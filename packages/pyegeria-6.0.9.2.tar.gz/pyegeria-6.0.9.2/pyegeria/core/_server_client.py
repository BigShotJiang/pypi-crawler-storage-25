"""
SPDX-License-Identifier: Apache-2.0
Copyright Contributors to the ODPi Egeria project.

This is a simple class to create and manage a connection to an Egeria backend. It is the Superclass for the
different client capabilities. It also provides the common methods used to make restful self.session to Egeria.

"""

import asyncio
import os
import re
import time
from collections.abc import Callable
from datetime import datetime
from typing import Any, Optional

from httpx import Response
from loguru import logger
from pydantic import TypeAdapter

from pyegeria.core._base_server_client import BaseServerClient
from pyegeria.core._exceptions import (
    PyegeriaConnectionException, PyegeriaInvalidParameterException, PyegeriaException, PyegeriaErrorCode
)
from pyegeria.core._globals import max_paging_size, NO_ELEMENTS_FOUND, default_time_out, COMMENT_TYPES
from pyegeria.view.base_report_formats import get_report_spec_match
from pyegeria.view.base_report_formats import select_report_spec
from pyegeria.models import (SearchStringRequestBody, FilterRequestBody, GetRequestBody, NewElementRequestBody,
                             TemplateRequestBody, UpdateElementRequestBody, NewAttachmentRequestBody,
                             NewRelationshipRequestBody,
                             UpdateRelationshipRequestBody, ResultsRequestBody,
                             DeploymentStatusSearchString, DeploymentStatusFilterRequestBody,
                             NewClassificationRequestBody,
                             DeleteElementRequestBody, DeleteRelationshipRequestBody, DeleteClassificationRequestBody,
                             LevelIdentifierQueryBody, UpdatePropertiesRequestBody, MetadataSourceRequestBody,
                             UpdateEffectivityDatesRequestBody, OpenMetadataDeleteRequestBody, ArchiveRequestBody,
                             NewOpenMetadataElementRequestBody, NewRelatedElementsRequestBody,
                             FindPropertyNamesRequestBody, FindRequestBody,
                             ContentStatusSearchString, ContentStatusFilterRequestBody,
                             ActivityStatusSearchString, ActivityStatusFilterRequestBody,
                             ActivityStatusRequestBody, ActionRequestBody)
from pyegeria.core.utils import body_slimmer, dynamic_catch
from pyegeria.view.output_formatter import populate_common_columns, resolve_output_formats, generate_output, \
    overlay_additional_values, _generate_default_output

# Main Client Imports
from pyegeria.models.models import (
    NewElementRequestBody,
    NewAttachmentRequestBody,
    UpdateElementRequestBody,
    UpdateRelationshipRequestBody,
    UpdateClassificationRequestBody,
    DeleteElementRequestBody,
    NewRelationshipRequestBody,
    DeleteRelationshipRequestBody,
    NewClassificationRequestBody,
    DeleteClassificationRequestBody,
    DeploymentStatusSearchString,
    DeploymentStatusFilterRequestBody,
    SearchStringRequestBody,
    FilterRequestBody,
    GetRequestBody,
    TemplateRequestBody,
    ResultsRequestBody,
    LevelIdentifierQueryBody,
    UpdatePropertiesRequestBody,
    MetadataSourceRequestBody,
    UpdateEffectivityDatesRequestBody,
    OpenMetadataDeleteRequestBody,
    ArchiveRequestBody,
    NewOpenMetadataElementRequestBody,
    NewRelatedElementsRequestBody,
    FindPropertyNamesRequestBody,
    FindRequestBody,
    ContentStatusSearchString,
    ContentStatusFilterRequestBody,
    ActivityStatusSearchString,
    ActivityStatusFilterRequestBody,
    ActivityStatusRequestBody,
    ActionRequestBody
)

__all__ = [
    # Models
    "NewElementRequestBody",
    "UpdateElementRequestBody",
    "UpdateRelationshipRequestBody",
    "UpdateClassificationRequestBody",
    "DeleteElementRequestBody",
    "NewRelationshipRequestBody",
    "DeleteRelationshipRequestBody",
    "NewClassificationRequestBody",
    "DeleteClassificationRequestBody",
    "SearchStringRequestBody",
    "FilterRequestBody",
    "GetRequestBody",
    "TemplateRequestBody",
    "ResultsRequestBody",
    "LevelIdentifierQueryBody",
    "UpdatePropertiesRequestBody",
    "MetadataSourceRequestBody",
    "UpdateEffectivityDatesRequestBody",
    "OpenMetadataDeleteRequestBody",
    "ArchiveRequestBody",
    "NewOpenMetadataElementRequestBody",
    "NewRelatedElementsRequestBody",
    "FindPropertyNamesRequestBody"
]

    # Exceptions


class ServerClient(BaseServerClient):
    """
    An abstract class used to establish connectivity for an Egeria Client
    for a particular server, platform and user.

    Attributes
    ----------
        server_name : str (required)
            Name of the OMAG server to use
        platform_url : str (required)
            URL of the server platform to connect to
        user_id : str
            The identity of the user calling the method - this sets a default optionally used by the methods
            when the user doesn't pass the user_id on a method call.
        user_pwd : str
            The password used to authenticate the server identity

    Methods
    -------
        create_egeria_bearer_token(user_Id: str, password: Optional[str] = None) -> str
           Create a bearer token using the simple Egeria token service - store the bearer token in the object instance.

        refresh_egeria_bearer_token()-> None
            Refresh the bearer token using the attributes of the object instance.

        set_bearer_token(token: str) -> None
            Set the bearer token attribute in the object instance - used when the token is generated
            by an external service.

        get_token() -> str
            Retrieve the bearer token.

        make_request(request_type: str, endpoint: str, payload: str | dict = None,
                    time_out: int = 30) -> Response
            Make an HTTP Restful request and handle potential errors and exceptions.

    """

    json_header = {"Content-Type": "application/json"}

    def __init__(
            self,
            server_name: str = None,
            platform_url: str = None,
            user_id: Optional[str] = None,
            user_pwd: Optional[str] = None,
            token: Optional[str] = None,
            token_src: Optional[str] = None,
            api_key: Optional[str] = None,
            page_size: int = None,
            local_qualifier: str = None,
    ):

        super().__init__(server_name, platform_url, user_id, user_pwd, token,
                         token_src, api_key, page_size, local_qualifier)

        self.command_root: str = f"{self.platform_url}/servers/{self.server_name}/api/open-metadata/"
        self._search_string_request_adapter = TypeAdapter(SearchStringRequestBody)
        self._filter_request_adapter = TypeAdapter(FilterRequestBody)
        self._get_request_adapter = TypeAdapter(GetRequestBody)
        self._new_element_request_adapter = TypeAdapter(NewElementRequestBody)
        self._new_attachment_request_adapter = TypeAdapter(NewAttachmentRequestBody)
        self._update_element_request_adapter = TypeAdapter(UpdateElementRequestBody)
        # self._update_status_request_adapter = TypeAdapter(UpdateStatusRequestBody)
        self._new_relationship_request_adapter = TypeAdapter(NewRelationshipRequestBody)
        self._new_classification_request_adapter = TypeAdapter(NewClassificationRequestBody)
        self._delete_element_request_adapter = TypeAdapter(DeleteElementRequestBody)
        self._delete_relationship_request_adapter = TypeAdapter(DeleteRelationshipRequestBody)
        self._delete_classification_request_adapter = TypeAdapter(DeleteClassificationRequestBody)
        self._template_request_adapter = TypeAdapter(TemplateRequestBody)
        self._update_relationship_request_adapter = TypeAdapter(UpdateRelationshipRequestBody)
        self._results_request_adapter = TypeAdapter(ResultsRequestBody)
        self._level_identifier_query_body = TypeAdapter(LevelIdentifierQueryBody)
        self._update_properties_request_adapter = TypeAdapter(UpdatePropertiesRequestBody)
        self._metadata_source_request_adapter = TypeAdapter(MetadataSourceRequestBody)
        self._update_effectivity_dates_request_adapter = TypeAdapter(UpdateEffectivityDatesRequestBody)
        self._open_metadata_delete_request_adapter = TypeAdapter(OpenMetadataDeleteRequestBody)
        self._archive_request_adapter = TypeAdapter(ArchiveRequestBody)
        self._new_open_metadata_element_request_adapter = TypeAdapter(NewOpenMetadataElementRequestBody)
        self._new_related_elements_request_adapter = TypeAdapter(NewRelatedElementsRequestBody)
        self._find_property_names_request_adapter = TypeAdapter(FindPropertyNamesRequestBody)
        self._find_request_adapter = TypeAdapter(FindRequestBody)
        self._deployment_status_search_request_adapter = TypeAdapter(DeploymentStatusSearchString)
        self._deployment_status_filter_request_adapter = TypeAdapter(DeploymentStatusFilterRequestBody)
        self._content_status_search_request_adapter = TypeAdapter(ContentStatusSearchString)
        self._content_status_filter_request_adapter = TypeAdapter(ContentStatusFilterRequestBody)
        self._activity_status_search_request_adapter = TypeAdapter(ActivityStatusSearchString)
        self._activity_status_filter_request_adapter = TypeAdapter(ActivityStatusFilterRequestBody)
        self._activity_status_request_adapter = TypeAdapter(ActivityStatusRequestBody)
        self._action_request_adapter = TypeAdapter(ActionRequestBody)
        self._request_id: str = None

        try:
            result = self.check_connection()
            logger.debug(f"client initialized, platform origin is: {result}")
        except PyegeriaConnectionException as e:
            raise PyegeriaConnectionException(e)

    # @logger.catch
    async def __async_get_guid__(
            self,
            guid: Optional[str] = None,
            display_name: Optional[str] = None,
            property_name: str = "qualifiedName",
            qualified_name: Optional[str] = None,
            tech_type: Optional[str] = None,
    ) -> str:
        """Helper function to return a server_guid - one of server_guid, qualified_name or display_name should
        contain information. If all are None, an exception will be thrown. If all contain
        values, server_guid will be used first, followed by qualified_name.  If the tech_type is supplied and the
        property_name is qualifiedName then the display_name will be pre-pended with the tech_type name to form a
        qualifiedName.

        An InvalidParameter Exception is thrown if multiple matches
        are found for the given property name. If this occurs, use a qualified name for the property name.
        Async version.
        """
        try:
            view_server = self.server_name
        except AttributeError:
            view_server = os.environ.get("EGERIA_VIEW_SERVER", "view-server")

        if guid:
            return guid

        if qualified_name:
            body = {
                "class": "FindPropertyNameProperties",
                "propertyValue": qualified_name,
                "propertyName": "qualifiedName",
                "forLineage": False,
                "forDuplicateProcessing": False,
                "effectiveTime": None,
            }
            url = (
                f"{self.platform_url}/servers/{self.server_name}/api/open-metadata/classification-explorer/"
                f"elements/guid-by-unique-name"
            )
        
            try:
                result = await self._async_make_request("POST", url, body_slimmer(body))
                guid_found = result.json().get("guid", NO_ELEMENTS_FOUND)
                if guid_found != NO_ELEMENTS_FOUND:
                    return guid_found
            except Exception:
                pass
        
        if display_name:
            if (tech_type) and (property_name == "qualifiedName"):
                name = f"{tech_type}::{display_name}"
                body = {
                    "class": "FindPropertyNameProperties",
                    "propertyValue": name,
                    "propertyName": property_name,
                    "forLineage": False,
                    "forDuplicateProcessing": False,
                    "effectiveTime": None,
                }
                url = (
                    f"{self.platform_url}/servers/{view_server}/api/open-metadata/classification-explorer/"
                    f"elements/guid-by-unique-name"
                )
        
                result = await self._async_make_request("POST", url, body_slimmer(body))
                return result.json().get("guid", NO_ELEMENTS_FOUND)
            else:
                body = {
                    "class": "FindPropertyNameProperties",
                    "propertyValue": display_name,
                    "propertyName": property_name,
                    "forLineage": False,
                    "forDuplicateProcessing": False,
                    "effectiveTime": None,
                }
                url = (
                    f"{self.platform_url}/servers/{view_server}/api/open-metadata/classification-explorer/"
                    f"elements/guid-by-unique-name"
                )
        
                result = await self._async_make_request("POST", url, body_slimmer(body))
                return result.json().get("guid", NO_ELEMENTS_FOUND)
        else:
            additional_info = {
                "reason": "Neither server_guid nor server_name were provided - please provide.",
                "parameters": (f"GUID={guid}, display_name={display_name}, property_name={property_name},"
                               f"qualified_name={qualified_name}, tech_type={tech_type}")
            }
            raise PyegeriaInvalidParameterException(None, None, additional_info)

    #
    # Include basic functions for finding elements and relationships.
    #

    def __get_guid__(
            self,
            guid: Optional[str] = None,
            display_name: Optional[str] = None,
            property_name: str = "qualifiedName",
            qualified_name: Optional[str] = None,
            tech_type: Optional[str] = None,
    ) -> str:
        """Helper function to return a server_guid - one of server_guid, qualified_name or display_name should
        contain information. If all are None, an exception will be thrown. If all contain
        values, server_guid will be used first, followed by qualified_name.  If the tech_type is supplied and the
        property_name is qualifiedName then the display_name will be pre-pended with the tech_type name to form a
        qualifiedName.

        An InvalidParameter Exception is thrown if multiple matches
        are found for the given property name. If this occurs, use a qualified name for the property name.
        Async version.
        """
        loop = asyncio.get_event_loop()
        result = loop.run_until_complete(
            self.__async_get_guid__(
                guid, display_name, property_name, qualified_name, tech_type
            )
        )
        return result

    async def _async_get_valid_metadata_values(
        self,
        property_name: str,
        type_name: Optional[str] = None,
    ) -> list:
        """
        Fetch valid values for a property. If found in cache, return from cache.
        Otherwise, fetch from Egeria and cache the result.
        Async version.
        """
        cache_key = f"{property_name}:{type_name}"
        if cache_key in self._valid_value_cache:
            return self._valid_value_cache[cache_key]

        url = (
            f"{self.platform_url}/servers/{self.server_name}/api/open-metadata/valid-metadata"
            f"/get-valid-metadata-values/{property_name}"
        )
        if type_name:
            url += f"?typeName={type_name}"
        else:
            url += "?typeName="

        try:
            resp = await self._async_make_request("GET", url)
            elements = resp.json().get("elements", [])
            self._valid_value_cache[cache_key] = elements
            return elements
        except Exception as e:
            logger.error(f"Error fetching valid values for {property_name}: {e}")
            return []

    def get_valid_metadata_values(
        self,
        property_name: str,
        type_name: Optional[str] = None,
    ) -> list:
        """
        Synchronous version of _async_get_valid_metadata_values.
        """
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            self._async_get_valid_metadata_values(property_name, type_name)
        )

    def __create_qualified_name__(self, type_name: str, display_name: str, local_qualifier: Optional[str] = None,
                                  version_identifier: Optional[str] = None) -> str:
        """Helper function to create a qualified name for a given type and display name.
           If present, the local qualifier will be prepended to the qualified name."""
        effective_local_qualifier = local_qualifier or self.local_qualifier or os.environ.get("EGERIA_LOCAL_QUALIFIER")

        if display_name is None:
            additional_info = {"reason": "Display name is missing - please provide.", }
            raise PyegeriaInvalidParameterException(additional_info=additional_info)
        display_name = re.sub(r'\s', '-', display_name.strip())  # This changes spaces between words to -; removing
        q_name = f"{type_name}::{display_name}"
        if effective_local_qualifier:
            q_name = f"{effective_local_qualifier}::{q_name}"
        if version_identifier:
            q_name = f"{q_name}::{version_identifier}"
        return q_name

#
# Basic Asset commands
#






    async def _async_get_relationships_with_property_value(
            self,
            relationship_type: str,
            property_value: str,
            property_names: list[str],
            effective_time: Optional[str] = None,
            for_lineage: Optional[bool] = None,
            for_duplicate_processing: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            time_out: int = default_time_out,
    ) -> list | str:
        """
        Retrieve relationships of the requested relationship type name and with the requested a value found in
        one of the relationship's properties specified.  The value must match exactly. Async version.

        https://egeria-project.org/types/

        Parameters
        ----------
        relationship_type: str
            - the type of relationship to navigate to related elements
        property_value: str
            - property value to be searched.
        property_names: [str]
            - property names to search in.
        effective_time: str, default = None
            - Time format is "YYYY-MM-DDTHH:MM:SS" (ISO 8601)
        for_lineage: bool, default is set by server
            - determines if elements classified as Memento should be returned - normally false
        for_duplicate_processing: bool, default is set by server
            - Normally false. Set true when the caller is part of a deduplication function
        start_from: int, default = 0
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.


        time_out: int, default = default_time_out
            - http request timeout for this request

        Returns
        -------
        [dict] | str
            Returns a string if no elements found and a list of dict of elements with the results.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid (for example, bad URL or invalid values).
        PyegeriaAPIException
            The server reported an error while processing a valid request.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """

        body = {
            "class": "FindPropertyNamesProperties",
            "openMetadataType": relationship_type,
            "propertyValue": property_value,
            "propertyNames": property_names,
            "effectiveTime": effective_time,
            "forLineage": for_lineage,
            "forDuplicateProcessing": for_duplicate_processing,
            "startFrom": start_from,
            "pageSize": page_size,
        }

        url = (
            f"{self.platform_url}/servers/{self.server_name}/api/open-metadata/classification-explorer/relationships/"
            f"with-exact-property-value"
        )

        response: Response = await self._async_make_request(
            "POST", url, body_slimmer(body), time_out=time_out
        )
        rels = response.json().get("relationships", NO_ELEMENTS_FOUND)
        if type(rels) is list:
            if len(rels) == 0:
                return NO_ELEMENTS_FOUND
        return rels

    def get_relationships_with_property_value(
            self,
            relationship_type: str,
            property_value: str,
            property_names: list[str],
            effective_time: Optional[str] = None,
            for_lineage: Optional[bool] = None,
            for_duplicate_processing: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            time_out: int = default_time_out,
    ) -> list | str:
        """
        Retrieve relationships of the requested relationship type name and with the requested a value found in
        one of the relationship's properties specified.  The value must match exactly.

        Parameters
        ----------
        relationship_type: str
            - the type of relationship to navigate to related elements
        property_value: str
            - property value to be searched.
        property_names: [str]
            - property names to search in.
        effective_time: str, default = None
            - Time format is "YYYY-MM-DDTHH:MM:SS" (ISO 8601)
        for_lineage: bool, default is set by server
            - determines if elements classified as Memento should be returned - normally false
        for_duplicate_processing: bool, default is set by server
            - Normally false. Set true when the caller is part of a deduplication function
        start_from: int, default = 0
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.


        time_out: int, default = default_time_out
            - http request timeout for this request

        Returns
        -------
        [dict] | str
            Returns a string if no elements found and a list of dict of elements with the results.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid (for example, bad URL or invalid values).
        PyegeriaAPIException
            The server reported an error while processing a valid request.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """

        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_relationships_with_property_value(
                relationship_type,
                property_value,
                property_names,
                effective_time,
                for_lineage,
                for_duplicate_processing,
                start_from,
                page_size,
                time_out,
            )
        )
        return response

    async def _async_get_elements_by_property_value(
            self,
            property_value: str,
            property_names: list[str],
            metadata_element_name: Optional[str] = None,
            effective_time: Optional[str] = None,
            for_lineage: Optional[bool] = None,
            for_duplicate_processing: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = 0,
            time_out: int = default_time_out,
    ) -> list | str:
        """
        Retrieve elements by a value found in one of the properties specified.  The value must match exactly.
        An open metadata type name may be supplied to restrict the results. Async version.

        https://egeria-project.org/types/

        Parameters
        ----------
        property_value: str
            - property value to be searched.
        property_names: [str]
            - property names to search in.
        metadata_element_name : str, default = None
            - open metadata type to be used to restrict the search
        effective_time: str, default = None
            - Time format is "YYYY-MM-DDTHH:MM:SS" (ISO 8601)
        for_lineage: bool, default is set by server
            - determines if elements classified as Memento should be returned - normally false
        for_duplicate_processing: bool, default is set by server
            - Normally false. Set true when the caller is part of a deduplication function
        start_from: int, default = 0
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.

        time_out: int, default = default_time_out
            - http request timeout for this request

        Returns
        -------
        [dict] | str
            Returns a string if no elements found and a list of dict of elements with the results.

        Raises
        ------
        PyegeriaException

        """

        body = {
            "class": "FindPropertyNamesProperties",
            "metadataElementTypeName": metadata_element_name,
            "propertyValue": property_value,
            "propertyNames": property_names,
            "effectiveTime": effective_time,
            "startFrom": start_from,
            "pageSize": page_size,
            "forLineage": for_lineage,
            "forDuplicateProcessing": for_duplicate_processing
        }

        url = f"{self.platform_url}/servers/{self.server_name}/api/open-metadata/classification-explorer/elements/by-exact-property-value"

        response: Response = await self._async_make_request(
            "POST", url, body_slimmer(body), time_out=time_out
        )

        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is list:
            if len(elements) == 0:
                return NO_ELEMENTS_FOUND
        return elements

    def get_elements_by_property_value(
            self,
            property_value: str,
            property_names: list[str],
            metadata_element_type: Optional[str] = None,
            effective_time: Optional[str] = None,
            for_lineage: Optional[bool] = None,
            for_duplicate_processing: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = 0,
            time_out: int = default_time_out,
    ) -> list | str:
        """
        Retrieve elements by a value found in one of the properties specified.  The value must match exactly.
        An open metadata type name may be supplied to restrict the results.

        https://egeria-project.org/types/

        Parameters
        ----------
        property_value: str
            - property value to be searched.
        property_names: [str]
            - property names to search in.
        metadata_element_type : str, default = None
            - open metadata type to be used to restrict the search
        effective_time: str, default = None
            - Time format is "YYYY-MM-DDTHH:MM:SS" (ISO 8601)
        for_lineage: bool, default is set by server
            - determines if elements classified as Memento should be returned - normally false
        for_duplicate_processing: bool, default is set by server
            - Normally false. Set true when the caller is part of a deduplication function
        start_from: int, default = 0
            - index of the list to start from (0 for start).
        page_size: int, default = 0
            - maximum number of elements to return.
        time_out: int, default = default_time_out
            - http request timeout for this request

        Returns
        -------
        [dict] | str
            Returns a string if no elements found and a list of dict of elements with the results.

        Raises
        ------
        PyegeriaException.
        """

        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_elements_by_property_value(property_value, property_names, metadata_element_type,
                                                       effective_time, for_lineage, for_duplicate_processing,
                                                       start_from, page_size, time_out)
        )
        return response

    async def _async_get_guid_for_name(
            self, name: str, property_name: list[str] = ["qualifiedName", "displayName", "resourceName","identifier"],
            type_name: str = None

    ) -> list | str:
        """
        Retrieve the guid associated with the supplied element name.
        If more than one element returned, an exception is thrown. Async version.

        Parameters
        ----------
        name: str
            - element name to be searched.
        property_name: [str], default = ["qualifiedName","displayName"]
            - properties to search in.
        type_name: str, default = "ValidMetadataValue"
            - metadata element type name to be used to restrict the search
        Returns
        -------
        str
            Returns the guid of the element.

        Raises
        ------
        PyegeriaException
        """

        elements = await self._async_get_elements_by_property_value(name, property_name, type_name)

        if isinstance(elements, list|dict):
            if len(elements) == 0:
                return NO_ELEMENTS_FOUND
            elif len(elements) > 1:
                raise PyegeriaException(context={"issue": "Multiple elements found for supplied name!"})
            elif len(elements) == 1:
                return elements[0]["elementHeader"]["guid"]
        else:
            return NO_ELEMENTS_FOUND
        return elements

    def get_guid_for_name(
            self, name: str, property_name: list[str] = ["qualifiedName", "displayName","resourceName","identifier"],
            type_name: str = None
    ) -> list | str:
        """
        Retrieve the guid associated with the supplied element name.
        If more than one element returned, an exception is thrown.

        Parameters
        ----------
        name: str
            - element name to be searched.
        property_name: [str], default = ["qualifiedName","displayName"]
            - properties to search in.
        type_name: str, default = "ValidMetadataValue"
            - metadata element type name to be used to restrict the search
        Returns
        -------
        str
            Returns the guid of the element.

        Raises
        ------
        PyegeriaException
        """

        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_guid_for_name(name, property_name, type_name)
        )
        return response

    async def _async_get_element_by_guid_(self, element_guid: str) -> dict | str:
        """
            Simplified, internal version of get_element_by_guid found in Classification Manager.
            Retrieve an element by its guid.  Async version.

        Parameters
        ----------
        element_guid: str
            - unique identifier for the element

        Returns
        -------
        dict | str
            Returns a string if no element found; otherwise a dict of the element.

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """

        body = {
            "class": "EffectiveTimeQueryRequestBody",
            "effectiveTime": None,
        }

        url = (f"{self.platform_url}/servers/{self.server_name}/api/open-metadata/classification-explorer/elements/"
               f"{element_guid}?forLineage=false&forDuplicateProcessing=false")

        response: Response = await self._async_make_request("POST", url, body_slimmer(body))

        elements = response.json().get("element", NO_ELEMENTS_FOUND)

        return elements

    def _get_element_by_guid_(self, element_guid: str) -> dict | str:
        """
            Simplified, internal version of get_element_by_guid found in Classification Manager.
            Retrieve an element by its guid.

        Parameters
        ----------
        element_guid: str
            - unique identifier for the element

        Returns
        -------
        dict | str
            Returns a string if no element found; otherwise a dict of the element.

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        result = loop.run_until_complete(
            self._async_get_element_by_guid_(
                element_guid
            )
        )
        return result


    async def _async_get_related_elements_with_property_value(
            self,
            element_guid: str,
            relationship_type: str,
            property_value: str,
            property_names: list[str],
            metadata_element_type_name: Optional[str] = None,
            start_at_end: int = 1,
            effective_time: Optional[str] = None,
            for_lineage: Optional[bool] = None,
            for_duplicate_processing: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = 0,
            time_out: int = default_time_out,
    ) -> list | str:
        """
        Retrieve elements linked via the requested relationship type name and with the requested a value found in one of
        the classification's properties specified.  The value must match exactly. An open metadata type name may be
        supplied to restrict the types of elements returned. Async version.

        https://egeria-project.org/types/

        Parameters
        ----------
        element_guid: str
            - the base element to get related elements for
        relationship_type: str
            - the type of relationship to navigate to related elements
        property_value: str
            - property value to be searched.
        property_names: [str]
            - property names to search in.
        metadata_element_type_name : str, default = None
            - restrict search to elements of this open metadata type
        start_at_end: int, default = 1
            - The end of the relationship to start from - typically End1
            - open metadata type to be used to restrict the search
        effective_time: str, default = None
            - Time format is "YYYY-MM-DDTHH:MM:SS" (ISO 8601)
        for_lineage: bool, default is set by server
            - determines if elements classified as Memento should be returned - normally false
        for_duplicate_processing: bool, default is set by server
            - Normally false. Set true when the caller is part of a deduplication function
        start_from: int, default = 0
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.


        time_out: int, default = default_time_out
            - http request timeout for this request

        Returns
        -------
        [dict] | str
            Returns a string if no elements found and a list of dict of elements with the results.

        Raises
        ------
        PyegeriaException
        """

        body = {
            "class": "FindPropertyNamesProperties",
            "metadataElementTypeName": metadata_element_type_name,
            "propertyValue": property_value,
            "propertyNames": property_names,
            "effectiveTime": effective_time,
            "forLineage": for_lineage,
            "forDuplicateProcessing": for_duplicate_processing,
            "startFrom": start_from,
            "pageSize": page_size
        }

        url = (
            f"{self.platform_url}/servers/{self.server_name}/api/open-metadata/classification-explorer/elements/{element_guid}"
            f"/by-relationship/{relationship_type}/with-exact-property-value?startAtEnd={start_at_end}"
        )

        response: Response = await self._async_make_request(
            "POST", url, body_slimmer(body), time_out=time_out
        )
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is list:
            if len(elements) == 0:
                return NO_ELEMENTS_FOUND
        return elements

    async def _async_get_connector_guid(self, connector_name: str) -> str:
        """Get the guid of a connector. Async version.
            Parameters:
                connector_name (str): The name of the connector to retrieve the guid for.
            Returns:
                str: The guid of the connector.
        """
        rel = await self._async_get_relationships_with_property_value(
            relationship_type="RegisteredIntegrationConnector",
            property_names=["connectorName"],
            property_value=connector_name,
        )
        if rel == "No elements found":
            logger.error(f"\n\n===> No connector found with name '{connector_name}'\n\n")
            return "No connector found"
        connector_guid = rel[0]['end2']['guid']

        if connector_guid is None:
            logger.error(f"\n\n===> No connector found with name '{connector_name}'\n\n")
            return "No connector found"

        return connector_guid

    def get_connector_guid(self, connector_name: str) -> str:
        """Get the guid of a connector.
            Parameters:
                connector_name (str): The name of the connector to retrieve the guid for.
            Returns:
                str: The guid of the connector.
        """

        loop = asyncio.get_event_loop()
        result = loop.run_until_complete(
            self._async_get_connector_guid(
                connector_name
            )
        )
        return result

    async def _async_add_archive_file(
            self,
            archive_file: str,
            server_guid: Optional[str] = None,
            display_name: Optional[str] = None,
            qualified_name: Optional[str] = None,
            time_out: int = 120,
    ) -> None:
        """Add a new open metadata archive to running OMAG Server's repository.
            An open metadata archive contains metadata types and instances.  This operation loads an open metadata archive
            that is stored in the named file.  It can be used with OMAG servers that are of type Open Metadata Store.
            Async version.

            https://egeria-project.org/concepts/open-metadata-archives/

        Parameters
        ----------
        archive_file: str
            Open metadata archive file to load.
        server_guid : str, default = None
            Identity of the server to act on. If not specified, qualified_name or server_name must be.
        display_name: str, default = None
            Name of server to act on. If not specified, server_guid or qualified_name must be.
        qualified_name: str, default = None
            Unique name of server to act on. If not specified, server_guid or server_name must be.
        time_out: int, optional
           Time out for the rest call.

        Returns
        -------
        Response
          None

        Raises
        ------
        PyegeriaInvalidParameterException
        PyegeriaAPIException
        PyegeriaUnauthorizedException

        """
        server_guid = self.__get_guid__(
            server_guid,
            display_name,
            "resourceName",
            qualified_name,
            "Metadata Access Server",
        )

        url = f"{self.command_root}runtime-manager/omag-servers/{server_guid}/instance/load/open-metadata-archives/file"

        await self._async_make_request(
            "POST-DATA", url, archive_file, time_out=time_out
        )


    def add_archive_file(
            self,
            archive_file: str,
            server_guid: Optional[str] = None,
            display_name: Optional[str] = None,
            qualified_name: Optional[str] = None,
            time_out: int = 120,
    ) -> None:
        """Add a new open metadata archive to running OMAG Server's repository.
            An open metadata archive contains metadata types and instances.  This operation loads an open metadata archive
            that is stored in the named file.  It can be used with OMAG servers that are of type Open Metadata Store.

            https://egeria-project.org/concepts/open-metadata-archives/

        Parameters
        ----------
        archive_file: str
            Open metadata archive file to load.
        server_guid : str, default = None
            Identity of the server to act on. If not specified, qualified_name or server_name must be.
        display_name: str, default = None
            Name of server to act on. If not specified, server_guid or qualified_name must be.
        qualified_name: str, default = None
            Unique name of server to act on. If not specified, server_guid or server_name must be.
        time_out: int, optional, default = 60 seconds

        Returns
        -------
        Response
           None

        Raises
        ------
        PyegeriaInvalidParameterException
        PyegeriaAPIException
        PyegeriaUnauthorizedException

        """

        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_add_archive_file(
                archive_file, server_guid, display_name, qualified_name, time_out
            )
        )
        return

    #
    #   Common feedback commands
    #

    def make_feedback_qn(self, feedback_type, src_guid, display_name=None) -> str:
        timestamp = int(time.time())
        if display_name is None:
            return f"{feedback_type}::{src_guid}::{self.user_id}::{timestamp}"
        else:
            return f"{feedback_type}::{src_guid}::{self.user_id}::{display_name}::{timestamp}"


    async def _async_add_comment_to_element(
            self,
            element_guid: str,
            comment: Optional[str] = None,
            comment_type: str = "STANDARD_COMMENT",
            body: dict = None,
    ) -> dict | str:
        """
        Creates a comment and attaches it to an element.

        Parameters
        ----------

        element_guid: str
            - unique id for the element.
        comment: str
            - The text of the comment.

        comment_type: str
            - the type of comment, default is STANDARD_COMMENT.
        body
            - containing type of comment enum and the text of the comment. Body overrides other parameters if present.
        Returns
        -------
        ElementGUID

        Raises
        ------
        PyEgeriaException

        """
        if body is None:
            if comment_type not in COMMENT_TYPES:
                context = {"issue": "Invalid comment type"}
                raise PyegeriaInvalidParameterException(context=context)
            body = {
                "class": "NewAttachmentRequestBody",
                "properties": {
                    "class": "CommentProperties",
                    "qualifiedName": self.make_feedback_qn("Comment", element_guid),
                    "description": comment,
                    "commentType": comment_type
                }
            }
        elif body is None and comment is None:
            context = {"issue": "Invalid comment and body not provided"}
            raise PyegeriaInvalidParameterException(context=context)

        url = f"{self.command_root}feedback-manager/elements/{element_guid}/comments"
        response = await self._async_make_request("POST", url, body)
        return response.json()

    def add_comment_to_element(
            self,
            element_guid: str,
            comment: Optional[str] = None,
            comment_type: str = "STANDARD_COMMENT",
            body: dict = None,
    ) -> dict | str:
        """
        Creates a comment and attaches it to an element.

        Parameters
        ----------

        element_guid
            - String - unique id for the element.
        comment: str
            - The text of the comment.
        comment_type
            - String - the type of comment, default is STANDARD_COMMENT.
        body
            - containing type of comment enum and the text of the comment. Body overrides other parameters if present.

        Returns
        -------
        ElementGUID

        Raises
        ------
        PyEgeriaException
        """

        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_add_comment_to_element(element_guid, comment, comment_type, body)
        )
        return response

    async def _async_update_comment(
            self,
            comment_guid: str,
            comment: Optional[str] = None,
            comment_type: str = "STANDARD_COMMENT",
            body: Optional[dict | UpdateElementRequestBody] = None,
            merge_update: bool = True,
    ) -> None:
        """
        Updates a comment.

        Parameters
        ----------

        comment_guid: str
            - unique id for the comment.
        comment: str
            - The text of the comment.

        comment_type: str
            - the type of comment, default is STANDARD_COMMENT.
        body: dict | UpdateElementRequestBody
            - containing type of comment enum and the text of the comment. Body overrides other parameters if present.
        merge_update: bool
        - Whether to merge the updated attributes or replace them.

        Returns
        -------
        None

        Raises
        ------
        PyEgeriaException

        """
        if body is None and comment:
            if comment_type not in COMMENT_TYPES:
                context = {"issue": "Invalid comment type"}
                raise PyegeriaInvalidParameterException(context=context)
            body = {
                "class": "UpdateElementRequestBody",
                "mergeUpdate": merge_update,
                "properties": {
                    "class": "CommentProperties",
                    "description": comment,
                    "commentType": comment_type
                }
            }
        elif body is None and comment is None:
            context = {"issue": "Invalid comment and body not provided"}
            raise PyegeriaInvalidParameterException(context=context)

        url = f"{self.command_root}feedback-manager/comments/{comment_guid}/update"
        await self._async_update_element_body_request(url, ["Comment"], body)

    def update_comment(
            self,
            comment_guid: str,
            comment: Optional[str] = None,
            comment_type: str = "STANDARD_COMMENT",
            body: Optional[dict | UpdateElementRequestBody] = None,
            merge_update: bool = True,
    ) -> None:
        """
        Creates a comment and attaches it to an element.

        Parameters
        ----------

        comment_guid
            - String - unique id for the comment.
        comment: str
            - The text of the comment.
        comment_type
            - String - the type of comment, default is STANDARD_COMMENT.
        body
            - containing type of comment enum and the text of the comment. Body overrides other parameters if present.
        merge_update: bool
            - Whether to merge the updated attributes or replace them.
        Returns
        -------
        ElementGUID

        Raises
        ------
        PyEgeriaException

        """

        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_update_comment(comment_guid, comment, comment_type, body, merge_update)
        )

    async def _async_setup_accepted_answer(
            self,
            question_comment_guid: str,
            answer_comment_guid: str,

    ) -> None:
        """
        Link a comment that contains the best answer to a question posed in another comment. Async version.

        Parameters
        ----------

        question_comment_guid: str
            - unique id for the question comment.
        answer_comment_guid: str
            - unique id for the answer comment.

        Returns
        -------
        None

        Raises
        ------
        PyEgeriaException

        """

        url = f"{self.command_root}feedback-manager/comments/questions/{question_comment_guid}/answers/{answer_comment_guid}"
        await self._async_make_request("POST", url)

    def setup_accepted_answer(
            self,
            question_comment_guid: str,
            answer_comment_guid: str,

    ) -> None:
        """
        Link a comment that contains the best answer to a question posed in another comment.

        Parameters
        ----------

        question_comment_guid: str
            - unique id for the question comment.
        answer_comment_guid: str
            - unique id for the answer comment.

        Returns
        -------
        None

        Raises
        ------
        PyEgeriaException

        """

        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_setup_accepted_answer(question_comment_guid, answer_comment_guid)
        )

    async def _async_clear_accepted_answer(
            self,
            question_comment_guid: str,
            answer_comment_guid: str,

    ) -> None:
        """
        Remove the accepted-answer link between a question comment and its answer. Async version.

        Parameters
        ----------
        question_comment_guid: str
            - unique id for the question comment.
        answer_comment_guid: str
            - unique id for the answer comment.

        Returns
        -------
        None

        Raises
        ------
        PyEgeriaException
        """

        url = f"{self.command_root}feedback-manager/comments/questions/{question_comment_guid}/answers/{answer_comment_guid}/remove"
        await self._async_make_request("POST", url)

    def setup_clear_answer(
            self,
            question_comment_guid: str,
            answer_comment_guid: str,

    ) -> None:
        """
        Remove the accepted-answer link between a question comment and its answer.

        Parameters
        ----------
        question_comment_guid: str
            - unique id for the question comment.
        answer_comment_guid: str
            - unique id for the answer comment.

        Returns
        -------
        None

        Raises
        ------
        PyEgeriaException
        """

        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_clear_accepted_answer(question_comment_guid, answer_comment_guid)
        )

    async def _async_remove_comment_from_element(
            self,
            comment_guid: str,
            body: Optional[dict | DeleteElementRequestBody] = None,
            cascade_delete: bool = False,
    ) -> None:
        """
        Removes a comment added to the element by this user.

        This deletes the link to the comment, the comment itself and any comment replies attached to it.

        Parameters
        ----------
        comment_guid
            - String - unique id for the comment object
        server_name
            - name of the server instances for this request

        body
            - containing type of comment enum and the text of the comment.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        Args:
            cascade_delete ():
        """

        url = f"{self.command_root}feedback-manager/comments/{comment_guid}/remove"
        await self._async_delete_element_request(url, body, cascade_delete)

    def remove_comment_from_element(
            self,
            comment_guid: str,
            body: Optional[dict | DeleteElementRequestBody] = None,
            cascade_delete: bool = False,

    ) -> None:
        """
        Remove a comment from an element added by this user.

        This deletes the link to the comment, the comment itself and any comment replies attached to it.

        Parameters
        ----------
        comment_guid: str
            - unique id for the comment object
        body: dict | DeleteElementRequestBody, optional
            - contains comment type and text
        cascade_delete: bool, default = False
            - whether to cascade delete

        Returns
        -------
        None

        Raises
        ------
        PyEgeriaException
        """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_remove_comment_from_element(comment_guid, body, cascade_delete=cascade_delete)
        )

    async def _async_get_comment_by_guid(
            self,
            comment_guid: str, element_type: str = "Comment",
            body: Optional[dict | GetRequestBody] = None,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None
    ) -> dict | str:
        """
        Return the requested comment.

        Parameters
        ----------
        comment_guid
            - unique identifier for the comment object.
        body
            - optional effective time

        Returns
        -------
        comment properties

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.

        """

        url = f"{self.command_root}feedback-manager/comments/{comment_guid}/retrieve"
        response = await self._async_get_guid_request(url, _type=element_type,
                                                      _gen_output=self._generate_comment_output,
                                                      output_format=output_format, report_spec=report_spec,
                                                      body=body)

        return response

    def get_comment_by_guid(
            self,
            comment_guid: str, element_type: str = "Comment",
            body: Optional[dict | GetRequestBody] = None,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None
    ) -> dict | str:
        """
        Return the requested comment.

        Parameters
        ----------
        comment_guid
            - unique identifier for the comment object.
        body
            - optional effective time

        Returns
        -------
        comment properties

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.

        Args:
            element_type ():
            output_format ():
            report_spec ():
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_comment_by_guid(comment_guid, element_type, body, output_format, report_spec)
        )
        return response

    async def _async_get_attached_comments(
            self,
            element_guid: str,
            element_type: str = "Comment",
            body: dict = {},
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None

    ) -> dict | str:
        """
        Return the comments attached to an element.

        Parameters
        ----------
        element_guid
            - unique identifier for the element that the comments are connected to (maybe a comment too).
        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.


        Returns
        -------
        list of comments

        Raises
        ------
        PyegeriaException

        """

        url = f"{self.command_root}feedback-manager/elements/{element_guid}/comments/retrieve"
        response = await self._async_make_request("POST", url, body)
        element = response.json().get("elements", NO_ELEMENTS_FOUND)
        if element == NO_ELEMENTS_FOUND:
            return NO_ELEMENTS_FOUND
        if output_format.upper() != 'JSON':  # return a simplified markdown representation
            return self._generate_comment_output(element, None, output_format, report_spec)
        return response.json().get("elements", NO_ELEMENTS_FOUND)

    def get_attached_comments(
            self, element_guid: str,
            element_type: Optional[str] = None,
            body: dict = {},
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None
    ) -> dict | str:
        """
        Return the comments attached to an element.

        Parameters
        ----------
        element_guid
            - unique identifier for the element that the comments are connected to (maybe a comment too).
        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.

        Returns
        -------
        list of comments

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.

        Args:
            element_type ():
            output_format ():
            report_spec ():
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_attached_comments(element_guid, element_type, body, start_from, page_size, output_format,
                                              report_spec)
        )
        return response

    async def _async_find_comments(
            self,
            search_string: Optional[str] = None,
            classification_names: Optional[list[str]] = None,
            metadata_element_subtypes: list[str] = ["Comment"],
            starts_with: Optional[bool] = None,
            ends_with: Optional[bool] = None,
            ignore_case: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            **kwargs
    ) -> dict | str:

        """
        Return the list of comments containing the supplied string. Async Version.

        Parameters
        ----------
        search_string : str, optional
            Search string to find in comments.
        classification_names : list[str], optional
            List of classification names to filter by.
        metadata_element_subtypes : list[str], default ["Comment"]
            List of metadata element subtypes to search.
        starts_with : bool, optional
            Does the value start with the supplied string?
        ends_with : bool, optional
            Does the value end with the supplied string?
        ignore_case : bool, optional
            Should the search ignore case?
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default max_paging_size
            Maximum number of elements to return.
        output_format : str, default "JSON"
            Output format for the response.
        report_spec : str | dict, optional
            Output format set for the response.
        body : dict | SearchStringRequestBody, optional
            Body of the request. Details of the body override other parameters if present.
        **kwargs : dict, optional
            Additional parameters supported by the underlying find request:
            
            - anchor_domain : str - Domain to anchor the search
            - metadata_element_type : str - Specific metadata element type
            - skip_relationships : list[str] - Relationship types to skip
            - include_only_relationships : list[str] - Only include these relationship types
            - skip_classified_elements : list[str] - Skip elements with these classifications
            - include_only_classified_elements : list[str] - Only include elements with these classifications
            - graph_query_depth : int - Depth of graph traversal (default 3)
            - governance_zone_filter : list[str] - Filter by governance zones
            - as_of_time : str - Historical query time
            - effective_time : str - Effective time for the query
            - relationship_page_size : int - Page size for relationships
            - limit_results_by_status : list[str] - Filter by element status
            - sequencing_order : str - Order of results
            - sequencing_property : str - Property to sequence by
            - property_names : list[str] - Specific properties to search

        Returns
        -------
        dict | str
            List of comment objects in the requested format.

        Raises
        ------
        PyegeriaException
            If there are issues in communications, message format, or Egeria errors.

        Notes
        -----
        The **kwargs parameter allows advanced users to access all parameters supported by the
        underlying _async_find_request helper method. Common parameters are explicitly listed
        in the signature for discoverability, while advanced parameters can be passed via kwargs.

        Examples
        --------
        Basic usage:
            >>> comments = await client._async_find_comments("test", starts_with=True)
        
        Advanced usage with kwargs:
            >>> comments = await client._async_find_comments(
            ...     "test",
            ...     starts_with=True,
            ...     graph_query_depth=5,
            ...     governance_zone_filter=["zone1"]
            ... )
        """

        url = f"{self.command_root}feedback-manager/comments/by-search-string"
        
        # Build params dict with explicit parameters
        params = {
            'search_string': search_string,
            'classification_names': classification_names,
            'metadata_element_subtypes': metadata_element_subtypes,
            'starts_with': starts_with,
            'ends_with': ends_with,
            'ignore_case': ignore_case,
            'start_from': start_from,
            'page_size': page_size,
            'output_format': output_format,
            'report_spec': report_spec,
            'body': body
        }
        # Merge with any additional kwargs, removing None values
        params.update(kwargs)
        # Filter out None values, but keep search_string even if None (it's required)
        params = {k: v for k, v in params.items() if v is not None or k == 'search_string'}
        
        response = await self._async_find_request(url, _type="Comment", _gen_output=self._generate_comment_output,
                                                  **params)

        return response

    def find_comments(
            self,
            search_string: Optional[str] = None,
            classification_names: Optional[list[str]] = None, metadata_element_subtypes: list[str] = ["Comment"],
            starts_with: bool = True,
            ends_with: bool = False,
            ignore_case: bool = False,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None,
            body: Optional[dict | SearchStringRequestBody] = None
    ) -> dict | str:
        """
        Return the list of comments containing the supplied string. Async Version.

        Parameters
        ----------
        search_string
            - search string and effective time.

        starts_with
            - does the value start with the supplied string?
        ends_with
            - does the value end with the supplied string?
        ignore_case
            - should the search ignore case?
        start_from
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.
        output_format
            - output format for the response
        report_spec
            - output format set for the response
        body
            - body of the request. Details of the body overrides other parameters if present.

        Returns
        -------
        list of comment objects

        Raises
        ------
        PyegeriaException

        Args:
            classification_names ():
            metadata_element_subtypes ():


        """
        loop = asyncio.get_event_loop()
        resp = loop.run_until_complete(
            self._async_find_comments(search_string, classification_names, metadata_element_subtypes, starts_with,
                                      ends_with, ignore_case, start_from, page_size, output_format, report_spec, body)
        )

        return resp

    def _generate_formatted_output(
            self,
            elements: dict | list[dict],
            query_string: Optional[str] = None,
            entity_type: str = "Referenceable",
            output_format: str = "DICT",
            extract_properties_func: Optional[Callable] = None,
            report_spec: Optional[dict | str] = None,
            **kwargs
    ) -> str | list[dict]:
        """Centralized output generation logic for OMVS managers.

        Args:
            elements: Raw elements to format.
            query_string: Search or filter string. If None, derived from kwargs.
            entity_type: Type of the entity for reporting.
            output_format: Desired format (DICT, MD, etc.).
            extract_properties_func: Callback to extract properties from a single element.
            report_spec: Optional specification (by label or dict).
            **kwargs: Passed through to resolve_output_formats and generate_output.
        """
        if output_format.upper() == "JSON":
            return elements

        # Resolve output formats structure
        output_formats = resolve_output_formats(
            entity_type,
            output_format,
            report_spec,
            default_label=entity_type,
            **kwargs
        )

        # Dynamic discovery of additional properties function
        get_additional_props_func = None
        if output_formats:
            get_additional_props_name = output_formats.get("get_additional_props", {}).get("function", None)
            if isinstance(get_additional_props_name, str):
                # Expecting something like "ClassName.method_name" or just "method_name"
                method_name = get_additional_props_name.split(".")[-1]
                if hasattr(self, method_name):
                    get_additional_props_func = getattr(self, method_name)

        # Priority: explicit query_string -> search_string -> filter_string
        if query_string is None:
            query_string = kwargs.get('search_string') or kwargs.get('filter_string')

        # Clean up kwargs to avoid multiple values for arguments we pass explicitly to generate_output
        for key in ['elements', 'search_string', 'filter_string', 'entity_type', 
                    'output_format', 'extract_properties_func', 
                    'get_additional_props_func', 'columns_struct']:
            kwargs.pop(key, None)

        return generate_output(
            elements=elements,
            search_string=query_string,
            entity_type=entity_type,
            output_format=output_format,
            extract_properties_func=extract_properties_func,
            get_additional_props_func=get_additional_props_func,
            columns_struct=output_formats,
            **kwargs
        )

    def _generate_comment_output(self, elements: dict | list[dict], search_string: Optional[str] = None,
                                 element_type_name: Optional[str] = None,
                                 output_format: str = 'DICT',
                                 report_spec: dict | str = None,
                                 **kwargs) -> str | list[dict]:
        return self._generate_formatted_output(
            elements=elements,
            query_string=search_string,
            entity_type=element_type_name or 'Comment',
            output_format=output_format,
            extract_properties_func=self._extract_comment_properties,
            report_spec=report_spec,
            **kwargs
        )

    #
    # Note log
    #

    @dynamic_catch
    async def _async_create_note_log(
            self,
            element_guid: Optional[str] = None,
            display_name: Optional[str] = None,
            description: Optional[str] = None,
            body: dict = None,
    ) -> str:
        """
        Creates a new noteLog and returns the unique identifier for it. Async Version.

        Parameters
        ----------
        element_guid: str, optional
            - unique identifier of the element where the note log is attached
        display_name: str, optional
            - name of the note log
        description: str, optional
            - text of the note log
        body
            - contains the name of the log and text. If present, the contents overrides
              the supplied parameters. If no element is provided, the property class must be "NewElementRequestBody".

        Returns
        -------
        ElementGUID

        Raises
        ------
        PyegeriaException
        Notes:
        ------
        Sample Body (simple version attaching to an associated element):

        {
            "class" : "NewAttachmentRequestBody",
            "initialClassifications": {
              "ZoneMembership" : {
                "class" : "ZoneMembershipProperties",
                "zoneMembership" : [ "erinoverview", "peterprofile" ]
              }
            },
            "properties": {
              "class": "NoteLogProperties",
              "qualifiedName": "Add unique name here",
              "displayName": "Add name here",
              "description": "Add description here",
              "additionalProperties": {
                "propertyName 1": "property value 1",
                "propertyName 2": "property value 2"
              }
            }
        }

        Full feature version allowing optional standalone use or attachment to an additional element:
        {
          "class" : "NewElementRequestBody",
          "anchorGUID" : "add guid here",
          "isOwnAnchor": false,
          "parentGUID": "add guid here",
          "parentRelationshipTypeName": "add type name here",
          "parentRelationshipProperties": {
            "class": "RelationshipElementProperties",
            "propertyValueMap" : {
              "description" : {
                "class": "PrimitiveTypePropertyValue",
                "typeName": "string",
                "primitiveValue" : "New description"
              }
            }
          },
          "parentAtEnd1": false,
          "properties": {
            "class": "NoteLogProperties",
            "qualifiedName": "Add unique name here",
            "displayName": "Add name here",
            "description": "Add description here",
            "additionalProperties": {
              "propertyName 1": "property value 1",
              "propertyName 2": "property value 2"
            },
            "effectiveFrom": "{{$isoTimestamp}}",
            "effectiveTo": "{{$isoTimestamp}}"
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }


        """
        if body is None and element_guid:
            body = {
                "class": "NewAttachmentRequestBody",
                "properties": {
                    "class": "NoteLogProperties",
                    "typeName": "NoteLog",
                    "displayName": display_name,
                    "qualifiedName": self.make_feedback_qn("NoteLog", element_guid, display_name),
                    "description": description,
                }
            }
        elif body is None and not element_guid:
            body = {
                "class": "NewAElementRequestBody",
                "properties": {
                    "class": "NoteLogProperties",
                    "typeName": "NoteLog",
                    "displayName": display_name,
                    "qualifiedName": self.make_feedback_qn("NoteLog", element_guid, display_name),
                    "description": description,
                }
            }

        elif body is None and display_name is None:
            context = {"issue": "Invalid display name and body not provided"}
            raise PyegeriaInvalidParameterException(context=context)

        if element_guid:
            url = f"{self.command_root}feedback-manager/elements/{element_guid}/note-logs"
        else:
            url = f"{self.command_root}feedback-manager/note-logs"
        response = await self._async_make_request("POST", url, body_slimmer(body))
        return response.json()

    @dynamic_catch
    def create_note_log(
            self,
            element_guid: Optional[str] = None,
            display_name: Optional[str] = None,
            description: Optional[str] = None,
            body: dict = None,
    ) -> str:
        """
        Creates a new noteLog and returns the unique identifier for it.

        Parameters
        ----------
        element_guid, str, optional
            - unique identifier of the element where the note log is attached
        display_name: str, optional
            - name of the note log
        description: str, optional
            - text of the note log
        body
            - contains the name of the tag and (optional) description of the tag. If present, the contents overridee
              the supplied parameters.

        Returns
        -------
        ElementGUID

        Raises
        ------
        PyegeriaException
        Notes:
        ------
        Sample Body:

        {
            "class" : "NewAttachmentRequestBody",
            "initialClassifications": {
              "ZoneMembership" : {
                "class" : "ZoneMembershipProperties",
                "zoneMembership" : [ "erinoverview", "peterprofile" ]
              }
            },
            "properties": {
              "class": "NoteLogProperties",
              "qualifiedName": "Add unique name here",
              "displayName": "Add name here",
              "description": "Add description here",
              "additionalProperties": {
                "propertyName 1": "property value 1",
                "propertyName 2": "property value 2"
              }
            }
        }

        Full feature version allowing optional standalone use or attachment to an additional element:
        {
          "class" : "NewElementRequestBody",
          "anchorGUID" : "add guid here",
          "isOwnAnchor": false,
          "parentGUID": "add guid here",
          "parentRelationshipTypeName": "add type name here",
          "parentRelationshipProperties": {
            "class": "RelationshipElementProperties",
            "propertyValueMap" : {
              "description" : {
                "class": "PrimitiveTypePropertyValue",
                "typeName": "string",
                "primitiveValue" : "New description"
              }
            }
          },
          "parentAtEnd1": false,
          "properties": {
            "class": "NoteLogProperties",
            "qualifiedName": "Add unique name here",
            "displayName": "Add name here",
            "description": "Add description here",
            "additionalProperties": {
              "propertyName 1": "property value 1",
              "propertyName 2": "property value 2"
            },
            "effectiveFrom": "{{$isoTimestamp}}",
            "effectiveTo": "{{$isoTimestamp}}"
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }

        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_create_note_log(element_guid, display_name, description, body)
        )
        return response

    @dynamic_catch
    async def _async_update_note_log(
            self,
            note_log_guid: str,
            display_name: Optional[str] = None,
            description: Optional[str] = None,
            body: dict = None,
            merge_update: bool = True,
    ) -> None:
        """
        Update an existing note log. Async Version.

        Parameters
        ----------
        note_log_guid
            - a unique identifier for the note log to change.
        display_name: str, optional
            - name of the note log
        description: str, optional
            - text of the note log
        body: dict, optional
            - details of the update - supersedes the other parameters.
        merge_update: bool, optional
            - whether to merge the new attributes with the existing note log attributes.

        Returns
        -------
        Void

        Raises
        ------
        PyegeriaExecption

        Notes:
        ______
        Sample body:

        {
          "class" : "UpdateElementRequestBody",
          "mergeUpdate": true,
          "properties" : {
            "class" : "NoteLogProperties",
            "qualifiedName" : "Add unique name here",
            "displayName" : "Add name here",
            "description" : "Add description here",
            "additionalProperties" : {
              "propertyName 1" : "property value 1",
              "propertyName 2" : "property value 2"
            }
          }
        }

        Args:
            display_name ():
            description ():

        """
        if body is None:
            body = {
                "class": "UpdateElementRequestBody",
                "mergeUpdate": merge_update,
                "properties": {
                    "class": "NoteLogProperties",
                    "description": description,
                    "displayName": display_name
                }
            }
        elif body is None and display_name is None:
            context = {"issue": "Invalid display name and body not provided"}
            raise PyegeriaInvalidParameterException(context=context)

        url = f"{self.command_root}feedback-manager/note-logs/note-logs/{note_log_guid}"
        await self._async_make_request("POST", url, body_slimmer(body))

    @dynamic_catch
    def update_note_log(
            self,
            note_log_guid: str,
            display_name: Optional[str] = None,
            description: Optional[str] = None,
            body: dict = None,
            merge_update: bool = True,
    ) -> None:
        """
        Update an existing note log.

        Parameters
        ----------
        note_log_guid
            - a unique identifier for the note log to change.
        display_name: str, optional
            - name of the note log
        description: str, optional
            - text of the note log
        body: dict, optional
            - details of the update - supersedes the other parameters.
        merge_update: bool, optional
            - whether to merge the new attributes with the existing note log attributes.
        Returns
        -------
        Void

        Raises
        ------
        PyegeriaExecption

        Notes:
        ______
        Sample body:

        {
          "class" : "UpdateElementRequestBody",
          "mergeUpdate": true,
          "properties" : {
            "class" : "NoteLogProperties",
            "qualifiedName" : "Add unique name here",
            "displayName" : "Add name here",
            "description" : "Add description here",
            "additionalProperties" : {
              "propertyName 1" : "property value 1",
              "propertyName 2" : "property value 2"
            }
          }
        }

        Args:
            display_name ():
            description ():

        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self.update_note_log(note_log_guid, display_name, description, body, merge_update)
        )
        return response

    @dynamic_catch
    async def _async_remove_note_log(
            self,
            note_log_guid: str,
            body: Optional[dict | DeleteElementRequestBody] = None,
            cascade_delete: bool = False,
    ) -> None:
        """
        Removes a Note Log from the repository. All the relationships to referenceables are lost. Async Version..

        Parameters
        ----------
        note_log_guid: str
            - String - unique id for the note log.
        body: dict | DeleteElementRequestBody, optional
            - containing type of comment enum and the text of the comment.
        cascade_delete: bool, optional
            - If True, deletes all comments and replies associated with the note log.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        """

        url = f"{self.command_root}feedback-manager/note-logs/{note_log_guid}/remove"
        await self._async_delete_element_request(url, body, cascade_delete)

    @dynamic_catch
    def remove_note_log(
            self,
            note_log_guid: str,
            body: Optional[dict | DeleteElementRequestBody] = None,
            cascade_delete: bool = False,

    ) -> None:
        """
        Remove a note log from the repository. All relationships to referenceables are lost.

        Parameters
        ----------
        note_log_guid: str
            - unique id for the note log
        body: dict | DeleteElementRequestBody, optional
            - request body details (if provided, supersedes other parameters)
        cascade_delete: bool, default = False
            - if True, deletes all comments and replies associated with the note log

        Returns
        -------
        None

        Raises
        ------
        PyEgeriaException
        """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_remove_note_log(note_log_guid, body, cascade_delete)
        )

    @dynamic_catch
    async def _async_find_note_logs(
            self,
            search_string: str,
            classification_names: Optional[list[str]] = None,
            metadata_element_subtypes: list[str] = ["NoteLog"],
            starts_with: Optional[bool] = None,
            ends_with: Optional[bool] = None,
            ignore_case: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            **kwargs
    ) -> dict | str:

        """
        Return the list of note logs containing the supplied string. Async Version.

        Parameters
        ----------
        search_string : str
            Search string to find in note logs.
        classification_names : list[str], optional
            List of classification names to filter by.
        metadata_element_subtypes : list[str], default ["NoteLog"]
            List of metadata element subtypes to search.
        starts_with : bool, optional
            Does the value start with the supplied string?
        ends_with : bool, optional
            Does the value end with the supplied string?
        ignore_case : bool, optional
            Should the search ignore case?
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default max_paging_size
            Maximum number of elements to return.
        output_format : str, default "JSON"
            Output format for the response.
        report_spec : str | dict, optional
            Output format set for the response.
        body : dict | SearchStringRequestBody, optional
            Body of the request. Details of the body override other parameters if present.
        **kwargs : dict, optional
            Additional parameters supported by the underlying find request:
            
            - anchor_domain : str - Domain to anchor the search
            - metadata_element_type : str - Specific metadata element type
            - skip_relationships : list[str] - Relationship types to skip
            - include_only_relationships : list[str] - Only include these relationship types
            - skip_classified_elements : list[str] - Skip elements with these classifications
            - include_only_classified_elements : list[str] - Only include elements with these classifications
            - graph_query_depth : int - Depth of graph traversal (default 3)
            - governance_zone_filter : list[str] - Filter by governance zones
            - as_of_time : str - Historical query time
            - effective_time : str - Effective time for the query
            - relationship_page_size : int - Page size for relationships
            - limit_results_by_status : list[str] - Filter by element status
            - sequencing_order : str - Order of results
            - sequencing_property : str - Property to sequence by
            - property_names : list[str] - Specific properties to search

        Returns
        -------
        dict | str
            List of note log objects in the requested format.

        Raises
        ------
        PyegeriaException
            If there are issues in communications, message format, or Egeria errors.

        Notes
        -----
        The **kwargs parameter allows advanced users to access all parameters supported by the
        underlying _async_find_request helper method. Common parameters are explicitly listed
        in the signature for discoverability, while advanced parameters can be passed via kwargs.

        Sample body structure:
        {
          "class" : "SearchStringRequestBody",
          "searchString" : "Add value here",
          "startsWith" : false,
          "endsWith" : false,
          "ignoreCase" : true,
          "startFrom" : 0,
          "pageSize": 10,
          "asOfTime" : "{{$isoTimestamp}}",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false,
          "limitResultsByStatus" : ["ACTIVE"],
          "sequencingOrder" : "PROPERTY_ASCENDING",
          "sequencingProperty" : "qualifiedName"
        }

        Examples
        --------
        Basic usage:
            >>> note_logs = await client._async_find_note_logs("project", starts_with=True)
        
        Advanced usage with kwargs:
            >>> note_logs = await client._async_find_note_logs(
            ...     "project",
            ...     starts_with=True,
            ...     graph_query_depth=5,
            ...     limit_results_by_status=["ACTIVE"]
            ... )
        """

        url = f"{self.command_root}feedback-manager/note-logs/by-search-string"
        
        # Build params dict with explicit parameters
        params = {
            'search_string': search_string,
            'metadata_element_subtypes': metadata_element_subtypes,
            'include_only_classified_elements': classification_names,
            'starts_with': starts_with,
            'ends_with': ends_with,
            'ignore_case': ignore_case,
            'start_from': start_from,
            'page_size': page_size,
            'output_format': output_format,
            'report_spec': report_spec,
            'body': body
        }
        # Merge with any additional kwargs, removing None values
        params.update(kwargs)
        # Filter out None values, but keep search_string even if None (it's required)
        params = {k: v for k, v in params.items() if v is not None or k == 'search_string'}
        
        response = await self._async_find_request(url, _type="NoteLog", _gen_output=self._generate_feedback_output,
                                                  **params)

        return response

    @dynamic_catch
    def find_note_logs(
            self,
            search_string: str,
            classification_names: Optional[list[str]] = None, metadata_element_subtypes: list[str] = ["NoteLog"],
            starts_with: bool = True,
            ends_with: bool = False,
            ignore_case: bool = False,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "JSON", report_spec: Optional[str | dict] = None,
            body: Optional[dict | SearchStringRequestBody] = None
    ) -> dict | str:
        """
        Return the list of comments containing the supplied string. Async Version.

        Parameters
        ----------
        search_string
            - search string and effective time.

        starts_with
            - does the value start with the supplied string?
        ends_with
            - does the value end with the supplied string?
        ignore_case
            - should the search ignore case?
        start_from
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.
        output_format
            - output format for the response
        report_spec
            - output format set for the response
        body
            - body of the request. Details of the body overrides other parameters if present.

        Returns
        -------
        list of comment objects

        Raises
        ------
        PyegeriaException

        Args:
            classification_names ():
            metadata_element_subtypes ():


        """
        loop = asyncio.get_event_loop()
        resp = loop.run_until_complete(
            self._async_find_note_logs(search_string, classification_names, metadata_element_subtypes, starts_with,
                                       ends_with, ignore_case, start_from, page_size, output_format, report_spec, body)
        )

        return resp

    @dynamic_catch
    async def _async_get_note_logs_by_name(
            self, filter_string: str,
            element_type: str = "NoteLog",
            body: Optional[dict | FilterRequestBody] = None,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None,
            start_from: int = 0, page_size: int = 0
    ) -> dict | str:
        """
        Retrieve the list of note log metadata elements with an exact matching qualifiedName or name. Asymc Version.

        Parameters
        ----------
        filter_string : str
            - the name to filter on.
        element_type: str
            - NoteLog element type.
        body: dict | FilterRequestBody
            - optional effective time. If present, values supercede other parameters.

        Returns
        -------
        Note logproperties

        Raises
        ------
        PyegeriaException

        """

        url = f"{self.command_root}feedback-manager/note-logs/by-name"
        response = await self._async_get_name_request(url, _type=element_type,
                                                      _gen_output=self._generate_feedback_output, start_from=0,
                                                      page_size=0, output_format="JSON", report_spec=report_spec,
                                                      body=body, filter_string=filter_string)

        return response

    @dynamic_catch
    def get_note_logs_by_name(
            self, filter_string: str,
            element_type: str = "NoteLog",
            body: Optional[dict | FilterRequestBody] = None,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None,
            start_from: int = 0, page_size: int = 0
    ) -> dict | str:
        """
        Retrieve the list of note log metadata elements with an exact matching qualifiedName or name.

        Parameters
        ----------
        filter_string : str
            - the name to filter on.
        element_type: str
            - NoteLog element type.
        body: dict | FilterRequestBody
            - optional effective time. If present, values supercede other parameters.

        Returns
        -------
        Note logproperties

        Raises
        ------
        PyegeriaException

        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_note_logs_by_name(filter, element_type, body, output_format, report_spec, start_from,
                                             page_size)
        )
        return response

    @dynamic_catch
    async def _async_get_attached_note_logs(
            self,
            element_guid: str,
            element_type: str = "NoteLog",
            body: dict = None,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None

    ) -> dict | str:
        """
        Return the note logs attached to an element. Async version.

        Parameters
        ----------
        element_guid
            - a unique identifier for the element that the note logs are connected to (maybe a comment too).
        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.


        Returns
        -------
        list of comments

        Raises
        ------
        PyegeriaException

        """

        url = f"{self.command_root}feedback-manager/elements/{element_guid}/note-logs/retrieve"
        response = await self._async_make_request("POST", url, body)
        element = response.json().get("elements", NO_ELEMENTS_FOUND)
        if element == NO_ELEMENTS_FOUND:
            return NO_ELEMENTS_FOUND
        if output_format.upper() != 'JSON':  # return a simplified markdown representation
            return self._generate_feedback_output(element, None, output_format, report_spec)
        return response.json().get("elements", NO_ELEMENTS_FOUND)

    @dynamic_catch
    def get_attached_note_logs(
            self, element_guid: str,
            element_type: Optional[str] = None,
            body: dict = None,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "JSON",
            report_spec: Optional[str | dict] = None
    ) -> dict | str:
        """
        Return the Note Logs attached to an element.

        Parameters
        ----------
        element_guid
            - a unique identifier for the element that the note logs are connected to (maybe a comment too).
        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.

        Returns
        -------
        list of comments

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.

        Args:
            element_type ():
            output_format ():
            report_spec ():
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_attached_comments(element_guid, element_type, body, start_from, page_size, output_format,
                                              report_spec)
        )
        return response

    @dynamic_catch
    async def _async_create_note(self, note_log_guid: str, display_name: Optional[str] = None, description: Optional[str] = None,
                                 associated_element: Optional[str] = None, body: Optional[dict | NewElementRequestBody] = None) -> str:
        """
        Creates a new note for a note log and returns the unique identifier for it. Async version.

        Parameters
        ----------
        note_log_guid
            - unique identifier of the note log
        display_name
            - optional display name for the note
        description
            - optional description for the note
        associated_element: str, default is None
            - guid of the element to associate with the note - if provided, the note will be anchored to this element.
        body
            - optional body for the note

        Returns
        -------
        Guid for the note

        Raises
        ------
        PyegeriaException

        Notes
        _____

        Sample body (a note is an asset)
        {
          "class" : "NewElementRequestBody",
          "anchorGUID" : "{{noteLogGUID}}",
          "isOwnAnchor": false,
          "parentGUID": "{{noteLogGUID}}",
          "parentRelationshipTypeName": "AttachedNoteLogEntry",
          "parentAtEnd1": true,
          "properties": {
            "class" : "NotificationProperties",
            "typeName" : "Notification",
            "qualifiedName": "add unique name here",
            "displayName": "add short name here",
            "description": "add description here",
            "systemAction" : "add optional system action that occurred as part of this notification processing",
            "userResponse" : "add optional action that the reader should take",
            "priority" : 1,
            "activityStatus" : "FOR_INFO",
            "additionalProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "extendedProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "effectiveFrom": "{{$isoTimestamp}}",
            "effectiveTo": "{{$isoTimestamp}}"
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }

        """

        if body is None and display_name:
            body = {
                "class": "NewElementRequestBody",
                "anchorGUID": associated_element if associated_element else note_log_guid,
                "isOwnAnchor": False,
                "parentGUID": note_log_guid,
                "parentRelationshipTypeName": "AttachedNoteLogEntry",
                "parentAtEnd1": True,
                "properties": {
                    "class": "NotificationProperties",
                    "typeName": "Notification",
                    "qualifiedName": self.make_feedback_qn("Note", note_log_guid, display_name),
                    "displayName": display_name,
                    "description": description,
                },
                "forLineage": False,
                "forDuplicateProcessing": False
            }

        elif body is None and display_name is None:
            context = {"issue": "Invalid display name and body not provided"}
            raise PyegeriaInvalidParameterException(context=context)

        url = f"{self.command_root}feedback-manager/assets"
        response = await self._async_create_element_body_request(url, ['Notification'], body)
        return response

    @dynamic_catch
    def create_note(
            self, note_log_guid:
            str, display_name: Optional[str] = None, description: Optional[str] = None,
            body: Optional[dict | NewElementRequestBody] = None) -> str:
        """
        Creates a new note for a note log and returns the unique identifier for it.
    
        Parameters
        ----------
        note_log_guid
            - unique identifier of the note log
        display_name
            - optional display name for the note
        description
            - optional description for the note
        body
            - optional body for the note
    
        Returns
        -------
        Guid for the note
    
        Raises
        ------
        PyegeriaException
    
        Notes
        _____
    
        Sample body (a note is an asset)
        {
          "class" : "NewElementRequestBody",
          "anchorGUID" : "{{noteLogGUID}}",
          "isOwnAnchor": false,
          "parentGUID": "{{noteLogGUID}}",
          "parentRelationshipTypeName": "AttachedNoteLogEntry",
          "parentAtEnd1": true,
          "properties": {
            "class" : "NotificationProperties",
            "typeName" : "Notification",
            "qualifiedName": "add unique name here",
            "displayName": "add short name here",
            "description": "add description here",
            "systemAction" : "add optional system action that occurred as part of this notification processing",
            "userResponse" : "add optional action that the reader should take",
            "priority" : 1,
            "activityStatus" : "FOR_INFO",
            "additionalProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "extendedProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "effectiveFrom": "{{$isoTimestamp}}",
            "effectiveTo": "{{$isoTimestamp}}"
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }
    
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_create_note(note_log_guid, display_name, body)
        )
        return response

    @dynamic_catch
    async def _async_add_journal_entry(self, note_log_qn: Optional[str] = None, element_qn: str =  None,
                                       note_log_display_name: Optional[str] = None, journal_entry_display_name: Optional[str] = None,
                                       note_entry: Optional[str] = None,
                                       body: Optional[dict | NewElementRequestBody] = None) -> str:
        """
        Creates a new journal entry for a note log and returns the unique identifier for it. The note_log will be
        created if it does not exist. Async version.

        Parameters
        ----------
        note_log_qn: str = None
            - If provided, the journal entry will be attached to this note log. If not provided, a new note_log will be created.
        element_qn: str = None
            - If provided, and note log needs to be created, this will be used to define the new note log and attach it
             to the specified element.
        note_log_display_name: str = None
            - optional note log display name
        journal_entry_display_name: str = None
            - optional journal entry display name
        note_entry: str = None
            - the journal entry text

        body
            - optional body for the note - if provided, details here will supercede other parameters.

        Returns
        -------
        GUID for the journal entry (note).

        Raises
        ------
        PyegeriaException

        Notes
        _____

        Sample body (a note is an asset)
        {
          "class" : "NewElementRequestBody",
          "anchorGUID" : "{{noteLogGUID}}",
          "isOwnAnchor": false,
          "parentGUID": "{{noteLogGUID}}",
          "parentRelationshipTypeName": "AttachedNoteLogEntry",
          "parentAtEnd1": true,
          "properties": {
            "class" : "NotificationProperties",
            "typeName" : "Notification",
            "qualifiedName": "add unique name here",
            "displayName": "add short name here",
            "description": "add description here",
            "systemAction" : "add optional system action that occurred as part of this notification processing",
            "userResponse" : "add optional action that the reader should take",
            "priority" : 1,
            "activityStatus" : "FOR_INFO",
            "additionalProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "extendedProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "effectiveFrom": "{{$isoTimestamp}}",
            "effectiveTo": "{{$isoTimestamp}}"
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }

        """
        note_log_guid = None
        element_guid = None
        # If a note_log_qn has been provided, look up its GUID
        if note_log_qn:
            note_log_guid = await self._async_get_guid_for_name(note_log_qn, ["qualifiedName"],'NoteLog' ) if note_log_qn else None

        # If we need to create a new note_log, then use the qualified name from the element_qn parameter, if provided.
        if note_log_guid is None or note_log_guid == NO_ELEMENTS_FOUND:
            if element_qn is None:
                if note_log_display_name is None:
                    note_log_display_name = f"NoteLog-{datetime.now().strftime('%Y-%m-%d %H:%M')}"

            else:
                element_guid = await self._async_get_guid_for_name(element_qn, ["qualifiedName"])
                if element_guid is None or element_guid == NO_ELEMENTS_FOUND:
                    context = { "reason" : "The specified associated element was not found"}
                    raise PyegeriaException(error_code = PyegeriaErrorCode.VALIDATION_ERROR, context = context)

            note_log = await self._async_create_note_log(element_guid = element_guid, display_name = note_log_display_name)
            note_log_guid = note_log["guid"]

        # Create the Journal Entry (Note)
        if journal_entry_display_name is None:
            journal_entry_display_name = f"Note-{datetime.now().strftime('%Y-%m-%d %H:%M')}"
        journal_entry_guid = await self._async_create_note(note_log_guid, journal_entry_display_name,
                                                           note_entry, body)

        return journal_entry_guid

    @dynamic_catch
    def add_journal_entry(self, note_log_qn: Optional[str] = None, element_qn: Optional[str] = None,
                           note_log_display_name: Optional[str] = None, journal_entry_display_name: Optional[str] = None,
                          note_entry: Optional[str] = None,
                           body: Optional[dict | NewElementRequestBody] = None) -> str:
        """
        Creates a new journal entry for a note log and returns the unique identifier for it. The note_log will be
        created if it does not exist.

        Parameters
        ----------
        note_log_qn: str = None
            - If provided, the journal entry will be attached to this note log. If not provided, a new note_log will be created.
        element_qn: str = None
            - If provided, and note log needs to be created, this will be used to define the new note log and attach it
             to the specified element.
        note_log_display_name: str = None
            - optional note log display name
        journal_entry_display_name: str = None
            - optional journal entry display name
        note_entry: str = None
            - the journal entry text

        body
            - optional body for the note - if provided, details here will supercede other parameters.

        Returns
        -------
        GUID for the journal entry (note).

        Raises
        ------
        PyegeriaException

        Notes
        _____

        Sample body (a note is an asset)
        {
          "class" : "NewElementRequestBody",
          "anchorGUID" : "{{noteLogGUID}}",
          "isOwnAnchor": false,
          "parentGUID": "{{noteLogGUID}}",
          "parentRelationshipTypeName": "AttachedNoteLogEntry",
          "parentAtEnd1": true,
          "properties": {
            "class" : "NotificationProperties",
            "typeName" : "Notification",
            "qualifiedName": "add unique name here",
            "displayName": "add short name here",
            "description": "add description here",
            "systemAction" : "add optional system action that occurred as part of this notification processing",
            "userResponse" : "add optional action that the reader should take",
            "priority" : 1,
            "activityStatus" : "FOR_INFO",
            "additionalProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "extendedProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "effectiveFrom": "{{$isoTimestamp}}",
            "effectiveTo": "{{$isoTimestamp}}"
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }

        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_add_journal_entry(note_log_qn, element_qn, note_log_display_name, journal_entry_display_name, note_entry, body)
        )
        return response


    @dynamic_catch
    async def _async_update_note(self, note_guid: str, display_name: Optional[str] = None, description: Optional[str] = None,
                                 body: Optional[dict | UpdateElementRequestBody] = None, merge_update: bool = True) -> None:
        """
        Update a note for a note log and returns the unique identifier for it. Async Version.

        Parameters
        ----------
        note_guid
            - unique identifier of the note log
        display_name
            - optional display name for the note
        description
            - optional description for the note
        body
            - optional body for the note. If provided, supercedes other parameters.
        merge_update
            - optional flag to merge the update with existing properties. Default is True.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        Notes
        _____

        Sample body (a note is an asset)
        {
          "class" : "UpdateElementRequestBody",
          "mergeUpdate": true,
          "properties": {
            "class" : "NotificationProperties",
            "typeName" : "Notification",
            "qualifiedName": "add unique name here",
            "displayName": "add short name here",
            "description": "add description here",
            "systemAction" : "add optional system action that occurred as part of this notification processing",
            "userResponse" : "add optional action that the reader should take",
            "priority" : 1,
            "activityStatus" : "FOR_INFO",
            "additionalProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "extendedProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            }
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }

        Args:
            merge_update ():

        """
        if body is None and display_name:
            body = {
                "class": "UpdateElementRequestBody",
                "mergeUpdate": merge_update,
                "properties": {
                    "class": "NotificationProperties",
                    "displayName": display_name,
                    "description": description,
                }
            }

        elif body is None and display_name is None:
            context = {"issue": "Invalid display name and body not provided"}
            raise PyegeriaInvalidParameterException(context=context)

        url = f"{self.command_root}feedback-manager/notes/{note_guid}"
        await self._async_update_element_body_request(url, ['Notification'], body)

    @dynamic_catch
    def update_note(
            self, note_guid: str, display_name: Optional[str] = None, description: Optional[str] = None,
            body: Optional[dict | UpdateElementRequestBody] = None, merge_update: bool = True) -> None:
        """
        Update a note for a note log and returns the unique identifier for it. Async Version.

        Parameters
        ----------
        note_guid
            - unique identifier of the note log
        display_name
            - optional display name for the note
        description
            - optional description for the note
        body
            - optional body for the note. If provided, supercedes other parameters.
        merge_update
            - optional flag to merge the update with existing properties. Default is True.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        Notes
        _____

        Sample body (a note is an asset)
        {
          "class" : "UpdateElementRequestBody",
          "mergeUpdate": true,
          "properties": {
            "class" : "NotificationProperties",
            "typeName" : "Notification",
            "qualifiedName": "add unique name here",
            "displayName": "add short name here",
            "description": "add description here",
            "systemAction" : "add optional system action that occurred as part of this notification processing",
            "userResponse" : "add optional action that the reader should take",
            "priority" : 1,
            "activityStatus" : "FOR_INFO",
            "additionalProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            },
            "extendedProperties": {
              "property1" : "propertyValue1",
              "property2" : "propertyValue2"
            }
          },
          "externalSourceGUID": "add guid here",
          "externalSourceName": "add qualified name here",
          "effectiveTime" : "{{$isoTimestamp}}",
          "forLineage" : false,
          "forDuplicateProcessing" : false
        }

        Args:
            merge_update ():

        """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_update_note(note_guid, display_name, description, body, merge_update)
        )

    @dynamic_catch
    async def _async_remove_note(
            self,
            note_guid: str,
            body: Optional[dict | DeleteElementRequestBody] = None,

    ) -> None:
        """
        Removes a note from the repository.

        All the relationships to referenceables are lost.

        Parameters
        ----------

        note_guid
            - unique id for the note.

        body: dict | DeleteElementRequestBody
           - optional body for the note deletion.

        Returns
        -------
        VoidResponse

        Raises
        ------
        PyegeriaException
        """
        url = f"{self.command_root}feedback-manager/assets/{note_guid}/delete"
        await self._async_delete_element_request(url, body)

    @dynamic_catch
    def remove_note(
            self,
            note_guid: str,
            body: dict = None,
    ) -> None:
        """
        Removes a note from the repository.

        All the relationships to referenceables are lost.

        Parameters
        ----------
        note_guid
            - unique id for the note .

        body: dict | DeleteElementRequestBody
           - optional body for the note deletion.

        Returns
        -------
        VoidResponse

        Raises
        ------
        PyegeriaException
        """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_remove_note(
                note_guid,
                body
            )
        )

    @dynamic_catch
    async def _async_find_notes(
            self, search_string: str = "*",
            starts_with: bool = True, ends_with: bool = False,
            ignore_case: bool = False,
            anchor_domain: Optional[str] = None,
            metadata_element_type: Optional[str] = None,
            metadata_element_subtypes: Optional[list[str]] = None,
            skip_relationships: Optional[list[str]] = None,
            include_only_relationships: Optional[list[str]] = None,
            skip_classified_elements: Optional[list[str]] = None,
            include_only_classified_elements: Optional[list[str]] = None,
            graph_query_depth: int = 3,
            governance_zone_filter: Optional[list[str]] = None, as_of_time: Optional[str] = None,
            effective_time: Optional[str] = None, relationship_page_size: int = 0,
            limit_results_by_status: Optional[list[str]] = None,
            sequencing_order: Optional[str] = None,
            sequencing_property: Optional[str] = None,
            output_format: str = "JSON",
            report_spec: str | dict = None,
            start_from: int = 0, page_size: int = 100,
            property_names: Optional[list[str]] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            **kwargs
    ) -> dict | str:
        """
        Retrieve the list of note metadata elements that contain the search string. Async version.

        Parameters
        ----------
        search_string : str, default "*"
            Search string to find in notes. If "*", all elements are returned.
        starts_with : bool, default True
            Does the value start with the supplied string?
        ends_with : bool, default False
            Does the value end with the supplied string?
        ignore_case : bool, default False
            Should the search ignore case?
        anchor_domain : str, optional
            Domain to anchor the search.
        metadata_element_type : str, optional
            Specific metadata element type to search.
        metadata_element_subtypes : list[str], optional
            List of metadata element subtypes to search.
        skip_relationships : list[str], optional
            Relationship types to skip in the query.
        include_only_relationships : list[str], optional
            Only include these relationship types.
        skip_classified_elements : list[str], optional
            Skip elements with these classifications.
        include_only_classified_elements : list[str], optional
            Only include elements with these classifications.
        graph_query_depth : int, default 3
            Depth of graph traversal for related elements.
        governance_zone_filter : list[str], optional
            Filter results by governance zones.
        as_of_time : str, optional
            Historical query time (ISO 8601 format).
        effective_time : str, optional
            Effective time for the query (ISO 8601 format).
        relationship_page_size : int, default 0
            Page size for relationship queries.
        limit_results_by_status : list[str], optional
            Filter by element status (e.g., ["ACTIVE"]).
        sequencing_order : str, optional
            Order of results (e.g., "PROPERTY_ASCENDING").
        sequencing_property : str, optional
            Property to sequence results by.
        output_format : str, default "JSON"
            Format of the returned output (JSON, MD, MERMAID, REPORT, LIST, etc.).
        report_spec : str | dict, optional
            Report specification for the returned output.
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default 100
            Maximum number of elements to return.
        property_names : list[str], optional
            Specific properties to search within.
        body : dict | SearchStringRequestBody, optional
            Request body that overrides other parameters if present.
        **kwargs : dict, optional
            Additional parameters supported by the underlying find request.
            Since this method already exposes most parameters, kwargs is provided
            for future extensibility.

        Returns
        -------
        dict | str
            List of matching note metadata elements in the requested format.

        Raises
        ------
        PyegeriaException
            If there are issues in communications, message format, or Egeria errors.

        Notes
        -----
        This method exposes most of the advanced parameters directly in its signature,
        making them easily discoverable. The **kwargs parameter is included for future
        extensibility and to maintain consistency with other find methods.

        Examples
        --------
        Basic usage:
            >>> notes = await client._async_find_notes("meeting", starts_with=True)
        
        Advanced usage with graph traversal:
            >>> notes = await client._async_find_notes(
            ...     "project",
            ...     graph_query_depth=5,
            ...     governance_zone_filter=["internal"],
            ...     limit_results_by_status=["ACTIVE"]
            ... )
        """

        url = f"{self.command_root}feedback-manager/assets/by-search-string"
        
        # Build params dict with explicit parameters
        params = {
            'search_string': search_string,
            'starts_with': starts_with,
            'ends_with': ends_with,
            'ignore_case': ignore_case,
            'anchor_domain': anchor_domain,
            'metadata_element_type': metadata_element_type,
            'metadata_element_subtypes': metadata_element_subtypes,
            'skip_relationships': skip_relationships,
            'include_only_relationships': include_only_relationships,
            'skip_classified_elements': skip_classified_elements,
            'include_only_classified_elements': include_only_classified_elements,
            'graph_query_depth': graph_query_depth,
            'governance_zone_filter': governance_zone_filter,
            'as_of_time': as_of_time,
            'effective_time': effective_time,
            'relationship_page_size': relationship_page_size,
            'limit_results_by_status': limit_results_by_status,
            'sequencing_order': sequencing_order,
            'sequencing_property': sequencing_property,
            'output_format': output_format,
            'report_spec': report_spec,
            'start_from': start_from,
            'page_size': page_size,
            'property_names': property_names,
            'body': body
        }
        # Merge with any additional kwargs, removing None values
        params.update(kwargs)
        # Filter out None values, but keep search_string even if None (it's required)
        params = {k: v for k, v in params.items() if v is not None or k == 'search_string'}
        
        response = await self._async_find_request(url, _type="NoteLog", _gen_output=self._generate_feedback_output,
                                                  **params)
        return response

    @dynamic_catch
    def find_notes(
            self, search_string: Optional[str] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            starts_with: bool = True,
            ends_with: bool = False,
            ignore_case: bool = False,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "JSON",
            report_spec: str = None
    ) -> dict | str:
        """
        Retrieve the list of note metadata elements that contain the search string.

        Parameters
        ----------
        search_string: str, optional = None
            - optional search string to search for. If none, all elements are returned.
        body
            - search string and effective time.

        starts_with
            - Does the value start with the supplied string?
        ends_with
            - Does the value end with the supplied string?
        ignore_case
            - Should the search ignore case?
        start_from
            - Index of the list to start from (0 for start).
        page_size
            -Maximum number of elements to return.

        Returns
        -------
        list of matching metadata elements

        Raises
        ------
        PyegeriaException

        Args:
            output_format ():
            report_spec ():


        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_find_notes(search_string, starts_with, ends_with, ignore_case, output_format=output_format,
                                   report_spec=report_spec, start_from=start_from, page_size=page_size, body=body)
        )
        return response

    @dynamic_catch
    async def _async_get_note_by_guid(
            self,
            note_guid: str,
            body: Optional[dict | GetRequestBody] = None,
            output_format: str = "JSON",
            report_spec: Optional[str] = None,
    ) -> dict | str:
        """
        Retrieve the note metadata element with the supplied unique identifier.

        Parameters
        ----------
        note_guid
             - unique identifier of the requested metadata element
        body: dict | GetRequestBody
            - optional details of the request.
        O=output_format: str, default = "JSON"
            - output type - JSON, MD, MERMAID, REPORT, LIST...
        report_spec: str, optional = None
            - Report specification for the returned output
         Returns
         -------
         matching metadata element

         Raises
         ------
         PyegeriaException
        """

        url = f"{self.command_root}feedback-manager/assets/{note_guid}/retrieve"
        response = await self._async_get_guid_request(url, "Notification", self._generate_feedback_output,
                                                      output_format, report_spec, body)
        return response

    @dynamic_catch
    def get_note_by_guid(
            self,
            note_guid: str,
            body: Optional[dict | GetRequestBody] = None,
            output_format: str = "JSON",
            report_spec: Optional[str] = None,
    ) -> dict | str:
        """
        Retrieve the note metadata element with the supplied unique identifier.

        Parameters
        ----------
        note_guid
             - unique identifier of the requested metadata element
        body: dict | GetRequestBody
            - optional details of the request.
        output_format: str, default = "JSON"
            - output type - JSON, MD, MERMAID, REPORT, LIST...
        report_spec: str, optional = None
            - Report specification for the returned output
         Returns
         -------
         matching metadata element

         Raises
         ------
         PyegeriaException
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_note_by_guid(note_guid, body, output_format, report_spec)
        )
        return response

    @dynamic_catch
    async def _async_get_notes_for_note_log(
            self,
            note_log_guid: str,
            body: Optional[dict | ResultsRequestBody] = None,
            start_from: int = 0, page_size: int = 0,
            output_format: str = "JSON",
            report_spec: Optional[str] = None,
    ) -> dict | str:
        """
        Retrieve the notes for the note_name.

        Parameters
        ----------
        note_log_guid
             - id of the note log to retrieve notes for.
        body: dict | ResultsRequestBody
            - optional details of the request.
        O=output_format: str, default = "JSON"
            - output type - JSON, MD, MERMAID, REPORT, LIST...
        report_spec: str, optional = None
            - Report specification for the returned output
         Returns
         -------
         matching metadata element

         Raises
         ------
         PyegeriaException

        """

        url = f"{self.command_root}feedback-manager/note-logs/{note_log_guid}/retrieve"
        response = await self._async_get_results_body_request(url, "Notification", self._generate_feedback_output,
                                                              0, 0, output_format, report_spec, body)
        return response

    @dynamic_catch
    def get_notes_for_note_log(
            self,
            note_log_guid: str,
            body: Optional[dict | ResultsRequestBody] = None,
            start_from: int = 0, page_size: int = 0,
            output_format: str = "JSON",
            report_spec: Optional[str] = None,
    ) -> dict | str:
        """
         Retrieve the notes for the note_name.

         Parameters
         ----------
         note_log_guid
              - note_log id to find notes for.
         body: dict | ResultsRequestBody
             - optional details of the request.
         O=output_format: str, default = "JSON"
             - output type - JSON, MD, MERMAID, REPORT, LIST...
         report_spec: str, optional = None
             - Report specification for the returned output
          Returns
          -------
          matching metadata element

          Raises
          ------
          PyegeriaException

         """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_notes_for_note_log(note_log_guid, body, start_from, page_size,
                                               output_format, report_spec)
        )
        return response

    #
    # Tags
    #
    @dynamic_catch
    async def _async_create_informal_tag(
            self,
            display_name: str = None,
            description: str = None,
            qualified_name: str = None,
            body: dict = None,
    ) -> str:
        """
        Creates a new informal tag and returns the unique identifier for it. Async Version.

        Parameters
        ----------

        display_name: str
            - The name of the informal tag.
        description: str
            - The description of the informal tag.
        qualified_name: str, optional
            - The qualified name of the informal tag. If not provided, it will be generated.
        body: dict, optional
            - Body of the request. Overrides other parameters if present.

        Returns
        -------
        new element_guid

        Raises
        ------
        PyegeriaException
        """
        url = f"{self.command_root}feedback-manager/tags"
       

        if body is None:
            if display_name is None:
                raise PyegeriaInvalidParameterException(context={"reason": "display_name is required"})
            if qualified_name is None:
                qualified_name = self.make_feedback_qn("InformalTag", None, display_name)
            body = {
                "class": "NewElementRequestBody",
                "properties": {
                    "class": "InformalTagProperties",
                    "name": display_name,
                    "displayName": display_name,
                    "qualifiedName" : qualified_name,
                    "description": description
                }
            }
        response = await self._async_create_element_body_request(url, ["InformalTagProperties"], body)
        return response

    @dynamic_catch
    def create_informal_tag(
            self,
            display_name: str = None,
            description: str = None,
            qualified_name: str = None,
            body: dict = None,
    ) -> str:
        """
        Creates a new informal tag and returns the unique identifier for it.

        Parameters
        ----------

        display_name: str
            - The name of the informal tag.
        description: str
            - The description of the informal tag.
        qualified_name: str, optional
            - The qualified name of the informal tag. If not provided, it will be created automatically.
        body: dict, optional
            - Body of the request. Overrides other parameters if present.

        Returns
        -------
        new element_guid

        Raises
        ------
        PyegeriaException
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_create_informal_tag(display_name, description, qualified_name, body)
        )
        return response

    @dynamic_catch
    async def _async_update_tag_description(
            self,
            tag_guid: str,
            description: str,
            body: Optional[dict | UpdateElementRequestBody] = None,

    ) -> None:
        """
        Updates the description of an existing tag. Async version.

        Parameters
        ----------

        tag_guid
            - unique id for the tag
        description: str
            - description of the tag

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        Args:
            body ():
        """
        body = {
            "class": "UpdateElementRequestBody",
            "mergeUpdate": True,
            "properties": {
                "class": "InformalTagProperties",
                "description": description
            }
        } if body is None else body

        url = f"{self.command_root}feedback-manager/tags/{tag_guid}/update"

        await self._async_make_request("POST", url, body)

    @dynamic_catch
    def update_tag_description(
            self,
            tag_guid: str,
            description: str,
            body: Optional[dict | UpdateElementRequestBody] = None,

    ) -> None:
        """
        Update the description of an existing tag.

        Parameters
        ----------
        tag_guid: str
            - unique id for the tag
        description: str
            - description of the tag

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        Args:
            body ():
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_update_tag_description(tag_guid, description)
        )
        return response

    @dynamic_catch
    async def _async_delete_tag(
            self,
            tag_guid: str

    ) -> None:
        """
        Removes an informal tag from the repository.

        All the tagging relationships to this informal tag are lost. A
        private tag can be deleted by its creator and all the
        references are lost; a public tag can be deleted by anyone,
        but only if it is not attached to any referenceable.

        Parameters
        ----------

        tag_guid
            - String - unique id for the tag.
        Returns
        -------
        None

        Raises
        ------
        PyegeriaException
        """

        url = f"{self.command_root}feedback-manager/tags/{tag_guid}/remove"
        await self._async_make_request("POST", url)

    @dynamic_catch
    def delete_tag(
            self,
            tag_guid: str
    ) -> None:
        """
         Removes an informal tag from the repository.

         All the tagging relationships to this informal tag are lost. A
         private tag can be deleted by its creator and all the
         references are lost; a public tag can be deleted by anyone,
         but only if it is not attached to any referenceable.

         Parameters
         ----------

         tag_guid
             - String - unique id for the tag.
         Returns
         -------
         VOIDResponse

         Raises
         ------
         PyegeriaException
         """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_delete_tag(tag_guid)
        )

    @dynamic_catch
    async def _async_get_tag_by_guid(
            self,
            tag_guid: str,
            body: Optional[dict | GetRequestBody] = None,
            output_format: str = "json",
            report_spec: Optional[str] = None) -> dict | str:
        """
        Return the informal tag for the supplied unique identifier (tag_guid).

        Parameters
        ----------

        tag_guid
            - unique identifier of the meaning.
        body: dict | GetRequestBody, Optional
            - details of the request.
        output_format: str, Optional, default = "JSON"
            - format of the response
        report_spec: str, Optional
            - specification for the report

        Returns
        -------
        list of tag objects

        Raises
        ------
        PyegeriaException

        Args:
            body ():
            output_format ():
            report_spec ():
        """

        url = f"{self.command_root}feedback-manager/tags/{tag_guid}/retrieve"

        response = await self._async_get_guid_request(url, "InformalTag", self._generate_feedback_output,
                                                      output_format, report_spec, body)
        return response

    @dynamic_catch
    def get_tag_by_guid(
            self,
            tag_guid: str,
            body: Optional[dict | GetRequestBody] = None,
            output_format: str = "json",
            report_spec: Optional[str] = None,
    ) -> dict | str:
        """
                Return the informal tag for the supplied unique identifier (tag_guid).

                Parameters
                ----------
                tag_guid
                    - unique identifier of the meaning.
                body: dict | GetRequestBody, Optional
                    - details of the request.
                output_format: str, Optional, default = "JSON"
                    - format of the response
                report_spec: str, Optional
                    - specification for the report

                Returns
                -------
                list of tag objects

                Raises
                ------
                PyegeriaException
            """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_tag_by_guid(tag_guid, body, output_format, report_spec)
        )
        return response

    @dynamic_catch
    async def _async_get_tags_by_name(
            self,
            tag_name: str,
            body: Optional[dict | FilterRequestBody] = None,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "json",
            report_spec: Optional[str] = None,
    ) -> dict | str:
        """
        Return the tags exactly matching the supplied name. Async Version.

        Parameters
        ----------
        tag_name: str
            - name of the informal tag to filter on.
        body
            - name of tag.
        start_from
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.

        Returns
        -------
        list of tag objects

        Raises
        ------
        PyegeriaException
        """

        url = f"{self.command_root}feedback-manager/tags/by-name"

        response = await self._async_get_name_request(url, _type="InformalTag",
                                                      _gen_output=self._generate_feedback_output,
                                                      filter_string=tag_name, start_from=start_from,
                                                      page_size=page_size, output_format=output_format,
                                                      report_spec=report_spec,
                                                      body=body)
        return response

    @dynamic_catch
    def get_tags_by_name(
            self,
            tag_name: str,
            body: Optional[dict | FilterRequestBody] = None,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "json",
            report_spec: Optional[str] = None,
    ) -> dict | str:
        """
        Return the tags exactly matching the supplied name.

        Parameters
        ----------
        tag_name: str
            - name of the informal tag to filter on.
        body
            - name of tag.
        start_from
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.

        Returns
        -------
        list of tag objects

        Raises
        ------
        PyegeriaException
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_tags_by_name(
                tag_name, body,
                start_from,
                page_size,
                output_format,
                report_spec,
            )
        )
        return response

    @dynamic_catch
    async def _async_find_tags(
            self,
            search_string: Optional[str] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            starts_with: bool = True,
            ends_with: bool = False,
            ignore_case: bool = False,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "json",
            report_spec: Optional[str] = None,
            **kwargs
    ) -> dict | str:
        """
        Return the list of informal tags containing the supplied string in their name or description. Async version.

        The search string is located in the request body and is interpreted as a plain string. The request parameters
        startsWith, endsWith and ignoreCase can be used to allow a fuzzy search. The request body also supports the
        specification of an effective time to restrict the search to elements that are/were effective at a particular time.

        Parameters
        ----------
        search_string : str, optional
            String to search for in tag names or descriptions.
        body : dict | SearchStringRequestBody, optional
            Details of the request. If provided, overrides other parameters.
        starts_with : bool, default True
            Does the value start with the supplied string?
        ends_with : bool, default False
            Does the value end with the supplied string?
        ignore_case : bool, default False
            Should the search ignore case?
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default max_paging_size
            Maximum number of elements to return.
        output_format : str, default "json"
            Format of the returned output.
        report_spec : str, optional
            Report specification for the returned output.
        **kwargs : dict, optional
            Additional parameters supported by the underlying find request:
            
            - anchor_domain : str - Domain to anchor the search
            - metadata_element_type : str - Specific metadata element type
            - metadata_element_subtypes : list[str] - List of metadata element subtypes
            - skip_relationships : list[str] - Relationship types to skip
            - include_only_relationships : list[str] - Only include these relationship types
            - skip_classified_elements : list[str] - Skip elements with these classifications
            - include_only_classified_elements : list[str] - Only include elements with these classifications
            - graph_query_depth : int - Depth of graph traversal (default 3)
            - governance_zone_filter : list[str] - Filter by governance zones
            - as_of_time : str - Historical query time
            - effective_time : str - Effective time for the query
            - relationship_page_size : int - Page size for relationships
            - limit_results_by_status : list[str] - Filter by element status
            - sequencing_order : str - Order of results
            - sequencing_property : str - Property to sequence by
            - property_names : list[str] - Specific properties to search

        Returns
        -------
        dict | str
            List of tag objects in the requested format.

        Raises
        ------
        PyegeriaException
            If there are issues in communications, message format, or Egeria errors.

        Notes
        -----
        The **kwargs parameter allows advanced users to access all parameters supported by the
        underlying _async_find_request helper method. Common parameters are explicitly listed
        in the signature for discoverability, while advanced parameters can be passed via kwargs.

        Examples
        --------
        Basic usage:
            >>> tags = await client._async_find_tags("project", starts_with=True)
        
        Advanced usage with kwargs:
            >>> tags = await client._async_find_tags(
            ...     "project",
            ...     starts_with=True,
            ...     governance_zone_filter=["internal"],
            ...     limit_results_by_status=["ACTIVE"]
            ... )
        """

        url = f"{self.command_root}feedback-manager/tags/by-search-string"
        
        # Build params dict with explicit parameters
        params = {
            'search_string': search_string,
            'starts_with': starts_with,
            'ends_with': ends_with,
            'ignore_case': ignore_case,
            'start_from': start_from,
            'page_size': page_size,
            'output_format': output_format,
            'report_spec': report_spec,
            'body': body
        }
        # Merge with any additional kwargs, removing None values
        params.update(kwargs)
        # Filter out None values, but keep search_string even if None (it's required)
        params = {k: v for k, v in params.items() if v is not None or k == 'search_string'}
        
        response = await self._async_find_request(url, _type="InformalTag", _gen_output=self._generate_feedback_output,
                                                  **params)
        return response

    @dynamic_catch
    def find_tags(
            self,
            search_string: Optional[str] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            starts_with: bool = True,
            ends_with: bool = False,
            ignore_case: bool = False,
            start_from: int = 0,
            page_size: int = max_paging_size, output_format: str = "json", report_spec: Optional[str] = None,
    ) -> dict | str:
        """
        Return the list of informal tags containing the supplied string in their name or description. The search string
        is located in the request body and is interpreted as a plain string.  The request parameters,
        startsWith, endsWith and ignoreCase can be used to allow a fuzzy search.  The request body also supports the
        specification of an effective time to restrict the search to element that are/were effective at a particular time.

        Parameters
        ----------
        search_string: str
            - string to search for.
        body: dict | SearchStringRequestBody
            - details of the request.
        starts_with
            - does the value start with the supplied string?
        ends_with
            - does the value end with the supplied string?
        ignore_case
            - should the search ignore case?
        start_from
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.

        Returns
        -------
        list of tag objects

        Raises
        ------
        PyegeriaException

"""
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_find_tags(search_string, body, starts_with, ends_with, ignore_case,
                                  start_from, page_size, output_format, report_spec)
        )
        return response

    async def _async_find_my_tags(
            self,
            search_string: Optional[str] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            starts_with: Optional[bool] = None,
            ends_with: Optional[bool] = None,
            ignore_case: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,

    ) -> dict | str:
        """
        Return the list of the calling user's private tags containing the supplied string in either the name or description.

        Parameters
        ----------
        search_string: str
        - string to search for.
        body: dict | SearchStringRequestBody
        - details of the request. Supersedes other parameters if present.
        starts_with
            - does the value start with the supplied string?
        ends_with
            - does the value end with the supplied string?
        ignore_case
            - should the search ignore case?
        start_from
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.

        Returns
        -------
        list of tag objects

        Raises
        ------
        PyegeriaException
        """

        url = f"{self.command_root}feedback-manager/tags/update"
        response = await self._async_make_request("POST", url, body)
        return response

    def find_my_tags(
            self,
            search_string: Optional[str] = None,
            body: Optional[dict | SearchStringRequestBody] = None,
            starts_with: Optional[bool] = None,
            ends_with: Optional[bool] = None,
            ignore_case: Optional[bool] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,

    ) -> dict | str:
        """
        Return the list of the calling user's private tags containing the supplied string in either the name or description.

        Parameters
        ----------
        search_string: str
        body: dict | SearchStringRequestBody
            - detailed request - supersedes other parameters.
        starts_with
            - does the value start with the supplied string?
        ends_with
            - does the value end with the supplied string?
        ignore_case
            - should the search ignore case?
        start_from
            - index of the list to start from (0 for start).
        page_size
            - maximum number of elements to return.


        Returns
        -------
        list of tag objects

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_find_my_tags(
                search_string,
                body,
                starts_with=starts_with,
                ends_with=ends_with,
                ignore_case=ignore_case,
                start_from=start_from,
                page_size=page_size,

            )
        )
        return response

    @dynamic_catch
    async def _async_add_tag_to_element(
            self,
            element_guid: str,
            tag_guid: str,
            is_public: bool = False,
            body: Optional[dict | NewRelationshipRequestBody] = None,

    ) -> None:
        """
        Adds an informal tag (either private of public) to an element. Async Version.

        Parameters
        ----------

        element_guid
            - unique id for the element.
        tag_guid
            - unique id of the tag.

        body: dict | NewRelationshipRequestBody
            - optional detailed information for the request.

        Returns
        -------
        Void

        Raises
        ------
        PyegeriaException
        """
        is_public_s = str(is_public).lower()

        url = f"{self.command_root}feedback-manager/elements/{element_guid}/tags/{tag_guid}?isPublic={is_public_s}"
        await self._async_new_relationship_request(url, 'InformalTag', body)

    @dynamic_catch
    def add_tag_to_element(
            self,
            element_guid: str,
            tag_guid: str,
            is_public: bool = False,
            body: Optional[dict | NewRelationshipRequestBody] = None,

    ) -> dict | str:
        """
        Adds an informal tag (either private of public) to an element. Async Version.

        Parameters
        ----------

        element_guid
            - unique id for the element.
        tag_guid
            - unique id of the tag.

        body: dict | NewRelationshipRequestBody
            - optional detailed information for the request.

        Returns
        -------
        Void

        Raises
        ------
        PyegeriaException
        """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_add_tag_to_element(
                element_guid,
                tag_guid,
                is_public,
                body
            )
        )

    @dynamic_catch
    async def _async_get_elements_by_tag(
            self,
            tag_guid: str,
            body: dict = {},
            start_from: int = 0,
            page_size: int = max_paging_size,

    ) -> dict | str:
        """
        Return the list of unique identifiers for elements that are linked to a specific tag either directly, or via one of its schema elements.

        Parameters
        ----------
        tag_guid
            - unique identifier of tag.
        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.

        Returns
        -------
        element stubs list

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """
        # Todo - fix the output format here when ready
        url = f"{self.command_root}feedback-manager/elements/by-tag/{tag_guid}?startFrom={start_from}&pageSize={page_size}"
        response = await self._async_make_request("POST", url, body)
        return response.json()

    @dynamic_catch
    def get_elements_by_tag(
            self,
            tag_guid: str,
            body: dict = {},
            start_from: int = 0,
            page_size: int = 0,

    ) -> dict | str:
        """
        Return the list of unique identifiers for elements that are linked to a specific tag either directly, or via one of its schema elements.

        Parameters
        ----------
        tag_guid
            - unique identifier of tag.
        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.

        Returns
        -------
        element stubs list

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_elements_by_tag(tag_guid, body, start_from, page_size)
        )
        return response

    @dynamic_catch
    async def _async_get_attached_tags(
            self,
            element_guid: str,
            body: dict = {},
            start_from: int = 0,
            page_size: int = max_paging_size,

    ) -> dict | str:
        """
        Return the informal tags attached to an element.

        Parameters
        ----------
        element_guid
            - unique identifier for the element that the ratings are connected to

        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.

        Returns
        -------
        List of InformalTags (InformalTagsResponse)

        Raises
        ------
        PyegeriaException
        """
        # Todo clean up and add output format stuff when ready
        url = f"{self.command_root}feedback-manager/elements/{element_guid}/tags/retrieve"
        response = await self._async_make_request("POST", url, body)
        return response.json()

    @dynamic_catch
    def get_attached_tags(
            self,
            element_guid: str,
            body: dict = {},
            start_from: int = 0,
            page_size: int = max_paging_size,

    ) -> dict | str:
        """
        Return the informal tags attached to an element.

        Parameters
        ----------
        element_guid
            - unique identifier for the element that the ratings are connected to

        body
            - optional effective time
        start_from
            - index of the list to start from (0 for start)
        page_size
            - maximum number of elements to return.

        Returns
        -------
        List of InformalTags (InformalTagsResponse)

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_attached_tags(
                element_guid,
                body,
                start_from,
                page_size,
            )
        )
        return response

    async def _async_remove_tag_from_element(
            self,
            element_guid: str,
            tag_guid: str,
            body: dict = None,

    ) -> dict | str:
        """
        Removes a link between a tag and an element that was added by this user.


        Parameters
        ----------

        element_guid
            - unique id for the element.
        tag_guid
            - unique id of the tag.

        body
            - null request body needed for correct protocol exchange.

        Returns
        -------
        Void

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """

        url = f"{self.command_root}feedback-manager/elements/{element_guid}/tags/{tag_guid}/remove"
        await self._async_make_request("POST", url, body)

    def remove_tag_from_element(
            self,
            element_guid: str,
            tag_guid: str,
            body: dict = None,

    ) -> dict | str:
        """
        Removes a link between a tag and an element that was added by this user.


        Parameters
        ----------
        element_guid
            - unique id for the element.
        tag_guid
            - unique id of the tag.

       body
            - null request body needed for correct protocol exchange.

        Returns
        -------
        Void

        Raises
        ------
        PyegeriaInvalidParameterException
            one of the parameters is null or invalid or
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository or
        PyegeriaUnauthorizedException
            the requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_remove_tag_from_element(
                element_guid,
                tag_guid,
                body
            )
        )
        return response
    #
    # Likes
    #
    @dynamic_catch
    async def _async_add_like_to_element(
            self,
            element_guid: str,
            emoji: str = None,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Creates a "like" object and attaches it to an element. Async version.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element.
        emoji :str, default None
            an optional emoji string
        body : dict, optional
            Optional effective time.

        Returns
        -------
        dict | str
            Response from the server.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.

        Notes:
        {
          "class" : "NewAttachmentRequestBody",
          "initialClassifications" : {
            "ZoneMembership" : {
              "class" : "ZoneMembershipProperties",
              "zoneMembership" : "erinoverview"
            }
          "properties" : {
            "class" : "LikeProperties",
            "emoji" : "Add characters here as text"
          }
        }

        """

        if body is None and emoji:
            body = {
              "class" : "NewAttachmentRequestBody",
              "initialClassifications" : {
                "ZoneMembership" : {
                  "class" : "ZoneMembershipProperties",
                  "zoneMembership" : "erinoverview"
                }
              },
              "properties" : {
                "class" : "LikeProperties",
                "emoji" : "Add characters here as text"
                }
            }
        url = f"{self.command_root}feedback-manager/elements/{element_guid}/likes"
        if body:
            response = await self._async_make_request("POST", url, body)
        else:
            response = await self._async_make_request("POST", url)
        return response.json()

    def add_like_to_element(
            self,
            element_guid: str,
            emoji: str = None,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Creates a "like" object and attaches it to an element.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element.
        emoji :str, default None
            an optional emoji string
        body : dict, optional
            Optional effective time.

        Returns
        -------
        dict | str
            Response from the server.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.

        Notes
        _____
        {
          "class" : "NewAttachmentRequestBody",
          "initialClassifications" : {
            "ZoneMembership" : {
              "class" : "ZoneMembershipProperties",
              "zoneMembership" : "erinoverview"
            }
          },
          "properties" : {
            "class" : "LikeProperties",
            "emoji" : "Add characters here as text"
          }
        }
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_add_like_to_element(element_guid, emoji, body)
        )
        return response

    @dynamic_catch
    async def _async_get_attached_likes(
            self,
            element_guid: str,
            body: Optional[dict] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "json",
            report_spec: Optional[str] = None
    ) -> dict | str:
        """
        Return the likes attached to an element. Async version.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element that the likes are connected to.
        body : dict, optional
            Optional effective time.
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default max_paging_size
            Maximum number of elements to return.
        output_format : str, default "json"
            Format of the returned output.
        report_spec : str, optional
            Report specification for the returned output.

        Returns
        -------
        dict | str
            List of likes in the requested format.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem retrieving information from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        if body is None:
            body = {}
        
        url = (f"{self.command_root}feedback-manager/elements/{element_guid}/likes/retrieve"
               f"?startFrom={start_from}&pageSize={page_size}")
        
        response = await self._async_make_request("POST", url, body)
        return response.json()

    def get_attached_likes(
            self,
            element_guid: str,
            body: Optional[dict] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "json",
            report_spec: Optional[str] = None
    ) -> dict | str:
        """
        Return the likes attached to an element.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element that the likes are connected to.
        body : dict, optional
            Optional effective time.
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default max_paging_size
            Maximum number of elements to return.
        output_format : str, default "json"
            Format of the returned output.
        report_spec : str, optional
            Report specification for the returned output.

        Returns
        -------
        dict | str
            List of likes in the requested format.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem retrieving information from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_attached_likes(element_guid, body, start_from, page_size,
                                          output_format, report_spec)
        )
        return response

    @dynamic_catch
    async def _async_remove_like_from_element(
            self,
            element_guid: str,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Removes a "Like" added to the element by this user. Async version.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element where the like is attached.
        body : dict, optional
            Optional effective time.

        Returns
        -------
        dict | str
            Response from the server.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem removing the like from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        url = f"{self.command_root}feedback-manager/elements/{element_guid}/likes/remove"
        
        response = await self._async_make_request("POST", url, body)
        return response.json()

    def remove_like_from_element(
            self,
            element_guid: str,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Removes a "Like" added to the element by this user.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element where the like is attached.
        body : dict, optional
            Optional effective time.

        Returns
        -------
        dict | str
            Response from the server.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem removing the like from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_remove_like_from_element(element_guid, body)
        )
        return response

    #
    # Ratings
    #
    @dynamic_catch
    async def _async_add_rating_to_element(
            self,
            element_guid: str,
            is_public: bool = True,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Adds a star rating and optional review text to the element. Async version.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element.
        is_public : bool, default True
            Is this visible to other people?
        body : dict, optional
            Contains the StarRating and user review of element.

        Returns
        -------
        dict | str
            Element GUID of the rating.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.

        Notes
        _____
        rating_body = {
            "class": "NewAttachmentRequestBody",
            "properties": {
                "class": "RatingProperties",
                "starRating": 5,
                "review": "Excellent test element!"
            }
        }
        """
        if body is None:
            body = {}
        
        url = (f"{self.command_root}feedback-manager/elements/{element_guid}/ratings"
               f"?isPublic={is_public}")
        
        response = await self._async_make_request("POST", url, body)
        return response.json()

    def add_rating_to_element(
            self,
            element_guid: str,
            is_public: bool = True,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Adds a star rating and optional review text to the element.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element.
        is_public : bool, default True
            Is this visible to other people?
        body : dict, optional
            Contains the StarRating and user review of element.

        Returns
        -------
        dict | str
            Element GUID of the rating.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem adding the element properties to the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.

        Notes
        _____
        rating_body = {
            "class": "NewAttachmentRequestBody",
            "properties": {
                "class": "RatingProperties",
                "starRating": 5,
                "review": "Excellent test element!"
            }
        }
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_add_rating_to_element(element_guid, is_public, body)
        )
        return response

    @dynamic_catch
    async def _async_get_attached_ratings(
            self,
            element_guid: str,
            body: Optional[dict] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "json",
            report_spec: Optional[str] = None
    ) -> dict | str:
        """
        Return the ratings attached to an element. Async version.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element that the ratings are connected to.
        body : dict, optional
            Optional effective time.
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default max_paging_size
            Maximum number of elements to return.
        output_format : str, default "json"
            Format of the returned output.
        report_spec : str, optional
            Report specification for the returned output.

        Returns
        -------
        dict | str
            List of ratings in the requested format.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem retrieving information from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        if body is None:
            body = {}
        
        url = (f"{self.command_root}feedback-manager/elements/{element_guid}/ratings/retrieve"
               f"?startFrom={start_from}&pageSize={page_size}")
        
        response = await self._async_make_request("POST", url, body)
        return response.json()

    def get_attached_ratings(
            self,
            element_guid: str,
            body: Optional[dict] = None,
            start_from: int = 0,
            page_size: int = max_paging_size,
            output_format: str = "json",
            report_spec: Optional[str] = None
    ) -> dict | str:
        """
        Return the ratings attached to an element.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element that the ratings are connected to.
        body : dict, optional
            Optional effective time.
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default max_paging_size
            Maximum number of elements to return.
        output_format : str, default "json"
            Format of the returned output.
        report_spec : str, optional
            Report specification for the returned output.

        Returns
        -------
        dict | str
            List of ratings in the requested format.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem retrieving information from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_attached_ratings(element_guid, body, start_from, page_size,
                                            output_format, report_spec)
        )
        return response

    @dynamic_catch
    async def _async_remove_rating_from_element(
            self,
            element_guid: str,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Removes a star rating/review that was added to the element by this user. Async version.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element where the rating is attached.
        body : dict, optional
            Optional effective time.

        Returns
        -------
        dict | str
            Response from the server.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem removing the rating from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        url = f"{self.command_root}feedback-manager/elements/{element_guid}/ratings/remove"
        
        response = await self._async_make_request("POST", url, body)
        return response.json()

    def remove_rating_from_element(
            self,
            element_guid: str,
            body: Optional[dict] = None
    ) -> dict | str:
        """
        Removes a star rating/review that was added to the element by this user.

        Parameters
        ----------
        element_guid : str
            Unique identifier for the element where the rating is attached.
        body : dict, optional
            Optional effective time.

        Returns
        -------
        dict | str
            Response from the server.

        Raises
        ------
        PyegeriaInvalidParameterException
            One of the parameters is null or invalid.
        PyegeriaAPIException
            There is a problem removing the rating from the metadata repository.
        PyegeriaUnauthorizedException
            The requesting user is not authorized to issue this request.
        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_remove_rating_from_element(element_guid, body)
        )
        return response


    #
    # Search Tags
    #
    @dynamic_catch
    async def _async_add_search_keyword_to_element(
            self,
            element_guid: str,
            keyword: Optional[str] = None,
            body: dict = None
    ) -> str:
        """
        Creates a search keyword and attaches it to an element.
        The GUID returned is the identifier of the relationship. Async Version.

        Parameters
        ----------
        element_guid: str
            - the identity of the element to update
        keyword: str = None
            - the name of the search keyword to add
        body: dict, optional
            - structure containing search string information - see Notes

        Returns
        -------
        Guid of the search keyword.

        Raises
        ------
        PyegeriaException

        Notes
        -----
        Sample body:
        {
          "class" : "NewAttachmentRequestBody",
          "properties" : {
            "class" : "SearchKeywordProperties",
            "keyword" : "myKeyword",
            "description" : "Add search keyword text here"
          }
        }

        """
        if body is None and keyword:
            body = {
                "class": "NewAttachmentRequestBody",
                "properties": {
                    "class": "SearchKeywordProperties",
                    "keyword": keyword
                }
            }
        elif body is None:
            raise PyegeriaInvalidParameterException(context={"reason": "keyword or body is required"})

        url = f"{self.command_root}classification-explorer/elements/{element_guid}/search-keywords"

        response = await self._async_make_request("POST", url, body_slimmer(body))
        return response.json().get('guid', 'Search keyword was not created')

    @dynamic_catch
    def add_search_keyword_to_element(
            self,
            element_guid: str,
            keyword: Optional[str] = None,
            body: dict = None,
    ) -> str:
        """
        Creates a search keyword and attaches it to an element.
        The GUID returned is the identifier of the relationship.

        Parameters
        ----------
        element_guid: str
            - the identity of the element to update
        keyword: str = None
            - the name of the search keyword to add
        body: dict, optional
            - structure containing search string information - see Notes

        Returns
        -------
        Guid of the search keyword.

        Raises
        ------
        PyegeriaException

        Notes
        -----
        Sample body:
        {
          "class" : "NewAttachmentRequestBody",
          "properties" : {
            "class" : "SearchKeywordProperties",
            "keyword" : "myKeyword",
            "description" : "Add search keyword text here"
          }
        }

        """

        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_add_search_keyword_to_element(element_guid, keyword, body)
        )
        return response


    @dynamic_catch
    async def _async_update_search_keyword(
            self,
            keyword_guid: str,
            body: Optional[dict | UpdateElementRequestBody] = None,
    ) -> str:
        """
       Update the properties of a search keyword. Async Version.

        Parameters
        ----------
        keyword_guid: str
            - identity of the keyword to update
        body: dict | UpdateElementRequestBody, optional
            - structure containing keyword information - see Notes

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        Notes
        -----
        Sample body:
        {
          "class" : "UpdateElementRequestBody",
          "mergeUpdate": true,
          "properties" : {
            "class" : "SearchKeywordProperties",
            "keyword" : "myKeyword",
            "description" : "Add search keyword text here"
          }
        }

        """

        url = f"{self.command_root}classification-explorer/search-keywords/{keyword_guid}/update"
        await self._async_update_relationship_request(url, None, body_slimmer(body))

    @dynamic_catch
    def update_search_keyword(
            self,
            keyword_guid: str,
            body: Optional[dict | UpdateElementRequestBody] = None,
    ) -> None:
        """
        Update the properties of a search keyword.

         Parameters
         ----------
         keyword_guid: str
             - identity of the keyword to update
         body: dict | UpdateElementRequestBody, optional
             - structure containing keyword information - see Notes

         Returns
         -------
         None

         Raises
         ------
         PyegeriaException

         Notes
         -----
         Sample body:
         {
           "class" : "UpdateElementRequestBody",
           "mergeUpdate": true,
           "properties" : {
             "class" : "SearchKeywordProperties",
             "keyword" : "myKeyword",
             "description" : "Add search keyword text here"
           }
         }

         """

        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_update_search_keyword(keyword_guid, body)
        )

    @dynamic_catch
    async def _async_remove_search_keyword(
            self,
            keyword_guid: str
    ) -> None:
        """
        Remove the search keyword for an element. Async Version.

        Parameters
        ----------
        keyword_guid: str
            - identity of the search keyword to remove.

        Returns
        -------

        Raises
        ------
        PyegeriaException


        """

        url = f"{self.command_root}classification-explorer/search-keywords/{keyword_guid}/remove"
        await self._async_delete_relationship_request(url = url, body = None, cascade_delete = False)

    @dynamic_catch
    def remove_search_keyword(
            self,
            keyword_guid,
    ) -> None:
        """
        Remove the search keyword for an element.

        Parameters
        ----------
        license_guid: str
            - identity of the license to remove

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException

        """

        loop = asyncio.get_event_loop()
        loop.run_until_complete(
            self._async_remove_search_keyword(keyword_guid )
        )

    @dynamic_catch
    async def _async_get_search_keyword_by_guid(
            self,
            keyword_guid: str,
            output_format: str | None = "JSON",
            report_spec: dict | str = None
    ) -> dict | str:
        """
        Return information about the specified search keyword.

        Parameters
        ----------
        keyword_guid: str
            - unique identifier of tag.
        output_format: str, default "JSON"
            - output format for the response
        report_spec: str | dict, default None
            - report specification

        Returns
        -------
        Details of the search keyword in the requested format.

        Raises
        ------
        PyegeriaException

        """

        url = f"{self.command_root}classification-explorer/search-keywords/{keyword_guid}"
        response = await self._async_get_guid_request(url, "SearchKeyword", self._generate_feedback_output,
                                                      output_format, report_spec)
        return response

    @dynamic_catch
    def get_search_keyword_by_guid(
            self,
            keyword_guid: str,
            output_format: str | None = "JSON",
            report_spec: dict | str = None

    ) -> dict | str:
        """
               Return information about the specified search keyword.

               Parameters
               ----------
               keyword_guid: str
                   - unique identifier of tag.
               output_format: str, default "JSON"
                   - output format for the response
               report_spec: str | dict, default None
                   - report specification

               Returns
               -------
               Details of the search keyword in the requested format.

               Raises
               ------
               PyegeriaException

               """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_get_search_keyword_by_guid(keyword_guid, output_format, report_spec)
        )
        return response

    @dynamic_catch
    async def _async_get_search_keyword_by_keyword(
            self,
            keyword: str,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str | None = "JSON",
            report_spec: dict | str = None,
            body: Optional[dict | FilterRequestBody] = None
    ) -> dict | str:
        """
        Return information about the specified search keyword. Async Version.

        Parameters
        ----------
        keyword : str
            - keyword to search for.
        start_from: int, default 0
            - start index of the search keyword
        page size
            - output_format: str, default "JSON
        output_format: str, default "JSON"
            - output format for the response
        report_spec: str | dict, default None
            - report specification
        body: dict | FilterRequestBody, optional
            - structure containing detailed request information.

        Returns
        -------
        Details of the search keyword in the requested format.

        Raises
        ------
        PyegeriaException

        """
        if body is None and keyword:
            body = {
                "class": "FilterRequestBody",
                "filter": keyword,
                "startFrom": start_from,
                "pageSize": page_size
            }
        url = f"{self.command_root}classification-explorer/search-keywords/by-keyword"
        response = await self._async_get_name_request(url, "SearchKeyword", self._generate_feedback_output,
                                                      start_from=0, page_size=0, output_format="JSON",
                                                      report_spec=keyword, body=None, max_mermaid_node_count=None)
        return response

    @dynamic_catch
    def get_search_keyword_by_keyword(
            self,
            keyword: str,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str | None = "JSON",
            report_spec: dict | str = None,
            body: Optional[dict | FilterRequestBody] = None
    ) -> dict | str:
        """
        Return information about the specified search keyword.

        Parameters
        ----------
        keyword : str
            - keyword to search for.
        start_from: int, default 0
            - start index of the search keyword
        page size
            - output_format: str, default "JSON
        output_format: str, default "JSON"
            - output format for the response
        report_spec: str | dict, default None
            - report specification
        body: dict | FilterRequestBody, optional
            - structure containing detailed request information.

        Returns
        -------
        Details of the search keyword in the requested format.

        Raises
        ------
        PyegeriaException

        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_find_search_keywords(keyword, body, start_from=start_from, page_size=page_size,
                                            output_format=output_format, report_spec=report_spec)
        )
        return response

    async def _async_find_search_keywords(
            self,
            search_string: str,
            body: Optional[dict | SearchStringRequestBody] = None,
            starts_with: bool = False,
            ends_with: bool = False,
            ignore_case: bool = True,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str | None = "JSON",
            report_spec: dict | str = None,
            **kwargs
    ) -> dict | str:
        """
        Return the list of search keywords containing the supplied string. Async version.

        The search string is located in the request body and is interpreted as a plain string. The request parameters
        startsWith, endsWith and ignoreCase can be used to allow a fuzzy search. The request body also supports the
        specification of an effective time to restrict the search to elements that are/were effective at a particular time.

        Parameters
        ----------
        search_string : str
            String to search for in search keyword names or descriptions.
        body : dict | SearchStringRequestBody, optional
            Details of the request. If provided, overrides other parameters.
        starts_with : bool, default False
            Does the value start with the supplied string?
        ends_with : bool, default False
            Does the value end with the supplied string?
        ignore_case : bool, default True
            Should the search ignore case?
        start_from : int, default 0
            Index of the list to start from (0 for start).
        page_size : int, default 0
            Maximum number of elements to return (0 for server default).
        output_format : str, default "JSON"
            Format of the returned output.
        report_spec : str | dict, optional
            Report specification for the returned output.
        **kwargs : dict, optional
            Additional parameters supported by the underlying find request:
            
            - anchor_domain : str - Domain to anchor the search
            - metadata_element_type : str - Specific metadata element type
            - metadata_element_subtypes : list[str] - List of metadata element subtypes
            - skip_relationships : list[str] - Relationship types to skip
            - include_only_relationships : list[str] - Only include these relationship types
            - skip_classified_elements : list[str] - Skip elements with these classifications
            - include_only_classified_elements : list[str] - Only include elements with these classifications
            - graph_query_depth : int - Depth of graph traversal (default 3)
            - governance_zone_filter : list[str] - Filter by governance zones
            - as_of_time : str - Historical query time
            - effective_time : str - Effective time for the query
            - relationship_page_size : int - Page size for relationships
            - limit_results_by_status : list[str] - Filter by element status
            - sequencing_order : str - Order of results
            - sequencing_property : str - Property to sequence by
            - property_names : list[str] - Specific properties to search

        Returns
        -------
        dict | str
            List of search keyword objects in the requested format.

        Raises
        ------
        PyegeriaException
            If there are issues in communications, message format, or Egeria errors.

        Notes
        -----
        The **kwargs parameter allows advanced users to access all parameters supported by the
        underlying _async_find_request helper method. Common parameters are explicitly listed
        in the signature for discoverability, while advanced parameters can be passed via kwargs.

        Examples
        --------
        Basic usage:
            >>> keywords = await client._async_find_search_keywords("data", starts_with=True)
        
        Advanced usage with kwargs:
            >>> keywords = await client._async_find_search_keywords(
            ...     "data",
            ...     starts_with=True,
            ...     governance_zone_filter=["internal"],
            ...     limit_results_by_status=["ACTIVE"]
            ... )
        """
        if body is None and search_string:
            body = {
                "class": "SearchStringRequestBody",
                "filter": search_string,
                "startFrom": start_from,
                "pageSize": page_size
            }
        url = f"{self.command_root}classification-explorer/search-keywords/by-search-string"
        
        # Build params dict with explicit parameters
        params = {
            'search_string': search_string,
            'starts_with': starts_with,
            'ends_with': ends_with,
            'ignore_case': ignore_case,
            'start_from': start_from,
            'page_size': page_size,
            'output_format': output_format,
            'report_spec': report_spec,
            'body': body
        }
        # Merge with any additional kwargs, removing None values
        params.update(kwargs)
        # Filter out None values, but keep search_string even if None (it's required)
        params = {k: v for k, v in params.items() if v is not None or k == 'search_string'}
        
        response = await self._async_find_request(url, _type="SearchKeyword",
                                                  _gen_output=self._generate_feedback_output, **params)
        return response

    @dynamic_catch
    def find_search_keywords(
            self,
            search_string: str,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str | None = "JSON",
            report_spec: dict | str = None,
            body: Optional[dict | SearchStringRequestBody] = None
    ) -> dict | str:
        """
        Return the list of search keywords containing the supplied string. The search string is located in the request
         body and is interpreted as a plain string.  The request parameters, startsWith, endsWith and ignoreCase can
         be used to allow a fuzzy search.  The request body also supports the specification of an effective time to
         restrict the search to element that are/were effective at a particular time. Async Version.

        Parameters
        ----------
        search_string : str
            - keyword to search for.
        start_from: int, default 0
            - start index of the search keyword
        page size
            - output_format: str, default "JSON
        output_format: str, default "JSON"
            - output format for the response
        report_spec: str | dict, default None
            - report specification
        body: dict | SearchStringRequestBody, optional
            - structure containing detailed request information.

        Returns
        -------
        Details of the search keyword in the requested format.

        Raises
        ------
        PyegeriaException

        """
        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            self._async_find_search_keywords(search_string, body, start_from=start_from, page_size=page_size,
                                            output_format=output_format, report_spec=report_spec)
        )
        return response

    @dynamic_catch
    def _extract_comment_properties(self, element: dict, columns_struct: dict) -> dict:
        props = element.get('properties', {}) or {}
        normalized = {
            'properties': props,
            'elementHeader': element.get('elementHeader', {}),
        }
        # Common population pipeline
        col_data = populate_common_columns(element, columns_struct)
        columns_list = col_data.get('formats', {}).get('attributes', [])
        # Overlay extras (project roles) only where empty
        # extra = self._extract_additional_project_properties(element, columns_struct)
        # col_data = overlay_additional_values(col_data, extra)
        return col_data

    def _extract_element_properties_for_keyword(self, element: dict, columns_struct: dict) -> dict:
        keyword_elements = None
        keyword_elements = element["keywordElements"]
        out_body = {}
        keyword = element["properties"].get('keyword', '')
        for el in keyword_elements:
            element = el.get("relatedElement", {})
            element_guid = element['elementHeader']['guid']
            element_type = element['elementHeader']['type']['typeName']
            element_display_name = element['properties'].get('displayName',"")
            element_description = element['properties'].get('description',"")
            element_category = element['properties'].get('category',"")
            out_body = {
                "element_display_name": element_display_name,
                "element_description": element_description,
                "element_category": element_category,
                "element_type": element_type,
                "element_guid": element_guid,
                "keyword": keyword
            }
        return out_body

    @dynamic_catch
    def _extract_feedback_properties(self, element: dict, columns_struct: dict) -> dict:
        props = element.get('properties', {}) or {}
        normalized = {
            'properties': props,
            'elementHeader': element.get('elementHeader', {}),
        }
        # Common population pipeline
        col_data = populate_common_columns(element, columns_struct)
        columns_list = col_data.get('formats', {}).get('attributes', [])
        # Overlay extras (project roles) only where empty
        keyword_elements = element.get("keywordElements", [])

        if keyword_elements != [] and isinstance(element['keywordElements'], list):
            extra = self._extract_element_properties_for_keyword(element, columns_struct)
            col_data = overlay_additional_values(col_data, extra)

        note_logs = element.get("presentInNoteLogs", [])
        if note_logs != []:
            extra = self._extract_element_properties_for_notes( element, columns_struct)
            col_data = overlay_additional_values(col_data, extra)

        return col_data

    @dynamic_catch
    def _generate_feedback_output(self, elements: dict | list[dict], search_string: Optional[str] = None,
                                  element_type_name: Optional[str] = None,
                                  output_format: str = 'DICT',
                                  report_spec: dict | str = None,
                                  **kwargs) -> str | list[dict]:
        return self._generate_formatted_output(
            elements=elements,
            query_string=search_string,
            entity_type=element_type_name,
            output_format=output_format,
            extract_properties_func=self._extract_feedback_properties,
            report_spec=report_spec,
            **kwargs
        )


    #
    # Helper functions for requests
    #

    @dynamic_catch
    def validate_new_attachment_request(self, body: dict | NewAttachmentRequestBody,
                                        prop: Optional[list[str]] = None) -> NewAttachmentRequestBody | None:
        if isinstance(body, NewAttachmentRequestBody):
            validated_body = body

        elif isinstance(body, dict):
            validated_body = self._new_attachment_request_adapter.validate_python(body)
        else:
            return None
        return validated_body

    @dynamic_catch
    def validate_new_element_request(self, body: dict | NewElementRequestBody,
                                     prop: Optional[list[str]] = None) -> NewElementRequestBody | None:
        if isinstance(body, NewElementRequestBody):
            # if body.properties.class_ in prop:
            validated_body = body
            # else:
            #     raise PyegeriaInvalidParameterException(additional_info=
            #                                             {"reason": "unexpected property class name"})

        elif isinstance(body, dict):
            # if body.get("properties", {}).get("class", "") == prop:
            validated_body = self._new_element_request_adapter.validate_python(body)
            # else:
            #     raise PyegeriaInvalidParameterException(additional_info=
            #                                             {"reason": "unexpected property class name"})
        else:
            return None
        return validated_body

    @dynamic_catch
    def validate_new_element_from_template_request(self, body: dict | TemplateRequestBody
                                                   ) -> NewElementRequestBody | None:
        if isinstance(body, TemplateRequestBody):
            validated_body = body

        elif isinstance(body, dict):
            # if body.get("properties", {}).get("class", "") == prop:
            validated_body = self._template_request_adapter.validate_python(body)
        else:
            return None
        return validated_body

    @dynamic_catch
    def validate_new_relationship_request(self, body: dict | NewRelationshipRequestBody,
                                          prop: Optional[list[str]] = None) -> NewRelationshipRequestBody | None:
        if isinstance(body, NewRelationshipRequestBody):
            # If a NewRelationshipRequestBody object is passed, we trust it,
            # but still check if prop is provided and matches.
            # To be more permissive, we allow it if prop is None or it matches.
            if prop is None or body.properties.get("class") in prop:
                validated_body = body
            else:
                # If it doesn't match the specific prop class, we still allow it
                # if it's a valid object, but log a warning if needed.
                # For now, let's just return it as is.
                validated_body = body
        elif isinstance(body, dict):
            if prop is None or body.get("properties", {}).get("class", "") in prop:
                validated_body = self._new_relationship_request_adapter.validate_python(body)
            else:
                # Fallback: try to validate even if prop doesn't match
                validated_body = self._new_relationship_request_adapter.validate_python(body)
        else:
            return None
        return validated_body

    @dynamic_catch
    def validate_new_classification_request(self, body: dict | NewClassificationRequestBody,
                                            prop: str | list[str] = None) -> NewClassificationRequestBody | None:
        if isinstance(body, NewClassificationRequestBody):
            if (prop and body.properties.get("class") in prop) or (prop is None):
                validated_body = body
            else:
                raise PyegeriaInvalidParameterException(additional_info=
                                                        {"reason": "unexpected property class name"})

        elif isinstance(body, dict):
            if prop is None or body.get("properties", {}).get("class", "") in prop:
                validated_body = self._new_classification_request_adapter.validate_python(body)
            else:
                raise PyegeriaInvalidParameterException(additional_info=
                                                        {"reason": "unexpected property class name"})
        else:
            return None

        return validated_body

    @dynamic_catch
    def validate_delete_element_request(self, body: Optional[dict | DeleteElementRequestBody] = None,
                                        cascade_delete: bool = False) -> DeleteElementRequestBody | None:
        if isinstance(body, DeleteElementRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._delete_element_request_adapter.validate_python(body)
        else:  # handle case where body not provided
            body = {
                "class": "DeleteElementRequestBody",
                "cascadeDelete": cascade_delete
            }
            validated_body = DeleteElementRequestBody.model_validate(body)
        return validated_body

    @dynamic_catch
    def validate_delete_relationship_request(self, body: dict | DeleteRelationshipRequestBody,
                                             cascade_delete: bool = False) -> DeleteRelationshipRequestBody | None:
        if isinstance(body, DeleteRelationshipRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._delete_relationship_request_adapter.validate_python(body)
        else:  # handle case where body not provided
            # body = {
            #     "class": "DeleteRelationshipRequestBody",
            #     "cascadeDelete": cascade_delete
            # }
            # validated_body = DeleteRelationshipRequestBody.model_validate(body)
            return None
        return validated_body

    @dynamic_catch
    def validate_delete_classification_request(self, body: dict | DeleteClassificationRequestBody,
                                               cascade_delete: bool = False) -> DeleteClassificationRequestBody | None:
        if isinstance(body, DeleteClassificationRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._delete_classification_request_adapter.validate_python(body)
        else:  # handle case where body not provided
            body = {
                "class": "DeleteClassificationRequestBody",
                "cascadeDelete": cascade_delete
            }
            validated_body = DeleteClassificationRequestBody.model_validate(body)
        return validated_body

    @dynamic_catch
    def validate_update_element_request(self, body: dict | UpdateElementRequestBody | UpdateClassificationRequestBody,
                                        prop: Optional[list[str]] = None) -> UpdateElementRequestBody | None:
        if isinstance(body, UpdateElementRequestBody | UpdateClassificationRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            if prop is None or (isinstance(body['properties'], dict) and body['properties'].get("class") in prop):
                validated_body = body
            else:
                raise PyegeriaInvalidParameterException(additional_info=
                                                        {"reason": "unexpected property class name"})

        elif isinstance(body, dict):
            # if body.get("properties", {}).get("class", "") in prop:
            validated_body = self._update_element_request_adapter.validate_python(body)
            # else:
            #     raise PyegeriaInvalidParameterException(additional_info=
            #                                             {"reason": "unexpected property class name"})
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    def validate_update_properties_request(self, body: dict | UpdatePropertiesRequestBody) -> UpdatePropertiesRequestBody | None:
        if isinstance(body, UpdatePropertiesRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._update_properties_request_adapter.validate_python(body)
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    def validate_metadata_source_request(self, body: dict | MetadataSourceRequestBody) -> MetadataSourceRequestBody | None:
        if isinstance(body, MetadataSourceRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._metadata_source_request_adapter.validate_python(body)
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    def validate_update_effectivity_dates_request(self, body: dict | UpdateEffectivityDatesRequestBody) -> UpdateEffectivityDatesRequestBody | None:
        if isinstance(body, UpdateEffectivityDatesRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._update_effectivity_dates_request_adapter.validate_python(body)
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    def validate_open_metadata_delete_request(self, body: dict | OpenMetadataDeleteRequestBody) -> OpenMetadataDeleteRequestBody | None:
        if isinstance(body, OpenMetadataDeleteRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._open_metadata_delete_request_adapter.validate_python(body)
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    def validate_archive_request(self, body: dict | ArchiveRequestBody) -> ArchiveRequestBody | None:
        if isinstance(body, ArchiveRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._archive_request_adapter.validate_python(body)
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    def validate_new_open_metadata_element_request(self, body: dict | NewOpenMetadataElementRequestBody) -> NewOpenMetadataElementRequestBody | None:
        if isinstance(body, NewOpenMetadataElementRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._new_open_metadata_element_request_adapter.validate_python(body)
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    def validate_new_related_elements_request(self, body: dict | NewRelatedElementsRequestBody) -> NewRelatedElementsRequestBody | None:
        if isinstance(body, NewRelationshipRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._new_relationship_request_adapter.validate_python(body)
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    async def _async_create_open_metadata_element_body_request(self, url: str, body: Optional[dict | NewOpenMetadataElementRequestBody] = None) -> str:
        validated_body = self.validate_new_open_metadata_element_request(body)
        response = await self._async_make_request("POST", url, validated_body.model_dump(by_alias=True, exclude_none=True))
        return response.json().get("guid")

    @dynamic_catch
    async def _async_update_properties_body_request(self, url: str, body: Optional[dict | UpdatePropertiesRequestBody] = None) -> None:
        validated_body = self.validate_update_properties_request(body)
        await self._async_make_request("POST", url, validated_body.model_dump(by_alias=True, exclude_none=True))

    @dynamic_catch
    async def _async_metadata_source_body_request(self, url: str, body: Optional[dict | MetadataSourceRequestBody] = None) -> None:
        validated_body = self.validate_metadata_source_request(body)
        await self._async_make_request("POST", url, validated_body.model_dump(by_alias=True, exclude_none=True))

    @dynamic_catch
    async def _async_update_effectivity_dates_body_request(self, url: str, body: Optional[dict | UpdateEffectivityDatesRequestBody] = None) -> None:
        validated_body = self.validate_update_effectivity_dates_request(body)
        await self._async_make_request("POST", url, validated_body.model_dump(by_alias=True, exclude_none=True))

    @dynamic_catch
    async def _async_open_metadata_delete_body_request(self, url: str, body: Optional[dict | OpenMetadataDeleteRequestBody] = None) -> None:
        validated_body = self.validate_open_metadata_delete_request(body)
        await self._async_make_request("POST", url, validated_body.model_dump(by_alias=True, exclude_none=True))

    @dynamic_catch
    async def _async_archive_body_request(self, url: str, body: Optional[dict | ArchiveRequestBody] = None) -> None:
        validated_body = self.validate_archive_request(body)
        await self._async_make_request("POST", url, validated_body.model_dump(by_alias=True, exclude_none=True))

    @dynamic_catch
    async def _async_create_related_elements_body_request(self, url: str, body: Optional[dict | NewRelatedElementsRequestBody] = None) -> str:
        validated_body = self.validate_new_related_elements_request(body)
        response = await self._async_make_request("POST", url, validated_body.model_dump(by_alias=True, exclude_none=True))
        return response.json().get("guid")

    # @dynamic_catch
    # def validate_update_status_request(self, status: Optional[str] = None, body: Optional[dict | UpdateStatusRequestBody] = None,
    #                                    prop: Optional[list[str]] = None) -> UpdateStatusRequestBody | None:
    #     if isinstance(body, UpdateStatusRequestBody):
    #         validated_body = body
    #
    #     elif isinstance(body, dict):
    #         validated_body = self._update_element_request_adapter.validate_python(body)
    #
    #     elif status:
    #         body = {
    #             "class": "UpdateStatusRequestBody",
    #             "newStatus": status
    #         }
    #         validated_body = UpdateStatusRequestBody.model_validate(body)
    #     else:
    #         raise PyegeriaInvalidParameterException
    #
    #     return validated_body

    @dynamic_catch
    def validate_update_relationship_request(self, body: dict | UpdateRelationshipRequestBody,
                                             prop: [str] = None) -> UpdateRelationshipRequestBody | None:
        if isinstance(body, UpdateRelationshipRequestBody):
            # if body.properties.class_ == prop:
            validated_body = body
            # else:
            #     raise PyegeriaInvalidParameterException(additional_info=
            #                                             {"reason": "unexpected property class name"})

        elif isinstance(body, dict):
            # if body.get("properties", {}).get("class", "") == prop:
            validated_body = self._update_relationship_request_adapter.validate_python(body)
            # else:
            #     raise PyegeriaInvalidParameterException(additional_info=
            #                                             {"reason": "unexpected property class name"})
        else:
            validated_body = None
        return validated_body

    @dynamic_catch
    async def _async_find_request(self, url: str, _type: str, _gen_output: Callable[..., Any], search_string: str,
                                  starts_with: bool = True, ends_with: bool = False, ignore_case: bool = False,
                                  anchor_domain: Optional[str] = None, anchor_type_name: Optional[str]=None,
                                  anchor_guid: Optional[str]=None,
                                  anchor_scope_guid=None, metadata_element_type: Optional[str] = None,
                                  metadata_element_subtypes: Optional[list[str]] = None,
                                  skip_relationships: Optional[list[str]] = None,
                                  include_only_relationships: Optional[list[str]] = None,
                                  skip_classified_elements: Optional[list[str]] = None,
                                  include_only_classified_elements: Optional[list[str]] = None,
                                  graph_query_depth: int = 5, max_mermaid_node_count: int = 5,
                                  governance_zone_filter: Optional[list[str]] = None, as_of_time: Optional[str] = None,
                                  effective_time: Optional[str] = None, relationship_page_size: int = 0,
                                  limit_results_by_status: Optional[list[str]] = None,
                                  sequencing_order: Optional[str] = None, sequencing_property: Optional[str] = None,
                                  output_format: str = "JSON", report_spec: Optional[str | dict] = None,
                                  start_from: int = 0, page_size: int | None = 100,
                                  property_names: Optional[list[str]] = None,
                                  body: dict | SearchStringRequestBody | FindPropertyNamesRequestBody = None,
                                  **kwargs) -> Any:

        if kwargs:
            invalid_keys = ", ".join(kwargs.keys())
            raise PyegeriaInvalidParameterException(
                additional_info={
                    "reason": f"Invalid find parameter(s) provided: {invalid_keys}. "
                              f"Please check the Pyegeria documentation for valid find property parameters."
                }
            )

        if isinstance(metadata_element_type, str) and not metadata_element_type.strip():
            metadata_element_type = None

        if isinstance(body, (SearchStringRequestBody, FindPropertyNamesRequestBody)):
            validated_body = body
        elif isinstance(body, dict):
            if body.get("class") == "FindPropertyNamesProperties":
                validated_body = self._find_property_names_request_adapter.validate_python(body)
            else:
                validated_body = self._search_string_request_adapter.validate_python(body)
        else:
            # Treat a lone '*' as a wildcard for any content: map to '.*' regex understood by Egeria
            search_string = None if search_string == "*" else search_string
            if page_size is None:
                page_size = 0

            if property_names:
                body = {
                    "class": "FindPropertyNamesProperties",
                    "metadataElementTypeName": metadata_element_type,
                    "propertyValue": search_string,
                    "propertyNames": property_names,
                    "asOfTime": as_of_time,
                    "effectiveTime": effective_time,
                    "limitResultsByStatus": limit_results_by_status,
                    "sequencingOrder": sequencing_order,
                    "sequencingProperty": sequencing_property,
                    "start_from": start_from,
                    "pageSize": page_size,
                    "metadataElementSubtypeNames": metadata_element_subtypes,
                    "skipRelationships": skip_relationships,
                    "includeOnlyRelationships": include_only_relationships,
                    "relationshipPageSize": relationship_page_size,
                    "skipClassifiedElements": skip_classified_elements,
                    "includeOnlyClassifiedElements": include_only_classified_elements,
                    "graphQueryDepth": graph_query_depth,
                    "maxMermaidNodeCount": max_mermaid_node_count,
                    "anchorGUID": anchor_guid,
                    "anchorTypeName": anchor_type_name,
                    "anchorDomainName": anchor_domain,
                    "anchorScopeGuid": anchor_scope_guid,
                }
                if not metadata_element_type:
                    body.pop("metadataElementTypeName", None)
                validated_body = FindPropertyNamesRequestBody.model_validate(body)
            else:
                body = {
                    "class": "SearchStringRequestBody",
                    "searchString": search_string,
                    "startWith": starts_with,
                    "endWith": ends_with,
                    "ignoreCase": ignore_case,
                    "anchorGUID": anchor_guid,
                    "anchorTypeName": anchor_type_name,
                    "anchorDomainName": anchor_domain,
                    "anchorScopeGuid": anchor_scope_guid,
                    "zoneFilter": governance_zone_filter,
                    "metadataElementTypeName": metadata_element_type,
                    "metadataElementSubtypeNames": metadata_element_subtypes,
                    "skipRelationships": skip_relationships,
                    "includeOnlyRelationships": include_only_relationships,
                    "relationshipPageSize": relationship_page_size,
                    "skipClassifiedElements": skip_classified_elements,
                    "includeOnlyClassifiedElements": include_only_classified_elements,
                    "graphQueryDepth": graph_query_depth,
                    "maxMermaidNodeCount": max_mermaid_node_count,
                    "asOfTime": as_of_time,
                    "effectiveTime": effective_time,
                    "limitResultsByStatus": limit_results_by_status,
                    "sequencingOrder": sequencing_order,
                    "sequencingProperty": sequencing_property,
                    "start_from": start_from,
                    "pageSize": page_size

                }
                if not metadata_element_type:
                    body.pop("metadataElementTypeName", None)
                validated_body = SearchStringRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)

        response = await self._async_make_request("POST", url, json_body, time_out = 90)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format and output_format.upper() != 'JSON':  # return a simplified markdown representation
            # logger.info(f"Found elements, output format: {output_format} and report_spec: {report_spec}")
            return _gen_output(elements=elements, search_string=search_string, element_type_name=_type,
                               output_format=output_format, report_spec=report_spec, **kwargs)
        return elements

    @dynamic_catch
    async def _async_get_name_request(self, url: str, _type: str, _gen_output: Callable[..., Any],
                                      filter_string: str = None, classification_names: list[str] = None,
                                      start_from: int = None, page_size: int = None, output_format: str = "JSON",
                                      report_spec: Optional[str | dict] = None,
                                      body: Optional[dict | FilterRequestBody] = None,
                                    max_mermaid_node_count=5, **kwargs) -> Any:

        if isinstance(body, FilterRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._filter_request_adapter.validate_python(body)
        else:
            filter_string = None if filter_string == "*" else filter_string
            classification_names = None if classification_names == [] else classification_names
            body = {
                "class": "FilterRequestBody",
                "filter": filter_string,
                "start_from": start_from,
                "page_size": page_size,
                "include_only_classified_elements": classification_names,
                "maxMermaidNodeCount": max_mermaid_node_count
            }
            validated_body = FilterRequestBody.model_validate(body)

        # classification_names = validated_body.include_only_classified_elements
        # element_type_name = classification_names[0] if classification_names else _type

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)

        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str or len(elements) == 0:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format and output_format.upper() != 'JSON':  # return a simplified markdown representation
            logger.info(f"Found elements, output format: {output_format} and report_spec: {report_spec}")
            return _gen_output(elements=elements, filter_string=filter_string, element_type_name=_type,
                               output_format=output_format, report_spec=report_spec, **kwargs)
        return elements

    @dynamic_catch
    async def _async_get_guid_request(self, url: str, _type: str, _gen_output: Callable[..., Any],
                                      output_format: str = 'JSON', report_spec: Optional[str | dict] = None,
                                      body: Optional[dict | GetRequestBody] = None, max_mermaid_node_count=5,
                                      **kwargs) -> Any:

        if isinstance(body, GetRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._get_request_adapter.validate_python(body)
        else:
            _type = _type.replace(" ", "")
            body = {
                "class": "GetRequestBody",
                "metadataElementTypeName": _type,
                "maxMermaidNodeCount": max_mermaid_node_count
            }
            validated_body = GetRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)

        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("element", NO_ELEMENTS_FOUND)
        if type(elements) is str:
            elements = response.json().get("elementGraph", NO_ELEMENTS_FOUND)
            if type(elements) is str:
                logger.info(NO_ELEMENTS_FOUND)
                return NO_ELEMENTS_FOUND

        if output_format and output_format.upper() != 'JSON':  # return a simplified markdown representation
            logger.info(f"Found elements, output format: {output_format} and report_spec: {report_spec}")
            return _gen_output(elements=elements, filter_string="GUID", element_type_name=_type, 
                               output_format=output_format, report_spec=report_spec, **kwargs)
        return elements

    @dynamic_catch
    async def _async_get_request_body_request(self, url: str, _type: str, _gen_output: Callable[..., Any],
                                              output_format: str = 'JSON',
                                              report_spec: Optional[str | dict] = None,
                                              body: Optional[dict | GetRequestBody] = None,
                                              max_mermaid_node_count=5, graph_query_depth=5,
                                              **kwargs) -> Any:
        """Handles request; returns elements or formatted output

        Args:
            max_mermaid_node_count ():
            graph_query_depth ():
        """
        if isinstance(body, GetRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._get_request_adapter.validate_python(body)
        else:
            body = {
                "class": "GetRequestBody",
                "metadataElementTypeName": _type,
                "maxMermaidNodeCount": max_mermaid_node_count,
                "graphQueryDepth": graph_query_depth
            }
            validated_body = GetRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)

        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", None)
        if elements is None:
            elements = response.json().get("element", NO_ELEMENTS_FOUND)

        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != 'JSON':  # return a simplified markdown representation
            logger.info(f"Found elements, output format: {output_format} and report_spec: {report_spec}")
            return _gen_output(elements, "Members", _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_activity_status_search_request(
        self,
        url: str,
        _type: str,
        _gen_output: Callable[..., Any],
        search_string: str,
        activity_status_list: Optional[list[str]] = None,
        starts_with: bool = True,
        ends_with: bool = False,
        ignore_case: bool = False,
        anchor_domain: Optional[str] = None,
        metadata_element_type: Optional[str] = None,
        metadata_element_subtypes: Optional[list[str]] = None,
        skip_relationships: Optional[list[str]] = None,
        include_only_relationships: Optional[list[str]] = None,
        skip_classified_elements: Optional[list[str]] = None,
        include_only_classified_elements: Optional[list[str]] = None,
        graph_query_depth: int = 3,
        max_mermaid_node_count: int = 5,
        governance_zone_filter: Optional[list[str]] = None,
        as_of_time: Optional[str] = None,
        effective_time: Optional[str] = None,
        relationship_page_size: int = 0,
        limit_results_by_status: Optional[list[str]] = None,
        sequencing_order: Optional[str] = None,
        sequencing_property: Optional[str] = None,
        output_format: Optional[str] = None,
        report_spec: Optional[str | dict] = None,
        start_from: int = 0,
        page_size: int | None = 100,
        body: dict | ActivityStatusSearchString | None = None,
        **kwargs
    ) -> Any:
        if isinstance(body, ActivityStatusSearchString):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._activity_status_search_request_adapter.validate_python(body)
        else:
            search_string = None if search_string == "*" else search_string
            if page_size is None:
                page_size = 0
            body = {
                "class": "ActivityStatusSearchString",
                "searchString": search_string,
                "activityStatusList": activity_status_list,
                "startWith": starts_with,
                "endWith": ends_with,
                "ignoreCase": ignore_case,
                "anchorDomain": anchor_domain,
                "zoneFilter": governance_zone_filter,
                "metadataElementTypeName": metadata_element_type,
                "metadataElementSubtypeNames": metadata_element_subtypes,
                "skipRelationships": skip_relationships,
                "includeOnlyRelationships": include_only_relationships,
                "relationshipPageSize": relationship_page_size,
                "skipClassifiedElements": skip_classified_elements,
                "includeOnlyClassifiedElements": include_only_classified_elements,
                "graphQueryDepth": graph_query_depth,
                "maxMermaidNodeCount": max_mermaid_node_count,
                "asOfTime": as_of_time,
                "effectiveTime": effective_time,
                "limitResultsByStatus": limit_results_by_status,
                "sequencingOrder": sequencing_order,
                "sequencingProperty": sequencing_property,
                "start_from": start_from,
                "pageSize": page_size,
            }
            validated_body = ActivityStatusSearchString.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        response = await self._async_make_request("POST", url, json_body, time_out=90)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != "JSON":
            return _gen_output(elements, search_string, _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_activity_status_filter_request(
        self,
        url: str,
        _type: str,
        _gen_output: Callable[..., Any],
        filter_string: str,
        activity_status_list: Optional[list[str]] = None,
        start_from: int = 0,
        page_size: int = 0,
        output_format: str = "JSON",
        report_spec: Optional[str | dict] = None,
        body: Optional[dict | ActivityStatusFilterRequestBody] = None,
        **kwargs
    ) -> Any:
        if isinstance(body, ActivityStatusFilterRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._activity_status_filter_request_adapter.validate_python(body)
        else:
            filter_string = None if filter_string == "*" else filter_string
            body = {
                "class": "ActivityStatusFilterRequestBody",
                "filter": filter_string,
                "activityStatusList": activity_status_list,
                "startFrom": start_from,
                "pageSize": page_size,
            }
            validated_body = ActivityStatusFilterRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str or len(elements) == 0:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != "JSON":
            return _gen_output(elements, filter_string, _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_activity_status_request(
        self,
        url: str,
        _type: str,
        _gen_output: Callable[..., Any],
        activity_status_list: Optional[list[str]] = None,
        start_from: int = 0,
        page_size: int = 0,
        limit_results_by_status: Optional[list[str]] = None,
        sequencing_order: Optional[str] = None,
        sequencing_property: Optional[str] = None,
        output_format: str = "JSON",
        report_spec: Optional[str | dict] = None,
        body: Optional[dict | ActivityStatusRequestBody] = None,
        **kwargs
    ) -> Any:
        if isinstance(body, ActivityStatusRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._activity_status_request_adapter.validate_python(body)
        else:
            body = {
                "class": "ActivityStatusRequestBody",
                "activityStatusList": activity_status_list,
                "startFrom": start_from,
                "pageSize": page_size,
                "limitResultsByStatus": limit_results_by_status,
                "sequencingOrder": sequencing_order,
                "sequencingProperty": sequencing_property,
            }
            validated_body = ActivityStatusRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != "JSON":
            return _gen_output(elements, "Members", _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_content_status_search_request(
        self,
        url: str,
        _type: str,
        _gen_output: Callable[..., Any],
        search_string: str,
        content_status_list: Optional[list[str]] = None,
        starts_with: bool = True,
        ends_with: bool = False,
        ignore_case: bool = False,
        anchor_domain: Optional[str] = None,
        metadata_element_type: Optional[str] = None,
        metadata_element_subtypes: Optional[list[str]] = None,
        skip_relationships: Optional[list[str]] = None,
        include_only_relationships: Optional[list[str]] = None,
        skip_classified_elements: Optional[list[str]] = None,
        include_only_classified_elements: Optional[list[str]] = None,
        graph_query_depth: int = 3,
        max_mermaid_node_count: int = 5,
        governance_zone_filter: Optional[list[str]] = None,
        as_of_time: Optional[str] = None,
        effective_time: Optional[str] = None,
        relationship_page_size: int = 0,
        limit_results_by_status: Optional[list[str]] = None,
        sequencing_order: Optional[str] = None,
        sequencing_property: Optional[str] = None,
        output_format: Optional[str] = None,
        report_spec: Optional[str | dict] = None,
        start_from: int = 0,
        page_size: int | None = 100,
        body: dict | ContentStatusSearchString | None = None,
        **kwargs
    ) -> Any:
        if isinstance(body, ContentStatusSearchString):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._content_status_search_request_adapter.validate_python(body)
        else:
            search_string = None if search_string == "*" else search_string
            if page_size is None:
                page_size = 0
            body = {
                "class": "ContentStatusSearchString",
                "searchString": search_string,
                "contentStatusList": content_status_list,
                "startWith": starts_with,
                "endWith": ends_with,
                "ignoreCase": ignore_case,
                "anchorDomain": anchor_domain,
                "zoneFilter": governance_zone_filter,
                "metadataElementTypeName": metadata_element_type,
                "metadataElementSubtypeNames": metadata_element_subtypes,
                "skipRelationships": skip_relationships,
                "includeOnlyRelationships": include_only_relationships,
                "relationshipPageSize": relationship_page_size,
                "skipClassifiedElements": skip_classified_elements,
                "includeOnlyClassifiedElements": include_only_classified_elements,
                "graphQueryDepth": graph_query_depth,
                "maxMermaidNodeCount": max_mermaid_node_count,
                "asOfTime": as_of_time,
                "effectiveTime": effective_time,
                "limitResultsByStatus": limit_results_by_status,
                "sequencingOrder": sequencing_order,
                "sequencingProperty": sequencing_property,
                "start_from": start_from,
                "pageSize": page_size,
            }
            validated_body = ContentStatusSearchString.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        response = await self._async_make_request("POST", url, json_body, time_out=90)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != "JSON":
            return _gen_output(elements, search_string, _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_content_status_filter_request(
        self,
        url: str,
        _type: str,
        _gen_output: Callable[..., Any],
        filter_string: str,
        content_status_list: Optional[list[str]] = None,
        start_from: int = 0,
        page_size: int = 0,
        output_format: str = "JSON",
        report_spec: Optional[str | dict] = None,
        body: Optional[dict | ContentStatusFilterRequestBody] = None,
        **kwargs
    ) -> Any:
        if isinstance(body, ContentStatusFilterRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._content_status_filter_request_adapter.validate_python(body)
        else:
            filter_string = None if filter_string == "*" else filter_string
            body = {
                "class": "ContentStatusFilterRequestBody",
                "filter": filter_string,
                "contentStatusList": content_status_list,
                "startFrom": start_from,
                "pageSize": page_size,
            }
            validated_body = ContentStatusFilterRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str or len(elements) == 0:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != "JSON":
            return _gen_output(elements, filter_string, _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_deployment_status_search_request(
        self,
        url: str,
        _type: str,
        _gen_output: Callable[..., Any],
        search_string: str,
        deployment_status_list: Optional[list[str]] = None,
        starts_with: bool = True,
        ends_with: bool = False,
        ignore_case: bool = False,
        anchor_domain: Optional[str] = None,
        metadata_element_type: Optional[str] = None,
        metadata_element_subtypes: Optional[list[str]] = None,
        skip_relationships: Optional[list[str]] = None,
        include_only_relationships: Optional[list[str]] = None,
        skip_classified_elements: Optional[list[str]] = None,
        include_only_classified_elements: Optional[list[str]] = None,
        graph_query_depth: int = 3,
        max_mermaid_node_count: int = 5,
        governance_zone_filter: Optional[list[str]] = None,
        as_of_time: Optional[str] = None,
        effective_time: Optional[str] = None,
        relationship_page_size: int = 0,
        limit_results_by_status: Optional[list[str]] = None,
        sequencing_order: Optional[str] = None,
        sequencing_property: Optional[str] = None,
        output_format: Optional[str] = None,
        report_spec: Optional[str | dict] = None,
        start_from: int = 0,
        page_size: int | None = 100,
        body: dict | DeploymentStatusSearchString | None = None,
    ) -> Any:
        if isinstance(body, DeploymentStatusSearchString):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._deployment_status_search_request_adapter.validate_python(body)
        else:
            search_string = None if search_string == "*" else search_string
            if page_size is None:
                page_size = 0
            body = {
                "class": "DeploymentStatusSearchString",
                "searchString": search_string,
                "deploymentStatusList": deployment_status_list,
                "startWith": starts_with,
                "endWith": ends_with,
                "ignoreCase": ignore_case,
                "anchorDomain": anchor_domain,
                "zoneFilter": governance_zone_filter,
                "metadataElementTypeName": metadata_element_type,
                "metadataElementSubtypeNames": metadata_element_subtypes,
                "skipRelationships": skip_relationships,
                "includeOnlyRelationships": include_only_relationships,
                "relationshipPageSize": relationship_page_size,
                "skipClassifiedElements": skip_classified_elements,
                "includeOnlyClassifiedElements": include_only_classified_elements,
                "graphQueryDepth": graph_query_depth,
                "maxMermaidNodeCount": max_mermaid_node_count,
                "asOfTime": as_of_time,
                "effectiveTime": effective_time,
                "limitResultsByStatus": limit_results_by_status,
                "sequencingOrder": sequencing_order,
                "sequencingProperty": sequencing_property,
                "start_from": start_from,
                "pageSize": page_size,
            }
            validated_body = DeploymentStatusSearchString.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        response = await self._async_make_request("POST", url, json_body, time_out=90)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != "JSON":
            return _gen_output(elements, search_string, _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_deployment_status_filter_request(
        self,
        url: str,
        _type: str,
        _gen_output: Callable[..., Any],
        filter_string: str,
        deployment_status_list: Optional[list[str]] = None,
        start_from: int = 0,
        page_size: int = 0,
        output_format: str = "JSON",
        report_spec: Optional[str | dict] = None,
        body: Optional[dict | DeploymentStatusFilterRequestBody] = None,
    ) -> Any:
        if isinstance(body, DeploymentStatusFilterRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._deployment_status_filter_request_adapter.validate_python(body)
        else:
            filter_string = None if filter_string == "*" else filter_string
            body = {
                "class": "DeploymentStatusFilterRequestBody",
                "filter": filter_string,
                "deploymentStatusList": deployment_status_list,
                "startFrom": start_from,
                "pageSize": page_size,
            }
            validated_body = DeploymentStatusFilterRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", NO_ELEMENTS_FOUND)
        if type(elements) is str or len(elements) == 0:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != "JSON":
            return _gen_output(elements, filter_string, _type, output_format, report_spec)
        return elements

    @dynamic_catch
    async def _async_get_results_body_request(self, url: str, _type: str, _gen_output: Callable[..., Any],
                                              start_from: int = 0, page_size: int = 0, output_format: str = 'JSON',
                                              report_spec: Optional[str | dict] = None,
                                              body: Optional[dict | ResultsRequestBody] = None,
                                              **kwargs) -> Any:
        """Handles request; returns elements or formatted output"""
        if isinstance(body, ResultsRequestBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._results_request_adapter.validate_python(body)
        else:
            body = {
                "class": "ResultsRequestBody",
                "metadataElementTypeName": _type,
                "start_from": start_from,
                "page_size": page_size,
            }
            validated_body = ResultsRequestBody.model_validate(body)

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)

        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", None)
        if elements is None:
            elements = response.json().get("element", NO_ELEMENTS_FOUND)

        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != 'JSON':  # return a simplified markdown representation
            logger.info(f"Found elements, output format: {output_format} and report_spec: {report_spec}")
            return _gen_output(elements=elements, filter_string="Members", element_type_name=_type,
                               output_format=output_format, report_spec=report_spec, **kwargs)
        return elements

    @dynamic_catch
    async def _async_get_level_identifier_query_body_request(self, url: str, _gen_output: Callable[..., Any],
                                                             output_format: str = 'JSON',
                                                             report_spec: Optional[str | dict] = None,
                                                             body: Optional[dict | ResultsRequestBody] = None,
                                                             **kwargs) -> Any:
        if isinstance(body, LevelIdentifierQueryBody):
            validated_body = body
        elif isinstance(body, dict):
            validated_body = self._level_identifier_query_body.validate_python(body)
        else:
            return None

        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)

        response = await self._async_make_request("POST", url, json_body)
        elements = response.json().get("elements", None)
        if elements is None:
            elements = response.json().get("element", NO_ELEMENTS_FOUND)

        if type(elements) is str:
            logger.info(NO_ELEMENTS_FOUND)
            return NO_ELEMENTS_FOUND

        if output_format.upper() != 'JSON':  # return a simplified markdown representation
            logger.info(f"Found elements, output format: {output_format} and report_spec: {report_spec}")
            return _gen_output(elements=elements, query_string="", entity_type="Referenceable",
                               output_format=output_format, report_spec=report_spec, **kwargs)
        return elements

    @dynamic_catch
    async def _async_create_attachment_body_request(self, url: str, prop: Optional[list[str]] = None,
                                                    body: Optional[dict | NewAttachmentRequestBody] = None) -> str:
        validated_body = self.validate_new_attachment_request(body, prop)
        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        logger.info(json_body)
        response = await self._async_make_request("POST", url, json_body)
        logger.info(response.json())
        return response.json().get("guid")

    @dynamic_catch
    async def _async_create_element_body_request(self, url: str, prop: Optional[list[str]] = None,
                                                 body: Optional[dict | NewElementRequestBody] = None) -> str:
        validated_body = self.validate_new_element_request(body, prop)
        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        logger.info(json_body)
        response = await self._async_make_request("POST", url, json_body, is_json=True)
        logger.info(response.json())
        return response.json().get("guid")

    @dynamic_catch
    async def _async_create_element_from_template(self, url: str, body: Optional[dict | TemplateRequestBody] = None) -> str:
        validated_body = self.validate_new_element_from_template_request(body)
        json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        logger.info(json_body)
        response = await self._async_make_request("POST", url, json_body, is_json=True)
        logger.info(response.json())
        return response.json().get("guid")

    @dynamic_catch
    async def _async_update_element_body_request(self, url: str, prop: Optional[list[str]] = None,
                                                 body: Optional[dict | UpdateElementRequestBody | UpdateClassificationRequestBody] = None) -> None:
        if isinstance(body,dict):
            json_body = body_slimmer(body)
        else:
            validated_body = self.validate_update_element_request(body, prop)
            json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
        logger.info(json_body)
        response = await self._async_make_request("POST", url, json_body, is_json=True)
        logger.info(response.json())

    # @dynamic_catch
    # async def _async_update_status_request(self, url: str, status: Optional[str] = None,
    #                                        body: Optional[dict | UpdateStatusRequestBody] = None) -> None:
    #     validated_body = self.validate_update_status_request(status, body)
    #     json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
    #     logger.info(json_body)
    #     response = await self._async_make_request("POST", url, json_body)
    #     logger.info(response.json())

    @dynamic_catch
    async def _async_new_relationship_request(self, url: str, prop: Optional[list[str]] = None,
                                              body: Optional[dict | NewRelationshipRequestBody] = None) -> None:
        validated_body = self.validate_new_relationship_request(body, prop)
        if validated_body:
            json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
            logger.info(json_body)
            await self._async_make_request("POST", url, json_body)
        else:
            if prop:
                prop_class = prop[0] if isinstance(prop, list) else prop
                body = {
                    "class": "NewRelationshipRequestBody",
                    "properties": {
                        "class": prop_class
                    }
                }
                await self._async_make_request("POST", url, body)
            else:
                await self._async_make_request("POST", url)

    @dynamic_catch
    async def _async_new_classification_request(self, url: str, prop: Optional[list[str]] = None,
                                                body: Optional[dict | NewClassificationRequestBody] = None) -> None:
        validated_body = self.validate_new_classification_request(body, prop)
        if validated_body:
            json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
            logger.info(json_body)
            await self._async_make_request("POST", url, json_body)
        else:
            await self._async_make_request("POST", url)

    @dynamic_catch
    async def _async_delete_element_request(self, url: str, body: Optional[dict | DeleteElementRequestBody] = None,
                                            cascade_delete: bool = False) -> None:
        if body:
            validated_body = self.validate_delete_element_request(body, cascade_delete)
            if validated_body:
                json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
                logger.info(json_body)
                await self._async_make_request("POST", url, json_body)
        else:
            await self._async_make_request("POST", url)

    @dynamic_catch
    async def _async_delete_relationship_request(self, url: str, body: Optional[dict | DeleteRelationshipRequestBody] = None,
                                                 cascade_delete: bool = False) -> None:
        if body:
            validated_body = self.validate_delete_relationship_request(body, cascade_delete)
            if validated_body:
                json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
                logger.info(json_body)
                await self._async_make_request("POST", url, json_body)
        else:
            await self._async_make_request("POST", url)

    @dynamic_catch
    async def _async_delete_classification_request(self, url: str, body: Optional[dict | DeleteClassificationRequestBody] = None,
                                                   cascade_delete: bool = False) -> None:
        validated_body = self.validate_delete_classification_request(body, cascade_delete)
        if validated_body:
            json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
            logger.info(json_body)
            await self._async_make_request("POST", url, json_body)
        else:
            await self._async_make_request("POST", url)

    @dynamic_catch
    async def _async_update_relationship_request(self, url: str, prop: Optional[list[str]] = None,
                                                 body: Optional[dict | UpdateRelationshipRequestBody] = None) -> None:
        validated_body = self.validate_update_relationship_request(body, prop)
        if validated_body:
            json_body = validated_body.model_dump_json(indent=2, exclude_none=True)
            logger.info(json_body)
            await self._async_make_request("POST", url, json_body)
        else:
            await self._async_make_request("POST", url)

    # @dynamic_catch
    # async def _async_update_element_status(self, guid: str, status: Optional[str] = None,
    #                                        body: Optional[dict | UpdateStatusRequestBody] = None) -> None:
    #     """ Update the status of an element. Async version.
    #
    #        Parameters
    #        ----------
    #        guid: str
    #            The guid of the element to update.
    #        status: str, optional
    #            The new lifecycle status for the element. Ignored, if the body is provided.
    #        body: dict | UpdateStatusRequestBody, optional
    #            A structure representing the details of the element status to update. If supplied, these details
    #            supersede the status parameter provided.
    #
    #        Returns
    #        -------
    #        Nothing
    #
    #        Raises
    #        ------
    #        PyegeriaException
    #        ValidationError
    #
    #        Notes
    #        -----
    #        JSON Structure looks like:
    #         {
    #          "class": "UpdateStatusRequestBody",
    #          "newStatus": "APPROVED",
    #          "externalSourceGUID": "add guid here",
    #          "externalSourceName": "add qualified name here",
    #          "effectiveTime": "{{$isoTimestamp}}",
    #          "forLineage": false,
    #          "forDuplicateProcessing": false
    #        }
    #        """
    #
    #     url = (f"{self.platform_url}/servers/{self.view_server}/api/open-metadata/"
    #            f"{self.url_marker}/metadata-elements/{guid}/update-status")
    #     await self._async_update_status_request(url, status, body)
    #
    # @dynamic_catch
    # def update_element_status(self, guid: str, status: Optional[str] = None,
    #                           body: Optional[dict | UpdateStatusRequestBody] = None) -> None:
    #     """ Update the status of an element. Async version.
    #
    #        Parameters
    #        ----------
    #        guid: str
    #            The guid of the element to update.
    #        status: str, optional
    #            The new lifecycle status for the element. Ignored, if the body is provided.
    #        body: dict | UpdateStatusRequestBody, optional
    #            A structure representing the details of the element status to update. If supplied, these details
    #            supersede the status parameter provided.
    #
    #        Returns
    #        -------
    #        Nothing
    #
    #        Raises
    #        ------
    #        PyegeriaException
    #        ValidationError
    #
    #        Notes
    #        -----
    #        JSON Structure looks like:
    #         {
    #          "class": "UpdateStatusRequestBody",
    #          "newStatus": "APPROVED",
    #          "externalSourceGUID": "add guid here",
    #          "externalSourceName": "add qualified name here",
    #          "effectiveTime": "{{$isoTimestamp}}",
    #          "forLineage": false,
    #          "forDuplicateProcessing": false
    #        }
    #        """
    #     loop = asyncio.get_event_loop()
    #     loop.run_until_complete(self._async_update_element_status(guid, status, body))

    @dynamic_catch
    async def _async_update_element_effectivity(self, guid: str, effectivity_time: Optional[str] = None,
                                                body: dict = None) -> None:
        """ Update the status of an element. Async version.

           Parameters
           ----------
           guid: str
               The guid of the element to update.
           effectivity_time: str, optional
               The new effectivity time for the element.
           body: dict, optional
               A structure representing the details of the effectivity time to update. If supplied, these details
                supersede the effectivity time parameter provided.

           Returns
           -------
           Nothing

           Raises
           ------
           PyegeriaException
           ValidationError

           Notes
           -----
           JSON Structure looks like:
            {
              "class" : "UpdateEffectivityDatesRequestBody",
              "externalSourceGUID" :  "",
              "externalSourceName" : "",
              "effectiveFrom" : "{{$isoTimestamp}}",
              "effectiveTo": "{{$isoTimestamp}}",
              "forLineage" : false,
              "forDuplicateProcessing" : false,
              "effectiveTime" : "{{$isoTimestamp}}"
            }
           """

        url = f"{self.command_root}/metadata-elements/{guid}/update-effectivity"
        if body is None:
            body = {
                "class": "UpdateEffectivityRequestBody",
                "effectiveTime": effectivity_time
            }
        logger.info(body)
        await self._async_make_request("POST", url, body)

    @dynamic_catch
    def update_element_effectivity(self, guid: str, status: Optional[str] = None,
                                   body: dict = None) -> None:
        """ Update the status of an element. Async version.

           Parameters
           ----------
           guid: str
               The guid of the element to update.
           effectivity_time: str, optional
               The new effectivity time for the element.
           body: dict, optional
               A structure representing the details of the effectivity time to update. If supplied, these details
                supersede the effectivity time parameter provided.

           Returns
           -------
           Nothing

           Raises
           ------
           PyegeriaException
           ValidationError

           Notes
           -----
           JSON Structure looks like:
            {
              "class" : "UpdateEffectivityDatesRequestBody",
              "externalSourceGUID" :  "",
              "externalSourceName" : "",
              "effectiveFrom" : "{{$isoTimestamp}}",
              "effectiveTo": "{{$isoTimestamp}}",
              "forLineage" : false,
              "forDuplicateProcessing" : false,
              "effectiveTime" : "{{$isoTimestamp}}"
            }
           """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self._async_update_element_status(guid, status, body))


    @dynamic_catch
    async def _async_create_asset(self, asset_type:list[str] = None, body: dict | NewElementRequestBody | None = None) -> str:
        """Create an asset. Async version.

        Parameters
        ----------
        asset_type: [str], optional
            The type of asset to create. If not provided, a generic asset type will be used.
        body: dict | NewElementRequestBody, optional
            A dict or NewElementRequestBody representing the details of the asset to create.

        Returns
        -------
        str - the guid of the created asset

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        ValidationError
            Pydantic validation errors are raised if the body does not conform to the NewElementRequestBody.

        Notes
        -----
        See: https://egeria-project.org/concepts/asset
        """
        if asset_type is None:
            asset_type = ["AssetProperties"]
        url = f"{self.command_root}asset-maker/assets"
        return await self._async_create_element_body_request(url, asset_type, body)

    @dynamic_catch
    def create_asset(self, asset_type: Optional[list[str]] = None, body: dict | NewElementRequestBody | None = None) -> str:
        """Create an asset.

        Parameters
        ----------
        asset_type: [str], optional
            The type of asset to create. If not provided, a generic asset type will be used.
        body: dict | NewElementRequestBody, optional
            A dict or NewElementRequestBody representing the details of the asset to create.

        Returns
        -------
        str - the guid of the created asset

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        ValidationError
            Pydantic validation errors are raised if the body does not conform to the NewElementRequestBody.

        Notes
        -----
        See: https://egeria-project.org/concepts/asset
        """
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._async_create_asset(asset_type, body))

    @dynamic_catch
    async def _async_create_asset_from_template(
        self, body: dict | TemplateRequestBody | None = None
    ) -> str:
        """Create a new metadata element to represent an asset using an existing metadata element as a template.
        The template defines additional classifications and relationships that should be added to the new element.
        Async version.

        Parameters
        ----------
        body: dict | TemplateRequestBody
            A dict or TemplateRequestBody representing the template details.

        Returns
        -------
        str - the guid of the created asset

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        ValidationError
            Pydantic validation errors are raised if the body does not conform to the TemplateRequestBody.
        """
        url = f"{self.command_root}asset-maker/assets/from-template"
        return await self._async_create_element_from_template(url, body)

    @dynamic_catch
    def create_asset_from_template(self, body: dict | TemplateRequestBody | None = None) -> str:
        """Create a new metadata element to represent an asset using an existing metadata element as a template.
        The template defines additional classifications and relationships that should be added to the new element.

        Parameters
        ----------
        body: dict | TemplateRequestBody
            A dict or TemplateRequestBody representing the template details.

        Returns
        -------
        str - the guid of the created asset

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        ValidationError
            Pydantic validation errors are raised if the body does not conform to the TemplateRequestBody.
        """
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._async_create_asset_from_template(body))

    @dynamic_catch
    async def _async_update_asset(
        self, asset_guid: str, body: dict | UpdateElementRequestBody | None = None
    ) -> None:
        """Update the properties of an asset. Async version.

        Parameters
        ----------
        asset_guid: str
            Unique identifier of the asset to update.
        body: dict | UpdateElementRequestBody
            A dict or UpdateElementRequestBody with the properties to update.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        ValidationError
            Pydantic validation errors are raised if the body does not conform to the UpdateElementRequestBody.
        """
        url = f"{self.command_root}asset-maker/assets/{asset_guid}/update"
        await self._async_update_element_body_request(url, ["AssetProperties"], body)

    @dynamic_catch
    def update_asset(
        self, asset_guid: str, body: dict | UpdateElementRequestBody | None = None
    ) -> None:
        """Update the properties of an asset.

        Parameters
        ----------
        asset_guid: str
            Unique identifier of the asset to update.
        body: dict | UpdateElementRequestBody
            A dict or UpdateElementRequestBody with the properties to update.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        ValidationError
            Pydantic validation errors are raised if the body does not conform to the UpdateElementRequestBody.
        """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self._async_update_asset(asset_guid, body))

    @dynamic_catch
    async def _async_delete_asset(
        self, asset_guid: str, body: dict | DeleteElementRequestBody | None = None
    ) -> None:
        """Delete an asset. Async version.

        Parameters
        ----------
        asset_guid: str
            Unique identifier of the asset to delete.
        body: dict | DeleteElementRequestBody, optional
            Additional parameters for the delete operation.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        """
        url = f"{self.command_root}asset-maker/assets/{asset_guid}/delete"
        await self._async_delete_element_request(url, body)

    @dynamic_catch
    def delete_asset(
        self, asset_guid: str, body: dict | DeleteElementRequestBody | None = None
    ) -> None:
        """Delete an asset.

        Parameters
        ----------
        asset_guid: str
            Unique identifier of the asset to delete.
        body: dict | DeleteElementRequestBody, optional
            Additional parameters for the delete operation.

        Returns
        -------
        None

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.
        """
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self._async_delete_asset(asset_guid, body))

    @dynamic_catch
    async def _async_find_assets(
            self,
            search_string: str = "*",
            body: dict | SearchStringRequestBody | None = None,
            starts_with: bool = False,
            ends_with: bool = False,
            ignore_case: bool = True,
            start_from: int = 0,
            page_size: int = 0,
            output_format: str = "DICT",
            report_spec: dict | str | None = None,
            **kwargs
    ) -> list | dict | str:
        """
        Retrieve the list of asset metadata elements that contain the search string. Async version.

        The search string is located in the request body and is interpreted as a plain string. The request parameters
        startsWith, endsWith and ignoreCase can be used to allow a fuzzy search. The request body also supports the
        specification of an effective time to restrict the search to elements that are/were effective at a particular time.

        Parameters
        ----------
        search_string : str, default "*"
            String to search for in asset properties.
        body : dict | SearchStringRequestBody, optional
            Details of the request. If provided, overrides other parameters.
        starts_with : bool, default False
            Whether to match only at the start of the string.
        ends_with : bool, default False
            Whether to match only at the end of the string.
        ignore_case : bool, default True
            Whether to ignore case in matching.
        start_from : int, default 0
            Index of the first result to return.
        page_size : int, default 0
            Maximum number of results to return (0 for server default).
        output_format : str, default "DICT"
            Format of the output.
        report_spec : dict | str, optional
            Specification for report formatting.
        **kwargs : dict, optional
            Additional parameters supported by the underlying find request:
            
            - anchor_domain : str - Domain to anchor the search
            - metadata_element_type : str - Specific metadata element type (e.g., "Asset")
            - metadata_element_subtypes : list[str] - List of metadata element subtypes
            - skip_relationships : list[str] - Relationship types to skip in graph traversal
            - include_only_relationships : list[str] - Only include these relationship types
            - skip_classified_elements : list[str] - Skip elements with these classifications
            - include_only_classified_elements : list[str] - Only include elements with these classifications
            - graph_query_depth : int - Depth of graph traversal (default 3)
            - governance_zone_filter : list[str] - Filter by governance zones
            - as_of_time : str - Historical query time (ISO 8601 format)
            - effective_time : str - Effective time for the query (ISO 8601 format)
            - relationship_page_size : int - Page size for relationships
            - limit_results_by_status : list[str] - Filter by element status (e.g., ["ACTIVE"])
            - sequencing_order : str - Order of results (e.g., "PROPERTY_ASCENDING")
            - sequencing_property : str - Property to sequence by
            - property_names : list[str] - Specific properties to search

        Returns
        -------
        list | dict | str
            List of matching assets in the specified format.

        Raises
        ------
        PyegeriaException
            If there are issues in communications, message format, or Egeria errors.

        Notes
        -----
        The **kwargs parameter allows advanced users to access all parameters supported by the
        underlying _async_find_request helper method. Common parameters are explicitly listed
        in the signature for discoverability, while advanced parameters can be passed via kwargs.
        
        This method is particularly useful for finding assets across the metadata repository.
        The graph_query_depth parameter controls how deep the relationship traversal goes,
        which can significantly impact performance and the amount of data returned.

        Examples
        --------
        Basic usage:
            >>> assets = await client._async_find_assets("customer", starts_with=True)
        
        Advanced usage with filtering:
            >>> assets = await client._async_find_assets(
            ...     "customer",
            ...     starts_with=True,
            ...     metadata_element_type="DataSet",
            ...     governance_zone_filter=["production"],
            ...     limit_results_by_status=["ACTIVE"],
            ...     graph_query_depth=2
            ... )
        
        Using effective time:
            >>> assets = await client._async_find_assets(
            ...     "customer",
            ...     effective_time="2024-01-01T00:00:00Z",
            ...     governance_zone_filter=["production"]
            ... )
        """
        url = f"{self.command_root}asset-maker/assets/by-search-string"

        # Build params dict with explicit parameters
        params = {
            'search_string': search_string,
            'starts_with': starts_with,
            'ends_with': ends_with,
            'ignore_case': ignore_case,
            'start_from': start_from,
            'page_size': page_size,
            'output_format': output_format,
            'report_spec': report_spec,
            'body': body
        }
        # Merge with any additional kwargs, removing None values
        params.update(kwargs)
        params = {k: v for k, v in params.items() if v is not None}
        
        return await self._async_find_request(url, _type="Asset", _gen_output=_generate_default_output, **params)

    @dynamic_catch
    def find_assets(self, search_string: str = "*", starts_with: bool = False, ends_with: bool = False,
                    ignore_case: bool = True, anchor_domain: Optional[str] = None, metadata_element_type: Optional[str] = None,
                    metadata_element_subtypes: Optional[list[str]] = None, skip_relationships: Optional[list[str]] = None,
                    include_only_relationships: Optional[list[str]] = None, skip_classified_elements: Optional[list[str]] = None,
                    include_only_classified_elements: Optional[list[str]] = None, graph_query_depth: int = 3,
                    governance_zone_filter: Optional[list[str]] = None, as_of_time: Optional[str] = None, effective_time: Optional[str] = None,
                    relationship_page_size: int = 0, limit_results_by_status: Optional[list[str]] = None,
                    sequencing_order: Optional[str] = None, sequencing_property: Optional[str] = None, output_format: str = "DICT",
                    report_spec: dict | str | None = None, start_from: int = 0, page_size: int = 0,
                    body: dict | SearchStringRequestBody | None = None) -> list | dict | str:
        """Retrieve the list of asset metadata elements that contain the search string.

        Parameters
        ----------
        search_string: str, optional
            String to search for in asset properties. Default is "*".
        starts_with: bool, optional
            Whether to match only at the start. Default is False.
        ends_with: bool, optional
            Whether to match only at the end. Default is False.
        ignore_case: bool, optional
            Whether to ignore case in matching. Default is True.
        start_from: int, optional
            Index of the first result to return. Default is 0.
        page_size: int, optional
            Maximum number of results to return. Default is None (server default).
        output_format: str, optional
            Format of the output. Default is "DICT".
        report_spec: dict | str, optional
            Specification for report formatting.
        body: dict | SearchStringRequestBody, optional
            Additional search parameters.

        Returns
        -------
        list | dict | str
            List of matching assets in the specified format.

        Raises
        ------
        PyegeriaException
            One of the pyegeria exceptions will be raised if there are issues in communications, message format, or
            Egeria errors.

        """
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            self._async_find_assets(search_string=search_string, starts_with=starts_with, ends_with=ends_with,
                                    ignore_case=ignore_case, anchor_domain=anchor_domain,
                                    metadata_element_type=metadata_element_type,
                                    metadata_element_subtypes=metadata_element_subtypes,
                                    skip_relationships=skip_relationships,
                                    include_only_relationships=include_only_relationships,
                                    skip_classified_elements=skip_classified_elements,
                                    include_only_classified_elements=include_only_classified_elements,
                                    graph_query_depth=graph_query_depth, governance_zone_filter=governance_zone_filter,
                                    as_of_time=as_of_time, effective_time=effective_time,
                                    relationship_page_size=relationship_page_size,
                                    limit_results_by_status=limit_results_by_status, sequencing_order=sequencing_order,
                                    sequencing_property=sequencing_property, output_format=output_format,
                                    report_spec=report_spec, start_from=start_from, page_size=page_size, body=body)
        )


    def _extract_referenceable_properties(self, element: dict, columns_struct: dict) -> dict:
        """Populate default Referenceable columns for output using common population pipeline."""
        return populate_common_columns(element, columns_struct)

    @dynamic_catch
    def _generate_referenceable_output(self, elements: dict | list[dict], search_string: Optional[str] = None,
                                       element_type_name: Optional[str] = None,
                                       output_format: str = "JSON",
                                       report_spec: dict | str = None,
                                       **kwargs) -> str | list[dict]:
        """Generate formatted output for generic Referenceable elements.

        If output_format is 'JSON', returns elements unchanged. Otherwise, resolves an
        output format set and delegates to generate_output with a standard extractor.
        """
        return self._generate_formatted_output(
            elements=elements,
            query_string=search_string,
            entity_type=element_type_name or "Referenceable",
            output_format=output_format,
            extract_properties_func=self._extract_referenceable_properties,
            report_spec=report_spec,
            **kwargs
        )

    def _extract_element_properties_for_keyword(self, element: dict, columns_struct: dict) -> dict:
        keyword_elements = None
        keyword_elements = element["keywordElements"]
        out_body = {}
        keyword = element["properties"].get('keyword', '')
        for el in keyword_elements:
            element = el.get("relatedElement", {})
            element_guid = element['elementHeader']['guid']
            element_type = element['elementHeader']['type']['typeName']
            element_display_name = element['properties'].get('displayName',"")
            element_description = element['properties'].get('description',"")
            element_category = element['properties'].get('category',"")
            out_body = {
                "element_display_name": element_display_name,
                "element_description": element_description,
                "element_category": element_category,
                "element_type": element_type,
                "element_guid": element_guid,
                "keyword": keyword
            }
        return out_body

    def _extract_element_properties_for_notes(self, element: dict, columns_struct: dict):
        note_log_qualified_name = None
        note_log_guid = None
        note_log_display_name = None
        note_log_description = None

        note_log_el = element.get("presentInNoteLogs",{})[0].get("relatedElement",None)
        if note_log_el:
            note_log_guid = note_log_el['elementHeader']['guid']
            note_log_display_name = note_log_el['properties'].get('displayName',"")
            note_log_qualified_name = note_log_el['properties']['qualifiedName']
            note_log_description = note_log_el['properties'].get('description',"")

        return {
            "note_log_name": note_log_display_name,
            "note_log_description": note_log_description,
            "note_log_qualified_name": note_log_qualified_name,
            "note_log_guid": note_log_guid,
        }

    def _extract_element_properties_for_note_logs(self, element: dict, columns_struct: dict):
        note_log_qualified_name = None
        note_log_guid = None
        note_log_display_name = None
        note_log_description = None

        note_log_el = element.get("presentInNoteLogs",{})[0].get("relatedElement",None)
        if note_log_el:
            note_log_guid = note_log_el['elementHeader']['guid']
            note_log_display_name = note_log_el['properties'].get('displayName',"")
            note_log_qualified_name = note_log_el['properties']['qualifiedName']
            note_log_description = note_log_el['properties'].get('description',"")

        return {
            "note_log_name": note_log_display_name,
            "note_log_description": note_log_description,
            "note_log_qualified_name": note_log_qualified_name,
            "note_log_guid": note_log_guid,
        }
