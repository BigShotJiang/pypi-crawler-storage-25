from pathlib import Path
import py_compile
import shutil

from isanic.cli import TEMPLATE_ROOT, init_project, main


def test_init_project_creates_full_template(tmp_path: Path) -> None:
    """测试初始化命令会生成完整项目结构。"""
    exit_code = init_project("demo", base_dir=tmp_path)
    project_dir = tmp_path / "demo"

    assert exit_code == 0
    assert (project_dir / "pyproject.toml").exists()
    assert (project_dir / "README.md").exists()
    assert (project_dir / ".gitignore").exists()
    assert (project_dir / "app" / "main.py").exists()
    assert (project_dir / "app" / "core" / "app.py").exists()
    assert (project_dir / "app" / "api" / "controllers" / "hello.py").exists()
    assert (project_dir / "app" / "api" / "schemas" / "login.py").exists()
    assert (project_dir / "tests" / "test_framework.py").exists()


def test_init_project_skips_template_pycache(tmp_path: Path) -> None:
    """测试安装后产生的模板缓存文件不会被复制。"""
    source_file = TEMPLATE_ROOT / "app" / "main.py"
    pycache_dir = source_file.parent / "__pycache__"

    try:
        py_compile.compile(str(source_file), doraise=True)
        exit_code = init_project("demo", base_dir=tmp_path)
    finally:
        if pycache_dir.exists():
            shutil.rmtree(pycache_dir)

    assert exit_code == 0
    assert not list((tmp_path / "demo").rglob("__pycache__"))
    assert not list((tmp_path / "demo").rglob("*.pyc"))


def test_init_project_renders_project_name(tmp_path: Path) -> None:
    """测试模板占位符会被替换为项目名。"""
    exit_code = init_project("demo", base_dir=tmp_path)
    project_dir = tmp_path / "demo"

    assert exit_code == 0
    assert 'name = "demo"' in (project_dir / "pyproject.toml").read_text(
        encoding="utf-8"
    )
    assert "demoTest" in (
        project_dir / "tests" / "test_framework.py"
    ).read_text(encoding="utf-8")


def test_init_project_rejects_non_empty_directory(tmp_path: Path) -> None:
    """测试非空目标目录会被拒绝。"""
    project_dir = tmp_path / "demo"
    project_dir.mkdir()
    (project_dir / "existing.txt").write_text("exists", encoding="utf-8")

    assert init_project("demo", base_dir=tmp_path) == 1


def test_init_project_rejects_invalid_name(tmp_path: Path) -> None:
    """测试非法项目名会被拒绝。"""
    assert init_project("../demo", base_dir=tmp_path) == 2


def test_cli_help_returns_success() -> None:
    """测试命令行帮助可以正常输出。"""
    try:
        main(["--help"])
    except SystemExit as exception:
        assert exception.code == 0
