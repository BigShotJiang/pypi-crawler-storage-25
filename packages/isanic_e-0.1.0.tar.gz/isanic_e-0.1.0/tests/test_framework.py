from sanic import Sanic

from app.core.app import create_app
from app.core.config import Settings


def make_app() -> Sanic:
    """创建测试应用。"""
    return create_app(Settings(app_name="iSanicTest"))


def test_hello_route_is_registered() -> None:
    """测试控制器方法自动注册为路由。"""
    _, response = make_app().test_client.get("/hello/test")

    assert response.status == 200
    assert response.json == {
        "code": 0,
        "message": "success",
        "data": {"message": "hello"},
    }


def test_json_body_is_validated_and_injected() -> None:
    """测试 JSON 请求体会被校验并注入表单对象。"""
    _, response = make_app().test_client.post(
        "/login/submit",
        json={"username": "alice", "password": "secret1"},
    )

    assert response.status == 200
    assert response.json["data"] == {"token": "token-for-alice"}


def test_form_data_is_validated_and_injected() -> None:
    """测试 form-data 会被校验并注入表单对象。"""
    _, response = make_app().test_client.post(
        "/login/submit",
        data={"username": "bob", "password": "secret2"},
    )

    assert response.status == 200
    assert response.json["data"] == {"token": "token-for-bob"}


def test_query_string_is_validated_and_injected() -> None:
    """测试查询字符串会被校验并注入表单对象。"""
    _, response = make_app().test_client.get("/users/list?page=2&size=20")

    assert response.status == 200
    assert response.json["data"] == {"page": 2, "size": 20}


def test_validation_error_returns_422() -> None:
    """测试表单校验失败会返回统一 422 响应。"""
    _, response = make_app().test_client.post(
        "/login/submit",
        json={"username": "a", "password": "bad"},
    )

    assert response.status == 422
    assert response.json["code"] == "VALIDATION_ERROR"
    assert response.json["message"] == "请求参数校验失败"
    assert {item["field"] for item in response.json["data"]} == {
        "username",
        "password",
    }


def test_app_error_returns_unified_response() -> None:
    """测试业务异常会返回统一错误响应。"""
    _, response = make_app().test_client.post(
        "/login/submit",
        json={"username": "disabled", "password": "secret1"},
    )

    assert response.status == 403
    assert response.json == {
        "code": "USER_DISABLED",
        "message": "用户已被禁用",
        "data": None,
    }


def test_http_response_is_not_wrapped_twice() -> None:
    """测试 Sanic 原生响应不会被二次包装。"""
    _, response = make_app().test_client.get("/users/raw")

    assert response.status == 200
    assert response.text == "raw response"


def test_not_found_returns_unified_response() -> None:
    """测试 404 会返回统一响应结构。"""
    _, response = make_app().test_client.get("/missing")

    assert response.status == 404
    assert response.json == {
        "code": "NOT_FOUND",
        "message": "接口不存在",
        "data": None,
    }
