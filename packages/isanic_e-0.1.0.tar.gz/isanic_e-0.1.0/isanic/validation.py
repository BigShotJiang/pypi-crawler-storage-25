import inspect
from collections.abc import Callable
from typing import Any, get_type_hints

from pydantic import BaseModel, ValidationError
from sanic import Request

from isanic.exceptions import ValidationAppError

BODY_METHODS = {"POST", "PUT", "PATCH"}
QUERY_METHODS = {"GET", "DELETE"}


class ValidationErrorResponse(BaseModel):
    """参数校验错误响应数据。"""

    field: str
    message: str
    type: str


class FormBinding(BaseModel):
    """控制器方法的表单绑定信息。"""

    parameter_name: str
    model_class: type[BaseModel]

    model_config = {"arbitrary_types_allowed": True}


def resolve_form_binding(handler: Callable[..., Any]) -> FormBinding | None:
    """从控制器方法签名中解析唯一表单参数。"""
    signature = inspect.signature(handler)
    type_hints = get_type_hints(handler)
    bindings: list[FormBinding] = []

    for name, parameter in signature.parameters.items():
        if name == "self":
            continue

        annotation = type_hints.get(name, parameter.annotation)
        if _is_pydantic_model(annotation):
            bindings.append(
                FormBinding(parameter_name=name, model_class=annotation)
            )

    if len(bindings) > 1:
        raise TypeError(f"{handler.__qualname__} 只允许声明一个表单模型参数")

    return bindings[0] if bindings else None


def build_form_model(request: Request, binding: FormBinding) -> BaseModel:
    """按 HTTP 方法提取请求数据并构建表单模型。"""
    payload = _extract_payload(request)
    try:
        return binding.model_class.model_validate(payload)
    except ValidationError as exception:
        raise ValidationAppError(_format_validation_errors(exception)) from exception


def _extract_payload(request: Request) -> dict[str, Any]:
    """从请求中提取待校验数据。"""
    method = request.method.upper()
    if method in QUERY_METHODS:
        return _mapping_to_dict(request.args)
    if method in BODY_METHODS:
        if _is_json_request(request):
            json_payload = request.json
            if isinstance(json_payload, dict):
                return json_payload
        return _mapping_to_dict(request.form)
    return {}


def _mapping_to_dict(mapping: Any) -> dict[str, Any]:
    """把 Sanic 的参数容器转换为普通字典。"""
    data: dict[str, Any] = {}
    for key, value in mapping.items():
        if isinstance(value, list) and len(value) == 1:
            data[key] = value[0]
        else:
            data[key] = value
    return data


def _format_validation_errors(error: ValidationError) -> list[dict[str, Any]]:
    """格式化 Pydantic 校验错误，避免泄露内部对象。"""
    errors: list[dict[str, Any]] = []
    for item in error.errors():
        errors.append(
            ValidationErrorResponse(
                field=".".join(str(part) for part in item["loc"]),
                message=item["msg"],
                type=item["type"],
            ).model_dump(mode="json")
        )
    return errors


def _is_json_request(request: Request) -> bool:
    """判断请求体是否声明为 JSON。"""
    content_type = request.headers.get("content-type", "")
    return "application/json" in content_type or content_type.endswith("+json")


def _is_pydantic_model(annotation: Any) -> bool:
    """判断注解是否为 Pydantic 模型类型。"""
    return inspect.isclass(annotation) and issubclass(annotation, BaseModel)
