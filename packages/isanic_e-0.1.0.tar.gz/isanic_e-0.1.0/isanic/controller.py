from typing import ClassVar

from sanic import Request


class ApiController:
    """控制器基类。"""

    prefix: ClassVar[str | None] = None
    request: Request

    def __init__(self, request: Request) -> None:
        self.request = request
