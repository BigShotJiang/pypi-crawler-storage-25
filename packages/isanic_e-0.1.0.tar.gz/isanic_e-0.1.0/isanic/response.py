from dataclasses import asdict, is_dataclass
from typing import Any, Generic, TypeAlias, TypeVar

from pydantic import BaseModel
from sanic.response import HTTPResponse, json

T = TypeVar("T")

JsonValue: TypeAlias = (
    dict[str, Any] | list[Any] | str | int | float | bool | None
)


class ApiResponse(Generic[T]):
    """统一响应结构的类型标记。"""

    code: int | str
    message: str
    data: T | None


def success(data: Any = None, message: str = "success", code: int = 0) -> HTTPResponse:
    """返回成功响应。"""
    return json(
        {
            "code": code,
            "message": message,
            "data": _to_jsonable(data),
        }
    )


def fail(
    code: int | str,
    message: str,
    data: Any = None,
    status: int = 400,
) -> HTTPResponse:
    """返回失败响应。"""
    return json(
        {
            "code": code,
            "message": message,
            "data": _to_jsonable(data),
        },
        status=status,
    )


def wrap_response(value: Any) -> HTTPResponse:
    """把业务返回值包装为统一响应。"""
    if isinstance(value, HTTPResponse):
        return value
    return success(value)


def _to_jsonable(value: Any) -> Any:
    """转换常见 Python 对象为可 JSON 序列化的数据。"""
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if is_dataclass(value) and not isinstance(value, type):
        return asdict(value)
    if isinstance(value, dict):
        return {key: _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, list | tuple | set):
        return [_to_jsonable(item) for item in value]
    return value
