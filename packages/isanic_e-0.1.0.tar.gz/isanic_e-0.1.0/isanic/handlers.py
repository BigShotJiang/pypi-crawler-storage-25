from sanic import Sanic
from sanic.exceptions import MethodNotAllowed, NotFound, SanicException

from isanic.exceptions import AppError
from isanic.response import fail


def setup_exception_handlers(app: Sanic) -> None:
    """注册全局异常处理器。"""

    @app.exception(AppError)
    async def handle_app_error(request, exception: AppError):
        return fail(
            exception.code,
            exception.message,
            exception.data,
            status=exception.status_code,
        )

    @app.exception(NotFound)
    async def handle_not_found(request, exception: NotFound):
        return fail("NOT_FOUND", "接口不存在", status=404)

    @app.exception(MethodNotAllowed)
    async def handle_method_not_allowed(request, exception: MethodNotAllowed):
        return fail("METHOD_NOT_ALLOWED", "请求方法不允许", status=405)

    @app.exception(Exception)
    async def handle_unknown_error(request, exception: Exception):
        if isinstance(exception, SanicException):
            status_code = exception.status_code or 500
            return fail(
                "HTTP_ERROR",
                str(exception) or "请求处理失败",
                status=status_code,
            )

        request.app.ctx.logger.exception("未捕获异常", exc_info=exception)
        return fail("INTERNAL_SERVER_ERROR", "服务器内部错误", status=500)
