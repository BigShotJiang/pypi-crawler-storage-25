import inspect
import pkgutil
import re
from collections.abc import Awaitable, Callable
from importlib import import_module
from types import ModuleType
from typing import Any, TypeAlias

from sanic import Request, Sanic
from sanic.response import HTTPResponse

from isanic.controller import ApiController
from isanic.response import wrap_response
from isanic.validation import build_form_model, resolve_form_binding

ControllerClass: TypeAlias = type[ApiController]
HandlerResult: TypeAlias = HTTPResponse | dict[str, Any] | list[Any] | str | int | float | bool | None
ControllerMethod: TypeAlias = Callable[..., Awaitable[HandlerResult]]

HTTP_METHODS = {"get", "post", "put", "patch", "delete"}
CONTROLLER_SUFFIX = "Controller"


def register_controllers(app: Sanic, package: str) -> None:
    """扫描指定包并注册所有控制器路由。"""
    root_module = import_module(package)
    for module in _walk_modules(root_module):
        for controller_class in _iter_controller_classes(module):
            _register_controller(app, controller_class)


def _walk_modules(root_module: ModuleType) -> list[ModuleType]:
    """递归加载包下所有模块。"""
    modules = [root_module]
    if not hasattr(root_module, "__path__"):
        return modules

    for module_info in pkgutil.walk_packages(
        root_module.__path__,
        prefix=f"{root_module.__name__}.",
    ):
        modules.append(import_module(module_info.name))
    return modules


def _iter_controller_classes(module: ModuleType) -> list[ControllerClass]:
    """查找模块中定义的控制器类。"""
    controllers: list[ControllerClass] = []
    for _, item in inspect.getmembers(module, inspect.isclass):
        if item is ApiController:
            continue
        if item.__module__ != module.__name__:
            continue
        if issubclass(item, ApiController):
            controllers.append(item)
    return controllers


def _register_controller(app: Sanic, controller_class: ControllerClass) -> None:
    """注册单个控制器上的所有 HTTP 方法。"""
    controller_prefix = _controller_prefix(controller_class)
    for route in _iter_routes(controller_class):
        uri = f"/{controller_prefix}/{route.path}".rstrip("/")
        app.add_route(
            _build_route_handler(controller_class, route.method_name),
            uri,
            methods=[route.http_method],
            name=f"{controller_class.__name__}.{route.method_name}",
        )


class RouteInfo:
    """控制器方法对应的路由信息。"""

    def __init__(self, http_method: str, method_name: str, path: str) -> None:
        self.http_method = http_method
        self.method_name = method_name
        self.path = path


def _iter_routes(controller_class: ControllerClass) -> list[RouteInfo]:
    """解析控制器类中的路由方法。"""
    routes: list[RouteInfo] = []
    for name, member in inspect.getmembers(controller_class, inspect.isfunction):
        http_method, path = _parse_route_method(name)
        if http_method is None or path is None:
            continue
        routes.append(RouteInfo(http_method, name, path))
    return routes


def _parse_route_method(name: str) -> tuple[str | None, str | None]:
    """把方法名解析为 HTTP 方法和路径。"""
    parts = name.split("_", 1)
    method = parts[0].lower()
    if method not in HTTP_METHODS:
        return None, None

    action = parts[1] if len(parts) > 1 else "index"
    return method.upper(), _to_kebab_case(action)


def _build_route_handler(
    controller_class: ControllerClass,
    method_name: str,
) -> Callable[[Request], Awaitable[HTTPResponse]]:
    """创建 Sanic 可识别的路由处理函数。"""
    controller_method = getattr(controller_class, method_name)
    form_binding = resolve_form_binding(controller_method)

    async def route_handler(request: Request) -> HTTPResponse:
        controller = controller_class(request)
        method = getattr(controller, method_name)
        if form_binding is None:
            result = await method()
        else:
            form = build_form_model(request, form_binding)
            result = await method(form)
        return wrap_response(result)

    route_handler.__name__ = f"{controller_class.__name__}_{method_name}"
    return route_handler


def _controller_prefix(controller_class: ControllerClass) -> str:
    """生成控制器路径前缀。"""
    if controller_class.prefix:
        return controller_class.prefix.strip("/")

    name = controller_class.__name__
    if name.endswith(CONTROLLER_SUFFIX):
        name = name[: -len(CONTROLLER_SUFFIX)]
    return _to_kebab_case(name)


def _to_kebab_case(value: str) -> str:
    """把类名或方法名片段转换为短横线命名。"""
    value = value.replace("_", "-")
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "-", value)
    value = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", "-", value)
    return value.lower()
