from typing import Any


class AppError(Exception):
    """业务异常基类。"""

    def __init__(
        self,
        message: str,
        *,
        code: int | str = "APP_ERROR",
        status_code: int = 400,
        data: Any = None,
    ) -> None:
        self.code = code
        self.message = message
        self.status_code = status_code
        self.data = data
        super().__init__(message)


class ValidationAppError(AppError):
    """请求参数校验失败。"""

    def __init__(self, errors: list[dict[str, Any]]) -> None:
        super().__init__(
            "请求参数校验失败",
            code="VALIDATION_ERROR",
            status_code=422,
            data=errors,
        )
