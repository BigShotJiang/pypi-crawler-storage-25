import argparse
import re
import shutil
import sys
from pathlib import Path

TEMPLATE_ROOT = Path(__file__).parent / "templates" / "full"
PROJECT_NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_-]*$")


def main(argv: list[str] | None = None) -> int:
    """命令行入口。"""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command == "init":
        return init_project(args.project_name)

    parser.print_help()
    return 0


def init_project(project_name: str, base_dir: Path | None = None) -> int:
    """初始化完整示例项目。"""
    if not PROJECT_NAME_PATTERN.fullmatch(project_name):
        print(
            "项目名只能包含字母、数字、短横线和下划线，并且必须以字母开头。",
            file=sys.stderr,
        )
        return 2

    root_dir = base_dir or Path.cwd()
    target_dir = root_dir / project_name
    if target_dir.exists() and any(target_dir.iterdir()):
        print(f"目标目录已存在且非空：{target_dir}", file=sys.stderr)
        return 1

    target_dir.mkdir(parents=True, exist_ok=True)
    _copy_template(TEMPLATE_ROOT, target_dir, project_name)
    _print_success(project_name)
    return 0


def _build_parser() -> argparse.ArgumentParser:
    """构建命令行参数解析器。"""
    parser = argparse.ArgumentParser(
        prog="isanic",
        description="iSanic-e 项目脚手架",
    )
    subparsers = parser.add_subparsers(dest="command")

    init_parser = subparsers.add_parser("init", help="初始化一个 Sanic 项目")
    init_parser.add_argument("project_name", help="要创建的项目目录名")
    return parser


def _copy_template(source_dir: Path, target_dir: Path, project_name: str) -> None:
    """递归复制模板文件到目标目录。"""
    for source_path in source_dir.rglob("*"):
        if _should_skip_template_path(source_path):
            continue

        relative_path = source_path.relative_to(source_dir)
        target_path = target_dir / _render_text(str(relative_path), project_name)

        if source_path.is_dir():
            target_path.mkdir(parents=True, exist_ok=True)
            continue

        target_path.parent.mkdir(parents=True, exist_ok=True)
        text = source_path.read_text(encoding="utf-8")
        target_path.write_text(_render_text(text, project_name), encoding="utf-8")

    gitignore_template = target_dir / "_gitignore"
    if gitignore_template.exists():
        shutil.move(str(gitignore_template), str(target_dir / ".gitignore"))


def _should_skip_template_path(path: Path) -> bool:
    """跳过安装后自动生成的缓存文件。"""
    if "__pycache__" in path.parts:
        return True
    return path.suffix in {".pyc", ".pyo"}


def _render_text(value: str, project_name: str) -> str:
    """替换模板中的占位符。"""
    return value.replace("{{ project_name }}", project_name)


def _print_success(project_name: str) -> None:
    """输出初始化成功提示。"""
    print(f"项目已创建：{project_name}")
    print("")
    print("下一步：")
    print(f"  cd {project_name}")
    print('  python -m pip install -e ".[dev]"')
    print("  python -m pytest")
    print("  python -m app.main")


if __name__ == "__main__":
    raise SystemExit(main())
