from pydantic import BaseModel, Field


class LoginForm(BaseModel):
    """登录表单。"""

    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=6, max_length=128)


class UserQueryForm(BaseModel):
    """用户列表查询表单。"""

    page: int = Field(default=1, ge=1)
    size: int = Field(default=10, ge=1, le=100)
