from isanic import ApiController


class Hello(ApiController):
    """示例控制器。"""

    async def get_test(self) -> dict[str, str]:
        """测试接口。"""
        return {"message": "hello"}
