from sanic.response import text

from app.api.schemas.login import LoginForm, UserQueryForm
from isanic import ApiController, AppError


class Login(ApiController):
    """登录控制器。"""

    async def post_submit(self, form: LoginForm) -> dict[str, str]:
        """提交登录表单。"""
        if form.username == "disabled":
            raise AppError("用户已被禁用", code="USER_DISABLED", status_code=403)
        return {"token": f"token-for-{form.username}"}


class UserProfile(ApiController):
    """用户资料控制器。"""

    prefix = "users"

    async def get_list(self, form: UserQueryForm) -> dict[str, int]:
        """查询用户列表。"""
        return {"page": form.page, "size": form.size}

    async def get_raw(self):
        """直接返回 Sanic 原生响应。"""
        return text("raw response")
