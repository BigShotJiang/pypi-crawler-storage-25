import logging


def configure_logging(debug: bool) -> logging.Logger:
    """配置应用日志。"""
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )
    return logging.getLogger("{{ project_name }}")
