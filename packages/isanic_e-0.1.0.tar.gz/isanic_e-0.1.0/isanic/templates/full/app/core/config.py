from dataclasses import dataclass
import os


@dataclass(frozen=True, slots=True)
class Settings:
    """应用运行配置。"""

    app_name: str = "{{ project_name }}"
    host: str = "127.0.0.1"
    port: int = 8000
    debug: bool = False
    auto_reload: bool = False
    controllers_package: str = "app.api.controllers"


def load_settings() -> Settings:
    """从环境变量加载配置。"""
    return Settings(
        app_name=os.getenv("APP_NAME", "{{ project_name }}"),
        host=os.getenv("APP_HOST", "127.0.0.1"),
        port=int(os.getenv("APP_PORT", "8000")),
        debug=_to_bool(os.getenv("APP_DEBUG"), default=False),
        auto_reload=_to_bool(os.getenv("APP_AUTO_RELOAD"), default=False),
        controllers_package=os.getenv(
            "APP_CONTROLLERS_PACKAGE",
            "app.api.controllers",
        ),
    )


def _to_bool(value: str | None, *, default: bool) -> bool:
    """把环境变量字符串转换为布尔值。"""
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}
