from sanic import Sanic

from app.core.config import Settings, load_settings
from app.core.logging import configure_logging
from isanic import register_controllers, setup_exception_handlers


def create_app(settings: Settings | None = None) -> Sanic:
    """创建 Sanic 应用实例。"""
    resolved_settings = settings or load_settings()
    app = Sanic(resolved_settings.app_name)
    app.ctx.settings = resolved_settings
    app.ctx.logger = configure_logging(resolved_settings.debug)

    setup_exception_handlers(app)
    register_controllers(app, resolved_settings.controllers_package)
    return app
