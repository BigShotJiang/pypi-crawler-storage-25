from app.core.app import create_app
from app.core.config import load_settings

settings = load_settings()
app = create_app(settings)


if __name__ == "__main__":
    app.run(
        host=settings.host,
        port=settings.port,
        debug=settings.debug,
        auto_reload=settings.auto_reload,
    )
