# {{ project_name }}

这是通过 `isanic init` 生成的 Sanic 后端项目。

## 快速开始

安装依赖：

```bash
python -m pip install -e ".[dev]"
```

运行测试：

```bash
python -m pytest
```

启动服务：

```bash
python -m app.main
```

示例接口：

```text
GET  /hello/test
POST /login/submit
GET  /users/list?page=1&size=10
GET  /users/raw
```
