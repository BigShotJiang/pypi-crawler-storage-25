# iSanic-e

基于 Sanic 的类型化表单验证后端脚手架。

安装后可以通过 `isanic init` 快速生成一个完整可运行的 Sanic 项目，内置：

- 控制器自动路由注册
- Pydantic v2 表单验证
- 统一成功和错误响应
- 全局异常处理
- 示例控制器、表单模型和测试

## 安装

```bash
python -m pip install isanic-e
```

## 初始化项目

```bash
isanic init demo
cd demo
python -m pip install -e ".[dev]"
python -m pytest
python -m app.main
```

## 控制器示例

```python
from app.api.schemas.login import LoginForm
from isanic import ApiController


class Login(ApiController):
    async def post_submit(self, form: LoginForm) -> dict[str, str]:
        return {"token": f"token-for-{form.username}"}
```

上面的代码会自动注册为：

```text
POST /login/submit
```

## 业务异常

```python
from isanic import AppError

raise AppError("用户已被禁用", code="USER_DISABLED", status_code=403)
```

返回：

```json
{
  "code": "USER_DISABLED",
  "message": "用户已被禁用",
  "data": null
}
```
