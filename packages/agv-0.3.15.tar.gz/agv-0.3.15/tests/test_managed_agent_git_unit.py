"""Offline unit tests for the git helper — asserts shell-escape guarantees.

The helper's contract is that every string argument (URL, path, branch,
commit message, identity) reaches the sandbox through ``shlex.quote`` or
``git`` argv — never raw. This file exercises the rendered command string
with a fake sandbox API so we can prove the escaping without needing a
live sandbox.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import pytest

from agentenv.api.managed_agent_git import (
    GitCommandError,
    ManagedAgentGit,
)
from agentenv.api.models import SandboxExecResult


@dataclass
class _Calls:
    commands: List[str] = field(default_factory=list)


class _FakeSandboxAPI:
    def __init__(self) -> None:
        self.calls = _Calls()
        self.next_exit = 0
        self.next_output = ""

    def exec(self, sandbox_id: str, command: str) -> SandboxExecResult:  # noqa: D401
        self.calls.commands.append(command)
        return SandboxExecResult(
            execId="mock",
            output=self.next_output,
            exitCode=self.next_exit,
        )


class _FakeManagedAgentAPI:
    def get(self, agent_id: str):
        class _A:
            sandbox_id = "sb-1"

        return _A()


@pytest.fixture()
def fake():
    sandbox = _FakeSandboxAPI()
    managed = _FakeManagedAgentAPI()
    git = ManagedAgentGit(
        "agent-1", sandbox_api=sandbox, managed_agent_api=managed, cwd="/workspace"
    )
    return git, sandbox


def test_exec_wraps_cd_and_quotes_cwd(fake):
    git, sandbox = fake
    git.exec("git status")
    assert sandbox.calls.commands == ["cd /workspace && git status"]


def test_cwd_with_spaces_is_quoted(fake):
    git, sandbox = fake
    git.exec("git status", cwd="/some path/with spaces")
    assert sandbox.calls.commands == [
        "cd '/some path/with spaces' && git status"
    ]


def test_commit_message_with_injection_is_safe(fake):
    git, sandbox = fake
    git.commit("oops; rm -rf /", cwd="/tmp/repo")
    cmd = sandbox.calls.commands[0]
    # The injection payload must be wrapped inside a single-quoted arg to git,
    # not executed as a shell command.
    assert "git commit -m 'oops; rm -rf /'" in cmd
    assert "rm -rf /" not in cmd.split("'oops; rm -rf /'")[0]


def test_clone_url_and_path_with_special_chars(fake):
    git, sandbox = fake
    git.clone(
        "https://example.com/org/repo.git",
        path="/tmp/has space/checkout",
        branch="feature/x",
    )
    cmd = sandbox.calls.commands[0]
    # Only the path needs quoting — shlex leaves safe chars alone.
    assert "git clone --branch feature/x https://example.com/org/repo.git '/tmp/has space/checkout'" in cmd


def test_clone_branch_with_shell_meta_is_quoted(fake):
    git, sandbox = fake
    git.clone("https://example.com/org/repo.git", branch="a;b")
    cmd = sandbox.calls.commands[0]
    assert "--branch 'a;b'" in cmd


def test_configure_identity_scope_validation(fake):
    git, _ = fake
    with pytest.raises(ValueError, match="scope must be one of"):
        git.configure_identity(name="x", email="y@z", scope="bogus")


def test_failed_command_raises_git_command_error(fake):
    git, sandbox = fake
    sandbox.next_exit = 128
    sandbox.next_output = "fatal: not a git repository"
    with pytest.raises(GitCommandError) as ei:
        git.status()
    assert ei.value.exit_code == 128
    assert "not a git repository" in ei.value.output


def test_diff_tolerates_exit_code_1(fake):
    git, sandbox = fake
    sandbox.next_exit = 1
    sandbox.next_output = "+foo"
    # git diff returns 1 when there IS a diff — helper must not raise.
    assert git.diff() == "+foo"


def test_status_parses_porcelain_v1(fake):
    git, sandbox = fake
    sandbox.next_exit = 0
    sandbox.next_output = (
        "?? new.txt\n"
        " M changed.txt\n"
        "M  staged.txt\n"
    )
    entries = git.status()
    assert [(e.status, e.path) for e in entries] == [
        ("??", "new.txt"),
        (" M", "changed.txt"),
        ("M ", "staged.txt"),
    ]


def test_log_parses_fields_with_x1f_separator(fake):
    git, sandbox = fake
    sandbox.next_exit = 0
    sandbox.next_output = (
        "aaa\x1fAlice <a@example.com>\x1fhello\n"
        "bbb\x1fBob <b@example.com>\x1fworld; stuff\n"
    )
    rows = git.log(max_count=2)
    assert rows == [
        {"sha": "aaa", "author": "Alice <a@example.com>", "subject": "hello"},
        {"sha": "bbb", "author": "Bob <b@example.com>", "subject": "world; stuff"},
    ]


def test_store_credentials_requires_http(fake):
    git, _ = fake
    with pytest.raises(ValueError, match="http"):
        git.store_credentials(
            url="git@github.com:foo/bar.git", username="u", password="p"
        )


def test_force_push_uses_force_with_lease(fake):
    git, sandbox = fake
    git.push(branch="main", force=True, cwd="/tmp/repo")
    cmd = sandbox.calls.commands[0]
    assert "--force-with-lease" in cmd
    assert "--force " not in cmd  # bare --force not used
