"""Tests for AI Gateway models."""

import pytest
from datetime import datetime
from agentenv.api.models import (
    Sandbox,
    PortMapping,
    GatewayUpstream,
    GatewayPool,
    GatewayApiKey,
    ChatCompletionRequest,
    ChatCompletionResponse,
    Message,
    Choice,
    Usage,
)


def test_gateway_upstream_creation():
    """Test GatewayUpstream model."""
    upstream = GatewayUpstream(
        id="up_123",
        name="OpenAI Prod",
        provider="openai",
        base_url="https://api.openai.com",
        is_active=True,
        rate_limit_rpm=1000,
        created_at=datetime.now(),
    )
    assert upstream.id == "up_123"
    assert upstream.provider == "openai"
    assert upstream.provider_type == "openai"


def test_gateway_upstream_parses_current_backend_shape():
    """GatewayUpstream should parse the current backend response contract."""
    upstream = GatewayUpstream(
        id="up_123",
        name="OpenAI Compatible",
        userId="user_123",
        providerType="openai-api",
        credentials={
            "baseUrl": "https://proxy.example/v1",
            "defaultModel": "gpt-5.4",
            "preferredOpenAIEndpoint": "responses",
            "supportedModels": ["gpt-5.4"],
        },
        rateLimitStatus={},
        isActive=True,
        isSystemManaged=True,
        builtinKey="builtin-openai-compatible",
        createdAt=datetime.now().isoformat(),
        updatedAt=datetime.now().isoformat(),
    )

    assert upstream.provider_type == "openai-api"
    assert upstream.provider == "openai-api"
    assert upstream.base_url == "https://proxy.example/v1"
    assert upstream.is_system_managed is True
    assert upstream.builtin_key == "builtin-openai-compatible"


def test_chat_completion_request():
    """Test ChatCompletionRequest model."""
    request = ChatCompletionRequest(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        temperature=0.7,
        stream=True,
    )
    assert request.model == "gpt-4"
    assert request.temperature == 0.7
    assert request.stream is True


def test_sandbox_allows_snapshot_only_config_without_image():
    """Sandbox model should parse restore responses that only include snapshotId."""
    sandbox = Sandbox(
        id="sb_123",
        name="restored",
        status="running",
        workspaceId="ws_123",
        config={
            "snapshotId": "snap_123",
            "cpuMillis": 2000,
            "memoryMb": 2048,
        },
        metadata={
            "createdAt": "2026-04-19T00:00:00Z",
            "startedAt": "2026-04-19T00:00:01Z",
        },
        createdAt="2026-04-19T00:00:00Z",
        updatedAt="2026-04-19T00:00:01Z",
    )

    assert sandbox.config.image is None
    assert sandbox.config.snapshot_id == "snap_123"


def test_port_mapping_allows_public_url_without_host_port():
    """Public port responses intentionally hide raw hypervisor host ports."""
    mapping = PortMapping(
        containerPort=9223,
        protocol="ws",
        publicUrl="https://9223-sandbox.proxy.example",
    )

    assert mapping.host_port is None
    assert mapping.container_port == 9223
    assert mapping.public_url == "https://9223-sandbox.proxy.example"
