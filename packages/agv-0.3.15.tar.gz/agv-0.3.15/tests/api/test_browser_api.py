"""Tests for browser API client."""

from unittest.mock import Mock

import pytest

from agentenv.api.browser import BrowserAPI


def _mock_response(payload):
    response = Mock()
    response.json.return_value = payload
    return response


@pytest.fixture
def mock_client():
    """Create a mock API client."""
    return Mock()


@pytest.fixture
def browser_api(mock_client):
    """Create BrowserAPI with a mock client."""
    return BrowserAPI(mock_client)


def test_create_browser_uses_current_session_dto(browser_api, mock_client):
    """Browser create should send the current browser session DTO fields."""
    mock_client.post.return_value = _mock_response({
        "id": "br-1",
        "name": "browser-demo",
        "status": "starting",
        "cdpUrl": "wss://example.com/devtools",
        "createdAt": "2024-01-01T00:00:00Z",
    })

    session = browser_api.create(
        name="browser-demo",
        workspace_id="wk-1",
        screen_width=1440,
        screen_height=900,
        enable_stealth=True,
        enable_adblock=True,
        profile_mode="persistent",
        profile_id="profile-1",
        proxy_url="http://proxy.example:8080",
        proxy_provider="brightdata",
        proxy_type="residential",
        enable_captcha_solver=True,
        captcha_provider="capsolver",
        captcha_api_key="secret",
        enable_rrweb=True,
        enable_logger=True,
        cpu_millis=2000,
        memory_mb=4096,
        max_lifetime_seconds=1800,
        gpu_type="A100",
        geonode_proxy={
            "enabled": True,
            "mode": "whitelist",
            "domains": ["*.example.com"],
        },
    )

    assert session.id == "br-1"
    mock_client.post.assert_called_once_with(
        "/v1/browser/sessions",
        json={
            "name": "browser-demo",
            "workspaceId": "wk-1",
            "screenWidth": 1440,
            "screenHeight": 900,
            "enableStealth": True,
            "enableAdblock": True,
            "profileMode": "persistent",
            "profileId": "profile-1",
            "proxyUrl": "http://proxy.example:8080",
            "proxyProvider": "brightdata",
            "proxyType": "residential",
            "enableCaptchaSolver": True,
            "captchaProvider": "capsolver",
            "captchaApiKey": "secret",
            "enableRrweb": True,
            "enableLogger": True,
            "cpuMillis": 2000,
            "memoryMb": 4096,
            "maxLifetimeSeconds": 1800,
            "gpuType": "A100",
            "geonodeProxy": {
                "enabled": True,
                "mode": "whitelist",
                "domains": ["*.example.com"],
            },
        },
    )


def test_list_browsers_can_filter_by_workspace(browser_api, mock_client):
    """Browser list should pass workspaceId when requested."""
    mock_client.get.return_value = _mock_response([])

    browser_api.list_all(workspace_id="wk-1")

    mock_client.get.assert_called_once_with(
        "/v1/browser/sessions",
        params={"workspaceId": "wk-1"},
    )


def test_list_browsers_can_filter_by_status(browser_api, mock_client):
    """Browser list should pass status when requested."""
    mock_client.get.return_value = _mock_response([])

    browser_api.list_all(status="running")

    mock_client.get.assert_called_once_with(
        "/v1/browser/sessions",
        params={"status": "running"},
    )


def test_get_browser_fetches_session_details(browser_api, mock_client):
    """Browser get should fetch a single session."""
    mock_client.get.return_value = _mock_response({
        "id": "br-1",
        "name": "browser-demo",
        "status": "running",
        "createdAt": "2024-01-01T00:00:00Z",
    })

    session = browser_api.get("br-1")

    assert session.id == "br-1"
    mock_client.get.assert_called_once_with("/v1/browser/sessions/br-1")


def test_stop_browser_updates_session_state(browser_api, mock_client):
    """Browser stop should call the stop endpoint."""
    mock_client.put.return_value = _mock_response({
        "id": "br-1",
        "name": "browser-demo",
        "status": "stopped",
        "createdAt": "2024-01-01T00:00:00Z",
    })

    session = browser_api.stop("br-1")

    assert session.status == "stopped"
    mock_client.put.assert_called_once_with("/v1/browser/sessions/br-1/stop")


def test_delete_browser_calls_delete_endpoint(browser_api, mock_client):
    """Browser delete should call the delete endpoint."""
    browser_api.delete("br-1")

    mock_client.delete.assert_called_once_with("/v1/browser/sessions/br-1")


def test_get_cdp_url_returns_cdp_url(browser_api, mock_client):
    """CDP URL lookup should read the cdpUrl field."""
    mock_client.get.return_value = _mock_response({"cdpUrl": "wss://example.com/devtools"})

    url = browser_api.get_cdp_url("br-1")

    assert url == "wss://example.com/devtools"
    mock_client.get.assert_called_once_with("/v1/browser/sessions/br-1/cdp-url")


def test_browser_logs_returns_formatted_entries(browser_api, mock_client):
    """Browser logs should flatten entry payloads for CLI-friendly output."""
    mock_client.get.return_value = _mock_response({
        "entries": [
            {"timestamp": "2024-01-01T00:00:00Z", "message": "Session started"},
            {"message": "Connected"},
        ]
    })

    output = browser_api.logs("br-1", limit=10)

    assert output == "2024-01-01T00:00:00Z Session started\nConnected"
    mock_client.get.assert_called_once_with(
        "/v1/browser/sessions/br-1/logs",
        params={"limit": 10},
    )


def test_browser_logs_can_return_raw_payload(browser_api, mock_client):
    """Browser logs should preserve the raw payload for JSON output callers."""
    payload = {"entries": [{"message": "Connected"}]}
    mock_client.get.return_value = _mock_response(payload)

    output = browser_api.logs("br-1", raw=True)

    assert output == payload


def test_get_recording_status_returns_payload(browser_api, mock_client):
    """Recording status should return the API payload unchanged."""
    payload = {"status": "recording", "eventCount": 42}
    mock_client.get.return_value = _mock_response(payload)

    status = browser_api.get_recording_status("br-1")

    assert status == payload
    mock_client.get.assert_called_once_with("/v1/browser/sessions/br-1/recording-status")


def test_wait_for_status_returns_running_session(browser_api, mock_client, monkeypatch):
    """wait_for_status should stop polling once the desired state is reached."""
    mock_client.get.side_effect = [
        _mock_response({
            "id": "br-1",
            "name": "browser-demo",
            "status": "starting",
            "createdAt": "2024-01-01T00:00:00Z",
        }),
        _mock_response({
            "id": "br-1",
            "name": "browser-demo",
            "status": "running",
            "createdAt": "2024-01-01T00:00:00Z",
        }),
    ]
    monkeypatch.setattr("time.sleep", lambda _: None)

    session = browser_api.wait_for_status("br-1", timeout=1, interval=0)

    assert session.status == "running"
    assert mock_client.get.call_count == 2


def test_wait_for_status_raises_when_session_stops(browser_api, mock_client, monkeypatch):
    """wait_for_status should fail fast when the session stops."""
    mock_client.get.return_value = _mock_response({
        "id": "br-1",
        "name": "browser-demo",
        "status": "stopped",
        "createdAt": "2024-01-01T00:00:00Z",
    })
    monkeypatch.setattr("time.sleep", lambda _: None)

    with pytest.raises(RuntimeError, match="Browser session br-1 stopped"):
        browser_api.wait_for_status("br-1", timeout=1, interval=0)


def test_wait_for_status_times_out(browser_api, mock_client, monkeypatch):
    """wait_for_status should raise TimeoutError after the timeout expires."""
    mock_client.get.return_value = _mock_response({
        "id": "br-1",
        "name": "browser-demo",
        "status": "starting",
        "createdAt": "2024-01-01T00:00:00Z",
    })
    times = iter([0.0, 0.6, 1.2])
    monkeypatch.setattr("time.time", lambda: next(times))
    monkeypatch.setattr("time.sleep", lambda _: None)

    with pytest.raises(TimeoutError, match="Timeout waiting for browser session br-1 to start"):
        browser_api.wait_for_status("br-1", timeout=1, interval=0.5)


def test_create_profile_posts_expected_payload(browser_api, mock_client):
    """Browser profile create should post to the profile endpoint."""
    mock_client.post.return_value = _mock_response({
        "id": "profile-1",
        "workspaceId": "wk-1",
        "name": "Research",
        "description": "Saved state",
        "chromeUserDataDir": "/tmp/profile",
        "isActive": True,
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    })

    profile = browser_api.create_profile(
        name="Research",
        workspace_id="wk-1",
        description="Saved state",
    )

    assert profile["id"] == "profile-1"
    mock_client.post.assert_called_once_with(
        "/browser-profiles",
        json={"name": "Research", "description": "Saved state"},
        params={"workspaceId": "wk-1"},
    )


def test_list_profiles_can_filter_by_workspace(browser_api, mock_client):
    """Browser profile list should pass workspaceId when requested."""
    mock_client.get.return_value = _mock_response([])

    browser_api.list_profiles(workspace_id="wk-1")

    mock_client.get.assert_called_once_with(
        "/browser-profiles",
        params={"workspaceId": "wk-1"},
    )


def test_get_profile_fetches_profile(browser_api, mock_client):
    """Browser profile inspect should call the profile endpoint."""
    mock_client.get.return_value = _mock_response({
        "id": "profile-1",
        "workspaceId": "wk-1",
        "name": "Research",
        "description": None,
        "chromeUserDataDir": "/tmp/profile",
        "isActive": True,
        "createdAt": "2024-01-01T00:00:00Z",
        "updatedAt": "2024-01-01T00:00:00Z",
    })

    profile = browser_api.get_profile("profile-1", workspace_id="wk-1")

    assert profile["name"] == "Research"
    mock_client.get.assert_called_once_with(
        "/browser-profiles/profile-1",
        params={"workspaceId": "wk-1"},
    )


def test_delete_profile_calls_delete_endpoint(browser_api, mock_client):
    """Browser profile delete should call the profile delete endpoint."""
    browser_api.delete_profile("profile-1", workspace_id="wk-1")

    mock_client.delete.assert_called_once_with(
        "/browser-profiles/profile-1",
        params={"workspaceId": "wk-1"},
    )
