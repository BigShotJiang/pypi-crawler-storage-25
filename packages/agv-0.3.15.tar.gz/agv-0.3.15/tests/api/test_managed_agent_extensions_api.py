"""Tests for managed-agent extensions API wrappers."""

from __future__ import annotations

from io import BytesIO
from unittest.mock import Mock

import pytest

from agentenv.api.extensions import ManagedAgentExtensionsAPI


def _mock_response(payload):
    response = Mock()
    response.json.return_value = payload
    response.content = b"body"
    return response


def _skill_payload(**overrides):
    payload = {
        "id": "skill_123",
        "name": "Review Skill",
        "slug": "review-skill",
        "workspaceId": "wk_123",
        "sha256": "a" * 64,
        "assignments": [{"agentId": "agent_123", "enabled": True}],
        "createdAt": "2026-05-09T00:00:00Z",
        "updatedAt": "2026-05-09T00:00:00Z",
    }
    payload.update(overrides)
    return payload


def _mcp_payload(**overrides):
    payload = {
        "id": "mcp_123",
        "name": "GitHub",
        "slug": "github",
        "workspaceId": "wk_123",
        "config": {"command": "npx"},
        "secretRefs": {},
        "assignments": [{"agentId": "agent_123", "enabled": True}],
        "createdAt": "2026-05-09T00:00:00Z",
        "updatedAt": "2026-05-09T00:00:00Z",
    }
    payload.update(overrides)
    return payload


def test_list_skills_passes_workspace_id() -> None:
    mock_client = Mock()
    mock_client.get.return_value = _mock_response([_skill_payload()])

    skills = ManagedAgentExtensionsAPI(mock_client).list_skills(
        workspace_id="wk_123",
    )

    mock_client.get.assert_called_once_with(
        "/v1/managed-agent-extensions/skills",
        params={"workspaceId": "wk_123"},
    )
    assert skills[0].workspace_id == "wk_123"
    assert skills[0].assignments[0].agent_id == "agent_123"


def test_upload_skill_sends_workspace_id_in_multipart_form() -> None:
    mock_client = Mock()
    mock_client.post.return_value = _mock_response(_skill_payload())
    stream = BytesIO(b"fake zip")
    stream.name = "/tmp/review.zip"

    skill = ManagedAgentExtensionsAPI(mock_client).upload_skill(
        stream,
        workspace_id="wk_123",
        name="Review Skill",
    )

    mock_client.post.assert_called_once()
    path = mock_client.post.call_args.args[0]
    kwargs = mock_client.post.call_args.kwargs
    assert path == "/v1/managed-agent-extensions/skills/upload"
    assert kwargs["data"] == {
        "workspaceId": "wk_123",
        "name": "Review Skill",
    }
    filename, file_obj, content_type = kwargs["files"]["file"]
    assert filename == "review.zip"
    assert file_obj is stream
    assert content_type == "application/zip"
    assert skill.workspace_id == "wk_123"


def test_skill_methods_require_workspace_id() -> None:
    api = ManagedAgentExtensionsAPI(Mock())

    with pytest.raises(ValueError, match="workspace_id is required"):
        api.list_skills(workspace_id="")

    with pytest.raises(ValueError, match="workspace_id is required"):
        api.upload_skill(BytesIO(b"fake zip"), workspace_id="")


def test_list_mcp_definitions_passes_workspace_id() -> None:
    mock_client = Mock()
    mock_client.get.return_value = _mock_response([_mcp_payload()])

    mcps = ManagedAgentExtensionsAPI(mock_client).list_mcp_definitions(
        workspace_id="wk_123",
    )

    mock_client.get.assert_called_once_with(
        "/v1/managed-agent-extensions/mcp",
        params={"workspaceId": "wk_123"},
    )
    assert mcps[0].workspace_id == "wk_123"
    assert mcps[0].assignments[0].agent_id == "agent_123"


def test_create_mcp_definition_sends_workspace_id() -> None:
    mock_client = Mock()
    mock_client.post.return_value = _mock_response(_mcp_payload())

    mcp = ManagedAgentExtensionsAPI(mock_client).create_mcp_definition(
        name="GitHub",
        config={"command": "npx"},
        workspace_id="wk_123",
    )

    mock_client.post.assert_called_once_with(
        "/v1/managed-agent-extensions/mcp",
        json={
            "name": "GitHub",
            "config": {"command": "npx"},
            "workspaceId": "wk_123",
        },
    )
    assert mcp.workspace_id == "wk_123"


def test_mcp_methods_require_workspace_id() -> None:
    api = ManagedAgentExtensionsAPI(Mock())

    with pytest.raises(ValueError, match="workspace_id is required"):
        api.list_mcp_definitions(workspace_id="")

    with pytest.raises(ValueError, match="workspace_id is required"):
        api.create_mcp_definition(
            name="GitHub",
            config={"command": "npx"},
            workspace_id="",
        )
