"""Tests for auth API client helpers."""

from unittest.mock import Mock

import httpx

from agentenv.api.auth import AuthAPI
from agentenv.api.client import Client


def _json_response(method: str, url: str, payload: object) -> httpx.Response:
    request = httpx.Request(method, url)
    return httpx.Response(200, request=request, json=payload)


def test_signup_sends_current_contract_fields() -> None:
    client = Client(base_url="https://api.example.com")
    client._client = Mock()
    client._client.request.return_value = _json_response(
        "POST",
        "https://api.example.com/v1/auth/signup",
        {"message": "ok"},
    )

    result = AuthAPI(client).signup(
        email="user@example.com",
        username="testuser",
        password="Password123",
        turnstile_token="turnstile-token",
        fingerprint="visitor-id",
        fingerprint_request_id="request-id",
    )

    client._client.request.assert_called_once_with(
        "POST",
        "https://api.example.com/v1/auth/signup",
        headers={},
        json={
            "email": "user@example.com",
            "username": "testuser",
            "password": "Password123",
            "turnstileToken": "turnstile-token",
            "fingerprint": "visitor-id",
            "fingerprintRequestId": "request-id",
        },
    )
    assert result == {"message": "ok"}


def test_create_api_key_sends_scope_fields() -> None:
    client = Client(base_url="https://api.example.com", access_token="token")
    client._client = Mock()
    client._client.request.return_value = _json_response(
        "POST",
        "https://api.example.com/v1/auth/api-keys",
        {
            "id": "key-1",
            "name": "CI",
            "type": "workspace",
            "workspaceId": "workspace-1",
            "apiKey": "sk_test",
            "createdAt": "2026-03-02T00:00:00Z",
        },
    )

    key = AuthAPI(client).create_api_key(
        "CI",
        key_type="workspace",
        workspace_id="workspace-1",
    )

    client._client.request.assert_called_once_with(
        "POST",
        "https://api.example.com/v1/auth/api-keys",
        headers={"Authorization": "Bearer token"},
        json={
            "name": "CI",
            "type": "workspace",
            "workspaceId": "workspace-1",
        },
    )
    assert key.type == "workspace"
    assert key.workspace_id == "workspace-1"


def test_create_api_key_omits_type_by_default() -> None:
    client = Client(base_url="https://api.example.com", access_token="token")
    client._client = Mock()
    client._client.request.return_value = _json_response(
        "POST",
        "https://api.example.com/v1/auth/api-keys",
        {
            "id": "key-1",
            "name": "CI",
            "type": "workspace",
            "workspaceId": "workspace-1",
            "apiKey": "sk_test",
            "createdAt": "2026-03-02T00:00:00Z",
        },
    )

    AuthAPI(client).create_api_key("CI")

    client._client.request.assert_called_once_with(
        "POST",
        "https://api.example.com/v1/auth/api-keys",
        headers={"Authorization": "Bearer token"},
        json={"name": "CI"},
    )


def test_create_api_key_infers_workspace_type_from_workspace_id() -> None:
    client = Client(base_url="https://api.example.com", access_token="token")
    client._client = Mock()
    client._client.request.return_value = _json_response(
        "POST",
        "https://api.example.com/v1/auth/api-keys",
        {
            "id": "key-1",
            "name": "CI",
            "type": "workspace",
            "workspaceId": "workspace-1",
            "apiKey": "sk_test",
            "createdAt": "2026-03-02T00:00:00Z",
        },
    )

    AuthAPI(client).create_api_key("CI", workspace_id="workspace-1")

    client._client.request.assert_called_once_with(
        "POST",
        "https://api.example.com/v1/auth/api-keys",
        headers={"Authorization": "Bearer token"},
        json={
            "name": "CI",
            "type": "workspace",
            "workspaceId": "workspace-1",
        },
    )


def test_list_api_keys_sends_optional_filters() -> None:
    client = Client(base_url="https://api.example.com", access_token="token")
    client._client = Mock()
    client._client.request.return_value = _json_response(
        "GET",
        "https://api.example.com/v1/auth/api-keys",
        [],
    )

    keys = AuthAPI(client).list_api_keys(
        key_type="workspace",
        workspace_id="workspace-1",
    )

    client._client.request.assert_called_once_with(
        "GET",
        "https://api.example.com/v1/auth/api-keys",
        headers={"Authorization": "Bearer token"},
        params={
            "type": "workspace",
            "workspaceId": "workspace-1",
        },
    )
    assert keys == []
