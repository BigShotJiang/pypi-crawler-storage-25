"""Tests for bot integrations API wrappers."""

from unittest.mock import Mock

import pytest

from agentenv.api.bot_integrations import BotIntegrationsAPI


def _mock_response(payload, *, status_code: int = 200):
    response = Mock()
    response.status_code = status_code
    response.json.return_value = payload
    response.content = b"body"
    return response


def _integration_payload(**overrides):
    payload = {
        "id": "bi_123",
        "workspaceId": "wk_123",
        "ownerUserId": "user_123",
        "provider": "telegram",
        "name": "Telegram Agent",
        "status": "active",
        "fixedAgentId": "ma_123",
        "agentWorkspaceGroupId": None,
        "model": None,
        "instructions": None,
        "lastError": None,
        "webhookUrl": "https://api.example.com/v1/bot-ingress/telegram/bi_123",
        "providerConfig": {
            "botTokenKey": "TELEGRAM_BOT_TOKEN",
            "botUsername": "agentbot",
        },
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    }
    payload.update(overrides)
    return payload


def test_create_telegram_posts_expected_payload() -> None:
    mock_client = Mock()
    mock_client.post.return_value = _mock_response(_integration_payload())

    integration = BotIntegrationsAPI(mock_client).create_telegram(
        "wk_123",
        agent_id="ma_123",
        name="Telegram Agent",
        bot_token="123:telegram-bot-token",
        secret_token="telegram-webhook-secret",
        allow_groups=True,
        require_mention_in_groups=True,
        allowed_chat_ids=["123"],
        bot_username="agentbot",
    )

    mock_client.post.assert_called_once_with(
        "/v1/workspaces/wk_123/bot-integrations",
        json={
            "provider": "telegram",
            "name": "Telegram Agent",
            "fixedAgentId": "ma_123",
            "telegramBotToken": "123:telegram-bot-token",
            "telegramSecretToken": "telegram-webhook-secret",
            "telegramAllowGroups": True,
            "telegramRequireMentionInGroups": True,
            "telegramAllowedChatIds": ["123"],
            "telegramBotUsername": "agentbot",
        },
    )
    assert integration.id == "bi_123"
    assert integration.fixed_agent_id == "ma_123"


def test_sync_telegram_webhook_posts_drop_pending_updates() -> None:
    mock_client = Mock()
    mock_client.post.return_value = _mock_response(
        {"success": True, "webhookUrl": "https://api.example.com/hook"}
    )

    result = BotIntegrationsAPI(mock_client).sync_telegram_webhook(
        "wk_123",
        "bi_123",
        drop_pending_updates=True,
    )

    mock_client.post.assert_called_once_with(
        "/v1/workspaces/wk_123/bot-integrations/bi_123/telegram/sync-webhook",
        json={"dropPendingUpdates": True},
    )
    assert result.success is True
    assert result.webhook_url == "https://api.example.com/hook"


def test_update_normalizes_pythonic_field_names() -> None:
    mock_client = Mock()
    mock_client.patch.return_value = _mock_response(_integration_payload(name="Updated"))

    result = BotIntegrationsAPI(mock_client).update(
        "wk_123",
        "bi_123",
        name="Updated",
        telegram_allow_groups=True,
        telegram_bot_token_key=None,
    )

    mock_client.patch.assert_called_once_with(
        "/v1/workspaces/wk_123/bot-integrations/bi_123",
        json={"name": "Updated", "telegramAllowGroups": True},
    )
    assert result.name == "Updated"


def test_update_rejects_empty_body() -> None:
    with pytest.raises(ValueError, match="at least one field"):
        BotIntegrationsAPI(Mock()).update("wk_123", "bi_123")
