"""End-to-end tests for managed-agent extensions + git integration.

These tests hit a real staging API server. Point them at a port-forward
or the public URL via ``AGENTENV_API_URL``; authentication reads from
``AGENTENV_API_KEY`` or, as a staging fallback, mints a test-token via
``POST /v1/auth/test-token``.

Skip when no API server is reachable — CI without staging access still
passes the unit tests under ``test_managed_agent_extensions_unit.py``.
"""

from __future__ import annotations

import io
import json
import os
import urllib.request
import zipfile

import pytest

from agentenv.sdk import Client, GitCommandError, GitStatusEntry

API_URL = os.environ.get("AGENTENV_API_URL", "http://127.0.0.1:13000")
API_KEY = os.environ.get("AGENTENV_API_KEY")


def _staging_reachable() -> bool:
    try:
        urllib.request.urlopen(f"{API_URL}/v1/auth/test-token", timeout=3).read
        return True
    except Exception:
        try:
            req = urllib.request.Request(
                f"{API_URL}/v1/auth/test-token",
                method="POST",
                data=b"{}",
                headers={"content-type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=3).read()
            return True
        except Exception:
            return False


pytestmark = pytest.mark.skipif(
    not _staging_reachable(),
    reason=f"API at {API_URL} unreachable",
)


def _mint_access_token() -> str:
    req = urllib.request.Request(
        f"{API_URL}/v1/auth/test-token",
        method="POST",
        data=b"{}",
        headers={"content-type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=5) as resp:
        return json.loads(resp.read())["accessToken"]


@pytest.fixture(scope="session")
def client() -> Client:
    if API_KEY:
        return Client(api_url=API_URL, api_key=API_KEY)
    return Client(api_url=API_URL, access_token=_mint_access_token())


@pytest.fixture(scope="session")
def workspace_id(client: Client) -> str:
    resp = client._client.get("/v1/workspaces")
    data = resp.json()
    workspaces = data.get("workspaces") if isinstance(data, dict) else data
    assert workspaces, f"no workspaces visible to caller: {data}"
    return workspaces[0]["id"]


@pytest.fixture(scope="session")
def upstream_id(client: Client, workspace_id: str) -> str:
    resp = client._client.get(
        "/v1/ai-gateway/upstreams", params={"workspaceId": workspace_id}
    )
    upstreams = resp.json()
    assert upstreams, f"no upstreams: {upstreams}"
    return upstreams[0]["id"]


@pytest.fixture()
def agent(client: Client, workspace_id: str, upstream_id: str):
    """Create a fresh managed agent, wait for running, clean up at teardown."""
    agent = client.managed_agents.create(
        name=f"sdk-ext-git-test-{os.getpid()}",
        workspace_id=workspace_id,
        upstream_id=upstream_id,
    )
    running = client.managed_agents.wait_for_status(
        agent.id, desired_status="running", timeout=180.0, interval=2.0
    )
    try:
        yield running
    finally:
        try:
            client.managed_agents.delete(running.id)
        except Exception:
            pass


# ============================================================ skills uploads


def _build_skill_zip() -> bytes:
    """Return a minimal ``.zip`` that the api-server's skill extractor accepts."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(
            "SKILL.md",
            "---\nname: sdk-test-skill\ndescription: sdk test skill\n---\n\nhi\n",
        )
        zf.writestr("README.md", "# sdk test skill\n")
    return buf.getvalue()


class TestSkills:
    def test_upload_list_delete_roundtrip(self, client: Client, workspace_id: str):
        ext = client.managed_agents.extensions
        content = _build_skill_zip()
        skill = ext.upload_skill(
            io.BytesIO(content),
            workspace_id=workspace_id,
            name="sdk-roundtrip",
        )
        try:
            assert skill.id
            assert skill.name == "sdk-roundtrip"
            assert skill.workspace_id == workspace_id
            assert skill.sha256 and len(skill.sha256) == 64
            found = [
                s
                for s in ext.list_skills(workspace_id=workspace_id)
                if s.id == skill.id
            ]
            assert len(found) == 1, "skill missing from list_skills()"
        finally:
            ext.delete_skill(skill.id)
        assert not [
            s for s in ext.list_skills(workspace_id=workspace_id) if s.id == skill.id
        ], "deleted skill still listed"

    def test_set_skill_assignment(self, client: Client, agent, workspace_id: str):
        ext = client.managed_agents.extensions
        skill = ext.upload_skill(
            io.BytesIO(_build_skill_zip()),
            workspace_id=workspace_id,
            name="sdk-assign",
        )
        try:
            on = ext.set_skill_assignment(agent.id, skill.id, enabled=True)
            matches = [a for a in on.assignments if a.agent_id == agent.id]
            assert matches, f"assignment not reflected: {on.assignments}"
            assert matches[0].enabled is True
            off = ext.set_skill_assignment(agent.id, skill.id, enabled=False)
            matches = [a for a in off.assignments if a.agent_id == agent.id]
            assert matches and matches[0].enabled is False
        finally:
            ext.delete_skill(skill.id)


# ============================================================ MCP definitions


class TestMcpDefinitions:
    def test_create_update_delete_roundtrip(self, client: Client, workspace_id: str):
        ext = client.managed_agents.extensions
        mcp = ext.create_mcp_definition(
            name="sdk-test-mcp",
            config={"command": "true"},  # no-op — we never start it
            workspace_id=workspace_id,
        )
        try:
            assert mcp.id
            assert mcp.name == "sdk-test-mcp"
            assert mcp.config == {"command": "true"}
            listing = ext.list_mcp_definitions(workspace_id=workspace_id)
            assert any(m.id == mcp.id for m in listing)

            updated = ext.update_mcp_definition(
                mcp.id,
                name="sdk-test-mcp-renamed",
                config={"command": "true", "args": ["--once"]},
            )
            assert updated.name == "sdk-test-mcp-renamed"
            assert updated.config == {"command": "true", "args": ["--once"]}
        finally:
            ext.delete_mcp_definition(mcp.id)

    def test_update_rejects_empty_body(self, client: Client, workspace_id: str):
        ext = client.managed_agents.extensions
        mcp = ext.create_mcp_definition(
            name="sdk-update-empty",
            config={"command": "true"},
            workspace_id=workspace_id,
        )
        try:
            with pytest.raises(ValueError, match="at least one of"):
                ext.update_mcp_definition(mcp.id)
        finally:
            ext.delete_mcp_definition(mcp.id)

    def test_set_mcp_assignment(self, client: Client, agent, workspace_id: str):
        ext = client.managed_agents.extensions
        mcp = ext.create_mcp_definition(
            name="sdk-mcp-assign",
            config={"command": "true"},
            workspace_id=workspace_id,
        )
        try:
            on = ext.set_mcp_assignment(agent.id, mcp.id, enabled=True)
            matches = [a for a in on.assignments if a.agent_id == agent.id]
            assert matches and matches[0].enabled is True
            off = ext.set_mcp_assignment(agent.id, mcp.id, enabled=False)
            matches = [a for a in off.assignments if a.agent_id == agent.id]
            assert matches and matches[0].enabled is False
        finally:
            ext.delete_mcp_definition(mcp.id)


# ============================================================ git integration


class TestGit:
    def test_configure_identity_roundtrip(self, client: Client, agent):
        git = client.managed_agents.git(agent.id)
        git.configure_identity(name="Sdk Test", email="sdk-test@example.com")
        name, email = git.get_identity()
        assert name == "Sdk Test"
        assert email == "sdk-test@example.com"

    def test_init_add_commit_log(self, client: Client, agent):
        git = client.managed_agents.git(agent.id, cwd="/tmp")
        # Fresh repo each run — /tmp is per-sandbox, so this is hermetic.
        repo = f"/tmp/sdk-git-test-{os.getpid()}"
        git.exec(f"rm -rf {repo} && mkdir -p {repo}")
        git.init(path=repo, initial_branch="main")
        repo_git = client.managed_agents.git(agent.id, cwd=repo)
        repo_git.configure_identity(
            name="Sdk Test", email="sdk-test@example.com", scope="local"
        )
        repo_git.exec("echo 'hello' > README.md")
        repo_git.add("README.md")
        repo_git.commit("initial commit")
        log = repo_git.log(max_count=1)
        assert len(log) == 1
        assert log[0]["subject"] == "initial commit"
        assert "Sdk Test" in log[0]["author"]
        assert repo_git.current_branch() == "main"
        assert len(repo_git.current_head()) == 40

    def test_status_porcelain(self, client: Client, agent):
        git = client.managed_agents.git(agent.id, cwd="/tmp")
        repo = f"/tmp/sdk-git-status-{os.getpid()}"
        git.exec(f"rm -rf {repo} && mkdir -p {repo}")
        git.init(path=repo, initial_branch="main")
        repo_git = client.managed_agents.git(agent.id, cwd=repo)
        repo_git.configure_identity(
            name="Sdk Test", email="sdk-test@example.com", scope="local"
        )
        # New untracked file → expect ?? status
        repo_git.exec("echo 'x' > new.txt")
        entries = repo_git.status()
        assert any(
            isinstance(e, GitStatusEntry) and e.status == "??" and e.path == "new.txt"
            for e in entries
        ), entries

    def test_clone_public_repo(self, client: Client, agent):
        git = client.managed_agents.git(agent.id, cwd="/tmp")
        dest = f"/tmp/sdk-git-clone-{os.getpid()}"
        git.exec(f"rm -rf {dest}")
        # Use github's hello-world (trivially small) with --depth=1.
        res = git.clone(
            "https://github.com/octocat/Hello-World.git",
            path=dest,
            depth=1,
        )
        assert res.exit_code == 0
        listing = git.exec(f"ls {dest}")
        assert "README" in listing.output

    def test_failed_command_raises(self, client: Client, agent):
        git = client.managed_agents.git(agent.id, cwd="/tmp")
        with pytest.raises(GitCommandError) as ei:
            # Run git in a non-repo directory → fails with exit code 128.
            git.exec("rm -rf /tmp/notarepo && mkdir -p /tmp/notarepo")
            client.managed_agents.git(agent.id, cwd="/tmp/notarepo").status()
        assert ei.value.exit_code != 0
