"""Tests for sandbox CLI log commands."""

from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
import typer

from agentenv.api.sandbox import SandboxAPI
from agentenv.cli.sandbox import (
    create_sandbox,
    delete_sandbox_alt,
    exec_sandbox,
    list_sandboxes,
    print_logs,
    resolve_sandbox_id,
    run_sandbox,
    upload_sandbox_file,
    wait,
)


class _DummyResponse:
    def __init__(self, payload=None, text: str = "", json_error: Exception | None = None):
        self._payload = payload
        self.text = text
        self._json_error = json_error

    def json(self):
        if self._json_error is not None:
            raise self._json_error
        return self._payload


def test_print_logs_follow_polls_lifecycle_and_prints_incremental_entries(
    monkeypatch,
    capsys,
) -> None:
    """follow mode should poll lifecycle logs and print only new messages."""
    mock_client = Mock()
    responses = [
        _DummyResponse(
            {
                "entries": [
                    {
                        "timestamp": "2026-03-03T07:13:54.960Z",
                        "message": "first",
                        "logPath": "pending",
                    },
                    {
                        "timestamp": "2026-03-03T07:13:55.000Z",
                        "message": "second",
                        "logPath": "pending",
                    },
                ]
            }
        ),
        _DummyResponse(
            {
                "entries": [
                    {
                        "timestamp": "2026-03-03T07:13:55.000Z",
                        "message": "second",
                        "logPath": "pending",
                    },
                    {
                        "timestamp": "2026-03-03T07:13:56.000Z",
                        "message": "third",
                        "logPath": "stdout",
                    },
                ]
            }
        ),
        KeyboardInterrupt(),
    ]

    def _fake_get(*_args, **_kwargs):
        item = responses.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item

    mock_client.get.side_effect = _fake_get

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: mock_client)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )
    monkeypatch.setattr("agentenv.cli.sandbox.time.sleep", lambda _seconds: None)

    print_logs("sandbox-prefix", follow=True, tail=50)

    assert mock_client.get.call_count == 3
    first_call = mock_client.get.call_args_list[0]
    second_call = mock_client.get.call_args_list[1]
    assert first_call.args[0] == "/v1/sandboxes/sandbox-full-id/logs/lifecycle"
    assert first_call.kwargs["params"] == {"sort": "asc", "limit": 50}
    assert second_call.kwargs["params"] == {
        "sort": "asc",
        "limit": 50,
        "from": "2026-03-03T07:13:55.000Z",
    }

    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["first", "second", "third"]


def test_print_logs_non_follow_reads_lifecycle_once(monkeypatch, capsys) -> None:
    """non-follow mode should read lifecycle logs once and print message lines."""
    mock_client = Mock()
    mock_client.get.return_value = _DummyResponse(
        {
            "entries": [
                {
                    "timestamp": "2026-03-03T07:13:54.960Z",
                    "message": "line-one",
                    "logPath": "stdout",
                },
                {
                    "timestamp": "2026-03-03T07:13:55.000Z",
                    "message": "line-two",
                    "logPath": "pending",
                },
            ]
        }
    )

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: mock_client)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )

    print_logs("sandbox-prefix", follow=False)

    mock_client.get.assert_called_once_with(
        "/v1/sandboxes/sandbox-full-id/logs/lifecycle",
        params={"sort": "asc", "limit": 200},
    )
    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["line-one", "line-two"]


def test_print_logs_non_follow_falls_back_to_plain_text(monkeypatch, capsys) -> None:
    """non-follow mode should print raw text if response body is not JSON."""
    mock_client = Mock()
    mock_client.get.return_value = _DummyResponse(
        payload=None,
        text="plain text log",
        json_error=ValueError("invalid json"),
    )

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: mock_client)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )

    print_logs("sandbox-prefix", follow=False)

    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["plain text log"]


def test_run_with_explicit_image_and_no_command_uses_image_default(monkeypatch) -> None:
    """run --image <img> without command should not force /bin/bash."""
    captured_args = {}
    mock_api = Mock()
    mock_api.create.return_value = SimpleNamespace(id="sb-1", status="pending")

    def _fake_build_request(**kwargs):
        captured_args["args"] = kwargs["args"]
        return {"args": kwargs["args"]}

    monkeypatch.setattr("agentenv.cli.sandbox.get_settings", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.build_sandbox_request", _fake_build_request)

    run_sandbox(
        ctx=Mock(),
        name="nginx",
        type=None,
        sandbox=None,
        image="nginx:latest",
        image_tag=None,
        snapshot=None,
        cpu=None,
        memory=None,
        gpu=0,
        gpu_type=None,
        env=[],
        expose=[],
        secret=[],
        region=None,
        max_lifetime_seconds=None,
        follow=False,
        command=None,
    )

    assert captured_args["args"] == []
    mock_api.create.assert_called_once_with({"args": []})


def test_run_without_runtime_source_and_no_command_defaults_to_bash(monkeypatch) -> None:
    """plain `agv run` without command should keep shell-first behavior."""
    captured_args = {}
    mock_api = Mock()
    mock_api.create.return_value = SimpleNamespace(id="sb-2", status="pending")

    def _fake_build_request(**kwargs):
        captured_args["args"] = kwargs["args"]
        return {"args": kwargs["args"]}

    monkeypatch.setattr("agentenv.cli.sandbox.get_settings", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.build_sandbox_request", _fake_build_request)

    run_sandbox(
        ctx=Mock(),
        name=None,
        type=None,
        sandbox=None,
        image=None,
        image_tag=None,
        snapshot=None,
        cpu=None,
        memory=None,
        gpu=0,
        gpu_type=None,
        env=[],
        expose=[],
        secret=[],
        region=None,
        max_lifetime_seconds=None,
        follow=False,
        command=None,
    )

    assert captured_args["args"] == ["/bin/bash"]
    mock_api.create.assert_called_once_with({"args": ["/bin/bash"]})


def test_run_sandbox_is_async_and_follows_logs_without_wait(monkeypatch) -> None:
    """run_sandbox should not wait for running and should follow lifecycle logs by default."""
    mock_api = Mock()
    mock_api.create.return_value = SimpleNamespace(id="sb-async", status="pending")
    mock_api.wait_for_status.side_effect = AssertionError("wait_for_status should not be called")

    monkeypatch.setattr("agentenv.cli.sandbox.get_settings", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.build_sandbox_request", lambda **_kwargs: {})
    mock_print_logs = Mock()
    monkeypatch.setattr("agentenv.cli.sandbox.print_logs", mock_print_logs)

    run_sandbox(
        ctx=Mock(),
        name="nginx",
        type=None,
        sandbox=None,
        image="nginx:latest",
        image_tag=None,
        snapshot=None,
        cpu=None,
        memory=None,
        gpu=0,
        gpu_type=None,
        env=[],
        expose=[],
        secret=[],
        region=None,
        max_lifetime_seconds=None,
        follow=True,
        command=[],
    )

    mock_api.create.assert_called_once_with({})
    assert mock_api.wait_for_status.call_count == 0
    mock_print_logs.assert_called_once_with("sb-async", follow=True)


def test_create_sandbox_without_command_does_not_default_to_bash(monkeypatch) -> None:
    """sandbox create should map to POST /sandboxes without shell-first defaults."""
    captured_args = {}
    mock_api = Mock()
    mock_api.create.return_value = SimpleNamespace(id="sb-create", status="pending")

    def _fake_build_request(**kwargs):
        captured_args["args"] = kwargs["args"]
        return {"args": kwargs["args"]}

    monkeypatch.setattr("agentenv.cli.sandbox.get_settings", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.build_sandbox_request", _fake_build_request)
    mock_print_logs = Mock()
    monkeypatch.setattr("agentenv.cli.sandbox.print_logs", mock_print_logs)

    create_sandbox(
        ctx=Mock(),
        name="exact-create",
        type=None,
        sandbox=None,
        image="python:3.11",
        image_tag=None,
        snapshot=None,
        cpu=None,
        memory=None,
        gpu=0,
        gpu_type=None,
        env=[],
        expose=[],
        secret=[],
        region=None,
        max_lifetime_seconds=None,
        command=None,
    )

    assert captured_args["args"] == []
    mock_api.create.assert_called_once_with({"args": []})
    assert mock_print_logs.call_count == 0


def test_list_sandboxes_default_includes_pending(monkeypatch) -> None:
    """default ls should keep pending sandboxes visible."""
    sandboxes = [
        SimpleNamespace(id="sb-pending", status="pending"),
        SimpleNamespace(id="sb-running", status="running"),
        SimpleNamespace(id="sb-stopped", status="stopped"),
    ]
    captured = {}
    mock_api = Mock()
    mock_api.list_all.return_value = sandboxes

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.print_sandbox_table", lambda rows: captured.setdefault("rows", rows))

    list_sandboxes(all=False)

    assert [sandbox.id for sandbox in captured["rows"]] == ["sb-pending", "sb-running"]


def test_delete_sandbox_alt_preserves_force_flag(monkeypatch) -> None:
    """deprecated delete alias should honor --force instead of always forcing."""
    called = {}

    def _fake_delete(sandbox_id, force=False):
        called["sandbox_id"] = sandbox_id
        called["force"] = force

    monkeypatch.setattr("agentenv.cli.sandbox.delete_sandbox", _fake_delete)

    delete_sandbox_alt("sb-123", force=False)
    assert called == {"sandbox_id": "sb-123", "force": False}


def test_wait_sandbox_polls_until_desired_status(monkeypatch, capsys) -> None:
    """sandbox wait should resolve IDs and delegate lifecycle polling to the API."""
    sandbox = SimpleNamespace(id="sandbox-full-id", status="running")
    mock_api = Mock()
    mock_api.wait_for_status.return_value = sandbox

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.print_success", print)

    wait("sandbox-prefix", "running", timeout=45.0, interval=1.5)

    mock_api.wait_for_status.assert_called_once_with(
        "sandbox-full-id",
        desired_status="running",
        timeout=45.0,
        interval=1.5,
    )
    assert capsys.readouterr().out.strip().splitlines() == [
        "Sandbox sandbox-full-id reached status running"
    ]


def test_wait_sandbox_reports_timeout(monkeypatch) -> None:
    """sandbox wait should convert timeout failures into CLI exits."""
    errors = []
    mock_api = Mock()
    mock_api.wait_for_status.side_effect = TimeoutError("too slow")

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.print_error", errors.append)

    with pytest.raises(typer.Exit):
        wait("sandbox-prefix", "stopped", timeout=5.0, interval=0.25)

    assert errors == [
        "Timed out after 5s waiting for sandbox sandbox-full-id to reach status stopped"
    ]


def test_resolve_sandbox_id_paginates_until_match(monkeypatch) -> None:
    """prefix resolution should search beyond the first page of sandboxes."""

    class _FakeAPI:
        def __init__(self, _client):
            self.calls = []

        def list_all(self, page=1, limit=100):
            self.calls.append((page, limit))
            if page == 1:
                return [SimpleNamespace(id=f"sb-{i:03d}") for i in range(100)]
            if page == 2:
                return [SimpleNamespace(id="target-sandbox-id")]
            return []

    api_instances = []

    def _fake_api(client):
        api = _FakeAPI(client)
        api_instances.append(api)
        return api

    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", _fake_api)

    resolved = resolve_sandbox_id(Mock(), "target")

    assert resolved == "target-sandbox-id"
    assert api_instances[0].calls == [(1, 100), (2, 100)]


def test_exec_sandbox_prints_output_and_exit_code(monkeypatch, capsys) -> None:
    """sandbox exec should run the command and print command output."""
    mock_api = Mock()
    mock_api.exec.return_value = SimpleNamespace(output="hello", exit_code=0)

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.print_success", print)

    exec_sandbox("sandbox-prefix", ["echo", "hello"])

    mock_api.exec.assert_called_once_with("sandbox-full-id", "echo hello")
    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["hello", "Command exited with code 0"]


def test_upload_sandbox_file_uploads_existing_path(monkeypatch, tmp_path, capsys) -> None:
    """sandbox upload should pass the local file and remote destination to the API."""
    local_file = tmp_path / "payload.txt"
    local_file.write_text("payload")

    mock_api = Mock()
    mock_api.upload_file.return_value = {"path": "/workspace/payload.txt"}

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.print_success", print)

    upload_sandbox_file("sandbox-prefix", str(local_file), "/workspace/payload.txt")

    mock_api.upload_file.assert_called_once_with(
        "sandbox-full-id",
        str(local_file),
        "/workspace/payload.txt",
    )
    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["File uploaded: /workspace/payload.txt"]


def test_upload_sandbox_file_rejects_missing_path(monkeypatch) -> None:
    """sandbox upload should fail fast when the local file does not exist."""
    errors = []
    monkeypatch.setattr("agentenv.cli.sandbox.print_error", errors.append)

    with pytest.raises(typer.Exit):
        upload_sandbox_file("sandbox-prefix", "/does/not/exist.txt", "/remote/file.txt")

    assert errors == ["File not found: /does/not/exist.txt"]


@pytest.mark.parametrize("protocol", ["http", "ws"])
def test_expose_port_normalizes_snake_case_mapping(protocol: str) -> None:
    """sandbox port exposure should accept snake_case response payloads."""
    mock_client = Mock()
    mock_client.post.return_value = _DummyResponse(
        {
            "mappings": [
                {
                    "host_port": 31000,
                    "container_port": 8080,
                    "public_url": "https://sandbox.example",
                    "port_type": protocol,
                }
            ]
        }
    )

    mapping = SandboxAPI(mock_client).expose_port("sb-123", 8080, protocol)

    post_kwargs = mock_client.post.call_args.kwargs
    assert post_kwargs["json"] == {
        "ports": [
            {
                "containerPort": 8080,
                "protocol": protocol,
            }
        ]
    }
    assert mapping.host_port == 31000
    assert mapping.container_port == 8080
    assert mapping.public_url == "https://sandbox.example"
    assert mapping.protocol == protocol
