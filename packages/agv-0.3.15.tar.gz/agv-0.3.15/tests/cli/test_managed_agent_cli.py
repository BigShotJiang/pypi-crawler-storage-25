"""Tests for managed-agent CLI commands."""

import json
from pathlib import Path
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.models import (
    BotIntegration,
    ManagedAgent,
    ManagedAgentListResponse,
    ManagedAgentMcpDefinition,
    ManagedAgentSkillAsset,
    ManagedAgentStreamEvent,
    OperationSuccess,
)
from agentenv.cli.app import app

runner = CliRunner()


def _build_agent(**overrides) -> ManagedAgent:
    payload = {
        "id": "ma_123",
        "workspaceId": "wk_123",
        "sandboxId": "sb_123",
        "name": "Managed Agent",
        "status": "running",
        "publicToken": "public-token",
        "config": {
            "upstreamId": "up_123",
            "model": "gpt-5-codex",
        },
        "metadata": None,
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    }
    payload.update(overrides)
    return ManagedAgent(**payload)


def _build_skill(**overrides) -> ManagedAgentSkillAsset:
    payload = {
        "id": "skill_123",
        "name": "PR Reviewer",
        "slug": "pr-reviewer",
        "workspaceId": "wk_123",
        "sha256": "a" * 64,
        "assignments": [{"agentId": "ma_123", "enabled": True}],
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    }
    payload.update(overrides)
    return ManagedAgentSkillAsset(**payload)


def _build_mcp(**overrides) -> ManagedAgentMcpDefinition:
    payload = {
        "id": "mcp_123",
        "name": "GitHub",
        "slug": "github",
        "workspaceId": "wk_123",
        "config": {
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-github"],
        },
        "secretRefs": {"env": {"GITHUB_TOKEN": "secret_123"}},
        "assignments": [{"agentId": "ma_123", "enabled": True}],
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    }
    payload.update(overrides)
    return ManagedAgentMcpDefinition(**payload)


def _build_bot_integration(**overrides) -> BotIntegration:
    payload = {
        "id": "bi_123",
        "workspaceId": "wk_123",
        "ownerUserId": "user_123",
        "provider": "telegram",
        "name": "Telegram Agent",
        "status": "active",
        "fixedAgentId": "ma_123",
        "agentWorkspaceGroupId": None,
        "model": None,
        "instructions": None,
        "lastError": None,
        "webhookUrl": "https://api.example.com/v1/bot-ingress/telegram/bi_123",
        "providerConfig": {
            "botTokenKey": "TELEGRAM_BOT_TOKEN",
            "secretTokenKey": "TELEGRAM_WEBHOOK_SECRET",
            "allowGroups": True,
            "requireMentionInGroups": True,
            "allowedChatIds": ["123"],
            "botUsername": "agentbot",
        },
        "createdAt": "2026-04-12T00:00:00Z",
        "updatedAt": "2026-04-12T00:00:00Z",
    }
    payload.update(overrides)
    return BotIntegration(**payload)


def test_managed_agent_ls_forwards_filters_and_renders_json() -> None:
    """managed-agent ls should pass filters to the API and emit JSON."""
    list_response = ManagedAgentListResponse(
        agents=[_build_agent()],
        total=1,
        page=2,
        limit=10,
    )

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.list_all.return_value = list_response

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "ls",
                    "--workspace",
                    "wk_123",
                    "--agent-workspace-group-id",
                    "awg_123",
                    "--search",
                    "Managed",
                    "--page",
                    "2",
                    "--limit",
                    "10",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    assert '"total": 1' in result.output
    mock_api_cls.return_value.list_all.assert_called_once_with(
        workspace_id="wk_123",
        agent_workspace_group_id="awg_123",
        search="Managed",
        page=2,
        limit=10,
    )


def test_managed_agent_create_forwards_expected_arguments() -> None:
    """managed-agent create should send the managed-agent DTO fields."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.create.return_value = _build_agent(status="starting")

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "create",
                    "--name",
                    "Builder",
                    "--workspace",
                    "wk_123",
                    "--upstream-id",
                    "up_123",
                    "--model",
                    "gpt-5-codex",
                    "--instructions",
                    "be careful",
                    "--image",
                    "docker://registry.example/agent:latest",
                    "--workspace-template",
                    "solayer-order-agent",
                    "--cpu",
                    "4000",
                    "--memory",
                    "8192",
                    "--agent-workspace-group-id",
                    "awg_123",
                    "--skill-id",
                    "skill_123",
                    "--mcp-id",
                    "mcp_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.create.assert_called_once_with(
        name="Builder",
        workspace_id="wk_123",
        upstream_id="up_123",
        model="gpt-5-codex",
        instructions="be careful",
        image="docker://registry.example/agent:latest",
        workspace_template="solayer-order-agent",
        cpu_millis=4000,
        memory_mb=8192,
        agent_workspace_group_id="awg_123",
        enabled_skill_ids=["skill_123"],
        enabled_mcp_ids=["mcp_123"],
    )


def test_managed_agent_create_global_json_keeps_stdout_strictly_json() -> None:
    """Progress/status output must not pollute stdout in global --json mode."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.create.return_value = _build_agent(status="starting")

            result = runner.invoke(
                app,
                [
                    "--json",
                    "managed-agent",
                    "create",
                    "--name",
                    "Builder",
                    "--workspace",
                    "wk_123",
                    "--upstream-id",
                    "up_123",
                ],
            )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["id"] == "ma_123"
    assert payload["status"] == "starting"


def test_managed_agent_create_prints_public_token_in_non_json_mode() -> None:
    """managed-agent create should show the public token for human output."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.create.return_value = _build_agent(status="starting")

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "create",
                    "--name",
                    "Builder",
                    "--workspace",
                    "wk_123",
                    "--upstream-id",
                    "up_123",
                ],
            )

    assert result.exit_code == 0
    assert "Public Token:" in result.output
    assert "public-token" in result.output


def test_managed_agent_inspect_omits_public_token_when_unavailable() -> None:
    """managed-agent inspect should not render a public token when it is unavailable."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.get.return_value = _build_agent(publicToken=None)

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "inspect",
                    "ma_123",
                ],
            )

    assert result.exit_code == 0
    assert "Public Token" not in result.output


def test_managed_agent_send_prints_final_assistant_message() -> None:
    """managed-agent send should stream assistant deltas for human output."""
    events = [
        ManagedAgentStreamEvent(type="run.started", runId="run_123", agentId="ma_123"),
        ManagedAgentStreamEvent(
            type="message.delta",
            messageId="msg_123",
            delta="Hello ",
        ),
        ManagedAgentStreamEvent(
            type="message.delta",
            messageId="msg_123",
            delta="from the agent",
        ),
        ManagedAgentStreamEvent(
            type="message.completed",
            messageId="msg_123",
            content="Hello from the agent",
        ),
    ]

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.get.return_value = _build_agent()
            mock_api_cls.return_value.stream_message.return_value = iter(events)

            result = runner.invoke(
                app,
                ["managed-agent", "send", "ma_123", "--", "hello", "agent"],
            )

    assert result.exit_code == 0
    assert "Hello from the agent" in result.output
    mock_api_cls.return_value.get.assert_called_once_with("ma_123")
    mock_api_cls.return_value.stream_message.assert_called_once_with("ma_123", "hello agent")


def test_managed_agent_send_wakes_sleeping_agent_before_streaming() -> None:
    """managed-agent send should auto-wake sleeping agents before streaming."""
    events = [
        ManagedAgentStreamEvent(
            type="message.completed",
            messageId="msg_123",
            content="Ready",
        ),
    ]

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.get.return_value = _build_agent(status="sleeping")
            mock_api_cls.return_value.stream_message.return_value = iter(events)

            result = runner.invoke(
                app,
                ["managed-agent", "send", "ma_123", "--", "wake", "up"],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.wake.assert_called_once_with("ma_123")
    mock_api_cls.return_value.wait_for_status.assert_called_once_with(
        "ma_123",
        desired_status="running",
        timeout=120.0,
    )


def test_managed_agent_send_events_streams_ndjson() -> None:
    """managed-agent send --events should emit one JSON event per line."""
    events = [
        ManagedAgentStreamEvent(type="run.started", runId="run_123", agentId="ma_123"),
        ManagedAgentStreamEvent(
            type="message.completed",
            messageId="msg_123",
            content="Hello from the agent",
        ),
    ]

    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.stream_message.return_value = iter(events)

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "send",
                    "ma_123",
                    "--events",
                    "--no-wake",
                    "--",
                    "hello",
                    "agent",
                ],
            )

    assert result.exit_code == 0
    lines = [json.loads(line) for line in result.output.splitlines() if line.strip()]
    assert [line["type"] for line in lines] == ["run.started", "message.completed"]
    assert lines[1]["content"] == "Hello from the agent"
    mock_api_cls.return_value.stream_message.assert_called_once_with("ma_123", "hello agent")
    mock_api_cls.return_value.send_message.assert_not_called()


def test_managed_agent_rm_deletes_with_force() -> None:
    """managed-agent rm --force should delete without prompting."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentAPI") as mock_api_cls:
            mock_api_cls.return_value.delete.return_value = OperationSuccess(success=True)

            result = runner.invoke(
                app,
                ["managed-agent", "rm", "ma_123", "--force", "--json"],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.delete.assert_called_once_with("ma_123")


def test_managed_agent_skill_upload_forwards_archive_and_renders_json() -> None:
    """managed-agent skill upload should pass the archive path to extensions API."""
    skill = _build_skill()

    with runner.isolated_filesystem():
        Path("skill.zip").write_bytes(b"zip")
        with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
            with patch("agentenv.cli.managed_agent.ManagedAgentExtensionsAPI") as mock_api_cls:
                mock_api_cls.return_value.upload_skill.return_value = skill

                result = runner.invoke(
                    app,
                    [
                        "managed-agent",
                        "skill",
                        "upload",
                        "skill.zip",
                        "--workspace",
                        "wk_123",
                        "--name",
                        "PR Reviewer",
                        "--json",
                    ],
                )

    assert result.exit_code == 0
    assert json.loads(result.stdout)["id"] == "skill_123"
    mock_api_cls.return_value.upload_skill.assert_called_once_with(
        Path("skill.zip"),
        workspace_id="wk_123",
        name="PR Reviewer",
    )


def test_managed_agent_mcp_ls_forwards_workspace_id() -> None:
    """managed-agent mcp ls should list MCP definitions for one workspace."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentExtensionsAPI") as mock_api_cls:
            mock_api_cls.return_value.list_mcp_definitions.return_value = [_build_mcp()]

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "mcp",
                    "ls",
                    "--workspace",
                    "wk_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    assert json.loads(result.stdout)[0]["id"] == "mcp_123"
    mock_api_cls.return_value.list_mcp_definitions.assert_called_once_with(
        workspace_id="wk_123",
    )


def test_managed_agent_skill_assignment_can_disable() -> None:
    """managed-agent skill assign --disable should forward enabled=False."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentExtensionsAPI") as mock_api_cls:
            mock_api_cls.return_value.set_skill_assignment.return_value = _build_skill()

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "skill",
                    "assign",
                    "ma_123",
                    "skill_123",
                    "--disable",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.set_skill_assignment.assert_called_once_with(
        "ma_123",
        "skill_123",
        enabled=False,
    )


def test_managed_agent_mcp_create_parses_config_and_secret_refs() -> None:
    """managed-agent mcp create should parse JSON options before calling API."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentExtensionsAPI") as mock_api_cls:
            mock_api_cls.return_value.create_mcp_definition.return_value = _build_mcp()

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "mcp",
                    "create",
                    "--name",
                    "GitHub",
                    "--config",
                    '{"command":"npx","args":["-y","@modelcontextprotocol/server-github"]}',
                    "--workspace",
                    "wk_123",
                    "--secret-refs",
                    '{"env":{"GITHUB_TOKEN":"secret_123"}}',
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.create_mcp_definition.assert_called_once_with(
        name="GitHub",
        config={
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-github"],
        },
        workspace_id="wk_123",
        secret_refs={"env": {"GITHUB_TOKEN": "secret_123"}},
    )


def test_managed_agent_mcp_update_forwards_workspace_id() -> None:
    """managed-agent mcp update should pass optional workspace ID through SDK."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentExtensionsAPI") as mock_api_cls:
            mock_api_cls.return_value.update_mcp_definition.return_value = _build_mcp()

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "mcp",
                    "update",
                    "mcp_123",
                    "--name",
                    "GitHub prod",
                    "--workspace",
                    "wk_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.update_mcp_definition.assert_called_once_with(
        "mcp_123",
        name="GitHub prod",
        config=None,
        workspace_id="wk_123",
        secret_refs=None,
    )


def test_managed_agent_mcp_create_rejects_invalid_config_json() -> None:
    """managed-agent mcp create should fail before API calls on invalid JSON."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.ManagedAgentExtensionsAPI") as mock_api_cls:
            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "mcp",
                    "create",
                    "--name",
                    "GitHub",
                    "--config",
                    "[]",
                ],
            )

    assert result.exit_code == 1
    assert "--config must be a JSON object" in result.output
    mock_api_cls.return_value.create_mcp_definition.assert_not_called()


def test_managed_agent_telegram_bind_forwards_expected_fields() -> None:
    """managed-agent telegram bind should create a Telegram bot integration."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.BotIntegrationsAPI") as mock_api_cls:
            mock_api_cls.return_value.create_telegram.return_value = _build_bot_integration()

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "telegram",
                    "bind",
                    "ma_123",
                    "--workspace",
                    "wk_123",
                    "--name",
                    "Telegram Agent",
                    "--bot-token",
                    "123:telegram-bot-token",
                    "--secret-token",
                    "telegram-webhook-secret",
                    "--allow-groups",
                    "--require-mention-in-groups",
                    "--allowed-chat-id",
                    "123",
                    "--bot-username",
                    "agentbot",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    assert json.loads(result.stdout)["id"] == "bi_123"
    mock_api_cls.return_value.create_telegram.assert_called_once_with(
        "wk_123",
        agent_id="ma_123",
        name="Telegram Agent",
        bot_token="123:telegram-bot-token",
        bot_token_key=None,
        secret_token="telegram-webhook-secret",
        secret_token_key=None,
        allow_groups=True,
        require_mention_in_groups=True,
        allowed_chat_ids=["123"],
        bot_username="agentbot",
        owner_user_id=None,
        agent_workspace_group_id=None,
        model=None,
        instructions=None,
    )


def test_managed_agent_telegram_ls_filters_provider() -> None:
    """managed-agent telegram ls should show only Telegram integrations."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.BotIntegrationsAPI") as mock_api_cls:
            mock_api_cls.return_value.list_all.return_value = [
                _build_bot_integration(id="bi_telegram", provider="telegram"),
                _build_bot_integration(id="bi_slack", provider="slack"),
            ]

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "telegram",
                    "ls",
                    "--workspace",
                    "wk_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert [item["id"] for item in payload] == ["bi_telegram"]
    mock_api_cls.return_value.list_all.assert_called_once_with("wk_123")


def test_managed_agent_telegram_list_alias_accepts_options() -> None:
    """managed-agent telegram list alias should mirror ls options."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.BotIntegrationsAPI") as mock_api_cls:
            mock_api_cls.return_value.list_all.return_value = [
                _build_bot_integration(id="bi_telegram", provider="telegram"),
            ]

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "telegram",
                    "list",
                    "--workspace",
                    "wk_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    assert json.loads(result.stdout)[0]["id"] == "bi_telegram"
    mock_api_cls.return_value.list_all.assert_called_once_with("wk_123")


def test_managed_agent_telegram_sync_webhook_forwards_drop_option() -> None:
    """managed-agent telegram sync-webhook should call the Telegram sync endpoint."""
    result_payload = {"success": True, "webhookUrl": "https://api.example.com/hook"}
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.BotIntegrationsAPI") as mock_api_cls:
            mock_api_cls.return_value.sync_telegram_webhook.return_value = result_payload

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "telegram",
                    "sync-webhook",
                    "bi_123",
                    "--workspace",
                    "wk_123",
                    "--drop-pending-updates",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.sync_telegram_webhook.assert_called_once_with(
        "wk_123",
        "bi_123",
        drop_pending_updates=True,
    )


def test_managed_agent_telegram_enable_forwards_to_api() -> None:
    """managed-agent telegram enable should enable a disabled binding."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.BotIntegrationsAPI") as mock_api_cls:
            mock_api_cls.return_value.enable.return_value = _build_bot_integration()

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "telegram",
                    "enable",
                    "bi_123",
                    "--workspace",
                    "wk_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api_cls.return_value.enable.assert_called_once_with("wk_123", "bi_123")


def test_managed_agent_telegram_unbind_forwards_to_api() -> None:
    """managed-agent telegram unbind should disable a binding."""
    with patch("agentenv.cli.managed_agent.get_client", return_value=Mock()):
        with patch("agentenv.cli.managed_agent.BotIntegrationsAPI") as mock_api_cls:
            mock_api_cls.return_value.disable.return_value = _build_bot_integration(
                status="disabled"
            )

            result = runner.invoke(
                app,
                [
                    "managed-agent",
                    "telegram",
                    "unbind",
                    "bi_123",
                    "--workspace",
                    "wk_123",
                    "--json",
                ],
            )

    assert result.exit_code == 0
    assert json.loads(result.stdout)["status"] == "disabled"
    mock_api_cls.return_value.disable.assert_called_once_with("wk_123", "bi_123")
