"""Tests for workflow CLI commands."""

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import Mock, patch
import json

from typer.testing import CliRunner

from agentenv.api.models import (
    Workflow,
    WorkflowDefinition,
    WorkflowExecution,
    WorkflowMetrics,
    WorkflowNodeDefinition,
    WorkflowNodeDefinitionLight,
    WorkflowNodeHandler,
    WorkflowNodeSchemas,
    WorkflowNodeSecrets,
    WorkflowTimeSeriesPoint,
    WorkflowWebhookEndpoint,
)
from agentenv.cli.app import app

runner = CliRunner()


def _make_workflow() -> Workflow:
    now = datetime.now(UTC)
    return Workflow(
        id="51699bcc-7308-4715-a0e8-aa375806e264",
        workspaceId="ff80914b-eb24-4d3d-b6d8-8a149dc91a10",
        name="daily-sync",
        description="sync workflow",
        version=3,
        status="draft",
        definition=WorkflowDefinition(nodes=[], edges=[]),
        publishedDefinition=None,
        publishedAt=None,
        createdAt=now,
        updatedAt=now,
    )


def _make_execution() -> WorkflowExecution:
    now = datetime.now(UTC)
    return WorkflowExecution(
        id="exec_123",
        workflowId="wf_123",
        workflowVersion=3,
        status="completed",
        input={"customerId": "cus_123"},
        output={"ok": True},
        nodeOutputs={"node-1": {"ok": True}},
        nodeErrors={},
        startedAt=now,
        completedAt=now,
        createdAt=now,
        error=None,
    )


def test_workflow_ls_json_uses_default_workspace_and_outputs_full_ids() -> None:
    """workflow ls --json should use the configured workspace and print full IDs."""
    workflow = _make_workflow()
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
            with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
                mock_api = mock_api_cls.return_value
                mock_api.list_all.return_value = [workflow]

                result = runner.invoke(app, ["workflow", "ls", "--json"])

    assert result.exit_code == 0
    assert workflow.id in result.output
    assert workflow.workspace_id in result.output
    mock_api.list_all.assert_called_once_with("wk_default", status=None)


def test_workflow_ls_global_json_outputs_machine_readable_payload() -> None:
    """Global --json should make workflow ls emit JSON instead of a Rich table."""
    workflow = _make_workflow()
    settings = SimpleNamespace(
        workspace="wk_default",
        is_authenticated=Mock(return_value=True),
        api_url="http://test",
        api_key=None,
        access_token="tok",
        json_output=True,
    )

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            with patch("agentenv.cli.workflow.Client"):
                mock_api = mock_api_cls.return_value
                mock_api.list_all.return_value = [workflow]

                result = runner.invoke(app, ["--json", "workflow", "ls"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload[0]["id"] == workflow.id
    mock_api.list_all.assert_called_once_with("wk_default", status=None)


def test_workflow_create_reads_definition_file(tmp_path) -> None:
    """workflow create should parse the definition file and pass it to the API."""
    definition_path = tmp_path / "workflow.json"
    definition_path.write_text(
        '{"nodes":[{"id":"trigger-1","type":"webhook","config":{}}],"edges":[]}',
        encoding="utf-8",
    )
    workflow = _make_workflow()
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
            with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
                mock_api = mock_api_cls.return_value
                mock_api.create.return_value = workflow

                result = runner.invoke(
                    app,
                    [
                        "workflow",
                        "create",
                        "daily-sync",
                        "--file",
                        str(definition_path),
                        "--json",
                    ],
                )

    assert result.exit_code == 0
    mock_api.create.assert_called_once_with(
        "wk_default",
        name="daily-sync",
        definition={
            "nodes": [{"id": "trigger-1", "type": "webhook", "config": {}}],
            "edges": [],
        },
        description=None,
    )


def test_workflow_create_global_json_outputs_created_workflow(tmp_path) -> None:
    """Global --json should make workflow create emit JSON."""
    definition_path = tmp_path / "workflow.json"
    definition_path.write_text('{"nodes":[],"edges":[]}', encoding="utf-8")
    workflow = _make_workflow()
    settings = SimpleNamespace(
        workspace="wk_default",
        is_authenticated=Mock(return_value=True),
        api_url="http://test",
        api_key=None,
        access_token="tok",
        json_output=True,
    )

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            with patch("agentenv.cli.workflow.Client"):
                mock_api = mock_api_cls.return_value
                mock_api.create.return_value = workflow

                result = runner.invoke(
                    app,
                    ["--json", "workflow", "create", "daily-sync", "--file", str(definition_path)],
                )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["id"] == workflow.id


def test_workflow_execute_reads_input_file(tmp_path) -> None:
    """workflow execute should parse structured input files."""
    input_path = tmp_path / "input.json"
    input_path.write_text('{"customerId":"cus_123","amount":42}', encoding="utf-8")

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.execute.return_value = {"executionId": "exec_123"}

            result = runner.invoke(
                app,
                [
                    "workflow",
                    "execute",
                    "wf_123",
                    "--input-file",
                    str(input_path),
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api.execute.assert_called_once_with(
        "wf_123",
        input_data={"customerId": "cus_123", "amount": 42},
        trigger_node_id=None,
    )
    assert "exec_123" in result.output


def test_workflow_execute_wait_json_outputs_final_execution_payload() -> None:
    """workflow execute --wait --json should poll and emit the final execution payload."""
    pending = _make_execution().model_copy(update={"status": "pending", "output": None, "completed_at": None})
    completed = _make_execution()

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            with patch("agentenv.cli.workflow.time.sleep") as mock_sleep:
                mock_api = mock_api_cls.return_value
                mock_api.execute.return_value = {"executionId": "exec_123"}
                mock_api.get_execution.side_effect = [pending, completed]

                result = runner.invoke(
                    app,
                    ["workflow", "execute", "wf_123", "--wait", "--json"],
                )

    assert result.exit_code == 0
    mock_api.execute.assert_called_once_with(
        "wf_123",
        input_data=None,
        trigger_node_id=None,
    )
    assert mock_api.get_execution.call_count == 2
    mock_sleep.assert_called_once_with(2.0)
    payload = json.loads(result.output)
    assert payload["id"] == "exec_123"
    assert payload["nodeOutputs"]["node-1"]["ok"] is True


def test_workflow_execute_wait_timeout_surfaces_timeout_error() -> None:
    """workflow execute --wait should fail with TIMEOUT when polling exceeds the timeout."""
    pending = _make_execution().model_copy(update={"status": "running", "output": None, "completed_at": None})

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            with (
                patch("agentenv.cli.workflow.time.sleep"),
                patch("agentenv.cli.workflow.time.monotonic", side_effect=[0.0, 0.0, 2.0]),
            ):
                mock_api = mock_api_cls.return_value
                mock_api.execute.return_value = {"executionId": "exec_123"}
                mock_api.get_execution.return_value = pending

                result = runner.invoke(
                    app,
                    ["workflow", "execute", "wf_123", "--wait", "--timeout", "1", "--json"],
                )

    assert result.exit_code == 1
    payload = json.loads(result.output)
    assert payload["error"]["code"] == "TIMEOUT"
    assert "timed out" in payload["error"]["message"]


def test_workflow_execute_wait_does_not_oversleep_past_timeout() -> None:
    """workflow execute --wait should cap sleep to the remaining timeout budget."""
    pending = _make_execution().model_copy(update={"status": "running", "output": None, "completed_at": None})

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            with (
                patch("agentenv.cli.workflow.time.sleep") as mock_sleep,
                patch("agentenv.cli.workflow.time.monotonic", side_effect=[0.0, 0.0, 1.0]),
            ):
                mock_api = mock_api_cls.return_value
                mock_api.execute.return_value = {"executionId": "exec_123"}
                mock_api.get_execution.return_value = pending

                result = runner.invoke(
                    app,
                    [
                        "workflow",
                        "execute",
                        "wf_123",
                        "--wait",
                        "--timeout",
                        "1",
                        "--poll-interval",
                        "5",
                        "--json",
                    ],
                )

    assert result.exit_code == 1
    mock_sleep.assert_called_once_with(1.0)
    payload = json.loads(result.output)
    assert payload["error"]["code"] == "TIMEOUT"


def test_workflow_deploy_calls_api() -> None:
    """workflow deploy should call the renamed API method."""
    workflow = _make_workflow()

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.deploy.return_value = workflow

            result = runner.invoke(app, ["workflow", "deploy", "wf_123", "--json"])

    assert result.exit_code == 0
    mock_api.deploy.assert_called_once_with("wf_123")
    assert workflow.id in result.output


def test_workflow_undeploy_calls_api() -> None:
    """workflow undeploy should call the API and emit the workflow payload."""
    workflow = _make_workflow()

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.undeploy.return_value = workflow

            result = runner.invoke(app, ["workflow", "undeploy", "wf_123", "--json"])

    assert result.exit_code == 0
    mock_api.undeploy.assert_called_once_with("wf_123")
    payload = json.loads(result.output)
    assert payload["id"] == workflow.id


def test_workflow_update_requires_changes() -> None:
    """workflow update should fail when no changes are provided."""
    result = runner.invoke(app, ["workflow", "update", "wf_123"])

    assert result.exit_code == 1
    assert "No updates specified" in result.output


def test_workflow_rm_json_preserves_backend_payload() -> None:
    """workflow rm --json should emit the backend action payload without rewriting it."""
    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.delete.return_value = {
                "id": "wf_123",
                "success": True,
                "action": "delete",
                "deletedAt": "2026-04-07T00:00:00Z",
            }

            result = runner.invoke(app, ["workflow", "rm", "wf_123", "--force", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["deletedAt"] == "2026-04-07T00:00:00Z"


def test_workflow_delete_alias_matches_rm() -> None:
    """workflow delete should remain a hidden alias for workflow rm."""
    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.delete.return_value = {"id": "wf_123", "success": True}

            result = runner.invoke(app, ["workflow", "delete", "wf_123", "--force", "--json"])

    assert result.exit_code == 0
    mock_api.delete.assert_called_once_with("wf_123")


def test_workflow_ls_rejects_invalid_status() -> None:
    """workflow ls should validate status filters before making API calls."""
    result = runner.invoke(app, ["workflow", "ls", "--status", "paused"])

    assert result.exit_code == 1
    assert "Invalid status 'paused'" in result.output


def test_workflow_create_rejects_non_object_definition() -> None:
    """workflow create should reject non-object workflow definitions before the API call."""
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        result = runner.invoke(
            app,
            [
                "workflow",
                "create",
                "daily-sync",
                "--definition",
                '["not","an","object"]',
            ],
        )

    assert result.exit_code == 1
    assert "workflow definition must be a JSON object" in result.output


def test_workflow_execute_rejects_non_object_input() -> None:
    """workflow execute should reject non-object input before hitting the API."""
    result = runner.invoke(
        app,
        [
            "workflow",
            "execute",
            "wf_123",
            "--input",
            '["bad"]',
        ],
    )

    assert result.exit_code == 1
    assert "execution input must be a JSON object" in result.output


def test_workflow_execute_in_memory_reads_definition_and_input_files(tmp_path) -> None:
    """workflow execute-in-memory should parse definition and input files."""
    definition_path = tmp_path / "workflow.json"
    definition_path.write_text(
        '{"nodes":[{"id":"trigger","type":"webhook","config":{}}],"edges":[]}',
        encoding="utf-8",
    )
    input_path = tmp_path / "input.json"
    input_path.write_text('{"customerId":"cus_123"}', encoding="utf-8")

    settings = SimpleNamespace(workspace="wk_default")
    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
            with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
                mock_api = mock_api_cls.return_value
                mock_api.execute_in_memory.return_value = {
                    "status": "completed",
                    "duration": 12,
                    "output": {"ok": True},
                }

                result = runner.invoke(
                    app,
                    [
                        "workflow",
                        "execute-in-memory",
                        "--file",
                        str(definition_path),
                        "--input-file",
                        str(input_path),
                        "--json",
                    ],
                )

    assert result.exit_code == 0
    mock_api.execute_in_memory.assert_called_once_with(
        "wk_default",
        {
            "nodes": [{"id": "trigger", "type": "webhook", "config": {}}],
            "edges": [],
        },
        input_data={"customerId": "cus_123"},
        trigger_node_id=None,
    )
    payload = json.loads(result.output)
    assert payload["status"] == "completed"


def test_workflow_execute_in_memory_rejects_non_object_input(tmp_path) -> None:
    """workflow execute-in-memory should reject non-object execution input."""
    definition_path = tmp_path / "workflow.json"
    definition_path.write_text(
        '{"nodes":[{"id":"trigger","type":"webhook","config":{}}],"edges":[]}',
        encoding="utf-8",
    )
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        result = runner.invoke(
            app,
            [
                "workflow",
                "execute-in-memory",
                "--file",
                str(definition_path),
                "--input",
                '"bad"',
            ],
        )

    assert result.exit_code == 1
    assert "execution input must be a JSON object" in result.output


def test_workflow_executions_json_outputs_data_and_pagination() -> None:
    """workflow executions --json should emit the API execution list envelope."""
    execution = _make_execution()

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.list_executions.return_value = (
                [execution],
                {"page": 2, "limit": 1, "total": 3},
            )

            result = runner.invoke(
                app,
                ["workflow", "executions", "wf_123", "--page", "2", "--limit", "1", "--json"],
            )

    assert result.exit_code == 0
    mock_api.list_executions.assert_called_once_with(
        "wf_123",
        page=2,
        limit=1,
        status=None,
        from_time=None,
        to_time=None,
    )
    payload = json.loads(result.output)
    assert payload["data"][0]["id"] == "exec_123"
    assert payload["pagination"]["total"] == 3


def test_workflow_executions_reject_invalid_status_filters() -> None:
    """workflow executions should validate comma-separated status filters before hitting the API."""
    result = runner.invoke(app, ["workflow", "executions", "wf_123", "--status", "running,paused"])

    assert result.exit_code == 1
    assert "Invalid execution status filter(s): paused" in result.output


def test_workflow_execution_json_outputs_execution_payload() -> None:
    """workflow execution --json should emit the serialized execution."""
    execution = _make_execution()

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.get_execution.return_value = execution

            result = runner.invoke(app, ["workflow", "execution", "wf_123", "exec_123", "--json"])

    assert result.exit_code == 0
    mock_api.get_execution.assert_called_once_with("wf_123", "exec_123")
    payload = json.loads(result.output)
    assert payload["nodeOutputs"]["node-1"]["ok"] is True


def test_workflow_cancel_json_preserves_backend_payload() -> None:
    """workflow cancel --json should emit the backend action payload without rewriting it."""
    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.cancel_execution.return_value = {
                "workflowId": "wf_123",
                "executionId": "exec_123",
                "success": True,
                "action": "cancel",
                "status": "pending_cancellation",
            }

            result = runner.invoke(
                app,
                ["workflow", "cancel", "wf_123", "exec_123", "--json"],
            )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "pending_cancellation"


def test_workflow_metrics_json_outputs_metric_payload() -> None:
    """workflow metrics --json should emit serialized metrics."""
    metrics = WorkflowMetrics(
        total=10,
        pending=1,
        running=2,
        completed=6,
        failed=1,
        successRate=85.71,
        avgDurationMs=1200,
    )

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.get_metrics.return_value = metrics

            result = runner.invoke(app, ["workflow", "metrics", "wf_123", "--json"])

    assert result.exit_code == 0
    mock_api.get_metrics.assert_called_once_with("wf_123", from_time=None, to_time=None)
    payload = json.loads(result.output)
    assert payload["successRate"] == 85.71
    assert payload["avgDurationMs"] == 1200


def test_workflow_metrics_timeseries_json_outputs_points() -> None:
    """workflow metrics-timeseries --json should emit the serialized point list."""
    points = [
        WorkflowTimeSeriesPoint(timestamp="2026-04-07T00:00:00Z", count=3),
        WorkflowTimeSeriesPoint(timestamp="2026-04-07T01:00:00Z", count=5),
    ]

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.get_time_series.return_value = points

            result = runner.invoke(
                app,
                ["workflow", "metrics-timeseries", "wf_123", "--interval", "hour", "--json"],
            )

    assert result.exit_code == 0
    mock_api.get_time_series.assert_called_once_with(
        "wf_123",
        interval="hour",
        from_time=None,
        to_time=None,
    )
    payload = json.loads(result.output)
    assert payload[1]["count"] == 5


def test_workflow_node_definitions_json_outputs_definitions() -> None:
    """workflow node-definitions --json should emit the serialized definition list."""
    definitions = [
        WorkflowNodeDefinitionLight(
            type="webhook",
            category="triggers",
            name="Webhook",
            description="Receives inbound requests",
            trusted=True,
            isBuiltin=True,
        )
    ]

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.list_node_definitions.return_value = definitions

            result = runner.invoke(app, ["workflow", "node-definitions", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload[0]["isBuiltin"] is True


def test_workflow_node_definition_json_outputs_definition_detail() -> None:
    """workflow node-definition --json should emit the serialized definition detail."""
    definition = WorkflowNodeDefinition(
        type="webhook",
        category="triggers",
        name="Webhook",
        description="Receives inbound requests",
        trusted=True,
        isBuiltin=True,
        schemas=WorkflowNodeSchemas(
            config={"type": "object"},
            input={"type": "object"},
            output={"type": "object"},
        ),
        handler=WorkflowNodeHandler(type="builtin", service="workflow", method="webhook"),
        secrets=WorkflowNodeSecrets(required=[], optional=[]),
    )

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.get_node_definition.return_value = definition

            result = runner.invoke(app, ["workflow", "node-definition", "webhook", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["handler"]["method"] == "webhook"


def test_workflow_plugins_json_outputs_plugins() -> None:
    """workflow plugins --json should emit the trusted plugin list."""
    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.list_trusted_plugins.return_value = ["openai", "github"]

            result = runner.invoke(app, ["workflow", "plugins", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload == ["openai", "github"]


def test_workflow_ls_json_auth_error_stays_machine_readable() -> None:
    """workflow ls --json should emit JSON for auth failures too."""
    settings = SimpleNamespace(
        workspace="wk_default",
        is_authenticated=Mock(return_value=False),
        api_url="http://test",
        api_key=None,
        access_token=None,
    )

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        result = runner.invoke(app, ["workflow", "ls", "--json"])

    assert result.exit_code == 1
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "AUTH_REQUIRED"
    assert "Not authenticated" in payload["error"]["message"]


def test_workflow_rm_json_requires_force_without_prompting() -> None:
    """workflow rm --json should fail with JSON instead of interactive confirmation."""
    result = runner.invoke(app, ["workflow", "rm", "wf_123", "--json"])

    assert result.exit_code == 1
    payload = json.loads(result.stdout)
    assert payload["error"]["code"] == "INVALID_ARGUMENT"
    assert "--force is required" in payload["error"]["message"]


def test_workflow_inspect_json_includes_webhook_endpoints() -> None:
    """workflow inspect --json should preserve webhook endpoint metadata."""
    workflow = _make_workflow().model_copy(
        update={
            "webhook_endpoints": [
                WorkflowWebhookEndpoint(
                    nodeId="trigger-1",
                    nodeType="webhook",
                    nodeName="Incoming Webhook",
                    path="wf_123/trigger-1/openai",
                    relativeUrl="/v1/webhooks/v1/wf_123/trigger-1/openai",
                    methods=["POST"],
                    isActive=True,
                )
            ]
        }
    )

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.get.return_value = workflow

            result = runner.invoke(app, ["workflow", "inspect", "wf_123", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["webhookEndpoints"][0]["relativeUrl"] == "/v1/webhooks/v1/wf_123/trigger-1/openai"
