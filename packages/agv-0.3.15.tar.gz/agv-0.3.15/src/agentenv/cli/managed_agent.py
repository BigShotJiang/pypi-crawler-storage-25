"""Managed-agent CLI commands."""

from __future__ import annotations

import json
import sys
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import typer

from ..api.bot_integrations import BotIntegrationsAPI
from ..api.client import APIError, Client
from ..api.extensions import ManagedAgentExtensionsAPI
from ..api.managed_agent import ManagedAgentAPI
from ..api.models import (
    BotIntegration,
    ManagedAgent,
    ManagedAgentListResponse,
    ManagedAgentMcpDefinition,
    ManagedAgentMessage,
    ManagedAgentSkillAsset,
    ManagedAgentStreamEvent,
)
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    _colored_status,
    _format_datetime,
    emit_json,
    json_output_enabled,
    print_browser_table,
    print_error,
    print_success,
)

app = typer.Typer(
    help="Managed-agent commands",
    no_args_is_help=True,
)

skill_app = typer.Typer(help="Managed-agent skill commands", no_args_is_help=True)
mcp_app = typer.Typer(help="Managed-agent MCP server commands", no_args_is_help=True)
telegram_app = typer.Typer(help="Managed-agent Telegram binding commands", no_args_is_help=True)

app.add_typer(skill_app, name="skill")
app.add_typer(skill_app, name="skills")
app.add_typer(mcp_app, name="mcp")
app.add_typer(mcp_app, name="mcps")
app.add_typer(telegram_app, name="telegram")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'agv login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _wants_json(json_output: bool = False) -> bool:
    """Whether the current command should emit JSON."""
    return json_output or json_output_enabled()


def _get_extensions_api() -> ManagedAgentExtensionsAPI:
    """Get the managed-agent extensions API wrapper."""
    return ManagedAgentExtensionsAPI(get_client())


def _get_bot_integrations_api() -> BotIntegrationsAPI:
    """Get the bot integrations API wrapper."""
    return BotIntegrationsAPI(get_client())


def _resolve_workspace_id(workspace_id: str | None) -> str:
    """Resolve workspace ID from an option or selected CLI workspace."""
    resolved = workspace_id or get_settings().workspace
    if resolved:
        return resolved
    print_error("No workspace specified. Use --workspace or set one with 'agv workspace use'.")
    raise typer.Exit(1)


def _parse_json_object(value: str, *, option_name: str) -> dict[str, Any]:
    """Parse a CLI JSON object option."""
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        print_error(f"{option_name} must be valid JSON: {exc.msg}")
        raise typer.Exit(1) from exc
    if not isinstance(parsed, dict):
        print_error(f"{option_name} must be a JSON object.")
        raise typer.Exit(1)
    return parsed


def _assignment_summary(assignments: Iterable[Any]) -> str:
    """Render assignment counts for compact list tables."""
    assignment_list = list(assignments or [])
    if not assignment_list:
        return "0 enabled"
    enabled = sum(1 for assignment in assignment_list if getattr(assignment, "enabled", False))
    return f"{enabled} enabled / {len(assignment_list)} total"


def _mcp_transport(config: dict[str, Any]) -> str:
    """Infer the MCP transport label from a Codex MCP config object."""
    if "command" in config:
        return "stdio"
    if "url" in config:
        return "url"
    return "-"


def _print_skill_table(
    skills: list[ManagedAgentSkillAsset],
    *,
    json_output: bool = False,
) -> None:
    """Render managed-agent skill assets."""
    if _wants_json(json_output):
        emit_json(skills)
        return

    from rich.console import Console
    from rich.table import Table

    if not skills:
        Console().print("[dim]No managed-agent skills found.[/dim]")
        return

    table = Table(title=f"Managed-Agent Skills ({len(skills)})")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Slug")
    table.add_column("SHA256", no_wrap=True)
    table.add_column("Assignments", no_wrap=True)
    table.add_column("Updated", no_wrap=True)

    for skill in skills:
        table.add_row(
            skill.id,
            skill.name,
            skill.slug,
            skill.sha256[:12],
            _assignment_summary(skill.assignments),
            _format_datetime(skill.updated_at),
        )

    Console().print(table)


def _print_mcp_table(
    definitions: list[ManagedAgentMcpDefinition],
    *,
    json_output: bool = False,
) -> None:
    """Render managed-agent MCP definitions."""
    if _wants_json(json_output):
        emit_json(definitions)
        return

    from rich.console import Console
    from rich.table import Table

    if not definitions:
        Console().print("[dim]No managed-agent MCP servers found.[/dim]")
        return

    table = Table(title=f"Managed-Agent MCP Servers ({len(definitions)})")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Slug")
    table.add_column("Workspace", no_wrap=True)
    table.add_column("Transport", no_wrap=True)
    table.add_column("Assignments", no_wrap=True)
    table.add_column("Updated", no_wrap=True)

    for definition in definitions:
        table.add_row(
            definition.id,
            definition.name,
            definition.slug,
            definition.workspace_id or "-",
            _mcp_transport(definition.config),
            _assignment_summary(definition.assignments),
            _format_datetime(definition.updated_at),
        )

    Console().print(table)


def _print_telegram_table(
    integrations: list[BotIntegration],
    *,
    json_output: bool = False,
) -> None:
    """Render Telegram integrations bound to managed agents."""
    if _wants_json(json_output):
        emit_json(integrations)
        return

    from rich.console import Console
    from rich.table import Table

    if not integrations:
        Console().print("[dim]No managed-agent Telegram bindings found.[/dim]")
        return

    table = Table(title=f"Managed-Agent Telegram Bindings ({len(integrations)})")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Status", no_wrap=True)
    table.add_column("Agent", no_wrap=True)
    table.add_column("Bot")
    table.add_column("Webhook")
    table.add_column("Updated", no_wrap=True)

    for integration in integrations:
        config = integration.provider_config or {}
        bot_username = config.get("botUsername") or "-"
        table.add_row(
            integration.id,
            integration.name,
            _colored_status(integration.status),
            integration.fixed_agent_id,
            str(bot_username),
            integration.webhook_url,
            _format_datetime(integration.updated_at),
        )

    Console().print(table)


def _print_managed_agent_table(
    result: ManagedAgentListResponse,
    *,
    json_output: bool = False,
) -> None:
    """Render a managed-agent list."""
    if _wants_json(json_output):
        emit_json(result)
        return

    from rich.console import Console
    from rich.table import Table

    if not result.agents:
        Console().print("[dim]No managed agents found.[/dim]")
        return

    table = Table(title=f"Managed Agents ({result.total})")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name")
    table.add_column("Status", no_wrap=True)
    table.add_column("Workspace", no_wrap=True)
    table.add_column("Model")
    table.add_column("Updated", no_wrap=True)

    for agent in result.agents:
        table.add_row(
            agent.id,
            agent.name,
            _colored_status(agent.status),
            agent.workspace_id,
            agent.config.model,
            _format_datetime(agent.updated_at),
        )

    Console().print(table)


def _print_managed_agent_detail(
    agent: ManagedAgent,
    *,
    json_output: bool = False,
) -> None:
    """Render managed-agent details."""
    if _wants_json(json_output):
        emit_json(agent)
        return

    from rich.console import Console
    from rich.table import Table

    table = Table(title=f"Managed Agent: {agent.name}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", agent.id)
    table.add_row("Workspace", agent.workspace_id)
    table.add_row("Sandbox", agent.sandbox_id or "-")
    table.add_row("Status", _colored_status(agent.status))
    table.add_row("Upstream", agent.config.upstream_id)
    table.add_row("Model", agent.config.model)
    if agent.public_token:
        table.add_row("Public Token", agent.public_token)
    table.add_row("Instructions", agent.config.instructions or "-")
    table.add_row(
        "CPU / Memory",
        f"{agent.config.cpu_millis or '-'} / {agent.config.memory_mb or '-'}",
    )
    table.add_row("Created", _format_datetime(agent.created_at))
    table.add_row("Updated", _format_datetime(agent.updated_at))

    if agent.metadata:
        table.add_section()
        table.add_row("Thread", agent.metadata.thread_id or "-")
        table.add_row("Runtime WS", agent.metadata.runtime_ws_url or "-")
        table.add_row("Last Error", agent.metadata.last_error or "-")
        table.add_row(
            "Last Activity",
            _format_datetime(agent.metadata.last_activity_at)
            if agent.metadata.last_activity_at
            else "-",
        )

    console = Console()
    console.print(table)
    if agent.public_token:
        console.print(f"Public Token: {agent.public_token}")


def _print_message_table(
    messages: list[ManagedAgentMessage],
    *,
    json_output: bool = False,
) -> None:
    """Render transcript messages."""
    if _wants_json(json_output):
        emit_json(messages)
        return

    from rich.console import Console
    from rich.table import Table

    if not messages:
        Console().print("[dim]No managed-agent messages found.[/dim]")
        return

    table = Table(title="Managed Agent Messages")
    table.add_column("Created", no_wrap=True)
    table.add_column("Role", no_wrap=True)
    table.add_column("Kind", no_wrap=True)
    table.add_column("Content")

    for message in messages:
        content = (message.content or "").strip() or "-"
        table.add_row(
            _format_datetime(message.created_at),
            message.role,
            message.kind,
            content,
        )

    Console().print(table)


def _parse_prompt(prompt: list[str] | None) -> str:
    """Normalize free-form message content."""
    content = " ".join(prompt).strip() if prompt else ""
    if content:
        return content
    print_error("Message content is required.")
    raise typer.Exit(1)


def _stream_assistant_output(
    events: Iterable[ManagedAgentStreamEvent],
) -> tuple[list[ManagedAgentStreamEvent], bool]:
    """Render assistant output as events arrive while retaining a fallback copy."""
    deltas_seen: set[str] = set()
    completed_messages: list[str] = []
    printed = False
    collected: list[ManagedAgentStreamEvent] = []

    for event in events:
        collected.append(event)
        payload = event.model_dump(exclude_none=True)
        event_type = payload.get("type")
        message_id = str(payload.get("messageId", "message"))

        if event_type == "message.delta":
            delta = payload.get("delta")
            if isinstance(delta, str) and delta:
                sys.stdout.write(delta)
                sys.stdout.flush()
                deltas_seen.add(message_id)
                printed = True
            continue

        if event_type == "message.completed" and payload.get("content"):
            if message_id in deltas_seen:
                continue
            completed_messages.append(str(payload["content"]))

    if printed:
        if completed_messages:
            sys.stdout.write("\n\n" + "\n\n".join(completed_messages))
        sys.stdout.write("\n")
        sys.stdout.flush()
        return collected, True

    if completed_messages:
        print("\n\n".join(completed_messages))
        return collected, True

    return collected, False


def _emit_stream_events(events: Iterable[ManagedAgentStreamEvent]) -> None:
    """Print raw stream events one JSON object per line."""
    for event in events:
        print(json.dumps(event.model_dump(by_alias=True, exclude_none=True), default=str))


def _wake_before_send(
    api: ManagedAgentAPI,
    agent_id: str,
    *,
    timeout: float,
) -> None:
    """Wake a sleeping managed agent before sending a message."""
    agent = api.get(agent_id)
    if agent.status != "sleeping":
        return

    with status(f"Waking managed agent {agent_id}..."):
        try:
            api.wake(agent_id)
        except APIError:
            # The backend may already be waking the agent. Poll the status either way.
            pass
        api.wait_for_status(agent_id, desired_status="running", timeout=timeout)


@app.command("ls")
def list_managed_agents(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    agent_workspace_group_id: str | None = typer.Option(
        None,
        "--agent-workspace-group-id",
        help="Agent workspace group ID",
    ),
    search: str | None = typer.Option(
        None,
        "--search",
        help="Search by agent or workspace group name",
    ),
    page: int | None = typer.Option(None, "--page", min=1, help="Page number"),
    limit: int | None = typer.Option(None, "--limit", min=1, help="Page size"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List managed agents."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        result = api.list_all(
            workspace_id=workspace_id,
            agent_workspace_group_id=agent_workspace_group_id,
            search=search,
            page=page,
            limit=limit,
        )
    except APIError as exc:
        print_error(f"Failed to list managed agents: {exc.message}")
        raise typer.Exit(1)

    _print_managed_agent_table(result, json_output=json_output)


@app.command("list", deprecated=True)
def list_managed_agents_alt() -> None:
    """List managed agents (alias for ls)."""
    list_managed_agents()


@skill_app.command("ls")
def list_skills(
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List managed-agent skill assets."""
    api = _get_extensions_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        skills = api.list_skills(workspace_id=resolved_workspace_id)
    except APIError as exc:
        print_error(f"Failed to list managed-agent skills: {exc.message}")
        raise typer.Exit(1)

    _print_skill_table(skills, json_output=json_output)


@skill_app.command("list", deprecated=True)
def list_skills_alt() -> None:
    """List managed-agent skill assets (alias for ls)."""
    list_skills(workspace_id=None, json_output=False)


@skill_app.command("upload")
def upload_skill(
    file: Path = typer.Argument(
        ...,
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        help="Skill .zip archive containing SKILL.md",
    ),
    name: str | None = typer.Option(None, "--name", help="Display name override"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Upload a managed-agent skill archive."""
    api = _get_extensions_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        with status(f"Uploading skill archive {file}..."):
            skill = api.upload_skill(
                file,
                workspace_id=resolved_workspace_id,
                name=name,
            )
    except APIError as exc:
        print_error(f"Failed to upload managed-agent skill: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(skill)
        return

    print_success(f"Managed-agent skill uploaded: {skill.id}")
    print(f"  Name: {skill.name}")
    print(f"  Slug: {skill.slug}")
    print(f"  SHA256: {skill.sha256}")


@skill_app.command("assign")
def assign_skill(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    skill_id: str = typer.Argument(..., help="Skill asset ID"),
    enabled: bool = typer.Option(
        True,
        "--enable/--disable",
        help="Enable or disable the assignment",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Enable or disable a skill for one managed agent."""
    api = _get_extensions_api()

    try:
        skill = api.set_skill_assignment(agent_id, skill_id, enabled=enabled)
    except APIError as exc:
        print_error(f"Failed to update managed-agent skill assignment: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(skill)
        return

    state = "enabled" if enabled else "disabled"
    print_success(f"Managed-agent skill {skill_id} {state} for {agent_id}")


@skill_app.command("unassign")
def unassign_skill(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    skill_id: str = typer.Argument(..., help="Skill asset ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Disable a skill for one managed agent."""
    assign_skill(
        agent_id=agent_id,
        skill_id=skill_id,
        enabled=False,
        json_output=json_output,
    )


@skill_app.command("rm")
def delete_skill(
    skill_id: str = typer.Argument(..., help="Skill asset ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed-agent skill asset."""
    if not force:
        typer.confirm(f"Delete managed-agent skill {skill_id}?", abort=True)

    api = _get_extensions_api()

    try:
        with status(f"Deleting managed-agent skill {skill_id}..."):
            result = api.delete_skill(skill_id)
    except APIError as exc:
        print_error(f"Failed to delete managed-agent skill: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(result)
        return

    print_success(f"Managed-agent skill {skill_id} deleted")


@skill_app.command("delete", deprecated=True)
def delete_skill_alt(
    skill_id: str = typer.Argument(..., help="Skill asset ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed-agent skill asset (alias for rm)."""
    delete_skill(skill_id=skill_id, force=force, json_output=json_output)


@mcp_app.command("ls")
def list_mcp_definitions(
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List managed-agent MCP server definitions."""
    api = _get_extensions_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        definitions = api.list_mcp_definitions(workspace_id=resolved_workspace_id)
    except APIError as exc:
        print_error(f"Failed to list managed-agent MCP servers: {exc.message}")
        raise typer.Exit(1)

    _print_mcp_table(definitions, json_output=json_output)


@mcp_app.command("list", deprecated=True)
def list_mcp_definitions_alt() -> None:
    """List managed-agent MCP server definitions (alias for ls)."""
    list_mcp_definitions(workspace_id=None, json_output=False)


@mcp_app.command("create")
def create_mcp_definition(
    name: str = typer.Option(..., "--name", help="MCP server display name"),
    config: str = typer.Option(
        ...,
        "--config",
        help='MCP config JSON, e.g. {"command":"npx","args":["-y","server"]}',
    ),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    secret_refs: str | None = typer.Option(
        None,
        "--secret-refs",
        help='Secret refs JSON, e.g. {"env":{"GITHUB_TOKEN":"secret_abc"}}',
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Create a managed-agent MCP server definition."""
    api = _get_extensions_api()
    parsed_config = _parse_json_object(config, option_name="--config")
    parsed_secret_refs = (
        _parse_json_object(secret_refs, option_name="--secret-refs")
        if secret_refs is not None
        else None
    )
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        definition = api.create_mcp_definition(
            name=name,
            config=parsed_config,
            workspace_id=resolved_workspace_id,
            secret_refs=parsed_secret_refs,
        )
    except APIError as exc:
        print_error(f"Failed to create managed-agent MCP server: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(definition)
        return

    print_success(f"Managed-agent MCP server created: {definition.id}")
    print(f"  Name: {definition.name}")
    print(f"  Slug: {definition.slug}")
    print(f"  Transport: {_mcp_transport(definition.config)}")


@mcp_app.command("update")
def update_mcp_definition(
    mcp_id: str = typer.Argument(..., help="MCP definition ID"),
    name: str | None = typer.Option(None, "--name", help="MCP server display name"),
    config: str | None = typer.Option(None, "--config", help="Replacement MCP config JSON"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Existing workspace ID; cannot move a definition between workspaces",
    ),
    secret_refs: str | None = typer.Option(
        None,
        "--secret-refs",
        help="Replacement secret refs JSON",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Update a managed-agent MCP server definition."""
    api = _get_extensions_api()
    parsed_config = (
        _parse_json_object(config, option_name="--config") if config is not None else None
    )
    parsed_secret_refs = (
        _parse_json_object(secret_refs, option_name="--secret-refs")
        if secret_refs is not None
        else None
    )

    try:
        definition = api.update_mcp_definition(
            mcp_id,
            name=name,
            config=parsed_config,
            workspace_id=workspace_id,
            secret_refs=parsed_secret_refs,
        )
    except ValueError as exc:
        print_error(str(exc))
        raise typer.Exit(1)
    except APIError as exc:
        print_error(f"Failed to update managed-agent MCP server: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(definition)
        return

    print_success(f"Managed-agent MCP server updated: {definition.id}")


@mcp_app.command("assign")
def assign_mcp_definition(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    mcp_id: str = typer.Argument(..., help="MCP definition ID"),
    enabled: bool = typer.Option(
        True,
        "--enable/--disable",
        help="Enable or disable the assignment",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Enable or disable an MCP server definition for one managed agent."""
    api = _get_extensions_api()

    try:
        definition = api.set_mcp_assignment(agent_id, mcp_id, enabled=enabled)
    except APIError as exc:
        print_error(f"Failed to update managed-agent MCP assignment: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(definition)
        return

    state = "enabled" if enabled else "disabled"
    print_success(f"Managed-agent MCP server {mcp_id} {state} for {agent_id}")


@mcp_app.command("unassign")
def unassign_mcp_definition(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    mcp_id: str = typer.Argument(..., help="MCP definition ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Disable an MCP server definition for one managed agent."""
    assign_mcp_definition(
        agent_id=agent_id,
        mcp_id=mcp_id,
        enabled=False,
        json_output=json_output,
    )


@mcp_app.command("rm")
def delete_mcp_definition(
    mcp_id: str = typer.Argument(..., help="MCP definition ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed-agent MCP server definition."""
    if not force:
        typer.confirm(f"Delete managed-agent MCP server {mcp_id}?", abort=True)

    api = _get_extensions_api()

    try:
        with status(f"Deleting managed-agent MCP server {mcp_id}..."):
            result = api.delete_mcp_definition(mcp_id)
    except APIError as exc:
        print_error(f"Failed to delete managed-agent MCP server: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(result)
        return

    print_success(f"Managed-agent MCP server {mcp_id} deleted")


@mcp_app.command("delete", deprecated=True)
def delete_mcp_definition_alt(
    mcp_id: str = typer.Argument(..., help="MCP definition ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed-agent MCP server definition (alias for rm)."""
    delete_mcp_definition(mcp_id=mcp_id, force=force, json_output=json_output)


@telegram_app.command("bind")
def bind_telegram(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    name: str | None = typer.Option(
        None,
        "--name",
        help="Telegram binding display name",
    ),
    bot_token: str | None = typer.Option(
        None,
        "--bot-token",
        envvar="TELEGRAM_BOT_TOKEN",
        help="Telegram bot token",
    ),
    bot_token_key: str | None = typer.Option(
        None,
        "--bot-token-key",
        help="Deprecated: workspace secret key containing the Telegram bot token",
    ),
    secret_token: str | None = typer.Option(
        None,
        "--secret-token",
        help="Telegram webhook secret token",
    ),
    secret_token_key: str | None = typer.Option(
        None,
        "--secret-token-key",
        help="Deprecated: workspace secret key containing Telegram webhook secret token",
    ),
    allow_groups: bool | None = typer.Option(
        None,
        "--allow-groups/--no-allow-groups",
        help="Allow Telegram group chats",
    ),
    require_mention_in_groups: bool | None = typer.Option(
        None,
        "--require-mention-in-groups/--no-require-mention-in-groups",
        help="Require @bot mention in group chats",
    ),
    allowed_chat_ids: list[str] | None = typer.Option(
        None,
        "--allowed-chat-id",
        help="Allowed Telegram chat ID; may be repeated",
    ),
    bot_username: str | None = typer.Option(
        None,
        "--bot-username",
        help="Telegram bot username, required when enforcing group mentions",
    ),
    owner_user_id: str | None = typer.Option(None, "--owner-user-id", help="Owner user ID"),
    agent_workspace_group_id: str | None = typer.Option(
        None,
        "--agent-workspace-group-id",
        help="Agent workspace group ID",
    ),
    model: str | None = typer.Option(None, "--model", help="Default model for bot turns"),
    instructions: str | None = typer.Option(
        None,
        "--instructions",
        help="Optional instructions for bot turns",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Bind a managed agent to a Telegram bot integration."""
    api = _get_bot_integrations_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    if not bot_token and not bot_token_key:
        print_error("Provide --bot-token (or legacy --bot-token-key).")
        raise typer.Exit(1)

    try:
        with status(f"Binding managed agent {agent_id} to Telegram..."):
            integration = api.create_telegram(
                resolved_workspace_id,
                agent_id=agent_id,
                name=name or f"Telegram {agent_id}",
                bot_token=bot_token,
                bot_token_key=bot_token_key,
                secret_token=secret_token,
                secret_token_key=secret_token_key,
                allow_groups=allow_groups,
                require_mention_in_groups=require_mention_in_groups,
                allowed_chat_ids=allowed_chat_ids,
                bot_username=bot_username,
                owner_user_id=owner_user_id,
                agent_workspace_group_id=agent_workspace_group_id,
                model=model,
                instructions=instructions,
            )
    except APIError as exc:
        print_error(f"Failed to bind managed agent to Telegram: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(integration)
        return

    print_success(f"Telegram binding created: {integration.id}")
    print(f"  Agent: {integration.fixed_agent_id}")
    print(f"  Status: {integration.status}")
    print(f"  Webhook URL: {integration.webhook_url}")


@telegram_app.command("ls")
def list_telegram_bindings(
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List Telegram bindings for a workspace."""
    api = _get_bot_integrations_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        integrations = [
            item for item in api.list_all(resolved_workspace_id) if item.provider == "telegram"
        ]
    except APIError as exc:
        print_error(f"Failed to list Telegram bindings: {exc.message}")
        raise typer.Exit(1)

    _print_telegram_table(integrations, json_output=json_output)


@telegram_app.command("list", deprecated=True)
def list_telegram_bindings_alt(
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List Telegram bindings (alias for ls)."""
    list_telegram_bindings(workspace_id=workspace_id, json_output=json_output)


@telegram_app.command("inspect")
def inspect_telegram_binding(
    integration_id: str = typer.Argument(..., help="Bot integration ID"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show a Telegram binding."""
    api = _get_bot_integrations_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        integration = api.get(resolved_workspace_id, integration_id)
    except APIError as exc:
        print_error(f"Failed to get Telegram binding: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(integration)
        return

    _print_telegram_table([integration], json_output=False)


@telegram_app.command("sync-webhook")
def sync_telegram_webhook(
    integration_id: str = typer.Argument(..., help="Bot integration ID"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    drop_pending_updates: bool | None = typer.Option(
        None,
        "--drop-pending-updates/--keep-pending-updates",
        help="Drop pending Telegram updates when setting webhook",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Sync Telegram webhook + commands for a binding."""
    api = _get_bot_integrations_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        result = api.sync_telegram_webhook(
            resolved_workspace_id,
            integration_id,
            drop_pending_updates=drop_pending_updates,
        )
    except APIError as exc:
        print_error(f"Failed to sync Telegram webhook: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(result)
        return

    print_success("Telegram webhook synced")
    print(f"  Webhook URL: {result.webhook_url}")


@telegram_app.command("unbind")
def unbind_telegram(
    integration_id: str = typer.Argument(..., help="Bot integration ID"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Disable a Telegram binding."""
    api = _get_bot_integrations_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        integration = api.disable(resolved_workspace_id, integration_id)
    except APIError as exc:
        print_error(f"Failed to disable Telegram binding: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(integration)
        return

    print_success(f"Telegram binding disabled: {integration.id}")


@telegram_app.command("enable")
def enable_telegram(
    integration_id: str = typer.Argument(..., help="Bot integration ID"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to selected workspace)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Enable a Telegram binding."""
    api = _get_bot_integrations_api()
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        integration = api.enable(resolved_workspace_id, integration_id)
    except APIError as exc:
        print_error(f"Failed to enable Telegram binding: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(integration)
        return

    print_success(f"Telegram binding enabled: {integration.id}")


@app.command("create")
def create_managed_agent(
    name: str = typer.Option(..., "--name", help="Managed-agent name"),
    workspace_id: str = typer.Option(..., "--workspace", "-w", help="Workspace ID"),
    upstream_id: str = typer.Option(..., "--upstream-id", help="AI gateway upstream ID"),
    model: str | None = typer.Option(None, "--model", help="Model override"),
    instructions: str | None = typer.Option(
        None,
        "--instructions",
        help="Developer instructions",
    ),
    image: str | None = typer.Option(
        None,
        "--image",
        help="Managed-agent image override",
    ),
    workspace_template: str | None = typer.Option(
        None,
        "--workspace-template",
        help="Bundled workspace template name when enabled by the server",
    ),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    agent_workspace_group_id: str | None = typer.Option(
        None,
        "--agent-workspace-group-id",
        help="Agent workspace group ID",
    ),
    enabled_skill_ids: list[str] | None = typer.Option(
        None,
        "--skill-id",
        help="Skill ID to enable at creation. Repeat to select multiple skills; omit to enable all workspace skills.",
    ),
    enabled_mcp_ids: list[str] | None = typer.Option(
        None,
        "--mcp-id",
        help="MCP definition ID to enable at creation. Repeat to select multiple MCP definitions; omit to enable all workspace MCP definitions.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Create a managed agent using --image or the server default."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Creating managed agent '{name}'..."):
            agent = api.create(
                name=name,
                workspace_id=workspace_id,
                upstream_id=upstream_id,
                model=model,
                instructions=instructions,
                image=image,
                workspace_template=workspace_template,
                cpu_millis=cpu,
                memory_mb=memory,
                agent_workspace_group_id=agent_workspace_group_id,
                enabled_skill_ids=enabled_skill_ids,
                enabled_mcp_ids=enabled_mcp_ids,
            )
    except APIError as exc:
        print_error(f"Failed to create managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(agent)
        return

    print_success(f"Managed agent {agent.id} created")
    print(f"  Name: {agent.name}")
    print(f"  Status: {agent.status}")
    if agent.public_token:
        print(f"  Public Token: {agent.public_token}")

@app.command()
def inspect(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show managed-agent details."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        agent = api.get(agent_id)
    except APIError as exc:
        print_error(f"Failed to get managed agent: {exc.message}")
        raise typer.Exit(1)

    _print_managed_agent_detail(agent, json_output=json_output)


@app.command("messages")
def list_messages(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List transcript messages for a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        messages = api.list_messages(agent_id)
    except APIError as exc:
        print_error(f"Failed to list managed-agent messages: {exc.message}")
        raise typer.Exit(1)

    _print_message_table(messages, json_output=json_output)


@app.command("history", deprecated=True)
def list_messages_alt(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List transcript messages (alias for messages)."""
    list_messages(agent_id=agent_id, json_output=json_output)


@app.command("send")
def send_message(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    events: bool = typer.Option(False, "--events", help="Print raw stream events"),
    wake: bool = typer.Option(
        True,
        "--wake/--no-wake",
        help="Wake the managed agent first when it is sleeping",
    ),
    wake_timeout: float = typer.Option(
        120.0,
        "--wake-timeout",
        min=0.0,
        help="Seconds to wait for a sleeping agent to wake before sending",
    ),
    prompt: list[str] = typer.Argument(None, help="Message content"),
) -> None:
    """Send a message to a managed agent."""
    content = _parse_prompt(prompt)
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        if wake:
            _wake_before_send(api, agent_id, timeout=wake_timeout)
        if _wants_json(json_output):
            with status(f"Sending message to managed agent {agent_id}..."):
                stream_events = api.send_message(agent_id, content)
        else:
            event_stream = api.stream_message(agent_id, content)
            if events:
                _emit_stream_events(event_stream)
                return
            stream_events, rendered = _stream_assistant_output(event_stream)
    except APIError as exc:
        print_error(f"Failed to send managed-agent message: {exc.message}")
        raise typer.Exit(1)
    except (RuntimeError, TimeoutError) as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(stream_events)
        return

    if rendered:
        return

    emit_json(stream_events)


@app.command("wake")
def wake_managed_agent(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Wake a sleeping managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Waking managed agent {agent_id}..."):
            agent = api.wake(agent_id)
    except APIError as exc:
        print_error(f"Failed to wake managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(agent)
        return

    print_success(f"Managed agent {agent_id} wake requested")


@app.command("fork")
def fork_managed_agent(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Fork a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Forking managed agent {agent_id}..."):
            agent = api.fork(agent_id)
    except APIError as exc:
        print_error(f"Failed to fork managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(agent)
        return

    print_success(f"Managed agent fork created: {agent.id}")


@app.command("rm")
def delete_managed_agent(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed agent."""
    if not force:
        typer.confirm(f"Delete managed agent {agent_id}?", abort=True)

    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        with status(f"Deleting managed agent {agent_id}..."):
            result = api.delete(agent_id)
    except APIError as exc:
        print_error(f"Failed to delete managed agent: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(result)
        return

    print_success(f"Managed agent {agent_id} deleted")


@app.command("delete", deprecated=True)
def delete_managed_agent_alt(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a managed agent (alias for rm)."""
    delete_managed_agent(agent_id=agent_id, force=True, json_output=json_output)


@app.command("file-content")
def get_file_content(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    content_hash: str = typer.Argument(..., help="CAS content hash"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Read managed-agent file content by CAS hash."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        payload = api.get_file_content(agent_id, content_hash)
    except APIError as exc:
        print_error(f"Failed to get managed-agent file content: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(payload)
        return

    print(payload.content)


@app.command("file")
def read_file(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    path: str = typer.Option(..., "--path", help="File path"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Read current file content from a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        payload = api.read_file(agent_id, path)
    except APIError as exc:
        print_error(f"Failed to read managed-agent file: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(payload)
        return

    print(payload.content)


@app.command("git-show")
def git_show_file(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    path: str = typer.Option(..., "--path", help="Workspace file path"),
    ref: str = typer.Option("HEAD", "--ref", help="Git ref"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Read committed file content from a managed agent via git show."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        payload = api.git_show(agent_id, path, ref=ref)
    except APIError as exc:
        print_error(f"Failed to read managed-agent git content: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(payload)
        return

    print(payload.content)


@app.command("browser-sessions")
def list_browser_sessions(
    agent_id: str = typer.Argument(..., help="Managed-agent ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List browser sessions for a managed agent."""
    client = get_client()
    api = ManagedAgentAPI(client)

    try:
        sessions = api.list_browser_sessions(agent_id)
    except APIError as exc:
        print_error(f"Failed to list managed-agent browser sessions: {exc.message}")
        raise typer.Exit(1)

    if _wants_json(json_output):
        emit_json(sessions)
        return

    print_browser_table(sessions)
