"""Credential resolution helpers for SDK entry points."""

from __future__ import annotations

from ..config.settings import Settings


def resolve_credentials(
    settings: Settings,
    *,
    api_key: str | None = None,
    access_token: str | None = None,
) -> tuple[str | None, str | None]:
    """Resolve one authentication method, preferring explicit caller input."""
    if api_key and access_token:
        raise ValueError("Provide either api_key or access_token, not both")
    if api_key is not None:
        return api_key, None
    if access_token is not None:
        return None, access_token
    if settings.access_token:
        return None, settings.access_token
    return settings.api_key, None
