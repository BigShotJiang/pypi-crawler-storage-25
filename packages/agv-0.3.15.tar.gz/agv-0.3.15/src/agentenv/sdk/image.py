"""High-level image builder for AgentEnv Cloud."""

from __future__ import annotations

import fnmatch
import glob
import hashlib
import json
import os
import shlex
import tarfile
import tempfile
import time
from datetime import datetime, timezone
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from ..api.client import Client as ApiClient
from ..api.image import ImageAPI
from ..api.models import CreateImageRequest, ImageBuildStep, ImageSnapshot
from ..api.sandbox import SandboxAPI
from ..config.settings import get_settings
from ._auth import resolve_credentials

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python 3.11 includes tomllib
    tomllib = None  # type: ignore

BUILDER_VERSION = "1"
DEFAULT_COPY_DIR = "/workspace"
STAGING_DIR = "/tmp/agentenv-image"
MAX_OUTPUT_PREVIEW = 4000
CACHE_REUSE = "reuse"
CACHE_CLEAN = "clean"
DEFAULT_SPARK_VERSION = "3.5.8"
DEFAULT_SPARK_HADOOP = "3"
DEFAULT_SPARK_INSTALL_PATH = "/opt/spark"
DEFAULT_SPARK_BASE_URL = "https://archive.apache.org/dist/spark"


@dataclass
class _ImageStep:
    type: str
    data: dict[str, Any]
    hash_data: dict[str, Any]
    runtime: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class BuildCondition:
    name: str
    predicate: Callable[[Any], bool]
    timeout: float = 300.0
    interval: float = 1.0
    hash_data: dict[str, Any] = field(default_factory=dict)


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _normalize_packages(packages: Iterable[str]) -> list[str]:
    if isinstance(packages, str):
        packages = [packages]
    cleaned = [pkg.strip() for pkg in packages if pkg and str(pkg).strip()]
    return sorted(set(cleaned))


def _shell_quote(value: str) -> str:
    return shlex.quote(value)


def _load_file_bytes(path: str) -> bytes:
    return Path(path).expanduser().read_bytes()


def _safe_basename(path: str) -> str:
    return Path(path).name


def _hash_file(path: str) -> str:
    return _sha256_bytes(_load_file_bytes(path))


def _compute_files_digest(files: list[Path], base_dir: Path) -> str:
    entries: list[tuple[str, str]] = []
    for file_path in sorted(files, key=lambda p: str(p)):
        rel = str(file_path.relative_to(base_dir)).replace(os.sep, "/")
        entries.append((rel, _hash_file(str(file_path))))
    payload = json.dumps(entries, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return _sha256_bytes(payload)


def _parse_pyproject_dependencies(path: str) -> list[str]:
    if tomllib is None:
        raise RuntimeError("tomllib is required to parse pyproject.toml")
    data = tomllib.loads(Path(path).read_text(encoding="utf-8"))
    deps: list[str] = []

    project = data.get("project", {}) if isinstance(data, dict) else {}
    project_deps = project.get("dependencies", [])
    if isinstance(project_deps, list):
        deps.extend(project_deps)

    poetry = data.get("tool", {}).get("poetry", {}) if isinstance(data, dict) else {}
    poetry_deps = poetry.get("dependencies", {}) if isinstance(poetry, dict) else {}
    if isinstance(poetry_deps, dict):
        for name, spec in poetry_deps.items():
            if name.lower() == "python":
                continue
            if isinstance(spec, str):
                deps.append(f"{name}{spec}")
            elif isinstance(spec, dict):
                version = spec.get("version")
                if version and version != "*":
                    deps.append(f"{name}{version}")
                else:
                    deps.append(name)

    return _normalize_packages(deps)


def _hash_env(env: dict[str, str]) -> str:
    payload = json.dumps(sorted(env.items()), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return _sha256_bytes(payload)


def _env_keys(env: dict[str, str]) -> list[str]:
    return sorted(env.keys())


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _truncate_output(output: str, limit: int = MAX_OUTPUT_PREVIEW) -> str:
    if output is None:
        return ""
    if len(output) <= limit:
        return output
    return output[:limit] + "...(truncated)"


def _has_glob(path: str) -> bool:
    return glob.has_magic(path)


def _load_ignore_patterns(ignore: str | list[str] | None) -> list[str]:
    if not ignore:
        return []
    if isinstance(ignore, list):
        return [p for p in (line.strip() for line in ignore) if p and not p.startswith("#")]
    ignore_path = Path(ignore)
    if ignore_path.exists():
        lines = ignore_path.read_text(encoding="utf-8").splitlines()
        return [p for p in (line.strip() for line in lines) if p and not p.startswith("#")]
    return [ignore]


def _should_include(rel_path: str, patterns: list[str]) -> bool:
    if not patterns:
        return True
    included = True
    for pattern in patterns:
        negated = pattern.startswith("!")
        pat = pattern[1:] if negated else pattern
        if not pat:
            continue
        if fnmatch.fnmatch(rel_path, pat) or fnmatch.fnmatch(rel_path.replace(os.sep, "/"), pat):
            included = True if negated else False
    return included


class ImageBuilder:
    """Builder for image snapshots."""

    def __init__(
        self,
        base_image: str | None,
        base_snapshot_id: str | None = None,
        workspace_id: str | None = None,
        name: str | None = None,
        api_url: str | None = None,
        api_key: str | None = None,
        access_token: str | None = None,
    ):
        settings = get_settings()
        resolved_image: str | None = None
        resolved_snapshot: str | None = None

        if base_image:
            if base_image.startswith("snapshot://"):
                resolved_snapshot = base_image.split("snapshot://", 1)[1]
            elif base_image.startswith("snapshot:"):
                resolved_snapshot = base_image.split("snapshot:", 1)[1]
            else:
                resolved_image = settings.resolve_image(base_image)
                if not resolved_image.startswith("docker://"):
                    resolved_image = f"docker://{resolved_image}"

        if base_snapshot_id:
            resolved_snapshot = base_snapshot_id
            resolved_image = None

        if not workspace_id:
            workspace_id = settings.workspace
        if not workspace_id:
            raise RuntimeError("workspace_id is required (or set default workspace via config)")

        if not resolved_image and not resolved_snapshot:
            raise RuntimeError("base_image or base_snapshot_id is required")

        self._base_image = resolved_image
        self._base_snapshot_id = resolved_snapshot
        self._workspace_id = workspace_id
        self._name_override = name
        self._steps: list[_ImageStep] = []
        self._tags: list[str] = []
        self._default_env: dict[str, str] = {}
        self._default_workdir: str | None = None
        self._cache_mode: str = CACHE_REUSE
        self._enabled_ray: bool = False
        self._enabled_spark: bool = False
        self._capabilities: list[str] = []
        self._conditions: list[BuildCondition] = []

        self._api_url = api_url or settings.api_url
        self._api_key, self._access_token = resolve_credentials(
            settings,
            api_key=api_key,
            access_token=access_token,
        )

        self._client = ApiClient(
            base_url=self._api_url,
            api_key=self._api_key,
            access_token=self._access_token,
            timeout=600.0,
        )
        self._sandbox_api = SandboxAPI(self._client)
        self._image_api = ImageAPI(self._client)

    def env(self, values: dict[str, str], merge: bool = True) -> "ImageBuilder":
        normalized = {str(k): str(v) for k, v in values.items()}
        if merge:
            self._default_env.update(normalized)
        else:
            self._default_env = dict(normalized)
        return self

    def build_args(self, values: dict[str, str], merge: bool = True) -> "ImageBuilder":
        return self.env(values, merge=merge)

    def workdir(self, path: str | None) -> "ImageBuilder":
        self._default_workdir = path
        return self

    def cache(self, mode: str) -> "ImageBuilder":
        normalized = mode.strip().lower()
        if normalized not in {CACHE_REUSE, CACHE_CLEAN}:
            raise ValueError("cache mode must be 'reuse' or 'clean'")
        self._cache_mode = normalized
        return self

    def enable_ray(
        self,
        break_system_packages: bool = False,
        pip_args: Iterable[str] | None = None,
        python_path: str | None = None,
    ) -> "ImageBuilder":
        """Ensure Ray is installed in the image (install via pip if missing)."""
        if self._enabled_ray:
            return self

        extra_args = list(pip_args or [])
        data: dict[str, Any] = {
            "breakSystemPackages": bool(break_system_packages),
            "pipArgs": extra_args,
            "pythonPath": python_path,
        }
        hash_data = dict(data)
        self._steps.append(
            _ImageStep(
                type="enable_ray",
                data=data,
                hash_data=hash_data,
            )
        )
        self._enabled_ray = True
        return self

    def enable_spark(
        self,
        spark_version: str | None = None,
        hadoop: str | None = None,
        install_path: str | None = None,
    ) -> "ImageBuilder":
        """Ensure Apache Spark is installed in the image (download if missing)."""
        if self._enabled_spark:
            return self

        version = str(spark_version or DEFAULT_SPARK_VERSION).strip()
        hadoop_variant = str(hadoop or DEFAULT_SPARK_HADOOP).strip()
        target_path = str(install_path or DEFAULT_SPARK_INSTALL_PATH).strip()
        if not version:
            raise ValueError("spark_version must be provided")
        if not hadoop_variant:
            raise ValueError("hadoop variant must be provided")
        if not target_path:
            raise ValueError("install_path must be provided")

        package = f"spark-{version}-bin-hadoop{hadoop_variant}"
        download_url = f"{DEFAULT_SPARK_BASE_URL}/spark-{version}/{package}.tgz"
        data: dict[str, Any] = {
            "version": version,
            "hadoop": hadoop_variant,
            "package": package,
            "installPath": target_path,
            "downloadUrl": download_url,
        }
        hash_data = dict(data)
        self._steps.append(
            _ImageStep(
                type="enable_spark",
                data=data,
                hash_data=hash_data,
            )
        )
        self._enabled_spark = True
        return self

    def tag(self, value: str) -> "ImageBuilder":
        if value:
            self._tags.append(value)
        return self

    def tags(self, values: Iterable[str]) -> "ImageBuilder":
        for value in values:
            if value:
                self._tags.append(value)
        return self

    def capability(self, value: str) -> "ImageBuilder":
        if value:
            self._capabilities.append(str(value))
        return self

    def capabilities(self, values: Iterable[str]) -> "ImageBuilder":
        for value in values:
            if value:
                self._capabilities.append(str(value))
        return self

    def wait_until(
        self,
        predicate: BuildCondition | Callable[[Any], bool],
        *,
        name: str | None = None,
        timeout: float | None = None,
        interval: float | None = None,
        hash_data: dict[str, Any] | None = None,
    ) -> "ImageBuilder":
        """Wait for a sandbox condition before snapshotting the image.

        The predicate receives a SandboxResource for the temporary build sandbox.
        """
        condition = self._coerce_condition(
            predicate,
            name=name,
            timeout=timeout,
            interval=interval,
            hash_data=hash_data,
        )
        self._conditions.append(condition)
        return self

    def execute(
        self,
        command: str,
        env: dict[str, str] | None = None,
        workdir: str | None = None,
    ) -> "ImageBuilder":
        merged_env = self._merge_env(env)
        env_hash = _hash_env(merged_env) if env is not None and merged_env else None
        env_keys = _env_keys(merged_env) if env is not None and merged_env else None
        resolved_workdir = workdir or self._default_workdir
        data = {"command": command}
        hash_data = {"command": command}
        runtime: dict[str, Any] = {"env": merged_env, "workdir": resolved_workdir}
        if env_hash:
            data["envHash"] = env_hash
            data["envKeys"] = env_keys
            hash_data["envHash"] = env_hash
        if resolved_workdir:
            data["workdir"] = resolved_workdir
            hash_data["workdir"] = resolved_workdir
        self._steps.append(
            _ImageStep(
                type="execute",
                data=data,
                hash_data=hash_data,
                runtime=runtime,
            )
        )
        return self

    def python_packages(self, packages: Iterable[str]) -> "ImageBuilder":
        normalized = _normalize_packages(packages)
        self._steps.append(
            _ImageStep(
                type="python_packages",
                data={"packages": normalized},
                hash_data={"packages": normalized},
            )
        )
        return self

    def requirements_file(self, local_file_path: str) -> "ImageBuilder":
        content = _load_file_bytes(local_file_path)
        digest = _sha256_bytes(content)
        dest = f"{STAGING_DIR}/requirements-{digest[:8]}.txt"
        self._steps.append(
            _ImageStep(
                type="requirements_file",
                data={"source": _safe_basename(local_file_path), "dest": dest, "sha256": digest},
                hash_data={"dest": dest, "sha256": digest},
                runtime={"local_path": local_file_path, "sha256": digest},
            )
        )
        return self

    def requirement_file(self, local_file_path: str) -> "ImageBuilder":
        return self.requirements_file(local_file_path)

    def pyproject_toml(self, local_file_path: str) -> "ImageBuilder":
        content = _load_file_bytes(local_file_path)
        digest = _sha256_bytes(content)
        deps = _parse_pyproject_dependencies(local_file_path)
        self._steps.append(
            _ImageStep(
                type="pyproject_toml",
                data={
                    "source": _safe_basename(local_file_path),
                    "sha256": digest,
                    "dependencies": deps,
                },
                hash_data={"sha256": digest, "dependencies": deps},
                runtime={"local_path": local_file_path, "sha256": digest, "dependencies": deps},
            )
        )
        return self

    def uv_lock(self, local_file_path: str) -> "ImageBuilder":
        content = _load_file_bytes(local_file_path)
        digest = _sha256_bytes(content)
        dest = f"{STAGING_DIR}/uv-{digest[:8]}.lock"
        self._steps.append(
            _ImageStep(
                type="uv_lock",
                data={"source": _safe_basename(local_file_path), "dest": dest, "sha256": digest},
                hash_data={"dest": dest, "sha256": digest},
                runtime={"local_path": local_file_path, "sha256": digest},
            )
        )
        return self

    def copy(
        self,
        local_path: str,
        remote_path: str | None = None,
        ignore: str | list[str] | None = None,
        sync: bool = False,
    ) -> "ImageBuilder":
        expanded = Path(local_path).expanduser()
        patterns = _load_ignore_patterns(ignore)

        def gather_files_from_dir(root: Path) -> list[Path]:
            files = []
            for path in root.rglob("*"):
                if path.is_file():
                    rel = str(path.relative_to(root)).replace(os.sep, "/")
                    if _should_include(rel, patterns):
                        files.append(path)
            return files

        files: list[Path] = []
        base_dir: Path | None = None

        if _has_glob(local_path):
            matches = [Path(p) for p in glob.glob(local_path, recursive=True)]
            for match in matches:
                if match.is_dir():
                    files.extend(gather_files_from_dir(match))
                elif match.is_file():
                    rel = match.name
                    if _should_include(rel, patterns):
                        files.append(match)
            if files:
                base_dir = Path(os.path.commonpath([str(p) for p in files]))
                if base_dir.is_file():
                    base_dir = base_dir.parent
        elif expanded.is_dir():
            files = gather_files_from_dir(expanded)
            base_dir = expanded
        else:
            # Single file
            digest = _hash_file(str(expanded))
            dest = remote_path or f"{DEFAULT_COPY_DIR}/{_safe_basename(local_path)}"
            if dest.endswith("/"):
                dest = f"{dest}{_safe_basename(local_path)}"
            self._steps.append(
                _ImageStep(
                    type="copy",
                    data={"mode": "file", "source": _safe_basename(local_path), "dest": dest, "sha256": digest},
                    hash_data={"mode": "file", "dest": dest, "sha256": digest},
                    runtime={"local_path": str(expanded), "sha256": digest},
                )
            )
            return self

        if not files or base_dir is None:
            raise RuntimeError(f"No files matched for copy: {local_path}")

        if not remote_path:
            if expanded.exists() and expanded.is_dir():
                remote_path = f"{DEFAULT_COPY_DIR}/{expanded.name}"
            else:
                remote_path = DEFAULT_COPY_DIR
        if remote_path != "/" and remote_path.endswith("/"):
            remote_path = remote_path.rstrip("/")

        digest = _compute_files_digest(files, base_dir)
        self._steps.append(
            _ImageStep(
                type="copy",
                data={
                    "mode": "archive",
                    "dest": remote_path,
                    "sha256": digest,
                    "fileCount": len(files),
                    "sync": sync,
                },
                hash_data={"mode": "archive", "dest": remote_path, "sha256": digest, "sync": sync},
                runtime={
                    "files": [str(p) for p in files],
                    "base_dir": str(base_dir),
                    "dest": remote_path,
                    "sha256": digest,
                    "sync": sync,
                },
            )
        )
        return self

    def remove(self, remote_file_path: str) -> "ImageBuilder":
        self._steps.append(
            _ImageStep(
                type="remove",
                data={"path": remote_file_path},
                hash_data={"path": remote_file_path},
            )
        )
        return self

    def git_clone(
        self,
        url: str,
        path: str,
        ref: str | None = None,
        depth: int | None = 1,
        token: str | None = None,
        ssh_key_path: str | None = None,
        submodules: bool = False,
    ) -> "ImageBuilder":
        sanitized_url = self._sanitize_git_url(url)
        data: dict[str, Any] = {
            "url": sanitized_url,
            "path": path,
            "ref": ref,
            "depth": depth,
            "submodules": submodules,
        }
        hash_data: dict[str, Any] = {
            "url": sanitized_url,
            "path": path,
            "ref": ref,
            "depth": depth,
            "submodules": submodules,
        }
        runtime: dict[str, Any] = {
            "url": url,
            "path": path,
            "ref": ref,
            "depth": depth,
            "token": token,
            "ssh_key_path": ssh_key_path,
            "submodules": submodules,
        }
        self._steps.append(
            _ImageStep(
                type="git_clone",
                data=data,
                hash_data=hash_data,
                runtime=runtime,
            )
        )
        return self

    def system_packages(self, packages: Iterable[str]) -> "ImageBuilder":
        normalized = _normalize_packages(packages)
        self._steps.append(
            _ImageStep(
                type="system_packages",
                data={"packages": normalized},
                hash_data={"packages": normalized},
            )
        )
        return self

    def execute_python_script(
        self,
        script: str,
        python_path: str | None = None,
        env: dict[str, str] | None = None,
        workdir: str | None = None,
    ) -> "ImageBuilder":
        content = self._resolve_script_content(script)
        digest = _sha256_bytes(content.encode("utf-8"))
        dest = f"{STAGING_DIR}/script-{digest[:8]}.py"
        merged_env = self._merge_env(env)
        env_hash = _hash_env(merged_env) if env is not None and merged_env else None
        env_keys = _env_keys(merged_env) if env is not None and merged_env else None
        resolved_workdir = workdir or self._default_workdir
        data: dict[str, Any] = {"sha256": digest, "dest": dest, "pythonPath": python_path}
        hash_data: dict[str, Any] = {"sha256": digest, "dest": dest, "pythonPath": python_path}
        if env_hash:
            data["envHash"] = env_hash
            data["envKeys"] = env_keys
            hash_data["envHash"] = env_hash
        if resolved_workdir:
            data["workdir"] = resolved_workdir
            hash_data["workdir"] = resolved_workdir
        self._steps.append(
            _ImageStep(
                type="execute_python_script",
                data=data,
                hash_data=hash_data,
                runtime={
                    "content": content,
                    "sha256": digest,
                    "env": merged_env,
                    "workdir": resolved_workdir,
                },
            )
        )
        return self

    def execute_nodejs_script(
        self,
        script: str,
        node_path: str | None = None,
        env: dict[str, str] | None = None,
        workdir: str | None = None,
    ) -> "ImageBuilder":
        content = self._resolve_script_content(script)
        digest = _sha256_bytes(content.encode("utf-8"))
        dest = f"{STAGING_DIR}/script-{digest[:8]}.js"
        merged_env = self._merge_env(env)
        env_hash = _hash_env(merged_env) if env is not None and merged_env else None
        env_keys = _env_keys(merged_env) if env is not None and merged_env else None
        resolved_workdir = workdir or self._default_workdir
        data: dict[str, Any] = {"sha256": digest, "dest": dest, "nodePath": node_path}
        hash_data: dict[str, Any] = {"sha256": digest, "dest": dest, "nodePath": node_path}
        if env_hash:
            data["envHash"] = env_hash
            data["envKeys"] = env_keys
            hash_data["envHash"] = env_hash
        if resolved_workdir:
            data["workdir"] = resolved_workdir
            hash_data["workdir"] = resolved_workdir
        self._steps.append(
            _ImageStep(
                type="execute_nodejs_script",
                data=data,
                hash_data=hash_data,
                runtime={
                    "content": content,
                    "sha256": digest,
                    "env": merged_env,
                    "workdir": resolved_workdir,
                },
            )
        )
        return self

    def build_hash(self) -> str:
        return self._compute_build_hash()

    def finalize(
        self,
        timeout: float = 900.0,
        force: bool = False,
        wait: bool = True,
        on_event: Any | None = None,
    ) -> ImageSnapshot:
        build_hash = self._compute_build_hash()
        env_hash = _hash_env(self._default_env) if self._default_env else None
        env_keys = _env_keys(self._default_env) if self._default_env else None
        tags = list(dict.fromkeys(self._tags))
        capabilities = [cap for cap in dict.fromkeys(self._capabilities) if cap]
        for cap in capabilities:
            if cap.lower().startswith("internal:"):
                raise RuntimeError("Capabilities starting with internal: are reserved")

        existing = self._image_api.list_all(
            workspace_id=self._workspace_id,
            build_hash=build_hash,
            page=1,
            limit=1,
        )
        if existing and not (force and existing[0].status == "failed"):
            image = existing[0]
            if tags:
                try:
                    image = self._image_api.add_tags(image.id, tags, overwrite=False)
                except Exception:
                    pass
            return self._wait_or_raise(image, timeout) if wait else image

        sandbox_name = f"image-build-{build_hash[:8]}"
        sandbox_id: str | None = None
        self._emit(on_event, "build_start", {"buildHash": build_hash, "steps": len(self._steps)})
        try:
            sandbox_request: dict[str, Any] = {
                "name": sandbox_name,
                "workspaceId": self._workspace_id,
            }
            if self._base_snapshot_id:
                sandbox_request["snapshotId"] = self._base_snapshot_id
            else:
                sandbox_request["image"] = self._base_image

            sandbox = self._sandbox_api.create(sandbox_request)
            sandbox_id = sandbox.id
            sandbox = self._sandbox_api.wait_for_status(sandbox_id, timeout=300)
            sandbox_resource = self._sandbox_resource(sandbox)

            self._exec(sandbox_id, f"mkdir -p {STAGING_DIR} {DEFAULT_COPY_DIR}")

            if self._cache_mode == CACHE_CLEAN:
                self._exec(sandbox_id, "rm -rf ~/.cache/pip ~/.cache/uv || true")

            for index, step in enumerate(self._steps):
                self._execute_step(sandbox_id, step, index=index, on_event=on_event)

            self._wait_for_conditions(sandbox_resource, on_event=on_event)

            steps_payload = [ImageBuildStep(type=s.type, data=s.data, meta=s.meta) for s in self._steps]

            image = self._image_api.ensure(
                CreateImageRequest(
                    sandboxId=sandbox_id,
                    name=self._name_override,
                    buildHash=build_hash,
                    baseImage=self._base_image,
                    baseSnapshotId=self._base_snapshot_id,
                    steps=steps_payload,
                    builderVersion=BUILDER_VERSION,
                    workdir=self._default_workdir,
                    envKeys=env_keys,
                    envHash=env_hash,
                    cacheMode=self._cache_mode,
                    tags=tags or None,
                    capabilities=capabilities or None,
                    force=force,
                )
            )
            self._emit(on_event, "build_snapshot", {"imageId": image.id})
            result = self._wait_or_raise(image, timeout) if wait else image
            self._emit(on_event, "build_complete", {"imageId": result.id, "status": result.status})
            return result
        finally:
            if sandbox_id:
                try:
                    self._sandbox_api.delete(sandbox_id)
                except Exception:
                    pass

    def _wait_or_raise(self, image: ImageSnapshot, timeout: float) -> ImageSnapshot:
        if image.status == "completed":
            return image
        if image.status in {"pending", "in_progress"}:
            return self._wait_for_image(image.id, timeout)
        raise RuntimeError(f"Image build failed (status={image.status})")

    def _wait_for_image(self, image_id: str, timeout: float) -> ImageSnapshot:
        deadline = time.time() + timeout
        last = None
        while time.time() < deadline:
            last = self._image_api.get(image_id)
            if last.status == "completed":
                return last
            if last.status == "failed":
                raise RuntimeError("Image build failed")
            time.sleep(2)
        raise TimeoutError(f"Timeout waiting for image {image_id} to complete")

    def _execute_step(
        self,
        sandbox_id: str,
        step: _ImageStep,
        index: int,
        on_event: Any | None = None,
    ) -> None:
        start_ts = _iso_now()
        start_time = time.time()
        self._emit(on_event, "step_start", {"index": index, "type": step.type, "data": step.data})

        output = ""
        exit_code = 0
        try:
            if step.type == "execute":
                result = self._exec(
                    sandbox_id,
                    step.data["command"],
                    env=step.runtime.get("env"),
                    workdir=step.runtime.get("workdir"),
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(output)
                return

            if step.type == "python_packages":
                packages = step.data.get("packages", [])
                if packages:
                    pkgs = " ".join(_shell_quote(p) for p in packages)
                    cmd = f"python3 -m pip install {pkgs}"
                    if self._cache_mode == CACHE_CLEAN:
                        cmd += " --no-cache-dir"
                    result = self._exec(
                        sandbox_id,
                        cmd,
                        env=self._default_env or None,
                        workdir=self._default_workdir,
                        allow_failure=True,
                    )
                    output = result.output
                    exit_code = result.exit_code
                    if exit_code != 0:
                        raise RuntimeError(result.output)
                return

            if step.type == "requirements_file":
                self._ensure_file_unchanged(step)
                dest = step.data["dest"]
                self._sandbox_api.upload_file(sandbox_id, step.runtime["local_path"], dest)
                cmd = f"python3 -m pip install -r {_shell_quote(dest)}"
                if self._cache_mode == CACHE_CLEAN:
                    cmd += " --no-cache-dir"
                result = self._exec(
                    sandbox_id,
                    cmd,
                    env=self._default_env or None,
                    workdir=self._default_workdir,
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(result.output)
                return

            if step.type == "pyproject_toml":
                self._ensure_file_unchanged(step)
                deps = step.runtime.get("dependencies", [])
                if deps:
                    pkgs = " ".join(_shell_quote(p) for p in deps)
                    cmd = f"python3 -m pip install {pkgs}"
                    if self._cache_mode == CACHE_CLEAN:
                        cmd += " --no-cache-dir"
                    result = self._exec(
                        sandbox_id,
                        cmd,
                        env=self._default_env or None,
                        workdir=self._default_workdir,
                        allow_failure=True,
                    )
                    output = result.output
                    exit_code = result.exit_code
                    if exit_code != 0:
                        raise RuntimeError(result.output)
                return

            if step.type == "uv_lock":
                self._ensure_file_unchanged(step)
                dest = step.data["dest"]
                self._sandbox_api.upload_file(sandbox_id, step.runtime["local_path"], dest)
                env = dict(self._default_env)
                if self._cache_mode == CACHE_CLEAN:
                    env["UV_NO_CACHE"] = "1"
                uv_install = "python3 -m pip install uv"
                if self._cache_mode == CACHE_CLEAN:
                    uv_install += " --no-cache-dir"
                self._exec(sandbox_id, uv_install, env=env or None, allow_failure=False)
                result = self._exec(
                    sandbox_id,
                    f"uv pip sync --system --lockfile {_shell_quote(dest)}",
                    env=env or None,
                    workdir=self._default_workdir,
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(result.output)
                return

            if step.type == "copy":
                self._ensure_file_unchanged(step)
                mode = step.data.get("mode", "file")
                if mode == "file":
                    dest = step.data["dest"]
                    self._sandbox_api.upload_file(sandbox_id, step.runtime["local_path"], dest)
                    return

                if mode == "archive":
                    archive_path = self._create_copy_archive(step)
                    dest = step.runtime["dest"]
                    remote_archive = f"{STAGING_DIR}/archive-{step.runtime['sha256'][:8]}.tar"
                    self._sandbox_api.upload_file(sandbox_id, archive_path, remote_archive)
                    try:
                        if step.runtime.get("sync"):
                            self._exec(sandbox_id, f"rm -rf {_shell_quote(dest)}")
                        self._exec(sandbox_id, f"mkdir -p {_shell_quote(dest)}")
                        self._exec(
                            sandbox_id,
                            f"tar -xf {_shell_quote(remote_archive)} -C {_shell_quote(dest)}",
                        )
                    finally:
                        os.unlink(archive_path)
                    return

                raise RuntimeError(f"Unknown copy mode: {mode}")

            if step.type == "remove":
                result = self._exec(
                    sandbox_id,
                    f"rm -rf {_shell_quote(step.data['path'])}",
                    env=self._default_env or None,
                    workdir=self._default_workdir,
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(result.output)
                return

            if step.type == "git_clone":
                self._ensure_git(sandbox_id)
                clone_cmd, clone_env = self._build_git_clone_command(sandbox_id, step)
                remote_key = step.runtime.get("remote_key_path")
                try:
                    result = self._exec(
                        sandbox_id,
                        clone_cmd,
                        env=clone_env,
                        workdir=self._default_workdir,
                        allow_failure=True,
                    )
                    output = result.output
                    token = step.runtime.get("token")
                    if token and output:
                        output = output.replace(token, "***")
                    exit_code = result.exit_code
                    if exit_code != 0:
                        raise RuntimeError(result.output)
                finally:
                    if remote_key:
                        try:
                            self._exec(
                                sandbox_id,
                                f"rm -f {_shell_quote(remote_key)}",
                                allow_failure=True,
                            )
                        except Exception:
                            pass
                return

            if step.type == "system_packages":
                packages = step.data.get("packages", [])
                if packages:
                    self._install_system_packages(sandbox_id, packages)
                return

            if step.type == "execute_python_script":
                content = step.runtime["content"]
                dest = step.data["dest"]
                self._upload_inline_content(sandbox_id, content, dest)
                python_path = step.data.get("pythonPath") or "python3"
                result = self._exec(
                    sandbox_id,
                    f"{_shell_quote(python_path)} {_shell_quote(dest)}",
                    env=step.runtime.get("env"),
                    workdir=step.runtime.get("workdir"),
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(result.output)
                return

            if step.type == "execute_nodejs_script":
                content = step.runtime["content"]
                dest = step.data["dest"]
                self._upload_inline_content(sandbox_id, content, dest)
                node_path = step.data.get("nodePath") or "node"
                result = self._exec(
                    sandbox_id,
                    f"{_shell_quote(node_path)} {_shell_quote(dest)}",
                    env=step.runtime.get("env"),
                    workdir=step.runtime.get("workdir"),
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(result.output)
                return

            if step.type == "enable_ray":
                break_system_packages = bool(step.data.get("breakSystemPackages"))
                pip_args = step.data.get("pipArgs") or []
                python_path = step.data.get("pythonPath")

                ray_check = self._exec(
                    sandbox_id,
                    "command -v ray >/dev/null 2>&1",
                    allow_failure=True,
                )
                if ray_check.exit_code == 0:
                    output = "ray already installed"
                    exit_code = 0
                    return

                chosen_python = None
                candidates = [python_path, "python3", "python"]
                for candidate in candidates:
                    if not candidate:
                        continue
                    exists = self._exec(
                        sandbox_id,
                        f"command -v {_shell_quote(candidate)} >/dev/null 2>&1",
                        allow_failure=True,
                    )
                    if exists.exit_code == 0:
                        chosen_python = candidate
                        break

                if not chosen_python:
                    raise RuntimeError("Python not found; cannot install ray")

                pip_check = self._exec(
                    sandbox_id,
                    f"{_shell_quote(chosen_python)} -m pip --version",
                    allow_failure=True,
                )
                if pip_check.exit_code != 0:
                    self._exec(
                        sandbox_id,
                        f"{_shell_quote(chosen_python)} -m ensurepip --upgrade",
                        allow_failure=True,
                    )

                install_args = list(pip_args)
                if break_system_packages:
                    install_args.append("--break-system-packages")
                if self._cache_mode == CACHE_CLEAN:
                    install_args.append("--no-cache-dir")
                arg_str = " ".join(_shell_quote(arg) for arg in install_args)
                cmd = f"{_shell_quote(chosen_python)} -m pip install {arg_str} ray".strip()
                result = self._exec(
                    sandbox_id,
                    cmd,
                    env=self._default_env or None,
                    workdir=self._default_workdir,
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(result.output)
                return

            if step.type == "enable_spark":
                install_path = step.data.get("installPath") or DEFAULT_SPARK_INSTALL_PATH
                version = step.data.get("version") or DEFAULT_SPARK_VERSION
                hadoop_variant = step.data.get("hadoop") or DEFAULT_SPARK_HADOOP
                package = step.data.get("package") or f"spark-{version}-bin-hadoop{hadoop_variant}"
                download_url = step.data.get("downloadUrl") or (
                    f"{DEFAULT_SPARK_BASE_URL}/spark-{version}/{package}.tgz"
                )

                spark_check = self._exec(
                    sandbox_id,
                    f"test -x {_shell_quote(install_path)}/sbin/start-master.sh",
                    allow_failure=True,
                )
                if spark_check.exit_code == 0:
                    output = "spark already installed"
                    exit_code = 0
                    return

                install_path_q = _shell_quote(install_path)
                package_q = _shell_quote(package)
                url_q = _shell_quote(download_url)
                command = [
                    "set -e",
                    f"INSTALL_PATH={install_path_q}",
                    f"PACKAGE={package_q}",
                    f"URL={url_q}",
                    'TMP_DIR="$(mktemp -d)"',
                    'trap \'rm -rf "$TMP_DIR"\' EXIT',
                    'ARCHIVE="$TMP_DIR/spark.tgz"',
                    'curl -fsSL --connect-timeout 5 --max-time 120 -o "$ARCHIVE" "$URL"',
                    'tar -xzf "$ARCHIVE" -C "$TMP_DIR"',
                    'rm -rf "$INSTALL_PATH"',
                    'mkdir -p "$(dirname "$INSTALL_PATH")"',
                    'mv "$TMP_DIR/$PACKAGE" "$INSTALL_PATH"',
                ]
                result = self._exec(
                    sandbox_id,
                    "\n".join(command),
                    env=self._default_env or None,
                    workdir=self._default_workdir,
                    allow_failure=True,
                )
                output = result.output
                exit_code = result.exit_code
                if exit_code != 0:
                    raise RuntimeError(result.output)
                return

            raise RuntimeError(f"Unknown step type: {step.type}")
        except Exception as exc:
            exit_code = exit_code or 1
            output = output or str(exc)
            raise
        finally:
            completed_ts = _iso_now()
            step.meta.update(
                {
                    "index": index,
                    "startedAt": start_ts,
                    "completedAt": completed_ts,
                    "durationMs": int((time.time() - start_time) * 1000),
                    "exitCode": exit_code,
                    "outputPreview": _truncate_output(output),
                }
            )
            if exit_code == 0:
                self._emit(on_event, "step_complete", {"index": index, "type": step.type, "meta": step.meta})
            else:
                self._emit(on_event, "step_error", {"index": index, "type": step.type, "meta": step.meta})

    def _exec(
        self,
        sandbox_id: str,
        command: str,
        env: dict[str, str] | None = None,
        workdir: str | None = None,
        allow_failure: bool = False,
    ) -> Any:
        final_command = self._build_command(command, env, workdir)
        result = self._sandbox_api.exec(sandbox_id, final_command)
        if result.exit_code != 0 and not allow_failure:
            raise RuntimeError(f"Command failed: {command}\n{result.output}")
        return result

    def _build_command(
        self,
        command: str,
        env: dict[str, str] | None,
        workdir: str | None,
    ) -> str:
        cmd = command
        if env:
            env_parts = " ".join(f"{k}={_shell_quote(v)}" for k, v in env.items())
            cmd = f"env {env_parts} {cmd}"
        if workdir:
            cmd = f"cd {_shell_quote(workdir)} && {cmd}"
        return cmd

    def _emit(self, handler: Any | None, event: str, payload: dict[str, Any]) -> None:
        if not handler:
            return
        data = {"event": event, **payload}
        try:
            handler(data)
        except TypeError:
            handler(event, payload)

    def _merge_env(self, override: dict[str, str] | None) -> dict[str, str]:
        merged = dict(self._default_env)
        if override:
            merged.update({str(k): str(v) for k, v in override.items()})
        return merged

    def _sandbox_resource(self, sandbox: Any) -> Any:
        from . import SandboxResource

        return SandboxResource(self._client, sandbox)

    def _coerce_condition(
        self,
        predicate: BuildCondition | Callable[[Any], bool],
        *,
        name: str | None,
        timeout: float | None,
        interval: float | None,
        hash_data: dict[str, Any] | None,
    ) -> BuildCondition:
        if isinstance(predicate, BuildCondition):
            return BuildCondition(
                name=name or predicate.name,
                predicate=predicate.predicate,
                timeout=timeout if timeout is not None else predicate.timeout,
                interval=interval if interval is not None else predicate.interval,
                hash_data=hash_data if hash_data is not None else dict(predicate.hash_data),
            )

        resolved_name = name or getattr(predicate, "__name__", None)
        if not resolved_name or resolved_name == "<lambda>":
            raise ValueError(
                "Custom builder conditions require a stable name= when using an anonymous lambda"
            )
        return BuildCondition(
            name=resolved_name,
            predicate=predicate,
            timeout=timeout if timeout is not None else 300.0,
            interval=interval if interval is not None else 1.0,
            hash_data=hash_data if hash_data is not None else {"name": resolved_name},
        )

    def _wait_for_conditions(self, sandbox: Any, on_event: Any | None = None) -> None:
        for index, condition in enumerate(self._conditions):
            started_at = time.time()
            deadline = started_at + condition.timeout
            self._emit(
                on_event,
                "condition_wait_start",
                {
                    "index": index,
                    "name": condition.name,
                    "timeout": condition.timeout,
                    "interval": condition.interval,
                },
            )
            while True:
                sandbox.refresh()
                if sandbox.status in ("failed", "terminated"):
                    raise RuntimeError(
                        f"Sandbox {sandbox.id} failed while waiting for condition {condition.name}"
                    )
                if condition.predicate(sandbox):
                    self._emit(
                        on_event,
                        "condition_wait_complete",
                        {
                            "index": index,
                            "name": condition.name,
                            "durationMs": int((time.time() - started_at) * 1000),
                        },
                    )
                    break
                if time.time() >= deadline:
                    raise TimeoutError(
                        f"Timeout waiting for builder condition {condition.name}"
                    )
                time.sleep(condition.interval)

    def _sanitize_git_url(self, url: str) -> str:
        if "://" not in url:
            return url
        scheme, rest = url.split("://", 1)
        if "@" in rest and ":" in rest.split("@")[0]:
            rest = rest.split("@", 1)[1]
        return f"{scheme}://{rest}"

    def _ensure_git(self, sandbox_id: str) -> None:
        try:
            self._exec(sandbox_id, "git --version")
        except Exception:
            self._install_system_packages(sandbox_id, ["git"])

    def _build_git_clone_command(self, sandbox_id: str, step: _ImageStep) -> tuple[str, dict[str, str] | None]:
        url = step.runtime.get("url")
        dest = step.runtime.get("path")
        ref = step.runtime.get("ref")
        depth = step.runtime.get("depth")
        token = step.runtime.get("token")
        ssh_key_path = step.runtime.get("ssh_key_path")
        submodules = step.runtime.get("submodules")

        clone_url = url
        if token and "://" in url:
            scheme, rest = url.split("://", 1)
            if "@" not in rest.split("/")[0]:
                clone_url = f"{scheme}://{token}@{rest}"

        env = dict(self._default_env)
        if ssh_key_path:
            key_bytes = _load_file_bytes(ssh_key_path)
            key_hash = _sha256_bytes(key_bytes)
            key_dest = f"{STAGING_DIR}/git-key-{key_hash[:8]}"
            self._sandbox_api.upload_file(sandbox_id, ssh_key_path, key_dest)
            self._exec(sandbox_id, f"chmod 600 {_shell_quote(key_dest)}")
            env["GIT_SSH_COMMAND"] = f"ssh -i {_shell_quote(key_dest)} -o StrictHostKeyChecking=no"
            step.runtime["remote_key_path"] = key_dest

        depth_arg = f"--depth {depth}" if depth else ""
        clone_cmd = f"git clone {depth_arg} {_shell_quote(clone_url)} {_shell_quote(dest)}".strip()
        if ref:
            clone_cmd += f" && git -C {_shell_quote(dest)} checkout {_shell_quote(ref)}"
        if submodules:
            clone_cmd += f" && git -C {_shell_quote(dest)} submodule update --init --recursive"

        return clone_cmd, env or None

    def _create_copy_archive(self, step: _ImageStep) -> str:
        files = [Path(p) for p in step.runtime.get("files", [])]
        base_dir = Path(step.runtime.get("base_dir", "."))
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".tar")
        temp_file.close()
        with tarfile.open(temp_file.name, "w") as tar:
            for file_path in files:
                arcname = str(file_path.relative_to(base_dir)).replace(os.sep, "/")
                tar.add(str(file_path), arcname=arcname)
        return temp_file.name

    def _install_system_packages(self, sandbox_id: str, packages: Iterable[str]) -> None:
        pkg_list = " ".join(_shell_quote(p) for p in packages)
        command = (
            "if command -v apt-get >/dev/null 2>&1; then "
            "DEBIAN_FRONTEND=noninteractive apt-get update -y && "
            f"DEBIAN_FRONTEND=noninteractive apt-get install -y {pkg_list}; "
            "elif command -v apk >/dev/null 2>&1; then "
            f"apk add --no-cache {pkg_list}; "
            "elif command -v dnf >/dev/null 2>&1; then "
            f"dnf install -y {pkg_list}; "
            "elif command -v yum >/dev/null 2>&1; then "
            f"yum install -y {pkg_list}; "
            "elif command -v microdnf >/dev/null 2>&1; then "
            f"microdnf install -y {pkg_list}; "
            "else echo 'No supported package manager found' >&2; exit 1; fi"
        )
        self._exec(sandbox_id, command)

    def _upload_inline_content(self, sandbox_id: str, content: str, dest: str) -> None:
        with tempfile.NamedTemporaryFile("w", delete=False) as tmp:
            tmp.write(content)
            tmp.flush()
            temp_path = tmp.name
        try:
            self._sandbox_api.upload_file(sandbox_id, temp_path, dest)
        finally:
            os.unlink(temp_path)

    def _resolve_script_content(self, script: str) -> str:
        if Path(script).expanduser().exists():
            return Path(script).expanduser().read_text(encoding="utf-8")
        return script

    def _ensure_file_unchanged(self, step: _ImageStep) -> None:
        local_path = step.runtime.get("local_path")
        if not local_path:
            files = step.runtime.get("files")
            base_dir = step.runtime.get("base_dir")
            if files and base_dir:
                current_hash = _compute_files_digest([Path(p) for p in files], Path(base_dir))
                if current_hash != step.runtime.get("sha256"):
                    raise RuntimeError("Files changed during build")
            return
        current_hash = _sha256_bytes(_load_file_bytes(local_path))
        if current_hash != step.runtime.get("sha256"):
            raise RuntimeError(f"File changed during build: {local_path}")

    def _compute_build_hash(self) -> str:
        env_hash = _hash_env(self._default_env) if self._default_env else None
        spec = {
            "baseImage": self._base_image,
            "baseSnapshotId": self._base_snapshot_id,
            "builderVersion": BUILDER_VERSION,
            "workdir": self._default_workdir,
            "envHash": env_hash,
            "cacheMode": self._cache_mode,
            "steps": [
                {"type": step.type, "data": step.hash_data}
                for step in self._steps
            ],
            "conditions": [
                {
                    "name": condition.name,
                    "timeout": condition.timeout,
                    "interval": condition.interval,
                    "data": condition.hash_data or {"name": condition.name},
                }
                for condition in self._conditions
            ],
        }
        payload = json.dumps(spec, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return _sha256_bytes(payload)


def condition(
    predicate: Callable[[Any], bool],
    *,
    name: str,
    timeout: float = 300.0,
    interval: float = 1.0,
    hash_data: dict[str, Any] | None = None,
) -> BuildCondition:
    """Create a reusable named build condition."""
    return BuildCondition(
        name=name,
        predicate=predicate,
        timeout=timeout,
        interval=interval,
        hash_data=hash_data or {"name": name},
    )


def http_ready(
    port: int,
    path: str = "/",
    *,
    expected_status: int = 200,
    port_type: str = "http",
    method: str = "GET",
    timeout: float = 300.0,
    interval: float = 1.0,
) -> BuildCondition:
    """Create a build condition that waits for an HTTP endpoint to become ready."""

    def _predicate(sandbox: Any) -> bool:
        return sandbox.http_ready(
            port,
            path=path,
            port_type=port_type,
            expected_status=expected_status,
            timeout=min(interval * 2, 5.0),
            method=method,
        )

    return BuildCondition(
        name=f"http-ready:{port_type}:{port}:{path}:{expected_status}:{method.upper()}",
        predicate=_predicate,
        timeout=timeout,
        interval=interval,
        hash_data={
            "type": "http_ready",
            "port": port,
            "path": path,
            "expectedStatus": expected_status,
            "portType": port_type,
            "method": method.upper(),
        },
    )


def image(
    base_image: str | None,
    base_snapshot_id: str | None = None,
    workspace_id: str | None = None,
    name: str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> ImageBuilder:
    return ImageBuilder(
        base_image=base_image,
        base_snapshot_id=base_snapshot_id,
        workspace_id=workspace_id,
        name=name,
        api_url=api_url,
        api_key=api_key,
        access_token=access_token,
    )


def py(
    version: str | None = None,
    *,
    base_snapshot_id: str | None = None,
    workspace_id: str | None = None,
    name: str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
) -> ImageBuilder:
    """Convenience constructor for a python slim base image."""
    resolved_version = str(version).strip() if version else "3.11"
    base_image = f"python:{resolved_version}-slim"
    return image(
        base_image=base_image,
        base_snapshot_id=base_snapshot_id,
        workspace_id=workspace_id,
        name=name,
        api_url=api_url,
        api_key=api_key,
        access_token=access_token,
    )


__all__ = ["BuildCondition", "ImageBuilder", "condition", "http_ready", "image", "py"]
