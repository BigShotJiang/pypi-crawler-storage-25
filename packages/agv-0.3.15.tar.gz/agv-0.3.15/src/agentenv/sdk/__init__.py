"""Python SDK for AgentEnv Cloud.

Usage:
    import agentenv as agv

    # Initialize client
    client = agv.Client(api_key="sk_live_xxxxx")

    # Create sandbox
    sandbox = client.sandbox.create(image="python:3.11", cpu=2000, memory=4096)

    # Wait for it to start
    sandbox.wait_for_status("running")

    # Get logs
    logs = sandbox.logs()

    # Expose port
    mapping = sandbox.expose_port(8080, "http")
"""

import socket
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx

from ..api.app import AppAPI as _AppAPI
from ..api.auth import AuthAPI as _AuthAPI
from ..api.bot_integrations import BotIntegrationsAPI as _BotIntegrationsAPI
from ..api.client import Client as _Client
from ..api.extensions import ManagedAgentExtensionsAPI as _ExtensionsAPI
from ..api.file import FileAPI as _FileAPI
from ..api.managed_agent_git import (
    GitCommandError,
    GitStatusEntry,
)
from ..api.managed_agent_git import (
    ManagedAgentGit as _ManagedAgentGit,
)
from ..api.models import (
    APIError,
    App,
    AppVersion,
    BotConversation,
    BotConversationListResponse,
    BotEvent,
    BotEventListResponse,
    BotIntegration,
    BrowserSession,
    CellOutput,
    CreateManagedAgentMcpDefinitionRequest,
    ExecutionResult,
    FileMetadata,
    ImageSnapshot,
    ImageTag,
    ManagedAgent,
    ManagedAgentContentBlob,
    ManagedAgentListResponse,
    ManagedAgentMcpDefinition,
    ManagedAgentMcpSecretRefs,
    ManagedAgentMessage,
    ManagedAgentPathContent,
    ManagedAgentSkillAsset,
    ManagedAgentStreamEvent,
    NotebookCell,
    NotebookCellDetail,
    NotebookCollaborator,
    NotebookDocument,
    NotebookSession,
    OperationSuccess,
    PortMapping,
    Sandbox,
    SandboxExecResult,
    Site,
    SiteVersion,
    Snapshot,
    SyncTelegramWebhookResult,
    Workflow,
    WorkflowDefinition,
    WorkflowExecution,
    WorkflowMetrics,
    WorkflowNodeDefinition,
    WorkflowNodeDefinitionLight,
    WorkflowTimeSeriesPoint,
    Workspace,
)
from ..api.site import SiteAPI as _SiteAPI
from ..api.workflow import WorkflowAPI as _WorkflowAPI
from ..config.settings import get_settings
from ._auth import resolve_credentials
from .ai import AIClient, ChatCompletions, Embeddings, ManagementAPI
from .function import RemoteFunctionError, function


class Client:
    """AgentEnv Cloud Python SDK client."""

    def __init__(
        self,
        api_key: str | None = None,
        api_url: str | None = None,
        access_token: str | None = None,
    ):
        """Initialize AgentEnv client.

        Args:
            api_key: API key for authentication
            api_url: API server URL (default: from settings or http://localhost:3000)
            access_token: JWT access token
        """
        settings = get_settings()

        resolved_api_key, resolved_access_token = resolve_credentials(
            settings,
            api_key=api_key,
            access_token=access_token,
        )
        resolved_api_url = api_url or settings.api_url

        self._client = _Client(
            base_url=resolved_api_url,
            api_key=resolved_api_key,
            access_token=resolved_access_token,
        )
        self._api_url = resolved_api_url

    @property
    def sandbox(self) -> "SandboxAPI":
        """Sandbox operations."""
        return SandboxAPI(self._client)

    @property
    def snapshot(self) -> "SnapshotAPI":
        """Snapshot operations."""
        return SnapshotAPI(self._client)

    @property
    def image(self) -> "ImageAPI":
        """Image snapshot operations."""
        return ImageAPI(self._client)

    @property
    def browser(self) -> "BrowserAPI":
        """Browser session operations."""
        return BrowserAPI(self._client)

    @property
    def app(self) -> "AppAPI":
        """App deployment operations."""
        return AppAPI(self._client)

    @property
    def site(self) -> "SiteAPI":
        """Static site operations."""
        return SiteAPI(self._client)

    @property
    def file(self) -> "FileAPI":
        """File storage operations."""
        return FileAPI(self._client)

    @property
    def managed_agent(self) -> "ManagedAgentAPI":
        """Managed-agent operations."""
        return ManagedAgentAPI(self._client)

    @property
    def managed_agents(self) -> "ManagedAgentAPI":
        """Alias for managed-agent operations."""
        return ManagedAgentAPI(self._client)

    @property
    def bot_integrations(self) -> "BotIntegrationsAPI":
        """Bot integrations bound to managed agents."""
        return BotIntegrationsAPI(self._client)

    @property
    def notebook(self) -> "NotebookAPI":
        """Notebook session operations."""
        return NotebookAPI(self._client)

    @property
    def workspace(self) -> "WorkspaceAPI":
        """Workspace operations."""
        return WorkspaceAPI(self._client)

    @property
    def workflow(self) -> "WorkflowAPI":
        """Workflow operations."""
        return WorkflowAPI(self._client)

    @property
    def billing(self) -> "BillingAPI":
        """Billing operations."""
        return BillingAPI(self._client)

    @property
    def auth(self) -> _AuthAPI:
        """Authentication and API key operations."""
        return _AuthAPI(self._client)

    @property
    def analytics(self):
        """Analytics operations."""
        return AnalyticsAPIWrapper(self._client)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, *args):
        """Context manager exit."""
        self.close()


class SandboxAPI:
    """Sandbox API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        image: str,
        cpu: int = 2000,
        memory: int = 4096,
        max_lifetime_seconds: int | None = None,
        name: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        **kwargs,
    ) -> "SandboxResource":
        """Create a sandbox.

        Args:
            image: Container image
            cpu: CPU in millis
            memory: Memory in MB
            max_lifetime_seconds: Maximum lifetime in seconds
            name: Optional name
            args: Command arguments
            env: Environment variables
            **kwargs: Additional arguments

        Returns:
            Sandbox resource object
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        # Build request
        data = {
            "image": image if image.startswith("docker://") else f"docker://{image}",
            "cpuMillis": cpu,
            "memoryMb": memory,
            "args": args or [],
            "env": env or {},
            **kwargs,
        }

        if name:
            data["name"] = name
        if max_lifetime_seconds is not None:
            data["maxLifetimeSeconds"] = max_lifetime_seconds

        result = _SandboxAPI(self._api).create(data)
        return SandboxResource(self._api, result)

    def get(self, sandbox_id: str) -> "SandboxResource":
        """Get a sandbox.

        Args:
            sandbox_id: Sandbox ID

        Returns:
            Sandbox resource object
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._api).get(sandbox_id)
        return SandboxResource(self._api, result)

    def list_all(self) -> list["SandboxResource"]:
        """List sandboxes.

        Returns:
            List of sandbox resource objects
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        results = _SandboxAPI(self._api).list_all()
        return [SandboxResource(self._api, r) for r in results]


class SnapshotAPI:
    """Snapshot API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        sandbox_id: str,
        name: str | None = None,
        description: str | None = None,
        with_memory: bool = False,
    ) -> Snapshot:
        """Create a snapshot.

        Args:
            sandbox_id: Sandbox ID
            name: Optional snapshot name
            description: Optional snapshot description
            with_memory: Include memory in snapshot
        Returns:
            Snapshot object
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).create(
            sandbox_id,
            name=name,
            description=description,
            with_memory=with_memory,
        )

    def get(self, snapshot_id: str) -> Snapshot:
        """Get a snapshot.

        Args:
            snapshot_id: Snapshot ID

        Returns:
            Snapshot object
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).get(snapshot_id)

    def list_all(
        self,
        sandbox_id: str | None = None,
        workspace_id: str | None = None,
        status: str | None = None,
        tag: str | None = None,
        include_internal: bool = False,
        page: int = 1,
        limit: int = 100,
    ) -> list[Snapshot]:
        """List snapshots.

        Args:
            sandbox_id: Optional sandbox ID filter
            workspace_id: Optional workspace ID filter
            status: Optional snapshot status filter
            tag: Optional snapshot tag filter
            include_internal: Whether to include internal snapshots
            page: Page number
            limit: Items per page

        Returns:
            List of snapshots
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).list_all(
            sandbox_id=sandbox_id,
            workspace_id=workspace_id,
            status=status,
            tag=tag,
            include_internal=include_internal,
            page=page,
            limit=limit,
        )

    def delete(self, snapshot_id: str) -> None:
        """Delete a snapshot."""
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        _SnapshotAPI(self._api).delete(snapshot_id)

    def restore(self, snapshot_id: str, name: str | None = None) -> Sandbox:
        """Restore a sandbox from snapshot.

        Args:
            snapshot_id: Snapshot ID or name
            name: Optional name for restored sandbox

        Returns:
            Created sandbox
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).restore(snapshot_id, name=name)

    def wait_for_status(
        self,
        snapshot_id: str,
        desired_status: str = "completed",
        timeout: float = 300.0,
        interval: float = 1.0,
    ) -> Snapshot:
        """Wait for a snapshot to reach a desired status."""
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).wait_for_status(
            snapshot_id,
            desired_status=desired_status,
            timeout=timeout,
            interval=interval,
        )


class ImageAPI:
    """Image snapshot API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def list_all(
        self,
        workspace_id: str | None = None,
        build_hash: str | None = None,
        tag: str | None = None,
        scope: str | None = None,
        page: int = 1,
        limit: int = 100,
    ) -> list[ImageSnapshot]:
        """List image snapshots."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).list_all(
            workspace_id=workspace_id,
            build_hash=build_hash,
            tag=tag,
            scope=scope,
            page=page,
            limit=limit,
        )

    def get(self, image_id: str) -> ImageSnapshot:
        """Get image snapshot details."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).get(image_id)

    def delete(self, image_id: str) -> None:
        """Delete an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        _ImageAPI(self._api).delete(image_id)

    def cancel(self, image_id: str) -> ImageSnapshot:
        """Cancel an in-progress image build."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).cancel(image_id)

    def add_tags(self, image_id: str, tags: list[str], overwrite: bool = False) -> ImageSnapshot:
        """Add tags to an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).add_tags(image_id, tags, overwrite)

    def remove_tag(self, image_id: str, tag: str) -> dict[str, Any]:
        """Remove a tag from an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).remove_tag(image_id, tag)

    def resolve(self, workspace_id: str, tag: str) -> ImageSnapshot:
        """Resolve an image tag to an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).resolve(workspace_id, tag)

    def list_tags(
        self,
        workspace_id: str | None = None,
        image_id: str | None = None,
        tag: str | None = None,
    ) -> list[ImageTag]:
        """List image tags."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).list_tags(
            workspace_id=workspace_id,
            image_id=image_id,
            tag=tag,
        )


class BrowserAPI:
    """Browser API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        name: str | None = None,
        workspace_id: str | None = None,
        screen_width: int | None = None,
        screen_height: int | None = None,
        stealth: bool = False,
        adblock: bool | None = None,
        profile_mode: str = "persistent",
        profile_id: str | None = None,
        proxy_url: str | None = None,
        proxy_username: str | None = None,
        proxy_password: str | None = None,
        proxy_provider: str | None = None,
        proxy_type: str | None = None,
        enable_captcha_solver: bool | None = None,
        captcha_provider: str | None = None,
        captcha_api_key: str | None = None,
        enable_rrweb: bool | None = None,
        enable_logger: bool | None = None,
        cpu_millis: int | None = None,
        memory_mb: int | None = None,
        max_lifetime_seconds: int | None = None,
        gpu_type: str | None = None,
        geonode_proxy: dict[str, Any] | None = None,
        width: int | None = None,
        height: int | None = None,
    ) -> BrowserSession:
        """Create a browser session.

        Args:
            name: Session name
            workspace_id: Optional workspace ID
            screen_width: Screen width
            screen_height: Screen height
            stealth: Enable stealth mode

        Returns:
            Browser session
        """
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).create(
            name=name,
            workspace_id=workspace_id,
            screen_width=screen_width,
            screen_height=screen_height,
            enable_stealth=stealth,
            enable_adblock=adblock,
            profile_mode=profile_mode,
            proxy_url=proxy_url,
            proxy_username=proxy_username,
            proxy_password=proxy_password,
            proxy_provider=proxy_provider,
            proxy_type=proxy_type,
            enable_captcha_solver=enable_captcha_solver,
            captcha_provider=captcha_provider,
            captcha_api_key=captcha_api_key,
            enable_rrweb=enable_rrweb,
            enable_logger=enable_logger,
            cpu_millis=cpu_millis,
            memory_mb=memory_mb,
            max_lifetime_seconds=max_lifetime_seconds,
            gpu_type=gpu_type,
            profile_id=profile_id,
            geonode_proxy=geonode_proxy,
            width=width,
            height=height,
        )

    def list_all(
        self,
        workspace_id: str | None = None,
        status: str | None = None,
    ) -> list[BrowserSession]:
        """List browser sessions.

        Returns:
            List of browser sessions
        """
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).list_all(workspace_id=workspace_id, status=status)

    def get(self, session_id: str) -> BrowserSession:
        """Get a browser session."""
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).get(session_id)

    def stop(self, session_id: str) -> BrowserSession:
        """Stop a browser session."""
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).stop(session_id)

    def delete(self, session_id: str) -> None:
        """Delete a browser session."""
        from ..api.browser import BrowserAPI as _BrowserAPI

        _BrowserAPI(self._api).delete(session_id)

    def get_cdp_url(self, session_id: str) -> str:
        """Get the CDP URL for a browser session."""
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).get_cdp_url(session_id)

    def wait_for_status(
        self,
        session_id: str,
        desired_status: str = "running",
        timeout: float = 60.0,
        interval: float = 0.5,
    ) -> BrowserSession:
        """Wait for a browser session to reach a status."""
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).wait_for_status(
            session_id,
            desired_status=desired_status,
            timeout=timeout,
            interval=interval,
        )

    def logs(
        self,
        session_id: str,
        query: str | None = None,
        limit: int | None = None,
        from_time: str | None = None,
        to_time: str | None = None,
        sort: str | None = None,
        log_path: str | None = None,
        raw: bool = False,
    ) -> Any:
        """Get browser session logs."""
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).logs(
            session_id,
            query=query,
            limit=limit,
            from_time=from_time,
            to_time=to_time,
            sort=sort,
            log_path=log_path,
            raw=raw,
        )

    def get_recording_status(self, session_id: str) -> dict[str, Any]:
        """Get recording status for a browser session."""
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).get_recording_status(session_id)


class AppAPI:
    """App deployment SDK wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(self, **kwargs: Any) -> App:
        return _AppAPI(self._api).create(kwargs)

    def list_all(self, workspace_id: str | None = None) -> list[App]:
        return _AppAPI(self._api).list_all(workspace_id=workspace_id)

    def get(self, id_or_slug: str) -> App:
        return _AppAPI(self._api).get(id_or_slug)

    def update(self, id_or_slug: str, **kwargs: Any) -> App:
        return _AppAPI(self._api).update(id_or_slug, **kwargs)

    def delete(self, id_or_slug: str) -> dict[str, Any]:
        return _AppAPI(self._api).delete(id_or_slug)

    def deploy(
        self,
        id_or_slug: str,
        snapshot_id: str,
        *,
        env_overrides: dict[str, str] | None = None,
        entrypoint_override: str | None = None,
    ) -> AppVersion:
        return _AppAPI(self._api).deploy(
            id_or_slug,
            snapshot_id,
            env_overrides=env_overrides,
            entrypoint_override=entrypoint_override,
        )

    def get_versions(self, id_or_slug: str) -> list[AppVersion]:
        return _AppAPI(self._api).get_versions(id_or_slug)

    def rollback(self, id_or_slug: str, version: str) -> AppVersion:
        return _AppAPI(self._api).rollback(id_or_slug, version)

    def get_instances(self, id_or_slug: str) -> list[dict[str, Any]]:
        return _AppAPI(self._api).get_instances(id_or_slug)

    def delete_version(self, id_or_slug: str, version: str) -> None:
        _AppAPI(self._api).delete_version(id_or_slug, version)

    def logs(self, id_or_slug: str, **kwargs: Any) -> Any:
        return _AppAPI(self._api).logs(id_or_slug, **kwargs)


class SiteAPI:
    """Static site SDK wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(self, name: str, slug: str | None = None, workspace_id: str | None = None) -> Site:
        return _SiteAPI(self._api).create(name=name, slug=slug, workspace_id=workspace_id)

    def list_all(self, workspace_id: str | None = None) -> list[Site]:
        return _SiteAPI(self._api).list_all(workspace_id=workspace_id)

    def get(self, site_id: str) -> Site:
        return _SiteAPI(self._api).get(site_id)

    def resolve(self, id_or_slug: str) -> Site | None:
        return _SiteAPI(self._api).resolve(id_or_slug)

    def update(
        self,
        site_id: str,
        *,
        name: str | None = None,
        slug: str | None = None,
        max_versions: int | None = None,
    ) -> Site:
        return _SiteAPI(self._api).update(site_id, name=name, slug=slug, max_versions=max_versions)

    def delete(self, site_id: str) -> None:
        _SiteAPI(self._api).delete(site_id)

    def check_slug(self, slug: str) -> bool:
        return _SiteAPI(self._api).check_slug(slug)

    def deploy(self, site_id: str, zip_path: Path) -> Site:
        return _SiteAPI(self._api).deploy(site_id, zip_path)

    def get_versions(self, site_id: str) -> list[SiteVersion]:
        return _SiteAPI(self._api).get_versions(site_id)

    def rollback(self, site_id: str, version: str) -> Site:
        return _SiteAPI(self._api).rollback(site_id, version)

    def delete_version(self, site_id: str, version: str) -> None:
        _SiteAPI(self._api).delete_version(site_id, version)


class FileAPI:
    """File storage SDK wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def upload(
        self,
        file_path: str,
        *,
        workspace_id: str | None = None,
        remote_path: str | None = None,
    ) -> FileMetadata:
        return _FileAPI(self._api).upload(file_path, workspace_id, remote_path)

    def list_all(self, *, workspace_id: str | None = None, path: str | None = None) -> list[FileMetadata]:
        return _FileAPI(self._api).list_all(workspace_id=workspace_id, path=path)

    def get_metadata(self, path: str, *, workspace_id: str | None = None) -> FileMetadata:
        return _FileAPI(self._api).get_metadata(workspace_id, path)

    def get_content(self, path: str, *, workspace_id: str | None = None) -> bytes:
        return _FileAPI(self._api).get_content(workspace_id, path)

    def download(self, remote_path: str, local_path: str, *, workspace_id: str | None = None) -> None:
        _FileAPI(self._api).download(remote_path, local_path, workspace_id)

    def create_directory(self, path: str, *, workspace_id: str | None = None) -> FileMetadata:
        return _FileAPI(self._api).create_directory(path, workspace_id)

    def delete(self, path: str, *, workspace_id: str | None = None) -> None:
        _FileAPI(self._api).delete(path, workspace_id)

    def update_metadata(
        self,
        path: str,
        metadata: dict[str, Any],
        *,
        workspace_id: str | None = None,
    ) -> FileMetadata:
        return _FileAPI(self._api).update_metadata(path, metadata, workspace_id)


class ManagedAgentAPI:
    """Managed-agent API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def list_all(
        self,
        *,
        workspace_id: str | None = None,
        agent_workspace_group_id: str | None = None,
        search: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> ManagedAgentListResponse:
        """List managed agents."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).list_all(
            workspace_id=workspace_id,
            agent_workspace_group_id=agent_workspace_group_id,
            search=search,
            page=page,
            limit=limit,
        )

    def create(
        self,
        *,
        name: str,
        workspace_id: str,
        upstream_id: str,
        model: str | None = None,
        instructions: str | None = None,
        image: str | None = None,
        workspace_template: str | None = None,
        cpu_millis: int | None = None,
        memory_mb: int | None = None,
        agent_workspace_group_id: str | None = None,
        enabled_skill_ids: list[str] | None = None,
        enabled_mcp_ids: list[str] | None = None,
    ) -> ManagedAgent:
        """Create a managed agent.

        The create response may include ``public_token`` once when the server
        is configured to return a managed-agent public token.
        """
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).create(
            name=name,
            workspace_id=workspace_id,
            upstream_id=upstream_id,
            model=model,
            instructions=instructions,
            image=image,
            workspace_template=workspace_template,
            cpu_millis=cpu_millis,
            memory_mb=memory_mb,
            agent_workspace_group_id=agent_workspace_group_id,
            enabled_skill_ids=enabled_skill_ids,
            enabled_mcp_ids=enabled_mcp_ids,
        )

    def get(self, agent_id: str) -> ManagedAgent:
        """Get a managed agent.

        This does not reissue ``public_token``; persist the create-time value if
        you need later access to ``/v1/public/managed-agent/*`` helper routes.
        """
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).get(agent_id)

    def list_messages(self, agent_id: str) -> list[ManagedAgentMessage]:
        """List transcript messages for a managed agent."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).list_messages(agent_id)

    def get_file_content(
        self,
        agent_id: str,
        content_hash: str,
    ) -> ManagedAgentContentBlob:
        """Read file content by CAS hash."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).get_file_content(agent_id, content_hash)

    def read_file(self, agent_id: str, path: str) -> ManagedAgentPathContent:
        """Read current file content from the managed-agent sandbox."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).read_file(agent_id, path)

    def git_show(
        self,
        agent_id: str,
        path: str,
        *,
        ref: str = "HEAD",
    ) -> ManagedAgentPathContent:
        """Read committed file content from the managed-agent sandbox."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).git_show(agent_id, path, ref=ref)

    def list_browser_sessions(self, agent_id: str) -> list[BrowserSession]:
        """List browser sessions linked to a managed agent."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).list_browser_sessions(agent_id)

    def wake(self, agent_id: str) -> ManagedAgent:
        """Wake a sleeping managed agent."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).wake(agent_id)

    @staticmethod
    def _is_inflight_wake_error(exc: APIError) -> bool:
        """Return True when wake failed only because the agent is already waking."""
        message = exc.message.lower()
        error_code = str(exc.details.get("code", "")).lower()
        return exc.status_code == 409 and (
            "already waking" in message or error_code == "already_waking"
        )

    def wake_and_wait(
        self,
        agent_id: str,
        *,
        desired_status: str = "running",
        timeout: float = 120.0,
        interval: float = 0.5,
    ) -> ManagedAgent:
        """Wake a managed agent and wait for the desired status."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        api = _ManagedAgentAPI(self._api)
        try:
            api.wake(agent_id)
        except APIError as exc:
            # The backend may already be waking the agent; poll the current state either way.
            if not self._is_inflight_wake_error(exc):
                raise
        return api.wait_for_status(
            agent_id,
            desired_status=desired_status,
            timeout=timeout,
            interval=interval,
        )

    def wait_for_status(
        self,
        agent_id: str,
        desired_status: str = "running",
        timeout: float = 120.0,
        interval: float = 0.5,
    ) -> ManagedAgent:
        """Wait for a managed agent to reach the desired status."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).wait_for_status(
            agent_id,
            desired_status=desired_status,
            timeout=timeout,
            interval=interval,
        )

    def delete(self, agent_id: str) -> OperationSuccess:
        """Delete a managed agent."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).delete(agent_id)

    def fork(self, agent_id: str) -> ManagedAgent:
        """Fork a managed agent."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).fork(agent_id)

    def stream_message(
        self,
        agent_id: str,
        content: str,
    ) -> Iterator[ManagedAgentStreamEvent]:
        """Yield SSE events for a managed-agent message."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).stream_message(agent_id, content)

    def send_message(
        self,
        agent_id: str,
        content: str,
    ) -> list[ManagedAgentStreamEvent]:
        """Collect the full managed-agent event stream."""
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI

        return _ManagedAgentAPI(self._api).send_message(agent_id, content)

    @property
    def extensions(self) -> _ExtensionsAPI:
        """Skills + MCP definitions + per-agent assignments.

        Example::

            mcp = client.managed_agents.extensions.create_mcp_definition(
                name="GitHub",
                config={"command": "npx", "args": ["-y",
                    "@modelcontextprotocol/server-github"]},
                workspace_id=workspace.id,
            )
            client.managed_agents.extensions.set_mcp_assignment(
                agent.id, mcp.id, enabled=True
            )
        """
        return _ExtensionsAPI(self._api)

    @property
    def telegram(self) -> "ManagedAgentTelegramAPI":
        """Telegram binding helpers for managed agents."""
        return ManagedAgentTelegramAPI(self._api)

    def git(
        self,
        agent_id: str,
        *,
        cwd: str = "/workspace",
    ) -> _ManagedAgentGit:
        """Return an e2b-style git helper for ``agent_id``'s sandbox.

        The helper shells out through the existing sandbox exec path — no
        new HTTP endpoints are needed on the api-server. Example::

            git = client.managed_agents.git(agent.id)
            git.configure_identity(name="Agent", email="agent@example.com")
            git.clone("https://github.com/octocat/Hello-World.git")
            git.exec("ls Hello-World")
        """
        from ..api.managed_agent import ManagedAgentAPI as _ManagedAgentAPI
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _ManagedAgentGit(
            agent_id,
            sandbox_api=_SandboxAPI(self._api),
            managed_agent_api=_ManagedAgentAPI(self._api),
            cwd=cwd,
        )


class ManagedAgentTelegramAPI:
    """Telegram helpers scoped to managed-agent bindings."""

    def __init__(self, client: _Client):
        self._api = client

    def bind(
        self,
        agent_id: str,
        *,
        workspace_id: str,
        name: str,
        bot_token: str | None = None,
        bot_token_key: str | None = None,
        secret_token: str | None = None,
        secret_token_key: str | None = None,
        allow_groups: bool | None = None,
        require_mention_in_groups: bool | None = None,
        allowed_chat_ids: list[str] | None = None,
        bot_username: str | None = None,
        owner_user_id: str | None = None,
        agent_workspace_group_id: str | None = None,
        model: str | None = None,
        instructions: str | None = None,
    ) -> BotIntegration:
        """Bind ``agent_id`` to a Telegram bot integration."""
        return _BotIntegrationsAPI(self._api).create_telegram(
            workspace_id,
            agent_id=agent_id,
            name=name,
            bot_token=bot_token,
            bot_token_key=bot_token_key,
            secret_token=secret_token,
            secret_token_key=secret_token_key,
            allow_groups=allow_groups,
            require_mention_in_groups=require_mention_in_groups,
            allowed_chat_ids=allowed_chat_ids,
            bot_username=bot_username,
            owner_user_id=owner_user_id,
            agent_workspace_group_id=agent_workspace_group_id,
            model=model,
            instructions=instructions,
        )

    def list(self, workspace_id: str) -> list[BotIntegration]:
        """List Telegram integrations in a workspace."""
        integrations = _BotIntegrationsAPI(self._api).list_all(workspace_id)
        return [item for item in integrations if item.provider == "telegram"]

    def sync_webhook(
        self,
        workspace_id: str,
        integration_id: str,
        *,
        drop_pending_updates: bool | None = None,
    ) -> SyncTelegramWebhookResult:
        """Sync Telegram webhook + commands for a binding."""
        return _BotIntegrationsAPI(self._api).sync_telegram_webhook(
            workspace_id,
            integration_id,
            drop_pending_updates=drop_pending_updates,
        )

    def disable(self, workspace_id: str, integration_id: str) -> BotIntegration:
        """Disable a Telegram integration."""
        return _BotIntegrationsAPI(self._api).disable(workspace_id, integration_id)


class BotIntegrationsAPI:
    """Bot integrations API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def list_all(self, workspace_id: str) -> list[BotIntegration]:
        return _BotIntegrationsAPI(self._api).list_all(workspace_id)

    def create_telegram(
        self,
        workspace_id: str,
        *,
        agent_id: str,
        name: str,
        bot_token: str | None = None,
        bot_token_key: str | None = None,
        secret_token: str | None = None,
        secret_token_key: str | None = None,
        allow_groups: bool | None = None,
        require_mention_in_groups: bool | None = None,
        allowed_chat_ids: list[str] | None = None,
        bot_username: str | None = None,
        owner_user_id: str | None = None,
        agent_workspace_group_id: str | None = None,
        model: str | None = None,
        instructions: str | None = None,
    ) -> BotIntegration:
        return _BotIntegrationsAPI(self._api).create_telegram(
            workspace_id,
            agent_id=agent_id,
            name=name,
            bot_token=bot_token,
            bot_token_key=bot_token_key,
            secret_token=secret_token,
            secret_token_key=secret_token_key,
            allow_groups=allow_groups,
            require_mention_in_groups=require_mention_in_groups,
            allowed_chat_ids=allowed_chat_ids,
            bot_username=bot_username,
            owner_user_id=owner_user_id,
            agent_workspace_group_id=agent_workspace_group_id,
            model=model,
            instructions=instructions,
        )

    def get(self, workspace_id: str, integration_id: str) -> BotIntegration:
        return _BotIntegrationsAPI(self._api).get(workspace_id, integration_id)

    def update(
        self,
        workspace_id: str,
        integration_id: str,
        **fields: Any,
    ) -> BotIntegration:
        return _BotIntegrationsAPI(self._api).update(
            workspace_id,
            integration_id,
            **fields,
        )

    def enable(self, workspace_id: str, integration_id: str) -> BotIntegration:
        return _BotIntegrationsAPI(self._api).enable(workspace_id, integration_id)

    def disable(self, workspace_id: str, integration_id: str) -> BotIntegration:
        return _BotIntegrationsAPI(self._api).disable(workspace_id, integration_id)

    def list_conversations(
        self,
        workspace_id: str,
        integration_id: str,
        *,
        page: int | None = None,
        limit: int | None = None,
    ) -> BotConversationListResponse:
        return _BotIntegrationsAPI(self._api).list_conversations(
            workspace_id,
            integration_id,
            page=page,
            limit=limit,
        )

    def list_events(
        self,
        workspace_id: str,
        integration_id: str,
        *,
        page: int | None = None,
        limit: int | None = None,
    ) -> BotEventListResponse:
        return _BotIntegrationsAPI(self._api).list_events(
            workspace_id,
            integration_id,
            page=page,
            limit=limit,
        )

    def sync_telegram_webhook(
        self,
        workspace_id: str,
        integration_id: str,
        *,
        drop_pending_updates: bool | None = None,
    ) -> SyncTelegramWebhookResult:
        return _BotIntegrationsAPI(self._api).sync_telegram_webhook(
            workspace_id,
            integration_id,
            drop_pending_updates=drop_pending_updates,
        )


class NotebookAPI:
    """Notebook API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        workspace_id: str,
        name: str | None = None,
        type: str = "small",
        cpu: int | None = None,
        memory: int | None = None,
        image: str | None = None,
        snapshot_id: str | None = None,
        gpu_count: int | None = None,
        gpu_type: str | None = None,
        storage_mode: str | None = None,
        env: dict[str, str] | None = None,
        idle_ttl_seconds: int | None = None,
        persistent: bool | None = None,
        snapshot_favor: str | None = None,
        hard_kill_at: str | None = None,
        hard_kill_after_seconds: int | None = None,
    ) -> NotebookSession:
        """Create a notebook session.

        Args:
            workspace_id: Workspace ID
            type: Sandbox type preset
            cpu: Custom CPU in millis
            memory: Custom memory in MB

        Returns:
            Notebook session
        """
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).create(
            workspace_id=workspace_id,
            name=name,
            type=type,
            cpu=cpu,
            memory=memory,
            image=image,
            snapshot_id=snapshot_id,
            gpu_count=gpu_count,
            gpu_type=gpu_type,
            storage_mode=storage_mode,
            env=env,
            idle_ttl_seconds=idle_ttl_seconds,
            persistent=persistent,
            snapshot_favor=snapshot_favor,
            hard_kill_at=hard_kill_at,
            hard_kill_after_seconds=hard_kill_after_seconds,
        )

    def list_all(self, workspace_id: str | None = None) -> list[NotebookSession]:
        """List notebook sessions.

        Returns:
            List of notebook sessions
        """
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_all(workspace_id=workspace_id)

    def get(self, session_id: str) -> NotebookSession:
        """Get notebook session details."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).get(session_id)

    def stop(self, session_id: str) -> NotebookSession:
        """Stop a notebook session."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).stop(session_id)

    def wake(self, session_id: str) -> NotebookSession:
        """Wake a notebook session from its latest snapshot."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).wake(session_id)

    def delete(self, session_id: str) -> None:
        """Delete a notebook session."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        _NotebookAPI(self._api).delete(session_id)

    def wait_for_status(
        self,
        session_id: str,
        desired_status: str = "running",
        timeout: float = 120.0,
        interval: float = 0.5,
    ) -> NotebookSession:
        """Wait for a notebook session to reach a desired status."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).wait_for_status(
            session_id,
            desired_status=desired_status,
            timeout=timeout,
            interval=interval,
        )

    def create_document(
        self,
        workspace_id: str,
        name: str,
        *,
        description: str | None = None,
        kernel: str | None = None,
        runtime: str | None = None,
        image: str | None = None,
        auto_save_enabled: bool | None = None,
        markdown_first_cell: bool = False,
    ) -> NotebookDocument:
        """Create a notebook document."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).create_document(
            workspace_id=workspace_id,
            name=name,
            description=description,
            kernel=kernel,
            runtime=runtime,
            image=image,
            auto_save_enabled=auto_save_enabled,
            markdown_first_cell=markdown_first_cell,
        )

    def list_documents(self, workspace_id: str) -> list[NotebookDocument]:
        """List notebook documents in a workspace."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_documents(workspace_id)

    def get_document(self, notebook_id: str) -> NotebookDocument:
        """Get notebook document details."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).get_document(notebook_id)

    def update_document(
        self,
        notebook_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        kernel: str | None = None,
        runtime: str | None = None,
        auto_save_enabled: bool | None = None,
    ) -> NotebookDocument:
        """Update notebook document metadata."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).update_document(
            notebook_id=notebook_id,
            name=name,
            description=description,
            kernel=kernel,
            runtime=runtime,
            auto_save_enabled=auto_save_enabled,
        )

    def delete_document(self, notebook_id: str) -> None:
        """Delete a notebook document."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        _NotebookAPI(self._api).delete_document(notebook_id)

    def duplicate_document(self, notebook_id: str) -> NotebookDocument:
        """Duplicate a notebook document."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).duplicate_document(notebook_id)

    def import_document(
        self,
        workspace_id: str,
        *,
        name: str | None = None,
        url: str | None = None,
        file_path: str | None = None,
        image: str | None = None,
    ) -> NotebookDocument:
        """Import a notebook document from URL or local file."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).import_document(
            workspace_id=workspace_id,
            name=name,
            url=url,
            file_path=file_path,
            image=image,
        )

    def export_document(
        self,
        notebook_id: str,
        *,
        download: bool = False,
    ) -> dict[str, Any] | str:
        """Export notebook document content."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).export_document(
            notebook_id,
            download=download,
        )

    def save_document(self, notebook_id: str) -> NotebookDocument:
        """Persist notebook document to storage."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).save_document(notebook_id)

    @staticmethod
    def _validate_cell_selector(
        index: int | None = None,
        cell_id: str | None = None,
    ) -> None:
        has_index = index is not None
        has_id = bool(cell_id)
        if has_index == has_id:
            raise ValueError("Provide exactly one of index or cell_id")
        if index is not None and index < 0:
            raise ValueError("index must be a non-negative integer")

    def list_cells(
        self,
        notebook_id: str,
        *,
        include_outputs: bool = False,
    ) -> list[NotebookCell] | list[NotebookCellDetail]:
        """List cells in a notebook."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_cells(
            notebook_id,
            include_outputs=include_outputs,
        )

    def add_cell(
        self,
        notebook_id: str,
        content: str,
        *,
        cell_type: str = "code",
        index: int | None = None,
    ) -> NotebookCell:
        """Add a cell to a notebook."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).add_cell(
            notebook_id,
            content,
            cell_type=cell_type,
            index=index,
        )

    def get_cell(
        self,
        notebook_id: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
    ) -> NotebookCellDetail:
        """Get a cell by ID or zero-based index."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        self._validate_cell_selector(index=index, cell_id=cell_id)
        api = _NotebookAPI(self._api)
        if cell_id:
            return api.get_cell(notebook_id, cell_id)
        return api.get_cell_by_index(notebook_id, index or 0)

    def update_cell(
        self,
        notebook_id: str,
        content: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
    ) -> NotebookCell:
        """Update a cell source by ID or index with optimistic concurrency."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        resolved = self.get_cell(notebook_id, index=index, cell_id=cell_id)
        return _NotebookAPI(self._api).update_cell_source(
            notebook_id,
            resolved.id,
            content,
            expected_version=resolved.source_ot_version,
        )

    def remove_cell(
        self,
        notebook_id: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
    ) -> None:
        """Delete a cell by ID or index."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        resolved = self.get_cell(notebook_id, index=index, cell_id=cell_id)
        _NotebookAPI(self._api).delete_cell(notebook_id, resolved.id)

    def ensure_kernel(
        self,
        notebook_id: str,
        *,
        wait: bool = False,
        timeout: int = 120,
    ) -> dict[str, Any]:
        """Ensure kernel exists and optionally wait until ready."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        api = _NotebookAPI(self._api)
        ensured = api.ensure_kernel(notebook_id)
        if not wait:
            return ensured

        import time

        start = time.time()
        while time.time() - start < timeout:
            kernel_status = api.get_kernel_status(notebook_id)
            status = str(kernel_status.get("status") or "")
            message = str(kernel_status.get("message") or "")
            if status == "idle" or (status == "busy" and message != "Kernel starting"):
                return {
                    "status": "running",
                    "ensureStatus": ensured.get("status"),
                    "kernelStatus": kernel_status,
                }
            time.sleep(0.5)

        raise TimeoutError(f"Timeout waiting for kernel readiness ({timeout}s)")

    def get_kernel_status(self, notebook_id: str) -> dict[str, Any]:
        """Get notebook kernel status."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).get_kernel_status(notebook_id)

    def interrupt_kernel(self, notebook_id: str) -> dict[str, Any]:
        """Interrupt a notebook kernel."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).interrupt_kernel(notebook_id)

    def restart_kernel(self, notebook_id: str) -> dict[str, Any]:
        """Restart a notebook kernel."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).restart_kernel(notebook_id)

    def update_kernel_ttl_policy(
        self,
        notebook_id: str,
        *,
        persistent: bool | None = None,
        idle_ttl_seconds: int | None = None,
        snapshot_favor: str | None = None,
        hard_kill_at: str | None = None,
        hard_kill_after_seconds: int | None = None,
    ) -> dict[str, Any]:
        """Update notebook kernel TTL policy."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).update_kernel_ttl_policy(
            notebook_id,
            persistent=persistent,
            idle_ttl_seconds=idle_ttl_seconds,
            snapshot_favor=snapshot_favor,
            hard_kill_at=hard_kill_at,
            hard_kill_after_seconds=hard_kill_after_seconds,
        )

    def get_cell_outputs(self, notebook_id: str, cell_id: str) -> list[CellOutput]:
        """Get outputs for a cell."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).get_cell_outputs(notebook_id, cell_id)

    def clear_notebook_outputs(self, notebook_id: str) -> dict[str, Any]:
        """Clear outputs for all code cells in a notebook."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).clear_notebook_outputs(notebook_id)

    def execute_cell(
        self,
        notebook_id: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
        wait: bool = True,
        timeout: int = 30,
    ) -> ExecutionResult | NotebookCellDetail:
        """Execute a cell and optionally wait for completion."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        self._validate_cell_selector(index=index, cell_id=cell_id)
        api = _NotebookAPI(self._api)
        result = api.execute_cell(
            notebook_id,
            cell_id=cell_id,
            cell_index=index,
        )
        if not wait:
            return result

        import time

        def _normalize_outputs(cell: NotebookCellDetail) -> list[dict]:
            outputs = getattr(cell, "outputs", None)
            if not isinstance(outputs, list):
                return []
            return [output.model_dump(by_alias=True, exclude_none=True) for output in outputs]

        def _is_execution_complete(
            cell: NotebookCellDetail,
            baseline_outputs: list[dict],
            baseline_execution_count: int | None,
            baseline_last_run_at: int | None,
            baseline_last_run_duration: float | int | None,
        ) -> bool:
            outputs = getattr(cell, "outputs", None)
            has_outputs = isinstance(outputs, (list, tuple)) and len(outputs) > 0
            has_execution_count = isinstance(cell.execution_count, int)
            has_last_run_at = isinstance(cell.last_run_at, int)
            has_last_run_duration = isinstance(cell.last_run_duration, (int, float))
            execution_settled = cell.status not in ("starting", "running")
            return (
                cell.status in ("ok", "error")
                or (has_outputs and _normalize_outputs(cell) != baseline_outputs)
                or (has_execution_count and cell.execution_count != baseline_execution_count)
                or (
                    execution_settled
                    and has_last_run_at
                    and cell.last_run_at != baseline_last_run_at
                )
                or (
                    execution_settled
                    and has_last_run_duration
                    and cell.last_run_duration != baseline_last_run_duration
                )
            )

        baseline_cell = self.get_cell(notebook_id, index=index, cell_id=cell_id)
        baseline_outputs = _normalize_outputs(baseline_cell)
        baseline_execution_count = (
            baseline_cell.execution_count if isinstance(baseline_cell.execution_count, int) else None
        )
        baseline_last_run_at = (
            baseline_cell.last_run_at if isinstance(baseline_cell.last_run_at, int) else None
        )
        baseline_last_run_duration = (
            baseline_cell.last_run_duration
            if isinstance(baseline_cell.last_run_duration, (int, float))
            else None
        )

        start = time.time()
        while time.time() - start < timeout:
            cell = self.get_cell(notebook_id, index=index, cell_id=cell_id)
            if _is_execution_complete(
                cell,
                baseline_outputs,
                baseline_execution_count,
                baseline_last_run_at,
                baseline_last_run_duration,
            ):
                return cell
            time.sleep(0.5)

        raise TimeoutError(f"Timeout waiting for cell execution ({timeout}s)")

    def list_files(
        self,
        notebook_id: str,
        path: str | None = None,
    ) -> list[FileMetadata]:
        """List notebook-scoped files."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_files(notebook_id, path)

    def create_directory(self, notebook_id: str, path: str) -> FileMetadata:
        """Create a notebook-scoped directory."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).create_directory(notebook_id, path)

    def upload_file(
        self,
        notebook_id: str,
        file_path: str,
        remote_path: str | None = None,
        remote_filename: str | None = None,
    ) -> FileMetadata:
        """Upload a notebook-scoped file."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).upload_file(
            notebook_id,
            file_path,
            remote_path=remote_path,
            remote_filename=remote_filename,
        )

    def download_file(
        self,
        notebook_id: str,
        remote_path: str,
        local_path: str,
    ) -> None:
        """Download a notebook-scoped file."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        _NotebookAPI(self._api).download_file(notebook_id, remote_path, local_path)

    def delete_file(self, notebook_id: str, path: str) -> None:
        """Delete a notebook-scoped file or directory."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        _NotebookAPI(self._api).delete_file(notebook_id, path)

    def list_collaborators(self, notebook_id: str) -> list[NotebookCollaborator]:
        """List active collaborators for a notebook."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_collaborators(notebook_id)


class WorkspaceAPI:
    """Workspace API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(self, name: str) -> Workspace:
        """Create a workspace.

        Args:
            name: Workspace name

        Returns:
            Workspace object
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).create(name)

    def list_all(self, page: int = 1, limit: int = 100) -> list[Workspace]:
        """List workspaces.

        Args:
            page: Page number
            limit: Maximum results per page

        Returns:
            List of workspaces
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).list_all(page=page, limit=limit)

    def get(self, workspace_id: str):
        """Get workspace details.

        Args:
            workspace_id: Workspace ID

        Returns:
            Detailed workspace object
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).get(workspace_id)

    def update(self, workspace_id: str, data: dict[str, Any]) -> Workspace:
        """Update a workspace.

        Args:
            workspace_id: Workspace ID
            data: Partial workspace fields to update

        Returns:
            Updated workspace object
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).update(workspace_id, data)

    def delete(self, workspace_id: str) -> None:
        """Delete a workspace.

        Args:
            workspace_id: Workspace ID
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        _WorkspaceAPI(self._api).delete(workspace_id)

    def invite_member(
        self,
        workspace_id: str,
        identifier: str,
        role: str | None = None,
    ) -> dict[str, Any]:
        """Invite a member to a workspace.

        Args:
            workspace_id: Workspace ID
            identifier: Member email or user ID
            role: Optional role to grant

        Returns:
            Invitation response payload
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).invite_member(
            workspace_id,
            identifier,
            role=role,
        )

    def join(self, join_code: str) -> Workspace:
        """Join a workspace using a join code.

        Args:
            join_code: Workspace join code

        Returns:
            Joined workspace object
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).join(join_code)

    def remove_member(self, workspace_id: str, user_id: str) -> None:
        """Remove a member from a workspace.

        Args:
            workspace_id: Workspace ID
            user_id: User ID to remove
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        _WorkspaceAPI(self._api).remove_member(workspace_id, user_id)

    def get_members(self, workspace_id: str):
        """Get workspace members.

        Args:
            workspace_id: Workspace ID

        Returns:
            List of workspace members
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).get_members(workspace_id)

    def get_default_billing_account_id(self, workspace_id: str) -> str | None:
        """Get the default billing account linked to a workspace."""
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).get_default_billing_account_id(workspace_id)

    def create_secret(
        self,
        workspace_id: str,
        key: str,
        value: str,
    ) -> dict[str, Any]:
        """Create a workspace secret."""
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).create_secret(workspace_id, key, value)

    def list_secrets(self, workspace_id: str) -> list[dict[str, Any]]:
        """List workspace secret metadata."""
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).list_secrets(workspace_id)

    def delete_secret(self, workspace_id: str, secret_id: str) -> None:
        """Delete a workspace secret."""
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        _WorkspaceAPI(self._api).delete_secret(workspace_id, secret_id)

    def update_secret(
        self,
        workspace_id: str,
        secret_id: str,
        *,
        key: str | None = None,
        value: str | None = None,
    ) -> dict[str, Any]:
        """Update a workspace secret."""
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).update_secret(
            workspace_id,
            secret_id,
            key=key,
            value=value,
        )


class WorkflowAPI:
    """Workflow SDK wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def list_all(
        self,
        workspace_id: str,
        *,
        status: str | None = None,
    ) -> list[Workflow]:
        return _WorkflowAPI(self._api).list_all(workspace_id, status=status)

    def create(
        self,
        workspace_id: str,
        name: str,
        definition: dict[str, Any] | WorkflowDefinition,
        *,
        description: str | None = None,
    ) -> Workflow:
        return _WorkflowAPI(self._api).create(workspace_id, name, definition, description=description)

    def get(self, workflow_id: str) -> Workflow:
        return _WorkflowAPI(self._api).get(workflow_id)

    def update(
        self,
        workflow_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        definition: dict[str, Any] | WorkflowDefinition | None = None,
        status: str | None = None,
    ) -> Workflow:
        return _WorkflowAPI(self._api).update(
            workflow_id,
            name=name,
            description=description,
            definition=definition,
            status=status,
        )

    def delete(self, workflow_id: str) -> dict[str, Any]:
        return _WorkflowAPI(self._api).delete(workflow_id)

    def deploy(self, workflow_id: str) -> Workflow:
        return _WorkflowAPI(self._api).deploy(workflow_id)

    def undeploy(self, workflow_id: str) -> Workflow:
        return _WorkflowAPI(self._api).undeploy(workflow_id)

    def execute(
        self,
        workflow_id: str,
        *,
        input_data: Any = None,
        trigger_node_id: str | None = None,
    ) -> dict[str, Any]:
        return _WorkflowAPI(self._api).execute(
            workflow_id,
            input_data=input_data,
            trigger_node_id=trigger_node_id,
        )

    def execute_in_memory(
        self,
        workspace_id: str,
        definition: dict[str, Any] | WorkflowDefinition,
        *,
        input_data: Any = None,
        trigger_node_id: str | None = None,
    ) -> dict[str, Any]:
        return _WorkflowAPI(self._api).execute_in_memory(
            workspace_id,
            definition,
            input_data=input_data,
            trigger_node_id=trigger_node_id,
        )

    def list_executions(
        self,
        workflow_id: str,
        *,
        page: int | None = None,
        limit: int | None = None,
        status: str | None = None,
        from_time: str | None = None,
        to_time: str | None = None,
    ) -> tuple[list[WorkflowExecution], dict[str, Any] | None]:
        return _WorkflowAPI(self._api).list_executions(
            workflow_id,
            page=page,
            limit=limit,
            status=status,
            from_time=from_time,
            to_time=to_time,
        )

    def get_execution(self, workflow_id: str, execution_id: str) -> WorkflowExecution:
        return _WorkflowAPI(self._api).get_execution(workflow_id, execution_id)

    def cancel_execution(self, workflow_id: str, execution_id: str) -> dict[str, Any]:
        return _WorkflowAPI(self._api).cancel_execution(workflow_id, execution_id)

    def list_node_definitions(self) -> list[WorkflowNodeDefinitionLight]:
        return _WorkflowAPI(self._api).list_node_definitions()

    def get_node_definition(self, node_type: str) -> WorkflowNodeDefinition:
        return _WorkflowAPI(self._api).get_node_definition(node_type)

    def list_trusted_plugins(self) -> list[str]:
        return _WorkflowAPI(self._api).list_trusted_plugins()

    def get_metrics(
        self,
        workflow_id: str,
        *,
        from_time: str | None = None,
        to_time: str | None = None,
    ) -> WorkflowMetrics:
        return _WorkflowAPI(self._api).get_metrics(workflow_id, from_time=from_time, to_time=to_time)

    def get_time_series(
        self,
        workflow_id: str,
        *,
        interval: str | None = None,
        from_time: str | None = None,
        to_time: str | None = None,
    ) -> list[WorkflowTimeSeriesPoint]:
        return _WorkflowAPI(self._api).get_time_series(
            workflow_id,
            interval=interval,
            from_time=from_time,
            to_time=to_time,
        )


class BillingAPI:
    """Billing API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def get_balance(self, workspace_id: str) -> dict[str, Any]:
        """Get workspace balance.

        Args:
            workspace_id: Workspace ID

        Returns:
            Balance info
        """
        from ..api.billing import BillingAPI as _BillingAPI

        result = _BillingAPI(self._api).get_balance(workspace_id)
        return {
            "billing_account_id": result.billing_account_id,
            "balance_cents": result.balance_cents,
            "total_charged_cents": result.total_charged_cents,
            "billing_enabled": result.billing_enabled,
        }

    def get_transactions(
        self,
        workspace_id: str,
        *,
        page: int = 1,
        limit: int = 50,
        start_date: str | None = None,
        end_date: str | None = None,
        include_types: list[str] | None = None,
        exclude_types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Get workspace transaction history plus pagination metadata."""
        from ..api.billing import BillingAPI as _BillingAPI

        result = _BillingAPI(self._api).get_transactions(
            workspace_id,
            page=page,
            limit=limit,
            start_date=start_date,
            end_date=end_date,
            include_types=include_types,
            exclude_types=exclude_types,
        )
        return {
            "transactions": [
                txn.model_dump(by_alias=True, exclude_none=True) for txn in result["transactions"]
            ],
            "total": result["total"],
            "page": result["page"],
            "limit": result["limit"],
        }

    def list_billing_accounts(self) -> list[dict[str, Any]]:
        """List billing accounts owned by the current user."""
        from ..api.billing import BillingAPI as _BillingAPI

        return _BillingAPI(self._api).list_billing_accounts()

    def get_billing_account(self, billing_account_id: str) -> dict[str, Any]:
        """Get one owned billing account."""
        from ..api.billing import BillingAPI as _BillingAPI

        return _BillingAPI(self._api).get_billing_account(billing_account_id)

    def get_billing_account_balance(
        self,
        billing_account_id: str,
    ) -> dict[str, Any]:
        """Get the balance for one owned billing account."""
        from ..api.billing import BillingAPI as _BillingAPI

        result = _BillingAPI(self._api).get_billing_account_balance(billing_account_id)
        return {
            "billing_account_id": result.billing_account_id,
            "balance_cents": result.balance_cents,
            "total_charged_cents": result.total_charged_cents,
            "billing_enabled": result.billing_enabled,
        }

    def get_billing_account_transactions(
        self,
        billing_account_id: str,
        *,
        page: int = 1,
        limit: int = 50,
        start_date: str | None = None,
        end_date: str | None = None,
        include_types: list[str] | None = None,
        exclude_types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Get owned billing-account transaction history plus pagination metadata."""
        from ..api.billing import BillingAPI as _BillingAPI

        result = _BillingAPI(self._api).get_billing_account_transactions(
            billing_account_id,
            page=page,
            limit=limit,
            start_date=start_date,
            end_date=end_date,
            include_types=include_types,
            exclude_types=exclude_types,
        )
        return {
            "transactions": [
                txn.model_dump(by_alias=True, exclude_none=True) for txn in result["transactions"]
            ],
            "total": result["total"],
            "page": result["page"],
            "limit": result["limit"],
        }


class AnalyticsAPIWrapper:
    """Analytics API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def list_installations(self) -> list["AnalyticsInstallationResource"]:
        """List analytics installations.

        Returns:
            List of installation resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        results = _AnalyticsAPI(self._api).list_installations()
        return [AnalyticsInstallationResource(self._api, r) for r in results]

    def create_installation(
        self,
        name: str,
        allowed_domains: list[str] | None = None,
        settings: dict[str, Any] | None = None,
    ) -> "AnalyticsInstallationResource":
        """Create an analytics installation.

        Args:
            name: Installation name
            allowed_domains: Optional allowed domains
            settings: Optional settings

        Returns:
            Installation resource
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._api).create_installation(
            name, allowed_domains, settings
        )
        return AnalyticsInstallationResource(self._api, result)

    def get_installation(self, installation_id: str) -> "AnalyticsInstallationResource":
        """Get one analytics installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._api).get_installation(installation_id)
        return AnalyticsInstallationResource(self._api, result)

    def update_installation(
        self,
        installation_id: str,
        *,
        name: str | None = None,
        allowed_domains: list[str] | None = None,
        settings: dict[str, Any] | None = None,
    ) -> "AnalyticsInstallationResource":
        """Update an analytics installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._api).update_installation(
            installation_id,
            name=name,
            allowed_domains=allowed_domains,
            settings=settings,
        )
        return AnalyticsInstallationResource(self._api, result)

    def hide_installation(self, installation_id: str) -> dict[str, Any]:
        """Hide an analytics installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).hide_installation(installation_id)

    def unhide_installation(self, installation_id: str) -> dict[str, Any]:
        """Unhide an analytics installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).unhide_installation(installation_id)

    def get_installation_script(self, installation_id: str) -> dict[str, Any]:
        """Get an installation script tag."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_installation_script(installation_id)

    def get_stats(self, installation_id: str | None = None) -> dict[str, Any]:
        """Get analytics statistics.

        Returns:
            Statistics data
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_stats(installation_id)

    def get_realtime_stats(self) -> dict[str, Any]:
        """Get real-time statistics.

        Returns:
            Real-time stats
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_realtime_stats()

    def get_time_series(
        self,
        metric: str = "sessions",
        interval: str = "day",
        days: int = 7,
    ) -> list[dict[str, Any]]:
        """Get time-series analytics data."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_time_series(
            metric=metric,
            interval=interval,
            days=days,
        )

    def list_funnels(self, installation_id: str) -> list["AnalyticsFunnelResource"]:
        """List funnels for an installation.

        Args:
            installation_id: Installation ID

        Returns:
            List of funnel resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        results = _AnalyticsAPI(self._api).list_funnels(installation_id=installation_id)
        return [AnalyticsFunnelResource(self._api, r) for r in results]

    def create_funnel(
        self,
        name: str,
        steps: list[dict[str, Any]],
    ) -> "AnalyticsFunnelResource":
        """Create a funnel.

        Args:
            name: Funnel name
            steps: List of steps with name and eventName

        Returns:
            Funnel resource
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._api).create_funnel(name, steps)
        return AnalyticsFunnelResource(self._api, result)

    def list_users(self, installation_id: str, limit: int = 100) -> list["AnalyticsUserResource"]:
        """List user profiles for an installation.

        Args:
            installation_id: Installation ID
            limit: Maximum number of results

        Returns:
            List of user resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        results = _AnalyticsAPI(self._api).list_users(installation_id=installation_id, limit=limit)
        return [AnalyticsUserResource(self._api, r) for r in results]

    def get_events(
        self,
        installation_id: str,
        event_name: str | None = None,
        fingerprint: str | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        limit: int = 100,
    ) -> list["AnalyticsEventResource"]:
        """Get events for an installation.

        Args:
            installation_id: Installation ID
            event_name: Optional event name filter
            fingerprint: Optional user fingerprint filter
            limit: Maximum number of results

        Returns:
            List of event resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        results = _AnalyticsAPI(self._api).query_events(
            installation_id=installation_id,
            event_name=event_name,
            fingerprint=fingerprint,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
        )
        return [AnalyticsEventResource(self._api, r) for r in results]

    def get_user_profile(self, fingerprint: str) -> "AnalyticsUserResource | None":
        """Get one analytics user profile."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._api).get_user_profile(fingerprint)
        if result is None:
            return None
        return AnalyticsUserResource(self._api, result)

    def get_trajectory(
        self,
        fingerprint: str,
        installation_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get user trajectory for an installation.

        Args:
            fingerprint: User fingerprint
            installation_id: Installation ID
            limit: Maximum number of sessions

        Returns:
            User trajectory data
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_trajectory(
            fingerprint=fingerprint,
            installation_id=installation_id,
            limit=limit,
        )


class AnalyticsEventResource:
    """Analytics event resource."""

    def __init__(self, client: _Client, event: Any):
        self._client = client
        self._event = event

    @property
    def id(self) -> str:
        return self._event.id

    @property
    def event_name(self) -> str:
        return self._event.event_name

    @property
    def fingerprint(self) -> str:
        return self._event.fingerprint

    @property
    def session_id(self) -> str | None:
        return self._event.session_id

    @property
    def properties(self) -> dict[str, Any]:
        return self._event.properties

    @property
    def timestamp(self) -> Any:
        return self._event.timestamp

    @property
    def url(self) -> str | None:
        return self._event.url


class AnalyticsInstallationResource:
    """Analytics installation resource."""

    def __init__(self, client: _Client, installation: Any):
        self._client = client
        self._installation = installation

    @property
    def id(self) -> str:
        return self._installation.id

    @property
    def name(self) -> str:
        return self._installation.name

    @property
    def api_key(self) -> str:
        return self._installation.api_key

    @property
    def is_active(self) -> bool:
        return self._installation.is_active

    @property
    def allowed_domains(self) -> list[str]:
        return self._installation.allowed_domains

    @property
    def settings(self) -> dict[str, Any]:
        return self._installation.settings

    @property
    def created_at(self) -> Any:
        return self._installation.created_at

    def get_script(self) -> dict[str, Any]:
        """Get installation script."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._client).get_installation_script(self._installation.id)

    def update(
        self,
        *,
        name: str | None = None,
        allowed_domains: list[str] | None = None,
        settings: dict[str, Any] | None = None,
    ) -> "AnalyticsInstallationResource":
        """Update the installation and return the refreshed resource."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._client).update_installation(
            self._installation.id,
            name=name,
            allowed_domains=allowed_domains,
            settings=settings,
        )
        self._installation = result
        return self

    def hide(self) -> dict[str, Any]:
        """Hide the installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._client).hide_installation(self._installation.id)

    def unhide(self) -> dict[str, Any]:
        """Unhide the installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._client).unhide_installation(self._installation.id)

    def delete(self) -> None:
        """Delete the installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        _AnalyticsAPI(self._client).delete_installation(self._installation.id)


class AnalyticsFunnelResource:
    """Analytics funnel resource."""

    def __init__(self, client: _Client, funnel: Any):
        self._client = client
        self._funnel = funnel

    @property
    def id(self) -> str:
        return self._funnel.id

    @property
    def name(self) -> str:
        return self._funnel.name

    @property
    def steps(self) -> list[Any]:
        return self._funnel.steps

    @property
    def is_active(self) -> bool:
        return self._funnel.is_active

    @property
    def created_at(self) -> Any:
        return self._funnel.created_at

    def analyze(self, installation_id: str, days: int | None = None) -> dict[str, Any]:
        """Analyze funnel conversion.

        Args:
            installation_id: Installation ID (required)
            days: Optional number of days to analyze

        Returns:
            Analysis results
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._client).analyze_funnel(
            self._funnel.id, installation_id=installation_id, days=days
        )

    def delete(self) -> None:
        """Delete the funnel."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        _AnalyticsAPI(self._client).delete_funnel(self._funnel.id)


class AnalyticsUserResource:
    """Analytics user resource."""

    def __init__(self, client: _Client, user: Any):
        self._client = client
        self._user = user

    @property
    def id(self) -> str:
        return self._user.id

    @property
    def fingerprint(self) -> str:
        return self._user.fingerprint

    @property
    def user_id(self) -> str | None:
        return self._user.user_id

    @property
    def email(self) -> str | None:
        return self._user.email

    @property
    def name(self) -> str | None:
        return self._user.name

    @property
    def traits(self) -> dict[str, Any]:
        return self._user.traits

    @property
    def session_count(self) -> int:
        return self._user.session_count

    @property
    def first_seen_at(self) -> Any:
        return self._user.first_seen_at

    @property
    def last_seen_at(self) -> Any:
        return self._user.last_seen_at


class SandboxResource:
    """A sandbox resource with helper methods."""

    def __init__(self, client: _Client, sandbox: Sandbox):
        self._client = client
        self._sandbox = sandbox

    @property
    def id(self) -> str:
        return self._sandbox.id

    @property
    def status(self) -> str:
        return self._sandbox.status

    @property
    def config(self):
        return self._sandbox.config

    @property
    def metadata(self):
        return self._sandbox.metadata

    def start(self) -> "SandboxResource":
        """Start the sandbox."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._client).start(self._sandbox.id)
        return SandboxResource(self._client, result)

    def stop(self) -> "SandboxResource":
        """Stop the sandbox."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._client).stop(self._sandbox.id)
        return SandboxResource(self._client, result)

    def delete(self) -> None:
        """Delete the sandbox."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        _SandboxAPI(self._client).delete(self._sandbox.id)

    def logs(
        self,
        follow: bool = False,
        tail: int | None = None,
    ) -> str:
        """Get sandbox logs.

        Args:
            follow: Whether to follow logs
            tail: Number of lines to tail

        Returns:
            Log output
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _SandboxAPI(self._client).logs(self._sandbox.id, follow, tail)

    def expose_port(
        self,
        port: int,
        port_type: str = "tcp",
    ):
        """Expose a port.

        Args:
            port: Container port
            port_type: Port type (tcp, http, ws)

        Returns:
            Port mapping
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _SandboxAPI(self._client).expose_port(self._sandbox.id, port, port_type)

    def list_ports(self) -> list[Any]:
        """List all exposed ports for this sandbox.

        Returns:
            List of PortMapping objects containing container_port, host_port,
            protocol, host_ip, and public_url for each exposed port.
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _SandboxAPI(self._client).list_ports(self._sandbox.id)

    def ensure_port(
        self,
        port: int,
        port_type: str = "tcp",
    ) -> PortMapping:
        """Return an existing port mapping or expose the port if needed."""
        normalized_type = str(port_type).lower()
        for mapping in self.list_ports():
            if mapping.container_port != port:
                continue
            if not mapping.protocol or str(mapping.protocol).lower() == normalized_type:
                return mapping
        return self.expose_port(port, port_type)

    def exec(self, command: str) -> SandboxExecResult:
        """Execute a command inside this sandbox."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _SandboxAPI(self._client).exec(self._sandbox.id, command)

    def _port_endpoint(
        self,
        port: int,
        port_type: str = "tcp",
        scheme: str = "http",
    ) -> tuple[PortMapping, str]:
        mapping = self.ensure_port(port, port_type)
        if mapping.public_url:
            return mapping, mapping.public_url
        if mapping.host_ip and mapping.host_port:
            return mapping, f"{scheme}://{mapping.host_ip}:{mapping.host_port}"
        raise RuntimeError(
            f"Sandbox port {port}/{port_type} has no reachable endpoint information"
        )

    def http_request(
        self,
        port: int,
        *,
        path: str = "/",
        port_type: str = "http",
        method: str = "GET",
        timeout: float = 5.0,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        data: Any | None = None,
    ) -> httpx.Response:
        """Make an HTTP request against an exposed sandbox port."""
        _, base_url = self._port_endpoint(port, port_type=port_type, scheme="http")
        url = urljoin(base_url.rstrip("/") + "/", path.lstrip("/"))
        return httpx.request(
            method.upper(),
            url,
            headers=headers,
            params=params,
            json=json,
            data=data,
            timeout=timeout,
            follow_redirects=False,
        )

    def http_ready(
        self,
        port: int,
        *,
        path: str = "/",
        port_type: str = "http",
        expected_status: int = 200,
        timeout: float = 5.0,
        method: str = "GET",
    ) -> bool:
        """Return True when an HTTP endpoint on the sandbox responds as expected."""
        try:
            response = self.http_request(
                port,
                path=path,
                port_type=port_type,
                timeout=timeout,
                method=method,
            )
        except Exception:
            return False
        return response.status_code == expected_status

    def tcp_ready(
        self,
        port: int,
        *,
        port_type: str = "tcp",
        timeout: float = 5.0,
    ) -> bool:
        """Return True when a raw TCP connection to the exposed port succeeds."""
        try:
            mapping = self.ensure_port(port, port_type)
            host = mapping.host_ip
            target_port = mapping.host_port
            if (not host or not target_port) and mapping.public_url:
                parsed = urlparse(mapping.public_url)
                host = parsed.hostname or host
                if parsed.port:
                    target_port = parsed.port
            if not host or not target_port:
                return False
            with socket.create_connection((host, int(target_port)), timeout=timeout):
                return True
        except Exception:
            return False

    def wait_for_status(
        self,
        desired_status: str = "running",
        timeout: float = 120.0,
    ) -> "SandboxResource":
        """Wait for sandbox to reach desired status.

        Args:
            desired_status: Desired status
            timeout: Maximum wait time in seconds

        Returns:
            Sandbox resource
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._client).wait_for_status(
            self._sandbox.id, desired_status, timeout
        )
        return SandboxResource(self._client, result)

    def create_snapshot(
        self,
        name: str | None = None,
        description: str | None = None,
        with_memory: bool = False,
    ) -> Snapshot:
        """Create a snapshot.

        Args:
            name: Snapshot name
            description: Snapshot description
            with_memory: Include memory
        Returns:
            Snapshot
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._client).create(
            self._sandbox.id,
            name=name,
            description=description,
            with_memory=with_memory,
        )

    def refresh(self) -> None:
        """Refresh sandbox data from API."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        self._sandbox = _SandboxAPI(self._client).get(self._sandbox.id)

    def __repr__(self) -> str:
        return f"Sandbox(id={self._sandbox.id}, status={self._sandbox.status})"


# Convenience function to create client with default settings
def connect(
    api_key: str | None = None,
    api_url: str | None = None,
) -> Client:
    """Create an AgentEnv client with default settings.

    Args:
        api_key: API key (reads from settings if not provided)
        api_url: API URL (reads from settings if not provided)

    Returns:
        Client instance
    """
    return Client(api_key=api_key, api_url=api_url)


# Export main classes
__all__ = [
    "Client",
    "connect",
    "SandboxResource",
    "function",
    "RemoteFunctionError",
    "AIClient",
    "ChatCompletions",
    "Embeddings",
    "ManagementAPI",
    "GitCommandError",
    "GitStatusEntry",
    "BotConversation",
    "BotConversationListResponse",
    "BotEvent",
    "BotEventListResponse",
    "BotIntegration",
    "BotIntegrationsAPI",
    "ManagedAgentTelegramAPI",
    "SyncTelegramWebhookResult",
    "ManagedAgentMcpDefinition",
    "ManagedAgentMcpSecretRefs",
    "ManagedAgentSkillAsset",
    "CreateManagedAgentMcpDefinitionRequest",
]
