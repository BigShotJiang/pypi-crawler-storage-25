"""Progress indicators and spinners for AgentEnv CLI.

All progress-like UX writes to stderr so stdout can remain machine-readable.
This is especially important for `--json` mode, where commands must emit one
JSON document on stdout without spinner/status contamination.
"""

import sys
import threading
import time
from contextlib import contextmanager
from typing import Any, Callable, Iterator

from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
    TimeRemainingColumn,
    DownloadColumn,
    TransferSpeedColumn,
)
from rich.status import Status

# Keep progress and spinner output off stdout so JSON responses stay clean.
console = Console(stderr=True)


class Spinner:
    """A simple spinner for long-running operations."""

    def __init__(self, message: str = "Loading..."):
        """Initialize spinner.

        Args:
            message: Message to display
        """
        self.message = message
        self._stopped = False
        self._thread: threading.Thread | None = None

    def _spin(self) -> None:
        """Run the spinner animation."""
        chars = "⠁⠂⠄⡀⢀⠠⠐⠈"
        idx = 0
        while not self._stopped:
            console.print(f"\r[{chars[idx]}] {self.message}", end="")
            idx = (idx + 1) % len(chars)
            time.sleep(0.1)
            # Clear the line
            console.print("\r" + " " * (len(self.message) + 10) + "\r", end="")

    def start(self) -> None:
        """Start the spinner."""
        self._stopped = False
        self._thread = threading.Thread(target=self._spin, daemon=True)
        if self._thread:
            self._thread.start()

    def stop(self) -> None:
        """Stop the spinner."""
        self._stopped = True
        if self._thread:
            self._thread.join(timeout=0.2)
            self._thread = None
        # Clear the line
        console.print("\r" + " " * 100 + "\r", end="")

    def update(self, message: str) -> None:
        """Update spinner message.

        Args:
            message: New message
        """
        self.message = message


@contextmanager
def spinner(message: str) -> Iterator[Spinner]:
    """Context manager for a spinner.

    Args:
        message: Message to display

    Yields:
        Spinner instance
    """
    sp = Spinner(message)
    sp.start()
    try:
        yield sp
    finally:
        sp.stop()


def progress_task(
    message: str,
    total: int | None = None,
) -> Iterator[Progress]:
    """Context manager for a progress bar.

    Args:
        message: Task message
        total: Total items (None for indeterminate)

    Yields:
        Progress and task ID
    """
    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeRemainingColumn(),
        console=console,
    )

    with progress:
        task = progress.add_task(message, total=total)
        yield progress


def download_progress(
    message: str = "Downloading",
) -> Iterator[Progress]:
    """Context manager for a download progress bar.

    Args:
        message: Task message

    Yields:
        Progress instance
    """
    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=console,
    )

    with progress:
        task = progress.add_task(message, start=False)
        yield progress


class Status:
    """Rich status indicator (alias for compatibility)."""

    def __init__(self, message: str, spinner: str = "dots"):
        """Initialize status.

        Args:
            message: Status message
            spinner: Spinner type
        """
        self._status = console.status(message, spinner=spinner)

    def start(self) -> None:
        """Start status."""
        self._status.start()

    def stop(self) -> None:
        """Stop status."""
        self._status.stop()

    def update(self, message: str) -> None:
        """Update status message.

        Args:
            message: New message
        """
        self._status.update(message)

    @staticmethod
    @contextmanager
    def context(message: str, spinner: str = "dots") -> Iterator[Status]:
        """Context manager for status.

        Args:
            message: Status message
            spinner: Spinner type

        Yields:
            Status instance
        """
        status = Status(message, spinner)
        status.start()
        try:
            yield status
        finally:
            status.stop()


@contextmanager
def status(message: str, spinner: str = "dots") -> Iterator[Status]:
    """Context manager for a status indicator.

    Args:
        message: Status message
        spinner: Spinner type

    Yields:
        Status instance
    """
    s = Status(message, spinner)
    s.start()
    try:
        yield s
    finally:
        s.stop()


# =============================================================================
# Specialized Progress Helpers
# =============================================================================

def wait_with_message(
    message: str,
    func: Callable[[], Any],
    done_message: str | None = None,
) -> Any:
    """Run a function with a waiting spinner.

    Args:
        message: Message while waiting
        func: Function to run
        done_message: Optional message when done

    Returns:
        Result of func
    """
    with status(message):
        result = func()

    if done_message:
        from .tables import print_success
        print_success(done_message)

    return result


def wait_for_condition(
    message: str,
    condition: Callable[[], bool],
    timeout: float = 60.0,
    interval: float = 0.5,
) -> bool:
    """Wait for a condition to be true with progress.

    Args:
        message: Message while waiting
        condition: Condition function
        timeout: Maximum wait time
        interval: Check interval

    Returns:
        True if condition met, False on timeout
    """
    import time

    start = time.time()

    with status(message):
        while time.time() - start < timeout:
            if condition():
                return True
            time.sleep(interval)

    return False
