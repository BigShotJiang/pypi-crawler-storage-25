"""Authentication API client."""

from typing import Any

from .client import Client
from .models import APIKey, APIKeyContext, UserProfile


class AuthAPI:
    """API client for authentication."""

    def __init__(self, client: Client):
        """Initialize auth API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def login(self, username: str, password: str) -> dict[str, Any]:
        """Login with username and password.

        Args:
            username: Username or email
            password: Password

        Returns:
            Login response with tokens or a TOTP challenge payload
        """
        response = self.client.post(
            "/v1/auth/login",
            json={"username": username, "password": password},
        )
        return response.json()

    def signup(
        self,
        email: str,
        password: str,
        username: str | None = None,
        *,
        turnstile_token: str | None = None,
        fingerprint: str | None = None,
        fingerprint_request_id: str | None = None,
        name: str | None = None,
    ) -> dict[str, Any]:
        """Sign up a new user.

        Args:
            email: Email address
            password: Password
            username: Username
            turnstile_token: Cloudflare Turnstile response token
            fingerprint: Optional Fingerprint visitor ID
            fingerprint_request_id: Optional Fingerprint request ID
            name: Deprecated alias for username

        Returns:
            Signup response
        """
        data: dict[str, Any] = {"email": email, "password": password}
        username_value = username or name
        if username_value:
            data["username"] = username_value
        if turnstile_token:
            data["turnstileToken"] = turnstile_token
        if fingerprint:
            data["fingerprint"] = fingerprint
        if fingerprint_request_id:
            data["fingerprintRequestId"] = fingerprint_request_id

        response = self.client.post("/v1/auth/signup", json=data)
        return response.json()

    def verify_email(self, token: str) -> dict[str, Any]:
        """Verify an email address."""
        response = self.client.post("/v1/auth/verify-email", json={"token": token})
        return response.json()

    def resend_verification(self, email: str) -> dict[str, Any]:
        """Resend the verification email."""
        response = self.client.post("/v1/auth/resend-verification", json={"email": email})
        return response.json()

    def forgot_password(self, email: str) -> dict[str, Any]:
        """Request a password reset email."""
        response = self.client.post("/v1/auth/forgot-password", json={"email": email})
        return response.json()

    def reset_password(self, token: str, new_password: str) -> dict[str, Any]:
        """Reset a password using a reset token."""
        response = self.client.post(
            "/v1/auth/reset-password",
            json={"token": token, "newPassword": new_password},
        )
        return response.json()

    def verify_totp(self, code: str, temp_token: str) -> dict[str, Any]:
        """Complete a TOTP login challenge."""
        response = self.client.post(
            "/v1/auth/totp/verify",
            json={"token": code, "tempToken": temp_token},
        )
        return response.json()

    def get_profile(self) -> UserProfile:
        """Get current user profile.

        Returns:
            User profile
        """
        response = self.client.get("/v1/auth/profile")
        return UserProfile(**response.json())

    def refresh_token(self, refresh_token: str) -> dict[str, Any]:
        """Refresh access token.

        Args:
            refresh_token: Refresh token

        Returns:
            New tokens
        """
        response = self.client.post(
            "/v1/auth/refresh",
            json={"refreshToken": refresh_token},
        )
        return response.json()

    def logout(self) -> None:
        """Logout current user."""
        self.client.post("/v1/auth/logout")

    # API Key management

    def create_api_key(
        self,
        name: str,
        key_type: str | None = None,
        workspace_id: str | None = None,
    ) -> APIKey:
        """Create a new API key.

        Args:
            name: API key name
            key_type: Optional API key type, either user or workspace.
                When omitted, the API infers the type from the caller.
            workspace_id: Workspace ID for workspace API keys

        Returns:
            Created API key (includes the key value)
        """
        if workspace_id and key_type is None:
            key_type = "workspace"

        payload = {"name": name}
        if key_type:
            payload["type"] = key_type
        if workspace_id:
            payload["workspaceId"] = workspace_id
        response = self.client.post("/v1/auth/api-keys", json=payload)
        return APIKey(**response.json())

    def list_api_keys(
        self,
        key_type: str | None = None,
        workspace_id: str | None = None,
    ) -> list[APIKey]:
        """List API keys for current user.

        Args:
            key_type: Optional API key type filter, either user or workspace
            workspace_id: Workspace ID when listing workspace API keys

        Returns:
            List of API keys
        """
        params: dict[str, str] = {}
        if key_type:
            params["type"] = key_type
        if workspace_id:
            params["workspaceId"] = workspace_id
        response = self.client.get("/v1/auth/api-keys", params=params or None)
        return [APIKey(**item) for item in response.json()]

    def delete_api_key(self, key_id: str) -> None:
        """Delete an API key.

        Args:
            key_id: API key ID
        """
        self.client.delete(f"/v1/auth/api-keys/{key_id}")

    def update_api_key(self, key_id: str, name: str) -> APIKey:
        """Update API key name.

        Args:
            key_id: API key ID
            name: New name

        Returns:
            Updated API key
        """
        response = self.client.patch(
            f"/v1/auth/api-keys/{key_id}",
            json={"name": name},
        )
        return APIKey(**response.json())

    def get_api_key_context(self) -> APIKeyContext:
        """Get the scope of the current API key or token."""
        response = self.client.get("/v1/auth/api-key-context")
        return APIKeyContext(**response.json())

    # Workspace management (for current user)

    def get_workspaces(self) -> dict[str, Any]:
        """Get workspaces for current user and the active selection.

        Returns:
            Payload containing ``workspaces`` and ``selectedWorkspaceId``
        """
        response = self.client.get("/v1/auth/workspaces")
        return response.json()

    def set_workspace(self, workspace_id: str) -> dict[str, Any]:
        """Set active workspace.

        Args:
            workspace_id: Workspace ID

        Returns:
            Updated user data
        """
        response = self.client.patch(
            "/v1/auth/workspace",
            json={"workspaceId": workspace_id},
        )
        return response.json()
