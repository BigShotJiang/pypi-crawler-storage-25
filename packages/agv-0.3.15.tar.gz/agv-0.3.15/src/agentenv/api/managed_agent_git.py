"""Client-side git integration for managed-agent sandboxes.

This module does NOT add any new HTTP endpoints to the api-server. It uses
the existing ``POST /v1/sandboxes/:id/exec`` to run ``git`` commands inside
the agent's backing sandbox, exposing an e2b-style interface familiar to
anyone who's used `sandbox.commands.run("git …")` before.

All public methods that accept string arguments (URLs, branch names, paths,
commit messages, identity values) are shell-quoted before they reach the
sandbox. Callers can pass arbitrary user input without worrying about
command injection.
"""

from __future__ import annotations

import shlex
from dataclasses import dataclass
from typing import Any, Iterable

from .client import APIError, Client
from .managed_agent import ManagedAgentAPI
from .models import ManagedAgent, SandboxExecResult
from .sandbox import SandboxAPI

DEFAULT_WORKDIR = "/workspace"


class GitCommandError(RuntimeError):
    """Raised when a git command returns a non-zero exit code.

    Exposes the structured exec result so callers can inspect ``exit_code``,
    ``output`` (combined stdout+stderr), and the exact ``command`` that ran.
    """

    def __init__(self, command: str, result: SandboxExecResult) -> None:
        tail = (result.output or "").strip().splitlines()
        snippet = "\n".join(tail[-5:]) if tail else ""
        super().__init__(
            f"git command failed (exit {result.exit_code}): {command}"
            + (f"\n---\n{snippet}" if snippet else "")
        )
        self.command = command
        self.result = result

    @property
    def exit_code(self) -> int:
        return self.result.exit_code

    @property
    def output(self) -> str:
        return self.result.output


@dataclass(frozen=True)
class GitStatusEntry:
    """One row from ``git status --porcelain=v1``.

    ``status`` preserves the raw two-character porcelain code (``??``,
    ``M `` = modified and staged, `` M`` = modified and unstaged, etc.) so
    callers don't lose information to categorization.
    """

    status: str
    path: str


class ManagedAgentGit:
    """e2b-style git helper scoped to a single managed agent.

    Every method is a thin wrapper over ``sandbox.exec`` — the agent's
    backing sandbox runs git commands in ``cwd`` (default ``/workspace``).
    Acquire one via ``client.managed_agents.git(agent_id)`` on the high-
    level SDK, or construct it directly for tests.
    """

    def __init__(
        self,
        agent_id: str,
        *,
        sandbox_api: SandboxAPI,
        managed_agent_api: ManagedAgentAPI,
        cwd: str = DEFAULT_WORKDIR,
    ) -> None:
        self.agent_id = agent_id
        self._sandbox_api = sandbox_api
        self._managed_agent_api = managed_agent_api
        self.cwd = cwd
        self._cached_sandbox_id: str | None = None

    # ------------------------------------------------------------ sandbox plumbing
    def _resolve_sandbox_id(self) -> str:
        if self._cached_sandbox_id:
            return self._cached_sandbox_id
        agent: ManagedAgent = self._managed_agent_api.get(self.agent_id)
        if not agent.sandbox_id:
            raise RuntimeError(
                f"Managed agent {self.agent_id} has no backing sandbox yet; "
                "wait for status=running before invoking git."
            )
        self._cached_sandbox_id = agent.sandbox_id
        return agent.sandbox_id

    def exec(
        self,
        command: str,
        *,
        cwd: str | None = None,
        check: bool = True,
    ) -> SandboxExecResult:
        """Run an arbitrary shell command in the agent's sandbox.

        Exposed for callers who need an escape hatch beyond the typed git
        helpers (e.g. ``agent.git.exec("git worktree add …")``). By default
        non-zero exits raise :class:`GitCommandError`; pass ``check=False``
        to get the raw result back.
        """
        working_dir = cwd or self.cwd
        wrapped = f"cd {shlex.quote(working_dir)} && {command}"
        sandbox_id = self._resolve_sandbox_id()
        try:
            result = self._sandbox_api.exec(sandbox_id, wrapped)
        except APIError as exc:
            # Bubble up auth/4xx/5xx with the original command for debugging.
            raise APIError(
                status_code=exc.status_code,
                message=f"sandbox.exec failed for `{command}`: {exc}",
                details=getattr(exc, "details", {}),
            ) from exc
        if check and result.exit_code != 0:
            raise GitCommandError(wrapped, result)
        return result

    def _git(
        self,
        args: Iterable[str],
        *,
        cwd: str | None = None,
        check: bool = True,
    ) -> SandboxExecResult:
        quoted = " ".join(shlex.quote(a) for a in args)
        return self.exec(f"git {quoted}", cwd=cwd, check=check)

    # ------------------------------------------------------------------- identity
    def configure_identity(
        self,
        *,
        name: str,
        email: str,
        scope: str = "global",
    ) -> None:
        """Set ``user.name`` + ``user.email`` — matches e2b's surface.

        ``scope`` is ``global`` by default so the identity persists across
        any repository in the sandbox. Pass ``scope="local"`` inside a
        repository to scope to that working tree only.
        """
        if scope not in {"global", "local", "system"}:
            raise ValueError(
                f"scope must be one of global/local/system, got {scope!r}"
            )
        scope_flag = f"--{scope}"
        self._git(["config", scope_flag, "user.name", name])
        self._git(["config", scope_flag, "user.email", email])

    def get_identity(self, *, scope: str = "global") -> tuple[str | None, str | None]:
        """Return ``(user.name, user.email)`` for the given scope, or None."""
        if scope not in {"global", "local", "system"}:
            raise ValueError(
                f"scope must be one of global/local/system, got {scope!r}"
            )
        scope_flag = f"--{scope}"
        name_res = self._git(
            ["config", scope_flag, "--default", "", "user.name"],
            check=False,
        )
        email_res = self._git(
            ["config", scope_flag, "--default", "", "user.email"],
            check=False,
        )
        name = name_res.output.strip() or None if name_res.exit_code == 0 else None
        email = email_res.output.strip() or None if email_res.exit_code == 0 else None
        return name, email

    # -------------------------------------------------------------- remote actions
    def clone(
        self,
        url: str,
        *,
        path: str | None = None,
        branch: str | None = None,
        depth: int | None = None,
    ) -> SandboxExecResult:
        """Clone ``url`` into ``path`` (or the default name git picks)."""
        args: list[str] = ["clone"]
        if depth is not None and depth > 0:
            args += ["--depth", str(depth)]
        if branch is not None:
            args += ["--branch", branch]
        args.append(url)
        if path is not None:
            args.append(path)
        return self._git(args)

    def pull(
        self,
        *,
        remote: str = "origin",
        branch: str | None = None,
        cwd: str | None = None,
        rebase: bool = False,
    ) -> SandboxExecResult:
        """``git pull [--rebase] <remote> [branch]`` in ``cwd``."""
        args: list[str] = ["pull"]
        if rebase:
            args.append("--rebase")
        args.append(remote)
        if branch is not None:
            args.append(branch)
        return self._git(args, cwd=cwd)

    def fetch(
        self,
        *,
        remote: str = "origin",
        branch: str | None = None,
        cwd: str | None = None,
        prune: bool = False,
    ) -> SandboxExecResult:
        args: list[str] = ["fetch"]
        if prune:
            args.append("--prune")
        args.append(remote)
        if branch is not None:
            args.append(branch)
        return self._git(args, cwd=cwd)

    def push(
        self,
        *,
        remote: str = "origin",
        branch: str | None = None,
        cwd: str | None = None,
        set_upstream: bool = False,
        force: bool = False,
    ) -> SandboxExecResult:
        """``git push`` — refuses ``--force`` by default, opt-in only."""
        args: list[str] = ["push"]
        if set_upstream:
            args.append("--set-upstream")
        if force:
            args.append("--force-with-lease")
        args.append(remote)
        if branch is not None:
            args.append(branch)
        return self._git(args, cwd=cwd)

    # ---------------------------------------------------------------- local actions
    def init(
        self,
        *,
        path: str | None = None,
        initial_branch: str | None = None,
        bare: bool = False,
    ) -> SandboxExecResult:
        args: list[str] = ["init"]
        if initial_branch is not None:
            args += ["--initial-branch", initial_branch]
        if bare:
            args.append("--bare")
        if path is not None:
            args.append(path)
        return self._git(args)

    def add(
        self,
        paths: str | Iterable[str] = ".",
        *,
        cwd: str | None = None,
    ) -> SandboxExecResult:
        if isinstance(paths, str):
            args = ["add", paths]
        else:
            args = ["add", *paths]
        return self._git(args, cwd=cwd)

    def commit(
        self,
        message: str,
        *,
        cwd: str | None = None,
        author: str | None = None,
        allow_empty: bool = False,
    ) -> SandboxExecResult:
        """``git commit -m <message>``.

        Pass ``author="Name <email>"`` for a one-off override that doesn't
        touch ``user.name`` / ``user.email``.
        """
        args: list[str] = ["commit", "-m", message]
        if author is not None:
            args += ["--author", author]
        if allow_empty:
            args.append("--allow-empty")
        return self._git(args, cwd=cwd)

    def checkout(
        self,
        ref: str,
        *,
        cwd: str | None = None,
        create: bool = False,
    ) -> SandboxExecResult:
        """``git checkout <ref>``; ``create=True`` switches to ``-b``."""
        args: list[str] = ["checkout"]
        if create:
            args.append("-b")
        args.append(ref)
        return self._git(args, cwd=cwd)

    def branch(
        self,
        *,
        cwd: str | None = None,
        list_remote: bool = False,
    ) -> list[str]:
        """Return the local branch names (or include remote-tracking when set)."""
        args: list[str] = ["branch"]
        if list_remote:
            args.append("-a")
        args += ["--format", "%(refname:short)"]
        result = self._git(args, cwd=cwd)
        return [line.strip() for line in result.output.splitlines() if line.strip()]

    def current_branch(self, *, cwd: str | None = None) -> str | None:
        """Name of the currently-checked-out branch, or None for detached HEAD."""
        result = self._git(
            ["symbolic-ref", "--short", "HEAD"],
            cwd=cwd,
            check=False,
        )
        if result.exit_code != 0:
            return None
        return result.output.strip() or None

    def current_head(self, *, cwd: str | None = None) -> str:
        """Full SHA of HEAD."""
        return self._git(["rev-parse", "HEAD"], cwd=cwd).output.strip()

    def status(
        self,
        *,
        cwd: str | None = None,
    ) -> list[GitStatusEntry]:
        """Return one :class:`GitStatusEntry` per ``git status --porcelain=v1`` row."""
        result = self._git(
            ["-c", "core.quotepath=false", "status", "--porcelain=v1"],
            cwd=cwd,
        )
        entries: list[GitStatusEntry] = []
        for line in result.output.splitlines():
            if len(line) < 3:
                continue
            entries.append(GitStatusEntry(status=line[:2], path=line[3:]))
        return entries

    def log(
        self,
        *,
        cwd: str | None = None,
        max_count: int | None = None,
    ) -> list[dict[str, Any]]:
        """``git log`` summarized as ``[{"sha", "author", "subject"}, ...]``.

        Uses ``%x1f`` as a field separator so arbitrary commit subjects
        don't corrupt the parse.
        """
        args: list[str] = ["log", "--format=%H%x1f%an <%ae>%x1f%s"]
        if max_count is not None and max_count > 0:
            args += ["-n", str(max_count)]
        result = self._git(args, cwd=cwd)
        entries: list[dict[str, Any]] = []
        for line in result.output.splitlines():
            parts = line.split("\x1f", 2)
            if len(parts) != 3:
                continue
            entries.append({"sha": parts[0], "author": parts[1], "subject": parts[2]})
        return entries

    def diff(
        self,
        *,
        cwd: str | None = None,
        staged: bool = False,
        name_only: bool = False,
        ref: str | None = None,
    ) -> str:
        """Return raw ``git diff`` output (empty string when there's no diff)."""
        args: list[str] = ["diff"]
        if staged:
            args.append("--cached")
        if name_only:
            args.append("--name-only")
        if ref is not None:
            args.append(ref)
        result = self._git(args, cwd=cwd, check=False)
        if result.exit_code not in (0, 1):
            # git diff exits 1 when differences exist — that's OK.
            raise GitCommandError(f"git {' '.join(args)}", result)
        return result.output

    # ------------------------------------------------------------- credentials
    def store_credentials(
        self,
        *,
        url: str,
        username: str,
        password: str,
    ) -> None:
        """Write a ``~/.git-credentials`` entry and enable the ``store`` helper.

        This lets subsequent ``clone``/``push``/``pull`` against the same
        host reuse the credential without re-prompting. The credential is
        written into the sandbox's home directory — it is tied to that
        sandbox's lifetime.
        """
        if not url.startswith(("http://", "https://")):
            raise ValueError(
                "store_credentials only supports http(s) URLs; "
                "for SSH, write the private key with sandbox.upload_file."
            )
        from urllib.parse import quote, urlsplit, urlunsplit

        split = urlsplit(url)
        if not split.hostname:
            raise ValueError(f"url has no hostname: {url!r}")
        authority = f"{quote(username, safe='')}:{quote(password, safe='')}@{split.netloc}"
        with_auth = urlunsplit(
            (split.scheme, authority, split.path or "/", "", "")
        )
        # Append (not overwrite) so multiple hosts can coexist in the file.
        self.exec(
            "mkdir -p ~ && touch ~/.git-credentials && chmod 600 ~/.git-credentials "
            f"&& printf '%s\\n' {shlex.quote(with_auth)} >> ~/.git-credentials"
        )
        self._git(["config", "--global", "credential.helper", "store"])
