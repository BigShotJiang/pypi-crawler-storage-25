"""Managed-agent extensions API client (skills + MCP servers).

The backend routes live under ``/v1/managed-agent-extensions/...`` and are
documented in ``api-server/src/managed-agent/managed-agent-extensions.controller.ts``.
"""

from __future__ import annotations

from pathlib import Path
from typing import IO, Any

from .client import Client
from .models import (
    CreateManagedAgentMcpDefinitionRequest,
    ManagedAgentMcpDefinition,
    ManagedAgentMcpSecretRefs,
    ManagedAgentSkillAsset,
    OperationSuccess,
)


class ManagedAgentExtensionsAPI:
    """Wrap the ``/v1/managed-agent-extensions/*`` endpoints.

    Skills and MCP definitions are workspace-scoped resources. Assignments
    flip an ``enabled`` bit per agent in that same workspace; the
    runtime pushes the on/enabled set into the Codex process on each wake via
    ``skills/list`` + ``config/batchWrite``.
    """

    def __init__(self, client: Client) -> None:
        self.client = client

    # ------------------------------------------------------------------ skills
    def list_skills(self, *, workspace_id: str) -> list[ManagedAgentSkillAsset]:
        """List skill assets owned by a workspace."""
        response = self.client.get(
            "/v1/managed-agent-extensions/skills",
            params={"workspaceId": _require_workspace_id(workspace_id)},
        )
        return [ManagedAgentSkillAsset(**item) for item in response.json()]

    def upload_skill(
        self,
        file: str | Path | IO[bytes],
        *,
        workspace_id: str,
        name: str | None = None,
    ) -> ManagedAgentSkillAsset:
        """Upload a workspace-owned skill archive (``.zip``).

        ``file`` may be a filesystem path or an already-opened binary stream.
        """
        close_after = False
        if isinstance(file, (str, Path)):
            path = Path(file)
            fh: IO[bytes] = open(path, "rb")
            close_after = True
            filename = path.name
        else:
            fh = file
            filename = getattr(file, "name", "skill.zip")
            filename = Path(filename).name if filename else "skill.zip"
        try:
            files: dict[str, Any] = {
                "file": (filename, fh, "application/zip"),
            }
            data: dict[str, Any] = {
                "workspaceId": _require_workspace_id(workspace_id),
            }
            if name is not None:
                data["name"] = name
            response = self.client.post(
                "/v1/managed-agent-extensions/skills/upload",
                files=files,
                data=data,
            )
        finally:
            if close_after:
                fh.close()
        return ManagedAgentSkillAsset(**response.json())

    def delete_skill(self, skill_id: str) -> OperationSuccess:
        """Delete a skill asset (unassigns it from every agent)."""
        response = self.client.delete(
            f"/v1/managed-agent-extensions/skills/{skill_id}",
        )
        payload = response.json() if response.content else {"success": True}
        return OperationSuccess(**payload)

    def set_skill_assignment(
        self,
        agent_id: str,
        skill_id: str,
        *,
        enabled: bool,
    ) -> ManagedAgentSkillAsset:
        """Enable or disable a skill for a specific managed agent."""
        response = self.client.put(
            f"/v1/managed-agent-extensions/agents/{agent_id}/skills/{skill_id}",
            json={"enabled": enabled},
        )
        return ManagedAgentSkillAsset(**response.json())

    # --------------------------------------------------------------------- mcp
    def list_mcp_definitions(
        self, *, workspace_id: str
    ) -> list[ManagedAgentMcpDefinition]:
        """List MCP server definitions owned by a workspace."""
        response = self.client.get(
            "/v1/managed-agent-extensions/mcp",
            params={"workspaceId": _require_workspace_id(workspace_id)},
        )
        return [ManagedAgentMcpDefinition(**item) for item in response.json()]

    def create_mcp_definition(
        self,
        *,
        name: str,
        config: dict[str, Any],
        workspace_id: str,
        secret_refs: ManagedAgentMcpSecretRefs | dict[str, Any] | None = None,
    ) -> ManagedAgentMcpDefinition:
        """Create an MCP server definition.

        ``config`` matches the shape Codex expects under
        ``[mcp_servers.<id>]`` in its ``config.toml`` — e.g.
        ``{"command": "npx", "args": ["-y", "@modelcontextprotocol/server-github"]}``
        for STDIO, or ``{"url": "https://…/sse"}`` for SSE.

        ``secret_refs`` is optional indirection: provide secret IDs, not
        plaintext, and the server materializes them at runtime.
        """
        if isinstance(secret_refs, dict):
            secret_refs = ManagedAgentMcpSecretRefs(**secret_refs)
        request = CreateManagedAgentMcpDefinitionRequest(
            name=name,
            config=config,
            workspaceId=_require_workspace_id(workspace_id),
            secretRefs=secret_refs,
        )
        response = self.client.post(
            "/v1/managed-agent-extensions/mcp",
            json=request.model_dump(by_alias=True, exclude_none=True),
        )
        return ManagedAgentMcpDefinition(**response.json())

    def update_mcp_definition(
        self,
        mcp_id: str,
        *,
        name: str | None = None,
        config: dict[str, Any] | None = None,
        workspace_id: str | None = None,
        secret_refs: ManagedAgentMcpSecretRefs | dict[str, Any] | None = None,
    ) -> ManagedAgentMcpDefinition:
        """Update an existing MCP definition in place."""
        if isinstance(secret_refs, dict):
            secret_refs = ManagedAgentMcpSecretRefs(**secret_refs)
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if config is not None:
            body["config"] = config
        if workspace_id is not None:
            body["workspaceId"] = workspace_id
        if secret_refs is not None:
            body["secretRefs"] = secret_refs.model_dump(
                by_alias=True, exclude_none=True
            )
        if not body:
            raise ValueError(
                "update_mcp_definition requires at least one of "
                "name / config / workspace_id / secret_refs"
            )
        response = self.client.put(
            f"/v1/managed-agent-extensions/mcp/{mcp_id}",
            json=body,
        )
        return ManagedAgentMcpDefinition(**response.json())

    def delete_mcp_definition(self, mcp_id: str) -> OperationSuccess:
        """Delete an MCP definition (unassigns it from every agent)."""
        response = self.client.delete(
            f"/v1/managed-agent-extensions/mcp/{mcp_id}",
        )
        payload = response.json() if response.content else {"success": True}
        return OperationSuccess(**payload)

    def set_mcp_assignment(
        self,
        agent_id: str,
        mcp_id: str,
        *,
        enabled: bool,
    ) -> ManagedAgentMcpDefinition:
        """Enable or disable an MCP definition for a specific managed agent."""
        response = self.client.put(
            f"/v1/managed-agent-extensions/agents/{agent_id}/mcp/{mcp_id}",
            json={"enabled": enabled},
        )
        return ManagedAgentMcpDefinition(**response.json())


def _require_workspace_id(workspace_id: str) -> str:
    if not workspace_id:
        raise ValueError("workspace_id is required for managed-agent extensions")
    return workspace_id
