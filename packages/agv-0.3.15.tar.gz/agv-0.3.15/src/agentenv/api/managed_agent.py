"""Managed-agent API client."""

from __future__ import annotations

import json
import time
from collections.abc import Iterator
from typing import Any

from .client import APIError, Client
from .models import (
    BrowserSession,
    CreateManagedAgentRequest,
    ManagedAgent,
    ManagedAgentContentBlob,
    ManagedAgentListResponse,
    ManagedAgentMessage,
    ManagedAgentPathContent,
    ManagedAgentStreamEvent,
    OperationSuccess,
    PortMapping,
)
from .sandbox import SandboxAPI


class ManagedAgentAPI:
    """API client for managed-agent resources."""

    def __init__(self, client: Client):
        self.client = client

    def list_all(
        self,
        *,
        workspace_id: str | None = None,
        agent_workspace_group_id: str | None = None,
        search: str | None = None,
        page: int | None = None,
        limit: int | None = None,
    ) -> ManagedAgentListResponse:
        """List managed agents."""
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        if agent_workspace_group_id:
            params["agentWorkspaceGroupId"] = agent_workspace_group_id
        if search:
            params["search"] = search
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        response = self.client.get("/v1/managed-agents", params=params or None)
        payload = response.json()

        if isinstance(payload, list):
            return ManagedAgentListResponse(
                agents=[ManagedAgent(**item) for item in payload],
                total=len(payload),
                page=page or 1,
                limit=limit or len(payload) or 50,
            )

        return ManagedAgentListResponse(**payload)

    def create(
        self,
        *,
        name: str,
        workspace_id: str,
        upstream_id: str,
        model: str | None = None,
        instructions: str | None = None,
        image: str | None = None,
        workspace_template: str | None = None,
        cpu_millis: int | None = None,
        memory_mb: int | None = None,
        agent_workspace_group_id: str | None = None,
        enabled_skill_ids: list[str] | None = None,
        enabled_mcp_ids: list[str] | None = None,
    ) -> ManagedAgent:
        """Create a managed agent.

        The create response may include ``public_token`` once when the server
        is configured to return a managed-agent public token.
        """
        request = CreateManagedAgentRequest(
            name=name,
            workspaceId=workspace_id,
            upstreamId=upstream_id,
            model=model,
            instructions=instructions,
            image=image,
            workspaceTemplate=workspace_template,
            cpuMillis=cpu_millis,
            memoryMb=memory_mb,
            agentWorkspaceGroupId=agent_workspace_group_id,
            enabledSkillIds=enabled_skill_ids,
            enabledMcpIds=enabled_mcp_ids,
        )
        response = self.client.post(
            "/v1/managed-agents",
            json=request.model_dump(by_alias=True, exclude_none=True),
        )
        return ManagedAgent(**response.json())

    def get(self, agent_id: str) -> ManagedAgent:
        """Get a managed agent.

        This does not reissue ``public_token``; persist the create-time value if
        you need later access to ``/v1/public/managed-agent/*`` helper routes.
        """
        response = self.client.get(f"/v1/managed-agents/{agent_id}")
        return ManagedAgent(**response.json())

    def list_messages(self, agent_id: str) -> list[ManagedAgentMessage]:
        """List managed-agent transcript messages."""
        response = self.client.get(f"/v1/managed-agents/{agent_id}/messages")
        return [ManagedAgentMessage(**item) for item in response.json()]

    def get_file_content(self, agent_id: str, content_hash: str) -> ManagedAgentContentBlob:
        """Read file content from CAS by hash."""
        response = self.client.get(
            f"/v1/managed-agents/{agent_id}/file-content/{content_hash}",
        )
        return ManagedAgentContentBlob(**response.json())

    def read_file(self, agent_id: str, path: str) -> ManagedAgentPathContent:
        """Read current file content from the managed-agent sandbox."""
        response = self.client.get(
            f"/v1/managed-agents/{agent_id}/file",
            params={"path": path},
        )
        return ManagedAgentPathContent(**response.json())

    def git_show(
        self,
        agent_id: str,
        path: str,
        *,
        ref: str = "HEAD",
    ) -> ManagedAgentPathContent:
        """Read committed file content from the managed-agent sandbox."""
        response = self.client.get(
            f"/v1/managed-agents/{agent_id}/git-show",
            params={"path": path, "ref": ref},
        )
        return ManagedAgentPathContent(**response.json())

    def list_browser_sessions(self, agent_id: str) -> list[BrowserSession]:
        """List browser sessions associated with a managed agent."""
        response = self.client.get(f"/v1/managed-agents/{agent_id}/browser-sessions")
        return [BrowserSession(**item) for item in response.json()]

    def wake(self, agent_id: str) -> ManagedAgent:
        """Wake a sleeping managed agent."""
        response = self.client.post(f"/v1/managed-agents/{agent_id}/wake")
        return ManagedAgent(**response.json())

    def wait_for_status(
        self,
        agent_id: str,
        desired_status: str = "running",
        timeout: float = 120.0,
        interval: float = 0.5,
    ) -> ManagedAgent:
        """Wait for a managed agent to reach the desired status."""
        start = time.time()
        while time.time() - start < timeout:
            agent = self.get(agent_id)
            if agent.status == desired_status:
                return agent
            if agent.status in {"failed", "deleting"} and agent.status != desired_status:
                raise RuntimeError(
                    f"Managed agent {agent_id} failed with status: {agent.status}"
                )
            time.sleep(interval)

        raise TimeoutError(
            f"Timeout waiting for managed agent {agent_id} to reach status {desired_status}"
        )

    def delete(self, agent_id: str) -> OperationSuccess:
        """Delete a managed agent."""
        response = self.client.delete(f"/v1/managed-agents/{agent_id}")
        payload = response.json() if response.content else {"success": True}
        return OperationSuccess(**payload)

    def fork(self, agent_id: str) -> ManagedAgent:
        """Fork a managed agent."""
        response = self.client.post(f"/v1/managed-agents/{agent_id}/fork")
        return ManagedAgent(**response.json())

    def expose_port(
        self,
        agent_id: str,
        port: int,
        port_type: str = "tcp",
    ) -> PortMapping:
        """Expose a port from the managed-agent sandbox to the internet.

        Args:
            agent_id: Managed agent ID
            port: Container port to expose (1-65535)
            port_type: One of ``tcp``, ``udp``, ``http``, ``ws``.
                Prefer ``http``/``ws`` for HTTP-based services so the
                response includes a browser-reachable ``publicUrl``.
        """
        response = self.client.post(
            f"/v1/managed-agents/{agent_id}/expose-port",
            json={"port": port, "type": port_type.upper()},
        )
        data = response.json()
        if isinstance(data, dict) and "mappings" in data and data["mappings"]:
            return PortMapping(
                **SandboxAPI._normalize_port_mapping_data(data["mappings"][0])
            )
        return PortMapping(**SandboxAPI._normalize_port_mapping_data(data))

    def list_ports(self, agent_id: str) -> list[PortMapping]:
        """List exposed ports on the managed-agent sandbox.

        Exposure persists across sleep/wake: the api-server re-applies the
        previously-exposed set as part of the wake path. Host ports and
        public URLs are re-allocated on wake (the proxy URL is keyed on
        the new containerId), so callers that cached a URL before sleep
        should re-fetch with this method after wake.
        """
        response = self.client.get(f"/v1/managed-agents/{agent_id}/ports")
        data = response.json()
        if isinstance(data, dict) and "mappings" in data:
            return [
                PortMapping(**SandboxAPI._normalize_port_mapping_data(m))
                for m in data["mappings"]
            ]
        return []

    def stream_message(
        self,
        agent_id: str,
        content: str,
    ) -> Iterator[ManagedAgentStreamEvent]:
        """Send a message to a managed agent and yield SSE events."""
        with self.client.stream(
            "POST",
            f"/v1/managed-agents/{agent_id}/messages",
            json={"content": content},
            headers={
                "Accept": "text/event-stream",
                "Content-Type": "application/json",
            },
        ) as response:
            if response.status_code >= 400:
                self._raise_stream_error(response)

            for line in response.iter_lines():
                if isinstance(line, bytes):
                    line = line.decode("utf-8")
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if not payload:
                    continue
                try:
                    yield ManagedAgentStreamEvent.model_validate_json(payload)
                except Exception:  # noqa: S110 - Skip malformed chunks
                    continue

    def send_message(
        self,
        agent_id: str,
        content: str,
    ) -> list[ManagedAgentStreamEvent]:
        """Collect the full managed-agent event stream into memory."""
        return list(self.stream_message(agent_id, content))

    def _raise_stream_error(self, response: Any) -> None:
        """Normalize streaming HTTP failures to APIError."""
        body = response.read()
        text = body.decode("utf-8", "replace") if isinstance(body, bytes) else str(body)
        details: dict[str, Any] = {}
        message = text or "Unknown error"

        try:
            error_data = json.loads(text)
            if "error" in error_data:
                error_obj = error_data["error"]
                if isinstance(error_obj, dict):
                    details = error_obj
                    message = error_obj.get("message", message)
                else:
                    message = str(error_obj)
                    details = error_data
            else:
                details = error_data
                if isinstance(error_data, dict):
                    message = error_data.get("message", message)
        except Exception:
            details = {}

        raise APIError(
            status_code=response.status_code,
            message=message,
            details=details,
        )
