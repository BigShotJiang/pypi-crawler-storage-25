"""Bot integrations API client.

Bot integrations bind external chat providers (Telegram, Slack, and generic
webhook-style bridges) to managed agents. Telegram binding is represented as a
``provider="telegram"`` integration with ``fixedAgentId`` set to the managed
agent ID.
"""

from __future__ import annotations

from typing import Any

from .client import Client
from .models import (
    BotConversation,
    BotConversationListResponse,
    BotEvent,
    BotEventListResponse,
    BotIntegration,
    CreateBotIntegrationRequest,
    SyncTelegramWebhookResult,
)


class BotIntegrationsAPI:
    """Wrap ``/v1/workspaces/:workspaceId/bot-integrations`` endpoints."""

    def __init__(self, client: Client) -> None:
        self.client = client

    @staticmethod
    def _base_path(workspace_id: str) -> str:
        return f"/v1/workspaces/{workspace_id}/bot-integrations"

    def list_all(self, workspace_id: str) -> list[BotIntegration]:
        """List bot integrations for a workspace."""
        response = self.client.get(self._base_path(workspace_id))
        return [BotIntegration(**item) for item in response.json()]

    def create(
        self,
        workspace_id: str,
        *,
        provider: str,
        name: str,
        fixed_agent_id: str,
        owner_user_id: str | None = None,
        agent_workspace_group_id: str | None = None,
        model: str | None = None,
        instructions: str | None = None,
        provider_config: dict[str, Any] | None = None,
        telegram_bot_token: str | None = None,
        telegram_bot_token_key: str | None = None,
        telegram_secret_token: str | None = None,
        telegram_secret_token_key: str | None = None,
        telegram_allow_groups: bool | None = None,
        telegram_require_mention_in_groups: bool | None = None,
        telegram_allowed_chat_ids: list[str] | None = None,
        telegram_bot_username: str | None = None,
    ) -> BotIntegration:
        """Create a bot integration."""
        request = CreateBotIntegrationRequest(
            provider=provider,
            name=name,
            fixedAgentId=fixed_agent_id,
            ownerUserId=owner_user_id,
            agentWorkspaceGroupId=agent_workspace_group_id,
            model=model,
            instructions=instructions,
            providerConfig=provider_config,
            telegramBotToken=telegram_bot_token,
            telegramBotTokenKey=telegram_bot_token_key,
            telegramSecretToken=telegram_secret_token,
            telegramSecretTokenKey=telegram_secret_token_key,
            telegramAllowGroups=telegram_allow_groups,
            telegramRequireMentionInGroups=telegram_require_mention_in_groups,
            telegramAllowedChatIds=telegram_allowed_chat_ids,
            telegramBotUsername=telegram_bot_username,
        )
        response = self.client.post(
            self._base_path(workspace_id),
            json=request.model_dump(by_alias=True, exclude_none=True),
        )
        return BotIntegration(**response.json())

    def create_telegram(
        self,
        workspace_id: str,
        *,
        agent_id: str,
        name: str,
        bot_token: str | None = None,
        bot_token_key: str | None = None,
        secret_token: str | None = None,
        secret_token_key: str | None = None,
        allow_groups: bool | None = None,
        require_mention_in_groups: bool | None = None,
        allowed_chat_ids: list[str] | None = None,
        bot_username: str | None = None,
        owner_user_id: str | None = None,
        agent_workspace_group_id: str | None = None,
        model: str | None = None,
        instructions: str | None = None,
    ) -> BotIntegration:
        """Bind a managed agent to Telegram.

        ``bot_token`` is the Telegram Bot API token. ``bot_token_key`` remains
        supported for callers that already store the token as a workspace
        secret.
        """
        if not bot_token and not bot_token_key:
            raise ValueError("create_telegram requires bot_token or bot_token_key")

        return self.create(
            workspace_id,
            provider="telegram",
            name=name,
            fixed_agent_id=agent_id,
            owner_user_id=owner_user_id,
            agent_workspace_group_id=agent_workspace_group_id,
            model=model,
            instructions=instructions,
            telegram_bot_token=bot_token,
            telegram_bot_token_key=bot_token_key,
            telegram_secret_token=secret_token,
            telegram_secret_token_key=secret_token_key,
            telegram_allow_groups=allow_groups,
            telegram_require_mention_in_groups=require_mention_in_groups,
            telegram_allowed_chat_ids=allowed_chat_ids,
            telegram_bot_username=bot_username,
        )

    def get(self, workspace_id: str, integration_id: str) -> BotIntegration:
        """Get a bot integration."""
        response = self.client.get(f"{self._base_path(workspace_id)}/{integration_id}")
        return BotIntegration(**response.json())

    def update(
        self,
        workspace_id: str,
        integration_id: str,
        **fields: Any,
    ) -> BotIntegration:
        """Patch a bot integration.

        Keyword names may be Pythonic snake_case or already-camelCase API keys.
        """
        body = _normalize_update_fields(fields)
        response = self.client.patch(
            f"{self._base_path(workspace_id)}/{integration_id}",
            json=body,
        )
        return BotIntegration(**response.json())

    def enable(self, workspace_id: str, integration_id: str) -> BotIntegration:
        """Enable a bot integration."""
        response = self.client.post(
            f"{self._base_path(workspace_id)}/{integration_id}/enable",
        )
        return BotIntegration(**response.json())

    def disable(self, workspace_id: str, integration_id: str) -> BotIntegration:
        """Disable a bot integration."""
        response = self.client.post(
            f"{self._base_path(workspace_id)}/{integration_id}/disable",
        )
        return BotIntegration(**response.json())

    def list_conversations(
        self,
        workspace_id: str,
        integration_id: str,
        *,
        page: int | None = None,
        limit: int | None = None,
    ) -> BotConversationListResponse:
        """List conversations for a bot integration."""
        params: dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        response = self.client.get(
            f"{self._base_path(workspace_id)}/{integration_id}/conversations",
            params=params or None,
        )
        payload = response.json()
        payload["items"] = [BotConversation(**item) for item in payload.get("items", [])]
        return BotConversationListResponse(**payload)

    def list_events(
        self,
        workspace_id: str,
        integration_id: str,
        *,
        page: int | None = None,
        limit: int | None = None,
    ) -> BotEventListResponse:
        """List events for a bot integration."""
        params: dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        response = self.client.get(
            f"{self._base_path(workspace_id)}/{integration_id}/events",
            params=params or None,
        )
        payload = response.json()
        payload["items"] = [BotEvent(**item) for item in payload.get("items", [])]
        return BotEventListResponse(**payload)

    def sync_telegram_webhook(
        self,
        workspace_id: str,
        integration_id: str,
        *,
        drop_pending_updates: bool | None = None,
    ) -> SyncTelegramWebhookResult:
        """Set Telegram webhook + commands for an integration."""
        body: dict[str, Any] = {}
        if drop_pending_updates is not None:
            body["dropPendingUpdates"] = drop_pending_updates
        response = self.client.post(
            f"{self._base_path(workspace_id)}/{integration_id}/telegram/sync-webhook",
            json=body,
        )
        return SyncTelegramWebhookResult(**response.json())


def _normalize_update_fields(fields: dict[str, Any]) -> dict[str, Any]:
    aliases = {
        "fixed_agent_id": "fixedAgentId",
        "owner_user_id": "ownerUserId",
        "agent_workspace_group_id": "agentWorkspaceGroupId",
        "provider_config": "providerConfig",
        "telegram_bot_token": "telegramBotToken",
        "telegram_bot_token_key": "telegramBotTokenKey",
        "telegram_secret_token": "telegramSecretToken",
        "telegram_secret_token_key": "telegramSecretTokenKey",
        "telegram_allow_groups": "telegramAllowGroups",
        "telegram_require_mention_in_groups": "telegramRequireMentionInGroups",
        "telegram_allowed_chat_ids": "telegramAllowedChatIds",
        "telegram_bot_username": "telegramBotUsername",
    }
    body: dict[str, Any] = {}
    for key, value in fields.items():
        if value is None:
            continue
        body[aliases.get(key, key)] = value
    if not body:
        raise ValueError("update requires at least one field")
    return body
