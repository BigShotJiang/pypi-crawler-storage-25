"""
examples/direct_debit_example.py

Full walkthrough of the Direct Debit service — demonstrates all 5 HTTP methods.
Run this against the staging environment with a valid API key.

Usage:
    export SECUREPAY_API_KEY="SP-PK-xxxx"
    python examples/direct_debit_example.py
"""

import os
from datetime import date

from securepay import (
    BankAccount,
    CreateMandateRequest,
    DebitFrequency,
    InitiateDebitRequest,
    MandateStatus,
    SecurePayApi,
    SecurePayConfig,
    SecurePayException,
    UpdateMandateRequest,
)

API_KEY = os.environ.get("SECUREPAY_API_KEY", "SP-PK-your-key-here")


def main() -> None:
    # ── Initialise client (staging with logging on) ────────────────────────────
    client = SecurePayApi(
        api_key=API_KEY,
        config=SecurePayConfig.staging(enable_logging=True),
    )

    try:
        # ── 1. POST — Create a mandate ─────────────────────────────────────────
        print("\n--- 1. Creating mandate ---")
        mandate = client.direct_debit.create_mandate(
            CreateMandateRequest(
                customer_name="Ada Obi",
                customer_email="ada.obi@example.com",
                customer_phone="+2348012345678",
                bank_account=BankAccount(
                    account_number="0123456789",
                    bank_code="058",
                    account_name="Ada Obi",
                ),
                amount=5_000.00,
                currency="NGN",
                frequency=DebitFrequency.MONTHLY,
                start_date=date(2025, 8, 1),
                description="Monthly subscription — Premium Plan",
                metadata={"plan": "premium", "user_id": "usr_12345"},
            )
        )
        print(f"✅ Mandate created: {mandate.mandate_id} | Status: {mandate.status}")

        mandate_id = mandate.mandate_id

        # ── 2. GET — Retrieve a single mandate ─────────────────────────────────
        print("\n--- 2. Fetching mandate ---")
        fetched = client.direct_debit.get_mandate(mandate_id)
        print(f"✅ Mandate fetched: {fetched.customer_name} | Amount: {fetched.amount}")

        # ── 2b. GET — List all mandates ────────────────────────────────────────
        print("\n--- 2b. Listing mandates ---")
        mandate_list = client.direct_debit.list_mandates(page=1, page_size=10)
        print(f"✅ Total mandates: {mandate_list.total} | Page: {mandate_list.page}")

        # ── 3. PUT — Update mandate amount and frequency ───────────────────────
        print("\n--- 3. Updating mandate ---")
        updated = client.direct_debit.update_mandate(
            mandate_id=mandate_id,
            request=UpdateMandateRequest(
                amount=7_500.00,
                frequency=DebitFrequency.QUARTERLY,
                description="Upgraded to Quarterly Plan",
            ),
        )
        print(f"✅ Mandate updated: Amount → {updated.amount} | Freq → {updated.frequency}")

        # ── 4. PATCH — Suspend the mandate ─────────────────────────────────────
        print("\n--- 4. Patching mandate status → SUSPENDED ---")
        patched = client.direct_debit.patch_mandate_status(
            mandate_id=mandate_id,
            status=MandateStatus.SUSPENDED,
            reason="Customer requested temporary pause.",
        )
        print(f"✅ Mandate status patched: {patched.status}")

        # Reactivate it
        reactivated = client.direct_debit.patch_mandate_status(
            mandate_id=mandate_id,
            status=MandateStatus.ACTIVE,
        )
        print(f"✅ Mandate reactivated: {reactivated.status}")

        # ── 5. POST — Initiate a collection ────────────────────────────────────
        print("\n--- 5. Initiating collection ---")
        collection = client.direct_debit.initiate_collection(
            mandate_id=mandate_id,
            request=InitiateDebitRequest(
                amount=7_500.00,
                narration="Q3 2025 subscription",
                reference="ORD-2025-Q3-001",
            ),
        )
        print(f"✅ Collection initiated: {collection.collection_id} | {collection.status}")

        # ── GET — List collections ─────────────────────────────────────────────
        print("\n--- Listing collections ---")
        collections = client.direct_debit.list_collections(mandate_id)
        print(f"✅ Total collections: {collections.total}")

        # ── DELETE — Cancel the mandate ────────────────────────────────────────
        print("\n--- DELETE — Cancelling mandate ---")
        result = client.direct_debit.cancel_mandate(mandate_id)
        print(f"✅ Mandate cancelled: {result}")

    except SecurePayException as e:
        print(f"\n❌ SecurePay error: {e}")

    finally:
        client.close()


if __name__ == "__main__":
    main()
