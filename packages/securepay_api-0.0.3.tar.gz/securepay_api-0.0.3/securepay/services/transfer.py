from core.client import SecurePayClient
from models import SecurePayApiResponse
from models.models import CustomerDetail, InitiateTransferRequest, PaymentLinkRequest, RequeryTransactionReferenceRequest, SimulateTransactionStatusRequest, SubAccountSplit, TransferWebhookRequest






_BASE = "/api/Transfer"




class TransferService:
    """
    Provides access to the Transfer API endpoints.

    Instantiated automatically by SecurePayApi — do not create directly.
    Access via ``client.transfer.<method>()``.
    """

    def __init__(self, client: SecurePayClient) -> None:
        self._client = client

    def initiate_transfer(
        self,
        amount: float,
        invoice_id: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Initiate a transfer for a merchant.
        POST /api/Transfer/initiate/v2
        """

        request = InitiateTransferRequest(amount=amount, invoice_id=invoice_id)
        raw = self._client.post(
            f"{_BASE}/initiate/v2", 
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    

    
    
    def create_payment_link(
        self,
        description: str,
        amount: int,
        customer_detail: CustomerDetail,
        redirect_url: str,
        transaction_ref: str,
        sub_account_splits: list[SubAccountSplit]
    ) -> SecurePayApiResponse[dict]:
        """
        Create a payment link for a merchant.
        POST /api/Transfer/payment-link
        """
        request = PaymentLinkRequest(
            description=description,
            amount=amount,
            customerDetails=customer_detail,
            redirectUrl=redirect_url,
            transactionRef=transaction_ref,
            subAccountSplits=sub_account_splits,
        )
        
        raw = self._client.post(
            f"{_BASE}/payment-link", 
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def simulate_transaction_status(
        self,
        transaction_id: str,
        invoice_id: str,
    ) -> SecurePayApiResponse[dict]:
        
        """
        Simulate a transaction status update for testing.
        """
        request = SimulateTransactionStatusRequest(
            transactionId=transaction_id,
            invoiceId=invoice_id,
        )
        raw = self._client.post(
            f"{_BASE}/simulate-transaction-statustest?transactionId={transaction_id}&invoiceId={invoice_id}", 
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def requery_transaction_reference(
        self,
        transaction_ref: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Requery a transaction by its reference.
        GET /api/Transfer/requery?transactionRef={transaction_ref}
        """
        
        raw = self._client.get(
            f"{_BASE}/requery?transactionRef={transaction_ref}"
        )
        return SecurePayApiResponse[dict].model_validate(raw
    )
        
        
        
    def transfer_webhook_handler(
        self,
        webhookUrl: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Handle incoming transfer webhooks.
        This method can be used as a handler for webhook events related to transfers.
        """
        
        
        request = TransferWebhookRequest(
            webhookUrl=webhookUrl,
        )
        raw = self._client.post(
            f"{_BASE}/webhook", 
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
      
    
    
      
  
  

      
        
        
        