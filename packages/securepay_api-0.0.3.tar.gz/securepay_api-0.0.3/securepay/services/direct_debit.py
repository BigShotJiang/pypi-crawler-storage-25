from core.client import SecurePayClient
from models import SecurePayApiResponse
from models.models import CreateDirectBillerRequest, CreateElectronicMandateRequest, CreateProductRequest, CustomerDetail, FundTransferRequest, NameInquiryRequest




_BASE = "/api/DirectDebit"


class DirectDebitService:
    """
    Provides access to the Direct Debit API endpoints.

    Instantiated automatically by SecurePayApi — do not create directly.
    Access via ``client.direct_debit.<method>()``.
    """

    def __init__(self, client: SecurePayClient) -> None:
        self._client = client
    
    

    def create_direct_biller(
        self,
        rcNumber: str,
        name: str,
        address: str,
        email: str,
        phoneNumber: str,
        accountNumber: str,
        accountName: str,
        bankCode: str,
        mandateStatusNotificationUrl: str,
        merchantId: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Create a direct biller for a merchant.
        POST /api/DirectDebit/createBiller
        """
        request = CreateDirectBillerRequest(
            rcNumber=rcNumber,
            name=name,
            address=address,
            email=email,
            phoneNumber=phoneNumber,
            accountNumber=accountNumber,
            accountName=accountName,
            bankCode=bankCode,
            mandateStatusNotificationUrl=mandateStatusNotificationUrl,
            merchantId=merchantId,
        )
        
        raw = self._client.post(
            f"{_BASE}/createBiller", 
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def create_product(
        self,
        billerId: str,
        productName: str,
        merchantId: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Create a product for a merchant.
        POST /api/DirectDebit/createProduct
        """
        request = CreateProductRequest(
            billerId=billerId,
            productName=productName,
            merchantId=merchantId,
        )

        raw = self._client.post(
            f"{_BASE}/createProduct",
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def retrieve_nip_banks(
        self,
    ) -> SecurePayApiResponse[dict]:
        """
        Retrieve NIP banks.
        GET /api/DirectDebit/nipBanks
        """
        
        raw = self._client.get(
            f"{_BASE}/nipBanks"
        )
        return SecurePayApiResponse[list].model_validate(raw)
    
    
    def create_emandate(
        self,
        productId: int,
        billerId: str,
        accountNumber: str,
        bankCode: str,
        payerName: str,
        accountName: str,
        amount: float,
        narration: str,
        phoneNumber: str,
        subscriberCode: str,
        startDate: str,
        endDate: str,
        payerEmail: str,
        merchantId: str
    ) -> SecurePayApiResponse[dict]:
        
        """
        Create an electronic mandate for (NIBSS Direct Debit) for a customer.
        POST /api/DirectDebit/create-e-mandate
        """
        request = CreateElectronicMandateRequest(
            productId=productId,
            billerId=billerId,
            accountNumber=accountNumber,
            bankCode=bankCode,
            payerName=payerName,
            accountName=accountName,
            amount=amount,
            narration=narration,
            phoneNumber=phoneNumber,
            subscriberCode=subscriberCode,
            startDate=startDate,
            endDate=endDate,
            payerEmail=payerEmail,
            merchantId=merchantId
        )

        raw = self._client.post(
            f"{_BASE}/create-e-mandate",
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def retrieve_emandate_status(
        self,
        mandateCode: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Retrieve the status of an electronic mandate.
        GET /api/DirectDebit/mandate-status/{mandateCode}
        """
        
        raw = self._client.get(
            f"{_BASE}/mandate-status/{mandateCode}"
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    
    def create_emandate_v2(
        self,
        productId: int,
        billerId: str,
        accountNumber: str,
        bankCode: str,
        payerName: str,
        accountName: str,
        amount: float,
        narration: str,
        phoneNumber: str,
        subscriberCode: str,
        startDate: str,
        endDate: str,
        payerEmail: str,
        merchantId: str
    ) -> SecurePayApiResponse[dict]:
        
        """
        Create an electronic mandate for (NIBSS Direct Debit) for a customer.
        POST /api/DirectDebit/create-e-mandate/v2
        """
        request = CreateElectronicMandateRequest(
            productId=productId,
            billerId=billerId,
            accountNumber=accountNumber,
            bankCode=bankCode,
            payerName=payerName,
            accountName=accountName,
            amount=amount,
            narration=narration,
            phoneNumber=phoneNumber,
            subscriberCode=subscriberCode,
            startDate=startDate,
            endDate=endDate,
            payerEmail=payerEmail,
            merchantId=merchantId
        )

        raw = self._client.post(
            f"{_BASE}/create-e-mandate/v2",
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def look_up_name_inquiry(
        self,
        accountNumber: str,
        channelCode: int,
        destinationInstitutionCode: str,
        transactionId: str
    ) -> SecurePayApiResponse[dict]:
        
        """
        Look up the name associated with an account number.
        POST /api/DirectDebit/name-inquiry
        """
        request = NameInquiryRequest(
            accountNumber=accountNumber,
            channelCode=channelCode,
            destinationInstitutionCode=destinationInstitutionCode,
            transactionId=transactionId
        )

        raw = self._client.post(
            f"{_BASE}/name-inquiry",
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)


    def retrieve_financial_institutions(
        self,
    ) -> SecurePayApiResponse[dict]:
        """
        Retrieve the status of an electronic mandate.
        GET /api/DirectDebit/get-financial-institution
        """
        
        raw = self._client.get(
            f"{_BASE}/get-financial-institution"
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    
    {
  "sourceInstitutionCode": "string",
  "amount": 0,
  "beneficiaryAccountName": "string",
  "beneficiaryAccountNumber": "string",
  "beneficiaryBankVerificationNumber": "string",
  "beneficiaryKYCLevel": 0,
  "channelCode": 0,
  "originatorAccountName": "string",
  "originatorAccountNumber": "string",
  "originatorBankVerificationNumber": "string",
  "originatorKYCLevel": 0,
  "destinationInstitutionCode": "string",
  "mandateReferenceNumber": "string",
  "nameEnquiryRef": "string",
  "originatorNarration": "string",
  "paymentReference": "string",
  "transactionId": "string",
  "transactionLocation": "string",
  "beneficiaryNarration": "string",
  "billerId": "string",
  "initiatorAccountNumber": "string",
  "initiatorAccountName": "string"
}
    
    
    def fund_transfer(
        self,
        sourceInstitutionCode: str,
        amount: float,
        beneficiaryAccountName: str,
        beneficiaryAccountNumber: str,
        beneficiaryBankVerificationNumber: str,
        beneficiaryKYCLevel: int,
        channelCode: int,
        originatorAccountName: str,
        originatorAccountNumber: str,
        originatorBankVerificationNumber: str,
        originatorKYCLevel: int,
        destinationInstitutionCode: str,
        mandateReferenceNumber: str,
        nameEnquiryRef: str,
        originatorNarration: str,
        paymentReference: str,
        transactionId: str,
        transactionLocation: str | None = None,
        beneficiaryNarration: str | None = None,
        billerId: str | None = None,
        initiatorAccountNumber: str | None = None,
        initiatorAccountName: str | None = None
    ) -> SecurePayApiResponse[dict]:
        
        """
        Perform a fund transfer using an electronic mandate.
        POST /api/DirectDebit/fund-transfer
        """
        request = FundTransferRequest(
            sourceInstitutionCode=sourceInstitutionCode,
            amount=amount,
            beneficiaryAccountName=beneficiaryAccountName,
            beneficiaryAccountNumber=beneficiaryAccountNumber,
            beneficiaryBankVerificationNumber=beneficiaryBankVerificationNumber,
            beneficiaryKYCLevel=beneficiaryKYCLevel,
            channelCode=channelCode,
            originatorAccountName=originatorAccountName,
            originatorAccountNumber=originatorAccountNumber,
            originatorBankVerificationNumber=originatorBankVerificationNumber,
            originatorKYCLevel=originatorKYCLevel,
            destinationInstitutionCode=destinationInstitutionCode,
            mandateReferenceNumber=mandateReferenceNumber,
            nameEnquiryRef=nameEnquiryRef,
            originatorNarration=originatorNarration,
            paymentReference=paymentReference,
            transactionId=transactionId,
            transactionLocation=transactionLocation,
            beneficiaryNarration=beneficiaryNarration,
            billerId=billerId,
            initiatorAccountNumber=initiatorAccountNumber,
            initiatorAccountName=initiatorAccountName
        )

        raw = self._client.post(
            f"{_BASE}/fund-transfer",
            body=request.to_api_dict()
        )
        return SecurePayApiResponse[dict].model_validate(raw)

    
    
    