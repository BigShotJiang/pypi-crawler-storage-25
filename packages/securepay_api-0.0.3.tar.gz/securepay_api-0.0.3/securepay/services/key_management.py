"""
Service class for the Key Management section of the SecurePay API.

Example::

    response = client.key_management.generate_key("merchant@example.com")

    print(response.success)                   # True
    print(response.message)                   # "Key generated successfully"
    print(response.data.public_key_encrypted) # "SP-PK-xxxx"
"""

from core.client import SecurePayClient
from models import SecurePayApiResponse
from models import GeneratedKeyData, GenerateKeyRequest

_BASE = "/api/KeyManager"





class KeyManagementService:
    """
    Provides access to the Key Management API endpoints.

    Instantiated automatically by SecurePayApi — do not create directly.
    Access via ``client.key_management.<method>()``.
    """

    def __init__(self, client: SecurePayClient) -> None:
        self._client = client

    def generate_key(
        self,
        merchant_email: str,
    ) -> SecurePayApiResponse[GeneratedKeyData]:
        """
        Generate a public API key for a merchant.

        GET /api/KeyManager/generateKey?merchantEmail=xxx

        Args:
            merchant_email: The merchant's registered email address.

        Returns:
            SecurePayApiResponse[GeneratedKeyData] — envelope with the
            generated key in the data field.

        Raises:
            SecurePayValidationError: If the email is missing or invalid.
            SecurePayUnauthorizedError: If the API key is invalid.

        Example::

            response = client.key_management.generate_key("merchant@example.com")
            print(response.data.public_key_encrypted)  # "SP-PK-xxxx"
        """
        request = GenerateKeyRequest(merchantEmail=merchant_email)
        raw = self._client.get(
            f"{_BASE}/generateKey",
            params=request.to_query_params(),
        )
        return SecurePayApiResponse[GeneratedKeyData].model_validate(
            {**raw, "data": GeneratedKeyData.model_validate(raw.get("data", {}))}
        )