from core.client import SecurePayClient
from models import SecurePayApiResponse





_BASE = "/api/checkout"


class CheckoutService:
    """
    Provides access to the Checkout API endpoints.

    Instantiated automatically by SecurePayApi — do not create directly.
    Access via ``client.checkout.<method>()``.
    """

    def __init__(self, client: SecurePayClient) -> None:
        self._client = client
    
    
    def retrieve_payment_channels(
        self,
        invoiceId: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Retrieve the available payment channels for an invoice.
        GET /api/checkout/{invoiceId}/available-channels
        """
        
        raw = self._client.get(
            f"{_BASE}/{invoiceId}/available-channels"
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def retrieve_price_info(
        self,
        invoiceId: str,
        channel: int,
    ) -> SecurePayApiResponse[dict]:
        
        """
        Retrieve the price information for an invoice.
        GET /api/checkout/{invoiceId}/channel/{channel}/breakdown"
        """
        
        raw = self._client.get(
            f"{_BASE}/{invoiceId}/channel/{channel}/breakdown"
        )
        return SecurePayApiResponse[dict].model_validate(raw)
    
    
    def generate_pricing_preview(
        self,
        invoiceId: str,
    ) -> SecurePayApiResponse[dict]:
        """
        Generate a pricing preview for an invoice/checkout session.
        GET /api/checkout/{invoiceId}/preview
        """
        
        raw = self._client.get(
            f"{_BASE}/{invoiceId}/preview"
        )
        return SecurePayApiResponse[dict].model_validate(raw)

    