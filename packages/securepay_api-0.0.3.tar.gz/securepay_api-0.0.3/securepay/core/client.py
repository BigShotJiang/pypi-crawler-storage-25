"""
Core HTTP client for all SecurePay API calls.

Wraps httpx and provides:
- Automatic injection of auth headers (X-Api-Key, X-Request-ID) on every request
- Structured request/response logging (when enabled)
- Automatic retry with exponential back-off via tenacity (when enabled)
- Typed exception mapping from HTTP errors to SecurePayException subclasses

All service classes receive an instance of SecurePayClient and call
get(), post(), put(), patch(), and delete() through it.
"""


from typing import Any

import httpx
from tenacity import (
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from .config import SecurePayConfig
from .exceptions import (
    SecurePayConflictError,
    SecurePayException,
    SecurePayNetworkError,
    SecurePayNotFoundError,
    SecurePayRateLimitError,
    SecurePayServerError,
    SecurePayUnauthorizedError,
    SecurePayValidationError,
)
from .logger import log_error, log_request, log_response, setup_logging


def _is_retryable(exc: BaseException) -> bool:
    """
    Determines whether an exception warrants a retry attempt.

    Retries on:
    - Network errors (no connectivity, DNS failure, timeout)
    - HTTP 500 (Internal Server Error)
    - HTTP 503 (Service Unavailable)

    Does NOT retry on auth, validation, or not-found errors.
    """
    if isinstance(exc, SecurePayNetworkError):
        return True
    if isinstance(exc, SecurePayServerError):
        return True
    return False


class SecurePayClient:
    """
    The central HTTP client used by all SecurePay service classes.

    Args:
        api_key:    Your SecurePay public API key.
        config:     Optional SecurePayConfig instance. Defaults to staging.

    Example::

        client = SecurePayClient(
            api_key="SP-PK-xxxx",
            config=SecurePayConfig.staging(enable_logging=True),
        )
    """

    def __init__(
        self,
        api_key: str,
        config: SecurePayConfig | None = None,
    ) -> None:
        self._api_key = api_key
        self._config = config or SecurePayConfig()
        self._logging_enabled = self._config.enable_logging

        setup_logging(self._config.enable_logging)

        self._http = httpx.Client(
            base_url=self._config.base_url,
            timeout=self._config.timeout,
        )

    # ── Public HTTP Methods ────────────────────────────────────────────────────

    def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a GET request to the given path."""
        return self._request("GET", path, params=params)

    def post(
        self,
        path: str,
        *,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a POST request with an optional JSON body."""
        return self._request("POST", path, body=body)

    def put(
        self,
        path: str,
        *,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a PUT request with an optional JSON body."""
        return self._request("PUT", path, body=body)

    def patch(
        self,
        path: str,
        *,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a PATCH request with an optional JSON body."""
        return self._request("PATCH", path, body=body)

    def delete(
        self,
        path: str,
        *,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a DELETE request with an optional JSON body."""
        return self._request("DELETE", path, body=body)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "SecurePayClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Internal ───────────────────────────────────────────────────────────────

    def _build_headers(self) -> dict[str, str]:
        """
        Builds the required headers for every SecurePay API request.

        Delegates to SecurePayConfig.build_headers() which is the single
        source of truth for all header keys and values, as per the
        SecurePay API docs:
            - X-Api-Key     : developer's SecurePay public API key
            - Content-Type  : application/json
            - X-Request-ID  : freshly generated UUID v4 for request tracing
        """
        return self._config.build_headers(self._api_key)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Core request dispatcher.

        Wraps the actual HTTP call with retry logic if enabled.
        """
        if self._config.enable_retry:
            return self._request_with_retry(method, path, params=params, body=body)
        return self._execute_request(method, path, params=params, body=body)

    def _request_with_retry(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Wraps _execute_request with tenacity retry logic."""

        @retry(
            retry=retry_if_exception(_is_retryable),
            stop=stop_after_attempt(self._config.max_retries),
            wait=wait_exponential(multiplier=1, min=1, max=8),
            reraise=True,
        )
        def _do() -> dict[str, Any]:
            return self._execute_request(method, path, params=params, body=body)

        return _do()

    def _execute_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Executes a single HTTP request and maps the response."""
        headers = self._build_headers()

        if self._logging_enabled:
            log_request(method, path, headers, body)

        try:
            response = self._http.request(
                method=method,
                url=path,
                params=params,
                json=body,
                headers=headers,
            )
        except httpx.TimeoutException as exc:
            raise SecurePayNetworkError(
                "Request timed out. The SecurePay server did not respond in time."
            ) from exc
        except httpx.ConnectError as exc:
            raise SecurePayNetworkError(
                "Connection failed. Unable to reach the SecurePay server."
            ) from exc
        except httpx.RequestError as exc:
            raise SecurePayNetworkError(str(exc)) from exc

        if self._logging_enabled:
            log_response(response.status_code, path, response.text)

        return self._handle_response(response)

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """
        Parses the HTTP response and raises typed exceptions on error status codes.
        """
        raw: dict[str, Any] = {}

        try:
            raw = response.json()
        except Exception:
            # If the body is not JSON, we still want to raise on error codes.
            pass

        server_message: str = raw.get("message", "")

        match response.status_code:
            case 200 | 201 | 202 | 204:
                return raw

            case 400:
                log_error(400, str(response.url), server_message)
                raise SecurePayValidationError(
                    detail=server_message or "Invalid request parameters.",
                    raw_response=raw,
                )
            case 401:
                log_error(401, str(response.url), server_message)
                raise SecurePayUnauthorizedError(raw_response=raw)

            case 404:
                log_error(404, str(response.url), server_message)
                raise SecurePayNotFoundError(
                    detail=server_message or "Resource not found.",
                    raw_response=raw,
                )
            case 409:
                log_error(409, str(response.url), server_message)
                raise SecurePayConflictError(
                    detail=server_message or "Resource conflict.",
                    raw_response=raw,
                )
            case 429:
                log_error(429, str(response.url), server_message)
                raise SecurePayRateLimitError(raw_response=raw)

            case 500 | 502 | 503:
                log_error(response.status_code, str(response.url), server_message)
                raise SecurePayServerError(raw_response=raw)

            case _:
                log_error(response.status_code, str(response.url), server_message)
                raise SecurePayException(
                    message=server_message or "An unexpected error occurred.",
                    status_code=response.status_code,
                    raw_response=raw,
                )
