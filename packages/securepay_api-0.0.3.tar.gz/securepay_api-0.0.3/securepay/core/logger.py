"""
Internal logging utilities for the SecurePay client.

Sensitive headers (X-Api-Key, Authorization) are always redacted
before any log output — even in development.
"""

import logging
from typing import Any

logger = logging.getLogger("securepay")

# ── Sensitive header keys to redact from logs ──────────────────────────────────
_SENSITIVE_HEADERS = {"x-api-key", "authorization"}


def setup_logging(enable: bool) -> None:
    """
    Configure the securepay logger.

    When enabled, sets up a coloured StreamHandler at DEBUG level.
    When disabled, adds a NullHandler so the library stays silent.
    """
    if not enable:
        logger.addHandler(logging.NullHandler())
        return

    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        fmt="%(asctime)s [%(name)s] %(levelname)s — %(message)s",
        datefmt="%H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)


def sanitise_headers(headers: dict[str, Any]) -> dict[str, Any]:
    """Returns a copy of headers with sensitive values replaced by ***REDACTED***."""
    return {
        key: "***REDACTED***" if key.lower() in _SENSITIVE_HEADERS else value
        for key, value in headers.items()
    }


def log_request(method: str, url: str, headers: dict, body: Any) -> None:
    logger.debug(
        "▶ REQUEST  %s %s\n  Headers: %s\n  Body:    %s",
        method.upper(),
        url,
        sanitise_headers(headers),
        body,
    )


def log_response(status_code: int, url: str, body: Any) -> None:
    logger.debug(
        "◀ RESPONSE %s %s\n  Body: %s",
        status_code,
        url,
        body,
    )


def log_error(status_code: int | None, url: str, message: str) -> None:
    logger.error(
        "✕ ERROR    %s %s — %s",
        status_code or "N/A",
        url,
        message,
    )
