"""
Configuration for the SecurePay API client.

Controls the environment (staging vs production), timeouts,
retry behaviour, logging, and the standard request headers
required by every SecurePay API call.

Required headers on every request (as per SecurePay API docs):
    X-Api-Key       — your SecurePay public API key
    Content-Type    — always application/json
    X-Request-ID    — a unique UUID v4 per request for server-side tracing
"""

import uuid
from dataclasses import dataclass


# ── Environment Base URLs ──────────────────────────────────────────────────────

STAGING_BASE_URL = "https://securepay-staging-api.getsecurepay.ai"
PRODUCTION_BASE_URL = "https://api.getsecurepay.ai"


# ── Required Request Header Keys ───────────────────────────────────────────────
# These are the exact header names the SecurePay API expects on every request.

HEADER_API_KEY = "X-Api-Key"
HEADER_CONTENT_TYPE = "Content-Type"
HEADER_REQUEST_ID = "X-Request-ID"
HEADER_ACCEPT = "Accept"

# ── Fixed Header Values ────────────────────────────────────────────────────────

CONTENT_TYPE_JSON = "application/json"
ACCEPT_JSON = "application/json"


@dataclass
class SecurePayConfig:
    """
    Configuration options for the SecurePay API client.

    Holds all settings needed to initialise the HTTP client, including
    the API base URL, timeouts, retry/logging toggles, and the method
    for building the required request headers for every API call.

    Required headers (built automatically via build_headers):
        X-Api-Key      — injected from the api_key passed to SecurePayApi
        Content-Type   — always set to application/json
        X-Request-ID   — auto-generated UUID v4 per request

    Attributes:
        base_url:       The API base URL. Defaults to staging.
        timeout:        Request timeout in seconds. Defaults to 30.
        max_retries:    Maximum retry attempts on transient errors. Defaults to 3.
        enable_logging: Whether to log requests and responses. Always False in production.
        enable_retry:   Whether to automatically retry failed requests.
    """

    base_url: str = STAGING_BASE_URL
    timeout: float = 30.0
    max_retries: int = 3
    enable_logging: bool = False
    enable_retry: bool = True

    def build_headers(self, api_key: str) -> dict[str, str]:
        """
        Builds the required headers for every SecurePay API request.

        As per the SecurePay API documentation, every request must include:
            - X-Api-Key     : the developer's SecurePay public API key
            - Content-Type  : application/json
            - X-Request-ID  : a freshly generated UUID v4 for request tracing

        Args:
            api_key: The SecurePay public API key to inject into X-Api-Key.

        Returns:
            A dict of headers ready to attach to any outgoing HTTP request.

        Example::

            config = SecurePayConfig.staging()
            headers = config.build_headers("SP-PK-xxxx")
            # {
            #     "X-Api-Key": "SP-PK-xxxx",
            #     "Content-Type": "application/json",
            #     "X-Request-ID": "a3f1c2d4-...",
            #     "Accept": "application/json",
            # }
        """
        return {
            HEADER_API_KEY: api_key,
            HEADER_CONTENT_TYPE: CONTENT_TYPE_JSON,
            HEADER_REQUEST_ID: str(uuid.uuid4()),
            HEADER_ACCEPT: ACCEPT_JSON,
        }

    # ── Environment Presets ────────────────────────────────────────────────────

    @classmethod
    def staging(
        cls,
        enable_logging: bool = True,
        enable_retry: bool = True,
    ) -> "SecurePayConfig":
        """
        Returns a config preset for the staging (sandbox) environment.

        Logging is enabled by default in staging so developers can
        inspect requests and responses during development.
        """
        return cls(
            base_url=STAGING_BASE_URL,
            enable_logging=enable_logging,
            enable_retry=enable_retry,
        )

    @classmethod
    def production(cls, enable_retry: bool = True) -> "SecurePayConfig":
        """
        Returns a config preset for the production environment.

        Logging is always disabled in production to prevent leaking
        sensitive payment data into application logs.
        """
        return cls(
            base_url=PRODUCTION_BASE_URL,
            enable_logging=False,  # Never log in production
            enable_retry=enable_retry,
        )
