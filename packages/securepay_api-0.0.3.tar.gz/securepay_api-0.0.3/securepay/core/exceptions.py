"""
Typed exception hierarchy for the SecurePay API client.

All errors raised by SecurePay service methods are instances of
SecurePayException or one of its subclasses, so callers can catch
them uniformly or handle specific cases individually.

Example::

    try:
        result = client.direct_debit.create_mandate(...)
    except SecurePayUnauthorizedError:
        # Handle invalid/expired API key
    except SecurePayValidationError as e:
        # Handle bad request data
        print(e.message)
    except SecurePayException as e:
        # Catch-all for any other SecurePay error
        print(e)
"""


class SecurePayException(Exception):
    """
    Base exception for all SecurePay API errors.

    Attributes:
        message:        Human-readable description of the error.
        status_code:    HTTP status code returned by the server, if available.
        error_code:     API-level error code from the response body, if available.
        raw_response:   The raw response dict from the server, if available.
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        error_code: str | None = None,
        raw_response: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        self.raw_response = raw_response

    def __str__(self) -> str:
        parts = [f"SecurePayException: {self.message}"]
        if self.status_code:
            parts.append(f"(HTTP {self.status_code})")
        if self.error_code:
            parts.append(f"[code: {self.error_code}]")
        return " ".join(parts)


# ── Specific Exception Types ───────────────────────────────────────────────────


class SecurePayUnauthorizedError(SecurePayException):
    """Raised on HTTP 401 — missing or invalid API key."""

    def __init__(self, raw_response: dict | None = None) -> None:
        super().__init__(
            message="Unauthorized: Missing or invalid API key. "
            "Check your API key in the SecurePay Developer Console.",
            status_code=401,
            error_code="UNAUTHORIZED",
            raw_response=raw_response,
        )


class SecurePayValidationError(SecurePayException):
    """Raised on HTTP 400 — request body failed server-side validation."""

    def __init__(
        self,
        detail: str = "Invalid request parameters.",
        raw_response: dict | None = None,
    ) -> None:
        super().__init__(
            message=f"Bad Request: {detail}",
            status_code=400,
            error_code="BAD_REQUEST",
            raw_response=raw_response,
        )


class SecurePayNotFoundError(SecurePayException):
    """Raised on HTTP 404 — the requested resource does not exist."""

    def __init__(
        self,
        detail: str = "The requested resource was not found.",
        raw_response: dict | None = None,
    ) -> None:
        super().__init__(
            message=f"Not Found: {detail}",
            status_code=404,
            error_code="NOT_FOUND",
            raw_response=raw_response,
        )


class SecurePayConflictError(SecurePayException):
    """Raised on HTTP 409 — resource conflict (e.g. duplicate mandate)."""

    def __init__(
        self,
        detail: str = "A conflict occurred with the current state of the resource.",
        raw_response: dict | None = None,
    ) -> None:
        super().__init__(
            message=f"Conflict: {detail}",
            status_code=409,
            error_code="CONFLICT",
            raw_response=raw_response,
        )


class SecurePayServerError(SecurePayException):
    """Raised on HTTP 500 — SecurePay internal server error."""

    def __init__(self, raw_response: dict | None = None) -> None:
        super().__init__(
            message="Server Error: SecurePay experienced an internal error. "
            "Please try again later or contact support.",
            status_code=500,
            error_code="SERVER_ERROR",
            raw_response=raw_response,
        )


class SecurePayNetworkError(SecurePayException):
    """Raised on connection/timeout failures — no HTTP response received."""

    def __init__(self, detail: str = "Unable to reach SecurePay.") -> None:
        super().__init__(
            message=f"Network Error: {detail} Check your internet connection.",
            error_code="NETWORK_ERROR",
        )


class SecurePayRateLimitError(SecurePayException):
    """Raised on HTTP 429 — rate limit exceeded."""

    def __init__(self, raw_response: dict | None = None) -> None:
        super().__init__(
            message="Rate Limit Exceeded: Too many requests. "
            "Please slow down and try again.",
            status_code=429,
            error_code="RATE_LIMITED",
            raw_response=raw_response,
        )
