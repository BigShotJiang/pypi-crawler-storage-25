"""
Typed request and response models for the Direct Debit API section.

All models use Pydantic v2 for automatic validation, serialisation,
and clear error messages when fields are missing or wrong type.

Every endpoint returns the standard SecurePayApiResponse envelope:
    {
        "success": true,
        "statusCode": "OK",
        "message": "Operation completed",
        "data": { ... }
    }

The `data` field is typed per-endpoint using SecurePayApiResponse[T].
"""

from datetime import date, datetime
from enum import Enum
from typing import Any, Generic, TypeVar
from pydantic import BaseModel, Field
from models import SecurePayApiResponse







# ── Generic Type Variable for typed response data ──────────────────────────────

T = TypeVar("T")


# ── Enums ──────────────────────────────────────────────────────────────────────


class MandateStatus(str, Enum):
    """Possible lifecycle states of a Direct Debit mandate."""

    PENDING = "pending"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


class DebitFrequency(str, Enum):
    """How often a recurring direct debit should be collected."""

    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    ANNUALLY = "annually"
    ONE_OFF = "one_off"


class DebitStatus(str, Enum):
    """Status of a single direct debit collection attempt."""

    PENDING = "pending"
    PROCESSING = "processing"
    SUCCESSFUL = "successful"
    FAILED = "failed"
    REVERSED = "reversed"


# ── Standard Response Envelope ─────────────────────────────────────────────────


class SecurePayApiResponse(BaseModel, Generic[T]):
    """
    Standard SecurePay API response envelope — returned by every endpoint.

    Generic over T so the `data` field is fully typed per endpoint.

    Usage::

        # Typed response for a single mandate
        response: SecurePayApiResponse[MandateData]

        # Typed response for a paginated list
        response: SecurePayApiResponse[MandateListData]

        # Typed response for a collection
        response: SecurePayApiResponse[DebitCollectionData]

    Shape::

        {
            "success": true,
            "statusCode": "OK",
            "message": "Operation completed",
            "data": { ... }        ← typed as T
        }
    """

    success: bool
    status_code: str = Field(alias="statusCode")
    message: str
    data: T | None = None

    model_config = {"populate_by_name": True}


# ── Shared Sub-models ──────────────────────────────────────────────────────────


class BankAccount(BaseModel):
    """Represents the customer's bank account for direct debit."""

    account_number: str = Field(..., description="Customer bank account number.")
    bank_code: str = Field(..., description="3-digit bank sort/routing code.")
    account_name: str = Field(..., description="Name on the bank account.")


# ── Response Data Models ───────────────────────────────────────────────────────
# These represent only the `data` field inside SecurePayApiResponse[T].
# They are never returned directly — always wrapped in SecurePayApiResponse.


class MandateData(BaseModel):
    """
    The mandate object inside SecurePayApiResponse[MandateData].

    Returned by: create_mandate, get_mandate, update_mandate,
                 patch_mandate_status.
    """

    mandate_id: str = Field(alias="mandateId")
    customer_name: str = Field(alias="customerName")
    customer_email: str = Field(alias="customerEmail")
    customer_phone: str = Field(alias="customerPhone")
    bank_account: BankAccount = Field(alias="bankAccount")
    amount: float
    currency: str
    frequency: DebitFrequency
    status: MandateStatus
    start_date: date = Field(alias="startDate")
    end_date: date | None = Field(default=None, alias="endDate")
    description: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")

    model_config = {"populate_by_name": True}


class MandateListData(BaseModel):
    """
    Paginated mandate list inside SecurePayApiResponse[MandateListData].

    Returned by: list_mandates.
    """

    items: list[MandateData]
    total: int
    page: int
    page_size: int = Field(alias="pageSize")
    has_next_page: bool = Field(alias="hasNextPage")

    model_config = {"populate_by_name": True}


class DebitCollectionData(BaseModel):
    """
    A single collection attempt inside SecurePayApiResponse[DebitCollectionData].

    Returned by: initiate_collection, get_collection.
    """

    collection_id: str = Field(alias="collectionId")
    mandate_id: str = Field(alias="mandateId")
    amount: float
    currency: str
    status: DebitStatus
    narration: str | None = None
    reference: str | None = None
    failure_reason: str | None = Field(default=None, alias="failureReason")
    collected_at: datetime | None = Field(default=None, alias="collectedAt")
    created_at: datetime = Field(alias="createdAt")

    model_config = {"populate_by_name": True}


class CollectionListData(BaseModel):
    """
    Paginated collection list inside SecurePayApiResponse[CollectionListData].

    Returned by: list_collections.
    """

    items: list[DebitCollectionData]
    total: int
    page: int
    page_size: int = Field(alias="pageSize")
    has_next_page: bool = Field(alias="hasNextPage")

    model_config = {"populate_by_name": True}


# ── Request Models ─────────────────────────────────────────────────────────────


class CreateMandateRequest(BaseModel):
    """
    Request body for POST /api/direct-debit/mandates.
    """

    customer_name: str = Field(..., description="Full name of the account holder.")
    customer_email: str = Field(..., description="Customer email address.")
    customer_phone: str = Field(..., description="Customer phone number.")
    bank_account: BankAccount = Field(..., description="Customer's bank account details.")
    amount: float = Field(..., gt=0, description="Amount to debit per collection cycle.")
    currency: str = Field(default="NGN", description="ISO 4217 currency code.")
    frequency: DebitFrequency = Field(..., description="How often to collect the debit.")
    start_date: date = Field(..., description="Date the mandate becomes active.")
    end_date: date | None = Field(default=None, description="Optional mandate expiry date.")
    description: str | None = Field(default=None, description="Optional mandate description.")
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Optional key-value metadata to attach to the mandate.",
    )

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)


class UpdateMandateRequest(BaseModel):
    """
    Request body for PUT /api/direct-debit/mandates/{mandate_id}.

    All fields are optional — only send what needs to change.
    """

    amount: float | None = Field(default=None, gt=0)
    frequency: DebitFrequency | None = None
    end_date: date | None = None
    description: str | None = None
    metadata: dict[str, Any] | None = None

    def to_api_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude_none=True)


class PatchMandateStatusRequest(BaseModel):
    """
    Request body for PATCH /api/direct-debit/mandates/{mandate_id}/status.
    """

    status: MandateStatus
    reason: str | None = Field(
        default=None,
        description="Optional reason for the status change.",
    )

    def to_api_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude_none=True)


class InitiateDebitRequest(BaseModel):
    """
    Request body for POST /api/direct-debit/mandates/{mandate_id}/collect.
    """

    amount: float = Field(..., gt=0, description="Amount to collect in this cycle.")
    currency: str = Field(default="NGN")
    narration: str | None = Field(
        default=None,
        description="Short description shown on the customer's bank statement.",
    )
    reference: str | None = Field(
        default=None,
        description="Your unique reference for this collection.",
    )

    def to_api_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude_none=True)


class ListMandatesRequest(BaseModel):
    """
    Query parameters for GET /api/direct-debit/mandates.
    """

    page: int = Field(default=1, description="Page number (1-based).")
    page_size: int = Field(default=20, alias="pageSize", description="Results per page.")
    status: MandateStatus | None = Field(default=None, description="Filter by mandate status.")
    customer_email: str | None = Field(
        default=None,
        alias="customerEmail",
        description="Filter by customer email.",
    )

    def to_query_params(self) -> dict[str, Any]:
        """Serialises the model into URL query parameters, excluding None values."""
        return self.model_dump(mode="json", exclude_none=True, by_alias=True)


class ListCollectionsRequest(BaseModel):
    """
    Query parameters for GET /api/direct-debit/mandates/{mandate_id}/collections.
    """

    page: int = Field(default=1, description="Page number (1-based).")
    page_size: int = Field(default=20, alias="pageSize", description="Results per page.")

    def to_query_params(self) -> dict[str, Any]:
        """Serialises the model into URL query parameters."""
        return self.model_dump(mode="json", exclude_none=True, by_alias=True)
    
    
    



# ── Request Model ──────────────────────────────────────────────────────────────


class GenerateKeyRequest(BaseModel):
    """
    Query parameters for GET /api/KeyManager/generateKey.

    Generates a public API key for a merchant.
    """

    merchant_email: str = Field(
        ...,
        alias="merchantEmail",
        description="The merchant's registered email address.",
    )

    def to_query_params(self) -> dict[str, Any]:
        """Serialises to URL query parameters using the API's camelCase field names."""
        return self.model_dump(mode="json", exclude_none=True, by_alias=True)


# ── Response Data Model ────────────────────────────────────────────────────────


class GeneratedKeyData(BaseModel):
    """
    The key payload inside SecurePayApiResponse[GeneratedKeyData].

    Returned by: generate_key.
    """

    public_key_encrypted: str = Field(
        alias="publicKeyEncrypted",
        description="The generated encrypted public API key. Format: SP-PK-<alphanumeric>",
    )

    model_config = {"populate_by_name": True}



## TRANSFERS

class InitiateTransferRequest(BaseModel):
    
    """
    Request body for POST /api/Transfer/initiate/v2.
    """
    
    amount: float = Field(..., gt=0, description="Amount to debit")
    invoice_id: str = Field(default="", description="Invoice id")
    

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)


class CustomerDetail(BaseModel):
    """Customer details nested inside PaymentLinkRequest."""
    emailAddress: str = Field(..., description="Customer email address.")
    phoneNumber: str = Field(..., description="Customer phone number.")
    
    
class SubAccountSplit(BaseModel):
    """Sub account split details nested inside PaymentLinkRequest."""
    settlementConfigId: str = Field(..., description="Settlement config id")
    transactionSplitRatio: str = Field(..., description="Transaction split ratio.")


class PaymentLinkRequest(BaseModel):
    """
    Request body for POST /api/Transfer/payment-link.
    """
    description: str = Field(..., description="Description for the payment link.")
    amount: int = Field(..., gt=0, description="Amount to debit.")
    customerDetails: CustomerDetail = Field(..., description="Customer details for the payment link.")
    redirectUrl: str = Field(..., description="URL to redirect the customer after payment.")
    transactionRef: str = Field(..., description="Unique transaction REF for idempotency.")
    subAccountSplits: list[SubAccountSplit] = Field(..., description="Sub account splits for the payment link.")
    

    def to_api_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude_none=True)
    
    
class SimulateTransactionStatusRequest(BaseModel):
    """
    Simulate transaction status
    """
    
    transactionId: str = Field(..., description="The transaction ID to simulate.")
    invoiceId: str = Field(..., description="The invoice id")
    
    
    def to_api_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json", exclude_none=True)
    
    
    
class TransferWebhookRequest(BaseModel):
    
    """
    Request body for POST /api/Transfer/webhook.
    """
    
    webhookUrl: str = Field(..., description="The webhook URL to receive notifications.")
    

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)
    
    
    



##  DIRECT DEBIT

class CreateDirectBillerRequest(BaseModel):
    
    """
    Request body for POST /api/DirectDebit/createBiller.
    """
    
    rcNumber: str = Field(..., description="The RC number of the biller.")
    name: str = Field(..., description="The name of the biller.")
    address: str = Field(..., description="The address of the biller.")
    email: str = Field(..., description="The email of the biller.")
    phoneNumber: str = Field(..., description="The phone number of the biller.")
    accountNumber: str = Field(..., description="The bank account number of the biller.")
    accountName: str = Field(..., description="The name on the bank account of the biller.")
    bankCode: str = Field(..., description="The 3-digit bank sort/routing code of the biller's bank.")
    mandateStatusNotificationUrl: str = Field(..., description="The URL to receive mandate status notifications.")
    merchantId: str = Field(..., description="The ID of the merchant creating the biller.")
    

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)
    




class CreateProductRequest(BaseModel):
    
    """
    Request body for POST /api/DirectDebit/createProduct.
    """
    
    billerId: str = Field(..., description="The ID of the biller.")
    productName: str = Field(..., description="The name of the product.")
    merchantId: str = Field(..., gt=0, description="The ID of the merchant creating the product.")
    

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)
    
    



    
class CreateElectronicMandateRequest(BaseModel):
    
    """
    Request body for POST /api/DirectDebit/createElectronicMandate.
    """
    
    productId: str = Field(..., description="The ID of the product.")
    billerId: str = Field(..., description="The ID of the biller.")
    
    accountNumber: str = Field(..., description="The account number of the customer")
    bankCode: str = Field(..., description="The 3-digit bank sort/routing code of the customer's bank.")
    payerName: str = Field(..., description="The name of the customer.")
    payerAddress: str = Field(..., description="The address of the customer.")
    accountName: str = Field(..., description="The name on the customer's bank account.")
    
    amount: float = Field(..., gt=0, description="Amount to debit per collection cycle.")
    narration: str | None = Field(default=None, description="Optional narration for the mandate.")
    phoneNumber: str = Field(..., description="The phone number of the customer.")
    subscriberCode: str | None = Field(default=None, description="Optional subscriber code for the mandate.")
    startDate: str = Field(..., description="Date the mandate becomes active.")
    endDate: str | None = Field(default=None, description="Optional mandate expiry date.")
    payerEmail: str | None = Field(default=None, description="Payer email address.")
    merchantId: str = Field(..., description="The ID of the merchant creating the mandate.")

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)
    
    
    
    
class NameInquiryRequest(BaseModel):
    
    """
    Request body for POST /api/DirectDebit/name-inquiry.
    """
    
    accountNumber: str = Field(..., description="The account number to look up")
    channelCode: int = Field(..., description="Numeric code identifying the channel through which the inquiry is initiated")
    destinationInstitutionCode: str = Field(..., description="Numeric code identifying the destination financial institution")
    transactionId: str = Field(..., description="Unique transaction reference ID for tracking the inquiry request")

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)
    
    
    
{
  "sourceInstitutionCode": "string",
  "amount": 0,
  "beneficiaryAccountName": "string",
  "beneficiaryAccountNumber": "string",
  "beneficiaryBankVerificationNumber": "string",
  "beneficiaryKYCLevel": 0,
  "channelCode": 0,
  "originatorAccountName": "string",
  "originatorAccountNumber": "string",
  "originatorBankVerificationNumber": "string",
  "originatorKYCLevel": 0,
  "destinationInstitutionCode": "string",
  "mandateReferenceNumber": "string",
  "nameEnquiryRef": "string",
  "originatorNarration": "string",
  "paymentReference": "string",
  "transactionId": "string",
  "transactionLocation": "string",
  "beneficiaryNarration": "string",
  "billerId": "string",
  "initiatorAccountNumber": "string",
  "initiatorAccountName": "string"
}


class FundTransferRequest(BaseModel):
    
    """
    Request body for POST /api/DirectDebit/fund-transfer.
    """
    
    sourceInstitutionCode: str = Field(..., description="Numeric code identifying the source financial institution")
    amount: float = Field(..., gt=0, description="Amount to transfer")
    beneficiaryAccountName: str = Field(..., description="Name of the beneficiary's account")
    beneficiaryAccountNumber: str = Field(..., description="Account number of the beneficiary")
    beneficiaryBankVerificationNumber: str = Field(..., description="Bank verification number of the beneficiary")
    beneficiaryKYCLevel: int = Field(..., description="KYC level of the beneficiary (e.g., 0 for basic, 1 for enhanced)")
    channelCode: int = Field(..., description="Numeric code identifying the channel through which the transfer is initiated")
    originatorAccountName: str = Field(..., description="Name of the originator's account")
    originatorAccountNumber: str = Field(..., description="Account number of the originator")
    originatorBankVerificationNumber: str = Field(..., description="Bank verification number of the originator")
    originatorKYCLevel: int = Field(..., description="KYC level of the originator (e.g., 0 for basic, 1 for enhanced)")
    destinationInstitutionCode: str = Field(..., description="Numeric code identifying the destination financial institution")
    mandateReferenceNumber: str | None = Field(default=None, description="Mandate reference number for recurring transfers")
    nameEnquiryRef: str | None = Field(default=None, description="Reference for name enquiry associated with this transfer")
    originatorNarration: str | None = Field(default=None, description="Optional narration from the originator's perspective")
    paymentReference: str | None = Field(default=None, description="Payment reference for tracking purposes")
    transactionId: str = Field(..., description="Unique transaction reference ID for tracking the transfer request")
    transactionLocation: str | None = Field(default=None, description="Location where the transaction is initiated")
    beneficiaryNarration: str | None = Field(default=None, description="Narration from the beneficiary's perspective")
    billerId: str | None = Field(default=None, description="Optional biller ID if the transfer is associated with a bill payment")
    initiatorAccountNumber: str | None = Field(default=None, description="Initiator Account Number for the transfer")
    initiatorAccountName: str | None = Field(default=None, description="Initiator Account Name for the transfer")

    def to_api_dict(self) -> dict[str, Any]:
        """Serialises the request into the JSON shape the API expects."""
        return self.model_dump(mode="json", exclude_none=True)
    
    