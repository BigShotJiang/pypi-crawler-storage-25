"""
securepay-api — Python library for the SecurePay payment platform.

Quick start::

    from securepay import SecurePayApi, SecurePayConfig

    client = SecurePayApi(
        api_key="SP-PK-xxxx",
        config=SecurePayConfig.staging(enable_logging=True),
    )

    response = client.direct_debit.get_mandate("mnd_abc123")
    print(response.success)          # True
    print(response.message)          # "Mandate retrieved successfully"
    print(response.data.mandate_id)  # "mnd_abc123"
"""

from .api import SecurePayApi
from .core.config import SecurePayConfig
from .core.exceptions import (
    SecurePayConflictError,
    SecurePayException,
    SecurePayNetworkError,
    SecurePayNotFoundError,
    SecurePayRateLimitError,
    SecurePayServerError,
    SecurePayUnauthorizedError,
    SecurePayValidationError,
)
from .models.direct_debit import (
    BankAccount,
    CollectionListData,
    CreateMandateRequest,
    DebitCollectionData,
    DebitFrequency,
    DebitStatus,
    InitiateDebitRequest,
    ListCollectionsRequest,
    ListMandatesRequest,
    MandateData,
    MandateListData,
    MandateStatus,
    PatchMandateStatusRequest,
    SecurePayApiResponse,
    UpdateMandateRequest,
)

__version__ = "0.0.1"

__all__ = [
    # Main client
    "SecurePayApi",
    "SecurePayConfig",
    # Exceptions
    "SecurePayException",
    "SecurePayUnauthorizedError",
    "SecurePayValidationError",
    "SecurePayNotFoundError",
    "SecurePayConflictError",
    "SecurePayServerError",
    "SecurePayNetworkError",
    "SecurePayRateLimitError",
    # Response envelope
    "SecurePayApiResponse",
    # Direct Debit models
    "BankAccount",
    "CollectionListData",
    "CreateMandateRequest",
    "DebitCollectionData",
    "DebitFrequency",
    "DebitStatus",
    "InitiateDebitRequest",
    "ListCollectionsRequest",
    "ListMandatesRequest",
    "MandateData",
    "MandateListData",
    "MandateStatus",
    "PatchMandateStatusRequest",
    "UpdateMandateRequest",
]
