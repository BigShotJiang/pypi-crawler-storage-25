"""
Main entry point for the SecurePay Python library.

Instantiate SecurePayApi once and access all service modules
through its named properties.

Example::

    from securepay import SecurePayApi, SecurePayConfig

    # Staging (development)
    client = SecurePayApi(
        api_key="SP-PK-xxxx",
        config=SecurePayConfig.staging(enable_logging=True),
    )

    # Production
    client = SecurePayApi(
        api_key="SP-PK-xxxx",
        config=SecurePayConfig.production(),
    )

    # Use as a context manager (auto-closes connection pool)
    with SecurePayApi(api_key="SP-PK-xxxx") as client:
        mandate = client.direct_debit.get_mandate("mnd_abc123")
"""

from typing import Any

from securepay.services.checkout import CheckoutService
from securepay.services.key_management import KeyManagementService
from securepay.services.transfer import TransferService

from .core.client import SecurePayClient
from .core.config import SecurePayConfig
from .services.direct_debit import DirectDebitService


class SecurePayApi:
    """
    The main facade for the SecurePay API Python library.

    Provides access to all SecurePay service modules through
    clearly named properties. Manages the underlying HTTP client
    lifecycle.

    Args:
        api_key:    Your SecurePay public API key (from the Developer Console).
        config:     Optional :class:`SecurePayConfig`. Defaults to staging.

    Available services:
        - :attr:`direct_debit` — mandate creation, updates, status patching,
          cancellation, and collection initiation.
    """

    def __init__(
        self,
        api_key: str,
        config: SecurePayConfig | None = None,
    ) -> None:
        self._client = SecurePayClient(
            api_key=api_key,
            config=config or SecurePayConfig(),
        )
        self._initialise_services()

    def _initialise_services(self) -> None:
        # Future services wired in here:
        self._key_management = KeyManagementService(self._client)
        self._transfers = TransferService(self._client)
        self._direct_debit = DirectDebitService(self._client)
        self._checkout = CheckoutService(self._client)
        
        # self._key_management = KeyManagementService(self._client)

    # Service Properties

    @property
    def direct_debit(self) -> DirectDebitService:
        """Access all Direct Debit mandate and collection endpoints."""
        return self._direct_debit

    @property
    def checkout(self) -> CheckoutService:
        """Access all Checkout endpoints."""
        return self._checkout

    @property
    def key_management(self) -> KeyManagementService:
        """Access all Key Management endpoints."""
        return self._key_management
    
    @property
    def transfers(self) -> TransferService:
        """Access all Transfer Service endpoints."""
        return self._transfers

    # Context Manager Support

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> "SecurePayApi":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
