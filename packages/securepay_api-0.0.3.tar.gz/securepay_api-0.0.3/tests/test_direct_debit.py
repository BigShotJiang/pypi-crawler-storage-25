"""
Tests for DirectDebitService.

Uses pytest-httpx to mock HTTP responses so no real network calls are made.
"""

import pytest
from datetime import date, datetime
from pytest_httpx import HTTPXMock

from securepay import (
    BankAccount,
    CreateMandateRequest,
    DebitFrequency,
    InitiateDebitRequest,
    MandateStatus,
    SecurePayApi,
    SecurePayConfig,
    SecurePayUnauthorizedError,
    SecurePayValidationError,
    UpdateMandateRequest,
)

# ── Fixtures ───────────────────────────────────────────────────────────────────

BASE_URL = "https://securepay-staging-api.getsecurepay.ai"


@pytest.fixture
def client():
    return SecurePayApi(
        api_key="SP-PK-test-key",
        config=SecurePayConfig.staging(enable_logging=False, enable_retry=False),
    )


MANDATE_PAYLOAD = {
    "mandateId": "mnd_abc123",
    "customerName": "Ada Obi",
    "customerEmail": "ada@example.com",
    "customerPhone": "+2348012345678",
    "bankAccount": {
        "account_number": "0123456789",
        "bank_code": "058",
        "account_name": "Ada Obi",
    },
    "amount": 5000.0,
    "currency": "NGN",
    "frequency": "monthly",
    "status": "pending",
    "startDate": "2025-08-01",
    "endDate": None,
    "createdAt": "2025-06-01T10:00:00",
    "updatedAt": "2025-06-01T10:00:00",
}

MANDATE_RESPONSE = {"success": True, "statusCode": "OK", "message": "Success", "data": MANDATE_PAYLOAD}


# ── Tests ──────────────────────────────────────────────────────────────────────


def test_create_mandate(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE_URL}/api/direct-debit/mandates",
        json=MANDATE_RESPONSE,
        status_code=200,
    )

    mandate = client.direct_debit.create_mandate(
        CreateMandateRequest(
            customer_name="Ada Obi",
            customer_email="ada@example.com",
            customer_phone="+2348012345678",
            bank_account=BankAccount(
                account_number="0123456789",
                bank_code="058",
                account_name="Ada Obi",
            ),
            amount=5000.0,
            frequency=DebitFrequency.MONTHLY,
            start_date=date(2025, 8, 1),
        )
    )

    assert mandate.mandate_id == "mnd_abc123"
    assert mandate.customer_name == "Ada Obi"
    assert mandate.status == MandateStatus.PENDING


def test_get_mandate(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE_URL}/api/direct-debit/mandates/mnd_abc123",
        json=MANDATE_RESPONSE,
        status_code=200,
    )

    mandate = client.direct_debit.get_mandate("mnd_abc123")
    assert mandate.mandate_id == "mnd_abc123"
    assert mandate.amount == 5000.0


def test_update_mandate(client, httpx_mock: HTTPXMock):
    updated_payload = {**MANDATE_PAYLOAD, "amount": 7500.0}
    httpx_mock.add_response(
        method="PUT",
        url=f"{BASE_URL}/api/direct-debit/mandates/mnd_abc123",
        json={"success": True, "statusCode": "OK", "message": "Updated", "data": updated_payload},
        status_code=200,
    )

    updated = client.direct_debit.update_mandate(
        "mnd_abc123",
        UpdateMandateRequest(amount=7500.0),
    )
    assert updated.amount == 7500.0


def test_patch_mandate_status(client, httpx_mock: HTTPXMock):
    suspended_payload = {**MANDATE_PAYLOAD, "status": "suspended"}
    httpx_mock.add_response(
        method="PATCH",
        url=f"{BASE_URL}/api/direct-debit/mandates/mnd_abc123/status",
        json={"success": True, "statusCode": "OK", "message": "Status updated", "data": suspended_payload},
        status_code=200,
    )

    result = client.direct_debit.patch_mandate_status(
        "mnd_abc123",
        status=MandateStatus.SUSPENDED,
        reason="Customer request.",
    )
    assert result.status == MandateStatus.SUSPENDED


def test_cancel_mandate(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="DELETE",
        url=f"{BASE_URL}/api/direct-debit/mandates/mnd_abc123",
        json={"success": True, "statusCode": "OK", "message": "Mandate cancelled"},
        status_code=200,
    )

    result = client.direct_debit.cancel_mandate("mnd_abc123")
    assert result["success"] is True


def test_initiate_collection(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE_URL}/api/direct-debit/mandates/mnd_abc123/collect",
        json={
            "success": True,
            "statusCode": "OK",
            "message": "Collection initiated",
            "data": {
                "collectionId": "col_xyz789",
                "mandateId": "mnd_abc123",
                "amount": 5000.0,
                "currency": "NGN",
                "status": "pending",
                "createdAt": "2025-06-01T10:00:00",
            },
        },
        status_code=200,
    )

    collection = client.direct_debit.initiate_collection(
        "mnd_abc123",
        InitiateDebitRequest(amount=5000.0, narration="June payment"),
    )

    assert collection.collection_id == "col_xyz789"
    assert collection.amount == 5000.0


def test_unauthorized_raises_correct_exception(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="GET",
        url=f"{BASE_URL}/api/direct-debit/mandates/mnd_abc123",
        json={"success": False, "statusCode": "UNAUTHORIZED", "message": "Invalid API key"},
        status_code=401,
    )

    with pytest.raises(SecurePayUnauthorizedError):
        client.direct_debit.get_mandate("mnd_abc123")


def test_bad_request_raises_validation_error(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE_URL}/api/direct-debit/mandates",
        json={"success": False, "statusCode": "BAD_REQUEST", "message": "amount must be greater than 0"},
        status_code=400,
    )

    with pytest.raises(SecurePayValidationError) as exc_info:
        client.direct_debit.create_mandate(
            CreateMandateRequest(
                customer_name="Ada Obi",
                customer_email="ada@example.com",
                customer_phone="+2348012345678",
                bank_account=BankAccount(
                    account_number="0123456789",
                    bank_code="058",
                    account_name="Ada Obi",
                ),
                amount=0.01,  # Will pass Pydantic but be rejected server-side
                frequency=DebitFrequency.MONTHLY,
                start_date=date(2025, 8, 1),
            )
        )

    assert exc_info.value.status_code == 400
