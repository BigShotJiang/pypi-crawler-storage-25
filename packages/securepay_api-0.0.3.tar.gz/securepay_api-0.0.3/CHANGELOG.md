## 0.0.1 (2025-06-01)

- Initial release.
- Core HTTP client with auth headers, logging, and retry interceptors.
- `DirectDebitService` — full mandate and collection lifecycle (GET, POST, PUT, PATCH, DELETE).
- Typed Pydantic v2 request/response models.
- `SecurePayException` hierarchy for structured error handling.
