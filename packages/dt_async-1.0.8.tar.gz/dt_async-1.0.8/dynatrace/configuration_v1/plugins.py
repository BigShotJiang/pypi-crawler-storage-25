"""
Copyright 2021 Dynatrace LLC

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from httpx import Response

from dynatrace.configuration_v1.endpoint import EndpointShortRepresentation
from dynatrace.dynatrace_object import DynatraceObject
from dynatrace.environment_v2.monitored_entities import EntityShortRepresentation
from dynatrace.http_client import HttpClient
from dynatrace.pagination import PaginatedList


class PluginService:
    def __init__(self, http_client: HttpClient):
        self.__http_client = http_client

    async def list(self) -> PaginatedList["PluginShortRepresentation"]:
        """
        List all uploaded plugins
        """
        return await PaginatedList(
            PluginShortRepresentation,
            self.__http_client,
            "/api/config/v1/plugins",
            list_item="values",
        ).initialize()

    async def list_states(self, plugin_id) -> PaginatedList["PluginState"]:
        """
        List the states of the specified plugin
        """
        return await PaginatedList(
            PluginState,
            self.__http_client,
            f"/api/config/v1/plugins/{plugin_id}/states",
            list_item="states",
        ).initialize()

    async def delete(self, plugin_id) -> Response:
        """
        Deletes the ZIP file of the specified plugin
        :param plugin_id: The ID of the plugin to be deleted
        """
        return await self.__http_client.make_request(
            f"/api/config/v1/plugins/{plugin_id}/binary", method="DELETE"
        )


class PluginState(DynatraceObject):
    def _create_from_raw_data(self, raw_element):
        self.plugin_id: str = raw_element.get("pluginId")
        self.version: str = raw_element.get("version")
        self.endpoint_id: str = raw_element.get("endpointId")
        self.state: str = raw_element.get("state")
        self.state_description: str = raw_element.get("stateDescription")
        self.timestamp: str = raw_element.get("timestamp")
        self.host_id: str = raw_element.get("hostId")
        self.process_id: str = raw_element.get("processId")


class PluginShortRepresentation(EntityShortRepresentation):
    async def delete(self) -> Response:
        """
        Deletes the ZIP file of this plugin
        """
        return await self._http_client.make_request(
            f"/api/config/v1/plugins/{self.id}/binary", method="DELETE"
        )

    @property
    def endpoints(self) -> PaginatedList[EndpointShortRepresentation]:
        return PaginatedList(
            EndpointShortRepresentation,
            self._http_client,
            f"/api/config/v1/plugins/{self.id}/endpoints",
            None,
            list_item="values",
        )

    @property
    def states(self) -> PaginatedList[PluginState]:
        return PaginatedList(
            PluginState,
            self._http_client,
            f"/api/config/v1/plugins/{self.id}/states",
            None,
            list_item="states",
        )
