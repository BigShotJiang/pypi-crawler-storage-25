use serde_json::Number;
use thiserror::Error;

#[derive(Debug, Error, serde::Serialize)]
pub enum PolicyEngineError {
    #[error(
        "Mismatched value type in {source_tag} at path {path}. Expected {expected}, got {actual}."
    )]
    MismatchedValueAtPath {
        source_tag: String,
        path: String, // todo: Add Original path here (state#path) for better visibility. https://linear.app/friskai/issue/POL-19/custom-error-messages-for-deny-actions
        expected: String, // Expected type
        actual: String, // Actual type
    },

    #[error(
        "Could not find the expected value to compare against in the given {source_tag} at path {path}."
    )]
    MissingExpectedValueAtPath {
        source_tag: String, // Source name
        path: String,       // Path string
    },

    #[error("Could not find value to inspect in the given {source_tag} at path {path}.")]
    MissingActualValueAtPath {
        source_tag: String, // Source name
        path: String,       // Path string
    },

    #[error("Mismatched value. Expected {required_type}, got {source_type}.")]
    ComparisonError {
        required_type: String, // Expected type
        source_type: String,   // Actual type
    },

    #[error("Failed to convert value {value} to a float")]
    FloatCoercionError { value: Number },

    #[error("Failed to parse regex {value}")]
    InvalidRegexError { value: String },
}

#[derive(Debug, Error, serde::Serialize)]
pub enum TelemetryError {
    #[error("An error occurred while trying to serialize telemetry field {field}.")]
    TelemetryFieldSerializationError { field: String },
}
