from __future__ import annotations

from typing import Any, cast

import pytest

from frisk_sdk.core.tool_call_span import ToolCallSpan
from frisk_sdk.framework_adapter.base_framework_adapter import BaseFrameworkAdapter
from frisk_sdk.framework_adapter.framework_adapter import NormalizedToolCall
from frisk_sdk.telemetry.constants import (
    ATTRIBUTE_NAME_FRISK_TOOL_ID,
    ATTRIBUTE_NAME_FRISK_TOOL_VERSION_ID,
)
from opentelemetry.sdk.trace import TracerProvider


@pytest.mark.unit
def test_tool_call_span_sets_tool_id_and_version_id_attributes() -> None:
    provider = TracerProvider()
    tracer = provider.get_tracer("test-tracer")

    span_cm = ToolCallSpan(
        session_id="session-1",
        framework_adapter=BaseFrameworkAdapter(),
        tool_call=NormalizedToolCall(
            id="call-1",
            name="send_email",
            args={},
        ),
        frisk_tool_id="tool-123",
        frisk_tool_version_id="tool-version-456",
        agent_state={},
        parent_span=None,
        tracer=tracer,
        options=None,
    )

    with span_cm as entered:
        assert entered.span is not None
        attrs: dict[str, Any] = dict(cast(Any, entered.span).attributes)

        assert attrs[ATTRIBUTE_NAME_FRISK_TOOL_ID] == "tool-123"
        assert attrs[ATTRIBUTE_NAME_FRISK_TOOL_VERSION_ID] == "tool-version-456"
