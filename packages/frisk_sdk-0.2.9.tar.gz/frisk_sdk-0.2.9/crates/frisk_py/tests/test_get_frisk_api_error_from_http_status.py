from frisk_sdk.errors.api_response_errors.get_frisk_api_error_from_http_status import (
    get_frisk_api_error_from_http_status,
)
from frisk_sdk.errors.api_response_errors import (
    FriskBadRequestError,
    FriskInvalidAPIKeyError,
    FriskForbiddenError,
    FriskBaseURLNotFoundError,
    FriskConflictError,
    FriskPayloadTooLargeError,
    FriskUnprocessableEntityError,
    FriskRateLimitError,
    FriskInternalServerError,
    FriskBadGatewayError,
    FriskServiceUnavailableError,
    FriskGatewayTimeoutError,
    FriskGenericAPIResponseError,
)


def test_status_code_to_error_class():
    cases = [
        (400, FriskBadRequestError),
        (401, FriskInvalidAPIKeyError),
        (403, FriskForbiddenError),
        (404, FriskBaseURLNotFoundError),
        (409, FriskConflictError),
        (413, FriskPayloadTooLargeError),
        (422, FriskUnprocessableEntityError),
        (429, FriskRateLimitError),
        (500, FriskInternalServerError),
        (502, FriskBadGatewayError),
        (503, FriskServiceUnavailableError),
        (504, FriskGatewayTimeoutError),
    ]
    for code, exc in cases:
        err = get_frisk_api_error_from_http_status(code)
        assert isinstance(err, exc)


def test_generic_error_for_unexpected_status():
    err = get_frisk_api_error_from_http_status(418, details="teapot!")
    assert isinstance(err, FriskGenericAPIResponseError)
    assert err.status_code == 418
    assert err.error_details == "teapot!"


def test_generic_error_details_none():
    err = get_frisk_api_error_from_http_status(499)
    assert isinstance(err, FriskGenericAPIResponseError)
    assert err.status_code == 499
    assert err.error_details is None
