import pytest


@pytest.fixture
def frisk_strands_instance(monkeypatch: pytest.MonkeyPatch):
    from frisk_sdk.adapters.strands.frisk_strands import FriskStrands

    def _noop_init(self, *args, **kwargs):
        self.logger_name = "frisk.test"
        self._tracer = object()

    monkeypatch.setattr(FriskStrands, "__init__", _noop_init)
    return FriskStrands(api_key="k")


@pytest.mark.unit
def test_frisk_strands_is_constructible(frisk_strands_instance):
    assert frisk_strands_instance.logger_name == "frisk.test"
    assert frisk_strands_instance._tracer is not None


@pytest.mark.unit
def test_tool_hook_returns_frisk_tool_hook(frisk_strands_instance):
    from frisk_sdk.adapters.strands.frisk_tool_hook import FriskStrandsToolHook

    hook = frisk_strands_instance.tool_hook()
    assert isinstance(hook, FriskStrandsToolHook)
    assert hook._frisk_handle is frisk_strands_instance
