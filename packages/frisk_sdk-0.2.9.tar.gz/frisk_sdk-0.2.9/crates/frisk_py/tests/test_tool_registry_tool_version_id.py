from __future__ import annotations

import pytest

from frisk_sdk.core.tool_registry import _parse_register_tools_response


@pytest.mark.unit
def test_parse_register_tools_response_includes_version_id() -> None:
    response = [
        {
            "id": "tool-1",
            "name": "send_email",
            "versionId": "tool-version-1",
        }
    ]

    parsed = _parse_register_tools_response(response)

    assert parsed == {
        "send_email": {
            "id": "tool-1",
            "name": "send_email",
            "versionId": "tool-version-1",
        }
    }
