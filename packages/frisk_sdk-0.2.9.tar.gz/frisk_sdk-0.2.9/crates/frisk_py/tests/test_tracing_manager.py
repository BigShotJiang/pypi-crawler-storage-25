from __future__ import annotations

from frisk_sdk.telemetry.tracing_manager import TracingManager, TracingManagerOptions


def test_tracing_manager_normalizes_v1_traces_path():
    opts = TracingManagerOptions(
        otlp_endpoint="http://localhost:4317/v1/traces",
        auth_token="t0",
        tracer_name="frisk_py_test",
        tracer_version="0.0.0",
    )

    mgr = TracingManager(
        otlp_endpoint=opts.otlp_endpoint,
        auth_token=opts.auth_token,
        tracer_name=opts.tracer_name,
        tracer_version=opts.tracer_version,
    )
    try:
        # The manager preserves the input endpoint; normalization returns a gRPC target.
        assert mgr.otlp_endpoint.endswith("/v1/traces")
        assert TracingManager._normalize_otel_grpc_endpoint(mgr.otlp_endpoint) == (
            "http://localhost:4317"
        )
    finally:
        mgr.shutdown()


def test_tracing_manager_updates_token_and_returns_tracer():
    opts = TracingManagerOptions(
        otlp_endpoint="http://localhost:4317",
        auth_token="t0",
        tracer_name="frisk_py_test",
        tracer_version="0.0.0",
    )

    mgr = TracingManager(
        otlp_endpoint=opts.otlp_endpoint,
        auth_token=opts.auth_token,
        tracer_name=opts.tracer_name,
        tracer_version=opts.tracer_version,
    )
    try:
        tracer = mgr.get_tracer()
        assert tracer is not None

        mgr.update_auth_token("t1")
        assert mgr.auth_token == "t1"
    finally:
        mgr.shutdown()
