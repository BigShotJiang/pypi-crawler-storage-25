from urllib.parse import urlparse


def is_secure_url(url: str) -> bool:
    """Return ``True`` if the URL uses HTTPS."""
    return urlparse(url).scheme == "https"
