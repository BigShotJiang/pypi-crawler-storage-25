import logging
from typing import Optional, TypedDict


class LoggingOptions(TypedDict, total=False):
    logger: Optional[logging.Logger]
    logger_name: Optional[str]
