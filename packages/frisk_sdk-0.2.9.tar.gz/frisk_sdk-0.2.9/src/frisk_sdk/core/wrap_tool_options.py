from typing import TypedDict, Optional


class WrapToolOptions(TypedDict, total=False):
    collect_reasoning: Optional[bool]
