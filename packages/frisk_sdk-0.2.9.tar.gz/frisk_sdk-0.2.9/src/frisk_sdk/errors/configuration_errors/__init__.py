from frisk_sdk.errors import FriskError as FriskError


class FriskConfigurationError(FriskError):
    """Raised when the SDK is misconfigured."""


class MissingAPIKeyError(FriskConfigurationError):
    """Raised when no Frisk API key is configured for SDK initialization."""

    code = "missing_api_key"
    message = """\
Frisk API key not configured.
    You must provide an API key either:
        • via the `api_key` argument: Frisk(api_key="...")
        • or via the environment variable FRISK_API_KEY
    Example:
        export FRISK_API_KEY="..."
        frisk = Frisk()\
"""


class MissingBaseURLError(FriskConfigurationError):
    """Raised when no Frisk API base URL is configured."""

    code = "missing_base_url"
    message = """\
Frisk base URL not configured.
    You must provide a Frisk base URL either:
        • via the environment variable FRISK_BASE_URL
        • or by explicitly passing `api_base_url` when initializing Frisk

    Example:
        export FRISK_BASE_URL="https://api.frisk.ai"
        frisk = Frisk()\
"""


class MissingOtlpEndpointError(FriskConfigurationError):
    """Raised when telemetry endpoint configuration is missing."""

    code = "missing_otlp_endpoint"
    message = """\
Frisk telemetry endpoint not configured.
    Frisk requires a telemetry endpoint to send agent activity,
    policy decisions, and execution traces.

    You must provide the telemetry endpoint via:
        • the FRISK_TELEMETRY_ENDPOINT environment variable

    Example:
        export FRISK_TELEMETRY_ENDPOINT="https://telemetry.frisk.ai"
        frisk = Frisk()\
"""


class TokenRuntimeConfigurationConflictError(FriskConfigurationError):
    """Raised when token runtime is initialized with conflicting settings."""

    code = "token_runtime_configuration_conflict"
    message = """\
        Frisk runtime already initialized with a different configuration.
            The Frisk SDK manages authentication and token lifecycle internally
            and should not be initialized directly.
    
            Please create and interact with Frisk using the Frisk() class
            for all API operations.
    
            If this occurs during testing, call:
                reset_token_runtime_for_testing()\
        """
