# KyberShield Python SDK

Official Python SDK for the [KyberShield AI Security Gateway](https://kybershield.ai).

## Installation

```bash
pip install kybershield
```

With LangChain extras:
```bash
pip install "kybershield[langchain]"
```

## Quick Start

```python
from kybershield import KyberShield, BlockedError, KyberShieldError

ks = KyberShield(agent_key="ks_your_key_here")

try:
    result = ks.query("SELECT * FROM customers LIMIT 10")
    print(result.verdict)           # 'allowed'
    print(result.risk_score)        # 5
    print(result.quantum_signature) # 'ML-DSA-87:...'
    print(result.data)              # rows from your database
except BlockedError as e:
    print(f"Blocked: {e.result.reason} (risk: {e.result.risk_score})")
except KyberShieldError as e:
    print(f"Gateway error: {e} (status: {e.status_code})")

# Health check
healthy = ks.ping()
print(f"Gateway healthy: {healthy}")
```

## Context Manager

```python
with KyberShield(agent_key="ks_your_key") as ks:
    result = ks.query("SELECT 1")
    print(result.verdict)
```

## Environment Variables

```bash
export KYBERSHIELD_AGENT_KEY=ks_your_key_here
export KYBERSHIELD_GATEWAY_URL=https://app.kybershield.ai
```

```python
# No key needed — reads from environment
ks = KyberShield()
```

## Links

- [Documentation](https://kybershield.ai/docs)
- [Gateway Dashboard](https://app.kybershield.ai)
- [Support](mailto:security@kybershield.ai)
