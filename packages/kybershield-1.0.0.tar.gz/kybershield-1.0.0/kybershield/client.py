"""KyberShield Python SDK client."""

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import requests


@dataclass
class QueryResult:
    verdict: str
    query_id: str
    risk_score: int
    reason: str
    quantum_signature: Optional[str] = None
    threats: List[str] = field(default_factory=list)
    data: List[Dict[str, Any]] = field(default_factory=list)
    rows_returned: Optional[int] = None
    rows_affected: Optional[int] = None
    timestamp: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "QueryResult":
        return cls(
            verdict=d.get("verdict", ""),
            query_id=d.get("queryId", ""),
            risk_score=d.get("riskScore", 0),
            reason=d.get("reason", ""),
            quantum_signature=d.get("quantumSignature"),
            threats=d.get("threats", []),
            data=d.get("data", []),
            rows_returned=d.get("rowsReturned"),
            rows_affected=d.get("rowsAffected"),
            timestamp=d.get("timestamp"),
        )


class KyberShieldError(Exception):
    """Raised for network errors, timeouts, or unexpected gateway responses."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class BlockedError(Exception):
    """Raised when the gateway blocks a query due to a security policy."""

    def __init__(self, message: str, result: QueryResult):
        super().__init__(message)
        self.verdict = "blocked"
        self.result = result


class KyberShield:
    """
    KyberShield AI Security Gateway client.

    Usage::

        from kybershield import KyberShield, BlockedError

        ks = KyberShield(agent_key="ks_your_key")
        result = ks.query("SELECT * FROM customers LIMIT 10")
        print(result.verdict, result.risk_score)

    Context manager::

        with KyberShield(agent_key="ks_your_key") as ks:
            result = ks.query("SELECT 1")
    """

    DEFAULT_GATEWAY_URL = "https://app.kybershield.ai"

    def __init__(
        self,
        agent_key: Optional[str] = None,
        gateway_url: Optional[str] = None,
        timeout: int = 30,
    ):
        self.agent_key = agent_key or os.environ.get("KYBERSHIELD_AGENT_KEY", "")
        self.gateway_url = (
            gateway_url or os.environ.get("KYBERSHIELD_GATEWAY_URL", self.DEFAULT_GATEWAY_URL)
        ).rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Content-Type": "application/json",
                "X-Agent-Key": self.agent_key,
            }
        )

        if not self.agent_key:
            raise KyberShieldError(
                "agent_key is required. Pass it as an argument or set the "
                "KYBERSHIELD_AGENT_KEY environment variable."
            )

    def query(self, sql: str, params: Optional[List[Any]] = None) -> QueryResult:
        """
        Submit a SQL query through the KyberShield security gateway.

        :param sql: The SQL query string.
        :param params: Optional list of query parameters.
        :returns: QueryResult with verdict, risk score, and data.
        :raises BlockedError: If the query is blocked by a security policy.
        :raises KyberShieldError: For network errors or unexpected responses.
        """
        payload: Dict[str, Any] = {"query": sql}
        if params is not None:
            payload["params"] = params

        try:
            resp = self._session.post(
                f"{self.gateway_url}/api/gateway/query",
                json=payload,
                timeout=self.timeout,
            )
        except requests.Timeout:
            raise KyberShieldError(f"Request timed out after {self.timeout}s")
        except requests.ConnectionError as e:
            raise KyberShieldError(f"Network error: {e}")

        if resp.status_code == 401:
            raise KyberShieldError("Invalid or expired API key", status_code=401)

        if resp.status_code not in (200,):
            raise KyberShieldError(
                f"Gateway returned HTTP {resp.status_code}", status_code=resp.status_code
            )

        try:
            data = resp.json()
        except ValueError as e:
            raise KyberShieldError(f"Invalid JSON response from gateway: {e}")

        result = QueryResult.from_dict(data)

        if result.verdict == "blocked":
            raise BlockedError(result.reason or "Query blocked by security policy", result)

        return result

    def ping(self) -> bool:
        """Check if the gateway is healthy. Returns True if healthy."""
        try:
            resp = self._session.get(
                f"{self.gateway_url}/api/gateway/health",
                timeout=5,
            )
            data = resp.json()
            return data.get("status") == "healthy"
        except Exception:
            return False

    def __enter__(self) -> "KyberShield":
        return self

    def __exit__(self, *args: Any) -> None:
        self._session.close()

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()
