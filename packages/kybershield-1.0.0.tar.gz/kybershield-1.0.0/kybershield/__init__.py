"""KyberShield Python SDK — Official client for the KyberShield AI Security Gateway."""

from .client import KyberShield, QueryResult, KyberShieldError, BlockedError

__version__ = "1.0.0"
__all__ = ["KyberShield", "QueryResult", "KyberShieldError", "BlockedError"]
