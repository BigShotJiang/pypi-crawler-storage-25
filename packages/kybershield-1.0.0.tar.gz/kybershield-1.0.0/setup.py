from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="kybershield",
    version="1.0.0",
    author="KyberShield",
    author_email="security@kybershield.ai",
    description="Official Python SDK for KyberShield AI Security Gateway",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://kybershield.ai",
    project_urls={
        "Documentation": "https://kybershield.ai/docs",
        "Source": "https://github.com/kybershield/sdk-python",
    },
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["requests>=2.28.0"],
    extras_require={
        "langchain": ["langchain>=0.1.0"],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries",
    ],
    keywords="kybershield security ai gateway post-quantum sql proxy",
)
