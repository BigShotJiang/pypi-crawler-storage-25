"""Simple event data classes for the hexDAG event system."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass(slots=True)
class Event:
    """Base class for all events - provides timestamp."""

    timestamp: datetime = field(default_factory=datetime.now, init=False)

    def log_message(self) -> str:
        """Get a formatted log message for this event.

        Override in subclasses to provide custom formatting.

        Returns
        -------
        str
            A formatted string suitable for logging
        """
        return f"{self.__class__.__name__} at {self.timestamp.isoformat()}"


# Node events
@dataclass(slots=True)
class NodeStarted(Event):
    """A node has started execution."""

    name: str
    wave_index: int
    dependencies: tuple[str, ...] | list[str] = field(default_factory=tuple)

    def log_message(self) -> str:
        """Format log message for node start event.

        Returns
        -------
        str
            Formatted log message for node start
        """
        deps = f" (deps: {', '.join(self.dependencies)})" if self.dependencies else ""
        return f"🚀 Node '{self.name}' started in wave {self.wave_index}{deps}"


@dataclass(slots=True)
class NodeCompleted(Event):
    """A node has completed successfully."""

    name: str
    wave_index: int
    result: Any
    duration_ms: float

    def log_message(self) -> str:
        """Format log message for node completion event.

        Returns
        -------
        str
            Formatted log message for node completion
        """
        return f"✅ Node '{self.name}' completed in {self.duration_ms / 1000:.2f}s"


@dataclass(slots=True)
class NodeFailed(Event):
    """A node has failed."""

    name: str
    wave_index: int
    error: Exception

    def log_message(self) -> str:
        """Format log message for node failure event.

        Returns
        -------
        str
            Formatted log message for node failure
        """
        return f"❌ Node '{self.name}' failed: {self.error}"


@dataclass(slots=True)
class NodeCancelled(Event):
    """A node execution was cancelled.

    Attributes
    ----------
    name : str
        Node name
    wave_index : int
        Wave index where node was executing
    reason : str | None
        Reason for cancellation (e.g., "timeout", "user_cancel")
    """

    name: str
    wave_index: int
    reason: str | None = None

    def log_message(self) -> str:
        """Format log message for node cancellation event."""
        return f"🚫 Node '{self.name}' cancelled: {self.reason or 'unknown'}"


@dataclass(slots=True)
class NodeSkipped(Event):
    """A node execution was skipped due to when clause evaluation.

    Attributes
    ----------
    name : str
        Node name
    wave_index : int
        Wave index where node was scheduled
    reason : str | None
        Reason for skipping (e.g., "when clause 'status == active' evaluated to False")
    """

    name: str
    wave_index: int
    reason: str | None = None

    def log_message(self) -> str:
        """Format log message for node skip event."""
        return f"⏭️ Node '{self.name}' skipped: {self.reason or 'unknown'}"


# Wave events (WaveStarted absorbed into WaveCompleted)
@dataclass(slots=True)
class WaveCompleted(Event):
    """A wave has completed.

    Attributes
    ----------
    wave_index : int
        Index of the completed wave
    duration_ms : float
        Duration of the wave in milliseconds
    nodes : list[str]
        Node names that were part of this wave
    """

    wave_index: int
    duration_ms: float
    nodes: list[str] = field(default_factory=list)

    def log_message(self) -> str:
        """Format log message for wave completion event.

        Returns
        -------
        str
            Formatted log message for wave completion
        """
        node_info = f" ({len(self.nodes)} nodes)" if self.nodes else ""
        return f"✅ Wave {self.wave_index} completed in {self.duration_ms / 1000:.2f}s{node_info}"


# Pipeline events (PipelineCancelled absorbed into PipelineCompleted)
@dataclass(slots=True)
class PipelineStarted(Event):
    """Pipeline execution has started."""

    name: str
    total_waves: int
    total_nodes: int

    def log_message(self) -> str:
        """Format log message for pipeline start event.

        Returns
        -------
        str
            Formatted log message for pipeline start
        """
        return (
            f"🎬 Pipeline '{self.name}' started "
            f"({self.total_nodes} nodes, {self.total_waves} waves)"
        )


@dataclass(slots=True)
class PipelineCompleted(Event):
    """Pipeline has completed (successfully, cancelled, or failed).

    Attributes
    ----------
    name : str
        Pipeline name
    duration_ms : float
        Total pipeline duration in milliseconds
    node_results : dict[str, Any]
        Results from completed nodes
    status : str
        Completion status: "completed", "cancelled", or "failed"
    reason : str | None
        Reason for cancellation/failure (None when completed successfully)
    """

    name: str
    duration_ms: float
    node_results: dict[str, Any] = field(default_factory=dict)
    status: str = "completed"
    reason: str | None = None

    def log_message(self) -> str:
        """Format log message for pipeline completion event.

        Returns
        -------
        str
            Formatted log message for pipeline completion
        """
        if self.status == "cancelled":
            completed_nodes = len(self.node_results)
            return (
                f"🛑 Pipeline '{self.name}' cancelled after {self.duration_ms / 1000:.2f}s "
                f"({completed_nodes} nodes completed): {self.reason or 'unknown'}"
            )
        return f"🎉 Pipeline '{self.name}' completed in {self.duration_ms / 1000:.2f}s"


# Body events (CompositeNode inline/pipeline body execution)
@dataclass(slots=True)
class BodyStarted(Event):
    """A CompositeNode body has started execution.

    Attributes
    ----------
    parent_node : str
        Name of the CompositeNode that owns this body
    body_name : str
        Identifier for the body: filename for body_pipeline,
        "inline" for body lists, "inline[N]" for loop iterations
    total_nodes : int
        Number of nodes in the body (0 if unknown)
    """

    parent_node: str
    body_name: str
    total_nodes: int = 0

    def log_message(self) -> str:
        """Format log message for body start event."""
        return f"▶ Body '{self.body_name}' started (parent: {self.parent_node})"


@dataclass(slots=True)
class BodyCompleted(Event):
    """A CompositeNode body has completed successfully.

    Attributes
    ----------
    parent_node : str
        Name of the CompositeNode that owns this body
    body_name : str
        Identifier for the body
    duration_ms : float
        Duration in milliseconds
    status : str
        "completed" or "failed"
    """

    parent_node: str
    body_name: str
    duration_ms: float
    status: str = "completed"

    def log_message(self) -> str:
        """Format log message for body completion event."""
        return (
            f"✓ Body '{self.body_name}' {self.status} in "
            f"{self.duration_ms / 1000:.2f}s (parent: {self.parent_node})"
        )


@dataclass(slots=True)
class BodyFailed(Event):
    """A CompositeNode body has failed.

    Emitted before the CompositeNode's error_handling strategy runs.

    Attributes
    ----------
    parent_node : str
        Name of the CompositeNode that owns this body
    body_name : str
        Identifier for the body
    error : str
        Error message
    """

    parent_node: str
    body_name: str
    error: str

    def log_message(self) -> str:
        """Format log message for body failure event."""
        return f"✗ Body '{self.body_name}' failed (parent: {self.parent_node}): {self.error}"


# System events (kind: System multi-process orchestration)
@dataclass(slots=True)
class SystemStarted(Event):
    """A system has started execution.

    Attributes
    ----------
    name : str
        System name from metadata
    total_processes : int
        Number of processes in the system
    execution_order : list[str]
        Topological execution order of process names
    """

    name: str
    total_processes: int
    execution_order: list[str] = field(default_factory=list)

    def log_message(self) -> str:
        """Format log message for system start event."""
        return f"System '{self.name}' started ({self.total_processes} processes)"


@dataclass(slots=True)
class ProcessStarted(Event):
    """A process within a system has started.

    Attributes
    ----------
    system_name : str
        Parent system name
    process_name : str
        Name of the process starting
    index : int
        Position in execution order (0-based)
    """

    system_name: str
    process_name: str
    index: int

    def log_message(self) -> str:
        """Format log message for process start event."""
        return f"Process '{self.process_name}' started (step {self.index + 1})"


@dataclass(slots=True)
class ProcessCompleted(Event):
    """A process within a system has completed.

    Attributes
    ----------
    system_name : str
        Parent system name
    process_name : str
        Name of the completed process
    index : int
        Position in execution order (0-based)
    duration_ms : float
        Process duration in milliseconds
    status : str
        "completed" or "failed"
    error : str | None
        Error message if failed
    """

    system_name: str
    process_name: str
    index: int
    duration_ms: float
    status: str = "completed"
    error: str | None = None

    def log_message(self) -> str:
        """Format log message for process completion event."""
        if self.status == "failed":
            return (
                f"Process '{self.process_name}' failed after "
                f"{self.duration_ms / 1000:.2f}s: {self.error}"
            )
        return f"Process '{self.process_name}' completed in {self.duration_ms / 1000:.2f}s"


@dataclass(slots=True)
class SystemCompleted(Event):
    """A system has completed execution.

    Attributes
    ----------
    name : str
        System name
    duration_ms : float
        Total system duration in milliseconds
    process_results : dict[str, Any]
        Results keyed by process name
    status : str
        "completed" or "failed"
    reason : str | None
        Failure reason if applicable
    """

    name: str
    duration_ms: float
    process_results: dict[str, Any] = field(default_factory=dict)
    status: str = "completed"
    reason: str | None = None

    def log_message(self) -> str:
        """Format log message for system completion event."""
        if self.status == "failed":
            return (
                f"System '{self.name}' failed after {self.duration_ms / 1000:.2f}s: {self.reason}"
            )
        return (
            f"System '{self.name}' completed in {self.duration_ms / 1000:.2f}s "
            f"({len(self.process_results)} processes)"
        )


# ---------------------------------------------------------------------------
# Entity state transition events
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TransitionContext:
    """Context for an entity state transition.

    Carries metadata about where and why the transition happened — used by
    transition handlers and observers for audit, persistence, and side effects.
    """

    run_id: str
    pipeline_name: str
    node_name: str


@dataclass(slots=True)
class StateTransitionEvent(Event):
    """An entity has transitioned to a new state.

    Emitted automatically by ``EntityState.atransition()`` whenever an observer
    manager is available in the execution context.  Observers receive this as a
    fire-and-forget notification (best-effort).

    Attributes
    ----------
    entity_type : str
        Entity kind (e.g. ``"ticket"``, ``"load"``, ``"order"``).
    entity_id : str
        Unique identifier for the entity instance.
    from_state : str
        State the entity was in before the transition.
    to_state : str
        State the entity moved to.
    reason : str | None
        Optional human-readable reason for the transition.
    node_name : str
        Name of the node or tool call that triggered the transition.
    """

    entity_type: str
    entity_id: str
    from_state: str
    to_state: str
    reason: str | None = None
    node_name: str = ""

    def log_message(self) -> str:
        """Format log message for state transition event."""
        reason_info = f" ({self.reason})" if self.reason else ""
        return (
            f"🔄 {self.entity_type}:{self.entity_id} "
            f"{self.from_state} → {self.to_state}{reason_info}"
        )


@dataclass(slots=True)
class EntityGarbageCollected(Event):
    """An entity has been garbage-collected after reaching a terminal state.

    Emitted when all obligations (hooks, pipelines) have been verified complete
    and in-memory state is cleaned up.

    Attributes
    ----------
    entity_type : str
        Entity kind.
    entity_id : str
        Unique identifier for the entity instance.
    final_state : str
        Terminal state the entity was in when collected.
    lifetime_ms : float
        Time from entity registration to GC in milliseconds.
    transition_count : int
        Total number of transitions during this entity's lifecycle.
    """

    entity_type: str
    entity_id: str
    final_state: str
    lifetime_ms: float
    transition_count: int

    def log_message(self) -> str:
        """Format log message for entity garbage collection event."""
        return (
            f"♻️ {self.entity_type}:{self.entity_id} collected "
            f"(state={self.final_state}, transitions={self.transition_count}, "
            f"lifetime={self.lifetime_ms / 1000:.1f}s)"
        )


@dataclass(slots=True)
class EntityObligationFailed(Event):
    """An obligation for an entity transition failed.

    Attributes
    ----------
    entity_type : str
        Entity kind.
    entity_id : str
        Unique identifier for the entity instance.
    state : str
        State the entity was in when the obligation failed.
    obligation : str
        What failed: ``"handler"``, ``"pipeline"``, ``"child_pipeline"``.
    pipeline_run_id : str | None
        Run ID of the failed pipeline, if applicable.
    error : str | None
        Error description.
    """

    entity_type: str
    entity_id: str
    state: str
    obligation: str
    pipeline_run_id: str | None = None
    error: str | None = None

    def log_message(self) -> str:
        """Format log message for entity obligation failure event."""
        return (
            f"⚠️ {self.entity_type}:{self.entity_id} obligation failed: "
            f"{self.obligation} in state {self.state}"
        )


@dataclass(slots=True)
class EntityCompensationEvent(Event):
    """A saga compensation was executed after a pipeline failure.

    Attributes
    ----------
    entity_type : str
        Entity kind.
    entity_id : str
        Unique identifier for the entity instance.
    failed_state : str
        State the entity was transitioning TO when failure occurred.
    reverted_to : str
        State the entity reverted back to.
    steps_compensated : int
        Number of forward steps that were compensated.
    compensation_errors : list[str]
        Errors from compensation steps that also failed (empty if all OK).
    """

    entity_type: str
    entity_id: str
    failed_state: str
    reverted_to: str
    steps_compensated: int
    compensation_errors: list[str] = field(default_factory=list)

    def log_message(self) -> str:
        """Format log message for entity compensation event."""
        errors = ""
        if self.compensation_errors:
            errors = f" ({len(self.compensation_errors)} compensation errors)"
        return (
            f"↩️ {self.entity_type}:{self.entity_id} "
            f"reverted {self.failed_state} → {self.reverted_to} "
            f"({self.steps_compensated} steps compensated){errors}"
        )


# ---------------------------------------------------------------------------
# Port call events — universal base for all port/adapter method calls
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class PortCallEvent(Event):
    """Base event for all port/adapter method calls.

    Provides a universal base that observers can use to catch *any* port call
    via ``isinstance(event, PortCallEvent)``.  Typed subtypes (``LLMPortCall``,
    ``ToolRouterPortCall``, etc.) add port-specific fields.

    Attributes
    ----------
    port_type : str
        Port category: ``"llm"``, ``"tool_router"``, ``"data_store"``, etc.
    method : str
        Method name that was called: ``"aresponse"``, ``"acall_tool"``, etc.
    node_name : str
        Name of the DAG node that triggered this call.
    duration_ms : float
        Wall-clock duration of the call in milliseconds.
    """

    port_type: str
    method: str
    node_name: str
    duration_ms: float = 0.0

    def log_message(self) -> str:
        """Format log message for port call event."""
        return f"⚡ {self.port_type}.{self.method} ({self.node_name}, {self.duration_ms:.1f}ms)"
