"""Execution coordinator for observer notifications and input mapping.

This module provides execution coordination functionality:

- Observer notifications during execution
- Input preparation and dependency mapping
- Input mapping transformation (including $input syntax)
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from hexdag.kernel.ports.observer_manager import ObserverManager
else:
    ObserverManager = Any

from hexdag.kernel.domain.dag import NodeSpec
from hexdag.kernel.expression_parser import (
    ALLOWED_FUNCTIONS,
    MISSING,
    ExpressionError,
    evaluate_expression,
)
from hexdag.kernel.logging import get_logger
from hexdag.stdlib.nodes.mapped_input import FieldExtractor

__all__ = ["ExecutionCoordinator"]

logger = get_logger(__name__)


def _parse_default_value(raw: str) -> Any:
    """Parse a default value from ``| default(X)`` modifier syntax.

    Handles: ``None``, integers, floats, booleans, and quoted strings.
    Unquoted strings are returned as-is.
    """
    if raw == "None":
        return None
    if raw in ("True", "true"):
        return True
    if raw in ("False", "false"):
        return False
    # Strip quotes from string literals
    if (raw.startswith("'") and raw.endswith("'")) or (raw.startswith('"') and raw.endswith('"')):
        return raw[1:-1]
    # Try numeric
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    return raw


class ExecutionCoordinator:
    """Coordinates execution context: observer notifications and input mapping.

    This component handles two responsibilities:

    1. **Observer Notifications**: Notifying observers of events during DAG execution.

    2. **Input Mapping**: Preparing input data for nodes based on their dependencies.
       Uses a smart mapping strategy:
       - No dependencies → initial input
       - Single dependency → pass through that result
       - Multiple dependencies → dict of results

    Examples
    --------
    Basic usage::

        coordinator = ExecutionCoordinator()

        # Notify observer of an event
        await coordinator.notify_observer(observer_manager, NodeStarted(...))

        # Prepare input for a node
        input_data = coordinator.prepare_node_input(
            node_spec, node_results, initial_input
        )
    """

    # ========================================================================
    # Observer Notifications (from PolicyCoordinator)
    # ========================================================================

    async def notify_observer(self, observer_manager: ObserverManager | None, event: Any) -> None:
        """Notify observer manager of an event if it exists.

        Parameters
        ----------
        observer_manager : ObserverManager | None
            Observer manager to notify (None if no observer configured)
        event : Any
            Event to send (typically NodeStarted, NodeCompleted, etc.)

        Examples
        --------
        >>> from hexdag.kernel.orchestration.events import NodeStarted
        >>> event = NodeStarted(name="my_node", wave_index=0)
        >>> await coordinator.notify_observer(observer_manager, event)  # doctest: +SKIP
        """
        if observer_manager:
            await observer_manager.notify(event)

    # ========================================================================
    # Input Mapping
    # ========================================================================

    def prepare_node_input(
        self, node_spec: NodeSpec, node_results: dict[str, Any], initial_input: Any
    ) -> Any:
        """Prepare input data for node execution with simplified data mapping.

        The mapping strategy is:
        1. **No dependencies** → initial_input (entry point)
        2. **Single dependency** → results[dependency_name] (pass-through)
        3. **Multiple dependencies** → {dep1: result1, dep2: result2, ...} (namespace)

        This approach balances simplicity (pass-through for single deps) with
        clarity (named dict for multiple deps).

        Parameters
        ----------
        node_spec : NodeSpec
            Node specification containing dependencies
        node_results : dict[str, Any]
            Results from previously executed nodes
        initial_input : Any
            Initial input data for the pipeline

        Returns
        -------
        Any
            Prepared input data for the node:
            - initial_input if no dependencies
            - dependency result if single dependency
            - dict of dependency results if multiple dependencies

        Examples
        --------
        >>> coordinator = ExecutionCoordinator()
        >>>
        >>> # No dependencies - gets initial input
        >>> # start_input = coordinator.prepare_node_input(
        >>> #     NodeSpec("start", lambda x: x.upper()),
        >>> #     node_results={},
        >>> #     initial_input="hello"
        >>> # )
        >>> # start_input == "hello"
        >>>
        >>> # Single dependency - gets that result directly
        >>> # process_input = coordinator.prepare_node_input(
        >>> #     NodeSpec("process", lambda x: x + "!", deps={"start"}),
        >>> #     node_results={"start": "HELLO"},
        >>> #     initial_input="hello"
        >>> # )
        >>> # process_input == "HELLO"

        Notes
        -----
        The multi-dependency dict preserves node names as keys, making it clear
        where each piece of data came from. This is especially useful for
        debugging and for nodes that need to treat different dependencies
        differently.

        If the node has an ``input_mapping`` in its params, the prepared input
        will be transformed according to the mapping. This supports:
        - ``$input.field`` - Reference the initial pipeline input
        - ``node_name.field`` - Reference a specific dependency's output
        """
        # Propagate skip: if ALL dependencies were skipped, return skip marker
        # so downstream nodes are auto-skipped (no need for explicit when clause)
        if node_spec.deps:
            all_skipped = all(
                isinstance(node_results.get(dep), dict)
                and node_results.get(dep, {}).get("_skipped")
                for dep in node_spec.deps
            )
            if all_skipped:
                return {"_skipped": True, "_upstream_skipped": True}

        # Prepare base input from dependencies
        if not node_spec.deps:
            base_input = initial_input
        elif len(node_spec.deps) == 1:
            dep_name = next(iter(node_spec.deps))
            base_input = node_results.get(dep_name, initial_input)
        else:
            # Multiple dependencies - preserve namespace structure
            base_input = {}
            for dep_name in node_spec.deps:
                if dep_name in node_results:
                    base_input[dep_name] = node_results[dep_name]

        # Apply input_mapping if present in node params
        input_mapping = node_spec.params.get("input_mapping") if node_spec.params else None
        if input_mapping:
            return self._apply_input_mapping(base_input, input_mapping, initial_input, node_results)

        # Auto-wire: when a single-dep node has in_model and no explicit input_mapping,
        # extract only the fields whose names match the in_model from the upstream dict.
        if (
            not input_mapping
            and node_spec.in_model
            and len(node_spec.deps) == 1
            and isinstance(base_input, dict)
        ):
            expected_fields = set(node_spec.in_model.model_fields.keys())
            matching = expected_fields & base_input.keys()
            if matching:
                base_input = {k: base_input[k] for k in matching}

        return base_input

    def _is_expression(self, source: str) -> bool:
        """Check if a source string is an expression (contains function calls or operators).

        Parameters
        ----------
        source : str
            The source string to check

        Returns
        -------
        bool
            True if the source appears to be an expression
        """
        # Check for function call patterns (function_name followed by parenthesis)
        for func_name in ALLOWED_FUNCTIONS:
            if f"{func_name}(" in source:
                return True

        # Check for arithmetic/comparison operators (but not dots which are field paths)
        # Be careful not to match operators in simple field paths
        expression_indicators = [
            "==",
            "!=",
            "<=",
            ">=",
            " < ",
            " > ",
            " + ",
            " - ",
            " * ",
            " / ",
            " % ",
            " and ",
            " or ",
            " not ",
            " in ",
        ]
        return any(op in source for op in expression_indicators)

    def _resolve_mapping_value(
        self,
        source: Any,
        base_input: Any,
        initial_input: Any,
        node_results: dict[str, Any],
    ) -> Any:
        """Resolve a single input_mapping value.

        If *source* is a ``dict``, its values are resolved recursively so that
        nested structures like::

            input_mapping:
              ctx:
                ctx1: "node1.output"
                ctx2: "$input.field"

        produce ``{"ctx": {"ctx1": <resolved>, "ctx2": <resolved>}}``.

        If *source* is a ``list``, each element is resolved recursively.

        If *source* is a ``str``, it is resolved using the standard
        ``$input`` / ``node.field`` / expression syntax.

        Any other type is returned as-is.
        """
        if isinstance(source, dict):
            return {
                k: self._resolve_mapping_value(v, base_input, initial_input, node_results)
                for k, v in source.items()
            }

        if isinstance(source, list):
            return [
                self._resolve_mapping_value(item, base_input, initial_input, node_results)
                for item in source
            ]

        if not isinstance(source, str):
            return source

        # --- Safe path modifiers: | required, | default(X) ---
        modifier = None
        modifier_arg: Any = None
        if " | " in source:
            raw_source, raw_modifier = source.rsplit(" | ", 1)
            raw_modifier = raw_modifier.strip()
            if raw_modifier == "required":
                modifier = "required"
                source = raw_source.strip()
            elif raw_modifier.startswith("default(") and raw_modifier.endswith(")"):
                modifier = "default"
                source = raw_source.strip()
                raw_val = raw_modifier[8:-1].strip()
                # Parse the default value: handle None, numbers, booleans, strings
                modifier_arg = _parse_default_value(raw_val)

        # --- String resolution (existing logic) ---
        resolved = self._resolve_string_value(source, base_input, initial_input, node_results)

        # --- Apply modifier ---
        if modifier == "required" and resolved is None:
            msg = f"Required field resolved to None: '{source}'"
            raise ValueError(msg)
        if modifier == "default" and resolved is None:
            return modifier_arg
        return resolved

    def _resolve_string_value(
        self,
        source: str,
        base_input: Any,
        initial_input: Any,
        node_results: dict[str, Any],
    ) -> Any:
        """Resolve a string reference to its value (no modifiers)."""
        if self._is_expression(source):
            return self._evaluate_expression(source, base_input, initial_input, node_results)

        if source.startswith("$input."):
            actual_path = source[7:]  # Remove "$input." prefix
            if actual_path:
                if isinstance(initial_input, dict):
                    value = FieldExtractor.extract(initial_input, actual_path)
                    # Node ($input) is known — deep miss is None, not MISSING
                    return None if value is MISSING else value
                return FieldExtractor.extract({"_root": initial_input}, "_root")
            return initial_input

        if source == "$input":
            return initial_input

        if "." in source:
            parts = source.split(".", 1)
            node_name, field_path = parts[0], parts[1]
            if node_name in node_results:
                value = FieldExtractor.extract(node_results[node_name], field_path)
                # Node is known — deep miss is None, not MISSING
                return None if value is MISSING else value
            # Node name not found — propagate MISSING
            return FieldExtractor.extract(
                base_input if isinstance(base_input, dict) else {}, source
            )

        # Simple field name - extract from base_input
        return FieldExtractor.extract(base_input if isinstance(base_input, dict) else {}, source)

    def _apply_input_mapping(
        self,
        base_input: Any,
        input_mapping: dict[str, Any],
        initial_input: Any,
        node_results: dict[str, Any],
    ) -> dict[str, Any]:
        """Apply field mapping to transform input data.

        The result dict is **additive**: it starts with the full upstream
        node namespace (n8n-like), then overlays explicit mappings on top.
        This means nodes can reference upstream data directly in expressions
        (e.g., ``get_context.negotiation.counter_count``) without needing
        an explicit ``input_mapping`` entry for every field.

        Supports multiple syntaxes:
        - ``$input.field`` - Extract from the initial pipeline input
        - ``node_name.field`` - Extract from a specific node's output
        - Expression syntax - Use allowed functions and operators
        - Nested dicts - Values are resolved recursively

        Parameters
        ----------
        base_input : Any
            The prepared input from dependencies (may be single value or dict)
        input_mapping : dict[str, Any]
            Mapping of {target_field: source}. Source can be a string
            (``"source_path"`` or ``"expression"``), a nested dict whose
            leaf strings are resolved, or a list of resolvable values.
        initial_input : Any
            The original pipeline input (for $input references)
        node_results : dict[str, Any]
            Results from all previously executed nodes

        Returns
        -------
        dict[str, Any]
            Transformed input with upstream namespace + mapped fields

        Examples
        --------
        >>> coordinator = ExecutionCoordinator()
        >>> mapping = {"load_id": "$input.load_id", "result": "analyzer.output"}
        >>> # This would extract load_id from initial input and result from analyzer node

        Nested mapping example::

            mapping = {
                "ctx": {
                    "user_name": "$input.name",
                    "score": "analyzer.metadata.score",
                },
            }

        Expression examples::

            mapping = {
                "is_valid": "len(items) > 0",
                "name_upper": "upper(user.name)",
                "total": "price * quantity",
            }
        """
        # Start with full upstream node namespace (n8n-like: all upstream data available)
        result: dict[str, Any] = {}
        result.update(node_results)

        # Also expose initial input as "input"
        if isinstance(initial_input, dict):
            result["input"] = initial_input

        # Overlay explicit input_mapping aliases (win over upstream names)
        for target_field, source in input_mapping.items():
            value = self._resolve_mapping_value(source, base_input, initial_input, node_results)

            if value is MISSING:
                source_repr = source if isinstance(source, str) else repr(source)
                raise ValueError(
                    f"input_mapping: path '{source_repr}' does not exist "
                    f"(target field: '{target_field}'). "
                    f"Available node names: {sorted(node_results.keys())}"
                )

            if value is None:
                source_repr = source if isinstance(source, str) else repr(source)
                logger.warning(
                    "input_mapping: '{}' resolved to None for target '{}'",
                    source_repr,
                    target_field,
                )

            result[target_field] = value

        return result

    def _evaluate_expression(
        self,
        expression: str,
        base_input: Any,
        initial_input: Any,
        node_results: dict[str, Any],
    ) -> Any:
        """Evaluate an expression against available data.

        Parameters
        ----------
        expression : str
            The expression to evaluate (e.g., "len(items) > 0")
        base_input : Any
            The prepared input from dependencies
        initial_input : Any
            The original pipeline input
        node_results : dict[str, Any]
            Results from all previously executed nodes

        Returns
        -------
        Any
            The result of evaluating the expression
        """
        # Build the data context for expression evaluation
        # Merge all available data sources into a single dict
        data_context: dict[str, Any] = {}

        # Add node results
        data_context.update(node_results)

        # Add base_input (either as-is if dict, or wrapped)
        if isinstance(base_input, dict):
            data_context.update(base_input)
        elif base_input is not None:
            data_context["_input"] = base_input

        # Add initial input with $input prefix removed (accessible as 'input')
        if isinstance(initial_input, dict):
            data_context["input"] = initial_input
            # Also add initial_input fields at top level for convenience
            for key, val in initial_input.items():
                if key not in data_context:
                    data_context[key] = val
        elif initial_input is not None:
            data_context["input"] = initial_input

        try:
            # Use evaluate_expression to get the actual value, not a boolean
            return evaluate_expression(expression, data_context, {})
        except ExpressionError as e:
            logger.error("Expression evaluation failed for '{}': {}", expression, e)
            return None
        except Exception as e:
            logger.error("Unexpected error evaluating expression '{}': {}", expression, e)
            return None
