"""Orchestrator Factory - Creates orchestrator instances from pipeline configuration.

This factory bridges the gap between declarative YAML configuration and the
runtime orchestrator, instantiating adapters and policies from their specs.
"""

from typing import TYPE_CHECKING, Any

from hexdag.compiler.component_instantiator import ComponentInstantiator
from hexdag.kernel.domain.pipeline_config import PipelineConfig, _rebuild_pipeline_config
from hexdag.kernel.exceptions import CapDeniedError, ComponentInstantiationError
from hexdag.kernel.logging import get_logger
from hexdag.kernel.orchestration.orchestrator import Orchestrator
from hexdag.kernel.ports_builder import PortsBuilder
from hexdag.kernel.resolver import resolve

if TYPE_CHECKING:
    from hexdag.kernel.domain.caps import CapSet
    from hexdag.kernel.orchestration.components.lifecycle_manager import (
        HookConfig,
        PostDagHookConfig,
    )

logger = get_logger(__name__)

# Ensure PipelineConfig forward references are resolved.
_rebuild_pipeline_config()


class OrchestratorFactory:
    """Factory for creating orchestrator instances from pipeline configuration.

    This factory handles the complex task of:
    1. Instantiating adapter instances from port specs
    2. Instantiating policy instances from policy specs
    3. Wiring everything together into a configured orchestrator

    Examples
    --------
    ```python
    from hexdag.compiler.yaml_builder import YamlPipelineBuilder
    from hexdag.kernel.orchestration.orchestrator_factory import OrchestratorFactory

    # Parse YAML pipeline
    builder = YamlPipelineBuilder()
    graph, pipeline_config = builder.build_from_yaml_file("pipeline.yaml")

    factory = OrchestratorFactory()
    orchestrator = factory.create_orchestrator(pipeline_config)

    # Execute the pipeline
    result = await orchestrator.aexecute_dag(graph, initial_input={"query": "..."})
    ```
    """

    def __init__(self) -> None:
        """Initialize the orchestrator factory."""
        self.component_instantiator = ComponentInstantiator()
        self._pipeline_cap_set: CapSet | None = None

    def create_orchestrator(
        self,
        pipeline_config: PipelineConfig,
        max_concurrent_nodes: int = 10,
        strict_validation: bool = False,
        default_node_timeout: float | None = None,
        additional_ports: dict[str, Any] | None = None,
        pre_hook_config: "HookConfig | None" = None,
        post_hook_config: "PostDagHookConfig | None" = None,
    ) -> Orchestrator:
        """Create an orchestrator instance from pipeline configuration.

        Parameters
        ----------
        pipeline_config : PipelineConfig
            Pipeline configuration with ports, policies, and metadata
        max_concurrent_nodes : int, optional
            Maximum number of nodes to execute concurrently, by default 10
        strict_validation : bool, optional
            If True, raise errors on validation failure, by default False
        default_node_timeout : float | None, optional
            Default timeout in seconds for each node, by default None
        additional_ports : dict[str, Any] | None, optional
            Additional ports to merge with configured ports, by default None
        pre_hook_config : HookConfig | None, optional
            Configuration for pre-DAG hooks (health checks, secrets, etc.)
        post_hook_config : PostDagHookConfig | None, optional
            Configuration for post-DAG hooks (cleanup, checkpoints, etc.)

        Returns
        -------
        Orchestrator
            Configured orchestrator ready to execute pipelines

        Examples
        --------
        Basic usage with global ports::

            factory = OrchestratorFactory()

            orchestrator = factory.create_orchestrator(
                pipeline_config=config,
                max_concurrent_nodes=5,
                strict_validation=True,
                default_node_timeout=60.0,
            )

        Notes
        -----
        **Known Limitations (Phase 4)**:

        - **Type-specific ports** (``type_ports`` in YAML): Parsed and validated
          but not yet used during execution. All nodes currently receive global ports.

        - **Node-level port overrides**: Not yet implemented. Requires orchestrator
          changes to resolve ports per-node at execution time.

        **Workaround for Advanced Port Configuration**:

        For type-specific or node-level port customization, use PortsBuilder
        programmatically::

            from hexdag.kernel.ports_builder import PortsBuilder

            builder = (
                PortsBuilder()
                .with_llm(MockLLM())  # Global default
                .for_type("agent", llm=OpenAIAdapter(model="gpt-4"))
                .for_node("researcher", llm=AnthropicAdapter(model="claude-3"))
            )

            # Pass as additional_ports
            orchestrator = factory.create_orchestrator(
                pipeline_config,
                additional_ports=builder.build()
            )

        These features are planned for future implementation when orchestrator
        supports per-node port resolution.
        """
        logger.info(
            "Creating orchestrator from pipeline config: {} ports, {} type_ports, {} policies",
            len(pipeline_config.ports),
            len(pipeline_config.type_ports),
            len(pipeline_config.policies),
        )

        if any(spec.get("middleware") for spec in pipeline_config.ports.values()):
            logger.info("Middleware declared on ports — will apply user middleware stack")

        # Step 1: Build PortsConfiguration if type_ports or node_ports are configured
        use_ports_config = bool(pipeline_config.type_ports)

        if use_ports_config:
            ports_config = self._build_ports_configuration(pipeline_config, additional_ports)
            # Note: PortsConfiguration converts dicts to tuples for immutability
            global_ports = {k: v.port for k, v in (ports_config.global_ports or ())}
        else:
            # Simple case: just global ports
            ports_config = None
            global_ports = self._instantiate_ports(pipeline_config.ports)
            if additional_ports:
                global_ports.update(additional_ports)

        # Step 2: Extract middleware config from port specs
        middleware_config = self._extract_middleware_config(pipeline_config.ports)

        # Step 3: Create orchestrator with configured ports
        orchestrator = Orchestrator(
            max_concurrent_nodes=max_concurrent_nodes,
            ports=ports_config if ports_config else global_ports,
            strict_validation=strict_validation,
            default_node_timeout=default_node_timeout,
            pre_hook_config=pre_hook_config,
            post_hook_config=post_hook_config,
            middleware_config=middleware_config or None,
        )

        # Step 4: Instantiate services if configured
        services = self._instantiate_services(pipeline_config, global_ports)

        # Auto-register PipelineMemory (always available, like run_id)
        if "pipeline_memory" not in services:
            from hexdag.stdlib.lib.pipeline_memory import (
                PipelineMemory,  # lazy: arch boundary, optional default service
            )

            services["pipeline_memory"] = PipelineMemory()

        # Auto-register EntityState from spec.state_machines (if declared)
        if pipeline_config.state_machines and "entity_state" not in services:
            self._register_state_machines(pipeline_config.state_machines, services)

        # Register YAML-declared observers with the observer manager
        if pipeline_config.observers:
            self._register_observers(pipeline_config.observers, orchestrator)

        if services:
            # Store services in orchestrator's ports dict so they are accessible via context
            if isinstance(orchestrator.ports, dict):
                orchestrator.ports["_hexdag_services"] = services
            logger.info(
                "✅ {} services instantiated",
                len(services),
            )

        logger.info(
            "✅ Orchestrator created with {} ports",
            len(global_ports),
        )

        return orchestrator

    def _extract_middleware_config(
        self, port_specs: dict[str, dict[str, Any]]
    ) -> dict[str, list[str]]:
        """Extract middleware declarations from port specs.

        Looks for ``middleware`` key in each port spec and collects them
        into a map of port_name → list of middleware module paths.

        Supports three formats:
        - ``middleware: [path1, path2]`` — inline list of module paths
        - ``middleware: path`` — single module path (wrapped in list)
        - ``middleware: stack-name`` — reference to a ``kind: Middleware`` manifest

        Parameters
        ----------
        port_specs : dict[str, dict[str, Any]]
            Raw port specs from PipelineConfig

        Returns
        -------
        dict[str, list[str]]
            Map of port_name → middleware module paths (empty if none declared)
        """
        from hexdag.compiler.plugins.middleware_definition import (
            get_middleware_stack,  # lazy: optional compiler dep
        )

        config: dict[str, list[str]] = {}
        for port_name, port_spec in port_specs.items():
            middleware = port_spec.get("middleware")
            if middleware:
                if isinstance(middleware, list):
                    config[port_name] = middleware
                elif isinstance(middleware, str):
                    # Check if it's a named middleware stack (from kind: Middleware)
                    named_stack = get_middleware_stack(middleware)
                    if named_stack is not None:
                        config[port_name] = named_stack
                    else:
                        # Single middleware module path
                        config[port_name] = [middleware]
                else:
                    logger.warning(
                        "Invalid middleware config for port '{}': expected list or string, got {}",
                        port_name,
                        type(middleware).__name__,
                    )
        return config

    def _instantiate_ports(self, port_specs: dict[str, dict[str, Any]]) -> dict[str, Any]:
        """Instantiate adapter instances from port specifications.

        Parameters
        ----------
        port_specs : dict[str, dict[str, Any]]
            Map of port_name -> adapter dict spec

        Returns
        -------
        dict[str, Any]
            Map of port_name -> adapter_instance
        """
        ports = {}

        for port_name, port_spec in port_specs.items():
            try:
                # Resolve adapter ref if present
                if "ref" in port_spec:
                    port_spec = self._resolve_adapter_ref(port_name, port_spec)

                logger.debug("Instantiating port: {} = {}", port_name, port_spec)
                adapter = self.component_instantiator.instantiate_adapter(port_spec, port_name)
                ports[port_name] = adapter
                logger.debug("✅ Port instantiated: {}", port_name)
            except Exception as e:
                logger.error(
                    "Failed to instantiate port '{}' from spec '{}': {}",
                    port_name,
                    port_spec,
                    e,
                )
                raise

        return ports

    def _resolve_adapter_ref(self, port_name: str, port_spec: dict[str, Any]) -> dict[str, Any]:
        """Resolve a ``ref:`` adapter reference to a full port spec.

        Looks up the named adapter definition from the adapter registry
        and merges any inline config overrides on top of the base config.

        Parameters
        ----------
        port_name : str
            Port name (for error messages)
        port_spec : dict[str, Any]
            Port spec containing ``ref`` key and optional ``config`` overrides

        Returns
        -------
        dict[str, Any]
            Resolved port spec with ``adapter`` and ``config`` keys
        """
        from hexdag.compiler.plugins.adapter_definition import (  # lazy: compiler boundary
            get_adapter_definition,
        )

        ref_name = port_spec["ref"]
        adapter_def = get_adapter_definition(ref_name)

        if adapter_def is None:
            raise ComponentInstantiationError(
                f"Port '{port_name}': adapter ref '{ref_name}' not found. "
                f"Define it with 'kind: Adapter' in your YAML."
            )

        # Validate capability requirements if declared
        capabilities = adapter_def.get("capabilities")
        if capabilities and "requires" in capabilities:
            self._validate_adapter_caps(port_name, ref_name, capabilities["requires"])

        # Merge: ref config as base, inline overrides on top
        merged_config = {**adapter_def["config"], **port_spec.get("config", {})}
        return {"adapter": adapter_def["class"], "config": merged_config}

    def _validate_adapter_caps(
        self,
        port_name: str,
        adapter_ref: str,
        required_caps: list[str],
    ) -> None:
        """Validate that the pipeline's CapSet allows the adapter's required caps.

        Parameters
        ----------
        port_name : str
            Port name (for error messages)
        adapter_ref : str
            Adapter ref name (for error messages)
        required_caps : list[str]
            Capabilities the adapter declares as required
        """
        # If no pipeline-level caps are configured, all caps are allowed
        if self._pipeline_cap_set is None:
            return

        cap_set = self._pipeline_cap_set
        for cap in required_caps:
            if not cap_set.allows(cap):
                raise CapDeniedError(
                    f"port '{port_name}' adapter '{adapter_ref}' requires cap '{cap}'",
                    cap_set,
                )

    def _instantiate_services(
        self,
        pipeline_config: PipelineConfig,
        ports: dict[str, Any],
    ) -> dict[str, Any]:
        """Instantiate Service instances from pipeline configuration.

        Parameters
        ----------
        pipeline_config : PipelineConfig
            Pipeline configuration with services specs
        ports : dict[str, Any]
            Already-instantiated ports (for resolving port references in config)

        Returns
        -------
        dict[str, Any]
            Map of service_name -> Service instance
        """
        services: dict[str, Any] = {}

        for service_name, service_spec in pipeline_config.services.items():
            try:
                logger.debug("Instantiating service: {} = {}", service_name, service_spec)

                # Resolve port references in config values
                config = dict(service_spec.get("config", {}))
                for key, value in config.items():
                    if isinstance(value, str) and value in ports:
                        config[key] = ports[value]

                # Resolve the service class via kernel resolver
                class_path = service_spec.get("class", "")
                service_cls = resolve(class_path)
                service = service_cls(**config)

                services[service_name] = service
                logger.debug("✅ Service instantiated: {}", service_name)
            except Exception as e:
                logger.error(
                    "Failed to instantiate service '{}' from spec '{}': {}",
                    service_name,
                    service_spec,
                    e,
                )
                raise

        return services

    @staticmethod
    def _register_state_machines(
        state_machines: dict[str, dict[str, Any]],
        services: dict[str, Any],
    ) -> None:
        """Create an EntityState service from ``spec.state_machines`` definitions.

        Parses each state machine definition into a ``StateMachineConfig``,
        registers it on a new ``EntityState`` instance, and stores the
        instance as the ``entity_state`` service.

        Parameters
        ----------
        state_machines : dict[str, dict[str, Any]]
            Map of entity_type -> {initial: str, transitions: dict, handlers: dict}
        services : dict[str, Any]
            Services dict to register the EntityState into.
        """
        from hexdag.kernel.domain.entity_state import (
            StateMachineConfig,  # lazy: only needed when state machines declared
        )
        from hexdag.kernel.resolver import resolve  # lazy: only needed when state machines declared
        from hexdag.stdlib.lib.entity_state import (
            EntityState,  # lazy: arch boundary, only when state machines declared
        )

        entity_state = EntityState()

        for entity_type, sm_spec in state_machines.items():
            initial = sm_spec.get("initial", "")
            transitions_raw = sm_spec.get("transitions", {})

            # Build transitions dict: normalize both list and dict-with-guards formats
            transitions: dict[str, set[str]] = {}
            for from_state, targets in transitions_raw.items():
                if isinstance(targets, list):
                    # Simple list format: OPEN: [INVESTIGATING, CLOSED]
                    # Items can be strings or dicts with 'to' key
                    target_set: set[str] = set()
                    for t in targets:
                        if isinstance(t, str):
                            target_set.add(t)
                        elif isinstance(t, dict) and "to" in t:
                            target_set.add(t["to"])
                    transitions[from_state] = target_set
                elif isinstance(targets, set):
                    transitions[from_state] = targets

            # Compute all states from transitions
            all_states = set(transitions.keys())
            for target_set in transitions.values():
                all_states |= target_set
            if initial:
                all_states.add(initial)

            config = StateMachineConfig(
                entity_type=entity_type,
                states=all_states,
                initial_state=initial,
                transitions=transitions,
            )
            entity_state.register_machine(config)

            # Register transition handler if declared
            handlers = sm_spec.get("handlers", {})
            handler_path = handlers.get("on_transition")
            if handler_path:
                handler_cls = resolve(handler_path)
                # Instantiate if it's a class, use directly if callable
                handler = handler_cls() if isinstance(handler_cls, type) else handler_cls
                entity_state.register_handler(entity_type, handler)

            logger.debug(
                "✅ State machine registered: {} ({} states, {} transition rules)",
                entity_type,
                len(all_states),
                len(transitions),
            )

        services["entity_state"] = entity_state

    @staticmethod
    def _register_observers(
        observers_config: list[dict[str, Any]],
        orchestrator: Any,
    ) -> None:
        """Instantiate and register observers declared in ``spec.observers``.

        Parameters
        ----------
        observers_config : list[dict[str, Any]]
            List of observer specs: [{class: str, config: dict}]
        orchestrator : Orchestrator
            The orchestrator instance (to access observer_manager from ports).
        """
        observer_manager = (
            orchestrator.ports.get("observer_manager")
            if isinstance(orchestrator.ports, dict)
            else None
        )
        if observer_manager is None:
            logger.warning("No observer_manager available; skipping spec.observers")
            return

        for obs_spec in observers_config:
            try:
                class_path = obs_spec.get("class", "")
                config = dict(obs_spec.get("config", {}))

                obs_cls = resolve(class_path)
                observer = obs_cls(**config) if config else obs_cls()

                observer_manager.register(observer)
                logger.debug("✅ Observer registered: {}", class_path)
            except Exception as e:
                logger.error(
                    "Failed to register observer '{}': {}",
                    obs_spec.get("class", "?"),
                    e,
                )

    def _build_ports_configuration(
        self, pipeline_config: PipelineConfig, additional_ports: dict[str, Any] | None
    ) -> Any:
        """Build a PortsConfiguration from pipeline config.

        Parameters
        ----------
        pipeline_config : PipelineConfig
            Pipeline configuration with ports, type_ports
        additional_ports : dict[str, Any] | None
            Additional ports to merge

        Returns
        -------
        PortsConfiguration
            Hierarchical ports configuration with type-specific support
        """
        from hexdag.kernel.orchestration.models import (  # lazy: avoids module-level cycle
            PortConfig,
            PortsConfiguration,
        )

        # Step 1: Instantiate global ports
        global_ports_dict = self._instantiate_ports(pipeline_config.ports)
        if additional_ports:
            global_ports_dict.update(additional_ports)

        # Wrap in PortConfig
        global_ports = {k: PortConfig(port=v) for k, v in global_ports_dict.items()}

        # Step 2: Instantiate type-specific ports
        type_ports = None
        if pipeline_config.type_ports:
            type_ports = {}
            for node_type, type_port_specs in pipeline_config.type_ports.items():
                type_port_instances = self._instantiate_ports(type_port_specs)
                type_ports[node_type] = {
                    k: PortConfig(port=v) for k, v in type_port_instances.items()
                }
                logger.debug(
                    "Configured {} ports for node type '{}'",
                    len(type_port_instances),
                    node_type,
                )

        # Step 3: TODO: Add node-level port support when available in YAML builder

        return PortsConfiguration(
            global_ports=global_ports,
            type_ports=type_ports,
            node_ports=None,  # Not yet implemented
        )

    def create_ports_builder(self, pipeline_config: PipelineConfig) -> PortsBuilder:
        """Create a PortsBuilder from pipeline configuration (convenience method).

        This method provides an alternative workflow using PortsBuilder for
        advanced use cases that need type-specific or node-specific port overrides.

        Parameters
        ----------
        pipeline_config : PipelineConfig
            Pipeline configuration with ports

        Returns
        -------
        PortsBuilder
            Builder with ports configured from pipeline config

        Examples
        --------
        ```python
        factory = OrchestratorFactory()

        builder = factory.create_ports_builder(pipeline_config)

        # Optionally add node-specific overrides
        builder.for_node("researcher", llm=custom_llm)

        ports = builder.build()
        ```
        """
        ports = self._instantiate_ports(pipeline_config.ports)

        builder = PortsBuilder()
        for port_name, port_instance in ports.items():
            builder.with_custom(port_name, port_instance)

        return builder
