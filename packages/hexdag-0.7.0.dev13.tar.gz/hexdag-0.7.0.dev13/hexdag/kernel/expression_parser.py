"""Safe expression parser for YAML conditional expressions.

This module provides a secure way to compile string expressions like
`"node.action == 'ACCEPT'"` into callable predicates without using eval().

Uses Python's AST module with a strict whitelist approach:
- Only allows comparison operators: ==, !=, <, >, <=, >=
- Only allows boolean operators: and, or, not
- Only allows membership: in, not in
- Only allows attribute access and subscript for data extraction
- Only allows whitelisted function calls (see ALLOWED_FUNCTIONS)

Examples
--------
Basic usage::

    from hexdag.kernel.expression_parser import compile_expression

    # Compile expression to predicate
    pred = compile_expression("action == 'ACCEPT'")
    result = pred({"action": "ACCEPT"}, {})  # True

    # Nested attribute access
    pred = compile_expression("node.response.status == 'success'")
    result = pred({"node": {"response": {"status": "success"}}}, {})  # True

    # Boolean operators
    pred = compile_expression("count > 5 and active == True")
    result = pred({"count": 10, "active": True}, {})  # True

    # State access
    pred = compile_expression("state.iteration < 10")
    result = pred({}, {"iteration": 5})  # True

    # Membership test
    pred = compile_expression("status in ['pending', 'active']")
    result = pred({"status": "active"}, {})  # True

    # Built-in functions
    pred = compile_expression("len(items) > 0")
    result = pred({"items": [1, 2, 3]}, {})  # True

    pred = compile_expression("upper(name) == 'JOHN'")
    result = pred({"name": "john"}, {})  # True
"""

import ast
import operator
from collections.abc import Callable, Iterator
from datetime import UTC, datetime
from decimal import Decimal
from functools import lru_cache
from typing import Any

from hexdag.kernel.exceptions import ExpressionError  # noqa: F401
from hexdag.kernel.logging import get_logger

__all__ = [
    "compile_expression",
    "evaluate_expression",
    "ExpressionError",
    "ALLOWED_FUNCTIONS",
    "MISSING",
]


class _MissingSentinel:
    """Sentinel indicating a path's first segment was not found in data.

    Distinguishes "the root name doesn't exist" (typo / missing node)
    from "a deeper field is None" (optional data).  Returned only when
    the **first** path segment cannot be resolved.
    """

    _instance: "_MissingSentinel | None" = None

    def __new__(cls) -> "_MissingSentinel":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "<MISSING>"

    def __bool__(self) -> bool:
        return False


MISSING = _MissingSentinel()

logger = get_logger(__name__)


# Allowed comparison operators
_COMPARE_OPS: dict[type[ast.cmpop], Callable[[Any, Any], bool]] = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda x, y: x in y,
    ast.NotIn: lambda x, y: x not in y,
    ast.Is: operator.is_,
    ast.IsNot: operator.is_not,
}

# Allowed boolean operators
_BOOL_OPS: dict[type[ast.boolop], Callable[..., bool]] = {
    ast.And: lambda *args: all(args),
    ast.Or: lambda *args: any(args),
}

# Allowed unary operators (return Any since they can be bool or numeric)
_UNARY_OPS: dict[type[ast.unaryop], Callable[..., Any]] = {
    ast.Not: operator.not_,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

# Safe built-in functions allowed in expressions
# These are carefully selected to avoid side effects and security risks
ALLOWED_FUNCTIONS: dict[str, Callable[..., Any]] = {
    # Date/time functions
    "now": lambda: datetime.now(),
    "utcnow": lambda: datetime.now(UTC),
    "timestamp": lambda dt: dt.timestamp() if isinstance(dt, datetime) else float(dt),
    # Type conversion functions
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    # Math functions
    "abs": abs,
    "round": round,
    "min": min,
    "max": max,
    "sum": sum,
    # Collection functions
    "len": len,
    "all": all,
    "any": any,
    "sorted": sorted,
    "reversed": lambda x: list(reversed(x)),
    "list": list,
    "set": set,
    "dict": dict,
    "tuple": tuple,
    # String operations (wrapped to handle non-strings gracefully)
    "lower": lambda s: s.lower() if isinstance(s, str) else str(s).lower(),
    "upper": lambda s: s.upper() if isinstance(s, str) else str(s).upper(),
    "strip": lambda s: s.strip() if isinstance(s, str) else str(s).strip(),
    "lstrip": lambda s: s.lstrip() if isinstance(s, str) else str(s).lstrip(),
    "rstrip": lambda s: s.rstrip() if isinstance(s, str) else str(s).rstrip(),
    "split": lambda s, sep=None: s.split(sep) if isinstance(s, str) else [s],
    "join": lambda sep, items: sep.join(str(i) for i in items),
    "replace": lambda s, old, new: s.replace(old, new) if isinstance(s, str) else s,
    "startswith": lambda s, prefix: s.startswith(prefix) if isinstance(s, str) else False,
    "endswith": lambda s, suffix: s.endswith(suffix) if isinstance(s, str) else False,
    "contains": lambda s, sub: sub in s if isinstance(s, str) else False,
    # Conditional/utility functions
    "default": lambda val, default: val if val is not None and val is not MISSING else default,
    "coalesce": lambda *args: next((a for a in args if a is not None and a is not MISSING), None),
    "isnone": lambda x: x is None or x is MISSING,
    "isempty": lambda x: x is None or x is MISSING or x == "" or x == [] or x == {},
    # Financial/precision math functions
    "Decimal": Decimal,
    "pow": pow,
    "format": format,
    # Sequence generation
    "range": lambda *args: range(*args),
    "zip": lambda *iterables: list(zip(*iterables, strict=False)),
}


def _get_function_name(func_node: ast.AST) -> str | None:
    """Extract function name from a Call node's func attribute.

    Parameters
    ----------
    func_node : ast.AST
        The func attribute of an ast.Call node

    Returns
    -------
    str | None
        Function name if it's a simple Name node, None otherwise
    """
    if isinstance(func_node, ast.Name):
        return func_node.id
    return None


def _validate_ast(node: ast.AST, expression: str) -> None:
    """Validate that an AST node only contains allowed operations.

    Parameters
    ----------
    node : ast.AST
        The AST node to validate
    expression : str
        Original expression for error messages

    Raises
    ------
    ExpressionError
        If the AST contains disallowed operations
    """
    allowed_types = (
        ast.Expression,
        ast.Compare,
        ast.BoolOp,
        ast.UnaryOp,
        ast.BinOp,
        ast.IfExp,  # Ternary conditional: a if condition else b
        ast.Attribute,
        ast.Subscript,
        ast.Name,
        ast.Constant,
        ast.Load,
        ast.Index,  # Python 3.8 compatibility
        ast.Slice,
        ast.Tuple,
        ast.List,
        ast.Dict,
        ast.Call,  # Now allowed for whitelisted functions
        ast.keyword,  # For keyword arguments in function calls
        # Comprehensions
        ast.ListComp,  # [x for x in items if x]
        ast.SetComp,  # {x for x in items}
        ast.DictComp,  # {k: v for k, v in items}
        ast.comprehension,  # The for-clause inside comprehensions
        ast.Store,  # Comprehension targets use Store context
        # Comparison operators
        ast.Eq,
        ast.NotEq,
        ast.Lt,
        ast.LtE,
        ast.Gt,
        ast.GtE,
        ast.In,
        ast.NotIn,
        ast.Is,
        ast.IsNot,
        # Boolean operators
        ast.And,
        ast.Or,
        ast.Not,
        # Unary operators
        ast.USub,
        ast.UAdd,
        # Binary operators (for arithmetic if needed)
        ast.Add,
        ast.Sub,
        ast.Mult,
        ast.Div,
        ast.Mod,
    )

    # Check this node
    if not isinstance(node, allowed_types):
        raise ExpressionError(expression, f"Disallowed expression type: {type(node).__name__}")

    # Check for function calls - only allow whitelisted functions
    if isinstance(node, ast.Call):
        func_name = _get_function_name(node.func)
        if func_name is None:
            raise ExpressionError(
                expression,
                "Only simple function calls are allowed (e.g., 'len(x)', not 'obj.method()')",
            )
        if func_name not in ALLOWED_FUNCTIONS:
            allowed_list = ", ".join(sorted(ALLOWED_FUNCTIONS.keys()))
            raise ExpressionError(
                expression,
                f"Function '{func_name}' is not allowed. Allowed functions: {allowed_list}",
            )

    # Recursively check all child nodes
    for child in ast.iter_child_nodes(node):
        _validate_ast(child, expression)


def _get_value(data: dict[str, Any], state: dict[str, Any], path: list[str]) -> Any:
    """Extract value from data or state using a path.

    Returns :data:`MISSING` when the **first** path segment is not found
    in *data* (or *state*).  This lets callers distinguish a genuine typo
    (the root name doesn't exist at all) from a deeper field that is
    legitimately ``None``.

    For deeper segments (index >= 1), a missing key still returns ``None``
    because the upstream node *was* found — the field is simply absent or
    optional.

    Parameters
    ----------
    data : dict
        Primary data dict (node outputs)
    state : dict
        Secondary state dict (loop state, etc.)
    path : list[str]
        Path components like ["node", "action"]

    Returns
    -------
    Any
        Extracted value, ``None`` for missing deep fields, or
        :data:`MISSING` if the first segment doesn't exist.
    """
    if not path:
        return None

    # Check if first component refers to "state"
    if path[0] == "state":
        current: Any = state
        path = path[1:]
    else:
        current = data

    for idx, key in enumerate(path):
        if current is None:
            return None
        if isinstance(current, dict):
            if key not in current:
                # First segment missing → MISSING (likely a typo)
                # Deeper segment missing → None (optional field)
                return MISSING if idx == 0 else None
            current = current[key]
        elif hasattr(current, key):
            current = getattr(current, key)
        else:
            return MISSING if idx == 0 else None

    return current


# Allowed binary operators (hoisted from inline dict)
_BINOP_MAP: dict[type[ast.operator], Callable[[Any, Any], Any]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
}


# --- Individual AST node handlers ---


def _eval_constant(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    return node.value  # type: ignore[attr-defined]


def _eval_name(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.Name = node  # type: ignore[assignment]
    if n.id == "True":
        return True
    if n.id == "False":
        return False
    if n.id == "None":
        return None
    if n.id == "state":
        return state
    if n.id in data:
        return data[n.id]
    return MISSING


def _eval_attribute(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    path = _collect_attribute_path(node)  # type: ignore[arg-type]
    return _get_value(data, state, path)


def _eval_subscript(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.Subscript = node  # type: ignore[assignment]
    value = _evaluate_node(n.value, data, state)
    if isinstance(n.slice, ast.Index):  # Python 3.8 compat
        key = _evaluate_node(n.slice.value, data, state)  # type: ignore[attr-defined]
    else:
        key = _evaluate_node(n.slice, data, state)
    if value is None:
        return None
    if isinstance(value, dict):
        return value.get(key)
    if isinstance(value, (list, tuple)) and isinstance(key, int):
        return value[key] if 0 <= key < len(value) else None
    return None


def _eval_compare(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.Compare = node  # type: ignore[assignment]
    left = _evaluate_node(n.left, data, state)
    result = True
    for op, comparator in zip(n.ops, n.comparators, strict=False):
        right = _evaluate_node(comparator, data, state)
        op_func = _COMPARE_OPS.get(type(op))
        if op_func is None:
            raise ExpressionError("", f"Unsupported comparison: {type(op).__name__}")
        try:
            result = result and op_func(left, right)
        except TypeError:
            return False
        left = right
    return result


def _eval_boolop(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.BoolOp = node  # type: ignore[assignment]
    values = [_evaluate_node(v, data, state) for v in n.values]
    op_func = _BOOL_OPS.get(type(n.op))
    if op_func is None:
        raise ExpressionError("", f"Unsupported boolean op: {type(n.op).__name__}")
    return op_func(*values)


def _eval_unaryop(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.UnaryOp = node  # type: ignore[assignment]
    operand = _evaluate_node(n.operand, data, state)
    op_func = _UNARY_OPS.get(type(n.op))
    if op_func is None:
        raise ExpressionError("", f"Unsupported unary op: {type(n.op).__name__}")
    return op_func(operand)


def _eval_ifexp(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.IfExp = node  # type: ignore[assignment]
    if _evaluate_node(n.test, data, state):
        return _evaluate_node(n.body, data, state)
    return _evaluate_node(n.orelse, data, state)


def _eval_list(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> list[Any]:
    return [_evaluate_node(elt, data, state) for elt in node.elts]  # type: ignore[attr-defined]


def _eval_tuple(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> tuple[Any, ...]:
    elts = node.elts  # type: ignore[attr-defined]
    return tuple(_evaluate_node(elt, data, state) for elt in elts)


def _eval_dict(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> dict[Any, Any]:
    n: ast.Dict = node  # type: ignore[assignment]
    keys = [_evaluate_node(k, data, state) if k else None for k in n.keys]
    values = [_evaluate_node(v, data, state) for v in n.values]
    return dict(zip(keys, values, strict=False))


def _eval_binop(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.BinOp = node  # type: ignore[assignment]
    left = _evaluate_node(n.left, data, state)
    right = _evaluate_node(n.right, data, state)
    op_func = _BINOP_MAP.get(type(n.op))
    if op_func is None:
        raise ExpressionError("", f"Unsupported binary op: {type(n.op).__name__}")
    return op_func(left, right)


def _eval_call(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    n: ast.Call = node  # type: ignore[assignment]
    func_name = _get_function_name(n.func)
    if func_name is None or func_name not in ALLOWED_FUNCTIONS:
        raise ExpressionError("", f"Unknown or disallowed function: {func_name}")

    func = ALLOWED_FUNCTIONS[func_name]
    args = [_evaluate_node(arg, data, state) for arg in n.args]
    kwargs = {}
    for kw in n.keywords:
        if kw.arg is not None:
            kwargs[kw.arg] = _evaluate_node(kw.value, data, state)

    try:
        return func(*args, **kwargs)
    except Exception as e:
        raise ExpressionError("", f"Error calling {func_name}: {e}") from e


# --- Comprehension helpers ---


def _bind_target(target: ast.AST, value: Any, data: dict[str, Any]) -> None:
    """Bind a comprehension target (simple name or tuple unpacking)."""
    if isinstance(target, ast.Name):
        data[target.id] = value
    elif isinstance(target, ast.Tuple):
        for t, v in zip(target.elts, value, strict=False):
            _bind_target(t, v, data)


def _iter_comprehension(
    generators: list[ast.comprehension],
    data: dict[str, Any],
    state: dict[str, Any],
) -> Iterator[dict[str, Any]]:
    """Iterate over comprehension generators, yielding updated data dicts."""
    if not generators:
        yield data
        return

    gen = generators[0]
    remaining = generators[1:]
    iterable = _evaluate_node(gen.iter, data, state)

    for item in iterable:
        item_data = {**data}
        _bind_target(gen.target, item, item_data)

        if all(_evaluate_node(if_clause, item_data, state) for if_clause in gen.ifs):
            yield from _iter_comprehension(remaining, item_data, state)


def _eval_listcomp(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> list[Any]:
    n: ast.ListComp = node  # type: ignore[assignment]
    return [_evaluate_node(n.elt, d, state) for d in _iter_comprehension(n.generators, data, state)]


def _eval_setcomp(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> set[Any]:
    n: ast.SetComp = node  # type: ignore[assignment]
    return {_evaluate_node(n.elt, d, state) for d in _iter_comprehension(n.generators, data, state)}


def _eval_dictcomp(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> dict[Any, Any]:
    n: ast.DictComp = node  # type: ignore[assignment]
    return {
        _evaluate_node(n.key, item_data, state): _evaluate_node(n.value, item_data, state)
        for item_data in _iter_comprehension(n.generators, data, state)
    }


# Dispatch table mapping AST node types to their handlers
_NODE_HANDLERS: dict[type, Callable[[ast.AST, dict[str, Any], dict[str, Any]], Any]] = {
    ast.Constant: _eval_constant,
    ast.Name: _eval_name,
    ast.Attribute: _eval_attribute,
    ast.Subscript: _eval_subscript,
    ast.Compare: _eval_compare,
    ast.BoolOp: _eval_boolop,
    ast.UnaryOp: _eval_unaryop,
    ast.IfExp: _eval_ifexp,
    ast.List: _eval_list,
    ast.Tuple: _eval_tuple,
    ast.Dict: _eval_dict,
    ast.BinOp: _eval_binop,
    ast.Call: _eval_call,
    ast.ListComp: _eval_listcomp,
    ast.SetComp: _eval_setcomp,
    ast.DictComp: _eval_dictcomp,
}


def _evaluate_node(node: ast.AST, data: dict[str, Any], state: dict[str, Any]) -> Any:
    """Evaluate an AST node against data and state."""
    handler = _NODE_HANDLERS.get(type(node))
    if handler is None:
        raise ExpressionError("", f"Unsupported AST node: {type(node).__name__}")
    return handler(node, data, state)


def _collect_attribute_path(node: ast.Attribute) -> list[str]:
    """Collect attribute path from nested attribute access.

    For `node.response.action`, returns ["node", "response", "action"]
    """
    path: list[str] = []
    current: ast.AST = node

    while isinstance(current, ast.Attribute):
        path.append(current.attr)
        current = current.value

    if isinstance(current, ast.Name):
        path.append(current.id)

    return list(reversed(path))


@lru_cache(maxsize=256)
def compile_expression(expression: str) -> Callable[[dict[str, Any], dict[str, Any]], bool]:
    """Compile a string expression into a safe predicate function.

    The compiled predicate takes two arguments:
    - data: dict containing node outputs and other data
    - state: dict containing loop state or other state variables

    Parameters
    ----------
    expression : str
        Expression string like "action == 'ACCEPT'" or "count > 5 and active"

    Returns
    -------
    Callable[[dict, dict], bool]
        Predicate function that returns True/False

    Raises
    ------
    ExpressionError
        If expression is invalid or contains disallowed operations

    Examples
    --------
    >>> pred = compile_expression("action == 'ACCEPT'")
    >>> pred({"action": "ACCEPT"}, {})
    True

    >>> pred = compile_expression("node.status in ['active', 'pending']")
    >>> pred({"node": {"status": "active"}}, {})
    True

    >>> pred = compile_expression("state.iteration < 10")
    >>> pred({}, {"iteration": 5})
    True
    """
    if not expression or not expression.strip():
        raise ExpressionError(expression, "Expression cannot be empty")

    expression = expression.strip()

    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as e:
        raise ExpressionError(expression, f"Syntax error: {e.msg}") from e

    # Validate AST is safe
    _validate_ast(tree, expression)

    def predicate(data: dict[str, Any], state: dict[str, Any]) -> bool:
        """Evaluate the compiled expression."""
        try:
            result = _evaluate_node(tree.body, data, state)
            if result is MISSING:
                logger.warning(
                    "Predicate '{}' contains a missing reference — evaluating to False. "
                    "Available names: {}",
                    expression,
                    sorted(data.keys()),
                )
                return False
            return bool(result)
        except Exception as e:
            logger.warning("Expression '{}' evaluation failed: {}", expression, e)
            return False

    return predicate


def evaluate_expression(
    expression: str,
    data: dict[str, Any],
    state: dict[str, Any] | None = None,
) -> Any:
    """Evaluate an expression and return the actual result value.

    Unlike compile_expression which returns a boolean predicate, this function
    returns the actual computed value of the expression. Use this for input_mapping
    transformations where you need the actual value, not just True/False.

    Parameters
    ----------
    expression : str
        Expression string like "len(items)" or "upper(name)"
    data : dict
        Data dict for variable resolution
    state : dict | None
        Optional state dict for state variable resolution

    Returns
    -------
    Any
        The actual result of evaluating the expression

    Raises
    ------
    ExpressionError
        If expression is invalid or contains disallowed operations

    Examples
    --------
    >>> evaluate_expression("len(items)", {"items": [1, 2, 3]})
    3

    >>> evaluate_expression("upper(name)", {"name": "john"})
    'JOHN'

    >>> evaluate_expression("price * quantity", {"price": 10, "quantity": 5})
    50
    """
    if not expression or not expression.strip():
        raise ExpressionError(expression, "Expression cannot be empty")

    expression = expression.strip()
    state = state or {}

    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as e:
        raise ExpressionError(expression, f"Syntax error: {e.msg}") from e

    # Validate AST is safe
    _validate_ast(tree, expression)

    result = _evaluate_node(tree.body, data, state)

    # If the entire expression resolved to MISSING, raise a clear error
    if result is MISSING:
        raise ExpressionError(
            expression,
            f"Expression resolved to a missing reference. Available names: {sorted(data.keys())}",
        )

    return result
