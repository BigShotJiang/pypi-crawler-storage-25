from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ValidatorScoreSummary")


@_attrs_define
class ValidatorScoreSummary:
    """Aggregated scoring stats for a single validator.

    Attributes:
        validator_hotkey (str): Validator hotkey
        total_runs (int): Total completed runs
        avg_score (float): Mean score across runs
        median_score (float): Median score
        stddev_score (float): Standard deviation of scores
        min_score (float): Minimum score
        max_score (float): Maximum score
        deviation_from_global (float): Percentage deviation from the global average (negative = below)
        is_outlier (bool): True if deviation exceeds 1.5 standard deviations from global mean
    """

    validator_hotkey: str
    total_runs: int
    avg_score: float
    median_score: float
    stddev_score: float
    min_score: float
    max_score: float
    deviation_from_global: float
    is_outlier: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        validator_hotkey = self.validator_hotkey

        total_runs = self.total_runs

        avg_score = self.avg_score

        median_score = self.median_score

        stddev_score = self.stddev_score

        min_score = self.min_score

        max_score = self.max_score

        deviation_from_global = self.deviation_from_global

        is_outlier = self.is_outlier

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "validator_hotkey": validator_hotkey,
                "total_runs": total_runs,
                "avg_score": avg_score,
                "median_score": median_score,
                "stddev_score": stddev_score,
                "min_score": min_score,
                "max_score": max_score,
                "deviation_from_global": deviation_from_global,
                "is_outlier": is_outlier,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        validator_hotkey = d.pop("validator_hotkey")

        total_runs = d.pop("total_runs")

        avg_score = d.pop("avg_score")

        median_score = d.pop("median_score")

        stddev_score = d.pop("stddev_score")

        min_score = d.pop("min_score")

        max_score = d.pop("max_score")

        deviation_from_global = d.pop("deviation_from_global")

        is_outlier = d.pop("is_outlier")

        validator_score_summary = cls(
            validator_hotkey=validator_hotkey,
            total_runs=total_runs,
            avg_score=avg_score,
            median_score=median_score,
            stddev_score=stddev_score,
            min_score=min_score,
            max_score=max_score,
            deviation_from_global=deviation_from_global,
            is_outlier=is_outlier,
        )

        validator_score_summary.additional_properties = d
        return validator_score_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
