## 0.5.1 (2026-04-20)

### Fix

- **cli**: fix mermaid and plantuml binary checks

