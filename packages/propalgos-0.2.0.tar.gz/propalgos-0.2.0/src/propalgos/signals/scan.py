"""Multi-symbol signal scanning utilities.

Vectorized signal computation across stacked (tall) DataFrames — the output
of ``pa.data.load()``. Two flavors:

- ``rsi_stacked()`` — optimized RSI that avoids groupby overhead entirely
- ``scan()`` — generic applicator for any single-symbol signal function
"""

from __future__ import annotations

import logging
from collections.abc import Callable

import numpy as np
import pandas as pd

from propalgos.exceptions import DataError

logger = logging.getLogger(__name__)


def rsi_stacked(
    df: pd.DataFrame,
    period: int = 14,
    symbol_col: str = "symbol",
    close_col: str = "close",
) -> pd.DataFrame:
    """Compute RSI vectorized across a stacked multi-symbol DataFrame.

    Returns a copy of the input with an ``rsi`` column appended. Uses Wilder
    smoothing (EWM with ``alpha = 1/period``). Nulls out symbol boundaries
    so values don't leak across pairs. First ``period`` rows per symbol
    are NaN (warmup).

    This avoids ``groupby().apply()`` entirely — instead we null out group
    boundaries so ``diff()``/``ewm()`` never leak across symbols. Runs as
    a single pass, compatible with cuDF GPU acceleration.

    Parameters
    ----------
    df:
        Stacked DataFrame with at least ``symbol_col`` and ``close_col``.
        Must be sorted by ``(symbol, timestamp)`` for correct results.
    period:
        RSI lookback period.
    symbol_col:
        Column identifying the symbol/pair.
    close_col:
        Column containing close prices.

    Returns
    -------
    pd.DataFrame
        Copy of input with ``rsi`` column (float, 0-100 range, NaN for warmup).
    """
    if symbol_col not in df.columns:
        raise DataError(
            f"symbol column {symbol_col!r} not found. "
            f"Columns: {list(df.columns)}"
        )
    if close_col not in df.columns:
        raise DataError(
            f"close column {close_col!r} not found. "
            f"Columns: {list(df.columns)}"
        )

    result = df.copy()
    close = result[close_col]
    delta = close.diff()

    # Null out rows where the symbol changes so values don't leak across pairs
    boundary = result[symbol_col] != result[symbol_col].shift(1)
    delta[boundary] = np.nan

    gain = delta.clip(lower=0.0)
    loss = (-delta).clip(lower=0.0)

    # Wilder smoothing: EWM with alpha = 1/period (equiv to com = period - 1)
    avg_gain = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_loss = loss.ewm(com=period - 1, min_periods=period).mean()

    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))

    # Null out the warmup rows per symbol
    cumcount = result.groupby(symbol_col).cumcount()
    rsi[cumcount < period] = np.nan

    result["rsi"] = rsi
    return result


def scan(
    df: pd.DataFrame,
    signal_fn: Callable[[pd.DataFrame], pd.Series],
    symbol_col: str = "symbol",
) -> pd.DataFrame:
    """Apply a signal function to each symbol group in a stacked DataFrame.

    Returns a copy of the input with a ``signal`` column appended. The
    ``signal_fn`` receives a single-symbol DataFrame (with a ``close`` column)
    and should return a ``pd.Series`` of signal values.

    Slower than ``rsi_stacked()`` but works with any ``pa.signals.*`` function.
    Groups that raise exceptions (e.g. too few rows) get signal = 0.

    Parameters
    ----------
    df:
        Stacked DataFrame with at least ``symbol_col`` and ``close``.
    signal_fn:
        Function ``(DataFrame) -> Series`` that computes a signal for one symbol.
    symbol_col:
        Column identifying the symbol/pair.

    Returns
    -------
    pd.DataFrame
        Copy of input with ``signal`` column appended.
    """
    if symbol_col not in df.columns:
        raise DataError(
            f"symbol column {symbol_col!r} not found. "
            f"Columns: {list(df.columns)}"
        )

    result = df.copy()

    def _safe_signal(group: pd.DataFrame) -> pd.Series:
        try:
            return signal_fn(group)
        except Exception as exc:
            logger.debug("scan: signal_fn failed for group: %s", exc)
            return pd.Series(0, index=group.index, dtype=int)

    # groupby().apply() lets cuDF parallelize across groups when available,
    # versus the previous explicit Python for-loop over groups.
    result["signal"] = result.groupby(symbol_col, group_keys=False).apply(_safe_signal)
    return result
