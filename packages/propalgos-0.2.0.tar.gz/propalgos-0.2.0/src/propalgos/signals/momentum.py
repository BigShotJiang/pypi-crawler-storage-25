"""Momentum-based signal generators.

Each signal function accepts a prices DataFrame (must contain a 'close' column)
and returns a pd.Series of int values in {-1, 0, 1}. The ``rsi`` helper
returns the raw RSI series (0-100 range) for users who want intermediate values.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from propalgos.signals.trend import _validate_prices


def rsi(
    prices: pd.DataFrame,
    period: int = 14,
) -> pd.Series:
    """Compute Relative Strength Index (0-100 range).

    Uses the Wilder smoothing method (exponential moving average with
    ``alpha = 1 / period``). This is a helper -- it returns raw RSI values,
    not a discretized signal.

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    period : int
        Lookback for the RSI calculation.

    Returns
    -------
    pd.Series
        RSI values in [0, 100]. First *period* values are NaN.
    """
    close = _validate_prices(prices)
    delta = close.diff()

    gain = delta.clip(lower=0.0)
    loss = (-delta).clip(lower=0.0)

    # Wilder smoothing: EWM with alpha = 1/period (equiv to com = period - 1)
    avg_gain = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_loss = loss.ewm(com=period - 1, min_periods=period).mean()

    rs = avg_gain / avg_loss
    rsi_values = 100.0 - (100.0 / (1.0 + rs))

    return rsi_values


def rsi_reversion(
    prices: pd.DataFrame,
    period: int = 14,
    overbought: float = 70.0,
    oversold: float = 30.0,
) -> pd.Series:
    """RSI mean-reversion signal.

    +1 when RSI drops below *oversold* (expect a bounce), -1 when RSI rises
    above *overbought* (expect a pullback), 0 otherwise or during warmup.

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    period : int
        RSI lookback.
    overbought : float
        Upper threshold (default 70).
    oversold : float
        Lower threshold (default 30).

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.
    """
    rsi_values = rsi(prices, period=period)

    signal = pd.Series(0, index=rsi_values.index, dtype=int)
    signal[rsi_values < oversold] = 1
    signal[rsi_values > overbought] = -1
    # NaN warmup -> 0 (already 0 by default, but be explicit)
    signal[rsi_values.isna()] = 0
    return signal


def macd(
    prices: pd.DataFrame,
    fast: int = 12,
    slow: int = 26,
    signal_period: int = 9,
) -> pd.Series:
    """MACD histogram signal.

    +1 when the MACD line is above the signal line (bullish momentum),
    -1 when below (bearish momentum), 0 during warmup.

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    fast : int
        Fast EMA span (default 12).
    slow : int
        Slow EMA span (default 26).
    signal_period : int
        Signal line EMA span (default 9).

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.
    """
    close = _validate_prices(prices)

    fast_ema = close.ewm(span=fast, adjust=False).mean()
    slow_ema = close.ewm(span=slow, adjust=False).mean()
    macd_line = fast_ema - slow_ema
    signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()

    signal = pd.Series(0, index=close.index, dtype=int)
    signal[macd_line > signal_line] = 1
    signal[macd_line < signal_line] = -1
    # Warmup: slow EMA + signal period bars are unreliable
    warmup = slow + signal_period
    signal.iloc[:warmup] = 0
    return signal
