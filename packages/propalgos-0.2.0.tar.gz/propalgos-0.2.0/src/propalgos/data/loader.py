"""Bulk dataset loader — load an entire timeframe parquet (all symbols).

The key missing API for multi-symbol analysis. Returns a tall, stacked
DataFrame with ``symbol``, ``timestamp``, OHLCV, and optionally ``trades``
columns — the shape needed for vectorized cross-universe computations like
``pa.signals.rsi_stacked()``.

Quick start on platform::

    import propalgos as pa

    df = pa.data.load("crypto-kraken", interval="1h")
    # → DataFrame [symbol, timestamp, open, high, low, close, volume, trades]
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path

import pandas as pd

from propalgos.data.staging import is_stale, resolve_stage_dir, stage_file
from propalgos.exceptions import DataError

logger = logging.getLogger(__name__)

# When cudf.pandas is active (installed by propalgos.__init__), pd.read_parquet
# already dispatches to cuDF. This flag is for logging/diagnostics only.
try:
    import cudf  # type: ignore[import-untyped]
    _GPU_AVAILABLE = True
except ImportError:
    _GPU_AVAILABLE = False

# Interval string -> consolidated parquet minutes suffix
_INTERVAL_TO_MINUTES: dict[str, int] = {
    "1m": 1,
    "5m": 5,
    "15m": 15,
    "30m": 30,
    "60m": 60,
    "1h": 60,
    "4h": 240,
    "12h": 720,
    "1d": 1440,
    "1D": 1440,
    "1wk": 10080,
}

# Module-level cache: (dataset_id, minutes) → DataFrame
_cache: dict[tuple[str, int], pd.DataFrame] = {}


def _parse_dataset_id(dataset_id: str) -> tuple[str, str]:
    """Parse ``"category-source"`` into ``(category, source)``.

    Raises ``DataError`` if the format is invalid.
    """
    if "-" not in dataset_id:
        raise DataError(
            f"invalid dataset_id {dataset_id!r} — expected 'category-source' "
            f"format (e.g. 'crypto-kraken')"
        )
    category, source = dataset_id.split("-", 1)
    if not category or not source:
        raise DataError(
            f"invalid dataset_id {dataset_id!r} — both category and source "
            f"must be non-empty"
        )
    return category, source


def _resolve_datasets_base() -> Path:
    """Resolve the root datasets directory (same logic as registry.py)."""
    explicit = os.environ.get("PROPALGOS_DATASETS_DIR")
    if explicit:
        p = Path(explicit)
        if p.exists():
            return p

    platform = Path("/home/propalgos/datasets")
    if platform.exists():
        return platform

    local = Path("data")
    if local.exists():
        return local

    raise DataError(
        "no datasets directory found. "
        "Set PROPALGOS_DATASETS_DIR or ensure /home/propalgos/datasets exists."
    )


def _resolve_source_path(category: str, source: str, filename: str) -> Path:
    """Resolve the source path for a consolidated parquet file.

    Today this checks the FUSE mount filesystem. When HTTP/S3-direct sources
    are added, only this function changes — staging/reading/caching stay same.
    """
    base = _resolve_datasets_base()
    return base / category / source / "consolidated" / filename


def load(dataset_id: str, interval: str = "1d") -> pd.DataFrame:
    """Load a full stacked DataFrame for a dataset and timeframe.

    Returns a tall DataFrame with all symbols, sorted by ``(symbol, timestamp)``.
    The parquet is staged to local disk on first access (fast NVMe reads),
    and cached in memory for the process lifetime.

    Parameters
    ----------
    dataset_id:
        Dataset identifier in ``"category-source"`` format, e.g.
        ``"crypto-kraken"``.
    interval:
        Bar interval — ``"1d"``, ``"1h"``, ``"5m"``, etc.

    Returns
    -------
    pd.DataFrame
        Stacked DataFrame with columns like ``symbol``, ``timestamp``,
        ``open``, ``high``, ``low``, ``close``, ``volume``.
    """
    category, source = _parse_dataset_id(dataset_id)

    minutes = _INTERVAL_TO_MINUTES.get(interval)
    if minutes is None:
        available = sorted(_INTERVAL_TO_MINUTES.keys())
        raise DataError(
            f"interval {interval!r} not recognized. Available: {available}"
        )

    cache_key = (dataset_id, minutes)
    if cache_key in _cache:
        return _cache[cache_key]

    filename = f"{source}_{minutes}.parquet"
    source_path = _resolve_source_path(category, source, filename)

    if not source_path.exists():
        # List available files for a helpful error
        consolidated_dir = source_path.parent
        if consolidated_dir.exists():
            available_files = sorted(p.name for p in consolidated_dir.glob("*.parquet"))
            raise DataError(
                f"parquet file not found: {source_path}. "
                f"Available files: {available_files}"
            )
        raise DataError(
            f"dataset directory not found: {consolidated_dir}. "
            f"Check that dataset_id={dataset_id!r} is correct and data exists."
        )

    # Stage to local disk (NVMe) before reading
    stage_dir = resolve_stage_dir() / category / source
    local = stage_dir / filename
    if not local.exists() or is_stale(source_path, local):
        local.parent.mkdir(parents=True, exist_ok=True)
        t0 = time.monotonic()
        stage_file(source_path, local)
        elapsed = time.monotonic() - t0
        size_mb = local.stat().st_size / (1024 * 1024)
        logger.info("Staged %s (%.1f MB) in %.1fs", filename, size_mb, elapsed)

    logger.debug("Loading %s (staged, gpu=%s)", local, _GPU_AVAILABLE)
    if _GPU_AVAILABLE:
        # Direct cudf.read_parquet — bypasses cudf.pandas shim overhead and
        # can leverage kvikIO/GDS for zero-copy GPU memory loads when available.
        df = cudf.read_parquet(local)
    else:
        df = pd.read_parquet(local)
    _cache[cache_key] = df
    return df
