"""Verify that the package imports cleanly and exposes the expected namespaces."""

from __future__ import annotations

import os
from unittest.mock import patch


def test_top_level_import():
    import propalgos as pa

    assert hasattr(pa, "__version__")
    assert pa.__version__ == "0.1.0"


def test_namespace_availability():
    import propalgos as pa

    namespaces = ["env", "data", "signals", "factors", "backtest", "viz"]
    for ns in namespaces:
        assert hasattr(pa, ns), f"pa.{ns} missing"

    # Stub modules should NOT be auto-imported at top level
    stubs = ["storage", "notebook", "account", "submit", "auth", "api"]
    for ns in stubs:
        assert not hasattr(pa, ns), f"pa.{ns} should not be auto-imported"


def test_top_level_shortcuts():
    import propalgos as pa

    assert callable(pa.prices)
    assert callable(pa.run_backtest)


def test_signal_functions_accessible():
    from propalgos import signals

    funcs = ["sma_cross", "ema_cross", "trend_filter", "rsi_reversion", "macd", "bollinger_bands", "zscore_reversion", "combine"]
    for fn in funcs:
        assert callable(getattr(signals, fn)), f"signals.{fn} not callable"


def test_factor_functions_accessible():
    from propalgos import factors

    funcs = ["sharpe", "sortino", "calmar", "max_drawdown", "var", "cvar", "beta", "annualized_volatility"]
    for fn in funcs:
        assert callable(getattr(factors, fn)), f"factors.{fn} not callable"


def test_backtest_exports():
    from propalgos.backtest import run, BacktestResult, CostModel

    assert callable(run)
    assert BacktestResult is not None
    assert CostModel is not None


def test_exceptions():
    from propalgos.exceptions import (
        PropAlgosError,
        AuthenticationError,
        APIError,
        InsufficientCreditsError,
        DataError,
        BacktestError,
        ConfigError,
    )

    assert issubclass(AuthenticationError, PropAlgosError)
    assert issubclass(DataError, PropAlgosError)
    assert issubclass(BacktestError, PropAlgosError)


def test_env_summary_runs():
    """env.summary() should not crash even without GPU/PropAlgos."""
    from propalgos import env

    env.summary()  # Should print to stdout without error


# -- _auto_enable_cudf tests --------------------------------------------------


class TestAutoEnableCudf:
    """Tests for the cudf.pandas auto-activation logic."""

    def test_noop_when_no_instance_id(self):
        """Off-platform (no PROPALGOS_INSTANCE_ID) should be a no-op."""
        from propalgos import _auto_enable_cudf

        env = os.environ.copy()
        env.pop("PROPALGOS_INSTANCE_ID", None)
        with patch.dict(os.environ, env, clear=True):
            _auto_enable_cudf()  # should not raise

    def test_noop_when_opted_out(self):
        """PROPALGOS_CUDF_AUTO=0 should skip activation."""
        from propalgos import _auto_enable_cudf

        with patch.dict(os.environ, {
            "PROPALGOS_INSTANCE_ID": "test-instance",
            "PROPALGOS_CUDF_AUTO": "0",
        }):
            _auto_enable_cudf()  # should not raise or attempt import

    def test_no_crash_when_cudf_missing(self):
        """On-platform but cudf not installed should fail silently."""
        from propalgos import _auto_enable_cudf

        with patch.dict(os.environ, {
            "PROPALGOS_INSTANCE_ID": "test-instance",
            "PROPALGOS_CUDF_AUTO": "1",
        }):
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                _auto_enable_cudf()  # cudf not available locally — should not raise

    def test_calls_cudf_install_when_available(self):
        """When on-platform and cudf is importable, should call install()."""
        from propalgos import _auto_enable_cudf
        from unittest.mock import MagicMock
        import sys

        mock_cudf_pandas = MagicMock()
        mock_cudf = MagicMock()
        mock_cudf.pandas = mock_cudf_pandas

        with patch.dict(os.environ, {
            "PROPALGOS_INSTANCE_ID": "test-instance",
            "PROPALGOS_CUDF_AUTO": "1",
        }):
            with patch.dict(sys.modules, {"cudf": mock_cudf, "cudf.pandas": mock_cudf_pandas}):
                _auto_enable_cudf()
                mock_cudf_pandas.install.assert_called_once()
