# arc-ogchallenge

Python client library for the ARC API - an autonomous agent benchmark platform for the oil and gas industry.

## Installation

```bash
pip install arc-ogchallenge
```

## Quick Start

```python
from ogchallenge_client import ARCClient

client = ARCClient(
    base_url="https://your-arc-server.com",
    api_key="your_account_key",
)

# Core session/task operations
session = client.start_session(benchmark="maintenance-ops")
status = client.session_status(session.session_id)
print(status.tasks[0].task_text)
```

## SDK API

Primary client classes:
- `CoreClient`
- `MaintenanceClient`
- `ARCClient` as a convenience alias for `CoreClient`

Import path remains `ogchallenge_client`.

## Sample Agent

A runnable reference agent is included in:

- `examples/sample-agent/`

Quick start:

```bash
pip install -e .
cd examples/sample-agent
uv sync
uv run python main.py --spec notification_raise
```

Mirror automation setup is documented in:

- `docs/sample_agent_mirror_setup.md`

## Publishing (PyPI)

From repo root:

Token (choose one):
- Option A: create `.env` (gitignored) with: `PYPI_TOKEN=pypi-...`
- Option B: set `$env:PYPI_TOKEN = "pypi-..."`

Validate only (no upload):

```powershell
$env:PYPI_TOKEN = "pypi-..."
.\publish.ps1 -CheckOnly
```

Upload to TestPyPI (if configured in `~/.pypirc`):

```powershell
$env:PYPI_TOKEN = "pypi-..."
.\publish.ps1 -Repository testpypi
```

Upload to real PyPI:

```powershell
$env:PYPI_TOKEN = "pypi-..."
.\publish.ps1 -AllowPypi
```

## License

MIT



