﻿from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from agencli.skills.cli_backend import (
    find_skills,
    install_skill_cli,
    list_installed_skills_cli,
    normalize_repo_skill_target,
    parse_find_output,
    parse_installed_output,
    render_command,
)
from agencli.skills.loader import resolve_skill_sources
from agencli.skills.manager import install_skill, list_installed_skills


def _write_skill(root: Path, name: str, description: str) -> Path:
    skill_dir = root / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    (skill_dir / "SKILL.md").write_text(
        (
            "---\n"
            f"name: {name}\n"
            f"description: {description}\n"
            "allowed-tools: read_file write_file\n"
            "---\n\n"
            "# Skill\n"
        ),
        encoding="utf-8",
    )
    return skill_dir


class SkillsHelpersTest(unittest.TestCase):
    def test_install_skill_creates_installed_and_named_roots(self) -> None:
        with TemporaryDirectory() as skills_dir, TemporaryDirectory() as source_dir:
            source_skill = _write_skill(Path(source_dir), "web-research", "Research the web carefully.")

            installed = install_skill(source_skill, skills_dir)

            self.assertEqual(installed.name, "web-research")
            self.assertTrue(Path(skills_dir, "installed", "web-research", "SKILL.md").exists())
            self.assertTrue(Path(skills_dir, "by-name", "web-research", "web-research", "SKILL.md").exists())

    def test_list_installed_skills_reads_metadata(self) -> None:
        with TemporaryDirectory() as skills_dir, TemporaryDirectory() as source_dir:
            install_skill(_write_skill(Path(source_dir), "shell-safety", "Use safe shell commands."), skills_dir)

            skills = list_installed_skills(skills_dir)

            self.assertEqual(len(skills), 1)
            self.assertEqual(skills[0].allowed_tools, ["read_file", "write_file"])
            self.assertEqual(skills[0].description, "Use safe shell commands.")

    def test_resolve_skill_sources_supports_installed_and_named_tokens(self) -> None:
        with TemporaryDirectory() as skills_dir, TemporaryDirectory() as source_dir:
            install_skill(_write_skill(Path(source_dir), "filesystem-review", "Inspect files precisely."), skills_dir)

            resolved = resolve_skill_sources(["installed", "filesystem-review"], skills_dir)

            self.assertEqual(
                resolved,
                [
                    Path(skills_dir, "installed").resolve().as_posix(),
                    Path(skills_dir, "by-name", "filesystem-review").resolve().as_posix(),
                ],
            )

    def test_resolve_skill_sources_keeps_virtual_sources_and_normalizes_paths(self) -> None:
        with TemporaryDirectory() as skills_dir, TemporaryDirectory() as source_dir:
            collection_root = Path(source_dir)
            _write_skill(collection_root, "python-quality", "Write readable Python.")

            resolved = resolve_skill_sources(
                ["/skills/project/", str(collection_root), str(collection_root / "python-quality")],
                skills_dir,
            )

            normalized = [item.rstrip("/") for item in resolved]
            self.assertEqual(normalized[0], "/skills/project")
            self.assertIn(collection_root.resolve().as_posix(), normalized)
            self.assertTrue(
                any(
                    candidate in normalized
                    for candidate in (
                        collection_root.resolve().as_posix(),
                        (collection_root / "python-quality").resolve().as_posix(),
                    )
                )
            )

    def test_parse_find_output_extracts_repo_and_install_command(self) -> None:
        output = (
            "anthropics/skills@frontend-design 212.6K installs\n"
            "└ https://skills.sh/anthropics/skills/frontend-design\n"
        )

        results = parse_find_output(output, query="ui")

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].name, "frontend-design")
        self.assertEqual(results[0].source, "anthropics/skills")
        self.assertEqual(results[0].skill_name, "frontend-design")
        self.assertEqual(results[0].install_count_text, "212.6K installs")
        self.assertEqual(results[0].skills_page_url, "https://skills.sh/anthropics/skills/frontend-design")
        self.assertEqual(
            results[0].install_command,
            ("npx", "skills", "add", "anthropics/skills", "--skill", "frontend-design", "-g", "-y"),
        )
        self.assertIn("trusted", results[0].quality.labels)

    def test_find_skills_shells_out_to_npx_skills_find(self) -> None:
        mocked = SimpleNamespace(
            returncode=0,
            stdout="anthropics/skills@frontend-design 212.6K installs\n└ https://skills.sh/anthropics/skills/frontend-design\n",
            stderr="",
        )
        with patch("agencli.skills.cli_backend.subprocess.run", return_value=mocked) as mocked_run:
            result, parsed = find_skills("ui", workspace_dir="/tmp/work")

        mocked_run.assert_called_once()
        self.assertTrue(result.ok)
        self.assertEqual(result.argv[:3], ("npx", "skills", "find"))
        self.assertEqual(parsed[0].source, "anthropics/skills")

    def test_parse_installed_output_ignores_cli_guidance_lines(self) -> None:
        output = (
            "Try listing global skills with -g\n"
            "Try listing global skills with -g\n"
        )

        parsed = parse_installed_output(output, default_scope="project")

        self.assertEqual(parsed, [])

    def test_parse_installed_output_handles_mixed_case_agents_label(self) -> None:
        output = "frontend-design  •  Agents: Codex, Cursor, OpenCode\n"

        parsed = parse_installed_output(output, default_scope="global")

        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0].name, "frontend-design")
        self.assertEqual(parsed[0].agents, ["codex", "cursor", "opencode"])

    def test_list_installed_skills_cli_merges_project_and_global_records(self) -> None:
        mocked_results = [
            SimpleNamespace(returncode=0, stdout="frontend-design  •  agents: codex\n", stderr=""),
            SimpleNamespace(returncode=0, stdout="docs-writer  •  agents: codex\n", stderr=""),
        ]
        with patch("agencli.skills.cli_backend.subprocess.run", side_effect=mocked_results) as mocked_run:
            result, records = list_installed_skills_cli(workspace_dir="/tmp/work")

        self.assertTrue(result.ok)
        self.assertEqual(mocked_run.call_count, 2)
        first_argv = mocked_run.call_args_list[0].args[0]
        second_argv = mocked_run.call_args_list[1].args[0]
        self.assertEqual(first_argv, ["npx", "skills", "list"])
        self.assertEqual(second_argv, ["npx", "skills", "list", "-g"])
        self.assertEqual([record.name for record in records], ["frontend-design", "docs-writer"])
        self.assertEqual(records[0].scope, "project")
        self.assertEqual(records[1].scope, "global")

    def test_list_installed_skills_cli_keeps_real_frontend_design_global_skill(self) -> None:
        mocked_results = [
            SimpleNamespace(
                returncode=0,
                stdout="Try listing global skills with -g\n",
                stderr="",
            ),
            SimpleNamespace(
                returncode=0,
                stdout="frontend-design  •  agents: codex, cursor, opencode\n",
                stderr="",
            ),
        ]
        with patch("agencli.skills.cli_backend.subprocess.run", side_effect=mocked_results):
            result, records = list_installed_skills_cli(workspace_dir="/tmp/work")

        self.assertTrue(result.ok)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].name, "frontend-design")
        self.assertEqual(records[0].scope, "global")
        self.assertIn("codex", records[0].details)

    def test_install_skill_cli_uses_safe_argument_array(self) -> None:
        mocked = SimpleNamespace(returncode=0, stdout="installed", stderr="")
        with patch("agencli.skills.cli_backend.subprocess.run", return_value=mocked) as mocked_run:
            result = install_skill_cli(
                "vercel-labs/agent-skills",
                workspace_dir="/tmp/work",
                skill_name="frontend-design",
            )

        argv = mocked_run.call_args.args[0]
        self.assertEqual(
            argv,
            ["npx", "skills", "add", "vercel-labs/agent-skills", "--skill", "frontend-design", "-g", "-y"],
        )
        self.assertTrue(result.ok)

    def test_normalize_repo_skill_target_supports_owner_repo_at_skill(self) -> None:
        source, skill_name = normalize_repo_skill_target("vercel-labs/agent-skills@frontend-design")

        self.assertEqual(source, "vercel-labs/agent-skills")
        self.assertEqual(skill_name, "frontend-design")

    def test_render_command_quotes_spaces(self) -> None:
        rendered = render_command(("npx", "skills", "add", "owner/repo", "--skill", "Convex Best Practices"))

        self.assertIn('"Convex Best Practices"', rendered)


if __name__ == "__main__":
    unittest.main()
