from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from textual import events

from agencli.agents.factory import AgentSpec
from agencli.agents.runtime import StreamEvent
from agencli.agents.registry import AgentRegistry
from agencli.core.config import AgenCLIConfig, OpenAICompatibleConfig, load_config, save_config
from agencli.core.session import append_chat_turn
from agencli.skills.cli_backend import CliCommandResult, InstalledSkillRecord, SkillResultQuality, SkillSearchResult, SkillsStatusResult
from agencli.tui.app import AgenCLIApp, HumanLoopState, ShellPromptInput, SubagentEditorState, VISIBLE_BRAND
from agencli.tui.screens import ThreadSelection


class AgenCLIAppShellTest(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self._tmpdir.name)
        for name in ("workspace", "sessions", "agents", "skills"):
            (self.root / name).mkdir()
        self.config_path = self.root / "config.toml"

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def _build_config(self, *, base_url: str, model: str) -> AgenCLIConfig:
        config = AgenCLIConfig(
            default_model="openai:gpt-4.1",
            workspace_dir=str(self.root / "workspace"),
            sessions_dir=str(self.root / "sessions"),
            agents_dir=str(self.root / "agents"),
            skills_dir=str(self.root / "skills"),
            mcp_config_path=str(self.root / "mcp_servers.json"),
            openai_compatible=OpenAICompatibleConfig(base_url=base_url, model=model),
        )
        save_config(config, self.config_path)
        return config

    async def test_slash_completion_selects_first_match_then_respects_arrow_navigation(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)

            prompt_input.value = "/his"
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(prompt_input.value, "/history")

            prompt_input.value = "/mo"
            await pilot.pause()
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(prompt_input.value, "/model")
            picker = app.query_one("#picker")
            self.assertIn("/model", str(picker.visual))
            self.assertIn("usage:", str(picker.visual).lower())

    async def test_prompt_history_navigates_recent_commands_with_up_and_down(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)

            prompt_input.value = "/status"
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            prompt_input.value = "/help"
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            await pilot.press("up")
            await pilot.pause()
            self.assertEqual(prompt_input.value, "/help")

            await pilot.press("up")
            await pilot.pause()
            self.assertEqual(prompt_input.value, "/status")

            await pilot.press("down")
            await pilot.pause()
            self.assertEqual(prompt_input.value, "/help")

            await pilot.press("down")
            await pilot.pause()
            self.assertEqual(prompt_input.value, "")

    async def test_plain_prompt_submission_clears_input(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            prompt_input.value = "hi"
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(prompt_input.value, "")

    async def test_welcome_panel_uses_visible_branding(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            await pilot.pause()
            welcome_panel = app.query_one("#welcome-left")
            self.assertIn(VISIBLE_BRAND, str(welcome_panel.visual))

    async def test_composer_lives_inside_main_viewport_for_terminal_like_scroll(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            await pilot.pause()
            viewport = app.query_one("#viewport")
            composer = app.query_one("#composer")
            self.assertIs(composer.parent, viewport)

    async def test_theme_command_opens_inline_picker_and_applies_selection(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            prompt_input.value = "/theme"
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(app._picker_mode, "theme")
            self.assertEqual(prompt_input.placeholder, "Choose a theme with Up/Down, then press Enter")

            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            self.assertEqual(app._theme_name, "light")
            self.assertFalse(app.dark)
            self.assertIsNone(app._picker_mode)
            self.assertEqual(prompt_input.placeholder, f'Try "/help" or ask {VISIBLE_BRAND} to inspect the workspace')

    async def test_saved_active_custom_agents_are_attached_to_supervisor(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        registry = AgentRegistry(config.agents_dir)
        registry.save_active_names(["organizer"])
        registry.save(
            AgentSpec(
                name="organizer",
                model="openai:gpt-4.1",
                description="Organize the workspace in bulk.",
                system_prompt="Organize files carefully.",
            )
        )
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            await pilot.pause()
            self.assertEqual(app._current_agent_name(), "supervisor-agent")
            supervisor = app._selected_agent_spec()
            self.assertIsNotNone(supervisor)
            names = [subagent.name for subagent in supervisor.subagents if hasattr(subagent, "name")]
            self.assertIn("organizer", names)

    async def test_agent_manager_uses_dedicated_active_picker(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        registry = AgentRegistry(config.agents_dir)
        registry.save_active_names(["organizer"])
        registry.save(
            AgentSpec(
                name="organizer",
                model="openai:gpt-4.1",
                description="Organize files",
                system_prompt="Organize files.",
            )
        )
        registry.save(
            AgentSpec(
                name="reviewer",
                model="openai:gpt-4.1",
                description="Review work",
                system_prompt="Review carefully.",
            )
        )
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            app.action_open_agents()
            await pilot.pause()
            self.assertEqual(app._picker_mode, "agent-root")

            await pilot.press("down")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(app._picker_mode, "agent-active")

            await pilot.press("down")
            await pilot.pause()
            await pilot.press("space")
            await pilot.pause()
            self.assertIn("reviewer", app._picker_marks)
            await pilot.press("enter")
            await pilot.pause()

        self.assertEqual(set(AgentRegistry(config.agents_dir).load_active_names()), {"organizer", "reviewer"})

    async def test_agent_manager_can_create_new_subagent_with_review(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            with patch.object(
                app,
                "_build_subagent_review",
                return_value=(
                    "batch-organizer: supervisor-managed specialist with skills none.",
                    "Organize files in batches and keep tool chatter low.",
                ),
            ):
                app.action_open_agents()
                await pilot.pause()
                self.assertEqual(app._picker_mode, "agent-root")

                await pilot.press("enter")
                await pilot.pause()
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                self.assertEqual(prompt_input.placeholder, "subagent-name")

                prompt_input.value = "batch-organizer"
                await pilot.press("enter")
                await pilot.pause()

                prompt_input.value = "Organize files in batches and keep tool chatter low."
                await pilot.press("enter")
                await pilot.pause()

                self.assertEqual(app._picker_mode, "agent-skills")
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

                self.assertEqual(app._picker_mode, "agent-review")
                await pilot.press("enter")
                await pilot.pause()

        saved = AgentRegistry(config.agents_dir).load("batch-organizer")
        self.assertEqual(saved.name, "batch-organizer")
        self.assertIn("Organize files in batches", saved.system_prompt)

    async def test_agent_skill_picker_includes_cli_installed_skills(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        app = AgenCLIApp(config=config, config_path=self.config_path)
        cli_result = CliCommandResult(
            argv=("npx", "skills", "list"),
            returncode=0,
            stdout="",
            stderr="",
            ok=True,
            error_summary=None,
        )
        installed_records = [
            InstalledSkillRecord(
                name="frontend-design",
                details="Installed via Skills CLI (global).",
                scope="global",
                source="anthropics/skills",
                agents=["codex"],
                raw_line="frontend-design",
            )
        ]

        with patch("agencli.tui.app.list_installed_skills_cli", return_value=(cli_result, installed_records)):
            rows = app._available_attachable_skill_rows()

        self.assertTrue(any(row[0] == "frontend-design" for row in rows))

    async def test_select_skill_command_attaches_skills_to_current_thread(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        app = AgenCLIApp(config=config, config_path=self.config_path)
        cli_result = CliCommandResult(
            argv=("npx", "skills", "list"),
            returncode=0,
            stdout="",
            stderr="",
            ok=True,
            error_summary=None,
        )
        installed_records = [
            InstalledSkillRecord(
                name="frontend-design",
                details="Installed via Skills CLI (global).",
                scope="global",
                source="anthropics/skills",
                agents=["codex"],
                raw_line="frontend-design",
            )
        ]

        async with app.run_test() as pilot:
            with (
                patch("agencli.tui.app.list_installed_skills_cli", return_value=(cli_result, installed_records)),
                patch.object(app, "_ensure_attachable_skill_tokens", return_value=["frontend-design"]),
            ):
                app._run_slash_command("/select-skill")
                await pilot.pause()

            self.assertEqual(app._picker_mode, "thread-skills")
            await pilot.press("down")
            await pilot.pause()
            await pilot.press("space")
            await pilot.pause()
            await pilot.press("enter")
            await pilot.pause()

            attached = app._thread_attached_skills("supervisor-agent")
            self.assertEqual(attached, ["frontend-design"])
            self.assertIsNone(app._picker_mode)
            conversation = app.query_one("#conversation")
            self.assertIn("Thread Skills", str(conversation.visual))

    async def test_agent_skill_submit_uses_normalized_attachable_tokens(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        app = AgenCLIApp(config=config, config_path=self.config_path)
        app._subagent_editor = SubagentEditorState(
            mode="new",
            name="frontend-agent",
            system_prompt="help with frontend work",
            step="skills",
        )
        app._picker_mode = "agent-skills"
        app._picker_rows = [("frontend-design", "frontend-design", "Installed via Skills CLI (global).")]
        app._picker_marks = {"frontend-design"}

        with (
            patch.object(app, "_ensure_attachable_skill_tokens", return_value=["frontend-design"]),
            patch.object(app, "_append_transcript"),
            patch.object(app, "_request_subagent_review") as review_mock,
        ):
            handled = app._submit_subagent_manager("")

        self.assertTrue(handled)
        self.assertEqual(app._subagent_editor.skills, ["frontend-design"])
        review_mock.assert_called_once()

    async def test_history_command_opens_inline_picker_and_loads_selected_thread(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        append_chat_turn(
            config.sessions_dir,
            "user",
            "show me thread one",
            agent_name="supervisor-agent",
            thread_id="supervisor-thread-1",
        )
        append_chat_turn(
            config.sessions_dir,
            "assistant",
            "thread one answer",
            agent_name="supervisor-agent",
            thread_id="supervisor-thread-1",
        )
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            app.action_open_history_browser()
            await pilot.pause()
            self.assertEqual(app._picker_mode, "history")

            await pilot.press("enter")
            await pilot.pause()

            conversation = app.query_one("#conversation")
            rendered = str(conversation.visual)
            self.assertIn("show me thread one", rendered)
            self.assertIn("thread one answer", rendered)

    async def test_skills_command_opens_inline_browser_root(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app.action_open_skills()
            await pilot.pause()

            self.assertEqual(app._picker_mode, "skills-root")
            picker = app.query_one("#picker")
            rendered = str(picker.visual)
            self.assertIn("Browse categories", rendered)
            self.assertIn("View installed skills", rendered)

    async def test_skills_search_renders_results_inline(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        cli_result = CliCommandResult(
            argv=("npx", "skills", "find", "react"),
            returncode=0,
            stdout="",
            stderr="",
            ok=True,
            error_summary=None,
        )
        parsed = [
            SkillSearchResult(
                name="frontend-design",
                description="Description not available from Skills CLI search output.",
                source="anthropics/skills",
                install_source="anthropics/skills",
                skill_name="frontend-design",
                skills_page_url="https://skills.sh/anthropics/skills/frontend-design",
                github_repo_url="https://github.com/anthropics/skills",
                install_count_text="212.6K installs",
                why_useful="Install `frontend-design` from `anthropics/skills`.",
                install_command=("npx", "skills", "add", "anthropics/skills", "--skill", "frontend-design", "-g", "-y"),
                quality=SkillResultQuality(score=5, labels=["trusted"]),
            )
        ]

        async with app.run_test() as pilot:
            with patch("agencli.tui.app.find_skills", return_value=(cli_result, parsed)):
                app.action_open_skills()
                await pilot.pause()
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                prompt_input.value = "react"
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

            self.assertEqual(app._picker_mode, "skills-results")
            picker = app.query_one("#picker")
            self.assertIn("frontend-design", str(picker.visual))
            self.assertEqual(app._skills_state.query, "react")

    async def test_skills_install_shows_confirmation_in_confirm_mode(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._approval_mode = "confirm"
            app._skills_state.pending_source = "vercel-labs/agent-skills"
            app._skills_state.pending_skill_name = "frontend-design"
            handled = app._handle_skills_install_request()
            await pilot.pause()

            self.assertTrue(handled)
            self.assertEqual(app._picker_mode, "skills-confirm-install")
            picker = app.query_one("#picker")
            self.assertIn("Continue", str(picker.visual))

    async def test_skills_check_renders_summary(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        cli_result = CliCommandResult(
            argv=("npx", "skills", "check"),
            returncode=0,
            stdout="",
            stderr="",
            ok=True,
            error_summary=None,
        )
        status = SkillsStatusResult(summary="2 updates available", items=["frontend-design", "docs-writer"], raw_output="")

        async with app.run_test() as pilot:
            with patch("agencli.tui.app.check_skills", return_value=(cli_result, status)):
                app._start_check_skills()
                await pilot.pause()
                await pilot.pause()

            conversation = app.query_one("#conversation")
            rendered = str(conversation.visual)
            self.assertIn("Skills Check", rendered)
            self.assertIn("2 updates available", rendered)

    async def test_mention_command_attaches_context_for_future_prompts(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        note_path = Path(config.workspace_dir) / "notes.txt"
        note_path.write_text("important context for the next run", encoding="utf-8")
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            app._run_slash_command(f"/mention {note_path}")
            await pilot.pause()

            self.assertEqual(len(app._mentioned_contexts), 1)
            augmented = app._augment_prompt("help me")
            self.assertIn("Attached context", augmented)
            self.assertIn("notes.txt", augmented)

    async def test_at_mention_completion_inserts_workspace_path(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        docs_dir = Path(config.workspace_dir) / "docs"
        docs_dir.mkdir()
        (docs_dir / "guide.md").write_text("guide", encoding="utf-8")
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            prompt_input.value = "@do"
            prompt_input.cursor_position = len(prompt_input.value)
            await pilot.pause()

            self.assertEqual(app._picker_mode, "mention")
            await pilot.press("enter")
            await pilot.pause()

            self.assertEqual(prompt_input.value, "@docs/ ")

    async def test_prompt_submit_resolves_at_mentions_into_attached_context(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        note_path = Path(config.workspace_dir) / "notes.txt"
        note_path.write_text("important context for mentions", encoding="utf-8")
        app = AgenCLIApp(config=config, config_path=self.config_path)
        attempted: list[tuple[str, str]] = []

        async def fake_run(agent_name: str, prompt: str, *, plan_phase=None) -> None:
            attempted.append((agent_name, prompt))

        async with app.run_test() as pilot:
            with patch.object(app, "_run_prompt", new=fake_run):
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                prompt_input.value = "review @notes.txt"
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

            self.assertEqual(attempted[0][1], "review notes.txt")
            self.assertTrue(any("notes.txt" in item.path for item in app._mentioned_contexts))

    async def test_compact_command_builds_structured_session_summary(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._append_transcript("> organize the downloads folder")
            app._append_transcript(f"{VISIBLE_BRAND}\nCreated a batch plan for files.")
            app._append_transcript("System\nWaiting for confirmation.")
            app._run_slash_command("/compact")
            await pilot.pause()

            self.assertIsNotNone(app._session_summary)
            self.assertIn("Session summary", app._session_summary)
            self.assertIn("Goal:", app._session_summary)
            conversation = app.query_one("#conversation")
            self.assertIn("Compact", str(conversation.visual))

    async def test_diff_command_renders_grouped_file_summary(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        diff_text = "\n".join(
            [
                "diff --git a/agencli/tui/app.py b/agencli/tui/app.py",
                "--- a/agencli/tui/app.py",
                "+++ b/agencli/tui/app.py",
                "@@ -1373,2 +1373,3 @@ async def _run_prompt",
                " async def _run_prompt(self, agent_name: str, prompt: str, *, plan_phase: bool | None = None) -> None:",
                "+    trace_table = None",
                "-    try:",
                "+    orchestration_table = None",
            ]
        )
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            with patch("agencli.tui.app.subprocess.run", return_value=SimpleNamespace(returncode=0, stdout=diff_text, stderr="")):
                app._run_slash_command("/diff")
                await pilot.pause()

            conversation = app.query_one("#conversation")
            rendered = str(conversation.visual)
            self.assertIn("Edited agencli/tui/app.py (+2 -1)", rendered)
            self.assertIn("trace_table = None", rendered)

    async def test_init_command_creates_project_specific_agents_md_and_loads_it(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        readme_path = Path(config.workspace_dir) / "README.md"
        readme_path.write_text("# AgenCLI\nA terminal coding shell.\n", encoding="utf-8")
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            app._run_slash_command("/init")
            await pilot.pause()

            agents_path = Path(config.workspace_dir) / "AGENTS.md"
            self.assertTrue(agents_path.exists())
            content = agents_path.read_text(encoding="utf-8")
            self.assertIn("A terminal coding shell.", content)
            self.assertIsNotNone(app._project_agents_context)

    async def test_plan_and_permissions_commands_update_shell_state(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._run_slash_command("/plan on")
            app._run_slash_command("/permissions read-only")
            app._run_slash_command("/personality collaborative")
            await pilot.pause()

            self.assertTrue(app._plan_mode)
            self.assertEqual(app._approval_mode, "read-only")
            self.assertEqual(app._personality, "collaborative")
            augmented = app._augment_prompt("inspect repo")
            self.assertIn("Plan mode is enabled", augmented)
            self.assertIn("read-only", augmented)
            self.assertIn("collaborative", augmented)

    async def test_plan_confirmation_continue_runs_execution_phase(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        attempted: list[tuple[str, str, bool | None]] = []

        async def fake_run(agent_name: str, prompt: str, *, plan_phase: bool | None = None) -> None:
            attempted.append((agent_name, prompt, plan_phase))

        async with app.run_test() as pilot:
            app._start_plan_confirmation(agent_name="supervisor-agent", prompt="organize downloads", plan_text="1. scan 2. move")
            with patch.object(app, "_run_prompt", new=fake_run):
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                prompt_input.value = "continue"
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

            self.assertIsNone(app._human_loop)
            self.assertEqual(attempted, [("supervisor-agent", unittest.mock.ANY, False)])
            self.assertIn("approved the plan", attempted[0][1])

    async def test_plan_confirmation_revise_stays_in_plan_phase(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        attempted: list[tuple[str, str, bool | None]] = []

        async def fake_run(agent_name: str, prompt: str, *, plan_phase: bool | None = None) -> None:
            attempted.append((agent_name, prompt, plan_phase))

        async with app.run_test() as pilot:
            app._start_plan_confirmation(agent_name="supervisor-agent", prompt="organize downloads", plan_text="1. scan 2. move")
            with patch.object(app, "_run_prompt", new=fake_run):
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                prompt_input.value = "revise to show the folder map first"
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

            self.assertIsNone(app._human_loop)
            self.assertEqual(attempted, [("supervisor-agent", unittest.mock.ANY, True)])
            self.assertIn("Update the plan only", attempted[0][1])

    async def test_fork_command_copies_current_thread_history(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        append_chat_turn(
            config.sessions_dir,
            "user",
            "base thread prompt",
            agent_name="supervisor-agent",
            thread_id="default:supervisor-agent",
        )
        append_chat_turn(
            config.sessions_dir,
            "assistant",
            "base thread answer",
            agent_name="supervisor-agent",
            thread_id="default:supervisor-agent",
        )
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            app._run_slash_command("/fork")
            await pilot.pause()

            thread_id = app._active_thread_id("supervisor-agent")
            self.assertNotEqual(thread_id, "default:supervisor-agent")
            conversation = app.query_one("#conversation")
            rendered = str(conversation.visual)
            self.assertIn("base thread prompt", rendered)
            self.assertIn("base thread answer", rendered)

    async def test_reset_command_restores_fresh_default_session_state(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        append_chat_turn(
            config.sessions_dir,
            "user",
            "default thread prompt",
            agent_name="supervisor-agent",
            thread_id="default:supervisor-agent",
        )
        append_chat_turn(
            config.sessions_dir,
            "assistant",
            "default thread answer",
            agent_name="supervisor-agent",
            thread_id="default:supervisor-agent",
        )
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            app._session_summary = "old summary"
            app._mentioned_contexts.append(SimpleNamespace(path="notes.txt", summary="old note"))
            app._active_threads["supervisor-agent"] = "default:supervisor-agent:abcd1234"
            app._append_transcript("> stale prompt")
            await pilot.pause()

            app._run_slash_command("/reset")
            await pilot.pause()
            await pilot.pause()

            self.assertEqual(app._active_thread_id("supervisor-agent"), "default:supervisor-agent")
            self.assertIsNone(app._session_summary)
            self.assertEqual(app._mentioned_contexts, [])
            self.assertIsNone(app._human_loop)
            conversation = app.query_one("#conversation")
            rendered = str(conversation.visual)
            self.assertIn("Reset", rendered)
            self.assertIn("fresh default session", rendered)
            self.assertNotIn("stale prompt", rendered)
            self.assertNotIn("default thread prompt", rendered)

    async def test_voice_toggle_appends_transcript_to_prompt(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        with patch("agencli.tui.app.transcribe_once", new=AsyncMock(return_value="hello from voice")):
            async with app.run_test() as pilot:
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                prompt_input.value = "draft"
                app.action_toggle_voice_input()
                await pilot.pause()
                await pilot.pause()
                self.assertEqual(prompt_input.value, "draft hello from voice")
                self.assertFalse(app._voice_listening)

    async def test_transcript_accepts_raw_html_like_text_without_markup_errors(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._append_transcript('[system] {"content":"<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"></head>"}')
            await pilot.pause()
            conversation = app.query_one("#conversation")
            self.assertIn("<!DOCTYPE html>", str(conversation.visual))

    async def test_tool_events_render_as_compact_blocks_with_running_status(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._set_run_state(True, "Tool call: write_file")
            app._append_stream_event(
                StreamEvent(
                    kind="tool",
                    label="write_file",
                    text='{"file_path":"C:/tmp/todo-app.html","content":"<!DOCTYPE html><html lang=\\"en\\">"}',
                    phase="start",
                )
            )
            await pilot.pause()
            conversation = app.query_one("#conversation")
            hint_line = app.query_one("#hint-line")
            rendered = str(conversation.visual)
            self.assertIn("Tool call", rendered)
            self.assertIn("todo-app.html", rendered)
            self.assertNotIn("<!DOCTYPE html>", rendered)
            self.assertIn("Tool call: write_file", str(hint_line.visual))

    async def test_initial_onboarding_runs_as_multistep_chat_flow(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="", model=""), config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)

            self.assertEqual(prompt_input.placeholder, "Choose a provider with Up/Down, then press Enter")

            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(prompt_input.placeholder, "API key (hidden in chat log)")

            prompt_input.value = ""
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(prompt_input.placeholder, "https://api.openai.com/v1")

            prompt_input.value = ""
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(prompt_input.placeholder, "gpt-4.1")

            prompt_input.value = ""
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(prompt_input.placeholder, f'Try "/help" or ask {VISIBLE_BRAND} to inspect the workspace')
            self.assertIsNone(app._onboarding)
            conversation = app.query_one("#conversation")
            rendered = str(conversation.visual)
            self.assertIn("Setup", rendered)
            self.assertNotIn("[setup]", rendered)

        updated = load_config(self.config_path)
        self.assertEqual(updated.openai_compatible.base_url, "https://api.openai.com/v1")
        self.assertEqual(updated.openai_compatible.model, "gpt-4.1")

    async def test_permission_error_enters_human_loop_and_prompts_for_input(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._maybe_start_human_loop(
                agent_name="coding-agent",
                prompt="empty the trash",
                error_message="Permission denied: sudo password is required",
            )
            await pilot.pause()

            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            conversation = app.query_one("#conversation")

            self.assertIsNotNone(app._human_loop)
            self.assertIn("permission", prompt_input.placeholder.lower())
            self.assertIn("Need Input", str(conversation.visual))

    async def test_destructive_prompt_enters_preflight_human_loop_before_run(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            triggered = app._maybe_start_preflight_human_loop(
                agent_name="coding-agent",
                prompt="empty my trash",
            )
            await pilot.pause()

            self.assertTrue(triggered)
            self.assertIsNotNone(app._human_loop)
            self.assertEqual(app._human_loop.kind, "preflight")
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            picker = app.query_one("#picker")
            self.assertIn("continue", prompt_input.placeholder.lower())
            self.assertIn("destructive", app._human_loop.request_text.lower())
            self.assertEqual(app._picker_mode, "human-loop")
            self.assertIn("Continue", str(picker.visual))

    async def test_bulk_and_privileged_prompt_mentions_multiple_preflight_categories(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            triggered = app._maybe_start_preflight_human_loop(
                agent_name="coding-agent",
                prompt="use sudo to organize my downloads folder",
            )
            await pilot.pause()

            self.assertTrue(triggered)
            self.assertIsNotNone(app._human_loop)
            request_text = app._human_loop.request_text.lower()
            self.assertIn("privileged", request_text)
            self.assertIn("bulk-filesystem", request_text)
            self.assertIn("show commands only", request_text)

    async def test_human_loop_submission_retries_prompt_with_user_input(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        attempted: list[tuple[str, str]] = []

        async def fake_run(agent_name: str, prompt: str) -> None:
            attempted.append((agent_name, prompt))

        async with app.run_test() as pilot:
            app._human_loop = HumanLoopState(
                agent_name="coding-agent",
                original_prompt="empty the trash",
                error_message="Permission denied",
                request_text="Need input",
                placeholder="Type guidance",
                sensitive=False,
            )
            with patch.object(app, "_run_prompt", new=fake_run):
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                prompt_input.placeholder = app._human_loop.placeholder
                prompt_input.value = "skip the privileged delete and tell me how to do it manually"
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

            self.assertIsNone(app._human_loop)
            self.assertEqual(len(attempted), 1)
            self.assertEqual(attempted[0][0], "coding-agent")
            self.assertIn("Additional input from the user", attempted[0][1])
            self.assertIn("skip the privileged delete", attempted[0][1])

    async def test_preflight_continue_retries_with_explicit_approval(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        attempted: list[tuple[str, str]] = []

        async def fake_run(agent_name: str, prompt: str) -> None:
            attempted.append((agent_name, prompt))

        async with app.run_test() as pilot:
            app._human_loop = HumanLoopState(
                agent_name="coding-agent",
                original_prompt="empty my trash",
                error_message="",
                request_text="Need input",
                placeholder="Type continue",
                kind="preflight",
                sensitive=False,
            )
            with patch.object(app, "_run_prompt", new=fake_run):
                prompt_input = app.query_one("#prompt-input", ShellPromptInput)
                prompt_input.placeholder = app._human_loop.placeholder
                prompt_input.value = "continue"
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

            self.assertIsNone(app._human_loop)
            self.assertEqual(len(attempted), 1)
            self.assertIn("explicitly approved", attempted[0][1])
            self.assertIn("empty my trash", attempted[0][1])

    async def test_preflight_picker_option_can_submit_without_typed_text(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        attempted: list[tuple[str, str]] = []

        async def fake_run(agent_name: str, prompt: str) -> None:
            attempted.append((agent_name, prompt))

        async with app.run_test() as pilot:
            triggered = app._maybe_start_preflight_human_loop(
                agent_name="coding-agent",
                prompt="empty my trash",
            )
            self.assertTrue(triggered)
            with patch.object(app, "_run_prompt", new=fake_run):
                await pilot.press("enter")
                await pilot.pause()
                await pilot.pause()

            self.assertIsNone(app._human_loop)
            self.assertEqual(len(attempted), 1)
            self.assertIn("explicitly approved", attempted[0][1])

    async def test_cancel_command_dismisses_human_loop(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._human_loop = HumanLoopState(
                agent_name="coding-agent",
                original_prompt="empty the trash",
                error_message="Permission denied",
                request_text="Need input",
                placeholder="Type guidance",
                sensitive=False,
            )
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            prompt_input.placeholder = app._human_loop.placeholder
            prompt_input.value = "/cancel"
            await pilot.press("enter")
            await pilot.pause()

            self.assertIsNone(app._human_loop)
            self.assertFalse(prompt_input.password)

    async def test_selecting_history_thread_loads_persisted_chat_into_transcript(self) -> None:
        config = self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1")
        append_chat_turn(
            config.sessions_dir,
            "user",
            "show me the earlier thread",
            agent_name="supervisor-agent",
            thread_id="supervisor-thread-1",
        )
        append_chat_turn(
            config.sessions_dir,
            "assistant",
            "Here is the earlier result.",
            agent_name="supervisor-agent",
            thread_id="supervisor-thread-1",
        )
        app = AgenCLIApp(config=config, config_path=self.config_path)

        async with app.run_test() as pilot:
            app._handle_thread_selection(
                ThreadSelection(
                    agent_name="supervisor-agent",
                    thread_id="supervisor-thread-1",
                    created_new=False,
                )
            )
            await pilot.pause()

            conversation = app.query_one("#conversation")
            rendered = str(conversation.visual)
            self.assertIn("show me the earlier thread", rendered)
            self.assertIn("Here is the earlier result.", rendered)

    async def test_escape_interrupts_active_run(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)
        worker = SimpleNamespace(is_finished=False, cancelled=False)

        def cancel() -> None:
            worker.cancelled = True

        worker.cancel = cancel

        async with app.run_test() as pilot:
            app._active_agent_worker = worker
            app._set_run_state(True, "Working with coding-agent")
            await pilot.press("escape")
            await pilot.pause()
            hint_line = app.query_one("#hint-line")
            self.assertNotIn("Ctrl+C again", str(hint_line.visual))

            self.assertTrue(worker.cancelled)
            self.assertFalse(app._run_active)
            self.assertEqual(app._ctrl_c_armed_at, 0.0)
            conversation = app.query_one("#conversation")
            self.assertIn("Interrupted the current run.", str(conversation.visual))

    async def test_ctrl_c_uses_copy_when_selection_exists(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._active_agent_worker = SimpleNamespace(is_finished=False, cancel=lambda: None)
            app._set_run_state(True, "Working with coding-agent")
            with patch.object(app, "_copy_selected_text", return_value=True) as copy_selected:
                await pilot.press("ctrl+c")
                await pilot.pause()

            copy_selected.assert_called_once()
            self.assertFalse(app._ctrl_c_armed_at)
            self.assertTrue(app._run_active)

    async def test_ctrl_shift_c_uses_copy_path_without_interrupt_arming(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._active_agent_worker = SimpleNamespace(is_finished=False, cancel=lambda: None)
            app._set_run_state(True, "Working with coding-agent")
            with patch.object(app, "_copy_selected_text", return_value=True) as copy_selected:
                app.action_copy_selection()
                await pilot.pause()

            copy_selected.assert_called_once()
            self.assertFalse(app._ctrl_c_armed_at)
            self.assertTrue(app._run_active)

    async def test_paste_clipboard_inserts_text_into_prompt(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            with patch.object(prompt_input, "action_paste") as action_paste:
                app.action_paste_clipboard()
                await pilot.pause()

            action_paste.assert_called_once()

    async def test_copy_to_clipboard_also_writes_to_system_clipboard(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            with patch("textual.app.App.copy_to_clipboard") as base_copy, patch.object(
                app, "_write_system_clipboard", return_value=True
            ) as system_copy:
                app.copy_to_clipboard("copied text")
                await pilot.pause()

            base_copy.assert_called_once_with("copied text")
            system_copy.assert_called_once_with("copied text")

    async def test_paste_clipboard_falls_back_to_system_clipboard(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            with patch.object(prompt_input, "action_paste", new=None), patch.object(
                app, "_read_system_clipboard", return_value="system clipboard text"
            ):
                app.action_paste_clipboard()
                await pilot.pause()

            self.assertEqual(prompt_input.value, "system clipboard text")

    async def test_click_without_selection_refocuses_prompt(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._append_transcript("> earlier output")
            await pilot.pause()
            conversation = app.query_one("#conversation")
            app.screen.set_focus(None)
            await pilot.pause()

            app.on_click(events.Click(conversation, 0, 0, 0, 0, 1, False, False, False))
            await pilot.pause()

            self.assertIs(app.focused, app.query_one("#prompt-input", ShellPromptInput))

    async def test_printable_key_refocuses_prompt_and_appends_text(self) -> None:
        app = AgenCLIApp(config=self._build_config(base_url="https://api.openai.com/v1", model="gpt-4.1"), config_path=self.config_path)

        async with app.run_test() as pilot:
            app._append_transcript("> earlier output")
            await pilot.pause()
            app.screen.set_focus(None)
            await pilot.pause()

            app.on_key(events.Key("a", "a"))
            await pilot.pause()

            prompt_input = app.query_one("#prompt-input", ShellPromptInput)
            self.assertIs(app.focused, prompt_input)
            self.assertEqual(prompt_input.value, "a")


if __name__ == "__main__":
    unittest.main()
