﻿from __future__ import annotations

import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from langgraph.constants import END, START
from langgraph.graph import StateGraph, add_messages
from langchain_core.messages import AIMessage, HumanMessage
from typing_extensions import Annotated, TypedDict

from agencli.agents.factory import AgentSpec, SubAgentSpec
from agencli.agents.management_tools import build_supervisor_management_tools
from agencli.agents.prebuilt.catalog import get_prebuilt_agents
from agencli.agents.registry import AgentRegistry
from agencli.core.config import AgenCLIConfig, OpenAICompatibleConfig
from agencli.agents.runtime import StreamEvent, build_prompt_payload, parse_stream_chunk
from agencli.core import session as session_module
from agencli.core.session import (
    ChatTurn,
    PersistentInMemoryCheckpointer,
    append_chat_turn,
    build_thread_config,
    clear_langgraph_checkpointer_cache,
    create_thread_id,
    delete_chat_thread,
    describe_langgraph_checkpointer,
    ensure_langgraph_checkpointer,
    get_thread_id,
    has_thread_checkpoint,
    list_chat_threads,
    load_chat_history,
    resolve_thread_id,
)
from agencli.providers.model import normalize_model_input
from agencli.tui.trace import OrchestrationLedger, TraceLedger


class MessageState(TypedDict):
    messages: Annotated[list, add_messages]


def _build_test_graph(checkpointer: PersistentInMemoryCheckpointer):
    builder = StateGraph(MessageState)

    def respond(state: MessageState) -> dict[str, list[tuple[str, str]]]:
        return {"messages": [("assistant", f"count={len(state['messages'])}")]}

    builder.add_node("respond", respond)
    builder.add_edge(START, "respond")
    builder.add_edge("respond", END)
    return builder.compile(checkpointer=checkpointer)


class RuntimeHelpersTest(unittest.TestCase):
    def tearDown(self) -> None:
        clear_langgraph_checkpointer_cache()

    def test_describe_langgraph_checkpointer_prefers_sqlite_when_available(self) -> None:
        class FakeSqliteSaver:
            def __init__(self, connection) -> None:
                self.connection = connection

            def get_tuple(self, _config):
                return None

        with TemporaryDirectory() as temp_dir:
            with patch.object(session_module, "SqliteSaver", FakeSqliteSaver):
                self.assertEqual(describe_langgraph_checkpointer(temp_dir), "sqlite")
                checkpointer = ensure_langgraph_checkpointer(temp_dir)

            self.assertIsInstance(checkpointer, FakeSqliteSaver)
            self.assertTrue(Path(temp_dir, "default.langgraph.sqlite3").exists())
            checkpointer.connection.close()

    def test_describe_langgraph_checkpointer_keeps_legacy_files_active(self) -> None:
        class FakeSqliteSaver:
            def __init__(self, connection) -> None:
                self.connection = connection

            def get_tuple(self, _config):
                return None

        with TemporaryDirectory() as temp_dir:
            base_path = Path(temp_dir) / "default.langgraph"
            graph = _build_test_graph(PersistentInMemoryCheckpointer(base_path))
            graph.invoke({"messages": [("user", "persist legacy")]}, config=build_thread_config("coding-agent"))

            with patch.object(session_module, "SqliteSaver", FakeSqliteSaver):
                self.assertEqual(describe_langgraph_checkpointer(temp_dir), "persistent-memory")
                checkpointer = ensure_langgraph_checkpointer(temp_dir)

            self.assertIsInstance(checkpointer, PersistentInMemoryCheckpointer)

    def test_build_prompt_payload_replays_history_before_current_prompt(self) -> None:
        history = [
            ChatTurn(role="user", content="first question", created_at="2026-03-27T00:00:00Z"),
            ChatTurn(role="assistant", content="first answer", created_at="2026-03-27T00:00:01Z"),
            ChatTurn(role="system", content="context", created_at="2026-03-27T00:00:02Z"),
        ]

        payload = build_prompt_payload("new question", history=history)

        self.assertEqual(
            payload,
            {
                "messages": [
                    {"role": "user", "content": "first question"},
                    {"role": "assistant", "content": "first answer"},
                    {"role": "system", "content": "context"},
                    {"role": "user", "content": "new question"},
                ]
            },
        )

    def test_build_prompt_payload_skips_empty_and_unknown_history_turns(self) -> None:
        history = [
            ChatTurn(role="tool", content="tool output", created_at="2026-03-27T00:00:00Z"),
            ChatTurn(role="assistant", content="   ", created_at="2026-03-27T00:00:01Z"),
        ]

        payload = build_prompt_payload("prompt", history=history)

        self.assertEqual(payload, {"messages": [{"role": "user", "content": "prompt"}]})

    def test_normalize_model_input_flattens_structured_content_blocks(self) -> None:
        payload = {
            "messages": [
                HumanMessage(content="plain"),
                AIMessage(content=[{"type": "text", "text": "step one"}, {"type": "text", "text": "step two"}]),
                {"role": "tool", "content": [{"text": "tool result"}, {"type": "text", "text": "continued"}]},
                ("assistant", [{"type": "text", "text": "tuple text"}]),
            ]
        }

        normalized = normalize_model_input(payload)

        self.assertEqual(normalized["messages"][0].content, "plain")
        self.assertEqual(normalized["messages"][1].content, "step one\nstep two")
        self.assertEqual(normalized["messages"][2]["content"], "tool result\ncontinued")
        self.assertEqual(normalized["messages"][3], ("assistant", "tuple text"))

    def test_normalize_model_input_preserves_non_content_fields(self) -> None:
        payload = {
            "messages": [
                {
                    "role": "assistant",
                    "content": [{"text": "hello"}],
                    "tool_calls": [{"id": "call-1", "name": "ls", "args": {"path": "/tmp"}}],
                }
            ],
            "metadata": {"thread_id": "thread-1"},
        }

        normalized = normalize_model_input(payload)

        self.assertEqual(normalized["messages"][0]["content"], "hello")
        self.assertEqual(normalized["messages"][0]["tool_calls"][0]["name"], "ls")
        self.assertEqual(normalized["metadata"]["thread_id"], "thread-1")

    def test_parse_stream_chunk_emits_tool_and_assistant_events(self) -> None:
        chunk = {
            "model": {
                "messages": [
                    {
                        "type": "ai",
                        "content": "Done",
                        "tool_calls": [{"id": "call-1", "name": "read_file", "args": {"path": "README.md"}}],
                    }
                ]
            },
            "tools": {
                "messages": [
                    {
                        "type": "tool",
                        "name": "read_file",
                        "tool_call_id": "call-1",
                        "content": "file contents",
                    }
                ]
            },
        }

        events = parse_stream_chunk(chunk)

        self.assertEqual(
            [(event.kind, event.label, event.text) for event in events],
            [
                ("tool", "read_file", '{"path": "README.md"}'),
                ("assistant", "assistant", "Done"),
                ("tool", "read_file", "file contents"),
            ],
        )
        self.assertEqual(events[0].phase, "start")
        self.assertEqual(events[0].trace_id, "call-1")
        self.assertEqual(events[2].phase, "end")
        self.assertEqual(events[2].trace_id, "call-1")

    def test_parse_stream_chunk_emits_state_summary_for_non_message_payloads(self) -> None:
        chunk = {"planner": {"next": "tools", "step": 2}}

        events = parse_stream_chunk(chunk)

        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].kind, "state")
        self.assertEqual(events[0].label, "planner")
        self.assertIn('"next": "tools"', events[0].text)

    def test_parse_stream_chunk_emits_subagent_events_for_task_tool_calls(self) -> None:
        chunk = {
            "supervisor.task": {
                "messages": [
                    {
                        "type": "ai",
                        "content": "",
                        "tool_calls": [
                            {
                                "id": "task-1",
                                "name": "task",
                                "args": {
                                    "subagent_type": "coding-specialist",
                                    "description": "Implement the bug fix and report risks.",
                                },
                            }
                        ],
                    },
                    {
                        "type": "tool",
                        "name": "task",
                        "tool_call_id": "task-1",
                        "content": "Implemented the fix and ran tests.",
                    },
                ]
            }
        }

        events = parse_stream_chunk(chunk)

        self.assertEqual(
            [(event.kind, event.label, event.phase, event.trace_id) for event in events],
            [
                ("subagent", "coding-specialist", "start", "task-1"),
                ("subagent", "task", "end", "task-1"),
            ],
        )
        self.assertIn("Implement the bug fix", events[0].text)
        self.assertEqual(events[1].text, "Implemented the fix and ran tests.")

    def test_chat_history_can_filter_by_agent_and_thread(self) -> None:
        with TemporaryDirectory() as temp_dir:
            append_chat_turn(
                temp_dir,
                "user",
                "hello from coding",
                agent_name="coding-agent",
                thread_id=get_thread_id("coding-agent"),
            )
            append_chat_turn(
                temp_dir,
                "user",
                "hello from shell",
                agent_name="shell-agent",
                thread_id=get_thread_id("shell-agent"),
            )

            coding_history = load_chat_history(
                temp_dir,
                agent_name="coding-agent",
                thread_id=get_thread_id("coding-agent"),
            )

            self.assertEqual(len(coding_history), 1)
            self.assertEqual(coding_history[0].content, "hello from coding")
            self.assertEqual(coding_history[0].agent_name, "coding-agent")

    def test_list_chat_threads_returns_latest_threads_first(self) -> None:
        with TemporaryDirectory() as temp_dir:
            append_chat_turn(
                temp_dir,
                "user",
                "coding first",
                agent_name="coding-agent",
                thread_id=get_thread_id("coding-agent"),
            )
            append_chat_turn(
                temp_dir,
                "assistant",
                "shell latest",
                agent_name="shell-agent",
                thread_id=get_thread_id("shell-agent"),
            )

            threads = list_chat_threads(temp_dir)

            self.assertEqual(len(threads), 2)
            self.assertEqual(threads[0].agent_name, "shell-agent")
            self.assertEqual(threads[0].last_content, "shell latest")
            self.assertEqual(threads[1].agent_name, "coding-agent")

    def test_list_chat_threads_can_filter_by_agent(self) -> None:
        with TemporaryDirectory() as temp_dir:
            append_chat_turn(
                temp_dir,
                "user",
                "coding one",
                agent_name="coding-agent",
                thread_id=get_thread_id("coding-agent"),
            )
            append_chat_turn(
                temp_dir,
                "user",
                "shell one",
                agent_name="shell-agent",
                thread_id=get_thread_id("shell-agent"),
            )

            threads = list_chat_threads(temp_dir, agent_name="coding-agent")

            self.assertEqual(len(threads), 1)
            self.assertEqual(threads[0].agent_name, "coding-agent")
            self.assertEqual(threads[0].thread_id, get_thread_id("coding-agent"))

    def test_list_chat_threads_can_filter_by_thread_and_query(self) -> None:
        with TemporaryDirectory() as temp_dir:
            default_thread_id = get_thread_id("coding-agent")
            review_thread_id = create_thread_id("coding-agent")
            append_chat_turn(
                temp_dir,
                "user",
                "default history",
                agent_name="coding-agent",
                thread_id=default_thread_id,
            )
            append_chat_turn(
                temp_dir,
                "assistant",
                "review this patch next",
                agent_name="coding-agent",
                thread_id=review_thread_id,
            )

            filtered = list_chat_threads(temp_dir, thread_id=review_thread_id)
            searched = list_chat_threads(temp_dir, query="review this")

            self.assertEqual(len(filtered), 1)
            self.assertEqual(filtered[0].thread_id, review_thread_id)
            self.assertEqual(len(searched), 1)
            self.assertEqual(searched[0].thread_id, review_thread_id)

    def test_resolve_thread_id_supports_default_explicit_and_new_threads(self) -> None:
        default_thread_id = resolve_thread_id("coding-agent")
        explicit_thread_id = resolve_thread_id("coding-agent", thread_id="custom-thread")
        new_thread_id = resolve_thread_id("coding-agent", new_thread=True)

        self.assertEqual(default_thread_id, get_thread_id("coding-agent"))
        self.assertEqual(explicit_thread_id, "custom-thread")
        self.assertNotEqual(new_thread_id, default_thread_id)
        self.assertTrue(new_thread_id.startswith(f"{default_thread_id}:"))

    def test_has_thread_checkpoint_can_target_non_default_thread(self) -> None:
        with TemporaryDirectory() as temp_dir:
            thread_id = create_thread_id("coding-agent")
            self.assertFalse(has_thread_checkpoint(temp_dir, "coding-agent", thread_id=thread_id))

            graph = _build_test_graph(ensure_langgraph_checkpointer(temp_dir))
            graph.invoke(
                {"messages": [("user", "persist alternate thread")]},
                config=build_thread_config("coding-agent", thread_id=thread_id),
            )

            self.assertTrue(has_thread_checkpoint(temp_dir, "coding-agent", thread_id=thread_id))
            self.assertFalse(has_thread_checkpoint(temp_dir, "coding-agent"))
            clear_langgraph_checkpointer_cache()

    def test_persistent_checkpointer_restores_thread_state_across_instances(self) -> None:
        with TemporaryDirectory() as temp_dir:
            base_path = Path(temp_dir) / "default.langgraph"
            thread_config = build_thread_config("coding-agent")

            first_graph = _build_test_graph(PersistentInMemoryCheckpointer(base_path))
            first_result = first_graph.invoke({"messages": [("user", "first")]}, config=thread_config)
            self.assertEqual(first_result["messages"][-1].content, "count=1")

            second_graph = _build_test_graph(PersistentInMemoryCheckpointer(base_path))
            second_result = second_graph.invoke({"messages": [("user", "second")]}, config=thread_config)

            self.assertEqual(second_result["messages"][-1].content, "count=3")

    def test_has_thread_checkpoint_reflects_saved_state(self) -> None:
        with TemporaryDirectory() as temp_dir:
            self.assertFalse(has_thread_checkpoint(temp_dir, "coding-agent"))

            graph = _build_test_graph(ensure_langgraph_checkpointer(temp_dir))
            graph.invoke({"messages": [("user", "persist me")]}, config=build_thread_config("coding-agent"))

            self.assertTrue(has_thread_checkpoint(temp_dir, "coding-agent"))
            clear_langgraph_checkpointer_cache()

    def test_delete_chat_thread_removes_only_matching_thread_rows(self) -> None:
        with TemporaryDirectory() as temp_dir:
            append_chat_turn(
                temp_dir,
                "user",
                "keep me",
                agent_name="coding-agent",
                thread_id="thread-keep",
            )
            append_chat_turn(
                temp_dir,
                "assistant",
                "delete me",
                agent_name="coding-agent",
                thread_id="thread-delete",
            )

            removed = delete_chat_thread(
                temp_dir,
                agent_name="coding-agent",
                thread_id="thread-delete",
            )

            self.assertEqual(removed, 1)
            remaining = load_chat_history(temp_dir, agent_name="coding-agent", limit=10)
            self.assertEqual(len(remaining), 1)
            self.assertEqual(remaining[0].thread_id, "thread-keep")

    def test_trace_ledger_groups_tool_start_and_end_into_one_row(self) -> None:
        ledger = TraceLedger()

        ledger.begin_run("coding-agent", "default:coding-agent")
        ledger.record(
            StreamEvent(
                kind="tool",
                label="read_file",
                text='{"path": "README.md"}',
                phase="start",
                trace_id="call-1",
            )
        )
        ledger.record(
            StreamEvent(
                kind="tool",
                label="read_file",
                text="file contents",
                phase="end",
                trace_id="call-1",
            )
        )

        self.assertEqual(len(ledger.rows), 2)
        tool_row = ledger.rows[-1]
        self.assertEqual(tool_row.kind, "tool")
        self.assertEqual(tool_row.status, "done")
        self.assertIn('{"path": "README.md"}', tool_row.detail)
        self.assertIn("file contents", tool_row.detail)

    def test_trace_ledger_keeps_state_updates_as_separate_rows(self) -> None:
        ledger = TraceLedger()

        ledger.record(StreamEvent(kind="state", label="planner", text='{"step": 1}', phase="update"))
        ledger.record(StreamEvent(kind="state", label="planner", text='{"step": 2}', phase="update"))

        self.assertEqual(len(ledger.rows), 2)
        self.assertEqual([row.status for row in ledger.rows], ["update", "update"])

    def test_trace_ledger_groups_subagent_start_and_end_into_one_row(self) -> None:
        ledger = TraceLedger()

        ledger.record(
            StreamEvent(
                kind="subagent",
                label="coding-specialist",
                text="Implement the patch.",
                phase="start",
                trace_id="task-1",
            )
        )
        ledger.record(
            StreamEvent(
                kind="subagent",
                label="task",
                text="Implemented and verified.",
                phase="end",
                trace_id="task-1",
            )
        )

        self.assertEqual(len(ledger.rows), 1)
        self.assertEqual(ledger.rows[0].kind, "subagent")
        self.assertEqual(ledger.rows[0].status, "done")
        self.assertIn("Implement the patch.", ledger.rows[0].detail)
        self.assertIn("Implemented and verified.", ledger.rows[0].detail)

    def test_orchestration_ledger_updates_configured_subagent_status(self) -> None:
        ledger = OrchestrationLedger()
        ledger.configure(
            [
                {
                    "name": "coding-specialist",
                    "role": "Implementation helper",
                    "tools": "mcp: filesystem, cmd",
                    "detail": "Ready for delegation.",
                }
            ]
        )

        ledger.record(
            StreamEvent(
                kind="subagent",
                label="coding-specialist",
                text="Investigate the failure and patch it.",
                phase="start",
                trace_id="task-1",
            )
        )
        ledger.record(
            StreamEvent(
                kind="subagent",
                label="task",
                text="Patched the code and reran tests.",
                phase="end",
                trace_id="task-1",
            )
        )

        self.assertEqual(len(ledger.rows), 1)
        self.assertEqual(ledger.rows[0].name, "coding-specialist")
        self.assertEqual(ledger.rows[0].status, "done")
        self.assertIn("Investigate the failure", ledger.rows[0].detail)
        self.assertIn("Patched the code", ledger.rows[0].detail)

    def test_prebuilt_catalog_includes_supervisor_agent(self) -> None:
        agents = get_prebuilt_agents("openai:gpt-4.1")

        self.assertIn("supervisor-agent", agents)
        self.assertGreaterEqual(len(agents["supervisor-agent"].subagents), 3)

    def test_filesystem_prompts_prefer_batched_organization_work(self) -> None:
        agents = get_prebuilt_agents("openai:gpt-4.1")

        filesystem_prompt = agents["filesystem-agent"].system_prompt.lower()
        supervisor_prompt = agents["supervisor-agent"].system_prompt.lower()
        filesystem_specialist = next(
            subagent for subagent in agents["supervisor-agent"].subagents if subagent.name == "filesystem-specialist"
        )
        specialist_prompt = filesystem_specialist.system_prompt.lower()

        self.assertIn("batched", filesystem_prompt)
        self.assertIn("grouped operations", filesystem_prompt)
        self.assertIn("batched", supervisor_prompt)
        self.assertIn("batched", specialist_prompt)
        self.assertIn("grouped", specialist_prompt)

    def test_all_prebuilt_agents_include_performance_guidance(self) -> None:
        agents = get_prebuilt_agents("openai:gpt-4.1")

        for name in ("filesystem-agent", "shell-agent", "search-agent", "coding-agent", "supervisor-agent"):
            prompt = agents[name].system_prompt.lower()
            self.assertIn("fewer", prompt, msg=name)
            self.assertIn("larger", prompt, msg=name)
            self.assertIn("avoid", prompt, msg=name)

    def test_supervisor_prompt_mentions_structured_subagent_and_skill_management(self) -> None:
        agents = get_prebuilt_agents("openai:gpt-4.1")

        prompt = agents["supervisor-agent"].system_prompt.lower()

        self.assertIn("structured management tools", prompt)
        self.assertIn("saved subagents", prompt)
        self.assertIn("marketplace", prompt)
        self.assertIn("confirmation", prompt)

    def test_supervisor_management_tools_expose_subagent_and_skill_actions(self) -> None:
        with TemporaryDirectory() as temp_dir:
            config = AgenCLIConfig(
                default_model="openai:gpt-4.1",
                workspace_dir=temp_dir,
                sessions_dir=temp_dir,
                agents_dir=temp_dir,
                skills_dir=temp_dir,
                mcp_config_path=str(Path(temp_dir) / "mcp.json"),
                openai_compatible=OpenAICompatibleConfig(base_url="https://api.openai.com/v1", model="gpt-4.1"),
            )

            tools = build_supervisor_management_tools(config)
            names = {tool.name for tool in tools}

            self.assertIn("list_saved_subagents", names)
            self.assertIn("save_subagent", names)
            self.assertIn("set_active_subagents", names)
            self.assertIn("list_attachable_skills", names)
            self.assertIn("search_marketplace_skills", names)
            self.assertIn("install_marketplace_skill", names)

    def test_supervisor_save_subagent_tool_persists_and_can_activate(self) -> None:
        with TemporaryDirectory() as temp_dir:
            config = AgenCLIConfig(
                default_model="openai:gpt-4.1",
                workspace_dir=temp_dir,
                sessions_dir=temp_dir,
                agents_dir=str(Path(temp_dir) / "agents"),
                skills_dir=str(Path(temp_dir) / "skills"),
                mcp_config_path=str(Path(temp_dir) / "mcp.json"),
                openai_compatible=OpenAICompatibleConfig(base_url="https://api.openai.com/v1", model="gpt-4.1"),
            )
            Path(config.agents_dir).mkdir()
            Path(config.skills_dir).mkdir()
            tools = {tool.name: tool for tool in build_supervisor_management_tools(config)}

            payload = json.loads(
                tools["save_subagent"].invoke(
                    {
                        "name": "frontend-agent",
                        "system_prompt": "Build polished frontend interfaces.",
                        "description": "Frontend specialist.",
                        "skills": ["frontend-design"],
                        "activate": True,
                    }
                )
            )

            self.assertEqual(payload["saved"], "frontend-agent")
            registry = AgentRegistry(config.agents_dir)
            saved = registry.load("frontend-agent")
            self.assertEqual(saved.skills, ["frontend-design"])
            self.assertIn("frontend-agent", registry.load_active_names())

    def test_supervisor_search_marketplace_tool_wraps_skills_cli_search(self) -> None:
        with TemporaryDirectory() as temp_dir:
            config = AgenCLIConfig(
                default_model="openai:gpt-4.1",
                workspace_dir=temp_dir,
                sessions_dir=temp_dir,
                agents_dir=str(Path(temp_dir) / "agents"),
                skills_dir=str(Path(temp_dir) / "skills"),
                mcp_config_path=str(Path(temp_dir) / "mcp.json"),
                openai_compatible=OpenAICompatibleConfig(base_url="https://api.openai.com/v1", model="gpt-4.1"),
            )
            Path(config.agents_dir).mkdir()
            Path(config.skills_dir).mkdir()
            tools = {tool.name: tool for tool in build_supervisor_management_tools(config)}

            with patch("agencli.agents.management_tools.find_skills") as search_mock:
                from agencli.skills.cli_backend import CliCommandResult, SkillSearchResult, SkillResultQuality

                search_mock.return_value = (
                    CliCommandResult(
                        argv=("npx", "skills", "find", "frontend"),
                        returncode=0,
                        stdout="",
                        stderr="",
                        ok=True,
                        error_summary=None,
                    ),
                    [
                        SkillSearchResult(
                            name="frontend-design",
                            description="Frontend UI guidance",
                            source="anthropics/skills",
                            install_source="anthropics/skills",
                            skill_name="frontend-design",
                            skills_page_url="https://skills.sh/anthropics/skills/frontend-design",
                            github_repo_url="https://github.com/anthropics/skills",
                            install_count_text="212.6K installs",
                            why_useful="Useful for frontend work.",
                            install_command=("npx", "skills", "add", "anthropics/skills", "--skill", "frontend-design", "-g", "-y"),
                            quality=SkillResultQuality(score=5, labels=["trusted"]),
                        )
                    ],
                )
                payload = json.loads(tools["search_marketplace_skills"].invoke({"query": "frontend"}))

            self.assertTrue(payload["ok"])
            self.assertEqual(payload["results"][0]["name"], "frontend-design")
            self.assertIn("trusted", payload["results"][0]["trust"])

    def test_local_prebuilt_agents_do_not_require_filesystem_or_cmd_mcp_servers(self) -> None:
        agents = get_prebuilt_agents("openai:gpt-4.1")

        self.assertEqual(agents["filesystem-agent"].mcp_servers, [])
        self.assertEqual(agents["shell-agent"].mcp_servers, [])
        self.assertEqual(agents["coding-agent"].mcp_servers, [])

        supervisor = agents["supervisor-agent"]
        self.assertTrue(all(not subagent.mcp_servers for subagent in supervisor.subagents))

    def test_registry_round_trip_preserves_structured_subagents(self) -> None:
        with TemporaryDirectory() as temp_dir:
            registry = AgentRegistry(temp_dir)
            spec = AgentSpec(
                name="supervisor-test",
                model="openai:gpt-4.1",
                system_prompt="delegate work",
                subagents=[
                    SubAgentSpec(
                        name="coding-specialist",
                        description="Implementation helper",
                        system_prompt="Write code carefully.",
                        mcp_servers=["filesystem", "cmd"],
                    )
                ],
            )

            registry.save(spec)
            loaded = registry.load("supervisor-test")

            self.assertEqual(len(loaded.subagents), 1)
            self.assertIsInstance(loaded.subagents[0], SubAgentSpec)
            self.assertEqual(loaded.subagents[0].mcp_servers, ["filesystem", "cmd"])

    def test_registry_delete_removes_saved_agent_file(self) -> None:
        with TemporaryDirectory() as temp_dir:
            registry = AgentRegistry(temp_dir)
            spec = AgentSpec(
                name="temporary-agent",
                model="openai:gpt-4.1",
                system_prompt="Be helpful.",
            )

            saved_path = registry.save(spec)
            deleted_path = registry.delete(spec.name)

            self.assertEqual(saved_path, deleted_path)
            self.assertFalse(deleted_path.exists())
            self.assertEqual(registry.list_agents(), [])

    def test_registry_persists_active_saved_agent_names(self) -> None:
        with TemporaryDirectory() as temp_dir:
            registry = AgentRegistry(temp_dir)
            registry.save_active_names(["writer", "reviewer", "writer"])

            self.assertEqual(registry.load_active_names(), ["reviewer", "writer"])


if __name__ == "__main__":
    unittest.main()
