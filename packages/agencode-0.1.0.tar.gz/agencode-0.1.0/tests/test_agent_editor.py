from __future__ import annotations

import unittest

from agencli.agents.editor import (
    build_agent_spec_from_editor,
    copy_agent_spec_for_customization,
    format_token_list,
    parse_token_list,
    partition_skill_tokens,
    suggest_custom_agent_name,
)
from agencli.agents.factory import AgentSpec, SubAgentSpec


class AgentEditorHelpersTest(unittest.TestCase):
    def test_parse_and_format_token_lists_normalize_values(self) -> None:
        parsed = parse_token_list(" filesystem, cmd \nsearch, filesystem ")

        self.assertEqual(parsed, ["filesystem", "cmd", "search"])
        self.assertEqual(format_token_list(parsed), "filesystem, cmd, search")

    def test_partition_skill_tokens_separates_managed_and_extra_tokens(self) -> None:
        managed, extra = partition_skill_tokens(
            ["installed", "shell-safety", "/skills/project/", "shell-safety"],
            {"shell-safety", "web-research"},
        )

        self.assertEqual(managed, ["installed", "shell-safety"])
        self.assertEqual(extra, ["/skills/project/"])

    def test_suggest_custom_agent_name_avoids_existing_names(self) -> None:
        suggested = suggest_custom_agent_name("coding-agent", {"coding-agent", "coding-agent-custom"})

        self.assertEqual(suggested, "coding-agent-custom-2")

    def test_copy_agent_spec_for_customization_preserves_fields_and_renames(self) -> None:
        spec = AgentSpec(
            name="supervisor-agent",
            model="openai:gpt-4.1",
            description="Delegate work",
            system_prompt="Delegate carefully.",
            skills=["installed"],
            mcp_servers=["filesystem", "cmd"],
            subagents=[
                SubAgentSpec(
                    name="coding-specialist",
                    description="Write code",
                    system_prompt="Be precise.",
                )
            ],
        )

        copied = copy_agent_spec_for_customization(
            spec,
            existing_names={"supervisor-agent", "supervisor-agent-custom"},
            default_model="openai:gpt-4.1-mini",
        )

        self.assertEqual(copied.name, "supervisor-agent-custom-2")
        self.assertEqual(copied.description, spec.description)
        self.assertEqual(copied.skills, ["installed"])
        self.assertEqual(len(copied.subagents), 1)
        self.assertIsInstance(copied.subagents[0], SubAgentSpec)

    def test_build_agent_spec_from_editor_updates_lists_and_preserves_subagents(self) -> None:
        base_spec = AgentSpec(
            name="coding-agent-custom",
            model="openai:gpt-4.1",
            description="Implement changes",
            system_prompt="Edit carefully.",
            skills=["shell-safety"],
            mcp_servers=["filesystem"],
            subagents=[
                SubAgentSpec(
                    name="reviewer",
                    description="Review work",
                    system_prompt="Spot regressions.",
                )
            ],
        )

        updated = build_agent_spec_from_editor(
            base_spec=base_spec,
            name="coding-agent-team",
            model="openai:gpt-4.1-mini",
            description="Team coding helper",
            system_prompt="Inspect files first.",
            workspace_dir="D:/workspace/project",
            mcp_servers_raw="filesystem, cmd",
            selected_skill_tokens=["installed", "shell-safety"],
            extra_skill_tokens_raw="/skills/project/, shell-safety",
        )

        self.assertEqual(updated.name, "coding-agent-team")
        self.assertEqual(updated.model, "openai:gpt-4.1-mini")
        self.assertEqual(updated.description, "Team coding helper")
        self.assertEqual(updated.workspace_dir, "D:/workspace/project")
        self.assertEqual(updated.mcp_servers, ["filesystem", "cmd"])
        self.assertEqual(updated.skills, ["installed", "shell-safety", "/skills/project/"])
        self.assertEqual(len(updated.subagents), 1)


if __name__ == "__main__":
    unittest.main()
