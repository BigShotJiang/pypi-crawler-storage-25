from __future__ import annotations

import asyncio
import unittest
from unittest.mock import patch

from agencli.mcp.config import default_mcp_servers
from agencli.tools.mcp import load_mcp_tools


class MCPToolLoaderTest(unittest.TestCase):
    def test_default_mcp_servers_only_bootstraps_search(self) -> None:
        servers = default_mcp_servers("/tmp/workspace")

        self.assertEqual(set(servers), {"search"})

    def test_load_mcp_tools_supports_running_event_loop(self) -> None:
        async def fake_get_tools(self, server_names=None):
            return ["demo-tool", *(server_names or [])]

        async def run_inside_loop() -> list[str]:
            return load_mcp_tools("unused.json", server_names=["search"])

        with (
            patch("agencli.tools.mcp.MCPToolClient.load_server_map", return_value={"search": {"url": "https://example.invalid/mcp"}}),
            patch("agencli.tools.mcp.MCPToolClient.get_tools", fake_get_tools),
        ):
            result = asyncio.run(run_inside_loop())

        self.assertEqual(result, ["demo-tool", "search"])

    def test_load_mcp_tools_skips_unavailable_servers_and_collects_diagnostics(self) -> None:
        async def fake_get_tools(self, server_names=None):
            if server_names == ["filesystem"]:
                raise FileNotFoundError(2, "The system cannot find the file specified")
            return [f"tool-{server_names[0]}"]

        diagnostics: list[str] = []
        with (
            patch(
                "agencli.tools.mcp.MCPToolClient.load_server_map",
                return_value={
                    "filesystem": {"command": "npx"},
                    "search": {"url": "https://example.invalid/mcp"},
                },
            ),
            patch("agencli.tools.mcp.MCPToolClient.get_tools", fake_get_tools),
        ):
            result = load_mcp_tools(
                "unused.json",
                server_names=["filesystem", "search"],
                diagnostics=diagnostics,
            )

        self.assertEqual(result, ["tool-search"])
        self.assertEqual(len(diagnostics), 1)
        self.assertIn("filesystem", diagnostics[0])
        self.assertIn("npx", diagnostics[0])


if __name__ == "__main__":
    unittest.main()
