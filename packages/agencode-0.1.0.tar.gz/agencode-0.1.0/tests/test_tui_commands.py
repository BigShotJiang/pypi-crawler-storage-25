from __future__ import annotations

import unittest

from agencli.tui.commands import best_slash_command_match, filter_slash_commands, get_slash_commands, resolve_slash_command


class SlashCommandHelpersTest(unittest.TestCase):
    def test_get_slash_commands_exposes_expected_core_actions(self) -> None:
        names = [command.name for command in get_slash_commands()]

        self.assertIn("agent", names)
        self.assertIn("build", names)
        self.assertIn("history", names)
        self.assertIn("resume", names)
        self.assertIn("reset", names)
        self.assertIn("fork", names)
        self.assertIn("compact", names)
        self.assertIn("select-skill", names)
        self.assertIn("mention", names)
        self.assertIn("diff", names)
        self.assertIn("init", names)
        self.assertIn("personality", names)
        self.assertIn("permissions", names)
        self.assertIn("plan", names)
        self.assertIn("theme", names)
        self.assertIn("voice", names)
        self.assertIn("status", names)
        self.assertIn("clear", names)

    def test_filter_slash_commands_matches_name_alias_and_description(self) -> None:
        by_name = filter_slash_commands("/agent")
        by_alias = filter_slash_commands("threads")
        by_description = filter_slash_commands("provider")

        self.assertEqual(by_name[0].name, "agent")
        self.assertEqual(by_alias[0].name, "history")
        self.assertEqual(by_description[0].name, "model")

    def test_resolve_slash_command_supports_aliases(self) -> None:
        self.assertEqual(resolve_slash_command("/build").name, "build")
        self.assertEqual(resolve_slash_command("use").name, "agent")
        self.assertEqual(resolve_slash_command("fresh").name, "reset")
        self.assertEqual(resolve_slash_command("thread-skills").name, "select-skill")
        self.assertIsNone(resolve_slash_command("missing"))

    def test_best_slash_command_match_prefers_prefix_completion(self) -> None:
        self.assertEqual(best_slash_command_match("/his").name, "history")
        self.assertEqual(best_slash_command_match("/").name, "agent")


if __name__ == "__main__":
    unittest.main()
