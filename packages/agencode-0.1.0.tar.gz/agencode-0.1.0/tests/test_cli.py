from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from agencli.cli import _resolve_project_config_path, app
from agencli.core.config import load_config


class CLITest(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self._tmpdir.name)
        self.runner = CliRunner()

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def test_resolve_project_config_path_defaults_to_local_dot_agencode(self) -> None:
        workspace = self.root / "workspace"
        workspace.mkdir()

        config_path = _resolve_project_config_path(None, workspace)

        self.assertEqual(config_path, workspace / ".agencode" / "config.toml")
        self.assertTrue(config_path.exists())

    def test_tui_uses_project_local_dot_agencode_config_and_current_workspace(self) -> None:
        workspace = self.root / "workspace"
        workspace.mkdir()

        captured: dict[str, object] = {}

        class FakeApp:
            def __init__(self, *, config, config_path) -> None:
                captured["config"] = config
                captured["config_path"] = config_path

            def run(self, *, inline: bool) -> None:
                captured["inline"] = inline

        with (
            patch("agencli.cli.AgenCLIApp", FakeApp),
            patch("agencli.cli.Path.cwd", return_value=workspace),
        ):
            result = self.runner.invoke(app, ["tui"], catch_exceptions=False)

        self.assertEqual(result.exit_code, 0)
        config_path = workspace / ".agencode" / "config.toml"
        self.assertEqual(captured["config_path"], config_path)
        self.assertTrue(config_path.exists())
        config = load_config(config_path)
        self.assertEqual(config.workspace_dir, str(workspace.resolve()))
        self.assertEqual(config.agents_dir, str((workspace / ".agencode" / "agents").resolve()))
        self.assertEqual(config.sessions_dir, str((workspace / ".agencode" / "sessions").resolve()))


if __name__ == "__main__":
    unittest.main()
