from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import os
import random
import re
import shutil
from pathlib import Path
import subprocess
from textwrap import shorten
from typing import Iterable

from rich.text import Text
from textual import events
from textual.app import App, ComposeResult, SystemCommand
from textual.binding import Binding
from textual.css.query import NoMatches
from textual.containers import Container, Horizontal, VerticalScroll
from textual.screen import Screen
from textual.actions import SkipAction
from textual.widgets import Input, Static

from agencli import __version__
from agencli.agents.factory import AgentSpec, SubAgentSpec, build_agent_async
from agencli.agents.prebuilt.catalog import get_prebuilt_agents
from agencli.agents.registry import AgentRegistry
from agencli.agents.runtime import (
    DEFAULT_HISTORY_REPLAY_LIMIT,
    build_prompt_payload,
    extract_text_response,
    parse_stream_chunk,
)
from agencli.core.config import AgenCLIConfig, load_config, save_config, set_openai_compatible_provider
from agencli.core.session import (
    append_chat_turn,
    build_thread_config,
    clear_langgraph_checkpointer_cache_async,
    create_thread_id,
    delete_chat_thread,
    delete_langgraph_thread_async,
    get_thread_id,
    has_thread_checkpoint_async,
    list_chat_threads,
    load_chat_history,
    )
from agencli.mcp.config import bootstrap_default_mcp_servers, load_mcp_servers, save_mcp_servers
from agencli.providers.model import describe_api_key_source, init_model
from agencli.skills.cli_backend import (
    SKILLS_BROWSE_CATEGORIES,
    InstalledSkillRecord,
    SkillSearchResult,
    SkillsStatusResult,
    check_skills,
    find_skills,
    install_skill_cli,
    list_installed_skills_cli,
    normalize_repo_skill_target,
    render_command,
    update_skills,
)
from agencli.skills.manager import install_skill as install_local_skill, list_installed_skills as list_local_skills
from agencli.tui.commands import best_slash_command_match, filter_slash_commands, get_slash_commands, resolve_slash_command
from agencli.tui.screens import (
    ThreadSelection,
)
from agencli.tui.trace import OrchestrationTable, TraceTable
from agencli.tui.voice import transcribe_once


VISIBLE_BRAND = "AgenCode"
CREATOR_NAME = "Sakthivel"
PROMPT_PLACEHOLDER = f'Try "/help" or ask {VISIBLE_BRAND} to inspect the workspace'
WELCOME_ART = r"""
    _                    ____          _
   / \   __ _  ___ _ __ / ___|___   __| | ___
  / _ \ / _` |/ _ \ '_ \| |   / _ \ / _` |/ _ \
 / ___ \ (_| |  __/ | | | |__| (_) | (_| |  __/
/_/   \_\__, |\___|_| |_|\____\___/ \__,_|\___|
        |___/
"""
WELCOME_QUOTES = [
    "Build small. Polish hard.",
    "One careful change at a time.",
    "Clear steps beat clever chaos.",
    "Fast feedback makes good software.",
    "Ship the simple thing first.",
    "Good tools feel calm under pressure.",
]

PREFLIGHT_RISK_RULES: tuple[tuple[str, tuple[str, ...], str, str], ...] = (
    (
        "privileged",
        ("sudo ", "root ", "/etc", "/usr", "/var", "/boot", "systemctl", "service ", "chmod ", "chown "),
        "This request may require elevated system access.",
        "Reply `continue` to proceed carefully, or give safer guidance such as `manual only`, `show commands only`, `explain first`, or a non-privileged alternative.",
    ),
    (
        "destructive",
        ("empty trash", "delete ", "remove ", "rm ", "wipe ", "purge ", "format ", "trash", "permanently delete"),
        "This request may permanently remove files or data.",
        "Reply `continue` to proceed carefully, or give safer guidance such as `dry run first`, `show what will change`, `manual only`, or `skip deletion`.",
    ),
    (
        "package-management",
        ("apt ", "apt-get ", "dnf ", "yum ", "pacman ", "brew ", "pip install", "pip uninstall", "npm install", "npm uninstall", "uv sync", "cargo install"),
        "This request may install, remove, or modify system or project dependencies.",
        "Reply `continue` to proceed, or give safer guidance such as `show commands only`, `explain impact first`, `use project-local install`, or `skip dependency changes`.",
    ),
    (
        "network",
        ("download ", "curl ", "wget ", "fetch ", "clone ", "git clone", "install from url", "open url"),
        "This request may access the network or pull external content.",
        "Reply `continue` to proceed, or give safer guidance such as `show urls first`, `manual only`, `summarize plan`, or `skip downloads`.",
    ),
    (
        "bulk-filesystem",
        ("organize ", "move all ", "sort files", "reorganize ", "rename all ", "bulk move", "clean downloads", "downloads folder"),
        "This request may apply bulk filesystem changes across many files or folders.",
        "Reply `continue` to proceed, or give safer guidance such as `dry run first`, `show plan first`, `organize by type`, or `manual only`.",
    ),
)


@dataclass(frozen=True, slots=True)
class ThemePalette:
    name: str
    dark: bool
    screen_bg: str
    panel_bg: str
    picker_bg: str
    border: str
    text: str
    muted: str
    subtle: str
    soft_text: str
    accent: str
    info: str
    success: str
    warning: str
    danger: str
    danger_soft: str
    picker_text: str
    picker_detail: str
    creator: str
    art_styles: tuple[str, ...]


THEMES: dict[str, ThemePalette] = {
    "dark": ThemePalette(
        name="dark",
        dark=True,
        screen_bg="#0f1411",
        panel_bg="#151c17",
        picker_bg="#131a15",
        border="#33a352",
        text="#edf5ef",
        muted="#b8c5bc",
        subtle="#6d8272",
        soft_text="#d7e0d8",
        accent="#33a352",
        info="#72c7b5",
        success="#88d498",
        warning="#d5b25f",
        danger="#d97a7a",
        danger_soft="#f0d7d7",
        picker_text="#dbe5dd",
        picker_detail="#98aea0",
        creator="#b9e6c4",
        art_styles=(
            "bold #bde6c8",
            "bold #98d7aa",
            "bold #72c989",
            "bold #58ba74",
            "bold #3fac5e",
            "#7ca886",
        ),
    ),
    "light": ThemePalette(
        name="light",
        dark=False,
        screen_bg="#f6fbf7",
        panel_bg="#edf7ef",
        picker_bg="#ffffff",
        border="#33a352",
        text="#183222",
        muted="#4e6756",
        subtle="#819684",
        soft_text="#375043",
        accent="#33a352",
        info="#2d8a77",
        success="#2f8f4b",
        warning="#9a6d1f",
        danger="#b34a4a",
        danger_soft="#864949",
        picker_text="#214030",
        picker_detail="#5d7866",
        creator="#1f6d33",
        art_styles=(
            "bold #5dbb74",
            "bold #4cae65",
            "bold #409f58",
            "bold #378e4d",
            "bold #2f7f43",
            "#5a8563",
        ),
    ),
}


@dataclass(slots=True)
class ProviderOnboardingState:
    source: str
    step: str = "provider"
    provider_name: str = ""
    base_url: str = ""
    model: str = ""
    model_kind: str = "chat"
    api_key_env: str = "OPENAI_API_KEY"
    api_key: str | None = None


@dataclass(slots=True)
class HumanLoopState:
    agent_name: str
    original_prompt: str
    error_message: str
    request_text: str
    placeholder: str
    kind: str = "retry"
    sensitive: bool = False
    choices: tuple[tuple[str, str, str], ...] = ()


@dataclass(slots=True)
class SubagentEditorState:
    mode: str
    original_name: str | None = None
    name: str = ""
    system_prompt: str = ""
    model: str = ""
    workspace_dir: str = ""
    skills: list[str] = field(default_factory=list)
    review_summary: str = ""
    refined_system_prompt: str = ""
    review_guidance: str = ""
    step: str = "name"


@dataclass(slots=True)
class MentionedContext:
    path: str
    summary: str


@dataclass(slots=True)
class SkillsBrowserState:
    query: str = ""
    results: list[SkillSearchResult] = field(default_factory=list)
    installed: list[InstalledSkillRecord] = field(default_factory=list)
    selected_index: int = 0
    detail_mode: str = "search"
    attach_mode: bool = False
    selected_tokens: set[str] = field(default_factory=set)
    pending_source: str | None = None
    pending_skill_name: str | None = None
    pending_command: tuple[str, ...] = ()
    pending_note: str = ""
    status_result: SkillsStatusResult | None = None


@dataclass(frozen=True, slots=True)
class PromptMention:
    raw_token: str
    token_path: str


class ShellPromptInput(Input):
    BINDINGS = [
        *Input.BINDINGS,
        Binding("up", "picker_up", show=False, priority=True),
        Binding("down", "picker_down", show=False, priority=True),
        Binding("space", "picker_toggle", show=False, priority=True),
        Binding("escape", "dismiss_picker", show=False, priority=True),
        Binding("enter", "smart_submit", show=False, priority=True),
    ]

    def action_picker_up(self) -> None:
        handler = getattr(self.app, "_move_picker_selection", None)
        if handler is not None and handler(-1):
            return

    def action_picker_down(self) -> None:
        handler = getattr(self.app, "_move_picker_selection", None)
        if handler is not None and handler(1):
            return

    def action_dismiss_picker(self) -> None:
        handler = getattr(self.app, "_dismiss_or_interrupt", None)
        if handler is not None and handler():
            return

    def action_picker_toggle(self) -> None:
        handler = getattr(self.app, "_toggle_picker_mark", None)
        if handler is not None and handler():
            return
        self.insert_text_at_cursor(" ")

    async def action_smart_submit(self) -> None:
        handler = getattr(self.app, "_handle_prompt_enter", None)
        if handler is not None and handler():
            return
        await self.action_submit()


class AgenCLIApp(App[None]):
    CSS = """
    Screen {
        background: #0f1411;
        color: #edf5ef;
    }

    #shell {
        height: 1fr;
        padding: 0;
    }

    #viewport {
        height: 1fr;
        padding: 1 2 0 2;
        scrollbar-size-vertical: 0;
        scrollbar-size-horizontal: 0;
    }

    #welcome-panel {
        height: 14;
        border: round #33a352;
        padding: 0;
        background: #151c17;
        margin-bottom: 1;
    }

    #welcome-columns {
        width: 100%;
        height: 100%;
    }

    #welcome-left {
        width: 1fr;
        padding: 1 2;
        border-right: solid #33a352;
        background: #151c17;
        height: 100%;
    }

    #welcome-right {
        width: 1fr;
        background: #151c17;
        height: 100%;
    }

    #welcome-activity {
        padding: 1 2;
        border-bottom: solid #33a352;
        height: 1fr;
    }

    #welcome-whats-new {
        padding: 1 2;
        height: 1fr;
    }

    #conversation {
        height: auto;
        padding: 0 1;
        background: #0f1411;
        color: #edf5ef;
    }

    #composer {
        height: auto;
        padding: 0 2 1 2;
        background: #0f1411;
        margin-top: 1;
    }

    #picker-overlay {
        height: 8;
        max-height: 8;
        border: round #4e5c63;
        background: #131a15;
        margin: 0 0 1 0;
        padding: 0 1;
        scrollbar-size-vertical: 0;
        scrollbar-size-horizontal: 0;
    }

    #picker {
        height: auto;
        color: #d5d2ce;
        padding: 0;
    }

    #prompt-row {
        height: auto;
        padding: 0 1;
    }

    #prompt-prefix {
        width: 3;
        color: #33a352;
    }

    #prompt-input {
        width: 1fr;
        border: none;
        background: transparent;
        color: #edf5ef;
        padding: 0;
    }

    #hint-line {
        color: #9aa1aa;
        padding: 0 1;
    }

    #hidden-runtime {
        display: none;
    }
    """

    TITLE = VISIBLE_BRAND
    SUB_TITLE = "Agentic coding shell"
    ENABLE_COMMAND_PALETTE = True
    BINDINGS = [
        Binding("ctrl+k", "command_palette", "Palette", show=False),
        Binding("ctrl+l", "clear_shell", "Clear", show=False),
        Binding("ctrl+alt+v", "toggle_voice_input", "Voice", show=False),
        Binding("ctrl+c", "copy_selection", "Copy", show=False, priority=True),
        Binding("ctrl+shift+c", "copy_selection", "Copy", show=False, priority=True),
        Binding("escape", "interrupt_or_dismiss", "Cancel", show=False, priority=True),
        Binding("ctrl+v", "paste_clipboard", "Paste", show=False, priority=True),
        Binding("ctrl+shift+v", "paste_clipboard", "Paste", show=False, priority=True),
    ]

    def __init__(self, config: AgenCLIConfig, config_path: Path | None = None) -> None:
        super().__init__()
        self.config = config
        self.config_path = config_path
        self._agent_names: list[str] = []
        self._agent_specs: dict[str, AgentSpec] = {}
        self._built_agents: dict[str, object] = {}
        self._built_agent_signatures: dict[str, tuple[str, ...]] = {}
        self._active_threads: dict[str, str] = {}
        self._thread_skill_tokens: dict[tuple[str, str], list[str]] = {}
        self._selected_agent_name_value: str | None = None
        self._welcome_written = False
        self._picker_mode: str | None = None
        self._picker_rows: list[tuple[str, ...]] = []
        self._picker_title = ""
        self._picker_index = 0
        self._picker_marks: set[str] = set()
        self._theme_name = "dark"
        self._onboarding: ProviderOnboardingState | None = None
        self._human_loop: HumanLoopState | None = None
        self._subagent_editor: SubagentEditorState | None = None
        self._transcript_blocks: list[str] = []
        self._streaming_assistant_index: int | None = None
        self._prompt_history: list[str] = []
        self._prompt_history_index: int | None = None
        self._prompt_history_draft = ""
        self._voice_task: asyncio.Task[None] | None = None
        self._voice_listening = False
        self._run_active = False
        self._run_status = ""
        self._spinner_frames = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")
        self._spinner_index = 0
        self._spinner_timer = None
        self._welcome_quote = random.choice(WELCOME_QUOTES)
        self._ctrl_c_armed_at = 0.0
        self._active_agent_worker = None
        self._saved_subagent_specs: dict[str, AgentSpec] = {}
        self._active_saved_subagent_names: set[str] = set()
        self._personality = config.shell_personality or "concise"
        self._approval_mode = config.approval_mode or "confirm"
        self._plan_mode = bool(config.plan_mode)
        self._mentioned_contexts: list[MentionedContext] = []
        self._session_summary: str | None = None
        self._project_agents_context: MentionedContext | None = None
        self._skills_state = SkillsBrowserState(query=config.skills_last_query or "")
        self._agent_config_name: str | None = None

    def compose(self) -> ComposeResult:
        with Container(id="shell"):
            with VerticalScroll(id="viewport"):
                with Container(id="welcome-panel"):
                    with Horizontal(id="welcome-columns"):
                        yield Static("", id="welcome-left", markup=False)
                        with Container(id="welcome-right"):
                            yield Static("", id="welcome-activity", markup=False)
                            yield Static("", id="welcome-whats-new", markup=False)
                yield Static("", id="conversation", markup=False)
                with Container(id="composer"):
                    with VerticalScroll(id="picker-overlay"):
                        yield Static("", id="picker", markup=False)
                    with Horizontal(id="prompt-row"):
                        yield Static(">", id="prompt-prefix", markup=False)
                        yield ShellPromptInput(
                            placeholder=PROMPT_PLACEHOLDER,
                            id="prompt-input",
                        )
                    yield Static("? for help  -  / for commands  -  Ctrl+K for palette", id="hint-line", markup=False)
            with Container(id="hidden-runtime"):
                yield OrchestrationTable(id="orchestration-table")
                yield TraceTable(id="trace-table")

    def on_mount(self) -> None:
        self._spinner_timer = self.set_interval(0.12, self._advance_run_spinner, pause=True)
        self._hide_picker()
        self._refresh_agent_catalog()
        self._load_project_agents_context()
        self._apply_theme()
        self._render_top_panel()
        self._render_conversation()
        self._prompt_input().focus()
        self._render_hint_line()
        if self._needs_provider_onboarding():
            self._start_provider_onboarding(source="initial")
        else:
            self._write_welcome_banner()

    async def on_unmount(self) -> None:
        if self._voice_task is not None and not self._voice_task.done():
            self._voice_task.cancel()
            try:
                await self._voice_task
            except asyncio.CancelledError:
                pass
        await clear_langgraph_checkpointer_cache_async()

    def action_clear_shell(self) -> None:
        self._set_run_state(False)
        self._transcript_blocks.clear()
        self._streaming_assistant_index = None
        self._render_conversation()
        self.query_one("#trace-table", TraceTable).reset()
        self.query_one("#orchestration-table", OrchestrationTable).reset()
        self._welcome_written = False
        self._render_top_panel()
        if self._onboarding is not None:
            self._resume_onboarding()
            return
        self._write_welcome_banner()

    def action_build_selected(self) -> None:
        spec = self._selected_agent_spec()
        if spec is None:
            return
        self._log(f"Building `{spec.name}`...")
        self._active_agent_worker = self.run_worker(self._build_selected(spec), exclusive=True, thread=False)

    def action_new_thread(self) -> None:
        agent_name = self._selected_agent_name()
        if agent_name is None:
            return
        thread_id = create_thread_id(agent_name)
        self._active_threads[agent_name] = thread_id
        self._render_top_panel()
        self._log(f"Started a new thread for `{agent_name}`: `{thread_id}`")

    def action_reset_session(self) -> None:
        agent_name = self._selected_agent_name()
        if agent_name is None:
            return
        self._active_agent_worker = self.run_worker(self._reset_agent_session(agent_name), exclusive=True, thread=False)

    def action_open_agents(self) -> None:
        self._show_subagent_manager()

    def action_open_skills(self) -> None:
        self._show_skills_root()

    def action_open_history_browser(self) -> None:
        self._show_history_picker()

    def action_open_mcp_browser(self) -> None:
        self._show_mcp_manager()

    def action_open_model_config(self) -> None:
        self._start_provider_onboarding(source="command")

    def action_toggle_voice_input(self) -> None:
        if self._voice_listening and self._voice_task is not None:
            self._voice_task.cancel()
            return
        self._voice_task = asyncio.create_task(self._capture_voice_input())

    def action_copy_or_interrupt(self) -> None:
        if self._copy_selected_text():
            return

    def action_copy_selection(self) -> None:
        self._copy_selected_text()

    def action_interrupt_or_dismiss(self) -> None:
        self._dismiss_or_interrupt()

    def action_paste_clipboard(self) -> None:
        prompt_input = self._prompt_input()
        if self.focused is not prompt_input:
            prompt_input.focus()
        paste = getattr(prompt_input, "action_paste", None)
        if callable(paste):
            paste()
            return
        clipboard_text = getattr(self, "clipboard", "") or ""
        if not clipboard_text:
            clipboard_text = self._read_system_clipboard()
        if not clipboard_text:
            return
        prompt_input.insert_text_at_cursor(clipboard_text)

    def copy_to_clipboard(self, text: str) -> None:
        super().copy_to_clipboard(text)
        self._write_system_clipboard(text)

    def _write_system_clipboard(self, text: str) -> bool:
        if not text:
            return False
        commands: list[tuple[str, ...]] = []
        if shutil.which("wl-copy"):
            commands.append(("wl-copy",))
        if shutil.which("xclip"):
            commands.append(("xclip", "-selection", "clipboard"))
        if shutil.which("xsel"):
            commands.append(("xsel", "--clipboard", "--input"))
        if shutil.which("python3"):
            commands.append(
                (
                    "python3",
                    "-c",
                    (
                        "import sys, tkinter as tk; "
                        "text = sys.stdin.read(); "
                        "root = tk.Tk(); root.withdraw(); "
                        "root.clipboard_clear(); root.clipboard_append(text); "
                        "root.update(); root.destroy()"
                    ),
                )
            )
        for command in commands:
            try:
                result = subprocess.run(
                    list(command),
                    input=text,
                    text=True,
                    capture_output=True,
                    check=False,
                    env=os.environ.copy(),
                )
            except OSError:
                continue
            if result.returncode == 0:
                return True
        return False

    def _read_system_clipboard(self) -> str:
        commands: list[tuple[str, ...]] = []
        if shutil.which("wl-paste"):
            commands.append(("wl-paste", "-n"))
        if shutil.which("xclip"):
            commands.append(("xclip", "-o", "-selection", "clipboard"))
        if shutil.which("xsel"):
            commands.append(("xsel", "--clipboard", "--output"))
        if shutil.which("python3"):
            commands.append(
                (
                    "python3",
                    "-c",
                    (
                        "import tkinter as tk; "
                        "root = tk.Tk(); root.withdraw(); "
                        "print(root.clipboard_get(), end=''); "
                        "root.destroy()"
                    ),
                )
            )
        for command in commands:
            try:
                result = subprocess.run(
                    list(command),
                    text=True,
                    capture_output=True,
                    check=False,
                    env=os.environ.copy(),
                )
            except OSError:
                continue
            if result.returncode == 0 and result.stdout:
                return result.stdout
        return ""

    def _copy_selected_text(self) -> bool:
        prompt_input = self._prompt_input()
        selection = getattr(prompt_input, "selection", None)
        if self.focused is prompt_input and selection is not None and not selection.is_empty:
            prompt_input.action_copy()
            self._ctrl_c_armed_at = 0.0
            self._render_hint_line()
            return True
        screen_copy = getattr(self.screen, "action_copy_text", None)
        if callable(screen_copy):
            try:
                screen_copy()
            except SkipAction:
                pass
            else:
                self._ctrl_c_armed_at = 0.0
                self._render_hint_line()
                return True
        return False

    def _cancel_active_run(self) -> None:
        worker = self._active_agent_worker
        self._ctrl_c_armed_at = 0.0
        if worker is None:
            self._set_run_state(False)
            return
        cancel = getattr(worker, "cancel", None)
        if callable(cancel):
            cancel()
        self._active_agent_worker = None
        self._set_run_state(False)
        self._append_transcript("\n".join(["System", "Interrupted the current run."]))

    def _dismiss_or_interrupt(self) -> bool:
        if self._dismiss_picker():
            return True
        if self._run_active and self._active_agent_worker is not None:
            self._cancel_active_run()
            return True
        return False

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "prompt-input":
            return
        if self._subagent_editor is not None:
            if self._picker_mode in {"slash", "mention"}:
                self._hide_picker()
            return
        if self._human_loop is not None:
            if self._picker_mode in {"slash", "mention"}:
                self._hide_picker()
            return
        if self._onboarding is not None:
            if self._onboarding.step == "provider":
                return
            if self._picker_mode in {"slash", "mention"}:
                self._hide_picker()
            return
        self._refresh_prompt_suggestions(event.value)

    def on_click(self, event: events.Click) -> None:
        if event.button != 1 or event.ctrl or event.meta:
            return
        self._focus_prompt_for_typing()

    def on_key(self, event: events.Key) -> None:
        if not event.is_printable:
            return
        if any(prefix in event.key for prefix in ("ctrl+", "alt+", "meta+", "super+")):
            return
        if self.focused is self._prompt_input():
            return
        if self._has_active_text_selection():
            return
        self._focus_prompt_for_typing(insert_text=event.character or "")
        event.stop()
        event.prevent_default()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "prompt-input":
            return
        raw_value = event.value.strip()
        if not raw_value:
            return
        if raw_value == "?":
            self._remember_prompt_entry(raw_value)
            self._clear_prompt()
            self._write_help_message()
            return
        if raw_value.startswith("/"):
            self._run_slash_command(raw_value)
            return
        if self._human_loop is not None:
            self._submit_human_loop_value(raw_value)
            return
        if self._onboarding is not None:
            self._submit_onboarding_value(raw_value)
            return

        spec = self._selected_agent_spec()
        if spec is None:
            return
        clean_prompt, mention_contexts = self._resolve_prompt_mentions(raw_value)
        self._remember_prompt_entry(raw_value)
        self._append_transcript(f"> {raw_value}")
        if self._maybe_start_preflight_human_loop(agent_name=spec.name, prompt=clean_prompt):
            self._clear_prompt()
            return
        self._clear_prompt()
        for context in mention_contexts:
            self._mentioned_contexts.append(context)
        self._active_agent_worker = self.run_worker(self._run_prompt(spec.name, clean_prompt), exclusive=True, thread=False)

    def get_system_commands(self, screen: Screen) -> Iterable[SystemCommand]:
        yield from super().get_system_commands(screen)
        for command in get_slash_commands():
            yield SystemCommand(
                f"/{command.name}",
                command.description,
                lambda raw=f"/{command.name}": self._run_slash_command(raw),
            )

    def _prompt_input(self) -> ShellPromptInput:
        return self.query_one("#prompt-input", ShellPromptInput)

    def _welcome_panel(self) -> Static:
        return self.query_one("#welcome-left", Static)

    def _welcome_activity(self) -> Static:
        return self.query_one("#welcome-activity", Static)

    def _welcome_whats_new(self) -> Static:
        return self.query_one("#welcome-whats-new", Static)

    def _conversation(self) -> Static:
        return self.query_one("#conversation", Static)

    def _picker(self) -> Static:
        return self.query_one("#picker", Static)

    def _prompt_prefix(self) -> Static:
        return self.query_one("#prompt-prefix", Static)

    def _hint_line(self) -> Static:
        return self.query_one("#hint-line", Static)

    def _picker_overlay(self) -> VerticalScroll:
        return self.query_one("#picker-overlay", VerticalScroll)

    def _viewport(self) -> VerticalScroll:
        return self.query_one("#viewport", VerticalScroll)

    def _has_active_text_selection(self) -> bool:
        prompt_input = self._prompt_input()
        selection = getattr(prompt_input, "selection", None)
        if selection is not None and not selection.is_empty:
            return True
        screen_selection = getattr(self.screen, "get_selected_text", None)
        if callable(screen_selection):
            return bool(screen_selection())
        return False

    def _focus_prompt_for_typing(self, *, insert_text: str = "") -> bool:
        if self._has_active_text_selection():
            return False
        prompt_input = self._prompt_input()
        if self.focused is not prompt_input:
            prompt_input.focus()
        self._scroll_transcript_to_end()
        if insert_text:
            prompt_input.insert_text_at_cursor(insert_text)
        return True

    def _palette(self) -> ThemePalette:
        return THEMES.get(self._theme_name, THEMES["dark"])

    def _apply_theme(self) -> None:
        palette = self._palette()
        self.dark = palette.dark
        self.screen.styles.background = palette.screen_bg
        self.screen.styles.color = palette.text

        for selector in ("#shell", "#viewport", "#conversation", "#composer"):
            widget = self.query_one(selector)
            widget.styles.background = palette.screen_bg
            widget.styles.color = palette.text

        welcome_panel = self.query_one("#welcome-panel")
        welcome_panel.styles.background = palette.panel_bg
        welcome_panel.styles.border = ("round", palette.border)

        welcome_left = self.query_one("#welcome-left")
        welcome_left.styles.background = palette.panel_bg
        welcome_left.styles.color = palette.text
        welcome_left.styles.border_right = ("solid", palette.border)

        welcome_right = self.query_one("#welcome-right")
        welcome_right.styles.background = palette.panel_bg
        welcome_right.styles.color = palette.text

        welcome_activity = self.query_one("#welcome-activity")
        welcome_activity.styles.background = palette.panel_bg
        welcome_activity.styles.color = palette.text
        welcome_activity.styles.border_bottom = ("solid", palette.border)

        welcome_whats_new = self.query_one("#welcome-whats-new")
        welcome_whats_new.styles.background = palette.panel_bg
        welcome_whats_new.styles.color = palette.text

        picker_overlay = self._picker_overlay()
        picker_overlay.styles.background = palette.picker_bg
        picker_overlay.styles.border = ("round", palette.border)

        picker = self._picker()
        picker.styles.background = palette.picker_bg
        picker.styles.color = palette.picker_text

        prompt_prefix = self._prompt_prefix()
        prompt_prefix.styles.color = palette.accent

        prompt_input = self._prompt_input()
        prompt_input.styles.background = palette.screen_bg
        prompt_input.styles.color = palette.text

        hint_line = self._hint_line()
        hint_line.styles.background = palette.screen_bg
        hint_line.styles.color = palette.muted

        self._render_top_panel()
        self._render_conversation()
        self._render_picker()
        self._render_hint_line()

    def _show_theme_picker(self) -> None:
        self._show_picker(
            mode="theme",
            title="Themes",
            columns=("Theme", "Description"),
            rows=[
                ("dark", "Dark", "Deep workspace shell with green accents."),
                ("light", "Light", "Bright workspace shell with the same green accent."),
            ],
        )
        self._prompt_input().placeholder = "Choose a theme with Up/Down, then press Enter"

    def _show_human_loop_picker(self, state: HumanLoopState) -> None:
        if not state.choices:
            return
        self._show_picker(
            mode="human-loop",
            title="Options",
            columns=("Choice", "Description"),
            rows=[(value, label, description) for value, label, description in state.choices],
        )

    def _apply_named_theme(self, theme_name: str, *, announce: bool = True) -> bool:
        normalized = theme_name.strip().lower()
        if normalized not in THEMES:
            return False
        self._theme_name = normalized
        self._apply_theme()
        if announce:
            self._log(f"Switched theme to `{normalized}`.")
        return True

    def _submit_theme_selection(self) -> bool:
        choice = self._selected_picker_key()
        if choice is None:
            return True
        self._hide_picker()
        if self._onboarding is None:
            self._prompt_input().placeholder = PROMPT_PLACEHOLDER
        self._prompt_input().value = ""
        if not self._apply_named_theme(choice):
            self._log(f"Unknown theme: `{choice}`")
        return True

    async def _capture_voice_input(self) -> None:
        self._voice_listening = True
        self._render_hint_line()
        self._log("Voice input listening. Speak now, or press `Ctrl+Alt+V` again to stop.")
        try:
            transcript = await transcribe_once()
        except asyncio.CancelledError:
            self._log("Voice input stopped.")
            raise
        except Exception as exc:
            self._log(f"Voice input failed: {exc}")
        else:
            if transcript:
                self._append_voice_text(transcript)
                self._log("Voice input added to the prompt.")
            else:
                self._log("Voice input did not detect any speech.")
        finally:
            self._voice_listening = False
            self._voice_task = None
            self._render_hint_line()
            self._prompt_input().focus()

    def _append_voice_text(self, transcript: str) -> None:
        normalized = " ".join(transcript.split())
        if not normalized:
            return
        prompt_input = self._prompt_input()
        existing = prompt_input.value.rstrip()
        prompt_input.value = f"{existing} {normalized}".strip() if existing else normalized
        prompt_input.cursor_position = len(prompt_input.value)

    def _clear_prompt(self) -> None:
        prompt_input = self._prompt_input()
        prompt_input.value = ""
        prompt_input.cursor_position = 0
        self._reset_prompt_history_cursor()
        if self._human_loop is not None:
            prompt_input.placeholder = self._human_loop.placeholder
        elif self._onboarding is None:
            prompt_input.placeholder = PROMPT_PLACEHOLDER
        if self._picker_mode == "slash":
            self._hide_picker()

    def _advance_run_spinner(self) -> None:
        if not self._run_active:
            return
        self._spinner_index = (self._spinner_index + 1) % len(self._spinner_frames)
        self._render_hint_line()

    def _set_run_state(self, active: bool, status: str = "") -> None:
        self._run_active = active
        self._run_status = status
        if active:
            if self._spinner_timer is not None:
                self._spinner_timer.resume()
        else:
            if self._spinner_timer is not None:
                self._spinner_timer.pause()
            self._spinner_index = 0
            self._ctrl_c_armed_at = 0.0
            worker = self._active_agent_worker
            if worker is not None and getattr(worker, "is_finished", False):
                self._active_agent_worker = None
        self._render_hint_line()

    def _render_hint_line(self) -> None:
        try:
            prompt_prefix = self._prompt_prefix()
            hint_line = self._hint_line()
        except NoMatches:
            return
        palette = self._palette()
        if self._run_active:
            frame = self._spinner_frames[self._spinner_index]
            prompt_prefix.update(Text(frame, style=f"bold {palette.accent}"))
            status = self._run_status or "Working..."
            text = Text()
            text.append(frame, style=f"bold {palette.accent}")
            text.append(" ")
            text.append(status, style=f"bold {palette.info}")
            if self._active_agent_worker is not None:
                text.append("  •  ", style=palette.subtle)
                text.append("Esc", style=f"bold {palette.accent}")
                text.append(" to interrupt", style=palette.muted)
            hint_line.update(text)
            return
        if self._voice_listening:
            prompt_prefix.update(Text("●", style=f"bold {palette.accent}"))
            text = Text()
            text.append("●", style=f"bold {palette.accent}")
            text.append(" Voice listening", style=f"bold {palette.info}")
            text.append("  •  ", style=palette.subtle)
            text.append("Ctrl+Alt+V", style=f"bold {palette.accent}")
            text.append(" stop", style=palette.muted)
            hint_line.update(text)
            return
        if self._human_loop is not None:
            prompt_prefix.update(Text("?", style=f"bold {palette.warning}"))
            text = Text()
            text.append("?", style=f"bold {palette.warning}")
            text.append(" Waiting for your input", style=f"bold {palette.warning}")
            text.append("  •  ", style=palette.subtle)
            text.append("/cancel", style=f"bold {palette.accent}")
            text.append(" to dismiss", style=palette.muted)
            hint_line.update(text)
            return
        prompt_prefix.update(Text("❯", style=f"bold {palette.accent}"))
        text = Text()
        text.append("?", style=f"bold {palette.success}")
        text.append(" help", style=palette.muted)
        text.append("  •  ", style=palette.subtle)
        text.append("/", style=f"bold {palette.info}")
        text.append(" commands", style=palette.muted)
        text.append("  •  ", style=palette.subtle)
        text.append("Ctrl+K", style=f"bold {palette.accent}")
        text.append(" palette", style=palette.muted)
        text.append("  •  ", style=palette.subtle)
        text.append("Ctrl+Alt+V", style=f"bold {palette.accent}")
        text.append(" voice", style=palette.muted)
        hint_line.update(text)

    def _append_transcript(self, block: str) -> None:
        normalized = block.strip()
        if not normalized:
            return
        self._transcript_blocks.append(normalized)
        self._streaming_assistant_index = None
        self._render_conversation()

    def _update_streaming_assistant(self, text: str) -> None:
        normalized = text.strip()
        if not normalized:
            return
        header = "Thinking" if self._run_active else VISIBLE_BRAND
        block = f"{header}\n{normalized}"
        if self._streaming_assistant_index is None:
            self._transcript_blocks.append(block)
            self._streaming_assistant_index = len(self._transcript_blocks) - 1
        else:
            self._transcript_blocks[self._streaming_assistant_index] = block
        self._render_conversation()

    def _finalize_streaming_assistant(self, text: str) -> None:
        normalized = text.strip()
        if not normalized:
            self._streaming_assistant_index = None
            return
        self._update_streaming_assistant(normalized)
        self._streaming_assistant_index = None

    def _render_conversation(self) -> None:
        body = Text()
        for index, block in enumerate(self._transcript_blocks):
            if index:
                body.append("\n\n")
            body.append_text(self._render_transcript_block(block))
        self._conversation().update(body)
        self.call_after_refresh(self._scroll_transcript_to_end)

    def _scroll_transcript_to_end(self) -> None:
        self._viewport().scroll_end(animate=False, immediate=True, x_axis=False)

    def _render_picker(self) -> None:
        picker = self._picker()
        overlay = self._picker_overlay()
        palette = self._palette()
        if self._picker_mode is None or not self._picker_rows:
            overlay.display = False
            picker.update(Text(""))
            return

        rendered = Text()
        if self._picker_title:
            rendered.append(f"{self._picker_title}\n", style=f"bold {palette.accent}")
        for index, row in enumerate(self._picker_rows):
            selected = index == self._picker_index
            marker = "❯" if selected else " "
            marker_style = f"bold {palette.accent}" if selected else palette.subtle
            line_style = f"bold {palette.text}" if selected else palette.picker_text
            detail_style = palette.info if selected else palette.picker_detail
            if self._picker_mode == "slash":
                _key, label, description, _usage = row
                rendered.append(marker, style=marker_style)
                rendered.append(" ")
                rendered.append(label, style=line_style)
                rendered.append("\n")
                rendered.append("  ")
                rendered.append(description, style=detail_style)
                usage_style = palette.success if selected else palette.subtle
                rendered.append("\n")
                rendered.append("  ")
                rendered.append(f"usage: {_usage}", style=usage_style)
            elif self._picker_mode in {"agent-active", "mcp-manager", "agent-skills", "thread-skills"}:
                key, label, description = row
                checked = key in self._picker_marks
                checkbox = "[x]" if checked else "[ ]"
                checkbox_style = palette.success if checked else palette.subtle
                rendered.append(marker, style=marker_style)
                rendered.append(" ")
                rendered.append(checkbox, style=checkbox_style)
                rendered.append(" ")
                rendered.append(label, style=line_style)
                rendered.append("\n")
                rendered.append("    ")
                rendered.append(description, style=detail_style)
            else:
                _key, label, description = row
                rendered.append(marker, style=marker_style)
                rendered.append(" ")
                rendered.append(label, style=line_style)
                rendered.append("\n")
                rendered.append("  ")
                rendered.append(description, style=detail_style)
            if index < len(self._picker_rows) - 1:
                rendered.append("\n\n")

        overlay.display = True
        picker.update(rendered)
        self.call_after_refresh(self._scroll_picker_to_selection)

    def _scroll_picker_to_selection(self) -> None:
        if self._picker_mode is None or not self._picker_rows:
            return
        lines_per_item = 4 if self._picker_mode == "slash" else 3
        top_padding = 1 if self._picker_title else 0
        target_y = max(0, top_padding + (self._picker_index * lines_per_item) - 1)
        self._picker_overlay().scroll_to(y=target_y, animate=False, immediate=True)

    def _render_top_panel(self) -> None:
        self._welcome_panel().update(self._render_welcome_left())
        self._welcome_activity().update(self._render_recent_activity())
        self._welcome_whats_new().update(self._render_whats_new())

    def _append_welcome_art(self, text: Text) -> None:
        palette = self._palette()
        lines = WELCOME_ART.strip("\n").splitlines()
        for index, line in enumerate(lines):
            style = palette.art_styles[min(index, len(palette.art_styles) - 1)]
            text.append(line, style=style)
            if index < len(lines) - 1:
                text.append("\n")

    def _render_welcome_left(self) -> Text:
        palette = self._palette()
        provider = self.config.openai_compatible
        model = self._display_model_name(provider.model or self.config.default_model)
        agent_name = self._current_agent_name() or "-"
        thread_id = self._active_thread_id(agent_name) if agent_name != "-" else "-"
        text = Text()
        text.append(VISIBLE_BRAND, style=f"bold {palette.accent}")
        text.append(f"  v{__version__}", style=palette.muted)
        text.append("  by ", style=palette.subtle)
        text.append(CREATOR_NAME, style=f"bold {palette.creator}")
        text.append("\n")
        self._append_welcome_art(text)
        text.append("\n")
        text.append("✦ ", style=palette.info)
        text.append(f"“{self._welcome_quote}”\n", style=f"italic {palette.soft_text}")
        text.append("● ", style=palette.info)
        text.append(model, style=f"bold {palette.info}")
        text.append("  -  ", style=palette.subtle)
        text.append(provider.provider_name, style=f"bold {palette.success}")
        text.append("\n")
        text.append("● ", style=palette.accent)
        text.append("agent", style=palette.muted)
        text.append(": ")
        text.append(agent_name, style=f"bold {palette.text}")
        text.append("\n")
        text.append("● ", style=palette.accent)
        text.append("active subagents", style=palette.muted)
        text.append(": ")
        text.append(str(len(self._active_saved_subagent_names)), style=f"bold {palette.text}")
        text.append("\n")
        text.append("● ", style=palette.accent)
        text.append("thread", style=palette.muted)
        text.append(": ")
        text.append(thread_id or "-", style=f"bold {palette.text}")
        text.append("\n")
        text.append("● ", style=palette.accent)
        text.append(self.config.workspace_dir, style=palette.muted)
        return text

    def _render_recent_activity(self) -> Text:
        palette = self._palette()
        text = Text()
        text.append("Recent activity\n", style=f"bold {palette.accent}")
        threads = list_chat_threads(self.config.sessions_dir, limit=4)
        if not threads:
            text.append("◌ ", style=palette.info)
            text.append("No saved threads yet\n", style=palette.text)
            text.append("Run a prompt to start building history", style=palette.muted)
            return text
        for summary in threads:
            preview = shorten(summary.last_content.replace("\n", " "), width=36, placeholder="...")
            text.append("◌ ", style=palette.success)
            text.append(f"{self._relative_time(summary.last_created_at):<7}", style=f"bold {palette.info}")
            text.append("  ")
            text.append(f"{preview}\n", style=palette.text)
        text.append("… ", style=palette.subtle)
        text.append("/history", style=f"bold {palette.accent}")
        text.append(" for more", style=palette.muted)
        return text

    def _render_whats_new(self) -> Text:
        palette = self._palette()
        text = Text()
        text.append("Quick commands\n", style=f"bold {palette.accent}")
        commands = [
            ("/agent", "to manage supervisor subagents"),
            ("/history", "to switch threads"),
            ("/skills", "to browse and install skills"),
            ("/model", "to update provider setup"),
            ("/mcp", "to manage configured MCP servers"),
        ]
        for command, description in commands:
            text.append("◌ ", style=palette.info)
            text.append(command, style=f"bold {palette.success}")
            text.append(f" {description}\n", style=palette.text)
        text.append("… ", style=palette.subtle)
        text.append("/help", style=f"bold {palette.accent}")
        text.append(" for more", style=palette.muted)
        return text

    def _relative_time(self, created_at: str) -> str:
        try:
            parsed = datetime.fromisoformat(created_at)
        except ValueError:
            return "now"
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        seconds = max(int((datetime.now(timezone.utc) - parsed).total_seconds()), 0)
        if seconds < 60:
            return "now"
        if seconds < 3600:
            return f"{seconds // 60}m ago"
        if seconds < 86400:
            return f"{seconds // 3600}h ago"
        if seconds < 604800:
            return f"{seconds // 86400}d ago"
        return f"{seconds // 604800}w ago"

    def _append_stream_event(self, event) -> None:
        if event.kind == "tool":
            if event.phase == "start":
                self._set_run_state(True, f"Tool call: {event.label}")
                self._append_transcript(
                    "\n".join(
                        [
                            "Tool call",
                            self._format_tool_call(event.label, event.text),
                        ]
                    )
                )
            else:
                self._set_run_state(True, f"Waiting for next step...")
                self._append_transcript(
                    "\n".join(
                        [
                            "Tool result",
                            self._format_tool_result(event.label, event.text),
                        ]
                    )
                )
            return
        if event.kind == "subagent":
            label = event.label or "subagent"
            if event.phase == "start":
                self._set_run_state(True, f"Delegating to {label}")
                self._append_transcript(
                    "\n".join(
                        [
                            "Delegating",
                            f"{label}  {self._compact_detail(event.text, width=100) or 'delegated'}",
                        ]
                    )
                )
            else:
                self._set_run_state(True, f"Continuing after {label}")
                self._append_transcript(
                    "\n".join(
                        [
                            "Delegation complete",
                            f"{label}  {self._compact_detail(event.text, width=100) or '(ok)'}",
                        ]
                    )
                )
            return
        return

    def _handle_prompt_enter(self) -> bool:
        raw_value = self._prompt_input().value.strip()
        if self._picker_mode == "theme":
            return self._submit_theme_selection()
        if self._picker_mode == "mention":
            return self._submit_mention_completion()
        if self._picker_mode in {
            "skills-root",
            "skills-categories",
            "skills-results",
            "skills-installed",
            "skills-detail",
            "skills-install-input",
            "skills-local-install",
            "skills-confirm-install",
            "skills-confirm-update",
        }:
            return self._submit_skills_picker(raw_value)
        if self._picker_mode in {"agent-root", "agent-active", "agent-config", "agent-skills", "thread-skills", "agent-review"}:
            return self._submit_subagent_manager(raw_value)
        if self._subagent_editor is not None:
            return self._submit_subagent_editor_value(raw_value)
        if self._picker_mode == "history":
            return self._submit_history_picker()
        if self._picker_mode == "mcp-manager":
            return self._submit_mcp_manager(raw_value)
        if raw_value == "?":
            self._remember_prompt_entry(raw_value)
            self._clear_prompt()
            self._write_help_message()
            return True
        if self._human_loop is not None:
            return self._submit_human_loop_value(raw_value)
        if self._onboarding is not None:
            return self._submit_onboarding_value(raw_value)
        if raw_value.startswith("/"):
            return self._submit_slash_value(raw_value)
        return False

    def _submit_slash_value(self, raw_value: str) -> bool:
        token, _, remainder = raw_value.strip()[1:].partition(" ")
        selected = self._selected_slash_command(raw_value)
        exact = resolve_slash_command(token)
        if selected is not None:
            selected_matches_input = exact is not None and exact.name == selected.name
            if not selected_matches_input:
                completed = f"/{selected.name}"
                argument = remainder.strip()
                if argument:
                    completed = f"{completed} {argument}"
                prompt_input = self._prompt_input()
                prompt_input.value = completed
                prompt_input.cursor_position = len(completed)
                self._refresh_prompt_suggestions(completed)
                return True

        if exact is not None:
            self._run_slash_command(raw_value)
            return True

        if selected is None:
            self._run_slash_command(raw_value)
            return True
        return False

    def _selected_slash_command(self, raw_value: str):
        if self._picker_mode == "slash" and self._picker_rows:
            selected_key = self._selected_picker_key()
            if selected_key:
                return resolve_slash_command(selected_key)
        return best_slash_command_match(raw_value)

    def _show_picker(
        self,
        *,
        mode: str,
        title: str,
        columns: tuple[str, ...],
        rows: list[tuple[str, ...]],
        marks: set[str] | None = None,
    ) -> None:
        self._picker_mode = mode
        self._picker_title = title
        self._picker_rows = rows
        self._picker_index = 0
        self._picker_marks = set(marks or ())
        self._render_picker()

    def _hide_picker(self) -> None:
        self._picker_mode = None
        self._picker_title = ""
        self._picker_rows = []
        self._picker_index = 0
        self._picker_marks.clear()
        self._render_picker()

    def _move_picker_selection(self, delta: int) -> bool:
        if self._prompt_history_index is not None:
            return self._navigate_prompt_history(delta)
        if self._picker_mode is None or not self._picker_rows:
            return self._navigate_prompt_history(delta)
        target = min(max(self._picker_index + delta, 0), len(self._picker_rows) - 1)
        self._picker_index = target
        self._render_picker()
        return True

    def _dismiss_picker(self) -> bool:
        if self._picker_mode in {
            "slash",
            "theme",
            "history",
            "mcp-manager",
            "agent-root",
            "agent-active",
            "agent-config",
            "agent-skills",
            "agent-review",
            "thread-skills",
            "mention",
            "skills-root",
            "skills-categories",
            "skills-results",
            "skills-installed",
            "skills-detail",
            "skills-install-input",
            "skills-local-install",
            "skills-confirm-install",
            "skills-confirm-update",
        }:
            self._hide_picker()
            if self._onboarding is None:
                self._prompt_input().placeholder = PROMPT_PLACEHOLDER
            return True
        return False

    def _toggle_picker_mark(self) -> bool:
        if self._picker_mode not in {"agent-active", "mcp-manager", "agent-skills", "thread-skills"}:
            return False
        if self._prompt_input().value:
            return False
        key = self._selected_picker_key()
        if key is None or key == "__empty__":
            return True
        if key in self._picker_marks:
            self._picker_marks.remove(key)
        else:
            self._picker_marks.add(key)
        self._render_picker()
        return True

    def _remember_prompt_entry(self, raw_value: str) -> None:
        normalized = raw_value.strip()
        if not normalized:
            return
        if self._prompt_history and self._prompt_history[-1] == normalized:
            self._reset_prompt_history_cursor()
            return
        self._prompt_history.append(normalized)
        if len(self._prompt_history) > 100:
            self._prompt_history = self._prompt_history[-100:]
        self._reset_prompt_history_cursor()

    def _reset_prompt_history_cursor(self) -> None:
        self._prompt_history_index = None
        self._prompt_history_draft = ""

    def _navigate_prompt_history(self, delta: int) -> bool:
        if not self._prompt_history:
            return False
        prompt_input = self._prompt_input()
        if delta < 0:
            if self._prompt_history_index is None:
                self._prompt_history_draft = prompt_input.value
                self._prompt_history_index = len(self._prompt_history) - 1
            elif self._prompt_history_index > 0:
                self._prompt_history_index -= 1
            prompt_input.value = self._prompt_history[self._prompt_history_index]
        else:
            if self._prompt_history_index is None:
                return False
            if self._prompt_history_index < len(self._prompt_history) - 1:
                self._prompt_history_index += 1
                prompt_input.value = self._prompt_history[self._prompt_history_index]
            else:
                prompt_input.value = self._prompt_history_draft
                self._prompt_history_index = None
                self._prompt_history_draft = ""
        prompt_input.cursor_position = len(prompt_input.value)
        if self._onboarding is None:
            self._refresh_slash_suggestions(prompt_input.value)
        return True

    def _selected_picker_key(self) -> str | None:
        if not self._picker_rows:
            return None
        row_index = min(max(self._picker_index, 0), len(self._picker_rows) - 1)
        return str(self._picker_rows[row_index][0])

    async def _build_selected(self, spec: AgentSpec) -> None:
        try:
            diagnostics: list[str] = []
            self._set_run_state(True, f"Building {spec.name}")
            build_spec = self._spec_with_thread_skills(spec)
            agent = await build_agent_async(build_spec, self.config, diagnostics=diagnostics)
        except asyncio.CancelledError:
            self._set_run_state(False)
            return
        except Exception as exc:
            self._set_run_state(False)
            self._log(f"Build failed for {spec.name}: {exc}")
            return
        self._built_agents[spec.name] = agent
        self._built_agent_signatures[spec.name] = self._build_signature_for_spec(build_spec)
        self._set_run_state(False)
        for message in diagnostics:
            self._log(message)
        self._log(f"Built `{spec.name}` as `{type(agent).__name__}`.")

    async def _build_agent_for_name(self, agent_name: str):
        spec = self._agent_specs[agent_name]
        build_spec = self._spec_with_thread_skills(spec)
        signature = self._build_signature_for_spec(build_spec)
        agent = self._built_agents.get(agent_name)
        if agent is not None and self._built_agent_signatures.get(agent_name) == signature:
            return agent, []
        diagnostics: list[str] = []
        agent = await build_agent_async(build_spec, self.config, diagnostics=diagnostics)
        self._built_agents[agent_name] = agent
        self._built_agent_signatures[agent_name] = signature
        return agent, diagnostics

    async def _run_prompt(self, agent_name: str, prompt: str, *, plan_phase: bool | None = None) -> None:
        trace_table = None
        orchestration_table = None
        try:
            effective_plan_phase = self._plan_mode if plan_phase is None else plan_phase
            augmented_prompt = self._augment_prompt(prompt, plan_phase=effective_plan_phase)
            self._set_run_state(True, f"Preparing {agent_name}")
            agent, diagnostics = await self._build_agent_for_name(agent_name)
            for message in diagnostics:
                self._log(message)
            spec = self._agent_specs[agent_name]
            thread_id = self._active_thread_id(agent_name)
            thread_config = build_thread_config(agent_name, thread_id=thread_id)
            should_bootstrap_history = not await has_thread_checkpoint_async(
                self.config.sessions_dir,
                agent_name,
                thread_id=thread_id,
            )
            try:
                trace_table = self.query_one("#trace-table", TraceTable)
            except NoMatches:
                trace_table = None
            try:
                orchestration_table = self.query_one("#orchestration-table", OrchestrationTable)
            except NoMatches:
                orchestration_table = None
            if orchestration_table is not None:
                orchestration_table.configure_subagents(self._configured_subagents(spec))
            if trace_table is not None:
                trace_table.begin_run(agent_name, thread_id)
            append_chat_turn(
                self.config.sessions_dir,
                "user",
                augmented_prompt,
                agent_name=agent_name,
                thread_id=thread_id,
            )
            self._set_run_state(True, f"Working with {agent_name}")
            history = (
                load_chat_history(
                    self.config.sessions_dir,
                    limit=DEFAULT_HISTORY_REPLAY_LIMIT,
                    agent_name=agent_name,
                    thread_id=thread_id,
                )
                if should_bootstrap_history
                else []
            )
            payload = build_prompt_payload(augmented_prompt, history=history)
            result = None
            final_response = ""
            async for chunk in agent.astream(payload, config=thread_config, stream_mode="updates"):
                result = chunk
                for stream_event in parse_stream_chunk(chunk):
                    if stream_event.kind == "assistant":
                        final_response = stream_event.text
                        self._set_run_state(True, "Thinking...")
                        self._update_streaming_assistant(stream_event.text)
                    else:
                        if orchestration_table is not None:
                            orchestration_table.record_event(stream_event)
                        if trace_table is not None:
                            trace_table.record_event(stream_event)
                        self._append_stream_event(stream_event)
            response = extract_text_response(result)
        except asyncio.CancelledError:
            self._streaming_assistant_index = None
            self._set_run_state(False)
            if trace_table is not None:
                trace_table.record_status(
                    label=agent_name,
                    status="cancelled",
                    detail="Run interrupted.",
                )
            return
        except Exception as exc:
            self._set_run_state(False)
            if trace_table is not None:
                trace_table.record_status(
                    label=agent_name,
                    status="error",
                    detail=str(exc),
                )
            if self._maybe_start_human_loop(agent_name=agent_name, prompt=augmented_prompt, error_message=str(exc)):
                return
            self._log(f"Error: {exc}")
            return

        self._set_run_state(False)
        if response and not str(response).startswith("{'"):
            final_response = response
            self._finalize_streaming_assistant(response)
        else:
            self._finalize_streaming_assistant(final_response)
        if final_response:
            append_chat_turn(
                self.config.sessions_dir,
                "assistant",
                final_response,
                agent_name=agent_name,
                thread_id=thread_id,
            )
            self._render_top_panel()
        if effective_plan_phase:
            self._start_plan_confirmation(agent_name=agent_name, prompt=prompt, plan_text=final_response or "Plan ready.")
            if trace_table is not None:
                trace_table.record_status(
                    label=agent_name,
                    status="planned",
                    detail="Awaiting confirmation.",
                )
            return
        if trace_table is not None:
            trace_table.record_status(
                label=agent_name,
                status="complete",
                detail="Run finished.",
            )

    def _maybe_start_human_loop(self, *, agent_name: str, prompt: str, error_message: str) -> bool:
        request = self._build_human_loop_request(error_message)
        if request is None:
            return False
        self._human_loop = HumanLoopState(
            agent_name=agent_name,
            original_prompt=prompt,
            error_message=error_message,
            request_text=request["request_text"],
            placeholder=request["placeholder"],
            kind=str(request.get("kind", "retry")),
            sensitive=bool(request.get("sensitive", False)),
            choices=tuple(request.get("choices", ())),
        )
        self._append_transcript("\n".join(["Need Input", request["request_text"]]))
        prompt_input = self._prompt_input()
        prompt_input.password = self._human_loop.sensitive
        prompt_input.placeholder = self._human_loop.placeholder
        self._show_human_loop_picker(self._human_loop)
        prompt_input.focus()
        self._render_hint_line()
        return True

    def _maybe_start_preflight_human_loop(self, *, agent_name: str, prompt: str) -> bool:
        request = self._build_preflight_request(prompt)
        if request is None:
            return False
        self._human_loop = HumanLoopState(
            agent_name=agent_name,
            original_prompt=prompt,
            error_message="",
            request_text=request["request_text"],
            placeholder=request["placeholder"],
            kind="preflight",
            sensitive=False,
            choices=tuple(request.get("choices", ())),
        )
        self._append_transcript("\n".join(["Need Input", request["request_text"]]))
        prompt_input = self._prompt_input()
        prompt_input.password = False
        prompt_input.placeholder = self._human_loop.placeholder
        self._show_human_loop_picker(self._human_loop)
        prompt_input.focus()
        self._render_hint_line()
        return True

    def _start_plan_confirmation(self, *, agent_name: str, prompt: str, plan_text: str) -> None:
        request_text = (
            "Plan mode is active. Review the proposed plan above, then choose what to do next.\n"
            "Reply `continue` to execute it now, `revise` to give new guidance, or `cancel` to stop."
        )
        self._human_loop = HumanLoopState(
            agent_name=agent_name,
            original_prompt=prompt,
            error_message="",
            request_text=request_text,
            placeholder="Type continue, revise, or /cancel",
            kind="plan-approval",
            sensitive=False,
            choices=(
                ("continue", "Continue", "Run the task now using the approved plan."),
                ("revise", "Revise", "Add more guidance before execution."),
                ("cancel", "Cancel", "Stop after planning only."),
            ),
        )
        self._append_transcript("\n".join(["Need Input", request_text]))
        prompt_input = self._prompt_input()
        prompt_input.password = False
        prompt_input.placeholder = self._human_loop.placeholder
        self._show_human_loop_picker(self._human_loop)
        prompt_input.focus()
        self._render_hint_line()

    def _submit_human_loop_value(self, raw_value: str) -> bool:
        state = self._human_loop
        if state is None:
            return False
        answer = raw_value.strip()
        if not answer and self._picker_mode == "human-loop":
            answer = self._selected_picker_key() or ""
        if not answer:
            return True
        self._remember_prompt_entry(answer)
        display_value = "[hidden]" if state.sensitive else answer
        self._append_transcript(f"> {display_value}")
        self._human_loop = None
        prompt_input = self._prompt_input()
        prompt_input.password = False
        self._clear_prompt()
        if state.kind == "plan-approval":
            lowered = answer.strip().lower()
            if lowered in {"continue", "yes", "y", "proceed", "ok"}:
                follow_up = (
                    f"{state.original_prompt}\n\n"
                    "The user approved the plan. Execute it now. You may perform the required changes and commands."
                )
                self._active_agent_worker = self.run_worker(
                    self._run_prompt(state.agent_name, follow_up, plan_phase=False),
                    exclusive=True,
                    thread=False,
                )
                return True
            if lowered in {"cancel", "/cancel", "stop"}:
                self._append_transcript("\n".join(["System", "Stopped after the planning phase."]))
                return True
            follow_up = (
                f"{state.original_prompt}\n\n"
                "Additional guidance from the user after reviewing the plan:\n"
                f"- user input: {answer}\n"
                "Update the plan only. Do not execute yet."
            )
            self._active_agent_worker = self.run_worker(
                self._run_prompt(state.agent_name, follow_up, plan_phase=True),
                exclusive=True,
                thread=False,
            )
            return True
        if state.kind == "preflight":
            if answer.strip().lower() in {"continue", "yes", "y", "proceed", "ok"}:
                follow_up = (
                    f"{state.original_prompt}\n\n"
                    "The user explicitly approved continuing with this potentially privileged or destructive task. "
                    "Proceed carefully, minimize risk, and ask again if you need a more specific requirement."
                )
            else:
                follow_up = (
                    f"{state.original_prompt}\n\n"
                    "Additional guidance from the user before starting the task:\n"
                    f"- user input: {answer}\n"
                    "Use this guidance to continue more safely and efficiently."
                )
        else:
            follow_up = (
                f"{state.original_prompt}\n\n"
                f"Additional input from the user after a blocked attempt:\n"
                f"- previous error: {state.error_message}\n"
                f"- user input: {answer}\n"
                "Continue the task using this new input. If the task still requires user action, ask clearly for the next specific requirement."
            )
        self._active_agent_worker = self.run_worker(self._run_prompt(state.agent_name, follow_up), exclusive=True, thread=False)
        return True

    def _build_preflight_request(self, prompt: str) -> dict[str, str] | None:
        normalized = " ".join(prompt.split()).lower()
        if not normalized:
            return None
        matched_categories: list[tuple[str, str, str]] = []
        for category, keywords, lead, options in PREFLIGHT_RISK_RULES:
            if any(keyword in normalized for keyword in keywords):
                matched_categories.append((category, lead, options))
        if not matched_categories:
            return None
        category_labels = ", ".join(category for category, _lead, _options in matched_categories)
        guidance_lines = [f"- {lead} {options}" for _category, lead, options in matched_categories]
        return {
            "request_text": (
                f"This request matches one or more high-risk categories: {category_labels}.\n"
                + "\n".join(guidance_lines)
            ),
            "placeholder": "Type continue, manual only, dry run first, or /cancel",
            "choices": (
                ("continue", "Continue", "Proceed carefully with explicit approval."),
                ("dry run first", "Dry Run", "Analyze and show the plan before changing anything."),
                ("show commands only", "Commands Only", "Prepare the exact commands without executing them."),
                ("manual only", "Manual Only", "Explain how to do it manually instead of executing."),
            ),
        }

    def _build_human_loop_request(self, error_message: str) -> dict[str, object] | None:
        normalized = " ".join(error_message.split()).lower()
        if not normalized:
            return None
        if any(
            token in normalized
            for token in (
                "permission denied",
                "operation not permitted",
                "access denied",
                "requires elevated privileges",
                "requires root",
                "sudo",
                "password",
                "authentication",
            )
        ):
            return {
                "request_text": (
                    "This task is blocked by system permissions or authentication. I can't safely keep going without your help. "
                    "Reply with the exact next requirement or instruction, such as an alternative path, confirmation to skip the privileged step, "
                    "or the command you want the agent to use after you grant access. Do not paste your system password into chat."
                ),
                "placeholder": "Type the required permission guidance, or /cancel",
                "kind": "retry",
                "sensitive": False,
                "choices": (
                    ("manual only", "Manual Only", "Stop executing and explain the manual privileged steps."),
                    ("show commands only", "Commands Only", "Show the privileged commands without running them."),
                    ("skip the privileged step", "Skip Step", "Continue without the blocked privileged action."),
                ),
            }
        if any(
            token in normalized
            for token in (
                "not found",
                "missing api key",
                "missing",
                "no such file",
                "unknown skill source",
                "command was not found",
                "not available",
            )
        ):
            return {
                "request_text": (
                    "This task needs something from you before it can continue. Reply with the missing value, corrected path, command, "
                    "or instruction for how the agent should proceed."
                ),
                "placeholder": "Type the missing input, or /cancel",
                "kind": "retry",
                "sensitive": False,
                "choices": (
                    ("show what is missing", "Explain Missing", "Summarize the exact missing requirement again."),
                    ("manual only", "Manual Only", "Stop executing and explain the next manual steps."),
                ),
            }
        return None

    def _augment_prompt(self, prompt: str, *, plan_phase: bool | None = None) -> str:
        instructions: list[str] = []
        instructions.append(f"Shell personality: {self._personality}. Keep the final response aligned with that style.")
        if self._approval_mode == "read-only":
            instructions.append(
                "Approval mode is read-only. Do not modify files, run write operations, or perform destructive changes. Inspect and explain only."
            )
        elif self._approval_mode == "confirm":
            instructions.append(
                "Approval mode is confirm. Before any destructive or modifying action, explain the intended action and ask for confirmation."
            )
        else:
            instructions.append("Approval mode is auto. Prefer efficient execution, but still call out meaningful risks.")
        effective_plan_mode = self._plan_mode if plan_phase is None else plan_phase
        if effective_plan_mode:
            instructions.append(
                "Plan mode is enabled. First return a concise execution plan and wait for user confirmation before making changes."
            )
        if plan_phase:
            instructions.append(
                "This is a strict planning pass. Do not execute commands that modify state, do not edit files, and do not perform destructive actions. Return only the plan and any blockers."
            )
        if self._project_agents_context is not None:
            instructions.append(
                f"Project instructions from {self._project_agents_context.path}:\n{self._project_agents_context.summary}"
            )
        if self._session_summary:
            instructions.append(f"Compacted session note:\n{self._session_summary}")
        if self._mentioned_contexts:
            mention_lines = [f"- {item.path}: {item.summary}" for item in self._mentioned_contexts[-6:]]
            instructions.append("Attached context:\n" + "\n".join(mention_lines))
        agent_name = self._current_agent_name()
        thread_skills = self._thread_attached_skills(agent_name)
        if thread_skills:
            instructions.append("Thread-attached skills:\n" + "\n".join(f"- {item}" for item in thread_skills))
        if not instructions:
            return prompt
        return f"{prompt}\n\nSession instructions:\n" + "\n".join(f"- {line}" for line in instructions)

    def _show_subagent_manager(self) -> None:
        rows = [
            ("__create__", "Create New Subagent", "Create a saved supervisor-managed specialist."),
            ("__active__", "Active Subagents", "Choose which saved subagents are active for `supervisor-agent`."),
        ]
        for name in sorted(self._saved_subagent_specs):
            spec = self._saved_subagent_specs[name]
            model = self._display_model_name(spec.model or self.config.default_model)
            active = "active" if name in self._active_saved_subagent_names else "inactive"
            rows.append((name, name, f"{spec.description or 'User-created specialist'}  •  {model}  •  {active}"))
        self._show_picker(
            mode="agent-root",
            title="Subagents",
            columns=("Name", "Details"),
            rows=rows,
        )
        self._clear_prompt()
        self._prompt_input().placeholder = "Enter opens a menu. Create New starts a draft. /cancel closes."
        self._prompt_input().focus()

    def _show_active_subagent_picker(self) -> None:
        rows = []
        for name in sorted(self._saved_subagent_specs):
            spec = self._saved_subagent_specs[name]
            rows.append((name, name, spec.description or "User-created specialist"))
        if not rows:
            rows.append(("__empty__", "No saved subagents", "Create one first."))
        self._show_picker(
            mode="agent-active",
            title="Active Subagents",
            columns=("Name", "Details"),
            rows=rows,
            marks=set(self._active_saved_subagent_names),
        )
        self._clear_prompt()
        self._prompt_input().placeholder = "Space toggles active. Enter saves. Type back to return."
        self._prompt_input().focus()

    def _show_subagent_config(self, name: str) -> None:
        spec = self._saved_subagent_specs[name]
        self._agent_config_name = name
        active_label = "Deactivate" if name in self._active_saved_subagent_names else "Activate"
        rows = [
            ("manual-edit", "Manual Edit", "Edit name, system prompt, and attached skills step by step."),
            ("ai-chat", "AI Chat Refine", "Describe changes in natural language and generate a reviewed draft."),
            ("skills", "Skills", f"Manage attached skills ({len(spec.skills)} currently attached)."),
            ("toggle-active", active_label, "Toggle whether this subagent is active under the supervisor."),
            ("delete", "Delete", "Delete this saved subagent."),
            ("back", "Back", "Return to the subagent list."),
        ]
        self._show_picker(
            mode="agent-config",
            title=f"Subagent: {name}",
            columns=("Action", "Details"),
            rows=rows,
        )
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose an action with Up/Down, then press Enter"
        self._prompt_input().focus()

    def _show_agent_skills_picker(self, editor: SubagentEditorState) -> None:
        rows = self._available_attachable_skill_rows()
        self._show_picker(
            mode="agent-skills",
            title="Subagent Skills",
            columns=("Skill", "Details"),
            rows=rows,
            marks=set(editor.skills),
        )
        self._clear_prompt()
        self._prompt_input().placeholder = "Space toggles skills. Enter saves. Type back to skip."
        self._prompt_input().focus()

    def _show_thread_skills_picker(self) -> None:
        agent_name = self._current_agent_name() or "supervisor-agent"
        rows = self._available_attachable_skill_rows()
        self._show_picker(
            mode="thread-skills",
            title="Thread Skills",
            columns=("Skill", "Details"),
            rows=rows,
            marks=set(self._thread_attached_skills(agent_name)),
        )
        self._clear_prompt()
        self._prompt_input().placeholder = "Space toggles thread-only skills. Enter saves. Type back to cancel."
        self._prompt_input().focus()

    def _available_attachable_skill_rows(self) -> list[tuple[str, str, str]]:
        rows = [("installed", "All local installed skills", "Attach the whole local installed-skill library token `installed`.")]
        seen: set[str] = {"installed"}
        for skill in list_local_skills(self.config.skills_dir):
            if skill.name in seen:
                continue
            rows.append((skill.name, skill.name, skill.description))
            seen.add(skill.name)
        try:
            _result, installed_records = list_installed_skills_cli(workspace_dir=self.config.workspace_dir)
        except Exception:
            installed_records = []
        for record in installed_records:
            token = record.name.strip()
            if not token or token in seen:
                continue
            rows.append((token, token, record.details or f"Installed via Skills CLI ({record.scope or 'installed'})."))
            seen.add(token)
        if len(rows) == 1:
            rows.append(("__empty__", "No attachable skills found", "Install skills first, or skip this step."))
        return rows

    def _thread_skill_key(self, agent_name: str, thread_id: str | None = None) -> tuple[str, str]:
        resolved_thread_id = thread_id or self._active_thread_id(agent_name) or get_thread_id(agent_name)
        return agent_name, resolved_thread_id

    def _thread_attached_skills(self, agent_name: str | None, thread_id: str | None = None) -> list[str]:
        if not agent_name:
            return []
        return list(self._thread_skill_tokens.get(self._thread_skill_key(agent_name, thread_id), []))

    def _spec_with_thread_skills(self, spec: AgentSpec) -> AgentSpec:
        merged_skills = sorted(dict.fromkeys([*spec.skills, *self._thread_attached_skills(spec.name)]))
        if merged_skills == list(spec.skills):
            return spec
        return AgentSpec(
            name=spec.name,
            model=spec.model,
            system_prompt=spec.system_prompt,
            description=spec.description,
            tools=list(spec.tools),
            subagents=list(spec.subagents),
            skills=merged_skills,
            mcp_servers=list(spec.mcp_servers),
            workspace_dir=spec.workspace_dir,
        )

    def _build_signature_for_spec(self, spec: AgentSpec) -> tuple[str, ...]:
        return (spec.name, spec.model, spec.system_prompt, *sorted(spec.skills))

    def _ensure_attachable_skill_tokens(self, requested: list[str]) -> list[str]:
        local_names = {skill.name for skill in list_local_skills(self.config.skills_dir)}
        resolved: list[str] = []
        for token in requested:
            cleaned = token.strip()
            if not cleaned or cleaned == "__empty__":
                continue
            if cleaned == "installed":
                resolved.append(cleaned)
                continue
            if cleaned in local_names:
                resolved.append(cleaned)
                continue
            source_path = self._discover_external_skill_path(cleaned)
            if source_path is None:
                self._append_transcript("\n".join(["Warning", f"Could not resolve installed skill `{cleaned}` into the local skill library."]))
                continue
            try:
                installed = install_local_skill(source_path, self.config.skills_dir, overwrite=False)
                resolved.append(installed.name)
                local_names.add(installed.name)
            except FileExistsError:
                resolved.append(cleaned)
                local_names.add(cleaned)
        return sorted(dict.fromkeys(resolved))

    def _discover_external_skill_path(self, skill_name: str) -> str | None:
        candidates = [
            Path(self.config.workspace_dir) / ".agents" / "skills" / skill_name,
            Path(self.config.workspace_dir) / ".codex" / "skills" / skill_name,
            Path.home() / ".agents" / "skills" / skill_name,
            Path.home() / ".codex" / "skills" / skill_name,
            Path.home() / ".config" / "agents" / "skills" / skill_name,
        ]
        for candidate in candidates:
            if (candidate / "SKILL.md").exists():
                return candidate.as_posix()
        return None

    def _show_history_picker(self) -> None:
        agent_name = self._current_agent_name()
        threads = list_chat_threads(self.config.sessions_dir, limit=100, agent_name=agent_name)
        rows = []
        for summary in threads:
            preview = shorten(summary.last_content.replace("\n", " "), width=72, placeholder="...")
            rows.append(
                (
                    summary.thread_id or "",
                    summary.thread_id or "(no thread id)",
                    f"{self._relative_time(summary.last_created_at)}  •  {preview}",
                )
            )
        if not rows:
            rows.append(("__empty__", "No saved threads", "Run a prompt first to create thread history."))
        self._show_picker(mode="history", title="History", columns=("Thread", "Details"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose a thread with Up/Down, then press Enter"
        self._prompt_input().focus()

    def _show_mcp_manager(self) -> None:
        servers = load_mcp_servers(self.config.mcp_config_path)
        rows = [("__bootstrap__", "Bootstrap Remote Defaults", "Add the default remote MCP servers into the config.")]
        rows.extend(
            (
                name,
                name,
                f"{server.transport}  •  {server.url or server.command or '-'}",
            )
            for name, server in sorted(servers.items())
        )
        self._show_picker(
            mode="mcp-manager",
            title="MCP Servers",
            columns=("Server", "Details"),
            rows=rows,
            marks=set(servers.keys()),
        )
        self._clear_prompt()
        self._prompt_input().placeholder = "Space toggles configured servers. Enter saves. Type bootstrap or /cancel"
        self._prompt_input().focus()

    def _show_skills_root(self) -> None:
        last_query = self._skills_state.query or self.config.skills_last_query or "react"
        rows = [
            ("browse", "Browse categories", "Starter discovery queries such as react, docs, docker, and automation."),
            ("search", "Search skills", f"Type a query and press Enter. Last query: `{last_query}`"),
            ("installed", "View installed skills", "Runs `npx skills list` and shows installed skills."),
            ("check", "Check for updates", "Runs `npx skills check` and summarizes available updates."),
            ("update", "Update all skills", "Runs `npx skills update` after confirmation if required."),
            ("install-repo", "Install from repo/package", "Type `owner/repo` or `owner/repo@skill` and press Enter."),
            ("local", "Install from local path", "Fallback for a local skill directory or `SKILL.md` path."),
        ]
        self._show_picker(mode="skills-root", title="Skills", columns=("Action", "Details"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose with Up/Down, or type a search query and press Enter"
        self._prompt_input().focus()

    def _show_skills_categories(self) -> None:
        rows = [(query, label, f"Starter query: `{query}`") for _, label, query in SKILLS_BROWSE_CATEGORIES]
        self._show_picker(mode="skills-categories", title="Browse Skills", columns=("Category", "Query"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose a category with Up/Down, then press Enter"
        self._prompt_input().focus()

    def _show_skills_results(self, query: str, results: list[SkillSearchResult], *, note: str = "") -> None:
        self._skills_state.query = query
        self.config.skills_last_query = query
        self._save_shell_settings()
        self._skills_state.results = list(results)
        self._skills_state.detail_mode = "search"
        rows: list[tuple[str, ...]] = []
        for index, result in enumerate(results):
            meta: list[str] = [result.source]
            if result.install_count_text:
                meta.append(result.install_count_text)
            if result.quality.labels:
                meta.extend(result.quality.labels[:1])
            rows.append(
                (
                    str(index),
                    result.name,
                    "  •  ".join(meta),
                )
            )
        if not rows:
            rows.append(("__empty__", f"No results for `{query}`", note or "Try another keyword such as react, docs, docker, or automation."))
        self._show_picker(mode="skills-results", title=f"Skills: {query}", columns=("Skill", "Details"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose a result with Up/Down, then press Enter"
        self._prompt_input().focus()

    def _show_skills_installed(self, records: list[InstalledSkillRecord], *, note: str = "") -> None:
        self._skills_state.installed = list(records)
        self._skills_state.detail_mode = "installed"
        rows = [
            (
                str(index),
                record.name,
                shorten(record.details, width=88, placeholder="..."),
            )
            for index, record in enumerate(records)
        ]
        if not rows:
            rows.append(("__empty__", "No installed skills found", note or "Install a skill first, then come back here."))
        self._show_picker(mode="skills-installed", title="Installed Skills", columns=("Skill", "Details"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose a skill with Up/Down, or type `back`"
        self._prompt_input().focus()

    def _show_skill_detail_actions(self, *, mode: str, index: int) -> None:
        self._skills_state.selected_index = index
        if mode == "search":
            result = self._skills_state.results[index]
            command = result.install_command or ()
            labels = ", ".join(result.quality.labels) or "No trust signals surfaced yet."
            self._append_transcript(
                "\n".join(
                    [
                        "Skill Details",
                        f"{result.name}",
                        f"Description: {result.description}",
                        f"Source repo: {result.source}",
                        f"Skills page: {result.skills_page_url or '-'}",
                        f"GitHub repo: {result.github_repo_url or '-'}",
                        f"Install count: {result.install_count_text or '-'}",
                        f"Install command: {render_command(command) if command else 'Unavailable from parsed output'}",
                        f"Why useful: {result.why_useful or '-'}",
                        f"Trust: {labels}",
                    ]
                )
            )
            self._skills_state.pending_source = result.install_source
            self._skills_state.pending_skill_name = result.skill_name
            self._skills_state.pending_command = command
            rows = [("show-command", "Show install command", "Display the exact command that will run."), ("back", "Back to results", "Return to the current result list.")]
            if result.install_source is not None:
                rows.insert(0, ("install", "Install", "Install this skill from the Skills CLI."))
            if index > 0:
                rows.append(("prev", "Previous result", "Open the previous search result."))
            if index < len(self._skills_state.results) - 1:
                rows.append(("next", "Next result", "Open the next search result."))
            title = f"Skill: {result.name}"
            placeholder = "Choose install/back/next/prev, or type `back`"
        else:
            record = self._skills_state.installed[index]
            self._append_transcript(
                "\n".join(
                    [
                        "Installed Skill",
                        f"{record.name}",
                        record.details,
                    ]
                )
            )
            self._skills_state.pending_source = record.source
            self._skills_state.pending_skill_name = None
            self._skills_state.pending_command = ()
            rows = [
                ("back", "Back to installed list", "Return to the installed skills list."),
                ("check", "Check updates", "Run `npx skills check`."),
                ("update", "Update all", "Run `npx skills update`."),
            ]
            title = f"Installed: {record.name}"
            placeholder = "Choose check/update/back, or type `back`"
        self._show_picker(mode="skills-detail", title=title, columns=("Action", "Details"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = placeholder
        self._prompt_input().focus()

    def _show_skills_repo_install_input(self) -> None:
        self._hide_picker()
        self._clear_prompt()
        self._prompt_input().placeholder = "Enter owner/repo or owner/repo@skill, then press Enter"
        self._picker_mode = "skills-install-input"
        self._prompt_input().focus()

    def _show_skills_local_install_input(self) -> None:
        self._hide_picker()
        self._clear_prompt()
        self._prompt_input().placeholder = "Enter a local skill directory or SKILL.md path, then press Enter"
        self._picker_mode = "skills-local-install"
        self._prompt_input().focus()

    def _show_skills_confirm(self, *, action: str, command: tuple[str, ...], note: str) -> None:
        self._skills_state.pending_note = note
        self._skills_state.pending_command = command
        rows = [
            ("continue", "Continue", "Run the selected Skills CLI command."),
            ("show-command", "Show command", "Display the exact command instead of running it."),
            ("back", "Back", "Return without running the command."),
        ]
        self._show_picker(mode=f"skills-confirm-{action}", title="Confirm Skills Action", columns=("Action", "Details"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose continue/show-command/back, or type a choice then press Enter"
        self._prompt_input().focus()

    def _save_shell_settings(self) -> None:
        self.config.shell_personality = self._personality
        self.config.approval_mode = self._approval_mode
        self.config.plan_mode = self._plan_mode
        self.config.skills_last_query = self._skills_state.query
        self.config.skills_install_scope = "global"
        if self.config_path is not None:
            self.config = load_config(save_config(self.config, self.config_path))

    def _load_project_agents_context(self) -> None:
        path = Path(self.config.workspace_dir) / "AGENTS.md"
        if not path.exists():
            self._project_agents_context = None
            return
        self._project_agents_context = MentionedContext(
            path=str(path),
            summary=self._summarize_path(path),
        )

    def _mention_path(self, raw_path: str) -> None:
        context = self._build_context_for_path(raw_path)
        if context is None:
            self._log(f"Missing path: `{raw_path}`")
            return
        self._mentioned_contexts.append(context)
        self._append_transcript("\n".join(["Mention", f"Attached `{context.path}`", context.summary]))

    def _build_context_for_path(self, raw_path: str) -> MentionedContext | None:
        workspace_root = Path(self.config.workspace_dir).resolve()
        candidate = Path(os.path.expanduser(raw_path))
        if not candidate.is_absolute():
            candidate = workspace_root / candidate
        candidate = candidate.resolve()
        if not candidate.exists():
            return None
        return MentionedContext(path=self._short_path(str(candidate)), summary=self._summarize_path(candidate))

    def _summarize_path(self, path: Path) -> str:
        if path.is_dir():
            entries = sorted(child.name for child in path.iterdir())[:8]
            extra = "" if len(entries) < 8 else ", ..."
            return f"Directory with entries: {', '.join(entries)}{extra}".strip()
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            return f"Unable to read file: {exc}"
        normalized = " ".join(content.split())
        return shorten(normalized, width=220, placeholder="...")

    def _resolve_prompt_mentions(self, prompt: str) -> tuple[str, list[MentionedContext]]:
        contexts: list[MentionedContext] = []
        cleaned = prompt
        for mention in self._extract_prompt_mentions(prompt):
            context = self._build_context_for_path(mention.token_path)
            if context is None:
                continue
            contexts.append(context)
            cleaned = cleaned.replace(mention.raw_token, context.path)
        cleaned = " ".join(cleaned.split())
        return cleaned, contexts

    def _extract_prompt_mentions(self, prompt: str) -> list[PromptMention]:
        mentions: list[PromptMention] = []
        for match in re.finditer(r"(?<!\S)@([^\s@]+)", prompt):
            token = match.group(1).rstrip(".,:;!?")
            raw_token = match.group(0)
            if not token:
                continue
            mentions.append(PromptMention(raw_token=raw_token, token_path=token))
        return mentions

    def _compact_session(self) -> None:
        if not self._transcript_blocks:
            self._log("Nothing to compact yet.")
            return
        self._session_summary = self._build_session_summary()
        self._transcript_blocks = [
            "\n".join(
                [
                    "Compact",
                    self._session_summary,
                ]
            )
        ]
        self._streaming_assistant_index = None
        self._render_conversation()
        self._append_transcript("\n".join(["System", "Compacted the session into one reusable summary block for future prompts."]))

    def _build_session_summary(self) -> str:
        user_goals: list[str] = []
        system_events: list[str] = []
        assistant_updates: list[str] = []
        for block in self._transcript_blocks[-16:]:
            normalized = " ".join(block.split())
            if not normalized:
                continue
            if block.startswith("> "):
                user_goals.append(shorten(block[2:], width=160, placeholder="..."))
                continue
            header, _, body = block.partition("\n")
            body = " ".join(body.split())
            if header in {"System", "Setup", "Need Input", "Plan Mode"} and body:
                system_events.append(shorten(body, width=160, placeholder="..."))
            elif header in {VISIBLE_BRAND, "Thinking", "Diff", "Init", "Mention"} and body:
                assistant_updates.append(shorten(body, width=160, placeholder="..."))
        lines = ["Session summary"]
        if user_goals:
            lines.append(f"Goal: {user_goals[-1]}")
        if assistant_updates:
            lines.append("Recent outcomes:")
            lines.extend(f"- {item}" for item in assistant_updates[-3:])
        if system_events:
            lines.append("Current state:")
            lines.extend(f"- {item}" for item in system_events[-2:])
        if self._mentioned_contexts:
            lines.append("Attached context:")
            lines.extend(f"- {item.path}" for item in self._mentioned_contexts[-3:])
        return "\n".join(lines)

    def _resume_thread(self, thread_id: str | None = None) -> None:
        agent_name = self._current_agent_name() or "supervisor-agent"
        if thread_id:
            self._handle_thread_selection(ThreadSelection(agent_name=agent_name, thread_id=thread_id, created_new=False))
            return
        threads = list_chat_threads(self.config.sessions_dir, limit=1, agent_name=agent_name)
        if not threads or not threads[0].thread_id:
            self._log("No saved thread available to resume.")
            return
        self._handle_thread_selection(ThreadSelection(agent_name=agent_name, thread_id=threads[0].thread_id, created_new=False))

    async def _reset_agent_session(self, agent_name: str) -> None:
        default_thread_id = get_thread_id(agent_name)
        current_thread_id = self._active_thread_id(agent_name)
        thread_ids_to_clear = {default_thread_id}
        if current_thread_id:
            thread_ids_to_clear.add(current_thread_id)

        self._set_run_state(False)
        self._human_loop = None
        self._subagent_editor = None
        self._ctrl_c_armed_at = 0.0
        self._session_summary = None
        self._mentioned_contexts.clear()
        self._streaming_assistant_index = None
        self._hide_picker()
        prompt_input = self._prompt_input()
        prompt_input.password = False

        removed_turns = 0
        for thread_id in thread_ids_to_clear:
            removed_turns += delete_chat_thread(
                self.config.sessions_dir,
                agent_name=agent_name,
                thread_id=thread_id,
            )
            try:
                await delete_langgraph_thread_async(self.config.sessions_dir, thread_id)
            except Exception:
                pass

        self._active_threads[agent_name] = default_thread_id
        self._transcript_blocks.clear()
        self._render_conversation()
        self.query_one("#trace-table", TraceTable).reset()
        self.query_one("#orchestration-table", OrchestrationTable).reset()
        self._welcome_written = False
        self._render_top_panel()
        self._clear_prompt()
        if self._needs_provider_onboarding():
            self._resume_onboarding()
        else:
            self._write_welcome_banner()
        self._append_transcript(
            "\n".join(
                [
                    "Reset",
                    f"Reset `{agent_name}` to a fresh default session on `{default_thread_id}`.",
                    f"Cleared {removed_turns} saved chat turn(s) and dropped deepagent checkpoint state for this session.",
                ]
            )
        )

    def _fork_current_thread(self) -> None:
        agent_name = self._current_agent_name() or "supervisor-agent"
        source_thread_id = self._active_thread_id(agent_name)
        if source_thread_id is None:
            self.action_new_thread()
            return
        turns = load_chat_history(
            self.config.sessions_dir,
            limit=DEFAULT_HISTORY_REPLAY_LIMIT,
            agent_name=agent_name,
            thread_id=source_thread_id,
        )
        new_thread_id = create_thread_id(agent_name)
        for turn in turns:
            append_chat_turn(
                self.config.sessions_dir,
                turn.role,
                turn.content,
                agent_name=agent_name,
                thread_id=new_thread_id,
            )
        self._active_threads[agent_name] = new_thread_id
        self._load_thread_transcript(agent_name, new_thread_id)
        self._render_top_panel()
        self._append_transcript("\n".join(["Fork", f"Forked `{source_thread_id}` into `{new_thread_id}`."]))

    def _show_git_diff(self) -> None:
        try:
            result = subprocess.run(
                ["git", "diff", "--no-color", "--unified=1", "--", "."],
                cwd=self.config.workspace_dir,
                check=False,
                capture_output=True,
                text=True,
            )
        except OSError as exc:
            self._log(f"Unable to run git diff: {exc}")
            return
        output = (result.stdout or result.stderr or "").strip()
        if result.returncode not in {0, 1}:
            self._log(output or "Unable to read git diff.")
            return
        rendered = self._render_git_diff_summary(output)
        self._append_transcript("\n".join(["Diff", rendered]))

    def _render_git_diff_summary(self, diff_text: str) -> str:
        if not diff_text.strip():
            return "No uncommitted changes."
        lines = diff_text.splitlines()
        blocks: list[str] = []
        current_path = ""
        additions = 0
        deletions = 0
        snippets: list[str] = []

        def flush() -> None:
            nonlocal current_path, additions, deletions, snippets
            if not current_path:
                return
            header = f"• Edited {current_path} (+{additions} -{deletions})"
            body = "\n".join([header, *snippets[:8]])
            blocks.append(body)
            current_path = ""
            additions = 0
            deletions = 0
            snippets = []

        for line in lines:
            if line.startswith("diff --git "):
                flush()
                continue
            if line.startswith("+++ b/"):
                current_path = line.removeprefix("+++ b/")
                continue
            if line.startswith("@@"):
                snippet = line.split("@@", 2)[-1].strip()
                if snippet:
                    snippets.append(f"    ⋮ {snippet}")
                continue
            if not current_path:
                continue
            if line.startswith("+") and not line.startswith("+++"):
                additions += 1
                snippets.append(f"    + {line[1:]}")
            elif line.startswith("-") and not line.startswith("---"):
                deletions += 1
                snippets.append(f"    - {line[1:]}")
            elif line.startswith(" "):
                snippets.append(f"      {line[1:]}")
        flush()
        return "\n\n".join(blocks) if blocks else "No uncommitted changes."

    def _init_agents_md(self) -> None:
        path = Path(self.config.workspace_dir) / "AGENTS.md"
        if path.exists():
            self._log(f"`{path}` already exists.")
            return
        scaffold = self._build_agents_md_content()
        path.write_text(scaffold, encoding="utf-8")
        self._load_project_agents_context()
        self._append_transcript(
            "\n".join(
                [
                    "Init",
                    f"Created `{self._short_path(str(path))}`.",
                    "Loaded this project guidance for future TUI sessions.",
                ]
            )
        )

    def _build_agents_md_content(self) -> str:
        workspace_root = Path(self.config.workspace_dir)
        readme_path = workspace_root / "README.md"
        project_name = workspace_root.name
        project_summary = "Project-specific agent guidance."
        if readme_path.exists():
            readme_text = readme_path.read_text(encoding="utf-8", errors="replace")
            lines = [line.strip() for line in readme_text.splitlines() if line.strip()]
            if lines:
                project_summary = lines[1] if len(lines) > 1 else lines[0]
        top_entries = ", ".join(path.name for path in sorted(workspace_root.iterdir())[:8])
        return "\n".join(
            [
                f"# AGENTS.md for {project_name}",
                "",
                "## Project Summary",
                project_summary,
                "",
                "## Stack",
                "- Python project managed with `uv`.",
                "- Main package: `agencli`.",
                "- TUI is built with Textual.",
                "",
                "## Workspace Shape",
                f"- Top-level entries: {top_entries}",
                "- Important runtime areas: `agencli/`, `tests/`, and project docs.",
                "",
                "## Agent Workflow",
                "- Inspect relevant files before editing.",
                "- Prefer precise, minimal changes.",
                "- Run targeted unittest coverage after edits.",
                "- Keep terminal UX keyboard-first and transcript-friendly.",
                "",
                "## Verification",
                "- Primary test command: `uv run python -m unittest tests.test_tui_app tests.test_runtime tests.test_tui_commands tests.test_mcp_tools`",
                "",
                "## Guardrails",
                "- Ask before destructive operations.",
                "- Prefer grouped operations over repetitive tool chatter.",
                "- Keep prompts and summaries concise and implementation-focused.",
            ]
        )

    def _start_subagent_editor(self, *, mode: str, spec: AgentSpec | None = None) -> None:
        self._subagent_editor = SubagentEditorState(
            mode=mode,
            original_name=spec.name if spec is not None else None,
            name=spec.name if spec is not None else "",
            system_prompt=spec.system_prompt if spec is not None else "",
            model=self._display_model_name(spec.model or self.config.default_model) if spec is not None else "",
            workspace_dir=spec.workspace_dir or "" if spec is not None else "",
            skills=list(spec.skills) if spec is not None else [],
            step="name",
        )
        self._hide_picker()
        self._clear_prompt()
        intro = "Create Subagent" if mode == "new" else f"Edit Subagent: {spec.name}"
        self._append_transcript("\n".join([intro, "Name the subagent. Press Enter to keep the current value when editing."]))
        self._prompt_input().placeholder = spec.name if spec is not None else "subagent-name"
        self._prompt_input().focus()

    def _start_subagent_ai_refine(self, spec: AgentSpec) -> None:
        self._subagent_editor = SubagentEditorState(
            mode="ai-edit",
            original_name=spec.name,
            name=spec.name,
            system_prompt=spec.system_prompt,
            model=self._display_model_name(spec.model or self.config.default_model),
            workspace_dir=spec.workspace_dir or "",
            skills=list(spec.skills),
            step="ai-guidance",
        )
        self._hide_picker()
        self._clear_prompt()
        self._append_transcript("\n".join(["AI Chat Refine", f"Describe how `{spec.name}` should change."]))
        self._prompt_input().placeholder = "Example: make it stricter about batch operations and clearer in summaries"
        self._prompt_input().focus()

    def _submit_subagent_editor_value(self, raw_value: str) -> bool:
        state = self._subagent_editor
        if state is None:
            return False
        answer = raw_value.strip()
        if state.step == "name":
            state.name = answer or state.name
            if not state.name:
                return True
            self._append_transcript(f"> {state.name}")
            state.step = "system-prompt"
            self._clear_prompt()
            self._append_transcript("\n".join(["Subagent", "Enter the system prompt for this subagent."]))
            self._prompt_input().placeholder = state.system_prompt or self._default_subagent_prompt(state.name)
            return True
        if state.step == "system-prompt":
            state.system_prompt = answer or state.system_prompt or self._default_subagent_prompt(state.name)
            self._append_transcript(f"> {shorten(state.system_prompt, width=120, placeholder='...')}")
            state.step = "skills"
            self._clear_prompt()
            self._append_transcript("\n".join(["Subagent", "Choose optional attached skills."]))
            self._show_agent_skills_picker(state)
            return True
        if state.step == "ai-guidance":
            state.review_guidance = answer or "Refine this subagent for clarity and stronger task execution."
            self._request_subagent_review(state)
            return True
        if state.step == "review-guidance":
            state.review_guidance = answer or "Tighten the prompt and keep it concise."
            self._request_subagent_review(state)
            return True
        return False

    def _default_subagent_prompt(self, name: str) -> str:
        return (
            f"You are `{name}`. Work as a supervisor-managed specialist. Inspect enough context once, "
            "keep tool calls minimal, prefer grouped actions when safe, and return concise outcomes with important risks."
        )

    def _request_subagent_review(self, state: SubagentEditorState) -> None:
        self._active_agent_worker = self.run_worker(self._generate_subagent_review(state), exclusive=True, thread=False)

    async def _generate_subagent_review(self, state: SubagentEditorState) -> None:
        self._set_run_state(True, f"Reviewing {state.name or 'subagent'}")
        try:
            review_summary, refined_prompt = await asyncio.to_thread(self._build_subagent_review, state)
        except Exception as exc:
            self._set_run_state(False)
            self._append_transcript("\n".join(["Error", f"Unable to build subagent review: {exc}"]))
            return
        self._set_run_state(False)
        state.review_summary = review_summary
        state.refined_system_prompt = refined_prompt
        state.step = "review"
        self._append_transcript(
            "\n".join(
                [
                    "Subagent Review",
                    review_summary,
                    "",
                    f"Refined prompt:\n{refined_prompt}",
                ]
            )
        )
        rows = [
            ("confirm", "Confirm", "Save this reviewed subagent draft."),
            ("refine-again", "Refine Again", "Add more guidance and regenerate the review."),
            ("cancel", "Cancel", "Discard this draft."),
        ]
        self._show_picker(mode="agent-review", title="Subagent Review", columns=("Action", "Details"), rows=rows)
        self._clear_prompt()
        self._prompt_input().placeholder = "Choose confirm/refine-again/cancel, or type guidance after choosing refine-again"
        self._prompt_input().focus()

    def _build_subagent_review(self, state: SubagentEditorState) -> tuple[str, str]:
        prompt = "\n".join(
            [
                "You are refining a supervisor-managed coding subagent.",
                "Return JSON with keys `summary` and `refined_prompt` only.",
                f"Subagent name: {state.name}",
                f"Current system prompt: {state.system_prompt or self._default_subagent_prompt(state.name)}",
                f"Attached skills: {', '.join(state.skills) or '(none)'}",
                f"Extra guidance: {state.review_guidance or '(none)'}",
                "The summary should be concise and mention the role and attached skills.",
            ]
        )
        try:
            model = init_model(self.config, model_name=self.config.default_model)
            response = model.invoke(prompt)
            content = extract_text_response(response)
            parsed = json.loads(content)
            summary = str(parsed.get("summary", "")).strip()
            refined = str(parsed.get("refined_prompt", "")).strip()
            if summary and refined:
                return summary, refined
        except Exception:
            pass
        skills_line = ", ".join(state.skills) if state.skills else "none"
        summary = f"{state.name}: supervisor-managed specialist with skills {skills_line}."
        base_prompt = state.system_prompt or self._default_subagent_prompt(state.name)
        guidance = f" Additional guidance: {state.review_guidance.strip()}." if state.review_guidance.strip() else ""
        refined = f"{base_prompt}{guidance}".strip()
        return summary, refined

    def _save_subagent_from_editor(self, state: SubagentEditorState) -> str:
        registry = AgentRegistry(self.config.agents_dir)
        model_value = state.model or self._display_model_name(self.config.default_model)
        if ":" not in model_value:
            provider_prefix = self.config.default_model.split(":", 1)[0] if ":" in self.config.default_model else "openai"
            model_value = f"{provider_prefix}:{model_value}"
        description = state.review_summary.split(":", 1)[-1].strip() if ":" in state.review_summary else state.review_summary.strip()
        description = description or "User-created specialist."
        spec = AgentSpec(
            name=state.name,
            model=model_value,
            description=description,
            system_prompt=state.refined_system_prompt or state.system_prompt or self._default_subagent_prompt(state.name),
            skills=list(state.skills),
            workspace_dir=state.workspace_dir or None,
        )
        if state.original_name and state.original_name != state.name and state.original_name in registry.list_agents():
            registry.delete(state.original_name)
        registry.save(spec)
        self._subagent_editor = None
        self._built_agents.clear()
        self._refresh_agent_catalog()
        self._render_top_panel()
        return spec.name

    def _submit_subagent_manager(self, raw_value: str) -> bool:
        command = raw_value.strip().lower()
        registry = AgentRegistry(self.config.agents_dir)
        selected_name = self._selected_picker_key()
        if self._picker_mode == "agent-root":
            if selected_name == "__create__":
                self._start_subagent_editor(mode="new")
                return True
            if selected_name == "__active__":
                self._show_active_subagent_picker()
                return True
            if selected_name and selected_name in self._saved_subagent_specs:
                self._show_subagent_config(selected_name)
                return True
            return True
        if self._picker_mode == "agent-active":
            if command == "back":
                self._show_subagent_manager()
                return True
            active_names = [name for name in self._picker_marks if name in self._saved_subagent_specs]
            registry.save_active_names(active_names)
            self._append_transcript("\n".join(["Subagents", f"Saved {len(active_names)} active subagent(s) for `supervisor-agent`."]))
            self._built_agents.clear()
            self._refresh_agent_catalog()
            self._render_top_panel()
            self._show_subagent_manager()
            return True
        if self._picker_mode == "agent-config":
            target = self._agent_config_name
            if not target or target not in self._saved_subagent_specs:
                self._show_subagent_manager()
                return True
            if command in {"", "manual-edit"} and (command or selected_name == "manual-edit"):
                self._start_subagent_editor(mode="edit", spec=self._saved_subagent_specs[target])
                return True
            if command == "ai-chat" or (not command and selected_name == "ai-chat"):
                self._start_subagent_ai_refine(self._saved_subagent_specs[target])
                return True
            if command == "skills" or (not command and selected_name == "skills"):
                self._subagent_editor = SubagentEditorState(
                    mode="edit",
                    original_name=target,
                    name=target,
                    system_prompt=self._saved_subagent_specs[target].system_prompt,
                    model=self._display_model_name(self._saved_subagent_specs[target].model or self.config.default_model),
                    workspace_dir=self._saved_subagent_specs[target].workspace_dir or "",
                    skills=list(self._saved_subagent_specs[target].skills),
                    step="skills",
                )
                self._show_agent_skills_picker(self._subagent_editor)
                return True
            if command == "toggle-active" or (not command and selected_name == "toggle-active"):
                active_names = set(registry.load_active_names())
                if target in active_names:
                    active_names.remove(target)
                    verb = "Deactivated"
                else:
                    active_names.add(target)
                    verb = "Activated"
                registry.save_active_names(sorted(active_names))
                self._append_transcript("\n".join(["Subagent", f"{verb} `{target}` for `supervisor-agent`."]))
                self._built_agents.clear()
                self._refresh_agent_catalog()
                self._render_top_panel()
                self._show_subagent_config(target)
                return True
            if command == "delete" or (not command and selected_name == "delete"):
                registry.delete(target)
                self._append_transcript("\n".join(["Subagents", f"Deleted `{target}`."]))
                self._built_agents.clear()
                self._refresh_agent_catalog()
                self._render_top_panel()
                self._agent_config_name = None
                self._show_subagent_manager()
                return True
            self._show_subagent_manager()
            return True
        if self._picker_mode == "agent-skills":
            if self._subagent_editor is None:
                self._show_subagent_manager()
                return True
            if command == "back":
                self._subagent_editor.step = "system-prompt"
                self._append_transcript("\n".join(["Subagent", "Skipped skills selection."]))
                self._request_subagent_review(self._subagent_editor)
                return True
            selected_skills = self._ensure_attachable_skill_tokens(
                [name for name in self._picker_marks if name != "__empty__"]
            )
            self._subagent_editor.skills = sorted(selected_skills)
            self._append_transcript("\n".join(["Subagent", f"Selected skills: {', '.join(self._subagent_editor.skills) or '(none)'}."]))
            self._request_subagent_review(self._subagent_editor)
            return True
        if self._picker_mode == "thread-skills":
            if command == "back":
                self._hide_picker()
                self._clear_prompt()
                self._prompt_input().placeholder = PROMPT_PLACEHOLDER
                return True
            agent_name = self._current_agent_name() or "supervisor-agent"
            selected_skills = self._ensure_attachable_skill_tokens(
                [name for name in self._picker_marks if name != "__empty__"]
            )
            key = self._thread_skill_key(agent_name)
            if selected_skills:
                self._thread_skill_tokens[key] = selected_skills
            else:
                self._thread_skill_tokens.pop(key, None)
            self._built_agents.pop(agent_name, None)
            self._built_agent_signatures.pop(agent_name, None)
            thread_id = key[1]
            attached = ", ".join(selected_skills) if selected_skills else "(none)"
            self._append_transcript("\n".join(["Thread Skills", f"Attached to `{thread_id}`: {attached}."]))
            self._hide_picker()
            self._clear_prompt()
            self._prompt_input().placeholder = PROMPT_PLACEHOLDER
            return True
        if self._picker_mode == "agent-review":
            if command == "cancel" or (not command and selected_name == "cancel"):
                self._subagent_editor = None
                self._append_transcript("\n".join(["System", "Cancelled the subagent draft."]))
                self._show_subagent_manager()
                return True
            if command == "refine-again" or (not command and selected_name == "refine-again"):
                if self._subagent_editor is None:
                    return True
                self._subagent_editor.step = "review-guidance"
                self._hide_picker()
                self._clear_prompt()
                self._append_transcript("\n".join(["Subagent Review", "Add guidance for another refinement pass."]))
                self._prompt_input().placeholder = "Example: make the prompt stricter about batching and concise summaries"
                return True
            if self._subagent_editor is not None:
                saved_name = self._save_subagent_from_editor(self._subagent_editor)
                self._append_transcript("\n".join(["Subagent", f"Saved `{saved_name}`."]))
                self._show_subagent_config(saved_name)
                return True
            return True
        return False

    def _submit_history_picker(self) -> bool:
        thread_id = self._selected_picker_key()
        if not thread_id or thread_id == "__empty__":
            return True
        self._handle_thread_selection(
            ThreadSelection(
                agent_name=self._current_agent_name() or "supervisor-agent",
                thread_id=thread_id,
                created_new=False,
            )
        )
        self._hide_picker()
        self._clear_prompt()
        return True

    def _submit_mcp_manager(self, raw_value: str) -> bool:
        command = raw_value.strip().lower()
        if command == "bootstrap" or (not command and self._selected_picker_key() == "__bootstrap__"):
            path = bootstrap_default_mcp_servers(self.config.mcp_config_path, self.config.workspace_dir)
            self._append_transcript("\n".join(["MCP", f"Bootstrapped remote defaults into `{path}`."]))
            self._show_mcp_manager()
            return True
        servers = load_mcp_servers(self.config.mcp_config_path)
        kept = {name: server for name, server in servers.items() if name in self._picker_marks}
        path = save_mcp_servers(self.config.mcp_config_path, kept)
        self._append_transcript("\n".join(["MCP", f"Saved {len(kept)} configured server(s) into `{path}`."]))
        self._hide_picker()
        self._clear_prompt()
        self._render_top_panel()
        return True

    def _submit_skills_picker(self, raw_value: str) -> bool:
        if raw_value.startswith("/"):
            return False
        mode = self._picker_mode or ""
        command = raw_value.strip()
        command_lower = command.lower()
        selected = self._selected_picker_key()

        if mode == "skills-root":
            if command_lower == "back":
                self._hide_picker()
                self._clear_prompt()
                return True
            if command:
                self._start_skills_search(command)
                return True
            if selected == "browse":
                self._show_skills_categories()
                return True
            if selected == "search":
                self._clear_prompt()
                self._prompt_input().placeholder = "Enter a skills query such as react, docs, docker, or automation"
                return True
            if selected == "installed":
                self._start_list_installed_skills()
                return True
            if selected == "check":
                self._start_check_skills()
                return True
            if selected == "update":
                return self._handle_skills_update_request()
            if selected == "install-repo":
                self._show_skills_repo_install_input()
                return True
            if selected == "local":
                self._show_skills_local_install_input()
                return True
            return True

        if mode == "skills-categories":
            if command_lower == "back":
                self._show_skills_root()
                return True
            if selected and selected != "__empty__":
                self._start_skills_search(selected)
            return True

        if mode == "skills-results":
            if command_lower == "back":
                self._show_skills_root()
                return True
            if selected in {None, "__empty__"}:
                return True
            self._show_skill_detail_actions(mode="search", index=int(selected))
            return True

        if mode == "skills-installed":
            if command_lower == "back":
                self._show_skills_root()
                return True
            if selected in {None, "__empty__"}:
                return True
            self._show_skill_detail_actions(mode="installed", index=int(selected))
            return True

        if mode == "skills-detail":
            action = command_lower or (selected or "")
            if action == "back":
                if self._skills_state.detail_mode == "installed":
                    self._show_skills_installed(self._skills_state.installed)
                else:
                    self._show_skills_results(self._skills_state.query, self._skills_state.results)
                return True
            if action == "next" and self._skills_state.detail_mode == "search":
                target = min(self._skills_state.selected_index + 1, len(self._skills_state.results) - 1)
                self._show_skill_detail_actions(mode="search", index=target)
                return True
            if action == "prev" and self._skills_state.detail_mode == "search":
                target = max(self._skills_state.selected_index - 1, 0)
                self._show_skill_detail_actions(mode="search", index=target)
                return True
            if action == "show-command":
                command_text = render_command(self._skills_state.pending_command) if self._skills_state.pending_command else "No install command available."
                self._append_transcript("\n".join(["Skill Command", command_text]))
                return True
            if action == "check":
                self._start_check_skills()
                return True
            if action == "update":
                return self._handle_skills_update_request()
            if action == "install":
                return self._handle_skills_install_request()
            return True

        if mode == "skills-install-input":
            if not command or command_lower == "back":
                self._show_skills_root()
                return True
            try:
                source, skill_name = normalize_repo_skill_target(command)
            except ValueError as exc:
                self._append_transcript("\n".join(["Error", str(exc)]))
                return True
            self._skills_state.pending_source = source
            self._skills_state.pending_skill_name = skill_name
            self._skills_state.pending_command = tuple(self._skills_install_argv(source, skill_name))
            self._handle_skills_install_request()
            return True

        if mode == "skills-local-install":
            if not command or command_lower == "back":
                self._show_skills_root()
                return True
            self._start_local_skill_install(command)
            return True

        if mode == "skills-confirm-install":
            action = command_lower or (selected or "")
            if action == "continue":
                self._start_install_skill(self._skills_state.pending_source or "", self._skills_state.pending_skill_name)
                return True
            if action == "show-command":
                self._append_transcript("\n".join(["Skill Command", render_command(self._skills_state.pending_command)]))
                return True
            if action == "back":
                self._show_skills_root()
                return True
            return True

        if mode == "skills-confirm-update":
            action = command_lower or (selected or "")
            if action == "continue":
                self._start_update_skills()
                return True
            if action == "show-command":
                self._append_transcript("\n".join(["Skill Command", render_command(self._skills_state.pending_command)]))
                return True
            if action == "back":
                self._show_skills_root()
                return True
            return True

        return False

    def _skills_install_argv(self, source: str, skill_name: str | None = None) -> list[str]:
        argv = ["npx", "skills", "add", source]
        if skill_name:
            argv.extend(["--skill", skill_name])
        argv.extend(["-g", "-y"])
        return argv

    def _handle_skills_install_request(self) -> bool:
        source = self._skills_state.pending_source
        if not source:
            self._append_transcript("\n".join(["Error", "This result does not expose an install source yet."]))
            return True
        command = tuple(self._skills_install_argv(source, self._skills_state.pending_skill_name))
        self._skills_state.pending_command = command
        if self._approval_mode == "read-only":
            self._append_transcript("\n".join(["Warning", f"Read-only mode is enabled.\n{render_command(command)}"]))
            return True
        if self._approval_mode == "confirm":
            self._show_skills_confirm(action="install", command=command, note="Install the selected skill.")
            return True
        self._start_install_skill(source, self._skills_state.pending_skill_name)
        return True

    def _handle_skills_update_request(self) -> bool:
        command = ("npx", "skills", "update")
        self._skills_state.pending_command = command
        if self._approval_mode == "read-only":
            self._append_transcript("\n".join(["Warning", f"Read-only mode is enabled.\n{render_command(command)}"]))
            return True
        if self._approval_mode == "confirm":
            self._show_skills_confirm(action="update", command=command, note="Update all installed skills.")
            return True
        self._start_update_skills()
        return True

    def _refresh_agent_catalog(self) -> None:
        prebuilt = get_prebuilt_agents(self.config.default_model)
        registry = AgentRegistry(self.config.agents_dir)
        self._saved_subagent_specs = {saved_name: registry.load(saved_name) for saved_name in registry.list_agents()}
        self._active_saved_subagent_names = {
            name for name in registry.load_active_names() if name in self._saved_subagent_specs
        }
        self._agent_specs = dict(prebuilt)
        supervisor = self._agent_specs.get("supervisor-agent")
        if supervisor is not None:
            supervisor.subagents = [
                *list(supervisor.subagents),
                *[
                    self._as_managed_subagent(self._saved_subagent_specs[name])
                    for name in sorted(self._active_saved_subagent_names)
                ],
            ]
        self._agent_names = ["supervisor-agent"] if "supervisor-agent" in self._agent_specs else list(self._agent_specs.keys())
        self._selected_agent_name_value = "supervisor-agent" if "supervisor-agent" in self._agent_specs else (self._agent_names[0] if self._agent_names else None)

    def _start_skills_search(self, query: str) -> None:
        cleaned = query.strip()
        if not cleaned:
            self._append_transcript("\n".join(["Warning", "Enter a skills query first."]))
            return
        self._active_agent_worker = self.run_worker(self._search_skills(cleaned), exclusive=True, thread=False)

    async def _search_skills(self, query: str) -> None:
        self._set_run_state(True, f"Searching skills: {query}")
        try:
            result, parsed = await asyncio.to_thread(find_skills, query, workspace_dir=self.config.workspace_dir)
        except Exception as exc:
            self._set_run_state(False)
            self._append_transcript("\n".join(["Error", f"Skill search failed: {exc}"]))
            return
        self._set_run_state(False)
        if not result.ok:
            self._append_transcript(
                "\n".join(
                    [
                        "Error",
                        f"Skill search failed.\nCommand: {render_command(result.argv)}\n{result.error_summary or result.stderr or result.stdout}",
                    ]
                )
            )
            return
        self._append_transcript("\n".join(["Skills Search", f"`{query}`  •  {len(parsed)} result(s)\nCommand: {render_command(result.argv)}"]))
        self._show_skills_results(query, parsed, note="No results returned by the Skills CLI.")

    def _start_list_installed_skills(self) -> None:
        self._active_agent_worker = self.run_worker(self._load_installed_skills(), exclusive=True, thread=False)

    async def _load_installed_skills(self) -> None:
        self._set_run_state(True, "Loading installed skills")
        try:
            result, records = await asyncio.to_thread(list_installed_skills_cli, workspace_dir=self.config.workspace_dir)
        except Exception as exc:
            self._set_run_state(False)
            self._append_transcript("\n".join(["Error", f"Unable to list installed skills: {exc}"]))
            return
        self._set_run_state(False)
        if not result.ok:
            self._append_transcript(
                "\n".join(
                    [
                        "Error",
                        f"Unable to list installed skills.\nCommand: {render_command(result.argv)}\n{result.error_summary or result.stderr or result.stdout}",
                    ]
                )
            )
            return
        self._append_transcript("\n".join(["Installed Skills", f"{len(records)} item(s)\nCommand: {render_command(result.argv)}"]))
        self._show_skills_installed(records)

    def _start_check_skills(self) -> None:
        self._active_agent_worker = self.run_worker(self._check_skills_async(), exclusive=True, thread=False)

    async def _check_skills_async(self) -> None:
        self._set_run_state(True, "Checking skill updates")
        try:
            result, status = await asyncio.to_thread(check_skills, workspace_dir=self.config.workspace_dir)
        except Exception as exc:
            self._set_run_state(False)
            self._append_transcript("\n".join(["Error", f"Unable to check skills: {exc}"]))
            return
        self._set_run_state(False)
        if not result.ok:
            self._append_transcript(
                "\n".join(
                    [
                        "Error",
                        f"Skills check failed.\nCommand: {render_command(result.argv)}\n{result.error_summary or result.stderr or result.stdout}",
                    ]
                )
            )
            return
        body = status.summary
        if status.items:
            body = f"{body}\n" + "\n".join(status.items[:10])
        body = f"{body}\nCommand: {render_command(result.argv)}"
        self._skills_state.status_result = status
        self._append_transcript("\n".join(["Skills Check", body]))
        self._show_skills_root()

    def _start_update_skills(self) -> None:
        self._active_agent_worker = self.run_worker(self._update_skills_async(), exclusive=True, thread=False)

    async def _update_skills_async(self) -> None:
        self._set_run_state(True, "Updating installed skills")
        try:
            result, status = await asyncio.to_thread(update_skills, workspace_dir=self.config.workspace_dir)
        except Exception as exc:
            self._set_run_state(False)
            self._append_transcript("\n".join(["Error", f"Unable to update skills: {exc}"]))
            return
        self._set_run_state(False)
        if not result.ok:
            self._append_transcript(
                "\n".join(
                    [
                        "Error",
                        f"Skills update failed.\nCommand: {render_command(result.argv)}\n{result.error_summary or result.stderr or result.stdout}",
                    ]
                )
            )
            return
        body = status.summary
        if status.items:
            body = f"{body}\n" + "\n".join(status.items[:10])
        body = f"{body}\nCommand: {render_command(result.argv)}"
        self._skills_state.status_result = status
        self._append_transcript("\n".join(["Skills Update", body]))
        self._show_skills_root()

    def _start_install_skill(self, source: str, skill_name: str | None = None) -> None:
        self._active_agent_worker = self.run_worker(self._install_skill_async(source, skill_name), exclusive=True, thread=False)

    async def _install_skill_async(self, source: str, skill_name: str | None = None) -> None:
        command = self._skills_install_argv(source, skill_name)
        self._set_run_state(True, f"Installing skill from {source}")
        try:
            result = await asyncio.to_thread(
                install_skill_cli,
                source,
                workspace_dir=self.config.workspace_dir,
                skill_name=skill_name,
                global_install=True,
                yes=True,
            )
        except Exception as exc:
            self._set_run_state(False)
            self._append_transcript("\n".join(["Error", f"Skill install failed: {exc}"]))
            return
        self._set_run_state(False)
        if not result.ok:
            details = result.stderr or result.stdout or result.error_summary or "Install failed."
            self._append_transcript("\n".join(["Error", f"Skill install failed.\nCommand: {render_command(command)}\n{details}"]))
            return
        summary = f"Installed from `{source}`."
        if skill_name:
            summary = f"Installed `{skill_name}` from `{source}`."
        output = (result.stdout or "").strip()
        if output:
            summary = f"{summary}\n{shorten(output.replace(chr(10), ' '), width=180, placeholder='...')}"
        summary = f"{summary}\nCommand: {render_command(result.argv)}"
        self._append_transcript("\n".join(["Skill Install", summary]))
        self._show_skills_root()

    def _start_local_skill_install(self, source: str) -> None:
        self._active_agent_worker = self.run_worker(self._install_local_skill_async(source), exclusive=True, thread=False)

    async def _install_local_skill_async(self, source: str) -> None:
        self._set_run_state(True, "Installing local skill")
        try:
            installed = await asyncio.to_thread(install_local_skill, source, self.config.skills_dir, overwrite=False)
        except Exception as exc:
            self._set_run_state(False)
            self._append_transcript("\n".join(["Error", f"Local skill install failed: {exc}"]))
            return
        self._set_run_state(False)
        self._append_transcript("\n".join(["Skill Install", f"Installed local skill `{installed.name}` from `{source}`."]))
        self._show_skills_root()

    def _refresh_prompt_suggestions(self, value: str | None = None) -> None:
        prompt_value = value if value is not None else self._prompt_input().value
        if self._onboarding is not None:
            return
        mention_token = self._current_mention_token(prompt_value)
        if mention_token is not None:
            self._show_mention_picker(mention_token)
            return
        if not prompt_value.startswith("/"):
            if self._picker_mode in {"slash", "mention"}:
                self._hide_picker()
            return

        matches = self._ranked_slash_matches(prompt_value)
        rows: list[tuple[str, ...]] = []
        for command in matches:
            aliases = f" ({', '.join(command.aliases)})" if command.aliases else ""
            rows.append(
                (
                    command.name,
                    f"/{command.name}{aliases}",
                    command.description,
                    command.usage,
                )
            )
        self._show_picker(
            mode="slash",
            title="Commands",
            columns=("Command", "Description", "Usage"),
            rows=rows,
        )

    def _refresh_slash_suggestions(self, value: str | None = None) -> None:
        self._refresh_prompt_suggestions(value)

    def _current_mention_token(self, prompt_value: str) -> str | None:
        prompt_input = self._prompt_input()
        cursor = getattr(prompt_input, "cursor_position", len(prompt_value))
        prefix = prompt_value[:cursor]
        match = re.search(r"(^|\s)@([^\s@]*)$", prefix)
        if match is None:
            return None
        return match.group(2)

    def _show_mention_picker(self, partial: str) -> None:
        rows = self._mention_candidates(partial)
        if not rows:
            if self._picker_mode == "mention":
                self._hide_picker()
            return
        self._show_picker(
            mode="mention",
            title="Workspace Paths",
            columns=("Path", "Details"),
            rows=rows,
        )

    def _mention_candidates(self, partial: str) -> list[tuple[str, ...]]:
        workspace_root = Path(self.config.workspace_dir)
        normalized = partial.lstrip("/")
        parent_fragment, _, tail = normalized.rpartition("/")
        base_dir = workspace_root / parent_fragment if parent_fragment else workspace_root
        try:
            entries = sorted(base_dir.iterdir(), key=lambda item: (not item.is_dir(), item.name.lower()))
        except OSError:
            return []
        rows: list[tuple[str, ...]] = []
        for entry in entries:
            if tail and not entry.name.lower().startswith(tail.lower()):
                continue
            relative = entry.relative_to(workspace_root).as_posix()
            display = f"@{relative}{'/' if entry.is_dir() else ''}"
            description = "directory" if entry.is_dir() else f"file  •  {entry.suffix or 'no extension'}"
            rows.append((display, display, description))
            if len(rows) >= 12:
                break
        return rows

    def _submit_mention_completion(self) -> bool:
        key = self._selected_picker_key()
        if not key:
            return True
        prompt_input = self._prompt_input()
        value = prompt_input.value
        cursor = getattr(prompt_input, "cursor_position", len(value))
        prefix = value[:cursor]
        suffix = value[cursor:]
        updated_prefix = re.sub(r"(^|\s)@[^\s@]*$", lambda m: f"{m.group(1)}{key}", prefix)
        if not updated_prefix.endswith(" "):
            updated_prefix = f"{updated_prefix} "
        prompt_input.value = f"{updated_prefix}{suffix}"
        prompt_input.cursor_position = len(updated_prefix)
        self._hide_picker()
        return True

    def _ranked_slash_matches(self, prompt_value: str) -> list:
        matches = filter_slash_commands(prompt_value)
        if not matches:
            return []
        recent_slash_names: list[str] = []
        seen: set[str] = set()
        for entry in reversed(self._prompt_history):
            if not entry.startswith("/"):
                continue
            token = entry[1:].split(" ", 1)[0].strip().lower()
            command = resolve_slash_command(token)
            if command is None or command.name in seen:
                continue
            recent_slash_names.append(command.name)
            seen.add(command.name)
        rank = {name: index for index, name in enumerate(recent_slash_names)}
        return sorted(matches, key=lambda command: (rank.get(command.name, len(rank)), command.name))

    def _run_slash_command(self, raw_command: str) -> None:
        prompt_input = self._prompt_input()
        token, _, remainder = raw_command.strip()[1:].partition(" ")
        command = resolve_slash_command(token)
        argument = remainder.strip()
        if command is None:
            self._log(f"Unknown command: `{raw_command}`")
            self._refresh_slash_suggestions(raw_command)
            return

        self._remember_prompt_entry(raw_command)
        self._append_transcript("\n".join(["Command", raw_command.strip()]))
        prompt_input.value = ""
        prompt_input.cursor_position = 0
        if self._picker_mode == "slash":
            self._hide_picker()
        self._reset_prompt_history_cursor()

        if command.name == "help":
            self._write_help_message()
            return
        if command.name == "status":
            self._write_status_message()
            return
        if command.name == "cancel":
            if self._human_loop is not None:
                self._human_loop = None
                prompt_input.password = False
                self._clear_prompt()
                self._log("Dismissed the waiting-for-input prompt.")
            return
        if command.name == "agent":
            if argument == "new":
                self._start_subagent_editor(mode="new")
            else:
                self.action_open_agents()
            return
        if command.name == "resume":
            if argument:
                self._resume_thread(argument)
            else:
                self._resume_thread()
            return
        if command.name == "reset":
            self.action_reset_session()
            return
        if command.name == "fork":
            self._fork_current_thread()
            return
        if command.name == "compact":
            self._compact_session()
            return
        if command.name == "select-skill":
            self._show_thread_skills_picker()
            return
        if command.name == "mention":
            if not argument:
                self._log("Usage: `/mention <path>`")
                return
            self._mention_path(argument)
            return
        if command.name == "diff":
            self._show_git_diff()
            return
        if command.name == "init":
            self._init_agents_md()
            return
        if command.name == "personality":
            choice = (argument or "").strip().lower()
            if choice not in {"concise", "collaborative", "direct"}:
                self._log("Usage: `/personality concise|collaborative|direct`")
                return
            self._personality = choice
            self._save_shell_settings()
            self._append_transcript("\n".join(["Personality", f"Set shell personality to `{choice}`."]))
            return
        if command.name == "permissions":
            choice = (argument or "").strip().lower()
            if choice not in {"auto", "confirm", "read-only"}:
                self._log("Usage: `/permissions auto|confirm|read-only`")
                return
            self._approval_mode = choice
            self._save_shell_settings()
            self._append_transcript("\n".join(["Permissions", f"Set approval mode to `{choice}`."]))
            return
        if command.name == "plan":
            choice = (argument or "").strip().lower()
            if choice in {"", "toggle"}:
                self._plan_mode = not self._plan_mode
            elif choice in {"on", "off"}:
                self._plan_mode = choice == "on"
            else:
                self._log("Usage: `/plan on|off`")
                return
            self._save_shell_settings()
            status = "on" if self._plan_mode else "off"
            self._append_transcript("\n".join(["Plan Mode", f"Plan mode is now `{status}`."]))
            return
        if command.name == "build":
            self.action_build_selected()
            return
        if command.name == "new-thread":
            self.action_new_thread()
            return
        if command.name == "history":
            self.action_open_history_browser()
            return
        if command.name == "skills":
            self.action_open_skills()
            return
        if command.name == "mcp":
            self.action_open_mcp_browser()
            return
        if command.name == "bootstrap-mcp":
            path = bootstrap_default_mcp_servers(self.config.mcp_config_path, self.config.workspace_dir)
            self._built_agents.clear()
            self._render_top_panel()
            self._log(f"Bootstrapped default MCP servers into `{path}`.")
            return
        if command.name == "model":
            self.action_open_model_config()
            return
        if command.name == "theme":
            if argument:
                if not self._apply_named_theme(argument):
                    self._log(f"Unknown theme: `{argument}`")
                return
            self._show_theme_picker()
            return
        if command.name == "voice":
            self.action_toggle_voice_input()
            return
        if command.name == "refresh":
            self._built_agents.clear()
            self._refresh_agent_catalog()
            self._render_top_panel()
            self._log("Refreshed runtime state.")
            return
        if command.name == "clear":
            self.action_clear_shell()

    def _selected_agent_spec(self) -> AgentSpec | None:
        agent_name = self._selected_agent_name()
        if agent_name is None:
            self._log("No agents available.")
            return None
        return self._agent_specs.get(agent_name)

    def _as_managed_subagent(self, spec: AgentSpec) -> SubAgentSpec:
        description = spec.description.strip() or "User-created specialist."
        return SubAgentSpec(
            name=spec.name,
            description=description,
            system_prompt=spec.system_prompt,
            model=spec.model,
            skills=list(spec.skills),
            mcp_servers=list(spec.mcp_servers),
            workspace_dir=spec.workspace_dir,
        )

    def _selected_agent_name(self) -> str | None:
        return self._selected_agent_name_value

    def _current_agent_name(self) -> str | None:
        return self._selected_agent_name_value

    def _active_thread_id(self, agent_name: str | None) -> str | None:
        if agent_name is None:
            return None
        return self._active_threads.get(agent_name, get_thread_id(agent_name))

    def _handle_agent_selection(self, agent_name: str | None) -> None:
        if not agent_name:
            return
        if agent_name not in self._agent_names:
            self._log(f"Unknown agent: `{agent_name}`")
            return
        self._selected_agent_name_value = agent_name
        self._render_top_panel()
        self._log(f"Selected agent: `{agent_name}`")

    def _handle_agent_manager_result(self, result: AgentManagerResult | None) -> None:
        if result is None:
            self._prompt_input().focus()
            return
        if result.did_change:
            self._built_agents.clear()
            self._refresh_agent_catalog()
            self._render_top_panel()
        if result.selected_agent_name:
            self._handle_agent_selection(result.selected_agent_name)
        self._prompt_input().focus()

    def _handle_thread_selection(self, selection: ThreadSelection | None) -> None:
        if selection is None:
            self._prompt_input().focus()
            return
        if selection.agent_name not in self._agent_names:
            self._log(f"Persisted thread belongs to unavailable agent: `{selection.agent_name}`")
            return
        self._active_threads[selection.agent_name] = selection.thread_id
        self._selected_agent_name_value = selection.agent_name
        self._load_thread_transcript(selection.agent_name, selection.thread_id)
        self._render_top_panel()
        if selection.created_new:
            self._log(f"Started new thread for `{selection.agent_name}`: `{selection.thread_id}`")
        else:
            self._log(f"Switched `{selection.agent_name}` to thread `{selection.thread_id}`")
        self._prompt_input().focus()

    def _refresh_after_modal(self, _result: object | None) -> None:
        self._built_agents.clear()
        self._refresh_agent_catalog()
        self._render_top_panel()
        self._prompt_input().focus()

    def _load_thread_transcript(self, agent_name: str, thread_id: str) -> None:
        turns = load_chat_history(
            self.config.sessions_dir,
            limit=DEFAULT_HISTORY_REPLAY_LIMIT,
            agent_name=agent_name,
            thread_id=thread_id,
        )
        transcript_blocks: list[str] = []
        for turn in turns:
            block = self._transcript_block_for_turn(turn)
            if block:
                transcript_blocks.append(block)
        self._transcript_blocks = transcript_blocks
        self._streaming_assistant_index = None
        self._render_conversation()

    def _transcript_block_for_turn(self, turn) -> str:
        content = (turn.content or "").strip()
        if not content:
            return ""
        role = (turn.role or "").strip().lower()
        if role in {"user", "human"}:
            return f"> {content}"
        if role in {"assistant", "ai"}:
            return f"{VISIBLE_BRAND}\n{content}"
        if role == "system":
            return "\n".join(["System", content])
        return ""

    def _needs_provider_onboarding(self) -> bool:
        provider = self.config.openai_compatible
        return not provider.base_url.strip() or not provider.model.strip()

    def _start_provider_onboarding(self, *, source: str) -> None:
        provider = self.config.openai_compatible
        self._onboarding = ProviderOnboardingState(
            source=source,
            provider_name=provider.provider_name or "openai-compatible",
            base_url=provider.base_url.strip(),
            model=self._display_model_name(provider.model or self.config.default_model),
            model_kind=provider.model_kind or "chat",
            api_key_env=provider.api_key_env or "OPENAI_API_KEY",
        )
        self._resume_onboarding()

    def _resume_onboarding(self) -> None:
        state = self._onboarding
        if state is None:
            return
        self._clear_prompt()
        if state.step == "provider":
            self._write_onboarding_intro(state.source)
            self._show_provider_picker()
            self._prompt_input().placeholder = "Choose a provider with Up/Down, then press Enter"
            return
        self._hide_picker()
        self._write_onboarding_question()

    def _write_onboarding_intro(self, source: str) -> None:
        palette = self._palette()
        if source == "initial":
            text = Text()
            text.append(f"Welcome to {VISIBLE_BRAND}!\n\n", style=f"bold {palette.text}")
            self._append_welcome_art(text)
            text.append("\n\n")
            text.append("Let's set up your model provider before the first prompt.\n", style=palette.text)
            text.append("Use Up/Down to choose a provider, then press Enter.", style=palette.muted)
            self._welcome_panel().update(text)
            self._transcript_blocks.clear()
            self._streaming_assistant_index = None
            self._render_conversation()
            return
        self._append_transcript(
            "\n".join(
                [
                    "Setup",
                    "Provider setup",
                    "Choose a provider with Up/Down, then press Enter.",
                ]
            )
        )

    def _show_provider_picker(self) -> None:
        self._show_picker(
            mode="provider",
            title="Choose Provider",
            columns=("Provider", "Details"),
            rows=[
                ("openai-compatible", "OpenAI-Compatible", "Enter API key, base URL, and model."),
                ("deepseek-compatible", "DeepSeek-Compatible", "Use DeepSeek defaults, then adjust if needed."),
                ("later", "Later", "Skip setup for now and continue into the shell."),
            ],
        )

    def _submit_onboarding_value(self, raw_value: str) -> bool:
        state = self._onboarding
        if state is None:
            return False

        if state.step == "provider":
            choice = self._selected_picker_key()
            if choice is None:
                return True
            self._append_transcript(f"> {choice}")
            if choice == "later":
                self._onboarding = None
                self._hide_picker()
                self._prompt_input().placeholder = PROMPT_PLACEHOLDER
                self._render_top_panel()
                self._write_welcome_banner()
                self._log("Provider setup skipped for now. Run `/model` when you're ready.")
                return True

            defaults = self._provider_defaults(choice)
            state.provider_name = defaults["provider_name"]
            state.base_url = defaults["base_url"]
            state.model = defaults["model"]
            state.model_kind = defaults["model_kind"]
            state.api_key_env = defaults["api_key_env"]
            state.step = "api_key"
            self._hide_picker()
            self._clear_prompt()
            self._write_onboarding_question()
            return True

        if state.step == "api_key":
            masked = "[keep current key]" if not raw_value or raw_value.lower() == "skip" else "[api key saved]"
            self._append_transcript(f"> {masked}")
            state.api_key = raw_value if raw_value and raw_value.lower() != "skip" else None
            state.step = "base_url"
            self._clear_prompt()
            self._write_onboarding_question()
            return True

        if state.step == "base_url":
            chosen_base_url = raw_value or state.base_url
            state.base_url = chosen_base_url
            self._append_transcript(f"> {chosen_base_url}")
            state.step = "model"
            self._clear_prompt()
            self._write_onboarding_question()
            return True

        if state.step == "model":
            chosen_model = raw_value or state.model
            state.model = self._display_model_name(chosen_model)
            self._append_transcript(f"> {state.model}")
            self._complete_provider_onboarding(state)
            return True

        return False

    def _write_onboarding_question(self) -> None:
        state = self._onboarding
        if state is None:
            return
        if state.step == "api_key":
            self._append_transcript(
                "\n".join(
                    [
                        "Setup",
                        f"Enter the API key for `{state.provider_name}`.",
                        "Leave it blank to keep the current key, or type `skip` to continue without changing it.",
                    ]
                )
            )
            self._prompt_input().placeholder = "API key (hidden in chat log)"
            return
        if state.step == "base_url":
            self._append_transcript(
                "\n".join(
                    [
                        "Setup",
                        "Enter the base URL.",
                        f"Press Enter to keep: {state.base_url}",
                    ]
                )
            )
            self._prompt_input().placeholder = state.base_url
            return
        if state.step == "model":
            self._append_transcript(
                "\n".join(
                    [
                        "Setup",
                        "Enter the model name.",
                        f"Press Enter to keep: {state.model}",
                    ]
                )
            )
            self._prompt_input().placeholder = state.model

    def _provider_defaults(self, choice: str) -> dict[str, str]:
        provider = self.config.openai_compatible
        lowered_provider = provider.provider_name.lower()
        lowered_base_url = provider.base_url.lower()
        lowered_model = provider.model.lower()
        if choice == "deepseek-compatible":
            use_current = any("deepseek" in value for value in (lowered_provider, lowered_base_url, lowered_model))
            return {
                "provider_name": "deepseek-compatible",
                "base_url": provider.base_url if use_current and provider.base_url else "https://api.deepseek.com",
                "model": self._display_model_name(provider.model if use_current and provider.model else "deepseek-chat"),
                "model_kind": provider.model_kind or "chat",
                "api_key_env": "DEEPSEEK_API_KEY",
            }
        use_current = not any("deepseek" in value for value in (lowered_provider, lowered_base_url, lowered_model))
        return {
            "provider_name": "openai-compatible",
            "base_url": provider.base_url if use_current and provider.base_url else "https://api.openai.com/v1",
            "model": self._display_model_name(provider.model if use_current and provider.model else self.config.default_model),
            "model_kind": provider.model_kind or "chat",
            "api_key_env": "OPENAI_API_KEY",
        }

    def _complete_provider_onboarding(self, state: ProviderOnboardingState) -> None:
        updated = set_openai_compatible_provider(
            config_path=self.config_path,
            provider_name=state.provider_name,
            base_url=state.base_url,
            model=state.model,
            model_kind=state.model_kind,
            api_key=state.api_key,
            api_key_env=state.api_key_env,
            set_as_default=True,
        )
        self.config = load_config(self.config_path) if self.config_path is not None else updated
        self._onboarding = None
        self._built_agents.clear()
        self._refresh_agent_catalog()
        self._clear_prompt()
        self._render_top_panel()
        self._append_transcript(
            "\n".join(
                [
                    "Setup",
                    f"Saved `{state.provider_name}` with model `{state.model}`.",
                ]
            )
        )
        self._write_welcome_banner()
        self._log("Provider setup complete. Type `/help` to get started.")

    def _display_model_name(self, model_name: str) -> str:
        return model_name.split(":", 1)[1] if ":" in model_name else model_name

    def _write_welcome_banner(self) -> None:
        self._welcome_written = True
        self._render_top_panel()

    def _write_help_message(self) -> None:
        lines = ["Available slash commands:"]
        for command in get_slash_commands():
            alias_text = f" (aliases: {', '.join(command.aliases)})" if command.aliases else ""
            lines.append(f"/{command.name}{alias_text} - {command.description}")
            lines.append(f"  usage: {command.usage}")
        self._append_transcript("\n".join(lines))

    def _write_status_message(self) -> None:
        agent_name = self._current_agent_name() or "-"
        spec = self._agent_specs.get(agent_name) if agent_name != "-" else None
        thread_id = self._active_thread_id(agent_name) if agent_name != "-" else "-"
        build_state = "built" if agent_name in self._built_agents else "not built"
        provider = self.config.openai_compatible
        message = "\n".join(
            [
                "Current setup:",
                f"theme: {self._theme_name}",
                f"voice_input: {'listening' if self._voice_listening else 'idle'}",
                f"personality: {self._personality}",
                f"approval_mode: {self._approval_mode}",
                f"plan_mode: {'on' if self._plan_mode else 'off'}",
                f"agent: {agent_name}",
                f"active_subagents: {len(self._active_saved_subagent_names)}",
                f"thread: {thread_id}",
                f"build: {build_state}",
                f"model: {spec.model if spec is not None else self.config.default_model}",
                f"provider: {provider.provider_name}",
                f"base_url: {provider.base_url or '-'}",
                f"api_key: {describe_api_key_source(self.config)}",
                f"mcp_servers: {len(load_mcp_servers(self.config.mcp_config_path))}",
                f"mentions: {len(self._mentioned_contexts)}",
                f"agents_md: {self._project_agents_context.path if self._project_agents_context is not None else '-'}",
            ]
        )
        self._append_transcript(message)

    def _configured_subagents(self, spec: AgentSpec | None) -> list[dict[str, str]]:
        if spec is None:
            return []
        subagents: list[dict[str, str]] = []
        for subagent in spec.subagents:
            if isinstance(subagent, SubAgentSpec):
                subagents.append(
                    {
                        "name": subagent.name,
                        "role": subagent.description,
                        "tools": self._describe_subagent_tools(
                            mcp_servers=subagent.mcp_servers,
                            skills=subagent.skills,
                            has_custom_tools=False,
                        ),
                        "detail": "Ready for delegation.",
                    }
                )
                continue
            payload = dict(subagent)
            subagents.append(
                {
                    "name": str(payload.get("name", "subagent")),
                    "role": str(payload.get("description", "Delegated role")),
                    "tools": self._describe_subagent_tools(
                        mcp_servers=list(payload.get("mcp_servers", [])),
                        skills=list(payload.get("skills", [])),
                        has_custom_tools="tools" in payload,
                    ),
                    "detail": "Ready for delegation.",
                }
            )
        if subagents and all(row["name"] != "general-purpose" for row in subagents):
            subagents.insert(
                0,
                {
                    "name": "general-purpose",
                    "role": "Implicit DeepAgents fallback for isolated delegated tasks.",
                    "tools": "inherits main tools",
                    "detail": "Available automatically when delegating with the task tool.",
                },
            )
        return subagents

    def _describe_subagent_tools(
        self,
        *,
        mcp_servers: list[str],
        skills: list[str],
        has_custom_tools: bool,
    ) -> str:
        parts: list[str] = []
        if mcp_servers:
            parts.append(f"mcp: {', '.join(mcp_servers)}")
        if skills:
            parts.append(f"skills: {', '.join(skills)}")
        if has_custom_tools:
            parts.append("custom tools")
        return " | ".join(parts) or "inherits main tools"

    def _render_transcript_block(self, block: str) -> Text:
        palette = self._palette()
        if block.startswith("> "):
            text = Text()
            text.append("❯ ", style=f"bold {palette.accent}")
            text.append(block[2:], style=f"bold {palette.text}")
            return text

        header, _, body = block.partition("\n")
        body = body.strip()
        icon = "•"
        header_style = f"bold {palette.text}"
        body_style = palette.soft_text

        if header == "Thinking":
            icon = "◌"
            header_style = f"bold {palette.info}"
            body_style = palette.text
        elif header in {VISIBLE_BRAND, "AgenCLI"}:
            icon = "✦"
            header_style = f"bold {palette.accent}"
            body_style = palette.text
        elif header == "Tool call":
            icon = "⚙"
            header_style = f"bold {palette.info}"
            body_style = palette.muted
        elif header == "Tool result":
            icon = "✓"
            header_style = f"bold {palette.success}"
            body_style = palette.soft_text
        elif header == "Delegating":
            icon = "⇢"
            header_style = f"bold {palette.info}"
            body_style = palette.soft_text
        elif header == "Delegation complete":
            icon = "✓"
            header_style = f"bold {palette.success}"
            body_style = palette.soft_text
        elif header == "Command":
            icon = "/"
            header_style = f"bold {palette.info}"
            body_style = palette.text
        elif header == "Compact":
            icon = "≡"
            header_style = f"bold {palette.success}"
            body_style = palette.text
        elif header == "Diff":
            icon = "Δ"
            header_style = f"bold {palette.info}"
            body_style = palette.text
        elif header == "Mention":
            icon = "@"
            header_style = f"bold {palette.accent}"
            body_style = palette.soft_text
        elif header == "Init":
            icon = "◫"
            header_style = f"bold {palette.success}"
            body_style = palette.soft_text
        elif header in {"Skills Search", "Installed Skills", "Skill Details", "Installed Skill"}:
            icon = "⌕"
            header_style = f"bold {palette.info}"
            body_style = palette.text
        elif header in {"Skill Install", "Skills Check", "Skills Update", "Skill Command"}:
            icon = "✓" if header != "Skill Command" else ">"
            header_style = f"bold {palette.success}" if header != "Skill Command" else f"bold {palette.accent}"
            body_style = palette.text
        elif header == "Setup":
            icon = "◈"
            header_style = f"bold {palette.accent}"
            body_style = palette.soft_text
        elif header == "Need Input":
            icon = "?"
            header_style = f"bold {palette.warning}"
            body_style = palette.soft_text
        elif header == "Warning":
            icon = "⚠"
            header_style = f"bold {palette.warning}"
            body_style = palette.soft_text
        elif header == "Error":
            icon = "✕"
            header_style = f"bold {palette.danger}"
            body_style = palette.danger_soft
        elif header == "System":
            icon = "ℹ"
            header_style = f"bold {palette.muted}"
            body_style = palette.soft_text

        text = Text()
        text.append(icon, style=header_style)
        text.append(" ")
        text.append(header, style=header_style)
        if body:
            text.append("\n")
            if header == "Diff":
                text.append_text(self._render_diff_body(body))
            elif header == "Compact":
                text.append_text(self._render_compact_body(body))
            else:
                text.append(body, style=body_style)
        return text

    def _render_diff_body(self, body: str) -> Text:
        palette = self._palette()
        rendered = Text()
        for index, line in enumerate(body.splitlines()):
            if index:
                rendered.append("\n")
            if line.startswith("• Edited "):
                rendered.append("• ", style=f"bold {palette.info}")
                rendered.append(line[2:], style=f"bold {palette.text}")
            elif line.lstrip().startswith("+ "):
                prefix, _, rest = line.partition("+ ")
                rendered.append(prefix, style=palette.subtle)
                rendered.append("+ ", style=f"bold {palette.success}")
                rendered.append(rest, style=palette.soft_text)
            elif line.lstrip().startswith("- "):
                prefix, _, rest = line.partition("- ")
                rendered.append(prefix, style=palette.subtle)
                rendered.append("- ", style=f"bold {palette.danger}")
                rendered.append(rest, style=palette.soft_text)
            elif "⋮" in line:
                rendered.append(line, style=palette.info)
            else:
                rendered.append(line, style=palette.soft_text)
        return rendered

    def _render_compact_body(self, body: str) -> Text:
        palette = self._palette()
        rendered = Text()
        for index, line in enumerate(body.splitlines()):
            if index:
                rendered.append("\n")
            if line.endswith(":"):
                rendered.append(line, style=f"bold {palette.info}")
            elif line.startswith("- "):
                rendered.append("- ", style=f"bold {palette.success}")
                rendered.append(line[2:], style=palette.text)
            else:
                rendered.append(line, style=palette.text)
        return rendered

    def _format_tool_call(self, label: str, detail: str) -> str:
        payload = self._parse_json_detail(detail)
        if isinstance(payload, dict):
            if label in {"write_file", "read_file"}:
                file_path = payload.get("file_path") or payload.get("path")
                if file_path:
                    return f"{label}  {self._short_path(str(file_path))}"
            if label == "ls":
                path = payload.get("path")
                if path:
                    return f"{label}  {self._short_path(str(path))}"
            if label == "write_todos":
                todos = payload.get("todos")
                if isinstance(todos, list):
                    return f"checklist  {len(todos)} item(s)"
            if label in {"grep", "search"}:
                query = payload.get("pattern") or payload.get("query")
                if query:
                    return f"{label}  {self._compact_detail(str(query), width=96)}"
        return f"{label}  {self._compact_detail(detail, width=96) or 'invoked'}"

    def _format_tool_result(self, label: str, detail: str) -> str:
        normalized = " ".join((detail or "").split())
        if not normalized:
            return f"{label} completed"
        if label == "write_todos":
            return "Checklist updated"
        if label == "write_file":
            trimmed = normalized.replace("Updated file ", "").replace("Created file ", "")
            return f"Saved {self._short_path(trimmed)}"
        if label == "ls":
            return f"Listed directory contents  {self._compact_detail(normalized, width=88)}"
        if label == "read_file":
            return f"Read file preview  {self._compact_detail(normalized, width=88)}"
        return self._compact_detail(normalized, width=110)

    def _parse_json_detail(self, detail: str) -> object | None:
        candidate = (detail or "").strip()
        if not candidate.startswith("{"):
            return None
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            return None

    def _short_path(self, value: str) -> str:
        normalized = value.replace("\\", "/")
        workspace_root = Path(self.config.workspace_dir).resolve()
        try:
            normalized = str(Path(normalized).resolve().relative_to(workspace_root)).replace("\\", "/")
        except Exception:
            pass
        return shorten(normalized, width=72, placeholder="...")

    def _compact_detail(self, value: str, *, width: int = 88) -> str:
        return shorten(" ".join((value or "").split()), width=width, placeholder="...")

    def _log(self, message: str) -> None:
        if message.startswith("Skipping MCP server"):
            self._append_transcript("\n".join(["Warning", message]))
            return
        if message.startswith("Error:"):
            self._append_transcript("\n".join(["Error", message.removeprefix("Error:").strip()]))
            return
        self._append_transcript("\n".join(["System", message]))
