﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, DataTable, Input, SelectionList, Static, TextArea

from agencli.agents.editor import (
    build_agent_spec_from_editor,
    copy_agent_spec_for_customization,
    format_token_list,
    partition_skill_tokens,
)
from agencli.agents.factory import AgentSpec
from agencli.agents.prebuilt.catalog import get_prebuilt_agents
from agencli.agents.registry import AgentRegistry
from agencli.core.config import AgenCLIConfig, load_config, set_openai_compatible_provider
from agencli.core.session import create_thread_id, list_chat_threads, load_chat_history
from agencli.mcp.config import bootstrap_default_mcp_servers, load_mcp_servers
from agencli.skills.manager import install_skill, list_installed_skills


@dataclass(slots=True)
class AgentManagerResult:
    selected_agent_name: str | None = None
    did_change: bool = False


class AgentEditorScreen(ModalScreen[AgentSpec | None]):
    CSS = """
    AgentEditorScreen {
        align: center middle;
    }

    #agent-editor-modal {
        width: 94%;
        height: 92%;
        border: round $accent;
        background: $surface;
        padding: 1 2;
    }

    #agent-editor-body {
        height: 1fr;
    }

    #agent-editor-form {
        width: 3fr;
        height: 1fr;
    }

    #agent-editor-side {
        width: 2fr;
        height: 1fr;
        border: round $panel;
        padding: 1;
    }

    #agent-system-prompt {
        height: 12;
        margin-top: 1;
    }

    #agent-editor-skills {
        height: 1fr;
        margin-top: 1;
    }

    .agent-editor-field {
        margin-top: 1;
    }
    """

    BINDINGS = [Binding("escape", "close", "Cancel")]

    def __init__(
        self,
        config: AgenCLIConfig,
        spec: AgentSpec,
        *,
        source_label: str,
    ) -> None:
        super().__init__()
        self.config = config
        self.spec = spec
        self.source_label = source_label
        self.installed_skills = list_installed_skills(config.skills_dir)
        self._installed_skill_names = {skill.name for skill in self.installed_skills}
        self._managed_skill_tokens, self._extra_skill_tokens = partition_skill_tokens(
            spec.skills,
            self._installed_skill_names,
        )

    def compose(self):
        with Vertical(id="agent-editor-modal"):
            yield Static(f"Agent Editor: {self.spec.name}")
            yield Static(self._editor_note())
            with Horizontal(id="agent-editor-body"):
                with Vertical(id="agent-editor-form"):
                    yield Static("Name", classes="agent-editor-field")
                    yield Input(value=self.spec.name, id="agent-name")
                    yield Static("Model", classes="agent-editor-field")
                    yield Input(value=self.spec.model or self.config.default_model, id="agent-model")
                    yield Static("Description", classes="agent-editor-field")
                    yield Input(value=self.spec.description, id="agent-description")
                    yield Static("Workspace Override", classes="agent-editor-field")
                    yield Input(value=self.spec.workspace_dir or "", id="agent-workspace")
                    yield Static("MCP Servers (comma separated)", classes="agent-editor-field")
                    yield Input(value=format_token_list(self.spec.mcp_servers), id="agent-mcp")
                    yield Static("System Prompt", classes="agent-editor-field")
                    yield TextArea(
                        self.spec.system_prompt,
                        id="agent-system-prompt",
                        language="markdown",
                        show_line_numbers=False,
                    )
                with Vertical(id="agent-editor-side"):
                    yield Static("Assigned Installed Skills")
                    yield SelectionList(
                        ("All installed skills (`installed`)", "installed", "installed" in self._managed_skill_tokens),
                        *[
                            (
                                f"{skill.name} - {skill.description}",
                                skill.name,
                                skill.name in self._managed_skill_tokens,
                            )
                            for skill in self.installed_skills
                        ],
                        id="agent-editor-skills",
                    )
                    yield Static("Extra Skill Tokens / Paths", classes="agent-editor-field")
                    yield Input(value=format_token_list(self._extra_skill_tokens), id="agent-extra-skills")
                    yield Static(self._sidebar_note(), id="agent-editor-details", classes="agent-editor-field")
            yield Static("", id="agent-editor-status", classes="agent-editor-field")
            with Horizontal(classes="agent-editor-field"):
                yield Button("Save Agent", id="agent-editor-save")
                yield Button("Cancel", id="agent-editor-close")

    def action_close(self) -> None:
        self.dismiss(None)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "agent-editor-close":
            self.dismiss(None)
            return
        if event.button.id != "agent-editor-save":
            return
        try:
            spec = build_agent_spec_from_editor(
                base_spec=self.spec,
                name=self.query_one("#agent-name", Input).value,
                model=self.query_one("#agent-model", Input).value,
                description=self.query_one("#agent-description", Input).value,
                system_prompt=self.query_one("#agent-system-prompt", TextArea).text,
                workspace_dir=self.query_one("#agent-workspace", Input).value,
                mcp_servers_raw=self.query_one("#agent-mcp", Input).value,
                selected_skill_tokens=self.query_one("#agent-editor-skills", SelectionList).selected,
                extra_skill_tokens_raw=self.query_one("#agent-extra-skills", Input).value,
            )
        except ValueError as exc:
            self.query_one("#agent-editor-status", Static).update(str(exc))
            return
        self.dismiss(spec)

    def _editor_note(self) -> str:
        if self.source_label == "prebuilt":
            return "Editing a prebuilt agent creates or updates a saved custom copy in the agent registry."
        if self.source_label == "new":
            return "Create a custom agent by adjusting the fields below, then save it into the local agent registry."
        return "Edit the saved agent fields below. Subagents are preserved even though they are not directly editable here yet."

    def _sidebar_note(self) -> str:
        parts = [
            f"Source: {self.source_label}",
            f"Configured MCP servers: {', '.join(self.spec.mcp_servers) or '-'}",
            f"Subagents preserved: {len(self.spec.subagents)}",
            f"Installed skill library: {len(self.installed_skills)} available",
            "",
            "Tip: use installed skills here for per-agent assignment. Any non-installed tokens or skill paths can stay in the extra field.",
        ]
        return "\n".join(parts)


class AgentManagerScreen(ModalScreen[AgentManagerResult | None]):
    CSS = """
    AgentManagerScreen {
        align: center middle;
    }

    #agent-manager-modal {
        width: 92%;
        height: 88%;
        border: round $accent;
        background: $surface;
        padding: 1 2;
    }

    #agent-manager-body {
        height: 1fr;
    }

    #agent-manager-table {
        width: 2fr;
        height: 1fr;
    }

    #agent-manager-details {
        width: 1fr;
        height: 1fr;
        border: round $panel;
        padding: 1;
    }
    """

    BINDINGS = [Binding("escape", "close", "Close")]

    def __init__(self, config: AgenCLIConfig) -> None:
        super().__init__()
        self.config = config
        self.registry = AgentRegistry(config.agents_dir)
        self._rows: list[tuple[str, str, AgentSpec]] = []
        self._did_change = False

    def compose(self):
        with Vertical(id="agent-manager-modal"):
            yield Static("Agent Manager")
            with Horizontal(id="agent-manager-body"):
                yield DataTable(id="agent-manager-table")
                yield Static("", id="agent-manager-details")
            with Horizontal():
                yield Button("Use Selected", id="agent-use")
                yield Button("New Custom", id="agent-new")
                yield Button("Edit Selected", id="agent-edit")
                yield Button("Save Prebuilt", id="agent-save")
                yield Button("Delete Saved", id="agent-delete")
                yield Button("Close", id="agent-close")

    def on_mount(self) -> None:
        table = self.query_one("#agent-manager-table", DataTable)
        table.cursor_type = "row"
        self._populate()

    def action_close(self) -> None:
        self.dismiss(
            AgentManagerResult(
                selected_agent_name=self._selected_row_name() if self._did_change else None,
                did_change=self._did_change,
            )
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "agent-close":
            self.action_close()
            return
        row = self._selected_row()
        if event.button.id == "agent-new":
            seed_spec = copy_agent_spec_for_customization(
                row[2] if row is not None else None,
                existing_names=self._existing_agent_names(),
                default_model=self.config.default_model,
            )
            self.app.push_screen(
                AgentEditorScreen(self.config, seed_spec, source_label="new"),
                self._handle_editor_result,
            )
            return
        if row is None:
            return
        name, source, spec = row
        if event.button.id == "agent-use":
            self.dismiss(AgentManagerResult(selected_agent_name=name, did_change=self._did_change))
        elif event.button.id == "agent-edit":
            editor_spec = (
                copy_agent_spec_for_customization(
                    spec,
                    existing_names=self._existing_agent_names(),
                    default_model=self.config.default_model,
                )
                if source == "prebuilt"
                else AgentSpec.from_dict(spec.serializable_dict())
            )
            self.app.push_screen(
                AgentEditorScreen(self.config, editor_spec, source_label=source),
                self._handle_editor_result,
            )
        elif event.button.id == "agent-save":
            if source == "prebuilt":
                path = self.registry.save(spec)
                self._did_change = True
                self._populate(select_name=spec.name, note=f"Saved prebuilt agent to {path}.")
            else:
                self.query_one("#agent-manager-details", Static).update(
                    self._format_details(spec, "Saved agents are already persisted.")
                )
        elif event.button.id == "agent-delete":
            if source != "saved":
                self.query_one("#agent-manager-details", Static).update(
                    self._format_details(spec, "Only saved custom agents can be deleted.")
                )
                return
            path = self.registry.delete(name)
            self._did_change = True
            self._populate(note=f"Deleted saved agent {path.name}.")

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.data_table.id == "agent-manager-table":
            self._update_details(event.cursor_row)

    def _populate(self, select_name: str | None = None, note: str = "") -> None:
        table = self.query_one("#agent-manager-table", DataTable)
        table.clear(columns=True)
        table.add_columns("Agent", "Source", "MCP", "Description")

        prebuilt = get_prebuilt_agents(self.config.default_model)
        self._rows = [(name, "prebuilt", spec) for name, spec in prebuilt.items()]
        self._rows.extend((name, "saved", self.registry.load(name)) for name in self.registry.list_agents())

        for _, source, spec in self._rows:
            table.add_row(spec.name, source, ", ".join(spec.mcp_servers) or "-", spec.description or "-")
        if not self._rows:
            self.query_one("#agent-manager-details", Static).update(note or "No agents available.")
            return

        target_row = self._find_row_index(select_name, preferred_source="saved" if select_name else None)
        table.move_cursor(row=target_row, column=0)
        self._update_details(target_row, note=note)

    def _update_details(self, row_index: int, note: str = "") -> None:
        if row_index < 0 or row_index >= len(self._rows):
            return
        _, source, spec = self._rows[row_index]
        self.query_one("#agent-manager-details", Static).update(self._format_details(spec, source=source, note=note))

    def _format_details(self, spec: AgentSpec, *, source: str = "-", note: str = "") -> str:
        parts = [
            f"Name: {spec.name}",
            f"Source: {source}",
            f"Model: {spec.model}",
            f"Workspace: {spec.workspace_dir or self.config.workspace_dir}",
            f"MCP: {', '.join(spec.mcp_servers) or '-'}",
            f"Skills: {', '.join(spec.skills) or '-'}",
            f"Subagents: {len(spec.subagents)}",
            "",
            "System Prompt:",
            spec.system_prompt,
        ]
        if note:
            parts.extend(["", note])
        return "\n".join(parts)

    def _selected_row(self) -> tuple[str, str, AgentSpec] | None:
        if not self._rows:
            return None
        row_index = self.query_one("#agent-manager-table", DataTable).cursor_row
        if row_index < 0 or row_index >= len(self._rows):
            return None
        return self._rows[row_index]

    def _selected_row_name(self) -> str | None:
        row = self._selected_row()
        return row[0] if row is not None else None

    def _existing_agent_names(self) -> set[str]:
        return {name for name, _, _ in self._rows}

    def _find_row_index(self, name: str | None, *, preferred_source: str | None = None) -> int:
        if not name:
            return 0
        for index, (row_name, source, _) in enumerate(self._rows):
            if row_name == name and (preferred_source is None or source == preferred_source):
                return index
        for index, (row_name, _, _) in enumerate(self._rows):
            if row_name == name:
                return index
        return 0

    def _handle_editor_result(self, spec: AgentSpec | None) -> None:
        if spec is None:
            return
        path = self.registry.save(spec)
        self._did_change = True
        self._populate(select_name=spec.name, note=f"Saved custom agent to {path}.")


class MCPBrowserScreen(ModalScreen[None]):
    CSS = """
    MCPBrowserScreen {
        align: center middle;
    }

    #mcp-browser-modal {
        width: 92%;
        height: 88%;
        border: round $accent;
        background: $surface;
        padding: 1 2;
    }

    #mcp-browser-body {
        height: 1fr;
    }

    #mcp-browser-table {
        width: 2fr;
        height: 1fr;
    }

    #mcp-browser-details {
        width: 1fr;
        height: 1fr;
        border: round $panel;
        padding: 1;
    }
    """

    BINDINGS = [Binding("escape", "close", "Close")]

    def __init__(self, config: AgenCLIConfig) -> None:
        super().__init__()
        self.config = config
        self._rows: list[tuple[str, str, str]] = []

    def compose(self):
        with Vertical(id="mcp-browser-modal"):
            yield Static("MCP Browser")
            with Horizontal(id="mcp-browser-body"):
                yield DataTable(id="mcp-browser-table")
                yield Static("", id="mcp-browser-details")
            with Horizontal():
                yield Button("Bootstrap Remote Defaults", id="mcp-bootstrap")
                yield Button("Refresh", id="mcp-refresh")
                yield Button("Close", id="mcp-close")

    def on_mount(self) -> None:
        table = self.query_one("#mcp-browser-table", DataTable)
        table.cursor_type = "row"
        self._populate()

    def action_close(self) -> None:
        self.dismiss(None)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "mcp-close":
            self.dismiss(None)
            return
        if event.button.id == "mcp-bootstrap":
            path = bootstrap_default_mcp_servers(self.config.mcp_config_path, self.config.workspace_dir)
            self._populate(note=f"Bootstrapped remote defaults into {path}.")
        elif event.button.id == "mcp-refresh":
            self._populate(note="Refreshed MCP server list.")

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.data_table.id == "mcp-browser-table":
            self._update_details(event.cursor_row)

    def _populate(self, note: str = "") -> None:
        table = self.query_one("#mcp-browser-table", DataTable)
        table.clear(columns=True)
        table.add_columns("Server", "Transport", "Target")
        self._rows = []
        servers = load_mcp_servers(self.config.mcp_config_path)
        for name, server in sorted(servers.items()):
            target = server.url or " ".join([server.command or "", *server.args]).strip() or "-"
            table.add_row(name, server.transport, target)
            self._rows.append((name, server.transport, target))
        if self._rows:
            table.move_cursor(row=0, column=0)
            self._update_details(0, note=note)
        else:
            self.query_one("#mcp-browser-details", Static).update(note or "No MCP servers configured.")

    def _update_details(self, row_index: int, note: str = "") -> None:
        if row_index < 0 or row_index >= len(self._rows):
            return
        name, transport, target = self._rows[row_index]
        parts = [
            f"Name: {name}",
            f"Transport: {transport}",
            f"Target: {target}",
        ]
        if note:
            parts.extend(["", note])
        self.query_one("#mcp-browser-details", Static).update("\n".join(parts))


class ProviderOnboardingScreen(ModalScreen[str | None]):
    CSS = """
    ProviderOnboardingScreen {
        align: center middle;
    }

    #provider-onboarding-modal {
        width: 78;
        max-width: 92%;
        height: auto;
        border: round $accent;
        background: $surface;
        padding: 1 2;
    }

    .provider-onboarding-field {
        margin-top: 1;
    }
    """

    def compose(self):
        with Vertical(id="provider-onboarding-modal"):
            yield Static("Choose A Provider")
            yield Static(
                "Set up your provider the first time you launch AgenCLI. "
                "OpenAI-compatible lets you enter API key, base URL, and model directly.",
                classes="provider-onboarding-field",
            )
            with Horizontal(classes="provider-onboarding-field"):
                yield Button("OpenAI-Compatible", id="provider-openai")
                yield Button("DeepSeek-Compatible", id="provider-deepseek")
                yield Button("Later", id="provider-later")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "provider-openai":
            self.dismiss("openai-compatible")
        elif event.button.id == "provider-deepseek":
            self.dismiss("deepseek-compatible")
        elif event.button.id == "provider-later":
            self.dismiss(None)


class ModelConfigScreen(ModalScreen[AgenCLIConfig | None]):
    CSS = """
    ModelConfigScreen {
        align: center middle;
    }

    #model-config-modal {
        width: 72;
        max-width: 92%;
        height: auto;
        border: round $accent;
        background: $surface;
        padding: 1 2;
    }

    .model-field {
        margin-top: 1;
    }
    """

    BINDINGS = [Binding("escape", "close", "Close")]

    def __init__(
        self,
        config: AgenCLIConfig,
        config_path: Path | None = None,
        *,
        title: str = "Model / Provider Settings",
        intro: str = "Update provider settings. API keys can be stored in keyring.",
        prefill: dict[str, str] | None = None,
        show_close: bool = True,
    ) -> None:
        super().__init__()
        self.config = config
        self.config_path = config_path
        self.title = title
        self.intro = intro
        self.prefill = prefill or {}
        self.show_close = show_close
        provider = config.openai_compatible
        self._provider_name = self.prefill.get("provider_name", provider.provider_name)
        self._base_url = self.prefill.get("base_url", provider.base_url)
        self._model = self.prefill.get("model", provider.model or self.config.default_model)
        self._model_kind = self.prefill.get("model_kind", provider.model_kind)
        self._api_key_env = self.prefill.get("api_key_env", provider.api_key_env)

    def compose(self):
        with Vertical(id="model-config-modal"):
            yield Static(self.title)
            yield Static(self.intro, classes="model-field")
            yield Static("Provider Name", classes="model-field")
            yield Input(value=self._provider_name, id="provider-name")
            yield Static("Base URL", classes="model-field")
            yield Input(value=self._base_url, id="base-url")
            yield Static("Model", classes="model-field")
            yield Input(value=self._model, id="model-name")
            yield Static("Model Kind", classes="model-field")
            yield Input(value=self._model_kind, id="model-kind")
            yield Static("API Key Env", classes="model-field")
            yield Input(value=self._api_key_env, id="api-key-env")
            yield Static("API Key (stored in keyring when provided)", classes="model-field")
            yield Input(password=True, id="api-key")
            yield Static("", id="model-config-status", classes="model-field")
            with Horizontal(classes="model-field"):
                yield Button("Save", id="model-save")
                if self.show_close:
                    yield Button("Close", id="model-close")

    def action_close(self) -> None:
        self.dismiss(None)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "model-close":
            self.dismiss(None)
            return
        if event.button.id != "model-save":
            return

        updated = set_openai_compatible_provider(
            config_path=self.config_path,
            provider_name=self.query_one("#provider-name", Input).value.strip() or None,
            base_url=self.query_one("#base-url", Input).value.strip() or None,
            model=self.query_one("#model-name", Input).value.strip() or None,
            model_kind=self.query_one("#model-kind", Input).value.strip() or None,
            api_key=self.query_one("#api-key", Input).value.strip() or None,
            api_key_env=self.query_one("#api-key-env", Input).value.strip() or None,
            set_as_default=True,
        )
        self.query_one("#model-config-status", Static).update("Saved provider settings.")
        self.dismiss(load_config(self.config_path) if self.config_path is not None else updated)


class SkillBrowserScreen(ModalScreen[None]):
    CSS = """
    SkillBrowserScreen {
        align: center middle;
    }

    #skill-browser-modal {
        width: 92%;
        height: 88%;
        border: round $accent;
        background: $surface;
        padding: 1 2;
    }

    #skill-browser-body {
        height: 1fr;
    }

    #skill-browser-table {
        width: 2fr;
        height: 1fr;
    }

    #skill-browser-details {
        width: 1fr;
        height: 1fr;
        border: round $panel;
        padding: 1;
    }

    #skill-source-input {
        margin-top: 1;
    }
    """

    BINDINGS = [Binding("escape", "close", "Close")]

    def __init__(self, config: AgenCLIConfig) -> None:
        super().__init__()
        self.config = config
        self._skills = []

    def compose(self):
        with Vertical(id="skill-browser-modal"):
            yield Static("Skills")
            with Horizontal(id="skill-browser-body"):
                yield DataTable(id="skill-browser-table")
                yield Static("", id="skill-browser-details")
            yield Static("Install from local directory or SKILL.md path")
            yield Input(placeholder="D:\\path\\to\\skill or D:\\path\\to\\SKILL.md", id="skill-source-input")
            with Horizontal():
                yield Button("Install Local", id="skill-install")
                yield Button("Refresh", id="skill-refresh")
                yield Button("Close", id="skill-close")

    def on_mount(self) -> None:
        table = self.query_one("#skill-browser-table", DataTable)
        table.cursor_type = "row"
        self._populate()

    def action_close(self) -> None:
        self.dismiss(None)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "skill-close":
            self.dismiss(None)
            return
        if event.button.id == "skill-refresh":
            self._populate(note="Refreshed installed skills.")
            return
        if event.button.id != "skill-install":
            return

        source = self.query_one("#skill-source-input", Input).value.strip()
        if not source:
            self.query_one("#skill-browser-details", Static).update("Enter a local skill path first.")
            return
        try:
            installed = install_skill(source, self.config.skills_dir, overwrite=False)
        except Exception as exc:
            self.query_one("#skill-browser-details", Static).update(f"Install failed: {exc}")
            return

        self.query_one("#skill-source-input", Input).value = ""
        self._populate(note=f"Installed `{installed.name}`.")

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.data_table.id == "skill-browser-table":
            self._update_details(event.cursor_row)

    def _populate(self, note: str = "") -> None:
        table = self.query_one("#skill-browser-table", DataTable)
        table.clear(columns=True)
        table.add_columns("Skill", "Tools", "Description")
        self._skills = list_installed_skills(self.config.skills_dir)
        for skill in self._skills:
            table.add_row(skill.name, ", ".join(skill.allowed_tools) or "-", skill.description)
        if self._skills:
            table.move_cursor(row=0, column=0)
            self._update_details(0, note=note)
        else:
            self.query_one("#skill-browser-details", Static).update(note or "No local skills installed.")

    def _update_details(self, row_index: int, note: str = "") -> None:
        if row_index < 0 or row_index >= len(self._skills):
            return
        skill = self._skills[row_index]
        parts = [
            f"Name: {skill.name}",
            f"Path: {skill.path}",
            f"Token: {skill.name}",
            "All Installed Token: installed",
            f"Allowed Tools: {', '.join(skill.allowed_tools) or '-'}",
            f"License: {skill.license or '-'}",
            f"Compatibility: {skill.compatibility or '-'}",
            "",
            skill.description,
        ]
        if note:
            parts.extend(["", note])
        self.query_one("#skill-browser-details", Static).update("\n".join(parts))


@dataclass(slots=True)
class ThreadSelection:
    agent_name: str
    thread_id: str
    created_new: bool = False


class SessionBrowserScreen(ModalScreen[ThreadSelection | None]):
    CSS = """
    SessionBrowserScreen {
        align: center middle;
    }

    #session-browser-modal {
        width: 92%;
        height: 88%;
        border: round $accent;
        background: $surface;
        padding: 1 2;
    }

    #session-browser-body {
        height: 1fr;
    }

    #session-browser-table {
        width: 2fr;
        height: 1fr;
    }

    #session-browser-details {
        width: 1fr;
        height: 1fr;
        border: round $panel;
        padding: 1;
    }

    #session-filter-input {
        margin-top: 1;
    }
    """

    BINDINGS = [Binding("escape", "close", "Close")]

    def __init__(
        self,
        config: AgenCLIConfig,
        *,
        preferred_agent_name: str | None = None,
        active_thread_id: str | None = None,
    ) -> None:
        super().__init__()
        self.config = config
        self.preferred_agent_name = preferred_agent_name
        self.active_thread_id = active_thread_id
        self._threads = []

    def compose(self):
        with Vertical(id="session-browser-modal"):
            yield Static("Session Browser")
            yield Static("Search agent name, thread ID, or latest content")
            yield Input(placeholder="Filter persisted threads", id="session-filter-input")
            with Horizontal(id="session-browser-body"):
                yield DataTable(id="session-browser-table")
                yield Static("", id="session-browser-details")
            with Horizontal():
                yield Button("Use Selected Thread", id="session-jump")
                yield Button("New Thread", id="session-new")
                yield Button("Refresh", id="session-refresh")
                yield Button("Close", id="session-close")

    def on_mount(self) -> None:
        table = self.query_one("#session-browser-table", DataTable)
        table.cursor_type = "row"
        self._populate()

    def action_close(self) -> None:
        self.dismiss(None)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "session-close":
            self.dismiss(None)
            return
        if event.button.id == "session-refresh":
            self._populate(note="Refreshed persisted threads.")
            return
        if event.button.id == "session-new":
            self._create_thread_selection()
            return
        if event.button.id != "session-jump":
            return
        row_index = self.query_one("#session-browser-table", DataTable).cursor_row
        if row_index < 0 or row_index >= len(self._threads):
            return
        thread = self._threads[row_index]
        if not thread.agent_name or not thread.thread_id:
            self.query_one("#session-browser-details", Static).update(
                "This persisted row is missing agent or thread metadata and cannot be reopened directly."
            )
            return
        self.dismiss(ThreadSelection(agent_name=thread.agent_name, thread_id=thread.thread_id))

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.data_table.id == "session-browser-table":
            self._update_details(event.cursor_row)

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "session-filter-input":
            self._populate()

    def _populate(self, note: str = "") -> None:
        table = self.query_one("#session-browser-table", DataTable)
        table.clear(columns=True)
        table.add_columns("Agent", "Thread", "Turns", "Last Role", "Last Updated")
        query = self.query_one("#session-filter-input", Input).value.strip()
        self._threads = list_chat_threads(self.config.sessions_dir, limit=100, query=query or None)
        for thread in self._threads:
            table.add_row(
                thread.agent_name or "-",
                thread.thread_id or "-",
                str(thread.turn_count),
                thread.last_role,
                thread.last_created_at,
            )
        if self._threads:
            target_row = self._preferred_row_index()
            table.move_cursor(row=target_row, column=0)
            self._update_details(target_row, note=note)
        else:
            message = note or "No persisted threads match this filter yet."
            if self.preferred_agent_name:
                message = f"{message}\n\nUse `New Thread` to start a fresh thread for {self.preferred_agent_name}."
            self.query_one("#session-browser-details", Static).update(message)

    def _update_details(self, row_index: int, note: str = "") -> None:
        if row_index < 0 or row_index >= len(self._threads):
            return
        thread = self._threads[row_index]
        turns = load_chat_history(
            self.config.sessions_dir,
            limit=8,
            agent_name=thread.agent_name,
            thread_id=thread.thread_id,
        )
        lines = [
            f"Agent: {thread.agent_name or '-'}",
            f"Thread: {thread.thread_id or '-'}",
            f"Turns: {thread.turn_count}",
            f"Last Updated: {thread.last_created_at}",
        ]
        if thread.thread_id == self.active_thread_id:
            lines.append("Current Selection: active")
        lines.extend(["", "Recent Turns:"])
        if not turns:
            lines.append("No turns found.")
        else:
            for turn in turns:
                preview = turn.content if len(turn.content) <= 120 else f"{turn.content[:117]}..."
                lines.append(f"{turn.role}: {preview}")
        if note:
            lines.extend(["", note])
        self.query_one("#session-browser-details", Static).update("\n".join(lines))

    def _create_thread_selection(self) -> None:
        agent_name = self._selected_agent_name() or self.preferred_agent_name
        if not agent_name:
            self.query_one("#session-browser-details", Static).update(
                "Select a persisted thread first, or open the browser while an agent is selected."
            )
            return
        self.dismiss(
            ThreadSelection(
                agent_name=agent_name,
                thread_id=create_thread_id(agent_name),
                created_new=True,
            )
        )

    def _selected_agent_name(self) -> str | None:
        row_index = self.query_one("#session-browser-table", DataTable).cursor_row
        if row_index < 0 or row_index >= len(self._threads):
            return None
        return self._threads[row_index].agent_name

    def _preferred_row_index(self) -> int:
        if self.active_thread_id is not None:
            for index, thread in enumerate(self._threads):
                if thread.thread_id == self.active_thread_id:
                    return index
        if self.preferred_agent_name is not None:
            for index, thread in enumerate(self._threads):
                if thread.agent_name == self.preferred_agent_name:
                    return index
        return 0
