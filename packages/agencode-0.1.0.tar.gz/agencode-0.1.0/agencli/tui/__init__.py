"""Textual UI for AgenCLI."""
