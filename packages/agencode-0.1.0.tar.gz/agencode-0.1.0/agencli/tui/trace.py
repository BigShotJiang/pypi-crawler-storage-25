from __future__ import annotations

from dataclasses import dataclass

from textual.widgets import DataTable

from agencli.agents.runtime import StreamEvent


TRACE_ROW_LIMIT = 40


@dataclass(slots=True)
class TraceRow:
    step: int
    kind: str
    label: str
    status: str
    detail: str


@dataclass(slots=True)
class OrchestrationRow:
    name: str
    role: str
    tools: str
    status: str
    detail: str


class TraceLedger:
    def __init__(self, max_rows: int = TRACE_ROW_LIMIT) -> None:
        self.max_rows = max_rows
        self.rows: list[TraceRow] = []
        self._next_step = 1
        self._active_tools: dict[str, TraceRow] = {}
        self._active_subagents: dict[str, TraceRow] = {}

    def reset(self) -> None:
        self.rows.clear()
        self._active_tools.clear()
        self._active_subagents.clear()
        self._next_step = 1

    def begin_run(self, agent_name: str, thread_id: str) -> None:
        self.reset()
        self.add_status(label=agent_name, status="thread", detail=thread_id, kind="session")

    def add_status(self, *, label: str, status: str, detail: str, kind: str = "state") -> None:
        self._append_row(kind=kind, label=label, status=status, detail=detail)

    def record(self, event: StreamEvent) -> None:
        if event.kind == "assistant":
            return
        if event.kind == "tool":
            self._record_tool_event(event)
            return
        if event.kind == "subagent":
            self._record_subagent_event(event)
            return
        self._append_row(
            kind=event.kind,
            label=event.label,
            status=event.phase or "update",
            detail=event.text or "(ok)",
        )

    def _record_tool_event(self, event: StreamEvent) -> None:
        tool_key = event.trace_id or event.label
        if event.phase == "start":
            row = self._append_row(
                kind="tool",
                label=event.label,
                status="running",
                detail=event.text or "invoked",
            )
            self._active_tools[tool_key] = row
            return

        existing = self._active_tools.pop(tool_key, None)
        if existing is None:
            self._append_row(
                kind="tool",
                label=event.label,
                status="done",
                detail=event.text or "(ok)",
            )
            return

        existing.status = "done"
        existing.detail = _merge_detail(existing.detail, event.text or "(ok)")

    def _record_subagent_event(self, event: StreamEvent) -> None:
        subagent_key = event.trace_id or event.label
        if event.phase == "start":
            row = self._append_row(
                kind="subagent",
                label=event.label,
                status="running",
                detail=event.text or "delegated",
            )
            self._active_subagents[subagent_key] = row
            return

        existing = self._active_subagents.pop(subagent_key, None)
        if existing is None:
            self._append_row(
                kind="subagent",
                label=event.label,
                status="done",
                detail=event.text or "(ok)",
            )
            return

        existing.status = "done"
        existing.detail = _merge_detail(existing.detail, event.text or "(ok)")

    def _append_row(self, *, kind: str, label: str, status: str, detail: str) -> TraceRow:
        row = TraceRow(
            step=self._next_step,
            kind=kind,
            label=label,
            status=status,
            detail=detail,
        )
        self._next_step += 1
        self.rows.append(row)
        self._trim_rows()
        return row

    def _trim_rows(self) -> None:
        while len(self.rows) > self.max_rows:
            dropped = self.rows.pop(0)
            stale_keys = [key for key, value in self._active_tools.items() if value is dropped]
            for key in stale_keys:
                self._active_tools.pop(key, None)
            stale_subagents = [key for key, value in self._active_subagents.items() if value is dropped]
            for key in stale_subagents:
                self._active_subagents.pop(key, None)


class OrchestrationLedger:
    def __init__(self) -> None:
        self.rows: list[OrchestrationRow] = []
        self._rows_by_name: dict[str, OrchestrationRow] = {}
        self._active_runs: dict[str, OrchestrationRow] = {}

    def configure(self, subagents: list[dict[str, str]]) -> None:
        self.rows.clear()
        self._rows_by_name.clear()
        self._active_runs.clear()
        if not subagents:
            self.rows.append(
                OrchestrationRow(
                    name="-",
                    role="No configured subagents",
                    tools="-",
                    status="idle",
                    detail="This agent currently runs without delegated subagent roles.",
                )
            )
            return
        for subagent in subagents:
            row = OrchestrationRow(
                name=subagent["name"],
                role=subagent["role"],
                tools=subagent["tools"],
                status="idle",
                detail=subagent.get("detail", "Ready"),
            )
            self.rows.append(row)
            self._rows_by_name[row.name] = row

    def record(self, event: StreamEvent) -> None:
        if event.kind != "subagent":
            return
        run_key = event.trace_id or event.label
        if event.phase == "start":
            row = self._rows_by_name.get(event.label)
            if row is None:
                if self.rows and self.rows[0].name == "-":
                    self.rows.clear()
                row = OrchestrationRow(
                    name=event.label,
                    role="Delegated task",
                    tools="dynamic",
                    status="idle",
                    detail="Discovered from runtime activity.",
                )
                self.rows.append(row)
                self._rows_by_name[row.name] = row
            row.status = "running"
            row.detail = event.text or "delegated"
            if event.trace_id:
                self._active_runs[run_key] = row
            return

        row = self._active_runs.pop(run_key, None)
        if row is None:
            row = self._rows_by_name.get(event.label)
        if row is None:
            row = OrchestrationRow(
                name=event.label,
                role="Delegated task",
                tools="dynamic",
                status="done",
                detail=event.text or "(ok)",
            )
            self.rows.append(row)
            self._rows_by_name[row.name] = row
            return
        row.status = "done"
        row.detail = _merge_detail(row.detail, event.text or "(ok)")

    def record_status(self, name: str, status: str, detail: str) -> None:
        row = self._rows_by_name.get(name)
        if row is None:
            return
        row.status = status
        row.detail = detail


class TraceTable(DataTable[str]):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.ledger = TraceLedger()
        self.cursor_type = "none"
        self.zebra_stripes = True
        self._configured = False

    def on_mount(self) -> None:
        self._ensure_columns()

    def begin_run(self, agent_name: str, thread_id: str) -> None:
        self.ledger.begin_run(agent_name, thread_id)
        self._render_rows()

    def reset(self) -> None:
        self.ledger.reset()
        self._render_rows()

    def record_event(self, event: StreamEvent) -> None:
        self.ledger.record(event)
        self._render_rows()

    def record_status(self, *, label: str, status: str, detail: str, kind: str = "state") -> None:
        self.ledger.add_status(label=label, status=status, detail=detail, kind=kind)
        self._render_rows()

    def _ensure_columns(self) -> None:
        if self._configured:
            return
        self.show_row_labels = False
        self.add_column("Step", key="step", width=6)
        self.add_column("Kind", key="kind", width=10)
        self.add_column("Target", key="label", width=18)
        self.add_column("Status", key="status", width=10)
        self.add_column("Detail", key="detail")
        self._configured = True

    def _render_rows(self) -> None:
        self._ensure_columns()
        self.clear(columns=False)
        for row in self.ledger.rows:
            self.add_row(
                str(row.step),
                row.kind,
                row.label,
                row.status,
                row.detail,
                key=f"trace-{row.step}",
            )


class OrchestrationTable(DataTable[str]):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.ledger = OrchestrationLedger()
        self.cursor_type = "none"
        self.zebra_stripes = True
        self._configured = False

    def on_mount(self) -> None:
        self._ensure_columns()

    def configure_subagents(self, subagents: list[dict[str, str]]) -> None:
        self.ledger.configure(subagents)
        self._render_rows()

    def reset(self) -> None:
        self.ledger.configure([])
        self._render_rows()

    def record_event(self, event: StreamEvent) -> None:
        self.ledger.record(event)
        self._render_rows()

    def record_status(self, name: str, status: str, detail: str) -> None:
        self.ledger.record_status(name, status, detail)
        self._render_rows()

    def _ensure_columns(self) -> None:
        if self._configured:
            return
        self.show_row_labels = False
        self.add_column("Subagent", key="name", width=20)
        self.add_column("Role", key="role", width=30)
        self.add_column("Tools", key="tools", width=18)
        self.add_column("Status", key="status", width=10)
        self.add_column("Detail", key="detail")
        self._configured = True

    def _render_rows(self) -> None:
        self._ensure_columns()
        self.clear(columns=False)
        for index, row in enumerate(self.ledger.rows, start=1):
            self.add_row(
                row.name,
                row.role,
                row.tools,
                row.status,
                row.detail,
                key=f"orchestration-{index}",
            )


def _merge_detail(current: str, new: str) -> str:
    normalized_current = current.strip()
    normalized_new = new.strip()
    if not normalized_current:
        return normalized_new
    if not normalized_new or normalized_current == normalized_new:
        return normalized_current
    return f"{normalized_current} -> {normalized_new}"
