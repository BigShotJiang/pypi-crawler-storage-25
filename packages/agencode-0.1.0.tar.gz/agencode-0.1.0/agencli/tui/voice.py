from __future__ import annotations

import asyncio
import base64
import sys
from textwrap import dedent


VOICE_TIMEOUT_SECONDS = 15


def _powershell_executable() -> str:
    return "powershell.exe" if sys.platform == "win32" else "pwsh"


def _encode_powershell(script: str) -> str:
    return base64.b64encode(script.encode("utf-16-le")).decode("ascii")


def build_voice_capture_script(timeout_seconds: int = VOICE_TIMEOUT_SECONDS) -> str:
    timeout_seconds = max(3, int(timeout_seconds))
    return dedent(
        f"""
        $ErrorActionPreference = 'Stop'
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        Add-Type -AssemblyName System.Speech

        $culture = [System.Globalization.CultureInfo]::InstalledUICulture
        try {{
            $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine($culture)
        }} catch {{
            $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine('en-US')
        }}

        $engine.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
        $engine.SetInputToDefaultAudioDevice()
        $result = $engine.Recognize([TimeSpan]::FromSeconds({timeout_seconds}))

        if ($null -eq $result -or [string]::IsNullOrWhiteSpace($result.Text)) {{
            exit 0
        }}

        Write-Output $result.Text
        """
    ).strip()


async def transcribe_once(timeout_seconds: int = VOICE_TIMEOUT_SECONDS) -> str:
    script = build_voice_capture_script(timeout_seconds=timeout_seconds)
    encoded = _encode_powershell(script)
    process = await asyncio.create_subprocess_exec(
        _powershell_executable(),
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-EncodedCommand",
        encoded,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await process.communicate()
    except asyncio.CancelledError:
        if process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=1.0)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
        raise

    if process.returncode not in (0, None):
        error_text = (stderr or b"").decode("utf-8", errors="replace").strip()
        raise RuntimeError(error_text or "Voice capture failed.")

    return (stdout or b"").decode("utf-8", errors="replace").strip()
