from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SlashCommand:
    name: str
    description: str
    usage: str
    aliases: tuple[str, ...] = ()


def get_slash_commands() -> list[SlashCommand]:
    return [
        SlashCommand("agent", "Manage saved supervisor subagents and their active state.", "/agent", ("use",)),
        SlashCommand("build", "Build the currently selected agent.", "/build"),
        SlashCommand("new-thread", "Start a fresh thread for the selected agent.", "/new-thread", ("thread",)),
        SlashCommand("history", "Open the inline persisted thread picker.", "/history", ("threads",)),
        SlashCommand("resume", "Resume the latest or a chosen persisted thread.", "/resume [thread-id]", ("continue",)),
        SlashCommand("reset", "Reset the current deepagent session back to a fresh default state.", "/reset", ("fresh",)),
        SlashCommand("fork", "Fork the current thread into a new persisted thread.", "/fork"),
        SlashCommand("compact", "Summarize the current conversation into a compact session note.", "/compact"),
        SlashCommand("select-skill", "Attach one or more skills to only the current thread.", "/select-skill", ("thread-skills",)),
        SlashCommand("mention", "Attach a file or folder as extra context for future prompts.", "/mention <path>", ("attach",)),
        SlashCommand("diff", "Show the current git diff for the workspace.", "/diff"),
        SlashCommand("init", "Create an AGENTS.md scaffold in the workspace root.", "/init"),
        SlashCommand("personality", "Set shell response style such as concise or collaborative.", "/personality [concise|collaborative|direct]", ("style",)),
        SlashCommand("permissions", "Set approval behavior such as auto, confirm, or read-only.", "/permissions [auto|confirm|read-only]", ("approval",)),
        SlashCommand("plan", "Toggle plan mode before execution, or set it explicitly.", "/plan [on|off]", ("plan-mode",)),
        SlashCommand("skills", "Browse, install, and update skills through the Skills CLI.", "/skills"),
        SlashCommand("mcp", "Open the inline MCP server manager.", "/mcp"),
        SlashCommand("bootstrap-mcp", "Seed the default MCP servers.", "/bootstrap-mcp"),
        SlashCommand("model", "Open model/provider settings.", "/model", ("models",)),
        SlashCommand("theme", "Switch between dark and light shell themes.", "/theme [dark|light]", ("appearance",)),
        SlashCommand("voice", "Toggle voice-to-text and fill the prompt from your microphone.", "/voice", ("mic", "dictate")),
        SlashCommand("status", "Show the current agent, thread, model, and provider status.", "/status"),
        SlashCommand("cancel", "Dismiss the current waiting-for-input prompt.", "/cancel"),
        SlashCommand("refresh", "Reload agent and runtime state.", "/refresh"),
        SlashCommand("clear", "Clear the conversation and runtime panes.", "/clear"),
        SlashCommand("help", "Show the available slash commands.", "/help", ("?",)),
    ]


def match_slash_commands(query: str) -> list[SlashCommand]:
    normalized = query.strip().lower().lstrip("/")
    token, _, _ = normalized.partition(" ")
    commands = get_slash_commands()
    if not token:
        return commands

    exact_matches = [command for command in commands if token == command.name or token in command.aliases]
    if exact_matches:
        return exact_matches

    prefix_matches = [
        command
        for command in commands
        if command.name.startswith(token) or any(alias.startswith(token) for alias in command.aliases)
    ]
    if prefix_matches:
        return prefix_matches

    filtered: list[SlashCommand] = []
    for command in commands:
        haystacks = [command.name, *command.aliases, command.description, command.usage]
        if any(token in value.lower() for value in haystacks):
            filtered.append(command)
    return filtered


def filter_slash_commands(query: str) -> list[SlashCommand]:
    return match_slash_commands(query)


def resolve_slash_command(name: str) -> SlashCommand | None:
    normalized = name.strip().lower().lstrip("/")
    for command in get_slash_commands():
        if normalized == command.name or normalized in command.aliases:
            return command
    return None


def best_slash_command_match(query: str) -> SlashCommand | None:
    matches = match_slash_commands(query)
    return matches[0] if matches else None
