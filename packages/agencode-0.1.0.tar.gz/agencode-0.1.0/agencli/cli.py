﻿from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from agencli.agents.factory import build_agent
from agencli.agents.prebuilt.catalog import get_prebuilt_agents
from agencli.agents.registry import AgentRegistry
from agencli.agents.runtime import (
    DEFAULT_HISTORY_REPLAY_LIMIT,
    build_prompt_payload,
    extract_text_response,
    parse_stream_chunk,
)
from agencli.core.config import (
    AgenCLIConfig,
    ensure_config,
    load_config,
    save_config,
    set_openai_compatible_provider,
)
from agencli.core.logger import configure_logging
from agencli.core.session import (
    append_chat_turn,
    build_thread_config,
    describe_langgraph_checkpointer,
    ensure_session_db,
    get_thread_id,
    has_thread_checkpoint,
    list_chat_threads,
    load_chat_history,
    resolve_thread_id,
)
from agencli.mcp.config import (
    MCPServerConfig,
    bootstrap_default_mcp_servers,
    load_mcp_servers,
    upsert_mcp_server,
)
from agencli.providers.model import describe_api_key_source
from agencli.skills.manager import install_skill, list_installed_skills
from agencli.tui.app import AgenCLIApp

app = typer.Typer(help="AgenCLI: a multi-agent terminal workspace.")
console = Console()


def _get_registry(config: AgenCLIConfig) -> AgentRegistry:
    return AgentRegistry(config.agents_dir)


def _resolve_agent_spec(config: AgenCLIConfig, name: str):
    prebuilt = get_prebuilt_agents(config.default_model)
    if name in prebuilt:
        return prebuilt[name]
    return _get_registry(config).load(name)


def _resolve_project_config_path(config_path: Path | None, workspace: Path) -> Path:
    if config_path is not None:
        return config_path
    return ensure_config(root=workspace / ".agencode")


@app.callback()
def main() -> None:
    """Initialize CLI state shared by all commands."""
    configure_logging()


@app.command()
def tui(
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
    workspace: Path | None = typer.Option(
        None,
        "--workspace",
        help="Workspace directory to open. Defaults to the current directory.",
    ),
    inline: bool = typer.Option(
        True,
        "--inline/--fullscreen",
        help="Run inline in the terminal scrollback instead of using Textual's fullscreen alternate screen.",
    ),
) -> None:
    """Launch the Textual UI."""
    launch_workspace = (workspace or Path.cwd()).expanduser().resolve()
    resolved_config_path = _resolve_project_config_path(config_path, launch_workspace)
    config = load_config(resolved_config_path)
    config = replace(config, workspace_dir=str(launch_workspace))
    save_config(config, resolved_config_path)
    AgenCLIApp(config=config, config_path=resolved_config_path).run(inline=inline)


@app.command("init-config")
def init_config(
    force: bool = typer.Option(False, "--force", help="Overwrite an existing config file."),
    base_url: str | None = typer.Option(None, "--base-url", help="OpenAI-compatible API base URL."),
    model: str | None = typer.Option(None, "--model", help="Default OpenAI-compatible model name."),
    model_kind: str | None = typer.Option(None, "--model-kind", help="Model kind, for example chat or responses."),
    api_key: str | None = typer.Option(None, "--api-key", help="OpenAI-compatible API key to store in keyring."),
) -> None:
    """Create the default AgenCLI config in the user directory."""
    path = ensure_config(overwrite=force)
    if any(value is not None for value in (base_url, model, model_kind, api_key)):
        set_openai_compatible_provider(
            config_path=path,
            base_url=base_url,
            model=model,
            model_kind=model_kind,
            api_key=api_key,
        )
    console.print(f"Config ready at {path}")


@app.command()
def doctor(config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml")) -> None:
    """Print basic environment details for debugging."""
    config: AgenCLIConfig = load_config(config_path)
    console.print(f"workspace: {config.workspace_dir}")
    console.print(f"sessions: {config.sessions_dir}")
    console.print(f"agents: {config.agents_dir}")
    console.print(f"default model: {config.default_model}")
    console.print(f"openai-compatible base_url: {config.openai_compatible.base_url or '-'}")
    console.print(f"openai-compatible model: {config.openai_compatible.model or '-'}")
    console.print(f"openai-compatible model_kind: {config.openai_compatible.model_kind}")
    console.print(f"openai-compatible api key: {describe_api_key_source(config)}")
    console.print(f"langgraph checkpointer: {describe_langgraph_checkpointer(config.sessions_dir)}")
    console.print(f"session db: {ensure_session_db(config.sessions_dir)}")


@app.command("config-openai")
def config_openai(
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
    provider_name: str = typer.Option("openai-compatible", "--provider-name", help="Logical provider label."),
    base_url: str = typer.Option(..., "--base-url", help="OpenAI-compatible API base URL."),
    model: str = typer.Option(..., "--model", help="Model name exposed by the provider."),
    model_kind: str = typer.Option("chat", "--model-kind", help="Model kind, for example chat or responses."),
    api_key: str | None = typer.Option(None, "--api-key", help="API key to store in keyring."),
    api_key_env: str = typer.Option("OPENAI_API_KEY", "--api-key-env", help="Env var name used by this provider."),
    set_default: bool = typer.Option(True, "--set-default/--no-set-default", help="Update default_model to this model."),
) -> None:
    """Configure an OpenAI-compatible provider."""
    config = set_openai_compatible_provider(
        config_path=config_path,
        provider_name=provider_name,
        base_url=base_url,
        model=model,
        model_kind=model_kind,
        api_key=api_key,
        api_key_env=api_key_env,
        set_as_default=set_default,
    )
    console.print(f"Saved OpenAI-compatible provider to {config_path or ensure_config()}")
    console.print(f"default model: {config.default_model}")


@app.command("config-show")
def config_show(config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml")) -> None:
    """Show the current resolved configuration."""
    config = load_config(config_path)
    table = Table(title="AgenCLI Config")
    table.add_column("Key")
    table.add_column("Value")
    table.add_row("workspace_dir", config.workspace_dir)
    table.add_row("sessions_dir", config.sessions_dir)
    table.add_row("agents_dir", config.agents_dir)
    table.add_row("skills_dir", config.skills_dir)
    table.add_row("default_model", config.default_model)
    table.add_row("openai.provider_name", config.openai_compatible.provider_name)
    table.add_row("openai.base_url", config.openai_compatible.base_url or "-")
    table.add_row("openai.model", config.openai_compatible.model or "-")
    table.add_row("openai.model_kind", config.openai_compatible.model_kind)
    table.add_row("openai.api_key_env", config.openai_compatible.api_key_env)
    table.add_row("openai.api_key", describe_api_key_source(config))
    console.print(table)


@app.command("mcp-list")
def mcp_list(config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml")) -> None:
    """List configured MCP servers."""
    config = load_config(config_path)
    servers = load_mcp_servers(config.mcp_config_path)
    table = Table(title="MCP Servers")
    table.add_column("Name")
    table.add_column("Transport")
    table.add_column("Command / URL")
    if not servers:
        table.add_row("-", "-", "No MCP servers configured")
    else:
        for name, server in sorted(servers.items()):
            target = server.url or " ".join([server.command or "", *server.args]).strip()
            table.add_row(name, server.transport, target or "-")
    console.print(table)


@app.command("mcp-add-stdio")
def mcp_add_stdio(
    name: str = typer.Argument(..., help="MCP server name."),
    command: str = typer.Option(..., "--command", help="Command used to start the server."),
    args: list[str] | None = typer.Option(None, "--arg", help="Repeatable command arguments."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Add or update a stdio MCP server."""
    config = load_config(config_path)
    path = upsert_mcp_server(
        config.mcp_config_path,
        name,
        MCPServerConfig(transport="stdio", command=command, args=args or []),
    )
    console.print(f"Saved MCP server `{name}` to {path}")


@app.command("mcp-add-http")
def mcp_add_http(
    name: str = typer.Argument(..., help="MCP server name."),
    url: str = typer.Option(..., "--url", help="HTTP MCP endpoint URL."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Add or update an HTTP MCP server."""
    config = load_config(config_path)
    path = upsert_mcp_server(
        config.mcp_config_path,
        name,
        MCPServerConfig(transport="http", url=url),
    )
    console.print(f"Saved MCP server `{name}` to {path}")


@app.command("mcp-bootstrap-defaults")
def mcp_bootstrap_defaults(
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Seed the default remote MCP servers."""
    config = load_config(config_path)
    path = bootstrap_default_mcp_servers(config.mcp_config_path, config.workspace_dir)
    console.print(f"Bootstrapped default MCP servers into {path}")


@app.command("agent-list")
def agent_list(
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
    include_saved: bool = typer.Option(True, "--include-saved/--no-include-saved", help="Show saved agents."),
) -> None:
    """List prebuilt and saved agent specs."""
    config = load_config(config_path)
    prebuilt = get_prebuilt_agents(config.default_model)
    registry = _get_registry(config)

    table = Table(title="Agents")
    table.add_column("Name")
    table.add_column("Source")
    table.add_column("MCP Servers")
    table.add_column("Description")
    for spec in prebuilt.values():
        table.add_row(spec.name, "prebuilt", ", ".join(spec.mcp_servers) or "-", spec.description)
    if include_saved:
        for name in registry.list_agents():
            spec = registry.load(name)
            table.add_row(spec.name, "saved", ", ".join(spec.mcp_servers) or "-", spec.description or "-")
    console.print(table)


@app.command("agent-show")
def agent_show(
    name: str = typer.Argument(..., help="Agent name."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Show a resolved agent spec."""
    config = load_config(config_path)
    spec = _resolve_agent_spec(config, name)
    table = Table(title=f"Agent: {spec.name}")
    table.add_column("Field")
    table.add_column("Value")
    table.add_row("model", spec.model)
    table.add_row("description", spec.description or "-")
    table.add_row("mcp_servers", ", ".join(spec.mcp_servers) or "-")
    table.add_row("skills", ", ".join(spec.skills) or "-")
    table.add_row("workspace_dir", spec.workspace_dir or config.workspace_dir)
    table.add_row("system_prompt", spec.system_prompt)
    console.print(table)


@app.command("agent-save-prebuilt")
def agent_save_prebuilt(
    name: str = typer.Argument(..., help="Prebuilt agent name."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Save a prebuilt agent spec into the user registry."""
    config = load_config(config_path)
    prebuilt = get_prebuilt_agents(config.default_model)
    if name not in prebuilt:
        raise typer.BadParameter(f"Unknown prebuilt agent: {name}")
    path = _get_registry(config).save(prebuilt[name])
    console.print(f"Saved agent `{name}` to {path}")


@app.command("agent-build-check")
def agent_build_check(
    name: str = typer.Argument(..., help="Agent name."),
    skill: list[str] | None = typer.Option(
        None,
        "--skill",
        help="Installed skill name, `installed`, or a skill source path to enable for this build.",
    ),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Construct an agent graph to verify runtime wiring."""
    config = load_config(config_path)
    spec = _resolve_agent_spec(config, name)
    if skill:
        spec = replace(spec, skills=[*spec.skills, *skill])
    diagnostics: list[str] = []
    agent = build_agent(spec, config=config, diagnostics=diagnostics)
    for message in diagnostics:
        console.print(f"[yellow]{message}[/yellow]")
    console.print(f"Built agent `{spec.name}` as {type(agent).__name__}")


@app.command("agent-run-prompt")
def agent_run_prompt(
    name: str = typer.Argument(..., help="Agent name."),
    prompt: str = typer.Option(..., "--prompt", help="Prompt text to send to the agent."),
    skill: list[str] | None = typer.Option(
        None,
        "--skill",
        help="Installed skill name, `installed`, or a skill source path to enable for this run.",
    ),
    stream: bool = typer.Option(False, "--stream", help="Print streamed updates instead of only the final response."),
    history_limit: int = typer.Option(
        DEFAULT_HISTORY_REPLAY_LIMIT,
        "--history-limit",
        min=0,
        help="Number of recent persisted turns to replay into the prompt.",
    ),
    thread_id: str | None = typer.Option(None, "--thread-id", help="Explicit persisted thread ID to continue."),
    new_thread: bool = typer.Option(False, "--new-thread", help="Create a fresh thread ID for this run."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Build an agent and run a single prompt."""
    config = load_config(config_path)
    spec = _resolve_agent_spec(config, name)
    if skill:
        spec = replace(spec, skills=[*spec.skills, *skill])
    diagnostics: list[str] = []
    agent = build_agent(spec, config=config, diagnostics=diagnostics)
    for message in diagnostics:
        console.print(f"[yellow]{message}[/yellow]")
    if thread_id and new_thread:
        raise typer.BadParameter("Use either --thread-id or --new-thread, not both.")
    resolved_thread_id = resolve_thread_id(spec.name, thread_id=thread_id, new_thread=new_thread)
    thread_config = build_thread_config(spec.name, thread_id=resolved_thread_id)
    should_bootstrap_history = history_limit > 0 and not has_thread_checkpoint(
        config.sessions_dir,
        spec.name,
        thread_id=resolved_thread_id,
    )
    history = (
        load_chat_history(
            config.sessions_dir,
            limit=history_limit,
            agent_name=spec.name,
            thread_id=resolved_thread_id,
        )
        if should_bootstrap_history
        else []
    )
    payload = build_prompt_payload(prompt, history=history)
    console.print(f"thread: {resolved_thread_id}")
    append_chat_turn(
        config.sessions_dir,
        "user",
        prompt,
        agent_name=spec.name,
        thread_id=resolved_thread_id,
    )
    if stream:
        last_chunk = None
        final_response = ""
        for chunk in agent.stream(payload, config=thread_config, stream_mode="updates"):
            last_chunk = chunk
            for event in parse_stream_chunk(chunk):
                if event.kind == "assistant":
                    final_response = event.text
                    console.print(event.text)
                else:
                    console.print(f"[{event.kind}:{event.label}] {event.text or '(ok)'}")
        if last_chunk is not None:
            final_text = extract_text_response(last_chunk)
            if final_text and not str(final_text).startswith("{'"):
                final_response = final_text
                console.print(f"[final] {final_text}")
        if final_response:
            append_chat_turn(
                config.sessions_dir,
                "assistant",
                final_response,
                agent_name=spec.name,
                thread_id=resolved_thread_id,
            )
        return

    result = agent.invoke(payload, config=thread_config)
    response = extract_text_response(result)
    console.print(response)
    if response:
        append_chat_turn(
            config.sessions_dir,
            "assistant",
            response,
            agent_name=spec.name,
            thread_id=resolved_thread_id,
        )


@app.command("session-show")
def session_show(
    limit: int = typer.Option(20, "--limit", help="Number of recent chat turns to show."),
    agent_name: str | None = typer.Option(None, "--agent", help="Optional agent name to filter by."),
    thread_id: str | None = typer.Option(None, "--thread-id", help="Optional explicit thread ID to filter by."),
    all_threads: bool = typer.Option(
        False,
        "--all-threads",
        help="When used with --agent, include every persisted thread for that agent.",
    ),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Show recent persisted chat turns."""
    config = load_config(config_path)
    if thread_id and all_threads:
        raise typer.BadParameter("Use either --thread-id or --all-threads, not both.")
    resolved_thread_id = thread_id
    if resolved_thread_id is None and agent_name and not all_threads:
        resolved_thread_id = get_thread_id(agent_name)
    turns = load_chat_history(
        config.sessions_dir,
        limit=limit,
        agent_name=agent_name,
        thread_id=resolved_thread_id,
    )
    table = Table(title="Recent Session History")
    table.add_column("Role")
    table.add_column("Content")
    table.add_column("Agent")
    table.add_column("Thread")
    table.add_column("Created At")
    if not turns:
        table.add_row("-", "No chat history", agent_name or "-", resolved_thread_id or "-", "-")
    else:
        for turn in turns:
            table.add_row(
                turn.role,
                turn.content,
                turn.agent_name or "-",
                turn.thread_id or "-",
                turn.created_at,
            )
    console.print(table)


@app.command("session-list")
def session_list(
    limit: int = typer.Option(20, "--limit", help="Number of persisted threads to show."),
    agent_name: str | None = typer.Option(None, "--agent", help="Optional agent name to filter by."),
    thread_id: str | None = typer.Option(None, "--thread-id", help="Optional exact thread ID to filter by."),
    query: str | None = typer.Option(None, "--query", help="Search agent name, thread ID, or latest content."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """List persisted chat threads with latest activity."""
    config = load_config(config_path)
    threads = list_chat_threads(
        config.sessions_dir,
        limit=limit,
        agent_name=agent_name,
        thread_id=thread_id,
        query=query,
    )
    table = Table(title="Session Threads")
    table.add_column("Agent")
    table.add_column("Thread")
    table.add_column("Turns")
    table.add_column("Last Role")
    table.add_column("Last Content")
    table.add_column("Last Updated")
    if not threads:
        table.add_row(agent_name or "-", "-", "0", "-", "No persisted threads", "-")
    else:
        for thread in threads:
            preview = thread.last_content if len(thread.last_content) <= 80 else f"{thread.last_content[:77]}..."
            table.add_row(
                thread.agent_name or "-",
                thread.thread_id or "-",
                str(thread.turn_count),
                thread.last_role,
                preview,
                thread.last_created_at,
            )
    console.print(table)


@app.command("skill-list")
def skill_list(config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml")) -> None:
    """List locally installed skills."""
    config = load_config(config_path)
    skills = list_installed_skills(config.skills_dir)
    table = Table(title="Installed Skills")
    table.add_column("Name")
    table.add_column("Tools")
    table.add_column("Description")
    table.add_column("Path")
    if not skills:
        table.add_row("-", "-", "No local skills installed", config.skills_dir)
    else:
        for skill in skills:
            table.add_row(
                skill.name,
                ", ".join(skill.allowed_tools) or "-",
                skill.description,
                str(skill.path),
            )
    console.print(table)


@app.command("skill-show")
def skill_show(
    name: str = typer.Argument(..., help="Installed skill name."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Show metadata for one locally installed skill."""
    config = load_config(config_path)
    skills = {skill.name: skill for skill in list_installed_skills(config.skills_dir)}
    if name not in skills:
        raise typer.BadParameter(f"Unknown installed skill: {name}")
    skill = skills[name]
    table = Table(title=f"Skill: {skill.name}")
    table.add_column("Field")
    table.add_column("Value")
    table.add_row("path", str(skill.path))
    table.add_row("description", skill.description)
    table.add_row("allowed_tools", ", ".join(skill.allowed_tools) or "-")
    table.add_row("license", skill.license or "-")
    table.add_row("compatibility", skill.compatibility or "-")
    table.add_row("agent spec token", skill.name)
    table.add_row("all installed token", "installed")
    console.print(table)


@app.command("skill-install")
def skill_install(
    source: Path = typer.Argument(..., help="Path to a local skill directory or SKILL.md file."),
    overwrite: bool = typer.Option(False, "--overwrite", help="Replace an existing installed skill."),
    config_path: Path | None = typer.Option(None, "--config", help="Path to config.toml"),
) -> None:
    """Install a local skill into the AgenCLI skill library."""
    config = load_config(config_path)
    installed = install_skill(source, config.skills_dir, overwrite=overwrite)
    console.print(f"Installed skill `{installed.name}` into {installed.path}")
    console.print("Use it with `--skill installed` or `--skill <skill-name>` on agent commands.")
