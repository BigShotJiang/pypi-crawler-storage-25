from __future__ import annotations

from collections.abc import Collection, Iterable, Sequence

from agencli.agents.factory import AgentSpec


def parse_token_list(raw: str) -> list[str]:
    tokens = [token.strip() for chunk in raw.replace("\n", ",").split(",") for token in [chunk.strip()]]
    return _dedupe([token for token in tokens if token])


def format_token_list(values: Sequence[str]) -> str:
    return ", ".join(value for value in values if value)


def partition_skill_tokens(
    skill_tokens: Sequence[str],
    installed_skill_names: Collection[str],
) -> tuple[list[str], list[str]]:
    installed_names = set(installed_skill_names)
    managed: list[str] = []
    extra: list[str] = []
    for token in skill_tokens:
        if token == "installed" or token in installed_names:
            managed.append(token)
        else:
            extra.append(token)
    return _dedupe(managed), _dedupe(extra)


def suggest_custom_agent_name(base_name: str, existing_names: Collection[str]) -> str:
    existing = set(existing_names)
    normalized_base = base_name.strip() or "custom-agent"
    candidate = normalized_base if normalized_base not in existing else f"{normalized_base}-custom"
    if candidate not in existing:
        return candidate

    index = 2
    while f"{candidate}-{index}" in existing:
        index += 1
    return f"{candidate}-{index}"


def copy_agent_spec_for_customization(
    spec: AgentSpec | None,
    *,
    existing_names: Collection[str],
    default_model: str,
) -> AgentSpec:
    if spec is None:
        return AgentSpec(
            name=suggest_custom_agent_name("custom-agent", existing_names),
            model=default_model,
            system_prompt="You are a helpful AI agent. Work carefully and explain your reasoning clearly.",
        )

    copied = AgentSpec.from_dict(spec.serializable_dict())
    copied.name = suggest_custom_agent_name(spec.name, existing_names)
    if not copied.model:
        copied.model = default_model
    return copied


def build_agent_spec_from_editor(
    *,
    base_spec: AgentSpec | None,
    name: str,
    model: str,
    description: str,
    system_prompt: str,
    workspace_dir: str,
    mcp_servers_raw: str,
    selected_skill_tokens: Iterable[str],
    extra_skill_tokens_raw: str,
) -> AgentSpec:
    normalized_name = name.strip()
    normalized_model = model.strip()
    normalized_prompt = system_prompt.strip()
    if not normalized_name:
        raise ValueError("Agent name is required.")
    if not normalized_model:
        raise ValueError("Agent model is required.")
    if not normalized_prompt:
        raise ValueError("System prompt is required.")

    seeded = AgentSpec.from_dict(base_spec.serializable_dict()) if base_spec is not None else AgentSpec(
        name=normalized_name,
        model=normalized_model,
        system_prompt=normalized_prompt,
    )
    seeded.name = normalized_name
    seeded.model = normalized_model
    seeded.description = description.strip()
    seeded.system_prompt = normalized_prompt
    seeded.workspace_dir = workspace_dir.strip() or None
    seeded.mcp_servers = parse_token_list(mcp_servers_raw)
    seeded.skills = _dedupe([*selected_skill_tokens, *parse_token_list(extra_skill_tokens_raw)])
    return seeded


def _dedupe(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped
