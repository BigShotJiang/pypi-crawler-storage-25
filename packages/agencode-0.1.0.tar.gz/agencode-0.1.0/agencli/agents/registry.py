from __future__ import annotations

import json
from pathlib import Path

from agencli.agents.factory import AgentSpec


class AgentRegistry:
    def __init__(self, agents_dir: str) -> None:
        self.agents_path = Path(agents_dir)
        self.agents_path.mkdir(parents=True, exist_ok=True)
        self._state_path = self.agents_path / ".agencli-state.json"

    def path_for(self, name: str) -> Path:
        return self.agents_path / f"{name}.json"

    def save(self, spec: AgentSpec) -> Path:
        path = self.path_for(spec.name)
        path.write_text(json.dumps(spec.serializable_dict(), indent=2), encoding="utf-8")
        return path

    def list_agents(self) -> list[str]:
        return sorted(path.stem for path in self.agents_path.glob("*.json") if path.name != self._state_path.name)

    def load(self, name: str) -> AgentSpec:
        path = self.path_for(name)
        raw = json.loads(path.read_text(encoding="utf-8"))
        return AgentSpec.from_dict(raw)

    def delete(self, name: str) -> Path:
        path = self.path_for(name)
        path.unlink()
        active_names = [item for item in self.load_active_names() if item != name]
        self.save_active_names(active_names)
        return path

    def load_active_names(self) -> list[str]:
        if not self._state_path.exists():
            return []
        raw = json.loads(self._state_path.read_text(encoding="utf-8"))
        names = raw.get("active_agents", [])
        if not isinstance(names, list):
            return []
        return [str(name) for name in names if str(name).strip()]

    def save_active_names(self, names: list[str]) -> Path:
        normalized = sorted({name.strip() for name in names if name and name.strip()})
        self._state_path.write_text(json.dumps({"active_agents": normalized}, indent=2), encoding="utf-8")
        return self._state_path
