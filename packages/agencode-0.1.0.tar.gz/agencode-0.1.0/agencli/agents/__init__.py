"""Agent construction and registration helpers."""
