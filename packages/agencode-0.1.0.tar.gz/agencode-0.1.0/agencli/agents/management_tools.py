from __future__ import annotations

import json
from pathlib import Path
from textwrap import shorten
from typing import TYPE_CHECKING

from langchain_core.tools import tool

from agencli.agents.registry import AgentRegistry
from agencli.core.config import AgenCLIConfig
from agencli.skills.cli_backend import (
    check_skills,
    find_skills,
    install_skill_cli,
    list_installed_skills_cli,
    render_command,
    update_skills,
)
from agencli.skills.manager import install_skill as install_local_skill, list_installed_skills as list_local_skills

if TYPE_CHECKING:
    from agencli.agents.factory import AgentSpec


def build_supervisor_management_tools(config: AgenCLIConfig) -> list:
    registry = AgentRegistry(config.agents_dir)

    @tool("list_saved_subagents")
    def list_saved_subagents() -> str:
        """List saved user-managed subagents and which ones are active under the supervisor."""
        active = set(registry.load_active_names())
        items = []
        for name in registry.list_agents():
            spec = registry.load(name)
            items.append(
                {
                    "name": spec.name,
                    "description": spec.description,
                    "skills": list(spec.skills),
                    "active": spec.name in active,
                }
            )
        return json.dumps({"active_names": sorted(active), "subagents": items}, indent=2)

    @tool("get_saved_subagent")
    def get_saved_subagent(name: str) -> str:
        """Load one saved subagent by name, including its prompt and attached skills."""
        spec = registry.load(name.strip())
        return json.dumps(_spec_payload(spec, active_names=registry.load_active_names()), indent=2)

    @tool("save_subagent")
    def save_subagent(
        name: str,
        system_prompt: str,
        description: str = "",
        skills: list[str] | None = None,
        activate: bool = False,
    ) -> str:
        """Create or update a saved subagent with the given prompt and attached skill names."""
        cleaned_name = name.strip()
        cleaned_prompt = system_prompt.strip()
        if not cleaned_name:
            raise ValueError("Subagent name cannot be empty.")
        if not cleaned_prompt:
            raise ValueError("Subagent system prompt cannot be empty.")
        from agencli.agents.factory import AgentSpec

        existing = registry.load(cleaned_name) if cleaned_name in registry.list_agents() else None
        spec = AgentSpec(
            name=cleaned_name,
            model=(existing.model if existing is not None else config.default_model),
            system_prompt=cleaned_prompt,
            description=description.strip() or (existing.description if existing is not None else _derive_description(cleaned_prompt)),
            skills=sorted(dict.fromkeys(skills or (existing.skills if existing is not None else []))),
            subagents=list(existing.subagents) if existing is not None else [],
            mcp_servers=list(existing.mcp_servers) if existing is not None else [],
            workspace_dir=(existing.workspace_dir if existing is not None else config.workspace_dir),
        )
        path = registry.save(spec)
        active_names = set(registry.load_active_names())
        if activate:
            active_names.add(cleaned_name)
            registry.save_active_names(sorted(active_names))
        return json.dumps(
            {
                "saved": cleaned_name,
                "path": str(path),
                "active": cleaned_name in set(registry.load_active_names()),
                "skills": spec.skills,
            },
            indent=2,
        )

    @tool("delete_subagent")
    def delete_subagent(name: str) -> str:
        """Delete a saved subagent and remove it from the supervisor active set."""
        path = registry.delete(name.strip())
        return json.dumps({"deleted": name.strip(), "path": str(path)}, indent=2)

    @tool("set_active_subagents")
    def set_active_subagents(names: list[str]) -> str:
        """Replace the supervisor active subagent list with the provided saved subagent names."""
        wanted = sorted({item.strip() for item in names if item and item.strip()})
        existing = set(registry.list_agents())
        missing = [name for name in wanted if name not in existing]
        if missing:
            raise ValueError(f"Unknown saved subagent(s): {', '.join(missing)}")
        registry.save_active_names(wanted)
        return json.dumps({"active_names": wanted}, indent=2)

    @tool("list_attachable_skills")
    def list_attachable_skills() -> str:
        """List skills that can be attached to subagents, including local and Skills CLI installed skills."""
        local = [
            {
                "name": skill.name,
                "description": skill.description,
                "source": str(skill.path),
                "kind": "local",
            }
            for skill in list_local_skills(config.skills_dir)
        ]
        try:
            _result, installed = list_installed_skills_cli(workspace_dir=config.workspace_dir)
        except Exception as exc:
            installed = []
            local.append(
                {
                    "name": "warning",
                    "description": f"Unable to query Skills CLI installed state: {exc}",
                    "source": "skills-cli",
                    "kind": "warning",
                }
            )
        merged = {item["name"]: item for item in local}
        for record in installed:
            merged.setdefault(
                record.name,
                {
                    "name": record.name,
                    "description": record.details,
                    "source": record.source or "skills-cli",
                    "kind": f"installed:{record.scope or 'unknown'}",
                },
            )
        return json.dumps({"skills": [merged[name] for name in sorted(merged)]}, indent=2)

    @tool("search_marketplace_skills")
    def search_marketplace_skills(query: str, limit: int = 8) -> str:
        """Search the Skills marketplace with `npx skills find` and return the strongest matching skills."""
        result, items = find_skills(query, workspace_dir=config.workspace_dir)
        payload = {
            "command": render_command(result.argv),
            "ok": result.ok,
            "results": [
                {
                    "name": item.name,
                    "source": item.source,
                    "skill_name": item.skill_name,
                    "skills_page_url": item.skills_page_url,
                    "github_repo_url": item.github_repo_url,
                    "install_count": item.install_count_text,
                    "description": item.description,
                    "trust": list(item.quality.labels),
                    "install_command": render_command(item.install_command) if item.install_command else None,
                }
                for item in items[: max(1, limit)]
            ],
        }
        return json.dumps(payload, indent=2)

    @tool("install_marketplace_skill")
    def install_marketplace_skill(source: str, skill_name: str = "", global_install: bool = True, yes: bool = True) -> str:
        """Install a skill through the Skills CLI and sync it into the local attachable skill library when possible."""
        result = install_skill_cli(
            source,
            workspace_dir=config.workspace_dir,
            skill_name=skill_name.strip() or None,
            global_install=global_install,
            yes=yes,
        )
        imported = None
        if result.ok and skill_name.strip():
            imported = _sync_installed_skill_into_local_library(config, skill_name.strip())
        return json.dumps(
            {
                "command": render_command(result.argv),
                "ok": result.ok,
                "imported_local_skill": imported,
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip(),
                "error": result.error_summary,
            },
            indent=2,
        )

    @tool("check_skill_updates")
    def check_skill_updates() -> str:
        """Check for updates to installed marketplace skills."""
        result, status = check_skills(workspace_dir=config.workspace_dir)
        return json.dumps(
            {
                "command": render_command(result.argv),
                "ok": result.ok,
                "summary": status.summary,
                "items": status.items,
            },
            indent=2,
        )

    @tool("update_marketplace_skills")
    def update_marketplace_skills() -> str:
        """Update installed marketplace skills to their latest versions."""
        result, status = update_skills(workspace_dir=config.workspace_dir)
        return json.dumps(
            {
                "command": render_command(result.argv),
                "ok": result.ok,
                "summary": status.summary,
                "items": status.items,
            },
            indent=2,
        )

    return [
        list_saved_subagents,
        get_saved_subagent,
        save_subagent,
        delete_subagent,
        set_active_subagents,
        list_attachable_skills,
        search_marketplace_skills,
        install_marketplace_skill,
        check_skill_updates,
        update_marketplace_skills,
    ]


def _spec_payload(spec: "AgentSpec", *, active_names: list[str]) -> dict[str, object]:
    return {
        "name": spec.name,
        "description": spec.description,
        "system_prompt": spec.system_prompt,
        "skills": list(spec.skills),
        "active": spec.name in set(active_names),
        "workspace_dir": spec.workspace_dir,
    }


def _derive_description(system_prompt: str) -> str:
    return shorten(system_prompt.strip().replace("\n", " "), width=96, placeholder="...")


def _sync_installed_skill_into_local_library(config: AgenCLIConfig, skill_name: str) -> str | None:
    source_path = _discover_external_skill_path(config, skill_name)
    if source_path is None:
        return None
    try:
        installed = install_local_skill(source_path, config.skills_dir, overwrite=False)
        return installed.name
    except FileExistsError:
        return skill_name


def _discover_external_skill_path(config: AgenCLIConfig, skill_name: str) -> str | None:
    candidates = [
        Path(config.workspace_dir) / ".agents" / "skills" / skill_name,
        Path(config.workspace_dir) / ".codex" / "skills" / skill_name,
        Path.home() / ".agents" / "skills" / skill_name,
        Path.home() / ".codex" / "skills" / skill_name,
        Path.home() / ".config" / "agents" / "skills" / skill_name,
    ]
    for candidate in candidates:
        if (candidate / "SKILL.md").exists():
            return candidate.as_posix()
    return None
