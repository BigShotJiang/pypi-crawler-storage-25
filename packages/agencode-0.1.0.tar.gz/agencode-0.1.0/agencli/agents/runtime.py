from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any

from agencli.core.session import ChatTurn


DEFAULT_HISTORY_REPLAY_LIMIT = 50
TRACE_PREVIEW_LIMIT = 240


@dataclass(slots=True)
class StreamEvent:
    kind: str
    label: str
    text: str
    phase: str = "update"
    trace_id: str = ""


def build_prompt_payload(
    prompt: str | None = None,
    *,
    history: list[ChatTurn] | None = None,
) -> dict[str, Any]:
    messages = build_message_history(history or [])
    if prompt:
        normalized_prompt = prompt.strip()
        if normalized_prompt:
            messages.append(
                {
                    "role": "user",
                    "content": normalized_prompt,
                }
            )
    return {"messages": messages}


def build_message_history(history: list[ChatTurn]) -> list[dict[str, str]]:
    messages: list[dict[str, str]] = []
    for turn in history:
        role = _normalize_role(turn.role)
        content = turn.content.strip()
        if role is None or not content:
            continue
        messages.append({"role": role, "content": content})
    return messages


def parse_stream_chunk(chunk: Any) -> list[StreamEvent]:
    if not isinstance(chunk, dict):
        return []

    events: list[StreamEvent] = []
    for label, payload in chunk.items():
        events.extend(_parse_payload_events(label, payload))
    return events


def extract_text_response(result: Any) -> str:
    if result is None:
        return ""

    if isinstance(result, str):
        return result

    if isinstance(result, dict):
        messages = result.get("messages")
        if isinstance(messages, list):
            for message in reversed(messages):
                text = _extract_message_text(message)
                if text:
                    return text
        for key in ("output", "result", "response"):
            value = result.get(key)
            if isinstance(value, str) and value.strip():
                return value
        return repr(result)

    return _extract_message_text(result) or repr(result)


def _summarize_payload(payload: Any) -> str:
    if payload is None:
        return ""
    if isinstance(payload, dict):
        filtered = {key: value for key, value in payload.items() if key not in {"messages", "skills_metadata"}}
        if not filtered:
            return ""
        return _compact_text(filtered)
    return _compact_text(payload)


def _normalize_trace_label(label: str) -> str:
    cleaned = label.replace("Middleware", "").replace("_", " ").strip()
    parts = [part.strip() for part in cleaned.split(".") if part.strip()]
    normalized = " / ".join(parts) if parts else cleaned
    return normalized.lower()


def _normalize_role(role: str | None) -> str | None:
    if role is None:
        return None
    normalized = role.strip().lower()
    if normalized in {"ai", "assistant"}:
        return "assistant"
    if normalized in {"human", "user"}:
        return "user"
    if normalized == "system":
        return "system"
    return None


def _parse_payload_events(label: str, payload: Any) -> list[StreamEvent]:
    if not isinstance(payload, dict):
        summarized = _compact_text(payload)
        if not summarized:
            return []
        return [StreamEvent(kind="state", label=_normalize_trace_label(label), text=summarized)]

    events: list[StreamEvent] = []
    messages = payload.get("messages", [])
    if isinstance(messages, list):
        for message in messages:
            events.extend(_parse_message_event(label, message))

    summary = _summarize_payload(payload)
    if summary:
        events.append(StreamEvent(kind="state", label=_normalize_trace_label(label), text=summary))
    return events


def _parse_message_event(label: str, message: Any) -> list[StreamEvent]:
    role = _message_role(message)
    events: list[StreamEvent] = []

    if role == "assistant":
        for tool_call in _extract_tool_calls(message):
            tool_name = tool_call.get("name") or _normalize_trace_label(label)
            tool_input = tool_call.get("args", tool_call.get("arguments"))
            trace_id = str(tool_call.get("id", "")).strip()
            if str(tool_name).strip() == "task" and isinstance(tool_input, dict):
                subagent_type = str(tool_input.get("subagent_type", "")).strip()
                description = _compact_text(tool_input.get("description")) or _compact_text(tool_input) or "invoked"
                if subagent_type:
                    events.append(
                        StreamEvent(
                            kind="subagent",
                            label=subagent_type,
                            text=description,
                            phase="start",
                            trace_id=trace_id,
                        )
                    )
                    continue
            events.append(
                StreamEvent(
                    kind="tool",
                    label=str(tool_name),
                    text=_compact_text(tool_input) or "invoked",
                    phase="start",
                    trace_id=trace_id,
                )
            )
        text = _extract_message_text(message)
        if text:
            events.append(StreamEvent(kind="assistant", label="assistant", text=text, phase="message"))
        return events

    if role == "tool":
        tool_name = _message_name(message) or _normalize_trace_label(label)
        tool_text = _extract_message_text(message)
        trace_id = _message_tool_call_id(message)
        if tool_name == "task":
            events.append(
                StreamEvent(
                    kind="subagent",
                    label=tool_name,
                    text=tool_text or "(ok)",
                    phase="end",
                    trace_id=trace_id,
                )
            )
            return events
        events.append(
            StreamEvent(
                kind="tool",
                label=tool_name,
                text=tool_text or "(ok)",
                phase="end",
                trace_id=trace_id,
            )
        )
        return events

    text = _extract_message_text(message)
    if text:
        events.append(StreamEvent(kind="state", label=_normalize_trace_label(label), text=text, phase="update"))
    return events


def _message_role(message: Any) -> str | None:
    role = getattr(message, "type", None)
    if role is None and isinstance(message, dict):
        role = message.get("type") or message.get("role")
    return _normalize_role(role) or ("tool" if str(role).strip().lower() == "tool" else None)


def _message_name(message: Any) -> str:
    name = getattr(message, "name", None)
    if name is None and isinstance(message, dict):
        name = message.get("name")
    return str(name).strip() if name else ""


def _message_tool_call_id(message: Any) -> str:
    tool_call_id = getattr(message, "tool_call_id", None)
    if tool_call_id is None and isinstance(message, dict):
        tool_call_id = message.get("tool_call_id")
    return str(tool_call_id).strip() if tool_call_id else ""


def _extract_tool_calls(message: Any) -> list[dict[str, Any]]:
    tool_calls = getattr(message, "tool_calls", None)
    if tool_calls is None and isinstance(message, dict):
        tool_calls = message.get("tool_calls")
    if not isinstance(tool_calls, list):
        return []
    return [call for call in tool_calls if isinstance(call, dict)]


def _extract_message_text(message: Any) -> str:
    content = getattr(message, "content", None)
    if content is None and isinstance(message, dict):
        content = message.get("content")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "\n".join(part for part in parts if part).strip()
    return ""


def _compact_text(value: Any, limit: int = TRACE_PREVIEW_LIMIT) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        text = value.strip()
    else:
        try:
            text = json.dumps(value, ensure_ascii=True, sort_keys=True)
        except TypeError:
            text = repr(value)
    compacted = " ".join(text.split())
    if len(compacted) <= limit:
        return compacted
    return f"{compacted[: limit - 3]}..."
