"""Prebuilt agent definitions."""
