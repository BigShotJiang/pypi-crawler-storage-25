from __future__ import annotations

from agencli.agents.factory import AgentSpec
from agencli.agents.supervisor import build_supervisor_agent


PERFORMANCE_PROMPT_SUFFIX = (
    " Optimize for fewer, larger operations. Inspect enough context up front, avoid repeating the same checks, "
    "keep tool calls minimal, and prefer one strong command or grouped action when it can safely replace many "
    "small steps."
)


def get_prebuilt_agents(default_model: str) -> dict[str, AgentSpec]:
    agents = {
        "filesystem-agent": AgentSpec(
            name="filesystem-agent",
            model=default_model,
            description="Reads, writes, and navigates the workspace with deepagents' built-in filesystem tools.",
            system_prompt=(
                "You are a filesystem specialist. Read carefully before editing, "
                "keep changes precise, and explain file operations clearly. When organizing files or folders, "
                "prefer batched plans and grouped operations over one-item-at-a-time actions whenever the "
                "available tools support it. Inspect first, decide the full target layout, then create needed "
                "folders together and move related files in as few operations as possible to reduce tool chatter."
                + PERFORMANCE_PROMPT_SUFFIX
            ),
        ),
        "shell-agent": AgentSpec(
            name="shell-agent",
            model=default_model,
            description="Runs shell commands with deepagents' built-in execute tool.",
            system_prompt=(
                "You are a shell automation specialist. Use commands carefully, "
                "prefer safe inspections first, and summarize command results precisely. When shell automation "
                "can safely batch a task, prefer one well-formed command over many tiny commands."
                + PERFORMANCE_PROMPT_SUFFIX
            ),
        ),
        "search-agent": AgentSpec(
            name="search-agent",
            model=default_model,
            description="Searches the web through MCP-backed search tools.",
            system_prompt=(
                "You are a research specialist. Search broadly, synthesize findings, "
                "and distinguish facts from inference. Avoid redundant searches and combine related questions into "
                "the fewest high-value lookups that still produce a reliable answer."
                + PERFORMANCE_PROMPT_SUFFIX
            ),
            mcp_servers=["search", "tavily-mcp"],
        ),
        "coding-agent": AgentSpec(
            name="coding-agent",
            model=default_model,
            description="Combines deepagents' built-in filesystem and shell tools for implementation work.",
            system_prompt=(
                "You are an expert software engineer. Inspect files before editing, "
                "make surgical changes, and verify your work. Prefer one cohesive patch and one targeted "
                "verification pass over fragmented micro-steps. Use shell commands for bulk filesystem work when "
                "they safely replace repetitive tool calls."
                + PERFORMANCE_PROMPT_SUFFIX
            ),
        ),
    }
    agents["supervisor-agent"] = build_supervisor_agent(default_model)
    return agents
