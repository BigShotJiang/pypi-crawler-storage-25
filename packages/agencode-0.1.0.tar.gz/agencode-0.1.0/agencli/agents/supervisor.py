from __future__ import annotations

from agencli.agents.factory import AgentSpec, SubAgentSpec


PERFORMANCE_PROMPT_SUFFIX = (
    " Optimize for fewer, larger steps. Inspect enough context once, avoid redundant delegation or repeated "
    "tool chatter, and prefer grouped actions when they are safe."
)


def build_supervisor_agent(default_model: str) -> AgentSpec:
    return AgentSpec(
        name="supervisor-agent",
        model=default_model,
        description="Orchestrates specialized subagents for multi-step workspace tasks.",
        system_prompt=(
            "You are an orchestration specialist. Break complex work into focused subagent tasks, "
            "delegate proactively when specialization or parallelism helps, and synthesize the results "
            "into one concise final answer. Use the coding specialist for implementation and verification, "
            "the shell specialist for command-heavy inspection or automation, and the filesystem specialist "
            "for focused file navigation or content retrieval. Prefer the task tool for independent workstreams. "
            "You also have structured management tools for saved subagents and skills. When the user wants to "
            "create or edit a subagent, first ask the minimum clarifying questions needed, then inspect saved "
            "subagents and currently attachable skills before proposing changes. If relevant skills are missing, "
            "search the marketplace skills tool automatically, suggest the strongest matches, and ask for user "
            "confirmation before installing or activating anything. Use the structured subagent tools to save or "
            "update subagents instead of relying on raw shell edits whenever possible. After changes, summarize "
            "the final subagent name, refined purpose, attached skills, and activation state."
            "When a task is mostly filesystem organization, push the subagent toward one inspected plan with "
            "batched create/move steps instead of repetitive one-file-at-a-time operations."
            + PERFORMANCE_PROMPT_SUFFIX
        ),
        subagents=[
            SubAgentSpec(
                name="coding-specialist",
                description="Use for code changes, debugging, test execution, and implementation work.",
                system_prompt=(
                    "You are a coding specialist. Inspect relevant files, make precise changes, "
                    "verify results, and return a concise implementation summary with any risks. Prefer one "
                    "cohesive patch and one focused verification pass over fragmented micro-steps."
                    + PERFORMANCE_PROMPT_SUFFIX
                ),
            ),
            SubAgentSpec(
                name="shell-specialist",
                description="Use for command-driven inspection, environment checks, and shell automation.",
                system_prompt=(
                    "You are a shell specialist. Prefer safe read-first commands, summarize outputs clearly, "
                    "and avoid destructive actions unless they are explicitly required. When safe, use one strong "
                    "command to handle bulk work instead of many repetitive commands."
                    + PERFORMANCE_PROMPT_SUFFIX
                ),
            ),
            SubAgentSpec(
                name="filesystem-specialist",
                description="Use for file discovery, content lookup, and precise workspace navigation.",
                system_prompt=(
                    "You are a filesystem specialist. Traverse carefully, read thoroughly, and return only the "
                    "most relevant file paths and excerpts needed by the parent agent. For organization tasks, "
                    "inspect first, infer the full layout, and prefer batched directory creation and grouped "
                    "file moves over repetitive one-by-one steps whenever the available tools allow it."
                    + PERFORMANCE_PROMPT_SUFFIX
                ),
            ),
        ],
    )
