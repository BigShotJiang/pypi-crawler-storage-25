﻿from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from agencli.core.config import AgenCLIConfig
from agencli.core.session import ensure_langgraph_checkpointer, ensure_langgraph_checkpointer_async
from agencli.providers.model import init_model
from agencli.skills.loader import resolve_skill_sources
from agencli.tools.mcp import load_mcp_tools, load_mcp_tools_async


@dataclass(slots=True)
class SubAgentSpec:
    name: str
    description: str
    system_prompt: str
    model: str | None = None
    skills: list[str] = field(default_factory=list)
    mcp_servers: list[str] = field(default_factory=list)
    workspace_dir: str | None = None

    def serializable_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "system_prompt": self.system_prompt,
            "model": self.model,
            "skills": self.skills,
            "mcp_servers": self.mcp_servers,
            "workspace_dir": self.workspace_dir,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "SubAgentSpec":
        return cls(
            name=raw["name"],
            description=raw["description"],
            system_prompt=raw["system_prompt"],
            model=raw.get("model"),
            skills=list(raw.get("skills", [])),
            mcp_servers=list(raw.get("mcp_servers", [])),
            workspace_dir=raw.get("workspace_dir"),
        )


@dataclass(slots=True)
class AgentSpec:
    name: str
    model: str
    system_prompt: str
    description: str = ""
    tools: list[Any] = field(default_factory=list)
    subagents: list[SubAgentSpec | dict[str, Any]] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    mcp_servers: list[str] = field(default_factory=list)
    workspace_dir: str | None = None

    def serializable_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "model": self.model,
            "system_prompt": self.system_prompt,
            "description": self.description,
            "subagents": [_serialize_subagent(subagent) for subagent in self.subagents],
            "skills": self.skills,
            "mcp_servers": self.mcp_servers,
            "workspace_dir": self.workspace_dir,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "AgentSpec":
        return cls(
            name=raw["name"],
            model=raw["model"],
            system_prompt=raw["system_prompt"],
            description=raw.get("description", ""),
            subagents=[_deserialize_subagent(subagent) for subagent in raw.get("subagents", [])],
            skills=list(raw.get("skills", [])),
            mcp_servers=list(raw.get("mcp_servers", [])),
            workspace_dir=raw.get("workspace_dir"),
        )


def build_agent(
    spec: AgentSpec,
    config: AgenCLIConfig | None = None,
    *,
    session_name: str = "default",
    checkpointer: Any | None = None,
    diagnostics: list[str] | None = None,
) -> Any:
    """Build a DeepAgent graph lazily once the runtime dependencies are installed."""
    try:
        from deepagents import create_deep_agent
        from deepagents.backends import FilesystemBackend, LocalShellBackend
    except ImportError as exc:
        raise RuntimeError(
            "Deep agent runtime dependencies are not installed yet. Run `uv sync` after dependencies are added."
        ) from exc

    resolved_tools = list(spec.tools)
    if config is None:
        try:
            from langchain.chat_models import init_chat_model
        except ImportError as exc:
            raise RuntimeError(
                "langchain is not installed yet. Run `uv sync` after dependencies are added."
            ) from exc
        model = init_chat_model(spec.model)
        workspace_dir = spec.workspace_dir
        resolved_subagents = _resolve_subagents(spec.subagents, model_name=spec.model)
        resolved_skills = list(spec.skills)
    else:
        model = init_model(config, model_name=spec.model)
        workspace_dir = spec.workspace_dir or config.workspace_dir
        if checkpointer is None:
            checkpointer = ensure_langgraph_checkpointer(config.sessions_dir, session_name=session_name)
        if spec.name == "supervisor-agent":
            from agencli.agents.management_tools import build_supervisor_management_tools

            resolved_tools.extend(build_supervisor_management_tools(config))
        if spec.mcp_servers:
            resolved_tools.extend(
                load_mcp_tools(
                    config.mcp_config_path,
                    server_names=spec.mcp_servers,
                    diagnostics=diagnostics,
                )
            )
        resolved_subagents = _resolve_subagents(
            spec.subagents,
            config=config,
            model_name=spec.model,
            diagnostics=diagnostics,
        )
        resolved_skills = resolve_skill_sources(spec.skills, config.skills_dir)

    backend = _build_backend(spec.name, workspace_dir, FilesystemBackend, LocalShellBackend)
    return create_deep_agent(
        model=model,
        tools=resolved_tools,
        system_prompt=spec.system_prompt,
        subagents=resolved_subagents,
        skills=resolved_skills or None,
        backend=backend,
        checkpointer=checkpointer,
        name=spec.name,
    )


async def build_agent_async(
    spec: AgentSpec,
    config: AgenCLIConfig | None = None,
    *,
    session_name: str = "default",
    checkpointer: Any | None = None,
    diagnostics: list[str] | None = None,
) -> Any:
    try:
        from deepagents import create_deep_agent
        from deepagents.backends import FilesystemBackend, LocalShellBackend
    except ImportError as exc:
        raise RuntimeError(
            "Deep agent runtime dependencies are not installed yet. Run `uv sync` after dependencies are added."
        ) from exc

    resolved_tools = list(spec.tools)
    if config is None:
        return build_agent(
            spec,
            config=None,
            session_name=session_name,
            checkpointer=checkpointer,
            diagnostics=diagnostics,
        )

    model = init_model(config, model_name=spec.model)
    workspace_dir = spec.workspace_dir or config.workspace_dir
    if checkpointer is None:
        checkpointer = await ensure_langgraph_checkpointer_async(config.sessions_dir, session_name=session_name)
    if spec.name == "supervisor-agent":
        from agencli.agents.management_tools import build_supervisor_management_tools

        resolved_tools.extend(build_supervisor_management_tools(config))
    if spec.mcp_servers:
        resolved_tools.extend(
            await load_mcp_tools_async(
                config.mcp_config_path,
                server_names=spec.mcp_servers,
                diagnostics=diagnostics,
            )
        )
    resolved_subagents = await _resolve_subagents_async(
        spec.subagents,
        config=config,
        model_name=spec.model,
        diagnostics=diagnostics,
    )
    resolved_skills = resolve_skill_sources(spec.skills, config.skills_dir)

    backend = _build_backend(spec.name, workspace_dir, FilesystemBackend, LocalShellBackend)
    return create_deep_agent(
        model=model,
        tools=resolved_tools,
        system_prompt=spec.system_prompt,
        subagents=resolved_subagents,
        skills=resolved_skills or None,
        backend=backend,
        checkpointer=checkpointer,
        name=spec.name,
    )


def _serialize_subagent(subagent: SubAgentSpec | dict[str, Any]) -> dict[str, Any]:
    if isinstance(subagent, SubAgentSpec):
        return {"kind": "spec", **subagent.serializable_dict()}
    if isinstance(subagent, dict) and "runnable" in subagent:
        raise ValueError("Compiled subagents cannot be serialized into agent registry JSON.")
    if isinstance(subagent, dict):
        return dict(subagent)
    raise TypeError(f"Unsupported subagent type: {type(subagent)!r}")


def _deserialize_subagent(raw: dict[str, Any]) -> SubAgentSpec | dict[str, Any]:
    if raw.get("kind") == "spec":
        payload = dict(raw)
        payload.pop("kind", None)
        return SubAgentSpec.from_dict(payload)
    if {"name", "description", "system_prompt"}.issubset(raw):
        return SubAgentSpec.from_dict(raw)
    return raw


def _build_backend(
    agent_name: str,
    workspace_dir: str | None,
    filesystem_backend_cls: Any,
    local_shell_backend_cls: Any,
):
    shell_enabled_agents = {"shell-agent", "coding-agent", "supervisor-agent"}
    backend_cls = local_shell_backend_cls if agent_name in shell_enabled_agents else filesystem_backend_cls
    if workspace_dir:
        return backend_cls(root_dir=workspace_dir)
    return backend_cls()


def _resolve_subagents(
    subagents: list[SubAgentSpec | dict[str, Any]],
    *,
    config: AgenCLIConfig | None = None,
    model_name: str,
    diagnostics: list[str] | None = None,
) -> list[dict[str, Any]]:
    resolved: list[dict[str, Any]] = []
    for subagent in subagents:
        if isinstance(subagent, SubAgentSpec):
            tools: list[Any] = []
            if config is not None and subagent.mcp_servers:
                tools.extend(
                    load_mcp_tools(
                        config.mcp_config_path,
                        server_names=subagent.mcp_servers,
                        diagnostics=diagnostics,
                    )
                )
            elif subagent.mcp_servers:
                raise RuntimeError("Subagents with MCP servers require a resolved AgenCLI config.")
            payload: dict[str, Any] = {
                "name": subagent.name,
                "description": subagent.description,
                "system_prompt": subagent.system_prompt,
                "tools": tools,
            }
            if subagent.model:
                payload["model"] = init_model(config, model_name=subagent.model) if config is not None else subagent.model
            elif config is not None:
                payload["model"] = init_model(config, model_name=model_name)
            else:
                payload["model"] = model_name
            if subagent.skills:
                payload["skills"] = (
                    resolve_skill_sources(subagent.skills, config.skills_dir)
                    if config is not None
                    else list(subagent.skills)
                )
            resolved.append(payload)
        else:
            resolved.append(dict(subagent))
    return resolved


async def _resolve_subagents_async(
    subagents: list[SubAgentSpec | dict[str, Any]],
    *,
    config: AgenCLIConfig | None = None,
    model_name: str,
    diagnostics: list[str] | None = None,
) -> list[dict[str, Any]]:
    resolved: list[dict[str, Any]] = []
    for subagent in subagents:
        if isinstance(subagent, SubAgentSpec):
            tools: list[Any] = []
            if config is not None and subagent.mcp_servers:
                tools.extend(
                    await load_mcp_tools_async(
                        config.mcp_config_path,
                        server_names=subagent.mcp_servers,
                        diagnostics=diagnostics,
                    )
                )
            elif subagent.mcp_servers:
                raise RuntimeError("Subagents with MCP servers require a resolved AgenCLI config.")
            payload: dict[str, Any] = {
                "name": subagent.name,
                "description": subagent.description,
                "system_prompt": subagent.system_prompt,
                "tools": tools,
            }
            if subagent.model:
                payload["model"] = init_model(config, model_name=subagent.model) if config is not None else subagent.model
            elif config is not None:
                payload["model"] = init_model(config, model_name=model_name)
            else:
                payload["model"] = model_name
            if subagent.skills:
                payload["skills"] = (
                    resolve_skill_sources(subagent.skills, config.skills_dir)
                    if config is not None
                    else list(subagent.skills)
                )
            resolved.append(payload)
        else:
            resolved.append(dict(subagent))
    return resolved
