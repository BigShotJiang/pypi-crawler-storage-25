from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import subprocess


SKILLS_BROWSE_CATEGORIES: tuple[tuple[str, str, str], ...] = (
    ("web-development", "Web Development", "react"),
    ("testing", "Testing", "playwright"),
    ("devops", "DevOps", "docker"),
    ("documentation", "Documentation", "docs"),
    ("code-quality", "Code Quality", "lint"),
    ("design", "Design", "ui"),
    ("productivity", "Productivity", "automation"),
)

_ANSI_PATTERN = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
_REPO_PATTERN = re.compile(r"\b([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)\b")
_CONTROL_PATTERN = re.compile(r"[\x00\r\n]")


@dataclass(slots=True)
class CliCommandResult:
    argv: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str
    ok: bool
    error_summary: str | None = None


@dataclass(slots=True)
class SkillResultQuality:
    score: int = 0
    labels: list[str] = field(default_factory=list)
    install_count: int | None = None
    trusted_source: bool = False


@dataclass(slots=True)
class SkillSearchResult:
    name: str
    description: str
    source: str
    install_source: str | None
    skill_name: str | None = None
    skills_page_url: str | None = None
    github_repo_url: str | None = None
    install_count_text: str | None = None
    why_useful: str | None = None
    install_command: tuple[str, ...] = ()
    quality: SkillResultQuality = field(default_factory=SkillResultQuality)
    raw_block: str = ""


@dataclass(slots=True)
class InstalledSkillRecord:
    name: str
    details: str
    scope: str | None = None
    source: str | None = None
    agents: list[str] = field(default_factory=list)
    raw_line: str = ""


@dataclass(slots=True)
class SkillsStatusResult:
    summary: str
    items: list[str] = field(default_factory=list)
    raw_output: str = ""


def run_skills_cli(args: list[str], *, workspace_dir: str) -> CliCommandResult:
    argv = ("npx", "skills", *args)
    try:
        result = subprocess.run(
            list(argv),
            cwd=workspace_dir,
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError as exc:
        return CliCommandResult(
            argv=argv,
            returncode=127,
            stdout="",
            stderr=str(exc),
            ok=False,
            error_summary=f"Unable to run `{render_command(argv)}`: {exc}",
        )

    stdout = result.stdout or ""
    stderr = result.stderr or ""
    ok = result.returncode == 0
    error_summary = None
    if not ok:
        error_summary = (stderr or stdout or f"`{render_command(argv)}` failed.").strip()
    return CliCommandResult(
        argv=argv,
        returncode=result.returncode,
        stdout=stdout,
        stderr=stderr,
        ok=ok,
        error_summary=error_summary,
    )


def find_skills(query: str, *, workspace_dir: str) -> tuple[CliCommandResult, list[SkillSearchResult]]:
    cleaned = query.strip()
    if not cleaned:
        raise ValueError("Search query cannot be empty.")
    result = run_skills_cli(["find", cleaned], workspace_dir=workspace_dir)
    return result, parse_find_output(result.stdout, query=cleaned)


def list_installed_skills_cli(
    *,
    workspace_dir: str,
    global_only: bool = False,
    agents: list[str] | None = None,
) -> tuple[CliCommandResult, list[InstalledSkillRecord]]:
    argv = ["list"]
    for agent in agents or ():
        argv.extend(["-a", agent])
    if global_only:
        global_result = run_skills_cli([*argv, "-g"], workspace_dir=workspace_dir)
        return global_result, parse_installed_output(global_result.stdout, default_scope="global")

    project_result = run_skills_cli(argv, workspace_dir=workspace_dir)
    global_result = run_skills_cli([*argv, "-g"], workspace_dir=workspace_dir)
    merged = _merge_cli_results(project_result, global_result)
    project_records = parse_installed_output(project_result.stdout, default_scope="project")
    global_records = parse_installed_output(global_result.stdout, default_scope="global")
    return merged, _merge_installed_records(project_records, global_records)


def install_skill_cli(
    source: str,
    *,
    workspace_dir: str,
    skill_name: str | None = None,
    global_install: bool = True,
    yes: bool = True,
    copy_files: bool = False,
    agents: list[str] | None = None,
) -> CliCommandResult:
    cleaned_source = validate_skill_source(source)
    argv = ["add", cleaned_source]
    if skill_name:
        argv.extend(["--skill", validate_skill_name(skill_name)])
    if global_install:
        argv.append("-g")
    if yes:
        argv.append("-y")
    if copy_files:
        argv.append("--copy")
    for agent in agents or ():
        argv.extend(["-a", agent])
    return run_skills_cli(argv, workspace_dir=workspace_dir)


def check_skills(*, workspace_dir: str) -> tuple[CliCommandResult, SkillsStatusResult]:
    result = run_skills_cli(["check"], workspace_dir=workspace_dir)
    return result, parse_status_output(result.stdout or result.stderr, empty_message="No skill updates reported.")


def update_skills(*, workspace_dir: str) -> tuple[CliCommandResult, SkillsStatusResult]:
    result = run_skills_cli(["update"], workspace_dir=workspace_dir)
    return result, parse_status_output(result.stdout or result.stderr, empty_message="No skill updates were applied.")


def render_command(argv: tuple[str, ...] | list[str]) -> str:
    return " ".join(_quote_arg(part) for part in argv)


def normalize_repo_skill_target(raw: str) -> tuple[str, str | None]:
    cleaned = raw.strip()
    if not cleaned:
        raise ValueError("Skill source cannot be empty.")
    if cleaned.count("@") == 1:
        repo, skill_name = cleaned.split("@", 1)
        if "/" in repo and skill_name:
            return validate_skill_source(repo), validate_skill_name(skill_name)
    return validate_skill_source(cleaned), None


def validate_skill_source(source: str) -> str:
    cleaned = source.strip()
    if not cleaned:
        raise ValueError("Skill source cannot be empty.")
    if _CONTROL_PATTERN.search(cleaned):
        raise ValueError("Skill source contains unsupported control characters.")
    return cleaned


def validate_skill_name(skill_name: str) -> str:
    cleaned = skill_name.strip()
    if not cleaned:
        raise ValueError("Skill name cannot be empty.")
    if _CONTROL_PATTERN.search(cleaned):
        raise ValueError("Skill name contains unsupported control characters.")
    return cleaned


def parse_find_output(stdout: str, *, query: str) -> list[SkillSearchResult]:
    cleaned = _strip_ansi(stdout).strip()
    if not cleaned:
        return []
    blocks = _split_blocks(cleaned)
    results: list[SkillSearchResult] = []
    for block in blocks:
        parsed = _parse_find_block(block, query=query)
        if parsed is not None:
            results.append(parsed)
    if results:
        return sorted(results, key=lambda item: (-item.quality.score, item.name.lower(), item.source.lower()))
    fallback = cleaned.splitlines()[0].strip()
    return [
        SkillSearchResult(
            name=fallback or query,
            description=cleaned,
            source="skills",
            install_source=None,
            why_useful=f"Search results for `{query}`.",
            raw_block=cleaned,
        )
    ]


def parse_installed_output(stdout: str, *, default_scope: str | None = None) -> list[InstalledSkillRecord]:
    cleaned = _strip_ansi(stdout).strip()
    if not cleaned:
        return []
    records: list[InstalledSkillRecord] = []
    for raw_line in cleaned.splitlines():
        line = raw_line.strip()
        if not line or _looks_like_heading(line) or _looks_like_installed_guidance(line):
            continue
        normalized = re.sub(r"^[*\-•\s]+", "", line)
        name = re.split(r"\s{2,}|  •  | • | - | — ", normalized, maxsplit=1)[0].strip()
        if not name:
            continue
        lowered = normalized.lower()
        scope = "global" if "global" in lowered else ("project" if "project" in lowered else default_scope)
        source_match = _REPO_PATTERN.search(normalized)
        agents: list[str] = []
        agents_match = re.search(r"agents:\s*(.+)$", normalized, re.IGNORECASE)
        if agents_match:
            agents = re.findall(r"\b[a-z0-9-]+(?:-cli)?\b", agents_match.group(1).lower())
        records.append(
            InstalledSkillRecord(
                name=name,
                details=normalized,
                scope=scope,
                source=source_match.group(1) if source_match else None,
                agents=agents,
                raw_line=line,
            )
        )
    return records


def parse_status_output(output: str, *, empty_message: str) -> SkillsStatusResult:
    cleaned = _strip_ansi(output).strip()
    if not cleaned:
        return SkillsStatusResult(summary=empty_message, raw_output="")
    lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
    summary = lines[0]
    return SkillsStatusResult(summary=summary, items=lines[1:], raw_output=cleaned)


def _parse_find_block(block: str, *, query: str) -> SkillSearchResult | None:
    lines = [line.strip() for line in block.splitlines() if line.strip()]
    if not lines:
        return None
    title = re.sub(r"^[*\-•\d.\s]+", "", lines[0]).strip()
    install_source: str | None = None
    skill_name: str | None = None
    install_count_text: str | None = None
    headline_match = re.match(
        r"^(?P<repo>[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)@(?P<skill>[A-Za-z0-9_.-]+)\s+(?P<count>.+?\s+installs?)$",
        title,
    )
    if headline_match:
        install_source = headline_match.group("repo")
        skill_name = headline_match.group("skill")
        install_count_text = headline_match.group("count").strip()
    skills_page_url = next((line.lstrip("└ ").strip() for line in lines[1:] if "skills.sh/" in line), None)
    if (install_source is None or skill_name is None) and skills_page_url:
        url_match = re.search(r"skills\.sh/(?P<repo>[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)/(?P<skill>[A-Za-z0-9_.-]+)", skills_page_url)
        if url_match:
            install_source = url_match.group("repo")
            skill_name = url_match.group("skill")
    if install_source is None:
        source_match = _REPO_PATTERN.search(block)
        install_source = source_match.group(1) if source_match else None
    source = install_source or "skills"
    github_repo_url = f"https://github.com/{install_source}" if install_source else None
    description = "Description not available from Skills CLI search output."
    if skill_name:
        title = skill_name
    elif install_source:
        title = install_source
    else:
        title = title or query
    install_command = tuple(_install_command_for(install_source, skill_name=skill_name)) if install_source else ()
    quality = _derive_quality(source=source, block=block, install_count_text=install_count_text)
    why_useful = f"Install `{title}` from `{source}`." if install_source else f"Search results for `{query}`."
    return SkillSearchResult(
        name=title,
        description=description,
        source=source,
        install_source=install_source,
        skill_name=skill_name,
        skills_page_url=skills_page_url,
        github_repo_url=github_repo_url,
        install_count_text=install_count_text,
        why_useful=why_useful,
        install_command=install_command,
        quality=quality,
        raw_block=block.strip(),
    )


def _derive_quality(*, source: str, block: str, install_count_text: str | None = None) -> SkillResultQuality:
    labels: list[str] = []
    score = 0
    lowered = block.lower()
    trusted = False
    if source.startswith(("vercel-labs/", "anthropics/")) or "official" in lowered or "verified" in lowered:
        labels.append("trusted")
        score += 5
        trusted = True
    if "github.com" in lowered or "/" in source:
        labels.append("source-known")
        score += 2
    install_count = None
    count_source = install_count_text or block
    match = re.search(r"(\d+(?:\.\d+)?)\s*([km]?)\s+installs?", count_source, re.IGNORECASE)
    if match:
        value = float(match.group(1).replace(",", ""))
        suffix = match.group(2).lower()
        multiplier = 1000 if suffix == "k" else (1000000 if suffix == "m" else 1)
        install_count = int(value * multiplier)
        score += min(install_count // 1000, 5)
        labels.append((install_count_text or f"{install_count}+ installs").strip())
    if "popular" in lowered or "leaderboard" in lowered:
        labels.append("popular")
        score += 2
    return SkillResultQuality(score=score, labels=labels, install_count=install_count, trusted_source=trusted)


def _install_command_for(source: str, *, skill_name: str | None = None) -> list[str]:
    argv = ["npx", "skills", "add", source]
    if skill_name:
        argv.extend(["--skill", skill_name])
    argv.extend(["-g", "-y"])
    return argv


def _split_blocks(text: str) -> list[str]:
    blocks = [block.strip() for block in re.split(r"\n\s*\n", text) if block.strip()]
    if len(blocks) == 1 and len(text.splitlines()) > 4:
        return [line.strip() for line in text.splitlines() if line.strip()]
    return blocks


def _looks_like_heading(line: str) -> bool:
    lowered = line.lower()
    return lowered.startswith(("installed skills", "skills list", "checking", "updates", "found ", "using "))


def _looks_like_installed_guidance(line: str) -> bool:
    lowered = line.lower()
    return lowered.startswith(
        (
            "try listing global skills",
            "try listing project skills",
            "no global skills found",
            "no project skills found",
            "run `npx skills list",
            "use `npx skills list",
        )
    )


def _merge_cli_results(primary: CliCommandResult, secondary: CliCommandResult) -> CliCommandResult:
    stdout_parts = [part.strip() for part in (primary.stdout, secondary.stdout) if part.strip()]
    stderr_parts = [part.strip() for part in (primary.stderr, secondary.stderr) if part.strip()]
    ok = primary.ok or secondary.ok
    error_summary = None
    if not ok:
        error_summary = secondary.error_summary or primary.error_summary
    return CliCommandResult(
        argv=primary.argv,
        returncode=0 if ok else (secondary.returncode or primary.returncode),
        stdout="\n\n".join(stdout_parts),
        stderr="\n\n".join(stderr_parts),
        ok=ok,
        error_summary=error_summary,
    )


def _merge_installed_records(*record_sets: list[InstalledSkillRecord]) -> list[InstalledSkillRecord]:
    merged: dict[tuple[str, str | None, str | None], InstalledSkillRecord] = {}
    for records in record_sets:
        for record in records:
            key = (record.name.lower(), record.scope, record.source)
            existing = merged.get(key)
            if existing is None:
                merged[key] = InstalledSkillRecord(
                    name=record.name,
                    details=record.details,
                    scope=record.scope,
                    source=record.source,
                    agents=list(record.agents),
                    raw_line=record.raw_line,
                )
                continue
            existing.agents = sorted(set([*existing.agents, *record.agents]))
            if len(record.details) > len(existing.details):
                existing.details = record.details
            if existing.scope is None:
                existing.scope = record.scope
            if existing.source is None:
                existing.source = record.source
    return sorted(
        merged.values(),
        key=lambda item: (
            0 if item.scope == "project" else 1 if item.scope == "global" else 2,
            item.name.lower(),
        ),
    )


def _strip_ansi(text: str) -> str:
    return _ANSI_PATTERN.sub("", text)


def _quote_arg(part: str) -> str:
    if re.fullmatch(r"[A-Za-z0-9_./:@=-]+", part):
        return part
    return '"' + part.replace('"', '\\"') + '"'
