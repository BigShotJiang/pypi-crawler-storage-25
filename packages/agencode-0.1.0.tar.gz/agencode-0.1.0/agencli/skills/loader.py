﻿from __future__ import annotations

from pathlib import Path

from agencli.skills.manager import (
    SKILL_FILE_NAME,
    installed_skills_root,
    named_skill_source_root,
    skills_dir_has_legacy_layout,
)

_INSTALLED_ALIASES = {"*", "all", "installed", "local"}


def resolve_skill_sources(skills: list[str], skills_dir: str | Path) -> list[str]:
    base_dir = Path(skills_dir).expanduser().resolve()
    resolved: list[str] = []
    seen: set[str] = set()

    def add(source: str) -> None:
        if source not in seen:
            seen.add(source)
            resolved.append(source)

    for raw in skills:
        token = raw.strip()
        if not token:
            continue
        lowered = token.lower()
        if lowered in _INSTALLED_ALIASES:
            installed_root = installed_skills_root(base_dir)
            if installed_root.exists():
                add(installed_root.as_posix())
            if skills_dir_has_legacy_layout(base_dir):
                add(base_dir.as_posix())
            continue
        if _is_backend_virtual_source(token):
            add(_normalize_virtual_source(token))
            continue
        if not _looks_like_path(token):
            named_root = named_skill_source_root(base_dir) / token
            if named_root.exists():
                add(named_root.resolve().as_posix())
                continue
        add(_resolve_filesystem_source(token))

    return resolved


def _is_backend_virtual_source(value: str) -> bool:
    return value.startswith("/") and ":" not in value and "\\" not in value


def _looks_like_path(value: str) -> bool:
    return ":" in value or "\\" in value or "/" in value or value.startswith(".")


def _normalize_virtual_source(value: str) -> str:
    normalized = value.rstrip("/")
    return f"{normalized}/" if normalized else "/"


def _resolve_filesystem_source(value: str) -> str:
    path = Path(value).expanduser()
    if not path.exists():
        raise ValueError(
            f"Unknown skill source `{value}`. Use `installed`, an installed skill name, or a filesystem path."
        )

    resolved = path.resolve()
    if resolved.is_file():
        if resolved.name != SKILL_FILE_NAME:
            raise ValueError(f"Skill path `{value}` must point to a directory or `{SKILL_FILE_NAME}` file.")
        return resolved.parent.parent.as_posix()
    if (resolved / SKILL_FILE_NAME).exists():
        return resolved.parent.as_posix()
    return resolved.as_posix()
