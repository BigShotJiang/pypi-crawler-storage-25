﻿from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import shutil

import yaml

SKILL_FILE_NAME = "SKILL.md"
_INSTALLED_DIR_NAME = "installed"
_BY_NAME_DIR_NAME = "by-name"
_FRONTMATTER_PATTERN = re.compile(r"^---\s*\n(.*?)\n---\s*(?:\n|$)", re.DOTALL)


@dataclass(slots=True)
class InstalledSkill:
    name: str
    description: str
    path: Path
    allowed_tools: list[str] = field(default_factory=list)
    license: str | None = None
    compatibility: str | None = None


def install_skill(source: str | Path, skills_dir: str | Path, *, overwrite: bool = False) -> InstalledSkill:
    source_dir = _coerce_skill_directory(source)
    skill = read_skill(source_dir)
    base_dir = Path(skills_dir).expanduser().resolve()
    installed_dir = installed_skills_root(base_dir)
    named_dir = named_skill_source_root(base_dir)
    installed_dir.mkdir(parents=True, exist_ok=True)
    named_dir.mkdir(parents=True, exist_ok=True)

    canonical_target = installed_dir / skill.name
    named_target = named_dir / skill.name / skill.name
    _copy_skill_tree(source_dir, canonical_target, overwrite=overwrite)
    _copy_skill_tree(source_dir, named_target, overwrite=overwrite)
    return read_skill(canonical_target)


def list_installed_skills(skills_dir: str | Path) -> list[InstalledSkill]:
    base_dir = Path(skills_dir).expanduser().resolve()
    skills: dict[str, InstalledSkill] = {}
    for skill_dir in _iter_installed_skill_dirs(base_dir):
        skill = read_skill(skill_dir)
        skills[skill.name] = skill
    return [skills[name] for name in sorted(skills)]


def read_skill(path: str | Path) -> InstalledSkill:
    skill_dir = _coerce_skill_directory(path)
    skill_file = skill_dir / SKILL_FILE_NAME
    raw = skill_file.read_text(encoding="utf-8")
    metadata = _parse_frontmatter(raw, skill_file)

    name = str(metadata.get("name", "")).strip() or skill_dir.name
    description = str(metadata.get("description", "")).strip()
    if not description:
        raise ValueError(f"Skill `{skill_file}` is missing a description in YAML frontmatter.")

    raw_tools = metadata.get("allowed-tools") or metadata.get("allowed_tools") or ""
    if isinstance(raw_tools, str):
        allowed_tools = [tool.strip(",") for tool in raw_tools.split() if tool.strip(",")]
    elif isinstance(raw_tools, list):
        allowed_tools = [str(tool).strip() for tool in raw_tools if str(tool).strip()]
    else:
        allowed_tools = []

    return InstalledSkill(
        name=name,
        description=description,
        path=skill_dir.resolve(),
        allowed_tools=allowed_tools,
        license=str(metadata.get("license", "")).strip() or None,
        compatibility=str(metadata.get("compatibility", "")).strip() or None,
    )


def installed_skills_root(skills_dir: str | Path) -> Path:
    return Path(skills_dir).expanduser().resolve() / _INSTALLED_DIR_NAME


def named_skill_source_root(skills_dir: str | Path) -> Path:
    return Path(skills_dir).expanduser().resolve() / _BY_NAME_DIR_NAME


def skills_dir_has_legacy_layout(skills_dir: str | Path) -> bool:
    base_dir = Path(skills_dir).expanduser().resolve()
    if not base_dir.exists():
        return False
    for child in base_dir.iterdir():
        if not child.is_dir() or child.name in {_INSTALLED_DIR_NAME, _BY_NAME_DIR_NAME}:
            continue
        if (child / SKILL_FILE_NAME).exists():
            return True
    return False


def _iter_installed_skill_dirs(skills_dir: Path) -> list[Path]:
    skill_dirs: dict[str, Path] = {}

    installed_dir = installed_skills_root(skills_dir)
    if installed_dir.exists():
        for child in installed_dir.iterdir():
            if child.is_dir() and (child / SKILL_FILE_NAME).exists():
                skill_dirs[child.name] = child

    if skills_dir.exists():
        for child in skills_dir.iterdir():
            if not child.is_dir() or child.name in {_INSTALLED_DIR_NAME, _BY_NAME_DIR_NAME}:
                continue
            if (child / SKILL_FILE_NAME).exists():
                skill_dirs.setdefault(child.name, child)

    return list(skill_dirs.values())


def _coerce_skill_directory(path: str | Path) -> Path:
    candidate = Path(path).expanduser().resolve()
    if candidate.is_file():
        if candidate.name != SKILL_FILE_NAME:
            raise ValueError(f"Expected `{SKILL_FILE_NAME}` or a skill directory, got `{candidate}`.")
        candidate = candidate.parent
    if not candidate.is_dir():
        raise ValueError(f"Skill source `{candidate}` is not a directory.")
    if not (candidate / SKILL_FILE_NAME).exists():
        raise ValueError(f"Skill directory `{candidate}` does not contain `{SKILL_FILE_NAME}`.")
    return candidate


def _parse_frontmatter(content: str, skill_file: Path) -> dict:
    normalized = content.replace("\r\n", "\n")
    match = _FRONTMATTER_PATTERN.match(normalized)
    if not match:
        raise ValueError(f"Skill `{skill_file}` is missing YAML frontmatter.")
    loaded = yaml.safe_load(match.group(1))
    if not isinstance(loaded, dict):
        raise ValueError(f"Skill `{skill_file}` has invalid YAML frontmatter.")
    return loaded


def _copy_skill_tree(source_dir: Path, target_dir: Path, *, overwrite: bool) -> None:
    source_dir = source_dir.resolve()
    target_dir = target_dir.resolve()
    if source_dir == target_dir:
        return
    if target_dir.exists():
        if not overwrite:
            raise FileExistsError(f"Skill destination `{target_dir}` already exists.")
        shutil.rmtree(target_dir)
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_dir, target_dir)
