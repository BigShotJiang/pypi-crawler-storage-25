"""Core runtime primitives for AgenCLI."""
