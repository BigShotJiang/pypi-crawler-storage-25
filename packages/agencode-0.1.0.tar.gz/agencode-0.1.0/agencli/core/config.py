from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
import tomllib

import tomli_w

from agencli.core.keystore import OPENAI_COMPATIBLE_API_KEY, get_secret, set_secret
from agencli.core.paths import AgenCLIPaths, default_paths, ensure_dirs


@dataclass(slots=True)
class OpenAICompatibleConfig:
    provider_name: str = "openai-compatible"
    base_url: str = ""
    model: str = ""
    model_kind: str = "chat"
    api_key_env: str = "OPENAI_API_KEY"
    api_key_name: str = OPENAI_COMPATIBLE_API_KEY


def _infer_api_key_env(provider_name: str, base_url: str, configured_env: str | None = None) -> str:
    if configured_env:
        return configured_env

    lowered_provider = provider_name.lower()
    lowered_base_url = base_url.lower()
    if "deepseek" in lowered_provider or "deepseek" in lowered_base_url:
        return "DEEPSEEK_API_KEY"
    return "OPENAI_API_KEY"


@dataclass(slots=True)
class AgenCLIConfig:
    default_model: str = "openai:gpt-4.1"
    log_level: str = "INFO"
    workspace_dir: str = ""
    sessions_dir: str = ""
    agents_dir: str = ""
    skills_dir: str = ""
    mcp_config_path: str = ""
    shell_personality: str = "concise"
    approval_mode: str = "confirm"
    plan_mode: bool = False
    skills_last_query: str = ""
    skills_install_scope: str = "global"
    openai_compatible: OpenAICompatibleConfig = field(default_factory=OpenAICompatibleConfig)

    @classmethod
    def from_paths(cls, paths: AgenCLIPaths) -> "AgenCLIConfig":
        return cls(
            workspace_dir=str(paths.workspace_dir),
            sessions_dir=str(paths.sessions_dir),
            agents_dir=str(paths.agents_dir),
            skills_dir=str(paths.skills_dir),
            mcp_config_path=str(paths.mcp_file),
        )


def _from_legacy_config(raw: dict, paths: AgenCLIPaths) -> AgenCLIConfig:
    core = raw.get("core", {})
    providers = raw.get("providers", {})
    default_provider = core.get("default_provider", "openai")
    provider_model = providers.get(default_provider, {}).get("model", "")
    selected_provider = providers.get(default_provider, {})
    return AgenCLIConfig(
        default_model=core.get("default_model", provider_model or "openai:gpt-4.1"),
        log_level=core.get("log_level", "INFO"),
        workspace_dir=core.get("workspace_dir", str(paths.workspace_dir)),
        sessions_dir=core.get("session_dir", str(paths.sessions_dir)),
        agents_dir=raw.get("agents_dir", str(paths.agents_dir)),
        skills_dir=raw.get("skills_dir", str(paths.skills_dir)),
        mcp_config_path=raw.get("mcp_config_path", str(paths.mcp_file)),
        skills_last_query=raw.get("skills_last_query", ""),
        skills_install_scope=raw.get("skills_install_scope", "global"),
        openai_compatible=OpenAICompatibleConfig(
            provider_name=default_provider,
            base_url=selected_provider.get("base_url", ""),
            model=provider_model or core.get("default_model", ""),
            model_kind=selected_provider.get("model_kind", "chat"),
            api_key_env=_infer_api_key_env(
                default_provider,
                selected_provider.get("base_url", ""),
                selected_provider.get("api_key_env"),
            ),
        ),
    )


def _from_modern_config(raw: dict) -> AgenCLIConfig:
    openai_compatible_raw = raw.get("openai_compatible", {})
    return AgenCLIConfig(
        default_model=raw.get("default_model", "openai:gpt-4.1"),
        log_level=raw.get("log_level", "INFO"),
        workspace_dir=raw.get("workspace_dir", ""),
        sessions_dir=raw.get("sessions_dir", ""),
        agents_dir=raw.get("agents_dir", ""),
        skills_dir=raw.get("skills_dir", ""),
        mcp_config_path=raw.get("mcp_config_path", ""),
        skills_last_query=raw.get("skills_last_query", ""),
        skills_install_scope=raw.get("skills_install_scope", "global"),
        openai_compatible=OpenAICompatibleConfig(**openai_compatible_raw),
    )


def ensure_config(root: Path | None = None, overwrite: bool = False) -> Path:
    paths = ensure_dirs(default_paths(root))
    if paths.config_file.exists() and not overwrite:
        return paths.config_file

    config = AgenCLIConfig.from_paths(paths)
    paths.config_file.write_text(tomli_w.dumps(asdict(config)), encoding="utf-8")
    return paths.config_file


def load_config(config_path: Path | None = None) -> AgenCLIConfig:
    if config_path is None:
        config_path = ensure_config()

    with config_path.open("rb") as handle:
        raw = tomllib.load(handle)

    root = config_path.parent
    paths = ensure_dirs(default_paths(root))

    if "core" in raw or "providers" in raw:
        config = _from_legacy_config(raw, paths)
    else:
        config = _from_modern_config(raw)

    defaults = AgenCLIConfig.from_paths(paths)
    for field in ("workspace_dir", "sessions_dir", "agents_dir", "skills_dir", "mcp_config_path"):
        if not getattr(config, field):
            setattr(config, field, getattr(defaults, field))

    return config


def save_config(config: AgenCLIConfig, config_path: Path | None = None) -> Path:
    if config_path is None:
        config_path = ensure_config()
    config_path.write_text(tomli_w.dumps(asdict(config)), encoding="utf-8")
    return config_path


def set_openai_compatible_provider(
    *,
    config_path: Path | None = None,
    provider_name: str | None = None,
    base_url: str | None = None,
    model: str | None = None,
    model_kind: str | None = None,
    api_key: str | None = None,
    api_key_env: str | None = None,
    set_as_default: bool = True,
) -> AgenCLIConfig:
    config = load_config(config_path)
    provider = config.openai_compatible
    if provider_name is not None:
        provider.provider_name = provider_name
    if base_url is not None:
        provider.base_url = base_url
    if model is not None:
        provider.model = model
    if model_kind is not None:
        provider.model_kind = model_kind
    if api_key_env is not None:
        provider.api_key_env = api_key_env
    if set_as_default and provider.model:
        config.default_model = provider.model
    save_config(config, config_path)
    if api_key is not None:
        set_secret(provider.api_key_name, api_key)
    return config


def get_openai_compatible_api_key(config: AgenCLIConfig) -> str | None:
    return get_secret(config.openai_compatible.api_key_name)
