from __future__ import annotations

import keyring

SERVICE_NAME = "agencli"
OPENAI_COMPATIBLE_API_KEY = "openai_compatible_api_key"


def set_secret(name: str, value: str) -> None:
    keyring.set_password(SERVICE_NAME, name, value)


def get_secret(name: str) -> str | None:
    return keyring.get_password(SERVICE_NAME, name)
