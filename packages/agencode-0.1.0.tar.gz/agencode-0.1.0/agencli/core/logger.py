from __future__ import annotations

import logging


def configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    for noisy_logger in (
        "httpx",
        "httpcore",
        "openai",
        "langchain_openai",
    ):
        logging.getLogger(noisy_logger).setLevel(logging.WARNING)
