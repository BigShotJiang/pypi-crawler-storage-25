from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AgenCLIPaths:
    root: Path
    config_file: Path
    mcp_file: Path
    agents_dir: Path
    skills_dir: Path
    sessions_dir: Path
    workspace_dir: Path


def default_paths(root: Path | None = None) -> AgenCLIPaths:
    base = (root or (Path.home() / ".agencli")).expanduser()
    return AgenCLIPaths(
        root=base,
        config_file=base / "config.toml",
        mcp_file=base / "mcp.json",
        agents_dir=base / "agents",
        skills_dir=base / "skills",
        sessions_dir=base / "sessions",
        workspace_dir=base / "workspace",
    )


def ensure_dirs(paths: AgenCLIPaths) -> AgenCLIPaths:
    paths.root.mkdir(parents=True, exist_ok=True)
    paths.agents_dir.mkdir(parents=True, exist_ok=True)
    paths.skills_dir.mkdir(parents=True, exist_ok=True)
    paths.sessions_dir.mkdir(parents=True, exist_ok=True)
    paths.workspace_dir.mkdir(parents=True, exist_ok=True)
    return paths
