from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
import os
from pathlib import Path
import shutil
from typing import Any


@dataclass(slots=True)
class MCPServerConfig:
    transport: str
    command: str | None = None
    args: list[str] = field(default_factory=list)
    url: str | None = None
    env: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "MCPServerConfig":
        return cls(
            transport=raw["transport"],
            command=raw.get("command"),
            args=list(raw.get("args", [])),
            url=raw.get("url"),
            env=dict(raw.get("env", {})),
        )

    def to_client_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"transport": self.transport}
        if self.command:
            payload["command"] = _resolve_command(self.command)
        if self.args:
            payload["args"] = [_resolve_template(arg) for arg in self.args]
        if self.url:
            payload["url"] = _resolve_template(self.url)
        if self.env:
            payload["env"] = {name: _resolve_template(value) for name, value in self.env.items()}
        return payload


def _resolve_template(value: str) -> str:
    for key, env_value in os.environ.items():
        value = value.replace(f"{{{key}}}", env_value)
    return value


def _resolve_command(command: str) -> str:
    if os.name != "nt":
        return command
    if shutil.which(command):
        return command

    for suffix in (".cmd", ".exe", ".bat"):
        candidate = command if command.lower().endswith(suffix) else f"{command}{suffix}"
        if shutil.which(candidate):
            return candidate
    return command


def load_mcp_servers(mcp_config_path: str) -> dict[str, MCPServerConfig]:
    path = Path(mcp_config_path).expanduser()
    if not path.exists():
        return {}

    raw = json.loads(path.read_text(encoding="utf-8"))
    if "mcpServers" in raw:
        raw = raw["mcpServers"]
    return {name: MCPServerConfig.from_dict(server) for name, server in raw.items()}


def save_mcp_servers(mcp_config_path: str, servers: dict[str, MCPServerConfig]) -> Path:
    path = Path(mcp_config_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"mcpServers": {name: asdict(server) for name, server in servers.items()}}
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def upsert_mcp_server(mcp_config_path: str, name: str, server: MCPServerConfig) -> Path:
    servers = load_mcp_servers(mcp_config_path)
    servers[name] = server
    return save_mcp_servers(mcp_config_path, servers)


def default_mcp_servers(workspace_dir: str) -> dict[str, MCPServerConfig]:
    return {
        "search": MCPServerConfig(
            transport="http",
            url="https://mcp.tavily.com/mcp/?tavilyApiKey={TAVILY_API_KEY}",
        ),
    }


def bootstrap_default_mcp_servers(mcp_config_path: str, workspace_dir: str) -> Path:
    servers = load_mcp_servers(mcp_config_path)
    for name, server in default_mcp_servers(workspace_dir).items():
        servers.setdefault(name, server)
    return save_mcp_servers(mcp_config_path, servers)
