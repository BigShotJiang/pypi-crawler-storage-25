"""MCP configuration and client helpers."""
