from __future__ import annotations

from typing import Any

from agencli.mcp.config import load_mcp_servers


class MCPToolClient:
    """Thin wrapper around MultiServerMCPClient for AgenCLI."""

    def __init__(self, mcp_config_path: str) -> None:
        self.mcp_config_path = mcp_config_path

    def load_server_map(self) -> dict[str, dict[str, Any]]:
        servers = load_mcp_servers(self.mcp_config_path)
        return {name: server.to_client_dict() for name, server in servers.items()}

    async def get_tools(self, server_names: list[str] | None = None) -> list[Any]:
        try:
            from langchain_mcp_adapters.client import MultiServerMCPClient
        except ImportError as exc:
            raise RuntimeError(
                "langchain-mcp-adapters is not installed yet. Run `uv sync` after dependencies are added."
            ) from exc

        server_map = self.load_server_map()
        if server_names is not None:
            server_map = {name: server_map[name] for name in server_names if name in server_map}
        if not server_map:
            return []

        client = MultiServerMCPClient(server_map)
        return await client.get_tools()
