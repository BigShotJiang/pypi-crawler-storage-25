"""Tool loaders and local tool definitions for AgenCLI."""
