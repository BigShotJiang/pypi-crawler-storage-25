from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
import logging
import shutil
from typing import Any

from agencli.mcp.client import MCPToolClient

logger = logging.getLogger(__name__)


async def load_mcp_tools_async(
    mcp_config_path: str,
    server_names: list[str] | None = None,
    *,
    diagnostics: list[str] | None = None,
) -> list[Any]:
    client = MCPToolClient(mcp_config_path)
    server_map = client.load_server_map()
    requested_servers = server_names or list(server_map)
    if not requested_servers:
        return []

    resolved_tools: list[Any] = []
    for server_name in requested_servers:
        if server_name not in server_map:
            continue
        try:
            resolved_tools.extend(await client.get_tools(server_names=[server_name]))
        except Exception as exc:
            message = _format_mcp_error(server_name, server_map[server_name], exc)
            if diagnostics is not None:
                if message not in diagnostics:
                    diagnostics.append(message)
            else:
                logger.warning(message)
    return resolved_tools


def _run_tool_request(client: MCPToolClient, server_names: list[str] | None = None) -> list[Any]:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(client.get_tools(server_names=server_names))

    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(asyncio.run, client.get_tools(server_names=server_names))
        return future.result()


def _format_mcp_error(server_name: str, server_config: dict[str, Any], exc: Exception) -> str:
    command = server_config.get("command") or ""
    if command.lower().startswith("npx") and shutil.which(command) is None and shutil.which(f"{command}.cmd") is None:
        return (
            f"Skipping MCP server `{server_name}` because `{command}` is not available. "
            "Install Node.js/npm or update the MCP config."
        )
    if command.lower().startswith("npx") and isinstance(exc, OSError) and getattr(exc, "errno", None) == 9:
        return (
            f"Skipping MCP server `{server_name}` because Windows could not open `{command}` cleanly. "
            "Install or repair Node.js/npm, or update the MCP config."
        )
    if isinstance(exc, FileNotFoundError):
        if command.lower().startswith("npx"):
            return (
                f"Skipping MCP server `{server_name}` because `{command}` is not available. "
                "Install Node.js/npm or update the MCP config."
            )
        if command:
            return f"Skipping MCP server `{server_name}` because command `{command}` was not found."
    return f"Skipping MCP server `{server_name}` because it could not start: {exc}"


def load_mcp_tools(
    mcp_config_path: str,
    server_names: list[str] | None = None,
    *,
    diagnostics: list[str] | None = None,
) -> list[Any]:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(load_mcp_tools_async(mcp_config_path, server_names=server_names, diagnostics=diagnostics))

    client = MCPToolClient(mcp_config_path)
    server_map = client.load_server_map()
    requested_servers = server_names or list(server_map)
    if not requested_servers:
        return []

    resolved_tools: list[Any] = []
    for server_name in requested_servers:
        if server_name not in server_map:
            continue
        try:
            resolved_tools.extend(_run_tool_request(client, server_names=[server_name]))
        except Exception as exc:
            message = _format_mcp_error(server_name, server_map[server_name], exc)
            if diagnostics is not None:
                if message not in diagnostics:
                    diagnostics.append(message)
            else:
                logger.warning(message)
    return resolved_tools
