from __future__ import annotations

from dataclasses import dataclass
import copy
import json
import os
from typing import Any

from agencli.core.config import AgenCLIConfig, get_openai_compatible_api_key


@dataclass(frozen=True, slots=True)
class ModelProfile:
    id: str
    label: str
    provider: str


DEFAULT_MODELS = [
    ModelProfile(id="openai:gpt-4.1", label="GPT-4.1", provider="openai"),
    ModelProfile(id="anthropic:claude-sonnet-4-5", label="Claude Sonnet 4.5", provider="anthropic"),
]


def list_models() -> list[ModelProfile]:
    return DEFAULT_MODELS.copy()


def _candidate_api_key_envs(config: AgenCLIConfig) -> list[str]:
    provider = config.openai_compatible
    candidates = [provider.api_key_env]
    provider_name = provider.provider_name.lower()
    base_url = provider.base_url.lower()
    model_name = provider.model.lower()

    if any("deepseek" in value for value in (provider_name, base_url, model_name)):
        candidates.append("DEEPSEEK_API_KEY")
    if "openai" not in candidates:
        candidates.append("OPENAI_API_KEY")

    seen: set[str] = set()
    ordered: list[str] = []
    for item in candidates:
        if item and item not in seen:
            seen.add(item)
            ordered.append(item)
    return ordered


def describe_api_key_source(config: AgenCLIConfig) -> str:
    env_names = _candidate_api_key_envs(config)
    for name in env_names:
        if os.getenv(name):
            return f"environment:{name}"
    if get_openai_compatible_api_key(config):
        return "keyring"
    return f"missing ({', '.join(env_names)})"


def normalize_model_input(value: Any) -> Any:
    if isinstance(value, dict):
        normalized = {key: normalize_model_input(item) for key, item in value.items()}
        if "content" in normalized:
            normalized["content"] = _normalize_message_content(normalized["content"])
        return normalized
    if isinstance(value, list):
        return [normalize_model_input(item) for item in value]
    if isinstance(value, tuple):
        if len(value) == 2 and isinstance(value[0], str):
            return (value[0], _normalize_message_content(value[1]))
        return tuple(normalize_model_input(item) for item in value)

    content = getattr(value, "content", None)
    if content is None:
        return value

    normalized_content = _normalize_message_content(content)
    if normalized_content == content:
        return value
    if hasattr(value, "model_copy"):
        return value.model_copy(update={"content": normalized_content})
    if hasattr(value, "copy"):
        try:
            return value.copy(update={"content": normalized_content})
        except TypeError:
            pass
    cloned = copy.copy(value)
    setattr(cloned, "content", normalized_content)
    return cloned


def _normalize_message_content(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            text = _extract_content_text(item)
            if text:
                parts.append(text)
        return "\n".join(parts).strip()
    if isinstance(content, dict):
        text = _extract_content_text(content)
        if text:
            return text
        try:
            return json.dumps(content, ensure_ascii=True, sort_keys=True)
        except TypeError:
            return str(content).strip()
    return str(content).strip()


def _extract_content_text(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts = [_extract_content_text(item) for item in value]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(value, dict):
        if isinstance(value.get("text"), str):
            return value["text"].strip()
        if "content" in value:
            return _extract_content_text(value["content"])
        if isinstance(value.get("input"), str):
            return value["input"].strip()
        if isinstance(value.get("output"), str):
            return value["output"].strip()
    return ""


def init_model(config: AgenCLIConfig, model_name: str | None = None):
    provider = config.openai_compatible
    tried_envs = _candidate_api_key_envs(config)
    api_key = next((os.getenv(name) for name in tried_envs if os.getenv(name)), None) or get_openai_compatible_api_key(config)
    resolved_model = model_name or provider.model or config.default_model
    if provider.base_url and provider.model:
        try:
            from langchain_openai import ChatOpenAI
        except ImportError as exc:
            raise RuntimeError(
                "langchain-openai is not installed yet. Run `uv sync` after dependencies are added."
            ) from exc

        class AgenChatOpenAI(ChatOpenAI):
            def invoke(self, input: Any, config: Any | None = None, **kwargs: Any) -> Any:
                return super().invoke(normalize_model_input(input), config=config, **kwargs)

            async def ainvoke(self, input: Any, config: Any | None = None, **kwargs: Any) -> Any:
                return await super().ainvoke(normalize_model_input(input), config=config, **kwargs)

            def stream(self, input: Any, config: Any | None = None, **kwargs: Any):
                return super().stream(normalize_model_input(input), config=config, **kwargs)

            async def astream(self, input: Any, config: Any | None = None, **kwargs: Any):
                async for chunk in super().astream(normalize_model_input(input), config=config, **kwargs):
                    yield chunk

        if not api_key:
            raise RuntimeError(
                f"Missing API key for provider `{provider.provider_name}`. "
                f"Set one of {', '.join(tried_envs)} or store it with `agencode config-openai --api-key ...`."
            )

        if ":" in resolved_model:
            resolved_model = resolved_model.split(":", 1)[1]

        return AgenChatOpenAI(
            model=resolved_model,
            base_url=provider.base_url,
            api_key=api_key,
        )

    try:
        from langchain.chat_models import init_chat_model
    except ImportError as exc:
        raise RuntimeError(
            "langchain is not installed yet. Run `uv sync` after dependencies are added."
        ) from exc

    return init_chat_model(resolved_model)
