# AgenCLI

AgenCLI is the Python reboot of the original agent CLI concept: a multi-agent terminal workspace with a Textual UI and a DeepAgents/LangGraph runtime.

This repo is now scaffolded as a proper `uv` project with:

- a package entrypoint at `agencode`
- `agencode tui` uses the current directory as the workspace by default
- a Typer CLI
- a minimal Textual app
- config and session directory bootstrapping
- basic agent registry and runtime stubs for the later DeepAgents integration
- CLI support for OpenAI-compatible `base_url`, `api_key`, `model`, and `model_kind`

## Run

```bash
uv sync
uv run agencode doctor
uv run agencode config-openai --base-url https://api.deepseek.com --model deepseek-chat --model-kind chat
uv run agencode tui

# Open a specific workspace explicitly
uv run agencode tui --workspace /path/to/project
```
