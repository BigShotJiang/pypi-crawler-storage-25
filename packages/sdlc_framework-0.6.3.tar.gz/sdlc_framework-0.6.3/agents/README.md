# SDLC Agent Roster

> "1 prompt to rule them all" không scale. Mỗi vai trò trong SDLC cần persona, kiến thức và tool set riêng.

## Hierarchy

```
                     ┌──────────────────┐
                     │   ORCHESTRATOR   │  reads state.json, chooses next agent
                     └────────┬─────────┘
                              │
        ┌────────────┬────────┼────────┬────────────┐
        ▼            ▼        ▼        ▼            ▼
   ┌────────┐  ┌─────────┐ ┌─────┐ ┌──────┐  ┌──────────┐
   │ PHASE 1│  │ PHASE 2 │ │ P 3 │ │ P 4  │  │   GATE   │
   │   PM   │  │Architect│ │ Dev │ │ SRE  │  │  (human) │
   └────┬───┘  └────┬────┘ └──┬──┘ └──┬───┘  └──────────┘
        │           │         │       │
        ▼           ▼         ▼       ▼
   ┌────────────────────────────────────────┐
   │  CROSS-CUTTING (called whenever needed)│
   │  • security-reviewer                   │
   │  • test-author                         │
   │  • doc-keeper                          │
   │  • clarification-triager               │
   └────────────────────────────────────────┘
```

## Agent catalog

### Orchestrator
| Agent | File | Trigger |
|---|---|---|
| **orchestrator** | `orchestrator.md` | Mọi turn — đọc state, gọi tiếp |

### Phase specialists (1 cho mỗi phase)
| Agent | File | Phase | Persona | Tools cần |
|---|---|---|---|---|
| **pm-agent** | `phase-1-pm.md` | 1 | Senior PM/BA | Read, Write, Edit, Glob |
| **architect-agent** | `phase-2-architect.md` | 2 | Staff/Principal Eng | Read, Write, Edit, Glob, Bash (mermaid, openapi lint) |
| **developer-agent** | `phase-3-developer.md` | 3 | Senior SWE | Read, Write, Edit, Bash (run tests/lint), Grep |
| **sre-agent** | `phase-4-sre.md` | 4 | SRE/DevOps Lead | Read, Write, Edit, Bash (CI, perf tests) |

### Cross-cutting (invoked from any phase)
| Agent | File | When to invoke |
|---|---|---|
| **security-reviewer** | `cross/security-reviewer.md` | Bất kỳ lúc nào touch auth/crypto/payment/PII/iam/secrets |
| **test-author** | `cross/test-author.md` | Khi DoD yêu cầu test mà chưa có |
| **doc-keeper** | `cross/doc-keeper.md` | Sau mỗi commit — update README/ADR/changelog |
| **clarification-triager** | `cross/clarification-triager.md` | Khi orchestrator detect ambiguity, chưa rõ tạo file thế nào |

## Hand-off protocol

1. **Caller** chuẩn bị **brief** (xem `_brief-template.md`):
   - Mục tiêu cụ thể
   - File/state liên quan
   - Constraints
   - Definition of "done" cho turn này
2. **Callee** đọc brief + state.json + relevant files
3. **Callee** trả về **report**:
   - Files changed
   - Evidence ngắn gọn (path + lý do)
   - Open questions (nếu có)
   - Next agent suggested
4. Caller verify (chạy `sdlc_engine.py`) trước khi tiếp tục

## Mapping sang từng AI tool

| Tool | Cách invoke specialist |
|---|---|
| **Claude Code** | Subagent files trong `.claude/agents/` (auto-detected); gọi qua Task tool |
| **Claude Desktop / API** | Copy paste prompt từ `agents/<name>.md` làm system prompt |
| **Cursor** | Mention file trong chat: `@agents/phase-1-pm.md` (Cursor đọc file vào context) |
| **Codex CLI** | `codex --instructions agents/<name>.md ...` hoặc reference trong AGENTS.md |
| **Aider** | `/load agents/<name>.md` hoặc add vào `read:` config khi cần |
| **OpenAI Agent SDK** | Mỗi file = 1 Agent definition (system prompt + tools) |

## Quick start

```bash
# Xem agent nào nên gọi tiếp
python3 scripts/sdlc-dispatch.py

# Output ví dụ:
# → Next: pm-agent
#   Reason: Phase 1 has 1 pending item: stakeholder-raci
#   Brief: agents/_briefs/2026-04-30-pm-stakeholder.md (auto-generated)
#   Invoke (Claude Code): /agent pm-agent
#   Invoke (Cursor): paste agents/phase-1-pm.md as system, then send brief
```

## Anti-patterns

- ❌ Gộp tất cả vào 1 prompt khổng lồ — context dilution, output quality giảm
- ❌ Để orchestrator code thay vì gọi developer-agent — mất specialization
- ❌ Skip security-reviewer cho code "nhỏ" — security incidents thường từ "1-line bugs"
- ❌ Agent tự ký gate — luôn human-only
- ❌ 2 agents edit cùng 1 file song song — orchestrator phải sequence
