<!-- AUTO-GENERATED FROM ai-tools/shared-prompts/. DO NOT EDIT DIRECTLY. -->
<!-- To change: edit _header-aider.md or standards.md, then run scripts/build-ai-configs.sh -->

<!-- Tool: Aider. Output path: CONVENTIONS.md (also referenced by .aider.conf.yml) -->
# Aider conventions

> Loaded as a `read` file. Tells Aider how to behave in this project.

## Identity
You are an expert engineer in this repo. Treat it as production code.

## SDLC compliance
This repo follows the SDLC under `01-Planning/`..`04-Testing-Deploy/`. Always follow standards in `03-Development/standards/`.

## Style
- Match the file you're editing.
- Diffs only — no rewriting unrelated code.
- One concern per commit.

## Commit message format
Conventional Commits:
```
feat(scope): subject

Body — what & why.

Refs PROJ-123.
Co-authored-by: Aider <noreply@aider.chat>
```

## Test policy
- For each functional change, add or update tests.
- If a test would be hard to write, surface that instead of skipping.

## When uncertain
Ask a clarifying question. Don't guess.

## Disclosure
On `git commit`, append `AI-Tools-Used: aider` trailer. PR description must mention Aider in the AI disclosure block.

<!-- standards.md — shared body included into every AI tool config. -->
<!-- Source of truth. Edit this file (and per-tool _header-*.md) only. -->

## ⚡ Subagent priority — read this first

This repo has Claude Code subagents in `.claude/agents/` (`pm-agent.md`,
`architect-agent.md`, `developer-agent.md`, `sre-agent.md`, plus 4 cross-cutting
roles + an orchestrator). They are explicit, named, opt-in.

**When the user says "use the X subagent ..." or "/agents X", you MUST
honour the subagent and not delegate to plugin skills (e.g. brainstorming,
test-author, etc.).** The subagent files in `.claude/agents/` are this
repo's authoritative role specs.

If you have a plugin skill whose description overlaps with what the user
asked (idea → spec, idea → design, plan, etc.), **defer to the named
subagent**. The user picked it deliberately.

## ⚡ Default behaviour when the user shares a project idea

If the user's first substantive message in this repo describes a **project
idea / requirement / what they want to build** (phrases like "tôi muốn build",
"I want to build", "let's start a project", "create an app for X", "yêu cầu
là...", "tôi cần một app...", "start a new project", or simply pasting an
idea/brief without explicit instructions) — and `automation/state.json`
shows `prd-exists` is **NOT done** — then **automatically** do the following
without asking permission:

1. Adopt the **`pm-agent`** role (read `agents/phase-1-pm.md` for full role spec).
2. Read `01-Planning/templates/01-PRD.md` to know the structure.
3. Read `automation/rules.json` → find item `prd-exists` → know what evidence is required.
4. If the user's idea fits in `01-Planning/IDEA.md`, write it there first as raw input.
5. Write the actual filled-in PRD to **`01-Planning/01-PRD.md`** (NOT into `templates/`),
   replacing all `{{PLACEHOLDERS}}`. Quantify NFRs (p95 / p99 / RTO / RPO / uptime%).
   Leave a maximum of 5 placeholders for genuinely unknown values, marked with
   `{{TBD: <reason>}}`.
6. Briefly tell the user what you wrote, where, and what's next:
   `sdlc scan --print` to verify, then `sdlc dispatch` for the next step.
7. **Stop**. Do not auto-progress to user stories / requirements / design unless
   the user explicitly asks. Phase 1 has more items (`user-stories-with-ac`,
   `nfr-quantified`, `stakeholder-raci`, `risks-mitigated`); the user picks pace.

**STOP triggers** (write `automation/clarifications/<NNN>-...md` with
`STATUS: open` and halt) — apply during step 5 if you encounter:
- 🔍 Ambiguity: idea too vague to fill required PRD sections.
- ⚔️ Conflict: user gave conflicting constraints.
- 🛑 High-risk path: idea touches auth/crypto/payment/secrets/migrations and
  needs explicit user direction before drafting.

**For subsequent items** (after `prd-exists` is done), follow the same pattern:
read `automation/state.json` → find first not-done item → pick the agent role
from `agents/<role>.md` matching that item's phase → read the relevant template
→ write the actual deliverable. Use `sdlc dispatch --json` to get a
machine-readable picker if needed.

---

## SDLC framework — what this repo expects

This repository follows a 4-phase SDLC. Every change should advance one of the
Definition of Done items tracked in `automation/state.json`. Run
`python3 automation/sdlc_engine.py --print` to see the current state.

### Phases (high-level)

1. **Planning** (`01-Planning/`) — PRD, user stories with Given/When/Then ACs,
   quantified NFRs, stakeholder map + RACI, risk register.
2. **Design** (`02-Design/`) — C4 architecture, API spec (OpenAPI when applicable),
   DB schema, UI/UX, ADRs, STRIDE threat model.
3. **Development** (`03-Development/`) — coding standards, git workflow, error
   handling, security checklist, PR template, code-review checklist.
4. **Testing & Deploy** (`04-Testing-Deploy/`) — test plan, CI/CD, deploy
   runbook, SLOs, incident response.

### Standards live in `03-Development/standards/`

- `coding-standards.md`
- `git-workflow.md`
- `error-handling.md`
- `security-checklist.md`

Read them before writing code in this repo.

### Project metadata: `project.yaml`

The repo MAY have a `project.yaml` at the root. When present, it pins:

- `tier` (1=critical, 2=standard, 3=experiment) — drives DoD strictness.
- `phase_target` (1..4) — phase the team is currently focused on.
- `owners` — sponsor, eng_lead, security, sre. Required keys depend on tier.
- `stack` — node | python | go.

The engine fails the `owners-defined` rule when required owners are missing.

### Autonomous loop rules

When operating without a human in the loop, follow `automation/AGENT-LOOP.md`.
Stop and write a clarification file under `automation/clarifications/` when:

- Information is ambiguous or missing.
- Two sources conflict.
- A gate (sign-off) is required.
- The task touches a high-risk path: auth, crypto, payment, IAM, secrets,
  database migrations, webhooks.

### AI disclosure

Every PR must include the AI tool disclosure section from
`03-Development/templates/PR-Template.md`. Do not omit it.

### Logging your run

When you start working on an SDLC item, append a `start` entry to the activity
log; when you finish (or fail), append `done` or `fail`. The wrapper handles
atomicity, duration, and retention.

```bash
# at the start of your task
SDLC_TOOL=<your-tool> scripts/agent-log.sh start <agent-name> <item-id>

# work...

# at the end
scripts/agent-log.sh done <agent-name> <item-id> --summary="<one-line>"
# or, on failure
scripts/agent-log.sh fail <agent-name> <item-id> --summary="<error>"
```

The log is local-only, gitignored, and capped at 50 entries. The dashboard
"Agent activity" panel renders from this file. Failing to call the wrapper
breaks nothing — the panel just shows fewer recent runs.

### Surfacing STOP triggers to GitHub

When you raise a clarification (`automation/clarifications/<NNN>-...md`) or
write a gate signoff placeholder (`automation/signoffs/<gate-id>.yaml`),
also run the gh wrapper so the issue is filed on GitHub:

```bash
scripts/gh-issue.sh --clarification automation/clarifications/<NNN>-...md
# or
scripts/gh-issue.sh --gate <gate-id>
```

Both wrappers are idempotent (skip on existing `issue_url:` field) and exit 0
when `gh` is unavailable, so they are safe to call unconditionally.

For phase-3 deliverables that touch code, open a draft PR with
`scripts/gh-pr.sh` once the branch is ready for review.
