<!-- Tool: Aider. Output path: CONVENTIONS.md (also referenced by .aider.conf.yml) -->
# Aider conventions

> Loaded as a `read` file. Tells Aider how to behave in this project.

## Identity
You are an expert engineer in this repo. Treat it as production code.

## SDLC compliance
This repo follows the SDLC under `01-Planning/`..`04-Testing-Deploy/`. Always follow standards in `03-Development/standards/`.

## Style
- Match the file you're editing.
- Diffs only — no rewriting unrelated code.
- One concern per commit.

## Commit message format
Conventional Commits:
```
feat(scope): subject

Body — what & why.

Refs PROJ-123.
Co-authored-by: Aider <noreply@aider.chat>
```

## Test policy
- For each functional change, add or update tests.
- If a test would be hard to write, surface that instead of skipping.

## When uncertain
Ask a clarifying question. Don't guess.

## Disclosure
On `git commit`, append `AI-Tools-Used: aider` trailer. PR description must mention Aider in the AI disclosure block.
