<!-- Tool: GitHub Copilot. Output path: .github/copilot-instructions.md -->
# Copilot custom instructions

> Symlinked / copied to `.github/copilot-instructions.md`.
> GitHub Copilot reads this for repo-wide context (Chat + inline suggestions).

## Project
{{PROJECT_NAME}} — see `CLAUDE.md` at root for full overview.

## Languages & frameworks
- TypeScript (Node 20) with NestJS for backend
- React 18 + Vite for frontend
- Python 3.12 + FastAPI for data services
- Go 1.22 for performance-critical microservices
- PostgreSQL 15, Redis 7

## Coding conventions Copilot must follow
- TS: `strict: true`, no `any`, prefer `unknown` + narrow.
- Errors: typed, RFC 7807 on the wire, see `03-Development/standards/error-handling.md`.
- Logs: structured JSON, never log secrets / PII.
- DB: parameterized queries only, snake_case columns.
- API: versioned `/v1/...`, OpenAPI as source of truth.
- Tests: same file as `*.spec.ts` colocated; AAA; ≥ 80% coverage on biz logic.

## Project structure shortcuts
- `src/modules/<domain>/...` — vertical slice per domain
- `src/lib/...` — pure utilities
- `tests/integration/...` — testcontainers-based
- `infra/...` — Terraform

## Patterns to prefer
- Constructor injection (NestJS), `@Injectable()`
- Pydantic models for FastAPI request/response
- Interface + impl split for ports/adapters
- Feature flags via `@growthbook/...` or in-house client

## When suggesting completions
- Prefer existing util in `src/lib/` over re-implementing.
- Reuse existing components in `src/components/` instead of new ones.
- Use the shared logger, never `console.log`.

## Forbidden
- New deps without `package.json` review
- Auth / crypto code without 2-human review (Copilot completion needs flagging)
- Disabling lint / type-check rules inline
