---
description: Save the user's project idea and immediately invoke the pm-agent subagent to draft the PRD.
argument-hint: "<your idea — e.g. mobile task app for 5-person team>"
---

# /sdlc-start

Begin a new SDLC project from the user's idea.

## Inputs

The user's idea is the entire argument string passed to this command (everything after `/sdlc-start`).

## What to do

1. **Persist the idea.** Run via Bash: `sdlc start "<the idea>"` — this writes `01-Planning/IDEA.md`.
2. **Invoke pm-agent.** Use the `pm-agent` subagent (read `.claude/agents/pm-agent.md`) and ask it to draft `01-Planning/01-PRD.md` from `01-Planning/IDEA.md`. Pass the idea explicitly. The pm-agent reads `01-Planning/templates/01-PRD.md` and `automation/rules.json` (item `prd-exists`) to know the structure and required evidence.
3. **Do not delegate to plugin skills** like `superpowers:brainstorming`. The user wants the SDLC PRD flow, not a generic spec. The pm-agent subagent is authoritative for this repo.
4. **Verify.** After the subagent finishes, run Bash: `sdlc scan --print | head -10` and report whether `prd-exists` flipped to ✓.
5. **Suggest next.** Tell the user: "Run `/sdlc-next` for the next pending DoD item."

## STOP triggers

If the idea is too vague to fill required PRD sections, **do not invent**. The pm-agent should write a clarification file under `automation/clarifications/` with `STATUS: open` and stop. Tell the user what info is missing.
