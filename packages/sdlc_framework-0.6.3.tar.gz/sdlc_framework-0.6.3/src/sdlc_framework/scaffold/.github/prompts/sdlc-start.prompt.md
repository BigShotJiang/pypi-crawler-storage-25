---
mode: agent
description: Start a new SDLC project from an idea — invoke pm-agent and draft the PRD.
---

The user wants to start a new SDLC project. Their idea is in the message they just sent (or in `01-Planning/IDEA.md` if they ran `sdlc start "..."` already).

## Steps

1. Adopt the **pm-agent** persona (read `agents/phase-1-pm.md`).
2. Read `01-Planning/templates/01-PRD.md` for the PRD structure.
3. Read `automation/rules.json` → item `prd-exists` → know what evidence is required.
4. Write `01-Planning/01-PRD.md` (NOT into `templates/`), filling placeholders from the user's idea. Quantify NFRs (p95/p99/RTO/RPO/uptime%).
5. Run the engine via the integrated terminal: `sdlc scan --print | head -10`. Report whether `prd-exists` flipped to ✓.
6. Tell the user: "Next: run `sdlc next` to pick up the next pending DoD item, or run `sdlc dashboard` for a live overview."

## STOP triggers

If the idea is too vague, write `automation/clarifications/<NNN>-<slug>.md` with `STATUS: open` and tell the user what's missing. Don't invent.
