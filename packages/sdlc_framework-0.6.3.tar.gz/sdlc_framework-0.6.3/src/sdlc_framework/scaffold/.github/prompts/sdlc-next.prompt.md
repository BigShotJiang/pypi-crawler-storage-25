---
mode: agent
description: Pick up the next pending SDLC DoD item and run the matching specialist agent.
---

The user wants to advance the SDLC pipeline.

## Steps

1. Run via integrated terminal: `sdlc next --json` and parse the JSON output. Fields: `phase`, `item_id`, `item_label`, `agent`, `role_file`.
2. If the action is "done", congratulate the user.
3. Otherwise, adopt the persona from `<role_file>` (e.g. `agents/phase-1-pm.md`).
4. Read `automation/rules.json` → find `<item_id>` → know what evidence is required.
5. Read the matching template under `01-Planning/templates/`, `02-Design/templates/`, `03-Development/standards/`, or `04-Testing-Deploy/templates/`.
6. Write the deliverable file (NOT into `templates/`).
7. Run `sdlc scan --print | head -10` and report whether the item flipped to ✓.
8. Tell the user to run this prompt again for the next item, or `sdlc dashboard` to view progress.

## STOP triggers

If the item is a gate, do NOT write a deliverable — tell the user the gate id and approvers, and that they must write `automation/signoffs/<id>.yaml` with `approved: true`.

If the item touches auth/crypto/payment/secrets/migrations, ask explicit confirmation before proceeding.
