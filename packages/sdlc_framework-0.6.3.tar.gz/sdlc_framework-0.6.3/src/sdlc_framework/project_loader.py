"""Load and validate the optional project.yaml metadata file.

The loader is permissive: missing file -> DEFAULTS with no errors.
Invalid fields -> field falls back to its default and an error string is
recorded so the engine can write a clarification file. The engine never
crashes on bad metadata.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

SUPPORTED_SCHEMA_VERSIONS = {1}
SUPPORTED_STACKS = {"node", "python", "go"}
VALID_TIERS = {1, 2, 3}
VALID_PHASES = {1, 2, 3, 4}

DEFAULTS: dict[str, Any] = {
    "schema_version": 1,
    "name": None,
    "team": None,
    "stack": None,
    "tier": 2,
    "phase_target": None,
    "repo_url": None,
    "owners": {},
    "flags": {
        "ai_disclosure_required": True,
        "signoffs_strict": "auto",
    },
    "custom_items": [],
}


def load_project(path: Path) -> tuple[dict[str, Any], list[str]]:
    """Load project metadata from `path`.

    Returns (project_dict, errors). `errors` is empty when the file is
    missing or fully valid. Invalid fields are reported but do not abort
    the load; the field falls back to its default value.
    """
    if not path.exists():
        return (_clone(DEFAULTS), [])

    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        return (_clone(DEFAULTS), [f"yaml parse error: {exc}"])

    if not isinstance(raw, dict):
        return (_clone(DEFAULTS), ["project.yaml top-level must be a mapping"])

    project = _clone(DEFAULTS)
    errors: list[str] = []

    schema_version = raw.get("schema_version", DEFAULTS["schema_version"])
    if schema_version not in SUPPORTED_SCHEMA_VERSIONS:
        errors.append(
            f"schema_version {schema_version!r} not supported "
            f"(supported: {sorted(SUPPORTED_SCHEMA_VERSIONS)})"
        )
    else:
        project["schema_version"] = schema_version

    for key in ("name", "team", "repo_url"):
        val = raw.get(key)
        if val is not None and not isinstance(val, str):
            errors.append(f"{key} must be a string, got {type(val).__name__}")
        else:
            project[key] = val

    stack = raw.get("stack")
    if stack is None:
        project["stack"] = None
    elif stack in SUPPORTED_STACKS:
        project["stack"] = stack
    else:
        errors.append(
            f"stack {stack!r} not supported (supported: {sorted(SUPPORTED_STACKS)})"
        )

    tier = raw.get("tier", DEFAULTS["tier"])
    if tier in VALID_TIERS:
        project["tier"] = tier
    else:
        errors.append(f"tier {tier!r} not in {sorted(VALID_TIERS)}; using default 2")

    phase_target = raw.get("phase_target")
    if phase_target is None:
        project["phase_target"] = None
    elif phase_target in VALID_PHASES:
        project["phase_target"] = phase_target
    else:
        errors.append(
            f"phase_target {phase_target!r} not in {sorted(VALID_PHASES)}"
        )

    owners = raw.get("owners")
    if owners is None:
        project["owners"] = {}
    elif isinstance(owners, dict):
        kept: dict[str, str] = {}
        dropped: list[str] = []
        for k, v in owners.items():
            if isinstance(v, str):
                kept[k] = v
            else:
                dropped.append(str(k))
        if dropped:
            errors.append(
                f"owners: keys {sorted(dropped)} have non-string values and were dropped"
            )
        project["owners"] = kept
    else:
        errors.append("owners must be a mapping of role -> email")

    flags = raw.get("flags")
    if flags is None:
        pass  # keep defaults
    elif isinstance(flags, dict):
        merged = dict(DEFAULTS["flags"])
        merged.update({k: v for k, v in flags.items()})
        project["flags"] = merged
    else:
        errors.append(f"flags must be a mapping, got {type(flags).__name__}")

    custom_items = raw.get("custom_items")
    if custom_items is None:
        project["custom_items"] = []
    elif isinstance(custom_items, list):
        valid: list[dict] = []
        for i, ci in enumerate(custom_items):
            if not isinstance(ci, dict):
                errors.append(f"custom_items[{i}] must be a mapping; skipped")
                continue
            cid = ci.get("id")
            label = ci.get("label") or cid
            phase = ci.get("phase", 3)
            checks = ci.get("checks") or []
            if not isinstance(cid, str) or not cid:
                errors.append(f"custom_items[{i}]: missing or non-string `id`; skipped")
                continue
            if phase not in VALID_PHASES:
                errors.append(f"custom_items[{cid}]: phase {phase!r} not in {sorted(VALID_PHASES)}; skipped")
                continue
            if not isinstance(checks, list) or not checks:
                errors.append(f"custom_items[{cid}]: `checks` must be a non-empty list; skipped")
                continue
            # TDD shortcut: tdd: true → auto-derive a tdd_pairing check from
            # the first file_glob_min_count check's glob (treat it as the code glob).
            if ci.get("tdd"):
                code_glob_default = None
                for c in checks:
                    if isinstance(c, dict) and c.get("type") == "file_glob_min_count":
                        code_glob_default = c.get("glob")
                        break
                code_glob = ci.get("code_glob") or code_glob_default
                test_glob = ci.get("test_glob")
                if not test_glob and code_glob:
                    # Heuristic: insert ".test" before the extension. e.g.
                    # src/auth/**/*.ts → src/auth/**/*.test.ts
                    if "*." in code_glob:
                        test_glob = code_glob.replace("*.", "*.test.", 1)
                if not code_glob or not test_glob:
                    errors.append(f"custom_items[{cid}]: tdd=true requires code_glob "
                                  f"+ test_glob (or a file_glob_min_count check to derive code_glob from)")
                else:
                    checks = list(checks) + [{
                        "type": "tdd_pairing",
                        "code_glob": code_glob,
                        "test_glob": test_glob,
                        "min_ratio": ci.get("min_ratio", 1.0),
                    }]

            valid.append({
                "id": cid,
                "label": str(label),
                "phase": phase,
                "checks": checks,
            })
        project["custom_items"] = valid
    else:
        errors.append("custom_items must be a list of {id, label, phase, checks} mappings")

    return (project, errors)


def _clone(d: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in d.items():
        out[k] = dict(v) if isinstance(v, dict) else v
    return out
