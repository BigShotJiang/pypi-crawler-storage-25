"""sdlc — CLI entry point."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from importlib import resources
from pathlib import Path

from sdlc_framework import __version__


def _cmd_scan(argv: list[str]) -> int:
    from sdlc_framework import engine
    parser = argparse.ArgumentParser(prog="sdlc scan")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval", type=float, default=3.0)
    parser.add_argument("--print", dest="print_summary", action="store_true")
    parser.add_argument("--root", type=Path, default=None)
    args = parser.parse_args(argv)

    engine.set_root(args.root or Path(os.environ.get("SDLC_LOG_ROOT") or os.getcwd()))
    sys_argv = ["engine"]
    if args.watch: sys_argv.append("--watch")
    if args.print_summary: sys_argv.append("--print")
    sys_argv += ["--interval", str(args.interval)]
    # The engine.main() reads sys.argv; replace temporarily.
    saved = sys.argv
    try:
        sys.argv = sys_argv
        return engine.main()
    finally:
        sys.argv = saved


def _cmd_dispatch(argv: list[str]) -> int:
    from sdlc_framework import dispatcher
    return dispatcher.main(argv)


COMMANDS = {
    "scan": _cmd_scan,
    "dispatch": _cmd_dispatch,
}


def _run_bundled_script(script_name: str, args: list[str]) -> int:
    """Locate a bundled bash script and exec it with args; cwd = user's project.

    Sets SDLC_LOG_ROOT=$PWD so the bash scripts (which otherwise resolve ROOT
    relative to the script's own location) operate against the user's repo
    instead of the installed package directory.
    """
    pkg_files = resources.files("sdlc_framework").joinpath("scripts")
    script_path = pkg_files / script_name
    # importlib.resources may return a MultiplexedPath / Traversable; convert
    # to a real filesystem path via as_file().
    with resources.as_file(script_path) as real_path:
        env = os.environ.copy()
        env.setdefault("SDLC_LOG_ROOT", os.getcwd())
        cmd = ["bash", str(real_path), *args]
        return subprocess.run(cmd, env=env).returncode


def _cmd_agent_log(argv: list[str]) -> int:
    return _run_bundled_script("agent-log.sh", argv)


def _cmd_notify(argv: list[str]) -> int:
    return _run_bundled_script("notify.sh", argv)


def _cmd_gh_issue(argv: list[str]) -> int:
    return _run_bundled_script("gh-issue.sh", argv)


def _cmd_gh_pr(argv: list[str]) -> int:
    return _run_bundled_script("gh-pr.sh", argv)


def _cmd_build_ai_configs(argv: list[str]) -> int:
    return _run_bundled_script("build-ai-configs.sh", argv)


_STACK_DETECTORS: list[tuple[str, str]] = [
    ("node", "package.json"),
    ("python", "pyproject.toml"),
    ("python", "requirements.txt"),
    ("python", "setup.py"),
    ("go", "go.mod"),
]


# Per-tool artifacts: (tool name, list of (relative-source, relative-dest, optional dir-only))
# dest is relative to project root; source is relative to the bundled scaffold/ tree.
_TOOL_ARTIFACTS: dict[str, list[tuple[str, str]]] = {
    "claude-code": [
        # Subagents (already in scaffold/.claude/agents/) + slash commands + skill
        (".claude/agents", ".claude/agents"),
        (".claude/commands", ".claude/commands"),
        (".claude/skills", ".claude/skills"),
    ],
    "cursor": [
        (".cursor/rules", ".cursor/rules"),
    ],
    "copilot": [
        (".github/prompts", ".github/prompts"),
    ],
    # Codex/Aider/Continue/Cline/Windsurf use the generic ai-tools/<tool>/ files
    # already produced by build-ai-configs.sh. They don't have native slash-command
    # surfaces, so users invoke the `sdlc` CLI from a built-in terminal.
    "codex": [],
    "aider": [],
    "continue": [],
    "cline": [],
    "windsurf": [],
}

_TOOL_DISPLAY = {
    "claude-code": "Claude Code (slash commands + subagents + skill)",
    "cursor": "Cursor (rules)",
    "copilot": "GitHub Copilot Chat (prompt files)",
    "codex": "OpenAI Codex (text rules — uses sdlc CLI from terminal)",
    "aider": "Aider (CONVENTIONS.md — uses sdlc CLI from terminal)",
    "continue": "Continue (text rules — uses sdlc CLI from terminal)",
    "cline": "Cline (text rules — uses sdlc CLI from terminal)",
    "windsurf": "Windsurf (text rules — uses sdlc CLI from terminal)",
}


def _detect_stack(target: Path) -> tuple[str | None, str | None]:
    """Return (stack, evidence_file) or (None, None) when no signal."""
    for stack, marker in _STACK_DETECTORS:
        if (target / marker).exists():
            return (stack, marker)
    return (None, None)


def _detect_tools(target: Path) -> list[str]:
    """Best-effort: which AI tools is the user already using here?"""
    found: list[str] = []
    if (target / ".claude" / "agents").exists() or (target / "CLAUDE.md").exists():
        found.append("claude-code")
    if (target / ".cursor").exists() or (target / ".cursorrules").exists():
        found.append("cursor")
    if (target / ".github" / "copilot-instructions.md").exists():
        found.append("copilot")
    if (target / "AGENTS.md").exists():
        found.append("codex")
    if (target / ".aider.conf.yml").exists() or (target / "CONVENTIONS.md").exists():
        found.append("aider")
    if (target / ".continue").exists() or (target / ".continuerules").exists():
        found.append("continue")
    if (target / ".clinerules").exists():
        found.append("cline")
    if (target / ".windsurfrules").exists():
        found.append("windsurf")
    return found


def _copy_tool_artifacts(tool: str, scaffold_root: Path, target: Path, force: bool) -> tuple[int, int]:
    """Copy a tool's artifacts from scaffold to target. Returns (copied, skipped)."""
    copied = 0
    skipped = 0
    for src_rel, dst_rel in _TOOL_ARTIFACTS.get(tool, []):
        src_root = scaffold_root / src_rel
        if not src_root.exists():
            continue
        for src_path in src_root.rglob("*"):
            if src_path.is_dir():
                continue
            rel = src_path.relative_to(src_root)
            dest_path = target / dst_rel / rel
            if dest_path.exists() and not force:
                skipped += 1
                continue
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(src_path.read_bytes())
            if os.access(src_path, os.X_OK):
                os.chmod(dest_path, 0o755)
            copied += 1
    return copied, skipped


def _cmd_setup(argv: list[str]) -> int:
    """Interactive setup: scaffold + pick AI tools to install native artifacts for."""
    parser = argparse.ArgumentParser(prog="sdlc setup")
    parser.add_argument("--tools", default=None,
                        help="Comma-separated tool list (e.g. claude-code,cursor). "
                             "Skip the interactive prompt.")
    parser.add_argument("--stack", choices=["node", "python", "go"], default=None,
                        help="Override auto-detected stack.")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing files.")
    args = parser.parse_args(argv)

    target = Path.cwd()

    # Step 1: scaffold (delegates to _cmd_init).
    init_argv: list[str] = []
    if args.stack:
        init_argv.append(f"--stack={args.stack}")
    if args.force:
        init_argv.append("--force")
    print("[sdlc setup] step 1/2 — scaffolding base project")
    rc = _cmd_init(init_argv)
    if rc != 0:
        print("[sdlc setup] init failed; aborting setup")
        return rc

    # Step 2: pick AI tools.
    print()
    print("[sdlc setup] step 2/2 — selecting AI tools")
    if args.tools:
        chosen = [t.strip() for t in args.tools.split(",") if t.strip()]
    else:
        detected = _detect_tools(target)
        all_tools = list(_TOOL_ARTIFACTS.keys())
        print()
        print("Which AI coding tools do you use? (multi-select)")
        for i, tool in enumerate(all_tools, 1):
            mark = " [detected]" if tool in detected else ""
            print(f"  {i}. {tool} — {_TOOL_DISPLAY[tool]}{mark}")
        print()
        print("Enter numbers separated by space, or press Enter for detected only.")
        try:
            raw = input("> ").strip()
        except EOFError:
            raw = ""
        if not raw:
            chosen = detected if detected else ["claude-code"]
            print(f"[sdlc setup] using {'detected' if detected else 'default'}: {', '.join(chosen)}")
        else:
            try:
                indices = [int(x) for x in raw.split()]
                chosen = [all_tools[i - 1] for i in indices if 1 <= i <= len(all_tools)]
            except (ValueError, IndexError):
                print("[sdlc setup] invalid selection; aborting")
                return 2

    # Step 3: copy artifacts for each chosen tool.
    pkg_files = resources.files("sdlc_framework").joinpath("scaffold")
    with resources.as_file(pkg_files) as scaffold_root:
        for tool in chosen:
            if tool not in _TOOL_ARTIFACTS:
                print(f"[sdlc setup] unknown tool: {tool}; skipping")
                continue
            artifacts = _TOOL_ARTIFACTS[tool]
            if not artifacts:
                # Tool has no native artifacts beyond the generic ones written by sdlc init.
                print(f"[sdlc setup] {tool}: no native slash-command surface; "
                      f"use the `sdlc` CLI from your tool's terminal")
                continue
            copied, skipped = _copy_tool_artifacts(tool, scaffold_root, target, args.force)
            print(f"[sdlc setup] {tool}: {copied} files copied, {skipped} skipped")

    # Step 4: tell the user what to do next, per tool.
    print()
    print("[sdlc setup] done. Next steps:")
    if "claude-code" in chosen:
        print("  Claude Code: open this folder, then use:")
        print("    /sdlc-start \"<your idea>\"   to begin Phase 1")
        print("    /sdlc-next                  to advance to the next pending item")
        print("    /sdlc-scan                  to refresh progress")
        print("    /sdlc-dashboard             to open the dashboard")
    if "cursor" in chosen:
        print("  Cursor: rules in .cursor/rules/sdlc.mdc are auto-loaded.")
        print("    Share your idea — Cursor adopts the pm-agent persona.")
        print("    Or use the integrated terminal: `sdlc start \"<idea>\"`")
    if "copilot" in chosen:
        print("  GitHub Copilot Chat: prompt files at .github/prompts/sdlc-*.prompt.md")
        print("    Use them via the Copilot Chat 'prompts' UI, or run `sdlc start ...` from terminal.")
    text_tools = [t for t in chosen if t in {"codex", "aider", "continue", "cline", "windsurf"}]
    if text_tools:
        print(f"  {', '.join(text_tools)}: text rules already wired by `sdlc init`.")
        print(f"    From the tool's terminal: sdlc start \"<idea>\" / sdlc next / sdlc scan.")
    return 0


def _cmd_init(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="sdlc init")
    parser.add_argument("--stack", choices=["node", "python", "go"], default=None,
                        help="Override auto-detected stack. Auto-detect from package.json / pyproject.toml / go.mod when omitted.")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing files.")
    args = parser.parse_args(argv)

    target = Path.cwd()

    # Resolve stack: explicit flag wins, else auto-detect, else None (no CI wiring).
    stack: str | None = args.stack
    if stack:
        print(f"[sdlc init] stack={stack} (from --stack flag)")
    else:
        detected, evidence = _detect_stack(target)
        if detected:
            stack = detected
            print(f"[sdlc init] stack={stack} (auto-detected from {evidence})")
        else:
            print("[sdlc init] no stack auto-detected (no package.json / pyproject.toml / go.mod found)")
            print("[sdlc init] CI workflow will not be wired. Re-run with --stack=node|python|go to add one later.")

    pkg_files = resources.files("sdlc_framework").joinpath("scaffold")

    copied = 0
    skipped = 0
    with resources.as_file(pkg_files) as real_root:
        for src_path in real_root.rglob("*"):
            if src_path.is_dir():
                continue
            rel = src_path.relative_to(real_root)
            dest_path = target / rel
            if dest_path.exists() and not args.force:
                skipped += 1
                continue
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(src_path.read_bytes())
            # preserve executable bit (best effort)
            if os.access(src_path, os.X_OK):
                os.chmod(dest_path, 0o755)
            copied += 1

    print(f"[sdlc init] copied {copied} files, skipped {skipped} existing")
    if copied == 0 and not args.force:
        print("[sdlc init] this looks like an already-initialized project — re-run with --force to overwrite, or `sdlc scan` to start.")

    if stack:
        # Ship the chosen CI workflow as .github/workflows/ci.yml
        ci_src = target / "04-Testing-Deploy" / "templates" / "ci-workflows" / f"{stack}-ci.yml"
        if ci_src.exists():
            ci_dest = target / ".github" / "workflows" / "ci.yml"
            ci_dest.parent.mkdir(parents=True, exist_ok=True)
            if args.force or not ci_dest.exists():
                ci_dest.write_bytes(ci_src.read_bytes())
                print(f"[sdlc init] wrote .github/workflows/ci.yml from {stack}-ci.yml")
            else:
                print(f"[sdlc init] .github/workflows/ci.yml exists; --force to overwrite")
    # Regenerate tool configs so the new headers from this version are picked up.
    rc = _run_bundled_script("build-ai-configs.sh", [])
    return rc


_PHASE_AGENT = {1: "pm-agent", 2: "architect-agent", 3: "developer-agent", 4: "sre-agent"}
_PHASE_FILE = {1: "phase-1-pm.md", 2: "phase-2-architect.md",
               3: "phase-3-developer.md", 4: "phase-4-sre.md"}


def _next_pending(state: dict) -> tuple[int, dict] | None:
    """Return (phase_id, item) for the first pending item, or None when done."""
    for ph in state.get("phases", []):
        if ph.get("complete"):
            continue
        for it in ph.get("items", []):
            if not it.get("done"):
                return (ph["id"], it)
    return None


def _cmd_start(argv: list[str]) -> int:
    """Save the user's idea and print a paste-ready instruction for the AI tool."""
    parser = argparse.ArgumentParser(prog="sdlc start")
    parser.add_argument("idea", nargs="?", help="One-line description of what you want to build.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    if not (target / "automation" / "rules.json").exists():
        print("[sdlc start] this directory doesn't look like an sdlc project. Run `sdlc init` first.")
        return 1

    idea = args.idea
    if not idea:
        try:
            idea = input("What do you want to build? > ").strip()
        except EOFError:
            print("[sdlc start] no idea provided; usage: sdlc start \"<your idea>\"")
            return 2
    if not idea:
        print("[sdlc start] no idea provided; aborting.")
        return 2

    idea_file = target / "01-Planning" / "IDEA.md"
    idea_file.parent.mkdir(parents=True, exist_ok=True)
    idea_file.write_text(
        f"# Project idea\n\n{idea}\n\n"
        f"<!-- Captured by `sdlc start` on first run. Edit freely; the engine "
        f"does not enforce a structure here. -->\n",
        encoding="utf-8",
    )
    print(f"[sdlc start] saved your idea to {idea_file.relative_to(target)}")
    print()
    print("Next step — open this folder in your AI coding tool, then paste:")
    print()
    print("─" * 64)
    print(f"Use the pm-agent subagent to draft 01-Planning/01-PRD.md from")
    print(f"01-Planning/IDEA.md. Idea: {idea}")
    print("─" * 64)
    print()
    print("Why \"use the pm-agent subagent\" explicitly?")
    print("  Some AI tools (e.g. Claude Code with the 'superpowers' plugin)")
    print("  auto-fire other skills like 'brainstorming' when you share an")
    print("  idea. Naming the subagent forces Claude Code to use this repo's")
    print("  .claude/agents/pm-agent.md instead, which writes 01-Planning/01-PRD.md")
    print("  per automation/rules.json.")
    print()
    print("After the AI writes the PRD:")
    print("  sdlc scan --print     # verify DoD progress")
    print("  sdlc next             # paste-ready prompt for the next item")
    return 0


# Impact map: which DoD items get marked dirty when a particular concern changes.
_REPLAN_IMPACT: dict[str, list[str]] = {
    "requirements": [
        "user-stories-with-ac", "nfr-quantified", "stakeholder-raci", "risks-mitigated",
        "api-spec", "db-schema", "threat-model",
        "tests-present",
    ],
    "ui-ux": [
        "ui-spec",
        "tests-present",
    ],
    "tech-stack": [
        "architecture-doc", "api-spec", "db-schema", "adr-logged", "threat-model",
        "coding-standards", "git-workflow", "security-checklist", "tests-present",
        "ci-cd", "deploy-runbook", "slo-monitoring",
    ],
    "scale-nfr": [
        "nfr-quantified",
        "architecture-doc", "db-schema", "threat-model",
        "slo-monitoring",
    ],
}

_REPLAN_CHOICES = [
    ("requirements", "Functional requirements / user stories changed"),
    ("ui-ux", "UI / UX scope or screens changed"),
    ("tech-stack", "Tech stack / language / framework changed"),
    ("scale-nfr", "Scale / NFR targets (RPS, latency, SLO) changed"),
    ("custom", "Custom — I'll list the item ids myself"),
    ("clear", "Clear all dirty markers (I've redone the work)"),
]


def _cmd_replan(argv: list[str]) -> int:
    """Mark downstream DoD items dirty after a major change."""
    parser = argparse.ArgumentParser(prog="sdlc replan")
    parser.add_argument("--scope", choices=[c for c, _ in _REPLAN_CHOICES if c != "custom"],
                        default=None, help="Skip the prompt; pick one impact preset.")
    parser.add_argument("--items", default=None,
                        help="Comma-separated DoD item ids to mark dirty (used with --scope=custom).")
    parser.add_argument("--reason", default=None, help="Free-text reason recorded with the replan.")
    parser.add_argument("--clear", action="store_true",
                        help="Clear all dirty markers (after you've redone the work).")
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_path = target / "automation" / "state.json"
    if not state_path.exists():
        print("[sdlc replan] state.json not found. Run `sdlc scan` first.")
        return 1

    # Locate engine module to call clear/load/write_replan helpers.
    from sdlc_framework import engine
    engine.set_root(target)

    # Quick path: clear.
    if args.clear or args.scope == "clear":
        engine.clear_replan()
        print("[sdlc replan] cleared all dirty markers. Run `sdlc scan` to refresh state.")
        return 0

    # Resolve scope: flag or interactive.
    scope = args.scope
    if not scope:
        print("What changed? Pick one:")
        for i, (key, desc) in enumerate(_REPLAN_CHOICES, 1):
            print(f"  {i}. {desc}")
        try:
            raw = input("> ").strip()
        except EOFError:
            print("[sdlc replan] no selection; aborting")
            return 2
        try:
            idx = int(raw) - 1
            scope = _REPLAN_CHOICES[idx][0]
        except (ValueError, IndexError):
            print("[sdlc replan] invalid selection; aborting")
            return 2
        if scope == "clear":
            engine.clear_replan()
            print("[sdlc replan] cleared all dirty markers.")
            return 0

    # Compute affected items.
    if scope == "custom":
        if args.items:
            affected = [s.strip() for s in args.items.split(",") if s.strip()]
        else:
            print("Enter comma-separated DoD item ids (e.g. api-spec,tests-present):")
            try:
                raw = input("> ").strip()
            except EOFError:
                raw = ""
            affected = [s.strip() for s in raw.split(",") if s.strip()]
        if not affected:
            print("[sdlc replan] no items provided; aborting")
            return 2
    else:
        affected = list(_REPLAN_IMPACT.get(scope, []))
        if not affected:
            print(f"[sdlc replan] unknown scope '{scope}'; aborting")
            return 2

    # Validate items exist in rules.
    state = json.loads(state_path.read_text())
    known = {it["id"] for ph in state.get("phases") or [] for it in ph.get("items") or []}
    unknown = [a for a in affected if a not in known]
    if unknown:
        print(f"[sdlc replan] warning: these item ids are not in rules.json — they will be ignored:")
        for u in unknown:
            print(f"     · {u}")
        affected = [a for a in affected if a in known]
        if not affected:
            print("[sdlc replan] no valid items remain; aborting")
            return 2

    # Confirm with user.
    reason = args.reason
    if not reason:
        print(f"\nThis will mark {len(affected)} item(s) dirty:")
        for a in affected:
            print(f"     · {a}")
        try:
            reason = input("\nWhy (one line for the audit log)?\n> ").strip()
        except EOFError:
            reason = ""
        if not reason:
            reason = f"replan: scope={scope}"
        try:
            confirm = input("Apply? [Y/n] ").strip().lower()
        except EOFError:
            confirm = "y"
        if confirm and confirm not in ("y", "yes"):
            print("[sdlc replan] cancelled")
            return 0

    # Merge with any existing replan (union of dirty_items, latest reason wins).
    existing = engine.load_replan()
    merged_items = sorted(set((existing.get("dirty_items") or []) + affected))
    payload = {
        "dirty_items": merged_items,
        "reason": reason,
        "ts": json.loads(json.dumps(__import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))),
        "scope": scope,
    }
    engine.write_replan(payload)

    # Drop a clarification file so the change is auditable on the dashboard.
    clarif_dir = target / "automation" / "clarifications"
    clarif_dir.mkdir(parents=True, exist_ok=True)
    ts_slug = payload["ts"].replace(":", "").replace("-", "")
    clarif_file = clarif_dir / f"replan-{ts_slug}.md"
    clarif_file.write_text(
        f"# Replan: {scope}\n\nSTATUS: open\n\n"
        f"Reason: {reason}\n\n"
        f"## Items marked dirty\n\n"
        + "\n".join(f"- `{a}`" for a in affected)
        + "\n\n"
        + "Resolve by re-doing the work for the dirty items, then running `sdlc replan --clear`.\n",
        encoding="utf-8",
    )

    print(f"\n[sdlc replan] marked {len(affected)} item(s) dirty.")
    print(f"[sdlc replan] wrote audit clarification: {clarif_file.relative_to(target)}")
    print(f"[sdlc replan] run `sdlc scan` to refresh state, then `sdlc resume` to see what to redo.")
    print(f"[sdlc replan] when done, run `sdlc replan --clear` to drop the dirty markers.")
    return 0


def _cmd_resume(argv: list[str]) -> int:
    """Print 'where you are' + last activity + next action. Use after stepping away."""
    parser = argparse.ArgumentParser(prog="sdlc resume")
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_path = target / "automation" / "state.json"
    if not state_path.exists():
        print("[sdlc resume] state.json not found. Run `sdlc scan` first.")
        return 1

    state = json.loads(state_path.read_text())
    project = state.get("project") or {}
    runs = state.get("agent_runs") or []
    nxt = _next_pending(state)
    clarifs = state.get("clarifications") or []
    gates = [g for g in (state.get("gates") or []) if not g.get("approved")]

    last_done = next((r for r in runs if r.get("status") == "done"), None)
    last_any = runs[0] if runs else None

    if args.json:
        out = {
            "project": project.get("name"),
            "overall_pct": state.get("overall_pct"),
            "total_done": state.get("total_done"),
            "total_all": state.get("total_all"),
            "current": (
                {"phase": nxt[0], "item_id": nxt[1]["id"], "item_label": nxt[1]["label"]}
                if nxt else None
            ),
            "last_activity": last_any,
            "open_clarifications": len(clarifs),
            "pending_gates": len(gates),
        }
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0

    name = project.get("name") or "(unnamed project)"
    pct = state.get("overall_pct", 0)
    done = state.get("total_done", 0)
    total = state.get("total_all", 0)

    print(f"📍 {name} — {pct}% done ({done}/{total} items)")

    if nxt is not None:
        phase_id, item = nxt
        print(f"⏳ Currently pending: phase {phase_id} · {item['id']} — {item['label']}")
    else:
        print("🎉 All phases complete. Nothing pending.")

    if last_done or last_any:
        r = last_done or last_any
        from datetime import datetime, timezone
        try:
            t = datetime.strptime(r["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            ago = datetime.now(timezone.utc) - t
            sec = int(ago.total_seconds())
            if sec < 60: rel = f"{sec}s ago"
            elif sec < 3600: rel = f"{sec // 60}m ago"
            elif sec < 86400: rel = f"{sec // 3600}h ago"
            else: rel = f"{sec // 86400}d ago"
        except Exception:
            rel = r.get("ts", "?")
        verb = "finished" if r.get("status") == "done" else r.get("status", "ran")
        print(f"🕐 Last activity: {r['agent']} {verb} `{r['item_id']}` · {rel}")
    else:
        print("🕐 No agent activity yet")

    if clarifs:
        print(f"✋ {len(clarifs)} open clarification(s):")
        for c in clarifs[:5]:
            print(f"     · {c.get('file') or c.get('title')}")
    if gates:
        print(f"🔒 {len(gates)} pending gate(s):")
        for g in gates[:5]:
            print(f"     · {g['id']} (phase {g.get('phase', '?')}) — needs {', '.join(g.get('approvers_required') or [])}")

    print()
    print("Next steps:")
    if clarifs:
        print(f"  → Resolve clarification first: edit {clarifs[0].get('file', '?')}")
        print("    Change `STATUS: open` → `STATUS: resolved`, then `sdlc scan`.")
    elif gates:
        gid = gates[0]["id"]
        print(f"  → Approve gate `{gid}` by writing automation/signoffs/{gid}.yaml")
        print("    with `approved: true`, then `sdlc scan`.")
    elif nxt is not None:
        print(f"  → /sdlc-next  (in your AI tool)")
        print(f"     OR sdlc next  (from terminal — prints a paste-ready prompt)")
    else:
        print("  → Done. Consider `sdlc dashboard` to admire your handiwork. 🎉")
    return 0


def _cmd_next(argv: list[str]) -> int:
    """Print a paste-ready instruction for the next pending DoD item."""
    parser = argparse.ArgumentParser(prog="sdlc next")
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_path = target / "automation" / "state.json"
    if not state_path.exists():
        print("[sdlc next] state.json not found. Run `sdlc scan` first.")
        return 1

    state = json.loads(state_path.read_text())
    nxt = _next_pending(state)
    if nxt is None:
        msg = "All DoD items are done. Nothing to dispatch."
        print("🎉  " + msg)
        return 0
    phase_id, item = nxt
    agent = _PHASE_AGENT.get(phase_id, "orchestrator")
    role_file = f"agents/{_PHASE_FILE.get(phase_id, 'orchestrator.md')}"

    if args.json:
        out = {
            "phase": phase_id,
            "item_id": item["id"],
            "item_label": item["label"],
            "agent": agent,
            "role_file": role_file,
        }
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0

    print(f"🎯 Next pending: phase {phase_id} · {item['id']} — {item['label']}")
    print()
    print("📋 Open this folder in your AI coding tool and paste:")
    print()
    print("─" * 64)
    print(f"Use the {agent} subagent. Read automation/rules.json item")
    print(f"`{item['id']}` and write the deliverable file that satisfies")
    print("its checks. Do not edit anything outside the deliverable for")
    print("this item. Stop and write a clarification file under")
    print("automation/clarifications/ if you hit ambiguity, conflict,")
    print("gate, or a high-risk path.")
    print("─" * 64)
    print()
    print("(\"Use the <name> subagent\" forces Claude Code to invoke the")
    print(" matching .claude/agents/<name>.md and bypass any plugin skills")
    print(" that might also match the prompt.)")
    print()
    fail_msgs = [c["msg"] for c in item.get("checks", []) if not c.get("ok")]
    if fail_msgs:
        print("Why it's pending:")
        for m in fail_msgs[:3]:
            print(f"  · {m}")
        print()
    print(f"After the AI writes the file, verify with: sdlc scan --print")
    return 0


def _cmd_dashboard(argv: list[str]) -> int:
    """Serve the bundled dashboard HTML against the cwd's state.json."""
    parser = argparse.ArgumentParser(prog="sdlc dashboard")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args(argv)

    target = Path.cwd()
    state_file = target / "dashboard" / "state.json"
    if not state_file.exists():
        print(f"[sdlc dashboard] state.json not found at {state_file}.")
        print("[sdlc dashboard] run `sdlc scan` first.")
        return 1

    # Drop the bundled index.html into ./dashboard/index.html if missing.
    pkg_html = resources.files("sdlc_framework").joinpath("dashboard").joinpath("index.html")
    target_html = target / "dashboard" / "index.html"
    if not target_html.exists():
        with resources.as_file(pkg_html) as real_html:
            target_html.write_bytes(real_html.read_bytes())
        print(f"[sdlc dashboard] wrote {target_html}")

    print(f"[sdlc dashboard] serving http://localhost:{args.port}/dashboard/")
    print(f"[sdlc dashboard] Ctrl-C to stop.")
    cmd = ["python3", "-m", "http.server", str(args.port)]
    return subprocess.run(cmd, cwd=target).returncode


COMMANDS.update({
    "setup": _cmd_setup,
    "start": _cmd_start,
    "next": _cmd_next,
    "resume": _cmd_resume,
    "status": _cmd_resume,  # alias
    "where": _cmd_resume,   # alias
    "replan": _cmd_replan,
    "agent-log": _cmd_agent_log,
    "notify": _cmd_notify,
    "gh-issue": _cmd_gh_issue,
    "gh-pr": _cmd_gh_pr,
    "build-ai-configs": _cmd_build_ai_configs,
    "init": _cmd_init,
    "dashboard": _cmd_dashboard,
})


def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    if not argv or argv[0] in ("--help", "-h"):
        print("usage: sdlc <command> [args]")
        print()
        print("getting-started:")
        print("  setup             scaffold + pick which AI tool(s) to install commands for")
        print("                    (interactive; or --tools=claude-code,cursor,copilot,...)")
        print("  init              just scaffold (no AI-tool selection — use `setup` instead)")
        print("  start \"<idea>\"    save your idea + show how to start (used by /sdlc-start)")
        print("  next              show next pending DoD item (used by /sdlc-next)")
        print("  resume            \"where am I?\" — phase, last activity, what to do next")
        print("                    (aliases: status, where)")
        print("  replan            mark downstream DoD items dirty after a major change")
        print("                    (--scope=requirements|ui-ux|tech-stack|scale-nfr|custom, --clear)")
        print()
        print("workflow:")
        print("  scan              run engine, write state.json")
        print("  dispatch          read state.json and print next-agent brief")
        print("  dashboard         serve dashboard on --port (default 8765)")
        print()
        print("integrations:")
        print("  agent-log         start|done|fail wrapper for activity log")
        print("  notify            kind id title body — fire desktop notification")
        print("  gh-issue          --clarification PATH | --gate ID")
        print("  gh-pr             [--ready] [--base BRANCH]")
        print("  build-ai-configs  regenerate AI tool configs from shared sources")
        print()
        print("misc:")
        print("  --version         print version")
        return 0

    if argv[0] in ("--version", "-V"):
        print(f"sdlc {__version__}")
        return 0

    cmd = argv[0]
    rest = argv[1:]
    fn = COMMANDS.get(cmd)
    if fn is None:
        print(f"sdlc: unknown command: {cmd}", file=sys.stderr)
        return 2
    return fn(rest)


if __name__ == "__main__":
    sys.exit(main())
