# NEPSE Utils - Complete API Calls Analysis

## Base Configuration
- **API Base URL**: `https://webbackend.cdsc.com.np/api`
- **Result API**: `https://iporesult.cdsc.com.np`
- **Web Frontend**: `https://meroshare.cdsc.com.np`

---

## Task 1: ADD ACCOUNT
**Command**: `add {dmat} {password} {crn} {pin}`

### Purpose
Add a new investment account to the system.

### API Calls

#### 1.1 Login (Authentication)
```
Method: POST
Endpoint: /meroShare/auth/
Headers:
  - Authorization: "null"
  - Content-Type: application/json
Body:
{
  "clientId": str(capital_id),
  "username": username,
  "password": password
}
Response: auth_token in Authorization header
Error Handling: Checks for passwordExpired, accountExpired, dematExpired
```

#### 1.2 Get Account Details
```
Method: GET
Endpoint: /meroShareView/myDetail/{dmat}
Headers:
  - Authorization: auth_token
Response: Account details including name, bankCode
```

#### 1.3 Get Bank Details by Code
```
Method: GET
Endpoint: /bankRequest/{bank_code}
Headers:
  - Authorization: auth_token
Response: Bank details including accountNumber
```

#### 1.4 Get Bank List
```
Method: GET
Endpoint: /meroShare/bank/
Headers:
  - Authorization: auth_token
Response: List of banks with their IDs
```

#### 1.5 Get Bank-Specific Details
```
Method: GET
Endpoint: /meroShare/bank/{bank_id}
Headers:
  - Authorization: auth_token
Response: Bank details including accountBranchId, accountTypeId
```

#### 1.6 Fetch Capital List (Background)
```
Method: GET
Endpoint: /meroShare/capital/
Headers:
  - Authorization: "null"
Response: List of capitals with code and ID mappings
```

---

## Task 2: APPLY FOR IPO
**Command**: `apply`

### Purpose
Apply for available IPO shares across selected accounts.

### API Calls

#### 2.1 Login
```
Method: POST
Endpoint: /meroShare/auth/
(Same as Task 1.1)
```

#### 2.2 Fetch Applicable Issues (Available IPOs)
```
Method: POST
Endpoint: /meroShare/companyShare/applicableIssue/
Headers:
  - Authorization: auth_token
  - Content-Type: application/json
Body:
{
  "filterFieldParams": [
    {
      "key": "companyIssue.companyISIN.script",
      "alias": "Scrip"
    },
    {
      "key": "companyIssue.companyISIN.company.name",
      "alias": "Company Name"
    },
    {
      "key": "companyIssue.assignedToClient.name",
      "value": "",
      "alias": "Issue Manager"
    }
  ],
  "page": 1,
  "size": 10,
  "searchRoleViewConstants": "VIEW_APPLICABLE_SHARE",
  "filterDateParams": [...]
}
Response: List of applicable IPO issues
```

#### 2.3 Get Details (if not cached)
```
Method: GET
Endpoint: /meroShareView/myDetail/{dmat}
(Same as Task 1.2)
```

#### 2.4 Get Bank Details
```
Method: GET
Endpoint: /meroShare/bank/
(Same as Task 1.4)
```

#### 2.5 Get Bank-Specific Details
```
Method: GET
Endpoint: /meroShare/bank/{bank_id}
(Same as Task 1.5)
```

#### 2.6 Apply for IPO Share
```
Method: POST
Endpoint: /meroShare/applicantForm/share/apply
Headers:
  - Authorization: auth_token
  - Content-Type: application/json
  - Pragma: no-cache
  - Cache-Control: no-cache
Body:
{
  "demat": dmat,
  "boid": dmat[-8:],
  "accountNumber": account_number,
  "customerId": customer_id,
  "accountBranchId": branch_id,
  "accountTypeId": account_type_id,
  "appliedKitta": str(quantity),
  "crnNumber": crn,
  "transactionPIN": pin,
  "companyShareId": str(share_id),
  "bankId": bank_id
}
Response: Confirmation of applied application
Status Code: 201 (Created)
```

#### 2.7 Fetch Applied Issues (to update local cache)
```
Method: POST
Endpoint: /meroShare/applicantForm/active/search/
Headers:
  - Authorization: auth_token
  - Content-Type: application/json
Body:
{
  "filterFieldParams": [...],
  "page": 1,
  "size": 200,
  "searchRoleViewConstants": "VIEW_APPLICANT_FORM_COMPLETE",
  "filterDateParams": [...]
}
Response: List of active applications
```

---

## Task 3: CHECK IPO APPLICATION STATUS
**Command**: `status`

### Purpose
Check the current status of IPO applications (Alloted/Not Alloted/Rejected/Pending).

### API Calls

#### 3.1 Login
```
Method: POST
Endpoint: /meroShare/auth/
(Same as Task 1.1)
```

#### 3.2 Fetch Application Reports (Active)
```
Method: POST
Endpoint: /meroShare/applicantForm/active/search/
Headers:
  - Authorization: auth_token
  - Content-Type: application/json
Body:
{
  "filterFieldParams": [...],
  "page": 1,
  "size": 200,
  "searchRoleViewConstants": "VIEW_APPLICANT_FORM_COMPLETE",
  "filterDateParams": [...]
}
Response: List of active applications with company_share_id
```

#### 3.3 Get Detailed Application Status (For Each Issue)
```
Method: GET
Endpoint: /meroShare/applicantForm/report/detail/{applicant_form_id}
Headers:
  - Authorization: auth_token
Response: Detailed status including:
  - statusName (Alloted/Not Alloted/Rejected)
  - receivedKitta (alloted quantity)
  - appliedDate
  - appliedKitta
  - amount
  - meroshareRemark
```

#### 3.4 Get Detailed Application Status (For Migrated Old Issues)
```
Method: GET
Endpoint: /meroShare/migrated/applicantForm/report/{applicant_form_id}
Headers:
  - Authorization: auth_token
Response: Same as 3.3 but for old/migrated issues
```

---

## Task 4: CHECK IPO RESULT
**Command**: `result`

### Purpose
Check allotment results for closed IPOs.

### API Calls

#### 4.1 Fetch Result Company List
```
Method: GET
Endpoint: https://iporesult.cdsc.com.np/result/companyShares/fileUploaded
Headers:
  - User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0
  - Accept: application/json
Response:
{
  "body": {
    "companyShareList": [
      {
        "companyName": string,
        "symbol": string,
        "id": string,
        "companyShareId": string,
        ...
      }
    ]
  }
}
```

#### 4.2 Fetch Allotment Results (No additional API call needed)
- Results are displayed from the company share list above
- User interactively selects from the company list

---

## Task 5: VIEW PORTFOLIO
**Command**: `portfolio`

### Purpose
Display the holdings and portfolio value of an account.

### API Calls

#### 5.1 Login
```
Method: POST
Endpoint: /meroShare/auth/
(Same as Task 1.1)
```

#### 5.2 Fetch Portfolio
```
Method: POST
Endpoint: /meroShareView/myPortfolio/
Headers:
  - Authorization: auth_token
  - Content-Type: application/json
Body:
{
  "sortBy": "script",
  "demat": [dmat],
  "clientCode": dpid,
  "page": 1,
  "size": 200,
  "sortAsc": true
}
Response:
{
  "meroShareMyPortfolio": [
    {
      "script": string,
      "scriptDesc": string,
      "currentBalance": float,
      "lastTransactionPrice": float,
      "previousClosingPrice": float,
      "valueAsOfLastTransactionPrice": float,
      "valueAsOfPreviousClosingPrice": float
    }
  ],
  "totalItems": int,
  "totalValueAsOfLastTransactionPrice": float,
  "totalValueAsOfPreviousClosingPrice": float
}
```

---

## Task 6: SYNC PORTFOLIO AND APPLICATION STATUS
**Command**: `sync`

### Purpose
Refresh portfolio and application status from MeroShare.

### API Calls

#### 6.1 All APIs from Task 3 (Status Check)
- Fetch Application Reports (Active & Migrated)
- Get Detailed Application Status

#### 6.2 All APIs from Task 5 (Portfolio)
- Fetch Portfolio

---

## Task 7: GET ACCOUNT DETAILS
**Command**: `add` (during account addition)

### Purpose
Get account information (name, account number, bank ID, branch ID, etc.)

### API Calls
(Same as Task 1, sections 1.2-1.5)

---

## Task 8: FETCH EDIS HISTORY
**Command**: `sync` (Background operation)

### Purpose
Fetch Electronic Delivery Instruction System history.

### API Calls

#### 8.1 Login
```
Method: POST
Endpoint: /meroShare/auth/
(Same as Task 1.1)
```

#### 8.2 Search EDIS History
```
Method: POST
Endpoint: /EDIS/report/search/
Headers:
  - Authorization: auth_token
  - Content-Type: application/json
Body:
{
  "filterFieldParams": [
    {
      "key": "requestStatus.name",
      "value": "",
      "alias": "Status"
    },
    {
      "key": "contractObligationMap.obligation.settleId",
      "alias": "Settlement Id"
    },
    {
      "key": "contractObligationMap.obligation.scriptCode",
      "alias": "Script"
    },
    {
      "key": "contractObligationMap.obligation.sellCmId",
      "alias": "CM ID",
      "condition": "': '"
    }
  ],
  "page": 1,
  "size": 200,
  "searchRoleViewConstants": "VIEW",
  "filterDateParams": [...]
}
Response:
{
  "object": [
    {
      "contract": {
        "obligation": {
          "scriptCode": string,
          "settleDate": string,
          ...
        }
      },
      "statusName": string,
      ...
    }
  ]
}
```

---

## Task 9: FIND MINIMUM APPLY UNIT
**Command**: `apply` (Background operation)

### Purpose
Get minimum number of shares required for IPO application.

### API Calls

#### 9.1 Login
```
Method: POST
Endpoint: /meroShare/auth/
(Same as Task 1.1)
```

#### 9.2 Get Minimum Apply Unit
```
Method: GET
Endpoint: /meroShare/active/{company_share_id}
Headers:
  - Authorization: auth_token
Response:
{
  "minUnit": int,
  "maxUnit": int,
  ...
}
```

---

## Task 10: LOGOUT
**Command**: `apply`, `status`, `portfolio` (After operations complete)

### Purpose
Cleanup session after operations.

### API Calls

#### 10.1 Logout
```
Method: GET
Endpoint: /meroShare/auth/logout/
Headers:
  - Authorization: auth_token
Status Code: 201 (Created)
Response: Empty or confirmation
```

---

## Authentication Flow

All authenticated operations follow this pattern:
1. **Login**: POST to `/meroShare/auth/` with clientId, username, password
2. **Receive**: Authorization token in response headers
3. **Use**: Add Authorization header to all subsequent requests
4. **Logout**: GET to `/meroShare/auth/logout/` (optional but recommended)

---

## Summary of All Unique API Endpoints

### MeroShare API (https://webbackend.cdsc.com.np/api)
1. `POST /meroShare/auth/` - Login
2. `GET /meroShare/auth/logout/` - Logout
3. `GET /meroShareView/myDetail/{dmat}` - Get Account Details
4. `GET /bankRequest/{bank_code}` - Get Bank Details
5. `GET /meroShare/bank/` - Get Bank List
6. `GET /meroShare/bank/{bank_id}` - Get Bank-Specific Details
7. `GET /meroShare/capital/` - Get Capital List
8. `POST /meroShare/companyShare/applicableIssue/` - Fetch Applicable Issues
9. `POST /meroShare/applicantForm/share/apply` - Apply for IPO
10. `POST /meroShare/applicantForm/active/search/` - Search Active Applications
11. `POST /meroShare/migrated/applicantForm/search/` - Search Migrated Applications
12. `GET /meroShare/applicantForm/report/detail/{form_id}` - Get Application Status
13. `GET /meroShare/migrated/applicantForm/report/{form_id}` - Get Migrated Application Status
14. `POST /meroShareView/myPortfolio/` - Get Portfolio
15. `GET /meroShare/active/{company_share_id}` - Get Minimum Apply Unit
16. `POST /EDIS/report/search/` - Search EDIS History

### External API (https://iporesult.cdsc.com.np)
1. `GET /result/companyShares/fileUploaded` - Fetch IPO Result Companies

---

## Request/Response Headers

### Default Headers (All Requests)
```
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0
Accept: application/json, text/plain, */*
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate, br, zstd
Content-Type: application/json
Origin: https://meroshare.cdsc.com.np
Connection: keep-alive
Referer: https://meroshare.cdsc.com.np/
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: cors
Sec-Fetch-Site: same-site
Pragma: no-cache
Cache-Control: no-cache
```

### Authentication Header
```
Authorization: {auth_token}
```
(Set to "null" for public endpoints like login and capital list)

---

## Error Handling

- **Status Code 200**: Success
- **Status Code 201**: Created (successful POST/PUT)
- **Status Code != Expected**: Raises `LocalException` or `GlobalError`

### Login-Specific Validations
- `passwordExpired`: Password needs to be updated
- `accountExpired`: Account has expired
- `dematExpired`: DMAT has expired

---

## Rate Limiting and Retry Strategy

- **Retry Logic**: 3 attempts maximum
- **Wait Time**: 2 seconds between retries
- **Applied To**: Most API calls except data-only operations

---

## Data Persistence

- All account data is encrypted using Fernet encryption
- Stored in config file at: `%APPDATA%\ipo\config.json` (Windows)
- Credentials include: DMAT, password, PIN, CRN, account details, portfolio, issues
