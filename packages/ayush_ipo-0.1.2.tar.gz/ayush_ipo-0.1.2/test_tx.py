from ipo.core.account import Account

acc = Account(
    dmat="1301240000288991",
    password="Ayush@20011",
    pin=2414,
    capital_id=195,
    crn="R010704061",
)

acc.login()
result = acc.fetch_transaction_history(script="nrn")
print(result)