from dataclasses import dataclass, asdict


@dataclass
class PortfolioEntry:
    current_balance: float
    last_transaction_price: float
    previous_closing_price: float
    script: str
    script_desc: str
    value_as_of_last_transaction_price: float
    value_as_of_previous_closing_price: float

    def to_json(self):
        return asdict(self)

    @classmethod
    def from_json(cls, json: dict):
        return cls(**json)


class Portfolio:
    entries: list[PortfolioEntry]

    total_items: int
    total_value_as_of_last_transaction_price: float
    total_value_as_of_previous_closing_price: float

    def __init__(
        self,
        entries: list[PortfolioEntry],
        total_items: int,
        total_value_as_of_last_transaction_price: float,
        total_value_as_of_previous_closing_price: float,
    ) -> None:
        self.entries = entries
        self.total_items = total_items
        self.total_value_as_of_last_transaction_price = total_value_as_of_last_transaction_price
        self.total_value_as_of_previous_closing_price = total_value_as_of_previous_closing_price

    def to_json(self):
        return {
            "entries": [entry.to_json() for entry in self.entries],
            "total_items": self.total_items,
            "total_value_as_of_last_transaction_price": self.total_value_as_of_last_transaction_price,
            "total_value_as_of_previous_closing_price": self.total_value_as_of_previous_closing_price,
        }

    @staticmethod
    def from_json(json: dict):
        return Portfolio(
            [PortfolioEntry.from_json(entry) for entry in json["entries"]],
            json["total_items"],
            json["total_value_as_of_last_transaction_price"],
            json["total_value_as_of_previous_closing_price"],
        )
