import requests
from tenacity import retry, stop_after_attempt, wait_random_exponential
from typing import Dict, List, Any
from ipo.constants import BASE_HEADERS, MS_API_BASE


class MeroShareAPI:
    """Client for MeroShare API interactions."""

    def __init__(self, session: requests.Session = None):
        self.session = session or requests.Session()
        self.session.headers.update(BASE_HEADERS)

    def set_auth_token(self, token: str):
        self.session.headers["Authorization"] = token

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def login(self, data: Dict[str, Any]) -> str:
        self.session.headers["Authorization"] = "null"
        self.session.headers["Content-Type"] = "application/json"
        response = self.session.post(f"{MS_API_BASE}/meroShare/auth/", json=data)
        response.raise_for_status()
        response_data = response.json()
        # Check for errors
        if response_data.get("passwordExpired"):
            raise ValueError("Password has expired")
        if response_data.get("accountExpired"):
            raise ValueError("Account has expired")
        if response_data.get("dematExpired"):
            raise ValueError("DMAT has expired")
        token = response.headers.get("Authorization")
        if token:
            self.set_auth_token(token)
        return token

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def logout(self) -> Dict[str, Any]:
        response = self.session.get(f"{MS_API_BASE}/meroShare/auth/logout/")
        if response.status_code != 201:
            response.raise_for_status()  # or custom check
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def get_details(self, dmat: str) -> Dict[str, Any]:
        response = self.session.get(f"{MS_API_BASE}/meroShareView/myDetail/{dmat}")
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def fetch_portfolio(self, dmat: str, dpid: str) -> Dict[str, Any]:
        data = {
            "sortBy": "script",
            "demat": [dmat],
            "clientCode": dpid,
            "page": 1,
            "size": 200,
            "sortAsc": True,
        }
        response = self.session.post(f"{MS_API_BASE}/meroShareView/myPortfolio/", json=data)
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def fetch_applicable_issues(self) -> Dict[str, Any]:
        data = {
            "filterFieldParams": [
                {
                    "key": "companyIssue.companyISIN.script",
                    "alias": "Scrip",
                },
                {
                    "key": "companyIssue.companyISIN.company.name",
                    "alias": "Company Name",
                },
                {
                    "key": "companyIssue.assignedToClient.name",
                    "value": "",
                    "alias": "Issue Manager",
                },
            ],
            "page": 1,
            "size": 10,
            "searchRoleViewConstants": "VIEW_APPLICABLE_SHARE",
            "filterDateParams": [
                {
                    "key": "minIssueOpenDate",
                    "condition": "",
                    "alias": "",
                    "value": "",
                },
                {
                    "key": "maxIssueCloseDate",
                    "condition": "",
                    "alias": "",
                    "value": "",
                },
            ],
        }
        response = self.session.post(f"{MS_API_BASE}/meroShare/companyShare/applicableIssue/", json=data)
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def apply_for_issue(self, data: Dict[str, Any]) -> Dict[str, Any]:
        response = self.session.post(f"{MS_API_BASE}/meroShare/applicantForm/share/apply", json=data)
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def fetch_application_reports(self, active: bool = True) -> Dict[str, Any]:
        search_role_view_constants = "VIEW_APPLICANT_FORM_COMPLETE" if active else "VIEW_APPLICANT_FORM_HISTORY"
        data = {
            "filterFieldParams": [
                {"key": "companyShare.companyIssue.companyISIN.script", "alias": "Scrip"},
                {"key": "companyShare.companyIssue.companyISIN.company.name", "alias": "Company Name"},
                {"key": "companyShare.applicantFormId", "alias": "Form ID"},
                {"key": "companyShare.companyIssue.issueOpenDate", "alias": "Open Date"},
                {"key": "companyShare.companyIssue.issueCloseDate", "alias": "Close Date"},
            ],
            "page": 1,
            "size": 200,
            "searchRoleViewConstants": search_role_view_constants,
            "filterDateParams": {"dateRange": [], "comparisonOperator": "LTE", "filterType": "ISSUE_CLOSE_DATE"},
        }
        response = self.session.post(f"{MS_API_BASE}/meroShare/applicantForm/active/search/", json=data)
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def fetch_application_status(self, form_id: str) -> Dict[str, Any]:
        response = self.session.get(f"{MS_API_BASE}/meroShare/applicantForm/report/detail/{form_id}")
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def fetch_min_apply_unit(self, share_id: str) -> Dict[str, Any]:
        response = self.session.get(f"{MS_API_BASE}/meroShare/companyShare/{share_id}")
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def get_bank_request(self, bank_code: str) -> Dict[str, Any]:
        response = self.session.get(f"{MS_API_BASE}/bankRequest/{bank_code}")
        response.raise_for_status()
        return response.json()

    @retry(stop=stop_after_attempt(3), wait=wait_random_exponential(multiplier=1, min=2, max=10), reraise=True)
    def get_bank_details(self) -> Dict[str, Any]:
        response = self.session.get(f"{MS_API_BASE}/meroShare/bank/")
        response.raise_for_status()
        return response.json()