from dataclasses import dataclass, field, asdict


@dataclass
class Issue:
    name: str
    symbol: str
    status: str
    share_type: str
    company_share_id: str
    applicant_form_id: str
    alloted: bool | None = None
    alloted_quantity: float | None = None
    applied_date: str | None = None
    applied_quantity: float | None = None
    applied_amount: float | None = None
    block_amount_status: str | None = None
    old: bool | None = None
    transaction_history: list | None = None

    def to_json(self):
        return asdict(self)

    @classmethod
    def from_json(cls, json: dict):
        known = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in json.items() if k in known})