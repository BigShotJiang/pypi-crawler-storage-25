#!/usr/bin/python3
from __future__ import annotations

import argparse
import csv
import json
import logging
import os
import sys
from cmd import Cmd
from datetime import date, datetime
from getpass import getpass
from pathlib import Path

from cryptography.fernet import InvalidToken
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm, Prompt
from rich.table import Table

from ipo.version import __version__
from rich.text import Text

from ipo.core.account import Account
from ipo.core.errors import LocalException
from ipo.core.meroshare import MeroShare
from ipo.core.portfolio import PortfolioEntry
from ipo.utils import config_converter

logging.basicConfig(
    format="%(asctime)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
)
logging.getLogger("urllib3").setLevel(logging.ERROR)

# Fix #14: dict lookup replaces if/elif chain in do_loglevel
_LOG_LEVELS: dict[str, int] = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
}

console = Console()

# ── Colour palette ────────────────────────────────────────────────────────────
C_BORDER   = "#1E3A8A"   # deep navy    – table/panel borders
C_PRIMARY  = "#60A5FA"   # sky blue     – IDs, titles, headings
C_VALUE    = "white"     # white        – primary data values
C_MUTED    = "#93C5FD"   # pale blue    – secondary / label columns
C_DIM      = "#64748B"   # slate grey   – hints, tips, dim text
C_SUCCESS  = "#22D3EE"   # cyan         – positive outcomes (allotted / applied)
C_ERROR    = "#EF4444"   # red          – errors and hard failures
C_WARN     = "#FBBF24"   # amber        – warnings (used sparingly)
C_TOTAL    = "#E2E8F0"   # near-white   – totals rows
C_DATA     = C_VALUE
# ─────────────────────────────────────────────────────────────────────────────

_MAX_LOGIN_ATTEMPTS = 3
_DEFAULT_PROMPT     = f"[bold {C_PRIMARY}]IPO > [/bold {C_PRIMARY}]"


def _prompt_or_esc(prompt_text: str) -> str | None:
    """
    Read a line of visible input character by character.
    Returns None if the user presses ESC (exits the current flow).
    Handles backspace. Works on Windows and Unix.
    """
    import sys
    sys.stdout.write(prompt_text)
    sys.stdout.flush()

    if sys.platform == "win32":
        import msvcrt
        chars: list[str] = []
        while True:
            ch = msvcrt.getch()
            if ch in (b"\r", b"\n"):
                sys.stdout.write("\n")
                sys.stdout.flush()
                return "".join(chars)
            elif ch == b"\x03":
                raise KeyboardInterrupt
            elif ch == b"\x1b":             # ESC
                sys.stdout.write("\n")
                sys.stdout.flush()
                return None
            elif ch in (b"\x08", b"\x7f"): # Backspace
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
            else:
                try:
                    c = ch.decode("utf-8")
                    chars.append(c)
                    sys.stdout.write(c)
                    sys.stdout.flush()
                except UnicodeDecodeError:
                    pass
    else:
        import termios, tty
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        chars: list[str] = []
        try:
            tty.setraw(fd)
            while True:
                ch = sys.stdin.read(1)
                if ch in ("\r", "\n"):
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    return "".join(chars)
                elif ch == "\x03":
                    raise KeyboardInterrupt
                elif ch == "\x1b":              # ESC
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    return None
                elif ch in ("\x7f", "\x08"):    # Backspace
                    if chars:
                        chars.pop()
                        sys.stdout.write("\b \b")
                        sys.stdout.flush()
                else:
                    chars.append(ch)
                    sys.stdout.write(ch)
                    sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return "".join(chars)


def _getpass_starred(prompt_text: str) -> str | None:
    """
    Read a password character by character, printing * for each character typed.
    Handles backspace. Works on both Windows and Unix.
    """
    import sys
    sys.stdout.write(prompt_text)
    sys.stdout.flush()

    if sys.platform == "win32":
        import msvcrt
        chars: list[str] = []
        while True:
            ch = msvcrt.getch()
            if ch in (b"\r", b"\n"):
                sys.stdout.write("\n")
                sys.stdout.flush()
                break
            elif ch == b"\x03":
                raise KeyboardInterrupt
            elif ch in (b"\x08", b"\x7f"):      # Backspace
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
            elif ch == b"\x1b":                  # ESC — cancel
                sys.stdout.write("\n")
                sys.stdout.flush()
                return None
            else:
                try:
                    chars.append(ch.decode("utf-8"))
                except UnicodeDecodeError:
                    pass
                sys.stdout.write("*")
                sys.stdout.flush()
        return "".join(chars)
    else:
        import termios, tty
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        chars: list[str] = []
        try:
            tty.setraw(fd)
            while True:
                ch = sys.stdin.read(1)
                if ch in ("\r", "\n"):
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    break
                elif ch == "\x03":
                    raise KeyboardInterrupt
                elif ch in ("\x7f", "\x08"):     # Backspace/Delete
                    if chars:
                        chars.pop()
                        sys.stdout.write("\b \b")
                        sys.stdout.flush()
                elif ch == "\x1b":               # ESC — cancel
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    return None
                else:
                    chars.append(ch)
                    sys.stdout.write("*")
                    sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return "".join(chars)


def _classify_sync_error(exc: Exception) -> str:
    """Return a human-readable reason string for a sync failure."""
    msg = str(exc).lower()
    if "401" in msg or "403" in msg or "unauthorized" in msg or "forbidden" in msg:
        return "Credentials invalid or session expired"
    if "timeout" in msg or "timed out" in msg:
        return "Request timed out"
    if (
        "connectionerror" in type(exc).__name__.lower()
        or "connection" in msg
        or "network" in msg
        or "unreachable" in msg
    ):
        return "Network unreachable"
    return str(exc)


class SyncMeta:
    """
    Thin wrapper around ipo_sync.json.
    Stores: last_synced_date (ISO date string), export_directory (str | None).
    Lives next to the encrypted MeroShare data file.
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        self._data: dict = {}
        if path.exists():
            try:
                self._data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                self._data = {}

    # ── persistence ──────────────────────────────────────────────────
    def save(self) -> None:
        self._path.write_text(
            json.dumps(self._data, indent=2), encoding="utf-8"
        )

    # ── last_synced_date ─────────────────────────────────────────────
    @property
    def last_synced_date(self) -> date | None:
        raw = self._data.get("last_synced_date")
        if raw:
            try:
                return date.fromisoformat(raw)
            except ValueError:
                pass
        return None

    @last_synced_date.setter
    def last_synced_date(self, value: date) -> None:
        self._data["last_synced_date"] = value.isoformat()

    # ── export_directory ─────────────────────────────────────────────
    @property
    def export_directory(self) -> str | None:
        return self._data.get("export_directory")

    @export_directory.setter
    def export_directory(self, value: str) -> None:
        self._data["export_directory"] = value


class IPOApp(Cmd):
    prompt = ""   # rendered via Rich in cmdloop; kept as "" to suppress Cmd's own output
    intro  = ""

    ms:               MeroShare
    meta:             SyncMeta
    _session_applied: bool = False

    def cmdloop(self, intro=None):
        """Override cmdloop to use Rich-formatted prompt (reads self.prompt)."""
        self.preloop()
        if self.use_rawinput and self.completekey:
            try:
                import readline
                self.old_completer = readline.get_completer()
                readline.set_completer(self.complete)
                readline.parse_and_bind(self.completekey + ": complete")
            except ImportError:
                pass
        try:
            if intro is not None:
                self.intro = intro
            if self.intro:
                self.stdout.write(str(self.intro) + "\n")
            stop = None
            while not stop:
                if self.cmdqueue:
                    line = self.cmdqueue.pop(0)
                else:
                    if self.use_rawinput:
                        try:
                            console.print(self.prompt, end="")
                            line = input()
                        except EOFError:
                            line = "EOF"
                    else:
                        self.stdout.write(self.prompt)
                        self.stdout.flush()
                        line = self.stdin.readline()
                        if not line:
                            line = "EOF"
                        else:
                            line = line.rstrip("\r\n")
                line = self.precmd(line)
                stop = self.onecmd(line)
                stop = self.postcmd(stop, line)
            self.postloop()
        finally:
            if self.use_rawinput and self.completekey:
                try:
                    import readline
                    readline.set_completer(self.old_completer)
                except ImportError:
                    pass

    def preloop(self, *args, **kwargs):
        if not (MeroShare.default_config_path()).exists():
            config_converter.pre_versioning_to_current()
            logging.info("Creating a new data file! Existing file not found!")
            MeroShare.default_config_directory().mkdir(parents=True, exist_ok=True)
            password = getpass(prompt="Set a password to unlock: ")
            self.ms = MeroShare.new(password)
        else:
            for attempt in range(1, _MAX_LOGIN_ATTEMPTS + 1):
                console.print(f"[bold {C_PRIMARY}]Enter password to unlock:[/bold {C_PRIMARY}] ", end="")
                password = _getpass_starred("")
                # Silence core logging (e.g. "Initializing Fernet!") during the attempt
                _root_level = logging.getLogger().level
                logging.getLogger().setLevel(logging.CRITICAL)
                try:
                    self.ms = MeroShare.load(password)
                    logging.getLogger().setLevel(_root_level)
                    break
                except InvalidToken:
                    logging.getLogger().setLevel(_root_level)
                    remaining = _MAX_LOGIN_ATTEMPTS - attempt
                    if remaining > 0:
                        console.print(
                            f"[{C_ERROR}]Incorrect password! "
                            f"{remaining} attempt(s) remaining.[/{C_ERROR}]"
                        )
                    else:
                        console.print(
                            f"[{C_ERROR}]Incorrect password! "
                            f"No attempts remaining. Exiting.[/{C_ERROR}]"
                        )
                        sys.exit(1)

        # ── Load sync metadata ────────────────────────────────────────
        meta_path  = MeroShare.default_config_directory() / "ipo_sync.json"
        self.meta  = SyncMeta(meta_path)

        self.prompt = _DEFAULT_PROMPT

        last_sync   = self.meta.last_synced_date
        sync_needed = last_sync is None or last_sync < date.today()
        sync_label  = (
            "Never synced" if last_sync is None
            else f"Last synced: {last_sync.isoformat()}"
        )

        banner = Panel.fit(
            f"[bold {C_PRIMARY}]✓ Welcome to NEPSE IPO v{__version__}[/bold {C_PRIMARY}]\n"
            f"[{C_DATA}]Date:[/{C_DATA}]      {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"[{C_DATA}]Accounts:[/{C_DATA}]  {len(self.ms.accounts)} loaded\n"
            f"[{C_DATA}]Sync:[/{C_DATA}]      {sync_label}"
            + (f" [{C_WARN}](auto-sync will run now)[/{C_WARN}]" if sync_needed else "")
            + f"\n[{C_DIM}]Type [bold {C_PRIMARY}]?[/bold {C_PRIMARY}] for help, "
            f"[bold {C_PRIMARY}]quit[/bold {C_PRIMARY}] to exit[/{C_DIM}]",
            title=f"[bold {C_PRIMARY}]═══ NEPSE IPO ═══[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
            padding=(1, 2),
        )
        console.print(banner)

        if sync_needed:
            self._run_sync(auto=True)

    # ------------------------------------------------------------------
    # _run_sync — shared engine for both auto-sync and manual sync
    # ------------------------------------------------------------------
    def _run_sync(self, auto: bool = False) -> None:
        """
        Sync portfolio and application data for all accounts.
        Prints a per-account live status with timestamps.
        Records last_synced_date regardless of partial failures.
        """
        label = "Auto-syncing" if auto else "Syncing"
        console.print(f"\n[bold {C_PRIMARY}]{label} accounts…[/bold {C_PRIMARY}]")

        results: list[tuple[str, bool, str, str]] = []  # name, ok, reason, timestamp

        for account in self.ms.accounts:
            ts_start = datetime.now().strftime("%H:%M:%S")
            console.print(
                f"  [{C_MUTED}]{ts_start}[/{C_MUTED}]  "
                f"[{C_PRIMARY}]{account.name}[/{C_PRIMARY}]  "
                f"[{C_DIM}]syncing…[/{C_DIM}]",
                end="\r",
            )
            try:
                account.fetch_portfolio()
                account.fetch_applied_issues()
                account.fetch_applied_issues_status()
                ts_end = datetime.now().strftime("%H:%M:%S")
                console.print(
                    f"  [{C_MUTED}]{ts_end}[/{C_MUTED}]  "
                    f"[{C_PRIMARY}]{account.name}[/{C_PRIMARY}]  "
                    f"[bold {C_SUCCESS}]✓ Completed[/bold {C_SUCCESS}]"
                    + " " * 20  # clear any leftover \r text
                )
                results.append((account.name, True, "", ts_end))
            except Exception as exc:
                reason = _classify_sync_error(exc)
                ts_end = datetime.now().strftime("%H:%M:%S")
                console.print(
                    f"  [{C_MUTED}]{ts_end}[/{C_MUTED}]  "
                    f"[{C_PRIMARY}]{account.name}[/{C_PRIMARY}]  "
                    f"[bold {C_ERROR}]✗ Failed[/bold {C_ERROR}]  "
                    f"[{C_DIM}]{reason}[/{C_DIM}]"
                    + " " * 20
                )
                results.append((account.name, False, reason, ts_end))

        self.ms.save_data()
        self.meta.last_synced_date = date.today()
        self.meta.save()

        ok_count   = sum(1 for _, ok, _, _ in results if ok)
        fail_count = len(results) - ok_count

        if fail_count == 0:
            console.print(
                f"\n[{C_SUCCESS}]Sync complete — all {ok_count} account(s) synced successfully.[/{C_SUCCESS}]"
            )
        else:
            console.print(
                f"\n[{C_WARN}]Sync complete — {ok_count}/{len(results)} succeeded, "
                f"{fail_count} failed.[/{C_WARN}]"
            )

    # ------------------------------------------------------------------
    # Helper: validated account selector
    # ------------------------------------------------------------------
    def _get_account(self, prompt: str = "Choose an account ID: ") -> Account | None:
        """Prompt the user for an account ID and return the Account, or None on invalid input."""
        raw = Prompt.ask(prompt)
        try:
            idx = int(raw) - 1
            if not (0 <= idx < len(self.ms.accounts)):
                raise IndexError
            return self.ms.accounts[idx]
        except (ValueError, IndexError):
            console.print(
                f"[{C_ERROR}]Invalid account ID '{raw}'. "
                f"Please enter a number between 1 and {len(self.ms.accounts)}.[/{C_ERROR}]"
            )
            return None

    def _require_accounts(self) -> bool:
        """Return True if at least one account exists; print an error and return False otherwise."""
        if not self.ms.accounts:
            console.print(
                f"[{C_ERROR}]No accounts found. Add one first with [bold]add[/bold].[/{C_ERROR}]"
            )
            return False
        return True

    def _prompt_int(self, prompt: str) -> int | None:
        """Prompt for an integer; print an error and return None if input is not numeric."""
        raw = Prompt.ask(prompt)
        try:
            return int(raw)
        except ValueError:
            console.print(f"[{C_ERROR}]Expected a number, got '{raw}'.[/{C_ERROR}]")
            return None

    # ------------------------------------------------------------------
    # add
    # ------------------------------------------------------------------
    def help_add(self):
        print("Add a new account!")
        print("Usage: add {dmat} {password} {crn} {pin}")

    def do_add(self, args):
        """Add a new MeroShare account."""
        args = args.split(" ")

        if len(args) == 4:
            dmat, password, crn, pin = args

            # ── Validate inline args ──────────────────────────────────
            if not dmat.isdigit() or len(dmat) != 16:
                console.print(f"[{C_ERROR}]Invalid DMAT '{dmat}'. Must be exactly 16 digits.[/{C_ERROR}]")
                return
            if not pin.isdigit():
                console.print(f"[{C_ERROR}]Invalid PIN '{pin}'. Must be numeric.[/{C_ERROR}]")
                return
            if not crn.strip():
                console.print(f"[{C_ERROR}]CRN cannot be empty.[/{C_ERROR}]")
                return

        elif len(args) == 1 and args[0] == "":
            console.print(f"[{C_DIM}]Press ESC at any field to cancel.[/{C_DIM}]")

            # ── DMAT ─────────────────────────────────────────────────
            while True:
                dmat = _prompt_or_esc("Enter DMAT (16 digits): ")
                if dmat is None:
                    console.print(f"[{C_DIM}]Add cancelled.[/{C_DIM}]")
                    return
                if dmat.isdigit() and len(dmat) == 16:
                    break
                console.print(
                    f"[{C_ERROR}]Invalid DMAT. Must be exactly 16 digits, got '{dmat}' "
                    f"({len(dmat)} char(s)).[/{C_ERROR}]"
                )

            # ── Password ──────────────────────────────────────────────
            while True:
                password = _getpass_starred("Enter Meroshare Password: ")
                if password is None:
                    console.print(f"[{C_DIM}]Add cancelled.[/{C_DIM}]")
                    return
                if password.strip():
                    break
                console.print(f"[{C_ERROR}]Password cannot be empty.[/{C_ERROR}]")

            # ── CRN ───────────────────────────────────────────────────
            while True:
                crn = _prompt_or_esc("Enter CRN Number: ")
                if crn is None:
                    console.print(f"[{C_DIM}]Add cancelled.[/{C_DIM}]")
                    return
                if crn.strip():
                    break
                console.print(f"[{C_ERROR}]CRN cannot be empty.[/{C_ERROR}]")

            # ── PIN ───────────────────────────────────────────────────
            while True:
                pin = _getpass_starred("Enter Meroshare PIN: ")
                if pin is None:
                    console.print(f"[{C_DIM}]Add cancelled.[/{C_DIM}]")
                    return
                if pin.isdigit() and pin.strip():
                    break
                console.print(f"[{C_ERROR}]PIN must be numeric. Got '{pin}'.[/{C_ERROR}]")

        else:
            print('Incorrect format. Type "help add" for help!')
            return

        capital_id = self.ms.capitals.get(dmat[3:8])

        if not capital_id:
            console.print(f"[{C_DATA}]Could not find capital ID for given DMAT.[/{C_DATA}]")
            console.print(f"[{C_DATA}]Updating capital list…[/{C_DATA}]")
            self.ms.update_capital_list()
            capital_id = self.ms.capitals.get(dmat[3:8])

        if not capital_id:
            console.print(f"[{C_DATA}]Could not find capital ID. Please enter it manually.[/{C_DATA}]")
            capital_id = Prompt.ask("Enter Capital ID")

        account = Account(dmat, password, int(pin), int(capital_id), crn, save=self.ms.save_data)

        try:
            account.get_details()
        except AssertionError as e:
            console.print(
                f"[{C_ERROR}]Account setup failed — invalid credentials or DMAT: {e}[/{C_ERROR}]"
            )
            return
        except LocalException as e:
            console.print(f"[{C_ERROR}]Failed to obtain details for account: {e}[/{C_ERROR}]")
            return
        except Exception as e:
            console.print(f"[{C_ERROR}]Unexpected error: {e}[/{C_ERROR}]")
            return

        self.ms.accounts.append(account)
        self.ms.save_data()
        logging.info(f"Successfully obtained details for account: {account.name}")
        console.print(
            f"[{C_SUCCESS}]✓ Account added successfully — {account.name} ({account.dmat})[/{C_SUCCESS}]"
        )

    # ------------------------------------------------------------------
    # remove
    # ------------------------------------------------------------------
    def help_remove(self):
        print("Remove an account!")
        print("Usage: remove")
        print("Then choose an account ID from the list!")

    def do_remove(self, args):
        """Remove an existing account."""
        if not self._require_accounts():
            return
        self.list_accounts()
        account = self._get_account()
        if account is None:
            return
        self.ms.accounts.remove(account)
        self.ms.save_data()
        console.print(f"[{C_PRIMARY}]Account removed.[/{C_PRIMARY}]")

    # ------------------------------------------------------------------
    # list helpers
    # ------------------------------------------------------------------
    def list_accounts_full(self):
        console.print(f"[{C_WARN}]⚠  WARNING: This will display passwords and PINs for all accounts.[/{C_WARN}]")
        confirm = Confirm.ask("Do you want to continue?", default=False)

        if confirm:
            table = Table(
                title=f"[bold {C_PRIMARY}]Accounts (Full Details)[/bold {C_PRIMARY}]",
                border_style=C_BORDER,
            )
            table.add_column("ID",       style=f"bold {C_PRIMARY}", no_wrap=True)
            table.add_column("Name",     style=C_VALUE)
            table.add_column("DMAT",     style=C_MUTED)
            table.add_column("Account",  style=C_MUTED)
            table.add_column("CRN",      style=C_MUTED)
            table.add_column("Password", style=C_VALUE)
            table.add_column("PIN",      style=C_VALUE)

            for idx, itm in enumerate(self.ms.accounts):
                table.add_row(
                    str(idx + 1),
                    itm.name,
                    itm.dmat,
                    itm.account,
                    itm.crn,
                    itm.password,
                    str(itm.pin),
                )
            console.print(table)

    def list_accounts(self):
        table = Table(
            title=f"[bold {C_PRIMARY}]Accounts[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("ID",      style=f"bold {C_PRIMARY}", no_wrap=True)
        table.add_column("Name",    style=C_VALUE)
        table.add_column("DMAT",    style=C_MUTED)
        table.add_column("Account", style=C_MUTED)
        table.add_column("CRN",     style=C_MUTED)
        table.add_column("Tag",     style=C_PRIMARY)

        for idx, itm in enumerate(self.ms.accounts):
            table.add_row(
                str(idx + 1),
                itm.name,
                itm.dmat,
                itm.account,
                itm.crn,
                itm.tag or "",
            )
        console.print(table)

    def list_application_reports(self):
        """Fetch and display application reports from the default account. Returns the raw list."""
        reports = self.ms.default_account.fetch_application_reports()

        table = Table(
            title=f"[bold {C_PRIMARY}]Application Reports[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("Share ID",     style=f"bold {C_PRIMARY}", no_wrap=True)
        table.add_column("Company Name", style=C_VALUE)
        table.add_column("Scrip",        style=C_PRIMARY)

        for itm in reversed(reports):
            table.add_row(
                str(itm.get("companyShareId")),
                itm.get("companyName"),
                itm.get("scrip"),
            )

        console.print(table)
        return reports

    def list_capitals(self):
        table = Table(
            title=f"[bold {C_PRIMARY}]Capitals[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("DPID", style=f"bold {C_PRIMARY}")
        table.add_column("ID",   style=C_DATA)

        for key, value in self.ms.capitals.items():
            table.add_row(str(key), str(value))
        console.print(table)

    # ------------------------------------------------------------------
    # portfolio
    # ------------------------------------------------------------------
    def help_portfolio(self):
        print("List portfolio of an account!")
        print("Usage: portfolio")
        print("       portfolio all")
        print()
        print("After selecting an account, keep entering IDs to view more.")
        print("Press ESC to exit.")

    def do_portfolio(self, args):
        """Show portfolio for one account or all accounts combined. ESC to exit."""
        if not self._require_accounts():
            return
        if args.strip() == "all":
            # ── all-accounts combined view (single shot, no loop needed) ──
            combined: dict[str, PortfolioEntry] = {}
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Fetching portfolios…", total=len(self.ms.accounts))
                for account in self.ms.accounts:
                    if len(account.portfolio.entries) == 0:
                        account.fetch_portfolio()
                    progress.update(task, advance=1)
                    for entry in account.portfolio.entries:
                        if entry.script in combined:
                            combined[entry.script].current_balance += entry.current_balance
                            combined[entry.script].value_as_of_last_transaction_price += (
                                entry.value_as_of_last_transaction_price
                            )
                            combined[entry.script].value_as_of_previous_closing_price += (
                                entry.value_as_of_previous_closing_price
                            )
                        else:
                            combined[entry.script] = PortfolioEntry.from_json(entry.to_json())
            self._print_portfolio_table(list(combined.values()), title="Combined Portfolio")
            return

        # ── per-account loop — stays open until ESC ──
        self.list_accounts()
        console.print(
            f"[{C_DIM}]Type a command to switch, or press ESC to exit.[/{C_DIM}]"
        )
        while True:
            raw = _prompt_or_esc("Choose an account ID: ")
            if raw is None:
                break
            raw = raw.strip()
            if not raw:
                continue

            # If the input looks like a command, hand it off and exit loop
            if self._intercept_command(raw):
                return

            try:
                idx = int(raw) - 1
                if not (0 <= idx < len(self.ms.accounts)):
                    raise IndexError
            except (ValueError, IndexError):
                console.print(
                    f"[{C_ERROR}]Invalid account ID '{raw}'. "
                    f"Enter a number between 1 and {len(self.ms.accounts)}, "
                    f"or press ESC to exit.[/{C_ERROR}]"
                )
                continue

            account = self.ms.accounts[idx]
            if len(account.portfolio.entries) == 0:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=console,
                ) as progress:
                    task = progress.add_task("Fetching portfolio…", total=1)
                    account.fetch_portfolio()
                    progress.update(task, advance=1)

            self._print_portfolio_table(account.portfolio.entries, title=f"Portfolio — {account.name}")

    def _print_portfolio_table(self, portfolio: list, title: str = "Portfolio") -> None:
        """Render a portfolio list as a Rich table."""
        total_value            = 0.0
        total_value_as_of_closing = 0.0
        for entry in portfolio:
            total_value               += entry.value_as_of_last_transaction_price
            total_value_as_of_closing += entry.value_as_of_previous_closing_price

        def _pct_change(last: float, prev: float) -> str:
            if prev == 0:
                return "N/A"
            return f"{(last - prev) / prev * 100:,.2f}%"

        table = Table(
            title=f"[bold {C_PRIMARY}]{title}[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("Scrip",            style=f"bold {C_PRIMARY}")
        table.add_column("Balance",          style=C_VALUE)
        table.add_column("Prev Closing",     style=C_MUTED)
        table.add_column("Last Transaction", style=C_MUTED)
        table.add_column("Value (Closing)",  style=C_MUTED)
        table.add_column("Value (Last)",     style=C_VALUE)
        table.add_column("+/- Amount",       style=C_VALUE)
        table.add_column("+/- %",            style=C_VALUE)

        for itm in portfolio:
            pct = _pct_change(
                itm.value_as_of_last_transaction_price,
                itm.value_as_of_previous_closing_price,
            )
            table.add_row(
                itm.script,
                str(itm.current_balance),
                f"{itm.previous_closing_price:,.1f}",
                f"{itm.last_transaction_price:,.1f}",
                f"{itm.value_as_of_previous_closing_price:,.1f}",
                f"{itm.value_as_of_last_transaction_price:,.1f}",
                f"{itm.value_as_of_last_transaction_price - itm.value_as_of_previous_closing_price:,.1f}",
                pct,
            )

        total_diff = total_value - total_value_as_of_closing
        total_diff_percent = (
            f"{total_diff / total_value_as_of_closing * 100:,.2f}%"
            if total_value_as_of_closing != 0
            else "N/A"
        )
        table.add_section()
        table.add_row(
            "[bold]Total[/bold]",
            "", "", "",
            f"{total_value_as_of_closing:,.1f}",
            f"{total_value:,.1f}",
            f"{total_diff:,.1f}",
            total_diff_percent,
            style=f"bold {C_TOTAL}",
        )
        console.print(table)

    # ------------------------------------------------------------------
    # list
    # ------------------------------------------------------------------
    def help_list(self):
        print("List accounts or capitals!")
        print("Usage: list { accounts | accounts full | capitals }")

    def do_list(self, args):
        """List accounts or capitals."""
        parts = args.split(" ")

        if len(parts) == 2 and parts[0] == "accounts" and parts[1] == "full":
            self.list_accounts_full()
        elif parts[0] == "accounts":
            self.list_accounts()
        elif parts[0] == "capitals":
            self.list_capitals()
        else:
            print('Incorrect format. Type "help list" for help!')

    # ------------------------------------------------------------------
    # select
    # ------------------------------------------------------------------
    def help_select(self):
        print("Selects accounts with specific tag to be used for further commands!")
        print("Usage: select {tag-name}")
        print("Usage: select all")

    def do_select(self, args):
        """Filter active accounts by tag for subsequent commands."""
        if not args.strip():
            print('Incorrect format. Type "help select" for help!')
            return

        parts = args.split(" ")

        if parts == ["all"]:
            self.ms.tag_selections = []
            self.prompt = _DEFAULT_PROMPT
        else:
            self.ms.tag_selections = parts
            self.prompt = (
                f"[bold {C_PRIMARY}]IPO ({','.join(self.ms.tag_selections)}) > "
                f"[/bold {C_PRIMARY}]"
            )

    # ------------------------------------------------------------------
    # sync
    # ------------------------------------------------------------------
    def help_sync(self):
        print("Syncs portfolio and application status for all accounts from MeroShare.")
        print("Usage: sync")
        print("Note: data is also auto-synced once per day on first login.")

    def do_sync(self, args):
        """Manually sync all accounts from MeroShare (always runs regardless of auto-sync)."""
        self._run_sync(auto=False)

    # ------------------------------------------------------------------
    # stats
    # ------------------------------------------------------------------
    def help_stats(self):
        print("Shows IPO application statistics for all accounts!")
        print("Usage: stats")
        print("       stats {account_id}  — jump straight to allotment details")
        print()
        print("Column meanings:")
        print("  Total Rejected   – applications with BLOCK_FAILED (payment block failed)")
        print("  Total Un-Allotted – result published, confirmed not allotted")
        print("  Total Allotted   – result published, confirmed allotted")
        print("  Pending          – result not yet published (alloted is None)")

    def _show_account_allotments(self, account) -> None:
        """Print a table of all allotted issues for a single account."""
        allotted = [iss for iss in account.issues if iss.alloted is True]

        if not allotted:
            console.print(
                f"[{C_WARN}]No allotments found for {account.name}.[/{C_WARN}]"
            )
            return

        detail_table = Table(
            title=f"[bold {C_PRIMARY}]Allotments — {account.name}[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        detail_table.add_column("Symbol",         style=f"bold {C_PRIMARY}")
        detail_table.add_column("Company",        style=C_VALUE, min_width=28)
        detail_table.add_column("Quantity",       style=C_DATA)
        detail_table.add_column("Share Type",     style=C_MUTED)
        detail_table.add_column("Applied Date",   style=C_MUTED, no_wrap=True)
        detail_table.add_column("Invested (NPR)", style=C_DATA)

        total_invested = 0.0

        for iss in sorted(allotted, key=lambda x: x.applied_date or "", reverse=True):
            invested_str = "—"
            try:
                if (
                    iss.applied_amount
                    and iss.applied_quantity
                    and int(iss.applied_quantity) > 0
                    and iss.alloted_quantity
                ):
                    issue_price  = float(iss.applied_amount) / int(iss.applied_quantity)
                    invested_val = issue_price * int(iss.alloted_quantity)
                    invested_str = f"{invested_val:,.2f}"
                    total_invested += invested_val
            except (ValueError, TypeError, ZeroDivisionError):
                pass

            applied_date_str = (iss.applied_date or "—").split("T")[0]

            detail_table.add_row(
                iss.symbol or "—",
                iss.name or "—",
                str(iss.alloted_quantity) if iss.alloted_quantity is not None else "—",
                iss.share_type or "—",
                applied_date_str,
                invested_str,
            )

        detail_table.add_section()
        detail_table.add_row(
            "[bold]Total[/bold]",
            "", "", "", "",
            f"{total_invested:,.2f}" if total_invested > 0 else "—",
            style=f"bold {C_TOTAL}",
        )

        console.print(detail_table)

    def do_stats(self, args):
        """Display IPO application statistics for all accounts."""
        if not self._require_accounts():
            return
        # ── If called with an account ID, jump straight to detail view ──
        if args.strip():
            try:
                idx = int(args.strip()) - 1
                if not (0 <= idx < len(self.ms.accounts)):
                    raise IndexError
            except (ValueError, IndexError):
                console.print(
                    f"[{C_ERROR}]Invalid account ID '{args.strip()}'. "
                    f"Please enter a number between 1 and {len(self.ms.accounts)}.[/{C_ERROR}]"
                )
                return
            self._show_account_allotments(self.ms.accounts[idx])
            return

        # ── Build per-account stats ──
        table = Table(
            title=f"[bold {C_PRIMARY}]Statistics[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("ID",                 style=f"bold {C_PRIMARY}", no_wrap=True)
        table.add_column("Name",               style=f"bold {C_PRIMARY}")
        table.add_column("Total Applied",      style=C_DATA)
        table.add_column("Total Rejected",     style=C_DATA)
        table.add_column("Total Un-Allotted",  style=C_DATA)
        table.add_column("Total Allotted",     style=C_DATA)
        table.add_column("Pending",            style=C_MUTED)
        table.add_column("% Allotted",         style=C_DATA)

        stats_data = []

        for idx, account in enumerate(self.ms.accounts):
            account_applied     = len(account.issues)
            account_allotted    = 0
            account_unallotted  = 0
            account_rejected    = 0
            account_pending     = 0

            for issue in account.issues:
                if issue.alloted is True:
                    account_allotted += 1
                elif issue.alloted is False:
                    account_unallotted += 1
                else:
                    account_pending += 1
                if issue.status == "BLOCK_FAILED":
                    account_rejected += 1

            allotted_pct = (
                f"{account_allotted / account_applied * 100:.2f}%"
                if account_applied > 0
                else "N/A"
            )

            stats_data.append([
                account_applied,
                account_rejected,
                account_unallotted,
                account_allotted,
                account_pending,
            ])
            table.add_row(
                str(idx + 1),
                account.name,
                str(account_applied),
                str(account_rejected),
                str(account_unallotted),
                str(account_allotted),
                str(account_pending) if account_pending > 0
                    else f"[{C_DIM}]0[/{C_DIM}]",
                allotted_pct,
            )

        total_applied     = sum(r[0] for r in stats_data)
        total_rejected    = sum(r[1] for r in stats_data)
        total_unallotted  = sum(r[2] for r in stats_data)
        total_allotted    = sum(r[3] for r in stats_data)
        total_pending     = sum(r[4] for r in stats_data)
        total_pct = (
            f"{total_allotted / total_applied * 100:.2f}%"
            if total_applied > 0
            else "N/A"
        )

        table.add_section()
        table.add_row(
            "",
            "[bold]Total[/bold]",
            str(total_applied),
            str(total_rejected),
            str(total_unallotted),
            str(total_allotted),
            str(total_pending),
            total_pct,
            style=f"bold {C_TOTAL}",
        )

        console.print(table)
        console.print(
            f"[{C_DIM}]Tip: type [bold {C_PRIMARY}]stats {{id}}[/bold {C_PRIMARY}]"
            f" (e.g. [bold {C_PRIMARY}]stats 1[/bold {C_PRIMARY}])"
            f" to view allotment details for an account.[/{C_DIM}]"
        )

        # ── Summary panel ──────────────────────────────────────────────
        total_portfolio_value         = 0.0
        total_portfolio_value_closing = 0.0

        for account in self.ms.accounts:
            for entry in account.portfolio.entries:
                total_portfolio_value         += entry.value_as_of_last_transaction_price
                total_portfolio_value_closing += entry.value_as_of_previous_closing_price

        summary_panel = Panel(
            f"[bold {C_PRIMARY}]Overall Summary[/bold {C_PRIMARY}]\n"
            f"[{C_DATA}]Total Applied IPOs:[/{C_DATA}]          {total_applied}\n"
            f"[{C_DATA}]Total Allotted:[/{C_DATA}]              {total_allotted}\n"
            f"[{C_DATA}]Total Un-Allotted:[/{C_DATA}]           {total_unallotted}\n"
            f"[{C_DATA}]Total Pending:[/{C_DATA}]               {total_pending}\n"
            f"[{C_DATA}]Success Rate:[/{C_DATA}]                {total_pct}\n"
            f"[{C_DATA}]Portfolio Value (Last):[/{C_DATA}]      {total_portfolio_value:,.2f}\n"
            f"[{C_DATA}]Portfolio Value (Closing):[/{C_DATA}]   {total_portfolio_value_closing:,.2f}",
            title=f"[bold {C_PRIMARY}]Summary[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
            padding=(1, 2),
        )
        console.print(summary_panel)

    # ------------------------------------------------------------------
    # status  (merged from former "result" + "status" commands)
    # ------------------------------------------------------------------
    def help_status(self):
        print("Check application status and allotment result for a specific share offering!")
        print("Usage: status       — shows the 5 most recent applications")
        print("       status all   — shows the full application list")
        print()
        print("After the list appears, enter a Share ID to fetch its details.")
        print("Keep entering Share IDs without re-running the command.")
        print("Press ESC to exit.")
        print()
        print("Allotted column meanings:")
        print("  Yes            – allotted (result published)")
        print("  No             – not allotted (result published)")
        print("  Not Published  – result has not been published yet")
        print("  N/A            – account did not apply for this offering")

    def do_status(self, args):
        """Check live application status and allotment result for a specific share offering."""
        if not self._require_accounts():
            return
        show_all = args.strip().lower() == "all"

        # ── Step 1: fetch live report list and display it ──────────────
        reports         = self.ms.default_account.fetch_application_reports()
        display_reports = reports if show_all else reports[:5]
        valid_ids       = {itm.get("companyShareId") for itm in reports}

        report_table = Table(
            title=(
                f"[bold {C_PRIMARY}]Application Reports"
                f"{'' if show_all else ' (recent 5)'}[/bold {C_PRIMARY}]"
            ),
            border_style=C_BORDER,
        )
        report_table.add_column("Share ID",     style=f"bold {C_PRIMARY}", no_wrap=True)
        report_table.add_column("Company Name", style=C_VALUE)
        report_table.add_column("Scrip",        style=C_PRIMARY)

        for itm in display_reports:
            report_table.add_row(
                str(itm.get("companyShareId")),
                itm.get("companyName"),
                itm.get("scrip"),
            )
        console.print(report_table)

        # Build a shareId → companyName lookup for table titles
        id_to_name = {
            itm.get("companyShareId"): itm.get("companyName", str(itm.get("companyShareId")))
            for itm in reports
        }

        if not show_all:
            console.print(
                f"[{C_DIM}]Showing 5 most recent. "
                f"Use [bold {C_PRIMARY}]status all[/bold {C_PRIMARY}] for the full list.[/{C_DIM}]"
            )
        console.print(
            f"[{C_DIM}]Type a command to switch, or press ESC to exit.[/{C_DIM}]"
        )

        # ── Step 2: loop — fetch live data per Share ID ─────────────────
        while True:
            raw = _prompt_or_esc("Enter Share ID: ")
            if raw is None:
                break
            raw = raw.strip()
            if not raw:
                continue

            if self._intercept_command(raw):
                return

            try:
                company_share_id_int = int(raw)
            except ValueError:
                console.print(
                    f"[{C_ERROR}]Expected a number, got '{raw}'. "
                    f"Try again or press ESC to exit.[/{C_ERROR}]"
                )
                continue

            if company_share_id_int not in valid_ids:
                console.print(
                    f"[{C_ERROR}]Share ID {company_share_id_int} is not in the list above. "
                    f"Try again or press ESC to exit.[/{C_ERROR}]"
                )
                continue

            company_name = id_to_name.get(company_share_id_int, str(company_share_id_int))

            rows: list[tuple[str, str, str, str, str]] = []

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task(
                    "Fetching live statuses…", total=len(self.ms.accounts)
                )

                for account in self.ms.accounts:
                    issue_ins = next(
                        (iss for iss in account.issues
                         if iss.company_share_id == company_share_id_int),
                        None,
                    )

                    try:
                        account.fetch_applied_issues_status(
                            company_id=company_share_id_int
                        )
                    except Exception as e:
                        logging.warning(
                            f"Could not refresh allotment for {account.name}: {e}"
                        )

                    issue_ins = next(
                        (iss for iss in account.issues
                         if iss.company_share_id == company_share_id_int),
                        None,
                    )

                    if issue_ins is None:
                        allotted_text = f"[{C_DIM}]N/A[/{C_DIM}]"
                        quantity_text = ""
                    elif issue_ins.alloted is True:
                        allotted_text = f"[bold {C_SUCCESS}]Yes[/bold {C_SUCCESS}]"
                        quantity_text = str(issue_ins.alloted_quantity)
                    elif issue_ins.alloted is False:
                        allotted_text = f"[{C_ERROR}]No[/{C_ERROR}]"
                        quantity_text = ""
                    else:
                        allotted_text = f"[{C_WARN}]Not Published[/{C_WARN}]"
                        quantity_text = ""

                    status_name   = "N/A"
                    status_detail = "N/A"
                    try:
                        acct_reports = account.fetch_application_reports()
                        form_id = next(
                            (
                                form.get("applicantFormId")
                                for form in acct_reports
                                if form.get("companyShareId") == company_share_id_int
                                and form.get("applicantFormId")
                            ),
                            None,
                        )
                        detailed      = account.fetch_application_status(form_id=form_id)
                        status_name   = detailed.get("statusName")   or "N/A"
                        status_detail = detailed.get("reasonOrRemark") or "N/A"
                    except LocalException as e:
                        logging.warning(f"Could not fetch status for {account.name}: {e}")
                    finally:
                        try:
                            account.logout()
                        except Exception as e:
                            logging.warning(f"Logout failed for {account.name}: {e}")
                        progress.update(task, advance=1)

                    rows.append((
                        account.name,
                        allotted_text,
                        quantity_text,
                        status_name,
                        status_detail,
                    ))

            result_table = Table(
                title=(
                    f"[bold {C_PRIMARY}]Live Status — "
                    f"{company_name}[/bold {C_PRIMARY}]"
                ),
                border_style=C_BORDER,
            )
            result_table.add_column("Name",     style=f"bold {C_PRIMARY}")
            result_table.add_column("Allotted", style=C_DATA)
            result_table.add_column("Quantity", style=C_DATA)
            result_table.add_column("Status",   style=C_VALUE)
            result_table.add_column("Detail",   style=C_MUTED)

            for row in rows:
                result_table.add_row(*row)

            console.print(result_table)

    # ------------------------------------------------------------------
    # tag
    # ------------------------------------------------------------------
    def help_tag(self):
        print("Tag an account to group them!")

    def do_tag(self, args):
        """Assign a tag to an account for grouping and filtering."""
        if not self._require_accounts():
            return
        self.list_accounts()

        account = self._get_account()
        if account is None:
            return

        tag = Prompt.ask(f"Set tag for account {account.name}")

        if tag == "" or tag == "all":
            console.print(f"[{C_ERROR}]Invalid tag '{tag}'. Leaving tag unchanged.[/{C_ERROR}]")
            return

        account.tag = tag
        self.ms.save_data()

    # ------------------------------------------------------------------
    # apply
    # ------------------------------------------------------------------
    def help_apply(self):
        print("Apply for shares")

    def do_apply(self, args):
        """Apply for an IPO or share offering across all (or selected) accounts."""
        if not self._require_accounts():
            return
        apply_table = []

        applicable_issues = self.ms.default_account.fetch_applicable_issues()

        table = Table(
            title=f"[bold {C_PRIMARY}]Applicable Issues[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("Share ID",     style=f"bold {C_PRIMARY}", no_wrap=True)
        table.add_column("Company Name", style=C_VALUE)
        table.add_column("Scrip",        style=C_PRIMARY)
        table.add_column("Type",         style=C_MUTED)
        table.add_column("Group",        style=C_MUTED)
        table.add_column("Close Date",   style=C_MUTED)

        for itm in applicable_issues:
            table.add_row(
                str(itm.get("companyShareId")),
                itm.get("companyName"),
                itm.get("scrip"),
                itm.get("shareTypeName"),
                itm.get("shareGroupName"),
                itm.get("issueCloseDate"),
            )

        console.print(table)
        company_to_apply = Prompt.ask("Enter Share ID")
        quantity         = Prompt.ask("Units to Apply")

        try:
            share_id_int  = int(company_to_apply)
            quantity_int  = int(quantity)
        except ValueError as e:
            console.print(f"[{C_ERROR}]Invalid input — expected numbers: {e}[/{C_ERROR}]")
            return

        valid_share_ids = {itm.get("companyShareId") for itm in applicable_issues}
        if share_id_int not in valid_share_ids:
            console.print(
                f"[{C_ERROR}]Share ID {share_id_int} is not in the list above.[/{C_ERROR}]"
            )
            return

        if quantity_int <= 0:
            console.print(f"[{C_ERROR}]Quantity must be a positive number.[/{C_ERROR}]")
            return

        summary_panel = Panel(
            f"[{C_DATA}]Share ID:[/{C_DATA}]  [bold]{company_to_apply}[/bold]\n"
            f"[{C_DATA}]Quantity:[/{C_DATA}]  [bold]{quantity}[/bold]\n"
            f"[{C_DATA}]Accounts:[/{C_DATA}]  [bold]{len(self.ms.accounts)}[/bold]",
            title=f"[bold {C_PRIMARY}]Confirm Application[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
            padding=(1, 2),
        )
        console.print(summary_panel)
        if not Confirm.ask("Apply for these accounts?", default=False):
            return

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Applying for IPO…", total=len(self.ms.accounts))

            for account in self.ms.accounts:
                try:
                    result = account.apply(
                        share_id=share_id_int, quantity=quantity_int
                    )
                except Exception as e:
                    logging.warning(f"Failed to apply for {account.name}: {e}")
                    result = {"status": "FAILED", "message": str(e)}
                finally:
                    try:
                        account.logout()
                    except Exception as e:
                        logging.warning(f"Failed to logout for {account.name}: {e}")

                applied_text = (
                    f"[bold {C_SUCCESS}]Yes[/bold {C_SUCCESS}]"
                    if result.get("status") == "CREATED"
                    else f"[{C_ERROR}]No[/{C_ERROR}]"
                )
                if result.get("status") == "CREATED":
                    self._session_applied = True
                apply_table.append([
                    account.name,
                    quantity,
                    applied_text,
                    result.get("message"),
                ])
                progress.update(task, advance=1)

        result_table = Table(
            title=f"[bold {C_PRIMARY}]Application Results[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        result_table.add_column("Name",     style=f"bold {C_PRIMARY}")
        result_table.add_column("Quantity", style=C_DATA)
        result_table.add_column("Applied",  style=C_DATA)
        result_table.add_column("Message",  style=C_DATA)

        for row in apply_table:
            result_table.add_row(*row)
        console.print(result_table)

    # ------------------------------------------------------------------
    # change
    # ------------------------------------------------------------------
    def help_change(self):
        print("Options:")
        print("lock     : Change IPO master password")
        print("password : Change an account's MeroShare password")
        print("export   : Change the export directory")

    def do_change(self, args):
        """Change the IPO lock password, an account's MeroShare password, or export directory."""
        parts = args.split(" ")

        if parts[0] == "lock":
            password = getpass(prompt="Enter new password for IPO: ")
            self.ms.fernet = self.ms.fernet_init(password)
            self.ms.save_data()
            console.print(f"[{C_PRIMARY}]Password changed successfully.[/{C_PRIMARY}]")
            sys.exit(0)

        elif parts[0] == "password":
            self.list_accounts()
            account = self._get_account()
            if account is None:
                return
            new_password = getpass(prompt=f"Enter new password for account {account.name}: ")
            account.password = new_password
            self.ms.save_data()
            console.print(f"[{C_PRIMARY}]Password updated for {account.name}.[/{C_PRIMARY}]")

        elif parts[0] == "export":
            self._prompt_and_save_export_dir()

        else:
            print('Unknown option. Type "help change" for help!')

    # ------------------------------------------------------------------
    # loglevel
    # ------------------------------------------------------------------
    def help_loglevel(self):
        print("Set logging level")
        print(f"Usage: loglevel {{ {' | '.join(_LOG_LEVELS)} }}")

    def do_loglevel(self, args):
        """Set the logging verbosity level (debug / info / warning / error / critical)."""
        level = _LOG_LEVELS.get(args.lower())
        if level is None:
            console.print(
                f"[{C_ERROR}]Invalid argument! "
                f"Choose from: {', '.join(_LOG_LEVELS)}[/{C_ERROR}]"
            )
            return

        self.ms.logging_level = level
        self.ms.save_data()
        console.print(
            f"[{C_PRIMARY}]Logging level set to {args}. Restart IPO to apply.[/{C_PRIMARY}]"
        )
        sys.exit(0)

    # ------------------------------------------------------------------
    # telegram
    # ------------------------------------------------------------------
    def help_telegram(self):
        print("Enable or disable telegram notifications")
        print("Usage: telegram {enable | disable}")

    def do_telegram(self, args):
        """Configure Telegram bot notifications (enable / disable)."""
        if args == "enable":
            token   = Prompt.ask("Enter Telegram bot token")
            chat_id = Prompt.ask("Enter Telegram chat ID")

            if not token or not chat_id:
                console.print(f"[{C_ERROR}]Invalid token or chat ID.[/{C_ERROR}]")
                return

            self.ms.telegram_bot_token = token
            self.ms.telegram_chat_id   = chat_id
            self.ms.save_data()
            console.print(f"[{C_PRIMARY}]Telegram notifications enabled.[/{C_PRIMARY}]")

        elif args == "disable":
            self.ms.telegram_bot_token = None
            self.ms.telegram_chat_id   = None
            self.ms.save_data()
            console.print(f"[{C_PRIMARY}]Telegram notifications disabled.[/{C_PRIMARY}]")

        else:
            print('Invalid argument. Type "help telegram" for help!')

    # ------------------------------------------------------------------
    # transactions
    # ------------------------------------------------------------------
    def help_transactions(self):
        print("Show transaction history for a specific stock or all stocks in an account.")
        print("Usage: transactions {account_id} {script}  — history for a specific script")
        print("       transactions {account_id} all       — full transaction history")
        print()
        print("Examples:")
        print("  transactions 2 NRN    — show NRN transactions for account 2")
        print("  transactions 2 all    — show all transactions for account 2")

    def _tx_type(self, desc: str) -> str:
        """Classify a transaction from its historyDesc."""
        d = desc.upper()
        if "INITIAL PUBLIC OFFERING" in d:
            return "IPO"
        if "CA-BONUS" in d:
            return "Bonus"
        if "CA-MERGER" in d:
            return "Merger"
        if "ON-CR" in d:
            return "Buy"
        if "ON-DR" in d:
            return "Sell"
        return "Other"

    def _print_transactions_table(
        self, txs: list, title: str, show_script: bool = False
    ) -> None:
        """Render a transaction list as a Rich table."""
        if not txs:
            console.print(f"[{C_WARN}]No transactions found.[/{C_WARN}]")
            return

        table = Table(
            title=f"[bold {C_PRIMARY}]{title}[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("Date",        style=C_MUTED, no_wrap=True)
        if show_script:
            table.add_column("Script", style=f"bold {C_PRIMARY}")
        table.add_column("Type",        style=C_VALUE)
        table.add_column("Credit",      style=C_SUCCESS)
        table.add_column("Debit",       style=C_ERROR)
        table.add_column("Balance",     style=C_DATA)
        table.add_column("Description", style=C_DIM)

        for tx in txs:
            date_str  = (tx.get("transactionDate") or "—").split("T")[0]
            tx_type   = self._tx_type(tx.get("historyDesc") or "")
            credit    = tx.get("creditQty", "-")
            debit     = tx.get("debitQty",  "-")
            balance   = str(tx.get("balAfterTrans", "—"))
            desc      = (tx.get("historyDesc") or "").strip()

            # Colour type
            type_colours = {
                "IPO":    C_SUCCESS,
                "Bonus":  C_WARN,
                "Buy":    C_PRIMARY,
                "Sell":   C_ERROR,
                "Merger": C_MUTED,
                "Other":  C_DIM,
            }
            colour    = type_colours.get(tx_type, C_DIM)
            type_rich = f"[{colour}]{tx_type}[/{colour}]"

            row = [date_str]
            if show_script:
                row.append(tx.get("script") or "—")
            row += [type_rich, credit, debit, balance, desc]
            table.add_row(*row)

        console.print(table)

    def do_transactions(self, args):
        """Show transaction history for a specific script or all scripts in an account."""
        if not self._require_accounts():
            return
        parts = args.strip().split()
        if len(parts) != 2:
            console.print(
                f"[{C_ERROR}]Usage: transactions {{account_id}} {{script|all}}[/{C_ERROR}]"
            )
            return

        account_id_str, script = parts
        try:
            idx = int(account_id_str) - 1
            if not (0 <= idx < len(self.ms.accounts)):
                raise IndexError
        except (ValueError, IndexError):
            console.print(
                f"[{C_ERROR}]Invalid account ID '{account_id_str}'. "
                f"Enter a number between 1 and {len(self.ms.accounts)}.[/{C_ERROR}]"
            )
            return

        account = self.ms.accounts[idx]

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Fetching transactions…", total=1)
            try:
                if script.lower() == "all":
                    txs = account.fetch_all_transaction_history()
                    title = f"All Transactions — {account.name}"
                    show_script = True
                else:
                    txs = account.fetch_transaction_history(script.upper())
                    title = f"Transactions — {script.upper()} ({account.name})"
                    show_script = False
                progress.update(task, advance=1)
            except Exception as e:
                progress.update(task, advance=1)
                console.print(f"[{C_ERROR}]Failed to fetch transactions: {e}[/{C_ERROR}]")
                return

        self._print_transactions_table(txs, title, show_script=show_script)

    do_transaction = do_transactions  # alias

    # ------------------------------------------------------------------
    # export
    # ------------------------------------------------------------------
    def help_export(self):
        print("Export portfolio, applications, or transaction history to CSV.")
        print("Usage: export {portfolio | applications | transactions {account_id}}")
        print("       change export  — update the saved export directory")
        print("Note: run 'sync' first to ensure data is up to date.")

    def _prompt_and_save_export_dir(self) -> str | None:
        """Ask the user for a valid export directory, save it, and return it."""
        console.print(
            f"[{C_DIM}]Enter the full path to the directory where exports should be saved.[/{C_DIM}]"
        )
        raw = Prompt.ask("Export directory")
        path = os.path.expanduser(raw.strip())
        if not os.path.isdir(path):
            console.print(
                f"[{C_ERROR}]Directory does not exist: {path}[/{C_ERROR}]"
            )
            return None
        self.meta.export_directory = path
        self.meta.save()
        console.print(f"[{C_PRIMARY}]Export directory saved: {path}[/{C_PRIMARY}]")
        return path

    def do_export(self, args):
        """Export portfolio holdings, IPO application history, or transaction history to a CSV file."""
        if not self._require_accounts():
            return
        parts = args.strip().split()
        if not parts:
            console.print(
                f"[{C_ERROR}]Usage: export {{portfolio | applications | transactions {{account_id}}}}[/{C_ERROR}]"
            )
            return

        export_type = parts[0].lower()
        if export_type not in ("portfolio", "applications", "transactions"):
            console.print(
                f'[{C_ERROR}]Invalid type. Use "portfolio", "applications", or "transactions {{account_id}}".[/{C_ERROR}]'
            )
            return

        # ── Resolve export directory ──────────────────────────────────
        export_dir = self.meta.export_directory

        if export_dir and not os.path.isdir(export_dir):
            console.print(
                f"[{C_WARN}]⚠  Saved export directory no longer exists: {export_dir}[/{C_WARN}]"
            )
            export_dir = None

        if not export_dir:
            export_dir = self._prompt_and_save_export_dir()
            if not export_dir:
                return

        date_str = datetime.now().strftime("%Y-%m-%d")

        # ── Transactions export (live API call) ───────────────────────
        if export_type == "transactions":
            if len(parts) < 2:
                console.print(
                    f"[{C_ERROR}]Usage: export transactions {{account_id}}[/{C_ERROR}]"
                )
                return
            try:
                idx = int(parts[1]) - 1
                if not (0 <= idx < len(self.ms.accounts)):
                    raise IndexError
            except (ValueError, IndexError):
                console.print(
                    f"[{C_ERROR}]Invalid account ID '{parts[1]}'.[/{C_ERROR}]"
                )
                return

            account = self.ms.accounts[idx]
            console.print(
                f"[{C_WARN}]⚠  Fetching live transaction data from MeroShare…[/{C_WARN}]"
            )
            try:
                csv_bytes = account.fetch_transaction_history_csv()
            except Exception as e:
                console.print(f"[{C_ERROR}]Failed to fetch transaction history: {e}[/{C_ERROR}]")
                return

            safe_name = (account.name or "account").replace(" ", "_")
            filename  = f"ipo_export_transactions_{safe_name}_{date_str}.csv"
            filepath  = os.path.join(export_dir, filename)
            with open(filepath, "wb") as f:
                f.write(csv_bytes)
            console.print(f"[{C_PRIMARY}]Exported transactions → {filepath}[/{C_PRIMARY}]")
            return

        # ── portfolio / applications (cached) ─────────────────────────
        console.print(
            f"[{C_WARN}]⚠  Exporting cached data. Run [bold]sync[/bold] first "
            f"if you need the latest figures.[/{C_WARN}]"
        )

        filename = f"ipo_export_{export_type}_{date_str}.csv"
        filepath = os.path.join(export_dir, filename)

        with open(filepath, "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.writer(csvfile)

            if export_type == "portfolio":
                writer.writerow([
                    "Account", "Scrip", "Balance",
                    "Previous Closing Price", "Last Transaction Price",
                    "Value as of Prev Closing", "Value",
                    "+/- Amount", "+/- %",
                ])
                for account in self.ms.accounts:
                    for entry in account.portfolio.entries:
                        pct_change = (
                            (entry.value_as_of_last_transaction_price
                             - entry.value_as_of_previous_closing_price)
                            / entry.value_as_of_previous_closing_price * 100
                            if entry.value_as_of_previous_closing_price != 0
                            else 0
                        )
                        writer.writerow([
                            account.name,
                            entry.script,
                            entry.current_balance,
                            entry.previous_closing_price,
                            entry.last_transaction_price,
                            entry.value_as_of_previous_closing_price,
                            entry.value_as_of_last_transaction_price,
                            entry.value_as_of_last_transaction_price
                            - entry.value_as_of_previous_closing_price,
                            f"{pct_change:.2f}%",
                        ])

            elif export_type == "applications":
                writer.writerow([
                    "Account", "Company Name", "Symbol", "Status",
                    "Share Type", "Applied Date", "Applied Quantity",
                    "Applied Amount", "Allotted", "Allotted Quantity",
                ])
                for account in self.ms.accounts:
                    for issue in account.issues:
                        writer.writerow([
                            account.name,
                            issue.name,
                            issue.symbol,
                            issue.status,
                            issue.share_type,
                            (issue.applied_date or "").split("T")[0],
                            issue.applied_quantity or "",
                            issue.applied_amount or "",
                            issue.alloted,
                            issue.alloted_quantity or "",
                        ])

        console.print(f"[{C_PRIMARY}]Exported {export_type} → {filepath}[/{C_PRIMARY}]")

    # ------------------------------------------------------------------
    # exit / clear / EOF / aliases
    # ------------------------------------------------------------------
    def do_exit(self, *args):
        """Exit the application."""
        import random

        _ALWAYS = [
            "Selling all holdings… just kidding. Bye!",
            "Mero share, mero choice. Bye!",
            "NEPSE ma pheri bhetaula.",
            "Dhanyabad. Ramro din hos!",
            "See you when the results drop.",
            "I'll miss you. Bye.",
            "Logout successful. I've seen better portfolios.",
            "Exiting… unlike your long-term holds.",
        ]

        _IF_APPLIED = [
            "IPO applied. Now we wait. Goodbye.",
            "Applications submitted. May the odds be ever in your favour.",
            "Applied and praying. See you on result day.",
        ]

        pool = _ALWAYS + (_IF_APPLIED if self._session_applied else [])
        console.print(f"[{C_DIM}]{random.choice(pool)}[/{C_DIM}]")
        return True

    def help_exit(self):
        print("Exit the application. Shortcuts: q or x")

    def do_EOF(self, args):
        return self.do_exit(args)

    def do_clear(self, args):
        """Clear the terminal screen."""
        os.system("cls" if os.name == "nt" else "clear")

    do_c       = do_clear

    # ── Silent aliases (not shown in help table) ──────────────────────
    do_cls     = do_clear   # cls  → clear
    do_stat    = do_stats   # stat → stats
    do_result  = do_status  # result  → status
    do_results = do_status  # results → status

    # ------------------------------------------------------------------
    # _intercept_command — shared by status / portfolio loops
    # ------------------------------------------------------------------
    def _intercept_command(self, raw: str) -> bool:
        """
        If `raw` is a valid command (including aliases), execute it and return True.
        The caller should `return` immediately after a True result.
        """
        cmd_word = raw.strip().split()[0].lower() if raw.strip() else ""
        if cmd_word and hasattr(self, f"do_{cmd_word}"):
            self.onecmd(raw.strip())
            return True
        return False

    # ------------------------------------------------------------------
    # help
    # ------------------------------------------------------------------
    def do_help(self, arg):
        """Show all available commands with descriptions."""
        if arg:
            return super().do_help(arg)

        _SKIP = {"c", "cls", "EOF", "result", "results", "stat", "transaction"}
        all_commands = []
        for attr in dir(self):
            if not attr.startswith("do_"):
                continue
            cmd_name = attr[3:]
            if cmd_name in _SKIP or cmd_name == "help":
                continue
            method   = getattr(self, attr)
            doc_line = (method.__doc__ or "").strip().split("\n")[0]
            all_commands.append((cmd_name, doc_line or "—"))

        all_commands.sort()

        table = Table(
            title=f"[bold {C_PRIMARY}]Available Commands[/bold {C_PRIMARY}]",
            border_style=C_BORDER,
        )
        table.add_column("Command",     style=f"bold {C_PRIMARY}", no_wrap=True)
        table.add_column("Description", style=C_DATA)

        for cmd, desc in all_commands:
            table.add_row(cmd, desc)

        console.print(table)
        console.print(
            f"[{C_DIM}]Tip: type [bold {C_PRIMARY}]help <command>[/bold {C_PRIMARY}]"
            f" for detailed usage on any command.[/{C_DIM}]"
        )

    def emptyline(self):
        """Do nothing on blank Enter (overrides Cmd default of repeating last command)."""
        pass

    def default(self, inp):
        if inp in ("x", "q"):
            return self.do_exit(inp)
        console.print(
            f"[{C_ERROR}]✗ Unknown command.[/{C_ERROR}]  "
            f"Type [bold {C_PRIMARY}]?[/bold {C_PRIMARY}] for help."
        )


# ------------------------------------------------------------------
# Non-interactive auto-apply mode
# ------------------------------------------------------------------
def _run_auto(password: str) -> None:
    """Non-interactive mode: apply for all eligible IPOs across all accounts."""
    if not password:
        console.print(f"[{C_ERROR}]Password not provided.[/{C_ERROR}]")
        sys.exit(1)

    ms: MeroShare = MeroShare.load(password)

    applicable_issues = ms.default_account.fetch_applicable_issues()

    has_applicable = False
    for issue in applicable_issues:
        if (
            issue.get("shareTypeName") == "IPO"
            and issue.get("shareGroupName") == "Ordinary Shares"
            and issue.get("subGroup") == "For General Public"
        ):
            has_applicable = True
            share_id = issue.get("companyShareId")

            try:
                min_unit = ms.default_account.find_min_apply_unit(share_id)
            except Exception as e:
                logging.warning(
                    f"Could not fetch min unit for share {share_id}, defaulting to 10: {e}"
                )
                min_unit = 10

            for account in ms.accounts:
                try:
                    account.apply(share_id=int(share_id), quantity=min_unit)
                except Exception as e:
                    logging.warning(f"Failed to apply for {account.dmat}: {e}")

    if not has_applicable:
        logging.info("No applicable issues found!")

    ms.save_data()

    for account in ms.accounts:
        account.fetch_applied_issues()
        account.fetch_applied_issues_status()

    ms.save_data()


def main():
    parser = argparse.ArgumentParser(description="NEPSE IPO CLI")
    parser.add_argument("--version", action="version", version=f"ayush-ipo {__version__}")
    parser.add_argument("--password", help="Password for auto_apply")
    parser.add_argument("--auto", action="store_true", help="Enable auto_apply mode")

    args = parser.parse_args()

    if args.auto and args.password:
        _run_auto(args.password)
    else:
        IPOApp().cmdloop()


if __name__ == "__main__":
    main()