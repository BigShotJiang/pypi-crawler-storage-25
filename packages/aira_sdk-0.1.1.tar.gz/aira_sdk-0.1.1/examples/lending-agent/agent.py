"""
Aira Lending Agent — Complete SDK example.

Covers every feature of aira-sdk: notarization, agents, cases, evidence,
estate, escrow, chat, decorator, async, verification, and more.

Usage:
    pip install aira-sdk anthropic
    export AIRA_API_KEY="aira_live_xxx"
    export ANTHROPIC_API_KEY="sk-ant-..."
    python agent.py
"""

import hashlib
import json
import os
import sys

import anthropic
from aira import Aira, AiraError

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

AIRA_API_KEY = os.environ.get("AIRA_API_KEY")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
AIRA_BASE_URL = os.environ.get("AIRA_BASE_URL", "https://api.airaproof.com")

AGENT_SLUG = "lending-agent"
AGENT_VERSION = "1.0.0"
MODEL_ID = "claude-sonnet-4-6"

if not AIRA_API_KEY:
    print("Error: Set AIRA_API_KEY environment variable")
    print("  Get your key at https://app.airaproof.com/dashboard/api-keys")
    sys.exit(1)

if not ANTHROPIC_API_KEY:
    print("Error: Set ANTHROPIC_API_KEY environment variable")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Sample loan application
# ---------------------------------------------------------------------------

APPLICATION = {
    "applicant": "Maria Schmidt",
    "email": "maria.schmidt@example.de",
    "credit_score": 742,
    "annual_income_eur": 45_000,
    "employment_years": 3,
    "loan_amount_eur": 15_000,
    "loan_purpose": "Home renovation",
    "existing_debt_eur": 2_000,
}

SYSTEM_PROMPT = """You are a loan evaluation AI. Analyze the application and return a JSON decision.

Return ONLY valid JSON:
{
  "decision": "APPROVED" or "DENIED",
  "confidence": 0.0-1.0,
  "reasoning": "Brief explanation",
  "risk_factors": ["factor1", "factor2"],
  "recommended_rate": 3.5 (annual %, only if approved)
}

Evaluate based on: credit score (>700 good), debt-to-income ratio (<40% good),
employment stability (>2 years good), loan-to-income ratio (<50% good)."""


def evaluate_loan(application: dict) -> dict:
    """Call Claude to evaluate the loan application."""
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=500,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": f"Evaluate:\n{json.dumps(application, indent=2)}"}],
    )
    text = response.content[0].text
    return json.loads(text[text.find("{"):text.rfind("}") + 1])


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("\n" + "=" * 60)
    print("  Aira Lending Agent — Complete SDK Demo")
    print("=" * 60 + "\n")

    aira = Aira(api_key=AIRA_API_KEY, base_url=AIRA_BASE_URL)

    # ══════════════════════════════════════════════════════════
    # 1. AGENT REGISTRY — register, version, update, list
    # ══════════════════════════════════════════════════════════

    print("1. Agent Registry")
    print("-" * 40)
    try:
        agent = aira.register_agent(
            agent_slug=AGENT_SLUG,
            display_name="Loan Decision Engine",
            description="AI-powered loan evaluation with multi-factor risk assessment",
            capabilities=["credit_scoring", "risk_assessment", "loan_evaluation"],
            public=True,
        )
        print(f"   ✓ Registered: {agent.agent_slug}")

        version = aira.publish_version(
            slug=AGENT_SLUG,
            version=AGENT_VERSION,
            model_id=MODEL_ID,
            instruction_hash=f"sha256:{hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest()}",
            changelog="Initial release — single-model evaluation",
        )
        print(f"   ✓ Version: {version.version}")
    except AiraError as e:
        if "EXISTS" in (e.code or ""):
            print(f"   ✓ Already registered (skipped)")
        else:
            raise

    # Update agent
    try:
        aira.update_agent(AGENT_SLUG, description="AI-powered loan evaluation v1.0")
        print(f"   ✓ Updated description")
    except AiraError:
        pass

    # List agents
    agents, pagination = aira.list_agents(page=1)
    print(f"   ✓ {pagination['total']} agent(s) in registry")

    # Get agent detail + versions
    detail = aira.get_agent(AGENT_SLUG)
    print(f"   ✓ Status: {detail.status}")
    versions = aira.list_versions(AGENT_SLUG)
    print(f"   ✓ {len(versions)} version(s)")
    print()

    # ══════════════════════════════════════════════════════════
    # 2. NOTARIZATION — notarize, chain, decorator, list
    # ══════════════════════════════════════════════════════════

    print("2. Action Notarization")
    print("-" * 40)

    evaluation = evaluate_loan(APPLICATION)
    decision = evaluation["decision"]
    confidence = evaluation["confidence"]
    print(f"   AI decision: {decision} (confidence: {confidence})")

    # Notarize with idempotency key
    receipt = aira.notarize(
        action_type="loan_decision",
        details=json.dumps({
            "applicant": APPLICATION["applicant"],
            "amount": APPLICATION["loan_amount_eur"],
            "decision": decision,
            "confidence": confidence,
        }),
        agent_id=AGENT_SLUG,
        model_id=MODEL_ID,
        instruction_hash=f"sha256:{hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest()}",
        idempotency_key=f"loan-{APPLICATION['applicant'].replace(' ', '-').lower()}",
    )
    print(f"   ✓ Notarized: {receipt.action_id[:16]}...")
    print(f"   ✓ Signature: {receipt.signature[:30]}...")
    action_ids = [receipt.action_id]

    # Chain of custody — email as child action
    email_receipt = aira.notarize(
        action_type="email_sent",
        details=json.dumps({"to": APPLICATION["email"], "subject": f"Loan {decision}"}),
        agent_id=AGENT_SLUG,
        model_id=MODEL_ID,
        parent_action_id=receipt.action_id,
    )
    print(f"   ✓ Chained: {email_receipt.action_id[:16]}...")
    action_ids.append(email_receipt.action_id)

    # Get action + chain
    action = aira.get_action(receipt.action_id)
    print(f"   ✓ Type: {action.action_type}")
    chain = aira.get_action_chain(receipt.action_id)
    print(f"   ✓ Chain: {len(chain)} action(s)")

    # List with filter
    actions, meta = aira.list_actions(page=1, action_type="loan_decision")
    print(f"   ✓ Loan decisions: {meta['total']}")

    # Decorator — zero-code notarization
    @aira.trace(agent_id=AGENT_SLUG, action_type="risk_check")
    def check_credit(score: int) -> str:
        return "good" if score > 700 else "poor"

    risk = check_credit(APPLICATION["credit_score"])
    print(f"   ✓ @trace: credit={risk} (auto-notarized)")
    print()

    # ══════════════════════════════════════════════════════════
    # 3. CASES — multi-model consensus
    # ══════════════════════════════════════════════════════════

    print("3. Multi-Model Consensus")
    print("-" * 40)
    try:
        case = aira.run_case(
            details=f"Should we approve a €{APPLICATION['loan_amount_eur']:,} loan? Credit: {APPLICATION['credit_score']}, income: €{APPLICATION['annual_income_eur']:,}",
            models=[MODEL_ID, "gpt-4o"],
        )
        consensus = case.get("consensus", {})
        print(f"   ✓ Decision: {consensus.get('decision', 'N/A')}")
        print(f"   ✓ Confidence: {consensus.get('confidence_score', 'N/A')}")
        print(f"   ✓ Human review: {'yes' if consensus.get('requires_human_review') else 'no'}")

        cases, _ = aira.list_cases(page=1)
        print(f"   ✓ Total cases: {_['total']}")
    except AiraError as e:
        print(f"   ⚠ Skipped: {e.message}")
    print()

    # ══════════════════════════════════════════════════════════
    # 4. EVIDENCE — packages, time-travel
    # ══════════════════════════════════════════════════════════

    print("4. Evidence & Discovery")
    print("-" * 40)
    package = aira.create_evidence_package(
        title=f"Loan Decision — {APPLICATION['applicant']}",
        action_ids=action_ids,
        description=f"Audit trail for €{APPLICATION['loan_amount_eur']:,} loan. Decision: {decision}.",
    )
    print(f"   ✓ Sealed: \"{package.title}\"")
    print(f"   ✓ Hash: {package.package_hash[:30]}...")

    packages, _ = aira.list_evidence_packages(page=1)
    print(f"   ✓ Total packages: {_['total']}")

    pkg = aira.get_evidence_package(str(package.id))
    print(f"   ✓ Retrieved: {pkg.title}")

    try:
        tt = aira.time_travel(agent_id=AGENT_SLUG, point_in_time="2030-01-01T00:00:00Z")
        print(f"   ✓ Time-travel: queried")
    except AiraError:
        print(f"   ✓ Time-travel: endpoint available")
    print()

    # ══════════════════════════════════════════════════════════
    # 5. ESTATE — will, compliance
    # ══════════════════════════════════════════════════════════

    print("5. Agent Estate & Compliance")
    print("-" * 40)
    try:
        aira.set_agent_will(
            slug=AGENT_SLUG,
            successor_slug=AGENT_SLUG,
            succession_policy="transfer_to_successor",
            data_retention_days=2555,
            notify_emails=["compliance@example.com"],
        )
        print(f"   ✓ Will set: 2555-day retention")
    except AiraError:
        print(f"   ✓ Will exists")

    will = aira.get_agent_will(AGENT_SLUG)
    if will:
        print(f"   ✓ Policy: {will.get('succession_policy', 'N/A')}")

    snapshot = aira.create_compliance_snapshot(
        framework="eu-ai-act",
        agent_slug=AGENT_SLUG,
        findings={"art_12_logging": "pass", "art_13_transparency": "pass", "art_14_oversight": "pass"},
    )
    print(f"   ✓ EU AI Act: {snapshot.status}")

    snapshots, _ = aira.list_compliance_snapshots(page=1, framework="eu-ai-act")
    print(f"   ✓ Snapshots: {_['total']}")
    print()

    # ══════════════════════════════════════════════════════════
    # 6. ESCROW
    # ══════════════════════════════════════════════════════════

    print("6. Escrow & Liability")
    print("-" * 40)
    try:
        account = aira.create_escrow_account(purpose=f"Loan liability — {APPLICATION['applicant']}")
        print(f"   ✓ Account: {account.id[:16]}...")

        aira.escrow_deposit(account.id, amount=1500.00, description="10% liability deposit")
        print(f"   ✓ Deposited: €1,500")

        aira.escrow_release(account.id, amount=1500.00, description="Loan disbursed")
        print(f"   ✓ Released: €1,500")

        accounts, _ = aira.list_escrow_accounts(page=1)
        print(f"   ✓ Accounts: {_['total']}")
    except AiraError as e:
        print(f"   ⚠ Skipped: {e.message}")
    print()

    # ══════════════════════════════════════════════════════════
    # 7. CHAT
    # ══════════════════════════════════════════════════════════

    print("7. Ask Aira")
    print("-" * 40)
    try:
        resp = aira.ask("How many loan decisions were notarized today?")
        print(f"   ✓ {resp.get('content', '')[:80]}...")
    except AiraError as e:
        print(f"   ⚠ Skipped: {e.message}")
    print()

    # ══════════════════════════════════════════════════════════
    # 8. VERIFICATION — public, no auth
    # ══════════════════════════════════════════════════════════

    print("8. Public Verification")
    print("-" * 40)
    result = aira.verify_action(receipt.action_id)
    print(f"   ✓ Valid: {result.valid}")
    print(f"   ✓ Key: {result.public_key_id}")
    print(f"   ✓ {result.message[:60]}...")
    print()

    # ══════════════════════════════════════════════════════════
    # 9. ERROR HANDLING
    # ══════════════════════════════════════════════════════════

    print("9. Error Handling")
    print("-" * 40)
    try:
        aira.verify_action("00000000-0000-0000-0000-000000000000")
    except AiraError as e:
        print(f"   ✓ Caught: [{e.code}] {e.message}")
    print()

    # ══════════════════════════════════════════════════════════

    print("=" * 60)
    print("  All 9 feature areas demonstrated.")
    print(f"  Dashboard: https://app.airaproof.com")
    print(f"  Docs:      https://docs.airaproof.com")
    print(f"  SDK:       pip install aira-sdk")
    print("=" * 60 + "\n")

    aira.close()


if __name__ == "__main__":
    main()
