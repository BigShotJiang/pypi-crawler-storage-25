"""
tui/app.py

App principal da TUI do UpaPasta.

Requer: pip install upapasta[tui]
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from textual import events, on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Footer, Header, Input, Label, Tree

from .catalog_index import load_catalog
from .screens.confirm import ConfirmScreen
from .screens.pattern_select import PatternSelectScreen, RuleKind, SelectionRule
from .screens.upload_progress import UploadProgressScreen
from .status import UploadStatus
from .widgets.dashboard import DashboardWidget
from .widgets.file_tree import FileTreeWidget
from .widgets.status_bar import StatusBar


class _QuitConfirmScreen(ModalScreen[bool]):
    """Modal de confirmação de saída quando há itens selecionados."""

    DEFAULT_CSS = """
    _QuitConfirmScreen { align: center middle; }
    #quit-dialog {
        background: $surface;
        border: thick $warning;
        padding: 1 2;
        width: 52;
        height: auto;
    }
    #quit-title { text-style: bold; color: $warning; margin-bottom: 1; }
    #quit-buttons { height: auto; align: right middle; margin-top: 1; }
    Button { margin-left: 1; }
    """

    def __init__(self, count: int) -> None:
        super().__init__()
        self._count = count

    def compose(self) -> ComposeResult:
        s = "s" if self._count != 1 else ""
        with Vertical(id="quit-dialog"):
            yield Label("Confirmar saída", id="quit-title")
            yield Label(f"Você tem {self._count} item{s} selecionado{s}.\nDeseja sair mesmo assim?")
            with Horizontal(id="quit-buttons"):
                yield Button("Cancelar", variant="default", id="btn-no")
                yield Button("Sair", variant="error", id="btn-yes")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "btn-yes")


class UpaPastaApp(App[None]):
    """Gerenciador visual de uploads Usenet."""

    TITLE = "UpaPasta"
    SUB_TITLE = "Gerenciador de Uploads Usenet"

    BINDINGS = [
        Binding("q", "quit_safe", "Sair", priority=True),
        Binding("r", "refresh", "Atualizar"),
        Binding("d", "toggle_dashboard", "Dashboard", priority=True),
        Binding("u", "upload", "Upload", show=True),
        Binding("p", "pattern_select", "Padrão", show=True),
        Binding("1", "filter_pending", "Pendentes", show=True),
        Binding("2", "filter_uploaded", "Enviados", show=True),
        Binding("3", "filter_partial", "Parciais", show=True),
        Binding("0", "filter_all", "Todos", show=True),
        Binding("x", "check_indexer", "Buscar indexador", show=True),
    ]

    CSS = """
    Screen {
        background: $surface;
    }

    #main-area {
        height: 1fr;
        width: 100%;
    }

    FileTreeWidget {
        width: 1fr;
        height: 100%;
        scrollbar-gutter: stable;
    }

    #search-input {
        dock: bottom;
        height: 3;
        margin: 0;
        border: tall $accent;
        display: none;
    }

    StatusBar {
        dock: bottom;
        height: 1;
        padding: 0 1;
        background: $panel-darken-1;
        color: $text-muted;
    }

    Footer {
        background: $panel;
    }
    """

    def __init__(self, root_path: Path) -> None:
        super().__init__()
        self.root_path = root_path

        from ..config import load_env_file, resolve_env_file

        env_vars = load_env_file(resolve_env_file())
        nzb_dirs_raw = env_vars.get("EXTERNAL_NZB_DIR", "")
        nzb_paths = [Path(p.strip()) for p in nzb_dirs_raw.split(",") if p.strip()]

        self._index = load_catalog(external_nzb_paths=nzb_paths)
        self._filter: Optional[UploadStatus] = None
        self._selection_count: int = 0

    # ── Composição ────────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main-area"):
            yield FileTreeWidget(
                self.root_path,
                self._index,
                id="file-tree",
            )
            yield DashboardWidget(self._index, self.root_path, id="dashboard")
        yield Input(placeholder="Buscar... (Enter ou Esc para fechar)", id="search-input")
        yield StatusBar(id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        self.sub_title = str(self.root_path)
        self.query_one(FileTreeWidget).focus()

    # ── Eventos ───────────────────────────────────────────────────────────────

    @on(Tree.NodeHighlighted)
    def _on_node_highlighted(self, event: Tree.NodeHighlighted[None]) -> None:
        file_node = event.node.data  # type: ignore[union-attr]
        self.query_one(StatusBar).update_node(file_node)  # type: ignore[arg-type]

    @on(Input.Changed, "#search-input")
    def _on_search_changed(self, event: Input.Changed) -> None:
        self.query_one(FileTreeWidget).set_search(event.value)

    @on(Input.Submitted, "#search-input")
    def _on_search_submitted(self, event: Input.Submitted) -> None:
        self._hide_search()

    @on(FileTreeWidget.SelectionChanged)
    def _on_selection_changed(self, event: FileTreeWidget.SelectionChanged) -> None:
        self._selection_count = len(event.selected)
        self._update_subtitle()

    def on_key(self, event: events.Key) -> None:
        search = self.query_one("#search-input", Input)

        if event.key == "slash" and not search.display:
            search.display = True
            search.focus()
            event.stop()
        elif event.key == "escape" and search.display:
            self._hide_search()
            event.stop()

    # ── Actions ───────────────────────────────────────────────────────────────

    @work
    async def action_quit_safe(self) -> None:
        """Sai imediatamente ou pede confirmação se há itens selecionados."""
        if self._selection_count > 0:
            confirmed = await self.push_screen_wait(_QuitConfirmScreen(self._selection_count))
            if not confirmed:
                return
        self.exit()

    def action_refresh(self) -> None:
        self._index.load()
        self.query_one(FileTreeWidget).reload()
        dash = self.query_one(DashboardWidget)
        if dash.display:
            dash.refresh_data()
        self.notify("Catálogo recarregado", severity="information", timeout=2)

    def action_toggle_dashboard(self) -> None:
        dash = self.query_one(DashboardWidget)
        dash.display = not dash.display
        if dash.display:
            self._index.load()
            dash.refresh_data()

    def action_pattern_select(self) -> None:
        self._open_pattern_select()

    @work
    async def _open_pattern_select(self) -> None:
        tree = self.query_one(FileTreeWidget)
        visible_names = [n.name for n in tree.selected_nodes()] or [
            fn.name
            for fn in (node.data for node in tree.query("TreeNode"))  # type: ignore[misc]
            if fn and not fn.is_dir  # type: ignore[union-attr]
        ]
        rule: SelectionRule | None = await self.push_screen_wait(PatternSelectScreen(visible_names))
        if rule is None:
            return
        tree = self.query_one(FileTreeWidget)
        if rule.kind == RuleKind.STATUS_PENDING:
            tree.select_by_status(UploadStatus.PENDING)
        elif rule.kind == RuleKind.STATUS_FAILED:
            tree.select_by_status(UploadStatus.FAILED)
        elif rule.kind == RuleKind.MIN_SIZE_GB:
            tree.select_by_min_size(int(rule.value))  # type: ignore[arg-type]
        elif rule.kind == RuleKind.SEASON_PATTERN:
            tree.select_by_pattern(r"S\d{2}")
        elif rule.kind == RuleKind.REGEX:
            tree.select_by_pattern(str(rule.value))

    def action_filter_pending(self) -> None:
        self._apply_filter(UploadStatus.PENDING)

    def action_filter_uploaded(self) -> None:
        self._apply_filter(UploadStatus.UPLOADED)

    def action_filter_partial(self) -> None:
        self._apply_filter(UploadStatus.PARTIAL)

    def action_filter_all(self) -> None:
        self._apply_filter(None)

    def action_check_indexer(self) -> None:
        """Dispara busca em background de todos os itens visíveis no indexador."""
        self.query_one(FileTreeWidget).start_indexer_search()

    def action_upload(self) -> None:
        items = self.query_one(FileTreeWidget).selected_nodes()
        if not items:
            self.notify("Selecione ao menos um item com Space", severity="warning", timeout=3)
            return
        self._run_upload_flow(items)

    @work
    async def _run_upload_flow(self, items: list) -> None:
        config = await self.push_screen_wait(ConfirmScreen(items))
        if config is None:
            return
        await self.push_screen_wait(UploadProgressScreen(items, config))
        tree = self.query_one(FileTreeWidget)
        tree.clear_selection()
        tree.reload()
        dash = self.query_one(DashboardWidget)
        if dash.display:
            self._index.load()
            dash.refresh_data()

    # ── Internals ────────────────────────────────────────────────────────────

    def _apply_filter(self, status: Optional[UploadStatus]) -> None:
        self._filter = status
        self.query_one(FileTreeWidget).set_filter(status)
        self._update_subtitle()
        if status is not None:
            self.notify(f"Filtro: {status.label}", severity="information", timeout=2)

    def _hide_search(self) -> None:
        search = self.query_one("#search-input", Input)
        search.display = False
        search.clear()
        tree = self.query_one(FileTreeWidget)
        tree.set_search("")
        tree.focus()

    def _update_subtitle(self) -> None:
        parts: list[str] = [str(self.root_path)]
        if self._filter is not None:
            parts.append(f"Filtro: {self._filter.label}")
        if self._selection_count > 0:
            s = "s" if self._selection_count != 1 else ""
            parts.append(f"{self._selection_count} selecionado{s}")
        self.sub_title = "  —  ".join(parts)


# ── Entry points ─────────────────────────────────────────────────────────────


def run_tui(root_path: Optional[Path] = None) -> None:
    """Inicia a TUI no diretório fornecido (padrão: cwd)."""
    if root_path is None:
        root_path = Path.cwd()
    root_path = root_path.resolve()
    if not root_path.is_dir():
        print(f"❌ Não é um diretório: {root_path}", file=sys.stderr)
        sys.exit(1)
    UpaPastaApp(root_path=root_path).run()


def run_tui_cli() -> None:
    """Entry point standalone: upapasta-tui [caminho]"""
    args = sys.argv[1:]
    root_path = Path(args[0]).resolve() if args else Path.cwd()
    run_tui(root_path=root_path)
