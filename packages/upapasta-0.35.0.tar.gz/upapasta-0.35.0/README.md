# UpaPasta

[Português (pt-BR)](README.pt-BR.md)

**Automated Usenet Uploader.** One command, full pipeline: PAR2 → upload → NZB ready.

```bash
upapasta /tv/Night.of.the.Living.Dead.S01/
```

[![PyPI](https://img.shields.io/pypi/v/upapasta)](https://pypi.org/project/upapasta/)
[![CI](https://github.com/franzopl/upapasta/actions/workflows/ci.yml/badge.svg)](https://github.com/franzopl/upapasta/actions)
[![Python](https://img.shields.io/pypi/pyversions/upapasta)](https://pypi.org/project/upapasta/)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue)](LICENSE)

---

## What it does

- Generates PAR2 with redundancy profiles (5 / 10 / 20%)
- Uploads via nyuu without staging in `/tmp` (direct paths)
- Delivers NZB + NFO with video metadata
- (Optional) Creates RAR5 or 7z with password before upload
- Logs everything in a centralized history (JSONL)
- Cross-platform: works on Linux, macOS, and Windows

---

## Installation

### 🚀 Portable (Windows / Linux)
**Recommended for most users.** Download the latest ZIP from [Releases](https://github.com/franzopl/upapasta/releases), extract and run. No Python or Node.js required.

### 📦 Via pip
```bash
pip install upapasta
```

**System dependencies (if not using Portable):**

| Binary | Function | Status | Install |
|---------|--------|----------|----------|
| `nyuu` | NNTP Upload | Mandatory | `npm install -g nyuu` |
| `parpar` | PAR2 Generation | Mandatory | `npm install -g @animetosho/parpar` |
| `7z` | Packaging | **Default** | `apt install p7zip-full` |
| `rar` | RAR5 support | Optional | `apt install rar` (or auto-download) |
| `ffprobe` | Video metadata | Optional | `apt install ffmpeg` |
| `mediainfo` | Technical info | Optional | `apt install mediainfo` |


See [INSTALL.md](INSTALL.md) for detailed instructions per platform.

---

## Configuration

On the first run, an interactive wizard creates your configuration file:

```bash
upapasta --config
```

- **Linux/macOS:** `~/.config/upapasta/.env`
- **Windows:** `%APPDATA%\upapasta\.env`

---

## Use cases

| Case | Command |
|------|---------|
| Entire folder | `upapasta Folder/` |
| Single file | `upapasta Episode.S01E01.mkv` |
| Reversible obfuscation | `upapasta Folder/ --obfuscate` |
| Pack + Password (default) | `upapasta Folder/ --password "abc123"` |
| Force 7z | `upapasta Folder/ --7z` |
| Force RAR | `upapasta Folder/ --rar` |
| Each file = release | `upapasta /tv/Show.S04/ --each` |
| Season + Single NZB | `upapasta /tv/Show.S04/ --season` |
| Daemon (watch folder) | `upapasta /downloads/ --watch` |
| Resume interrupted upload | `upapasta Folder/ --resume` |

---

## Recommended Workflow 2026

RAR/7z is no longer necessary for most cases. parpar stores the folder hierarchy in `.par2` files, and recent SABnzbd/NZBGet versions rebuild the tree upon download:

```bash
upapasta Folder/ --obfuscate --par-profile safe
```

Use packaging (`--compress`, `--rar` or `--7z`) only when you need a password or when the downloader does not support folder reconstruction via PAR2.

### Obfuscation

Since v0.28.0, the `--obfuscate` flag provides maximum stealth by default:
- Files and PAR2 volumes are renamed to random strings.
- NZB subjects are obfuscated (protected from indexer "peepers").
- NZB file headers allow downloaders to restore original names automatically.

---

## Main options

```
-c, --compress           Activate packaging using default compressor from .env
--rar                    Force RAR5 packaging (ignores .env)
--7z                     Force 7z packaging (ignores .env)
--password PASSWORD      Encryption password (uses default compressor if unspecified)
--obfuscate              Maximum privacy: random names for everything
--tmdb                   Enrich NFO with TMDb metadata (requires API Key)
--tmdb-search TERMO      Search TMDb and list IDs (utility)
--par-profile PROFILE    fast (5%) · balanced (10%) · safe (20%)
--jobs N                 Parallel uploads for multiple inputs
--resume                 Resume interrupted upload
--dry-run                Simulate without sending
--skip-upload            Generate files without uploading
--each                   Each file in folder = separate release
--season                 Like --each + single season NZB
--watch                  Daemon: automatically process new items
```

`upapasta --help` lists all options with full descriptions.

---

## History and statistics

```bash
# Last 5 uploads
tail -5 ~/.config/upapasta/history.jsonl | python3 -m json.tool

# Aggregated statistics
upapasta --stats

# Archived NZBs (hardlinks by timestamp)
ls -la ~/.config/upapasta/nzb/
```

---

## Webhooks and hooks

Configure post-upload notifications in `.env`:

```ini
# Discord, Slack, Telegram or any endpoint accepting POST JSON
WEBHOOK_URL=https://discord.com/api/webhooks/...

# External script (receives UPAPASTA_* variables)
POST_UPLOAD_SCRIPT=/home/user/notify.sh
```

See [DOCS.md § Hooks and webhooks](DOCS.md#10-hooks-and-webhooks) for the full list of variables.

---

## Documentation

- **[DOCS.md](DOCS.md)** — full reference: configuration, pipeline, flags, obfuscation, PAR2, multiple servers, resume, catalog, hooks
- **[docs/FAQ.md](docs/FAQ.md)** — frequent errors and direct answers
- **[docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** — symptom-based diagnosis
- **[INSTALL.md](INSTALL.md)** — dependency installation per platform
- **[CHANGELOG.md](CHANGELOG.md)** — version history

---

## License

MIT — see [LICENSE](LICENSE).

Developed by **franzopl**.
