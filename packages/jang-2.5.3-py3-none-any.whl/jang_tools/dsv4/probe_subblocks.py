"""Fast sub-block probe."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np, torch
import mlx.core as mx

from jang_tools.dsv4 import mlx_register
from jang_tools.dsv4.mlx_model import ModelArgs as MLXArgs, DeepseekV4DecoderLayer
from jang_tools.dsv4.layer_forward import DSV4Config, Block, load_block_from_shards
from jang_tools.dsv4.weight_loader import ShardIndex
from jang_tools.dsv4.ops import precompute_freqs_cis


def diff(name, a, b):
    an = np.array(a, copy=False).astype(np.float32) if isinstance(a, mx.array) else a.detach().float().numpy()
    bn = b.detach().float().numpy() if isinstance(b, torch.Tensor) else np.array(b, copy=False).astype(np.float32)
    if an.shape != bn.shape:
        print(f"  [{name}] SHAPE: {an.shape} vs {bn.shape}"); return
    d = np.abs(an - bn)
    print(f"  [{name:28}] max={d.max():.4g}  mean={d.mean():.4g}  "
          f"a_rng=[{an.min():.3g},{an.max():.3g}]  b_rng=[{bn.min():.3g},{bn.max():.3g}]")


def _to_mx16(t):
    return mx.array(t.detach().float().numpy().astype(np.float16))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, type=Path)
    ap.add_argument("--layer", type=int, default=3)
    args = ap.parse_args()

    src_idx = ShardIndex(args.source)
    cfg_json = json.loads((args.source / "config.json").read_text())
    torch_cfg = DSV4Config.from_config_json(cfg_json)
    torch_blk = load_block_from_shards(args.layer, torch_cfg, src_idx).eval()

    mlx_cfg_fields = {f.name for f in MLXArgs.__dataclass_fields__.values()}
    mlx_cfg = MLXArgs(**{k: v for k, v in cfg_json.items() if k in mlx_cfg_fields})
    mlx_layer = DeepseekV4DecoderLayer(mlx_cfg, layer_id=args.layer)

    def cp(mx_mod, torch_linear):
        mx_mod.weight = _to_mx16(torch_linear.weight)
    def cpn(mx_n, torch_n):
        mx_n.weight = _to_mx16(torch_n.weight)

    cp(mlx_layer.self_attn.wq_a, torch_blk.attn.wq_a)
    cpn(mlx_layer.self_attn.q_norm, torch_blk.attn.q_norm)
    cp(mlx_layer.self_attn.wq_b, torch_blk.attn.wq_b)
    cp(mlx_layer.self_attn.wkv, torch_blk.attn.wkv)
    cpn(mlx_layer.self_attn.kv_norm, torch_blk.attn.kv_norm)
    cp(mlx_layer.self_attn.wo_a, torch_blk.attn.wo_a)
    cp(mlx_layer.self_attn.wo_b, torch_blk.attn.wo_b)
    mlx_layer.self_attn.attn_sink = _to_mx16(torch_blk.attn.attn_sink)
    cpn(mlx_layer.input_layernorm, torch_blk.attn_norm)
    cpn(mlx_layer.post_attention_layernorm, torch_blk.ffn_norm)
    for attr in ("hc_attn_fn", "hc_ffn_fn", "hc_attn_base", "hc_ffn_base", "hc_attn_scale", "hc_ffn_scale"):
        setattr(mlx_layer, attr, _to_mx16(getattr(torch_blk, attr)))
    mlx_layer.mlp.gate.weight = _to_mx16(torch_blk.ffn.gate.weight)
    if torch_blk.ffn.gate.bias is not None:
        mlx_layer.mlp.gate.bias = _to_mx16(torch_blk.ffn.gate.bias)
    cp(mlx_layer.mlp.shared_experts.gate_proj, torch_blk.ffn.shared_experts.w1)
    cp(mlx_layer.mlp.shared_experts.down_proj, torch_blk.ffn.shared_experts.w2)
    cp(mlx_layer.mlp.shared_experts.up_proj, torch_blk.ffn.shared_experts.w3)
    n_e = mlx_cfg.n_routed_experts
    mlx_layer.mlp.switch_mlp.gate_proj.weight = _to_mx16(
        torch.stack([torch_blk.ffn.experts[e].w1.weight for e in range(n_e)]))
    mlx_layer.mlp.switch_mlp.down_proj.weight = _to_mx16(
        torch.stack([torch_blk.ffn.experts[e].w2.weight for e in range(n_e)]))
    mlx_layer.mlp.switch_mlp.up_proj.weight = _to_mx16(
        torch.stack([torch_blk.ffn.experts[e].w3.weight for e in range(n_e)]))

    # Same input
    torch.manual_seed(0); np.random.seed(0)
    B, L = 1, 8
    x_np = np.random.randn(B, L, torch_cfg.hc_mult, torch_cfg.dim).astype(np.float32) * 0.02
    x_t = torch.from_numpy(x_np).to(torch.bfloat16)
    x_m = mx.array(x_np.astype(np.float16))
    ids_np = np.random.randint(0, torch_cfg.vocab_size, (B, L)).astype(np.int64)
    ids_t = torch.from_numpy(ids_np)
    ids_m = mx.array(ids_np.astype(np.int32))
    fc_t = precompute_freqs_cis(torch_cfg.rope_head_dim, L, torch_cfg.original_seq_len,
        torch_cfg.rope_theta, torch_cfg.rope_factor, torch_cfg.beta_fast, torch_cfg.beta_slow)

    print("\n=== Probe 1: hc_pre (attn branch) ===")
    with torch.inference_mode():
        y_pre_t, post_t, comb_t = torch_blk._hc_pre(x_t, torch_blk.hc_attn_fn,
                                                    torch_blk.hc_attn_scale, torch_blk.hc_attn_base)
    y_pre_m, post_m, comb_m = mlx_layer._hc_pre(x_m, mlx_layer.hc_attn_fn,
                                                 mlx_layer.hc_attn_scale, mlx_layer.hc_attn_base)
    mx.eval(y_pre_m); mx.eval(post_m); mx.eval(comb_m)
    diff("y_hc_pre", y_pre_m, y_pre_t)
    diff("post", post_m, post_t)
    diff("comb", comb_m, comb_t)

    print("\n=== Probe 2: attn input + attn output ===")
    x_in_t = torch_blk.attn_norm(y_pre_t)
    x_in_m = mlx_layer.input_layernorm(y_pre_m)
    diff("after_attn_norm", x_in_m, x_in_t)

    with torch.inference_mode():
        attn_out_t = torch_blk.attn(x_in_t, fc_t)
    attn_out_m = mlx_layer.self_attn(x_in_m, mask=None, cache=None)
    mx.eval(attn_out_m)
    diff("attn_out", attn_out_m, attn_out_t)

    print("\n=== Probe 3: MoE input + MoE output ===")
    # Construct identical ffn input: just x_in_t / x_in_m
    with torch.inference_mode():
        ffn_in_t = torch_blk.ffn_norm(y_pre_t + 0.01)
        moe_out_t = torch_blk.ffn(ffn_in_t, ids_t)
    ffn_in_m = mlx_layer.post_attention_layernorm(y_pre_m + 0.01)
    moe_out_m = mlx_layer.mlp(ffn_in_m, input_ids=ids_m)
    mx.eval(moe_out_m)
    diff("ffn_in", ffn_in_m, ffn_in_t)
    diff("moe_out", moe_out_m, moe_out_t)


if __name__ == "__main__":
    sys.exit(main())
