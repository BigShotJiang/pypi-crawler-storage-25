"""Deep probe of attention forward — every intermediate."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np, torch
import mlx.core as mx

from jang_tools.dsv4 import mlx_register
from jang_tools.dsv4.mlx_model import (
    ModelArgs as MLXArgs, DeepseekV4DecoderLayer,
    _mlx_apply_rotary_cis,
)
from jang_tools.dsv4.layer_forward import DSV4Config, load_block_from_shards
from jang_tools.dsv4.weight_loader import ShardIndex
from jang_tools.dsv4.ops import precompute_freqs_cis, apply_rotary_emb


def diff(name, a, b):
    an = np.array(a, copy=False).astype(np.float32) if isinstance(a, mx.array) else a.detach().float().numpy()
    bn = b.detach().float().numpy() if isinstance(b, torch.Tensor) else np.array(b, copy=False).astype(np.float32)
    if an.shape != bn.shape:
        print(f"  [{name:28}] SHAPE: {an.shape} vs {bn.shape}"); return
    d = np.abs(an - bn)
    print(f"  [{name:28}] max={d.max():.4g}  mean={d.mean():.4g}  "
          f"a_rng=[{an.min():.3g},{an.max():.3g}]  b_rng=[{bn.min():.3g},{bn.max():.3g}]")


def _to_mx16(t):
    return mx.array(t.detach().float().numpy().astype(np.float16))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, type=Path)
    ap.add_argument("--layer", type=int, default=3)
    args = ap.parse_args()

    src_idx = ShardIndex(args.source)
    cfg_json = json.loads((args.source / "config.json").read_text())
    torch_cfg = DSV4Config.from_config_json(cfg_json)
    torch_blk = load_block_from_shards(args.layer, torch_cfg, src_idx).eval()
    attn_t = torch_blk.attn

    mlx_cfg_fields = {f.name for f in MLXArgs.__dataclass_fields__.values()}
    mlx_cfg = MLXArgs(**{k: v for k, v in cfg_json.items() if k in mlx_cfg_fields})
    mlx_layer = DeepseekV4DecoderLayer(mlx_cfg, layer_id=args.layer)
    attn_m = mlx_layer.self_attn

    def cp(m, t): m.weight = _to_mx16(t.weight)
    cp(attn_m.wq_a, attn_t.wq_a)
    attn_m.q_norm.weight = _to_mx16(attn_t.q_norm.weight)
    cp(attn_m.wq_b, attn_t.wq_b)
    cp(attn_m.wkv, attn_t.wkv)
    attn_m.kv_norm.weight = _to_mx16(attn_t.kv_norm.weight)
    cp(attn_m.wo_a, attn_t.wo_a)
    cp(attn_m.wo_b, attn_t.wo_b)
    attn_m.attn_sink = _to_mx16(attn_t.attn_sink)

    torch.manual_seed(0); np.random.seed(0)
    B, L = 1, 8
    x_np = np.random.randn(B, L, torch_cfg.dim).astype(np.float32) * 0.1
    x_t = torch.from_numpy(x_np).to(torch.bfloat16)
    x_m = mx.array(x_np.astype(np.float16))
    fc_t = precompute_freqs_cis(torch_cfg.rope_head_dim, L, torch_cfg.original_seq_len,
        torch_cfg.rope_theta, torch_cfg.rope_factor, torch_cfg.beta_fast, torch_cfg.beta_slow)

    cfg = torch_cfg
    rd = cfg.rope_head_dim

    # === TORCH: step by step ===
    with torch.inference_mode():
        qr_t = attn_t.q_norm(attn_t.wq_a(x_t))
        q_t = attn_t.wq_b(qr_t).unflatten(-1, (cfg.n_heads, cfg.head_dim)).transpose(1, 2)
        q_t = (q_t.float() * torch.rsqrt(q_t.float().square().mean(-1, keepdim=True) + cfg.norm_eps)).to(q_t.dtype)
        apply_rotary_emb(q_t[..., -rd:], fc_t)
        kv_t = attn_t.kv_norm(attn_t.wkv(x_t)).unsqueeze(1)
        apply_rotary_emb(kv_t[..., -rd:], fc_t)
        k_t = kv_t.expand(-1, cfg.n_heads, -1, -1)
        scores_t = (q_t @ k_t.transpose(-1, -2)) * attn_t.softmax_scale
        mask_t = torch.triu(torch.full((L, L), float("-inf")), diagonal=1)
        scores_t = scores_t + mask_t
        sink_t = attn_t.attn_sink.view(1, cfg.n_heads, 1, 1).expand(B, -1, L, 1).to(scores_t.dtype)
        scores_with_sink_t = torch.cat([sink_t, scores_t], dim=-1)
        attn_probs_t = scores_with_sink_t.softmax(-1)
        attn_probs_t = attn_probs_t[..., 1:].to(kv_t.dtype)
        o_before_inv_rope_t = attn_probs_t @ k_t
        apply_rotary_emb(o_before_inv_rope_t[..., -rd:], fc_t, inverse=True)
        o_after_inv_rope_t = o_before_inv_rope_t
        o_transpose_t = o_after_inv_rope_t.transpose(1, 2).contiguous()
        o_group_view_t = o_transpose_t.view(B, L, cfg.o_groups, -1)
        wo_a_w = attn_t.wo_a.weight.view(cfg.o_groups, cfg.o_lora_rank, -1)
        o_after_wo_a_t = torch.einsum("bsgd,grd->bsgr", o_group_view_t, wo_a_w)
        o_final_t = attn_t.wo_b(o_after_wo_a_t.flatten(2))

    # === MLX: step by step (manually replicate) ===
    qr_m = attn_m.q_norm(attn_m.wq_a(x_m))
    q_m = attn_m.wq_b(qr_m).reshape(B, L, mlx_cfg.num_attention_heads, mlx_cfg.head_dim).transpose(0, 2, 1, 3)
    q_m = q_m * mx.rsqrt(mx.mean(q_m.astype(mx.float32).square(), axis=-1, keepdims=True) + mlx_cfg.rms_norm_eps).astype(q_m.dtype)
    q_nope_m, q_rope_m = mx.split(q_m, [mlx_cfg.head_dim - rd], axis=-1)
    fc_real = attn_m._freqs_cis_real[0:L]
    q_rope_m = _mlx_apply_rotary_cis(q_rope_m, fc_real)
    q_m = mx.concatenate([q_nope_m, q_rope_m], axis=-1)
    kv_m = attn_m.kv_norm(attn_m.wkv(x_m)).reshape(B, L, 1, mlx_cfg.head_dim).transpose(0, 2, 1, 3)
    kv_nope_m, kv_rope_m = mx.split(kv_m, [mlx_cfg.head_dim - rd], axis=-1)
    kv_rope_m = _mlx_apply_rotary_cis(kv_rope_m, fc_real)
    kv_m = mx.concatenate([kv_nope_m, kv_rope_m], axis=-1)
    k_m = mx.broadcast_to(kv_m, (B, mlx_cfg.num_attention_heads, L, mlx_cfg.head_dim))
    scores_m = (q_m * attn_m.softmax_scale) @ k_m.swapaxes(-1, -2)
    mask_m = mx.triu(mx.full((L, L), -mx.inf, dtype=scores_m.dtype), k=1)
    scores_m = scores_m + mask_m
    sink_m = mx.broadcast_to(attn_m.attn_sink.reshape(1, mlx_cfg.num_attention_heads, 1, 1), scores_m.shape[:-1] + (1,)).astype(scores_m.dtype)
    scores_with_sink_m = mx.concatenate([sink_m, scores_m], axis=-1)
    attn_probs_m = mx.softmax(scores_with_sink_m, axis=-1, precise=True)
    attn_probs_m = attn_probs_m[..., 1:]
    o_m = attn_probs_m @ k_m
    # Inverse RoPE
    o_nope_m, o_rope_m = mx.split(o_m, [mlx_cfg.head_dim - rd], axis=-1)
    fc_inv = mx.stack([fc_real[..., 0], -fc_real[..., 1]], axis=-1)
    o_rope_m = _mlx_apply_rotary_cis(o_rope_m, fc_inv)
    o_after_inv_rope_m = mx.concatenate([o_nope_m, o_rope_m], axis=-1)
    o_transpose_m = o_after_inv_rope_m.transpose(0, 2, 1, 3).reshape(B, L, mlx_cfg.o_groups, -1)
    # wo_a — NO QUANT in this probe
    wa_m = attn_m.wo_a.weight.reshape(mlx_cfg.o_groups, mlx_cfg.o_lora_rank, -1)
    o_after_wo_a_m = mx.einsum("bsgd,grd->bsgr", o_transpose_m, wa_m)
    o_final_m = attn_m.wo_b(mx.flatten(o_after_wo_a_m, start_axis=2))

    mx.eval(q_m); mx.eval(kv_m); mx.eval(scores_m); mx.eval(attn_probs_m); mx.eval(o_m)
    mx.eval(o_after_inv_rope_m); mx.eval(o_transpose_m); mx.eval(o_after_wo_a_m); mx.eval(o_final_m)

    print("=== Deep attention step diff ===")
    diff("q_post_rope", q_m, q_t)
    diff("kv_post_rope", kv_m.squeeze(1), kv_t.squeeze(1))
    diff("scores", scores_m, scores_t)
    diff("attn_probs (post-drop-sink)", attn_probs_m, attn_probs_t)
    diff("o (before inv rope)", o_m, o_before_inv_rope_t)
    diff("o (after inv rope)", o_after_inv_rope_m, o_after_inv_rope_t)
    diff("o (after transpose+reshape)", o_transpose_m, o_group_view_t)
    diff("o (after wo_a)", o_after_wo_a_m, o_after_wo_a_t)
    diff("o_final (after wo_b)", o_final_m, o_final_t)


if __name__ == "__main__":
    sys.exit(main())
