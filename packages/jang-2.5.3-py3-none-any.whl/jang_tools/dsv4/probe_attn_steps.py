"""Step-by-step attention divergence probe."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np, torch
import mlx.core as mx
import mlx.nn as nn

from jang_tools.dsv4 import mlx_register
from jang_tools.dsv4.mlx_model import ModelArgs as MLXArgs, DeepseekV4DecoderLayer
from jang_tools.dsv4.layer_forward import DSV4Config, load_block_from_shards
from jang_tools.dsv4.weight_loader import ShardIndex
from jang_tools.dsv4.ops import precompute_freqs_cis


def diff(name, a, b):
    an = np.array(a, copy=False).astype(np.float32) if isinstance(a, mx.array) else a.detach().float().numpy()
    bn = b.detach().float().numpy() if isinstance(b, torch.Tensor) else np.array(b, copy=False).astype(np.float32)
    if an.shape != bn.shape:
        print(f"  [{name:24}] SHAPE: {an.shape} vs {bn.shape}"); return
    d = np.abs(an - bn)
    print(f"  [{name:24}] max={d.max():.4g}  mean={d.mean():.4g}  "
          f"a_rng=[{an.min():.3g},{an.max():.3g}]  b_rng=[{bn.min():.3g},{bn.max():.3g}]")


def _to_mx16(t):
    return mx.array(t.detach().float().numpy().astype(np.float16))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, type=Path)
    ap.add_argument("--layer", type=int, default=3)
    args = ap.parse_args()

    src_idx = ShardIndex(args.source)
    cfg_json = json.loads((args.source / "config.json").read_text())
    torch_cfg = DSV4Config.from_config_json(cfg_json)
    torch_blk = load_block_from_shards(args.layer, torch_cfg, src_idx).eval()
    attn_t = torch_blk.attn

    # Build MLX attention with identical weights
    mlx_cfg_fields = {f.name for f in MLXArgs.__dataclass_fields__.values()}
    mlx_cfg = MLXArgs(**{k: v for k, v in cfg_json.items() if k in mlx_cfg_fields})
    mlx_layer = DeepseekV4DecoderLayer(mlx_cfg, layer_id=args.layer)
    attn_m = mlx_layer.self_attn

    def cp(m, t): m.weight = _to_mx16(t.weight)
    def cpn(m, t): m.weight = _to_mx16(t.weight)
    cp(attn_m.wq_a, attn_t.wq_a)
    cpn(attn_m.q_norm, attn_t.q_norm)
    cp(attn_m.wq_b, attn_t.wq_b)
    cp(attn_m.wkv, attn_t.wkv)
    cpn(attn_m.kv_norm, attn_t.kv_norm)
    cp(attn_m.wo_a, attn_t.wo_a)
    cp(attn_m.wo_b, attn_t.wo_b)
    attn_m.attn_sink = _to_mx16(attn_t.attn_sink)

    # Identical input
    torch.manual_seed(0); np.random.seed(0)
    B, L = 1, 8
    x_np = np.random.randn(B, L, torch_cfg.dim).astype(np.float32) * 0.1
    x_t = torch.from_numpy(x_np).to(torch.bfloat16)
    x_m = mx.array(x_np.astype(np.float16))
    fc_t = precompute_freqs_cis(torch_cfg.rope_head_dim, L, torch_cfg.original_seq_len,
        torch_cfg.rope_theta, torch_cfg.rope_factor, torch_cfg.beta_fast, torch_cfg.beta_slow)

    # Torch path: manually step through
    with torch.inference_mode():
        from jang_tools.dsv4.ops import apply_rotary_emb as _rope_t
        B_, L_, _ = x_t.shape
        freqs = fc_t
        cfg = torch_cfg
        rd = cfg.rope_head_dim
        qr_t = attn_t.q_norm(attn_t.wq_a(x_t))
        q_t = attn_t.wq_b(qr_t).unflatten(-1, (cfg.n_heads, cfg.head_dim)).transpose(1, 2)
        q_t = q_t * torch.rsqrt(q_t.float().square().mean(-1, keepdim=True) + cfg.norm_eps).to(q_t.dtype)
        q_pre = q_t.clone()
        _rope_t(q_t[..., -rd:], freqs)
        kv_t = attn_t.kv_norm(attn_t.wkv(x_t))
        kv_pre = kv_t.clone()
        _rope_t(kv_t[..., -rd:], freqs)

    # MLX path: step through
    qr_m = attn_m.q_norm(attn_m.wq_a(x_m))
    q_m0 = attn_m.wq_b(qr_m).reshape(B, L, mlx_cfg.num_attention_heads, mlx_cfg.head_dim).transpose(0, 2, 1, 3)
    q_m = q_m0 * mx.rsqrt(mx.mean(q_m0.astype(mx.float32).square(), axis=-1, keepdims=True) + mlx_cfg.rms_norm_eps).astype(q_m0.dtype)
    q_m_pre = q_m
    # Split + rope
    from jang_tools.dsv4.mlx_model import _mlx_apply_rotary_cis
    q_nope, q_rope = mx.split(q_m, [mlx_cfg.head_dim - mlx_cfg.qk_rope_head_dim], axis=-1)
    fc_real = attn_m._freqs_cis_real[0:L]
    q_rope = _mlx_apply_rotary_cis(q_rope, fc_real)
    q_m_post = mx.concatenate([q_nope, q_rope], axis=-1)
    kv_m = attn_m.kv_norm(attn_m.wkv(x_m))
    kv_m = kv_m.reshape(B, L, 1, mlx_cfg.head_dim).transpose(0, 2, 1, 3)
    kv_m_pre = kv_m
    kv_nope, kv_rope = mx.split(kv_m, [mlx_cfg.head_dim - mlx_cfg.qk_rope_head_dim], axis=-1)
    kv_rope = _mlx_apply_rotary_cis(kv_rope, fc_real)
    kv_m_post = mx.concatenate([kv_nope, kv_rope], axis=-1)
    mx.eval(q_m_post); mx.eval(kv_m_post)

    print("=== Step-by-step diff ===")
    diff("qr (after q_norm)", qr_m, qr_t)
    diff("q (pre-RoPE)", q_m_pre, q_pre)
    diff("q (post-RoPE)", q_m_post, q_t)
    diff("kv (pre-RoPE)", kv_m_pre.squeeze(1), kv_pre)
    diff("kv (post-RoPE)", kv_m_post.squeeze(1), kv_t)


if __name__ == "__main__":
    sys.exit(main())
