"""Test DSV4 generation with PROPER chat encoding (encoding_dsv4.encode_messages).

Demonstrates:
  - chat vs thinking reasoning modes
  - reasoning_effort levels (None/high/max)
  - DSML tool-call parser
  - jang_config.json metadata use (EOS, sampling defaults)

Usage:
  python3 -m jang_tools.dsv4.test_chat \\
      --bundle /path/to/DSV4-Flash-JANGTQ4 \\
      --mode chat --max-tokens 80
  python3 -m jang_tools.dsv4.test_chat \\
      --bundle /path/to/DSV4-Flash-JANGTQ4 \\
      --mode thinking --reasoning-effort max
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


# ---------- DSML tool-call parser (no deps) ----------

DSML_CHAR = "｜"  # ｜ (fullwidth vertical bar)
DSML_PREFIX = f"{DSML_CHAR}DSML{DSML_CHAR}"


def parse_dsml_tool_calls(text: str) -> list[dict]:
    """Parse DeepSeek DSML tool_calls blocks from a completion.

    Returns list of dicts: {name, arguments: {param_name: value}}.
    """
    invoke_re = re.compile(
        rf"<{re.escape(DSML_PREFIX)}invoke name=\"([^\"]+)\">(.*?)</{re.escape(DSML_PREFIX)}invoke>",
        re.DOTALL,
    )
    param_re = re.compile(
        rf"<{re.escape(DSML_PREFIX)}parameter name=\"([^\"]+)\" string=\"(true|false)\">(.*?)</{re.escape(DSML_PREFIX)}parameter>",
        re.DOTALL,
    )
    calls = []
    for m in invoke_re.finditer(text):
        name = m.group(1)
        params = {}
        for pm in param_re.finditer(m.group(2)):
            pname, is_string, value = pm.group(1), pm.group(2), pm.group(3)
            if is_string == "false":
                try:
                    value = json.loads(value)
                except Exception:
                    pass
            params[pname] = value
        calls.append({"name": name, "arguments": params})
    return calls


def split_reasoning_response(completion: str, thinking_mode: str) -> tuple[str, str]:
    """Return (reasoning, response). For chat mode, reasoning is empty."""
    if thinking_mode == "chat":
        return "", completion
    # thinking mode: split at first </think>
    if "</think>" in completion:
        r, rest = completion.split("</think>", 1)
        return r, rest
    # Model didn't close <think>: treat whole thing as reasoning
    return completion, ""


# ---------- Main ----------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--max-tokens", type=int, default=120)
    ap.add_argument("--wired-gb", type=int, default=192)
    ap.add_argument("--mode", default="chat", choices=("chat", "thinking"))
    ap.add_argument("--reasoning-effort", default=None, choices=(None, "high", "max"))
    ap.add_argument("--temp", type=float, default=None,
                    help="Sampling temperature (default: from jang_config sampling_defaults)")
    ap.add_argument("--top-p", type=float, default=None)
    ap.add_argument("--prompts", nargs="+", default=[
        "What is 2+2?",
        "What is the capital of France?",
        "Write a Python function that returns the nth Fibonacci number.",
    ])
    args = ap.parse_args()

    # Chat encoder from source
    sys.path.insert(0, "<path/to/DeepSeek-V4-Flash>/encoding")
    from encoding_dsv4 import encode_messages

    import mlx.core as mx
    mx.set_wired_limit(args.wired_gb * 1000 * 1000 * 1000)
    from jang_tools.load_jangtq import load_jangtq_model

    bundle = Path(args.bundle)
    print(f"Loading bundle: {bundle}", flush=True)
    model, tok = load_jangtq_model(str(bundle))
    mx.set_wired_limit(args.wired_gb * 1000 * 1000 * 1000)  # reassert after load

    # Read jang_config for chat metadata (auto-applied by load_jangtq but
    # re-read here so we can introspect modes, defaults, etc).
    jang_cfg = json.loads((bundle / "jang_config.json").read_text())
    chat_cfg = jang_cfg.get("chat", {})
    sampling = chat_cfg.get("sampling_defaults", {})
    temp = args.temp if args.temp is not None else sampling.get("temperature", 0.6)
    top_p = args.top_p if args.top_p is not None else sampling.get("top_p", 0.95)

    # Report config
    print(f"\n=== Bundle metadata ===")
    print(f"  profile:        {jang_cfg.get('profile')}")
    print(f"  model_family:   {jang_cfg.get('model_family')}")
    print(f"  eos_token_id:   {chat_cfg.get('eos_token_id')} ({chat_cfg.get('eos_token')!r})")
    print(f"  reasoning:      supported={chat_cfg.get('reasoning', {}).get('supported')} "
          f"modes={chat_cfg.get('reasoning', {}).get('modes')}")
    print(f"  tool_calling:   parser={chat_cfg.get('tool_calling', {}).get('parser')}")
    print(f"  sampler:        temp={temp} top_p={top_p}")

    from mlx_lm import generate
    from mlx_lm.sample_utils import make_sampler
    sampler = make_sampler(temp=temp, top_p=top_p) if temp > 0 else None

    for p in args.prompts:
        enc_kwargs = {"thinking_mode": args.mode}
        if args.reasoning_effort:
            enc_kwargs["reasoning_effort"] = args.reasoning_effort
        prompt_text = encode_messages(
            [{"role": "user", "content": p}],
            **enc_kwargs,
        )
        print(f"\n=== USER: {p!r} (mode={args.mode} effort={args.reasoning_effort})")
        print(f"    FORMATTED: {prompt_text!r}")
        try:
            if sampler is not None:
                out = generate(model, tok, prompt=prompt_text,
                               max_tokens=args.max_tokens, sampler=sampler,
                               verbose=False)
            else:
                out = generate(model, tok, prompt=prompt_text,
                               max_tokens=args.max_tokens, verbose=False)
            reasoning, response = split_reasoning_response(out, args.mode)
            if reasoning:
                print(f"    REASONING: {reasoning!r}")
            print(f"    RESPONSE:  {response!r}")
            calls = parse_dsml_tool_calls(out)
            if calls:
                print(f"    TOOL CALLS: {calls}")
        except Exception as e:
            print(f"    ERROR: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
