"""Провайдеры аутентификации и token-flow для SDK Avito."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Protocol

import httpx

from avito.auth.enums import CLIENT_CREDENTIALS_GRANT, REFRESH_TOKEN_GRANT
from avito.auth.mappers import map_token_response
from avito.auth.models import (
    AccessToken,
    ClientCredentialsRequest,
    RefreshTokenRequest,
    TokenResponse,
)
from avito.auth.settings import AuthSettings
from avito.core.exceptions import AuthenticationError

if TYPE_CHECKING:
    pass


class TokenFetcher(Protocol):
    """Контракт получения нового access token из внешнего источника."""

    def __call__(self, settings: AuthSettings) -> TokenResponse: ...


@dataclass(slots=True)
class AuthProvider:
    """Поставляет и кэширует токен доступа для transport-слоя."""

    settings: AuthSettings
    token_client: TokenClient | None = None
    legacy_token_client: LegacyTokenClient | None = None
    autoteka_token_client: TokenClient | None = None
    token_fetcher: TokenFetcher | None = None
    _access_token: AccessToken | None = field(default=None, init=False, repr=False)
    _refresh_token: str | None = field(default=None, init=False, repr=False)
    _autoteka_access_token: AccessToken | None = field(default=None, init=False, repr=False)

    def get_access_token(self) -> str:
        """Возвращает валидный access token, обновляя кэш при необходимости."""

        token = self._access_token
        now = datetime.now(UTC)
        if token is None or token.is_expired(now):
            token = self.refresh_access_token().access_token
        return token.value

    def refresh_access_token(self) -> TokenResponse:
        """Принудительно обновляет токен через refresh token или client credentials."""

        token_response = self._fetch_token_response()
        self._store_token_response(token_response)
        return token_response

    def invalidate_token(self) -> None:
        """Сбрасывает закэшированный токен после `401 Unauthorized`."""

        self._access_token = None

    def close(self) -> None:
        """Закрывает внутренние HTTP-клиенты provider-а."""

        for client in (self.token_client, self.legacy_token_client, self.autoteka_token_client):
            if client is not None:
                client.close()

    def get_autoteka_access_token(self) -> str:
        """Возвращает отдельный access token для flow Автотеки."""

        token = self._autoteka_access_token
        now = datetime.now(UTC)
        if token is None or token.is_expired(now):
            token_response = self._get_autoteka_token_client().request_client_credentials_token(
                ClientCredentialsRequest(
                    client_id=self.settings.autoteka_client_id or self.settings.client_id or "",
                    client_secret=self.settings.autoteka_client_secret
                    or self.settings.client_secret
                    or "",
                    scope=self.settings.autoteka_scope,
                )
            )
            self._autoteka_access_token = token_response.access_token
            token = token_response.access_token
        return token.value

    def token_flow(self) -> TokenClient:
        """Возвращает canonical token client для low-level OAuth операций."""

        return self._get_token_client()

    def legacy_token_flow(self) -> LegacyTokenClient:
        """Возвращает legacy alias token client без отдельного публичного API метода."""

        return self._get_legacy_token_client()

    def _fetch_token_response(self) -> TokenResponse:
        if self.token_fetcher is not None:
            token_response = self.token_fetcher(self.settings)
            if isinstance(token_response, AccessToken):
                return TokenResponse(access_token=token_response)
            return token_response
        if self._refresh_token:
            return self._get_token_client().request_refresh_token(
                RefreshTokenRequest(
                    client_id=self._require_client_id(),
                    client_secret=self._require_client_secret(),
                    refresh_token=self._refresh_token,
                    scope=self.settings.scope,
                )
            )
        if self.settings.refresh_token:
            return self._get_token_client().request_refresh_token(
                RefreshTokenRequest(
                    client_id=self._require_client_id(),
                    client_secret=self._require_client_secret(),
                    refresh_token=self.settings.refresh_token,
                    scope=self.settings.scope,
                )
            )
        return self._get_token_client().request_client_credentials_token(
            ClientCredentialsRequest(
                client_id=self._require_client_id(),
                client_secret=self._require_client_secret(),
                scope=self.settings.scope,
            )
        )

    def _store_token_response(self, token_response: TokenResponse) -> None:
        self._access_token = token_response.access_token
        self._refresh_token = token_response.refresh_token or self._refresh_token

    def _get_token_client(self) -> TokenClient:
        if self.token_client is None:
            self.token_client = TokenClient(self.settings)
        return self.token_client

    def _get_legacy_token_client(self) -> LegacyTokenClient:
        if self.legacy_token_client is None:
            self.legacy_token_client = LegacyTokenClient(self.settings)
        return self.legacy_token_client

    def _get_autoteka_token_client(self) -> TokenClient:
        if self.autoteka_token_client is None:
            self.autoteka_token_client = TokenClient(
                self.settings, token_url=self.settings.autoteka_token_url
            )
        return self.autoteka_token_client

    def _require_client_id(self) -> str:
        if self.settings.client_id is None:
            raise AuthenticationError("Для OAuth flow не задан `client_id`.")
        return self.settings.client_id

    def _require_client_secret(self) -> str:
        if self.settings.client_secret is None:
            raise AuthenticationError("Для OAuth flow не задан `client_secret`.")
        return self.settings.client_secret


@dataclass(slots=True)
class TokenClient:
    """Служебный клиент для canonical OAuth token endpoint."""

    settings: AuthSettings
    token_url: str | None = None
    client: httpx.Client | None = None

    def close(self) -> None:
        """Закрывает выделенный HTTP-клиент, если он был передан снаружи."""

        if self.client is not None:
            self.client.close()

    def request_client_credentials_token(
        self,
        request: ClientCredentialsRequest,
    ) -> TokenResponse:
        """Запрашивает access token по flow `client_credentials`."""

        payload: dict[str, str] = {
            "grant_type": CLIENT_CREDENTIALS_GRANT,
            "client_id": request.client_id,
            "client_secret": request.client_secret,
        }
        if request.scope is not None:
            payload["scope"] = request.scope
        return self._request_token(payload)

    def request_refresh_token(self, request: RefreshTokenRequest) -> TokenResponse:
        """Запрашивает новый access token по flow `refresh_token`."""

        payload: dict[str, str] = {
            "grant_type": REFRESH_TOKEN_GRANT,
            "client_id": request.client_id,
            "client_secret": request.client_secret,
            "refresh_token": request.refresh_token,
        }
        if request.scope is not None:
            payload["scope"] = request.scope
        return self._request_token(payload)

    def _request_token(self, payload: dict[str, str]) -> TokenResponse:
        client = self.client or httpx.Client()
        owns_client = self.client is None
        try:
            response = client.post(
                self.token_url or self.settings.token_url,
                data=payload,
                headers={"Accept": "application/json"},
            )
        except httpx.HTTPError as exc:
            raise AuthenticationError(f"Ошибка OAuth transport: {exc}") from exc
        finally:
            if owns_client:
                client.close()

        if response.is_error:
            raise AuthenticationError(
                self._extract_error_message(response),
                status_code=response.status_code,
                error_code=self._extract_error_code(response),
                payload=self._safe_payload(response),
                headers=dict(response.headers),
            )

        try:
            payload_object = response.json()
        except ValueError as exc:
            raise AuthenticationError(
                "OAuth endpoint вернул невалидный JSON.",
                status_code=response.status_code,
                payload=response.text,
                headers=dict(response.headers),
            ) from exc
        return map_token_response(payload_object)

    def _safe_payload(self, response: httpx.Response) -> object:
        try:
            return response.json()
        except ValueError:
            return response.text

    def _extract_error_message(self, response: httpx.Response) -> str:
        payload = self._safe_payload(response)
        if isinstance(payload, dict):
            for key in ("message", "error_description", "error", "detail"):
                value = payload.get(key)
                if isinstance(value, str) and value:
                    return value
        return f"Ошибка OAuth endpoint: HTTP {response.status_code}"

    def _extract_error_code(self, response: httpx.Response) -> str | None:
        payload = self._safe_payload(response)
        if isinstance(payload, dict):
            value = payload.get("error") or payload.get("code")
            if isinstance(value, str):
                return value
        return None


@dataclass(slots=True)
class LegacyTokenClient:
    """Служебный клиент для legacy alias token endpoint из swagger."""

    settings: AuthSettings
    client: httpx.Client | None = None

    def close(self) -> None:
        """Закрывает выделенный HTTP-клиент legacy token flow."""

        if self.client is not None:
            self.client.close()

    def request_client_credentials_token(
        self,
        request: ClientCredentialsRequest,
    ) -> TokenResponse:
        """Запрашивает токен через legacy alias canonical `/token`."""

        return TokenClient(
            self.settings,
            token_url=self.settings.legacy_token_url,
            client=self.client,
        ).request_client_credentials_token(request)

    def request_refresh_token(self, request: RefreshTokenRequest) -> TokenResponse:
        """Обновляет токен через legacy alias canonical `/token`."""

        return TokenClient(
            self.settings,
            token_url=self.settings.legacy_token_url,
            client=self.client,
        ).request_refresh_token(request)


__all__ = ("AuthProvider", "LegacyTokenClient", "TokenClient", "TokenFetcher")
