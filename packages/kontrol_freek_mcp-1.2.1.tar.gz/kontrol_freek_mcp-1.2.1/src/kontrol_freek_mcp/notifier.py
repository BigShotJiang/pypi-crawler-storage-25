"""Notification Router — Telegram, Slack, Web Dashboard, Terminal fallback.

Routes human approval requests across channels when ctx.elicit() is unavailable."""

from __future__ import annotations
import asyncio, json, logging, time, uuid
from typing import Any


def _new_rid() -> str:
    """Generate a short, collision-resistant request ID (timestamp prefix + uuid suffix)."""
    ts = format(int(time.time() * 1000) % 0xFFFFFF, "06x")
    return f"{ts}{str(uuid.uuid4()).replace('-', '')[:6]}"

LOG = logging.getLogger("kontrol-freek.notifier")
_pending: dict[str, asyncio.Event] = {}
_responses: dict[str, dict[str, Any]] = {}
_polling_tasks: dict[str, asyncio.Task] = {}  # token -> polling task


class NotificationRouter:
    def __init__(self, telegram_token: str = "", telegram_chat_id: str = "",
                 slack_webhook: str = "", web_port: int = 9111, project_name: str = ""):
        self.telegram_token, self.telegram_chat_id = telegram_token, telegram_chat_id
        self.slack_webhook, self.web_port = slack_webhook, web_port
        self.project_name = project_name or "kontrol-freek"
        self._channels: list[str] = []
        if telegram_token and telegram_chat_id:
            self._channels.append("telegram")
            self._ensure_polling()
        if slack_webhook: self._channels.append("slack")
        self._channels.append("web")  # terminal removed: input() blocks MCP stdio

    def _ensure_polling(self):
        """Start Telegram polling loop, cancelling any existing task for this token first."""
        if not self.telegram_token:
            return
        # Cancel stale task to prevent duplicate polling loops after config reload
        existing = _polling_tasks.get(self.telegram_token)
        if existing is not None and not existing.done():
            existing.cancel()
            LOG.info("Cancelled stale Telegram polling task for token ...%s", self.telegram_token[-6:])
        _polling_tasks.pop(self.telegram_token, None)
        try:
            loop = asyncio.get_running_loop()
            task = loop.create_task(self._poll_telegram())
            task.add_done_callback(lambda t: LOG.warning("Telegram polling ended: %s", t.exception()) if not t.cancelled() and t.exception() else None)
            _polling_tasks[self.telegram_token] = task
            LOG.info("Telegram polling started for token ...%s", self.telegram_token[-6:])
        except RuntimeError:
            pass  # No running event loop yet — polling will be started lazily on first request

    async def _poll_telegram(self):
        """Long-poll Telegram for /kf approve/reject/answer commands."""
        import httpx
        offset = 0
        base = f"https://api.telegram.org/bot{self.telegram_token}"
        LOG.info("Telegram polling loop running")
        while True:
            try:
                async with httpx.AsyncClient(timeout=35) as c:
                    r = await c.get(f"{base}/getUpdates", params={"offset": offset, "timeout": 30, "allowed_updates": ["message"]})
                    data = r.json()
                if not data.get("ok"):
                    await asyncio.sleep(5)
                    continue
                for upd in data.get("result", []):
                    offset = upd["update_id"] + 1
                    text = upd.get("message", {}).get("text", "").strip()
                    if not text.startswith("/kf "):
                        continue
                    parts = text[4:].split(maxsplit=2)
                    if not parts:
                        continue
                    cmd = parts[0].lower()
                    rid = parts[1] if len(parts) > 1 else ""
                    extra = parts[2] if len(parts) > 2 else ""
                    if cmd == "approve" and rid:
                        resolve_approval(rid, True, extra or "Approved via Telegram")
                        LOG.info("Telegram approved: %s", rid)
                    elif cmd == "reject" and rid:
                        resolve_approval(rid, False, extra or "Rejected via Telegram")
                        LOG.info("Telegram rejected: %s", rid)
                    elif cmd == "answer" and rid:
                        resolve_answer(rid, extra)
                        LOG.info("Telegram answered: %s = %s", rid, extra)
            except asyncio.CancelledError:
                LOG.info("Telegram polling cancelled")
                return
            except Exception as e:
                LOG.warning("Telegram polling error: %s", e)
                await asyncio.sleep(5)

    async def request_approval(self, message: str) -> dict[str, Any]:
        # Lazily start polling if event loop is now available
        if self.telegram_token and self.telegram_token not in _polling_tasks:
            self._ensure_polling()

        rid = _new_rid()
        event = asyncio.Event()
        _pending[rid] = event

        remote_channels = [ch for ch in self._channels if ch not in ("terminal", "web")]
        tasks = []
        for ch in self._channels:
            if ch == "telegram": tasks.append(self._send_telegram(rid, message, "approval"))
            elif ch == "slack": tasks.append(self._send_slack(rid, message, "approval"))
            elif ch == "web": tasks.append(self._log_web(rid, message))
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        if not remote_channels:
            # No remote channels configured — terminal input would block MCP stdio.
            # Caller (server.py _request_human_approval) handles this case before
            # calling request_approval, so this path should not be reached normally.
            _pending.pop(rid, None)
            return {"approved": False, "comment": "No remote channels configured.", "channel": "unavailable"}

        # Remote channels notified — wait for response (180s keeps under Claude Code's 4-min tool timeout)
        try:
            await asyncio.wait_for(event.wait(), timeout=180)
            return _responses.pop(rid, {"approved": False, "comment": "Timeout", "channel": "timeout"})
        except asyncio.TimeoutError:
            _pending.pop(rid, None)
            LOG.warning("No remote response within 3 minutes — returning timeout")
            return {"approved": False, "comment": "No response within 3 minutes. Use /kf approve <rid> via Telegram or configure KF_SLACK_WEBHOOK.", "channel": "timeout"}

    async def ask_question(self, question: str) -> dict[str, Any]:
        if self.telegram_token and self.telegram_token not in _polling_tasks:
            self._ensure_polling()
        rid = _new_rid()
        event = asyncio.Event()
        _pending[rid] = event
        remote_channels = [ch for ch in self._channels if ch not in ("terminal", "web")]
        if not remote_channels:
            _pending.pop(rid, None)
            return {"answer": "", "channel": "unavailable", "note": "No remote channels configured. Set KF_TELEGRAM_TOKEN or KF_SLACK_WEBHOOK."}
        tasks = []
        for ch in self._channels:
            if ch == "telegram": tasks.append(self._send_telegram(rid, question, "question"))
            elif ch == "slack": tasks.append(self._send_slack(rid, question, "question"))
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        try:
            await asyncio.wait_for(event.wait(), timeout=180)
            return _responses.pop(rid, {"answer": "", "channel": "timeout"})
        except asyncio.TimeoutError:
            _pending.pop(rid, None)
            LOG.warning("No remote response within 3 minutes — returning timeout")
            return {"answer": "", "channel": "timeout"}

    # --- Telegram ---
    async def _send_telegram(self, rid: str, message: str, msg_type: str):
        try:
            import httpx
            proj_label = f"`{self.project_name}`"
            if msg_type == "approval":
                text = f"🔥 *Kontrol Freek* [{proj_label}] [`{rid}`]\n\n{message}\n\n✅ Approve: `/kf approve {rid}`\n❌ Reject: `/kf reject {rid} [reason]`"
            else:
                text = f"❓ *Kontrol Freek* [{proj_label}] [`{rid}`]\n\n{message}\n\nReply: `/kf answer {rid} [answer]`"
            async with httpx.AsyncClient() as c:
                await c.post(f"https://api.telegram.org/bot{self.telegram_token}/sendMessage",
                             json={"chat_id": self.telegram_chat_id, "text": text, "parse_mode": "Markdown"})
        except Exception as e:
            LOG.warning("Telegram send failed: %s", e)

    # --- Slack ---
    async def _send_slack(self, rid: str, message: str, msg_type: str):
        # Note: Slack interactive buttons require a separate /slack/actions webhook endpoint.
        # Until that is implemented, approval requests use text-only format with
        # instructions to respond via the web dashboard or Telegram.
        try:
            import httpx
            if msg_type == "approval":
                text = (
                    f"🔥 *Kontrol Freek* [`{rid}`]\n\n{message}\n\n"
                    f"Approve: `POST /approve/{rid}` · Reject: `POST /approve/{rid}` with `approved=false`\n"
                    f"_(Or use Telegram: `/kf approve {rid}` / `/kf reject {rid} [reason]`)_"
                )
            else:
                text = (
                    f"❓ *Kontrol Freek* [`{rid}`]\n\n{message}\n\n"
                    f"Answer: `POST /answer/{rid}` · _(Or Telegram: `/kf answer {rid} [answer]`)_"
                )
            async with httpx.AsyncClient() as c:
                await c.post(self.slack_webhook, json={"text": text})
        except Exception as e:
            LOG.warning("Slack send failed: %s", e)

    async def _log_web(self, rid: str, message: str):
        LOG.info("[WEB] Pending %s: %s", rid, message[:100])


# --- External resolution API ---
def resolve_approval(request_id: str, approved: bool, comment: str = ""):
    _responses[request_id] = {"approved": approved, "comment": comment, "channel": "external"}
    e = _pending.pop(request_id, None)
    if e: e.set()

def resolve_answer(request_id: str, answer: str):
    _responses[request_id] = {"answer": answer, "channel": "external"}
    e = _pending.pop(request_id, None)
    if e: e.set()
