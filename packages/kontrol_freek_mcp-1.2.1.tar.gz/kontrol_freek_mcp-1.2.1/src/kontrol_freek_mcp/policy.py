"""Policy Engine — risk scoring, auto-approve / block / review decisions with time decay."""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any

class RiskLevel(Enum):
    LOW = "low"; MEDIUM = "medium"; HIGH = "high"; CRITICAL = "critical"
    @classmethod
    def from_str(cls, s: str) -> "RiskLevel":
        return cls(s.lower()) if s.lower() in cls._value2member_map_ else cls.MEDIUM
    @property
    def score(self) -> float:
        return {"low": 0.2, "medium": 0.5, "high": 0.8, "critical": 1.0}[self.value]

@dataclass
class PolicyVerdict:
    action: str  # "auto_approve" | "review" | "block"
    reason: str
    confidence: float

ALWAYS_REVIEW_CATEGORIES = {"security", "data_deletion", "architecture", "deployment", "billing"}

class PolicyEngine:
    """
    Policy rules:
    1. Critical risk → always block
    2. Contradiction detected → block
    3. Critical category → always review
    4. High similarity + past approval + low risk → auto_approve (with decay)
    5. High risk → review
    6. Default → review
    """
    def __init__(self, db: Any, similarity_threshold: float = 0.78, decay_days: int = 90):
        self.db = db
        self.similarity_threshold = similarity_threshold
        self.decay_days = decay_days

    def _time_decay(self, created_at: str) -> float:
        try:
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(created_at)).total_seconds() / 86400
            return math.exp(-age / self.decay_days)
        except Exception:
            return 0.5

    def evaluate(self, assumption: str, risk: RiskLevel, category: str,
                 similar_decisions: list[dict], contradictions: list[dict]) -> PolicyVerdict:
        if risk == RiskLevel.CRITICAL:
            return PolicyVerdict("block", "Critical risk level — human approval required.", 1.0)
        if contradictions:
            reasons = "; ".join(c.get("reason", "") for c in contradictions[:3])
            return PolicyVerdict("block", f"Contradiction with past decisions: {reasons}", 0.95)
        if category.lower() in ALWAYS_REVIEW_CATEGORIES:
            return PolicyVerdict("review", f"Category '{category}' always requires human review.", 0.9)
        if risk in (RiskLevel.LOW, RiskLevel.MEDIUM) and similar_decisions:
            best = similar_decisions[0]
            if best["score"] >= self.similarity_threshold and best.get("status") in ("confirmed", "human_approved", "auto_approved"):
                decay = self._time_decay(best.get("created_at", ""))
                if best["score"] * decay >= self.similarity_threshold and risk == RiskLevel.LOW:
                    return PolicyVerdict("auto_approve", f"Similar approved decision found ({int(best['score']*100)}% match, decay: {decay:.2f}). Low risk.", best["score"] * decay)
        if risk == RiskLevel.HIGH:
            return PolicyVerdict("review", "High risk level — human review recommended.", 0.7)
        return PolicyVerdict("review", "Medium risk or insufficient past decisions — human input needed.", 0.5)
