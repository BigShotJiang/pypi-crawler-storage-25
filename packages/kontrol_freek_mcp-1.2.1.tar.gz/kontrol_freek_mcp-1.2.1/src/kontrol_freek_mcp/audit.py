"""Cryptographic audit trail — HMAC-SHA256 signed, hash-chained, append-only JSONL."""

from __future__ import annotations
import hashlib, hmac, json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

class AuditTrail:
    def __init__(self, path: str = "./audit.jsonl", secret: str = "change-me"):
        self.path, self.secret = Path(path), secret
        self._prev_hash = "0" * 64
        if self.path.exists():
            lines = self.path.read_text().strip().split("\n")
            if lines and lines[-1]:
                try: self._prev_hash = json.loads(lines[-1]).get("hash", self._prev_hash)
                except json.JSONDecodeError: pass

    def append(self, action: str, text: str, detail: str = "", decision_id: Optional[int] = None):
        ts = datetime.now(timezone.utc).isoformat()
        payload = json.dumps({"action": action, "text": text, "detail": detail, "decision_id": decision_id, "ts": ts, "prev": self._prev_hash}, ensure_ascii=False, sort_keys=True)
        sig = hmac.new(self.secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        entry = {"action": action, "text": text, "detail": detail, "decision_id": decision_id, "ts": ts, "prev": self._prev_hash, "hash": sig}
        self._prev_hash = sig
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def verify_chain(self) -> tuple[bool, int]:
        """Verify the audit chain. Returns (is_valid, line_count)."""
        if not self.path.exists(): return True, 0
        lines = self.path.read_text().strip().split("\n")
        prev = "0" * 64
        for i, line in enumerate(lines):
            try: entry = json.loads(line)
            except json.JSONDecodeError: return False, i
            if entry.get("prev") != prev: return False, i
            stored = entry.pop("hash")
            computed = hmac.new(self.secret.encode(), json.dumps(entry, ensure_ascii=False, sort_keys=True).encode(), hashlib.sha256).hexdigest()
            if computed != stored: return False, i
            prev = stored; entry["hash"] = stored
        return True, len(lines)
