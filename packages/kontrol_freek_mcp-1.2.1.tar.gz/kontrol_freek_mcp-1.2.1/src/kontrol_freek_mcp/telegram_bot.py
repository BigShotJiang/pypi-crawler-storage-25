"""Telegram Bot — polling-based bot for receiving approval and answer responses.

Commands:
  /kf approve <id>          — Approve an assumption
  /kf reject <id> [reason]  — Reject an assumption
  /kf answer <id> <answer>  — Answer a question
  /kf stats                 — Show statistics
  /kf recent                — List recent decisions
"""

from __future__ import annotations
import asyncio, logging
from typing import Any

LOG = logging.getLogger("kontrol-freek.telegram")

async def run_telegram_bot(token: str, chat_id: str, db: Any):
    try:
        import httpx
    except ImportError:
        LOG.error("httpx required for Telegram bot: pip install httpx"); return

    from . import notifier as nmod
    base = f"https://api.telegram.org/bot{token}"
    offset = 0
    LOG.info("Telegram bot started, listening...")

    async with httpx.AsyncClient(timeout=60) as c:
        while True:
            try:
                resp = await c.get(f"{base}/getUpdates", params={"offset": offset, "timeout": 30})
                data = resp.json()
                if not data.get("ok"): await asyncio.sleep(5); continue
                for u in data.get("result", []):
                    offset = u["update_id"] + 1
                    text = u.get("message", {}).get("text", "").strip()
                    if not text.startswith("/kf"): continue
                    parts = text.split(maxsplit=3)
                    cmd = parts[1].lower() if len(parts) > 1 else ""
                    if cmd == "approve" and len(parts) >= 3:
                        nmod.resolve_approval(parts[2], True, "Telegram approval")
                        await c.post(f"{base}/sendMessage", json={"chat_id": chat_id, "text": f"✅ `{parts[2]}` approved.", "parse_mode": "Markdown"})
                    elif cmd == "reject" and len(parts) >= 3:
                        reason = parts[3] if len(parts) > 3 else "Rejected"
                        nmod.resolve_approval(parts[2], False, reason)
                        await c.post(f"{base}/sendMessage", json={"chat_id": chat_id, "text": f"❌ `{parts[2]}` rejected: {reason}", "parse_mode": "Markdown"})
                    elif cmd == "answer" and len(parts) >= 4:
                        nmod.resolve_answer(parts[2], parts[3])
                        await c.post(f"{base}/sendMessage", json={"chat_id": chat_id, "text": f"💬 `{parts[2]}` answered.", "parse_mode": "Markdown"})
                    elif cmd == "stats":
                        s = db.get_stats()
                        await c.post(f"{base}/sendMessage", json={"chat_id": chat_id, "text": f"📊 *Kontrol Freek*\nTotal: {s['total_decisions']}\nApproved: {s['by_status'].get('human_approved',0)+s['by_status'].get('auto_approved',0)}\nRejected: {s['by_status'].get('human_rejected',0)}\nBlocked: {s['by_status'].get('blocked',0)}", "parse_mode": "Markdown"})
                    elif cmd == "recent":
                        r = db.search_decisions(limit=5)
                        lines = [f"• [{d['status']}] {d['text'][:60]}" for d in r]
                        await c.post(f"{base}/sendMessage", json={"chat_id": chat_id, "text": "*Recent:*\n" + "\n".join(lines) if lines else "No decisions yet.", "parse_mode": "Markdown"})
            except Exception as e:
                LOG.error("Telegram bot error: %s", e); await asyncio.sleep(5)
