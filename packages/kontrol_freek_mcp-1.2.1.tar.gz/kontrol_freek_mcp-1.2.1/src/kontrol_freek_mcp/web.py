"""Web Dashboard — FastAPI-based approval interface and decision viewer."""

from __future__ import annotations
import logging
from typing import Any

LOG = logging.getLogger("kontrol-freek.web")

try:
    from fastapi import FastAPI
    from fastapi.responses import HTMLResponse
    from pydantic import BaseModel as PydanticBaseModel
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

def create_app(db: Any, notifier_module: Any) -> Any:
    if not HAS_FASTAPI:
        LOG.warning("FastAPI not installed — web dashboard disabled")
        return None

    app = FastAPI(title="Kontrol Freek Dashboard", version="1.0.0")

    class ApprovalReq(PydanticBaseModel):
        approved: bool; comment: str = ""

    class AnswerReq(PydanticBaseModel):
        answer: str

    @app.get("/", response_class=HTMLResponse)
    async def dashboard():
        stats = db.get_stats()
        recent = db.search_decisions(limit=20)
        rows = ""
        for d in recent:
            emoji = {"confirmed": "✅", "human_approved": "👤✅", "auto_approved": "🤖✅", "human_rejected": "❌", "blocked": "⛔", "pending": "⏳"}.get(d["status"], "❔")
            rows += f"<tr><td>{d['id']}</td><td>{emoji} {d['status']}</td><td>{d['risk_level']}</td><td>{d['category']}</td><td title=\"{d['text']}\">{d['text'][:80]}</td><td>{d['created_at'][:19]}</td></tr>"
        return f"""<!DOCTYPE html><html><head><title>Kontrol Freek</title>
<style>body{{font-family:-apple-system,sans-serif;max-width:1200px;margin:0 auto;padding:20px;background:#0a0a0a;color:#e0e0e0}}h1{{color:#ff6b35}}.stats{{display:flex;gap:20px;margin:20px 0}}.stat{{background:#1a1a2e;padding:16px 24px;border-radius:12px;text-align:center}}.stat .num{{font-size:2em;font-weight:bold;color:#ff6b35}}.stat .label{{font-size:.85em;color:#888}}table{{width:100%;border-collapse:collapse;margin-top:20px}}th,td{{padding:10px 12px;text-align:left;border-bottom:1px solid #222}}th{{background:#1a1a2e;color:#ff6b35}}tr:hover{{background:#111}}</style></head><body>
<h1>🔥 Kontrol Freek</h1>
<div class="stats"><div class="stat"><div class="num">{stats['total_decisions']}</div><div class="label">Total</div></div><div class="stat"><div class="num">{stats['by_status'].get('human_approved',0)}</div><div class="label">Human Approved</div></div><div class="stat"><div class="num">{stats['by_status'].get('auto_approved',0)}</div><div class="label">Auto Approved</div></div><div class="stat"><div class="num">{stats['by_status'].get('human_rejected',0)+stats['by_status'].get('blocked',0)}</div><div class="label">Rejected</div></div></div>
<table><thead><tr><th>#</th><th>Status</th><th>Risk</th><th>Category</th><th>Decision</th><th>Date</th></tr></thead><tbody>{rows}</tbody></table></body></html>"""

    @app.post("/approve/{rid}")
    async def approve(rid: str, body: ApprovalReq):
        notifier_module.resolve_approval(rid, body.approved, body.comment); return {"status": "ok", "request_id": rid}

    @app.post("/answer/{rid}")
    async def answer(rid: str, body: AnswerReq):
        notifier_module.resolve_answer(rid, body.answer); return {"status": "ok", "request_id": rid}

    @app.get("/decisions")
    async def list_decisions(keyword: str = "", category: str = "", limit: int = 50):
        return db.search_decisions(keyword=keyword, category=category, limit=limit)

    @app.get("/stats")
    async def stats():
        return db.get_stats()

    return app
