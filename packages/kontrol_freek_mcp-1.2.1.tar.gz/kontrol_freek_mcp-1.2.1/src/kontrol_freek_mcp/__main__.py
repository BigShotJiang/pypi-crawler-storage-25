"""python -m kontrol_freek_mcp"""
from .server import main
main()
