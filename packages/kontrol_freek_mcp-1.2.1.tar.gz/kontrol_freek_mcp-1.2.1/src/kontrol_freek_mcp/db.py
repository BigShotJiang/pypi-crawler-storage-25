"""SQLite decision database — append-only, queryable, with statistics."""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Any


class DecisionDB:
    def __init__(self, db_path: str = "./decisions.db"):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_schema()

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'general',
                risk_level TEXT NOT NULL DEFAULT 'medium',
                status TEXT NOT NULL DEFAULT 'pending',
                rationale TEXT DEFAULT '',
                context TEXT DEFAULT '',
                alternatives TEXT DEFAULT '[]',
                signature TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                embedding BLOB DEFAULT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_decisions_category ON decisions(category);
            CREATE INDEX IF NOT EXISTS idx_decisions_status ON decisions(status);
            CREATE INDEX IF NOT EXISTS idx_decisions_created ON decisions(created_at);
        """)
        self._conn.commit()

    def log_decision(self, text: str, category: str = "general", risk_level: str = "medium",
                     status: str = "pending", rationale: str = "", context: str = "",
                     alternatives: str = "[]", signature: str = "", embedding: bytes | None = None) -> int:
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO decisions (text,category,risk_level,status,rationale,context,alternatives,signature,created_at,updated_at,embedding) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (text, category, risk_level, status, rationale, context, alternatives, signature, now, now, embedding))
            self._conn.commit()
        return cur.lastrowid  # type: ignore

    def update_status(self, decision_id: int, status: str, rationale: str = ""):
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._conn.execute("UPDATE decisions SET status=?, rationale=?, updated_at=? WHERE id=?", (status, rationale, now, decision_id))
            self._conn.commit()

    def search_decisions(self, keyword: str = "", category: str = "", status: str = "", limit: int = 20) -> list[dict[str, Any]]:
        clauses, params = [], []
        if keyword:
            clauses.append("(text LIKE ? OR rationale LIKE ? OR context LIKE ?)")
            kw = f"%{keyword}%"; params += [kw, kw, kw]
        if category: clauses.append("category = ?"); params.append(category)
        if status: clauses.append("status = ?"); params.append(status)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        params.append(limit)
        return [dict(r) for r in self._conn.execute(f"SELECT * FROM decisions{where} ORDER BY created_at DESC LIMIT ?", params).fetchall()]

    def get_all_for_embedding(self) -> list[dict[str, Any]]:
        return [dict(r) for r in self._conn.execute(
            "SELECT id, text, category, status, risk_level, created_at, embedding FROM decisions ORDER BY id"
        ).fetchall()]

    def save_embedding(self, decision_id: int, embedding: bytes) -> None:
        with self._lock:
            self._conn.execute("UPDATE decisions SET embedding=? WHERE id=?", (embedding, decision_id))
            self._conn.commit()

    def get_stats(self) -> dict[str, Any]:
        total = self._conn.execute("SELECT COUNT(*) FROM decisions").fetchone()[0]
        by_status = {r["status"]: r["cnt"] for r in self._conn.execute("SELECT status, COUNT(*) as cnt FROM decisions GROUP BY status")}
        by_category = {r["category"]: r["cnt"] for r in self._conn.execute("SELECT category, COUNT(*) as cnt FROM decisions GROUP BY category")}
        by_risk = {r["risk_level"]: r["cnt"] for r in self._conn.execute("SELECT risk_level, COUNT(*) as cnt FROM decisions GROUP BY risk_level")}
        recent = [dict(r) for r in self._conn.execute("SELECT text, status, created_at FROM decisions ORDER BY created_at DESC LIMIT 5").fetchall()]
        return {"total_decisions": total, "by_status": by_status, "by_category": by_category, "by_risk_level": by_risk, "recent": recent}

    def close(self):
        self._conn.close()
