"""Kontrol Freek — AI assumption firewall MCP server."""
__version__ = "1.0.0"
from .server import mcp
