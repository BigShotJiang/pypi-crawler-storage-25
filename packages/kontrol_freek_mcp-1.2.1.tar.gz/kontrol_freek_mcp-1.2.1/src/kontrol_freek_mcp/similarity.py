"""Semantic Similarity Matcher — past decision comparison and contradiction detection.

Two modes:
1. sentence-transformers installed → real embedding cosine similarity
   Embeddings are persisted to SQLite so each decision is encoded only once.
2. Not installed → TF-IDF cosine similarity (zero-dependency fallback)
"""

from __future__ import annotations
import logging, math, re, struct
from collections import Counter
from typing import Any

LOG = logging.getLogger("kontrol-freek.similarity")
_model = None
_use_embeddings = None

def _check_embeddings() -> bool:
    global _use_embeddings, _model
    if _use_embeddings is not None: return _use_embeddings
    try:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer("all-MiniLM-L6-v2")
        _use_embeddings = True
        LOG.info("Using sentence-transformers for semantic matching")
    except ImportError:
        _use_embeddings = False
        LOG.info("sentence-transformers not installed, using TF-IDF fallback")
    return _use_embeddings

def _tokenize(text: str) -> list[str]:
    return re.findall(r'\w+', text.lower())

def _tfidf_cosine(a: str, b: str) -> float:
    ta, tb = Counter(_tokenize(a)), Counter(_tokenize(b))
    if not ta or not tb: return 0.0
    vocab = set(ta) | set(tb)
    dot = sum(ta.get(w, 0) * tb.get(w, 0) for w in vocab)
    na, nb = math.sqrt(sum(v**2 for v in ta.values())), math.sqrt(sum(v**2 for v in tb.values()))
    return dot / (na * nb) if na and nb else 0.0

def _vec_to_bytes(vec: list[float]) -> bytes:
    return struct.pack(f"{len(vec)}f", *vec)

def _bytes_to_vec(b: bytes) -> list[float]:
    n = len(b) // 4
    return list(struct.unpack(f"{n}f", b))

def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0

def _embed_single(text: str) -> list[float] | None:
    if _model is None: return None
    return _model.encode([text], normalize_embeddings=True)[0].tolist()

class SemanticMatcher:
    def __init__(self, db: Any):
        self.db = db

    def _get_or_compute_embedding(self, decision: dict[str, Any]) -> list[float] | None:
        """Return stored embedding or encode and persist it."""
        raw = decision.get("embedding")
        if raw:
            try:
                return _bytes_to_vec(raw)
            except Exception:
                pass
        if not _check_embeddings():
            return None
        vec = _embed_single(decision["text"])
        if vec is not None:
            try:
                self.db.save_embedding(decision["id"], _vec_to_bytes(vec))
            except Exception as e:
                LOG.warning("Failed to persist embedding for decision %s: %s", decision["id"], e)
        return vec

    def find_similar(self, text: str, top_k: int = 5) -> list[dict[str, Any]]:
        decisions = self.db.get_all_for_embedding()
        if not decisions: return []

        if _check_embeddings():
            query_vec = _embed_single(text)
            if query_vec:
                scores = []
                for d in decisions:
                    vec = self._get_or_compute_embedding(d)
                    scores.append(_cosine(query_vec, vec) if vec else 0.0)
            else:
                scores = [_tfidf_cosine(text, d["text"]) for d in decisions]
        else:
            scores = [_tfidf_cosine(text, d["text"]) for d in decisions]

        scored = [{**d, "score": scores[i] if i < len(scores) else 0.0} for i, d in enumerate(decisions)]
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]

    def find_contradictions(self, assumption: str, similar: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Detect contradictions: high similarity but rejected, or negation patterns."""
        contradictions = []
        negation_pairs = [
            ("use", "avoid"), ("add", "remove"), ("enable", "disable"),
            ("include", "exclude"), ("yes", "no"), ("true", "false"),
            ("allow", "deny"), ("accept", "reject"), ("create", "delete"),
            ("keep", "drop"), ("start", "stop"), ("open", "close"),
        ]
        a_lower = assumption.lower()
        for s in similar:
            if s["score"] < 0.4: continue
            if s["score"] >= 0.7 and s.get("status") in ("human_rejected", "blocked"):
                contradictions.append({"id": s["id"], "text": s["text"], "reason": f"Similar assumption was previously rejected (score: {s['score']:.2f})"})
                continue
            s_lower = s["text"].lower()
            for pos, neg in negation_pairs:
                if (pos in a_lower and neg in s_lower) or (neg in a_lower and pos in s_lower):
                    if s["score"] >= 0.5:
                        contradictions.append({"id": s["id"], "text": s["text"], "reason": f"Opposing direction detected: '{pos}' vs '{neg}'"})
                        break
        return contradictions
