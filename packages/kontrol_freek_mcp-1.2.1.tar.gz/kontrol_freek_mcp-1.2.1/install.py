#!/usr/bin/env python3
"""
Kontrol Freek — Installer & Auto-Start Setup
==============================================
Sets up auto-start on macOS (launchd), Linux (systemd), Windows (Task Scheduler).
Registers the MCP server with compatible clients. Generates .env with random HMAC secret.

Usage:
  python install.py              # Interactive install
  python install.py --minimal    # pip install + config only
  python install.py --uninstall  # Remove service
  python install.py --status     # Health check
"""

from __future__ import annotations
import json, os, platform, shutil, subprocess, sys, textwrap
from pathlib import Path

SYSTEM = platform.system()
HOME = Path.home()
IS_MAC, IS_LINUX, IS_WIN = SYSTEM == "Darwin", SYSTEM == "Linux", SYSTEM == "Windows"
KF_HOME = HOME / ".kontrol-freek"
LAUNCHD_LABEL = "com.kontrol-freek.mcp"
LAUNCHD_PLIST = HOME / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
SYSTEMD_DIR = HOME / ".config" / "systemd" / "user"
SYSTEMD_SERVICE = SYSTEMD_DIR / "kontrol-freek.service"

def _c(t, code): return f"\033[{code}m{t}\033[0m" if sys.stdout.isatty() else t
def green(t): return _c(t, "32")
def yellow(t): return _c(t, "33")
def red(t): return _c(t, "31")
def bold(t): return _c(t, "1")
def dim(t): return _c(t, "2")
def _run(cmd, **kw): return subprocess.run(cmd, capture_output=True, text=True, **kw)

def install_package(full=True):
    print(bold("\n📦 Installing package..."))
    extras = ".[full]" if full else "."
    d = str(Path(__file__).parent)
    r = _run([sys.executable, "-m", "pip", "install", "-e", extras], cwd=d)
    if r.returncode != 0:
        r = _run([sys.executable, "-m", "pip", "install", "-e", extras, "--break-system-packages"], cwd=d)
    if r.returncode != 0: print(red(f"❌ pip install failed:\n{r.stderr}")); sys.exit(1)
    print(green("✅ Package installed"))

def setup_directories():
    print(bold("\n📁 Setting up directories..."))
    KF_HOME.mkdir(exist_ok=True)
    env_file = KF_HOME / ".env"
    if not env_file.exists():
        import secrets
        env_file.write_text(textwrap.dedent(f"""\
            KF_HMAC_SECRET={secrets.token_hex(32)}
            KF_DB_PATH={KF_HOME}/decisions.db
            KF_AUDIT_PATH={KF_HOME}/audit.jsonl
            KF_PROJECT_ROOT=.
            KF_TELEGRAM_TOKEN=
            KF_TELEGRAM_CHAT_ID=
            KF_SLACK_WEBHOOK=
            KF_WEB_PORT=9111
            KF_SIMILARITY_THRESHOLD=0.78
            KF_DECAY_DAYS=90
        """))
        print(green(f"✅ .env created: {env_file}"))
        print(yellow(f"   → Add Telegram token: nano {env_file}"))
    else:
        print(dim(f"   .env already exists: {env_file}"))

def create_wrapper():
    wrapper = KF_HOME / ("run.bat" if IS_WIN else "run.sh")
    kf_bin = shutil.which("kontrol-freek") or f"{sys.executable} -m kontrol_freek_mcp"
    if IS_WIN:
        wrapper.write_text(textwrap.dedent(f"""\
            @echo off
            cd /d "{KF_HOME}"
            for /f "tokens=1,2 delims==" %%a in (.env) do set %%a=%%b
            :loop
            echo [%date% %time%] Starting Kontrol Freek...
            {kf_bin}
            echo [%date% %time%] Crashed, restarting in 5s...
            timeout /t 5
            goto loop
        """))
    else:
        wrapper.write_text(textwrap.dedent(f"""\
            #!/usr/bin/env bash
            set -euo pipefail
            cd "{KF_HOME}"
            [ -f .env ] && {{ set -a; source .env; set +a; }}
            MAX=10; COUNT=0; COOL=5
            while [ $COUNT -lt $MAX ]; do
                echo "[$(date)] Starting Kontrol Freek (attempt $((COUNT+1)))..."
                {kf_bin} "$@" && break
                COUNT=$((COUNT+1))
                echo "[$(date)] Crashed (exit $?), restarting in ${{COOL}}s... ($COUNT/$MAX)"
                sleep $COOL; COOL=$((COOL*2))
            done
            [ $COUNT -ge $MAX ] && echo "[$(date)] Max restarts reached." && exit 1
        """))
        wrapper.chmod(0o755)
    print(green(f"✅ Wrapper: {wrapper}"))
    return wrapper

def install_macos(wrapper):
    print(bold("\n🍎 Installing macOS LaunchAgent..."))
    plist = textwrap.dedent(f"""\
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0"><dict>
            <key>Label</key><string>{LAUNCHD_LABEL}</string>
            <key>ProgramArguments</key><array><string>{wrapper}</string></array>
            <key>RunAtLoad</key><true/>
            <key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
            <key>StandardOutPath</key><string>{KF_HOME}/stdout.log</string>
            <key>StandardErrorPath</key><string>{KF_HOME}/stderr.log</string>
            <key>WorkingDirectory</key><string>{KF_HOME}</string>
            <key>EnvironmentVariables</key><dict><key>PATH</key><string>/usr/local/bin:/usr/bin:/bin:{Path(sys.executable).parent}</string></dict>
            <key>ThrottleInterval</key><integer>10</integer>
        </dict></plist>""")
    LAUNCHD_PLIST.parent.mkdir(parents=True, exist_ok=True)
    LAUNCHD_PLIST.write_text(plist)
    _run(["launchctl", "bootout", f"gui/{os.getuid()}/{LAUNCHD_LABEL}"])
    r = _run(["launchctl", "bootstrap", f"gui/{os.getuid()}", str(LAUNCHD_PLIST)])
    if r.returncode != 0: _run(["launchctl", "load", str(LAUNCHD_PLIST)])
    print(green("✅ LaunchAgent installed and started"))

def install_linux(wrapper):
    print(bold("\n🐧 Installing systemd user service..."))
    unit = textwrap.dedent(f"""\
        [Unit]
        Description=Kontrol Freek MCP Server
        After=network.target
        [Service]
        Type=simple
        ExecStart={wrapper}
        Restart=on-failure
        RestartSec=10
        WorkingDirectory={KF_HOME}
        Environment=PATH=/usr/local/bin:/usr/bin:/bin:{Path(sys.executable).parent}
        [Install]
        WantedBy=default.target""")
    SYSTEMD_DIR.mkdir(parents=True, exist_ok=True)
    SYSTEMD_SERVICE.write_text(unit)
    _run(["systemctl", "--user", "daemon-reload"])
    _run(["systemctl", "--user", "enable", "kontrol-freek"])
    r = _run(["systemctl", "--user", "start", "kontrol-freek"])
    if r.returncode == 0: print(green("✅ systemd service installed and started"))
    else: print(yellow(f"⚠️  Could not start (may be WSL): {r.stderr.strip()}"))
    _run(["loginctl", "enable-linger", os.getenv("USER", "")])

def install_windows(wrapper):
    print(bold("\n🪟 Installing Windows Task Scheduler..."))
    r = _run(["schtasks", "/create", "/tn", "KontrolFreek", "/tr", str(wrapper), "/sc", "onlogon", "/rl", "limited", "/f"])
    if r.returncode == 0:
        print(green("✅ Scheduled task installed")); _run(["schtasks", "/run", "/tn", "KontrolFreek"])
    else: print(red(f"❌ Failed: {r.stderr}\n   Try running as administrator."))

def uninstall():
    if IS_MAC:
        _run(["launchctl", "bootout", f"gui/{os.getuid()}/{LAUNCHD_LABEL}"])
        _run(["launchctl", "unload", str(LAUNCHD_PLIST)])
        if LAUNCHD_PLIST.exists(): LAUNCHD_PLIST.unlink()
    elif IS_LINUX:
        _run(["systemctl", "--user", "stop", "kontrol-freek"])
        _run(["systemctl", "--user", "disable", "kontrol-freek"])
        if SYSTEMD_SERVICE.exists(): SYSTEMD_SERVICE.unlink()
        _run(["systemctl", "--user", "daemon-reload"])
    elif IS_WIN:
        _run(["schtasks", "/delete", "/tn", "KontrolFreek", "/f"])
    print(green("✅ Service removed. To uninstall package: pip uninstall kontrol-freek-mcp"))

def configure_mcp_clients():
    print(bold("\n🔌 Configuring MCP clients..."))
    kf_bin = shutil.which("kontrol-freek")
    env_vars = {}
    env_file = KF_HOME / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                if v.strip(): env_vars[k.strip()] = v.strip()
    entry = {"command": kf_bin or sys.executable, "args": [] if kf_bin else ["-m", "kontrol_freek_mcp"], "env": env_vars}

    # Register via MCP CLI if available (works with any MCP-compatible CLI tool)
    mcp_bin = shutil.which("mcp")
    if mcp_bin:
        cmd = [mcp_bin, "add", "kontrol-freek", entry["command"]]
        for k, v in env_vars.items():
            cmd += ["-e", f"{k}={v}"]
        if entry["args"]:
            cmd += ["--"] + entry["args"]
        r = _run(cmd)
        if r.returncode == 0:
            print(green("✅ MCP client registered (global)"))
        else:
            print(yellow(f"⚠️  mcp add failed: {r.stderr.strip()}"))

    # Write to MCP Desktop config locations (macOS / Windows)
    desktop_configs = []
    if IS_MAC:
        desktop_configs.append(HOME / "Library" / "Application Support" / "MCP" / "config.json")
    if IS_WIN:
        desktop_configs.append(Path(os.getenv("APPDATA", "")) / "MCP" / "config.json")

    for path in desktop_configs:
        cfg = {}
        if path.exists():
            try: cfg = json.loads(path.read_text())
            except: cfg = {}
        cfg.setdefault("mcpServers", {})["kontrol-freek"] = entry
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cfg, indent=2))
        print(green(f"✅ MCP config: {path}"))

    if not mcp_bin and not desktop_configs:
        print(yellow("⚠️  No MCP CLI found. Add manually to your MCP client config:"))
        print(json.dumps({"mcpServers": {"kontrol-freek": entry}}, indent=2))


def check_status():
    print(bold("\n🔍 Status check..."))
    r = _run([sys.executable, "-c", "import kontrol_freek_mcp; print(kontrol_freek_mcp.__version__)"])
    print(green(f"  ✅ Package: v{r.stdout.strip()}") if r.returncode == 0 else red("  ❌ Package not installed"))
    db_path = KF_HOME / "decisions.db"
    print(green(f"  ✅ DB: {db_path} ({db_path.stat().st_size} bytes)") if db_path.exists() else dim("  ⏳ DB not created yet (created on first use)"))
    if IS_MAC:
        r = _run(["launchctl", "print", f"gui/{os.getuid()}/{LAUNCHD_LABEL}"])
        print(green("  ✅ macOS LaunchAgent: active") if r.returncode == 0 else yellow("  ⚠️  LaunchAgent: not active"))
    elif IS_LINUX:
        r = _run(["systemctl", "--user", "is-active", "kontrol-freek"])
        s = r.stdout.strip()
        print(green("  ✅ systemd: active") if s == "active" else yellow(f"  ⚠️  systemd: {s}"))
    audit_path = KF_HOME / "audit.jsonl"
    if audit_path.exists():
        from kontrol_freek_mcp.audit import AuditTrail
        secret = "change-me"
        env_file = KF_HOME / ".env"
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                if line.startswith("KF_HMAC_SECRET="): secret = line.split("=", 1)[1].strip()
        valid, count = AuditTrail(str(audit_path), secret).verify_chain()
        print(green(f"  ✅ Audit chain: {count} entries, integrity OK") if valid else red(f"  ❌ Audit chain BROKEN at ~line {count}"))

def main():
    import argparse
    p = argparse.ArgumentParser(description="Kontrol Freek Installer")
    p.add_argument("--minimal", action="store_true", help="pip install + config only")
    p.add_argument("--uninstall", action="store_true")
    p.add_argument("--status", action="store_true")
    p.add_argument("--lite", action="store_true", help="Install without sentence-transformers")
    a = p.parse_args()

    print(bold("🔥 Kontrol Freek Installer"))
    print(dim(f"   Platform: {SYSTEM} ({platform.machine()})"))
    print(dim(f"   Python:   {sys.version.split()[0]}"))
    print(dim(f"   Home:     {KF_HOME}"))

    if a.status: check_status(); return
    if a.uninstall: uninstall(); return

    install_package(full=not a.lite)
    setup_directories()
    if not a.minimal:
        w = create_wrapper()
        if IS_MAC: install_macos(w)
        elif IS_LINUX: install_linux(w)
        elif IS_WIN: install_windows(w)
    configure_mcp_clients()
    check_status()

    print(bold(f"\n{'='*60}"))
    print(green("✅ Installation complete!"))
    print(f"\n  Home:   {KF_HOME}")
    print(f"  Config: {KF_HOME}/.env")
    print(f"  Logs:   {KF_HOME}/stdout.log")
    print(yellow(f"\n  Next steps:"))
    print(f"  1. Add Telegram:    nano {KF_HOME}/.env")
    print(f"  2. Check status:    python install.py --status")
    print(f"  3. Uninstall:       python install.py --uninstall")
    print(bold(f"{'='*60}\n"))

if __name__ == "__main__":
    main()
