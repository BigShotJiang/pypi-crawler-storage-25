# Graph Report - .  (2026-04-11)

## Corpus Check
- Corpus is ~8,728 words - fits in a single context window. You may not need a graph.

## Summary
- 171 nodes · 389 edges · 14 communities detected
- Extraction: 72% EXTRACTED · 28% INFERRED · 0% AMBIGUOUS · INFERRED: 109 edges (avg confidence: 0.5)
- Token cost: 0 input · 0 output

## God Nodes (most connected - your core abstractions)
1. `DecisionDB` - 29 edges
2. `SemanticMatcher` - 24 edges
3. `PolicyEngine` - 24 edges
4. `AuditTrail` - 23 edges
5. `NotificationRouter` - 23 edges
6. `RiskLevel` - 21 edges
7. `main()` - 14 edges
8. `Kontrol Freek MCP` - 13 edges
9. `green()` - 12 edges
10. `_get_db()` - 11 edges

## Surprising Connections (you probably didn't know these)
- `TestDecisionDB` --uses--> `DecisionDB`  [INFERRED]
  tests/test_core.py → src/kontrol_freek_mcp/db.py
- `TestDecisionDB` --uses--> `AuditTrail`  [INFERRED]
  tests/test_core.py → src/kontrol_freek_mcp/audit.py
- `TestPolicyEngine` --uses--> `DecisionDB`  [INFERRED]
  tests/test_core.py → src/kontrol_freek_mcp/db.py
- `TestPolicyEngine` --uses--> `AuditTrail`  [INFERRED]
  tests/test_core.py → src/kontrol_freek_mcp/audit.py
- `TestAuditTrail` --uses--> `DecisionDB`  [INFERRED]
  tests/test_core.py → src/kontrol_freek_mcp/db.py

## Hyperedges (group relationships)
- **Kontrol Freek MCP Tools** — readme_check_assumption, readme_confirm_decision, readme_ask_human, readme_query_decisions, readme_get_firewall_stats, readme_healthcheck, readme_setup_project [EXTRACTED 1.00]
- **Notification Channels** — readme_telegram, readme_slack, readme_web_dashboard [EXTRACTED 1.00]

## Communities

### Community 0 - "Policy Engine & Risk Scoring"
Cohesion: 0.08
Nodes (19): Enum, PolicyEngine, PolicyVerdict, Policy Engine — risk scoring, auto-approve / block / review decisions with time, Policy rules:     1. Critical risk → always block     2. Contradiction detected, RiskLevel, assumption_discipline_prompt(), get_firewall_stats() (+11 more)

### Community 1 - "Docs & MCP Tool Contracts"
Cohesion: 0.11
Nodes (21): Hot Config Reload, Mandatory Rules for AI Agents, ask_human Tool, AI Assumption Firewall, HMAC-SHA256 Signed Audit Trail, check_assumption Tool, confirm_decision Tool, FastMCP Python Server (+13 more)

### Community 2 - "Install & Setup Scripts"
Cohesion: 0.44
Nodes (17): bold(), _c(), check_status(), configure_mcp_clients(), create_wrapper(), dim(), green(), install_linux() (+9 more)

### Community 3 - "Notification Router"
Cohesion: 0.21
Nodes (8): _new_rid(), NotificationRouter, Notification Router — Telegram, Slack, Web Dashboard, Terminal fallback.  Routes, Generate a short, collision-resistant request ID (timestamp prefix + uuid suffix, Start Telegram polling loop, cancelling any existing task for this token first., Long-poll Telegram for /kf approve/reject/answer commands., resolve_answer(), resolve_approval()

### Community 4 - "Decision Database"
Cohesion: 0.18
Nodes (2): DecisionDB, SQLite decision database — append-only, queryable, with statistics.

### Community 5 - "Semantic Similarity"
Cohesion: 0.29
Nodes (9): _bytes_to_vec(), _check_embeddings(), _cosine(), _embed_single(), Semantic Similarity Matcher — past decision comparison and contradiction detecti, Return stored embedding or encode and persist it., _tfidf_cosine(), _tokenize() (+1 more)

### Community 6 - "Server Entry & Config Cache"
Cohesion: 0.22
Nodes (6): Kontrol Freek — AI assumption firewall MCP server., python -m kontrol_freek_mcp, _invalidate_notifier(), Kontrol Freek MCP Server ========================= An MCP server that catches AI, Initialize Kontrol Freek for the current project.      Checks if .kontrol-freek., setup_project()

### Community 7 - "Audit Trail"
Cohesion: 0.22
Nodes (5): AuditTrail, Cryptographic audit trail — HMAC-SHA256 signed, hash-chained, append-only JSONL., Verify the audit chain. Returns (is_valid, line_count)., query_decisions(), Search past decisions for context and consistency.     Always pass project_root

### Community 8 - "Project Config & Health"
Cohesion: 0.25
Nodes (9): _get_notifier(), healthcheck(), _load_project_config(), _project_data_dir(), _project_slug(), Full health check — DB, audit chain, channels.     Always pass project_root as t, Load .kontrol-freek.json from the project root if it exists., Return a filesystem-safe slug for a project root path. (+1 more)

### Community 9 - "Assumption Check Pipeline"
Cohesion: 0.36
Nodes (8): check_assumption(), _get_db(), _get_matcher(), _get_policy(), _process_human_response(), Verify an assumption against past decisions. Checks for contradictions,     scor, _sign(), stats_resource()

### Community 10 - "Human Question & Revoke"
Cohesion: 0.33
Nodes (6): ask_human(), _ask_human_question(), _get_audit(), Ask the human a direct question and wait for their response. Call this whenever, Revoke or supersede a previously approved decision.      Use this when a past de, revoke_decision()

### Community 11 - "Telegram Bot"
Cohesion: 0.67
Nodes (1): Telegram Bot — polling-based bot for receiving approval and answer responses.  C

### Community 12 - "Confirm & Human Approval"
Cohesion: 0.67
Nodes (3): confirm_decision(), Record a finalized decision. Irreversible decisions always require human approva, _request_human_approval()

### Community 13 - "Web Dashboard"
Cohesion: 0.67
Nodes (1): Web Dashboard — FastAPI-based approval interface and decision viewer.

## Knowledge Gaps
- **28 isolated node(s):** `Telegram Bot — polling-based bot for receiving approval and answer responses.  C`, `SQLite decision database — append-only, queryable, with statistics.`, `Web Dashboard — FastAPI-based approval interface and decision viewer.`, `Cryptographic audit trail — HMAC-SHA256 signed, hash-chained, append-only JSONL.`, `Verify the audit chain. Returns (is_valid, line_count).` (+23 more)
  These have ≤1 connection - possible missing edges or undocumented components.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `SemanticMatcher` connect `Policy Engine & Risk Scoring` to `Semantic Similarity`, `Server Entry & Config Cache`, `Audit Trail`, `Project Config & Health`, `Assumption Check Pipeline`, `Human Question & Revoke`, `Confirm & Human Approval`?**
  _High betweenness centrality (0.103) - this node is a cross-community bridge._
- **Why does `NotificationRouter` connect `Notification Router` to `Policy Engine & Risk Scoring`, `Server Entry & Config Cache`, `Audit Trail`, `Project Config & Health`, `Assumption Check Pipeline`, `Human Question & Revoke`, `Confirm & Human Approval`?**
  _High betweenness centrality (0.103) - this node is a cross-community bridge._
- **Why does `DecisionDB` connect `Decision Database` to `Policy Engine & Risk Scoring`, `Server Entry & Config Cache`, `Audit Trail`, `Project Config & Health`, `Assumption Check Pipeline`, `Human Question & Revoke`, `Confirm & Human Approval`?**
  _High betweenness centrality (0.102) - this node is a cross-community bridge._
- **Are the 19 inferred relationships involving `DecisionDB` (e.g. with `TestDecisionDB` and `TestPolicyEngine`) actually correct?**
  _`DecisionDB` has 19 INFERRED edges - model-reasoned connections that need verification._
- **Are the 19 inferred relationships involving `SemanticMatcher` (e.g. with `TestDecisionDB` and `TestPolicyEngine`) actually correct?**
  _`SemanticMatcher` has 19 INFERRED edges - model-reasoned connections that need verification._
- **Are the 19 inferred relationships involving `PolicyEngine` (e.g. with `TestDecisionDB` and `TestPolicyEngine`) actually correct?**
  _`PolicyEngine` has 19 INFERRED edges - model-reasoned connections that need verification._
- **Are the 19 inferred relationships involving `AuditTrail` (e.g. with `TestDecisionDB` and `TestPolicyEngine`) actually correct?**
  _`AuditTrail` has 19 INFERRED edges - model-reasoned connections that need verification._