"""High-level `Agent` convenience layer.

`Agent` is a thin composition over `Harness`, `SessionCache`, and the built-in
tools. It exists so the quick-start example reads cleanly. The low-level
primitives remain the canonical teaching surface — `agent.explain()` returns a
sketch of the equivalent explicit wiring.

`Agent.run()` is one-shot: each call builds a fresh `Harness` and starts with a
new message history. It is not a chat session.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from dataact.cache import SessionCache
from dataact.loop import Harness
from dataact.providers.base import ProviderAdapter
from dataact.schema import infer_input_schema
from dataact.tools.connectors import ConnectorRegistry
from dataact.tools.interpreter import PythonInterpreter
from dataact.tools.planner import Planner
from dataact.tools.subagent import make_subagent_spec
from dataact.tools.variables import make_list_variables_spec
from dataact.types import ToolSpec


@dataclass(frozen=True)
class _ConnectorToolDefinition:
    connector_name: str
    fn: Callable[..., Any]
    description: str
    input_schema: dict


@dataclass(frozen=True)
class _ConnectorDefinition:
    name: str
    description: str


class ConnectorBuilder:
    def __init__(self, agent: Agent, name: str) -> None:
        self._agent = agent
        self._name = name

    def tool(
        self,
        fn: Callable[..., Any],
        *,
        description: str,
        input_schema: dict | None = None,
    ) -> Callable[..., Any]:
        schema = input_schema if input_schema is not None else infer_input_schema(fn)
        self._agent._connector_tools.append(
            _ConnectorToolDefinition(
                connector_name=self._name,
                fn=fn,
                description=description,
                input_schema=schema,
            )
        )
        return fn


class Agent:
    def __init__(
        self,
        adapter: ProviderAdapter,
        system: str,
        *,
        max_turns: int = 25,
        cache: SessionCache | None = None,
        run_dir: str | Path | None = None,
    ) -> None:
        self._adapter = adapter
        self._system = system
        self._max_turns = max_turns
        self._cache = cache if cache is not None else SessionCache()
        self._run_dir = run_dir
        self._last_harness: Harness | None = None
        self._last_run_file: str | None = None
        self._connectors: dict[str, _ConnectorDefinition] = {}
        self._connector_tools: list[_ConnectorToolDefinition] = []
        self._planner_enabled = False
        self._subagent_factory: Callable[[], ProviderAdapter] | None = None

    @property
    def cache(self) -> SessionCache:
        return self._cache

    @property
    def last_harness(self) -> Harness | None:
        return self._last_harness

    @property
    def last_run_file(self) -> str | None:
        return self._last_run_file

    def connector(self, name: str, *, description: str) -> ConnectorBuilder:
        self._connectors[name] = _ConnectorDefinition(
            name=name,
            description=description,
        )
        return ConnectorBuilder(self, name)

    def enable_planner(self) -> Agent:
        self._planner_enabled = True
        return self

    def enable_subagents(
        self, *, adapter_factory: Callable[[], ProviderAdapter]
    ) -> Agent:
        self._subagent_factory = adapter_factory
        return self

    def run(self, user_message: str) -> str:
        planner = Planner() if self._planner_enabled else None
        tools = self._build_tools(planner=planner)
        if self._subagent_factory is not None:
            subagent_parent_tools = self._build_tools(planner=None)
            effective_run_dir = (
                str(self._run_dir) if self._run_dir is not None else "./runs"
            )
            tools.append(
                make_subagent_spec(
                    adapter_factory=self._subagent_factory,
                    parent_tools=subagent_parent_tools,
                    parent_cache=self._cache,
                    run_dir=effective_run_dir,
                    make_sub_tools=lambda sub_cache: self._build_tools(
                        planner=None,
                        cache=sub_cache,
                    ),
                )
            )
        harness_kwargs: dict = {
            "adapter": self._adapter,
            "system": self._system,
            "tools": tools,
            "max_turns": self._max_turns,
            "cache": self._cache,
        }
        if self._run_dir is not None:
            harness_kwargs["run_dir"] = str(self._run_dir)

        harness = Harness(**harness_kwargs)
        if planner is not None:
            harness.register_reminder(planner.reminder_hook)
        self._last_harness = harness
        result = harness.run(user_message)
        # Newest jsonl in the run dir belongs to this run
        run_dir = Path(harness._run_dir)
        files = sorted(run_dir.glob("*.jsonl"), key=lambda f: f.stat().st_mtime)
        if files:
            self._last_run_file = str(files[-1])
        return result

    def explain(self) -> str:
        return _EXPLAIN_TEMPLATE.format(
            system=_truncate(self._system),
            max_turns=self._max_turns,
            run_dir=self._run_dir if self._run_dir is not None else "./runs",
        )

    def _build_tools(
        self,
        *,
        planner: Planner | None = None,
        cache: SessionCache | None = None,
    ) -> list[ToolSpec]:
        target_cache = cache if cache is not None else self._cache
        tools = [
            PythonInterpreter.make_tool_spec(target_cache),
            make_list_variables_spec(target_cache),
        ]
        if planner is not None:
            tools.extend(planner.make_tool_specs())
        if self._connectors:
            registry = ConnectorRegistry()
            for connector_name, connector in self._connectors.items():
                registry.register(
                    name=connector_name,
                    description=connector.description,
                    tools=[
                        ToolSpec(
                            name=f"{connector_name}__{definition.fn.__name__}",
                            description=definition.description,
                            input_schema=definition.input_schema,
                            handler=definition.fn,
                            visible=False,
                        )
                        for definition in self._connector_tools
                        if definition.connector_name == connector_name
                    ],
                )
            tools.append(registry.get_load_connectors_spec())
            tools.extend(registry.make_wrapped_specs(target_cache))
        return tools


_EXPLAIN_TEMPLATE = """\
Agent is a thin composition layer. The equivalent explicit wiring is:

    from dataact.cache import SessionCache
    from dataact.loop import Harness
    from dataact.tools.interpreter import PythonInterpreter
    from dataact.tools.variables import make_list_variables_spec

    cache = SessionCache()
    tools = [
        PythonInterpreter.make_tool_spec(cache),
        make_list_variables_spec(cache),
    ]
    harness = Harness(
        adapter=adapter,
        system={system!r},
        tools=tools,
        max_turns={max_turns},
        run_dir={run_dir!r},
        cache=cache,
    )
    harness.run(user_message)

Each call to Agent.run() builds a fresh Harness with fresh tool specs.
Model-visible tools include python_interpreter and list_variables.
The message history resets per run; this is not a chat session.
"""


def _truncate(text: str, limit: int = 80) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"
