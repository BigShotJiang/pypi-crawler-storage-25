"""由 ``gui_layout.json`` 的 ``chrome`` 节挂载窗口外壳（可见性、pack 均由配置决定）。"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import TYPE_CHECKING, Any

from .gui_mount import apply_pack, pack_options

if TYPE_CHECKING:
    from .gui import TestBenchGUI


def chrome_visible(block: dict[str, Any] | None, *, default: bool = True) -> bool:
    if not isinstance(block, dict):
        return default
    v = block.get("visible")
    return default if v is None else bool(v)


def build_shell(gui: TestBenchGUI, snap0: dict[str, Any], comp0: dict[str, Any]) -> None:
    """根据 JSON ``chrome`` 构建 menubar / 顶栏 / 摘要 / 工具栏 / 分页区。"""
    ch = gui._layout.get("chrome") or {}

    gui.expression_var = tk.StringVar(value=str(snap0.get("expression_line") or ""))
    gui.display_var = tk.StringVar(value=str(snap0.get("display") or ""))

    if chrome_visible(ch.get("menubar"), default=True):
        gui._build_menubar()

    if chrome_visible(ch.get("header"), default=True):
        _build_header(gui, ch)
    if chrome_visible(ch.get("display_strip"), default=True):
        _build_display_strip(gui, ch)
    if chrome_visible(ch.get("toolbar"), default=True):
        _build_toolbar(gui, ch)

    _build_main_paned(gui, ch, comp0)


def _build_header(gui: TestBenchGUI, ch: dict[str, Any]) -> None:
    hdr = ch.get("header") or {}
    header = tk.Frame(gui.root, bg=gui._bg)
    apply_pack(header, hdr.get("layout"))
    tl = hdr.get("title_label") or {}
    tk.Label(
        header,
        text=str(gui._layout.get("title_bar", "")),
        bg=gui._bg,
        fg=gui._main_fg,
        font=gui.font_title,
    ).pack(**pack_options(tl.get("layout")))


def _build_display_strip(gui: TestBenchGUI, ch: dict[str, Any]) -> None:
    ds = ch.get("display_strip") or {}
    disp_frame = tk.Frame(
        gui.root,
        bg=gui._display_bg,
        highlightthickness=int(ds.get("highlightthickness", 1)),
        highlightbackground=str(ds.get("highlightbackground", gui._display_border)),
    )
    apply_pack(disp_frame, ds.get("layout"))
    ex = ds.get("expression_label") or {}
    ep = ex.get("props") or {}
    tk.Label(
        disp_frame,
        textvariable=gui.expression_var,
        bg=gui._display_bg,
        fg=gui._expr_fg,
        font=gui.font_expr,
        **{k: ep[k] for k in ("anchor", "padx", "pady") if k in ep},
    ).pack(**pack_options(ex.get("layout")))
    ml = ds.get("main_label") or {}
    mp = ml.get("props") or {}
    tk.Label(
        disp_frame,
        textvariable=gui.display_var,
        bg=gui._display_bg,
        fg=gui._main_fg,
        font=gui.font_display,
        **{k: mp[k] for k in ("anchor", "padx", "pady") if k in mp},
    ).pack(**pack_options(ml.get("layout")))


def _build_toolbar(gui: TestBenchGUI, ch: dict[str, Any]) -> None:
    tb_spec = ch.get("toolbar") or {}
    tb = tk.Frame(gui.root, bg=gui._bg)
    apply_pack(tb, tb_spec.get("layout"))
    for item in tb_spec.get("buttons", []) or []:
        gui._toolbar_btn_spec(
            tb,
            str(item["text"]),
            str(item["key"]),
            bool(item.get("typewriter_on_result")),
            item.get("layout"),
        )


def _build_main_paned(gui: TestBenchGUI, ch: dict[str, Any], comp0: dict[str, Any]) -> None:
    mp = ch.get("main_paned") or {}
    orient = tk.HORIZONTAL if str(mp.get("orient", "horizontal")).lower() == "horizontal" else tk.VERTICAL
    hpw = tk.PanedWindow(gui.root, orient=orient, sashrelief=tk.RAISED, bg=gui._bg)
    apply_pack(hpw, mp.get("layout"))

    np = mp.get("nav_pane") or {}
    gui._nav_pane_visible = chrome_visible(np, default=True)
    gui._page_host = tk.Frame(hpw, bg=gui._bg)
    cont = mp.get("content_pane") or {}

    if gui._nav_pane_visible:
        nav_fr = tk.Frame(hpw, bg=gui._bg)
        cap = np.get("caption") or {}
        tk.Label(
            nav_fr,
            text=str((cap.get("props") or {}).get("text", "")),
            bg=gui._bg,
            fg=gui._mem_fg,
            font=gui.font_sec,
        ).pack(**pack_options(cap.get("layout")))
        lb_spec = np.get("listbox") or {}
        lpr = lb_spec.get("props") or {}
        gui._nav_lb = tk.Listbox(
            nav_fr,
            width=int(lpr.get("width", 28)),
            height=int(lpr.get("height", 24)),
            exportselection=bool(lpr.get("exportselection", False)),
            font=gui.font_btn,
            bg="#fafafa",
        )
        for _pid, title in gui._page_tuples:
            gui._nav_lb.insert(tk.END, title)
        apply_pack(gui._nav_lb, lb_spec.get("layout"))
        gui._nav_lb.bind("<<ListboxSelect>>", gui._on_nav)
        hpw.add(nav_fr, minsize=int(np.get("minsize", 170)))
        hpw.add(gui._page_host, minsize=int(cont.get("minsize", 420)))
    else:
        gui._nav_lb = tk.Listbox(
            gui.root,
            width=1,
            height=max(1, len(gui._page_tuples)),
            exportselection=False,
            font=gui.font_btn,
            bg="#fafafa",
        )
        for _pid, title in gui._page_tuples:
            gui._nav_lb.insert(tk.END, title)
        gui._nav_lb.place(x=-2000, y=-2000)
        hpw.add(gui._page_host, minsize=int(cont.get("minsize", 320)))

    gui._page_wrap: dict[str, tk.Frame] = {}
    for page in gui._layout.get("pages", []) or []:
        pid = str(page["id"])
        wrap = tk.Frame(gui._page_host, bg=gui._bg)
        inner = gui._mk_scroll(wrap)
        gui._build_page_from_json(inner, page, comp0)
        gui._page_wrap[pid] = wrap
        wrap.pack_forget()

    if gui._nav_pane_visible:
        gui._nav_lb.bind("<MouseWheel>", gui._on_nav_wheel)

    raw_pid = str(comp0.get("ui_page", "") or "").strip()
    init_pid = raw_pid if raw_pid in gui._page_wrap else ""
    if not init_pid and gui._page_tuples:
        init_pid = str(gui._page_tuples[0][0])
    init_idx = 0
    for i, (pid, _) in enumerate(gui._page_tuples):
        if str(pid) == init_pid:
            init_idx = i
            break
    gui._suppress = True
    try:
        gui._nav_lb.selection_clear(0, tk.END)
        gui._nav_lb.selection_set(init_idx)
        gui._nav_lb.activate(init_idx)
        gui._show_page(init_pid)
    finally:
        gui._suppress = False
