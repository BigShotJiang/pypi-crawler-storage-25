# -*- coding: utf-8 -*-
"""``python -m yxd_soft`` — 默认 ``yxd_soft.harness.TestHarness`` 与包内布局 JSON。"""
from __future__ import annotations

import sys

from .host import run_host_cli


def main() -> None:
    raise SystemExit(run_host_cli())


if __name__ == "__main__":
    main()
