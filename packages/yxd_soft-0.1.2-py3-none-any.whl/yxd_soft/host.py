# -*- coding: utf-8 -*-
"""
宿主入口：``TestbenchHost`` 封装 ``init_layout`` + ``create_app`` + uvicorn + 可选 Tk。

业务方实现与 ``api_server`` 约定一致的对象（``snapshot`` / ``press`` / ``merge_components`` /
``reset_all`` 等），再通过 ``engine=`` 或 ``engine_factory=`` 注入即可；JSON 仅指 ``gui_layout``
与 ``load_calc_settings`` 所用路径。
"""
from __future__ import annotations

import argparse
import sys
import threading
from collections.abc import Callable
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

import uvicorn


@runtime_checkable
class BenchEngine(Protocol):
    """与 ``api_server.create_app`` 匹配的最低约定（可子类化扩展）。"""

    def snapshot(self) -> dict[str, Any]: ...
    def merge_components(self, **kwargs: Any) -> None: ...
    def press(self, key: str) -> None: ...
    def reset_all(self) -> None: ...


class TestbenchHost:
    """
    将「配置 JSON + 业务 engine」与 HTTP/WebSocket/Tk 绑在一起。

    - ``engine``：已构造好的实例（单例式宿主）。
    - ``engine_factory``：每次 ``run()`` 调用时 ``factory()`` 得到新实例；与 ``engine`` 二选一。
    - 若两者皆省略，默认 ``engine_factory = engine.TestHarness``（本仓库演示用）。
    """

    def __init__(
        self,
        *,
        engine: Any | None = None,
        engine_factory: Callable[[], Any] | None = None,
        gui_layout: str | Path | None = None,
        calc_settings_path: str | Path | None = None,
    ) -> None:
        if engine is not None and engine_factory is not None:
            raise ValueError("请只指定 engine 或 engine_factory 之一")
        self._engine = engine
        self._engine_factory = engine_factory
        self._gui_layout = gui_layout
        self._calc_settings_path = calc_settings_path

    def _resolve_engine(self) -> Any:
        if self._engine is not None:
            return self._engine
        if self._engine_factory is not None:
            return self._engine_factory()
        from yxd_soft.harness import TestHarness

        return TestHarness()

    def run(
        self,
        *,
        with_gui: bool = True,
        with_api: bool = True,
        bind_host: str | None = None,
        bind_port: int | None = None,
        gui_layout_path: str | Path | None = None,
    ) -> None:
        """
        阻塞运行：可选后台 uvicorn + 前台 Tk（与原先 ``main.main`` 行为一致）。

        ``gui_layout_path`` 若给出，则覆盖构造时的 ``gui_layout``（便于命令行传入）。
        """
        from .api_server import create_app
        from .calc_settings import load_calc_settings
        from .gui import run_gui
        from .gui_config import init_layout

        layout = gui_layout_path if gui_layout_path is not None else self._gui_layout
        init_layout(layout)

        settings = load_calc_settings(self._calc_settings_path)
        host = settings.host if bind_host is None else bind_host
        port = settings.port if bind_port is None else bind_port

        eng = self._resolve_engine()
        lock = threading.Lock()
        app = create_app(eng, lock)

        server_thread: threading.Thread | None = None
        if with_api:
            config = uvicorn.Config(
                app,
                host=host,
                port=port,
                log_level="info",
                ws_ping_interval=25.0,
                ws_ping_timeout=None,
                timeout_keep_alive=120,
            )
            server = uvicorn.Server(config)
            server_thread = threading.Thread(target=server.run, daemon=True)
            server_thread.start()
            print(f"HTTP: http://{host}:{port}/docs")
            print(f"WebSocket: ws://{host}:{port}/ws")
            print("  消息为 JSON 文本帧，见 yxd_soft.api_server.ws_calc 文档字符串")
            print("  POST /press、/sequence、GET /display/stream (SSE) 等仍可用")
            print("另一终端 WebSocket REPL:")
            print(f"  yxd-soft-input http://{settings.host}:{settings.port}")
            print("  默认布局为包内 data/config/gui_layout.json；精简单页: --gui-layout <gui_layout.minimal.json>")
            print("提示: 关闭测试台窗口不会结束 API；在本终端按 Ctrl+C 可退出进程。")

        ran_gui = False
        if with_gui:
            ran_gui = True
            run_gui(eng, lock, layout_path=layout)

        if server_thread is not None:
            if ran_gui:
                print(
                    "\n测试台窗口已关闭；WebSocket / HTTP 仍在运行。"
                    "需要彻底退出时请在本终端按 Ctrl+C。",
                    flush=True,
                )
            try:
                server_thread.join()
            except KeyboardInterrupt:
                pass


def run_host_cli(argv: list[str] | None = None) -> int:
    """命令行入口（与原先 ``main.py`` 参数兼容）。"""
    argv = argv if argv is not None else sys.argv[1:]
    p = argparse.ArgumentParser(description="HTTP + WebSocket 测试台（Tk 可选）— yxd_soft")
    p.add_argument(
        "--config",
        default=None,
        help="Path to calc_config.json 或含 server 的 gui_layout.json（host + port）",
    )
    p.add_argument("--host", default=None, help="API bind address (default: host in config)")
    p.add_argument("--port", type=int, default=None, help="API port (default: port in config)")
    p.add_argument(
        "--gui-layout",
        default=None,
        help="Path to gui_layout.json (default: packaged yxd_soft data/config/gui_layout.json)",
    )
    p.add_argument("--no-gui", action="store_true", help="API only (no Tk window)")
    p.add_argument("--no-api", action="store_true", help="GUI only (no HTTP server)")
    args = p.parse_args(argv)

    from .calc_settings import load_calc_settings

    settings = load_calc_settings(args.config)
    bind_host = settings.host if args.host is None else args.host
    bind_port = settings.port if args.port is None else args.port

    host = TestbenchHost(
        gui_layout=args.gui_layout,
        calc_settings_path=args.config,
    )
    host.run(
        with_gui=not args.no_gui,
        with_api=not args.no_api,
        bind_host=bind_host,
        bind_port=bind_port,
        gui_layout_path=args.gui_layout,
    )
    return 0
