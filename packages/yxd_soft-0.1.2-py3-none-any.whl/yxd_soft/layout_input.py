# -*- coding: utf-8 -*-
"""从 ``gui_layout.json`` 的 ``input`` 节读取终端/引擎约定（各子应用共用）。"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def input_rules_from_dict(layout: dict[str, Any]) -> dict[str, Any]:
    block = layout.get("input")
    return dict(block) if isinstance(block, dict) else {}


def load_input_rules_from_path(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.is_file():
        return {}
    data = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return {}
    return input_rules_from_dict(data)


def load_input_rules() -> dict[str, Any]:
    """使用当前已通过 ``init_layout`` 加载的布局。"""
    from .gui_config import get_gui_layout

    return input_rules_from_dict(get_gui_layout())
