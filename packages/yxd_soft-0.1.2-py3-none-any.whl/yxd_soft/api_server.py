"""REST + WebSocket API：将请求 **转发** 至注入的 ``engine``；不在此实现业务状态机或算式逻辑。"""
from __future__ import annotations

import asyncio
import json
import random
import threading
from typing import Any, AsyncIterator

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from .calc_settings import WS_SERVER_IDLE_NOTIFY_SECONDS
from yxd_soft.harness import TestHarness
from .gui_config import merge_components_kwargs_for_patches
from .gui_layout import attach_gui_to_snapshot

# WebSocket 文本帧 JSON 的 ``action`` 白名单（与 ws_calc 分支一致；供 /health 与 unknown 错误体列出）
WS_ACTION_NAMES: tuple[str, ...] = (
    "ping",
    "display",
    "gui",
    "set_by_id",
    "merge_components",
    "engine_invoke",
    "reset",
    "press",
    "sequence",
    "display_stream",
)


def _apply_engine_invoke(engine: TestHarness, msg: dict) -> None:
    """``action: engine_invoke`` 时按 ``method`` 白名单调用 ``TestHarness``（业务状态机）。"""
    method = str(msg.get("method", "")).strip()
    if method == "press":
        key = msg.get("key")
        if not isinstance(key, str) or not key.strip():
            raise ValueError("press requires non-empty string key")
        engine.press(key)
        return
    if method == "merge_components":
        patch = {k: v for k, v in msg.items() if k not in ("action", "method")}
        engine.merge_components(**patch)
        return
    if method == "reset_all":
        engine.reset_all()
        return
    raise ValueError(
        f"unknown engine method: {method!r} (allowed: press, merge_components, reset_all)"
    )


def _api_console_log(message: str) -> None:
    """Print to the terminal where uvicorn / main.py runs (stdout)."""
    print(message, flush=True)


class PressBody(BaseModel):
    key: str = Field(..., description="任意字符串键名；!err 会返回 400")

    model_config = {"json_schema_extra": {"examples": [{"key": "T1"}, {"key": "hello"}]}}


class SequenceBody(BaseModel):
    keys: list[str] = Field(..., description="按顺序模拟多次 press")

    model_config = {"json_schema_extra": {"examples": [{"keys": ["T1", "T2", "hello"]}]}}


def create_app(engine: TestHarness, lock: threading.Lock) -> FastAPI:
    app = FastAPI(title="Test harness API", version="1.0.0")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    idle_seconds = float(WS_SERVER_IDLE_NOTIFY_SECONDS)
    if idle_seconds <= 0:
        idle_seconds = 25.0

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {"status": "ok", "websocket_actions": list(WS_ACTION_NAMES)}

    @app.get("/display")
    def get_display() -> dict:
        with lock:
            return attach_gui_to_snapshot(engine.snapshot())

    @app.get("/gui")
    def get_gui() -> dict:
        """仅返回与 Tk 测试台对齐的界面树。"""
        with lock:
            snap = engine.snapshot()
        return {"gui": attach_gui_to_snapshot(snap)["gui"]}

    @app.post("/press")
    def press(body: PressBody) -> dict:
        with lock:
            try:
                engine.press(body.key)
            except ValueError as e:
                raise HTTPException(status_code=400, detail=str(e)) from e
            snap = attach_gui_to_snapshot(engine.snapshot())
        _api_console_log(f"[测试 API] press key={body.key!r}  →  display={snap['display']!r}  rev={snap['revision']}")
        return snap

    @app.post("/sequence")
    def sequence(body: SequenceBody) -> dict:
        with lock:
            for k in body.keys:
                try:
                    engine.press(k)
                except ValueError as e:
                    raise HTTPException(status_code=400, detail=str(e)) from e
            snap = attach_gui_to_snapshot(engine.snapshot())
        keys_s = " ".join(body.keys)
        _api_console_log(f"[测试 API] sequence [{keys_s}]  →  display={snap['display']!r}  rev={snap['revision']}")
        return snap

    @app.post("/reset")
    def reset() -> dict:
        with lock:
            engine.reset_all()
            snap = attach_gui_to_snapshot(engine.snapshot())
        _api_console_log(f"[测试 API] reset  →  display={snap['display']!r}  rev={snap['revision']}")
        return snap

    @app.get("/display/stream")
    async def display_stream(
        min_ms: int = 40,
        max_ms: int = 130,
    ) -> StreamingResponse:
        """SSE: each event is one character building up to current display (typing simulation)."""

        async def gen() -> AsyncIterator[bytes]:
            with lock:
                text = engine.snapshot()["display"]
            delays = []
            acc = ""
            for i, ch in enumerate(text):
                acc += ch
                d = random.uniform(min_ms, max_ms) / 1000.0
                if i > 0 and text[i - 1] == ch:
                    d *= random.uniform(0.65, 0.95)
                delays.append((acc, d))
            for partial, d in delays:
                payload = json.dumps({"partial": partial, "full": text}, ensure_ascii=False)
                yield f"data: {payload}\n\n".encode("utf-8")
                await asyncio.sleep(d)
            yield b"data: [DONE]\n\n"

        return StreamingResponse(gen(), media_type="text/event-stream")

    @app.websocket("/ws")
    async def ws_calc(websocket: WebSocket) -> None:
        """
        JSON 文本帧协议（与 HTTP 能力对齐）。

        客户端 → 服务端（单条 JSON 字符串）::

            {"action":"ping"}
            {"action":"display"}
            {"action":"press","key":"7"}
            {"action":"sequence","keys":["1","+","2","="]}
            {"action":"reset"}
            {"action":"gui"}
            {"action":"display_stream","min_ms":40,"max_ms":130}
            {"action":"merge_components","paned_sash":200,"menubutton_pick":"项A","ttk_paned_left":80}
            {"action":"set_by_id","patches":[{"id":"w_entry","value":"hi"},{"id":"w_paned","value":200}]}
            {"action":"set_by_id","id":"listbox_page_nav","value":"tk_lmb"}
            {"action":"engine_invoke","method":"press","key":"7"}
            {"action":"engine_invoke","method":"merge_components","ui_page":"intro"}
            {"action":"engine_invoke","method":"reset_all"}

        ``engine_invoke``：由 JSON 字段 ``method`` 指定 ``engine``（``TestHarness``）上的白名单方法；
        其余字段按方法需要传入（与 ``press`` / ``merge_components`` / ``reset`` 等价，便于在 ``io_mapping`` 中统一写一种上行形状）。

        服务端 → 客户端::

            {"ok":true,"type":"pong"}  # ping
            {"ok":true,"type":"heartbeat"}  # 空闲超时服务端主动推送，便于穿透/代理保活
            {"ok":true,"snapshot":{...}}  # display / press / sequence / reset / merge_components / set_by_id / engine_invoke 成功（snapshot 含 gui）
            {"ok":true,"gui":{...}}  # gui 成功
            {"ok":false,"error":"..."}  # 失败
            # display_stream 期间多条:
            {"ok":true,"type":"display_partial","partial":"...","full":"..."}
            {"ok":true,"type":"display_stream_done","full":"..."}
        """
        await websocket.accept()
        peer = getattr(websocket, "client", None)
        peer_s = f"{peer.host}:{peer.port}" if peer else "?"
        _api_console_log(f"[测试 WS] opened  peer={peer_s}")
        try:
            while True:
                try:
                    raw = await asyncio.wait_for(websocket.receive_text(), timeout=idle_seconds)
                except asyncio.TimeoutError:
                    try:
                        await websocket.send_json({"ok": True, "type": "heartbeat"})
                    except Exception:
                        return
                    continue
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    await websocket.send_json({"ok": False, "error": "invalid json"})
                    continue

                if not isinstance(msg, dict):
                    await websocket.send_json({"ok": False, "error": "message must be a JSON object"})
                    continue

                action = msg.get("action")
                if action == "ping":
                    await websocket.send_json({"ok": True, "type": "pong"})
                    continue

                if action == "display":
                    with lock:
                        snap = attach_gui_to_snapshot(engine.snapshot())
                    await websocket.send_json({"ok": True, "snapshot": snap})
                    continue

                if action == "gui":
                    with lock:
                        snap = attach_gui_to_snapshot(engine.snapshot())
                    await websocket.send_json({"ok": True, "gui": snap["gui"]})
                    continue

                if action == "set_by_id":
                    patches = msg.get("patches")
                    if patches is None and isinstance(msg.get("id"), str) and str(msg.get("id")).strip():
                        patches = [{"id": str(msg["id"]).strip(), "value": msg.get("value")}]
                    if not isinstance(patches, list) or not patches:
                        await websocket.send_json(
                            {"ok": False, "error": "set_by_id requires non-empty patches or id+value"}
                        )
                        continue
                    err: str | None = None
                    snap: dict | None = None
                    with lock:
                        try:
                            kw = merge_components_kwargs_for_patches(patches)
                            engine.merge_components(**kw)
                            snap = attach_gui_to_snapshot(engine.snapshot())
                            keys_s = ",".join(sorted(kw.keys()))
                        except ValueError as e:
                            err = str(e)
                    if err is not None:
                        await websocket.send_json({"ok": False, "error": err})
                        continue
                    assert snap is not None
                    _api_console_log(f"[测试 WS] set_by_id  →  keys=[{keys_s}]  rev={snap['revision']}")
                    await websocket.send_json({"ok": True, "snapshot": snap})
                    continue

                if action == "merge_components":
                    patch = {k: v for k, v in msg.items() if k != "action"}
                    with lock:
                        engine.merge_components(**patch)
                        snap = attach_gui_to_snapshot(engine.snapshot())
                    keys_s = ",".join(sorted(patch.keys())) if patch else ""
                    _api_console_log(
                        f"[测试 WS] merge_components keys=[{keys_s}]  →  rev={snap['revision']}"
                    )
                    await websocket.send_json({"ok": True, "snapshot": snap})
                    continue

                if action == "engine_invoke":
                    err: str | None = None
                    snap_e: dict | None = None
                    with lock:
                        try:
                            _apply_engine_invoke(engine, msg)
                            snap_e = attach_gui_to_snapshot(engine.snapshot())
                        except ValueError as e:
                            err = str(e)
                    if err is not None:
                        await websocket.send_json({"ok": False, "error": err})
                        continue
                    assert snap_e is not None
                    _api_console_log(
                        f"[测试 WS] engine_invoke method={msg.get('method')!r}  →  rev={snap_e['revision']}"
                    )
                    await websocket.send_json({"ok": True, "snapshot": snap_e})
                    continue

                if action == "reset":
                    with lock:
                        engine.reset_all()
                        snap = attach_gui_to_snapshot(engine.snapshot())
                    _api_console_log(
                        f"[测试 WS] reset  →  display={snap['display']!r}  rev={snap['revision']}"
                    )
                    await websocket.send_json({"ok": True, "snapshot": snap})
                    continue

                if action == "press":
                    key = msg.get("key")
                    if not isinstance(key, str) or not key.strip():
                        await websocket.send_json({"ok": False, "error": "missing or invalid key"})
                        continue
                    err: str | None = None
                    snap: dict | None = None
                    with lock:
                        try:
                            engine.press(key)
                            snap = attach_gui_to_snapshot(engine.snapshot())
                        except ValueError as e:
                            err = str(e)
                    if err is not None:
                        await websocket.send_json({"ok": False, "error": err})
                        continue
                    assert snap is not None
                    _api_console_log(
                        f"[测试 WS] press key={key!r}  →  display={snap['display']!r}  rev={snap['revision']}"
                    )
                    await websocket.send_json({"ok": True, "snapshot": snap})
                    continue

                if action == "sequence":
                    keys = msg.get("keys")
                    if not isinstance(keys, list) or not keys:
                        await websocket.send_json({"ok": False, "error": "missing or invalid keys"})
                        continue
                    if not all(isinstance(k, str) for k in keys):
                        await websocket.send_json({"ok": False, "error": "keys must be strings"})
                        continue
                    err = None
                    snap: dict | None = None
                    with lock:
                        for k in keys:
                            try:
                                engine.press(k)
                            except ValueError as e:
                                err = str(e)
                                break
                        if err is None:
                            snap = attach_gui_to_snapshot(engine.snapshot())
                    if err is not None:
                        await websocket.send_json({"ok": False, "error": err})
                        continue
                    assert snap is not None
                    keys_s = " ".join(keys)
                    _api_console_log(
                        f"[测试 WS] sequence [{keys_s}]  →  display={snap['display']!r}  rev={snap['revision']}"
                    )
                    await websocket.send_json({"ok": True, "snapshot": snap})
                    continue

                if action == "display_stream":
                    min_ms = int(msg.get("min_ms", 40))
                    max_ms = int(msg.get("max_ms", 130))
                    with lock:
                        text = engine.snapshot()["display"]
                    for i, _ch in enumerate(text):
                        acc = text[: i + 1]
                        d = random.uniform(min_ms, max_ms) / 1000.0
                        if i > 0 and text[i - 1] == text[i]:
                            d *= random.uniform(0.65, 0.95)
                        await websocket.send_json(
                            {"ok": True, "type": "display_partial", "partial": acc, "full": text}
                        )
                        await asyncio.sleep(d)
                    await websocket.send_json({"ok": True, "type": "display_stream_done", "full": text})
                    continue

                await websocket.send_json(
                    {
                        "ok": False,
                        "error": f"unknown action: {action!r}",
                        "websocket_actions": list(WS_ACTION_NAMES),
                    }
                )
        except WebSocketDisconnect as e:
            code = getattr(e, "code", None)
            reason = getattr(e, "reason", None)
            _api_console_log(f"[测试 WS] closed  peer={peer_s}  code={code!r}  reason={reason!r}")
            return

    return app
