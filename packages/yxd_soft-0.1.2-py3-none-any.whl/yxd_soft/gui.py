"""Tkinter 界面（输出呈现）：由布局 JSON 描述控件；**不**内含业务状态机，状态一律来自 ``engine.snapshot()``。"""
from __future__ import annotations

import threading
import tkinter as tk
from tkinter import font as tkfont
from tkinter import messagebox
from tkinter import ttk

from yxd_soft.harness import TestHarness
from .gui_config import get_gui_layout, gui_pages_tuples, init_layout
from .gui_mount import _pw_sash_get, _pw_sash_set, apply_pack, mount_widget, pack_options
from .gui_shell import build_shell
from .typing_display import TypingPlayer


class TestBenchGUI:
    def __init__(self, engine: TestHarness, lock: threading.Lock) -> None:
        self.engine = engine
        self.lock = lock
        self._layout = get_gui_layout()
        theme = self._layout.get("theme") or {}
        self._bg = str(theme.get("window_bg", "#f0f0f0"))
        self._mem_fg = str(theme.get("memory_btn_fg", "#555555"))
        self._main_fg = str(theme.get("main_display_fg", "#111111"))
        self._expr_fg = str(theme.get("expression_fg", "#666666"))
        self._display_bg = str(theme.get("display_bg", "#ffffff"))
        self._display_border = str(theme.get("display_border", "#dddddd"))

        self.root = tk.Tk()
        win = self._layout.get("window") or {}
        self.root.title(str(win.get("title", "测试台")))
        self.root.configure(bg=self._bg)
        ms = win.get("minsize") or [640, 640]
        if not isinstance(ms, (list, tuple)) or len(ms) < 2:
            ms = [640, 640]
        self.root.minsize(int(ms[0]), int(ms[1]))

        self._suppress = False
        self._gui_is_writing = False
        self._sub_win: tk.Toplevel | None = None
        self._page_tuples = gui_pages_tuples()
        self._current_pid = self._page_tuples[0][0]

        with self.lock:
            snap0 = self.engine.snapshot()
            self._last_rendered_revision = snap0["revision"]
            comp0 = snap0.get("components") or {}

        self._player = TypingPlayer(self._apply_partial_label, self._typing_done)

        base = tkfont.nametofont("TkDefaultFont")
        fam = base.actual()["family"]
        self.font_title = (fam, 12, "bold")
        self.font_expr = (fam, 10)
        self.font_display = (fam, 14, "bold")
        self.font_sec = (fam, 9, "bold")
        self.font_btn = (fam, 10)

        build_shell(self, snap0, comp0)

        self.root.after(120, self._poll_external)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _section_from_json(self, parent: tk.Frame, sec: dict) -> tk.Frame:
        slo = sec.get("section_layout") or {"fill": "x", "padx": 4, "pady": 6}
        outer = tk.Frame(parent, bg=self._bg)
        apply_pack(outer, slo)
        title = str(sec.get("title", ""))
        if title:
            tk.Label(outer, text=title, bg=self._bg, fg=self._mem_fg, font=self.font_sec, anchor="w").pack(fill=tk.X)
        body = tk.Frame(outer, bg=self._bg)
        apply_pack(body, sec.get("body_layout") or {"fill": "x", "pady": (2, 0)})
        return body

    def _build_page_from_json(self, inner: tk.Frame, page: dict, comp: dict) -> None:
        for sec in page.get("sections", []) or []:
            body = self._section_from_json(inner, sec)
            for item in sec.get("widgets", []) or []:
                mount_widget(self, body, item, comp)

    def _toolbar_btn_spec(
        self,
        parent: tk.Frame,
        text: str,
        key: str,
        typewriter: bool,
        layout: dict | None,
    ) -> None:
        bg = "#ffdddd" if key == "!err" else self._bg
        b = tk.Button(
            parent,
            text=text,
            command=lambda k=key, tw=typewriter: self._press(k, typewriter=tw),
            bg=bg,
            fg=self._mem_fg,
            activebackground="#e5e5e5",
            relief=tk.GROOVE,
            font=self.font_btn,
            padx=4,
            pady=2,
        )
        apply_pack(b, layout or {"side": "left", "padx": 2, "pady": 2})

    def _on_nav_wheel(self, e: tk.Event) -> None:
        if not getattr(self, "_nav_pane_visible", True):
            return
        self._nav_lb.yview_scroll(int(-1 * (e.delta / 120)), "units")

    def _mk_scroll(self, parent: tk.Frame) -> tk.Frame:
        canvas = tk.Canvas(parent, highlightthickness=0, bg=self._bg)
        sb = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=self._bg)

        def _ic(_: object = None) -> None:
            canvas.configure(scrollregion=canvas.bbox("all"))

        inner.bind("<Configure>", _ic)
        wid = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _cc(e: tk.Event) -> None:
            canvas.itemconfigure(wid, width=e.width)

        canvas.bind("<Configure>", _cc)

        def _wh(e: tk.Event) -> None:
            canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")

        canvas.bind("<MouseWheel>", _wh)
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        return inner

    def _show_page(self, pid: str) -> None:
        for w in self._page_wrap.values():
            w.pack_forget()
        self._page_wrap[pid].pack(fill=tk.BOTH, expand=True)
        self._current_pid = pid

    def _on_nav(self, _e: tk.Event | None = None) -> None:
        if self._suppress or not getattr(self, "_nav_pane_visible", True):
            return
        sel = self._nav_lb.curselection()
        if not sel:
            return
        i = int(sel[0])
        pid = self._page_tuples[i][0]
        self._show_page(pid)
        with self.lock:
            self.engine.merge_components(ui_page=pid, ui_page_index=i)

    def _build_menubar(self) -> None:
        mbar = tk.Menu(self.root)
        self.root.config(menu=mbar)
        f = tk.Menu(mbar, tearoff=0)
        mbar.add_cascade(label="菜单（根）", menu=f)
        f.add_command(label="演示：写入菜单记录", command=lambda: self._menu_hit("file:demo"))
        h = tk.Menu(mbar, tearoff=0)
        mbar.add_cascade(label="帮助", menu=h)
        h.add_command(label="关于（消息框）", command=self._menu_help_msg)

    def _menu_hit(self, tag: str) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(menu_last=tag)

    def _menu_help_msg(self) -> None:
        messagebox.showinfo("菜单", "来自根窗口菜单栏。", parent=self.root)
        if not self._suppress:
            with self.lock:
                self.engine.merge_components(menu_last="help:msg", messagebox_last="info:Menu")

    def _lf_change(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(label_frame_entry=self.var_lf.get())

    def _on_option(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(optionmenu=self.var_opt.get())

    def _on_paned_release(self, _e: tk.Event | None = None) -> None:
        if self._suppress:
            return
        try:
            pos = _pw_sash_get(self.paned, 0)
        except tk.TclError:
            return
        with self.lock:
            self.engine.merge_components(paned_sash=pos)

    def _mb_pick(self, v: str) -> None:
        if self._suppress:
            return
        self.var_mb.set(f"Menubutton → {v}")
        with self.lock:
            self.engine.merge_components(menubutton_pick=v)

    def _canvas_more(self) -> None:
        if self._suppress:
            return
        with self.lock:
            n = int(self.engine.snapshot()["components"].get("canvas_draws", 0)) + 1
            self.engine.merge_components(canvas_draws=n)
        y = 20 + n * 10
        self.cv.create_line(10, y, 200, min(y + 50, 100), fill="#c42")

    def _msg(self, kind: str) -> None:
        if kind == "info":
            messagebox.showinfo("提示", "信息框（showinfo）演示。", parent=self.root)
            last = "info:btn"
        else:
            messagebox.showwarning("警告", "警告框（showwarning）演示。", parent=self.root)
            last = "warn:btn"
        if not self._suppress:
            with self.lock:
                self.engine.merge_components(messagebox_last=last)

    def _open_toplevel(self) -> None:
        if self._sub_win is not None and self._sub_win.winfo_exists():
            self._sub_win.lift()
            return
        tw = tk.Toplevel(self.root)
        tw.title("顶层窗口")
        tw.configure(bg=self._bg)
        tk.Label(tw, text="子窗口", bg=self._bg, font=self.font_btn).pack(padx=24, pady=20)
        tw.protocol("WM_DELETE_WINDOW", tw.destroy)
        self._sub_win = tw

        def _d(e: tk.Event) -> None:
            if e.widget == tw:
                self._sub_win = None

        tw.bind("<Destroy>", _d)
        if not self._suppress:
            with self.lock:
                c = int(self.engine.snapshot()["components"].get("toplevel_opens", 0)) + 1
                self.engine.merge_components(toplevel_opens=c)

    def _ttk_hit(self) -> None:
        if self._suppress:
            return
        with self.lock:
            n = int(self.engine.snapshot()["components"].get("ttk_hits", 0)) + 1
            self.engine.merge_components(ttk_hits=n)

    def _ttk_entry_change(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(ttk_entry=self.var_ttk_e.get())

    def _ttk_check_cmd(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(ttk_check2=self.var_ttk_c2.get())

    def _ttk_radio_cmd(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(ttk_radio2=self.var_ttk_r2.get())

    def _ttk_scale_cmd(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(ttk_scale2=self.var_ttk_sc2.get())

    def _ttk_spin_cmd(self) -> None:
        if self._suppress:
            return
        try:
            v = int(str(self.var_ttk_sp2.get()))
        except ValueError:
            v = 0
        with self.lock:
            self.engine.merge_components(ttk_spin2=v)

    def _on_ttk_paned_release(self, _e: tk.Event | None = None) -> None:
        if self._suppress:
            return
        try:
            pos = _pw_sash_get(self.ttk_pw, 0)
        except tk.TclError:
            return
        with self.lock:
            self.engine.merge_components(ttk_paned_left=pos)

    def _on_entry_change(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(entry=self.var_entry.get())

    def _flush_text_to_engine(self) -> None:
        if self._suppress:
            return
        t = self.txt.get("1.0", "end-1c")
        with self.lock:
            self.engine.merge_components(text=t)

    def _on_listbox(self, _e: tk.Event | None = None) -> None:
        if self._suppress:
            return
        sel = self.lst.curselection()
        if not sel:
            return
        i = int(sel[0])
        with self.lock:
            self.engine.merge_components(listbox_index=i, listbox_value=self.lst.get(i))

    def _on_checks(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(check_a=self.var_ca.get(), check_b=self.var_cb.get())

    def _on_radio(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(radio=self.var_radio.get())

    def _on_scale_spin(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(scale=self.var_scale.get(), spin=self._spin_int())

    def _on_scale_spin_trace(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(scale=self.var_scale.get(), spin=self._spin_int())

    def _spin_int(self) -> int:
        try:
            return int(str(self.var_spin.get()))
        except ValueError:
            return 0

    def _on_combo(self) -> None:
        if self._suppress:
            return
        with self.lock:
            self.engine.merge_components(combo=self.var_combo.get())

    def _on_tree(self, _e: tk.Event | None = None) -> None:
        if self._suppress:
            return
        sel = self.tree.selection()
        iid = sel[0] if sel else ""
        with self.lock:
            self.engine.merge_components(tree_selection=iid)

    def _on_close(self) -> None:
        self._player.stop()
        self.root.destroy()

    def _apply_partial_label(self, partial: str) -> None:
        self.display_var.set(partial)

    def _set_summary_from_snap(self, snap: dict) -> None:
        self.expression_var.set(str(snap.get("expression_line") or ""))

    def _typing_done(self, _full: str) -> None:
        self._gui_is_writing = False

    def _apply_components_from_snap(self, comp: dict) -> None:
        self._suppress = True
        try:
            pid = str(comp.get("ui_page", self._page_tuples[0][0]))
            idx = int(comp.get("ui_page_index", 0))
            if getattr(self, "_nav_pane_visible", True):
                self._nav_lb.selection_clear(0, tk.END)
                self._nav_lb.selection_set(idx)
                self._nav_lb.activate(idx)
            self._show_page(pid)

            if hasattr(self, "var_entry"):
                self.var_entry.set(str(comp.get("entry", "")))
            if hasattr(self, "txt"):
                self.txt.delete("1.0", tk.END)
                self.txt.insert("1.0", str(comp.get("text", "")))
                self.txt.edit_modified(False)
            if hasattr(self, "lst"):
                i = int(comp.get("listbox_index", 0))
                self.lst.selection_clear(0, tk.END)
                self.lst.selection_set(i)
                self.lst.see(i)
            if hasattr(self, "var_ca"):
                self.var_ca.set(bool(comp.get("check_a", False)))
                self.var_cb.set(bool(comp.get("check_b", True)))
                self.var_radio.set(str(comp.get("radio", "opt1")))
                self.var_scale.set(int(comp.get("scale", 0)))
                self.var_spin.set(int(comp.get("spin", 0)))
            if hasattr(self, "var_lf"):
                self.var_lf.set(str(comp.get("label_frame_entry", "")))
            if hasattr(self, "var_opt"):
                self.var_opt.set(str(comp.get("optionmenu", "红豆")))
            if hasattr(self, "paned"):
                try:
                    _pw_sash_set(self.paned, 0, int(comp.get("paned_sash", 140)))
                except tk.TclError:
                    pass
            if hasattr(self, "var_mb"):
                self.var_mb.set(f"Menubutton → {comp.get('menubutton_pick', '')}")
            if hasattr(self, "var_prog"):
                pv = int(comp.get("progress", 0))
                self.var_prog.set(pv)
                self.prog["value"] = pv
            if hasattr(self, "var_combo"):
                self.var_combo.set(str(comp.get("combo", "选项乙")))
            if hasattr(self, "var_ttk_e"):
                self.var_ttk_e.set(str(comp.get("ttk_entry", "")))
                self.var_ttk_c2.set(bool(comp.get("ttk_check2", True)))
                self.var_ttk_r2.set(str(comp.get("ttk_radio2", "x1")))
                self.var_ttk_sc2.set(int(comp.get("ttk_scale2", 0)))
                self.var_ttk_sp2.set(int(comp.get("ttk_spin2", 0)))
            if hasattr(self, "ttk_pw"):
                try:
                    _pw_sash_set(self.ttk_pw, 0, int(comp.get("ttk_paned_left", 100)))
                except tk.TclError:
                    pass
            if hasattr(self, "tree"):
                ts = str(comp.get("tree_selection", ""))
                for x in self.tree.selection():
                    self.tree.selection_remove(x)
                if ts:
                    try:
                        self.tree.selection_set(ts)
                        self.tree.focus(ts)
                    except tk.TclError:
                        pass
        except tk.TclError:
            pass
        finally:
            self._suppress = False

    def _press(self, key: str, *, typewriter: bool) -> None:
        self._player.stop()
        with self.lock:
            try:
                self.engine.press(key)
            except ValueError:
                return
            snap = self.engine.snapshot()
        self._last_rendered_revision = snap["revision"]
        self._set_summary_from_snap(snap)
        self._apply_components_from_snap(snap.get("components") or {})
        text = snap["display"]
        if typewriter:
            self._gui_is_writing = True
            self._player.play(text)
        else:
            self.display_var.set(text)

    def _poll_external(self) -> None:
        try:
            if not self.root.winfo_exists():
                return
        except tk.TclError:
            return
        with self.lock:
            snap = self.engine.snapshot()
        rev = snap["revision"]
        if rev != self._last_rendered_revision and not self._gui_is_writing:
            self._player.stop()
            self._set_summary_from_snap(snap)
            self.display_var.set(str(snap.get("display") or ""))
            self._apply_components_from_snap(snap.get("components") or {})
            self._last_rendered_revision = rev
        self.root.after(120, self._poll_external)

    def run(self) -> None:
        self.root.mainloop()


def run_gui(engine: TestHarness, lock: threading.Lock, layout_path: str | None = None) -> None:
    init_layout(layout_path)
    TestBenchGUI(engine, lock).run()
