"""由 gui_layout.json 的 widget 描述挂载控件到 Tk；逻辑从原 gui._page_* 迁入。"""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .gui import TestBenchGUI


def _pw_sash_set(w: tk.Widget, index: int, pos: int) -> None:
    try:
        w.tk.call(w._w, "sashpos", index, pos)
    except tk.TclError:
        pass


def _pw_sash_get(w: tk.Widget, index: int) -> int:
    try:
        return int(float(w.tk.call(w._w, "sashpos", index)))
    except (tk.TclError, ValueError):
        return 0


def apply_pack(widget: tk.Widget, layout: dict[str, Any] | None) -> None:
    opts = pack_options(layout)
    if opts:
        widget.pack(**opts)


def pack_options(layout: dict[str, Any] | None) -> dict[str, Any]:
    if not layout:
        return {}
    kw: dict[str, Any] = {}
    if "anchor" in layout:
        kw["anchor"] = layout["anchor"]
    if "side" in layout:
        s = str(layout["side"]).lower()
        kw["side"] = {"left": tk.LEFT, "right": tk.RIGHT, "top": tk.TOP, "bottom": tk.BOTTOM}.get(s, tk.TOP)
    if "fill" in layout:
        f = str(layout["fill"]).lower()
        kw["fill"] = {"none": tk.NONE, "x": tk.X, "y": tk.Y, "both": tk.BOTH}.get(f, tk.NONE)
    if "expand" in layout:
        kw["expand"] = bool(layout["expand"])
    for key in ("padx", "pady", "ipadx", "ipady"):
        if key in layout:
            v = layout[key]
            kw[key] = tuple(v) if isinstance(v, list) else v
    return kw


def mount_widget(gui: TestBenchGUI, parent: tk.Frame, item: dict[str, Any], comp: dict[str, Any]) -> None:
    """根据 JSON 单条 widget 描述创建控件。"""
    wtype = str(item.get("widget", ""))
    pr = item.get("props") or {}
    layout = item.get("layout")
    ck = str(item.get("component_key") or "")
    action = str(item.get("action") or "")
    BG = gui._bg
    MAIN_FG = gui._main_fg
    font_btn = gui.font_btn

    if wtype == "intro.readonly_text":
        tx = tk.Text(parent, height=int(pr.get("height", 12)), width=int(pr.get("width", 72)), font=font_btn, wrap="word", bg=BG, relief=tk.FLAT)
        apply_pack(tx, layout)
        tx.insert("1.0", str(pr.get("text", "")))
        tx.configure(state=tk.DISABLED)
        return

    if wtype == "layout.frame":
        row_bg = str(pr.get("bg", BG))
        fr = tk.Frame(parent, bg=row_bg)
        apply_pack(fr, layout)
        for ch in item.get("children", []) or []:
            mount_widget(gui, fr, ch, comp)
        return

    if wtype == "tk.Label":
        lb = tk.Label(parent, text=str(pr.get("text", "")), bg=BG, fg=MAIN_FG, font=font_btn)
        apply_pack(lb, layout)
        return

    if wtype == "tk.Message":
        m = tk.Message(
            parent,
            text=str(pr.get("text", "")),
            bg=BG,
            fg=MAIN_FG,
            width=int(pr.get("width", 480)),
            font=font_btn,
        )
        apply_pack(m, layout)
        return

    if wtype == "tk.Button":
        key_bind = str(item.get("key") or "").strip()
        if action == "msg_info":
            cmd = lambda: gui._msg("info")
        elif action == "msg_warn":
            cmd = lambda: gui._msg("warn")
        elif action == "open_toplevel":
            cmd = gui._open_toplevel
        elif key_bind:
            tw = bool(item.get("typewriter_on_result", False))
            theme = gui._layout.get("theme") or {}
            variant = str(pr.get("variant") or "")
            if variant == "equals":
                bg = str(pr.get("bg") or theme.get("equals_bg", "#0078d4"))
                fg = str(pr.get("fg") or theme.get("equals_fg", "#ffffff"))
            else:
                bg = str(pr.get("bg") or theme.get("keypad_btn_bg", "#ffffff"))
                fg = str(pr.get("fg") or theme.get("keypad_btn_fg", "#1a1a1a"))
            cmd = lambda k=key_bind, tw=tw: gui._press(k, typewriter=tw)
            b = tk.Button(
                parent,
                text=str(pr.get("text", key_bind)),
                command=cmd,
                font=font_btn,
                bg=bg,
                fg=fg,
                activebackground="#c4c4c4" if variant != "equals" else "#106ebe",
                activeforeground=fg,
                relief=tk.FLAT,
                bd=0,
                highlightthickness=0,
            )
            apply_pack(b, layout)
            return
        else:
            cmd = lambda: None
        b = tk.Button(parent, text=str(pr.get("text", "")), command=cmd, font=font_btn)
        apply_pack(b, layout)
        return

    if wtype == "tk.Entry" and ck == "entry":
        gui.var_entry = tk.StringVar(value=str(comp.get("entry", "")))
        e = tk.Entry(parent, textvariable=gui.var_entry, width=int(pr.get("width", 50)), font=font_btn)
        apply_pack(e, layout)
        gui.var_entry.trace_add("write", lambda *_: gui._on_entry_change())
        return

    if wtype == "compound.text_scrollbars":
        b = parent
        fr = tk.Frame(b, bg=BG)
        apply_pack(fr, layout)
        gui.txt = tk.Text(
            fr,
            height=int(pr.get("height", 8)),
            width=int(pr.get("width", 60)),
            font=font_btn,
            wrap={"none": tk.NONE, "char": tk.CHAR, "word": tk.WORD}.get(str(pr.get("wrap", "none")).lower(), tk.NONE),
        )
        sy = tk.Scrollbar(fr, orient=tk.VERTICAL, command=gui.txt.yview)
        sx = tk.Scrollbar(fr, orient=tk.HORIZONTAL, command=gui.txt.xview)
        gui.txt.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        gui.txt.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        fr.rowconfigure(0, weight=1)
        fr.columnconfigure(0, weight=1)
        gui.txt.insert("1.0", str(comp.get("text", "")))
        gui.txt.bind("<FocusOut>", lambda _e: gui._flush_text_to_engine())
        flush_label = str(pr.get("flush_button_text", "Text → 引擎"))
        if bool(pr.get("show_flush_button", True)):
            tk.Button(b, text=flush_label, command=gui._flush_text_to_engine, font=font_btn).pack(anchor="w", pady=4)
        if bool(pr.get("flush_on_return", False)):

            def _ret(_e: tk.Event) -> str | None:
                gui._flush_text_to_engine()
                return "break"

            gui.txt.bind("<Return>", _ret)
        return

    if wtype == "compound.listbox_scroll":
        fr = tk.Frame(parent, bg=BG)
        apply_pack(fr, layout)
        sb = tk.Scrollbar(fr)
        gui.lst = tk.Listbox(
            fr,
            height=int(pr.get("height", 8)),
            font=font_btn,
            yscrollcommand=sb.set,
            exportselection=bool(pr.get("exportselection", False)),
        )
        sb.config(command=gui.lst.yview)
        for it in pr.get("items") or []:
            gui.lst.insert(tk.END, it)
        gui.lst.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        i = int(comp.get("listbox_index", 0))
        gui.lst.selection_set(i)
        gui.lst.see(i)
        gui.lst.bind("<<ListboxSelect>>", gui._on_listbox)
        return

    if wtype == "compound.check_ab":
        row = tk.Frame(parent, bg=BG)
        apply_pack(row, layout)
        labels = pr.get("labels") or ["A", "B"]
        gui.var_ca = tk.BooleanVar(value=bool(comp.get("check_a", False)))
        gui.var_cb = tk.BooleanVar(value=bool(comp.get("check_b", True)))
        tk.Checkbutton(row, text=str(labels[0]), variable=gui.var_ca, command=gui._on_checks, bg=BG, font=font_btn).pack(
            side=tk.LEFT, padx=8
        )
        tk.Checkbutton(row, text=str(labels[1]) if len(labels) > 1 else "B", variable=gui.var_cb, command=gui._on_checks, bg=BG, font=font_btn).pack(
            side=tk.LEFT
        )
        return

    if wtype == "compound.radio_row":
        rfr = tk.Frame(parent, bg=BG)
        apply_pack(rfr, layout)
        gui.var_radio = tk.StringVar(value=str(comp.get("radio", "opt1")))
        for opt in pr.get("options") or []:
            val, text = str(opt.get("value")), str(opt.get("text"))
            tk.Radiobutton(rfr, text=text, variable=gui.var_radio, value=val, command=gui._on_radio, bg=BG, font=font_btn).pack(
                side=tk.LEFT, padx=6
            )
        return

    if wtype == "compound.scale_spin_row":
        row2 = tk.Frame(parent, bg=BG)
        apply_pack(row2, layout)
        gui.var_scale = tk.IntVar(value=int(comp.get("scale", 42)))
        tk.Scale(
            row2,
            from_=float(pr.get("scale_from", 0)),
            to=float(pr.get("scale_to", 100)),
            orient=tk.HORIZONTAL,
            variable=gui.var_scale,
            command=lambda _v: gui._on_scale_spin(),
            bg=BG,
            length=int(pr.get("scale_length", 220)),
        ).pack(side=tk.LEFT, padx=(0, 12))
        gui.var_spin = tk.IntVar(value=int(comp.get("spin", 7)))
        tk.Spinbox(
            row2,
            from_=int(pr.get("spin_from", 0)),
            to=int(pr.get("spin_to", 20)),
            textvariable=gui.var_spin,
            width=6,
            font=font_btn,
            command=gui._on_scale_spin,
        ).pack(side=tk.LEFT)
        gui.var_spin.trace_add("write", lambda *_: gui._on_scale_spin_trace())
        return

    if wtype == "compound.colored_inner_frame":
        ff = tk.Frame(parent, bg=str(pr.get("frame_bg", "#dde8f0")), height=int(pr.get("height", 40)))
        apply_pack(ff, layout)
        tk.Label(ff, text=str(pr.get("inner_text", "")), bg=str(pr.get("frame_bg", "#dde8f0"))).pack(pady=6)
        return

    if wtype == "compound.label_frame_entry":
        lf = tk.LabelFrame(parent, text=str(pr.get("frame_text", "LabelFrame")), bg=BG, padx=8, pady=6, font=font_btn)
        apply_pack(lf, layout)
        gui.var_lf = tk.StringVar(value=str(comp.get("label_frame_entry", "")))
        tk.Entry(lf, textvariable=gui.var_lf, width=int(pr.get("width", 44)), font=font_btn).pack(fill=tk.X)
        gui.var_lf.trace_add("write", lambda *_: gui._lf_change())
        return

    if wtype == "compound.optionmenu":
        vals = tuple(pr.get("values") or ())
        if not vals:
            return
        gui.var_opt = tk.StringVar(value=str(comp.get("optionmenu", vals[0])))
        om = tk.OptionMenu(parent, gui.var_opt, *vals)
        om.config(font=font_btn)
        gui.var_opt.trace_add("write", lambda *_: gui._on_option())
        apply_pack(om, layout)
        return

    if wtype == "compound.paned_horizontal":
        gui.paned = tk.PanedWindow(parent, orient=tk.HORIZONTAL, sashrelief=tk.RAISED, bg=BG)
        apply_pack(gui.paned, layout)
        pl = tk.Frame(gui.paned, bg=str(pr.get("left_bg", "#f4e8dc")))
        prf = tk.Frame(gui.paned, bg=str(pr.get("right_bg", "#dce8f4")))
        tk.Label(pl, text=str(pr.get("left_text", "左")), bg=str(pr.get("left_bg", "#f4e8dc"))).pack(expand=True)
        tk.Label(prf, text=str(pr.get("right_text", "右")), bg=str(pr.get("right_bg", "#dce8f4"))).pack(expand=True)
        gui.paned.add(pl, minsize=50)
        gui.paned.add(prf, minsize=50)
        try:
            _pw_sash_set(gui.paned, 0, int(comp.get("paned_sash", 140)))
        except tk.TclError:
            pass
        gui.paned.bind("<ButtonRelease-1>", gui._on_paned_release)
        return

    if wtype == "compound.menubutton_menu":
        gui.var_mb = tk.StringVar(value=f"Menubutton → {comp.get('menubutton_pick', '')}")
        mb = tk.Menubutton(
            parent,
            textvariable=gui.var_mb,
            relief=tk.RAISED,
            bg=BG,
            font=font_btn,
            direction=getattr(tk, "BELOW", "below"),
        )
        apply_pack(mb, layout)
        mm = tk.Menu(mb, tearoff=0)
        mb.config(menu=mm)
        for it in pr.get("items") or []:
            lab, val = str(it.get("label")), str(it.get("value"))
            mm.add_command(label=lab, command=lambda v=val: gui._mb_pick(v))
        return

    if wtype == "compound.canvas_scroll_draw":
        cv_fr = tk.Frame(parent, bg=BG)
        apply_pack(cv_fr, layout)
        cv_sb = tk.Scrollbar(cv_fr, orient=tk.VERTICAL)
        gui.cv = tk.Canvas(
            cv_fr,
            width=int(pr.get("canvas_width", 220)),
            height=int(pr.get("canvas_height", 110)),
            bg="#fff",
            yscrollcommand=cv_sb.set,
            highlightthickness=1,
        )
        cv_sb.config(command=gui.cv.yview)
        gui.cv.pack(side=tk.LEFT)
        cv_sb.pack(side=tk.RIGHT, fill=tk.Y)
        gui.cv.configure(scrollregion=(0, 0, 220, 220))
        gui.cv.create_line(10, 10, 200, 90, fill="#0078d4", width=2)
        tk.Button(parent, text="Canvas 再画线", command=gui._canvas_more, font=font_btn).pack(anchor="w")
        return

    if wtype == "compound.ttk_frame_label_button":
        ff = ttk.Frame(parent, padding=int(pr.get("padding", 8)), relief=tk.GROOVE)
        apply_pack(ff, layout)
        ttk.Label(ff, text="ttk.Label").pack(anchor="w")
        ttk.Button(ff, text="ttk.Button 计数", command=gui._ttk_hit).pack(anchor="w", pady=4)
        return

    if wtype == "ttk.Separator":
        orient = str(pr.get("orient", "horizontal")).lower()
        o = tk.HORIZONTAL if orient == "horizontal" else tk.VERTICAL
        sep = ttk.Separator(parent, orient=o)
        apply_pack(sep, layout)
        return

    if wtype == "compound.ttk_style_button":
        try:
            st = ttk.Style()
            st.configure("Demo.TButton", foreground="navy")
            ttk.Button(parent, text="Demo.TButton", style="Demo.TButton").pack(**pack_options(layout))
        except tk.TclError:
            ttk.Label(parent, text="Style 不可用").pack(**pack_options(layout))
        return

    if wtype == "compound.ttk_sizegrip_row":
        sg_fr = ttk.Frame(parent)
        apply_pack(sg_fr, layout)
        ttk.Label(sg_fr, text="右下角 Sizegrip").pack(side=tk.LEFT)
        ttk.Sizegrip(sg_fr).pack(side=tk.RIGHT)
        return

    if wtype == "compound.ttk_labelframe_entry":
        lf = ttk.LabelFrame(parent, text=str(pr.get("frame_text", "ttk.LabelFrame")), padding=8)
        apply_pack(lf, layout)
        gui.var_ttk_e = tk.StringVar(value=str(comp.get("ttk_entry", "")))
        ttk.Entry(lf, textvariable=gui.var_ttk_e, width=int(pr.get("width", 40))).pack(fill=tk.X, pady=4)
        gui.var_ttk_e.trace_add("write", lambda *_: gui._ttk_entry_change())
        return

    if wtype == "compound.ttk_combobox":
        vals = list(pr.get("values") or [])
        gui.var_combo = tk.StringVar(value=str(comp.get("combo", vals[1] if len(vals) > 1 else (vals[0] if vals else ""))))
        cb = ttk.Combobox(parent, textvariable=gui.var_combo, values=vals, state="readonly", width=int(pr.get("width", 24)))
        apply_pack(cb, layout)
        gui.var_combo.trace_add("write", lambda *_: gui._on_combo())
        return

    if wtype == "ttk.Checkbutton" and ck == "ttk_check2":
        gui.var_ttk_c2 = tk.BooleanVar(value=bool(comp.get("ttk_check2", True)))
        ttk.Checkbutton(parent, text=str(pr.get("text", "ttk.Checkbutton")), variable=gui.var_ttk_c2, command=gui._ttk_check_cmd).pack(
            **pack_options(layout)
        )
        return

    if wtype == "compound.ttk_radio_row":
        rf = tk.Frame(parent, bg=BG)
        apply_pack(rf, layout)
        gui.var_ttk_r2 = tk.StringVar(value=str(comp.get("ttk_radio2", "x1")))
        for opt in pr.get("options") or []:
            val, text = str(opt.get("value")), str(opt.get("text"))
            ttk.Radiobutton(rf, text=text, variable=gui.var_ttk_r2, value=val, command=gui._ttk_radio_cmd).pack(side=tk.LEFT, padx=8)
        return

    if wtype == "ttk.Scale" and ck == "ttk_scale2":
        gui.var_ttk_sc2 = tk.IntVar(value=int(comp.get("ttk_scale2", 40)))
        ttk.Scale(parent, from_=float(pr.get("from_", 0)), to=float(pr.get("to", 100)), variable=gui.var_ttk_sc2, command=lambda _v: gui._ttk_scale_cmd()).pack(
            **pack_options(layout)
        )
        return

    if wtype == "ttk.Spinbox" and ck == "ttk_spin2":
        gui.var_ttk_sp2 = tk.IntVar(value=int(comp.get("ttk_spin2", 3)))
        ttk.Spinbox(
            parent,
            from_=int(pr.get("from_", 0)),
            to=int(pr.get("to", 9)),
            textvariable=gui.var_ttk_sp2,
            width=int(pr.get("width", 8)),
            command=gui._ttk_spin_cmd,
        ).pack(**pack_options(layout))
        gui.var_ttk_sp2.trace_add("write", lambda *_: gui._ttk_spin_cmd())
        return

    if wtype == "compound.ttk_scrollbar_text":
        txf = ttk.Frame(parent)
        apply_pack(txf, layout)
        tsb = ttk.Scrollbar(txf)
        gui.ttk_txt = tk.Text(txf, height=int(pr.get("height", 4)), width=int(pr.get("width", 50)), font=font_btn, yscrollcommand=tsb.set)
        tsb.config(command=gui.ttk_txt.yview)
        gui.ttk_txt.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tsb.pack(side=tk.RIGHT, fill=tk.Y)
        return

    if wtype == "ttk.LabeledScale":
        if hasattr(ttk, "LabeledScale"):
            ttk.LabeledScale(parent, from_=float(pr.get("from_", 0)), to=float(pr.get("to", 10))).pack(**pack_options(layout))
        else:
            ttk.Label(parent, text="ttk.LabeledScale 不可用").pack(**pack_options(layout))
        return

    if wtype == "compound.ttk_paned_pair":
        pw_wrap = tk.Frame(parent, height=int(pr.get("wrap_height", 80)))
        apply_pack(pw_wrap, layout)
        pw_wrap.pack_propagate(False)
        gui.ttk_pw = ttk.Panedwindow(pw_wrap, orient=tk.HORIZONTAL)
        gui.ttk_pw.pack(fill=tk.BOTH, expand=True)
        p1 = ttk.Label(gui.ttk_pw, text=str(pr.get("left_text", "左")), anchor="center", padding=16)
        p2 = ttk.Label(gui.ttk_pw, text=str(pr.get("right_text", "右")), anchor="center", padding=16)
        gui.ttk_pw.add(p1, weight=1)
        gui.ttk_pw.add(p2, weight=1)
        try:
            _pw_sash_set(gui.ttk_pw, 0, int(comp.get("ttk_paned_left", 100)))
        except tk.TclError:
            pass
        gui.ttk_pw.bind("<ButtonRelease-1>", gui._on_ttk_paned_release)
        return

    if wtype == "compound.ttk_notebook_nested":
        nbn = ttk.Notebook(parent)
        apply_pack(nbn, layout)
        t1 = ttk.Frame(nbn, padding=8)
        t2 = ttk.Frame(nbn, padding=8)
        ttk.Label(t1, text="嵌套 Tab A").pack()
        ttk.Label(t2, text="嵌套 Tab B").pack()
        nbn.add(t1, text="子页A")
        nbn.add(t2, text="子页B")
        return

    if wtype == "compound.treeview_std":
        cols = ("col_b",)
        gui.tree = ttk.Treeview(parent, columns=cols, show="tree headings", height=int(pr.get("height", 10)), selectmode="browse")
        apply_pack(gui.tree, layout)
        gui.tree.heading("#0", text="列A")
        gui.tree.column("#0", width=140, stretch=False)
        gui.tree.heading("col_b", text="列B")
        gui.tree.column("col_b", width=100, stretch=False)
        for row in pr.get("rows") or []:
            gui.tree.insert("", tk.END, iid=str(row["iid"]), text=str(row["text"]), values=(str(row.get("col_b", "")),))
        sel = str(comp.get("tree_selection", ""))
        if sel:
            gui.tree.selection_set(sel)
        gui.tree.bind("<<TreeviewSelect>>", gui._on_tree)
        return

    if wtype == "compound.progressbar_scale":
        wrap = tk.Frame(parent, bg=BG)
        apply_pack(wrap, layout)
        gui.prog = ttk.Progressbar(wrap, length=int(pr.get("length", 400)), mode="determinate", maximum=100)
        gui.prog.pack(fill=tk.X, pady=4)
        gui.var_prog = tk.IntVar(value=int(comp.get("progress", 35)))
        gui.prog["value"] = gui.var_prog.get()

        def _ps(v: str) -> None:
            if gui._suppress:
                return
            gui.var_prog.set(int(float(v)))
            gui.prog["value"] = gui.var_prog.get()
            with gui.lock:
                gui.engine.merge_components(progress=gui.var_prog.get())

        tk.Scale(
            wrap,
            from_=0,
            to=100,
            orient=tk.HORIZONTAL,
            label="%",
            command=_ps,
            bg=BG,
            length=int(pr.get("scale_length", 360)),
        ).pack(fill=tk.X, pady=4)
        return

    # 未知类型：占位
    ttk.Label(parent, text=f"[未实现] {wtype}", foreground="red").pack(anchor="w", pady=4)
