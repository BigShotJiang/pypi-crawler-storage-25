"""
在「第二个终端」运行：通过 WebSocket 连到测试台（python main.py）。

**职责边界**：本文件是 **I/O 与协议客户端**——连接、心跳、把终端行映射为 WebSocket JSON
（``press`` / ``sequence`` / ``set_by_id`` 等），**不包含**业务状态机、算式求值或领域规则；
宿主进程里的 ``engine``（如 ``engine.TestHarness`` 或 ``calculator.engine.CalculatorEngine``）
负责全部业务数据处理。

用法:
  python input.py
  python input.py http://127.0.0.1:9527
  python input.py --config calc_config.json
  python input.py --demo-tests              # 跑项目内 config/test_inputs.json 再进 REPL
  python input.py --gui-layout config/gui_layout.json  # 与 main 使用同一路径时本地加载 id 注册表
  python input.py --dump-bindings-json -   # 导出绑定描述 JSON（stdout）；不写则照常连 WS
  python input.py --quiet http://127.0.0.1:9527   # 不打印布局字段说明

JSON 测试文件:
  · 根对象含 ``actions`` 数组；每项为 object，必须有 ``type``。
  · ``type`` 为 ``set_by_id`` 时，使用与界面相同的 ``config/gui_layout.json``（服务端加载路径须一致）里
    控件的 ``id``：可提供 ``patches``: ``[{\"id\":\"w_entry\",\"value\":\"…\"}]``，或单条 ``id`` + ``value``。
    分页 Listbox 的 id（如 ``listbox_page_nav``）可用页下标或页 ``id`` 字符串切换 ``ui_page``。
  · ``type`` 为 ``engine_invoke`` 时需提供 ``method``（``press`` / ``merge_components`` / ``reset_all``），
    其余键按该方法传入（经 WebSocket 白名单调用服务端 ``engine`` / ``TestHarness``）。
  · ``type`` 为 ``merge_components`` 时，同一条 object 里除 ``type``、``_`` 前缀键外的字段会作为
    组件补丁发给服务端（与 ``engine.merge_components`` 白名单对齐，如 ``paned_sash``、
    ``ttk_paned_left``、``menubutton_pick``、``ui_page`` 等）。
  · 给人看的说明写在 ``_说明`` / ``comment`` / ``_comment``（不会发给服务端）。
  · 启动时（默认）会打印：已加载的 gui_layout 路径、set_by_id 各 id 与规定值、merge_components 字段、
    测试 JSON 的 type 列表、WebSocket action；可用 ``--quiet`` 关闭。
  · ``--dump-bindings-json PATH`` 或 ``-``：写出完整机器可读 JSON 后退出（不连 WebSocket）。

环境变量 CALC_API_BASE：可写 http(s):// 或 ws(s):// 地址（会自动补全 /ws）。
默认连接地址优先：命令行 BASE → CALC_API_BASE → calc_config.json 或 config/gui_layout.json 中 ``server``（或旧版 ``api_server``）的 host/port。

后台线程按间隔发 JSON ``{"action":"ping"}`` 做心跳；断线时自动重连，**不在终端输出任何重连/心跳日志**。

依赖: pip install websocket-client
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from yxd_soft.gui_config import bindings_descriptor, format_bindings_help_text, init_layout, merge_components_kwargs_for_patches

from yxd_soft.calc_settings import (
    WS_APP_HEARTBEAT_INTERVAL_SECONDS,
    WS_CLIENT_PING_INTERVAL_SECONDS,
    WS_CLIENT_PING_TIMEOUT_SECONDS,
    WS_RECONNECT_IMMEDIATE_TRIES,
    WS_RECONNECT_INITIAL_DELAY_SECONDS,
    WS_RECONNECT_MAX_ATTEMPTS,
    WS_RECONNECT_MAX_DELAY_SECONDS,
    http_base,
    load_calc_settings,
)

if TYPE_CHECKING:
    from websocket import WebSocket


def to_ws_url(base: str) -> str:
    b = base.strip().rstrip("/")
    if b.startswith("ws://") or b.startswith("wss://"):
        return b if b.endswith("/ws") else f"{b}/ws"
    if b.startswith("http://"):
        return "ws://" + b[len("http://") :] + "/ws"
    if b.startswith("https://"):
        return "wss://" + b[len("https://") :] + "/ws"
    return f"ws://{b}/ws"


def _parse_line(line: str) -> tuple[str, dict] | None:
    s = line.strip()
    if not s or s.startswith("#"):
        return None
    low = s.lower()
    if low in ("quit", "exit", "q"):
        return "quit", {}
    if low == "reset":
        return "reset", {}
    if low in ("display", "d"):
        return "display", {}
    if low == "gui":
        return "gui", {}
    if low == "stream" or low == "display_stream":
        return "display_stream", {}
    if low == "ping":
        return "ping", {}
    m_set = re.match(r"(?i)^set\s+(\S+)\s+(.*)$", s)
    if m_set:
        return "set_by_id", {"patches": [{"id": m_set.group(1), "value": m_set.group(2)}]}
    if "," in s:
        keys = [p.strip() for p in s.split(",") if p.strip()]
        return "sequence", {"keys": keys}
    parts = s.split()
    if len(parts) == 2:
        try:
            from yxd_soft.gui_config import known_element_ids

            if parts[0] in known_element_ids():
                return "set_by_id", {"patches": [{"id": parts[0], "value": parts[1]}]}
        except Exception:
            pass
    if len(parts) > 1:
        return "sequence", {"keys": parts}
    return "press", {"key": s}


from yxd_soft.paths import default_test_inputs_path

_DEFAULT_TEST_JSON = default_test_inputs_path()


def _strip_json_comments(src: str) -> str:
    """去掉 //、# 整行注释与行尾 //（不计字符串内的 //）。"""
    lines_out: list[str] = []
    for line in src.splitlines():
        t = line.lstrip()
        if t.startswith("//") or t.startswith("#"):
            continue
        chars: list[str] = []
        i = 0
        n = len(line)
        in_str = False
        esc = False
        quote = ""
        while i < n:
            c = line[i]
            if not in_str:
                if i + 1 < n and line[i : i + 2] == "//":
                    break
                if c in "\"'":
                    in_str = True
                    quote = c
                    chars.append(c)
                    i += 1
                    continue
                chars.append(c)
                i += 1
                continue
            chars.append(c)
            if esc:
                esc = False
                i += 1
                continue
            if c == "\\":
                esc = True
                i += 1
                continue
            if c == quote:
                in_str = False
                quote = ""
            i += 1
        lines_out.append("".join(chars).rstrip())
    return "\n".join(lines_out)


def _strip_block_comments(src: str) -> str:
    """去掉 /* ... */（非嵌套），不计字符串内。"""
    out: list[str] = []
    i = 0
    n = len(src)
    in_str = False
    esc = False
    quote = ""
    while i < n:
        c = src[i]
        if not in_str:
            if i + 1 < n and src[i : i + 2] == "/*":
                j = src.find("*/", i + 2)
                if j == -1:
                    break
                i = j + 2
                continue
            if c in "\"'":
                in_str = True
                quote = c
                out.append(c)
                i += 1
                continue
            out.append(c)
            i += 1
            continue
        out.append(c)
        if esc:
            esc = False
            i += 1
            continue
        if c == "\\":
            esc = True
            i += 1
            continue
        if c == quote:
            in_str = False
            quote = ""
        i += 1
    return "".join(out)


def load_test_plan(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"找不到测试 JSON: {p}")
    raw = p.read_text(encoding="utf-8")
    raw = _strip_block_comments(_strip_json_comments(raw))
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("测试 JSON 根必须是 object")
    actions = data.get("actions")
    if not isinstance(actions, list):
        raise ValueError("测试 JSON 必须有 actions 数组")
    return data


def _action_human_note(act: dict) -> str:
    return str(act.get("_说明") or act.get("_comment") or act.get("comment") or "").strip()


def _json_action_to_kind_body(act: dict) -> tuple[str, dict] | tuple[str, float]:
    """
    将 JSON 里的一条 action 转成与 _parse_line 一致的 (kind, body)，
    或 ('sleep', 秒数) / ('noop', {}) 跳过。
    """
    t = str(act.get("type", "")).strip().lower()
    if t in ("comment", "noop", "skip"):
        return "noop", {}
    if t == "sleep" or t == "delay_ms":
        ms = act.get("ms", act.get("delay_ms", 0))
        return "sleep", max(0, int(ms)) / 1000.0
    if t == "ping":
        return "ping", {}
    if t == "display":
        return "display", {}
    if t == "gui":
        return "gui", {}
    if t in ("display_stream", "stream"):
        return "display_stream", {}
    if t == "reset":
        return "reset", {}
    if t in ("set_by_id", "setid"):
        patches = act.get("patches")
        if patches is None and isinstance(act.get("id"), str) and str(act.get("id")).strip():
            patches = [{"id": str(act["id"]).strip(), "value": act.get("value")}]
        if not isinstance(patches, list) or not patches:
            raise ValueError("set_by_id 需要 patches 数组，或同时提供 id 与 value")
        return "set_by_id", {"patches": patches}
    if t in ("merge_components", "components"):
        patch = {
            k: v
            for k, v in act.items()
            if k != "type" and isinstance(k, str) and not k.startswith("_")
        }
        if not patch:
            raise ValueError("merge_components 需要至少一个组件字段（如 paned_sash、menubutton_pick）")
        return "merge_components", patch
    if t in ("engine_invoke", "engine"):
        method = str(act.get("method", "")).strip()
        if not method:
            raise ValueError("engine_invoke 需要非空 method（press | merge_components | reset_all）")
        rest = {
            k: v
            for k, v in act.items()
            if k not in ("type", "method") and isinstance(k, str) and not k.startswith("_")
        }
        return "engine_invoke", {"method": method, **rest}
    if t == "press":
        key = act.get("key")
        if not isinstance(key, str) or not key.strip():
            raise ValueError("press 动作需要非空字符串 key")
        return "press", {"key": key.strip()}
    if t == "sequence":
        keys = act.get("keys")
        if not isinstance(keys, list) or not keys:
            raise ValueError("sequence 动作需要非空 keys 数组")
        if not all(isinstance(k, str) for k in keys):
            raise ValueError("sequence.keys 必须全是字符串")
        return "sequence", {"keys": keys}
    raise ValueError(f"未知 type: {act.get('type')!r}")


def _dispatch(ws: _WsConn, kind: str, body: Any, *, prefix: str = "") -> bool:
    """
    执行一条与 REPL 等价的动作。prefix 非空时打印步骤前缀。
    返回 False 表示应结束主循环（断线等）。
    """
    pf = prefix

    if kind == "noop":
        return True

    if kind == "sleep":
        assert isinstance(body, float)
        if pf:
            print(f"{pf}sleep {body:.3f}s")
        time.sleep(body)
        return True

    if kind == "ping":
        try:
            out = ws.send_recv({"action": "ping"})
        except ConnectionError:
            return False
        if pf:
            print(f"{pf}ping → {json.dumps(out, ensure_ascii=False)}")
        else:
            print(json.dumps(out, ensure_ascii=False))
        return True

    if kind == "display":
        try:
            out = ws.send_recv({"action": "display"})
        except ConnectionError:
            return False
        if pf:
            print(f"{pf}display:")
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return True

    if kind == "gui":
        try:
            out = ws.send_recv({"action": "gui"})
        except ConnectionError:
            return False
        if pf:
            print(f"{pf}gui:")
        if not out.get("ok"):
            print(json.dumps(out, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({"ok": True, "gui": out.get("gui")}, ensure_ascii=False, indent=2))
        return True

    if kind == "display_stream":
        if pf:
            print(f"{pf}display_stream …")
        try:
            ws.begin_stream()
            try:
                ws.send_only({"action": "display_stream"})
            except ConnectionError:
                return False
            except Exception:
                try:
                    ws.connect_until_alive()
                except ConnectionError:
                    pass
                return True
            _recv_until_stream_done(ws)
        finally:
            ws.end_stream()
        return True

    assert isinstance(body, dict)
    try:
        if kind == "set_by_id":
            try:
                merge_components_kwargs_for_patches(body["patches"])
            except (ValueError, KeyError, TypeError) as e:
                if pf:
                    print(f"{pf}[本地校验失败] set_by_id: {e}")
                else:
                    print(f"[本地校验失败] set_by_id: {e}")
                return True
            out = ws.send_recv({"action": "set_by_id", "patches": body["patches"]})
        elif kind == "engine_invoke":
            out = ws.send_recv({"action": "engine_invoke", **body})
        elif kind == "merge_components":
            from yxd_soft.harness import COMPONENT_KEYS

            bad = [k for k in body if k not in COMPONENT_KEYS]
            if bad:
                msg = f"[提示] 以下键不在 engine 白名单，将被服务端忽略: {bad}"
                print(f"{pf}{msg}" if pf else msg)
            out = ws.send_recv({"action": "merge_components", **body})
        elif kind == "reset":
            out = ws.send_recv({"action": "reset"})
        elif kind == "press":
            out = ws.send_recv({"action": "press", "key": body["key"]})
        else:
            out = ws.send_recv({"action": "sequence", "keys": body["keys"]})
    except ConnectionError:
        return False

    if not out.get("ok"):
        err = out.get("error", "")
        if (
            isinstance(err, str)
            and "unknown action" in err
            and "websocket_actions" not in out
        ):
            print(
                "（提示）当前 WebSocket 服务端很可能是未重启的旧进程（响应里尚无 websocket_actions 列表）。"
                "请结束占用该端口的进程后在本仓库重新运行: python main.py",
                flush=True,
            )
        print(out)
    else:
        snap = out.get("snapshot") or {}
        if pf:
            print(f"{pf}{kind}")
            ex = (snap.get("expression_line") or "").strip()
            if ex:
                print(f"     算式: {ex}")
            print(f"     display={snap.get('display')!r}  revision={snap.get('revision')}")
            if kind in ("merge_components", "set_by_id", "engine_invoke") and isinstance(body, dict):
                comp = snap.get("components") or {}
                if kind == "merge_components":
                    keys = sorted(body.keys())
                elif kind == "engine_invoke" and str(body.get("method")) == "merge_components":
                    keys = sorted(k for k in body if k not in ("method",))
                else:
                    keys = sorted(merge_components_kwargs_for_patches(body["patches"]).keys())
                for k in keys:
                    if k in comp:
                        print(f"     components[{k!r}]={comp[k]!r}")
        else:
            ex = (snap.get("expression_line") or "").strip()
            if ex:
                print(f"  → 算式: {ex}")
            print(f"  → display: {snap.get('display')}   revision: {snap.get('revision')}")
            if kind in ("merge_components", "set_by_id", "engine_invoke") and isinstance(body, dict):
                comp = snap.get("components") or {}
                if kind == "merge_components":
                    keys = sorted(body.keys())
                elif kind == "engine_invoke" and str(body.get("method")) == "merge_components":
                    keys = sorted(k for k in body if k not in ("method",))
                else:
                    keys = sorted(merge_components_kwargs_for_patches(body["patches"]).keys())
                for k in keys:
                    if k in comp:
                        print(f"  → components[{k!r}]={comp[k]!r}")
    return True


def _run_test_json(ws: _WsConn, path: str | Path) -> bool:
    """执行 JSON 中的 actions。返回 False 表示应退出主程序循环。"""
    plan = load_test_plan(path)
    note_top = plan.get("_文件说明") or plan.get("_file_note")
    if note_top:
        print("【测试文件说明】", note_top)
    actions = plan["actions"]
    print(f"--- 开始跑测试 JSON（共 {len(actions)} 步）: {path}")
    for i, act in enumerate(actions):
        if not isinstance(act, dict):
            raise SystemExit(f"actions[{i}] 必须是 JSON object")
        hn = _action_human_note(act)
        prefix = f"[{i + 1}/{len(actions)}] "
        if hn:
            print(f"{prefix}# {hn}")
        try:
            kind, body = _json_action_to_kind_body(act)
        except ValueError as e:
            raise SystemExit(f"actions[{i}] 无效: {e}") from e
        if not _dispatch(ws, kind, body, prefix=prefix):
            return False
    print("--- 测试 JSON 跑完")
    return True


def _reconnect_delay(attempt: int) -> float:
    """第 1..WS_RECONNECT_IMMEDIATE_TRIES 次为 0（立即），之后指数退避。"""
    if attempt <= WS_RECONNECT_IMMEDIATE_TRIES:
        return 0.0
    n = attempt - WS_RECONNECT_IMMEDIATE_TRIES - 1
    return min(WS_RECONNECT_MAX_DELAY_SECONDS, WS_RECONNECT_INITIAL_DELAY_SECONDS * (2**n))


class _WsConn:
    """WebSocket：RFC ping + 应用层 JSON ping；持锁收发；断线自动静默重连。"""

    def __init__(self, ws_url: str) -> None:
        self.ws_url = ws_url
        self._conn: WebSocket | None = None
        self._lock = threading.RLock()
        self._stream_depth = 0

    def begin_stream(self) -> None:
        with self._lock:
            self._stream_depth += 1

    def end_stream(self) -> None:
        with self._lock:
            self._stream_depth = max(0, self._stream_depth - 1)

    def _streaming_unlocked(self) -> bool:
        return self._stream_depth > 0

    def close(self) -> None:
        with self._lock:
            self._close_unlocked()

    def _close_unlocked(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    def _open_unlocked(self) -> WebSocket:
        from websocket import create_connection

        kwargs: dict = {"timeout": 30}
        if WS_CLIENT_PING_INTERVAL_SECONDS > 0:
            kwargs["ping_interval"] = WS_CLIENT_PING_INTERVAL_SECONDS
        if WS_CLIENT_PING_TIMEOUT_SECONDS > 0:
            kwargs["ping_timeout"] = WS_CLIENT_PING_TIMEOUT_SECONDS
        return create_connection(self.ws_url, **kwargs)

    def _ensure_unlocked(self) -> WebSocket:
        if self._conn is None:
            self._conn = self._open_unlocked()
        return self._conn

    def _ping_pong_unlocked(self) -> None:
        c = self._ensure_unlocked()
        c.send(json.dumps({"action": "ping"}, ensure_ascii=False))
        raw = c.recv()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        msg = json.loads(raw)
        if not msg.get("ok") or msg.get("type") != "pong":
            raise ConnectionError(f"heartbeat 期望 pong，收到: {msg!r}")

    def connect_until_alive(self) -> None:
        """建连并收到 pong；用于启动与心跳失败后的恢复。"""
        attempt = 0
        last_err: BaseException | None = None
        while True:
            attempt += 1
            if WS_RECONNECT_MAX_ATTEMPTS and attempt > WS_RECONNECT_MAX_ATTEMPTS:
                raise ConnectionError(
                    f"无法连接 {self.ws_url}（已尝试 {attempt - 1} 次）。"
                    f"最后错误: {type(last_err).__name__ if last_err else 'unknown'}: {last_err}"
                ) from last_err
            delay = _reconnect_delay(attempt - 1) if attempt > 1 else 0.0
            if delay > 0:
                time.sleep(delay)
            try:
                with self._lock:
                    self._close_unlocked()
                    self._conn = self._open_unlocked()
                    self._ping_pong_unlocked()
                return
            except Exception as e:
                last_err = e

    def send_recv(self, payload: dict) -> dict:
        attempt = 0
        last_err: BaseException | None = None
        while True:
            attempt += 1
            if WS_RECONNECT_MAX_ATTEMPTS and attempt > WS_RECONNECT_MAX_ATTEMPTS:
                raise ConnectionError(
                    f"发送失败（已重试 {attempt - 1} 次）。"
                    f"最后错误: {type(last_err).__name__ if last_err else 'unknown'}: {last_err}"
                ) from last_err
            try:
                with self._lock:
                    c = self._ensure_unlocked()
                    c.send(json.dumps(payload, ensure_ascii=False))
                    raw = c.recv()
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8")
                return json.loads(raw)
            except Exception as e:
                last_err = e
                with self._lock:
                    self._close_unlocked()
                d = _reconnect_delay(attempt)
                if d > 0:
                    time.sleep(d)

    def send_only(self, payload: dict) -> None:
        with self._lock:
            c = self._ensure_unlocked()
            c.send(json.dumps(payload, ensure_ascii=False))

    def recv_json(self) -> dict:
        with self._lock:
            c = self._ensure_unlocked()
            raw = c.recv()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        return json.loads(raw)


def _heartbeat_loop(ws: _WsConn, stop: threading.Event) -> None:
    interval = float(WS_APP_HEARTBEAT_INTERVAL_SECONDS)
    if interval <= 0:
        return
    while not stop.wait(interval):
        with ws._lock:
            if ws._streaming_unlocked():
                continue
        try:
            with ws._lock:
                if ws._streaming_unlocked():
                    continue
                ws._ping_pong_unlocked()
        except Exception:
            try:
                ws.connect_until_alive()
            except ConnectionError:
                pass


def _recv_until_stream_done(ws: _WsConn) -> None:
    """Consume display_stream messages; ignore server JSON heartbeats if any."""
    while True:
        try:
            msg = ws.recv_json()
        except Exception:
            try:
                ws.connect_until_alive()
            except ConnectionError:
                pass
            return
        if not msg.get("ok"):
            print(msg)
            return
        t = msg.get("type")
        if t == "heartbeat":
            continue
        if t == "display_partial":
            print(f"\r  typing: {msg.get('partial', '')}", end="", flush=True)
        elif t == "display_stream_done":
            print()
            print(f"  → full: {msg.get('full')}")
            return
        else:
            print(msg)
            return


def main() -> None:
    ap = argparse.ArgumentParser(description="WebSocket REPL for the test harness")
    ap.add_argument(
        "--config",
        default=None,
        help="Path to calc_config.json 或含 server 的 gui_layout.json（host + port）",
    )
    ap.add_argument(
        "--gui-layout",
        default=None,
        metavar="PATH",
        help="与 main.py --gui-layout 相同：加载 config/gui_layout.json 用于本地解析/校验 set_by_id 的 id",
    )
    ap.add_argument(
        "--dump-bindings-json",
        default=None,
        metavar="PATH",
        help="写出 bindings_descriptor() JSON 到 PATH，或 - 表示 stdout，然后退出（不连接）",
    )
    ap.add_argument(
        "--quiet",
        action="store_true",
        help="不打印布局/字段说明（仍加载 --gui-layout 用于本地校验）",
    )
    ap.add_argument(
        "--test-json",
        default=None,
        metavar="PATH",
        help="连接后先执行该 JSON 里的 actions，再进入交互 ws>",
    )
    ap.add_argument(
        "--demo-tests",
        action="store_true",
        help=f"等同于 --test-json {_DEFAULT_TEST_JSON.name}（文件在项目的 config 目录）",
    )
    ap.add_argument(
        "--test-only",
        action="store_true",
        help="与 --test-json / --demo-tests 合用：跑完 JSON 即退出，不进入 ws> 交互",
    )
    ap.add_argument(
        "base",
        nargs="?",
        default=None,
        help="http(s)://host:port — overrides CALC_API_BASE 与配置中的 host/port",
    )
    args = ap.parse_args()

    init_layout(args.gui_layout)

    if args.dump_bindings_json is not None:
        settings = load_calc_settings(args.config)
        base = (
            args.base.strip()
            if args.base
            else (os.environ.get("CALC_API_BASE") or "").strip() or http_base(settings)
        )
        desc = bindings_descriptor(http_base=base, ws_url=to_ws_url(base))
        out = json.dumps(desc, ensure_ascii=False, indent=2)
        path = args.dump_bindings_json.strip()
        if path == "-":
            sys.stdout.write(out + "\n")
        else:
            Path(path).write_text(out + "\n", encoding="utf-8")
        return

    if args.test_only and not args.test_json and not args.demo_tests:
        ap.error("--test-only 需要同时指定 --test-json 或 --demo-tests")

    test_path: str | None = args.test_json
    if test_path is None and args.demo_tests:
        test_path = str(_DEFAULT_TEST_JSON)

    settings = load_calc_settings(args.config)
    base = (
        args.base.strip()
        if args.base
        else (os.environ.get("CALC_API_BASE") or "").strip() or http_base(settings)
    )
    ws_url = to_ws_url(base)
    ws = _WsConn(ws_url)

    print(f"测试台 WebSocket 客户端 → {ws_url}")
    print(f"calc_config: {settings.host}:{settings.port}", flush=True)
    if not args.quiet:
        print(format_bindings_help_text(http_base=base, ws_url=ws_url))
        print("—" * 48)
    if test_path:
        print(f"将执行测试 JSON: {test_path}")
        if args.test_only:
            print("模式: --test-only（跑完即退出）")
        else:
            print("模式: 跑完 JSON 后进入交互 ws>")
    else:
        print("每行一条指令，回车发送。规则：")
        print("  · 整行无逗号 → 单键 press；一行多个词（空格）→ sequence；逗号分隔 → sequence")
        print("  · 命令: reset | d/display | gui | stream | ping | quit")
        print("  · 按布局 id 写值: 两词「id 值」且 id 在布局中 → 自动按 set_by_id；或显式: set <id> <值>（值可取剩余整行）")
        print("  · 或: python input.py --demo-tests   或   --test-json config/test_inputs.json")
    print()

    try:
        import websocket  # noqa: F401
    except ImportError as e:
        raise SystemExit("请先安装依赖: pip install websocket-client") from e

    try:
        ws.connect_until_alive()
    except ConnectionError as e:
        raise SystemExit(f"无法连接 {ws_url}: {e}\n请先运行: yxd-soft-bench 或 python -m yxd_soft") from e

    stop_hb = threading.Event()
    hb_thread: threading.Thread | None = None
    if WS_APP_HEARTBEAT_INTERVAL_SECONDS > 0:
        hb_thread = threading.Thread(
            target=_heartbeat_loop,
            args=(ws, stop_hb),
            name="ws-heartbeat",
            daemon=True,
        )
        hb_thread.start()

    try:
        if test_path is not None:
            tpath = Path(test_path)
            if not tpath.is_file():
                raise SystemExit(f"找不到测试 JSON: {tpath.resolve()}")
            if not _run_test_json(ws, tpath):
                return
            if args.test_only:
                return

        while True:
            try:
                line = input("ws> ")
            except EOFError:
                print(
                    "\n输入已结束（例如管道只给了一行），客户端将退出，WebSocket 会断开。"
                    "请在本机终端里直接运行 python input.py 以保持交互。",
                    flush=True,
                )
                break
            except KeyboardInterrupt:
                print()
                break

            parsed = _parse_line(line)
            if parsed is None:
                continue
            kind, body = parsed
            if kind == "quit":
                break
            if not _dispatch(ws, kind, body):
                break
    finally:
        stop_hb.set()
        if hb_thread is not None:
            hb_thread.join(timeout=2.0)
        ws.close()


if __name__ == "__main__":
    main()
