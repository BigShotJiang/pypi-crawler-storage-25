"""Load API bind host/port：优先 ``calc_config.json``，否则 ``config/gui_layout.json`` 根下的 ``server``（或与旧版 ``api_server``）。"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

# WebSocket / 重连：代码内固定，与 JSON 无关
WS_SERVER_IDLE_NOTIFY_SECONDS = 25.0
WS_CLIENT_PING_INTERVAL_SECONDS = 20
WS_CLIENT_PING_TIMEOUT_SECONDS = 10
# 应用层心跳（JSON ping），间隔应小于服务端空闲 JSON heartbeat，便于尽早发现断线
WS_APP_HEARTBEAT_INTERVAL_SECONDS = 12
# 断线重连：前若干次零延迟（立即），再指数退避
WS_RECONNECT_IMMEDIATE_TRIES = 8
WS_RECONNECT_INITIAL_DELAY_SECONDS = 0.35
WS_RECONNECT_MAX_DELAY_SECONDS = 8.0
WS_RECONNECT_MAX_ATTEMPTS = 0  # 0 = 单次请求内不限制重试次数


@dataclass
class CalcSettings:
    host: str = "127.0.0.1"
    port: int = 9527


def _config_candidate_paths() -> list[Path]:
    from yxd_soft.paths import default_gui_layout_path

    out: list[Path] = []
    env = os.environ.get("CALC_CONFIG")
    if env:
        out.append(Path(env))
    out.append(Path.cwd() / "calc_config.json")
    out.append(default_gui_layout_path())
    out.append(Path.cwd() / "config" / "gui_layout.json")
    out.append(Path.cwd() / "calc_config.json")
    return out


def _settings_from_file_dict(data: dict) -> CalcSettings | None:
    """若 data 可解析为绑定地址则返回，否则 None（用于跳过无 server 节的 gui_layout）。"""
    if isinstance(data.get("server"), dict):
        s = data["server"]
        return CalcSettings(
            host=str(s.get("host", "127.0.0.1")),
            port=int(s.get("port", 9527)),
        )
    if isinstance(data.get("api_server"), dict):
        a = data["api_server"]
        return CalcSettings(
            host=str(a.get("host", "127.0.0.1")),
            port=int(a.get("port", 9527)),
        )
    if "host" in data or "port" in data or isinstance(data.get("client"), dict):
        host, port = _unified_host_port(data)
        return CalcSettings(host=host, port=port)
    return None


def _unified_host_port(data: dict) -> tuple[str, int]:
    """顶层 host/port；若无则兼容旧版 client 对象。"""
    if "host" in data or "port" in data:
        return str(data.get("host", "127.0.0.1")), int(data.get("port", 9527))
    if isinstance(data.get("client"), dict):
        c = data["client"]
        return str(c.get("host", "127.0.0.1")), int(c.get("port", 9527))
    return "127.0.0.1", 9527


def load_calc_settings(config_path: str | Path | None = None) -> CalcSettings:
    if config_path is not None:
        p = Path(config_path)
        if not p.is_file():
            raise FileNotFoundError(f"calc config not found: {p}")
        paths = [p]
    else:
        paths = _config_candidate_paths()
    for path in paths:
        if not path.is_file():
            continue
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            data = {}
        st = _settings_from_file_dict(data)
        if st is not None:
            return st
    if config_path is not None:
        p = paths[0]
        raise ValueError(f"无法在配置文件中解析 server、api_server 或 host/port: {p}")
    return CalcSettings()


def http_base(settings: CalcSettings) -> str:
    return f"http://{settings.host}:{settings.port}"
