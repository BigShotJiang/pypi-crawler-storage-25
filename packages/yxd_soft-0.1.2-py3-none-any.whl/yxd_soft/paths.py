# -*- coding: utf-8 -*-
"""
仅从 **pip 非 editable 安装** 到 ``site-packages`` 的包内读资源。

- 未 ``pip install`` → 报错  
- ``pip install -e .``（源码在开发目录）→ 报错  
- ``pip install .`` / ``pip install yxd_soft`` → 允许（路径在 site-packages 下）
"""
from __future__ import annotations

import importlib.util
import sysconfig
from functools import lru_cache
from importlib.metadata import PackageNotFoundError, distribution, version
from pathlib import Path

_DISTRIBUTION = "yxd_soft"


def ensure_pip_installed(dist_name: str = _DISTRIBUTION) -> str:
    """确认发行版已安装；拒绝 editable；返回版本号。"""
    try:
        ver = version(dist_name)
    except PackageNotFoundError as e:
        raise ImportError(
            f"未在当前 Python 环境中安装 {dist_name!r}。"
            f"请先执行: pip install {dist_name}"
        ) from e
    _reject_editable(dist_name)
    return ver


def _reject_editable(dist_name: str) -> None:
    try:
        direct = distribution(dist_name).read_text("direct_url.json")
    except (FileNotFoundError, OSError, PackageNotFoundError):
        return
    if direct and '"editable"' in direct:
        raise ImportError(
            f"检测到 {dist_name!r} 为可编辑安装 (pip install -e)，本库仅允许正式安装到 site-packages。\n"
            f"请执行:\n"
            f"  pip uninstall {dist_name} -y\n"
            f"  pip install .\n"
            f"（在项目目录下，且不要使用 -e）"
        )


def _site_packages_roots() -> tuple[Path, ...]:
    roots: list[Path] = []
    for key in ("purelib", "platlib"):
        raw = sysconfig.get_paths().get(key)
        if raw:
            roots.append(Path(raw).resolve())
    return tuple(roots)


def _require_site_packages(path: Path) -> Path:
    """路径必须在 site-packages 内（排除 editable 指向的源码树）。"""
    resolved = path.resolve()
    for root in _site_packages_roots():
        try:
            resolved.relative_to(root)
            return resolved
        except ValueError:
            continue
    roots = "\n  ".join(str(r) for r in _site_packages_roots())
    raise ImportError(
        f"资源路径不在 site-packages 内，不能从源码目录读取:\n  {resolved}\n"
        f"site-packages 根目录:\n  {roots}\n"
        f"请使用正式安装: pip uninstall {_DISTRIBUTION} -y && pip install . （勿用 -e）"
    )


@lru_cache(maxsize=16)
def package_dir(package: str) -> Path:
    """已安装子包在 site-packages 中的顶层目录。"""
    ensure_pip_installed()
    spec = importlib.util.find_spec(package)
    if spec is None or not spec.submodule_search_locations:
        raise ImportError(f"找不到已安装的 Python 包: {package!r}")
    root = Path(spec.submodule_search_locations[0])
    return _require_site_packages(root)


@lru_cache(maxsize=32)
def package_file(package: str, *relative: str) -> Path:
    """子包内资源文件（仅 site-packages）。"""
    p = package_dir(package).joinpath(*relative).resolve()
    _require_site_packages(p)
    if not p.is_file():
        raise FileNotFoundError(p)
    return p


def default_gui_layout_path() -> Path:
    return package_file("yxd_soft", "data", "config", "gui_layout.json")


def default_minimal_gui_layout_path() -> Path:
    return package_file("yxd_soft", "data", "config", "gui_layout.minimal.json")


def default_test_inputs_path() -> Path:
    return package_file("yxd_soft", "data", "config", "test_inputs.json")


def default_io_mapping_path() -> Path:
    return package_file("yxd_soft", "data", "config", "io_mapping.cof")
