"""从 JSON 加载测试台界面布局；供 gui_layout / gui 共用。"""
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from yxd_soft.paths import default_gui_layout_path

DEFAULT_GUI_LAYOUT_PATH = default_gui_layout_path()

_layout: dict[str, Any] | None = None
_layout_path: Path | None = None
_element_registry: dict[str, dict[str, Any]] | None = None


def init_layout(path: str | Path | None = None) -> dict[str, Any]:
    """加载布局（可重复调用切换路径）。path 为 None 时使用项目内默认 JSON。"""
    global _layout, _layout_path, _element_registry
    p = Path(path) if path else DEFAULT_GUI_LAYOUT_PATH
    if not p.is_file():
        raise FileNotFoundError(f"找不到 GUI 布局文件: {p}")
    raw = p.read_text(encoding="utf-8")
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("gui_layout.json 根必须是 object")
    pages = data.get("pages")
    if not isinstance(pages, list) or not pages:
        raise ValueError("gui_layout.json 需要非空 pages 数组")
    for i, pg in enumerate(pages):
        if not isinstance(pg, dict) or not str(pg.get("id", "")).strip():
            raise ValueError(f"pages[{i}] 需要非空 id")
    _layout_path = p
    data["_path"] = str(p.resolve())
    _element_registry = None
    _layout = data
    return _layout


def get_gui_layout() -> dict[str, Any]:
    if _layout is None:
        init_layout(None)
    assert _layout is not None
    return _layout


def layout_source_path() -> Path:
    get_gui_layout()
    assert _layout_path is not None
    return _layout_path


def flatten_page_widgets(page: dict[str, Any]) -> list[dict[str, Any]]:
    """将 page.sections[].widgets 打平，并附上 section_id / section_title。"""
    out: list[dict[str, Any]] = []
    for sec in page.get("sections", []) or []:
        if not isinstance(sec, dict):
            continue
        sid = str(sec.get("id", ""))
        stitle = str(sec.get("title", ""))
        for w in sec.get("widgets", []) or []:
            if not isinstance(w, dict):
                continue
            row = deepcopy(w)
            row["section_id"] = sid
            row["section_title"] = stitle
            out.append(row)
    return out


def gui_pages_tuples() -> list[tuple[str, str]]:
    return [(str(p["id"]), str(p["title"])) for p in get_gui_layout()["pages"]]


def page_by_id(pid: str) -> dict[str, Any] | None:
    for p in get_gui_layout()["pages"]:
        if str(p.get("id")) == pid:
            return p
    return None


def _build_element_registry() -> dict[str, dict[str, Any]]:
    """由共享 gui_layout.json 构建 element_id → 绑定元数据（供 set_by_id）。"""
    L = get_gui_layout()
    reg: dict[str, dict[str, Any]] = {}
    for page in L.get("pages", []) or []:
        for w in flatten_page_widgets(page):
            eid = w.get("id")
            if not eid:
                continue
            eid_s = str(eid)
            ck = w.get("component_key")
            if ck:
                reg[eid_s] = {
                    "kind": "component",
                    "component_key": str(ck),
                    "widget": str(w.get("widget", "")),
                    "props": dict(w.get("props") or {}),
                }
    try:
        lb = L["chrome"]["main_paned"]["nav_pane"]["listbox"]
        lid = lb.get("id")
        if lid:
            reg[str(lid)] = {"kind": "page_nav", "props": dict(lb.get("props") or {})}
    except (KeyError, TypeError):
        pass
    return reg


def get_element_registry() -> dict[str, dict[str, Any]]:
    global _element_registry
    if _element_registry is None:
        _element_registry = _build_element_registry()
    return _element_registry


def known_element_ids() -> tuple[str, ...]:
    return tuple(sorted(get_element_registry().keys()))


def _coerce_engine_value(engine_key: str, raw: Any) -> Any:
    from yxd_soft.harness import _default_components

    template = _default_components().get(engine_key)
    if template is None:
        return raw
    if isinstance(template, bool):
        if isinstance(raw, bool):
            return raw
        sl = str(raw).strip().lower()
        if sl in ("1", "true", "yes", "on"):
            return True
        if sl in ("0", "false", "no", "off", ""):
            return False
        raise ValueError(f"字段 {engine_key} 需要布尔值，无法解析: {raw!r}")
    if isinstance(template, int):
        if isinstance(raw, bool):
            raise ValueError(f"字段 {engine_key} 需要整数，得到布尔")
        if isinstance(raw, int) and not isinstance(raw, bool):
            return int(raw)
        return int(float(str(raw).strip()))
    if isinstance(template, float):
        return float(raw)
    return raw if isinstance(raw, str) else str(raw)


def _merge_kw_for_component_key(component_key: str, raw: Any, props: dict[str, Any]) -> dict[str, Any]:
    from yxd_soft.harness import COMPONENT_KEYS as _COMPONENT_KEYS

    if component_key == "listbox":
        items = tuple(props.get("items") or ())
        if not items:
            raise ValueError("listbox 缺少 props.items，无法解析取值")
        if isinstance(raw, (int, float)) and not isinstance(raw, bool):
            i = int(raw)
            if not (0 <= i < len(items)):
                raise ValueError(f"listbox 索引越界: {i}（共 {len(items)} 项）")
            return {"listbox_index": i, "listbox_value": str(items[i])}
        s = str(raw).strip()
        if s.isdigit():
            i = int(s)
            if 0 <= i < len(items):
                return {"listbox_index": i, "listbox_value": str(items[i])}
        if s in items:
            i = items.index(s)
            return {"listbox_index": i, "listbox_value": s}
        raise ValueError(f"listbox 项不在 items 中: {s!r}")

    if component_key not in _COMPONENT_KEYS:
        raise ValueError(f"component_key 未映射到引擎字段: {component_key!r}")
    return {component_key: _coerce_engine_value(component_key, raw)}


def _merge_kw_for_page_nav(raw: Any) -> dict[str, Any]:
    pages = get_gui_layout().get("pages") or []
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        i = int(raw)
        if not (0 <= i < len(pages)):
            raise ValueError(f"页索引越界: {i}（共 {len(pages)} 页）")
        pid = str(pages[i].get("id", ""))
        return {"ui_page_index": i, "ui_page": pid}
    s = str(raw).strip()
    if s.isdigit():
        i = int(s)
        if 0 <= i < len(pages):
            pid = str(pages[i].get("id", ""))
            return {"ui_page_index": i, "ui_page": pid}
    for i, p in enumerate(pages):
        if str(p.get("id")) == s:
            return {"ui_page_index": i, "ui_page": s}
    raise ValueError(f"未知页 id: {s!r}")


def merge_components_kwargs_for_element_id(element_id: str, raw_value: Any) -> dict[str, Any]:
    """
    将 gui_layout.json 中的控件 id 转为 engine.merge_components(**kwargs)。

    与界面、api_input 共用同一份布局 JSON（由 init_layout / 默认路径加载）。
    """
    reg = get_element_registry()
    eid = str(element_id).strip()
    if eid not in reg:
        raise ValueError(f"未知元素 id: {eid!r}。已知 id: {', '.join(known_element_ids()[:24])}{'…' if len(reg) > 24 else ''}")
    meta = reg[eid]
    kind = meta.get("kind")
    if kind == "page_nav":
        return _merge_kw_for_page_nav(raw_value)
    if kind == "component":
        return _merge_kw_for_component_key(str(meta["component_key"]), raw_value, meta.get("props") or {})
    raise ValueError(f"内部错误: 未知 registry kind {kind!r}")


def merge_components_kwargs_for_patches(patches: list[dict[str, Any]]) -> dict[str, Any]:
    """多条 {id, value} 合并为一次 merge_components 的 kwargs（同名字段后者覆盖）。"""
    out: dict[str, Any] = {}
    for i, p in enumerate(patches):
        if not isinstance(p, dict):
            raise ValueError(f"patches[{i}] 必须是 object")
        eid = p.get("id")
        if not isinstance(eid, str) or not eid.strip():
            raise ValueError(f"patches[{i}] 需要非空字符串 id")
        part = merge_components_kwargs_for_element_id(eid.strip(), p.get("value"))
        out.update(part)
    return out


def _engine_key_template() -> dict[str, Any]:
    from yxd_soft.harness import _default_components

    return _default_components()


def _value_schema_for_registry_entry(eid: str, meta: dict[str, Any]) -> dict[str, Any]:
    """供 api_input / JSON 描述：控件取值形态与可选枚举。"""
    kind = meta.get("kind")
    if kind == "page_nav":
        pages = get_gui_layout().get("pages") or []
        return {
            "type": "page_index_or_page_id",
            "description": "非负整数页下标，或字符串页 id（与 pages[].id 一致）",
            "pages": [
                {"index": i, "id": str(p.get("id", "")), "title": str(p.get("title", ""))}
                for i, p in enumerate(pages)
            ],
        }
    props = dict(meta.get("props") or {})
    ck = str(meta.get("component_key", ""))
    w = str(meta.get("widget", ""))
    tmpl = _engine_key_template()

    if ck == "listbox":
        items = list(props.get("items") or [])
        return {
            "type": "listbox_index_or_item_label",
            "description": "整数下标 0..n-1，或 items 中某一行的字符串",
            "items": items,
            "engine_keys": ["listbox_index", "listbox_value"],
        }

    if ck in ("radio",) or "radio_row" in w:
        opts = props.get("options") or []
        vals = [str(o["value"]) for o in opts if isinstance(o, dict) and "value" in o]
        labs = [str(o.get("text", "")) for o in opts if isinstance(o, dict)]
        return {
            "type": "radio_one_of",
            "one_of": vals,
            "labels": labs,
            "engine_keys": ["radio"],
        }

    if ck == "ttk_radio2" or "ttk_radio_row" in w:
        opts = props.get("options") or []
        vals = [str(o["value"]) for o in opts if isinstance(o, dict) and "value" in o]
        return {"type": "radio_one_of", "one_of": vals, "engine_keys": ["ttk_radio2"]}

    if ck == "combo":
        vals = list(props.get("values") or [])
        return {"type": "combobox_one_of", "one_of": vals, "engine_keys": ["combo"]}

    if ck == "optionmenu":
        vals = list(props.get("values") or [])
        return {"type": "optionmenu_one_of", "one_of": vals, "engine_keys": ["optionmenu"]}

    if ck == "menubutton_pick":
        items = props.get("items") or []
        vals = [str(it.get("value", it.get("label"))) for it in items if isinstance(it, dict)]
        return {"type": "menu_pick_one_of", "one_of": vals, "engine_keys": ["menubutton_pick"]}

    if ck == "tree_selection":
        rows = props.get("rows") or []
        iids = [str(r.get("iid")) for r in rows if isinstance(r, dict) and r.get("iid") is not None]
        return {"type": "tree_row_iid", "one_of": iids, "engine_keys": ["tree_selection"]}

    if ck in tmpl and isinstance(tmpl[ck], bool):
        return {
            "type": "boolean",
            "description": "true/false、1/0、yes/no",
            "engine_keys": [ck],
        }

    if ck in tmpl and isinstance(tmpl[ck], int):
        sch: dict[str, Any] = {"type": "integer", "engine_keys": [ck]}
        for a, b in (
            ("from_", "min"),
            ("to", "max"),
            ("scale_from", "min"),
            ("scale_to", "max"),
            ("spin_from", "min"),
            ("spin_to", "max"),
        ):
            if a in props:
                sch[b] = props[a]
        return sch

    return {"type": "string", "engine_keys": [ck], "description": "写入 engine 对应字符串字段"}


def bindings_descriptor(
    *,
    http_base: str | None = None,
    ws_url: str | None = None,
) -> dict[str, Any]:
    """
    机器可读：当前 gui_layout + engine 白名单，供 api_input 展示或 ``--dump-bindings-json`` 导出。

    下拉 / 单选等约束来自布局 JSON 的 props（items、values、options 等）。
    """
    from yxd_soft.harness import COMPONENT_KEYS as _COMPONENT_KEYS

    L = get_gui_layout()
    reg = get_element_registry()
    elements: list[dict[str, Any]] = []
    for eid in sorted(reg.keys()):
        meta = reg[eid]
        entry: dict[str, Any] = {
            "id": eid,
            "kind": meta.get("kind"),
            "widget": meta.get("widget", ""),
            "component_key": meta.get("component_key", ""),
            "value": _value_schema_for_registry_entry(eid, meta),
        }
        if meta.get("kind") == "component":
            ck = str(meta.get("component_key", ""))
            if ck and ck != "listbox":
                entry["engine_keys_written"] = [ck]
            elif ck == "listbox":
                entry["engine_keys_written"] = ["listbox_index", "listbox_value"]
        elif meta.get("kind") == "page_nav":
            entry["engine_keys_written"] = ["ui_page", "ui_page_index"]
        elements.append(entry)

    test_actions = [
        {"type": "ping", "body": {}},
        {"type": "display", "body": {}},
        {"type": "gui", "body": {}},
        {"type": "reset", "body": {}},
        {"type": "sleep", "body": {"ms": "integer 毫秒"}},
        {"type": "display_stream", "body": {}},
        {"type": "press", "body": {"key": "字符串"}},
        {"type": "sequence", "body": {"keys": ["字符串数组"]}},
        {
            "type": "engine_invoke",
            "body": {
                "method": "press | merge_components | reset_all",
                "说明": "其余键按 method 传入，如 press 需 key；merge_components 写 engine 字段",
            },
        },
        {
            "type": "merge_components",
            "body": {
                "说明": "除 type 与 _ 前缀外任意键为 engine 字段",
                "allowed_keys": sorted(_COMPONENT_KEYS),
            },
        },
        {
            "type": "set_by_id",
            "body": {
                "任选其一": [
                    {"patches": [{"id": "见 set_by_id_elements[].id", "value": "见 value 约束"}]},
                    {"id": "元素 id", "value": "任意"},
                ]
            },
        },
    ]

    out: dict[str, Any] = {
        "layout_source": str(L.get("_path", "")),
        "set_by_id_elements": elements,
        "merge_components_allowed_keys": sorted(_COMPONENT_KEYS),
        "test_json_action_types": test_actions,
        "websocket_actions": [
            "ping",
            "display",
            "gui",
            "reset",
            "press",
            "sequence",
            "merge_components",
            "set_by_id",
            "display_stream",
            "engine_invoke",
        ],
    }
    if http_base:
        out["http_base"] = http_base
    if ws_url:
        out["ws_url"] = ws_url
    return out


def format_bindings_help_text(
    *,
    http_base: str | None = None,
    ws_url: str | None = None,
) -> str:
    """终端打印用：加载布局后的字段说明、枚举值、连接信息。"""
    d = bindings_descriptor(http_base=http_base, ws_url=ws_url)
    lines: list[str] = []
    lines.append("=== 已加载布局（与 Tk 界面 / set_by_id 同源）===")
    lines.append(f"文件: {d.get('layout_source', '')}")
    if ws_url:
        lines.append(f"本次 WebSocket: {ws_url}")
    if http_base:
        lines.append(f"HTTP 基址: {http_base}")
    lines.append("")
    lines.append("--- set_by_id：元素 id 与取值约束 ---")
    for el in d.get("set_by_id_elements", []):
        eid = el.get("id", "")
        vs = el.get("value") or {}
        vtype = vs.get("type", "")
        extra = ""
        if "one_of" in vs and vs["one_of"]:
            shown = vs["one_of"]
            if len(shown) > 12:
                shown = list(shown[:12]) + ["…"]
            extra = f" 规定值: {shown!r}"
        elif "items" in vs:
            extra = f" 项: {vs['items']!r}"
        elif "pages" in vs:
            pg = vs["pages"]
            short = [f"{p['index']}={p['id']}" for p in pg[:8]]
            if len(pg) > 8:
                short.append("…")
            extra = f" 页: {', '.join(short)}"
        elif vtype == "integer":
            mn, mx = vs.get("min"), vs.get("max")
            if mn is not None or mx is not None:
                extra = f" 范围: [{mn}, {mx}]"
            else:
                extra = ""
        elif vtype == "boolean":
            extra = f" {vs.get('description', '')}"
        elif vtype == "string" and vs.get("description"):
            extra = f" {vs['description']}"
        eng = el.get("engine_keys_written") or vs.get("engine_keys") or []
        lines.append(f"  · {eid}  →  engine {eng}  ({vtype}){extra}")
    lines.append("")
    lines.append("--- merge_components：允许字段名（与 engine 一致）---")
    keys = d.get("merge_components_allowed_keys") or []
    chunk = 6
    for i in range(0, len(keys), chunk):
        lines.append("  " + ", ".join(keys[i : i + chunk]))
    lines.append("")
    lines.append("--- 测试 JSON actions.type 一览 ---")
    for a in d.get("test_json_action_types", []):
        lines.append(f"  · {a.get('type')}: {a.get('body')}")
    lines.append("")
    lines.append("--- WebSocket action 字符串 ---")
    lines.append("  " + ", ".join(d.get("websocket_actions", [])))
    lines.append("")
    lines.append("完整机器可读 JSON: 加参数 --dump-bindings-json -（或文件路径）")
    return "\n".join(lines)
