"""最小状态机：按键历史 + 多组件状态，供 HTTP/WebSocket/Tk 联调。

业务状态与变更集中在此（``TestHarness``）。典型链路：终端/客户端输入
→ ``config/io_mapping.cof`` 将行匹配为上行 JSON → ``yxd_soft.api_server`` WebSocket
按 ``action`` / ``engine_invoke`` 调用本类方法 → 返回 ``snapshot``（可带 ``gui``）到页面或 REPL 模板。
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any


def _default_components() -> dict[str, Any]:
    # 键名与 gui_layout / gui.py 中控件 id 对齐；改选项时同步 gui_layout 常量
    return {
        "entry": "",
        "text": "多行\n示例",
        "listbox_index": 0,
        "listbox_value": "alpha",
        "check_a": False,
        "check_b": True,
        "radio": "opt1",
        "scale": 42,
        "spin": 7,
        "combo": "选项乙",
        "progress": 35,
        "tree_selection": "",
        # —— tk 补充 ——
        "label_frame_entry": "LabelFrame 内 Entry",
        "messagebox_last": "",
        "optionmenu": "红豆",
        "menubutton_pick": "",
        "paned_sash": 140,
        "canvas_draws": 0,
        "menu_last": "",
        "toplevel_opens": 0,
        # —— ttk 补充 ——
        "ttk_entry": "ttk.Entry",
        "ttk_hits": 0,
        "ttk_scale2": 40,
        "ttk_spin2": 3,
        "ttk_radio2": "x1",
        "ttk_check2": True,
        "ttk_paned_left": 100,
        "ui_page": "intro",
        "ui_page_index": 0,
    }


COMPONENT_KEYS = frozenset(_default_components().keys())
_COMPONENT_KEYS = COMPONENT_KEYS  # 兼容旧名


@dataclass
class TestHarness:
    revision: int = 0
    _history: list[str] = field(default_factory=list)
    _keep: int = 48
    _components: dict[str, Any] = field(default_factory=_default_components)

    def snapshot(self) -> dict:
        if not self._history:
            display = "（尚未按键）"
        else:
            display = " ".join(self._history[-12:])
        return {
            "display": display,
            "expression_line": f"revision={self.revision}  累计按键={len(self._history)}",
            "memory": 0.0,
            "has_memory": False,
            "revision": self.revision,
            "components": deepcopy(self._components),
        }

    def merge_components(self, **kwargs: Any) -> None:
        dirty = False
        for k, v in kwargs.items():
            if k in _COMPONENT_KEYS:
                self._components[k] = v
                dirty = True
        if dirty:
            self.revision += 1

    def press(self, key: str) -> None:
        key = key.strip()
        if not key:
            raise ValueError("空键名")
        if key == "!err":
            raise ValueError("模拟非法键（用于测 400）")
        if key in ("清空", "CLR", "clear"):
            self._history.clear()
            self._components = _default_components()
            self.revision += 1
            return
        self._history.append(key)
        if len(self._history) > self._keep:
            self._history = self._history[-self._keep :]
        self.revision += 1

    def reset_all(self) -> None:
        self._history.clear()
        self._components = _default_components()
        self.revision += 1
