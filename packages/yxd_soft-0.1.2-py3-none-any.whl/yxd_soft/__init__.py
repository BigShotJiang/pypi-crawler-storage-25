# -*- coding: utf-8 -*-
"""yxd_soft：JSON 布局 + Tk/HTTP/WebSocket 测试台。"""
from __future__ import annotations

from pathlib import Path

_PKG_DIR = Path(__file__).resolve().parent
__version__ = (_PKG_DIR / "VERSION").read_text(encoding="utf-8").strip()

from .host import TestbenchHost, run_host_cli

__all__ = ["__version__", "TestbenchHost", "run_host_cli"]
