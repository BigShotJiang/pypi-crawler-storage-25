"""
与 ``gui.py`` 全控件分页演示一致；供 HTTP/WebSocket 的 ``gui`` 字段使用。

**职责边界**：根据 ``snapshot`` 与布局 JSON **拼装**只读的 GUI 树描述（含各控件当前展示值），
**不**执行业务规则、不修改引擎状态；业务状态仅由 ``engine`` 读写。

布局（分页、chrome、每页 sections/widgets 的 id 与 layout）来自 ``config/gui_layout.json``，
由 ``gui_config.get_gui_layout()`` 加载。
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from .gui_config import flatten_page_widgets, get_gui_layout, gui_pages_tuples


def get_theme() -> dict[str, str]:
    return dict(get_gui_layout().get("theme") or {})


def get_title_bar() -> str:
    return str(get_gui_layout().get("title_bar") or "")


def get_toolbar_buttons() -> list[dict[str, Any]]:
    ch = get_gui_layout().get("chrome") or {}
    tb = ch.get("toolbar") or {}
    return list(tb.get("buttons") or [])


def get_native_widget_catalog() -> list[dict[str, Any]]:
    return list(get_gui_layout().get("native_widget_catalog") or [])


def _enrich_widget_row(row: dict[str, Any], comp: dict[str, Any]) -> dict[str, Any]:
    out = dict(row)
    ck = str(out.get("component_key") or "")
    wid = str(out.get("id") or "")
    wtype = str(out.get("widget") or "")
    if ck == "listbox" or wid == "listbox":
        out["selected_index"] = int(comp.get("listbox_index", 0))
        out["selected_value"] = str(comp.get("listbox_value", ""))
    elif ck == "tree_selection" or "tree" in wid:
        out["selection"] = str(comp.get("tree_selection", ""))
    elif "paned_horizontal" in wtype or ck == "paned_sash":
        out["sash"] = int(comp.get("paned_sash", 140))
    elif "ttk_paned_pair" in wtype or ck == "ttk_paned_left":
        out["sash"] = int(comp.get("ttk_paned_left", 100))
    elif "canvas_scroll_draw" in wtype or ck == "canvas_draws":
        out["draws"] = int(comp.get("canvas_draws", 0))
    elif "menubutton_menu" in wtype or ck == "menubutton_pick":
        out["last"] = str(comp.get("menubutton_pick", ""))
    elif ck and ck in comp:
        out["value"] = comp[ck]
    elif wid and wid in comp:
        out["value"] = comp[wid]
    return out


def _enrich_widgets_for_page(pid: str, comp: dict[str, Any]) -> list[dict[str, Any]]:
    L = get_gui_layout()
    page = next((p for p in L["pages"] if str(p.get("id")) == pid), None)
    if page is None:
        return []
    return [_enrich_widget_row(dict(w), comp) for w in flatten_page_widgets(page)]


def build_gui_tree(engine_snap: dict[str, Any]) -> dict[str, Any]:
    L = get_gui_layout()
    comp = engine_snap.get("components") or {}
    pages_cfg = L.get("pages") or []
    cur = str(comp.get("ui_page") or (pages_cfg[0]["id"] if pages_cfg else "intro"))
    idx = int(comp.get("ui_page_index", 0))
    pages = []
    for i, pg in enumerate(pages_cfg):
        pid = str(pg.get("id", ""))
        pages.append(
            {
                "index": i,
                "id": pid,
                "title": str(pg.get("title", "")),
                "active": pid == cur,
                "widgets": _enrich_widgets_for_page(pid, comp),
            }
        )
    ch = L.get("chrome") or {}
    win = L.get("window") or {}
    return {
        "layout_source": str(L.get("_path", "")),
        "theme": L.get("theme") or {},
        "window": {
            "id": win.get("id", "win_testbench"),
            "title": str(win.get("title", "")),
            "minsize": win.get("minsize", [640, 640]),
        },
        "chrome": ch,
        "native_widget_catalog": get_native_widget_catalog(),
        "summary_strip": {
            "widget": "Frame",
            "expression": {"widget": "Label", "value": str(engine_snap.get("expression_line") or "")},
            "main": {"widget": "Label", "value": str(engine_snap.get("display") or "")},
        },
        "toolbar": ch.get("toolbar") or {"widget": "Frame", "buttons": []},
        "pagination": {
            "widget": "tk.Listbox + tk.Frame",
            "current_page": cur,
            "current_index": idx,
            "page_count": len(pages_cfg),
            "pages": pages,
        },
    }


def attach_gui_to_snapshot(snap: dict[str, Any]) -> dict[str, Any]:
    out = dict(snap)
    out["gui"] = build_gui_tree(snap)
    return out


# 兼容旧 import：元组列表由 JSON pages 派生
def iter_gui_pages() -> list[tuple[str, str]]:
    return gui_pages_tuples()
