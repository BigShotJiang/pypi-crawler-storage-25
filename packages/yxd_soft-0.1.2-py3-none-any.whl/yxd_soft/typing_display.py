"""Human-like character-by-character display updates."""
from __future__ import annotations

import random
import threading
import time
from collections.abc import Callable
from typing import Any


def human_delay_chars(
    text: str,
    *,
    min_ms: int = 35,
    max_ms: int = 120,
) -> list[tuple[str, float]]:
    """Build (char, delay_seconds) pairs with slight randomness per character."""
    out: list[tuple[str, float]] = []
    for i, ch in enumerate(text):
        base = random.uniform(min_ms, max_ms) / 1000.0
        if ch in "0123456789":
            base *= random.uniform(0.85, 1.15)
        if i > 0 and text[i - 1] == ch:
            base *= random.uniform(0.7, 1.0)
        out.append((ch, base))
    return out


class TypingPlayer:
    """Run typing on a background thread; invoke callback for each char and when done."""

    def __init__(
        self,
        on_partial: Callable[[str], None],
        on_complete: Callable[[str], None] | None = None,
    ) -> None:
        self._on_partial = on_partial
        self._on_complete = on_complete
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def play(self, full_text: str, **kwargs: Any) -> None:
        self.stop()
        self._stop = threading.Event()
        pairs = human_delay_chars(full_text, **kwargs)

        def run() -> None:
            buf = ""
            for ch, delay in pairs:
                if self._stop.is_set():
                    return
                buf += ch
                self._on_partial(buf)
                time.sleep(delay)
            if not self._stop.is_set() and self._on_complete:
                self._on_complete(buf)

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()
