"""输入侧：仅发送上行 JSON。"""
from __future__ import annotations

import json

from .link import WsLink
from .loggers import LogHub
from .registry import register_input_backend


class WebSocketInput:
    """仅负责「上行」与输入日志。"""

    def __init__(self, link: WsLink, hub: LogHub) -> None:
        self._link = link
        self._hub = hub

    def send_request(self, payload: dict) -> None:
        line = json.dumps(payload, ensure_ascii=False)
        self._hub.log_input(line)
        self._hub.log_operation(f"send action={payload.get('action')!r}")
        self._link.send_only(payload)


def _factory(link: WsLink, hub: LogHub) -> WebSocketInput:
    return WebSocketInput(link, hub)


register_input_backend("websocket", _factory)
