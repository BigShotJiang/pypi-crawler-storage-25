"""统一入口：装配配置、日志、输入/输出后端与交互循环。"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

from . import websocket_input as _websocket_input  # noqa: F401
from . import websocket_output as _websocket_output  # noqa: F401
from .config import WebSocketCof, http_base, load_websocket_cof, ws_url
from yxd_soft.calc_settings import (
    WS_RECONNECT_INITIAL_DELAY_SECONDS,
    WS_RECONNECT_MAX_ATTEMPTS,
    WS_RECONNECT_MAX_DELAY_SECONDS,
)
from .io_mapping import IoMappingEngine, render_rpc_output, render_stream_done_lines
from .link import WsLink
from .loggers import FileLogSinks, LogHub
from .paths import logs_dir, resolve_root
from .registry import create_input, create_output


class CalcWsApp:
    """热插拔：``io_mapping`` 驱动输入/输出；``registry`` / ``LogHub`` 可扩展。"""

    def __init__(
        self,
        *,
        cof_path: Path | None = None,
        attach_file_logs: bool = True,
    ) -> None:
        self.cfg: WebSocketCof = load_websocket_cof(cof_path)
        self.hub = LogHub()
        if attach_file_logs:
            self._files = FileLogSinks(logs_dir())
            self.hub.attach_sink(self._files)
        else:
            self._files = None
        self._hub = self.hub
        self.link = WsLink(ws_url(self.cfg))
        self.input = create_input(self.cfg.input_backend, self.link, self._hub)
        self.output = create_output(self.cfg.output_backend, self.link, self._hub)
        self.mapper = IoMappingEngine.load(self.cfg.io_mapping, resolve_root())
        self.hub.log_operation(
            f"CalcWsApp init root={resolve_root()} ws={ws_url(self.cfg)} "
            f"in={self.cfg.input_backend!r} out={self.cfg.output_backend!r}"
        )

    def close(self) -> None:
        self.hub.log_operation("CalcWsApp close")
        self.link.close()
        self.hub.close()

    def rpc(self, payload: dict) -> dict:
        """一次请求-响应；带重连。"""
        delay = WS_RECONNECT_INITIAL_DELAY_SECONDS
        max_delay = WS_RECONNECT_MAX_DELAY_SECONDS
        max_attempts = WS_RECONNECT_MAX_ATTEMPTS
        attempt = 0
        last_exc: BaseException | None = None
        while True:
            attempt += 1
            try:
                self.input.send_request(payload)
                return self.output.recv_response()
            except Exception as e:
                last_exc = e
                self.hub.log_operation(f"rpc error {type(e).__name__}: {e} (attempt {attempt})")
                self.link.reset()
                if max_attempts and attempt >= max_attempts:
                    raise ConnectionError(
                        f"WebSocket 多次失败（{attempt} 次），最后错误: {type(e).__name__}: {e}"
                    ) from last_exc
                time.sleep(delay)
                delay = min(delay * 2, max_delay)

    def run_interactive(self) -> int:
        base = http_base(self.cfg)
        print(f"[yxd_soft.ws_client] WS {ws_url(self.cfg)}  |  HTTP {base}", flush=True)
        print(
            f"[yxd_soft.ws_client] 数据根目录: {resolve_root()}（I/O 映射见 io_mapping）",
            flush=True,
        )
        print("[yxd_soft.ws_client] 每行一条指令；quit 见映射表 quit_tokens。", flush=True)
        try:
            self.link.ensure()
        except ImportError:
            print("请先安装: pip install websocket-client", flush=True)
            return 1
        except OSError as e:
            print(f"无法连接: {e}", flush=True)
            return 1

        def _print(*a: object, **kw: object) -> None:
            print(*a, **kw)

        while True:
            try:
                line = input("calc> ")
            except (EOFError, KeyboardInterrupt):
                print(flush=True)
                break
            act = self.mapper.match(line)
            if act is None:
                continue
            if act.kind == "skip":
                continue
            if act.kind == "quit":
                break
            prof = self.mapper.profile(act.output_profile)
            try:
                if act.kind == "rpc":
                    out = self.rpc(act.body)
                    render_rpc_output(prof, out, _print)
                    continue
                if act.kind == "stream":
                    self.input.send_request(act.body)

                    op = prof.get("on_partial") or {}
                    prefix = str(op.get("prefix", ""))
                    suffix = str(op.get("suffix", ""))

                    def _on_partial(p: str) -> None:
                        _print(f"{prefix}{p}{suffix}", end="", flush=True)

                    full = self.output.recv_stream_profile(prof, _on_partial)
                    if op.get("newline_after_done", True):
                        _print(flush=True)
                    render_stream_done_lines(prof, full or "", _print)
                    continue
            except ConnectionError as e:
                print(str(e), flush=True)
                break
        return 0


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    ap = argparse.ArgumentParser(
        description="yxd_soft.ws_client — WebSocket 测试台客户端（io_mapping）"
    )
    ap.add_argument(
        "--cof",
        dest="cof_path",
        default=None,
        help="覆盖默认的 config/gui_layout.json（或 websocket.cof）路径",
    )
    ap.add_argument(
        "--no-file-logs",
        action="store_true",
        help="不向 logs/ 写入文件（仍可用 LogHub.attach_sink 自行挂接）",
    )
    ap.add_argument(
        "--root",
        default=None,
        help="设置数据根目录（等价于环境变量 CALC_WS_ROOT），内含 logs/ 与 config/",
    )
    args = ap.parse_args(argv)
    if args.root:
        os.environ["CALC_WS_ROOT"] = args.root

    cof = Path(args.cof_path) if args.cof_path else None
    app = CalcWsApp(cof_path=cof, attach_file_logs=not args.no_file_logs)
    try:
        return app.run_interactive()
    finally:
        app.close()


def run_cli() -> None:
    raise SystemExit(main())
