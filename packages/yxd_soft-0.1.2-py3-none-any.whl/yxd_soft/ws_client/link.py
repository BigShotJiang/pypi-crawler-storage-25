"""共享 WebSocket：仅 send / recv，重连由 ``CalcWsApp.rpc`` 负责。"""
from __future__ import annotations

import json
from typing import Any

from yxd_soft.calc_settings import (
    WS_CLIENT_PING_INTERVAL_SECONDS,
    WS_CLIENT_PING_TIMEOUT_SECONDS,
)


class WsLink:
    def __init__(self, ws_url: str) -> None:
        self.ws_url = ws_url
        self._conn: Any = None

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    def _open(self) -> Any:
        from websocket import create_connection

        kwargs: dict[str, Any] = {"timeout": 30}
        if WS_CLIENT_PING_INTERVAL_SECONDS > 0:
            kwargs["ping_interval"] = WS_CLIENT_PING_INTERVAL_SECONDS
        if WS_CLIENT_PING_TIMEOUT_SECONDS > 0:
            kwargs["ping_timeout"] = WS_CLIENT_PING_TIMEOUT_SECONDS
        return create_connection(self.ws_url, **kwargs)

    def ensure(self) -> Any:
        if self._conn is None:
            self._conn = self._open()
        return self._conn

    def reset(self) -> Any:
        self.close()
        self._conn = self._open()
        return self._conn

    def send_only(self, payload: dict) -> None:
        c = self.ensure()
        c.send(json.dumps(payload, ensure_ascii=False))

    def recv_json(self) -> dict:
        c = self.ensure()
        raw = c.recv()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        return json.loads(raw)
