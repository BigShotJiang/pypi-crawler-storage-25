"""
解析数据根目录：默认 ``Path.cwd()``（工作目录），可用环境变量 ``CALC_WS_ROOT`` 覆盖。

其下为同级（并列）目录::

    {root}/logs/
    {root}/config/gui_layout.json  （优先；统一布局 + 根下 ``server`` 节）
    {root}/config/websocket.json   （若无统一布局则 UTF-8 JSON）
    {root}/config/websocket.cof    （最后回退；同为 JSON 内容）
"""
from __future__ import annotations

import os
from pathlib import Path


def resolve_root() -> Path:
    raw = os.environ.get("CALC_WS_ROOT", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.cwd().resolve()


def logs_dir() -> Path:
    d = resolve_root() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def config_dir() -> Path:
    d = resolve_root() / "config"
    d.mkdir(parents=True, exist_ok=True)
    return d


def websocket_cof_path() -> Path:
    """返回 WebSocket 配置所在 JSON 路径：优先包内默认布局，再 ``CALC_WS_ROOT/config``。"""
    try:
        from yxd_soft.paths import default_gui_layout_path

        gl = default_gui_layout_path()
        if gl.is_file():
            return gl
    except (ImportError, FileNotFoundError):
        pass
    d = config_dir()
    gl = d / "gui_layout.json"
    if gl.is_file():
        return gl
    j = d / "websocket.json"
    if j.is_file():
        return j
    return d / "websocket.cof"
