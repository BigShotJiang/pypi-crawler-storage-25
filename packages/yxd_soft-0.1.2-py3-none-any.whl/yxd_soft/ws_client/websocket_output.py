"""输出侧：仅接收下行 JSON 并写输出日志。"""
from __future__ import annotations

import json
from typing import Any, Callable

from .link import WsLink
from .loggers import LogHub
from .registry import register_output_backend


class WebSocketOutput:
    """负责「下行」解析与输出日志。"""

    def __init__(self, link: WsLink, hub: LogHub) -> None:
        self._link = link
        self._hub = hub

    def recv_response(self) -> dict[str, Any]:
        raw_obj = self._link.recv_json()
        self._hub.log_output(json.dumps(raw_obj, ensure_ascii=False))
        return raw_obj

    def recv_stream_profile(
        self,
        profile: dict[str, Any],
        on_partial: Callable[[str], None] | None = None,
    ) -> str | None:
        """按 ``io_mapping`` 中 ``output_profiles.<name>``（type=stream）消费下行。"""
        skip = {str(x) for x in (profile.get("skip_message_types") or [])}
        pt = str(profile.get("partial_message_type", "display_partial"))
        pk = str(profile.get("partial_field", "partial"))
        dt = str(profile.get("done_message_type", "display_stream_done"))
        dk = str(profile.get("done_field", "full"))
        while True:
            msg = self.recv_response()
            if not msg.get("ok"):
                self._hub.log_operation(f"stream error: {msg!r}")
                return None
            t = msg.get("type")
            if t in skip:
                continue
            if t == pt:
                if on_partial:
                    try:
                        on_partial(str(msg.get(pk, "")))
                    except Exception:
                        pass
                continue
            if t == dt:
                full = str(msg.get(dk, ""))
                self._hub.log_operation("display_stream done")
                return full
            self._hub.log_operation(f"stream unexpected: {msg!r}")
            return None

    def recv_stream_until_done(self, on_partial: Callable[[str], None] | None = None) -> str | None:
        """兼容旧行为：固定为测试台 ``display_stream`` 协议。"""
        return self.recv_stream_profile(
            {
                "skip_message_types": ["heartbeat"],
                "partial_message_type": "display_partial",
                "partial_field": "partial",
                "done_message_type": "display_stream_done",
                "done_field": "full",
            },
            on_partial,
        )


def _factory(link: WsLink, hub: LogHub) -> WebSocketOutput:
    return WebSocketOutput(link, hub)


register_output_backend("websocket", _factory)
