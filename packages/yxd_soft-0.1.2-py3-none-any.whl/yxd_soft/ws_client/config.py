"""读取 WebSocket 客户端配置：默认自 ``config/gui_layout.json`` 根下 ``server``（或与旧版 ``websocket_client``），或独立 ``websocket.json`` / ``websocket.cof``。"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .paths import websocket_cof_path


@dataclass
class WebSocketCof:
    host: str = "127.0.0.1"
    port: int = 9527
    ws_path: str = "/ws"
    input_backend: str = "websocket"
    output_backend: str = "websocket"
    """相对 ``CALC_WS_ROOT`` 的映射表路径（JSON），或内嵌 dict；缺省为 ``config/io_mapping.cof``。"""
    io_mapping: str | dict[str, Any] | None = None
    extra: dict[str, Any] = field(default_factory=dict)


def load_websocket_cof(path: Path | None = None) -> WebSocketCof:
    p = path or websocket_cof_path()
    if not p.is_file():
        return WebSocketCof()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return WebSocketCof()
    if not isinstance(data, dict):
        return WebSocketCof()
    if isinstance(data.get("server"), dict):
        data = dict(data["server"])
    elif isinstance(data.get("websocket_client"), dict):
        data = dict(data["websocket_client"])
    elif isinstance(data.get("pages"), list):
        # 统一布局文件尚无 server 节时，勿把界面 JSON 误当作连接表
        return WebSocketCof()
    host = str(data.get("host", "127.0.0.1"))
    port = int(data.get("port", 9527))
    ws_path = str(data.get("ws_path", "/ws")).strip() or "/ws"
    if not ws_path.startswith("/"):
        ws_path = "/" + ws_path
    in_b = str(data.get("input_backend", "websocket"))
    out_b = str(data.get("output_backend", "websocket"))
    raw_io = data.get("io_mapping", None)
    io_mapping: str | dict[str, Any] | None
    if isinstance(raw_io, dict):
        io_mapping = raw_io
    elif isinstance(raw_io, str):
        io_mapping = raw_io.strip() or None
    else:
        io_mapping = None
    known = {"host", "port", "ws_path", "input_backend", "output_backend", "io_mapping"}
    extra = {
        k: v
        for k, v in data.items()
        if k not in known and not (isinstance(k, str) and k.startswith("_"))
    }
    return WebSocketCof(
        host=host,
        port=port,
        ws_path=ws_path,
        input_backend=in_b,
        output_backend=out_b,
        io_mapping=io_mapping,
        extra=extra,
    )


def http_base(cfg: WebSocketCof) -> str:
    return f"http://{cfg.host}:{cfg.port}"


def ws_url(cfg: WebSocketCof) -> str:
    return f"ws://{cfg.host}:{cfg.port}{cfg.ws_path}"
