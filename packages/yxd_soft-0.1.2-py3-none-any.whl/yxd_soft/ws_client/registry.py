"""输入 / 输出后端热插拔注册表。"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

InputFactory = Callable[[Any, Any], Any]
OutputFactory = Callable[[Any, Any], Any]

_INPUT_REGISTRY: dict[str, InputFactory] = {}
_OUTPUT_REGISTRY: dict[str, OutputFactory] = {}


def register_input_backend(name: str, factory: InputFactory) -> None:
    _INPUT_REGISTRY[name] = factory


def register_output_backend(name: str, factory: OutputFactory) -> None:
    _OUTPUT_REGISTRY[name] = factory


def create_input(name: str, link: Any, hub: Any) -> Any:
    fac = _INPUT_REGISTRY.get(name)
    if fac is None:
        raise KeyError(f"unknown input_backend: {name!r}")
    return fac(link, hub)


def create_output(name: str, link: Any, hub: Any) -> Any:
    fac = _OUTPUT_REGISTRY.get(name)
    if fac is None:
        raise KeyError(f"unknown output_backend: {name!r}")
    return fac(link, hub)
