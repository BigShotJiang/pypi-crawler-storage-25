"""根据 ``io_mapping`` 配置表匹配行、构造上行 JSON、按 profile 渲染下行。"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal

def _expand_line_vars(template: str, line: str) -> str:
    """仅支持 ``${line}``（原始行）、``${line_stripped}``。"""

    def rep(m: re.Match[str]) -> str:
        key = m.group(1).strip()
        if key == "line":
            return line
        if key in ("line_stripped", "stripped"):
            return line.strip()
        return m.group(0)

    return re.sub(r"\$\{([^}]+)\}", rep, template)


def _get_path(obj: Any, path: str) -> Any:
    cur: Any = obj
    for part in path.split("."):
        if cur is None:
            return None
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            cur = getattr(cur, part, None)
    return cur


def _expand_response_vars(template: str, resp: dict[str, Any], extra: dict[str, Any] | None = None) -> str:
    ctx: dict[str, Any] = dict(resp)
    if extra:
        ctx.update(extra)

    def rep(m: re.Match[str]) -> str:
        key = m.group(1).strip()
        if key in ctx and not isinstance(ctx[key], (dict, list)):
            return str(ctx[key])
        v = _get_path(ctx, key)
        if v is None:
            return ""
        if isinstance(v, (dict, list)):
            return json.dumps(v, ensure_ascii=False)
        return str(v)

    return re.sub(r"\$\{([^}]+)\}", rep, template)


def _resolver_literal(spec: dict[str, Any], line: str) -> Any:
    return spec.get("value")


def _resolver_line_stripped(spec: dict[str, Any], line: str) -> str:
    src = spec.get("source", "${line}")
    return _expand_line_vars(str(src), line).strip()


def _resolver_split_csv(spec: dict[str, Any], line: str) -> list[str]:
    src = _expand_line_vars(str(spec.get("source", "${line}")), line)
    sep = str(spec.get("separator", ","))
    return [p.strip() for p in src.split(sep) if p.strip()]


def _resolver_split_ws(spec: dict[str, Any], line: str) -> list[str]:
    src = _expand_line_vars(str(spec.get("source", "${line}")), line).strip()
    if not src:
        return []
    return src.split()


def _resolver_compact_calc_sequence(spec: dict[str, Any], line: str) -> list[str]:
    allowed = frozenset(str(spec.get("allowed", "0123456789.+-*/×÷%=")))
    min_len = int(spec.get("min_len", 2))
    raw = _expand_line_vars(str(spec.get("source", "${line}")), line)
    raw = raw.strip().replace(" ", "")
    if spec.get("unicode_minus_to_hyphen", True):
        raw = raw.replace("\u2212", "-")
    if len(raw) < min_len or any(ch not in allowed for ch in raw):
        raise ValueError("compact_calc: line not in allowed charset or too short")
    keys: list[str] = list(raw)
    if spec.get("append_equals_if_needed", True):
        keys = _maybe_append_equals(keys, spec.get("equals_rules") or {})
    return keys


def _maybe_append_equals(keys: list[str], rules: dict[str, Any]) -> list[str]:
    if not keys or keys[-1] == "=":
        return keys
    last = keys[-1]
    ops = str(rules.get("ops_if_any", "+-*/×÷"))
    num_tail = bool(rules.get("number_tail", True))
    if num_tail and last not in "0123456789.":
        return keys
    if not any(k in ops for k in keys):
        return keys
    return keys + ["="]


_RESOLVERS: dict[str, Callable[[dict[str, Any], str], Any]] = {
    "literal": _resolver_literal,
    "line_stripped": _resolver_line_stripped,
    "split_csv": _resolver_split_csv,
    "split_ws": _resolver_split_ws,
    "compact_calc_sequence": _resolver_compact_calc_sequence,
}


def register_value_resolver(name: str, fn: Callable[[dict[str, Any], str], Any]) -> None:
    """热插拔：注册 ``input.body`` 里 ``{"from": "<name>", ...}`` 的解析器。"""
    _RESOLVERS[name] = fn


def _resolve_value(v: Any, line: str) -> Any:
    if isinstance(v, dict) and "from" in v:
        name = str(v.get("from", ""))
        fn = _RESOLVERS.get(name)
        if fn is None:
            raise KeyError(f"unknown value resolver: {name!r}")
        return fn(v, line)
    if isinstance(v, str):
        return _expand_line_vars(v, line)
    if isinstance(v, dict):
        return {k: _resolve_value(x, line) for k, x in v.items()}
    if isinstance(v, list):
        return [_resolve_value(x, line) for x in v]
    return v


def _when_matches(when: dict[str, Any], line: str) -> bool:
    wtype = str(when.get("type", ""))
    s = line.strip()
    if wtype == "default":
        return True
    if wtype == "line_empty":
        return s == ""
    if wtype == "line_equals_ci":
        vals = when.get("values") or []
        if not isinstance(vals, list):
            return False
        low = s.lower()
        return any(low == str(x).lower() for x in vals)
    if wtype == "line_contains":
        sub = str(when.get("substring", ""))
        return sub in line
    if wtype == "regex":
        pat = str(when.get("pattern", ""))
        flags = 0
        fs = str(when.get("flags", "")).upper()
        if "IGNORECASE" in fs:
            flags |= re.IGNORECASE
        style = str(when.get("style", "fullmatch")).lower()
        try:
            rx = re.compile(pat, flags)
        except re.error:
            return False
        target = s if when.get("strip_line", True) else line
        if style == "search":
            ok = rx.search(target) is not None
        else:
            ok = rx.fullmatch(target) is not None
        if not ok:
            return False
        if "min_len" in when and len(target) < int(when["min_len"]):
            return False
        return True
    return False


def _load_json_file(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return {}
    return data


DEFAULT_IO_MAPPING: dict[str, Any] = {
    "version": 1,
    "quit_tokens": ["quit", "exit", "q"],
    "routes": [
        {
            "id": "ping",
            "when": {"type": "line_equals_ci", "values": ["ping"]},
            "transport": "rpc",
            "input": {"body": {"action": "ping"}},
            "output_profile": "ws_ok_raw",
        },
        {
            "id": "display",
            "when": {"type": "line_equals_ci", "values": ["display", "d"]},
            "transport": "rpc",
            "input": {"body": {"action": "display"}},
            "output_profile": "json_pretty",
        },
        {
            "id": "stream",
            "when": {"type": "line_equals_ci", "values": ["stream", "display_stream"]},
            "transport": "stream",
            "input": {"body": {"action": "display_stream"}},
            "output_profile": "calc_display_stream",
        },
        {
            "id": "reset",
            "when": {"type": "line_equals_ci", "values": ["reset"]},
            "transport": "rpc",
            "input": {"body": {"action": "reset"}},
            "output_profile": "calc_snapshot_lines",
        },
        {
            "id": "sequence_csv",
            "when": {"type": "line_contains", "substring": ","},
            "transport": "rpc",
            "input": {
                "body": {
                    "action": "sequence",
                    "keys": {"from": "split_csv", "source": "${line}", "separator": ","},
                }
            },
            "output_profile": "calc_snapshot_lines",
        },
        {
            "id": "sequence_ws",
            "when": {"type": "regex", "pattern": r"^\S+\s+\S", "style": "search"},
            "transport": "rpc",
            "input": {
                "body": {
                    "action": "sequence",
                    "keys": {"from": "split_ws", "source": "${line}"},
                }
            },
            "output_profile": "calc_snapshot_lines",
        },
        {
            "id": "compact_expr",
            "when": {
                "type": "regex",
                "pattern": r"^[0-9.+\-*/%=×÷]+$",
                "style": "fullmatch",
                "min_len": 2,
            },
            "transport": "rpc",
            "input": {
                "body": {
                    "action": "sequence",
                    "keys": {
                        "from": "compact_calc_sequence",
                        "source": "${line}",
                        "allowed": "0123456789.+-*/×÷%=",
                        "min_len": 2,
                        "unicode_minus_to_hyphen": True,
                        "append_equals_if_needed": True,
                        "equals_rules": {"ops_if_any": "+-*/×÷", "number_tail": True},
                    },
                }
            },
            "output_profile": "calc_snapshot_lines",
        },
        {
            "id": "single_press",
            "when": {"type": "default"},
            "transport": "rpc",
            "input": {"body": {"action": "press", "key": {"from": "line_stripped", "source": "${line}"}}},
            "output_profile": "calc_snapshot_lines",
        },
    ],
    "output_profiles": {
        "json_pretty": {"type": "json_dump", "indent": 2},
        "ws_ok_raw": {"type": "json_dump", "indent": None},
        "calc_snapshot_lines": {
            "type": "template_lines",
            "on_not_ok": [{"print_template": "${raw_json}"}],
            "on_ok": [
                {
                    "if_nonempty_path": "snapshot.expression_line",
                    "print_template": "  → 式子: ${snapshot.expression_line}",
                },
                {
                    "print_template": "  → display: ${snapshot.display}   revision: ${snapshot.revision}",
                },
            ],
        },
        "calc_display_stream": {
            "type": "stream",
            "skip_message_types": ["heartbeat"],
            "partial_message_type": "display_partial",
            "partial_field": "partial",
            "done_message_type": "display_stream_done",
            "done_field": "full",
            "on_partial": {"prefix": "\r  typing: ", "suffix": "", "newline_after_done": True},
            "after_done": [{"print_template": "  → full: ${full}"}],
        },
    },
}


def load_io_mapping_document(
    ref: str | dict[str, Any] | None,
    root: Path,
) -> dict[str, Any]:
    """``ref`` 为相对 ``root`` 的路径、内嵌 dict，或 ``None`` 时使用默认路径 / 内置表。"""
    if isinstance(ref, dict):
        return ref
    rel = (ref or "config/io_mapping.cof").strip() or "config/io_mapping.cof"
    path = Path(rel)
    if not path.is_absolute():
        path = (root / path).resolve()
    if path.is_file():
        return _load_json_file(path)
    return json.loads(json.dumps(DEFAULT_IO_MAPPING))


@dataclass
class MappedLine:
    kind: Literal["skip", "quit", "rpc", "stream"]
    route_id: str
    body: dict[str, Any]
    output_profile: str


class IoMappingEngine:
    def __init__(self, doc: dict[str, Any]) -> None:
        self._doc = doc
        self.quit_tokens = {str(x).lower() for x in (doc.get("quit_tokens") or [])}

    @classmethod
    def load(cls, ref: str | dict[str, Any] | None, root: Path) -> IoMappingEngine:
        return cls(load_io_mapping_document(ref, root))

    def match(self, line: str) -> MappedLine | None:
        s = line.strip()
        if not s or s.startswith("#"):
            return MappedLine(kind="skip", route_id="", body={}, output_profile="")
        if s.lower() in self.quit_tokens:
            return MappedLine(kind="quit", route_id="quit", body={}, output_profile="")
        routes = self._doc.get("routes")
        if not isinstance(routes, list):
            return None
        for route in routes:
            if not isinstance(route, dict):
                continue
            when = route.get("when") or {}
            if not isinstance(when, dict):
                continue
            if not _when_matches(when, line):
                continue
            rid = str(route.get("id", "route"))
            transport = str(route.get("transport", "rpc"))
            inp = route.get("input") or {}
            body = inp.get("body") if isinstance(inp, dict) else None
            if not isinstance(body, dict):
                body = {}
            body = _resolve_value(body, line)
            prof = str(route.get("output_profile", "") or "")
            if transport == "stream":
                return MappedLine(kind="stream", route_id=rid, body=body, output_profile=prof)
            return MappedLine(kind="rpc", route_id=rid, body=body, output_profile=prof)
        return None

    def profile(self, name: str) -> dict[str, Any]:
        profiles = self._doc.get("output_profiles") or {}
        if not isinstance(profiles, dict):
            return {}
        p = profiles.get(name)
        return p if isinstance(p, dict) else {}


def render_rpc_output(
    profile: dict[str, Any],
    resp: dict[str, Any],
    print_fn: Callable[..., None],
) -> None:
    ptype = str(profile.get("type", "template_lines"))
    if ptype == "json_dump":
        indent = profile.get("indent")
        if indent is None:
            print_fn(json.dumps(resp, ensure_ascii=False), flush=True)
        else:
            print_fn(json.dumps(resp, ensure_ascii=False, indent=int(indent)), flush=True)
        return
    if ptype != "template_lines":
        print_fn(str(resp), flush=True)
        return
    extra = {"raw_json": json.dumps(resp, ensure_ascii=False)}
    if not resp.get("ok"):
        for rule in profile.get("on_not_ok") or []:
            if not isinstance(rule, dict):
                continue
            tpl = str(rule.get("print_template", ""))
            print_fn(_expand_response_vars(tpl, resp, extra), flush=True)
        return
    for rule in profile.get("on_ok") or []:
        if not isinstance(rule, dict):
            continue
        path = rule.get("if_nonempty_path")
        if path:
            v = _get_path(resp, str(path))
            if v is None or str(v).strip() == "":
                continue
        tpl = str(rule.get("print_template", ""))
        if tpl:
            print_fn(_expand_response_vars(tpl, resp, extra), flush=True)


def render_stream_done_lines(
    profile: dict[str, Any],
    full: str,
    print_fn: Callable[..., None],
) -> None:
    for rule in profile.get("after_done") or []:
        if not isinstance(rule, dict):
            continue
        tpl = str(rule.get("print_template", ""))
        ctx: dict[str, Any] = {"full": full}
        print_fn(_expand_response_vars(tpl, ctx, ctx), flush=True)
