# -*- coding: utf-8 -*-
"""
WebSocket 客户端（``yxd_soft`` 子包）：输入/输出分离、``io_mapping`` 驱动 REPL、可热插拔后端。

替代原独立包 ``calc_ws_lib``；入口：``python -m yxd_soft.ws_client``。
"""
from __future__ import annotations

from ..calc_settings import (
    WS_CLIENT_PING_INTERVAL_SECONDS,
    WS_CLIENT_PING_TIMEOUT_SECONDS,
    WS_RECONNECT_INITIAL_DELAY_SECONDS,
    WS_RECONNECT_MAX_ATTEMPTS,
    WS_RECONNECT_MAX_DELAY_SECONDS,
)
from .config import WebSocketCof, http_base, load_websocket_cof, ws_url
from .entry import CalcWsApp, main, run_cli
from .io_mapping import (
    IoMappingEngine,
    load_io_mapping_document,
    register_value_resolver,
)
from .loggers import FileLogSinks, LogHub, LogSink
from .paths import config_dir, logs_dir, resolve_root, websocket_cof_path
from .registry import (
    create_input,
    create_output,
    register_input_backend,
    register_output_backend,
)

__all__ = [
    "CalcWsApp",
    "main",
    "run_cli",
    "WebSocketCof",
    "load_websocket_cof",
    "http_base",
    "ws_url",
    "IoMappingEngine",
    "load_io_mapping_document",
    "register_value_resolver",
    "resolve_root",
    "logs_dir",
    "config_dir",
    "websocket_cof_path",
    "LogHub",
    "LogSink",
    "FileLogSinks",
    "register_input_backend",
    "register_output_backend",
    "create_input",
    "create_output",
    "WS_CLIENT_PING_INTERVAL_SECONDS",
    "WS_CLIENT_PING_TIMEOUT_SECONDS",
    "WS_RECONNECT_INITIAL_DELAY_SECONDS",
    "WS_RECONNECT_MAX_DELAY_SECONDS",
    "WS_RECONNECT_MAX_ATTEMPTS",
]
