"""输入 / 输出 / 操作 三类日志，各自独立文件，可热插拔附加后端。"""
from __future__ import annotations

import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Protocol


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class LogSink(Protocol):
    def write_input(self, line: str) -> None: ...
    def write_output(self, line: str) -> None: ...
    def write_operation(self, line: str) -> None: ...


@dataclass
class FileLogSinks:
    """三个独立日志文件，位于 ``logs/`` 下。"""

    root_logs: Path
    _input_fp: Any = field(init=False, repr=False)
    _output_fp: Any = field(init=False, repr=False)
    _op_fp: Any = field(init=False, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def __post_init__(self) -> None:
        self.root_logs.mkdir(parents=True, exist_ok=True)
        object.__setattr__(self, "_lock", threading.Lock())
        object.__setattr__(self, "_input_fp", open(self.root_logs / "input.log", "a", encoding="utf-8"))
        object.__setattr__(self, "_output_fp", open(self.root_logs / "output.log", "a", encoding="utf-8"))
        object.__setattr__(self, "_op_fp", open(self.root_logs / "operation.log", "a", encoding="utf-8"))

    def close(self) -> None:
        with self._lock:
            for fp in (self._input_fp, self._output_fp, self._op_fp):
                try:
                    fp.close()
                except Exception:
                    pass

    def write_input(self, line: str) -> None:
        self._write(self._input_fp, line)

    def write_output(self, line: str) -> None:
        self._write(self._output_fp, line)

    def write_operation(self, line: str) -> None:
        self._write(self._op_fp, line)

    def _write(self, fp: Any, line: str) -> None:
        msg = f"[{_ts()}] {line}\n"
        with self._lock:
            fp.write(msg)
            fp.flush()


SinkHook = Callable[[str, str], None]  # (kind, line) kind in input|output|operation


@dataclass
class LogHub:
    """聚合多个 ``LogSink``；运行时可 ``attach`` / ``detach``。"""

    _sinks: list[LogSink] = field(default_factory=list)
    _hooks: list[SinkHook] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "_lock", threading.Lock())

    def attach_sink(self, sink: LogSink) -> None:
        with self._lock:
            if sink not in self._sinks:
                self._sinks.append(sink)

    def detach_sink(self, sink: LogSink) -> None:
        with self._lock:
            try:
                self._sinks.remove(sink)
            except ValueError:
                pass

    def attach_hook(self, hook: SinkHook) -> None:
        with self._lock:
            if hook not in self._hooks:
                self._hooks.append(hook)

    def detach_hook(self, hook: SinkHook) -> None:
        with self._lock:
            try:
                self._hooks.remove(hook)
            except ValueError:
                pass

    def log_input(self, line: str) -> None:
        self._emit("input", line, "write_input")

    def log_output(self, line: str) -> None:
        self._emit("output", line, "write_output")

    def log_operation(self, line: str) -> None:
        self._emit("operation", line, "write_operation")

    def _emit(self, kind: str, line: str, method: str) -> None:
        with self._lock:
            sinks = list(self._sinks)
            hooks = list(self._hooks)
        for h in hooks:
            try:
                h(kind, line)
            except Exception:
                pass
        for s in sinks:
            try:
                getattr(s, method)(line)
            except Exception:
                pass

    def close(self) -> None:
        with self._lock:
            for s in list(self._sinks):
                close = getattr(s, "close", None)
                if callable(close):
                    try:
                        close()
                    except Exception:
                        pass
            self._sinks.clear()
            self._hooks.clear()
