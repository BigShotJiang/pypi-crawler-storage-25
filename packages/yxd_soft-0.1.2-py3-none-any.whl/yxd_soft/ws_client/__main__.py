# -*- coding: utf-8 -*-
"""``python -m yxd_soft.ws_client`` — WebSocket REPL（io_mapping 驱动）。"""
from __future__ import annotations

from .entry import main


if __name__ == "__main__":
    raise SystemExit(main())
