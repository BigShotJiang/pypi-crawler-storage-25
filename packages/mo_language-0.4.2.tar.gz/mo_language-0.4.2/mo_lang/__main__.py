"""
mo_lang.__main__ — entry point for the Mo language.
Invoked via `mo` console script or `python -m mo_lang`.

Usage:
    mo program.mo           # compile + run (bytecode VM)
    mo                      # interactive REPL
    mo --interp file.mo     # tree-walk interpreter (fallback)
    mo --dis file.mo        # disassemble bytecode
    mo --llvm file.mo       # compile to LLVM IR
    mo --llvm-run file.mo   # compile + run with LLVM JIT
    mo --wasm file.mo       # compile to WebAssembly
    mo --wat file.mo        # compile to WAT (WebAssembly Text)
    mo install <pkg>        # install a package
    mo remove <pkg>         # remove a package
    mo list                 # list installed packages
"""
import sys
import os
import pickle
from typing import Union
from .lexer import Lexer, LexError
from .parser import Parser, ParseError
from .interpreter import RuntimeError_


def _get_cache_path(src_path: str) -> str:
    return src_path + ".cache"


def _load_from_cache(cache_path: str, src_mtime: float) -> Union[list, None]:
    if not os.path.exists(cache_path):
        return None
    try:
        with open(cache_path, "rb") as f:
            cached = pickle.load(f)
            if cached.get("mtime") == src_mtime:
                return cached.get("ast")
    except Exception:
        pass
    return None


def _save_to_cache(cache_path: str, ast: list, src_mtime: float):
    try:
        with open(cache_path, "wb") as f:
            pickle.dump({"mtime": src_mtime, "ast": ast}, f)
    except Exception:
        pass


def _parse_cached(src_path: str) -> list:
    """Parse with AST caching."""
    src = open(src_path).read()
    src_mtime = os.path.getmtime(src_path)
    cache_path = _get_cache_path(src_path)
    ast = _load_from_cache(cache_path, src_mtime)
    if ast is None:
        ast = _parse(src)
        _save_to_cache(cache_path, ast, src_mtime)
    return ast


def _parse(source: str):
    tokens = Lexer(source).tokenize()
    return Parser(tokens).parse()


# ── VM path ───────────────────────────────────────────────────────────────────

def vm_execute(source: str, vm, env=None):
    from .compiler import Compiler
    from .vm import MoThrow
    try:
        code = Compiler().compile(_parse(source))
        vm.run(code, env)
    except LexError as e:
        print(f"[Lex Error] {e}")
    except ParseError as e:
        print(f"[Parse Error] {e}")
    except MoThrow as e:
        print(f"[Uncaught throw] {e.value}")
    except RuntimeError_ as e:
        line = getattr(vm, '_current_line', 0)
        loc = f" line {line}:" if line else ""
        print(f"[Runtime Error]{loc} {e}")


def vm_repl():
    from .vm import VM
    from .interpreter import Environment

    try:
        import readline
        readline.parse_and_bind("tab: complete")
    except ImportError:
        pass  # Windows without pyreadline — arrow keys won't work but REPL still runs

    machine = VM()
    env = Environment(parent=machine.globals)
    print("Mo REPL  (type 'exit' to quit)")
    while True:
        try:
            line = input(">>> ")
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break
        if line.strip() == "exit":
            break
        if line.strip():
            vm_execute(line, machine, env)


def _ensure_cvm():
    """Return path to C VM binary, compiling from bundled source if needed."""
    import os, subprocess, shutil
    bin_name = "mo-vm.exe" if sys.platform == "win32" else "mo-vm"
    pkg_dir  = os.path.dirname(__file__)

    # 1. already built inside the package (normal case after first run)
    bin_path = os.path.join(pkg_dir, bin_name)
    if os.path.isfile(bin_path) and os.access(bin_path, os.X_OK):
        return bin_path

    # 2. dev tree: cvm/mo-vm
    dev_bin = os.path.abspath(os.path.join(pkg_dir, "..", "cvm", bin_name))
    if os.path.isfile(dev_bin) and os.access(dev_bin, os.X_OK):
        return dev_bin

    # 3. nowhere found — try to compile from bundled mo_vm.c
    src = os.path.join(pkg_dir, "mo_vm.c")
    if not os.path.isfile(src):
        src = os.path.abspath(os.path.join(pkg_dir, "..", "cvm", "mo_vm.c"))
    if not os.path.isfile(src):
        return None

    compilers = ([os.environ["CC"]] if "CC" in os.environ else []) + (
        ["cl"] if sys.platform == "win32" else ["gcc", "clang", "cc"]
    )
    for cc in compilers:
        cmd = ([cc, "/O2", f"/Fe{bin_path}", src] if sys.platform == "win32"
               else [cc, "-O2", "-o", bin_path, src, "-lm"])
        try:
            print(f"[mo] Building C VM with {cc}...", end=" ", flush=True)
            subprocess.run(cmd, check=True, capture_output=True)
            os.chmod(bin_path, 0o755)
            print("done")
            return bin_path
        except FileNotFoundError:
            continue
        except subprocess.CalledProcessError as e:
            print(f"failed\n[mo] {e.stderr.decode().strip()}")
            return None

    return None


def _make_import_callback(base_dir: str):
    """Return a callable used by the C extension to compile imported modules."""
    import os
    from .compiler import Compiler
    from .bytecode import bytecode_to_json

    pkg_dir = os.path.dirname(__file__)
    std_dir = os.path.join(pkg_dir, "std")
    pkg_packages = os.path.expanduser("~/.mo/packages")

    def _callback(mo_path: str, vm_base_dir: str) -> str:
        candidates = [
            os.path.join(vm_base_dir, mo_path),
            os.path.join(std_dir, mo_path.replace("std/", "")),
            os.path.join(pkg_packages, mo_path),
        ]
        src = None
        for p in candidates:
            if os.path.exists(p):
                try:
                    src = open(p).read()
                except OSError:
                    pass
                break
        if src is None:
            return None
        try:
            ast = _parse_cached(p)
            code = Compiler().compile(ast)
            return bytecode_to_json(code)
        except Exception:
            return None

    return _callback


def _cvm_ext_run_file(path: str, trace: bool = False):
    """Run a file via the Python C extension (no fork, no temp files)."""
    import os
    from . import _cvm
    from .compiler import Compiler
    from .bytecode import bytecode_to_json
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        code = Compiler().compile(ast)
        json_str = bytecode_to_json(code)
    except (LexError, ParseError) as e:
        print(f"[Parse Error] {e}")
        sys.exit(1)

    base_dir = os.path.dirname(os.path.abspath(path))
    import_cb = _make_import_callback(base_dir)
    try:
        if trace:
            _cvm.run_trace(json_str, base_dir, import_cb)
        else:
            _cvm.run(json_str, base_dir, import_cb)
    except RuntimeError as e:
        print(e)
        sys.exit(1)


def _cvm_run_file(path: str, cvm_bin: str, trace: bool = False):
    import os, tempfile, subprocess
    from .compiler import Compiler
    from .bytecode import bytecode_to_json
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        code = Compiler().compile(ast)
        json_bytes = bytecode_to_json(code).encode()
    except (LexError, ParseError) as e:
        print(f"[Parse Error] {e}")
        sys.exit(1)

    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tf:
        tf.write(json_bytes)
        tf_name = tf.name

    try:
        cmd = [cvm_bin]
        if trace:
            cmd.append("--trace")
        cmd += [tf_name, os.path.abspath(path)]
        result = subprocess.run(cmd)
        sys.exit(result.returncode)
    finally:
        os.unlink(tf_name)


def vm_run_file(path: str, trace: bool = False):
    import os
    # Fastest path: C extension (no fork, no temp files)
    try:
        from . import _cvm  # noqa: F401
        _cvm_ext_run_file(path, trace=trace)
        return
    except ImportError:
        pass
    # Second path: standalone C binary
    cvm = _ensure_cvm()
    if cvm:
        _cvm_run_file(path, cvm, trace=trace)
        return
    # Fallback: pure Python VM (with AST cache)
    from .vm import VM
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    machine = VM(trace=trace)
    machine._base_dir = os.path.dirname(os.path.abspath(path))
    from .compiler import Compiler
    code = Compiler().compile(ast)
    machine.run(code)


# ── disassembler ──────────────────────────────────────────────────────────────

def disassemble(path: str):
    from .compiler import Compiler
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        code = Compiler().compile(ast)
    except (LexError, ParseError) as e:
        print(f"[Error] {e}")
        sys.exit(1)
    _dis_code(code, "<module>")


def _dis_code(code: list, name: str, indent: int = 0):
    from .compiler import Op
    pad = "  " * indent
    print(f"{pad}=== {name} ===")
    for i, instr in enumerate(code):
        if instr.op is Op.MAKE_FUNCTION:
            print(f"{pad}{i:4d}  {instr.op.name}  {instr.arg.name}")
            _dis_code(instr.arg.code, instr.arg.name, indent + 1)
        elif instr.op is Op.MAKE_CLASS:
            cname, parent, methods = instr.arg
            print(f"{pad}{i:4d}  {instr.op.name}  {cname}"
                  + (f" extends {parent}" if parent else ""))
            for mname, cfn in methods.items():
                _dis_code(cfn.code, f"{cname}.{mname}", indent + 1)
        else:
            arg_str = "" if instr.arg is None else f"  {instr.arg!r}"
            print(f"{pad}{i:4d}  {instr.op.name}{arg_str}")


# ── LLVM backend ──────────────────────────────────────────────────────────────

def llvm_compile_file(path: str):
    """Compile Mo file to LLVM IR."""
    from .llvm_backend import compile_to_llvm
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        ir_code = compile_to_llvm(ast)
        print(ir_code)
    except Exception as e:
        print(f"[LLVM Compile Error] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def llvm_run_file(path: str):
    """Compile and run Mo file using LLVM JIT."""
    from .llvm_backend import LLVMJIT
    from .compiler import Compiler
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        jit = LLVMJIT()
        bytecode = Compiler().compile(ast)
        result = jit.compile_and_run(bytecode)
        print(result)
    except Exception as e:
        print(f"[LLVM Run Error] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


# ── WebAssembly backend ───────────────────────────────────────────────────────

def wasm_compile_file(path: str, output: str):
    """Compile Mo file to WebAssembly binary."""
    from .wasm_backend import compile_to_wasm
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        wasm_bytes = compile_to_wasm(ast)
        with open(output, 'wb') as f:
            f.write(wasm_bytes)
        print(f"Compiled to {output} ({len(wasm_bytes)} bytes)")
    except Exception as e:
        print(f"[WASM Compile Error] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def wat_compile_file(path: str):
    """Compile Mo file to WAT (WebAssembly Text format)."""
    from .wasm_backend import compile_to_wasm, wasm_to_wat
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    try:
        wasm_bytes = compile_to_wasm(ast)
        wat_code = wasm_to_wat(wasm_bytes)
        print(wat_code)
    except Exception as e:
        print(f"[WAT Compile Error] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


# ── interpreter fallback ──────────────────────────────────────────────────────

def interp_run_file(path: str):
    import os
    from .interpreter import Interpreter
    try:
        ast = _parse_cached(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        sys.exit(1)
    interp = Interpreter()
    interp._base_dir = os.path.dirname(os.path.abspath(path))
    try:
        interp.run(ast)
    except LexError as e:
        print(f"[Lex Error] {e}")
    except ParseError as e:
        print(f"[Parse Error] {e}")
    except RuntimeError_ as e:
        line = getattr(interp, '_current_line', 0)
        loc = f" line {line}:" if line else ""
        print(f"[Runtime Error]{loc} {e}")


# ── package manager ───────────────────────────────────────────────────────────

def _packages_dir() -> str:
    import os
    d = os.path.expanduser("~/.mo/packages")
    os.makedirs(d, exist_ok=True)
    return d


def _lock_path() -> str:
    import os
    return os.path.join(_packages_dir(), "mo.lock")


def _read_lock() -> dict:
    import json, os
    p = _lock_path()
    if os.path.exists(p):
        try:
            return json.loads(open(p).read())
        except Exception:
            pass
    return {}


def _write_lock(lock: dict):
    import json
    open(_lock_path(), "w").write(json.dumps(lock, indent=2) + "\n")


def pkg_install(spec: str):
    """Install a Mo package.

    mo install https://example.com/foo.mo      → download directly
    mo install user/repo                        → GitHub shorthand
    mo install user/repo/path/to/file.mo       → specific file on GitHub
    """
    import os, urllib.request
    pkgs = _packages_dir()

    if spec.startswith("http://") or spec.startswith("https://"):
        url = spec
        filename = url.split("/")[-1]
        if not filename.endswith(".mo"):
            filename += ".mo"
    elif "/" in spec:
        # support user/repo@v1.2.3 or user/repo@tag
        version = "main"
        if "@" in spec:
            spec, version = spec.rsplit("@", 1)
        parts = spec.split("/")
        if len(parts) == 2:
            user, repo = parts
            url = f"https://raw.githubusercontent.com/{user}/{repo}/{version}/{repo}.mo"
            filename = f"{repo}.mo"
        else:
            user, repo = parts[0], parts[1]
            file_path = "/".join(parts[2:])
            url = f"https://raw.githubusercontent.com/{user}/{repo}/{version}/{file_path}"
            filename = parts[-1] if parts[-1].endswith(".mo") else parts[-1] + ".mo"
    else:
        print(f"[mo] Unknown package spec: {spec!r}")
        print("     Usage: mo install <url> | mo install user/repo | mo install user/repo/file.mo")
        sys.exit(1)

    dest = os.path.join(pkgs, filename)
    print(f"[mo] Installing {filename} from {url} ...")
    try:
        urllib.request.urlretrieve(url, dest)
        print(f"[mo] Installed → {dest}")
        print(f"[mo] Use with: import \"{filename[:-3]}\"")
        lock = _read_lock()
        lock[filename[:-3]] = {"url": url, "file": filename}
        _write_lock(lock)
    except Exception as e:
        print(f"[mo] Install failed: {e}")
        sys.exit(1)


def pkg_remove(name: str):
    import os
    pkgs = _packages_dir()
    filename = name if name.endswith(".mo") else name + ".mo"
    path = os.path.join(pkgs, filename)
    if os.path.exists(path):
        os.remove(path)
        lock = _read_lock()
        lock.pop(name.rstrip(".mo"), None)
        _write_lock(lock)
        print(f"[mo] Removed {filename}")
    else:
        print(f"[mo] Package not found: {filename}")
        sys.exit(1)


def pkg_list():
    import os, glob
    pkgs = _packages_dir()
    files = sorted(glob.glob(os.path.join(pkgs, "**/*.mo"), recursive=True))
    if not files:
        print("[mo] No packages installed. Use: mo install <url>")
        return
    print(f"[mo] Installed packages ({pkgs}):")
    for f in files:
        name = os.path.relpath(f, pkgs)
        print(f"  {name}")


def pkg_info(name: str):
    """Show package info from registry."""
    from .registry import get_registry
    registry = get_registry()
    info = registry.get_info(name)
    if not info:
        print(f"[mo] Package {name} not found in registry.")
        return
    
    print(f"[mo] Package: {info.get('name')}")
    print(f"[mo]   Version: {info.get('version')}")
    print(f"[mo]   Description: {info.get('description', '')}")
    print(f"[mo]   Author: {info.get('author', 'unknown')}")
    print(f"[mo]   Repository: {info.get('repo', 'N/A')}")
    print(f"[mo]   URL: {info.get('url', 'N/A')}")
    
    deps = info.get('deps', [])
    if deps:
        print(f"[mo]   Dependencies: {', '.join(deps)}")


def pkg_publish():
    """Show publishing instructions."""
    print("""[mo] Publishing to Mo Package Registry

To publish a package:

1. Create a GitHub repository (e.g., mo-lang/mo-redis)

2. Add your package code (e.g., mo-redis.mo):

   $ cat > mo-redis.mo << 'EOF'
   # Mo Redis client
   fn connect(host, port) { ... }
   fn get(key) { ... }
   fn set(key, value) { ... }
   EOF

3. Create packages.json in repo root:
   
   {
     "name": "mo-redis",
     "version": "1.0.0",
     "description": "Redis client",
     "author": "yourname",
     "deps": []
   }

4. Submit a PR to https://github.com/mo-lang/packages

For direct install without publishing:
   $ mo install https://raw.githubusercontent.com/user/repo/main/file.mo
""")


# ── debugger ──────────────────────────────────────────────────────────────────

def debug_run_file(path: str, break_at_start: bool = False):
    from .debug_adapter import start_debugger
    start_debugger(path, break_at_start=break_at_start)


# ── entry point ───────────────────────────────────────────────────────────────

def _check_path():
    import os, shutil
    if shutil.which("mo"):
        return
    import sysconfig
    scripts_dir = sysconfig.get_path("scripts")
    if sys.platform == "win32":
        print(f"\n[Mo] 提示: 'mo' 命令未加入 PATH，请按以下步骤添加：")
        print(f"  1. 搜索「环境变量」→ 编辑系统环境变量 → 环境变量")
        print(f"  2. 在「用户变量」的 Path 里点「新建」，粘贴：")
        print(f"     {scripts_dir}")
        print(f"  3. 重新打开命令行即可使用 mo 命令")
        print(f"  (现在可继续用 'python -m mo_language' 代替 'mo')\n")
    else:
        shell_rc = "~/.zshrc" if os.environ.get("SHELL", "").endswith("zsh") else "~/.bashrc"
        print(f"\n[Mo] 提示: 'mo' 命令未加入 PATH，运行以下命令添加：")
        print(f'  echo \'export PATH="{scripts_dir}:$PATH"\' >> {shell_rc}')
        print(f"  source {shell_rc}\n")


_HELP = """\
Mo programming language  (https://github.com/qinghua/mo)

Usage:
  mo                        Start interactive REPL
  mo <file.mo>              Run a Mo source file
  mo -h, --help             Show this help message
  mo --version              Show version number
  mo --dis <file.mo>        Disassemble bytecode
  mo --trace <file.mo>      Run with instruction-level trace (debug)
  mo --debug <file.mo>      Run with DAP debugger
  mo --break <file.mo>      Run with debugger, pause at start
  mo --interp <file.mo>     Run via tree-walk interpreter (fallback)

LLVM Backend:
  mo --llvm <file.mo>       Compile to LLVM IR
  mo --llvm-run <file.mo>   Compile and run with LLVM JIT

WebAssembly Backend:
  mo --wasm <file.mo>       Compile to WebAssembly binary
  mo --wat <file.mo>        Compile to WAT (WebAssembly Text)

LSP (Language Server Protocol):
  mo lsp                    Start LSP server (stdio)
  mo lsp --stdio            Use stdin/stdout
  mo lsp --tcp --port 8765  Use TCP on port 8765

Package manager:
  mo install <url>                     Install package from URL
  mo install <user/repo>               Install from GitHub (main branch)
  mo install <user/repo@tag>           Install a specific tag/version
  mo install <user/repo/path/file.mo>  Install a specific file
  mo install --update                  Update all packages
  mo install --update <pkg>           Update specific package
  mo remove <package>                  Remove an installed package
  mo list                              List installed packages
  mo search <query>                    Search packages
  mo info <package>                   Show package info
  mo publish                          Publish package (instructions)

Standard library modules (use: import "std/name" as name):
  std/math      math_sqrt, math_pow, math_abs, math_floor, math_ceil, math_round, math_sin, math_cos, math_log, math_pi
  std/list      push, pop, len
  std/json      json_parse, json_stringify, json_pretty
  std/time      time_now, time_sleep
  std/http      serve, fetch, fetch_post
  std/file      read, write, exists, delete, list_dir
  std/path      path_join, path_dir, path_base, path_ext
  std/os        os_name, os_cwd, os_env, os_cpus
  std/net       net_listen, net_connect, net_send, net_recv
  std/random    random_int, random_float, random_pick
  std/crypto    crypto_md5, crypto_sha256, crypto_sha1
  std/url       url_parse, url_encode, url_decode
  std/process   proc_args, proc_pid, proc_exit

Language features:
  let x = 10                Variables
  fn add(a, b) { a + b }    Functions
  let f = fn(x) { x * 2 }  Anonymous functions
  `Hello, ${name}!`         Template strings
  import "std/json" as json Module imports with namespace
  class Foo extends Bar {}  Classes with inheritance
  try { } catch e { }       Exception handling
  throw "error"             Throw exceptions
  for x in list { }         For loops
  while cond { }            While loops
  break / continue          Loop control

Examples:
  mo hello.mo
  mo install alice/mylib
  mo install alice/mylib@v1.2.0
"""


def main():
    args = sys.argv[1:]
    if not args:
        _check_path()
        vm_repl()
    elif args[0] in ("-h", "--help"):
        print(_HELP)
    elif args[0] == "--version":
        from importlib.metadata import version as _v
        try:
            ver = _v('mo-language')
        except Exception:
            ver = "dev"
        try:
            from . import _cvm  # noqa: F401
            vm_info = "C extension VM"
        except ImportError:
            cvm = _ensure_cvm()
            vm_info = f"C VM ({cvm})" if cvm else "Python VM (C VM not built)"
        print(f"mo {ver}  [{vm_info}]")
    elif args[0] == "install":
        if len(args) < 2:
            print("Usage: mo install <url | user/repo | user/repo@tag>")
            print("       mo install --update [package]  Update packages")
            sys.exit(1)
        if args[1] == "--update":
            from .package_manager import PackageManager
            pm = PackageManager()
            package = args[2] if len(args) > 2 else None
            pm.update(package)
            return
        pkg_install(args[1])
    elif args[0] == "remove":
        if len(args) < 2:
            print("Usage: mo remove <package-name>")
            sys.exit(1)
        pkg_remove(args[1])
    elif args[0] == "list":
        pkg_list()
    elif args[0] == "search":
        if len(args) < 2:
            print("Usage: mo search <query>")
            sys.exit(1)
        from .package_manager import PackageManager
        pm = PackageManager()
        pm.search(args[1])
    elif args[0] == "info":
        if len(args) < 2:
            print("Usage: mo info <package>")
            sys.exit(1)
        pkg_info(args[1])
    elif args[0] == "publish":
        pkg_publish()
    elif args[0] == "fmt":
        if len(args) < 2:
            print("Usage: mo fmt <file.mo> [--check] [--write]")
            print("       --check   Check if file needs formatting")
            print("       --write   Write formatted output to stdout")
            sys.exit(1)
        check_mode = "--check" in args
        write_mode = "--write" in args
        path = args[1]
        if path.startswith("-"):
            path = args[2] if len(args) > 2 else None
        if not path:
            print("Usage: mo fmt <file.mo>")
            sys.exit(1)
        try:
            from .formatter import format_file
            formatted = format_file(path)
            if check_mode:
                with open(path) as f:
                    original = f.read()
                if original != formatted:
                    print(f"{path}: would reformat")
                    sys.exit(1)
                else:
                    print(f"{path}: already formatted")
            elif write_mode:
                print(formatted, end="")
            else:
                with open(path, "w") as f:
                    f.write(formatted)
                print(f"Formatted {path}")
        except Exception as e:
            print(f"Error formatting {path}: {e}")
            sys.exit(1)
    elif args[0] == "lint":
        if len(args) < 2:
            print("Usage: mo lint <file.mo>")
            sys.exit(1)
        path = args[1]
        try:
            from .linter import lint_file
            diagnostics = lint_file(path)
            errors = sum(1 for d in diagnostics if d.severity.value == "error")
            warnings = sum(1 for d in diagnostics if d.severity.value == "warning")
            infos = sum(1 for d in diagnostics if d.severity.value == "info")
            for diag in diagnostics:
                print(diag)
            if diagnostics:
                print(f"\n{errors} errors, {warnings} warnings, {infos} infos")
                if errors > 0:
                    sys.exit(1)
            else:
                print(f"No issues found in {path}")
        except Exception as e:
            print(f"Error linting {path}: {e}")
            sys.exit(1)
    elif args[0] == "--interp":
        if len(args) < 2:
            print("Usage: mo --interp <file.mo>")
            sys.exit(1)
        interp_run_file(args[1])
    elif args[0] == "--dis":
        if len(args) < 2:
            print("Usage: mo --dis <file.mo>")
            sys.exit(1)
        disassemble(args[1])
    elif args[0] == "--trace":
        if len(args) < 2:
            print("Usage: mo --trace <file.mo>")
            sys.exit(1)
        vm_run_file(args[1], trace=True)
    elif args[0] == "--debug":
        if len(args) < 2:
            print("Usage: mo --debug <file.mo>")
            sys.exit(1)
        path_idx = 1
        break_at = args[1] == "--break" if len(args) > 2 else False
        if break_at:
            path_idx = 2
        debug_run_file(args[path_idx], break_at_start=break_at)
    elif args[0] == "lsp":
        from .lsp_server import start_lsp_server
        mode = "stdio"
        port = 8765
        i = 1
        while i < len(args):
            if args[i] == "--stdio":
                mode = "stdio"
            elif args[i] == "--tcp":
                mode = "tcp"
            elif args[i] == "--port" and i + 1 < len(args):
                port = int(args[i + 1])
                i += 1
            i += 1
        start_lsp_server(mode, port)
    elif args[0] == "--llvm":
        if len(args) < 2:
            print("Usage: mo --llvm <file.mo>")
            print("Compiles Mo code to LLVM IR")
            sys.exit(1)
        llvm_compile_file(args[1])
    elif args[0] == "--llvm-run":
        if len(args) < 2:
            print("Usage: mo --llvm-run <file.mo>")
            print("Compiles and executes Mo code using LLVM JIT")
            sys.exit(1)
        llvm_run_file(args[1])
    elif args[0] == "--wasm":
        if len(args) < 2:
            print("Usage: mo --wasm <file.mo> [output.wasm]")
            print("Compiles Mo code to WebAssembly")
            sys.exit(1)
        output = args[2] if len(args) > 2 else "output.wasm"
        wasm_compile_file(args[1], output)
    elif args[0] == "--wat":
        if len(args) < 2:
            print("Usage: mo --wat <file.mo>")
            print("Compiles Mo code to WAT (WebAssembly Text)")
            sys.exit(1)
        wat_compile_file(args[1])
    else:
        vm_run_file(args[0])


if __name__ == "__main__":
    main()
