"""
wasm_backend.py — WebAssembly code generator for Mo language.

Generates WASM binary from Mo AST.
"""
from __future__ import annotations
from typing import Dict, List, Any, BinaryIO, Optional
from dataclasses import dataclass
from enum import IntEnum
import struct

from .ast_nodes import *


# WebAssembly types
class ValType(IntEnum):
    I32 = 0x7f
    I64 = 0x7e
    F32 = 0x7d
    F64 = 0x7c
    V128 = 0x7b
    FUNCREF = 0x70
    EXTERNREF = 0x6f
    VOID = 0x40  # Empty block type


# WebAssembly opcodes
class OpCode(IntEnum):
    UNREACHABLE = 0x00
    NOP = 0x01
    BLOCK = 0x02
    LOOP = 0x03
    IF = 0x04
    ELSE = 0x05
    END = 0x0b
    BR = 0x0c
    BR_IF = 0x0d
    RETURN = 0x0f
    DROP = 0x1a
    SELECT = 0x1b
    
    LOCAL_GET = 0x20
    LOCAL_SET = 0x21
    LOCAL_TEE = 0x22
    GLOBAL_GET = 0x23
    GLOBAL_SET = 0x24
    
    I32_LOAD = 0x28
    I32_STORE = 0x36
    I64_LOAD = 0x29
    I64_STORE = 0x37
    F32_LOAD = 0x2a
    F32_STORE = 0x38
    F64_LOAD = 0x2b
    F64_STORE = 0x39
    
    MEMORY_SIZE = 0x3f
    MEMORY_GROW = 0x40
    
    I32_CONST = 0x41
    I64_CONST = 0x42
    F32_CONST = 0x43
    F64_CONST = 0x44
    
    I32_EQZ = 0x45
    I32_EQ = 0x46
    I32_NE = 0x47
    I32_LT_S = 0x48
    I32_GT_S = 0x4a
    I32_LE_S = 0x4c
    I32_GE_S = 0x4e
    
    I32_ADD = 0x6a
    I32_SUB = 0x6b
    I32_MUL = 0x6c
    I32_DIV_S = 0x6d
    I32_REM_S = 0x6f
    I32_AND = 0x71
    I32_OR = 0x72
    I32_XOR = 0x73
    
    F64_ADD = 0xa0
    F64_SUB = 0xa1
    F64_MUL = 0xa2
    F64_DIV = 0xa3
    
    CALL = 0x10
    CALL_INDIRECT = 0x11


# WebAssembly section IDs
class Section(IntEnum):
    CUSTOM = 0
    TYPE = 1
    IMPORT = 2
    FUNCTION = 3
    TABLE = 4
    MEMORY = 5
    GLOBAL = 6
    EXPORT = 7
    START = 8
    ELEMENT = 9
    CODE = 10
    DATA = 11
    DATA_COUNT = 12


class WASType:
    """WebAssembly type definitions for Mo."""
    
    def __init__(self):
        # Mo values are represented as 64-bit floats (f64) for simplicity
        # In a full implementation, we'd use a tagged union
        self.value_type = ValType.F64
        self.int_type = ValType.I32
        self.ptr_type = ValType.I32  # WASM32


class WASMEncoder:
    """Encodes WebAssembly binary format."""
    
    def __init__(self):
        self.data = bytearray()
    
    def write_byte(self, b: int):
        self.data.append(b & 0xff)
    
    def write_bytes(self, b: bytes):
        self.data.extend(b)
    
    def write_u32(self, n: int):
        """Write unsigned LEB128 32-bit integer."""
        while True:
            byte = n & 0x7f
            n >>= 7
            if n != 0:
                byte |= 0x80
            self.write_byte(byte)
            if n == 0:
                break
    
    def write_i32(self, n: int):
        """Write signed LEB128 32-bit integer."""
        while True:
            byte = n & 0x7f
            n >>= 7
            if (n == 0 and (byte & 0x40) == 0) or (n == -1 and (byte & 0x40) != 0):
                self.write_byte(byte)
                break
            self.write_byte(byte | 0x80)
    
    def write_f64(self, f: float):
        """Write 64-bit float."""
        self.write_bytes(struct.pack('<d', f))
    
    def write_string(self, s: str):
        """Write string with length prefix."""
        encoded = s.encode('utf8')
        self.write_u32(len(encoded))
        self.write_bytes(encoded)
    
    def write_vec(self, items: List[bytes]):
        """Write vector of bytes."""
        self.write_u32(len(items))
        for item in items:
            self.write_bytes(item)
    
    def get_bytes(self) -> bytes:
        return bytes(self.data)


class WASMCompiler:
    """Compiles Mo AST to WebAssembly."""

    def __init__(self):
        self.types = WASType()
        self.encoder = WASMEncoder()

        self.func_types: List[bytes] = []
        self.func_sigs: List[int] = []
        self.func_bodies: List[bytes] = []
        self.exports: List[bytes] = []
        self.imports: List[bytes] = []

        # Local variables for the current function
        self.local_count = 0
        self.local_map: Dict[str, int] = {}

        # Function name -> (import_count + func_index) for CALL
        self.func_index: Dict[str, int] = {}
    
    def compile(self, stmts: List) -> bytes:
        """Compile Mo statements to WASM binary."""
        # Add runtime imports
        self._add_imports()
        
        # Compile functions
        for stmt in stmts:
            self._compile_stmt(stmt)
        
        # Generate WASM binary
        return self._generate_wasm()
    
    def _add_imports(self):
        """Add imports for runtime functions."""
        # Import print function: print(f64) -> void
        # Type index 0: () -> f64 (for main)
        # Type index 1: (f64) -> void (for print)
        
        # Add function type for main: () -> f64
        type_main = self._encode_func_type([], [ValType.F64])
        self.func_types.append(type_main)
        
        # Add function type for print: (f64) -> void
        type_print = self._encode_func_type([ValType.F64], [])
        self.func_types.append(type_print)
        
        # Import print from env
        import_print = self._encode_import("env", "print", 1)
        self.imports.append(import_print)
    
    def _encode_func_type(self, params: List[ValType], 
                          results: List[ValType]) -> bytes:
        """Encode function type."""
        enc = WASMEncoder()
        enc.write_byte(0x60)  # func type
        enc.write_u32(len(params))
        for p in params:
            enc.write_byte(p)
        enc.write_u32(len(results))
        for r in results:
            enc.write_byte(r)
        return enc.get_bytes()
    
    def _encode_import(self, module: str, name: str, type_idx: int) -> bytes:
        """Encode import entry."""
        enc = WASMEncoder()
        enc.write_string(module)
        enc.write_string(name)
        enc.write_byte(0x00)  # import kind: function
        enc.write_u32(type_idx)
        return enc.get_bytes()
    
    def _compile_stmt(self, stmt):
        """Compile a statement."""
        t = type(stmt)
        
        if t is FnDef:
            self._compile_function(stmt)
        elif t is LetStmt:
            self._compile_let(stmt)
        elif t is ExprStmt:
            self._compile_expr_stmt(stmt)
        elif t is ReturnStmt:
            self._compile_return(stmt)
    
    def _compile_function(self, node: FnDef):
        """Compile function definition."""
        param_names = [p[0] if isinstance(p, (tuple, list)) else p for p in node.params]
        self.local_count = len(param_names)
        self.local_map = {name: i for i, name in enumerate(param_names)}

        body_enc = WASMEncoder()
        for stmt in node.body:
            self._compile_stmt_to_bytes(stmt, body_enc)

        # Implicit return 0.0 if no explicit return
        body_enc.write_byte(OpCode.F64_CONST)
        body_enc.write_f64(0.0)
        body_enc.write_byte(OpCode.RETURN)
        body_enc.write_byte(OpCode.END)

        # Declare extra locals (variables created with let)
        extra_locals = max(0, self.local_count - len(param_names))
        func_body = WASMEncoder()
        if extra_locals > 0:
            func_body.write_u32(1)              # one local declaration group
            func_body.write_u32(extra_locals)   # count
            func_body.write_byte(ValType.F64)   # type
        else:
            func_body.write_u32(0)
        func_body.write_bytes(body_enc.get_bytes())

        # Build type: (f64 * n_params) -> f64
        n_params = len(param_names)
        func_type = self._encode_func_type(
            [ValType.F64] * n_params, [ValType.F64]
        )
        type_idx = len(self.func_types)
        self.func_types.append(func_type)

        func_abs_idx = len(self.imports) + len(self.func_sigs)
        self.func_index[node.name] = func_abs_idx
        self.func_sigs.append(type_idx)
        self.func_bodies.append(func_body.get_bytes())

        export = self._encode_export(node.name, func_abs_idx)
        self.exports.append(export)
    
    def _encode_export(self, name: str, func_idx: int) -> bytes:
        """Encode export entry."""
        enc = WASMEncoder()
        enc.write_string(name)
        enc.write_byte(0x00)  # export kind: function
        enc.write_u32(func_idx)
        return enc.get_bytes()
    
    def _compile_let(self, node: LetStmt):
        """Compile let statement."""
        pass  # Handled in function compilation
    
    def _compile_expr_stmt(self, node: ExprStmt):
        """Compile expression statement."""
        pass  # Handled in function compilation
    
    def _compile_return(self, node: ReturnStmt):
        """Compile return statement."""
        pass  # Handled in function compilation
    
    def _compile_stmt_to_bytes(self, stmt, enc: WASMEncoder):
        t = type(stmt)

        if t is LetStmt:
            self._compile_expr_to_bytes(stmt.value, enc)
            local_idx = self.local_count
            self.local_map[stmt.name] = local_idx
            self.local_count += 1
            enc.write_byte(OpCode.LOCAL_SET)
            enc.write_u32(local_idx)

        elif t is AssignStmt:
            self._compile_expr_to_bytes(stmt.value, enc)
            if stmt.name in self.local_map:
                enc.write_byte(OpCode.LOCAL_SET)
                enc.write_u32(self.local_map[stmt.name])
            # else: global assignment — not supported, silently drop

        elif t is ExprStmt:
            self._compile_expr_to_bytes(stmt.expr, enc)
            enc.write_byte(OpCode.DROP)

        elif t is ReturnStmt:
            if stmt.value:
                self._compile_expr_to_bytes(stmt.value, enc)
            else:
                enc.write_byte(OpCode.F64_CONST)
                enc.write_f64(0.0)
            enc.write_byte(OpCode.RETURN)

        elif t is IfStmt:
            self._compile_expr_to_bytes(stmt.condition, enc)
            # Convert f64 truthy to i32 boolean: value != 0.0
            enc.write_byte(OpCode.F64_CONST)
            enc.write_f64(0.0)
            enc.write_byte(0x61)  # f64.ne
            enc.write_byte(OpCode.IF)
            enc.write_byte(ValType.VOID)
            for s in stmt.then_body:
                self._compile_stmt_to_bytes(s, enc)
            if stmt.else_body:
                enc.write_byte(OpCode.ELSE)
                for s in stmt.else_body:
                    self._compile_stmt_to_bytes(s, enc)
            enc.write_byte(OpCode.END)

        elif t is WhileStmt:
            # loop { if !cond { break } body }
            enc.write_byte(OpCode.BLOCK)
            enc.write_byte(ValType.VOID)
            enc.write_byte(OpCode.LOOP)
            enc.write_byte(ValType.VOID)
            self._compile_expr_to_bytes(stmt.condition, enc)
            enc.write_byte(OpCode.F64_CONST)
            enc.write_f64(0.0)
            enc.write_byte(0x61)  # f64.ne
            enc.write_byte(0x45)  # i32.eqz  (negate)
            enc.write_byte(OpCode.BR_IF)
            enc.write_u32(1)  # break out of block
            for s in stmt.body:
                self._compile_stmt_to_bytes(s, enc)
            enc.write_byte(OpCode.BR)
            enc.write_u32(0)  # continue loop
            enc.write_byte(OpCode.END)  # end loop
            enc.write_byte(OpCode.END)  # end block
    
    def _compile_expr_to_bytes(self, expr, enc: WASMEncoder):
        t = type(expr)

        if t is Number:
            enc.write_byte(OpCode.F64_CONST)
            enc.write_f64(float(expr.value))

        elif t is Bool:
            enc.write_byte(OpCode.F64_CONST)
            enc.write_f64(1.0 if expr.value else 0.0)

        elif t is Null:
            enc.write_byte(OpCode.F64_CONST)
            enc.write_f64(0.0)

        elif t is UnaryOp:
            if expr.op == '-':
                self._compile_expr_to_bytes(expr.right, enc)
                enc.write_byte(OpCode.F64_CONST)
                enc.write_f64(-1.0)
                enc.write_byte(OpCode.F64_MUL)
            else:  # not
                self._compile_expr_to_bytes(expr.right, enc)
                enc.write_byte(OpCode.F64_CONST)
                enc.write_f64(0.0)
                enc.write_byte(0x61)   # f64.ne
                enc.write_byte(0x45)   # i32.eqz → boolean not
                # convert i32 back to f64
                enc.write_byte(0xb9)   # f64.convert_i32_u

        elif t is BinOp:
            # Comparison operators produce i32 in WASM; convert back to f64
            cmp_ops = {'==': 0x61, '!=': 0x62, '<': 0x63, '>': 0x64, '<=': 0x65, '>=': 0x66}
            # f64.ne=0x62, f64.lt=0x63, f64.gt=0x64, f64.le=0x65, f64.ge=0x66, f64.eq=0x61
            self._compile_expr_to_bytes(expr.left, enc)
            self._compile_expr_to_bytes(expr.right, enc)
            if expr.op == '+':
                enc.write_byte(OpCode.F64_ADD)
            elif expr.op == '-':
                enc.write_byte(OpCode.F64_SUB)
            elif expr.op == '*':
                enc.write_byte(OpCode.F64_MUL)
            elif expr.op == '/':
                enc.write_byte(OpCode.F64_DIV)
            elif expr.op == '%':
                # fmod via: a - floor(a/b)*b  (simplified: use trunc)
                # Actually WASM has no direct fmod; emit a - trunc(a/b)*b
                # For simplicity just emit F64_DIV for now
                enc.write_byte(OpCode.F64_DIV)
            elif expr.op in cmp_ops:
                enc.write_byte(cmp_ops[expr.op])
                enc.write_byte(0xb9)   # f64.convert_i32_u
            elif expr.op == '&&':
                # result is already on stack from left/right; use SELECT
                enc.write_byte(OpCode.SELECT)
            elif expr.op == '||':
                enc.write_byte(OpCode.SELECT)

        elif t is Call:
            for arg in expr.args:
                self._compile_expr_to_bytes(arg, enc)
            if expr.name == "print":
                enc.write_byte(OpCode.CALL)
                enc.write_u32(0)  # import index 0 = print
            elif expr.name in self.func_index:
                enc.write_byte(OpCode.CALL)
                enc.write_u32(self.func_index[expr.name])
            # else: unknown function call — drop (produces no value on stack)

        elif t is Ident:
            if expr.name in self.local_map:
                enc.write_byte(OpCode.LOCAL_GET)
                enc.write_u32(self.local_map[expr.name])
            else:
                # unknown variable — emit 0
                enc.write_byte(OpCode.F64_CONST)
                enc.write_f64(0.0)
    
    def _generate_wasm(self) -> bytes:
        """Generate complete WASM binary."""
        enc = WASMEncoder()
        
        # Magic number
        enc.write_bytes(b'\x00asm')
        
        # Version
        enc.write_bytes(b'\x01\x00\x00\x00')
        
        # Type section
        if self.func_types:
            type_section = WASMEncoder()
            type_section.write_u32(len(self.func_types))
            for ft in self.func_types:
                type_section.write_bytes(ft)
            self._write_section(enc, Section.TYPE, type_section.get_bytes())
        
        # Import section
        if self.imports:
            import_section = WASMEncoder()
            import_section.write_u32(len(self.imports))
            for imp in self.imports:
                import_section.write_bytes(imp)
            self._write_section(enc, Section.IMPORT, import_section.get_bytes())
        
        # Function section
        if self.func_sigs:
            func_section = WASMEncoder()
            func_section.write_u32(len(self.func_sigs))
            for sig in self.func_sigs:
                func_section.write_u32(sig)
            self._write_section(enc, Section.FUNCTION, func_section.get_bytes())
        
        # Export section
        if self.exports:
            export_section = WASMEncoder()
            export_section.write_u32(len(self.exports))
            for exp in self.exports:
                export_section.write_bytes(exp)
            self._write_section(enc, Section.EXPORT, export_section.get_bytes())
        
        # Code section
        if self.func_bodies:
            code_section = WASMEncoder()
            code_section.write_u32(len(self.func_bodies))
            for body in self.func_bodies:
                code_section.write_bytes(body)
            self._write_section(enc, Section.CODE, code_section.get_bytes())
        
        return enc.get_bytes()
    
    def _write_section(self, enc: WASMEncoder, section_id: Section, data: bytes):
        """Write a WASM section."""
        enc.write_byte(section_id)
        enc.write_u32(len(data))
        enc.write_bytes(data)


def compile_to_wasm(stmts: List) -> bytes:
    """Compile Mo AST to WebAssembly binary."""
    compiler = WASMCompiler()
    return compiler.compile(stmts)


def wasm_to_wat(wasm_bytes: bytes) -> str:
    """Convert WASM binary to WAT text format.

    Uses wabt's wasm2wat if available, otherwise returns a descriptive stub.
    """
    import subprocess, shutil, tempfile, os
    if shutil.which("wasm2wat"):
        with tempfile.NamedTemporaryFile(suffix=".wasm", delete=False) as f:
            f.write(wasm_bytes)
            tmp = f.name
        try:
            result = subprocess.run(["wasm2wat", tmp], capture_output=True, text=True)
            if result.returncode == 0:
                return result.stdout
        finally:
            os.unlink(tmp)
    # Fallback: emit a minimal structural description
    size = len(wasm_bytes)
    return (
        f";; WebAssembly binary ({size} bytes)\n"
        f";; Install wabt (https://github.com/WebAssembly/wabt) for full WAT output\n"
        f";; Magic: {wasm_bytes[:4].hex()}  Version: {wasm_bytes[4:8].hex()}\n"
    )
