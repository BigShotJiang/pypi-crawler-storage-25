"""
Mo Language Server Protocol (LSP) Implementation.

Supports:
- Hover providers
- Completion providers
- Go to Definition
- Find References
- Diagnostics (syntax/semantic errors)
- Text document sync (open/change/save)
"""
import json
import sys
import threading
import socket
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from .lexer import Lexer, LexError, TT, KEYWORDS
from .parser import Parser, ParseError
from .ast_nodes import *


@dataclass
class SymbolInfo:
    """Information about a symbol (variable, function, class)."""
    name: str
    symbol_type: str  # 'variable', 'function', 'class', 'parameter'
    line: int
    column: int
    uri: str
    end_line: int = 0
    end_column: int = 0


@dataclass
class SymbolTable:
    """Symbol table for a single document."""
    definitions: Dict[str, SymbolInfo] = field(default_factory=dict)
    references: Dict[str, List[Tuple[int, int]]] = field(default_factory=dict)  # name -> [(line, col), ...]
    all_symbols: List[SymbolInfo] = field(default_factory=list)  # All definitions in order


class SymbolAnalyzer:
    """Analyzes AST to build symbol table with scope tracking."""

    def __init__(self, uri: str, source: str, tokens=None):
        self.uri = uri
        self.source = source
        self.lines = source.split('\n')
        self.tokens = tokens
        self.symbol_table = SymbolTable()
        self.scope_stack: List[Dict[str, SymbolInfo]] = [{}]  # Global scope
        self.current_scope_depth = 0

    def analyze(self, stmts: List) -> SymbolTable:
        """Analyze statements and build symbol table."""
        # First pass: collect global definitions
        self._collect_globals(stmts)

        # Second pass: analyze all statements for references
        for stmt in stmts:
            self._analyze_stmt(stmt)

        # Third pass: scan source for accurate reference positions
        self._scan_references()

        return self.symbol_table

    def _scan_references(self):
        """Scan source lines for all identifier references."""
        import re

        # Get all defined symbol names plus builtins
        all_names = set(self.symbol_table.definitions.keys())
        all_names.update(['print', 'len', 'str', 'num', 'range', 'push', 'pop'])

        # Clear existing references (we'll rebuild them properly)
        self.symbol_table.references = {}

        for line_num, line_text in enumerate(self.lines, start=1):
            # Skip empty lines and comments
            stripped = line_text.strip()
            if not stripped or stripped.startswith('#'):
                continue

            # Find all word-like identifiers in the line
            for match in re.finditer(r'[a-zA-Z_][a-zA-Z0-9_]*', line_text):
                name = match.group(0)
                if name in all_names and name not in KEYWORDS:
                    col = match.start()
                    # Check if this is not the definition location
                    is_def = False
                    def_info = self.symbol_table.definitions.get(name)
                    if def_info and def_info.line == line_num and def_info.column == col:
                        is_def = True
                    # Also check if it's a parameter definition (params are on function line)
                    if def_info and def_info.symbol_type == 'parameter':
                        param_line = def_info.line
                        if param_line == line_num and col >= def_info.column and col < def_info.column + len(name):
                            is_def = True

                    if not is_def:
                        if name not in self.symbol_table.references:
                            self.symbol_table.references[name] = []
                        self.symbol_table.references[name].append((line_num, col))

    def _get_column(self, line: int, name: str) -> int:
        """Get column position of a name in a line."""
        if line < 1 or line > len(self.lines):
            return 0
        line_text = self.lines[line - 1]
        idx = line_text.find(name)
        return idx if idx >= 0 else 0

    def _get_end_position(self, line: int, start_col: int, name: str) -> Tuple[int, int]:
        """Get end line and column for a symbol."""
        return (line, start_col + len(name))
    
    def _add_definition(self, name: str, symbol_type: str, line: int):
        """Add a symbol definition."""
        col = self._get_column(line, name)
        end_line, end_col = self._get_end_position(line, col, name)
        
        info = SymbolInfo(
            name=name,
            symbol_type=symbol_type,
            line=line,
            column=col,
            uri=self.uri,
            end_line=end_line,
            end_column=end_col
        )
        
        self.symbol_table.definitions[name] = info
        self.symbol_table.all_symbols.append(info)
        
        # Add to current scope
        self.scope_stack[-1][name] = info
    
    def _add_reference(self, name: str, line: int):
        """Track that a name is referenced (used for scope analysis only)."""
        # References are collected via _scan_references for accurate positions
        pass
    
    def _collect_globals(self, stmts: List):
        """Collect globally defined names (functions, classes)."""
        for stmt in stmts:
            t = type(stmt)
            line = getattr(stmt, 'line', 1)
            
            if t is FnDef:
                self._add_definition(stmt.name, 'function', line)
            elif t is AsyncFn:
                self._add_definition(stmt.name, 'function', line)
            elif t is ClassDef:
                self._add_definition(stmt.name, 'class', line)
    
    def _push_scope(self):
        """Push a new scope."""
        self.scope_stack.append({})
        self.current_scope_depth += 1
    
    def _pop_scope(self):
        """Pop the current scope."""
        if len(self.scope_stack) > 1:
            self.scope_stack.pop()
            self.current_scope_depth -= 1
    
    def _find_definition(self, name: str) -> Optional[SymbolInfo]:
        """Find symbol definition in current scope chain."""
        for scope in reversed(self.scope_stack):
            if name in scope:
                return scope[name]
        return None
    
    def _analyze_stmt(self, stmt):
        """Analyze a statement."""
        t = type(stmt)
        line = getattr(stmt, 'line', 1)
        
        if t is LetStmt:
            self._analyze_expr(stmt.value)
            self._add_definition(stmt.name, 'variable', line)
        
        elif t is DestructureLet:
            self._analyze_expr(stmt.value)
            # Add pattern variables
            if isinstance(stmt.pattern, ListPattern):
                for elem in stmt.pattern.elements:
                    self._add_definition(elem, 'variable', line)
            elif isinstance(stmt.pattern, DictPattern):
                for key, var_name in stmt.pattern.pairs:
                    self._add_definition(var_name, 'variable', line)
        
        elif t is AssignStmt:
            self._add_reference(stmt.name, line)
            self._analyze_expr(stmt.value)
        
        elif t is ExprStmt:
            self._analyze_expr(stmt.expr)
        
        elif t is FnDef:
            self._push_scope()
            # Add parameters to scope
            for param, default in stmt.params:
                param_line = line  # Parameters are on same line as function
                self._add_definition(param, 'parameter', param_line)
                if default:
                    self._analyze_expr(default)
            # Analyze body
            for body_stmt in stmt.body:
                self._analyze_stmt(body_stmt)
            self._pop_scope()
        
        elif t is AsyncFn:
            self._push_scope()
            for param, default in stmt.params:
                param_line = line
                self._add_definition(param, 'parameter', param_line)
                if default:
                    self._analyze_expr(default)
            for body_stmt in stmt.body:
                self._analyze_stmt(body_stmt)
            self._pop_scope()
        
        elif t is ReturnStmt:
            if stmt.value:
                self._analyze_expr(stmt.value)
        
        elif t is IfStmt:
            self._analyze_expr(stmt.condition)
            self._push_scope()
            for body_stmt in stmt.then_body:
                self._analyze_stmt(body_stmt)
            self._pop_scope()
            
            if stmt.else_body:
                self._push_scope()
                for body_stmt in stmt.else_body:
                    self._analyze_stmt(body_stmt)
                self._pop_scope()
        
        elif t is WhileStmt:
            self._analyze_expr(stmt.condition)
            self._push_scope()
            for body_stmt in stmt.body:
                self._analyze_stmt(body_stmt)
            self._pop_scope()
        
        elif t is ForStmt:
            self._analyze_expr(stmt.iter)
            self._push_scope()
            self._add_definition(stmt.var, 'variable', line)
            for body_stmt in stmt.body:
                self._analyze_stmt(body_stmt)
            self._pop_scope()
        
        elif t is TryCatch:
            self._push_scope()
            for body_stmt in stmt.try_body:
                self._analyze_stmt(body_stmt)
            self._pop_scope()
            
            self._push_scope()
            self._add_definition(stmt.err_var, 'variable', line)
            for body_stmt in stmt.catch_body:
                self._analyze_stmt(body_stmt)
            self._pop_scope()
        
        elif t is ThrowStmt:
            self._analyze_expr(stmt.value)
        
        elif t is ClassDef:
            self._push_scope()
            for method in stmt.methods:
                self._analyze_stmt(method)
            self._pop_scope()
        
        elif t is MatchStmt:
            self._analyze_expr(stmt.expr)
            for case in stmt.cases:
                self._push_scope()
                self._analyze_pattern(case.pattern)
                for body_stmt in case.body:
                    self._analyze_stmt(body_stmt)
                self._pop_scope()
        
        elif t is IndexSet:
            self._analyze_expr(stmt.obj)
            self._analyze_expr(stmt.index)
            self._analyze_expr(stmt.value)
        
        elif t is SetAttr:
            self._analyze_expr(stmt.obj)
            self._analyze_expr(stmt.value)
    
    def _analyze_pattern(self, pattern):
        """Analyze a pattern and add bindings."""
        t = type(pattern)
        line = getattr(pattern, 'line', 1)
        
        if t is Ident:
            # Variable binding in pattern
            self._add_definition(pattern.name, 'variable', line)
        elif t is ListLiteral:
            for elem in pattern.elements:
                self._analyze_pattern(elem)
        elif t is DictLiteral:
            for key, val in pattern.pairs:
                self._analyze_pattern(val)
    
    def _analyze_expr(self, expr):
        """Analyze an expression for references."""
        t = type(expr)
        line = getattr(expr, 'line', 1)
        
        if t is Ident:
            self._add_reference(expr.name, line)
        
        elif t is BinOp:
            self._analyze_expr(expr.left)
            self._analyze_expr(expr.right)
        
        elif t is UnaryOp:
            self._analyze_expr(expr.right)
        
        elif t is Call:
            self._add_reference(expr.name, line)
            for arg in expr.args:
                self._analyze_expr(arg)
        
        elif t is CallExpr:
            self._analyze_expr(expr.callee)
            for arg in expr.args:
                self._analyze_expr(arg)
        
        elif t is ListLiteral:
            for elem in expr.elements:
                self._analyze_expr(elem)
        
        elif t is DictLiteral:
            for k, v in expr.pairs:
                self._analyze_expr(k)
                self._analyze_expr(v)
        
        elif t is IndexGet:
            self._analyze_expr(expr.obj)
            self._analyze_expr(expr.index)
        
        elif t is GetAttr:
            self._analyze_expr(expr.obj)
        
        elif t is MethodCall:
            self._analyze_expr(expr.obj)
            for arg in expr.args:
                self._analyze_expr(arg)
        
        elif t is AnonFn:
            self._push_scope()
            for param, default in expr.params:
                self._add_definition(param, 'parameter', line)
                if default:
                    self._analyze_expr(default)
            for stmt in expr.body:
                self._analyze_stmt(stmt)
            self._pop_scope()
        
        elif t is AwaitExpr:
            self._analyze_expr(expr.expr)
        
        elif t is TemplateStr:
            for part in expr.parts:
                if not isinstance(part, str):
                    self._analyze_expr(part)


class MoLanguageServer:
    PROTOCOL_VERSION = "1.77.0"
    
    def __init__(self):
        self.documents: dict[str, str] = {}
        self.symbol_tables: dict[str, SymbolTable] = {}  # uri -> SymbolTable
        self.client_capabilities: dict = {}
        self.server_capabilities = {
            "codeActionProvider": False,
            "codeLensProvider": None,
            "completionProvider": {
                "resolveProvider": False,
                "triggerCharacters": ["."],
            },
            "definitionProvider": True,
            "documentFormattingProvider": False,
            "documentHighlightProvider": False,
            "documentLinkProvider": None,
            "documentRangeFormattingProvider": False,
            "executeCommandProvider": None,
            "experimental": None,
            "hoverProvider": True,
            "implementationProvider": False,
            "referencesProvider": True,
            "renameProvider": False,
            "signatureHelpProvider": None,
            "synchronization": {
                "willSave": False,
                "willSaveWaitUntil": False,
                "didSave": True,
                "didOpen": True,
                "didChange": True,
            },
            "typeDefinitionProvider": False,
            "textDocumentPosition": {
                "dynamicRegistration": False,
            },
        }
    
    def handle_request(self, method: str, params: Any = None) -> dict:
        handlers = {
            "initialize": self._initialize,
            "initialized": self._initialized,
            "shutdown": self._shutdown,
            "textDocument/hover": self._hover,
            "textDocument/completion": self._completion,
            "textDocument/definition": self._definition,
            "textDocument/references": self._references,
            "textDocument/didOpen": self._did_open,
            "textDocument/didChange": self._did_change,
            "textDocument/didSave": self._did_save,
            "textDocument/didClose": self._did_close,
        }
        handler = handlers.get(method)
        if handler:
            return handler(params) if params else handler()
        return self._not_found(method)
    
    def _initialize(self, params: dict) -> dict:
        self.client_capabilities = params.get("capabilities", {})
        root_uri = params.get("rootUri", "")
        return {
            "capabilities": self.server_capabilities,
            "serverInfo": {
                "name": "Mo Language Server",
                "version": "0.1.17",
            },
            "rootUri": root_uri,
        }
    
    def _initialized(self, params: dict) -> dict:
        return {}
    
    def _shutdown(self, params: Any = None) -> dict:
        return {}
    
    def _not_found(self, method: str) -> dict:
        return {"error": {"code": -32601, "message": f"Method not found: {method}"}}
    
    def _get_word_at(self, text: str, line: int, char: int) -> str:
        lines = text.split("\n")
        if line < 0 or line >= len(lines):
            return ""
        line_text = lines[line]
        if char < 0 or char >= len(line_text):
            return ""
        start = char
        end = char
        while start > 0 and (line_text[start - 1].isalnum() or line_text[start - 1] == "_"):
            start -= 1
        while end < len(line_text) and (line_text[end].isalnum() or line_text[end] == "_"):
            end += 1
        return line_text[start:end]
    
    def _get_symbols(self, text: str) -> dict:
        symbols = {}
        try:
            tokens = Lexer(text).tokenize()
        except LexError:
            return symbols
        for tok in tokens:
            if tok.type == TT.IDENT and tok.value:
                symbols[tok.value] = {"line": tok.line, "type": "variable"}
        return symbols

    def _build_symbol_table(self, uri: str, text: str) -> SymbolTable:
        """Build symbol table for a document."""
        try:
            tokens = Lexer(text).tokenize()
            stmts = Parser(tokens).parse()
            analyzer = SymbolAnalyzer(uri, text, tokens)
            return analyzer.analyze(stmts)
        except (LexError, ParseError):
            return SymbolTable()

    def _update_symbol_table(self, uri: str):
        """Update symbol table for a document."""
        text = self.documents.get(uri, "")
        self.symbol_tables[uri] = self._build_symbol_table(uri, text)
    
    def _hover(self, params: dict) -> dict:
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        position = params.get("position", {})
        line = position.get("line", 0)
        character = position.get("character", 0)
        
        text = self.documents.get(uri, "")
        word = self._get_word_at(text, line, character)
        
        if not word:
            return {"contents": ""}
        
        symbols = self._get_symbols(text)
        info = symbols.get(word, {})
        sym_type = info.get("type", "unknown")
        
        if word in KEYWORDS:
            sym_type = "keyword"
        
        return {
            "contents": {
                "kind": "markdown",
                "value": f"**{word}** — `{sym_type}`",
            },
            "range": {
                "start": {"line": line, "character": character - len(word)},
                "end": {"line": line, "character": character},
            },
        }
    
    def _completion(self, params: dict) -> dict:
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        position = params.get("position", {})
        line = position.get("line", 0)
        character = position.get("character", 0)
        
        text = self.documents.get(uri, "")
        symbols = self._get_symbols(text)
        
        completions = []
        
        keywords = [
            "let", "if", "else", "while", "for", "in", "fn", "return",
            "true", "false", "null", "try", "catch", "throw",
            "import", "class", "extends", "as", "break", "continue",
            "async", "await", "int", "str", "bool", "list", "dict", "float",
        ]
        
        for kw in keywords:
            completions.append({
                "label": kw,
                "kind": 14,
                "insertText": kw,
            })
        
        for sym in symbols:
            completions.append({
                "label": sym,
                "kind": 6 if symbols[sym]["type"] == "function" else 5,
                "insertText": sym,
            })
        
        return {"isIncomplete": False, "items": completions}

    def _definition(self, params: dict) -> dict:
        """Handle textDocument/definition - Go to Definition."""
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        position = params.get("position", {})
        line = position.get("line", 0)
        character = position.get("character", 0)

        text = self.documents.get(uri, "")
        word = self._get_word_at(text, line, character)

        if not word:
            return []

        # Ensure symbol table is up to date
        if uri not in self.symbol_tables:
            self._update_symbol_table(uri)

        sym_table = self.symbol_tables.get(uri, SymbolTable())

        # Look for the symbol definition
        if word in sym_table.definitions:
            info = sym_table.definitions[word]
            # LSP uses 0-indexed lines, our internal storage uses 1-indexed
            return {
                "uri": info.uri,
                "range": {
                    "start": {"line": info.line - 1, "character": info.column},
                    "end": {"line": info.line - 1, "character": info.column + len(info.name)},
                }
            }

        return []

    def _references(self, params: dict) -> dict:
        """Handle textDocument/references - Find References."""
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        position = params.get("position", {})
        line = position.get("line", 0)
        character = position.get("character", 0)

        text = self.documents.get(uri, "")
        word = self._get_word_at(text, line, character)

        if not word:
            return []

        # Ensure symbol table is up to date
        if uri not in self.symbol_tables:
            self._update_symbol_table(uri)

        sym_table = self.symbol_tables.get(uri, SymbolTable())

        locations = []

        # Check if this is a known symbol
        if word in sym_table.definitions or word in sym_table.references:
            # Add definition location
            if word in sym_table.definitions:
                info = sym_table.definitions[word]
                locations.append({
                    "uri": info.uri,
                    "range": {
                        "start": {"line": info.line - 1, "character": info.column},
                        "end": {"line": info.line - 1, "character": info.column + len(info.name)},
                    }
                })

            # Add all reference locations
            if word in sym_table.references:
                for ref_line, ref_col in sym_table.references[word]:
                    # Skip if this is the same as definition (line 0-indexed check)
                    is_def = False
                    if word in sym_table.definitions:
                        def_info = sym_table.definitions[word]
                        if ref_line == def_info.line and ref_col == def_info.column:
                            is_def = True

                    if not is_def:
                        locations.append({
                            "uri": uri,
                            "range": {
                                "start": {"line": ref_line - 1, "character": ref_col},
                                "end": {"line": ref_line - 1, "character": ref_col + len(word)},
                            }
                        })

        return locations

    def _did_open(self, params: dict) -> dict:
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        text = text_doc.get("text", "")
        self.documents[uri] = text
        self._update_symbol_table(uri)
        return self._publish_diagnostics(uri, text)

    def _did_change(self, params: dict) -> dict:
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        changes = params.get("contentChanges", [])
        if changes:
            text = changes[-1].get("text", "")
            self.documents[uri] = text
            self._update_symbol_table(uri)
        return self._publish_diagnostics(uri, self.documents.get(uri, ""))

    def _did_save(self, params: dict) -> dict:
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        return self._publish_diagnostics(uri, self.documents.get(uri, ""))

    def _did_close(self, params: dict) -> dict:
        text_doc = params.get("textDocument", {})
        uri = text_doc.get("uri", "")
        self.documents.pop(uri, None)
        self.symbol_tables.pop(uri, None)
        return {}
    
    def _publish_diagnostics(self, uri: str, text: str) -> dict:
        from .parser import Parser, ParseError
        diagnostics = []

        try:
            tokens = Lexer(text).tokenize()
        except LexError as e:
            msg = str(e)
            line_num = 0
            if "line" in msg:
                try:
                    line_num = max(0, int(msg.split("line")[-1].strip().split()[0]) - 1)
                except (ValueError, IndexError):
                    line_num = 0
            diagnostics.append({
                "severity": 1,
                "range": {
                    "start": {"line": line_num, "character": 0},
                    "end":   {"line": line_num, "character": 80},
                },
                "message": msg,
                "source": "mo",
            })
            return {"diagnostics": diagnostics, "uri": uri}

        try:
            Parser(tokens).parse()
        except ParseError as e:
            msg = str(e)
            line_num = 0
            if "line" in msg:
                try:
                    line_num = max(0, int(msg.split("line")[-1].strip().split()[0]) - 1)
                except (ValueError, IndexError):
                    line_num = 0
            diagnostics.append({
                "severity": 1,
                "range": {
                    "start": {"line": line_num, "character": 0},
                    "end":   {"line": line_num, "character": 80},
                },
                "message": msg,
                "source": "mo",
            })

        return {"diagnostics": diagnostics, "uri": uri}
    
    def run_stdio(self):
        while True:
            try:
                line = sys.stdin.readline()
                if not line:
                    break
                request = json.loads(line)
                
                method = request.get("method", "")
                params = request.get("params")
                msg_id = request.get("id")
                
                result = self.handle_request(method, params)
                
                response = {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": result,
                }
                print(json.dumps(response), flush=True)
            except Exception as e:
                response = {
                    "jsonrpc": "2.0",
                    "error": {"code": -32603, "message": str(e)},
                }
                print(json.dumps(response), flush=True)
    
    def run_tcp(self, port: int = 8765):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("", port))
        server.listen(1)
        print(f"Mo LSP server listening on port {port}", file=sys.stderr)
        
        while True:
            conn, addr = server.accept()
            print(f"Client connected from {addr}", file=sys.stderr)
            
            def handle_connection():
                buffer = b""
                try:
                    while True:
                        data = conn.recv(4096)
                        if not data:
                            break
                        buffer += data
                        while buffer:
                            try:
                                request = json.loads(buffer.decode())
                                buffer = b""
                                break
                            except json.JSONDecodeError:
                                if len(buffer) > 64000:
                                    break
                                data = conn.recv(4096)
                                if not data:
                                    break
                                buffer += data
                            
                            method = request.get("method", "")
                            params = request.get("params")
                            msg_id = request.get("id")
                            
                            result = self.handle_request(method, params)
                            
                            response = {
                                "jsonrpc": "2.0",
                                "id": msg_id,
                                "result": result,
                            }
                            conn.sendall((json.dumps(response) + "\n").encode())
                except Exception as e:
                    print(f"Error: {e}", file=sys.stderr)
                finally:
                    conn.close()
            
            thread = threading.Thread(target=handle_connection)
            thread.start()


def start_lsp_server(mode: str = "stdio", port: int = 8765):
    server = MoLanguageServer()
    if mode == "tcp":
        server.run_tcp(port)
    else:
        server.run_stdio()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Mo Language Server")
    parser.add_argument("--stdio", action="store_true", help="Use stdin/stdout")
    parser.add_argument("--tcp", action="store_true", help="Use TCP")
    parser.add_argument("--port", type=int, default=8765, help="TCP port")
    args = parser.parse_args()
    
    mode = "tcp" if args.tcp else "stdio"
    start_lsp_server(mode, args.port)