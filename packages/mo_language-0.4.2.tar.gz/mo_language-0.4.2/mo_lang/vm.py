"""
vm.py — stack-based virtual machine for Mo bytecode.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import asyncio
from .compiler import Op, CompiledFn
from .jit import JitVM, JIT_COMPILE_THRESHOLD
from .interpreter import (
    Environment, Function, Klass, Instance, BoundSuper, AsyncFunction, Iterator,
    RuntimeError_, Interpreter,
)


class MoThrow(Exception):
    def __init__(self, value):
        self.value = value


class AsyncReturnSignal(Exception):
    def __init__(self, value):
        self.value = value


class VMFunction:
    def __init__(self, name: str, params: list[str], code: list, closure: Environment,
                 variadic: tuple[str | None, str | None] = (None, None), defaults: list = None):
        self.name     = name
        self.params   = params
        self.code     = code
        self.closure  = closure
        self.variadic = variadic   # (*args_name, **kwargs_name)
        self.defaults = defaults   # parallel to params: None or list[Instr]

    def __repr__(self):
        param_strs = list(self.params)
        args_name, kwargs_name = self.variadic
        if args_name:
            param_strs.append(f"*{args_name}")
        if kwargs_name:
            param_strs.append(f"**{kwargs_name}")
        return f"<fn {self.name}({', '.join(param_strs)})>"


class VMAsyncFunction:
    def __init__(self, name: str, params: list[str], code: list, closure: Environment, variadic: tuple[str | None, str | None] = (None, None)):
        self.name    = name
        self.params  = params
        self.code    = code
        self.closure = closure
        self.variadic = variadic  # (*args_name, **kwargs_name)

    def __repr__(self):
        param_strs = list(self.params)
        args_name, kwargs_name = self.variadic
        if args_name:
            param_strs.append(f"*{args_name}")
        if kwargs_name:
            param_strs.append(f"**{kwargs_name}")
        return f"<async fn {self.name}({', '.join(param_strs)})>"


@dataclass
class Frame:
    code:      list
    ip:        int              = 0
    env:       Environment      = field(default_factory=Environment)
    stack:     list             = field(default_factory=list)
    try_stack: list             = field(default_factory=list)
    retval:    object           = None


class VM:
    def __init__(self, trace: bool = False, use_jit: bool = False):
        self._interp = Interpreter()
        self._interp._vm = self
        self.globals = self._interp.globals
        self._base_dir = '.'
        self._current_line = 0
        self._trace = trace
        self._frames = []
        self._jit_vm = JitVM(use_jit=use_jit) if use_jit else None
        self._hot_functions: dict = {}

    def run(self, code: list, env: Environment = None) -> None:
        if env is None:
            env = Environment(parent=self.globals)
        frame = Frame(code=code, env=env)
        self._frames.append(frame)
        try:
            self._run_frame(frame)
        finally:
            self._frames.pop()

    def _run_frame(self, frame: Frame) -> object:
        code  = frame.code
        stack = frame.stack
        env   = frame.env

        while frame.ip < len(code):
            instr = code[frame.ip]
            if self._trace:
                import sys
                print(f"  {frame.ip:4d}  {instr!r:<30s}  stack={[repr(s)[:20] for s in stack]}", file=sys.stderr)
            frame.ip += 1
            try:
                done = self._exec(instr, frame, stack, env)
                if done:
                    return frame.retval
            except (MoThrow, RuntimeError_) as exc:
                if frame.try_stack:
                    catch_ip, err_var, depth = frame.try_stack.pop()
                    while len(stack) > depth:
                        stack.pop()
                    err_val = exc.value if isinstance(exc, MoThrow) else str(exc)
                    env.define(err_var, err_val)
                    frame.ip = catch_ip
                else:
                    raise

        return frame.retval

    def _exec(self, instr, frame: Frame, stack: list, env: Environment) -> bool:
        op, arg = instr.op, instr.arg

        if op is Op.LINE:
            self._current_line = arg
            return False

        if op is Op.LOAD_CONST:
            stack.append(arg)

        elif op is Op.LOAD_NAME:
            stack.append(env.get(arg))

        elif op is Op.DEFINE_NAME:
            env.define(arg, stack.pop())

        elif op is Op.STORE_NAME:
            env.set(arg, stack.pop())

        elif op is Op.POP:
            stack.pop()

        elif op is Op.DUP:
            stack.append(stack[-1])

        elif op is Op.BINARY_OP:
            right = stack.pop()
            left  = stack.pop()
            stack.append(self._interp._binop(arg, left, right))

        elif op is Op.UNARY_OP:
            val = stack.pop()
            if arg == '-':
                stack.append(-val)
            else:
                stack.append(not self._interp._truthy(val))

        elif op is Op.JUMP:
            frame.ip = arg

        elif op is Op.JUMP_IF_FALSE:
            if not self._interp._truthy(stack.pop()):
                frame.ip = arg

        elif op is Op.CALL:
            argc = arg
            args = list(reversed([stack.pop() for _ in range(argc)]))
            fn   = stack.pop()
            stack.append(self._call(fn, args, env))

        elif op is Op.RETURN:
            frame.retval = stack.pop()
            return True

        elif op is Op.MAKE_LIST:
            items = list(reversed([stack.pop() for _ in range(arg)]))
            stack.append(items)

        elif op is Op.MAKE_DICT:
            pairs = []
            for _ in range(arg):
                v = stack.pop()
                k = stack.pop()
                pairs.append((k, v))
            pairs.reverse()
            stack.append(dict(pairs))

        elif op is Op.INDEX_GET:
            idx = stack.pop()
            obj = stack.pop()
            stack.append(self._interp._index_get(obj, idx))

        elif op is Op.INDEX_SET:
            val = stack.pop()
            idx = stack.pop()
            obj = stack.pop()
            self._interp._index_set(obj, idx, val)
            stack.append(val)

        elif op is Op.GET_ATTR:
            obj = stack.pop()
            stack.append(self._get_attr(obj, arg))

        elif op is Op.SET_ATTR:
            val = stack.pop()
            obj = stack.pop()
            if not isinstance(obj, Instance):
                raise RuntimeError_("Can only set attributes on class instances")
            obj.fields[arg] = val
            stack.append(val)

        elif op is Op.METHOD_CALL:
            method, argc = arg
            args = list(reversed([stack.pop() for _ in range(argc)]))
            obj  = stack.pop()
            stack.append(self._call_method(obj, method, args))

        elif op is Op.MAKE_FUNCTION:
            cfn: CompiledFn = arg
            stack.append(VMFunction(cfn.name, cfn.params, cfn.code, env, cfn.variadic, cfn.defaults))

        elif op is Op.MAKE_ASYNC_FUNCTION:
            cfn: CompiledFn = arg
            stack.append(VMAsyncFunction(cfn.name, cfn.params, cfn.code, env, cfn.variadic))

        elif op is Op.AWAIT:
            aw = stack.pop()
            result = self._await_value(aw)
            stack.append(result)

        elif op is Op.ASYNC_RETURN:
            value = stack.pop() if stack else None
            raise AsyncReturnSignal(value)

        elif op is Op.MAKE_CLASS:
            name, parent_name, method_cfns = arg
            methods = {
                mname: VMFunction(cfn.name, cfn.params, cfn.code, env, cfn.variadic, cfn.defaults)
                for mname, cfn in method_cfns.items()
            }
            parent = None
            if parent_name:
                parent = env.get(parent_name)
                if not isinstance(parent, Klass):
                    raise RuntimeError_(f"'{parent_name}' is not a class")
            stack.append(Klass(name, methods, parent))

        elif op is Op.THROW:
            raise MoThrow(stack.pop())

        elif op is Op.SETUP_TRY:
            catch_ip, err_var = arg
            frame.try_stack.append((catch_ip, err_var, len(stack)))

        elif op is Op.END_TRY:
            frame.try_stack.pop()

        elif op is Op.IMPORT:
            self._import(arg, env)
            return False

        elif op is Op.MAKE_ITER:
            lst = stack.pop()
            if isinstance(lst, list):
                stack.append(iter(lst))
            elif isinstance(lst, dict):
                stack.append(iter(lst.keys()))
            elif isinstance(lst, str):
                stack.append(iter(lst))
            elif isinstance(lst, Iterator):
                # Iterator objects are already iterators
                stack.append(lst)
            else:
                raise RuntimeError_("'for' requires a list, dict, string, or iterator")

        elif op is Op.FOR_ITER:
            it = stack[-1]
            # Support both Python iterators and custom Iterator class
            if isinstance(it, Iterator):
                if it.has_next():
                    stack.append(it.next())
                else:
                    stack.pop()
                    frame.ip = arg
            else:
                try:
                    stack.append(next(it))
                except StopIteration:
                    stack.pop()
                    frame.ip = arg

        elif op is Op.MATCH_START:
            # Value is already on stack from previous expression
            pass  # Just a marker opcode

        elif op is Op.MATCH_END:
            # Clean up match value if still on stack
            if stack:
                stack.pop()

        elif op is Op.MATCH_CASE:
            # Pattern matching is handled by compiled code sequence
            # This opcode is primarily for debugging/marker purposes
            pass

        elif op is Op.MATCH_BIND:
            # Bind top of stack to variable name
            var_name = arg
            value = stack[-1]  # Keep value on stack
            env.define(var_name, value)

        elif op is Op.DESTRUCTURE_LIST:
            # Pop list from stack, define each element to corresponding variable
            value = stack.pop()
            if not isinstance(value, list):
                raise RuntimeError_(f"Cannot destructure list pattern from {type(value).__name__}")
            var_names = arg
            if len(var_names) != len(value):
                raise RuntimeError_(f"List destructuring pattern has {len(var_names)} elements but value has {len(value)}")
            for var_name, val in zip(var_names, value):
                env.define(var_name, val)

        elif op is Op.DESTRUCTURE_DICT:
            # Pop dict from stack, define each key's value to corresponding variable
            value = stack.pop()
            if not isinstance(value, dict):
                raise RuntimeError_(f"Cannot destructure dict pattern from {type(value).__name__}")
            pairs = arg  # list of (key, var_name)
            for key, var_name in pairs:
                if key not in value:
                    raise RuntimeError_(f"Key '{key}' not found in dict for destructuring")
                env.define(var_name, value[key])

        return False

    def _call(self, fn, args: list, env: Environment):
        if isinstance(fn, VMAsyncFunction):
            return self._invoke_async_vm(fn, args)
        if isinstance(fn, VMFunction):
            return self._invoke_vm(fn, None, args)
        if isinstance(fn, Klass):
            return self._instantiate(fn, args)
        if isinstance(fn, AsyncFunction):
            return self._interp._call_async_fn(fn, args)
        if isinstance(fn, Function):
            return self._interp._call(fn, args)
        if callable(fn):
            return fn(args)
        raise RuntimeError_(f"{fn!r} is not callable")

    def _invoke_async_vm(self, fn, args: list, kwargs: dict = None):
        """Invoke an async VM function (runs synchronously with await support)."""
        if kwargs is None:
            kwargs = {}
        call_env = Environment(parent=fn.closure)
        self._bind_params(fn, args, kwargs, call_env)
        try:
            self._exec_code(fn.code, call_env)
        except AsyncReturnSignal as r:
            return r.value
        return None

    def _exec_code(self, code: list, env: Environment):
        """Execute bytecode synchronously in a new frame."""
        frame = Frame(code, env=env)
        self._frames.append(frame)
        try:
            self._run_frame(frame)
        finally:
            self._frames.pop()

    def _await_value(self, aw):
        """Run an awaitable synchronously, regardless of whether a loop is running."""
        if not (asyncio.iscoroutine(aw) or asyncio.isfuture(aw)):
            return aw.__await__() if hasattr(aw, '__await__') else aw
        try:
            asyncio.get_running_loop()
            # Inside a running event loop — dispatch to a worker thread with its own loop
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(asyncio.run, aw).result()
        except RuntimeError:
            # No running loop — safe to use asyncio.run()
            return asyncio.run(aw)

    def _instantiate(self, klass: Klass, args: list):
        instance = Instance(klass)
        init = self._interp._lookup_method(klass, "init")
        if init:
            self._invoke_callable(init, args, instance=instance)
        return instance

    def _call_method(self, obj, method: str, args: list):
        if isinstance(obj, (str, list)):
            return self._interp._call_method(obj, method, args)
        if isinstance(obj, Instance):
            fn = self._interp._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"'{obj.klass.name}' has no method '{method}'")
            return self._invoke_callable(fn, args, instance=obj)
        if isinstance(obj, BoundSuper):
            fn = self._interp._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"super has no method '{method}'")
            return self._invoke_callable(fn, args, instance=obj.instance,
                                         super_klass=obj.klass.parent)
        if isinstance(obj, dict):
            fn = obj.get(method)
            if fn is None:
                raise RuntimeError_(f"Module has no function '{method}'")
            return self._call(fn, args, None)
        raise RuntimeError_(
            f"Cannot call method on {self._interp._builtin_type([obj])}"
        )

    def _get_attr(self, obj, attr: str):
        if isinstance(obj, Instance):
            if attr in obj.fields:
                return obj.fields[attr]
            fn = self._interp._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"'{obj.klass.name}' has no attribute '{attr}'")
        if isinstance(obj, BoundSuper):
            fn = self._interp._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"super has no attribute '{attr}'")
        if isinstance(obj, str):
            return self._interp._str_method(obj, attr)
        if isinstance(obj, dict):
            if attr in obj:
                return obj[attr]
            raise RuntimeError_(f"Key '{attr}' not found in dict")
        raise RuntimeError_(
            f"Cannot get attribute '{attr}' on {self._interp._builtin_type([obj])}"
        )

    def _invoke_callable(self, fn, args: list, instance=None, super_klass=None):
        if isinstance(fn, VMFunction):
            return self._invoke_vm(fn, instance, args, super_klass)
        if isinstance(fn, Function):
            if instance is not None:
                return self._interp._invoke_method(fn, instance, args, super_klass)
            return self._interp._call(fn, args)
        if callable(fn):
            return fn(args)
        raise RuntimeError_(f"{fn!r} is not callable")

    def _invoke_vm(self, fn: VMFunction, instance, args: list, super_klass=None, kwargs: dict = None):
        if kwargs is None:
            kwargs = {}

        jit_code = None
        if self._jit_vm:
            self._jit_vm.record_call(fn.name)
            if self._jit_vm.should_compile(fn.name):
                jit_code = self._jit_vm.compile_function(
                    fn.name, fn.params, fn.code, fn.closure
                )
                if jit_code:
                    self._hot_functions[fn.name] = -1
                    return self._invoke_jit(fn, instance, args, super_klass, jit_code)

        self._hot_functions[fn.name] = self._hot_functions.get(fn.name, 0) + 1

        call_env = Environment(parent=fn.closure)
        if instance is not None:
            call_env.define("self", instance)
            if super_klass is not None:
                call_env.define("super", BoundSuper(super_klass, instance))
            elif isinstance(instance, Instance) and instance.klass.parent:
                call_env.define("super", BoundSuper(instance.klass.parent, instance))

        # Bind parameters (including variadic)
        self._bind_params(fn, args, kwargs, call_env)

        frame = Frame(code=fn.code, env=call_env)
        return self._run_frame(frame)

    def _bind_params(self, fn, args: list, kwargs: dict, call_env: Environment):
        """Bind parameters to the function environment, handling variadic args and defaults."""
        args_name, kwargs_name = fn.variadic
        params   = fn.params
        defaults = fn.defaults if fn.defaults is not None else []
        num_params = len(params)
        num_args   = len(args)

        # Count params that have no default (required)
        required_count = sum(
            1 for i, p in enumerate(params)
            if i >= len(defaults) or defaults[i] is None
        )

        if args_name:
            regular_args_count = min(num_args, num_params)
        else:
            if num_args > num_params:
                raise RuntimeError_(f"{fn.name}() takes {num_params} args, got {num_args}")
            if num_args < required_count:
                raise RuntimeError_(f"{fn.name}() requires {required_count} args, got {num_args}")
            regular_args_count = num_args

        # Bind provided positional args
        for i in range(regular_args_count):
            call_env.define(params[i], args[i])

        # Apply defaults for remaining params
        for i in range(regular_args_count, num_params):
            if i < len(defaults) and defaults[i] is not None:
                default_frame = Frame(code=defaults[i], env=call_env)
                call_env.define(params[i], self._run_frame(default_frame))
            elif not args_name:
                raise RuntimeError_(f"{fn.name}() missing argument '{params[i]}'")

        if args_name:
            call_env.define(args_name, args[regular_args_count:])

        if kwargs_name:
            call_env.define(kwargs_name, kwargs)
        elif kwargs:
            raise RuntimeError_(f"{fn.name}() does not accept keyword arguments")

    def _invoke_jit(self, fn: VMFunction, instance, args: list, super_klass, jit_code):
        call_env = fn.closure.vars.copy()
        if instance is not None:
            call_env["self"] = instance
        param_dict = dict(zip(fn.params, args))
        call_env.update(param_dict)
        
        try:
            return jit_code(**call_env)
        except Exception as e:
            raise RuntimeError_(f"JIT execution error in {fn.name}: {e}")

    def _import(self, path_alias, env: Environment):
        import os
        from .lexer import Lexer, LexError
        from .parser import Parser, ParseError
        from .compiler import Compiler
        path, alias = path_alias if isinstance(path_alias, tuple) else (path_alias, None)
        mo_path = path if path.endswith('.mo') else path + '.mo'
        full = os.path.join(self._base_dir, mo_path)
        if not os.path.exists(full):
            pkg_fallback = os.path.join(os.path.dirname(__file__), mo_path)
            if os.path.exists(pkg_fallback):
                full = pkg_fallback
            else:
                user_pkg = os.path.join(os.path.expanduser("~/.mo/packages"), mo_path)
                if os.path.exists(user_pkg):
                    full = user_pkg
                else:
                    raise RuntimeError_(f"Cannot find module '{path}'")
        source = open(full).read()
        try:
            tokens = Lexer(source).tokenize()
            ast    = Parser(tokens).parse()
            code   = Compiler().compile(ast)
        except Exception as e:
            raise RuntimeError_(f"Error in module '{path}': {e}")
        mod_env = Environment(parent=self.globals)
        mod_frame = Frame(code=code, env=mod_env)
        self._run_frame(mod_frame)
        if alias:
            mod_name = path.split('/')[-1]
            prefix   = mod_name + "_"
            ns = {}
            for name, val in mod_env.vars.items():
                short = name[len(prefix):] if name.startswith(prefix) else name
                ns[short] = val
            env.define(alias, ns)
        else:
            for name, val in mod_env.vars.items():
                env.define(name, val)
