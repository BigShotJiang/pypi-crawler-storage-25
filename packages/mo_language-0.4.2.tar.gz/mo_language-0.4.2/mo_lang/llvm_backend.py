"""
llvm_backend.py — LLVM IR generator and JIT compiler for Mo language.

This module compiles Mo AST directly to LLVM IR and executes it using LLVM JIT.
"""
from __future__ import annotations
import ctypes
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

from llvmlite import ir, binding

from .ast_nodes import *
from .compiler import Op, Instr


# Initialize LLVM
binding.initialize()
binding.initialize_native_target()
binding.initialize_native_asmprinter()


class LLVMType:
    """Type definitions for Mo values in LLVM."""
    # Mo is dynamically typed, so we use a tagged union representation
    # struct MoValue {
    #     int8 type;      // 0=null, 1=number, 2=bool, 3=string, 4=list, 5=dict
    #     double num;     // for numbers
    #     int8* str;      // for strings
    #     void* ptr;      // for lists/dicts
    # }
    
    def __init__(self, module: ir.Module):
        self.type_tag = ir.IntType(8)
        self.double = ir.DoubleType()
        self.int32 = ir.IntType(32)
        self.int64 = ir.IntType(64)
        self.int8 = ir.IntType(8)
        self.int8_ptr = ir.PointerType(self.int8)
        self.void_ptr = ir.PointerType(ir.IntType(8))
        self.void = ir.VoidType()
        
        # Define MoValue struct
        self.value_struct = ir.LiteralStructType([
            self.type_tag,   # type tag
            self.double,     # numeric value
            self.int8_ptr,   # string pointer
            self.void_ptr,   # object pointer
        ])
        self.value_ptr = ir.PointerType(self.value_struct)
        
        # Define function types
        self.print_fn_type = ir.FunctionType(self.void, [self.value_ptr])
        self.alloc_fn_type = ir.FunctionType(self.value_ptr, [self.int8])
        self.num_fn_type = ir.FunctionType(self.value_ptr, [self.double])
        self.str_fn_type = ir.FunctionType(self.value_ptr, [self.int8_ptr])


class LLVMCompiler:
    """Compiles Mo bytecode to LLVM IR."""
    
    def __init__(self):
        self.module = ir.Module(name="mo_program")
        self.types = LLVMType(self.module)
        self.builder: Optional[ir.IRBuilder] = None
        self.function: Optional[ir.Function] = None
        
        # Variable mapping: name -> alloca pointer
        self.variables: Dict[str, ir.AllocaInstr] = {}
        
        # Current block for insertion
        self.blocks: List[ir.Block] = []
        
        # Declare external functions
        self._declare_externals()
    
    def _declare_externals(self):
        """Declare external runtime functions."""
        # mo_print(MoValue*)
        ir.Function(self.module, self.types.print_fn_type, name="mo_print")
        
        # mo_alloc(int8 type) -> MoValue*
        ir.Function(self.module, self.types.alloc_fn_type, name="mo_alloc")
        
        # mo_number(double) -> MoValue*
        ir.Function(self.module, self.types.num_fn_type, name="mo_number")
        
        # mo_string(int8*) -> MoValue*
        ir.Function(self.module, self.types.str_fn_type, name="mo_string")
        
        # mo_add(MoValue*, MoValue*) -> MoValue*
        add_type = ir.FunctionType(self.types.value_ptr, 
                                   [self.types.value_ptr, self.types.value_ptr])
        ir.Function(self.module, add_type, name="mo_add")
        
        # mo_sub, mo_mul, mo_div
        ir.Function(self.module, add_type, name="mo_sub")
        ir.Function(self.module, add_type, name="mo_mul")
        ir.Function(self.module, add_type, name="mo_div")
        
        # mo_cmp_eq, mo_cmp_lt, etc.
        ir.Function(self.module, add_type, name="mo_cmp_eq")
        ir.Function(self.module, add_type, name="mo_cmp_lt")
        ir.Function(self.module, add_type, name="mo_cmp_gt")
    
    def compile_function(self, name: str, params: List[str], 
                         code: List[Instr]) -> ir.Function:
        """Compile a Mo function to LLVM IR."""
        # Create function type: returns MoValue*, takes MoValue** args
        param_types = [self.types.value_ptr] * len(params)
        func_type = ir.FunctionType(self.types.value_ptr, param_types)
        func = ir.Function(self.module, func_type, name=name)
        
        # Create entry block
        block = func.append_basic_block(name="entry")
        self.builder = ir.IRBuilder(block)
        self.function = func
        self.variables = {}
        
        # Allocate storage for parameters
        for i, param in enumerate(params):
            alloca = self.builder.alloca(self.types.value_ptr, name=f"var_{param}")
            self.builder.store(func.args[i], alloca)
            self.variables[param] = alloca
        
        # Compile bytecode instructions
        self._compile_bytecode(code)
        
        # Return null if no explicit return
        if not self.builder.block.is_terminated:
            null_val = self._create_null()
            self.builder.ret(null_val)
        
        return func
    
    def _compile_bytecode(self, code: List[Instr]):
        """Compile Mo bytecode to LLVM IR."""
        for instr in code:
            op = instr.op
            arg = instr.arg
            
            if op is Op.LOAD_CONST:
                val = self._create_value(arg)
                # Push to stack (using alloca for simplicity)
                stack_slot = self.builder.alloca(self.types.value_ptr)
                self.builder.store(val, stack_slot)
                
            elif op is Op.LOAD_NAME:
                if arg in self.variables:
                    ptr = self.variables[arg]
                    val = self.builder.load(ptr, name=f"load_{arg}")
                    stack_slot = self.builder.alloca(self.types.value_ptr)
                    self.builder.store(val, stack_slot)
                else:
                    # Undefined variable - load null
                    null_val = self._create_null()
                    stack_slot = self.builder.alloca(self.types.value_ptr)
                    self.builder.store(null_val, stack_slot)
            
            elif op is Op.STORE_NAME:
                # Pop from stack and store
                if arg not in self.variables:
                    self.variables[arg] = self.builder.alloca(
                        self.types.value_ptr, name=f"var_{arg}"
                    )
                # TODO: actually pop from stack
                
            elif op is Op.BINARY_OP:
                # Pop two operands, apply operation, push result
                if arg == "+":
                    self._emit_binary_call("mo_add")
                elif arg == "-":
                    self._emit_binary_call("mo_sub")
                elif arg == "*":
                    self._emit_binary_call("mo_mul")
                elif arg == "/":
                    self._emit_binary_call("mo_div")
                    
            elif op is Op.CALL:
                # Call function
                self._emit_call(arg)
                
            elif op is Op.RETURN:
                # Return value from stack
                ret_val = self._create_null()  # TODO: pop from stack
                self.builder.ret(ret_val)
    
    def _create_value(self, value: Any) -> ir.Value:
        """Create an LLVM value for a Mo constant."""
        if value is None:
            return self._create_null()
        elif isinstance(value, (int, float)):
            return self._create_number(float(value))
        elif isinstance(value, str):
            return self._create_string(value)
        elif isinstance(value, bool):
            return self._create_bool(value)
        else:
            return self._create_null()
    
    def _create_null(self) -> ir.Value:
        """Create a null Mo value."""
        mo_alloc = self.module.get_global("mo_alloc")
        type_null = ir.Constant(self.types.type_tag, 0)
        return self.builder.call(mo_alloc, [type_null])
    
    def _create_number(self, n: float) -> ir.Value:
        """Create a numeric Mo value."""
        mo_number = self.module.get_global("mo_number")
        num_const = ir.Constant(self.types.double, n)
        return self.builder.call(mo_number, [num_const])
    
    def _create_string(self, s: str) -> ir.Value:
        """Create a string Mo value."""
        # Create global string constant
        str_const = ir.Constant(ir.ArrayType(self.types.int8, len(s) + 1), 
                                bytearray(s.encode('utf8')) + b'\0')
        global_str = ir.GlobalVariable(self.module, str_const.type, 
                                       name=f"str_{len(self.module.global_values)}")
        global_str.global_constant = True
        global_str.initializer = str_const
        
        # Get pointer to string
        str_ptr = self.builder.bitcast(global_str, self.types.int8_ptr)
        
        # Call mo_string
        mo_string = self.module.get_global("mo_string")
        return self.builder.call(mo_string, [str_ptr])
    
    def _create_bool(self, b: bool) -> ir.Value:
        """Create a boolean Mo value."""
        mo_alloc = self.module.get_global("mo_alloc")
        type_bool = ir.Constant(self.types.type_tag, 2 if b else 1)
        return self.builder.call(mo_alloc, [type_bool])
    
    def _emit_binary_call(self, fn_name: str):
        """Emit a binary operation call."""
        fn = self.module.get_global(fn_name)
        # TODO: pop two values from stack
        left = self._create_number(0.0)
        right = self._create_number(0.0)
        result = self.builder.call(fn, [left, right])
        # TODO: push result to stack
    
    def _emit_call(self, argc: int):
        """Emit a function call."""
        # TODO: pop function and arguments from stack
        pass
    
    def get_ir(self) -> str:
        """Get the generated LLVM IR as string."""
        return str(self.module)


class LLVMJIT:
    """LLVM JIT execution engine for Mo."""
    
    def __init__(self):
        self.target = binding.Target.from_default_triple()
        self.target_machine = self.target.create_target_machine()
        self.engine = None
        self.compiler = LLVMCompiler()
    
    def compile_module(self, code: List[Instr]) -> str:
        """Compile Mo bytecode to LLVM IR."""
        # Compile main function
        self.compiler.compile_function("main", [], code)
        
        # Get IR
        ir_code = self.compiler.get_ir()
        return ir_code
    
    def execute(self, ir_code: str) -> Any:
        """Execute LLVM IR using JIT."""
        # Parse IR
        llvm_module = binding.parse_assembly(ir_code)
        llvm_module.verify()
        
        # Create execution engine
        if self.engine is None:
            self.engine = binding.create_mcjit_compiler(llvm_module, self.target_machine)
        else:
            # Add module to existing engine
            self.engine.add_module(llvm_module)
        
        # Finalize and get function pointer
        self.engine.finalize_object()
        
        # Get main function
        func_ptr = self.engine.get_function_address("main")
        
        # Create ctypes function signature
        cfunc = ctypes.CFUNCTYPE(ctypes.c_void_p)(func_ptr)
        
        # Call function
        result = cfunc()
        
        return result
    
    def compile_and_run(self, code: List[Instr]) -> Any:
        """Compile and execute bytecode."""
        ir_code = self.compile_module(code)
        print("Generated LLVM IR:")
        print(ir_code[:2000])  # Print first 2000 chars
        print("...")
        # Note: Runtime functions need to be implemented in C
        # For now, just return the IR
        return ir_code


def compile_to_llvm(ast: List) -> str:
    """Compile Mo AST to LLVM IR."""
    from .compiler import Compiler
    
    # First compile to bytecode
    bytecode = Compiler().compile(ast)
    
    # Then compile to LLVM
    jit = LLVMJIT()
    ir_code = jit.compile_module(bytecode)
    
    return ir_code
