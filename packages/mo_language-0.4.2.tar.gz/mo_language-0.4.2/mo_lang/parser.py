"""
Parser — turns a list of tokens into an AST.
"""
from __future__ import annotations
from .lexer import TT, Token, Lexer
from .ast_nodes import *


class ParseError(Exception):
    pass


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos    = 0

    # ── helpers ───────────────────────────────────────────────────────────────

    def _peek(self) -> Token:
        return self.tokens[self.pos]

    def _peek_type(self) -> TT:
        return self.tokens[self.pos].type

    def _advance(self) -> Token:
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def _check(self, *types: TT) -> bool:
        return self._peek_type() in types

    def _match(self, *types: TT) -> Token | None:
        if self._check(*types):
            return self._advance()
        return None

    def _expect(self, tt: TT) -> Token:
        if self._peek_type() == tt:
            return self._advance()
        tok = self._peek()
        raise ParseError(f"Expected {tt.name}, got {tok.type.name} {tok.value!r} at line {tok.line}")

    def _skip_newlines(self):
        while self._check(TT.NEWLINE):
            self._advance()

    # ── program ───────────────────────────────────────────────────────────────

    def parse(self) -> list:
        stmts = []
        self._skip_newlines()
        while not self._check(TT.EOF):
            stmts.append(self._stmt())
            self._skip_newlines()
        return stmts

    # ── statements ────────────────────────────────────────────────────────────

    def _stmt(self):
        line = self._peek().line
        tt = self._peek_type()
        if tt == TT.LET:      node = self._let_stmt()
        elif tt == TT.IF:     node = self._if_stmt()
        elif tt == TT.WHILE:  node = self._while_stmt()
        elif tt == TT.FOR:    node = self._for_stmt()
        elif tt == TT.TRY:    node = self._try_stmt()
        elif tt == TT.THROW:  node = self._throw_stmt()
        elif tt == TT.IMPORT: node = self._import_stmt()
        elif tt == TT.CLASS:  node = self._class_def()
        elif tt == TT.FN:     node = self._fn_def()
        elif tt == TT.ASYNC:   node = self._async_fn_def()
        elif tt == TT.RETURN: node = self._return_stmt()
        elif tt == TT.MATCH:  node = self._match_stmt()
        elif tt == TT.MACRO:  node = self._macro_def()
        elif tt == TT.BREAK:
            self._advance()
            self._end_stmt()
            node = BreakStmt()
        elif tt == TT.CONTINUE:
            self._advance()
            self._end_stmt()
            node = ContinueStmt()
        elif tt == TT.IDENT:
            node = self._assign_or_expr_stmt()
        elif tt == TT.COMMENT:
            self._advance()
            self._skip_newlines()
            node = ExprStmt(Null())
        else:
            node = self._expr_stmt()
        node.line = line
        return node

    def _let_stmt(self):
        self._expect(TT.LET)

        # Check for destructuring patterns: let [a, b, c] = ... or let {"key": var} = ...
        if self._check(TT.LBRACKET):
            pattern = self._parse_list_pattern()
            self._expect(TT.ASSIGN)
            value = self._expr()
            self._end_stmt()
            return DestructureLet(pattern, value)

        if self._check(TT.LBRACE):
            pattern = self._parse_dict_pattern()
            self._expect(TT.ASSIGN)
            value = self._expr()
            self._end_stmt()
            return DestructureLet(pattern, value)

        # Regular let statement
        name = self._expect(TT.IDENT).value
        type_hint = None
        if self._check(TT.COLON):
            self._advance()
            type_hint = self._expect_type_keyword()
        self._expect(TT.ASSIGN)
        value = self._expr()
        if self._check(TT.COMMENT):
            comment = self._advance().value
            VALID_TYPES = {"int", "str", "bool", "list", "dict", "float"}
            if comment in VALID_TYPES:
                type_hint = comment
        self._end_stmt()
        return LetStmt(name, value, type_hint)

    def _parse_list_pattern(self) -> ListPattern:
        """Parse [a, b, c] pattern"""
        self._expect(TT.LBRACKET)
        elements = []
        if not self._check(TT.RBRACKET):
            elements.append(self._expect(TT.IDENT).value)
            while self._match(TT.COMMA):
                self._skip_newlines()
                if self._check(TT.RBRACKET):
                    break
                elements.append(self._expect(TT.IDENT).value)
        self._expect(TT.RBRACKET)
        return ListPattern(elements)

    def _parse_dict_pattern(self) -> DictPattern:
        """Parse {"key": var, ...} pattern"""
        self._expect(TT.LBRACE)
        pairs = []
        self._skip_newlines()
        while not self._check(TT.RBRACE, TT.EOF):
            key = self._expect(TT.STRING).value
            self._expect(TT.COLON)
            var_name = self._expect(TT.IDENT).value
            pairs.append((key, var_name))
            self._skip_newlines()
            if not self._check(TT.RBRACE):
                self._expect(TT.COMMA)
                self._skip_newlines()
        self._expect(TT.RBRACE)
        return DictPattern(pairs)

    def _expect_type_keyword(self) -> str:
        tt = self._peek_type()
        TYPE_MAP = {
            TT.TYPE_INT: "int",
            TT.TYPE_STR: "str",
            TT.TYPE_BOOL: "bool",
            TT.TYPE_LIST: "list",
            TT.TYPE_DICT: "dict",
            TT.TYPE_FLOAT: "float",
        }
        if tt in TYPE_MAP:
            return TYPE_MAP[self._advance().type]
        raise ParseError(f"Expected type keyword, got {tt.name} at line {self._peek().line}")

    def _assign_or_expr_stmt(self):
        """Parse an IDENT-starting statement: assignment (simple or complex lvalue) or expression."""
        expr = self._expr()
        if self._check(TT.ASSIGN):
            self._advance()
            value = self._expr()
            self._end_stmt()
            if isinstance(expr, Ident):
                return AssignStmt(expr.name, value)
            if isinstance(expr, IndexGet):
                return ExprStmt(IndexSet(expr.obj, expr.index, value))
            if isinstance(expr, GetAttr):
                return ExprStmt(SetAttr(expr.obj, expr.attr, value))
            raise ParseError(f"Invalid assignment target at line {self._peek().line}")
        self._end_stmt()
        return ExprStmt(expr)

    def _assign_stmt(self) -> AssignStmt:
        name = self._advance().value
        self._advance()
        value = self._expr()
        self._end_stmt()
        return AssignStmt(name, value)

    def _if_stmt(self) -> IfStmt:
        self._expect(TT.IF)
        condition = self._expr()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        then_body = self._block()
        else_body = []
        self._skip_newlines()
        if self._match(TT.ELSE):
            self._skip_newlines()
            if self._check(TT.IF):
                else_body = [self._if_stmt()]
            else:
                self._expect(TT.LBRACE)
                else_body = self._block()
        return IfStmt(condition, then_body, else_body)

    def _match_stmt(self) -> MatchStmt:
        self._expect(TT.MATCH)
        expr = self._expr()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        cases = []
        self._skip_newlines()
        while not self._check(TT.RBRACE, TT.EOF):
            if self._check(TT.CASE):
                cases.append(self._parse_case())
            self._skip_newlines()
        self._expect(TT.RBRACE)
        return MatchStmt(expr, cases)

    def _parse_case(self) -> Case:
        self._expect(TT.CASE)
        pattern = self._parse_pattern()
        self._expect(TT.ARROW)
        body = self._parse_case_body()
        return Case(pattern, body)

    def _parse_pattern(self):
        """Parse a pattern for match/case.

        Patterns can be:
        - Literals: numbers, strings, true, false, null
        - Wildcard: _
        - Variables: identifiers (for binding)
        - List patterns: [pattern1, pattern2, ...]
        - Dict patterns: {"key": pattern, ...}
        """
        tok = self._peek()

        # Literal patterns
        if tok.type == TT.NUMBER:
            self._advance()
            return Number(tok.value)

        if tok.type == TT.STRING:
            self._advance()
            return String(tok.value)

        if tok.type == TT.TRUE:
            self._advance()
            return Bool(True)

        if tok.type == TT.FALSE:
            self._advance()
            return Bool(False)

        if tok.type == TT.NULL:
            self._advance()
            return Null()

        # Wildcard or variable binding
        if tok.type == TT.IDENT:
            self._advance()
            return Ident(tok.value)

        # List pattern: [x, y, ...]
        if tok.type == TT.LBRACKET:
            self._advance()
            elements = []
            if not self._check(TT.RBRACKET):
                elements.append(self._parse_pattern())
                while self._match(TT.COMMA):
                    self._skip_newlines()
                    if self._check(TT.RBRACKET):
                        break
                    elements.append(self._parse_pattern())
            self._expect(TT.RBRACKET)
            return ListLiteral(elements)

        # Dict pattern: {"key": x, ...}
        if tok.type == TT.LBRACE:
            self._advance()
            pairs = []
            self._skip_newlines()
            while not self._check(TT.RBRACE, TT.EOF):
                # Key can be string literal or identifier (converted to string)
                if self._check(TT.STRING):
                    key = String(self._advance().value)
                elif self._check(TT.IDENT):
                    key = String(self._advance().value)
                else:
                    key = self._expr()
                self._expect(TT.COLON)
                val_pattern = self._parse_pattern()
                pairs.append((key, val_pattern))
                self._skip_newlines()
                if not self._check(TT.RBRACE):
                    self._expect(TT.COMMA)
                    self._skip_newlines()
            self._expect(TT.RBRACE)
            return DictLiteral(pairs)

        raise ParseError(f"Unexpected token in pattern: {tok.type.name} at line {tok.line}")

    def _parse_case_body(self) -> list:
        """Parse the body of a case statement.

        Can be:
        - A single expression or statement (no braces)
        - A block of statements { ... }
        """
        self._skip_newlines()

        # If it's a block
        if self._check(TT.LBRACE):
            self._advance()
            return self._block()

        # Single statement (could be return, throw, or expression)
        tt = self._peek_type()
        if tt == TT.RETURN:
            self._advance()
            value = None
            if not self._check(TT.NEWLINE, TT.EOF, TT.RBRACE):
                value = self._expr()
            self._end_stmt()
            return [ReturnStmt(value)]
        elif tt == TT.THROW:
            self._advance()
            value = self._expr()
            self._end_stmt()
            return [ThrowStmt(value)]
        else:
            # Single expression
            expr = self._expr()
            return [ExprStmt(expr)]

    def _while_stmt(self) -> WhileStmt:
        self._expect(TT.WHILE)
        condition = self._expr()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return WhileStmt(condition, body)

    def _fn_def(self) -> FnDef:
        self._expect(TT.FN)
        name = self._expect(TT.IDENT).value
        params, variadic = self._parse_params()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return FnDef(name, params, body, variadic=variadic)

    def _async_fn_def(self) -> AsyncFn:
        self._expect(TT.ASYNC)
        self._expect(TT.FN)
        name = self._expect(TT.IDENT).value
        params, variadic = self._parse_params()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return AsyncFn(name, params, body, variadic=variadic)

    def _macro_def(self) -> MacroDef:
        self._expect(TT.MACRO)
        name = self._expect(TT.IDENT).value
        params = self._parse_macro_params()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return MacroDef(name, params, body)

    def _parse_macro_params(self) -> list[str]:
        """Parse macro parameters: (name1, name2, ...)"""
        self._expect(TT.LPAREN)
        params = []
        if not self._check(TT.RPAREN):
            while True:
                name = self._expect(TT.IDENT).value
                params.append(name)
                if not self._match(TT.COMMA):
                    break
        self._expect(TT.RPAREN)
        return params

    def _parse_params(self) -> tuple[list[tuple[str, object]], tuple[str | None, str | None]]:
        """Parse function parameters: name or name = default_value, *args, **kwargs"""
        self._expect(TT.LPAREN)
        params = []
        args_name = None
        kwargs_name = None
        has_variadic = False

        if not self._check(TT.RPAREN):
            while True:
                if self._check(TT.STAR):
                    # *args
                    self._advance()
                    args_name = self._expect(TT.IDENT).value
                    has_variadic = True
                elif self._check(TT.STAR_STAR):
                    # **kwargs
                    self._advance()
                    kwargs_name = self._expect(TT.IDENT).value
                    has_variadic = True
                elif not has_variadic:
                    # Regular parameter
                    name = self._expect(TT.IDENT).value
                    default = None
                    if self._match(TT.ASSIGN):
                        default = self._expr()
                    params.append((name, default))
                else:
                    break

                if not self._match(TT.COMMA):
                    break

        self._expect(TT.RPAREN)
        return params, (args_name, kwargs_name)

    def _for_stmt(self) -> ForStmt:
        self._expect(TT.FOR)
        var = self._expect(TT.IDENT).value
        self._expect(TT.IN)
        iter_expr = self._expr()
        self._skip_newlines()
        self._expect(TT.LBRACE)
        body = self._block()
        return ForStmt(var, iter_expr, body)

    def _try_stmt(self) -> TryCatch:
        self._expect(TT.TRY)
        self._skip_newlines()
        self._expect(TT.LBRACE)
        try_body = self._block()
        self._skip_newlines()
        self._expect(TT.CATCH)
        err_var = self._expect(TT.IDENT).value
        self._skip_newlines()
        self._expect(TT.LBRACE)
        catch_body = self._block()
        return TryCatch(try_body, err_var, catch_body)

    def _class_def(self) -> ClassDef:
        self._expect(TT.CLASS)
        name = self._expect(TT.IDENT).value
        parent = None
        if self._match(TT.EXTENDS):
            parent = self._expect(TT.IDENT).value
        self._skip_newlines()
        self._expect(TT.LBRACE)
        methods = []
        self._skip_newlines()
        while not self._check(TT.RBRACE, TT.EOF):
            if self._check(TT.FN):
                methods.append(self._fn_def())
            self._skip_newlines()
        self._expect(TT.RBRACE)
        return ClassDef(name, parent, methods)

    def _is_attr_assign(self) -> bool:
        i = self.pos
        if self.tokens[i].type != TT.IDENT:
            return False
        i += 1
        while i < len(self.tokens) and self.tokens[i].type == TT.DOT:
            i += 1
            if i >= len(self.tokens) or self.tokens[i].type != TT.IDENT:
                return False
            i += 1
        return i < len(self.tokens) and self.tokens[i].type == TT.ASSIGN

    def _attr_assign_stmt(self):
        obj = Ident(self._advance().value)
        while self._check(TT.DOT):
            self._advance()
            attr = self._expect(TT.IDENT).value
            if self._check(TT.DOT):
                obj = GetAttr(obj, attr)
            else:
                self._expect(TT.ASSIGN)
                value = self._expr()
                self._end_stmt()
                return ExprStmt(SetAttr(obj, attr, value))
        raise ParseError("Invalid attribute assignment")

    def _import_stmt(self) -> ImportStmt:
        self._expect(TT.IMPORT)
        path = self._expect(TT.STRING).value
        alias = None
        if self._match(TT.AS):
            alias = self._expect(TT.IDENT).value
        self._end_stmt()
        return ImportStmt(path, alias)

    def _throw_stmt(self) -> ThrowStmt:
        self._expect(TT.THROW)
        value = self._expr()
        self._end_stmt()
        return ThrowStmt(value)

    def _return_stmt(self) -> ReturnStmt:
        self._expect(TT.RETURN)
        value = None
        if not self._check(TT.NEWLINE, TT.EOF):
            value = self._expr()
        self._end_stmt()
        return ReturnStmt(value)

    def _index_assign_or_expr(self):
        saved = self.pos
        try:
            name  = self._advance().value
            self._advance()
            index = self._expr()
            self._expect(TT.RBRACKET)
            if self._check(TT.ASSIGN):
                self._advance()
                value = self._expr()
                self._end_stmt()
                return ExprStmt(IndexSet(Ident(name), index, value))
        except Exception:
            pass
        self.pos = saved
        return self._expr_stmt()

    def _expr_stmt(self) -> ExprStmt:
        expr = self._expr()
        self._end_stmt()
        return ExprStmt(expr)

    def _block(self) -> list:
        stmts = []
        self._skip_newlines()
        while not self._check(TT.RBRACE, TT.EOF):
            stmts.append(self._stmt())
            self._skip_newlines()
        self._expect(TT.RBRACE)
        return stmts

    def _end_stmt(self):
        while self._check(TT.COMMENT):
            self._advance()
        if not self._check(TT.NEWLINE, TT.EOF, TT.RBRACE):
            raise ParseError(f"Expected newline after statement, got {self._peek()}")
        self._match(TT.NEWLINE)

    # ── expressions ───────────────────────────────────────────────────────────

    def _expr(self):
        return self._or_expr()

    def _or_expr(self):
        left = self._and_expr()
        while self._check(TT.OR):
            self._advance()
            left = BinOp("||", left, self._and_expr())
        return left

    def _and_expr(self):
        left = self._equality()
        while self._check(TT.AND):
            self._advance()
            left = BinOp("&&", left, self._equality())
        return left

    def _equality(self):
        left = self._compare()
        while self._check(TT.EQ, TT.NEQ):
            op = self._advance().type
            left = BinOp("==" if op == TT.EQ else "!=", left, self._compare())
        return left

    def _compare(self):
        left = self._add_sub()
        OPS = {TT.LT: "<", TT.GT: ">", TT.LTE: "<=", TT.GTE: ">="}
        while self._check(*OPS):
            op = OPS[self._advance().type]
            left = BinOp(op, left, self._add_sub())
        return left

    def _add_sub(self):
        left = self._mul_div()
        while self._check(TT.PLUS, TT.MINUS):
            op = "+" if self._advance().type == TT.PLUS else "-"
            left = BinOp(op, left, self._mul_div())
        return left

    def _mul_div(self):
        left = self._unary()
        OPS = {TT.STAR: "*", TT.SLASH: "/", TT.FLOORDIV: "//", TT.PERCENT: "%"}
        while self._check(*OPS):
            op = OPS[self._advance().type]
            left = BinOp(op, left, self._unary())
        return left

    def _unary(self):
        if self._check(TT.MINUS):
            self._advance()
            return UnaryOp("-", self._unary())
        if self._check(TT.BANG):
            self._advance()
            # Check if this is a macro call: !MacroName(args)
            # A macro call requires ! followed by IDENT (starting with uppercase) and then LPAREN
            if self._check(TT.IDENT):
                ident_tok = self._peek()
                # Macro names must start with uppercase letter
                if ident_tok.value and ident_tok.value[0].isupper():
                    # Lookahead to check if next token after IDENT is LPAREN
                    saved_pos = self.pos
                    self._advance()  # consume IDENT
                    is_macro_call = self._check(TT.LPAREN)
                    self.pos = saved_pos  # restore position
                    if is_macro_call:
                        return self._macro_call()
            return UnaryOp("!", self._unary())
        if self._check(TT.AWAIT):
            self._advance()
            return AwaitExpr(self._unary())
        return self._primary()

    def _macro_call(self) -> MacroCall:
        """Parse a macro call: !name(args)"""
        line = self._peek().line
        name = self._expect(TT.IDENT).value
        args = self._parse_macro_args()
        return MacroCall(name, args, line)

    def _parse_macro_args(self) -> list:
        """Parse macro arguments: (expr1, expr2, ...)"""
        self._expect(TT.LPAREN)
        args = []
        if not self._check(TT.RPAREN):
            while True:
                # For macros, we parse expressions but don't evaluate them yet
                arg = self._expr()
                args.append(arg)
                if not self._match(TT.COMMA):
                    break
        self._expect(TT.RPAREN)
        return args

    def _primary(self):
        tok = self._peek()

        if tok.type == TT.NUMBER:
            self._advance()
            return self._chain(Number(tok.value))

        if tok.type == TT.STRING:
            self._advance()
            return self._chain(String(tok.value))

        if tok.type == TT.TEMPLATE:
            self._advance()
            return self._chain(self._build_template(tok.value))

        if tok.type == TT.TRUE:
            self._advance()
            return Bool(True)

        if tok.type == TT.FALSE:
            self._advance()
            return Bool(False)

        if tok.type == TT.NULL:
            self._advance()
            return Null()

        # Anonymous function: fn(params) { body }
        if tok.type == TT.FN:
            self._advance()
            params, variadic = self._parse_params()
            self._skip_newlines()
            self._expect(TT.LBRACE)
            body = self._block()
            return self._chain(AnonFn(params, body, variadic))

        if tok.type == TT.IDENT and tok.value == "super":
            self._advance()
            return self._chain(Ident("super"))

        if tok.type == TT.LBRACE:
            self._advance()
            pairs = []
            self._skip_newlines()
            while not self._check(TT.RBRACE, TT.EOF):
                key = self._expr()
                self._expect(TT.COLON)
                val = self._expr()
                pairs.append((key, val))
                self._skip_newlines()
                if not self._check(TT.RBRACE):
                    self._expect(TT.COMMA)
                    self._skip_newlines()
            self._expect(TT.RBRACE)
            return self._chain(DictLiteral(pairs))

        if tok.type == TT.LBRACKET:
            self._advance()
            elements = []
            if not self._check(TT.RBRACKET):
                elements.append(self._expr())
                while self._match(TT.COMMA):
                    self._skip_newlines()
                    if self._check(TT.RBRACKET):
                        break
                    elements.append(self._expr())
            self._expect(TT.RBRACKET)
            return self._chain(ListLiteral(elements))

        if tok.type == TT.IDENT:
            self._advance()
            if self._check(TT.LPAREN):
                self._advance()
                args = []
                if not self._check(TT.RPAREN):
                    args.append(self._expr())
                    while self._match(TT.COMMA):
                        args.append(self._expr())
                self._expect(TT.RPAREN)
                node = Call(tok.value, args)
            else:
                node = Ident(tok.value)
            return self._chain(node)

        if tok.type == TT.LPAREN:
            self._advance()
            expr = self._expr()
            self._expect(TT.RPAREN)
            return self._chain(expr)

        raise ParseError(f"Unexpected token {tok.type.name} {tok.value!r} at line {tok.line}")

    def _build_template(self, parts: list):
        """Convert template parts list into a BinOp(+) tree."""
        if not parts:
            return String("")
        nodes = []
        for part in parts:
            if isinstance(part, str):
                nodes.append(String(part))
            else:
                _, src = part
                sub_tokens = Lexer(src).tokenize()
                expr = Parser(sub_tokens)._expr()
                # wrap in str() to ensure string conversion
                nodes.append(Call("str", [expr]))
        result = nodes[0]
        for n in nodes[1:]:
            result = BinOp("+", result, n)
        return result

    def _chain(self, node):
        while True:
            if self._check(TT.DOT):
                self._advance()
                attr = self._expect(TT.IDENT).value
                if self._check(TT.LPAREN):
                    self._advance()
                    args = []
                    if not self._check(TT.RPAREN):
                        args.append(self._expr())
                        while self._match(TT.COMMA):
                            args.append(self._expr())
                    self._expect(TT.RPAREN)
                    node = MethodCall(node, attr, args)
                else:
                    node = GetAttr(node, attr)
            elif self._check(TT.LBRACKET):
                self._advance()
                index = self._expr()
                self._expect(TT.RBRACKET)
                node = IndexGet(node, index)
            elif self._check(TT.LPAREN):
                # calling the result of an expression: fns[0](x), get_fn()()
                self._advance()
                args = []
                if not self._check(TT.RPAREN):
                    args.append(self._expr())
                    while self._match(TT.COMMA):
                        args.append(self._expr())
                self._expect(TT.RPAREN)
                node = CallExpr(node, args)
            else:
                break
        return node
