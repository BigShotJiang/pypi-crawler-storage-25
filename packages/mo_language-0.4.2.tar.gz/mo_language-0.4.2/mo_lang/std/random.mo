# std/random.mo — random number generation

fn random_int(min, max) {
    return __random_int__(min, max)
}

fn random_float() {
    return __random_float__()
}

fn random_pick(lst) {
    return __random_pick__(lst)
}
