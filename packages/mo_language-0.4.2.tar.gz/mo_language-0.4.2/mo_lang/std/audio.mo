fn play(path) {
    return __audio_play__(path)
}