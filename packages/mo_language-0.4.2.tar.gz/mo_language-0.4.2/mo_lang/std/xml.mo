# std/xml.mo — XML parse and stringify

fn parse(text) {
    return __xml_parse__(text)
}

fn to_string(obj) {
    return __xml_to_string__(obj)
}