fn open(path) {
    return __sqlite_open__(path)
}

fn exec(db, sql) {
    return __sqlite_exec__(db, sql)
}

fn close(db) {
    __sqlite_close__(db)
}