# std/math.mo — math utilities

fn math_pow(base, exp) {
    if exp == 0 { return 1 }
    let result = 1
    let i = 0
    while i < exp {
        result = result * base
        i = i + 1
    }
    return result
}

fn math_sqrt(n) {
    if n < 0 { throw "sqrt of negative number" }
    if n == 0 { return 0 }
    let guess = n / 2
    let i = 0
    while i < 50 {
        guess = (guess + n / guess) / 2
        i = i + 1
    }
    return guess
}

fn math_max(a, b) {
    if a > b { return a }
    return b
}

fn math_min(a, b) {
    if a < b { return a }
    return b
}

fn math_clamp(val, lo, hi) {
    if val < lo { return lo }
    if val > hi { return hi }
    return val
}

fn math_abs(x) {
    if x < 0 { return -x }
    return x
}

fn math_floor(x) {
    return __floor__(x)
}

fn math_ceil(x) {
    return __ceil__(x)
}

fn math_round(x) {
    return __round__(x)
}

fn math_log(x) {
    # Natural logarithm using Newton-Raphson approximation
    if x <= 0 { throw "log of non-positive number" }
    if x == 1 { return 0 }
    let n = 0
    while x >= 2 {
        x = x / 2.718281828459045
        n = n + 1
    }
    while x < 0.5 {
        x = x * 2.718281828459045
        n = n - 1
    }
    # ln(x) approximation for x close to 1
    let z = (x - 1) / (x + 1)
    let z2 = z * z
    let result = z
    let term = z
    let i = 1
    while i < 20 {
        term = term * z2
        result = result + term / (2 * i + 1)
        i = i + 1
    }
    return 2 * result + n
}

fn math_sin(x) {
    # Taylor series approximation
    x = x % 6.283185307179586
    let term = x
    let result = x
    let i = 1
    while i < 10 {
        term = -term * x * x / ((2 * i) * (2 * i + 1))
        result = result + term
        i = i + 1
    }
    return result
}

fn math_cos(x) {
    x = x % 6.283185307179586
    let term = 1
    let result = 1
    let i = 1
    while i < 10 {
        term = -term * x * x / ((2 * i - 1) * (2 * i))
        result = result + term
        i = i + 1
    }
    return result
}

fn math_tan(x) {
    let c = math_cos(x)
    if c == 0 { throw "tan undefined at this value" }
    return math_sin(x) / c
}

fn math_pi() {
    return 3.141592653589793
}
