# std/yaml.mo — YAML parse and stringify

fn parse(text) {
    return __yaml_parse__(text)
}

fn stringify(obj) {
    return __yaml_stringify__(obj)
}