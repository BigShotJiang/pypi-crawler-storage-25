fn window(title, width, height) {
    return __gui_window__(title, width, height)
}

fn rectangle(x, y, w, h, color) {
    return __gui_rect__(x, y, w, h, color)
}

fn circle(x, y, radius, color) {
    return __gui_circle__(x, y, radius, color)
}

fn text(x, y, content, size, color) {
    return __gui_text__(x, y, content, size, color)
}

fn line(x1, y1, x2, y2, color) {
    return __gui_line__(x1, y1, x2, y2, color)
}

fn image(path, x, y, w, h) {
    return __gui_image__(path, x, y, w, h)
}

fn on_click(callback) {
    return __gui_on_click__(callback)
}

fn on_key(callback) {
    return __gui_on_key__(callback)
}

fn loop() {
    __gui_loop__()
}