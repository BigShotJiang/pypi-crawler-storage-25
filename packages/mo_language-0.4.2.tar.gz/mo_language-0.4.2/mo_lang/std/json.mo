# std/json.mo — JSON parse and stringify

fn json_parse(s) {
    return __json_parse__(s)
}

fn json_stringify(val) {
    return __json_stringify__(val)
}

fn json_pretty(val) {
    return __json_stringify__(val, 2)
}
