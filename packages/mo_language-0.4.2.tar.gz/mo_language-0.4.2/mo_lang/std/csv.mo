# std/csv.mo — CSV read and write

fn read(path) {
    return __csv_read__(path)
}

fn write(path, data) {
    __csv_write__(path, data)
}