fn match(pattern, text) {
    return __regex_match__(pattern, text)
}

fn replace(pattern, text, replacement) {
    return __regex_replace__(pattern, text, replacement)
}

fn split(pattern, text) {
    return __regex_split__(pattern, text)
}