# std/concurrency.mo — Concurrency primitives for Mo language
# Provides high-level helpers for locks, semaphores, and channels
# 
# Built-in primitives available directly:
#   lock()              - Create a new mutex lock
#   lock_acquire(mtx)   - Acquire a lock (blocking)
#   lock_release(mtx)   - Release a lock
#   semaphore(n)        - Create a semaphore with n permits
#   sem_acquire(sem)    - Acquire a semaphore permit
#   sem_release(sem)    - Release a semaphore permit
#   channel(name)       - Create or get a named channel
#   send(ch, value)     - Send a value to a channel
#   recv(ch)            - Receive a value from a channel (blocking)
#   spawn(f)            - Spawn a new async task
#   parallel(fns)       - Run multiple functions in parallel
#   gather(awaitables)  - Gather results from multiple awaitables
#   sleep_async(ms)     - Sleep asynchronously (non-blocking)
#   run_async(f)        - Run an async function and await its result

# ============================================================================
# Mutex Lock Helpers
# ============================================================================

# Execute a function with a lock held (sugar for acquire/release)
fn with_lock(mtx, f) {
    lock_acquire(mtx)
    let result = f()
    lock_release(mtx)
    return result
}

# Create a lock and return it along with synchronized wrapper object
fn synchronized() {
    let mtx = lock()
    return {
        "lock": mtx,
        "acquire": fn() { lock_acquire(mtx) },
        "release": fn() { lock_release(mtx) },
        "run": fn(f) { with_lock(mtx, f) }
    }
}

# ============================================================================
# Semaphore Helpers
# ============================================================================

# Execute a function with a semaphore permit held
fn with_semaphore(sem, f) {
    sem_acquire(sem)
    let result = f()
    sem_release(sem)
    return result
}

# Create a bounded resource pool using a semaphore
fn resource_pool(size) {
    let sem = semaphore(size)
    return {
        "semaphore": sem,
        "acquire": fn() { sem_acquire(sem) },
        "release": fn() { sem_release(sem) },
        "run": fn(f) { with_semaphore(sem, f) }
    }
}

# ============================================================================
# Examples / Usage patterns
# ============================================================================
# 
# Basic mutex usage:
#   let mtx = lock()
#   lock_acquire(mtx)
#   # critical section
#   lock_release(mtx)
#
# Using with_lock helper:
#   let mtx = lock()
#   let result = with_lock(mtx, fn() {
#       # critical section
#       return 42
#   })
#
# Using synchronized object:
#   let sync = synchronized()
#   sync.acquire()
#   # critical section
#   sync.release()
#   # or:
#   sync.run(fn() {
#       # critical section
#   })
#
# Semaphore for limiting concurrency:
#   let sem = semaphore(3)  # max 3 concurrent
#   sem_acquire(sem)
#   # limited concurrency section
#   sem_release(sem)
#
# Using resource_pool:
#   let pool = resource_pool(5)  # pool of 5 resources
#   pool.run(fn() {
#       # use one resource slot
#   })
#
# Channels for async communication:
#   let ch = channel("my_channel")
#   send(ch, "hello")
#   let msg = recv(ch)
#
# Running tasks in parallel:
#   parallel(fn() { task1() }, fn() { task2() })
