RETRANSCRIPTIONS AUTOMATIQUES DES CONFERENCES DE REDACTION AFP – TEST D’USAGE DANS LE SALESCHATBOT

**Introduction – Couverture éditoriale AFP : Conférences de rédaction quotidiennes**

**But du document :**

Ce document rassemble les notes générées automatiquement des conférences de rédaction quotidiennes de l’AFP. Il sert, sur des sujets spécifiques, à illustrer l’ampleur, la réactivité et la diversité de la couverture mondiale de l’Agence, en donnant un aperçu concret des sujets traités chaque jour par les équipes éditoriales.

**Objectif commercial :**

Des extraits choisis et contextualisés du document pourraient permettre aux commerciaux AFP de montrer la richesse de la couverture internationale en temps réel, et d’appuyer leurs argumentaires sur des exemples précis, la crédibilité, la vérification et la variété des sources de l’AFP. Les exemples présentés ici démontrent la présence quotidienne de l’AFP sur tous les grands événements mondiaux, “foot on the ground” qu’ils soient politiques, environnementaux, économiques, culturels ou sportifs.

**Note technique :**

Ces transcriptions sont générées et structurées automatiquement pour enrichir le Sales & Marketing Chatbot (ask.afp.com). Elles peuvent être citées ou résumées dans les présentations commerciales, mais doivent toujours être vérifiées avant diffusion externe comme toute autre information produite par le chatbot.

**Point d’attention :**

Certains points communiqués lors des conférences de rédaction - à l’oral par les journalistes de l’AFP et retranscrits ici comme les prénoms, challenges etc. - doivent rester confidentiels et comme toute autre information interne disponible dans la Tooblox ou via le Sales chatbot, elles ne peuvent pas être communiquées telles quelles à l'extérieur de l'AFP. Le bon sens est de rigueur. En cas de doutes, contacter nicolas.giraudon@afp.com

---------------------------------------------------------------------------------------------------------

27/01/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Crise à Minneapolis et Réactions Politiques:** L'équipe, menée par Didier, a discuté des récents développements à Minneapolis, notamment les mouvements nocturnes, les réactions politiques des équipes de Trump, les possibles limogeages de responsables, et la couverture médiatique sur place avec Roberto, tout en abordant les implications pour la ministre de l'Intérieur et les tensions budgétaires au Congrès.
  + **Mouvements Nocturnes et Limogeages:** Didier a rapporté d'importants mouvements à Minneapolis durant la nuit, évoquant la prise de conscience des équipes de Trump de la nécessité d'apaisement, avec des rumeurs confirmées par ABC sur le renvoi de responsables comme Gobineau, chef de tiers-frontière, qui retournerait à ses fonctions en Californie.
  + **Réactions Politiques et Pressions:** L'équipe a souligné que la ministre de l'Intérieur pourrait servir de fusible pour calmer la situation, alors que plusieurs républicains commencent à s'inquiéter de l'ampleur des événements, et que l'avocat du policier impliqué dans la mort d'une jeune femme s'est retiré de l'affaire, jugeant la situation trop extrême.
  + **Conséquences Budgétaires:** Il a été noté que si les démocrates refusent de voter le budget du secrétariat à l'Intérieur, cela pourrait provoquer une crise politique supplémentaire, illustrant la tension persistante autour de la gestion de la crise.
  + **Couverture Médiatique sur Place:** Roberto assure la couverture photo sur le terrain, avec une production équivalente à celle des concurrents, tandis qu'en vidéo, l'équipe a obtenu des réactions rapides et des images en direct, notamment avec l'arrivée de Cécilia de New York pour renforcer la couverture.
* **Tensions et Répression en Iran:** Rita a présenté un point détaillé sur la situation en Iran, marquée par la transformation des protestations en guerre verbale avec les États-Unis, la présence du porte-avions Abraham Lincoln, la poursuite de la répression, les coupures d'Internet, et la préparation de plusieurs papiers d'analyse et d'illustration par l'équipe, avec l'appui de Sébastien et Chris.
  + **Escalade Diplomatique et Militaire:** Rita a expliq<ué que la répression des protestations en Iran s'est muée en affrontement verbal avec les États-Unis, avec la menace des Gardiens de la Révolution de cibler le porte-avions Abraham Lincoln s'il entrait dans les eaux iraniennes, tandis que Trump a réaffirmé sa proximité militaire tout en laissant la porte ouverte à la diplomatie.
  + **Poursuite de la Répression et Arrestations:** La répression se poursuit avec plus de 41 000 arrestations selon l'ONG Rana, les autorités iraniennes maintenant le lien entre les manifestants et des puissances étrangères, et la coupure d'Internet reste effective malgré plusieurs annonces officielles de rétablissement.
  + **Difficultés de Couverture et Production de Contenus:** Le bureau sur place dispose d'un accès Internet très limité, ce qui complique la collecte d'informations, mais Sébastien prépare un article sur la vie d'un chef de bureau en Iran, tandis que le pôle Inter travaille sur un papier concernant la restitution des corps des victimes aux familles, conditionnée à leur silence et à un paiement.
  + **Illustrations et Communication Visuelle:** L'équipe a évoqué la diffusion d'une affiche anti-américaine montrant le porte-avions Abraham Lincoln en flammes, reprise dans la presse conservatrice iranienne, et a précisé que seules des images d'archives peuvent être utilisées pour illustrer la présence du porte-avions.
* **Accord Commercial UE-Inde et Implications Stratégiques:** Peter a présenté l'accord commercial majeur entre l'Union européenne et l'Inde, soulignant ses volets économiques (réduction des tarifs sur des produits européens) et sécuritaires, le contexte de tensions globales, et la préparation de contenus explicatifs par Umberto et l'équipe de Bruxelles.
  + **Contenu de l'Accord:** Peter a détaillé que l'accord, fruit de vingt ans de négociations, inclut des avantages commerciaux pour des produits européens comme les voitures de luxe, l'huile d'olive, le vin et les pâtes, ainsi qu'un volet sécurité et défense important dans le contexte international actuel.
  + **Contexte Géopolitique:** L'accord s'inscrit dans un climat d'insécurité croissante et de turbulences mondiales, avec des relations parfois tendues avec les États-Unis ayant contribué à accélérer la conclusion de l'accord avec l'Inde.
  + **Production de Contenus et Suivi:** Umberto, venu de Bruxelles, travaille sur un article retraçant le processus ayant mené à l'accord, tandis que Bruxelles prépare un fact box pour expliquer ses implications pour l'Europe, en prévision de futurs sommets en Inde sur la défense.
* **Gestion des Images et Couverture Technique:** L'équipe a abordé la gestion des images et la couverture technique des événements, évoquant les difficultés de connexion lors des directs, l'utilisation de ressources propres et de backups, ainsi que la production d'illustrations pour accompagner les sujets traités.
  + **Problèmes de Connexion et Solutions:** L'équipe a rencontré des difficultés de connexion lors d'un live en Algérie, ayant initialement utilisé des ressources propres avant de recourir à des sources moyennes et à AEBS avec l'UE en backup pour assurer la continuité de la couverture.

Tâches de suivi:

* **Recherche de citation officielle sur la menace iranienne:** Tenter de trouver une déclaration officielle des Gardiens de la Révolution concernant la menace contre le porte-avions Abraham Lincoln. (Rita)
* **Prudence sur les annonces de rétablissement d’Internet en Iran:** Faire preuve de plus de prudence dans la communication sur le retour d’Internet en Iran, en raison des annonces non tenues des autorités. (Rita)
* **Publication d’un article sur la vie d’un chef de bureau en Iran:** Essayer de publier aujourd’hui ou demain l’article préparé par Sébastien sur la vie d’un chef de bureau de terrain en Iran. (Rita, Sébastien)
* **Demande de photo spécifique pour illustration médiatique:** Envoyer la photo de la une d’un journal conservateur iranien montrant le porte-avions Abraham Lincoln en flammes, comme demandé par Chris. (Sébastien)

15/01/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Couverture de la situation en Iran:** L'équipe, avec Chris, Dounia, Mariam et Amine, a discuté de la couverture quotidienne de la situation en Iran, des difficultés techniques pour accéder à la télévision iranienne, et de l'organisation de la vérification des contenus UGC, tout en assurant la présence de deux éditrices spéciales pour renforcer la vérification.
  + **Difficultés d'accès à la télévision iranienne:** L'équipe a rencontré des problèmes techniques persistants pour récupérer les images de la télévision iranienne, notamment lors des interventions d'officiels comme le président, malgré un accord avec Iran Presse ; ils travaillent avec le technicien du bureau pour trouver une solution, y compris l'utilisation ponctuelle d'un site piraté.
  + **Organisation de la vérification UGC:** Dounia et Mariam sont chargées de la vérification et de la sécurisation des contenus UGC, avec un système bien rodé en place depuis le début, garantissant la fiabilité des images envoyées malgré les contraintes de sécurité.
  + **Couverture des événements officiels:** L'équipe a pu couvrir les funérailles des forces de sécurité du régime, en précisant que les sorties sont autorisées uniquement pour des événements non anti-régime, ce qui limite la diversité des sujets traités.
* **Déploiement militaire et tensions au Groenland:** L'équipe, avec Jonathan Klein, Alessandro et Alexandra, a analysé la couverture du déploiement de petits contingents militaires de pays européens au Groenland, les réactions locales et les implications pour l'OTAN, tout en assurant un suivi terrain et une production d'images et de vidéos.
  + **Déploiement de contingents européens:** Des petits contingents militaires, notamment français (environ une quinzaine de soldats), ont été envoyés au Groenland par plusieurs pays européens, illustrant une situation inédite où des membres de l'OTAN déploient des troupes sur un territoire convoité par les États-Unis.
  + **Couverture terrain et production d'images:** Jonathan Klein a assuré la couverture vidéo, Alessandro la photographie, et Alexandra prendra le relais pour la production d'images et de vidéos, notamment sur les réactions des habitants et la présence de drapeaux groenlandais dans la ville.
  + **Réactions et désaccords diplomatiques:** Les rencontres à Washington ont mis en lumière un profond désaccord entre les Groenlandais, les Danois et les Américains sur l'avenir du Groenland, avec une déclaration martiale de Trump mais l'espoir d'une solution.
  + **Enjeux pour l'OTAN:** Le bureau de Bruxelles travaille sur l'angle de la crise existentielle de l'OTAN, soulignant la position délicate de son secrétaire général, confronté à la menace principale venant des États-Unis eux-mêmes selon l'équipe.
* **Couverture de l'élection en Ouganda:** L'équipe, avec Patrick, Louise et le stringer Patrogatumba, a assuré une couverture complète de l'élection présidentielle en Ouganda malgré des conditions de sécurité difficiles, des coupures d'internet et des restrictions de mouvement, en utilisant des solutions alternatives pour transmettre les contenus.
  + **Conditions de couverture difficiles:** La couverture de l'élection a été rendue complexe par l'absence quasi totale d'internet, des restrictions de sécurité et des difficultés pour les photographes et vidéastes à se déplacer librement.
  + **Solutions techniques pour la transmission:** L'équipe a utilisé l'internet de l'hôtel et des cartes SIM kényanes pour transmettre les contenus, permettant d'envoyer photos et vidéos malgré les blocages.
  + **Suivi du vote et des résultats:** Des images des bureaux de vote et des vox pop ont été obtenues, avec la possibilité de couvrir le vote du candidat d'opposition Bobby Wine, tandis que pour le président sortant, seules des images officielles (hand out) étaient disponibles.

Tâches de suivi:

* **Accès à la Télévision Iranienne:** Trouver une solution technique pour capter la télévision iranienne, en collaboration avec le technicien du Bureau de Téhéran. (the team)
* **Vérification des UGC:** Sécuriser et vérifier les UGC avant leur envoi, en s'assurant qu'ils ne présentent pas de risques de sécurité. (Dounia, Mariam)
* **Coordination de la Couverture Photo en Ouganda:** Briefer Patrick, Louise et le stringer sur place (Patrogatumba) concernant les réserves de mouvement pour la couverture photo en Ouganda. (the team)

14/01/2026

12/01/2026

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Menaces Pénales Contre la Fed et Jérôme Powell:** Sophie a présenté les récentes menaces de poursuites judiciaires contre Jérôme Powell et la Fed, évoquant les tensions croissantes entre Donald Trump et le président de la Fed, ainsi que les impacts sur les marchés financiers, avec des interventions de Ben et d'autres membres de l'équipe sur les conséquences et la couverture médiatique.
  + **Contexte des Menaces:** Sophie a expliqué que les tensions entre Donald Trump et Jérôme Powell durent depuis plusieurs mois, marquées par des invectives, mais ont franchi un nouveau palier avec la menace de poursuites judiciaires contre Powell et la Fed, officiellement pour des soupçons de fraude liés au budget de rénovation du siège de la Banque centrale américaine.
  + **Motivations Réelles:** Sophie a précisé que, selon Powell, la véritable raison de ces menaces serait le mécontentement de Trump face au refus de la Fed de baisser les taux d'intérêt, ce qui serait perçu comme une forme de punition politique.
  + **Impact sur les Marchés:** Ben a interrogé sur les impacts globaux, et Sophie a détaillé que l'or et l'argent, valeurs refuges, flambent, tandis que le dollar et les bourses européennes baissent légèrement, soulignant l'importance de l'indépendance des banques centrales pour la stabilité des marchés.
  + **Couverture Médiatique:** L'équipe a mentionné la préparation de contenus sur les déclarations de Trump et Powell, la récupération de vidéos et d'images pertinentes, et la diffusion de stockshots sur l'argent, afin d'assurer une couverture complète de l'événement.
* **Situation et Couverture des Manifestations en Iran:** Stuart a fait un point sur la situation en Iran, marquée par des manifestations et une répression accrue, en détaillant les difficultés d'accès à l'information, les stratégies de couverture, et la collaboration avec des agences photo, avec des interventions de Stéphane, Katia et Chris.
  + **Résumé de la Situation:** Stuart a résumé la situation en Iran, évoquant la montée du nombre de morts, y compris parmi les forces de sécurité, la difficulté d'obtenir des informations fiables à cause du blocage d'internet, et la diffusion de vidéos sur les réseaux sociaux.
  + **Stratégie de Couverture:** L'équipe a expliqué qu'ils utilisent principalement des vidéos UGC (contenu généré par les utilisateurs) et des images satellites pour documenter les événements, en raison de l'absence d'accréditation pour leur photographe et du manque de photos récentes.
  + **Collaboration avec Agences Photo:** Stéphane et Katia ont précisé que, bien qu'ils n'aient pas de lien éditorial avec l'agence Middle East Images, cette dernière fournit des photos récentes des manifestations, disponibles sur leur plateforme pour les clients, mais non diffusées directement par leur équipe.
  + **Difficultés Techniques et Logistiques:** Chris a souligné la nécessité d'une couverture simultanée et la difficulté d'obtenir des informations fiables à cause du blocage d'internet, tout en appelant à l'aide de personnes parlant français pour améliorer la collecte d'informations.
* **Menaces de Trump Contre Cuba:** Daniel a présenté les récentes menaces de Donald Trump envers Cuba, en lien avec l'opération Caracas et le contrôle du pétrole vénézuélien, et l'équipe photo à Cuba a détaillé leur couverture sur place, incluant des vox pop et des images d'archives.
  + **Contexte Politique:** Daniel a expliqué que, suite à l'opération Caracas, Trump a adressé de nouveaux messages de menace à Cuba, notamment sur l'arrêt du soutien financier et moral, et le contrôle du pétrole vénézuélien, essentiel pour l'économie cubaine.
  + **Réactions Locales:** L'équipe sur place à Cuba a recueilli des vox pop depuis La Havane, montrant que la population est partagée entre peur et résignation, et a collecté des images d'ambiance et de vie quotidienne pour illustrer la situation.
  + **Couverture Photo:** L'équipe photo a précisé qu'ils accompagnent la couverture des événements par des photos d'archives du président cubain et des images classiques, tout en restant attentifs à l'évolution de la situation.

Tâches de suivi:

* **Accréditation du Photographe en Iran:** Vérifier si le photographe obtiendra une accréditation en tant que journaliste pour couvrir la manifestation en Iran. (the team)
* **Vérification des Vidéos sur les Manifestations en Iran:** Vérifier et authentifier les vidéos UGC récupérées près de Téhéran concernant les manifestations. (the team)
* **Soutien pour la Couverture Internet en Iran:** Identifier toute personne parlant français et disposée à aider à obtenir des informations sur le réseau internet en Iran. (Chris)

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Menaces Pénales Contre la Fed et Jérôme Powell:** Sophie a présenté les récentes menaces de poursuites judiciaires contre Jérôme Powell et la Fed, évoquant les tensions croissantes entre Donald Trump et le président de la Fed, ainsi que les impacts sur les marchés financiers, avec des interventions de Ben et d'autres membres de l'équipe sur les conséquences et la couverture médiatique.
  + **Contexte des Menaces:** Sophie a expliqué que les tensions entre Donald Trump et Jérôme Powell durent depuis plusieurs mois, marquées par des invectives, mais ont franchi un nouveau palier avec la menace de poursuites judiciaires contre Powell et la Fed, officiellement pour des soupçons de fraude liés au budget de rénovation du siège de la Banque centrale américaine.
  + **Motivations Réelles:** Sophie a précisé que, selon Powell, la véritable raison de ces menaces serait le mécontentement de Trump face au refus de la Fed de baisser les taux d'intérêt, ce qui serait perçu comme une forme de punition politique.
  + **Impact sur les Marchés:** Ben a interrogé sur les impacts globaux, et Sophie a détaillé que l'or et l'argent, valeurs refuges, flambent, tandis que le dollar et les bourses européennes baissent légèrement, soulignant l'importance de l'indépendance des banques centrales pour la stabilité des marchés.
  + **Couverture Médiatique:** L'équipe a mentionné la préparation de contenus sur les déclarations de Trump et Powell, la récupération de vidéos et d'images pertinentes, et la diffusion de stockshots sur l'argent, afin d'assurer une couverture complète de l'événement.
* **Situation et Couverture des Manifestations en Iran:** Stuart a fait un point sur la situation en Iran, marquée par des manifestations et une répression accrue, en détaillant les difficultés d'accès à l'information, les stratégies de couverture, et la collaboration avec des agences photo, avec des interventions de Stéphane, Katia et Chris.
  + **Résumé de la Situation:** Stuart a résumé la situation en Iran, évoquant la montée du nombre de morts, y compris parmi les forces de sécurité, la difficulté d'obtenir des informations fiables à cause du blocage d'internet, et la diffusion de vidéos sur les réseaux sociaux.
  + **Stratégie de Couverture:** L'équipe a expliqué qu'ils utilisent principalement des vidéos UGC (contenu généré par les utilisateurs) et des images satellites pour documenter les événements, en raison de l'absence d'accréditation pour leur photographe et du manque de photos récentes.
  + **Collaboration avec Agences Photo:** Stéphane et Katia ont précisé que, bien qu'ils n'aient pas de lien éditorial avec l'agence Middle East Images, cette dernière fournit des photos récentes des manifestations, disponibles sur leur plateforme pour les clients, mais non diffusées directement par leur équipe.
  + **Difficultés Techniques et Logistiques:** Chris a souligné la nécessité d'une couverture simultanée et la difficulté d'obtenir des informations fiables à cause du blocage d'internet, tout en appelant à l'aide de personnes parlant français pour améliorer la collecte d'informations.
* **Menaces de Trump Contre Cuba:** Daniel a présenté les récentes menaces de Donald Trump envers Cuba, en lien avec l'opération Caracas et le contrôle du pétrole vénézuélien, et l'équipe photo à Cuba a détaillé leur couverture sur place, incluant des vox pop et des images d'archives.
  + **Contexte Politique:** Daniel a expliqué que, suite à l'opération Caracas, Trump a adressé de nouveaux messages de menace à Cuba, notamment sur l'arrêt du soutien financier et moral, et le contrôle du pétrole vénézuélien, essentiel pour l'économie cubaine.
  + **Réactions Locales:** L'équipe sur place à Cuba a recueilli des vox pop depuis La Havane, montrant que la population est partagée entre peur et résignation, et a collecté des images d'ambiance et de vie quotidienne pour illustrer la situation.
  + **Couverture Photo:** L'équipe photo a précisé qu'ils accompagnent la couverture des événements par des photos d'archives du président cubain et des images classiques, tout en restant attentifs à l'évolution de la situation.

Tâches de suivi:

* **Accréditation du Photographe en Iran:** Vérifier si le photographe obtiendra une accréditation en tant que journaliste pour couvrir la manifestation en Iran. (the team)
* **Vérification des Vidéos sur les Manifestations en Iran:** Vérifier et authentifier les vidéos UGC récupérées près de Téhéran concernant les manifestations. (the team)
* **Soutien pour la Couverture Internet en Iran:** Identifier toute personne parlant français et disposée à aider à obtenir des informations sur le réseau internet en Iran. (Chris)

11/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Saisie d’un Pétrolier Vénézuélien par les États-Unis:** Sébastien a présenté les détails de la saisie d’un super pétrolier transportant du brut vénézuélien par les forces américaines, avec l’appui du FBI et de l’armée, et a expliqué les réactions de Donald Trump et du régime de Nicolas Maduro.
  + **Contexte de la Saisie:** Sébastien a expliqué que les États-Unis ont saisi un super pétrolier transportant du brut vénézuélien au large des côtes, dans le cadre de sanctions de longue date contre le navire pour transport de brut iranien et vénézuélien.
  + **Déroulement de l’Opération:** La présentation a inclus une vidéo montrant deux hélicoptères du FBI, appuyés par l’armée américaine, arraisonnant le pétrolier, sans révéler le nom du navire ni celui de son propriétaire.
  + **Réactions Politiques:** Donald Trump a annoncé la saisie, affirmant que l’objectif était de renverser le régime de Maduro, tandis que le Venezuela a dénoncé un acte de piraterie internationale et que la ministre PAM Bondy a précisé le contexte des sanctions.
  + **Conséquences et Analyse:** L’équipe a noté une hausse des cours du brut suite à l’incident, et a discuté de l’impact limité des sanctions précédentes sur le maintien au pouvoir de Maduro, tout en actualisant leur documentation avec les nouveaux éléments.
* **Arrivée de l’Opposante Vénézuélienne Machado à Oslo:** L’équipe, dont plusieurs membres à Oslo et à Caracas, a suivi en direct l’arrivée de Machado, opposante vénézuélienne, après 11 mois d’absence publique, et a couvert les réactions et événements liés à sa présence.
  + **Arrivée et Mobilisation:** Machado est arrivée à Oslo dans la nuit, accueillie par une foule de partisans, marquant sa première apparition publique depuis 11 mois, avec une forte mobilisation des équipes sur place.
  + **Interview et Circonstances de la Sortie:** Machado a donné une interview à la BBC, remerciant ceux qui ont facilité sa sortie du Venezuela, sans révéler les détails, bien que des rumeurs évoquent une fuite par bateau de pêcheurs déguisés.
  + **Couverture Médiatique et Prix Nobel:** La fille de Machado, exilée, a reçu le prix Nobel en son nom, et l’équipe a assuré une couverture large, incluant des photos à l’aéroport, à l’hôtel, et lors du gala des Nobel.
  + **Réactions au Venezuela:** Des articles ont été produits sur les réactions au Venezuela, où les partisans de Maduro accusent Machado de trahison, tandis que ses soutiens la saluent comme une libératrice ; Machado a affirmé son intention de rentrer au Venezuela.
  + **Organisation de la Couverture:** L’équipe a été renforcée sur place pour suivre les deux conférences de presse prévues, et a assuré une veille continue, notamment grâce à la présence de journalistes et photographes à différents points stratégiques.
* **Jeu Vidéo Français Favori aux Game Awards:** Killian a présenté la participation exceptionnelle d’un jeu vidéo français, développé par un petit studio de Montpellier, aux Game Awards à Los Angeles, où il est favori avec un record de nominations.
  + **Présentation du Jeu:** Le jeu, développé par une équipe d’une trentaine de personnes à Montpellier, est nommé dans 13 catégories, une première pour un jeu français, et affronte des productions majeures internationales.
  + **Processus de Nomination et Récompenses:** Le jeu est favori pour le titre de jeu de l’année et pourrait battre un record de trophées, alors que la France n’a jamais remporté cette distinction malgré plusieurs nominations passées.
  + **Direction Artistique et Réception:** Le jeu se distingue par une direction artistique inspirée de la Belle Époque parisienne, un style de jeu de rôle apprécié, et a généré un engouement notable dès son annonce.
  + **Musique et Impact Culturel:** La bande originale, composée par un ancien professeur de guitare, a rencontré un grand succès, avec des concerts à guichets fermés et une popularité jusque dans les karaokés parisiens.
  + **Couverture Médiatique et Interviews:** L’équipe prévoit une couverture photo et vidéo de la cérémonie, avec des interviews programmées avec les créateurs, et souligne l’impact de la « patte française » dans la réception du jeu à l’international.
* **Reportage Exceptionnel à Aden au Yémen:** Haitham a partagé son expérience d’une mission rare à Aden, réalisée grâce à des contacts avec les autorités saoudiennes, et a détaillé la production de plusieurs reportages sur la situation humanitaire et sécuritaire.
  + **Accès et Organisation de la Mission:** Haitham a expliqué que l’accès à Aden a été possible grâce à des contacts continus avec les Saoudiens, qui contrôlent l’entrée, et que la mission a duré quatre jours.
  + **Reportages Réalisés:** Trois sujets ont été produits : l’état de l’éducation avec 3 000 écoles endommagées, la situation des réfugiés somaliens, et un reportage sur la vie quotidienne à Aden.
  + **Conditions de Sécurité:** Haitham a décrit la présence de nombreux points de contrôle, la pauvreté omniprésente, et la difficulté de travailler sur place, tout en soulignant l’importance du travail d’équipe avec les journalistes locaux.
  + **Impact et Visibilité:** Le reportage vise à attirer l’attention sur un conflit oublié, rarement traité en une, et met en avant la nécessité de continuer à couvrir la situation au Yémen.
* **Confirmation de l’Implication Française dans la Protection du Président du Bénin:** L’équipe du bureau d’Abidjan a été la première à confirmer l’implication de l’armée française dans la protection du président Talon au Bénin après la tentative de coup d’État, grâce à des contacts avec le chef d’état-major.
  + **Obtention de l’Information:** Le bureau d’Abidjan a obtenu la confirmation officielle de l’implication française auprès du chef d’état-major, permettant de publier deux alertes et d’être les premiers à diffuser l’information.
* **Refonte du Manuel Agencier et Développement du Stylebot:** Pauline, Julie et l’équipe centrale ont présenté la refonte du Manuel agencier, la publication de nouvelles entrées sur l’autisme et les vaccins, et le développement d’un outil chatbot (stylebot) pour faciliter l’accès aux recommandations rédactionnelles.
  + **Nouvelles Entrées et Structuration:** Les entrées sur l’autisme et les vaccins ont été réécrites pour être plus claires, structurées par recommandations, contexte et précautions, afin de répondre aux besoins des journalistes et de préparer l’intégration dans le stylebot.
  + **Objectifs du Stylebot:** Le stylebot permettra aux journalistes de poser des questions et d’obtenir rapidement des réponses issues du Manuel agencier, rendant l’outil plus accessible et interactif.
  + **Méthodologie et Collaboration:** La refonte est menée en collaboration avec l’équipe centrale, Éric, Pauline, Jenny et le réseau, et implique une structuration adaptée à l’usage des LLM et chatbots, tout en conservant la tradition journalistique de l’AFP.
  + **Exemples et Précautions:** Julie a détaillé la nécessité d’expliciter les règles, notamment sur les sujets sensibles comme les vaccins, pour éviter la désinformation et garantir la neutralité et la rigueur des dépêches, en s’appuyant sur l’expertise du fact-checking.
  + **Déploiement Progressif:** Le travail de réécriture se poursuit sur d’autres thèmes, comme la couverture des conflits, avec l’objectif de rendre le Manuel plus utile et de permettre à terme une utilisation commerciale des contenus structurés.

Tâches de suivi:

* **Enquête sur la Sortie de Machado du Venezuela:** Tenter d'obtenir plus d'informations sur la manière dont Machado est sortie du Venezuela, en particulier en poursuivant l'investigation par le Bureau de Caracas. (Teams)

09/01/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Situation en Iran et Collecte de Témoignages:** L'équipe, incluant Chris, Stéphane et Sebastianis, a discuté de la situation actuelle en Iran, de la nécessité de recueillir des témoignages d'Iraniens de l'intérieur, des difficultés de vérification des contenus UGC, et des précautions à prendre dans la publication des images.
  + **Appel à Témoignages:** L'équipe a réitéré l'importance d'obtenir des témoignages directs d'Iraniens vivant sur place, notamment en cas de manifestations dans les capitales durant le week-end, et a rappelé que la liste des sources a été actualisée, avec Global Shift informé de cette mise à jour.
  + **Difficultés de Vérification UGC:** Stéphane a expliqué que la vérification des contenus UGC est rendue complexe par l'absence de cartes en persan pour identifier les bâtiments et rues, obligeant l'équipe à utiliser des images satellites pour vérifier l'état des lieux, ce qui prend beaucoup de temps.
  + **Sécurité et Précautions:** Il a été souligné que de nombreuses images sont floutées par les manifestants pour des raisons de sécurité, ce qui complique encore la vérification, et que des images générées par IA circulent également, nécessitant une grande prudence dans la publication.
  + **Procédures et Coordination:** L'équipe a rappelé que toutes les UGC sont bien téléchargées par les clients, que le sujet fait l'objet d'une vigilance accrue, et que les procédures doivent être suivies en coordination avec Global Shift.
* **Frappes Russes en Ukraine et Conséquences:** Marianne, Katia et l'équipe ont fait le point sur les frappes russes en Ukraine, détaillant le lancement de missiles et drones, les conséquences humaines et matérielles, ainsi que les difficultés rencontrées pour la transmission des images en raison de coupures internet.
  + **Détails des Frappes:** Il a été rapporté que 36 missiles, dont un missile balistique à capacité nucléaire, et 242 drones ont été lancés contre l'Ukraine, en réponse à une attaque supposée sur une résidence de Poutine, causant notamment 4 morts à Kiev et des dégâts à l'ambassade du Qatar.
  + **Situation des Équipes sur Place:** L'équipe sur place va bien, bien que le traducteur Stash ait été particulièrement touché par la chute d'un drone près de son immeuble, causant de la peur mais sans victimes.
  + **Analyse du Missile:** La Russie affirme que ce missile est impossible à intercepter, et le pôle Inter travaille sur l'analyse de la portée symbolique de cette frappe, d'autant que la Russie ne disposerait que de peu d'unités de ce type de missile.
  + **Transmission des Images:** En raison d'un blocage internet, l'équipe a dû transmettre les images via Whatsapp, ce qui a affecté la qualité mais permis d'obtenir rapidement les premières images en direct.
* **Commémoration de l’Incendie de Crans-Montana et Procès Moretti:** Marianne, Fabrice et l’équipe ont couvert la commémoration de l’incendie de Crans-Montana, la mobilisation autour du procès du couple Moretti, et les efforts déployés pour assurer une couverture complète, malgré des conditions difficiles.
  + **Organisation de la Commémoration:** La cérémonie de commémoration, marquée par une minute de silence à 13h00 GMT dans toute la Suisse et la présence de personnalités comme Macron et le président italien Matarella, a été organisée à Martigny en raison des conditions météorologiques.
  + **Procès du Couple Moretti:** Le procès du couple Moretti, gérants du bar impliqué dans l’incendie, a débuté, avec une forte mobilisation médiatique et la possibilité d’une détention à l’issue de l’audience.
  + **Couverture Médiatique:** Fabrice, photographe, et plusieurs vidéastes, dont Élodie, ont assuré la couverture photo et vidéo, obtenant notamment les premières images du couple Moretti, malgré des conditions d’accès difficiles et un chaos organisationnel à Sion.
  + **Impact sur les Communautés:** Un reportage a été réalisé à Lutry, commune particulièrement touchée, où le club de football local a perdu 7 membres, et des reportages sur les funérailles en Italie ont également été produits, soulignant l’ampleur du drame.

Tâches de suivi:

* **Vérification des images UGC en Iran:** Vérifier les images UGC en utilisant les images satellites pour compenser l'absence de cartes persanes et la présence d'images floutées ou générées par IA. (l'équipe)
* **Mise à jour sur l’état de l’équipe à Kiev:** Confirmer les dernières nouvelles concernant les membres de l’équipe à Kiev, notamment ceux dont la situation reste à vérifier après les frappes. (l'équipe)

09/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Mise en Application de la Loi sur les Réseaux Sociaux en Australie:** David a présenté depuis Sydney les détails de l'entrée en vigueur de la nouvelle loi australienne sur les réseaux sociaux, en expliquant les mesures prises par les plateformes, les réactions des parties prenantes, et la couverture prévue par l'équipe, avec une attention particulière sur la réaction internationale et les défis techniques.
  + **Entrée en Vigueur de la Loi:** David a expliqué que l'interdiction officielle entre en vigueur à 13h GMT en Australie orientale, avec un dispositif de couverture prêt à être diffusé en différé pour alerter les principaux clients et suivre les développements en temps réel.
  + **Réactions des Plateformes:** David a précisé que certaines plateformes comme Metro ont déjà commencé à exclure les moins de 16 ans, tandis que d'autres, comme X, n'ont pas encore communiqué leur stratégie, ce qui nécessite une veille particulière, notamment sur les annonces potentielles de la part d'Elon Musk.
  + **Défis Juridiques et Techniques:** David a mentionné qu'il existe une contestation juridique en cours contre la loi, mais sans demande d'injonction immédiate, et que Reddit considère la loi comme juridiquement incorrecte sans confirmer une action légale, ce qui est relayé dans les médias australiens.
  + **Couverture Médiatique et Ressources:** L'équipe a prévu d'utiliser des stockshots de plateformes comme TikTok et Facebook, ainsi que des images d'adolescents avec des appareils électroniques, pour enrichir la couverture, et deux VJs seront mobilisés pour des vox pops et des reportages à Sydney.
  + **Limites de l’Application:** David a souligné que le gouvernement australien reconnaît que la couverture ne sera pas totale, mais que la responsabilité est transférée aux plateformes pour s'adapter, tout en sachant que certains jeunes pourront contourner les restrictions.
* **Assouplissement des Restrictions sur les Puces Nvidia en Chine:** Katharine a détaillé depuis Tokyo la décision de l'administration Trump d'autoriser Nvidia à vendre certaines puces avancées à la Chine, en exposant les enjeux de sécurité nationale, les réactions politiques américaines, et l'impact sur le marché des semi-conducteurs.
  + **Contexte de Sécurité Nationale:** Katharine a expliqué que les puces concernées alimentent des systèmes d'IA pouvant offrir un avantage militaire à la Chine, ce qui motive les restrictions américaines, tout en soulignant l'importance économique du marché chinois pour Nvidia.
  + **Effets sur l’Industrie Chinoise:** Elle a précisé que la politique américaine pourrait accélérer le développement de l'industrie locale des semi-conducteurs en Chine, Pékin encourageant les entreprises à adopter des alternatives nationales.
  + **Détails de la Décision:** La décision permet à Nvidia de vendre des puces comme la H200, qui restent en retrait par rapport aux modèles les plus avancés (Blackwell), mais qui ne sont qu'à 18 mois de retard technologique, ce qui représente une ouverture partielle du marché.
  + **Réactions Politiques:** Katharine a rapporté que la décision a été critiquée par des membres du Parti démocrate, certains avançant des soupçons de conflits d’intérêts, bien que ces allégations n’aient pas été vérifiées.
* **Reprise du Conflit Cambodge-Thaïlande et Couverture sur le Terrain:** Matthew a fait le point depuis Bangkok sur la reprise du conflit entre le Cambodge et la Thaïlande, en détaillant le déploiement des équipes sur le terrain, la situation humanitaire, et les stratégies de couverture multimédia prévues.
  + **Situation sur le Terrain:** Matthew a indiqué que le conflit a repris de façon similaire à juillet, avec des affrontements et un nombre important de déplacés, principalement en Thaïlande, et un bilan provisoire de 10 morts, dont 3 soldats thaïlandais et 7 civils cambodgiens.
  + **Déploiement des Équipes:** L’équipe cambodgienne s’est rendue dans la province frontalière pour réaliser des directs et collecter des témoignages, tandis que l’équipe thaïlandaise doit partir tôt le lendemain pour diversifier la couverture, avec l’appui d’un vidéaste local.
  + **Stratégie de Couverture:** La priorité est donnée à la couverture des évacués des deux côtés de la frontière, avec une adaptation des déplacements selon les informations reçues du terrain, et l’utilisation de moyens techniques innovants pour la transmission d’images en direct.
  + **Aspects Techniques:** L’équipe a testé l’utilisation de téléphones portables couplés à des lentilles d’appareils photo pour permettre des zooms lors des directs, ce qui s’est avéré efficace même dans des conditions de connexion parfois difficiles.
* **Tentative de Coup d’État au Bénin et Coordination de la Couverture:** Pierre a exposé depuis Abidjan les coulisses de la couverture de la tentative de coup d’État au Bénin, en détaillant la chronologie des événements, la mobilisation des équipes, la vérification des informations, et l’intervention régionale.
  + **Déroulement des Événements:** Pierre a décrit les deux scénarios classiques de coup d’État, précisant que cette fois-ci, des militaires ont pris la télévision pour annoncer la destitution du président Talon, ce qui a été rapidement vérifié par les correspondants sur place.
  + **Vérification et Alerte:** Grâce à des sources proches du président, l’équipe a pu confirmer rapidement que le président allait bien et que l’armée reprenait le contrôle, permettant d’alerter les clients avant la concurrence.
  + **Mobilisation des Bureaux:** Le bureau de Lagos a dépêché une équipe texte, photo et vidéo à la frontière, qui a pu rejoindre Cotonou pour réaliser des directs et compléter la couverture, en coordination avec le bureau d’Abidjan.
  + **Intervention Nigériane et Régionale:** Pierre a confirmé que l’armée nigériane est intervenue par des frappes aériennes pour soutenir le président, information d’abord obtenue en off puis confirmée officiellement, suivie par l’envoi de troupes du bloc ouest-africain.
  + **Analyse et Collaboration:** Pierre a souligné la rapidité de la réaction régionale, contrastant avec d’autres coups d’État récents au Sahel, et a mis en avant la collaboration efficace entre les équipes de Lagos et d’Abidjan, ainsi que la couverture exclusive obtenue.
* **Point sur les Conflits Internationaux en Cours:** L’équipe a fait un tour d’horizon des principaux conflits internationaux, notamment en RDC, Ukraine, Israël-Hamas, et d’autres, en préparant une synthèse des situations sur le terrain et de la présence des équipes.
  + **Synthèse des Conflits:** L’équipe a recensé sept conflits majeurs, dont la RDC avec l’avancée des troupes rwandaises, l’Ukraine, et la phase 2 du conflit Israël-Hamas, en soulignant la présence de correspondants sur place pour chaque zone.

Tâches de suivi:

* **Suivi des Réactions des Plateformes à la Loi Australienne:** Surveiller les annonces potentielles de la part de X (notamment Elon Musk) concernant leur conformité à l'interdiction en Australie. (David)
* **Collecte d’Images de Puces Nvidia:** Accroître le stock d’images de puces Nvidia lors de conférences, showcases ou autres événements pertinents. (Teams)
* **Point sur les Conflits Internationaux:** Rassembler et faire un point précis sur l’évolution des sept conflits majeurs, en s’appuyant sur les informations terrain disponibles. (Teams)

8/01/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Manifestations en Iran et Couverture Médiatique:** L'équipe, avec Chris en intervenant principal, a discuté de l'extension des manifestations en Iran, des difficultés de couverture sur place, des sanctions européennes et des stratégies pour obtenir des images malgré les restrictions, en se concentrant sur Téhéran et l'utilisation de contenus générés par les utilisateurs (UGC).
  + **Extension des Manifestations:** Chris a expliqué que les manifestations en Iran s'étendent désormais à plusieurs villes, rendant la couverture particulièrement complexe, notamment en raison des restrictions imposées aux journalistes qui restent cantonnés à Téhéran.
  + **Difficultés de Couverture:** L'équipe a souligné que les actions sur le terrain sont très difficiles, la plupart des images disponibles étant limitées à des scènes de vie quotidienne génériques, prises par leur photographe à Téhéran pour éviter tout risque.
  + **Utilisation de l'UGC:** Ils récupèrent ou reçoivent quelques contenus générés par les utilisateurs (UGC) lorsque cela est possible, mais la majorité des images proviennent de Téhéran, où leur photographe se limite à des prises de vue sans danger.
  + **Sanctions et Contexte Économique:** Le groupe a brièvement évoqué l'effondrement économique lié aux sanctions européennes, ce qui complique davantage la situation sur place et la couverture médiatique.
  + **Stratégie de Suivi:** L'équipe prévoit de suivre l'évolution de la situation dans les prochains jours afin de déterminer s'il sera possible de mettre en place une nouvelle stratégie de couverture ou de relation sur le terrain.
* **Affaire de la Femme Tuée à Minneapolis et Réactions:** L'équipe, avec Sébastien en intervenant principal, a analysé l'incident impliquant la mort d'une femme lors d'une opération policière à Minneapolis, les réactions des autorités américaines, la couverture médiatique, et les actions prévues pour approfondir le portrait de la victime et suivre les suites de l'enquête.
  + **Contexte de l'Opération Policière:** Sébastien a détaillé qu'une vaste opération de la police de l'immigration (ICE) à Minneapolis a mobilisé 2000 agents pour arrêter des personnes en situation irrégulière, mais la victime n'avait pas ce profil, étant une Américaine de 37 ans, mère de trois enfants, en situation régulière.
  + **Déroulement de l'Incident:** Selon les vidéos, la victime était dans sa voiture, n'a pas obéi aux injonctions de la police et a tenté de partir, ce qui a conduit un policier à tirer à bout portant sur le pare-brise, causant sa mort.
  + **Réactions des Autorités et Polémiques:** La ministre de la sécurité intérieure a immédiatement qualifié l'incident de terrorisme intérieur, soutenue par Trump qui a évoqué la légitime défense des policiers, bien que les vidéos ne confirment pas cette version ; des leaders démocrates et la ville de Minneapolis ont contesté cette qualification.
  + **Couverture Médiatique et Collecte d'Images:** L'équipe a obtenu les premières photos via Getty, montrant la voiture encastrée et l'airbag ensanglanté, et leur pigiste Karam a couvert les réactions et affrontements sur place, tandis qu'une équipe de Washington se rend à Minneapolis pour poursuivre la couverture.
  + **Enquête et Actions à Venir:** Une enquête officielle est ouverte pour déterminer les circonstances de l'incident et la justification de la qualification de terrorisme intérieur ; l'équipe prévoit de réaliser un portrait de la victime et de suivre les développements, notamment les manifestations et les réactions politiques.

Tâches de suivi:

* **Portrait de la victime de Minneapolis:** Réaliser un portrait détaillé de la femme tuée à Minneapolis, en vérifiant son profil et son passé pour clarifier les circonstances de l’incident. (Teams)
* **Vérification des soins apportés après la fusillade:** Vérifier si les policiers ont empêché l’accès à la victime pour lui donner des soins et clarifier les faits à ce sujet. (Teams)

6/01/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Crise Politique et Humanitaire au Venezuela:** L'équipe a discuté en détail de la situation actuelle au Venezuela, notamment la couverture médiatique des événements à New York et Caracas, la prestation de serment de Delcy Rodriguez, les attaques américaines, le flou autour du nombre de victimes, et les perspectives de transition politique, avec des interventions de plusieurs membres de l'équipe sur les reportages en cours et les difficultés rencontrées.
  + **Couverture Médiatique à New York et Caracas:** L'équipe a couvert la comparution de Maduro devant le tribunal à New York, où il a clamé son innocence, ainsi que la prestation de serment de Delcy Rodriguez à Caracas, devenue présidente. Les reportages ont mis en avant la difficulté d'obtenir des images clés, notamment celles de l'arrivée de Maduro en hélicoptère, qui ont été diffusées par d'autres agences comme Reuters et Bloomberg.
  + **Attaques et Victimes Civiles:** Un reportage a été réalisé dans le quartier La Voile à Caracas, où une attaque américaine a causé d'importants dégâts matériels et la mort d'une femme, avec le témoignage de son neveu. Le nombre de morts reste incertain, les informations hospitalières étant très opaques et difficiles à obtenir.
  + **Transition Politique et Rôle de Washington:** La discussion a porté sur la possible transition politique au Venezuela, Washington ayant exprimé son refus d'élections immédiates. Valia Colina Mattia a également évoqué son souhait de rentrer et de jouer un rôle, bien que la nature de ce rôle reste indéterminée.
  + **Reportages sur l’Armée et la Diaspora:** Deux reportages validés sont en cours : l’un à la frontière avec les militaires et des déserteurs, qui se montrent pessimistes quant à un changement de régime ou de rôle de l’armée ; l’autre à Bogota sur la diaspora, qui exprime un manque de confiance et n’envisage pas de retour prochain au Venezuela.
  + **Défis de la Couverture et Manque d’Images:** L’équipe a souligné la difficulté d’obtenir certaines images essentielles, notamment celles de Maduro et de son épouse, ce qui a nui à la couverture médiatique par rapport à d’autres agences internationales.
* **Discussions sur la Paix en Ukraine à Paris:** Marianne a présenté les discussions en cours à Paris sur la paix en Ukraine, impliquant des leaders internationaux comme Macron et Starmer, avec un focus sur les modalités d’un cessez-le-feu, la création d’une force multinationale, et les positions divergentes de la Russie, tandis que tous les bureaux européens suivent la conférence de presse prévue.
  + **Participants et Objectifs de la Réunion:** Les discussions rassemblent des leaders de plusieurs pays, dont Macron et Starmer, pour aborder la paix en Ukraine, les modalités d’un cessez-le-feu, et la possibilité d’une force multinationale pour garantir la sécurité en cas d’accord de paix.
  + **Position de la Russie:** La Russie refuse catégoriquement la présence de troupes de l’OTAN sur le sol ukrainien et s’oppose à un cessez-le-feu temporaire, ce qui complique les négociations et limite les avancées possibles lors de la réunion.
  + **Attentes et Annonces Possibles:** Selon Francesco, des annonces importantes pourraient être faites, notamment sur les pays prêts à contribuer à une force multinationale ou à fournir un soutien logistique ou financier, bien que les détails restent à confirmer lors de la conférence de presse prévue à 18h45.
  + **Suivi par les Bureaux Européens:** Tous les bureaux européens, notamment ceux de Berlin, Londres et Kiev, suivent de près la conférence de presse et les interventions de leurs leaders respectifs pour relayer les informations en temps réel.
* **Actualité du Football Européen et Multi-Club Ownership:** L’équipe a brièvement abordé l’actualité du football européen, notamment la situation de Manchester United sous la direction de Jim Ratcliffe, le licenciement de l’entraîneur de Chelsea, et l’exemple de la multipropriété de clubs avec Strasbourg, en soulignant les implications pour la gestion et le développement des clubs.
  + **Situation de Manchester United:** Manchester United, malgré des difficultés sur le terrain, reste le club le plus riche du monde sous la direction de Jim Ratcliffe, avec des questions persistantes sur la stratégie et l’ingérence dans la gestion du club.
  + **Multipropriété de Clubs:** L’exemple de Strasbourg, détenu par les mêmes propriétaires que Chelsea, illustre la tendance croissante à la multipropriété de clubs en Europe, permettant des synergies mais soulevant aussi des questions sur l’indépendance et la gestion sportive.
  + **Changements d’Entraîneurs:** Chelsea a récemment limogé son entraîneur Enzo Maresca, tandis que Liam Rossignol, nouvel entraîneur de Strasbourg, est présenté comme un exemple de mobilité dans le coaching européen.

Tâches de suivi:

* **Manque d’images clés sur Maduro:** Identifier et obtenir, si possible, des images manquantes de Maduro et de sa femme lors du transfert au tribunal. (Teams)
* **Annonces potentielles sur la paix en Ukraine:** Surveiller et relayer toute annonce importante issue de la conférence de presse prévue à l’Élysée concernant la paix en Ukraine. (Teams)

02/01/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Couverture de l'incendie en Suisse:** L'équipe, avec la coordination de Martin, Olivier, Fabrice Coffrini et Maxime Schmitt, a assuré une couverture rapide et complète de l'incendie à Crans-Montana, devançant les agences concurrentes et mobilisant des ressources photo, vidéo et rédactionnelles malgré les contraintes de vacances.
  + **Réactivité et organisation:** Martin et l'équipe ont souligné leur avance sur AP et Reuters grâce à une alerte précoce et une organisation rapide, bien que la mobilisation des pigistes ait pris un peu de temps. La couverture s'est déroulée efficacement, notamment en photo, avec une grande avance sur les concurrents.
  + **Mobilisation des photographes:** Fabrice Coffrini, photographe en Suisse, a été alerté très tôt et a contacté Maxime Schmitt, pigiste local, qui a pu se rendre rapidement sur place. Leur présence a permis d'obtenir des images exclusives avec quatre heures d'avance sur Reuters, assurant une forte visibilité dans les médias tout au long de la journée.
  + **Production vidéo et vérification:** Le bureau de Hong Kong a réagi rapidement en vérifiant les contenus UGC dès l'alerte, permettant la diffusion rapide de la première vidéo authentifiée grâce à un touriste new-yorkais. Les fact-checkers ont validé la vidéo originale et ses métadonnées, accélérant la couverture vidéo.
  + **Défis logistiques et renforts:** En raison des vacances, il a été difficile de mobiliser des journalistes et pigistes, mais deux équipes ont finalement été dépêchées depuis Paris et Lyon, arrivant sur place vers 19h. Maxime Schmitt a également aidé la vidéo, permettant la diffusion d'images d'ambulances et la récupération de sources suisses officielles.
  + **Poursuite de la couverture et perspectives:** La couverture se poursuit avec des envoyés spéciaux sur place, un reportage prévu près de l'hôpital à Sion, un récit basé sur des témoignages recueillis via les réseaux sociaux, et la possibilité d'une nouvelle conférence de presse de la police cantonale dans la journée.
* **Analyse de la contestation en Iran:** Anna et l'équipe ont discuté des difficultés de couverture du mouvement de contestation en Iran, de la réaction internationale, des contraintes éditoriales et de la stratégie pour contextualiser et analyser l'ampleur du mouvement à travers des sources variées et des dataviz.
  + **Contexte et évolution du mouvement:** Le mouvement, initialement centré sur la vie chère, s'est étendu à plusieurs villes et traduit un ressentiment plus large contre les autorités. Anna précise qu'il s'agit désormais d'un mouvement de contestation, sans pouvoir employer le terme de révolte, et rappelle les précédents historiques de manifestations en Iran.
  + **Contraintes éditoriales et sécuritaires:** La couverture depuis Téhéran est très limitée : il est impossible de citer ou d'interviewer des personnes, de publier certaines informations ou images, et les journalistes sont soumis à des contrôles stricts. Pour contourner ces contraintes, des copies parallèles datées de Paris sont envisagées afin de relayer des informations plus complètes.
  + **Vérification des sources et vidéos:** La vérification des vidéos issues des réseaux sociaux est complexe, car la perception en ligne diffère de la réalité sur le terrain. Katia et l'équipe insistent sur la nécessité de croiser les sources, d'utiliser des relais de réseaux de droits humains et d'experts pour évaluer l'ampleur réelle du mouvement.
  + **Dataviz et contextualisation:** Une actualisation des repères sur vingt ans de contestation en Iran est en cours, mettant en avant l'évolution des mouvements et notamment l'impact du décès de Mahsa Amini sur la question du port du voile. Les dataviz permettront de suivre l'évolution du nombre de morts et la répartition géographique des manifestations.
  + **Réactions internationales et enjeux:** L'équipe mentionne la réaction de Donald Trump et la réponse de l'Iran, qui accuse les États-Unis d'ingérence. Le contexte régional, marqué par l'affaiblissement des alliés de l'Iran et les tensions récentes avec Israël, est pris en compte pour analyser les enjeux et la possible évolution du mouvement.

Tâches de suivi:

* **Conférence de presse de la police cantonale suisse:** Surveiller l'annonce de la nouvelle conférence de presse de la police cantonale suisse et communiquer l'heure exacte dès qu'elle sera confirmée. (Teams)
* **Actualisation de la dataviz sur les contestations en Iran:** Examiner la base de données commencée par Sébastien et proposer une solution pour faciliter la mise à jour de la dataviz sur les 20 ans de contestation en Iran. (Teams)

30/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Tensions Croissantes au Yémen entre l'Arabie Saoudite et les Émirats:** Rita a présenté une analyse détaillée de l'accélération des tensions au Yémen, mettant en avant la rivalité entre l'Arabie saoudite et les Émirats arabes unis, les récents bombardements, les communiqués diplomatiques, et les enjeux liés à la division du pays, avec la participation active de l'équipe pour la couverture terrain et la production de contenus explicatifs.
  + **Contexte du Conflit au Sud:** Rita a expliqué que les combats dans le sud du Yémen se sont intensifiés, avec le Conseil de transition du Sud (STC) revendiquant ouvertement la division du pays et la refondation de l'État du Sud, qui existait avant la réunification de 1990.
  + **Rivalité Arabie Saoudite-Émirats:** Rita a souligné la montée de la rivalité entre l'Arabie saoudite et les Émirats, illustrée par deux communiqués saoudiens : le premier évoquant une escalade dangereuse tout en maintenant un ton diplomatique, le second soutenant la demande du gouvernement yéménite pour le retrait des forces émiraties sous 24 heures.
  + **Actions Militaires et Couverture Terrain:** Rita a rapporté que l'Arabie saoudite a bombardé la région de Mukala après avoir lancé un ultimatum et une demande d'évacuation, sans pertes humaines majeures, et que l'équipe dispose d'images de véhicules détruits et d'une vidéo d'un grand rassemblement en faveur de l'indépendance du Sud.
  + **Difficultés de Communication et Production de Contenus:** Rita a mentionné la difficulté de communication avec les pigistes sur place, souvent politisés, et a indiqué que l'équipe attend la livraison d'un explainer et travaille sur un papier d'angle axé sur la rivalité Émirats-Arabie, tout en mettant la pression pour accélérer la production.
  + **Perspectives et Limites de l'Escalade:** Rita a estimé qu'une guerre ouverte dans le Golfe est peu probable en raison des intérêts économiques communs, mais que l'Arabie saoudite n'acceptera pas une expansion de forces anti-saoudiennes à sa frontière, rappelant l'intervention de 2015 contre les Houthis.
* **Couverture Médiatique des Frappes et Témoignages au Yémen:** L'équipe, incluant Katia, Olivier et Jean-Pierre, a assuré une publication rapide des premières images des frappes au port yéménite, recueilli des témoignages de victimes et obtenu des vidéos de la coalition menée par l'Arabie saoudite, renforçant la couverture terrain de la situation.
  + **Diffusion Rapide des Images:** L'équipe a été parmi les premières à publier des images des frappes sur le port, permettant une couverture immédiate de l'événement.
  + **Recueil de Témoignages Locaux:** Des témoignages de personnes dont les maisons ont été touchées par les frappes ont été obtenus, apportant un éclairage humain à la couverture.
  + **Vidéos de la Coalition:** L'équipe a également obtenu des vidéos montrant les mouvements de la coalition menée par l'Arabie saoudite, notamment sur les bateaux, enrichissant la documentation visuelle de la situation.
  + **Images des Bombardements Récents:** Des images des bombardements et des véhicules endommagés du matin même ont été collectées, complétant la couverture en temps réel des événements.
* **Exercices Militaires Chinois près de Taïwan:** Olivier a signalé que l'équipe est la première agence à disposer d'images et de contexte sur les tirs d'exercice des forces chinoises près de Taïwan, assurant une couverture exclusive depuis le début de la matinée.
  + **Obtention d'Images Exclusives:** Olivier a précisé que l'équipe a obtenu des images des tirs d'exercice chinois à proximité de Taïwan, ce qui constitue une exclusivité parmi les agences de presse.
* **Préparation du Papier Nouvel An:** L'équipe a rappelé que le papier sur le Nouvel An doit être finalisé pour 20h00 GMT, avec le MAP déjà rédigé et en édition, et a invité les membres à envoyer leurs contributions régionales dignes d'intérêt avant la deadline.
  + **Instructions de Soumission:** Il a été demandé aux membres de transmettre leurs contributions régionales pour le papier Nouvel An avant 20h00 GMT, le MAP étant déjà en cours d'édition par les desks français et espagnol.

Tâches de suivi:

* **Pression pour l’Explainer sur le Conflit Arabie-Émirats:** Faire pression pour accélérer la réception de l’explainer sur le conflit entre l’Arabie saoudite et les Émirats. (Rita)
* **Contributions au Papier Nouvel An:** Envoyer toute contribution régionale digne d’intérêt pour le papier Nouvel An avant la publication à 20h00 GMT. (tous les membres)

24/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Discussions Sur Le Plan De Paix En Ukraine:** L'équipe, avec Karim, a discuté du plan américain révisé pour mettre fin à la guerre en Ukraine, des négociations entre Américains, Ukrainiens et Russes, et des attentes de réponse de la part des Américains et des Européens, en s'appuyant sur les informations partagées par Zelensky lors d'une conférence de presse off.
  + **Présentation Du Plan Américain:** Karim a expliqué qu'un premier plan américain en 20 points, issu de l'administration Trump, a été présenté pour mettre fin à la guerre en Ukraine, mais il était perçu comme une capitulation pour l'Ukraine.
  + **Évolution Des Négociations:** Des discussions ont eu lieu entre Américains, Ukrainiens et Russes, notamment trois jours de négociations à Miami, aboutissant à un texte plus équilibré selon les propos rapportés par Zelensky.
  + **Points Clés Du Texte:** Le texte actuel, lu par Zelensky, aborde la question du contrôle des territoires, notamment Donetsk, et propose que la ligne de front actuelle serve de base au partage des territoires ; la question de l'entrée de l'Ukraine dans l'OTAN reste floue, et la gestion de la centrale nucléaire de Zaporizhzhia serait co-administrée par plusieurs parties.
  + **Attente De Réponses:** Zelensky a transmis le texte aux Américains et attend une réponse sur les points litigieux, tandis que les réactions des Russes et des Européens, informés par les Ukrainiens, sont également attendues.
  + **Gestion Médiatique Et Alertes:** L'équipe a diffusé plusieurs alertes sur les points saillants du texte, notamment sur les risques liés à la centrale nucléaire, après avoir échangé avec son directeur, et a assuré la coordination avec les desks pour la couverture médiatique.
* **Organisation De La Couverture Médiatique De Noël:** Alice, en direct de Bethléem, a présenté le dispositif de couverture des célébrations de Noël, incluant des directs vidéo, des reportages texte, et la coordination avec le bureau de Rome pour la messe du pape, avec la participation de Nico et la mobilisation de l'ensemble du réseau.
  + **Déploiement À Bethléem:** Alice a décrit l'ambiance festive à Bethléem, la présence du patriarche latin de Jérusalem, la préparation de voxpops avec Yannick, Aurélie et Bilal, et l'envoi d'un wrap texte au bureau, avec des mises à jour prévues toute la journée.
  + **Directs Vidéo Et Couverture Continue:** Nico assure des directs vidéo toute la journée depuis Bethléem, avec le dernier live prévu à 22h00 GMT, et des images complémentaires des célébrations dans d'autres communautés sont également prévues.
  + **Coordination Avec Rome Et Autres Bureaux:** Le bureau de Rome prendra le relais le lendemain matin pour la messe du pape, point d'orgue de la couverture, tandis que la famille royale britannique sera couverte dans l'après-midi du 25 décembre.
  + **Instructions Pour Les Desks:** Les desks sont invités à enrichir leurs copies texte avec les images et vidéos reçues, afin d'apporter de la couleur à la couverture, et à surveiller les contenus qui tombent en photo et vidéo.
* **Gestion Des Alertes Sur La Centrale Nucléaire:** L'équipe a évoqué la diffusion d'alertes spécifiques concernant les risques liés à la centrale nucléaire, en lien avec les discussions sur le plan de paix et après échange avec le directeur de la centrale.
  + **Alertes Sur Les Risques Nucléaires:** Deux alertes ont été diffusées concernant les risques d'une éventuelle frappe supplémentaire sur le dôme de la centrale nucléaire, après un échange avec le directeur de la centrale.

Tâches de suivi:

* **Mise à jour du wrap de Bethléem:** Envoyer le wrap initial sur Bethléem au bureau, puis le traduire, l’éditer et le mettre à jour tout au long de la journée. (Alice)
* **Couverture photo de la rencontre journalistes:** Vérifier et partager les photos de la rencontre avec les journalistes si elles sont disponibles. (Teams)
* **Alertes sur la centrale nucléaire:** Surveiller et alerter sur les risques liés à une éventuelle frappe supplémentaire sur le dôme de la centrale nucléaire. (Teams)
* **Ajout de couleurs dans la copie texte:** Bien intégrer les images photo et vidéo reçues pour enrichir la copie texte lors de la reprise par le desk. (Teams)

23/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Crise Entre Les États-Unis Et Le Venezuela:** Les participants, dont Gabrielle, ont discuté en détail de l'escalade des tensions entre les États-Unis et le Venezuela, abordant les récentes pressions politiques, les incidents maritimes impliquant des tankers, les réactions internationales, et la couverture médiatique prévue, notamment la réunion du Conseil de sécurité.
  + **Pression Politique Américaine:** Les participants ont évoqué l'intensification de la pression exercée par les États-Unis sur le Venezuela, citant les déclarations de Trump qui a suggéré la démission du dirigeant vénézuélien et n'a pas exclu la possibilité d'une guerre, tout en soulignant que la pression s'exerce sur plusieurs fronts, notamment politique et économique.
  + **Incidents Maritimes Et Sanctions:** Il a été rapporté que deux bateaux ont été arraisonnés et un troisième poursuivi par les gardes-côtes américains, avec des précisions sur le fait que l'un des navires n'était pas sur la liste des bateaux sanctionnés, mais transportait du pétrole sous sanction appartenant à la compagnie pétrolière vénézuélienne.
  + **Impact Sur Le Secteur Pétrolier:** Les discussions ont souligné le risque d'effondrement de la production pétrolière vénézuélienne, rappelant la grève de 2002, et notant que la réduction des capacités de stockage pourrait avoir un impact économique majeur sur la principale source de devises du pays.
  + **Réactions Internationales:** Il a été mentionné que la Russie et la Chine ont exprimé leur soutien au Venezuela, avec une conversation entre le ministre vénézuélien et son homologue russe Lavrov, dans le contexte des nouvelles doctrines de sécurité américaine visant à renforcer l'influence des États-Unis dans l'hémisphère occidental.
  + **Couverture Médiatique Et Actions À Venir:** Gabrielle a indiqué que la couverture vidéo inclut l'arraisonnement des tankers, la réaction de Maduro, et une manifestation anti-Trump, et a précisé qu'un direct serait assuré lors de la réunion du Conseil de sécurité prévue dans l'après-midi.
* **Sélection De Photos Par Le Guardian:** Les participants ont discuté de la sélection par le Guardian de plusieurs photographes, dont Roman Pilipal, Louise Tatto et Olivia, pour un diaporama marquant l'année, et ont mentionné la reconnaissance régulière du travail photographique par ce média.
  + **Photographes Sélectionnés:** Le Guardian a choisi trois photographes, dont Roman Pilipal, Louise Tatto et Olivia pour l'Afrique, pour illustrer leur diaporama annuel, en collaboration avec Reuters, AFP et Angetti.
  + **Reconnaissance Du Travail:** Il a été noté que le Guardian envoie régulièrement des messages pour exprimer son appréciation du travail photographique fourni, soulignant la qualité et l'originalité de la couverture des événements.

Tâches de suivi:

* **Images du Troisième Tanker Arraisonné:** Surveiller et récupérer les images du troisième tanker arraisonné dès qu'elles seront disponibles. (Gabrielle)
* **Couverture du Conseil de Sécurité en Direct:** Assurer la couverture en direct du Conseil de sécurité cet après-midi concernant la crise entre les États-Unis et le Venezuela. (Gabrielle)

22/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Explosion Mortelle d'un Général Russe à Moscou:** L'équipe, menée par Teams, a couvert l'explosion ayant tué le général russe Fanil Salvarov à Moscou, abordant les soupçons des autorités russes envers l'Ukraine, l'impact potentiel sur les négociations internationales, et la mobilisation rapide des équipes sur place.
  + **Détails de l'Attentat:** Teams a rapporté la mort du général russe Fanil Salvarov, responsable de la formation opérationnelle au sein de l'État-major, tué lors de l'explosion de sa voiture dans le sud de Moscou, près de la périphérie résidentielle.
  + **Réactions et Enquête:** Les autorités russes ont lancé une enquête et soupçonnent une implication des services de sécurité ukrainiens, tandis que les autorités ukrainiennes n'ont pas encore réagi ; cette attaque s'inscrit dans une série de meurtres de hauts responsables russes depuis 2022, Moscou accusant systématiquement Kiev.
  + **Conséquences Diplomatiques:** Teams a soulevé la question de l'impact de cet événement sur les pourparlers en cours sur l'Ukraine, l'explosion survenant peu après un round de négociations à Miami impliquant des émissaires russes, ukrainiens, américains et européens, sans avancée majeure.
  + **Couverture Médiatique et Visuelle:** L'équipe a envoyé rapidement des journalistes sur place, obtenant et diffusant les premières images de la voiture détruite, ainsi que des photos de Sasha Nemenoff et des vidéos, en soulignant que la concurrence n'avait pas encore diffusé ces contenus.
  + **Initiatives Diplomatiques Annexes:** Teams a mentionné des signaux diplomatiques entre Paris et Moscou, dont la possibilité d'un entretien entre Emmanuel Macron et Vladimir Poutine, et une tentative avortée de rencontre entre émissaires russe et ukrainien à Miami, illustrant la complexité du contexte.
* **Nouvelles Révélations sur l'Attaque de Bondi Beach en Australie:** Oliver et Teams ont détaillé la publication de documents judiciaires concernant l'attaque de Bondi Beach, la rapidité de la couverture par leur équipe, les excuses du Premier ministre australien, et les enjeux politiques et médiatiques associés.
  + **Publication de Documents Judiciaires:** Oliver a expliqué que la levée d'une ordonnance de suppression a permis à leur correspondante Laura d'obtenir rapidement le dossier de police sur l'un des suspects survivants, comprenant des images marquantes d'entraînements armés et de symboles extrémistes.
  + **Réactivité de la Rédaction:** L'équipe a été en mesure d'alerter rapidement et de diffuser ces images avant la concurrence, notamment Reuters, grâce à l'expérience de Laura dans la couverture judiciaire australienne.
  + **Excuses du Premier Ministre:** Teams et Oliver ont mentionné les excuses publiques du Premier ministre australien, sous pression pour sa réaction jugée tardive face à l'antisémitisme, et la diffusion de vidéos d'excuses et d'images de commémorations.
  + **Enquête et Législation:** Teams a signalé la poursuite de l'enquête, la publication de nouvelles révélations, et la diffusion d'un handout parlementaire sur un projet de loi antiterroriste, ainsi que la couverture des cérémonies et de l'ambiance à Bondi Beach.
* **Lancement de la Coupe d'Afrique des Nations au Maroc:** Teams, Andrew et plusieurs coordinateurs ont assuré la couverture du lancement de la CAN au Maroc, détaillant la victoire du pays hôte, l'organisation inédite pendant les fêtes, la mobilisation des équipes sur place, et les enjeux sportifs et médiatiques.
  + **Déroulement de la Compétition:** Teams a annoncé la victoire du Maroc lors du match d'ouverture contre les Comores, soulignant l'organisation exceptionnelle de la CAN pendant la période de Noël et du Nouvel An, avec plusieurs envoyés spéciaux mobilisés.
  + **Couverture sur le Terrain:** Andrew a décrit l'ambiance à Rabat, la présence du prince héritier, la couverture des matchs à venir, et la coordination entre les reporters, vidéastes et photographes répartis entre différentes villes marocaines.
  + **Enjeux et Pression sur le Maroc:** Andrew a insisté sur la pression ressentie par le Maroc, favori de la compétition, et sur l'attente populaire, rappelant la fierté nationale après la demi-finale de la Coupe du monde 2022 et la ferveur dans tout le pays.
  + **Production de Contenus:** Teams et Katia ont détaillé la production de vox pop, la couverture de l'entraînement de Salah, la gestion des droits vidéo, et la mobilisation de coordinateurs et JRI de différentes régions africaines pour assurer une couverture complète.
  + **Organisation des Équipes:** Teams a précisé la présence de six photographes et d'une équipe d'encadrement, la réalisation de l'ouverture et des entraînements, et la production de contenus sur l'ambiance autour de la compétition.
* **Enquête sur les Mercenaires Colombiens au Soudan:** Teams et Bahira ont présenté un long format collaboratif sur le recrutement de mercenaires colombiens pour combattre au Soudan, détaillant la rigueur de l'enquête, la vérification des informations, et l'impact international de la publication.
  + **Collaboration Internationale:** Teams a expliqué que l'enquête a mobilisé plusieurs bureaux (Le Caire, Soudan, Bogota, Nairobi) et a été massivement reprise par les médias francophones, anglophones, arabophones et hispanophones.
  + **Méthodologie de Vérification:** Bahira a détaillé la rigueur du travail, notamment la géolocalisation de vidéos envoyées par des milices, la vérification minutieuse de chaque élément, et la difficulté d'obtenir des réponses officielles malgré des sollicitations nocturnes.
  + **Conséquences et Sanctions:** Bahira a souligné que l'enquête a eu un impact concret, les États-Unis ayant sanctionné ce mois-ci l'opération, le colonel colombien impliqué et la société panaméenne traitant les paiements.
  + **Enjeux Politiques Internationaux:** Bahira a évoqué l'importance de ces révélations dans le contexte de la position américaine sur le Soudan, et la possible implication future des États-Unis dans la région.

Tâches de suivi:

* **Suivi de l'impact de l'enquête sur les mercenaires colombiens:** Suivre l'impact potentiel de l'article sur le recrutement de mercenaires colombiens au Soudan et envisager un suivi si nécessaire. (Teams)

16/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Enquête sur l'attentat de Sydney:** Joshua a présenté l'avancement de l'enquête sur l'attentat de Sydney, soulignant que les deux suspects étaient inspirés par l'État islamique et avaient séjourné aux Philippines, tandis que l'équipe de Sydney assure une couverture photographique et vidéo de qualité relayée par de nombreux médias internationaux.
  + **Séjour des suspects aux Philippines:** Joshua a expliqué que les deux suspects de l'attentat de Sydney avaient passé le mois de novembre dans le sud des Philippines, une région connue pour la présence de groupes affiliés à l'État islamique, notamment Abusayef, bien qu'aucun lien direct n'ait été établi à ce stade.
  + **Chronologie de l'attaque:** Joshua a mentionné la mise en place d'une chronologie détaillée retraçant le déroulement de l'attaque, incluant les victimes, les modalités de la fusillade et l'intervention d'un héros ayant désarmé l'un des tireurs.
  + **Identification des victimes:** L'équipe suit l'identification progressive des victimes, parmi lesquelles figurent deux survivants de l'Holocauste, et reste attentive à la publication de nouveaux éléments.
  + **Couverture médiatique et photographique:** L'équipe de Sydney, composée de deux photographes, assure une couverture suivie de l'événement, leurs clichés étant largement repris par des médias internationaux tels que le Financial Times et Le Monde, et complétés par des vidéos et des images du héros de l'attaque.
* **Assouplissement de l'objectif européen sur les voitures électriques:** Sophie a détaillé les propositions de la Commission européenne visant à assouplir l'objectif de 100% de voitures électriques neuves en 2035, en permettant une réduction de 90% des émissions de CO2 et en laissant une marge pour les hybrides et thermiques, dans un contexte de recul des politiques climatiques.
  + **Proposition d'assouplissement:** Sophie a expliqué que la Commission européenne envisage de remplacer l'objectif de 100% de voitures électriques neuves en 2035 par une réduction de 90% des émissions de CO2, permettant ainsi la vente d'une minorité de véhicules hybrides ou thermiques.
  + **Réactions des constructeurs automobiles:** Les constructeurs automobiles, notamment allemands, ont critiqué la mesure initiale, invoquant des difficultés de compétitivité, ce qui a motivé la proposition d'assouplissement.
  + **Calendrier et communication:** La décision doit être actée lors d'une réunion de la Commission européenne à Strasbourg, suivie d'une conférence de presse prévue à 15h30, avec la possibilité d'une interview du vice-président de la Commission.
  + **Contexte européen et international:** L'équipe a rappelé que 2025 marque un recul des politiques climatiques en Europe, avec plusieurs mesures phares suspendues ou repoussées, et que d'autres pays comme les États-Unis et le Royaume-Uni envisagent également d'abandonner des objectifs similaires.
* **Litige financier entre Mbappé et le PSG devant les prud'hommes:** L'équipe a présenté le litige opposant Mbappé à son ancien employeur le PSG devant les prud'hommes, où le joueur réclame 263 millions d'euros pour requalification de contrat et divers préjudices, tandis que le club contre-attaque avec une demande de 440 millions d'euros.
  + **Montants et motifs des réclamations:** Mbappé réclame initialement 55 millions d'euros pour salaires et primes impayés, montant porté à 263 millions d'euros devant les prud'hommes pour requalification de son CDD en CDI, licenciement sans cause, harcèlement moral et travail dissimulé.
  + **Contre-attaque du PSG:** Le PSG réclame 440 millions d'euros à Mbappé, invoquant un accord verbal antérieur selon lequel le joueur s'engageait à ne pas léser financièrement le club en cas de départ libre.
  + **Procédure et enjeux:** L'affaire est jugée devant les prud'hommes, avec une audience prévue à 13h00, mais l'issue reste incertaine en raison des montants en jeu et de la forte médiatisation, ce qui pourrait conduire à un renvoi devant un juge professionnel.

Tâches de suivi:

* **Décision Prud’homale PSG/Mbappé:** Vérifie et communique le résultat du Conseil des prud’hommes concernant le litige financier entre Mbappé et le PSG après l’audience de 13h00. (Teams)
* **Annonce Commission Européenne sur les Voitures Électriques:** Couvre la conférence de presse de la Commission européenne à 15h30 à Strasbourg et partage les mesures finales annoncées concernant l’objectif 2035 pour les voitures électriques. (Sophie)
* **Interview avec le Vice-Président de la Commission Européenne:** Réalise et diffuse l’interview prévue avec le vice-président de la Commission européenne sur les mesures pour le secteur automobile. (Sophie)

Lundi 29 décembre

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Rencontre Trump-Netanyahou et Situation au Proche-Orient:** Anne a présenté les enjeux de la rencontre entre Trump et Netanyahou aux États-Unis, abordant la deuxième phase du cessez-le-feu à Gaza, les attentes israéliennes, la position du Hamas, ainsi que la question iranienne, tout en mentionnant la pression médiatique américaine.
  + **Enjeux de la Rencontre:** Anne a expliqué que la rencontre entre Trump et Netanyahou, la cinquième de l'année aux États-Unis, portera principalement sur la deuxième phase du cessez-le-feu en vigueur depuis le 10 octobre, incluant le désarmement du Hamas, le retrait progressif de l'armée israélienne de Gaza et la mise en place d'une autorité de transition.
  + **Blocages et Pressions:** Anne a souligné que les discussions sur la deuxième phase du cessez-le-feu piétinent, avec des médias à Washington qui souhaitent accélérer la pression sur Netanyahou, tandis qu'Israël attend le retour du corps d'un dernier otage et que le Hamas refuse de désarmer, proposant seulement un gel des stocks d'armes.
  + **Question Iranienne:** Anne a précisé que la question de l'Iran sera également abordée lors de la rencontre, avec la possibilité de nouvelles frappes évoquée par les deux dirigeants.
* **Manifestations en Iran et Impact Économique:** Anne a informé Emmanuel de la tenue de manifestations de commerçants en Iran contre l'hyperinflation et la dépréciation de la monnaie, précisant que Terence prépare un article approfondi sur le sujet.
  + **Manifestations et Blocage Commercial:** Anne a détaillé que des commerçants iraniens ont manifesté contre l'inflation et la chute historique de la monnaie, ce qui bloque les transactions car les vendeurs refusent de vendre, anticipant une hausse des prix le lendemain.
* **Suivi des Pourparlers Trump-Zelensky et Réactions Russes:** Marianne a fait le point sur le suivi des discussions entre Trump et Zelensky, indiquant que peu de progrès ont été réalisés sur les questions territoriales et de sécurité, et que l'équipe attend les réactions russes, notamment une éventuelle conférence de presse du Kremlin.
  + **État des Négociations:** Marianne a rapporté que les discussions entre Trump et Zelensky n'ont pas permis d'avancées significatives concernant le Donbass et les garanties de sécurité, selon les alertes reçues après une conférence de presse virtuelle de Zelensky.
  + **Actions de l'Équipe:** Marianne a précisé que Yann va rédiger un PRA axé sur les propos de Zelensky, tandis que l'équipe surveille les réactions russes et attend un éventuel appel entre Trump et Poutine ou une conférence de presse du porte-parole du Kremlin.
* **Décès de Brigitte Bardot : Traitement Médiatique et Organisation:** Virginie, appuyée par Jean-François Guillaume et l'équipe, a détaillé la gestion de l'annonce du décès de Brigitte Bardot, la préparation des contenus, la coordination avec les sources, et l'impact de la couverture sur la presse française et internationale, avec des compléments d'Olivier pour la photo et d'Ekaterina pour la vidéo.
  + **Préparation et Annonce:** Virginie a expliqué que l'équipe a été la première à annoncer le décès de Brigitte Bardot, grâce à une préparation en amont et à l'alerte de Jean-François Guillaume, qui a permis de diffuser rapidement un premier PG et plusieurs angles déjà prêts.
  + **Gestion des Sources et Exclusivité:** Virginie a précisé que l'exclusivité sur l'annonce du décès a été obtenue grâce à une relation de longue date avec l'attaché de presse de la Fondation Bardot, impliquant parfois la diffusion de démentis en échange d'informations privilégiées, tout en maintenant une certaine indépendance éditoriale.
  + **Impact Médiatique:** Virginie a souligné que les angles préparés par l'équipe ont été largement repris par la presse française, notamment par TF1 et Le Monde, et que la nouvelle a eu un fort retentissement, y compris dans la presse britannique.
  + **Traitement Photo et Vidéo:** Olivier a indiqué que 106 photos de Bardot ont été validées et massivement diffusées à l'international, occupant la quasi-totalité des téléchargements récents, tandis qu'Ekaterina a précisé que la production vidéo, bien que moins riche en archives, a été rapide et bien reprise par les clients français et internationaux.
  + **Suivi des Obsèques:** Virginie a ajouté qu'un nouveau PG daté de Saint-Tropez est prévu, alors que les préparatifs des obsèques s'accélèrent, sans que la date ou le lieu exact ne soient encore connus, et que l'équipe continue de décliner les angles préparés.

Tâches de suivi:

* **Manifestations des commerçants en Iran:** Préparer un article de fond sur les manifestations des commerçants en Iran contre l'inflation et la dépréciation monétaire. (Terence)
* **Suivi des pourparlers entre Trump et Zelensky:** Rédiger le PRA en intégrant les déclarations de Zelensky lors de la conférence de presse virtuelle concernant les pourparlers. (Yann)

15/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Couverture de l'attentat antisémite à Bondi Beach:** David a présenté la mobilisation rapide des équipes à Sydney, Hong Kong et Séoul pour couvrir l'attentat antisémite survenu à Bondi Beach, avec le soutien d'Ollie, Angela, Dean Chen, Linda Kwok, David Rey et Riley Weston, et la gestion des contenus UGC par Reuben.
  + **Mobilisation des équipes:** David a expliqué que l'attentat a eu lieu en fin de journée alors qu'une seule personne était présente à la rédaction, mais que l'ensemble du bureau s'est rapidement mobilisé, avec l'appui d'Ollie à Séoul et d'autres bureaux, pour assurer une couverture complète de l'événement.
  + **Production éditoriale et photo:** Angela a rédigé un article de fond sur l'antisémitisme en Australie, Dean Chen a réalisé une interview d'un homme faussement identifié comme agresseur, et la production photo a été assurée par David Rey sur la plage, éditée par Riley Weston à Melbourne.
  + **Gestion des contenus UGC:** Reuben a détaillé les difficultés à sourcer une vidéo virale montrant un individu arrachant une arme à un agresseur, expliquant que la vidéo circule massivement sur les réseaux sociaux sans source claire, et que l'équipe a préféré utiliser un autre UGC obtenu avec DocuSign montrant la fuite des personnes.
  + **Suivi et angles futurs:** David a indiqué que l'équipe surveille les développements pour d'éventuelles alertes et prépare un angle sur les conséquences psychologiques pour les survivants de la fusillade.
* **Résultats de l’élection présidentielle au Chili:** L’équipe, avec Dany, a couvert l’élection du nouveau président chilien Cast, en détaillant son parcours, ses soutiens, la couverture sur le terrain et les réactions, avec une mobilisation importante en photo et vidéo.
  + **Profil du président élu:** Cast, candidat de droite, a remporté la présidence après plusieurs tentatives, en cherchant à atténuer les aspects les plus controversés de son idéologie, notamment son soutien à la dictature de Pinochet.
  + **Couverture terrain:** L’équipe a assuré une couverture complète de la journée électorale, des bureaux de vote à la victoire de Cast, avec des réactions de supporters dans la rue et une production photo et vidéo riche et variée.
  + **Analyse régionale:** La discussion a mis en perspective le basculement politique en Amérique latine, du centre-gauche vers la droite, en citant d’autres pays comme l’Argentine, la Bolivie et le Salvador.
  + **Prochaines étapes:** Cast doit être reçu par Boric, et l’équipe prévoit de suivre les développements politiques à venir.
* **Condamnation de Jimmy Lai à Hong Kong:** Holmes a présenté la condamnation de Jimmy Lai, ancien patron d’Apple Daily, pour collusion avec l’étranger et sédition, en détaillant la procédure judiciaire, la couverture médiatique sur place et les réactions internationales attendues.
  + **Détails du verdict:** Jimmy Lai a été reconnu coupable de trois chefs d’accusation, dont deux pour collusion avec l’étranger sous la loi sur la sécurité nationale, et un pour conspiration à publier des publications séditieuses.
  + **Procédure judiciaire:** La sentence pourrait aller jusqu’à la prison à vie, mais la décision finale sera rendue le 12 janvier ; l’affaire est suivie de près depuis le retour de Hong Kong à la Chine en 1997.
  + **Couverture sur le terrain:** Holmes et Reuben ont expliqué les difficultés d’accès à la salle d’audience, la nécessité de s’équiper pour attendre, et la présence de nombreux médias et diplomates européens sur place.
  + **Réactions internationales:** Les réactions américaines sont attendues, avec la possibilité de nouvelles sanctions contre Hong Kong et la Chine, dans un contexte de tensions géopolitiques.
* **Homicide de Rob Reiner et son épouse en Californie:** L’équipe a brièvement évoqué la découverte des corps de Rob Reiner et de son épouse à leur domicile en Californie, notant l’absence de suspect ou de mobile connu, et la couverture limitée prévue.
  + **Faits connus:** Deux corps ont été retrouvés au domicile de Rob Reiner, réalisateur, et de son épouse, sans suspect ni mobile identifié ; la police évoque un homicide apparent, possiblement par arme blanche.
* **Enquête sur la traite d’êtres humains dans le trafic de drogue à Marseille:** Sandra a présenté les résultats de trois ans d’enquête sur l’implication de mineurs dans le trafic de drogue à Marseille, révélant l’émergence de la qualification de traite d’êtres humains pour criminalité forcée, avec l’appui d’une juge pour enfants.
  + **Méthodologie d’enquête:** Sandra a assisté à des audiences de comparutions immédiates pour identifier les profils des jeunes impliqués, puis a établi un contact privilégié avec une juge pour enfants sur le départ, qui lui a permis d’observer des déferrements.
  + **Qualification de traite d’êtres humains:** La juge a qualifié pour la première fois ces jeunes de victimes de traite d’êtres humains, une notion inédite en France pour la criminalité forcée, habituellement réservée à la prostitution ou la mendicité.
  + **Évolution judiciaire:** Le parquet de Marseille a ouvert des enquêtes pour traite d’êtres humains, bien qu’aucun procès n’ait encore eu lieu sous ce qualificatif.
  + **Difficultés d’accès aux victimes:** Sandra n’a pas pu interroger directement les victimes, se basant sur l’observation, les dossiers judiciaires et les témoignages indirects, en raison du huis clos et de la vulnérabilité des jeunes concernés.
  + **Éléments marquants de l’enquête:** Un exemple fort cité est la découverte d’un mot dans un pochon de drogue, écrit par un mineur demandant de l’aide et précisant leur âge, destiné à alerter les consommateurs et la police.

Tâches de suivi:

* **Réactions Internationales au Verdict de Jimmy Lai:** Suivre et compiler les réactions internationales, notamment américaines, concernant le verdict de Jimmy Lai. (Holmes)
* **Conséquences Psychologiques de la Fusillade à Sydney:** Réaliser un angle sur les conséquences du traumatisme psychologique pour les survivants de la fusillade de Sydney. (David)
* **Source de la Vidéo UGC de l’Attaque de Sydney:** Tenter de retrouver la source originale de la vidéo UGC montrant la saisie du fusil d’assaut lors de l’attaque. (Reuben)
* **Enquête sur la Traite d’Êtres Humains à Marseille:** Poursuivre la collecte de témoignages indirects et de dossiers judiciaires pour approfondir l’enquête sur la traite. (Sandra)

11/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Saisie d’un Pétrolier Vénézuélien par les États-Unis:** Sébastien a présenté les détails de la saisie d’un super pétrolier transportant du brut vénézuélien par les forces américaines, avec l’appui du FBI et de l’armée, et a expliqué les réactions de Donald Trump et du régime de Nicolas Maduro.
  + **Contexte de la Saisie:** Sébastien a expliqué que les États-Unis ont saisi un super pétrolier transportant du brut vénézuélien au large des côtes, dans le cadre de sanctions de longue date contre le navire pour transport de brut iranien et vénézuélien.
  + **Déroulement de l’Opération:** La présentation a inclus une vidéo montrant deux hélicoptères du FBI, appuyés par l’armée américaine, arraisonnant le pétrolier, sans révéler le nom du navire ni celui de son propriétaire.
  + **Réactions Politiques:** Donald Trump a annoncé la saisie, affirmant que l’objectif était de renverser le régime de Maduro, tandis que le Venezuela a dénoncé un acte de piraterie internationale et que la ministre PAM Bondy a précisé le contexte des sanctions.
  + **Conséquences et Analyse:** L’équipe a noté une hausse des cours du brut suite à l’incident, et a discuté de l’impact limité des sanctions précédentes sur le maintien au pouvoir de Maduro, tout en actualisant leur documentation avec les nouveaux éléments.
* **Arrivée de l’Opposante Vénézuélienne Machado à Oslo:** L’équipe, dont plusieurs membres à Oslo et à Caracas, a suivi en direct l’arrivée de Machado, opposante vénézuélienne, après 11 mois d’absence publique, et a couvert les réactions et événements liés à sa présence.
  + **Arrivée et Mobilisation:** Machado est arrivée à Oslo dans la nuit, accueillie par une foule de partisans, marquant sa première apparition publique depuis 11 mois, avec une forte mobilisation des équipes sur place.
  + **Interview et Circonstances de la Sortie:** Machado a donné une interview à la BBC, remerciant ceux qui ont facilité sa sortie du Venezuela, sans révéler les détails, bien que des rumeurs évoquent une fuite par bateau de pêcheurs déguisés.
  + **Couverture Médiatique et Prix Nobel:** La fille de Machado, exilée, a reçu le prix Nobel en son nom, et l’équipe a assuré une couverture large, incluant des photos à l’aéroport, à l’hôtel, et lors du gala des Nobel.
  + **Réactions au Venezuela:** Des articles ont été produits sur les réactions au Venezuela, où les partisans de Maduro accusent Machado de trahison, tandis que ses soutiens la saluent comme une libératrice ; Machado a affirmé son intention de rentrer au Venezuela.
  + **Organisation de la Couverture:** L’équipe a été renforcée sur place pour suivre les deux conférences de presse prévues, et a assuré une veille continue, notamment grâce à la présence de journalistes et photographes à différents points stratégiques.
* **Jeu Vidéo Français Favori aux Game Awards:** Killian a présenté la participation exceptionnelle d’un jeu vidéo français, développé par un petit studio de Montpellier, aux Game Awards à Los Angeles, où il est favori avec un record de nominations.
  + **Présentation du Jeu:** Le jeu, développé par une équipe d’une trentaine de personnes à Montpellier, est nommé dans 13 catégories, une première pour un jeu français, et affronte des productions majeures internationales.
  + **Processus de Nomination et Récompenses:** Le jeu est favori pour le titre de jeu de l’année et pourrait battre un record de trophées, alors que la France n’a jamais remporté cette distinction malgré plusieurs nominations passées.
  + **Direction Artistique et Réception:** Le jeu se distingue par une direction artistique inspirée de la Belle Époque parisienne, un style de jeu de rôle apprécié, et a généré un engouement notable dès son annonce.
  + **Musique et Impact Culturel:** La bande originale, composée par un ancien professeur de guitare, a rencontré un grand succès, avec des concerts à guichets fermés et une popularité jusque dans les karaokés parisiens.
  + **Couverture Médiatique et Interviews:** L’équipe prévoit une couverture photo et vidéo de la cérémonie, avec des interviews programmées avec les créateurs, et souligne l’impact de la « patte française » dans la réception du jeu à l’international.
* **Reportage Exceptionnel à Aden au Yémen:** Haitham a partagé son expérience d’une mission rare à Aden, réalisée grâce à des contacts avec les autorités saoudiennes, et a détaillé la production de plusieurs reportages sur la situation humanitaire et sécuritaire.
  + **Accès et Organisation de la Mission:** Haitham a expliqué que l’accès à Aden a été possible grâce à des contacts continus avec les Saoudiens, qui contrôlent l’entrée, et que la mission a duré quatre jours.
  + **Reportages Réalisés:** Trois sujets ont été produits : l’état de l’éducation avec 3 000 écoles endommagées, la situation des réfugiés somaliens, et un reportage sur la vie quotidienne à Aden.
  + **Conditions de Sécurité:** Haitham a décrit la présence de nombreux points de contrôle, la pauvreté omniprésente, et la difficulté de travailler sur place, tout en soulignant l’importance du travail d’équipe avec les journalistes locaux.
  + **Impact et Visibilité:** Le reportage vise à attirer l’attention sur un conflit oublié, rarement traité en une, et met en avant la nécessité de continuer à couvrir la situation au Yémen.
* **Confirmation de l’Implication Française dans la Protection du Président du Bénin:** L’équipe du bureau d’Abidjan a été la première à confirmer l’implication de l’armée française dans la protection du président Talon au Bénin après la tentative de coup d’État, grâce à des contacts avec le chef d’état-major.
  + **Obtention de l’Information:** Le bureau d’Abidjan a obtenu la confirmation officielle de l’implication française auprès du chef d’état-major, permettant de publier deux alertes et d’être les premiers à diffuser l’information.
* **Refonte du Manuel Agencier et Développement du Stylebot:** Pauline, Julie et l’équipe centrale ont présenté la refonte du Manuel agencier, la publication de nouvelles entrées sur l’autisme et les vaccins, et le développement d’un outil chatbot (stylebot) pour faciliter l’accès aux recommandations rédactionnelles.
  + **Nouvelles Entrées et Structuration:** Les entrées sur l’autisme et les vaccins ont été réécrites pour être plus claires, structurées par recommandations, contexte et précautions, afin de répondre aux besoins des journalistes et de préparer l’intégration dans le stylebot.
  + **Objectifs du Stylebot:** Le stylebot permettra aux journalistes de poser des questions et d’obtenir rapidement des réponses issues du Manuel agencier, rendant l’outil plus accessible et interactif.
  + **Méthodologie et Collaboration:** La refonte est menée en collaboration avec l’équipe centrale, Éric, Pauline, Jenny et le réseau, et implique une structuration adaptée à l’usage des LLM et chatbots, tout en conservant la tradition journalistique de l’AFP.
  + **Exemples et Précautions:** Julie a détaillé la nécessité d’expliciter les règles, notamment sur les sujets sensibles comme les vaccins, pour éviter la désinformation et garantir la neutralité et la rigueur des dépêches, en s’appuyant sur l’expertise du fact-checking.
  + **Déploiement Progressif:** Le travail de réécriture se poursuit sur d’autres thèmes, comme la couverture des conflits, avec l’objectif de rendre le Manuel plus utile et de permettre à terme une utilisation commerciale des contenus structurés.

Tâches de suivi:

* **Enquête sur la Sortie de Machado du Venezuela:** Tenter d'obtenir plus d'informations sur la manière dont Machado est sortie du Venezuela, en particulier en poursuivant l'investigation par le Bureau de Caracas. (Teams)

09/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Mise en Application de la Loi sur les Réseaux Sociaux en Australie:** David a présenté depuis Sydney les détails de l'entrée en vigueur de la nouvelle loi australienne sur les réseaux sociaux, en expliquant les mesures prises par les plateformes, les réactions des parties prenantes, et la couverture prévue par l'équipe, avec une attention particulière sur la réaction internationale et les défis techniques.
  + **Entrée en Vigueur de la Loi:** David a expliqué que l'interdiction officielle entre en vigueur à 13h GMT en Australie orientale, avec un dispositif de couverture prêt à être diffusé en différé pour alerter les principaux clients et suivre les développements en temps réel.
  + **Réactions des Plateformes:** David a précisé que certaines plateformes comme Metro ont déjà commencé à exclure les moins de 16 ans, tandis que d'autres, comme X, n'ont pas encore communiqué leur stratégie, ce qui nécessite une veille particulière, notamment sur les annonces potentielles de la part d'Elon Musk.
  + **Défis Juridiques et Techniques:** David a mentionné qu'il existe une contestation juridique en cours contre la loi, mais sans demande d'injonction immédiate, et que Reddit considère la loi comme juridiquement incorrecte sans confirmer une action légale, ce qui est relayé dans les médias australiens.
  + **Couverture Médiatique et Ressources:** L'équipe a prévu d'utiliser des stockshots de plateformes comme TikTok et Facebook, ainsi que des images d'adolescents avec des appareils électroniques, pour enrichir la couverture, et deux VJs seront mobilisés pour des vox pops et des reportages à Sydney.
  + **Limites de l’Application:** David a souligné que le gouvernement australien reconnaît que la couverture ne sera pas totale, mais que la responsabilité est transférée aux plateformes pour s'adapter, tout en sachant que certains jeunes pourront contourner les restrictions.
* **Assouplissement des Restrictions sur les Puces Nvidia en Chine:** Katharine a détaillé depuis Tokyo la décision de l'administration Trump d'autoriser Nvidia à vendre certaines puces avancées à la Chine, en exposant les enjeux de sécurité nationale, les réactions politiques américaines, et l'impact sur le marché des semi-conducteurs.
  + **Contexte de Sécurité Nationale:** Katharine a expliqué que les puces concernées alimentent des systèmes d'IA pouvant offrir un avantage militaire à la Chine, ce qui motive les restrictions américaines, tout en soulignant l'importance économique du marché chinois pour Nvidia.
  + **Effets sur l’Industrie Chinoise:** Elle a précisé que la politique américaine pourrait accélérer le développement de l'industrie locale des semi-conducteurs en Chine, Pékin encourageant les entreprises à adopter des alternatives nationales.
  + **Détails de la Décision:** La décision permet à Nvidia de vendre des puces comme la H200, qui restent en retrait par rapport aux modèles les plus avancés (Blackwell), mais qui ne sont qu'à 18 mois de retard technologique, ce qui représente une ouverture partielle du marché.
  + **Réactions Politiques:** Katharine a rapporté que la décision a été critiquée par des membres du Parti démocrate, certains avançant des soupçons de conflits d’intérêts, bien que ces allégations n’aient pas été vérifiées.
* **Reprise du Conflit Cambodge-Thaïlande et Couverture sur le Terrain:** Matthew a fait le point depuis Bangkok sur la reprise du conflit entre le Cambodge et la Thaïlande, en détaillant le déploiement des équipes sur le terrain, la situation humanitaire, et les stratégies de couverture multimédia prévues.
  + **Situation sur le Terrain:** Matthew a indiqué que le conflit a repris de façon similaire à juillet, avec des affrontements et un nombre important de déplacés, principalement en Thaïlande, et un bilan provisoire de 10 morts, dont 3 soldats thaïlandais et 7 civils cambodgiens.
  + **Déploiement des Équipes:** L’équipe cambodgienne s’est rendue dans la province frontalière pour réaliser des directs et collecter des témoignages, tandis que l’équipe thaïlandaise doit partir tôt le lendemain pour diversifier la couverture, avec l’appui d’un vidéaste local.
  + **Stratégie de Couverture:** La priorité est donnée à la couverture des évacués des deux côtés de la frontière, avec une adaptation des déplacements selon les informations reçues du terrain, et l’utilisation de moyens techniques innovants pour la transmission d’images en direct.
  + **Aspects Techniques:** L’équipe a testé l’utilisation de téléphones portables couplés à des lentilles d’appareils photo pour permettre des zooms lors des directs, ce qui s’est avéré efficace même dans des conditions de connexion parfois difficiles.
* **Tentative de Coup d’État au Bénin et Coordination de la Couverture:** Pierre a exposé depuis Abidjan les coulisses de la couverture de la tentative de coup d’État au Bénin, en détaillant la chronologie des événements, la mobilisation des équipes, la vérification des informations, et l’intervention régionale.
  + **Déroulement des Événements:** Pierre a décrit les deux scénarios classiques de coup d’État, précisant que cette fois-ci, des militaires ont pris la télévision pour annoncer la destitution du président Talon, ce qui a été rapidement vérifié par les correspondants sur place.
  + **Vérification et Alerte:** Grâce à des sources proches du président, l’équipe a pu confirmer rapidement que le président allait bien et que l’armée reprenait le contrôle, permettant d’alerter les clients avant la concurrence.
  + **Mobilisation des Bureaux:** Le bureau de Lagos a dépêché une équipe texte, photo et vidéo à la frontière, qui a pu rejoindre Cotonou pour réaliser des directs et compléter la couverture, en coordination avec le bureau d’Abidjan.
  + **Intervention Nigériane et Régionale:** Pierre a confirmé que l’armée nigériane est intervenue par des frappes aériennes pour soutenir le président, information d’abord obtenue en off puis confirmée officiellement, suivie par l’envoi de troupes du bloc ouest-africain.
  + **Analyse et Collaboration:** Pierre a souligné la rapidité de la réaction régionale, contrastant avec d’autres coups d’État récents au Sahel, et a mis en avant la collaboration efficace entre les équipes de Lagos et d’Abidjan, ainsi que la couverture exclusive obtenue.
* **Point sur les Conflits Internationaux en Cours:** L’équipe a fait un tour d’horizon des principaux conflits internationaux, notamment en RDC, Ukraine, Israël-Hamas, et d’autres, en préparant une synthèse des situations sur le terrain et de la présence des équipes.
  + **Synthèse des Conflits:** L’équipe a recensé sept conflits majeurs, dont la RDC avec l’avancée des troupes rwandaises, l’Ukraine, et la phase 2 du conflit Israël-Hamas, en soulignant la présence de correspondants sur place pour chaque zone.

Tâches de suivi:

* **Suivi des Réactions des Plateformes à la Loi Australienne:** Surveiller les annonces potentielles de la part de X (notamment Elon Musk) concernant leur conformité à l'interdiction en Australie. (David)
* **Collecte d’Images de Puces Nvidia:** Accroître le stock d’images de puces Nvidia lors de conférences, showcases ou autres événements pertinents. (Teams)
* **Point sur les Conflits Internationaux:** Rassembler et faire un point précis sur l’évolution des sept conflits majeurs, en s’appuyant sur les informations terrain disponibles. (Teams)

8/12/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Couverture du Coup d'État au Bénin:** L'équipe, avec Patrick et plusieurs journalistes sur le terrain, a discuté de la couverture rapide et exclusive du coup d'État au Bénin, en soulignant la mobilisation du bureau, la coordination avec les équipes à Abidjan et Lagos, et la diffusion d'informations exclusives, notamment sur la sécurité du président Talon et l'intervention de la CEDEAO.
  + **Mobilisation du Bureau:** Le bureau s'est mobilisé rapidement pour couvrir le coup d'État au Bénin, avec une préparation en amont incluant des visas prêts et des journalistes expérimentés dans la région, permettant une arrivée rapide sur place et une couverture efficace.
  + **Sources Exclusives et Sécurité:** Des informations exclusives ont été obtenues, notamment via l'AFP, concernant la sécurité du président Talon, confirmée par une source présidentielle, et la réaction rapide des forces armées pour protéger les institutions clés.
  + **Diffusion et Impact Médiatique:** La couverture a été reprise par de grands médias internationaux comme la BBC, avec des vidéos et des reportages sur les scènes de soldats dans la ville, et une communication efficace sur la normalisation de la situation après les événements.
  + **Rôle de la CEDEAO et Réactions Régionales:** La CEDEAO a été mentionnée pour son intervention, marquant la première fois depuis 2017 qu'elle aide un autre pays, avec une confirmation de la présidence nigériane sur la coordination régionale pour stabiliser la situation.
  + **Gestion de la Communication et Internet:** Une question a été posée sur la coupure d'internet ; il a été confirmé qu'il n'y a pas eu de coupure généralisée, car les événements se sont déroulés trop rapidement pour que les autorités prennent cette mesure.
* **Réunion des Ministres de l’Intérieur de l’UE sur la Politique Migratoire:** Yann a présenté la réunion des ministres de l’Intérieur de l’Union européenne à Bruxelles, axée sur la politique migratoire, avec des propositions sur les hubs de retour, les sanctions contre les migrants refusant de partir, et la relocalisation des demandeurs d’asile, sous l’impulsion du Danemark.
  + **Propositions Migratoires:** Les ministres discutent de la création de hubs de retour pour les migrants déboutés, de sanctions renforcées pour ceux qui refusent de quitter l’UE, et du renvoi vers des pays tiers jugés sûrs, des mesures impulsées par le Danemark.
  + **Consensus et Réserves:** La majorité des 27 États membres soutiennent ces propositions, à l’exception de la France qui questionne leur légalité et de l’Espagne qui doute de l’efficacité des hubs, citant l’échec du modèle italien.
  + **Processus Législatif:** Après l’accord des ministres, le texte sera négocié avec le Parlement européen, avec l’objectif d’un vote en début d’année suivante.
  + **Relocalisation des Demandeurs d’Asile:** Des discussions spécifiques portent sur la répartition des demandeurs d’asile entre les pays de l’UE, afin de soulager ceux sous forte pression migratoire comme l’Italie ou la Grèce.
* **Sélection d’Images Positives de l’Année:** L’équipe a évoqué la diffusion prochaine d’une sélection d’images positives et joyeuses de l’année, initiative présentée par Éric, qui sera publiée sur les fils et réseaux sociaux pour contrebalancer la lourdeur de l’actualité.
  + **Objectif de la Sélection:** La sélection vise à mettre en avant des moments heureux, insolites ou festifs, pour offrir une vision plus légère et positive de l’actualité, en complément des sujets plus graves.
  + **Diffusion et Contenu:** Les images seront diffusées le lendemain sur les fils et réseaux sociaux, illustrant des fêtes populaires, des rassemblements originaux comme celui des Schtroumpfs, et d’autres moments marquants de l’année.

Tâches de suivi:

* **Diffusion de la sélection d'images joyeuses:** Mettre le lien du showcase dans la note de conférence pour la diffusion de la sélection d'images joyeuses demain. (Teams)

17/11/2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Élections et Virage Politique au Chili:** Les participants ont discuté de la dynamique politique actuelle au Chili, notamment la montée de la droite, l'impact de la criminalité et de l'immigration sur la campagne électorale, ainsi que la couverture médiatique des élections par l'équipe, avec une coordination importante entre les membres pour assurer un suivi complet des événements.
  + **Montée de la Droite:** Les intervenants ont analysé la progression de la droite au Chili, soulignant que la campagne électorale est dominée par les thèmes de la sécurité, de l'insécurité et de la criminalité, avec des promesses de mesures strictes, notamment sur l'immigration et la gestion des frontières.
  + **Stratégies des Candidats:** Il a été mentionné que les candidats de droite détiennent environ 50% des voix au premier tour, et que le candidat arrivé troisième pourrait jouer un rôle clé en décidant de s'allier à la droite ou à la gauche, influençant ainsi le second tour prévu pour le 14 décembre.
  + **Couverture Médiatique:** L'équipe a assuré une couverture étendue des élections, mobilisant cinq photographes et un envoyé spécial pour couvrir les événements sur trois week-ends, incluant la journée de vote et les soirées électorales, avec une coordination efficace pour produire des contenus en images et en vidéo.
  + **Contexte Régional:** Les participants ont replacé la situation chilienne dans un contexte plus large de virage à droite en Amérique latine, citant la Bolivie, le Pérou et le Chili comme exemples, et notant que le soutien de figures internationales comme Trump facilite la dynamique pour la droite.
* **Tensions Croissantes entre la Chine et le Japon:** Hui Min et d'autres membres ont abordé l'escalade des tensions entre la Chine et le Japon, évoquant les avertissements de voyage chinois, l'impact économique sur le tourisme japonais, la réaction de Taïwan, et la couverture médiatique des événements par l'équipe.
  + **Avertissements et Réactions Officielles:** La Chine a émis un avertissement de voyage à destination de ses citoyens concernant le Japon, tandis que les compagnies aériennes chinoises proposent des remboursements gratuits, et Taïwan a critiqué la Chine pour ses attaques contre le Japon, soulignant les risques pour la stabilité régionale.
  + **Impact Économique:** Il a été souligné que la baisse du tourisme chinois pourrait avoir des conséquences dramatiques pour l'économie japonaise, le tourisme chinois représentant une part majeure du secteur, ce qui se traduit déjà par une chute des actions dans le commerce de détail et le tourisme au Japon.
  + **Couverture Médiatique et Vox Populi:** L'équipe a collecté des vox pops en Chine, montrant que l'opinion publique considère que le Japon ne devrait pas s'immiscer dans les affaires internes, et a diffusé des images de touristes chinois au Japon ainsi qu'un reportage à bord d'un patrouilleur des gardes-côtes taïwanais.
  + **Projets de Reportages:** Des travaux sont en cours pour développer un angle économique sur la situation, avec la diffusion d'images et de reportages, et la préparation d'un explicatif sur la relation sino-japonaise.
* **Volte-Face de Trump dans l'Affaire Austin et Dossier Epstein:** Les participants ont discuté du revirement inattendu de Donald Trump concernant le soutien à la publication du dossier Epstein, des tensions internes au sein du mouvement républicain, et des répercussions économiques de la suspension de certains droits de douane par l'administration Trump.
  + **Soutien à la Publication du Dossier Epstein:** Donald Trump a décidé de soutenir un vote à la Chambre pour la publication du dossier Epstein, une décision surprenante après des pressions internes, notamment de la part de Taylor Green, figure du mouvement Maga.
  + **Motivations et Conséquences Politiques:** Les intervenants se sont interrogés sur les raisons de ce revirement, suggérant que Trump cherchait à ressouder son mouvement et à tenir ses promesses de campagne sur la transparence, tout en notant que la commission de surveillance de la Chambre a toute latitude pour agir.
  + **Suspension des Droits de Douane:** L'administration Trump a suspendu certains droits de douane, notamment sur le café et la banane, en raison de leur impact négatif sur le pouvoir d'achat des Américains, ce qui a été perçu comme un aveu d'échec dans la gestion économique.
  + **Couverture Médiatique:** L'équipe a mentionné la diffusion d'images d'archives et de contenus liés à Trump, notamment ses déplacements en Air Force, tout en notant l'absence d'éléments visuels nouveaux à signaler pour le week-end.

Tâches de suivi:

* **Analyse économique de la crise sino-japonaise:** Travailler sur un angle économique pour les prochains jours afin d’illustrer l’impact de la crise entre la Chine et le Japon, notamment en ce qui concerne le tourisme et les marchés financiers, et identifier les images pertinentes à utiliser. (the team)
* **Explication des relations sino-japonaises:** Préparer et diffuser un explicatif sur la relation entre le Japon et la Chine, en mettant en avant les tensions actuelles et leurs conséquences régionales. (Hui Min)

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Débat Interne sur le Soutien au Budget Américain:** Sophie a présenté une proposition concernant le débat interne au sein du parti sur le soutien au budget américain, abordant les accusations de trahison, les conséquences économiques du blocage prolongé, et l'incertitude persistante sur certains projets comme Obamacare.
  + **Accusations de Trahison:** Sophie a expliqué que certains membres du parti qui ont soutenu le budget en l'état sont accusés d'avoir trahi leur camp, tandis que d'autres, comme Trump, critiquent fortement ces décisions.
  + **Conséquences Économiques:** Sophie a souligné que le blocage du budget a duré plus d'un mois, ce qui aura des effets sur la croissance économique américaine, bien que la durée exacte de l'impact reste incertaine en raison du manque de données économiques publiées ou collectées pendant cette période.
  + **Incidence sur les Projets Symboliques:** Sophie a mentionné que certains projets emblématiques, comme Obamacare, restent en suspens, car le texte du budget n'apporte pas de clarification, ce qui entretient une grande incertitude sur leur avenir.
  + **Retard dans la Publication des Données:** Sophie a précisé que, par exemple, les chiffres économiques d'octobre pourraient ne jamais être publiés, car il n'y avait personne pour les collecter durant le blocage.
* **Commémoration des Attentats en France:** L'équipe, menée par Teams, a détaillé la couverture de la journée de commémoration des attentats en France, incluant les cérémonies officielles, la participation de Macron, la diffusion de reportages et témoignages, et les actions symboliques comme l'illumination de la Tour Eiffel.
  + **Organisation des Cérémonies:** Teams a expliqué que de nombreuses cérémonies se déroulent dans chaque lieu des attentats, présidées par Macron, avec une couverture en direct tout au long de la journée.
  + **Actions Symboliques:** L'évêché de Paris a annoncé que les cloches de plusieurs églises, dont Notre-Dame, sonneront pendant cinq minutes, et la Tour Eiffel a été illuminée aux couleurs de la France la veille.
  + **Couverture Médiatique:** L'équipe a diffusé de nombreux reportages, témoignages vidéo, et archives photos, notamment une interview avec François Hollande, pour illustrer l'émotion collective et la mémoire des événements.
  + **Événements Publics:** Des rassemblements ont eu lieu place de la République, où la mairie de Paris a invité le public à déposer des bougies, fleurs et messages, et une minute de silence est prévue avant le match France-Ukraine.
* **Examens d’Entrée à l’Université en Corée du Sud:** Jin-Kyu a présenté l’importance des examens d’entrée à l’université en Corée du Sud, décrivant leur impact sur la société, les mesures exceptionnelles prises lors des épreuves, et la perception de cet événement comme un rite de passage national.
  + **Déroulement de l’Examen:** Jin-Kyu a expliqué que l’examen a lieu une fois par an, avec une section d’écoute en anglais l’après-midi, et que des mesures comme l’arrêt des vols pendant cette épreuve sont prises pour garantir le calme.
  + **Importance Sociale:** Jin-Kyu a insisté sur le fait que cet examen est un passage obligé pour tous les jeunes Sud-Coréens, indépendamment de leur genre ou classe sociale, et qu’il est considéré comme l’un des deux grands obstacles de la jeunesse, l’autre étant le service militaire.
  + **Préparation Intensive:** La préparation à cet examen commence dès la première année d’école primaire et dure douze ans, toute la scolarité étant orientée vers cette journée décisive.
  + **Perception Culturelle:** Jin-Kyu a partagé que l’examen est si marquant que de nombreux Coréens font des cauchemars à son sujet, au même titre que le service militaire, illustrant la pression sociale associée à ces étapes.
* **Analyse de l’Affaire BBC et Pratiques Documentaires:** L’équipe, sous la direction de Teams, a analysé l’affaire BBC concernant le montage d’un documentaire, discutant des erreurs de montage, de leur exploitation contre les journalistes, et de la création d’une nouvelle règle interne sur les citations.
  + **Présentation de l’Affaire:** Teams a présenté un montage réalisé par le Washington Post pour illustrer les coupes effectuées dans le documentaire de la BBC, mettant en avant les différences entre la version originale et la version diffusée.
  + **Pratiques de Montage:** L’équipe a discuté de la pratique courante dans les documentaires de raccourcir les propos et d’ajouter des plans de coupe, tout en soulignant les risques de déformation du sens initial.
  + **Conséquences et Attaques:** Teams a expliqué que l’erreur de montage a été utilisée comme arme par certains membres du conseil d’administration de la BBC pour attaquer la crédibilité des journalistes, et que toute erreur est exploitée pour dénoncer un biais.
  + **Création d’une Règle Interne:** L’équipe a décidé de publier une note et d’ajouter une nouvelle entrée dans leur manuel, appelée la 'Frank and quote', pour rappeler l’importance de la rigueur dans la restitution des citations et éviter les montages qui dénaturent le propos.

Tâches de suivi:

* **Ajout d'une entrée dans le Manuel sur les citations manipulées:** Publier une nouvelle entrée dans le Manuel intitulée "la Frank and quote" pour rappeler l'importance de la rigueur dans le rapport des citations et sensibiliser sur les risques de manipulations. (Teams)

10 novembre 2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Crise de Gouvernance à la BBC:** Catherine a présenté un exposé détaillé sur la démission du directeur général et de la patronne de BBC News, suite à une polémique sur un montage trompeur dans un documentaire, avec des réactions politiques fortes de Boris Johnson, Donald Trump et l'ambassade d'Israël, et une attente persistante d'explications officielles de la BBC.
  + **Origine de la Polémique:** Catherine a expliqué que la crise a débuté avec la fuite d'un rapport interne critiquant un documentaire de la BBC sur Donald Trump et l'assaut du Capitole, où un montage a donné l'impression erronée que Trump avait appelé à attaquer le Capitole, ce qui a déclenché une vague de critiques contre la BBC.
  + **Réactions Politiques:** Boris Johnson a exigé la démission du directeur général de la BBC et a menacé de ne plus payer la redevance tant que des mesures ne seraient pas prises, tandis que Donald Trump et son équipe ont publiquement accusé la BBC de diffuser de fausses informations, et l'ambassade d'Israël s'est également réjouie des démissions.
  + **Conséquences et Attentes:** La BBC a publié un communiqué annonçant les démissions, mais n'a pas encore fourni d'explications sur le montage controversé ; le président de la BBC doit s'expliquer devant la commission parlementaire des médias, avec des modalités d'audition encore incertaines.
  + **Contexte Médiatique et Critiques:** Catherine a souligné que la BBC, comme d'autres médias traditionnels, fait face à des critiques croissantes sur son impartialité, dans un contexte de montée des médias partisans et d'accusations récurrentes, notamment sur la couverture de Trump et du conflit israélo-palestinien.
  + **Incidents Récents et Tensions Internes:** Des cas récents, comme la diffusion d'un live controversé et la révélation de l'identité du narrateur d'un documentaire, ont valu à la BBC des critiques du régulateur des médias, tandis que des divisions internes au sein du board de la BBC ont été évoquées comme facteur aggravant.
* **Défis Logistiques et Organisationnels de la COP à Belém:** Laura, Ivan et Thomas ont détaillé les difficultés rencontrées pour organiser la couverture de la COP à Belém, au cœur de l’Amazonie, notamment la gestion complexe de l’hébergement, la mobilisation d’équipes internationales et la coordination logistique sur place.
  + **Préparation et Mobilisation des Équipes:** Laura a expliqué que la préparation a nécessité une année de travail, impliquant des dizaines de journalistes de l’AFP dans le monde, avec environ 10 à 11 journalistes sur place malgré des coûts d’hébergement très élevés.
  + **Gestion de l’Hébergement:** Ivan a décrit les difficultés pour réserver des logements, dues à l’attente d’une plateforme officielle en retard, à la flambée des prix et à la nécessité de recourir à des contacts internes, comme la belle-sœur de Yann Bernal, pour loger une partie de l’équipe.
  + **Logistique sur Place:** L’équipe a dû s’adapter à une organisation locale en retard, avec une logistique complexe pour le centre de conférence, mais a finalement réussi à installer tous les membres nécessaires, y compris vidéastes, photographes, rédacteurs et techniciens.
  + **Stratégie de Couverture:** Ivan a précisé que la couverture AFP est très décentralisée, avec des équipes à distance à Paris et Washington, et une présence réduite de médias internationaux sur place, ce qui permet à l’AFP de se démarquer, notamment par des reportages originaux et des enquêtes multimédias.
* **Stratégie de Couverture et Enjeux de la COP:** Ivan et l’équipe ont exposé la stratégie de couverture de la COP, insistant sur la nécessité de se différencier dans un contexte très concurrentiel, et ont évoqué les principaux enjeux du sommet, notamment les tensions entre pays riches et pays vulnérables.
  + **Organisation de la Couverture:** Ivan a expliqué que la couverture est la plus décentralisée jamais réalisée par l’AFP pour une COP, avec une équipe sur place réduite et un appui quotidien des rédactions de Paris et Washington, tandis que d’autres médias internationaux ont réduit leur présence.
  + **Différenciation et Visibilité:** L’AFP vise à se distinguer en allant chercher des témoignages de délégués moins médiatisés et en produisant des contenus repris par de grands médias brésiliens, comme la une du Globo avec des photos AFP.
  + **Enjeux du Sommet:** Les discussions portent sur les clivages persistants entre pays riches et pays vulnérables, notamment sur la question des énergies fossiles et des conséquences du changement climatique, avec une forte présence de journalistes internationaux.
* **Enquête sur les Attaques Ethniques au Soudan:** Serene a présenté le reportage de l’AFP sur les attaques à caractère ethnique commises par les FSR au Soudan, soulignant la difficulté de l’enquête, la collecte de témoignages directs et la confirmation par des experts de l’ONU et MSF.
  + **Méthodologie de l’Enquête:** Serene a détaillé que l’équipe a intégré des éléments sur les attaques ethniques dans des reportages précédents, mais que ce papier est le premier à aborder explicitement ce sujet, avec la participation de plusieurs correspondants et stringers.
  + **Témoignages et Sources:** Le reportage s’appuie sur des témoignages directs de victimes, dont une femme ayant perdu son mari et son fils, ainsi que sur des avis d’experts de l’ONU et de MSF, et inclut le démenti officiel des FSR obtenu in extremis.
  + **Difficultés de la Couverture:** L’équipe a rencontré des difficultés majeures, notamment l’assassinat de sources et de médecins, ce qui complique la collecte d’informations et la sécurité des journalistes sur le terrain.

Tâches de suivi:

* **Explications attendues de la BBC:** Obtenir et diffuser les explications officielles de la BBC concernant le montage trompeur du documentaire sur Donald Trump. (Catherine)
* **Enquête multimédia sur les incendies en Amazonie:** Finaliser et publier l’enquête multimédia novatrice sur les responsables des incendies en Amazonie, en s’appuyant sur les reportages, interviews et analyses de données réalisés par l’équipe de cinq journalistes. (Laura)
* **Témoignages sur les attaques ethniques au Soudan:** Recueillir et intégrer des témoignages supplémentaires de survivants et d’experts pour renforcer la couverture des attaques ethniques au Soudan. (Serene)
* **Sécurité des sources au Soudan:** Expliquer dans les prochains jours comment certaines sources de l’AFP, notamment des médecins, ont été assassinées, et analyser l’impact sur la couverture du conflit. (Teams)

7 NOVEMBRE 2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Challenges in Obtaining Images from Sudan:** Jewel updated the team, including Mehdi and Rita, on the difficulties in acquiring images from Sudan, explaining that while some demonstration photos were obtained from a stringer in Tawya, efforts to reach another stringer in Omdurman have so far been unsuccessful.
  + **Image Acquisition Difficulties:** Jewel explained that it is very challenging to get any images from Sudan due to the current situation, but the team managed to obtain some pictures from R1, a stringer based in Tawya.
  + **Coverage of Demonstrations:** Jewel reported that the team has acquired images of anti-RSF demonstrations from the wire, specifically from the previous day, and these are being processed for use.
  + **Efforts to Reach Omdurman Stringer:** Jewel mentioned ongoing attempts to contact a photo stringer in Omdurman to obtain additional images, but noted that there has been no success in reaching them yet.
* **Commissioning of China’s Third Aircraft Carrier:** Peter briefed the group on the official commissioning of China’s third aircraft carrier, the Fujian, highlighting its advanced aircraft launch technology and the significance of its name and recent activities near Taiwan.
  + **Official Commissioning Announcement:** Peter stated that Chinese state media announced the official commissioning of the third aircraft carrier, which means it is now entering active service with the Chinese Navy.
  + **Carrier Activities and Confirmation:** Peter explained that the carrier had been active around China’s coasts for several months, including a notable passage through the Taiwan Strait in September, but the official confirmation of its commissioning was only received today after several days of speculation.
  + **Technological Advancements:** Peter highlighted that the carrier features advanced aircraft launch technology, previously only found on U.S. carriers, marking a significant step in China’s military modernization.
  + **Naming and Symbolism:** Peter noted that the carrier is named Fujian, after the Chinese province directly across from Taiwan, a detail that has drawn attention among observers.
  + **Media Coverage and Imagery:** Peter mentioned that the team covered the announcement with an alert and has been tracking and publishing images released by Chinese state media.

Tâches de suivi:

6 NOVEMBRE 2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Typhoon Impact in the Philippines and Vietnam:** Hui Min provided a comprehensive update on the recent typhoon, detailing its deadly impact in the Philippines, the ongoing situation as it approaches Vietnam, and the governmental response including the declaration of a state of calamity and aid measures.
  + **Casualty and Damage Report:** Hui Min reported that the typhoon has resulted in over 140 deaths, with 114 confirmed by federal authorities and an additional 28 reported by local sources. The storm was not classified as a super typhoon but caused significant rainfall, delivering about 1.5 times the annual average in just over a day.
  + **Governmental Response:** The Philippines president declared a state of calamity, which enables the release of funding for aid and the capping of prices on daily necessities. This measure is intended to facilitate relief efforts and stabilize essential goods for affected populations.
  + **On-the-Ground Reporting:** Hui Min described the team's presence in the affected areas, sharing accounts such as a woman unable to rescue her sister from floodwaters. The team is also stationed in central Vietnam, where the typhoon is expected to make landfall in an already flooded region, potentially worsening conditions.
* **Security Measures for Aston Villa vs. Maccabi Tel Aviv Match:** Teams participants discussed the security situation surrounding the Aston Villa vs. Maccabi Tel Aviv football match in Birmingham, highlighting the ban on Israeli fans, expected demonstrations, and the deployment of a significant police presence.
  + **Background of Fan Ban:** Teams participants explained that Maccabi Tel Aviv fans were banned from attending the match in Birmingham due to previous incidents involving the club, including unclear events and riots in Amsterdam in November 2024. Despite calls from British Prime Minister Starmer to reverse the ban, it remained in place.
  + **Security and Demonstration Concerns:** The discussion noted that Birmingham, particularly the area around the Aston Villa stadium, has a large Muslim population, and authorities are expecting demonstrations. Approximately 700 police officers, about a tenth of the local force, have been deployed to manage the situation.
  + **Event Logistics and Media Coverage:** It was mentioned that no tickets were sold to Israeli fans, and media teams are positioned outside the stadium to cover the event. The kickoff is scheduled for 8 PM local time, and the situation is expected to be tense due to the combination of the fan ban and potential protests.
  + **Student Population Factor:** Teams participants highlighted that Birmingham has a large student population, around 440,000, which could contribute to the likelihood of demonstrations during the match.

5 novembre 2025

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Iraqi Social Media Mercenaries in Russia:** Roba presented their investigative report to the team, detailing how Iraqi social media influencers are recruiting Iraqis to fight for Russia in the Ukraine war, with the team supporting the investigation and discussing the challenges faced by families of missing Iraqis.
  + **Investigation Overview:** Roba explained that the investigation focused on Iraqi social media influencers who encourage Iraqis, many of whom are unemployed and living in poverty, to travel to Russia to fight in the Ukraine war, often without informing their families.
  + **Challenges for Families:** Roba described how many Iraqi families, particularly those from poor backgrounds, are left without information about their missing relatives in Russia and face difficulties in repatriating their bodies.
  + **Research Process:** Roba shared that the investigation took over a month and a half, with the entire office involved in gathering information, fact-checkers and Mena geolocating influencers, and stringers contributing to the effort.
  + **Political Angle and Focus:** Roba noted that while there are reports of political involvement in the recruitment, the investigation focused on the most tangible angle—the social media link and the families' stories—due to lack of evidence regarding politicians.
  + **Origin of the Story:** Roba revealed that the initial tip for the story came from the family of Hammad Ahmad, who posted on social media searching for him, which led to the broader investigation.
* **New York Election and Political Commentary:** The team discussed various aspects of the New York election, referencing political parties, candidates such as Donald Trump, and related political dynamics, with several participants contributing fragmented commentary.
  + **Election Parties and Candidates:** Participants mentioned the Democratic Party, Donald Trump, and other political figures, discussing their positions and the general atmosphere of the New York election.
* **Collaboration and Newsroom Operations:** Daphné and the team briefly discussed ongoing collaborations with other bureaus, including Paris and Tehran, and referenced preparations for upcoming news coverage.
  + **Bureau Collaboration:** Daphné mentioned ongoing contact and collaboration with the Tehran bureau and preparations involving other team members for future news coverage.

Généré par l’IA. Veillez à vérifier l’exactitude.

Notes de la réunion:

* **Crise de Gouvernance à la BBC:** Catherine a présenté un exposé détaillé sur la démission du directeur général et de la patronne de BBC News, suite à une polémique sur un montage trompeur dans un documentaire, avec des réactions politiques fortes de Boris Johnson, Donald Trump et l'ambassade d'Israël, et une attente persistante d'explications officielles de la BBC.
  + **Origine de la Polémique:** Catherine a expliqué que la crise a débuté avec la fuite d'un rapport interne critiquant un documentaire de la BBC sur Donald Trump et l'assaut du Capitole, où un montage a donné l'impression erronée que Trump avait appelé à attaquer le Capitole, ce qui a déclenché une vague de critiques contre la BBC.
  + **Réactions Politiques:** Boris Johnson a exigé la démission du directeur général de la BBC et a menacé de ne plus payer la redevance tant que des mesures ne seraient pas prises, tandis que Donald Trump et son équipe ont publiquement accusé la BBC de diffuser de fausses informations, et l'ambassade d'Israël s'est également réjouie des démissions.
  + **Conséquences et Attentes:** La BBC a publié un communiqué annonçant les démissions, mais n'a pas encore fourni d'explications sur le montage controversé ; le président de la BBC doit s'expliquer devant la commission parlementaire des médias, avec des modalités d'audition encore incertaines.
  + **Contexte Médiatique et Critiques:** Catherine a souligné que la BBC, comme d'autres médias traditionnels, fait face à des critiques croissantes sur son impartialité, dans un contexte de montée des médias partisans et d'accusations récurrentes, notamment sur la couverture de Trump et du conflit israélo-palestinien.
  + **Incidents Récents et Tensions Internes:** Des cas récents, comme la diffusion d'un live controversé et la révélation de l'identité du narrateur d'un documentaire, ont valu à la BBC des critiques du régulateur des médias, tandis que des divisions internes au sein du board de la BBC ont été évoquées comme facteur aggravant.
* **Défis Logistiques et Organisationnels de la COP à Belém:** Laura, Ivan et Thomas ont détaillé les difficultés rencontrées pour organiser la couverture de la COP à Belém, au cœur de l’Amazonie, notamment la gestion complexe de l’hébergement, la mobilisation d’équipes internationales et la coordination logistique sur place.
  + **Préparation et Mobilisation des Équipes:** Laura a expliqué que la préparation a nécessité une année de travail, impliquant des dizaines de journalistes de l’AFP dans le monde, avec environ 10 à 11 journalistes sur place malgré des coûts d’hébergement très élevés.
  + **Gestion de l’Hébergement:** Ivan a décrit les difficultés pour réserver des logements, dues à l’attente d’une plateforme officielle en retard, à la flambée des prix et à la nécessité de recourir à des contacts internes, comme la belle-sœur de Yann Bernal, pour loger une partie de l’équipe.
  + **Logistique sur Place:** L’équipe a dû s’adapter à une organisation locale en retard, avec une logistique complexe pour le centre de conférence, mais a finalement réussi à installer tous les membres nécessaires, y compris vidéastes, photographes, rédacteurs et techniciens.
  + **Stratégie de Couverture:** Ivan a précisé que la couverture AFP est très décentralisée, avec des équipes à distance à Paris et Washington, et une présence réduite de médias internationaux sur place, ce qui permet à l’AFP de se démarquer, notamment par des reportages originaux et des enquêtes multimédias.
* **Stratégie de Couverture et Enjeux de la COP:** Ivan et l’équipe ont exposé la stratégie de couverture de la COP, insistant sur la nécessité de se différencier dans un contexte très concurrentiel, et ont évoqué les principaux enjeux du sommet, notamment les tensions entre pays riches et pays vulnérables.
  + **Organisation de la Couverture:** Ivan a expliqué que la couverture est la plus décentralisée jamais réalisée par l’AFP pour une COP, avec une équipe sur place réduite et un appui quotidien des rédactions de Paris et Washington, tandis que d’autres médias internationaux ont réduit leur présence.
  + **Différenciation et Visibilité:** L’AFP vise à se distinguer en allant chercher des témoignages de délégués moins médiatisés et en produisant des contenus repris par de grands médias brésiliens, comme la une du Globo avec des photos AFP.
  + **Enjeux du Sommet:** Les discussions portent sur les clivages persistants entre pays riches et pays vulnérables, notamment sur la question des énergies fossiles et des conséquences du changement climatique, avec une forte présence de journalistes internationaux.
* **Enquête sur les Attaques Ethniques au Soudan:** Serene a présenté le reportage de l’AFP sur les attaques à caractère ethnique commises par les FSR au Soudan, soulignant la difficulté de l’enquête, la collecte de témoignages directs et la confirmation par des experts de l’ONU et MSF.
  + **Méthodologie de l’Enquête:** Serene a détaillé que l’équipe a intégré des éléments sur les attaques ethniques dans des reportages précédents, mais que ce papier est le premier à aborder explicitement ce sujet, avec la participation de plusieurs correspondants et stringers.
  + **Témoignages et Sources:** Le reportage s’appuie sur des témoignages directs de victimes, dont une femme ayant perdu son mari et son fils, ainsi que sur des avis d’experts de l’ONU et de MSF, et inclut le démenti officiel des FSR obtenu in extremis.
  + **Difficultés de la Couverture:** L’équipe a rencontré des difficultés majeures, notamment l’assassinat de sources et de médecins, ce qui complique la collecte d’informations et la sécurité des journalistes sur le terrain.

Tâches de suivi:

* **Explications attendues de la BBC:** Obtenir et diffuser les explications officielles de la BBC concernant le montage trompeur du documentaire sur Donald Trump. (Catherine)
* **Enquête multimédia sur les incendies en Amazonie:** Finaliser et publier l’enquête multimédia novatrice sur les responsables des incendies en Amazonie, en s’appuyant sur les reportages, interviews et analyses de données réalisés par l’équipe de cinq journalistes. (Laura)
* **Témoignages sur les attaques ethniques au Soudan:** Recueillir et intégrer des témoignages supplémentaires de survivants et d’experts pour renforcer la couverture des attaques ethniques au Soudan. (Serene)
* **Sécurité des sources au Soudan:** Expliquer dans les prochains jours comment certaines sources de l’AFP, notamment des médecins, ont été assassinées, et analyser l’impact sur la couverture du conflit. (Teams)

| | | | | | | **Note rédactionnelle**  *Mercredi 29 octobre* | | --- | | | --- | --- | | | --- | --- | --- | | | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | |
| --- | --- | --- | --- | --- | --- | --- |
| |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | |  | | --- | | | --- | --- | | | | **Cessez-le-feu à Gaza** | | --- | | | --- | --- | | | | ![img-0.jpg](img-0.jpg) | | --- | | | |  |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | | | | | Israël a annoncé reprendre le cessez-le-feu dans la bande de Gaza après des frappes nocturnes ayant fait plus de cent morts, selon des sources palestiniennes à Gaza, en représailles à l’attaque ayant tué un soldat israélien. Nous avons eu des images fortes des blessés à l’hôpital Al-Adwa à Nousseirat et sommes en direct en vidéo depuis le sud d’Israël.    Les journalistes travaillant sur Gaza ont alimenté toute la nuit le Global Shift à Hong Kong avec les détails pour faire les alertes et les éléments de couleur pour alimenter la confection des papiers.    La production met bien en avant l’épuisement des populations civiles : “Nous venions tout juste de commencer à respirer à nouveau, à essayer de reconstruire nos vies, quand les bombardements ont repris, ramenant la guerre, les explosions et la mort”, a dit une habitante de Gaza citée.    L’envoyée spéciale de la Maison Blanche, qui suit Donald Trump dans sa tournée asiatique, a elle aussi alerté sur les déclarations faites depuis Air Force One en direction de Séoul. Il a assuré que le cessez-le-feu restait intact, tout en estimant qu’Israël était en droit de riposter à la mort du soldat. Le Hamas a réaffirmé son engagement envers la trêve, mais les échanges d’accusations entre les deux camps fragilisent fortement l’accord.    Une série marquante de photos montre des membres du Hamas creusant avec un bulldozer pour extraire un corps supposé appartenir à un otage près de Khan Younès – première scène du genre depuis le début du conflit. | | --- | | | --- | --- | | | --- | --- | --- | | | ![img-1.jpg](img-1.jpg) | | --- | | | | | | | | | | | | | | | **Ouragan Melissa** | | --- | | | --- | --- | | | | | | | | | | | | | | ![img-2.jpg](img-2.jpg) | | --- | | | --- | --- | | | | ![img-3.jpg](img-3.jpg) | | --- | | | --- | --- | | | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | | | | | | | | | | | | ![img-4.jpg](img-4.jpg) | | --- | | | --- | --- | | | | ![img-5.jpg](img-5.jpg) | | --- | | | --- | --- | | | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | | | | L’ouragan Melissa a touché mercredi la côte sud-est de Cuba, rétrogradé en catégorie 3 mais toujours accompagné de vents dépassant les 200 km/h. En Jamaïque, désormais déclarée « zone sinistrée », plus de 530.000 personnes restent sans électricité et plusieurs hôpitaux ont été endommagés.    Nos équipes à Santiago de Cuba ont passé la nuit à l’abri et les connexions sont désormais coupées dans la région. Le bureau de La Havane a assuré jusqu’au petit matin la veille avec la Cellule USA et les desks parisien et de Hong Kong en appui, qui ont alerté sur le communiqué du Centre national américain des ouragans (NHC) annonçant que Melissa touchait terre cubaine.    Une équipe reste en stand-by à Miami pour rejoindre la Jamaïque dès la réouverture des liaisons aériennes, et un appel a été lancé à l’ensemble des bureaux et régions concernés pour tenter de se joindre aux équipes de secours étrangères qui pourraient être déployées sur place.    Le desk vidéo à Washington a sourcé et vérifié plusieurs contenus UGC très utilisés au vu des difficultés d’accès et des dégâts dans les zones isolées. Un live de plusieurs heures a pu être réalisé hier par ailleurs grâce à un réseau de caméras de vidéosurveillance locales.    Bon travail d’analyse de Dataviz. Grâce aux données NOAA, l’AFP a réussi à confirmer que Melissa était la tempête tropicale la plus puissante de 2025, avec des vents ayant atteint 300 km/h en Jamaïque, et en a tiré une bonne alerte. Le service a pu également produire une vidéo du passage de l’ouragan. | | --- | | | --- | --- | | | | ![img-6.png](img-6.png) | | --- | | | | | **TRUMP EN ASIE** | | --- | | | --- | --- | | | | ![img-7.jpg](img-7.jpg) | | --- | | | | | Donald Trump poursuit sa tournée asiatique avec une arrivée en Corée du Sud mercredi, avant une rencontre prévue jeudi avec Xi Jinping à Busan. Il dit s'attendre à une "excellente rencontre" avec le président chinois, estimant qu’il pourrait résoudre plusieurs différends commerciaux et diplomatiques.    Aucune entrevue en revanche avec Kim Jong Un n’est à l’agenda, Trump jugeant que “l’heure n’est pas encore venue”. Le président a visité le musée national de Gyeongju, où il s’est vu offrir une réplique d’une couronne portée par les rois de Silla. Bon cliché pris par le photographe de l’AFP voyageant avec lui.    Trump devait également participer à un dîner auquel doit aussi être présent le Premier ministre canadien Mark Carney. Les deux voisins nord-américains ne devraient toutefois pas avoir d’échange suite à la colère de Trump sur une publicité diffusée par la province de l’Ontario contre les droits de douane.    Pour le sommet de l’APEC, nous avons sur place six journalistes texte, quatre vidéastes et deux photographes. | | --- | | | --- | --- | | | | | |
| |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | | |  | | --- | | | | **Autres titres** | | --- | | | --- | --- | | | | | * **INFO AFP -** La Suissesse Laura Villars, empêchée de postuler à la présidence de la Fédération internationale de l'automobile (FIA), a assignél'instance en justice pour contester les règles du scrutin, qui interdisent selon elle à tout opposant à l'actuel président, l'Emirati Mohamed Ben Sulayem, de se présenter. * **INFO AFP** - Des habitants d'une favela du nord de Rio de Janeiro ont aligné plus de 40 corps sur une place mercredi matin, au lendemain de l'opération policière la plus sanglante de l'histoire de la ville contre un gang de narcotrafiquants, a constaté l'AFP. * Les électeurs néerlandais se rendent aux urnes pour des élections législatives anticipées qui devraient permettre d'évaluer l'ampleur de la poussée de l'extrême droite partout en Europe. Très bon travail de préparation pour un scrutin clé. * Les négociations entre le Pakistan et l'Afghanistan pour une trêve durable ont échoué, selon Islamabad. Pas de confirmation encore côté taliban. * La Tanzanie fait face à une "perturbation nationale" d'internet mercredi, jour où se déroulent des élections présidentielle et législatives desquelles l'opposition a été largement tenue à l'écart, a affirmé l'ONG de surveillance de la cybersécurité Netblocks. * L'affaire du vol spectaculaire de huit joyaux de la Couronne de France au Louvre pourrait connaître une accélération mercredi, avec la fin imminente des gardes à vue des deux suspects interpellés et une conférence de presse de la procureure de Paris. * Les Etats-Unis vont réduire leur présence militaire sur le front oriental de l'Europe, a annoncé la Roumanie. * L'Espagne rend un hommage solennel dans des "funérailles d'Etat" aux plus de 230 personnes disparues il y a un an, jour pour jour, dans des inondations qui restent la pire catastrophe naturelle du pays depuis des décennies. | | --- | | | --- | --- | | | | | **Highlight** | | --- | | | --- | --- | | | | ![img-8.jpg](img-8.jpg) | | --- | | | | | Le bureau de New Delhi a réussi à obtenir la première interview de l’ex-Première ministre du Bangladesh Sheikh Hasina, renversée etdésormais réfugiée à New Delhi. Après des mois de tentatives et de messages envoyés via ses contacts, Delhi a finalement obtenu une série de réponses écrites aux questions envoyées.    Dans cette interview, Sheikh Hasina dénonce son procès comme une « farce politique » et estime qu’un scrutin sans son parti risque de créer des divisions. Ces deux éléments ont été alertés avant publication de l’entretien. Il s’agit des premières déclarations à un média de Hasina depuis un an. Le tribunal de Dacca la juge depuis juin par contumace pour avoir ordonné la répression des émeutes qui ont précipité sa chute en 2024. Le verdict est attendu le 13 novembre. | | --- | | | --- | --- | | | | | |