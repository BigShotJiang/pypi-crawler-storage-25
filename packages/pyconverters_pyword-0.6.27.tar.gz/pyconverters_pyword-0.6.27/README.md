# pyconverters_pyword

[![license](https://img.shields.io/pypi/l/pyconverters-pyword)](https://bitbucket.org/kairntech/pyconverters_pyword/src/master/LICENSE)
[![version](https://img.shields.io/pypi/v/pyconverters-pyword)](https://pypi.org/project/pyconverters-pyword/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters-pyword)](https://pypi.org/project/pyconverters-pyword/)

Convert DOCX to Markdown using [mammoth](https://github.com/mwilliamson/python-mammoth)

## Installation

You can simply `pip install pyconverters-pyword`.

## Developing

### Pre-requisites

You will need to install [uv](https://docs.astral.sh/uv/) (for managing the virtual environment and dependencies):

```
pip install uv
```

Clone the repository:

```
git clone https://bitbucket.org/kairntech/pyconverters_pyword
```

Install the project with its test dependencies:

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
