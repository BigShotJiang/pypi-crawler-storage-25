<!-- mcp-name: com.easyship/mcp -->
# Easyship MCP Server

MCP server for [Easyship](https://www.easyship.com) — get shipping rates and track shipments.

## Tools

- **get_shipping_rates** — compare courier options with prices and delivery times for a parcel
- **track_shipment** — get current status and checkpoint history for a shipment

## Quick Start

### Claude Desktop

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "easyship": {
      "command": "uvx",
      "args": ["easyship-mcp"],
      "env": {
        "EASYSHIP_API_ACCESS_TOKEN": "your-key-here"
      }
    }
  }
}
```

### Claude Code

```bash
claude mcp add easyship -- uvx easyship-mcp
```

Then set `EASYSHIP_API_ACCESS_TOKEN` in your environment.

## Configuration

Get your API key from [Easyship Dashboard → Connect → API](https://app.easyship.com/connect/api).

```bash
export EASYSHIP_API_ACCESS_TOKEN="your-key-here"
```

## Install from source

```bash
pip install -e .
```

## Usage examples

**Get shipping rates:**
> "What are the shipping options for a 1.5kg package (30×20×15 cm) from Hong Kong to New York?"

**Track a shipment:**
> "Track shipment ESSG10006001"

## API version

This server targets the Easyship API **v2024-09**.

## License

MIT
