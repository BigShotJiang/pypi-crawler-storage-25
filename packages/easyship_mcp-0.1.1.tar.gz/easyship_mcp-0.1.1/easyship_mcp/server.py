"""Easyship MCP Server — shipping rates and tracking via the Easyship API."""

from __future__ import annotations

import os
from typing import Any

import httpx
from fastmcp import FastMCP

BASE_URL = "https://public-api.easyship.com"
API_VERSION = "2024-09"

mcp = FastMCP(
    "Easyship",
    instructions="Get shipping rates and track shipments using the Easyship API",
)


def _get_client() -> httpx.AsyncClient:
    api_key = os.environ.get("EASYSHIP_API_ACCESS_TOKEN", "")
    if not api_key:
        raise ValueError(
            "EASYSHIP_API_ACCESS_TOKEN environment variable is not set. "
            "Get your API key from https://app.easyship.com/connect/api"
        )
    return httpx.AsyncClient(
        base_url=BASE_URL,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        timeout=30.0,
    )


def _parse_error(response: httpx.Response) -> dict[str, Any]:
    """Extract a structured error from an Easyship error response."""
    try:
        body = response.json()
        err = body.get("error", {})
        return {
            "error": True,
            "status_code": response.status_code,
            "type": err.get("type", "unknown_error"),
            "code": err.get("code", "unknown"),
            "message": err.get("message", response.text),
            "details": err.get("details", []),
        }
    except Exception:
        return {
            "error": True,
            "status_code": response.status_code,
            "message": response.text or f"HTTP {response.status_code}",
        }


# ── Tool 1: get_shipping_rates ──────────────────────────────────────────────


@mcp.tool()
async def get_shipping_rates(
    origin_country_alpha2: str,
    destination_country_alpha2: str,
    total_actual_weight: float,
    length: float,
    width: float,
    height: float,
    item_description: str = "General goods",
    item_quantity: int = 1,
    item_declared_customs_value: float = 10.0,
    item_declared_currency: str = "USD",
    item_category: str | None = None,
    origin_city: str | None = None,
    origin_state: str | None = None,
    origin_postal_code: str | None = None,
    destination_city: str | None = None,
    destination_state: str | None = None,
    destination_postal_code: str | None = None,
    destination_line_1: str | None = None,
    output_currency: str | None = None,
    incoterms: str | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """Get available shipping rates (courier options with prices and delivery times) for a parcel.

    Compares couriers to find the cheapest, fastest, or best-value option for
    shipping a package between two countries.

    Args:
        origin_country_alpha2: ISO 3166-1 alpha-2 origin country code, e.g. "US", "HK", "GB".
        destination_country_alpha2: ISO 3166-1 alpha-2 destination country code, e.g. "SG", "DE", "JP".
        total_actual_weight: Total weight of the parcel in kg, including packaging. Example: 1.5
        length: Box length in cm. Example: 30
        width: Box width in cm. Example: 20
        height: Box height in cm. Example: 15
        item_description: Short description of what is being shipped. Example: "Cotton T-Shirts"
        item_quantity: Number of items in the parcel. Default 1.
        item_declared_customs_value: Declared customs value per item in the currency specified. Example: 25.0
        item_declared_currency: ISO-4217 currency code for customs value. Example: "USD", "EUR", "GBP".
        item_category: Item category slug (e.g. "fashion", "electronics", "documents"). Optional.
        origin_city: Origin city. Recommended for US, CA, MX, AU for accurate rates.
        origin_state: Origin state/province. Use 2-letter abbreviation for US/CA.
        origin_postal_code: Origin postal code. Required for most countries.
        destination_city: Destination city. Recommended for US, CA, MX, AU.
        destination_state: Destination state/province. Use 2-letter abbreviation for US/CA.
        destination_postal_code: Destination postal code. Required for most countries.
        destination_line_1: Destination street address line 1. Some couriers need this for accurate rates.
        output_currency: ISO-4217 currency for returned prices (e.g. "USD"). Defaults to origin country currency.
        incoterms: "DDU" (buyer pays duties on delivery) or "DDP" (seller pre-pays duties). Optional.

    Returns:
        A list of rate options, each with courier name, price breakdown, and delivery estimate.
    """
    origin_address: dict[str, Any] = {"country_alpha2": origin_country_alpha2}
    if origin_city:
        origin_address["city"] = origin_city
    if origin_state:
        origin_address["state"] = origin_state
    if origin_postal_code:
        origin_address["postal_code"] = origin_postal_code

    destination_address: dict[str, Any] = {"country_alpha2": destination_country_alpha2}
    if destination_line_1:
        destination_address["line_1"] = destination_line_1
    if destination_city:
        destination_address["city"] = destination_city
    if destination_state:
        destination_address["state"] = destination_state
    if destination_postal_code:
        destination_address["postal_code"] = destination_postal_code

    item: dict[str, Any] = {
        "description": item_description,
        "quantity": item_quantity,
        "declared_customs_value": item_declared_customs_value,
        "declared_currency": item_declared_currency,
    }
    if item_category:
        item["category"] = item_category

    payload: dict[str, Any] = {
        "origin_address": origin_address,
        "destination_address": destination_address,
        "parcels": [
            {
                "total_actual_weight": total_actual_weight,
                "box": {"length": length, "width": width, "height": height},
                "items": [item],
            }
        ],
    }

    if output_currency:
        payload["shipping_settings"] = {"output_currency": output_currency}
    if incoterms:
        payload["incoterms"] = incoterms

    try:
        async with _get_client() as client:
            resp = await client.post(f"/{API_VERSION}/rates", json=payload)
    except ValueError as e:
        return {"error": True, "message": str(e)}
    except httpx.HTTPError as e:
        return {"error": True, "message": f"HTTP request failed: {e}"}

    if resp.status_code != 200:
        return _parse_error(resp)

    data = resp.json()
    rates = data.get("rates", [])

    # Flatten to only the fields an AI agent would care about
    return [
        {
            "courier_name": r.get("courier_service", {}).get("name"),
            "courier_id": r.get("courier_service", {}).get("id"),
            "min_delivery_days": r.get("min_delivery_time"),
            "max_delivery_days": r.get("max_delivery_time"),
            "total_charge": r.get("total_charge"),
            "shipment_charge": r.get("shipment_charge"),
            "fuel_surcharge": r.get("fuel_surcharge"),
            "insurance_fee": r.get("insurance_fee"),
            "remote_area_surcharge": r.get("remote_area_surcharge"),
            "currency": r.get("currency"),
            "incoterms": r.get("incoterms"),
            "estimated_import_tax": r.get("estimated_import_tax"),
            "estimated_import_duty": r.get("estimated_import_duty"),
            "description": r.get("full_description"),
            "cost_rank": r.get("cost_rank"),
            "delivery_time_rank": r.get("delivery_time_rank"),
            "value_for_money_rank": r.get("value_for_money_rank"),
            "easyship_rating": r.get("easyship_rating"),
            "discount_amount": (r.get("discount") or {}).get("amount"),
            "payment_recipient": r.get("payment_recipient"),
        }
        for r in rates
    ]


# ── Tool 2: track_shipment ──────────────────────────────────────────────────


@mcp.tool()
async def track_shipment(
    easyship_shipment_id: str | None = None,
    platform_order_number: str | None = None,
) -> dict[str, Any] | list[dict[str, Any]]:
    """Track a shipment and get its current status plus checkpoint history.

    Provide either the Easyship shipment ID (e.g. "ESSG10006001") or the
    platform/order number from your store. Returns the latest status,
    estimated delivery date, and a list of tracking checkpoints showing
    the shipment's journey.

    Args:
        easyship_shipment_id: The Easyship shipment ID, e.g. "ESSG10006001" or "ESHK10017799".
            You get this when creating a shipment via the API or from the Easyship dashboard.
        platform_order_number: Your store's order number, e.g. "#1042". Use this if you
            don't have the Easyship shipment ID.

    Returns:
        Tracking status with checkpoints showing the shipment's journey, or an error.
    """
    if not easyship_shipment_id and not platform_order_number:
        return {
            "error": True,
            "message": "Provide either easyship_shipment_id or platform_order_number.",
        }

    params: dict[str, Any] = {"include_checkpoints": "true"}
    if easyship_shipment_id:
        params["easyship_shipment_id"] = easyship_shipment_id
    if platform_order_number:
        params["platform_order_number"] = platform_order_number

    try:
        async with _get_client() as client:
            resp = await client.get(f"/{API_VERSION}/shipments/trackings", params=params)
    except ValueError as e:
        return {"error": True, "message": str(e)}
    except httpx.HTTPError as e:
        return {"error": True, "message": f"HTTP request failed: {e}"}

    if resp.status_code != 200:
        return _parse_error(resp)

    data = resp.json()
    shipments = data.get("shipments", [])

    if not shipments:
        return {
            "error": True,
            "message": "No shipment found for the given ID.",
        }

    results = []
    for s in shipments:
        checkpoints = [
            {
                "time": cp.get("checkpoint_time"),
                "status": cp.get("primary_status"),
                "message": cp.get("message"),
                "location": cp.get("location"),
                "city": cp.get("city"),
                "country": cp.get("country_name"),
                "handler": cp.get("handler"),
            }
            for cp in (s.get("checkpoints") or [])
        ]

        tracking_numbers = [
            {
                "tracking_number": t.get("tracking_number"),
                "handler": t.get("handler"),
                "leg": t.get("leg_number"),
                "state": t.get("tracking_state"),
            }
            for t in (s.get("trackings") or [])
        ]

        results.append(
            {
                "easyship_shipment_id": s.get("easyship_shipment_id"),
                "status": s.get("status"),
                "eta_date": s.get("eta_date"),
                "origin_country": s.get("origin_country_alpha2"),
                "destination_country": s.get("destination_country_alpha2"),
                "platform_order_number": s.get("platform_order_number"),
                "tracking_page_url": s.get("tracking_page_url"),
                "tracking_numbers": tracking_numbers,
                "checkpoints": checkpoints,
            }
        )

    return results[0] if len(results) == 1 else results


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
