"""
supero.cli.env_manager — .env file management + config.js generation.

Reads, writes, and manages .env values for Supero apps.
Also generates the runtime config.js that the web UI reads.
No external dependencies.

Quoting rules (important):
  - All values are written QUOTED in double quotes, always.
    This makes .env files safe to `source` in bash, safe for Docker
    --env-file, and removes any ambiguity with special chars like
    `=`, `#`, spaces, or `$`.
  - On read, outer single- or double-quotes are stripped exactly once.
    Backslash escapes inside quotes (\\" and \\\\) are unescaped.

Project name rule (important):
  - SUPERO_PROJECT has NO default. If not set, generate_config_js()
    raises, setup fails loudly, and the caller must fix the config.
  - "default-project" used to be a silent fallback that routed apps
    to a zombie namespace. Never again.
"""

import os
import re


# Keys that, if present, form a complete Supero app configuration.
# Used by is_configured() and validation in save().
_REQUIRED_API_KEY_MODE = ("SUPERO_DOMAIN", "SUPERO_PROJECT", "SUPERO_API_KEY")
_REQUIRED_PASSWORD_MODE = ("SUPERO_DOMAIN", "SUPERO_PROJECT", "SUPERO_ADMIN_EMAIL", "SUPERO_PASSWORD")

# Well-known Supero-related keys (used for clear() and env-override logic)
_SUPERO_KEYS = (
    "SUPERO_URL", "SUPERO_DOMAIN", "SUPERO_ADMIN_EMAIL",
    "SUPERO_PASSWORD", "SUPERO_API_KEY", "SUPERO_PROJECT",
    "SUPERO_DEFAULT_TENANT",
    "PLATFORM_CORE_HOST", "PLATFORM_CORE_PORT",
    "PUBLIC_SCHEMAS",
    "APP_NAME", "APP_EMOJI", "APP_DESCRIPTION",
    "PORT", "UI_PORT",
    "SUPERO_PREVIEW",  # set by Cloud Run preview containers
)


def _shell_quote(value: str) -> str:
    """
    Quote a value for safe .env storage.

    Always uses double quotes so shell `source`, Docker --env-file,
    and most parsers all agree. Escapes embedded backslashes and
    double quotes.
    """
    if value is None:
        return '""'
    s = str(value)
    # Escape backslashes FIRST, then double quotes
    s = s.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{s}"'


def _shell_unquote(value: str) -> str:
    """
    Reverse of _shell_quote. Strips one layer of matching outer
    single- or double-quotes and unescapes backslash escapes inside
    double-quoted values.

    - '"foo"'      → 'foo'
    - "'foo'"      → 'foo'
    - '"he said \\"hi\\""' → 'he said "hi"'
    - 'foo'        → 'foo'  (no quotes, returned as-is)
    - '"mismatched\\''  → '"mismatched\\''  (no matching quotes, returned as-is)
    """
    if value is None or len(value) < 2:
        return value

    first, last = value[0], value[-1]
    if first == last and first in ('"', "'"):
        inner = value[1:-1]
        if first == '"':
            # Unescape \\ and \"
            inner = inner.replace('\\"', '"').replace("\\\\", "\\")
        return inner
    return value


class EnvManager:
    """
    Manages .env configuration for Supero apps.

    Reads/writes .env files with proper quoting, merges environment
    variables (for containerized deploys), and generates the config.js
    file that the web UI reads at runtime.
    """

    def __init__(self, env_path: str = ".env"):
        self.path = env_path
        self.values: dict = {}
        self._load()

    # ─────────────────────────────────────────────────────────────
    # Loading
    # ─────────────────────────────────────────────────────────────

    def _load(self):
        """
        Load values from .env file if it exists, then layer OS environment
        on top (environment always wins, to support Docker/Cloud Run deploys
        that inject config via env vars without touching .env).

        Unlike the previous implementation, this version:
          - Strips quotes properly (matching pairs only)
          - Unescapes \\\" and \\\\ inside double-quoted values
          - Warns on malformed lines instead of silently dropping them
          - Picks up well-known Supero env vars even if .env is missing
            or doesn't contain them (critical for preview containers)
        """
        # 1. Read .env file if present
        if os.path.exists(self.path):
            with open(self.path) as f:
                for lineno, raw_line in enumerate(f, start=1):
                    line = raw_line.strip()
                    if not line or line.startswith("#"):
                        continue

                    # Allow optional `export KEY=VALUE` form
                    if line.startswith("export "):
                        line = line[len("export "):].lstrip()

                    if "=" not in line:
                        print(f"  ⚠ {self.path}:{lineno}: skipping malformed line (no '='): {line[:40]}")
                        continue

                    key, val = line.split("=", 1)
                    key = key.strip()
                    val = val.strip()

                    if not key or not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", key):
                        print(f"  ⚠ {self.path}:{lineno}: skipping invalid key: {key!r}")
                        continue

                    self.values[key] = _shell_unquote(val)

        # 2. Layer OS environment on top (env always wins).
        #
        # Loop over the UNION of keys already in .env AND well-known
        # Supero keys that MAY be in the environment. This fixes the
        # Cloud Run preview scenario where .env was stripped during
        # sanitization but Cloud Run injects SUPERO_* env vars.
        candidate_keys = set(self.values.keys()) | set(_SUPERO_KEYS)
        for key in candidate_keys:
            env_val = os.environ.get(key)
            if env_val is not None and env_val != "":
                self.values[key] = env_val

    def reload(self):
        """Reload .env file (call after setup.py may have modified it)."""
        self.values.clear()
        self._load()

    # ─────────────────────────────────────────────────────────────
    # Access
    # ─────────────────────────────────────────────────────────────

    def get(self, key: str, default: str = "") -> str:
        """
        Get a value. Priority order:
          1. In-memory value (from .env load + any set() calls)
          2. OS environment
          3. provided default

        Note: _load() already merges env into self.values, so path (1)
        is normally authoritative. Path (2) is a safety net for keys
        set via os.environ after construction.
        """
        val = self.values.get(key)
        if val:
            return val
        env_val = os.environ.get(key)
        if env_val:
            return env_val
        return default

    def set(self, key: str, value: str):
        """Set a value in memory and in the process environment."""
        self.values[key] = value
        os.environ[key] = value

    def is_configured(self) -> bool:
        """
        Check if minimum configuration exists to run setup.

        Two valid modes:
          - API-key mode: DOMAIN + PROJECT + ak_... API key
          - Password mode: DOMAIN + PROJECT + EMAIL + PASSWORD

        NOTE: PROJECT is now required in both modes. Previously it
        silently defaulted to "default-project", which caused apps
        to upload schemas to the wrong namespace.
        """
        api_key = self.get("SUPERO_API_KEY", "")
        if (
            self.get("SUPERO_DOMAIN")
            and self.get("SUPERO_PROJECT")
            and api_key.startswith("ak_")
        ):
            return True
        return bool(
            self.get("SUPERO_DOMAIN")
            and self.get("SUPERO_PROJECT")
            and self.get("SUPERO_ADMIN_EMAIL")
            and self.get("SUPERO_PASSWORD")
        )

    def missing_required_keys(self) -> list:
        """
        Return a list of required keys missing for either config mode.
        Useful for producing actionable error messages.
        """
        api_key = self.get("SUPERO_API_KEY", "")
        if api_key.startswith("ak_"):
            return [k for k in _REQUIRED_API_KEY_MODE if not self.get(k)]
        return [k for k in _REQUIRED_PASSWORD_MODE if not self.get(k)]

    # ─────────────────────────────────────────────────────────────
    # Writing
    # ─────────────────────────────────────────────────────────────

    def save(self, allow_partial: bool = False):
        """
        Write current values to .env file, quoting all values.

        Args:
            allow_partial: If False (default), raises ValueError if
                           required keys are missing. Set True only for
                           partial/bootstrap writes from interactive
                           setup where the user hasn't filled in
                           everything yet.

        All values are double-quoted with proper escape handling, so the
        resulting .env is safe to `source` in bash and to pass as a
        Docker --env-file.
        """
        if not allow_partial:
            missing = self.missing_required_keys()
            if missing:
                raise ValueError(
                    f"Refusing to save incomplete .env — missing required keys: "
                    f"{', '.join(missing)}. Pass allow_partial=True if intentional."
                )

        with open(self.path, "w") as f:
            f.write("# Supero App Configuration\n")
            f.write("# Generated by supero CLI — edit or delete to re-configure\n")
            f.write("# All values are double-quoted for safe shell/Docker parsing.\n\n")

            ordered_keys = [
                "SUPERO_URL", "SUPERO_DOMAIN", "SUPERO_ADMIN_EMAIL",
                "SUPERO_PASSWORD", "SUPERO_PROJECT", "SUPERO_API_KEY",
                "SUPERO_DEFAULT_TENANT",
                "PLATFORM_CORE_HOST", "PLATFORM_CORE_PORT",
                "PUBLIC_SCHEMAS",
                "APP_NAME", "APP_EMOJI", "APP_DESCRIPTION",
                "PORT", "UI_PORT",
            ]
            written = set()

            for key in ordered_keys:
                if key in self.values:
                    f.write(f"{key}={_shell_quote(self.values[key])}\n")
                    written.add(key)

            remaining = {k: v for k, v in self.values.items() if k not in written}
            if remaining:
                f.write("\n# Additional configuration\n")
                for key, val in remaining.items():
                    f.write(f"{key}={_shell_quote(val)}\n")

    def clear(self):
        """Clear all values and delete .env file."""
        self.values.clear()
        if os.path.exists(self.path):
            os.remove(self.path)

        for key in _SUPERO_KEYS:
            os.environ.pop(key, None)

    # ─────────────────────────────────────────────────────────────
    # SDK derivations
    # ─────────────────────────────────────────────────────────────

    def derive_sdk_vars(self):
        """
        Derive PLATFORM_CORE_HOST and PLATFORM_CORE_PORT from SUPERO_URL.

        The Supero SDK reads these env vars for API connectivity,
        not the higher-level SUPERO_URL.
        """
        url = self.get("SUPERO_URL", "https://api.supero.dev")
        stripped = url.replace("http://", "").replace("https://", "")

        if ":" in stripped:
            host = stripped.split(":")[0]
            port = stripped.split(":")[1].split("/")[0]
        elif url.startswith("https://"):
            host = stripped.split("/")[0]
            port = "443"
        else:
            host = stripped.split("/")[0]
            port = "8083"

        self.set("PLATFORM_CORE_HOST", host)
        self.set("PLATFORM_CORE_PORT", port)

    # ─────────────────────────────────────────────────────────────
    # config.js generation
    # ─────────────────────────────────────────────────────────────

    def generate_config_js(self, ui_dir: str, app_name: str = "", app_emoji: str = "", app_description: str = "", public_schemas: list = None):
        """
        Generate config.js for the web UI.

        The web UI reads window.__SUPERO_CONFIG at startup to determine
        domain, project, API server, and app branding for the login page.

        CRITICAL CHANGES vs. previous version:
          - SUPERO_PROJECT NO LONGER defaults to "default-project".
            If it's missing, this method raises ValueError. This prevents
            the silent-fallback-to-zombie-namespace bug where apps were
            deployed pointing at a project that was never explicitly set.
          - SUPERO_DOMAIN is also required (was implicitly empty string).
        """
        domain = self.get("SUPERO_DOMAIN", "")
        project = self.get("SUPERO_PROJECT", "")

        if not domain:
            raise ValueError(
                "Cannot generate config.js: SUPERO_DOMAIN is not set. "
                "Run `supero init` or set SUPERO_DOMAIN in the environment."
            )
        if not project:
            raise ValueError(
                "Cannot generate config.js: SUPERO_PROJECT is not set. "
                "There is NO default project — pass --project or set "
                "SUPERO_PROJECT explicitly. 'default-project' is no longer "
                "a silent fallback because it caused apps to route schemas "
                "to the wrong namespace."
            )

        tenant = self.get("SUPERO_DEFAULT_TENANT", "default-tenant")
        api_url = self.get("SUPERO_URL", "https://api.supero.dev")

        # App branding: env > method args > domain-derived
        name = self.get("APP_NAME") or app_name or domain.replace("-", " ").title() or "Supero App"
        emoji = self.get("APP_EMOJI") or app_emoji or "🚀"
        description = self.get("APP_DESCRIPTION") or app_description or ""

        def js_escape(s: str) -> str:
            return s.replace("\\", "\\\\").replace('"', '\\"')

        # publicSchemas is the runtime injection point for the browser.
        # The CLI populates it from schemas.py PUBLIC_SCHEMAS so AppShell
        # never has to read it from app.js (where the LLM might have
        # hardcoded a wrong value).
        _ps_list = list(public_schemas) if public_schemas is not None else []
        _ps_js_items = ", ".join(f'"{js_escape(s)}"' for s in _ps_list)
        _ps_js_array = f"[{_ps_js_items}]"

        config_js = (
            "// Generated by supero CLI — do not edit manually\n"
            "window.__SUPERO_CONFIG = {\n"
            f'    domain: "{js_escape(domain)}",\n'
            f'    project: "{js_escape(project)}",\n'
            f'    tenant: "{js_escape(tenant)}",\n'
            f'    apiUrl: "{js_escape(api_url)}",\n'
            f'    appName: "{js_escape(name)}",\n'
            f'    appEmoji: "{js_escape(emoji)}",\n'
            f'    appDescription: "{js_escape(description)}",\n'
            f'    publicSchemas: {_ps_js_array}\n'
            "};\n"
        )

        os.makedirs(ui_dir, exist_ok=True)
        config_path = os.path.join(ui_dir, "config.js")
        with open(config_path, "w") as f:
            f.write(config_js)

        print(f"  ✓ Generated config.js (domain={domain}, project={project})")
