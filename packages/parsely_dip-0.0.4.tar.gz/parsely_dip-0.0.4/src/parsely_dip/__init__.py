"""PARSELY-DIP: Parsing And RegEx Syntactic Engine with Linguistic Yield - Deterministic Intent Parser"""

__version__ = "0.0.4"

from pathlib import Path
from parsely_dip.engine.regex import load_patterns, check_regex
from parsely_dip.engine.nlp import load_nlp_patterns, check_nlp
from parsely_dip.engine.registry import dispatch

# Auto-import intents to trigger @intent decorator registration
from parsely_dip.intents import time  # noqa: F401
from parsely_dip.intents import weather  # noqa: F401
from parsely_dip.intents import scrum  # noqa: F401
from parsely_dip.intents import day  # noqa: F401

# Default pattern paths (package-relative)
_PATTERNS_DIR = Path(__file__).parent / "patterns"
_regex_patterns = None
_nlp_patterns = None
_regex_mtime = 0
_nlp_mtime = 0


def _load_default_patterns():
    """Load default patterns, reloading if files changed on disk."""
    global _regex_patterns, _nlp_patterns, _regex_mtime, _nlp_mtime

    base_patterns = _PATTERNS_DIR / "base.patterns"
    base_nlp = _PATTERNS_DIR / "base_nlp.json"

    rx_mtime = base_patterns.stat().st_mtime if base_patterns.exists() else 0
    nlp_mt = base_nlp.stat().st_mtime if base_nlp.exists() else 0

    if _regex_patterns is None or rx_mtime != _regex_mtime:
        _regex_patterns = load_patterns(base_patterns)
        _regex_mtime = rx_mtime

    if _nlp_patterns is None or nlp_mt != _nlp_mtime:
        _nlp_patterns = load_nlp_patterns(base_nlp)
        _nlp_mtime = nlp_mt


def parse(prompt, regex_patterns=None, nlp_patterns=None):
    """Parse a prompt through the DIP pipeline.

    RegEx first, then NLP, then returns None (pass to LLM).

    Args:
        prompt: raw user input string
        regex_patterns: optional override (list from load_patterns)
        nlp_patterns: optional override (list from load_nlp_patterns)

    Returns:
        str response if matched, None if no match
    """
    if regex_patterns is None or nlp_patterns is None:
        _load_default_patterns()

    rx = regex_patterns if regex_patterns is not None else _regex_patterns
    nlp = nlp_patterns if nlp_patterns is not None else _nlp_patterns

    # Layer 1: Regex
    intent_name, context = check_regex(prompt, rx)

    # Layer 2: NLP (only if regex missed)
    if not intent_name and nlp:
        intent_name, context = check_nlp(prompt, nlp)

    # Dispatch to handler with context
    if intent_name:
        return dispatch(intent_name, context)

    return None
