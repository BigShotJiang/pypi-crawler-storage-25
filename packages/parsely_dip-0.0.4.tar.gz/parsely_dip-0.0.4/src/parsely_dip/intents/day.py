"""Intent: Tell Day

Returns day of the week for a given date reference.
Handles: today, tomorrow, yesterday, relative days, holidays, specific dates.
"""

from datetime import datetime, timedelta
from parsely_dip.engine.registry import intent


# Relative day words
RELATIVE_DAYS = {
    "today": 0,
    "tomorrow": 1,
    "yesterday": -1,
}

# Weekday names for lookup
WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

# Fixed US holidays (month, day) -> name
HOLIDAYS = {
    (1, 1): "New Year's Day",
    (2, 14): "Valentine's Day",
    (3, 17): "St. Patrick's Day",
    (4, 1): "April Fool's Day",
    (5, 5): "Cinco de Mayo",
    (6, 19): "Juneteenth",
    (7, 4): "Independence Day",
    (9, 11): "Patriot Day",
    (10, 31): "Halloween",
    (11, 11): "Veterans Day",
    (12, 25): "Christmas Day",
    (12, 31): "New Year's Eve",
}


def _nth_weekday(year, month, weekday, n):
    """Find the Nth occurrence of a weekday in a month.

    Args:
        year: target year
        month: target month (1-12)
        weekday: 0=Monday, 6=Sunday
        n: occurrence (1=first, 2=second, etc.)

    Returns:
        datetime
    """
    first = datetime(year, month, 1)
    # Days until first occurrence of target weekday
    days_ahead = weekday - first.weekday()
    if days_ahead < 0:
        days_ahead += 7
    first_occurrence = first + timedelta(days=days_ahead)
    return first_occurrence + timedelta(weeks=n - 1)


def _last_weekday(year, month, weekday):
    """Find the last occurrence of a weekday in a month."""
    if month == 12:
        next_month = datetime(year + 1, 1, 1)
    else:
        next_month = datetime(year, month + 1, 1)
    last_day = next_month - timedelta(days=1)
    days_back = last_day.weekday() - weekday
    if days_back < 0:
        days_back += 7
    return last_day - timedelta(days=days_back)


def _easter(year):
    """Compute Easter Sunday using the Anonymous Gregorian algorithm."""
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return datetime(year, month, day)


def _moving_holidays(year):
    """Calculate all moving holidays for a given year.

    Returns:
        dict: holiday_name -> datetime
    """
    return {
        "Martin Luther King Jr. Day": _nth_weekday(year, 1, 0, 3),    # 3rd Monday Jan
        "Presidents Day": _nth_weekday(year, 2, 0, 3),                 # 3rd Monday Feb
        "Easter": _easter(year),                                        # Computed
        "Mother's Day": _nth_weekday(year, 5, 6, 2),                   # 2nd Sunday May
        "Memorial Day": _last_weekday(year, 5, 0),                     # Last Monday May
        "Father's Day": _nth_weekday(year, 6, 6, 3),                   # 3rd Sunday Jun
        "Labor Day": _nth_weekday(year, 9, 0, 1),                      # 1st Monday Sep
        "Columbus Day": _nth_weekday(year, 10, 0, 2),                  # 2nd Monday Oct
        "Thanksgiving": _nth_weekday(year, 11, 3, 4),                  # 4th Thursday Nov
    }


# Build reverse lookup: holiday name -> resolver
HOLIDAY_NAMES = {}

# Fixed holidays
for (m, d), name in HOLIDAYS.items():
    HOLIDAY_NAMES[name.lower()] = (m, d)
    short = name.lower().replace("'s", "").replace(" day", "").strip()
    HOLIDAY_NAMES[short] = (m, d)

# Extra aliases for fixed holidays
HOLIDAY_NAMES["april fools"] = (4, 1)
HOLIDAY_NAMES["new years"] = (1, 1)
HOLIDAY_NAMES["new year"] = (1, 1)
HOLIDAY_NAMES["xmas"] = (12, 25)
HOLIDAY_NAMES["christmas"] = (12, 25)
HOLIDAY_NAMES["valentines"] = (2, 14)
HOLIDAY_NAMES["halloween"] = (10, 31)
HOLIDAY_NAMES["veterans"] = (11, 11)
HOLIDAY_NAMES["independence"] = (7, 4)
HOLIDAY_NAMES["fourth of july"] = (7, 4)
HOLIDAY_NAMES["4th of july"] = (7, 4)
HOLIDAY_NAMES["4th july"] = (7, 4)

# Moving holiday aliases (name -> calculator key)
MOVING_HOLIDAY_ALIASES = {
    "easter": "Easter",
    "thanksgiving": "Thanksgiving",
    "memorial day": "Memorial Day",
    "memorial": "Memorial Day",
    "labor day": "Labor Day",
    "labor": "Labor Day",
    "mlk day": "Martin Luther King Jr. Day",
    "mlk": "Martin Luther King Jr. Day",
    "martin luther king": "Martin Luther King Jr. Day",
    "martin luther king day": "Martin Luther King Jr. Day",
    "presidents day": "Presidents Day",
    "presidents": "Presidents Day",
    "president's day": "Presidents Day",
    "mothers day": "Mother's Day",
    "mother's day": "Mother's Day",
    "fathers day": "Father's Day",
    "father's day": "Father's Day",
    "columbus day": "Columbus Day",
    "columbus": "Columbus Day",
    "mothers": "Mother's Day",
    "mother": "Mother's Day",
    "mothers'": "Mother's Day",
    "mothers' day": "Mother's Day",
    "mothers day": "Mother's Day",
    "mother day": "Mother's Day",
    "fathers": "Father's Day",
    "father": "Father's Day",
    "fathers'": "Father's Day",
    "fathers' day": "Father's Day",
    "fathers day": "Father's Day",
    "father day": "Father's Day",
}


def resolve_date(reference=None):
    """Resolve a date reference to a datetime object.

    Args:
        reference: None (today), relative word, holiday name, or date string

    Returns:
        tuple: (datetime, description) or (None, error_message)
    """
    now = datetime.now()

    if reference is None:
        return now, "today"

    ref = reference.strip().lower()

    # Strip leading prepositions
    for prep in ['on ', 'of ']:
        if ref.startswith(prep):
            ref = ref[len(prep):]

    # Relative days
    if ref in RELATIVE_DAYS:
        target = now + timedelta(days=RELATIVE_DAYS[ref])
        return target, ref

    # "in N days"
    if ref.startswith("in "):
        parts = ref[3:].split()
        if len(parts) >= 2 and parts[0].isdigit():
            days = int(parts[0])
            target = now + timedelta(days=days)
            return target, f"in {days} days"

    # "N days from now"
    if "days from now" in ref:
        parts = ref.split()
        if parts[0].isdigit():
            days = int(parts[0])
            target = now + timedelta(days=days)
            return target, f"in {days} days"

    # "next" prefix — force next occurrence
    force_next = False
    if ref.startswith("next "):
        ref = ref[5:]
        force_next = True

    # Weekday name ("wednesday")
    for i, day_name in enumerate(WEEKDAYS):
        if ref == day_name.lower():
            current_weekday = now.weekday()
            days_ahead = i - current_weekday
            if days_ahead <= 0:
                days_ahead += 7
            target = now + timedelta(days=days_ahead)
            return target, f"next {day_name}"

    # Moving holidays (Easter, Thanksgiving, etc.)
    if ref in MOVING_HOLIDAY_ALIASES:
        key = MOVING_HOLIDAY_ALIASES[ref]
        moving = _moving_holidays(now.year)
        target = moving[key]
        if force_next and target.date() <= now.date():
            target = _moving_holidays(now.year + 1)[key]
        return target, key

    # Fixed holidays
    if ref in HOLIDAY_NAMES:
        m, d = HOLIDAY_NAMES[ref]
        target = datetime(now.year, m, d)
        if force_next and target.date() <= now.date():
            target = datetime(now.year + 1, m, d)
        holiday_display = HOLIDAYS.get((m, d), ref.title())
        return target, holiday_display

    # Numeric date: M/D or M-D
    for sep in ['/', '-']:
        if sep in ref:
            parts = ref.split(sep)
            if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
                m, d = int(parts[0]), int(parts[1])
                year = int(parts[2]) if len(parts) == 3 and parts[2].isdigit() else now.year
                try:
                    target = datetime(year, m, d)
                    if force_next and target.date() <= now.date():
                        target = datetime(now.year + 1, m, d)
                    return target, f"{m}/{d}/{target.year}"
                except ValueError:
                    pass

    # "Nth of Month" pattern (e.g., "4th of July", "1st of December")
    import re
    ordinal_match = re.match(r'(\d+)(?:st|nd|rd|th)?\s+of\s+(\w+)', ref)
    if ordinal_match:
        day_num = int(ordinal_match.group(1))
        month_name = ordinal_match.group(2).lower()
        month_names = {
            'january': 1, 'february': 2, 'march': 3, 'april': 4,
            'may': 5, 'june': 6, 'july': 7, 'august': 8,
            'september': 9, 'october': 10, 'november': 11, 'december': 12
        }
        if month_name in month_names:
            m = month_names[month_name]
            try:
                target = datetime(now.year, m, day_num)
                if force_next and target.date() <= now.date():
                    target = datetime(now.year + 1, m, day_num)
                return target, f"{ordinal_match.group(2).title()} {day_num}"
            except ValueError:
                pass

    return None, f"Could not resolve: {reference}"


def format_day_response(dt, description):
    """Format a day response with correct tense."""
    day_name = WEEKDAYS[dt.weekday()]
    date_str = dt.strftime("%B %d, %Y")
    today = datetime.now().date()

    if description == "today":
        return f"Today is {day_name}, {date_str}."
    elif description == "yesterday":
        return f"Yesterday was {day_name}, {date_str}."
    elif description == "tomorrow":
        return f"Tomorrow will be {day_name}, {date_str}."
    elif description.startswith("in "):
        if dt.date() < today:
            return f"{description} it was {day_name}, {date_str}."
        return f"{description} it will be {day_name}, {date_str}."
    elif dt.date() < today:
        return f"{description} was {day_name}, {date_str}."
    elif dt.date() == today:
        return f"{description} is today, {day_name}, {date_str}."
    else:
        return f"{description} will be {day_name}, {date_str}."


def extract_date_reference(context):
    """Extract a date reference string from NLP or regex context.

    Reads parsed words and builds a reference string from the meaningful
    parts — PROPNs, NOUNs, NUMs, ADJs, ADVs — skipping structural words
    like 'what', 'day', 'is', 'it', 'be', 'will', 'the', 'when'.
    """
    if not context:
        return None

    if context.get('source') == 'regex':
        return None  # regex tell_day has no parameters

    words = context.get('words', [])
    skip_lemmas = {'what', 'be', 'it', 'will', 'when', 'the', 'a'}
    skip_pos = {'PUNCT', 'DET'}

    ref_parts = []
    for w in words:
        lemma = w.get('lemma', '').lower()
        pos = w.get('pos', '')
        dep = w.get('dep', '')
        text = w.get('text', '')

        # Skip "day" only when it's the question subject, not the time reference
        if lemma == 'day' and dep in ('nsubj', 'root', 'det'):
            continue
        if lemma in skip_lemmas:
            continue
        if pos in skip_pos:
            continue

        # Keep PROPNs, NOUNs, NUMs, ADJs, ADPs, ADVs
        if pos in ('PROPN', 'NOUN', 'NUM', 'ADJ', 'ADP', 'ADV'):
            ref_parts.append(text)

    if ref_parts:
        # Ensure "next" is at the front (Stanza parses it as ADJ modifier)
        if 'next' in ref_parts and ref_parts[0] != 'next':
            ref_parts.remove('next')
            ref_parts.insert(0, 'next')
        return ' '.join(ref_parts)
    return None


@intent('tell_day')
def tell_day(context=None):
    """Returns day for a date reference. No context = today."""
    ref = extract_date_reference(context)

    # Try word2number conversion for written numbers
    if ref:
        try:
            from word2number import w2n
            parts = ref.split()
            converted = []
            for part in parts:
                try:
                    converted.append(str(w2n.word_to_num(part)))
                except ValueError:
                    converted.append(part)
            ref = ' '.join(converted)
        except ImportError:
            pass

    dt, desc = resolve_date(ref)
    if dt is None:
        return desc  # error message
    return format_day_response(dt, desc)
