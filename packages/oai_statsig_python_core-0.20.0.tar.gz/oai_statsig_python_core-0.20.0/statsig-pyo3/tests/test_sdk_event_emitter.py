import json

from pytest_httpserver import HTTPServer
from statsig_python_core import Statsig, StatsigOptions, StatsigUser

from utils import get_test_data_resource


def test_subscribe_receives_gate_event():
    statsig = Statsig("secret-key")
    received_events = []

    try:
        statsig.subscribe("gate_evaluated", received_events.append)

        statsig.check_gate(StatsigUser("a-user"), "test_gate")

        assert len(received_events) == 1
        event = received_events[0]
        assert event["event_name"] == "gate_evaluated"
        assert event["data"]["gate_name"] == "test_gate"
        assert event["data"]["reason"] == "Uninitialized"
    finally:
        statsig.shutdown().wait()


def test_subscribe_receives_specs_updated_event(httpserver: HTTPServer):
    dcs_content = get_test_data_resource("eval_proj_dcs.json")
    json_data = json.loads(dcs_content)

    httpserver.expect_request(
        "/v2/download_config_specs/secret-key.json"
    ).respond_with_json(json_data)
    httpserver.expect_request("/v1/log_event").respond_with_json({"success": True})

    options = StatsigOptions(
        specs_url=httpserver.url_for("/v2/download_config_specs"),
        log_event_url=httpserver.url_for("/v1/log_event"),
    )
    statsig = Statsig("secret-key", options)
    received_events = []

    try:
        statsig.subscribe("specs_updated", received_events.append)

        statsig.initialize().wait()

        assert received_events
        event = received_events[0]
        assert event["event_name"] == "specs_updated"
        assert "values" in event["data"]
        assert isinstance(event["data"]["values"]["time"], int)
    finally:
        statsig.shutdown().wait()


def test_unsubscribe_by_id_stops_callback_delivery():
    statsig = Statsig("secret-key")
    received_events = []

    try:
        subscription_id = statsig.subscribe(
            "gate_evaluated", received_events.append
        )
        statsig.unsubscribe_by_id(subscription_id)

        statsig.check_gate(StatsigUser("a-user"), "test_gate")

        assert received_events == []
    finally:
        statsig.shutdown().wait()


def test_unsubscribe_by_event_stops_callback_delivery():
    statsig = Statsig("secret-key")
    received_events = []

    try:
        statsig.subscribe("gate_evaluated", received_events.append)
        statsig.unsubscribe("gate_evaluated")

        statsig.check_gate(StatsigUser("a-user"), "test_gate")

        assert received_events == []
    finally:
        statsig.shutdown().wait()


def test_unsubscribe_all_stops_callback_delivery():
    statsig = Statsig("secret-key")
    received_events = []

    try:
        statsig.subscribe("*", received_events.append)
        statsig.subscribe("gate_evaluated", received_events.append)
        statsig.unsubscribe_all()

        statsig.check_gate(StatsigUser("a-user"), "test_gate")

        assert received_events == []
    finally:
        statsig.shutdown().wait()
