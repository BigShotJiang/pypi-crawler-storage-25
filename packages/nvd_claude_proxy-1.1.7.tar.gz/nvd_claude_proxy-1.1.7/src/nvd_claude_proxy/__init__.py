"""nvd-claude-proxy: Anthropic Messages ↔ NVIDIA NIM proxy."""

__version__ = "1.1.7"
