from __future__ import annotations

import re
from typing import Any, Iterable, TYPE_CHECKING, Literal

from .events import RawOpenAIChunk, TranslatedEvent, StreamState, StreamProcessor
from .tool_accumulator import ToolAccumulator

if TYPE_CHECKING:
    from ..translators.tool_translator import ToolIdMap
    from ..translators.tool_controller import ToolInvocationController

BlockType = Literal["text", "thinking", "tool_use"]


class BaseProcessor(StreamProcessor):
    """Shared helpers for all processors."""

    def _emit(self, event: str, data: dict[str, Any]) -> TranslatedEvent:
        return TranslatedEvent(event, data)

    def _ensure_started(self, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.started:
            return
        state.started = True
        yield self._emit(
            "message_start",
            {
                "type": "message_start",
                "message": {
                    "id": state.message_id,
                    "type": "message",
                    "role": "assistant",
                    "content": [],
                    "model": state.model_name,
                    "stop_reason": None,
                    "stop_sequence": None,
                    "usage": {"input_tokens": state.estimated_input_tokens, "output_tokens": 0},
                },
            },
        )

    def _close_open_block(self, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.open_block_type is not None and state.open_block_index is not None:
            yield self._emit(
                "content_block_stop",
                {"type": "content_block_stop", "index": state.open_block_index},
            )
            state.open_block_type = None
            state.open_block_index = None


class MetadataProcessor(BaseProcessor):
    """Handles stream start and usage accumulation."""

    def process(self, chunk: RawOpenAIChunk, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.finished:
            return []

        # We must return an iterable, so we use a generator pattern with yield from.
        def _gen():
            yield from self._ensure_started(state)

            if not chunk.data.get("choices"):
                usage = chunk.data.get("usage")
                if usage:
                    state.usage_input = usage.get("prompt_tokens", state.usage_input)
                    state.usage_output = usage.get("completion_tokens", state.usage_output)
        
        return _gen()


class TextProcessor(BaseProcessor):
    """Handles content and reasoning_content from OpenAI."""

    def process(self, chunk: RawOpenAIChunk, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.finished:
            return []

        choices = chunk.data.get("choices") or []
        if not choices:
            return []

        def _gen():
            delta = choices[0].get("delta") or {}
            reasoning = delta.get("reasoning_content")
            text = delta.get("content")

            if reasoning:
                yield from self._handle_reasoning(reasoning, state)
            if text:
                yield from self._handle_text(text, state)
        
        return _gen()

    def _handle_reasoning(self, reasoning: str, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.thinking_budget_hit:
            return

        if state.open_block_type != "thinking":
            yield from self._close_open_block(state)
            yield from self._open_block("thinking", state)

        yield self._emit(
            "content_block_delta",
            {
                "type": "content_block_delta",
                "index": state.open_block_index,
                "delta": {"type": "thinking_delta", "thinking": reasoning},
            },
        )

    def _handle_text(self, text: str, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.open_block_type != "text":
            yield from self._close_open_block(state)
            yield from self._open_block("text", state)

        yield self._emit(
            "content_block_delta",
            {
                "type": "content_block_delta",
                "index": state.open_block_index,
                "delta": {"type": "text_delta", "text": text},
            },
        )

    def _open_block(self, block_type: BlockType, state: StreamState) -> Iterable[TranslatedEvent]:
        idx = state.next_index
        state.next_index += 1
        state.open_block_type = block_type
        state.open_block_index = idx

        content_block: dict[str, Any] = {"type": block_type}
        if block_type == "text":
            content_block["text"] = ""
        elif block_type == "thinking":
            content_block["thinking"] = ""
            content_block["signature"] = ""

        yield self._emit(
            "content_block_start",
            {"type": "content_block_start", "index": idx, "content_block": content_block},
        )


class ToolProcessor(BaseProcessor):
    """Buffers, validates, and emits tool_use blocks."""

    def __init__(self, tool_id_map: ToolIdMap, tool_controller: ToolInvocationController) -> None:
        self.tool_id_map = tool_id_map
        self.tool_controller = tool_controller
        self._accumulators: dict[int, ToolAccumulator] = {}

    def process(self, chunk: RawOpenAIChunk, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.finished:
            return []

        choices = chunk.data.get("choices") or []
        if not choices:
            return []

        def _gen():
            delta = choices[0].get("delta") or {}
            tool_calls = delta.get("tool_calls") or []

            for tc in tool_calls:
                idx = tc.get("index", 0)
                acc = self._accumulators.setdefault(idx, ToolAccumulator())

                if "id" in tc:
                    acc.openai_id = tc["id"]
                fn = tc.get("function") or {}
                if "name" in fn:
                    acc.name = fn["name"]
                if "arguments" in fn:
                    acc.arguments += fn["arguments"]

            finish_reason = choices[0].get("finish_reason")
            if finish_reason in ("tool_calls", "function_call") or (
                finish_reason == "stop" and self._accumulators
            ):
                for idx in sorted(self._accumulators.keys()):
                    acc = self._accumulators[idx]
                    if not acc.closed:
                        yield from self._flush_tool(acc, state)
        
        return _gen()

    def _flush_tool(self, acc: ToolAccumulator, state: StreamState) -> Iterable[TranslatedEvent]:
        if not acc.openai_id or not acc.name:
            return

        original_name = self.tool_id_map.original_tool_name(acc.name)
        yield from self._close_open_block(state)
        
        acc.anthropic_id = self.tool_id_map.openai_to_anthropic(acc.openai_id)
        acc.anth_index = state.next_index
        state.next_index += 1
        state.open_block_type = "tool_use"
        state.open_block_index = acc.anth_index

        yield self._emit(
            "content_block_start",
            {
                "type": "content_block_start",
                "index": acc.anth_index,
                "content_block": {
                    "type": "tool_use",
                    "id": acc.anthropic_id,
                    "name": original_name,
                    "input": {},
                },
            },
        )

        yield self._emit(
            "content_block_delta",
            {
                "type": "content_block_delta",
                "index": acc.anth_index,
                "delta": {"type": "input_json_delta", "partial_json": acc.arguments},
            },
        )
        
        yield from self._close_open_block(state)
        acc.closed = True


class SafetyProcessor(BaseProcessor):
    """Detects and prevents infinite loops."""

    def __init__(self, max_repetitions: int = 3, max_hallucinations: int = 3) -> None:
        self.max_repetitions = max_repetitions
        self.max_hallucinations = max_hallucinations
        self._last_tool_names: list[str] = []
        self._repetition_count = 0
        self._hallucination_count = 0
        self._tag_hallucination_re = re.compile(r"(command-name>|command-arguments>)", re.IGNORECASE)

    def process(self, chunk: RawOpenAIChunk, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.finished:
            return []

        choices = chunk.data.get("choices") or []
        if not choices:
            return []

        delta = choices[0].get("delta") or {}
        text = delta.get("content")
        tool_calls = delta.get("tool_calls") or []

        if text and self._tag_hallucination_re.search(text):
            self._hallucination_count += 1
            if self._hallucination_count >= self.max_hallucinations:
                state.finished = True
                state.stop_reason = "end_turn"

        for tc in tool_calls:
            fn = tc.get("function") or {}
            name = fn.get("name")
            if name and not fn.get("arguments"):
                self._last_tool_names.append(name)
                if len(self._last_tool_names) > 10:
                    self._last_tool_names.pop(0)

                if len(self._last_tool_names) >= 4:
                    unique = set(self._last_tool_names[-6:])
                    recent_count = self._last_tool_names[-6:].count(name)
                    if len(unique) <= 2 and recent_count >= 4:
                        self._repetition_count += 1
                        if self._repetition_count >= self.max_repetitions:
                            state.finished = True
                            state.stop_reason = "end_turn"
        
        return []


class FinalizerProcessor(BaseProcessor):
    """Handles finish reason and stream closure. Should run LAST."""

    def process(self, chunk: RawOpenAIChunk, state: StreamState) -> Iterable[TranslatedEvent]:
        if state.finished:
            return []

        choices = chunk.data.get("choices") or []
        if not choices:
            return []

        def _gen():
            choice = choices[0]
            finish = choice.get("finish_reason")
            if finish:
                yield from self._close_open_block(state)
                state.stop_reason = self._map_finish_reason(finish)
                state.finished = True
                yield from self.finalize(state)
        
        return _gen()

    def _map_finish_reason(self, finish: str) -> str:
        mapping = {
            "stop": "end_turn",
            "length": "max_tokens",
            "tool_calls": "tool_use",
            "content_filter": "end_turn",
        }
        return mapping.get(finish, "end_turn")

    def finalize(self, state: StreamState) -> Iterable[TranslatedEvent]:
        if not state.started:
            yield from self._ensure_started(state)
        
        yield from self._close_open_block(state)
        
        yield self._emit(
            "message_delta",
            {
                "type": "message_delta",
                "delta": {"stop_reason": state.stop_reason, "stop_sequence": None},
                "usage": {
                    "input_tokens": state.usage_input or state.estimated_input_tokens,
                    "output_tokens": state.usage_output,
                },
            },
        )
        yield self._emit("message_stop", {"type": "message_stop"})
        state.finished = True
