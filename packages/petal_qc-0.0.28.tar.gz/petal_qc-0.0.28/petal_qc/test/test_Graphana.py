#!/usr/bin/env python3
"""Test the connection with graphana to get the value at the peak."""
import sys
from pathlib import Path
import datetime
import numpy as np

cwd = Path(__file__).parent.parent.parent
sys.path.insert(0, cwd.as_posix())

from petal_qc.utils.readGraphana import ReadGraphana
from petal_qc.thermal.IRDataGetter import IRDataGetter
from petal_qc.thermal.IRPetalParam import IRPetalParam
from petal_qc.thermal import IRBFile



options = IRPetalParam()
options.institute = "IFIC"
options.files = [Path("~/SACO-CSIC/ITk-Strips/Local.Supports/thermal/IFIC-thermal/IRB_files/PPC.164.irb").expanduser().resolve()]
getter = IRDataGetter.factory(options.institute, options)
DB = ReadGraphana(host="itkendcap4.ific.uv.es")
#irbf = IRBFile.open_file(options.files)

#frames = getter.get_analysis_frame(irbf)
#print(frames[0].timestamp)
#the_time = frames[0].timestamp

the_time="2026-03-10 19:58:36.373000"

try:
    X, val = DB.get_temperature(the_time, 5)
    for x, y in zip(X, val):
        print("{} - {:.1f}".format(x, y))
        
    print("{:.1f}".format(np.min(val)))
except ValueError as e:
    print(e)
