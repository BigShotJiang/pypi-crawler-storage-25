#!/usr/bin/env python3
"""Class to access graphana data."""

import datetime
from dateutil.parser import parse

try:
    import influxdb_client
    has_influx = True
except ImportError:
    has_influx = False

__token__ = "njO_F69IVuk6qIkmnstIJ7L-sfr_-rVDAUJLRGFLcKn3l_1yYOUMXigrAMUBOobD8It49oBhUxQEwnhlfydpMw=="

class ReadGraphana(object):
    """Connect to the GraphanaDB"""

    def __init__(self, host="itkendcap4.ific.uv.es", port=8086):
        """Connect to Graphan server

        Args:
            host (str, optional): The IP of the server.
            port (int, optional): The port to the server.
        """
        self.url="http://{}:{}".format(host, port)
        self.org = "IFIC"
        
        if has_influx:
            self.client = influxdb_client.InfluxDBClient(
                url=self.url,
                org=self.org,
                token=__token__,
                database="Sentuinos",
                debug=False,
            )
            self.query_api = self.client.query_api()
        else:
            self.client = None
            self.query_api = None

    def get_temperature(self, the_time, window=10):
        """REturns the temperature

        Args:
            teh_time: the time to query the DB.
            window: the time window, in minutes, around the given time.
            
        Returns:
            time, values: where time and values are arrays.
        """
        time = []
        values = []

        if self.client is not None:
            if not isinstance(the_time, datetime.datetime):
                the_time = parse(the_time)

            wnd = int(window/2.0+0.5)
            td = datetime.timedelta(minutes=wnd)
            t1 = the_time - td
            t2 = the_time + td

            t1q = t1.astimezone(datetime.timezone.utc).isoformat(timespec="seconds").replace('+00:00', 'Z')
            t2q = t2.astimezone(datetime.timezone.utc).isoformat(timespec="seconds").replace('+00:00', 'Z')

            value="Temp"
            setup="MARTA"
            boardID="MARTA_APP"
            location="MARTA_tt06"
            bucket="Sentuinos"

            query = f'from(bucket:"{bucket}")\
                |> range(start: {t1q}, stop: {t2q}) \
                |> filter(fn: (r) => r.Setup == "{setup}") \
                |> filter(fn: (r) => r.boardID == "{boardID}") \
                |> filter(fn:(r) => r.location == "{location}")\
                |> filter(fn:(r) => r._measurement == "{value}")'

            try:
                result = self.query_api.query(query=query)
                for table in result:
                    for r in table.records:
                        time.append(r.get_time())
                        values.append(r.get_value())

            except Exception as e:
                print("Error retrieving tables.\n{}\n\n".format(e))

        return time, values
