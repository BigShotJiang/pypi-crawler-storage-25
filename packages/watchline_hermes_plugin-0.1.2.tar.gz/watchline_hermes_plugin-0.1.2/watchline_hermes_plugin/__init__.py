"""Watchline Hermes plugin package."""
