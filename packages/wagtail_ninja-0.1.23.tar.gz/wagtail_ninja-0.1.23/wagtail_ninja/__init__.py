class WagtailNinjaException(Exception):
    pass
