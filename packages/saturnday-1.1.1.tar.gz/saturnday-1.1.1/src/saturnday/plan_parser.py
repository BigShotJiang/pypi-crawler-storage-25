"""Load, validate, and dependency-sort project plans.

Accepts the saturnday-v3 full plan format — including ``definition_of_done``,
``stop_conditions``, ``max_project_tickets``, ``phases``, and ``mode`` — and
produces a typed ``ProjectPlan`` with tickets in topological order.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from saturnday._exceptions import PlanValidationError
from saturnday._types import PhaseDef, ProjectPlan, TicketScope, TicketSpec

KNOWN_DEFINITION_MARKERS = frozenset({"tickets_applied", "all_tickets_passed"})

logger = logging.getLogger(__name__)


def _parse_string_tuple(val: Any) -> tuple[str, ...]:
    """Safely parse a JSON value into a tuple of strings.

    Args:
        val: A raw JSON value that should be a list of strings.

    Returns:
        A tuple containing only the string elements from ``val``, or an empty
        tuple when ``val`` is not a list or contains no strings.
    """
    if isinstance(val, list):
        return tuple(str(s) for s in val if isinstance(s, str))
    return ()


def load_plan(path: str | Path) -> ProjectPlan:
    """Load a project plan from a JSON file.

    Args:
        path: Filesystem path to the plan JSON.

    Returns:
        A validated ``ProjectPlan`` with tickets in dependency order.

    Raises:
        PlanValidationError: If the plan is invalid.
        FileNotFoundError: If the plan file does not exist.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Plan file not found: {path}")

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PlanValidationError([f"Invalid JSON: {exc}"]) from exc

    if not isinstance(raw, dict):
        raise PlanValidationError(["Plan must be a JSON object"])

    errors = validate_plan(raw)
    if errors:
        raise PlanValidationError(errors)

    tickets = _parse_tickets(raw.get("tickets", []))
    sorted_tickets = resolve_ticket_order(tickets)

    # Parse v3 plan-level fields
    dod = raw.get("definition_of_done")
    if isinstance(dod, list):
        dod = tuple(str(m) for m in dod if isinstance(m, str))
    else:
        dod = ("all_tickets_passed",)

    stop_conds = raw.get("stop_conditions")
    if isinstance(stop_conds, list):
        stop_conds = tuple(str(s) for s in stop_conds if isinstance(s, str))
    else:
        stop_conds = ()

    max_pt = raw.get("max_project_tickets")
    if not isinstance(max_pt, int) or max_pt < 1:
        max_pt = None

    phases = _parse_phases(raw.get("phases", []))
    mode = raw.get("mode", "generation")
    if mode not in ("generation", "remediation"):
        mode = "generation"

    return ProjectPlan(
        version=raw.get("version", 1),
        project_id=raw.get("project_id", "unknown"),
        notes=raw.get("notes", ""),
        tickets=tuple(sorted_tickets),
        definition_of_done=dod,
        stop_conditions=stop_conds,
        max_project_tickets=max_pt,
        phases=phases,
        mode=mode,
        default_timeout_seconds=raw.get("default_timeout_seconds", 300),
        default_retry_limit=raw.get("default_retry_limit", 2),
        # Plan-governance fields — backward compatible: old plans without these
        # fields load with empty defaults, identical to pre-PG behaviour.
        governing_goal=raw.get("governing_goal", raw.get("notes", "")),
        required_outcomes=_parse_string_tuple(raw.get("required_outcomes")),
        scoped_categories=_parse_string_tuple(raw.get("scoped_categories")),
        exclusions=_parse_string_tuple(raw.get("exclusions")),
        constraints=_parse_string_tuple(raw.get("constraints")),
        proof_expectations=_parse_string_tuple(raw.get("proof_expectations")),
    )


def validate_plan(raw: dict[str, Any]) -> list[str]:
    """Check required fields, types, budget sanity, and ticket ID uniqueness.

    Returns:
        A list of validation error strings (empty if valid).
    """
    errors: list[str] = []

    if "tickets" not in raw:
        errors.append("Missing required field: 'tickets'")
        return errors

    tickets = raw["tickets"]
    if not isinstance(tickets, list):
        errors.append("'tickets' must be an array")
        return errors

    if not tickets:
        errors.append("Plan has no tickets")
        return errors

    seen_ids: set[str] = set()
    for i, t in enumerate(tickets):
        if not isinstance(t, dict):
            errors.append(f"Ticket at index {i} is not an object")
            continue

        tid = t.get("ticket_id", "")
        if not tid:
            errors.append(f"Ticket at index {i} missing 'ticket_id'")
            continue

        if tid in seen_ids:
            errors.append(f"Duplicate ticket_id: {tid!r}")
        seen_ids.add(tid)

        if not t.get("goal"):
            errors.append(f"Ticket {tid!r} missing 'goal'")

        # Budget sanity
        scope = t.get("scope", {})
        if isinstance(scope, dict):
            budgets = scope.get("budgets", {})
            if isinstance(budgets, dict):
                for key in ("max_files_changed", "max_total_diff_lines", "max_per_file_diff_lines"):
                    val = budgets.get(key)
                    if val is not None and (not isinstance(val, int) or val < 1):
                        errors.append(f"Ticket {tid!r}: budget '{key}' must be a positive integer, got {val!r}")

        # Dependency references
        deps = t.get("dependencies", [])
        if isinstance(deps, list):
            for dep in deps:
                if dep not in seen_ids and dep not in {tt.get("ticket_id") for tt in tickets}:
                    errors.append(f"Ticket {tid!r} depends on unknown ticket {dep!r}")

    # Validate definition_of_done markers
    dod = raw.get("definition_of_done")
    if isinstance(dod, list):
        for marker in dod:
            if isinstance(marker, str) and marker not in KNOWN_DEFINITION_MARKERS:
                errors.append(
                    f"Unknown definition_of_done marker: {marker!r}. "
                    f"Known markers: {sorted(KNOWN_DEFINITION_MARKERS)}"
                )

    # Validate max_project_tickets
    max_pt = raw.get("max_project_tickets")
    if max_pt is not None:
        if not isinstance(max_pt, int) or max_pt < 1:
            errors.append(
                f"'max_project_tickets' must be a positive integer, got {max_pt!r}"
            )

    # Validate phases reference real ticket IDs
    phases_raw = raw.get("phases")
    if isinstance(phases_raw, list):
        all_ticket_ids = seen_ids
        for pi, phase in enumerate(phases_raw):
            if not isinstance(phase, dict):
                errors.append(f"Phase at index {pi} is not an object")
                continue
            phase_tids = phase.get("ticket_ids", [])
            if isinstance(phase_tids, list):
                for ptid in phase_tids:
                    if isinstance(ptid, str) and ptid not in all_ticket_ids:
                        errors.append(
                            f"Phase {phase.get('phase_id', pi)!r} references "
                            f"unknown ticket {ptid!r}"
                        )

    return errors


def resolve_ticket_order(tickets: list[TicketSpec]) -> list[TicketSpec]:
    """Topological sort tickets by their dependency graph.

    Args:
        tickets: Unsorted list of ticket specs.

    Returns:
        Tickets in dependency-first order.

    Raises:
        PlanValidationError: If a dependency cycle is detected.
    """
    by_id: dict[str, TicketSpec] = {t.ticket_id: t for t in tickets}
    visited: set[str] = set()
    in_stack: set[str] = set()
    ordered: list[TicketSpec] = []

    def visit(tid: str) -> None:
        if tid in visited:
            return
        if tid in in_stack:
            raise PlanValidationError([f"Dependency cycle involving ticket {tid!r}"])
        in_stack.add(tid)
        ticket = by_id.get(tid)
        if ticket is None:
            return
        for dep in ticket.dependencies:
            visit(dep)
        in_stack.discard(tid)
        visited.add(tid)
        ordered.append(ticket)

    for tid in by_id:
        visit(tid)

    return ordered


def _parse_phases(raw_phases: list[Any]) -> tuple[PhaseDef, ...]:
    """Parse raw phase dicts into typed PhaseDef objects."""
    if not isinstance(raw_phases, list):
        return ()
    result: list[PhaseDef] = []
    for i, p in enumerate(raw_phases):
        if not isinstance(p, dict):
            continue
        phase_id = str(p.get("phase_id", f"phase-{i + 1}"))
        name = str(p.get("name", phase_id))
        ticket_ids = tuple(
            str(tid) for tid in p.get("ticket_ids", []) if isinstance(tid, str)
        )
        result.append(PhaseDef(phase_id=phase_id, name=name, ticket_ids=ticket_ids))
    return tuple(result)


def _parse_tickets(raw_tickets: list[dict[str, Any]]) -> list[TicketSpec]:
    """Parse raw ticket dicts into typed TicketSpec objects."""
    result: list[TicketSpec] = []
    for t in raw_tickets:
        if not isinstance(t, dict):
            continue

        scope_raw = t.get("scope", {})
        budgets = scope_raw.get("budgets", {}) if isinstance(scope_raw, dict) else {}

        scope = TicketScope(
            allowed_globs=tuple(scope_raw.get("allowed_globs", ["**"])) if isinstance(scope_raw, dict) else TicketScope().allowed_globs,
            forbidden_globs=tuple(scope_raw.get("forbidden_globs", [])) if isinstance(scope_raw, dict) else TicketScope().forbidden_globs,
            max_files_changed=budgets.get("max_files_changed", 20) if isinstance(budgets, dict) else 20,
            max_total_diff_lines=budgets.get("max_total_diff_lines", 2000) if isinstance(budgets, dict) else 2000,
            max_per_file_diff_lines=budgets.get("max_per_file_diff_lines", 500) if isinstance(budgets, dict) else 500,
        )

        deps = t.get("dependencies", [])
        if not isinstance(deps, list):
            deps = []

        criteria = t.get("acceptance_criteria", [])
        if isinstance(criteria, str):
            criteria = [criteria]
        elif not isinstance(criteria, list):
            criteria = []

        out_of_scope_raw = t.get("out_of_scope", [])
        if not isinstance(out_of_scope_raw, list):
            out_of_scope_raw = []

        evidence_required_raw = t.get("evidence_required", [])
        if not isinstance(evidence_required_raw, list):
            evidence_required_raw = []

        failure_mode = t.get("failure_mode", "")
        if not isinstance(failure_mode, str):
            failure_mode = ""

        if_blocked = t.get("if_blocked", "")
        if not isinstance(if_blocked, str):
            if_blocked = ""

        tid = t.get("ticket_id", "")

        # Rubric completeness warnings — never reject, only advise.
        if not criteria:
            logger.warning("Ticket %r has no acceptance_criteria — rubric incomplete", tid)
        if not out_of_scope_raw:
            logger.warning("Ticket %r has no out_of_scope — rubric incomplete", tid)
        if not evidence_required_raw:
            logger.debug("Ticket %r has no evidence_required — rubric incomplete", tid)

        result.append(TicketSpec(
            ticket_id=tid,
            goal=t.get("goal", ""),
            scope=scope,
            verify_cmd=t.get("verify_cmd", ""),
            acceptance_criteria=tuple(criteria),
            dependencies=tuple(deps),
            out_of_scope=tuple(str(s) for s in out_of_scope_raw if isinstance(s, str)),
            evidence_required=tuple(str(s) for s in evidence_required_raw if isinstance(s, str)),
            failure_mode=failure_mode,
            if_blocked=if_blocked,
        ))

    return result
