"""Tests for repair denied-paths filtering."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestDeniedPathFiltering:
    """Findings in denied paths are excluded from repair."""

    def test_finding_in_denied_path_excluded(self, tmp_path: Path) -> None:
        """Finding in tests/fixtures/** should be excluded after filtering."""
        from saturnday.interactive import _scan_for_repair

        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / ".saturnday-policy.yaml").write_text(
            "schema_version: '1.0.0'\nscope:\n  denied_paths:\n    - 'tests/fixtures/**'\n",
            encoding="utf-8",
        )

        # Initialise a minimal git repo so _scan_for_repair takes the git branch
        subprocess.run(["git", "init", "-q", str(repo)], check=True, capture_output=True)
        subprocess.run(
            ["git", "-C", str(repo), "config", "user.email", "t@t.com"],
            check=True, capture_output=True,
        )
        subprocess.run(
            ["git", "-C", str(repo), "config", "user.name", "T"],
            check=True, capture_output=True,
        )
        (repo / "dummy.py").write_text("x = 1\n", encoding="utf-8")
        subprocess.run(["git", "-C", str(repo), "add", "."], check=True, capture_output=True)
        subprocess.run(
            ["git", "-C", str(repo), "commit", "-q", "-m", "init"],
            check=True, capture_output=True,
        )

        # Build a mock EvidencePack whose check_results contain two findings:
        # one inside tests/fixtures/ and one in a real source file.
        mock_cr = MagicMock()
        mock_cr.name = "hardcoded_jwt"
        mock_cr.severity = "error"
        mock_cr.findings = [
            {"file": "tests/fixtures/vulnerable/jwt.py", "kind": "hardcoded_secret", "message": "fixture secret"},
            {"file": "src/myapp/auth.py", "kind": "hardcoded_secret", "message": "real secret"},
        ]
        mock_pack = MagicMock()
        mock_pack.check_results = [mock_cr]

        with patch("saturnday.governance.run_full_repo_review") as mock_review:
            mock_review.return_value = (mock_pack, None)
            findings, scan_mode = _scan_for_repair(repo)

        assert scan_mode == "repo"
        file_paths = [f.file for f in findings]
        assert "tests/fixtures/vulnerable/jwt.py" not in file_paths, (
            "Fixture finding should have been filtered by denied_paths"
        )
        assert "src/myapp/auth.py" in file_paths, (
            "Non-fixture finding must survive denied-path filtering"
        )

    def test_finding_in_allowed_path_preserved(self) -> None:
        """Finding outside denied paths is not matched."""
        from saturnday.scope_rules import matches_path_patterns

        assert not matches_path_patterns("src/myapp/auth.py", ["tests/fixtures/**"])

    def test_no_denied_paths_returns_all(self) -> None:
        """Empty denied-paths list means no filtering."""
        from saturnday.scope_rules import matches_path_patterns

        assert not matches_path_patterns("tests/fixtures/x.py", [])

    def test_policy_without_denied_paths_key(self) -> None:
        """Policy YAML with no scope.denied_paths key yields empty list."""
        import yaml

        raw = yaml.safe_load("schema_version: '1.0.0'\n")
        denied = (raw or {}).get("scope", {}).get("denied_paths", [])
        assert denied == []

    def test_multiple_denied_patterns(self) -> None:
        """Multiple denied patterns all filter correctly."""
        from saturnday.scope_rules import matches_path_patterns

        patterns = ["tests/fixtures/**", "vendor/**"]
        assert matches_path_patterns("tests/fixtures/vuln.py", patterns)
        assert matches_path_patterns("vendor/lib/x.py", patterns)
        assert not matches_path_patterns("src/app.py", patterns)

    def test_no_policy_file_no_filter(self, tmp_path: Path) -> None:
        """Without a policy file, all findings pass through unchanged."""
        from saturnday.interactive import _scan_for_repair

        repo = tmp_path / "repo"
        repo.mkdir()

        subprocess.run(["git", "init", "-q", str(repo)], check=True, capture_output=True)
        subprocess.run(
            ["git", "-C", str(repo), "config", "user.email", "t@t.com"],
            check=True, capture_output=True,
        )
        subprocess.run(
            ["git", "-C", str(repo), "config", "user.name", "T"],
            check=True, capture_output=True,
        )
        (repo / "dummy.py").write_text("x = 1\n", encoding="utf-8")
        subprocess.run(["git", "-C", str(repo), "add", "."], check=True, capture_output=True)
        subprocess.run(
            ["git", "-C", str(repo), "commit", "-q", "-m", "init"],
            check=True, capture_output=True,
        )

        mock_cr = MagicMock()
        mock_cr.name = "hardcoded_jwt"
        mock_cr.severity = "error"
        mock_cr.findings = [
            {"file": "tests/fixtures/vuln.py", "kind": "hardcoded_secret", "message": "x"},
        ]
        mock_pack = MagicMock()
        mock_pack.check_results = [mock_cr]

        with patch("saturnday.governance.run_full_repo_review") as mock_review:
            mock_review.return_value = (mock_pack, None)
            findings, _ = _scan_for_repair(repo)

        # No policy — fixture finding must survive
        file_paths = [f.file for f in findings]
        assert "tests/fixtures/vuln.py" in file_paths

    def test_self_scan_policy_excludes_fixtures(self) -> None:
        """Real .saturnday-policy.yaml in saturnday-public excludes fixture paths."""
        policy_path = Path("/home/onur/saturnday-public/.saturnday-policy.yaml")
        if not policy_path.is_file():
            pytest.skip("Policy file not available")

        import yaml
        from saturnday.scope_rules import matches_path_patterns

        raw = yaml.safe_load(policy_path.read_text(encoding="utf-8"))
        denied = (raw or {}).get("scope", {}).get("denied_paths", [])

        # Fixture paths must match
        assert matches_path_patterns("tests/fixtures/vulnerable/jwt.py", denied)
        assert matches_path_patterns(
            "tests/fixtures/sample-python-service/src/myservice/app.py", denied
        )
        # Production paths must not match
        assert not matches_path_patterns("src/saturnday/cli.py", denied)
        assert not matches_path_patterns("src/saturnday/governance.py", denied)
