"""
Parameter validation for Wavesim simulations

Ported from MATLAB validateParameters.m. Validates all simulation parameters
before uploading files to the server, providing detailed error/warning messages.
"""

import math
import logging
from typing import List, Dict, Any, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class ParameterValidationError(Exception):
    """Raised when parameter validation fails with one or more errors."""

    def __init__(self, errors: List[str], warnings: List[str] = None):
        self.errors = errors
        self.warnings = warnings or []
        msg = f"Parameter validation failed with {len(errors)} error(s):\n  - " + "\n  - ".join(errors)
        super().__init__(msg)


DEFAULT_GPU_MEMORY_OK_GB = 16
DEFAULT_GPU_MEMORY_MAX_GB = 65


def validate_parameters(
    refractive_index: np.ndarray,
    sources: List[Dict[str, Any]],
    wavelength: float,
    pixel_size: float,
    threshold: float = 1e-2,
    max_iterations: int = 1000,
    boundary_width: int = 0,
    is_vectorial: bool = True,
    strict_validation: bool = False,
    gpu_memory_max_gb: Optional[float] = None,
) -> List[str]:
    """
    Validate simulation parameters before upload.

    Args:
        refractive_index: [nx, ny, nz] array (refractive index or permittivity)
        sources: List of source dicts with 'field', 'position', 'polarization' keys
        wavelength: Wavelength in micrometers
        pixel_size: Pixel size in micrometers
        threshold: Convergence threshold
        max_iterations: Maximum iterations
        boundary_width: Boundary width in pixels
        is_vectorial: True for Maxwell, False for Helmholtz
        strict_validation: If True, "soft" issues (GPU memory cap exceeded,
            source field larger than domain) raise ParameterValidationError.
            If False (default), they are emitted as warnings and the
            simulation proceeds. Hard issues (NaN/Inf, empty arrays, missing
            wavelength/pixel_size) always raise regardless of this flag.
        gpu_memory_max_gb: Hard cap (GB) above which estimated GPU memory
            triggers a soft error. Default 65. Pass math.inf (or any large
            value) to disable the cap entirely.

    Returns:
        List of warning strings (empty if no warnings)

    Raises:
        ParameterValidationError: If any hard error is found, or if any soft
            error is found while strict_validation=True.
    """
    errors: List[str] = []
    soft_errors: List[str] = []
    warnings: List[str] = []

    gpu_memory_max_gb = (
        DEFAULT_GPU_MEMORY_MAX_GB if gpu_memory_max_gb is None else float(gpu_memory_max_gb)
    )

    logger.info("Validating simulation parameters...")

    # 1. Validate refractive index / permittivity array
    if refractive_index is None or refractive_index.size == 0:
        errors.append("Refractive index array is empty")
    else:
        shape = refractive_index.shape
        # Pad to 3D
        while len(shape) < 3:
            shape = shape + (1,)
        nx, ny, nz = shape[0], shape[1], shape[2]

        # Allow size-1 in any dimension (collapsed 2D/1D), but non-singleton dims must be >= 2
        _small = [d for d in (nx, ny, nz) if d != 1 and d < 2]
        if _small or all(d == 1 for d in (nx, ny, nz)):
            errors.append(f"Domain too small: [{nx}, {ny}, {nz}]. Non-singleton dimensions must be >= 2")

        if np.any(np.isnan(refractive_index)):
            errors.append("Refractive index contains NaN values")
        if np.any(np.isinf(refractive_index)):
            errors.append("Refractive index contains Inf values")

        min_real = float(np.min(np.real(refractive_index)))
        max_real = float(np.max(np.real(refractive_index)))
        if min_real <= 0:
            warnings.append(f"Refractive index has non-positive real values (min={min_real:.4f}). This may cause issues.")
        if max_real > 10:
            warnings.append(f"Refractive index has very high values (max={max_real:.4f}). Verify this is correct.")

        logger.info(f"  Domain: [{nx} x {ny} x {nz}]")

    # 2. Validate wavelength
    if wavelength is None:
        errors.append("Wavelength is required")
    elif wavelength <= 0:
        errors.append(f"Wavelength must be positive (got {wavelength:.4f})")
    elif wavelength < 0.1 or wavelength > 100:
        warnings.append(f"Unusual wavelength: {wavelength:.4f} um. Typical range is 0.1-100 um.")

    # 3. Validate pixel size
    if pixel_size is None:
        errors.append("Pixel size is required")
    elif pixel_size <= 0:
        errors.append(f"Pixel size must be positive (got {pixel_size:.4f})")
    elif refractive_index is not None and refractive_index.size > 0 and wavelength and wavelength > 0:
        n_max = float(np.max(np.real(refractive_index)))
        if n_max > 0:
            nyquist_limit = wavelength / (2 * n_max)
            if pixel_size > nyquist_limit:
                warnings.append(
                    f"Pixel size ({pixel_size:.4f} um) exceeds Nyquist limit "
                    f"({nyquist_limit:.4f} um for n_max={n_max:.2f}). Results may be inaccurate."
                )
            pixels_per_wavelength = wavelength / (n_max * pixel_size)
            if pixels_per_wavelength < 10:
                warnings.append(
                    f"Only {pixels_per_wavelength:.1f} pixels per wavelength in "
                    f"highest-index medium. Recommend >= 10."
                )

    # 4. Validate threshold
    if threshold is None:
        errors.append("Threshold must be numeric")
    elif threshold <= 0:
        errors.append(f"Threshold must be positive (got {threshold:.2e})")
    elif threshold > 1:
        warnings.append(f"Threshold ({threshold:.2e}) is very high. Typical range is 1e-9 to 1e-2.")
    elif threshold < 1e-12:
        warnings.append(f"Threshold ({threshold:.2e}) is very low. May not converge within max iterations.")

    # 5. Validate max iterations
    if max_iterations is None:
        errors.append("Max iterations must be numeric")
    elif max_iterations < 1:
        errors.append(f"Max iterations must be >= 1 (got {max_iterations})")
    elif max_iterations < 100:
        warnings.append(f"Max iterations ({max_iterations}) is low. May not converge.")
    elif max_iterations > 100000:
        warnings.append(f"Max iterations ({max_iterations}) is very high. Simulation may take a long time.")

    # 6. Validate boundary width
    if boundary_width is not None:
        if boundary_width < 0:
            errors.append(f"Boundary width must be >= 0 (got {boundary_width})")
        elif boundary_width > 0 and refractive_index is not None and refractive_index.size > 0:
            shape = refractive_index.shape
            while len(shape) < 3:
                shape = shape + (1,)
            dims = shape[:3]
            dim_names = ("x", "y", "z")
            exceeded = []
            for i in range(3):
                max_allowed = dims[i] // 2
                if boundary_width > max_allowed:
                    exceeded.append(f"{dim_names[i]} ({dims[i]}->{max_allowed})")
            if exceeded:
                warnings.append(
                    f"Boundary width ({boundary_width} pixels) is large relative to domain size "
                    f"in dimension(s): {', '.join(exceeded)}. Results may differ from local execution."
                )

    # 7. Validate GPU memory requirements
    if refractive_index is not None and refractive_index.size > 0:
        shape = refractive_index.shape
        while len(shape) < 3:
            shape = shape + (1,)
        nx, ny, nz = shape[0], shape[1], shape[2]

        total_nx = nx + 2 * boundary_width
        total_ny = ny + 2 * boundary_width
        total_nz = nz + 2 * boundary_width
        total_voxels = total_nx * total_ny * total_nz

        bytes_per_voxel = 120 if is_vectorial else 40
        gpu_memory_gb = (total_voxels * bytes_per_voxel) / (1024 ** 3)

        logger.info(f"  GPU memory estimate: {gpu_memory_gb:.2f} GB ({'Vectorial' if is_vectorial else 'Scalar'})")

        if gpu_memory_gb > gpu_memory_max_gb:
            soft_errors.append(
                f"Domain size too large for GPU. Estimated memory: {gpu_memory_gb:.2f} GB "
                f"exceeds cap {gpu_memory_max_gb:.0f} GB. Reduce domain size or pixel count, "
                f"raise gpu_memory_max_gb, or keep strict_validation=False to proceed anyway."
            )
        elif gpu_memory_gb > DEFAULT_GPU_MEMORY_OK_GB:
            warnings.append(
                f"GPU memory {gpu_memory_gb:.2f} GB exceeds standard {DEFAULT_GPU_MEMORY_OK_GB:.0f} GB. "
                f"Will use advanced GPU instance."
            )

    # 8. Validate sources
    if not sources:
        errors.append("At least one source is required")
    else:
        ri_shape = refractive_index.shape if refractive_index is not None else (0, 0, 0)
        while len(ri_shape) < 3:
            ri_shape = ri_shape + (1,)
        nx, ny, nz = ri_shape[0], ri_shape[1], ri_shape[2]

        for i, src in enumerate(sources):
            src_field = src.get("field")
            if src_field is None or (isinstance(src_field, np.ndarray) and src_field.size == 0):
                errors.append(f"Source {i + 1}: field is empty")
            elif isinstance(src_field, np.ndarray):
                if np.any(np.isnan(src_field)):
                    errors.append(f"Source {i + 1}: field contains NaN values")
                if np.any(np.isinf(src_field)):
                    errors.append(f"Source {i + 1}: field contains Inf values")

                src_shape = src_field.shape
                while len(src_shape) < 3:
                    src_shape = src_shape + (1,)
                if src_shape[0] > nx or src_shape[1] > ny or src_shape[2] > nz:
                    soft_errors.append(
                        f"Source {i + 1}: field size [{src_shape[0]},{src_shape[1]},{src_shape[2]}] "
                        f"exceeds domain [{nx},{ny},{nz}]"
                    )

                if np.all(src_field == 0):
                    warnings.append(f"Source {i + 1}: field is all zeros")

            # Check position
            pos = src.get("position")
            if pos is None or len(pos) < 3:
                errors.append(f"Source {i + 1}: position must have at least 3 elements [x, y, z]")
            elif pixel_size and pixel_size > 0:
                domain_x = nx * pixel_size
                domain_y = ny * pixel_size
                domain_z = nz * pixel_size
                if pos[0] < 0 or pos[0] > domain_x:
                    warnings.append(f"Source {i + 1}: x position ({pos[0]:.2f} um) outside domain [0, {domain_x:.2f}]")
                if pos[1] < 0 or pos[1] > domain_y:
                    warnings.append(f"Source {i + 1}: y position ({pos[1]:.2f} um) outside domain [0, {domain_y:.2f}]")
                if pos[2] < 0 or pos[2] > domain_z:
                    warnings.append(f"Source {i + 1}: z position ({pos[2]:.2f} um) outside domain [0, {domain_z:.2f}]")

            # Check polarization for vectorial
            pol = src.get("polarization")
            if pol is not None and is_vectorial and pol not in (0, 1, 2):
                warnings.append(f"Source {i + 1}: invalid polarization {pol} for vectorial simulation (expected 0=x, 1=y, 2=z)")

    # In non-strict mode, soft errors are downgraded to warnings.
    if strict_validation:
        errors = errors + soft_errors
    else:
        warnings = warnings + soft_errors

    # Report warnings
    for w in warnings:
        logger.warning(f"  [!] {w}")

    # Raise on errors
    if errors:
        for e in errors:
            logger.error(f"  [X] {e}")
        raise ParameterValidationError(errors, warnings)

    logger.info("  All parameters validated successfully")
    return warnings
