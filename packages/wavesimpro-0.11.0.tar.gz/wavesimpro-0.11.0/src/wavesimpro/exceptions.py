"""
Exception classes for WavesimPythonAPI
"""


class RayfosAPIError(Exception):
    """Base exception for all Rayfos API errors"""
    
    def __init__(self, message: str, status_code: int = None, response=None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class AuthenticationError(RayfosAPIError):
    """Raised when authentication fails"""
    pass


class NotFoundError(RayfosAPIError):
    """Raised when a resource is not found (404)"""
    pass


class ValidationError(RayfosAPIError):
    """Raised when input validation fails (400)"""
    pass


class ServerError(RayfosAPIError):
    """Raised when the server encounters an error (5xx)"""
    pass


class ConfigurationError(RayfosAPIError):
    """Raised when configuration is invalid"""
    pass


