"""
Configuration module for WavesimPythonAPI
"""

import os
from typing import Optional
from dataclasses import dataclass


@dataclass
class ClientConfig:
    """
    Configuration for the Rayfos API client
    
    Attributes:
        api_token: User API token for authentication
        server_url: Base URL of RayfosJobServer for project management (default: server.rayfos.com)
        machine_service_url: Optional URL of RayfosMachineService for file uploads
        timeout: Request timeout in seconds
        verify_ssl: Whether to verify SSL certificates for server_url
        verify_ssl_machine_service: Whether to verify SSL certificates for machine_service_url
    """
    
    api_token: str
    server_url: str = "https://server.rayfos.com"
    machine_service_url: Optional[str] = None
    timeout: int = 30
    verify_ssl: bool = True
    verify_ssl_machine_service: bool = True
    
    def __post_init__(self):
        """Validate configuration after initialization"""
        # Remove trailing slashes from URLs
        if self.server_url:
            self.server_url = self.server_url.rstrip('/')
        if self.machine_service_url:
            self.machine_service_url = self.machine_service_url.rstrip('/')
            
            # Auto-detect SSL verification for localhost machine service
            if not hasattr(self, '_verify_ssl_ms_set'):
                if "localhost" in self.machine_service_url or "127.0.0.1" in self.machine_service_url:
                    self.verify_ssl_machine_service = False
    
    @classmethod
    def from_env(cls) -> "ClientConfig":
        """
        Create configuration from environment variables
        
        Environment variables:
            RAYFOS_API_TOKEN: API token (required)
            RAYFOS_SERVER_URL: Project server URL (optional, defaults to server.rayfos.com)
            RAYFOS_MACHINE_SERVICE_URL: Machine service URL for file uploads (optional)
        
        Returns:
            ClientConfig instance
        
        Raises:
            ValueError: If required environment variables are missing
        """
        api_token = os.getenv("RAYFOS_API_TOKEN")
        if not api_token:
            raise ValueError("RAYFOS_API_TOKEN environment variable is required")
        
        # Get server URL (defaults to cloud server)
        server_url = os.getenv("RAYFOS_SERVER_URL", "https://server.rayfos.com")
        
        # Get optional machine service URL for file uploads
        machine_service_url = os.getenv("RAYFOS_MACHINE_SERVICE_URL")
        
        # SSL verification for main server (always True for production servers)
        verify_ssl = True
        if "localhost" in server_url or "127.0.0.1" in server_url:
            verify_ssl = False
        
        # SSL verification for machine service (auto-detect localhost)
        verify_ssl_machine_service = True
        if machine_service_url and ("localhost" in machine_service_url or "127.0.0.1" in machine_service_url):
            verify_ssl_machine_service = False
        
        return cls(
            api_token=api_token,
            server_url=server_url,
            machine_service_url=machine_service_url,
            timeout=30,
            verify_ssl=verify_ssl,
            verify_ssl_machine_service=verify_ssl_machine_service,
        )
    
    def get_api_url(self, endpoint: str) -> str:
        """
        Get the full URL for an API endpoint
        
        Args:
            endpoint: API endpoint path (e.g., '/api/projects')
        
        Returns:
            Full URL
        """
        if not endpoint.startswith('/'):
            endpoint = f'/{endpoint}'
        return f"{self.server_url}{endpoint}"
    
    def get_machine_service_url(self, endpoint: str) -> str:
        """
        Get the full URL for a machine service endpoint
        
        Args:
            endpoint: Machine service endpoint path
        
        Returns:
            Full URL
        
        Raises:
            ValueError: If machine_service_url is not configured
        """
        if not self.machine_service_url:
            raise ValueError("Machine service URL is not configured")
        
        if not endpoint.startswith('/'):
            endpoint = f'/{endpoint}'
        return f"{self.machine_service_url}{endpoint}"


