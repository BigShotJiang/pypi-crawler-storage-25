"""
Setup wizard and credential management for wavesimpro.

Global config lives at ~/.wavesimpro/.env and is written by run_setup().
Credential resolution order:
    1. configure() call
    2. Local .env in the current working directory
    3. ~/.wavesimpro/.env  (global, written by this wizard)
    4. RAYFOS_API_KEY / RAYFOS_API_URL environment variables
"""

import getpass
import os
from pathlib import Path

DEFAULT_API_URL = "https://server.rayfos.com"
GLOBAL_CONFIG_DIR = Path.home() / ".wavesimpro"
GLOBAL_CONFIG_FILE = GLOBAL_CONFIG_DIR / ".env"


def load_global_config() -> dict:
    """Load key/url from the global config file if it exists."""
    result = {}
    if GLOBAL_CONFIG_FILE.exists():
        for line in GLOBAL_CONFIG_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                result[k.strip()] = v.strip()
    return result


def save_global_config(api_key: str, api_url: str):
    GLOBAL_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    GLOBAL_CONFIG_FILE.write_text(
        f"RAYFOS_API_KEY={api_key}\n"
        f"RAYFOS_API_URL={api_url}\n",
        encoding="utf-8",
    )


def resolve_credentials() -> tuple[str | None, str]:
    """Return (api_key, api_url) from the first source that has them."""
    from .simulate import _defaults

    api_key = _defaults.get("api_key")
    api_url = _defaults.get("api_url")
    if api_key:
        return api_key, api_url or DEFAULT_API_URL

    # Local .env
    local_env = Path(".env")
    if local_env.exists():
        from dotenv import dotenv_values
        vals = dotenv_values(local_env)
        api_key = api_key or vals.get("RAYFOS_API_KEY")
        api_url = api_url or vals.get("RAYFOS_API_URL")
    if api_key:
        return api_key, api_url or DEFAULT_API_URL

    # Global config
    cfg = load_global_config()
    api_key = api_key or cfg.get("RAYFOS_API_KEY")
    api_url = api_url or cfg.get("RAYFOS_API_URL")
    if api_key:
        return api_key, api_url or DEFAULT_API_URL

    # Environment variables
    api_key = os.environ.get("RAYFOS_API_KEY")
    api_url = api_url or os.environ.get("RAYFOS_API_URL")
    return api_key, api_url or DEFAULT_API_URL


def _test_connection(api_key: str, api_url: str) -> bool:
    try:
        import requests
        resp = requests.get(
            f"{api_url.rstrip('/')}/api/health",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10,
            verify=not ("localhost" in api_url or "127.0.0.1" in api_url),
        )
        return resp.status_code < 500
    except Exception as e:
        print(f"  Connection error: {e}")
        return False


def run_setup():
    print()
    print("wavesimpro — setup wizard")
    print("=" * 40)

    existing = load_global_config()
    existing_key = existing.get("RAYFOS_API_KEY", "")
    existing_url = existing.get("RAYFOS_API_URL", DEFAULT_API_URL)

    if existing_key:
        masked = existing_key[:6] + "..." + existing_key[-4:]
        print(f"Existing config found at: {GLOBAL_CONFIG_FILE}")
        print(f"  API key : {masked}")
        print(f"  Server  : {existing_url}")
        print()
        overwrite = input("Overwrite? [y/N]: ").strip().lower()
        if overwrite != "y":
            print("Keeping existing config.")
            return

    print()
    api_key = input("API key: ").strip()
    if not api_key:
        print("No API key entered. Aborting.")
        return
    masked_preview = api_key[:6] + "*" * max(0, len(api_key) - 6)
    print(f"  Got: {masked_preview}")

    url_prompt = f"Server URL [{DEFAULT_API_URL}]: "
    api_url = input(url_prompt).strip() or DEFAULT_API_URL

    print()
    print("Testing connection...")
    ok = _test_connection(api_key, api_url)
    if ok:
        print("  Connection successful.")
    else:
        print("  Could not reach server — saving anyway (check URL/key later).")

    save_global_config(api_key, api_url)
    print()
    print(f"Config saved to: {GLOBAL_CONFIG_FILE}")
    print("You're all set. Import wavesimpro in any project without extra setup.")
    print()


def run_status():
    print()
    print("wavesimpro — current configuration")
    print("=" * 40)

    api_key, api_url = resolve_credentials()

    if not api_key:
        print("No credentials found.")
        print("Run: python -m wavesimpro setup")
        return

    masked = api_key[:6] + "..." + api_key[-4:] if len(api_key) > 10 else "***"
    print(f"API key : {masked}")
    print(f"Server  : {api_url}")

    cfg = load_global_config()
    if cfg.get("RAYFOS_API_KEY") == api_key:
        print(f"Source  : {GLOBAL_CONFIG_FILE}")
    elif Path(".env").exists():
        print("Source  : local .env")
    else:
        print("Source  : environment variable")

    print()
    print("Testing connection...")
    ok = _test_connection(api_key, api_url)
    print("  OK" if ok else "  Failed — check your API key and server URL")
    print()
