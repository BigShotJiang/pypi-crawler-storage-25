"""
Interactive setup wizard for wavesimPro_api.

Usage:
    python -m wavesimPro_api
    python -m wavesimPro_api setup
    python -m wavesimPro_api status
"""

import sys


def main():
    command = sys.argv[1] if len(sys.argv) > 1 else "setup"

    if command == "setup":
        from .setup import run_setup
        run_setup()
    elif command == "status":
        from .setup import run_status
        run_status()
    else:
        print(f"Unknown command: {command}")
        print("Usage: python -m wavesimPro_api [setup|status]")
        sys.exit(1)


if __name__ == "__main__":
    main()
