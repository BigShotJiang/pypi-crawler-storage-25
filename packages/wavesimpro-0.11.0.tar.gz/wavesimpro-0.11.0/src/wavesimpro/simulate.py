"""
Remote simulate — drop-in replacement for wavesim.simulate() that executes via the Rayfos API.

To switch an example from local to remote, change only the import:
    from wavesim.simulate import simulate       # local GPU
    from wavesimPro_api import simulate         # Rayfos cloud

Credentials are resolved automatically — run the setup wizard once on each machine:
    python -m wavesimPro_api setup

Call configure() to override programmatically.
"""

import inspect
from pathlib import Path
from typing import Callable, Optional, Sequence

import numpy as np

from .execute import execute_via_api


def _caller_script_name() -> str:
    for frame_info in inspect.stack():
        path = frame_info.filename
        if "wavesimpro" not in path and path not in ("<stdin>", "<string>"):
            return Path(path).stem
    return "wavesimpro"

# Sentinel for configure() — distinguishes "not passed" from explicit None,
# which is meaningful for use_gpu (None = auto), gpu_memory_max_gb (None = default cap)
# and strict_validation (False = default).
_UNSET = object()

# Module-level defaults — overridden by configure() or per-call kwargs
_defaults = {
    "api_key": None,
    "api_url": None,
    "description": None,
    "poll_interval": 10.0,
    "engine_preference": "Any",
    "use_gpu": None,
    "strict_validation": False,
    "gpu_memory_max_gb": None,
}


def configure(
    *,
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
    description: Optional[str] = None,
    poll_interval: Optional[float] = None,
    engine_preference: Optional[str] = None,
    use_gpu: Optional[bool] = None,
    strict_validation=_UNSET,
    gpu_memory_max_gb=_UNSET,
):
    """Set module-level defaults for remote execution.

    Call once at the top of a script to avoid repeating credentials on every
    simulate() call.  Any value left as None keeps its current default.

    Args:
        api_key: Rayfos API key (overrides RAYFOS_API_KEY env var).
        api_url: Rayfos API base URL (overrides RAYFOS_API_URL env var).
        description: Job label shown in the Rayfos dashboard.
        poll_interval: Status polling interval in seconds.
        engine_preference: 'Any' (default), 'Python', or 'Cpp'.
        use_gpu: None (auto), True (require GPU), False (force CPU).
        strict_validation: When True, soft validation issues (GPU memory cap
            exceeded, source field larger than domain) raise instead of
            warning. Default False — simulations are not stopped by these.
        gpu_memory_max_gb: Override the soft GPU memory cap (default 65 GB).
            Pass math.inf to disable entirely.
    """
    if api_key is not None:
        _defaults["api_key"] = api_key
    if api_url is not None:
        _defaults["api_url"] = api_url
    if description is not None:
        _defaults["description"] = description
    if poll_interval is not None:
        _defaults["poll_interval"] = poll_interval
    if engine_preference is not None:
        _defaults["engine_preference"] = engine_preference
    if use_gpu is not None:
        _defaults["use_gpu"] = use_gpu
    if strict_validation is not _UNSET:
        _defaults["strict_validation"] = bool(strict_validation)
    if gpu_memory_max_gb is not _UNSET:
        _defaults["gpu_memory_max_gb"] = gpu_memory_max_gb


def simulate(
    permittivity: np.ndarray,
    sources: Sequence[tuple],
    wavelength: float,
    pixel_size: float,
    boundary_width: float = 1.0,
    periodic: tuple = (False, False, False),  # forwarded to PeriodicX/Y/Z in JSON
    use_gpu=None,                              # forwarded to API (None = auto)
    n_domains=None,          # local only — accepted and ignored
    max_iterations: int = 100000,
    threshold: float = 1.0e-6,
    alpha: float = 0.75,
    full_residuals: bool = False,
    crop_boundaries: bool = True,  # local only — accepted and ignored
    callback: Optional[Callable] = None,
    strict_validation: Optional[bool] = None,
    gpu_memory_max_gb=_UNSET,
    **kwargs,
):
    """Execute a Wavesim simulation remotely via the Rayfos API.

    Identical signature to wavesim.simulate() — swap the import, nothing else changes.
    Local-only parameters (periodic, n_domains, alpha, full_residuals, crop_boundaries)
    are silently ignored.

    Credentials are resolved in this order:
        1. configure() call
        2. Local .env in the current working directory
        3. ~/.wavesimPro_api/.env (written by: python -m wavesimPro_api setup)
        4. RAYFOS_API_KEY / RAYFOS_API_URL environment variables

    Returns:
        u: np.ndarray, output field (same shape as wavesim.simulate()).
        iterations: int or None, last reported iteration count.
        residual_norm: float or None, last reported residual norm.
    """
    from .setup import resolve_credentials
    _api_key, _api_url = resolve_credentials()
    api_key = _defaults["api_key"] or _api_key
    api_url = _defaults["api_url"] or _api_url
    if not api_key:
        raise SystemExit(
            "\nwavesimpro: no API key configured.\n"
            "Run the setup wizard once to get started:\n\n"
            "    python -m wavesimpro setup\n"
        )
    description = _defaults["description"] or _caller_script_name()
    poll_interval = _defaults["poll_interval"]
    engine_preference = _defaults["engine_preference"]
    effective_use_gpu = use_gpu if use_gpu is not None else _defaults["use_gpu"]
    effective_strict = (
        _defaults["strict_validation"] if strict_validation is None else bool(strict_validation)
    )
    effective_gpu_max = (
        _defaults["gpu_memory_max_gb"] if gpu_memory_max_gb is _UNSET else gpu_memory_max_gb
    )

    is_vectorial = any(len(s[1]) == 4 for s in sources)
    boundary_width_px = int(np.round(boundary_width / pixel_size))

    api_sources = []
    for src_array, src_pos in sources:
        pos = list(src_pos)
        if is_vectorial:
            pol_1based = int(pos[0]) + 1
            api_pos = [pos[1] * pixel_size, pos[2] * pixel_size, pos[3] * pixel_size, pol_1based]
            src_field = (src_array[0] if src_array.ndim == 4 else src_array).astype(np.complex64)
        else:
            api_pos = [pos[0] * pixel_size, pos[1] * pixel_size, pos[2] * pixel_size]
            src_field = src_array.astype(np.complex64)
        api_sources.append({"Es": src_field, "position": api_pos})

    _last = {"iteration": None, "residual_norm": None, "residuals_list": None}

    def _progress_cb(info: dict):
        _last["iteration"] = info.get("iteration", _last["iteration"])
        _last["residual_norm"] = info.get("residual_norm", _last["residual_norm"])
        if info.get("residuals_list") is not None:
            _last["residuals_list"] = info["residuals_list"]
        if callback is not None and _last["iteration"] is not None:
            extra = {k: v for k, v in info.items() if k not in ("iteration", "residual_norm")}
            callback(None, _last["iteration"], None, _last["residual_norm"], **extra)

    E, _ = execute_via_api(
        refractive_index=permittivity,
        source=api_sources,
        wavelength=wavelength,
        pixel_size=pixel_size,
        boundary_width=boundary_width_px,
        is_vectorial=is_vectorial,
        data_type="Permittivity",
        max_iterations=max_iterations,
        threshold=threshold,
        periodic=periodic,
        api_key=api_key,
        api_url=api_url,
        description=description,
        poll_interval=poll_interval,
        engine_preference=engine_preference,
        use_gpu=effective_use_gpu,
        alpha=alpha,
        keep_residuals_list=full_residuals,
        progress_callback=_progress_cb,
        strict_validation=effective_strict,
        gpu_memory_max_gb=effective_gpu_max,
    )

    iterations = _last["iteration"] or 1
    final_residual = _last["residual_norm"] if _last["residual_norm"] is not None else float("nan")
    if full_residuals:
        residual_norm = _last["residuals_list"] if _last["residuals_list"] else [final_residual] * iterations
    else:
        residual_norm = final_residual
    return E, iterations, residual_norm


def simulate_pro(
    permittivity: np.ndarray,
    sources: Sequence[tuple],
    wavelength: float,
    pixel_size: float,
    boundary_width: float = 1.0,
    periodic: tuple = (False, False, False),
    max_iterations: int = 100000,
    threshold: float = 1.0e-6,
    alpha: float = 0.75,
    n_domains=None,
    full_residuals: bool = False,
    crop_boundaries: bool = True,  # local only — accepted and ignored
    callback: Optional[Callable] = None,
    # remote execution options
    engine: str = "Any",
    use_gpu: Optional[bool] = None,
    machine_id: Optional[str] = None,
    poll_interval: float = 10.0,
    description: Optional[str] = None,
    server: Optional[str] = None,
    strict_validation: Optional[bool] = None,
    gpu_memory_max_gb=_UNSET,
    **kwargs,
):
    """Execute a Wavesim simulation remotely with full control over execution options.

    Drop-in compatible with wavesim.simulate() but exposes all remote-specific options
    that simulate() manages via configure():

        engine       : 'Any' (default) | 'Cpp' | 'Python'
        use_gpu      : None (auto) | True (require GPU) | False (force CPU)
        machine_id   : preferred machine service ID to pin the job to a specific machine
        poll_interval: seconds between status polls (default 10)
        description  : job label shown in the Rayfos dashboard (default: caller script name)
    """
    from .setup import resolve_credentials
    _api_key, _api_url = resolve_credentials()
    api_key = _defaults["api_key"] or _api_key
    api_url = server or _defaults["api_url"] or _api_url
    if not api_key:
        raise SystemExit(
            "\nwavesimpro: no API key configured.\n"
            "Run the setup wizard once to get started:\n\n"
            "    python -m wavesimpro setup\n"
        )

    effective_description = description or _defaults["description"] or _caller_script_name()
    effective_use_gpu = use_gpu if use_gpu is not None else _defaults["use_gpu"]
    effective_strict = (
        _defaults["strict_validation"] if strict_validation is None else bool(strict_validation)
    )
    effective_gpu_max = (
        _defaults["gpu_memory_max_gb"] if gpu_memory_max_gb is _UNSET else gpu_memory_max_gb
    )

    is_vectorial = any(len(s[1]) == 4 for s in sources)
    boundary_width_px = int(np.round(boundary_width / pixel_size))

    api_sources = []
    for src_array, src_pos in sources:
        pos = list(src_pos)
        if is_vectorial:
            pol_1based = int(pos[0]) + 1
            api_pos = [pos[1] * pixel_size, pos[2] * pixel_size, pos[3] * pixel_size, pol_1based]
            src_field = (src_array[0] if src_array.ndim == 4 else src_array).astype(np.complex64)
        else:
            api_pos = [pos[0] * pixel_size, pos[1] * pixel_size, pos[2] * pixel_size]
            src_field = src_array.astype(np.complex64)
        api_sources.append({"Es": src_field, "position": api_pos})

    _last = {"iteration": None, "residual_norm": None, "residuals_list": None}

    def _progress_cb(info: dict):
        _last["iteration"] = info.get("iteration", _last["iteration"])
        _last["residual_norm"] = info.get("residual_norm", _last["residual_norm"])
        if info.get("residuals_list") is not None:
            _last["residuals_list"] = info["residuals_list"]
        if callback is not None and _last["iteration"] is not None:
            extra = {k: v for k, v in info.items() if k not in ("iteration", "residual_norm")}
            callback(None, _last["iteration"], None, _last["residual_norm"], **extra)

    E, _ = execute_via_api(
        refractive_index=permittivity,
        source=api_sources,
        wavelength=wavelength,
        pixel_size=pixel_size,
        boundary_width=boundary_width_px,
        is_vectorial=is_vectorial,
        data_type="Permittivity",
        max_iterations=max_iterations,
        threshold=threshold,
        periodic=periodic,
        api_key=api_key,
        api_url=api_url,
        description=effective_description,
        poll_interval=poll_interval,
        engine_preference=engine,
        use_gpu=effective_use_gpu,
        preferred_machine_id=machine_id,
        alpha=alpha,
        keep_residuals_list=full_residuals,
        progress_callback=_progress_cb,
        strict_validation=effective_strict,
        gpu_memory_max_gb=effective_gpu_max,
    )

    iterations = _last["iteration"] or 1
    final_residual = _last["residual_norm"] if _last["residual_norm"] is not None else float("nan")
    if full_residuals:
        residual_norm = _last["residuals_list"] if _last["residuals_list"] else [final_residual] * iterations
    else:
        residual_norm = final_residual
    return E, iterations, residual_norm
