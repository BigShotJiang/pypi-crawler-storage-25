"""
Engagement triage — analyzes scope and assigns agents dynamically.

For "Scan & Report" depth: a fast LLM call picks agents + parallel groups.
Falls back to hardcoded default plans if triage fails.
"""

from __future__ import annotations

import json
import logging
from typing import TypedDict

logger = logging.getLogger("triage")


class ExecutionPlan(TypedDict):
    agents: list[str]  # all agents in order
    parallel_groups: list[list[str]]  # groups that run concurrently
    prompts: dict[str, str]  # agent_id → custom prompt context from triage


# ---------------------------------------------------------------------------
# Default execution plans (fallback if triage LLM fails)
# ---------------------------------------------------------------------------

DEFAULT_PLANS: dict[str, ExecutionPlan] = {
    "shield": {
        "agents": ["bug-hunter", "test-goblin", "code-gremlin", "pdf-forge"],
        "parallel_groups": [
            ["bug-hunter"],
            ["test-goblin", "code-gremlin"],
            ["pdf-forge"],
        ],
        "prompts": {},
    },
    "blueprint": {
        "agents": ["cloud-sensei", "devops-dwarf", "pdf-forge"],
        "parallel_groups": [
            ["cloud-sensei"],
            ["devops-dwarf"],
            ["pdf-forge"],
        ],
        "prompts": {},
    },
    "launchpad": {
        "agents": [
            "bug-hunter",
            "cloud-sensei",
            "devops-dwarf",
            "test-goblin",
            "code-gremlin",
            "pdf-forge",
        ],
        "parallel_groups": [
            ["bug-hunter", "cloud-sensei"],
            ["devops-dwarf"],
            ["test-goblin", "code-gremlin"],
            ["pdf-forge"],
        ],
        "prompts": {},
    },
}

# All available engagement agents and what they do (for the triage prompt)
AGENT_CAPABILITIES = {
    "bug-hunter": "Security audit — OWASP/MITRE mapping, vulnerability scanning, severity ratings",
    "test-goblin": "Test suite generation — unit, integration, security regression, edge cases",
    "code-gremlin": "Code fixes — patches vulnerabilities, adds hardening, refactors",
    "cloud-sensei": "AWS architecture review — Well-Architected, cost optimization, IaC guidance",
    "devops-dwarf": "Infrastructure — Dockerfiles, CI/CD, Terraform, CloudFormation, Kubernetes",
    "data-sprite": "Database — schemas, migrations, seed data, ETL scripts",
    "pdf-forge": "Report generation — branded PDF documents from analysis results",
}

TRIAGE_SYSTEM_PROMPT = """You are an engagement triage agent. Given a repository URL, scope notes, and package type, decide which agents to assign and how to parallelize them.

Available agents:
{agent_list}

Rules:
1. pdf-forge is ALWAYS the last step (generates the report)
2. Agents in the same parallel group run simultaneously — only group them if they don't need each other's output
3. If an agent depends on another's output, put it in a later group
4. For Shield (security): bug-hunter must run before test-goblin and code-gremlin
5. For Blueprint (architecture): cloud-sensei must run before devops-dwarf
6. For LaunchPad (production readiness): include all relevant agents
7. Only include agents that are relevant to the scope — don't add agents that won't help

Return ONLY valid JSON:
{{
  "agents": ["agent-id", ...],
  "parallel_groups": [["group1-agents"], ["group2-agents"], ...],
  "reasoning": "brief explanation"
}}"""


async def triage(
    repo_url: str,
    scope_notes: str,
    package: str,
) -> ExecutionPlan:
    """Analyze the engagement scope and return an execution plan.

    Uses a fast/cheap LLM call to pick agents and parallelize.
    Falls back to DEFAULT_PLANS if the LLM call fails.
    """
    if package not in DEFAULT_PLANS:
        logger.warning("Unknown package '%s', using launchpad default", package)
        return DEFAULT_PLANS["launchpad"]

    try:
        return await _triage_llm(repo_url, scope_notes, package)
    except Exception as e:
        logger.warning("Triage LLM failed, using default plan: %s", e)
        return DEFAULT_PLANS[package]


async def _triage_llm(repo_url: str, scope_notes: str, package: str) -> ExecutionPlan:
    """Call a fast LLM to determine the execution plan."""
    from agents.llm import _get_openrouter_llm

    agent_list = "\n".join(f"- {aid}: {desc}" for aid, desc in AGENT_CAPABILITIES.items())
    system = TRIAGE_SYSTEM_PROMPT.format(agent_list=agent_list)

    user_msg = (
        f"Package: {package}\n"
        f"Repository: {repo_url}\n"
        f"Scope: {scope_notes or 'General assessment'}\n\n"
        f"Which agents should run, and how should they be grouped for parallel execution?"
    )

    # Use Gemini Flash — fast, cheap, 1M context
    llm = _get_openrouter_llm("google/gemini-3-flash-preview", temperature=0.1, max_tokens=2000)
    from langchain_core.messages import HumanMessage, SystemMessage

    response = llm.invoke([SystemMessage(content=system), HumanMessage(content=user_msg)])

    # Parse the response
    text = response.content if isinstance(response.content, str) else str(response.content)

    # Extract JSON from response (may be wrapped in ```json blocks)
    json_str = text
    if "```" in text:
        import re

        match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
        if match:
            json_str = match.group(1)

    parsed = json.loads(json_str)

    agents = parsed.get("agents", [])
    parallel_groups = parsed.get("parallel_groups", [])

    # Validate: ensure pdf-forge is last
    if "pdf-forge" in agents and agents[-1] != "pdf-forge":
        agents = [a for a in agents if a != "pdf-forge"] + ["pdf-forge"]

    # Validate: ensure all agents in groups are in the agents list
    all_grouped = [a for group in parallel_groups for a in group]
    for agent_id in agents:
        if agent_id not in all_grouped:
            parallel_groups.insert(-1, [agent_id])  # Add before pdf-forge group

    # Ensure pdf-forge is in its own final group
    if parallel_groups and "pdf-forge" not in parallel_groups[-1]:
        parallel_groups = [g for g in parallel_groups if "pdf-forge" not in g] + [["pdf-forge"]]

    logger.info("Triage result for %s: %s (reason: %s)", package, agents, parsed.get("reasoning", ""))

    return {
        "agents": agents,
        "parallel_groups": parallel_groups,
        "prompts": {},
    }


def get_default_plan(package: str) -> ExecutionPlan:
    """Get the default execution plan for a package (no LLM call)."""
    return DEFAULT_PLANS.get(package, DEFAULT_PLANS["launchpad"])
