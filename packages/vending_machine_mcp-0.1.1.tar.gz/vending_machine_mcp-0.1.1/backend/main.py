"""
Vending Machine Backend — FastAPI + LangGraph + WebSocket + Job Queue

Streams agent state transitions and LLM output to the frontend
for real-time xterm.js rendering in the diorama.

Also provides REST endpoints for async job submission and polling
(used for long-running agents like Research Owl deep research).
"""

import asyncio
import contextlib
import logging
import os
import time

logger = logging.getLogger("main")

from dotenv import load_dotenv

# Load .env BEFORE any module that reads os.environ at import time
# (mcp_registry seeds MCP servers from env vars on import)
load_dotenv(override=True)

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agents.llm import MODELS
from agents.registry import (
    AGENT_GRAPHS,
    AGENT_NAMES,
    build_initial_state,
    estimate_tokens,
    format_step_output,
)
from guards.gate_keeper import screen_input
from guards.qa_auditor import audit_output
from job_runner import run_job
from jobs import (
    JobStatus,
    cancel_job,
    create_job,
    get_job,
    list_jobs,
    load_active_jobs_from_db,
    reap_stuck_jobs,
    update_job,
)
from mcp_routes import mcp_router
from pricing import calculate_cost, ensure_prices_loaded

# Set of strong references to background tasks to prevent garbage collection (RUF006)
_background_tasks: set[asyncio.Task] = set()

from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """Startup and shutdown lifecycle events."""
    await ensure_prices_loaded()

    # Load active jobs from Supabase on startup (JOB-001)
    loaded = load_active_jobs_from_db()
    logger.info("Startup: loaded %d active jobs from database", loaded)

    # Load and resume interrupted engagements (ENG-001)
    from engagements import load_engagements_from_db, resume_running_engagements

    eng_loaded = load_engagements_from_db()
    logger.info("Startup: loaded %d engagements from database", eng_loaded)
    if eng_loaded > 0:
        eng_resumed = await resume_running_engagements()
        if eng_resumed:
            logger.info("Startup: resumed %d interrupted engagements", eng_resumed)

    # Start the stuck job reaper (JOB-002)
    reaper_task = asyncio.create_task(_job_reaper_loop())
    _background_tasks.add(reaper_task)
    reaper_task.add_done_callback(_background_tasks.discard)

    yield


async def _job_reaper_loop():
    """Background task that expires stuck jobs and checks alerts every 60 seconds."""
    while True:
        await asyncio.sleep(60)
        try:
            reaped = reap_stuck_jobs()
            if reaped:
                logger.warning("Reaper expired %d stuck jobs: %s", len(reaped), reaped)
        except Exception as e:
            logger.exception("Reaper error: %s", e)

        # Run alert checks (OBS-002)
        try:
            from alerting import check_alerts

            alerts = check_alerts()
            if alerts:
                logger.warning("Alerts triggered: %s", alerts)
        except Exception as e:
            logger.debug("Alert check error: %s", e)


app = FastAPI(title="Vending Machine API", version="0.6.0", lifespan=lifespan)

# Register production middleware
from errors import register_error_handlers
from middleware import RequestIDMiddleware, check_rate_limit, get_metrics, get_uptime, inc_metric

app.add_middleware(RequestIDMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register standard error handlers (SAFE-001)
register_error_handlers(app)

# MCP server registry routes
app.include_router(mcp_router)


# ─── Tenant Identification Middleware (TENANT-001) ────────────────────


@app.middleware("http")
async def tenant_middleware(request: Request, call_next):
    """Extract tenant_id from auth headers and set on request state."""
    tenant_id = "anonymous"

    # Try to identify tenant from auth headers (lightweight, no full validation)
    authorization = request.headers.get("authorization", "")
    x_api_key = request.headers.get("x-api-key", "")

    if authorization.startswith("Bearer ") and len(authorization) > 20:
        # Decode JWT to extract stable Supabase user ID (sub claim)
        import base64
        import json as _json

        try:
            token = authorization[7:]
            # JWT payload is the second segment, base64url-encoded
            payload_b64 = token.split(".")[1]
            # Add padding if needed
            payload_b64 += "=" * (-len(payload_b64) % 4)
            payload = _json.loads(base64.urlsafe_b64decode(payload_b64))
            tenant_id = payload.get("sub", "anonymous")
        except Exception:
            import hashlib

            tenant_id = f"jwt:{hashlib.sha256(authorization.encode()).hexdigest()[:12]}"
    elif x_api_key:
        import hashlib

        tenant_id = f"key:{hashlib.sha256(x_api_key.encode()).hexdigest()[:12]}"

    request.state.tenant_id = tenant_id
    return await call_next(request)


# ─── Rate Limiting Middleware ─────────────────────────────────────────


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Enforce rate limits on all API endpoints."""
    # Skip non-API routes and health checks
    if not request.url.path.startswith("/api") or request.url.path == "/health":
        return await call_next(request)

    from middleware import check_idempotency

    # Check idempotency cache first (IDEMP-001)
    cached = await check_idempotency(request)
    if cached:
        from fastapi.responses import JSONResponse

        return JSONResponse(content=cached, headers={"X-Idempotent-Replay": "true"})

    # Check rate limit (RATE-001)
    allowed, headers = await check_rate_limit(request)
    if not allowed:
        inc_metric("requests_429")
        from fastapi.responses import JSONResponse

        request_id = getattr(request.state, "request_id", "")
        return JSONResponse(
            status_code=429,
            content={
                "error": {
                    "code": "RATE_LIMIT_EXCEEDED",
                    "message": "Too many requests. Please slow down.",
                    "request_id": request_id,
                    "details": {},
                }
            },
            headers=headers,
        )

    response = await call_next(request)

    # Add rate limit headers to response
    for k, v in headers.items():
        response.headers[k] = v

    # Track metrics
    inc_metric("requests_total")
    if response.status_code >= 500:
        inc_metric("requests_5xx")
    elif response.status_code >= 400:
        inc_metric("requests_4xx")

    return response


# ─── Health + Metrics ─────────────────────────────────────────────────


@app.get("/health")
async def health():
    """Enhanced health check with dependency status and metrics."""
    from jobs import JOB_STORE, TERMINAL_STATES
    from sandbox import is_available as sandbox_available

    active_jobs = sum(1 for j in JOB_STORE.values() if j["status"] not in TERMINAL_STATES)

    # Check Supabase connectivity
    sb_status = "disconnected"
    try:
        from supabase_client import get_supabase, is_available

        if is_available():
            get_supabase().table("profiles").select("id").limit(1).execute()
            sb_status = "connected"
    except Exception:
        sb_status = "error"

    # Check Redis connectivity
    redis_status = "disconnected"
    try:
        from middleware import get_redis

        r = get_redis()
        if r:
            r.ping()
            redis_status = "connected"
    except Exception:
        redis_status = "error"

    return {
        "status": "ok",
        "version": "0.6.0",
        "uptime_seconds": get_uptime(),
        "sandbox_provider": os.getenv("SANDBOX_PROVIDER", "auto"),
        "dependencies": {
            "supabase": sb_status,
            "redis": redis_status,
            "sandbox": "available" if sandbox_available() else "unavailable",
        },
        "agents": [*AGENT_GRAPHS.keys(), "ceo-agent"],
        "metrics": {
            "active_jobs": active_jobs,
            **get_metrics(),
        },
    }


@app.get("/metrics")
async def metrics_endpoint(request: Request):
    """Metrics endpoint — JSON by default, Prometheus text if requested."""
    from metrics import export_json, export_prometheus

    accept = request.headers.get("accept", "")
    if "text/plain" in accept or "prometheus" in accept:
        from fastapi.responses import PlainTextResponse

        return PlainTextResponse(export_prometheus(), media_type="text/plain; charset=utf-8")
    return export_json()


# ─── Ops Endpoints ────────────────────────────────────────────────────


@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job_endpoint(job_id: str):
    """Cancel a running or queued job."""
    result = cancel_job(job_id)
    if not result:
        raise HTTPException(status_code=404, detail="Job not found")
    return {"job_id": job_id, "status": result["status"]}


@app.get("/api/ops/errors")
async def ops_error_summary(window: int = 15):
    """Get error summary for the last N minutes (admin/ops only)."""
    from jobs import JOB_STORE

    cutoff = time.time() - (window * 60)
    errors = []
    for job in JOB_STORE.values():
        if job["status"] in ("error", "expired") and (job.get("completed_at") or 0) > cutoff:
            errors.append(
                {
                    "job_id": job["job_id"],
                    "agent": job["agent_id"],
                    "error": job.get("error", "")[:200],
                    "completed_at": job.get("completed_at"),
                }
            )
    return {"window_minutes": window, "error_count": len(errors), "errors": errors}


@app.get("/api/ops/stuck")
async def ops_stuck_jobs():
    """List currently stuck jobs (running past their timeout)."""
    from jobs import JOB_STORE, TERMINAL_STATES

    now = time.time()
    stuck = []
    for job in JOB_STORE.values():
        if job["status"] not in TERMINAL_STATES:
            timeout_at = job.get("timeout_at", 0)
            if timeout_at and now > timeout_at:
                stuck.append(
                    {
                        "job_id": job["job_id"],
                        "agent": job["agent_id"],
                        "age_seconds": int(now - job["created_at"]),
                        "timeout_at": timeout_at,
                    }
                )
    return {"stuck_count": len(stuck), "stuck_jobs": stuck}


@app.get("/api/ops/spend")
async def ops_spend_summary(window: int = 60):
    """Get spend summary for the last N minutes (admin/ops only)."""
    from jobs import JOB_STORE

    cutoff = time.time() - (window * 60)
    total_cost = 0.0
    total_tokens = 0
    jobs_in_window = 0

    for job in JOB_STORE.values():
        completed = job.get("completed_at", 0) or 0
        if completed > cutoff and job.get("metadata"):
            meta = job["metadata"]
            total_cost += meta.get("cost", 0)
            total_tokens += meta.get("inputTokens", 0) + meta.get("outputTokens", 0)
            jobs_in_window += 1

    return {
        "window_minutes": window,
        "jobs_completed": jobs_in_window,
        "total_cost_usd": round(total_cost, 6),
        "total_tokens": total_tokens,
        "avg_cost_per_job": round(total_cost / max(jobs_in_window, 1), 6),
    }


# ─── WebSocket (real-time streaming for quick agents) ─────────────────


@app.websocket("/ws/agent/{agent_id}")
async def agent_websocket(websocket: WebSocket, agent_id: str):
    """
    WebSocket endpoint for running an agent.

    Client sends: {"task": "..."}
    Server streams: {"step": "...", "output": "..."} per node
    Final message includes metadata: runtime, tokens, timestamp
    """
    await websocket.accept()

    # CEO Agent has its own WebSocket at /ws/ceo — redirect if client hits this endpoint
    if agent_id == "ceo-agent":
        await websocket.send_json({"error": "CEO Agent uses /ws/ceo endpoint"})
        await websocket.close()
        return

    if agent_id not in AGENT_GRAPHS:
        await websocket.send_json({"error": f"Unknown agent: {agent_id}"})
        await websocket.close()
        return

    graph = AGENT_GRAPHS[agent_id]
    agent_name = AGENT_NAMES.get(agent_id, agent_id)

    try:
        while True:
            data = await websocket.receive_json()
            task = data.get("task", "")

            if not task:
                await websocket.send_json({"error": "No task provided"})
                continue

            # ── Gate Keeper: screen input before running agent ──
            screen = await screen_input(task, agent_id)
            if screen.blocked:
                await websocket.send_json(
                    {
                        "step": "error",
                        "output": f"\n> Transaction Declined.\n> {screen.reason}",
                        "metadata": {
                            "agentId": agent_id,
                            "agentName": agent_name,
                            "blocked": True,
                            "riskScore": screen.risk_score,
                            "flags": screen.flags,
                            "timestamp": int(time.time() * 1000),
                        },
                    }
                )
                continue

            # Track timing and output for metadata
            start_time = time.time()
            all_outputs: list[str] = []
            input_text = task

            # Include gate keeper warning if flagged but not blocked
            thinking_msg = f'$ {agent_id} --analyze\n> Parsing request: "{task}"\n> Planning approach...'
            if screen.flags:
                thinking_msg += f"\n> Gate Keeper: {len(screen.flags)} low-risk flag(s) noted."

            await websocket.send_json(
                {
                    "step": "thinking",
                    "output": thinking_msg,
                }
            )

            try:
                initial_state = build_initial_state(task)
                final_token_usage = {"input_tokens": 0, "output_tokens": 0}

                async for event in graph.astream(initial_state, stream_mode="updates"):
                    for node_name, state_update in event.items():
                        step = state_update.get("current_step", node_name)
                        output = format_step_output(step, state_update)
                        all_outputs.append(output)

                        # Capture accumulated token usage from state
                        if "token_usage" in state_update:
                            final_token_usage = state_update["token_usage"]

                        try:
                            await websocket.send_json(
                                {
                                    "step": step,
                                    "output": output,
                                }
                            )
                        except (WebSocketDisconnect, RuntimeError):
                            return

                # ── QA Auditor: verify output before delivery ──
                full_output = "\n".join(all_outputs)

                await websocket.send_json(
                    {
                        "step": "reviewing",
                        "output": "> QA Auditor: Verifying output quality...",
                    }
                )

                qa_result = await audit_output(
                    output=full_output,
                    agent_id=agent_id,
                    task=task,
                    skip_llm=False,
                )

                # Calculate metadata with real tokens + cost
                elapsed_ms = int((time.time() - start_time) * 1000)
                input_tokens = final_token_usage.get("input_tokens", 0) or estimate_tokens(input_text)
                output_tokens = final_token_usage.get("output_tokens", 0) or estimate_tokens(full_output)

                # Get the model ID for this agent to calculate cost
                model_info = MODELS.get(agent_id)
                model_id = model_info[0] if model_info else "unknown"
                cost = calculate_cost(model_id, input_tokens, output_tokens)

                # Build QA summary for metadata
                qa_meta = {
                    "verdict": qa_result.verdict,
                    "toolChecks": len(qa_result.tool_checks),
                    "toolFailures": len([c for c in qa_result.tool_checks if not c.passed]),
                    "secretFindings": qa_result.secret_findings,
                    "llmSummary": qa_result.llm_summary[:200] if qa_result.llm_summary else "",
                    "latencyMs": round(qa_result.latency_ms, 1),
                }

                # Add QA badge to completion message
                qa_badge = ""
                if qa_result.verdict == "WARN":
                    qa_badge = f"\n> QA Auditor: ⚠️ {qa_result.llm_summary[:150]}"
                elif qa_result.verdict == "FAIL":
                    qa_badge = f"\n> QA Auditor: ❌ {qa_result.llm_summary[:150]}"
                else:
                    qa_badge = "\n> QA Auditor: ✅ Output verified."

                await websocket.send_json(
                    {
                        "step": "complete",
                        "output": f"{qa_badge}\n> Done. Dispensing from {agent_name}.\n> Thank you for your hire!",
                        "metadata": {
                            "agentId": agent_id,
                            "agentName": agent_name,
                            "model": model_id,
                            "runtimeMs": elapsed_ms,
                            "inputTokens": input_tokens,
                            "outputTokens": output_tokens,
                            "cost": round(cost, 6),
                            "timestamp": int(time.time() * 1000),
                            "qa": qa_meta,
                        },
                    }
                )

            except WebSocketDisconnect:
                return
            except Exception as e:
                elapsed_ms = int((time.time() - start_time) * 1000)
                try:
                    await websocket.send_json(
                        {
                            "step": "error",
                            "output": f"\n> Error: {e!s}",
                            "metadata": {
                                "agentId": agent_id,
                                "agentName": agent_name,
                                "runtimeMs": elapsed_ms,
                                "inputTokens": estimate_tokens(task),
                                "outputTokens": 0,
                                "timestamp": int(time.time() * 1000),
                            },
                        }
                    )
                except (WebSocketDisconnect, RuntimeError):
                    return

    except WebSocketDisconnect:
        pass


# ─── CEO WebSocket (real-time War Room streaming) ────────────────────


@app.websocket("/ws/ceo")
async def ceo_websocket(websocket: WebSocket):
    """
    Dedicated WebSocket for the CEO Agent with structured progress events.

    Client sends: {"task": "..."}
    Server streams: CeoProgressEvent objects (planning, delegation_start,
                    delegation_complete, synthesizing, complete, error)
    """
    await websocket.accept()

    try:
        data = await websocket.receive_json()
        task = data.get("task", "")

        if not task:
            await websocket.send_json({"type": "error", "message": "No task provided"})
            await websocket.close()
            return

        # Create job for Inbox tracking
        job = create_job("ceo-agent", "CEO Agent", task)
        job_id = job["job_id"]
        update_job(job_id, status=JobStatus.running, started_at=time.time())

        # Send job_id so frontend can track in Inbox
        await websocket.send_json({"type": "job_created", "jobId": job_id})

        # Progress callback streams events to WebSocket
        async def send_event(event: dict):
            with contextlib.suppress(WebSocketDisconnect, RuntimeError):
                await websocket.send_json(event)

        start_time = time.time()

        try:
            from agents.ceo_agent import run_ceo_agent

            await run_ceo_agent(task, job_id, progress_callback=send_event)

            # Finalize job metadata — merge with what run_ceo_agent already stored
            elapsed_ms = int((time.time() - start_time) * 1000)
            final_job = get_job(job_id)
            full_output = final_job["output"] if final_job else ""
            existing_meta = final_job.get("metadata") or {} if final_job else {}

            merged_meta = {
                "agentId": "ceo-agent",
                "agentName": "CEO Agent",
                "model": "claude-sonnet-4-6",
                "runtimeMs": elapsed_ms,
                "inputTokens": existing_meta.get("inputTokens") or estimate_tokens(task),
                "outputTokens": existing_meta.get("outputTokens") or estimate_tokens(full_output),
                "cost": existing_meta.get("cost", 0),
                "timestamp": int(time.time() * 1000),
            }
            if "delegations" in existing_meta:
                merged_meta["delegations"] = existing_meta["delegations"]

            update_job(
                job_id,
                status=JobStatus.complete,
                completed_at=time.time(),
                metadata=merged_meta,
            )

        except Exception as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            await send_event({"type": "error", "message": str(e)})
            update_job(
                job_id,
                status=JobStatus.error,
                completed_at=time.time(),
                error=str(e),
                metadata={
                    "agentId": "ceo-agent",
                    "agentName": "CEO Agent",
                    "runtimeMs": elapsed_ms,
                    "inputTokens": estimate_tokens(task),
                    "outputTokens": 0,
                    "timestamp": int(time.time() * 1000),
                },
            )

    except WebSocketDisconnect:
        pass


# ─── REST Job Queue (for long-running agents) ────────────────────────


class JobSubmitRequest(BaseModel):
    agent_id: str
    task: str


@app.post("/api/jobs")
async def submit_job(req: JobSubmitRequest, request: Request):
    """Submit an async job. Returns immediately with a job_id for polling.

    Checks credit balance before accepting the job (BILL-001).
    """
    from credits import check_balance, get_agent_cost

    # Extract user for billing
    tenant_id = getattr(request.state, "tenant_id", "anonymous")

    # Check credit balance before accepting
    cost = get_agent_cost(req.agent_id)
    allowed, balance, _ = check_balance(tenant_id, cost)
    if not allowed:
        raise HTTPException(
            status_code=402,
            detail=f"Insufficient credits. Required: {cost}, balance: {balance}. Refills monthly.",
        )

    # CEO Agent uses Claude Agent SDK (not LangGraph) — special routing
    if req.agent_id == "ceo-agent":
        from ceo_runner import run_ceo_job

        job = create_job(req.agent_id, "CEO Agent", req.task)
        task = asyncio.create_task(run_ceo_job(job["job_id"]))
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)
        return {"job_id": job["job_id"], "status": job["status"]}

    if req.agent_id not in AGENT_GRAPHS:
        return {"error": f"Unknown agent: {req.agent_id}"}, 404

    agent_name = AGENT_NAMES.get(req.agent_id, req.agent_id)
    job = create_job(req.agent_id, agent_name, req.task)

    # Fire and forget — the job runs in the background
    task = asyncio.create_task(run_job(job["job_id"]))
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)

    return {"job_id": job["job_id"], "status": job["status"]}


@app.get("/api/jobs/{job_id}")
async def poll_job(job_id: str):
    """Poll a job's status and result."""
    job = get_job(job_id)
    if not job:
        return {"error": "Job not found"}, 404
    return job


@app.get("/api/jobs")
async def list_all_jobs():
    """List all jobs, newest first."""
    return list_jobs()


# ─── Engagements (White-Glove Delivery) ─────────────────────────────


class CreateEngagementRequest(BaseModel):
    package: str  # "shield" | "blueprint" | "launchpad"
    tier: str = "self-serve"  # "self-serve" | "premium"
    depth: str = "scan"  # "scan" | "autonomous"
    repo_url: str
    scope_notes: str = ""


@app.post("/api/engagements")
async def create_engagement_endpoint(req: CreateEngagementRequest, request: Request):
    """Create a new engagement. Validates inputs, checks credits, starts pipeline."""
    from credits import check_balance, get_workflow_cost
    from engagements import (
        VALID_DEPTHS,
        VALID_PACKAGES,
        VALID_TIERS,
        create_engagement,
        run_autonomous_engagement,
        run_engagement,
    )

    if req.package not in VALID_PACKAGES:
        raise HTTPException(status_code=400, detail=f"Invalid package. Must be one of: {', '.join(VALID_PACKAGES)}")
    if req.tier not in VALID_TIERS:
        raise HTTPException(status_code=400, detail=f"Invalid tier. Must be one of: {', '.join(VALID_TIERS)}")
    if req.depth not in VALID_DEPTHS:
        raise HTTPException(status_code=400, detail=f"Invalid depth. Must be one of: {', '.join(VALID_DEPTHS)}")

    tenant_id = getattr(request.state, "tenant_id", "anonymous")

    cost = get_workflow_cost(req.package)
    allowed, balance, _ = check_balance(tenant_id, cost)
    if not allowed:
        raise HTTPException(
            status_code=402,
            detail=f"Insufficient credits. Required: {cost}, balance: {balance}.",
        )

    engagement = create_engagement(tenant_id, req.package, req.tier, req.repo_url, req.scope_notes, depth=req.depth)

    # Route to the appropriate pipeline based on depth
    if req.depth == "autonomous":
        coro = run_autonomous_engagement(engagement["id"])
    else:
        coro = run_engagement(engagement["id"])

    task = asyncio.create_task(coro)
    _background_tasks.add(task)

    def _on_done(t):
        _background_tasks.discard(t)
        if t.exception():
            logger.error("Engagement task failed: %s", t.exception())
        else:
            logger.info("Engagement task completed for %s", engagement["id"])

    task.add_done_callback(_on_done)
    logger.warning("Started %s engagement task for %s (depth=%s)", req.package, engagement["id"], req.depth)

    return engagement


@app.get("/api/engagements")
async def list_engagements_endpoint(request: Request):
    """List current user's engagements."""
    from engagements import list_engagements

    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    return list_engagements(tenant_id)


@app.get("/api/engagements/{engagement_id}")
async def get_engagement_endpoint(engagement_id: str, request: Request):
    """Get engagement detail with sub-job statuses."""
    from engagements import get_engagement

    engagement = get_engagement(engagement_id)
    if not engagement:
        raise HTTPException(status_code=404, detail="Engagement not found")

    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    if engagement["user_id"] != tenant_id and tenant_id == "anonymous":
        raise HTTPException(status_code=401, detail="Authentication required")

    # Enrich with sub-job details — unified store, single get_job() call
    enriched = dict(engagement)
    steps = []
    for job_id in engagement["job_ids"]:
        job = get_job(job_id)
        if job:
            meta = job.get("metadata") or {}
            steps.append(
                {
                    "job_id": job.get("job_id", job_id),
                    "agent_id": job.get("agent_id", ""),
                    "agent_name": job.get("agent_name", ""),
                    "status": job.get("status", "running"),
                    "runtime_ms": meta.get("runtimeMs", 0) or job.get("runtime_ms", 0),
                    "output": job.get("output", "")[:20_000],  # truncate for response size
                }
            )
    enriched["steps"] = steps
    return enriched


@app.get("/api/engagements/{engagement_id}/report")
async def download_report_endpoint(engagement_id: str, request: Request):
    """Download the final PDF report."""
    from engagements import EngagementStatus, get_engagement

    engagement = get_engagement(engagement_id)
    if not engagement:
        raise HTTPException(status_code=404, detail="Engagement not found")

    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    if engagement["user_id"] != tenant_id and tenant_id == "anonymous":
        raise HTTPException(status_code=401, detail="Authentication required")

    if engagement["status"] not in (EngagementStatus.review, EngagementStatus.delivered):
        raise HTTPException(status_code=400, detail="Report not ready yet")

    report_path = engagement.get("report_path")
    if not report_path or not os.path.isfile(report_path):
        raise HTTPException(status_code=404, detail="Report file not found")

    from fastapi.responses import FileResponse

    return FileResponse(report_path, media_type="application/pdf", filename=f"{engagement['package']}-report.pdf")


@app.get("/api/admin/engagements/review")
async def admin_review_queue(request: Request):
    """List engagements awaiting human review (premium tier)."""
    from engagements import list_review_queue

    # Simple admin check — in production, use role-based auth
    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    if tenant_id == "anonymous":
        raise HTTPException(status_code=401, detail="Authentication required")

    return list_review_queue()


class DeliverEngagementRequest(BaseModel):
    reviewer_notes: str = ""


@app.post("/api/admin/engagements/{engagement_id}/deliver")
async def admin_deliver_engagement(engagement_id: str, req: DeliverEngagementRequest, request: Request):
    """Admin delivers a reviewed engagement to the client."""
    from engagements import deliver_engagement

    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    if tenant_id == "anonymous":
        raise HTTPException(status_code=401, detail="Authentication required")

    result = await deliver_engagement(engagement_id, tenant_id, req.reviewer_notes)
    if not result:
        raise HTTPException(status_code=404, detail="Engagement not found or not in review status")

    return result


# ─── File Upload (Any Agent) ─────────────────────────────────────────

# Agents that support file upload
UPLOAD_AGENTS = {
    "code-gremlin",
    "bug-hunter",
    "devops-dwarf",
    "test-goblin",
    "web-weaver",
    "mcp-maker",
    "data-sprite",
    "spreadsheet-sage",
    "cloud-sensei",
    "embeddings-agent",
    "pdf-forge",
}

# Max file size: 2MB for text, 20MB for multimodal
MAX_UPLOAD_SIZE_TEXT = 2 * 1024 * 1024
MAX_UPLOAD_SIZE_MULTIMODAL = 20 * 1024 * 1024

# File extensions that are multimodal (binary, not text)
MULTIMODAL_EXTENSIONS = {
    # Images
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".gif",
    # PDFs
    ".pdf",
    # Video
    ".mp4",
    # Audio
    ".mp3",
    ".wav",
    ".ogg",
    ".flac",
}


def _is_multimodal_file(filename: str) -> bool:
    """Check if a file is a multimodal (binary) format."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return f".{ext}" in MULTIMODAL_EXTENSIONS


def _get_mime_type(filename: str) -> str:
    """Infer MIME type from filename extension."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    mime_map = {
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "webp": "image/webp",
        "gif": "image/gif",
        "pdf": "application/pdf",
        "mp4": "video/mp4",
        "mp3": "audio/mpeg",
        "wav": "audio/wav",
        "ogg": "audio/ogg",
        "flac": "audio/flac",
    }
    return mime_map.get(ext, "application/octet-stream")


@app.post("/api/agents/{agent_id}/upload")
async def upload_for_agent(
    agent_id: str,
    file: UploadFile = File(...),
    task: str = Form("Analyze this file"),
    # Embeddings agent optional params
    provider: str = Form(""),
    model: str = Form(""),
    mode: str = Form(""),
    dimensions: int | None = Form(None),
    chunk_strategy: str = Form(""),
    output_format: str = Form(""),
    encoding_format: str = Form(""),
    input_type: str = Form(""),
    output_dtype: str = Form(""),
    task_type: str = Form(""),
):
    """Upload a file for any agent that supports it. Returns a job_id for polling.

    Supports both text and binary (multimodal) files. Multimodal files
    (images, PDFs, audio, video) are passed as raw bytes to the embeddings agent.
    """
    if agent_id not in AGENT_GRAPHS:
        return {"error": f"Unknown agent: {agent_id}"}, 404

    if agent_id not in UPLOAD_AGENTS:
        return {"error": f"Agent {agent_id} does not support file upload"}, 400

    content = await file.read()
    filename = file.filename or "upload.txt"
    is_multimodal = _is_multimodal_file(filename)

    # Size limits
    max_size = MAX_UPLOAD_SIZE_MULTIMODAL if is_multimodal else MAX_UPLOAD_SIZE_TEXT
    if len(content) > max_size:
        return {"error": f"File too large. Max {max_size // (1024 * 1024)}MB."}, 400

    # Multimodal files: only allowed for embeddings-agent with supported models
    if is_multimodal and agent_id != "embeddings-agent":
        return {"error": f"Binary files only supported for embeddings-agent. Got: {filename}"}, 400

    agent_name = AGENT_NAMES.get(agent_id, agent_id)
    job = create_job(agent_id, agent_name, task)

    # Build extra state
    extra: dict = {"file_name": filename}

    if is_multimodal:
        # Binary file → store as bytes, pass mime type
        import base64

        extra["file_bytes_b64"] = base64.b64encode(content).decode("ascii")
        extra["file_mime_type"] = _get_mime_type(filename)
        extra["file_content"] = f"[Binary file: {filename} ({len(content):,} bytes, {_get_mime_type(filename)})]"
        extra["multimodal"] = True
    else:
        # Text file
        try:
            file_text = content.decode("utf-8")
        except UnicodeDecodeError:
            return {"error": "File must be UTF-8 text (or use a supported binary format: images, PDF, video)"}, 400
        extra["file_content"] = file_text

    # Pass through embeddings agent params
    if provider:
        extra["provider"] = provider
    if model:
        extra["model"] = model
    if mode:
        extra["mode"] = mode
    if dimensions is not None:
        extra["dimensions"] = dimensions
    if chunk_strategy:
        extra["chunk_strategy"] = chunk_strategy
    if output_format:
        extra["output_format"] = output_format
    if encoding_format:
        extra["encoding_format"] = encoding_format
    if input_type:
        extra["input_type"] = input_type
    if output_dtype:
        extra["output_dtype"] = output_dtype
    if task_type:
        extra["task_type"] = task_type

    from job_runner import run_job_with_extra

    task = asyncio.create_task(run_job_with_extra(job["job_id"], **extra))
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)

    return {"job_id": job["job_id"], "status": job["status"]}


# ─── Batch Polling (Embeddings Agent) ──────────────────────────────────


@app.get("/api/agents/embeddings-agent/batch/{batch_id}")
async def poll_embeddings_batch(batch_id: str, provider: str = "openai"):
    """Poll the status of an embeddings batch job."""
    from agents.embeddings.batch import poll_batch

    try:
        result = poll_batch(provider, batch_id)
        return result
    except Exception as e:
        return {"error": str(e), "batch_id": batch_id, "provider": provider}


@app.get("/api/agents/embeddings-agent/batch/{batch_id}/download")
async def download_embeddings_batch(batch_id: str, provider: str = "openai"):
    """Download completed batch results."""
    from agents.embeddings.batch import download_batch

    try:
        results = download_batch(provider, batch_id)
        return {"batch_id": batch_id, "provider": provider, "results": results}
    except Exception as e:
        return {"error": str(e), "batch_id": batch_id, "provider": provider}


# ─── Script Marketplace ────────────────────────────────────────────────

from scripts import (
    get_script as _get_script,
)
from scripts import (
    list_scripts as _list_scripts,
)
from scripts import (
    validate_and_register as _validate_and_register,
)


class ScriptRegisterRequest(BaseModel):
    name: str
    description: str
    creator: str = "anonymous"
    code: str
    packages: list[str] = []
    price: float = 0.05
    input_schema: str = "Any text input"
    # Optional: creator-provided test data (auto-generated by LLM if not provided)
    sample_input: str | None = None
    expected_output: str | None = None
    test_code: str | None = None
    # Dry run: validate without registering (for CLI validate command)
    dry_run: bool = False


@app.post("/api/scripts")
async def register_script(req: ScriptRegisterRequest):
    """Register a new script with security validation.

    Flow:
    - Runs 7-layer validation pipeline
    - If REJECTED by automation → instant reject, user notified
    - If passes validation → status = "pending", admin notified
    - Vending code assigned only when admin approves
    """
    import uuid as uuid_mod

    from notifications import notify_script_auto_rejected, notify_script_submitted
    from scripts import list_scripts

    # Dedup check — reject if script name already exists
    existing = [s for s in list_scripts(include_rejected=True) if s["name"].lower() == req.name.strip().lower()]
    if existing:
        raise HTTPException(status_code=409, detail=f"A script named '{req.name}' already exists.")

    script = await _validate_and_register(
        name=req.name,
        description=req.description,
        creator=req.creator,
        code=req.code,
        packages=req.packages,
        price=req.price,
        input_schema=req.input_schema,
        sample_input=req.sample_input,
        expected_output=req.expected_output,
        test_code=req.test_code,
    )

    # Generate submission ID for tracking
    submission_id = f"SUB-{uuid_mod.uuid4().hex[:8].upper()}"
    script["submission_id"] = submission_id

    if script.get("validation_status") == "rejected":
        # Auto-rejected by validation pipeline — notify user immediately
        notify_script_auto_rejected(req.creator, req.name, script.get("script_id", ""))
    else:
        # Passed automated checks — set to pending for admin review
        script["validation_status"] = "pending"
        # Don't assign vending code yet — that happens on admin approval
        notify_script_submitted(req.creator, req.name, script.get("script_id", ""), submission_id)

    return script


@app.post("/api/scripts/validate-stream")
async def validate_script_stream(req: ScriptRegisterRequest):
    """Register a script with SSE-streamed validation progress.

    Streams layer-by-layer results as Server-Sent Events, then returns
    the final script with submission ID on completion.
    """
    import json as json_mod

    from starlette.responses import StreamingResponse

    from scripts import list_scripts

    # Check if script with same name already exists
    existing = [s for s in list_scripts(include_rejected=True) if s["name"].lower() == req.name.strip().lower()]
    existing_script = None
    if existing:
        ex = existing[0]
        # Same creator → version update; different creator → reject
        if ex.get("creator", "").lower() != req.creator.strip().lower():
            raise HTTPException(
                status_code=409, detail=f"A script named '{req.name}' already exists (different creator)."
            )
        existing_script = ex

    async def event_stream():
        """Run validation layers and yield SSE events.

        Wrapped in try/except so the frontend ALWAYS receives a completion
        event, even if a layer crashes (e.g. missing E2B_API_KEY).
        """
        import os
        import uuid as uuid_mod

        from notifications import notify_script_auto_rejected, notify_script_submitted
        from scripts import register_script as _register

        def sse(data):
            return f"data: {json_mod.dumps(data)}\n\n"

        all_findings = []
        all_cves = []
        risk_score = 0.0
        func_summary: dict = {}
        qual_summary: dict = {}
        rel_summary: dict = {}

        has_e2b = bool(os.environ.get("E2B_API_KEY"))
        has_llm = bool(os.environ.get("OPENROUTER_API_KEY"))

        try:
            from guards.script_quality import run_quality_layers
            from guards.script_validator import (
                _build_report,
                _calculate_risk_score,
                _layer1_static,
                _layer2_deps,
                _layer3_probe,
                _layer4_llm,
            )

            # Layer 1: Static Analysis
            yield sse({"layer": 0, "name": "Static Analysis", "status": "running"})
            layer1 = _layer1_static(req.code)
            all_findings.extend(layer1)
            yield sse(
                {
                    "layer": 0,
                    "name": "Static Analysis",
                    "status": "passed" if not layer1 else "complete",
                    "findings": len(layer1),
                }
            )

            # Layer 2: Dependency Audit
            yield sse({"layer": 1, "name": "Dependency Audit", "status": "running"})
            layer2_findings, cves = await _layer2_deps(req.packages)
            all_findings.extend(layer2_findings)
            all_cves = cves
            yield sse(
                {
                    "layer": 1,
                    "name": "Dependency Audit",
                    "status": "passed" if not layer2_findings else "complete",
                    "findings": len(layer2_findings),
                    "packages": req.packages[:5],
                }
            )

            # Layer 3: Sandbox Probe (requires E2B)
            if has_e2b:
                yield sse({"layer": 2, "name": "Sandbox Probe", "status": "running"})
                layer3 = await _layer3_probe(req.code, req.packages)
                all_findings.extend(layer3)
                yield sse(
                    {
                        "layer": 2,
                        "name": "Sandbox Probe",
                        "status": "passed" if not layer3 else "complete",
                        "findings": len(layer3),
                    }
                )
            else:
                yield sse({"layer": 2, "name": "Sandbox Probe", "status": "skipped"})

            # Calculate risk score
            risk_score = _calculate_risk_score(all_findings)

            # Layer 4: LLM Review (requires OpenRouter)
            if has_llm and 0.25 <= risk_score <= 0.75:
                yield sse({"layer": 3, "name": "LLM Review", "status": "running"})
                layer4 = await _layer4_llm(req.code, req.description, all_findings)
                all_findings.extend(layer4)
                risk_score = _calculate_risk_score(all_findings)
                yield sse({"layer": 3, "name": "LLM Review", "status": "complete", "findings": len(layer4)})
            else:
                yield sse({"layer": 3, "name": "LLM Review", "status": "skipped"})

            # Layers 5-7: Quality (requires E2B for sandbox execution)
            if has_e2b:
                layer_names = {4: "Functionality Test", 5: "Code Quality", 6: "Reliability Test"}
                progress_queue: asyncio.Queue = asyncio.Queue()

                def on_quality_progress(layer_idx: int, status: str) -> None:
                    progress_queue.put_nowait(
                        {"layer": layer_idx, "name": layer_names.get(layer_idx, ""), "status": status}
                    )

                quality_task = asyncio.create_task(
                    run_quality_layers(
                        code=req.code,
                        packages=req.packages,
                        description=req.description,
                        input_schema=req.input_schema,
                        sample_input=req.sample_input,
                        expected_output=req.expected_output,
                        test_code=req.test_code,
                        on_layer_progress=on_quality_progress,
                    )
                )

                while not quality_task.done():
                    try:
                        event = await asyncio.wait_for(progress_queue.get(), timeout=1.0)
                        yield sse(event)
                    except TimeoutError:
                        pass

                while not progress_queue.empty():
                    yield sse(progress_queue.get_nowait())

                quality_findings, func_summary, qual_summary, rel_summary = quality_task.result()
                all_findings.extend(quality_findings)
            else:
                # Skip quality layers when E2B unavailable
                yield sse({"layer": 4, "name": "Functionality Test", "status": "skipped"})
                yield sse({"layer": 5, "name": "Code Quality", "status": "skipped"})
                yield sse({"layer": 6, "name": "Reliability Test", "status": "skipped"})

        except Exception as e:
            logger.exception("validate-stream pipeline error: %s", e)
            # Even on crash, fall through to register the script

        # Build final report (always runs)
        try:
            from guards.script_validator import _build_report

            report = _build_report(all_findings, all_cves, risk_score)
            report.functionality_summary = func_summary
            report.quality_summary = qual_summary
            report.reliability_summary = rel_summary
            verdict = report.verdict
            report_dict = report.to_dict()
        except Exception:
            verdict = "APPROVED"  # Default to pending review if report building fails
            report_dict = {"verdict": verdict, "riskScore": risk_score, "findings": []}

        # Register or update script (always runs)
        if existing_script:
            # Version update — increment version on existing script
            import hashlib as _hashlib

            new_hash = _hashlib.sha256(req.code.encode()).hexdigest()[:12]
            new_version = existing_script["version"] + 1
            existing_script["code"] = req.code
            existing_script["code_hash"] = new_hash
            existing_script["version"] = new_version
            existing_script["description"] = req.description
            existing_script["packages"] = req.packages
            existing_script["input_schema"] = req.input_schema
            existing_script["validation_report"] = report_dict
            existing_script["versions"].append(
                {
                    "version": new_version,
                    "code_hash": new_hash,
                    "created_at": time.time(),
                    "validation_status": "pending" if verdict != "REJECTED" else "rejected",
                }
            )
            script = existing_script
        else:
            # New script
            script = _register(
                name=req.name,
                description=req.description,
                creator=req.creator,
                code=req.code,
                packages=req.packages,
                price=req.price,
                input_schema=req.input_schema,
            )
            script["validation_report"] = report_dict

        submission_id = f"SUB-{uuid_mod.uuid4().hex[:8].upper()}"
        script["submission_id"] = submission_id

        if verdict == "REJECTED":
            script["validation_status"] = "rejected"
            notify_script_auto_rejected(req.creator, req.name, script.get("script_id", ""))

            yield sse(
                {
                    "layer": -1,
                    "status": "complete",
                    "validation_status": "rejected",
                    "script_id": script.get("script_id"),
                    "submission_id": submission_id,
                    "vending_code": "",
                }
            )
        else:
            # Passed validation — set to pending for admin review
            script["validation_status"] = "pending"
            script["vending_code"] = "PENDING"
            notify_script_submitted(req.creator, req.name, script.get("script_id", ""), submission_id)

            yield sse(
                {
                    "layer": -1,
                    "status": "complete",
                    "validation_status": "pending",
                    "script_id": script.get("script_id"),
                    "submission_id": submission_id,
                    "vending_code": "PENDING",
                }
            )

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@app.get("/api/scripts")
async def list_all_scripts():
    """List all marketplace scripts (approved and flagged only)."""
    return [{k: v for k, v in s.items() if k not in ("code", "validation_report")} for s in _list_scripts()]


@app.get("/api/creator/dashboard")
async def get_creator_dashboard(creator: str = "platform"):
    """Aggregate creator stats and script details for the dashboard."""
    scripts = [s for s in _list_scripts(include_rejected=True) if s.get("creator") == creator]
    total_scripts = len(scripts)
    total_runs = sum(s.get("runs", 0) for s in scripts)
    total_revenue = round(sum(float(s.get("revenue", 0)) for s in scripts), 6)

    def _script_summary(script: dict) -> dict:
        return {
            "script_id": script["script_id"],
            "name": script["name"],
            "vending_code": script.get("vending_code", ""),
            "runs": script.get("runs", 0),
            "revenue": float(script.get("revenue", 0)),
            "price": float(script.get("price", 0)),
            "validation_status": script.get("validation_status", "unknown"),
            "validation_report": script.get("validation_report", {}),
            "last_run_at": script.get("last_run_at"),
            "created_at": script.get("created_at"),
        }

    summaries = [_script_summary(s) for s in scripts]
    top_script = None
    if summaries:
        top_script = max(
            summaries,
            key=lambda s: (s.get("revenue", 0), s.get("runs", 0)),
        )

    avg_runs = total_runs / total_scripts if total_scripts else 0
    avg_revenue = total_revenue / total_scripts if total_scripts else 0

    return {
        "creator": creator,
        "totals": {
            "scripts": total_scripts,
            "runs": total_runs,
            "revenue": total_revenue,
        },
        "summary": {
            "top_script": top_script,
            "avg_runs": avg_runs,
            "avg_revenue": avg_revenue,
        },
        "scripts": summaries,
    }


@app.get("/api/scripts/hashes")
async def get_script_hashes():
    """All approved script hashes for the verify page."""
    return [
        {
            "vending_code": s["vending_code"],
            "name": s["name"],
            "version": s.get("version", 1),
            "code_hash": s.get("code_hash", ""),
            "validation_status": s.get("validation_status", "unknown"),
        }
        for s in _list_scripts()
        if s.get("validation_status") in ("approved", "flagged")
    ]


@app.get("/api/scripts/mine")
async def get_my_scripts(request: Request):
    """Get scripts owned by the authenticated user."""
    from auth import get_current_user

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    user = await get_current_user(authorization=authorization, x_api_key=x_api_key)
    user_id = user.get("id", "")
    email = user.get("email", "")

    # Match by creator_user_id (Supabase) or creator email (in-memory fallback)
    results = []
    for s in _list_scripts(include_rejected=True):
        if s.get("creator_user_id") == user_id or s.get("creator") == email:
            results.append(s)
    return results


@app.get("/api/scripts/{script_id}")
async def get_script_detail(script_id: str):
    """Get script details (without code or full validation report)."""
    script = _get_script(script_id)
    if not script:
        return {"error": f"Script not found: {script_id}"}, 404
    return {k: v for k, v in script.items() if k not in ("code", "validation_report")}


@app.get("/api/scripts/{script_id}/validation")
async def get_script_validation(script_id: str):
    """Get the full security compliance report for a script."""
    script = _get_script(script_id)
    if not script:
        return {"error": f"Script not found: {script_id}"}, 404
    return {
        "script_id": script_id,
        "name": script["name"],
        "validation_status": script.get("validation_status", "unknown"),
        "report": script.get("validation_report", {}),
    }


@app.post("/api/scripts/{script_id}/run")
async def run_marketplace_script(
    script_id: str,
    user_input: str = Form("", alias="input"),
    input_file: UploadFile | None = None,
):
    """Run a marketplace script. Returns a job_id for polling."""
    script = _get_script(script_id)
    if not script:
        return {"error": f"Script not found: {script_id}"}, 404

    # Build user input from form field or uploaded file
    if input_file:
        content = await input_file.read()
        try:
            user_input = content.decode("utf-8")
        except UnicodeDecodeError:
            return {"error": "Input file must be UTF-8 text"}, 400

    job = create_job(script_id, script["name"], user_input[:200])

    from script_runner import run_script_job

    task = asyncio.create_task(run_script_job(job["job_id"], script_id, user_input))
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)

    return {"job_id": job["job_id"], "status": job["status"], "script": script["name"], "price": script["price"]}


@app.get("/api/scripts/{script_id}/stats")
async def get_script_stats(script_id: str):
    """Get execution stats for a script (creator view)."""
    script = _get_script(script_id)
    if not script:
        return {"error": f"Script not found: {script_id}"}, 404
    return {
        "script_id": script_id,
        "name": script["name"],
        "creator": script["creator"],
        "runs": script["runs"],
        "revenue": script["revenue"],
        "price": script["price"],
    }


# ---------------------------------------------------------------------------
# Script lookup by vending code (for CLI)
# ---------------------------------------------------------------------------


@app.get("/api/scripts/by-code/{vending_code}")
async def get_script_by_code(vending_code: str):
    """Look up a script by its vending code (S-XXXX). Used by the CLI for stats."""
    from scripts import get_script_by_vending_code

    script = get_script_by_vending_code(vending_code)
    if not script:
        return {"error": f"Script not found: {vending_code}"}
    return {k: v for k, v in script.items() if k not in ("code", "validation_report")}


# ---------------------------------------------------------------------------
# Credit system endpoints
# ---------------------------------------------------------------------------


@app.post("/api/keys")
async def create_api_key():
    """Generate a new API key with free tier credits (500/month)."""
    from credits import generate_key

    account = generate_key()
    return {
        "key": account["key"],
        "tier": account["tier"],
        "balance": account["balance"],
        "monthly_allowance": account["monthly_allowance"],
    }


# ---------------------------------------------------------------------------
# Portal endpoints
# ---------------------------------------------------------------------------


@app.post("/api/scripts/{script_id}/pr")
async def create_script_pr(script_id: str, request: Request):
    """Create a GitHub PR for an approved script."""
    import httpx

    from auth import get_current_user

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    await get_current_user(authorization=authorization, x_api_key=x_api_key)

    script = _get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail=f"Script not found: {script_id}")
    if script.get("validation_status") != "approved":
        raise HTTPException(status_code=400, detail="Only approved scripts can create PRs")

    github_token = os.environ.get("GITHUB_TOKEN")
    if not github_token:
        raise HTTPException(status_code=500, detail="GITHUB_TOKEN not configured on server")

    repo = "YokiiDesu/Vending-Machine"
    branch_name = f"scripts/{script['vending_code']}-v{script.get('version', 1)}"
    file_path = f"marketplace-scripts/{script['vending_code']}.py"

    headers = {
        "Authorization": f"token {github_token}",
        "Accept": "application/vnd.github.v3+json",
    }

    async with httpx.AsyncClient() as client:
        # Get main branch SHA
        ref_resp = await client.get(f"https://api.github.com/repos/{repo}/git/ref/heads/main", headers=headers)
        if ref_resp.status_code != 200:
            raise HTTPException(status_code=502, detail="Failed to get main branch ref")
        main_sha = ref_resp.json()["object"]["sha"]

        # Create branch
        branch_resp = await client.post(
            f"https://api.github.com/repos/{repo}/git/refs",
            headers=headers,
            json={"ref": f"refs/heads/{branch_name}", "sha": main_sha},
        )
        if branch_resp.status_code not in (201, 422):  # 422 = branch exists
            raise HTTPException(status_code=502, detail="Failed to create branch")

        # Add script file
        import base64

        encoded_code = base64.b64encode(script.get("code", "").encode()).decode()
        file_resp = await client.put(
            f"https://api.github.com/repos/{repo}/contents/{file_path}",
            headers=headers,
            json={
                "message": f"Add marketplace script {script['vending_code']}: {script['name']}",
                "content": encoded_code,
                "branch": branch_name,
            },
        )
        if file_resp.status_code not in (201, 200):
            raise HTTPException(status_code=502, detail="Failed to add script file")

        # Create PR
        pr_body = (
            f"## {script['name']} ({script['vending_code']})\n\n"
            f"**Creator:** {script.get('creator', 'unknown')}\n"
            f"**Description:** {script.get('description', '')}\n"
            f"**Version:** {script.get('version', 1)}\n"
            f"**Hash:** `{script.get('code_hash', '')}`\n"
            f"**Validation:** {script.get('validation_status', 'unknown')}\n"
            f"**Risk Score:** {script.get('validation_report', {}).get('risk_score', 'N/A')}\n"
        )
        pr_resp = await client.post(
            f"https://api.github.com/repos/{repo}/pulls",
            headers=headers,
            json={
                "title": f"[Script] {script['vending_code']}: {script['name']}",
                "body": pr_body,
                "head": branch_name,
                "base": "main",
            },
        )
        if pr_resp.status_code != 201:
            raise HTTPException(status_code=502, detail=f"Failed to create PR: {pr_resp.text}")

        pr_data = pr_resp.json()
        return {"pr_url": pr_data["html_url"], "pr_number": pr_data["number"]}


async def _require_admin(request: Request) -> dict:
    """Require admin auth — checks is_admin flag in Supabase profiles table."""
    from auth import get_current_user

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    user = await get_current_user(authorization=authorization, x_api_key=x_api_key)
    user_id = user.get("id", "")

    if not user_id or user_id == "anonymous":
        raise HTTPException(status_code=401, detail="Authentication required")

    # Check is_admin in profiles table
    try:
        from supabase_client import get_supabase, is_available

        if is_available():
            sb = get_supabase()
            result = sb.table("profiles").select("is_admin").eq("id", user_id).single().execute()
            if result.data and result.data.get("is_admin"):
                return user
    except Exception:
        logger.debug("Failed to check admin status for user %s", user_id)

    raise HTTPException(status_code=403, detail="Admin access required")


@app.get("/api/admin/scripts")
async def admin_list_scripts(request: Request):
    """List ALL scripts including rejected/pending (admin only)."""
    await _require_admin(request)
    from scripts import list_scripts

    return list_scripts(include_rejected=True)


@app.post("/api/admin/scripts/{script_id}/approve")
async def admin_approve_script(script_id: str, request: Request):
    """Approve a pending script — assigns vending code and notifies creator."""
    await _require_admin(request)
    script = _get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    from notifications import notify_script_approved

    script["validation_status"] = "approved"

    # Assign vending code NOW (not at submission time)
    if not script.get("vending_code") or script["vending_code"] == "PENDING":
        try:
            from graph import generate_vending_code

            script["vending_code"] = generate_vending_code()
        except Exception:
            import uuid as uuid_mod

            script["vending_code"] = f"S-{uuid_mod.uuid4().hex[:4].upper()}"

    try:
        from scripts import _sync_script_to_db

        _sync_script_to_db(script)
    except Exception:
        logger.debug("Failed to sync script %s to database", script_id)

    try:
        from graph import embed_script, is_available, sync_script_to_graph

        if is_available():
            script_dict: dict = dict(script)
            embedding = embed_script(script_dict)
            sync_script_to_graph(script_dict, embedding=embedding)
    except Exception:
        logger.debug("Failed to sync script %s to graph index", script_id)

    # Notify creator
    notify_script_approved(
        creator_email=script.get("creator", ""),
        script_name=script.get("name", ""),
        script_id=script_id,
        vending_code=script.get("vending_code", ""),
    )

    return {
        "script_id": script_id,
        "status": "approved",
        "vending_code": script.get("vending_code"),
    }


@app.post("/api/admin/scripts/{script_id}/reject")
async def admin_reject_script(script_id: str, request: Request):
    """Reject a script and notify creator."""
    await _require_admin(request)
    script = _get_script(script_id)
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    from notifications import notify_script_rejected

    script["validation_status"] = "rejected"

    try:
        from scripts import _sync_script_to_db

        _sync_script_to_db(script)
    except Exception:
        logger.debug("Failed to sync script %s to database", script_id)

    notify_script_rejected(
        creator_email=script.get("creator", ""),
        script_name=script.get("name", ""),
        script_id=script_id,
    )

    return {"script_id": script_id, "status": "rejected"}


@app.get("/api/notifications")
async def get_user_notifications(request: Request):
    """Get notifications for the authenticated user."""
    from auth import get_current_user
    from notifications import get_notifications

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    user = await get_current_user(authorization=authorization, x_api_key=x_api_key)
    email = user.get("email", "")
    if not email or email == "anonymous":
        return []
    return get_notifications(email)


@app.post("/api/notifications/test-approval")
async def test_approval_notification(request: Request):
    """DEV ONLY: Create a fake approval notification for testing the celebration overlay."""
    from notifications import notify_script_approved

    body = await request.json()
    notify_script_approved(
        creator_email=body.get("email", "yokiidesu@gmail.com"),
        script_name=body.get("name", "test-script"),
        script_id=body.get("script_id", "test-id"),
        vending_code=body.get("vending_code", "S-TEST"),
    )
    return {"status": "ok", "message": "Test approval notification created"}


@app.post("/api/notifications/{notification_id}/read")
async def mark_notification_read(notification_id: str, request: Request):
    """Mark a notification as read."""
    from auth import get_current_user
    from notifications import mark_read

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    await get_current_user(authorization=authorization, x_api_key=x_api_key)
    mark_read(notification_id)
    return {"status": "ok"}


@app.post("/api/notifications/read-all")
async def mark_all_notifications_read(request: Request):
    """Mark all notifications as read for the authenticated user."""
    from auth import get_current_user
    from notifications import mark_all_read

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    user = await get_current_user(authorization=authorization, x_api_key=x_api_key)
    mark_all_read(user.get("email", ""))
    return {"status": "ok"}


# ─── Profile Preferences ────────────────────────────────────────────────


@app.get("/api/profile/prefs")
async def get_profile_prefs(request: Request):
    """Get notification preferences for the authenticated user."""
    from auth import get_current_user

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    user = await get_current_user(authorization=authorization, x_api_key=x_api_key)
    user_id = user.get("id", "")

    try:
        from supabase_client import get_supabase

        sb = get_supabase()
        result = sb.table("profiles").select("notification_prefs").eq("id", user_id).single().execute()
        return (
            {"notification_prefs": result.data.get("notification_prefs") or {}}
            if result.data
            else {"notification_prefs": {}}
        )
    except Exception:
        return {"notification_prefs": {}}


@app.put("/api/profile/prefs")
async def update_profile_prefs(request: Request):
    """Update notification preferences for the authenticated user."""
    from auth import get_current_user

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    user = await get_current_user(authorization=authorization, x_api_key=x_api_key)
    user_id = user.get("id", "")

    body = await request.json()
    prefs = body.get("notification_prefs", {})

    try:
        from supabase_client import get_supabase

        sb = get_supabase()
        sb.table("profiles").update({"notification_prefs": prefs}).eq("id", user_id).execute()
        return {"status": "ok"}
    except Exception as e:
        logger.warning("Failed to update prefs: %s", e)
        return {"status": "ok"}  # Graceful — don't fail the UI


@app.get("/api/agents")
async def list_portal_agents():
    """List all agents for the portal directory.

    Only returns the 13 agents that are actively supported in the MCP server.
    Removed agents: research-owl, info-scout, fridge-chef, spreadsheet-sage, web-weaver.
    """
    from agents.llm import MODELS
    from agents.registry import AGENT_NAMES

    # Agents removed from the public MCP server (PR #22)
    removed = {"research-owl", "info-scout", "fridge-chef", "spreadsheet-sage", "web-weaver", "ceo-agent"}

    agents = []
    for agent_id, agent_name in sorted(AGENT_NAMES.items()):
        if agent_id in removed:
            continue
        model_info = MODELS.get(agent_id)
        model_id = model_info[0] if model_info else "unknown"
        agents.append(
            {
                "id": agent_id,
                "name": agent_name,
                "model": model_id,
            }
        )
    return agents


@app.get("/api/credits/me")
async def get_my_balance(request: Request):
    """Get credit balance for the authenticated user."""
    from auth import get_current_user
    from credits import get_balance

    authorization = request.headers.get("authorization")
    x_api_key = request.headers.get("x-api-key")
    user = await get_current_user(authorization=authorization, x_api_key=x_api_key)
    return get_balance(user["id"])


@app.get("/api/keys/{key}/balance")
async def get_key_balance(key: str):
    """Check credit balance and tier info."""
    from credits import get_balance

    return get_balance(key)


@app.get("/api/keys/{key}/ledger")
async def get_key_ledger(key: str, limit: int = 20):
    """Get recent credit transaction history."""
    from credits import get_ledger

    return get_ledger(key, limit=limit)


# ─── Dev Agent (Autonomous Claude Code in Daytona) ──────────────────────

# In-memory store for active dev agent jobs
_DEV_AGENT_JOBS: dict[str, dict] = {}


class DevTaskRequest(BaseModel):
    repo: str = "YokiiDesu/Vending-Machine"
    task: str
    agent: str = "claude"  # "claude" or "codex"
    branch: str | None = None


@app.post("/api/dev-agent/task")
async def submit_dev_task(req: DevTaskRequest):
    """Submit a task to an autonomous dev agent.

    Creates a persistent Daytona sandbox with the selected coding agent,
    clones the repo, runs the task, and creates a PR.

    Agents: "claude" (Claude Code CLI), "codex" (OpenAI Codex CLI)
    """
    import uuid as uuid_mod

    from dev_agent import AGENT_CONFIGS, run_dev_task_async

    if req.agent not in AGENT_CONFIGS:
        raise HTTPException(
            status_code=400, detail=f"Unknown agent: {req.agent}. Available: {list(AGENT_CONFIGS.keys())}"
        )

    job_id = str(uuid_mod.uuid4())[:8]
    _DEV_AGENT_JOBS[job_id] = {
        "status": "running",
        "task": req.task,
        "repo": req.repo,
        "agent": req.agent,
        "agent_name": AGENT_CONFIGS[req.agent]["name"],
        "branch": req.branch,
        "started_at": time.time(),
        "result": None,
    }

    async def _run():
        try:
            result = await run_dev_task_async(
                repo=req.repo,
                task=req.task,
                agent=req.agent,
                branch=req.branch,
            )
            _DEV_AGENT_JOBS[job_id]["status"] = result.get("status", "complete")
            _DEV_AGENT_JOBS[job_id]["result"] = result
        except Exception as e:
            logger.exception("Dev agent task failed: %s", e)
            _DEV_AGENT_JOBS[job_id]["status"] = "error"
            _DEV_AGENT_JOBS[job_id]["result"] = {"error": str(e)}

    task_ref = asyncio.create_task(_run())
    _DEV_AGENT_JOBS[job_id]["_task"] = task_ref

    return {"job_id": job_id, "status": "running", "agent": req.agent, "task": req.task}


@app.get("/api/dev-agent/agents")
async def list_dev_agents():
    """List available coding agents for the dev agent sandbox."""
    from dev_agent import AGENT_CONFIGS

    return [
        {"id": agent_id, "name": config["name"], "api_key_env": config["api_key_env"]}
        for agent_id, config in AGENT_CONFIGS.items()
    ]


@app.get("/api/dev-agent/task/{job_id}")
async def get_dev_task_status(job_id: str):
    """Poll the status of a dev agent task."""
    job = _DEV_AGENT_JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/api/dev-agent/jobs")
async def list_dev_agent_jobs():
    """List all dev agent jobs."""
    return [{"job_id": k, **v} for k, v in _DEV_AGENT_JOBS.items()]


# ─── API Key Management ──────────────────────────────────────────────────


class CreateKeyRequest(BaseModel):
    name: str = "default"


@app.post("/api/auth/keys")
async def create_api_key_endpoint(req: CreateKeyRequest, request: Request):
    """Create a new API key. Returns plaintext key ONCE."""
    from auth import create_api_key, require_auth

    authorization = request.headers.get("authorization")
    user = await require_auth(authorization=authorization)

    result = create_api_key(user["id"], req.name)
    if not result:
        raise HTTPException(status_code=500, detail="Failed to create API key")

    from audit import log_action

    log_action(
        tenant_id=user["id"],
        action="auth.key_create",
        resource_type="api_key",
        resource_id=result["key_id"],
        metadata={"name": req.name},
        request_id=getattr(request.state, "request_id", ""),
    )

    return result


@app.get("/api/auth/keys")
async def list_api_keys_endpoint(request: Request):
    """List API keys for the authenticated user (masked, no plaintext)."""
    from auth import list_api_keys, require_auth

    authorization = request.headers.get("authorization")
    user = await require_auth(authorization=authorization)
    return list_api_keys(user["id"])


@app.delete("/api/auth/keys/{key_id}")
async def revoke_api_key_endpoint(key_id: str, request: Request):
    """Revoke an API key."""
    from auth import require_auth, revoke_api_key

    authorization = request.headers.get("authorization")
    user = await require_auth(authorization=authorization)
    success = revoke_api_key(user["id"], key_id)
    if not success:
        raise HTTPException(status_code=404, detail="Key not found or already revoked")

    from audit import log_action

    log_action(
        tenant_id=user["id"],
        action="auth.key_revoke",
        resource_type="api_key",
        resource_id=key_id,
        request_id=getattr(request.state, "request_id", ""),
    )

    return {"status": "revoked", "key_id": key_id}


# ─── Audit Trail ─────────────────────────────────────────────────────────


@app.get("/api/audit")
async def get_audit_log_endpoint(request: Request, resource_type: str | None = None, limit: int = 50):
    """Query the audit log (admin only)."""
    from audit import get_audit_log

    await _require_admin(request)
    return get_audit_log(resource_type=resource_type, limit=limit)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)  # noqa: S104 — dev server, bind all interfaces
