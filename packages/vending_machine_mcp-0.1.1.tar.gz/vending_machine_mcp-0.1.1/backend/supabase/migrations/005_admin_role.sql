-- Add admin role to profiles
-- Run after 004_notifications.sql

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT FALSE;

-- To grant admin access, run:
-- UPDATE profiles SET is_admin = TRUE WHERE id = '<your-user-uuid>';
