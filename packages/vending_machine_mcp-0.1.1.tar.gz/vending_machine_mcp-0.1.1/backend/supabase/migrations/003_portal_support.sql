-- Portal support: PR tracking + realtime
-- Run after 002_user_profiles.sql

-- Track GitHub PR URLs on scripts
ALTER TABLE scripts
  ADD COLUMN IF NOT EXISTS pr_url TEXT,
  ADD COLUMN IF NOT EXISTS pr_number INT;

-- Enable realtime on scripts table for validation progress streaming
ALTER PUBLICATION supabase_realtime ADD TABLE scripts;
