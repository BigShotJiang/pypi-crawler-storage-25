-- Vending Machine Marketplace — Initial Schema
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New Query)

-- ============================================================
-- Credit Accounts (1 per user)
-- ============================================================
CREATE TABLE credit_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  tier TEXT NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'pro')),
  balance INT NOT NULL DEFAULT 500,
  monthly_allowance INT NOT NULL DEFAULT 500,
  last_refill TEXT NOT NULL DEFAULT to_char(NOW(), 'YYYY-MM'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Credit Transactions (ledger)
CREATE TABLE credit_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID REFERENCES credit_accounts(id) ON DELETE CASCADE,
  action TEXT NOT NULL CHECK (action IN ('deposit', 'withdrawal')),
  amount INT NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  balance_after INT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_transactions_account ON credit_transactions(account_id, created_at DESC);

-- ============================================================
-- Scripts (marketplace)
-- ============================================================
CREATE TABLE scripts (
  id TEXT PRIMARY KEY,
  vending_code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  creator TEXT NOT NULL DEFAULT 'anonymous',
  creator_user_id UUID REFERENCES auth.users(id),
  code TEXT NOT NULL,
  packages JSONB NOT NULL DEFAULT '[]',
  price NUMERIC(10,4) NOT NULL DEFAULT 0.05,
  input_schema TEXT NOT NULL DEFAULT 'Any text input',
  runs INT NOT NULL DEFAULT 0,
  revenue NUMERIC(10,6) NOT NULL DEFAULT 0,
  validation_status TEXT NOT NULL DEFAULT 'pending'
    CHECK (validation_status IN ('pending', 'approved', 'flagged', 'rejected')),
  validation_report JSONB NOT NULL DEFAULT '{}',
  version INT NOT NULL DEFAULT 1,
  code_hash TEXT NOT NULL,
  versions JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_scripts_vending_code ON scripts(vending_code);
CREATE INDEX idx_scripts_status ON scripts(validation_status);

-- ============================================================
-- Jobs (agent executions)
-- ============================================================
CREATE TABLE jobs (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  agent_name TEXT NOT NULL,
  task TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued', 'running', 'complete', 'error')),
  output TEXT NOT NULL DEFAULT '',
  error TEXT,
  steps JSONB NOT NULL DEFAULT '[]',
  metadata JSONB,
  user_id UUID REFERENCES auth.users(id),
  source TEXT NOT NULL DEFAULT 'web' CHECK (source IN ('web', 'mcp', 'ceo', 'workflow')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ
);
CREATE INDEX idx_jobs_status ON jobs(status, created_at DESC);
CREATE INDEX idx_jobs_user ON jobs(user_id, created_at DESC);

-- ============================================================
-- Webhooks
-- ============================================================
CREATE TABLE webhooks (
  id TEXT PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  events JSONB NOT NULL DEFAULT '[]',
  secret_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Webhook Deliveries
CREATE TABLE webhook_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  webhook_id TEXT REFERENCES webhooks(id) ON DELETE CASCADE,
  event TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('success', 'failed')),
  attempts INT NOT NULL DEFAULT 1,
  response_code INT,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_deliveries_webhook ON webhook_deliveries(webhook_id, created_at DESC);

-- ============================================================
-- Row Level Security
-- ============================================================
ALTER TABLE credit_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE credit_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE scripts ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhooks ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_deliveries ENABLE ROW LEVEL SECURITY;

-- Credits: users see only their own
CREATE POLICY "users_own_credits" ON credit_accounts
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "users_own_transactions" ON credit_transactions
  FOR ALL USING (
    account_id IN (SELECT id FROM credit_accounts WHERE user_id = auth.uid())
  );

-- Scripts: anyone can read approved, creators manage their own
CREATE POLICY "anyone_reads_approved_scripts" ON scripts
  FOR SELECT USING (validation_status IN ('approved', 'flagged'));

CREATE POLICY "creators_manage_scripts" ON scripts
  FOR ALL USING (creator_user_id = auth.uid());

-- Service role can manage all scripts (for seeding + validation)
CREATE POLICY "service_role_all_scripts" ON scripts
  FOR ALL USING (auth.role() = 'service_role');

-- Jobs: users see their own, service role sees all
CREATE POLICY "users_own_jobs" ON jobs
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "service_role_all_jobs" ON jobs
  FOR ALL USING (auth.role() = 'service_role');

-- Webhooks: users manage their own
CREATE POLICY "users_own_webhooks" ON webhooks
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "users_own_deliveries" ON webhook_deliveries
  FOR ALL USING (
    webhook_id IN (SELECT id FROM webhooks WHERE user_id = auth.uid())
  );

-- ============================================================
-- Helper function: increment script runs atomically
-- ============================================================
CREATE OR REPLACE FUNCTION increment_script_runs(sid TEXT, run_cost NUMERIC)
RETURNS VOID AS $$
BEGIN
  UPDATE scripts
  SET runs = runs + 1,
      revenue = revenue + run_cost
  WHERE id = sid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- Enable Realtime on jobs table (for MCP → frontend bridge)
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE jobs;
