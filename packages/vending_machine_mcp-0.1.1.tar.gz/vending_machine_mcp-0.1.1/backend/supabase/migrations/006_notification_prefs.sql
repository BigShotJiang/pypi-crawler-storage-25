-- Add notification preferences to profiles
-- Stores email notification toggles as JSONB
-- Default: all email notifications enabled

ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS notification_prefs JSONB DEFAULT '{
  "email_approved": true,
  "email_rejected": true,
  "email_submitted": true,
  "email_admin": true
}'::jsonb;

COMMENT ON COLUMN profiles.notification_prefs IS 'Email notification preferences: email_approved, email_rejected, email_submitted, email_admin';
