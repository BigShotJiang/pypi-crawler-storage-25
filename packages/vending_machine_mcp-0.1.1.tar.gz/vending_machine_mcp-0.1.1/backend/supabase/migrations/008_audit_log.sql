-- Append-only audit trail for compliance and debugging
-- Records every significant action taken by users and the system

CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT,
    metadata JSONB DEFAULT '{}',
    request_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_tenant_time ON audit_log(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_resource ON audit_log(resource_type, resource_id);

-- RLS: service role only (backend writes, no direct user access)
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- No user-facing policies — only service role can read/write
-- Admin endpoint provides filtered access

COMMENT ON TABLE audit_log IS 'Append-only audit trail. Actions: job.create, job.cancel, script.submit, script.approve, script.reject, dev_agent.task';
