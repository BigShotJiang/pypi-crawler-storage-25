-- User Profiles — app-specific user data
-- Run this AFTER 001_initial_schema.sql

CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL DEFAULT '',
  is_creator BOOLEAN NOT NULL DEFAULT FALSE,
  creator_name TEXT,  -- public creator name for marketplace listings
  avatar_url TEXT,
  total_revenue NUMERIC(10,6) NOT NULL DEFAULT 0,
  scripts_published INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_profiles_creator ON profiles(is_creator) WHERE is_creator = TRUE;

-- RLS: users see all profiles (public), but only edit their own
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone_reads_profiles" ON profiles
  FOR SELECT USING (true);

CREATE POLICY "users_update_own_profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "service_role_all_profiles" ON profiles
  FOR ALL USING (auth.role() = 'service_role');

-- Auto-create profile + credit account on user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Create profile
  INSERT INTO profiles (id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)));

  -- Create credit account with 500 free credits
  INSERT INTO credit_accounts (user_id, tier, balance, monthly_allowance)
  VALUES (NEW.id, 'free', 500, 500);

  -- Log the initial deposit
  INSERT INTO credit_transactions (account_id, action, amount, reason, balance_after)
  VALUES (
    (SELECT id FROM credit_accounts WHERE user_id = NEW.id),
    'deposit',
    500,
    'Welcome bonus — 500 free credits/month',
    500
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger: auto-create profile on auth.users insert
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Function: promote user to creator
CREATE OR REPLACE FUNCTION promote_to_creator(uid UUID, name TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE profiles
  SET is_creator = TRUE,
      creator_name = name,
      updated_at = NOW()
  WHERE id = uid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
