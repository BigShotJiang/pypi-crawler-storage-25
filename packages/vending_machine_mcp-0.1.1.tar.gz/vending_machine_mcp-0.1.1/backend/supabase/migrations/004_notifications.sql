-- Notification system for script submission workflow
-- Run after 003_portal_support.sql

-- Notifications table
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  user_email TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN (
    'script_submitted',
    'script_approved',
    'script_rejected',
    'script_flagged',
    'admin_new_submission'
  )),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  script_id TEXT,
  read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(user_email, created_at DESC);
CREATE INDEX idx_notifications_unread ON notifications(user_email, read) WHERE read = FALSE;

-- RLS: users see their own notifications, admin sees admin notifications
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users_read_own_notifications" ON notifications
  FOR SELECT USING (user_email = current_setting('request.jwt.claims', true)::json->>'email');

CREATE POLICY "service_role_all_notifications" ON notifications
  FOR ALL TO service_role WITH CHECK (true);

-- Enable realtime for live notification delivery
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;

-- Add submission_id to scripts for tracking before vending code is assigned
ALTER TABLE scripts
  ADD COLUMN IF NOT EXISTS submission_id TEXT UNIQUE;
