"""Tests for Supabase integration — credits, jobs, scripts persistence.

These tests hit the real Supabase instance. They use the service role key
so they bypass RLS. Skipped if SUPABASE_URL is not configured.
"""

from __future__ import annotations

import os
import uuid

import pytest
from dotenv import load_dotenv

# Load dotenv BEFORE skip check so env vars are available
load_dotenv(override=True)

# Skip entire module if Supabase not configured
pytestmark = pytest.mark.skipif(
    not os.getenv("SUPABASE_URL") or not os.getenv("SUPABASE_SECRET_KEY"),
    reason="SUPABASE_URL or SUPABASE_SECRET_KEY not set",
)


# ---------------------------------------------------------------------------
# Supabase client
# ---------------------------------------------------------------------------


class TestSupabaseClient:
    def test_client_initializes(self):
        from supabase_client import get_supabase, is_available

        assert is_available()
        sb = get_supabase()
        assert sb is not None

    def test_tables_exist(self):
        from supabase_client import get_supabase

        sb = get_supabase()
        tables = [
            "credit_accounts",
            "credit_transactions",
            "scripts",
            "jobs",
            "webhooks",
            "webhook_deliveries",
            "profiles",
        ]
        for table in tables:
            result = sb.table(table).select("count", count="exact").limit(0).execute()
            assert result.count is not None, f"Table {table} not accessible"


# ---------------------------------------------------------------------------
# Jobs persistence
# ---------------------------------------------------------------------------


class TestJobsPersistence:
    def test_create_job_persists_to_db(self):
        from jobs import JOB_STORE, create_job
        from supabase_client import get_supabase

        sb = get_supabase()
        job = create_job("test-agent", "Test Agent", "Test task for Supabase")

        # Should be in memory
        assert job["job_id"] in JOB_STORE

        # Should be in Supabase
        result = sb.table("jobs").select("*").eq("id", job["job_id"]).limit(1).execute()
        assert len(result.data) == 1
        assert result.data[0]["agent_id"] == "test-agent"
        assert result.data[0]["status"] == "queued"

        # Cleanup
        sb.table("jobs").delete().eq("id", job["job_id"]).execute()
        del JOB_STORE[job["job_id"]]

    def test_update_job_persists_to_db(self):
        from jobs import JOB_STORE, create_job, update_job
        from supabase_client import get_supabase

        sb = get_supabase()
        job = create_job("test-agent", "Test Agent", "Update test")

        update_job(job["job_id"], status="complete", output="Test output from Supabase")

        # Check DB
        result = sb.table("jobs").select("*").eq("id", job["job_id"]).limit(1).execute()
        assert result.data[0]["status"] == "complete"
        assert result.data[0]["output"] == "Test output from Supabase"

        # Cleanup
        sb.table("jobs").delete().eq("id", job["job_id"]).execute()
        del JOB_STORE[job["job_id"]]

    def test_job_source_field(self):
        from jobs import JOB_STORE, create_job
        from supabase_client import get_supabase

        sb = get_supabase()
        job = create_job("test-agent", "Test Agent", "MCP source test", source="mcp")

        result = sb.table("jobs").select("source").eq("id", job["job_id"]).limit(1).execute()
        assert result.data[0]["source"] == "mcp"

        # Cleanup
        sb.table("jobs").delete().eq("id", job["job_id"]).execute()
        del JOB_STORE[job["job_id"]]


# ---------------------------------------------------------------------------
# Scripts persistence
# ---------------------------------------------------------------------------


class TestScriptsPersistence:
    def test_register_script_persists_to_db(self):
        from scripts import SCRIPT_STORE, register_script
        from supabase_client import get_supabase

        sb = get_supabase()
        test_name = f"Test Script {uuid.uuid4().hex[:6]}"

        script = register_script(
            name=test_name,
            description="A test script for Supabase integration",
            creator="test-runner",
            code='print("hello from test")',
            packages=[],
            price=0.01,
            input_schema="Any text",
        )

        # Check DB
        result = sb.table("scripts").select("*").eq("id", script["script_id"]).limit(1).execute()
        assert len(result.data) == 1
        assert result.data[0]["name"] == test_name
        assert result.data[0]["creator"] == "test-runner"

        # Cleanup
        sb.table("scripts").delete().eq("id", script["script_id"]).execute()
        del SCRIPT_STORE[script["script_id"]]

    def test_record_run_increments_in_db(self):
        from scripts import SCRIPT_STORE, record_run, register_script
        from supabase_client import get_supabase

        sb = get_supabase()
        test_name = f"Run Counter {uuid.uuid4().hex[:6]}"

        script = register_script(
            name=test_name,
            description="Test run counting",
            creator="test-runner",
            code='print("counting")',
            packages=[],
            price=0.02,
        )

        # Record 3 runs
        record_run(script["script_id"], 0.02)
        record_run(script["script_id"], 0.02)
        record_run(script["script_id"], 0.02)

        # Check DB — should have 3 runs and $0.06 revenue
        result = sb.table("scripts").select("runs, revenue").eq("id", script["script_id"]).limit(1).execute()
        assert result.data[0]["runs"] == 3
        assert float(result.data[0]["revenue"]) == pytest.approx(0.06, abs=0.001)

        # Cleanup
        sb.table("scripts").delete().eq("id", script["script_id"]).execute()
        del SCRIPT_STORE[script["script_id"]]


# ---------------------------------------------------------------------------
# Webhook persistence
# ---------------------------------------------------------------------------


class TestWebhookPersistence:
    @pytest.mark.asyncio
    async def test_register_webhook_persists_to_db(self):
        from httpx import ASGITransport, AsyncClient

        from supabase_client import get_supabase
        from webhook_service import app, webhooks_store

        sb = get_supabase()

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://testserver") as client:
            resp = await client.post(
                "/webhooks/register",
                json={
                    "url": "https://example.com/test-hook",
                    "events": ["script.run"],
                    "secret": "test-secret-for-supabase-16chars",
                },
            )

        assert resp.status_code == 201
        wh_id = resp.json()["webhook_id"]

        # Check DB
        result = sb.table("webhooks").select("*").eq("id", wh_id).limit(1).execute()
        assert len(result.data) == 1
        assert result.data[0]["url"] == "https://example.com/test-hook"
        # Secret should be bcrypt hashed, not plaintext
        assert result.data[0]["secret_hash"].startswith("$2")

        # Cleanup
        sb.table("webhooks").delete().eq("id", wh_id).execute()
        webhooks_store.pop(wh_id, None)

    @pytest.mark.asyncio
    async def test_delete_webhook_removes_from_db(self):
        from httpx import ASGITransport, AsyncClient

        from supabase_client import get_supabase
        from webhook_service import app, webhooks_store

        sb = get_supabase()

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://testserver") as client:
            # Register
            reg = await client.post(
                "/webhooks/register",
                json={
                    "url": "https://example.com/delete-test",
                    "events": ["job.complete"],
                    "secret": "delete-test-secret-16chars",
                },
            )
            wh_id = reg.json()["webhook_id"]

            # Delete
            await client.delete(f"/webhooks/{wh_id}")

        # Should be gone from DB
        result = sb.table("webhooks").select("*").eq("id", wh_id).limit(1).execute()
        assert len(result.data) == 0

        webhooks_store.pop(wh_id, None)
