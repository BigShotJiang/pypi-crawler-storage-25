# ruff: noqa: S105, S106 — test file intentionally uses hardcoded secrets
"""Tests for webhook_service.py — adapted from Test Goblin output."""

from __future__ import annotations

import hashlib
import hmac
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport, AsyncClient
from pydantic import ValidationError

from webhook_service import (
    DeliveryStatus,
    EventType,
    RegisterWebhookRequest,
    StoredWebhook,
    WebhookPayload,
    app,
    compute_signature,
    deliver_webhook,
    delivery_logs_store,
    sign_payload,
    verify_signature,
    webhooks_store,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_stores():
    """Clear in-memory stores between tests."""
    webhooks_store.clear()
    delivery_logs_store.clear()


@pytest.fixture
async def client():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://testserver") as ac:
        yield ac


# ---------------------------------------------------------------------------
# Model validation
# ---------------------------------------------------------------------------


class TestWebhookRegistrationModel:
    def test_accepts_valid_https_url(self):
        reg = RegisterWebhookRequest(
            url="https://example.com/webhook",
            events=["script.run", "job.complete"],
            secret="my-super-secret-1234",
        )
        assert str(reg.url).startswith("https://")
        assert len(reg.events) == 2

    def test_rejects_http_url(self):
        with pytest.raises(ValidationError, match="HTTPS"):
            RegisterWebhookRequest(
                url="http://example.com/webhook",
                events=["script.run"],
                secret="my-super-secret-1234",
            )

    def test_rejects_localhost(self):
        with pytest.raises(ValidationError):
            RegisterWebhookRequest(
                url="https://localhost/webhook",
                events=["script.run"],
                secret="my-super-secret-1234",
            )

    def test_rejects_private_ip(self):
        with pytest.raises(ValidationError):
            RegisterWebhookRequest(
                url="https://10.0.0.1/webhook",
                events=["script.run"],
                secret="my-super-secret-1234",
            )

    def test_rejects_metadata_endpoint(self):
        with pytest.raises(ValidationError):
            RegisterWebhookRequest(
                url="https://169.254.169.254/latest/meta-data/",
                events=["script.run"],
                secret="my-super-secret-1234",
            )

    def test_rejects_empty_events(self):
        with pytest.raises(ValidationError):
            RegisterWebhookRequest(
                url="https://example.com/webhook",
                events=[],
                secret="my-super-secret-1234",
            )

    def test_rejects_short_secret(self):
        with pytest.raises(ValidationError):
            RegisterWebhookRequest(
                url="https://example.com/webhook",
                events=["script.run"],
                secret="short",
            )

    def test_deduplicates_events(self):
        reg = RegisterWebhookRequest(
            url="https://example.com/webhook",
            events=["script.run", "script.run", "job.complete"],
            secret="my-super-secret-1234",
        )
        assert reg.events == [EventType.SCRIPT_RUN, EventType.JOB_COMPLETE]


# ---------------------------------------------------------------------------
# Signature functions
# ---------------------------------------------------------------------------


class TestSignature:
    def test_compute_signature_matches_reference(self):
        payload = b'{"event":"script.run","amount":1000}'
        secret = "topsecret-longkey"
        expected = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        assert compute_signature(payload, secret) == expected

    def test_signature_changes_for_tampered_payload(self):
        secret = "topsecret-longkey"
        sig1 = compute_signature(b'{"x":1}', secret)
        sig2 = compute_signature(b'{"x":2}', secret)
        assert sig1 != sig2

    def test_signature_changes_for_different_secret(self):
        payload = b'{"x":1}'
        assert compute_signature(payload, "secret-aaaaaaaaaa") != compute_signature(payload, "secret-bbbbbbbbbb")

    def test_sign_payload_has_prefix(self):
        sig = sign_payload("my-long-secret-key", b'{"test":true}')
        assert sig.startswith("sha256=")
        assert len(sig) == 7 + 64  # "sha256=" + 64 hex chars

    def test_verify_signature_valid(self):
        secret = "verify-me-long-key"
        payload = b'{"ok":true}'
        sig = sign_payload(secret, payload)
        assert verify_signature(payload, sig, secret) is True

    def test_verify_signature_tampered(self):
        secret = "verify-me-long-key"
        payload = b'{"ok":true}'
        sig = sign_payload(secret, payload)
        assert verify_signature(b'{"ok":false}', sig, secret) is False

    def test_verify_signature_wrong_prefix(self):
        assert verify_signature(b"data", "md5=abc", "secret") is False


# ---------------------------------------------------------------------------
# Delivery logic
# ---------------------------------------------------------------------------


class TestDelivery:
    @pytest.mark.asyncio
    async def test_successful_delivery(self):
        webhook = StoredWebhook(
            webhook_id="wh-test1",
            url="https://example.com/hook",
            events=[EventType.SCRIPT_RUN],
            secret="test-secret-longkey",
            created_at="2026-04-05T12:00:00Z",
        )
        payload = WebhookPayload(
            event=EventType.SCRIPT_RUN,
            timestamp="2026-04-05T12:00:00Z",
            webhook_id="wh-test1",
            nonce="abc123",
            data={"script_name": "CSV Analyzer"},
        )

        ok_response = MagicMock()
        ok_response.status_code = 200

        with patch("webhook_service.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(return_value=ok_response)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await deliver_webhook("dlv-1", webhook, payload)

        assert mock_client.post.await_count == 1
        # Check signature header was sent
        _, kwargs = mock_client.post.await_args
        headers = kwargs.get("headers", {})
        assert "X-Webhook-Signature" in headers
        assert headers["X-Webhook-Signature"].startswith("sha256=")

        # Check delivery was logged
        assert "wh-test1" in delivery_logs_store
        log = list(delivery_logs_store["wh-test1"])
        assert len(log) == 1
        assert log[0].status == DeliveryStatus.SUCCESS
        assert log[0].attempts == 1

    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        webhook = StoredWebhook(
            webhook_id="wh-retry",
            url="https://example.com/hook",
            events=[EventType.SCRIPT_RUN],
            secret="retry-secret-longkey",
            created_at="2026-04-05T12:00:00Z",
        )
        payload = WebhookPayload(
            event=EventType.SCRIPT_RUN,
            timestamp="2026-04-05T12:00:00Z",
            webhook_id="wh-retry",
            nonce="retry123",
            data={},
        )

        request = httpx.Request("POST", "https://example.com/hook")
        fail = httpx.ConnectError("connection refused", request=request)

        ok_response = MagicMock()
        ok_response.status_code = 200

        sleep_mock = AsyncMock()

        with (
            patch("webhook_service.httpx.AsyncClient") as mock_client_cls,
            patch("webhook_service.asyncio.sleep", new=sleep_mock),
        ):
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(side_effect=[fail, fail, ok_response])
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await deliver_webhook("dlv-retry", webhook, payload)

        assert mock_client.post.await_count == 3
        # Verify backoff timing: 1s after first fail, 4s after second
        assert sleep_mock.await_count == 2
        sleep_mock.assert_any_await(1)
        sleep_mock.assert_any_await(4)

        log = list(delivery_logs_store["wh-retry"])
        assert log[0].status == DeliveryStatus.SUCCESS
        assert log[0].attempts == 3

    @pytest.mark.asyncio
    async def test_all_retries_exhausted(self):
        webhook = StoredWebhook(
            webhook_id="wh-fail",
            url="https://example.com/hook",
            events=[EventType.SCRIPT_RUN],
            secret="fail-secret-longkeyy",
            created_at="2026-04-05T12:00:00Z",
        )
        payload = WebhookPayload(
            event=EventType.SCRIPT_RUN,
            timestamp="2026-04-05T12:00:00Z",
            webhook_id="wh-fail",
            nonce="fail123",
            data={},
        )

        request = httpx.Request("POST", "https://example.com/hook")
        fail = httpx.ConnectError("connection refused", request=request)

        with (
            patch("webhook_service.httpx.AsyncClient") as mock_client_cls,
            patch("webhook_service.asyncio.sleep", new=AsyncMock()),
        ):
            mock_client = AsyncMock()
            mock_client.post = AsyncMock(side_effect=[fail, fail, fail])
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await deliver_webhook("dlv-fail", webhook, payload)

        log = list(delivery_logs_store["wh-fail"])
        assert log[0].status == DeliveryStatus.FAILED
        assert log[0].attempts == 3
        assert log[0].error is not None


# ---------------------------------------------------------------------------
# API endpoints
# ---------------------------------------------------------------------------


class TestEndpoints:
    @pytest.mark.asyncio
    async def test_register_webhook(self, client):
        resp = await client.post(
            "/webhooks/register",
            json={
                "url": "https://example.com/webhook",
                "events": ["script.run"],
                "secret": "my-super-secret-1234",
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["webhook_id"].startswith("wh-")
        assert data["events"] == ["script.run"]

    @pytest.mark.asyncio
    async def test_register_rejects_http(self, client):
        resp = await client.post(
            "/webhooks/register",
            json={
                "url": "http://example.com/webhook",
                "events": ["script.run"],
                "secret": "my-super-secret-1234",
            },
        )
        assert resp.status_code == 422

    @pytest.mark.asyncio
    async def test_register_rejects_private_ip(self, client):
        resp = await client.post(
            "/webhooks/register",
            json={
                "url": "https://10.0.0.1/webhook",
                "events": ["script.run"],
                "secret": "my-super-secret-1234",
            },
        )
        assert resp.status_code == 422

    @pytest.mark.asyncio
    async def test_list_webhooks(self, client):
        # Register one
        await client.post(
            "/webhooks/register",
            json={
                "url": "https://example.com/hook1",
                "events": ["script.run"],
                "secret": "list-test-secret-1234",
            },
        )

        resp = await client.get("/webhooks")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert len(data["webhooks"]) == 1
        # Secret should NOT be in the response
        assert "secret" not in data["webhooks"][0]

    @pytest.mark.asyncio
    async def test_delete_webhook(self, client):
        # Register
        reg = await client.post(
            "/webhooks/register",
            json={
                "url": "https://example.com/hook-del",
                "events": ["script.run"],
                "secret": "delete-test-secret-1234",
            },
        )
        wh_id = reg.json()["webhook_id"]

        # Delete
        resp = await client.delete(f"/webhooks/{wh_id}")
        assert resp.status_code == 204

        # Verify gone
        list_resp = await client.get("/webhooks")
        assert list_resp.json()["total"] == 0

    @pytest.mark.asyncio
    async def test_delete_nonexistent_returns_404(self, client):
        resp = await client.delete("/webhooks/wh-doesntexist")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_deliveries_endpoint(self, client):
        # Register
        reg = await client.post(
            "/webhooks/register",
            json={
                "url": "https://example.com/hook-log",
                "events": ["script.run"],
                "secret": "delivery-test-secret-1234",
            },
        )
        wh_id = reg.json()["webhook_id"]

        # Check deliveries (should be empty)
        resp = await client.get(f"/webhooks/{wh_id}/deliveries")
        assert resp.status_code == 200
        assert resp.json()["deliveries"] == []

    @pytest.mark.asyncio
    async def test_health(self, client):
        resp = await client.get("/health")
        assert resp.status_code == 200
        assert resp.json() == {"status": "ok"}

    @pytest.mark.asyncio
    async def test_test_webhook_not_found(self, client):
        resp = await client.post(
            "/webhooks/test",
            json={"webhook_id": "wh-nonexistent"},
        )
        assert resp.status_code == 404
