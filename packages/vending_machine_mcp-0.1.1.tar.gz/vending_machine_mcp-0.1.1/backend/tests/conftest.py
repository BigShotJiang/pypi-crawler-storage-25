"""Shared fixtures for the test suite."""

import os
import sys

import pytest

# Ensure backend is on the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@pytest.fixture(autouse=True)
def _reset_stores():
    """Reset in-memory stores between tests."""
    from jobs import JOB_STORE
    from scripts import SCRIPT_STORE

    JOB_STORE.clear()
    SCRIPT_STORE.clear()

    # Re-seed scripts
    from scripts import _seed

    _seed()

    yield

    JOB_STORE.clear()
    SCRIPT_STORE.clear()


def requires_e2b(fn):
    """Skip test if E2B_API_KEY is not set."""
    return pytest.mark.skipif(
        not os.getenv("E2B_API_KEY"),
        reason="E2B_API_KEY not set — skipping integration test",
    )(fn)


def requires_openrouter(fn):
    """Skip test if OPENROUTER_API_KEY is not set."""
    return pytest.mark.skipif(
        not os.getenv("OPENROUTER_API_KEY"),
        reason="OPENROUTER_API_KEY not set — skipping LLM test",
    )(fn)
