"""API tests — FastAPI TestClient, no real server needed."""

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client():
    from main import app

    return TestClient(app)


class TestScriptsAPI:
    def test_list_scripts_returns_seed_scripts(self, client):
        resp = client.get("/api/scripts")
        assert resp.status_code == 200
        scripts = resp.json()
        assert len(scripts) >= 4  # seed scripts
        # Should not include code field
        for s in scripts:
            assert "code" not in s
            assert "validation_status" in s

    def test_get_script_detail(self, client):
        # Get a script ID from the list
        scripts = client.get("/api/scripts").json()
        sid = scripts[0]["script_id"]

        resp = client.get(f"/api/scripts/{sid}")
        assert resp.status_code == 200
        detail = resp.json()
        assert detail["script_id"] == sid
        assert "code" not in detail

    def test_get_nonexistent_script(self, client):
        resp = client.get("/api/scripts/nonexistent")
        assert resp.status_code == 200  # FastAPI returns 200 with error body
        body = resp.json()
        assert "error" in body if isinstance(body, dict) else True

    def test_get_script_validation(self, client):
        scripts = client.get("/api/scripts").json()
        sid = scripts[0]["script_id"]

        resp = client.get(f"/api/scripts/{sid}/validation")
        assert resp.status_code == 200
        body = resp.json()
        assert "validation_status" in body
        assert "report" in body

    def test_get_script_stats(self, client):
        scripts = client.get("/api/scripts").json()
        sid = scripts[0]["script_id"]

        resp = client.get(f"/api/scripts/{sid}/stats")
        assert resp.status_code == 200
        stats = resp.json()
        assert "runs" in stats
        assert "revenue" in stats


class TestCreatorDashboardAPI:
    def test_creator_dashboard(self, client):
        resp = client.get("/api/creator/dashboard?creator=platform")
        assert resp.status_code == 200
        body = resp.json()
        assert body["creator"] == "platform"
        assert "totals" in body
        assert "summary" in body
        assert "scripts" in body
        assert isinstance(body["scripts"], list)
        if body["scripts"]:
            script = body["scripts"][0]
            assert "name" in script
            assert "vending_code" in script
            assert "runs" in script
            assert "revenue" in script
            assert "validation_status" in script


class TestJobsAPI:
    def test_list_jobs_empty(self, client):
        resp = client.get("/api/jobs")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_nonexistent_job(self, client):
        resp = client.get("/api/jobs/nonexistent-id")
        assert resp.status_code == 200
        body = resp.json()
        assert "error" in body if isinstance(body, dict) else True


class TestHealthAPI:
    def test_health_endpoint(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        body = resp.json()
        assert body["status"] == "ok"
        assert "agents" in body
        assert len(body["agents"]) > 0
