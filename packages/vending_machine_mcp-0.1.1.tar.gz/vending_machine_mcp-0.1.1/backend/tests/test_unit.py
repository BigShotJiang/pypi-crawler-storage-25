"""Unit tests — pure functions, no external services needed."""

import pytest

# ---------------------------------------------------------------------------
# Chunking strategies
# ---------------------------------------------------------------------------


class TestChunking:
    def test_paragraph_splits_on_double_newline(self):
        from agents.embeddings.chunking import chunk_paragraph

        text = "First paragraph.\n\nSecond paragraph.\n\nThird."
        chunks = chunk_paragraph(text, max_chars=1000)
        assert len(chunks) == 1  # all fit in one chunk
        assert "First paragraph." in chunks[0]

    def test_paragraph_splits_when_exceeds_max(self):
        from agents.embeddings.chunking import chunk_paragraph

        text = "A" * 50 + "\n\n" + "B" * 50 + "\n\n" + "C" * 50
        chunks = chunk_paragraph(text, max_chars=60)
        assert len(chunks) == 3
        assert chunks[0].strip() == "A" * 50
        assert chunks[1].strip() == "B" * 50

    def test_paragraph_handles_empty_input(self):
        from agents.embeddings.chunking import chunk_paragraph

        chunks = chunk_paragraph("", max_chars=100)
        assert len(chunks) == 1  # returns [text[:max_chars]]

    def test_sentence_splits_on_punctuation(self):
        from agents.embeddings.chunking import chunk_sentence

        text = "Hello world. This is a test. Another sentence here!"
        chunks = chunk_sentence(text, max_chars=30)
        assert len(chunks) >= 2

    def test_sentence_single_sentence(self):
        from agents.embeddings.chunking import chunk_sentence

        chunks = chunk_sentence("Just one sentence.", max_chars=1000)
        assert len(chunks) == 1

    def test_fixed_size_produces_correct_overlap(self):
        from agents.embeddings.chunking import chunk_fixed_size

        text = "A" * 100
        chunks = chunk_fixed_size(text, chunk_size=40, overlap=10)
        assert len(chunks) >= 3
        # All chunks should be non-empty
        assert all(len(c) > 0 for c in chunks)

    def test_fixed_size_empty_input(self):
        from agents.embeddings.chunking import chunk_fixed_size

        assert chunk_fixed_size("", chunk_size=100) == []

    def test_recursive_falls_through_separators(self):
        from agents.embeddings.chunking import chunk_recursive

        # No double newlines, should fall to single newline
        text = "line1\nline2\nline3\nline4"
        chunks = chunk_recursive(text, max_chars=15)
        assert len(chunks) >= 2

    def test_auto_select_picks_fixed_for_code(self):
        from agents.embeddings.chunking import auto_select_strategy

        code = "\n".join(["def foo():", "    x = 1", "    return x", ""] * 30)
        assert auto_select_strategy(code, "openai", "text-embedding-3-small") == "fixed_size"

    def test_auto_select_picks_paragraph_for_prose(self):
        from agents.embeddings.chunking import auto_select_strategy

        prose = "Hello.\n\nWorld.\n\nFoo.\n\nBar.\n\nBaz."
        assert auto_select_strategy(prose, "openai", "text-embedding-3-small") == "paragraph"

    def test_auto_select_picks_contextualized_for_voyage(self):
        from agents.embeddings.chunking import auto_select_strategy

        assert auto_select_strategy("any text", "voyage", "voyage-context-3") == "contextualized"


# ---------------------------------------------------------------------------
# Security validator (static analysis only)
# ---------------------------------------------------------------------------


class TestSecurityValidator:
    async def _run(self, code, packages=None):
        from guards.script_validator import validate_script

        return await validate_script(
            code=code,
            packages=packages or [],
            description="test",
            skip_sandbox=True,
            skip_llm=True,
            skip_functionality=True,
            skip_quality=True,
            skip_reliability=True,
        )

    @pytest.mark.asyncio
    async def test_os_system_detected(self):
        r = await self._run('import os\nos.system("whoami")')
        assert r.verdict == "REJECTED"
        attacks = [f.attack_id for f in r.findings]
        assert "T1059.006" in attacks

    @pytest.mark.asyncio
    async def test_eval_base64_detected(self):
        r = await self._run('import base64\nx = base64.b64encode(b"test")\neval(base64.b64decode(x))')
        assert r.verdict == "REJECTED"
        attacks = [f.attack_id for f in r.findings]
        assert "T1027" in attacks

    @pytest.mark.asyncio
    async def test_open_etc_passwd_detected(self):
        r = await self._run('data = open("/etc/passwd").read()')
        attacks = [f.attack_id for f in r.findings]
        assert "T1005" in attacks or "T1552.001" in attacks

    @pytest.mark.asyncio
    async def test_clean_script_no_findings(self):
        r = await self._run("import csv\nprint('hello')")
        assert r.verdict == "APPROVED"
        assert len(r.findings) == 0

    @pytest.mark.asyncio
    async def test_shutil_rmtree_detected(self):
        r = await self._run('import shutil\nshutil.rmtree("/")')
        assert r.verdict == "REJECTED"
        assert any(f.attack_id == "T1070.004" for f in r.findings)

    @pytest.mark.asyncio
    async def test_subprocess_safe_cli_tool(self):
        """subprocess.run(["ls"]) with shell=False is a safe CLI wrapper — not rejected."""
        r = await self._run('import subprocess\nsubprocess.run(["ls"])')
        # Safe CLI tools are flagged as low severity, not rejected
        assert r.verdict != "REJECTED"
        assert any(f.attack_id == "T1059.006.safe" for f in r.findings)

    @pytest.mark.asyncio
    async def test_subprocess_shell_true_rejected(self):
        """subprocess.run with shell=True is always dangerous."""
        r = await self._run('import subprocess\nsubprocess.run("ls -la", shell=True)')
        assert r.verdict == "REJECTED"
        assert any(f.attack_id == "T1059.006" for f in r.findings)

    @pytest.mark.asyncio
    async def test_subprocess_dangerous_cmd_rejected(self):
        """subprocess.run with destructive commands is rejected."""
        r = await self._run('import subprocess\nsubprocess.run(["rm", "-rf", "/"])')
        assert r.verdict == "REJECTED"
        assert any(f.attack_id == "T1059.006" for f in r.findings)

    @pytest.mark.asyncio
    async def test_typosquat_detected(self):
        r = await self._run("print('hello')", packages=["reqeusts"])
        assert r.verdict == "FLAGGED"
        assert any("typosquat" in f.message.lower() for f in r.findings)

    def test_levenshtein_distance(self):
        from guards.script_validator import _levenshtein

        assert _levenshtein("requests", "requests") == 0
        assert _levenshtein("reqeusts", "requests") == 2
        assert _levenshtein("", "abc") == 3
        assert _levenshtein("kitten", "sitting") == 3

    @pytest.mark.asyncio
    async def test_known_malicious_package(self):
        r = await self._run("print('hello')", packages=["colourama"])
        assert r.verdict == "REJECTED"

    @pytest.mark.asyncio
    async def test_findings_have_framework_tags(self):
        r = await self._run('import os\nos.system("ls")')
        for f in r.findings:
            assert f.attack_id, f"Finding missing ATT&CK ID: {f.message}"
            assert f.kill_chain_stage, f"Finding missing Kill Chain stage: {f.message}"
            assert f.nist_function, f"Finding missing NIST function: {f.message}"


# ---------------------------------------------------------------------------
# Analysis module
# ---------------------------------------------------------------------------


class TestAnalysis:
    def test_cosine_identical_vectors(self):
        from agents.embeddings.analysis import cosine_similarity

        a = [1.0, 2.0, 3.0]
        assert cosine_similarity(a, a) == pytest.approx(1.0)

    def test_cosine_orthogonal_vectors(self):
        from agents.embeddings.analysis import cosine_similarity

        assert cosine_similarity([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0)

    def test_cosine_zero_vector(self):
        from agents.embeddings.analysis import cosine_similarity

        assert cosine_similarity([0.0, 0.0], [1.0, 2.0]) == pytest.approx(0.0)

    def test_cosine_opposite_vectors(self):
        from agents.embeddings.analysis import cosine_similarity

        assert cosine_similarity([1.0, 0.0], [-1.0, 0.0]) == pytest.approx(-1.0)

    def test_pairwise_sorts_descending(self):
        from agents.embeddings.analysis import compute_similarity_pairs

        # Three vectors: a and b similar, c different
        a = [1.0, 0.0, 0.0]
        b = [0.9, 0.1, 0.0]
        c = [0.0, 0.0, 1.0]
        pairs = compute_similarity_pairs([a, b, c])
        assert pairs[0][2] > pairs[-1][2]  # first pair most similar


# ---------------------------------------------------------------------------
# Script store
# ---------------------------------------------------------------------------


class TestScriptStore:
    def test_register_creates_with_fields(self):
        from scripts import register_script

        s = register_script(
            name="Test",
            description="A test script",
            creator="tester",
            code="print('hi')",
        )
        assert s["name"] == "Test"
        assert s["creator"] == "tester"
        assert s["runs"] == 0
        assert s["revenue"] == 0.0
        assert s["validation_status"] == "pending"

    def test_list_scripts_excludes_rejected(self):
        from scripts import list_scripts, register_script

        s = register_script(name="Bad", description="x", creator="x", code="x")
        s["validation_status"] = "rejected"

        all_scripts = list_scripts(include_rejected=True)
        visible = list_scripts(include_rejected=False)
        assert len(all_scripts) > len(visible)

    def test_record_run_increments(self):
        from scripts import list_scripts, record_run

        script = list_scripts()[0]
        sid = script["script_id"]
        assert script["runs"] == 0

        record_run(sid, 0.05)
        assert script["runs"] == 1
        assert script["revenue"] == 0.05

        record_run(sid, 0.05)
        assert script["runs"] == 2
        assert script["revenue"] == pytest.approx(0.10)


# ---------------------------------------------------------------------------
# Job store
# ---------------------------------------------------------------------------


class TestJobStore:
    def test_create_job(self):
        from jobs import create_job

        job = create_job("test-agent", "Test Agent", "do something")
        assert job["agent_id"] == "test-agent"
        assert job["status"] == "queued"
        assert job["output"] == ""

    def test_update_job(self):
        from jobs import JobStatus, create_job, update_job

        job = create_job("test", "Test", "task")
        update_job(job["job_id"], status=JobStatus.running, output="hello")
        assert job["status"] == "running"
        assert job["output"] == "hello"

    def test_list_jobs_sorted(self):
        import time

        from jobs import create_job, list_jobs

        create_job("a", "A", "first")
        time.sleep(0.01)
        j2 = create_job("b", "B", "second")
        jobs = list_jobs()
        assert jobs[0]["job_id"] == j2["job_id"]  # newest first

    def test_get_nonexistent_returns_none(self):
        from jobs import get_job

        assert get_job("nonexistent-id") is None


# ---------------------------------------------------------------------------
# Risk score filtering
# ---------------------------------------------------------------------------


class TestRiskScoreFiltering:
    def test_quality_findings_excluded(self):
        from guards.script_validator import _calculate_risk_score
        from guards.security_types import Finding

        security = Finding(layer="static", severity="high", message="test")
        quality = Finding(layer="quality", severity="high", message="test")
        reliability = Finding(layer="reliability", severity="high", message="test")

        score_security = _calculate_risk_score([security])
        score_quality = _calculate_risk_score([quality])
        score_mixed = _calculate_risk_score([security, quality, reliability])

        assert score_security > 0
        assert score_quality == 0.0
        assert score_mixed == score_security
