"""GitHub Advisory Database — REST API client.

Endpoint: https://api.github.com/advisories
Requires GITHUB_TOKEN for authentication.
Rate limit: 5000 requests/hour with token.
"""

import os

import httpx

from .. import cache

BASE_URL = "https://api.github.com/advisories"
TIMEOUT = 20

# Map friendly names to GitHub's ecosystem identifiers
ECOSYSTEM_MAP = {
    "npm": "npm",
    "pypi": "pip",
    "pip": "pip",
    "go": "go",
    "crates.io": "rust",
    "rust": "rust",
    "maven": "maven",
    "nuget": "nuget",
    "rubygems": "rubygems",
}


def _headers() -> dict[str, str]:
    token = os.getenv("GITHUB_TOKEN", "")
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _is_available() -> bool:
    """Check if GITHUB_TOKEN is configured."""
    return bool(os.getenv("GITHUB_TOKEN", ""))


async def search(
    ecosystem: str | None = None,
    severity: str | None = None,
    keyword: str | None = None,
    max_results: int = 20,
) -> list[dict]:
    """Search GitHub Advisory Database for security advisories."""
    if not _is_available():
        return [{"error": "GITHUB_TOKEN not configured — GitHub Advisories unavailable"}]

    cache_key = f"gh:adv:{ecosystem}:{severity}:{keyword}:{max_results}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    params: dict[str, str | int] = {
        "per_page": min(max_results, 100),
        "sort": "published",
        "direction": "desc",
    }

    if ecosystem:
        gh_eco = ECOSYSTEM_MAP.get(ecosystem.lower(), ecosystem.lower())
        params["ecosystem"] = gh_eco

    if severity and severity.lower() in ("low", "medium", "high", "critical"):
        params["severity"] = severity.lower()

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.get(BASE_URL, params=params, headers=_headers())
        if resp.status_code == 401:
            return [{"error": "GitHub token invalid or expired"}]
        resp.raise_for_status()
        data = resp.json()

    results = []
    for adv in data:
        # Apply keyword filter client-side (GitHub API doesn't support keyword search)
        if keyword:
            keyword_lower = keyword.lower()
            summary = (adv.get("summary") or "").lower()
            desc = (adv.get("description") or "").lower()
            if keyword_lower not in summary and keyword_lower not in desc:
                continue

        vulnerabilities = adv.get("vulnerabilities", [])
        affected_packages = []
        for v in vulnerabilities:
            pkg = v.get("package", {})
            affected_packages.append(
                {
                    "ecosystem": pkg.get("ecosystem", ""),
                    "name": pkg.get("name", ""),
                    "vulnerable_range": v.get("vulnerable_version_range", ""),
                    "first_patched": v.get("first_patched_version", ""),
                }
            )

        results.append(
            {
                "ghsa_id": adv.get("ghsa_id", ""),
                "cve_id": adv.get("cve_id"),
                "summary": adv.get("summary", ""),
                "severity": adv.get("severity", ""),
                "published_at": adv.get("published_at", ""),
                "updated_at": adv.get("updated_at", ""),
                "html_url": adv.get("html_url", ""),
                "affected_packages": affected_packages[:5],
            }
        )

    cache.put(cache_key, results)
    return results


async def search_malware(
    ecosystem: str | None = None,
    max_results: int = 20,
) -> list[dict]:
    """Search for malicious package advisories (supply-chain attacks)."""
    # GitHub tags malware advisories with "malware" in the type field
    # or with specific labels. We filter by keyword.
    all_advs = await search(
        ecosystem=ecosystem,
        severity="critical",
        max_results=100,
    )

    malware = []
    for adv in all_advs:
        if isinstance(adv, dict) and "error" in adv:
            return [adv]

        summary = (adv.get("summary") or "").lower()
        if any(kw in summary for kw in ("malicious", "malware", "supply chain", "backdoor", "compromised")):
            malware.append(adv)
            if len(malware) >= max_results:
                break

    return malware
