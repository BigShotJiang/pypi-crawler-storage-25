"""NVD/NIST API client — National Vulnerability Database.

Endpoint: https://services.nvd.nist.gov/rest/json/cves/2.0
Rate limit: 5 req/30s without key, 50 req/30s with NVD_API_KEY.
"""

import os
from datetime import UTC, datetime, timedelta

import httpx

from .. import cache

BASE_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
TIMEOUT = 30


def _headers() -> dict[str, str]:
    key = os.getenv("NVD_API_KEY", "")
    if key:
        return {"apiKey": key}
    return {}


async def search(
    keyword: str,
    severity: str | None = None,
    days_back: int = 30,
    max_results: int = 20,
) -> list[dict]:
    """Search NVD for CVEs matching keyword and optional severity/date filter."""
    cache_key = f"nvd:search:{keyword}:{severity}:{days_back}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    params: dict[str, str | int] = {
        "keywordSearch": keyword,
        "resultsPerPage": max_results,
    }

    if severity and severity.upper() in ("LOW", "MEDIUM", "HIGH", "CRITICAL"):
        params["cvssV3Severity"] = severity.upper()

    if days_back > 0:
        end = datetime.now(UTC)
        start = end - timedelta(days=min(days_back, 120))  # NVD max 120 days
        params["pubStartDate"] = start.strftime("%Y-%m-%dT00:00:00.000")
        params["pubEndDate"] = end.strftime("%Y-%m-%dT23:59:59.999")

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.get(BASE_URL, params=params, headers=_headers())
        resp.raise_for_status()
        data = resp.json()

    results = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        metrics = cve.get("metrics", {})

        # Extract CVSS score
        cvss_score = None
        cvss_severity = None
        for version_key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV40"):
            metric_list = metrics.get(version_key, [])
            if metric_list:
                cvss_data = metric_list[0].get("cvssData", {})
                cvss_score = cvss_data.get("baseScore")
                cvss_severity = cvss_data.get("baseSeverity")
                break

        descriptions = cve.get("descriptions", [])
        desc_en = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")

        results.append(
            {
                "cve_id": cve.get("id", ""),
                "description": desc_en[:500],
                "cvss_score": cvss_score,
                "severity": cvss_severity,
                "published": cve.get("published", ""),
                "last_modified": cve.get("lastModified", ""),
                "references": [r.get("url", "") for r in cve.get("references", [])[:3]],
            }
        )

    cache.put(cache_key, results)
    return results


async def get_cve(cve_id: str) -> dict | None:
    """Fetch a single CVE by ID from NVD."""
    cache_key = f"nvd:cve:{cve_id}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    params = {"cveId": cve_id}

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.get(BASE_URL, params=params, headers=_headers())
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        data = resp.json()

    vulns = data.get("vulnerabilities", [])
    if not vulns:
        return None

    cve = vulns[0].get("cve", {})
    metrics = cve.get("metrics", {})

    cvss_score = None
    cvss_severity = None
    cvss_vector = None
    for version_key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV40"):
        metric_list = metrics.get(version_key, [])
        if metric_list:
            cvss_data = metric_list[0].get("cvssData", {})
            cvss_score = cvss_data.get("baseScore")
            cvss_severity = cvss_data.get("baseSeverity")
            cvss_vector = cvss_data.get("vectorString")
            break

    descriptions = cve.get("descriptions", [])
    desc_en = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")

    weaknesses = []
    for w in cve.get("weaknesses", []):
        for desc in w.get("description", []):
            if desc.get("lang") == "en":
                weaknesses.append(desc.get("value", ""))

    result = {
        "cve_id": cve.get("id", ""),
        "description": desc_en,
        "cvss_score": cvss_score,
        "severity": cvss_severity,
        "cvss_vector": cvss_vector,
        "published": cve.get("published", ""),
        "last_modified": cve.get("lastModified", ""),
        "weaknesses": weaknesses,
        "references": [r.get("url", "") for r in cve.get("references", [])],
    }

    cache.put(cache_key, result)
    return result
