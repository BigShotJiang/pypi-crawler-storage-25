"""AWS Security Bulletins — RSS feed parser.

Feed: https://aws.amazon.com/security/security-bulletins/rss/
No auth. No rate limits. Standard RSS 2.0 XML.
"""

import feedparser
import httpx

from .. import cache

FEED_URL = "https://aws.amazon.com/security/security-bulletins/rss/"
TIMEOUT = 15


async def fetch_bulletins(
    limit: int = 20,
    search: str | None = None,
) -> list[dict]:
    """Fetch recent AWS security bulletins from the RSS feed."""
    cache_key = f"aws:bulletins:{limit}:{search or ''}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    # Fetch raw RSS
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.get(FEED_URL)
        resp.raise_for_status()
        raw_xml = resp.text

    # Parse with feedparser (sync, but fast)
    feed = feedparser.parse(raw_xml)

    results = []
    for entry in feed.entries:
        title = entry.get("title", "")
        summary = entry.get("summary", entry.get("description", ""))
        link = entry.get("link", "")
        published = entry.get("published", "")

        # Apply search filter if provided
        if search:
            search_lower = search.lower()
            if search_lower not in title.lower() and search_lower not in summary.lower():
                continue

        results.append(
            {
                "title": title,
                "summary": summary[:500],
                "link": link,
                "published": published,
            }
        )

        if len(results) >= limit:
            break

    cache.put(cache_key, results)
    return results
