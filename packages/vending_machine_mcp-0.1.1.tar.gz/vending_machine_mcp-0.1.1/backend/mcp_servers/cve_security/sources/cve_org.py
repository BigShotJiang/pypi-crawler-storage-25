"""CVE.org API client — official CVE Program registry.

Endpoint: https://cveawg.mitre.org/api/cve/{cve_id}
No authentication required for public reads.
Used as a fallback when NVD doesn't have the CVE yet.
"""

import httpx

from .. import cache

BASE_URL = "https://cveawg.mitre.org/api"
TIMEOUT = 20


async def get_cve(cve_id: str) -> dict | None:
    """Fetch a CVE record from CVE.org by ID."""
    cache_key = f"cveorg:{cve_id}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.get(f"{BASE_URL}/cve/{cve_id}")
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        data = resp.json()

    cna = data.get("containers", {}).get("cna", {})

    # Extract description
    descriptions = cna.get("descriptions", [])
    desc_en = next(
        (d.get("value", "") for d in descriptions if d.get("lang", "").startswith("en")),
        "",
    )

    # Extract affected products
    affected = []
    for a in cna.get("affected", []):
        product = a.get("product", "")
        vendor = a.get("vendor", "")
        versions = []
        for v in a.get("versions", []):
            status = v.get("status", "")
            ver = v.get("version", "")
            if status == "affected":
                versions.append(ver)
        affected.append(
            {
                "vendor": vendor,
                "product": product,
                "affected_versions": versions[:5],
            }
        )

    # Extract references
    references = [r.get("url", "") for r in cna.get("references", [])]

    # Extract metrics if available
    metrics = cna.get("metrics", [])
    cvss_score = None
    cvss_severity = None
    for m in metrics:
        for key in ("cvssV3_1", "cvssV3_0", "cvssV4_0"):
            if key in m:
                cvss_score = m[key].get("baseScore")
                cvss_severity = m[key].get("baseSeverity")
                break

    result = {
        "cve_id": data.get("cveMetadata", {}).get("cveId", cve_id),
        "state": data.get("cveMetadata", {}).get("state", ""),
        "description": desc_en,
        "affected": affected,
        "cvss_score": cvss_score,
        "severity": cvss_severity,
        "published": data.get("cveMetadata", {}).get("datePublished", ""),
        "last_modified": data.get("cveMetadata", {}).get("dateUpdated", ""),
        "references": references,
        "source": "cve.org",
    }

    cache.put(cache_key, result)
    return result
