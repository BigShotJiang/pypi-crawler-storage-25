"""OSV.dev API client — Google's open-source vulnerability database.

Endpoint: https://api.osv.dev/v1/query
No auth required. No rate limits.
Covers: npm, PyPI, Go, crates.io, Maven, RubyGems, NuGet, etc.
"""

import logging

import httpx

from .. import cache

logger = logging.getLogger("osv")

BASE_URL = "https://api.osv.dev"
TIMEOUT = 20


async def query_package(
    name: str,
    ecosystem: str,
    version: str | None = None,
) -> list[dict]:
    """Query OSV for vulnerabilities affecting a specific package."""
    cache_key = f"osv:pkg:{ecosystem}:{name}:{version or 'any'}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    body: dict = {
        "package": {
            "name": name,
            "ecosystem": ecosystem,
        },
    }
    if version:
        body["version"] = version

    results = []
    page_token = None

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        # Paginate (up to 3 pages to keep response bounded)
        for _ in range(3):
            if page_token:
                body["page_token"] = page_token

            resp = await client.post(f"{BASE_URL}/v1/query", json=body)
            resp.raise_for_status()
            data = resp.json()

            for vuln in data.get("vulns", []):
                severity_info = vuln.get("database_specific", {}).get("severity")
                cvss = None
                for s in vuln.get("severity", []):
                    if s.get("type") == "CVSS_V3":
                        cvss = s.get("score")

                affected_versions = []
                for affected in vuln.get("affected", []):
                    for r in affected.get("ranges", []):
                        for event in r.get("events", []):
                            if "introduced" in event:
                                affected_versions.append(f">= {event['introduced']}")
                            if "fixed" in event:
                                affected_versions.append(f"< {event['fixed']}")

                results.append(
                    {
                        "id": vuln.get("id", ""),
                        "summary": vuln.get("summary", ""),
                        "details": (vuln.get("details", "") or "")[:500],
                        "aliases": vuln.get("aliases", []),
                        "severity": severity_info or cvss,
                        "published": vuln.get("published", ""),
                        "modified": vuln.get("modified", ""),
                        "affected_versions": affected_versions[:5],
                        "references": [r.get("url", "") for r in vuln.get("references", [])[:3]],
                    }
                )

            page_token = data.get("next_page_token")
            if not page_token:
                break

    cache.put(cache_key, results)
    return results


async def query_malware(
    ecosystem: str | None = None,
    days_back: int = 90,
) -> list[dict]:
    """Query OSV for malicious packages (supply-chain attacks).

    OSV uses the MAL- prefix for malicious package advisories.
    We also look for vulns with 'malicious' in summary/details.
    """
    cache_key = f"osv:malware:{ecosystem or 'all'}:{days_back}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    # OSV doesn't have a direct "malware" filter, so we query by ecosystem
    # and filter client-side. For well-known ecosystems, MAL- prefixed IDs
    # are the malicious package advisories.
    # We use the batch endpoint for efficiency if we knew specific packages,
    # but for discovery we need to use the web/list approach.
    # Workaround: query vulns for common malicious package indicators.

    results = []

    # Strategy: search for recent vulns and filter for malware indicators
    # OSV doesn't support keyword search directly, so we query broadly
    # and filter. For a production system, you'd use the OSV BigQuery dataset.
    # Here we do a pragmatic approach: query a few known malware-heavy packages
    # or rely on the caller combining with GitHub Advisories.

    # Since OSV /v1/query needs a specific package, we'll return what we can
    # by querying for known supply-chain attack vectors
    known_supply_chain = [
        ("event-stream", "npm"),
        ("ua-parser-js", "npm"),
        ("colors", "npm"),
        ("faker", "npm"),
        ("node-ipc", "npm"),
        ("peacenotwar", "npm"),
    ]

    if ecosystem:
        known_supply_chain = [(p, e) for p, e in known_supply_chain if e == ecosystem]

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        for pkg_name, eco in known_supply_chain[:5]:
            body = {"package": {"name": pkg_name, "ecosystem": eco}}
            try:
                resp = await client.post(f"{BASE_URL}/v1/query", json=body)
                if resp.status_code != 200:
                    continue
                data = resp.json()
                for vuln in data.get("vulns", []):
                    summary = (vuln.get("summary", "") or "").lower()
                    vuln_id = vuln.get("id", "")
                    is_malware = (
                        vuln_id.startswith("MAL-")
                        or "malicious" in summary
                        or "supply chain" in summary
                        or "compromised" in summary
                    )
                    if is_malware:
                        results.append(
                            {
                                "id": vuln_id,
                                "package": pkg_name,
                                "ecosystem": eco,
                                "summary": vuln.get("summary", ""),
                                "published": vuln.get("published", ""),
                                "references": [r.get("url", "") for r in vuln.get("references", [])[:3]],
                            }
                        )
            except Exception:
                logger.debug("OSV query failed for package %s/%s, skipping", pkg_name, eco)
                continue

    cache.put(cache_key, results, ttl=600)  # cache malware results longer
    return results
