"""Simple in-memory TTL cache for API responses."""

import time
from typing import Any

_store: dict[str, tuple[Any, float]] = {}

DEFAULT_TTL = 300  # 5 minutes


def get(key: str) -> Any | None:
    """Return cached value if it exists and hasn't expired."""
    entry = _store.get(key)
    if entry is None:
        return None
    value, expiry = entry
    if time.time() > expiry:
        del _store[key]
        return None
    return value


def put(key: str, value: Any, ttl: int = DEFAULT_TTL) -> None:
    """Cache a value with a TTL in seconds."""
    _store[key] = (value, time.time() + ttl)


def clear() -> None:
    """Clear all cached entries."""
    _store.clear()
