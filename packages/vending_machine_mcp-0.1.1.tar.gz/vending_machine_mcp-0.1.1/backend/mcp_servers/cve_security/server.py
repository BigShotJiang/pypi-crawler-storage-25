#!/usr/bin/env python3
"""
CVE Security MCP Server — Multi-source vulnerability intelligence.

Aggregates data from:
  - NVD/NIST (CVE search, details)
  - OSV.dev (package-specific vulns, malware detection)
  - CVE.org (CVE detail fallback)
  - AWS Security Bulletins (RSS feed)
  - GitHub Advisory Database (ecosystem advisories)

Setup:
  pip install "mcp[cli]" httpx feedparser
  python server.py

Optional env vars:
  NVD_API_KEY    — increases NVD rate limit (5 → 50 req/30s)
  GITHUB_TOKEN   — required for GitHub Advisory Database

claude_desktop_config.json:
  {
    "mcpServers": {
      "cve-security": {
        "command": "python",
        "args": ["path/to/server.py"],
        "env": {
          "NVD_API_KEY": "your-key",
          "GITHUB_TOKEN": "ghp_your-token"
        }
      }
    }
  }
"""

import asyncio
import os
import sys

# Ensure the package is importable when run directly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp.server.fastmcp import FastMCP

from cve_security.sources import aws_bulletins, cve_org, github_advisory, nvd, osv

mcp = FastMCP("cve-security")


# ─── Tool 1: search_cves ────────────────────────────────────────────


@mcp.tool()
async def search_cves(
    keyword: str,
    severity: str = "",
    days_back: int = 30,
) -> str:
    """Search the National Vulnerability Database (NVD) for CVEs.

    Args:
        keyword: Search term (e.g. "xz-utils", "log4j", "npm")
        severity: Filter by CVSS severity — LOW, MEDIUM, HIGH, or CRITICAL
        days_back: How far back to search (max 120 days, default 30)
    """
    try:
        results = await nvd.search(
            keyword=keyword,
            severity=severity or None,
            days_back=days_back,
        )
    except Exception as e:
        return f"Error querying NVD: {e}"

    if not results:
        return f"No CVEs found for '{keyword}' in the last {days_back} days."

    lines = [f'## NVD Search: "{keyword}" ({len(results)} results)\n']
    for r in results:
        score = f"CVSS {r['cvss_score']}" if r.get("cvss_score") else "No score"
        sev = r.get("severity", "Unknown")
        lines.append(f"### {r['cve_id']} — {sev} ({score})")
        lines.append(f"Published: {r['published'][:10]}")
        lines.append(f"{r['description'][:300]}")
        if r.get("references"):
            lines.append(f"Ref: {r['references'][0]}")
        lines.append("")

    return "\n".join(lines)


# ─── Tool 2: get_cve ────────────────────────────────────────────────


@mcp.tool()
async def get_cve(cve_id: str) -> str:
    """Get full details for a specific CVE by ID.

    Args:
        cve_id: CVE identifier (e.g. "CVE-2024-3094", "CVE-2021-44228")
    """
    cve_id = cve_id.upper().strip()

    # Try NVD first (richer data), fall back to CVE.org
    try:
        result = await nvd.get_cve(cve_id)
    except Exception:
        result = None

    if not result:
        try:
            result = await cve_org.get_cve(cve_id)
        except Exception as e:
            return f"Error fetching {cve_id}: {e}"

    if not result:
        return f"CVE {cve_id} not found in NVD or CVE.org."

    lines = [f"## {result['cve_id']}"]

    if result.get("severity"):
        score_str = f"CVSS {result['cvss_score']}" if result.get("cvss_score") else ""
        lines.append(f"**Severity:** {result['severity']} {score_str}")

    if result.get("cvss_vector"):
        lines.append(f"**Vector:** `{result['cvss_vector']}`")

    lines.append(f"**Published:** {result.get('published', 'Unknown')[:10]}")
    lines.append(f"**Modified:** {result.get('last_modified', 'Unknown')[:10]}")
    lines.append("")
    lines.append(f"### Description\n{result.get('description', 'No description available.')}")

    if result.get("weaknesses"):
        lines.append(f"\n**Weaknesses:** {', '.join(result['weaknesses'])}")

    if result.get("affected"):
        lines.append("\n### Affected Products")
        for a in result["affected"][:5]:
            lines.append(
                f"- {a.get('vendor', '?')}/{a.get('product', '?')}: {', '.join(a.get('affected_versions', []))}"
            )

    if result.get("references"):
        lines.append("\n### References")
        for ref in result["references"][:5]:
            lines.append(f"- {ref}")

    return "\n".join(lines)


# ─── Tool 3: check_package ──────────────────────────────────────────


@mcp.tool()
async def check_package(
    name: str,
    ecosystem: str,
    version: str = "",
) -> str:
    """Check if a package has known vulnerabilities using OSV.dev.

    Args:
        name: Package name (e.g. "lodash", "requests", "tokio")
        ecosystem: Package ecosystem — npm, PyPI, Go, crates.io, Maven, RubyGems, NuGet
        version: Specific version to check (optional, checks all if omitted)
    """
    try:
        results = await osv.query_package(
            name=name,
            ecosystem=ecosystem,
            version=version or None,
        )
    except Exception as e:
        return f"Error querying OSV: {e}"

    if not results:
        ver_str = f" v{version}" if version else ""
        return f"No known vulnerabilities for {name}{ver_str} ({ecosystem})."

    lines = [f"## Vulnerabilities for {name} ({ecosystem}) — {len(results)} found\n"]
    for v in results[:15]:
        aliases = ", ".join(v.get("aliases", [])[:3])
        alias_str = f" ({aliases})" if aliases else ""
        lines.append(f"### {v['id']}{alias_str}")
        lines.append(f"{v.get('summary', 'No summary')}")
        if v.get("affected_versions"):
            lines.append(f"Affected: {' '.join(v['affected_versions'])}")
        if v.get("published"):
            lines.append(f"Published: {v['published'][:10]}")
        lines.append("")

    return "\n".join(lines)


# ─── Tool 4: list_supply_chain_attacks ───────────────────────────────


@mcp.tool()
async def list_supply_chain_attacks(
    ecosystem: str = "",
    days_back: int = 90,
) -> str:
    """List recent supply-chain attacks and malicious packages.

    Combines data from OSV.dev and GitHub Advisory Database.

    Args:
        ecosystem: Filter by ecosystem (npm, PyPI, etc.) — empty for all
        days_back: How far back to search (default 90 days)
    """
    # Fan out to both sources in parallel
    osv_task = osv.query_malware(
        ecosystem=ecosystem or None,
        days_back=days_back,
    )
    gh_task = github_advisory.search_malware(
        ecosystem=ecosystem or None,
        max_results=15,
    )

    try:
        osv_results, gh_results = await asyncio.gather(osv_task, gh_task)
    except Exception as e:
        return f"Error searching for supply-chain attacks: {e}"

    lines = ["## Recent Supply-Chain Attacks\n"]

    if osv_results:
        lines.append("### From OSV.dev")
        for r in osv_results[:10]:
            lines.append(f"- **{r['id']}** — {r.get('package', '?')} ({r.get('ecosystem', '?')})")
            lines.append(f"  {r.get('summary', '')[:200]}")
            if r.get("published"):
                lines.append(f"  Published: {r['published'][:10]}")
        lines.append("")

    if gh_results and not (len(gh_results) == 1 and "error" in gh_results[0]):
        lines.append("### From GitHub Advisories")
        for r in gh_results[:10]:
            pkgs = ", ".join(p["name"] for p in r.get("affected_packages", [])[:3])
            lines.append(f"- **{r['ghsa_id']}** ({r.get('severity', '?')}) — {pkgs}")
            lines.append(f"  {r.get('summary', '')[:200]}")
            if r.get("html_url"):
                lines.append(f"  {r['html_url']}")
        lines.append("")
    elif gh_results and "error" in gh_results[0]:
        lines.append(f"*GitHub Advisories: {gh_results[0]['error']}*\n")

    if not osv_results and (not gh_results or (gh_results and "error" in gh_results[0])):
        lines.append("No recent supply-chain attacks found for the given criteria.")

    return "\n".join(lines)


# ─── Tool 5: aws_security_bulletins ─────────────────────────────────


@mcp.tool()
async def get_aws_security_bulletins(
    limit: int = 10,
    search: str = "",
) -> str:
    """Get recent AWS security bulletins.

    Args:
        limit: Max bulletins to return (default 10)
        search: Filter by keyword in title/description (optional)
    """
    try:
        results = await aws_bulletins.fetch_bulletins(
            limit=limit,
            search=search or None,
        )
    except Exception as e:
        return f"Error fetching AWS bulletins: {e}"

    if not results:
        return "No AWS security bulletins found."

    lines = [f"## AWS Security Bulletins ({len(results)} results)\n"]
    for b in results:
        lines.append(f"### {b['title']}")
        lines.append(f"Published: {b.get('published', 'Unknown')}")
        lines.append(f"{b['summary'][:300]}")
        if b.get("link"):
            lines.append(f"Link: {b['link']}")
        lines.append("")

    return "\n".join(lines)


# ─── Tool 6: vulnerability_summary ──────────────────────────────────


@mcp.tool()
async def vulnerability_summary(
    package_name: str,
    ecosystem: str,
) -> str:
    """Get a comprehensive vulnerability summary for a package across all sources.

    Fans out to OSV.dev, NVD, and GitHub Advisories in parallel.

    Args:
        package_name: Package name (e.g. "express", "django", "serde")
        ecosystem: Package ecosystem — npm, PyPI, Go, crates.io, Maven
    """
    osv_task = osv.query_package(package_name, ecosystem)
    nvd_task = nvd.search(keyword=package_name, days_back=120)
    gh_task = github_advisory.search(ecosystem=ecosystem, keyword=package_name)

    try:
        osv_results, nvd_results, gh_results = await asyncio.gather(
            osv_task,
            nvd_task,
            gh_task,
        )
    except Exception as e:
        return f"Error generating summary: {e}"

    total = len(osv_results) + len(nvd_results)
    if gh_results and not (len(gh_results) == 1 and "error" in gh_results[0]):
        total += len(gh_results)

    lines = [
        f"## Vulnerability Summary: {package_name} ({ecosystem})",
        f"**Total findings:** {total}\n",
    ]

    # OSV
    lines.append(f"### OSV.dev — {len(osv_results)} vulnerabilities")
    if osv_results:
        critical = [v for v in osv_results if "CRITICAL" in str(v.get("severity", "")).upper()]
        high = [v for v in osv_results if "HIGH" in str(v.get("severity", "")).upper()]
        lines.append(
            f"Critical: {len(critical)} | High: {len(high)} | Other: {len(osv_results) - len(critical) - len(high)}"
        )
        for v in osv_results[:5]:
            lines.append(f"- {v['id']}: {v.get('summary', '')[:150]}")
    else:
        lines.append("No vulnerabilities found in OSV.")
    lines.append("")

    # NVD
    lines.append(f"### NVD/NIST — {len(nvd_results)} CVEs")
    if nvd_results:
        for v in nvd_results[:5]:
            sev = v.get("severity", "?")
            score = v.get("cvss_score", "?")
            lines.append(f"- {v['cve_id']} ({sev}, {score}): {v.get('description', '')[:150]}")
    else:
        lines.append("No CVEs found in NVD.")
    lines.append("")

    # GitHub
    if gh_results and not (len(gh_results) == 1 and "error" in gh_results[0]):
        lines.append(f"### GitHub Advisories — {len(gh_results)} advisories")
        for v in gh_results[:5]:
            lines.append(f"- {v['ghsa_id']} ({v.get('severity', '?')}): {v.get('summary', '')[:150]}")
    elif gh_results and "error" in gh_results[0]:
        lines.append(f"### GitHub Advisories\n*{gh_results[0]['error']}*")
    else:
        lines.append("### GitHub Advisories — 0 advisories")
    lines.append("")

    # Recommendation
    if total == 0:
        lines.append("**Assessment:** No known vulnerabilities. Package appears clean.")
    elif total <= 3:
        lines.append("**Assessment:** Low vulnerability count. Review individual findings.")
    else:
        lines.append(f"**Assessment:** {total} findings warrant review. Check for patches and updates.")

    return "\n".join(lines)


# ─── Resource: security dashboard ───────────────────────────────────


@mcp.resource("security://dashboard")
async def security_dashboard() -> str:
    """A live summary of today's critical security landscape."""
    nvd_task = nvd.search(keyword="critical", severity="CRITICAL", days_back=7)
    aws_task = aws_bulletins.fetch_bulletins(limit=5)

    try:
        critical_cves, aws_items = await asyncio.gather(nvd_task, aws_task)
    except Exception as e:
        return f"Error loading dashboard: {e}"

    lines = [
        "# Security Dashboard",
        "*Last 7 days*\n",
        f"## Critical CVEs — {len(critical_cves)} recent",
    ]

    for c in critical_cves[:10]:
        lines.append(f"- **{c['cve_id']}** (CVSS {c.get('cvss_score', '?')}): {c.get('description', '')[:120]}")

    lines.append(f"\n## AWS Security Bulletins — {len(aws_items)} recent")
    for b in aws_items:
        lines.append(f"- **{b['title']}** ({b.get('published', '')})")

    return "\n".join(lines)


# ─── Tool 7: scan_lockfile ───────────────────────────────────────────


@mcp.tool()
async def scan_lockfile(
    packages: list[dict],
) -> str:
    """Bulk-scan a list of dependencies for known vulnerabilities.

    Accepts a list of packages (from package-lock.json, requirements.txt, etc.)
    and checks each against OSV.dev. Returns a risk-ranked report.

    Args:
        packages: List of {"name": "lodash", "version": "4.17.20", "ecosystem": "npm"} objects
    """
    if not packages:
        return "No packages provided. Send a list of {name, version, ecosystem} objects."

    if len(packages) > 50:
        packages = packages[:50]
        truncated = True
    else:
        truncated = False

    results = []
    for pkg in packages:
        name = pkg.get("name", "")
        version = pkg.get("version", "")
        ecosystem = pkg.get("ecosystem", "npm")

        if not name:
            continue

        try:
            vulns = await osv.query_package(name, ecosystem, version or None)
            if vulns:
                results.append(
                    {
                        "package": name,
                        "version": version,
                        "ecosystem": ecosystem,
                        "vuln_count": len(vulns),
                        "severity": "CRITICAL"
                        if any("CRITICAL" in str(v.get("severity", "")).upper() for v in vulns)
                        else "HIGH"
                        if any("HIGH" in str(v.get("severity", "")).upper() for v in vulns)
                        else "MEDIUM",
                        "vulns": [{"id": v["id"], "summary": v.get("summary", "")[:100]} for v in vulns[:3]],
                    }
                )
        except Exception:
            results.append(
                {
                    "package": name,
                    "version": version,
                    "ecosystem": ecosystem,
                    "vuln_count": -1,
                    "severity": "ERROR",
                    "vulns": [],
                }
            )

    # Sort by severity (critical first)
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "ERROR": 3}
    results.sort(key=lambda r: severity_order.get(r["severity"], 99))

    vulnerable = [r for r in results if r["vuln_count"] > 0]
    clean = len(packages) - len(vulnerable) - len([r for r in results if r["vuln_count"] == -1])
    errors = len([r for r in results if r["vuln_count"] == -1])

    lines = [
        "## Lockfile Scan Results",
        f"**Scanned:** {len(packages)} packages" + (" (capped at 50)" if truncated else ""),
        f"**Vulnerable:** {len(vulnerable)} | **Clean:** {clean} | **Errors:** {errors}\n",
    ]

    if vulnerable:
        lines.append("### Vulnerable Packages (risk-ranked)\n")
        for r in vulnerable:
            lines.append(
                f"**{r['package']}** v{r['version']} ({r['ecosystem']}) — {r['severity']} ({r['vuln_count']} vulns)"
            )
            for v in r["vulns"]:
                lines.append(f"  - {v['id']}: {v['summary']}")
            lines.append("")
    else:
        lines.append("All scanned packages appear clean.")

    return "\n".join(lines)


if __name__ == "__main__":
    mcp.run()
