#!/usr/bin/env python3
"""
QA Tools MCP Server — Static analysis and verification toolchain.

Provides code quality tools that any agent (or the QA Auditor) can call:
  - biome_check     — Lint/format JS/TS/JSON via Biome
  - ruff_check      — Lint/format Python via Ruff
  - cfn_lint        — Validate CloudFormation templates
  - hadolint        — Lint Dockerfiles
  - dep_audit_npm   — Check npm dependencies for vulnerabilities/updates
  - dep_audit_python — Check Python deps for known vulnerabilities
  - secret_scan     — Regex scan for leaked keys/tokens/passwords
  - syntax_check    — Verify code actually parses (node/python/json/yaml)
  - detect_artifacts — Identify code languages and file types in output

All tools operate on TEXT input — no filesystem access needed.
They write temp files, run analysis, and clean up.

Setup:
  pip install "mcp[cli]" ruff
  npm install -g @biomejs/biome  (or use npx)

claude_desktop_config.json:
  {
    "mcpServers": {
      "qa-tools": {
        "command": "python",
        "args": ["path/to/server.py"]
      }
    }
  }
"""

import asyncio
import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("qa-tools")

# ─── Helpers ────────────────────────────────────────────────────────

# Discover tool paths — check common locations
_FRONTEND_ROOT = Path(__file__).resolve().parent.parent.parent
_BIOME_BIN = shutil.which("biome") or str(_FRONTEND_ROOT / "node_modules" / ".bin" / "biome")
_RUFF_BIN = shutil.which("ruff") or "ruff"
_HADOLINT_BIN = shutil.which("hadolint") or "hadolint"
_CFN_LINT_BIN = shutil.which("cfn-lint") or "cfn-lint"
_NODE_BIN = shutil.which("node") or "node"
_PYTHON_BIN = shutil.which("python3") or shutil.which("python") or "python3"
_NPX_BIN = shutil.which("npx") or "npx"


async def _run_tool(cmd: list[str], timeout: int = 30) -> tuple[int, str, str]:
    """Run a subprocess tool and return (returncode, stdout, stderr)."""
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return (
            proc.returncode or 0,
            stdout.decode("utf-8", errors="replace").strip(),
            stderr.decode("utf-8", errors="replace").strip(),
        )
    except TimeoutError:
        proc.kill()
        return (-1, "", f"Tool timed out after {timeout}s")
    except FileNotFoundError:
        return (-1, "", f"Tool not found: {cmd[0]}")
    except Exception as e:
        return (-1, "", f"Error running tool: {e}")


def _write_temp(content: str, suffix: str = ".txt") -> str:
    """Write content to a temp file and return the path."""
    fd, path = tempfile.mkstemp(suffix=suffix)
    with os.fdopen(fd, "w") as f:
        f.write(content)
    return path


def _tool_available(bin_path: str) -> bool:
    """Check if a binary exists and is executable."""
    return shutil.which(bin_path) is not None or os.path.isfile(bin_path)


# ─── Tool 1: biome_check ───────────────────────────────────────────


@mcp.tool()
async def biome_check(
    code: str,
    language: str = "typescript",
) -> str:
    """Lint and format-check JavaScript/TypeScript/JSON code using Biome.

    Returns lint errors, warnings, and formatting issues.

    Args:
        code: The source code to check
        language: "javascript", "typescript", "jsx", "tsx", or "json"
    """
    if not _tool_available(_BIOME_BIN):
        return "TOOL_UNAVAILABLE: Biome is not installed. Install via: npm install -g @biomejs/biome"

    ext_map = {
        "javascript": ".js",
        "js": ".js",
        "typescript": ".ts",
        "ts": ".ts",
        "jsx": ".jsx",
        "tsx": ".tsx",
        "json": ".json",
    }
    ext = ext_map.get(language.lower(), ".ts")
    tmp = _write_temp(code, suffix=ext)

    try:
        # Run biome check (lint + format)
        rc, stdout, stderr = await _run_tool([_BIOME_BIN, "check", "--no-errors-on-unmatched", tmp])

        if rc == 0 and not stdout and not stderr:
            return "PASS: No lint or formatting issues found."

        output_parts = []
        if stdout:
            output_parts.append(stdout)
        if stderr and "WARN" not in stderr:
            output_parts.append(stderr)

        result = "\n".join(output_parts) if output_parts else "PASS: Clean."

        # Count issues
        error_count = result.count("error") + result.count("ERROR")
        warn_count = result.count("warning") + result.count("WARN")

        summary = f"Biome found {error_count} error(s), {warn_count} warning(s)."
        return f"{summary}\n\n{result}"
    finally:
        os.unlink(tmp)


# ─── Tool 2: ruff_check ────────────────────────────────────────────


@mcp.tool()
async def ruff_check(
    code: str,
    fix_suggestions: bool = True,
) -> str:
    """Lint Python code using Ruff (extremely fast Python linter).

    Returns lint violations with fix suggestions.

    Args:
        code: Python source code to check
        fix_suggestions: Include auto-fix suggestions (default True)
    """
    if not _tool_available(_RUFF_BIN):
        return "TOOL_UNAVAILABLE: Ruff is not installed. Install via: pip install ruff"

    tmp = _write_temp(code, suffix=".py")

    try:
        # Lint check
        cmd = [_RUFF_BIN, "check", "--output-format=text"]
        if fix_suggestions:
            cmd.append("--show-fixes")
        cmd.append(tmp)

        rc, stdout, _stderr = await _run_tool(cmd)

        # Also check formatting
        fmt_rc, fmt_out, _fmt_err = await _run_tool([_RUFF_BIN, "format", "--check", "--diff", tmp])

        parts = []

        if rc == 0 and not stdout:
            parts.append("Lint: PASS — No violations found.")
        else:
            violation_count = len([line for line in stdout.splitlines() if line.strip() and "Found" not in line])
            parts.append(f"Lint: {violation_count} violation(s) found.\n{stdout}")

        if fmt_rc == 0:
            parts.append("Format: PASS — Code is properly formatted.")
        else:
            parts.append(f"Format: Issues found.\n{fmt_out}")

        return "\n\n".join(parts)
    finally:
        os.unlink(tmp)


# ─── Tool 3: cfn_lint ──────────────────────────────────────────────


@mcp.tool()
async def cfn_lint(
    template: str,
    fmt: str = "yaml",
) -> str:
    """Validate a CloudFormation template using cfn-lint.

    Checks for syntax errors, invalid resource types, and best practices.
    No AWS credentials required.

    Args:
        template: The CloudFormation template content
        fmt: "yaml" or "json" (default "yaml")
    """
    if not _tool_available(_CFN_LINT_BIN):
        return "TOOL_UNAVAILABLE: cfn-lint is not installed. Install via: pip install cfn-lint"

    ext = ".yaml" if fmt.lower() in ("yaml", "yml") else ".json"
    tmp = _write_temp(template, suffix=ext)

    try:
        rc, stdout, stderr = await _run_tool([_CFN_LINT_BIN, tmp, "-f", "parseable"])

        if rc == 0 and not stdout:
            return "PASS: CloudFormation template is valid."

        output = stdout or stderr
        error_count = output.count(":E")
        warn_count = output.count(":W")
        info_count = output.count(":I")

        return f"cfn-lint: {error_count} error(s), {warn_count} warning(s), {info_count} info.\n\n{output}"
    finally:
        os.unlink(tmp)


# ─── Tool 4: hadolint ──────────────────────────────────────────────


@mcp.tool()
async def hadolint(
    dockerfile: str,
) -> str:
    """Lint a Dockerfile using Hadolint for best practices.

    Checks for common anti-patterns like using latest tag,
    running as root, missing health checks, etc.

    Args:
        dockerfile: The Dockerfile content to check
    """
    if not _tool_available(_HADOLINT_BIN):
        return "TOOL_UNAVAILABLE: hadolint is not installed. Install via: brew install hadolint"

    tmp = _write_temp(dockerfile, suffix="")

    try:
        rc, stdout, stderr = await _run_tool([_HADOLINT_BIN, tmp])

        if rc == 0 and not stdout:
            return "PASS: Dockerfile follows best practices."

        output = stdout or stderr
        issue_count = len([line for line in output.splitlines() if line.strip()])
        return f"hadolint: {issue_count} issue(s) found.\n\n{output}"
    finally:
        os.unlink(tmp)


# ─── Tool 5: dep_audit_npm ────────────────────────────────────────


@mcp.tool()
async def dep_audit_npm(
    package_json: str,
) -> str:
    """Check npm package.json dependencies for outdated or vulnerable packages.

    Runs npm-check-updates to find available updates and checks for
    known vulnerabilities using npm audit (dry-run, no install).

    Args:
        package_json: The content of package.json
    """
    # Validate JSON first
    try:
        pkg = json.loads(package_json)
    except json.JSONDecodeError as e:
        return f"FAIL: Invalid package.json — {e}"

    deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
    if not deps:
        return "SKIP: No dependencies found in package.json."

    tmpdir = tempfile.mkdtemp(prefix="qa_npm_")

    try:
        # Write package.json
        pkg_path = os.path.join(tmpdir, "package.json")
        with open(pkg_path, "w") as f:
            json.dump(pkg, f)

        parts = []

        # Run npx npm-check-updates (no install needed)
        _rc, stdout, stderr = await _run_tool(
            [_NPX_BIN, "-y", "npm-check-updates", "--packageFile", pkg_path],
            timeout=60,
        )

        if stdout:
            outdated_lines = [line for line in stdout.splitlines() if "→" in line or "->" in line]
            if outdated_lines:
                parts.append(f"Outdated packages ({len(outdated_lines)}):\n" + "\n".join(outdated_lines))
            else:
                parts.append("Dependencies: All up to date.")
        elif stderr and "not found" in stderr.lower():
            parts.append("npm-check-updates: Not available (npx failed).")
        else:
            parts.append("Dependencies: All up to date.")

        # Extract dependency list for vulnerability context
        dep_list = [f"  {name}@{ver}" for name, ver in list(deps.items())[:30]]
        parts.append(f"\nScanned {len(deps)} dependencies:\n" + "\n".join(dep_list))

        return "\n\n".join(parts)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


# ─── Tool 6: dep_audit_python ──────────────────────────────────────


@mcp.tool()
async def dep_audit_python(
    requirements_txt: str,
) -> str:
    """Check Python requirements.txt for known vulnerabilities using pip-audit.

    Args:
        requirements_txt: Content of requirements.txt (one package per line)
    """
    pip_audit = shutil.which("pip-audit")
    if not pip_audit:
        # Fall back to basic version check
        lines = [line.strip() for line in requirements_txt.splitlines() if line.strip() and not line.startswith("#")]
        return (
            f"TOOL_UNAVAILABLE: pip-audit not installed. Install via: pip install pip-audit\n"
            f"Parsed {len(lines)} dependencies from requirements.txt:\n" + "\n".join(f"  {line}" for line in lines[:30])
        )

    tmp = _write_temp(requirements_txt, suffix=".txt")

    try:
        rc, stdout, stderr = await _run_tool(
            [pip_audit, "-r", tmp, "--format", "columns"],
            timeout=120,
        )

        if rc == 0:
            return f"PASS: No known vulnerabilities in {len(requirements_txt.splitlines())} dependencies."

        return f"pip-audit results:\n{stdout}\n{stderr}".strip()
    finally:
        os.unlink(tmp)


# ─── Tool 7: secret_scan ──────────────────────────────────────────


@mcp.tool()
async def secret_scan(
    code: str,
) -> str:
    """Scan code for hardcoded secrets, API keys, tokens, and passwords.

    Uses pattern matching to detect common secret formats.
    Zero false negatives > zero false positives — flags anything suspicious.

    Args:
        code: Source code to scan
    """
    patterns = [
        # AWS
        (r"AKIA[0-9A-Z]{16}", "AWS Access Key ID"),
        (r"(?:aws_secret_access_key|AWS_SECRET)\s*[=:]\s*['\"]?[A-Za-z0-9/+=]{40}", "AWS Secret Key"),
        # GitHub
        (r"ghp_[A-Za-z0-9_]{36}", "GitHub Personal Access Token"),
        (r"github_pat_[A-Za-z0-9_]{22}_[A-Za-z0-9_]{59}", "GitHub Fine-Grained PAT"),
        (r"ghs_[A-Za-z0-9_]{36}", "GitHub App Token"),
        # OpenAI / Anthropic / Generic AI
        (r"sk-[A-Za-z0-9]{20}T3BlbkFJ[A-Za-z0-9]{20}", "OpenAI API Key"),
        (r"sk-ant-[A-Za-z0-9\-_]{80,}", "Anthropic API Key"),
        (r"sk-or-v1-[a-f0-9]{64}", "OpenRouter API Key"),
        # Stripe
        (r"sk_live_[A-Za-z0-9]{24,}", "Stripe Secret Key"),
        (r"sk_test_[A-Za-z0-9]{24,}", "Stripe Test Key"),
        # Slack
        (r"xoxb-[0-9]{10,13}-[0-9]{10,13}-[A-Za-z0-9]{24}", "Slack Bot Token"),
        (r"xoxp-[0-9]{10,13}-[0-9]{10,13}-[A-Za-z0-9]{24}", "Slack User Token"),
        # Database URLs
        (r"(?:mysql|postgres|postgresql|mongodb|redis):\/\/[^\s'\"]+:[^\s'\"]+@", "Database Connection String"),
        # Private keys
        (r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", "Private Key"),
        # JWT (long base64 with dots)
        (r"eyJ[A-Za-z0-9_-]{20,}\.eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}", "JSON Web Token"),
        # Generic patterns
        (r"(?:password|passwd|pwd)\s*[=:]\s*['\"][^'\"]{8,}['\"]", "Hardcoded Password"),
        (r"(?:api[_-]?key|apikey|api[_-]?secret)\s*[=:]\s*['\"][A-Za-z0-9]{16,}['\"]", "API Key Assignment"),
        (r"Bearer\s+[A-Za-z0-9\-_.~+/]+=*", "Bearer Token"),
    ]

    findings = []
    lines = code.splitlines()

    for line_num, line in enumerate(lines, 1):
        for pattern, label in patterns:
            matches = re.finditer(pattern, line, re.IGNORECASE)
            for match in matches:
                # Mask the middle of the secret
                secret = match.group(0)
                masked = secret[:6] + "..." + secret[-4:] if len(secret) > 12 else secret[:4] + "..."
                findings.append(
                    {
                        "line": line_num,
                        "type": label,
                        "masked": masked,
                    }
                )

    if not findings:
        return "PASS: No hardcoded secrets detected."

    lines_out = [f"FAIL: {len(findings)} potential secret(s) found!\n"]
    for f in findings:
        lines_out.append(f"  Line {f['line']}: {f['type']} — {f['masked']}")

    lines_out.append("\nThese values should be moved to environment variables or a secrets manager.")
    return "\n".join(lines_out)


# ─── Tool 8: syntax_check ──────────────────────────────────────────


@mcp.tool()
async def syntax_check(
    code: str,
    language: str,
) -> str:
    """Verify that code parses without syntax errors.

    Runs the language's native parser/compiler in check mode.
    Does NOT execute the code — only validates syntax.

    Args:
        code: Source code to check
        language: "javascript", "typescript", "python", "json", or "yaml"
    """
    lang = language.lower().strip()

    if lang in ("json",):
        try:
            json.loads(code)
            return "PASS: Valid JSON."
        except json.JSONDecodeError as e:
            return f"FAIL: Invalid JSON at line {e.lineno}, col {e.colno} — {e.msg}"

    if lang in ("yaml", "yml"):
        try:
            import yaml

            yaml.safe_load(code)
            return "PASS: Valid YAML."
        except ImportError:
            return "TOOL_UNAVAILABLE: PyYAML not installed."
        except yaml.YAMLError as e:
            return f"FAIL: Invalid YAML — {e}"

    if lang in ("python", "py"):
        tmp = _write_temp(code, suffix=".py")
        try:
            rc, stdout, stderr = await _run_tool([_PYTHON_BIN, "-m", "py_compile", tmp])
            if rc == 0:
                return "PASS: Valid Python syntax."
            return f"FAIL: Python syntax error.\n{stderr}"
        finally:
            os.unlink(tmp)

    if lang in ("javascript", "js"):
        tmp = _write_temp(code, suffix=".js")
        try:
            rc, stdout, stderr = await _run_tool([_NODE_BIN, "--check", tmp])
            if rc == 0:
                return "PASS: Valid JavaScript syntax."
            return f"FAIL: JavaScript syntax error.\n{stderr}"
        finally:
            os.unlink(tmp)

    if lang in ("typescript", "ts", "tsx", "jsx"):
        # TypeScript check requires tsc — fall back to biome parse
        if _tool_available(_BIOME_BIN):
            ext = f".{lang}" if lang in ("tsx", "jsx") else ".ts"
            tmp = _write_temp(code, suffix=ext)
            try:
                rc, stdout, stderr = await _run_tool([_BIOME_BIN, "check", "--no-errors-on-unmatched", tmp])
                if rc == 0:
                    return f"PASS: Valid {language} (parsed by Biome)."
                return f"Issues found:\n{stdout}\n{stderr}".strip()
            finally:
                os.unlink(tmp)
        return "TOOL_UNAVAILABLE: Neither tsc nor Biome available for TypeScript checking."

    return f"UNSUPPORTED: Language '{language}' is not supported. Use: python, javascript, typescript, json, yaml."


# ─── Tool 9: detect_artifacts ─────────────────────────────────────


@mcp.tool()
async def detect_artifacts(
    output: str,
) -> str:
    """Detect code languages, file types, and structures in agent output.

    Scans text for fenced code blocks, file headers, shebang lines,
    and language-specific patterns. Returns a list of detected artifacts
    with their type and location.

    Use this to determine which QA tools to run on an agent's output.

    Args:
        output: The full agent output text to analyze
    """
    artifacts = []

    # Fenced code blocks: ```language ... ```
    fenced_pattern = re.compile(r"```(\w+)?\s*\n(.*?)```", re.DOTALL)
    for match in fenced_pattern.finditer(output):
        lang = match.group(1) or "unknown"
        code = match.group(2).strip()
        start_line = output[: match.start()].count("\n") + 1
        artifacts.append(
            {
                "type": "fenced_code_block",
                "language": lang.lower(),
                "start_line": start_line,
                "length": len(code.splitlines()),
                "preview": code[:80],
            }
        )

    # Shebang detection
    shebang_pattern = re.compile(r"^#!(/usr/bin/env\s+)?(\w+)", re.MULTILINE)
    for match in shebang_pattern.finditer(output):
        interpreter = match.group(2)
        lang_map = {"python3": "python", "python": "python", "node": "javascript", "bash": "bash", "sh": "bash"}
        artifacts.append(
            {
                "type": "shebang",
                "language": lang_map.get(interpreter, interpreter),
                "start_line": output[: match.start()].count("\n") + 1,
            }
        )

    # Dockerfile detection
    if re.search(r"^FROM\s+\w+", output, re.MULTILINE):
        artifacts.append({"type": "dockerfile", "language": "dockerfile"})

    # CloudFormation detection
    if re.search(r"AWSTemplateFormatVersion|Resources:\s*\n\s+\w+:", output):
        artifacts.append({"type": "cloudformation", "language": "yaml"})

    # SAM template detection
    if re.search(r"Transform:\s*AWS::Serverless", output):
        artifacts.append({"type": "sam_template", "language": "yaml"})

    # Terraform detection
    if re.search(r'(?:resource|provider|module)\s+"[\w-]+"', output):
        artifacts.append({"type": "terraform", "language": "hcl"})

    # package.json detection
    if '"dependencies"' in output and '"name"' in output:
        artifacts.append({"type": "package_json", "language": "json"})

    # requirements.txt pattern
    if re.search(r"^[\w-]+==[0-9]+\.\d+", output, re.MULTILINE):
        artifacts.append({"type": "requirements_txt", "language": "text"})

    if not artifacts:
        return json.dumps({"artifacts": [], "summary": "No code artifacts detected — text-only output."})

    # Deduplicate by language
    languages = list({a["language"] for a in artifacts})

    # Map languages to recommended QA tools
    tool_map = {
        "javascript": ["biome_check", "syntax_check", "secret_scan"],
        "typescript": ["biome_check", "syntax_check", "secret_scan"],
        "jsx": ["biome_check", "syntax_check", "secret_scan"],
        "tsx": ["biome_check", "syntax_check", "secret_scan"],
        "python": ["ruff_check", "syntax_check", "secret_scan"],
        "json": ["syntax_check"],
        "yaml": ["syntax_check"],
        "dockerfile": ["hadolint", "secret_scan"],
        "hcl": ["secret_scan"],
        "bash": ["secret_scan"],
    }

    recommended_tools = set()
    for lang in languages:
        recommended_tools.update(tool_map.get(lang, ["secret_scan"]))

    return json.dumps(
        {
            "artifacts": artifacts,
            "languages": languages,
            "recommended_tools": sorted(recommended_tools),
            "summary": f"Found {len(artifacts)} artifact(s) in {len(languages)} language(s): {', '.join(languages)}",
        },
        indent=2,
    )


# ─── Tool 10: gitignore_audit ─────────────────────────────────────

# Files/dirs that should ALWAYS be in .gitignore for each project type
_GITIGNORE_RULES: dict[str, list[tuple[str, str]]] = {
    # (pattern_to_check, description)
    "universal": [
        (".env", "Environment variables (may contain secrets)"),
        (".env.*", "Environment variable variants (.env.local, .env.production)"),
        ("*.pem", "SSL/TLS certificates and private keys"),
        ("*.key", "Private key files"),
        ("*.p12", "PKCS#12 certificate bundles"),
        ("*.pfx", "Personal Information Exchange files"),
        (".DS_Store", "macOS metadata files"),
        ("Thumbs.db", "Windows thumbnail cache"),
        ("*.log", "Log files (may contain sensitive data)"),
    ],
    "node": [
        ("node_modules", "npm/yarn dependencies (huge, reproducible from package.json)"),
        ("node_modules/", "npm/yarn dependencies (directory form)"),
        (".npm", "npm cache"),
        (".yarn/cache", "Yarn cache"),
        ("dist", "Build output"),
        ("build", "Build output"),
        (".next", "Next.js build cache"),
        (".nuxt", "Nuxt.js build cache"),
        ("coverage", "Test coverage reports"),
        (".turbo", "Turborepo cache"),
    ],
    "python": [
        ("__pycache__", "Python bytecode cache"),
        ("__pycache__/", "Python bytecode cache (directory form)"),
        ("*.pyc", "Compiled Python files"),
        ("*.pyo", "Optimized Python files"),
        ("venv", "Virtual environment"),
        ("venv/", "Virtual environment (directory form)"),
        (".venv", "Virtual environment (dotfile variant)"),
        ("*.egg-info", "Python package metadata"),
        ("dist/", "Python distribution archives"),
        (".mypy_cache", "mypy type checking cache"),
        (".ruff_cache", "Ruff linter cache"),
        (".pytest_cache", "Pytest cache"),
    ],
    "cloud": [
        (".aws/credentials", "AWS credentials file"),
        (".aws/config", "AWS config (may contain account IDs)"),
        ("*.tfstate", "Terraform state (contains all resource details + secrets)"),
        ("*.tfstate.*", "Terraform state backups"),
        ("*.tfvars", "Terraform variables (often contain secrets)"),
        (".terraform/", "Terraform provider cache"),
        ("samconfig.toml", "SAM deployment config (may contain account IDs)"),
        ("cdk.out/", "AWS CDK synthesis output"),
    ],
    "docker": [
        (".dockerignore", "Not gitignored but should EXIST alongside Dockerfile"),
    ],
    "ide": [
        (".idea/", "JetBrains IDE config"),
        (".vscode/settings.json", "VS Code user-specific settings"),
        ("*.swp", "Vim swap files"),
        ("*.swo", "Vim swap files"),
        ("*.sublime-workspace", "Sublime Text workspace"),
    ],
}


@mcp.tool()
async def gitignore_audit(
    gitignore_content: str = "",
    project_files: str = "",
    project_type: str = "auto",
) -> str:
    """Audit a .gitignore file for missing critical exclusions.

    Checks that sensitive files (.env, credentials, keys), build artifacts
    (node_modules, __pycache__), and cloud state files (*.tfstate) are
    properly excluded.

    Args:
        gitignore_content: The content of the .gitignore file (empty string if none exists)
        project_files: Comma-separated list of files/dirs in the project root
                       (helps auto-detect project type). E.g. "package.json,src/,tsconfig.json"
        project_type: "node", "python", "cloud", "fullstack", or "auto" (default: auto-detect)
    """
    files_list = [f.strip() for f in project_files.split(",") if f.strip()] if project_files else []
    gitignore_lines = set()
    if gitignore_content:
        for line in gitignore_content.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                # Normalize: remove trailing slashes for comparison
                gitignore_lines.add(stripped.rstrip("/"))
                gitignore_lines.add(stripped)

    # Auto-detect project type
    detected_types = {"universal"}
    if project_type == "auto":
        file_str = " ".join(files_list).lower()
        if any(f in file_str for f in ("package.json", "node_modules", "tsconfig", "next.config", ".npmrc")):
            detected_types.add("node")
        if any(f in file_str for f in ("requirements.txt", "setup.py", "pyproject.toml", "pipfile", "__pycache__")):
            detected_types.add("python")
        if any(f in file_str for f in ("terraform", ".tf", "cloudformation", "template.yaml", "samconfig", "cdk.json")):
            detected_types.add("cloud")
        if any(f in file_str for f in ("dockerfile", "docker-compose", ".dockerignore")):
            detected_types.add("docker")
        detected_types.add("ide")
    else:
        detected_types = {"universal", project_type, "ide"}

    # Check each rule
    missing: list[dict] = []
    present: list[str] = []
    warnings: list[str] = []

    for ptype in detected_types:
        rules = _GITIGNORE_RULES.get(ptype, [])
        for pattern, description in rules:
            # Check if pattern or a broader version is in .gitignore
            normalized = pattern.rstrip("/")
            found = False
            for gi_line in gitignore_lines:
                gi_norm = gi_line.rstrip("/")
                # Exact match, or gitignore has a wildcard that covers it
                if gi_norm == normalized:
                    found = True
                    break
                # e.g. "*.env*" covers ".env.local"
                if gi_line.startswith("*") and normalized.endswith(gi_line.lstrip("*").rstrip("*")):
                    found = True
                    break
                # e.g. ".env*" covers ".env.production"
                if normalized.startswith(gi_line.rstrip("*")) and gi_line.endswith("*"):
                    found = True
                    break

            if found:
                present.append(pattern)
            else:
                severity = (
                    "CRITICAL"
                    if ptype == "universal" and pattern in (".env", "*.pem", "*.key")
                    else "CRITICAL"
                    if "credentials" in pattern or "tfstate" in pattern
                    else "HIGH"
                    if ptype in ("node", "python") and pattern in ("node_modules", "__pycache__", "venv")
                    else "MEDIUM"
                )
                missing.append(
                    {
                        "pattern": pattern,
                        "description": description,
                        "severity": severity,
                        "category": ptype,
                    }
                )

    # No .gitignore at all
    if not gitignore_content.strip():
        warnings.append("CRITICAL: No .gitignore file found! All files are at risk of being committed.")

    # .env files exist in project but not gitignored
    env_files = [f for f in files_list if f.startswith(".env")]
    if env_files and ".env" not in gitignore_lines:
        warnings.append(f"CRITICAL: .env files detected in project ({', '.join(env_files)}) but NOT in .gitignore!")

    # Sort missing by severity
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2}
    missing.sort(key=lambda m: severity_order.get(m["severity"], 99))

    # Build report
    lines = ["## .gitignore Audit Report\n"]
    lines.append(f"**Project types detected:** {', '.join(sorted(detected_types))}")
    lines.append(f"**Gitignore entries parsed:** {len(gitignore_lines)}")
    lines.append(f"**Rules checked:** {len(present) + len(missing)}")
    lines.append(f"**Covered:** {len(present)} | **Missing:** {len(missing)}\n")

    if warnings:
        lines.append("### Warnings")
        for w in warnings:
            lines.append(f"- {w}")
        lines.append("")

    if missing:
        critical = [m for m in missing if m["severity"] == "CRITICAL"]
        high = [m for m in missing if m["severity"] == "HIGH"]
        medium = [m for m in missing if m["severity"] == "MEDIUM"]

        if critical:
            lines.append("### CRITICAL — Must Add")
            for m in critical:
                lines.append(f"- `{m['pattern']}` — {m['description']}")
            lines.append("")

        if high:
            lines.append("### HIGH — Should Add")
            for m in high:
                lines.append(f"- `{m['pattern']}` — {m['description']}")
            lines.append("")

        if medium:
            lines.append("### MEDIUM — Recommended")
            for m in medium:
                lines.append(f"- `{m['pattern']}` — {m['description']}")
            lines.append("")

        # Generate the fix
        lines.append("### Suggested .gitignore additions")
        lines.append("```gitignore")
        lines.append("# === QA Auditor Recommendations ===")
        current_cat = ""
        for m in missing:
            if m["category"] != current_cat:
                current_cat = m["category"]
                lines.append(f"\n# {current_cat}")
            lines.append(m["pattern"])
        lines.append("```")

        verdict = "FAIL" if critical else "WARN" if high else "PASS"
        lines.insert(0, f"{verdict}: {len(critical)} critical, {len(high)} high, {len(medium)} medium issues.\n")
    else:
        lines.insert(0, "PASS: .gitignore covers all recommended exclusions.\n")

    return "\n".join(lines)


# ─── Tool 11: key_hygiene_audit ───────────────────────────────────


@mcp.tool()
async def key_hygiene_audit(
    code: str,
    project_files: str = "",
) -> str:
    """Audit code for API key and credential management best practices.

    Goes beyond secret_scan (which catches literal keys) to check
    HOW credentials are loaded and managed:
    - Are keys loaded from environment variables?
    - Is there a .env.example with placeholder values?
    - Are credentials passed via function params (injectable) or hardcoded?
    - Is there a secrets manager integration?
    - Are there any credential rotation patterns?

    Args:
        code: Source code to audit (can be multiple files concatenated)
        project_files: Comma-separated list of project files (helps context)
    """
    files_list = [f.strip() for f in project_files.split(",") if f.strip()] if project_files else []
    lines = code.splitlines()
    findings: list[dict] = []
    good_practices: list[str] = []

    # ── Check 1: Hardcoded credential assignments ──
    hardcoded_patterns = [
        # Direct string assignment to key-like variables
        (
            r"""(?:api[_-]?key|secret[_-]?key|access[_-]?key|auth[_-]?token|password|passwd|credentials?)\s*[=:]\s*['"][A-Za-z0-9_\-./+=]{8,}['"]""",
            "Hardcoded credential assignment",
        ),
        # Dict/object literal with credential keys
        (
            r"""['"](?:api[_-]?key|secret|token|password|auth)['"]:\s*['"][A-Za-z0-9_\-./+=]{8,}['"]""",
            "Credential in dict/object literal",
        ),
        # Connection strings with embedded passwords
        (
            r"""(?:connection[_-]?string|database[_-]?url|dsn)\s*[=:]\s*['"](?:mysql|postgres|mongodb|redis)://\w+:[^'\"]+@""",
            "Database connection string with embedded password",
        ),
    ]

    for line_num, line in enumerate(lines, 1):
        for pattern, label in hardcoded_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                # Exclude common false positives
                if any(
                    fp in line.lower()
                    for fp in [
                        "example",
                        "placeholder",
                        "your-",
                        "xxx",
                        "changeme",
                        "test",
                        "mock",
                        "fake",
                        "dummy",
                        "sample",
                        "todo",
                        "process.env",
                        "os.environ",
                        "os.getenv",
                        "env(",
                    ]
                ):
                    continue
                findings.append(
                    {
                        "line": line_num,
                        "type": label,
                        "severity": "CRITICAL",
                        "snippet": line.strip()[:80],
                    }
                )

    # ── Check 2: Environment variable usage (good!) ──
    env_patterns = {
        "python_os_environ": r"os\.environ(?:\.get)?\s*\(\s*['\"]",
        "python_os_getenv": r"os\.getenv\s*\(\s*['\"]",
        "python_dotenv": r"(?:load_dotenv|dotenv_values)",
        "node_process_env": r"process\.env\.\w+",
        "node_dotenv": r"require\s*\(\s*['\"]dotenv['\"]",
        "generic_env": r"(?:from_env|get_env|read_env|env\[)",
    }

    env_usage_count = 0
    for line in lines:
        for _name, pattern in env_patterns.items():
            if re.search(pattern, line):
                env_usage_count += 1
                break

    if env_usage_count > 0:
        good_practices.append(f"Environment variables used ({env_usage_count} instances)")

    # ── Check 3: Secrets manager integration (great!) ──
    secrets_managers = {
        "AWS Secrets Manager": r"(?:secretsmanager|SecretsManager|get_secret_value)",
        "AWS SSM Parameter Store": r"(?:ssm\.get_parameter|SSMClient|parameter_store)",
        "HashiCorp Vault": r"(?:hvac\.Client|vault_client|VAULT_ADDR|vault\.read)",
        "Azure Key Vault": r"(?:SecretClient|KeyVaultSecret|azure.*keyvault)",
        "GCP Secret Manager": r"(?:secretmanager|SecretManagerServiceClient|access_secret_version)",
        "1Password CLI": r"(?:op\s+read|op://|onepassword)",
        "Doppler": r"(?:doppler|DOPPLER_TOKEN)",
    }

    for name, pattern in secrets_managers.items():
        if re.search(pattern, code, re.IGNORECASE):
            good_practices.append(f"Secrets manager detected: {name}")

    # ── Check 4: .env.example presence ──
    has_env_example = any(f in files_list for f in [".env.example", ".env.sample", ".env.template"])
    if has_env_example:
        good_practices.append(".env.example file present (documents required variables)")
    elif env_usage_count > 0:
        findings.append(
            {
                "line": 0,
                "type": "Missing .env.example",
                "severity": "MEDIUM",
                "snippet": "Project uses env vars but has no .env.example for documentation",
            }
        )

    # ── Check 5: Credential passing patterns ──
    # Good: passing via function params (dependency injection)
    injection_patterns = [
        (
            r"def\s+\w+\([^)]*(?:api_key|token|credentials?|secret|password)\s*[:=]",
            "Python function accepts credentials as params",
        ),
        (
            r"(?:constructor|function)\s*\([^)]*(?:apiKey|token|credentials?|secret|password)",
            "JS/TS function accepts credentials as params",
        ),
        (r"(?:interface|type)\s+\w+.*(?:apiKey|token|credentials?|secret)", "Credential type/interface defined"),
    ]

    for pattern, label in injection_patterns:
        if re.search(pattern, code):
            good_practices.append(f"Dependency injection: {label}")

    # ── Check 6: Key rotation / expiry patterns ──
    rotation_patterns = [
        (r"(?:rotate|refresh|renew)[_-]?(?:key|token|credential|secret)", "Key rotation logic"),
        (r"(?:expir|ttl|time_to_live|max_age|valid_until)", "Token expiry handling"),
        (r"(?:assume_role|get_session_token|sts\.)", "AWS STS temporary credentials"),
    ]

    for pattern, label in rotation_patterns:
        if re.search(pattern, code, re.IGNORECASE):
            good_practices.append(f"Rotation/expiry: {label}")

    # ── Check 7: Credential logging risk ──
    logging_risks = []
    for line_num, line in enumerate(lines, 1):
        # Check if credential variables are passed to print/log/console
        if re.search(
            r"(?:print|log(?:ger)?\.(?:info|debug|warn|error)|console\.log)\s*\(.*(?:api_key|token|password|secret|credential|apiKey)",
            line,
            re.IGNORECASE,
        ) and not any(mask in line.lower() for mask in ["mask", "redact", "***", "...", "[:4]", "[:6]"]):
            logging_risks.append(
                {
                    "line": line_num,
                    "type": "Credential may be logged",
                    "severity": "HIGH",
                    "snippet": line.strip()[:80],
                }
            )

    findings.extend(logging_risks)

    # ── Build report ──
    report = ["## API Key & Credential Hygiene Report\n"]

    # Score
    critical = len([f for f in findings if f["severity"] == "CRITICAL"])
    high = len([f for f in findings if f["severity"] == "HIGH"])
    medium = len([f for f in findings if f["severity"] == "MEDIUM"])

    if critical > 0:
        verdict = "FAIL"
    elif high > 0 or (medium > 0 and not good_practices):
        verdict = "WARN"
    else:
        verdict = "PASS"

    report.insert(0, f"{verdict}: {critical} critical, {high} high, {medium} medium findings.\n")

    # Good practices
    if good_practices:
        report.append("### Good Practices Detected")
        for gp in good_practices:
            report.append(f"- ✅ {gp}")
        report.append("")

    # Findings
    if findings:
        report.append("### Issues Found")
        for f in sorted(findings, key=lambda x: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2}.get(x["severity"], 3)):
            line_ref = f"Line {f['line']}: " if f["line"] > 0 else ""
            report.append(f"- **{f['severity']}** — {line_ref}{f['type']}")
            if f["snippet"]:
                report.append(f"  `{f['snippet']}`")
        report.append("")

    # Recommendations
    report.append("### Recommendations")
    if not env_usage_count:
        report.append("- Load all credentials from environment variables (os.environ / process.env)")
    if not has_env_example and env_usage_count:
        report.append("- Create a .env.example file documenting required variables (with placeholder values)")
    if critical:
        report.append("- Move all hardcoded credentials to environment variables or a secrets manager")
    if logging_risks:
        report.append("- Redact credentials before logging (show only first 4 chars)")
    if not any("Secrets manager" in gp for gp in good_practices):
        report.append("- Consider using a secrets manager (AWS Secrets Manager, Vault, etc.) for production")
    if not any("Rotation" in gp for gp in good_practices):
        report.append("- Implement credential rotation or use short-lived tokens (STS, OAuth)")

    return "\n".join(report)


# ─── Tool 12: sql_injection_scan ──────────────────────────────────


@mcp.tool()
async def sql_injection_scan(
    code: str,
    language: str = "auto",
) -> str:
    """Scan code for SQL injection vulnerabilities.

    Detects string concatenation/interpolation in SQL queries
    and recommends parameterized queries instead.

    Args:
        code: Source code to scan
        language: "python", "javascript", "typescript", or "auto"
    """
    lines = code.splitlines()
    findings: list[dict] = []
    safe_patterns: int = 0

    # Dangerous patterns — string concat/interpolation in SQL
    dangerous = [
        # Python f-string in SQL
        (
            r"""(?:execute|query|cursor\.execute|\.raw|\.extra)\s*\(\s*f['\"].*(?:SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE)""",
            "f-string SQL query (use parameterized query)",
        ),
        # Python .format() in SQL
        (
            r"""(?:execute|query|cursor\.execute)\s*\(\s*['\"].*(?:SELECT|INSERT|UPDATE|DELETE).*['\"]\.format\s*\(""",
            ".format() SQL query (use parameterized query)",
        ),
        # Python % formatting in SQL
        (
            r"""(?:execute|query|cursor\.execute)\s*\(\s*['\"].*(?:SELECT|INSERT|UPDATE|DELETE).*%s.*['\"].*%\s*\(""",
            "% format SQL query (use execute() params instead)",
        ),
        # Python/JS string concat with + in SQL
        (
            r"""(?:SELECT|INSERT|UPDATE|DELETE|WHERE)\s.*['\"]?\s*\+\s*(?:\w+|['"])""",
            "String concatenation in SQL query",
        ),
        # JS template literal in SQL
        (
            r"""(?:execute|query|pool\.query|db\.query)\s*\(\s*`.*\$\{.*(?:SELECT|INSERT|UPDATE|DELETE)""",
            "Template literal SQL query (use parameterized query)",
        ),
        (r"""(?:SELECT|INSERT|UPDATE|DELETE).*\$\{""", "Template literal interpolation in SQL"),
        # Raw user input in WHERE clause
        (
            r"""WHERE\s+\w+\s*=\s*['\"]?\s*\+\s*(?:req\.|request\.|params\.|body\.|query\.)""",
            "User input directly in WHERE clause",
        ),
    ]

    # Safe patterns — parameterized queries
    safe = [
        r"(?:execute|query)\s*\(\s*['\"].*\?\s*",  # ? placeholders
        r"(?:execute|query)\s*\(\s*['\"].*%s.*['\"],\s*\(",  # %s with tuple params
        r"(?:execute|query)\s*\(\s*['\"].*:\w+",  # :named params
        r"(?:execute|query)\s*\(\s*['\"].*\$\d+",  # $1 positional params
        r"\.prepare\s*\(",  # Prepared statements
        r"(?:text|sql)\s*\(\s*['\"]",  # Tagged template / query builder
    ]

    for line_num, line in enumerate(lines, 1):
        # Check dangerous patterns
        for pattern, description in dangerous:
            if re.search(pattern, line, re.IGNORECASE):
                findings.append(
                    {
                        "line": line_num,
                        "type": description,
                        "snippet": line.strip()[:100],
                    }
                )

        # Count safe patterns
        for pattern in safe:
            if re.search(pattern, line, re.IGNORECASE):
                safe_patterns += 1

    # ORM detection (generally safe)
    orm_patterns = {
        "SQLAlchemy": r"(?:session\.query|Column\(|relationship\(|declarative_base|create_engine)",
        "Django ORM": r"(?:\.objects\.|\.filter\(|\.exclude\(|models\.Model)",
        "Prisma": r"(?:prisma\.\w+\.(?:find|create|update|delete)|@prisma/client)",
        "Sequelize": r"(?:sequelize\.define|Model\.init|\.findAll\(|\.findOne\()",
        "TypeORM": r"(?:@Entity|@Column|Repository|getRepository|createQueryBuilder)",
        "Drizzle": r"(?:drizzle\(|pgTable\(|mysqlTable\()",
    }

    detected_orms = []
    for name, pattern in orm_patterns.items():
        if re.search(pattern, code):
            detected_orms.append(name)

    # Build report
    report = []

    if not findings:
        report.append("PASS: No SQL injection vulnerabilities detected.\n")
    else:
        report.append(f"FAIL: {len(findings)} potential SQL injection vulnerability(ies) found.\n")

    report.append("## SQL Injection Audit\n")

    if detected_orms:
        report.append(f"**ORM detected:** {', '.join(detected_orms)} (generally safe from injection)")
    if safe_patterns:
        report.append(f"**Safe parameterized queries:** {safe_patterns} instance(s)")
    report.append("")

    if findings:
        report.append("### Vulnerabilities")
        for f in findings:
            report.append(f"- **Line {f['line']}:** {f['type']}")
            report.append(f"  `{f['snippet']}`")
        report.append("")

        report.append("### How to Fix")
        report.append("Use parameterized queries instead of string interpolation:\n")
        report.append("```python")
        report.append("# BAD — SQL injection risk")
        report.append('cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")')
        report.append("")
        report.append("# GOOD — parameterized query")
        report.append('cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))')
        report.append("```")
        report.append("")
        report.append("```javascript")
        report.append("// BAD — SQL injection risk")
        report.append("db.query(`SELECT * FROM users WHERE id = ${userId}`)")
        report.append("")
        report.append("// GOOD — parameterized query")
        report.append("db.query('SELECT * FROM users WHERE id = $1', [userId])")
        report.append("```")

    return "\n".join(report)


# ─── Tool 13: import_audit ────────────────────────────────────────

# Python standard library modules (3.10+)
_PYTHON_STDLIB = {
    "abc",
    "aifc",
    "argparse",
    "array",
    "ast",
    "asyncio",
    "atexit",
    "base64",
    "bdb",
    "binascii",
    "bisect",
    "builtins",
    "bz2",
    "calendar",
    "cgi",
    "cgitb",
    "chunk",
    "cmath",
    "cmd",
    "code",
    "codecs",
    "codeop",
    "collections",
    "colorsys",
    "compileall",
    "concurrent",
    "configparser",
    "contextlib",
    "contextvars",
    "copy",
    "copyreg",
    "cProfile",
    "crypt",
    "csv",
    "ctypes",
    "curses",
    "dataclasses",
    "datetime",
    "dbm",
    "decimal",
    "difflib",
    "dis",
    "distutils",
    "doctest",
    "email",
    "encodings",
    "enum",
    "errno",
    "faulthandler",
    "fcntl",
    "filecmp",
    "fileinput",
    "fnmatch",
    "fractions",
    "ftplib",
    "functools",
    "gc",
    "getopt",
    "getpass",
    "gettext",
    "glob",
    "graphlib",
    "grp",
    "gzip",
    "hashlib",
    "heapq",
    "hmac",
    "html",
    "http",
    "idlelib",
    "imaplib",
    "imghdr",
    "imp",
    "importlib",
    "inspect",
    "io",
    "ipaddress",
    "itertools",
    "json",
    "keyword",
    "lib2to3",
    "linecache",
    "locale",
    "logging",
    "lzma",
    "mailbox",
    "mailcap",
    "marshal",
    "math",
    "mimetypes",
    "mmap",
    "modulefinder",
    "multiprocessing",
    "netrc",
    "nis",
    "nntplib",
    "numbers",
    "operator",
    "optparse",
    "os",
    "ossaudiodev",
    "pathlib",
    "pdb",
    "pickle",
    "pickletools",
    "pipes",
    "pkgutil",
    "platform",
    "plistlib",
    "poplib",
    "posix",
    "posixpath",
    "pprint",
    "profile",
    "pstats",
    "pty",
    "pwd",
    "py_compile",
    "pyclbr",
    "pydoc",
    "queue",
    "quopri",
    "random",
    "re",
    "readline",
    "reprlib",
    "resource",
    "rlcompleter",
    "runpy",
    "sched",
    "secrets",
    "select",
    "selectors",
    "shelve",
    "shlex",
    "shutil",
    "signal",
    "site",
    "smtplib",
    "sndhdr",
    "socket",
    "socketserver",
    "sqlite3",
    "ssl",
    "stat",
    "statistics",
    "string",
    "stringprep",
    "struct",
    "subprocess",
    "sunau",
    "symtable",
    "sys",
    "sysconfig",
    "syslog",
    "tabnanny",
    "tarfile",
    "telnetlib",
    "tempfile",
    "termios",
    "test",
    "textwrap",
    "threading",
    "time",
    "timeit",
    "tkinter",
    "token",
    "tokenize",
    "tomllib",
    "trace",
    "traceback",
    "tracemalloc",
    "tty",
    "turtle",
    "turtledemo",
    "types",
    "typing",
    "unicodedata",
    "unittest",
    "urllib",
    "uu",
    "uuid",
    "venv",
    "warnings",
    "wave",
    "weakref",
    "webbrowser",
    "winreg",
    "winsound",
    "wsgiref",
    "xdrlib",
    "xml",
    "xmlrpc",
    "zipapp",
    "zipfile",
    "zipimport",
    "zlib",
    "_thread",
    "__future__",
    "typing_extensions",
}

# Well-known npm packages (top 200+)
_KNOWN_NPM = {
    "react",
    "react-dom",
    "next",
    "vue",
    "svelte",
    "angular",
    "express",
    "fastify",
    "koa",
    "hono",
    "axios",
    "node-fetch",
    "got",
    "superagent",
    "lodash",
    "underscore",
    "ramda",
    "date-fns",
    "dayjs",
    "moment",
    "uuid",
    "nanoid",
    "crypto-js",
    "bcrypt",
    "bcryptjs",
    "jsonwebtoken",
    "dotenv",
    "cors",
    "helmet",
    "morgan",
    "winston",
    "pino",
    "chalk",
    "commander",
    "yargs",
    "inquirer",
    "ora",
    "execa",
    "shelljs",
    "fs-extra",
    "glob",
    "minimatch",
    "chokidar",
    "nodemon",
    "typescript",
    "ts-node",
    "tsx",
    "esbuild",
    "webpack",
    "vite",
    "rollup",
    "jest",
    "vitest",
    "mocha",
    "chai",
    "cypress",
    "playwright",
    "prisma",
    "@prisma/client",
    "sequelize",
    "typeorm",
    "drizzle-orm",
    "mongoose",
    "mongodb",
    "redis",
    "ioredis",
    "pg",
    "mysql2",
    "better-sqlite3",
    "zod",
    "yup",
    "joi",
    "ajv",
    "class-validator",
    "tailwindcss",
    "postcss",
    "autoprefixer",
    "sass",
    "less",
    "framer-motion",
    "gsap",
    "three",
    "d3",
    "chart.js",
    "recharts",
    "socket.io",
    "ws",
    "mqtt",
    "amqplib",
    "@aws-sdk/client-s3",
    "@aws-sdk/client-dynamodb",
    "@aws-sdk/client-lambda",
    "openai",
    "@anthropic-ai/sdk",
    "langchain",
    "@langchain/core",
    "stripe",
    "paypal-rest-sdk",
    "sharp",
    "jimp",
    "canvas",
    "puppeteer",
    "cheerio",
    "path",
    "url",
    "querystring",
    "buffer",
    "stream",
    "events",
    "util",
    "fs",
    "http",
    "https",
    "net",
    "os",
    "child_process",
    "cluster",
    "crypto",
}


@mcp.tool()
async def import_audit(
    code: str,
    language: str = "auto",
    package_json: str = "",
    requirements_txt: str = "",
) -> str:
    """Audit imports for hallucinated, misspelled, or unavailable packages.

    LLMs frequently hallucinate package names. This tool cross-references
    imports against known standard libraries and popular packages.

    Args:
        code: Source code to audit
        language: "python", "javascript", "typescript", or "auto"
        package_json: Content of package.json (if available, for dependency verification)
        requirements_txt: Content of requirements.txt (if available)
    """
    lang = language.lower()
    if lang == "auto":
        if re.search(r"^(?:import |from )\w+", code, re.MULTILINE):
            lang = "python"
        elif re.search(r"(?:import .+ from |require\s*\(|from ['\"]\w)", code):
            lang = "javascript"
        else:
            return "SKIP: Could not auto-detect language for import audit."

    findings: list[dict] = []
    verified: list[str] = []

    if lang in ("python", "py"):
        # Extract Python imports
        import_pattern = re.compile(r"^(?:import|from)\s+([\w.]+)", re.MULTILINE)
        imports = set()
        for match in import_pattern.finditer(code):
            module = match.group(1).split(".")[0]  # Top-level package
            imports.add(module)

        # Check against known packages
        declared_deps = set()
        if requirements_txt:
            for line in requirements_txt.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    pkg = re.split(r"[>=<!\[;]", line)[0].strip()
                    # Package names use hyphens, import names use underscores
                    declared_deps.add(pkg.replace("-", "_").lower())

        for module in sorted(imports):
            module_lower = module.lower()
            if module_lower in _PYTHON_STDLIB:
                verified.append(f"{module} (stdlib)")
            elif module_lower in declared_deps or module_lower.replace("_", "-") in declared_deps:
                verified.append(f"{module} (declared dep)")
            else:
                # Flag as potentially hallucinated
                findings.append(
                    {
                        "module": module,
                        "status": "UNVERIFIED",
                        "note": "Not in stdlib or declared dependencies",
                    }
                )

    elif lang in ("javascript", "typescript", "js", "ts"):
        # Extract JS/TS imports
        import_patterns = [
            re.compile(r"""import\s+.*?\s+from\s+['"]([^'"./][^'"]*?)['"]"""),
            re.compile(r"""require\s*\(\s*['"]([^'"./][^'"]*?)['"]"""),
        ]

        imports = set()
        for pattern in import_patterns:
            for match in pattern.finditer(code):
                pkg = match.group(1)
                # Handle scoped packages: @scope/package → @scope/package
                pkg = "/".join(pkg.split("/")[:2]) if pkg.startswith("@") else pkg.split("/")[0]
                imports.add(pkg)

        # Check against package.json if provided
        declared_deps = set()
        if package_json:
            try:
                pkg_data = json.loads(package_json)
                for dep_type in ("dependencies", "devDependencies", "peerDependencies"):
                    declared_deps.update(pkg_data.get(dep_type, {}).keys())
            except json.JSONDecodeError:
                pass

        for pkg in sorted(imports):
            if pkg in _KNOWN_NPM or pkg.startswith("node:"):
                verified.append(f"{pkg} (known package)")
            elif pkg in declared_deps:
                verified.append(f"{pkg} (declared dep)")
            else:
                findings.append(
                    {
                        "module": pkg,
                        "status": "UNVERIFIED",
                        "note": "Not a known package or declared dependency",
                    }
                )

    # Build report
    report = []
    total = len(verified) + len(findings)

    if not findings:
        report.append(f"PASS: All {total} imports verified.\n")
    else:
        report.append(f"WARN: {len(findings)} unverified import(s) out of {total} total.\n")

    report.append("## Import Audit\n")

    if findings:
        report.append("### Unverified Imports (possibly hallucinated)")
        for f in findings:
            report.append(f"- `{f['module']}` — {f['note']}")
        report.append("")
        report.append(
            "These packages may not exist. Verify on [npm](https://npmjs.com) or [PyPI](https://pypi.org) before installing."
        )
        report.append("")

    if verified:
        report.append(f"### Verified Imports ({len(verified)})")
        for v in verified[:20]:
            report.append(f"- ✅ {v}")
        if len(verified) > 20:
            report.append(f"- ... and {len(verified) - 20} more")

    return "\n".join(report)


# ─── Tool 14: complexity_score ────────────────────────────────────


@mcp.tool()
async def complexity_score(
    code: str,
    language: str = "auto",
) -> str:
    """Calculate cyclomatic complexity and code quality metrics.

    Counts decision points (if/else/for/while/try/catch/switch/case/&&/||)
    to estimate maintainability. Also checks function length, nesting depth,
    and other quality signals.

    Args:
        code: Source code to analyze
        language: "python", "javascript", "typescript", or "auto"
    """
    lines = code.splitlines()
    total_lines = len(lines)
    blank_lines = sum(1 for line in lines if not line.strip())
    comment_lines = sum(1 for line in lines if line.strip().startswith(("#", "//", "/*", "*", "/**")))
    code_lines = total_lines - blank_lines - comment_lines

    # Count decision points (cyclomatic complexity proxy)
    decision_keywords = [
        r"\bif\b",
        r"\belif\b",
        r"\belse\s+if\b",
        r"\belse\b",
        r"\bfor\b",
        r"\bwhile\b",
        r"\bdo\b",
        r"\btry\b",
        r"\bcatch\b",
        r"\bexcept\b",
        r"\bcase\b",
        r"\bswitch\b",
        r"\b\?\s*.*\s*:",  # ternary
        r"&&",
        r"\|\|",
        r"\band\b",
        r"\bor\b",  # Python logical
    ]

    decision_count = 0
    for line in lines:
        for pattern in decision_keywords:
            decision_count += len(re.findall(pattern, line))

    # Count functions/methods
    func_pattern = re.compile(r"(?:def |function |async function |const \w+ = (?:async )?\(|=>\s*\{|class )")
    functions = func_pattern.findall(code)
    func_count = len(functions) or 1  # avoid div by zero

    avg_complexity = round(decision_count / func_count, 1)

    # Measure max nesting depth
    max_depth = 0
    current_depth = 0
    for line in lines:
        stripped = line.lstrip()
        indent = len(line) - len(stripped)
        # Rough depth estimation (4 spaces or 1 tab = 1 level)
        depth = indent // 4 if "    " in line[:indent] else indent // 2
        # Also count braces for JS/TS
        current_depth += line.count("{") - line.count("}")
        max_depth = max(max_depth, depth, current_depth)

    # Find long functions
    long_functions: list[dict] = []
    in_func = False
    func_start = 0
    func_name = ""
    func_line_count = 0
    func_pattern2 = re.compile(r"(?:def |function |async function )(\w+)")

    for i, line in enumerate(lines):
        match = func_pattern2.search(line)
        if match:
            if in_func and func_line_count > 50:
                long_functions.append({"name": func_name, "lines": func_line_count, "start": func_start + 1})
            in_func = True
            func_start = i
            func_name = match.group(1)
            func_line_count = 0
        if in_func:
            func_line_count += 1

    if in_func and func_line_count > 50:
        long_functions.append({"name": func_name, "lines": func_line_count, "start": func_start + 1})

    # Score
    # Complexity rating
    if avg_complexity <= 5:
        complexity_rating = "LOW"
        complexity_emoji = "🟢"
    elif avg_complexity <= 10:
        complexity_rating = "MODERATE"
        complexity_emoji = "🟡"
    elif avg_complexity <= 20:
        complexity_rating = "HIGH"
        complexity_emoji = "🟠"
    else:
        complexity_rating = "VERY HIGH"
        complexity_emoji = "🔴"

    # Overall verdict
    issues = []
    if avg_complexity > 15:
        issues.append("high complexity")
    if max_depth > 6:
        issues.append("deep nesting")
    if long_functions:
        issues.append("long functions")

    verdict = "FAIL" if avg_complexity > 20 or max_depth > 8 else "WARN" if issues else "PASS"

    # Build report
    report = [f"{verdict}: Complexity is {complexity_rating.lower()}.\n"]
    report.append("## Code Complexity Analysis\n")

    report.append("| Metric | Value |")
    report.append("|--------|-------|")
    report.append(f"| Total lines | {total_lines} |")
    report.append(f"| Code lines | {code_lines} |")
    report.append(f"| Comment lines | {comment_lines} |")
    report.append(f"| Functions/methods | {func_count} |")
    report.append(f"| Decision points | {decision_count} |")
    report.append(f"| Avg complexity/function | {complexity_emoji} {avg_complexity} ({complexity_rating}) |")
    report.append(f"| Max nesting depth | {max_depth} |")
    report.append("")

    if long_functions:
        report.append("### Long Functions (>50 lines)")
        for lf in long_functions:
            report.append(f"- `{lf['name']}()` — {lf['lines']} lines (line {lf['start']})")
        report.append("")

    if issues:
        report.append("### Recommendations")
        if "high complexity" in issues:
            report.append("- Break complex functions into smaller, focused helpers")
        if "deep nesting" in issues:
            report.append("- Reduce nesting with early returns / guard clauses")
        if "long functions" in issues:
            report.append("- Extract long functions into smaller units (<50 lines each)")

    return "\n".join(report)


if __name__ == "__main__":
    mcp.run()
