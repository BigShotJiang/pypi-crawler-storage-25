"""
Webhook Notification Service for the Vending Machine marketplace.

Notifies creators when their scripts are run, and users when async jobs complete.
Built by Code Gremlin + Bug Hunter security fixes.

Endpoints:
    POST /webhooks/register  — register a webhook URL with events + secret
    POST /webhooks/test      — send test payload to registered URL
    DELETE /webhooks/{id}    — remove a webhook
    GET  /webhooks           — list all registered webhooks
    GET  /webhooks/{id}/deliveries — last 20 delivery attempts
    GET  /health             — health check
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import ipaddress
import json
import logging
import time
from collections import deque
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from urllib.parse import urlparse
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException, status
from pydantic import AnyHttpUrl, BaseModel, Field, field_validator

logger = logging.getLogger("webhook_service")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_LOG_ENTRIES: int = 20
MAX_ATTEMPTS: int = 3
RETRY_BACKOFF_SECONDS: tuple[int, ...] = (1, 4, 16)
MAX_WEBHOOKS_PER_ACCOUNT: int = 20
MAX_PAYLOAD_SIZE: int = 65_536  # 64KB max for webhook data field
DELIVERY_TIMEOUT: float = 10.0

# SSRF protection: blocked IP ranges and hostnames
_BLOCKED_HOSTNAMES = frozenset(
    {
        "localhost",
        "127.0.0.1",
        "0.0.0.0",  # noqa: S104 — intentionally blocking all-interfaces IP
        "::1",
        "metadata.google.internal",
        "metadata.internal",
    }
)

_BLOCKED_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),  # AWS/GCP/Azure metadata
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("fc00::/7"),  # IPv6 private
    ipaddress.ip_network("fe80::/10"),  # IPv6 link-local
]


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class EventType(StrEnum):
    SCRIPT_RUN = "script.run"
    JOB_COMPLETE = "job.complete"
    JOB_FAILED = "job.failed"
    CREDIT_LOW = "credit.low"
    ENGAGEMENT_COMPLETE = "engagement.complete"
    ENGAGEMENT_DELIVERED = "engagement.delivered"


class DeliveryStatus(StrEnum):
    SUCCESS = "success"
    FAILED = "failed"


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class RegisterWebhookRequest(BaseModel):
    url: AnyHttpUrl
    events: list[EventType] = Field(..., min_length=1)
    secret: str = Field(..., min_length=16, max_length=256)

    @field_validator("events")
    @classmethod
    def dedupe_events(cls, value: list[EventType]) -> list[EventType]:
        seen: set[EventType] = set()
        deduped: list[EventType] = []
        for event in value:
            if event not in seen:
                deduped.append(event)
                seen.add(event)
        return deduped

    @field_validator("url")
    @classmethod
    def validate_url_security(cls, value: AnyHttpUrl) -> AnyHttpUrl:
        """Block SSRF: reject internal IPs, non-HTTPS, and dangerous schemes."""
        parsed = urlparse(str(value))

        # Must be HTTPS
        if parsed.scheme != "https":
            msg = "Webhook URL must use HTTPS"
            raise ValueError(msg)

        hostname = parsed.hostname or ""

        # Block known internal hostnames
        if hostname.lower() in _BLOCKED_HOSTNAMES:
            msg = f"Webhook URL hostname '{hostname}' is not allowed"
            raise ValueError(msg)

        # Block private/reserved IP ranges
        try:
            ip = ipaddress.ip_address(hostname)
        except ValueError:
            # hostname is not an IP — that's fine (it's a domain name)
            pass
        else:
            # It IS an IP — check against blocked ranges
            for network in _BLOCKED_NETWORKS:
                if ip in network:
                    msg = f"Webhook URL points to private/reserved IP range: {hostname}"
                    raise ValueError(msg)

        return value


class RegisterWebhookResponse(BaseModel):
    webhook_id: str
    url: AnyHttpUrl
    events: list[EventType]
    created_at: str


class TestWebhookRequest(BaseModel):
    webhook_id: str = Field(..., min_length=1)
    event: EventType = EventType.SCRIPT_RUN
    data: dict[str, Any] = Field(default_factory=dict)

    @field_validator("data")
    @classmethod
    def validate_data_size(cls, value: dict[str, Any]) -> dict[str, Any]:
        """Prevent oversized payloads (DoS protection)."""
        serialized = json.dumps(value, separators=(",", ":"))
        if len(serialized) > MAX_PAYLOAD_SIZE:
            msg = f"Payload data exceeds {MAX_PAYLOAD_SIZE} bytes"
            raise ValueError(msg)
        return value


class TestWebhookResponse(BaseModel):
    delivery_id: str
    queued: bool
    message: str


class WebhookPayload(BaseModel):
    event: EventType
    timestamp: str
    webhook_id: str
    nonce: str  # Replay attack prevention
    data: dict[str, Any]


class DeliveryLogEntry(BaseModel):
    delivery_id: str
    event: EventType
    timestamp: str
    status: DeliveryStatus
    attempts: int
    response_code: int | None = None
    error: str | None = None


class DeliveryLogResponse(BaseModel):
    webhook_id: str
    deliveries: list[DeliveryLogEntry]


class StoredWebhook(BaseModel):
    webhook_id: str
    url: AnyHttpUrl
    events: list[EventType]
    secret: str  # In production: hash this, don't store plaintext
    created_at: str


# ---------------------------------------------------------------------------
# App + in-memory stores
# ---------------------------------------------------------------------------

app = FastAPI(title="Webhook Notification Service", version="1.0.0")

webhooks_store: dict[str, StoredWebhook] = {}
delivery_logs_store: dict[str, deque[DeliveryLogEntry]] = {}

store_lock = asyncio.Lock()
_active_tasks: set[asyncio.Task[None]] = set()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_sb():
    try:
        from supabase_client import get_supabase

        return get_supabase()
    except Exception:
        return None


def _hash_secret(secret: str) -> str:
    """Hash webhook secret with bcrypt for storage."""
    import bcrypt

    return bcrypt.hashpw(secret.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def utc_now_iso() -> str:
    return datetime.now(tz=UTC).isoformat().replace("+00:00", "Z")


def compute_signature(payload: bytes, secret: str) -> str:
    """Compute HMAC-SHA256 signature for webhook payload."""
    return hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def sign_payload(secret: str, body: bytes) -> str:
    """Create the full signature header value."""
    return f"sha256={compute_signature(body, secret)}"


def verify_signature(payload: bytes, signature_header: str, secret: str) -> bool:
    """Constant-time signature verification (prevents timing attacks)."""
    if not signature_header.startswith("sha256="):
        return False
    expected = signature_header[7:]
    computed = compute_signature(payload, secret)
    return hmac.compare_digest(computed, expected)


async def _append_delivery_log(webhook_id: str, entry: DeliveryLogEntry) -> None:
    async with store_lock:
        if webhook_id not in delivery_logs_store:
            delivery_logs_store[webhook_id] = deque(maxlen=MAX_LOG_ENTRIES)
        delivery_logs_store[webhook_id].appendleft(entry)

    # Write-through to Supabase
    sb = _get_sb()
    if sb:
        try:
            sb.table("webhook_deliveries").insert(
                {
                    "webhook_id": webhook_id,
                    "event": entry.event.value if hasattr(entry.event, "value") else entry.event,
                    "status": entry.status.value if hasattr(entry.status, "value") else entry.status,
                    "attempts": entry.attempts,
                    "response_code": entry.response_code,
                    "error": entry.error,
                }
            ).execute()
        except Exception as e:
            logger.debug("Failed to log delivery to Supabase: %s", e)


# ---------------------------------------------------------------------------
# Delivery engine
# ---------------------------------------------------------------------------


async def deliver_webhook(
    delivery_id: str,
    webhook: StoredWebhook,
    payload: WebhookPayload,
) -> None:
    """Deliver a webhook with retry logic (3 attempts, exponential backoff)."""
    payload_dict = payload.model_dump(mode="json")
    body = json.dumps(payload_dict, separators=(",", ":"), sort_keys=True).encode("utf-8")
    signature = sign_payload(webhook.secret, body)

    headers = {
        "Content-Type": "application/json",
        "X-Webhook-Signature": signature,
        "X-Webhook-Event": payload.event.value,
        "X-Webhook-ID": webhook.webhook_id,
        "X-Delivery-ID": delivery_id,
        "X-Webhook-Timestamp": str(int(time.time())),
    }

    attempts_made = 0
    last_status_code: int | None = None
    last_error: str | None = None
    final_status = DeliveryStatus.FAILED

    async with httpx.AsyncClient(timeout=httpx.Timeout(DELIVERY_TIMEOUT)) as client:
        for attempt in range(1, MAX_ATTEMPTS + 1):
            attempts_made = attempt
            try:
                response = await client.post(str(webhook.url), content=body, headers=headers)
                last_status_code = response.status_code

                if 200 <= response.status_code < 300:
                    final_status = DeliveryStatus.SUCCESS
                    last_error = None
                    break

                last_error = f"Non-2xx response: {response.status_code}"

            except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPError) as exc:
                last_error = f"{type(exc).__name__}: {exc}"

            if attempt < MAX_ATTEMPTS:
                backoff = RETRY_BACKOFF_SECONDS[attempt - 1]
                await asyncio.sleep(backoff)

    log_entry = DeliveryLogEntry(
        delivery_id=delivery_id,
        event=payload.event,
        timestamp=utc_now_iso(),
        status=final_status,
        attempts=attempts_made,
        response_code=last_status_code,
        error=last_error if final_status == DeliveryStatus.FAILED else None,
    )
    await _append_delivery_log(webhook.webhook_id, log_entry)

    if final_status == DeliveryStatus.FAILED:
        logger.warning("Webhook delivery failed: %s → %s (%s)", delivery_id, webhook.url, last_error)


def _track_task(task: asyncio.Task[None]) -> None:
    _active_tasks.add(task)

    def _cleanup(done_task: asyncio.Task[None]) -> None:
        _active_tasks.discard(done_task)
        if not done_task.cancelled():
            exc = done_task.exception()
            if exc:
                logger.error("Webhook delivery task crashed: %s", exc)

    task.add_done_callback(_cleanup)


# ---------------------------------------------------------------------------
# Public function: fire a webhook event (called by main app)
# ---------------------------------------------------------------------------


async def fire_event(event: EventType, data: dict[str, Any]) -> None:
    """Fire a webhook event to all subscribers. Called by the main app."""
    async with store_lock:
        subscribers = [wh for wh in webhooks_store.values() if event in wh.events]

    for webhook in subscribers:
        payload = WebhookPayload(
            event=event,
            timestamp=utc_now_iso(),
            webhook_id=webhook.webhook_id,
            nonce=str(uuid4()),
            data=data,
        )
        delivery_id = str(uuid4())
        task = asyncio.create_task(deliver_webhook(delivery_id, webhook, payload))
        _track_task(task)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.post(
    "/webhooks/register",
    response_model=RegisterWebhookResponse,
    status_code=status.HTTP_201_CREATED,
)
async def register_webhook_endpoint(request: RegisterWebhookRequest) -> RegisterWebhookResponse:
    """Register a new webhook subscription."""
    async with store_lock:
        # Rate limit: max webhooks per store (simple DoS protection)
        if len(webhooks_store) >= MAX_WEBHOOKS_PER_ACCOUNT:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Maximum {MAX_WEBHOOKS_PER_ACCOUNT} webhooks allowed",
            )

        webhook_id = f"wh-{uuid4().hex[:12]}"
        created_at = utc_now_iso()

        stored = StoredWebhook(
            webhook_id=webhook_id,
            url=request.url,
            events=request.events,
            secret=request.secret,
            created_at=created_at,
        )

        webhooks_store[webhook_id] = stored
        delivery_logs_store[webhook_id] = deque(maxlen=MAX_LOG_ENTRIES)

    # Write-through to Supabase
    sb = _get_sb()
    if sb:
        try:
            sb.table("webhooks").insert(
                {
                    "id": webhook_id,
                    "url": str(request.url),
                    "events": json.dumps([e.value for e in request.events]),
                    "secret_hash": _hash_secret(request.secret),
                }
            ).execute()
        except Exception as e:
            logger.warning("Failed to persist webhook to Supabase: %s", e)

    return RegisterWebhookResponse(
        webhook_id=webhook_id,
        url=stored.url,
        events=stored.events,
        created_at=stored.created_at,
    )


@app.post(
    "/webhooks/test",
    response_model=TestWebhookResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def test_webhook_endpoint(request: TestWebhookRequest) -> TestWebhookResponse:
    """Send a test payload to a registered webhook."""
    async with store_lock:
        webhook = webhooks_store.get(request.webhook_id)

    if webhook is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook not found")

    if request.event not in webhook.events:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Webhook not subscribed to event '{request.event.value}'",
        )

    payload = WebhookPayload(
        event=request.event,
        timestamp=utc_now_iso(),
        webhook_id=webhook.webhook_id,
        nonce=str(uuid4()),
        data=request.data if request.data else {"test": True, "message": "Hello from Vending Machine!"},
    )

    delivery_id = str(uuid4())
    task = asyncio.create_task(deliver_webhook(delivery_id, webhook, payload))
    _track_task(task)

    return TestWebhookResponse(delivery_id=delivery_id, queued=True, message="Webhook delivery queued")


@app.get("/webhooks")
async def list_webhooks() -> dict[str, Any]:
    """List all registered webhooks (without secrets)."""
    async with store_lock:
        webhooks = [
            {
                "webhook_id": wh.webhook_id,
                "url": str(wh.url),
                "events": [e.value for e in wh.events],
                "created_at": wh.created_at,
            }
            for wh in webhooks_store.values()
        ]
    return {"webhooks": webhooks, "total": len(webhooks)}


@app.delete("/webhooks/{webhook_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_webhook(webhook_id: str) -> None:
    """Remove a registered webhook."""
    async with store_lock:
        if webhook_id not in webhooks_store:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook not found")
        del webhooks_store[webhook_id]
        delivery_logs_store.pop(webhook_id, None)

    # Delete from Supabase (cascade deletes deliveries)
    sb = _get_sb()
    if sb:
        try:
            sb.table("webhooks").delete().eq("id", webhook_id).execute()
        except Exception as e:
            logger.warning("Failed to delete webhook from Supabase: %s", e)


@app.get("/webhooks/{webhook_id}/deliveries", response_model=DeliveryLogResponse)
async def get_deliveries(webhook_id: str) -> DeliveryLogResponse:
    """Get the last 20 delivery attempts for a webhook."""
    async with store_lock:
        if webhook_id not in webhooks_store:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook not found")
        logs = delivery_logs_store.get(webhook_id)

    return DeliveryLogResponse(webhook_id=webhook_id, deliveries=list(logs or []))


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}
