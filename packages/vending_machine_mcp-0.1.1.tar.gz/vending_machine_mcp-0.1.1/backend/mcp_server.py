"""
Vending Machine MCP Server — exposes all agents and scripts as tools.

Usage:
    python mcp_server.py          # stdio transport (for Claude Code)

All 18 agents are available via hire_agent(). Every agent runs async
(fire-and-forget + poll via check_job) because the MCP client has a
30-second timeout and even "fast" agents can exceed that with multi-node
LangGraph pipelines (3 API calls per run).
"""

import asyncio
import logging
import os
import sys
import time
import uuid

logger = logging.getLogger("mcp_server")

# Set of strong references to background tasks to prevent garbage collection (RUF006)
_background_tasks: set[asyncio.Task] = set()

# Ensure the backend dir is on the path (needed when launched without cwd)
_backend_dir = os.path.dirname(os.path.abspath(__file__))
if _backend_dir not in sys.path:
    sys.path.insert(0, _backend_dir)
os.chdir(_backend_dir)

# Load env vars BEFORE any agent imports (they read keys at import time)
from dotenv import load_dotenv

load_dotenv(override=True)

from mcp.server.fastmcp import FastMCP

from agents.llm import MODELS
from agents.registry import AGENT_GRAPHS
from credits import (
    check_balance as _check_balance,
)
from credits import (
    deduct as _deduct_credits,
)
from credits import (
    get_agent_cost as _agent_cost,
)
from credits import (
    get_script_cost as _script_cost,
)
from credits import (
    get_workflow_cost as _workflow_cost,
)
from pricing import (
    FALLBACK_PRICES,
    PRICE_CACHE,
    calculate_cost,
    ensure_prices_loaded,
    format_cost,
)
from sandbox import is_available as _sandbox_available
from sandbox import run_code as _sandbox_run_code
from scripts import list_scripts as _list_scripts
from scripts import record_run as _record_run

# MCP session ID — generated once at server startup, used for chain detection.
# Each MCP client connection runs its own server process, so this naturally
# scopes to one user session.
_MCP_SESSION_ID = str(uuid.uuid4())[:8]

# MCP user identity — anonymous until auth is wired.
# In production, this comes from the MCP client's API key or JWT.
_MCP_USER_ID = "mcp-anonymous"

# ---------------------------------------------------------------------------
# Agent metadata — descriptions for all 18 agents
# ---------------------------------------------------------------------------

AGENT_META: dict[str, dict] = {
    "code-gremlin": {
        "name": "Code Gremlin",
        "desc": "Writes, debugs, and refactors code in 12+ languages. Premium Codex model.",
    },
    "inbox-zero": {
        "name": "Inbox Zero",
        "desc": "Email triage — categorize, prioritize, draft replies, suggest labels and filters.",
    },
    "vibe-writer": {
        "name": "Vibe Writer",
        "desc": "Ghostwriting — LinkedIn posts, newsletters, tweets, blog outlines, taglines. Multiple variations.",
    },
    "number-crunch": {
        "name": "Number Crunch",
        "desc": "Data analysis — statistics, trends, KPI dashboards, visualization recommendations.",
    },
    "mcp-maker": {
        "name": "MCP Maker",
        "desc": "Generates MCP server code (Python FastMCP, TypeScript, Go) with tool definitions and transport config.",
    },
    "embeddings-agent": {
        "name": "Embeddings Agent",
        "desc": "Multi-provider embeddings (OpenAI, Voyage AI, Gemini). Chunking, similarity analysis, batch processing.",
    },
    "bug-hunter": {
        "name": "Bug Hunter",
        "desc": "Code review, debugging, and security audits. Finds vulnerabilities and suggests fixes.",
    },
    "test-goblin": {
        "name": "Test Goblin",
        "desc": "Test suite generation — unit, integration, e2e tests. Provide source code in the task.",
    },
    "data-sprite": {
        "name": "Data Sprite",
        "desc": "Database schemas, seed files, mock data, SQL migrations, ETL scripts. Multi-DB support.",
    },
    "pdf-forge": {
        "name": "PDF Forge",
        "desc": "PDF generation — LaTeX, HTML-to-PDF, ReportLab. Structured documents and reports.",
    },
    "cloud-sensei": {
        "name": "Cloud Sensei",
        "desc": "AWS architecture, troubleshooting, cost optimization. IaC templates and best practices.",
    },
    "devops-dwarf": {
        "name": "DevOps Dwarf",
        "desc": "Dockerfiles, Terraform, CI/CD pipelines, Kubernetes manifests, cloud deployments.",
    },
    "desk-pilot": {
        "name": "Desk Pilot",
        "desc": "Email drafts, meeting prep, SOPs, task management. Lightweight admin assistant (free model).",
    },
}

# ALL agents run async — MCP client has a 30s timeout which even
# "fast" agents can exceed due to LLM latency (3-node pipeline = 3 API calls).
LONG_RUNNING_AGENTS = set(AGENT_META.keys())

# ---------------------------------------------------------------------------
# Unified job store — delegates to jobs.py (Supabase write-through)
# ---------------------------------------------------------------------------

from jobs import JOB_STORE
from jobs import create_job as _jobs_create
from jobs import get_job as _get_job
from jobs import update_job as _update_job


def _create_job(agent_id: str, task: str, name: str = "") -> dict:
    """Create a job in the unified store. Thin wrapper for backward compat."""
    agent_name = name or (AGENT_META[agent_id]["name"] if agent_id in AGENT_META else agent_id)
    job = _jobs_create(agent_id, agent_name, task, source="mcp")
    # MCP jobs start running immediately (no queued state)
    _update_job(job["job_id"], status="running", started_at=time.time())
    return JOB_STORE[job["job_id"]]


# ---------------------------------------------------------------------------
# Helpers (inlined from registry to avoid importing all 18 agents)
# ---------------------------------------------------------------------------


def _build_initial_state(task: str) -> dict:
    return {
        "task": task,
        "current_step": "idle",
        "plan": "",
        "code": "",
        "review": "",
        "messages": [],
        "research": "",
        "analysis": "",
        "organization": "",
        "voice_analysis": "",
        "draft": "",
        "computation": "",
        "assessment": "",
        "recipe": "",
        "report": "",
        "file_content": "",
        "file_name": "",
        "provider": "",
        "embeddings_result": "",
        "model_override": None,
        "token_usage": {"input_tokens": 0, "output_tokens": 0},
    }


def _format_output(step: str, state_update: dict) -> str:
    if step == "thinking":
        plan = (
            state_update.get("plan")
            or state_update.get("analysis")
            or state_update.get("voice_analysis")
            or state_update.get("assessment")
            or ""
        )
        return plan
    elif step == "coding":
        return (
            state_update.get("code")
            or state_update.get("research")
            or state_update.get("report")
            or state_update.get("organization")
            or state_update.get("draft")
            or state_update.get("computation")
            or state_update.get("recipe")
            or state_update.get("embeddings_result")
            or ""
        )
    elif step == "researching":
        return state_update.get("research", "")
    elif step == "reviewing":
        return state_update.get("review", "")
    else:
        return ""


def _estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)


async def _run_agent(agent_id: str, task: str) -> dict:
    """Run an agent graph and return results dict."""
    graph = AGENT_GRAPHS[agent_id]

    # Lazy-init pricing cache
    if not PRICE_CACHE:
        try:
            await ensure_prices_loaded()
        except Exception:
            PRICE_CACHE.update(FALLBACK_PRICES)

    start_time = time.time()
    all_outputs: list[str] = []
    final_token_usage = {"input_tokens": 0, "output_tokens": 0}

    initial_state = _build_initial_state(task)

    async for event in graph.astream(initial_state, stream_mode="updates"):
        for node_name, state_update in event.items():
            step = state_update.get("current_step", node_name)
            output = _format_output(step, state_update)
            if output and output.strip():
                all_outputs.append(output)
            if "token_usage" in state_update:
                final_token_usage = state_update["token_usage"]

    full_output = "\n\n".join(all_outputs)
    elapsed_ms = int((time.time() - start_time) * 1000)

    input_tokens = final_token_usage.get("input_tokens", 0) or _estimate_tokens(task)
    output_tokens = final_token_usage.get("output_tokens", 0) or _estimate_tokens(full_output)

    model_info = MODELS.get(agent_id)
    model_id = model_info[0] if model_info else "unknown"
    cost = calculate_cost(model_id, input_tokens, output_tokens)

    return {
        "output": full_output,
        "elapsed_ms": elapsed_ms,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "model_id": model_id,
        "cost": cost,
    }


def _extract_python_code(output: str) -> str | None:
    """Extract the largest Python code block from agent output."""
    import re

    matches = re.findall(r"```python\n(.*?)```", output, re.DOTALL)
    if not matches:
        return None
    return max(matches, key=len)


async def _run_pdf_forge_script(code: str) -> dict:
    """Execute a PDF Forge script locally via subprocess and return the result.

    Runs in a temp directory so the PDF lands somewhere predictable.
    Returns the path to the generated PDF file.
    """
    import tempfile

    # Patch the common canvas_factory compatibility issue
    patched = code.replace(
        "def canvas_factory(filename, doc):",
        "def canvas_factory(filename, **kwargs):",
    )
    patched = patched.replace(
        "pagesize=doc.pagesize,",
        'pagesize=kwargs.get("pagesize", LETTER),',
    )

    try:
        # Write script to temp dir, execute there so PDF lands in a known location
        with tempfile.TemporaryDirectory(prefix="pdf_forge_") as tmpdir:
            script_path = os.path.join(tmpdir, "generate_pdf.py")
            with open(script_path, "w") as f:
                f.write(patched)

            # Ensure reportlab is available
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "pip",
                "install",
                "-q",
                "reportlab",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await proc.communicate()

            # Run the script
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                script_path,
                cwd=tmpdir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, stderr_bytes = await asyncio.wait_for(proc.communicate(), timeout=60)
            stdout = stdout_bytes.decode("utf-8", errors="replace")
            stderr = stderr_bytes.decode("utf-8", errors="replace")

            # Find generated PDF files
            pdf_files = [f for f in os.listdir(tmpdir) if f.endswith(".pdf")]

            if proc.returncode == 0 and pdf_files:
                # Copy PDF to user-accessible location
                output_dir = os.path.expanduser("~/Documents")
                os.makedirs(output_dir, exist_ok=True)
                pdf_name = pdf_files[0]
                dest = os.path.join(output_dir, pdf_name)
                import shutil

                shutil.copy2(os.path.join(tmpdir, pdf_name), dest)

                return {
                    "stdout": stdout,
                    "stderr": "",
                    "error": None,
                    "exit_code": 0,
                    "pdf_path": dest,
                }

            return {
                "stdout": stdout,
                "stderr": stderr,
                "error": stderr if proc.returncode != 0 else "No PDF file generated",
                "exit_code": proc.returncode or 1,
                "pdf_path": None,
            }

    except TimeoutError:
        return {
            "stdout": "",
            "stderr": "Script execution timed out (60s)",
            "error": "Timeout",
            "exit_code": 1,
            "pdf_path": None,
        }
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "error": str(e), "exit_code": 1, "pdf_path": None}


async def _run_job_background(job_id: str) -> None:
    """Run an agent job in the background, updating the job store on completion."""
    job = JOB_STORE.get(job_id)
    if not job:
        return

    try:
        result = await _run_agent(job["agent_id"], job["task"])

        # PDF Forge: auto-execute the generated script locally
        if job["agent_id"] == "pdf-forge":
            code = _extract_python_code(result["output"])
            if code:
                exec_result = await _run_pdf_forge_script(code)
                if exec_result["exit_code"] == 0 and exec_result.get("pdf_path"):
                    result["output"] += (
                        "\n\n---\n"
                        "**PDF Generated Successfully**\n"
                        f"File: {exec_result['pdf_path']}\n"
                        f"{exec_result['stdout']}"
                    )
                else:
                    result["output"] += (
                        "\n\n---\n"
                        "**PDF Generation Failed**\n"
                        f"Error: {exec_result.get('error', exec_result.get('stderr', 'Unknown error'))}\n"
                    )

        _update_job(
            job_id,
            status="complete",
            output=result["output"],
            completed_at=time.time(),
            metadata={
                "runtimeMs": result["elapsed_ms"],
                "inputTokens": result["input_tokens"],
                "outputTokens": result["output_tokens"],
                "cost": result["cost"],
                "model": result.get("model_id", "unknown"),
            },
        )
        # Keep backward-compat fields on the in-memory dict for _wait_for_job / check_job
        job = JOB_STORE.get(job_id, {})
        job["runtime_ms"] = result["elapsed_ms"]
        job["tokens_in"] = result["input_tokens"]
        job["tokens_out"] = result["output_tokens"]
        job["cost"] = result["cost"]
    except Exception as e:
        _update_job(
            job_id,
            status="error",
            error=str(e),
            completed_at=time.time(),
        )
        job = JOB_STORE.get(job_id, {})
        job["runtime_ms"] = int((time.time() - job.get("created_at", time.time())) * 1000)


def _format_metadata(agent_id: str, result: dict) -> str:
    agent_name = AGENT_META[agent_id]["name"]
    elapsed_ms = result["elapsed_ms"]
    elapsed_str = f"{elapsed_ms / 1000:.1f}s" if elapsed_ms < 60_000 else f"{elapsed_ms / 60_000:.1f}m"
    return (
        f"\n\n---\n"
        f"Agent: {agent_name} | Model: {result['model_id']}\n"
        f"Runtime: {elapsed_str} | Tokens: {result['input_tokens']:,} in / {result['output_tokens']:,} out | Cost: {format_cost(result['cost'])}"
    )


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "vending-machine",
    instructions=(
        "AI agent marketplace tools. Use hire_agent to delegate tasks to specialized agents "
        "(Bug Hunter for security audits, Test Goblin for test generation, DevOps Dwarf for CI/CD). "
        "Use list_agents to see available agents. All agents return a job_id — use check_job to poll."
    ),
)


@mcp.tool()
async def list_agents() -> str:
    """List available Vending Machine agents and their capabilities."""
    lines = ["Available agents:\n"]
    for agent_id in sorted(AGENT_META.keys()):
        meta = AGENT_META[agent_id]
        model_info = MODELS.get(agent_id)
        model_id = model_info[0] if model_info else "unknown"
        lines.append(f"  {agent_id} ({meta['name']})")
        lines.append(f"    Model: {model_id}")
        lines.append(f"    {meta['desc']}")
        if meta.get("long_running"):
            lines.append("    ⏳ Async — returns job_id, use check_job to poll.")
        lines.append("")
    return "\n".join(lines)


@mcp.tool()
async def hire_agent(agent_id: str, task: str) -> str:
    """Hire a Vending Machine agent to perform a task.

    Args:
        agent_id: Which agent to hire. One of: bug-hunter, test-goblin, devops-dwarf, cloud-sensei, code-gremlin, data-sprite, desk-pilot, embeddings-agent, inbox-zero, mcp-maker, number-crunch, pdf-forge, vibe-writer.
        task: Detailed task description. Be specific — the agent only sees this text.
    """
    if agent_id not in AGENT_META:
        available = ", ".join(sorted(AGENT_META.keys()))
        return f"Error: Unknown agent '{agent_id}'. Available: {available}"

    graph = AGENT_GRAPHS.get(agent_id)
    if not graph:
        return f"Error: Agent '{agent_id}' graph not compiled."

    # Credit check
    cost = _agent_cost(agent_id)
    allowed, balance, _ = _check_balance(_MCP_USER_ID, cost)
    if not allowed:
        return f"Insufficient credits: {balance}/{cost} needed. Agent: {AGENT_META[agent_id]['name']} costs {cost} credits."

    # Deduct credits before execution
    _deduct_credits(_MCP_USER_ID, cost, f"Agent hire: {agent_id}")

    # All agents run async — MCP client has a 30s timeout that even
    # fast agents can exceed (multi-node pipeline = multiple LLM calls)
    job = _create_job(agent_id, task)
    bg_task = asyncio.create_task(_run_job_background(job["job_id"]))
    _background_tasks.add(bg_task)
    bg_task.add_done_callback(_background_tasks.discard)

    agent_name = AGENT_META[agent_id]["name"]
    slow_agents = {"embeddings-agent"}
    eta = "2-10 minutes" if agent_id in slow_agents else "30-90 seconds"
    return (
        f"{agent_name} is working on your task in the background.\n\n"
        f"Job ID: {job['job_id']}\n"
        f"Status: running\n"
        f"ETA: {eta}\n\n"
        f'Use check_job(job_id="{job["job_id"]}") to poll for results.'
    )


@mcp.tool()
async def check_job(job_id: str) -> str:
    """Check the status of a background agent job.

    Args:
        job_id: The job ID returned by hire_agent for long-running agents.
    """
    job = _get_job(job_id)
    if not job:
        # Check if it's a partial match
        matches = [j for jid, j in JOB_STORE.items() if jid.startswith(job_id)]
        if len(matches) == 1:
            job = matches[0]
        else:
            return f"Error: Job '{job_id}' not found. Active jobs: {', '.join(list(JOB_STORE.keys())[:10]) or 'none'}"

    if job["status"] in ("running", "queued"):
        elapsed = int(time.time() - job["created_at"])
        return (
            f"Job {job['job_id']} is still running.\n"
            f"Agent: {job['agent_name']}\n"
            f"Task: {job['task'][:100]}...\n"
            f"Elapsed: {elapsed}s\n\n"
            f"Try again in 30-60 seconds."
        )

    if job["status"] == "error":
        return f"Job {job['job_id']} failed.\nAgent: {job['agent_name']}\nError: {job.get('error', 'Unknown error')}\n"

    # Complete — extract metadata (may be in metadata dict or flat fields)
    meta = job.get("metadata") or {}
    runtime_ms = meta.get("runtimeMs", 0) or job.get("runtime_ms", 0)
    tokens_in = meta.get("inputTokens", 0) or job.get("tokens_in", 0)
    tokens_out = meta.get("outputTokens", 0) or job.get("tokens_out", 0)
    cost = meta.get("cost", 0) or job.get("cost", 0)

    elapsed_str = f"{runtime_ms / 1000:.1f}s" if runtime_ms < 60_000 else f"{runtime_ms / 60_000:.1f}m"

    model_id = meta.get("model") or (MODELS.get(job["agent_id"], [None])[0]) or "unknown"

    footer = (
        f"\n\n---\n"
        f"Agent: {job['agent_name']} | Model: {model_id}\n"
        f"Runtime: {elapsed_str} | Tokens: {tokens_in:,} in / {tokens_out:,} out | Cost: {format_cost(cost)}"
    )

    return job.get("output", "") + footer


# ---------------------------------------------------------------------------
# Script Marketplace (GraphRAG-powered)
# ---------------------------------------------------------------------------


@mcp.tool()
async def search_scripts(query: str) -> str:
    """Search the marketplace for scripts matching a natural language query.
    Returns top 5 results with vending codes, descriptions, and pricing.

    Args:
        query: Natural language description of what you need (e.g. "analyze CSV data").
    """
    from graph import embed_query as _embed_query
    from graph import is_available as _graph_available
    from graph import search_scripts as _graph_search

    if _graph_available():
        try:
            query_embedding = _embed_query(query)
            results = _graph_search(query_embedding, limit=5)
            if results:
                lines = [f'Search results for "{query}":\n']
                for r in results:
                    status = r.get("validationStatus", "unknown")
                    badge = {"approved": "[APPROVED]", "flagged": "[FLAGGED]"}.get(status, "")
                    lines.append(f"  {r['vendingCode']} — {r['name']} (${r['price']:.2f}/run) {badge}")
                    lines.append(f"    {r['description']}")
                    lines.append(f"    Input: {r.get('inputSchema', 'Any text')}")
                    lines.append(
                        f"    Creator: {r.get('creator', 'unknown')} | Runs: {r.get('runs', 0)} | Score: {r['score']:.2f}"
                    )
                    lines.append("")
                lines.append('Use run(vending_code="S-XXXX", input="...") to execute a script.')
                return "\n".join(lines)
        except Exception as e:
            logger.warning(f"Graph search failed: {e}")

    # Fallback: list from in-memory store
    scripts = _list_scripts()
    if not scripts:
        return "No scripts available."

    lines = ["Available scripts:\n"]
    for s in scripts:
        code = s.get("vending_code", s["script_id"])
        lines.append(f"  {code} — {s['name']} (${s['price']:.2f}/run)")
        lines.append(f"    {s['description']}")
        lines.append("")
    return "\n".join(lines)


@mcp.tool()
async def run(vending_code: str, user_input: str) -> str:
    """Run a marketplace script by its vending code (e.g. S-7K2M).
    Returns a job_id for polling via check_job.

    Args:
        vending_code: The script's vending code from search_scripts (e.g. "S-7K2M").
        user_input: Text input for the script (check the script's input_schema for format).
    """
    from scripts import get_script_by_vending_code

    script = get_script_by_vending_code(vending_code)
    if not script:
        return f"Error: Script '{vending_code}' not found. Use search_scripts() to find scripts."

    if not _sandbox_available():
        return "Error: E2B_API_KEY not configured."

    # Credit check
    cost = _script_cost(script["price"])
    allowed, balance, _ = _check_balance(_MCP_USER_ID, cost)
    if not allowed:
        return f"Insufficient credits: {balance}/{cost} needed. Script: {script['name']} costs {cost} credits."
    _deduct_credits(_MCP_USER_ID, cost, f"Script run: {vending_code}")

    job = _create_job(script["script_id"], user_input[:200], name=script["name"])
    job_id = job["job_id"]

    async def _run():
        import time as _time

        start = _time.time()
        try:
            escaped = user_input.replace("\\", "\\\\").replace('"""', '\\"\\"\\"')
            code = f'USER_INPUT = """{escaped}"""\n\n{script["code"]}'

            result = _sandbox_run_code(
                code=code,
                language="python",
                timeout=30,
                packages=script["packages"] if script["packages"] else None,
            )

            elapsed_ms = int((_time.time() - start) * 1000)
            _record_run(script["script_id"], script["price"], session_id=_MCP_SESSION_ID)

            parts = []
            if result["stdout"]:
                parts.append(result["stdout"])
            if result["stderr"]:
                parts.append(f"[stderr]\n{result['stderr']}")
            if result["error"]:
                parts.append(f"[error]\n{result['error']}")

            output = "\n".join(parts) if parts else "(no output)"
            job["status"] = "complete" if result["exit_code"] == 0 else "error"
            job["output"] = output
            job["completed_at"] = _time.time()
            job["runtime_ms"] = elapsed_ms
            job["tokens_in"] = 0
            job["tokens_out"] = 0
            job["cost"] = script["price"]
        except Exception as e:
            job["status"] = "error"
            job["error"] = str(e)
            job["completed_at"] = _time.time()

    bg_task = asyncio.create_task(_run())
    _background_tasks.add(bg_task)
    bg_task.add_done_callback(_background_tasks.discard)

    return (
        f"Running **{script['name']}** ({vending_code}, ${script['price']:.2f})...\n\n"
        f"Job ID: {job_id}\n"
        f"Status: running\n\n"
        f'Use check_job(job_id="{job_id}") to get results.'
    )


@mcp.tool()
async def info(vending_code: str) -> str:
    """Get full details about a script: description, validation report,
    usage stats, similar scripts, and creator info.

    Args:
        vending_code: The script's vending code (e.g. "S-7K2M").
    """
    from graph import get_similar_scripts as _graph_similar
    from graph import is_available as _graph_available
    from scripts import get_script_by_vending_code

    script = get_script_by_vending_code(vending_code)
    if not script:
        return f"Error: Script '{vending_code}' not found."

    lines = [
        f"# {script['name']} ({vending_code})",
        "",
        f"**Description:** {script['description']}",
        f"**Creator:** {script['creator']}",
        f"**Price:** ${script['price']:.2f}/run",
        f"**Input:** {script['input_schema']}",
        f"**Packages:** {', '.join(script['packages']) or 'none'}",
        f"**Runs:** {script['runs']} | **Revenue:** ${script['revenue']:.2f}",
        f"**Validation:** {script.get('validation_status', 'unknown')}",
    ]

    # Similar scripts from graph
    if _graph_available():
        try:
            similar = _graph_similar(vending_code, limit=3)
            if similar:
                lines.append("")
                lines.append("**Similar scripts:**")
                for s in similar:
                    lines.append(f"  - {s['vendingCode']}: {s['name']} (score: {s['score']:.2f})")
        except Exception as e:
            logger.debug("Failed to fetch similar scripts: %s", e)

        # Chain patterns — scripts commonly run after this one
        try:
            from graph import get_script_chains as _graph_chains

            chains = _graph_chains(vending_code)
            if chains:
                lines.append("")
                lines.append("**Commonly chained with (run next):**")
                for c in chains:
                    lines.append(f"  - {c['vendingCode']}: {c['name']} ({c['chainCount']}x)")
        except Exception as e:
            logger.debug("Failed to fetch chain data: %s", e)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Sandbox: run code in E2B
# ---------------------------------------------------------------------------


@mcp.tool()
async def run_code(code: str, language: str = "python", packages: str = "") -> str:
    """Run code in a secure E2B sandbox. Returns stdout, stderr, and any errors.

    Args:
        code: The source code to execute.
        language: "python" or "javascript" (default: python).
        packages: Comma-separated list of packages to install (e.g. "pandas,numpy").
    """
    if not _sandbox_available():
        return "Error: E2B_API_KEY not configured. Add it to your .env file."

    # Credit check for sandbox execution
    from credits import CODE_EXEC_CREDIT_COST

    allowed, balance, _ = _check_balance(_MCP_USER_ID, CODE_EXEC_CREDIT_COST)
    if not allowed:
        return f"Insufficient credits: {balance}/{CODE_EXEC_CREDIT_COST} needed for code execution."
    _deduct_credits(_MCP_USER_ID, CODE_EXEC_CREDIT_COST, "Sandbox code execution")

    pkg_list = [p.strip() for p in packages.split(",") if p.strip()] if packages else None

    try:
        result = _sandbox_run_code(
            code=code,
            language=language,
            timeout=30,
            packages=pkg_list,
        )
    except Exception as e:
        return f"Sandbox error: {e}"

    # Format output
    parts = []
    if result["stdout"]:
        parts.append(result["stdout"])
    if result["stderr"]:
        parts.append(f"[stderr]\n{result['stderr']}")
    if result["error"]:
        parts.append(f"[error]\n{result['error']}")
    if result["results"]:
        for r in result["results"]:
            if r["type"] == "text":
                parts.append(r["value"])

    output = "\n".join(parts) if parts else "(no output)"
    status = "✅" if result["exit_code"] == 0 else "❌"

    return f"{status} Exit code: {result['exit_code']}\n\n{output}"


# ---------------------------------------------------------------------------
# Workflow Engine — chain multiple agents in sequence (async)
# ---------------------------------------------------------------------------

# Workflow definitions: each is a list of steps with agent_id and prompt template.
# Templates use {input} for the initial input and {prev} for previous step output.
WORKFLOWS = {
    "audit_code": {
        "name": "Security Audit",
        "steps": [
            {
                "agent_id": "bug-hunter",
                "prompt": "Review this code for security vulnerabilities, bugs, and performance issues. "
                "Provide severity ratings and fixes.\n\n```\n{input}\n```",
            },
            {
                "agent_id": "test-goblin",
                "prompt": "Generate pytest tests for this code. Focus on the security issues found in this review:\n\n"
                "### Code:\n```\n{input}\n```\n\n### Bug Report:\n{prev}",
            },
            {
                "agent_id": "code-gremlin",
                "prompt": "Fix the security vulnerabilities in this code based on the bug report below. "
                "Return the complete fixed code.\n\n### Original Code:\n```\n{input}\n```\n\n"
                "### Vulnerabilities Found:\n{prev_0}",
            },
        ],
    },
    "ship_feature": {
        "name": "Ship Feature",
        "steps": [
            {
                "agent_id": "code-gremlin",
                "prompt": "Write production-ready {language} code for: {input}\n\n"
                "Include error handling, type hints, and docstrings.",
            },
            {
                "agent_id": "bug-hunter",
                "prompt": "Review this {language} implementation for bugs and security issues:\n\n{prev}",
            },
            {
                "agent_id": "test-goblin",
                "prompt": "Generate comprehensive tests for this {language} code:\n\n{prev_0}",
            },
            {
                "agent_id": "devops-dwarf",
                "prompt": "Generate a production Dockerfile and deployment config for this {language} application:\n\n{prev_0}",
            },
        ],
    },
    "analyze_data": {
        "name": "Data Analysis",
        "steps": [
            {
                "agent_id": "number-crunch",
                "prompt": "Analyze this data. Find trends, outliers, and actionable insights. "
                "Include statistics and visualization recommendations.\n\n{input}",
            },
            {
                "agent_id": "vibe-writer",
                "prompt": "Write a concise executive summary of this data analysis. "
                "Highlight the 3 most important findings and recommended actions.\n\n{prev}",
            },
        ],
    },
    # ----- Engagement packages (white-glove delivery) -----
    "shield": {
        "name": "Shield — Security Audit",
        "steps": [
            {
                "agent_id": "bug-hunter",
                "prompt": (
                    "Perform a comprehensive security audit of this codebase. "
                    "Map every finding to OWASP Top 10 and MITRE ATT&CK. "
                    "Rate each: Critical / High / Medium / Low / Info.\n\n"
                    "Repository: {repo_url}\nScope: {scope_notes}\n\nCode:\n```\n{input}\n```"
                ),
            },
            {
                "agent_id": "test-goblin",
                "prompt": (
                    "Generate a security regression test suite for the vulnerabilities found:\n\n"
                    "### Code:\n```\n{input}\n```\n\n### Vulnerability Report:\n{prev}"
                ),
            },
            {
                "agent_id": "code-gremlin",
                "prompt": (
                    "Generate fix patches for all Critical and High vulnerabilities. "
                    "Return complete fixed code with inline comments explaining each fix.\n\n"
                    "### Original Code:\n```\n{input}\n```\n\n### Vulnerabilities:\n{prev_0}"
                ),
            },
            {
                "agent_id": "pdf-forge",
                "prompt": (
                    "Generate a branded security audit report PDF using Python ReportLab. Output a complete, runnable Python script that generates the PDF using reportlab. Use reportlab.lib.pagesizes, reportlab.platypus, and reportlab.lib.styles. "
                    "Title: 'Shield Security Audit Report'. "
                    "Sections: Executive Summary, Findings Table (severity, OWASP mapping, "
                    "description, remediation status), Test Coverage Summary, Fix Patch Summary, "
                    "Risk Score, Methodology.\n\n"
                    "### Audit Findings:\n{prev_0}\n\n### Test Suite:\n{prev_1}\n\n"
                    "### Fix Patches:\n{prev}"
                ),
            },
        ],
    },
    "blueprint": {
        "name": "Blueprint — Architecture Review",
        "steps": [
            {
                "agent_id": "cloud-sensei",
                "prompt": (
                    "Perform a comprehensive AWS Well-Architected Review. "
                    "Score each of the 6 pillars 1-5. Identify risks, anti-patterns, "
                    "and cost optimization opportunities.\n\n"
                    "Repository: {repo_url}\nScope: {scope_notes}\n\n"
                    "Infrastructure code:\n```\n{input}\n```"
                ),
            },
            {
                "agent_id": "devops-dwarf",
                "prompt": (
                    "Generate hardened IaC templates (CloudFormation or Terraform) that address "
                    "the issues found in the architecture review. Include monitoring and alerting.\n\n"
                    "### Current IaC:\n```\n{input}\n```\n\n### Architecture Review:\n{prev}"
                ),
            },
            {
                "agent_id": "pdf-forge",
                "prompt": (
                    "Generate a branded architecture review report PDF using Python ReportLab. Output a complete, runnable Python script that generates the PDF using reportlab. Use reportlab.lib.pagesizes, reportlab.platypus, and reportlab.lib.styles. "
                    "Title: 'Blueprint Architecture Review'. "
                    "Sections: Executive Summary, Well-Architected Scorecard (6 pillars with scores), "
                    "Risk Register, Cost Optimization Recommendations, Remediation Roadmap, "
                    "IaC Template Summary.\n\n"
                    "### Architecture Review:\n{prev_0}\n\n### Remediation IaC:\n{prev}"
                ),
            },
        ],
    },
    "launchpad": {
        "name": "LaunchPad — Production Readiness",
        "steps": [
            {
                "agent_id": "bug-hunter",
                "prompt": (
                    "Security audit for production readiness. OWASP + MITRE mapping. "
                    "Focus on auth, injection, secrets, and deployment attack surface.\n\n"
                    "Repository: {repo_url}\nScope: {scope_notes}\n\nCode:\n```\n{input}\n```"
                ),
            },
            {
                "agent_id": "cloud-sensei",
                "prompt": (
                    "AWS production readiness review. Score Well-Architected pillars. "
                    "Check monitoring, alerting, DR, scaling, and cost.\n\n"
                    "### Code:\n```\n{input}\n```\n\n### Security Findings:\n{prev}"
                ),
            },
            {
                "agent_id": "devops-dwarf",
                "prompt": (
                    "Generate production deployment artifacts: Dockerfile, CI/CD pipeline, "
                    "monitoring config, IaC with security fixes applied.\n\n"
                    "### Code:\n```\n{input}\n```\n\n### Architecture Review:\n{prev}"
                ),
            },
            {
                "agent_id": "test-goblin",
                "prompt": (
                    "Generate comprehensive test suite: unit, integration, security regression, "
                    "and load test skeletons.\n\n"
                    "### Code:\n```\n{input}\n```\n\n### Security Findings:\n{prev_0}"
                ),
            },
            {
                "agent_id": "code-gremlin",
                "prompt": (
                    "Apply all Critical/High security fixes and add production hardening: "
                    "structured logging, health checks, graceful shutdown, retry patterns.\n\n"
                    "### Code:\n```\n{input}\n```\n\n### Security Findings:\n{prev_0}\n\n"
                    "### Architecture Review:\n{prev_1}"
                ),
            },
            {
                "agent_id": "pdf-forge",
                "prompt": (
                    "Generate a comprehensive production readiness report PDF using Python ReportLab. Output a complete, runnable Python script that generates the PDF using reportlab. Use reportlab.lib.pagesizes, reportlab.platypus, and reportlab.lib.styles. "
                    "Title: 'LaunchPad Production Readiness Report'. "
                    "Sections: Executive Summary, Security Audit (findings table with severity), "
                    "Architecture Scorecard (6 pillars), Deployment Checklist, "
                    "Test Coverage Matrix, Remediation Summary, Go/No-Go Recommendation.\n\n"
                    "### Security:\n{prev_0}\n### Architecture:\n{prev_1}\n"
                    "### Deployment:\n{prev_2}\n### Tests:\n{prev_3}\n### Fixes:\n{prev}"
                ),
            },
        ],
    },
}


async def _wait_for_job(job_id: str, timeout: float = 1800) -> dict:
    """Poll a job until it completes or times out."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        job = _get_job(job_id)
        if not job:
            return {"status": "error", "output": f"Job {job_id} not found", "runtime_ms": 0, "cost": 0}
        if job["status"] in ("complete", "error", "cancelled", "expired"):
            return job
        await asyncio.sleep(3)
    return {"status": "error", "output": "Workflow step timed out", "runtime_ms": 0, "cost": 0}


async def _run_workflow_background(workflow_job_id: str, workflow_key: str, user_input: str, **kwargs: str) -> None:
    """Run a multi-step workflow in the background, updating the parent job on completion."""
    parent = JOB_STORE.get(workflow_job_id)
    if not parent:
        return

    workflow = WORKFLOWS[workflow_key]
    step_results: list[dict] = []
    total_cost = 0.0
    total_ms = 0

    for step in workflow["steps"]:
        # Build prompt with template substitution — supports {prev_N} for any step index
        prev_map: dict[str, str] = {f"prev_{i}": sr["output"][:4000] for i, sr in enumerate(step_results)}
        prev_map["prev"] = step_results[-1]["output"][:8000] if step_results else ""
        prev_map["input"] = user_input[:8000]
        prev_map.update(kwargs)

        prompt = step["prompt"].format_map(
            {**prev_map, **{k: "" for k in __import__("re").findall(r"\{(\w+)\}", step["prompt"]) if k not in prev_map}}
        )

        # Run the agent step
        sub_job = _create_job(step["agent_id"], prompt[:200], name=AGENT_META[step["agent_id"]]["name"])
        bg = asyncio.create_task(_run_job_background(sub_job["job_id"]))
        _background_tasks.add(bg)
        bg.add_done_callback(_background_tasks.discard)

        result = await _wait_for_job(sub_job["job_id"])
        step_results.append({"agent_id": step["agent_id"], **result})
        total_cost += result.get("cost", 0)
        total_ms += result.get("runtime_ms", 0)

        # If a step fails, stop the workflow
        if result["status"] == "error":
            agent_name = AGENT_META[step["agent_id"]]["name"]
            parent["status"] = "error"
            parent["error"] = f"{agent_name} failed: {result.get('error', result.get('output', 'unknown'))}"
            parent["completed_at"] = time.time()
            parent["runtime_ms"] = total_ms
            parent["cost"] = total_cost
            return

    # Format combined output
    sections: list[str] = []
    for sr in step_results:
        agent_name = AGENT_META.get(sr["agent_id"], {}).get("name", sr["agent_id"])
        sections.append(f"## {agent_name}\n\n{sr['output']}")

    elapsed = f"{total_ms / 1000:.1f}s" if total_ms < 60_000 else f"{total_ms / 60_000:.1f}m"
    footer = (
        f"\n\n---\n"
        f"Workflow: {workflow['name']} | {len(step_results)} agents | "
        f"Runtime: {elapsed} | Cost: {format_cost(total_cost)}"
    )

    parent["status"] = "complete"
    parent["output"] = "\n\n".join(sections) + footer
    parent["completed_at"] = time.time()
    parent["runtime_ms"] = total_ms
    parent["cost"] = total_cost


@mcp.tool()
async def audit_code(code: str) -> str:
    """Full security audit pipeline: Bug Hunter finds vulnerabilities, Test Goblin
    generates regression tests, Code Gremlin writes fixes. Returns combined report.

    Args:
        code: The source code to audit (paste the full code).
    """
    # Credit check for workflow
    cost = _workflow_cost("audit_code")
    allowed, balance, _ = _check_balance(_MCP_USER_ID, cost)
    if not allowed:
        return f"Insufficient credits: {balance}/{cost} needed. Security Audit workflow costs {cost} credits."
    _deduct_credits(_MCP_USER_ID, cost, "Workflow: audit_code")

    job = _create_job("audit_code", code[:200], name="Security Audit Workflow")
    bg = asyncio.create_task(_run_workflow_background(job["job_id"], "audit_code", code))
    _background_tasks.add(bg)
    bg.add_done_callback(_background_tasks.discard)

    return (
        f"Security Audit workflow started (Bug Hunter → Test Goblin → Code Gremlin).\n\n"
        f"Job ID: {job['job_id']}\n"
        f"Status: running\n"
        f"ETA: 3-10 minutes\n\n"
        f'Use check_job(job_id="{job["job_id"]}") to poll for results.'
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="stdio")
