"""
Supabase client — singleton for backend use.

Uses the service role (secret) key to bypass RLS.
All modules import get_supabase() from here.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger("supabase_client")

_client = None
_available = False


def is_available() -> bool:
    """Check if Supabase credentials are configured."""
    return bool(os.getenv("SUPABASE_URL")) and bool(os.getenv("SUPABASE_SECRET_KEY"))


def get_supabase():
    """Get the singleton Supabase client. Returns None if not configured."""
    global _client, _available

    if _client is not None:
        return _client

    url = os.getenv("SUPABASE_URL", "")
    key = os.getenv("SUPABASE_SECRET_KEY", "")

    if not url or not key:
        logger.info("SUPABASE_URL or SUPABASE_SECRET_KEY not set — database features disabled")
        _available = False
        return None

    try:
        from supabase import create_client

        _client = create_client(url, key)
        _available = True
        logger.info("Supabase client initialized: %s", url[:40])
        return _client
    except ImportError:
        logger.warning("supabase package not installed — pip install supabase")
        _available = False
        return None
    except Exception as e:
        logger.error("Failed to initialize Supabase client: %s", e)
        _available = False
        return None


def get_sb():
    """Safe wrapper — returns Supabase client or None.

    Use this instead of duplicating _get_sb() in every module:
        from supabase_client import get_sb
        sb = get_sb()
        if not sb: return
    """
    if not is_available():
        return None
    return get_supabase()
