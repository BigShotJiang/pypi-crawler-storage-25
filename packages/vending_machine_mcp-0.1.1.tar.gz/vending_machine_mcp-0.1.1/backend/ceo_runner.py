"""
CEO Agent job runner — thin bridge between main.py and the Claude Agent SDK CEO agent.

Follows the same pattern as job_runner.py but calls run_ceo_agent() instead of graph.astream().
Used when CEO tasks are submitted via REST /api/jobs (fallback path).
The primary path is the /ws/ceo WebSocket which streams to the War Room UI.
"""

import time

from agents.registry import estimate_tokens
from jobs import JobStatus, get_job, update_job


async def run_ceo_job(job_id: str) -> None:
    """Run the CEO agent as a background job."""
    job = get_job(job_id)
    if not job:
        return

    update_job(job_id, status=JobStatus.running, started_at=time.time())
    start_time = time.time()

    # Progress callback that writes structured steps to job store
    async def _job_progress(event: dict) -> None:
        current_job = get_job(job_id)
        if not current_job:
            return
        steps = current_job["steps"]
        step_type = event.get("type", "unknown")
        output = event.get("plan") or event.get("partial") or event.get("output") or event.get("message") or ""
        if event.get("agentName"):
            output = f"> {event['agentName']}: {event.get('task', '')[:100]}"
        steps.append({"step": step_type, "output": output})
        update_job(job_id, steps=steps)

    try:
        from agents.ceo_agent import run_ceo_agent

        await run_ceo_agent(job["task"], job_id, progress_callback=_job_progress)

        # Finalize metadata — merge with what run_ceo_agent already stored
        # (it may have set delegation costs, real token counts, etc.)
        elapsed_ms = int((time.time() - start_time) * 1000)
        final_job = get_job(job_id)
        full_output = final_job["output"] if final_job else ""
        existing_meta = final_job.get("metadata") or {} if final_job else {}

        merged_meta = {
            "agentId": "ceo-agent",
            "agentName": "CEO Agent",
            "model": "claude-sonnet-4-6",
            "runtimeMs": elapsed_ms,
            "inputTokens": existing_meta.get("inputTokens") or estimate_tokens(job["task"]),
            "outputTokens": existing_meta.get("outputTokens") or estimate_tokens(full_output),
            "cost": existing_meta.get("cost", 0),
            "timestamp": int(time.time() * 1000),
        }
        # Preserve delegation breakdown if CEO set it
        if "delegations" in existing_meta:
            merged_meta["delegations"] = existing_meta["delegations"]

        update_job(
            job_id,
            status=JobStatus.complete,
            completed_at=time.time(),
            metadata=merged_meta,
        )

    except Exception as e:
        elapsed_ms = int((time.time() - start_time) * 1000)
        update_job(
            job_id,
            status=JobStatus.error,
            completed_at=time.time(),
            error=str(e),
            metadata={
                "agentId": "ceo-agent",
                "agentName": "CEO Agent",
                "runtimeMs": elapsed_ms,
                "inputTokens": estimate_tokens(job["task"]),
                "outputTokens": 0,
                "timestamp": int(time.time() * 1000),
            },
        )
