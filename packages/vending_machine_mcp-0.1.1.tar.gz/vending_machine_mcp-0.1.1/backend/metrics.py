"""
Metrics collection and Prometheus-compatible export.

Provides in-process counters and gauges that are exposed via /metrics
in both JSON and Prometheus text format. No external dependency needed.

Usage:
    from metrics import inc, gauge, export_prometheus, export_json

    inc("requests_total", labels={"method": "POST", "path": "/api/jobs"})
    gauge("active_jobs", 5)
    text = export_prometheus()
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from threading import Lock

logger = logging.getLogger("metrics")

_START_TIME = time.time()
_lock = Lock()

# Counters: monotonically increasing values
_counters: dict[str, float] = defaultdict(float)

# Gauges: point-in-time values
_gauges: dict[str, float] = {}

# Labeled counters: key = (metric_name, label_key, label_value)
_labeled_counters: dict[tuple[str, str, str], float] = defaultdict(float)


# ─── Recording ────────────────────────────────────────────────────────────


def inc(name: str, amount: float = 1, labels: dict[str, str] | None = None) -> None:
    """Increment a counter."""
    with _lock:
        _counters[name] += amount
        if labels:
            for k, v in labels.items():
                _labeled_counters[(name, k, v)] += amount


def gauge(name: str, value: float) -> None:
    """Set a gauge to a specific value."""
    with _lock:
        _gauges[name] = value


def get_counter(name: str) -> float:
    """Get current counter value."""
    return _counters.get(name, 0)


# ─── Export ───────────────────────────────────────────────────────────────


def export_json() -> dict:
    """Export all metrics as a JSON-friendly dict."""
    uptime = time.time() - _START_TIME
    total = _counters.get("requests_total", 0)
    errors = _counters.get("requests_4xx", 0) + _counters.get("requests_5xx", 0)

    result = {
        "uptime_seconds": round(uptime, 1),
        "error_rate": round(errors / max(total, 1), 4),
    }

    # Add all counters
    with _lock:
        for k, v in sorted(_counters.items()):
            result[k] = v

        # Add all gauges
        for k, v in sorted(_gauges.items()):
            result[k] = v

        # Add labeled breakdowns
        breakdowns: dict[str, dict[str, float]] = defaultdict(dict)
        for (metric, label_key, label_value), count in sorted(_labeled_counters.items()):
            breakdowns[f"{metric}_by_{label_key}"][label_value] = count
        for k, v in breakdowns.items():
            result[k] = v

    return result


def export_prometheus() -> str:
    """Export metrics in Prometheus text exposition format."""
    lines = []

    lines.append("# HELP vm_uptime_seconds Server uptime in seconds")
    lines.append("# TYPE vm_uptime_seconds gauge")
    lines.append(f"vm_uptime_seconds {time.time() - _START_TIME:.1f}")

    with _lock:
        # Counters
        for name, value in sorted(_counters.items()):
            safe_name = name.replace(".", "_")
            lines.append(f"# TYPE vm_{safe_name} counter")
            lines.append(f"vm_{safe_name} {value}")

        # Gauges
        for name, value in sorted(_gauges.items()):
            safe_name = name.replace(".", "_")
            lines.append(f"# TYPE vm_{safe_name} gauge")
            lines.append(f"vm_{safe_name} {value}")

        # Labeled counters
        grouped: dict[str, list[tuple[str, str, float]]] = defaultdict(list)
        for (metric, label_key, label_value), count in _labeled_counters.items():
            grouped[metric].append((label_key, label_value, count))

        for metric, entries in sorted(grouped.items()):
            safe_name = metric.replace(".", "_")
            lines.append(f"# TYPE vm_{safe_name} counter")
            for label_key, label_value, count in sorted(entries):
                safe_value = label_value.replace('"', '\\"')
                lines.append(f'vm_{safe_name}{{{label_key}="{safe_value}"}} {count}')

    lines.append("")
    return "\n".join(lines)
