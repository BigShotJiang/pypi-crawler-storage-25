"""
Notification service for the Vending Machine portal.

Sends notifications to users and admins when script submissions
change status. Uses Supabase for persistence and Resend for email delivery.
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger("notifications")

_RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
_FROM_EMAIL = os.environ.get("NOTIFICATION_FROM_EMAIL", "Vending Machine <notifications@yokiistudio.com>")
_PORTAL_URL = os.environ.get("PORTAL_URL", "http://localhost:3001")


# ─── Email Sending ──────────────────────────────────────────────────────


def _send_email(to: str, subject: str, html: str) -> None:
    """Send an email via Resend. Silently skips if RESEND_API_KEY is not set."""
    if not _RESEND_API_KEY:
        logger.debug("RESEND_API_KEY not set — skipping email to %s: %s", to, subject)
        return

    try:
        import resend

        resend.api_key = _RESEND_API_KEY
        resend.Emails.send(
            {
                "from": _FROM_EMAIL,
                "to": [to],
                "subject": subject,
                "html": html,
            }
        )
        logger.info("Email sent to %s: %s", to, subject)
    except Exception as e:
        logger.warning("Failed to send email to %s: %s", to, e)


def _should_send_email(user_email: str, pref_key: str) -> bool:
    """Check if the user has opted in for this email type."""
    sb = _get_sb()
    if not sb:
        return True  # Default to sending if we can't check prefs

    try:
        # Find user ID from email via auth admin
        user_resp = sb.auth.admin.list_users()
        user_id = None
        for u in user_resp:
            if hasattr(u, "email") and u.email == user_email:
                user_id = u.id
                break
        if not user_id:
            return True

        prefs_result = sb.table("profiles").select("notification_prefs").eq("id", str(user_id)).single().execute()
        if prefs_result.data:
            prefs = prefs_result.data.get("notification_prefs") or {}
            return prefs.get(pref_key, True)  # Default to True if not set
    except Exception as e:
        logger.debug("Failed to check email prefs for %s: %s", user_email, e)

    return True  # Default to sending


def _email_wrapper(subject: str, body_html: str) -> str:
    """Wrap email body in a styled template."""
    return f"""
    <div style="font-family: 'Courier New', monospace; background: #0d0d1a; color: #e0e0e0; padding: 32px; max-width: 560px; margin: 0 auto;">
      <div style="text-align: center; margin-bottom: 24px;">
        <span style="color: #ff2d95; font-size: 18px; font-weight: bold; letter-spacing: 4px;">VENDING MACHINE</span>
        <br/>
        <span style="color: #00f0ff; font-size: 11px; letter-spacing: 2px;">SCRIPT MARKETPLACE</span>
      </div>
      <div style="background: #1a1a2e; border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 24px;">
        {body_html}
      </div>
      <div style="text-align: center; margin-top: 20px; color: #666; font-size: 11px;">
        <a href="{_PORTAL_URL}" style="color: #00f0ff; text-decoration: none;">Open Marketplace</a>
        &nbsp;&middot;&nbsp;
        <a href="{_PORTAL_URL}/profile" style="color: #666; text-decoration: none;">Email Settings</a>
      </div>
    </div>
    """


# ─── Supabase Helpers ────────────────────────────────────────────────────


def _get_admin_emails() -> list[str]:
    """Fetch admin emails from the profiles table."""
    sb = _get_sb()
    if not sb:
        return []
    try:
        result = sb.table("profiles").select("id").eq("is_admin", True).execute()
        if not result.data:
            return []
        emails = []
        for row in result.data:
            user_resp = sb.auth.admin.get_user_by_id(row["id"])
            if user_resp and user_resp.user and user_resp.user.email:
                emails.append(user_resp.user.email)
        return emails
    except Exception:
        logger.debug("Failed to fetch admin emails from profiles")
        return []


def _get_sb():
    """Get Supabase client if available."""
    try:
        from supabase_client import get_supabase, is_available

        if not is_available():
            return None
        return get_supabase()
    except Exception:
        return None


def _insert_notification(
    user_email: str,
    notification_type: str,
    title: str,
    message: str,
    script_id: str | None = None,
) -> dict[str, Any] | None:
    """Insert a notification into Supabase."""
    sb = _get_sb()
    if not sb:
        logger.debug("Supabase not available — notification not persisted: %s", title)
        return None

    data = {
        "user_email": user_email,
        "type": notification_type,
        "title": title,
        "message": message,
        "script_id": script_id,
        "read": False,
    }

    try:
        result = sb.table("notifications").insert(data).execute()
        if result.data:
            logger.info("Notification sent to %s: %s", user_email, title)
            return result.data[0]
    except Exception as e:
        logger.warning("Failed to insert notification: %s", e)

    return None


# ─── Public Notification Functions ───────────────────────────────────────


def notify_script_submitted(
    creator_email: str,
    script_name: str,
    script_id: str,
    submission_id: str,
) -> None:
    """Notify creator that their script was submitted and is pending review."""
    _insert_notification(
        user_email=creator_email,
        notification_type="script_submitted",
        title="Script Submitted",
        message=f'Your script "{script_name}" (ID: {submission_id}) has been submitted and is pending admin review.',
        script_id=script_id,
    )

    # Email to creator
    if _should_send_email(creator_email, "email_submitted"):
        _send_email(
            to=creator_email,
            subject=f"Script Submitted: {script_name}",
            html=_email_wrapper(
                f"Script Submitted: {script_name}",
                f"""
                <h2 style="color: #fff01f; margin: 0 0 12px;">Script Submitted</h2>
                <p>Your script <strong style="color: #00f0ff;">"{script_name}"</strong> has been submitted for review.</p>
                <div style="background: #0d0d1a; border-radius: 8px; padding: 12px; margin: 16px 0; text-align: center;">
                  <span style="color: #fff01f; font-size: 14px; font-weight: bold;">{submission_id}</span>
                </div>
                <p style="color: #888; font-size: 12px;">Your script will be reviewed by our team. You'll receive an email when it's approved or if changes are needed.</p>
                <div style="text-align: center; margin-top: 20px;">
                  <a href="{_PORTAL_URL}/catalog/{script_id}" style="display: inline-block; background: rgba(0,240,255,0.1); border: 1px solid rgba(0,240,255,0.3); color: #00f0ff; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">View Script</a>
                </div>
                """,
            ),
        )

    # Notify all admins
    for admin_email in _get_admin_emails():
        _insert_notification(
            user_email=admin_email,
            notification_type="admin_new_submission",
            title="New Script Submission",
            message=f'"{script_name}" by {creator_email} is waiting for review. Submission ID: {submission_id}',
            script_id=script_id,
        )

        if _should_send_email(admin_email, "email_admin"):
            _send_email(
                to=admin_email,
                subject=f"[Admin] New submission: {script_name}",
                html=_email_wrapper(
                    f"New Submission: {script_name}",
                    f"""
                    <h2 style="color: #00f0ff; margin: 0 0 12px;">New Script Submission</h2>
                    <p><strong style="color: white;">"{script_name}"</strong> by <span style="color: #00f0ff;">{creator_email}</span> is waiting for review.</p>
                    <div style="background: #0d0d1a; border-radius: 8px; padding: 12px; margin: 16px 0;">
                      <span style="color: #888; font-size: 12px;">Submission ID:</span> <span style="color: #fff01f;">{submission_id}</span>
                    </div>
                    <div style="text-align: center; margin-top: 20px;">
                      <a href="{_PORTAL_URL}/admin" style="display: inline-block; background: rgba(255,45,149,0.1); border: 1px solid rgba(255,45,149,0.3); color: #ff2d95; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">Review in Admin Panel</a>
                    </div>
                    """,
                ),
            )


def notify_script_approved(
    creator_email: str,
    script_name: str,
    script_id: str,
    vending_code: str,
) -> None:
    """Notify creator that their script was approved."""
    _insert_notification(
        user_email=creator_email,
        notification_type="script_approved",
        title="Script Approved!",
        message=f'Your script "{script_name}" has been approved! Vending code: {vending_code}',
        script_id=script_id,
    )

    if _should_send_email(creator_email, "email_approved"):
        _send_email(
            to=creator_email,
            subject=f"Script Approved! {script_name} is live",
            html=_email_wrapper(
                f"Script Approved: {script_name}",
                f"""
                <h2 style="color: #39ff14; margin: 0 0 12px;">Your Script is Live!</h2>
                <p><strong style="color: white;">"{script_name}"</strong> has been approved and is now available in the marketplace.</p>
                <div style="background: #0d0d1a; border: 2px solid #39ff14; border-radius: 12px; padding: 16px; margin: 20px 0; text-align: center;">
                  <span style="color: #39ff14; font-size: 28px; font-weight: bold; letter-spacing: 4px; text-shadow: 0 0 8px rgba(57,255,20,0.5);">{vending_code}</span>
                </div>
                <p style="color: #888; font-size: 12px; text-align: center;">Users can now run your script with this vending code.</p>
                <div style="text-align: center; margin-top: 20px;">
                  <a href="{_PORTAL_URL}/catalog/{script_id}?celebrate=true" style="display: inline-block; background: rgba(57,255,20,0.1); border: 1px solid rgba(57,255,20,0.3); color: #39ff14; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">View Your Script</a>
                </div>
                """,
            ),
        )


def notify_script_rejected(
    creator_email: str,
    script_name: str,
    script_id: str,
    reason: str = "Did not pass admin review.",
) -> None:
    """Notify creator that their script was rejected."""
    _insert_notification(
        user_email=creator_email,
        notification_type="script_rejected",
        title="Script Rejected",
        message=f'Your script "{script_name}" was rejected. Reason: {reason}',
        script_id=script_id,
    )

    if _should_send_email(creator_email, "email_rejected"):
        _send_email(
            to=creator_email,
            subject=f"Script Review: {script_name}",
            html=_email_wrapper(
                f"Script Review: {script_name}",
                f"""
                <h2 style="color: #ff2d95; margin: 0 0 12px;">Script Needs Changes</h2>
                <p><strong style="color: white;">"{script_name}"</strong> did not pass review.</p>
                <div style="background: #0d0d1a; border-left: 3px solid #ff2d95; padding: 12px 16px; margin: 16px 0; color: #ccc; font-size: 13px;">
                  {reason}
                </div>
                <p style="color: #888; font-size: 12px;">You can update your script and resubmit for review.</p>
                <div style="text-align: center; margin-top: 20px;">
                  <a href="{_PORTAL_URL}/catalog/{script_id}" style="display: inline-block; background: rgba(0,240,255,0.1); border: 1px solid rgba(0,240,255,0.3); color: #00f0ff; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">View Report</a>
                </div>
                """,
            ),
        )


def notify_script_auto_rejected(
    creator_email: str,
    script_name: str,
    script_id: str,
) -> None:
    """Notify creator that their script failed automated validation."""
    _insert_notification(
        user_email=creator_email,
        notification_type="script_rejected",
        title="Script Failed Validation",
        message=f'Your script "{script_name}" did not pass the automated security validation pipeline. Check the validation report for details.',
        script_id=script_id,
    )

    if _should_send_email(creator_email, "email_rejected"):
        _send_email(
            to=creator_email,
            subject=f"Validation Failed: {script_name}",
            html=_email_wrapper(
                f"Validation Failed: {script_name}",
                f"""
                <h2 style="color: #ff2d95; margin: 0 0 12px;">Validation Failed</h2>
                <p><strong style="color: white;">"{script_name}"</strong> did not pass the automated security validation pipeline.</p>
                <p style="color: #888; font-size: 12px;">Review the validation report for specific findings. You can fix the issues and resubmit.</p>
                <div style="text-align: center; margin-top: 20px;">
                  <a href="{_PORTAL_URL}/catalog/{script_id}" style="display: inline-block; background: rgba(0,240,255,0.1); border: 1px solid rgba(0,240,255,0.3); color: #00f0ff; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">View Report</a>
                </div>
                """,
            ),
        )


# ─── Engagement Notifications ───────────────────────────────────────────


_PACKAGE_LABELS = {
    "shield": ("Shield", "Security Audit", "#ff2d95"),
    "blueprint": ("Blueprint", "Architecture Review", "#00f0ff"),
    "launchpad": ("LaunchPad", "Production Readiness", "#39ff14"),
}


def notify_engagement_started(user_id: str, package: str, engagement_id: str) -> None:
    """Notify client their engagement pipeline has started."""
    label, desc, color = _PACKAGE_LABELS.get(package, (package, package, "#00f0ff"))
    user_email = _resolve_email(user_id)
    if not user_email:
        return

    _insert_notification(
        user_email=user_email,
        notification_type="engagement_started",
        title=f"{label} engagement started",
        message=f"Your {desc} is now running. You'll be notified when it's ready.",
    )

    if _should_send_email(user_email, "email_engagement"):
        _send_email(
            to=user_email,
            subject=f"{label} — Pipeline Started",
            html=_email_wrapper(
                f"{label} — Pipeline Started",
                f"""
                <h2 style="color: {color}; margin: 0 0 12px;">{label} Engagement Started</h2>
                <p>Your <strong style="color: white;">{desc}</strong> is now running.</p>
                <p style="color: #888; font-size: 12px;">Our agent pipeline is analyzing your codebase. You'll receive a notification when your report is ready.</p>
                <div style="text-align: center; margin-top: 20px;">
                  <a href="{_PORTAL_URL}/engagements/{engagement_id}" style="display: inline-block; background: rgba(0,240,255,0.1); border: 1px solid rgba(0,240,255,0.3); color: #00f0ff; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">Track Progress</a>
                </div>
                """,
            ),
        )


def notify_engagement_ready_for_review(engagement_id: str, package: str) -> None:
    """Notify admins that a premium engagement is ready for human review."""
    label, desc, color = _PACKAGE_LABELS.get(package, (package, package, "#00f0ff"))
    admin_emails = _get_admin_emails()

    for email in admin_emails:
        _send_email(
            to=email,
            subject=f"[Review] {label} engagement ready — {engagement_id[:8]}",
            html=_email_wrapper(
                f"[Review] {label} Engagement",
                f"""
                <h2 style="color: {color}; margin: 0 0 12px;">Premium Engagement Ready for Review</h2>
                <p>A <strong style="color: white;">{desc}</strong> engagement has completed the agent pipeline and needs human review before delivery.</p>
                <p style="color: #888; font-size: 12px;">Engagement ID: {engagement_id}</p>
                <div style="text-align: center; margin-top: 20px;">
                  <a href="{_PORTAL_URL}/engagements/{engagement_id}" style="display: inline-block; background: rgba(255,45,149,0.1); border: 1px solid rgba(255,45,149,0.3); color: #ff2d95; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">Review & Deliver</a>
                </div>
                """,
            ),
        )


def notify_engagement_delivered(user_id: str, package: str, engagement_id: str) -> None:
    """Notify client their engagement report is ready for download."""
    label, desc, color = _PACKAGE_LABELS.get(package, (package, package, "#00f0ff"))
    user_email = _resolve_email(user_id)
    if not user_email:
        return

    _insert_notification(
        user_email=user_email,
        notification_type="engagement_delivered",
        title=f"{label} report delivered",
        message=f"Your {desc} report is ready for download.",
    )

    if _should_send_email(user_email, "email_engagement"):
        _send_email(
            to=user_email,
            subject=f"{label} — Report Delivered",
            html=_email_wrapper(
                f"{label} — Report Delivered",
                f"""
                <h2 style="color: {color}; margin: 0 0 12px;">{label} Report Ready</h2>
                <p>Your <strong style="color: white;">{desc}</strong> report is ready for download.</p>
                <p style="color: #888; font-size: 12px;">The report includes findings, recommendations, and remediation artifacts.</p>
                <div style="text-align: center; margin-top: 20px;">
                  <a href="{_PORTAL_URL}/engagements/{engagement_id}" style="display: inline-block; background: rgba(57,255,20,0.1); border: 1px solid rgba(57,255,20,0.3); color: #39ff14; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 13px;">Download Report</a>
                </div>
                """,
            ),
        )


def notify_engagement_error(user_id: str, package: str, engagement_id: str, error: str) -> None:
    """Notify client that their engagement pipeline encountered an error."""
    label, desc, _color = _PACKAGE_LABELS.get(package, (package, package, "#00f0ff"))
    user_email = _resolve_email(user_id)
    if not user_email:
        return

    _insert_notification(
        user_email=user_email,
        notification_type="engagement_error",
        title=f"{label} engagement error",
        message=f"Your {desc} encountered an error: {error[:200]}",
    )

    if _should_send_email(user_email, "email_engagement"):
        _send_email(
            to=user_email,
            subject=f"{label} — Pipeline Error",
            html=_email_wrapper(
                f"{label} — Pipeline Error",
                f"""
                <h2 style="color: #ff2d95; margin: 0 0 12px;">{label} Pipeline Error</h2>
                <p>Your <strong style="color: white;">{desc}</strong> encountered an error during processing.</p>
                <p style="color: #ff6b6b; font-size: 12px; background: rgba(255,45,149,0.05); padding: 8px 12px; border-radius: 6px;">{error[:200]}</p>
                <p style="color: #888; font-size: 12px;">Our team has been notified. You won't be charged for failed engagements.</p>
                """,
            ),
        )


def _resolve_email(user_id: str) -> str | None:
    """Resolve a user ID to an email address via Supabase auth."""
    sb = _get_sb()
    if not sb:
        return None
    try:
        user_resp = sb.auth.admin.get_user_by_id(user_id)
        if user_resp and user_resp.user and user_resp.user.email:
            return user_resp.user.email
    except Exception:
        logger.debug("Failed to resolve email for user %s", user_id)
    return None


# ─── Read/Query Functions ────────────────────────────────────────────────


def get_notifications(user_email: str, limit: int = 50) -> list[dict[str, Any]]:
    """Get notifications for a user."""
    sb = _get_sb()
    if not sb:
        return []

    try:
        result = (
            sb.table("notifications")
            .select("*")
            .eq("user_email", user_email)
            .order("created_at", desc=True)
            .limit(limit)
            .execute()
        )
        return result.data or []
    except Exception as e:
        logger.warning("Failed to fetch notifications: %s", e)
        return []


def mark_read(notification_id: str) -> None:
    """Mark a notification as read."""
    sb = _get_sb()
    if not sb:
        return

    try:
        sb.table("notifications").update({"read": True}).eq("id", notification_id).execute()
    except Exception as e:
        logger.warning("Failed to mark notification read: %s", e)


def mark_all_read(user_email: str) -> None:
    """Mark all notifications as read for a user."""
    sb = _get_sb()
    if not sb:
        return

    try:
        sb.table("notifications").update({"read": True}).eq("user_email", user_email).eq("read", False).execute()
    except Exception as e:
        logger.warning("Failed to mark all read: %s", e)
