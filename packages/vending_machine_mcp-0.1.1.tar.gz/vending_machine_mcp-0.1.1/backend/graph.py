"""
Graph/search layer for marketplace scripts.

Default backend is SQLite (single product, portable for vendors).
Neo4j remains optional for advanced graph/vector features.

Environment:
- GRAPH_BACKEND: sqlite | neo4j | auto (default: sqlite)
- SCRIPT_INDEX_DB_PATH: path to sqlite db (default: backend/data/script_index.sqlite3)
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import secrets
import sqlite3
import string
import time as _time
from pathlib import Path
from threading import RLock

from neo4j import GraphDatabase

logger = logging.getLogger("graph")

# ---------------------------------------------------------------------------
# Backend selection and connection state
# ---------------------------------------------------------------------------

_driver = None
_sqlite_conn: sqlite3.Connection | None = None
_sqlite_ready = False
_sqlite_lock = RLock()

_CODE_CHARS = string.ascii_uppercase + string.digits

# In-memory session tracking for chain detection.
# Maps session_id -> (last_vending_code, timestamp).
_session_last_run: dict[str, tuple[str, float]] = {}
_CHAIN_WINDOW_SECONDS = 60
_usage_call_count = 0


def _configured_backend() -> str:
    value = os.getenv("GRAPH_BACKEND", "sqlite").strip().lower()
    if value in {"sqlite", "neo4j", "auto"}:
        return value
    logger.warning("Unknown GRAPH_BACKEND=%s, falling back to sqlite", value)
    return "sqlite"


def _neo4j_configured() -> bool:
    return bool(os.getenv("NEO4J_URI", "").strip() and os.getenv("NEO4J_PASSWORD", "").strip())


def _active_backend() -> str:
    configured = _configured_backend()
    if configured == "sqlite":
        return "sqlite"
    if configured == "neo4j":
        return "neo4j" if _neo4j_configured() else "sqlite"
    # auto
    return "neo4j" if _neo4j_configured() else "sqlite"


# ---------------------------------------------------------------------------
# SQLite helpers
# ---------------------------------------------------------------------------


def _default_sqlite_path() -> Path:
    return Path(__file__).resolve().parent / "data" / "script_index.sqlite3"


def _sqlite_path() -> Path:
    configured = os.getenv("SCRIPT_INDEX_DB_PATH", "").strip()
    return Path(configured).expanduser() if configured else _default_sqlite_path()


def _get_sqlite_conn() -> sqlite3.Connection:
    global _sqlite_conn
    if _sqlite_conn is None:
        path = _sqlite_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        _sqlite_conn = sqlite3.connect(path, check_same_thread=False)
        _sqlite_conn.row_factory = sqlite3.Row
        logger.info("SQLite script index connected: %s", path)
    _ensure_sqlite_schema()
    return _sqlite_conn


def _ensure_sqlite_schema() -> None:
    global _sqlite_ready
    if _sqlite_ready:
        return

    conn = _sqlite_conn
    if conn is None:
        return

    with _sqlite_lock:
        if _sqlite_ready:
            return
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS script_index (
                script_id TEXT PRIMARY KEY,
                vending_code TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                creator TEXT NOT NULL,
                price REAL NOT NULL DEFAULT 0,
                runs INTEGER NOT NULL DEFAULT 0,
                revenue REAL NOT NULL DEFAULT 0,
                validation_status TEXT NOT NULL DEFAULT 'pending',
                input_schema TEXT NOT NULL DEFAULT '',
                packages_json TEXT NOT NULL DEFAULT '[]',
                embedding_json TEXT,
                created_at REAL NOT NULL DEFAULT (strftime('%s','now')),
                version INTEGER NOT NULL DEFAULT 1,
                code_hash TEXT NOT NULL DEFAULT ''
            );

            CREATE INDEX IF NOT EXISTS idx_script_index_status ON script_index(validation_status);
            CREATE INDEX IF NOT EXISTS idx_script_index_code ON script_index(vending_code);

            CREATE TABLE IF NOT EXISTS script_chains (
                prev_code TEXT NOT NULL,
                next_code TEXT NOT NULL,
                chain_count INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (prev_code, next_code)
            );
            """
        )
        conn.commit()
        _sqlite_ready = True


def _sqlite_code_exists(code: str) -> bool:
    conn = _get_sqlite_conn()
    row = conn.execute("SELECT 1 FROM script_index WHERE vending_code = ? LIMIT 1", (code,)).fetchone()
    return row is not None


def _sqlite_sync_script(script: dict, embedding: list[float] | None = None) -> str:
    conn = _get_sqlite_conn()
    vending_code = script.get("vending_code") or script.get("vendingCode") or ""
    if not vending_code:
        vending_code = generate_vending_code()

    with _sqlite_lock:
        conn.execute(
            """
            INSERT INTO script_index (
                script_id, vending_code, name, description, creator, price, runs, revenue,
                validation_status, input_schema, packages_json, embedding_json, created_at,
                version, code_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(script_id) DO UPDATE SET
                vending_code=excluded.vending_code,
                name=excluded.name,
                description=excluded.description,
                creator=excluded.creator,
                price=excluded.price,
                runs=excluded.runs,
                revenue=excluded.revenue,
                validation_status=excluded.validation_status,
                input_schema=excluded.input_schema,
                packages_json=excluded.packages_json,
                embedding_json=CASE
                    WHEN excluded.embedding_json IS NULL OR excluded.embedding_json = ''
                    THEN script_index.embedding_json
                    ELSE excluded.embedding_json
                END,
                version=excluded.version,
                code_hash=excluded.code_hash
            """,
            (
                script.get("script_id", ""),
                vending_code,
                script.get("name", ""),
                script.get("description", ""),
                script.get("creator", "unknown"),
                float(script.get("price", 0.0)),
                int(script.get("runs", 0)),
                float(script.get("revenue", 0.0)),
                script.get("validation_status", "pending"),
                script.get("input_schema", ""),
                json.dumps(script.get("packages", [])),
                json.dumps(embedding) if embedding is not None else None,
                float(script.get("created_at", _time.time())),
                int(script.get("version", 1)),
                script.get("code_hash", ""),
            ),
        )
        conn.commit()

    logger.info("Script synced to sqlite index: %s (%s)", vending_code, script.get("name", ""))
    return vending_code


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def _local_hash_embedding(text: str, dims: int = 256) -> list[float]:
    """Fast local embedding fallback for zero-dependency portability."""
    vec = [0.0] * dims
    tokens = [t for t in "".join(c.lower() if c.isalnum() else " " for c in text).split() if len(t) > 1]
    for token in tokens:
        h = hashlib.sha256(token.encode("utf-8")).digest()
        idx = int.from_bytes(h[:2], "big") % dims
        sign = 1.0 if (h[2] % 2 == 0) else -1.0
        weight = 1.0 + (len(token) / 16.0)
        vec[idx] += sign * weight

    norm = math.sqrt(sum(x * x for x in vec))
    if norm == 0:
        return vec
    return [x / norm for x in vec]


# ---------------------------------------------------------------------------
# Neo4j helpers (optional backend)
# ---------------------------------------------------------------------------


def get_driver():
    """Get or create the Neo4j driver (lazy singleton)."""
    global _driver
    if _active_backend() != "neo4j":
        return None

    if _driver is None:
        uri = os.getenv("NEO4J_URI", "")
        user = os.getenv("NEO4J_USER", "neo4j")
        password = os.getenv("NEO4J_PASSWORD", "")
        if not uri or not password:
            logger.warning("NEO4J_URI or NEO4J_PASSWORD not set — falling back to sqlite backend")
            return None
        _driver = GraphDatabase.driver(uri, auth=(user, password))
        logger.info("Neo4j connected: %s", uri)
    return _driver


def _neo4j_available() -> bool:
    try:
        driver = get_driver()
        if not driver:
            return False
        with driver.session() as session:
            session.run("RETURN 1")
        return True
    except Exception:
        return False


def close():
    """Close active DB connections."""
    global _driver, _sqlite_conn, _sqlite_ready
    if _driver:
        _driver.close()
        _driver = None
    if _sqlite_conn:
        _sqlite_conn.close()
        _sqlite_conn = None
        _sqlite_ready = False


def is_available() -> bool:
    """Check if the configured backend is reachable."""
    backend = _active_backend()
    if backend == "neo4j":
        return _neo4j_available()
    try:
        _get_sqlite_conn()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Schema initialization
# ---------------------------------------------------------------------------


def init_graph():
    """Initialize storage indexes for active backend."""
    if _active_backend() == "sqlite":
        _get_sqlite_conn()
        logger.info("SQLite schema initialized")
        return

    driver = get_driver()
    if not driver:
        logger.warning("Neo4j unavailable; sqlite backend will be used")
        _get_sqlite_conn()
        return

    with driver.session() as session:
        session.run("CREATE CONSTRAINT script_id IF NOT EXISTS FOR (s:Script) REQUIRE s.scriptId IS UNIQUE")
        session.run("CREATE CONSTRAINT vending_code IF NOT EXISTS FOR (s:Script) REQUIRE s.vendingCode IS UNIQUE")
        session.run("CREATE CONSTRAINT category_name IF NOT EXISTS FOR (c:Category) REQUIRE c.name IS UNIQUE")
        session.run("CREATE CONSTRAINT creator_name IF NOT EXISTS FOR (c:Creator) REQUIRE c.name IS UNIQUE")
        session.run("CREATE CONSTRAINT package_name IF NOT EXISTS FOR (p:Package) REQUIRE p.name IS UNIQUE")
        session.run("CREATE CONSTRAINT tag_name IF NOT EXISTS FOR (t:Tag) REQUIRE t.name IS UNIQUE")

        session.run(
            """
            CREATE VECTOR INDEX script_embeddings IF NOT EXISTS
            FOR (s:Script) ON (s.embedding)
            OPTIONS {indexConfig: {
                `vector.dimensions`: 1024,
                `vector.similarity_function`: 'cosine'
            }}
            """
        )

        session.run("CREATE TEXT INDEX script_name_text IF NOT EXISTS FOR (s:Script) ON (s.name)")
        session.run("CREATE TEXT INDEX script_desc_text IF NOT EXISTS FOR (s:Script) ON (s.description)")

    logger.info("Neo4j schema initialized")


# ---------------------------------------------------------------------------
# Vending code generation
# ---------------------------------------------------------------------------


def generate_vending_code() -> str:
    """Generate a unique S-XXXX vending code."""
    for _ in range(100):
        code = "S-" + "".join([secrets.choice(_CODE_CHARS) for _ in range(4)])
        if _active_backend() == "neo4j":
            driver = get_driver()
            if not driver:
                if not _sqlite_code_exists(code):
                    return code
                continue
            with driver.session() as session:
                result = session.run(
                    "MATCH (s:Script {vendingCode: $code}) RETURN count(s) AS cnt",
                    code=code,
                )
                if result.single()["cnt"] == 0:
                    return code
        else:
            if not _sqlite_code_exists(code):
                return code

    return "S-" + "".join([secrets.choice(_CODE_CHARS) for _ in range(5)])


# ---------------------------------------------------------------------------
# Embedding helpers
# ---------------------------------------------------------------------------


def embed_script(script: dict) -> list[float]:
    """Generate embedding for a script.

    Uses Voyage code embeddings when VOYAGE_API_KEY is present; otherwise
    falls back to a local hash embedding for portability.
    """
    text = (
        f"{script.get('name', '')}. {script.get('description', '')}. "
        f"Packages: {', '.join(script.get('packages', []))}. "
        f"Input: {script.get('input_schema', '')}. "
        f"Code: {script.get('code', '')[:2000]}"
    )

    voyage_key = os.getenv("VOYAGE_API_KEY", "").strip()
    if not voyage_key:
        return _local_hash_embedding(text)

    try:
        import voyageai

        client = voyageai.Client(api_key=voyage_key)
        result = client.embed([text], model="voyage-code-3", input_type="document")
        return result.embeddings[0]
    except Exception as e:
        logger.warning("Voyage embedding failed, falling back to local hash embedding: %s", e)
        return _local_hash_embedding(text)


def embed_query(query: str) -> list[float]:
    """Generate embedding for a query."""
    voyage_key = os.getenv("VOYAGE_API_KEY", "").strip()
    if not voyage_key:
        return _local_hash_embedding(query)

    try:
        import voyageai

        client = voyageai.Client(api_key=voyage_key)
        result = client.embed([query], model="voyage-code-3", input_type="query")
        return result.embeddings[0]
    except Exception as e:
        logger.warning("Voyage query embedding failed, falling back to local hash embedding: %s", e)
        return _local_hash_embedding(query)


# ---------------------------------------------------------------------------
# Script CRUD
# ---------------------------------------------------------------------------


def sync_script_to_graph(script: dict, embedding: list[float] | None = None) -> str:
    """Upsert script into the active backend."""
    if _active_backend() == "sqlite":
        return _sqlite_sync_script(script, embedding=embedding)

    driver = get_driver()
    if not driver:
        return _sqlite_sync_script(script, embedding=embedding)

    vending_code = script.get("vending_code") or script.get("vendingCode") or ""
    if not vending_code:
        with driver.session() as session:
            result = session.run(
                "MATCH (s:Script {scriptId: $scriptId}) RETURN s.vendingCode AS code",
                scriptId=script["script_id"],
            )
            record = result.single()
            if record and record["code"]:
                vending_code = record["code"]

    if not vending_code:
        vending_code = generate_vending_code()

    with driver.session() as session:
        session.run(
            """
            MERGE (s:Script {scriptId: $scriptId})
            SET s.vendingCode = $vendingCode,
                s.name = $name,
                s.description = $description,
                s.creator = $creator,
                s.price = $price,
                s.runs = $runs,
                s.revenue = $revenue,
                s.validationStatus = $validationStatus,
                s.inputSchema = $inputSchema,
                s.createdAt = $createdAt,
                s.version = $version,
                s.codeHash = $codeHash
            """,
            scriptId=script["script_id"],
            vendingCode=vending_code,
            name=script["name"],
            description=script["description"],
            creator=script["creator"],
            price=script["price"],
            runs=script.get("runs", 0),
            revenue=script.get("revenue", 0.0),
            validationStatus=script.get("validation_status", "pending"),
            inputSchema=script.get("input_schema", ""),
            createdAt=script.get("created_at", 0.0),
            version=script.get("version", 1),
            codeHash=script.get("code_hash", ""),
        )

        if embedding:
            session.run(
                "MATCH (s:Script {scriptId: $scriptId}) SET s.embedding = $embedding",
                scriptId=script["script_id"],
                embedding=embedding,
            )

        session.run(
            """
            MERGE (c:Creator {name: $creator})
            WITH c
            MATCH (s:Script {scriptId: $scriptId})
            MERGE (s)-[:CREATED_BY]->(c)
            """,
            creator=script["creator"],
            scriptId=script["script_id"],
        )

        for pkg in script.get("packages", []):
            session.run(
                """
                MERGE (p:Package {name: $pkg})
                WITH p
                MATCH (s:Script {scriptId: $scriptId})
                MERGE (s)-[:DEPENDS_ON]->(p)
                """,
                pkg=pkg,
                scriptId=script["script_id"],
            )

    logger.info("Script synced to graph: %s (%s)", vending_code, script["name"])
    return vending_code


def remove_script_from_graph(script_id: str):
    """Remove a script from active backend."""
    if _active_backend() == "sqlite":
        conn = _get_sqlite_conn()
        with _sqlite_lock:
            row = conn.execute("SELECT vending_code FROM script_index WHERE script_id = ?", (script_id,)).fetchone()
            conn.execute("DELETE FROM script_index WHERE script_id = ?", (script_id,))
            if row:
                code = row["vending_code"]
                conn.execute("DELETE FROM script_chains WHERE prev_code = ? OR next_code = ?", (code, code))
            conn.commit()
        return

    driver = get_driver()
    if not driver:
        return

    with driver.session() as session:
        session.run("MATCH (s:Script {scriptId: $scriptId}) DETACH DELETE s", scriptId=script_id)


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


def search_scripts(query_embedding: list[float], limit: int = 5) -> list[dict]:
    """Vector similarity search over active backend."""
    if _active_backend() == "sqlite":
        conn = _get_sqlite_conn()
        rows = conn.execute(
            """
            SELECT vending_code, name, description, price, runs, validation_status, input_schema, creator, embedding_json
            FROM script_index
            WHERE validation_status IN ('approved', 'flagged')
            """
        ).fetchall()

        scored: list[dict] = []
        for row in rows:
            if not row["embedding_json"]:
                continue
            try:
                embedding = json.loads(row["embedding_json"])
            except Exception as e:
                logger.debug("Bad embedding JSON for %s: %s", row.get("vending_code", "?"), e)
                continue
            score = _cosine_similarity(query_embedding, embedding)
            scored.append(
                {
                    "vendingCode": row["vending_code"],
                    "name": row["name"],
                    "description": row["description"],
                    "price": float(row["price"]),
                    "runs": int(row["runs"]),
                    "validationStatus": row["validation_status"],
                    "inputSchema": row["input_schema"],
                    "creator": row["creator"],
                    "score": score,
                }
            )

        scored.sort(key=lambda r: r["score"], reverse=True)
        return scored[:limit]

    driver = get_driver()
    if not driver:
        return []

    with driver.session() as session:
        result = session.run(
            """
            CALL db.index.vector.queryNodes('script_embeddings', $limit, $queryVector)
            YIELD node, score
            WHERE node.validationStatus IN ['approved', 'flagged']
            OPTIONAL MATCH (node)-[:CREATED_BY]->(c:Creator)
            RETURN
                node.vendingCode AS vendingCode,
                node.name AS name,
                node.description AS description,
                node.price AS price,
                node.runs AS runs,
                node.validationStatus AS validationStatus,
                node.inputSchema AS inputSchema,
                c.name AS creator,
                score
            ORDER BY score DESC
            """,
            limit=limit,
            queryVector=query_embedding,
        )
        return [dict(record) for record in result]


def get_script_by_code(vending_code: str) -> dict | None:
    """Look up a script by its vending code."""
    if _active_backend() == "sqlite":
        conn = _get_sqlite_conn()
        row = conn.execute(
            """
            SELECT script_id, vending_code, name, description, creator, price, runs,
                   revenue, validation_status, input_schema, packages_json
            FROM script_index
            WHERE vending_code = ?
            LIMIT 1
            """,
            (vending_code,),
        ).fetchone()
        if not row:
            return None
        return {
            "scriptId": row["script_id"],
            "vendingCode": row["vending_code"],
            "name": row["name"],
            "description": row["description"],
            "creator": row["creator"],
            "price": float(row["price"]),
            "runs": int(row["runs"]),
            "revenue": float(row["revenue"]),
            "validationStatus": row["validation_status"],
            "inputSchema": row["input_schema"],
            "packages": json.loads(row["packages_json"] or "[]"),
        }

    driver = get_driver()
    if not driver:
        return None

    with driver.session() as session:
        result = session.run(
            """
            MATCH (s:Script {vendingCode: $code})
            OPTIONAL MATCH (s)-[:CREATED_BY]->(c:Creator)
            OPTIONAL MATCH (s)-[:DEPENDS_ON]->(p:Package)
            RETURN s, c.name AS creator, collect(p.name) AS packages
            """,
            code=vending_code,
        )
        record = result.single()
        if not record:
            return None

        node = record["s"]
        return {
            "scriptId": node["scriptId"],
            "vendingCode": node["vendingCode"],
            "name": node["name"],
            "description": node["description"],
            "creator": record["creator"],
            "price": node["price"],
            "runs": node["runs"],
            "revenue": node.get("revenue", 0.0),
            "validationStatus": node["validationStatus"],
            "inputSchema": node.get("inputSchema", ""),
            "packages": record["packages"],
        }


# ---------------------------------------------------------------------------
# Usage tracking
# ---------------------------------------------------------------------------


def record_usage(vending_code: str, caller: str = "anonymous", session_id: str = ""):
    """Record a script execution and optional chain usage."""
    del caller  # currently unused

    global _usage_call_count
    _usage_call_count += 1

    if _active_backend() == "sqlite":
        conn = _get_sqlite_conn()
        with _sqlite_lock:
            conn.execute(
                "UPDATE script_index SET runs = runs + 1 WHERE vending_code = ?",
                (vending_code,),
            )

            if session_id:
                prev = _session_last_run.get(session_id)
                if prev:
                    prev_code, prev_time = prev
                    if prev_code != vending_code and (_time.time() - prev_time) < _CHAIN_WINDOW_SECONDS:
                        conn.execute(
                            """
                            INSERT INTO script_chains (prev_code, next_code, chain_count)
                            VALUES (?, ?, 1)
                            ON CONFLICT(prev_code, next_code)
                            DO UPDATE SET chain_count = chain_count + 1
                            """,
                            (prev_code, vending_code),
                        )
                _session_last_run[session_id] = (vending_code, _time.time())

            conn.commit()

        if _usage_call_count % 100 == 0:
            _cleanup_stale_sessions()
        return

    driver = get_driver()
    if not driver:
        if session_id:
            _session_last_run[session_id] = (vending_code, _time.time())
        if _usage_call_count % 100 == 0:
            _cleanup_stale_sessions()
        return

    with driver.session() as db:
        db.run(
            """
            MATCH (s:Script {vendingCode: $code})
            SET s.runs = coalesce(s.runs, 0) + 1
            """,
            code=vending_code,
        )

        if session_id:
            prev = _session_last_run.get(session_id)
            if prev:
                prev_code, prev_time = prev
                if prev_code != vending_code and (_time.time() - prev_time) < _CHAIN_WINDOW_SECONDS:
                    db.run(
                        """
                        MATCH (a:Script {vendingCode: $prev}), (b:Script {vendingCode: $curr})
                        MERGE (a)-[r:CHAINS_WITH]->(b)
                        ON CREATE SET r.count = 1
                        ON MATCH SET r.count = r.count + 1
                        """,
                        prev=prev_code,
                        curr=vending_code,
                    )
            _session_last_run[session_id] = (vending_code, _time.time())

    if _usage_call_count % 100 == 0:
        _cleanup_stale_sessions()


def _cleanup_stale_sessions():
    cutoff = _time.time() - 300
    stale = [sid for sid, (_, ts) in _session_last_run.items() if ts < cutoff]
    for sid in stale:
        del _session_last_run[sid]


# ---------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------


def get_similar_scripts(vending_code: str, limit: int = 3) -> list[dict]:
    """Find scripts similar to the given script code."""
    if _active_backend() == "sqlite":
        conn = _get_sqlite_conn()
        src = conn.execute(
            "SELECT embedding_json FROM script_index WHERE vending_code = ? LIMIT 1",
            (vending_code,),
        ).fetchone()
        if not src or not src["embedding_json"]:
            return []
        source_embedding = json.loads(src["embedding_json"])

        rows = conn.execute(
            """
            SELECT vending_code, name, description, embedding_json
            FROM script_index
            WHERE vending_code <> ? AND validation_status IN ('approved', 'flagged')
            """,
            (vending_code,),
        ).fetchall()

        scored = []
        for row in rows:
            if not row["embedding_json"]:
                continue
            try:
                emb = json.loads(row["embedding_json"])
            except Exception as e:
                logger.debug("Bad embedding JSON: %s", e)
                continue
            scored.append(
                {
                    "vendingCode": row["vending_code"],
                    "name": row["name"],
                    "description": row["description"],
                    "score": _cosine_similarity(source_embedding, emb),
                }
            )
        scored.sort(key=lambda item: item["score"], reverse=True)
        return scored[:limit]

    driver = get_driver()
    if not driver:
        return []

    with driver.session() as session:
        result = session.run(
            "MATCH (s:Script {vendingCode: $code}) RETURN s.embedding AS embedding",
            code=vending_code,
        )
        record = result.single()
        if not record or not record["embedding"]:
            return []

        similar = session.run(
            """
            CALL db.index.vector.queryNodes('script_embeddings', $limit, $embedding)
            YIELD node, score
            WHERE node.vendingCode <> $code AND node.validationStatus IN ['approved', 'flagged']
            RETURN node.vendingCode AS vendingCode, node.name AS name,
                   node.description AS description, score
            """,
            limit=limit + 1,
            embedding=record["embedding"],
            code=vending_code,
        )
        return [dict(r) for r in similar][:limit]


def get_script_chains(vending_code: str) -> list[dict]:
    """Find scripts commonly run after this one."""
    if _active_backend() == "sqlite":
        conn = _get_sqlite_conn()
        rows = conn.execute(
            """
            SELECT c.next_code AS vendingCode, s.name AS name, c.chain_count AS chainCount
            FROM script_chains c
            JOIN script_index s ON s.vending_code = c.next_code
            WHERE c.prev_code = ? AND s.validation_status IN ('approved', 'flagged')
            ORDER BY c.chain_count DESC
            LIMIT 3
            """,
            (vending_code,),
        ).fetchall()
        return [dict(row) for row in rows]

    driver = get_driver()
    if not driver:
        return []

    with driver.session() as session:
        result = session.run(
            """
            MATCH (s:Script {vendingCode: $code})-[r:CHAINS_WITH]->(next:Script)
            WHERE next.validationStatus IN ['approved', 'flagged']
            RETURN next.vendingCode AS vendingCode, next.name AS name, r.count AS chainCount
            ORDER BY r.count DESC
            LIMIT 3
            """,
            code=vending_code,
        )
        return [dict(r) for r in result]
