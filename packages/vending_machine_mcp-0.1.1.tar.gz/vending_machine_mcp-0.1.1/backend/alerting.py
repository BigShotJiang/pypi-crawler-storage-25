"""
Alerting — checks metrics and sends email/log alerts when thresholds are crossed.

Runs periodically alongside the job reaper. Uses Resend for email delivery
(same integration as notification system).

Alert conditions:
- Error rate > 5% in last 15 minutes
- Stuck jobs > 3
- Spend rate > $1/hour
- Job failure spike (> 5 failures in 15 min)
"""

from __future__ import annotations

import logging
import os
import time

logger = logging.getLogger("alerting")

# Alert cooldowns — don't spam (minimum seconds between alerts of the same type)
_COOLDOWN = 900  # 15 minutes
_last_alert: dict[str, float] = {}

# Thresholds
ERROR_RATE_THRESHOLD = 0.05  # 5%
STUCK_JOB_THRESHOLD = 3
SPEND_RATE_THRESHOLD = 1.0  # $1/hour
FAILURE_SPIKE_THRESHOLD = 5  # failures in window

_ADMIN_EMAIL = os.environ.get("ALERT_EMAIL", "")


def _can_alert(alert_type: str) -> bool:
    """Check if enough time has passed since last alert of this type."""
    last = _last_alert.get(alert_type, 0)
    if time.time() - last < _COOLDOWN:
        return False
    _last_alert[alert_type] = time.time()
    return True


def _send_alert(subject: str, body: str) -> None:
    """Send an alert via email and log."""
    logger.warning("ALERT: %s — %s", subject, body[:200])

    if not _ADMIN_EMAIL:
        return

    try:
        from notifications import _send_email

        _send_email(
            to=_ADMIN_EMAIL,
            subject=f"[VM Alert] {subject}",
            html=f"""
            <div style="font-family: monospace; background: #1a1a2e; color: #ff2d95; padding: 20px; border-radius: 8px;">
                <h2 style="color: #ff2d95; margin: 0 0 12px;">⚠️ {subject}</h2>
                <p style="color: #e0e0e0;">{body}</p>
                <p style="color: #666; font-size: 11px; margin-top: 16px;">
                    Vending Machine Ops Alert — {time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())}
                </p>
            </div>
            """,
        )
    except Exception as e:
        logger.debug("Alert email failed: %s", e)


def check_alerts() -> list[str]:
    """Run all alert checks. Returns list of triggered alert descriptions.

    Call this periodically (e.g., every 60 seconds from the reaper loop).
    """
    triggered = []

    # Check error rate
    try:
        from middleware import get_metrics

        m = get_metrics()
        error_rate = m.get("error_rate", 0)
        if error_rate > ERROR_RATE_THRESHOLD and _can_alert("error_rate"):
            msg = f"Error rate is {error_rate:.1%} (threshold: {ERROR_RATE_THRESHOLD:.0%})"
            _send_alert("High Error Rate", msg)
            triggered.append(msg)
    except Exception as e:
        logger.debug("Alert check failed: %s", e)

    # Check stuck jobs
    try:
        from jobs import JOB_STORE, TERMINAL_STATES

        now = time.time()
        stuck = sum(
            1
            for j in JOB_STORE.values()
            if j["status"] not in TERMINAL_STATES and j.get("timeout_at", 0) and now > j["timeout_at"]
        )
        if stuck > STUCK_JOB_THRESHOLD and _can_alert("stuck_jobs"):
            msg = f"{stuck} jobs are stuck past their timeout (threshold: {STUCK_JOB_THRESHOLD})"
            _send_alert("Stuck Jobs", msg)
            triggered.append(msg)
    except Exception as e:
        logger.debug("Alert check failed: %s", e)

    # Check spend rate
    try:
        from jobs import JOB_STORE

        now = time.time()
        hour_ago = now - 3600
        hour_spend = sum(
            j.get("metadata", {}).get("cost", 0)
            for j in JOB_STORE.values()
            if (j.get("completed_at") or 0) > hour_ago and j.get("metadata")
        )
        if hour_spend > SPEND_RATE_THRESHOLD and _can_alert("spend_rate"):
            msg = f"Spend rate: ${hour_spend:.4f}/hour (threshold: ${SPEND_RATE_THRESHOLD}/hour)"
            _send_alert("Spend Anomaly", msg)
            triggered.append(msg)
    except Exception as e:
        logger.debug("Alert check failed: %s", e)

    # Check failure spike
    try:
        from jobs import JOB_STORE

        now = time.time()
        window = now - 900  # 15 min
        recent_failures = sum(
            1
            for j in JOB_STORE.values()
            if j["status"] in ("error", "expired") and (j.get("completed_at") or 0) > window
        )
        if recent_failures > FAILURE_SPIKE_THRESHOLD and _can_alert("failure_spike"):
            msg = f"{recent_failures} job failures in last 15 minutes (threshold: {FAILURE_SPIKE_THRESHOLD})"
            _send_alert("Job Failure Spike", msg)
            triggered.append(msg)
    except Exception as e:
        logger.debug("Alert check failed: %s", e)

    return triggered
