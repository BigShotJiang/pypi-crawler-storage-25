"""
Background job runner — executes agent graphs asynchronously.

Called via asyncio.create_task() from REST endpoints.
Mirrors the WebSocket streaming logic but accumulates output into the job store.
"""

import asyncio
import logging
import time

from agents.llm import MODELS, get_upload_routing_info, route_model_for_upload
from agents.registry import AGENT_GRAPHS, AGENT_NAMES, build_initial_state, estimate_tokens, format_step_output
from guards.gate_keeper import screen_input
from guards.qa_auditor import audit_output
from jobs import JobStatus, get_job, update_job
from pricing import calculate_cost

logger = logging.getLogger("job_runner")

# Background tasks set — prevents GC of fire-and-forget webhook tasks
_bg_tasks: set[asyncio.Task] = set()  # type: ignore[type-arg]


def _fire_webhook_safe(event_name: str, data: dict) -> None:
    """Best-effort webhook delivery — never blocks or raises."""
    try:
        from webhook_service import EventType, fire_event

        event_map = {
            "job.complete": EventType.JOB_COMPLETE,
            "job.failed": EventType.JOB_FAILED,
            "script.run": EventType.SCRIPT_RUN,
        }
        event = event_map.get(event_name)
        if event:
            task = asyncio.create_task(fire_event(event, data))
            _bg_tasks.add(task)
            task.add_done_callback(_bg_tasks.discard)
    except Exception:
        logger.debug("Webhook fire failed for %s", event_name)


async def run_job(job_id: str, **extra_state) -> None:
    """Run an agent graph in the background, updating the job store as it progresses."""
    job = get_job(job_id)
    if not job:
        return

    agent_id = job["agent_id"]
    graph = AGENT_GRAPHS.get(agent_id)
    if not graph:
        update_job(job_id, status=JobStatus.error, error=f"Unknown agent: {agent_id}")
        return

    agent_name = AGENT_NAMES.get(agent_id, agent_id)

    # ── Gate Keeper: screen input before running agent ──
    screen = await screen_input(job["task"], agent_id)
    if screen.blocked:
        update_job(
            job_id,
            status=JobStatus.error,
            completed_at=time.time(),
            error=f"Transaction Declined: {screen.reason}",
            metadata={
                "agentId": agent_id,
                "agentName": agent_name,
                "blocked": True,
                "riskScore": screen.risk_score,
                "flags": screen.flags,
                "timestamp": int(time.time() * 1000),
            },
        )
        return

    # ── Upload routing: upgrade model if file is too large for default ──
    file_content = extra_state.get("file_content", "")
    model_override = None
    routing_info = None

    if file_content:
        routing_info = get_upload_routing_info(agent_id, file_content, job["task"])
        routed = route_model_for_upload(agent_id, file_content, job["task"])
        if routed:
            model_override = routed  # (model_id, provider)
            extra_state["model_override"] = model_override
            logger.info(
                f"Job {job_id}: Model upgraded from {routing_info['default_model']} "
                f"to {routing_info['routed_model']} for {routing_info['file_tokens']:,} file tokens"
            )

    update_job(job_id, status=JobStatus.running, started_at=time.time())

    start_time = time.time()
    all_outputs: list[str] = []
    final_token_usage = {"input_tokens": 0, "output_tokens": 0}

    try:
        initial_state = build_initial_state(job["task"], **extra_state)

        async for event in graph.astream(initial_state, stream_mode="updates"):
            for node_name, state_update in event.items():
                step = state_update.get("current_step", node_name)
                output = format_step_output(step, state_update)
                all_outputs.append(output)

                # Capture accumulated token usage from state
                if "token_usage" in state_update:
                    final_token_usage = state_update["token_usage"]

                # Update job with latest step
                job_steps = get_job(job_id)
                if job_steps:
                    steps = job_steps["steps"]
                    steps.append({"step": step, "output": output})
                    update_job(job_id, steps=steps, output="\n".join(all_outputs))

        full_output = "\n".join(all_outputs)

        # ── QA Auditor: verify output before marking complete ──
        qa_result = await audit_output(
            output=full_output,
            agent_id=agent_id,
            task=job["task"],
            skip_llm=False,
        )

        elapsed_ms = int((time.time() - start_time) * 1000)

        # Use real token counts if available, fall back to estimates
        input_tokens = final_token_usage.get("input_tokens", 0) or estimate_tokens(job["task"])
        output_tokens = final_token_usage.get("output_tokens", 0) or estimate_tokens(full_output)

        # Get model ID for cost calculation — use routed model if upgraded
        if model_override:
            model_id = model_override[0]
        else:
            model_info = MODELS.get(agent_id)
            model_id = model_info[0] if model_info else "unknown"
        cost = calculate_cost(model_id, input_tokens, output_tokens)

        # Build QA metadata
        qa_meta = {
            "verdict": qa_result.verdict,
            "toolChecks": len(qa_result.tool_checks),
            "toolFailures": len([c for c in qa_result.tool_checks if not c.passed]),
            "secretFindings": qa_result.secret_findings,
            "llmSummary": qa_result.llm_summary[:200] if qa_result.llm_summary else "",
            "latencyMs": round(qa_result.latency_ms, 1),
        }

        # Build routing metadata
        routing_meta = None
        if routing_info:
            routing_meta = {
                "fileTokens": routing_info["file_tokens"],
                "defaultModel": routing_info["default_model"],
                "routedModel": routing_info["routed_model"],
                "wasUpgraded": routing_info["was_upgraded"],
            }

        # Add QA badge to output
        if qa_result.verdict == "WARN":
            full_output += f"\n\n---\n⚠️ QA Auditor: {qa_result.llm_summary[:300]}"
        elif qa_result.verdict == "FAIL":
            full_output += f"\n\n---\n❌ QA Auditor: {qa_result.llm_summary[:300]}"

        meta = {
            "agentId": agent_id,
            "agentName": agent_name,
            "model": model_id,
            "runtimeMs": elapsed_ms,
            "inputTokens": input_tokens,
            "outputTokens": output_tokens,
            "cost": round(cost, 6),
            "timestamp": int(time.time() * 1000),
            "qa": qa_meta,
        }
        if routing_meta:
            meta["routing"] = routing_meta

        update_job(
            job_id,
            status=JobStatus.complete,
            completed_at=time.time(),
            output=full_output,
            metadata=meta,
        )

        # Deduct credits from user's account (BILL-001)
        try:
            from credits import deduct, get_agent_cost

            credit_cost = get_agent_cost(agent_id)
            user_id = job.get("metadata", {}).get("user_id") if job.get("metadata") else None
            if user_id:
                deduct(user_id, credit_cost, f"Agent: {agent_name} (job {job_id})")
        except Exception as e:
            logger.debug("Credit deduction skipped: %s", e)

        # Track token metrics
        try:
            from middleware import inc_metric

            inc_metric("jobs_completed")
            inc_metric("tokens_used", input_tokens + output_tokens)
        except Exception as e:
            logger.debug("Metric tracking failed: %s", e)

        # Fire webhook: job.complete (best-effort)
        _fire_webhook_safe(
            "job.complete",
            {
                "job_id": job_id,
                "agent_id": agent_id,
                "agent_name": agent_name,
                "cost": round(cost, 6),
                "runtime_ms": elapsed_ms,
            },
        )

    except Exception as e:
        elapsed_ms = int((time.time() - start_time) * 1000)
        update_job(
            job_id,
            status=JobStatus.error,
            completed_at=time.time(),
            error=str(e),
            metadata={
                "agentId": agent_id,
                "agentName": agent_name,
                "runtimeMs": elapsed_ms,
                "inputTokens": estimate_tokens(job["task"]),
                "outputTokens": 0,
                "cost": 0,
                "timestamp": int(time.time() * 1000),
            },
        )

        # Fire webhook: job.failed (best-effort)
        _fire_webhook_safe(
            "job.failed",
            {"job_id": job_id, "agent_id": agent_id, "error_code": type(e).__name__, "error_message": str(e)[:500]},
        )


async def run_job_with_extra(job_id: str, **extra_state) -> None:
    """Convenience wrapper — runs a job with extra initial state fields (e.g., file_content)."""
    await run_job(job_id, **extra_state)
