"""
Standard error handling — consistent error responses across all endpoints.

Every error response follows the schema:
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable description",
    "request_id": "uuid",
    "details": {}
  }
}
"""

from __future__ import annotations

import logging

from fastapi import FastAPI, Request  # noqa: TC002
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

logger = logging.getLogger("errors")

# ─── Error Codes ──────────────────────────────────────────────────────────

# Map HTTP status codes to default error codes
STATUS_CODES = {
    400: "BAD_REQUEST",
    401: "UNAUTHORIZED",
    402: "PAYMENT_REQUIRED",
    403: "FORBIDDEN",
    404: "NOT_FOUND",
    405: "METHOD_NOT_ALLOWED",
    409: "CONFLICT",
    422: "VALIDATION_ERROR",
    429: "RATE_LIMIT_EXCEEDED",
    500: "INTERNAL_ERROR",
    502: "BAD_GATEWAY",
    503: "SERVICE_UNAVAILABLE",
    504: "GATEWAY_TIMEOUT",
}


def _build_error(
    code: str,
    message: str,
    request_id: str = "",
    details: dict | None = None,
    status_code: int = 500,
) -> JSONResponse:
    """Build a standardized error response."""
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "code": code,
                "message": message,
                "request_id": request_id,
                "details": details or {},
            }
        },
    )


def register_error_handlers(app: FastAPI) -> None:
    """Register global exception handlers on the FastAPI app."""

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        request_id = getattr(request.state, "request_id", "")
        code = STATUS_CODES.get(exc.status_code, "ERROR")
        message = str(exc.detail) if exc.detail else code

        if exc.status_code >= 500:
            logger.error("HTTP %s: %s [%s]", exc.status_code, message, request_id)

        return _build_error(
            code=code,
            message=message,
            request_id=request_id,
            status_code=exc.status_code,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        request_id = getattr(request.state, "request_id", "")
        errors = exc.errors()

        # Simplify validation error details
        details = [
            {
                "field": ".".join(str(loc) for loc in e.get("loc", [])),
                "message": e.get("msg", ""),
                "type": e.get("type", ""),
            }
            for e in errors
        ]

        return _build_error(
            code="VALIDATION_ERROR",
            message=f"Request validation failed: {len(errors)} error(s)",
            request_id=request_id,
            details={"errors": details},
            status_code=422,
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        request_id = getattr(request.state, "request_id", "")
        logger.exception("Unhandled exception [%s]: %s", request_id, exc)

        # Never expose stack traces in production
        return _build_error(
            code="INTERNAL_ERROR",
            message="An internal error occurred. Please try again later.",
            request_id=request_id,
            status_code=500,
        )
