"""
Script marketplace runner — executes creator scripts in E2B sandbox.

Takes a script from the store, prepends user input as a variable,
and runs it in a sandboxed environment. Updates the job store with results.
"""

import logging
import time

from jobs import JobStatus, get_job, update_job
from sandbox import run_code
from scripts import get_script, record_run

logger = logging.getLogger("script_runner")


async def run_script_job(
    job_id: str,
    script_id: str,
    user_input: str = "",
) -> None:
    """Execute a marketplace script in the sandbox, updating the job store."""
    job = get_job(job_id)
    if not job:
        return

    script = get_script(script_id)
    if not script:
        update_job(job_id, status=JobStatus.error, error=f"Script not found: {script_id}")
        return

    update_job(job_id, status=JobStatus.running, started_at=time.time())
    start_time = time.time()

    try:
        # Build the execution code:
        # 1. Define USER_INPUT variable with the user's input
        # 2. Append the creator's script
        escaped_input = user_input.replace("\\", "\\\\").replace('"""', '\\"\\"\\"')
        execution_code = f'USER_INPUT = """{escaped_input}"""\n\n{script["code"]}'

        # Run in sandbox
        result = run_code(
            code=execution_code,
            language="python",
            timeout=30,
            packages=script["packages"] if script["packages"] else None,
        )

        elapsed_ms = int((time.time() - start_time) * 1000)
        cost = script["price"]

        # Record the run on the script
        record_run(script_id, cost)

        # Fire webhook: script.run (best-effort)
        from job_runner import _fire_webhook_safe

        _fire_webhook_safe(
            "script.run",
            {
                "script_name": script["name"],
                "vending_code": script.get("vending_code", script_id),
                "cost": cost,
                "runtime_ms": elapsed_ms,
            },
        )

        # Build output
        output_parts = []
        if result["stdout"]:
            output_parts.append(result["stdout"])
        if result["stderr"]:
            output_parts.append(f"\n[stderr]\n{result['stderr']}")
        if result["error"]:
            output_parts.append(f"\n[error]\n{result['error']}")
        if result["results"]:
            for r in result["results"]:
                if r["type"] == "text":
                    output_parts.append(r["value"])

        full_output = "\n".join(output_parts) if output_parts else "(no output)"

        status = JobStatus.complete if result["exit_code"] == 0 else JobStatus.error

        update_job(
            job_id,
            status=status,
            completed_at=time.time(),
            output=full_output,
            error=result["error"] if result["exit_code"] != 0 else None,
            metadata={
                "scriptId": script_id,
                "scriptName": script["name"],
                "creator": script["creator"],
                "runtimeMs": elapsed_ms,
                "cost": cost,
                "exitCode": result["exit_code"],
                "timestamp": int(time.time() * 1000),
            },
        )

    except Exception as e:
        elapsed_ms = int((time.time() - start_time) * 1000)
        logger.error(f"Script execution failed: {e}")
        update_job(
            job_id,
            status=JobStatus.error,
            completed_at=time.time(),
            error=str(e),
            metadata={
                "scriptId": script_id,
                "scriptName": script["name"],
                "runtimeMs": elapsed_ms,
                "cost": 0,
                "timestamp": int(time.time() * 1000),
            },
        )
