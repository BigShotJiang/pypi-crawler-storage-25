"""
Credit-based economy for the Vending Machine marketplace.

Free tier: 500 credits/month (refills on 1st of each month).
Pro tier: unlimited (placeholder for MCPize/Stripe activation).

Persists to Supabase PostgreSQL when configured, falls back to in-memory dict.
"""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from typing import Any, TypedDict

logger = logging.getLogger("credits")

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


class CreditTransaction(TypedDict):
    timestamp: float
    action: str  # "deposit" | "withdrawal"
    amount: int
    reason: str
    balance: int


class CreditAccount(TypedDict):
    key: str  # user_id (Supabase) or vm-xxx (legacy)
    tier: str  # "free" | "pro"
    balance: int
    monthly_allowance: int
    last_refill: str  # "YYYY-MM"
    created_at: float
    ledger: list[CreditTransaction]


# ---------------------------------------------------------------------------
# Credit costs per action
# ---------------------------------------------------------------------------

SCRIPT_CREDIT_COST = {"cheap": 1, "mid": 3, "premium": 5}

AGENT_CREDIT_COST = {
    "minimax": 5,
    "gemini": 5,
    "codex": 15,
    "sonnet": 20,
    "mimo": 10,
}

WORKFLOW_CREDIT_COST = {
    "audit_code": 75,
    "ship_feature": 100,
    "analyze_data": 30,
    # Engagement packages (white-glove delivery)
    "shield": 150,
    "blueprint": 200,
    "launchpad": 400,
}

CODE_EXEC_CREDIT_COST = 5
FREE_MONTHLY_CREDITS = 500

_AGENT_MODEL_TIER: dict[str, str] = {
    "code-gremlin": "codex",
    "research-owl": "sonnet",
    "info-scout": "minimax",
    "inbox-zero": "minimax",
    "vibe-writer": "minimax",
    "number-crunch": "minimax",
    "fridge-chef": "gemini",
    "mcp-maker": "codex",
    "embeddings-agent": "minimax",
    "bug-hunter": "minimax",
    "devops-dwarf": "codex",
    "test-goblin": "codex",
    "data-sprite": "minimax",
    "spreadsheet-sage": "minimax",
    "pdf-forge": "sonnet",
    "web-weaver": "codex",
    "cloud-sensei": "mimo",
    "desk-pilot": "gemini",
}


# ---------------------------------------------------------------------------
# In-memory fallback (when Supabase is not configured)
# ---------------------------------------------------------------------------

_accounts: dict[str, CreditAccount] = {}


def _get_sb():
    """Lazy import Supabase client."""
    try:
        from supabase_client import get_supabase

        return get_supabase()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Account management
# ---------------------------------------------------------------------------


def create_account(user_id: str) -> dict[str, Any]:
    """Create a credit account for a user. Returns account info."""
    sb = _get_sb()
    now_month = datetime.now(tz=UTC).strftime("%Y-%m")

    if sb:
        try:
            result = (
                sb.table("credit_accounts")
                .insert(
                    {
                        "user_id": user_id,
                        "tier": "free",
                        "balance": FREE_MONTHLY_CREDITS,
                        "monthly_allowance": FREE_MONTHLY_CREDITS,
                        "last_refill": now_month,
                    }
                )
                .execute()
            )

            account = result.data[0]

            # Log the initial deposit
            sb.table("credit_transactions").insert(
                {
                    "account_id": account["id"],
                    "action": "deposit",
                    "amount": FREE_MONTHLY_CREDITS,
                    "reason": "Free tier signup",
                    "balance_after": FREE_MONTHLY_CREDITS,
                }
            ).execute()

            return {
                "account_id": account["id"],
                "user_id": user_id,
                "tier": account["tier"],
                "balance": account["balance"],
                "monthly_allowance": account["monthly_allowance"],
            }
        except Exception as e:
            logger.error("Failed to create Supabase account: %s", e)

    # Fallback: in-memory
    key = user_id
    account: CreditAccount = {
        "key": key,
        "tier": "free",
        "balance": FREE_MONTHLY_CREDITS,
        "monthly_allowance": FREE_MONTHLY_CREDITS,
        "last_refill": now_month,
        "created_at": time.time(),
        "ledger": [
            {
                "timestamp": time.time(),
                "action": "deposit",
                "amount": FREE_MONTHLY_CREDITS,
                "reason": "Free tier signup",
                "balance": FREE_MONTHLY_CREDITS,
            }
        ],
    }
    _accounts[key] = account
    return {
        "account_id": key,
        "user_id": user_id,
        "tier": "free",
        "balance": FREE_MONTHLY_CREDITS,
        "monthly_allowance": FREE_MONTHLY_CREDITS,
    }


def get_account_by_user(user_id: str) -> dict[str, Any] | None:
    """Get credit account for a user. Auto-refills monthly credits."""
    sb = _get_sb()

    if sb:
        try:
            result = sb.table("credit_accounts").select("*").eq("user_id", user_id).limit(1).execute()
            if not result.data or len(result.data) == 0:
                return None

            account = result.data[0]

            # Monthly refill check
            now_month = datetime.now(tz=UTC).strftime("%Y-%m")
            if account["tier"] == "free" and account["last_refill"] != now_month:
                sb.table("credit_accounts").update(
                    {
                        "balance": FREE_MONTHLY_CREDITS,
                        "last_refill": now_month,
                    }
                ).eq("id", account["id"]).execute()

                sb.table("credit_transactions").insert(
                    {
                        "account_id": account["id"],
                        "action": "deposit",
                        "amount": FREE_MONTHLY_CREDITS,
                        "reason": f"Monthly refill ({now_month})",
                        "balance_after": FREE_MONTHLY_CREDITS,
                    }
                ).execute()

                account["balance"] = FREE_MONTHLY_CREDITS
                account["last_refill"] = now_month

            return account
        except Exception as e:
            logger.error("Failed to get Supabase account: %s", e)

    # Fallback: in-memory
    account_mem = _accounts.get(user_id)
    if not account_mem:
        return None

    now_month = datetime.now(tz=UTC).strftime("%Y-%m")
    if account_mem["tier"] == "free" and account_mem["last_refill"] != now_month:
        account_mem["balance"] = FREE_MONTHLY_CREDITS
        account_mem["last_refill"] = now_month

    return {
        "id": user_id,
        "user_id": user_id,
        "tier": account_mem["tier"],
        "balance": account_mem["balance"],
        "monthly_allowance": account_mem["monthly_allowance"],
        "last_refill": account_mem["last_refill"],
    }


# ---------------------------------------------------------------------------
# Credit operations
# ---------------------------------------------------------------------------


def get_script_cost(price: float) -> int:
    """Determine credit cost for a script based on its price."""
    if price <= 0.01:
        return SCRIPT_CREDIT_COST["cheap"]
    if price <= 0.03:
        return SCRIPT_CREDIT_COST["mid"]
    return SCRIPT_CREDIT_COST["premium"]


def get_agent_cost(agent_id: str) -> int:
    """Determine credit cost for hiring an agent."""
    tier = _AGENT_MODEL_TIER.get(agent_id, "minimax")
    return AGENT_CREDIT_COST.get(tier, 5)


def get_workflow_cost(workflow_key: str) -> int:
    """Determine credit cost for a workflow pipeline."""
    return WORKFLOW_CREDIT_COST.get(workflow_key, 50)


def check_balance(user_id: str, required: int) -> tuple[bool, int, int]:
    """Check if user has enough credits. Returns (allowed, balance, required)."""
    account = get_account_by_user(user_id)
    if not account:
        # Auto-create account for new users
        create_account(user_id)
        account = get_account_by_user(user_id)

    if not account:
        return False, 0, required

    if account["tier"] == "pro":
        return True, account["balance"], required

    return account["balance"] >= required, account["balance"], required


def deduct(user_id: str, amount: int, reason: str) -> tuple[bool, int]:
    """Deduct credits. Returns (success, remaining_balance)."""
    account = get_account_by_user(user_id)
    if not account:
        create_account(user_id)
        account = get_account_by_user(user_id)

    if not account:
        return False, 0

    if account["tier"] == "pro":
        return True, account["balance"]

    if account["balance"] < amount:
        return False, account["balance"]

    new_balance = account["balance"] - amount
    sb = _get_sb()

    if sb:
        try:
            sb.table("credit_accounts").update(
                {
                    "balance": new_balance,
                }
            ).eq("id", account["id"]).execute()

            sb.table("credit_transactions").insert(
                {
                    "account_id": account["id"],
                    "action": "withdrawal",
                    "amount": amount,
                    "reason": reason,
                    "balance_after": new_balance,
                }
            ).execute()

            return True, new_balance
        except Exception as e:
            logger.error("Failed to deduct credits in Supabase: %s", e)

    # Fallback: in-memory
    mem = _accounts.get(user_id)
    if mem:
        mem["balance"] = new_balance
        mem["ledger"].append(
            {
                "timestamp": time.time(),
                "action": "withdrawal",
                "amount": amount,
                "reason": reason,
                "balance": new_balance,
            }
        )
        if len(mem["ledger"]) > 200:
            mem["ledger"] = mem["ledger"][-200:]

    return True, new_balance


def get_balance(user_id: str) -> dict[str, Any]:
    """Get account balance and tier info."""
    account = get_account_by_user(user_id)
    if not account:
        return {"error": "Account not found", "user_id": user_id}

    return {
        "user_id": user_id,
        "tier": account["tier"],
        "balance": account["balance"],
        "monthly_allowance": account.get("monthly_allowance", FREE_MONTHLY_CREDITS),
        "last_refill": account.get("last_refill", ""),
    }


def get_ledger(user_id: str, limit: int = 20) -> list[dict[str, Any]]:
    """Get recent transaction history."""
    sb = _get_sb()

    if sb:
        try:
            account = get_account_by_user(user_id)
            if not account:
                return []

            result = (
                sb.table("credit_transactions")
                .select("*")
                .eq("account_id", account["id"])
                .order("created_at", desc=True)
                .limit(limit)
                .execute()
            )
            return result.data or []
        except Exception as e:
            logger.error("Failed to get ledger from Supabase: %s", e)

    # Fallback: in-memory
    mem = _accounts.get(user_id)
    if not mem:
        return []
    return mem["ledger"][-limit:]
