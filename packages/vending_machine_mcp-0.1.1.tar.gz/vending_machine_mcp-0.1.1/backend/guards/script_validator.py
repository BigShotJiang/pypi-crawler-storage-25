"""
Script Security Compliance Engine — 4-layer validation pipeline.

Validates creator-uploaded scripts against three industry frameworks:
  - MITRE ATT&CK (adversary techniques)
  - Cyber Kill Chain (attack stages)
  - NIST CSF 2.0 (organizational response)

Layers:
  1. Static Analysis — AST parsing + pattern matching
  2. Dependency Audit — NVD/CVE lookup + typosquatting detection
  3. Sandbox Probe — Runtime behavior monitoring in E2B
  4. LLM Review — Context-aware review for ambiguous cases

Usage:
    from guards.script_validator import validate_script
    report = await validate_script(code, packages, description)
    if report.verdict == "REJECTED":
        return error(report.summary)
"""

import ast
import json
import logging
import re
import time

import httpx

from guards.security_types import (
    ATTACK_TECHNIQUES,
    ComplianceReport,
    Finding,
    make_finding_from_technique,
)

logger = logging.getLogger("script_validator")

# Security layers — only these affect the security verdict (quality/reliability excluded)
SECURITY_LAYERS = {"static", "deps", "sandbox", "llm"}

# Severity weights for risk score calculation
SEVERITY_WEIGHTS = {"critical": 1.0, "high": 0.7, "medium": 0.3, "low": 0.1}


# ---------------------------------------------------------------------------
# Layer 1: Static Analysis + ATT&CK Mapping
# ---------------------------------------------------------------------------

# AST patterns: (node_test_fn, attack_id, message_template)
# Each entry detects a specific pattern in the AST and maps it to ATT&CK


def _get_attr_chain(node: ast.Attribute) -> str:
    """Resolve a dotted attribute chain like urllib.request into a string."""
    parts = []
    current = node.value
    while isinstance(current, ast.Attribute):
        parts.append(current.attr)
        current = current.value
    if isinstance(current, ast.Name):
        parts.append(current.id)
    return ".".join(reversed(parts))


# CLI tools that are safe to invoke via subprocess (no shell=True needed)
_SAFE_CLI_TOOLS = frozenset(
    {
        "npx",
        "node",
        "npm",
        "tsc",
        "biome",
        "eslint",
        "prettier",
        "ruff",
        "black",
        "mypy",
        "pyright",
        "pytest",
        "python",
        "python3",
        "pip",
        "pip3",
        "uv",
        "cargo",
        "go",
        "rustc",
        "gcc",
        "make",
        "git",
        "ls",
        "cat",
        "head",
        "tail",
        "wc",
        "sort",
        "uniq",
        "grep",
        "find",
        "echo",
        "date",
        "pwd",
        "whoami",
        "which",
    }
)

# Commands that are destructive regardless of context
_DANGEROUS_COMMANDS = frozenset(
    {
        "rm",
        "rmdir",
        "del",
        "format",
        "mkfs",
        "dd",
        "shred",
        "curl",
        "wget",
        "nc",
        "ncat",
        "bash",
        "sh",
        "zsh",
        "cmd",
        "powershell",
        "chmod",
        "chown",
        "sudo",
        "su",
        "kill",
        "pkill",
    }
)


def _classify_subprocess_call(node: ast.Call) -> str:
    """Classify a subprocess call by danger level.

    Returns an ATT&CK technique ID:
    - "T1059.006" for dangerous calls (shell=True, destructive commands, dynamic args)
    - "T1059.006.safe" for safe CLI tool invocations (shell=False, hardcoded safe tools)
    """
    # Check if shell=True is used
    for kw in node.keywords:
        if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
            return "T1059.006"  # shell=True is always dangerous

    # Check the command argument (first positional arg)
    if not node.args:
        return "T1059.006"  # No command specified — suspicious

    cmd_arg = node.args[0]

    # subprocess.run(["tool", "arg1", ...]) — list literal
    if isinstance(cmd_arg, ast.List) and cmd_arg.elts:
        first_elem = cmd_arg.elts[0]

        # First element is a string constant — check it directly
        if isinstance(first_elem, ast.Constant) and isinstance(first_elem.value, str):
            tool_name = first_elem.value.rsplit("/", 1)[-1]
            if tool_name in _DANGEROUS_COMMANDS:
                return "T1059.006"  # Destructive command
            if tool_name in _SAFE_CLI_TOOLS:
                return "T1059.006.safe"  # Safe CLI wrapper
            return "T1059.006"  # Unknown command

        # First element is a variable — check if any string constants in the list
        # are known safe tools (e.g. [npx, "tsc", "--noEmit"])
        string_elts = [e.value for e in cmd_arg.elts if isinstance(e, ast.Constant) and isinstance(e.value, str)]
        if any(s.rsplit("/", 1)[-1] in _SAFE_CLI_TOOLS for s in string_elts):
            return "T1059.006.safe"  # List contains known safe tool names
        if any(s.rsplit("/", 1)[-1] in _DANGEROUS_COMMANDS for s in string_elts):
            return "T1059.006"  # List contains dangerous commands

        # Check if capture_output=True or check=False — typical safe patterns
        has_capture = any(
            kw.arg == "capture_output" and isinstance(kw.value, ast.Constant) and kw.value.value is True
            for kw in node.keywords
        )
        has_timeout = any(kw.arg == "timeout" for kw in node.keywords)
        if has_capture and has_timeout:
            return "T1059.006.safe"  # Defensive subprocess usage pattern

        return "T1059.006"  # Dynamic command — unknown risk

    # subprocess.run(string_var) or subprocess.run(f"...") — dynamic, dangerous
    return "T1059.006"


def _is_dangerous_call(node: ast.Call) -> list[tuple[str, str, str]]:
    """Check if an ast.Call node matches a dangerous pattern.
    Returns list of (attack_id, message, code_repr).
    """
    findings = []
    func = node.func

    # os.system(), os.popen(), os.exec*()
    if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
        if func.value.id == "os" and func.attr in (
            "system",
            "popen",
            "execl",
            "execle",
            "execlp",
            "execv",
            "execve",
            "execvp",
        ):
            findings.append(("T1059.006", f"Shell execution via os.{func.attr}()", ast.dump(node)))

        # subprocess.* — context-aware: shell=True or destructive commands are critical,
        # hardcoded safe CLI tools with shell=False (default) are low severity
        if func.value.id == "subprocess" and func.attr in (
            "run",
            "call",
            "Popen",
            "check_output",
            "check_call",
            "getoutput",
            "getstatusoutput",
        ):
            severity = _classify_subprocess_call(node)
            findings.append((severity, f"Shell execution via subprocess.{func.attr}()", ast.dump(node)))

        # shutil.rmtree, os.remove, os.unlink
        if (func.value.id == "shutil" and func.attr == "rmtree") or (
            func.value.id == "os" and func.attr in ("remove", "unlink", "rmdir")
        ):
            findings.append(("T1070.004", f"File deletion via {func.value.id}.{func.attr}()", ast.dump(node)))

        # socket.bind, socket.listen, socket.connect
        if func.value.id == "socket" and func.attr in ("bind", "listen", "connect"):
            findings.append(("T1571", f"Network socket via socket.{func.attr}()", ast.dump(node)))

        # os.getenv / os.environ (non-whitelisted)
        if func.value.id == "os" and func.attr in ("getenv", "environ"):
            if node.args and isinstance(node.args[0], ast.Constant):
                env_name = str(node.args[0].value)
                safe_vars = {"USER_INPUT", "PATH", "HOME", "LANG", "LC_ALL", "TZ", "PYTHONPATH"}
                if env_name not in safe_vars:
                    cred_patterns = ("TOKEN", "KEY", "SECRET", "PASSWORD", "CREDENTIAL", "API_KEY", "ACCESS")
                    is_cred = any(p in env_name.upper() for p in cred_patterns)
                    tid = "T1552.001"
                    msg = f"{'Credential' if is_cred else 'Environment'} variable access: os.getenv('{env_name}')"
                    findings.append((tid, msg, ast.dump(node)))
            elif node.args and not isinstance(node.args[0], ast.Constant):
                # Dynamic env var access (variable as argument) — suspicious
                findings.append(
                    ("T1552.001", "Dynamic environment variable access: os.getenv(<variable>)", ast.dump(node))
                )

        # urllib.request.urlretrieve / urlopen (handles nested attribute chains)
        if func.attr in ("urlretrieve", "urlopen"):
            # Check if it's urllib.request.urlopen or similar
            attr_chain = _get_attr_chain(func)
            if any(part in attr_chain for part in ("urllib", "request", "http")):
                findings.append(
                    (
                        "T1105" if func.attr == "urlretrieve" else "T1041",
                        f"Network access via {attr_chain}.{func.attr}()",
                        ast.dump(node),
                    )
                )

        # requests.post / requests.get (popular HTTP library)
        if (
            func.attr in ("post", "get", "put", "delete", "patch")
            and isinstance(func.value, ast.Name)
            and func.value.id == "requests"
        ):
            findings.append(("T1041", f"Network access via requests.{func.attr}()", ast.dump(node)))

        # httpx.post / httpx.get
        if (
            func.attr in ("post", "get", "put", "delete")
            and isinstance(func.value, ast.Name)
            and func.value.id == "httpx"
        ):
            findings.append(("T1041", f"Network access via httpx.{func.attr}()", ast.dump(node)))

        # platform.*, sys.version, os.uname
        if func.value.id == "platform" and func.attr in (
            "system",
            "node",
            "release",
            "version",
            "machine",
            "processor",
            "uname",
        ):
            findings.append(("T1082", f"System discovery via platform.{func.attr}()", ast.dump(node)))

        if func.value.id == "os" and func.attr == "uname":
            findings.append(("T1082", "System discovery via os.uname()", ast.dump(node)))

    # Nested attribute chains (e.g., urllib.request.urlopen)
    if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Attribute):
        chain = _get_attr_chain(func)
        # urllib.request.urlopen / urlretrieve
        if func.attr in ("urlretrieve", "urlopen") and any(p in chain for p in ("urllib", "request", "http")):
            findings.append(
                (
                    "T1105" if func.attr == "urlretrieve" else "T1041",
                    f"Network access via {chain}.{func.attr}()",
                    ast.dump(node),
                )
            )

    # eval() and exec() — check if argument is dynamic (not a literal)
    if (
        isinstance(func, ast.Name)
        and func.id in ("eval", "exec")
        and node.args
        and not isinstance(node.args[0], ast.Constant)
    ):
        findings.append(("T1027", f"Dynamic code execution via {func.id}() with non-literal argument", ast.dump(node)))

    # compile() with exec/eval mode
    if isinstance(func, ast.Name) and func.id == "compile":
        findings.append(("T1027", "Dynamic code compilation via compile()", ast.dump(node)))

    # __import__()
    if isinstance(func, ast.Name) and func.id == "__import__":
        findings.append(("T1027", "Dynamic import via __import__()", ast.dump(node)))

    return findings


def _check_open_paths(node: ast.Call) -> list[tuple[str, str, str]]:
    """Check open() calls for path traversal outside /tmp."""
    findings = []
    func = node.func

    if (
        isinstance(func, ast.Name)
        and func.id == "open"
        and node.args
        and isinstance(node.args[0], ast.Constant)
        and isinstance(node.args[0].value, str)
    ):
        path = node.args[0].value
        # Allow /tmp, relative paths, and USER_INPUT-derived paths
        if path.startswith(("/etc", "/home", "/root", "/var", "/usr", "/proc", "/sys")):
            findings.append(("T1005", f"Suspicious file access: open('{path}')", ast.dump(node)))
        if ".env" in path or "credentials" in path.lower() or "passwd" in path:
            findings.append(("T1552.001", f"Credential file access: open('{path}')", ast.dump(node)))

    return findings


def _check_imports(tree: ast.Module) -> list[tuple[str, str, int]]:
    """Check imports for suspicious modules."""
    findings = []
    suspicious_modules = {
        "socket": ("T1571", "Network socket module imported"),
        "ctypes": ("T1059.006", "Low-level C interface module imported"),
        "crontab": ("T1053.005", "Cron scheduling module imported"),
    }
    crypto_modules = {"cryptography", "Crypto", "Cryptodome", "nacl"}

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.name.split(".")[0]
                if name in suspicious_modules:
                    tid, msg = suspicious_modules[name]
                    findings.append((tid, msg, node.lineno))
                if name in crypto_modules:
                    findings.append(("T1486", f"Encryption module imported: {alias.name}", node.lineno))

        elif isinstance(node, ast.ImportFrom) and node.module:
            root = node.module.split(".")[0]
            if root in suspicious_modules:
                tid, msg = suspicious_modules[root]
                findings.append((tid, msg, node.lineno))
            if root in crypto_modules:
                findings.append(("T1486", f"Encryption module imported: {node.module}", node.lineno))

    return findings


def _check_obfuscation(code: str) -> list[tuple[str, str]]:
    """Detect code obfuscation patterns."""
    findings = []

    # base64 decode → exec/eval chain
    if re.search(r"(?:eval|exec)\s*\(\s*(?:base64\.b64decode|codecs\.decode|bytes\.fromhex)", code):
        findings.append(("T1027", "Obfuscation: eval/exec on decoded data"))

    # Hex-encoded strings executed
    if re.search(r"exec\s*\(\s*bytes\.fromhex\s*\(", code):
        findings.append(("T1027", "Obfuscation: exec on hex-decoded bytes"))

    # Multiple layers of encoding
    if code.count("base64") >= 2 or code.count("decode") >= 3:
        findings.append(("T1027", "Obfuscation: multiple encoding/decoding layers"))

    # Reversed string execution
    if re.search(r"exec\s*\(\s*['\"].*['\"].*\[::-1\]", code):
        findings.append(("T1027", "Obfuscation: reversed string execution"))

    return findings


def _layer1_static(code: str) -> list[Finding]:
    """Layer 1: Static analysis via AST parsing + pattern matching."""
    findings: list[Finding] = []

    # Parse AST
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        findings.append(
            Finding(
                layer="static",
                severity="medium",
                message=f"Syntax error in script: {e}",
                line_number=e.lineno,
            )
        )
        return findings

    # Walk AST for dangerous calls
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for attack_id, message, snippet in _is_dangerous_call(node):
                findings.append(
                    make_finding_from_technique(
                        attack_id,
                        "static",
                        message,
                        line_number=getattr(node, "lineno", None),
                        code_snippet=snippet[:200],
                    )
                )
            for attack_id, message, snippet in _check_open_paths(node):
                findings.append(
                    make_finding_from_technique(
                        attack_id,
                        "static",
                        message,
                        line_number=getattr(node, "lineno", None),
                        code_snippet=snippet[:200],
                    )
                )

    # Check imports
    for attack_id, message, lineno in _check_imports(tree):
        findings.append(
            make_finding_from_technique(
                attack_id,
                "static",
                message,
                line_number=lineno,
            )
        )

    # Check obfuscation patterns (regex-based, not AST)
    for attack_id, message in _check_obfuscation(code):
        findings.append(
            make_finding_from_technique(
                attack_id,
                "static",
                message,
            )
        )

    return findings


# ---------------------------------------------------------------------------
# Layer 2: Dependency Audit + CVE/NVD
# ---------------------------------------------------------------------------

# Known-malicious PyPI packages (confirmed supply chain attacks)
MALICIOUS_PACKAGES = {
    "colourama",
    "python-dateutil2",
    "jeIlyfish",
    "python3-dateutil",
    "free-net-vpn",
    "free-net-vpn2",
    "libpeshnern",
    "libpeshka",
    "requesocks",
    "distaborutils",
    "setuptools-dev",
    "pipsqlite3",
    "baboricmm",
    "coloram",
    "opencv-python-headless-gpu",
}

# Popular packages (targets for typosquatting)
POPULAR_PACKAGES = {
    "requests",
    "numpy",
    "pandas",
    "flask",
    "django",
    "boto3",
    "scipy",
    "matplotlib",
    "pillow",
    "cryptography",
    "pyyaml",
    "beautifulsoup4",
    "selenium",
    "scrapy",
    "fastapi",
    "sqlalchemy",
    "celery",
    "redis",
    "psycopg2",
    "pymongo",
    "httpx",
    "colorama",
    "setuptools",
    "pip",
    "wheel",
    "twine",
    "tensorflow",
    "torch",
    "transformers",
    "openai",
    "langchain",
}

NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
_nvd_cache: dict[str, list[dict]] = {}


def _levenshtein(a: str, b: str) -> int:
    """Compute Levenshtein edit distance between two strings."""
    if len(a) < len(b):
        return _levenshtein(b, a)
    if len(b) == 0:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(prev[j + 1] + 1, curr[j] + 1, prev[j] + (ca != cb)))
        prev = curr
    return prev[len(b)]


def _extract_fix_versions(cve_data: dict) -> str:
    """Extract fix/patched versions from CVE configurations or references."""
    # Try to find version info from configurations
    configs = cve_data.get("configurations", [])
    fix_parts = []
    for config in configs:
        for node in config.get("nodes", []):
            for match in node.get("cpeMatch", []):
                if match.get("versionEndExcluding"):
                    fix_parts.append(f">={match['versionEndExcluding']}")
                elif match.get("versionEndIncluding"):
                    fix_parts.append(f">{match['versionEndIncluding']}")
    return ", ".join(fix_parts) if fix_parts else ""


def format_vulnerability_report(cves: list[dict], packages: list[str]) -> str:
    """Format CVE findings as a Security & Vulnerability Assessment Report.

    Generates a tabular report matching industry standard vulnerability
    disclosure format: package, version, CVE ID, fix versions, description.
    """
    if not cves:
        return ""

    lines = [
        "## Security & Vulnerability Assessment Report",
        "",
        f"Found **{len(cves)} known vulnerabilities** in declared dependencies.",
        "",
        "| Package | CVE ID | CVSS | Severity | Fix Versions | Description |",
        "|---------|--------|------|----------|--------------|-------------|",
    ]

    for cve in cves:
        pkg = cve.get("package", "unknown")
        cve_id = cve.get("id", "N/A")
        cvss = cve.get("cvss", 0.0)
        severity = cve.get("severity", "HIGH")
        fix = cve.get("fix_versions", "") or "None available"
        desc = cve.get("description", "")[:120].replace("|", "/").replace("\n", " ")
        lines.append(f"| {pkg} | {cve_id} | {cvss} | {severity} | {fix} | {desc} |")

    lines.extend(
        [
            "",
            "**Action required:** Resolve all HIGH and CRITICAL vulnerabilities before script approval.",
            "Update affected packages to their fix versions, or remove them if not needed.",
        ]
    )

    return "\n".join(lines)


async def _check_nvd(package: str) -> list[dict]:
    """Query NVD for known CVEs affecting a Python package."""
    if package in _nvd_cache:
        return _nvd_cache[package]

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                NVD_API,
                params={"keywordSearch": f"python {package}", "resultsPerPage": 5},
            )
            if resp.status_code != 200:
                return []

            data = resp.json()
            cves = []
            for vuln in data.get("vulnerabilities", []):
                cve = vuln.get("cve", {})
                # Extract CVSS score
                metrics = cve.get("metrics", {})
                cvss = 0.0
                for version_key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
                    metric_list = metrics.get(version_key, [])
                    if metric_list:
                        cvss = metric_list[0].get("cvssData", {}).get("baseScore", 0.0)
                        break

                if cvss >= 7.0:
                    desc = ""
                    for d in cve.get("descriptions", []):
                        if d.get("lang") == "en":
                            desc = d.get("value", "")
                            break

                    # Extract fix versions from references
                    fix_versions = _extract_fix_versions(cve)

                    cves.append(
                        {
                            "id": cve.get("id", ""),
                            "package": package,
                            "description": desc[:300],
                            "cvss": cvss,
                            "severity": "CRITICAL" if cvss >= 9.0 else "HIGH",
                            "fix_versions": fix_versions,
                        }
                    )

            _nvd_cache[package] = cves
            return cves

    except Exception as e:
        logger.warning(f"NVD lookup failed for {package}: {e}")
        return []


async def _layer2_deps(packages: list[str]) -> tuple[list[Finding], list[dict]]:
    """Layer 2: Dependency audit + CVE/NVD check."""
    findings: list[Finding] = []
    all_cves: list[dict] = []

    for pkg in packages:
        pkg_lower = pkg.lower().strip()

        # Check known-malicious
        if pkg_lower in MALICIOUS_PACKAGES:
            findings.append(
                Finding(
                    layer="deps",
                    severity="critical",
                    message=f"Known malicious package: {pkg}",
                    attack_id="T1195.002",
                    attack_name="Supply Chain Compromise: Compromise Software Supply Chain",
                    attack_tactic="Initial Access",
                    kill_chain_stage="delivery",
                    nist_function="PR",
                    nist_refs=["PR.PS-05", "ID.RA-09"],
                )
            )
            continue

        # Check typosquatting
        for popular in POPULAR_PACKAGES:
            if pkg_lower != popular and _levenshtein(pkg_lower, popular) <= 2:
                findings.append(
                    Finding(
                        layer="deps",
                        severity="high",
                        message=f"Possible typosquat: '{pkg}' is similar to '{popular}' (edit distance: {_levenshtein(pkg_lower, popular)})",
                        attack_id="T1195.002",
                        attack_name="Supply Chain Compromise",
                        attack_tactic="Initial Access",
                        kill_chain_stage="delivery",
                        nist_function="ID",
                        nist_refs=["ID.RA-09", "PR.PS-05"],
                    )
                )
                break

        # Query NVD
        cves = await _check_nvd(pkg_lower)
        if cves:
            all_cves.extend(cves)
            for cve in cves:
                findings.append(
                    make_finding_from_technique(
                        "T1190" if cve["cvss"] >= 9.0 else "",
                        "deps",
                        f"CVE {cve['id']} (CVSS {cve['cvss']}) in {pkg}: {cve['description'][:100]}",
                    )
                )
                # Manually set severity from CVSS
                findings[-1].severity = "critical" if cve["cvss"] >= 9.0 else "high"
                findings[-1].nist_function = "ID"
                findings[-1].nist_refs = ["ID.RA-01", "DE.AE-07"]

    return findings, all_cves


# ---------------------------------------------------------------------------
# Layer 3: Sandbox Probe
# ---------------------------------------------------------------------------

MONITOR_WRAPPER = """
import json as _json

_MONITOR_LOG = []

# Monkey-patch network access
try:
    import urllib.request as _urllib_req
    _orig_urlopen = _urllib_req.urlopen
    def _mon_urlopen(url, *a, **kw):
        _MONITOR_LOG.append({"type": "network", "action": "urlopen", "target": str(url)})
        raise PermissionError("Network access blocked during validation probe")
    _urllib_req.urlopen = _mon_urlopen
except ImportError:
    pass

# Monkey-patch file open for sensitive paths
_orig_open = open
_SENSITIVE_PREFIXES = ("/etc", "/home", "/root", "/var/log", "/proc", "/sys")
def _mon_open(path, *a, **kw):
    path_str = str(path)
    if any(path_str.startswith(p) for p in _SENSITIVE_PREFIXES):
        _MONITOR_LOG.append({"type": "filesystem", "action": "open", "target": path_str})
        raise PermissionError(f"Access to {path_str} blocked during validation probe")
    return _orig_open(path, *a, **kw)
import builtins
builtins.open = _mon_open

# Monkey-patch subprocess
try:
    import subprocess as _subprocess
    _orig_run = _subprocess.run
    def _mon_run(cmd, *a, **kw):
        _MONITOR_LOG.append({"type": "exec", "action": "subprocess.run", "target": str(cmd)})
        raise PermissionError("Subprocess execution blocked during validation probe")
    _subprocess.run = _mon_run
    _subprocess.call = _mon_run
    _subprocess.Popen = _mon_run
    _subprocess.check_output = _mon_run
except ImportError:
    pass

# Monkey-patch socket
try:
    import socket as _socket
    _orig_connect = _socket.socket.connect
    def _mon_connect(self, addr):
        _MONITOR_LOG.append({"type": "network", "action": "socket.connect", "target": str(addr)})
        raise PermissionError("Socket connection blocked during validation probe")
    _socket.socket.connect = _mon_connect
except ImportError:
    pass

USER_INPUT = "test sample data\\n1,2,3\\nfoo,bar,baz"

"""

MONITOR_FOOTER = """

# Dump monitor log
import json as _json2
print("\\n__MONITOR_LOG__:" + _json2.dumps(_MONITOR_LOG))
"""


async def _layer3_probe(code: str, packages: list[str]) -> list[Finding]:
    """Layer 3: Execute script in sandbox with monitoring wrapper."""
    from sandbox import run_code

    findings: list[Finding] = []

    probe_code = MONITOR_WRAPPER + code + MONITOR_FOOTER

    try:
        import asyncio
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor() as pool:
            result = await asyncio.get_event_loop().run_in_executor(
                pool,
                lambda: run_code(
                    probe_code,
                    language="python",
                    timeout=15,
                    packages=packages if packages else None,
                ),
            )
    except Exception as e:
        findings.append(
            Finding(
                layer="sandbox",
                severity="medium",
                message=f"Sandbox probe failed to execute: {e}",
            )
        )
        return findings

    # Parse monitor log from stdout
    stdout = result.get("stdout", "")
    log_marker = "__MONITOR_LOG__:"
    if log_marker in stdout:
        log_json = stdout[stdout.index(log_marker) + len(log_marker) :].strip()
        try:
            monitor_log = json.loads(log_json)
        except json.JSONDecodeError:
            monitor_log = []

        for entry in monitor_log:
            etype = entry.get("type", "")
            action = entry.get("action", "")
            target = entry.get("target", "")

            if etype == "network":
                findings.append(
                    make_finding_from_technique(
                        "T1041",
                        "sandbox",
                        f"Runtime network access detected: {action}({target})",
                    )
                )
            elif etype == "filesystem":
                findings.append(
                    make_finding_from_technique(
                        "T1005",
                        "sandbox",
                        f"Runtime sensitive file access: {action}({target})",
                    )
                )
            elif etype == "exec":
                findings.append(
                    make_finding_from_technique(
                        "T1059.006",
                        "sandbox",
                        f"Runtime shell execution: {action}({target})",
                    )
                )

    # Check if the script errored in a suspicious way
    error = result.get("error", "")
    if error and "PermissionError" not in error:
        # Non-permission errors during probe are suspicious but not blocking
        findings.append(
            Finding(
                layer="sandbox",
                severity="low",
                message=f"Script errored during probe: {error[:200]}",
            )
        )

    return findings


# ---------------------------------------------------------------------------
# Layer 4: LLM Review
# ---------------------------------------------------------------------------


async def _layer4_llm(
    code: str,
    description: str,
    prior_findings: list[Finding],
) -> list[Finding]:
    """Layer 4: LLM-based review for ambiguous cases."""
    findings: list[Finding] = []

    try:
        from langchain_core.messages import HumanMessage, SystemMessage

        from agents.llm import get_llm
        from agents.parse import extract_text

        # Format prior findings for context
        findings_summary = (
            "\n".join(f"- [{f.severity.upper()}] {f.attack_id or 'N/A'}: {f.message}" for f in prior_findings)
            or "No automated findings."
        )

        llm = get_llm(
            override_model="google/gemini-3-flash-preview",
            override_provider="openrouter",
            temperature=0.1,
            max_tokens=1024,
        )

        response = llm.invoke(
            [
                SystemMessage(
                    content=(
                        "You are a cybersecurity analyst reviewing code submitted to a script marketplace. "
                        "Your job is to determine if the code is SAFE, SUSPICIOUS, or MALICIOUS. "
                        "Consider: does the code do what its description says? Are there hidden behaviors? "
                        "Is there data exfiltration, credential theft, or destructive actions?"
                    )
                ),
                HumanMessage(
                    content=(
                        f"## Script Description\n{description}\n\n"
                        f"## Automated Findings\n{findings_summary}\n\n"
                        f"## Code\n```python\n{code[:4000]}\n```\n\n"
                        "Respond with exactly one of: SAFE, SUSPICIOUS, or MALICIOUS\n"
                        "Then explain in 1-2 sentences why."
                    )
                ),
            ]
        )

        text = extract_text(response.content).strip()
        first_word = text.split()[0].upper() if text else "SAFE"

        if first_word == "MALICIOUS":
            findings.append(
                Finding(
                    layer="llm",
                    severity="high",
                    message=f"LLM review: MALICIOUS — {text[len(first_word) :].strip()[:200]}",
                    nist_function="DE",
                    nist_refs=["DE.AE-02"],
                )
            )
        elif first_word == "SUSPICIOUS":
            findings.append(
                Finding(
                    layer="llm",
                    severity="medium",
                    message=f"LLM review: SUSPICIOUS — {text[len(first_word) :].strip()[:200]}",
                    nist_function="DE",
                    nist_refs=["DE.AE-02"],
                )
            )

    except Exception as e:
        logger.warning(f"LLM review failed: {e}")

    return findings


# ---------------------------------------------------------------------------
# Main validation pipeline
# ---------------------------------------------------------------------------


async def validate_script(
    code: str,
    packages: list[str],
    description: str,
    skip_sandbox: bool = False,
    skip_llm: bool = False,
    # Quality layers (5-7)
    sample_input: str | None = None,
    expected_output: str | None = None,
    test_code: str | None = None,
    input_schema: str = "",
    skip_functionality: bool = False,
    skip_quality: bool = False,
    skip_reliability: bool = False,
) -> ComplianceReport:
    """Run the full 7-layer validation pipeline.

    Layers 1-4: Security (MITRE ATT&CK, Kill Chain, NIST CSF)
    Layers 5-7: Quality (Functionality, Code Quality, Reliability)

    Returns a ComplianceReport with security verdict + quality summaries.
    """
    start_time = time.time()
    all_findings: list[Finding] = []
    all_cves: list[dict] = []

    # Layer 1: Static analysis (always runs)
    layer1 = _layer1_static(code)
    all_findings.extend(layer1)

    # Layer 2: Dependency audit (always runs)
    layer2_findings, cves = await _layer2_deps(packages)
    all_findings.extend(layer2_findings)
    all_cves = cves

    # Layer 3: Sandbox probe (can be skipped)
    if not skip_sandbox:
        layer3 = await _layer3_probe(code, packages)
        all_findings.extend(layer3)

    # Calculate intermediate risk score (security layers only)
    risk_score = _calculate_risk_score(all_findings)

    # Layer 4: LLM review (only if ambiguous, can be skipped)
    if not skip_llm and 0.25 <= risk_score <= 0.75:
        layer4 = await _layer4_llm(code, description, all_findings)
        all_findings.extend(layer4)
        risk_score = _calculate_risk_score(all_findings)

    # Layers 5-7: Quality (Functionality, Code Quality, Reliability)
    from guards.script_quality import run_quality_layers

    quality_findings, func_summary, qual_summary, rel_summary = await run_quality_layers(
        code=code,
        packages=packages,
        description=description,
        input_schema=input_schema,
        sample_input=sample_input,
        expected_output=expected_output,
        test_code=test_code,
        skip_functionality=skip_functionality,
        skip_quality=skip_quality,
        skip_reliability=skip_reliability,
    )
    all_findings.extend(quality_findings)

    # Build compliance report (risk score excludes quality layers)
    report = _build_report(all_findings, all_cves, risk_score)
    report.functionality_summary = func_summary
    report.quality_summary = qual_summary
    report.reliability_summary = rel_summary
    report.latency_ms = (time.time() - start_time) * 1000

    return report


def _calculate_risk_score(findings: list[Finding]) -> float:
    """Calculate security risk score from findings.

    Only counts security layers (static, deps, sandbox, llm).
    Quality/reliability findings don't affect the security verdict.
    """
    security_findings = [f for f in findings if f.layer in SECURITY_LAYERS]
    if not security_findings:
        return 0.0
    total = sum(SEVERITY_WEIGHTS.get(f.severity, 0.1) for f in security_findings)
    return min(1.0, total / max(len(security_findings), 1) * min(len(security_findings), 5) / 5)


def _build_report(
    findings: list[Finding],
    cves: list[dict],
    risk_score: float,
) -> ComplianceReport:
    """Build the full compliance report with framework coverage."""

    # Determine verdict
    severities = [f.severity for f in findings]
    if "critical" in severities or severities.count("high") >= 2:
        verdict = "REJECTED"
    elif "high" in severities:
        verdict = "FLAGGED"
    elif findings:
        verdict = "APPROVED"
    else:
        verdict = "APPROVED"

    # Build attack surface (unique ATT&CK techniques)
    attack_surface = []
    seen_attacks = set()
    for f in findings:
        if f.attack_id and f.attack_id not in seen_attacks:
            seen_attacks.add(f.attack_id)
            tech = ATTACK_TECHNIQUES.get(f.attack_id)
            attack_surface.append(
                {
                    "id": f.attack_id,
                    "name": f.attack_name or (tech.name if tech else ""),
                    "tactic": f.attack_tactic or (tech.tactic if tech else ""),
                    "severity": f.severity,
                }
            )

    # Build Kill Chain coverage
    kill_chain_coverage = {}
    for f in findings:
        if f.kill_chain_stage:
            kill_chain_coverage[f.kill_chain_stage] = kill_chain_coverage.get(f.kill_chain_stage, 0) + 1

    # Build NIST summary
    nist_summary = {
        "GV": "Security policy applied: import whitelist, severity thresholds, auto-reject rules",
        "ID": f"Risk assessment: {len(attack_surface)} ATT&CK techniques identified, {len(cves)} CVEs found",
        "PR": f"Protection: validation pipeline {'blocked' if verdict == 'REJECTED' else 'screened'} script",
        "DE": f"Detection: {len(findings)} findings across {len({f.layer for f in findings})} layers",
        "RS": f"Response: verdict={verdict}, risk_score={risk_score:.2f}",
        "RC": "Recovery: E2B sandbox containers are ephemeral, no persistent state contamination",
    }

    # Generate vulnerability assessment report if CVEs found
    vuln_report = format_vulnerability_report(cves, []) if cves else ""

    # Generate summary
    if verdict == "APPROVED" and not findings:
        summary = "No security findings. Script approved for marketplace."
    elif verdict == "APPROVED":
        summary = f"Minor findings ({len(findings)}). Script approved with notes."
    elif verdict == "FLAGGED":
        high_findings = [f for f in findings if f.severity == "high"]
        summary = (
            f"Security concerns detected: {len(high_findings)} high-severity finding(s). Script flagged for review."
        )
    else:
        critical = [f for f in findings if f.severity == "critical"]
        summary = f"Script rejected: {len(critical)} critical finding(s). " + "; ".join(
            f.message[:80] for f in critical[:3]
        )

    # Append vulnerability report to summary if present
    if vuln_report:
        summary += f"\n\n{vuln_report}"

    return ComplianceReport(
        verdict=verdict,
        risk_score=risk_score,
        findings=findings,
        cves=cves,
        attack_surface=attack_surface,
        kill_chain_coverage=kill_chain_coverage,
        nist_summary=nist_summary,
        summary=summary,
    )
