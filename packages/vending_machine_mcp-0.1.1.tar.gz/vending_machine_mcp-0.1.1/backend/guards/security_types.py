"""
Security framework types — MITRE ATT&CK, Cyber Kill Chain, NIST CSF 2.0.

Provides the constants, dataclasses, and mappings used by the script
validation engine to tag findings across all three frameworks.

References:
  - MITRE ATT&CK: https://attack.mitre.org/techniques/enterprise/
  - Cyber Kill Chain: Lockheed Martin (2011)
  - NIST CSF 2.0: NIST.CSWP.29 (February 2024)
  - NIST IR 8374: Ransomware Risk Management Profile (February 2022)
"""

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# MITRE ATT&CK Techniques (subset relevant to script analysis)
# ---------------------------------------------------------------------------


@dataclass
class AttackTechnique:
    id: str
    name: str
    tactic: str
    description: str
    severity: str  # critical | high | medium | low
    kill_chain_stage: str
    nist_functions: list[str]


ATTACK_TECHNIQUES: dict[str, AttackTechnique] = {
    "T1059.006": AttackTechnique(
        id="T1059.006",
        name="Command & Scripting Interpreter: Python",
        tactic="Execution",
        description="Adversaries abuse Python to execute commands via os.system, subprocess, or os.popen",
        severity="critical",
        kill_chain_stage="exploitation",
        nist_functions=["DE.CM-09", "PR.PS-05"],
    ),
    "T1059.006.safe": AttackTechnique(
        id="T1059.006.safe",
        name="CLI Tool Wrapper (subprocess, shell=False)",
        tactic="Execution",
        description="Script invokes known CLI tools via subprocess with shell=False — low risk",
        severity="low",
        kill_chain_stage="exploitation",
        nist_functions=["DE.CM-09"],
    ),
    "T1005": AttackTechnique(
        id="T1005",
        name="Data from Local System",
        tactic="Collection",
        description="Adversaries search local system sources for data of interest prior to exfiltration",
        severity="high",
        kill_chain_stage="actions_on_objectives",
        nist_functions=["DE.CM-09", "PR.DS-01"],
    ),
    "T1041": AttackTechnique(
        id="T1041",
        name="Exfiltration Over C2 Channel",
        tactic="Exfiltration",
        description="Adversaries steal data by sending it over an existing command-and-control channel",
        severity="high",
        kill_chain_stage="command_and_control",
        nist_functions=["DE.CM-01", "DE.AE-02"],
    ),
    "T1027": AttackTechnique(
        id="T1027",
        name="Obfuscated Files or Information",
        tactic="Defense Evasion",
        description="Adversaries obfuscate payloads using encoding, encryption, or other techniques",
        severity="critical",
        kill_chain_stage="weaponization",
        nist_functions=["DE.AE-02", "ID.RA-09"],
    ),
    "T1552.001": AttackTechnique(
        id="T1552.001",
        name="Unsecured Credentials: Credentials in Files",
        tactic="Credential Access",
        description="Adversaries search local filesystems or environment variables for credentials",
        severity="high",
        kill_chain_stage="actions_on_objectives",
        nist_functions=["DE.CM-09", "PR.DS-01"],
    ),
    "T1070.004": AttackTechnique(
        id="T1070.004",
        name="Indicator Removal: File Deletion",
        tactic="Defense Evasion",
        description="Adversaries delete files to remove indicators of compromise or destroy data",
        severity="critical",
        kill_chain_stage="actions_on_objectives",
        nist_functions=["DE.CM-09", "RS.MI-01"],
    ),
    "T1053.005": AttackTechnique(
        id="T1053.005",
        name="Scheduled Task/Job",
        tactic="Persistence",
        description="Adversaries abuse task scheduling to execute malicious code at system startup or on a schedule",
        severity="medium",
        kill_chain_stage="installation",
        nist_functions=["DE.CM-09", "PR.PS-05"],
    ),
    "T1571": AttackTechnique(
        id="T1571",
        name="Non-Standard Port",
        tactic="Command and Control",
        description="Adversaries communicate using non-standard ports to bypass filtering",
        severity="medium",
        kill_chain_stage="command_and_control",
        nist_functions=["DE.CM-01", "PR.IR-01"],
    ),
    "T1105": AttackTechnique(
        id="T1105",
        name="Ingress Tool Transfer",
        tactic="Command and Control",
        description="Adversaries transfer tools or files from an external system into a compromised environment",
        severity="high",
        kill_chain_stage="installation",
        nist_functions=["DE.CM-01", "PR.PS-05"],
    ),
    "T1486": AttackTechnique(
        id="T1486",
        name="Data Encrypted for Impact",
        tactic="Impact",
        description="Adversaries encrypt data to interrupt availability and hold it for ransom",
        severity="high",
        kill_chain_stage="actions_on_objectives",
        nist_functions=["DE.AE-02", "RS.MI-01"],
    ),
    "T1082": AttackTechnique(
        id="T1082",
        name="System Information Discovery",
        tactic="Discovery",
        description="Adversaries gather system information including OS version, hardware, and patches",
        severity="low",
        kill_chain_stage="reconnaissance",
        nist_functions=["DE.CM-09"],
    ),
    "T1016": AttackTechnique(
        id="T1016",
        name="System Network Configuration Discovery",
        tactic="Discovery",
        description="Adversaries look for network configuration and settings of the compromised system",
        severity="medium",
        kill_chain_stage="reconnaissance",
        nist_functions=["DE.CM-01", "DE.CM-09"],
    ),
}


# ---------------------------------------------------------------------------
# Cyber Kill Chain stages (Lockheed Martin)
# ---------------------------------------------------------------------------

KILL_CHAIN_STAGES = [
    "reconnaissance",
    "weaponization",
    "delivery",
    "exploitation",
    "installation",
    "command_and_control",
    "actions_on_objectives",
]

KILL_CHAIN_LABELS = {
    "reconnaissance": "Reconnaissance",
    "weaponization": "Weaponization",
    "delivery": "Delivery",
    "exploitation": "Exploitation",
    "installation": "Installation",
    "command_and_control": "Command & Control",
    "actions_on_objectives": "Actions on Objectives",
}


# ---------------------------------------------------------------------------
# NIST CSF 2.0 Functions and Categories (from NIST.CSWP.29)
# ---------------------------------------------------------------------------

NIST_FUNCTIONS = {
    "GV": "Govern",
    "ID": "Identify",
    "PR": "Protect",
    "DE": "Detect",
    "RS": "Respond",
    "RC": "Recover",
}

NIST_CATEGORIES = {
    # Govern
    "GV.OC": "Organizational Context",
    "GV.RM": "Risk Management Strategy",
    "GV.RR": "Roles, Responsibilities, and Authorities",
    "GV.PO": "Policy",
    "GV.OV": "Oversight",
    "GV.SC": "Cybersecurity Supply Chain Risk Management",
    # Identify
    "ID.AM": "Asset Management",
    "ID.RA": "Risk Assessment",
    "ID.IM": "Improvement",
    # Protect
    "PR.AA": "Identity Management, Authentication, and Access Control",
    "PR.AT": "Awareness and Training",
    "PR.DS": "Data Security",
    "PR.PS": "Platform Security",
    "PR.IR": "Technology Infrastructure Resilience",
    # Detect
    "DE.CM": "Continuous Monitoring",
    "DE.AE": "Adverse Event Analysis",
    # Respond
    "RS.MA": "Incident Management",
    "RS.AN": "Incident Analysis",
    "RS.CO": "Incident Response Reporting and Communication",
    "RS.MI": "Incident Mitigation",
    # Recover
    "RC.RP": "Incident Recovery Plan Execution",
    "RC.CO": "Incident Recovery Communication",
}

# Key subcategories referenced in our validation pipeline
NIST_SUBCATEGORIES = {
    "ID.RA-01": "Vulnerabilities in assets are identified, validated, and recorded",
    "ID.RA-09": "Software integrity assessed prior to acquisition and use",
    "PR.PS-05": "Installation and execution of unauthorized software are prevented",
    "PR.PS-06": "Secure software development practices are integrated",
    "PR.DS-01": "Confidentiality, integrity, availability of data-at-rest are protected",
    "PR.IR-01": "Networks and environments protected from unauthorized access",
    "DE.CM-01": "Networks monitored to find potentially adverse events",
    "DE.CM-09": "Software, runtime environments, and data monitored for adverse events",
    "DE.AE-02": "Potentially adverse events analyzed to understand activities",
    "DE.AE-07": "Cyber threat intelligence integrated into analysis",
    "RS.MA-03": "Incidents are categorized and prioritized",
    "RS.AN-03": "Analysis performed to establish root cause",
    "RS.MI-01": "Incidents are contained",
    "RC.RP-05": "Integrity of restored assets verified",
}


# ---------------------------------------------------------------------------
# Finding and Compliance Report
# ---------------------------------------------------------------------------


@dataclass
class Finding:
    """A single security finding tagged across all three frameworks."""

    layer: str  # static | deps | sandbox | llm
    severity: str  # critical | high | medium | low
    message: str
    line_number: int | None = None
    code_snippet: str | None = None
    # MITRE ATT&CK
    attack_id: str = ""  # e.g., "T1059.006"
    attack_name: str = ""  # e.g., "Command & Scripting: Python"
    attack_tactic: str = ""  # e.g., "Execution"
    # Cyber Kill Chain
    kill_chain_stage: str = ""  # e.g., "exploitation"
    # NIST CSF 2.0
    nist_function: str = ""  # e.g., "DE" (Detect)
    nist_refs: list[str] = field(default_factory=list)  # e.g., ["DE.CM-09", "PR.PS-05"]

    def to_dict(self) -> dict:
        return {
            "layer": self.layer,
            "severity": self.severity,
            "message": self.message,
            "lineNumber": self.line_number,
            "codeSnippet": self.code_snippet,
            "attack": {
                "id": self.attack_id,
                "name": self.attack_name,
                "tactic": self.attack_tactic,
            }
            if self.attack_id
            else None,
            "killChainStage": KILL_CHAIN_LABELS.get(self.kill_chain_stage, self.kill_chain_stage),
            "nist": {
                "function": NIST_FUNCTIONS.get(self.nist_function, self.nist_function),
                "refs": self.nist_refs,
            }
            if self.nist_function
            else None,
        }


@dataclass
class ComplianceReport:
    """Full security compliance report across all three frameworks."""

    verdict: str = "APPROVED"  # APPROVED | FLAGGED | REJECTED
    risk_score: float = 0.0  # 0.0 - 1.0
    findings: list[Finding] = field(default_factory=list)
    cves: list[dict] = field(default_factory=list)
    attack_surface: list[dict] = field(default_factory=list)
    kill_chain_coverage: dict = field(default_factory=dict)
    nist_summary: dict = field(default_factory=dict)
    summary: str = ""
    latency_ms: float = 0.0
    # Quality layers (Layers 5-7)
    functionality_summary: dict = field(default_factory=dict)
    quality_summary: dict = field(default_factory=dict)
    reliability_summary: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "riskScore": self.risk_score,
            "findings": [f.to_dict() for f in self.findings],
            "cves": self.cves,
            "attackSurface": self.attack_surface,
            "killChainCoverage": {KILL_CHAIN_LABELS.get(k, k): v for k, v in self.kill_chain_coverage.items()},
            "nistSummary": self.nist_summary,
            "summary": self.summary,
            "latencyMs": round(self.latency_ms, 1),
            "functionalitySummary": self.functionality_summary,
            "qualitySummary": self.quality_summary,
            "reliabilitySummary": self.reliability_summary,
        }


def make_finding_from_technique(
    technique_id: str,
    layer: str,
    message: str,
    line_number: int | None = None,
    code_snippet: str | None = None,
) -> Finding:
    """Create a Finding pre-populated with all framework tags from an ATT&CK technique ID."""
    tech = ATTACK_TECHNIQUES.get(technique_id)
    if not tech:
        return Finding(
            layer=layer,
            severity="medium",
            message=message,
            line_number=line_number,
            code_snippet=code_snippet,
        )
    return Finding(
        layer=layer,
        severity=tech.severity,
        message=message,
        line_number=line_number,
        code_snippet=code_snippet,
        attack_id=tech.id,
        attack_name=tech.name,
        attack_tactic=tech.tactic,
        kill_chain_stage=tech.kill_chain_stage,
        nist_function=tech.nist_functions[0].split(".")[0] if tech.nist_functions else "DE",
        nist_refs=tech.nist_functions,
    )
