"""
QA Auditor — Independent output verification pipeline.

Runs AFTER agent completion, BEFORE delivery to the user.

Pipeline:
  1. Detect artifacts (what languages/file types are in the output?)
  2. Extract code blocks from the output
  3. Run appropriate static analysis tools (via QA Tools MCP server)
  4. Secret scan everything
  5. LLM review with tool results as evidence
  6. Return verdict: PASS / WARN / FAIL

The QA Auditor uses a DIFFERENT model than the primary agent
to avoid shared blind spots.

Usage:
    from guards.qa_auditor import audit_output
    result = await audit_output(output, agent_id, task)
    if result.verdict == "FAIL":
        # retry once or deliver with warning
"""

import logging
import re
import time
from dataclasses import dataclass, field

logger = logging.getLogger("qa_auditor")


@dataclass
class ToolCheckResult:
    """Result from a single QA tool."""

    tool: str
    passed: bool
    summary: str
    details: str = ""


@dataclass
class AuditResult:
    """Full audit result."""

    verdict: str = "PASS"  # PASS, WARN, FAIL
    risk_score: float = 0.0  # 0.0 = perfect, 1.0 = critical failure
    tool_checks: list[ToolCheckResult] = field(default_factory=list)
    secret_findings: int = 0
    llm_summary: str = ""
    latency_ms: float = 0.0
    skipped: bool = False  # True if audit was skipped (text-only agent)
    skip_reason: str = ""


# ─── Code Extraction ───────────────────────────────────────────────


def _extract_code_blocks(output: str) -> list[dict]:
    """
    Extract fenced code blocks from agent output.
    Returns list of {"language": str, "code": str}.
    """
    blocks = []
    pattern = re.compile(r"```(\w+)?\s*\n(.*?)```", re.DOTALL)

    for match in pattern.finditer(output):
        lang = (match.group(1) or "text").lower()
        code = match.group(2).strip()
        if code and len(code) > 10:  # Skip trivial snippets
            blocks.append({"language": lang, "code": code})

    return blocks


def _detect_inline_code(output: str) -> list[dict]:
    """
    Detect significant code that isn't in fenced blocks.
    Looks for file-like structures (imports, function defs, etc.)
    """
    blocks = []

    # Python-like blocks (not in fenced blocks)
    if re.search(r"^(?:import |from |def |class |async def )", output, re.MULTILINE):
        # Extract contiguous Python-looking lines
        py_lines = []
        for line in output.splitlines():
            if re.match(r"^(?:import |from |def |class |async def |    |@|\s*#)", line):
                py_lines.append(line)
            elif py_lines and line.strip() == "":
                py_lines.append(line)  # Keep blank lines within code
            elif py_lines:
                if len(py_lines) > 5:
                    blocks.append({"language": "python", "code": "\n".join(py_lines)})
                py_lines = []
        if len(py_lines) > 5:
            blocks.append({"language": "python", "code": "\n".join(py_lines)})

    return blocks


# ─── Agent → Tool Mapping ──────────────────────────────────────────

# Which agents produce code that should be tool-checked
CODE_AGENTS = {
    "code-gremlin",
    "bug-hunter",
    "devops-dwarf",
    "test-goblin",
    "web-weaver",
    "mcp-maker",
    "data-sprite",
    "spreadsheet-sage",
    "cloud-sensei",
}

# Text-only agents — skip tool checks, LLM-only review
TEXT_AGENTS = {
    "vibe-writer",
    "research-owl",
    "inbox-zero",
    "fridge-chef",
    "desk-pilot",
    "info-scout",
}

# Language → QA tools to run
LANGUAGE_TOOLS = {
    "javascript": ["biome_check", "syntax_check", "secret_scan", "import_audit", "complexity_score"],
    "typescript": ["biome_check", "syntax_check", "secret_scan", "import_audit", "complexity_score"],
    "js": ["biome_check", "syntax_check", "secret_scan", "import_audit", "complexity_score"],
    "ts": ["biome_check", "syntax_check", "secret_scan", "import_audit", "complexity_score"],
    "jsx": ["biome_check", "syntax_check", "secret_scan", "import_audit"],
    "tsx": ["biome_check", "syntax_check", "secret_scan", "import_audit"],
    "python": ["ruff_check", "syntax_check", "secret_scan", "import_audit", "complexity_score"],
    "py": ["ruff_check", "syntax_check", "secret_scan", "import_audit", "complexity_score"],
    "json": ["syntax_check"],
    "yaml": ["syntax_check"],
    "yml": ["syntax_check"],
    "dockerfile": ["hadolint", "secret_scan"],
    "docker": ["hadolint", "secret_scan"],
    "bash": ["secret_scan"],
    "sh": ["secret_scan"],
    "shell": ["secret_scan"],
    "hcl": ["secret_scan"],
    "terraform": ["secret_scan"],
    "sql": ["secret_scan", "sql_injection_scan"],
}


# ─── Tool Runner (calls QA MCP tools directly) ─────────────────────


async def _run_qa_tool(tool_name: str, **kwargs) -> ToolCheckResult:
    """
    Call a QA tool directly (in-process, no MCP transport overhead).
    Falls back gracefully if the tool isn't available.
    """
    try:
        from mcp_servers.qa_tools.server import (
            biome_check,
            cfn_lint,
            complexity_score,
            dep_audit_npm,
            dep_audit_python,
            gitignore_audit,
            hadolint,
            import_audit,
            key_hygiene_audit,
            ruff_check,
            secret_scan,
            sql_injection_scan,
            syntax_check,
        )

        tool_map = {
            "biome_check": biome_check,
            "ruff_check": ruff_check,
            "cfn_lint": cfn_lint,
            "hadolint": hadolint,
            "dep_audit_npm": dep_audit_npm,
            "dep_audit_python": dep_audit_python,
            "secret_scan": secret_scan,
            "syntax_check": syntax_check,
            "gitignore_audit": gitignore_audit,
            "key_hygiene_audit": key_hygiene_audit,
            "sql_injection_scan": sql_injection_scan,
            "import_audit": import_audit,
            "complexity_score": complexity_score,
        }

        fn = tool_map.get(tool_name)
        if not fn:
            return ToolCheckResult(
                tool=tool_name,
                passed=True,
                summary=f"Unknown tool: {tool_name}",
            )

        result = await fn(**kwargs)

        passed = result.startswith("PASS")
        is_unavailable = "TOOL_UNAVAILABLE" in result

        return ToolCheckResult(
            tool=tool_name,
            passed=passed or is_unavailable,  # Don't fail if tool isn't installed
            summary=result.splitlines()[0] if result else "No output",
            details=result,
        )

    except Exception as e:
        logger.warning(f"QA tool {tool_name} failed: {e}")
        return ToolCheckResult(
            tool=tool_name,
            passed=True,  # Don't block on tool errors
            summary=f"Tool error: {e}",
        )


# ─── LLM Review ───────────────────────────────────────────────────


async def _llm_review(
    task: str,
    output: str,
    tool_results: list[ToolCheckResult],
    agent_id: str,
) -> tuple[str, str]:
    """
    Independent LLM review of agent output.
    Uses a different model than the primary agent.
    Returns (verdict, summary).
    """
    try:
        from agents.llm import get_llm

        # Use a different model family for independent review
        llm = get_llm(
            agent_id="_qa_auditor",
            temperature=0.1,
            override_model="google/gemini-3-flash-preview",
            override_provider="openrouter",
        )

        # Format tool results for context
        tool_context = ""
        if tool_results:
            tool_lines = []
            for tr in tool_results:
                status = "PASS" if tr.passed else "FAIL"
                tool_lines.append(f"  [{status}] {tr.tool}: {tr.summary}")
            tool_context = "Static analysis results:\n" + "\n".join(tool_lines)
        else:
            tool_context = "No static analysis tools were applicable."

        review_prompt = f"""You are an independent QA reviewer for an AI agent marketplace.
An agent just completed a task. Review the output for quality and safety.

Agent: {agent_id}
Task: {task[:500]}

{tool_context}

Agent Output (first 3000 chars):
---
{output[:3000]}
---

Check for:
1. COMPLETENESS: Does the output address the task? Any obvious gaps?
2. CORRECTNESS: Any clearly wrong information, hallucinated APIs, fake URLs?
3. SAFETY: Any hardcoded secrets, dangerous commands without warnings, or security anti-patterns?
4. QUALITY: Is it well-structured and usable as-is?

Respond with exactly:
VERDICT: PASS or WARN or FAIL
SUMMARY: One paragraph explaining your assessment (under 100 words).

PASS = Ready to deliver. Minor issues at most.
WARN = Deliverable but has notable issues the user should know about.
FAIL = Significant problems — incomplete, dangerous, or clearly wrong."""

        response = await llm.ainvoke(review_prompt)
        raw = response.content if hasattr(response, "content") else str(response)
        text = raw.strip() if isinstance(raw, str) else str(raw).strip()

        # Parse verdict
        verdict = "PASS"
        summary = text

        verdict_match = re.search(r"VERDICT:\s*(PASS|WARN|FAIL)", text, re.IGNORECASE)
        if verdict_match:
            verdict = verdict_match.group(1).upper()

        summary_match = re.search(r"SUMMARY:\s*(.+)", text, re.DOTALL)
        if summary_match:
            summary = summary_match.group(1).strip()[:500]

        return verdict, summary

    except Exception as e:
        logger.warning(f"QA LLM review failed: {e}")
        return "PASS", f"LLM review unavailable: {e}"


# ─── Main Entry Point ──────────────────────────────────────────────


async def audit_output(
    output: str,
    agent_id: str,
    task: str = "",
    skip_llm: bool = False,
) -> AuditResult:
    """
    Run the full QA audit pipeline on agent output.

    Args:
        output: The agent's complete output text
        agent_id: Which agent produced this
        task: The original user task (for context)
        skip_llm: Skip the LLM review step (faster, tool-only)

    Returns:
        AuditResult with verdict, tool results, and summary
    """
    start = time.time()

    if not output or not output.strip():
        return AuditResult(
            verdict="FAIL",
            risk_score=1.0,
            llm_summary="Agent produced empty output.",
            latency_ms=(time.time() - start) * 1000,
        )

    # Text-only agents — skip tool checks
    if agent_id in TEXT_AGENTS:
        if skip_llm:
            return AuditResult(
                skipped=True,
                skip_reason=f"{agent_id} is a text-only agent (no code to lint)",
                latency_ms=(time.time() - start) * 1000,
            )

        # Still do LLM review for factual consistency
        verdict, summary = await _llm_review(task, output, [], agent_id)
        return AuditResult(
            verdict=verdict,
            llm_summary=summary,
            latency_ms=(time.time() - start) * 1000,
        )

    # ── Step 1: Extract code blocks ──
    code_blocks = _extract_code_blocks(output)
    if not code_blocks:
        code_blocks = _detect_inline_code(output)

    if not code_blocks:
        # No code found — treat as text-only for this output
        if skip_llm:
            return AuditResult(
                skipped=True,
                skip_reason="No code artifacts detected in output.",
                latency_ms=(time.time() - start) * 1000,
            )

        verdict, summary = await _llm_review(task, output, [], agent_id)
        return AuditResult(
            verdict=verdict,
            llm_summary=summary,
            latency_ms=(time.time() - start) * 1000,
        )

    # ── Step 2: Run appropriate tools on each code block ──
    all_checks: list[ToolCheckResult] = []
    secret_count = 0

    for block in code_blocks:
        lang = block["language"]
        code = block["code"]
        tools = LANGUAGE_TOOLS.get(lang, ["secret_scan"])

        for tool_name in tools:
            if tool_name == "biome_check":
                result = await _run_qa_tool("biome_check", code=code, language=lang)
            elif tool_name == "ruff_check":
                result = await _run_qa_tool("ruff_check", code=code)
            elif tool_name == "hadolint":
                result = await _run_qa_tool("hadolint", dockerfile=code)
            elif tool_name == "syntax_check":
                result = await _run_qa_tool("syntax_check", code=code, language=lang)
            elif tool_name == "secret_scan":
                result = await _run_qa_tool("secret_scan", code=code)
                if not result.passed:
                    # Count secret findings
                    secret_count += len([line for line in result.details.splitlines() if "Line" in line])
            elif tool_name == "sql_injection_scan":
                result = await _run_qa_tool("sql_injection_scan", code=code, language=lang)
            elif tool_name == "import_audit":
                result = await _run_qa_tool("import_audit", code=code, language=lang)
            elif tool_name == "complexity_score":
                result = await _run_qa_tool("complexity_score", code=code, language=lang)
            else:
                continue

            all_checks.append(result)

    # ── Step 3: Also secret-scan the full output (catches secrets outside code blocks) ──
    full_secret_check = await _run_qa_tool("secret_scan", code=output)
    if not full_secret_check.passed:
        all_checks.append(full_secret_check)
        secret_count = len([line for line in full_secret_check.details.splitlines() if "Line" in line])

    # ── Step 3b: Key hygiene audit on the full output ──
    if agent_id in CODE_AGENTS:
        key_result = await _run_qa_tool("key_hygiene_audit", code=output)
        all_checks.append(key_result)

    # ── Step 3c: Gitignore audit if output contains a .gitignore ──
    gi_match = re.search(r"```(?:gitignore)?\s*\n(.*?)```", output, re.DOTALL)
    if gi_match:
        gi_result = await _run_qa_tool("gitignore_audit", gitignore_content=gi_match.group(1))
        all_checks.append(gi_result)

    # ── Step 4: Check for package.json / requirements.txt in output ──
    pkg_json_match = re.search(r"```(?:json)?\s*\n(\{[^`]*\"dependencies\"[^`]*\})\s*```", output, re.DOTALL)
    if pkg_json_match:
        dep_result = await _run_qa_tool("dep_audit_npm", package_json=pkg_json_match.group(1))
        all_checks.append(dep_result)

    req_txt_match = re.search(r"```(?:text|txt|requirements)?\s*\n([\w-]+==[^\`]+)```", output, re.DOTALL)
    if req_txt_match:
        dep_result = await _run_qa_tool("dep_audit_python", requirements_txt=req_txt_match.group(1))
        all_checks.append(dep_result)

    # ── Step 5: Calculate tool-based verdict ──
    failed_checks = [c for c in all_checks if not c.passed]
    critical_failures = [c for c in failed_checks if c.tool in ("secret_scan", "syntax_check")]

    if critical_failures:
        tool_verdict = "FAIL"
        tool_score = 0.8
    elif len(failed_checks) > len(all_checks) * 0.5:
        tool_verdict = "FAIL"
        tool_score = 0.7
    elif failed_checks:
        tool_verdict = "WARN"
        tool_score = 0.4
    else:
        tool_verdict = "PASS"
        tool_score = 0.0

    # ── Step 6: LLM review with tool evidence ──
    if not skip_llm:
        llm_verdict, llm_summary = await _llm_review(task, output, all_checks, agent_id)

        # Combine tool and LLM verdicts (tools take priority for FAIL)
        verdict_priority = {"FAIL": 3, "WARN": 2, "PASS": 1}
        final_verdict = max(tool_verdict, llm_verdict, key=lambda v: verdict_priority[v])

        # If tools say FAIL but LLM says PASS, trust tools (concrete evidence)
        if tool_verdict == "FAIL" and llm_verdict == "PASS":
            final_verdict = "FAIL"
            llm_summary = f"Tools detected critical issues. {llm_summary}"

        # If LLM says FAIL but tools say PASS, trust LLM but downgrade to WARN
        # (LLM might be wrong, don't block without tool evidence)
        if llm_verdict == "FAIL" and tool_verdict == "PASS":
            final_verdict = "WARN"
            llm_summary = f"LLM flagged concerns (no tool evidence). {llm_summary}"
    else:
        final_verdict = tool_verdict
        llm_summary = "LLM review skipped."

    return AuditResult(
        verdict=final_verdict,
        risk_score=tool_score,
        tool_checks=all_checks,
        secret_findings=secret_count,
        llm_summary=llm_summary,
        latency_ms=(time.time() - start) * 1000,
    )
