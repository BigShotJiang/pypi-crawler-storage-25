"""
Script Quality Validation — Layers 5-7: Functionality, Quality, Reliability.

Extends the security validation pipeline with tests that verify scripts
actually work, are well-written, and behave reliably across inputs.

Layer 5: Functionality — does the script run and produce correct output?
Layer 6: Quality — is the code clean, well-structured, and documented?
Layer 7: Reliability — is output deterministic? does it handle edge cases?

When the creator doesn't provide sample inputs or tests, the platform
auto-generates them using an LLM (Gemini Flash) based on the script's
code, description, and input_schema.
"""

import ast
import asyncio
import concurrent.futures
import json
import logging
import re
from collections.abc import Callable

from guards.security_types import Finding

logger = logging.getLogger("script_quality")

# Security layers — only these affect the security verdict
SECURITY_LAYERS = {"static", "deps", "sandbox", "llm"}


# ---------------------------------------------------------------------------
# LLM Test Generation
# ---------------------------------------------------------------------------


async def _generate_test_inputs(
    code: str,
    description: str,
    input_schema: str,
) -> tuple[str, list[str], list[str]]:
    """Use LLM to generate sample input, expected output patterns, and edge cases.

    Returns: (sample_input, expected_patterns, edge_case_inputs)
    """
    try:
        from langchain_core.messages import HumanMessage, SystemMessage

        from agents.llm import get_llm
        from agents.parse import extract_text

        llm = get_llm(
            override_model="google/gemini-3-flash-preview",
            override_provider="openrouter",
            temperature=0.2,
            max_tokens=2048,
        )

        messages = [
            SystemMessage(
                content=(
                    "You generate test inputs for Python scripts. Return ONLY valid JSON, no markdown, no explanation."
                )
            ),
            HumanMessage(
                content=(
                    f"Script description: {description}\n"
                    f"Input schema: {input_schema}\n"
                    f"Code:\n```python\n{code[:3000]}\n```\n\n"
                    "Generate test data as JSON:\n"
                    "{\n"
                    '  "sample_input": "a realistic input that exercises the main functionality",\n'
                    '  "expected_patterns": ["3-5 substrings the output should contain if working"],\n'
                    '  "edge_cases": ["empty input", "large input", "unicode input", "malformed input"]\n'
                    "}"
                )
            ),
        ]

        # Run synchronous LLM call in a thread to avoid blocking the event loop
        response = await asyncio.to_thread(llm.invoke, messages)

        text = extract_text(response.content).strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            text = re.sub(r"^```\w*\n?", "", text)
            text = re.sub(r"\n?```$", "", text)

        data = json.loads(text)
        return (
            data.get("sample_input", "test input"),
            data.get("expected_patterns", []),
            data.get("edge_cases", ["", "A" * 10000, "Hello \U0001f30d caf\u00e9", "None"]),
        )

    except Exception as e:
        logger.warning(f"LLM test generation failed: {e}")
        # Fallback: generic test data
        return (
            "test sample data\n1,2,3\nfoo,bar,baz",
            [],
            ["", "A" * 10000, "Hello \U0001f30d caf\u00e9 na\u00efve", "None"],
        )


# ---------------------------------------------------------------------------
# Layer 5: Functionality Testing
# ---------------------------------------------------------------------------


def _build_execution_code(code: str, user_input: str) -> str:
    """Build the script execution code with USER_INPUT prepended."""
    escaped = user_input.replace("\\", "\\\\").replace('"""', '\\"\\"\\"')
    return f'USER_INPUT = """{escaped}"""\n\n{code}'


async def _run_in_sandbox(code: str, packages: list[str] | None = None, timeout: int = 30) -> dict:
    """Run code in E2B sandbox via thread executor."""
    from sandbox import run_code

    loop = asyncio.get_event_loop()
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return await loop.run_in_executor(
            pool,
            lambda: run_code(code=code, language="python", timeout=timeout, packages=packages),
        )


async def _layer5_functionality(
    code: str,
    packages: list[str],
    sample_input: str | None,
    expected_output: str | None,
    expected_patterns: list[str] | None,
    test_code: str | None,
) -> tuple[list[Finding], dict]:
    """Layer 5: Does the script run and produce correct output?"""
    findings: list[Finding] = []
    summary: dict = {"tested": False, "crashed": False, "output_match": None, "tests_passed": None}

    if not sample_input and not test_code:
        findings.append(
            Finding(
                layer="functionality",
                severity="low",
                message="No sample input or test code provided — functionality not verified",
                nist_function="PR",
                nist_refs=["PR.PS-06"],
            )
        )
        return findings, summary

    # Run with sample input
    if sample_input:
        exec_code = _build_execution_code(code, sample_input)
        result = await _run_in_sandbox(exec_code, packages=packages or None)
        summary["tested"] = True

        if result["exit_code"] != 0:
            summary["crashed"] = True
            findings.append(
                Finding(
                    layer="functionality",
                    severity="medium",
                    message=f"Script crashed on sample input: {result['error'][:200] if result['error'] else 'unknown error'}",
                    nist_function="PR",
                    nist_refs=["PR.PS-06"],
                )
            )
        elif not result["stdout"].strip():
            findings.append(
                Finding(
                    layer="functionality",
                    severity="medium",
                    message="Script produced no output on sample input",
                    nist_function="PR",
                    nist_refs=["PR.PS-06"],
                )
            )
        else:
            # Check against expected output (exact match)
            if expected_output:
                if expected_output.strip() == result["stdout"].strip():
                    summary["output_match"] = True
                else:
                    summary["output_match"] = False
                    findings.append(
                        Finding(
                            layer="functionality",
                            severity="medium",
                            message="Script output does not match expected output",
                            nist_function="PR",
                            nist_refs=["PR.PS-06"],
                        )
                    )

            # Check against expected patterns (substring match)
            if expected_patterns:
                stdout = result["stdout"]
                missing = [p for p in expected_patterns if p not in stdout]
                if missing:
                    findings.append(
                        Finding(
                            layer="functionality",
                            severity="low",
                            message=f"Output missing expected patterns: {missing[:3]}",
                            nist_function="PR",
                            nist_refs=["PR.PS-06"],
                        )
                    )

    # Run creator's test code
    if test_code:
        result = await _run_in_sandbox(test_code, packages=packages or None)
        if result["exit_code"] == 0:
            summary["tests_passed"] = True
        else:
            summary["tests_passed"] = False
            findings.append(
                Finding(
                    layer="functionality",
                    severity="medium",
                    message=f"Creator test code failed: {result['error'][:200] if result['error'] else 'exit code ' + str(result['exit_code'])}",
                    nist_function="PR",
                    nist_refs=["PR.PS-06"],
                )
            )

    return findings, summary


# ---------------------------------------------------------------------------
# Layer 6: Quality Analysis
# ---------------------------------------------------------------------------


async def _layer6_quality(code: str, packages: list[str]) -> tuple[list[Finding], dict]:
    """Layer 6: Is the code clean, well-structured, and documented?"""
    findings: list[Finding] = []
    summary: dict = {
        "lint_errors": 0,
        "lint_warnings": 0,
        "total_lines": 0,
        "function_count": 0,
        "class_count": 0,
        "max_nesting": 0,
        "comment_ratio": 0.0,
    }

    lines = code.split("\n")
    summary["total_lines"] = len(lines)

    # --- Ruff lint in sandbox ---
    try:
        ruff_code = (
            "import subprocess, sys, tempfile, os\n"
            "code = " + repr(code) + "\n"
            "with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:\n"
            "    f.write(code)\n"
            "    tmp = f.name\n"
            "result = subprocess.run(\n"
            "    ['ruff', 'check', '--output-format=json', '--select=E,W,F', tmp],\n"
            "    capture_output=True, text=True, timeout=15\n"
            ")\n"
            "os.unlink(tmp)\n"
            "print(result.stdout)\n"
        )
        result = await _run_in_sandbox(ruff_code, packages=["ruff"])
        if result["stdout"].strip():
            try:
                lint_results = json.loads(result["stdout"])
                errors = [r for r in lint_results if r.get("code", "").startswith(("E", "F"))]
                warnings = [r for r in lint_results if r.get("code", "").startswith("W")]
                summary["lint_errors"] = len(errors)
                summary["lint_warnings"] = len(warnings)

                if len(errors) > 10:
                    findings.append(
                        Finding(
                            layer="quality",
                            severity="medium",
                            message=f"Ruff found {len(errors)} lint errors and {len(warnings)} warnings",
                            nist_function="PR",
                            nist_refs=["PR.PS-06"],
                        )
                    )
                elif len(errors) > 0:
                    findings.append(
                        Finding(
                            layer="quality",
                            severity="low",
                            message=f"Ruff found {len(errors)} lint errors and {len(warnings)} warnings",
                            nist_function="PR",
                            nist_refs=["PR.PS-06"],
                        )
                    )
            except json.JSONDecodeError:
                pass
    except Exception as e:
        logger.warning(f"Ruff lint check failed: {e}")

    # --- AST complexity analysis (in-process, no sandbox) ---
    try:
        tree = ast.parse(code)

        func_count = sum(1 for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)))
        class_count = sum(1 for node in ast.walk(tree) if isinstance(node, ast.ClassDef))
        summary["function_count"] = func_count
        summary["class_count"] = class_count

        # Max nesting depth
        max_depth = _calculate_max_nesting(tree)
        summary["max_nesting"] = max_depth

        if max_depth > 5:
            findings.append(
                Finding(
                    layer="quality",
                    severity="medium",
                    message=f"High nesting depth: {max_depth} levels (max recommended: 4)",
                    nist_function="PR",
                    nist_refs=["PR.PS-06"],
                )
            )

        # Monolithic script check
        if len(lines) > 100 and func_count == 0:
            findings.append(
                Finding(
                    layer="quality",
                    severity="low",
                    message=f"Monolithic script: {len(lines)} lines with no function definitions",
                    nist_function="PR",
                    nist_refs=["PR.PS-06"],
                )
            )

    except SyntaxError:
        pass  # Already caught by Layer 1

    # --- Comment/docstring ratio ---
    comment_lines = sum(1 for line in lines if line.strip().startswith("#"))
    docstring_count = (
        sum(
            1
            for node in ast.walk(tree)
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)
        )
        if "tree" in dir()
        else 0
    )

    total_comment_lines = comment_lines + docstring_count * 3  # rough estimate
    ratio = total_comment_lines / max(len(lines), 1)
    summary["comment_ratio"] = round(ratio, 3)

    if ratio < 0.05 and len(lines) > 20:
        findings.append(
            Finding(
                layer="quality",
                severity="low",
                message=f"Low comment ratio: {ratio:.1%} (recommended: >5%)",
                nist_function="PR",
                nist_refs=["PR.PS-06"],
            )
        )

    return findings, summary


def _calculate_max_nesting(tree: ast.AST) -> int:
    """Calculate maximum nesting depth of control flow structures."""
    nesting_nodes = (ast.For, ast.While, ast.If, ast.With, ast.Try)

    def _depth(node: ast.AST, current: int = 0) -> int:
        max_d = current
        for child in ast.iter_child_nodes(node):
            if isinstance(child, nesting_nodes):
                max_d = max(max_d, _depth(child, current + 1))
            else:
                max_d = max(max_d, _depth(child, current))
        return max_d

    return _depth(tree)


# ---------------------------------------------------------------------------
# Layer 7: Reliability Testing
# ---------------------------------------------------------------------------

# Patterns to strip before comparing outputs for determinism
_NONDETERMINISTIC_PATTERNS = [
    r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}",  # ISO timestamps
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",  # UUIDs
    r"\d{10,13}",  # epoch timestamps (10 or 13 digits)
    r"0x[0-9a-f]{8,16}",  # memory addresses
]


def _normalize_output(text: str) -> str:
    """Strip non-deterministic content for comparison."""
    result = text
    for pattern in _NONDETERMINISTIC_PATTERNS:
        result = re.sub(pattern, "<DYNAMIC>", result)
    return result.strip()


async def _layer7_reliability(
    code: str,
    packages: list[str],
    sample_input: str | None,
) -> tuple[list[Finding], dict]:
    """Layer 7: Is output deterministic? Does it handle edge cases?"""
    findings: list[Finding] = []
    summary: dict = {
        "deterministic": None,
        "edge_cases_passed": 0,
        "edge_cases_total": 0,
        "handles_errors_gracefully": True,
    }

    test_input = sample_input or "test sample data\n1,2,3"
    pkg_list = packages or None

    # --- Determinism check: run 3x, compare outputs ---
    exec_code = _build_execution_code(code, test_input)

    try:
        results = await asyncio.gather(
            _run_in_sandbox(exec_code, packages=pkg_list),
            _run_in_sandbox(exec_code, packages=pkg_list),
            _run_in_sandbox(exec_code, packages=pkg_list),
        )

        outputs = [_normalize_output(r["stdout"]) for r in results]
        if all(o == outputs[0] for o in outputs):
            summary["deterministic"] = True
        else:
            summary["deterministic"] = False
            findings.append(
                Finding(
                    layer="reliability",
                    severity="medium",
                    message="Non-deterministic: 3 runs with identical input produced different outputs",
                    nist_function="PR",
                    nist_refs=["PR.IR-03"],
                )
            )
    except Exception as e:
        logger.warning(f"Determinism check failed: {e}")

    # --- Edge case testing ---
    edge_cases = [
        ("empty", ""),
        ("large", "A" * 10000),
        ("unicode", "Hello \U0001f30d caf\u00e9 na\u00efve \u4e16\u754c"),
        ("none_like", "None"),
    ]

    summary["edge_cases_total"] = len(edge_cases)

    async def _test_edge(name: str, input_val: str) -> Finding | None:
        edge_code = _build_execution_code(code, input_val)
        try:
            result = await _run_in_sandbox(edge_code, packages=pkg_list, timeout=15)
            if result["exit_code"] != 0:
                error = result.get("error", "") or result.get("stderr", "")
                has_traceback = "Traceback (most recent call last)" in error
                if has_traceback:
                    summary["handles_errors_gracefully"] = False
                    return Finding(
                        layer="reliability",
                        severity="medium",
                        message=f"Edge case '{name}': crashed with raw traceback (no graceful error handling)",
                        nist_function="PR",
                        nist_refs=["PR.IR-03"],
                    )
                else:
                    return Finding(
                        layer="reliability",
                        severity="low",
                        message=f"Edge case '{name}': exited with error but handled gracefully",
                        nist_function="PR",
                        nist_refs=["PR.IR-03"],
                    )
            return None  # passed
        except Exception as e:
            return Finding(
                layer="reliability",
                severity="low",
                message=f"Edge case '{name}': sandbox error: {e}",
                nist_function="PR",
                nist_refs=["PR.IR-03"],
            )

    edge_results = await asyncio.gather(*[_test_edge(name, val) for name, val in edge_cases])

    for result in edge_results:
        if result is None:
            summary["edge_cases_passed"] += 1
        else:
            findings.append(result)

    # --- Python version compatibility check ---
    compat_findings, compat_summary = _check_python_version_compatibility(code)
    findings.extend(compat_findings)
    summary["python_compatibility"] = compat_summary

    return findings, summary


# ---------------------------------------------------------------------------
# Python version compatibility checking
# ---------------------------------------------------------------------------

# Syntax features and the minimum Python version they require
_VERSION_FEATURES = [
    # (pattern_description, min_version, ast_check_fn)
    ("match/case statement", "3.10", lambda tree: any(type(n).__name__ == "Match" for n in ast.walk(tree))),
    ("except* (exception groups)", "3.11", lambda tree: any(type(n).__name__ == "TryStar" for n in ast.walk(tree))),
    ("type alias (type X = ...)", "3.12", lambda tree: any(type(n).__name__ == "TypeAlias" for n in ast.walk(tree))),
    (
        "PEP 695 generics (def f[T])",
        "3.12",
        lambda tree: any(
            hasattr(n, "type_params") and getattr(n, "type_params", None)
            for n in ast.walk(tree)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        ),
    ),
]

# Type hint features detectable via string matching (AST doesn't always capture these)
_VERSION_PATTERNS = [
    ("X | Y union type in runtime", "3.10", r":\s*\w+\s*\|\s*\w+"),  # x: int | str
    ("StrEnum", "3.11", r"\bStrEnum\b"),
    ("ExceptionGroup", "3.11", r"\bExceptionGroup\b"),
    ("override decorator", "3.12", r"@override\b"),
]

SUPPORTED_PYTHON_VERSIONS = ["3.11", "3.12", "3.13", "3.14"]


def _check_python_version_compatibility(code: str) -> tuple[list[Finding], dict]:
    """Check which Python versions the script is compatible with.

    Analyzes syntax features to determine the minimum required version,
    then reports compatibility with supported versions (3.11-3.14).
    """
    findings: list[Finding] = []
    min_version = "3.11"  # our minimum supported
    features_used: list[str] = []

    # AST-based checks
    try:
        tree = ast.parse(code)
        for desc, version, check_fn in _VERSION_FEATURES:
            try:
                if check_fn(tree):
                    features_used.append(f"{desc} (requires {version}+)")
                    if version > min_version:
                        min_version = version
            except Exception:
                logger.debug("Version feature check failed for: %s", desc)
    except SyntaxError:
        pass

    # Pattern-based checks
    for desc, version, pattern in _VERSION_PATTERNS:
        if re.search(pattern, code):
            features_used.append(f"{desc} (requires {version}+)")
            if version > min_version:
                min_version = version

    # Determine compatible versions
    compatible = [v for v in SUPPORTED_PYTHON_VERSIONS if v >= min_version]
    incompatible = [v for v in SUPPORTED_PYTHON_VERSIONS if v < min_version]

    summary = {
        "min_version": min_version,
        "compatible_versions": compatible,
        "incompatible_versions": incompatible,
        "features_detected": features_used,
    }

    if incompatible:
        findings.append(
            Finding(
                layer="reliability",
                severity="low",
                message=f"Requires Python {min_version}+. Incompatible with: {', '.join(incompatible)}. Features: {', '.join(features_used[:3])}",
                nist_function="PR",
                nist_refs=["PR.IR-03"],
            )
        )

    return findings, summary


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


async def run_quality_layers(
    code: str,
    packages: list[str],
    description: str = "",
    input_schema: str = "",
    sample_input: str | None = None,
    expected_output: str | None = None,
    test_code: str | None = None,
    skip_functionality: bool = False,
    skip_quality: bool = False,
    skip_reliability: bool = False,
    on_layer_progress: Callable[[int, str], None] | None = None,
) -> tuple[list[Finding], dict, dict, dict]:
    """Run Layers 5-7: Functionality, Quality, Reliability.

    Auto-generates test inputs via LLM if the creator didn't provide them.

    Args:
        on_layer_progress: Optional callback(layer_index, status) called before/after each layer.
            layer_index: 4=functionality, 5=quality, 6=reliability
            status: "running" | "complete"

    Returns: (all_findings, functionality_summary, quality_summary, reliability_summary)
    """
    all_findings: list[Finding] = []
    func_summary: dict = {}
    qual_summary: dict = {}
    rel_summary: dict = {}

    def _notify(layer: int, status: str) -> None:
        if on_layer_progress:
            on_layer_progress(layer, status)

    # Auto-generate test inputs if not provided
    expected_patterns: list[str] | None = None
    if not sample_input and not skip_functionality:
        logger.info("No sample_input provided — generating via LLM")
        generated_input, expected_patterns, _edge_cases = await _generate_test_inputs(code, description, input_schema)
        sample_input = generated_input
        logger.info(f"Generated sample_input: {sample_input[:100]}...")

    # Layer 5: Functionality
    if not skip_functionality:
        _notify(4, "running")
        layer5_findings, func_summary = await _layer5_functionality(
            code,
            packages,
            sample_input,
            expected_output,
            expected_patterns,
            test_code,
        )
        all_findings.extend(layer5_findings)
        _notify(4, "complete")
    else:
        _notify(4, "skipped")

    # Layer 6: Quality
    if not skip_quality:
        _notify(5, "running")
        layer6_findings, qual_summary = await _layer6_quality(code, packages)
        all_findings.extend(layer6_findings)
        _notify(5, "complete")
    else:
        _notify(5, "skipped")

    # Layer 7: Reliability
    if not skip_reliability:
        _notify(6, "running")
        layer7_findings, rel_summary = await _layer7_reliability(code, packages, sample_input)
        all_findings.extend(layer7_findings)
        _notify(6, "complete")
    else:
        _notify(6, "skipped")

    return all_findings, func_summary, qual_summary, rel_summary
