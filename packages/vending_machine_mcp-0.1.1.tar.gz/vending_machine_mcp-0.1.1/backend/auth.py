"""
Auth middleware for FastAPI — validates Supabase JWT tokens and API keys.

Supports two auth modes:
  1. Supabase JWT (frontend web app) — Bearer token in Authorization header
  2. API key (MCP clients, CLI) — X-API-Key header, validated against hashed keys in DB

When Supabase is not configured, auth is disabled (local dev mode).
"""

from __future__ import annotations

import hashlib
import logging
import secrets
from typing import Any

from fastapi import Header, HTTPException

logger = logging.getLogger("auth")


def _get_sb():
    from supabase_client import get_sb

    return get_sb()


def _hash_key(key: str) -> str:
    """Hash an API key with SHA-256 for storage."""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


async def get_current_user(
    authorization: str | None = Header(None),
    x_api_key: str | None = Header(None),
) -> dict[str, Any] | None:
    """Extract and validate user identity from request headers.

    Returns user dict with at least {"id": "...", "source": "jwt"|"api_key"|"anonymous"}.
    Returns None when auth is disabled (no Supabase configured).
    """
    sb = _get_sb()

    # If Supabase not configured, auth is disabled (local dev)
    if not sb:
        return {"id": "anonymous", "email": "anonymous", "source": "anonymous"}

    # Try JWT first (frontend)
    if authorization and authorization.startswith("Bearer "):
        token = authorization.split(" ", 1)[1]
        try:
            user_response = sb.auth.get_user(token)
            if user_response and user_response.user:
                return {
                    "id": str(user_response.user.id),
                    "email": user_response.user.email or "",
                    "source": "jwt",
                }
        except Exception as e:
            logger.debug("JWT validation failed: %s", e)
            raise HTTPException(status_code=401, detail="Invalid or expired token") from None

    # Try API key (MCP clients, CLI)
    if x_api_key:
        return await _validate_api_key(x_api_key, sb)

    # No auth provided — anonymous
    return {"id": "anonymous", "email": "anonymous", "source": "anonymous"}


async def _validate_api_key(key: str, sb) -> dict[str, Any]:
    """Validate an API key against hashed values in the database."""
    key_hash = _hash_key(key)

    try:
        result = (
            sb.table("api_keys")
            .select("id, user_id, name")
            .eq("key_hash", key_hash)
            .eq("revoked", False)
            .single()
            .execute()
        )

        if result.data:
            user_id = result.data["user_id"]

            # Update last_used_at (fire-and-forget, don't block auth)
            try:
                import time

                sb.table("api_keys").update({"last_used_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}).eq(
                    "id", result.data["id"]
                ).execute()
            except Exception as e:
                logger.debug("Non-critical auth operation failed: %s", e)

            # Get user email from auth
            email = ""
            try:
                user_resp = sb.auth.admin.get_user_by_id(user_id)
                if user_resp and user_resp.user:
                    email = user_resp.user.email or ""
            except Exception as e:
                logger.debug("Non-critical auth operation failed: %s", e)

            return {
                "id": user_id,
                "email": email,
                "source": "api_key",
                "key_name": result.data.get("name", ""),
            }

    except Exception as e:
        logger.debug("API key validation failed: %s", e)

    raise HTTPException(status_code=401, detail="Invalid API key")


async def require_auth(
    authorization: str | None = Header(None),
    x_api_key: str | None = Header(None),
) -> dict[str, Any]:
    """Like get_current_user but raises 401 if not authenticated."""
    user = await get_current_user(authorization, x_api_key)
    if not user or user["source"] == "anonymous":
        sb = _get_sb()
        if sb:
            raise HTTPException(status_code=401, detail="Authentication required")
    return user or {"id": "anonymous", "email": "anonymous", "source": "anonymous"}


# ─── API Key Management ──────────────────────────────────────────────────


def create_api_key(user_id: str, name: str = "default") -> dict[str, str] | None:
    """Create a new API key for a user.

    Returns {"key": "vm_...", "key_id": "uuid", "name": "..."} — plaintext key returned ONCE.
    """
    sb = _get_sb()
    if not sb:
        return None

    # Generate key: vm_ prefix + 40 random chars
    raw_key = f"vm_{secrets.token_urlsafe(30)}"
    key_hash = _hash_key(raw_key)

    try:
        result = sb.table("api_keys").insert({"user_id": user_id, "key_hash": key_hash, "name": name}).execute()
        if result.data:
            logger.info("API key created for user %s: %s", user_id, name)
            return {
                "key": raw_key,  # Only time plaintext is available
                "key_id": result.data[0]["id"],
                "name": name,
            }
    except Exception as e:
        logger.warning("Failed to create API key: %s", e)

    return None


def list_api_keys(user_id: str) -> list[dict[str, Any]]:
    """List API keys for a user (masked, no plaintext)."""
    sb = _get_sb()
    if not sb:
        return []

    try:
        result = (
            sb.table("api_keys")
            .select("id, name, created_at, last_used_at, revoked")
            .eq("user_id", user_id)
            .order("created_at", desc=True)
            .execute()
        )
        return result.data or []
    except Exception as e:
        logger.warning("Failed to list API keys: %s", e)
        return []


def revoke_api_key(user_id: str, key_id: str) -> bool:
    """Revoke an API key. Returns True if successful."""
    sb = _get_sb()
    if not sb:
        return False

    try:
        result = sb.table("api_keys").update({"revoked": True}).eq("id", key_id).eq("user_id", user_id).execute()
        if result.data:
            logger.info("API key revoked: %s for user %s", key_id, user_id)
            return True
    except Exception as e:
        logger.warning("Failed to revoke API key: %s", e)

    return False
