"""
Audit trail — append-only log of significant actions.

Every mutation (job creation, script submission, approval, cancellation)
gets recorded with who did it, what they did, and when.

Usage:
    from audit import log_action

    log_action(
        tenant_id="user-123",
        action="job.create",
        resource_type="job",
        resource_id="job-456",
        metadata={"agent": "bug-hunter", "task": "audit my code"},
        request_id="req-789",
    )
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("audit")


def _get_sb():
    from supabase_client import get_sb

    return get_sb()


def log_action(
    tenant_id: str,
    action: str,
    resource_type: str,
    resource_id: str | None = None,
    metadata: dict[str, Any] | None = None,
    request_id: str | None = None,
) -> None:
    """Record an action in the audit log.

    Actions: job.create, job.cancel, script.submit, script.approve,
    script.reject, dev_agent.task, auth.login, auth.key_create
    """
    sb = _get_sb()
    if not sb:
        # Log locally when Supabase unavailable
        logger.info(
            "AUDIT [%s] %s %s/%s %s",
            tenant_id,
            action,
            resource_type,
            resource_id or "-",
            metadata or {},
        )
        return

    row = {
        "tenant_id": tenant_id,
        "action": action,
        "resource_type": resource_type,
        "resource_id": resource_id,
        "metadata": metadata or {},
        "request_id": request_id or "",
    }

    try:
        sb.table("audit_log").insert(row).execute()
    except Exception as e:
        # Never fail the request because audit logging failed
        logger.warning("Audit log insert failed: %s", e)


def get_audit_log(
    tenant_id: str | None = None,
    resource_type: str | None = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Query the audit log with optional filters."""
    sb = _get_sb()
    if not sb:
        return []

    try:
        query = sb.table("audit_log").select("*").order("created_at", desc=True).limit(limit)
        if tenant_id:
            query = query.eq("tenant_id", tenant_id)
        if resource_type:
            query = query.eq("resource_type", resource_type)
        result = query.execute()
        return result.data or []
    except Exception as e:
        logger.warning("Audit log query failed: %s", e)
        return []
