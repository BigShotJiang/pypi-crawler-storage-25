"""
Production middleware — request IDs, structured logging, rate limiting, idempotency.

Provides the infrastructure hardening layer between incoming requests
and the application logic. Every request gets a unique ID, JSON-structured
logs, rate limit enforcement, and optional idempotency caching.
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid

from fastapi import Request, Response  # noqa: TC002
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("middleware")

_START_TIME = time.time()


# ─── Request ID Middleware ────────────────────────────────────────────────


# Strict validation for client-supplied request IDs (HIGH-001 fix)
import re  # noqa: E402 — needed here, after fastapi imports

_SAFE_REQUEST_ID = re.compile(r"^[A-Za-z0-9._\-]{8,128}$")


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Assigns a unique request_id to every request and adds it to the response."""

    async def dispatch(self, request: Request, call_next):
        client_id = request.headers.get("X-Request-ID", "")
        request_id = client_id if client_id and _SAFE_REQUEST_ID.match(client_id) else str(uuid.uuid4())
        request.state.request_id = request_id

        start = time.monotonic()
        response: Response = await call_next(request)
        duration_ms = round((time.monotonic() - start) * 1000, 2)

        response.headers["X-Request-ID"] = request_id

        # Structured access log
        _log_request(request, response, request_id, duration_ms)

        return response


def _log_request(request: Request, response: Response, request_id: str, duration_ms: float) -> None:
    """Emit a structured JSON access log line."""
    # Skip noisy health checks
    if request.url.path == "/health":
        return

    log_data = {
        "type": "access",
        "request_id": request_id,
        "method": request.method,
        "path": request.url.path,
        "status": response.status_code,
        "duration_ms": duration_ms,
        "client_ip": request.client.host if request.client else "unknown",
    }

    level = logging.WARNING if response.status_code >= 400 else logging.INFO
    logger.log(level, json.dumps(log_data))


# ─── Upstash Redis Client ────────────────────────────────────────────────


_redis = None


def get_redis():
    """Get or create the Upstash Redis client."""
    global _redis
    if _redis is not None:
        return _redis

    url = os.environ.get("UPSTASH_REDIS_REST_URL", "")
    token = os.environ.get("UPSTASH_REDIS_REST_TOKEN", "")
    if not url or not token:
        return None

    try:
        from upstash_redis import Redis

        _redis = Redis(url=url, token=token)
        logger.info("Upstash Redis connected")
        return _redis
    except Exception as e:
        logger.warning("Upstash Redis unavailable: %s", e)
        return None


# ─── Rate Limiting ────────────────────────────────────────────────────────

# Default limits per window
_DEFAULT_RATE = 60  # requests per minute
_RATE_WINDOW = 60  # seconds

# Per-endpoint overrides (path prefix → requests per window)
_ENDPOINT_LIMITS: dict[str, tuple[int, int]] = {
    "/api/scripts/validate-stream": (5, 3600),  # 5 per hour
    "/api/dev-agent/task": (3, 3600),  # 3 per hour
    "/api/scripts": (120, 60),  # 120 per minute (read-heavy)
}


def _get_rate_limit_key(request: Request) -> str:
    """Build a rate limit key from the request."""
    # Use tenant ID if authenticated, otherwise IP
    tenant = getattr(request.state, "tenant_id", None)
    if tenant and tenant != "anonymous":
        identifier = f"tenant:{tenant}"
    else:
        identifier = f"ip:{request.client.host}" if request.client else "ip:unknown"

    return f"rl:{identifier}:{request.url.path}"


async def check_rate_limit(request: Request) -> tuple[bool, dict]:
    """Check if the request exceeds rate limits.

    Returns: (allowed, headers_dict)
    """
    redis = get_redis()
    if not redis:
        # No Redis → no rate limiting (graceful degradation)
        return True, {}

    # Find applicable limit
    limit, window = _DEFAULT_RATE, _RATE_WINDOW
    for prefix, (ep_limit, ep_window) in _ENDPOINT_LIMITS.items():
        if request.url.path.startswith(prefix) and request.method == "POST":
            limit, window = ep_limit, ep_window
            break

    key = _get_rate_limit_key(request)

    try:
        current = redis.incr(key)
        if current == 1:
            redis.expire(key, window)

        ttl = redis.ttl(key)

        headers = {
            "X-RateLimit-Limit": str(limit),
            "X-RateLimit-Remaining": str(max(0, limit - current)),
            "X-RateLimit-Reset": str(int(time.time()) + (ttl if ttl > 0 else window)),
        }

        if current > limit:
            headers["Retry-After"] = str(ttl if ttl > 0 else window)
            return False, headers

        return True, headers

    except Exception as e:
        logger.warning("Rate limit check failed: %s", e)
        return True, {}  # Fail open


# ─── Idempotency ─────────────────────────────────────────────────────────

_IDEMPOTENCY_TTL = 86400  # 24 hours


async def check_idempotency(request: Request) -> dict | None:
    """Check if this request has a cached idempotent response.

    Returns cached response dict if found, None otherwise.
    """
    key_header = request.headers.get("Idempotency-Key")
    if not key_header or request.method != "POST":
        return None

    redis = get_redis()
    if not redis:
        return None

    # Scope by tenant to prevent cross-tenant replay (MEDIUM-003 fix)
    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    cache_key = f"idemp:{tenant_id}:{key_header}"

    try:
        cached = redis.get(cache_key)
        if cached:
            return json.loads(cached)
    except Exception as e:
        logger.debug("Idempotency check failed: %s", e)

    return None


def store_idempotent_response(request: Request, response_body: dict) -> None:
    """Cache a response for idempotent replay."""
    key_header = request.headers.get("Idempotency-Key")
    if not key_header or request.method != "POST":
        return

    redis = get_redis()
    if not redis:
        return

    # Scope by tenant (MEDIUM-003 fix)
    tenant_id = getattr(request.state, "tenant_id", "anonymous")
    cache_key = f"idemp:{tenant_id}:{key_header}"

    try:
        redis.set(cache_key, json.dumps(response_body), ex=_IDEMPOTENCY_TTL)
    except Exception as e:
        logger.debug("Idempotency store failed: %s", e)


# ─── Metrics Tracking ─────────────────────────────────────────────────────

# Simple in-process counters (no external dependency)
_metrics: dict[str, int | float] = {
    "requests_total": 0,
    "requests_4xx": 0,
    "requests_5xx": 0,
    "jobs_created": 0,
    "jobs_completed": 0,
    "jobs_failed": 0,
    "tokens_used": 0,
}


def inc_metric(name: str, amount: int | float = 1) -> None:
    """Increment a metric counter."""
    _metrics[name] = _metrics.get(name, 0) + amount


def get_metrics() -> dict:
    """Get all metrics + computed values."""
    uptime = time.time() - _START_TIME
    total = _metrics.get("requests_total", 0)
    errors = _metrics.get("requests_4xx", 0) + _metrics.get("requests_5xx", 0)
    error_rate = round(errors / max(total, 1), 4)

    return {
        **_metrics,
        "uptime_seconds": round(uptime, 1),
        "error_rate": error_rate,
    }


def get_uptime() -> float:
    """Get server uptime in seconds."""
    return round(time.time() - _START_TIME, 1)
