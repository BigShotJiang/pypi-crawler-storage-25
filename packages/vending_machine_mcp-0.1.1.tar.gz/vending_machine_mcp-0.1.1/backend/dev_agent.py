"""
Dev Agent — multi-agent coding in persistent Daytona sandboxes.

Supports multiple coding agents (Claude Code, OpenAI Codex) running
in isolated cloud environments. Each agent clones the user's repo,
works autonomously, and creates PRs.

Usage:
    from dev_agent import DevAgent

    agent = DevAgent(repo="YokiiDesu/Vending-Machine", agent="claude")
    agent.setup()
    result = agent.run_task("Fix the React key warning", branch="fix/keys")
    print(result["pr_url"])

    agent = DevAgent(repo="YokiiDesu/Vending-Machine", agent="codex")
    agent.setup()
    result = agent.run_task("Optimize database queries", branch="perf/db")
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Literal

logger = logging.getLogger("dev_agent")

AgentType = Literal["claude", "codex"]

# ─── Agent Configurations ────────────────────────────────────────────────

AGENT_CONFIGS: dict[str, dict] = {
    "claude": {
        "name": "Claude Code",
        "install_cmd": "(which claude && echo 'already installed') || npm install -g @anthropic-ai/claude-code 2>&1 | tail -3",
        "version_cmd": "claude --version 2>&1",
        "api_key_env": "ANTHROPIC_API_KEY",
        "run_template": "cd /home/daytona/repo && claude --print --dangerously-skip-permissions '{task}'",
        "co_author": "Co-Authored-By: Claude Opus 4.6 (1M context) <noreply@anthropic.com>",
    },
    "codex": {
        "name": "OpenAI Codex",
        "install_cmd": "(which codex && echo 'already installed') || npm install -g @openai/codex 2>&1 | tail -3",
        "version_cmd": "codex --version 2>&1",
        "api_key_env": "OPENAI_API_KEY",
        "run_template": "cd /home/daytona/repo && codex exec --full-auto '{task}' 2>&1",
        "co_author": "Co-Authored-By: OpenAI Codex <noreply@openai.com>",
    },
}


def _read_dotenv_key(key: str) -> str:
    """Read a key from .env file directly, bypassing os.environ overrides."""
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    try:
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith(f"{key}=") and not line.startswith("#"):
                    return line.split("=", 1)[1].strip()
    except FileNotFoundError:
        pass
    return os.environ.get(key, "")


# ─── DevAgent Class ──────────────────────────────────────────────────────


class DevAgent:
    """A persistent dev agent that runs coding CLIs in a Daytona sandbox."""

    def __init__(
        self,
        repo: str,
        agent: AgentType = "claude",
        github_token: str | None = None,
        api_key: str | None = None,
        sandbox_id: str | None = None,
    ):
        if agent not in AGENT_CONFIGS:
            msg = f"Unknown agent: {agent}. Available: {list(AGENT_CONFIGS.keys())}"
            raise ValueError(msg)

        self.repo = repo
        self.agent = agent
        self.config = AGENT_CONFIGS[agent]
        self.github_token = github_token or _read_dotenv_key("GITHUB_TOKEN")
        self.api_key = api_key or _read_dotenv_key(self.config["api_key_env"])
        self.sandbox_id = sandbox_id
        self._daytona = None
        self._sandbox = None

    def _get_daytona(self):
        if not self._daytona:
            from daytona import Daytona

            self._daytona = Daytona()
        return self._daytona

    def _get_sandbox(self):
        """Get or create the persistent sandbox."""
        if self._sandbox:
            return self._sandbox

        d = self._get_daytona()

        # Resume existing sandbox
        if self.sandbox_id:
            try:
                self._sandbox = d.get(self.sandbox_id)
                logger.info("Resumed sandbox: %s", self.sandbox_id)
                return self._sandbox
            except Exception:
                logger.warning("Failed to resume sandbox %s, creating new", self.sandbox_id)

        # Create new persistent sandbox with the agent's API key
        from daytona import CreateSandboxBaseParams

        self._sandbox = d.create(
            CreateSandboxBaseParams(
                language="python",
                env_vars={
                    self.config["api_key_env"]: self.api_key,
                    "GITHUB_TOKEN": self.github_token,
                    "GH_TOKEN": self.github_token,
                    "OPENROUTER_API_KEY": os.environ.get("OPENROUTER_API_KEY", ""),
                },
                ephemeral=False,
            )
        )
        self.sandbox_id = self._sandbox.id
        logger.info("Created %s sandbox: %s", self.config["name"], self.sandbox_id)
        return self._sandbox

    def setup(self) -> dict:
        """Set up sandbox: install agent CLI, gh CLI, clone repo.

        Returns: {"sandbox_id": str, "status": str, "agent": str, "details": dict}
        """
        sbx = self._get_sandbox()
        results = {}

        # Install gh CLI (retry up to 2 times — network can be slow in sandbox)
        logger.info("Installing gh CLI...")
        gh_cmd = (
            "(which gh || (PATH=$HOME/.local/bin:$PATH which gh)) && echo 'gh already installed' || "
            "(mkdir -p $HOME/.local/bin "
            "&& GH_VER=$(curl -sI https://github.com/cli/cli/releases/latest "
            "| grep -i location | sed 's|.*/tag/v||' | tr -d '\\r') "
            "&& curl -fsSL https://github.com/cli/cli/releases/download/v${GH_VER}/gh_${GH_VER}_linux_amd64.tar.gz "
            "| tar -xz -C /tmp "
            "&& cp /tmp/gh_${GH_VER}_linux_amd64/bin/gh $HOME/.local/bin/gh "
            "&& echo 'gh installed')"
        )
        for attempt in range(2):
            r = sbx.process.exec(gh_cmd, timeout=180)
            if r.exit_code == 0:
                break
            logger.warning("gh install attempt %d failed: %s", attempt + 1, r.result[:200])
        results["gh_install"] = r.result.strip()

        # Install the coding agent CLI (retry up to 2 times)
        logger.info("Installing %s...", self.config["name"])
        for attempt in range(2):
            r = sbx.process.exec(self.config["install_cmd"], timeout=240)
            if r.exit_code == 0:
                break
            logger.warning("Agent install attempt %d failed: %s", attempt + 1, r.result[:200])
        results["agent_install"] = r.result.strip()

        # Configure git
        logger.info("Configuring git...")
        sbx.process.exec('git config --global user.name "Dev Agent"', timeout=5)
        sbx.process.exec('git config --global user.email "dev-agent@vending-machine.dev"', timeout=5)
        sbx.process.exec("git config --global credential.helper store", timeout=5)
        sbx.process.exec(
            f"echo 'https://x-access-token:{self.github_token}@github.com' > ~/.git-credentials",
            timeout=5,
        )

        # Clone repo
        logger.info("Cloning %s...", self.repo)
        repo_url = f"https://github.com/{self.repo}.git"
        r = sbx.process.exec(
            f"if [ -d /home/daytona/repo ]; then "
            f"cd /home/daytona/repo && git fetch --all && git checkout main && git pull; "
            f"else GIT_TERMINAL_PROMPT=0 git clone {repo_url} /home/daytona/repo; fi",
            timeout=180,
        )
        results["clone"] = r.result.strip()

        # Verify
        r = sbx.process.exec(
            f"{self.config['version_cmd']} && "
            f"(PATH=$HOME/.local/bin:$PATH gh --version 2>/dev/null | head -1 || echo 'gh: not installed') && "
            f"cd /home/daytona/repo && git log --oneline -3",
            timeout=15,
        )
        results["verify"] = r.result.strip()

        return {
            "sandbox_id": self.sandbox_id,
            "status": "ready",
            "agent": self.agent,
            "agent_name": self.config["name"],
            "details": results,
        }

    def run_task(
        self,
        task: str,
        branch: str | None = None,
        create_pr: bool = True,
        base_branch: str = "main",
    ) -> dict:
        """Run a task using the configured coding agent.

        Args:
            task: Natural language task description
            branch: Git branch name (auto-generated if not provided)
            create_pr: Whether to create a PR after completion
            base_branch: Branch to base the work on

        Returns:
            {"status": str, "output": str, "branch": str, "pr_url": str | None, "agent": str}
        """
        sbx = self._get_sandbox()

        if not branch:
            slug = task.lower()[:30].replace(" ", "-").replace("/", "-")
            slug = "".join(c for c in slug if c.isalnum() or c == "-")
            branch = f"dev-agent/{self.agent}/{slug}-{int(time.time()) % 10000}"

        # Sync with remote and create branch
        logger.info("[%s] Creating branch: %s", self.agent, branch)
        r = sbx.process.exec(
            f"cd /home/daytona/repo && git fetch origin "
            f"&& git checkout {base_branch} && git pull origin {base_branch} "
            f"&& git checkout -b {branch}",
            timeout=30,
        )
        if r.exit_code != 0:
            return _task_error(f"Git branch setup failed: {r.result}", branch, self.agent)

        # Build and run the agent command
        logger.info("[%s] Running task: %s", self.agent, task[:80])
        escaped_task = task.replace("'", "'\\''")
        agent_cmd = self.config["run_template"].replace("{task}", escaped_task)
        r = sbx.process.exec(agent_cmd, timeout=1800)
        agent_output = r.result or ""

        if r.exit_code != 0 and not agent_output.strip():
            return _task_error(f"Agent execution failed: {agent_output}", branch, self.agent)

        # Check for changes
        r = sbx.process.exec("cd /home/daytona/repo && git status --porcelain", timeout=10)
        if not r.result.strip():
            return {
                "status": "no_changes",
                "output": agent_output,
                "branch": branch,
                "pr_url": None,
                "agent": self.agent,
            }

        # Commit
        logger.info("[%s] Committing changes...", self.agent)
        sbx.process.exec("cd /home/daytona/repo && git add -A", timeout=10)
        short_task = task[:72].replace("'", "")
        commit_msg = (
            f"feat: {short_task}\n\n"
            f"Autonomous change by {self.config['name']} in Daytona sandbox.\n\n"
            f"{self.config['co_author']}"
        )
        sbx.process.exec(
            f"cat > /tmp/commit_msg.txt << 'COMMITMSG'\n{commit_msg}\nCOMMITMSG",
            timeout=5,
        )
        r = sbx.process.exec("cd /home/daytona/repo && git commit -F /tmp/commit_msg.txt", timeout=15)
        if r.exit_code != 0:
            return _task_error(f"Commit failed: {r.result}", branch, self.agent)

        # Push
        logger.info("[%s] Pushing branch...", self.agent)
        r = sbx.process.exec(f"cd /home/daytona/repo && git push -u origin {branch}", timeout=30)
        if r.exit_code != 0:
            return _task_error(f"Push failed: {r.result}", branch, self.agent)

        # Create PR
        pr_url = None
        if create_pr:
            pr_url = self._create_pr(sbx, task, agent_output, branch, base_branch)

        return {
            "status": "complete",
            "output": agent_output,
            "branch": branch,
            "pr_url": pr_url,
            "agent": self.agent,
        }

    def _create_pr(self, sbx, task: str, output: str, branch: str, base_branch: str) -> str | None:
        """Create a pull request from the sandbox."""
        logger.info("[%s] Creating PR...", self.agent)
        pr_title = task[:70].replace("'", "")
        output_preview = output[:500].replace("'", "")
        pr_body = (
            f"## Summary\n{task}\n\n"
            f"## Agent: {self.config['name']}\n"
            f"## Agent Output\n```\n{output_preview}\n```\n\n"
            f"Autonomous PR by **{self.config['name']}** in Daytona sandbox `{self.sandbox_id}`.\n\n"
            f"Generated with [{self.config['name']}] via Vending Machine Dev Agent"
        )
        sbx.process.exec(
            f"cat > /tmp/pr_body.txt << 'PRBODY'\n{pr_body}\nPRBODY",
            timeout=5,
        )
        r = sbx.process.exec(
            f"cd /home/daytona/repo && PATH=$HOME/.local/bin:$PATH "
            f"gh pr create --title '{pr_title}' --body-file /tmp/pr_body.txt --base {base_branch}",
            timeout=30,
        )
        if r.exit_code == 0:
            url = r.result.strip()
            logger.info("[%s] PR created: %s", self.agent, url)
            return url
        logger.warning("[%s] PR creation failed: %s", self.agent, r.result)
        return None

    def stop(self) -> None:
        """Stop the sandbox (preserves state for later resume)."""
        if self._sandbox:
            try:
                self._sandbox.stop()
                logger.info("Sandbox %s stopped", self.sandbox_id)
            except Exception as e:
                logger.warning("Failed to stop sandbox: %s", e)

    def get_status(self) -> dict:
        """Get sandbox status and recent git log."""
        sbx = self._get_sandbox()
        r = sbx.process.exec(
            "cd /home/daytona/repo && git branch --show-current && echo '---' "
            "&& git log --oneline -5 && echo '---' && git status --short",
            timeout=10,
        )
        return {
            "sandbox_id": self.sandbox_id,
            "agent": self.agent,
            "agent_name": self.config["name"],
            "info": r.result,
        }


def _task_error(message: str, branch: str, agent: str) -> dict:
    """Build a standardized error response."""
    return {
        "status": "error",
        "output": message,
        "branch": branch,
        "pr_url": None,
        "agent": agent,
    }


# ─── Async wrapper for API endpoints ─────────────────────────────────────


async def run_dev_task_async(
    repo: str,
    task: str,
    agent: AgentType = "claude",
    branch: str | None = None,
    github_token: str | None = None,
    api_key: str | None = None,
    sandbox_id: str | None = None,
) -> dict:
    """Run a dev agent task asynchronously (for use in FastAPI background tasks)."""
    dev = DevAgent(
        repo=repo,
        agent=agent,
        github_token=github_token,
        api_key=api_key,
        sandbox_id=sandbox_id,
    )

    loop = asyncio.get_event_loop()

    # Setup in thread (blocking Daytona calls)
    setup_result = await loop.run_in_executor(None, dev.setup)
    if setup_result["status"] != "ready":
        return {"status": "setup_failed", **setup_result}

    # Run task in thread
    result = await loop.run_in_executor(None, lambda: dev.run_task(task, branch=branch))

    # Keep sandbox alive for future tasks
    return {**result, "sandbox_id": dev.sandbox_id}
