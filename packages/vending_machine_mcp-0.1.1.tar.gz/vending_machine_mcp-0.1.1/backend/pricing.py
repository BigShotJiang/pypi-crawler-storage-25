"""
Model pricing — fetches from OpenRouter + hardcoded fallbacks.

Caches pricing in memory, refreshes every 12 hours.
OpenRouter endpoint: GET https://openrouter.ai/api/v1/models (no auth needed)
"""

import logging
import time
from typing import TypedDict

import httpx

logger = logging.getLogger("pricing")

OPENROUTER_MODELS_URL = "https://openrouter.ai/api/v1/models"
FETCH_INTERVAL = 12 * 3600  # 12 hours


class ModelPricing(TypedDict):
    prompt: float  # cost per token (input)
    completion: float  # cost per token (output)


# In-memory cache
PRICE_CACHE: dict[str, ModelPricing] = {}
LAST_FETCH: float = 0

# Hardcoded fallbacks for models not on OpenRouter (direct API)
# and as safety net if fetch fails
FALLBACK_PRICES: dict[str, ModelPricing] = {
    # OpenRouter models (approximate, updated 2026-04)
    "openai/gpt-5.3-codex": {"prompt": 0.00000175, "completion": 0.000014},
    "anthropic/claude-sonnet-4.6": {"prompt": 0.000003, "completion": 0.000015},
    "anthropic/claude-opus-4.6": {"prompt": 0.000005, "completion": 0.000025},
    "google/gemini-3-flash-preview": {"prompt": 0.0000005, "completion": 0.000003},
    "minimax/minimax-m2.7": {"prompt": 0.0000003, "completion": 0.0000012},
    "xiaomi/mimo-v2-pro": {"prompt": 0.000001, "completion": 0.000003},
    # Direct OpenAI models (not on OpenRouter)
    "o4-mini-deep-research": {"prompt": 0.0000025, "completion": 0.00001},
    "gpt-5.4-mini": {"prompt": 0.0000003, "completion": 0.0000012},
    # Anthropic direct (CEO Agent SDK) — approximate
    "claude-sonnet-4-6": {"prompt": 0.000003, "completion": 0.000015},
}


async def refresh_prices() -> None:
    """Fetch current pricing from OpenRouter and update the cache."""
    global LAST_FETCH

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(OPENROUTER_MODELS_URL)
            resp.raise_for_status()
            data = resp.json()

        models = data.get("data", [])
        count = 0
        for m in models:
            model_id = m.get("id", "")
            pricing = m.get("pricing", {})
            prompt_price = pricing.get("prompt")
            completion_price = pricing.get("completion")

            if model_id and prompt_price is not None and completion_price is not None:
                PRICE_CACHE[model_id] = {
                    "prompt": float(prompt_price),
                    "completion": float(completion_price),
                }
                count += 1

        LAST_FETCH = time.time()
        logger.info(f"Pricing cache refreshed: {count} models loaded")

    except Exception as e:
        logger.warning(f"Failed to fetch pricing from OpenRouter: {e}. Using fallbacks.")
        # Load fallbacks if cache is empty
        if not PRICE_CACHE:
            PRICE_CACHE.update(FALLBACK_PRICES)
            LAST_FETCH = time.time()


async def ensure_prices_loaded() -> None:
    """Load prices if not loaded or stale."""
    if time.time() - LAST_FETCH > FETCH_INTERVAL:
        await refresh_prices()


def get_model_pricing(model_id: str) -> ModelPricing:
    """Get pricing for a model. Returns fallback if not in cache."""
    if model_id in PRICE_CACHE:
        return PRICE_CACHE[model_id]
    if model_id in FALLBACK_PRICES:
        return FALLBACK_PRICES[model_id]
    # Unknown model — return zero pricing (free/unknown)
    return {"prompt": 0.0, "completion": 0.0}


def calculate_cost(model_id: str, input_tokens: int, output_tokens: int) -> float:
    """Calculate the USD cost for a model invocation."""
    pricing = get_model_pricing(model_id)
    return (input_tokens * pricing["prompt"]) + (output_tokens * pricing["completion"])


def format_cost(cost: float) -> str:
    """Format a cost as a human-readable string."""
    if cost < 0.001:
        return f"${cost:.6f}"
    elif cost < 0.01:
        return f"${cost:.4f}"
    elif cost < 1.0:
        return f"${cost:.3f}"
    else:
        return f"${cost:.2f}"
