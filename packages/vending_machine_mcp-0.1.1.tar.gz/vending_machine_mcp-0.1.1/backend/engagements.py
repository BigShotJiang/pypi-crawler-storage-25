"""
White-glove engagement pipeline — ties client, scope, agent pipeline,
human review, and branded report into a single trackable unit.

Packages:
    Shield     — Security audit (Bug Hunter → Test Goblin → Code Gremlin → PDF Forge)
    Blueprint  — AWS architecture review (Cloud Sensei → DevOps Dwarf → PDF Forge)
    LaunchPad  — Production readiness (all agents → PDF Forge)

Lifecycle:
    intake → running → [review (premium)] → delivered
                     ↘ error
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from enum import StrEnum
from typing import Any, TypedDict

logger = logging.getLogger("engagements")


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


class EngagementStatus(StrEnum):
    intake = "intake"
    running = "running"
    review = "review"
    delivered = "delivered"
    error = "error"


TERMINAL_STATES = {EngagementStatus.delivered, EngagementStatus.error}

VALID_PACKAGES = {"shield", "blueprint", "launchpad"}
VALID_TIERS = {"self-serve", "premium"}
VALID_DEPTHS = {"scan", "autonomous"}

# Agent pipeline per package (order matters — PDF Forge is always last)
PACKAGE_AGENTS: dict[str, list[str]] = {
    "shield": ["bug-hunter", "test-goblin", "code-gremlin", "pdf-forge"],
    "blueprint": ["cloud-sensei", "devops-dwarf", "pdf-forge"],
    "launchpad": [
        "bug-hunter",
        "cloud-sensei",
        "devops-dwarf",
        "test-goblin",
        "code-gremlin",
        "pdf-forge",
    ],
}


class Engagement(TypedDict):
    id: str
    user_id: str
    package: str  # "shield" | "blueprint" | "launchpad"
    tier: str  # "self-serve" | "premium"
    depth: str  # "scan" | "autonomous"
    status: EngagementStatus
    repo_url: str
    scope_notes: str
    job_ids: list[str]
    current_step: int
    report_path: str | None
    output: str  # autonomous mode: Claude Code output; scan mode: empty
    findings_summary: dict | None
    reviewer_id: str | None
    reviewer_notes: str | None
    total_cost: float
    total_runtime_ms: int
    created_at: float
    started_at: float | None
    completed_at: float | None
    delivered_at: float | None


# ---------------------------------------------------------------------------
# In-memory store (hot cache, Supabase write-through)
# ---------------------------------------------------------------------------

ENGAGEMENT_STORE: dict[str, Engagement] = {}


def _get_sb():
    try:
        from supabase_client import get_supabase

        return get_supabase()
    except Exception:
        return None


def _write_to_db(engagement: Engagement) -> None:
    """Write-through to Supabase (best-effort)."""
    sb = _get_sb()
    if not sb:
        return
    try:
        from datetime import UTC, datetime

        row = {
            "id": engagement["id"],
            "user_id": engagement["user_id"],
            "package": engagement["package"],
            "tier": engagement["tier"],
            "depth": engagement.get("depth", "scan"),
            "status": engagement["status"],
            "repo_url": engagement["repo_url"],
            "scope_notes": engagement["scope_notes"][:10_000],
            "job_ids": engagement["job_ids"],
            "current_step": engagement["current_step"],
            "report_path": engagement["report_path"],
            "output": engagement.get("output", "")[:50_000],
            "findings_summary": engagement["findings_summary"],
            "reviewer_id": engagement["reviewer_id"],
            "reviewer_notes": engagement["reviewer_notes"],
            "total_cost": float(engagement["total_cost"]),
            "total_runtime_ms": engagement["total_runtime_ms"],
            "created_at": datetime.fromtimestamp(engagement["created_at"], tz=UTC).isoformat(),
        }
        for ts_field in ("started_at", "completed_at", "delivered_at"):
            val = engagement[ts_field]
            row[ts_field] = datetime.fromtimestamp(val, tz=UTC).isoformat() if val else None

        sb.table("engagements").upsert(row).execute()
    except Exception as e:
        logger.warning("Failed to write engagement %s to DB: %s", engagement["id"], e)


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


def create_engagement(
    user_id: str,
    package: str,
    tier: str,
    repo_url: str,
    scope_notes: str = "",
    depth: str = "scan",
) -> Engagement:
    """Create a new engagement in intake status."""
    engagement: Engagement = {
        "id": str(uuid.uuid4())[:12],
        "user_id": user_id,
        "package": package,
        "tier": tier,
        "depth": depth,
        "status": EngagementStatus.intake,
        "repo_url": repo_url,
        "scope_notes": scope_notes,
        "job_ids": [],
        "current_step": 0,
        "report_path": None,
        "output": "",
        "findings_summary": None,
        "reviewer_id": None,
        "reviewer_notes": None,
        "total_cost": 0.0,
        "total_runtime_ms": 0,
        "created_at": time.time(),
        "started_at": None,
        "completed_at": None,
        "delivered_at": None,
    }
    ENGAGEMENT_STORE[engagement["id"]] = engagement
    _write_to_db(engagement)

    # Audit trail
    try:
        from audit import log_action

        log_action(user_id, "engagement.create", "engagement", engagement["id"], {"package": package, "tier": tier})
    except Exception:
        logger.debug("Failed to log engagement.create audit action")

    return engagement


def get_engagement(engagement_id: str) -> Engagement | None:
    """Fetch an engagement by ID."""
    return ENGAGEMENT_STORE.get(engagement_id)


def list_engagements(user_id: str, limit: int = 20) -> list[Engagement]:
    """List a user's engagements, newest first."""
    user_engagements = [e for e in ENGAGEMENT_STORE.values() if e["user_id"] == user_id]
    user_engagements.sort(key=lambda e: e["created_at"], reverse=True)
    return user_engagements[:limit]


def update_engagement(engagement_id: str, **fields: Any) -> Engagement | None:
    """Partial update. Write-through to Supabase."""
    engagement = ENGAGEMENT_STORE.get(engagement_id)
    if not engagement:
        return None
    for k, v in fields.items():
        if k in engagement:
            engagement[k] = v  # type: ignore[literal-required]
    _write_to_db(engagement)
    return engagement


def list_review_queue(limit: int = 20) -> list[Engagement]:
    """List engagements awaiting human review (premium tier)."""
    reviews = [e for e in ENGAGEMENT_STORE.values() if e["status"] == EngagementStatus.review]
    reviews.sort(key=lambda e: e["completed_at"] or e["created_at"], reverse=True)
    return reviews[:limit]


# ---------------------------------------------------------------------------
# Findings parser
# ---------------------------------------------------------------------------

_SEVERITY_RE = re.compile(r"\b(critical|high|medium|low|info(?:rmational)?)\b", re.IGNORECASE)


def _parse_findings(bug_hunter_output: str) -> dict[str, int]:
    """Extract severity counts from Bug Hunter output."""
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for match in _SEVERITY_RE.finditer(bug_hunter_output):
        severity = match.group(1).lower()
        if severity.startswith("info"):
            severity = "info"
        counts[severity] = counts.get(severity, 0) + 1
    return counts


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------


async def run_engagement(engagement_id: str) -> None:
    """Run the engagement workflow with triage-based parallel execution.

    1. Triage: determine which agents to run and how to parallelize
    2. Execute parallel groups concurrently via asyncio.gather
    3. Auto-execute PDF Forge output to generate report
    4. Route to review (premium) or delivered (self-serve)
    5. Send notifications
    """
    from mcp_server import (
        AGENT_META,
        WORKFLOWS,
        _background_tasks,
        _create_job,
        _run_job_background,
        _run_pdf_forge_script,
        _wait_for_job,
    )
    from triage import triage

    engagement = ENGAGEMENT_STORE.get(engagement_id)
    if not engagement:
        return

    package = engagement["package"]

    # Mark running
    update_engagement(engagement_id, status=EngagementStatus.running, started_at=time.time())

    try:
        from audit import log_action

        log_action(engagement["user_id"], "engagement.start", "engagement", engagement_id)
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)

    try:
        from notifications import notify_engagement_started

        notify_engagement_started(engagement["user_id"], package, engagement_id)
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)

    # Triage: get execution plan (agents + parallel groups)
    plan = await triage(engagement["repo_url"], engagement["scope_notes"], package)
    parallel_groups = plan["parallel_groups"]

    # Get workflow prompts (for building agent-specific prompts)
    workflow = WORKFLOWS.get(package)
    workflow_steps = {step["agent_id"]: step for step in workflow["steps"]} if workflow else {}

    step_results: list[dict] = []
    total_cost = 0.0
    total_ms = 0
    step_index = 0

    for group in parallel_groups:
        # Build prompts for all agents in this group
        group_jobs: list[tuple[str, dict]] = []

        for agent_id in group:
            # Build prompt context from prior results
            prev_map: dict[str, str] = {f"prev_{j}": sr["output"][:4000] for j, sr in enumerate(step_results)}
            prev_map["prev"] = step_results[-1]["output"][:8000] if step_results else ""
            prev_map["input"] = engagement["scope_notes"][:8000]
            prev_map["repo_url"] = engagement["repo_url"]
            prev_map["scope_notes"] = engagement["scope_notes"][:2000]

            # Use workflow-defined prompt if available, otherwise generic
            step_def = workflow_steps.get(agent_id)
            if step_def:
                try:
                    prompt = step_def["prompt"].format(**prev_map)
                except KeyError:
                    prompt = step_def["prompt"].format_map(
                        {**prev_map, **dict.fromkeys(re.findall(r"\{(\w+)\}", step_def["prompt"]), "")}
                    )
            else:
                prompt = (
                    f"Analyze this codebase.\n\nRepository: {engagement['repo_url']}\n"
                    f"Scope: {engagement['scope_notes']}\n\n"
                    f"Previous findings:\n{prev_map['prev'][:4000]}"
                )

            agent_name = AGENT_META.get(agent_id, {}).get("name", agent_id)
            sub_job = _create_job(agent_id, prompt[:200], name=agent_name)

            # Update engagement with new job immediately
            job_ids = engagement["job_ids"] + [sub_job["job_id"]]
            update_engagement(engagement_id, job_ids=job_ids, current_step=step_index)

            group_jobs.append((agent_id, sub_job))
            step_index += 1

        # Run all agents in this group concurrently
        async def _run_and_wait(job_id: str) -> dict:
            bg = asyncio.create_task(_run_job_background(job_id))
            _background_tasks.add(bg)
            bg.add_done_callback(_background_tasks.discard)
            return await _wait_for_job(job_id)

        group_results = await asyncio.gather(
            *[_run_and_wait(sub_job["job_id"]) for _, sub_job in group_jobs],
            return_exceptions=True,
        )

        # Process group results
        group_failed = False
        for (agent_id, _sub_job), result in zip(group_jobs, group_results, strict=True):
            if isinstance(result, Exception):
                result = {"status": "error", "output": "", "error": str(result), "cost": 0, "runtime_ms": 0}

            step_results.append({"agent_id": agent_id, **result})
            total_cost += result.get("cost", 0)
            total_ms += result.get("runtime_ms", 0)

            try:
                from audit import log_action

                log_action(
                    engagement["user_id"],
                    "engagement.step_complete",
                    "engagement",
                    engagement_id,
                    {"agent_id": agent_id, "status": result.get("status", "error")},
                )
            except Exception:
                logger.debug("Best-effort operation failed", exc_info=True)

            if result.get("status") == "error":
                group_failed = True
                error_msg = (
                    f"{AGENT_META.get(agent_id, {}).get('name', agent_id)} failed: {result.get('error', 'unknown')}"
                )

        update_engagement(engagement_id, total_cost=total_cost, total_runtime_ms=total_ms)

        if group_failed:
            update_engagement(engagement_id, status=EngagementStatus.error, completed_at=time.time())
            try:
                from notifications import notify_engagement_error

                notify_engagement_error(engagement["user_id"], package, engagement_id, error_msg)
            except Exception:
                logger.debug("Best-effort operation failed", exc_info=True)
            return

    # Auto-execute PDF Forge output to generate report file
    report_path = None
    if step_results and step_results[-1]["agent_id"] == "pdf-forge":
        pdf_output = step_results[-1].get("output", "")
        code = _extract_python_code(pdf_output)
        if code:
            exec_result = await _run_pdf_forge_script(code)
            if exec_result.get("pdf_path"):
                report_path = exec_result["pdf_path"]

    # Parse findings from bug-hunter step
    findings = None
    for sr in step_results:
        if sr["agent_id"] == "bug-hunter":
            findings = _parse_findings(sr.get("output", ""))
            break

    # Route based on tier
    now = time.time()
    if engagement["tier"] == "premium":
        update_engagement(
            engagement_id,
            status=EngagementStatus.review,
            completed_at=now,
            report_path=report_path,
            findings_summary=findings,
        )
        try:
            from notifications import notify_engagement_ready_for_review

            notify_engagement_ready_for_review(engagement_id, package)
        except Exception:
            logger.debug("Best-effort operation failed", exc_info=True)
    else:
        update_engagement(
            engagement_id,
            status=EngagementStatus.delivered,
            completed_at=now,
            delivered_at=now,
            report_path=report_path,
            findings_summary=findings,
        )
        try:
            from notifications import notify_engagement_delivered

            notify_engagement_delivered(engagement["user_id"], package, engagement_id)
        except Exception:
            logger.debug("Best-effort operation failed", exc_info=True)

    # Fire webhook
    try:
        from webhook_service import EventType, fire_event

        fire_event(EventType.ENGAGEMENT_COMPLETE, {"engagement_id": engagement_id, "package": package})
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)

    try:
        from audit import log_action

        log_action(engagement["user_id"], "engagement.complete", "engagement", engagement_id)
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)


async def run_autonomous_engagement(engagement_id: str) -> None:
    """Run a fully autonomous engagement inside a Fly Sprite sandbox.

    Installs vending-machine-mcp in the sandbox so Claude Code/Codex
    can hire Bug Hunter, Test Goblin, Code Gremlin, DevOps Dwarf directly.
    Applies fixes, runs tests, and opens a PR.
    """
    import base64
    import os
    import shlex
    import subprocess
    from pathlib import Path

    engagement = ENGAGEMENT_STORE.get(engagement_id)
    if not engagement:
        return

    package = engagement["package"]
    repo_url = engagement["repo_url"]
    repo = repo_url.rstrip("/").split("github.com/")[-1].removesuffix(".git")
    sprite_name = f"eng-{engagement_id[:8]}"
    github_token = os.environ.get("GITHUB_TOKEN", "")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    openrouter_key = os.environ.get("OPENROUTER_API_KEY", "")
    loop = asyncio.get_running_loop()

    default_debug_dir = Path.home() / ".venda" / "engagement-logs"
    debug_dir = Path(os.environ.get("ENGAGEMENT_DEBUG_DIR", str(default_debug_dir)))
    debug_dir.mkdir(parents=True, exist_ok=True)
    run_stamp = int(time.time())
    debug_log_path = debug_dir / f"{engagement_id}-{run_stamp}.log"
    sprite_debug_log_path = debug_dir / f"{engagement_id}-{run_stamp}-sprite-cli.log"

    def _trim_output(value: str | None, limit: int = 20_000) -> str:
        text = (value or "").strip()
        if not text:
            return ""
        if len(text) <= limit:
            return text
        return f"{text[:limit]}\n...[truncated {len(text) - limit} chars]"

    def _debug(message: str) -> None:
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        with debug_log_path.open("a", encoding="utf-8") as fh:
            fh.write(f"[{ts}] {message}\n")

    def _run_local(
        args: list[str],
        *,
        timeout: int,
        label: str,
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        _debug(f"{label} command: {shlex.join(args)}")
        try:
            result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            timeout_stdout = _trim_output(exc.stdout)
            timeout_stderr = _trim_output(exc.stderr)
            if timeout_stdout:
                _debug(f"{label} timeout stdout:\n{timeout_stdout}")
            if timeout_stderr:
                _debug(f"{label} timeout stderr:\n{timeout_stderr}")
            raise RuntimeError(f"{label} timed out after {timeout}s") from exc

        _debug(f"{label} rc={result.returncode}")
        stdout = _trim_output(result.stdout)
        stderr = _trim_output(result.stderr)
        if stdout:
            _debug(f"{label} stdout:\n{stdout}")
        if stderr:
            _debug(f"{label} stderr:\n{stderr}")

        if check and result.returncode != 0:
            excerpt = (stderr or stdout or "<no output>")[:500]
            raise RuntimeError(f"{label} failed (rc={result.returncode}): {excerpt}")

        return result

    def _sprite_exec(
        cmd: str,
        timeout: int = 300,
        workdir: str | None = None,
        *,
        check: bool = True,
        label: str | None = None,
    ) -> str:
        full_cmd = f"set -euo pipefail; [ -f ~/.sprite_env ] && source ~/.sprite_env; {cmd}"
        args = ["sprite", f"--debug={sprite_debug_log_path}", "exec", "-s", sprite_name]
        if workdir:
            args.extend(["--dir", workdir])
        args.extend(["--", "bash", "-lc", full_cmd])
        result = _run_local(args, timeout=timeout, label=label or f"sprite exec: {cmd[:60]}", check=check)
        return (result.stdout or "").strip()

    def _setup_sprite() -> None:
        nonlocal sprite_created
        _run_local(
            ["sprite", f"--debug={sprite_debug_log_path}", "create", sprite_name],
            timeout=30,
            label="sprite create",
        )
        sprite_created = True

        env_lines = [
            f"export ANTHROPIC_API_KEY={shlex.quote(anthropic_key)}",
            f"export OPENROUTER_API_KEY={shlex.quote(openrouter_key)}",
            f"export GITHUB_TOKEN={shlex.quote(github_token)}",
            f"export GH_TOKEN={shlex.quote(github_token)}",
        ]
        env_blob = base64.b64encode(("\n".join(env_lines) + "\n").encode("utf-8")).decode("ascii")
        _sprite_exec(
            f"printf '%s' {shlex.quote(env_blob)} | base64 -d > ~/.sprite_env && chmod 600 ~/.sprite_env",
            timeout=10,
            label="sprite write env",
        )

        env_check = _sprite_exec(
            "source ~/.sprite_env; for k in ANTHROPIC_API_KEY OPENROUTER_API_KEY GITHUB_TOKEN GH_TOKEN; do "
            "if [ -n \"${!k:-}\" ]; then echo \"$k=present\"; else echo \"$k=missing\"; fi; done",
            timeout=10,
            label="sprite verify env",
        )
        _debug(f"sprite env status:\n{env_check}")

        _sprite_exec('git config --global user.name "Venda Agent"', timeout=5, label="sprite git user.name")
        _sprite_exec('git config --global user.email "agent@vending-machine.dev"', timeout=5, label="sprite git user.email")
        _sprite_exec("git config --global credential.helper store", timeout=5, label="sprite git credential.helper")
        _sprite_exec(
            "echo \"https://x-access-token:${GITHUB_TOKEN}@github.com\" > ~/.git-credentials && chmod 600 ~/.git-credentials",
            timeout=5,
            label="sprite git credentials",
        )

        # vending-machine-mcp is not published on PyPI yet — skip MCP server install.
        # Claude Code can still perform security audits, write tests, and apply fixes
        # using its built-in tools (Edit, Write, Bash). The MCP agents (Bug Hunter,
        # Test Goblin, etc.) will be available once the package is published.
        _sprite_exec(
            "python -m pip install --disable-pip-version-check vending-machine-mcp 2>/dev/null || echo 'MCP server not available on PyPI, skipping'",
            timeout=60,
            check=False,
            label="sprite pip install vending-machine-mcp (optional)",
        )

        _sprite_exec(
            f"GIT_TERMINAL_PROMPT=0 git clone {shlex.quote(f'https://github.com/{repo}.git')} /home/sprite/repo",
            timeout=180,
            label="sprite clone repo",
        )
        _sprite_exec(
            "test -d /home/sprite/repo/.git && echo clone_ok",
            timeout=5,
            label="sprite verify clone",
        )

    def _run_autonomous() -> dict[str, str | None]:
        branch = f"engagement/{engagement_id[:8]}"
        repo_dir = "/home/sprite/repo"

        _sprite_exec(f"git checkout -B {branch}", timeout=15, workdir=repo_dir, label="sprite checkout branch")
        _sprite_exec("claude --version", timeout=10, workdir=repo_dir, label="sprite claude version")

        package_tasks = {
            "shield": (
                "Perform a comprehensive security audit of this codebase. "
                "Use hire_agent to run bug-hunter for vulnerability scanning, "
                "test-goblin for regression tests, and code-gremlin to fix critical issues. "
                "Apply all fixes and commit them."
            ),
            "blueprint": (
                "Review the AWS architecture and infrastructure of this codebase. "
                "Use hire_agent to run cloud-sensei for Well-Architected review "
                "and devops-dwarf for IaC hardening. Apply improvements and commit."
            ),
            "launchpad": (
                "Full production readiness assessment. "
                "Use hire_agent to run: bug-hunter (security), cloud-sensei (architecture), "
                "devops-dwarf (infrastructure), test-goblin (tests), code-gremlin (fixes). "
                "Apply all fixes, add monitoring, and commit everything."
            ),
        }

        task = (
            f"{package_tasks.get(package, package_tasks['launchpad'])}\n\n"
            f"Scope: {engagement['scope_notes'] or 'Full codebase assessment'}\n\n"
            "After completing all changes, create a git commit with a descriptive message."
        )
        escaped_task = task.replace("'", "'\\''")
        output = _sprite_exec(
            f"claude --print --dangerously-skip-permissions '{escaped_task}'",
            timeout=1800,
            workdir=repo_dir,
            label="sprite run claude",
        )
        if not output.strip():
            raise RuntimeError("Claude returned empty output; inspect sprite stderr in debug logs.")

        status = _sprite_exec("git status --porcelain", timeout=10, workdir=repo_dir, label="sprite git status")
        if not status.strip():
            _debug("No git changes detected after Claude run.")
            return {"status": "no_changes", "output": output, "pr_url": None}

        short_task = " ".join(task.split())[:72].replace("'", "")
        commit_msg = (
            f"feat: {short_task}\n\n"
            "Autonomous change by Claude Code in Sprites sandbox.\n\n"
            "Co-Authored-By: Claude Code <noreply@anthropic.com>\n"
        )
        commit_blob = base64.b64encode(commit_msg.encode("utf-8")).decode("ascii")
        _sprite_exec(
            f"printf '%s' {shlex.quote(commit_blob)} | base64 -d > /tmp/engagement_commit_msg.txt",
            timeout=5,
            workdir=repo_dir,
            label="sprite write commit message",
        )
        _sprite_exec("git add -A", timeout=10, workdir=repo_dir, label="sprite git add")
        _sprite_exec("git commit -F /tmp/engagement_commit_msg.txt", timeout=15, workdir=repo_dir, label="sprite git commit")
        _sprite_exec(f"git push -u origin {branch}", timeout=60, workdir=repo_dir, label="sprite git push")

        pr_title = f"feat: {short_task}"
        pr_body = f"Autonomous engagement by Venda agent pipeline.\n\nEngagement: {engagement_id}\n"
        pr_body_blob = base64.b64encode(pr_body.encode("utf-8")).decode("ascii")
        _sprite_exec(
            f"printf '%s' {shlex.quote(pr_body_blob)} | base64 -d > /tmp/engagement_pr_body.txt",
            timeout=5,
            workdir=repo_dir,
            label="sprite write pr body",
        )
        pr_url = _sprite_exec(
            f"gh pr create --title {shlex.quote(pr_title)} --body-file /tmp/engagement_pr_body.txt",
            timeout=30,
            workdir=repo_dir,
            check=False,
            label="sprite create pr",
        )

        return {"status": "complete", "output": output, "pr_url": pr_url or None}

    sprite_created = False

    update_engagement(engagement_id, status=EngagementStatus.running, started_at=time.time())

    try:
        from notifications import notify_engagement_started

        notify_engagement_started(engagement["user_id"], package, engagement_id)
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)

    try:
        _debug(
            f"starting autonomous engagement id={engagement_id} package={package} repo={repo_url} sprite={sprite_name}"
        )
        logger.warning(
            "Autonomous engagement %s started. Debug logs: %s, %s",
            engagement_id,
            debug_log_path,
            sprite_debug_log_path,
        )

        await loop.run_in_executor(None, _setup_sprite)
        result = await loop.run_in_executor(None, _run_autonomous)
        _debug(f"autonomous result: {result}")

        if result.get("status") == "no_changes":
            logger.warning("Autonomous engagement %s finished with no changes.", engagement_id)

        now = time.time()
        autonomous_output = result.get("output", "")
        update_engagement(
            engagement_id,
            status=EngagementStatus.review if engagement["tier"] == "premium" else EngagementStatus.delivered,
            completed_at=now,
            delivered_at=now if engagement["tier"] != "premium" else None,
            output=autonomous_output[:50_000],
        )

        pr_url = result.get("pr_url")
        if pr_url:
            update_engagement(engagement_id, scope_notes=f"{engagement['scope_notes']}\n\nPR: {pr_url}")

        try:
            from notifications import notify_engagement_delivered

            notify_engagement_delivered(engagement["user_id"], package, engagement_id)
        except Exception:
            logger.debug("Best-effort operation failed", exc_info=True)

    except Exception as e:
        _debug(f"autonomous engagement failed: {e!r}")
        logger.exception("Autonomous engagement %s failed: %s", engagement_id, e)
        update_engagement(engagement_id, status=EngagementStatus.error, completed_at=time.time())
        try:
            from notifications import notify_engagement_error

            notify_engagement_error(engagement["user_id"], package, engagement_id, str(e))
        except Exception:
            logger.debug("Best-effort operation failed", exc_info=True)
    finally:
        if sprite_created:
            try:
                await loop.run_in_executor(
                    None,
                    lambda: _run_local(
                        ["sprite", f"--debug={sprite_debug_log_path}", "destroy", "--force", sprite_name],
                        timeout=15,
                        label="sprite destroy",
                        check=False,
                    ),
                )
            except Exception:
                logger.debug("Failed to destroy sprite %s", sprite_name)


def _extract_python_code(output: str) -> str | None:
    """Extract the largest Python code block from output."""
    matches = re.findall(r"```python\n(.*?)```", output, re.DOTALL)
    if not matches:
        return None
    return max(matches, key=len)


async def deliver_engagement(
    engagement_id: str,
    reviewer_id: str,
    reviewer_notes: str = "",
) -> Engagement | None:
    """Admin approves and delivers a premium engagement."""
    engagement = ENGAGEMENT_STORE.get(engagement_id)
    if not engagement or engagement["status"] != EngagementStatus.review:
        return None

    update_engagement(
        engagement_id,
        status=EngagementStatus.delivered,
        reviewer_id=reviewer_id,
        reviewer_notes=reviewer_notes,
        delivered_at=time.time(),
    )

    # Notify client
    try:
        from notifications import notify_engagement_delivered

        notify_engagement_delivered(engagement["user_id"], engagement["package"], engagement_id)
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)

    # Fire webhook
    try:
        from webhook_service import EventType, fire_event

        fire_event(EventType.ENGAGEMENT_DELIVERED, {"engagement_id": engagement_id})
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)

    try:
        from audit import log_action

        log_action(reviewer_id, "engagement.deliver", "engagement", engagement_id)
    except Exception:
        logger.debug("Best-effort operation failed", exc_info=True)

    return ENGAGEMENT_STORE.get(engagement_id)


# ---------------------------------------------------------------------------
# Startup: load and resume engagements from Supabase
# ---------------------------------------------------------------------------


def load_engagements_from_db() -> int:
    """Load all non-terminal engagements from Supabase into memory.

    Returns count of loaded engagements.
    """
    sb = _get_sb()
    if not sb:
        return 0

    try:
        result = sb.table("engagements").select("*").in_("status", ["intake", "running", "review"]).execute()
        if not result.data:
            return 0

        from datetime import datetime

        count = 0
        for row in result.data:
            eid = row["id"]
            if eid in ENGAGEMENT_STORE:
                continue

            def _parse_ts(val: str | None) -> float | None:
                if not val:
                    return None
                try:
                    return datetime.fromisoformat(val).timestamp()
                except Exception:
                    return None

            engagement: Engagement = {
                "id": eid,
                "user_id": row.get("user_id", "anonymous"),
                "package": row["package"],
                "tier": row.get("tier", "self-serve"),
                "status": EngagementStatus(row["status"]),
                "repo_url": row["repo_url"],
                "scope_notes": row.get("scope_notes", ""),
                "job_ids": row.get("job_ids", []),
                "current_step": row.get("current_step", 0),
                "report_path": row.get("report_path"),
                "findings_summary": row.get("findings_summary"),
                "reviewer_id": row.get("reviewer_id"),
                "reviewer_notes": row.get("reviewer_notes"),
                "total_cost": float(row.get("total_cost", 0)),
                "total_runtime_ms": int(row.get("total_runtime_ms", 0)),
                "created_at": _parse_ts(row.get("created_at")) or time.time(),
                "started_at": _parse_ts(row.get("started_at")),
                "completed_at": _parse_ts(row.get("completed_at")),
                "delivered_at": _parse_ts(row.get("delivered_at")),
            }
            ENGAGEMENT_STORE[eid] = engagement
            count += 1

        logger.info("Loaded %d engagements from Supabase", count)
        return count
    except Exception as e:
        logger.warning("Failed to load engagements from DB: %s", e)
        return 0


async def resume_running_engagements() -> int:
    """Resume engagements that were interrupted by a restart.

    Finds engagements with status='running', determines which step
    they were on, and restarts the pipeline from that step.
    """
    resumed = 0
    for eid, engagement in list(ENGAGEMENT_STORE.items()):
        if engagement["status"] != EngagementStatus.running:
            continue

        current_step = engagement["current_step"]
        package = engagement["package"]

        logger.info("Resuming engagement %s (%s) from step %d", eid, package, current_step)

        task = asyncio.create_task(_resume_engagement(eid, current_step))
        task.add_done_callback(lambda t: None)
        resumed += 1

    if resumed:
        logger.info("Resumed %d interrupted engagements", resumed)
    return resumed


async def _resume_engagement(engagement_id: str, from_step: int) -> None:
    """Resume an engagement pipeline from a specific step."""
    from mcp_server import (
        AGENT_META,
        WORKFLOWS,
        _background_tasks,
        _create_job,
        _run_job_background,
        _run_pdf_forge_script,
        _wait_for_job,
    )

    engagement = ENGAGEMENT_STORE.get(engagement_id)
    if not engagement:
        return

    package = engagement["package"]
    if package not in WORKFLOWS:
        update_engagement(engagement_id, status=EngagementStatus.error)
        return

    workflow = WORKFLOWS[package]
    total_steps = len(workflow["steps"])

    # Collect outputs from completed sub-jobs (steps before from_step)
    step_results: list[dict] = []
    from jobs import get_job as _get_job

    for job_id in engagement["job_ids"][:from_step]:
        job = _get_job(job_id)
        if job and job.get("status") in ("complete", "completed"):
            step_results.append(
                {
                    "agent_id": job["agent_id"],
                    "output": job.get("output", ""),
                    "status": "complete",
                    "cost": job.get("cost", 0),
                    "runtime_ms": job.get("runtime_ms", 0),
                }
            )
        else:
            step_results.append(
                {
                    "agent_id": workflow["steps"][len(step_results)]["agent_id"],
                    "output": "[output lost during restart]",
                    "status": "complete",
                    "cost": 0,
                    "runtime_ms": 0,
                }
            )

    total_cost = engagement["total_cost"]
    total_ms = engagement["total_runtime_ms"]

    for i in range(from_step, total_steps):
        step = workflow["steps"][i]

        prev_map: dict[str, str] = {f"prev_{j}": sr["output"][:4000] for j, sr in enumerate(step_results)}
        prev_map["prev"] = step_results[-1]["output"][:8000] if step_results else ""
        prev_map["input"] = engagement["scope_notes"][:8000]
        prev_map["repo_url"] = engagement["repo_url"]
        prev_map["scope_notes"] = engagement["scope_notes"][:2000]

        try:
            prompt = step["prompt"].format(**prev_map)
        except KeyError:
            prompt = step["prompt"].format_map(
                {**prev_map, **dict.fromkeys(re.findall(r"\{(\w+)\}", step["prompt"]), "")}
            )

        agent_id = step["agent_id"]
        agent_name = AGENT_META.get(agent_id, {}).get("name", agent_id)
        sub_job = _create_job(agent_id, prompt[:200], name=agent_name)

        job_ids = engagement["job_ids"] + [sub_job["job_id"]]
        update_engagement(engagement_id, job_ids=job_ids, current_step=i)

        bg = asyncio.create_task(_run_job_background(sub_job["job_id"]))
        _background_tasks.add(bg)
        bg.add_done_callback(_background_tasks.discard)

        result = await _wait_for_job(sub_job["job_id"])
        step_results.append({"agent_id": agent_id, **result})
        total_cost += result.get("cost", 0)
        total_ms += result.get("runtime_ms", 0)

        update_engagement(engagement_id, total_cost=total_cost, total_runtime_ms=total_ms)

        if result["status"] == "error":
            error_msg = f"{agent_name} failed: {result.get('error', result.get('output', 'unknown'))}"
            update_engagement(engagement_id, status=EngagementStatus.error, completed_at=time.time())
            logger.warning("Resumed engagement %s failed at step %d: %s", engagement_id, i, error_msg)
            return

    # Pipeline complete
    report_path = None
    if step_results and step_results[-1]["agent_id"] == "pdf-forge":
        pdf_output = step_results[-1].get("output", "")
        code = _extract_python_code(pdf_output)
        if code:
            exec_result = await _run_pdf_forge_script(code)
            if exec_result.get("pdf_path"):
                report_path = exec_result["pdf_path"]

    findings = None
    for sr in step_results:
        if sr["agent_id"] == "bug-hunter":
            findings = _parse_findings(sr.get("output", ""))
            break

    now = time.time()
    if engagement["tier"] == "premium":
        update_engagement(
            engagement_id,
            status=EngagementStatus.review,
            completed_at=now,
            report_path=report_path,
            findings_summary=findings,
        )
    else:
        update_engagement(
            engagement_id,
            status=EngagementStatus.delivered,
            completed_at=now,
            delivered_at=now,
            report_path=report_path,
            findings_summary=findings,
        )

    logger.info("Resumed engagement %s completed successfully", engagement_id)
