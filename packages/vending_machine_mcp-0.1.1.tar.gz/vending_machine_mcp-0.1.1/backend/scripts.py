"""
Script marketplace store.

Scripts are Python files that take USER_INPUT and produce output.
The platform handles sandboxed execution, billing, and delivery.

Persists to Supabase PostgreSQL when configured, with in-memory cache.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from typing import Any, TypedDict

logger = logging.getLogger("scripts")


def _get_sb():
    try:
        from supabase_client import get_supabase

        return get_supabase()
    except Exception:
        return None


def _sync_script_to_db(script: dict[str, Any]) -> None:
    """Write-through: persist script to Supabase."""
    sb = _get_sb()
    if not sb:
        return
    try:
        sb.table("scripts").upsert(
            {
                "id": script["script_id"],
                "vending_code": script["vending_code"],
                "name": script["name"],
                "description": script["description"],
                "creator": script["creator"],
                "code": script["code"],
                "packages": json.dumps(script["packages"]),
                "price": float(script["price"]),
                "input_schema": script["input_schema"],
                "runs": script["runs"],
                "revenue": float(script["revenue"]),
                "validation_status": script.get("validation_status", "pending"),
                "validation_report": json.dumps(script.get("validation_report", {})),
                "version": script["version"],
                "code_hash": script["code_hash"],
                "versions": json.dumps(script.get("versions", [])),
            }
        ).execute()
    except Exception as e:
        logger.debug("Failed to sync script to Supabase: %s", e)


class Script(TypedDict):
    script_id: str
    vending_code: str  # S-XXXX — permanent, human-readable, shareable code
    name: str
    description: str
    creator: str
    code: str
    packages: list[str]
    price: float
    input_schema: str
    runs: int
    revenue: float
    created_at: float
    last_run_at: float | None
    validation_status: str  # approved | flagged | rejected | pending
    validation_report: dict  # serialized ComplianceReport
    # Version control
    version: int  # current version number (1, 2, 3, ...)
    code_hash: str  # SHA-256 of the code — detects actual changes
    versions: list[dict]  # history: [{version, code_hash, created_at, validation_status}]


def _hash_code(code: str) -> str:
    """SHA-256 hash of script code for version tracking."""
    return hashlib.sha256(code.encode("utf-8")).hexdigest()[:16]


SCRIPT_STORE: dict[str, Script] = {}


def register_script(
    name: str,
    description: str,
    creator: str,
    code: str,
    packages: list[str] | None = None,
    price: float = 0.05,
    input_schema: str = "Any text input",
    script_id: str | None = None,
) -> Script:
    code_hash = _hash_code(code)

    script: Script = {
        "script_id": script_id or str(uuid.uuid4())[:8],
        "vending_code": "",
        "name": name,
        "description": description,
        "creator": creator,
        "code": code,
        "packages": packages or [],
        "price": price,
        "input_schema": input_schema,
        "runs": 0,
        "revenue": 0.0,
        "created_at": time.time(),
        "last_run_at": None,
        "validation_status": "pending",
        "validation_report": {},
        "version": 1,
        "code_hash": code_hash,
        "versions": [{"version": 1, "code_hash": code_hash, "created_at": time.time(), "validation_status": "pending"}],
    }

    # Vending code is assigned on admin approval, not at registration.
    # Graph sync deferred until approval (PENDING violates unique constraint).
    script["vending_code"] = "PENDING"

    SCRIPT_STORE[script["script_id"]] = script

    # Write-through to Supabase
    _sync_script_to_db(dict(script))

    return script


def update_script(
    vending_code: str,
    code: str,
    description: str | None = None,
    packages: list[str] | None = None,
    input_schema: str | None = None,
) -> Script | None:
    """Update a script's code, creating a new version.

    Returns None if vending code not found or code hasn't changed.
    The vending code stays the same — only the version increments.
    """
    script = get_script_by_vending_code(vending_code)
    if not script:
        return None

    new_hash = _hash_code(code)
    if new_hash == script["code_hash"]:
        return None  # No actual change

    # Increment version
    new_version = script["version"] + 1
    script["code"] = code
    script["code_hash"] = new_hash
    script["version"] = new_version
    script["validation_status"] = "pending"  # re-validate on update
    script["versions"].append(
        {
            "version": new_version,
            "code_hash": new_hash,
            "created_at": time.time(),
            "validation_status": "pending",
        }
    )

    if description is not None:
        script["description"] = description
    if packages is not None:
        script["packages"] = packages
    if input_schema is not None:
        script["input_schema"] = input_schema

    # Re-sync to graph with new embedding
    try:
        from graph import embed_script, is_available, sync_script_to_graph

        if is_available():
            script_dict: dict = dict(script)
            embedding = embed_script(script_dict)
            sync_script_to_graph(script_dict, embedding=embedding)
    except Exception as e:
        logger.debug("Graph operation failed: %s", e)

    return script


async def validate_and_register(
    name: str,
    description: str,
    creator: str,
    code: str,
    packages: list[str] | None = None,
    price: float = 0.05,
    input_schema: str = "Any text input",
    sample_input: str | None = None,
    expected_output: str | None = None,
    test_code: str | None = None,
) -> Script:
    """Register a script with full 7-layer validation.

    Layers 1-4: Security (ATT&CK, Kill Chain, NIST CSF)
    Layers 5-7: Quality (Functionality, Code Quality, Reliability)

    Rejected scripts are stored but marked as rejected (not browsable).
    """
    from guards.script_validator import validate_script

    script = register_script(
        name=name,
        description=description,
        creator=creator,
        code=code,
        packages=packages,
        price=price,
        input_schema=input_schema,
    )

    report = await validate_script(
        code=code,
        packages=packages or [],
        description=description,
        input_schema=input_schema,
        sample_input=sample_input,
        expected_output=expected_output,
        test_code=test_code,
    )

    script["validation_status"] = report.verdict.lower()
    script["validation_report"] = report.to_dict()

    # Sync validation results to Supabase
    _sync_script_to_db(dict(script))

    # Keep rejected scripts in store for admin visibility
    # (list_scripts filters them out for public browsing)

    return script


def get_script(script_id: str) -> Script | None:
    return SCRIPT_STORE.get(script_id)


def list_scripts(include_rejected: bool = False) -> list[Script]:
    scripts = SCRIPT_STORE.values()
    if not include_rejected:
        scripts = [s for s in scripts if s.get("validation_status") != "rejected"]
    return sorted(scripts, key=lambda s: s["created_at"], reverse=True)


def record_run(script_id: str, cost: float, session_id: str = "") -> None:
    script = SCRIPT_STORE.get(script_id)
    if script:
        script["runs"] += 1
        script["revenue"] = round(script["revenue"] + cost, 6)
        script["last_run_at"] = time.time()

        # Write-through to Supabase (atomic increment)
        sb = _get_sb()
        if sb:
            try:
                sb.rpc("increment_script_runs", {"sid": script_id, "run_cost": float(cost)}).execute()
            except Exception as e:
                logger.debug("Failed to record run in Supabase: %s", e)

        # Update graph with chain detection
        try:
            from graph import record_usage

            if script.get("vending_code"):
                record_usage(script["vending_code"], session_id=session_id)
        except Exception as e:
            logger.debug("Graph operation failed: %s", e)


def get_script_by_vending_code(vending_code: str) -> Script | None:
    """Look up a script by its vending code (S-XXXX)."""
    for script in SCRIPT_STORE.values():
        if script.get("vending_code") == vending_code:
            return script
    return None


# ---------------------------------------------------------------------------
# Seed scripts — pre-loaded marketplace examples
# ---------------------------------------------------------------------------


def _seed():
    # Seed scripts are platform-provided and pre-approved
    def _seed_script(**kwargs) -> Script:
        # Deterministic script_id from name — ensures vending codes persist across restarts
        stable_id = hashlib.sha256(kwargs["name"].encode()).hexdigest()[:8]
        s = register_script(script_id=stable_id, **kwargs)
        s["validation_status"] = "approved"
        # Seed scripts get real vending codes immediately (they're pre-approved)
        if not s.get("vending_code") or s["vending_code"] == "PENDING":
            from graph import generate_vending_code, is_available

            try:
                s["vending_code"] = generate_vending_code() if is_available() else f"S-{stable_id[:4].upper()}"
            except Exception:
                s["vending_code"] = f"S-{stable_id[:4].upper()}"
        s["validation_report"] = {
            "verdict": "APPROVED",
            "riskScore": 0.0,
            "findings": [],
            "summary": "Platform seed script — pre-approved.",
        }
        # Sync seed scripts into whichever backend is active (sqlite or neo4j).
        try:
            from graph import embed_script, is_available, sync_script_to_graph

            if is_available() and s.get("vending_code"):
                script_dict: dict = dict(s)
                embedding = embed_script(script_dict)
                sync_script_to_graph(script_dict, embedding=embedding)
        except Exception as e:
            logger.debug("Graph sync failed for seed script: %s", e)
        return s

    _seed_script(
        name="CSV Analyzer",
        description="Upload a CSV and get statistical summary — row/column counts, data types, descriptive stats, missing values, and correlations.",
        creator="platform",
        code="""import sys, csv, io, statistics

data = USER_INPUT.strip()
reader = csv.DictReader(io.StringIO(data))
rows = list(reader)

if not rows:
    print("Error: No data found. Provide CSV with headers.")
    sys.exit(1)

cols = list(rows[0].keys())
print(f"# CSV Analysis")
print(f"**Rows:** {len(rows)} | **Columns:** {len(cols)}")
print(f"**Headers:** {', '.join(cols)}")
print()

for col in cols:
    values = [r[col] for r in rows if r[col]]
    # Try numeric analysis
    nums = []
    for v in values:
        try:
            nums.append(float(v))
        except ValueError:
            logger.debug("Graph operation failed: %s", e)

    if nums and len(nums) > len(values) * 0.5:
        print(f"## {col} (numeric)")
        print(f"- Count: {len(nums)}")
        print(f"- Mean: {statistics.mean(nums):.2f}")
        print(f"- Median: {statistics.median(nums):.2f}")
        print(f"- Std Dev: {statistics.stdev(nums):.2f}" if len(nums) > 1 else "")
        print(f"- Min: {min(nums):.2f} | Max: {max(nums):.2f}")
    else:
        unique = set(values)
        print(f"## {col} (categorical)")
        print(f"- Count: {len(values)} | Unique: {len(unique)}")
        if len(unique) <= 10:
            print(f"- Values: {', '.join(sorted(unique)[:10])}")
    missing = len(rows) - len(values)
    if missing:
        print(f"- Missing: {missing} ({missing/len(rows)*100:.1f}%)")
    print()
""",
        packages=[],
        price=0.03,
        input_schema="CSV text with headers (paste or upload)",
    )

    _seed_script(
        name="Regex Extractor",
        description="Extract all matches of a regex pattern from text. First line is the pattern, rest is the text to search.",
        creator="platform",
        code="""import re

lines = USER_INPUT.strip().split("\\n", 1)
if len(lines) < 2:
    print("Error: First line should be the regex pattern, rest is the text to search.")
    print("Example:\\n  \\\\b[A-Z][a-z]+\\\\b\\n  Hello World from Python")
else:
    pattern = lines[0].strip()
    text = lines[1]
    try:
        matches = re.findall(pattern, text)
        print(f"# Regex Results")
        print(f"**Pattern:** `{pattern}`")
        print(f"**Matches found:** {len(matches)}")
        print()
        if matches:
            for i, m in enumerate(matches[:100]):
                print(f"{i+1}. `{m}`")
            if len(matches) > 100:
                print(f"... and {len(matches) - 100} more")
        else:
            print("No matches found.")
    except re.error as e:
        print(f"Invalid regex: {e}")
""",
        packages=[],
        price=0.01,
        input_schema="Line 1: regex pattern. Line 2+: text to search.",
    )

    _seed_script(
        name="JSON Transformer",
        description="Transform JSON data with Python expressions. First line is the expression (use `data` variable), rest is the JSON.",
        creator="platform",
        code="""import json, sys

lines = USER_INPUT.strip().split("\\n", 1)
if len(lines) < 2:
    print("Error: First line is the Python expression, rest is JSON.")
    print("Example:\\n  [x['name'] for x in data if x['age'] > 30]\\n  [{...}, ...]")
    sys.exit(1)

expr = lines[0].strip()
json_text = lines[1].strip()

try:
    data = json.loads(json_text)
except json.JSONDecodeError as e:
    print(f"Invalid JSON: {e}")
    sys.exit(1)

try:
    result = eval(expr, {"__builtins__": {}, "data": data, "len": len, "sum": sum, "min": min, "max": max, "sorted": sorted, "str": str, "int": int, "float": float, "list": list, "dict": dict, "set": set, "enumerate": enumerate, "zip": zip, "map": map, "filter": filter})
    print(json.dumps(result, indent=2, default=str))
except Exception as e:
    print(f"Expression error: {e}")
""",
        packages=[],
        price=0.02,
        input_schema="Line 1: Python expression using `data` variable. Line 2+: JSON input.",
    )

    _seed_script(
        name="Text Stats",
        description="Analyze text — word count, sentence count, readability score, top words, and character frequency.",
        creator="platform",
        code="""import re
from collections import Counter

text = USER_INPUT.strip()
if not text:
    print("Error: No text provided.")
else:
    words = re.findall(r"\\b\\w+\\b", text.lower())
    sentences = re.split(r"[.!?]+", text)
    sentences = [s.strip() for s in sentences if s.strip()]
    chars = len(text)

    # Readability (Flesch-Kincaid approximation)
    syllables = sum(max(1, len(re.findall(r"[aeiouy]+", w, re.I))) for w in words)
    if words and sentences:
        fk_grade = 0.39 * (len(words)/len(sentences)) + 11.8 * (syllables/len(words)) - 15.59
    else:
        fk_grade = 0

    word_freq = Counter(words)

    print("# Text Analysis")
    print(f"**Characters:** {chars:,} | **Words:** {len(words):,} | **Sentences:** {len(sentences):,}")
    print(f"**Avg words/sentence:** {len(words)/max(len(sentences),1):.1f}")
    print(f"**Readability:** Flesch-Kincaid Grade {fk_grade:.1f}")
    print()
    print("## Top 15 Words")
    for word, count in word_freq.most_common(15):
        bar = "█" * min(count, 30)
        print(f"  {word:15s} {count:4d} {bar}")
    print()
    print("## Character Classes")
    alpha = sum(1 for c in text if c.isalpha())
    digits = sum(1 for c in text if c.isdigit())
    spaces = sum(1 for c in text if c.isspace())
    punct = chars - alpha - digits - spaces
    print(f"  Letters: {alpha} | Digits: {digits} | Spaces: {spaces} | Punctuation: {punct}")
""",
        packages=[],
        price=0.02,
        input_schema="Any text to analyze.",
    )

    # -----------------------------------------------------------------------
    # 5. Seed Data Generator
    # -----------------------------------------------------------------------
    _seed_script(
        name="Seed Data Generator",
        description="Generate mock JSON data — users, products, or orders with customizable fields and counts.",
        creator="platform",
        code="""import json, random, string, uuid, sys
from datetime import datetime, timedelta

lines = USER_INPUT.strip().split("\\n")
if not lines:
    print("Error: Provide type on line 1 (users/products/orders), count on line 2.")
    sys.exit(1)

data_type = lines[0].strip().lower()
count = 10
if len(lines) > 1:
    try:
        count = max(1, min(int(lines[1].strip()), 1000))
    except ValueError:
        count = 10

FIRST = ["Alice","Bob","Carol","Dave","Eve","Frank","Grace","Hank","Ivy","Jack",
         "Kara","Leo","Mia","Nick","Olivia","Pete","Quinn","Rosa","Sam","Tina"]
LAST = ["Smith","Jones","Brown","Wilson","Taylor","Clark","Hall","Lee","Young","King"]
DOMAINS = ["gmail.com","outlook.com","yahoo.com","hey.com","proton.me"]
STREETS = ["Main St","Oak Ave","Pine Rd","Elm Blvd","Cedar Ln","Maple Dr"]
CITIES = ["Springfield","Portland","Austin","Denver","Miami","Seattle","Boston"]
CATEGORIES = ["Electronics","Books","Clothing","Home","Sports","Toys","Food","Tools"]
ADJECTIVES = ["Premium","Classic","Ultra","Pro","Eco","Smart","Turbo","Mini"]
NOUNS = ["Widget","Gadget","Device","Tool","Kit","Pack","Set","Box","Module","Unit"]
STATUSES = ["pending","confirmed","shipped","delivered"]

def gen_user():
    first, last = random.choice(FIRST), random.choice(LAST)
    return {
        "id": str(uuid.uuid4())[:8],
        "name": f"{first} {last}",
        "email": f"{first.lower()}.{last.lower()}@{random.choice(DOMAINS)}",
        "age": random.randint(18, 75),
        "address": f"{random.randint(1,9999)} {random.choice(STREETS)}, {random.choice(CITIES)}",
        "created_at": (datetime.now() - timedelta(days=random.randint(0, 730))).isoformat()
    }

def gen_product():
    name = f"{random.choice(ADJECTIVES)} {random.choice(NOUNS)}"
    return {
        "id": str(uuid.uuid4())[:8],
        "name": name,
        "sku": "SKU-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=6)),
        "price": round(random.uniform(1.99, 499.99), 2),
        "category": random.choice(CATEGORIES),
        "in_stock": random.choice([True, True, True, False]),
        "rating": round(random.uniform(1.0, 5.0), 1)
    }

def gen_order():
    n_items = random.randint(1, 5)
    items = []
    for _ in range(n_items):
        qty = random.randint(1, 4)
        price = round(random.uniform(5.99, 199.99), 2)
        items.append({"product": f"{random.choice(ADJECTIVES)} {random.choice(NOUNS)}", "qty": qty, "price": price})
    total = round(sum(i["price"] * i["qty"] for i in items), 2)
    return {
        "order_id": "ORD-" + "".join(random.choices(string.digits, k=8)),
        "customer_id": str(uuid.uuid4())[:8],
        "items": items,
        "total": total,
        "status": random.choice(STATUSES),
        "date": (datetime.now() - timedelta(days=random.randint(0, 365))).isoformat()
    }

generators = {"users": gen_user, "products": gen_product, "orders": gen_order}
if data_type not in generators:
    print(f"Error: Unknown type '{data_type}'. Use: users, products, or orders.")
    sys.exit(1)

result = [generators[data_type]() for _ in range(count)]
print(f"# Generated {count} {data_type}\\n")
print(json.dumps(result, indent=2))
""",
        packages=[],
        price=0.03,
        input_schema="Line 1: type (users/products/orders). Line 2: count (default 10).",
    )

    # -----------------------------------------------------------------------
    # 6. Data Analysis
    # -----------------------------------------------------------------------
    _seed_script(
        name="Data Analysis",
        description="Compute statistical summary of numeric data — mean, median, mode, stdev, quartiles, outliers, and ASCII histogram.",
        creator="platform",
        code="""import statistics, math, sys, re

raw = USER_INPUT.strip()
if not raw:
    print("Error: Provide numeric data — one number per line, or comma-separated.")
    sys.exit(1)

# Parse numbers from input (comma-separated or newline-separated)
tokens = re.split(r"[,\\n]+", raw)
nums = []
for t in tokens:
    t = t.strip()
    if not t:
        continue
    try:
        nums.append(float(t))
    except ValueError:
        pass

if len(nums) < 2:
    print("Error: Need at least 2 numeric values for analysis.")
    sys.exit(1)

nums.sort()
n = len(nums)
mean = statistics.mean(nums)
median = statistics.median(nums)
try:
    mode = statistics.mode(nums)
except statistics.StatisticsError:
    mode = "N/A (no unique mode)"
stdev = statistics.stdev(nums)
variance = statistics.variance(nums)
q1 = statistics.median(nums[:n//2])
q3 = statistics.median(nums[(n+1)//2:])
iqr = q3 - q1
p90 = nums[int(n * 0.9)]

# Outlier detection (IQR method)
lower_fence = q1 - 1.5 * iqr
upper_fence = q3 + 1.5 * iqr
outliers = [x for x in nums if x < lower_fence or x > upper_fence]

print("# Data Analysis Report")
print(f"**Count:** {n}")
print(f"**Mean:** {mean:.4f}")
print(f"**Median:** {median:.4f}")
print(f"**Mode:** {mode}")
print(f"**Std Dev:** {stdev:.4f}")
print(f"**Variance:** {variance:.4f}")
print(f"**Min:** {nums[0]:.4f} | **Max:** {nums[-1]:.4f} | **Range:** {nums[-1]-nums[0]:.4f}")
print()
print("## Percentiles")
print(f"  P25 (Q1): {q1:.4f}")
print(f"  P50 (Median): {median:.4f}")
print(f"  P75 (Q3): {q3:.4f}")
print(f"  P90: {p90:.4f}")
print(f"  IQR: {iqr:.4f}")
print()

if outliers:
    print(f"## Outliers ({len(outliers)} detected)")
    print(f"  Fences: [{lower_fence:.4f}, {upper_fence:.4f}]")
    print(f"  Values: {', '.join(f'{x:.2f}' for x in outliers[:20])}")
else:
    print("## Outliers: None detected")
print()

# ASCII histogram
print("## Distribution (ASCII Histogram)")
num_bins = min(20, n)
bin_width = (nums[-1] - nums[0]) / num_bins if nums[-1] != nums[0] else 1
bins = [0] * num_bins
for x in nums:
    idx = min(int((x - nums[0]) / bin_width), num_bins - 1)
    bins[idx] += 1
max_count = max(bins) if bins else 1
for i, count in enumerate(bins):
    lo = nums[0] + i * bin_width
    bar_len = int(count / max_count * 30) if max_count else 0
    bar = "█" * bar_len
    print(f"  {lo:8.2f} | {bar} ({count})")
""",
        packages=[],
        price=0.03,
        input_schema="Numeric data — one number per line, or comma-separated.",
    )

    # -----------------------------------------------------------------------
    # 7. Text Similarity (TF-IDF)
    # -----------------------------------------------------------------------
    _seed_script(
        name="Text Similarity (TF-IDF)",
        description="Compare two texts using TF-IDF cosine similarity. Prints score, shared terms, and unique terms.",
        creator="platform",
        code="""import re, math, sys
from collections import Counter

raw = USER_INPUT.strip()
parts = re.split(r"\\n---\\n", raw, maxsplit=1)
if len(parts) < 2:
    print("Error: Provide two texts separated by '---' on its own line.")
    print("Example:\\n  The quick brown fox\\n  ---\\n  The fast brown dog")
    sys.exit(1)

def tokenize(text):
    return re.findall(r"\\b[a-z]+\\b", text.lower())

text_a, text_b = parts[0].strip(), parts[1].strip()
tokens_a, tokens_b = tokenize(text_a), tokenize(text_b)

if not tokens_a or not tokens_b:
    print("Error: Both texts must contain words.")
    sys.exit(1)

# Build document frequency
docs = [tokens_a, tokens_b]
all_terms = set(tokens_a) | set(tokens_b)
df = {}
for term in all_terms:
    df[term] = sum(1 for d in docs if term in d)

# TF-IDF vectors
def tfidf_vector(tokens):
    tf = Counter(tokens)
    n = len(tokens)
    vec = {}
    for term in all_terms:
        tf_val = tf.get(term, 0) / n
        idf_val = math.log(2 / df[term]) + 1  # smooth IDF for 2 docs
        vec[term] = tf_val * idf_val
    return vec

vec_a = tfidf_vector(tokens_a)
vec_b = tfidf_vector(tokens_b)

# Cosine similarity
dot = sum(vec_a[t] * vec_b[t] for t in all_terms)
mag_a = math.sqrt(sum(v**2 for v in vec_a.values()))
mag_b = math.sqrt(sum(v**2 for v in vec_b.values()))
similarity = dot / (mag_a * mag_b) if mag_a and mag_b else 0.0

shared = sorted(set(tokens_a) & set(tokens_b))
only_a = sorted(set(tokens_a) - set(tokens_b))
only_b = sorted(set(tokens_b) - set(tokens_a))

print("# Text Similarity Report")
print(f"**Cosine Similarity:** {similarity:.4f}")
print(f"**Interpretation:** ", end="")
if similarity > 0.8: print("Very similar")
elif similarity > 0.5: print("Moderately similar")
elif similarity > 0.2: print("Somewhat similar")
else: print("Not very similar")
print()
print(f"## Shared Terms ({len(shared)})")
print(f"  {', '.join(shared[:50]) if shared else 'None'}")
print(f"\\n## Unique to Text A ({len(only_a)})")
print(f"  {', '.join(only_a[:50]) if only_a else 'None'}")
print(f"\\n## Unique to Text B ({len(only_b)})")
print(f"  {', '.join(only_b[:50]) if only_b else 'None'}")
print(f"\\n## Stats")
print(f"  Text A: {len(tokens_a)} words, {len(set(tokens_a))} unique")
print(f"  Text B: {len(tokens_b)} words, {len(set(tokens_b))} unique")
print(f"  Vocabulary: {len(all_terms)} total unique terms")
""",
        packages=[],
        price=0.04,
        input_schema="Two texts separated by '---' on its own line.",
    )

    # -----------------------------------------------------------------------
    # 8. Markdown Table Builder
    # -----------------------------------------------------------------------
    _seed_script(
        name="Markdown Table Builder",
        description="Convert CSV, TSV, or JSON array data into a GitHub-flavored markdown table.",
        creator="platform",
        code="""import csv, json, io, sys

raw = USER_INPUT.strip()
if not raw:
    print("Error: Provide CSV, TSV, or JSON array data.")
    sys.exit(1)

rows = []
headers = []

# Try JSON array first
if raw.startswith("["):
    try:
        data = json.loads(raw)
        if isinstance(data, list) and data:
            if isinstance(data[0], dict):
                headers = list(data[0].keys())
                rows = [headers] + [[str(r.get(h, "")) for h in headers] for r in data]
            elif isinstance(data[0], list):
                rows = [[str(c) for c in r] for r in data]
                headers = rows[0] if rows else []
    except json.JSONDecodeError:
        pass

# Try TSV (if tabs present)
if not rows and "\\t" in raw:
    reader = csv.reader(io.StringIO(raw), delimiter="\\t")
    rows = [row for row in reader]
    headers = rows[0] if rows else []

# Fall back to CSV
if not rows:
    reader = csv.reader(io.StringIO(raw))
    rows = [row for row in reader]
    headers = rows[0] if rows else []

if not rows or len(rows) < 1:
    print("Error: Could not parse any tabular data.")
    sys.exit(1)

# Normalize row lengths
max_cols = max(len(r) for r in rows)
for r in rows:
    while len(r) < max_cols:
        r.append("")

# Calculate column widths
widths = [max(len(rows[r][c]) for r in range(len(rows))) for c in range(max_cols)]
widths = [max(w, 3) for w in widths]  # minimum width 3

# Print markdown table
def fmt_row(row):
    return "| " + " | ".join(cell.ljust(widths[i]) for i, cell in enumerate(row)) + " |"

print(fmt_row(rows[0]))
print("| " + " | ".join("-" * widths[i] for i in range(max_cols)) + " |")
for row in rows[1:]:
    print(fmt_row(row))

print(f"\\n*{len(rows)-1} data rows, {max_cols} columns*")
""",
        packages=[],
        price=0.02,
        input_schema="CSV, TSV, or JSON array data.",
    )

    # -----------------------------------------------------------------------
    # 9. URL Slug Generator
    # -----------------------------------------------------------------------
    _seed_script(
        name="URL Slug Generator",
        description="Convert titles or text into URL-friendly slugs — one per line.",
        creator="platform",
        code="""import re, unicodedata, sys

raw = USER_INPUT.strip()
if not raw:
    print("Error: Provide one title/text per line.")
    sys.exit(1)

lines = raw.split("\\n")
print("# URL Slugs\\n")
for line in lines:
    line = line.strip()
    if not line:
        continue
    # Normalize unicode
    slug = unicodedata.normalize("NFKD", line)
    slug = slug.encode("ascii", "ignore").decode("ascii")
    slug = slug.lower()
    slug = re.sub(r"[^a-z0-9\\s-]", "", slug)
    slug = re.sub(r"[\\s-]+", "-", slug)
    slug = slug.strip("-")
    print(f"  {line}")
    print(f"  -> `{slug}`")
    print()
""",
        packages=[],
        price=0.01,
        input_schema="One title/text per line.",
    )

    # -----------------------------------------------------------------------
    # 10. Hash Generator
    # -----------------------------------------------------------------------
    _seed_script(
        name="Hash Generator",
        description="Compute MD5, SHA1, SHA256, or SHA512 hashes of text input.",
        creator="platform",
        code="""import hashlib, sys

lines = USER_INPUT.strip().split("\\n", 1)
if len(lines) < 2:
    print("Error: Line 1 = algorithm (md5, sha1, sha256, sha512, all). Line 2+ = text to hash.")
    sys.exit(1)

algo = lines[0].strip().lower()
text = lines[1]
data = text.encode("utf-8")

algos = {
    "md5": hashlib.md5,
    "sha1": hashlib.sha1,
    "sha256": hashlib.sha256,
    "sha512": hashlib.sha512,
}

if algo == "all":
    selected = list(algos.keys())
elif algo in algos:
    selected = [algo]
else:
    print(f"Error: Unknown algorithm '{algo}'. Use: md5, sha1, sha256, sha512, or all.")
    sys.exit(1)

print("# Hash Results\\n")
print(f"**Input:** {len(data)} bytes")
print()
for name in selected:
    digest = algos[name](data).hexdigest()
    print(f"**{name.upper()}:**")
    print(f"  `{digest}`")
    print()
""",
        packages=[],
        price=0.01,
        input_schema="Line 1: algorithm (md5, sha1, sha256, sha512, all). Line 2+: text to hash.",
    )

    # -----------------------------------------------------------------------
    # 11. Base64 Encode/Decode
    # -----------------------------------------------------------------------
    _seed_script(
        name="Base64 Encode/Decode",
        description="Encode text to Base64 or decode Base64 back to text.",
        creator="platform",
        code="""import base64, sys

lines = USER_INPUT.strip().split("\\n", 1)
if len(lines) < 2:
    print("Error: Line 1 = 'encode' or 'decode'. Line 2+ = text.")
    sys.exit(1)

action = lines[0].strip().lower()
text = lines[1]

if action == "encode":
    data = text.encode("utf-8")
    encoded = base64.b64encode(data).decode("ascii")
    print("# Base64 Encode\\n")
    print(f"**Input:** {len(data)} bytes")
    print(f"**Output:** {len(encoded)} characters\\n")
    print(f"```\\n{encoded}\\n```")
elif action == "decode":
    try:
        decoded = base64.b64decode(text.strip()).decode("utf-8")
        print("# Base64 Decode\\n")
        print(f"**Input:** {len(text.strip())} characters")
        print(f"**Output:** {len(decoded.encode('utf-8'))} bytes\\n")
        print(f"```\\n{decoded}\\n```")
    except Exception as e:
        print(f"Error: Invalid Base64 input -- {e}")
        sys.exit(1)
else:
    print("Error: First line must be 'encode' or 'decode'.")
    sys.exit(1)
""",
        packages=[],
        price=0.01,
        input_schema="Line 1: 'encode' or 'decode'. Line 2+: text.",
    )

    # -----------------------------------------------------------------------
    # 12. JWT Decoder
    # -----------------------------------------------------------------------
    _seed_script(
        name="JWT Decoder",
        description="Decode a JWT token — inspect header, payload, and expiration without verification.",
        creator="platform",
        code="""import base64, json, sys
from datetime import datetime, timezone

token = USER_INPUT.strip()
if not token:
    print("Error: Provide a JWT token string.")
    sys.exit(1)

parts = token.split(".")
if len(parts) != 3:
    print(f"Error: JWT must have 3 parts (header.payload.signature), got {len(parts)}.")
    sys.exit(1)

def decode_part(s):
    # Fix padding
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    return json.loads(base64.urlsafe_b64decode(s).decode("utf-8"))

try:
    header = decode_part(parts[0])
    payload = decode_part(parts[1])
except Exception as e:
    print(f"Error: Failed to decode JWT -- {e}")
    sys.exit(1)

print("# JWT Decoded\\n")
print("## Header")
print(f"```json\\n{json.dumps(header, indent=2)}\\n```\\n")
print("## Payload")
print(f"```json\\n{json.dumps(payload, indent=2)}\\n```\\n")

# Check expiration
if "exp" in payload:
    exp_dt = datetime.fromtimestamp(payload["exp"], tz=timezone.utc)
    now = datetime.now(tz=timezone.utc)
    expired = now > exp_dt
    print("## Expiration")
    print(f"  **Expires:** {exp_dt.isoformat()}")
    print(f"  **Status:** {'EXPIRED' if expired else 'Valid'}")
    if expired:
        delta = now - exp_dt
        print(f"  **Expired:** {delta.days}d {delta.seconds//3600}h ago")
    else:
        delta = exp_dt - now
        print(f"  **Remaining:** {delta.days}d {delta.seconds//3600}h")

if "iat" in payload:
    iat_dt = datetime.fromtimestamp(payload["iat"], tz=timezone.utc)
    print(f"\\n  **Issued at:** {iat_dt.isoformat()}")

print(f"\\n## Signature")
print(f"  `{parts[2][:40]}...` (not verified -- no secret key)")
""",
        packages=[],
        price=0.01,
        input_schema="A JWT token string.",
    )

    # -----------------------------------------------------------------------
    # 13. Cron Expression Explainer
    # -----------------------------------------------------------------------
    _seed_script(
        name="Cron Expression Explainer",
        description="Parse a cron expression into human-readable description and calculate next 5 fire times.",
        creator="platform",
        code="""import sys
from datetime import datetime, timedelta

raw = USER_INPUT.strip()
if not raw:
    print("Error: Provide a cron expression (5 fields: minute hour day-of-month month day-of-week).")
    sys.exit(1)

fields = raw.split()
if len(fields) != 5:
    print(f"Error: Expected 5 fields, got {len(fields)}. Format: minute hour dom month dow")
    sys.exit(1)

FIELD_NAMES = ["Minute", "Hour", "Day of Month", "Month", "Day of Week"]
FIELD_RANGES = [(0,59), (0,23), (1,31), (1,12), (0,6)]
DOW_NAMES = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]
MONTH_NAMES = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]

def parse_field(expr, lo, hi):
    values = set()
    for part in expr.split(","):
        step = 1
        if "/" in part:
            part, step = part.split("/", 1)
            step = int(step)
        if part == "*":
            values.update(range(lo, hi+1, step))
        elif "-" in part:
            a, b = part.split("-", 1)
            values.update(range(int(a), int(b)+1, step))
        else:
            values.add(int(part))
    return values

def describe_field(expr, name, lo, hi, names=None):
    if expr == "*":
        return f"every {name.lower()}"
    if "/" in expr and expr.startswith("*/"):
        step = expr.split("/")[1]
        return f"every {step} {name.lower()}s"
    vals = sorted(parse_field(expr, lo, hi))
    if names:
        return ", ".join(names[v] if v < len(names) else str(v) for v in vals)
    return ", ".join(str(v) for v in vals)

try:
    parsed = [parse_field(fields[i], *FIELD_RANGES[i]) for i in range(5)]
except (ValueError, IndexError) as e:
    print(f"Error: Invalid cron expression -- {e}")
    sys.exit(1)

print("# Cron Expression Explained\\n")
print(f"**Expression:** `{raw}`\\n")

descs = [
    describe_field(fields[0], "Minute", 0, 59),
    describe_field(fields[1], "Hour", 0, 23),
    describe_field(fields[2], "Day of Month", 1, 31),
    describe_field(fields[3], "Month", 1, 12, MONTH_NAMES),
    describe_field(fields[4], "Day of Week", 0, 6, DOW_NAMES),
]
print("## Fields")
for i, name in enumerate(FIELD_NAMES):
    print(f"  **{name}** (`{fields[i]}`): {descs[i]}")
print()

# Calculate next 5 fire times
print("## Next 5 Fire Times")
now = datetime.now()
dt = now.replace(second=0, microsecond=0) + timedelta(minutes=1)
found = 0
attempts = 0
while found < 5 and attempts < 525960:
    if (dt.minute in parsed[0] and dt.hour in parsed[1] and
        dt.day in parsed[2] and dt.month in parsed[3] and
        dt.weekday() in {(d - 1) % 7 for d in parsed[4]}):
        print(f"  {found+1}. {dt.strftime('%Y-%m-%d %H:%M')} ({DOW_NAMES[(dt.weekday()+1)%7]})")
        found += 1
        dt += timedelta(minutes=1)
    else:
        dt += timedelta(minutes=1)
    attempts += 1

if found == 0:
    print("  Could not find fire times within next year.")
""",
        packages=[],
        price=0.01,
        input_schema="A cron expression (5 fields: minute hour day-of-month month day-of-week).",
    )

    # -----------------------------------------------------------------------
    # 14. JSON <-> YAML Converter
    # -----------------------------------------------------------------------
    _seed_script(
        name="JSON/YAML Converter",
        description="Convert JSON to YAML or simple YAML to JSON — no external dependencies.",
        creator="platform",
        code="""import json, re, sys

lines = USER_INPUT.strip().split("\\n", 1)
if len(lines) < 2:
    print("Error: Line 1 = 'to_yaml' or 'to_json'. Line 2+ = data.")
    sys.exit(1)

action = lines[0].strip().lower()
data_str = lines[1].strip()

def to_yaml(obj, indent=0):
    prefix = "  " * indent
    if isinstance(obj, dict):
        if not obj:
            return "{}"
        parts = []
        for k, v in obj.items():
            if isinstance(v, (dict, list)) and v:
                parts.append(f"{prefix}{k}:")
                parts.append(to_yaml(v, indent + 1))
            else:
                parts.append(f"{prefix}{k}: {fmt_val(v)}")
        return "\\n".join(parts)
    elif isinstance(obj, list):
        if not obj:
            return f"{prefix}[]"
        parts = []
        for item in obj:
            if isinstance(item, (dict, list)) and item:
                first_line = to_yaml(item, indent + 1).lstrip()
                parts.append(f"{prefix}- {first_line}")
            else:
                parts.append(f"{prefix}- {fmt_val(item)}")
        return "\\n".join(parts)
    else:
        return f"{prefix}{fmt_val(obj)}"

def fmt_val(v):
    if v is None: return "null"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, (int, float)): return str(v)
    s = str(v)
    if any(c in s for c in ":#{}[],"): return f'"{s}"'
    return s

def parse_yaml(text):
    result = {}
    stack = [(result, -1)]
    for line in text.split("\\n"):
        stripped = line.rstrip()
        if not stripped or stripped.lstrip().startswith("#"):
            continue
        indent = len(line) - len(line.lstrip())
        while len(stack) > 1 and stack[-1][1] >= indent:
            stack.pop()
        parent = stack[-1][0]
        content = stripped.lstrip()
        if content.startswith("- "):
            value = content[2:].strip()
            if isinstance(parent, dict):
                last_key = list(parent.keys())[-1] if parent else None
                if last_key is not None:
                    if not isinstance(parent[last_key], list):
                        parent[last_key] = []
                    parent[last_key].append(parse_val(value))
            elif isinstance(parent, list):
                parent.append(parse_val(value))
        elif ":" in content:
            key, _, val = content.partition(":")
            key = key.strip()
            val = val.strip()
            if val:
                parent[key] = parse_val(val)
            else:
                parent[key] = {}
                stack.append((parent[key], indent))

    return result

def parse_val(s):
    s = s.strip()
    if s in ("null", "~"): return None
    if s == "true": return True
    if s == "false": return False
    if s.startswith('"') and s.endswith('"'): return s[1:-1]
    if s.startswith("'") and s.endswith("'"): return s[1:-1]
    try: return int(s)
    except ValueError: pass
    try: return float(s)
    except ValueError: pass
    return s

if action == "to_yaml":
    try:
        obj = json.loads(data_str)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON -- {e}")
        sys.exit(1)
    print("# JSON -> YAML\\n")
    print("```yaml")
    print(to_yaml(obj))
    print("```")
elif action == "to_json":
    try:
        obj = parse_yaml(data_str)
    except Exception as e:
        print(f"Error: Failed to parse YAML -- {e}")
        sys.exit(1)
    print("# YAML -> JSON\\n")
    print("```json")
    print(json.dumps(obj, indent=2))
    print("```")
else:
    print("Error: First line must be 'to_yaml' or 'to_json'.")
    sys.exit(1)
""",
        packages=[],
        price=0.02,
        input_schema="Line 1: 'to_yaml' or 'to_json'. Line 2+: data to convert.",
    )

    # -----------------------------------------------------------------------
    # 15. Timestamp Converter
    # -----------------------------------------------------------------------
    _seed_script(
        name="Timestamp Converter",
        description="Convert between timestamp formats — epoch, ISO 8601, human-readable, with relative time.",
        creator="platform",
        code="""import re, sys
from datetime import datetime, timezone, timedelta

raw = USER_INPUT.strip()
if not raw:
    print("Error: Provide a timestamp (epoch seconds, epoch millis, ISO 8601, or date string).")
    sys.exit(1)

dt = None

# Try epoch milliseconds (13+ digits)
if re.match(r"^\\d{13,}$", raw):
    dt = datetime.fromtimestamp(int(raw) / 1000, tz=timezone.utc)

# Try epoch seconds (9-10 digits)
elif re.match(r"^\\d{9,10}$", raw):
    dt = datetime.fromtimestamp(int(raw), tz=timezone.utc)

# Try ISO 8601
elif re.match(r"^\\d{4}-\\d{2}-\\d{2}", raw):
    for fmt in [
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ]:
        try:
            dt = datetime.strptime(raw.replace("Z", "+00:00"), fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            break
        except ValueError:
            continue

# Try common date formats
if dt is None:
    for fmt in ["%B %d, %Y", "%b %d, %Y", "%m/%d/%Y", "%d/%m/%Y"]:
        try:
            dt = datetime.strptime(raw, fmt).replace(tzinfo=timezone.utc)
            break
        except ValueError:
            continue

if dt is None:
    print(f"Error: Could not parse '{raw}'. Try: epoch seconds, epoch millis, ISO 8601, or YYYY-MM-DD.")
    sys.exit(1)

# Calculate relative time
now = datetime.now(tz=timezone.utc)
diff = now - dt
if diff.total_seconds() >= 0:
    total_sec = int(diff.total_seconds())
    if total_sec < 60: relative = f"{total_sec} seconds ago"
    elif total_sec < 3600: relative = f"{total_sec//60} minutes ago"
    elif total_sec < 86400: relative = f"{total_sec//3600} hours ago"
    else: relative = f"{diff.days} days ago"
else:
    total_sec = int(-diff.total_seconds())
    if total_sec < 60: relative = f"in {total_sec} seconds"
    elif total_sec < 3600: relative = f"in {total_sec//60} minutes"
    elif total_sec < 86400: relative = f"in {total_sec//3600} hours"
    else: relative = f"in {-diff.days} days"

epoch_s = int(dt.timestamp())
epoch_ms = int(dt.timestamp() * 1000)

print("# Timestamp Converter\\n")
print(f"**Input:** `{raw}`\\n")
print("| Format | Value |")
print("|--------|-------|")
print(f"| Epoch (seconds) | `{epoch_s}` |")
print(f"| Epoch (milliseconds) | `{epoch_ms}` |")
print(f"| ISO 8601 | `{dt.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]}Z` |")
print(f"| UTC Human | `{dt.strftime('%A, %B %d, %Y at %H:%M:%S UTC')}` |")
print(f"| Relative | {relative} |")
""",
        packages=[],
        price=0.01,
        input_schema="A timestamp (epoch seconds, epoch millis, ISO 8601, or human-readable date).",
    )

    # -----------------------------------------------------------------------
    # 16. UUID Generator
    # -----------------------------------------------------------------------
    _seed_script(
        name="UUID Generator",
        description="Generate UUIDs — supports v4 (random) and v7 (time-ordered).",
        creator="platform",
        code="""import uuid, sys, time, random

lines = USER_INPUT.strip().split("\\n")
count = 1
version = 4

if lines[0].strip():
    try:
        count = max(1, min(int(lines[0].strip()), 100))
    except ValueError:
        count = 1

if len(lines) > 1 and lines[1].strip():
    v = lines[1].strip()
    if v in ("4", "v4"):
        version = 4
    elif v in ("7", "v7"):
        version = 7
    else:
        print(f"Error: Unknown version '{v}'. Use 4 or 7.")
        sys.exit(1)

def uuid7():
    timestamp_ms = int(time.time() * 1000)
    rand_bytes = random.getrandbits(74)
    uuid_int = (timestamp_ms & 0xFFFFFFFFFFFF) << 80
    uuid_int |= 0x7 << 76
    uuid_int |= (rand_bytes >> 62) << 64
    uuid_int |= 0x2 << 62
    uuid_int |= rand_bytes & 0x3FFFFFFFFFFFFFFF
    h = f"{uuid_int:032x}"
    return f"{h[:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:]}"

print("# UUID Generator\\n")
print(f"**Version:** {version} | **Count:** {count}\\n")
print("```")
for i in range(count):
    if version == 4:
        print(str(uuid.uuid4()))
    else:
        print(uuid7())
print("```")
""",
        packages=[],
        price=0.01,
        input_schema="Line 1: count (default 1). Line 2: version -- 4 or 7 (default 4).",
    )

    # -----------------------------------------------------------------------
    # 17. Password Generator
    # -----------------------------------------------------------------------
    _seed_script(
        name="Password Generator",
        description="Generate cryptographically secure passwords with configurable rules and entropy estimate.",
        creator="platform",
        code="""import secrets, string, math, sys

lines = USER_INPUT.strip().split("\\n")

count = 5
length = 16
rules = {"upper", "lower", "digits", "symbols"}

if lines[0].strip():
    try:
        count = max(1, min(int(lines[0].strip()), 50))
    except ValueError:
        count = 5

if len(lines) > 1 and lines[1].strip():
    try:
        length = max(4, min(int(lines[1].strip()), 128))
    except ValueError:
        length = 16

if len(lines) > 2 and lines[2].strip():
    rules = {r.strip().lower() for r in lines[2].split(",") if r.strip()}

# Build character pool
pool = ""
if "upper" in rules: pool += string.ascii_uppercase
if "lower" in rules: pool += string.ascii_lowercase
if "digits" in rules: pool += string.digits
if "symbols" in rules: pool += "!@#$%^&*()-_=+[]{}|;:,.<>?"

if not pool:
    pool = string.ascii_letters + string.digits
    rules = {"upper", "lower", "digits"}

pool_size = len(set(pool))
entropy_per_char = math.log2(pool_size) if pool_size > 1 else 0
total_entropy = entropy_per_char * length

def gen_password():
    while True:
        pw = "".join(secrets.choice(pool) for _ in range(length))
        ok = True
        if "upper" in rules and not any(c in string.ascii_uppercase for c in pw): ok = False
        if "lower" in rules and not any(c in string.ascii_lowercase for c in pw): ok = False
        if "digits" in rules and not any(c in string.digits for c in pw): ok = False
        if "symbols" in rules and not any(c in "!@#$%^&*()-_=+[]{}|;:,.<>?" for c in pw): ok = False
        if ok or length < len(rules):
            return pw

print("# Password Generator\\n")
print(f"**Length:** {length} | **Rules:** {', '.join(sorted(rules))}")
print(f"**Pool size:** {pool_size} chars | **Entropy:** {total_entropy:.1f} bits")
if total_entropy >= 80: strength = "Very Strong"
elif total_entropy >= 60: strength = "Strong"
elif total_entropy >= 40: strength = "Moderate"
else: strength = "Weak"
print(f"**Strength:** {strength}\\n")
print("```")
for _ in range(count):
    print(gen_password())
print("```")
""",
        packages=[],
        price=0.01,
        input_schema="Line 1: count (default 5). Line 2: length (default 16). Line 3: rules -- upper,lower,digits,symbols (default all).",
    )

    # -----------------------------------------------------------------------
    # 18. IP Subnet Calculator
    # -----------------------------------------------------------------------
    _seed_script(
        name="IP Subnet Calculator",
        description="Calculate network details from CIDR notation — addresses, host range, masks. IPv4 and IPv6.",
        creator="platform",
        code="""import ipaddress, sys

raw = USER_INPUT.strip()
if not raw:
    print("Error: Provide CIDR notation (e.g. 192.168.1.0/24 or 2001:db8::/32).")
    sys.exit(1)

try:
    network = ipaddress.ip_network(raw, strict=False)
except ValueError as e:
    print(f"Error: Invalid CIDR -- {e}")
    sys.exit(1)

is_v6 = isinstance(network, ipaddress.IPv6Network)
total = network.num_addresses

print("# IP Subnet Calculator\\n")
print(f"**Input:** `{raw}`")
print(f"**Version:** IPv{'6' if is_v6 else '4'}\\n")
print("| Property | Value |")
print("|----------|-------|")
print(f"| Network | `{network.network_address}` |")
print(f"| Prefix Length | `/{network.prefixlen}` |")
print(f"| Netmask | `{network.netmask}` |")

if not is_v6:
    hostmask = network.hostmask
    print(f"| Wildcard Mask | `{hostmask}` |")
    print(f"| Broadcast | `{network.broadcast_address}` |")

    hosts = list(network.hosts())
    if hosts:
        print(f"| First Host | `{hosts[0]}` |")
        print(f"| Last Host | `{hosts[-1]}` |")
    print(f"| Total Addresses | {total:,} |")
    print(f"| Usable Hosts | {max(0, total - 2):,} |")

    first_octet = int(str(network.network_address).split(".")[0])
    if first_octet < 128: cls = "A"
    elif first_octet < 192: cls = "B"
    elif first_octet < 224: cls = "C"
    elif first_octet < 240: cls = "D (multicast)"
    else: cls = "E (reserved)"
    print(f"| Class | {cls} |")
    print(f"| Private | {'Yes' if network.is_private else 'No'} |")
else:
    print(f"| Total Addresses | 2^{128 - network.prefixlen} |")
    print(f"| Scope | {'Link-local' if network.is_link_local else 'Global' if network.is_global else 'Private' if network.is_private else 'Other'} |")
""",
        packages=[],
        price=0.02,
        input_schema="CIDR notation (e.g. 192.168.1.0/24 or 2001:db8::/32).",
    )

    # -----------------------------------------------------------------------
    # 19. Diff Checker
    # -----------------------------------------------------------------------
    _seed_script(
        name="Diff Checker",
        description="Compare two texts and generate a unified diff with added/removed/changed line counts.",
        creator="platform",
        code="""import difflib, sys, re

raw = USER_INPUT.strip()
parts = re.split(r"\\n---\\n", raw, maxsplit=1)
if len(parts) < 2:
    print("Error: Provide two texts separated by '---' on its own line.")
    sys.exit(1)

text_a = parts[0].rstrip()
text_b = parts[1].rstrip()
lines_a = text_a.split("\\n")
lines_b = text_b.split("\\n")

diff = list(difflib.unified_diff(lines_a, lines_b, fromfile="Text A", tofile="Text B", lineterm=""))

added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
ctx = len(diff) - added - removed - 4 if len(diff) > 4 else 0

print("# Diff Report\\n")
print(f"**Text A:** {len(lines_a)} lines | **Text B:** {len(lines_b)} lines")
print(f"**Added:** {added} | **Removed:** {removed} | **Context:** {max(0,ctx)}\\n")

if not diff:
    print("*Texts are identical.*")
else:
    print("```diff")
    for line in diff:
        print(line)
    print("```")

    ratio = difflib.SequenceMatcher(None, text_a, text_b).ratio()
    print(f"\\n**Similarity:** {ratio:.1%}")
""",
        packages=[],
        price=0.02,
        input_schema="Two texts separated by '---' on its own line.",
    )

    # -----------------------------------------------------------------------
    # 20. Regex Tester
    # -----------------------------------------------------------------------
    _seed_script(
        name="Regex Tester",
        description="Test a regex pattern against multiple strings — shows matches, groups, and positions.",
        creator="platform",
        code="""import re, sys

lines = USER_INPUT.strip().split("\\n")
if len(lines) < 2:
    print("Error: Line 1 = regex pattern. Line 2+ = test strings (one per line).")
    sys.exit(1)

pattern_str = lines[0].strip()
test_strings = [l for l in lines[1:] if l.strip()]

if not test_strings:
    print("Error: Provide at least one test string after the pattern.")
    sys.exit(1)

try:
    pattern = re.compile(pattern_str)
except re.error as e:
    print(f"Error: Invalid regex -- {e}")
    sys.exit(1)

print("# Regex Tester\\n")
print(f"**Pattern:** `{pattern_str}`")
print(f"**Flags:** {pattern.flags}\\n")

total_match = 0
total_no_match = 0

for i, s in enumerate(test_strings):
    s = s.strip()
    match = pattern.search(s)
    full_match = pattern.fullmatch(s)

    print(f"## Test {i+1}: `{s}`")
    if match:
        total_match += 1
        print(f"  **Result:** MATCH {'(full)' if full_match else '(partial)'}")
        print(f"  **Span:** [{match.start()}, {match.end()})")
        print(f"  **Matched:** `{match.group()}`")

        all_matches = list(pattern.finditer(s))
        if len(all_matches) > 1:
            print(f"  **All matches ({len(all_matches)}):**")
            for j, m in enumerate(all_matches[:10]):
                print(f"    {j+1}. `{m.group()}` at [{m.start()}, {m.end()})")

        if match.groupdict():
            print(f"  **Named groups:**")
            for name, val in match.groupdict().items():
                print(f"    {name} = `{val}`")
        elif match.groups():
            print(f"  **Groups:**")
            for j, g in enumerate(match.groups(), 1):
                print(f"    Group {j} = `{g}`")
    else:
        total_no_match += 1
        print(f"  **Result:** NO MATCH")
    print()

print(f"---\\n**Summary:** {total_match} matched, {total_no_match} did not match out of {len(test_strings)} strings.")
""",
        packages=[],
        price=0.02,
        input_schema="Line 1: regex pattern. Line 2+: test strings (one per line).",
    )


_seed()
