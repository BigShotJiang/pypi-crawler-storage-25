from typing import Any

class _EmbeddingValue:
    values: list[float]

class _EmbedResult:
    embeddings: list[_EmbeddingValue]

class _Models:
    def embed_content(self, *, model: str, contents: Any, config: Any = ...) -> _EmbedResult: ...

class Client:
    models: _Models
    def __init__(self, api_key: str = ...) -> None: ...
