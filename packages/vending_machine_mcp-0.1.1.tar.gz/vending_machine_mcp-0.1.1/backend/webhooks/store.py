from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from uuid import UUID, uuid4

import bcrypt

from .models import DeliveryAttempt, EventType, WebhookRegistration, WebhookRegistrationRequest


class WebhookStore:
    """Thread-safe in-memory store for webhook registrations and delivery history."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._webhooks: dict[UUID, WebhookRegistration] = {}
        self._delivery_history: dict[UUID, list[DeliveryAttempt]] = {}
        # Plaintext secret kept in memory for signing — never persisted to disk.
        self._secrets: dict[UUID, str] = {}

    async def register(self, req: WebhookRegistrationRequest) -> WebhookRegistration:
        """Register a webhook and return the stored model.

        Raises ValueError if the URL is already registered for this owner.
        """
        async with self._lock:
            for existing in self._webhooks.values():
                if existing.owner_id == req.owner_id and str(existing.url) == str(req.url):
                    raise ValueError("Webhook URL already registered for this owner.")

            webhook_id = uuid4()
            hashed_secret = bcrypt.hashpw(req.secret.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

            webhook = WebhookRegistration(
                id=webhook_id,
                url=req.url,
                events=req.events,
                secret=hashed_secret,
                owner_id=req.owner_id,
                created_at=datetime.now(UTC),
                is_active=True,
                failure_count=0,
            )
            self._webhooks[webhook_id] = webhook
            self._delivery_history[webhook_id] = []
            self._secrets[webhook_id] = req.secret
            return webhook.model_copy(deep=True)

    async def get(self, webhook_id: UUID) -> WebhookRegistration | None:
        """Get a webhook by ID. Returns None if not found."""
        async with self._lock:
            webhook = self._webhooks.get(webhook_id)
            return webhook.model_copy(deep=True) if webhook else None

    async def list_by_owner(self, owner_id: str) -> list[WebhookRegistration]:
        """List all webhooks belonging to an owner."""
        async with self._lock:
            return [w.model_copy(deep=True) for w in self._webhooks.values() if w.owner_id == owner_id]

    async def list_by_event(self, event_type: EventType) -> list[WebhookRegistration]:
        """List all active webhooks subscribed to a given event type."""
        async with self._lock:
            return [w.model_copy(deep=True) for w in self._webhooks.values() if w.is_active and event_type in w.events]

    async def update_failure_count(self, webhook_id: UUID, count: int) -> None:
        """Update the failure count; auto-deactivates at >= 5 consecutive failures."""
        async with self._lock:
            webhook = self._webhooks.get(webhook_id)
            if not webhook:
                return
            webhook.failure_count = max(0, count)
            if webhook.failure_count >= 5:
                webhook.is_active = False

    async def deactivate(self, webhook_id: UUID) -> None:
        """Explicitly deactivate a webhook."""
        async with self._lock:
            webhook = self._webhooks.get(webhook_id)
            if webhook:
                webhook.is_active = False

    async def add_delivery_attempt(self, attempt: DeliveryAttempt) -> None:
        """Append a delivery attempt to the webhook's history (capped at 1000)."""
        async with self._lock:
            history = self._delivery_history.setdefault(attempt.webhook_id, [])
            history.append(attempt)
            # Simple memory guard: keep only the last 1000 entries.
            if len(history) > 1000:
                del history[:-1000]

    async def get_delivery_history(self, webhook_id: UUID) -> list[DeliveryAttempt]:
        """Return a copy of the delivery history for a webhook."""
        async with self._lock:
            history = self._delivery_history.get(webhook_id, [])
            return [a.model_copy(deep=True) for a in history]

    async def get_plain_secret(self, webhook_id: UUID) -> str | None:
        """Return the runtime plaintext secret used for HMAC signing."""
        async with self._lock:
            return self._secrets.get(webhook_id)


# Module-level singleton used by router and delivery engine.
store = WebhookStore()
