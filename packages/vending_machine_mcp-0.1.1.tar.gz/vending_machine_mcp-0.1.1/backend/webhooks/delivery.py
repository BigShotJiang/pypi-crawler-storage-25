from __future__ import annotations

import asyncio
import logging
import secrets
from datetime import UTC, datetime
from typing import Any

import httpx

from .models import DeliveryAttempt, EventType, WebhookPayload, WebhookRegistration
from .security import generate_signature
from .store import store

logger = logging.getLogger(__name__)

# Exponential backoff delays (seconds) between attempts.
_BACKOFF_DELAYS = [1, 2, 4]
_MAX_ATTEMPTS = len(_BACKOFF_DELAYS)
_JITTER_FACTOR = 0.2  # ±20%
_TIMEOUT = httpx.Timeout(10.0)


async def deliver_webhook(
    webhook: WebhookRegistration,
    event_type: EventType,
    data: dict[str, Any],
) -> tuple[bool, DeliveryAttempt | None]:
    """Attempt to deliver a webhook payload with retry + exponential backoff.

    Returns:
        (success, last_delivery_attempt) — attempt is None only if webhook
        is inactive or secret is unavailable.
    """
    if not webhook.is_active:
        return False, None

    secret = await store.get_plain_secret(webhook.id)
    if not secret:
        logger.error("Missing runtime secret for webhook %s — cannot sign payload.", webhook.id)
        attempt = DeliveryAttempt(
            webhook_id=webhook.id,
            event_type=event_type,
            payload={"event": event_type.value, "data": data},
            attempt_number=1,
            error="Missing runtime secret for signing.",
            delivered_at=datetime.now(UTC),
        )
        await store.add_delivery_attempt(attempt)
        await store.update_failure_count(webhook.id, webhook.failure_count + 1)
        return False, attempt

    payload_model = WebhookPayload(
        event=event_type,
        timestamp=datetime.now(UTC),
        webhook_id=webhook.id,
        data=data,
    )
    payload_json = payload_model.model_dump_json()
    payload_bytes = payload_json.encode("utf-8")
    signature = generate_signature(payload_bytes, secret)
    timestamp_str = payload_model.timestamp.isoformat()

    headers = {
        "X-Webhook-ID": str(webhook.id),
        "X-Timestamp": timestamp_str,
        "X-Signature-256": signature,
        "X-Event-Type": event_type.value,
        "Content-Type": "application/json",
    }

    last_attempt: DeliveryAttempt | None = None

    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        for attempt_num, base_delay in enumerate(_BACKOFF_DELAYS, start=1):
            status_code: int | None = None
            error: str | None = None

            try:
                response = await client.post(
                    str(webhook.url),
                    content=payload_bytes,
                    headers=headers,
                )
                status_code = response.status_code

                if 200 <= status_code < 300:
                    last_attempt = DeliveryAttempt(
                        webhook_id=webhook.id,
                        event_type=event_type,
                        payload=payload_model.model_dump(mode="json"),
                        attempt_number=attempt_num,
                        status_code=status_code,
                        delivered_at=datetime.now(UTC),
                    )
                    await store.add_delivery_attempt(last_attempt)
                    await store.update_failure_count(webhook.id, 0)
                    logger.info(
                        "Webhook %s delivered successfully (attempt %d, status %d).",
                        webhook.id,
                        attempt_num,
                        status_code,
                    )
                    return True, last_attempt

                error = f"Non-2xx response: {status_code}"

            except Exception as exc:
                error = str(exc)
                logger.warning(
                    "Webhook %s delivery attempt %d failed: %s",
                    webhook.id,
                    attempt_num,
                    error,
                )

            last_attempt = DeliveryAttempt(
                webhook_id=webhook.id,
                event_type=event_type,
                payload=payload_model.model_dump(mode="json"),
                attempt_number=attempt_num,
                status_code=status_code,
                error=error,
                delivered_at=datetime.now(UTC),
            )
            await store.add_delivery_attempt(last_attempt)

            # Sleep before next attempt (skip sleep after final attempt).
            if attempt_num < _MAX_ATTEMPTS:
                jitter = base_delay * (secrets.randbelow(201) - 100) / 100 * _JITTER_FACTOR
                await asyncio.sleep(base_delay + jitter)

    # All attempts exhausted — increment persistent failure count.
    current = await store.get(webhook.id)
    if current:
        new_count = current.failure_count + 1
        await store.update_failure_count(webhook.id, new_count)
        if new_count >= 5:
            logger.warning("Webhook %s deactivated after %d consecutive failures.", webhook.id, new_count)

    return False, last_attempt


async def broadcast_event(event_type: EventType, data: dict[str, Any]) -> None:
    """Fan out an event to all active webhooks subscribed to it.

    Errors in individual deliveries are isolated and never propagate to the caller.
    """
    try:
        webhooks = await store.list_by_event(event_type)
        if not webhooks:
            return

        tasks = [deliver_webhook(wh, event_type, data) for wh in webhooks]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for wh, result in zip(webhooks, results, strict=False):
            if isinstance(result, Exception):
                logger.error("Unexpected error delivering to webhook %s: %s", wh.id, result)

    except Exception:
        # Delivery failures must never crash the calling application path.
        logger.exception("Unexpected error in broadcast_event for %s.", event_type)
