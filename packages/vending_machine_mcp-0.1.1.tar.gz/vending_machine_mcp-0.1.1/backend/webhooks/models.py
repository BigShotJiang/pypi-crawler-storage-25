from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator

if TYPE_CHECKING:
    from uuid import UUID


class EventType(StrEnum):
    """Supported webhook event types."""

    SCRIPT_RUN = "script.run"
    JOB_COMPLETE = "job.complete"
    JOB_FAILED = "job.failed"
    CREDIT_LOW = "credit.low"


class WebhookRegistration(BaseModel):
    """Stored webhook registration model."""

    id: UUID
    url: HttpUrl
    events: list[EventType]
    secret: str  # bcrypt hash stored at rest; plaintext kept separately in store
    owner_id: str
    created_at: datetime
    is_active: bool
    failure_count: int = 0

    model_config = ConfigDict(from_attributes=True)


class WebhookRegistrationRequest(BaseModel):
    """Incoming webhook registration request."""

    url: HttpUrl
    events: list[EventType] = Field(min_length=1)
    secret: str = Field(min_length=8, max_length=64)
    owner_id: str = Field(min_length=1, max_length=256)

    @field_validator("events")
    @classmethod
    def _dedupe_events(cls, value: list[EventType]) -> list[EventType]:
        """Remove duplicate events while preserving order."""
        seen: set[EventType] = set()
        out: list[EventType] = []
        for event in value:
            if event not in seen:
                seen.add(event)
                out.append(event)
        return out


class WebhookRegistrationResponse(BaseModel):
    """Safe registration response model — never exposes secret or hash."""

    id: UUID
    url: HttpUrl
    events: list[EventType]
    owner_id: str
    created_at: datetime
    is_active: bool


class WebhookTestRequest(BaseModel):
    """Webhook test delivery request."""

    webhook_id: UUID


class DeliveryAttempt(BaseModel):
    """Record of a single delivery attempt."""

    webhook_id: UUID
    event_type: EventType
    payload: dict[str, Any]
    attempt_number: int
    status_code: int | None = None
    error: str | None = None
    delivered_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class WebhookPayload(BaseModel):
    """Outbound payload delivered to webhook consumers."""

    event: EventType
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    webhook_id: UUID
    data: dict[str, Any]
