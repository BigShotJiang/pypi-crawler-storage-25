from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import APIRouter, HTTPException, Request, status

from .delivery import deliver_webhook
from .models import (
    DeliveryAttempt,
    EventType,
    WebhookRegistrationRequest,
    WebhookRegistrationResponse,
    WebhookTestRequest,
)
from .security import RateLimiter, validate_url
from .store import store

if TYPE_CHECKING:
    from uuid import UUID

router = APIRouter(prefix="/webhooks", tags=["webhooks"])

# 10 registrations per IP per hour.
_rate_limiter = RateLimiter(max_requests=10, window_seconds=3600)


def _to_response(webhook) -> WebhookRegistrationResponse:
    """Convert a WebhookRegistration to a safe response model (no secret)."""
    return WebhookRegistrationResponse(
        id=webhook.id,
        url=webhook.url,
        events=webhook.events,
        owner_id=webhook.owner_id,
        created_at=webhook.created_at,
        is_active=webhook.is_active,
    )


@router.post(
    "/register",
    response_model=WebhookRegistrationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a webhook endpoint",
)
async def register_webhook(
    req: WebhookRegistrationRequest,
    request: Request,
) -> WebhookRegistrationResponse:
    """Register a new webhook URL to receive marketplace events.

    - Validates the target URL for SSRF vectors.
    - Applies per-IP sliding-window rate limiting (10/hr).
    - Returns 409 if the same URL is already registered for this owner.
    """
    client_ip = request.client.host if request.client else "unknown"

    allowed = await _rate_limiter.allow(client_ip)
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded. Max 10 registrations per hour per IP.",
        )

    try:
        normalised_url = validate_url(str(req.url))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    # Rebuild request with the normalised URL.
    payload = req.model_copy(update={"url": normalised_url})

    try:
        webhook = await store.register(payload)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    return _to_response(webhook)


@router.get(
    "/owner/{owner_id}",
    response_model=list[WebhookRegistrationResponse],
    summary="List webhooks for an owner",
)
async def list_owner_webhooks(owner_id: str) -> list[WebhookRegistrationResponse]:
    """Return all webhook registrations belonging to the given owner."""
    webhooks = await store.list_by_owner(owner_id)
    return [_to_response(w) for w in webhooks]


@router.get(
    "/{webhook_id}/deliveries",
    response_model=list[DeliveryAttempt],
    summary="Get delivery history",
)
async def get_webhook_deliveries(webhook_id: UUID) -> list[DeliveryAttempt]:
    """Return the last 100 delivery attempts for a webhook."""
    webhook = await store.get(webhook_id)
    if not webhook:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook not found.")

    history = await store.get_delivery_history(webhook_id)
    return history[-100:]


@router.get(
    "/{webhook_id}",
    response_model=WebhookRegistrationResponse,
    summary="Get webhook details",
)
async def get_webhook(webhook_id: UUID) -> WebhookRegistrationResponse:
    """Return webhook registration details (secret is never returned)."""
    webhook = await store.get(webhook_id)
    if not webhook:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook not found.")
    return _to_response(webhook)


@router.delete(
    "/{webhook_id}",
    summary="Deactivate a webhook",
)
async def delete_webhook(webhook_id: UUID) -> dict[str, str]:
    """Deactivate a registered webhook so it no longer receives events."""
    webhook = await store.get(webhook_id)
    if not webhook:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook not found.")

    await store.deactivate(webhook_id)
    return {"status": "deactivated", "webhook_id": str(webhook_id)}


@router.post(
    "/test",
    summary="Send a test payload",
)
async def test_webhook(req: WebhookTestRequest) -> dict:
    """Fire a test ``script.run`` event at the registered webhook URL.

    Useful for verifying that your endpoint is reachable and correctly validates
    the HMAC signature.
    """
    webhook = await store.get(req.webhook_id)
    if not webhook:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook not found.")
    if not webhook.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Webhook is inactive and cannot receive test events.",
        )

    data = {
        "message": "Test delivery from Vending Machine AI marketplace",
        "agent_id": "test-agent",
        "script_name": "health_check.py",
        "user_id": webhook.owner_id,
        "cost_credits": 0,
        "output_summary": "Webhook connectivity test — no real task was executed.",
    }

    success, attempt = await deliver_webhook(webhook, EventType.SCRIPT_RUN, data)
    if attempt is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not create delivery attempt (missing secret).",
        )

    return {
        "status": "delivered" if success else "failed",
        "attempt": attempt.model_dump(mode="json"),
    }
