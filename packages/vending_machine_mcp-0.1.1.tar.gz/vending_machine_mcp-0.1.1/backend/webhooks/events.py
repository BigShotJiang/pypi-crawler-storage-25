"""High-level event helpers for the main application to import.

Usage::

    from webhooks.events import notify_job_complete
    await notify_job_complete(job_id="abc", agent_id="code-gremlin", ...)
"""

from __future__ import annotations

from .delivery import broadcast_event
from .models import EventType


async def notify_script_run(
    agent_id: str,
    script_name: str,
    user_id: str,
    cost_credits: int,
    output_summary: str,
) -> None:
    """Broadcast a ``script.run`` event to all subscribed webhooks."""
    await broadcast_event(
        EventType.SCRIPT_RUN,
        {
            "agent_id": agent_id,
            "script_name": script_name,
            "user_id": user_id,
            "cost_credits": cost_credits,
            "output_summary": output_summary,
        },
    )


async def notify_job_complete(
    job_id: str,
    agent_id: str,
    user_id: str,
    cost_credits: int,
    output_summary: str,
) -> None:
    """Broadcast a ``job.complete`` event to all subscribed webhooks."""
    await broadcast_event(
        EventType.JOB_COMPLETE,
        {
            "job_id": job_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "cost_credits": cost_credits,
            "output_summary": output_summary,
        },
    )


async def notify_job_failed(
    job_id: str,
    agent_id: str,
    user_id: str,
    error: str,
) -> None:
    """Broadcast a ``job.failed`` event to all subscribed webhooks."""
    await broadcast_event(
        EventType.JOB_FAILED,
        {
            "job_id": job_id,
            "agent_id": agent_id,
            "user_id": user_id,
            "error": error,
        },
    )


async def notify_credit_low(
    user_id: str,
    credits_remaining: int,
    threshold: int,
) -> None:
    """Broadcast a ``credit.low`` event to all subscribed webhooks."""
    await broadcast_event(
        EventType.CREDIT_LOW,
        {
            "user_id": user_id,
            "credits_remaining": credits_remaining,
            "threshold": threshold,
        },
    )
