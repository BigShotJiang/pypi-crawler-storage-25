from __future__ import annotations

import asyncio
import hmac
import ipaddress
import socket
import time
from collections import defaultdict, deque
from hashlib import sha256
from urllib.parse import urlparse, urlunparse


def generate_signature(payload_bytes: bytes, secret: str) -> str:
    """Generate an HMAC-SHA256 signature in ``sha256=<hex>`` format."""
    digest = hmac.new(secret.encode("utf-8"), payload_bytes, sha256).hexdigest()
    return f"sha256={digest}"


def verify_signature(payload_bytes: bytes, secret: str, signature: str) -> bool:
    """Verify an HMAC-SHA256 signature using a timing-safe comparison.

    Uses ``hmac.compare_digest`` to prevent timing oracle attacks.
    """
    expected = generate_signature(payload_bytes, secret)
    return hmac.compare_digest(expected, signature)


def _is_blocked_ip(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    """Return True if the IP belongs to any blocked range (SSRF protection)."""
    return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified


def validate_url(url: str) -> str:
    """Validate and normalise a webhook URL with SSRF protections.

    Checks:
    - Only HTTP/HTTPS schemes allowed.
    - No userinfo (credentials) in URL.
    - Blocked internal hostnames (localhost, *.local, *.internal).
    - IP literals in blocked ranges are rejected.
    - DNS-resolved IPs are each checked against blocked ranges.

    Returns the normalised URL string on success.
    Raises ValueError with a human-readable message on failure.
    """
    parsed = urlparse(url)

    if parsed.scheme.lower() not in {"http", "https"}:
        raise ValueError("Only HTTP(S) webhook URLs are allowed.")

    if parsed.username or parsed.password:
        raise ValueError("Credentials (userinfo) in the URL are not allowed.")

    host = (parsed.hostname or "").strip().lower().rstrip(".")
    if not host:
        raise ValueError("Invalid or missing URL host.")

    # Block well-known internal hostnames.
    if host == "localhost" or host.endswith(".local") or host.endswith(".internal"):
        raise ValueError("Internal hostnames are not allowed as webhook targets.")

    # Check if the host is an IP literal.
    try:
        ip_obj = ipaddress.ip_address(host)
        if _is_blocked_ip(ip_obj):
            raise ValueError("Target IP address is in a blocked range.")
    except ValueError as exc:
        # Re-raise only SSRF errors; a non-IP host is expected.
        if "blocked range" in str(exc) or "not allowed" in str(exc):
            raise
        # Hostname — resolve and check every returned address.
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        try:
            addrinfos = socket.getaddrinfo(host, port)
        except socket.gaierror as dns_exc:
            raise ValueError("Unable to resolve webhook hostname.") from dns_exc

        if not addrinfos:
            raise ValueError("Webhook hostname resolves to no addresses.") from None

        for info in addrinfos:
            resolved = info[4][0]
            ip_obj = ipaddress.ip_address(resolved)
            if _is_blocked_ip(ip_obj):
                raise ValueError(f"Webhook hostname resolves to a blocked IP range ({resolved}).") from None

    # Normalise: lowercase scheme/host, preserve path/query/fragment.
    netloc = host
    if parsed.port:
        netloc = f"{host}:{parsed.port}"
    normalised = parsed._replace(scheme=parsed.scheme.lower(), netloc=netloc)
    return urlunparse(normalised)


class RateLimiter:
    """Sliding-window rate limiter.

    Tracks the number of actions per key within a rolling time window.
    Default: 10 registrations per IP per hour.
    """

    def __init__(self, max_requests: int = 10, window_seconds: int = 3600) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._lock = asyncio.Lock()
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    async def allow(self, key: str) -> bool:
        """Return True and record hit if the action is within limits; False otherwise."""
        now = time.time()
        cutoff = now - self.window_seconds

        async with self._lock:
            bucket = self._hits[key]
            # Evict expired entries.
            while bucket and bucket[0] < cutoff:
                bucket.popleft()

            if len(bucket) >= self.max_requests:
                return False

            bucket.append(now)
            return True


class ReplayProtector:
    """Nonce-based replay protection.

    Stores seen jti (JWT ID / nonce) values with a configurable TTL.
    Returns True if a nonce has been seen before (replay detected).
    """

    def __init__(self, ttl_seconds: int = 300) -> None:
        self.ttl_seconds = ttl_seconds
        self._lock = asyncio.Lock()
        self._seen: dict[str, float] = {}  # nonce -> expiry timestamp

    async def check_and_store(self, jti: str) -> bool:
        """Return True if replay detected, else store nonce and return False."""
        now = time.time()

        async with self._lock:
            # Purge expired nonces.
            expired = [k for k, exp in self._seen.items() if exp <= now]
            for key in expired:
                del self._seen[key]

            if jti in self._seen:
                return True  # Replay detected.

            self._seen[jti] = now + self.ttl_seconds
            return False
