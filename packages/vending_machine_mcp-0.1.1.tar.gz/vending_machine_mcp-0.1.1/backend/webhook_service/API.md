# Webhook Notification System — API Reference

Use webhooks to receive real-time HTTP notifications when events occur in your account — scripts running, jobs completing, credits running low. Register a URL, specify which events you want, and we'll POST a signed payload to you.

## Getting Started

1. **Build an endpoint.** Your server needs an HTTP endpoint that accepts POST requests with JSON body. Respond with `2xx` within 30 seconds.

2. **Register your webhook.** `POST /webhooks/register` with your HTTPS URL, event list, and a secret (min 16 characters).

3. **Verify signatures.** Every payload includes `X-Webhook-Signature`. Use your secret to compute HMAC-SHA256 and compare.

4. **Handle retries.** Failed deliveries retry 3x with exponential backoff: 1s, 4s, 16s.

---

## Endpoints

### Register a Webhook

```
POST /webhooks/register
```

```bash
curl -X POST https://api.vendingmachine.dev/webhooks/register \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://your-server.com/webhooks",
    "events": ["script.run", "job.complete"],
    "secret": "my-super-secret-key-2026"
  }'
```

**Response** `201 Created`

```json
{
  "webhook_id": "wh-6371f2c15ce7",
  "url": "https://your-server.com/webhooks",
  "events": ["script.run", "job.complete"],
  "created_at": "2026-04-05T12:00:00Z"
}
```

### Send Test Notification

```
POST /webhooks/test
```

```bash
curl -X POST https://api.vendingmachine.dev/webhooks/test \
  -H "Content-Type: application/json" \
  -d '{"webhook_id": "wh-6371f2c15ce7"}'
```

### List Webhooks

```
GET /webhooks
```

```bash
curl https://api.vendingmachine.dev/webhooks
```

### Delete a Webhook

```
DELETE /webhooks/{webhook_id}
```

```bash
curl -X DELETE https://api.vendingmachine.dev/webhooks/wh-6371f2c15ce7
```

### Delivery History

```
GET /webhooks/{webhook_id}/deliveries
```

```bash
curl https://api.vendingmachine.dev/webhooks/wh-6371f2c15ce7/deliveries
```

---

## Event Types

| Event | Trigger |
|-------|---------|
| `script.run` | A marketplace script executes |
| `job.complete` | An async agent job finishes successfully |
| `job.failed` | An async agent job fails or times out |
| `credit.low` | Account credits fall below threshold |

---

## Payload Schema

```json
{
  "event": "script.run",
  "timestamp": "2026-04-05T12:00:00Z",
  "webhook_id": "wh-6371f2c15ce7",
  "nonce": "abc123-unique",
  "data": {
    "script_name": "CSV Analyzer",
    "vending_code": "S-UOB6",
    "cost": 0.03,
    "runtime_ms": 1200
  }
}
```

### Event-specific data fields

**script.run**: `script_name`, `vending_code`, `cost`, `runtime_ms`

**job.complete**: `job_id`, `agent_id`, `agent_name`, `cost`, `runtime_ms`

**job.failed**: `job_id`, `agent_id`, `error_code`, `error_message`

**credit.low**: `current_balance`, `monthly_allowance`, `threshold_pct`

---

## Signature Verification

Every delivery includes `X-Webhook-Signature: sha256=<hex_digest>`.

### Python

```python
import hmac
import hashlib

def verify_signature(payload_body: bytes, signature_header: str, secret: str) -> bool:
    if not signature_header.startswith("sha256="):
        return False
    expected = signature_header[7:]
    computed = hmac.new(secret.encode("utf-8"), payload_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(computed, expected)
```

### Node.js

```javascript
const crypto = require('crypto');

function verifySignature(payloadBody, signatureHeader, secret) {
  if (!signatureHeader.startsWith('sha256=')) return false;
  const expected = signatureHeader.slice(7);
  const computed = crypto.createHmac('sha256', secret).update(payloadBody).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(computed, 'hex'));
}
```

---

## Security

- **HTTPS required** — HTTP URLs are rejected
- **SSRF protection** — localhost, private IPs (10.x, 172.16.x, 192.168.x), and cloud metadata endpoints are blocked
- **HMAC-SHA256 signatures** — constant-time verification prevents timing attacks
- **Replay protection** — unique nonce in every payload
- **Payload size limit** — 64KB max for webhook data
- **Rate limit** — max 20 webhooks per account

## Retry Policy

| Attempt | Delay |
|---------|-------|
| 1 | Immediate |
| 2 | 1 second |
| 3 | 4 seconds |

After 3 failures, delivery is marked failed. Check `/webhooks/{id}/deliveries` for status.
