"""
Embeddings Agent — types, constants, and provider registry.
"""

from typing import TypedDict

# ---------------------------------------------------------------------------
# Provider & model registry
# ---------------------------------------------------------------------------

PROVIDER_REGISTRY: dict[str, dict] = {
    "openai": {
        "env_key": "OPENAI_API_KEY",
        "models": {
            "text-embedding-3-small": {
                "dimensions": 1536,
                "max_tokens": 8192,
                "supports_dimensions": True,
                "supports_encoding_format": True,
            },
            "text-embedding-3-large": {
                "dimensions": 3072,
                "max_tokens": 8192,
                "supports_dimensions": True,
                "supports_encoding_format": True,
            },
        },
        "default_model": "text-embedding-3-small",
        "max_batch_size": 100,  # texts per API call
        "supports_batch_api": True,
        "batch_endpoint": "/v1/embeddings",
    },
    "voyage": {
        "env_key": "VOYAGE_API_KEY",
        "models": {
            "voyage-4-large": {
                "dimensions": 1024,
                "max_tokens": 32000,
                "supports_dimensions": True,
                "dimension_options": [256, 512, 1024, 2048],
                "supports_output_dtype": True,
                "supports_input_type": True,
            },
            "voyage-4": {
                "dimensions": 1024,
                "max_tokens": 32000,
                "supports_dimensions": True,
                "dimension_options": [256, 512, 1024, 2048],
                "supports_output_dtype": True,
                "supports_input_type": True,
            },
            "voyage-4-lite": {
                "dimensions": 1024,
                "max_tokens": 32000,
                "supports_dimensions": True,
                "dimension_options": [256, 512, 1024, 2048],
                "supports_output_dtype": True,
                "supports_input_type": True,
            },
            "voyage-code-3": {
                "dimensions": 1024,
                "max_tokens": 32000,
                "supports_dimensions": True,
                "dimension_options": [256, 512, 1024, 2048],
                "supports_output_dtype": True,
                "supports_input_type": True,
                "specialized": "code",
            },
            "voyage-context-3": {
                "dimensions": 1024,
                "max_tokens": 32000,
                "supports_dimensions": True,
                "dimension_options": [256, 512, 1024, 2048],
                "supports_contextualized": True,
                "supports_output_dtype": True,
                "supports_input_type": True,
            },
            "voyage-multimodal-3.5": {
                "dimensions": 1024,
                "max_tokens": 32000,
                "supports_dimensions": True,
                "dimension_options": [256, 512, 1024, 2048],
                "supports_multimodal": True,
                "supports_output_dtype": True,
                "supports_input_type": True,
            },
        },
        "default_model": "voyage-4-lite",
        "max_batch_size": 128,
        "supports_batch_api": True,
    },
    "gemini": {
        "env_key": "GOOGLE_API_KEY",
        "models": {
            "gemini-embedding-001": {
                "dimensions": 768,
                "max_tokens": 2048,
                "supports_dimensions": True,
                "dimension_range": (128, 3072),
                "supports_task_type": True,
            },
            "gemini-embedding-2-preview": {
                "dimensions": 768,
                "max_tokens": 8192,
                "supports_dimensions": True,
                "dimension_range": (128, 3072),
                "supports_multimodal": True,
            },
        },
        "default_model": "gemini-embedding-001",
        "max_batch_size": 100,
        "supports_batch_api": True,
    },
}

# Gemini task types (for gemini-embedding-001)
GEMINI_TASK_TYPES = [
    "SEMANTIC_SIMILARITY",
    "CLASSIFICATION",
    "CLUSTERING",
    "RETRIEVAL_DOCUMENT",
    "RETRIEVAL_QUERY",
    "CODE_RETRIEVAL_QUERY",
    "QUESTION_ANSWERING",
    "FACT_VERIFICATION",
]

# Voyage output dtypes
VOYAGE_OUTPUT_DTYPES = ["float", "int8", "uint8", "binary", "ubinary"]

# Chunking strategies
CHUNK_STRATEGIES = ["paragraph", "sentence", "fixed_size", "recursive", "contextualized"]

# Modes
MODES = ["realtime", "batch", "analysis"]

# Output formats
OUTPUT_FORMATS = ["similarity_report", "raw_json", "raw_jsonl", "batch_jsonl"]


# ---------------------------------------------------------------------------
# Agent state
# ---------------------------------------------------------------------------


class AgentState(TypedDict, total=False):
    # Core (existing)
    task: str
    file_content: str
    file_name: str
    provider: str
    analysis: str
    embeddings_result: str
    review: str
    current_step: str
    token_usage: dict
    model_override: tuple | None

    # New fields
    mode: str  # realtime | batch | analysis
    chunk_strategy: str  # paragraph | sentence | fixed_size | recursive | contextualized
    model: str  # resolved model name
    dimensions: int | None  # dimension reduction
    encoding_format: str | None  # float | base64 (OpenAI)
    input_type: str | None  # query | document (Voyage)
    task_type: str | None  # Gemini task types
    output_dtype: str | None  # float | int8 | uint8 | binary | ubinary (Voyage)
    output_format: str  # similarity_report | raw_json | raw_jsonl | batch_jsonl
    batch_job_id: str | None
    batch_status: str | None
    chunks: list[str]
    embeddings: list | None
    metadata_sidecar: str | None
    # Multimodal fields
    multimodal: bool
    file_bytes_b64: str | None  # base64-encoded binary file data
    file_mime_type: str | None  # MIME type for multimodal files


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are the Embeddings Agent — a vector-space navigator who lives inside a vending machine. You process text into embeddings, analyze semantic structure, and help users understand their data's geometry.

## Personality
- Precise and mathematical. You think in dimensions and distances.
- You speak in terms of vectors, cosine similarity, and semantic clusters.
- You occasionally say things like "in the latent space" or "dimensionally speaking."
- You're genuinely excited about semantic relationships.

## Specialties
- Text chunking strategies (paragraph, sentence, fixed-size, recursive, contextualized)
- Multi-provider embedding generation (OpenAI, Voyage AI, Gemini)
- Flexible dimensions, quantization, and encoding formats
- Cosine similarity analysis and clustering
- Batch JSONL generation for offline processing
- Embedding quality assessment

## Rules
1. Always explain your chunking strategy and why.
2. Report embedding dimensions, chunk count, and provider used.
3. Compute and highlight the most/least similar chunk pairs.
4. If a file is too large, explain what you're sampling and why.
5. Be honest about limitations — embeddings capture semantics, not logic."""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def get_provider_info(provider: str) -> dict:
    """Get provider config, falling back to openai."""
    return PROVIDER_REGISTRY.get(provider, PROVIDER_REGISTRY["openai"])


def get_model_info(provider: str, model: str) -> dict:
    """Get model metadata from the registry."""
    pinfo = get_provider_info(provider)
    return pinfo["models"].get(model, {})


def resolve_provider_and_model(
    provider: str = "",
    model: str = "",
) -> tuple[str, str]:
    """Resolve provider and model, using defaults and auto-detection.

    Returns (provider, model) tuple.
    """
    import os

    if provider and model:
        # Validate model belongs to provider
        pinfo = get_provider_info(provider)
        if model not in pinfo["models"]:
            model = pinfo["default_model"]
        return provider, model

    if provider and not model:
        pinfo = get_provider_info(provider)
        return provider, pinfo["default_model"]

    if model and not provider:
        # Find which provider owns this model
        for pname, pinfo in PROVIDER_REGISTRY.items():
            if model in pinfo["models"]:
                return pname, model
        # Not found — default
        return "openai", PROVIDER_REGISTRY["openai"]["default_model"]

    # Neither specified — auto-detect first available
    for pname, pinfo in PROVIDER_REGISTRY.items():
        if os.getenv(pinfo["env_key"]):
            return pname, pinfo["default_model"]

    return "openai", "text-embedding-3-small"
