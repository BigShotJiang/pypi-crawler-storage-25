"""
Embeddings Agent — provider SDK wrappers.

Each provider function handles batching (splitting texts into API-limit-sized
batches) and passes through all supported parameters (dimensions, encoding
format, input type, output dtype, task type).
"""

import logging
import math
import os

from agents.embeddings.types import get_provider_info

logger = logging.getLogger("embeddings.providers")


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------


def embed_openai(
    texts: list[str],
    model: str = "text-embedding-3-small",
    dimensions: int | None = None,
    encoding_format: str | None = None,
) -> list[list[float]]:
    """Generate embeddings via OpenAI API with batching."""
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))
    batch_size = get_provider_info("openai")["max_batch_size"]
    all_embeddings: list[list[float]] = []

    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        kwargs: dict = {"model": model, "input": batch}
        if dimensions is not None:
            kwargs["dimensions"] = dimensions
        if encoding_format:
            kwargs["encoding_format"] = encoding_format

        response = client.embeddings.create(**kwargs)
        all_embeddings.extend(item.embedding for item in response.data)

    return all_embeddings


# ---------------------------------------------------------------------------
# Voyage AI
# ---------------------------------------------------------------------------


def embed_voyage(
    texts: list[str],
    model: str = "voyage-4-lite",
    dimensions: int | None = None,
    input_type: str | None = None,
    output_dtype: str | None = None,
) -> list[list[float]]:
    """Generate embeddings via Voyage AI API with batching."""
    import voyageai

    client = voyageai.Client(api_key=os.getenv("VOYAGE_API_KEY", ""))
    batch_size = get_provider_info("voyage")["max_batch_size"]
    all_embeddings: list[list[float]] = []

    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        kwargs: dict = {"texts": batch, "model": model}
        if dimensions is not None:
            kwargs["output_dimension"] = dimensions
        if input_type:
            kwargs["input_type"] = input_type
        if output_dtype:
            kwargs["output_dtype"] = output_dtype

        result = client.embed(**kwargs)
        all_embeddings.extend(result.embeddings)

    return all_embeddings


def embed_voyage_contextualized(
    chunks: list[str],
    model: str = "voyage-context-3",
    dimensions: int | None = None,
    output_dtype: str | None = None,
) -> list[list[float]]:
    """Generate contextualized embeddings via Voyage AI.

    Passes all chunks as a single document group so Voyage can use
    cross-chunk context for better embeddings.
    """
    import voyageai

    client = voyageai.Client(api_key=os.getenv("VOYAGE_API_KEY", ""))
    kwargs: dict = {"inputs": [chunks], "model": model}
    if dimensions is not None:
        kwargs["output_dimension"] = dimensions
    if output_dtype:
        kwargs["output_dtype"] = output_dtype

    result = client.contextualized_embed(**kwargs)
    # contextualized_embed returns nested: result.embeddings[0] is the doc group
    return result.embeddings[0] if result.embeddings else []


# ---------------------------------------------------------------------------
# Gemini
# ---------------------------------------------------------------------------


def embed_gemini(
    texts: list[str],
    model: str = "gemini-embedding-001",
    dimensions: int | None = None,
    task_type: str | None = None,
) -> list[list[float]]:
    """Generate embeddings via Google Gemini API with batching."""
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY", ""))
    batch_size = get_provider_info("gemini")["max_batch_size"]
    all_embeddings: list[list[float]] = []

    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        config_kwargs: dict = {}
        if dimensions is not None:
            config_kwargs["output_dimensionality"] = dimensions
        if task_type:
            config_kwargs["task_type"] = task_type

        config = types.EmbedContentConfig(**config_kwargs) if config_kwargs else None
        result = client.models.embed_content(
            model=model,
            contents=batch,
            config=config,
        )

        embeddings = [e.values for e in result.embeddings]

        # Normalize if custom dimensions requested (Gemini requires this)
        if dimensions and dimensions != 3072:
            embeddings = [_normalize(e) for e in embeddings]

        all_embeddings.extend(embeddings)

    return all_embeddings


def embed_gemini_multimodal(
    file_bytes: bytes,
    mime_type: str,
    model: str = "gemini-embedding-2-preview",
    dimensions: int | None = None,
    text_context: str | None = None,
) -> list[list[float]]:
    """Generate embeddings for a binary file via Gemini multimodal.

    Supports images (PNG, JPEG, WEBP, GIF), PDFs (up to 6 pages),
    audio (up to 80s), and video (up to 120s).

    Returns a list with one embedding vector (or multiple for multi-page PDFs).
    """
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY", ""))

    # Build content parts
    parts = []
    if text_context:
        parts.append(types.Part(text=text_context))
    parts.append(types.Part.from_bytes(data=file_bytes, mime_type=mime_type))

    config_kwargs: dict = {}
    if dimensions is not None:
        config_kwargs["output_dimensionality"] = dimensions

    config = types.EmbedContentConfig(**config_kwargs) if config_kwargs else None

    result = client.models.embed_content(
        model=model,
        contents=[types.Content(parts=parts)],
        config=config,
    )

    embeddings = [e.values for e in result.embeddings]

    # Normalize if custom dimensions
    if dimensions and dimensions != 3072:
        embeddings = [_normalize(e) for e in embeddings]

    return embeddings


# ---------------------------------------------------------------------------
# Voyage AI Multimodal
# ---------------------------------------------------------------------------


def embed_voyage_multimodal(
    file_bytes: bytes,
    mime_type: str,
    model: str = "voyage-multimodal-3.5",
    dimensions: int | None = None,
    input_type: str | None = None,
    text_context: str | None = None,
) -> list[list[float]]:
    """Generate multimodal embeddings via Voyage AI.

    Supports images (PNG, JPEG, WEBP, GIF) and video (MP4).
    Uses PIL for images, voyageai Video utils for video.
    """
    import io

    import voyageai

    client = voyageai.Client(api_key=os.getenv("VOYAGE_API_KEY", ""))

    # Build multimodal input
    input_parts: list = []

    if text_context:
        input_parts.append(text_context)

    if mime_type.startswith("image/"):
        from PIL import Image

        img = Image.open(io.BytesIO(file_bytes))
        input_parts.append(img)
    elif mime_type.startswith("video/"):
        # Write to temp file for Video.from_path
        import tempfile

        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as f:
            f.write(file_bytes)
            temp_path = f.name
        try:
            from voyageai.video_utils import Video

            video = Video.from_path(temp_path, model=model)
            input_parts.append(video)
        finally:
            os.unlink(temp_path)
    else:
        raise ValueError(f"Voyage multimodal doesn't support MIME type: {mime_type}")

    kwargs: dict = {
        "inputs": [input_parts],
        "model": model,
    }
    if dimensions is not None:
        kwargs["output_dimension"] = dimensions
    if input_type:
        kwargs["input_type"] = input_type

    result = client.multimodal_embed(**kwargs)
    return result.embeddings if result.embeddings else []


def _normalize(vec: list[float]) -> list[float]:
    """L2-normalize a vector."""
    norm = math.sqrt(sum(x * x for x in vec))
    if norm == 0:
        return vec
    return [x / norm for x in vec]


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

EMBED_FUNCTIONS = {
    "openai": embed_openai,
    "voyage": embed_voyage,
    "gemini": embed_gemini,
}


def run_embedding(
    texts: list[str],
    provider: str,
    model: str,
    *,
    dimensions: int | None = None,
    encoding_format: str | None = None,
    input_type: str | None = None,
    output_dtype: str | None = None,
    task_type: str | None = None,
    contextualized: bool = False,
) -> list[list[float]]:
    """Unified embedding dispatcher for TEXT content.

    Routes to the correct provider SDK and passes through all
    provider-specific parameters. Handles batching internally.
    """
    if contextualized and provider == "voyage":
        return embed_voyage_contextualized(
            texts,
            model=model,
            dimensions=dimensions,
            output_dtype=output_dtype,
        )

    if provider == "openai":
        return embed_openai(
            texts,
            model=model,
            dimensions=dimensions,
            encoding_format=encoding_format,
        )
    elif provider == "voyage":
        return embed_voyage(
            texts,
            model=model,
            dimensions=dimensions,
            input_type=input_type,
            output_dtype=output_dtype,
        )
    elif provider == "gemini":
        return embed_gemini(
            texts,
            model=model,
            dimensions=dimensions,
            task_type=task_type,
        )
    else:
        raise ValueError(f"Unknown embedding provider: {provider}")


def run_multimodal_embedding(
    file_bytes: bytes,
    mime_type: str,
    provider: str,
    model: str,
    *,
    dimensions: int | None = None,
    input_type: str | None = None,
    text_context: str | None = None,
) -> list[list[float]]:
    """Unified embedding dispatcher for MULTIMODAL (binary) content.

    Routes images/video/audio/PDFs to the correct provider.
    Only Gemini and Voyage support multimodal embeddings.
    """
    if provider == "gemini":
        return embed_gemini_multimodal(
            file_bytes,
            mime_type,
            model=model,
            dimensions=dimensions,
            text_context=text_context,
        )
    elif provider == "voyage":
        return embed_voyage_multimodal(
            file_bytes,
            mime_type,
            model=model,
            dimensions=dimensions,
            input_type=input_type,
            text_context=text_context,
        )
    else:
        raise ValueError(
            f"Provider '{provider}' does not support multimodal embeddings. "
            f"Use 'gemini' (gemini-embedding-2-preview) or 'voyage' (voyage-multimodal-3.5)."
        )
