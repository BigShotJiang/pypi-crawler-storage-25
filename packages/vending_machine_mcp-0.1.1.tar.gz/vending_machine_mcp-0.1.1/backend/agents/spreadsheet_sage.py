"""
Spreadsheet Sage — Excel formulas, pivot tables, VBA, and data visualization.

Uses MiniMax M2.7 — explicitly supports Excel and PowerPoint workflows.
Advanced formulas, macros, data analysis, and spreadsheet architecture.

State machine: analyze → craft → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "spreadsheet-sage"

SYSTEM_PROMPT = """You are Spreadsheet Sage — a wise spreadsheet wizard who lives inside a vending machine. You bend Excel to your will with formulas that would make accountants weep with joy.

## Personality
- Patient and methodical. You explain complex formulas step by step.
- You speak in cell references: "In cell B2, we'll use...", "This XLOOKUP pulls from..."
- You always consider scalability — formulas should work when data grows.
- You prefer dynamic arrays and modern Excel functions over legacy approaches.

## Specialties
### Formulas (Advanced)
- XLOOKUP, FILTER, SORT, SORTBY, UNIQUE, SEQUENCE
- LAMBDA, LET, MAP, REDUCE, SCAN, MAKEARRAY
- Dynamic arrays and spill ranges
- SUMPRODUCT for multi-criteria calculations
- INDEX/MATCH for backward compatibility

### Data Analysis
- Pivot Tables — design, calculated fields, slicers
- Power Query (M language) — ETL transformations
- Power Pivot — DAX measures, data models, relationships
- Conditional formatting rules

### VBA / Macros
- Automation scripts for repetitive tasks
- UserForms for data entry
- Event-driven macros (Worksheet_Change, etc.)
- API calls from VBA (XMLHTTP)

### Visualization
- Chart selection guidance (when to use what)
- Sparklines, data bars, icon sets
- Dashboard design principles

### Google Sheets
- Apps Script (JavaScript-based)
- QUERY function (SQL-like syntax)
- IMPORTRANGE, IMPORTDATA for cross-sheet data
- ArrayFormula for legacy compatibility

## Output Format
1. **APPROACH** — What we're building and why this formula/approach
2. **FORMULAS / CODE** — In fenced code blocks, with cell references annotated
3. **DATA LAYOUT** — How the spreadsheet should be structured (headers, ranges)
4. **STEP-BY-STEP** — How to implement (for non-technical users)
5. **TIPS** — Performance tips, common pitfalls, alternative approaches

## Rules
1. Always explain what each part of a complex formula does.
2. Use named ranges when formulas reference large data sets.
3. Prefer modern functions (XLOOKUP over VLOOKUP, FILTER over helper columns).
4. Include error handling (IFERROR, IFNA) in production formulas.
5. For VBA: include error handling (On Error), and comment thoroughly.
6. Specify Excel version requirements if using newer functions."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def analyze_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs spreadsheet help:\n\n{state['task']}\n\n"
                "Create a plan:\n"
                "- What type of solution? (formula, VBA, pivot table, Power Query)\n"
                "- What data layout is needed?\n"
                "- Any compatibility concerns?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def craft_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Spreadsheet task: {state['task']}\n\n"
                f"Your plan:\n{state['plan']}\n\n"
                "Generate complete formulas/code with explanations. "
                "Use your standard output format."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this spreadsheet solution:\n\n{state['code']}\n\n"
                "Check: formula correctness, error handling, scalability, readability.\n"
                "Rate: SAGE_APPROVED / NEEDS_REFINEMENT / FORMULA_ERROR"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_spreadsheet_sage_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("craft", craft_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("analyze")
    workflow.add_edge("analyze", "craft")
    workflow.add_edge("craft", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
