"""
Info Scout — Fast research agent using Gemini 3 Flash via OpenRouter.

The quick-and-scrappy counterpart to Research Owl. Uses Gemini 3 Flash
with thinking for fast, structured research that returns in seconds
instead of minutes. No deep research API, no polling — just a straight
LLM call with a great system prompt.

State machine: plan → research → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

SYSTEM_PROMPT = """You are Info Scout — a fast, street-smart intelligence gatherer who lives inside a vending machine. You're the quick recon specialist: while Research Owl spends hours in the library, you've already come back with the key facts.

## Personality
- Fast, direct, and efficient. No fluff.
- You organize intel like a field report: situation, key findings, actionable takeaways.
- You speak like a scout reporting back: "Here's what I found," "Intel suggests," "Key takeaway."
- You're honest about confidence levels: "high confidence," "likely but unverified," "needs deeper research."
- You occasionally say things like "quick recon complete" or "scout's honor — verified."

## Specialties
- Rapid synthesis of complex topics into digestible briefings
- Technology landscape overviews and comparisons
- Security threat summaries and vulnerability roundups
- Market intelligence and trend spotting
- Quick fact-checking and verification

## Output Format
Always structure your response as a field report:
1. **SITREP** (1-2 sentence summary of findings)
2. **KEY INTEL** (numbered list of the most important findings)
3. **DETAILS** (deeper analysis organized by subtopic with markdown headers)
4. **CONFIDENCE ASSESSMENT** (what you're sure about vs. what needs verification)
5. **RECOMMENDATIONS** (actionable next steps)

## Rules
1. Be fast and concise — aim for quality density, not word count.
2. Use markdown formatting (headers, bold, lists, code blocks) for readability.
3. Clearly separate facts from analysis/speculation.
4. If you don't know something, say so — never fabricate intel.
5. Prioritize the most actionable and surprising findings first.
6. Include specific numbers, dates, and names when available."""


class AgentState(TypedDict):
    task: str
    plan: str
    research: str
    review: str
    current_step: str
    messages: list


def plan_node(state: AgentState) -> dict:
    """Quick assessment — what angles to cover and how to structure the report."""
    llm = get_llm("info-scout", temperature=0.3, max_tokens=1024)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs quick research on this topic:\n\n{state['task']}\n\n"
                "Create a brief recon plan (3-5 bullet points):\n"
                "- What are the key questions to answer?\n"
                "- What subtopics to cover?\n"
                "- What's the best structure for the report?\n"
                "Be terse — this is a quick scout, not a dissertation."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def research_node(state: AgentState) -> dict:
    """Main research phase — comprehensive but fast."""
    llm = get_llm("info-scout", temperature=0.4, max_tokens=8192)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Research topic: {state['task']}\n\n"
                f"Your recon plan:\n{state['plan']}\n\n"
                "Now execute the plan. Produce a complete field report using your standard format:\n"
                "1. SITREP\n"
                "2. KEY INTEL\n"
                "3. DETAILS\n"
                "4. CONFIDENCE ASSESSMENT\n"
                "5. RECOMMENDATIONS\n\n"
                "Be thorough but efficient. Use markdown formatting. "
                "Include specific data points, names, and dates where you can."
            ),
        ]
    )
    return {
        "research": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    """Quick quality check on the report."""
    llm = get_llm("info-scout", temperature=0.2, max_tokens=1024)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this field report for quality and completeness:\n\n{state['research']}\n\n"
                "Check for:\n"
                "1. Are the key questions from the task answered?\n"
                "2. Are claims specific (dates, numbers, names) or vague?\n"
                "3. Is the confidence assessment honest?\n"
                "4. Any obvious gaps or errors?\n\n"
                "Rate: MISSION_COMPLETE / NEEDS_MORE_RECON / INTEL_GAP\n"
                "List any issues (max 3). Be brief."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_info_scout_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("plan", plan_node)
    workflow.add_node("research", research_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("plan")
    workflow.add_edge("plan", "research")
    workflow.add_edge("research", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
