#!/usr/bin/env python3
"""
AWS Docs MCP worker — runs in a clean subprocess.

Called by aws_docs.py to avoid pydantic/anyio import conflicts.
Usage: python _aws_docs_worker.py <tool_name> <json_arguments>
Prints the tool result text to stdout.
"""

import asyncio
import json
import sys


async def main():
    if len(sys.argv) < 3:
        print("Usage: _aws_docs_worker.py <tool_name> <json_arguments>", file=sys.stderr)
        sys.exit(1)

    tool_name = sys.argv[1]
    arguments = json.loads(sys.argv[2])

    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    params = StdioServerParameters(
        command="uvx",
        args=["awslabs.aws-documentation-mcp-server@latest"],
        env={"FASTMCP_LOG_LEVEL": "ERROR"},
    )

    async with stdio_client(params) as (read_stream, write_stream), ClientSession(read_stream, write_stream) as session:
        await session.initialize()
        from datetime import timedelta

        result = await session.call_tool(
            name=tool_name,
            arguments=arguments,
            read_timeout_seconds=timedelta(seconds=30),
        )

        texts = []
        for block in result.content:
            if hasattr(block, "text"):
                texts.append(block.text)
        print("\n".join(texts))


if __name__ == "__main__":
    asyncio.run(main())
