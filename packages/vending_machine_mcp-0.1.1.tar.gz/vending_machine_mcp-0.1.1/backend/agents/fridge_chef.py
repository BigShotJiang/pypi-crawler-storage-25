"""
Fridge Chef - LangGraph agent for recipe generation from ingredients.

State machine: assess → cook → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "fridge-chef"

SYSTEM_PROMPT = """You are the Fridge Chef — a resourceful, zero-waste cooking assistant who lives inside a vending machine. You turn whatever people have into something delicious.

## Personality
- Warm and encouraging. "You've got more to work with than you think!"
- Practical over fancy. You'd rather make a great quesadilla than a mediocre soufflé.
- You think in constraints: what's available, dietary restrictions, time, skill level.
- Occasional food puns. "Lettuce begin!"

## Specialties
- Ingredient-based recipe generation (what's in your fridge?)
- Meal planning from available ingredients
- Dietary restriction adaptation (vegan, gluten-free, keto, etc.)
- Cooking time estimation and difficulty rating
- Substitution suggestions for missing ingredients
- Nutrition estimates

## Rules
1. Always ask: What ingredients are available? Any restrictions?
2. Suggest 1-3 recipes ranked by simplicity.
3. Include prep time, cook time, and difficulty (Easy/Medium/Hard).
4. List exact measurements when possible.
5. Suggest substitutions for uncommon ingredients.
6. Flag common allergens explicitly.
7. Never assume specialized equipment — use common kitchen tools."""


class AgentState(TypedDict):
    task: str
    assessment: str
    recipe: str
    review: str
    current_step: str


def _get_llm():
    return get_llm(AGENT_ID, temperature=0.5)


def assess_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs cooking help:\n\n{state['task']}\n\n"
                "Assess: What ingredients/constraints are we working with? "
                "What cuisine directions make sense? Brief plan (3-5 points)."
            ),
        ]
    )
    return {
        "assessment": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def cook_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Cooking request: {state['task']}\n\nYour assessment:\n{state['assessment']}\n\n"
                "Now provide 1-3 recipes. For each include: name, difficulty, "
                "prep/cook time, ingredients list with measurements, step-by-step instructions, "
                "and any substitution notes."
            ),
        ]
    )
    return {
        "recipe": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review these recipes:\n\n{state['recipe']}\n\n"
                "Check for: missing steps, allergen warnings, unrealistic times, "
                "and whether a normal kitchen could handle this. Brief review (max 5 items). "
                "End with: CHEF'S VERDICT: [CHEF'S KISS / SOLID MEAL / NEEDS SEASONING]."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_fridge_chef_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("assess", assess_node)
    workflow.add_node("cook", cook_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("assess")
    workflow.add_edge("assess", "cook")
    workflow.add_edge("cook", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
