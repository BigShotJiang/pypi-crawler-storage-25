"""
Research Owl - LangGraph agent for deep research and structured reports.

Uses two OpenAI models via direct API:
  - o3-deep-research for the research/gathering phase
  - gpt-5.4-mini for planning and report writing

State machine: plan → research → report → review → END
"""

import os
import time
from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph
from openai import OpenAI

from agents.llm import get_research_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

SYSTEM_PROMPT = """You are the Research Owl — a meticulous, citation-obsessed academic who lives inside a vending machine. You produce structured research reports with verified sources.

## Personality
- Precise and thorough. You present findings in clean, hierarchical structure.
- You always cite your reasoning, even when speculating.
- You separate FACTS from OPINIONS clearly.
- You speak like a professor who genuinely loves their subject.
- You occasionally say things like "fascinating footnote:" or "the literature suggests..."

## Specialties
- Topic deep-dives with structured sections
- Comparative analysis (pros/cons, options, alternatives)
- Fact-checking and source evaluation
- Literature reviews and trend analysis
- Executive summaries with confidence ratings

## Rules
1. Always structure output with clear headings and bullet points.
2. Mark speculative claims with [OPINION] or [UNVERIFIED].
3. Provide 3-5 key takeaways at the end.
4. If the topic is too broad, narrow it and state your scope.
5. Be honest about knowledge gaps — "I don't have data on X" is fine.
6. Never fabricate citations. State when you're reasoning from general knowledge."""


class AgentState(TypedDict):
    task: str
    plan: str
    research: str
    report: str
    review: str
    current_step: str


def plan_node(state: AgentState) -> dict:
    """Plan the research approach — uses gpt-5.4-mini for fast planning."""
    llm = get_research_llm("report", temperature=0.3, max_tokens=2048)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user hired you to research:\n\n{state['task']}\n\n"
                "Create a brief research plan (3-5 bullet points). "
                "What angles will you cover? What's the scope? Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def research_node(state: AgentState) -> dict:
    """Deep research phase — uses o3-deep-research via OpenAI Responses API."""
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))

    prompt = (
        f"{SYSTEM_PROMPT}\n\n"
        f"Research topic: {state['task']}\n\nYour plan:\n{state['plan']}\n\n"
        "Conduct thorough research on this topic. Gather key facts, data points, "
        "expert perspectives, and relevant context. Be comprehensive but organized. "
        "Cite sources where possible."
    )

    response = client.responses.create(
        model="o3-deep-research",
        input=prompt,
        tools=[{"type": "web_search_preview"}],
    )

    # Poll if background — deep research can take up to 30 minutes
    poll_start = time.time()
    max_poll_seconds = 1800  # 30 minutes
    while response.status == "queued" or response.status == "in_progress":
        if time.time() - poll_start > max_poll_seconds:
            raise TimeoutError(
                f"Research Owl deep research timed out after {max_poll_seconds // 60} minutes. "
                "The query may be too broad — try narrowing your research topic."
            )
        time.sleep(2)
        response = client.responses.retrieve(response.id)

    # Extract text from the response output items
    text_parts = []
    for item in response.output:
        if hasattr(item, "text"):
            text_parts.append(item.text)
        elif hasattr(item, "content") and isinstance(item.content, list):
            for block in item.content:
                if hasattr(block, "text"):
                    text_parts.append(block.text)

    return {"research": "\n".join(text_parts).strip() or str(response.output), "current_step": "coding"}


def report_node(state: AgentState) -> dict:
    """Write the polished report — uses gpt-5.4-mini for clear, structured writing."""
    llm = get_research_llm("report", temperature=0.4, max_tokens=8192)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Research topic: {state['task']}\n\n"
                f"Raw research findings:\n{state['research']}\n\n"
                "Now write the final polished report. Use markdown headings, bullet points, "
                "and clearly separate facts from opinions. Include a Key Takeaways section at the end. "
                "Make it clear, well-structured, and publication-ready."
            ),
        ]
    )
    return {
        "report": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    """Review the report for gaps — uses gpt-5.4-mini."""
    llm = get_research_llm("report", temperature=0.2, max_tokens=2048)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this research report for gaps, bias, and accuracy:\n\n{state['report']}\n\n"
                "List any gaps or caveats (max 5 items). Rate overall confidence: HIGH / MEDIUM / LOW."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_research_owl_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("plan", plan_node)
    workflow.add_node("research", research_node)
    workflow.add_node("report", report_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("plan")
    workflow.add_edge("plan", "research")
    workflow.add_edge("research", "report")
    workflow.add_edge("report", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
