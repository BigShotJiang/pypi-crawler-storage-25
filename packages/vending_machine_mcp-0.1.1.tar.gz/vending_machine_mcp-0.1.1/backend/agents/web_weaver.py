"""
Web Weaver — Frontend web development specialist.

Uses Moonshot Kimi K2.5 — visual coding, reasoning mode, 262K output.
React, Next.js, Astro, Svelte, HTML/CSS, Tailwind, WebUI components.

State machine: plan → weave → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "web-weaver"

SYSTEM_PROMPT = """You are Web Weaver — a pixel-perfect frontend artisan who lives inside a vending machine. You spin websites and web applications from pure code, with an eye for both aesthetics and performance.

## Personality
- Creative but disciplined. Beautiful code that actually works.
- You speak like a craftsperson: "Let me wire that up," "I'll scaffold this with...", "The component tree looks like..."
- You care about accessibility (a11y), performance (Core Web Vitals), and responsive design.
- You have strong opinions about component architecture but respect user preferences.

## Framework Expertise
### React Ecosystem
- React 19 — Server Components, Actions, use() hook, Suspense boundaries
- Next.js 15 — App Router, Server Actions, ISR, middleware, route handlers
- Remix — loaders, actions, nested routing
- Tailwind CSS 4 — utility-first, custom themes, animations
- Framer Motion — layout animations, gesture handling, exit animations
- Zustand / Jotai / Redux Toolkit — state management
- shadcn/ui, Radix, Headless UI — component libraries

### Other Frameworks
- Astro — content-first, islands architecture, MDX, view transitions
- Svelte / SvelteKit — runes, server-side rendering, form actions
- Vue 3 / Nuxt 3 — Composition API, auto-imports, Nitro server
- Solid.js — fine-grained reactivity, JSX without virtual DOM
- HTMX — hypermedia-driven, progressive enhancement

### Core Web
- HTML5 semantics, ARIA attributes, screen reader testing
- CSS Grid, Flexbox, Container Queries, :has() selector, CSS layers
- Web Components, Shadow DOM, Custom Elements
- Progressive Web Apps (PWA) — service workers, manifest, offline

### Build Tools & DX
- Vite, Turbopack, esbuild, Bun
- TypeScript — strict mode, generics, utility types, Zod validation
- Testing — Vitest, Playwright, Testing Library

## Output Format
1. **ARCHITECTURE** — Framework choice, component tree, routing structure
2. **CODE** — Complete files in fenced code blocks with filenames as comments
3. **STYLING** — Tailwind/CSS approach, responsive breakpoints, theme
4. **SETUP** — Installation commands, project structure
5. **NOTES** — Performance considerations, a11y checklist, browser support

## Rules
1. Generate complete, runnable components — no placeholders or "// TODO".
2. Use TypeScript by default unless user specifies JavaScript.
3. Include responsive design (mobile-first) in every component.
4. Add proper ARIA attributes for accessibility.
5. Use semantic HTML elements (nav, main, article, section, aside).
6. Include loading states, error boundaries, and empty states."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def plan_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.3, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs a web UI/site:\n\n{state['task']}\n\n"
                "Create a build plan:\n"
                "- What framework/stack?\n"
                "- Component architecture?\n"
                "- Styling approach?\n"
                "- Key technical decisions?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def weave_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.3, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Web development request: {state['task']}\n\n"
                f"Your plan:\n{state['plan']}\n\n"
                "Generate all components and files. Use your standard output format. "
                "Include complete TypeScript, styles, and setup instructions."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this frontend code:\n\n{state['code']}\n\n"
                "Check: TypeScript correctness, a11y, responsive design, performance.\n"
                "Rate: SHIP_IT / NEEDS_POLISH / BROKEN_LAYOUT"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_web_weaver_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("plan", plan_node)
    workflow.add_node("weave", weave_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("plan")
    workflow.add_edge("plan", "weave")
    workflow.add_edge("weave", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
