"""
CEO Agent — Claude Agent SDK orchestrator with MCP tool access.

Uses Anthropic's Claude Agent SDK (not LangGraph) with:
  - Custom hire_agent tool to delegate to other Vending Machine agents
  - MCP tools from user's connected servers
  - Real-time progress streaming via callback

Runs in the job queue or via dedicated /ws/ceo WebSocket.
"""

import asyncio
import logging
import os
import time
import uuid
from collections.abc import Awaitable, Callable
from typing import Any

import httpx

from jobs import get_job, update_job
from mcp_registry import get_enabled_servers
from pricing import calculate_cost, format_cost

logger = logging.getLogger("ceo_agent")

# ---------------------------------------------------------------------------
# Lazy import — Claude Agent SDK is optional
# ---------------------------------------------------------------------------
_sdk_available = False
try:
    from claude_agent_sdk import (
        AssistantMessage,
        ClaudeAgentOptions,
        ResultMessage,
        TextBlock,
        create_sdk_mcp_server,
        query,
        tool,
    )

    _sdk_available = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Agent roster (available for delegation)
# ---------------------------------------------------------------------------
HIREABLE_AGENTS = {
    # ── Coders ──
    "code-gremlin": "Code Gremlin — writes scripts in Python, Bash, PowerShell, Node.js (gpt-5.3-codex)",
    "mcp-maker": "MCP Maker — generates MCP server code in Python/TypeScript/Go (qwen3-coder-480B)",
    "web-weaver": "Web Weaver — frontend dev: React, Next.js, Astro, Svelte, HTML/CSS (kimi-k2.5, 262K output)",
    "devops-dwarf": "DevOps Dwarf — Docker, Terraform, CI/CD, GitHub Actions, Kubernetes (gpt-5.3-codex)",
    "test-goblin": "Test Goblin — unit tests, integration tests, edge cases (qwen3-coder-480B)",
    "bug-hunter": "Bug Hunter — code review, debugging, security audit (deepseek-v3.2)",
    # ── Researchers ──
    "info-scout": "Info Scout — fast research and intelligence gathering, seconds not minutes (qwen3.6-plus, FREE)",
    "research-owl": "Research Owl — deep academic research with verified sources (o4-mini-deep-research, SLOW: 5-30min)",
    # ── Data & Documents ──
    "data-sprite": "Data Sprite — SQL, ETL, schema design for ALL databases: Postgres, Mongo, DynamoDB, Supabase, etc. (minimax-m2.7)",
    "number-crunch": "Number Crunch — data analysis, trends, and visualization (minimax-m2.7)",
    "spreadsheet-sage": "Spreadsheet Sage — Excel formulas, pivot tables, VBA, Google Sheets (minimax-m2.7)",
    "pdf-forge": "PDF Forge — creates perfectly formatted PDFs, reports, invoices (claude-sonnet-4.6)",
    "embeddings-agent": "Embeddings Agent — file embedding and semantic analysis (deepseek-v3.2)",
    # ── Cloud & Ops ──
    "cloud-sensei": "Cloud Sensei — AWS architecture, troubleshooting, cost optimization (mimo-v2-pro, 1M context)",
    # ── Communication & Admin ──
    "inbox-zero": "Inbox Zero — sorts, labels, and summarizes email (deepseek-v3.2)",
    "vibe-writer": "Vibe Writer — ghostwriting for LinkedIn, Twitter, newsletters (kimi-k2.5)",
    "desk-pilot": "Desk Pilot — admin assistant: scheduling, SOPs, meeting prep, email drafts (qwen3.6-plus, FREE)",
    "fridge-chef": "Fridge Chef — recipes from ingredients (qwen3.6-plus, FREE)",
}

API_BASE = "http://localhost:8000"

# Max chars to pass back from a sub-agent's output to the CEO.
# The CEO runs on claude-sonnet-4-6 (1M context) so it can handle large
# tool results. 400K chars ≈ 100K tokens — leaves ~900K tokens for the
# CEO's system prompt, other tool calls, and its own output generation.
# Coding agents can produce up to 128K output tokens (~500K chars), so
# this limit ensures full code outputs are never truncated.
_MAX_DELEGATION_OUTPUT = 400_000

# Type alias for the progress callback
ProgressCallback = Callable[[dict], Awaitable[None]] | None


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------
def _build_system_prompt(mcp_tool_names: list[str]) -> str:
    agent_list = "\n".join(f"  - {aid}: {desc}" for aid, desc in HIREABLE_AGENTS.items())

    tool_section = ""
    if mcp_tool_names:
        tool_list = ", ".join(mcp_tool_names[:20])
        tool_section = f"""
## Connected MCP Tools
You have access to these external tools: {tool_list}
Use them when the task requires interacting with external services (GitHub, filesystem, search, etc.).

### GitHub MCP Usage Guide
When pushing code to GitHub, you MUST use the GitHub MCP tools (NOT git CLI commands):
- Use `create_or_update_file` to push each file individually. It takes: owner, repo, path, content, message, branch, sha (for updates).
- For new repos/branches, omit the `sha` parameter.
- Push files ONE AT A TIME — there is no batch push. Plan for this.
- To push many files efficiently:
  1. Collect all file contents from agent delegations
  2. Push them sequentially using create_or_update_file
  3. Use a consistent commit message prefix like "feat: add <component>"
- NEVER use shell commands like `git push` — you don't have shell access.
- To check if a file exists: use `get_file_contents` (returns sha needed for updates).
- To create a PR: use `create_pull_request` after pushing to a feature branch.
"""

    return f"""You are the CEO Agent — the boss of the Vending Machine AI marketplace. You orchestrate complex tasks by combining MCP tools and delegating sub-tasks to specialized agents.

## Personality
- Strategic and decisive. You think before you act.
- You delegate ruthlessly — never do a specialist's job yourself.
- You speak like a concise executive: "Here's the plan. Here's what I did. Here's the result."
- You track what worked and what didn't.

## Available Agents for Delegation
You can hire these agents via the hire_agent tool:
{agent_list}

{tool_section}

## Rules
1. Break complex tasks into sub-tasks and delegate to the right specialist.
2. Use MCP tools directly when the task involves external services.
3. Always synthesize results from multiple delegations into a clear summary.
4. If a delegation fails, try an alternative approach or report what went wrong.
5. Never fabricate results — if you don't have the data, say so.
6. Keep the user informed of your plan and progress.
7. CRITICAL: If your plan involves multiple delegations, you MUST complete ALL of them before writing your final summary. Never stop after a partial set — the user is paying for the full deliverable. If you planned 5 agents, hire all 5.
8. When possible, run independent delegations in parallel by calling hire_agent multiple times before waiting for results.

## Workflow
1. Analyze the task and create a brief plan
2. Execute — use MCP tools and/or hire agents
3. Synthesize results into a clear deliverable
4. Review your own output for completeness"""


# ---------------------------------------------------------------------------
# hire_agent tool definition (used by Claude Agent SDK)
# ---------------------------------------------------------------------------
def _build_hire_agent_tool(job_id: str, progress_cb: ProgressCallback, delegation_costs: list):
    """Build the hire_agent tool function with closures for job tracking and progress.

    delegation_costs: mutable list that accumulates per-delegation cost records.
    Each entry: {"agent_id", "agent_name", "model", "input_tokens", "output_tokens", "cost", "runtime_ms"}
    """
    if not _sdk_available:
        raise RuntimeError("Claude Agent SDK not installed")

    @tool(
        "hire_agent",
        "Hire a specialized Vending Machine agent to perform a sub-task. "
        "The agent runs asynchronously and returns its output when complete.",
        {
            "type": "object",
            "properties": {
                "agent_id": {
                    "type": "string",
                    "enum": list(HIREABLE_AGENTS.keys()),
                    "description": "ID of the agent to hire",
                },
                "task": {
                    "type": "string",
                    "description": "Task description for the agent",
                },
            },
            "required": ["agent_id", "task"],
        },
    )
    async def hire_agent(args: dict[str, Any]) -> dict[str, Any]:
        agent_id = args["agent_id"]
        task_desc = args["task"]

        if agent_id not in HIREABLE_AGENTS:
            return {
                "content": [{"type": "text", "text": f"Unknown agent: {agent_id}"}],
                "is_error": True,
            }

        agent_name = HIREABLE_AGENTS[agent_id].split(" — ")[0]
        delegation_id = str(uuid.uuid4())[:8]

        # Emit delegation_start event
        if progress_cb:
            await progress_cb(
                {
                    "type": "delegation_start",
                    "delegationId": delegation_id,
                    "agentId": agent_id,
                    "agentName": agent_name,
                    "task": task_desc[:200],
                }
            )

        # Update CEO job store with delegation step
        ceo_job = get_job(job_id)
        if ceo_job:
            steps = ceo_job["steps"]
            steps.append(
                {
                    "step": "delegating",
                    "output": f"> Hiring {agent_name} for: {task_desc[:100]}",
                }
            )
            update_job(job_id, steps=steps)

        # Submit sub-task via REST API (loopback to local backend)
        sub_job_id = None
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(
                    f"{API_BASE}/api/jobs",
                    json={"agent_id": agent_id, "task": task_desc},
                )
                sub_job = resp.json()
                sub_job_id = sub_job.get("job_id")
                if not sub_job_id:
                    error_msg = f"Error submitting job: {sub_job}"
                    if progress_cb:
                        await progress_cb(
                            {
                                "type": "delegation_complete",
                                "delegationId": delegation_id,
                                "agentId": agent_id,
                                "result": error_msg,
                                "success": False,
                            }
                        )
                    return {"content": [{"type": "text", "text": error_msg}], "is_error": True}
        except Exception as e:
            error_msg = f"Error connecting to backend: {e}"
            if progress_cb:
                await progress_cb(
                    {
                        "type": "delegation_complete",
                        "delegationId": delegation_id,
                        "agentId": agent_id,
                        "result": error_msg,
                        "success": False,
                    }
                )
            return {"content": [{"type": "text", "text": error_msg}], "is_error": True}

        # Poll for completion (max 5 minutes)
        max_wait = 600  # 10 min — large code generation tasks can take 5+ min
        start = time.time()
        while time.time() - start < max_wait:
            try:
                async with httpx.AsyncClient(timeout=10) as client:
                    resp = await client.get(f"{API_BASE}/api/jobs/{sub_job_id}")
                    result = resp.json()

                status = result.get("status")
                if status == "complete":
                    output = result.get("output", "")
                    if len(output) > _MAX_DELEGATION_OUTPUT:
                        output = (
                            output[:_MAX_DELEGATION_OUTPUT] + "\n\n[Output truncated — full result available in inbox]"
                        )

                    # Extract cost metadata from completed sub-job
                    meta = result.get("metadata", {})
                    delegation_costs.append(
                        {
                            "agent_id": agent_id,
                            "agent_name": agent_name,
                            "model": meta.get("model", "unknown"),
                            "input_tokens": meta.get("inputTokens", 0),
                            "output_tokens": meta.get("outputTokens", 0),
                            "cost": meta.get("cost", 0),
                            "runtime_ms": meta.get("runtimeMs", 0),
                        }
                    )

                    if progress_cb:
                        await progress_cb(
                            {
                                "type": "delegation_complete",
                                "delegationId": delegation_id,
                                "agentId": agent_id,
                                "result": output[:500],
                                "success": True,
                                "cost": meta.get("cost", 0),
                            }
                        )

                    return {"content": [{"type": "text", "text": f"Agent {agent_id} completed:\n\n{output}"}]}

                elif status == "error":
                    error_msg = result.get("error", "Unknown error")
                    if progress_cb:
                        await progress_cb(
                            {
                                "type": "delegation_complete",
                                "delegationId": delegation_id,
                                "agentId": agent_id,
                                "result": error_msg,
                                "success": False,
                            }
                        )
                    return {
                        "content": [{"type": "text", "text": f"Agent {agent_id} failed: {error_msg}"}],
                        "is_error": True,
                    }

            except Exception:
                logger.debug("Polling sub-job %s failed, retrying...", sub_job_id)

            await asyncio.sleep(3)

        timeout_msg = f"Agent {agent_id} timed out after {max_wait}s."
        if progress_cb:
            await progress_cb(
                {
                    "type": "delegation_complete",
                    "delegationId": delegation_id,
                    "agentId": agent_id,
                    "result": timeout_msg,
                    "success": False,
                }
            )
        return {"content": [{"type": "text", "text": timeout_msg}], "is_error": True}

    return hire_agent


# ---------------------------------------------------------------------------
# MCP server config builder
# ---------------------------------------------------------------------------
def _build_mcp_server_configs() -> tuple[dict[str, Any], list[str]]:
    """Translate registry MCP servers into Claude Agent SDK mcp_servers format.

    Returns (mcp_servers_dict, tool_name_hints) where tool_name_hints are
    the expected tool name prefixes for allowed_tools.
    """
    enabled = get_enabled_servers()
    if not enabled:
        return {}, []

    mcp_servers: dict[str, Any] = {}
    tool_hints: list[str] = []

    for server in enabled:
        # Sanitize name for use as dict key (no spaces)
        key = server["name"].lower().replace(" ", "_")

        if server["transport"] == "stdio":
            if not server.get("command"):
                continue
            mcp_servers[key] = {
                "command": server["command"],
                "args": server.get("args", []),
                "env": {k: v for k, v in server.get("env", {}).items() if v},
            }
        elif server["transport"] in ("sse", "http"):
            url = server.get("url", "")
            if not url:
                continue
            mcp_servers[key] = {
                "url": url,
                "transport": server["transport"],
            }
        else:
            continue

        tool_hints.append(f"mcp__{key}__*")

    return mcp_servers, tool_hints


# ---------------------------------------------------------------------------
# Cost breakdown formatter
# ---------------------------------------------------------------------------
def _format_cost_breakdown(delegation_costs: list, ceo_cost: float) -> str:
    """Format a markdown cost breakdown table for the CEO's final output."""
    if not delegation_costs:
        return ""

    lines = [
        "",
        "---",
        "### 💰 Cost Breakdown",
        "",
        "| Agent | Model | In Tokens | Out Tokens | Cost |",
        "|-------|-------|-----------|------------|------|",
    ]

    total_in = 0
    total_out = 0
    total_cost = 0.0

    for d in delegation_costs:
        model_short = d["model"].split("/")[-1] if "/" in d["model"] else d["model"]
        in_tok = d["input_tokens"]
        out_tok = d["output_tokens"]
        cost = d["cost"]
        total_in += in_tok
        total_out += out_tok
        total_cost += cost
        lines.append(f"| {d['agent_name']} | {model_short} | {in_tok:,} | {out_tok:,} | {format_cost(cost)} |")

    # Add CEO's own cost row
    total_cost += ceo_cost
    lines.append(f"| CEO (self) | claude-sonnet-4-6 | — | — | {format_cost(ceo_cost)} |")

    lines.append(f"| **TOTAL** | | **{total_in:,}** | **{total_out:,}** | **{format_cost(total_cost)}** |")
    lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
async def run_ceo_agent(
    task: str,
    job_id: str,
    progress_callback: ProgressCallback = None,
) -> None:
    """Run the CEO agent for a given task.

    Streams progress events via progress_callback (if provided) and
    updates the job store with steps/output throughout execution.
    """
    if not _sdk_available:
        raise RuntimeError("Claude Agent SDK not installed. Run: pip install claude-agent-sdk")

    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not set")

    # Record initial thinking step
    ceo_job = get_job(job_id)
    if ceo_job:
        ceo_job["steps"].append(
            {
                "step": "thinking",
                "output": f'> CEO Agent analyzing task: "{task[:100]}"\n> Loading connected tools...',
            }
        )
        update_job(job_id, steps=ceo_job["steps"], output=f"> Analyzing: {task[:100]}")

    if progress_callback:
        await progress_callback(
            {
                "type": "planning",
                "plan": f"Analyzing task: {task[:200]}",
            }
        )

    # Build MCP server configs from registry
    mcp_servers, mcp_tool_hints = _build_mcp_server_configs()

    # Collect MCP tool names for system prompt
    mcp_tool_names = [h.replace("mcp__", "").replace("__*", "") for h in mcp_tool_hints]

    # Track per-delegation costs for final breakdown
    delegation_costs: list[dict] = []

    # Build the hire_agent tool as an SDK MCP server
    hire_tool = _build_hire_agent_tool(job_id, progress_callback, delegation_costs)
    agent_tools_server = create_sdk_mcp_server(
        name="vending_machine",
        version="1.0.0",
        tools=[hire_tool],
    )

    # Merge MCP servers
    all_mcp_servers = {"vending_machine": agent_tools_server, **mcp_servers}

    # Build allowed tools list
    allowed_tools = ["mcp__vending_machine__hire_agent", *mcp_tool_hints]

    # Build options
    system_prompt = _build_system_prompt(mcp_tool_names)
    options = ClaudeAgentOptions(
        model="claude-sonnet-4-6",
        system_prompt=system_prompt,
        mcp_servers=all_mcp_servers,
        allowed_tools=allowed_tools,
        max_turns=200,
        permission_mode="bypassPermissions",
    )

    # Run the agent and stream progress
    all_outputs: list[str] = []
    start_time = time.time()

    try:
        async for message in query(prompt=task, options=options):
            if isinstance(message, AssistantMessage):
                for block in message.content:
                    if isinstance(block, TextBlock) and block.text.strip():
                        text = block.text.strip()
                        all_outputs.append(text)

                        # Detect if this is planning vs synthesis
                        # First text block = planning, subsequent = synthesis
                        event_type = "planning" if len(all_outputs) == 1 else "synthesizing"
                        if progress_callback:
                            await progress_callback(
                                {
                                    "type": event_type,
                                    "plan" if event_type == "planning" else "partial": text,
                                }
                            )

                        # Update job store
                        ceo_job = get_job(job_id)
                        if ceo_job:
                            ceo_job["steps"].append(
                                {
                                    "step": "thinking" if event_type == "planning" else "coding",
                                    "output": text,
                                }
                            )
                            update_job(job_id, steps=ceo_job["steps"], output="\n\n".join(all_outputs))

            elif isinstance(message, ResultMessage):
                elapsed_ms = int((time.time() - start_time) * 1000)
                final_output = message.result or "\n\n".join(all_outputs)

                # Estimate CEO's own cost (Claude Sonnet 4.6 via Anthropic direct)
                ceo_input_est = len(task) // 3 + 2000  # task + system prompt
                ceo_output_est = len(final_output) // 3
                ceo_cost = calculate_cost("claude-sonnet-4-6", ceo_input_est, ceo_output_est)

                # Append cost breakdown table if any delegations occurred
                cost_breakdown = _format_cost_breakdown(delegation_costs, ceo_cost)
                if cost_breakdown:
                    final_output += cost_breakdown

                # Calculate total cost (delegations + CEO)
                total_delegation_cost = sum(d["cost"] for d in delegation_costs)
                total_cost = total_delegation_cost + ceo_cost
                total_in = sum(d["input_tokens"] for d in delegation_costs) + ceo_input_est
                total_out = sum(d["output_tokens"] for d in delegation_costs) + ceo_output_est

                if progress_callback:
                    await progress_callback(
                        {
                            "type": "complete",
                            "output": final_output,
                            "runtimeMs": elapsed_ms,
                            "inputTokens": total_in,
                            "outputTokens": total_out,
                            "cost": round(total_cost, 6),
                        }
                    )

                # Finalize job store
                ceo_job = get_job(job_id)
                if ceo_job:
                    ceo_job["steps"].append(
                        {
                            "step": "complete",
                            "output": f"> CEO Agent finished.\n{'─' * 40}\n{final_output}\n{'─' * 40}",
                        }
                    )
                    step_outputs = [s["output"] for s in ceo_job["steps"]]
                    update_job(
                        job_id,
                        steps=ceo_job["steps"],
                        output="\n".join(step_outputs),
                        metadata={
                            "agentId": "ceo-agent",
                            "agentName": "CEO Agent",
                            "model": "claude-sonnet-4-6",
                            "runtimeMs": elapsed_ms,
                            "inputTokens": total_in,
                            "outputTokens": total_out,
                            "cost": round(total_cost, 6),
                            "timestamp": int(time.time() * 1000),
                            "delegations": [
                                {
                                    "agentId": d["agent_id"],
                                    "agentName": d["agent_name"],
                                    "model": d["model"],
                                    "inputTokens": d["input_tokens"],
                                    "outputTokens": d["output_tokens"],
                                    "cost": d["cost"],
                                    "runtimeMs": d["runtime_ms"],
                                }
                                for d in delegation_costs
                            ],
                        },
                    )

    except Exception as e:
        if progress_callback:
            await progress_callback({"type": "error", "message": str(e)})
        raise
