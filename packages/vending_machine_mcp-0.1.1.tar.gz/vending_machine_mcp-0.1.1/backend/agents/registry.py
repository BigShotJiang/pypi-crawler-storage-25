"""
Agent registry — shared graphs, names, and helper functions.

Centralizes agent compilation so both the WebSocket handler and
the job runner can import from the same place.
"""

from agents.bug_hunter import build_bug_hunter_graph
from agents.cloud_sensei import build_cloud_sensei_graph
from agents.code_gremlin import build_code_gremlin_graph
from agents.data_sprite import build_data_sprite_graph
from agents.desk_pilot import build_desk_pilot_graph
from agents.devops_dwarf import build_devops_dwarf_graph
from agents.embeddings import build_embeddings_agent_graph
from agents.fridge_chef import build_fridge_chef_graph
from agents.inbox_zero import build_inbox_zero_graph
from agents.info_scout import build_info_scout_graph
from agents.mcp_maker import build_mcp_maker_graph
from agents.number_crunch import build_number_crunch_graph
from agents.pdf_forge import build_pdf_forge_graph
from agents.research_owl import build_research_owl_graph
from agents.spreadsheet_sage import build_spreadsheet_sage_graph
from agents.test_goblin import build_test_goblin_graph
from agents.vibe_writer import build_vibe_writer_graph
from agents.web_weaver import build_web_weaver_graph

# Pre-compile agents at import time
AGENT_GRAPHS = {
    # Original agents
    "code-gremlin": build_code_gremlin_graph(),
    "research-owl": build_research_owl_graph(),
    "inbox-zero": build_inbox_zero_graph(),
    "vibe-writer": build_vibe_writer_graph(),
    "number-crunch": build_number_crunch_graph(),
    "fridge-chef": build_fridge_chef_graph(),
    "mcp-maker": build_mcp_maker_graph(),
    "embeddings-agent": build_embeddings_agent_graph(),
    "info-scout": build_info_scout_graph(),
    # New agents
    "bug-hunter": build_bug_hunter_graph(),
    "devops-dwarf": build_devops_dwarf_graph(),
    "test-goblin": build_test_goblin_graph(),
    "data-sprite": build_data_sprite_graph(),
    "spreadsheet-sage": build_spreadsheet_sage_graph(),
    "pdf-forge": build_pdf_forge_graph(),
    "web-weaver": build_web_weaver_graph(),
    "cloud-sensei": build_cloud_sensei_graph(),
    "desk-pilot": build_desk_pilot_graph(),
}

AGENT_NAMES = {
    # Original agents
    "code-gremlin": "Code Gremlin",
    "research-owl": "Research Owl",
    "inbox-zero": "Inbox Zero",
    "vibe-writer": "Vibe Writer",
    "number-crunch": "Number Crunch",
    "fridge-chef": "Fridge Chef",
    "mcp-maker": "MCP Maker",
    "embeddings-agent": "Embeddings Agent",
    "ceo-agent": "CEO Agent",
    "info-scout": "Info Scout",
    # New agents
    "bug-hunter": "Bug Hunter",
    "devops-dwarf": "DevOps Dwarf",
    "test-goblin": "Test Goblin",
    "data-sprite": "Data Sprite",
    "spreadsheet-sage": "Spreadsheet Sage",
    "pdf-forge": "PDF Forge",
    "web-weaver": "Web Weaver",
    "cloud-sensei": "Cloud Sensei",
    "desk-pilot": "Desk Pilot",
}


def build_initial_state(task: str, **extra) -> dict:
    """Build a universal initial state dict that works for all agents.

    If file_content is provided in extra, it's appended to the task
    so all agents automatically see the uploaded file in their prompts.

    Also stores model routing info if a file upload triggered a model upgrade.
    """
    # If a file was uploaded, enrich the task with file content
    file_content = extra.get("file_content", "")
    file_name = extra.get("file_name", "")
    enriched_task = task
    if file_content:
        file_lines = len(file_content.splitlines())
        file_tokens_est = len(file_content) // 3  # conservative estimate
        enriched_task = (
            f"{task}\n\n"
            f"--- UPLOADED FILE: {file_name} ({file_lines:,} lines, ~{file_tokens_est:,} tokens) ---\n"
            f"{file_content}\n"
            f"--- END OF FILE ---"
        )

    state = {
        "task": enriched_task,
        "current_step": "idle",
        "plan": "",
        "code": "",
        "review": "",
        "messages": [],
        "research": "",
        "analysis": "",
        "organization": "",
        "voice_analysis": "",
        "draft": "",
        "computation": "",
        "assessment": "",
        "recipe": "",
        "report": "",
        # File upload fields (preserved for agents that need raw access)
        "file_content": file_content,
        "file_name": file_name,
        "provider": "",
        "embeddings_result": "",
        # Embeddings agent extended fields
        "mode": "",
        "chunk_strategy": "",
        "model": "",
        "dimensions": None,
        "encoding_format": None,
        "input_type": None,
        "task_type": None,
        "output_dtype": None,
        "output_format": "",
        "batch_job_id": None,
        "batch_status": None,
        "chunks": [],
        "embeddings": None,
        "metadata_sidecar": None,
        "multimodal": False,
        "file_bytes_b64": None,
        "file_mime_type": None,
        # Model routing override (set by job_runner when upload triggers upgrade)
        "model_override": extra.get("model_override"),
        # Token tracking (accumulated across all nodes)
        "token_usage": {"input_tokens": 0, "output_tokens": 0},
    }
    state.update(extra)
    return state


def format_step_output(step: str, state_update: dict) -> str:
    """Format a step's state update into terminal-friendly output."""
    if step == "thinking":
        plan = (
            state_update.get("plan")
            or state_update.get("analysis")
            or state_update.get("voice_analysis")
            or state_update.get("assessment")
            or ""
        )
        return f"\n> Strategy:\n{plan}"
    elif step == "coding":
        content = (
            state_update.get("code")
            or state_update.get("research")
            or state_update.get("report")
            or state_update.get("organization")
            or state_update.get("draft")
            or state_update.get("computation")
            or state_update.get("recipe")
            or state_update.get("embeddings_result")
            or ""
        )
        return f"\n> Generating output...\n{'─' * 40}\n{content}\n{'─' * 40}"
    elif step == "researching":
        research = state_update.get("research", "")
        preview = research[:500] if research else ""
        return f"\n> Searching AWS documentation...\n{preview}"
    elif step == "reviewing":
        return f"\n> Running review...\n{state_update.get('review', '')}"
    elif step == "tool_call":
        return state_update.get("output", "\n> Calling MCP tool...")
    elif step == "delegating":
        return state_update.get("output", "\n> Hiring agent...")
    else:
        return f"\n> Step: {step}"


def estimate_tokens(text: str) -> int:
    """Rough token estimate — ~4 chars per token for English text."""
    if not text:
        return 0
    return max(1, len(text) // 4)
