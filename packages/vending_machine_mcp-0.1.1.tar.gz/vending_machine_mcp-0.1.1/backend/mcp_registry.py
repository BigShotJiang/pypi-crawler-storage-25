"""
In-memory MCP server registry.

Stores MCP server configurations that agents can connect to.
Pre-seeds popular MCP servers (all disabled by default).
No database — just a dict, same pattern as jobs.py.
"""

import os
import time
import uuid
from typing import Literal, TypedDict


class MCPServerConfig(TypedDict):
    id: str
    name: str
    description: str
    transport: Literal["stdio", "sse", "http"]
    command: str | None  # stdio only: "npx", "uvx", "python"
    args: list[str]  # stdio only: ["-y", "@modelcontextprotocol/server-github"]
    url: str | None  # sse/http only
    env: dict[str, str]  # e.g. {"GITHUB_TOKEN": "ghp_xxx"}
    enabled: bool
    icon: str
    tools_count: int | None  # populated after connection test
    created_at: float


MCP_STORE: dict[str, MCPServerConfig] = {}


def _seed_defaults() -> None:
    """Pre-seed popular MCP servers (all disabled)."""
    defaults: list[dict] = [
        {
            "name": "GitHub",
            "description": "Repository management, issues, pull requests, and code search",
            "transport": "stdio",
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-github"],
            "env": {"GITHUB_TOKEN": ""},
            "icon": "🐙",
        },
        {
            "name": "Filesystem",
            "description": "Read, write, and search files on the local filesystem",
            "transport": "stdio",
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],  # noqa: S108 — MCP filesystem server needs a root path
            "env": {},
            "icon": "📁",
        },
        {
            "name": "Brave Search",
            "description": "Web and news search via the Brave Search API",
            "transport": "stdio",
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-brave-search"],
            "env": {"BRAVE_API_KEY": ""},
            "icon": "🔍",
        },
        {
            "name": "Slack",
            "description": "Read channels, send messages, and manage Slack workspaces",
            "transport": "stdio",
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-slack"],
            "env": {"SLACK_BOT_TOKEN": ""},
            "icon": "💬",
        },
        {
            "name": "CVE Security",
            "description": "Vulnerability intelligence — search CVEs, check packages, AWS bulletins, supply-chain attacks",
            "transport": "stdio",
            "command": "python",
            "args": ["mcp_servers/cve_security/server.py"],
            "env": {"NVD_API_KEY": "", "GITHUB_TOKEN": ""},
            "icon": "🛡️",
        },
        {
            "name": "AWS Documentation",
            "description": "Search, read, and get recommendations from official AWS documentation",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.aws-documentation-mcp-server@latest"],
            "env": {"FASTMCP_LOG_LEVEL": "ERROR"},
            "icon": "☁️",
        },
        {
            "name": "AWS IaC",
            "description": "CloudFormation validation, compliance checking, CDK docs search. No AWS creds needed for validation.",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.aws-iac-mcp-server@latest"],
            "env": {},
            "icon": "🏗️",
        },
        {
            "name": "AWS API",
            "description": "Execute AWS CLI commands, get command suggestions, execution plans. REQUIRES AWS credentials.",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.aws-api-mcp-server@latest"],
            "env": {"AWS_API_MCP_PROFILE_NAME": "default"},
            "icon": "⚡",
        },
        {
            "name": "AWS Knowledge",
            "description": "AWS knowledge base — docs, API refs, What's New, Well-Architected, Agent SOPs",
            "transport": "http",
            "url": "https://knowledge-mcp.global.api.aws",
            "env": {},
            "icon": "📚",
        },
        {
            "name": "AWS Serverless",
            "description": "SAM CLI — init, build, deploy, logs. Lambda event schemas, serverless templates",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.aws-serverless-mcp-server@latest"],
            "env": {"AWS_PROFILE": ""},
            "icon": "⚡",
        },
        {
            "name": "AWS Pricing",
            "description": "Real-time AWS pricing, cost analysis, CDK/Terraform project cost estimation",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.aws-pricing-mcp-server@latest"],
            "env": {},
            "icon": "💰",
        },
        {
            "name": "AWS IAM",
            "description": "IAM users, roles, groups, policies. Policy simulation and security best practices",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.iam-mcp-server@latest"],
            "env": {"AWS_PROFILE": ""},
            "icon": "🔐",
        },
        {
            "name": "DynamoDB",
            "description": "Data modeling guidance, schema validation, cost estimation, access layer generation",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.dynamodb-mcp-server@latest"],
            "env": {},
            "icon": "🗄️",
        },
        {
            "name": "Lambda Tool",
            "description": "Execute Lambda functions as MCP tools — bridge AI to private resources",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.lambda-tool-mcp-server@latest"],
            "env": {"AWS_PROFILE": "", "AWS_REGION": ""},
            "icon": "λ",
        },
        {
            "name": "Bedrock Knowledge Bases",
            "description": "Query enterprise knowledge bases with citation support (RAG)",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.bedrock-kb-retrieval-mcp-server@latest"],
            "env": {"AWS_PROFILE": "", "AWS_REGION": ""},
            "icon": "🧠",
        },
        {
            "name": "Bedrock Custom Models",
            "description": "Import, manage, and deploy custom models in Amazon Bedrock",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.aws-bedrock-custom-model-import-mcp-server@latest"],
            "env": {"AWS_PROFILE": "", "AWS_REGION": ""},
            "icon": "🤖",
        },
        {
            "name": "Bedrock AgentCore",
            "description": "AgentCore platform docs, runtime management, memory, gateway + browser automation",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.amazon-bedrock-agentcore-mcp-server@latest"],
            "env": {},
            "icon": "🏛️",
        },
        {
            "name": "ElastiCache",
            "description": "ElastiCache control plane — serverless cache, replication groups, clusters, metrics",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.elasticache-mcp-server@latest"],
            "env": {"AWS_PROFILE": "", "AWS_REGION": ""},
            "icon": "⚡",
        },
        {
            "name": "Memcached",
            "description": "ElastiCache Memcached data operations — get, set, delete, stats, flush",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.memcached-mcp-server@latest"],
            "env": {"MEMCACHED_HOST": "", "MEMCACHED_PORT": ""},
            "icon": "🔄",
        },
        {
            "name": "SNS/SQS",
            "description": "Event-driven messaging — create topics/queues, publish, subscribe, receive messages",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.amazon-sns-sqs-mcp-server@latest"],
            "env": {"AWS_PROFILE": "", "AWS_REGION": ""},
            "icon": "📨",
        },
        {
            "name": "Step Functions",
            "description": "Execute AWS Step Functions state machines as MCP tools for complex workflows",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.stepfunctions-tool-mcp-server@latest"],
            "env": {"AWS_PROFILE": "", "AWS_REGION": ""},
            "icon": "🔀",
        },
        {
            "name": "Finch",
            "description": "Build and push container images via Finch CLI, create ECR repos",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.finch-mcp-server@latest"],
            "env": {},
            "icon": "🐳",
        },
        {
            "name": "OpenAPI",
            "description": "Dynamic API integration — generates MCP tools from any OpenAPI specification",
            "transport": "stdio",
            "command": "uvx",
            "args": ["awslabs.openapi-mcp-server@latest"],
            "env": {},
            "icon": "🔗",
        },
        {
            "name": "Azure",
            "description": "Manage Azure resources, deploy apps, and query Azure cloud services",
            "transport": "stdio",
            "command": "npx",
            "args": ["-y", "@azure/mcp@latest"],
            "env": {},
            "icon": "🔷",
        },
        {
            "name": "QA Tools",
            "description": "Static analysis toolchain — Biome, Ruff, cfn-lint, hadolint, secret scanning, syntax checking",
            "transport": "stdio",
            "command": "python",
            "args": ["mcp_servers/qa_tools/server.py"],
            "env": {},
            "icon": "🔍",
        },
    ]

    for d in defaults:
        # Auto-populate env vars from os.environ (e.g. GITHUB_TOKEN from .env)
        env = d.get("env", {})
        for key in env:
            if not env[key] and os.environ.get(key):
                env[key] = os.environ[key]

        # Auto-enable servers that have all required env vars populated
        has_env = all(v for v in env.values()) if env else True
        auto_enable = has_env and bool(env)  # only auto-enable if it has env vars and they're all set

        server: MCPServerConfig = {
            "id": str(uuid.uuid4()),
            "name": d["name"],
            "description": d["description"],
            "transport": d["transport"],
            "command": d.get("command"),
            "args": d.get("args", []),
            "url": d.get("url"),
            "env": env,
            "enabled": auto_enable,
            "icon": d["icon"],
            "tools_count": None,
            "created_at": time.time(),
        }
        MCP_STORE[server["id"]] = server


# Seed on import
_seed_defaults()


def create_server(
    name: str,
    transport: Literal["stdio", "sse", "http"],
    description: str = "",
    command: str | None = None,
    args: list[str] | None = None,
    url: str | None = None,
    env: dict[str, str] | None = None,
    icon: str = "🔌",
) -> MCPServerConfig:
    server: MCPServerConfig = {
        "id": str(uuid.uuid4()),
        "name": name,
        "description": description,
        "transport": transport,
        "command": command,
        "args": args or [],
        "url": url,
        "env": env or {},
        "enabled": False,
        "icon": icon,
        "tools_count": None,
        "created_at": time.time(),
    }
    MCP_STORE[server["id"]] = server
    return server


def get_server(server_id: str) -> MCPServerConfig | None:
    return MCP_STORE.get(server_id)


def list_servers() -> list[MCPServerConfig]:
    return sorted(MCP_STORE.values(), key=lambda s: s["created_at"])


def update_server(server_id: str, **fields) -> MCPServerConfig | None:
    server = MCP_STORE.get(server_id)
    if not server:
        return None
    for k, v in fields.items():
        if k in server:
            server[k] = v  # type: ignore[literal-required]
    return server


def delete_server(server_id: str) -> bool:
    if server_id in MCP_STORE:
        del MCP_STORE[server_id]
        return True
    return False


def get_enabled_servers() -> list[MCPServerConfig]:
    return [s for s in MCP_STORE.values() if s["enabled"]]
