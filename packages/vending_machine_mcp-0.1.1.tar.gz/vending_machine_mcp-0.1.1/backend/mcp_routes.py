"""
MCP server registry REST API routes.

CRUD for MCP server configurations + connection testing.
"""

import asyncio

from fastapi import APIRouter
from pydantic import BaseModel

from mcp_registry import (
    create_server,
    delete_server,
    get_server,
    list_servers,
    update_server,
)

mcp_router = APIRouter(prefix="/api/mcp")


class CreateServerRequest(BaseModel):
    name: str
    transport: str  # "stdio" | "sse" | "http"
    description: str = ""
    command: str | None = None
    args: list[str] | None = None
    url: str | None = None
    env: dict[str, str] | None = None
    icon: str = "🔌"


class UpdateServerRequest(BaseModel):
    name: str | None = None
    description: str | None = None
    transport: str | None = None
    command: str | None = None
    args: list[str] | None = None
    url: str | None = None
    env: dict[str, str] | None = None
    enabled: bool | None = None
    icon: str | None = None


@mcp_router.get("/servers")
async def get_servers():
    return list_servers()


@mcp_router.get("/servers/{server_id}")
async def get_server_by_id(server_id: str):
    server = get_server(server_id)
    if not server:
        return {"error": "Server not found"}, 404
    return server


@mcp_router.post("/servers")
async def create_new_server(req: CreateServerRequest):
    server = create_server(
        name=req.name,
        transport=req.transport,
        description=req.description,
        command=req.command,
        args=req.args,
        url=req.url,
        env=req.env,
        icon=req.icon,
    )
    return server


@mcp_router.put("/servers/{server_id}")
async def update_existing_server(server_id: str, req: UpdateServerRequest):
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    server = update_server(server_id, **updates)
    if not server:
        return {"error": "Server not found"}, 404
    return server


@mcp_router.delete("/servers/{server_id}")
async def delete_existing_server(server_id: str):
    if delete_server(server_id):
        return {"deleted": True}
    return {"error": "Server not found"}, 404


@mcp_router.post("/servers/{server_id}/test")
async def test_server_connection(server_id: str):
    """Test an MCP server connection — spawns process/connects, lists tools, disconnects."""
    server = get_server(server_id)
    if not server:
        return {"error": "Server not found"}, 404

    try:
        tools = await asyncio.to_thread(_test_mcp_connection, server)
        update_server(server_id, tools_count=len(tools))
        return {"ok": True, "tools": tools, "error": None}
    except Exception as e:
        return {"ok": False, "tools": [], "error": str(e)}


def _test_mcp_connection(server: dict) -> list[str]:
    """Synchronous MCP connection test — runs in thread pool.

    Uses the mcp Python package directly (no Strands dependency).
    """
    import asyncio

    async def _test() -> list[str]:
        if server["transport"] == "stdio":
            from mcp import StdioServerParameters
            from mcp.client.stdio import stdio_client

            params = StdioServerParameters(
                command=server["command"],
                args=server["args"],
                env={**server.get("env", {})},
            )

            async with stdio_client(params) as (read_stream, write_stream):
                from mcp import ClientSession

                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    return [t.name for t in result.tools]

        elif server["transport"] in ("sse", "http"):
            url = server.get("url", "")
            if not url:
                raise ValueError("URL required for SSE/HTTP transport")

            from mcp.client.sse import sse_client

            async with sse_client(url) as (read_stream, write_stream):
                from mcp import ClientSession

                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    return [t.name for t in result.tools]

        else:
            raise ValueError(f"Unknown transport: {server['transport']}")

    return asyncio.run(_test())
