# Vending Machine MCP Server

13 specialist AI agents for your coding assistant. Hire them for security audits, test generation, infrastructure, and more — all from Claude Code, Cursor, Windsurf, or any MCP-compatible client.

## Why?

Your AI assistant writes code. These agents review, test, harden, and ship it.

- **Bug Hunter** finds vulnerabilities your AI misses — different model architecture catches what the author can't see
- **Test Goblin** writes the test suites you'd skip — edge cases, dead branches, type coercion traps
- **DevOps Dwarf** generates production infrastructure — Dockerfiles, Terraform, CI/CD pipelines
- **Cloud Sensei** reviews your AWS architecture against the Well-Architected Framework with live documentation

**Benchmark:** We raced a 4-agent pipeline against a single AI model on the same task. The model was 16x faster. Then we ran Bug Hunter on the model's output — it found 3 critical vulnerabilities the model missed. The agents don't replace your AI. They extend it.

## Tools

| Tool | What it does |
|------|-------------|
| `hire_agent` | Delegate to a specialist agent (Bug Hunter, Test Goblin, DevOps Dwarf, etc.) |
| `check_job` | Poll async agent results |
| `list_agents` | See all available agents and their capabilities |
| `search_scripts` | Find marketplace scripts by description |
| `run` | Execute a validated script by vending code |
| `info` | Get script details and validation report |
| `run_code` | Execute Python/JS in an E2B sandbox |
| `audit_code` | Security audit pipeline — Bug Hunter finds vulns, Test Goblin writes tests, Code Gremlin patches |

## Agents

| Agent | What it does |
|-------|-------------|
| **Bug Hunter** | Security audit with OWASP/MITRE mapping, severity ratings, fix recommendations |
| **Test Goblin** | Comprehensive test suites — unit, integration, edge cases, dead branch detection |
| **Code Gremlin** | Code writing, debugging, refactoring in 12+ languages |
| **DevOps Dwarf** | Dockerfiles, Terraform, CI/CD, Kubernetes, CloudFormation |
| **Cloud Sensei** | AWS architecture review, cost optimization, Well-Architected assessment |
| **MCP Maker** | Generate MCP server code (Python FastMCP, TypeScript, Go) |
| **Data Sprite** | Database schemas, migrations, seed data, ETL scripts |
| **PDF Forge** | PDF report generation from structured data |
| **Inbox Zero** | Email triage — categorize, prioritize, draft replies |
| **Vibe Writer** | Content creation — posts, newsletters, taglines |
| **Number Crunch** | Data analysis, statistics, KPI dashboards |
| **Desk Pilot** | Admin assistant — SOPs, meeting prep, task management |
| **Embeddings Agent** | Multi-provider text embeddings and similarity analysis |

## Quick Start

```bash
pip install vending-machine-mcp
```

### Claude Code / Cursor / Windsurf
```json
{
  "mcpServers": {
    "vending-machine": {
      "command": "vending-machine-mcp"
    }
  }
}
```

### Usage

```
> hire_agent("bug-hunter", "Review this auth middleware for vulnerabilities: <paste code>")
> check_job("abc123")
> audit_code("<paste code>")  # Full pipeline: Bug Hunter → Test Goblin → Code Gremlin
```

## Requirements

- Python 3.11+
- `OPENROUTER_API_KEY` — powers all agents ([get one here](https://openrouter.ai/keys))
- `E2B_API_KEY` — sandbox execution (optional, needed for `run_code` and scripts)

## Security

Every marketplace script passes a 7-layer validation pipeline before approval:
1. Static AST analysis with MITRE ATT&CK mapping
2. Dependency CVE/NVD audit
3. Sandbox behavior probe
4. LLM security review
5. Functionality testing
6. Code quality analysis
7. Reliability testing
