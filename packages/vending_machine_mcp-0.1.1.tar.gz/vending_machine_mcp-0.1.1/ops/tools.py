"""
OpenClaw ops skill tools — HTTP calls to the Vending Machine backend.

Each tool is a function that calls the VM API and returns structured data
for the ops agent to reason about.

Configuration via environment variables:
    VM_API_URL — backend base URL (default: http://localhost:8000)
    VM_OPS_API_KEY — API key for ops endpoints (optional)
    RAILWAY_TOKEN — Railway API token for service restart
    RAILWAY_SERVICE_ID — Railway service ID
    ALERT_EMAIL — email for ops alerts
    RESEND_API_KEY — Resend API key for email delivery
"""

from __future__ import annotations

import logging
import os
import time

import httpx

logger = logging.getLogger("ops_agent")

_API_URL = os.environ.get("VM_API_URL", "http://localhost:8000")
_API_KEY = os.environ.get("VM_OPS_API_KEY", "")
_RAILWAY_TOKEN = os.environ.get("RAILWAY_TOKEN", "")
_RAILWAY_SERVICE_ID = os.environ.get("RAILWAY_SERVICE_ID", "")

# Circuit breaker: max 1 restart per hour
_last_restart: float = 0
_RESTART_COOLDOWN = 3600


def _headers() -> dict[str, str]:
    h = {"Content-Type": "application/json"}
    if _API_KEY:
        h["X-API-Key"] = _API_KEY
    return h


# ─── Health ───────────────────────────────────────────────────────────────


def check_health() -> dict:
    """Check backend health. Returns health status + dependency info."""
    try:
        r = httpx.get(f"{_API_URL}/health", headers=_headers(), timeout=10)
        return r.json()
    except Exception as e:
        return {"status": "unreachable", "error": str(e)}


# ─── Metrics ──────────────────────────────────────────────────────────────


def get_metrics() -> dict:
    """Get current metrics from the backend."""
    try:
        r = httpx.get(f"{_API_URL}/metrics", headers=_headers(), timeout=10)
        return r.json()
    except Exception as e:
        return {"error": str(e)}


# ─── Jobs ─────────────────────────────────────────────────────────────────


def list_stuck_jobs() -> dict:
    """Get list of stuck jobs (running past timeout)."""
    try:
        r = httpx.get(f"{_API_URL}/api/ops/stuck", headers=_headers(), timeout=10)
        return r.json()
    except Exception as e:
        return {"error": str(e)}


def cancel_job(job_id: str) -> dict:
    """Cancel a specific job."""
    try:
        r = httpx.post(f"{_API_URL}/api/jobs/{job_id}/cancel", headers=_headers(), timeout=10)
        return r.json()
    except Exception as e:
        return {"error": str(e)}


def get_error_summary(window_minutes: int = 15) -> dict:
    """Get error summary for the last N minutes."""
    try:
        r = httpx.get(f"{_API_URL}/api/ops/errors", params={"window": window_minutes}, headers=_headers(), timeout=10)
        return r.json()
    except Exception as e:
        return {"error": str(e)}


def get_spend_summary(window_minutes: int = 60) -> dict:
    """Get spend summary for the last N minutes."""
    try:
        r = httpx.get(f"{_API_URL}/api/ops/spend", params={"window": window_minutes}, headers=_headers(), timeout=10)
        return r.json()
    except Exception as e:
        return {"error": str(e)}


# ─── Alerting ─────────────────────────────────────────────────────────────


def send_alert(subject: str, message: str) -> dict:
    """Send an ops alert via email."""
    alert_email = os.environ.get("ALERT_EMAIL", "")
    if not alert_email:
        logger.warning("ALERT (no email configured): %s — %s", subject, message)
        return {"status": "logged", "subject": subject}

    try:
        import resend

        resend.api_key = os.environ.get("RESEND_API_KEY", "")
        from_email = os.environ.get("NOTIFICATION_FROM_EMAIL", "onboarding@resend.dev")

        resend.Emails.send(
            {
                "from": from_email,
                "to": [alert_email],
                "subject": f"[VM Ops] {subject}",
                "html": (
                    f'<div style="font-family:monospace;background:#1a1a2e;color:#e0e0e0;padding:20px;border-radius:8px;">'
                    f'<h2 style="color:#ff2d95;">⚠️ {subject}</h2>'
                    f"<p>{message}</p>"
                    f'<p style="color:#666;font-size:11px;">VM Ops Agent — {time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())}</p>'
                    f"</div>"
                ),
            }
        )
        logger.info("Alert email sent: %s", subject)
        return {"status": "sent", "subject": subject, "to": alert_email}
    except Exception as e:
        logger.warning("Alert email failed: %s", e)
        return {"status": "failed", "error": str(e)}


# ─── Service Management ──────────────────────────────────────────────────


def restart_service() -> dict:
    """Restart the backend service via Railway API. Max 1 per hour."""
    global _last_restart

    now = time.time()
    if now - _last_restart < _RESTART_COOLDOWN:
        remaining = int(_RESTART_COOLDOWN - (now - _last_restart))
        return {"status": "cooldown", "message": f"Restart on cooldown. {remaining}s remaining."}

    if not _RAILWAY_TOKEN or not _RAILWAY_SERVICE_ID:
        return {"status": "skipped", "message": "RAILWAY_TOKEN or RAILWAY_SERVICE_ID not configured."}

    try:
        r = httpx.post(
            "https://backboard.railway.com/graphql/v2",
            headers={
                "Authorization": f"Bearer {_RAILWAY_TOKEN}",
                "Content-Type": "application/json",
            },
            json={
                "query": "mutation { serviceInstanceRedeploy(serviceId: $id) }",
                "variables": {"id": _RAILWAY_SERVICE_ID},
            },
            timeout=30,
        )
        _last_restart = now
        logger.warning("Service restart triggered via Railway API")
        return {"status": "restarted", "response": r.status_code}
    except Exception as e:
        return {"status": "failed", "error": str(e)}


# ─── Main Ops Loop ───────────────────────────────────────────────────────


def run_ops_check() -> dict:
    """Run a full ops check cycle. Returns summary of actions taken.

    This is the main entry point — call this every 5 minutes.
    """
    results = {"timestamp": time.time(), "actions": [], "status": "ok"}

    # 1. Health check
    health = check_health()
    if health.get("status") != "ok":
        results["actions"].append(f"UNHEALTHY: {health}")
        send_alert("Backend Unhealthy", f"Health check returned: {health}")
        results["status"] = "unhealthy"
        return results

    # 2. Metrics check
    metrics = get_metrics()
    error_rate = metrics.get("error_rate", 0)
    if error_rate > 0.05:
        errors = get_error_summary(15)
        msg = f"Error rate: {error_rate:.1%}. {errors.get('error_count', 0)} errors in last 15 min."
        results["actions"].append(msg)
        send_alert("High Error Rate", msg)
        results["status"] = "warning"

    # 3. Stuck jobs
    stuck = list_stuck_jobs()
    stuck_count = stuck.get("stuck_count", 0)
    if stuck_count > 0:
        for job in stuck.get("stuck_jobs", []):
            cancel_job(job["job_id"])
        msg = f"Cancelled {stuck_count} stuck jobs."
        results["actions"].append(msg)
        send_alert("Stuck Jobs Cancelled", msg)

    # 4. Spend check
    spend = get_spend_summary(60)
    hourly_cost = spend.get("total_cost_usd", 0)
    if hourly_cost > 1.0:
        msg = f"Spend: ${hourly_cost:.4f}/hour ({spend.get('jobs_completed', 0)} jobs)."
        results["actions"].append(msg)
        send_alert("Spend Anomaly", msg)
        results["status"] = "warning"

    if not results["actions"]:
        results["actions"].append("All clear.")

    return results
