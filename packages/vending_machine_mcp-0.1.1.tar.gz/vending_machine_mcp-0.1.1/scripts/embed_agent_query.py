#!/usr/bin/env python3
"""
Upload a combined Markdown file to the Embeddings Agent and (optionally)
run a local cosine-similarity query.

This uses the Vending Machine backend upload endpoint:
  POST /api/agents/embeddings-agent/upload
  GET  /api/jobs/{job_id}

Note: The embeddings agent returns an analysis report, not raw vectors.
For actual semantic search, enable --use-openai-direct (requires OPENAI_API_KEY).
"""

from __future__ import annotations

import argparse
import os
import time
from typing import List

import requests


def upload_to_embeddings_agent(api_base: str, file_path: str, task: str) -> str:
    with open(file_path, "rb") as f:
        files = {"file": (os.path.basename(file_path), f, "text/markdown")}
        data = {"task": task}
        resp = requests.post(f"{api_base}/api/agents/embeddings-agent/upload", files=files, data=data, timeout=60)
    resp.raise_for_status()
    payload = resp.json()
    return payload["job_id"]


def poll_job(api_base: str, job_id: str, timeout_s: int = 600) -> dict:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        resp = requests.get(f"{api_base}/api/jobs/{job_id}", timeout=30)
        resp.raise_for_status()
        job = resp.json()
        if job.get("status") in ("complete", "error"):
            return job
        time.sleep(3)
    raise TimeoutError("Job timed out")


def _cosine(a: List[float], b: List[float]) -> float:
    import math

    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def _embed_openai(texts: List[str], model: str) -> List[List[float]]:
    from openai import OpenAI

    client = OpenAI()
    vectors: List[List[float]] = []
    batch_size = 64
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        resp = client.embeddings.create(model=model, input=batch)
        vectors.extend(d.embedding for d in resp.data)
    return vectors


def _embed_voyage(texts: List[str], model: str) -> List[List[float]]:
    import voyageai

    client = voyageai.Client()
    vectors: List[List[float]] = []
    batch_size = 64
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        result = client.embed(texts=batch, model=model)
        vectors.extend(result.embeddings)
    return vectors


def _split_long_text(text: str, max_chars: int = 6000, overlap: int = 400) -> List[str]:
    if len(text) <= max_chars:
        return [text]

    parts: List[str] = []
    start = 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        window = text[start:end]

        if end < len(text):
            split_at = window.rfind("\n\n")
            if split_at > max_chars // 2:
                end = start + split_at
                window = text[start:end]

        parts.append(window.strip())
        if end >= len(text):
            break
        start = max(0, end - overlap)

    return [p for p in parts if p]


def local_query(file_path: str, query: str, model: str, provider: str) -> None:
    # Very simple chunking by headings
    chunks: List[str] = []
    current: List[str] = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("# ") and current:
                chunks.append("".join(current).strip())
                current = [line]
            else:
                current.append(line)
        if current:
            chunks.append("".join(current).strip())

    normalized_chunks: List[str] = []
    for chunk in chunks:
        normalized_chunks.extend(_split_long_text(chunk))

    if provider == "voyage":
        embeddings = _embed_voyage(normalized_chunks + [query], model=model)
    else:
        embeddings = _embed_openai(normalized_chunks + [query], model=model)
    query_vec = embeddings[-1]
    scored = [(i, _cosine(vec, query_vec)) for i, vec in enumerate(embeddings[:-1])]
    scored.sort(key=lambda x: x[1], reverse=True)

    top = scored[:3]
    print("\nTop matches:")
    for idx, score in top:
        preview = normalized_chunks[idx].split("\n", 1)[0]
        print(f"- {score:.4f} | {preview[:120]}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Upload docs to embeddings agent and query locally.")
    parser.add_argument("--api-base", default="http://localhost:8000")
    parser.add_argument("--combined-md", required=True, help="Path to combined markdown file")
    parser.add_argument("--task", default="Embed and analyze this documentation set.")
    parser.add_argument("--query", default="")
    parser.add_argument("--use-openai-direct", action="store_true")
    parser.add_argument("--model", default="text-embedding-3-small")
    parser.add_argument("--provider", choices=["openai", "voyage"], default="openai")
    args = parser.parse_args()

    job_id = upload_to_embeddings_agent(args.api_base, args.combined_md, args.task)
    job = poll_job(args.api_base, job_id)

    print("\nEmbeddings Agent Output:\n")
    print(job.get("output", "(no output)"))

    if args.query:
        if not args.use_openai_direct:
            print("\nQuery skipped: embeddings agent does not return raw vectors.")
            print("Run again with --use-openai-direct to compute vectors locally.")
            return 0
        local_query(args.combined_md, args.query, args.model, args.provider)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
