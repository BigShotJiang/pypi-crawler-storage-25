"""
Word Counter — count words, sentences, and characters in text.
Returns a formatted summary with top 10 most frequent words.
"""
import re
from collections import Counter

USER_INPUT = ""

def analyze(text):
    words = re.findall(r'\b\w+\b', text.lower())
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    chars = len(text)

    word_freq = Counter(words).most_common(10)

    lines = []
    lines.append(f"Words: {len(words)}")
    lines.append(f"Sentences: {len(sentences)}")
    lines.append(f"Characters: {chars}")
    lines.append(f"Avg words/sentence: {len(words) / max(len(sentences), 1):.1f}")
    lines.append("")
    lines.append("Top 10 words:")
    for word, count in word_freq:
        bar = "#" * min(count, 30)
        lines.append(f"  {word:15s} {count:4d}  {bar}")

    return "\n".join(lines)

print(analyze(USER_INPUT))
