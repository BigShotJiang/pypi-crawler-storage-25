#!/usr/bin/env python3
"""
ts-biome-fixer — Run TypeScript + Biome checks, auto-fix what's possible,
report what needs manual attention. Groups errors by category for batch fixing.

Usage:
    python ts_biome_fixer.py                  # current directory
    python ts_biome_fixer.py ./portal         # specific project
    python ts_biome_fixer.py ./portal --fix   # auto-fix safe issues
"""

import json
import os
import re
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

# ── Error categories for grouping ─────────────────────────────────────────
CATEGORIES = {
    "unused_import": {
        "ts_codes": {"TS6133", "TS6196"},
        "biome_rules": {"lint/correctness/noUnusedImports"},
        "auto_fixable": True,
        "label": "Unused Imports",
    },
    "unused_var": {
        "ts_codes": {"TS6133"},
        "biome_rules": {"lint/correctness/noUnusedVariables"},
        "auto_fixable": False,
        "label": "Unused Variables",
    },
    "type_mismatch": {
        "ts_codes": {"TS2322", "TS2345", "TS2769"},
        "biome_rules": set(),
        "auto_fixable": False,
        "label": "Type Mismatches",
    },
    "missing_import": {
        "ts_codes": {"TS2305", "TS2307", "TS2339", "TS2552"},
        "biome_rules": set(),
        "auto_fixable": False,
        "label": "Missing Imports / Properties",
    },
    "format": {
        "ts_codes": set(),
        "biome_rules": {"format"},
        "auto_fixable": True,
        "label": "Formatting Issues",
    },
    "suspicious": {
        "ts_codes": set(),
        "biome_rules": {
            "lint/suspicious/noTemplateCurlyInString",
            "lint/suspicious/noExplicitAny",
            "lint/suspicious/noArrayIndexKey",
        },
        "auto_fixable": False,
        "label": "Suspicious Patterns",
    },
    "style": {
        "ts_codes": set(),
        "biome_rules": {"lint/style/useConst", "lint/style/noNonNullAssertion", "lint/style/useTemplate"},
        "auto_fixable": True,
        "label": "Style Issues",
    },
}


def find_npx():
    """Find npx binary."""
    for candidate in ["npx", os.path.expanduser("~/.local/share/fnm/aliases/default/bin/npx")]:
        try:
            subprocess.run([candidate, "--version"], capture_output=True, timeout=5, check=False)
            return candidate
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return "npx"


def run_tsc(project_dir, npx="npx"):
    """Run TypeScript compiler and parse errors."""
    result = subprocess.run(
        [npx, "tsc", "--noEmit", "--pretty", "false"],
        cwd=project_dir,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )

    errors = []
    pattern = re.compile(r"^(.+?)\((\d+),(\d+)\): error (TS\d+): (.+)$")

    for line in result.stdout.splitlines() + result.stderr.splitlines():
        m = pattern.match(line.strip())
        if m:
            errors.append({
                "file": m.group(1),
                "line": int(m.group(2)),
                "col": int(m.group(3)),
                "code": m.group(4),
                "message": m.group(5),
                "source": "tsc",
            })

    return errors


def run_biome(project_dir, npx="npx"):
    """Run Biome check and parse diagnostics."""
    result = subprocess.run(
        [npx, "biome", "check", "."],
        cwd=project_dir,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )

    errors = []
    output = result.stdout + result.stderr

    for line in output.splitlines():
        if "format" in line.lower() and "would have" in line:
            m = re.match(r"^(.+?)\s+format\b", line)
            if m:
                errors.append({
                    "file": m.group(1),
                    "line": 0,
                    "col": 0,
                    "code": "format",
                    "message": "File needs formatting",
                    "source": "biome",
                    "fixable": True,
                })
        elif "FIXABLE" in line or "lint/" in line:
            m = re.match(r"^(.+?)[:( ](\d+)", line)
            rule = re.search(r"(lint/\S+)", line)
            if m and rule:
                errors.append({
                    "file": m.group(1),
                    "line": int(m.group(2)),
                    "col": 0,
                    "code": rule.group(1),
                    "message": line.strip()[:120],
                    "source": "biome",
                    "fixable": "FIXABLE" in line,
                })

    return errors


def categorize_error(error):
    """Assign an error to a category."""
    code = error["code"]
    for cat_name, cat in CATEGORIES.items():
        if error["source"] == "tsc" and code in cat["ts_codes"]:
            return cat_name
        if error["source"] == "biome" and code in cat["biome_rules"]:
            return cat_name
        if error["source"] == "biome" and cat_name == "format" and code == "format":
            return cat_name
    return "other"


def auto_fix_biome(project_dir, npx="npx"):
    """Run biome --write to auto-fix safe issues."""
    result = subprocess.run(
        [npx, "biome", "check", "--write", "."],
        cwd=project_dir,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    m = re.search(r"Fixed (\d+) file", result.stdout + result.stderr)
    return int(m.group(1)) if m else 0


def remove_unused_imports(project_dir, errors):
    """Remove lines flagged as unused imports by tsc."""
    files_to_fix = defaultdict(set)
    for e in errors:
        if e["code"] in ("TS6133", "TS6196") and "imported but" in e.get("message", ""):
            files_to_fix[e["file"]].add(e["line"])

    fixed = 0
    for filepath, lines_to_remove in files_to_fix.items():
        full_path = os.path.join(project_dir, filepath)
        try:
            with open(full_path) as f:
                all_lines = f.readlines()
            new_lines = [line for i, line in enumerate(all_lines, 1) if i not in lines_to_remove or "import" not in line]
            removed = len(all_lines) - len(new_lines)
            if removed:
                with open(full_path, "w") as f:
                    f.writelines(new_lines)
                fixed += removed
        except Exception:
            continue
    return fixed


def format_report(tsc_errors, biome_errors, auto_fixed=0):
    """Format errors into a grouped markdown report."""
    all_errors = tsc_errors + biome_errors
    grouped = defaultdict(list)
    for e in all_errors:
        grouped[categorize_error(e)].append(e)

    lines = ["# TypeScript + Biome Health Check\n"]
    total = len(all_errors)
    fixable = sum(1 for e in all_errors if e.get("fixable") or categorize_error(e) in ("format", "style", "unused_import"))

    lines.append(f"**Total issues:** {total}")
    lines.append(f"**Auto-fixable:** {fixable}")
    lines.append(f"**Manual fixes needed:** {total - fixable}")
    if auto_fixed:
        lines.append(f"**Already auto-fixed:** {auto_fixed}")
    lines.append("")

    for cat_name, cat_info in CATEGORIES.items():
        cat_errors = grouped.get(cat_name, [])
        if not cat_errors:
            continue
        fix_tag = " (auto-fixable)" if cat_info["auto_fixable"] else ""
        lines.append(f"## {cat_info['label']}{fix_tag} — {len(cat_errors)} issues\n")
        by_file = defaultdict(list)
        for e in cat_errors:
            by_file[e["file"]].append(e)
        for fp, fe in sorted(by_file.items()):
            lines.append(f"### `{fp}`")
            for e in sorted(fe, key=lambda x: x["line"]):
                lines.append(f"- Line {e['line']}: [{e['code']}] {e['message'][:100]}")
            lines.append("")

    other = grouped.get("other", [])
    if other:
        lines.append(f"## Other Issues — {len(other)}\n")
        for e in other[:20]:
            lines.append(f"- `{e['file']}:{e['line']}` [{e['code']}] {e['message'][:100]}")
        if len(other) > 20:
            lines.append(f"- ... and {len(other) - 20} more")
    lines.append("")
    return "\n".join(lines)


def main():
    # Support both CLI args (sys.argv) and marketplace (USER_INPUT variable)
    user_input = globals().get("USER_INPUT", "").strip()
    if user_input:
        parts = user_input.split()
        project_dir = parts[0] if parts else "."
        do_fix = "--fix" in parts
    else:
        project_dir = sys.argv[1] if len(sys.argv) > 1 else "."
        do_fix = "--fix" in sys.argv
    project_dir = os.path.abspath(project_dir)

    if not os.path.isdir(project_dir):
        print(f"Error: {project_dir} is not a directory")
        return 1

    npx = find_npx()
    print(f"Checking {project_dir}...")

    print("[1/2] Running TypeScript compiler...")
    tsc_errors = run_tsc(project_dir, npx)
    print(f"      Found {len(tsc_errors)} TypeScript errors")

    print("[2/2] Running Biome check...")
    biome_errors = run_biome(project_dir, npx)
    print(f"      Found {len(biome_errors)} Biome issues")
    print()

    auto_fixed = 0
    if do_fix:
        print("[FIX] Auto-fixing safe issues...")
        fixed_biome = auto_fix_biome(project_dir, npx)
        print(f"      Biome auto-fixed {fixed_biome} files")

        import_errors = [e for e in tsc_errors if "imported but" in e.get("message", "")]
        if import_errors:
            fixed_imports = remove_unused_imports(project_dir, import_errors)
            print(f"      Removed {fixed_imports} unused imports")
            auto_fixed += fixed_imports
        auto_fixed += fixed_biome

        print("\n[RECHECK] Running checks after auto-fix...")
        tsc_errors = run_tsc(project_dir, npx)
        biome_errors = run_biome(project_dir, npx)
        print(f"      Remaining: {len(tsc_errors)} TS + {len(biome_errors)} Biome\n")

    report = format_report(tsc_errors, biome_errors, auto_fixed)
    print(report)

    report_path = os.path.join(project_dir, ".health-report.md")
    with open(report_path, "w") as f:
        f.write(report)
    print(f"Report saved to {report_path}")

    return 1 if (len(tsc_errors) + len(biome_errors)) > 0 else 0


if __name__ == "__main__":
    rc = main()
    if rc:
        sys.exit(rc)
