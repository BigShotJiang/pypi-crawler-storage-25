#!/usr/bin/env python3
"""
Crawl OpenAI developer docs pages and save as Markdown.

Example:
  python openai_docs_to_md.py \
    --seed-url "https://developers.openai.com/api/docs/guides/agents" \
    --output-dir ./openai-sdk-docs \
    --max-pages 50

Notes:
- Respects same-domain and include-prefix filters.
- English-only by default (skips /ja/, /zh/, /ko/, /fr/, /es/, /de/).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
from collections import deque
from urllib.parse import urljoin, urlparse, urldefrag

import requests
from bs4 import BeautifulSoup

try:
    from markdownify import markdownify as html_to_md
except Exception:  # pragma: no cover
    html_to_md = None

SKIP_LANGS = {"/ja/", "/zh/", "/ko/", "/fr/", "/es/", "/de/"}


def _slugify(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9_-]+", "-", text).strip("-").lower()
    return text or "index"


def _extract_main_html(soup: BeautifulSoup) -> str:
    main = soup.find("main")
    if main:
        return str(main)
    article = soup.find("article")
    if article:
        return str(article)
    body = soup.find("body")
    return str(body) if body else str(soup)


def _html_to_markdown(html: str) -> str:
    if html_to_md:
        return html_to_md(html, heading_style="ATX")
    # Fallback: plain text with minimal formatting
    text = BeautifulSoup(html, "html.parser").get_text("\n", strip=True)
    return text


def _should_skip(url: str, include_prefix: str, domain: str) -> bool:
    if not url.startswith(include_prefix):
        return True
    parsed = urlparse(url)
    if parsed.netloc != domain:
        return True
    for lang in SKIP_LANGS:
        if lang in parsed.path:
            return True
    return False


def crawl(seed_urls: list[str], output_dir: str, include_prefix: str, max_pages: int, delay: float) -> dict:
    os.makedirs(output_dir, exist_ok=True)
    domain = urlparse(include_prefix).netloc
    visited: set[str] = set()
    queue = deque(seed_urls)
    index: dict[str, str] = {}

    while queue and len(visited) < max_pages:
        raw = queue.popleft()
        url, _ = urldefrag(raw)
        if url in visited:
            continue
        if _should_skip(url, include_prefix, domain):
            continue

        try:
            resp = requests.get(url, timeout=20)
            if resp.status_code != 200:
                continue
        except Exception:
            continue

        visited.add(url)
        soup = BeautifulSoup(resp.text, "html.parser")
        title = soup.find("title").get_text(strip=True) if soup.find("title") else url

        main_html = _extract_main_html(soup)
        md = _html_to_markdown(main_html)
        md = f"# {title}\n\n" + md

        path = urlparse(url).path.strip("/")
        filename = _slugify(path.replace("/", "-")) + ".md"
        out_path = os.path.join(output_dir, filename)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(md)
        index[url] = out_path

        # Discover links
        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if href.startswith("#"):
                continue
            next_url = urljoin(url, href)
            next_url, _ = urldefrag(next_url)
            if next_url not in visited and not _should_skip(next_url, include_prefix, domain):
                queue.append(next_url)

        time.sleep(delay)

    # Save index and combined file
    index_path = os.path.join(output_dir, "_index.json")
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump(index, f, indent=2)

    combined_path = os.path.join(output_dir, "_combined.md")
    with open(combined_path, "w", encoding="utf-8") as f:
        for url, path in index.items():
            f.write(f"\n\n---\n# Source: {url}\n\n")
            with open(path, "r", encoding="utf-8") as src:
                f.write(src.read())

    return {
        "pages": len(index),
        "index": index_path,
        "combined": combined_path,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Crawl OpenAI developer docs into Markdown.")
    parser.add_argument("--seed-url", action="append", required=True, help="Seed URL(s) to crawl")
    parser.add_argument("--output-dir", default="./openai-sdk-docs", help="Output directory")
    parser.add_argument(
        "--include-prefix",
        default="https://developers.openai.com/api/docs/",
        help="Only crawl URLs starting with this prefix",
    )
    parser.add_argument("--max-pages", type=int, default=50, help="Max pages to crawl")
    parser.add_argument("--delay", type=float, default=0.4, help="Delay between requests")
    args = parser.parse_args()

    result = crawl(args.seed_url, args.output_dir, args.include_prefix, args.max_pages, args.delay)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
