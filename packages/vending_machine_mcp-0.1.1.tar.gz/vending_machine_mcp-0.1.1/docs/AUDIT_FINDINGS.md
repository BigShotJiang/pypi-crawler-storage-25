# Security Audit Findings — Production Hardening

**Audited by**: Bug Hunter + Test Goblin + Code Gremlin (Vending Machine MCP)  
**Date**: 2026-04-09  
**Scope**: Phase 1 (middleware, rate limiting, jobs) + Phase 2 (auth, tenant isolation, audit trail)  
**Cost**: $0.238 total ($0.122 middleware + $0.116 auth)

---

## Summary

| Severity | Phase 1 (Middleware) | Phase 2 (Auth) | Total |
|----------|---------------------|----------------|-------|
| Critical | 0 | 0 | **0** |
| High | 1 | 0 | **1** |
| Medium | 3 | 2 | **5** |
| Low | 2 | 2 | **4** |
| Info | 1 | 1 | **2** |

---

## Phase 1 — Middleware, Rate Limiting, Job Lifecycle

### HIGH-001 — Request ID CRLF Injection
- **File**: `middleware.py` → `RequestIDMiddleware.dispatch()`
- **Issue**: Client-supplied `X-Request-ID` header is accepted without validation. An attacker can inject `\r\n` characters to perform HTTP response splitting or log injection.
- **Impact**: Log injection, potential HTTP response splitting if request ID is reflected in headers.
- **Fix**: Validate request ID against regex `^[A-Za-z0-9._\-]{8,128}$`. Reject or regenerate if invalid.
- **Status**: 🔴 Open

### MEDIUM-001 — Log Injection via Malicious Headers
- **Phase**: 1
- **File**: `middleware.py` → `_log_request()`
- **Issue**: Client IP and path are logged without sanitization. Control characters (`\r`, `\n`, bidi overrides) in headers can corrupt structured log output.
- **Impact**: Log poisoning, SIEM evasion, misleading audit trails.
- **Fix**: Sanitize all logged values — strip control chars, cap length, escape special characters before JSON serialization.
- **Status**: 🔴 Open

### MEDIUM-002 — Rate Limit Bypass via X-Forwarded-For Rotation
- **Phase**: 1
- **File**: `middleware.py` → `_get_rate_limit_key()`
- **Issue**: Rate limiting keys by `request.client.host` which is the direct client IP. Behind a proxy, the real IP may differ. If an attacker rotates X-Forwarded-For, they could appear as different clients.
- **Impact**: Rate limit bypass when behind reverse proxy.
- **Fix**: Do not trust X-Forwarded-For for rate limiting unless from a trusted proxy. Current behavior (using transport-level IP) is actually correct for Railway — Railway terminates TLS and sets the real IP. Document this assumption.
- **Status**: 🟡 Acceptable risk (Railway handles proxy correctly)

### MEDIUM-003 — Idempotency Key Not Scoped Per Tenant
- **Phase**: 1
- **File**: `middleware.py` → `check_idempotency()`
- **Issue**: Idempotency cache key is `idemp:{key_header}` — not scoped by tenant. Two different users sending the same `Idempotency-Key` value would collide, causing tenant A to receive tenant B's cached response.
- **Impact**: Cross-tenant data leakage via idempotency replay.
- **Fix**: Scope cache key by tenant: `idemp:{tenant_id}:{key_header}`.
- **Status**: 🔴 Open — **this should be fixed before production**

### LOW-001 — Unbounded Metrics Dict
- **Phase**: 1
- **File**: `middleware.py` → `_metrics` dict
- **Issue**: In-process metrics use a plain dict that grows if custom metric names are dynamically generated. No memory bound.
- **Impact**: Theoretical memory leak if `inc_metric()` is called with unbounded dynamic keys.
- **Fix**: Use a fixed set of allowed metric names. Reject unknown keys.
- **Status**: 🟢 Low risk (all current callers use static names)

### LOW-002 — Rate Limit Window Drift
- **Phase**: 1
- **File**: `middleware.py` → `check_rate_limit()`
- **Issue**: Redis INCR + EXPIRE is not atomic. Under high concurrency, the key could be incremented without the EXPIRE being set, causing it to persist indefinitely.
- **Impact**: Permanent rate limit block for a key (until manual Redis cleanup).
- **Fix**: Use Redis MULTI/EXEC or Lua script for atomic increment + expire. Or use SETEX with NX for initialization.
- **Status**: 🟡 Low probability at our scale

### INFO-001 — Health Check Leaks Dependency Details
- **Phase**: 1
- **File**: `main.py` → `/health` endpoint
- **Issue**: Health check returns internal dependency names and status (Supabase, Redis, sandbox provider). This information could help an attacker understand the infrastructure.
- **Impact**: Information disclosure (non-critical for internal API, problematic if public).
- **Fix**: Add an admin-only `/health/detailed` endpoint. Keep public `/health` minimal (`{"status": "ok"}`).
- **Status**: 🟡 Acceptable for internal use

---

## Phase 2 — Auth, Tenant Isolation, Audit Trail

### MEDIUM-004 — API Key Lookup Not Fully Constant-Time
- **Phase**: 2
- **File**: `auth.py` → `_validate_api_key()`
- **Issue**: API key is hashed with SHA-256 then looked up via Supabase query (`WHERE key_hash = ?`). The database lookup time varies based on index hit/miss, which could theoretically leak whether a hash prefix exists.
- **Impact**: Extremely low — the attacker would need to brute-force SHA-256 hashes, which is computationally infeasible.
- **Fix**: No action needed. SHA-256 pre-hashing makes timing attacks on the DB query irrelevant.
- **Status**: 🟢 Acceptable

### MEDIUM-005 — Tenant ID Derived from Token Hash, Not User ID
- **Phase**: 2
- **File**: `main.py` → `tenant_middleware`
- **Issue**: Tenant ID is derived by hashing the JWT token (`jwt:sha256[:12]`), not by validating the token and extracting the user ID. Different sessions for the same user produce different tenant IDs, causing per-tenant rate limits to reset on token refresh.
- **Impact**: Rate limit bypass by refreshing JWT token. Each new session gets a fresh rate limit bucket.
- **Fix**: Validate the JWT in the tenant middleware (or defer to a later middleware) and use the stable `user.id` as tenant_id. Currently this is a performance tradeoff — full JWT validation on every request is expensive.
- **Status**: 🔴 Open — should fix for production

### LOW-003 — Audit Log Never Fails the Request
- **Phase**: 2
- **File**: `jobs.py` → `create_job()`, `audit.py` → `log_action()`
- **Issue**: Audit logging is wrapped in try/except that swallows all errors. If audit logging consistently fails, no alert is raised.
- **Impact**: Silent audit gap — compliance violations could go undetected.
- **Fix**: Add a metric counter for audit failures. Alert if audit failure rate exceeds threshold.
- **Status**: 🟡 Low risk (Supabase is reliable)

### LOW-004 — API Key Plaintext Returned in Response
- **Phase**: 2
- **File**: `auth.py` → `create_api_key()`
- **Issue**: The plaintext API key is returned in the HTTP response body. If the response is logged by any intermediate proxy, load balancer, or monitoring tool, the key is compromised.
- **Impact**: Key exposure via response logging.
- **Fix**: Ensure response logging (if any) redacts the `key` field. Document that the key is shown once and cannot be recovered.
- **Status**: 🟡 By design (keys must be shown once)

### INFO-002 — Auth Module Has No Rate Limiting on Failed Attempts
- **Phase**: 2
- **File**: `auth.py` → `_validate_api_key()`, `get_current_user()`
- **Issue**: Failed authentication attempts are not rate limited separately from successful ones. An attacker could brute-force API keys at the general rate limit (60/min).
- **Impact**: Brute-force attack on API keys limited only by general rate limiter.
- **Fix**: Add per-IP failed auth counter. Lock out after N failures (e.g., 10 failures in 5 minutes → 15 minute cooldown).
- **Status**: 🟡 Mitigated by SHA-256 hashing (brute-force infeasible)

---

## Test Goblin — Generated Test Coverage

Test Goblin generated 25+ security-focused tests across two test files. These should be added to the test suite:

### Middleware Tests (`tests/test_middleware_security.py`)
| Test | What it probes |
|------|---------------|
| `test_request_id_missing_header_generates_safe_value` | Server generates bounded, CRLF-safe ID |
| `test_request_id_valid_header_is_propagated` | Valid UUID propagated unchanged |
| `test_request_id_oversized_header_is_rejected_or_sanitized` | 5000-char ID rejected or replaced |
| `test_request_id_crlf_injection_is_not_reflected` | `\r\n` in ID not reflected in response |
| `test_request_id_unicode_confusable_is_rejected` | Bidi override chars stripped |
| `test_logs_do_not_contain_raw_crlf` | Log injection via User-Agent |
| `test_logs_do_not_include_bidi_controls` | Bidi chars in request body |
| `test_logs_do_not_dump_unbounded_body` | Large payload not dumped raw |
| `test_rate_limit_enforces_on_burst` | 120 rapid requests get 429 |
| `test_rate_limit_xff_bypass` | X-Forwarded-For rotation doesn't bypass |
| `test_rate_limit_retry_after_recovery` | Rate limit resets after Retry-After |
| `test_rate_limit_cross_user_collision` | User B not throttled by User A |
| `test_idempotency_same_key_replays` | Duplicate request returns cached |
| `test_idempotency_different_body_rejected` | Same key + different body = 409 |
| `test_idempotency_concurrent_race` | 12 concurrent same-key requests = 1 execution |
| `test_idempotency_cross_tenant_scoping` | Tenant A's key doesn't replay for Tenant B |

### Auth Tests (`tests/test_auth_security.py`)
| Test | What it probes |
|------|---------------|
| `test_validate_jwt_allows_valid_token` | Valid HS256 JWT passes |
| `test_validate_jwt_rejects_malformed` | Empty, spaces, partial tokens rejected |
| `test_validate_jwt_rejects_alg_none` | Algorithm confusion attack blocked |
| `test_validate_jwt_rejects_bad_signature` | Wrong secret rejected |
| `test_validate_jwt_rejects_expired` | Expired token rejected |
| `test_validate_api_key_allows_exact_valid` | Correct key passes |
| `test_validate_api_key_rejects_blank` | Empty/whitespace rejected |
| `test_validate_api_key_rejects_case_variants` | Case changes rejected |
| `test_validate_api_key_rejects_revoked` | Revoked key denied |
| `test_authenticate_rejects_conflicting_credentials` | Invalid JWT + valid key = deny |
| `test_authenticate_does_not_log_secrets` | Tokens/keys not in log output |

---

## Code Gremlin — Suggested Hardened Implementations

Code Gremlin provided two production-grade reference implementations:

1. **`SecurityMiddleware`** — ASGI-level middleware with request ID validation, sliding-window rate limiter, structured logging with sanitization, and IP trust chain handling.

2. **`AuthMiddleware`** — ASGI-level auth with manual HS256 JWT verification, constant-time API key comparison via SHA-256 digest matching, strict algorithm allowlist, and clock-skew-aware expiry validation.

These are available as reference but our current implementation (Supabase SDK for JWT, FastAPI middleware for request handling) is simpler and appropriate for our scale. The Gremlin implementations would be relevant if we move to custom JWT handling without Supabase.

---

## Priority Fix List

| Priority | Finding | Effort | Impact |
|----------|---------|--------|--------|
| **P0** | MEDIUM-003 — Idempotency not scoped per tenant | 10 min | Cross-tenant data leak |
| **P0** | MEDIUM-005 — Tenant ID from token hash, not user ID | 30 min | Rate limit bypass |
| **P1** | HIGH-001 — Request ID CRLF injection | 15 min | Log injection |
| **P1** | MEDIUM-001 — Log injection via headers | 20 min | Log poisoning |
| **P2** | INFO-002 — No failed auth rate limiting | 1 hr | Brute-force mitigation |
| **P2** | LOW-003 — Silent audit failures | 15 min | Compliance gap |
| **P3** | LOW-002 — Rate limit INCR/EXPIRE atomicity | 30 min | Edge case fix |
| **P3** | INFO-001 — Health check leaks infra details | 15 min | Info disclosure |

---

## Next Steps

1. Fix P0 items (MEDIUM-003, MEDIUM-005) before any public launch
2. Fix P1 items (HIGH-001, MEDIUM-001) before GPT Store submission
3. Add Test Goblin's generated tests to `tests/` directory
4. Re-run audit after Phase 3 (Billing) and Phase 4 (Observability)
5. Schedule quarterly security audits via Bug Hunter
