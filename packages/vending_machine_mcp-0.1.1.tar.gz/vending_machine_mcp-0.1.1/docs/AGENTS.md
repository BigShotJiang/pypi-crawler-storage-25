# Vending Machine — AI Agent Marketplace

## Project Summary
An AI agent marketplace where creators host specialized agents and users "hire" them for micro-tasks. Think "Gig Economy for AI" — users pay per-task wages instead of monthly subscriptions. The platform uses a fun, 2D arcade-style vending machine UI with illustrated chibi characters and warm diorama workspaces.

## Architecture Overview

### Frontend (`vending-machine-app/`)
- **Stack**: React 19 + Vite 8 + TypeScript 6 + Tailwind CSS 4 + Framer Motion 12 + Zustand 5 + react-markdown
- **Linter**: Biome 2.4.9 (replaced ESLint)
- **Key UI flows**:
  1. **Landing Scene** — Neon "VENDING MACHINE" sign with chibi character preview grid, neon hum sound, click to zoom in
  2. **Carousel** — Draggable horizontal carousel with agent badges showing chibi avatars, jiggle on hover, sound effects
  3. **Inspect Overlay** — Agent resume card with chibi avatar, glow effect, stats, pins, hire/try buttons, coin-drop sound
  4. **Diorama** — Illustrated workspace with SVG scene (wooden frame, desk, monitor, lamp, wall decor). Code Gremlin gets xterm.js terminal; others get chat with markdown rendering. Sci-fi comm screen shows chibi avatar with status indicators
  5. **Bounty Wall** — Corkboard with "Wanted" poster bounties for creators
  6. **Inbox** — Results inbox with task history, metadata (runtime, tokens, price), full output with markdown, copy/download buttons

### Backend (`vending-machine-app/backend/`)
- **Stack**: Python 3.14 + FastAPI + LangGraph + langchain-openai + OpenAI SDK
- **API Gateway**: OpenRouter (most agents) + Direct OpenAI API (Research Owl deep research)
- **WebSocket streaming**: Client connects to `ws://localhost:8000/ws/agent/{agent-id}`, sends `{"task": "..."}`, receives `{"step": "thinking|coding|reviewing|complete", "output": "...", "metadata": {...}}`
- **REST Job Queue**: `POST /api/jobs` submits async jobs, `GET /api/jobs/{id}` polls status. Used for long-running agents (Research Owl, Embeddings Agent). In-memory store, background execution via `asyncio.create_task()`
- **File Upload**: `POST /api/agents/embeddings-agent/upload` accepts multipart form data for the Embeddings Agent
- **8 LangGraph agents**: Each has plan → work → review pipeline with specialized system prompts
- **Agent Registry**: `agents/registry.py` centralizes graph compilation, shared helpers, and initial state builder
- **Response parsing**: `agents/parse.py` handles structured content blocks from reasoning models (Codex, o-series)
- **Completion metadata**: Runtime, token counts, timestamps sent with completion messages for inbox tracking
- **Frontend auto-detects** backend availability and falls back to simulated output when offline

### Sound System (`src/lib/sounds.ts` + `src/hooks/useSound.ts`)
- Web Audio API synthesis — no audio files needed
- 8 sounds: coinDrop, hookClack, jiggle, whoosh, pop, ding, error, neonHum
- All gated by `soundEnabled` toggle in store

### Agent Characters
- **Chibi PNG avatars** (transparent backgrounds) in `public/agents/` — used in badges, inspect, comm screen
- **SVG BlobCharacter** (`src/components/shared/BlobCharacter.tsx`) — kawaii blob with moods, kept for fallback
- **CommScreen** (`src/components/diorama/CommScreen.tsx`) — sci-fi video-call panel showing chibi with status HUD

### Per-Category Dioramas
Each agent category has a unique themed workspace:
| Category | Frame | Wall Decor | Desk Items | Lamp Glow |
|----------|-------|------------|------------|-----------|
| Coder | Dark metal | HACK poster, bookshelf | Green coffee | Green |
| Researcher | Purple wood | Double bookshelves, brain poster | Papers, magnifying glass | Purple |
| Assistant | Cream/beige | Checklist board, calendar | Tea cup, zen plant | Pink |
| Analyst | Dark blue | Stock charts, data ticker | Calculator | Blue |
| Creative | Warm wood | Mood board with pins, vinyl record | Coffee, pencil | Orange |

## Agents & Models

| Agent | Model | Provider | Temperature |
|-------|-------|----------|-------------|
| Code Gremlin | `openai/gpt-5.3-codex` | OpenRouter | 0.2-0.3 |
| Research Owl (plan/report/review) | `gpt-5.4-mini` | Direct OpenAI | 0.2-0.4 |
| Research Owl (research) | `o4-mini-deep-research` | Direct OpenAI Responses API | — |
| Inbox Zero | `anthropic/Codex-sonnet-4.6` | OpenRouter | 0.3 |
| Vibe Writer | `anthropic/Codex-sonnet-4.6` | OpenRouter | 0.7 |
| Number Crunch | `anthropic/Codex-sonnet-4.6` | OpenRouter | 0.2 |
| Fridge Chef | `anthropic/Codex-sonnet-4.6` | OpenRouter | 0.5 |
| MCP Maker | `openai/gpt-5.3-codex` | OpenRouter | 0.1-0.3 |
| Embeddings Agent (analysis/review) | `anthropic/Codex-sonnet-4.6` | OpenRouter | 0.2-0.3 |
| Embeddings Agent (embed) | `text-embedding-3-small` / `voyage-3` / `text-embedding-004` | OpenAI / Voyage AI / Gemini | — |

## Current State (End of Session 3)
- Full frontend with 6 views (landing, carousel, inspect, diorama, bounty, inbox)
- Illustrated diorama with SVG scene, comm screen, per-category themes
- Chibi PNG character avatars for 6 original agents (new agents need avatars)
- Sound effects system (Web Audio API)
- Live LLM integration working via OpenRouter + OpenAI
- Response parsing for reasoning model structured outputs
- Results inbox with localStorage persistence, markdown rendering, copy/download
- Markdown support in chat output and inbox detail view
- **Job queue system** — REST endpoints for async job submission + polling. Long-running agents (Research Owl, Embeddings Agent) auto-route to job queue. Inbox polls pending jobs every 5s
- **Research Owl timeout fix** — 30-minute max polling timeout on deep research
- **MCP Maker agent** — Generates MCP server code (Python FastMCP, TypeScript McpServer, Go SDK) with proper SDK patterns, tool/resource definitions, and transport config
- **Embeddings Agent** — File upload + multi-provider embedding (OpenAI, Voyage AI, Gemini). Chunking, cosine similarity analysis, statistics. Uses job queue for async processing
- **8 total agents** in the marketplace (6 original + MCP Maker + Embeddings Agent)

## What's Next
1. **Chibi avatars** for MCP Maker and Embeddings Agent (`public/agents/mcp_maker.png`, `public/agents/embeddings_agent.png`)
2. **Code execution sandbox** — Docker/node-pty behind xterm.js for running generated scripts
3. **Auth + payments** — User accounts, wallet system, wage escrow
4. **Creator dashboard** — Upload agents, customize avatars, view earnings
5. **AWS deployment** — ECS/Fargate for agent containers, API Gateway for WebSocket, Bedrock integration
6. **Database persistence** — Replace in-memory job store with PostgreSQL/DynamoDB
7. **Job queue improvements** — Progress streaming via SSE, job cancellation, job expiry/cleanup

## Running Locally
```bash
# Frontend
cd vending-machine-app
npm install
npm run dev

# Backend
cd vending-machine-app/backend
python3.14 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # Then add your keys
python3 main.py
```

### Required API Keys (`.env`)
```
OPENROUTER_API_KEY=sk-or-...   # Most agents
OPENAI_API_KEY=sk-...           # Research Owl + Embeddings (OpenAI provider)
VOYAGE_API_KEY=pa-...           # Optional: Embeddings (Voyage AI provider)
GOOGLE_API_KEY=...              # Optional: Embeddings (Gemini provider)
```

## Key Files
### Frontend
- `src/App.tsx` — View routing (landing, carousel, inspect, diorama, bounty, inbox)
- `src/components/landing/LandingScene.tsx` — Neon sign + machine with chibi grid
- `src/components/carousel/CarouselScene.tsx` — Badge carousel with drag
- `src/components/carousel/AgentBadge.tsx` — Agent card with chibi avatar
- `src/components/inspect/InspectOverlay.tsx` — Agent resume with chibi + glow
- `src/components/diorama/DioramaScene.tsx` — Main workspace with ResizeObserver overlay
- `src/components/diorama/DioramaFrame.tsx` — SVG illustrated scene (wall, desk, monitor, lamp)
- `src/components/diorama/CommScreen.tsx` — Sci-fi comm panel with chibi avatar
- `src/components/diorama/RetroTerminal.tsx` — xterm.js CRT terminal (Code Gremlin)
- `src/components/diorama/ChatOutput.tsx` — Chat bubbles with markdown (other agents)
- `src/components/inbox/InboxScene.tsx` — Results inbox with detail view
- `src/components/shared/BlobCharacter.tsx` — Animated SVG blob (fallback)
- `src/components/shared/MarkdownContent.tsx` — Styled markdown renderer
- `src/components/bounty/BountyWallScene.tsx` — Corkboard bounties
- `src/components/diorama/FileUploadInput.tsx` — File upload drop zone (Embeddings Agent)
- `src/lib/agent-client.ts` — WebSocket client, REST job queue, file upload, simulation fallback
- `src/lib/sounds.ts` — Web Audio API sound synthesis
- `src/hooks/useSound.ts` — Sound hook gated by store toggle
- `src/stores/useAppStore.ts` — Zustand state (view, agent, sound)
- `src/stores/useResultsStore.ts` — Zustand results with localStorage persistence
- `src/data/mock-agents.ts` — 8 agents with avatar image paths
- `src/data/system-prompts.ts` — LLM prompts per agent
- `src/types/agent.ts` — Agent type definition
- `src/types/result.ts` — TaskResult type definition

### Backend
- `backend/main.py` — FastAPI + WebSocket + REST job queue + file upload endpoints
- `backend/agents/registry.py` — Agent graph compilation, shared helpers, initial state builder
- `backend/jobs.py` — In-memory job store (JobStatus enum, CRUD operations)
- `backend/job_runner.py` — Background job execution via asyncio.create_task()
- `backend/agents/llm.py` — Shared LLM factory (OpenRouter + direct OpenAI)
- `backend/agents/parse.py` — Response parser for structured/reasoning model outputs
- `backend/agents/code_gremlin.py` — Codex-powered code generation
- `backend/agents/research_owl.py` — Deep research with o4-mini + gpt-5.4-mini (30 min timeout)
- `backend/agents/inbox_zero.py` — Email triage and organization
- `backend/agents/vibe_writer.py` — Ghostwriting and content creation
- `backend/agents/number_crunch.py` — Data analysis and insights
- `backend/agents/fridge_chef.py` — Recipe generation from ingredients
- `backend/agents/mcp_maker.py` — MCP server code generation (Python/TS/Go)
- `backend/agents/embeddings_agent.py` — Multi-provider embeddings (OpenAI, Voyage AI, Gemini)
- `backend/requirements.txt` — Python deps (langchain, fastapi, openai, voyageai, google-genai)
- `backend/.env.example` — API key template (4 keys, 2 optional)

### Assets
- `public/agents/*.png` — Chibi character images (transparent backgrounds)
