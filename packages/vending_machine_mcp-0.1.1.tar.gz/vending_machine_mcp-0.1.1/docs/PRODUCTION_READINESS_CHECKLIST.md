# Vending Machine Production Readiness Checklist

Last updated: 2026-04-09
Owner: Platform / Backend
Scope: ChatGPT GPT + Vending Machine backend + async jobs + script marketplace

## How To Use This

- Mark each item `PASS`, `FAIL`, or `N/A`.
- A launch is blocked if any **P0 gate** is `FAIL`.
- A launch is discouraged if any **P1 gate** is `FAIL`.
- Evidence must include a link to PR, dashboard, test run, or runbook.

## Go-Live Gates

### P0 (Must Pass Before Public Launch)

- [ ] `AUTH-001` API authentication enforced on all write endpoints.
- [ ] `TENANT-001` Tenant isolation verified at API, DB, cache, and logs.
- [ ] `BILL-001` Spend caps + hard stop behavior implemented per tenant.
- [ ] `SAFE-001` Input validation and schema checks on all public endpoints.
- [ ] `IDEMP-001` Idempotency keys implemented for all mutating requests.
- [ ] `JOB-001` Durable job state (no data loss on process restart).
- [ ] `JOB-002` Stuck-job reaper and timeout transitions to terminal states.
- [ ] `OBS-001` Request IDs + trace IDs on every request/response.
- [ ] `OBS-002` Alerting for error rate, latency, stuck jobs, and cost spikes.
- [ ] `SEC-001` Secret management (no plaintext secrets in repo or logs).
- [ ] `SEC-002` Webhook signature verification + replay protection.
- [ ] `IR-001` Incident response runbook and on-call escalation path tested.
- [ ] `BACKUP-001` Backup + restore drill completed for critical data stores.

### P1 (Strongly Recommended Before GA)

- [ ] `RATE-001` Rate limiting and abuse controls tuned per endpoint/tenant.
- [ ] `FALL-001` Model/provider fallback policy with circuit breakers.
- [ ] `CANCEL-001` Task cancellation behavior documented and tested.
- [ ] `DLQ-001` Dead-letter queue for irrecoverable async failures.
- [ ] `RELEASE-001` Progressive rollout + feature flags in place.
- [ ] `QA-001` End-to-end test matrix across major agent types and file modes.
- [ ] `PRIV-001` PII redaction and data retention policy enforced.
- [ ] `COMPLY-001` Audit trail for task execution and billing events.

## Detailed Checklist

## 1. API Contract and Gateway

- [ ] All GPT-facing endpoints versioned (`/v1/...`).
- [ ] OpenAPI spec validates against live implementation.
- [ ] Error schema standardized (`code`, `message`, `request_id`, `details`).
- [ ] Backward compatibility policy documented.
- [ ] Payload size limits configured and tested.
- [ ] Content-type strictness enforced (`application/json`, multipart).

Evidence:
- 

## 2. Auth, Identity, and Tenant Isolation

- [ ] Service-to-service auth in place (JWT/mTLS/API key + scope).
- [ ] User identity mapped to tenant on every request.
- [ ] Row-level access policy validated against cross-tenant tests.
- [ ] Cache keys namespaced by tenant.
- [ ] Logs and traces scrubbed of cross-tenant payload leakage.

Evidence:
- 

## 3. Job Orchestration and Reliability

- [ ] State machine enforced: `queued -> running -> succeeded|failed|cancelled|expired`.
- [ ] Retry policy configured (max attempts, backoff, jitter, retryable errors list).
- [ ] Idempotent replays for duplicate submit calls.
- [ ] Worker crash recovery verified.
- [ ] Poison pill handling routes to DLQ with diagnostics.

Evidence:
- 

## 4. Model Routing and Provider Resilience

- [ ] Primary/secondary model map defined by agent/task type.
- [ ] Provider timeout budgets configured.
- [ ] Circuit breaker thresholds configured and tested.
- [ ] Fallback preserves response schema and metadata.
- [ ] Cost guardrail per request and per tenant.

Evidence:
- 

## 5. Billing, Credits, and Financial Correctness

- [ ] Charge ledger is append-only and auditable.
- [ ] Atomic charge semantics (or compensating transaction) documented.
- [ ] Partial failure billing policy implemented and user-visible.
- [ ] Reconciliation job compares usage vs billed records daily.
- [ ] Dispute and refund workflow documented.

Evidence:
- 

## 6. Security and Sandbox

- [ ] Script execution sandbox has CPU/memory/time/network limits.
- [ ] Dangerous syscall/file/network vectors blocked.
- [ ] Dependency allowlist/denylist policies enforced.
- [ ] Malware/supply chain scan for uploaded/installed packages.
- [ ] Prompt injection defenses for tool-use and retrieval contexts.

Evidence:
- 

## 7. Data Governance and Privacy

- [ ] Data classification completed (PII, secrets, public).
- [ ] Encryption in transit and at rest validated.
- [ ] Retention + deletion policy implemented and tested.
- [ ] Export/delete user data flows tested.
- [ ] Access logs retained per policy.

Evidence:
- 

## 8. Observability and SLOs

- [ ] Structured logs with `request_id`, `task_id`, `tenant_id`.
- [ ] Distributed tracing across gateway/orchestrator/worker/provider.
- [ ] Metrics dashboards live:
- request volume
- p50/p95/p99 latency
- success/error rate by agent/provider
- stuck jobs
- cost per successful task
- [ ] SLOs defined with error budget policy.

Evidence:
- 

## 9. Testing and Validation

- [ ] Unit tests for critical orchestration and billing paths.
- [ ] Contract tests for GPT tool calls and JSON schemas.
- [ ] Load tests for submit/poll/result endpoints.
- [ ] Chaos tests for provider outage and worker crash.
- [ ] Security tests: auth bypass, tenant escape, injection vectors.
- [ ] Disaster recovery simulation completed.

Evidence:
- 

## 10. Operations and Incident Response

- [ ] Runbooks for top incidents (provider outage, queue backlog, billing drift).
- [ ] Pager rotation and escalation contacts current.
- [ ] Feature-flag rollback playbook tested.
- [ ] Communication template for customer incident updates.
- [ ] Postmortem template and cadence defined.

Evidence:
- 

## Launch Decision

- Launch Date:
- Release Candidate SHA:
- Decision: `GO` / `NO-GO`
- P0 Failed Items:
- P1 Failed Items:
- Risk Acceptance Approver:

## Recommended SLO Baselines (Initial)

- API availability: `99.5%`
- Job completion success (terminal): `>= 97%`
- P95 submit-to-start latency: `< 10s`
- P95 start-to-complete latency (non-research agents): `< 120s`
- Billing reconciliation drift: `< 0.5% daily`

## Notes

- For GPT Store distribution, ChatGPT remains UI/orchestration initiator; backend provider mix can stay multi-vendor.
- Production confidence should be measured by repeatable pass/fail evidence, not one-off green runs.
