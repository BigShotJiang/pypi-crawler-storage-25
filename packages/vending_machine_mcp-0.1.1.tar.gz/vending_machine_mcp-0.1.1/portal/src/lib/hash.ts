/**
 * Client-side SHA-256 hash computation.
 * MUST match backend's 16-char truncation in scripts.py _hash_code()
 */
export async function computeHash(code: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(code);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  // Backend truncates to 16 chars
  return hashHex.slice(0, 16);
}
