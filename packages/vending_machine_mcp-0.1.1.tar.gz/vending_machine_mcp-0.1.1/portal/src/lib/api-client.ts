import type { Agent } from "../types/agent";
import type { CreatorDashboardResponse } from "../types/creator-dashboard";
import type { Script, ScriptHash } from "../types/script";
import { supabase } from "./supabase-client";

const API_BASE = import.meta.env.VITE_API_URL || "";

async function getAuthHeaders(): Promise<Record<string, string>> {
  try {
    const { data } = await supabase.auth.getSession();
    if (data.session?.access_token) {
      return { Authorization: `Bearer ${data.session.access_token}` };
    }
  } catch {
    // No auth
  }
  return {};
}

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const authHeaders = await getAuthHeaders();
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...authHeaders,
      ...options?.headers,
    },
  });
  if (!res.ok) {
    throw new Error(`API error: ${res.status} ${res.statusText}`);
  }
  return res.json();
}

// Scripts
export const fetchScripts = () => apiFetch<Script[]>("/api/scripts");
export const fetchScript = (id: string) => apiFetch<Script>(`/api/scripts/${id}`);
export const fetchScriptValidation = (id: string) =>
  apiFetch<{ script_id: string; name: string; validation_status: string; report: Record<string, unknown> }>(
    `/api/scripts/${id}/validation`,
  );
export const fetchScriptStats = (id: string) => apiFetch<Script>(`/api/scripts/${id}/stats`);
export const fetchScriptHashes = () => apiFetch<ScriptHash[]>("/api/scripts/hashes");
export const fetchMyScripts = () => apiFetch<Script[]>("/api/scripts/mine");
export const fetchCreatorDashboard = (creator: string) =>
  apiFetch<CreatorDashboardResponse>(`/api/creator/dashboard?creator=${encodeURIComponent(creator)}`);

export async function submitScript(data: {
  name: string;
  description: string;
  creator: string;
  code: string;
  packages: string[];
  input_schema: string;
  sample_input?: string;
}): Promise<Script> {
  return apiFetch<Script>("/api/scripts", {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export async function createScriptPR(scriptId: string): Promise<{ pr_url: string; pr_number: number }> {
  return apiFetch(`/api/scripts/${scriptId}/pr`, { method: "POST" });
}

// Notifications
export interface Notification {
  id: string;
  user_email: string;
  type: string;
  title: string;
  message: string;
  script_id?: string;
  read: boolean;
  created_at: string;
}

export const fetchNotifications = () => apiFetch<Notification[]>("/api/notifications");
export const markNotificationRead = (id: string) => apiFetch(`/api/notifications/${id}/read`, { method: "POST" });
export const markAllNotificationsRead = () => apiFetch("/api/notifications/read-all", { method: "POST" });

// Admin
export const fetchAdminScripts = () => apiFetch<Script[]>("/api/admin/scripts");
export const approveScript = (id: string) =>
  apiFetch<{ script_id: string; status: string }>(`/api/admin/scripts/${id}/approve`, { method: "POST" });
export const rejectScript = (id: string) =>
  apiFetch<{ script_id: string; status: string }>(`/api/admin/scripts/${id}/reject`, { method: "POST" });

// Streaming validation
export interface ValidationEvent {
  layer: number;
  name?: string;
  status: "running" | "complete" | "passed" | "skipped" | "pending";
  findings?: number;
  packages?: string[];
  vending_code?: string;
  validation_status?: string;
  script_id?: string;
  submission_id?: string;
}

export async function submitScriptStreaming(
  data: {
    name: string;
    description: string;
    creator: string;
    code: string;
    packages: string[];
    input_schema: string;
    sample_input?: string;
  },
  onEvent: (event: ValidationEvent) => void,
): Promise<void> {
  const authHeaders = await getAuthHeaders();
  const res = await fetch(`${API_BASE}/api/scripts/validate-stream`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders },
    body: JSON.stringify(data),
  });

  if (!res.ok) throw new Error(`API error: ${res.status}`);
  if (!res.body) throw new Error("No response body");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      if (line.startsWith("data: ")) {
        try {
          const event = JSON.parse(line.slice(6)) as ValidationEvent;
          onEvent(event);
        } catch {
          // skip malformed events
        }
      }
    }
  }
}

// Agents
export const fetchAgents = () => apiFetch<Agent[]>("/api/agents");

// Engagements
import type { Engagement, EngagementDepth, EngagementPackage, EngagementTier } from "../types/engagement";

export const createEngagement = (data: {
  package: EngagementPackage;
  tier: EngagementTier;
  depth: EngagementDepth;
  repo_url: string;
  scope_notes: string;
}) =>
  apiFetch<Engagement>("/api/engagements", {
    method: "POST",
    body: JSON.stringify(data),
  });

export const fetchEngagements = () => apiFetch<Engagement[]>("/api/engagements");

export const fetchEngagement = (id: string) =>
  apiFetch<Engagement>(`/api/engagements/${id}`);

export const getReportUrl = (id: string) =>
  `${API_BASE}/api/engagements/${id}/report`;

export const fetchReviewQueue = () =>
  apiFetch<Engagement[]>("/api/admin/engagements/review");

export const deliverEngagement = (id: string, reviewerNotes: string = "") =>
  apiFetch<Engagement>(`/api/admin/engagements/${id}/deliver`, {
    method: "POST",
    body: JSON.stringify({ reviewer_notes: reviewerNotes }),
  });
