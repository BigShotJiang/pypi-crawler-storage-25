import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { useParams, useSearchParams } from "react-router";
import { CodeBlock } from "../components/shared/CodeBlock";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { StatusBadge } from "../components/shared/StatusBadge";
import { fetchScript, fetchScriptValidation } from "../lib/api-client";
import type { Script, ValidationFinding, ValidationReport } from "../types/script";

/* ---------- mock data ---------- */

const MOCK_REPORT: ValidationReport = {
  verdict: "approved",
  risk_score: 12,
  layers: {
    "Static Analysis": {
      passed: true,
      score: 95,
      findings: [],
    },
    "Dependency Audit": {
      passed: true,
      score: 100,
      findings: [
        {
          layer: "Dependency Audit",
          severity: "low",
          title: "reportlab pinned to minor range",
          description: "Consider pinning to exact version for reproducibility.",
        },
      ],
    },
    "Sandbox Probe": {
      passed: true,
      score: 100,
      findings: [],
    },
    "LLM Review": {
      passed: true,
      score: 88,
      findings: [
        {
          layer: "LLM Review",
          severity: "low",
          title: "No input size limit",
          description: "Consider adding a max length check on user_input to prevent memory issues.",
        },
      ],
    },
    "Functionality Test": {
      passed: true,
      score: 92,
      findings: [],
    },
    "Code Quality": {
      passed: true,
      score: 90,
      findings: [
        {
          layer: "Code Quality",
          severity: "low",
          title: "Missing docstring on helper function",
          description: "add_header() lacks a docstring.",
        },
      ],
    },
    "Reliability Test": {
      passed: true,
      score: 96,
      findings: [],
    },
  },
};

const MOCK_SCRIPT: Script = {
  script_id: "scr_abc123",
  vending_code: "S-7K2M",
  name: "PDF Report Generator",
  description: "Generates formatted PDF reports from structured JSON data with charts and tables.",
  creator: "alice@example.com",
  packages: ["reportlab", "matplotlib"],
  price: 3,
  input_schema: '{"type": "object", "properties": {"data": {"type": "string"}}}',
  runs: 247,
  revenue: 741,
  validation_status: "approved",
  validation_report: MOCK_REPORT,
  version: 3,
  code_hash: "a3f8c1d2e5b7",
  versions: [
    {
      version: 1,
      code_hash: "f1a2b3c4d5e6",
      validation_status: "rejected",
      created_at: "2026-03-01T10:00:00Z",
    },
    {
      version: 2,
      code_hash: "b7c8d9e0f1a2",
      validation_status: "approved",
      created_at: "2026-03-15T14:30:00Z",
    },
    {
      version: 3,
      code_hash: "a3f8c1d2e5b7",
      validation_status: "approved",
      created_at: "2026-03-28T09:15:00Z",
    },
  ],
  created_at: "2026-03-01T10:00:00Z",
  code: `import json
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def add_header(c, title):
    c.setFont("Helvetica-Bold", 18)
    c.drawString(72, 750, title)
    c.line(72, 745, 540, 745)

def generate(user_input: str) -> bytes:
    data = json.loads(user_input)
    # ... PDF generation logic
    return pdf_bytes`,
};

/* ---------- Receipt Layer Row ---------- */

interface ReceiptLayerProps {
  name: string;
  passed: boolean;
  findings: ValidationFinding[];
  score?: number;
}

const ReceiptLayer = ({ name, passed, findings, score }: ReceiptLayerProps) => (
  <div className="border-b border-dashed border-gray-300 py-2">
    <div className="flex items-center justify-between">
      <span className="font-bold uppercase">{name}</span>
      <span className="font-bold" style={{ color: passed ? "#228B22" : "#cc0000" }}>
        {passed ? "[PASSED]" : "[FAILED]"}
      </span>
    </div>
    {score != null && <div className="mt-0.5 text-gray-500">Score: {score}/100</div>}
    {findings.length > 0 && (
      <div className="mt-1 space-y-0.5 pl-2">
        {findings.map((f, i) => (
          <div key={`${f.layer}-${f.severity}-${f.title.slice(0, 30)}-${f.line ?? i}`} className="text-gray-600">
            {">"} [{f.severity.toUpperCase()}] {f.title}
          </div>
        ))}
      </div>
    )}
  </div>
);

/* ---------- Neon Confetti ---------- */

const NEON_COLORS = ["#ff2d95", "#00f0ff", "#39ff14", "#fff01f", "#bf00ff"];

function ConfettiParticle({ delay, color, x }: { delay: number; color: string; x: number }) {
  return (
    <motion.div
      className="pointer-events-none absolute top-0 rounded-full"
      style={{
        left: `${x}%`,
        width: Math.random() * 6 + 4,
        height: Math.random() * 12 + 6,
        backgroundColor: color,
        boxShadow: `0 0 6px ${color}, 0 0 12px ${color}60`,
      }}
      initial={{ y: -20, opacity: 1, rotate: 0 }}
      animate={{
        y: 400,
        opacity: [1, 1, 0.6, 0],
        rotate: Math.random() * 720 - 360,
        x: [0, (Math.random() - 0.5) * 100],
      }}
      transition={{ duration: 2 + Math.random(), delay, ease: "easeIn" }}
    />
  );
}

function NeonConfetti() {
  const particles = useMemo(
    () =>
      Array.from({ length: 40 }, (_, i) => ({
        id: i,
        delay: Math.random() * 0.6,
        color: NEON_COLORS[Math.floor(Math.random() * NEON_COLORS.length)],
        x: Math.random() * 100,
      })),
    [],
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((p) => (
        <ConfettiParticle key={p.id} delay={p.delay} color={p.color} x={p.x} />
      ))}
    </div>
  );
}

/* ---------- Page ---------- */

export const ScriptDetailPage = () => {
  const { scriptId } = useParams();
  const [searchParams] = useSearchParams();
  const [receiptVisible, setReceiptVisible] = useState(true);
  const [script, setScript] = useState<Script | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Celebration state — triggered by ?celebrate=true from approval notification
  const shouldCelebrate = searchParams.get("celebrate") === "true";
  const [celebrating, setCelebrating] = useState(false);
  const [slotDisplay, setSlotDisplay] = useState("");
  const [slotLanded, setSlotLanded] = useState(false);

  useEffect(() => {
    if (!scriptId) return;
    let cancelled = false;
    setLoading(true);

    Promise.all([fetchScript(scriptId).catch(() => null), fetchScriptValidation(scriptId).catch(() => null)])
      .then(([scriptData, validationData]) => {
        if (cancelled) return;
        if (scriptData) {
          // API returns { report: {...} } — normalize to validation_report
          const report = validationData?.report as ValidationReport | undefined;
          const merged: Script = {
            ...scriptData,
            ...(report ? { validation_report: report } : {}),
          };
          setScript(merged);
          setError(null);
        } else {
          console.error("Failed to fetch script, using mock data");
          setError("Failed to load script from API. Showing cached data.");
          setScript(MOCK_SCRIPT);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [scriptId]);

  // Trigger celebration animation when navigated with ?celebrate=true
  useEffect(() => {
    if (!script || !shouldCelebrate || celebrating) return;

    // Clear param so refresh doesn't replay
    window.history.replaceState(null, "", window.location.pathname);

    setCelebrating(true);
    setSlotLanded(false);

    const vendingCode = script.vending_code || "S-????";
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let count = 0;
    const interval = setInterval(() => {
      setSlotDisplay(`S-${Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join("")}`);
      count++;
      if (count >= 25) {
        clearInterval(interval);
        setSlotDisplay(vendingCode);
        setSlotLanded(true);
      }
    }, 80);

    return () => clearInterval(interval);
  }, [script, shouldCelebrate, celebrating]);

  if (loading) {
    return (
      <div className="flex justify-center py-32">
        <LoadingSpinner />
      </div>
    );
  }

  if (!script) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-12 text-center">
        <p className="text-white/40">Script not found.</p>
      </div>
    );
  }

  // Normalize backend report format (flat findings) to layered format for the receipt
  const rawReport = script.validation_report;
  const report = rawReport?.layers
    ? rawReport
    : rawReport
      ? (() => {
          const layerNames = [
            "Static Analysis",
            "Dependency Audit",
            "Sandbox Probe",
            "LLM Review",
            "Functionality Test",
            "Code Quality",
            "Reliability Test",
          ];
          const findings = rawReport.findings ?? [];
          const layers: Record<string, { passed: boolean; score?: number; findings: ValidationFinding[] }> = {};
          for (const name of layerNames) {
            const layerKey = name.toLowerCase().replace(/ /g, "_").replace("_test", "").replace("_audit", "");
            const layerFindings = findings
              .filter(
                (f: { layer?: string }) =>
                  f.layer === layerKey ||
                  f.layer === name.toLowerCase().split(" ")[0] ||
                  name.toLowerCase().includes(f.layer ?? ""),
              )
              .map(
                (f: { severity?: string; message?: string; layer?: string }): ValidationFinding => ({
                  layer: name,
                  severity: (f.severity ?? "low") as ValidationFinding["severity"],
                  title: f.message ?? "",
                  description: "",
                }),
              );
            layers[name] = {
              passed: layerFindings.filter((f) => f.severity === "critical" || f.severity === "high").length === 0,
              findings: layerFindings,
            };
          }
          return {
            verdict: rawReport.verdict?.toLowerCase() ?? "unknown",
            risk_score: Math.round((rawReport.riskScore ?? 0) * 100),
            layers,
          };
        })()
      : null;

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      {/* Error banner */}
      {error && (
        <div className="mb-6 rounded-lg border border-yellow-500/30 bg-yellow-500/5 px-4 py-3 text-sm text-yellow-400">
          {error}
        </div>
      )}

      {/* Header */}
      <motion.div
        className="mb-8 flex flex-wrap items-start gap-4"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <motion.span
          className="rounded-lg border border-neon-blue/40 bg-neon-blue/10 px-3 py-1 font-mono text-lg font-bold text-neon-blue"
          style={{ textShadow: "0 0 8px #00f0ff50" }}
          whileHover={{
            boxShadow: "0 0 16px #00f0ff30",
          }}
        >
          {script.vending_code}
        </motion.span>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-white/90">{script.name}</h1>
          <p className="mt-1 text-sm text-white/40">by {script.creator}</p>
        </div>
        <StatusBadge status={script.validation_status} />
      </motion.div>

      {/* Stats Row */}
      <div className="mb-8 flex flex-wrap gap-4">
        {[
          { label: "Runs", value: (script.runs ?? 0).toLocaleString() },
          { label: "Version", value: `v${script.version ?? 1}` },
          {
            label: "Hash",
            value: script.code_hash,
            mono: true,
          },
        ].map((stat) => (
          <GlassCard key={stat.label} className="flex-1 min-w-[120px] !p-4">
            <p className="text-xs text-white/30">{stat.label}</p>
            <p className={`mt-1 text-lg font-semibold ${stat.mono ? "font-mono text-sm" : ""} text-white/80`}>
              {stat.value}
            </p>
          </GlassCard>
        ))}
      </div>

      <p className="mb-8 text-sm leading-relaxed text-white/50">{script.description}</p>

      {/* Celebration — inline where report would be */}
      <AnimatePresence>
        {celebrating && (
          <motion.div
            className="relative mb-8 overflow-hidden rounded-2xl border border-neon-green/30 bg-[#0a0a14] p-8"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            {slotLanded && <NeonConfetti />}

            <div className="relative z-10 flex flex-col items-center gap-4">
              <p className="font-mono text-[10px] tracking-widest text-white/40">VENDING MACHINE MARKETPLACE</p>

              {/* Slot Machine */}
              <motion.div
                className="rounded-xl border-2 px-8 py-4 font-mono text-3xl font-black tracking-[0.2em]"
                style={{
                  borderColor: slotLanded ? "#39ff14" : "#4a4a8a",
                  color: slotLanded ? "#39ff14" : "#00f0ff",
                  background: "#080812",
                  boxShadow: slotLanded
                    ? "0 0 30px rgba(57, 255, 20, 0.4), 0 0 60px rgba(57, 255, 20, 0.2)"
                    : "inset 0 0 20px rgba(0, 240, 255, 0.03)",
                  textShadow: slotLanded ? "0 0 12px #39ff14, 0 0 24px #39ff1460" : "0 0 8px #00f0ff40",
                }}
                animate={slotLanded ? { scale: [1, 1.08, 1] } : {}}
                transition={{ duration: 0.4 }}
              >
                {slotDisplay || "S-????"}
              </motion.div>

              {slotLanded ? (
                <motion.div
                  className="flex flex-col items-center gap-2"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.15 }}
                >
                  <p
                    className="font-mono text-lg font-bold tracking-wider text-neon-green"
                    style={{ textShadow: "0 0 12px #39ff1480" }}
                  >
                    YOUR SCRIPT IS LIVE!
                  </p>
                  <p className="text-center font-mono text-xs text-white/40">
                    Users can now find and run <span className="font-bold text-white/70">{script.name}</span> with code{" "}
                    <span className="font-bold text-neon-blue">{script.vending_code}</span>
                  </p>
                </motion.div>
              ) : (
                <motion.p
                  className="font-mono text-xs text-white/30"
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
                >
                  Generating vending code...
                </motion.p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Validation Report - Receipt Printer */}
      {report && (
        <div className="mb-8">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="neon-text-blue font-mono text-lg text-neon-blue">Validation Report</h2>
            <motion.button
              type="button"
              className="font-mono text-xs text-white/30 transition-colors hover:text-neon-blue"
              onClick={() => setReceiptVisible((v) => !v)}
              whileTap={{ scale: 0.95 }}
            >
              {receiptVisible ? "Hide" : "Print Receipt"}
            </motion.button>
          </div>

          <motion.div
            className="receipt-paper overflow-hidden px-6 py-4"
            initial={{ maxHeight: 0, opacity: 0 }}
            animate={{
              maxHeight: receiptVisible ? 800 : 0,
              opacity: receiptVisible ? 1 : 0,
            }}
            transition={{ duration: 1.5, ease: "easeOut" }}
          >
            {/* Receipt header */}
            <div className="border-b-2 border-double border-gray-400 pb-2 text-center">
              <div className="text-lg font-bold">VENDING MACHINE</div>
              <div>VALIDATION RECEIPT</div>
              <div className="mt-1 text-gray-400">
                {new Date(
                  typeof script.created_at === "number" && script.created_at < 1e12
                    ? script.created_at * 1000
                    : script.created_at,
                ).toLocaleDateString()}
              </div>
            </div>

            <div className="mt-2 border-b border-dashed border-gray-300 pb-2">
              <div>Script: {script.name}</div>
              <div>Code: {script.vending_code}</div>
              <div>Hash: {script.code_hash}</div>
            </div>

            {/* Layers */}
            <div className="mt-2">
              {Object.entries(report.layers).map(([layerName, layerData]) => (
                <ReceiptLayer
                  key={layerName}
                  name={layerName}
                  passed={layerData.passed}
                  findings={layerData.findings}
                  score={layerData.score}
                />
              ))}
            </div>

            {/* Footer */}
            <div className="mt-2 border-t-2 border-double border-gray-400 pt-2 text-center">
              <div className="text-lg font-bold">
                VERDICT:{" "}
                <span
                  style={{
                    color: report.verdict === "approved" ? "#228B22" : "#cc0000",
                  }}
                >
                  {report.verdict.toUpperCase()}
                </span>
              </div>
              <div className="text-gray-400">Risk Score: {report.risk_score}/100</div>
              <div className="mt-2 text-gray-300">--- END OF RECEIPT ---</div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Version History */}
      <div className="mb-8">
        <h2 className="neon-text-blue mb-4 font-mono text-lg text-neon-blue">Version History</h2>
        <GlassCard className="!p-0 overflow-hidden">
          <div className="divide-y divide-white/5">
            {(script.versions ?? []).map((v, i) => (
              <motion.div
                key={v.version}
                className="flex items-center gap-4 px-5 py-3"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                {/* Timeline dot */}
                <div className="flex flex-col items-center">
                  <div
                    className="h-3 w-3 rounded-full"
                    style={{
                      background:
                        v.validation_status === "approved"
                          ? "#39ff14"
                          : v.validation_status === "rejected"
                            ? "#ff2d95"
                            : "#00f0ff",
                      boxShadow: `0 0 8px ${v.validation_status === "approved" ? "#39ff1460" : v.validation_status === "rejected" ? "#ff2d9560" : "#00f0ff60"}`,
                    }}
                  />
                  {i < (script.versions ?? []).length - 1 && <div className="mt-1 h-4 w-px bg-white/10" />}
                </div>
                <div className="flex-1">
                  <span className="font-mono text-sm text-white/70">v{v.version}</span>
                  <span className="ml-3 font-mono text-xs text-white/30">{v.code_hash}</span>
                </div>
                <span className="text-xs text-white/30">
                  {new Date(
                    typeof v.created_at === "number" && v.created_at < 1e12 ? v.created_at * 1000 : v.created_at,
                  ).toLocaleDateString()}
                </span>
                <StatusBadge status={v.validation_status} />
              </motion.div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Code Preview */}
      {script.code && (
        <div>
          <h2 className="neon-text-blue mb-4 font-mono text-lg text-neon-blue">Code Preview</h2>
          <CodeBlock code={script.code} language="python" />
        </div>
      )}
    </div>
  );
};
