import { AnimatePresence, motion } from "framer-motion";
import { type DragEvent, useCallback, useState } from "react";
import { Link } from "react-router";
import { GlassCard } from "../components/shared/GlassCard";
import { ValidationProgress } from "../components/submit/ValidationProgress";
import { submitScriptStreaming, type ValidationEvent } from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";

type SubmitStatus = "idle" | "validating" | "pending" | "rejected";

export const SubmitPage = () => {
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [inputSchema, setInputSchema] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [vendingCode, setVendingCode] = useState<string | null>(null);
  const [submitStatus, setSubmitStatus] = useState<SubmitStatus>("idle");
  const [rejectedScriptId, setRejectedScriptId] = useState<string | null>(null);

  const [reqsFile, setReqsFile] = useState<File | null>(null);

  const handleDrop = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    for (const f of files) {
      if (f.name.endsWith(".py")) setFile(f);
      if (f.name === "requirements.txt") setReqsFile(f);
    }
  }, []);

  const handleDragOver = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOver(false);
  }, []);

  const [submitError, setSubmitError] = useState<string | null>(null);
  const [packages, setPackages] = useState("");
  const [validationEvents, setValidationEvents] = useState<ValidationEvent[]>([]);
  const user = useAuthStore((s) => s.user);

  const handleSubmit = async () => {
    if (!file || !name.trim()) return;
    setIsValidating(true);
    setSubmitStatus("validating");
    setVendingCode(null);
    setSubmitError(null);
    setValidationEvents([]);

    try {
      const code = await file.text();

      let pkgList = packages
        .split(",")
        .map((p) => p.trim())
        .filter(Boolean);
      if (reqsFile && pkgList.length === 0) {
        const reqsContent = await reqsFile.text();
        pkgList = reqsContent
          .split("\n")
          .map((l) => l.trim().split(/[=<>!]/)[0])
          .filter(Boolean);
      }

      await submitScriptStreaming(
        {
          name: name.trim(),
          description: description.trim(),
          creator: user?.email ?? "anonymous",
          code,
          packages: pkgList,
          input_schema: inputSchema.trim() || "Any text input",
        },
        (event) => {
          setValidationEvents((prev) => [...prev, event]);

          if (event.layer === -1 && event.status === "complete") {
            if (event.validation_status === "rejected") {
              setSubmitStatus("rejected");
              setRejectedScriptId(event.script_id ?? null);
              setSubmitError("Script rejected by validation pipeline.");
            } else if (event.validation_status === "pending") {
              setSubmitStatus("pending");
              setVendingCode(event.submission_id ?? "PENDING");
            }
            setIsValidating(false);
          }
        },
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Submission failed.";
      if (msg.includes("409")) {
        setSubmitError("A script with this name already exists. Use a different name or update the existing script.");
      } else {
        setSubmitError(msg);
      }
      setSubmitStatus("idle");
      setIsValidating(false);
    }
  };

  const handleComplete = (_code: string) => {
    // Mock animation completed — no action needed, real submit handles state
  };

  const inputClasses =
    "w-full rounded-lg border border-white/10 bg-[#0d0d1a] px-4 py-3 text-sm text-white/90 font-mono placeholder-white/20 outline-none transition-all duration-200 focus:border-neon-blue focus:shadow-[0_0_12px_#00f0ff30]";

  return (
    <div className="mx-auto max-w-2xl px-6 py-12">
      {/* Heading */}
      <motion.h1
        className="neon-text mb-10 text-center font-mono text-4xl font-bold tracking-wider text-neon-pink"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        SUBMIT SCRIPT
      </motion.h1>

      <GlassCard className="space-y-6">
        {/* File Drop Zone */}
        <motion.div
          className="relative flex min-h-[140px] cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 transition-colors"
          style={{
            borderColor: dragOver ? "#00f0ff" : file ? "#39ff14" : "#4a4a8a60",
            background: dragOver
              ? "rgba(0, 240, 255, 0.05)"
              : file
                ? "rgba(57, 255, 20, 0.03)"
                : "rgba(13, 13, 26, 0.5)",
            boxShadow: dragOver ? "inset 0 0 30px rgba(0, 240, 255, 0.08)" : "none",
          }}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          whileHover={{ borderColor: "#00f0ff80" }}
          transition={{ duration: 0.2 }}
        >
          {file ? (
            <motion.div
              className="flex flex-col items-center gap-2"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
            >
              <span className="font-mono text-2xl text-neon-green">{"\u2713"}</span>
              <span className="font-mono text-sm text-neon-green">{file.name}</span>
              <span className="text-xs text-white/30">{(file.size / 1024).toFixed(1)} KB</span>
              {reqsFile && <span className="font-mono text-xs text-neon-blue">+ {reqsFile.name}</span>}
            </motion.div>
          ) : (
            <div className="flex flex-col items-center gap-2 text-white/30">
              <span className="text-3xl">{"\u21e7"}</span>
              <span className="font-mono text-sm">Drop .py file here</span>
              <span className="text-xs text-white/20">Also accepts requirements.txt</span>
            </div>
          )}
        </motion.div>

        {/* Form Fields */}
        <div className="space-y-4">
          <div>
            <label htmlFor="submit-name" className="mb-1.5 block font-mono text-xs text-white/40">
              Script Name
            </label>
            <input
              id="submit-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. csv-analyzer"
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="submit-description" className="mb-1.5 block font-mono text-xs text-white/40">
              Description
            </label>
            <textarea
              id="submit-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does this script do?"
              rows={3}
              className={`${inputClasses} resize-none`}
            />
          </div>

          <div>
            <label htmlFor="submit-input-schema" className="mb-1.5 block font-mono text-xs text-white/40">
              Input Schema
            </label>
            <textarea
              id="submit-input-schema"
              value={inputSchema}
              onChange={(e) => setInputSchema(e.target.value)}
              placeholder="Describe the expected input format"
              rows={2}
              className={`${inputClasses} resize-none`}
            />
          </div>

          <div>
            <label htmlFor="submit-packages" className="mb-1.5 block font-mono text-xs text-white/40">
              Dependencies (comma-separated)
            </label>
            <input
              id="submit-packages"
              type="text"
              value={packages}
              onChange={(e) => setPackages(e.target.value)}
              placeholder="e.g. requests, pandas, reportlab"
              className={inputClasses}
            />
          </div>
        </div>

        {/* Submit Button / Status Indicator */}
        {submitStatus === "validating" ? (
          <motion.div
            className="flex w-full items-center justify-center rounded-xl border border-neon-blue/40 bg-neon-blue/10 px-6 py-3.5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <span
              className="font-mono text-sm font-bold tracking-wider text-neon-blue"
              style={{ textShadow: "0 0 8px #00f0ff60" }}
            >
              VALIDATING
            </span>
            <motion.span
              className="ml-1 font-mono text-sm font-bold text-neon-blue"
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
            >
              ...
            </motion.span>
          </motion.div>
        ) : submitStatus === "pending" ? (
          <motion.div
            className="flex w-full items-center justify-center rounded-xl border border-neon-green/40 bg-neon-green/10 px-6 py-3.5"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <span
              className="font-mono text-sm font-bold tracking-wider text-neon-green"
              style={{ textShadow: "0 0 8px #39ff1460" }}
            >
              PENDING REVIEW
            </span>
          </motion.div>
        ) : submitStatus === "rejected" ? (
          <motion.div
            className="flex w-full items-center justify-center rounded-xl border border-neon-pink/40 bg-neon-pink/10 px-6 py-3.5"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <span
              className="font-mono text-sm font-bold tracking-wider text-neon-pink"
              style={{ textShadow: "0 0 8px #ff2d9560" }}
            >
              REJECTED
            </span>
          </motion.div>
        ) : (
          <motion.button
            type="button"
            className="w-full rounded-xl border border-neon-pink/40 bg-neon-pink/10 px-6 py-3.5 font-mono text-sm font-bold tracking-wider text-neon-pink transition-colors disabled:cursor-not-allowed disabled:opacity-40"
            style={{ textShadow: "0 0 8px #ff2d9560" }}
            whileHover={
              file && name.trim()
                ? {
                    background: "rgba(255, 45, 149, 0.2)",
                    boxShadow: "0 0 20px rgba(255, 45, 149, 0.3), 0 0 40px rgba(255, 45, 149, 0.15)",
                  }
                : {}
            }
            whileTap={file && name.trim() ? { scale: 0.98 } : {}}
            onClick={handleSubmit}
            disabled={!file || !name.trim()}
          >
            SUBMIT FOR VALIDATION
          </motion.button>
        )}

        {/* Status Messages */}
        <AnimatePresence>
          {submitStatus === "pending" && vendingCode && (
            <motion.div
              className="rounded-xl border border-neon-green/30 bg-neon-green/5 p-4 text-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <p className="font-mono text-sm text-neon-green">
                Script submitted! Tracking ID: <span className="text-lg font-bold">{vendingCode}</span>
              </p>
              <p className="mt-2 font-mono text-xs text-white/40">
                Pending admin review. You'll be notified when approved.
              </p>
            </motion.div>
          )}

          {submitStatus === "rejected" && submitError && (
            <motion.div
              className="rounded-xl border border-neon-pink/30 bg-neon-pink/5 p-4"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <p className="text-center font-mono text-sm text-neon-pink">{submitError}</p>
              {/* Show which layers flagged issues */}
              {validationEvents.filter((e) => e.layer >= 0 && e.findings && e.findings > 0).length > 0 && (
                <div className="mt-3 space-y-1">
                  {validationEvents
                    .filter((e) => e.layer >= 0 && e.findings && e.findings > 0)
                    .map((e) => (
                      <div key={e.layer} className="flex items-center gap-2 font-mono text-xs">
                        <span className="text-neon-yellow">!</span>
                        <span className="text-white/50">{e.name}</span>
                        <span className="text-neon-pink">
                          {e.findings} finding{(e.findings ?? 0) > 1 ? "s" : ""}
                        </span>
                      </div>
                    ))}
                </div>
              )}
              {rejectedScriptId && (
                <div className="mt-3 text-center">
                  <Link
                    to={`/catalog/${rejectedScriptId}`}
                    className="font-mono text-xs text-neon-blue transition-colors hover:text-neon-blue/80"
                    style={{ textShadow: "0 0 6px #00f0ff40" }}
                  >
                    View Full Report &rarr;
                  </Link>
                </div>
              )}
            </motion.div>
          )}

          {submitStatus === "idle" && submitError && (
            <motion.div
              className="rounded-xl border border-neon-pink/30 bg-neon-pink/5 p-4 text-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <p className="font-mono text-sm text-neon-pink">{submitError}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </GlassCard>

      {/* Validation Progress */}
      <ValidationProgress isValidating={isValidating} onComplete={handleComplete} events={validationEvents} />
    </div>
  );
};
