import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { StatusBadge } from "../components/shared/StatusBadge";
import { fetchEngagements } from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";
import type { Engagement, EngagementPackage } from "../types/engagement";

const PACKAGE_STYLES: Record<
  EngagementPackage,
  { icon: string; color: string; label: string }
> = {
  shield: { icon: "\u{1F6E1}", color: "#ff2d95", label: "Shield" },
  blueprint: { icon: "\u{1F3D7}", color: "#00f0ff", label: "Blueprint" },
  launchpad: { icon: "\u{1F680}", color: "#39ff14", label: "LaunchPad" },
};

function formatDate(ts: number | null | undefined): string {
  if (!ts) return "\u2014";
  const d = new Date(ts * 1000);
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const EngagementsPage = () => {
  const { user } = useAuthStore();
  const [engagements, setEngagements] = useState<Engagement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    fetchEngagements()
      .then((data) => {
        if (!cancelled) setEngagements(data);
      })
      .catch(console.error)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <GlassCard>
          <p className="text-gray-400">Sign in to view your engagements.</p>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Engagements</h1>
          <p className="text-sm text-gray-400 mt-1">
            Security audits, architecture reviews, and production readiness assessments.
          </p>
        </div>
        <Link
          to="/engagements/new"
          className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
          style={{
            background: "rgba(0,240,255,0.1)",
            border: "1px solid rgba(0,240,255,0.3)",
            color: "#00f0ff",
          }}
        >
          New Engagement
        </Link>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : engagements.length === 0 ? (
        <GlassCard>
          <div className="text-center py-8">
            <p className="text-gray-400 mb-4">No engagements yet.</p>
            <Link
              to="/engagements/new"
              className="text-cyan-400 hover:text-cyan-300 text-sm"
            >
              Start your first engagement
            </Link>
          </div>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {engagements.map((eng, i) => {
            const pkg = PACKAGE_STYLES[eng.package];
            return (
              <motion.div
                key={eng.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link to={`/engagements/${eng.id}`}>
                  <GlassCard glowColor={pkg.color} className="!p-4">
                    <div className="flex items-center gap-4">
                      <span className="text-xl">{pkg.icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span
                            className="text-sm font-bold"
                            style={{ color: pkg.color }}
                          >
                            {pkg.label}
                          </span>
                          <StatusBadge status={eng.status} />
                          {eng.tier === "premium" && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                              Premium
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 truncate mt-0.5">
                          {eng.repo_url}
                        </p>
                      </div>
                      <div className="text-right text-xs text-gray-500">
                        <div>{formatDate(eng.created_at)}</div>
                        {eng.findings_summary && (
                          <div className="mt-0.5">
                            <span className="text-red-400">
                              {eng.findings_summary.critical}C
                            </span>{" "}
                            <span className="text-orange-400">
                              {eng.findings_summary.high}H
                            </span>{" "}
                            <span className="text-yellow-400">
                              {eng.findings_summary.medium}M
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
