import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import { AuthModal } from "../components/auth/AuthModal";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { StatusBadge } from "../components/shared/StatusBadge";
import { createScriptPR, fetchMyScripts } from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";
import { useToastStore } from "../stores/useToastStore";
import type { ValidationStatus } from "../types/script";

/* ---------- mock data ---------- */

interface DashboardScript {
  script_id: string;
  name: string;
  vending_code: string;
  validation_status: ValidationStatus;
  runs: number;
  version: number;
  pr_url?: string;
}

const MOCK_SCRIPTS: DashboardScript[] = [
  {
    script_id: "scr_abc123",
    name: "PDF Report Generator",
    vending_code: "S-7K2M",
    validation_status: "approved",
    runs: 247,
    version: 3,
    pr_url: "https://github.com/example/repo/pull/42",
  },
  {
    script_id: "scr_def456",
    name: "Data Normalizer",
    vending_code: "S-4N8P",
    validation_status: "pending",
    runs: 0,
    version: 1,
  },
];

export const DashboardPage = () => {
  const { user } = useAuthStore();
  const [showAuth, setShowAuth] = useState(false);
  const [scripts, setScripts] = useState<DashboardScript[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [prLoading, setPrLoading] = useState<string | null>(null);
  const addToast = useToastStore((s) => s.addToast);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    setLoading(true);
    fetchMyScripts()
      .then((data) => {
        if (!cancelled) {
          setScripts(data as unknown as DashboardScript[]);
          setError(null);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          console.error("Failed to fetch scripts, using mock data:", err);
          setError("Failed to load scripts from API. Showing cached data.");
          setScripts(MOCK_SCRIPTS);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  const handleCreatePR = async (scriptId: string) => {
    setPrLoading(scriptId);
    try {
      const result = await createScriptPR(scriptId);
      setScripts((prev) => prev.map((s) => (s.script_id === scriptId ? { ...s, pr_url: result.pr_url } : s)));
      addToast(`PR #${result.pr_number} created successfully`, "success");
    } catch (err) {
      console.error("Failed to create PR:", err);
      addToast("Failed to create PR. Please try again.", "error");
    } finally {
      setPrLoading(null);
    }
  };

  // Not logged in
  if (!user) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <motion.h1
          className="neon-text mb-6 font-mono text-3xl font-bold tracking-wider text-neon-pink"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          MY SCRIPTS
        </motion.h1>
        <GlassCard className="!p-10">
          <p className="mb-6 text-white/50">Sign in to view and manage your submitted scripts.</p>
          <motion.button
            type="button"
            className="rounded-xl border border-neon-pink/40 bg-neon-pink/10 px-8 py-3 font-mono text-sm font-bold tracking-wider text-neon-pink"
            style={{ textShadow: "0 0 8px #ff2d9560" }}
            whileHover={{
              background: "rgba(255, 45, 149, 0.2)",
              boxShadow: "0 0 20px rgba(255, 45, 149, 0.3)",
            }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setShowAuth(true)}
          >
            SIGN IN
          </motion.button>
        </GlassCard>
        {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
      </div>
    );
  }

  // Loading state
  if (loading) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <motion.h1
          className="neon-text mb-6 font-mono text-3xl font-bold tracking-wider text-neon-pink"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          MY SCRIPTS
        </motion.h1>
        <div className="flex justify-center py-16">
          <LoadingSpinner />
        </div>
      </div>
    );
  }

  // Empty state
  if (scripts.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <motion.h1
          className="neon-text mb-6 font-mono text-3xl font-bold tracking-wider text-neon-pink"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          MY SCRIPTS
        </motion.h1>
        <GlassCard className="!p-10">
          <p className="mb-4 text-white/50">No scripts yet. Submit your first script!</p>
          <Link
            to="/submit"
            className="inline-block rounded-lg border border-neon-blue/40 bg-neon-blue/10 px-6 py-2.5 font-mono text-sm font-bold text-neon-blue transition-colors hover:bg-neon-blue/20"
            style={{ textShadow: "0 0 8px #00f0ff50" }}
          >
            GO TO SUBMIT
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      {/* Error banner */}
      {error && (
        <div className="mb-6 rounded-lg border border-yellow-500/30 bg-yellow-500/5 px-4 py-3 text-sm text-yellow-400">
          {error}
        </div>
      )}

      {/* Heading */}
      <motion.div
        className="mb-8 flex items-center justify-between"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="neon-text font-mono text-3xl font-bold tracking-wider text-neon-pink">MY SCRIPTS</h1>
        <Link
          to="/submit"
          className="rounded-lg border border-neon-green/40 bg-neon-green/10 px-4 py-2 font-mono text-xs font-bold text-neon-green transition-colors hover:bg-neon-green/20"
          style={{ textShadow: "0 0 8px #39ff1450" }}
        >
          + NEW SCRIPT
        </Link>
      </motion.div>

      {/* Scripts Table */}
      <GlassCard className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-xs text-white/30">
                <th className="px-5 py-3 font-mono font-normal">Name</th>
                <th className="px-5 py-3 font-mono font-normal">Code</th>
                <th className="px-5 py-3 font-mono font-normal">Status</th>
                <th className="px-5 py-3 font-mono font-normal">Runs</th>
                <th className="px-5 py-3 font-mono font-normal">Version</th>
                <th className="px-5 py-3 font-mono font-normal">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {scripts.map((script, i) => (
                <motion.tr
                  key={script.script_id}
                  className="transition-colors hover:bg-white/[0.02]"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                >
                  <td className="px-5 py-3">
                    <Link
                      to={`/catalog/${script.script_id}`}
                      className="text-white/80 transition-colors hover:text-neon-blue"
                    >
                      {script.name}
                    </Link>
                  </td>
                  <td className="px-5 py-3 font-mono text-neon-blue">{script.vending_code}</td>
                  <td className="px-5 py-3">
                    <StatusBadge status={script.validation_status} />
                  </td>
                  <td className="px-5 py-3 font-mono text-white/50">{script.runs}</td>
                  <td className="px-5 py-3 font-mono text-white/50">v{script.version}</td>
                  <td className="px-5 py-3">
                    {script.pr_url ? (
                      <span className="font-mono text-xs text-white/30">PR #{script.pr_url.split("/").pop()}</span>
                    ) : script.validation_status === "approved" ? (
                      <motion.button
                        type="button"
                        className="rounded-md border border-neon-purple/40 bg-neon-purple/10 px-3 py-1 font-mono text-xs text-neon-purple transition-colors disabled:opacity-40"
                        whileHover={{
                          background: "rgba(191, 0, 255, 0.2)",
                          boxShadow: "0 0 12px rgba(191, 0, 255, 0.2)",
                        }}
                        whileTap={{ scale: 0.95 }}
                        disabled={prLoading === script.script_id}
                        onClick={() => handleCreatePR(script.script_id)}
                      >
                        {prLoading === script.script_id ? "Creating..." : "Create PR"}
                      </motion.button>
                    ) : script.validation_status === "rejected" ? (
                      <Link
                        to={`/catalog/${script.script_id}`}
                        className="font-mono text-xs text-neon-pink transition-colors hover:text-neon-pink/80"
                      >
                        View Report
                      </Link>
                    ) : (
                      <span className="font-mono text-xs text-white/20">Awaiting review</span>
                    )}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};
