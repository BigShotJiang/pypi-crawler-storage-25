import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { StatusBadge } from "../components/shared/StatusBadge";
import { approveScript, fetchAdminScripts, rejectScript } from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";
import { useToastStore } from "../stores/useToastStore";
import type { Script, ValidationStatus } from "../types/script";

export const AdminPage = () => {
  const user = useAuthStore((s) => s.user);
  const addToast = useToastStore((s) => s.addToast);
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | ValidationStatus>("all");
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});
  const [expandedReport, setExpandedReport] = useState<string | null>(null);
  const [accessDenied, setAccessDenied] = useState(false);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    setAccessDenied(false);
    fetchAdminScripts()
      .then(setScripts)
      .catch((err) => {
        if (err.message.includes("403")) {
          setAccessDenied(true);
        } else {
          addToast(`Failed to load scripts: ${err.message}`, "error");
        }
      })
      .finally(() => setLoading(false));
  }, [user, addToast]);

  const handleApprove = async (scriptId: string) => {
    setActionLoading((prev) => ({ ...prev, [scriptId]: true }));
    try {
      await approveScript(scriptId);
      setScripts((prev) => prev.map((s) => (s.script_id === scriptId ? { ...s, validation_status: "approved" } : s)));
      addToast("Script approved!", "success");
    } catch (err) {
      addToast(`Approve failed: ${err instanceof Error ? err.message : "Unknown error"}`, "error");
    }
    setActionLoading((prev) => ({ ...prev, [scriptId]: false }));
  };

  const handleReject = async (scriptId: string) => {
    setActionLoading((prev) => ({ ...prev, [scriptId]: true }));
    try {
      await rejectScript(scriptId);
      setScripts((prev) => prev.map((s) => (s.script_id === scriptId ? { ...s, validation_status: "rejected" } : s)));
      addToast("Script rejected.", "info");
    } catch (err) {
      addToast(`Reject failed: ${err instanceof Error ? err.message : "Unknown error"}`, "error");
    }
    setActionLoading((prev) => ({ ...prev, [scriptId]: false }));
  };

  if (!user) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <GlassCard className="max-w-md p-8 text-center">
          <p className="mb-4 text-white/60">Sign in to access admin panel.</p>
        </GlassCard>
      </div>
    );
  }

  if (accessDenied) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <GlassCard className="max-w-md p-8 text-center">
          <p className="text-lg font-bold text-neon-pink">Access Denied</p>
          <p className="mt-2 text-sm text-white/40">You don't have admin privileges.</p>
        </GlassCard>
      </div>
    );
  }

  const filtered = filter === "all" ? scripts : scripts.filter((s) => s.validation_status === filter);
  const counts = {
    all: scripts.length,
    pending: scripts.filter((s) => s.validation_status === "pending").length,
    flagged: scripts.filter((s) => s.validation_status === "flagged").length,
    approved: scripts.filter((s) => s.validation_status === "approved").length,
    rejected: scripts.filter((s) => s.validation_status === "rejected").length,
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <motion.h1
        className="neon-text mb-2 text-3xl font-bold text-neon-pink"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Admin Panel
      </motion.h1>
      <p className="mb-8 text-sm text-white/40">Review and manage script submissions</p>

      {/* Filter tabs */}
      <div className="mb-6 flex flex-wrap gap-2">
        {(["all", "pending", "flagged", "approved", "rejected"] as const).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFilter(f)}
            className={`rounded-full border px-4 py-1.5 font-mono text-xs font-semibold capitalize transition-all ${
              filter === f
                ? "border-neon-blue bg-neon-blue/10 text-neon-blue"
                : "border-white/10 text-white/40 hover:border-white/30 hover:text-white/60"
            }`}
          >
            {f} ({counts[f]})
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <LoadingSpinner />
        </div>
      ) : filtered.length === 0 ? (
        <GlassCard className="p-8 text-center">
          <p className="text-white/40">No scripts match this filter.</p>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {filtered.map((script) => (
              <motion.div
                key={script.script_id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                <GlassCard className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="mb-1 flex items-center gap-3">
                        <span className="rounded border border-neon-blue/30 bg-neon-blue/10 px-2 py-0.5 font-mono text-xs text-neon-blue">
                          {script.vending_code}
                        </span>
                        <Link
                          to={`/catalog/${script.script_id}`}
                          className="text-sm font-semibold text-white/90 hover:text-neon-blue"
                        >
                          {script.name}
                        </Link>
                        <StatusBadge status={script.validation_status} />
                      </div>
                      <p className="mb-1 text-xs text-white/40">
                        by {script.creator} &middot; v{script.version} &middot; {script.runs} runs &middot; hash:{" "}
                        <span className="font-mono">{script.code_hash}</span>
                      </p>
                      <p className="text-xs text-white/50">{script.description}</p>
                    </div>

                    <div className="flex shrink-0 gap-2">
                      {/* View validation report */}
                      <button
                        type="button"
                        onClick={() => setExpandedReport(expandedReport === script.script_id ? null : script.script_id)}
                        className="rounded border border-white/10 px-3 py-1.5 font-mono text-xs text-white/50 transition-colors hover:border-neon-blue/30 hover:text-neon-blue"
                      >
                        Report
                      </button>

                      {script.validation_status !== "approved" && (
                        <button
                          type="button"
                          onClick={() => handleApprove(script.script_id)}
                          disabled={actionLoading[script.script_id]}
                          className="rounded border border-neon-green/30 bg-neon-green/10 px-3 py-1.5 font-mono text-xs font-bold text-neon-green transition-colors hover:bg-neon-green/20 disabled:opacity-40"
                        >
                          {actionLoading[script.script_id] ? "..." : "Approve"}
                        </button>
                      )}

                      {script.validation_status !== "rejected" && (
                        <button
                          type="button"
                          onClick={() => handleReject(script.script_id)}
                          disabled={actionLoading[script.script_id]}
                          className="rounded border border-neon-pink/30 bg-neon-pink/10 px-3 py-1.5 font-mono text-xs font-bold text-neon-pink transition-colors hover:bg-neon-pink/20 disabled:opacity-40"
                        >
                          {actionLoading[script.script_id] ? "..." : "Reject"}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Expandable validation report */}
                  <AnimatePresence>
                    {expandedReport === script.script_id && script.validation_report && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="receipt-paper mt-4 max-h-96 overflow-auto p-4">
                          <div className="mb-2 border-b border-dashed border-gray-300 pb-2 text-center text-sm font-bold">
                            VALIDATION REPORT
                          </div>
                          <div className="mb-2 text-xs">
                            <strong>Verdict:</strong> {script.validation_report.verdict}
                          </div>
                          <div className="mb-2 text-xs">
                            <strong>Risk Score:</strong> {(script.validation_report.risk_score * 100).toFixed(0)}%
                          </div>
                          {script.validation_report.layers &&
                            Object.entries(script.validation_report.layers).map(([layer, data]) => (
                              <div key={layer} className="mb-2 border-b border-dotted border-gray-200 pb-2">
                                <div className="flex justify-between text-xs font-bold">
                                  <span>{layer}</span>
                                  <span>{data.passed ? "PASS" : "FAIL"}</span>
                                </div>
                                {data.findings?.length > 0 && (
                                  <ul className="ml-2 mt-1">
                                    {data.findings.map((f) => (
                                      <li key={`${layer}-${f.severity}-${f.title}`} className="text-xs text-gray-600">
                                        [{f.severity}] {f.title}
                                      </li>
                                    ))}
                                  </ul>
                                )}
                              </div>
                            ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </GlassCard>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};
