import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { fetchAgents } from "../lib/api-client";
import type { Agent, AgentTier } from "../types/agent";
import { AGENT_TIERS } from "../types/agent";

const FALLBACK_AGENTS: Agent[] = [
  {
    id: "bug-hunter",
    name: "Bug Hunter",
    description:
      "Security vulnerability scanner. Finds injection, XSS, SSRF, and other OWASP Top 10 issues. Builds exploit chains and self-reviews findings.",
    model: "minimax-m2.7",
    category: "coder",
    tier: 1,
  },
  {
    id: "test-goblin",
    name: "Test Goblin",
    description:
      "Comprehensive test generation. Unit, integration, edge cases, dead branch detection, type coercion traps. Powered by Codex.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 1,
  },
  {
    id: "devops-dwarf",
    name: "DevOps Dwarf",
    description:
      "CI/CD, Dockerfiles, Terraform, GitHub Actions. OIDC trusted publishing, matrix testing. Self-reviews and catches gaps.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 1,
  },
  {
    id: "cloud-sensei",
    name: "Cloud Sensei",
    description:
      "AWS architecture, CDK templates, cost optimization, Well-Architected reviews. Finds implementation bugs in its own output.",
    model: "mimo-v2-pro",
    category: "analyst",
    tier: 1,
  },
  {
    id: "pdf-forge",
    name: "PDF Forge",
    description:
      "Professional PDF generation via ReportLab. Invoices, receipts, reports. Auto-executes and saves the PDF locally.",
    model: "claude-sonnet-4.6",
    category: "creative",
    tier: 2,
  },
  {
    id: "number-crunch",
    name: "Number Crunch",
    description:
      "Data analysis with growth rates, anomaly detection, forecasting. Self-corrects calculations in review.",
    model: "minimax-m2.7",
    category: "analyst",
    tier: 2,
  },
  {
    id: "inbox-zero",
    name: "Inbox Zero",
    description:
      "Email and issue triage. Sprint planning, priority matrices, draft responses. Catches missing assignments.",
    model: "minimax-m2.7",
    category: "assistant",
    tier: 2,
  },
  {
    id: "desk-pilot",
    name: "Desk Pilot",
    description:
      "SOPs, meeting agendas, launch checklists. Fast (20s) and comprehensive. Catches process gaps in review.",
    model: "gemini-3-flash",
    category: "assistant",
    tier: 2,
  },
  {
    id: "data-sprite",
    name: "Data Sprite",
    description:
      "Database schemas, SQL migrations, ETL scripts. Full RLS policies, triggers, indexes. Self-reviews for concurrency issues.",
    model: "minimax-m2.7",
    category: "analyst",
    tier: 2,
  },
  {
    id: "mcp-maker",
    name: "MCP Maker",
    description:
      "Generates MCP server code in Python, TypeScript, or Go with proper SDK patterns, transport config, and SQL injection prevention.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 2,
  },
  {
    id: "vibe-writer",
    name: "Vibe Writer",
    description:
      "README intros, LinkedIn posts, blog outlines. Tone-aware with self-review for buzzword check and parallelism.",
    model: "minimax-m2.7",
    category: "creative",
    tier: 2,
  },
  {
    id: "code-gremlin",
    name: "Code Gremlin",
    description:
      "General code generation with plan-code-review pipeline. Writes, debugs, and refactors across 12+ languages.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 3,
  },
  {
    id: "embeddings-agent",
    name: "Embeddings Agent",
    description:
      "Multi-provider embeddings with chunking, cosine similarity analysis. Supports OpenAI, Voyage AI, Gemini.",
    model: "text-embedding-3-small",
    category: "analyst",
    tier: 3,
  },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06 } },
};

const item = {
  hidden: { opacity: 0, y: 15 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35 } },
};

const TierBadge = ({ tier }: { tier: AgentTier }) => {
  const { label, color } = AGENT_TIERS[tier];
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider"
      style={{
        color,
        background: `${color}12`,
        border: `1px solid ${color}35`,
        textShadow: `0 0 6px ${color}50`,
      }}
    >
      T{tier} &middot; {label}
    </span>
  );
};

export const AgentsPage = () => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetchAgents()
      .then((data) => {
        if (cancelled) return;
        // API may return partial data — merge with fallback for missing fields
        const merged = data.map((apiAgent) => {
          const fallback = FALLBACK_AGENTS.find((f) => f.id === apiAgent.id);
          return {
            ...apiAgent,
            description: apiAgent.description || fallback?.description || "",
            category: apiAgent.category || fallback?.category || "coder",
            tier: apiAgent.tier || fallback?.tier || (3 as AgentTier),
          };
        });
        setAgents(merged);
        setError(null);
      })
      .catch((err) => {
        if (cancelled) return;
        console.error("Failed to fetch agents, using mock data:", err);
        setError("Failed to load agents from API. Showing cached data.");
        setAgents(FALLBACK_AGENTS);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <motion.h1
        className="neon-text-blue mb-8 text-3xl font-bold text-neon-blue"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Agent Directory
      </motion.h1>

      {error && (
        <div className="mb-6 rounded-lg border border-yellow-500/30 bg-yellow-500/5 px-4 py-3 text-sm text-yellow-400">
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-20">
          <LoadingSpinner />
        </div>
      ) : (
        <motion.div
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3"
          variants={container}
          initial="hidden"
          animate="show"
        >
          {agents.map((agent) => (
            <motion.div key={agent.id} variants={item}>
              <Link to={`/agents/${agent.id}`} className="block">
                <GlassCard glowColor={AGENT_TIERS[agent.tier].color}>
                  <div className="mb-3 flex items-start justify-between gap-2">
                    <h3 className="text-base font-semibold text-white/90">{agent.name}</h3>
                    <TierBadge tier={agent.tier} />
                  </div>

                  <p className="mb-3 line-clamp-2 text-sm leading-relaxed text-white/50">{agent.description}</p>

                  <div className="flex items-center justify-between text-xs text-white/30">
                    <span className="font-mono">{agent.model}</span>
                    <span className="capitalize">{agent.category}</span>
                  </div>
                </GlassCard>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
};
