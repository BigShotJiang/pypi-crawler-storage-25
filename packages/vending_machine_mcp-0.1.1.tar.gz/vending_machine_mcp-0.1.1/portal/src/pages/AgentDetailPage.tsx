import { motion } from "framer-motion";
import { Link, useParams } from "react-router";
import { GlassCard } from "../components/shared/GlassCard";
import type { Agent, AgentTier } from "../types/agent";
import { AGENT_TIERS } from "../types/agent";

interface AgentDetail extends Agent {
  capabilities: string[];
}

const AGENTS: Record<string, AgentDetail> = {
  "bug-hunter": {
    id: "bug-hunter",
    name: "Bug Hunter",
    description:
      "Security vulnerability scanner. Found jwt.decode() auth bypass, SQL injection, 12 issues with full exploit chain in benchmark test. Self-reviews and corrects severity ratings.",
    model: "minimax-m2.7",
    category: "coder",
    tier: 1,
    capabilities: [
      "OWASP Top 10",
      "MITRE ATT&CK tagging",
      "Exploit chain reconstruction",
      "SQL injection detection",
      "Self-review",
    ],
  },
  "test-goblin": {
    id: "test-goblin",
    name: "Test Goblin",
    description:
      "Comprehensive test generation. Created 6 test groups with edge cases, dead branch detection, and found a real bug (S prefix unreachable) in benchmark. Suggests property-based testing.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 1,
    capabilities: [
      "Unit tests",
      "Edge case detection",
      "Dead branch analysis",
      "Type coercion traps",
      "Property-based testing",
    ],
  },
  "devops-dwarf": {
    id: "devops-dwarf",
    name: "DevOps Dwarf",
    description:
      "CI/CD and infrastructure automation. Built full OIDC trusted publishing pipeline with matrix testing in benchmark. Self-reviewed and caught unpinned action versions.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 1,
    capabilities: ["GitHub Actions", "OIDC publishing", "Dockerfiles", "Terraform", "Matrix testing"],
  },
  "cloud-sensei": {
    id: "cloud-sensei",
    name: "Cloud Sensei",
    description:
      "AWS architecture specialist. Designed full CDK stack with $13/mo cost estimate and found a non-functional WebSocket bug in its own output. Well-Architected reviews.",
    model: "mimo-v2-pro",
    category: "analyst",
    tier: 1,
    capabilities: ["AWS CDK", "Cost optimization", "Well-Architected review", "Lambda + API Gateway", "VPC design"],
  },
  "pdf-forge": {
    id: "pdf-forge",
    name: "PDF Forge",
    description:
      "Professional PDF generation via ReportLab. Creates invoices, receipts, reports with custom branding. Auto-executes the generated script and saves the PDF locally.",
    model: "claude-sonnet-4.6",
    category: "creative",
    tier: 2,
    capabilities: ["ReportLab", "Invoice generation", "Custom branding", "Auto-execution", "Typography"],
  },
  "number-crunch": {
    id: "number-crunch",
    name: "Number Crunch",
    description:
      "Data analysis with growth rates, anomaly detection, exponential smoothing forecasts. Self-corrected a standard deviation calculation during review.",
    model: "minimax-m2.7",
    category: "analyst",
    tier: 2,
    capabilities: ["Growth rates", "Anomaly detection", "Forecasting", "Correlation analysis", "Self-correction"],
  },
  "inbox-zero": {
    id: "inbox-zero",
    name: "Inbox Zero",
    description:
      "Email and issue triage. Sprint planning with P0-P3 prioritization, draft responses, follow-up checklists. Caught missing owner assignments in self-review.",
    model: "minimax-m2.7",
    category: "assistant",
    tier: 2,
    capabilities: ["Email triage", "Sprint planning", "Priority scoring", "Draft responses", "Follow-up tracking"],
  },
  "desk-pilot": {
    id: "desk-pilot",
    name: "Desk Pilot",
    description:
      "SOPs, meeting agendas, launch checklists. Fastest agent (20s). Built a complete Product Hunt launch SOP with hour-by-hour timeline in benchmark.",
    model: "gemini-3-flash",
    category: "assistant",
    tier: 2,
    capabilities: ["SOPs", "Meeting agendas", "Launch planning", "Task management", "Process documentation"],
  },
  "data-sprite": {
    id: "data-sprite",
    name: "Data Sprite",
    description:
      "Database schemas, SQL migrations, ETL scripts. Generated full schema with triggers, RLS policies, generated columns. Self-reviewed for concurrency issues.",
    model: "minimax-m2.7",
    category: "analyst",
    tier: 2,
    capabilities: ["Schema design", "SQL migrations", "RLS policies", "Trigger logic", "Index optimization"],
  },
  "mcp-maker": {
    id: "mcp-maker",
    name: "MCP Maker",
    description:
      "Generates MCP server code in Python (FastMCP), TypeScript, or Go. Built a SQLite MCP server with SQL injection prevention and Pydantic validation in benchmark.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 2,
    capabilities: [
      "Python FastMCP",
      "TypeScript McpServer",
      "SQL injection prevention",
      "Tool definitions",
      "Transport config",
    ],
  },
  "vibe-writer": {
    id: "vibe-writer",
    name: "Vibe Writer",
    description:
      "README intros, LinkedIn posts, blog outlines. Tone-aware copy with self-review for buzzword check, parallelism, and CTA effectiveness.",
    model: "minimax-m2.7",
    category: "creative",
    tier: 2,
    capabilities: ["README writing", "LinkedIn posts", "Blog outlines", "Tone matching", "Self-review"],
  },
  "code-gremlin": {
    id: "code-gremlin",
    name: "Code Gremlin",
    description:
      "General code generation with plan-code-review pipeline. Writes, debugs, refactors across 12+ languages. Self-found 4 bugs in its own output during benchmark.",
    model: "gpt-5.3-codex",
    category: "coder",
    tier: 3,
    capabilities: ["Code generation", "Bug fixing", "Refactoring", "Multi-language", "Self-review"],
  },
  "embeddings-agent": {
    id: "embeddings-agent",
    name: "Embeddings Agent",
    description:
      "Multi-provider embeddings with chunking, cosine similarity analysis. Supports OpenAI, Voyage AI, Gemini providers.",
    model: "text-embedding-3-small",
    category: "analyst",
    tier: 3,
    capabilities: ["OpenAI embeddings", "Voyage AI", "Gemini embeddings", "Chunking", "Similarity analysis"],
  },
};

const TierBadge = ({ tier }: { tier: AgentTier }) => {
  const { label, color } = AGENT_TIERS[tier];
  return (
    <span
      className="inline-flex items-center rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider"
      style={{
        color,
        background: `${color}12`,
        border: `1px solid ${color}35`,
        textShadow: `0 0 6px ${color}50`,
      }}
    >
      Tier {tier} &middot; {label}
    </span>
  );
};

export const AgentDetailPage = () => {
  const { agentId } = useParams<{ agentId: string }>();
  const agent = agentId ? AGENTS[agentId] : undefined;

  if (!agent) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <p className="mb-4 text-lg text-white/50">Agent not found.</p>
        <Link to="/agents" className="text-sm text-neon-blue hover:underline">
          Back to Agents
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <Link
        to="/agents"
        className="mb-6 inline-flex items-center gap-1 text-sm text-white/40 transition-colors hover:text-neon-blue"
      >
        <svg
          className="h-4 w-4"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
          aria-hidden="true"
        >
          <title>Back arrow</title>
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
        Back to Agents
      </Link>

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <GlassCard glowColor={AGENT_TIERS[agent.tier].color} className="mb-6">
          <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
            <h1 className="text-2xl font-bold text-white/95">{agent.name}</h1>
            <TierBadge tier={agent.tier} />
          </div>

          <p className="mb-6 leading-relaxed text-white/60">{agent.description}</p>

          {/* Meta row */}
          <div className="mb-6 flex flex-wrap gap-4 text-sm text-white/40">
            <span>
              <span className="text-white/20">Model: </span>
              <span className="font-mono text-neon-blue/80">{agent.model}</span>
            </span>
            <span>
              <span className="text-white/20">Category: </span>
              <span className="capitalize">{agent.category}</span>
            </span>
          </div>

          {/* Capabilities */}
          <div>
            <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-white/30">Capabilities</h2>
            <div className="flex flex-wrap gap-2">
              {agent.capabilities.map((cap) => (
                <span
                  key={cap}
                  className="rounded-lg border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs text-white/60"
                >
                  {cap}
                </span>
              ))}
            </div>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
};
