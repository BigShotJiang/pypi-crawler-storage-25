import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { GlassCard } from "../components/shared/GlassCard";
import { useAuthStore } from "../stores/useAuthStore";

interface NotificationPrefs {
  email_approved: boolean;
  email_rejected: boolean;
  email_submitted: boolean;
  email_admin: boolean;
}

const DEFAULT_PREFS: NotificationPrefs = {
  email_approved: true,
  email_rejected: true,
  email_submitted: true,
  email_admin: true,
};

function Toggle({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between py-3">
      <div>
        <p className="text-sm text-white/80">{label}</p>
        <p className="text-xs text-white/30">{description}</p>
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className="relative h-6 w-11 shrink-0 rounded-full transition-colors"
        style={{
          backgroundColor: checked ? "rgba(57, 255, 20, 0.3)" : "rgba(255, 255, 255, 0.1)",
          border: `1px solid ${checked ? "rgba(57, 255, 20, 0.5)" : "rgba(255, 255, 255, 0.15)"}`,
        }}
        aria-label={`Toggle ${label}`}
      >
        <motion.div
          className="absolute top-0.5 h-4 w-4 rounded-full"
          style={{ backgroundColor: checked ? "#39ff14" : "#666" }}
          animate={{ left: checked ? 22 : 3 }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
        />
      </button>
    </div>
  );
}

export const ProfilePage = () => {
  const { user, signOut } = useAuthStore();
  const [prefs, setPrefs] = useState<NotificationPrefs>(DEFAULT_PREFS);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Load prefs from backend on mount
  useEffect(() => {
    if (!user) return;
    fetch("/api/profile/prefs")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.notification_prefs) {
          setPrefs({ ...DEFAULT_PREFS, ...data.notification_prefs });
        }
      })
      .catch(() => {});
  }, [user]);

  const updatePref = (key: keyof NotificationPrefs, value: boolean) => {
    const newPrefs = { ...prefs, [key]: value };
    setPrefs(newPrefs);
    setSaving(true);
    setSaved(false);

    fetch("/api/profile/prefs", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ notification_prefs: newPrefs }),
    })
      .then(() => {
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      })
      .catch(() => {})
      .finally(() => setSaving(false));
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <motion.h1
        className="neon-text-blue mb-8 text-3xl font-bold text-neon-blue"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Profile
      </motion.h1>

      {/* Account info */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <GlassCard className="mb-6">
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-white/30">Account</h2>
          <div className="mb-6 flex items-center gap-4">
            <div
              className="flex h-12 w-12 items-center justify-center rounded-full text-lg font-bold"
              style={{
                background: "rgba(0,240,255,0.1)",
                border: "1px solid rgba(0,240,255,0.3)",
                color: "#00f0ff",
              }}
            >
              {user?.email?.charAt(0).toUpperCase() ?? "?"}
            </div>
            <div>
              <div className="text-sm text-white/80">{user?.email ?? "Not signed in"}</div>
              <div className="text-xs text-white/30">
                Member since {user?.created_at ? new Date(user.created_at).toLocaleDateString() : "--"}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => signOut()}
            className="rounded-lg border border-neon-pink/30 bg-neon-pink/10 px-5 py-2 text-sm font-semibold text-neon-pink transition-all hover:bg-neon-pink/20 hover:shadow-[0_0_12px_rgba(255,45,149,0.15)]"
          >
            Sign Out
          </button>
        </GlassCard>
      </motion.div>

      {/* Authentication */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <GlassCard className="mb-6">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-white/30">Authentication</h2>
          <p className="text-sm text-white/50">
            Your marketplace session is managed via Supabase Auth. The MCP server authenticates using your session token
            automatically — no API keys needed.
          </p>
          <div className="mt-3 rounded-lg bg-white/5 px-4 py-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-white/40">Session</span>
              <span className="rounded-full bg-neon-green/10 px-2 py-0.5 font-mono text-[10px] text-neon-green">
                Active
              </span>
            </div>
          </div>
        </GlassCard>
      </motion.div>

      {/* Notification Preferences */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <GlassCard>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-white/30">Email Notifications</h2>
            {saving && <span className="font-mono text-[10px] text-white/20">Saving...</span>}
            {saved && <span className="font-mono text-[10px] text-neon-green">Saved</span>}
          </div>

          <div className="divide-y divide-white/5">
            <Toggle
              label="Script Submitted"
              description="Confirmation when you submit a script for review"
              checked={prefs.email_submitted}
              onChange={(v) => updatePref("email_submitted", v)}
            />
            <Toggle
              label="Script Approved"
              description="Alert when your script passes review and goes live"
              checked={prefs.email_approved}
              onChange={(v) => updatePref("email_approved", v)}
            />
            <Toggle
              label="Script Rejected"
              description="Alert when your script fails review with details"
              checked={prefs.email_rejected}
              onChange={(v) => updatePref("email_rejected", v)}
            />
            <Toggle
              label="Admin Alerts"
              description="New submission alerts (admin only)"
              checked={prefs.email_admin}
              onChange={(v) => updatePref("email_admin", v)}
            />
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
};
