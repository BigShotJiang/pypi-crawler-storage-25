import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import { FindingsSummary } from "../components/engagements/FindingsSummary";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import {
  fetchEngagement,
  fetchEngagements,
  getReportUrl,
} from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";
import type {
  Engagement,
  EngagementPackage,
  EngagementStep,
} from "../types/engagement";

const PACKAGE_STYLES: Record<
  EngagementPackage,
  { icon: string; color: string; label: string }
> = {
  shield: { icon: "\u{1F6E1}", color: "#ff2d95", label: "Shield" },
  blueprint: { icon: "\u{1F3D7}", color: "#00f0ff", label: "Blueprint" },
  launchpad: { icon: "\u{1F680}", color: "#39ff14", label: "LaunchPad" },
};

function formatDate(ts: number | null | undefined): string {
  if (!ts) return "\u2014";
  const d = new Date(ts * 1000);
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatDuration(ms: number): string {
  if (ms < 60_000) return `${(ms / 1000).toFixed(0)}s`;
  return `${(ms / 60_000).toFixed(1)}m`;
}

function AgentOutputCard({ step }: { step: EngagementStep }) {
  const [expanded, setExpanded] = useState(false);
  const output = step.output || "";
  const preview = output.slice(0, 200);
  const hasMore = output.length > 200;

  if (!output) return null;

  return (
    <div className="rounded-lg bg-white/[0.02] border border-white/5 overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-3 py-2 text-left hover:bg-white/[0.03] transition-colors"
      >
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-white/70">
            {step.agent_name}
          </span>
          {step.runtime_ms > 0 && (
            <span className="text-[10px] text-gray-600 font-mono">
              {formatDuration(step.runtime_ms)}
            </span>
          )}
        </div>
        <span className="text-[10px] text-gray-600">
          {expanded ? "\u25B2" : "\u25BC"}
        </span>
      </button>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <pre className="px-3 pb-3 text-[11px] text-gray-400 whitespace-pre-wrap break-words max-h-96 overflow-y-auto leading-relaxed">
              {output}
            </pre>
          </motion.div>
        )}
        {!expanded && preview && (
          <div className="px-3 pb-2">
            <p className="text-[11px] text-gray-600 truncate">
              {preview}
              {hasMore && "..."}
            </p>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function InboxItem({ engagement: eng }: { engagement: Engagement }) {
  const pkg = PACKAGE_STYLES[eng.package];
  const hasReport = !!eng.report_path;
  const hasFindings = !!eng.findings_summary;
  const [steps, setSteps] = useState<EngagementStep[] | null>(null);
  const [showOutputs, setShowOutputs] = useState(false);
  const [loadingOutputs, setLoadingOutputs] = useState(false);

  const loadOutputs = async () => {
    // Autonomous mode: output is already on the engagement, no fetch needed
    if (eng.depth === "autonomous" && eng.output) {
      setShowOutputs(!showOutputs);
      return;
    }
    if (steps) {
      setShowOutputs(!showOutputs);
      return;
    }
    setLoadingOutputs(true);
    try {
      const detail = await fetchEngagement(eng.id);
      setSteps(detail.steps || []);
      setShowOutputs(true);
    } catch {
      // silently fail
    } finally {
      setLoadingOutputs(false);
    }
  };

  return (
    <GlassCard glowColor={pkg.color}>
      <div className="flex items-start gap-4">
        {/* Icon */}
        <div className="flex-shrink-0 pt-1">
          <span className="text-2xl">{pkg.icon}</span>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-bold text-sm" style={{ color: pkg.color }}>
              {pkg.label}
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-green-500/10 text-green-400 border border-green-500/20">
              Delivered
            </span>
            {eng.tier === "premium" && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                Premium
              </span>
            )}
          </div>

          <p className="text-xs text-gray-500 truncate mb-3">{eng.repo_url}</p>

          {/* Action buttons */}
          <div className="flex flex-wrap gap-2 mb-3">
            {hasReport && (
              <a
                href={getReportUrl(eng.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                style={{
                  background: `${pkg.color}15`,
                  border: `1px solid ${pkg.color}30`,
                  color: pkg.color,
                }}
              >
                {"\u{1F4C4}"} Download PDF
              </a>
            )}
            <Link
              to={`/engagements/${eng.id}`}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all bg-white/5 border border-white/10 text-gray-300 hover:text-white hover:border-white/20"
            >
              {"\u{1F50D}"} View Details
            </Link>
            <button
              type="button"
              onClick={loadOutputs}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all bg-white/5 border border-white/10 text-gray-300 hover:text-white hover:border-white/20"
            >
              {loadingOutputs ? (
                <LoadingSpinner />
              ) : (
                <>
                  {"\u{1F4DD}"} {showOutputs ? "Hide" : "Show"} {eng.depth === "autonomous" ? "Report" : "Agent Outputs"}
                </>
              )}
            </button>
          </div>

          {/* Findings inline */}
          {hasFindings && (
            <div className="max-w-xs mb-3">
              <FindingsSummary findings={eng.findings_summary!} />
            </div>
          )}

          {/* Expandable outputs — agent steps OR autonomous output */}
          <AnimatePresence>
            {showOutputs && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="space-y-2 overflow-hidden"
              >
                {/* Autonomous mode: single Claude Code output */}
                {eng.depth === "autonomous" && eng.output ? (
                  <>
                    <div className="text-[10px] text-gray-500 uppercase tracking-wider font-bold pt-2 border-t border-white/5">
                      Claude Code Output
                    </div>
                    <div className="rounded-lg bg-white/[0.02] border border-white/5 p-3">
                      <pre className="text-[11px] text-gray-400 whitespace-pre-wrap break-words max-h-96 overflow-y-auto leading-relaxed">
                        {eng.output}
                      </pre>
                    </div>
                  </>
                ) : steps && steps.length > 0 ? (
                  <>
                    <div className="text-[10px] text-gray-500 uppercase tracking-wider font-bold pt-2 border-t border-white/5">
                      Agent Outputs
                    </div>
                    {steps
                      .filter((s) => s.output && s.status === "complete")
                      .map((step) => (
                        <AgentOutputCard key={step.job_id} step={step} />
                      ))}
                    {steps.filter((s) => s.output).length === 0 && (
                      <p className="text-xs text-gray-600 py-2">
                        No agent outputs available.
                      </p>
                    )}
                  </>
                ) : eng.output ? (
                  <div className="rounded-lg bg-white/[0.02] border border-white/5 p-3">
                    <pre className="text-[11px] text-gray-400 whitespace-pre-wrap break-words max-h-96 overflow-y-auto leading-relaxed">
                      {eng.output}
                    </pre>
                  </div>
                ) : (
                  <p className="text-xs text-gray-600 py-2 pt-2 border-t border-white/5">
                    No outputs available.
                  </p>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Metadata */}
        <div className="flex-shrink-0 text-right text-[11px] text-gray-500 space-y-1">
          <div>{formatDate(eng.delivered_at || eng.completed_at)}</div>
          <div className="font-mono">{formatDuration(eng.total_runtime_ms)}</div>
          <div className="font-mono">${eng.total_cost.toFixed(2)}</div>
        </div>
      </div>

      {/* Reviewer notes */}
      {eng.reviewer_notes && (
        <div className="mt-3 pt-3 border-t border-white/5">
          <span className="text-[10px] text-yellow-400 font-bold">
            Reviewer Notes
          </span>
          <p className="text-xs text-gray-400 mt-1">{eng.reviewer_notes}</p>
        </div>
      )}
    </GlassCard>
  );
}

export const InboxPage = () => {
  const { user } = useAuthStore();
  const [engagements, setEngagements] = useState<Engagement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    fetchEngagements()
      .then((data) => {
        if (!cancelled) {
          setEngagements(
            data.filter(
              (e) => e.status === "delivered" || e.status === "review",
            ),
          );
        }
      })
      .catch(console.error)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <GlassCard>
          <p className="text-gray-400">Sign in to view your inbox.</p>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Inbox</h1>
          <p className="text-sm text-gray-400 mt-1">
            Delivered reports and engagement artifacts.
          </p>
        </div>
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : engagements.length === 0 ? (
        <GlassCard>
          <div className="text-center py-12">
            <span className="text-4xl block mb-4">{"\u{1F4EC}"}</span>
            <p className="text-gray-400 mb-2">No deliverables yet.</p>
            <p className="text-xs text-gray-600">
              Completed engagements will appear here with downloadable reports.
            </p>
            <Link
              to="/engagements/new"
              className="inline-block mt-4 text-cyan-400 hover:text-cyan-300 text-sm"
            >
              Start an engagement
            </Link>
          </div>
        </GlassCard>
      ) : (
        <div className="space-y-4">
          {engagements.map((eng, i) => (
            <motion.div
              key={eng.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <InboxItem engagement={eng} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
