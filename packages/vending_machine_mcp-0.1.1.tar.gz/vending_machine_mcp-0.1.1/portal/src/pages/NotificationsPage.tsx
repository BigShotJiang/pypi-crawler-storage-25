import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import {
  fetchNotifications,
  markAllNotificationsRead,
  markNotificationRead,
  type Notification,
} from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";

const TYPE_CONFIG: Record<string, { color: string; icon: string; label: string }> = {
  script_submitted: { color: "#fff01f", icon: "\uD83D\uDCE4", label: "Submitted" },
  script_approved: { color: "#39ff14", icon: "\u2705", label: "Approved" },
  script_rejected: { color: "#ff2d95", icon: "\u274C", label: "Rejected" },
  script_flagged: { color: "#fff01f", icon: "\u26A0\uFE0F", label: "Flagged" },
  admin_new_submission: { color: "#00f0ff", icon: "\uD83D\uDCEC", label: "Admin Review" },
};

function timeAgo(dateStr: string): string {
  const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

function extractSubmissionId(message: string): string | null {
  const match = message.match(/SUB-[A-Z0-9]+/);
  return match ? match[0] : null;
}

export const NotificationsPage = () => {
  const user = useAuthStore((s) => s.user);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchNotifications()
      .then(setNotifications)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user]);

  const handleMarkRead = async (id: string) => {
    await markNotificationRead(id);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const handleMarkAllRead = async () => {
    await markAllNotificationsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <p className="text-white/40">Sign in to view notifications.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center py-32">
        <LoadingSpinner />
      </div>
    );
  }

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      <motion.div
        className="mb-8 flex items-center justify-between"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="neon-text font-mono text-3xl font-bold tracking-wider text-neon-pink">NOTIFICATIONS</h1>
        {unreadCount > 0 && (
          <button
            type="button"
            onClick={handleMarkAllRead}
            className="rounded-lg border border-neon-blue/30 bg-neon-blue/10 px-4 py-2 font-mono text-xs text-neon-blue transition-colors hover:bg-neon-blue/20"
          >
            Mark all read ({unreadCount})
          </button>
        )}
      </motion.div>

      {notifications.length === 0 ? (
        <GlassCard className="!p-10 text-center">
          <p className="text-white/40">No notifications yet.</p>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {notifications.map((n, i) => {
            const config = TYPE_CONFIG[n.type] ?? { color: "#4a4a8a", icon: "\uD83D\uDCCC", label: "Info" };
            const submissionId = extractSubmissionId(n.message);

            return (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
              >
                <GlassCard className={`!p-0 transition-all ${n.read ? "opacity-60" : ""}`}>
                  <div className="flex gap-4 p-5">
                    {/* Icon */}
                    <div className="shrink-0 pt-0.5 text-xl">{config.icon}</div>

                    {/* Content */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-semibold text-white/90">{n.title}</span>
                        <span
                          className="rounded-full px-2 py-0.5 font-mono text-[10px] font-bold"
                          style={{
                            backgroundColor: `${config.color}15`,
                            color: config.color,
                            border: `1px solid ${config.color}30`,
                          }}
                        >
                          {config.label}
                        </span>
                        {!n.read && <span className="h-2 w-2 rounded-full" style={{ backgroundColor: config.color }} />}
                      </div>

                      <p className="mt-2 text-sm leading-relaxed text-white/50">{n.message}</p>

                      {/* Metadata row */}
                      <div className="mt-3 flex flex-wrap items-center gap-4 text-xs">
                        <span className="text-white/25">{timeAgo(n.created_at)}</span>

                        {submissionId && (
                          <span className="rounded-md bg-white/5 px-2 py-0.5 font-mono text-neon-yellow">
                            {submissionId}
                          </span>
                        )}

                        {n.script_id && (
                          <Link
                            to={
                              n.type === "script_approved"
                                ? `/catalog/${n.script_id}?celebrate=true`
                                : `/catalog/${n.script_id}`
                            }
                            className="font-mono text-neon-blue transition-colors hover:text-neon-blue/80"
                          >
                            View Script
                          </Link>
                        )}

                        {!n.read && (
                          <button
                            type="button"
                            onClick={() => handleMarkRead(n.id)}
                            className="text-white/30 transition-colors hover:text-white/60"
                          >
                            Mark read
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
