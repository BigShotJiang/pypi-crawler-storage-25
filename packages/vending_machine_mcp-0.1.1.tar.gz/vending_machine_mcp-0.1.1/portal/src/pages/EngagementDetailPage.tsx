import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router";
import { FindingsSummary } from "../components/engagements/FindingsSummary";
import { PipelineStepper } from "../components/engagements/PipelineStepper";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { StatusBadge } from "../components/shared/StatusBadge";
import { fetchEngagement, getReportUrl } from "../lib/api-client";
import type { Engagement, EngagementPackage } from "../types/engagement";
import { PACKAGES } from "../types/engagement";

const PKG_COLORS: Record<EngagementPackage, string> = {
  shield: "#ff2d95",
  blueprint: "#00f0ff",
  launchpad: "#39ff14",
};

function formatDuration(ms: number): string {
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60_000).toFixed(1)}m`;
}

export const EngagementDetailPage = () => {
  const { engagementId } = useParams<{ engagementId: string }>();
  const [engagement, setEngagement] = useState<Engagement | null>(null);
  const [loading, setLoading] = useState(true);
  const [pollError, setPollError] = useState<string | null>(null);
  const engagementRef = useRef(engagement);
  engagementRef.current = engagement;

  useEffect(() => {
    if (!engagementId) return;
    let cancelled = false;
    let retries = 0;

    const poll = async () => {
      try {
        const data = await fetchEngagement(engagementId);
        if (!cancelled) {
          setEngagement(data);
          setPollError(null);
          retries = 0;
        }
      } catch (err) {
        retries++;
        if (!cancelled && retries >= 3) {
          setPollError("Failed to fetch engagement status.");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    poll();
    const interval = setInterval(() => {
      const status = engagementRef.current?.status;
      if (status === "running" || status === "intake") {
        poll();
      }
    }, 5000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [engagementId]);

  if (loading) return <LoadingSpinner />;
  if (!engagement) {
    return (
      <div className="text-center py-16 text-gray-400">
        Engagement not found
      </div>
    );
  }

  const color = PKG_COLORS[engagement.package];
  const pkgInfo = PACKAGES.find((p) => p.id === engagement.package);
  const totalSteps = pkgInfo?.agents.length ?? 0;
  const isComplete =
    engagement.status === "delivered" || engagement.status === "review";

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <span className="text-2xl">{pkgInfo?.icon}</span>
          <h1 className="text-xl font-bold" style={{ color }}>
            {pkgInfo?.name}
          </h1>
          <StatusBadge status={engagement.status} />
          {engagement.tier === "premium" && (
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
              Premium
            </span>
          )}
        </div>
        <p className="text-sm text-gray-500">{engagement.repo_url}</p>
        {engagement.scope_notes && (
          <p className="text-xs text-gray-600 mt-1">
            {engagement.scope_notes}
          </p>
        )}
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Pipeline Progress */}
        <GlassCard className="md:col-span-2" glowColor={color}>
          <h2
            className="text-sm font-bold mb-4"
            style={{ color: "rgba(255,255,255,0.7)" }}
          >
            Pipeline Progress
          </h2>
          {/* Progress bar */}
          {(engagement.status === "running" || engagement.status === "intake") && (
            <div className="mb-4">
              <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                <span>Step {engagement.current_step} of {totalSteps}</span>
                <span>{Math.round((engagement.current_step / totalSteps) * 100)}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: `linear-gradient(90deg, ${color}, ${color}80)` }}
                  initial={{ width: 0 }}
                  animate={{ width: `${(engagement.current_step / totalSteps) * 100}%` }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                />
                {/* Shimmer overlay on the filled portion */}
                <motion.div
                  className="h-full rounded-full -mt-1.5"
                  style={{
                    background: `linear-gradient(90deg, transparent, ${color}30, transparent)`,
                    width: `${(engagement.current_step / totalSteps) * 100}%`,
                  }}
                  animate={{ x: ["-100%", "100%"] }}
                  transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                />
              </div>
            </div>
          )}

          {engagement.steps && engagement.steps.length > 0 ? (
            <PipelineStepper
              steps={engagement.steps}
              currentStep={engagement.current_step}
              totalSteps={totalSteps}
              agentNames={pkgInfo?.agents ?? []}
              packageColor={color}
              engagementStatus={engagement.status}
            />
          ) : engagement.status === "running" || engagement.status === "intake" ? (
            <PipelineStepper
              steps={[]}
              currentStep={0}
              totalSteps={totalSteps}
              agentNames={pkgInfo?.agents ?? []}
              packageColor={color}
              engagementStatus={engagement.status}
            />
          ) : (
            <p className="text-sm text-gray-500">
              Pipeline not started
            </p>
          )}
          {pollError && (
            <div className="mt-3 text-xs text-red-400 bg-red-500/10 px-3 py-2 rounded">
              {pollError}
            </div>
          )}
        </GlassCard>

        {/* Stats */}
        <div className="space-y-4">
          {/* Inbox link */}
          {isComplete && (
            <Link
              to="/inbox"
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-xs font-medium transition-all bg-white/[0.03] border border-white/10 text-gray-300 hover:text-white hover:border-white/20 hover:bg-white/[0.06]"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="22 12 16 12 14 15 10 15 8 12 2 12" />
                <path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" />
              </svg>
              See details in Inbox
            </Link>
          )}
          {/* Metadata */}
          <GlassCard>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-500">Runtime</span>
                <span className="text-white font-mono">
                  {engagement.total_runtime_ms > 0
                    ? formatDuration(engagement.total_runtime_ms)
                    : "\u2014"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Cost</span>
                <span className="text-white font-mono">
                  ${engagement.total_cost.toFixed(4)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Steps</span>
                <span className="text-white font-mono">
                  {engagement.current_step}/{totalSteps}
                </span>
              </div>
            </div>
          </GlassCard>

          {/* Findings */}
          {engagement.findings_summary && (
            <GlassCard>
              <h3
                className="text-xs font-bold mb-3"
                style={{ color: "rgba(255,255,255,0.7)" }}
              >
                Findings
              </h3>
              <FindingsSummary findings={engagement.findings_summary} />
            </GlassCard>
          )}
        </div>
      </div>

      {/* Report Download */}
      {isComplete && engagement.report_path && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <GlassCard glowColor={color}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">
                  Report Ready
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  Your {pkgInfo?.tagline.toLowerCase()} report is available
                  for download.
                </p>
              </div>
              <a
                href={getReportUrl(engagement.id)}
                className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
                style={{
                  background: `${color}15`,
                  border: `1px solid ${color}40`,
                  color,
                }}
              >
                Download PDF
              </a>
            </div>
          </GlassCard>
        </motion.div>
      )}

      {/* Reviewer Notes (premium) */}
      {engagement.reviewer_notes && (
        <GlassCard className="mt-4">
          <h3 className="text-xs font-bold text-yellow-400 mb-2">
            Reviewer Notes
          </h3>
          <p className="text-sm text-gray-300">{engagement.reviewer_notes}</p>
        </GlassCard>
      )}
    </div>
  );
};
