import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { ScriptCard } from "../components/catalog/ScriptCard";
import { SearchBar } from "../components/catalog/SearchBar";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { fetchScripts } from "../lib/api-client";
import type { Script, ValidationStatus } from "../types/script";

const MOCK_SCRIPTS: Script[] = [
  {
    script_id: "csv-analyzer",
    vending_code: "S-7K2M",
    name: "CSV Analyzer",
    description:
      "Upload a CSV file and get descriptive statistics, correlation matrices, missing-value reports, and AI-generated insights. Supports large files with streaming.",
    creator: "data_dave",
    packages: ["pandas", "numpy"],
    price: 5,
    input_schema: '{"file_path": "string"}',
    runs: 14820,
    revenue: 74100,
    validation_status: "approved",
    version: 3,
    code_hash: "abc123",
    versions: [],
    created_at: "2025-12-01T00:00:00Z",
  },
  {
    script_id: "json-schema-gen",
    vending_code: "S-3F9N",
    name: "JSON Schema Generator",
    description:
      "Paste any JSON payload and generate a complete JSON Schema with type inference, required fields, and description placeholders.",
    creator: "schema_sam",
    packages: [],
    price: 3,
    input_schema: '{"json_input": "string"}',
    runs: 11340,
    revenue: 34020,
    validation_status: "approved",
    version: 2,
    code_hash: "def456",
    versions: [],
    created_at: "2025-12-15T00:00:00Z",
  },
  {
    script_id: "md-to-pdf",
    vending_code: "S-8P1Q",
    name: "Markdown to PDF",
    description:
      "Convert Markdown documents to styled PDFs with syntax highlighting, table of contents, and custom headers/footers.",
    creator: "print_pat",
    packages: ["reportlab"],
    price: 4,
    input_schema: '{"markdown": "string"}',
    runs: 9870,
    revenue: 39480,
    validation_status: "approved",
    version: 1,
    code_hash: "ghi789",
    versions: [],
    created_at: "2026-01-05T00:00:00Z",
  },
  {
    script_id: "api-mock",
    vending_code: "S-2D6R",
    name: "API Mock Server",
    description:
      "Generate a mock REST API server from an OpenAPI spec. Returns realistic fake data with configurable latency and error rates.",
    creator: "mock_maya",
    packages: ["fastapi", "faker"],
    price: 8,
    input_schema: '{"openapi_spec": "string"}',
    runs: 8450,
    revenue: 67600,
    validation_status: "flagged",
    version: 4,
    code_hash: "jkl012",
    versions: [],
    created_at: "2026-01-20T00:00:00Z",
  },
  {
    script_id: "regex-tester",
    vending_code: "S-5X4W",
    name: "Regex Tester",
    description:
      "Test regex patterns against sample strings with match highlighting, group extraction, and performance benchmarks.",
    creator: "regex_rex",
    packages: [],
    price: 2,
    input_schema: '{"pattern": "string", "test_string": "string"}',
    runs: 7210,
    revenue: 14420,
    validation_status: "approved",
    version: 1,
    code_hash: "mno345",
    versions: [],
    created_at: "2026-02-01T00:00:00Z",
  },
  {
    script_id: "env-validator",
    vending_code: "S-4H7L",
    name: "Env Validator",
    description:
      "Validate .env files against a schema. Checks for missing keys, type mismatches, and insecure default values.",
    creator: "sec_sara",
    packages: [],
    price: 3,
    input_schema: '{"env_content": "string", "schema": "string"}',
    runs: 4100,
    revenue: 12300,
    validation_status: "pending",
    version: 1,
    code_hash: "pqr678",
    versions: [],
    created_at: "2026-03-10T00:00:00Z",
  },
];

type FilterKey = "all" | "approved" | "flagged";

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "approved", label: "Approved" },
  { key: "flagged", label: "Flagged" },
];

const FILTER_COLORS: Record<FilterKey, string> = {
  all: "#4a4a8a",
  approved: "#39ff14",
  flagged: "#fff01f",
};

export const CatalogPage = () => {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterKey>("all");

  useEffect(() => {
    setLoading(true);
    fetchScripts()
      .then((data) => {
        setScripts(data);
        setError(null);
      })
      .catch((err) => {
        console.error("Failed to fetch scripts, using mock data:", err);
        setError("Failed to load scripts from API. Showing cached data.");
        setScripts(MOCK_SCRIPTS);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const filtered = useMemo(() => {
    let results = scripts;
    if (filter !== "all") {
      results = results.filter((s) => s.validation_status === (filter as ValidationStatus));
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      results = results.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.vending_code.toLowerCase().includes(q) ||
          s.description.toLowerCase().includes(q),
      );
    }
    return results;
  }, [scripts, search, filter]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <motion.h1
        className="neon-text-blue mb-8 text-3xl font-bold text-neon-blue"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Script Catalog
      </motion.h1>

      {/* Search + filters */}
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center">
        <SearchBar value={search} onChange={setSearch} />

        <div className="flex gap-2">
          {FILTERS.map((f) => {
            const active = filter === f.key;
            const color = FILTER_COLORS[f.key];
            return (
              <button
                type="button"
                key={f.key}
                onClick={() => setFilter(f.key)}
                className="rounded-full px-4 py-1.5 text-xs font-semibold transition-all"
                style={{
                  color: active ? color : "rgba(255,255,255,0.4)",
                  background: active ? `${color}15` : "transparent",
                  border: `1px solid ${active ? `${color}50` : "rgba(255,255,255,0.1)"}`,
                  textShadow: active ? `0 0 8px ${color}60` : "none",
                }}
              >
                {f.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Error banner */}
      {error && (
        <div className="mb-6 rounded-lg border border-yellow-500/30 bg-yellow-500/5 px-4 py-3 text-sm text-yellow-400">
          {error}
        </div>
      )}

      {/* Grid */}
      {loading ? (
        <div className="flex justify-center py-20">
          <LoadingSpinner />
        </div>
      ) : filtered.length === 0 ? (
        <p className="py-20 text-center text-sm text-white/30">No scripts match your search.</p>
      ) : (
        <motion.div
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3"
          initial="hidden"
          animate="show"
          variants={{ hidden: {}, show: { transition: { staggerChildren: 0.07 } } }}
        >
          {filtered.map((script) => (
            <motion.div
              key={script.script_id}
              variants={{
                hidden: { opacity: 0, y: 15 },
                show: { opacity: 1, y: 0, transition: { duration: 0.35 } },
              }}
            >
              <ScriptCard script={script} />
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
};
