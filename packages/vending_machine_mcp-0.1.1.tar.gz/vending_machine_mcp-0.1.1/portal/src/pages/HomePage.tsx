import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { fetchScripts } from "../lib/api-client";
import type { ValidationStatus } from "../types/script";

interface LeaderboardEntry {
  rank: number;
  vending_code: string;
  name: string;
  runs: number;
  status: ValidationStatus;
}

const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, vending_code: "S-7K2M", name: "CSV Analyzer", runs: 14820, status: "approved" },
  { rank: 2, vending_code: "S-3F9N", name: "JSON Schema Generator", runs: 11340, status: "approved" },
  { rank: 3, vending_code: "S-8P1Q", name: "Markdown to PDF", runs: 9870, status: "approved" },
  { rank: 4, vending_code: "S-2D6R", name: "API Mock Server", runs: 8450, status: "approved" },
  { rank: 5, vending_code: "S-5X4W", name: "Regex Tester", runs: 7210, status: "approved" },
  { rank: 6, vending_code: "S-1A8T", name: "SQL Formatter", runs: 6890, status: "approved" },
  { rank: 7, vending_code: "S-9C3V", name: "Image Resizer", runs: 5430, status: "flagged" },
  { rank: 8, vending_code: "S-4H7L", name: "Env Validator", runs: 4100, status: "approved" },
  { rank: 9, vending_code: "S-6B2J", name: "Cron Parser", runs: 3650, status: "approved" },
  { rank: 10, vending_code: "S-0E5G", name: "Base64 Toolkit", runs: 2980, status: "approved" },
];

const STATUS_COLORS: Record<ValidationStatus, string> = {
  approved: "#39ff14",
  flagged: "#fff01f",
  rejected: "#ff2d95",
  pending: "#00f0ff",
};

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06 } },
};

const row = {
  hidden: { opacity: 0, x: -20 },
  show: { opacity: 1, x: 0, transition: { duration: 0.35, ease: "easeOut" as const } },
};

const stats = [
  { value: "20+", label: "Scripts" },
  { value: "13", label: "Agents" },
  { value: "7-Layer", label: "Security" },
];

const CONFIG_JSON = `{
  "mcpServers": {
    "vending-machine": {
      "command": "uvx",
      "args": ["vending-machine-mcp"]
    }
  }
}`;

export const HomePage = () => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLeaderboardLoading(true);
    fetchScripts()
      .then((scripts) => {
        if (cancelled) return;
        const sorted = [...scripts]
          .sort((a, b) => b.runs - a.runs)
          .slice(0, 10)
          .map((s, i) => ({
            rank: i + 1,
            vending_code: s.vending_code,
            name: s.name,
            runs: s.runs,
            status: s.validation_status,
          }));
        setLeaderboard(sorted);
      })
      .catch((err) => {
        if (!cancelled) {
          console.error("Failed to fetch scripts for leaderboard, using mock data:", err);
          setLeaderboard(MOCK_LEADERBOARD);
        }
      })
      .finally(() => {
        if (!cancelled) setLeaderboardLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="mx-auto max-w-5xl px-4 py-12">
      {/* ---- Hero ---- */}
      <section className="mb-20 text-center">
        <motion.h1
          className="neon-text mb-3 text-5xl font-black tracking-widest text-neon-pink sm:text-6xl"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          VENDING MACHINE
        </motion.h1>

        <motion.p
          className="neon-text-blue mb-8 text-lg font-medium tracking-wide text-neon-blue"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.4 }}
        >
          Script Marketplace
        </motion.p>

        {/* pip install block */}
        <motion.div
          className="mx-auto mb-10 max-w-md rounded-xl border border-white/10 bg-[#0a0a1a] px-6 py-3"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.4 }}
        >
          <code className="font-mono text-sm text-neon-green">pip install vending-machine-mcp</code>
        </motion.div>

        {/* CTA buttons */}
        <motion.div
          className="flex flex-wrap justify-center gap-4"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.4 }}
        >
          <Link
            to="/catalog"
            className="rounded-xl border border-neon-blue/40 bg-neon-blue/10 px-8 py-3 text-sm font-semibold text-neon-blue transition-all hover:bg-neon-blue/20 hover:shadow-[0_0_20px_rgba(0,240,255,0.15)]"
          >
            Browse Catalog
          </Link>
          <Link
            to="/submit"
            className="rounded-xl border border-neon-pink/40 bg-neon-pink/10 px-8 py-3 text-sm font-semibold text-neon-pink transition-all hover:bg-neon-pink/20 hover:shadow-[0_0_20px_rgba(255,45,149,0.15)]"
          >
            Submit Script
          </Link>
        </motion.div>
      </section>

      {/* ---- Arcade Leaderboard ---- */}
      <section className="mb-20">
        <motion.h2
          className="neon-flicker neon-text-green mb-6 text-center font-mono text-2xl font-bold tracking-widest text-neon-green"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          TOP SCRIPTS
        </motion.h2>

        <div className="overflow-hidden rounded-2xl border border-neon-green/20 bg-[#0a0a1a]/80">
          {/* Table header */}
          <div className="grid grid-cols-[3rem_5.5rem_1fr_5rem_5.5rem] gap-2 border-b border-neon-green/15 px-4 py-2.5 text-[11px] font-semibold uppercase tracking-widest text-white/30">
            <span>#</span>
            <span>Code</span>
            <span>Name</span>
            <span className="text-right">Runs</span>
            <span className="text-right">Status</span>
          </div>

          {/* Table rows */}
          {leaderboardLoading ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner />
            </div>
          ) : (
            <motion.div variants={container} initial="hidden" animate="show">
              {leaderboard.map((entry) => (
                <motion.div
                  key={entry.vending_code}
                  variants={row}
                  className="grid grid-cols-[3rem_5.5rem_1fr_5rem_5.5rem] items-center gap-2 border-b border-white/5 px-4 py-2.5 transition-colors last:border-0 hover:bg-white/[0.03]"
                >
                  {/* Rank */}
                  <span
                    className="font-mono text-lg font-black tabular-nums"
                    style={{
                      color: "#39ff14",
                      textShadow: "0 0 8px rgba(57,255,20,0.5)",
                    }}
                  >
                    {entry.rank}
                  </span>

                  {/* Vending code */}
                  <span
                    className="font-mono text-xs font-bold tracking-wider"
                    style={{
                      color: "#00f0ff",
                      textShadow: "0 0 6px rgba(0,240,255,0.4)",
                    }}
                  >
                    {entry.vending_code}
                  </span>

                  {/* Name */}
                  <span className="truncate text-sm text-white/80">{entry.name}</span>

                  {/* Runs */}
                  <span className="text-right font-mono text-xs tabular-nums text-white/50">
                    {entry.runs.toLocaleString()}
                  </span>

                  {/* Status dot */}
                  <span className="flex justify-end">
                    <span
                      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold"
                      style={{
                        color: STATUS_COLORS[entry.status],
                        background: `${STATUS_COLORS[entry.status]}10`,
                        border: `1px solid ${STATUS_COLORS[entry.status]}30`,
                      }}
                    >
                      <span
                        className="h-1.5 w-1.5 rounded-full"
                        style={{
                          background: STATUS_COLORS[entry.status],
                          boxShadow: `0 0 4px ${STATUS_COLORS[entry.status]}`,
                        }}
                      />
                      {entry.status}
                    </span>
                  </span>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* ---- Stats Row ---- */}
      <section className="mb-20">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              className="rounded-2xl border border-white/10 bg-[#1a1a2e]/70 p-6 text-center backdrop-blur-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 + i * 0.1, duration: 0.4 }}
              whileHover={{
                borderColor: "rgba(74,74,138,0.6)",
                boxShadow: "0 0 20px rgba(74,74,138,0.15)",
                y: -2,
              }}
            >
              <div className="neon-text-blue mb-1 text-3xl font-black text-neon-blue">{stat.value}</div>
              <div className="text-sm text-white/50">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ---- Install Section ---- */}
      <section className="mb-12">
        <motion.h2
          className="neon-text-blue mb-4 text-center text-xl font-bold text-neon-blue"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          Configuration
        </motion.h2>
        <motion.div
          className="mx-auto max-w-lg overflow-hidden rounded-xl border border-white/10 bg-[#0a0a1a]"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.4 }}
        >
          <div className="border-b border-white/5 px-4 py-2 text-[11px] font-semibold uppercase tracking-widest text-white/30">
            claude_desktop_config.json
          </div>
          <pre className="overflow-x-auto p-4 font-mono text-xs leading-relaxed text-neon-green/80">{CONFIG_JSON}</pre>
        </motion.div>
      </section>
    </div>
  );
};
