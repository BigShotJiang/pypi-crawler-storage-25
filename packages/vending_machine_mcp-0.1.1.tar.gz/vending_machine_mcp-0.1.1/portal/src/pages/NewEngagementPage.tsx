import { motion } from "framer-motion";
import { useState } from "react";
import { useNavigate } from "react-router";
import { DepthSelector } from "../components/engagements/DepthSelector";
import { PackageCard } from "../components/engagements/PackageCard";
import { GlassCard } from "../components/shared/GlassCard";
import { createEngagement } from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";
import type { EngagementDepth, EngagementPackage, EngagementTier } from "../types/engagement";
import { PACKAGES } from "../types/engagement";

export const NewEngagementPage = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();

  const [selectedPackage, setSelectedPackage] =
    useState<EngagementPackage | null>(null);
  const [tier, setTier] = useState<EngagementTier>("self-serve");
  const [depth, setDepth] = useState<EngagementDepth>("scan");
  const [repoUrl, setRepoUrl] = useState("");
  const [scopeNotes, setScopeNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedPkg = PACKAGES.find((p) => p.id === selectedPackage);

  const handleSubmit = async () => {
    if (!selectedPackage || !repoUrl.trim()) return;

    setSubmitting(true);
    setError(null);

    try {
      const engagement = await createEngagement({
        package: selectedPackage,
        tier,
        depth,
        repo_url: repoUrl.trim(),
        scope_notes: scopeNotes.trim(),
      });
      navigate(`/engagements/${engagement.id}`);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to create engagement",
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <GlassCard>
          <p className="text-gray-400">Sign in to create an engagement.</p>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-white mb-2">New Engagement</h1>
      <p className="text-sm text-gray-400 mb-8">
        Select a package, provide your repo, and our agent pipeline will deliver
        a comprehensive assessment with a branded PDF report.
      </p>

      {/* Package Selection */}
      <div className="space-y-3 mb-8">
        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
          Select Package
        </label>
        {PACKAGES.map((pkg) => (
          <PackageCard
            key={pkg.id}
            pkg={pkg}
            selected={selectedPackage === pkg.id}
            onSelect={(id) => setSelectedPackage(id as EngagementPackage)}
          />
        ))}
      </div>

      {/* Tier Toggle */}
      <div className="mb-6">
        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">
          Tier
        </label>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setTier("self-serve")}
            className="px-4 py-2 rounded-lg text-sm transition-all"
            style={{
              background:
                tier === "self-serve"
                  ? "rgba(0,240,255,0.1)"
                  : "rgba(255,255,255,0.03)",
              border: `1px solid ${tier === "self-serve" ? "rgba(0,240,255,0.3)" : "rgba(255,255,255,0.08)"}`,
              color:
                tier === "self-serve" ? "#00f0ff" : "rgba(255,255,255,0.5)",
            }}
          >
            Self-Serve
          </button>
          <button
            type="button"
            onClick={() => setTier("premium")}
            className="px-4 py-2 rounded-lg text-sm transition-all flex items-center gap-2"
            style={{
              background:
                tier === "premium"
                  ? "rgba(255,214,10,0.1)"
                  : "rgba(255,255,255,0.03)",
              border: `1px solid ${tier === "premium" ? "rgba(255,214,10,0.3)" : "rgba(255,255,255,0.08)"}`,
              color:
                tier === "premium" ? "#ffd60a" : "rgba(255,255,255,0.5)",
            }}
          >
            Premium
            <span className="text-[10px] opacity-60">
              (includes human review)
            </span>
          </button>
        </div>
      </div>

      {/* Depth */}
      <div className="mb-6">
        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">
          Depth
        </label>
        <DepthSelector depth={depth} onSelect={setDepth} />
      </div>

      {/* Repo URL */}
      <div className="mb-4">
        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">
          Repository URL
        </label>
        <input
          type="url"
          value={repoUrl}
          onChange={(e) => setRepoUrl(e.target.value)}
          placeholder="https://github.com/org/repo"
          className="w-full px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/40"
        />
      </div>

      {/* Scope Notes */}
      <div className="mb-6">
        <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">
          Scope Notes{" "}
          <span className="text-gray-600 normal-case">(optional)</span>
        </label>
        <textarea
          value={scopeNotes}
          onChange={(e) => setScopeNotes(e.target.value)}
          placeholder="Focus areas, specific files, compliance requirements..."
          rows={3}
          className="w-full px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500/40 resize-none"
        />
      </div>

      {/* Summary + Submit */}
      {selectedPkg && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <GlassCard glowColor={selectedPkg.color}>
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span>{selectedPkg.icon}</span>
                  <span
                    className="font-bold text-sm"
                    style={{ color: selectedPkg.color }}
                  >
                    {selectedPkg.name}
                  </span>
                  {tier === "premium" && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                      Premium
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {selectedPkg.agents.length} agents &middot;{" "}
                  {selectedPkg.credits} credits
                </p>
              </div>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={submitting || !repoUrl.trim()}
                className="px-5 py-2.5 rounded-lg text-sm font-medium transition-all disabled:opacity-40"
                style={{
                  background: `${selectedPkg.color}20`,
                  border: `1px solid ${selectedPkg.color}50`,
                  color: selectedPkg.color,
                }}
              >
                {submitting ? "Starting..." : "Start Engagement"}
              </button>
            </div>
          </GlassCard>
        </motion.div>
      )}

      {error && (
        <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
          {error}
        </div>
      )}
    </div>
  );
};
