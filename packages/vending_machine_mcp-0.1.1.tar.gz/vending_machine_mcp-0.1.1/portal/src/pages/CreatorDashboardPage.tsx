import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { AuthModal } from "../components/auth/AuthModal";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { StatusBadge } from "../components/shared/StatusBadge";
import { creatorDashboardMock } from "../data/creator-dashboard";
import { fetchCreatorDashboard } from "../lib/api-client";
import { useAuthStore } from "../stores/useAuthStore";
import { useCreatorDashboardStore } from "../stores/useCreatorDashboardStore";
import type { CreatorDashboardResponse, CreatorScriptSummary } from "../types/creator-dashboard";

function formatMoney(value: number): string {
  return `$${value.toFixed(2)}`;
}

function formatDate(ts: number | null | undefined): string {
  if (!ts) return "—";
  const d = new Date(ts);
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const CreatorDashboardPage = () => {
  const { user } = useAuthStore();
  const [showAuth, setShowAuth] = useState(false);
  const [data, setData] = useState<CreatorDashboardResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { sortKey, sortDirection, setSort, selectedScriptId, setSelectedScriptId } = useCreatorDashboardStore();

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    setLoading(true);
    fetchCreatorDashboard("platform")
      .then((response) => {
        if (!cancelled) {
          setData(response);
          setError(null);
        }
      })
      .catch((err) => {
        console.error("Failed to fetch creator dashboard, using mock data:", err);
        if (!cancelled) {
          setError("Failed to load creator metrics from API. Showing cached data.");
          setData(creatorDashboardMock);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  const sortedScripts = useMemo(() => {
    if (!data) return [];
    const scripts = [...data.scripts];
    const direction = sortDirection === "asc" ? 1 : -1;
    scripts.sort((a, b) => {
      if (sortKey === "name") return a.name.localeCompare(b.name) * direction;
      if (sortKey === "runs") return (a.runs - b.runs) * direction;
      return (a.revenue - b.revenue) * direction;
    });
    return scripts;
  }, [data, sortKey, sortDirection]);

  const selectedScript = useMemo<CreatorScriptSummary | null>(() => {
    if (!data || !selectedScriptId) return null;
    return data.scripts.find((s) => s.script_id === selectedScriptId) ?? null;
  }, [data, selectedScriptId]);

  if (!user) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <motion.h1
          className="neon-text mb-6 font-mono text-3xl font-bold tracking-wider text-neon-pink"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          CREATOR DASHBOARD
        </motion.h1>
        <GlassCard className="!p-10">
          <p className="mb-6 text-white/50">Sign in to view creator performance and payouts.</p>
          <motion.button
            type="button"
            className="rounded-xl border border-neon-pink/40 bg-neon-pink/10 px-8 py-3 font-mono text-sm font-bold tracking-wider text-neon-pink"
            style={{ textShadow: "0 0 8px #ff2d9560" }}
            whileHover={{
              background: "rgba(255, 45, 149, 0.2)",
              boxShadow: "0 0 20px rgba(255, 45, 149, 0.3)",
            }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setShowAuth(true)}
          >
            SIGN IN
          </motion.button>
        </GlassCard>
        {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
      </div>
    );
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <motion.h1
          className="neon-text mb-6 font-mono text-3xl font-bold tracking-wider text-neon-pink"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          CREATOR DASHBOARD
        </motion.h1>
        <div className="flex justify-center py-16">
          <LoadingSpinner />
        </div>
      </div>
    );
  }

  if (!data) {
    return <div className="mx-auto max-w-2xl px-6 py-24 text-center text-white/60">No creator data available.</div>;
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-12">
      {error && (
        <div className="mb-6 rounded-lg border border-yellow-500/30 bg-yellow-500/5 px-4 py-3 text-sm text-yellow-400">
          {error}
        </div>
      )}

      <motion.div className="mb-8" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="neon-text font-mono text-3xl font-bold tracking-wider text-neon-pink">CREATOR DASHBOARD</h1>
        <p className="mt-2 text-sm text-white/50">
          Snapshot for {data.creator} with live totals, rankings, and validation status.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <GlassCard className="!p-5">
          <div className="text-xs uppercase tracking-[0.2em] text-white/40">Scripts</div>
          <div className="mt-3 text-2xl font-semibold text-white">{data.totals.scripts}</div>
        </GlassCard>
        <GlassCard className="!p-5">
          <div className="text-xs uppercase tracking-[0.2em] text-white/40">Total Runs</div>
          <div className="mt-3 text-2xl font-semibold text-white">{data.totals.runs}</div>
        </GlassCard>
        <GlassCard className="!p-5">
          <div className="text-xs uppercase tracking-[0.2em] text-white/40">Revenue</div>
          <div className="mt-3 text-2xl font-semibold text-white">{formatMoney(data.totals.revenue)}</div>
        </GlassCard>
        <GlassCard className="!p-5">
          <div className="text-xs uppercase tracking-[0.2em] text-white/40">Top Script</div>
          <div className="mt-2 text-lg font-semibold text-white">{data.summary.top_script?.name ?? "—"}</div>
          <div className="text-xs text-white/40">
            {data.summary.top_script
              ? `${data.summary.top_script.runs} runs · ${formatMoney(data.summary.top_script.revenue)}`
              : "No activity yet"}
          </div>
        </GlassCard>
      </div>

      <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
        <div className="text-sm text-white/70">Scripts</div>
        <div className="text-xs text-white/40">
          Avg runs: {data.summary.avg_runs.toFixed(1)} · Avg revenue: {formatMoney(data.summary.avg_revenue)}
        </div>
      </div>

      <GlassCard className="mt-3 !p-0 overflow-hidden">
        <div className="grid grid-cols-[1.4fr_0.6fr_0.7fr_0.6fr] border-b border-white/10 bg-white/5 px-5 py-3 text-xs text-white/40">
          <button type="button" className="text-left" onClick={() => setSort("name")}>
            Name {sortKey === "name" ? (sortDirection === "asc" ? "↑" : "↓") : ""}
          </button>
          <button type="button" className="text-left" onClick={() => setSort("runs")}>
            Runs {sortKey === "runs" ? (sortDirection === "asc" ? "↑" : "↓") : ""}
          </button>
          <button type="button" className="text-left" onClick={() => setSort("revenue")}>
            Revenue {sortKey === "revenue" ? (sortDirection === "asc" ? "↑" : "↓") : ""}
          </button>
          <div>Status</div>
        </div>
        <div className="divide-y divide-white/5">
          {sortedScripts.map((script) => (
            <button
              type="button"
              key={script.script_id}
              className="grid w-full grid-cols-[1.4fr_0.6fr_0.7fr_0.6fr] px-5 py-4 text-left text-sm text-white/80 transition-colors hover:bg-white/5"
              onClick={() => setSelectedScriptId(script.script_id)}
            >
              <div>
                <div className="font-semibold">{script.name}</div>
                <div className="text-xs text-white/40 font-mono">{script.vending_code || "PENDING"}</div>
              </div>
              <div className="text-white/70">{script.runs}</div>
              <div className="text-white/70">{formatMoney(script.revenue)}</div>
              <div>
                <StatusBadge status={script.validation_status} />
              </div>
            </button>
          ))}
        </div>
      </GlassCard>

      {selectedScript && (
        <motion.div
          className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="h-full w-full max-w-md border-l border-white/10 bg-[#0b0f1c] p-6"
            initial={{ x: 40, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 40, opacity: 0 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-lg font-semibold text-white">{selectedScript.name}</div>
                <div className="text-xs text-white/40 font-mono">{selectedScript.vending_code}</div>
              </div>
              <button
                type="button"
                className="text-sm text-white/50 hover:text-white"
                onClick={() => setSelectedScriptId(null)}
              >
                Close
              </button>
            </div>

            <div className="mt-6 space-y-4 text-sm text-white/70">
              <GlassCard className="!p-4">
                <div className="text-xs uppercase tracking-[0.2em] text-white/40">Validation</div>
                <div className="mt-2">
                  <StatusBadge status={selectedScript.validation_status} />
                </div>
                <div className="mt-2 text-xs text-white/50">
                  {typeof selectedScript.validation_report?.summary === "string"
                    ? selectedScript.validation_report.summary
                    : "No validation summary available."}
                </div>
              </GlassCard>

              <GlassCard className="!p-4">
                <div className="text-xs uppercase tracking-[0.2em] text-white/40">Recent Runs</div>
                <div className="mt-2 text-xs text-white/60">Last run: {formatDate(selectedScript.last_run_at)}</div>
                <div className="mt-1 text-xs text-white/60">
                  Avg revenue/run:{" "}
                  {selectedScript.runs > 0 ? formatMoney(selectedScript.revenue / selectedScript.runs) : "—"}
                </div>
              </GlassCard>

              <GlassCard className="!p-4">
                <div className="text-xs uppercase tracking-[0.2em] text-white/40">Performance</div>
                <div className="mt-2 text-xs text-white/60">Runs: {selectedScript.runs}</div>
                <div className="mt-1 text-xs text-white/60">Revenue: {formatMoney(selectedScript.revenue)}</div>
                <div className="mt-1 text-xs text-white/60">Price/run: {formatMoney(selectedScript.price)}</div>
              </GlassCard>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};
