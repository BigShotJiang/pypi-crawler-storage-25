import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router";
import { GlassCard } from "../components/shared/GlassCard";
import { LoadingSpinner } from "../components/shared/LoadingSpinner";
import { StatusBadge } from "../components/shared/StatusBadge";
import { fetchScriptHashes } from "../lib/api-client";
import type { ScriptHash, ValidationStatus } from "../types/script";

/* ---------- mock registry ---------- */

const MOCK_HASHES: ScriptHash[] = [
  {
    vending_code: "S-7K2M",
    name: "PDF Report Generator",
    version: 3,
    code_hash: "a3f8c1d2e5b7",
    validation_status: "approved",
  },
  {
    vending_code: "S-9P4Q",
    name: "CSV Analyzer",
    version: 2,
    code_hash: "c4e6f8a1b3d5",
    validation_status: "approved",
  },
  {
    vending_code: "S-2L8N",
    name: "Sentiment Scorer",
    version: 1,
    code_hash: "e7f9a2b4c6d8",
    validation_status: "pending",
  },
  {
    vending_code: "S-5R1T",
    name: "Image Resizer",
    version: 4,
    code_hash: "b1c3d5e7f9a2",
    validation_status: "approved",
  },
  {
    vending_code: "S-3W6X",
    name: "Web Scraper",
    version: 1,
    code_hash: "d8e0f2a4b6c8",
    validation_status: "rejected",
  },
  {
    vending_code: "S-8Y0Z",
    name: "Email Formatter",
    version: 2,
    code_hash: "f3a5b7c9d1e4",
    validation_status: "approved",
  },
];

type VerifyResult = { found: true; entry: ScriptHash } | { found: false } | null;

export const VerifyPage = () => {
  const { hash: paramHash } = useParams();
  const [hashes, setHashes] = useState<ScriptHash[]>([]);
  const [hashesLoading, setHashesLoading] = useState(true);
  const [hashesError, setHashesError] = useState<string | null>(null);
  const [inputHash, setInputHash] = useState(paramHash ?? "");
  const [result, setResult] = useState<VerifyResult>(null);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setHashesLoading(true);
    fetchScriptHashes()
      .then((data) => {
        if (!cancelled) {
          setHashes(data);
          setHashesError(null);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          console.error("Failed to fetch hashes, using mock data:", err);
          setHashesError("Failed to load hash registry from API. Showing cached data.");
          setHashes(MOCK_HASHES);
        }
      })
      .finally(() => {
        if (!cancelled) setHashesLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const verify = useCallback(
    (hashToCheck: string) => {
      const trimmed = hashToCheck.trim().toLowerCase();
      if (!trimmed) return;
      setSearched(true);
      const match = hashes.find((h) => h.code_hash.toLowerCase() === trimmed);
      setResult(match ? { found: true, entry: match } : { found: false });
    },
    [hashes],
  );

  useEffect(() => {
    if (paramHash && !hashesLoading) {
      setInputHash(paramHash);
      verify(paramHash);
    }
  }, [paramHash, hashesLoading, verify]);

  const handleVerify = () => verify(inputHash);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleVerify();
  };

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      {/* Heading */}
      <motion.h1
        className="neon-text-blue mb-10 text-center font-mono text-4xl font-bold tracking-wider text-neon-blue"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        VERIFY INTEGRITY
      </motion.h1>

      {/* Search */}
      <GlassCard className="mb-8">
        <label htmlFor="verify-hash-input" className="mb-2 block font-mono text-xs text-white/40">
          Paste a code hash to verify
        </label>
        <div className="flex gap-3">
          <input
            id="verify-hash-input"
            type="text"
            value={inputHash}
            onChange={(e) => setInputHash(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="e.g. a3f8c1d2e5b7"
            className="flex-1 rounded-lg border border-white/10 bg-[#0d0d1a] px-4 py-3 font-mono text-sm text-white/90 placeholder-white/20 outline-none transition-all duration-200 focus:border-neon-blue focus:shadow-[0_0_12px_#00f0ff30]"
          />
          <motion.button
            type="button"
            className="rounded-lg border border-neon-blue/40 bg-neon-blue/10 px-6 py-3 font-mono text-sm font-bold tracking-wider text-neon-blue"
            style={{ textShadow: "0 0 8px #00f0ff50" }}
            whileHover={{
              background: "rgba(0, 240, 255, 0.2)",
              boxShadow: "0 0 20px rgba(0, 240, 255, 0.25)",
            }}
            whileTap={{ scale: 0.97 }}
            onClick={handleVerify}
          >
            VERIFY
          </motion.button>
        </div>

        {/* Result */}
        <AnimatePresence mode="wait">
          {searched && result && (
            <motion.div
              key={result.found ? "found" : "notfound"}
              className="mt-5"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {result.found ? (
                <div
                  className="flex flex-wrap items-center gap-4 rounded-xl border p-4"
                  style={{
                    borderColor: "#39ff1440",
                    background: "rgba(57, 255, 20, 0.04)",
                  }}
                >
                  <motion.span
                    className="rounded-lg border border-neon-green/40 bg-neon-green/10 px-4 py-2 font-mono text-xl font-bold text-neon-green"
                    style={{
                      textShadow: "0 0 12px #39ff1460",
                      boxShadow: "0 0 16px #39ff1420",
                    }}
                    animate={{
                      boxShadow: ["0 0 8px #39ff1420", "0 0 24px #39ff1440", "0 0 8px #39ff1420"],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Number.POSITIVE_INFINITY,
                    }}
                  >
                    VERIFIED
                  </motion.span>
                  <div className="flex-1">
                    <p className="font-semibold text-white/80">{result.entry.name}</p>
                    <p className="mt-0.5 font-mono text-xs text-white/40">
                      {result.entry.vending_code} &middot; v{result.entry.version} &middot; {result.entry.code_hash}
                    </p>
                  </div>
                  <StatusBadge status={result.entry.validation_status} />
                </div>
              ) : (
                <div
                  className="flex items-center gap-3 rounded-xl border p-4"
                  style={{
                    borderColor: "#ff2d9540",
                    background: "rgba(255, 45, 149, 0.04)",
                  }}
                >
                  <motion.span
                    className="rounded-lg border border-neon-pink/40 bg-neon-pink/10 px-4 py-2 font-mono text-lg font-bold text-neon-pink"
                    style={{ textShadow: "0 0 10px #ff2d9560" }}
                  >
                    NOT FOUND
                  </motion.span>
                  <p className="text-sm text-white/40">No script matches this hash in the registry.</p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </GlassCard>

      {/* Hash Registry Table */}
      <div>
        <h2 className="neon-text-blue mb-4 font-mono text-lg text-neon-blue">Hash Registry</h2>

        {hashesError && (
          <div className="mb-4 rounded-lg border border-yellow-500/30 bg-yellow-500/5 px-4 py-3 text-sm text-yellow-400">
            {hashesError}
          </div>
        )}

        {hashesLoading ? (
          <div className="flex justify-center py-16">
            <LoadingSpinner />
          </div>
        ) : (
          <GlassCard className="!p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-xs text-white/30">
                    <th className="px-5 py-3 font-mono font-normal">Code</th>
                    <th className="px-5 py-3 font-mono font-normal">Name</th>
                    <th className="px-5 py-3 font-mono font-normal">Ver</th>
                    <th className="px-5 py-3 font-mono font-normal">Code Hash</th>
                    <th className="px-5 py-3 font-mono font-normal">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {hashes.map((entry, i) => (
                    <motion.tr
                      key={entry.vending_code}
                      className="transition-colors hover:bg-white/[0.02]"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <td className="px-5 py-3 font-mono text-neon-blue">{entry.vending_code}</td>
                      <td className="px-5 py-3 text-white/70">{entry.name}</td>
                      <td className="px-5 py-3 font-mono text-white/50">v{entry.version}</td>
                      <td className="px-5 py-3 font-mono text-xs text-white/40">{entry.code_hash}</td>
                      <td className="px-5 py-3">
                        <StatusBadge status={entry.validation_status as ValidationStatus} />
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>
        )}
      </div>
    </div>
  );
};
