export type ValidationStatus = "approved" | "flagged" | "rejected" | "pending";

export interface ScriptVersion {
  version: number;
  code_hash: string;
  validation_status: ValidationStatus;
  created_at: string;
}

export interface ValidationFinding {
  layer: string;
  severity: "critical" | "high" | "medium" | "low";
  title: string;
  description: string;
  mitre_id?: string;
  line?: number;
}

export interface ValidationReport {
  verdict: string;
  risk_score: number;
  layers: Record<
    string,
    {
      passed: boolean;
      findings: ValidationFinding[];
      score?: number;
    }
  >;
  // Backend flat format (before normalization)
  riskScore?: number;
  findings?: ValidationFinding[];
}

export interface Script {
  script_id: string;
  vending_code: string;
  name: string;
  description: string;
  creator: string;
  packages: string[];
  price: number;
  input_schema: string;
  runs: number;
  revenue: number;
  validation_status: ValidationStatus;
  validation_report?: ValidationReport;
  version: number;
  code_hash: string;
  versions: ScriptVersion[];
  created_at: string;
  code?: string;
  pr_url?: string;
  pr_number?: number;
  submission_id?: string;
}

export interface ScriptHash {
  vending_code: string;
  name: string;
  version: number;
  code_hash: string;
  validation_status: ValidationStatus;
}
