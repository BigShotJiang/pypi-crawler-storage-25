export type EngagementPackage = "shield" | "blueprint" | "launchpad";
export type EngagementTier = "self-serve" | "premium";
export type EngagementDepth = "scan" | "autonomous";
export type EngagementStatus =
  | "intake"
  | "running"
  | "review"
  | "delivered"
  | "error";

export interface EngagementStep {
  job_id: string;
  agent_id: string;
  agent_name: string;
  status: "queued" | "running" | "complete" | "error";
  runtime_ms: number;
  output?: string;
}

export interface FindingsSummary {
  critical: number;
  high: number;
  medium: number;
  low: number;
  info: number;
}

export interface Engagement {
  id: string;
  user_id: string;
  package: EngagementPackage;
  tier: EngagementTier;
  depth: EngagementDepth;
  status: EngagementStatus;
  repo_url: string;
  scope_notes: string;
  job_ids: string[];
  current_step: number;
  steps?: EngagementStep[];
  report_path: string | null;
  output: string;
  findings_summary: FindingsSummary | null;
  reviewer_id: string | null;
  reviewer_notes: string | null;
  total_cost: number;
  total_runtime_ms: number;
  created_at: number;
  started_at: number | null;
  completed_at: number | null;
  delivered_at: number | null;
}

export interface PackageInfo {
  id: EngagementPackage;
  name: string;
  tagline: string;
  agents: string[];
  credits: number;
  color: string;
  icon: string;
}

export const PACKAGES: PackageInfo[] = [
  {
    id: "shield",
    name: "Shield",
    tagline: "Security Audit",
    agents: ["Bug Hunter", "Test Goblin", "Code Gremlin", "PDF Forge"],
    credits: 150,
    color: "#ff2d95",
    icon: "\u{1F6E1}",
  },
  {
    id: "blueprint",
    name: "Blueprint",
    tagline: "Architecture Review",
    agents: ["Cloud Sensei", "DevOps Dwarf", "PDF Forge"],
    credits: 200,
    color: "#00f0ff",
    icon: "\u{1F3D7}",
  },
  {
    id: "launchpad",
    name: "LaunchPad",
    tagline: "Production Readiness",
    agents: [
      "Bug Hunter",
      "Cloud Sensei",
      "DevOps Dwarf",
      "Test Goblin",
      "Code Gremlin",
      "PDF Forge",
    ],
    credits: 400,
    color: "#39ff14",
    icon: "\u{1F680}",
  },
];
