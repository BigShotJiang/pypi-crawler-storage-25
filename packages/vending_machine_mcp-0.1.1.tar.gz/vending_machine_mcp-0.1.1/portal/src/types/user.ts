export interface PortalUser {
  id: string;
  email: string;
  display_name?: string;
  is_creator: boolean;
}
