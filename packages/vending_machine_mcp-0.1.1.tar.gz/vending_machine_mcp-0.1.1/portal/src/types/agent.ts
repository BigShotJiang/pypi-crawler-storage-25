export type AgentTier = 1 | 2 | 3;

export interface Agent {
  id: string;
  name: string;
  description: string;
  model: string;
  category: string;
  tier: AgentTier;
  avatarImage?: string;
}

export const AGENT_TIERS: Record<AgentTier, { label: string; color: string }> = {
  1: { label: "Genuinely Useful", color: "#39ff14" },
  2: { label: "Situationally Useful", color: "#00f0ff" },
  3: { label: "General Purpose", color: "#4a4a8a" },
};
