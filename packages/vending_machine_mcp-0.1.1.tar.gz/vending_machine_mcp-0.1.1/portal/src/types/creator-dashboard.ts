import type { ValidationStatus } from "./script";

export interface CreatorScriptSummary {
  script_id: string;
  name: string;
  vending_code: string;
  runs: number;
  revenue: number;
  price: number;
  validation_status: ValidationStatus;
  validation_report: Record<string, unknown>;
  last_run_at: number | null;
  created_at?: number;
}

export interface CreatorDashboardResponse {
  creator: string;
  totals: {
    scripts: number;
    runs: number;
    revenue: number;
  };
  summary: {
    top_script: CreatorScriptSummary | null;
    avg_runs: number;
    avg_revenue: number;
  };
  scripts: CreatorScriptSummary[];
}
