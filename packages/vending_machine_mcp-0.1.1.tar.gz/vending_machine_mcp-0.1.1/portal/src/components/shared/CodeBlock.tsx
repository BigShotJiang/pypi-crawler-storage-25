import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { atomDark } from "react-syntax-highlighter/dist/esm/styles/prism";

interface CodeBlockProps {
  code: string;
  language?: string;
}

export const CodeBlock = ({ code, language = "python" }: CodeBlockProps) => {
  return (
    <div className="overflow-hidden rounded-xl border border-white/10">
      <div className="flex items-center justify-between bg-[#1a1a2e] px-4 py-2">
        <span className="text-xs font-mono text-white/40">{language}</span>
        <button
          type="button"
          className="text-xs text-white/40 transition-colors hover:text-neon-blue"
          onClick={() => navigator.clipboard.writeText(code)}
        >
          Copy
        </button>
      </div>
      <SyntaxHighlighter
        language={language}
        style={atomDark}
        customStyle={{
          margin: 0,
          padding: "1rem",
          background: "#0d0d1a",
          fontSize: "0.85rem",
          borderRadius: 0,
        }}
        showLineNumbers
        lineNumberStyle={{ color: "#4a4a8a", fontSize: "0.75rem" }}
      >
        {code}
      </SyntaxHighlighter>
    </div>
  );
};
