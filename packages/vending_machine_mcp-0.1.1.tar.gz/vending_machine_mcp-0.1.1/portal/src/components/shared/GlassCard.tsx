import { motion } from "framer-motion";
import type { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  glowColor?: string;
}

export const GlassCard = ({ children, className = "", onClick, glowColor = "#4a4a8a" }: GlassCardProps) => {
  return (
    <motion.div
      className={`relative rounded-2xl border border-white/10 bg-[#1a1a2e]/70 p-6 backdrop-blur-xl ${className}`}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      whileHover={{
        borderColor: `${glowColor}99`,
        boxShadow: `0 0 20px ${glowColor}30, 0 0 40px ${glowColor}15`,
        y: -2,
      }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      style={{
        cursor: onClick ? "pointer" : "default",
      }}
    >
      {children}
    </motion.div>
  );
};
