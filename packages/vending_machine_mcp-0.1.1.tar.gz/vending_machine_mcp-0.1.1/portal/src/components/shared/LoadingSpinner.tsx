import { motion } from "framer-motion";

interface LoadingSpinnerProps {
  size?: number;
  color?: string;
}

export const LoadingSpinner = ({ size = 40, color = "#00f0ff" }: LoadingSpinnerProps) => {
  return (
    <div className="flex items-center justify-center" role="status" aria-label="Loading">
      <motion.div
        className="rounded-full border-2 border-transparent"
        style={{
          width: size,
          height: size,
          borderTopColor: color,
          borderRightColor: `${color}40`,
          boxShadow: `0 0 15px ${color}50, inset 0 0 15px ${color}20`,
        }}
        animate={{ rotate: 360 }}
        transition={{
          duration: 1,
          repeat: Number.POSITIVE_INFINITY,
          ease: "linear",
        }}
      />
    </div>
  );
};
