import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router";
import {
  fetchNotifications,
  markAllNotificationsRead,
  markNotificationRead,
  type Notification,
} from "../../lib/api-client";
import { useAuthStore } from "../../stores/useAuthStore";

const TYPE_STYLES: Record<string, { color: string; icon: string }> = {
  script_submitted: { color: "#fff01f", icon: "📤" },
  script_approved: { color: "#39ff14", icon: "✅" },
  script_rejected: { color: "#ff2d95", icon: "❌" },
  script_flagged: { color: "#fff01f", icon: "⚠️" },
  admin_new_submission: { color: "#00f0ff", icon: "📬" },
};

export const NotificationInbox = () => {
  const user = useAuthStore((s) => s.user);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const load = () => {
      fetchNotifications()
        .then((data) => {
          if (!cancelled) setNotifications(data);
        })
        .catch(() => {});
    };

    load();
    // Poll every 30 seconds for new notifications
    const interval = setInterval(load, 30000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [user]);

  const handleMarkRead = async (n: Notification) => {
    await markNotificationRead(n.id);
    setNotifications((prev) => prev.map((notif) => (notif.id === n.id ? { ...notif, read: true } : notif)));

    // Approval notifications navigate to the script page with celebration
    if (n.type === "script_approved" && n.script_id) {
      setIsOpen(false);
      navigate(`/catalog/${n.script_id}?celebrate=true`);
    }
  };

  const handleMarkAllRead = async () => {
    setLoading(true);
    await markAllNotificationsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    setLoading(false);
  };

  if (!user) return null;

  return (
    <div className="relative">
      {/* Bell button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="relative rounded-lg border border-white/10 p-2 text-white/50 transition-colors hover:border-neon-blue/30 hover:text-white/80"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <title>Notifications</title>
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        {unreadCount > 0 && (
          <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-neon-pink text-[9px] font-bold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="absolute right-0 top-full z-50 mt-2 w-80 overflow-hidden rounded-xl border border-white/10 bg-[#12121a] shadow-2xl"
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
              <span className="font-mono text-xs font-bold text-white/60">NOTIFICATIONS</span>
              {unreadCount > 0 && (
                <button
                  type="button"
                  onClick={handleMarkAllRead}
                  disabled={loading}
                  className="font-mono text-[10px] text-neon-blue hover:underline disabled:opacity-40"
                >
                  Mark all read
                </button>
              )}
            </div>

            {/* List */}
            <div className="max-h-96 overflow-auto">
              {notifications.length === 0 ? (
                <div className="px-4 py-8 text-center text-xs text-white/30">No notifications yet.</div>
              ) : (
                notifications.map((n) => {
                  const style = TYPE_STYLES[n.type] || { color: "#4a4a8a", icon: "📌" };
                  return (
                    <button
                      key={n.id}
                      type="button"
                      onClick={() => handleMarkRead(n)}
                      className={`block w-full border-b border-white/5 px-4 py-3 text-left transition-colors hover:bg-white/[0.03] ${
                        n.read ? "opacity-50" : ""
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <span className="mt-0.5 text-sm">{style.icon}</span>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-white/80">{n.title}</span>
                            {!n.read && (
                              <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: style.color }} />
                            )}
                          </div>
                          <p className="mt-0.5 text-[11px] leading-relaxed text-white/40">{n.message}</p>
                          <span className="mt-1 block text-[10px] text-white/20">
                            {new Date(n.created_at).toLocaleDateString()}
                          </span>
                        </div>
                        {n.script_id && (
                          <Link
                            to={`/catalog/${n.script_id}`}
                            onClick={(e) => e.stopPropagation()}
                            className="mt-1 font-mono text-[10px] text-neon-blue hover:underline"
                          >
                            View
                          </Link>
                        )}
                      </div>
                    </button>
                  );
                })
              )}
            </div>

            {/* View All link */}
            <Link
              to="/notifications"
              onClick={() => setIsOpen(false)}
              className="block border-t border-white/5 px-4 py-2.5 text-center font-mono text-[10px] text-neon-blue transition-colors hover:bg-white/[0.03]"
            >
              View All Notifications
            </Link>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Click outside to close */}
      {isOpen && (
        <button
          type="button"
          className="fixed inset-0 z-40 cursor-default"
          onClick={() => setIsOpen(false)}
          aria-label="Close notifications"
        />
      )}
    </div>
  );
};
