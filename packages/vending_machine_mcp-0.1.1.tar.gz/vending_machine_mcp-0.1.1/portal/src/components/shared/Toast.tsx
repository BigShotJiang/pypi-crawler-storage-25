import { AnimatePresence, motion } from "framer-motion";
import { useToastStore } from "../../stores/useToastStore";

const TYPE_STYLES: Record<string, { bg: string; border: string; icon: string }> = {
  success: { bg: "rgba(57,255,20,0.1)", border: "#39ff14", icon: "check_circle" },
  error: { bg: "rgba(255,45,149,0.1)", border: "#ff2d95", icon: "error" },
  info: { bg: "rgba(0,240,255,0.1)", border: "#00f0ff", icon: "info" },
};

export const Toast = () => {
  const { toasts, removeToast } = useToastStore();

  return (
    <div className="pointer-events-none fixed right-4 bottom-4 z-50 flex flex-col gap-3">
      <AnimatePresence>
        {toasts.map((toast) => {
          const style = TYPE_STYLES[toast.type] ?? TYPE_STYLES.info;
          return (
            <motion.div
              key={toast.id}
              className="pointer-events-auto flex items-center gap-3 rounded-xl px-4 py-3 backdrop-blur-xl"
              style={{
                background: style.bg,
                border: `1px solid ${style.border}40`,
                boxShadow: `0 0 20px ${style.border}20`,
                minWidth: 280,
              }}
              initial={{ opacity: 0, x: 80, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 80, scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 25 }}
            >
              <span className="text-sm" style={{ color: style.border }}>
                {style.icon === "check_circle" && "\u2713"}
                {style.icon === "error" && "\u2717"}
                {style.icon === "info" && "\u2139"}
              </span>
              <span className="flex-1 text-sm text-white/90">{toast.message}</span>
              <button
                type="button"
                className="text-white/40 transition-colors hover:text-white/80"
                onClick={() => removeToast(toast.id)}
              >
                \u00d7
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
