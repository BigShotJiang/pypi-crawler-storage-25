import { motion } from "framer-motion";

type BadgeStatus =
  | "approved"
  | "flagged"
  | "rejected"
  | "pending"
  // Engagement statuses
  | "intake"
  | "running"
  | "review"
  | "delivered"
  | "error";

interface StatusBadgeProps {
  status: string;
}

const STATUS_CONFIG: Record<BadgeStatus, { color: string; label: string; pulse?: boolean }> = {
  approved: { color: "#39ff14", label: "Approved" },
  flagged: { color: "#fff01f", label: "Flagged" },
  rejected: { color: "#ff2d95", label: "Rejected" },
  pending: { color: "#00f0ff", label: "Pending" },
  intake: { color: "#888", label: "Intake" },
  running: { color: "#00f0ff", label: "Running", pulse: true },
  review: { color: "#fff01f", label: "In Review" },
  delivered: { color: "#39ff14", label: "Delivered" },
  error: { color: "#ff2d95", label: "Error" },
};

export const StatusBadge = ({ status }: StatusBadgeProps) => {
  const config = STATUS_CONFIG[status as BadgeStatus] ?? STATUS_CONFIG.pending;
  const { color, label, pulse } = config;

  return (
    <motion.span
      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold"
      style={{
        background: `${color}15`,
        border: `1px solid ${color}40`,
        color,
        textShadow: `0 0 8px ${color}60`,
      }}
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 20 }}
    >
      <motion.span
        className="h-2 w-2 rounded-full"
        style={{
          background: color,
          boxShadow: `0 0 6px ${color}, 0 0 12px ${color}80`,
        }}
        animate={pulse ? { opacity: [1, 0.4, 1], scale: [1, 1.2, 1] } : {}}
        transition={pulse ? { duration: 1.5, repeat: Number.POSITIVE_INFINITY } : {}}
      />
      {label}
    </motion.span>
  );
};
