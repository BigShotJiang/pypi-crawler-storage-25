import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useRef, useState } from "react";
import type { ValidationEvent } from "../../lib/api-client";

interface ValidationProgressProps {
  isValidating: boolean;
  onComplete: (vendingCode: string) => void;
  /** Real-time events from SSE stream. When provided, overrides mock timers. */
  events?: ValidationEvent[];
}

const LAYERS = [
  { key: "static", label: "Static Analysis", phase: "security" },
  { key: "deps", label: "Dependency Audit", phase: "security" },
  { key: "sandbox", label: "Sandbox Probe", phase: "security" },
  { key: "llm", label: "LLM Review", phase: "security" },
  { key: "func", label: "Functionality Test", phase: "quality" },
  { key: "quality", label: "Code Quality", phase: "quality" },
  { key: "reliability", label: "Reliability Test", phase: "quality" },
] as const;

const MOCK_PACKAGES = ["reportlab", "requests", "numpy", "pandas"];

type LayerState = "idle" | "active" | "passed" | "failed" | "skipped" | "warn";

function generateRandomCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const code = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  return `S-${code}`;
}

export const ValidationProgress = ({ isValidating, onComplete, events }: ValidationProgressProps) => {
  const [layerStates, setLayerStates] = useState<LayerState[]>(LAYERS.map(() => "idle"));
  const [layerProgress, setLayerProgress] = useState<number[]>(LAYERS.map(() => 0));
  const [, setActiveLayer] = useState(-1);
  const [allDone, setAllDone] = useState(false);
  const [slotCode, setSlotCode] = useState("");
  const [slotLanded, setSlotLanded] = useState(false);
  const [showConveyor, setShowConveyor] = useState(false);
  const [scannedPackages, setScannedPackages] = useState<{ name: string; passed: boolean; scanned: boolean }[]>([]);
  const finalCode = useRef("S-7K2M");
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;
  // Track whether we're using real SSE events (disables mock animation)
  const usingRealEvents = useRef(false);

  const runMockValidation = useCallback(() => {
    let currentLayer = 0;

    const processLayer = () => {
      // Stop mock if real events started arriving
      if (usingRealEvents.current) return;
      if (currentLayer >= LAYERS.length) {
        setAllDone(true);
        return;
      }

      setActiveLayer(currentLayer);
      setLayerStates((prev) => {
        const next = [...prev];
        next[currentLayer] = "active";
        return next;
      });

      // Dependency Audit layer - show conveyor
      if (currentLayer === 1) {
        setShowConveyor(true);
        setScannedPackages(MOCK_PACKAGES.map((name) => ({ name, passed: false, scanned: false })));

        for (const [i] of MOCK_PACKAGES.entries()) {
          setTimeout(
            () => {
              if (usingRealEvents.current) return;
              setScannedPackages((prev) =>
                prev.map((pkg, j) => (j === i ? { ...pkg, scanned: true, passed: true } : pkg)),
              );
            },
            300 + i * 400,
          );
        }
      } else {
        setShowConveyor(false);
      }

      // Animate progress
      const steps = 20;
      const stepDuration = 1200 / steps;
      for (let step = 1; step <= steps; step++) {
        setTimeout(() => {
          if (usingRealEvents.current) return;
          setLayerProgress((prev) => {
            const next = [...prev];
            next[currentLayer] = (step / steps) * 100;
            return next;
          });
        }, step * stepDuration);
      }

      // Complete layer
      setTimeout(() => {
        if (usingRealEvents.current) return;
        setLayerStates((prev) => {
          const next = [...prev];
          next[currentLayer] = "passed";
          return next;
        });
        currentLayer++;
        setTimeout(processLayer, 300);
      }, 1500);
    };

    processLayer();
  }, []);

  useEffect(() => {
    if (isValidating) {
      setLayerStates(LAYERS.map(() => "idle"));
      setLayerProgress(LAYERS.map(() => 0));
      setActiveLayer(-1);
      setAllDone(false);
      setSlotCode("");
      setSlotLanded(false);
      setShowConveyor(false);
      setScannedPackages([]);
      usingRealEvents.current = false;
      // Only run mock if no events prop — real SSE will drive the UI
      runMockValidation();
    }
  }, [isValidating, runMockValidation]);

  // Process real SSE events when available
  useEffect(() => {
    if (!events || events.length === 0) return;

    // First real event arrives — kill the mock animation
    if (!usingRealEvents.current) {
      usingRealEvents.current = true;
      // Reset all states so mock progress doesn't linger
      setLayerStates(LAYERS.map(() => "idle"));
      setLayerProgress(LAYERS.map(() => 0));
      setShowConveyor(false);
    }

    // Build layer states from ALL events
    const newStates: LayerState[] = LAYERS.map(() => "idle");
    const newProgress: number[] = LAYERS.map(() => 0);

    for (const evt of events) {
      if (evt.layer < 0 || evt.layer >= LAYERS.length) continue;

      if (evt.status === "running") {
        if (newStates[evt.layer] === "idle") {
          newStates[evt.layer] = "active";
          newProgress[evt.layer] = 50;
        }

        // Show conveyor for dependency audit
        if (evt.layer === 1 && evt.packages) {
          setShowConveyor(true);
          setScannedPackages(evt.packages.map((name) => ({ name, passed: false, scanned: false })));
        }
      } else if (evt.status === "skipped") {
        newStates[evt.layer] = "skipped";
        newProgress[evt.layer] = 100;
      } else if (evt.status === "passed" || evt.status === "complete") {
        // "complete" with findings = warning, without = pass
        const hasFindings = evt.findings !== undefined && evt.findings > 0;
        newStates[evt.layer] = hasFindings ? "warn" : "passed";
        newProgress[evt.layer] = 100;
      }
    }

    setLayerStates(newStates);
    setLayerProgress(newProgress);

    // Check for final completion event
    const latest = events[events.length - 1];
    if (latest.layer === -1 && latest.status === "complete") {
      if (latest.vending_code) {
        finalCode.current = latest.vending_code;
      }
      setAllDone(true);
    }
  }, [events]);

  // Slot machine animation
  useEffect(() => {
    if (!allDone) return;

    let count = 0;
    const interval = setInterval(() => {
      setSlotCode(generateRandomCode());
      count++;
      if (count >= 20) {
        clearInterval(interval);
        setSlotCode(finalCode.current);
        setSlotLanded(true);
        setTimeout(() => {
          onCompleteRef.current(finalCode.current);
        }, 1000);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [allDone]);

  if (!isValidating && !allDone) return null;

  return (
    <motion.div
      className="mt-8 space-y-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Progress Bars */}
      <div className="space-y-3">
        {LAYERS.map((layer, i) => {
          const state = layerStates[i];
          const progress = layerProgress[i];

          const barColor =
            state === "passed"
              ? "#39ff14"
              : state === "warn"
                ? "#fff01f"
                : state === "failed"
                  ? "#ff2d95"
                  : state === "skipped"
                    ? "#4a4a8a"
                    : state === "active"
                      ? "#00f0ff"
                      : "#4a4a8a";

          const statusLabel =
            state === "passed"
              ? "PASS"
              : state === "warn"
                ? "WARN"
                : state === "failed"
                  ? "FAIL"
                  : state === "skipped"
                    ? "SKIP"
                    : null;

          return (
            <motion.div
              key={layer.key}
              className="flex items-center gap-4"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
            >
              <span
                className="w-44 shrink-0 text-right font-mono text-xs"
                style={{
                  color: state === "idle" ? "#4a4a8a" : barColor,
                  textShadow: state !== "idle" ? `0 0 8px ${barColor}60` : "none",
                }}
              >
                {layer.label}
              </span>
              <div className="relative h-5 flex-1 overflow-hidden rounded-full bg-[#0d0d1a] border border-white/5">
                <motion.div
                  className="absolute inset-y-0 left-0 rounded-full"
                  style={{
                    background: `linear-gradient(90deg, ${barColor}80, ${barColor})`,
                    boxShadow:
                      state === "active" || state === "passed" || state === "warn"
                        ? `0 0 12px ${barColor}60, 0 0 24px ${barColor}30`
                        : "none",
                  }}
                  initial={{ width: "0%" }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.6, ease: "easeOut" }}
                />
                {statusLabel && (
                  <motion.span
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-bold"
                    style={{ color: barColor }}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 500, damping: 15 }}
                  >
                    {statusLabel}
                  </motion.span>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Package Conveyor Belt */}
      <AnimatePresence>
        {showConveyor && (
          <motion.div
            className="relative overflow-hidden rounded-xl border border-white/10 bg-[#0d0d1a] p-4"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <p className="mb-3 font-mono text-xs text-neon-blue/70">Scanning dependencies...</p>
            <div className="absolute left-1/2 top-10 bottom-4 w-px bg-neon-blue/60 shadow-[0_0_8px_#00f0ff60]" />

            <div className="flex items-center gap-3 py-2">
              {scannedPackages.map((pkg, i) => (
                <motion.div
                  key={pkg.name}
                  className="flex items-center gap-2 rounded-full border px-3 py-1.5 font-mono text-xs"
                  style={{
                    borderColor: pkg.scanned ? (pkg.passed ? "#39ff1460" : "#ff2d9560") : "#4a4a8a40",
                    background: pkg.scanned ? (pkg.passed ? "#39ff1410" : "#ff2d9510") : "#1a1a2e",
                    color: pkg.scanned ? (pkg.passed ? "#39ff14" : "#ff2d95") : "#8a8ab0",
                  }}
                  initial={{ x: 200, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{
                    delay: i * 0.3,
                    duration: 0.5,
                    ease: "easeOut",
                  }}
                >
                  <span>{pkg.name}</span>
                  <AnimatePresence>
                    {pkg.scanned && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{
                          type: "spring",
                          stiffness: 500,
                          damping: 15,
                        }}
                      >
                        {pkg.passed ? "\u2713" : "\u2717"}
                      </motion.span>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Slot Machine Vending Code — only for mock animation, hidden when real SSE events exist */}
      <AnimatePresence>
        {allDone && !usingRealEvents.current && (
          <motion.div
            className="flex flex-col items-center gap-4 py-8"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
          >
            <p className="font-mono text-sm text-white/60">Generating vending code...</p>
            <motion.div
              className="rounded-xl border-2 px-8 py-4 font-mono text-3xl font-bold tracking-widest"
              style={{
                borderColor: slotLanded ? "#39ff14" : "#4a4a8a",
                color: slotLanded ? "#39ff14" : "#00f0ff",
                background: "#0d0d1a",
                textShadow: slotLanded ? "0 0 12px #39ff1480, 0 0 24px #39ff1440" : "0 0 8px #00f0ff40",
              }}
              animate={
                slotLanded
                  ? {
                      boxShadow: [
                        "0 0 0px #39ff1400",
                        "0 0 30px #39ff1460, 0 0 60px #39ff1430",
                        "0 0 15px #39ff1440, 0 0 30px #39ff1420",
                      ],
                    }
                  : {}
              }
              transition={{ duration: 0.6 }}
            >
              {slotCode || "S-????"}
            </motion.div>
            {slotLanded && (
              <motion.p
                className="font-mono text-sm text-neon-green"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                Validation complete! Script approved.
              </motion.p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
