import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { Link, useLocation } from "react-router";
import { useAuthStore } from "../../stores/useAuthStore";
import { AuthModal } from "../auth/AuthModal";
import { NotificationInbox } from "../shared/NotificationInbox";

const NAV_LINKS = [
  { to: "/catalog", label: "Catalog" },
  { to: "/agents", label: "Agents" },
  { to: "/engagements", label: "Engagements" },
  { to: "/verify", label: "Verify" },
];

export const Navbar = () => {
  const { user, signOut } = useAuthStore();
  const location = useLocation();
  const [showAuth, setShowAuth] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <>
      <nav className="fixed top-0 right-0 left-0 z-40 border-b border-white/5 bg-[#0a0a1a]/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          {/* Left: Logo */}
          <Link to="/" className="flex items-center gap-2">
            <span className="neon-text text-lg font-bold tracking-widest text-neon-pink">VENDING MACHINE</span>
          </Link>

          {/* Center: Nav links */}
          <div className="flex items-center gap-8">
            {NAV_LINKS.map((link) => {
              const isActive = location.pathname.startsWith(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`relative text-sm font-medium transition-colors ${
                    isActive ? "text-neon-blue" : "text-white/60 hover:text-white/90"
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <motion.div
                      className="absolute -bottom-1 left-0 right-0 h-0.5 rounded-full bg-neon-blue"
                      layoutId="nav-underline"
                      style={{ boxShadow: "0 0 8px #00f0ff80" }}
                    />
                  )}
                </Link>
              );
            })}
          </div>

          {/* Right: Inbox + Notifications + User menu */}
          <div className="flex items-center gap-3">
            {user && (
              <Link
                to="/inbox"
                className="relative p-2 rounded-lg text-white/50 hover:text-white/90 hover:bg-white/5 transition-colors"
                title="Inbox"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="22 12 16 12 14 15 10 15 8 12 2 12" />
                  <path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" />
                </svg>
              </Link>
            )}
            <NotificationInbox />
            <div className="relative">
              {user ? (
                <div>
                  <button
                    type="button"
                    className="flex items-center gap-2 rounded-lg border border-white/10 px-3 py-1.5 text-sm text-white/80 transition-colors hover:border-white/20 hover:text-white"
                    onClick={() => setShowUserMenu((prev) => !prev)}
                  >
                    <span className="h-2 w-2 rounded-full bg-neon-green" />
                    {user.email}
                  </button>
                  <AnimatePresence>
                    {showUserMenu && (
                      <motion.div
                        className="absolute right-0 mt-2 w-48 rounded-xl border border-white/10 bg-[#1a1a2e]/95 p-2 backdrop-blur-xl"
                        initial={{ opacity: 0, y: -8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        transition={{ duration: 0.15 }}
                      >
                        <Link
                          to="/profile"
                          className="block rounded-lg px-3 py-2 text-sm text-white/70 transition-colors hover:bg-white/5 hover:text-white"
                          onClick={() => setShowUserMenu(false)}
                        >
                          Profile
                        </Link>
                        <Link
                          to="/inbox"
                          className="block rounded-lg px-3 py-2 text-sm text-white/70 transition-colors hover:bg-white/5 hover:text-white"
                          onClick={() => setShowUserMenu(false)}
                        >
                          Inbox
                        </Link>
                        <Link
                          to="/dashboard"
                          className="block rounded-lg px-3 py-2 text-sm text-white/70 transition-colors hover:bg-white/5 hover:text-white"
                          onClick={() => setShowUserMenu(false)}
                        >
                          Dashboard
                        </Link>
                        <Link
                          to="/creator-dashboard"
                          className="block rounded-lg px-3 py-2 text-sm text-white/70 transition-colors hover:bg-white/5 hover:text-white"
                          onClick={() => setShowUserMenu(false)}
                        >
                          Creator Dashboard
                        </Link>
                        <hr className="my-1 border-white/10" />
                        <button
                          type="button"
                          className="w-full rounded-lg px-3 py-2 text-left text-sm text-neon-pink/80 transition-colors hover:bg-white/5 hover:text-neon-pink"
                          onClick={() => {
                            signOut();
                            setShowUserMenu(false);
                          }}
                        >
                          Sign Out
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <button
                  type="button"
                  className="rounded-lg border border-neon-blue/40 px-4 py-1.5 text-sm font-medium text-neon-blue transition-all hover:border-neon-blue/60 hover:shadow-[0_0_15px_rgba(0,240,255,0.2)]"
                  onClick={() => setShowAuth(true)}
                >
                  Sign In
                </button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <AnimatePresence>{showAuth && <AuthModal onClose={() => setShowAuth(false)} />}</AnimatePresence>
    </>
  );
};
