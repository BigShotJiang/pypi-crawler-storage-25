import { useEffect, useMemo } from "react";
import { Outlet } from "react-router";
import { useAuthStore } from "../../stores/useAuthStore";
import { Toast } from "../shared/Toast";
import { Footer } from "./Footer";
import { Navbar } from "./Navbar";

const STAR_COUNT = 40;

interface Star {
  id: number;
  x: number;
  y: number;
  size: number;
  opacity: number;
  delay: number;
}

const generateStars = (): Star[] =>
  Array.from({ length: STAR_COUNT }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 2 + 1,
    opacity: Math.random() * 0.5 + 0.1,
    delay: Math.random() * 4,
  }));

export const RootLayout = () => {
  const initialize = useAuthStore((s) => s.initialize);
  const stars = useMemo(generateStars, []);

  useEffect(() => {
    initialize();
  }, [initialize]);

  return (
    <div className="relative flex min-h-screen flex-col">
      {/* Starfield background */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden="true">
        {stars.map((star) => (
          <div
            key={star.id}
            className="absolute rounded-full bg-white"
            style={{
              left: `${star.x}%`,
              top: `${star.y}%`,
              width: star.size,
              height: star.size,
              opacity: star.opacity,
              animation: `pulse ${2 + star.delay}s ease-in-out infinite`,
              animationDelay: `${star.delay}s`,
            }}
          />
        ))}
        <style>{`
          @keyframes pulse {
            0%, 100% { opacity: var(--tw-opacity, 0.2); }
            50% { opacity: calc(var(--tw-opacity, 0.2) + 0.3); }
          }
        `}</style>
      </div>

      <Navbar />

      <main className="relative z-10 mx-auto w-full max-w-7xl flex-1 px-6 pt-24 pb-12">
        <Outlet />
      </main>

      <Footer />
      <Toast />
    </div>
  );
};
