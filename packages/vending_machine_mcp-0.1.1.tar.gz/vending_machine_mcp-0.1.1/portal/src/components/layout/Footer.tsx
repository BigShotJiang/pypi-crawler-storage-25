export const Footer = () => {
  return (
    <footer className="border-t border-white/5 bg-[#0a0a1a]/90">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <span className="text-sm text-white/30">Vending Machine Marketplace</span>

        <div className="flex items-center gap-6">
          <code className="rounded-md bg-white/5 px-2 py-1 text-xs text-white/40">pip install vending-machine-mcp</code>
          <a
            href="https://github.com/yokiido/vending-machine"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-white/30 transition-colors hover:text-neon-blue"
          >
            GitHub
          </a>
        </div>
      </div>
    </footer>
  );
};
