import { motion } from "framer-motion";
import { type FormEvent, useState } from "react";
import { useAuthStore } from "../../stores/useAuthStore";

interface AuthModalProps {
  onClose: () => void;
}

export const AuthModal = ({ onClose }: AuthModalProps) => {
  const { signIn, signUp } = useAuthStore();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    const result = mode === "signin" ? await signIn(email, password) : await signUp(email, password);

    setLoading(false);

    if (result) {
      setError(result);
    } else if (mode === "signup") {
      setSuccess("Check your email to confirm your account.");
    } else {
      onClose();
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Backdrop */}
      <button
        type="button"
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        onKeyDown={(e) => e.key === "Escape" && onClose()}
        tabIndex={0}
        aria-label="Close modal"
      />

      {/* Modal */}
      <motion.div
        className="relative w-full max-w-md rounded-2xl border border-white/10 bg-[#1a1a2e]/95 p-8 backdrop-blur-xl"
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        style={{
          boxShadow: "0 0 40px rgba(0,240,255,0.1), 0 0 80px rgba(0,240,255,0.05)",
        }}
      >
        <h2 className="mb-6 text-center text-2xl font-bold text-white">
          {mode === "signin" ? "Welcome Back" : "Create Account"}
        </h2>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label htmlFor="auth-email" className="mb-1 block text-sm text-white/60">
              Email
            </label>
            <input
              id="auth-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full rounded-lg border border-white/10 bg-[#0a0a1a]/80 px-4 py-2.5 text-sm text-white outline-none transition-colors placeholder:text-white/20 focus:border-neon-blue/50"
              placeholder="you@example.com"
            />
          </div>

          <div>
            <label htmlFor="auth-password" className="mb-1 block text-sm text-white/60">
              Password
            </label>
            <input
              id="auth-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              className="w-full rounded-lg border border-white/10 bg-[#0a0a1a]/80 px-4 py-2.5 text-sm text-white outline-none transition-colors placeholder:text-white/20 focus:border-neon-blue/50"
              placeholder="Min 6 characters"
            />
          </div>

          {error && (
            <motion.p
              className="rounded-lg bg-neon-pink/10 px-3 py-2 text-sm text-neon-pink"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {error}
            </motion.p>
          )}

          {success && (
            <motion.p
              className="rounded-lg bg-neon-green/10 px-3 py-2 text-sm text-neon-green"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {success}
            </motion.p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="mt-2 rounded-lg bg-neon-blue/20 py-2.5 text-sm font-semibold text-neon-blue transition-all hover:bg-neon-blue/30 hover:shadow-[0_0_20px_rgba(0,240,255,0.25)] disabled:cursor-not-allowed disabled:opacity-50"
            style={{ border: "1px solid rgba(0,240,255,0.3)" }}
          >
            {loading ? "Loading..." : mode === "signin" ? "Sign In" : "Create Account"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-white/40">
          {mode === "signin" ? "Don't have an account? " : "Already have an account? "}
          <button
            type="button"
            className="text-neon-blue transition-colors hover:text-neon-blue/80"
            onClick={() => {
              setMode(mode === "signin" ? "signup" : "signin");
              setError(null);
              setSuccess(null);
            }}
          >
            {mode === "signin" ? "Sign Up" : "Sign In"}
          </button>
        </p>

        {/* Close button */}
        <button
          type="button"
          className="absolute top-4 right-4 text-white/30 transition-colors hover:text-white/60"
          onClick={onClose}
          aria-label="Close"
        >
          \u00d7
        </button>
      </motion.div>
    </motion.div>
  );
};
