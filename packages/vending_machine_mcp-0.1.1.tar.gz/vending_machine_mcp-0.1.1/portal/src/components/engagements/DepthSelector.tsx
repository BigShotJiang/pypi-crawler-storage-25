import { useState } from "react";
import type { EngagementDepth } from "../../types/engagement";

interface DepthSelectorProps {
  depth: EngagementDepth;
  onSelect: (depth: EngagementDepth) => void;
}

const DEPTH_OPTIONS: {
  id: EngagementDepth;
  label: string;
  description: string;
  tooltip: string;
  color: string;
}[] = [
  {
    id: "scan",
    label: "Scan & Report",
    description: "AI agents analyze your codebase and deliver a branded PDF report",
    tooltip:
      "A triage agent picks which specialist agents to run based on your repo and scope. " +
      "Agents run in parallel where possible. You get a comprehensive report with findings, " +
      "recommendations, and remediation guidance. No code changes are applied.",
    color: "#00f0ff",
  },
  {
    id: "autonomous",
    label: "Fully Autonomous",
    description: "AI clones your repo, applies fixes, runs tests, and opens a PR",
    tooltip:
      "A Daytona sandbox clones your repository and runs Claude Code with access to all " +
      "specialist agents (Bug Hunter, Test Goblin, Code Gremlin, DevOps Dwarf). " +
      "The AI applies fixes, runs tests, commits changes, and opens a pull request. " +
      "Requires GitHub access to your repository.",
    color: "#39ff14",
  },
];

function InfoTooltip({ text }: { text: string }) {
  const [show, setShow] = useState(false);

  return (
    <span
      className="relative inline-flex items-center justify-center w-4 h-4 rounded-full border border-white/20 text-[9px] text-white/40 cursor-help ml-1"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      ?
      {show && (
        <span className="absolute bottom-6 left-1/2 -translate-x-1/2 w-64 p-3 rounded-lg bg-[#1a1a2e] border border-white/10 text-xs text-gray-300 shadow-xl z-50 leading-relaxed">
          {text}
        </span>
      )}
    </span>
  );
}

export const DepthSelector = ({ depth, onSelect }: DepthSelectorProps) => {
  return (
    <div className="flex gap-3">
      {DEPTH_OPTIONS.map((opt) => (
        <button
          key={opt.id}
          type="button"
          onClick={() => onSelect(opt.id)}
          className="flex-1 text-left rounded-xl p-4 transition-all"
          style={{
            background:
              depth === opt.id
                ? `linear-gradient(135deg, ${opt.color}10, ${opt.color}05)`
                : "rgba(255,255,255,0.03)",
            border: `1px solid ${depth === opt.id ? `${opt.color}40` : "rgba(255,255,255,0.08)"}`,
          }}
        >
          <div className="flex items-center gap-1 mb-1">
            <span
              className="text-sm font-medium"
              style={{ color: depth === opt.id ? opt.color : "rgba(255,255,255,0.6)" }}
            >
              {opt.label}
            </span>
            <InfoTooltip text={opt.tooltip} />
          </div>
          <p className="text-[11px] text-gray-500 leading-snug">{opt.description}</p>
        </button>
      ))}
    </div>
  );
};
