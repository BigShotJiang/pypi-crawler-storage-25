import { motion } from "framer-motion";
import type { PackageInfo } from "../../types/engagement";

interface PackageCardProps {
  pkg: PackageInfo;
  selected: boolean;
  onSelect: (id: string) => void;
}

export const PackageCard = ({ pkg, selected, onSelect }: PackageCardProps) => {
  return (
    <motion.button
      type="button"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onSelect(pkg.id)}
      className="text-left w-full rounded-xl p-5 transition-all"
      style={{
        background: selected
          ? `linear-gradient(135deg, ${pkg.color}15, ${pkg.color}08)`
          : "rgba(255,255,255,0.03)",
        border: `1px solid ${selected ? `${pkg.color}60` : "rgba(255,255,255,0.08)"}`,
      }}
    >
      <div className="flex items-center gap-3 mb-3">
        <span className="text-2xl">{pkg.icon}</span>
        <div>
          <h3
            className="font-bold text-base"
            style={{ color: pkg.color }}
          >
            {pkg.name}
          </h3>
          <p className="text-xs text-gray-400">{pkg.tagline}</p>
        </div>
        <span
          className="ml-auto text-sm font-mono px-2 py-1 rounded"
          style={{
            background: `${pkg.color}15`,
            color: pkg.color,
          }}
        >
          {pkg.credits} credits
        </span>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {pkg.agents.map((agent) => (
          <span
            key={agent}
            className="text-[10px] px-2 py-0.5 rounded-full"
            style={{
              background: "rgba(255,255,255,0.05)",
              color: "rgba(255,255,255,0.6)",
            }}
          >
            {agent}
          </span>
        ))}
      </div>
    </motion.button>
  );
};
