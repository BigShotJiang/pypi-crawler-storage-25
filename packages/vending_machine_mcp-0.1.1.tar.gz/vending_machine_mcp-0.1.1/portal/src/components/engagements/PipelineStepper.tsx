import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import type { EngagementStep } from "../../types/engagement";

interface PipelineStepperProps {
  steps: EngagementStep[];
  currentStep: number;
  totalSteps: number;
  agentNames: string[];
  packageColor: string;
  engagementStatus: string;
}

const STATUS_LABEL: Record<string, string> = {
  pending: "",
  queued: "Queued",
  running: "Analyzing...",
  complete: "Done",
  error: "Failed",
};

function LiveTimer() {
  const startRef = useRef(Date.now());
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const mins = Math.floor(elapsed / 60);
  const secs = elapsed % 60;
  return (
    <span className="text-[10px] font-mono tabular-nums" style={{ color: "#ff6b35" }}>
      {mins > 0 ? `${mins}m ${secs}s` : `${secs}s`}
    </span>
  );
}

function formatElapsed(ms: number): string {
  if (ms < 1000) return "<1s";
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60_000).toFixed(1)}m`;
}

export const PipelineStepper = ({
  steps,
  currentStep,
  agentNames,
  packageColor,
  engagementStatus,
}: PipelineStepperProps) => {
  const names = agentNames ?? [];
  const isPipelineLive = engagementStatus === "running" || engagementStatus === "intake";

  // Determine which index is active based on currentStep prop (not array length)
  // currentStep from backend is 1-indexed (0 = not started, 1 = first step done/running)
  const activeIndex = isPipelineLive ? Math.max(0, currentStep) : -1;

  // Build unified step list: match by name only, no index fallback
  const allSteps = names.map((name, i) => {
    const step = steps.find((s) => s.agent_name === name);
    const isActive = i === activeIndex && isPipelineLive && (!step || step.status !== "complete");

    if (step) {
      return {
        key: name,
        agentLabel: name,
        status: step.status,
        runtime_ms: step.runtime_ms,
        isActive: isActive || step.status === "running",
      };
    }

    return {
      key: name,
      agentLabel: name,
      status: "pending" as const,
      runtime_ms: 0,
      isActive,
    };
  });

  return (
    <div className="space-y-0">
      {allSteps.map((step, i) => {
        const { isActive } = step;
        const isDone = step.status === "complete";
        const isError = step.status === "error";
        const isPending = step.status === "pending";
        const isLast = i === allSteps.length - 1;

        // Dot colors — blue for active, green for done
        const activeColor = "#00f0ff";
        let dotColor = "rgba(255,255,255,0.08)";
        let dotBorder = "rgba(255,255,255,0.12)";
        if (isActive) {
          dotColor = activeColor;
          dotBorder = activeColor;
        } else if (isDone) {
          dotColor = "#39ff14";
          dotBorder = "#39ff14";
        } else if (isError) {
          dotColor = "#ff2d95";
          dotBorder = "#ff2d95";
        }

        const lineColor = isDone ? "#39ff1440" : "rgba(255,255,255,0.06)";

        return (
          <div key={step.key} className="flex items-start gap-4">
            {/* Timeline column */}
            <div className="flex flex-col items-center w-5 flex-shrink-0">
              <div className="relative">
                {isActive && (
                  <>
                    {/* Pulsing glow ring */}
                    <motion.div
                      className="absolute -inset-1.5 rounded-full"
                      style={{ border: `1.5px solid ${activeColor}` }}
                      animate={{ opacity: [0.3, 0.8, 0.3], scale: [1, 1.15, 1] }}
                      transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
                    />
                    {/* Spinning arc */}
                    <motion.div
                      className="absolute -inset-2.5 rounded-full"
                      style={{
                        border: "2px solid transparent",
                        borderTopColor: activeColor,
                        borderRightColor: `${activeColor}40`,
                      }}
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1.2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                    />
                  </>
                )}
                <motion.div
                  className="w-3 h-3 rounded-full relative z-10"
                  style={{
                    background: isPending && !isActive ? "transparent" : dotColor,
                    border: isPending && !isActive
                      ? `1.5px dashed ${dotBorder}`
                      : `1.5px solid ${dotBorder}`,
                  }}
                  animate={isActive ? {
                    boxShadow: [
                      `0 0 4px ${activeColor}60`,
                      `0 0 12px ${activeColor}80`,
                      `0 0 4px ${activeColor}60`,
                    ],
                  } : {}}
                  transition={isActive ? { duration: 1.5, repeat: Number.POSITIVE_INFINITY } : {}}
                />
              </div>

              {/* Connector line */}
              {!isLast && (
                <motion.div
                  className="w-px flex-1 min-h-[28px]"
                  style={{ background: lineColor }}
                  animate={isActive ? {
                    background: [`${activeColor}15`, `${activeColor}50`, `${activeColor}15`],
                  } : {}}
                  transition={isActive ? { duration: 2, repeat: Number.POSITIVE_INFINITY } : {}}
                />
              )}
            </div>

            {/* Step content */}
            <div className="pb-5 -mt-0.5 flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span
                  className="text-sm font-medium"
                  style={{
                    color: isActive
                      ? "#fff"
                      : isDone
                        ? "rgba(255,255,255,0.7)"
                        : isPending
                          ? "rgba(255,255,255,0.25)"
                          : isError
                            ? "#ff2d95"
                            : "rgba(255,255,255,0.5)",
                  }}
                >
                  {step.agentLabel}
                </span>

                {isActive && (
                  <motion.span
                    className="text-[10px] px-1.5 py-0.5 rounded"
                    style={{ background: `${activeColor}15`, color: activeColor }}
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1.2, repeat: Number.POSITIVE_INFINITY }}
                  >
                    {STATUS_LABEL.running}
                  </motion.span>
                )}
                {isDone && !isActive && (
                  <span className="text-[10px] text-green-500/70">{STATUS_LABEL.complete}</span>
                )}
                {isError && (
                  <span className="text-[10px] text-pink-500">{STATUS_LABEL.error}</span>
                )}
              </div>

              {/* Timer */}
              <div className="mt-0.5">
                {isActive && <LiveTimer />}
                {isDone && step.runtime_ms > 0 && (
                  <span className="text-[10px] text-gray-600 font-mono">
                    {formatElapsed(step.runtime_ms)}
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
