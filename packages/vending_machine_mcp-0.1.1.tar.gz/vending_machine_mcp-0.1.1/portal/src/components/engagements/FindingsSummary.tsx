import type { FindingsSummary as FindingsType } from "../../types/engagement";

interface FindingsSummaryProps {
  findings: FindingsType;
}

const SEVERITIES: { key: keyof FindingsType; label: string; color: string }[] =
  [
    { key: "critical", label: "Critical", color: "#ff2d55" },
    { key: "high", label: "High", color: "#ff6b35" },
    { key: "medium", label: "Medium", color: "#ffd60a" },
    { key: "low", label: "Low", color: "#00b4d8" },
    { key: "info", label: "Info", color: "#888" },
  ];

export const FindingsSummary = ({ findings }: FindingsSummaryProps) => {
  const total = Object.values(findings).reduce((a, b) => a + b, 0);
  if (total === 0) {
    return (
      <div className="text-center py-4 text-gray-500 text-sm">
        No findings detected
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {SEVERITIES.map(({ key, label, color }) => {
        const count = findings[key];
        const pct = total > 0 ? (count / total) * 100 : 0;

        return (
          <div key={key} className="flex items-center gap-3">
            <span
              className="text-xs font-medium w-16 text-right"
              style={{ color }}
            >
              {label}
            </span>
            <div className="flex-1 h-2 rounded-full bg-white/5 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${pct}%`, background: color }}
              />
            </div>
            <span className="text-xs font-mono text-gray-400 w-6 text-right">
              {count}
            </span>
          </div>
        );
      })}
      <div className="text-right text-[10px] text-gray-500 pt-1">
        {total} total finding{total !== 1 ? "s" : ""}
      </div>
    </div>
  );
};
