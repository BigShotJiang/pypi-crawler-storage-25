import { motion } from "framer-motion";
import { Link } from "react-router";
import type { Script } from "../../types/script";
import { StatusBadge } from "../shared/StatusBadge";

interface ScriptCardProps {
  script: Script;
}

export const ScriptCard = ({ script }: ScriptCardProps) => {
  return (
    <Link to={`/catalog/${script.script_id}`} className="block">
      <motion.div
        className="relative rounded-2xl border border-white/10 bg-[#1a1a2e]/70 p-5 backdrop-blur-xl"
        whileHover={{
          borderColor: "rgba(0, 240, 255, 0.4)",
          boxShadow: "0 0 20px rgba(0,240,255,0.1), 0 0 40px rgba(0,240,255,0.05)",
          y: -3,
        }}
        transition={{ duration: 0.25, ease: "easeOut" }}
      >
        {/* Vending code badge */}
        <div className="mb-3 flex items-center justify-between">
          <span
            className="rounded-md px-2.5 py-1 font-mono text-xs font-bold tracking-wider"
            style={{
              color: "#00f0ff",
              background: "rgba(0,240,255,0.08)",
              border: "1px solid rgba(0,240,255,0.25)",
              textShadow: "0 0 8px rgba(0,240,255,0.5)",
            }}
          >
            {script.vending_code}
          </span>
          <StatusBadge status={script.validation_status} />
        </div>

        {/* Name */}
        <h3 className="mb-1.5 text-base font-semibold text-white/90">{script.name}</h3>

        {/* Description - truncated */}
        <p className="mb-4 line-clamp-2 text-sm leading-relaxed text-white/50">{script.description}</p>

        {/* Footer: creator + runs */}
        <div className="flex items-center justify-between text-xs text-white/40">
          <span>by {script.creator}</span>
          <span className="font-mono tabular-nums">{script.runs.toLocaleString()} runs</span>
        </div>
      </motion.div>
    </Link>
  );
};
