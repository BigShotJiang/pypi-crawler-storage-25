import { motion } from "framer-motion";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export const SearchBar = ({ value, onChange }: SearchBarProps) => {
  return (
    <motion.div
      className="relative w-full max-w-xl"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <svg
        className="absolute top-1/2 left-4 h-5 w-5 -translate-y-1/2 text-white/40"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
        aria-hidden="true"
      >
        <title>Search</title>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35M11 19a8 8 0 100-16 8 8 0 000 16z" />
      </svg>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search scripts..."
        className="w-full rounded-xl border border-white/10 bg-[#0a0a1a] py-3 pr-4 pl-12 text-sm text-white/90 outline-none transition-all duration-300 placeholder:text-white/30 focus:border-neon-blue/60 focus:ring-2 focus:ring-neon-blue/20"
        style={{
          boxShadow: "inset 0 1px 4px rgba(0,0,0,0.4)",
        }}
      />
    </motion.div>
  );
};
