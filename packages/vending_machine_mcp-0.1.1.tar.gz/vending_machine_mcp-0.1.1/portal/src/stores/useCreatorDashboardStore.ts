import { create } from "zustand";

export type CreatorSortKey = "name" | "runs" | "revenue";
export type CreatorSortDirection = "asc" | "desc";

interface CreatorDashboardState {
  sortKey: CreatorSortKey;
  sortDirection: CreatorSortDirection;
  selectedScriptId: string | null;
  setSort: (key: CreatorSortKey) => void;
  setSelectedScriptId: (id: string | null) => void;
}

export const useCreatorDashboardStore = create<CreatorDashboardState>((set) => ({
  sortKey: "runs",
  sortDirection: "desc",
  selectedScriptId: null,
  setSort: (key) =>
    set((state) => ({
      sortKey: key,
      sortDirection: state.sortKey === key && state.sortDirection === "desc" ? "asc" : "desc",
    })),
  setSelectedScriptId: (id) => set({ selectedScriptId: id }),
}));
