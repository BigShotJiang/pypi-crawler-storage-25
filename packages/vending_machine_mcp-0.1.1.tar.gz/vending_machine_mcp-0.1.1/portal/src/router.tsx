import { createBrowserRouter } from "react-router";
import { RootLayout } from "./components/layout/RootLayout";
import { AdminPage } from "./pages/AdminPage";
import { AgentDetailPage } from "./pages/AgentDetailPage";
import { AgentsPage } from "./pages/AgentsPage";
import { CatalogPage } from "./pages/CatalogPage";
import { CreatorDashboardPage } from "./pages/CreatorDashboardPage";
import { DashboardPage } from "./pages/DashboardPage";
import { EngagementDetailPage } from "./pages/EngagementDetailPage";
import { EngagementsPage } from "./pages/EngagementsPage";
import { HomePage } from "./pages/HomePage";
import { NewEngagementPage } from "./pages/NewEngagementPage";
import { InboxPage } from "./pages/InboxPage";
import { NotificationsPage } from "./pages/NotificationsPage";
import { ProfilePage } from "./pages/ProfilePage";
import { ScriptDetailPage } from "./pages/ScriptDetailPage";
import { SubmitPage } from "./pages/SubmitPage";
import { VerifyPage } from "./pages/VerifyPage";

export const router = createBrowserRouter([
  {
    element: <RootLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "catalog", element: <CatalogPage /> },
      { path: "catalog/:scriptId", element: <ScriptDetailPage /> },
      { path: "submit", element: <SubmitPage /> },
      { path: "dashboard", element: <DashboardPage /> },
      { path: "creator-dashboard", element: <CreatorDashboardPage /> },
      { path: "verify", element: <VerifyPage /> },
      { path: "verify/:hash", element: <VerifyPage /> },
      { path: "agents", element: <AgentsPage /> },
      { path: "agents/:agentId", element: <AgentDetailPage /> },
      { path: "engagements", element: <EngagementsPage /> },
      { path: "engagements/new", element: <NewEngagementPage /> },
      { path: "engagements/:engagementId", element: <EngagementDetailPage /> },
      { path: "inbox", element: <InboxPage /> },
      { path: "notifications", element: <NotificationsPage /> },
      { path: "profile", element: <ProfilePage /> },
      { path: "admin", element: <AdminPage /> },
    ],
  },
]);
