# Venda — AI Agent Marketplace

Script marketplace with 7-layer security validation, 13 specialized agents, and autonomous dev agent capabilities. MCP-native distribution for Claude Code, Codex, Cursor, and any MCP-compatible client.

## Architecture

```
backend/     FastAPI + LangGraph agents + WebSocket streaming
portal/      React 19 + Vite + Tailwind + Framer Motion
ops/         OpenClaw ops agent for self-healing infrastructure
mcp/         MCP server package (pip install vending-machine-mcp)
scripts/     Marketplace scripts (community-contributed)
infra/       Dockerfiles, compose, CI/CD, Terraform
docs/        Project docs, audit findings, production checklist
```

## Quick Start

```bash
# Backend
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # Add your API keys
python3 main.py

# Portal
cd portal
npm install
npm run dev
```

## API Keys Required

```
OPENROUTER_API_KEY    — Most agents (OpenRouter gateway)
OPENAI_API_KEY        — Research Owl, embeddings
DAYTONA_API_KEY       — Sandbox execution (or E2B_API_KEY)
SUPABASE_URL          — Database
SUPABASE_SECRET_KEY   — Database (service role)
UPSTASH_REDIS_REST_URL    — Rate limiting, caching
UPSTASH_REDIS_REST_TOKEN  — Redis auth
RESEND_API_KEY        — Email notifications (optional)
```

## Production Hardening

See `docs/PRODUCTION_READINESS_CHECKLIST.md` for the full go-live gate checklist.

## License

MIT
