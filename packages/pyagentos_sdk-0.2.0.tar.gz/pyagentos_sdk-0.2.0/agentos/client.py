"""AgentOS HTTP client — wraps httpx for the ingest API."""

from __future__ import annotations

from typing import Any

import httpx

from .errors import (
    AgentOSAuthError,
    AgentOSError,
    AgentOSRateLimitError,
    AgentOSValidationError,
)
from .run import Run

DEFAULT_BASE_URL = "https://agentos-ai.dev"
USER_AGENT = "agentos-sdk-py/0.2.0"


class AgentOS:
    """Top-level AgentOS client.

    >>> aos = AgentOS(api_key="aos_test_...", agent_id="...")
    >>> run = aos.start_run(input={"invoice_id": "INV-1"})
    >>> run.emit_tool_call("validate_amounts", {"expected": 1250.0})
    >>> run.complete(output={"processed": True})
    """

    def __init__(
        self,
        *,
        api_key: str,
        agent_id: str,
        base_url: str | None = None,
        batch_interval_ms: int = 500,
        batch_size: int = 50,
        disabled: bool = False,
        timeout_seconds: float = 10.0,
    ) -> None:
        self.api_key = api_key
        self.agent_id = agent_id
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.batch_interval_ms = batch_interval_ms
        self.batch_size = batch_size
        self.disabled = disabled
        self._http = httpx.Client(timeout=timeout_seconds)

    def start_run(
        self,
        *,
        input: dict[str, Any] | None = None,
        trigger_type: str = "sdk",
        external_run_id: str | None = None,
    ) -> Run:
        """Create a new run on the server and return a Run handle."""
        if self.disabled:
            return Run(run_id="disabled", client=self)
        body: dict[str, Any] = {
            "agent_id": self.agent_id,
            "trigger_type": trigger_type,
            "input": input or {},
        }
        if external_run_id is not None:
            body["external_run_id"] = external_run_id
        res = self.post("/api/ingest/v1/run/start", body)
        run_id: str = res["data"]["run_id"]
        return Run(run_id=run_id, client=self)

    def invoke(
        self,
        input: dict[str, Any] | None = None,
        *,
        agent_id: str | None = None,
    ) -> dict[str, Any]:
        """Call a hosted agent and get its output back synchronously.

        AgentOS runs the agent server-side. This is the counterpart to
        ``start_run()``, which is for external agents reporting their own runs.

        Defaults to the ``agent_id`` from the constructor. Pass ``agent_id`` to
        target a different hosted agent with the same client.

        Returns ``{"run_id": str, "output": dict}``.
        """
        if self.disabled:
            return {"run_id": "disabled", "output": {}}
        target_id = agent_id or self.agent_id
        res = self.post(
            f"/api/v1/agents/{target_id}/invoke",
            {"input": input or {}},
        )
        return {
            "run_id": res["data"]["run_id"],
            "output": res["data"].get("output", {}),
        }

    def post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        if self.disabled:
            return {"data": None}
        url = f"{self.base_url}{path}"
        try:
            resp = self._http.post(
                url,
                json=body,
                headers={
                    "authorization": f"Bearer {self.api_key}",
                    "user-agent": USER_AGENT,
                    "content-type": "application/json",
                },
            )
        except httpx.HTTPError as exc:
            raise AgentOSError(f"network error: {exc}", code="INTERNAL_ERROR") from exc
        if resp.is_success:
            return resp.json()
        # Error path: parse {error: {code, message}} envelope.
        message = f"{resp.status_code} {resp.reason_phrase}"
        code: str | None = None
        try:
            payload = resp.json()
            err = payload.get("error") if isinstance(payload, dict) else None
            if isinstance(err, dict):
                if isinstance(err.get("message"), str):
                    message = err["message"]
                if isinstance(err.get("code"), str):
                    code = err["code"]
        except Exception:  # noqa: BLE001 — body wasn't JSON; fall through.
            pass
        if code == "UNAUTHENTICATED":
            raise AgentOSAuthError(message)
        if code == "VALIDATION_ERROR":
            raise AgentOSValidationError(message)
        if code == "RATE_LIMITED":
            raise AgentOSRateLimitError(message)
        raise AgentOSError(message, code=code or "INTERNAL_ERROR")

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "AgentOS":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()
