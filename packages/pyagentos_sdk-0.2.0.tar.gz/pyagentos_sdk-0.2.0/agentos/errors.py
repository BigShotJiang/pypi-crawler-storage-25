"""Typed errors for AgentOS SDK. Mirror the TypeScript SDK's class hierarchy."""

from __future__ import annotations


class AgentOSError(Exception):
    """Base class for all SDK errors."""

    def __init__(self, message: str, code: str = "INTERNAL_ERROR") -> None:
        super().__init__(message)
        self.code = code


class AgentOSAuthError(AgentOSError):
    """Raised when the API key is missing, malformed, revoked, or expired."""

    def __init__(self, message: str = "Invalid or revoked API key") -> None:
        super().__init__(message, code="UNAUTHENTICATED")


class AgentOSValidationError(AgentOSError):
    """Raised when the request body fails server-side Zod validation."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="VALIDATION_ERROR")


class AgentOSRateLimitError(AgentOSError):
    """Raised when ingest rate-limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded") -> None:
        super().__init__(message, code="RATE_LIMITED")
