"""Run + Task classes for AgentOS Python SDK.

Mirrors the TypeScript shape — emit() is fire-and-forget (we send synchronously
on a background thread for now; switch to a thread pool when batching becomes
hot). Task ids are client-generated UUIDs so create + complete share an id.
"""

from __future__ import annotations

import threading
import time
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .client import AgentOS


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class Run:
    """Handle for a running agent run. Buffer emits, flush in batches."""

    def __init__(self, *, run_id: str, client: "AgentOS") -> None:
        self.run_id = run_id
        self._client = client
        self._buffer: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._flush_timer: threading.Timer | None = None
        self._ended = False

    # ── emit helpers ──────────────────────────────────────────────────────

    def emit(
        self,
        type: str,  # noqa: A002 — mirrors TS API
        payload: dict[str, Any] | None = None,
        level: str = "info",
    ) -> None:
        if self._ended:
            return
        with self._lock:
            self._buffer.append(
                {
                    "type": type,
                    "level": level,
                    "payload": payload or {},
                    "occurred_at": _now_iso(),
                }
            )
            self._schedule_flush_locked()

    def emit_llm_request(
        self, model: str, prompt: str, options: dict[str, Any] | None = None
    ) -> None:
        self.emit("llm.request", {"model": model, "prompt": prompt, **(options or {})})

    def emit_llm_response(
        self,
        model: str,
        response: str,
        token_usage: dict[str, int] | None = None,
    ) -> None:
        self.emit(
            "llm.response",
            {"model": model, "response": response, **(token_usage or {})},
        )

    def emit_tool_call(self, tool: str, input: dict[str, Any] | None = None) -> None:  # noqa: A002
        self.emit("tool.called", {"tool": tool, "input": input or {}})

    def emit_tool_return(self, tool: str, output: dict[str, Any] | None = None) -> None:
        self.emit("tool.returned", {"tool": tool, "output": output or {}})

    def emit_tool_error(self, tool: str, error: str) -> None:
        self.emit("tool.failed", {"tool": tool, "error": error}, level="error")

    # ── tasks ─────────────────────────────────────────────────────────────

    def start_task(self, name: str, input: dict[str, Any] | None = None) -> "Task":  # noqa: A002
        self.flush()
        task_id = str(uuid.uuid4())
        self._client.post(
            "/api/ingest/v1/tasks",
            {
                "run_id": self.run_id,
                "task": {
                    "id": task_id,
                    "name": name,
                    "status": "running",
                    "input": input or {},
                },
            },
        )
        return Task(task_id=task_id, name=name, run_id=self.run_id, client=self._client)

    # ── lifecycle ─────────────────────────────────────────────────────────

    def complete(self, output: dict[str, Any] | None = None) -> None:
        self.flush()
        body: dict[str, Any] = {"run_id": self.run_id}
        if output is not None:
            body["output"] = output
        self._client.post("/api/ingest/v1/run/complete", body)
        self._ended = True

    def fail(self, error_message: str, error_detail: dict[str, Any] | None = None) -> None:
        self.flush()
        body: dict[str, Any] = {"run_id": self.run_id, "error_message": error_message}
        if error_detail is not None:
            body["error_detail"] = error_detail
        self._client.post("/api/ingest/v1/run/fail", body)
        self._ended = True

    def flush(self) -> None:
        with self._lock:
            if self._flush_timer is not None:
                self._flush_timer.cancel()
                self._flush_timer = None
            if not self._buffer:
                return
            batch = self._buffer[: self._client.batch_size]
            self._buffer = self._buffer[self._client.batch_size :]
        self._client.post(
            "/api/ingest/v1/events",
            {"run_id": self.run_id, "events": batch},
        )
        if self._buffer:
            # Drain any remaining items recursively.
            self.flush()

    # ── internal ──────────────────────────────────────────────────────────

    def _schedule_flush_locked(self) -> None:
        if len(self._buffer) >= self._client.batch_size:
            # Flush synchronously without holding the lock during HTTP call.
            self._lock.release()
            try:
                self.flush()
            finally:
                self._lock.acquire()
            return
        if self._flush_timer is not None:
            return
        delay_seconds = self._client.batch_interval_ms / 1000.0
        self._flush_timer = threading.Timer(delay_seconds, self._timer_flush)
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def _timer_flush(self) -> None:
        try:
            self.flush()
        except Exception:  # noqa: BLE001 — flusher must not crash the host process
            time.sleep(0)


class Task:
    """One unit of work within a run. Lifecycle: complete | fail | skip."""

    def __init__(self, *, task_id: str, name: str, run_id: str, client: "AgentOS") -> None:
        self.task_id = task_id
        self.name = name
        self._run_id = run_id
        self._client = client

    def complete(self, output: dict[str, Any] | None = None) -> None:
        self._client.post(
            "/api/ingest/v1/tasks",
            {
                "run_id": self._run_id,
                "task": {
                    "id": self.task_id,
                    "name": self.name,
                    "status": "completed",
                    "output": output or {},
                },
            },
        )

    def fail(self, error_message: str) -> None:
        self._client.post(
            "/api/ingest/v1/tasks",
            {
                "run_id": self._run_id,
                "task": {
                    "id": self.task_id,
                    "name": self.name,
                    "status": "failed",
                    "error_message": error_message,
                },
            },
        )

    def skip(self) -> None:
        self._client.post(
            "/api/ingest/v1/tasks",
            {
                "run_id": self._run_id,
                "task": {
                    "id": self.task_id,
                    "name": self.name,
                    "status": "skipped",
                },
            },
        )
