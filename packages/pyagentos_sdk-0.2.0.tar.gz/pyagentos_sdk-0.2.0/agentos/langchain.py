"""AgentOSCallbackHandler — wires LangChain (Python) callbacks into a Run.

Optional dependency: install with ``pip install agentos-sdk[langchain]`` to
pull in ``langchain-core``. Apps that don't use LangChain don't import this
module and pay nothing.

Usage::

    from agentos import AgentOS
    from agentos.langchain import AgentOSCallbackHandler

    aos = AgentOS(api_key=..., agent_id=...)
    run = aos.start_run()
    handler = AgentOSCallbackHandler(run)

    from langchain_anthropic import ChatAnthropic
    model = ChatAnthropic(callbacks=[handler])
    model.invoke("...")

    run.complete()

Mirrors the TypeScript SDK's ``AgentOSCallbackHandler`` behaviour:

* LLM start / end / error → run.emit_llm_request / response / fail
* Tool start / end / error → run.emit_tool_call / return / error
* Chain start / end / error → run.start_task / Task.complete / Task.fail

We import LangChain's BaseCallbackHandler at runtime so that the rest of the
SDK can be installed without LangChain present.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from uuid import UUID

if TYPE_CHECKING:
    from .run import Run, Task


def _import_base() -> type:
    """Lazy-import LangChain's BaseCallbackHandler so non-LangChain users
    don't pay for it. Raises a friendly error if the optional dep is missing."""
    try:
        from langchain_core.callbacks import BaseCallbackHandler  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover — only triggers without optional dep
        raise ImportError(
            "AgentOSCallbackHandler requires `langchain-core`. "
            "Install with: pip install agentos-sdk[langchain]"
        ) from exc
    return BaseCallbackHandler


_Base = _import_base()


class AgentOSCallbackHandler(_Base):  # type: ignore[misc, valid-type]
    """LangChain callback handler that mirrors a chain/LLM/tool run into AgentOS.

    Pass an instance to any LangChain primitive's ``callbacks=`` parameter.
    """

    name = "agentos-handler"

    def __init__(self, run: "Run") -> None:
        super().__init__()
        self.run = run
        self._tasks: dict[str, "Task"] = {}

    # ── LLMs ──────────────────────────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        **kwargs: Any,  # noqa: ARG002 — LangChain passes extras we don't need
    ) -> None:
        model = serialized.get("name") or (serialized.get("id") or ["unknown"])[-1]
        self.run.emit_llm_request(str(model), "\n---\n".join(prompts))

    def on_llm_end(self, response: Any, **_: Any) -> None:
        # LLMResult has .generations: list[list[Generation]] and .llm_output: dict | None
        try:
            generations = response.generations
            text = generations[0][0].text if generations and generations[0] else ""
        except (AttributeError, IndexError):
            text = ""
        usage = {}
        try:
            llm_output = response.llm_output or {}
            token_usage = llm_output.get("token_usage", {}) if isinstance(llm_output, dict) else {}
            input_tokens = token_usage.get("prompt_tokens")
            output_tokens = token_usage.get("completion_tokens")
            if input_tokens is not None:
                usage["input_tokens"] = input_tokens
            if output_tokens is not None:
                usage["output_tokens"] = output_tokens
        except AttributeError:
            pass
        self.run.emit_llm_response("llm", text, usage if usage else None)

    def on_llm_error(self, error: BaseException, **_: Any) -> None:
        self.run.emit("llm.failed", {"error": str(error)}, level="error")

    # ── Tools ─────────────────────────────────────────────────────────────

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        **_: Any,
    ) -> None:
        name = serialized.get("name") or "tool"
        self.run.emit_tool_call(name, {"input": input_str})

    def on_tool_end(self, output: str, **_: Any) -> None:
        # LangChain doesn't pass the tool name on End; emit a generic returned event.
        self.run.emit_tool_return("tool", {"output": output})

    def on_tool_error(self, error: BaseException, **_: Any) -> None:
        self.run.emit_tool_error("tool", str(error))

    # ── Chains ────────────────────────────────────────────────────────────

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        **_: Any,
    ) -> None:
        name = serialized.get("name") or "chain"
        task = self.run.start_task(name, inputs)
        self._tasks[str(run_id)] = task

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        **_: Any,
    ) -> None:
        task = self._tasks.pop(str(run_id), None)
        if task is not None:
            task.complete(output=outputs)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **_: Any,
    ) -> None:
        task = self._tasks.pop(str(run_id), None)
        if task is not None:
            task.fail(error_message=str(error))
        else:
            self.run.emit("chain.failed", {"error": str(error)}, level="error")
