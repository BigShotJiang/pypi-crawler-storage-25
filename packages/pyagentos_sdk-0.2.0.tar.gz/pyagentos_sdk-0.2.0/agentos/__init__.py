"""AgentOS Python SDK — v0.2.

Mirrors the TypeScript SDK API surface. See agentos-specs/05-sdk-spec.md.
"""

from .client import AgentOS
from .errors import (
    AgentOSAuthError,
    AgentOSError,
    AgentOSRateLimitError,
    AgentOSValidationError,
)
from .run import Run, Task

__version__ = "0.2.0"

__all__ = [
    "AgentOS",
    "AgentOSError",
    "AgentOSAuthError",
    "AgentOSValidationError",
    "AgentOSRateLimitError",
    "Run",
    "Task",
    "__version__",
]
