"""Test suite for rootcoz."""
