from collections.abc import Callable as Callable
from dataclasses import dataclass
from typing import Any

from .connection import Connection as Connection
from .exception import (
    NodeAlreadyInGraphError as NodeAlreadyInGraphError,
)
from .exception import (
    NodeNotFoundError as NodeNotFoundError,
)
from .node import (
    Node as Node,
)
from .node import (
    NodeIsOffline as NodeIsOffline,
)
from .node import (
    NodeIsOnline as NodeIsOnline,
)

@dataclass
class Graph:
    is_directed: bool = ...
    nodes: set[Node] = ...
    data: Any = ...
    def add(self, node: Node) -> Node: ...
    def internal_add_node(self, node: Node) -> None: ...
    def connect(
        self, source: Node, connection: Connection, destination: Node
    ) -> Graph: ...
    def get_by_id(self, node_id: str) -> Node: ...
    def get_by_class(self, class_: type[Node]) -> set[Node]: ...
    def get_by_data(
        self, filter_: Callable[[Any], bool]
    ) -> set[Node]: ...
    def delete(self, node_id: str) -> Node: ...
    def internal_delete_node(self, node: Node) -> None: ...
