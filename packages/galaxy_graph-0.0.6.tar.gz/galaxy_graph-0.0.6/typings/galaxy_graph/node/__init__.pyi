from dataclasses import dataclass
from typing import Any

from galaxy_graph.connection import Connection

from .online import (
    NodeIsOffline as NodeIsOffline,
)
from .online import (
    NodeIsOnline as NodeIsOnline,
)
from .online import (
    NodeOnlineState as NodeOnlineState,
)
from .state import NodeState as NodeState

__all__ = [
    "Node",
    "NodeIsOffline",
    "NodeIsOnline",
    "NodeOnlineState",
    "NodeState",
]

@dataclass
class Node:
    identifier: str = ...
    data: Any = ...
    state: NodeState = ...
    def __post_init__(self) -> None: ...
    def connect(
        self, connection: Connection, destination: Node
    ) -> Connection: ...
    def __eq__(self, value: object) -> bool: ...
    def __hash__(self) -> int: ...
