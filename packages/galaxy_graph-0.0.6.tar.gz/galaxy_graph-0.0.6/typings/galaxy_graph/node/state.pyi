from dataclasses import dataclass

from . import Node as Node
from .online import (
    NodeIsOffline as NodeIsOffline,
)
from .online import (
    NodeOnlineState as NodeOnlineState,
)

@dataclass
class NodeState:
    node: Node
    online: NodeOnlineState = ...
    def __post_init__(self) -> None: ...
    def is_online(self) -> bool: ...
