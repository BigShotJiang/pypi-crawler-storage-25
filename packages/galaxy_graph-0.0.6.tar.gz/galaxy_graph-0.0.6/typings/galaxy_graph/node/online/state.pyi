from dataclasses import dataclass

from galaxy_graph.node.state import NodeState as NodeState

@dataclass
class NodeOnlineState:
    state: NodeState
    def is_online(self) -> bool: ...
