from collections.abc import Callable as Callable
from dataclasses import dataclass
from typing import Any

from galaxy_graph.connection import Connection as Connection
from galaxy_graph.exception import (
    ConnectionAlreadyInNodeError as ConnectionAlreadyInNodeError,
)
from galaxy_graph.exception import (
    ConnectionAlreadySetupError as ConnectionAlreadySetupError,
)
from galaxy_graph.graph import Graph as Graph
from galaxy_graph.node import Node as Node

from .state import NodeOnlineState as NodeOnlineState

@dataclass
class NodeIsOnline(NodeOnlineState):
    graph: Graph
    connections: set[Connection] = ...
    def detach(self) -> Node: ...
    def connect(
        self, connection: Connection, destination: Node
    ) -> Connection: ...
    def get_neighbors_by_connection_data(
        self, filter_: Callable[[Any], bool]
    ) -> set[Node]: ...
    def get_neighbors_by_connection_type(
        self, type_: type[Connection]
    ) -> set[Node]: ...
    def get_neighbors_by_node_data(
        self, filter_: Callable[[Any], bool]
    ) -> set[Node]: ...
    def get_neighbors_by_node_type(
        self, type_: type[Node]
    ) -> set[Node]: ...
    def is_online(self) -> bool: ...
