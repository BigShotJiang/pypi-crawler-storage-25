from dataclasses import dataclass

from galaxy_graph.graph import Graph as Graph
from galaxy_graph.node import Node as Node

from .state import NodeOnlineState as NodeOnlineState

@dataclass
class NodeIsOffline(NodeOnlineState):
    def attach(self, graph: Graph) -> Node: ...
    def is_online(self) -> bool: ...
