from dataclasses import dataclass

from galaxy_graph.connection import Connection as Connection
from galaxy_graph.node import Node as Node

from .state import ConnectionSetupState as ConnectionSetupState
from .yes import ConnectionSetup as ConnectionSetup

@dataclass
class ConnectionNotSetup(ConnectionSetupState):
    def setup(self, source: Node, destination: Node) -> Connection: ...
    def is_setup(self) -> bool: ...
