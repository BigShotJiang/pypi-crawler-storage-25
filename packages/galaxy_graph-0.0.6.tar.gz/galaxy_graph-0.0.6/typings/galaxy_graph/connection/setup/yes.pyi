from dataclasses import dataclass

from galaxy_graph.node import Node as Node

from .state import ConnectionSetupState as ConnectionSetupState

@dataclass
class ConnectionSetup(ConnectionSetupState):
    source: Node
    destination: Node
    def is_setup(self) -> bool: ...
