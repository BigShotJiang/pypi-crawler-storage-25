from dataclasses import dataclass

from galaxy_graph.connection.state import (
    ConnectionState as ConnectionState,
)

@dataclass
class ConnectionSetupState:
    state: ConnectionState
    def is_setup(self) -> bool: ...
