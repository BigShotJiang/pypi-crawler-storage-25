from dataclasses import dataclass

from galaxy_graph.connection.setup import (
    ConnectionNotSetup as ConnectionNotSetup,
)
from galaxy_graph.connection.setup import (
    ConnectionSetupState as ConnectionSetupState,
)

from . import Connection as Connection

@dataclass
class ConnectionState:
    connection: Connection
    setup: ConnectionSetupState = ...
    def __post_init__(self) -> None: ...
    def is_setup(self) -> bool: ...
