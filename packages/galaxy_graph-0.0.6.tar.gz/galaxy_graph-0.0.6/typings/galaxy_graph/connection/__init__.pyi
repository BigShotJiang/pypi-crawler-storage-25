from dataclasses import dataclass
from typing import Any

from galaxy_graph.connection.setup import (
    ConnectionNotSetup as ConnectionNotSetup,
)
from galaxy_graph.connection.setup import (
    ConnectionSetup as ConnectionSetup,
)
from galaxy_graph.connection.setup import (
    ConnectionSetupState as ConnectionSetupState,
)

from .state import ConnectionState as ConnectionState

__all__ = [
    "Connection",
    "ConnectionNotSetup",
    "ConnectionSetup",
    "ConnectionSetupState",
    "ConnectionState",
]

@dataclass
class Connection:
    data: Any = ...
    identifier: str = ...
    state: ConnectionState = ...
    def __post_init__(self) -> None: ...
    def __eq__(self, value: object) -> bool: ...
    def __hash__(self) -> int: ...
