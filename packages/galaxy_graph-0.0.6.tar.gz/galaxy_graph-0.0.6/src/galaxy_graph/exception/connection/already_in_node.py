"""ConnectionAlreadyInNodeError class container."""


class ConnectionAlreadyInNodeError(Exception):
    """The connection is already in the node."""

    def __init__(self, identifier: str) -> None:
        """
        Error initialization.

        Parameters
        ----------
        identifier: str
            Connection identifier

        """
        super().__init__(f"Connection {identifier} already in the node")
