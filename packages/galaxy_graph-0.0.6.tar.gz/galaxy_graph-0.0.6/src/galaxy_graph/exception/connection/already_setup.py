"""ConnectionAlreadySetupError class container."""


class ConnectionAlreadySetupError(Exception):
    """The connection is already setup."""

    def __init__(self, identifier: str) -> None:
        """
        Error initialization.

        Parameters
        ----------
        identifier: str
            Connection identifier

        """
        super().__init__(f"Connection {identifier} already setup.")
