"""Exception concerning Connection."""

from .already_in_node import ConnectionAlreadyInNodeError
from .already_setup import ConnectionAlreadySetupError

__all__ = [
    "ConnectionAlreadyInNodeError",
    "ConnectionAlreadySetupError",
]
