"""NodeOfflineError class container."""


class NodeOfflineError(Exception):
    """Node is not online."""

    def __init__(self, identifier: str) -> None:
        """
        Error initialization.

        Parameters
        ----------
        identifier: str
            Node identifier

        """
        super().__init__(f"Node {identifier} is offline")
