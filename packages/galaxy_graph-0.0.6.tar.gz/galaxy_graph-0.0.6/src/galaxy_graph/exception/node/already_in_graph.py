"""NodeAlreadyInGraph class container."""


class NodeAlreadyInGraphError(Exception):
    """Node already in graph."""

    def __init__(self, identifier: str) -> None:
        """
        Error initialization.

        Parameters
        ----------
        identifier: str
            Node identifier

        """
        super().__init__(f"Node {identifier} already in graph")
