"""NodeNotFoundError class container."""


class NodeNotFoundError(Exception):
    """Node not found."""

    def __init__(self, identifier: str) -> None:
        """
        Error initialization.

        Parameters
        ----------
        identifier: str
            Node identifier

        """
        super().__init__(f"Node {identifier} not found")
