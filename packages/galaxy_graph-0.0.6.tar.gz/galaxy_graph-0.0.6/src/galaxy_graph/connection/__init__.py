"""Sub-module that contains behavior and state about Connection."""

from dataclasses import dataclass, field
from typing import Any
from uuid import uuid4

from .setup import (
    ConnectionNotSetup,
    ConnectionSetup,
    ConnectionSetupState,
)
from .state import ConnectionState


@dataclass
class Connection:
    """Connection between two nodes from the same graph."""

    data: Any = None  # Data associated to this connection
    identifier: str = field(default_factory=lambda: str(uuid4()))

    state: ConnectionState = field(init=False)

    def __post_init__(self) -> None:
        """ConnectionState needs self to initialize."""
        self.state = ConnectionState(connection=self)

    def __eq__(self, value: object, /) -> bool:
        """Check equality."""
        if not isinstance(value, Connection):
            message = f"{value} is not a Connection"
            raise TypeError(message)
        return self.identifier == value.identifier

    def __hash__(self) -> int:
        """For built-in function hash()."""
        return hash(self.identifier)


__all__ = [
    "Connection",
    "ConnectionNotSetup",
    "ConnectionSetup",
    "ConnectionSetupState",
    "ConnectionState",
]
