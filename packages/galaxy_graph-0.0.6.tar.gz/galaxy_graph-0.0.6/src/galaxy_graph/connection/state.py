"""ConnectionState class container."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .setup import ConnectionNotSetup, ConnectionSetupState

if TYPE_CHECKING:
    from . import Connection


@dataclass
class ConnectionState:
    """States of the connection that modify the Connection behavior."""

    connection: Connection
    setup: ConnectionSetupState = field(init=False)

    def __post_init__(self) -> None:
        """ConnectionNotSetup needs self to initialize."""
        self.setup = ConnectionNotSetup(state=self)

    def is_setup(self) -> bool:
        """Check if the Connection is associated to Nodes."""
        return self.setup.is_setup()
