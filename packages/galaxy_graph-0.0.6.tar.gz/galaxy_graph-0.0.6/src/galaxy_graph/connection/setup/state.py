"""ConnectionSetupState class container."""

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from galaxy_graph.connection.state import ConnectionState


@dataclass
class ConnectionSetupState:
    """
    Information if the Connection is already setup.

    If the connection is setup, it has a source and a destination and
    cannot be updated anymore.
    """

    state: ConnectionState

    def is_setup(self) -> bool:
        """Check if the Connection is associated to Nodes."""
        raise NotImplementedError(
            "Use ConnectionSetup or ConnectionNotSetup state."
        )
