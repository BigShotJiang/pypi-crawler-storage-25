"""ConnectionNotSetup class container."""

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .state import ConnectionSetupState
from .yes import ConnectionSetup

if TYPE_CHECKING:
    from galaxy_graph.connection import Connection
    from galaxy_graph.node import Node


@dataclass
class ConnectionNotSetup(ConnectionSetupState):
    """The Connection is not setup yet."""

    def setup(self, source: Node, destination: Node) -> Connection:
        """
        Associate this Connection to two Nodes.

        Parameters
        ----------
        source: Node
            First node of the connection (its source).
        destination: Node
            Last node of the connection (pointing of the arrow).

        """
        connection = self.state.connection
        connection.state.setup = ConnectionSetup(
            state=connection.state,
            source=source,
            destination=destination,
        )
        return connection

    def is_setup(self) -> bool:
        """Check if the Connection is associated to Nodes."""
        return False
