"""ConnectionSetup class container."""

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .state import ConnectionSetupState

if TYPE_CHECKING:
    from galaxy_graph.node import Node


@dataclass
class ConnectionSetup(ConnectionSetupState):
    """The Connection is setup."""

    source: Node
    destination: Node

    def is_setup(self) -> bool:
        """Check if the Connection is associated to Nodes."""
        return True
