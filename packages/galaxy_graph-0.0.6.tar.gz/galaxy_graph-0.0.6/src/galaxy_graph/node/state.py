"""NodeState class container."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .online import NodeIsOffline

if TYPE_CHECKING:
    from . import Node
    from .online import NodeOnlineState


@dataclass
class NodeState:
    """States of the node that modify the Node behavior."""

    node: Node
    online: NodeOnlineState = field(init=False)

    def __post_init__(self) -> None:
        """NodeIsOffline needs self to initialize."""
        self.online = NodeIsOffline(state=self)

    def is_online(self) -> bool:
        """Check if the Node is associated to a Graph."""
        return self.online.is_online()
