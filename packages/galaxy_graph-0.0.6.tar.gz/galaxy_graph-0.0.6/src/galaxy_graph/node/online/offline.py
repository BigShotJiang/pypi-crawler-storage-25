"""NodeIsOffline class container."""

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .state import NodeOnlineState

if TYPE_CHECKING:
    from galaxy_graph.graph import Graph
    from galaxy_graph.node import Node


@dataclass
class NodeIsOffline(NodeOnlineState):
    """The Node is not in a Graph."""

    def attach(self, graph: Graph) -> Node:
        """Attach the Node to a Graph."""
        from .online import NodeIsOnline  # noqa: PLC0415

        node = self.state.node
        graph.internal_add_node(node=node)
        node.state.online = NodeIsOnline(state=node.state, graph=graph)
        return node

    def is_online(self) -> bool:
        """Check if the Node is associated to a Graph."""
        return False
