"""NodeOnlineState class container."""

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from galaxy_graph.node.state import NodeState


@dataclass
class NodeOnlineState:
    """Information if the Node is in a Graph."""

    state: NodeState  # state holder

    def is_online(self) -> bool:
        """Check if the Node is associated to a Graph."""
        raise NotImplementedError(
            "Use NodeIsOnline or NodeIsOffline state."
        )
