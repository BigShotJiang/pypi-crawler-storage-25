"""Sub-module that contains behavior and state about Node."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from galaxy_graph.exception import NodeOfflineError

from .online import NodeIsOffline, NodeIsOnline, NodeOnlineState
from .state import NodeState

if TYPE_CHECKING:
    from galaxy_graph.connection import Connection


@dataclass
class Node:
    """
    Singular element storing data.

    Can be connected to other node and be a part of a Graph.
    """

    identifier: str = field(
        default_factory=lambda: str(uuid4())
    )  # unique identifier
    data: Any = None  # Data associated to this node

    state: NodeState = field(
        init=False
    )  # state of this node that change behaviors

    def __post_init__(self) -> None:
        """NodeState needs self to initialize."""
        self.state = NodeState(node=self)

    def connect(
        self, connection: Connection, destination: Node
    ) -> Connection:
        """
        Connect this node to another one with a specific connection.

        If the graph of the node is not directed, the other node will
        have the same connection.

        Notes
        -----
        This should be used on Node that are online !

        Parameters
        ----------
        connection: Connection
            Connection not already connected to nodes.
        destination: Node
            Node already in the Graph or not.

        Raises
        ------
        NodeOfflineError
            If the Node is not in a graph.

        """
        online_state = self.state.online
        if not isinstance(online_state, NodeIsOnline):
            raise NodeOfflineError(self.identifier)

        return online_state.connect(
            connection=connection, destination=destination
        )

    def __eq__(self, value: object, /) -> bool:
        """Check equality."""
        if not isinstance(value, Node):
            message = f"{value} is not a Node"
            raise TypeError(message)
        return self.identifier == value.identifier

    def __hash__(self) -> int:
        """For built-in function hash()."""
        return hash(self.identifier)


__all__ = [
    "Node",
    "NodeIsOffline",
    "NodeIsOnline",
    "NodeOnlineState",
    "NodeState",
]
