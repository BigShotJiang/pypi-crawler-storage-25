"""Graph class container."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .exception import NodeAlreadyInGraphError, NodeNotFoundError
from .node import NodeIsOffline, NodeIsOnline

if TYPE_CHECKING:
    from collections.abc import Callable

    from .connection import Connection
    from .node import Node


@dataclass
class Graph:
    """Set of nodes."""

    is_directed: bool = (
        True  # If false, connections will be shared by both nodes
    )
    nodes: set[Node] = field(default_factory=set)  # Nodes in this graph
    data: Any = None  # Data attached to this graph

    def add(self, node: Node) -> Node:
        """Add an offline Node to this Graph."""
        if node.state.is_online():
            raise NodeAlreadyInGraphError(node.identifier)

        online_state = node.state.online
        if not isinstance(online_state, NodeIsOffline):
            raise TypeError
        online_state.attach(graph=self)

        return node

    def internal_add_node(self, node: Node) -> None:
        """
        Add a node to the graph.

        Internal use only.
        """
        if node.state.is_online():
            raise NodeAlreadyInGraphError(node.identifier)

        try:
            self.get_by_id(node.identifier)
            raise NodeAlreadyInGraphError(node.identifier)
        except NodeNotFoundError:
            pass

        self.nodes.add(node)

    def connect(
        self, source: Node, connection: Connection, destination: Node
    ) -> Graph:
        """
        Add two node with a connection quickly.

        The two created node and connection will be added to the graph.
        If the graph of the node is not directed, each node will have
        the same connection.

        Parameters
        ----------
        source: Node
            First node of the connection. If graph is directed, origin
            of the arrow
        connection: Connection
            Connection linking the first and the second node. This
            connection must not have been already used in another link.
        destination: Node
            Last node of the connection. If graph is directed, pointing
            of the arrow.

        """
        if source.state.is_online():
            # checks if the node is in this Graph
            _ = self.get_by_id(source.identifier)
        else:
            online_state = source.state.online
            if not isinstance(online_state, NodeIsOffline):
                raise TypeError
            online_state.attach(graph=self)

        online_state = source.state.online
        if not isinstance(online_state, NodeIsOnline):
            raise TypeError
        online_state.connect(
            connection=connection, destination=destination
        )

        return self

    def get_by_id(self, node_id: str) -> Node:
        """Get a node from its node identifier."""
        for node in self.nodes:
            if node.identifier == node_id:
                return node
        raise NodeNotFoundError(node_id)

    def get_by_class(self, class_: type[Node]) -> set[Node]:
        """Get all node of a given class."""
        return {node for node in self.nodes if isinstance(node, class_)}

    def get_by_data(self, filter_: Callable[[Any], bool]) -> set[Node]:
        """
        Get all node of the graph respecting a condition on its data.

        Return every nodes for which applying the node's data to filter
        return True.
        """
        return {node for node in self.nodes if filter_(node.data)}

    def delete(self, node_id: str) -> Node:
        """Delete a node and all of its connections."""
        node = self.get_by_id(node_id=node_id)

        online_state = node.state.online
        if not isinstance(online_state, NodeIsOnline):
            raise TypeError
        online_state.detach()

        return node

    def internal_delete_node(self, node: Node) -> None:
        """
        Delete a node and all of its connections to other nodes.

        Internal use only.
        """
        if not node.state.is_online():
            raise NodeNotFoundError(node.identifier)
        # Checks if the node is in this graph
        _ = self.get_by_id(node_id=node.identifier)

        self.nodes = {
            temp_node
            for temp_node in self.nodes
            if temp_node.identifier != node.identifier
        }
        for temp_node in self.nodes:
            temp_node.state.online.connections = {  # ty: ignore [unresolved-attribute]
                connection
                for connection in temp_node.state.online.connections  # ty: ignore [unresolved-attribute]
                if connection.state.setup.destination.identifier
                != node.identifier
            }
