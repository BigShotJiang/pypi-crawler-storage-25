import pandas as pd

from .amazon_ads_reporting_api import create_ads_report, fetch_ads_report

# ---------------------------------------------------------------------------
# spAdvertisedProduct
# ---------------------------------------------------------------------------

SP_ADVERTISED_PRODUCT_COLUMNS = [
    'acosClicks14d',
    'acosClicks7d',
    'adGroupId',
    'adGroupName',
    'adId',
    'advertisedAsin',
    'advertisedSku',
    'attributedSalesSameSku14d',
    'attributedSalesSameSku1d',
    'attributedSalesSameSku30d',
    'attributedSalesSameSku7d',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clickThroughRate',
    'clicks',
    'cost',
    'costPerClick',
    'date',
    'impressions',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'portfolioId',
    'purchases14d',
    'purchases1d',
    'purchases30d',
    'purchases7d',
    'purchasesSameSku14d',
    'purchasesSameSku1d',
    'purchasesSameSku30d',
    'purchasesSameSku7d',
    'roasClicks14d',
    'roasClicks7d',
    'sales14d',
    'sales1d',
    'sales30d',
    'sales7d',
    'salesOtherSku7d',
    'spend',
    'unitsSoldClicks14d',
    'unitsSoldClicks1d',
    'unitsSoldClicks30d',
    'unitsSoldClicks7d',
    'unitsSoldOtherSku7d',
    'unitsSoldSameSku14d',
    'unitsSoldSameSku1d',
    'unitsSoldSameSku30d',
    'unitsSoldSameSku7d',
]

_SP_ADV_STR_COLS = {
    'adGroupId', 'adGroupName', 'adId', 'advertisedAsin', 'advertisedSku',
    'campaignBudgetCurrencyCode', 'campaignBudgetType', 'campaignId',
    'campaignName', 'campaignStatus', 'portfolioId',
}


def process_sp_advertised_product(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    df['date'] = pd.to_datetime(df.get('date'), errors='coerce')

    for col in df.columns:
        if col == 'date':
            continue
        if col in _SP_ADV_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


SP_ADVERTISED_FILTER = [
    {'field': 'adCreativeStatus', 'values': ['ENABLED', 'PAUSED', 'ARCHIVED']}
]


def get_sp_advertised_product_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an spAdvertisedProduct daily report.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default)
    - filters       : defaults to adCreativeStatus (all) — campaignStatus is invalid for groupBy advertiser

    Returns:
    - DataFrame with one row per advertised product per day
    """
    if filters is None:
        filters = SP_ADVERTISED_FILTER

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='spAdvertisedProduct',
        ad_product='SPONSORED_PRODUCTS',
        start_date=start_date,
        end_date=end_date,
        columns=SP_ADVERTISED_PRODUCT_COLUMNS,
        group_by=['advertiser'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_advertised_product(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sdAdvertisedProduct
# ---------------------------------------------------------------------------

SD_ADVERTISED_PRODUCT_COLUMNS = [
    'adGroupId',
    'adGroupName',
    'adId',
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToCartViews',
    'bidOptimization',
    'brandedSearchRate',
    'brandedSearches',
    'brandedSearchesClicks',
    'brandedSearchesViews',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'clicks',
    'cost',
    'cumulativeReach',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'eCPBrandSearch',
    'impressions',
    'impressionsFrequencyAverage',
    'impressionsViews',
    'newToBrandDetailPageViewClicks',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViewViews',
    'newToBrandDetailPageViews',
    'newToBrandECPDetailPageView',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'promotedAsin',
    'promotedSku',
    'purchases',
    'purchasesClicks',
    'purchasesPromotedClicks',
    'sales',
    'salesClicks',
    'salesPromotedClicks',
    'unitsSold',
    'unitsSoldClicks',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewClickThroughRate',
    'viewabilityRate',
]

_SD_ADV_STR_COLS = {
    'adGroupId', 'adGroupName', 'adId', 'bidOptimization',
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'promotedAsin', 'promotedSku',
}


def process_sd_advertised_product(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    df['date'] = pd.to_datetime(df.get('date'), errors='coerce')

    for col in df.columns:
        if col == 'date':
            continue
        if col in _SD_ADV_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sd_advertised_product_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an sdAdvertisedProduct daily report.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID (one per marketplace — call separately for NA/EU)
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default)
    - filters       : N/A — sdAdvertisedProduct does not support filters

    Returns:
    - DataFrame with one row per advertised product per day
    """
    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sdAdvertisedProduct',
        ad_product='SPONSORED_DISPLAY',
        start_date=start_date,
        end_date=end_date,
        columns=SD_ADVERTISED_PRODUCT_COLUMNS,
        group_by=['advertiser'],
        time_unit=time_unit,
        filters=[],  # sdAdvertisedProduct does not support filters
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_advertised_product(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# spPurchasedProduct
# ---------------------------------------------------------------------------

SP_PURCHASED_PRODUCT_COLUMNS = [
    'adGroupId',
    'adGroupName',
    'advertisedAsin',
    'advertisedSku',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'date',
    'keyword',
    'keywordId',
    'keywordType',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'matchType',
    'portfolioId',
    'purchasedAsin',
    'purchases14d',
    'purchases1d',
    'purchases30d',
    'purchases7d',
    'purchasesOtherSku14d',
    'purchasesOtherSku1d',
    'purchasesOtherSku30d',
    'purchasesOtherSku7d',
    'sales14d',
    'sales1d',
    'sales30d',
    'sales7d',
    'salesOtherSku14d',
    'salesOtherSku1d',
    'salesOtherSku30d',
    'salesOtherSku7d',
    'unitsSoldClicks14d',
    'unitsSoldClicks1d',
    'unitsSoldClicks30d',
    'unitsSoldClicks7d',
    'unitsSoldOtherSku14d',
    'unitsSoldOtherSku1d',
    'unitsSoldOtherSku30d',
    'unitsSoldOtherSku7d',
]

# Default filter for purchased product — by keyword type
SP_PURCHASED_PRODUCT_FILTER = [
    {
        'field': 'keywordType',
        'values': [
            'BROAD',
            'EXACT',
            'PHRASE',
            'TARGETING_EXPRESSION',
            'TARGETING_EXPRESSION_PREDEFINED',
        ],
    }
]

_SP_PURCH_STR_COLS = {
    'adGroupId', 'adGroupName', 'advertisedAsin', 'advertisedSku',
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'keyword', 'keywordId', 'keywordType', 'matchType', 'portfolioId',
    'purchasedAsin',
}


def process_sp_purchased_product(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    df['date'] = pd.to_datetime(df.get('date'), errors='coerce')

    for col in df.columns:
        if col == 'date':
            continue
        if col in _SP_PURCH_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sp_purchased_product_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an spPurchasedProduct daily report.
    Groups by ASIN — shows attributed purchases/sales per purchased ASIN.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID (one per marketplace)
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default)
    - filters       : defaults to SP_PURCHASED_PRODUCT_FILTER (all keyword types)

    Returns:
    - DataFrame with one row per purchased ASIN per day
    """
    if filters is None:
        filters = SP_PURCHASED_PRODUCT_FILTER

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='spPurchasedProduct',
        ad_product='SPONSORED_PRODUCTS',
        start_date=start_date,
        end_date=end_date,
        columns=SP_PURCHASED_PRODUCT_COLUMNS,
        group_by=['asin'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_purchased_product(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sbPurchasedProduct
# ---------------------------------------------------------------------------

SB_PURCHASED_PRODUCT_COLUMNS = [
    'adGroupId',
    'adGroupName',
    'attributionType',
    'budgetCurrency',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'date',
    'newToBrandOrders14d',
    'newToBrandOrdersPercentage14d',
    'newToBrandPurchases14d',
    'newToBrandPurchasesPercentage14d',
    'newToBrandSales14d',
    'newToBrandSalesPercentage14d',
    'newToBrandUnitsSold14d',
    'newToBrandUnitsSoldPercentage14d',
    'orders14d',
    'productCategory',
    'productName',
    'purchasedAsin',
    'sales14d',
    'unitsSold14d',
]

_SB_PURCH_STR_COLS = {
    'adGroupId', 'adGroupName', 'attributionType', 'budgetCurrency',
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'productCategory', 'productName', 'purchasedAsin',
}


def process_sb_purchased_product(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    df['date'] = pd.to_datetime(df.get('date'), errors='coerce')

    for col in df.columns:
        if col == 'date':
            continue
        if col in _SB_PURCH_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sb_purchased_product_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
):
    """
    Requests, downloads, and processes an sbPurchasedProduct daily report.
    Groups by purchasedAsin — attributed purchases/sales by ASIN for SB campaigns.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID (one per marketplace)
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default)

    Note: sbPurchasedProduct does not support filters — API rejects any filter.
    """
    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sbPurchasedProduct',
        ad_product='SPONSORED_BRANDS',
        start_date=start_date,
        end_date=end_date,
        columns=SB_PURCHASED_PRODUCT_COLUMNS,
        group_by=['purchasedAsin'],
        time_unit=time_unit,
        filters=[],  # sbPurchasedProduct does not support filters
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_purchased_product(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sdPurchasedProduct
# ---------------------------------------------------------------------------

SD_PURCHASED_PRODUCT_COLUMNS = [
    'adGroupId',
    'adGroupName',
    'asinBrandHalo',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'conversionsBrandHalo',
    'conversionsBrandHaloClicks',
    'date',
    'promotedAsin',
    'promotedSku',
    'salesBrandHalo',
    'salesBrandHaloClicks',
    'unitsSoldBrandHalo',
    'unitsSoldBrandHaloClicks',
]

_SD_PURCH_STR_COLS = {
    'adGroupId', 'adGroupName', 'asinBrandHalo',
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'promotedAsin', 'promotedSku',
}


def process_sd_purchased_product(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    df['date'] = pd.to_datetime(df.get('date'), errors='coerce')

    for col in df.columns:
        if col == 'date':
            continue
        if col in _SD_PURCH_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sd_purchased_product_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an sdPurchasedProduct daily report.
    Groups by ASIN — brand halo conversions/sales attributed to SD campaigns.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID (one per marketplace)
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default)
    - filters       : list of filter dicts — defaults to all campaign statuses

    Returns:
    - DataFrame with one row per purchased ASIN per day
    """
    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sdPurchasedProduct',
        ad_product='SPONSORED_DISPLAY',
        start_date=start_date,
        end_date=end_date,
        columns=SD_PURCHASED_PRODUCT_COLUMNS,
        group_by=['asin'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_purchased_product(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# spTargeting — single call, all keyword types
# DAILY default. TARGETING_EXPRESSION rows have 'targeting'; keyword rows have 'keyword'.
# ---------------------------------------------------------------------------

# DAILY columns — includes both 'targeting' and 'keyword'/'keywordBid' (nulls for inapplicable rows)
SP_TARGETING_COLUMNS = [
    'acosClicks14d',
    'acosClicks7d',
    'adGroupId',
    'adGroupName',
    'adKeywordStatus',
    'attributedSalesSameSku14d',
    'attributedSalesSameSku1d',
    'attributedSalesSameSku30d',
    'attributedSalesSameSku7d',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clickThroughRate',
    'clicks',
    'cost',
    'costPerClick',
    'date',
    'impressions',
    'keyword',
    'keywordBid',
    'keywordId',
    'keywordType',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'matchType',
    'portfolioId',
    'purchases14d',
    'purchases1d',
    'purchases30d',
    'purchases7d',
    'purchasesSameSku14d',
    'purchasesSameSku1d',
    'purchasesSameSku30d',
    'purchasesSameSku7d',
    'roasClicks14d',
    'roasClicks7d',
    'sales14d',
    'sales1d',
    'sales30d',
    'sales7d',
    'salesOtherSku7d',
    'targeting',
    'unitsSoldClicks14d',
    'unitsSoldClicks1d',
    'unitsSoldClicks30d',
    'unitsSoldClicks7d',
    'unitsSoldOtherSku7d',
    'unitsSoldSameSku14d',
    'unitsSoldSameSku1d',
    'unitsSoldSameSku30d',
    'unitsSoldSameSku7d',
]

# SUMMARY columns — swap 'date' for 'startDate'/'endDate'
SP_TARGETING_SUMMARY_COLUMNS = [c for c in SP_TARGETING_COLUMNS if c != 'date'] + ['startDate', 'endDate']

# All keyword types + all statuses in one filter
SP_TARGETING_FILTER = [
    {
        'field': 'keywordType',
        'values': ['BROAD', 'PHRASE', 'EXACT', 'TARGETING_EXPRESSION', 'TARGETING_EXPRESSION_PREDEFINED'],
    },
    {
        'field': 'adKeywordStatus',
        'values': ['ARCHIVED', 'ENABLED', 'PAUSED'],
    },
]

_SP_TARG_ALL_DATE_COLS = {'date', 'startDate', 'endDate'}

_SP_TARG_STR_COLS = {
    'adGroupId', 'adGroupName', 'adKeywordStatus',
    'campaignBudgetCurrencyCode', 'campaignBudgetType', 'campaignId',
    'campaignName', 'campaignStatus', 'keyword', 'keywordId', 'keywordType',
    'matchType', 'portfolioId', 'targeting',
}


def process_sp_targeting(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SP_TARG_ALL_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SP_TARG_ALL_DATE_COLS:
            continue
        if col in _SP_TARG_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sp_targeting_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an spTargeting report — all keyword types in one call.
    TARGETING_EXPRESSION rows populate 'targeting'; BROAD/EXACT/PHRASE rows populate 'keyword'/'keywordBid'.
    Inapplicable columns will be null — perfectly queryable in BQ with WHERE keywordType = ...

    Parameters:
    - time_unit : 'DAILY' (default) → 'date' col | 'SUMMARY' → 'startDate'/'endDate' cols
    - filters   : defaults to SP_TARGETING_FILTER (all keyword types + all statuses)
    """
    if filters is None:
        filters = SP_TARGETING_FILTER

    cols = SP_TARGETING_COLUMNS if time_unit == 'DAILY' else SP_TARGETING_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='spTargeting',
        ad_product='SPONSORED_PRODUCTS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['targeting'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_targeting(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sbTargeting — single call, all keyword types (incl. THEME)
# TARGETING_EXPRESSION rows → targeting* cols; keyword rows → keyword* cols
# ---------------------------------------------------------------------------

SB_TARGETING_COLUMNS = [
    'adGroupId',
    'adGroupName',
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'brandedSearches',
    'brandedSearchesClicks',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clicks',
    'cost',
    'costType',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'impressions',
    'keywordBid',
    'keywordId',
    'adKeywordStatus',
    'keywordText',
    'keywordType',
    'matchType',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViews',
    'newToBrandDetailPageViewsClicks',
    'newToBrandECPDetailPageView',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandPurchasesPercentage',
    'newToBrandPurchasesRate',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandSalesPercentage',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'newToBrandUnitsSoldPercentage',
    'purchases',
    'purchasesClicks',
    'purchasesPromoted',
    'sales',
    'salesClicks',
    'salesPromoted',
    'targetingExpression',
    'targetingId',
    'targetingText',
    'targetingType',
    'topOfSearchImpressionShare',
    'unitsSold',
    'unitsSoldClicks',
    'video5SecondViewRate',
    'video5SecondViews',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewClickThroughRate',
    'viewabilityRate',
    'viewableImpressions',
]

SB_TARGETING_FILTER = [
    {
        'field': 'adKeywordStatus',
        'values': ['ARCHIVED', 'ENABLED', 'PAUSED'],
    },
    {
        'field': 'keywordType',
        'values': ['BROAD', 'PHRASE', 'EXACT', 'TARGETING_EXPRESSION', 'TARGETING_EXPRESSION_PREDEFINED', 'THEME'],
    },
]

_SB_TARG_DATE_COLS = {'date', 'startDate', 'endDate'}

_SB_TARG_STR_COLS = {
    'adGroupId', 'adGroupName', 'campaignBudgetCurrencyCode', 'campaignBudgetType',
    'campaignId', 'campaignName', 'campaignStatus', 'costType', 'matchType',
    'keywordId', 'adKeywordStatus', 'keywordText', 'keywordType',
    'targetingExpression', 'targetingId', 'targetingText', 'targetingType',
}


def process_sb_targeting(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SB_TARG_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SB_TARG_DATE_COLS:
            continue
        if col in _SB_TARG_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sb_targeting_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an sbTargeting report — all keyword types in one call.
    TARGETING_EXPRESSION rows populate targeting* cols; keyword rows populate keyword* cols.
    Includes THEME keywordType (SB-only).

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to SB_TARGETING_FILTER (all types + all statuses)
    """
    if filters is None:
        filters = SB_TARGETING_FILTER

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sbTargeting',
        ad_product='SPONSORED_BRANDS',
        start_date=start_date,
        end_date=end_date,
        columns=SB_TARGETING_COLUMNS if time_unit == 'DAILY' else [c for c in SB_TARGETING_COLUMNS if c != 'date'] + ['startDate', 'endDate'],
        group_by=['targeting'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_targeting(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sdTargeting
# ---------------------------------------------------------------------------

SD_TARGETING_COLUMNS = [
    'adGroupId',
    'adGroupName',
    'adKeywordStatus',
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToCartViews',
    'brandedSearchRate',
    'brandedSearches',
    'brandedSearchesClicks',
    'brandedSearchesViews',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'clicks',
    'cost',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'eCPBrandSearch',
    'impressions',
    'impressionsViews',
    'newToBrandDetailPageViewClicks',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViewViews',
    'newToBrandDetailPageViews',
    'newToBrandECPDetailPageView',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'purchases',
    'purchasesClicks',
    'purchasesPromotedClicks',
    'sales',
    'salesClicks',
    'salesPromotedClicks',
    'targetingExpression',
    'targetingId',
    'targetingText',
    'unitsSold',
    'unitsSoldClicks',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewClickThroughRate',
    'viewabilityRate',
]

_SD_TARGETING_STR_COLS = {
    'adGroupId', 'adGroupName', 'adKeywordStatus',
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'targetingExpression', 'targetingId', 'targetingText',
}


def process_sd_targeting(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    df['date'] = pd.to_datetime(df.get('date'), errors='coerce')

    for col in df.columns:
        if col == 'date':
            continue
        if col in _SD_TARGETING_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sd_targeting_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
):
    """
    Requests, downloads, and processes an sdTargeting daily report.
    Groups by targeting — SD-specific metrics including views, addToCart, brandedSearches.
    NOTE: SD targeting does not support filters — none are sent.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID (one per marketplace)
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default)

    Returns:
    - DataFrame with one row per targeting expression per day
    """
    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sdTargeting',
        ad_product='SPONSORED_DISPLAY',
        start_date=start_date,
        end_date=end_date,
        columns=SD_TARGETING_COLUMNS,
        group_by=['targeting'],
        time_unit=time_unit,
        filters=[],  # SD targeting: Filters N/A per docs
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_targeting(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sbCampaigns — grouped by campaign (DAILY default)
# Note: preview API — only works for campaigns with isMultiAdGroupsEnabled=True
# ---------------------------------------------------------------------------

SB_CAMPAIGN_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToList',
    'addToListFromClicks',
    'brandStorePageView',
    'brandedSearches',
    'brandedSearchesClicks',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clicks',
    'cost',
    'costType',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'impressions',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'longTermROAS',
    'longTermSales',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViews',
    'newToBrandDetailPageViewsClicks',
    'newToBrandECPDetailPageView',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandPurchasesPercentage',
    'newToBrandPurchasesRate',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandSalesPercentage',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'newToBrandUnitsSoldPercentage',
    'purchases',
    'purchasesClicks',
    'purchasesPromoted',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'sales',
    'salesClicks',
    'salesPromoted',
    'topOfSearchImpressionShare',
    'unitsSold',
    'unitsSoldClicks',
    'video5SecondViewRate',
    'video5SecondViews',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewableImpressions',
    'viewClickThroughRate',
]

# SUMMARY: swap 'date' for 'startDate'/'endDate'
SB_CAMPAIGN_SUMMARY_COLUMNS = [c for c in SB_CAMPAIGN_COLUMNS if c != 'date'] + ['startDate', 'endDate']

_SB_CAMP_DATE_COLS = {'date', 'startDate', 'endDate'}

_SB_CAMP_STR_COLS = {
    'campaignBudgetCurrencyCode', 'campaignBudgetType', 'campaignId',
    'campaignName', 'campaignStatus', 'costType',
}


def process_sb_campaign(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SB_CAMP_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SB_CAMP_DATE_COLS:
            continue
        if col in _SB_CAMP_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sb_campaign_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an sbCampaigns report grouped by campaign.

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to campaignStatus (ENABLED/PAUSED/ARCHIVED)

    Note: Preview API — only returns data for campaigns with isMultiAdGroupsEnabled=True.
    """
    cols = SB_CAMPAIGN_COLUMNS if time_unit == 'DAILY' else SB_CAMPAIGN_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sbCampaigns',
        ad_product='SPONSORED_BRANDS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['campaign'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_campaign(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sbCampaignPlacement
# ---------------------------------------------------------------------------

SB_PLACEMENT_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToList',
    'addToListFromClicks',
    'brandedSearches',
    'brandedSearchesClicks',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clicks',
    'cost',
    'costType',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'impressions',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViews',
    'newToBrandDetailPageViewsClicks',
    'newToBrandECPDetailPageView',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandPurchasesPercentage',
    'newToBrandPurchasesRate',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandSalesPercentage',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'newToBrandUnitsSoldPercentage',
    'placementClassification',
    'purchases',
    'purchasesClicks',
    'purchasesPromoted',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'sales',
    'salesClicks',
    'salesPromoted',
    'unitsSold',
    'unitsSoldClicks',
    'video5SecondViewRate',
    'video5SecondViews',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewableImpressions',
    'viewClickThroughRate',
]

# SUMMARY: swap 'date' for 'startDate'/'endDate' (same pattern as SP)
SB_PLACEMENT_SUMMARY_COLUMNS = [c for c in SB_PLACEMENT_COLUMNS if c != 'date'] + ['startDate', 'endDate']

_SB_PLACEMENT_DATE_COLS = {'date', 'startDate', 'endDate'}

_SB_PLACEMENT_STR_COLS = {
    'campaignBudgetCurrencyCode', 'campaignBudgetType', 'campaignId',
    'campaignName', 'campaignStatus', 'costType', 'placementClassification',
}


def process_sb_placement(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SB_PLACEMENT_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SB_PLACEMENT_DATE_COLS:
            continue
        if col in _SB_PLACEMENT_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sb_placement_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
):
    """
    Requests, downloads, and processes an sbCampaignPlacement report.
    Groups by campaignPlacement — includes placementClassification dimension column.
    NOTE: No filters supported for this report type.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID (one per marketplace)
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default) | 'SUMMARY'

    Returns:
    - DataFrame with one row per campaign × placement per day (DAILY) or per range (SUMMARY)
    """
    cols = SB_PLACEMENT_COLUMNS if time_unit == 'DAILY' else SB_PLACEMENT_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sbCampaignPlacement',
        ad_product='SPONSORED_BRANDS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['campaignPlacement'],
        time_unit=time_unit,
        filters=[],  # no filters supported per docs
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_placement(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# spCampaigns — Placement (DAILY default — supports both DAILY and SUMMARY)
# groupBy: campaignPlacement (single value — filters ARE supported)
# ---------------------------------------------------------------------------

# DAILY columns — use 'date'; for SUMMARY swap to startDate + endDate
SP_PLACEMENT_COLUMNS = [
    'addToList',
    'attributedSalesSameSku14d',
    'attributedSalesSameSku1d',
    'attributedSalesSameSku30d',
    'attributedSalesSameSku7d',
    'campaignApplicableBudgetRuleId',
    'campaignApplicableBudgetRuleName',
    'campaignBiddingStrategy',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignRuleBasedBudgetAmount',
    'campaignStatus',
    'clickThroughRate',
    'clicks',
    'cost',
    'costPerClick',
    'date',
    'impressions',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'placementClassification',
    'purchases14d',
    'purchases1d',
    'purchases30d',
    'purchases7d',
    'purchasesSameSku14d',
    'purchasesSameSku1d',
    'purchasesSameSku30d',
    'purchasesSameSku7d',
    'qualifiedBorrows',
    'royaltyQualifiedBorrows',
    'sales14d',
    'sales1d',
    'sales30d',
    'sales7d',
    'spend',
    'topOfSearchImpressionShare',
    'unitsSoldClicks14d',
    'unitsSoldClicks1d',
    'unitsSoldClicks30d',
    'unitsSoldClicks7d',
    'unitsSoldSameSku14d',
    'unitsSoldSameSku1d',
    'unitsSoldSameSku30d',
    'unitsSoldSameSku7d',
]

# SUMMARY columns — swap 'date' for 'startDate'/'endDate'
SP_PLACEMENT_SUMMARY_COLUMNS = [
    c for c in SP_PLACEMENT_COLUMNS if c != 'date'
] + ['startDate', 'endDate']

_SP_PLACEMENT_STR_COLS = {
    'campaignApplicableBudgetRuleId', 'campaignApplicableBudgetRuleName',
    'campaignBiddingStrategy', 'campaignBudgetCurrencyCode', 'campaignBudgetType',
    'campaignId', 'campaignName', 'campaignStatus', 'placementClassification',
}

_SP_PLACEMENT_ALL_DATE_COLS = {'date', 'startDate', 'endDate'}


def process_sp_placement(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SP_PLACEMENT_ALL_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SP_PLACEMENT_ALL_DATE_COLS:
            continue
        if col in _SP_PLACEMENT_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sp_placement_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an spCampaigns placement report.
    Groups by campaignPlacement — includes placementClassification + topOfSearchImpressionShare.
    Optional filter: campaignSite=['AmazonBusiness'] to restrict to B2B placements.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID (one per marketplace)
    - region        : 'NA', 'EU', or 'FE'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - time_unit     : 'DAILY' (default) | 'SUMMARY'
    - filters       : defaults to no filters; pass [{'field':'campaignSite','values':['AmazonBusiness']}]
                      to restrict to Amazon Business placements only

    Returns:
    - DataFrame with one row per campaign × placement per day (DAILY) or per range (SUMMARY)
    """
    cols = SP_PLACEMENT_COLUMNS if time_unit == 'DAILY' else SP_PLACEMENT_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='spCampaigns',
        ad_product='SPONSORED_PRODUCTS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['campaignPlacement'],
        time_unit=time_unit,
        filters=filters if filters is not None else [],
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_placement(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# spSearchTerm — single call, all keyword types
# TARGETING_EXPRESSION rows → 'targeting' col; keyword rows → 'keyword' col
# ---------------------------------------------------------------------------

SP_SEARCH_TERM_COLUMNS = [
    'acosClicks14d',
    'acosClicks7d',
    'addToList',
    'adGroupId',
    'adGroupName',
    'adKeywordStatus',
    'attributedSalesSameSku14d',
    'attributedSalesSameSku1d',
    'attributedSalesSameSku30d',
    'attributedSalesSameSku7d',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clickThroughRate',
    'clicks',
    'cost',
    'costPerClick',
    'date',
    'impressions',
    'keyword',
    'keywordBid',
    'keywordId',
    'keywordType',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'matchType',
    'portfolioId',
    'purchases14d',
    'purchases1d',
    'purchases30d',
    'purchases7d',
    'purchasesSameSku14d',
    'purchasesSameSku1d',
    'purchasesSameSku30d',
    'purchasesSameSku7d',
    'qualifiedBorrows',
    'roasClicks14d',
    'roasClicks7d',
    'royaltyQualifiedBorrows',
    'sales14d',
    'sales1d',
    'sales30d',
    'sales7d',
    'salesOtherSku7d',
    'searchTerm',
    'targeting',
    'unitsSoldClicks14d',
    'unitsSoldClicks1d',
    'unitsSoldClicks30d',
    'unitsSoldClicks7d',
    'unitsSoldOtherSku7d',
    'unitsSoldSameSku14d',
    'unitsSoldSameSku1d',
    'unitsSoldSameSku30d',
    'unitsSoldSameSku7d',
]

SP_SEARCH_TERM_SUMMARY_COLUMNS = [c for c in SP_SEARCH_TERM_COLUMNS if c != 'date'] + ['startDate', 'endDate']

SP_SEARCH_TERM_FILTER = [
    {
        'field': 'keywordType',
        'values': ['BROAD', 'PHRASE', 'EXACT', 'TARGETING_EXPRESSION', 'TARGETING_EXPRESSION_PREDEFINED'],
    },
]

_SP_ST_DATE_COLS = {'date', 'startDate', 'endDate'}

_SP_ST_STR_COLS = {
    'adGroupId', 'adGroupName', 'adKeywordStatus', 'campaignBudgetCurrencyCode',
    'campaignBudgetType', 'campaignId', 'campaignName', 'campaignStatus',
    'keyword', 'keywordId', 'keywordType', 'matchType', 'portfolioId',
    'searchTerm', 'targeting',
}


def process_sp_search_term(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SP_ST_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SP_ST_DATE_COLS:
            continue
        if col in _SP_ST_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sp_search_term_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an spSearchTerm report — all keyword types in one call.
    TARGETING_EXPRESSION rows populate 'targeting'; BROAD/EXACT/PHRASE rows populate 'keyword'.
    Note: only includes impressions that resulted in at least one click.

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to SP_SEARCH_TERM_FILTER (all keyword types)
    """
    if filters is None:
        filters = SP_SEARCH_TERM_FILTER

    cols = SP_SEARCH_TERM_COLUMNS if time_unit == 'DAILY' else SP_SEARCH_TERM_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='spSearchTerm',
        ad_product='SPONSORED_PRODUCTS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['searchTerm'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_search_term(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sbSearchTerm — single call, all keyword types
# ---------------------------------------------------------------------------

SB_SEARCH_TERM_COLUMNS = [
    'adGroupId',
    'adGroupName',
    'adKeywordStatus',
    'addToList',
    'addToListFromClicks',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clicks',
    'cost',
    'costType',
    'date',
    'impressions',
    'keywordBid',
    'keywordId',
    'keywordText',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'matchType',
    'purchases',
    'purchasesClicks',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'sales',
    'salesClicks',
    'searchTerm',
    'unitsSold',
    'video5SecondViewRate',
    'video5SecondViews',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewableImpressions',
    'viewClickThroughRate',
]

# SUMMARY: swap 'date' for 'startDate'/'endDate' (same pattern as SP)
SB_SEARCH_TERM_SUMMARY_COLUMNS = [c for c in SB_SEARCH_TERM_COLUMNS if c != 'date'] + ['startDate', 'endDate']

SB_SEARCH_TERM_FILTER = [
    {
        'field': 'keywordType',
        'values': ['BROAD', 'PHRASE', 'EXACT', 'TARGETING_EXPRESSION', 'TARGETING_EXPRESSION_PREDEFINED'],
    },
]

_SB_ST_DATE_COLS = {'date', 'startDate', 'endDate'}

_SB_ST_STR_COLS = {
    'adGroupId', 'adGroupName', 'adKeywordStatus', 'campaignBudgetCurrencyCode',
    'campaignBudgetType', 'campaignId', 'campaignName', 'campaignStatus',
    'costType', 'keywordId', 'keywordText', 'matchType', 'searchTerm',
}


def process_sb_search_term(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SB_ST_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SB_ST_DATE_COLS:
            continue
        if col in _SB_ST_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sb_search_term_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an sbSearchTerm report — all keyword types in one call.
    Note: only includes impressions that resulted in at least one click.

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to SB_SEARCH_TERM_FILTER (all keyword types)
    """
    if filters is None:
        filters = SB_SEARCH_TERM_FILTER

    cols = SB_SEARCH_TERM_COLUMNS if time_unit == 'DAILY' else SB_SEARCH_TERM_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sbSearchTerm',
        ad_product='SPONSORED_BRANDS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['searchTerm'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_search_term(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sbAds — Sponsored Brands ads-level performance (groupBy=ads)
# reportTypeId: sbAds | adProduct: SPONSORED_BRANDS
# Max date range: 31 days | Retention: 60 days
# Filter: adStatus (ENABLED, PAUSED, ARCHIVED)
# ---------------------------------------------------------------------------

SB_ADS_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToList',
    'addToListFromClicks',
    'adGroupId',
    'adGroupName',
    'adId',
    'brandedSearches',
    'brandedSearchesClicks',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clicks',
    'cost',
    'costType',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'impressions',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViews',
    'newToBrandDetailPageViewsClicks',
    'newToBrandECPDetailPageView',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandPurchasesPercentage',
    'newToBrandPurchasesRate',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandSalesPercentage',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'newToBrandUnitsSoldPercentage',
    'purchases',
    'purchasesClicks',
    'purchasesPromoted',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'sales',
    'salesClicks',
    'salesPromoted',
    'unitsSold',
    'unitsSoldClicks',
    'video5SecondViewRate',
    'video5SecondViews',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewableImpressions',
]

# SUMMARY: swap 'date' for 'startDate'/'endDate' (same pattern as other SB reports)
SB_ADS_SUMMARY_COLUMNS = [c for c in SB_ADS_COLUMNS if c != 'date'] + ['startDate', 'endDate']

SB_ADS_FILTER = [
    {'field': 'adStatus', 'values': ['ENABLED', 'PAUSED', 'ARCHIVED']},
]

_SB_ADS_DATE_COLS = {'date', 'startDate', 'endDate'}

_SB_ADS_STR_COLS = {
    'adGroupId', 'adGroupName', 'adId',
    'campaignBudgetCurrencyCode', 'campaignBudgetType',
    'campaignId', 'campaignName', 'campaignStatus',
    'costType',
}


def process_sb_ads(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SB_ADS_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SB_ADS_DATE_COLS:
            continue
        if col in _SB_ADS_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sb_ads_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an sbAds report grouped by ad (ad-level performance).

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to SB_ADS_FILTER (adStatus ENABLED/PAUSED/ARCHIVED)
    """
    if filters is None:
        filters = SB_ADS_FILTER

    cols = SB_ADS_COLUMNS if time_unit == 'DAILY' else SB_ADS_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sbAds',
        ad_product='SPONSORED_BRANDS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['ads'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_ads(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sbAdGroup — Sponsored Brands ad-group-level performance (groupBy=adGroup)
# reportTypeId: sbAdGroup | adProduct: SPONSORED_BRANDS
# Max date range: 31 days | Retention: 60 days
# Filter: adStatus (ENABLED, PAUSED, ARCHIVED)
# ---------------------------------------------------------------------------

SB_ADGROUP_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToList',
    'addToListFromClicks',
    'adGroupId',
    'adGroupName',
    'adStatus',
    'brandedSearches',
    'brandedSearchesClicks',
    'campaignBudgetAmount',
    'campaignBudgetCurrencyCode',
    'campaignBudgetType',
    'campaignId',
    'campaignName',
    'campaignStatus',
    'clicks',
    'cost',
    'costType',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'impressions',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViews',
    'newToBrandDetailPageViewsClicks',
    'newToBrandECPDetailPageView',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandPurchasesPercentage',
    'newToBrandPurchasesRate',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandSalesPercentage',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'newToBrandUnitsSoldPercentage',
    'purchases',
    'purchasesClicks',
    'purchasesPromoted',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'sales',
    'salesClicks',
    'salesPromoted',
    'unitsSold',
    'unitsSoldClicks',
    'video5SecondViewRate',
    'video5SecondViews',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
]

SB_ADGROUP_SUMMARY_COLUMNS = [c for c in SB_ADGROUP_COLUMNS if c != 'date'] + ['startDate', 'endDate']

SB_ADGROUP_FILTER = [
    {'field': 'adStatus', 'values': ['ENABLED', 'PAUSED', 'ARCHIVED']},
]

_SB_ADGROUP_DATE_COLS = {'date', 'startDate', 'endDate'}

_SB_ADGROUP_STR_COLS = {
    'adGroupId', 'adGroupName', 'adStatus',
    'campaignBudgetCurrencyCode', 'campaignBudgetType',
    'campaignId', 'campaignName', 'campaignStatus',
    'costType',
}


def process_sb_adgroup(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SB_ADGROUP_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SB_ADGROUP_DATE_COLS:
            continue
        if col in _SB_ADGROUP_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sb_adgroup_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an sbAdGroup report (groupBy=adGroup).

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to SB_ADGROUP_FILTER (adStatus ENABLED/PAUSED/ARCHIVED)
    """
    if filters is None:
        filters = SB_ADGROUP_FILTER

    cols = SB_ADGROUP_COLUMNS if time_unit == 'DAILY' else SB_ADGROUP_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sbAdGroup',
        ad_product='SPONSORED_BRANDS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['adGroup'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_adgroup(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sdAdGroup — Sponsored Display ad-group-level performance (groupBy=adGroup)
# reportTypeId: sdAdGroup | adProduct: SPONSORED_DISPLAY
# Max date range: 31 days | Retention: 65 days | No filters supported
# ---------------------------------------------------------------------------

SD_ADGROUP_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToCartViews',
    'adGroupId',
    'adGroupName',
    'addToList',
    'addToListFromClicks',
    'addToListFromViews',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'qualifiedBorrowsFromViews',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrowsFromViews',
    'bidOptimization',
    'brandedSearches',
    'brandedSearchesClicks',
    'brandedSearchesViews',
    'brandedSearchRate',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'clicks',
    'cost',
    'cumulativeReach',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'eCPBrandSearch',
    'impressions',
    'impressionsViews',
    'newToBrandPurchases',
    'kindleEditionNormalizedPagesRead',
    'kindleEditionNormalizedPagesReadFromClicks',
    'kindleEditionNormalizedPagesReadFromViews',
    'kindleEditionNormalizedPagesRoyalties',
    'kindleEditionNormalizedPagesRoyaltiesFromClicks',
    'kindleEditionNormalizedPagesRoyaltiesFromViews',
    'newToBrandPurchasesClicks',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'purchases',
    'purchasesClicks',
    'purchasesPromotedClicks',
    'sales',
    'salesClicks',
    'salesPromotedClicks',
    'unitsSold',
    'unitsSoldClicks',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewClickThroughRate',
    # additional metrics for groupBy=adGroup
    'impressionsFrequencyAverage',
    'newToBrandDetailPageViewClicks',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViews',
    'newToBrandDetailPageViewViews',
    'newToBrandECPDetailPageView',
]

SD_ADGROUP_SUMMARY_COLUMNS = [c for c in SD_ADGROUP_COLUMNS if c != 'date'] + ['startDate', 'endDate']

_SD_ADGROUP_DATE_COLS = {'date', 'startDate', 'endDate'}

_SD_ADGROUP_STR_COLS = {
    'adGroupId', 'adGroupName', 'bidOptimization',
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
}


def process_sd_adgroup(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SD_ADGROUP_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SD_ADGROUP_DATE_COLS:
            continue
        if col in _SD_ADGROUP_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sd_adgroup_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
):
    """
    Requests, downloads, and processes an sdAdGroup report (groupBy=adGroup).
    No filters supported.
    """
    cols = SD_ADGROUP_COLUMNS if time_unit == 'DAILY' else SD_ADGROUP_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sdAdGroup',
        ad_product='SPONSORED_DISPLAY',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['adGroup'],
        time_unit=time_unit,
        filters=[],
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_adgroup(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sdAdGroup (matchedTarget) — Sponsored Display matched-target performance
# reportTypeId: sdAdGroup | adProduct: SPONSORED_DISPLAY | groupBy=matchedTarget
# Max date range: 31 days | Retention: 65 days | No filters supported
# ---------------------------------------------------------------------------

SD_MATCHED_TARGET_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToCartViews',
    'adGroupId',
    'adGroupName',
    'addToList',
    'addToListFromClicks',
    'addToListFromViews',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'qualifiedBorrowsFromViews',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrowsFromViews',
    'bidOptimization',
    'brandedSearches',
    'brandedSearchesClicks',
    'brandedSearchesViews',
    'brandedSearchRate',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'clicks',
    'cost',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'eCPBrandSearch',
    'impressions',
    'impressionsViews',
    'newToBrandPurchases',
    'kindleEditionNormalizedPagesRead',
    'kindleEditionNormalizedPagesReadFromClicks',
    'kindleEditionNormalizedPagesReadFromViews',
    'kindleEditionNormalizedPagesRoyalties',
    'kindleEditionNormalizedPagesRoyaltiesFromClicks',
    'kindleEditionNormalizedPagesRoyaltiesFromViews',
    'newToBrandPurchasesClicks',
    'newToBrandSales',
    'newToBrandSalesClicks',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'purchases',
    'purchasesClicks',
    'purchasesPromotedClicks',
    'sales',
    'salesClicks',
    'salesPromotedClicks',
    'unitsSold',
    'unitsSoldClicks',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewClickThroughRate',
    # additional metric for groupBy=matchedTarget
    'matchedTargetAsin',
]

SD_MATCHED_TARGET_SUMMARY_COLUMNS = [c for c in SD_MATCHED_TARGET_COLUMNS if c != 'date'] + ['startDate', 'endDate']

_SD_MATCHED_TARGET_DATE_COLS = {'date', 'startDate', 'endDate'}

_SD_MATCHED_TARGET_STR_COLS = {
    'adGroupId', 'adGroupName', 'bidOptimization',
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'matchedTargetAsin',
}


def process_sd_matched_target(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SD_MATCHED_TARGET_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SD_MATCHED_TARGET_DATE_COLS:
            continue
        if col in _SD_MATCHED_TARGET_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sd_matched_target_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
):
    """
    Requests, downloads, and processes an sdAdGroup report grouped by matchedTarget.
    No filters supported.
    """
    cols = SD_MATCHED_TARGET_COLUMNS if time_unit == 'DAILY' else SD_MATCHED_TARGET_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sdAdGroup',
        ad_product='SPONSORED_DISPLAY',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['matchedTarget'],
        time_unit=time_unit,
        filters=[],
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_matched_target(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# spCampaigns (campaign) — Sponsored Products campaign-level performance
# reportTypeId: spCampaigns | adProduct: SPONSORED_PRODUCTS | groupBy=campaign
# Max date range: 31 days | Retention: 95 days
# Filter: campaignStatus (ENABLED, PAUSED, ARCHIVED)
# ---------------------------------------------------------------------------

SP_CAMPAIGN_COLUMNS = [
    'impressions',
    'addToList',
    'qualifiedBorrows',
    'royaltyQualifiedBorrows',
    'clicks',
    'cost',
    'purchases1d',
    'purchases7d',
    'purchases14d',
    'purchases30d',
    'purchasesSameSku1d',
    'purchasesSameSku7d',
    'purchasesSameSku14d',
    'purchasesSameSku30d',
    'unitsSoldClicks1d',
    'unitsSoldClicks7d',
    'unitsSoldClicks14d',
    'unitsSoldClicks30d',
    'sales1d',
    'sales7d',
    'sales14d',
    'sales30d',
    'attributedSalesSameSku1d',
    'attributedSalesSameSku7d',
    'attributedSalesSameSku14d',
    'attributedSalesSameSku30d',
    'unitsSoldSameSku1d',
    'unitsSoldSameSku7d',
    'unitsSoldSameSku14d',
    'unitsSoldSameSku30d',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'date',
    'campaignBiddingStrategy',
    'costPerClick',
    'clickThroughRate',
    'spend',
    # additional metrics for groupBy=campaign
    'campaignName',
    'campaignId',
    'campaignStatus',
    'campaignBudgetAmount',
    'campaignBudgetType',
    'campaignRuleBasedBudgetAmount',
    'campaignApplicableBudgetRuleId',
    'campaignApplicableBudgetRuleName',
    'campaignBudgetCurrencyCode',
    'topOfSearchImpressionShare',
]

SP_CAMPAIGN_SUMMARY_COLUMNS = [c for c in SP_CAMPAIGN_COLUMNS if c != 'date'] + ['startDate', 'endDate']

SP_CAMPAIGN_FILTER = [
    {'field': 'campaignStatus', 'values': ['ENABLED', 'PAUSED', 'ARCHIVED']},
]

_SP_CAMPAIGN_DATE_COLS = {'date', 'startDate', 'endDate'}

_SP_CAMPAIGN_STR_COLS = {
    'campaignBiddingStrategy',
    'campaignName', 'campaignId', 'campaignStatus',
    'campaignBudgetType', 'campaignBudgetCurrencyCode',
    'campaignApplicableBudgetRuleId', 'campaignApplicableBudgetRuleName',
}


def process_sp_campaign(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SP_CAMPAIGN_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SP_CAMPAIGN_DATE_COLS:
            continue
        if col in _SP_CAMPAIGN_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sp_campaign_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an spCampaigns report (groupBy=campaign).

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to SP_CAMPAIGN_FILTER (campaignStatus ENABLED/PAUSED/ARCHIVED)
    """
    if filters is None:
        filters = SP_CAMPAIGN_FILTER

    cols = SP_CAMPAIGN_COLUMNS if time_unit == 'DAILY' else SP_CAMPAIGN_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='spCampaigns',
        ad_product='SPONSORED_PRODUCTS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['campaign'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_campaign(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# spCampaigns (adGroup) — Sponsored Products ad-group-level performance
# reportTypeId: spCampaigns | adProduct: SPONSORED_PRODUCTS | groupBy=adGroup
# Max date range: 31 days | Retention: 95 days
# Filter: adStatus (ENABLED, PAUSED, ARCHIVED)
# Note: Amazon does not provide a separate SP ad-group report. Ad-group data
# is only available via spCampaigns with groupBy=adGroup.
# ---------------------------------------------------------------------------

SP_ADGROUP_COLUMNS = [
    'impressions',
    'addToList',
    'qualifiedBorrows',
    'royaltyQualifiedBorrows',
    'clicks',
    'cost',
    'purchases1d',
    'purchases7d',
    'purchases14d',
    'purchases30d',
    'purchasesSameSku1d',
    'purchasesSameSku7d',
    'purchasesSameSku14d',
    'purchasesSameSku30d',
    'unitsSoldClicks1d',
    'unitsSoldClicks7d',
    'unitsSoldClicks14d',
    'unitsSoldClicks30d',
    'sales1d',
    'sales7d',
    'sales14d',
    'sales30d',
    'attributedSalesSameSku1d',
    'attributedSalesSameSku7d',
    'attributedSalesSameSku14d',
    'attributedSalesSameSku30d',
    'unitsSoldSameSku1d',
    'unitsSoldSameSku7d',
    'unitsSoldSameSku14d',
    'unitsSoldSameSku30d',
    'kindleEditionNormalizedPagesRead14d',
    'kindleEditionNormalizedPagesRoyalties14d',
    'date',
    'campaignBiddingStrategy',
    'costPerClick',
    'clickThroughRate',
    'spend',
    # additional metrics for groupBy=adGroup
    'adGroupName',
    'adGroupId',
    'adStatus',
]

SP_ADGROUP_SUMMARY_COLUMNS = [c for c in SP_ADGROUP_COLUMNS if c != 'date'] + ['startDate', 'endDate']

SP_ADGROUP_FILTER = [
    {'field': 'adStatus', 'values': ['ENABLED', 'PAUSED', 'ARCHIVED']},
]

_SP_ADGROUP_DATE_COLS = {'date', 'startDate', 'endDate'}

_SP_ADGROUP_STR_COLS = {
    'campaignBiddingStrategy',
    'adGroupName', 'adGroupId', 'adStatus',
}


def process_sp_adgroup(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SP_ADGROUP_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SP_ADGROUP_DATE_COLS:
            continue
        if col in _SP_ADGROUP_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sp_adgroup_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
    filters=None,
):
    """
    Requests, downloads, and processes an spCampaigns report (groupBy=adGroup).
    This is the ONLY way to get SP ad-group-level data.

    Parameters:
    - time_unit : 'DAILY' (default) | 'SUMMARY'
    - filters   : defaults to SP_ADGROUP_FILTER (adStatus ENABLED/PAUSED/ARCHIVED)
    """
    if filters is None:
        filters = SP_ADGROUP_FILTER

    cols = SP_ADGROUP_COLUMNS if time_unit == 'DAILY' else SP_ADGROUP_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='spCampaigns',
        ad_product='SPONSORED_PRODUCTS',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['adGroup'],
        time_unit=time_unit,
        filters=filters,
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_adgroup(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sdCampaigns (campaign) — Sponsored Display campaign-level performance
# reportTypeId: sdCampaigns | adProduct: SPONSORED_DISPLAY | groupBy=campaign
# Max date range: 31 days | Retention: 65 days | No filters supported
# ---------------------------------------------------------------------------

SD_CAMPAIGN_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToCartViews',
    'addToList',
    'addToListFromClicks',
    'addToListFromViews',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'qualifiedBorrowsFromViews',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrowsFromViews',
    'brandedSearches',
    'brandedSearchesClicks',
    'brandedSearchesViews',
    'brandedSearchRate',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'clicks',
    'cost',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'eCPBrandSearch',
    'impressions',
    'impressionsViews',
    'kindleEditionNormalizedPagesRead',
    'kindleEditionNormalizedPagesReadFromClicks',
    'kindleEditionNormalizedPagesReadFromViews',
    'kindleEditionNormalizedPagesRoyalties',
    'kindleEditionNormalizedPagesRoyaltiesFromClicks',
    'kindleEditionNormalizedPagesRoyaltiesFromViews',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandSalesClicks',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'purchases',
    'purchasesClicks',
    'purchasesPromotedClicks',
    'sales',
    'salesClicks',
    'salesPromotedClicks',
    'unitsSold',
    'unitsSoldClicks',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewClickThroughRate',
    # additional metrics for groupBy=campaign
    'campaignBudgetAmount',
    'campaignStatus',
    'costType',
    'cumulativeReach',
    'impressionsFrequencyAverage',
    'longTermSales',
    'longTermROAS',
    'newToBrandDetailPageViewClicks',
    'newToBrandDetailPageViewRate',
    'newToBrandDetailPageViews',
    'newToBrandDetailPageViewViews',
    'newToBrandECPDetailPageView',
    'newToBrandSales',
]

SD_CAMPAIGN_SUMMARY_COLUMNS = [c for c in SD_CAMPAIGN_COLUMNS if c != 'date'] + ['startDate', 'endDate']

_SD_CAMPAIGN_DATE_COLS = {'date', 'startDate', 'endDate'}

_SD_CAMPAIGN_STR_COLS = {
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'campaignStatus', 'costType',
}


def process_sd_campaign(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SD_CAMPAIGN_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SD_CAMPAIGN_DATE_COLS:
            continue
        if col in _SD_CAMPAIGN_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sd_campaign_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
):
    """
    Requests, downloads, and processes an sdCampaigns report (groupBy=campaign).
    No filters supported.
    """
    cols = SD_CAMPAIGN_COLUMNS if time_unit == 'DAILY' else SD_CAMPAIGN_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sdCampaigns',
        ad_product='SPONSORED_DISPLAY',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['campaign'],
        time_unit=time_unit,
        filters=[],
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_campaign(data, profile_id=profile_id)


# ---------------------------------------------------------------------------
# sdCampaigns (matchedTarget) — Sponsored Display matched-target at campaign level
# reportTypeId: sdCampaigns | adProduct: SPONSORED_DISPLAY | groupBy=matchedTarget
# Max date range: 31 days | Retention: 65 days | No filters supported
# Note: differs from sd_matched_target (sdAdGroup reportTypeId). This one
# aggregates matchedTarget at campaign level — no adGroup fields, fewer columns.
# ---------------------------------------------------------------------------

SD_CAMPAIGN_MATCHED_TARGET_COLUMNS = [
    'addToCart',
    'addToCartClicks',
    'addToCartRate',
    'addToCartViews',
    'addToList',
    'addToListFromClicks',
    'addToListFromViews',
    'qualifiedBorrows',
    'qualifiedBorrowsFromClicks',
    'qualifiedBorrowsFromViews',
    'royaltyQualifiedBorrows',
    'royaltyQualifiedBorrowsFromClicks',
    'royaltyQualifiedBorrowsFromViews',
    'brandedSearches',
    'brandedSearchesClicks',
    'brandedSearchesViews',
    'brandedSearchRate',
    'campaignBudgetCurrencyCode',
    'campaignId',
    'campaignName',
    'clicks',
    'cost',
    'date',
    'detailPageViews',
    'detailPageViewsClicks',
    'eCPAddToCart',
    'eCPBrandSearch',
    'impressions',
    'impressionsViews',
    'kindleEditionNormalizedPagesRead',
    'kindleEditionNormalizedPagesReadFromClicks',
    'kindleEditionNormalizedPagesReadFromViews',
    'kindleEditionNormalizedPagesRoyalties',
    'kindleEditionNormalizedPagesRoyaltiesFromClicks',
    'kindleEditionNormalizedPagesRoyaltiesFromViews',
    'newToBrandPurchases',
    'newToBrandPurchasesClicks',
    'newToBrandSalesClicks',
    'newToBrandUnitsSold',
    'newToBrandUnitsSoldClicks',
    'purchases',
    'purchasesClicks',
    'purchasesPromotedClicks',
    'sales',
    'salesClicks',
    'salesPromotedClicks',
    'unitsSold',
    'unitsSoldClicks',
    'videoCompleteViews',
    'videoFirstQuartileViews',
    'videoMidpointViews',
    'videoThirdQuartileViews',
    'videoUnmutes',
    'viewabilityRate',
    'viewClickThroughRate',
    # additional metric for groupBy=matchedTarget
    'matchedTargetAsin',
]

SD_CAMPAIGN_MATCHED_TARGET_SUMMARY_COLUMNS = [c for c in SD_CAMPAIGN_MATCHED_TARGET_COLUMNS if c != 'date'] + ['startDate', 'endDate']

_SD_CAMPAIGN_MATCHED_TARGET_DATE_COLS = {'date', 'startDate', 'endDate'}

_SD_CAMPAIGN_MATCHED_TARGET_STR_COLS = {
    'campaignBudgetCurrencyCode', 'campaignId', 'campaignName',
    'matchedTargetAsin',
}


def process_sd_campaign_matched_target(data, profile_id=None):
    df = pd.DataFrame(data)
    if df.empty:
        return df

    for col in _SD_CAMPAIGN_MATCHED_TARGET_DATE_COLS:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    for col in df.columns:
        if col in _SD_CAMPAIGN_MATCHED_TARGET_DATE_COLS:
            continue
        if col in _SD_CAMPAIGN_MATCHED_TARGET_STR_COLS:
            df[col] = df[col].astype(str).where(df[col].notna(), None)
        else:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    if profile_id is not None:
        df.insert(0, 'profileId', str(profile_id))

    return df


def get_sd_campaign_matched_target_report(
    access_token,
    client_id,
    profile_id,
    region,
    start_date,
    end_date,
    time_unit='DAILY',
):
    """
    Requests, downloads, and processes an sdCampaigns report grouped by matchedTarget.
    No filters supported.

    Note: this is the campaign-level aggregate. For ad-group-level matched-target
    data (richer column set, includes adGroupId/adGroupName/bidOptimization/etc.),
    use `get_sd_matched_target_report` (sdAdGroup reportTypeId).
    """
    cols = SD_CAMPAIGN_MATCHED_TARGET_COLUMNS if time_unit == 'DAILY' else SD_CAMPAIGN_MATCHED_TARGET_SUMMARY_COLUMNS

    report_id = create_ads_report(
        access_token=access_token,
        client_id=client_id,
        profile_id=profile_id,
        region=region,
        report_type_id='sdCampaigns',
        ad_product='SPONSORED_DISPLAY',
        start_date=start_date,
        end_date=end_date,
        columns=cols,
        group_by=['matchedTarget'],
        time_unit=time_unit,
        filters=[],
    )
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_campaign_matched_target(data, profile_id=profile_id)


# ===========================================================================
# Fire / Fetch wrappers — for 2-step (cron) pipelines
# fire_X  → returns report_id only (no polling)
# fetch_X → polls + downloads + processes → returns DataFrame
# ===========================================================================

# --- Sponsored Products ---

def fire_sp_advertised(access_token, client_id, profile_id, region,
                       start_date, end_date, time_unit='DAILY', filters=None):
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='spAdvertisedProduct', ad_product='SPONSORED_PRODUCTS',
        start_date=start_date, end_date=end_date,
        columns=SP_ADVERTISED_PRODUCT_COLUMNS, group_by=['advertiser'],
        time_unit=time_unit,
        filters=filters if filters is not None else SP_ADVERTISED_FILTER,
    )


def fetch_sp_advertised(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_advertised_product(data, profile_id=profile_id)


def fire_sp_purchased(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY', filters=None):
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='spPurchasedProduct', ad_product='SPONSORED_PRODUCTS',
        start_date=start_date, end_date=end_date,
        columns=SP_PURCHASED_PRODUCT_COLUMNS, group_by=['asin'],
        time_unit=time_unit,
        filters=filters if filters is not None else SP_PURCHASED_PRODUCT_FILTER,
    )


def fetch_sp_purchased(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_purchased_product(data, profile_id=profile_id)


def fire_sp_search_term(access_token, client_id, profile_id, region,
                        start_date, end_date, time_unit='DAILY', filters=None):
    cols = SP_SEARCH_TERM_COLUMNS if time_unit == 'DAILY' else SP_SEARCH_TERM_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='spSearchTerm', ad_product='SPONSORED_PRODUCTS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['searchTerm'],
        time_unit=time_unit,
        filters=filters if filters is not None else SP_SEARCH_TERM_FILTER,
    )


def fetch_sp_search_term(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_search_term(data, profile_id=profile_id)


def fire_sp_targeting(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY', filters=None):
    cols = SP_TARGETING_COLUMNS if time_unit == 'DAILY' else SP_TARGETING_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='spTargeting', ad_product='SPONSORED_PRODUCTS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['targeting'],
        time_unit=time_unit,
        filters=filters if filters is not None else SP_TARGETING_FILTER,
    )


def fetch_sp_targeting(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_targeting(data, profile_id=profile_id)


def fire_sp_placement(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY', filters=None):
    cols = SP_PLACEMENT_COLUMNS if time_unit == 'DAILY' else SP_PLACEMENT_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='spCampaigns', ad_product='SPONSORED_PRODUCTS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['campaignPlacement'],
        time_unit=time_unit,
        filters=filters if filters is not None else [],
    )


def fetch_sp_placement(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_placement(data, profile_id=profile_id)


def fire_sp_campaign(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY', filters=None):
    """spCampaigns — SP campaign-level performance (groupBy=campaign)."""
    cols = SP_CAMPAIGN_COLUMNS if time_unit == 'DAILY' else SP_CAMPAIGN_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='spCampaigns', ad_product='SPONSORED_PRODUCTS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['campaign'],
        time_unit=time_unit,
        filters=filters if filters is not None else SP_CAMPAIGN_FILTER,
    )


def fetch_sp_campaign(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_campaign(data, profile_id=profile_id)


def fire_sp_adgroup(access_token, client_id, profile_id, region,
                    start_date, end_date, time_unit='DAILY', filters=None):
    """spCampaigns (groupBy=adGroup) — SP ad-group-level performance. Only path for SP adGroup data."""
    cols = SP_ADGROUP_COLUMNS if time_unit == 'DAILY' else SP_ADGROUP_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='spCampaigns', ad_product='SPONSORED_PRODUCTS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['adGroup'],
        time_unit=time_unit,
        filters=filters if filters is not None else SP_ADGROUP_FILTER,
    )


def fetch_sp_adgroup(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sp_adgroup(data, profile_id=profile_id)


# --- Sponsored Brands ---

def fire_sb_purchased(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY'):
    """Also called sb_attributed — sbPurchasedProduct does not support filters."""
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sbPurchasedProduct', ad_product='SPONSORED_BRANDS',
        start_date=start_date, end_date=end_date,
        columns=SB_PURCHASED_PRODUCT_COLUMNS, group_by=['purchasedAsin'],
        time_unit=time_unit, filters=[],
    )


def fetch_sb_purchased(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_purchased_product(data, profile_id=profile_id)


# Aliases for clients who use 'sb_attributed' naming
fire_sb_attributed = fire_sb_purchased
fetch_sb_attributed = fetch_sb_purchased


def fire_sb_campaign(access_token, client_id, profile_id, region,
                    start_date, end_date, time_unit='DAILY', filters=None):
    cols = SB_CAMPAIGN_COLUMNS if time_unit == 'DAILY' else SB_CAMPAIGN_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sbCampaigns', ad_product='SPONSORED_BRANDS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['campaign'],
        time_unit=time_unit, filters=filters,
    )


def fetch_sb_campaign(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_campaign(data, profile_id=profile_id)


def fire_sb_ads(access_token, client_id, profile_id, region,
                start_date, end_date, time_unit='DAILY'):
    """sbAds — SB ad-level performance (groupBy=ads). Does not support filters."""
    cols = SB_ADS_COLUMNS if time_unit == 'DAILY' else SB_ADS_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sbAds', ad_product='SPONSORED_BRANDS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['ads'],
        time_unit=time_unit, filters=[],
    )


def fetch_sb_ads(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_ads(data, profile_id=profile_id)


def fire_sb_adgroup(access_token, client_id, profile_id, region,
                    start_date, end_date, time_unit='DAILY', filters=None):
    """sbAdGroup — SB ad-group level performance (groupBy=adGroup)."""
    cols = SB_ADGROUP_COLUMNS if time_unit == 'DAILY' else SB_ADGROUP_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sbAdGroup', ad_product='SPONSORED_BRANDS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['adGroup'],
        time_unit=time_unit,
        filters=filters if filters is not None else SB_ADGROUP_FILTER,
    )


def fetch_sb_adgroup(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_adgroup(data, profile_id=profile_id)


def fire_sb_search_term(access_token, client_id, profile_id, region,
                        start_date, end_date, time_unit='DAILY', filters=None):
    cols = SB_SEARCH_TERM_COLUMNS if time_unit == 'DAILY' else SB_SEARCH_TERM_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sbSearchTerm', ad_product='SPONSORED_BRANDS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['searchTerm'],
        time_unit=time_unit,
        filters=filters if filters is not None else SB_SEARCH_TERM_FILTER,
    )


def fetch_sb_search_term(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_search_term(data, profile_id=profile_id)


def fire_sb_targeting(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY', filters=None):
    cols = SB_TARGETING_COLUMNS if time_unit == 'DAILY' else [c for c in SB_TARGETING_COLUMNS if c != 'date'] + ['startDate', 'endDate']
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sbTargeting', ad_product='SPONSORED_BRANDS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['targeting'],
        time_unit=time_unit,
        filters=filters if filters is not None else SB_TARGETING_FILTER,
    )


def fetch_sb_targeting(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_targeting(data, profile_id=profile_id)


def fire_sb_placement(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY'):
    """sbCampaignPlacement — no filters supported."""
    cols = SB_PLACEMENT_COLUMNS if time_unit == 'DAILY' else SB_PLACEMENT_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sbCampaignPlacement', ad_product='SPONSORED_BRANDS',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['campaignPlacement'],
        time_unit=time_unit, filters=[],
    )


def fetch_sb_placement(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sb_placement(data, profile_id=profile_id)


# --- Sponsored Display ---

def fire_sd_advertised(access_token, client_id, profile_id, region,
                      start_date, end_date, time_unit='DAILY'):
    """sdAdvertisedProduct does not support filters."""
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sdAdvertisedProduct', ad_product='SPONSORED_DISPLAY',
        start_date=start_date, end_date=end_date,
        columns=SD_ADVERTISED_PRODUCT_COLUMNS, group_by=['advertiser'],
        time_unit=time_unit, filters=[],
    )


def fetch_sd_advertised(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_advertised_product(data, profile_id=profile_id)


def fire_sd_purchased(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY'):
    """sdPurchasedProduct does not support filters."""
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sdPurchasedProduct', ad_product='SPONSORED_DISPLAY',
        start_date=start_date, end_date=end_date,
        columns=SD_PURCHASED_PRODUCT_COLUMNS, group_by=['asin'],
        time_unit=time_unit, filters=[],
    )


def fetch_sd_purchased(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_purchased_product(data, profile_id=profile_id)


def fire_sd_targeting(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY'):
    """sdTargeting does not support filters."""
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sdTargeting', ad_product='SPONSORED_DISPLAY',
        start_date=start_date, end_date=end_date,
        columns=SD_TARGETING_COLUMNS, group_by=['targeting'],
        time_unit=time_unit, filters=[],
    )


def fetch_sd_targeting(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_targeting(data, profile_id=profile_id)


def fire_sd_adgroup(access_token, client_id, profile_id, region,
                    start_date, end_date, time_unit='DAILY'):
    """sdAdGroup — SD ad-group level performance (groupBy=adGroup). No filters."""
    cols = SD_ADGROUP_COLUMNS if time_unit == 'DAILY' else SD_ADGROUP_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sdAdGroup', ad_product='SPONSORED_DISPLAY',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['adGroup'],
        time_unit=time_unit, filters=[],
    )


def fetch_sd_adgroup(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_adgroup(data, profile_id=profile_id)


def fire_sd_matched_target(access_token, client_id, profile_id, region,
                           start_date, end_date, time_unit='DAILY'):
    """sdAdGroup — SD matched-target performance (groupBy=matchedTarget). No filters."""
    cols = SD_MATCHED_TARGET_COLUMNS if time_unit == 'DAILY' else SD_MATCHED_TARGET_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sdAdGroup', ad_product='SPONSORED_DISPLAY',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['matchedTarget'],
        time_unit=time_unit, filters=[],
    )


def fetch_sd_matched_target(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_matched_target(data, profile_id=profile_id)


def fire_sd_campaign(access_token, client_id, profile_id, region,
                     start_date, end_date, time_unit='DAILY'):
    """sdCampaigns — SD campaign-level performance (groupBy=campaign). No filters."""
    cols = SD_CAMPAIGN_COLUMNS if time_unit == 'DAILY' else SD_CAMPAIGN_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sdCampaigns', ad_product='SPONSORED_DISPLAY',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['campaign'],
        time_unit=time_unit, filters=[],
    )


def fetch_sd_campaign(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_campaign(data, profile_id=profile_id)


def fire_sd_campaign_matched_target(access_token, client_id, profile_id, region,
                                    start_date, end_date, time_unit='DAILY'):
    """sdCampaigns (groupBy=matchedTarget) — campaign-level matched-target. No filters.

    Companion to fire_sd_matched_target (sdAdGroup reportTypeId, ad-group level).
    """
    cols = SD_CAMPAIGN_MATCHED_TARGET_COLUMNS if time_unit == 'DAILY' else SD_CAMPAIGN_MATCHED_TARGET_SUMMARY_COLUMNS
    return create_ads_report(
        access_token=access_token, client_id=client_id, profile_id=profile_id, region=region,
        report_type_id='sdCampaigns', ad_product='SPONSORED_DISPLAY',
        start_date=start_date, end_date=end_date,
        columns=cols, group_by=['matchedTarget'],
        time_unit=time_unit, filters=[],
    )


def fetch_sd_campaign_matched_target(access_token, client_id, profile_id, region, report_id):
    data = fetch_ads_report(access_token, client_id, profile_id, region, report_id)
    return process_sd_campaign_matched_target(data, profile_id=profile_id)
