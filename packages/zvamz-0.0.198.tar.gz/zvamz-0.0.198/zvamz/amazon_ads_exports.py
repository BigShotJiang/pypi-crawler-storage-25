import gc
import gzip
import json
import os
import pandas as pd
from datetime import datetime, timezone

from .amazon_ads_api import get_ads_export, create_ads_export, fetch_ads_export, download_export_file


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _to_df(rows):
    return pd.DataFrame(rows) if rows else pd.DataFrame()


def _scalar(v):
    # productPrimeShippingEligible returns mixed types across profiles (bool / list / None),
    # which breaks pandas_gbq/pyarrow schema inference. Force to string so the column is uniform.
    if v is None:
        return None
    return json.dumps(v) if isinstance(v, (list, dict)) else str(v)


def _budget(caps):
    monetary = caps.get('budgetValue', {}).get('monetaryBudget', {})
    return {
        'budget_type':    caps.get('budgetType'),
        'budget_period':  caps.get('recurrenceTimePeriod'),
        'budget_amount':  monetary.get('amount'),
        'currency_code':  monetary.get('currencyCode'),
    }


def _placement_adj(pba_list):
    """Pivot placementBidAdjustments list to individual bid_adj_{placement} columns."""
    return {
        f"bid_adj_{pba.get('placement', '').lower()}": pba.get('percentage')
        for pba in pba_list
    }


def _extract_asins(creative):
    """Return comma-separated ASIN string from creative.products list."""
    return ','.join(
        p.get('productId', '') for p in creative.get('products', [])
        if p.get('productId')
    )


# ─── Campaigns ────────────────────────────────────────────────────────────────

def sp_campaigns_export(data):
    """
    Flattens Sponsored Products campaign export data into a DataFrame.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'campaigns', 'SPONSORED_PRODUCTS')

    Returns:
    - DataFrame with one row per campaign
    """
    rows = []
    for c in data:
        opt = c.get('optimization', {})
        rows.append({
            'campaign_id':           c.get('campaignId'),
            'ad_product':            c.get('adProduct'),
            'portfolio_id':          c.get('portfolioId'),
            'name':                  c.get('name'),
            'start_date':            c.get('startDate'),
            'end_date':              c.get('endDate'),
            'state':                 c.get('state'),
            'targeting_type':        c.get('targetingSettings'),
            'bid_strategy':          opt.get('bidStrategy'),
            **_placement_adj(opt.get('placementBidAdjustments', [])),
            **_budget(c.get('budgetCaps', {})),
            'delivery_status':       c.get('deliveryStatus'),
            'delivery_reasons':      json.dumps(c.get('deliveryReasons', [])),
            'tags':                  json.dumps(c.get('tags', [])),
            'creation_datetime':     c.get('creationDateTime'),
            'last_updated_datetime': c.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)


def sb_campaigns_export(data):
    """
    Flattens Sponsored Brands campaign export data into a DataFrame.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'campaigns', 'SPONSORED_BRANDS')

    Returns:
    - DataFrame with one row per campaign
    """
    rows = []
    for c in data:
        opt = c.get('optimization', {})
        rows.append({
            'campaign_id':                      c.get('campaignId'),
            'ad_product':                       c.get('adProduct'),
            'portfolio_id':                     c.get('portfolioId'),
            'brand_entity_id':                  c.get('brandEntityId'),
            'name':                             c.get('name'),
            'start_date':                       c.get('startDate'),
            'state':                            c.get('state'),
            'cost_type':                        c.get('costType'),
            'bid_strategy':                     opt.get('bidStrategy'),
            **_placement_adj(opt.get('placementBidAdjustments', [])),
            'shopper_segment_bid_adjustments':  json.dumps(opt.get('shopperSegmentBidAdjustments', [])),
            **_budget(c.get('budgetCaps', {})),
            'delivery_status':                  c.get('deliveryStatus'),
            'delivery_reasons':                 json.dumps(c.get('deliveryReasons', [])),
            'tags':                             json.dumps(c.get('tags', [])),
            'creation_datetime':                c.get('creationDateTime'),
            'last_updated_datetime':            c.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)


def sd_campaigns_export(data):
    """
    Flattens Sponsored Display campaign export data into a DataFrame.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'campaigns', 'SPONSORED_DISPLAY')

    Returns:
    - DataFrame with one row per campaign
    """
    rows = []
    for c in data:
        rows.append({
            'campaign_id':           c.get('campaignId'),
            'ad_product':            c.get('adProduct'),
            'portfolio_id':          c.get('portfolioId'),
            'name':                  c.get('name'),
            'start_date':            c.get('startDate'),
            'end_date':              c.get('endDate'),
            'state':                 c.get('state'),
            'cost_type':             c.get('costType'),
            'targeting_settings':    c.get('targetingSettings'),
            **_budget(c.get('budgetCaps', {})),
            'delivery_status':       c.get('deliveryStatus'),
            'delivery_reasons':      json.dumps(c.get('deliveryReasons', [])),
            'tags':                  json.dumps(c.get('tags', [])),
            'creation_datetime':     c.get('creationDateTime'),
            'last_updated_datetime': c.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)


# ─── Ad Groups ────────────────────────────────────────────────────────────────

def sp_adgroups_export(data):
    """
    Flattens Sponsored Products ad group export data into a DataFrame.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'adGroups', 'SPONSORED_PRODUCTS')

    Returns:
    - DataFrame with one row per ad group
    """
    rows = []
    for ag in data:
        bid = ag.get('bid', {})
        rows.append({
            'ad_group_id':           ag.get('adGroupId'),
            'campaign_id':           ag.get('campaignId'),
            'ad_product':            ag.get('adProduct'),
            'name':                  ag.get('name'),
            'state':                 ag.get('state'),
            'default_bid':           bid.get('defaultBid'),
            'currency_code':         bid.get('currencyCode'),
            'delivery_status':       ag.get('deliveryStatus'),
            'delivery_reasons':      json.dumps(ag.get('deliveryReasons', [])),
            'creation_datetime':     ag.get('creationDateTime'),
            'last_updated_datetime': ag.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)


def sb_adgroups_export(data):
    """
    Flattens Sponsored Brands ad group export data into a DataFrame.
    Note: SB ad groups do not have a default bid.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'adGroups', 'SPONSORED_BRANDS')

    Returns:
    - DataFrame with one row per ad group
    """
    rows = []
    for ag in data:
        goal = ag.get('optimization', {}).get('goalSettings', {})
        rows.append({
            'ad_group_id':           ag.get('adGroupId'),
            'campaign_id':           ag.get('campaignId'),
            'ad_product':            ag.get('adProduct'),
            'name':                  ag.get('name'),
            'state':                 ag.get('state'),
            'creative_type':         ag.get('creativeType'),
            'goal_type':             goal.get('goalType'),
            'goal_kpi':              goal.get('goalKpi'),
            'delivery_status':       ag.get('deliveryStatus'),
            'delivery_reasons':      json.dumps(ag.get('deliveryReasons', [])),
            'creation_datetime':     ag.get('creationDateTime'),
            'last_updated_datetime': ag.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)


def sd_adgroups_export(data):
    """
    Flattens Sponsored Display ad group export data into a DataFrame.
    Note: SD ad groups do not have a default bid.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'adGroups', 'SPONSORED_DISPLAY')

    Returns:
    - DataFrame with one row per ad group
    """
    return sb_adgroups_export(data)


# ─── Targets ──────────────────────────────────────────────────────────────────

def _flatten_target(t):
    td = t.get('targetDetails', {})
    bid = t.get('bid', {})
    return {
        'target_id':                   t.get('targetId'),
        'ad_group_id':                 t.get('adGroupId'),
        'campaign_id':                 t.get('campaignId'),   # campaign-level negatives only
        'ad_product':                  t.get('adProduct'),
        'state':                       t.get('state'),
        'negative':                    t.get('negative'),
        'target_type':                 t.get('targetType'),
        'bid':                         bid.get('bid'),
        'currency_code':               bid.get('currencyCode'),
        # keyword fields
        'match_type':                  td.get('matchType'),
        'keyword':                     td.get('keyword'),
        'native_language_keyword':     td.get('nativeLanguageKeyword'),
        'native_language_locale':      td.get('nativeLanguageLocale'),
        # product fields
        'asin':                        td.get('asin'),
        # audience fields
        'audience_id':                 td.get('audienceId'),
        'lookback':                    td.get('lookback'),
        'event':                       td.get('event'),
        # product category fields
        'product_category_id':         td.get('productCategoryId'),
        'product_category_resolved':   td.get('productCategoryResolved'),
        'product_brand':               td.get('productBrand'),
        'product_brand_resolved':      td.get('productBrandResolved'),
        'product_genre':               td.get('productGenre'),
        'product_genre_resolved':      td.get('productGenreResolved'),
        'product_price_less_than':     td.get('productPriceLessThan'),
        'product_price_greater_than':  td.get('productPriceGreaterThan'),
        'product_rating_less_than':    td.get('productRatingLessThan'),
        'product_rating_greater_than': td.get('productRatingGreaterThan'),
        'product_age_range':           td.get('productAgeRange'),
        'product_age_range_resolved':  td.get('productAgeRangeResolved'),
        'product_prime_shipping':      _scalar(td.get('productPrimeShippingEligible')),
        'delivery_status':             t.get('deliveryStatus'),
        'delivery_reasons':            json.dumps(t.get('deliveryReasons', [])),
        'creation_datetime':           t.get('creationDateTime'),
        'last_updated_datetime':       t.get('lastUpdatedDateTime'),
    }


def sp_targets_export(data):
    """
    Flattens Sponsored Products target export data into a DataFrame.
    Covers all target types: KEYWORD, PRODUCT, AUTO (positive and negative).

    Parameters:
    - data : list of dicts from get_ads_export(..., 'targets', 'SPONSORED_PRODUCTS')

    Returns:
    - DataFrame with one row per target
    """
    return _to_df([_flatten_target(t) for t in data])


def sb_targets_export(data):
    """
    Flattens Sponsored Brands target export data into a DataFrame.
    Covers all target types: KEYWORD, PRODUCT (positive and negative).

    Parameters:
    - data : list of dicts from get_ads_export(..., 'targets', 'SPONSORED_BRANDS')

    Returns:
    - DataFrame with one row per target
    """
    return _to_df([_flatten_target(t) for t in data])


def sd_targets_export(data):
    """
    Flattens Sponsored Display target export data into a DataFrame.
    Covers all target types: PRODUCT, PRODUCT_CATEGORY, AUDIENCE,
    PRODUCT_AUDIENCE, PRODUCT_CATEGORY_AUDIENCE (positive and negative).

    Parameters:
    - data : list of dicts from get_ads_export(..., 'targets', 'SPONSORED_DISPLAY')

    Returns:
    - DataFrame with one row per target
    """
    return _to_df([_flatten_target(t) for t in data])


# ─── Ads ──────────────────────────────────────────────────────────────────────

def sp_ads_export(data):
    """
    Flattens Sponsored Products ad export data into a DataFrame.
    ASINs from creative.products stored as comma-separated string.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'ads', 'SPONSORED_PRODUCTS')

    Returns:
    - DataFrame with one row per ad
    """
    rows = []
    for ad in data:
        creative = ad.get('creative', {})
        rows.append({
            'ad_id':                 ad.get('adId'),
            'ad_group_id':           ad.get('adGroupId'),
            'ad_product':            ad.get('adProduct'),
            'state':                 ad.get('state'),
            'ad_type':               ad.get('adType'),
            'asins':                 _extract_asins(creative),
            'headline':              creative.get('headline'),
            'delivery_status':       ad.get('deliveryStatus'),
            'delivery_reasons':      json.dumps(ad.get('deliveryReasons', [])),
            'creation_datetime':     ad.get('creationDateTime'),
            'last_updated_datetime': ad.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)


def sb_ads_export(data):
    """
    Flattens Sponsored Brands ad export data into a DataFrame.
    Covers adTypes: PRODUCT_COLLECTION, VIDEO, STORE_SPOTLIGHT.
    ASINs from creative.products stored as comma-separated string.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'ads', 'SPONSORED_BRANDS')

    Returns:
    - DataFrame with one row per ad
    """
    rows = []
    for ad in data:
        creative = ad.get('creative', {})
        logo = creative.get('brandLogo', {})
        landing = creative.get('landingPage', {})
        rows.append({
            'ad_id':                 ad.get('adId'),
            'ad_group_id':           ad.get('adGroupId'),
            'ad_product':            ad.get('adProduct'),
            'state':                 ad.get('state'),
            'ad_type':               ad.get('adType'),
            'ad_version_id':         ad.get('adVersionId'),
            'asins':                 _extract_asins(creative),
            'headline':              creative.get('headline'),
            'brand_name':            creative.get('brandName'),
            'brand_logo_asset_id':   logo.get('assetId'),
            'landing_page_type':     landing.get('landingPageType'),
            'landing_page_url':      landing.get('landingPageUrl'),
            'videos':                json.dumps(creative.get('videos', [])),
            'cards':                 json.dumps(creative.get('cards', [])),
            'custom_images':         json.dumps(creative.get('customImages', [])),
            'delivery_status':       ad.get('deliveryStatus'),
            'delivery_reasons':      json.dumps(ad.get('deliveryReasons', [])),
            'creation_datetime':     ad.get('creationDateTime'),
            'last_updated_datetime': ad.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)


def sd_ads_export(data):
    """
    Flattens Sponsored Display ad export data into a DataFrame.
    Covers adTypes: IMAGE.
    ASINs from creative.products stored as comma-separated string.

    Parameters:
    - data : list of dicts from get_ads_export(..., 'ads', 'SPONSORED_DISPLAY')

    Returns:
    - DataFrame with one row per ad
    """
    rows = []
    for ad in data:
        creative = ad.get('creative', {})
        logo = creative.get('brandLogo', {})
        landing = creative.get('landingPage', {})
        rows.append({
            'ad_id':                 ad.get('adId'),
            'ad_group_id':           ad.get('adGroupId'),
            'ad_product':            ad.get('adProduct'),
            'state':                 ad.get('state'),
            'ad_type':               ad.get('adType'),
            'ad_version_id':         ad.get('adVersionId'),
            'asins':                 _extract_asins(creative),
            'headline':              creative.get('headline'),
            'brand_logo_asset_id':   logo.get('assetId'),
            'landing_page_type':     landing.get('landingPageType'),
            'landing_page_url':      landing.get('landingPageUrl'),
            'videos':                json.dumps(creative.get('videos', [])),
            'custom_images':         json.dumps(creative.get('customImages', [])),
            'delivery_status':       ad.get('deliveryStatus'),
            'delivery_reasons':      json.dumps(ad.get('deliveryReasons', [])),
            'creation_datetime':     ad.get('creationDateTime'),
            'last_updated_datetime': ad.get('lastUpdatedDateTime'),
        })
    return _to_df(rows)

# ─── Pull Wrappers (multi-profile, BQ-ready) ──────────────────────────────────

def _concat(dfs):
    dfs = [df for df in dfs if df is not None and not df.empty]
    return pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()


def _pull_exports(access_token, client_id, profile_ids, region, ad_product,
                  campaigns_fn, adgroups_fn, targets_fn, ads_fn):
    if isinstance(profile_ids, int):
        profile_ids = [profile_ids]

    all_campaigns, all_adgroups, all_targets, all_ads = [], [], [], []

    for profile_id in profile_ids:
        for entity, fn, store in [
            ('campaigns', campaigns_fn, all_campaigns),
            ('adGroups',  adgroups_fn,  all_adgroups),
            ('targets',   targets_fn,   all_targets),
            ('ads',       ads_fn,       all_ads),
        ]:
            data = get_ads_export(access_token, client_id, profile_id, region, entity, ad_product)
            df = fn(data)
            if df is not None and not df.empty:
                df.insert(0, 'profile_id', str(profile_id))
                store.append(df)

    return {
        'campaigns': _concat(all_campaigns),
        'adgroups':  _concat(all_adgroups),
        'targets':   _concat(all_targets),
        'ads':       _concat(all_ads),
    }


def pull_sp_exports(access_token, client_id, profile_ids, region):
    """
    Pulls all Sponsored Products exports for one or more profiles.
    Returns 4 flattened DataFrames ready for BigQuery ingestion.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - profile_ids  : int or list of ints — from get_ads_profiles()
    - region       : 'NA', 'EU', or 'FE'

    Returns:
    - dict with keys: 'campaigns', 'adgroups', 'targets', 'ads'

    Example:
        auth = zv_ads_client_access('mjt_arvin', 'NA')
        profiles = get_ads_profiles(auth['access_token'], auth['client_id'], 'NA')
        mjt_ids = [p['profileId'] for p in profiles
                   if 'M & J Trading' in p.get('accountInfo', {}).get('name', '')]

        result = pull_sp_exports(auth['access_token'], auth['client_id'], mjt_ids, 'NA')
        result['campaigns']  # DataFrame ready for BQ
        result['targets']    # DataFrame ready for BQ
    """
    return _pull_exports(
        access_token, client_id, profile_ids, region,
        'SPONSORED_PRODUCTS',
        sp_campaigns_export, sp_adgroups_export, sp_targets_export, sp_ads_export,
    )


def pull_sb_exports(access_token, client_id, profile_ids, region):
    """
    Pulls all Sponsored Brands exports for one or more profiles.
    Returns 4 flattened DataFrames ready for BigQuery ingestion.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - profile_ids  : int or list of ints — from get_ads_profiles()
    - region       : 'NA', 'EU', or 'FE'

    Returns:
    - dict with keys: 'campaigns', 'adgroups', 'targets', 'ads'
    """
    return _pull_exports(
        access_token, client_id, profile_ids, region,
        'SPONSORED_BRANDS',
        sb_campaigns_export, sb_adgroups_export, sb_targets_export, sb_ads_export,
    )


def pull_sd_exports(access_token, client_id, profile_ids, region):
    """
    Pulls all Sponsored Display exports for one or more profiles.
    Returns 4 flattened DataFrames ready for BigQuery ingestion.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - profile_ids  : int or list of ints — from get_ads_profiles()
    - region       : 'NA', 'EU', or 'FE'

    Returns:
    - dict with keys: 'campaigns', 'adgroups', 'targets', 'ads'
    """
    return _pull_exports(
        access_token, client_id, profile_ids, region,
        'SPONSORED_DISPLAY',
        sd_campaigns_export, sd_adgroups_export, sd_targets_export, sd_ads_export,
    )


# ─── Two-Step: Request IDs + Download ─────────────────────────────────────────

_AD_PRODUCTS = ['SPONSORED_PRODUCTS', 'SPONSORED_BRANDS', 'SPONSORED_DISPLAY']
_ENTITIES    = ['campaigns', 'adGroups', 'targets', 'ads']


def request_ads_exports(access_token, client_id, profile_ids, region, save_path,
                        state_filter='ENABLED,PAUSED,ARCHIVED'):
    """
    Fires export requests for SP, SB, and SD across all entity types and profiles.
    Saves export IDs to a CSV — no polling, returns immediately.
    Run fetch_ads_export / download_sp/sb/sd_exports after ~1 hour to download.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - profile_ids  : int or list of ints — from get_ads_profiles()
    - region       : 'NA', 'EU', or 'FE'
    - save_path    : path to save the CSV, e.g. '/home/arvin/projects/mjt-automation/ads_export_ids.csv'
    - state_filter : default 'ENABLED,PAUSED,ARCHIVED'

    Returns:
    - DataFrame of all export IDs (also saved to save_path)

    Example:
        auth = zv_ads_client_access('mjt_arvin', 'NA')
        request_ads_exports(auth['access_token'], auth['client_id'],
                            mjt_ids, 'NA', '/home/arvin/projects/mjt-automation/ads_export_ids.csv')
    """
    if isinstance(profile_ids, (int, str)):
        profile_ids = [profile_ids]

    rows = []
    requested_at = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')

    for profile_id in profile_ids:
        for ad_product in _AD_PRODUCTS:
            for entity_type in _ENTITIES:
                export_id = create_ads_export(
                    access_token, client_id, profile_id, region,
                    entity_type, ad_product, state_filter,
                )
                rows.append({
                    'profile_id':   str(profile_id),
                    'ad_product':   ad_product,
                    'entity_type':  entity_type,
                    'export_id':    export_id,
                    'requested_at': requested_at,
                })

    df = pd.DataFrame(rows)
    df.to_csv(save_path, index=False)
    print(f'[request] {len(rows)} export IDs saved to {save_path}')
    return df


def _download_exports(access_token, client_id, region, ad_product, save_path,
                      campaigns_fn, adgroups_fn, targets_fn, ads_fn):
    ids_df = pd.read_csv(save_path, dtype={'profile_id': str, 'export_id': str})
    filtered = ids_df[ids_df['ad_product'] == ad_product]

    if filtered.empty:
        raise ValueError(f'No export IDs found for {ad_product} in {save_path}')

    fn_map = {
        'campaigns': (campaigns_fn, 'campaigns'),
        'adGroups':  (adgroups_fn,  'adgroups'),
        'targets':   (targets_fn,   'targets'),
        'ads':       (ads_fn,       'ads'),
    }

    buckets = {'campaigns': [], 'adgroups': [], 'targets': [], 'ads': []}

    for _, row in filtered.iterrows():
        profile_id  = row['profile_id']
        entity_type = row['entity_type']
        export_id   = row['export_id']

        data = fetch_ads_export(access_token, client_id, profile_id, region, entity_type, export_id)
        fn, key = fn_map[entity_type]
        df = fn(data)

        if not df.empty:
            df.insert(0, 'profile_id', profile_id)
            buckets[key].append(df)

    return {k: _concat(v) for k, v in buckets.items()}


def download_sp_exports(access_token, client_id, region, save_path):
    """
    Polls and downloads all Sponsored Products exports from a saved export IDs CSV.
    Returns 4 flattened DataFrames ready for BigQuery ingestion.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - region       : 'NA', 'EU', or 'FE'
    - save_path    : path to the CSV saved by request_ads_exports()

    Returns:
    - dict with keys: 'campaigns', 'adgroups', 'targets', 'ads'
    """
    return _download_exports(
        access_token, client_id, region, 'SPONSORED_PRODUCTS', save_path,
        sp_campaigns_export, sp_adgroups_export, sp_targets_export, sp_ads_export,
    )


def download_sb_exports(access_token, client_id, region, save_path):
    """
    Polls and downloads all Sponsored Brands exports from a saved export IDs CSV.
    Returns 4 flattened DataFrames ready for BigQuery ingestion.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - region       : 'NA', 'EU', or 'FE'
    - save_path    : path to the CSV saved by request_ads_exports()

    Returns:
    - dict with keys: 'campaigns', 'adgroups', 'targets', 'ads'
    """
    return _download_exports(
        access_token, client_id, region, 'SPONSORED_BRANDS', save_path,
        sb_campaigns_export, sb_adgroups_export, sb_targets_export, sb_ads_export,
    )


def download_sd_exports(access_token, client_id, region, save_path):
    """
    Polls and downloads all Sponsored Display exports from a saved export IDs CSV.
    Returns 4 flattened DataFrames ready for BigQuery ingestion.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - region       : 'NA', 'EU', or 'FE'
    - save_path    : path to the CSV saved by request_ads_exports()

    Returns:
    - dict with keys: 'campaigns', 'adgroups', 'targets', 'ads'
    """
    return _download_exports(
        access_token, client_id, region, 'SPONSORED_DISPLAY', save_path,
        sd_campaigns_export, sd_adgroups_export, sd_targets_export, sd_ads_export,
    )


# ─── 12 Individual Entity Download Functions ──────────────────────────────────

def _download_single_entity(access_token, client_id, region, ad_product, entity_type,
                             save_path, processor_fn, download_dir=None):
    ids_df = pd.read_csv(save_path, dtype={'profile_id': str, 'export_id': str})
    filtered = ids_df[
        (ids_df['ad_product'] == ad_product) &
        (ids_df['entity_type'] == entity_type)
    ]

    if filtered.empty:
        raise ValueError(f'No export ID found for {ad_product} / {entity_type} in {save_path}')

    dfs = []
    for _, row in filtered.iterrows():
        profile_id = row['profile_id']
        export_id  = row['export_id']

        if download_dir:
            file_path = os.path.join(download_dir, f'{ad_product}_{entity_type}_{profile_id}.json.gz')
            if os.path.exists(file_path):
                print(f'[export] Reading {entity_type} from {file_path}...')
                with gzip.open(file_path, 'rb') as f:
                    data = json.load(f)
            else:
                data = fetch_ads_export(access_token, client_id, profile_id, region, entity_type, export_id)
        else:
            data = fetch_ads_export(access_token, client_id, profile_id, region, entity_type, export_id)

        df = processor_fn(data)
        del data
        gc.collect()

        if not df.empty:
            df.insert(0, 'profile_id', profile_id)
            dfs.append(df)

    return _concat(dfs)


# SP
def download_sp_campaigns(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_PRODUCTS', 'campaigns', save_path, sp_campaigns_export, download_dir)

def download_sp_adgroups(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_PRODUCTS', 'adGroups', save_path, sp_adgroups_export, download_dir)

def download_sp_targets(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_PRODUCTS', 'targets', save_path, sp_targets_export, download_dir)

def download_sp_ads(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_PRODUCTS', 'ads', save_path, sp_ads_export, download_dir)


# SB
def download_sb_campaigns(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_BRANDS', 'campaigns', save_path, sb_campaigns_export, download_dir)

def download_sb_adgroups(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_BRANDS', 'adGroups', save_path, sb_adgroups_export, download_dir)

def download_sb_targets(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_BRANDS', 'targets', save_path, sb_targets_export, download_dir)

def download_sb_ads(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_BRANDS', 'ads', save_path, sb_ads_export, download_dir)


# SD
def download_sd_campaigns(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_DISPLAY', 'campaigns', save_path, sd_campaigns_export, download_dir)

def download_sd_adgroups(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_DISPLAY', 'adGroups', save_path, sd_adgroups_export, download_dir)

def download_sd_targets(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_DISPLAY', 'targets', save_path, sd_targets_export, download_dir)

def download_sd_ads(access_token, client_id, region, save_path, download_dir=None):
    return _download_single_entity(access_token, client_id, region,
                                   'SPONSORED_DISPLAY', 'ads', save_path, sd_ads_export, download_dir)


def prefetch_ads_exports(access_token, client_id, region, save_path, download_dir):
    """
    Downloads all gzip files from a saved export IDs CSV to download_dir. No parsing.
    Use this to pre-download all files before processing — keeps RAM low during download phase.
    Then pass download_dir to any download_* function to read from disk instead of re-fetching.

    Parameters:
    - save_path    : path to CSV saved by request_ads_exports()
    - download_dir : folder to save gzip files — created if it doesn't exist

    Example:
        zv.prefetch_ads_exports(auth['access_token'], auth['client_id'], 'NA',
                                '/content/ads_export_ids.csv', '/content/ads_gzip')

        sp_campaigns = zv.download_sp_campaigns(..., download_dir='/content/ads_gzip')
    """
    os.makedirs(download_dir, exist_ok=True)
    ids_df = pd.read_csv(save_path, dtype={'profile_id': str, 'export_id': str})

    for _, row in ids_df.iterrows():
        file_name = f"{row['ad_product']}_{row['entity_type']}_{row['profile_id']}.json.gz"
        file_path = os.path.join(download_dir, file_name)
        download_export_file(
            access_token, client_id, row['profile_id'], region,
            row['entity_type'], row['export_id'], file_path,
        )

    print(f'[prefetch] {len(ids_df)} files saved to {download_dir}')


# ─── Chunked Streaming (for large files like SP targets) ──────────────────────

def _stream_from_gzip(file_path, processor_fn, chunk_size=10000):
    """
    Generator — streams a gzip JSON export file in chunks, yielding a processed
    DataFrame per chunk. Uses ijson to parse record by record — never holds the
    full decompressed JSON in memory.

    Parameters:
    - file_path    : path to a .json.gz export file
    - processor_fn : one of the sp/sb/sd_*_export functions
    - chunk_size   : records per chunk (default 10,000)

    Yields:
    - DataFrame per chunk
    """
    import ijson
    chunk = []
    with gzip.open(file_path, 'rb') as f:
        for record in ijson.items(f, 'item'):
            chunk.append(record)
            if len(chunk) >= chunk_size:
                df = processor_fn(chunk)
                chunk = []
                gc.collect()
                if not df.empty:
                    yield df
    if chunk:
        df = processor_fn(chunk)
        if not df.empty:
            yield df


def _stream_entity(access_token, client_id, region, ad_product, entity_type,
                   save_path, download_dir, processor_fn, chunk_size):
    ids_df = pd.read_csv(save_path, dtype={'profile_id': str, 'export_id': str})
    filtered = ids_df[
        (ids_df['ad_product'] == ad_product) &
        (ids_df['entity_type'] == entity_type)
    ]
    if filtered.empty:
        raise ValueError(f'No export ID found for {ad_product} / {entity_type} in {save_path}')

    for _, row in filtered.iterrows():
        profile_id = row['profile_id']
        file_path  = os.path.join(download_dir, f'{ad_product}_{entity_type}_{profile_id}.json.gz')

        for chunk_df in _stream_from_gzip(file_path, processor_fn, chunk_size):
            chunk_df.insert(0, 'profile_id', profile_id)
            yield chunk_df


def stream_sp_campaigns(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """
    Generator — yields SP campaigns DataFrames in chunks from a pre-downloaded gzip file.
    Use this instead of download_sp_campaigns when RAM is limited.
    Requires prefetch_ads_exports() to have been run first.

    Example (VPS):
        for chunk in zv.stream_sp_campaigns(token, client_id, 'NA', CSV, GZIP_DIR):
            bq_push(chunk, 'ads_sp_campaigns', if_exists='append')
            del chunk; gc.collect()
    """
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_PRODUCTS', 'campaigns',
                              save_path, download_dir, sp_campaigns_export, chunk_size)


def stream_sp_adgroups(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SP adgroups DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_PRODUCTS', 'adGroups',
                              save_path, download_dir, sp_adgroups_export, chunk_size)


def stream_sp_targets(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SP targets DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_PRODUCTS', 'targets',
                              save_path, download_dir, sp_targets_export, chunk_size)


def stream_sp_ads(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SP ads DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_PRODUCTS', 'ads',
                              save_path, download_dir, sp_ads_export, chunk_size)


def stream_sb_campaigns(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SB campaigns DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_BRANDS', 'campaigns',
                              save_path, download_dir, sb_campaigns_export, chunk_size)


def stream_sb_adgroups(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SB adgroups DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_BRANDS', 'adGroups',
                              save_path, download_dir, sb_adgroups_export, chunk_size)


def stream_sb_targets(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SB targets DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_BRANDS', 'targets',
                              save_path, download_dir, sb_targets_export, chunk_size)


def stream_sb_ads(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SB ads DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_BRANDS', 'ads',
                              save_path, download_dir, sb_ads_export, chunk_size)


def stream_sd_campaigns(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SD campaigns DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_DISPLAY', 'campaigns',
                              save_path, download_dir, sd_campaigns_export, chunk_size)


def stream_sd_adgroups(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SD adgroups DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_DISPLAY', 'adGroups',
                              save_path, download_dir, sd_adgroups_export, chunk_size)


def stream_sd_targets(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SD targets DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_DISPLAY', 'targets',
                              save_path, download_dir, sd_targets_export, chunk_size)


def stream_sd_ads(access_token, client_id, region, save_path, download_dir, chunk_size=10000):
    """Generator — yields SD ads DataFrames in chunks. See stream_sp_campaigns for usage."""
    yield from _stream_entity(access_token, client_id, region,
                              'SPONSORED_DISPLAY', 'ads',
                              save_path, download_dir, sd_ads_export, chunk_size)
