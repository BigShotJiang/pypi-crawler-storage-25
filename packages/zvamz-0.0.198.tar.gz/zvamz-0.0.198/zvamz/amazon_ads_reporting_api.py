import gc
import os
import requests
import tempfile
import time

from .amazon_ads_api import ADS_BASE_URLS, _stream_to_file, parse_export_file

REPORTING_CONTENT_TYPE = 'application/vnd.createasyncreportrequest.v3+json'
REPORTING_ACCEPT_TYPE  = 'application/vnd.getasyncreportresponse.v3+json'

STATE_FILTER = [
    {'field': 'campaignStatus', 'values': ['ENABLED', 'PAUSED', 'ARCHIVED']}
]


def _report_headers(access_token, client_id, profile_id):
    return {
        'Authorization':                  f'Bearer {access_token}',
        'Amazon-Advertising-API-ClientId': client_id,
        'Amazon-Advertising-API-Scope':   str(profile_id),
        'Content-Type':                   REPORTING_CONTENT_TYPE,
        'Accept':                         REPORTING_ACCEPT_TYPE,
    }


def create_ads_report(
    access_token,
    client_id,
    profile_id,
    region,
    report_type_id,
    ad_product,
    start_date,
    end_date,
    columns,
    group_by,
    time_unit='DAILY',
    filters=None,
    name=None,
):
    """
    Fires an Amazon Ads report request and returns the reportId immediately — no polling.
    Use this with fetch_ads_report() for the two-step (request now, download later) pattern.

    Parameters:
    - access_token  : from zv_ads_client_access()
    - client_id     : from zv_ads_client_access()
    - profile_id    : advertiser profile ID — use get_ads_profiles() to find it
    - region        : 'NA', 'EU', or 'FE'
    - report_type_id: e.g. 'spAdvertisedProduct', 'spTargeting', etc.
    - ad_product    : 'SPONSORED_PRODUCTS', 'SPONSORED_BRANDS', or 'SPONSORED_DISPLAY'
    - start_date    : 'YYYY-MM-DD'
    - end_date      : 'YYYY-MM-DD'
    - columns       : list of metric/dimension column names
    - group_by      : list, e.g. ['advertiser'] or ['asin']
    - time_unit     : 'DAILY' (default)
    - filters       : list of filter dicts — defaults to all campaign statuses
    - name          : report name string (optional)

    Returns:
    - reportId string
    """
    if filters is None:
        filters = STATE_FILTER

    headers  = _report_headers(access_token, client_id, profile_id)
    base_url = ADS_BASE_URLS[region]

    body = {
        'configuration': {
            'adProduct':    ad_product,
            'reportTypeId': report_type_id,
            'columns':      columns,
            'groupBy':      group_by,
            'timeUnit':     time_unit,
            'format':       'GZIP_JSON',
            'filters':      filters,
        },
        'startDate': start_date,
        'endDate':   end_date,
        'name':      name or f'{report_type_id}_{start_date}_{end_date}',
    }

    print(f'[report] Requesting {report_type_id} ({start_date} → {end_date}, profile {profile_id})...')

    for attempt in range(10):
        response = requests.post(f'{base_url}/reporting/reports', headers=headers, json=body)
        if response.status_code != 429:
            break
        retry_after = int(response.headers.get('Retry-After', 60))
        print(f'[report] 429 throttled — waiting {retry_after}s (attempt {attempt + 1}/10)...')
        time.sleep(retry_after)

    # 425 = duplicate request — Amazon returns the existing reportId
    if response.status_code == 425:
        import re
        match = re.search(r'([0-9a-f-]{36})', response.text)
        if match:
            report_id = match.group(1)
            print(f'[report] Duplicate — reusing existing reportId: {report_id}')
            return report_id
        raise ValueError(f'[report] Duplicate but could not extract reportId: {response.text}')

    if response.status_code != 200:
        raise ValueError(f'[report] Request failed: {response.status_code} - {response.text}')

    report_id = response.json().get('reportId')
    print(f'[report] reportId: {report_id}')
    return report_id


def fetch_ads_report(access_token, client_id, profile_id, region, report_id):
    """
    Polls an existing Amazon Ads report until COMPLETED, then downloads and returns the data.
    Re-polls fresh on every call — always gets a valid URL regardless of timing.
    Use this with create_ads_report() for the two-step (request now, download later) pattern.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - profile_id   : the same profile ID used in create_ads_report()
    - region       : 'NA', 'EU', or 'FE'
    - report_id    : reportId string returned by create_ads_report()

    Returns:
    - list of dicts (one per row)
    """
    headers  = _report_headers(access_token, client_id, profile_id)
    base_url = ADS_BASE_URLS[region]

    print(f'[report] Polling reportId {report_id} (profile {profile_id})...')
    elapsed = 0

    for attempt in range(360):  # up to ~6hrs (3hrs typical max + buffer)
        sleep_secs = min(5 * (2 ** attempt), 60)
        time.sleep(sleep_secs)
        elapsed += sleep_secs

        status_response = requests.get(
            f'{base_url}/reporting/reports/{report_id}', headers=headers
        )

        # 429 — throttled, respect Retry-After
        if status_response.status_code == 429:
            retry_after = int(status_response.headers.get('Retry-After', 60))
            print(f'[report] 429 throttled — waiting {retry_after}s...')
            time.sleep(retry_after)
            continue

        if status_response.status_code != 200:
            raise ValueError(f'[report] Poll failed: {status_response.status_code} - {status_response.text}')

        status_data = status_response.json()
        status      = status_data.get('status', '')
        print(f'[report] attempt {attempt + 1} (~{elapsed}s): {status}')

        if status == 'COMPLETED':
            download_url = status_data['url']
            break
        elif status == 'FAILED':
            raise ValueError(f'[report] Report failed: {status_data.get("failureReason")}')
    else:
        raise TimeoutError('[report] Timed out after ~6 hours.')

    print(f'[report] Downloading...')
    with tempfile.NamedTemporaryFile(delete=False, suffix='.json.gz') as tmp:
        tmp_path = tmp.name

    _stream_to_file(download_url, tmp_path)
    data = parse_export_file(tmp_path)
    os.unlink(tmp_path)
    gc.collect()
    print(f'[report] Done — {len(data)} records.')
    return data


def get_ads_report(
    access_token,
    client_id,
    profile_id,
    region,
    report_type_id,
    ad_product,
    start_date,
    end_date,
    columns,
    group_by,
    time_unit='DAILY',
    filters=None,
    name=None,
):
    """
    Combined: creates report request + polls until COMPLETED + downloads.
    Returns list of dicts. For interactive/Colab use.
    For production VPS, use create_ads_report() + fetch_ads_report() separately.
    """
    report_id = create_ads_report(
        access_token, client_id, profile_id, region,
        report_type_id, ad_product, start_date, end_date,
        columns, group_by, time_unit, filters, name,
    )
    return fetch_ads_report(access_token, client_id, profile_id, region, report_id)
