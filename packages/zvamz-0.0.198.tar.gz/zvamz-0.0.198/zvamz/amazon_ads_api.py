import gc
import gzip
import json
import os
import requests
import tempfile
import time

ADS_BASE_URLS = {
    'NA': 'https://advertising-api.amazon.com',
    'EU': 'https://advertising-api-eu.amazon.com',
    'FE': 'https://advertising-api-fe.amazon.com',
}

EXPORT_CONTENT_TYPES = {
    'campaigns': 'application/vnd.campaignsexport.v1+json',
    'adGroups':  'application/vnd.adgroupsexport.v1+json',
    'targets':   'application/vnd.targetsexport.v1+json',
    'ads':       'application/vnd.adsexport.v1+json',
}


def zv_ads_client_access(username, region):
    """
    Authentication for Amazon Ads API. ZV Data Automation clients only.

    Parameters:
    - username : registered username on zvdataautomation.com
    - region   : 'NA', 'EU', or 'FE'

    Returns:
    - dict { 'access_token', 'client_id' }
    """
    response = requests.post(
        "https://zvdataautomation.com/zvadsauth/",
        json={"username": username, "region": region},
    )
    if response.status_code == 200:
        data = response.json()
        print('Ads Access Token granted — 1 hour validity.')
        return {'access_token': data['access_token'], 'client_id': data['client_id']}
    else:
        raise ValueError(f"zv_ads_client_access failed: {response.json().get('error', 'Not Authenticated')}")


def get_ads_profiles(access_token, client_id, region):
    """
    Lists all Amazon Ads profiles for the authenticated account.
    Use this to look up profileId values needed for all Ads API calls.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - region       : 'NA', 'EU', or 'FE'

    Returns:
    - list of profile dicts — each has profileId, countryCode, accountInfo, etc.

    Example — filter to one advertiser across all countries:
        profiles = get_ads_profiles(token, client_id, 'NA')
        mjt = [p for p in profiles if 'M & J Trading' in p.get('accountInfo', {}).get('name', '')]
    """
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Amazon-Advertising-API-ClientId': client_id,
        'Content-Type': 'application/json',
    }
    response = requests.get(f'{ADS_BASE_URLS[region]}/v2/profiles', headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        raise ValueError(f'get_ads_profiles failed: {response.status_code} - {response.text}')


def _export_headers(access_token, client_id, profile_id, entity_type):
    content_type = EXPORT_CONTENT_TYPES[entity_type]
    return {
        'Authorization': f'Bearer {access_token}',
        'Amazon-Advertising-API-ClientId': client_id,
        'Amazon-Advertising-API-Scope': str(profile_id),
        'Content-Type': content_type,
        'Accept': content_type,
    }


def _poll_until_completed(headers, base_url, export_id):
    """Polls GET /exports/{exportId} until COMPLETED. Returns the S3 download URL."""
    elapsed = 0
    for attempt in range(63):
        sleep_secs = min(5 * (2 ** attempt), 60)
        time.sleep(sleep_secs)
        elapsed += sleep_secs

        status_response = requests.get(f'{base_url}/exports/{export_id}', headers=headers)
        if status_response.status_code != 200:
            raise ValueError(f'[export] Poll failed: {status_response.status_code} - {status_response.text}')

        status_data = status_response.json()
        status = status_data.get('status', '')
        print(f'[export] attempt {attempt + 1} (~{elapsed}s): {status}')

        if status == 'COMPLETED':
            return status_data['url']
        elif status == 'FAILED':
            raise ValueError(f'[export] Export failed: {status_data}')
    raise TimeoutError('[export] Timed out after ~60 minutes.')


def _stream_to_file(download_url, file_path):
    """Streams S3 download to file_path in 8KB chunks — never holds full file in RAM."""
    response = requests.get(download_url, stream=True)
    if response.status_code != 200:
        raise ValueError(f'[export] Download failed: {response.status_code}')
    with open(file_path, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
    del response
    gc.collect()


def parse_export_file(file_path):
    """Parses a gzip JSON export file into a list of dicts."""
    with gzip.open(file_path, 'rb') as f:
        return json.load(f)


def _poll_and_download(headers, base_url, export_id):
    """Polls until COMPLETED, streams to temp file, parses, cleans up. Returns list of dicts."""
    download_url = _poll_until_completed(headers, base_url, export_id)

    print(f'[export] Downloading...')
    with tempfile.NamedTemporaryFile(delete=False, suffix='.json.gz') as tmp:
        tmp_path = tmp.name

    _stream_to_file(download_url, tmp_path)
    data = parse_export_file(tmp_path)
    os.unlink(tmp_path)
    gc.collect()
    print(f'[export] Done — {len(data)} records.')
    return data


def download_export_file(access_token, client_id, profile_id, region, entity_type, export_id, file_path):
    """
    Polls an export until COMPLETED, then streams the gzip file to file_path. No parsing.
    Use this with prefetch_ads_exports() to pre-download all files before processing.

    Parameters:
    - file_path : destination path, e.g. '/tmp/ads/SP_campaigns_12345.json.gz'
    """
    if entity_type not in EXPORT_CONTENT_TYPES:
        raise ValueError(f"entity_type must be one of: {list(EXPORT_CONTENT_TYPES.keys())}")

    headers  = _export_headers(access_token, client_id, profile_id, entity_type)
    base_url = ADS_BASE_URLS[region]

    print(f'[export] Polling {entity_type} exportId {export_id} (profile {profile_id})...')
    download_url = _poll_until_completed(headers, base_url, export_id)
    print(f'[export] Saving to {file_path}...')
    _stream_to_file(download_url, file_path)
    print(f'[export] Saved.')


def create_ads_export(
    access_token,
    client_id,
    profile_id,
    region,
    entity_type,
    ad_product,
    state_filter='ENABLED,PAUSED,ARCHIVED',
    negative_filter=None,
    target_level_filter=None,
    target_type_filter=None,
):
    """
    Fires an Amazon Ads export request and returns the exportId immediately — no polling.
    Use this with fetch_ads_export() for the two-step (request now, download later) pattern.

    Parameters:
    - access_token       : from zv_ads_client_access()
    - client_id          : from zv_ads_client_access()
    - profile_id         : advertiser profile ID — use get_ads_profiles() to find it
    - region             : 'NA', 'EU', or 'FE'
    - entity_type        : 'campaigns', 'adGroups', 'targets', or 'ads'
    - ad_product         : 'SPONSORED_PRODUCTS', 'SPONSORED_BRANDS', or 'SPONSORED_DISPLAY'
    - state_filter       : list or comma-separated string — default 'ENABLED,PAUSED,ARCHIVED'

    Targets-only parameters (ignored for other entity types):
    - negative_filter      : list — ['false'] positive only, ['true'] negative only, None = both
    - target_level_filter  : list — ['AD_GROUP'], ['CAMPAIGN'], or None = both
    - target_type_filter   : list — e.g. ['KEYWORD','PRODUCT','AUTO'] or None = all types

    Returns:
    - exportId string — save this and pass to fetch_ads_export() to download
    """
    if entity_type not in EXPORT_CONTENT_TYPES:
        raise ValueError(f"entity_type must be one of: {list(EXPORT_CONTENT_TYPES.keys())}")

    def to_list(val):
        if val is None:
            return None
        return val if isinstance(val, list) else val.split(',')

    body = {
        'adProductFilter': to_list(ad_product) or [ad_product],
        'stateFilter': to_list(state_filter),
    }

    if entity_type == 'targets':
        if negative_filter is not None:
            body['negativeFilter'] = negative_filter
        if target_level_filter is not None:
            body['targetLevelFilter'] = target_level_filter
        if target_type_filter is not None:
            body['targetTypeFilter'] = target_type_filter

    headers = _export_headers(access_token, client_id, profile_id, entity_type)
    base_url = ADS_BASE_URLS[region]

    print(f'[export] Requesting {entity_type} export for {ad_product} (profile {profile_id})...')
    response = requests.post(f'{base_url}/{entity_type}/export', headers=headers, json=body)

    if response.status_code != 202:
        raise ValueError(f'[export] Request failed: {response.status_code} - {response.text}')

    export_id = response.json().get('exportId')
    print(f'[export] exportId: {export_id}')
    return export_id


def fetch_ads_export(access_token, client_id, profile_id, region, entity_type, export_id):
    """
    Polls an existing Amazon Ads export until COMPLETED, then downloads and returns the data.
    Use this with create_ads_export() for the two-step (request now, download later) pattern.

    Parameters:
    - access_token : from zv_ads_client_access()
    - client_id    : from zv_ads_client_access()
    - profile_id   : the same profile ID used in create_ads_export()
    - region       : 'NA', 'EU', or 'FE'
    - entity_type  : 'campaigns', 'adGroups', 'targets', or 'ads'
    - export_id    : exportId string returned by create_ads_export()

    Returns:
    - list of dicts (one per entity record)
    """
    if entity_type not in EXPORT_CONTENT_TYPES:
        raise ValueError(f"entity_type must be one of: {list(EXPORT_CONTENT_TYPES.keys())}")

    headers = _export_headers(access_token, client_id, profile_id, entity_type)
    base_url = ADS_BASE_URLS[region]

    print(f'[export] Polling {entity_type} exportId {export_id} (profile {profile_id})...')
    return _poll_and_download(headers, base_url, export_id)


def get_ads_export(
    access_token,
    client_id,
    profile_id,
    region,
    entity_type,
    ad_product,
    state_filter='ENABLED,PAUSED,ARCHIVED',
    negative_filter=None,
    target_level_filter=None,
    target_type_filter=None,
):
    """
    Requests and downloads an Amazon Ads export for a given entity type and ad product.
    Returns the parsed JSON data as a list of dicts.

    Uses the Exports API (replacement for Snapshots). Returns campaign structure metadata
    only — no performance metrics. Use reporting API functions for impressions/clicks/spend.

    Parameters:
    - access_token       : from zv_ads_client_access()
    - client_id          : from zv_ads_client_access()
    - profile_id         : advertiser profile ID — use get_ads_profiles() to find it
    - region             : 'NA', 'EU', or 'FE'
    - entity_type        : 'campaigns', 'adGroups', 'targets', or 'ads'
    - ad_product         : 'SPONSORED_PRODUCTS', 'SPONSORED_BRANDS', or 'SPONSORED_DISPLAY'
                           (or a list: ['SPONSORED_PRODUCTS', 'SPONSORED_BRANDS'])
    - state_filter       : list or comma-separated string — default 'ENABLED,PAUSED,ARCHIVED'

    Targets-only parameters (ignored for other entity types):
    - negative_filter      : list — ['false'] positive only, ['true'] negative only, None = both
    - target_level_filter  : list — ['AD_GROUP'], ['CAMPAIGN'], or None = both
    - target_type_filter   : list — e.g. ['KEYWORD','PRODUCT','AUTO'] or None = all types
                             Options: AUDIENCE, AUTO, KEYWORD, PRODUCT, PRODUCT_AUDIENCE,
                                      PRODUCT_CATEGORY, PRODUCT_CATEGORY_AUDIENCE, THEME

    Returns:
    - list of dicts (one per entity record)

    Example:
        auth = zv_ads_client_access('mjt_arvin', 'NA')

        # All SP campaigns
        campaigns = get_ads_export(auth['access_token'], auth['client_id'],
                                   1546111973526309, 'NA',
                                   'campaigns', 'SPONSORED_PRODUCTS')

        # SP keywords + product targets only (no negatives)
        targets = get_ads_export(auth['access_token'], auth['client_id'],
                                 1546111973526309, 'NA',
                                 'targets', 'SPONSORED_PRODUCTS',
                                 negative_filter=['false'],
                                 target_type_filter=['KEYWORD', 'PRODUCT', 'AUTO'])
    """
    export_id = create_ads_export(
        access_token, client_id, profile_id, region, entity_type, ad_product,
        state_filter, negative_filter, target_level_filter, target_type_filter,
    )
    return fetch_ads_export(access_token, client_id, profile_id, region, entity_type, export_id)
