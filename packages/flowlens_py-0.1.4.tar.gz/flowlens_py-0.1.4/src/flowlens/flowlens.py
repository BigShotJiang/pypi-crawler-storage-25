import sys
import webbrowser
import os
import time
import functools
from dataclasses import dataclass

@dataclass(slots=True, frozen=True)
class FunctionStats:
    calls: int
    total_time: float
    @property
    def average_time(self) -> float:
        return self.total_time / self.calls if self.calls > 0 else 0.0

class FlowLens:
    def __init__(self):
        self.steps = []
        self.indent_level = 0
        self.registry = {}

    def track_stats(self, func):
        """Decorador para medir rendimiento y registrar funciones en el radar."""
        _stats = {"calls": 0, "total_time": 0.0}
        self.registry[func.__name__] = _stats
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            start = time.perf_counter()
            try: 
                return func(*args, **kwargs)
            finally:
                duration = time.perf_counter() - start
                _stats["total_time"] += duration
                _stats["calls"] += 1
                # Si la función está en el timeline, actualizamos su tiempo
                if self.steps and self.steps[-1]['func'] == func.__name__:
                    self.steps[-1]['ms'] = round(duration * 1000, 4)
        return wrapper

    def _tracer(self, frame, event, arg):
        """Motor de rastreo basado en inspección de frames."""
        filename = frame.f_code.co_filename
        
        # Filtro: Ignorar librerías internas de Python y el propio archivo flowlens.py
        if "site-packages" in filename or "flowlens.py" in filename or "<" in filename:
            return self._tracer
        
        func_name = frame.f_code.co_name
        # Ignorar funciones administrativas y de sistema
        if func_name in ["run_test", "menu", "<module>", "input", "wrapper", "_tracer", "_render", "stop"]: 
            return self._tracer

        if event == 'call':
            # Detección de intención (Salida de datos vs Proceso interno)
            is_output = any(x in func_name.lower() for x in ["print", "show", "display", "output", "render"])
            comment = "📢 DATA OUTPUT" if is_output else "⚙️ INTERNAL PROCESS / CALCULATION"
            
            # Captura segura de argumentos
            try:
                local_vars = {k: str(v) for k, v in frame.f_locals.items() if not k.startswith('__')}
            except Exception:
                local_vars = "Error al capturar datos"

            self.steps.append({
                "type": "START", 
                "func": func_name, 
                "line": frame.f_lineno,
                "data": local_vars, 
                "level": self.indent_level,
                "action": comment,
                "ms": 0
            })
            self.indent_level += 1
            
        elif event == 'return':
            self.indent_level = max(0, self.indent_level - 1)
            self.steps.append({
                "type": "END", 
                "func": func_name, 
                "line": frame.f_lineno,
                "data": str(arg), 
                "level": self.indent_level,
                "ms": 0
            })
        return self._tracer

    def start(self):
        """Inicia el motor de auditoría."""
        self.steps = []
        self.indent_level = 0
        sys.settrace(self._tracer)
        print("🔍 FlowLens: Auditando procesos...")

    def stop(self):
        """Detiene el motor y genera el reporte visual."""
        sys.settrace(None)
        print("✅ Rastreo finalizado. Generando reporte...")
        self._render()

    def _render(self):
        """Genera el HTML con estilo oscuro y timeline profesional."""
        blocks = ""
        for step in self.steps:
            is_start = step['type'] == "START"
            color = "#58a6ff" if is_start else "#7ee787"
            margin = step['level'] * 40
            
            status_text = step.get('action', '') if is_start else "🏁 PROCESS COMPLETED"
            meta_label = "📥 Arguments received" if is_start else "📤 Data generated"
            time_info = f"<span class='perf'>⏱️ {step.get('ms', 0)}ms</span>" if not is_start and step.get('ms', 0) > 0 else ""

            blocks += f"""
            <div class="trace-box" style="margin-left:{margin}px; border-left: 3px solid {color}">
                <div class="action-label">{status_text}</div>
                <div class="node">
                    <div class="node-header">
                        <span class="tag" style="background:{color}">{step['type']}</span>
                        <strong>{step['func']}</strong> {time_info}
                    </div>
                    <div class="node-body">
                        <small>Line {step['line']} | {meta_label}:</small><br>
                        <code>{step['data']}</code>
                    </div>
                </div>
            </div>"""

        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>FlowLens Audit Timeline</title>
            <style>
                body {{ background: #0d1117; color: #c9d1d9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; line-height: 1.6; }}
                h1 {{ color: #58a6ff; text-align: center; margin-bottom: 5px; }}
                .subtitle {{ text-align: center; color: #8b949e; margin-bottom: 5px; font-size: 14px; }}
                .email {{ text-align: center; color: #58a6ff; margin-bottom: 40px; font-size: 12px; font-family: 'Consolas', monospace; }}
                .timeline {{ max-width: 900px; margin: 0 auto; }}
                .trace-box {{ position: relative; padding: 10px 0 10px 25px; margin-bottom: 5px; }}
                .action-label {{ font-size: 10px; color: #8b949e; margin-bottom: 4px; font-weight: bold; letter-spacing: 1px; }}
                .node {{ background: #161b22; padding: 12px 18px; border-radius: 6px; border: 1px solid #30363d; min-width: 350px; display: inline-block; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }}
                .tag {{ font-size: 9px; color: #0d1117; padding: 2px 6px; border-radius: 3px; margin-right: 10px; font-weight: 800; }}
                .perf {{ color: #d29922; font-size: 11px; margin-left: 10px; font-weight: bold; }}
                .node-body {{ margin-top: 8px; font-size: 12px; color: #8b949e; }}
                code {{ color: #ffa657; background: #070a0e; padding: 3px 6px; border-radius: 4px; display: inline-block; margin-top: 5px; font-family: 'Consolas', monospace; border: 1px solid #30363d; }}
                footer {{ text-align: center; margin-top: 50px; font-size: 11px; color: #484f58; border-top: 1px solid #30363d; padding-top: 20px; }}
            </style>
        </head>
        <body>
            <h1>FlowLens Audit Timeline</h1>
            <p class="subtitle">Desarrollado por Hans Clisman Saldias Mura</p>
            <p class="email text-blue-400">dev.hans.saldias@gmail.com</p>
            <div class="timeline">{blocks}</div>
            <footer>
                Generado automáticamente por el motor FlowLens-py<br>
                © {time.strftime("%Y")} | Hans Clisman Saldias Mura
            </footer>
        </body>
        </html>"""
        
        path = os.path.abspath("flowlens_report.html")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(html)
            webbrowser.open("file://" + path.replace("\\", "/"))
            print(f"✨ Reporte generado exitosamente.")
        except Exception as e:
            print(f"❌ Error al guardar el reporte: {e}")
# Instancia única para exportar
lens = FlowLens()