import pandas as _pd


def _index(x):
    return [ind - 1 for ind in x]


def eortc_qlqc30(x):
    """Scoring for EORTC QLQ-C30

    Calculate the three scores: qol (higher better), functional scale (higher
    better), symptoms scale (lower better),
    following scoring manual available here
    https://www.eortc.org/app/uploads/sites/2/2018/02/SCmanual.pdf

    Parameters
    ----------
    x: pd.DataFrame
        data frame of 30 QLQ-C30 items, one item per column (patient in row)

    Returns
    -------
    rval: pd.DataFrame
        data frame with 3 columns, qol (general QOL), funct and sympts
    """
    qdv_items = [29, 30]
    funct_items = list(range(1, 7+1)) + list(range(20, 27+1))
    sympts_items = list(range(8, 19+1)) + [28]
    # extract data
    qdv = x.iloc[:, _index(qdv_items)]
    funct = x.iloc[:, _index(funct_items)]
    sympts = x.iloc[:, _index(sympts_items)]
    funct_score = (1 - ((funct.mean(axis=1) - 1)/3)) * 100
    qdv_score = ((qdv.mean(axis=1) - 1)/6) * 100
    sympts_score = ((sympts.mean(axis=1) - 1)/3) * 100
    res = _pd.concat([qdv_score, funct_score, sympts_score], axis=1)
    return res.rename({0: "qol", 1: "funct", 2: "sympts"}, axis=1)
