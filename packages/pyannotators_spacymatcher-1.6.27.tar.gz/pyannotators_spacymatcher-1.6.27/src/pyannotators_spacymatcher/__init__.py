"""SpacyMatcher annotator using the spacy rule-matching engine"""

__version__ = "1.6.27"
