from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone

from memorymaster.embeddings import EmbeddingProvider, cosine_similarity
from memorymaster.models import (
    ActionProposal,
    CLAIM_LINK_TYPES,
    CLAIM_STATUSES,
    MEDIA_RETRY_STATUSES,
    STATUS_TRANSITION_EVENT_TYPES,
    Citation,
    CitationInput,
    Claim,
    ClaimLink,
    EvidenceItem,
    Event,
    ExternalSource,
    MediaRetryItem,
    SourceItem,
    validate_event_payload,
    validate_event_type,
    validate_transition_event_type,
)
from memorymaster.retry import connect_with_retry
from memorymaster.storage import EVENT_HASH_ALGO, SQLiteStore, generate_top_level_human_id

POSTGRES_EVENTS_APPEND_ONLY_TRIGGERS = (
    "trg_events_append_only_update",
    "trg_events_append_only_delete",
)
POSTGRES_CONFIRMED_TUPLE_GUARD_TRIGGER = "trg_claims_confirmed_tuple_guard"


def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


class PostgresStore(SQLiteStore):
    def __init__(self, dsn: str) -> None:
        self.dsn = dsn
        self._psycopg = None
        self._vector_table_available: bool | None = None

    def _load_psycopg(self):
        if self._psycopg is None:
            try:
                import psycopg  # type: ignore
                from psycopg.rows import dict_row  # type: ignore
                from psycopg.types.json import Jsonb  # type: ignore
            except Exception as exc:  # pragma: no cover
                raise RuntimeError(
                    "Postgres backend requires psycopg. Install with: pip install 'memorymaster[postgres]'"
                ) from exc
            self._psycopg = (psycopg, dict_row, Jsonb)
        return self._psycopg

    def connect(self):
        psycopg, dict_row, _ = self._load_psycopg()

        def _open():
            return psycopg.connect(self.dsn, row_factory=dict_row)

        return connect_with_retry(_open)

    def init_db(self) -> None:
        from memorymaster.schema import load_schema_postgres_sql

        sql = load_schema_postgres_sql()
        statements = self._split_sql_statements(sql)
        with self.connect() as conn, conn.cursor() as cur:
            for statement in statements:
                cur.execute(statement)
            self._ensure_confirmed_tuple_uniqueness_schema(conn)
            self._ensure_event_integrity_schema(conn)
            self._ensure_claim_links_schema(conn)
            self._ensure_human_id_schema(conn)
            self._ensure_tenant_id_schema(conn)
            self._ensure_binding_schema(conn)

    @staticmethod
    def _canonical_payload(payload: object | None) -> str:
        if payload is None:
            return ""
        if isinstance(payload, str):
            raw = payload.strip()
            if not raw:
                return ""
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError:
                return raw
            return json.dumps(parsed, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    @staticmethod
    def _compute_event_hash(
        *,
        claim_id: int | None,
        event_type: str,
        from_status: str | None,
        to_status: str | None,
        details: str | None,
        payload: object | None,
        created_at: datetime,
        prev_event_hash: str | None,
        hash_algo: str = EVENT_HASH_ALGO,
    ) -> str:
        created_iso = created_at.replace(microsecond=0).isoformat()
        components = [
            hash_algo,
            str(claim_id) if claim_id is not None else "",
            event_type,
            from_status or "",
            to_status or "",
            details or "",
            PostgresStore._canonical_payload(payload),
            created_iso,
            prev_event_hash or "",
        ]
        material = "\x1f".join(components)
        return hashlib.sha256(material.encode("utf-8")).hexdigest()

    def _ensure_event_integrity_schema(self, conn) -> None:
        with conn.cursor() as cur:
            cur.execute("ALTER TABLE events ADD COLUMN IF NOT EXISTS prev_event_hash TEXT")
            cur.execute("ALTER TABLE events ADD COLUMN IF NOT EXISTS event_hash TEXT")
            cur.execute("ALTER TABLE events ADD COLUMN IF NOT EXISTS hash_algo TEXT")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_events_event_hash ON events(event_hash)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_events_prev_event_hash ON events(prev_event_hash)")
            self._drop_events_append_only_triggers(cur)
            self._backfill_event_chain(conn)
            self._ensure_events_append_only_rules(cur)

    def _ensure_confirmed_tuple_uniqueness_schema(self, conn) -> None:
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE OR REPLACE FUNCTION memorymaster_claims_confirmed_tuple_guard()
                RETURNS trigger
                LANGUAGE plpgsql
                AS $$
                BEGIN
                    IF NEW.status = 'confirmed'
                       AND NEW.subject IS NOT NULL
                       AND NEW.predicate IS NOT NULL
                       AND EXISTS (
                           SELECT 1
                           FROM claims c
                           WHERE c.status = 'confirmed'
                             AND c.subject = NEW.subject
                             AND c.predicate = NEW.predicate
                             AND c.scope = NEW.scope
                             AND (TG_OP = 'INSERT' OR c.id <> NEW.id)
                       ) THEN
                        RAISE EXCEPTION 'only one confirmed claim is allowed per (subject,predicate,scope)'
                            USING ERRCODE = '23505';
                    END IF;
                    RETURN NEW;
                END;
                $$;
                """
            )
            cur.execute(
                f"""
                DO $$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1
                        FROM pg_trigger
                        WHERE tgname = '{POSTGRES_CONFIRMED_TUPLE_GUARD_TRIGGER}'
                          AND tgrelid = 'claims'::regclass
                    ) THEN
                        CREATE TRIGGER {POSTGRES_CONFIRMED_TUPLE_GUARD_TRIGGER}
                        BEFORE INSERT OR UPDATE OF status, subject, predicate, scope ON claims
                        FOR EACH ROW
                        EXECUTE FUNCTION memorymaster_claims_confirmed_tuple_guard();
                    END IF;
                END
                $$;
                """
            )
            self._try_create_confirmed_tuple_unique_index(cur)

    @staticmethod
    def _try_create_confirmed_tuple_unique_index(cur) -> None:
        savepoint = "sp_claims_confirmed_tuple_unique_idx"
        cur.execute(f"SAVEPOINT {savepoint}")
        try:
            cur.execute(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS idx_claims_confirmed_tuple_unique
                ON claims(subject, predicate, scope)
                WHERE status = 'confirmed'
                  AND subject IS NOT NULL
                  AND predicate IS NOT NULL
                """
            )
        except Exception as exc:
            cur.execute(f"ROLLBACK TO SAVEPOINT {savepoint}")
            cur.execute(f"RELEASE SAVEPOINT {savepoint}")
            lowered = str(exc).lower()
            if (
                "could not create unique index" in lowered
                or "duplicate key value" in lowered
                or "is duplicated" in lowered
            ):
                return
            raise
        cur.execute(f"RELEASE SAVEPOINT {savepoint}")

    @staticmethod
    def _drop_events_append_only_triggers(cur) -> None:
        for trigger in POSTGRES_EVENTS_APPEND_ONLY_TRIGGERS:
            cur.execute(f"DROP TRIGGER IF EXISTS {trigger} ON events")

    @staticmethod
    def _ensure_events_append_only_rules(cur) -> None:
        cur.execute(
            """
            CREATE OR REPLACE FUNCTION memorymaster_events_append_only_guard()
            RETURNS trigger
            LANGUAGE plpgsql
            AS $$
            BEGIN
                RAISE EXCEPTION 'events table is append-only; % is not allowed', TG_OP;
            END;
            $$;
            """
        )
        cur.execute(
            """
            DO $$
            BEGIN
                IF NOT EXISTS (
                    SELECT 1
                    FROM pg_trigger
                    WHERE tgname = 'trg_events_append_only_update'
                      AND tgrelid = 'events'::regclass
                ) THEN
                    CREATE TRIGGER trg_events_append_only_update
                    BEFORE UPDATE ON events
                    FOR EACH ROW
                    EXECUTE FUNCTION memorymaster_events_append_only_guard();
                END IF;
            END
            $$;
            """
        )
        cur.execute(
            """
            DO $$
            BEGIN
                IF NOT EXISTS (
                    SELECT 1
                    FROM pg_trigger
                    WHERE tgname = 'trg_events_append_only_delete'
                      AND tgrelid = 'events'::regclass
                ) THEN
                    CREATE TRIGGER trg_events_append_only_delete
                    BEFORE DELETE ON events
                    FOR EACH ROW
                    EXECUTE FUNCTION memorymaster_events_append_only_guard();
                END IF;
            END
            $$;
            """
        )

    def _backfill_event_chain(self, conn, *, rebuild_all: bool = False) -> int:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT id, claim_id, event_type, from_status, to_status, details, payload_json, created_at, event_hash, hash_algo
                FROM events
                ORDER BY id ASC
                """
            )
            rows = cur.fetchall()
            if not rows:
                return 0

            updated = 0
            prev_hash: str | None = None
            for row in rows:
                row_hash = row.get("event_hash")
                row_algo = row.get("hash_algo")
                if row_hash and not rebuild_all:
                    prev_hash = str(row_hash)
                    continue

                algo = str(row_algo) if row_algo else EVENT_HASH_ALGO
                payload = row.get("payload_json")
                created_at = row["created_at"]
                if not isinstance(created_at, datetime):
                    created_at = datetime.fromisoformat(str(created_at))
                event_hash = self._compute_event_hash(
                    claim_id=int(row["claim_id"]) if row["claim_id"] is not None else None,
                    event_type=str(row["event_type"]),
                    from_status=self._as_text(row["from_status"]),
                    to_status=self._as_text(row["to_status"]),
                    details=self._as_text(row["details"]),
                    payload=payload,
                    created_at=created_at,
                    prev_event_hash=prev_hash,
                    hash_algo=algo,
                )
                cur.execute(
                    "UPDATE events SET prev_event_hash = %s, event_hash = %s, hash_algo = %s WHERE id = %s",
                    (prev_hash, event_hash, algo, int(row["id"])),
                )
                updated += 1
                prev_hash = event_hash
            return updated

    def _insert_event_row(
        self,
        conn,
        *,
        claim_id: int | None,
        event_type: str,
        from_status: str | None,
        to_status: str | None,
        details: str | None,
        payload: dict[str, object] | None,
        created_at: datetime,
    ) -> int:
        _, _, Jsonb = self._load_psycopg()
        with conn.cursor() as cur:
            cur.execute("SELECT event_hash FROM events WHERE event_hash IS NOT NULL ORDER BY id DESC LIMIT 1")
            prev_row = cur.fetchone()
            prev_event_hash = str(prev_row["event_hash"]) if prev_row and prev_row.get("event_hash") else None
            event_hash = self._compute_event_hash(
                claim_id=claim_id,
                event_type=event_type,
                from_status=from_status,
                to_status=to_status,
                details=details,
                payload=payload,
                created_at=created_at,
                prev_event_hash=prev_event_hash,
                hash_algo=EVENT_HASH_ALGO,
            )
            cur.execute(
                """
                INSERT INTO events (
                    claim_id, event_type, from_status, to_status, details, payload_json, created_at,
                    prev_event_hash, event_hash, hash_algo
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (
                    claim_id,
                    event_type,
                    from_status,
                    to_status,
                    details,
                    Jsonb(payload) if payload is not None else None,
                    created_at,
                    prev_event_hash,
                    event_hash,
                    EVENT_HASH_ALGO,
                ),
            )
            inserted = cur.fetchone()
        if inserted is None:
            raise RuntimeError("Failed to insert event row.")
        return int(inserted["id"])

    def create_claim(
        self,
        text: str,
        citations: list[CitationInput],
        *,
        idempotency_key: str | None = None,
        claim_type: str | None = None,
        subject: str | None = None,
        predicate: str | None = None,
        object_value: str | None = None,
        scope: str = "project",
        volatility: str = "medium",
        confidence: float = 0.5,
        tenant_id: str | None = None,
    ) -> Claim:
        if not citations:
            raise ValueError("At least one citation is required.")
        normalized_idempotency_key = (idempotency_key or "").strip() or None
        normalized_tenant_id = (tenant_id or "").strip() or None
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    INSERT INTO claims (
                        text, idempotency_key, normalized_text, claim_type, subject, predicate, object_value,
                        scope, volatility, status, confidence, pinned, supersedes_claim_id,
                        replaced_by_claim_id, created_at, updated_at, last_validated_at, archived_at,
                        tenant_id
                    ) VALUES (
                        %s, %s, NULL, %s, %s, %s, %s, %s, %s, 'candidate', %s, FALSE, NULL, NULL, %s, %s, NULL, NULL,
                        %s
                    )
                    ON CONFLICT (idempotency_key) DO NOTHING
                    RETURNING id
                    """,
                (
                    text,
                    normalized_idempotency_key,
                    claim_type,
                    subject,
                    predicate,
                    object_value,
                    scope,
                    volatility,
                    confidence,
                    now,
                    now,
                    normalized_tenant_id,
                ),
            )
            claim_row = cur.fetchone()
            if claim_row is None:
                if normalized_idempotency_key is None:
                    raise RuntimeError("Failed to create claim.")
                cur.execute(
                    "SELECT id FROM claims WHERE idempotency_key = %s",
                    (normalized_idempotency_key,),
                )
                existing_row = cur.fetchone()
                if existing_row is None:
                    raise RuntimeError("Idempotency key matched missing claim.")
                claim_id = int(existing_row["id"])
                claim = self.get_claim(claim_id)
                if claim is None:
                    raise RuntimeError("Idempotency key matched missing claim.")
                return claim
            claim_id = int(claim_row["id"])

            # Assign a human-readable ID.
            try:
                human_id = self._allocate_human_id(cur, subject, text, claim_id)
                cur.execute(
                    "UPDATE claims SET human_id = %s WHERE id = %s",
                    (human_id, claim_id),
                )
            except Exception:
                # Column may not exist in legacy schemas; skip gracefully.
                pass

            for cite in citations:
                cur.execute(
                    """
                        INSERT INTO citations (claim_id, source, locator, excerpt, created_at)
                        VALUES (%s, %s, %s, %s, %s)
                        """,
                    (claim_id, cite.source, cite.locator, cite.excerpt, now),
                )
            ingest_payload = validate_event_payload(
                "ingest",
                {"citation_count": len(citations)},
                details="claim_ingested",
            )
            self._insert_event_row(
                conn,
                claim_id=claim_id,
                event_type="ingest",
                from_status=None,
                to_status="candidate",
                details="claim_ingested",
                payload=ingest_payload,
                created_at=now,
            )

        claim = self.get_claim(claim_id)
        if claim is None:
            raise RuntimeError("Failed to load claim after insert.")
        return claim

    def get_claim(self, claim_id: int, include_citations: bool = True) -> Claim | None:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM claims WHERE id = %s", (claim_id,))
            row = cur.fetchone()
        if row is None:
            return None
        claim = self._row_to_claim(row)
        if include_citations:
            claim.citations = self.list_citations(claim.id)
        return claim

    def get_claim_by_idempotency_key(self, idempotency_key: str, include_citations: bool = True) -> Claim | None:
        normalized_idempotency_key = idempotency_key.strip()
        if not normalized_idempotency_key:
            return None
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM claims WHERE idempotency_key = %s",
                (normalized_idempotency_key,),
            )
            row = cur.fetchone()
        if row is None:
            return None
        claim = self._row_to_claim(row)
        if include_citations:
            claim.citations = self.list_citations(claim.id)
        return claim

    def list_claims(
        self,
        *,
        status: str | None = None,
        status_in: list[str] | None = None,
        limit: int = 50,
        include_archived: bool = False,
        text_query: str | None = None,
        include_citations: bool = False,
        scope_allowlist: list[str] | None = None,
        tenant_id: str | None = None,
    ) -> list[Claim]:
        clauses: list[str] = []
        params: list[object] = []

        if tenant_id is not None:
            clauses.append("tenant_id = %s")
            params.append(tenant_id)

        if status is not None:
            clauses.append("status = %s")
            params.append(status)
        elif status_in:
            placeholders = ",".join("%s" for _ in status_in)
            clauses.append(f"status IN ({placeholders})")
            params.extend(status_in)

        if not include_archived and status != "archived":
            clauses.append("status <> 'archived'")

        if text_query:
            clauses.append("(LOWER(text) LIKE %s OR LOWER(COALESCE(normalized_text, '')) LIKE %s)")
            needle = f"%{text_query.lower()}%"
            params.extend([needle, needle])

        if scope_allowlist:
            normalized_scopes = [scope.strip() for scope in scope_allowlist if scope and scope.strip()]
            if normalized_scopes:
                placeholders = ",".join("%s" for _ in normalized_scopes)
                clauses.append(f"scope IN ({placeholders})")
                params.extend(normalized_scopes)

        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"""
            SELECT * FROM claims
            {where_sql}
            ORDER BY pinned DESC, confidence DESC, updated_at DESC, id DESC
            LIMIT %s
        """
        params.append(limit)

        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()

        claims = [self._row_to_claim(row) for row in rows]
        if include_citations:
            for claim in claims:
                claim.citations = self.list_citations(claim.id)
        return claims

    def list_citations(self, claim_id: int) -> list[Citation]:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM citations WHERE claim_id = %s ORDER BY id ASC",
                (claim_id,),
            )
            rows = cur.fetchall()
        return [self._row_to_citation(row) for row in rows]

    def list_events(
        self,
        claim_id: int | None = None,
        limit: int = 100,
        event_type: str | None = None,
    ) -> list[Event]:
        clauses: list[str] = []
        params: list[object] = []

        if claim_id is not None:
            clauses.append("claim_id = %s")
            params.append(claim_id)
        if event_type is not None:
            clauses.append("event_type = %s")
            params.append(event_type)

        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT * FROM events {where_sql} ORDER BY created_at DESC, id DESC LIMIT %s"
        params.append(limit)

        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
        return [self._row_to_event(row) for row in rows]

    def count_citations(self, claim_id: int) -> int:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS c FROM citations WHERE claim_id = %s", (claim_id,))
            row = cur.fetchone()
        return int(row["c"]) if row is not None else 0

    def list_citations_batch(self, claim_ids: list[int]) -> dict[int, list[Citation]]:
        if not claim_ids:
            return {}
        return {claim_id: self.list_citations(claim_id) for claim_id in claim_ids}

    def count_citations_batch(self, claim_ids: list[int]) -> dict[int, int]:
        if not claim_ids:
            return {}
        return {claim_id: self.count_citations(claim_id) for claim_id in claim_ids}

    def set_normalized_text(self, claim_id: int, normalized_text: str) -> None:
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "UPDATE claims SET normalized_text = %s, updated_at = %s WHERE id = %s",
                (normalized_text, now, claim_id),
            )

    def set_normalized_texts_batch(self, updates: dict[int, str]) -> None:
        if not updates:
            return
        for claim_id, normalized_text in updates.items():
            self.set_normalized_text(claim_id, normalized_text)

    def redact_claim_payload(
        self,
        claim_id: int,
        *,
        mode: str = "redact",
        redact_claim: bool = True,
        redact_citations: bool = True,
        reason: str | None = None,
        actor: str = "system",
    ) -> dict[str, object]:
        normalized_mode = str(mode).strip().lower()
        if normalized_mode not in {"redact", "erase"}:
            raise ValueError("mode must be one of: redact, erase.")
        if not redact_claim and not redact_citations:
            raise ValueError("At least one of redact_claim or redact_citations must be true.")

        now = utc_now()
        details = "claim_payload_redacted" if normalized_mode == "redact" else "claim_payload_erased"
        claim_text = "[REDACTED_CLAIM_TEXT]" if normalized_mode == "redact" else "[ERASED_CLAIM_TEXT]"
        subject_value = "[REDACTED]" if normalized_mode == "redact" else None
        predicate_value = "[REDACTED]" if normalized_mode == "redact" else None
        object_value = "[REDACTED]" if normalized_mode == "redact" else None
        citation_source = "[REDACTED_SOURCE]" if normalized_mode == "redact" else "[ERASED_SOURCE]"
        citation_locator = "[REDACTED_LOCATOR]" if normalized_mode == "redact" else None
        citation_excerpt = "[REDACTED_EXCERPT]" if normalized_mode == "redact" else None

        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT status FROM claims WHERE id = %s", (claim_id,))
            status_row = cur.fetchone()
            if status_row is None:
                raise ValueError(f"Claim {claim_id} does not exist.")
            current_status = str(status_row["status"]) if status_row["status"] is not None else None

            claim_rows = 0
            citation_rows = 0

            if redact_claim:
                cur.execute(
                    """
                        UPDATE claims
                        SET text = %s,
                            normalized_text = NULL,
                            subject = %s,
                            predicate = %s,
                            object_value = %s,
                            updated_at = %s
                        WHERE id = %s
                        """,
                    (claim_text, subject_value, predicate_value, object_value, now, claim_id),
                )
                claim_rows = int(cur.rowcount)

            if redact_citations:
                cur.execute(
                    """
                        UPDATE citations
                        SET source = %s, locator = %s, excerpt = %s
                        WHERE claim_id = %s
                        """,
                    (citation_source, citation_locator, citation_excerpt, claim_id),
                )
                citation_rows = int(cur.rowcount)
                if not redact_claim:
                    cur.execute(
                        "UPDATE claims SET updated_at = %s WHERE id = %s",
                        (now, claim_id),
                    )

            payload: dict[str, object] = {
                "source": str(actor or "system"),
                "mode": normalized_mode,
                "redact_claim": bool(redact_claim),
                "redact_citations": bool(redact_citations),
                "claim_rows": claim_rows,
                "citation_rows": citation_rows,
            }
            if reason and reason.strip():
                payload["reason"] = reason.strip()
            validated_payload = validate_event_payload("audit", payload, details=details)
            self._insert_event_row(
                conn,
                claim_id=claim_id,
                event_type="audit",
                from_status=current_status,
                to_status=current_status,
                details=details,
                payload=validated_payload,
                created_at=now,
            )

        return {
            "claim_id": claim_id,
            "mode": normalized_mode,
            "redact_claim": bool(redact_claim),
            "redact_citations": bool(redact_citations),
            "claim_rows": claim_rows,
            "citation_rows": citation_rows,
            "event_details": details,
        }

    def update_claim_structure(
        self,
        claim_id: int,
        *,
        claim_type: str | None = None,
        subject: str | None = None,
        predicate: str | None = None,
        object_value: str | None = None,
    ) -> None:
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    UPDATE claims
                    SET claim_type = COALESCE(claim_type, %s),
                        subject = COALESCE(subject, %s),
                        predicate = COALESCE(predicate, %s),
                        object_value = COALESCE(object_value, %s),
                        updated_at = %s
                    WHERE id = %s
                    """,
                (claim_type, subject, predicate, object_value, now, claim_id),
            )

    def set_confidence(self, claim_id: int, confidence: float, details: str | None = None) -> None:
        bounded = max(0.0, min(1.0, confidence))
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "UPDATE claims SET confidence = %s, updated_at = %s WHERE id = %s",
                (bounded, now, claim_id),
            )
            if details:
                cur.execute("SELECT status FROM claims WHERE id = %s", (claim_id,))
                status_row = cur.fetchone()
                current_status = str(status_row["status"]) if status_row else None
                self._insert_event_row(
                    conn,
                    claim_id=claim_id,
                    event_type="confidence",
                    from_status=current_status,
                    to_status=current_status,
                    details=details,
                    payload=None,
                    created_at=now,
                )

    def set_pinned(self, claim_id: int, pinned: bool, reason: str) -> None:
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "UPDATE claims SET pinned = %s, updated_at = %s WHERE id = %s",
                (pinned, now, claim_id),
            )
            self._insert_event_row(
                conn,
                claim_id=claim_id,
                event_type="pin" if pinned else "unpin",
                from_status=None,
                to_status=None,
                details=reason,
                payload=None,
                created_at=now,
            )

    def apply_status_transition(
        self,
        claim: Claim,
        *,
        to_status: str,
        reason: str,
        event_type: str,
        replaced_by_claim_id: int | None = None,
    ) -> Claim:
        validated_event_type = validate_transition_event_type(event_type)
        now = utc_now()
        last_validated_at = now if to_status in {"confirmed", "stale", "conflicted"} else claim.last_validated_at
        archived_at = now if to_status == "archived" else None
        next_replaced_by = replaced_by_claim_id if replaced_by_claim_id is not None else claim.replaced_by_claim_id

        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                UPDATE claims
                SET status = %s, updated_at = %s, last_validated_at = %s, archived_at = %s, replaced_by_claim_id = %s
                WHERE id = %s
                """,
                (to_status, now, last_validated_at, archived_at, next_replaced_by, claim.id),
            )
            self._insert_event_row(
                conn,
                claim_id=claim.id,
                event_type=validated_event_type,
                from_status=claim.status,
                to_status=to_status,
                details=reason,
                payload={"replaced_by_claim_id": replaced_by_claim_id} if replaced_by_claim_id else None,
                created_at=now,
            )

        updated = self.get_claim(claim.id)
        if updated is None:
            raise RuntimeError("Failed to load claim after transition.")
        return updated

    def set_supersedes(self, claim_id: int, supersedes_claim_id: int) -> None:
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    UPDATE claims
                    SET supersedes_claim_id = %s, updated_at = %s
                    WHERE id = %s
                    """,
                (supersedes_claim_id, now, claim_id),
            )

    def mark_superseded(self, old_claim_id: int, new_claim_id: int, reason: str) -> None:
        old_claim = self.get_claim(old_claim_id, include_citations=False)
        if old_claim is None:
            return
        self.apply_status_transition(
            old_claim,
            to_status="superseded",
            reason=reason,
            event_type="supersession",
            replaced_by_claim_id=new_claim_id,
        )
        self.set_supersedes(new_claim_id, old_claim_id)

    def find_by_status(self, status: str, limit: int = 100, include_citations: bool = False) -> list[Claim]:
        return self.list_claims(
            status=status,
            limit=limit,
            include_archived=True,
            include_citations=include_citations,
        )

    def find_for_decay(self, limit: int = 200) -> list[Claim]:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    SELECT * FROM claims
                    WHERE status = 'confirmed'
                      AND pinned = FALSE
                    ORDER BY updated_at ASC, id ASC
                    LIMIT %s
                    """,
                (limit,),
            )
            rows = cur.fetchall()
        return [self._row_to_claim(row) for row in rows]

    def find_for_compaction(self, retain_days: int, limit: int = 500) -> list[Claim]:
        cutoff = utc_now() - timedelta(days=retain_days)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    SELECT * FROM claims
                    WHERE status IN ('stale', 'superseded', 'conflicted')
                      AND pinned = FALSE
                      AND updated_at < %s
                    ORDER BY updated_at ASC, id ASC
                    LIMIT %s
                    """,
                (cutoff, limit),
            )
            rows = cur.fetchall()
        return [self._row_to_claim(row) for row in rows]

    def find_confirmed_by_tuple(
        self,
        *,
        subject: str | None,
        predicate: str | None,
        scope: str | None,
        exclude_claim_id: int | None = None,
    ) -> list[Claim]:
        if not subject or not predicate:
            return []

        clauses = ["status = 'confirmed'", "subject = %s", "predicate = %s", "scope = %s"]
        params: list[object] = [subject, predicate, scope or "project"]
        if exclude_claim_id is not None:
            clauses.append("id <> %s")
            params.append(exclude_claim_id)

        sql = f"""
            SELECT * FROM claims
            WHERE {' AND '.join(clauses)}
            ORDER BY confidence DESC, updated_at DESC
        """
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
        return [self._row_to_claim(row) for row in rows]

    def delete_old_events(self, retain_days: int) -> int:
        # Events are append-only by contract; retention trim is a no-op.
        return 0

    def reconcile_integrity(self, *, fix: bool = False, limit: int = 500) -> dict[str, object]:
        report: dict[str, object] = {
            "checked_at": utc_now().isoformat(),
            "fix_mode": bool(fix),
            "issues": {},
            "actions": [],
        }
        with self.connect() as conn:
            self._ensure_event_integrity_schema(conn)
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT e.id
                    FROM events e
                    LEFT JOIN claims c ON c.id = e.claim_id
                    WHERE e.claim_id IS NOT NULL AND c.id IS NULL
                    ORDER BY e.id ASC
                    LIMIT %s
                    """,
                    (limit,),
                )
                orphan_events = [int(row["id"]) for row in cur.fetchall()]

                cur.execute(
                    """
                    SELECT ci.id
                    FROM citations ci
                    LEFT JOIN claims c ON c.id = ci.claim_id
                    WHERE c.id IS NULL
                    ORDER BY ci.id ASC
                    LIMIT %s
                    """,
                    (limit,),
                )
                orphan_citations = [int(row["id"]) for row in cur.fetchall()]

                cur.execute(
                    """
                    SELECT id
                    FROM claims
                    WHERE status = 'superseded' AND replaced_by_claim_id IS NULL
                    ORDER BY id ASC
                    LIMIT %s
                    """,
                    (limit,),
                )
                superseded_without_replacement = [int(row["id"]) for row in cur.fetchall()]

                cur.execute(
                    """
                    SELECT c.id
                    FROM claims c
                    LEFT JOIN claims n ON n.id = c.replaced_by_claim_id
                    WHERE c.replaced_by_claim_id IS NOT NULL AND n.id IS NULL
                    ORDER BY c.id ASC
                    LIMIT %s
                    """,
                    (limit,),
                )
                dangling_replaced_by = [int(row["id"]) for row in cur.fetchall()]

                cur.execute(
                    """
                    SELECT c.id
                    FROM claims c
                    LEFT JOIN claims p ON p.id = c.supersedes_claim_id
                    WHERE c.supersedes_claim_id IS NOT NULL AND p.id IS NULL
                    ORDER BY c.id ASC
                    LIMIT %s
                    """,
                    (limit,),
                )
                dangling_supersedes = [int(row["id"]) for row in cur.fetchall()]

                transition_placeholders = ",".join("%s" for _ in STATUS_TRANSITION_EVENT_TYPES)
                cur.execute(
                    f"""
                    SELECT id, event_type, from_status, to_status
                    FROM events
                    WHERE event_type IN ({transition_placeholders})
                    ORDER BY id ASC
                    """,
                    list(STATUS_TRANSITION_EVENT_TYPES),
                )
                transition_rows = cur.fetchall()
                transition_issues: list[dict[str, object]] = []
                from memorymaster.lifecycle import ALLOWED_TRANSITIONS

                for row in transition_rows:
                    from_status = self._as_text(row["from_status"])
                    to_status = self._as_text(row["to_status"])
                    if from_status is None or to_status is None:
                        continue
                    if from_status not in CLAIM_STATUSES or to_status not in CLAIM_STATUSES:
                        transition_issues.append(
                            {
                                "event_id": int(row["id"]),
                                "event_type": str(row["event_type"]),
                                "reason": "unknown_status",
                                "from_status": from_status,
                                "to_status": to_status,
                            }
                        )
                        continue
                    if from_status == to_status:
                        continue
                    if to_status not in ALLOWED_TRANSITIONS.get(from_status, set()):
                        transition_issues.append(
                            {
                                "event_id": int(row["id"]),
                                "event_type": str(row["event_type"]),
                                "reason": "invalid_transition",
                                "from_status": from_status,
                                "to_status": to_status,
                            }
                        )

                cur.execute("SELECT id, prev_event_hash, event_hash, hash_algo FROM events ORDER BY id ASC")
                chain_rows = cur.fetchall()
                chain_issues: list[dict[str, object]] = []
                expected_prev: str | None = None
                for row in chain_rows:
                    row_prev = self._as_text(row["prev_event_hash"])
                    row_hash = self._as_text(row["event_hash"])
                    row_algo = self._as_text(row["hash_algo"])
                    if row_hash is None:
                        chain_issues.append({"event_id": int(row["id"]), "reason": "missing_hash"})
                        continue
                    if row_algo not in {None, EVENT_HASH_ALGO}:
                        chain_issues.append(
                            {"event_id": int(row["id"]), "reason": "unexpected_hash_algo", "hash_algo": row_algo}
                        )
                    if row_prev != expected_prev:
                        chain_issues.append(
                            {
                                "event_id": int(row["id"]),
                                "reason": "broken_prev_link",
                                "expected_prev_event_hash": expected_prev,
                                "actual_prev_event_hash": row_prev,
                            }
                        )
                    expected_prev = row_hash

                issues = {
                    "orphan_events": orphan_events,
                    "orphan_citations": orphan_citations,
                    "superseded_without_replacement": superseded_without_replacement,
                    "dangling_replaced_by": dangling_replaced_by,
                    "dangling_supersedes": dangling_supersedes,
                    "transition_issues": transition_issues[:limit],
                    "hash_chain_issues": chain_issues[:limit],
                }
                report["issues"] = issues
                report["summary"] = {
                    key: (len(value) if isinstance(value, list) else 0)
                    for key, value in issues.items()
                }

                actions: list[dict[str, object]] = []
                if fix:
                    if orphan_citations:
                        cur.execute("DELETE FROM citations WHERE id = ANY(%s)", (orphan_citations,))
                        actions.append({"action": "delete_orphan_citations", "rows": int(cur.rowcount)})
                    if orphan_events:
                        actions.append(
                            {
                                "action": "skip_delete_orphan_events_append_only",
                                "rows": 0,
                                "reason": "events table is append-only",
                            }
                        )
                    if dangling_replaced_by:
                        cur.execute(
                            "UPDATE claims SET replaced_by_claim_id = NULL WHERE id = ANY(%s)",
                            (dangling_replaced_by,),
                        )
                        actions.append({"action": "clear_dangling_replaced_by", "rows": int(cur.rowcount)})
                    if dangling_supersedes:
                        cur.execute(
                            "UPDATE claims SET supersedes_claim_id = NULL WHERE id = ANY(%s)",
                            (dangling_supersedes,),
                        )
                        actions.append({"action": "clear_dangling_supersedes", "rows": int(cur.rowcount)})
                    if chain_issues:
                        actions.append(
                            {
                                "action": "skip_rebuild_event_hash_chain_append_only",
                                "rows": 0,
                                "reason": "events table is append-only",
                            }
                        )
                report["actions"] = actions
        return report

    def record_event(
        self,
        *,
        claim_id: int | None,
        event_type: str,
        from_status: str | None = None,
        to_status: str | None = None,
        details: str | None = None,
        payload: dict[str, object] | None = None,
    ) -> None:
        validated_event_type = validate_event_type(event_type)
        validated_payload = validate_event_payload(
            validated_event_type,
            payload,
            details=details,
        )
        now = utc_now()
        with self.connect() as conn:
            self._insert_event_row(
                conn,
                claim_id=claim_id,
                event_type=validated_event_type,
                from_status=from_status,
                to_status=to_status,
                details=details,
                payload=validated_payload,
                created_at=now,
            )

    def _has_vector_table(self) -> bool:
        if self._vector_table_available is not None:
            return self._vector_table_available
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    SELECT EXISTS (
                      SELECT 1
                      FROM information_schema.tables
                      WHERE table_schema = 'public' AND table_name = 'claim_embeddings'
                    ) AS ok
                    """
            )
            row = cur.fetchone()
        self._vector_table_available = bool(row["ok"]) if row is not None else False
        return self._vector_table_available

    @staticmethod
    def _vector_literal(vec: list[float]) -> str:
        return "[" + ",".join(f"{x:.8f}" for x in vec) + "]"

    def upsert_embeddings(self, claims: list[Claim], provider: EmbeddingProvider) -> int:
        if not claims:
            return 0
        if not self._has_vector_table():
            return 0
        now = utc_now()
        rows: list[tuple[object, ...]] = []
        for claim in claims:
            text = " ".join(
                part
                for part in [claim.text, claim.normalized_text or "", claim.subject or "", claim.object_value or ""]
                if part
            )
            emb = provider.embed(text)
            rows.append((claim.id, provider.model, self._vector_literal(emb), now))

        with self.connect() as conn, conn.cursor() as cur:
            cur.executemany(
                """
                    INSERT INTO claim_embeddings (claim_id, model, embedding, updated_at)
                    VALUES (%s, %s, %s::vector, %s)
                    ON CONFLICT (claim_id) DO UPDATE SET
                      model = EXCLUDED.model,
                      embedding = EXCLUDED.embedding,
                      updated_at = EXCLUDED.updated_at
                    """,
                rows,
            )
        return len(rows)

    def vector_scores(
        self,
        query_text: str,
        claims: list[Claim],
        provider: EmbeddingProvider,
    ) -> dict[int, float]:
        if not claims:
            return {}
        if not self._has_vector_table():
            return self._vector_scores_fallback(query_text, claims, provider)

        self.upsert_embeddings(claims, provider)
        query_vec = self._vector_literal(provider.embed(query_text))
        ids = [c.id for c in claims]
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    SELECT claim_id, 1 - (embedding <=> %s::vector) AS sim
                    FROM claim_embeddings
                    WHERE claim_id = ANY(%s)
                    """,
                (query_vec, ids),
            )
            rows = cur.fetchall()
        out: dict[int, float] = {}
        for row in rows:
            sim = float(row["sim"])
            out[int(row["claim_id"])] = max(0.0, min(1.0, (sim + 1.0) / 2.0))
        return out

    def _vector_scores_fallback(
        self,
        query_text: str,
        claims: list[Claim],
        provider: EmbeddingProvider,
    ) -> dict[int, float]:
        query_vec = provider.embed(query_text)
        out: dict[int, float] = {}
        for claim in claims:
            text = " ".join(
                part
                for part in [claim.text, claim.normalized_text or "", claim.subject or "", claim.object_value or ""]
                if part
            )
            emb = provider.embed(text)
            sim = cosine_similarity(query_vec, emb)
            out[claim.id] = max(0.0, min(1.0, (sim + 1.0) / 2.0))
        return out

    @staticmethod
    def _as_iso(value: object) -> str | None:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value.replace(microsecond=0).isoformat()
        return str(value)

    @staticmethod
    def _as_text(value: object) -> str | None:
        if value is None:
            return None
        return str(value)

    @staticmethod
    def _handle_dollar_quote(
        sql: str,
        i: int,
        current: list[str],
        dollar_quote_tag: str | None,
    ) -> tuple[int, str | None]:
        """Handle dollar-quoted string transitions."""
        if dollar_quote_tag is not None:
            if sql.startswith(dollar_quote_tag, i):
                current.append(dollar_quote_tag)
                return i + len(dollar_quote_tag), None
            current.append(sql[i])
            return i + 1, dollar_quote_tag

        # Check if starting a new dollar quote
        if sql[i] == "$":
            j = i + 1
            while j < len(sql) and (sql[j].isalnum() or sql[j] == "_"):
                j += 1
            if j < len(sql) and sql[j] == "$":
                tag = sql[i : j + 1]
                current.append(tag)
                return j + 1, tag

        return i, dollar_quote_tag

    @staticmethod
    def _handle_single_quote(
        sql: str,
        i: int,
        current: list[str],
        in_single_quote: bool,
    ) -> tuple[int, bool]:
        """Handle single-quoted string transitions."""
        if in_single_quote:
            current.append(sql[i])
            if sql[i] == "'":
                if i + 1 < len(sql) and sql[i + 1] == "'":
                    current.append("'")
                    return i + 2, True
                return i + 1, False
            return i + 1, True

        if sql[i] == "'":
            current.append(sql[i])
            return i + 1, True

        return i, in_single_quote

    @staticmethod
    def _split_sql_statements(sql: str) -> list[str]:
        statements: list[str] = []
        current: list[str] = []
        in_single_quote = False
        dollar_quote_tag: str | None = None
        i = 0
        n = len(sql)

        while i < n:
            ch = sql[i]

            # Handle dollar-quoted strings
            new_i, new_tag = PostgresStore._handle_dollar_quote(sql, i, current, dollar_quote_tag)
            if new_i != i:
                i = new_i
                dollar_quote_tag = new_tag
                continue

            # Handle single-quoted strings
            new_i, new_in_quote = PostgresStore._handle_single_quote(sql, i, current, in_single_quote)
            if new_i != i or new_in_quote != in_single_quote:
                i = new_i
                in_single_quote = new_in_quote
                continue

            # Handle statement terminator
            if ch == ";":
                statement = "".join(current).strip()
                if statement:
                    statements.append(statement)
                current = []
                i += 1
                continue

            current.append(ch)
            i += 1

        tail = "".join(current).strip()
        if tail:
            statements.append(tail)
        return statements

    @classmethod
    def _row_to_claim(cls, row: dict[str, object]) -> Claim:
        return Claim(
            id=int(row["id"]),
            text=str(row["text"]),
            idempotency_key=cls._as_text(row.get("idempotency_key")),
            normalized_text=cls._as_text(row["normalized_text"]),
            claim_type=cls._as_text(row["claim_type"]),
            subject=cls._as_text(row["subject"]),
            predicate=cls._as_text(row["predicate"]),
            object_value=cls._as_text(row["object_value"]),
            scope=str(row["scope"]),
            volatility=str(row["volatility"]),
            status=str(row["status"]),
            confidence=float(row["confidence"]),
            pinned=bool(row["pinned"]),
            supersedes_claim_id=int(row["supersedes_claim_id"]) if row["supersedes_claim_id"] is not None else None,
            replaced_by_claim_id=int(row["replaced_by_claim_id"]) if row["replaced_by_claim_id"] is not None else None,
            created_at=cls._as_iso(row["created_at"]) or "",
            updated_at=cls._as_iso(row["updated_at"]) or "",
            last_validated_at=cls._as_iso(row["last_validated_at"]),
            archived_at=cls._as_iso(row["archived_at"]),
            human_id=cls._as_text(row.get("human_id")),
            tenant_id=cls._as_text(row.get("tenant_id")),
            wiki_article=cls._as_text(row.get("wiki_article")),
        )

    @classmethod
    def _row_to_citation(cls, row: dict[str, object]) -> Citation:
        return Citation(
            id=int(row["id"]),
            claim_id=int(row["claim_id"]),
            source=str(row["source"]),
            locator=cls._as_text(row["locator"]),
            excerpt=cls._as_text(row["excerpt"]),
            created_at=cls._as_iso(row["created_at"]) or "",
        )

    @classmethod
    def _row_to_event(cls, row: dict[str, object]) -> Event:
        payload_value = row["payload_json"]
        if payload_value is None:
            payload_json = None
        elif isinstance(payload_value, str):
            payload_json = payload_value
        else:
            payload_json = json.dumps(payload_value)

        return Event(
            id=int(row["id"]),
            claim_id=int(row["claim_id"]) if row["claim_id"] is not None else None,
            event_type=str(row["event_type"]),
            from_status=cls._as_text(row["from_status"]),
            to_status=cls._as_text(row["to_status"]),
            details=cls._as_text(row["details"]),
            payload_json=payload_json,
            created_at=cls._as_iso(row["created_at"]) or "",
        )

    @classmethod
    def _json_text(cls, value: object) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            return value
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    @classmethod
    def _row_to_external_source(cls, row: dict[str, object]) -> ExternalSource:
        return ExternalSource(
            id=int(row["id"]),
            source_type=str(row["source_type"]),
            display_name=str(row["display_name"]),
            config_json=cls._json_text(row.get("config_json")),
            created_at=cls._as_iso(row["created_at"]) or "",
            updated_at=cls._as_iso(row["updated_at"]) or "",
        )

    @classmethod
    def _row_to_source_item(cls, row: dict[str, object]) -> SourceItem:
        return SourceItem(
            id=int(row["id"]),
            source_id=int(row["source_id"]),
            source_item_id=str(row["source_item_id"]),
            item_type=str(row["item_type"]),
            chat_id=cls._as_text(row.get("chat_id")),
            sender_id=cls._as_text(row.get("sender_id")),
            sender_name=cls._as_text(row.get("sender_name")),
            occurred_at=cls._as_iso(row.get("occurred_at")),
            text=cls._as_text(row.get("text")),
            payload_json=cls._json_text(row.get("payload_json")),
            content_hash=cls._as_text(row.get("content_hash")),
            sensitivity=cls._as_text(row.get("sensitivity")),
            created_at=cls._as_iso(row["created_at"]) or "",
            updated_at=cls._as_iso(row["updated_at"]) or "",
        )

    @classmethod
    def _row_to_evidence_item(cls, row: dict[str, object]) -> EvidenceItem:
        confidence = row.get("confidence")
        return EvidenceItem(
            id=int(row["id"]),
            source_item_id=int(row["source_item_id"]),
            evidence_type=str(row["evidence_type"]),
            text=cls._as_text(row.get("text")),
            media_path=cls._as_text(row.get("media_path")),
            provider=cls._as_text(row.get("provider")),
            confidence=float(confidence) if confidence is not None else None,
            payload_json=cls._json_text(row.get("payload_json")),
            sensitivity=cls._as_text(row.get("sensitivity")),
            created_at=cls._as_iso(row["created_at"]) or "",
        )

    @classmethod
    def _row_to_action_proposal(cls, row: dict[str, object]) -> ActionProposal:
        return ActionProposal(
            id=int(row["id"]),
            proposal_type=str(row["proposal_type"]),
            title=str(row["title"]),
            description=cls._as_text(row.get("description")),
            source_item_id=int(row["source_item_id"]) if row.get("source_item_id") is not None else None,
            evidence_item_id=int(row["evidence_item_id"]) if row.get("evidence_item_id") is not None else None,
            claim_id=int(row["claim_id"]) if row.get("claim_id") is not None else None,
            suggested_due_at=cls._as_iso(row.get("suggested_due_at")),
            destination=str(row["destination"]),
            status=str(row["status"]),
            confidence=float(row["confidence"]),
            payload_json=cls._json_text(row.get("payload_json")),
            exported_at=cls._as_iso(row.get("exported_at")),
            external_ref=cls._as_text(row.get("external_ref")),
            idempotency_key=cls._as_text(row.get("idempotency_key")),
            created_at=cls._as_iso(row["created_at"]) or "",
            updated_at=cls._as_iso(row["updated_at"]) or "",
        )

    @classmethod
    def _row_to_claim_link(cls, row: dict[str, object]) -> ClaimLink:
        return ClaimLink(
            id=int(row["id"]),
            source_id=int(row["source_id"]),
            target_id=int(row["target_id"]),
            link_type=str(row["link_type"]),
            created_at=cls._as_iso(row["created_at"]) or "",
        )

    def _ensure_claim_links_schema(self, conn) -> None:
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS claim_links (
                    id BIGSERIAL PRIMARY KEY,
                    source_id BIGINT NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
                    target_id BIGINT NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
                    link_type TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL,
                    CHECK (source_id <> target_id),
                    CHECK (link_type IN ('relates_to', 'supersedes', 'derived_from', 'contradicts', 'supports'))
                )
                """
            )
            cur.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_claim_links_unique ON claim_links(source_id, target_id, link_type)"
            )
            cur.execute(
                "CREATE INDEX IF NOT EXISTS idx_claim_links_source ON claim_links(source_id)"
            )
            cur.execute(
                "CREATE INDEX IF NOT EXISTS idx_claim_links_target ON claim_links(target_id)"
            )

    def _ensure_human_id_schema(self, conn) -> None:
        """Add human_id column if missing and backfill existing claims."""
        with conn.cursor() as cur:
            cur.execute("ALTER TABLE claims ADD COLUMN IF NOT EXISTS human_id TEXT")
            cur.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_claims_human_id ON claims(human_id)"
            )
        self._backfill_human_ids(conn)

    def _backfill_human_ids(self, conn) -> int:
        """Assign human_id to all claims that lack one."""
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, subject, text FROM claims WHERE human_id IS NULL ORDER BY id ASC"
            )
            rows = cur.fetchall()
            if not rows:
                return 0
            updated = 0
            for row in rows:
                claim_id = int(row["id"])
                subject = self._as_text(row["subject"])
                text = str(row["text"])
                human_id = self._allocate_human_id(cur, subject, text, claim_id)
                cur.execute(
                    "UPDATE claims SET human_id = %s WHERE id = %s",
                    (human_id, claim_id),
                )
                updated += 1
            return updated

    @staticmethod
    def _allocate_human_id(cur, subject: str | None, text: str, claim_id: int) -> str:
        """Build a unique human_id, checking for derived_from parent links."""
        cur.execute(
            """
            SELECT c.human_id
            FROM claim_links cl
            JOIN claims c ON c.id = cl.target_id
            WHERE cl.source_id = %s
              AND cl.link_type = 'derived_from'
              AND c.human_id IS NOT NULL
            LIMIT 1
            """,
            (claim_id,),
        )
        parent_row = cur.fetchone()

        if parent_row and parent_row["human_id"]:
            parent_hid = str(parent_row["human_id"])
            cur.execute(
                "SELECT COUNT(*) AS cnt FROM claims WHERE human_id LIKE %s AND human_id != %s",
                (parent_hid + ".%", parent_hid),
            )
            child_count = cur.fetchone()
            next_child = (int(child_count["cnt"]) if child_count else 0) + 1
            candidate = f"{parent_hid}.{next_child}"
        else:
            candidate = generate_top_level_human_id(subject, text)

        final = candidate
        suffix = 1
        while True:
            cur.execute("SELECT 1 FROM claims WHERE human_id = %s", (final,))
            existing = cur.fetchone()
            if existing is None:
                return final
            suffix += 1
            final = f"{candidate}~{suffix}"

    def _ensure_tenant_id_schema(self, conn) -> None:
        """Add tenant_id column if missing, with an index for tenant isolation."""
        with conn.cursor() as cur:
            cur.execute("ALTER TABLE claims ADD COLUMN IF NOT EXISTS tenant_id TEXT")
            cur.execute(
                "CREATE INDEX IF NOT EXISTS idx_claims_tenant_id ON claims(tenant_id)"
            )

    def _ensure_binding_schema(self, conn) -> None:
        """Add wiki_article column for claim↔wiki bidirectional binding (v3.4)."""
        with conn.cursor() as cur:
            cur.execute("ALTER TABLE claims ADD COLUMN IF NOT EXISTS wiki_article TEXT")
            cur.execute(
                "CREATE INDEX IF NOT EXISTS idx_claims_wiki_article ON claims(wiki_article)"
            )

    @staticmethod
    def _json_payload(value: dict[str, object] | str | None) -> object | None:
        if value is None:
            return None
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            try:
                return json.loads(stripped)
            except json.JSONDecodeError:
                return stripped
        return value

    def upsert_external_source(
        self,
        *,
        source_type: str,
        display_name: str,
        config_json: dict[str, object] | str | None = None,
    ) -> ExternalSource:
        _, _, Jsonb = self._load_psycopg()
        normalized_source_type = source_type.strip().lower()
        normalized_display_name = display_name.strip()
        if not normalized_source_type:
            raise ValueError("source_type must be non-empty.")
        if not normalized_display_name:
            raise ValueError("display_name must be non-empty.")
        now = utc_now()
        payload = self._json_payload(config_json)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO external_sources (source_type, display_name, config_json, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT(source_type, display_name) DO UPDATE SET
                    config_json = EXCLUDED.config_json,
                    updated_at = EXCLUDED.updated_at
                RETURNING *
                """,
                (
                    normalized_source_type,
                    normalized_display_name,
                    Jsonb(payload) if payload is not None else None,
                    now,
                    now,
                ),
            )
            row = cur.fetchone()
        if row is None:
            raise RuntimeError("Failed to upsert external source.")
        return self._row_to_external_source(row)

    def upsert_source_item(
        self,
        *,
        source_id: int,
        source_item_id: str,
        item_type: str,
        chat_id: str | None = None,
        sender_id: str | None = None,
        sender_name: str | None = None,
        occurred_at: str | None = None,
        text: str | None = None,
        payload_json: dict[str, object] | str | None = None,
        content_hash: str | None = None,
        sensitivity: str | None = None,
    ) -> SourceItem:
        from memorymaster._storage_sources import _normalize_sensitivity

        _, _, Jsonb = self._load_psycopg()
        normalized_source_item_id = source_item_id.strip()
        normalized_item_type = item_type.strip().lower()
        if source_id <= 0:
            raise ValueError("source_id must be positive.")
        if not normalized_source_item_id:
            raise ValueError("source_item_id must be non-empty.")
        if not normalized_item_type:
            raise ValueError("item_type must be non-empty.")
        normalized_sensitivity = _normalize_sensitivity(sensitivity)
        now = utc_now()
        payload = self._json_payload(payload_json)
        # Preserve existing sensitivity on re-import unless caller passed one
        preserve_sensitivity_clause = (
            "sensitivity = EXCLUDED.sensitivity"
            if sensitivity is not None
            else "sensitivity = source_items.sensitivity"
        )
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT id FROM source_items WHERE source_id = %s AND source_item_id = %s",
                (source_id, normalized_source_item_id),
            )
            existing = cur.fetchone()
            cur.execute(
                f"""
                INSERT INTO source_items (
                    source_id, source_item_id, item_type, chat_id, sender_id, sender_name,
                    occurred_at, text, payload_json, content_hash, sensitivity, created_at, updated_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT(source_id, source_item_id) DO UPDATE SET
                    item_type = EXCLUDED.item_type,
                    chat_id = EXCLUDED.chat_id,
                    sender_id = EXCLUDED.sender_id,
                    sender_name = EXCLUDED.sender_name,
                    occurred_at = EXCLUDED.occurred_at,
                    text = EXCLUDED.text,
                    payload_json = EXCLUDED.payload_json,
                    content_hash = EXCLUDED.content_hash,
                    {preserve_sensitivity_clause},
                    updated_at = EXCLUDED.updated_at
                RETURNING *
                """,
                (
                    source_id,
                    normalized_source_item_id,
                    normalized_item_type,
                    chat_id,
                    sender_id,
                    sender_name,
                    occurred_at,
                    text,
                    Jsonb(payload) if payload is not None else None,
                    content_hash,
                    normalized_sensitivity,
                    now,
                    now,
                ),
            )
            row = cur.fetchone()
            if existing is None:
                self._insert_event_row(
                    conn,
                    claim_id=None,
                    event_type="source_import",
                    from_status=None,
                    to_status=None,
                    details="source_item_imported",
                    payload={
                        "source_id": source_id,
                        "source_item_id": normalized_source_item_id,
                        "item_type": normalized_item_type,
                    },
                    created_at=now,
                )
        if row is None:
            raise RuntimeError("Failed to upsert source item.")
        return self._row_to_source_item(row)

    def get_source_item(self, *, source_id: int, source_item_id: str) -> SourceItem | None:
        normalized_source_item_id = source_item_id.strip()
        if source_id <= 0:
            raise ValueError("source_id must be positive.")
        if not normalized_source_item_id:
            return None
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM source_items WHERE source_id = %s AND source_item_id = %s",
                (source_id, normalized_source_item_id),
            )
            row = cur.fetchone()
        return self._row_to_source_item(row) if row is not None else None

    def get_source_item_by_id(self, source_item_row_id: int) -> SourceItem | None:
        if source_item_row_id <= 0:
            raise ValueError("source_item_row_id must be positive.")
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM source_items WHERE id = %s", (source_item_row_id,))
            row = cur.fetchone()
        return self._row_to_source_item(row) if row is not None else None

    def add_evidence_item(
        self,
        *,
        source_item_id: int,
        evidence_type: str,
        text: str | None = None,
        media_path: str | None = None,
        provider: str | None = None,
        confidence: float | None = None,
        payload_json: dict[str, object] | str | None = None,
        sensitivity: str | None = None,
    ) -> EvidenceItem:
        from memorymaster._storage_sources import _normalize_sensitivity

        _, _, Jsonb = self._load_psycopg()
        normalized_evidence_type = evidence_type.strip().lower()
        if source_item_id <= 0:
            raise ValueError("source_item_id must be positive.")
        if not normalized_evidence_type:
            raise ValueError("evidence_type must be non-empty.")
        normalized_sensitivity = _normalize_sensitivity(sensitivity)
        now = utc_now()
        bounded = None if confidence is None else max(0.0, min(1.0, float(confidence)))
        payload = self._json_payload(payload_json)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO evidence_items (
                    source_item_id, evidence_type, text, media_path, provider,
                    confidence, payload_json, sensitivity, created_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (
                    source_item_id,
                    normalized_evidence_type,
                    text,
                    media_path,
                    provider,
                    bounded,
                    Jsonb(payload) if payload is not None else None,
                    normalized_sensitivity,
                    now,
                ),
            )
            row = cur.fetchone()
            if row is None:
                raise RuntimeError("Failed to add evidence item.")
            self._insert_event_row(
                conn,
                claim_id=None,
                event_type="media_process",
                from_status=None,
                to_status=None,
                details="evidence_item_added",
                payload={
                    "source_item_id": source_item_id,
                    "evidence_item_id": int(row["id"]),
                    "evidence_type": normalized_evidence_type,
                },
                created_at=now,
            )
        return self._row_to_evidence_item(row)

    def list_evidence_items(
        self,
        *,
        source_item_id: int | None = None,
        evidence_type: str | None = None,
        limit: int = 100,
    ) -> list[EvidenceItem]:
        clauses: list[str] = []
        params: list[object] = []
        if source_item_id is not None:
            if source_item_id <= 0:
                raise ValueError("source_item_id must be positive.")
            clauses.append("source_item_id = %s")
            params.append(source_item_id)
        if evidence_type:
            clauses.append("evidence_type = %s")
            params.append(evidence_type.strip().lower())
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                f"SELECT * FROM evidence_items {where_sql} ORDER BY created_at ASC, id ASC LIMIT %s",
                params,
            )
            rows = cur.fetchall()
        return [self._row_to_evidence_item(row) for row in rows]

    def create_action_proposal(
        self,
        *,
        proposal_type: str,
        title: str,
        description: str | None = None,
        source_item_id: int | None = None,
        evidence_item_id: int | None = None,
        claim_id: int | None = None,
        suggested_due_at: str | None = None,
        destination: str = "manual",
        confidence: float = 0.5,
        payload_json: dict[str, object] | str | None = None,
        idempotency_key: str | None = None,
    ) -> ActionProposal:
        _, _, Jsonb = self._load_psycopg()
        normalized_type = proposal_type.strip().lower()
        normalized_title = title.strip()
        normalized_destination = destination.strip() or "manual"
        normalized_idempotency_key = (idempotency_key or "").strip() or None
        if not normalized_type:
            raise ValueError("proposal_type must be non-empty.")
        if not normalized_title:
            raise ValueError("title must be non-empty.")
        if normalized_idempotency_key:
            existing = self.get_action_proposal_by_idempotency_key(normalized_idempotency_key)
            if existing is not None:
                return existing
        now = utc_now()
        bounded = max(0.0, min(1.0, float(confidence)))
        payload = self._json_payload(payload_json)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO action_proposals (
                    proposal_type, title, description, source_item_id, evidence_item_id,
                    claim_id, suggested_due_at, destination, status, confidence, payload_json,
                    exported_at, external_ref, idempotency_key, created_at, updated_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'candidate', %s, %s, NULL, NULL, %s, %s, %s)
                RETURNING *
                """,
                (
                    normalized_type,
                    normalized_title,
                    description,
                    source_item_id,
                    evidence_item_id,
                    claim_id,
                    suggested_due_at,
                    normalized_destination,
                    bounded,
                    Jsonb(payload) if payload is not None else None,
                    normalized_idempotency_key,
                    now,
                    now,
                ),
            )
            row = cur.fetchone()
            if row is None:
                raise RuntimeError("Failed to create action proposal.")
            self._insert_event_row(
                conn,
                claim_id=claim_id,
                event_type="action_proposal",
                from_status=None,
                to_status="candidate",
                details="action_proposal_created",
                payload={
                    "proposal_id": int(row["id"]),
                    "proposal_type": normalized_type,
                    "destination": normalized_destination,
                },
                created_at=now,
            )
        return self._row_to_action_proposal(row)

    def get_action_proposal_by_idempotency_key(self, idempotency_key: str) -> ActionProposal | None:
        normalized = idempotency_key.strip()
        if not normalized:
            return None
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM action_proposals WHERE idempotency_key = %s", (normalized,))
            row = cur.fetchone()
        return self._row_to_action_proposal(row) if row is not None else None

    def update_action_proposal_status(
        self,
        proposal_id: int,
        *,
        status: str,
        external_ref: str | None = None,
        exported_at: str | None = None,
        payload_json: dict[str, object] | str | None = None,
    ) -> ActionProposal:
        _, _, Jsonb = self._load_psycopg()
        normalized_status = status.strip().lower()
        if proposal_id <= 0:
            raise ValueError("proposal_id must be positive.")
        if normalized_status not in {"candidate", "approved", "rejected", "exported", "failed"}:
            raise ValueError("status must be one of: candidate, approved, rejected, exported, failed.")
        now = utc_now()
        payload = self._json_payload(payload_json)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM action_proposals WHERE id = %s", (proposal_id,))
            current = cur.fetchone()
            if current is None:
                raise ValueError(f"Action proposal {proposal_id} does not exist.")
            final_exported_at = exported_at if exported_at is not None else current["exported_at"]
            if normalized_status == "exported" and final_exported_at is None:
                final_exported_at = now
            if payload is not None:
                final_payload = Jsonb(payload)
            elif current["payload_json"] is not None:
                final_payload = Jsonb(current["payload_json"])
            else:
                final_payload = None
            final_external_ref = external_ref if external_ref is not None else current["external_ref"]
            cur.execute(
                """
                UPDATE action_proposals
                SET status = %s,
                    external_ref = %s,
                    exported_at = %s,
                    payload_json = %s,
                    updated_at = %s
                WHERE id = %s
                RETURNING *
                """,
                (normalized_status, final_external_ref, final_exported_at, final_payload, now, proposal_id),
            )
            row = cur.fetchone()
            event_type = "action_export" if normalized_status == "exported" else "action_proposal"
            self._insert_event_row(
                conn,
                claim_id=int(current["claim_id"]) if current["claim_id"] is not None else None,
                event_type=event_type,
                from_status=str(current["status"]),
                to_status=normalized_status,
                details="action_proposal_status_updated",
                payload={"proposal_id": proposal_id, "status": normalized_status},
                created_at=now,
            )
        if row is None:
            raise RuntimeError("Failed to update action proposal.")
        return self._row_to_action_proposal(row)

    def set_source_item_sensitivity(
        self,
        source_item_row_id: int,
        sensitivity: str | None,
    ) -> SourceItem:
        from memorymaster._storage_sources import _normalize_sensitivity

        if source_item_row_id <= 0:
            raise ValueError("source_item_row_id must be positive.")
        normalized = _normalize_sensitivity(sensitivity)
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM source_items WHERE id = %s", (source_item_row_id,))
            current = cur.fetchone()
            if current is None:
                raise ValueError(f"Source item {source_item_row_id} does not exist.")
            current_sensitivity = current.get("sensitivity")
            if current_sensitivity == normalized:
                return self._row_to_source_item(current)
            cur.execute(
                "UPDATE source_items SET sensitivity = %s, updated_at = %s WHERE id = %s RETURNING *",
                (normalized, now, source_item_row_id),
            )
            row = cur.fetchone()
            self._insert_event_row(
                conn,
                claim_id=None,
                event_type="source_import",
                from_status=None,
                to_status=None,
                details="source_item_sensitivity_set",
                payload={"source_item_id": source_item_row_id, "from": current_sensitivity, "to": normalized},
                created_at=now,
            )
        return self._row_to_source_item(row)

    def set_evidence_item_sensitivity(
        self,
        evidence_item_row_id: int,
        sensitivity: str | None,
    ) -> EvidenceItem:
        from memorymaster._storage_sources import _normalize_sensitivity

        if evidence_item_row_id <= 0:
            raise ValueError("evidence_item_row_id must be positive.")
        normalized = _normalize_sensitivity(sensitivity)
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM evidence_items WHERE id = %s", (evidence_item_row_id,))
            current = cur.fetchone()
            if current is None:
                raise ValueError(f"Evidence item {evidence_item_row_id} does not exist.")
            current_sensitivity = current.get("sensitivity")
            if current_sensitivity == normalized:
                return self._row_to_evidence_item(current)
            cur.execute(
                "UPDATE evidence_items SET sensitivity = %s WHERE id = %s RETURNING *",
                (normalized, evidence_item_row_id),
            )
            row = cur.fetchone()
            self._insert_event_row(
                conn,
                claim_id=None,
                event_type="media_process",
                from_status=None,
                to_status=None,
                details="evidence_item_sensitivity_set",
                payload={"evidence_item_id": evidence_item_row_id, "from": current_sensitivity, "to": normalized},
                created_at=now,
            )
        return self._row_to_evidence_item(row)

    # ----------------------------------------------------------------------
    # Media retry queue (Atlas v1.4.0) — Postgres mirror of SQLite mixin
    # ----------------------------------------------------------------------

    @classmethod
    def _row_to_media_retry(cls, row: dict[str, object]) -> MediaRetryItem:
        return MediaRetryItem(
            id=int(row["id"]),
            source_item_id=int(row["source_item_id"]),
            media_key=str(row["media_key"]),
            chat_id=cls._as_text(row.get("chat_id")),
            media_type=cls._as_text(row.get("media_type")),
            media_path=cls._as_text(row.get("media_path")),
            media_url=cls._as_text(row.get("media_url")),
            status=str(row["status"]),
            attempt_count=int(row["attempt_count"]),
            last_http_status=int(row["last_http_status"]) if row.get("last_http_status") is not None else None,
            last_error=cls._as_text(row.get("last_error")),
            next_attempt_time=cls._as_iso(row.get("next_attempt_time")),
            created_at=cls._as_iso(row["created_at"]) or "",
            updated_at=cls._as_iso(row["updated_at"]) or "",
        )

    def enqueue_media_retry(
        self,
        *,
        source_item_id: int,
        media_key: str,
        chat_id: str | None = None,
        media_type: str | None = None,
        media_path: str | None = None,
        media_url: str | None = None,
        status: str = "pending",
        next_attempt_time: str | None = None,
    ) -> MediaRetryItem:
        if source_item_id <= 0:
            raise ValueError("source_item_id must be positive.")
        normalized_key = (media_key or "").strip()
        if not normalized_key:
            raise ValueError("media_key must be non-empty.")
        if status not in MEDIA_RETRY_STATUSES:
            raise ValueError(f"status must be one of: {', '.join(MEDIA_RETRY_STATUSES)}.")
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM media_retry_queue WHERE source_item_id = %s AND media_key = %s",
                (source_item_id, normalized_key),
            )
            existing = cur.fetchone()
            if existing is not None:
                cur.execute(
                    """
                    UPDATE media_retry_queue
                    SET chat_id = COALESCE(%s, chat_id),
                        media_type = COALESCE(%s, media_type),
                        media_path = COALESCE(%s, media_path),
                        media_url = COALESCE(%s, media_url),
                        next_attempt_time = COALESCE(%s, next_attempt_time),
                        updated_at = %s
                    WHERE id = %s
                    RETURNING *
                    """,
                    (chat_id, media_type, media_path, media_url, next_attempt_time, now, int(existing["id"])),
                )
                row = cur.fetchone()
                return self._row_to_media_retry(row)
            cur.execute(
                """
                INSERT INTO media_retry_queue (
                    source_item_id, media_key, chat_id, media_type, media_path, media_url,
                    status, attempt_count, last_http_status, last_error, next_attempt_time,
                    created_at, updated_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, 0, NULL, NULL, %s, %s, %s)
                RETURNING *
                """,
                (
                    source_item_id, normalized_key, chat_id, media_type, media_path, media_url,
                    status, next_attempt_time, now, now,
                ),
            )
            row = cur.fetchone()
            self._insert_event_row(
                conn,
                claim_id=None,
                event_type="media_process",
                from_status=None,
                to_status=status,
                details="media_retry_enqueued",
                payload={"retry_id": int(row["id"]), "source_item_id": source_item_id, "media_key": normalized_key},
                created_at=now,
            )
        return self._row_to_media_retry(row)

    def claim_pending_media_retries(self, limit: int = 25) -> list[MediaRetryItem]:
        if limit <= 0:
            return []
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                UPDATE media_retry_queue
                SET status = 'retrying',
                    attempt_count = attempt_count + 1,
                    updated_at = %s
                WHERE id IN (
                    SELECT id FROM media_retry_queue
                    WHERE status = 'pending'
                      AND (next_attempt_time IS NULL OR next_attempt_time <= %s)
                    ORDER BY id ASC
                    LIMIT %s
                    FOR UPDATE SKIP LOCKED
                )
                RETURNING *
                """,
                (now, now, limit),
            )
            rows = cur.fetchall()
            for row in rows:
                self._insert_event_row(
                    conn,
                    claim_id=None,
                    event_type="media_process",
                    from_status="pending",
                    to_status="retrying",
                    details="media_retry_claimed",
                    payload={"retry_id": int(row["id"])},
                    created_at=now,
                )
        return [self._row_to_media_retry(r) for r in rows]

    def record_media_retry_outcome(
        self,
        retry_id: int,
        *,
        status: str,
        media_path: str | None = None,
        last_http_status: int | None = None,
        last_error: str | None = None,
        next_attempt_time: str | None = None,
    ) -> MediaRetryItem:
        if retry_id <= 0:
            raise ValueError("retry_id must be positive.")
        if status not in MEDIA_RETRY_STATUSES:
            raise ValueError(f"status must be one of: {', '.join(MEDIA_RETRY_STATUSES)}.")
        if status == "done" and not media_path:
            raise ValueError("media_path is required when status='done'.")
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM media_retry_queue WHERE id = %s", (retry_id,))
            current = cur.fetchone()
            if current is None:
                raise ValueError(f"media_retry_queue row {retry_id} does not exist.")
            new_path = media_path if media_path is not None else current["media_path"]
            new_http = last_http_status if last_http_status is not None else current["last_http_status"]
            new_err = last_error if last_error is not None else current["last_error"]
            new_next = next_attempt_time if next_attempt_time is not None else current["next_attempt_time"]
            cur.execute(
                """
                UPDATE media_retry_queue
                SET status = %s,
                    media_path = %s,
                    last_http_status = %s,
                    last_error = %s,
                    next_attempt_time = %s,
                    updated_at = %s
                WHERE id = %s
                RETURNING *
                """,
                (status, new_path, new_http, new_err, new_next, now, retry_id),
            )
            row = cur.fetchone()
            self._insert_event_row(
                conn,
                claim_id=None,
                event_type="media_process",
                from_status=str(current["status"]),
                to_status=status,
                details=f"media_retry_outcome_{status}",
                payload={
                    "retry_id": retry_id,
                    "http_status": last_http_status,
                    "has_path": bool(new_path),
                },
                created_at=now,
            )
        return self._row_to_media_retry(row)

    def list_media_retries(
        self,
        *,
        status: str | None = None,
        source_item_id: int | None = None,
        limit: int = 100,
    ) -> list[MediaRetryItem]:
        clauses: list[str] = []
        params: list[object] = []
        if status:
            if status not in MEDIA_RETRY_STATUSES:
                raise ValueError(f"status must be one of: {', '.join(MEDIA_RETRY_STATUSES)}.")
            clauses.append("status = %s")
            params.append(status)
        if source_item_id is not None:
            if source_item_id <= 0:
                raise ValueError("source_item_id must be positive.")
            clauses.append("source_item_id = %s")
            params.append(source_item_id)
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                f"SELECT * FROM media_retry_queue {where_sql} ORDER BY updated_at DESC, id DESC LIMIT %s",
                params,
            )
            rows = cur.fetchall()
        return [self._row_to_media_retry(r) for r in rows]

    def media_retry_status_counts(self) -> dict[str, int]:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT status, COUNT(*) AS n FROM media_retry_queue GROUP BY status")
            rows = cur.fetchall()
        counts = {s: 0 for s in MEDIA_RETRY_STATUSES}
        for r in rows:
            counts[str(r["status"])] = int(r["n"])
        return counts

    def update_action_proposal_fields(
        self,
        proposal_id: int,
        *,
        title: str | None = None,
        description: str | None = None,
        suggested_due_at: str | None = None,
        confidence: float | None = None,
        payload_json: dict[str, object] | str | None = None,
    ) -> ActionProposal:
        """Postgres mirror of SQLite update_action_proposal_fields."""
        _, _, Jsonb = self._load_psycopg()
        if proposal_id <= 0:
            raise ValueError("proposal_id must be positive.")
        if title is None and description is None and suggested_due_at is None and confidence is None and payload_json is None:
            raise ValueError("at least one field must be provided to update.")

        normalized_title = title.strip() if title is not None else None
        if normalized_title is not None and not normalized_title:
            raise ValueError("title cannot be blank when provided.")
        bounded = max(0.0, min(1.0, float(confidence))) if confidence is not None else None
        payload = self._json_payload(payload_json) if payload_json is not None else None

        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT * FROM action_proposals WHERE id = %s", (proposal_id,))
            current = cur.fetchone()
            if current is None:
                raise ValueError(f"Action proposal {proposal_id} does not exist.")

            updates: list[str] = []
            params: list[object] = []
            changed: list[str] = []
            if normalized_title is not None and normalized_title != current["title"]:
                updates.append("title = %s")
                params.append(normalized_title)
                changed.append("title")
            if description is not None and description != current["description"]:
                updates.append("description = %s")
                params.append(description)
                changed.append("description")
            if suggested_due_at is not None and suggested_due_at != current["suggested_due_at"]:
                updates.append("suggested_due_at = %s")
                params.append(suggested_due_at)
                changed.append("suggested_due_at")
            if bounded is not None and bounded != current["confidence"]:
                updates.append("confidence = %s")
                params.append(bounded)
                changed.append("confidence")
            if payload is not None and payload != current["payload_json"]:
                updates.append("payload_json = %s")
                params.append(Jsonb(payload))
                changed.append("payload_json")

            if not changed:
                return self._row_to_action_proposal(current)

            updates.append("updated_at = %s")
            params.append(now)
            params.append(proposal_id)

            cur.execute(
                f"UPDATE action_proposals SET {', '.join(updates)} WHERE id = %s RETURNING *",
                params,
            )
            row = cur.fetchone()
            self._insert_event_row(
                conn,
                claim_id=int(current["claim_id"]) if current["claim_id"] is not None else None,
                event_type="action_proposal",
                from_status=str(current["status"]),
                to_status=str(current["status"]),
                details="action_proposal_fields_updated",
                payload={"proposal_id": proposal_id, "changed": changed},
                created_at=now,
            )
        if row is None:
            raise RuntimeError("Failed to update action proposal fields.")
        return self._row_to_action_proposal(row)

    def list_action_proposals(
        self,
        *,
        status: str | None = None,
        destination: str | None = None,
        limit: int = 100,
    ) -> list[ActionProposal]:
        clauses: list[str] = []
        params: list[object] = []
        if status:
            clauses.append("status = %s")
            params.append(status.strip().lower())
        if destination:
            clauses.append("destination = %s")
            params.append(destination.strip())
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                f"SELECT * FROM action_proposals {where_sql} ORDER BY updated_at DESC, id DESC LIMIT %s",
                params,
            )
            rows = cur.fetchall()
        return [self._row_to_action_proposal(row) for row in rows]

    def get_claim_by_human_id(self, human_id: str, include_citations: bool = True) -> Claim | None:
        """Look up a claim by its human-readable ID (e.g. ``mm-a3f8``)."""
        normalized = human_id.strip()
        if not normalized:
            return None
        with self.connect() as conn, conn.cursor() as cur:
            try:
                cur.execute(
                    "SELECT * FROM claims WHERE human_id = %s",
                    (normalized,),
                )
                row = cur.fetchone()
            except Exception:
                # Column may not exist yet.
                return None
        if row is None:
            return None
        claim = self._row_to_claim(row)
        if include_citations:
            claim.citations = self.list_citations(claim.id)
        return claim

    def resolve_claim_id(self, identifier: str | int) -> int:
        """Resolve a numeric ID or human_id string to a numeric claim ID."""
        if isinstance(identifier, int):
            return identifier
        raw = str(identifier).strip()
        try:
            return int(raw)
        except ValueError:
            pass
        claim = self.get_claim_by_human_id(raw, include_citations=False)
        if claim is not None:
            return claim.id
        raise ValueError(f"No claim found for identifier '{raw}'.")

    def add_claim_link(self, source_id: int, target_id: int, link_type: str) -> ClaimLink:
        if link_type not in CLAIM_LINK_TYPES:
            allowed = ", ".join(CLAIM_LINK_TYPES)
            raise ValueError(f"Invalid link_type '{link_type}'. Allowed: {allowed}.")
        if source_id == target_id:
            raise ValueError("source_id and target_id must be different.")
        now = utc_now()
        with self.connect() as conn, conn.cursor() as cur:
            try:
                cur.execute(
                    """
                        INSERT INTO claim_links (source_id, target_id, link_type, created_at)
                        VALUES (%s, %s, %s, %s)
                        RETURNING id
                        """,
                    (source_id, target_id, link_type, now),
                )
                row = cur.fetchone()
            except Exception as exc:
                msg = str(exc).lower()
                if "unique" in msg or "duplicate key" in msg or "already exists" in msg:
                    raise ValueError(
                        f"Link already exists: {source_id} -> {target_id} ({link_type})."
                    ) from exc
                if "foreign key" in msg or "violates foreign key" in msg or "is not present" in msg:
                    raise ValueError(
                        f"One or both claim ids do not exist: {source_id}, {target_id}."
                    ) from exc
                if "check" in msg and "source_id" in msg:
                    raise ValueError("source_id and target_id must be different.") from exc
                raise
            if row is None:
                raise RuntimeError("Failed to insert claim link.")
            return ClaimLink(
                id=int(row["id"]),
                source_id=source_id,
                target_id=target_id,
                link_type=link_type,
                created_at=self._as_iso(now) or "",
            )

    def remove_claim_link(self, source_id: int, target_id: int, link_type: str | None = None) -> int:
        with self.connect() as conn, conn.cursor() as cur:
            if link_type is not None:
                cur.execute(
                    "DELETE FROM claim_links WHERE source_id = %s AND target_id = %s AND link_type = %s",
                    (source_id, target_id, link_type),
                )
            else:
                cur.execute(
                    "DELETE FROM claim_links WHERE source_id = %s AND target_id = %s",
                    (source_id, target_id),
                )
            return cur.rowcount

    def get_derived_from_target_ids(self, candidate_ids: list[int]) -> set[int]:
        """Return the subset of *candidate_ids* that are targets of a ``derived_from`` link."""
        if not candidate_ids:
            return set()
        with self.connect() as conn, conn.cursor() as cur:
            placeholders = ",".join("%s" for _ in candidate_ids)
            cur.execute(
                f"""
                    SELECT DISTINCT target_id FROM claim_links
                    WHERE link_type = 'derived_from'
                      AND target_id IN ({placeholders})
                    """,
                candidate_ids,
            )
            rows = cur.fetchall()
        return {row[0] if isinstance(row, (tuple, list)) else row["target_id"] for row in rows}

    def get_claim_links(self, claim_id: int) -> list[ClaimLink]:
        with self.connect() as conn, conn.cursor() as cur:
            cur.execute(
                """
                    SELECT * FROM claim_links
                    WHERE source_id = %s OR target_id = %s
                    ORDER BY created_at ASC
                    """,
                (claim_id, claim_id),
            )
            rows = cur.fetchall()
        return [self._row_to_claim_link(row) for row in rows]

    def get_linked_claims(self, claim_id: int, link_type: str | None = None) -> list[ClaimLink]:
        with self.connect() as conn, conn.cursor() as cur:
            if link_type is not None:
                cur.execute(
                    """
                        SELECT * FROM claim_links
                        WHERE (source_id = %s OR target_id = %s) AND link_type = %s
                        ORDER BY created_at ASC
                        """,
                    (claim_id, claim_id, link_type),
                )
            else:
                cur.execute(
                    """
                        SELECT * FROM claim_links
                        WHERE source_id = %s OR target_id = %s
                        ORDER BY created_at ASC
                        """,
                    (claim_id, claim_id),
                )
            rows = cur.fetchall()
        return [self._row_to_claim_link(row) for row in rows]
