'''
Function:
    Implementation of SCDNProxiedSession
Author:
    Zhenchao Jin
WeChat Official Account (微信公众号):
    Charles的皮卡丘
'''
import requests
from tqdm import tqdm
from .base import BaseProxiedSession
from concurrent.futures import ThreadPoolExecutor, as_completed
from ..utils import filterinvalidproxies, applyfilterrule, ProxyInfo, IPLocater


'''SCDNProxiedSession'''
class SCDNProxiedSession(BaseProxiedSession):
    source = 'SCDNProxiedSession'
    homepage = 'https://proxy.scdn.io/'
    def __init__(self, **kwargs):
        super(SCDNProxiedSession, self).__init__(**kwargs)
    '''refreshproxies'''
    @applyfilterrule()
    @filterinvalidproxies
    def refreshproxies(self):
        # initialize
        self.candidate_proxies, session = [], requests.Session()
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"}
        # obtain proxies
        for page in range(1, self.max_pages+1):
            # --https
            try:
                (resp := session.get(f'https://proxy.scdn.io/api/get_proxy.php?protocol=https&count=20&page={page}', headers=self.getrandomheaders(base_headers=headers), timeout=60)).raise_for_status()
                for item in resp.json()['data']['proxies']: self.candidate_proxies.append(ProxyInfo(source=self.source, protocol='https', ip=str(item).split(':')[0], port=str(item).split(':')[1], country_code="", in_chinese_mainland=None, anonymity=""))
            except Exception: pass
            # --http
            try:
                (resp := session.get(f'https://proxy.scdn.io/api/get_proxy.php?protocol=http&count=20&page={page}', headers=self.getrandomheaders(base_headers=headers), timeout=60)).raise_for_status()
                for item in resp.json()['data']['proxies']: self.candidate_proxies.append(ProxyInfo(source=self.source, protocol='http', ip=str(item).split(':')[0], port=str(item).split(':')[1], country_code="", in_chinese_mainland=None, anonymity=""))
            except Exception: pass
            # --socks4
            try:
                (resp := session.get(f'https://proxy.scdn.io/api/get_proxy.php?protocol=socks4&count=20&page={page}', headers=self.getrandomheaders(base_headers=headers), timeout=60)).raise_for_status()
                for item in resp.json()['data']['proxies']: self.candidate_proxies.append(ProxyInfo(source=self.source, protocol='socks4', ip=str(item).split(':')[0], port=str(item).split(':')[1], country_code="", in_chinese_mainland=None, anonymity=""))
            except Exception: pass
            # --socks5
            try:
                (resp := session.get(f'https://proxy.scdn.io/api/get_proxy.php?protocol=socks5&count=20&page={page}', headers=self.getrandomheaders(base_headers=headers), timeout=60)).raise_for_status()
                for item in resp.json()['data']['proxies']: self.candidate_proxies.append(ProxyInfo(source=self.source, protocol='socks5', ip=str(item).split(':')[0], port=str(item).split(':')[1], country_code="", in_chinese_mainland=None, anonymity=""))
            except Exception: pass
        # append country code info
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_map = {executor.submit(IPLocater.locate, p.ip): p for p in self.candidate_proxies}
            if not self.disable_print: future_map_wrapper = tqdm(as_completed(future_map), desc=f"{self.source} >>> adding country_code")
            else: future_map_wrapper = as_completed(future_map)
            for future in future_map_wrapper:
                try: country_code = future.result(); assert country_code
                except Exception: continue
                proxy_info: ProxyInfo = future_map[future]
                proxy_info.country_code = country_code
                proxy_info.in_chinese_mainland = (country_code.lower() in ['cn'])
        # return
        return self.candidate_proxies