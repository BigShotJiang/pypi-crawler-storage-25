"""ftune CLI package."""
