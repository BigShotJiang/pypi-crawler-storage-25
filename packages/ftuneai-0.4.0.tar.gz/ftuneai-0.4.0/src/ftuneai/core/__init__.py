"""Core estimation engines."""
