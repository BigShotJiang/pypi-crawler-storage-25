"""Utility functions for ftune."""
