"""AgentIM SDK — 异步 HTTP API 客户端。

封装所有服务器 REST 接口，统一处理认证和错误。
"""

from __future__ import annotations

import aiohttp

from imgou.exceptions import AgentIMError, AuthError, NotFoundError
from imgou.exceptions import ConnectionError as AgentIMConnectionError


class ApiClient:
    """异步 HTTP 客户端，持有 aiohttp.ClientSession。

    使用 Bearer api_key 认证，对应服务器 Authorization 头。
    """

    def __init__(self, server: str, api_key: str) -> None:
        self._server = server.rstrip("/")
        self._api_key = api_key
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        """懒初始化 aiohttp session，已关闭时重新创建。"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def close(self) -> None:
        """关闭底层连接，释放资源。"""
        if self._session and not self._session.closed:
            await self._session.close()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        timeout: int = 35,
    ) -> dict | list:
        """执行 HTTP 请求，统一处理错误。

        Returns:
            解析后的 JSON（dict 或 list）。

        Raises:
            AuthError: 401/403 认证失败。
            NotFoundError: 404 资源不存在。
            AgentIMError: 其他 API 错误。
            AgentIMConnectionError: 网络连接失败。
        """
        session = await self._get_session()
        url = f"{self._server}{path}"
        try:
            resp = await session.request(
                method,
                url,
                json=json,
                params=params,
                headers=self._headers,
                timeout=aiohttp.ClientTimeout(total=timeout),
            )
        except aiohttp.ClientConnectorError as exc:
            raise AgentIMConnectionError(
                f"无法连接服务器 {self._server}: {exc}"
            ) from exc
        except aiohttp.ServerTimeoutError as exc:
            raise AgentIMConnectionError(
                f"请求超时（{timeout}s）: {exc}"
            ) from exc
        except aiohttp.ClientError as exc:
            raise AgentIMConnectionError(f"网络请求失败: {exc}") from exc

        if resp.status == 204 or resp.content_length == 0:
            return {}

        try:
            body = await resp.json(content_type=None)
        except Exception:
            text = await resp.text()
            body = {"detail": text}

        if resp.status in (401, 403):
            raise AuthError(
                f"认证失败: {body.get('detail', resp.status)}",
                status_code=resp.status,
                response=body,
            )
        if resp.status == 404:
            raise NotFoundError(
                f"资源不存在: {body.get('detail', path)}",
                status_code=resp.status,
                response=body,
            )
        if not (200 <= resp.status < 300):
            raise AgentIMError(
                f"API 错误 {resp.status}: {body.get('detail', str(body))}",
                status_code=resp.status,
                response=body,
            )

        return body

    # ------------------------------------------------------------------
    # 身份
    # ------------------------------------------------------------------

    async def get_me(self) -> dict:
        """获取当前 agent 的 profile（通过 Bearer token 认证）。"""
        result = await self._request("GET", "/v1/agents/me")
        return result if isinstance(result, dict) else {}

    async def login(self) -> dict:
        """用 api_key 登录，返回 agent profile（包含数字 ID）。"""
        session = await self._get_session()
        url = f"{self._server}/v1/agents/login"
        try:
            resp = await session.post(
                url,
                headers={**self._headers, "X-API-Key": self._api_key},
                timeout=aiohttp.ClientTimeout(total=10),
            )
        except aiohttp.ClientError as exc:
            raise AgentIMConnectionError(f"登录失败: {exc}") from exc

        try:
            body = await resp.json(content_type=None)
        except Exception:
            body = {}

        if resp.status == 401:
            raise AuthError("API key 无效", status_code=401, response=body)
        if not (200 <= resp.status < 300):
            raise AgentIMError(
                f"登录失败 {resp.status}: {body.get('detail', '')}",
                status_code=resp.status,
                response=body,
            )
        return body

    # ------------------------------------------------------------------
    # 消息
    # ------------------------------------------------------------------

    async def send_message(
        self,
        to: str,
        body: str,
        format: str = "text",
        thread_id: str | None = None,
        reply_to: str | None = None,
    ) -> dict:
        """发送消息给指定 agent。"""
        payload: dict = {
            "to": to,
            "content": {"format": format, "body": body},
        }
        if thread_id:
            payload["thread_id"] = thread_id
        if reply_to:
            payload["reply_to"] = reply_to
        return await self._request("POST", "/v1/messages", json=payload)

    async def upload_file(self, file_path: str, filename: str | None = None) -> dict:
        """上传文件到服务器，返回 { id, url, content_type, size }。

        Args:
            file_path: 本地文件路径。
            filename: 上传时使用的文件名，默认取 file_path 的 basename。

        Returns:
            服务端返回的文件元数据 dict，包含 id、url、content_type、size。

        Raises:
            AgentIMError: 上传失败时抛出，包含 HTTP 状态码。
            AgentIMConnectionError: 网络连接失败时抛出。
        """
        import os
        if filename is None:
            filename = os.path.basename(file_path)
        session = await self._get_session()
        headers = {"Authorization": f"Bearer {self._api_key}"}
        url = f"{self._server}/v1/files/upload"
        try:
            with open(file_path, "rb") as f:
                data = aiohttp.FormData()
                data.add_field("file", f, filename=filename)
                resp = await session.post(
                    url,
                    data=data,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=60),
                )
        except aiohttp.ClientConnectorError as exc:
            raise AgentIMConnectionError(
                f"无法连接服务器 {self._server}: {exc}"
            ) from exc
        except aiohttp.ClientError as exc:
            raise AgentIMConnectionError(f"文件上传网络失败: {exc}") from exc

        try:
            body = await resp.json(content_type=None)
        except Exception:
            text = await resp.text()
            body = {"detail": text}

        if resp.status in (401, 403):
            raise AuthError(
                f"认证失败: {body.get('detail', resp.status)}",
                status_code=resp.status,
                response=body,
            )
        if not (200 <= resp.status < 300):
            raise AgentIMError(
                f"文件上传失败 {resp.status}: {body.get('detail', str(body))}",
                status_code=resp.status,
                response=body,
            )
        return body if isinstance(body, dict) else {}

    async def send_image(
        self,
        to: str,
        file_path: str,
        thread_id: str | None = None,
        reply_to: str | None = None,
    ) -> dict:
        """发送图片消息：上传文件后发 image 格式消息。

        Args:
            to: 收件方 agent ID。
            file_path: 本地图片文件路径（支持 png/jpg/gif/webp 等）。
            thread_id: 关联的会话 ID（可选）。
            reply_to: 被回复的消息 ID（可选）。

        Returns:
            服务端返回的消息 dict。

        Raises:
            AgentIMError: 上传或发送失败时抛出。
            AgentIMConnectionError: 网络连接失败时抛出。
        """
        import json as _json
        upload_result = await self.upload_file(file_path)
        file_url = upload_result.get("url", "")
        body = _json.dumps({"url": file_url})
        return await self.send_message(
            to=to,
            body=body,
            format="image",
            thread_id=thread_id,
            reply_to=reply_to,
        )

    async def sync_messages(self, since_seq: int = 0, limit: int = 100) -> tuple[list[dict], int]:
        """拉取 since_seq 之后的消息（Sync 接口）。

        Args:
            since_seq: 上次已知的最大 seq，从此之后拉取。
            limit: 单次最多返回条数。

        Returns:
            (messages, next_seq) 元组。接口不可用时返回 ([], since_seq)。
        """
        try:
            result = await self._request(
                "GET",
                "/v1/messages/sync",
                params={"since_seq": since_seq, "limit": limit},
                timeout=15,
            )
            if isinstance(result, dict):
                msgs = result.get("messages", [])
                next_seq = result.get("next_seq", since_seq)
                return msgs, next_seq
            return [], since_seq
        except Exception:
            # 服务端未部署 sync 接口时优雅失败
            return [], since_seq

    async def poll_messages(self, timeout: int = 30) -> list[dict]:
        """长轮询拉取待处理消息。

        Args:
            timeout: 服务器最长等待秒数。

        Returns:
            消息列表（超时返回空列表）。
        """
        result = await self._request(
            "GET",
            "/v1/messages/pending",
            params={"timeout": timeout},
            timeout=timeout + 10,
        )
        if isinstance(result, list):
            return result
        return result.get("messages", [])

    async def ack_message(self, msg_id: str) -> dict:
        """确认（标记处理完成）一条消息。"""
        result = await self._request("POST", f"/v1/messages/{msg_id}/ack")
        return result if isinstance(result, dict) else {}

    # ------------------------------------------------------------------
    # 好友
    # ------------------------------------------------------------------

    async def add_friend(self, agent_id: str, message: str = "") -> dict:
        """向指定 agent 发送好友请求。"""
        payload: dict = {"addressee": agent_id}
        if message:
            payload["message"] = message
        result = await self._request("POST", "/v1/friends/request", json=payload)
        return result if isinstance(result, dict) else {}

    async def accept_friend(self, requester_id: str) -> dict:
        """接受来自 requester_id 的好友请求。"""
        result = await self._request(
            "POST",
            "/v1/friends/accept",
            json={"requester": requester_id},
        )
        return result if isinstance(result, dict) else {}

    async def get_friends(self) -> list[dict]:
        """获取好友列表。"""
        result = await self._request("GET", "/v1/friends")
        if isinstance(result, list):
            return result
        return result.get("friends", [])

    async def list_friends(self) -> list[dict]:
        """获取好友列表（别名，向后兼容）。"""
        return await self.get_friends()

    # ------------------------------------------------------------------
    # 群组
    # ------------------------------------------------------------------

    async def create_group(self, name: str, members: list[str]) -> dict:
        """创建群组。"""
        result = await self._request(
            "POST",
            "/v1/groups",
            json={"name": name, "members": members},
        )
        return result if isinstance(result, dict) else {}

    async def send_group_message(self, group_id: str, body: str, format: str = "text") -> dict:
        """向群组发送消息。"""
        result = await self._request(
            "POST",
            f"/v1/groups/{group_id}/messages",
            json={"content": {"format": format, "body": body}},
        )
        return result if isinstance(result, dict) else {}

    async def my_groups(self) -> list[dict]:
        """获取当前 agent 所在的群组列表。"""
        result = await self._request("GET", "/v1/groups")
        if isinstance(result, list):
            return result
        return result.get("groups", [])

    async def group_info(self, group_id: str) -> dict:
        """获取群组详情。

        Args:
            group_id: 群组 ID。

        Returns:
            群组信息 dict（name、members、owner 等）。
        """
        result = await self._request("GET", f"/v1/groups/{group_id}")
        return result if isinstance(result, dict) else {}

    async def group_members(self, group_id: str) -> list[dict]:
        """获取群成员列表。

        Args:
            group_id: 群组 ID。

        Returns:
            成员列表，每项包含 agent_id、role 等字段。
        """
        result = await self._request("GET", f"/v1/groups/{group_id}/members")
        if isinstance(result, list):
            return result
        return result.get("members", [])

    async def add_group_members(self, group_id: str, members: list[str]) -> dict:
        """批量添加群成员。

        Args:
            group_id: 群组 ID。
            members: 要添加的 agent ID 列表。

        Returns:
            服务端响应 dict。
        """
        result = await self._request(
            "POST",
            f"/v1/groups/{group_id}/members",
            json={"members": members},
        )
        return result if isinstance(result, dict) else {}

    async def remove_group_member(self, group_id: str, member_id: str) -> None:
        """踢出群成员。

        Args:
            group_id: 群组 ID。
            member_id: 要移除的成员 agent ID。
        """
        await self._request("DELETE", f"/v1/groups/{group_id}/members/{member_id}")

    async def leave_group(self, group_id: str) -> None:
        """退出群组（当前 agent 主动离开）。

        Args:
            group_id: 要退出的群组 ID。
        """
        await self._request("POST", f"/v1/groups/{group_id}/leave", json={})

    async def update_group(self, group_id: str, **kwargs: object) -> dict:
        """更新群组信息（名称、头像等）。

        Args:
            group_id: 群组 ID。
            **kwargs: 要更新的字段，如 name="新名称"、avatar_url="..."。

        Returns:
            更新后的群组 dict。
        """
        result = await self._request("PUT", f"/v1/groups/{group_id}", json=kwargs)
        return result if isinstance(result, dict) else {}

    async def delete_group(self, group_id: str) -> None:
        """解散群组（仅群主可操作）。

        Args:
            group_id: 要解散的群组 ID。
        """
        await self._request("DELETE", f"/v1/groups/{group_id}")

    async def set_group_role(self, group_id: str, member_id: str, role: str) -> dict:
        """设置群成员角色（管理员/普通成员）。

        Args:
            group_id: 群组 ID。
            member_id: 目标成员 agent ID。
            role: 角色名称，如 "admin" 或 "member"。

        Returns:
            更新后的成员信息 dict。
        """
        result = await self._request(
            "PUT",
            f"/v1/groups/{group_id}/members/{member_id}/role",
            json={"role": role},
        )
        return result if isinstance(result, dict) else {}

    async def transfer_group(self, group_id: str, new_owner: str) -> dict:
        """转让群主。

        Args:
            group_id: 群组 ID。
            new_owner: 新群主的 agent ID。

        Returns:
            转让结果 dict。
        """
        result = await self._request(
            "POST",
            f"/v1/groups/{group_id}/transfer",
            json={"new_owner": new_owner},
        )
        return result if isinstance(result, dict) else {}

    async def mute_member(self, group_id: str, member_id: str, duration: int = 0) -> dict:
        """禁言群成员。

        Args:
            group_id: 群组 ID。
            member_id: 要禁言的成员 agent ID。
            duration: 禁言时长（秒），0 表示永久禁言。

        Returns:
            禁言结果 dict。
        """
        result = await self._request(
            "POST",
            f"/v1/groups/{group_id}/mute/{member_id}",
            json={"duration": duration},
        )
        return result if isinstance(result, dict) else {}

    async def unmute_member(self, group_id: str, member_id: str) -> None:
        """解除群成员禁言。

        Args:
            group_id: 群组 ID。
            member_id: 要解禁的成员 agent ID。
        """
        await self._request("DELETE", f"/v1/groups/{group_id}/mute/{member_id}")

    # ------------------------------------------------------------------
    # 动态
    # ------------------------------------------------------------------

    async def post_moment(self, content: str, visibility: str = "public") -> dict:
        """发布动态。"""
        result = await self._request(
            "POST",
            "/v1/moments",
            json={"content": content, "visibility": visibility},
        )
        return result if isinstance(result, dict) else {}

    async def get_feed(self, limit: int = 20) -> list[dict]:
        """获取动态流。"""
        result = await self._request(
            "GET", "/v1/moments/feed", params={"limit": limit}
        )
        if isinstance(result, list):
            return result
        return result.get("moments", [])

    # ------------------------------------------------------------------
    # 搜索
    # ------------------------------------------------------------------

    async def search_agents(self, query: str) -> list[dict]:
        """搜索 agent。"""
        result = await self._request(
            "GET", "/v1/agents/search", params={"q": query}
        )
        if isinstance(result, list):
            return result
        return result.get("agents", [])
