"""Dispatch handlers, catalog sync, and profile/autoload for capability_ops."""

from __future__ import annotations

import json
import sys
import uuid
from typing import Any, Dict, List, Optional, Tuple

from ....contracts.v1 import DaemonResponse
from ....kernel.capabilities import BUILTIN_CAPABILITY_PACKS, BUILTIN_CAPSULE_SKILLS
from ....util.time import parse_utc_iso, utc_now_iso

from ._common import (
    _SOURCE_IDS,
    _CATALOG_LOCK,
    _STATE_LOCK,
    _RUNTIME_LOCK,
    _LEVEL_INDEXED,
    _LEVEL_MOUNTED,
    _QUAL_QUALIFIED,
    _QUAL_BLOCKED,
    _QUAL_UNAVAILABLE,
    _QUAL_STATES,
    _error,
    _ensure_group,
    _is_foreman,
    _normalize_scope,
    _env_bool,
    _quota_limit,
)
from ._documents import (
    _source_state_template,
    _load_state_doc,
    _save_state_doc,
    _load_runtime_doc,
    _save_runtime_doc,
)
from ._runtime import (
    _runtime_artifacts,
    _runtime_capability_artifacts,
    _runtime_actor_bindings,
    _record_runtime_recent_success,
    _set_runtime_actor_binding,
    _remove_runtime_group_capability_bindings,
    _remove_runtime_capability_artifact,
    _remove_runtime_artifact_if_unreferenced,
    _append_audit_event,
)
from ._install import (
    _catalog_staleness_seconds,
    _needs_registry_hydration,
    _supported_external_install_record,
    _tool_name_aliases,
    _build_synthetic_tool_name,
    _invoke_installed_external_tool_with_aliases,
)
from ._policy import _normalize_policy_level
from ._remote import _mark_source_disabled
from ._state import (
    _binding_state_allows_external_tool,
    _install_state_allows_external_tool,
    _collect_enabled_capabilities,
    _collect_blocked_capabilities,
    _remove_capability_bindings,
    _has_any_binding_for_capability,
    handle_capability_enable,
)
from ._search import (
    _display_name_from_capability_id,
    _render_source_states,
)


def _pkg():
    """Get parent package module for mock-compatible function lookups."""
    return sys.modules[__name__.rsplit(".", 1)[0]]


def _normalize_recommendation_lines(raw: Any, *, max_items: int = 4, max_chars: int = 180) -> List[str]:
    items: List[str] = []
    if isinstance(raw, (list, tuple)):
        items = [str(x or "").strip() for x in raw if str(x or "").strip()]
    else:
        single = str(raw or "").strip()
        if single:
            items = [single]
    out: List[str] = []
    seen: set[str] = set()
    for item in items:
        normalized = " ".join(str(item or "").split()).strip()
        if not normalized:
            continue
        if len(normalized) > max_chars:
            normalized = normalized[: max_chars - 3].rstrip() + "..."
        key = normalized.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(normalized)
        if len(out) >= max_items:
            break
    return out


def _normalize_recommendation_fields(raw: Any) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    payload: Dict[str, Any] = {}
    for field in ("use_when", "avoid_when", "gotchas"):
        rows = _normalize_recommendation_lines(raw.get(field))
        if rows:
            payload[field] = rows
    evidence_kind = " ".join(str(raw.get("evidence_kind") or "").split()).strip()
    if evidence_kind:
        if len(evidence_kind) > 180:
            evidence_kind = evidence_kind[:177].rstrip() + "..."
        payload["evidence_kind"] = evidence_kind
    return payload


def _build_import_readiness_preview(
    *,
    rec: Dict[str, Any],
    capability_id: str,
    policy: Dict[str, Any],
    policy_level: str,
    enable_block_reason: str,
    diagnostics: List[Dict[str, Any]],
    probe_result: Dict[str, Any],
) -> Dict[str, Any]:
    qualification_status = str(rec.get("qualification_status") or _QUAL_QUALIFIED).strip().lower()
    preview = _pkg()._build_readiness_preview(
        rec=rec,
        capability_id=capability_id,
        policy=policy,
        policy_level=policy_level,
        blocked_reason_code=(enable_block_reason if enable_block_reason in {"policy_level_indexed", "qualification_blocked", "capability_unavailable"} else ""),
        qualification_status=qualification_status,
        enable_supported=bool(_pkg()._record_enable_supported(rec, capability_id=capability_id)),
        recent_success=None,
    )
    if str(probe_result.get("state") or "").strip().lower() == "failed":
        code = str(probe_result.get("install_error_code") or "probe_failed").strip() or "probe_failed"
        retryable = bool(probe_result.get("retryable"))
        if code in {"missing_required_env", "runtime_permission_denied", "runtime_binary_missing", "unsupported_external_installer"}:
            preview["preview_status"] = "blocked"
            preview["enable_block_reason"] = code
            preview["next_step"] = "fix_known_blocker"
        elif not retryable:
            preview["preview_status"] = "needs_inspect"
            preview["enable_block_reason"] = code
            preview["next_step"] = "inspect"
        preview["probe_state"] = "failed"
    elif str(probe_result.get("state") or "").strip().lower() in {"ready", "runnable"}:
        preview["probe_state"] = "runnable"
    elif str(probe_result.get("state") or "").strip().lower() == "skipped":
        preview["probe_state"] = "skipped"
    if diagnostics:
        preview["diagnostics"] = diagnostics
    return preview


# ---------------------------------------------------------------------------
# Curated / policy-apply helpers
# ---------------------------------------------------------------------------

def _curated_install_metadata(install_mode_preference: str) -> Tuple[str, Dict[str, Any]]:
    pref = str(install_mode_preference or "").strip().lower()
    if pref == "remote_only":
        return "remote_only", {"transport": "http", "url": ""}
    if pref == "package:npm":
        return "package", {"registry_type": "npm", "runtime_hint": "npx", "identifier": "", "version": ""}
    if pref.startswith("package:"):
        return "package", {"registry_type": pref.split(":", 1)[1], "runtime_hint": "", "identifier": "", "version": ""}
    return "", {}


def _build_curated_records_from_policy(policy: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    now_iso = utc_now_iso()
    out: Dict[str, Dict[str, Any]] = {}
    mcp_rows = policy.get("curated_mcp_entries") if isinstance(policy.get("curated_mcp_entries"), list) else []
    for raw in mcp_rows:
        if not isinstance(raw, dict):
            continue
        cap_id = str(raw.get("capability_id") or "").strip()
        if not cap_id.startswith("mcp:"):
            continue
        level = _normalize_policy_level(raw.get("level"), default=_LEVEL_MOUNTED)
        trust = str(raw.get("trust") or "").strip().lower()
        notes = str(raw.get("notes") or "").strip()
        risk_tags_raw = raw.get("risk_tags")
        risk_tags = [str(x).strip() for x in risk_tags_raw if str(x).strip()] if isinstance(risk_tags_raw, list) else []
        required_secrets_raw = raw.get("required_secrets")
        required_secrets = (
            [str(x).strip() for x in required_secrets_raw if str(x).strip()]
            if isinstance(required_secrets_raw, list)
            else []
        )
        install_mode, install_spec = _curated_install_metadata(str(raw.get("install_mode_preference") or ""))
        supported, unsupported_reason = _supported_external_install_record(
            {"install_mode": install_mode, "install_spec": install_spec}
        )
        hydration_needed = _needs_registry_hydration(
            cap_id,
            {"capability_id": cap_id, "kind": "mcp_toolpack", "install_mode": install_mode, "install_spec": install_spec},
        )
        qualification = _QUAL_QUALIFIED if (supported or hydration_needed) else _QUAL_UNAVAILABLE
        reasons: List[str] = []
        if level == _LEVEL_INDEXED:
            reasons.append("curated_indexed_default")
        if risk_tags:
            reasons.append("risk_tags_present")
        if unsupported_reason:
            reasons.append(unsupported_reason)
        out[cap_id] = {
            "capability_id": cap_id,
            "kind": "mcp_toolpack",
            "name": _display_name_from_capability_id(cap_id),
            "description_short": notes or f"Curated MCP capability {cap_id}",
            "tags": ["mcp", "external", "curated", *risk_tags],
            "source_id": "mcp_registry_official",
            "source_tier": "tier1",
            "source_uri": "",
            "source_record_id": cap_id.split(":", 1)[1],
            "source_record_version": "",
            "updated_at_source": now_iso,
            "last_synced_at": now_iso,
            "sync_state": "curated",
            "install_mode": install_mode,
            "install_spec": install_spec,
            "requirements": {"required_secrets": required_secrets} if required_secrets else {},
            "license": "",
            "trust_tier": trust or "tier1",
            "qualification_status": qualification,
            "qualification_reasons": reasons,
            "health_status": "curated",
            "enable_supported": bool(supported or hydration_needed),
        }

    skill_rows = policy.get("curated_skill_entries") if isinstance(policy.get("curated_skill_entries"), list) else []
    for raw in skill_rows:
        if not isinstance(raw, dict):
            continue
        cap_id = str(raw.get("capability_id") or "").strip()
        if not cap_id.startswith("skill:"):
            continue
        name = str(raw.get("name") or "").strip() or _display_name_from_capability_id(cap_id).replace(" ", "-")
        level = _normalize_policy_level(raw.get("level"), default=_LEVEL_MOUNTED)
        trust = str(raw.get("trust") or "").strip().lower()
        notes = str(raw.get("notes") or "").strip()
        source_id = str(raw.get("source_id") or "anthropic_skills").strip() or "anthropic_skills"
        source_uri = str(raw.get("source_uri") or "").strip()
        description_short = str(raw.get("description_short") or "").strip()
        license_text = str(raw.get("license") or "").strip()
        tags_raw = raw.get("tags")
        tags = [str(x).strip() for x in tags_raw if str(x).strip()] if isinstance(tags_raw, list) else []
        if source_id == "anthropic_skills" and "anthropic" not in {t.lower() for t in tags}:
            tags.append("anthropic")
        requires_raw = raw.get("requires_capabilities")
        requires_capabilities = (
            [str(x).strip() for x in requires_raw if str(x).strip()]
            if isinstance(requires_raw, list)
            else []
        )
        capsule_text = str(raw.get("capsule_text") or "").strip()
        qualification = str(raw.get("qualification_status") or "").strip().lower()
        if qualification not in _QUAL_STATES:
            qualification = _QUAL_QUALIFIED
        reasons_raw = raw.get("qualification_reasons")
        reasons = (
            [str(x).strip() for x in reasons_raw if str(x).strip()]
            if isinstance(reasons_raw, list)
            else []
        )
        if not reasons and qualification != _QUAL_QUALIFIED:
            reasons = [f"curated_{qualification}"]
        if not source_uri and source_id == "anthropic_skills":
            source_uri = f"https://github.com/anthropics/skills/tree/main/skills/{name}"
        if not description_short:
            description_short = notes or f"Curated skill {name}"
        if not capsule_text:
            capsule_text = f"Skill: {name}\nSummary: {description_short}".strip()
        recommendation_fields = _normalize_recommendation_fields(raw)
        out[cap_id] = {
            "capability_id": cap_id,
            "kind": "skill",
            "name": name,
            "description_short": description_short,
            "tags": ["skill", "external", "curated", *tags],
            "source_id": source_id,
            "source_tier": "tier1" if source_id == "anthropic_skills" else "tier2",
            "source_uri": source_uri,
            "source_record_id": name,
            "source_record_version": "",
            "updated_at_source": now_iso,
            "last_synced_at": now_iso,
            "sync_state": "curated",
            "install_mode": "builtin",
            "install_spec": {},
            "requirements": {},
            "license": license_text,
            "trust_tier": trust or ("tier1" if source_id == "anthropic_skills" else "tier2"),
            "qualification_status": qualification,
            "qualification_reasons": reasons,
            "health_status": "curated",
            "enable_supported": qualification != _QUAL_BLOCKED,
            "capsule_text": capsule_text,
            "requires_capabilities": requires_capabilities,
            **recommendation_fields,
        }
    return out


def _build_builtin_skill_records() -> Dict[str, Dict[str, Any]]:
    now_iso = utc_now_iso()
    out: Dict[str, Dict[str, Any]] = {}
    for cap_id, raw in BUILTIN_CAPSULE_SKILLS.items():
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("name") or "").strip() or _display_name_from_capability_id(cap_id).replace(" ", "-")
        description_short = str(raw.get("description_short") or "").strip()
        capsule_text = str(raw.get("capsule_text") or "").strip()
        tags = [str(x).strip() for x in (raw.get("tags") if isinstance(raw.get("tags"), (list, tuple)) else []) if str(x).strip()]
        requires_capabilities = [
            str(x).strip()
            for x in (raw.get("requires_capabilities") if isinstance(raw.get("requires_capabilities"), (list, tuple)) else [])
            if str(x).strip()
        ]
        recommendation_fields = _normalize_recommendation_fields(raw)
        out[cap_id] = {
            "capability_id": cap_id,
            "kind": "skill",
            "name": name,
            "description_short": description_short,
            "tags": ["skill", "builtin", *tags],
            "source_id": "cccc_builtin",
            "source_tier": "builtin",
            "source_uri": "",
            "source_record_id": name,
            "source_record_version": "",
            "updated_at_source": now_iso,
            "last_synced_at": now_iso,
            "sync_state": "builtin",
            "install_mode": "builtin",
            "install_spec": {},
            "requirements": {},
            "license": "",
            "trust_tier": "builtin",
            "qualification_status": _QUAL_QUALIFIED,
            "qualification_reasons": [],
            "health_status": "builtin",
            "enable_supported": True,
            "capsule_text": capsule_text or f"Skill: {name}\nSummary: {description_short}".strip(),
            "requires_capabilities": requires_capabilities,
            **recommendation_fields,
        }
    return out


def _ensure_curated_catalog_records(catalog_doc: Dict[str, Any], *, policy: Dict[str, Any]) -> bool:
    records = catalog_doc.get("records") if isinstance(catalog_doc.get("records"), dict) else {}
    if not isinstance(records, dict):
        records = {}
    curated = {
        **_build_builtin_skill_records(),
        **_build_curated_records_from_policy(policy),
    }
    if not curated:
        return False

    changed = False
    touched_sources: set[str] = set()
    for cap_id, rec in curated.items():
        existing = records.get(cap_id) if isinstance(records.get(cap_id), dict) else None
        if isinstance(existing, dict):
            if existing == rec:
                continue
            touched_sources.add(str(existing.get("source_id") or "").strip())
            records[cap_id] = rec
            touched_sources.add(str(rec.get("source_id") or "").strip())
            changed = True
            continue
        records[cap_id] = rec
        touched_sources.add(str(rec.get("source_id") or "").strip())
        changed = True
    if not changed:
        return False

    catalog_doc["records"] = records
    sources = catalog_doc.get("sources") if isinstance(catalog_doc.get("sources"), dict) else {}
    now_iso = utc_now_iso()
    for source_id in touched_sources:
        if not source_id:
            continue
        state = sources.get(source_id) if isinstance(sources.get(source_id), dict) else _source_state_template("never")
        if str(state.get("sync_state") or "").strip() in {"", "never", "disabled"}:
            state["sync_state"] = "curated"
        if not str(state.get("last_synced_at") or "").strip():
            state["last_synced_at"] = now_iso
        state["error"] = ""
        state["staleness_seconds"] = _catalog_staleness_seconds(str(state.get("last_synced_at") or ""))
        sources[source_id] = state
    catalog_doc["sources"] = sources
    _refresh_source_record_counts(catalog_doc)
    return True


# ---------------------------------------------------------------------------
# Catalog pruning / sorting / sync
# ---------------------------------------------------------------------------

def _sync_tier_rank(tier: str) -> int:
    t = str(tier or "").strip().lower()
    if t in {"builtin", "official", "tier1"}:
        return 0
    if t in {"tier2"}:
        return 1
    return 2


def _qualification_rank(q: str) -> int:
    status = str(q or "").strip().lower()
    if status == _QUAL_QUALIFIED:
        return 0
    if status == _QUAL_UNAVAILABLE:
        return 1
    if status == _QUAL_BLOCKED:
        return 2
    return 3


def _catalog_record_sort_key(item: Dict[str, Any]) -> Tuple[int, int, int, int, str]:
    source_tier = str(item.get("source_tier") or "")
    qual = str(item.get("qualification_status") or "")
    updated_at_source = str(item.get("updated_at_source") or "")
    last_synced_at = str(item.get("last_synced_at") or "")
    name = str(item.get("name") or item.get("capability_id") or "").lower()
    updated_dt = parse_utc_iso(updated_at_source)
    synced_dt = parse_utc_iso(last_synced_at)
    updated_rank = -int(updated_dt.timestamp()) if updated_dt is not None else 0
    synced_rank = -int(synced_dt.timestamp()) if synced_dt is not None else 0
    return (
        _sync_tier_rank(source_tier),
        _qualification_rank(qual),
        updated_rank,
        synced_rank,
        name,
    )


def _catalog_max_records() -> int:
    return _quota_limit(
        "CCCC_CAPABILITY_CATALOG_MAX_RECORDS",
        20_000,
        minimum=200,
        maximum=500_000,
    )


def _prune_catalog_records(catalog: Dict[str, Any]) -> int:
    records = catalog.get("records") if isinstance(catalog.get("records"), dict) else {}
    if not isinstance(records, dict):
        return 0
    max_records = _catalog_max_records()
    if len(records) <= max_records:
        return 0
    rows: List[Tuple[str, Dict[str, Any]]] = []
    for cap_id, rec in records.items():
        if not isinstance(rec, dict):
            continue
        rows.append((str(cap_id or ""), dict(rec)))
    rows.sort(key=lambda x: _catalog_record_sort_key(x[1]))
    # Keep best candidates, then stable-id for deterministic output.
    keep_rows = rows[:max_records]
    keep_rows.sort(key=lambda x: str(x[0] or ""))
    keep_ids = {str(cap_id or "") for cap_id, _ in keep_rows}
    pruned = max(0, len(records) - len(keep_ids))
    if pruned <= 0:
        return 0
    catalog["records"] = {cid: rec for cid, rec in records.items() if str(cid or "") in keep_ids}
    return pruned


def _refresh_source_record_counts(catalog: Dict[str, Any]) -> None:
    sources = catalog.get("sources") if isinstance(catalog.get("sources"), dict) else {}
    records = catalog.get("records") if isinstance(catalog.get("records"), dict) else {}
    counts = {source_id: 0 for source_id in _SOURCE_IDS}
    for rec in records.values() if isinstance(records, dict) else []:
        if not isinstance(rec, dict):
            continue
        sid = str(rec.get("source_id") or "").strip()
        if sid in counts:
            counts[sid] += 1
    for source_id in _SOURCE_IDS:
        state = sources.get(source_id) if isinstance(sources.get(source_id), dict) else _source_state_template("never")
        state["record_count"] = int(counts.get(source_id) or 0)
        sources[source_id] = state
    catalog["sources"] = sources


def _sync_catalog(catalog_doc: Dict[str, Any], *, force: bool) -> Dict[str, Any]:
    before = json.dumps(catalog_doc, ensure_ascii=False, sort_keys=True)
    upserted: Dict[str, int] = {}

    if _env_bool("CCCC_CAPABILITY_SOURCE_MCP_REGISTRY_ENABLED", True):
        upserted["mcp_registry_official"] = int(_pkg()._sync_mcp_registry_source(catalog_doc, force=force))
    else:
        _mark_source_disabled(catalog_doc, "mcp_registry_official")
        upserted["mcp_registry_official"] = 0

    if _env_bool("CCCC_CAPABILITY_SOURCE_ANTHROPIC_SKILLS_ENABLED", True):
        upserted["anthropic_skills"] = int(_pkg()._sync_anthropic_skills_source(catalog_doc, force=force))
    else:
        _mark_source_disabled(catalog_doc, "anthropic_skills")
        upserted["anthropic_skills"] = 0

    pruned = _prune_catalog_records(catalog_doc)
    _refresh_source_record_counts(catalog_doc)

    after = json.dumps(catalog_doc, ensure_ascii=False, sort_keys=True)
    return {
        "changed": (before != after),
        "upserted": upserted,
        "upserted_total": sum(max(0, int(v or 0)) for v in upserted.values()),
        "pruned": int(pruned),
    }


def _auto_sync_catalog(catalog_doc: Dict[str, Any]) -> bool:
    return bool(_sync_catalog(catalog_doc, force=False).get("changed"))


def sync_capability_catalog_once(*, force: bool = False) -> Dict[str, Any]:
    """Run one capability catalog sync pass and persist if changed.

    Intended for daemon-owned background sync loops. Does not raise.
    """
    try:
        with _CATALOG_LOCK:
            catalog_path, catalog_doc = _pkg()._load_catalog_doc()
            result = _pkg()._sync_catalog(catalog_doc, force=bool(force))
            if bool(result.get("changed")):
                _pkg()._save_catalog_doc(catalog_path, catalog_doc)
        return {
            "ok": True,
            "changed": bool(result.get("changed")),
            "upserted_total": int(result.get("upserted_total") or 0),
            "upserted": result.get("upserted") if isinstance(result.get("upserted"), dict) else {},
            "pruned": int(result.get("pruned") or 0),
            "source_states": _render_source_states(catalog_doc),
        }
    except Exception as e:
        return {
            "ok": False,
            "changed": False,
            "upserted_total": 0,
            "upserted": {},
            "pruned": 0,
            "error": str(e),
            "source_states": {},
        }


# ---------------------------------------------------------------------------
# Profile / autoload helpers
# ---------------------------------------------------------------------------

def _normalize_capability_id_list(raw: Any) -> List[str]:
    out: List[str] = []
    if not isinstance(raw, list):
        return out
    seen: set[str] = set()
    for item in raw:
        cap_id = str(item or "").strip()
        if not cap_id or cap_id in seen:
            continue
        seen.add(cap_id)
        out.append(cap_id)
    return out


def _normalize_profile_capability_defaults(raw: Any) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        return {"autoload_capabilities": [], "default_scope": "actor", "session_ttl_seconds": 3600}
    scope = str(raw.get("default_scope") or "actor").strip().lower()
    if scope not in {"actor", "session"}:
        scope = "actor"
    try:
        ttl = int(raw.get("session_ttl_seconds") or 3600)
    except Exception:
        ttl = 3600
    ttl = max(60, min(ttl, 24 * 3600))
    autoload = _normalize_capability_id_list(raw.get("autoload_capabilities"))
    return {"autoload_capabilities": autoload, "default_scope": scope, "session_ttl_seconds": ttl}


def apply_actor_profile_capability_defaults(
    *,
    group_id: str,
    actor_id: str,
    profile_id: str,
    capability_defaults: Any,
) -> Dict[str, Any]:
    cfg = _normalize_profile_capability_defaults(capability_defaults)
    requested = list(cfg.get("autoload_capabilities") or [])
    scope = str(cfg.get("default_scope") or "actor")
    ttl_seconds = int(cfg.get("session_ttl_seconds") or 3600)
    if not requested:
        return {
            "requested_count": 0,
            "applied": [],
            "skipped": [],
            "scope": scope,
            "ttl_seconds": ttl_seconds,
        }

    applied: List[str] = []
    skipped: List[Dict[str, str]] = []
    for cap_id in requested:
        resp = handle_capability_enable(
            {
                "group_id": group_id,
                "by": "user",
                "actor_id": actor_id,
                "capability_id": cap_id,
                "scope": scope,
                "enabled": True,
                "ttl_seconds": ttl_seconds,
                "reason": f"profile_default:{profile_id}",
            }
        )
        if not bool(resp.ok):
            code = str((resp.error.code if resp.error else "") or "enable_failed")
            skipped.append({"capability_id": cap_id, "reason": code})
            continue
        result = resp.result if isinstance(resp.result, dict) else {}
        state = str(result.get("state") or "").strip().lower()
        if state == "ready" and bool(result.get("enabled", True)):
            applied.append(cap_id)
            continue
        reason = str(result.get("reason") or state or "not_ready")
        skipped.append({"capability_id": cap_id, "reason": reason})
    return {
        "requested_count": len(requested),
        "applied": applied,
        "skipped": skipped,
        "scope": scope,
        "ttl_seconds": ttl_seconds,
    }


def apply_actor_capability_autoload(
    *,
    group_id: str,
    actor_id: str,
    autoload_capabilities: Any,
    scope: str = "actor",
    ttl_seconds: int = 3600,
    reason: str = "actor_autoload",
) -> Dict[str, Any]:
    requested = _normalize_capability_id_list(autoload_capabilities)
    eff_scope = str(scope or "actor").strip().lower()
    if eff_scope not in {"actor", "session"}:
        eff_scope = "actor"
    try:
        eff_ttl = int(ttl_seconds or 3600)
    except Exception:
        eff_ttl = 3600
    eff_ttl = max(60, min(eff_ttl, 24 * 3600))
    if not requested:
        return {
            "requested_count": 0,
            "applied": [],
            "skipped": [],
            "scope": eff_scope,
            "ttl_seconds": eff_ttl,
        }

    applied: List[str] = []
    skipped: List[Dict[str, str]] = []
    for cap_id in requested:
        resp = handle_capability_enable(
            {
                "group_id": group_id,
                "by": "user",
                "actor_id": actor_id,
                "capability_id": cap_id,
                "scope": eff_scope,
                "enabled": True,
                "ttl_seconds": eff_ttl,
                "reason": reason,
            }
        )
        if not bool(resp.ok):
            code = str((resp.error.code if resp.error else "") or "enable_failed")
            skipped.append({"capability_id": cap_id, "reason": code})
            continue
        result = resp.result if isinstance(resp.result, dict) else {}
        state = str(result.get("state") or "").strip().lower()
        if state == "ready" and bool(result.get("enabled", True)):
            applied.append(cap_id)
            continue
        reason_code = str(result.get("reason") or state or "not_ready")
        skipped.append({"capability_id": cap_id, "reason": reason_code})
    return {
        "requested_count": len(requested),
        "applied": applied,
        "skipped": skipped,
        "scope": eff_scope,
        "ttl_seconds": eff_ttl,
    }


# ---------------------------------------------------------------------------
# handle_capability_import
# ---------------------------------------------------------------------------

def _normalize_import_kind(raw_kind: Any) -> str:
    kind = str(raw_kind or "").strip().lower()
    if kind in {"mcp", "mcp_tool", "mcp_toolpack"}:
        return "mcp_toolpack"
    if kind == "skill":
        return "skill"
    return ""


def _coerce_import_source_id(kind: str, raw_source_id: Any) -> str:
    source_id = str(raw_source_id or "").strip()
    if source_id:
        return source_id if source_id in _SOURCE_IDS else "manual_import"
    return "manual_import"


def _normalize_import_tags(raw: Any, *, kind: str) -> List[str]:
    out: List[str] = []
    if isinstance(raw, list):
        for item in raw:
            token = str(item or "").strip()
            if token and token not in out:
                out.append(token)
    for token in ("external", "imported", "skill" if kind == "skill" else "mcp"):
        if token not in out:
            out.append(token)
    return out[:64]


def _normalize_import_reasons(raw: Any) -> List[str]:
    out: List[str] = []
    if isinstance(raw, list):
        for item in raw:
            token = str(item or "").strip()
            if token and token not in out:
                out.append(token)
    return out[:32]


def _normalize_import_requires(raw: Any) -> List[str]:
    out: List[str] = []
    if isinstance(raw, list):
        for item in raw:
            token = str(item or "").strip()
            if token and token not in out:
                out.append(token)
    return out[:32]


def _has_import_command_tokens(raw: Any) -> bool:
    if isinstance(raw, str):
        return bool(raw.strip())
    if isinstance(raw, list):
        return any(bool(str(item or "").strip()) for item in raw)
    return False


def _normalize_import_record(raw_record: Any) -> Dict[str, Any]:
    if not isinstance(raw_record, dict):
        raise ValueError("record must be an object")

    now_iso = utc_now_iso()
    cap_id = str(raw_record.get("capability_id") or "").strip()
    if not cap_id:
        raise ValueError("record.capability_id is required")
    kind = _normalize_import_kind(raw_record.get("kind"))
    if not kind:
        raise ValueError("record.kind must be mcp_toolpack or skill")

    if kind == "mcp_toolpack" and not cap_id.startswith("mcp:"):
        raise ValueError("mcp capability_id must start with mcp:")
    if kind == "skill" and not cap_id.startswith("skill:"):
        raise ValueError("skill capability_id must start with skill:")

    source_id = _coerce_import_source_id(kind, raw_record.get("source_id"))
    source_uri = str(raw_record.get("source_uri") or "").strip()
    source_tier = str(raw_record.get("source_tier") or "").strip() or "tier2"
    trust_tier = str(raw_record.get("trust_tier") or "").strip() or "tier2"
    source_record_id = str(raw_record.get("source_record_id") or "").strip() or cap_id
    source_record_version = str(raw_record.get("source_record_version") or "").strip()
    updated_at_source = str(raw_record.get("updated_at_source") or "").strip() or now_iso
    name = str(raw_record.get("name") or "").strip() or _display_name_from_capability_id(cap_id)
    description_short = str(raw_record.get("description_short") or "").strip()
    if not description_short:
        description_short = f"Imported capability {cap_id}"
    license_text = str(raw_record.get("license") or "").strip()
    qualification = str(raw_record.get("qualification_status") or "").strip().lower()
    if qualification not in _QUAL_STATES:
        qualification = ""
    qualification_reasons = _normalize_import_reasons(raw_record.get("qualification_reasons"))
    tags = _normalize_import_tags(raw_record.get("tags"), kind=kind)
    recommendation_fields = _normalize_recommendation_fields(raw_record)

    if kind == "mcp_toolpack":
        install_mode = str(raw_record.get("install_mode") or "").strip().lower()
        if install_mode not in {"remote_only", "package", "command"}:
            raise ValueError("mcp import requires record.install_mode in {remote_only, package, command}")
        install_spec = raw_record.get("install_spec")
        if not isinstance(install_spec, dict):
            raise ValueError("mcp import requires record.install_spec object")
        install_spec = dict(install_spec)
        if "command" not in install_spec and raw_record.get("command") is not None:
            install_spec["command"] = raw_record.get("command")
        if "command_candidates" not in install_spec and raw_record.get("command_candidates") is not None:
            install_spec["command_candidates"] = raw_record.get("command_candidates")
        if "fallback_command" not in install_spec and raw_record.get("fallback_command") is not None:
            install_spec["fallback_command"] = raw_record.get("fallback_command")
        if (
            "fallback_command_candidates" not in install_spec
            and raw_record.get("fallback_command_candidates") is not None
        ):
            install_spec["fallback_command_candidates"] = raw_record.get("fallback_command_candidates")
        if install_mode == "command":
            command = install_spec.get("command")
            command_candidates = install_spec.get("command_candidates")
            has_command = _has_import_command_tokens(command)
            has_command_candidates = False
            if isinstance(command_candidates, list):
                for row in command_candidates:
                    if _has_import_command_tokens(row):
                        has_command_candidates = True
                        break
            if not (has_command or has_command_candidates):
                raise ValueError("command install_mode requires install_spec.command or install_spec.command_candidates")
        rec: Dict[str, Any] = {
            "capability_id": cap_id,
            "kind": "mcp_toolpack",
            "name": name,
            "description_short": description_short,
            "tags": tags,
            "source_id": source_id,
            "source_tier": source_tier,
            "source_uri": source_uri,
            "source_record_id": source_record_id,
            "source_record_version": source_record_version,
            "updated_at_source": updated_at_source,
            "last_synced_at": now_iso,
            "sync_state": "imported",
            "install_mode": install_mode,
            "install_spec": install_spec,
            "requirements": {},
            "license": license_text,
            "trust_tier": trust_tier,
            "health_status": "imported",
        }
        supported, unsupported_reason = _supported_external_install_record(rec)
        if not qualification:
            qualification = _QUAL_QUALIFIED if supported else _QUAL_UNAVAILABLE
        if unsupported_reason and unsupported_reason not in qualification_reasons:
            qualification_reasons.append(unsupported_reason)
        rec["qualification_status"] = qualification
        rec["qualification_reasons"] = qualification_reasons
        rec["enable_supported"] = bool(
            qualification != _QUAL_BLOCKED and supported
        )
        rec.update(recommendation_fields)
        return rec

    capsule_text = str(raw_record.get("capsule_text") or "").strip()
    if not capsule_text:
        raise ValueError("skill import requires record.capsule_text")
    requires_capabilities = _normalize_import_requires(raw_record.get("requires_capabilities"))
    if not qualification:
        qualification = _QUAL_QUALIFIED
    rec = {
        "capability_id": cap_id,
        "kind": "skill",
        "name": name,
        "description_short": description_short,
        "tags": tags,
        "source_id": source_id,
        "source_tier": source_tier,
        "source_uri": source_uri,
        "source_record_id": source_record_id,
        "source_record_version": source_record_version,
        "updated_at_source": updated_at_source,
        "last_synced_at": now_iso,
        "sync_state": "imported",
        "install_mode": "builtin",
        "install_spec": {},
        "requirements": {},
        "license": license_text,
        "trust_tier": trust_tier,
        "qualification_status": qualification,
        "qualification_reasons": qualification_reasons,
        "health_status": "imported",
        "enable_supported": qualification != _QUAL_BLOCKED,
        "capsule_text": capsule_text[:2400],
        "requires_capabilities": requires_capabilities,
        **recommendation_fields,
    }
    return rec


def _probe_import_record(rec: Dict[str, Any], *, capability_id: str, enabled: bool) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    if not enabled:
        return ({"state": "skipped"}, [])
    kind = str(rec.get("kind") or "").strip().lower()
    if kind == "skill":
        return (
            {
                "state": "runnable",
                "kind": "skill",
                "capsule_present": bool(str(rec.get("capsule_text") or "").strip()),
            },
            [],
        )
    try:
        install = _pkg()._install_external_capability(rec, capability_id=capability_id)
        tools = install.get("tools") if isinstance(install.get("tools"), list) else []
        names = [
            str(item.get("real_tool_name") or item.get("name") or "").strip()
            for item in tools
            if isinstance(item, dict)
        ]
        names = [name for name in names if name]
        install_state = str(install.get("state") or "").strip() or "installed"
        probe = {
            "state": "runnable",
            "kind": "mcp_toolpack",
            "install_state": install_state,
            "installer": str(install.get("installer") or ""),
            "tool_count": len(names),
            "tool_names": names[:64],
            "degraded": install_state == "installed_degraded",
            "install_error_code": str(install.get("last_error_code") or ""),
            "install_error": str(install.get("last_error") or ""),
        }
        return probe, []
    except Exception as e:
        diagnostics = _pkg()._diagnostics_from_install_error(e)
        info = _pkg()._classify_external_install_error(e)
        code = str(info.get("code") or "probe_failed")
        probe = {
            "state": "failed",
            "kind": "mcp_toolpack",
            "reason": f"probe_failed:{code}",
            "install_error_code": code,
            "install_error": str(e),
            "retryable": bool(info.get("retryable")),
        }
        return probe, diagnostics


def handle_capability_import(args: Dict[str, Any]) -> DaemonResponse:
    group_id = str(args.get("group_id") or "").strip()
    by = str(args.get("by") or args.get("actor_id") or "").strip()
    actor_id = str(args.get("actor_id") or by).strip()
    dry_run = bool(args.get("dry_run", False))
    probe = bool(args.get("probe", True))
    enable_after_import = bool(args.get("enable_after_import", False))
    scope = _normalize_scope(args.get("scope"))
    ttl_seconds_raw = args.get("ttl_seconds")
    try:
        ttl_seconds = int(ttl_seconds_raw if ttl_seconds_raw is not None else 3600)
    except Exception:
        raise ValueError("invalid ttl_seconds")
    reason = str(args.get("reason") or "").strip()
    action_id = f"cact_{uuid.uuid4().hex[:16]}"

    def _audit(
        outcome: str,
        *,
        state: str = "",
        error_code: str = "",
        details: Optional[Dict[str, Any]] = None,
        capability_id: str = "",
    ) -> None:
        payload = dict(details) if isinstance(details, dict) else {}
        if state:
            payload["state"] = state
        if error_code:
            payload["error_code"] = error_code
        if reason:
            payload["reason"] = reason
        try:
            _append_audit_event(
                action_id=action_id,
                op="capability_import",
                group_id=group_id,
                actor_id=actor_id,
                by=by,
                capability_id=str(capability_id or ""),
                scope=scope,
                enabled=bool(enable_after_import),
                outcome=outcome,
                details=payload,
            )
        except Exception:
            pass

    try:
        group = _ensure_group(group_id)
        if by != "user":
            if not by:
                _audit("denied", state="denied", error_code="missing_actor_id")
                return _error("missing_actor_id", "missing actor identity (by)", details={"action_id": action_id})
            actors = group.doc.get("actors") if isinstance(group.doc.get("actors"), list) else []
            known = {str(item.get("id") or "").strip() for item in actors if isinstance(item, dict)}
            if by not in known:
                _audit("denied", state="denied", error_code="actor_not_found")
                return _error("actor_not_found", f"actor not found in group: {by}", details={"action_id": action_id})
            if actor_id and actor_id != by:
                _audit("denied", state="denied", error_code="permission_denied")
                return _error(
                    "permission_denied",
                    "actor can only import capabilities as self",
                    details={"action_id": action_id},
                )
        rec = _normalize_import_record(args.get("record"))
        cap_id = str(rec.get("capability_id") or "").strip()
        policy = _pkg()._allowlist_policy()
        actor_role = _pkg()._resolve_actor_role(group, actor_id)
        effective_policy_level = _pkg()._effective_policy_level(
            policy,
            capability_id=cap_id,
            kind=str(rec.get("kind") or ""),
            source_id=str(rec.get("source_id") or ""),
            actor_role=actor_role,
        )
        qualification = str(rec.get("qualification_status") or _QUAL_QUALIFIED).strip().lower()
        policy_visible = bool(_pkg()._policy_level_visible(effective_policy_level))
        supported_now = bool(_pkg()._record_enable_supported(rec, capability_id=cap_id))
        enable_block_reason = ""
        if not policy_visible:
            enable_block_reason = "policy_level_indexed"
        elif qualification == _QUAL_BLOCKED:
            enable_block_reason = "qualification_blocked"
        elif not supported_now:
            enable_block_reason = "capability_unavailable"
        enableable_now = not bool(enable_block_reason)
        probe_result, diagnostics = _probe_import_record(rec, capability_id=cap_id, enabled=probe)

        readiness_preview = _build_import_readiness_preview(
            rec=rec,
            capability_id=cap_id,
            policy=policy,
            policy_level=effective_policy_level,
            enable_block_reason=enable_block_reason,
            diagnostics=diagnostics,
            probe_result=probe_result,
        )

        if dry_run:
            dry_state = str(readiness_preview.get("preview_status") or "needs_inspect")
            _audit(
                "ready",
                state=dry_state,
                details={
                    "dry_run": True,
                    "probe_state": str(probe_result.get("state") or ""),
                    "effective_policy_level": effective_policy_level,
                    "enableable_now": bool(enableable_now),
                    "enable_block_reason": enable_block_reason,
                    "preview_status": dry_state,
                },
                capability_id=cap_id,
            )
            return DaemonResponse(
                ok=True,
                result={
                    "action_id": action_id,
                    "group_id": group_id,
                    "actor_id": actor_id,
                    "capability_id": cap_id,
                    "kind": str(rec.get("kind") or ""),
                    "dry_run": True,
                    "imported": False,
                    "record": rec,
                    "probe": probe_result,
                    "diagnostics": diagnostics,
                    "would_enable": bool(enable_after_import),
                    "effective_policy_level": effective_policy_level,
                    "enableable_now": bool(enableable_now),
                    "enable_block_reason": enable_block_reason,
                    "refresh_required": False,
                    "state": dry_state,
                    "readiness_preview": readiness_preview,
                },
            )

        with _CATALOG_LOCK:
            catalog_path, catalog_doc = _pkg()._load_catalog_doc()
            rows = catalog_doc.get("records") if isinstance(catalog_doc.get("records"), dict) else {}
            existing = rows.get(cap_id) if isinstance(rows.get(cap_id), dict) else None
            deduped = bool(existing == rec)
            rows[cap_id] = rec
            catalog_doc["records"] = rows

            source_id = str(rec.get("source_id") or "").strip()
            if source_id:
                sources = catalog_doc.get("sources") if isinstance(catalog_doc.get("sources"), dict) else {}
                state = (
                    sources.get(source_id)
                    if isinstance(sources.get(source_id), dict)
                    else _source_state_template("never")
                )
                state["sync_state"] = "imported"
                state["last_synced_at"] = utc_now_iso()
                state["staleness_seconds"] = 0
                state["error"] = ""
                sources[source_id] = state
                catalog_doc["sources"] = sources
            _refresh_source_record_counts(catalog_doc)
            _pkg()._save_catalog_doc(catalog_path, catalog_doc)

        enable_result: Dict[str, Any] = {}
        refresh_required = False
        state = str(readiness_preview.get("preview_status") or "needs_inspect")
        result_reason = ""
        if enable_after_import:
            enable_resp = handle_capability_enable(
                {
                    "group_id": group_id,
                    "by": by,
                    "actor_id": actor_id or by,
                    "capability_id": cap_id,
                    "scope": scope,
                    "enabled": True,
                    "ttl_seconds": ttl_seconds,
                    "reason": reason or "capability_import_enable",
                }
            )
            if enable_resp.ok and isinstance(enable_resp.result, dict):
                enable_result = dict(enable_resp.result)
                refresh_required = bool(enable_result.get("refresh_required"))
                state = str(enable_result.get("state") or "runnable").strip().lower() or "runnable"
                result_reason = str(enable_result.get("reason") or "").strip()
            else:
                state = "blocked"
                result_reason = str((enable_resp.error.message if enable_resp.error else "enable_failed") or "enable_failed")

        final_state = str(state or readiness_preview.get("preview_status") or "needs_inspect").strip().lower() or "needs_inspect"
        if str(probe_result.get("state") or "").strip().lower() == "failed" and final_state not in {"blocked", "needs_inspect"}:
            final_state = "needs_inspect"
        if final_state == "blocked" and not result_reason:
            result_reason = str(enable_block_reason or probe_result.get("reason") or "").strip()

        _audit(
            "ready" if final_state in {"enableable", "activation_pending", "runnable", "verified"} else "failed",
            state=final_state,
            error_code=result_reason if final_state in {"blocked", "needs_inspect"} else "",
            details={
                "deduped": bool(deduped),
                "enable_after_import": bool(enable_after_import),
                "probe_state": str(probe_result.get("state") or ""),
            },
            capability_id=cap_id,
        )
        out: Dict[str, Any] = {
            "action_id": action_id,
            "group_id": group_id,
            "actor_id": actor_id,
            "capability_id": cap_id,
            "kind": str(rec.get("kind") or ""),
            "dry_run": False,
            "imported": True,
            "deduped": bool(deduped),
            "record": rec,
            "probe": probe_result,
            "diagnostics": diagnostics,
            "effective_policy_level": effective_policy_level,
            "enableable_now": bool(enableable_now),
            "enable_block_reason": enable_block_reason,
            "refresh_required": bool(refresh_required),
            "enable_after_import": bool(enable_after_import),
            "state": final_state,
            "readiness_preview": readiness_preview,
        }
        if enable_result:
            out["enable_result"] = enable_result
        if result_reason:
            out["reason"] = result_reason
        return DaemonResponse(ok=True, result=out)
    except LookupError as e:
        _audit("failed", state="failed", error_code="group_not_found", details={"error": str(e)})
        return _error("group_not_found", str(e), details={"action_id": action_id})
    except ValueError as e:
        msg = str(e)
        code = "capability_import_invalid"
        if msg == "missing_group_id":
            code = "missing_group_id"
            msg = "missing group_id"
        _audit("failed", state="failed", error_code=code, details={"error": str(e)})
        return _error(code, msg, details={"action_id": action_id})
    except Exception as e:
        _audit("failed", state="failed", error_code="capability_import_failed", details={"error": str(e)})
        return _error("capability_import_failed", str(e), details={"action_id": action_id})


# ---------------------------------------------------------------------------
# handle_capability_uninstall
# ---------------------------------------------------------------------------

def handle_capability_uninstall(args: Dict[str, Any]) -> DaemonResponse:
    group_id = str(args.get("group_id") or "").strip()
    by = str(args.get("by") or args.get("actor_id") or "").strip()
    actor_id = str(args.get("actor_id") or by).strip()
    capability_id = str(args.get("capability_id") or "").strip()
    reason = str(args.get("reason") or "").strip()
    if len(reason) > 280:
        reason = reason[:280]
    action_id = f"cact_{uuid.uuid4().hex[:16]}"

    def _audit(outcome: str, *, state: str = "", error_code: str = "", details: Optional[Dict[str, Any]] = None) -> None:
        payload = dict(details) if isinstance(details, dict) else {}
        if state:
            payload["state"] = state
        if error_code:
            payload["error_code"] = error_code
        if reason:
            payload["reason"] = reason
        try:
            _append_audit_event(
                action_id=action_id,
                op="capability_uninstall",
                group_id=group_id,
                actor_id=actor_id,
                by=by,
                capability_id=capability_id,
                scope="group",
                enabled=False,
                outcome=outcome,
                details=payload,
            )
        except Exception:
            pass

    try:
        group = _ensure_group(group_id)
        if not capability_id:
            _audit("denied", state="denied", error_code="missing_capability_id")
            return _error("missing_capability_id", "missing capability_id", details={"action_id": action_id})
        if by != "user" and (not _is_foreman(group, by)):
            _audit("denied", state="denied", error_code="permission_denied")
            return _error(
                "permission_denied",
                "only user or foreman can uninstall capability",
                details={"action_id": action_id},
            )

        removed_bindings = 0
        has_remaining_binding = False
        with _STATE_LOCK:
            state_path, state_doc = _load_state_doc()
            removed_bindings = _remove_capability_bindings(
                state_doc,
                group_id=group_id,
                capability_id=capability_id,
            )
            has_remaining_binding = _has_any_binding_for_capability(state_doc, capability_id=capability_id)
            if removed_bindings > 0:
                _save_state_doc(state_path, state_doc)

        removed_installation = False
        removed_runtime_bindings = 0
        cleanup_skipped_reason = ""
        with _RUNTIME_LOCK:
            runtime_path, runtime_doc = _load_runtime_doc()
            removed_runtime_bindings = _remove_runtime_group_capability_bindings(
                runtime_doc,
                group_id=group_id,
                capability_id=capability_id,
            )
            runtime_changed = bool(removed_runtime_bindings > 0)
            if has_remaining_binding:
                cleanup_skipped_reason = "cleanup_skipped_capability_still_bound"
            else:
                removed_artifact_id = _remove_runtime_capability_artifact(
                    runtime_doc,
                    capability_id=capability_id,
                )
                if removed_artifact_id:
                    removed_installation = _remove_runtime_artifact_if_unreferenced(
                        runtime_doc,
                        artifact_id=removed_artifact_id,
                    )
                    runtime_changed = True
            if runtime_changed:
                _save_runtime_doc(runtime_path, runtime_doc)

        refresh_required = bool(removed_bindings > 0 or removed_installation or removed_runtime_bindings > 0)
        _audit(
            "ready",
            state="ready",
            details={
                "removed_bindings": int(removed_bindings),
                "removed_installation": bool(removed_installation),
                "removed_runtime_bindings": int(removed_runtime_bindings),
                "cleanup_skipped_reason": cleanup_skipped_reason,
            },
        )
        result: Dict[str, Any] = {
            "action_id": action_id,
            "group_id": group_id,
            "actor_id": actor_id,
            "capability_id": capability_id,
            "state": "ready",
            "removed_bindings": int(removed_bindings),
            "removed_installation": bool(removed_installation),
            "removed_runtime_bindings": int(removed_runtime_bindings),
            "refresh_required": refresh_required,
        }
        if cleanup_skipped_reason:
            result["cleanup_skipped_reason"] = cleanup_skipped_reason
        if refresh_required:
            result["wait"] = "relist_or_reconnect"
            result["refresh_mode"] = "relist_or_reconnect"
        return DaemonResponse(ok=True, result=result)
    except LookupError as e:
        _audit("failed", state="failed", error_code="group_not_found", details={"error": str(e)})
        return _error("group_not_found", str(e), details={"action_id": action_id})
    except ValueError as e:
        message = str(e)
        if message == "missing_group_id":
            _audit("failed", state="failed", error_code="missing_group_id")
            return _error("missing_group_id", "missing group_id", details={"action_id": action_id})
        _audit("failed", state="failed", error_code="capability_uninstall_invalid", details={"error": message})
        return _error("capability_uninstall_invalid", message, details={"action_id": action_id})
    except Exception as e:
        _audit("failed", state="failed", error_code="capability_uninstall_failed", details={"error": str(e)})
        return _error("capability_uninstall_failed", str(e), details={"action_id": action_id})


# ---------------------------------------------------------------------------
# handle_capability_tool_call
# ---------------------------------------------------------------------------

def handle_capability_tool_call(args: Dict[str, Any]) -> DaemonResponse:
    group_id = str(args.get("group_id") or "").strip()
    by = str(args.get("by") or args.get("actor_id") or "").strip()
    actor_id = str(args.get("actor_id") or by).strip()
    capability_id_hint = str(args.get("capability_id") or "").strip()
    tool_name = str(args.get("tool_name") or "").strip()
    arguments = args.get("arguments") if isinstance(args.get("arguments"), dict) else {}

    try:
        group = _ensure_group(group_id)
        if by and by != "user" and actor_id and actor_id != by:
            return _error("permission_denied", "actor can only call tools as self")
        if not actor_id:
            return _error("missing_actor_id", "missing actor_id")
        if not tool_name:
            return _error("missing_tool_name", "missing tool_name")
        if actor_id != "user":
            actors = group.doc.get("actors") if isinstance(group.doc.get("actors"), list) else []
            if actor_id not in {str(a.get("id") or "") for a in actors if isinstance(a, dict)}:
                return _error("actor_not_found", f"actor not found in group: {actor_id}")

        with _STATE_LOCK:
            state_path, state_doc = _load_state_doc()
            enabled_caps, mutated = _collect_enabled_capabilities(state_doc, group_id=group_id, actor_id=actor_id)
            blocked_caps, blocked_mutated = _collect_blocked_capabilities(state_doc, group_id=group_id)
            if mutated or blocked_mutated:
                _save_state_doc(state_path, state_doc)

        enabled_external = [cid for cid in enabled_caps if cid not in BUILTIN_CAPABILITY_PACKS]
        if capability_id_hint and capability_id_hint in BUILTIN_CAPABILITY_PACKS:
            return _error("capability_tool_not_found", f"capability is not external: {capability_id_hint}")
        if capability_id_hint and isinstance(blocked_caps.get(capability_id_hint), dict):
            block_entry = blocked_caps.get(capability_id_hint) if isinstance(blocked_caps.get(capability_id_hint), dict) else {}
            scope_token = str(block_entry.get("scope") or "group").strip().lower()
            reason_code = "blocked_by_global_policy" if scope_token == "global" else "blocked_by_group_policy"
            details = {"capability_id": capability_id_hint, "tool_name": tool_name, "blocked_scope": scope_token}
            reason_text = str(block_entry.get("reason") or "").strip()
            if reason_text:
                details["blocked_reason"] = reason_text
            return _error(reason_code, f"capability blocked: {capability_id_hint}", details=details)
        if capability_id_hint and capability_id_hint not in set(enabled_external):
            return _error(
                "capability_tool_not_found",
                f"capability not enabled for actor: {capability_id_hint}",
                details={"capability_id": capability_id_hint, "tool_name": tool_name},
            )
        candidate_caps = [
            cid
            for cid in ([capability_id_hint] if capability_id_hint else list(enabled_external))
            if not isinstance(blocked_caps.get(cid), dict)
        ]
        if not candidate_caps:
            blocked_ids = [cid for cid in enabled_external if isinstance(blocked_caps.get(cid), dict)]
            if blocked_ids:
                return _error(
                    "blocked_by_group_policy",
                    "all enabled external capabilities are blocked",
                    details={"tool_name": tool_name, "blocked_capabilities": blocked_ids},
                )

        target_capability_id = ""
        target_artifact_id = ""
        target_install: Dict[str, Any] = {}
        real_tool_name = ""
        resolved_tool_name = tool_name
        tool_aliases = set(_tool_name_aliases(tool_name))
        if not tool_aliases:
            tool_aliases = {tool_name}

        with _RUNTIME_LOCK:
            _, runtime_doc = _load_runtime_doc()
            artifacts = _runtime_artifacts(runtime_doc)
            capability_artifacts = _runtime_capability_artifacts(runtime_doc)
            actor_bindings = _runtime_actor_bindings(runtime_doc)
            per_group_bindings = (
                actor_bindings.get(group_id)
                if isinstance(actor_bindings.get(group_id), dict)
                else {}
            )
            per_actor_bindings = (
                per_group_bindings.get(actor_id)
                if isinstance(per_group_bindings.get(actor_id), dict)
                else {}
            )
            matches: List[Tuple[str, str, Dict[str, Any], str, str]] = []
            available_by_cap: Dict[str, set[str]] = {}
            direct_fallback: Optional[Tuple[str, str, Dict[str, Any]]] = None
            for capability_id in candidate_caps:
                binding = per_actor_bindings.get(capability_id) if isinstance(per_actor_bindings, dict) else None
                binding_state = str((binding or {}).get("state") or "").strip() if isinstance(binding, dict) else ""
                if not _binding_state_allows_external_tool(binding_state):
                    continue
                artifact_id = str((binding or {}).get("artifact_id") or "").strip() if isinstance(binding, dict) else ""
                if not artifact_id:
                    artifact_id = str(capability_artifacts.get(capability_id) or "").strip()
                install = artifacts.get(artifact_id) if isinstance(artifacts, dict) else None
                if not isinstance(install, dict):
                    continue
                if not _install_state_allows_external_tool(install.get("state")):
                    continue
                tools = install.get("tools") if isinstance(install.get("tools"), list) else []
                if not tools:
                    if capability_id_hint and capability_id == capability_id_hint:
                        direct_fallback = (capability_id, artifact_id, install)
                    continue
                for tool in tools:
                    if not isinstance(tool, dict):
                        continue
                    synthetic_name = str(tool.get("name") or "").strip()
                    real_name = str(tool.get("real_tool_name") or "").strip()
                    if not synthetic_name or not real_name:
                        continue
                    names = available_by_cap.setdefault(capability_id, set())
                    names.add(synthetic_name)
                    names.add(real_name)
                    if (
                        tool_name != synthetic_name
                        and tool_name != real_name
                        and synthetic_name not in tool_aliases
                        and real_name not in tool_aliases
                    ):
                        continue
                    matches.append((capability_id, artifact_id, install, real_name, synthetic_name))

            if not matches:
                if capability_id_hint and isinstance(direct_fallback, tuple):
                    target_capability_id, target_artifact_id, target_install = direct_fallback
                    real_tool_name = tool_name
                    resolved_tool_name = tool_name
                else:
                    details: Dict[str, Any] = {}
                    if capability_id_hint:
                        available = sorted(available_by_cap.get(capability_id_hint) or [])
                        if available:
                            details["available_tools"] = available[:64]
                        details["capability_id"] = capability_id_hint
                    return _error("capability_tool_not_found", f"tool not found or not enabled: {tool_name}", details=details)
            else:
                if len(matches) > 1:
                    candidates = [
                        {
                            "capability_id": cap_id,
                            "tool_name": synthetic,
                            "real_tool_name": real,
                        }
                        for cap_id, _, _, real, synthetic in matches
                    ]
                    return _error(
                        "capability_tool_ambiguous",
                        f"tool resolves to multiple enabled capabilities: {tool_name}",
                        details={"tool_name": tool_name, "candidates": candidates},
                    )
                target_capability_id, target_artifact_id, target_install, real_tool_name, resolved_tool_name = matches[0]

        try:
            result, resolved_real_tool_name = _pkg()._invoke_installed_external_tool_with_aliases(
                target_install,
                requested_tool_name=real_tool_name,
                arguments=arguments,
            )
        except Exception as e:
            with _RUNTIME_LOCK:
                # Update last error for observability; do not change enabled scope on transient failures.
                path, doc = _load_runtime_doc()
                artifacts2 = _runtime_artifacts(doc)
                install2 = artifacts2.get(target_artifact_id) if isinstance(artifacts2, dict) else None
                if isinstance(install2, dict):
                    install2["last_error"] = str(e)
                    install2["updated_at"] = utc_now_iso()
                    artifacts2[target_artifact_id] = install2
                    doc["artifacts"] = artifacts2
                    _set_runtime_actor_binding(
                        doc,
                        group_id=group_id,
                        actor_id=actor_id,
                        capability_id=target_capability_id,
                        artifact_id=target_artifact_id,
                        state="tool_call_failed",
                        last_error=str(e),
                    )
                    _save_runtime_doc(path, doc)
            return _error("capability_tool_call_failed", str(e))

        with _RUNTIME_LOCK:
            path, doc = _load_runtime_doc()
            artifacts2 = _runtime_artifacts(doc)
            install2 = artifacts2.get(target_artifact_id) if isinstance(artifacts2, dict) else None
            if isinstance(install2, dict):
                tools2 = install2.get("tools") if isinstance(install2.get("tools"), list) else []
                has_tool = any(
                    isinstance(item, dict)
                    and str(item.get("real_tool_name") or "").strip() == str(resolved_real_tool_name or "").strip()
                    for item in tools2
                )
                if (not has_tool) and str(resolved_real_tool_name or "").strip():
                    used_names = {
                        str(item.get("name") or "").strip()
                        for item in tools2
                        if isinstance(item, dict)
                    }
                    tools2.append(
                        {
                            "name": _build_synthetic_tool_name(
                                target_capability_id,
                                str(resolved_real_tool_name or ""),
                                used=used_names,
                            ),
                            "real_tool_name": str(resolved_real_tool_name or ""),
                            "description": f"{resolved_real_tool_name} tool",
                            "inputSchema": {"type": "object", "properties": {}, "required": []},
                        }
                    )
                install2["tools"] = tools2
                install2["last_error"] = ""
                if str(install2.get("state") or "").strip().lower() == "installed_degraded" and tools2:
                    install2["state"] = "installed"
                install2["updated_at"] = utc_now_iso()
                artifacts2[target_artifact_id] = install2
                doc["artifacts"] = artifacts2
            _set_runtime_actor_binding(
                doc,
                group_id=group_id,
                actor_id=actor_id,
                capability_id=target_capability_id,
                artifact_id=target_artifact_id,
                state="verified",
                last_error="",
            )
            _record_runtime_recent_success(
                doc,
                capability_id=target_capability_id,
                group_id=group_id,
                actor_id=actor_id,
                action="tool_call",
            )
            _save_runtime_doc(path, doc)

        return DaemonResponse(
            ok=True,
            result={
                "tool_name": tool_name,
                "resolved_tool_name": resolved_tool_name,
                "real_tool_name": resolved_real_tool_name,
                "capability_id": target_capability_id,
                "result": result,
            },
        )
    except LookupError as e:
        return _error("group_not_found", str(e))
    except Exception as e:
        return _error("capability_tool_call_failed", str(e))
