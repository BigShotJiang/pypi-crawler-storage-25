# CLAUDE.md

## Commands

```bash
.venv/bin/python -m ruff format --check .
.venv/bin/python -m ruff check .
.venv/bin/python -m pytest -q
.venv/bin/python -m build --sdist --wheel --outdir dist
.venv/bin/python -m twine check dist/*
```

## Rules That Prevent Mistakes

Psyduck is SDK-only. Do not add a CLI, console entry point, or command-oriented docs unless the product direction changes.

The base package intentionally ships with PyMuPDF only. Do not add built-in Docling, Camelot, pdfplumber, OCR, or Tesseract adapters without a new design review. Heavier integrations belong behind custom extractor registration.

Public output must stay structured. Use the schema types in `src/psyduck/schema.py`; do not return ad hoc dictionaries from SDK internals.

Page numbers in public output are original PDF page numbers. For page-scoped processing, do not renumber selected pages to a dense 1..N range.

Warnings are part of the SDK contract. If an extractor is missing, unavailable, or fails, preserve a machine-readable warning and let quality decide whether the result needs review.

## What Not To Do

- No CLI implementation.
- No hidden optional adapter behavior in the default planner.
- No silent degradation for forced OCR/table requests.
- No generated caches or `dist/` in commits.
- No PyPI upload without a fresh format, lint, test, build, and `twine check`.

## Release Checklist

Update these together when API behavior or version changes:

- `pyproject.toml`
- `CHANGELOG.md`
- `README.md`
- `docs/API.md`
- `docs/EXTENDING.md`
- `llms.txt`
- `skills/psyduck/SKILL.md`

Tag releases as `vX.Y.Z`.
