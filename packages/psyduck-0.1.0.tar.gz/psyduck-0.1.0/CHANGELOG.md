# Changelog

All notable changes to Psyduck are documented here.

## 0.1.0 - 2026-05-12

Initial alpha release.

### Added

- SDK-only PDF processing through `Psyduck().process(...)`.
- Default PyMuPDF-backed text extraction.
- Page profiling with page count, text-layer detection, scan ratio, likely table pages, selected pages, and processed page count.
- Structured schemas for documents, blocks, tables, quality reports, warnings, and results.
- Exported run artifacts: `document.md`, `document.json`, `profile.json`, `quality.json`, and `run.json`.
- `load_result(output_dir)` for reloading previous SDK runs.
- `recover(output_dir)` for refreshing quality on an existing run.
- Page preview rendering through `mode="high_quality"`.
- Embedded image extraction through `goal="archive"`.
- Custom extractor registry support with `process(..., extractors=[...])`.

### Changed

- The package is intentionally SDK-only and does not publish a command-line interface.
- First-party optional adapters for OCR and table extraction are not bundled in this release.
- `ocr="force"` and `tables="force"` are capability signals. They produce review warnings unless caller-provided extractors satisfy the requested work.

### Known Limitations

- OCR is not implemented by default.
- Table extraction is not implemented by default.
- Custom extractor capabilities are inferred from returned document content and warnings; there is no formal capability registry yet.
