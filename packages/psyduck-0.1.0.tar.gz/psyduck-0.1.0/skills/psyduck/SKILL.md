---
name: psyduck
description: Use when building with the Psyduck Python SDK, integrating PDF extraction into agents, handling PsyduckResult quality reports, writing custom extractors, or debugging SDK-only PDF processing code that imports psyduck.
---

# Psyduck SDK

Psyduck is a Python SDK for agent-safe PDF extraction. It converts PDFs into structured text, Markdown, JSON, page previews, assets, profiles, and quality reports.

## Install

```bash
pip install psyduck
```

For local development:

```bash
python -m venv .venv
.venv/bin/python -m pip install -e ".[dev]"
```

## Minimal Use

```python
from psyduck import Psyduck

result = Psyduck().process(
    "document.pdf",
    goal="rag",
    output_dir="output",
    return_content=True,
)

if result.status == "needs_review":
    print(result.quality.warnings)
else:
    print(result.outputs["markdown"])
```

## API Reference

| Need | Use |
|------|-----|
| Process a PDF | `Psyduck().process(path, ...)` |
| Reload a previous run | `Psyduck().load_result(run_dir)` |
| Re-evaluate stored output | `Psyduck().recover(run_dir)` |
| Add an extractor | `Psyduck(extractor_registry={...})` |
| Inspect warnings | `result.quality.warnings` |
| Find artifacts | `result.outputs` |

Important `process()` options:

- `goal`: `auto`, `rag`, `summary`, `tables`, `archive`
- `mode`: `fast`, `balanced`, `high_quality`
- `pages`: original PDF page numbers to process
- `ocr`: `auto`, `force`, `off`
- `tables`: `auto`, `force`, `off`
- `extractors`: explicit extractor names from the registry
- `return_content`: include or omit the in-memory document

## Quality Handling

Agents should treat `status="needs_review"` as a routing signal, not as an exception.

Common warning codes:

- `EMPTY_PAGE`: processed page has no extracted text
- `OCR_NEEDED`: PDF looks scan-heavy
- `OCR_ADAPTER_NEEDED`: OCR was requested but no OCR adapter is registered
- `NO_TABLES_EXTRACTED`: table goal produced no tables
- `TABLE_ADAPTER_NEEDED`: forced table extraction produced no tables
- `UNKNOWN_EXTRACTOR`: requested extractor is not registered
- `EXTRACTOR_UNAVAILABLE`: extractor dependency or runtime requirement is unavailable
- `EXTRACTOR_FAILED`: extractor raised an unexpected exception

## Custom Extractors

The base SDK ships with PyMuPDF only. Register heavier tools as custom extractors.

```python
from psyduck import Psyduck
from psyduck.extractors.base import ExtractorOutput
from psyduck.schema import PsyduckBlock


class MyExtractor:
    name = "my-extractor"

    def extract(self, file_path, pages=None):
        return ExtractorOutput(
            source=self.name,
            blocks=[
                PsyduckBlock(
                    id="my_b1",
                    page=1,
                    type="paragraph",
                    text="Extracted content",
                    source=self.name,
                    confidence=0.9,
                )
            ]
        )


result = Psyduck(extractor_registry={"my-extractor": MyExtractor}).process(
    "document.pdf",
    extractors=["my-extractor"],
)
```

Extractor output should use `ExtractorOutput(source=..., blocks=..., tables=..., warnings=...)`.

## Development Guardrails

- Psyduck is SDK-only. Do not add CLI behavior.
- Keep default dependencies small: `pydantic` and `pymupdf`.
- Do not add built-in Docling, Camelot, pdfplumber, or OCR adapters without a new design review.
- Keep original PDF page numbers in public output.
- Preserve machine-readable warnings for missing, unavailable, or failed extractors.

## Local Checks

```bash
.venv/bin/python -m ruff format --check .
.venv/bin/python -m ruff check .
.venv/bin/python -m pytest -q
.venv/bin/python -m build --sdist --wheel --outdir dist
.venv/bin/python -m twine check dist/*
```
