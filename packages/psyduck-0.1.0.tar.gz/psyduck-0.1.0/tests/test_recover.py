from pathlib import Path

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_text_pdf


def test_recover_reloads_and_refreshes_existing_result_without_adapter_reruns(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    result = Psyduck().process(pdf_path, output_dir=tmp_path / "out", return_content=True)

    recovered = Psyduck().recover(result.output_dir)

    assert recovered.run_id == result.run_id
    assert recovered.document.blocks
    assert recovered.quality.score == result.quality.score
