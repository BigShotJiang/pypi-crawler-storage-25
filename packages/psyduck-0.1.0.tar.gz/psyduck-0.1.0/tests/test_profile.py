from pathlib import Path

from psyduck.profile import profile_pdf
from tests.fixtures.make_pdfs import make_text_pdf


def test_profile_pdf_detects_text_layer_and_page_count(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)

    profile = profile_pdf(pdf_path)

    assert profile.page_count == 2
    assert profile.has_text_layer is True
    assert profile.scan_ratio == 0
    assert profile.avg_text_chars_per_page > 0


def test_profile_pdf_marks_likely_table_pages(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "table.pdf", pages=1)

    profile = profile_pdf(pdf_path)

    assert profile.likely_table_pages == [1]
