from psyduck.quality import evaluate_quality
from psyduck.schema import PsyduckDocument, PsyduckProfile, PsyduckTable, PsyduckWarning


def test_quality_warns_when_page_has_no_blocks():
    document = PsyduckDocument(document_id="doc", source_path="sample.pdf", page_count=2)
    profile = PsyduckProfile(page_count=2, has_text_layer=True)

    report = evaluate_quality(document, profile)

    assert report.needs_review is True
    assert any(w.code == "EMPTY_PAGE" for w in report.warnings)


def test_quality_warns_on_uneven_table_rows():
    document = PsyduckDocument(
        document_id="doc",
        source_path="sample.pdf",
        page_count=1,
        tables=[
            PsyduckTable(
                id="t1",
                page=1,
                headers=[["A", "B"]],
                rows=[["1"], ["2", "3"]],
                source="test",
                confidence=0.6,
            )
        ],
    )
    profile = PsyduckProfile(page_count=1, has_text_layer=True)

    report = evaluate_quality(document, profile)

    assert any(w.code == "MALFORMED_TABLE" for w in report.warnings)
    assert any(action["type"] == "needs_table_adapter" for action in report.suggested_actions)


def test_quality_preserves_extractor_warnings():
    document = PsyduckDocument(document_id="doc", source_path="sample.pdf", page_count=1)
    profile = PsyduckProfile(page_count=1, has_text_layer=True)

    report = evaluate_quality(
        document,
        profile,
        extractor_warnings=[
            PsyduckWarning(
                code="EXTRACTOR_UNAVAILABLE",
                severity="warning",
                message="Custom extractor is unavailable.",
            )
        ],
    )

    assert any(w.code == "EXTRACTOR_UNAVAILABLE" for w in report.warnings)
