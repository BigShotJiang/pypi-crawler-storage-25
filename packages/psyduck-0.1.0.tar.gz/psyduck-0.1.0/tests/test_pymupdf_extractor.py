from pathlib import Path

from psyduck.extractors.base import ExtractorOutput
from psyduck.extractors.pymupdf import PyMuPDFExtractor
from tests.fixtures.make_pdfs import make_text_pdf


def test_extractor_output_defaults_to_empty_lists():
    output = ExtractorOutput(source="fake")

    assert output.blocks == []
    assert output.tables == []
    assert output.warnings == []


def test_pymupdf_extractor_returns_paragraph_blocks(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    output = PyMuPDFExtractor().extract(pdf_path)

    assert output.source == "pymupdf"
    assert output.blocks
    assert output.blocks[0].page == 1
    assert "Sample PDF page 1" in (output.blocks[0].text or "")
