from psyduck.config import PsyduckConfig
from psyduck.planner import plan_extraction
from psyduck.schema import PsyduckProfile


def test_all_goals_use_pymupdf_only_by_default():
    profile = PsyduckProfile(page_count=1, has_text_layer=True, likely_table_pages=[1])

    for goal in ["auto", "summary", "qa", "rag", "tables", "archive"]:
        plan = plan_extraction(profile, PsyduckConfig(goal=goal))
        assert plan.extractors == ["pymupdf"]
        assert "csv" not in plan.exports


def test_high_quality_plan_records_page_preview_export():
    profile = PsyduckProfile(page_count=1, has_text_layer=True)

    plan = plan_extraction(profile, PsyduckConfig(mode="high_quality"))

    assert plan.extractors == ["pymupdf"]
    assert "page_previews" in plan.exports
