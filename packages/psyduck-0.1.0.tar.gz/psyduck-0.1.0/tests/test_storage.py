from pathlib import Path

from psyduck.storage import create_run_dir, write_json


def test_create_run_dir_uses_stem_and_run_prefix(tmp_path: Path):
    run = create_run_dir(tmp_path / "report.pdf", tmp_path)

    assert run.path.exists()
    assert run.path.name.startswith("report-")
    assert run.tables_dir.exists()
    assert run.assets_dir.exists()


def test_create_run_dir_avoids_same_second_collisions(tmp_path: Path):
    first = create_run_dir(tmp_path / "report.pdf", tmp_path)
    second = create_run_dir(tmp_path / "report.pdf", tmp_path)

    assert first.run_id != second.run_id
    assert first.path != second.path


def test_write_json_serializes_mapping(tmp_path: Path):
    path = tmp_path / "profile.json"

    write_json(path, {"page_count": 3})

    assert '"page_count": 3' in path.read_text()
