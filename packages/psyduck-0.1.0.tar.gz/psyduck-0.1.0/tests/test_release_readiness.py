from pathlib import Path

import tomllib


def test_release_documents_exist():
    for path in [
        "LICENSE",
        "CHANGELOG.md",
        "AGENTS.md",
        "CLAUDE.md",
        "llms.txt",
        "docs/API.md",
        "docs/EXTENDING.md",
        "skills/psyduck/SKILL.md",
        ".gitignore",
    ]:
        assert Path(path).exists(), f"{path} is required before release"


def test_developer_skill_has_discoverable_frontmatter():
    skill = Path("skills/psyduck/SKILL.md").read_text(encoding="utf-8")

    assert skill.startswith("---\n")
    assert "name: psyduck" in skill
    assert "description: Use when" in skill
    assert "Psyduck" in skill


def test_developer_docs_use_current_extractor_api():
    for path in ["llms.txt", "skills/psyduck/SKILL.md"]:
        content = Path(path).read_text(encoding="utf-8")

        assert "Psyduck(registry=" not in content
        assert "Psyduck(extractor_registry=" in content
        assert 'kind="text"' not in content
        assert "ExtractorOutput(\n            source=self.name," in content
        assert 'type="paragraph"' in content
        assert 'id="my_b1"' in content
        assert "confidence=0.9" in content


def test_pyproject_has_release_metadata():
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    project = pyproject["project"]

    assert project["license"] == "MIT"
    assert project["authors"]
    assert "pdf" in project["keywords"]
    assert "Programming Language :: Python :: 3" in project["classifiers"]
    assert project["urls"]["Repository"]
