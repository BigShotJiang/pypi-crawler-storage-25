from pathlib import Path

from psyduck.export import export_document
from psyduck.schema import PsyduckBlock, PsyduckDocument, PsyduckTable


def test_export_document_writes_markdown_json_and_csv(tmp_path: Path):
    document = PsyduckDocument(
        document_id="doc",
        source_path="sample.pdf",
        page_count=1,
        blocks=[
            PsyduckBlock(
                id="b1",
                type="paragraph",
                page=1,
                text="Hello world",
                source="pymupdf",
                confidence=1,
            )
        ],
        tables=[
            PsyduckTable(
                id="t1",
                page=1,
                headers=[["A", "B"]],
                rows=[["1", "2"]],
                source="test",
                confidence=1,
            )
        ],
    )

    outputs = export_document(document, tmp_path)

    assert Path(outputs["markdown"]).read_text().strip() == "Hello world"
    json_payload = Path(outputs["json"]).read_text()
    assert Path(outputs["tables_dir"], "t1.csv").exists()
    assert "t1.csv" in json_payload
