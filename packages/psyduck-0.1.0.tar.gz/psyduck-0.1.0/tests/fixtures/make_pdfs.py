from pathlib import Path

from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from PIL import Image


def make_text_pdf(path: Path, pages: int = 2) -> Path:
    c = canvas.Canvas(str(path), pagesize=letter)
    for page in range(1, pages + 1):
        c.drawString(72, 720, f"Sample PDF page {page}")
        c.drawString(72, 690, "Header A Header B Header C")
        c.drawString(72, 660, "1 2 3")
        c.showPage()
    c.save()
    return path


def make_blank_pdf(path: Path, pages: int = 1) -> Path:
    c = canvas.Canvas(str(path), pagesize=letter)
    for _ in range(pages):
        c.showPage()
    c.save()
    return path


def make_pdf_with_image(path: Path) -> Path:
    image_path = path.with_suffix(".png")
    image = Image.new("RGB", (64, 64), color=(40, 120, 200))
    image.save(image_path)

    c = canvas.Canvas(str(path), pagesize=letter)
    c.drawString(72, 720, "PDF with embedded image")
    c.drawImage(ImageReader(str(image_path)), 72, 620, width=64, height=64)
    c.showPage()
    c.save()
    return path


def make_ruled_table_pdf(path: Path) -> Path:
    c = canvas.Canvas(str(path), pagesize=letter)
    x0, y0 = 72, 700
    col_widths = [120, 80, 80]
    row_height = 28
    rows = [
        ["Metric", "2024", "2023"],
        ["Revenue", "100", "90"],
        ["Profit", "20", "15"],
    ]

    table_width = sum(col_widths)
    table_height = row_height * len(rows)
    c.rect(x0, y0 - table_height, table_width, table_height)

    x = x0
    for width in col_widths[:-1]:
        x += width
        c.line(x, y0, x, y0 - table_height)

    for row_index in range(1, len(rows)):
        y = y0 - row_height * row_index
        c.line(x0, y, x0 + table_width, y)

    for row_index, row in enumerate(rows):
        y = y0 - row_height * row_index - 18
        x = x0 + 8
        for col_index, cell in enumerate(row):
            c.drawString(x, y, cell)
            x += col_widths[col_index]

    c.showPage()
    c.save()
    return path
