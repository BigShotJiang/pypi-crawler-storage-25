from pathlib import Path

from psyduck.schema import (
    PsyduckBlock,
    PsyduckDocument,
    PsyduckQualityReport,
    PsyduckResult,
    PsyduckTable,
    PsyduckWarning,
)


def test_public_imports():
    from psyduck import Psyduck, PsyduckConfig

    assert Psyduck is not None
    assert PsyduckConfig is not None


def test_document_schema_tracks_pages_blocks_and_tables():
    block = PsyduckBlock(
        id="b_001",
        type="paragraph",
        page=1,
        bbox=[10, 20, 100, 140],
        text="Hello PDF",
        source="pymupdf",
        confidence=1.0,
    )
    table = PsyduckTable(
        id="t_001",
        page=1,
        bbox=None,
        title="Example",
        headers=[["A", "B"]],
        rows=[["1", "2"]],
        source="custom_table_extractor",
        confidence=0.8,
    )

    document = PsyduckDocument(
        document_id="doc_001",
        source_path="sample.pdf",
        page_count=1,
        blocks=[block],
        tables=[table],
    )

    assert document.blocks[0].text == "Hello PDF"
    assert document.tables[0].rows == [["1", "2"]]


def test_quality_report_suggests_review_when_warning_is_error():
    report = PsyduckQualityReport(
        score=0.55,
        warnings=[
            PsyduckWarning(
                code="LOW_TEXT_DENSITY",
                severity="error",
                page=2,
                message="Page may need OCR",
                suggested_action={"type": "needs_ocr_adapter", "pages": [2]},
            )
        ],
    )

    assert report.needs_review is True


def test_result_goal_usability_uses_quality_threshold(tmp_path: Path):
    result = PsyduckResult(
        run_id="run_001",
        status="completed",
        output_dir=str(tmp_path),
        document=None,
        profile=None,
        quality=PsyduckQualityReport(score=0.8, warnings=[]),
        outputs={"markdown": str(tmp_path / "document.md")},
    )

    assert result.is_usable_for("summary") is True
