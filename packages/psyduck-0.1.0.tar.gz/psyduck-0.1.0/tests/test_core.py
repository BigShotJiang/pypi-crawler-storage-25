from pathlib import Path

from psyduck import Psyduck
from psyduck.extractors.base import ExtractorOutput
from psyduck.normalize import normalize_outputs
from psyduck.schema import PsyduckBlock, PsyduckProfile
from tests.fixtures.make_pdfs import make_text_pdf


def test_default_registry_is_pymupdf_only():
    duck = Psyduck()

    assert set(duck.extractor_registry) == {"pymupdf"}


def test_normalize_outputs_merges_blocks_into_document():
    output = ExtractorOutput(
        source="pymupdf",
        blocks=[
            PsyduckBlock(
                id="b1",
                type="paragraph",
                page=1,
                text="Hello",
                source="pymupdf",
                confidence=1,
            )
        ],
    )
    profile = PsyduckProfile(page_count=1, has_text_layer=True)

    document = normalize_outputs("sample.pdf", profile, [output])

    assert document.page_count == 1
    assert document.blocks[0].text == "Hello"


def test_process_profiles_extracts_exports_and_scores_pdf(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    result = Psyduck().process(
        pdf_path,
        goal="summary",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert result.status == "completed"
    assert result.profile.page_count == 1
    assert result.document.blocks
    assert Path(result.outputs["markdown"]).exists()
    assert Path(result.outputs["json"]).exists()
    assert result.quality.score >= 0.7


def test_process_can_omit_document_content_from_result(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    result = Psyduck().process(pdf_path, goal="summary", output_dir=tmp_path / "out")

    assert result.document is None
    assert Path(result.outputs["json"]).exists()


def test_tables_goal_without_custom_table_extractor_needs_review(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    result = Psyduck().process(
        pdf_path,
        goal="tables",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert result.status == "needs_review"
    assert result.is_usable_for("tables") is False
    assert any(w.code == "NO_TABLES_EXTRACTED" for w in result.quality.warnings)


def test_run_extractors_turns_unexpected_failures_into_warnings(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    outputs = Psyduck(
        extractor_registry={"custom": lambda: CrashingExtractor("custom")}
    )._run_extractors(pdf_path, ["custom"])

    assert outputs[0].warnings[0].code == "EXTRACTOR_FAILED"
    assert outputs[0].warnings[0].block_id == "custom"


def test_custom_registry_can_add_named_extractors(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    calls = []

    class CustomExtractor:
        def extract(self, file_path, pages=None):
            calls.append(("custom", pages))
            return ExtractorOutput(source="custom")

    result = Psyduck(
        extractor_registry={
            "pymupdf": lambda: FakeTextExtractor(),
            "custom": lambda: CustomExtractor(),
        }
    )._run_extractors(pdf_path, ["pymupdf", "custom"], pages=[1])

    assert [output.source for output in result] == ["pymupdf", "custom"]
    assert calls == [("custom", [1])]


def test_process_can_run_requested_custom_extractors(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    calls = []

    class CustomExtractor:
        def extract(self, file_path, pages=None):
            calls.append(("custom", pages))
            return ExtractorOutput(
                source="custom",
                blocks=[
                    PsyduckBlock(
                        id="custom_b1",
                        type="paragraph",
                        page=1,
                        text="custom text",
                        source="custom",
                        confidence=1,
                    )
                ],
            )

    result = Psyduck(
        extractor_registry={
            "pymupdf": lambda: FakeTextExtractor(),
            "custom": lambda: CustomExtractor(),
        }
    ).process(
        pdf_path,
        extractors=["pymupdf", "custom"],
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert calls == [("custom", None)]
    assert any(block.source == "custom" for block in result.document.blocks)


def test_tables_force_reports_missing_table_adapter(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    result = Psyduck().process(
        pdf_path,
        goal="rag",
        tables="force",
        output_dir=tmp_path / "out",
    )

    assert result.status == "needs_review"
    assert any(w.code == "TABLE_ADAPTER_NEEDED" for w in result.quality.warnings)


def test_ocr_force_reports_missing_ocr_adapter(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    result = Psyduck().process(
        pdf_path,
        goal="rag",
        ocr="force",
        output_dir=tmp_path / "out",
    )

    assert result.status == "needs_review"
    assert any(w.code == "OCR_ADAPTER_NEEDED" for w in result.quality.warnings)


def test_page_limited_process_does_not_score_unrequested_pages(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)

    result = Psyduck(extractor_registry={"pymupdf": lambda: FakeTextExtractor(page=1)}).process(
        pdf_path,
        goal="tables",
        pages=[1],
        tables="off",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert not any(w.code == "EMPTY_PAGE" and w.page == 2 for w in result.quality.warnings)


class FakeTextExtractor:
    def __init__(self, page=1):
        self.page = page

    def extract(self, file_path, pages=None):
        return ExtractorOutput(
            source="pymupdf",
            blocks=[
                PsyduckBlock(
                    id=f"p{self.page}_b1",
                    type="paragraph",
                    page=self.page,
                    text="text",
                    source="pymupdf",
                    confidence=1,
                )
            ],
        )


class CrashingExtractor:
    def __init__(self, source):
        self.source = source

    def extract(self, file_path, pages=None):
        raise ValueError(f"{self.source} backend crashed")
