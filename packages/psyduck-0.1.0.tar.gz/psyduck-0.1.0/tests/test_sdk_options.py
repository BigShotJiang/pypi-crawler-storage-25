from pathlib import Path

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_text_pdf


def test_pages_option_limits_quality_and_document_blocks_without_redefining_page_count(
    tmp_path: Path,
):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=3)

    result = Psyduck().process(
        pdf_path,
        pages=[2],
        tables="off",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert result.profile.page_count == 3
    assert result.profile.selected_pages == [2]
    assert result.profile.processed_page_count == 1
    assert {block.page for block in result.document.blocks} == {2}
    assert not any(w.code == "EMPTY_PAGE" and w.page in {1, 3} for w in result.quality.warnings)


def test_pages_option_rejects_invalid_page_numbers(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    try:
        Psyduck().process(pdf_path, pages=[0], output_dir=tmp_path / "out")
    except ValueError as exc:
        assert "pages must be 1-based" in str(exc)
    else:
        raise AssertionError("expected ValueError")


def test_pages_option_does_not_change_default_extractor_set(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)
    result = Psyduck().process(
        pdf_path,
        pages=[1],
        tables="off",
        output_dir=tmp_path / "out",
    )

    assert result.profile.selected_pages == [1]
    assert result.quality.score >= 0
