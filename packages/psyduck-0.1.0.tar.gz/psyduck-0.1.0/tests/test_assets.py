from pathlib import Path

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_pdf_with_image, make_text_pdf


def test_high_quality_mode_renders_page_previews(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)

    result = Psyduck().process(
        pdf_path,
        mode="high_quality",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    pages_dir = Path(result.outputs["pages_dir"])
    assert (pages_dir / "page_001.png").exists()
    assert (pages_dir / "page_002.png").exists()
    assert any(asset["type"] == "page_preview" for asset in result.document.assets)


def test_archive_goal_extracts_image_assets(tmp_path: Path):
    pdf_path = make_pdf_with_image(tmp_path / "image.pdf")

    result = Psyduck().process(
        pdf_path,
        goal="archive",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert any(asset["type"] == "image" for asset in result.document.assets)
