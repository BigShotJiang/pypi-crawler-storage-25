from pathlib import Path

from psyduck import Psyduck
from psyduck.storage import read_json
from tests.fixtures.make_pdfs import make_text_pdf


def test_load_result_restores_profile_quality_document_and_outputs(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    created = Psyduck().process(
        pdf_path,
        goal="summary",
        output_dir=tmp_path / "out",
        return_content=False,
    )

    loaded = Psyduck().load_result(created.output_dir)

    assert loaded.run_id == created.run_id
    assert loaded.profile.page_count == 1
    assert loaded.quality.score == created.quality.score
    assert loaded.document is not None
    assert loaded.document.blocks
    assert loaded.outputs["markdown"].endswith("document.md")


def test_load_result_can_omit_document_content(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    created = Psyduck().process(pdf_path, output_dir=tmp_path / "out")

    loaded = Psyduck().load_result(created.output_dir, return_content=False)

    assert loaded.document is None
    assert loaded.outputs["json"].endswith("document.json")


def test_run_metadata_records_source_goal_mode_and_pages(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)

    result = Psyduck().process(
        pdf_path,
        goal="qa",
        mode="high_quality",
        pages=[1],
        output_dir=tmp_path / "out",
    )

    run = read_json(Path(result.output_dir) / "run.json")

    assert run["source_path"] == str(pdf_path)
    assert run["config"]["goal"] == "qa"
    assert run["config"]["mode"] == "high_quality"
    assert run["pages"] == [1]
