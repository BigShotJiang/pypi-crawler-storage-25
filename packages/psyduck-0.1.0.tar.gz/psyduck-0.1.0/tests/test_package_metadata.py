from pathlib import Path

import tomllib


def test_package_has_no_console_scripts_or_cli_dependencies():
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))

    project = pyproject["project"]
    assert "scripts" not in project
    assert "typer>=0.12" not in project["dependencies"]
    assert "rich>=13.7" not in project["dependencies"]


def test_package_has_no_builtin_optional_adapter_extras():
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))

    optional = pyproject["project"].get("optional-dependencies", {})
    removed_document_adapter = "doc" + "ling"
    removed_ocr_adapter = "o" + "cr"
    assert removed_document_adapter not in optional
    assert "tables" not in optional
    assert removed_ocr_adapter not in optional
    assert "all" not in optional


def test_config_has_no_dead_render_page_previews_field():
    from psyduck import PsyduckConfig

    assert "render_page_previews" not in PsyduckConfig.model_fields
