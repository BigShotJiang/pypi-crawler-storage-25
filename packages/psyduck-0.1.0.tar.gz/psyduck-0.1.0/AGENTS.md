# AGENTS.md

Psyduck is a Python SDK for agent-safe PDF extraction. It is not a CLI project.

## Where To Find Things

| What | Where |
|------|-------|
| Public package exports | `src/psyduck/__init__.py` |
| Main SDK entry point | `src/psyduck/core.py` |
| Runtime configuration | `src/psyduck/config.py` |
| Pydantic schemas | `src/psyduck/schema.py` |
| PDF profiling | `src/psyduck/profile.py` |
| Planning extractor/export work | `src/psyduck/planner.py` |
| Extraction base protocol | `src/psyduck/extractors/base.py` |
| Built-in extractor | `src/psyduck/extractors/pymupdf.py` |
| Output normalization | `src/psyduck/normalize.py` |
| Artifact export | `src/psyduck/export.py` |
| Run storage/loading | `src/psyduck/storage.py` |
| Quality evaluation | `src/psyduck/quality.py` |
| API docs | `docs/API.md` |
| Extension docs | `docs/EXTENDING.md` |
| LLM quick reference | `llms.txt` |
| Developer skill | `skills/psyduck/SKILL.md` |

## Project Boundaries

- Keep Psyduck SDK-only. Do not add CLI commands, console scripts, or shell-first flows.
- Keep the default install narrow: `pydantic` and `pymupdf`.
- Do not add built-in Docling, Camelot, pdfplumber, Tesseract, or OCR adapters without a new design review.
- Integrations with heavier PDF tools should use custom extractor registration.
- Keep result data structured. Prefer `PsyduckBlock`, `PsyduckTable`, `PsyduckWarning`, and `PsyduckQualityReport` over ad hoc dictionaries.
- Keep original PDF page numbering in public output.

## Agent Behavior

When changing extraction behavior:

1. Add or update tests first.
2. Verify page-scoped behavior with `pages=[...]`.
3. Verify `return_content=False` if returned content shape changes.
4. Verify `needs_review` behavior when extractors are unavailable or fail.
5. Do not silence extractor warnings unless a test proves they are redundant.

When changing docs or release metadata:

1. Keep `README.md`, `docs/API.md`, `docs/EXTENDING.md`, `llms.txt`, and `skills/psyduck/SKILL.md` consistent.
2. Update `CHANGELOG.md` for release-visible behavior.
3. Check `pyproject.toml` URLs and classifiers.

## Commands

```bash
.venv/bin/python -m ruff format --check .
.venv/bin/python -m ruff check .
.venv/bin/python -m pytest -q
.venv/bin/python -m build --sdist --wheel --outdir dist
.venv/bin/python -m twine check dist/*
```

## Release

Release artifacts are built from `pyproject.toml` using Hatchling.

Before publishing:

- run format, lint, tests, build, and `twine check`
- confirm `dist/psyduck-<version>.tar.gz`
- confirm `dist/psyduck-<version>-py3-none-any.whl`
- tag with `v<version>`
- push only to `origin`

## Do Not Do

- Do not use `git add .` or `git add -A`; stage explicit paths.
- Do not commit generated caches or `dist/`.
- Do not hardcode credentials or PyPI tokens.
- Do not use destructive git commands unless explicitly instructed.
- Do not publish to PyPI from an unverified build.
