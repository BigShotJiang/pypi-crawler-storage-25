from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from psyduck.config import AutoOption, PsyduckConfig, PsyduckGoal, PsyduckMode
from psyduck.export import export_document
from psyduck.extractors.base import ExtractorOutput
from psyduck.extractors.pymupdf import PyMuPDFExtractor, extract_images, render_page_previews
from psyduck.normalize import normalize_outputs
from psyduck.planner import plan_extraction
from psyduck.profile import profile_pdf
from psyduck.quality import evaluate_quality
from psyduck.schema import (
    PsyduckDocument,
    PsyduckProfile,
    PsyduckQualityReport,
    PsyduckResult,
    PsyduckWarning,
)
from psyduck.storage import create_run_dir, discover_outputs, read_json, write_json


class Psyduck:
    def __init__(
        self,
        extractor_registry: dict[str, Callable[[], object]] | None = None,
    ) -> None:
        self.extractor_registry = extractor_registry or {
            "pymupdf": PyMuPDFExtractor,
        }

    def process(
        self,
        file_path: str | Path,
        *,
        goal: PsyduckGoal = "auto",
        mode: PsyduckMode = "balanced",
        ocr: AutoOption = "auto",
        tables: AutoOption = "auto",
        pages: list[int] | None = None,
        extractors: list[str] | None = None,
        output_dir: str | Path | None = None,
        return_content: bool = False,
    ) -> PsyduckResult:
        config = PsyduckConfig(
            goal=goal,
            mode=mode,
            ocr=ocr,
            tables=tables,
            return_content=return_content,
        )
        run = create_run_dir(file_path, output_dir)
        profile = profile_pdf(file_path, pages=pages)
        plan = plan_extraction(profile, config)
        extractor_names = extractors or plan.extractors
        extractor_outputs = self._run_extractors(file_path, extractor_names, pages=pages)
        document = normalize_outputs(file_path, profile, extractor_outputs)
        if mode == "high_quality":
            document.assets.extend(render_page_previews(file_path, run.pages_dir, pages=pages))
        if goal == "archive":
            document.assets.extend(extract_images(file_path, run.assets_dir, pages=pages))
        outputs = export_document(document, run.path)
        extractor_warnings = [
            warning for output in extractor_outputs for warning in output.warnings
        ]
        quality = evaluate_quality(
            document,
            profile,
            extractor_warnings=extractor_warnings,
            goal=goal,
            ocr=ocr,
            tables=tables,
            evaluated_pages=pages,
        )
        write_json(run.path / "profile.json", profile.model_dump())
        write_json(run.path / "quality.json", quality.model_dump())
        write_json(
            run.path / "run.json",
            {
                "run_id": run.run_id,
                "source_path": str(file_path),
                "config": config.model_dump(),
                "pages": pages,
                "plan": plan.model_copy(update={"extractors": extractor_names}).model_dump(),
                "outputs": outputs,
            },
        )

        status = "needs_review" if quality.needs_review else "completed"
        return PsyduckResult(
            run_id=run.run_id,
            status=status,
            output_dir=str(run.path),
            document=document if return_content else None,
            profile=profile,
            quality=quality,
            outputs={
                **outputs,
                "quality": str(run.path / "quality.json"),
                "profile": str(run.path / "profile.json"),
                "assets_dir": str(run.assets_dir),
                "pages_dir": str(run.pages_dir),
            },
        )

    def recover(self, run_id: str | Path, actions: list[dict] | None = None) -> PsyduckResult:
        loaded = self.load_result(run_id, return_content=True)
        root = Path(loaded.output_dir)
        run_payload = read_json(root / "run.json")
        if loaded.document is None or loaded.profile is None:
            return loaded

        quality = evaluate_quality(
            loaded.document,
            loaded.profile,
            goal=run_payload["config"]["goal"],
            ocr=run_payload["config"].get("ocr", "auto"),
            tables=run_payload["config"].get("tables", "auto"),
            evaluated_pages=run_payload.get("pages"),
        )
        write_json(root / "quality.json", quality.model_dump())

        return self.load_result(root, return_content=True)

    def load_result(
        self,
        output_dir: str | Path,
        *,
        return_content: bool = True,
    ) -> PsyduckResult:
        root = Path(output_dir)
        outputs = discover_outputs(root)
        run_payload = read_json(root / "run.json")
        profile = PsyduckProfile.model_validate(read_json(root / "profile.json"))
        quality = PsyduckQualityReport.model_validate(read_json(root / "quality.json"))
        document = None
        if return_content:
            document = PsyduckDocument.model_validate(read_json(root / "document.json"))

        return PsyduckResult(
            run_id=run_payload["run_id"],
            status="needs_review" if quality.needs_review else "completed",
            output_dir=str(root),
            document=document,
            profile=profile,
            quality=quality,
            outputs=outputs,
        )

    def _run_extractors(
        self,
        file_path: str | Path,
        extractor_names: list[str],
        pages: list[int] | None = None,
    ) -> list[ExtractorOutput]:
        outputs: list[ExtractorOutput] = []
        for name in extractor_names:
            factory = self.extractor_registry.get(name)
            if factory is None:
                outputs.append(
                    ExtractorOutput(
                        source=name,
                        warnings=[
                            PsyduckWarning(
                                code="UNKNOWN_EXTRACTOR",
                                severity="warning",
                                message=f"No extractor is registered for {name}.",
                            )
                        ],
                    )
                )
                continue
            extractor = factory()
            try:
                outputs.append(extractor.extract(file_path, pages=pages))
            except RuntimeError as exc:
                outputs.append(
                    ExtractorOutput(
                        source=name,
                        warnings=[
                            PsyduckWarning(
                                code="EXTRACTOR_UNAVAILABLE",
                                severity="warning",
                                message=str(exc),
                            )
                        ],
                    )
                )
            except Exception as exc:
                outputs.append(
                    ExtractorOutput(
                        source=name,
                        warnings=[
                            PsyduckWarning(
                                code="EXTRACTOR_FAILED",
                                severity="error",
                                block_id=name,
                                message=f"{name} extractor failed: {exc}",
                            )
                        ],
                    )
                )
        return outputs
