from typing import Literal

from pydantic import BaseModel, Field

PsyduckGoal = Literal["auto", "summary", "qa", "rag", "tables", "archive"]
PsyduckMode = Literal["fast", "balanced", "high_quality"]
AutoOption = Literal["off", "auto", "force"]


class PsyduckConfig(BaseModel):
    goal: PsyduckGoal = "auto"
    mode: PsyduckMode = "balanced"
    ocr: AutoOption = "auto"
    tables: AutoOption = "auto"
    return_content: bool = False
    quality_threshold: float = Field(default=0.7, ge=0.0, le=1.0)
