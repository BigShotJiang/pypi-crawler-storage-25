from __future__ import annotations

from collections import defaultdict

from psyduck.schema import PsyduckDocument, PsyduckProfile, PsyduckQualityReport, PsyduckWarning


def evaluate_quality(
    document: PsyduckDocument,
    profile: PsyduckProfile,
    extractor_warnings: list[PsyduckWarning] | None = None,
    goal: str = "auto",
    ocr: str = "auto",
    tables: str = "auto",
    evaluated_pages: list[int] | None = None,
) -> PsyduckQualityReport:
    warnings: list[PsyduckWarning] = list(extractor_warnings or [])
    score = 1.0
    pages_to_evaluate = evaluated_pages or list(range(1, profile.page_count + 1))

    blocks_by_page = defaultdict(list)
    for block in document.blocks:
        blocks_by_page[block.page].append(block)

    for page in pages_to_evaluate:
        if not blocks_by_page[page]:
            score -= 0.1
            warnings.append(
                PsyduckWarning(
                    code="EMPTY_PAGE",
                    severity="warning",
                    page=page,
                    message="No extractable blocks were found on this page.",
                    suggested_action={"type": "needs_ocr_adapter", "pages": [page]},
                )
            )

    for table in document.tables:
        if table.confidence < 0.7:
            score -= 0.05
            warnings.append(
                PsyduckWarning(
                    code="LOW_CONFIDENCE_TABLE",
                    severity="warning",
                    page=table.page,
                    block_id=table.id,
                    message="Table confidence is below threshold.",
                    suggested_action={
                        "type": "needs_table_adapter",
                        "pages": [table.page],
                    },
                )
            )
        expected_width = len(table.headers[-1]) if table.headers else None
        if expected_width and any(len(row) != expected_width for row in table.rows):
            score -= 0.1
            warnings.append(
                PsyduckWarning(
                    code="MALFORMED_TABLE",
                    severity="warning",
                    page=table.page,
                    block_id=table.id,
                    message="Table rows have inconsistent column counts.",
                    suggested_action={
                        "type": "needs_table_adapter",
                        "pages": [table.page],
                    },
                )
            )

    if goal == "tables" and not document.tables:
        score -= 0.3
        warnings.append(
            PsyduckWarning(
                code="NO_TABLES_EXTRACTED",
                severity="error",
                message="Table extraction was requested but no tables were extracted.",
                suggested_action={"type": "needs_table_adapter"},
            )
        )

    if tables == "force" and not document.tables:
        score -= 0.2
        warnings.append(
            PsyduckWarning(
                code="TABLE_ADAPTER_NEEDED",
                severity="error",
                message="Table extraction was forced, but no table adapter is configured.",
                suggested_action={"type": "needs_table_adapter"},
            )
        )

    if ocr == "force":
        score -= 0.2
        warnings.append(
            PsyduckWarning(
                code="OCR_ADAPTER_NEEDED",
                severity="error",
                message="OCR was forced, but no OCR adapter is configured.",
                suggested_action={"type": "needs_ocr_adapter"},
            )
        )

    if profile.scan_ratio > 0.3:
        score -= 0.2
        warnings.append(
            PsyduckWarning(
                code="OCR_NEEDED",
                severity="error",
                message="Document appears to contain scanned pages.",
                suggested_action={
                    "type": "needs_ocr_adapter",
                    "pages": profile.image_heavy_pages or None,
                },
            )
        )

    review_codes = {
        "EMPTY_PAGE",
        "LOW_CONFIDENCE_TABLE",
        "MALFORMED_TABLE",
        "OCR_NEEDED",
        "NO_TABLES_EXTRACTED",
        "TABLE_ADAPTER_NEEDED",
        "OCR_ADAPTER_NEEDED",
        "EXTRACTOR_FAILED",
    }
    return PsyduckQualityReport(
        score=max(score, 0.0),
        needs_review=any(warning.code in review_codes for warning in warnings),
        warnings=warnings,
    )
