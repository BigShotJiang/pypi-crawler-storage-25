from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4


@dataclass(frozen=True)
class RunDirectory:
    run_id: str
    path: Path
    tables_dir: Path
    assets_dir: Path
    pages_dir: Path


def create_run_dir(file_path: str | Path, output_root: str | Path | None = None) -> RunDirectory:
    source = Path(file_path)
    root = Path(output_root) if output_root else Path("output")
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"{source.stem}-{timestamp}-{uuid4().hex[:8]}"
    path = root / run_id
    tables_dir = path / "tables"
    assets_dir = path / "assets"
    pages_dir = path / "pages"
    for directory in (path, tables_dir, assets_dir, pages_dir):
        directory.mkdir(parents=True, exist_ok=True)
    return RunDirectory(
        run_id=run_id,
        path=path,
        tables_dir=tables_dir,
        assets_dir=assets_dir,
        pages_dir=pages_dir,
    )


def write_json(path: str | Path, payload: Any) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return destination


def read_json(path: str | Path) -> Any:
    source = Path(path)
    return json.loads(source.read_text(encoding="utf-8"))


def discover_outputs(output_dir: str | Path) -> dict[str, str]:
    root = Path(output_dir)
    outputs = {
        "markdown": root / "document.md",
        "json": root / "document.json",
        "quality": root / "quality.json",
        "profile": root / "profile.json",
        "run": root / "run.json",
        "tables_dir": root / "tables",
        "assets_dir": root / "assets",
        "pages_dir": root / "pages",
    }
    return {key: str(path) for key, path in outputs.items() if path.exists()}
