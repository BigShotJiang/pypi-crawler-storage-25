from __future__ import annotations

from pathlib import Path

import fitz

from psyduck.schema import PsyduckProfile


def profile_pdf(file_path: str | Path, pages: list[int] | None = None) -> PsyduckProfile:
    doc = fitz.open(str(file_path))
    selected_pages = _validate_pages(doc, pages)
    text_counts: list[int] = []
    image_heavy_pages: list[int] = []
    likely_table_pages: list[int] = []
    rotated_pages: list[int] = []

    for index in selected_pages:
        page = doc[index - 1]
        text = page.get_text("text") or ""
        text_counts.append(len(text.strip()))
        images = page.get_images(full=True)
        if len(images) >= 3 and len(text.strip()) < 100:
            image_heavy_pages.append(index)
        if page.rotation:
            rotated_pages.append(index)
        if _looks_like_table_text(text):
            likely_table_pages.append(index)

    page_count = len(doc)
    processed_page_count = len(selected_pages)
    pages_with_text = sum(1 for count in text_counts if count > 20)
    scan_like_pages = processed_page_count - pages_with_text
    avg_text = sum(text_counts) / processed_page_count if processed_page_count else 0

    return PsyduckProfile(
        page_count=page_count,
        encrypted=doc.needs_pass,
        has_text_layer=pages_with_text > 0,
        scan_ratio=(scan_like_pages / processed_page_count) if processed_page_count else 0,
        avg_text_chars_per_page=avg_text,
        image_heavy_pages=image_heavy_pages,
        likely_table_pages=likely_table_pages,
        rotated_pages=rotated_pages,
        selected_pages=selected_pages if pages is not None else None,
        processed_page_count=processed_page_count,
    )


def _looks_like_table_text(text: str) -> bool:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    numericish = sum(1 for line in lines if sum(ch.isdigit() for ch in line) >= 2)
    columnish = sum(1 for line in lines if len(line.split()) >= 3)
    return numericish >= 1 and columnish >= 2


def _validate_pages(doc, pages: list[int] | None) -> list[int]:
    if pages is None:
        return list(range(1, len(doc) + 1))
    if any(page < 1 for page in pages):
        raise ValueError("pages must be 1-based positive integers")
    if any(page > len(doc) for page in pages):
        raise ValueError(f"pages cannot exceed PDF page count {len(doc)}")
    return list(dict.fromkeys(pages))
