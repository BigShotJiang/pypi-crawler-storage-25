from __future__ import annotations

from pydantic import BaseModel, Field

from psyduck.config import PsyduckConfig
from psyduck.schema import PsyduckProfile


class PsyduckPlan(BaseModel):
    extractors: list[str] = Field(default_factory=list)
    exports: list[str] = Field(default_factory=list)
    table_pages: list[int] = Field(default_factory=list)
    ocr_pages: list[int] = Field(default_factory=list)


def plan_extraction(profile: PsyduckProfile, config: PsyduckConfig) -> PsyduckPlan:
    extractors: list[str] = ["pymupdf"]
    exports: list[str] = ["json", "markdown"]

    if config.mode == "high_quality":
        exports.append("page_previews")

    if config.goal == "archive":
        exports.append("assets")

    return PsyduckPlan(
        extractors=_dedupe(extractors),
        exports=_dedupe(exports),
        table_pages=profile.likely_table_pages,
        ocr_pages=profile.image_heavy_pages,
    )


def _dedupe(values: list[str]) -> list[str]:
    return list(dict.fromkeys(values))
