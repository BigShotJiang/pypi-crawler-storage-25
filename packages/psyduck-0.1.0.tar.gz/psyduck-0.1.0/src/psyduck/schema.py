from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

BlockType = Literal["heading", "paragraph", "list_item", "table", "figure", "header", "footer"]
RunStatus = Literal["completed", "needs_review", "failed"]
Severity = Literal["info", "warning", "error"]


class PsyduckBlock(BaseModel):
    id: str
    type: BlockType
    page: int = Field(ge=1)
    bbox: list[float] | None = None
    text: str | None = None
    source: str
    confidence: float = Field(ge=0.0, le=1.0)


class PsyduckTable(BaseModel):
    id: str
    page: int = Field(ge=1)
    bbox: list[float] | None = None
    title: str | None = None
    headers: list[list[str]] = Field(default_factory=list)
    rows: list[list[str]] = Field(default_factory=list)
    source: str
    confidence: float = Field(ge=0.0, le=1.0)
    csv_path: str | None = None


class PsyduckDocument(BaseModel):
    document_id: str
    source_path: str
    page_count: int = Field(ge=0)
    blocks: list[PsyduckBlock] = Field(default_factory=list)
    tables: list[PsyduckTable] = Field(default_factory=list)
    assets: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PsyduckProfile(BaseModel):
    page_count: int = Field(ge=0)
    encrypted: bool = False
    has_text_layer: bool = False
    scan_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    avg_text_chars_per_page: float = Field(default=0.0, ge=0.0)
    image_heavy_pages: list[int] = Field(default_factory=list)
    likely_table_pages: list[int] = Field(default_factory=list)
    rotated_pages: list[int] = Field(default_factory=list)
    language: str | None = None
    selected_pages: list[int] | None = None
    processed_page_count: int | None = None


class PsyduckWarning(BaseModel):
    code: str
    severity: Severity
    page: int | None = None
    block_id: str | None = None
    message: str
    suggested_action: dict[str, Any] | None = None


class PsyduckQualityReport(BaseModel):
    score: float = Field(ge=0.0, le=1.0)
    needs_review: bool = False
    warnings: list[PsyduckWarning] = Field(default_factory=list)
    suggested_actions: list[dict[str, Any]] = Field(default_factory=list)

    @model_validator(mode="after")
    def derive_review_state(self) -> "PsyduckQualityReport":
        if self.score < 0.7 or any(w.severity == "error" for w in self.warnings):
            self.needs_review = True
        if not self.suggested_actions:
            self.suggested_actions = [
                warning.suggested_action
                for warning in self.warnings
                if warning.suggested_action is not None
            ]
        return self


class PsyduckResult(BaseModel):
    run_id: str
    status: RunStatus
    output_dir: str
    document: PsyduckDocument | None
    profile: PsyduckProfile | None
    quality: PsyduckQualityReport
    outputs: dict[str, str] = Field(default_factory=dict)

    def is_usable_for(self, goal: str, threshold: float = 0.7) -> bool:
        if self.status == "failed":
            return False
        if self.quality.score < threshold:
            return False
        if goal == "tables" and self.quality.needs_review:
            return False
        if goal == "tables":
            blocking_codes = {
                "LOW_CONFIDENCE_TABLE",
                "MALFORMED_TABLE",
                "NO_TABLES_EXTRACTED",
            }
            return not any(w.code in blocking_codes for w in self.quality.warnings)
        return True
