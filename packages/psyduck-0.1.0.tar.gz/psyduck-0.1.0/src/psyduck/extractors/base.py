from __future__ import annotations

from pathlib import Path
from typing import Protocol

from pydantic import BaseModel, Field

from psyduck.schema import PsyduckBlock, PsyduckTable, PsyduckWarning


class ExtractorOutput(BaseModel):
    source: str
    blocks: list[PsyduckBlock] = Field(default_factory=list)
    tables: list[PsyduckTable] = Field(default_factory=list)
    warnings: list[PsyduckWarning] = Field(default_factory=list)


class Extractor(Protocol):
    source: str

    def extract(self, file_path: str | Path, pages: list[int] | None = None) -> ExtractorOutput: ...
