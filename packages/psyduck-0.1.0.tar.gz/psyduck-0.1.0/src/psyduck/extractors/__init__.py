from psyduck.extractors.base import Extractor, ExtractorOutput

__all__ = ["Extractor", "ExtractorOutput"]
