from __future__ import annotations

from pathlib import Path

import fitz

from psyduck.extractors.base import ExtractorOutput
from psyduck.schema import PsyduckBlock


class PyMuPDFExtractor:
    source = "pymupdf"

    def extract(self, file_path: str | Path, pages: list[int] | None = None) -> ExtractorOutput:
        doc = fitz.open(str(file_path))
        page_filter = set(pages) if pages else None
        blocks: list[PsyduckBlock] = []

        for page_index, page in enumerate(doc, start=1):
            if page_filter is not None and page_index not in page_filter:
                continue
            for block_index, block in enumerate(page.get_text("blocks"), start=1):
                x0, y0, x1, y1, text, *_ = block
                cleaned = " ".join(str(text).split())
                if not cleaned:
                    continue
                blocks.append(
                    PsyduckBlock(
                        id=f"p{page_index}_b{block_index}",
                        type="paragraph",
                        page=page_index,
                        bbox=[x0, y0, x1, y1],
                        text=cleaned,
                        source=self.source,
                        confidence=1.0,
                    )
                )

        return ExtractorOutput(source=self.source, blocks=blocks)


def render_page_previews(
    file_path: str | Path,
    output_dir: str | Path,
    pages: list[int] | None = None,
    zoom: float = 1.5,
) -> list[dict]:
    doc = fitz.open(str(file_path))
    selected = pages or list(range(1, len(doc) + 1))
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    assets = []
    matrix = fitz.Matrix(zoom, zoom)
    for page_number in selected:
        pix = doc[page_number - 1].get_pixmap(matrix=matrix)
        path = root / f"page_{page_number:03d}.png"
        pix.save(str(path))
        assets.append({"type": "page_preview", "page": page_number, "path": str(path)})
    return assets


def extract_images(
    file_path: str | Path,
    output_dir: str | Path,
    pages: list[int] | None = None,
) -> list[dict]:
    doc = fitz.open(str(file_path))
    selected = pages or list(range(1, len(doc) + 1))
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    assets = []
    for page_number in selected:
        page = doc[page_number - 1]
        for index, image in enumerate(page.get_images(full=True), start=1):
            xref = image[0]
            extracted = doc.extract_image(xref)
            ext = extracted.get("ext", "png")
            path = root / f"page_{page_number:03d}_image_{index:03d}.{ext}"
            path.write_bytes(extracted["image"])
            assets.append({"type": "image", "page": page_number, "path": str(path)})
    return assets
