from __future__ import annotations

import csv
from pathlib import Path

from psyduck.schema import PsyduckDocument
from psyduck.storage import write_json


def export_document(document: PsyduckDocument, output_dir: str | Path) -> dict[str, str]:
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    tables_dir = root / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)

    markdown_path = root / "document.md"
    json_path = root / "document.json"

    markdown_path.write_text(_to_markdown(document), encoding="utf-8")

    for table in document.tables:
        csv_path = tables_dir / f"{table.id}.csv"
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            for header in table.headers:
                writer.writerow(header)
            writer.writerows(table.rows)
        table.csv_path = str(csv_path)

    write_json(json_path, document.model_dump())

    return {
        "markdown": str(markdown_path),
        "json": str(json_path),
        "tables_dir": str(tables_dir),
    }


def _to_markdown(document: PsyduckDocument) -> str:
    lines: list[str] = []
    for block in sorted(document.blocks, key=lambda item: (item.page, item.id)):
        if block.text:
            lines.append(block.text)
    return "\n\n".join(lines) + ("\n" if lines else "")
