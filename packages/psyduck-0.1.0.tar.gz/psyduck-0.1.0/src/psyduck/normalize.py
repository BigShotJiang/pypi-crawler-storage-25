from __future__ import annotations

from pathlib import Path

from psyduck.extractors.base import ExtractorOutput
from psyduck.schema import PsyduckDocument, PsyduckProfile


def normalize_outputs(
    file_path: str | Path,
    profile: PsyduckProfile,
    outputs: list[ExtractorOutput],
) -> PsyduckDocument:
    blocks = []
    tables = []
    extractor_warnings = []
    for output in outputs:
        blocks.extend(output.blocks)
        tables.extend(output.tables)
        extractor_warnings.extend(warning.model_dump() for warning in output.warnings)

    return PsyduckDocument(
        document_id=Path(file_path).stem,
        source_path=str(file_path),
        page_count=profile.page_count,
        blocks=blocks,
        tables=tables,
        metadata={
            "extractors": [output.source for output in outputs],
            "extractor_warnings": extractor_warnings,
        },
    )
