# Psyduck SDK-Only Minimal Core Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn Psyduck into a clean SDK-only PDF processing package with no CLI and only a PyMuPDF-backed default extraction path.

**Architecture:** Keep `Psyduck.process()` as the public entrypoint and keep structured schemas, profiling, normalization, export, loading, quality reports, page previews, and image asset extraction. Remove CLI packaging and optional built-in adapters so the core SDK has a small dependency surface; future adapters can be supplied by callers through `extractor_registry` without being shipped as first-party modules.

**Tech Stack:** Python 3.11+, Pydantic v2, PyMuPDF, pytest, ruff, reportlab test fixtures.

---

## File Structure

**Files to delete**
- `src/psyduck/cli.py`: CLI surface is out of scope.
- `src/psyduck/extractors/docling.py`: remove first-party optional adapter.
- `src/psyduck/extractors/camelot.py`: remove first-party optional adapter.
- `src/psyduck/extractors/pdfplumber.py`: remove first-party optional adapter.
- `src/psyduck/extractors/ocr.py`: remove placeholder adapter.
- `tests/test_cli.py`: CLI tests no longer apply.
- `tests/test_optional_integrations.py`: optional integration adapters no longer ship.

**Files to modify**
- `pyproject.toml`: remove CLI dependencies, optional adapter extras, and console script.
- `README.md`: document SDK-only install and usage; remove CLI and optional adapter installation docs.
- `src/psyduck/core.py`: default registry becomes PyMuPDF-only; remove optional adapter imports and recovery action reruns that rely on removed adapters.
- `src/psyduck/planner.py`: only plans `pymupdf`; keep export intent metadata for JSON/Markdown/page previews/assets without selecting removed adapters. Do not advertise CSV in the default plan because no built-in table extractor remains.
- `src/psyduck/quality.py`: keep content/table/OCR quality warnings, but do not suggest unsupported recovery actions as if bundled.
- `src/psyduck/extractors/base.py`: keep protocol focused on `extract(file_path, pages=None)`.
- `src/psyduck/extractors/__init__.py`: export only base and PyMuPDF names if it currently exports removed adapters.
- `tests/test_core.py`: remove tests for removed adapters; add tests proving default SDK does not try missing adapters.
- `tests/test_planner.py`: rewrite expected plan to PyMuPDF-only.
- `tests/test_quality.py`: update suggested action expectations to match SDK-only behavior.
- `tests/test_recover.py`: simplify or remove adapter-specific recovery tests.
- `tests/test_sdk_options.py`: remove tests that assert OCR/docling planning; keep page subset behavior tests.
- `tests/test_assets.py`, `tests/test_export.py`, `tests/test_load_result.py`, `tests/test_profile.py`, `tests/test_pymupdf_extractor.py`, `tests/test_schema.py`, `tests/test_storage.py`: keep and adjust only if imports or expected warnings change.

**Generated/local cleanup**
- Remove local `output/` sample runs, `.DS_Store`, `.pytest_cache`, `__pycache__`, and `.ruff_cache` if they are present in the project tree. Do not remove `.venv`.

---

## Chunk 1: Remove CLI Surface

### Task 1: Remove package CLI metadata

**Files:**
- Modify: `pyproject.toml`
- Delete later in Task 2: `src/psyduck/cli.py`
- Delete later in Task 2: `tests/test_cli.py`

- [ ] **Step 1: Write failing metadata test**

Create `tests/test_package_metadata.py` with:

```python
from pathlib import Path

import tomllib


def test_package_has_no_console_scripts_or_cli_dependencies():
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))

    project = pyproject["project"]
    assert "scripts" not in project
    assert "typer>=0.12" not in project["dependencies"]
    assert "rich>=13.7" not in project["dependencies"]
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
.venv/bin/pytest tests/test_package_metadata.py::test_package_has_no_console_scripts_or_cli_dependencies -v
```

Expected: FAIL because `[project.scripts]`, `typer`, and `rich` still exist.

- [ ] **Step 3: Remove CLI packaging**

Edit `pyproject.toml`:

```toml
dependencies = [
  "pydantic>=2.7",
  "pymupdf>=1.24",
]
```

Remove the entire block:

```toml
[project.scripts]
psyduck = "psyduck.cli:app"
```

- [ ] **Step 4: Run test to verify it passes**

Run:

```bash
.venv/bin/pytest tests/test_package_metadata.py::test_package_has_no_console_scripts_or_cli_dependencies -v
```

Expected: PASS.

### Task 2: Delete CLI module and tests

**Files:**
- Delete: `src/psyduck/cli.py`
- Delete: `tests/test_cli.py`

- [ ] **Step 1: Delete CLI files**

Use `apply_patch`:

```diff
*** Begin Patch
*** Delete File: src/psyduck/cli.py
*** End Patch
```

Use a second `apply_patch` call:

```diff
*** Begin Patch
*** Delete File: tests/test_cli.py
*** End Patch
```

- [ ] **Step 2: Search for CLI references**

Run:

```bash
rg -n "psyduck\\.cli|Typer|typer|rich|project\\.scripts|\\[project\\.scripts\\]|psyduck inspect|psyduck process|CLI" .
```

Expected: this command may still find matches in docs/plans, so do not use it as the final gate. It is only a broad diagnostic. The final obsolete-reference gate in Task 10 is scoped to active package files.

- [ ] **Step 3: Run focused tests**

Run:

```bash
.venv/bin/pytest tests/test_package_metadata.py -v
```

Expected: PASS.

---

## Chunk 2: Remove Built-In Optional Adapters

### Task 3: Remove optional dependency extras

**Files:**
- Modify: `pyproject.toml`
- Test: `tests/test_package_metadata.py`

- [ ] **Step 1: Extend failing metadata test**

Update `test_package_has_no_console_scripts_or_cli_dependencies` or add:

```python
def test_package_has_no_builtin_optional_adapter_extras():
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))

    optional = pyproject["project"].get("optional-dependencies", {})
    assert "docling" not in optional
    assert "tables" not in optional
    assert "ocr" not in optional
    assert "all" not in optional
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
.venv/bin/pytest tests/test_package_metadata.py::test_package_has_no_builtin_optional_adapter_extras -v
```

Expected: FAIL because optional extras still exist.

- [ ] **Step 3: Remove optional adapter extras**

Edit `pyproject.toml` so only `dev` remains:

```toml
[project.optional-dependencies]
dev = ["pytest>=8.0", "ruff>=0.6", "reportlab>=4.0"]
```

- [ ] **Step 4: Run metadata tests**

Run:

```bash
.venv/bin/pytest tests/test_package_metadata.py -v
```

Expected: PASS.

### Task 4: Delete optional adapter modules

**Files:**
- Delete: `src/psyduck/extractors/docling.py`
- Delete: `src/psyduck/extractors/camelot.py`
- Delete: `src/psyduck/extractors/pdfplumber.py`
- Delete: `src/psyduck/extractors/ocr.py`
- Delete: `tests/test_optional_integrations.py`
- Modify: `tests/test_core.py`

- [ ] **Step 1: Write failing import-boundary test**

Add to `tests/test_core.py`:

```python
def test_default_registry_is_pymupdf_only():
    duck = Psyduck()

    assert set(duck.extractor_registry) == {"pymupdf"}
```

- [ ] **Step 2: Run test to verify it fails**

Run:

```bash
.venv/bin/pytest tests/test_core.py::test_default_registry_is_pymupdf_only -v
```

Expected: FAIL because the default registry still includes `docling`, `camelot`, `pdfplumber`, and `ocr`.

- [ ] **Step 3: Delete adapter modules and optional integration tests**

Use `apply_patch`:

```diff
*** Begin Patch
*** Delete File: src/psyduck/extractors/docling.py
*** End Patch
```

Use a second `apply_patch` call:

```diff
*** Begin Patch
*** Delete File: src/psyduck/extractors/camelot.py
*** End Patch
```

Use a third `apply_patch` call:

```diff
*** Begin Patch
*** Delete File: src/psyduck/extractors/pdfplumber.py
*** End Patch
```

Use a fourth `apply_patch` call:

```diff
*** Begin Patch
*** Delete File: src/psyduck/extractors/ocr.py
*** End Patch
```

Use a fifth `apply_patch` call:

```diff
*** Begin Patch
*** Delete File: tests/test_optional_integrations.py
*** End Patch
```

- [ ] **Step 4: Remove adapter tests from `tests/test_core.py`**

Delete these tests:

```python
test_missing_optional_docling_dependency_has_clear_error
test_docling_adapter_converts_markdown_to_block
test_camelot_adapter_converts_tables_to_schema
test_pdfplumber_adapter_converts_tables_to_schema
test_normalize_prefers_docling_blocks_over_duplicate_pymupdf_blocks
```

Keep tests for `Psyduck.process()`, `normalize_outputs()`, table quality, extractor failure handling, and page-scoped behavior.

- [ ] **Step 5: Update imports**

In `tests/test_core.py`, remove imports for:

```python
from psyduck.extractors.camelot import CamelotExtractor
from psyduck.extractors.docling import DoclingExtractor
from psyduck.extractors.pdfplumber import PdfPlumberExtractor
```

- [ ] **Step 6: Run focused test**

Run:

```bash
.venv/bin/pytest tests/test_core.py::test_default_registry_is_pymupdf_only -v
```

Expected: still FAIL until `src/psyduck/core.py` is updated in the next chunk.

---

## Chunk 3: Simplify Core Planning and Extraction

### Task 5: Make default extraction PyMuPDF-only

**Files:**
- Modify: `src/psyduck/core.py`
- Modify: `src/psyduck/planner.py`
- Test: `tests/test_core.py`
- Test: `tests/test_planner.py`

- [ ] **Step 1: Update planner tests first**

Rewrite `tests/test_planner.py` to assert SDK-only planning:

```python
from psyduck.config import PsyduckConfig
from psyduck.planner import plan_extraction
from psyduck.schema import PsyduckProfile


def test_all_goals_use_pymupdf_only_by_default():
    profile = PsyduckProfile(page_count=1, has_text_layer=True, likely_table_pages=[1])

    for goal in ["auto", "summary", "qa", "rag", "tables", "archive"]:
        plan = plan_extraction(profile, PsyduckConfig(goal=goal))
        assert plan.extractors == ["pymupdf"]


def test_high_quality_plan_records_page_preview_export():
    profile = PsyduckProfile(page_count=1, has_text_layer=True)

    plan = plan_extraction(profile, PsyduckConfig(mode="high_quality"))

    assert plan.extractors == ["pymupdf"]
    assert "page_previews" in plan.exports
```

- [ ] **Step 2: Run planner tests to verify they fail**

Run:

```bash
.venv/bin/pytest tests/test_planner.py -v
```

Expected: FAIL because planner still selects removed adapters.

- [ ] **Step 3: Update `src/psyduck/planner.py`**

Replace `plan_extraction()` with:

```python
def plan_extraction(profile: PsyduckProfile, config: PsyduckConfig) -> PsyduckPlan:
    exports: list[str] = ["json", "markdown"]

    if config.mode == "high_quality":
        exports.append("page_previews")

    if config.goal == "archive":
        exports.append("assets")

    return PsyduckPlan(
        extractors=["pymupdf"],
        exports=_dedupe(exports),
        table_pages=profile.likely_table_pages,
        ocr_pages=profile.image_heavy_pages,
    )
```

Keep `_dedupe()` and `PsyduckPlan`.

- [ ] **Step 4: Update `src/psyduck/core.py` imports and registry**

Remove imports:

```python
from inspect import Parameter, signature
from psyduck.extractors.camelot import CamelotExtractor
from psyduck.extractors.docling import DoclingExtractor
from psyduck.extractors.ocr import OcrExtractor
from psyduck.extractors.pdfplumber import PdfPlumberExtractor
```

Change default registry to:

```python
self.extractor_registry = extractor_registry or {
    "pymupdf": PyMuPDFExtractor,
}
```

Remove the page-scoped Docling filtering block from `process()` because Docling is not selected anymore:

```python
if pages is not None and "docling" in plan.extractors:
    ...
```

- [ ] **Step 5: Simplify `_run_extractors()`**

Change signature:

```python
def _run_extractors(
    self,
    file_path: str | Path,
    extractor_names: list[str],
    pages: list[int] | None = None,
) -> list[ExtractorOutput]:
```

Call extractors directly:

```python
extractor = factory()
outputs.append(extractor.extract(file_path, pages=pages))
```

Delete `_supported_extractor_options()`.

- [ ] **Step 6: Run focused tests**

Run:

```bash
.venv/bin/pytest tests/test_planner.py tests/test_core.py::test_default_registry_is_pymupdf_only -v
```

Expected: PASS.

### Task 6: Preserve custom extractor extension point

**Files:**
- Modify: `tests/test_core.py`
- Modify: `src/psyduck/core.py` only if needed

- [ ] **Step 1: Add custom registry test**

Add:

```python
def test_custom_registry_can_add_named_extractors(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    calls = []

    class CustomExtractor:
        def extract(self, file_path, pages=None):
            calls.append(("custom", pages))
            return ExtractorOutput(source="custom")

    result = Psyduck(
        extractor_registry={
            "pymupdf": lambda: FakeTextExtractor(),
            "custom": lambda: CustomExtractor(),
        }
    )._run_extractors(pdf_path, ["pymupdf", "custom"], pages=[1])

    assert [output.source for output in result] == ["pymupdf", "custom"]
    assert calls == [("custom", [1])]
```

- [ ] **Step 2: Run test**

Run:

```bash
.venv/bin/pytest tests/test_core.py::test_custom_registry_can_add_named_extractors -v
```

Expected: PASS if `_run_extractors()` still supports caller-supplied registries.

---

## Chunk 4: Simplify Recovery and Quality Actions

### Task 7: Remove bundled OCR/table recovery claims

**Files:**
- Modify: `src/psyduck/core.py`
- Modify: `src/psyduck/quality.py`
- Modify: `tests/test_recover.py`
- Modify: `tests/test_quality.py`

- [ ] **Step 1: Replace recovery tests**

Rewrite `tests/test_recover.py` to SDK-only behavior:

```python
from pathlib import Path

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_text_pdf


def test_recover_reloads_and_refreshes_existing_result_without_adapter_reruns(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    result = Psyduck().process(pdf_path, output_dir=tmp_path / "out", return_content=True)

    recovered = Psyduck().recover(result.output_dir)

    assert recovered.run_id == result.run_id
    assert recovered.document.blocks
    assert recovered.quality.score == result.quality.score
```

- [ ] **Step 2: Run recovery test to verify it fails or old tests fail**

Run:

```bash
.venv/bin/pytest tests/test_recover.py -v
```

Expected: FAIL until `recover()` is simplified and old adapter tests are removed.

- [ ] **Step 3: Simplify `recover()`**

Replace `recover()` with:

```python
def recover(self, run_id: str | Path, actions: list[dict] | None = None) -> PsyduckResult:
    loaded = self.load_result(run_id, return_content=True)
    if loaded.document is None or loaded.profile is None:
        return loaded

    root = Path(loaded.output_dir)
    run_payload = read_json(root / "run.json")
    quality = evaluate_quality(
        loaded.document,
        loaded.profile,
        goal=run_payload["config"]["goal"],
        evaluated_pages=run_payload.get("pages"),
    )
    write_json(root / "quality.json", quality.model_dump())
    return self.load_result(root, return_content=True)
```

Delete `_run_table_recovery()`.

- [ ] **Step 4: Update quality suggestions**

In `src/psyduck/quality.py`, keep warning codes but remove unsupported first-party recovery claims:

For `EMPTY_PAGE`, use:

```python
suggested_action={"type": "needs_ocr_adapter", "pages": [page]}
```

For `LOW_CONFIDENCE_TABLE` / `MALFORMED_TABLE`, use:

```python
suggested_action={"type": "needs_table_adapter", "pages": [table.page]}
```

For `NO_TABLES_EXTRACTED`, use:

```python
suggested_action={"type": "needs_table_adapter"}
```

For `OCR_NEEDED`, use:

```python
suggested_action={"type": "needs_ocr_adapter", "pages": profile.image_heavy_pages or None}
```

- [ ] **Step 5: Update quality tests**

In `tests/test_quality.py`, replace:

```python
assert any(action["type"] == "rerun_tables" for action in report.suggested_actions)
```

with:

```python
assert any(action["type"] == "needs_table_adapter" for action in report.suggested_actions)
```

- [ ] **Step 6: Run focused tests**

Run:

```bash
.venv/bin/pytest tests/test_recover.py tests/test_quality.py -v
```

Expected: PASS.

---

## Chunk 5: Update SDK Tests for Minimal Scope

### Task 8: Rewrite SDK option tests

**Files:**
- Modify: `tests/test_sdk_options.py`

- [ ] **Step 1: Remove adapter-specific option tests**

Delete tests that assert:
- Docling is skipped for page-scoped runs.
- OCR is planned or invoked for scanned pages.
- `tables="off"` suppresses table extractors.
- `ocr="off"` suppresses OCR extractor.

These are obsolete because the default SDK has only PyMuPDF.

- [ ] **Step 2: Keep and strengthen page subset tests**

Keep:

```python
test_pages_option_limits_quality_and_document_blocks_without_redefining_page_count
test_pages_option_rejects_invalid_page_numbers
```

Add:

```python
def test_pages_option_does_not_change_default_extractor_set(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)
    result = Psyduck().process(
        pdf_path,
        pages=[1],
        tables="off",
        output_dir=tmp_path / "out",
    )

    assert result.profile.selected_pages == [1]
    assert result.quality.score >= 0
```

- [ ] **Step 3: Run SDK option tests**

Run:

```bash
.venv/bin/pytest tests/test_sdk_options.py -v
```

Expected: PASS.

### Task 9: Update core tests for removed adapters

**Files:**
- Modify: `tests/test_core.py`

- [ ] **Step 1: Remove now-obsolete tests**

Delete tests that require built-in table adapters to run:

```python
test_process_runs_planned_extractors
test_tables_goal_is_not_usable_when_table_extractors_are_unavailable
```

Replace with:

```python
def test_tables_goal_without_custom_table_extractor_needs_review(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    result = Psyduck().process(
        pdf_path,
        goal="tables",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert result.status == "needs_review"
    assert result.is_usable_for("tables") is False
    assert any(w.code == "NO_TABLES_EXTRACTED" for w in result.quality.warnings)
```

- [ ] **Step 2: Keep runtime failure handling test with custom extractor**

Keep `test_process_turns_unexpected_extractor_failures_into_review_warnings`, but make it explicitly call `_run_extractors()` or use a custom planner path only if needed. Since the default planner only returns `pymupdf`, this test should directly exercise `_run_extractors()`:

```python
def test_run_extractors_turns_unexpected_failures_into_warnings(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    outputs = Psyduck(
        extractor_registry={"custom": lambda: CrashingExtractor("custom")}
    )._run_extractors(pdf_path, ["custom"])

    assert outputs[0].warnings[0].code == "EXTRACTOR_FAILED"
```

- [ ] **Step 3: Run core tests**

Run:

```bash
.venv/bin/pytest tests/test_core.py -v
```

Expected: PASS.

---

## Chunk 6: Update Documentation

### Task 10: Rewrite README as SDK-only

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Replace README content**

Use this structure:

```markdown
# Psyduck

Psyduck is a small Python SDK for turning PDFs into agent-ready structured documents.

It is intentionally SDK-only: import it from Python, run `Psyduck().process(...)`, and inspect the returned document, profile, quality report, and exported artifacts.

## Install

```bash
pip install psyduck
```

Development install:

```bash
pip install -e ".[dev]"
```

## Python API

```python
from psyduck import Psyduck

duck = Psyduck()
result = duck.process("report.pdf", goal="rag", mode="balanced", return_content=True)

if result.quality.needs_review:
    for warning in result.quality.warnings:
        print(warning.code, warning.message)

for block in result.document.blocks:
    print(block.page, block.text)
```

## Output Directory

```text
output/report-<timestamp>-<id>/
  run.json
  profile.json
  document.md
  document.json
  quality.json
  tables/
  assets/
  pages/
```

## SDK Contract

- Default extraction uses PyMuPDF.
- `process()` always writes Markdown, JSON, profile, quality, and run metadata.
- `return_content=False` keeps large document content out of the immediate result.
- `load_result(output_dir)` reloads a previous SDK run.
- Custom extractors can be supplied through `extractor_registry`.

## Agent Policy

1. Always call `process()` before answering questions about PDF contents.
2. Check `result.quality` before using extracted content.
3. Use Markdown for summaries and JSON for page-aware answers.
4. Do not claim complete extraction when `needs_review` is true.
```

- [ ] **Step 2: Search for obsolete docs**

Run:

```bash
rg -n "CLI|psyduck inspect|psyduck process|docling|camelot|pdfplumber|pytesseract|psyduck\\[all\\]|psyduck\\[tables\\]|psyduck\\[docling\\]" README.md pyproject.toml src tests
```

Expected: no obsolete references in active package docs/code/tests. If this finds matches in deleted adapter paths, the files were not removed.

---

## Chunk 7: Clean Generated Files and Verify

### Task 11: Clean local generated output

**Files/directories:**
- Delete local generated directory: `output/`
- Delete local cache files: `.DS_Store`, `.pytest_cache/`, `__pycache__/`, `.ruff_cache/`
- Keep: `.venv/`

- [ ] **Step 1: Remove local generated files**

Run:

```bash
rm -rf output .pytest_cache .ruff_cache
find . -path './.venv' -prune -o \( -name '__pycache__' -o -name '.DS_Store' \) -print -exec rm -rf {} +
```

Expected: command completes without touching `.venv`.

- [ ] **Step 2: Confirm active source tree**

Run:

```bash
find src/psyduck tests -maxdepth 3 -type f | sort
```

Expected:
- No `src/psyduck/cli.py`
- No optional adapter modules
- No `tests/test_cli.py`
- No `tests/test_optional_integrations.py`

### Task 12: Full quality gate

**Files:**
- All active package and test files.

- [ ] **Step 1: Run formatter**

Run:

```bash
.venv/bin/ruff format .
```

Expected: completes successfully.

- [ ] **Step 2: Verify formatting**

Run:

```bash
.venv/bin/ruff format --check .
```

Expected: all files already formatted.

- [ ] **Step 3: Run lint**

Run:

```bash
.venv/bin/ruff check .
```

Expected: all checks passed.

- [ ] **Step 4: Run full test suite**

Run:

```bash
.venv/bin/pytest -q
```

Expected: all active tests pass. The number of tests will drop from the current suite because CLI and optional adapter tests are removed.

- [ ] **Step 5: Run SDK smoke test**

Run:

```bash
.venv/bin/python - <<'PY'
from pathlib import Path
from psyduck import Psyduck
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

pdf = Path("/tmp/psyduck-sdk-only-smoke.pdf")
c = canvas.Canvas(str(pdf), pagesize=letter)
for page in range(1, 3):
    c.drawString(72, 720, f"Plain paragraph page {page}")
    c.drawString(72, 690, "This PDF has text but no table-like fixture rows.")
    c.showPage()
c.save()

result = Psyduck().process(
    pdf,
    goal="rag",
    output_dir="/tmp/psyduck-sdk-only-smoke",
    return_content=True,
)
loaded = Psyduck().load_result(result.output_dir)

print(result.status)
print(len(result.document.blocks))
print(loaded.profile.page_count)
print(result.outputs["markdown"])
PY
```

Expected:

```text
completed
<positive block count>
2
/tmp/psyduck-sdk-only-smoke/.../document.md
```

### Task 13: Final report

- [ ] **Step 1: Summarize changed scope**

Report:
- CLI removed.
- First-party optional adapters removed.
- Default SDK uses PyMuPDF only.
- Custom extractors remain possible through `extractor_registry`.
- Quality warnings now describe missing adapter needs instead of pretending bundled recovery exists.

- [ ] **Step 2: Report verification**

Include exact final commands and results:

```text
.venv/bin/ruff format --check . -> pass
.venv/bin/ruff check . -> pass
.venv/bin/pytest -q -> pass
SDK smoke test -> pass
```

---

## Notes for Implementer

- This directory may not be a git repository. If `git status --short` returns “not a git repository,” skip commit steps and report that no commit was created.
- Do not add a new CLI, web app, tender connector, crawler, or new adapter in this plan.
- Do not remove `extractor_registry`; it is the SDK extension point for downstream users.
- Keep generated artifact output behavior because SDK consumers need persisted `document.json`, `document.md`, `profile.json`, `quality.json`, and `run.json`.
- Keep `PsyduckTable` schema even if no default table extractor exists; custom extractors can still return tables.
