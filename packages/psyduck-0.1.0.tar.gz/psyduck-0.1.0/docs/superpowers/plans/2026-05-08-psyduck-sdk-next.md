# Psyduck SDK Next Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Improve Psyduck as a Python SDK by adding result loading, SDK-level option handling, recover actions, stronger table/docling behavior, and page preview/assets support without expanding the CLI.

**Architecture:** Keep `Psyduck.process()` as the primary SDK entrypoint and add SDK-only APIs around persisted run results and fallback execution. Keep adapters isolated behind `ExtractorOutput`, preserve canonical schemas, and make quality evaluation goal-aware so agents can trust `PsyduckResult` without knowing parser details.

**Tech Stack:** Python 3.11+, Pydantic, PyMuPDF, pytest, Ruff, optional Docling/Camelot/pdfplumber extras.

---

## Scope

This plan is explicitly **SDK-first**. Do not add new CLI commands or CLI options in this phase. Existing CLI tests may be updated only if SDK model changes require keeping current CLI behavior working.

Deliver working, testable increments:

1. `Psyduck.load_result(output_dir)`
2. SDK option semantics for `pages`, `tables`, `ocr`, `mode`, and `return_content`
3. `Psyduck.recover()` for table reruns and OCR placeholder actions
4. Better result/quality metadata for table and optional dependency states
5. Page preview rendering and image asset extraction using PyMuPDF
6. Integration-test boundaries for real optional extras, skipped when extras are absent

---

## File Structure

- Modify: `src/psyduck/core.py` — SDK orchestration, `load_result()`, `recover()`, option plumbing.
- Modify: `src/psyduck/schema.py` — add run metadata, output paths model if useful, quality helper methods.
- Modify: `src/psyduck/storage.py` — result file discovery and loading helpers.
- Modify: `src/psyduck/profile.py` — optional page-scoped profiling support.
- Modify: `src/psyduck/planner.py` — stricter SDK option semantics.
- Modify: `src/psyduck/quality.py` — goal/table/page-aware warnings and suggested actions.
- Modify: `src/psyduck/extractors/pymupdf.py` — page preview rendering and image asset extraction helpers.
- Modify: `src/psyduck/extractors/camelot.py` — table method selection support.
- Modify: `src/psyduck/extractors/pdfplumber.py` — table fallback consistency.
- Modify: `src/psyduck/extractors/ocr.py` — structured placeholder output for recover.
- Create: `tests/test_load_result.py`
- Create: `tests/test_recover.py`
- Create: `tests/test_sdk_options.py`
- Create: `tests/test_assets.py`
- Create: `tests/test_optional_integrations.py`
- Modify: existing tests as needed to preserve current behavior.

---

## Chunk 1: Persisted Results and SDK Loading

### Task 1: Add `load_result()` for Existing Runs

**Files:**
- Modify: `src/psyduck/core.py`
- Modify: `src/psyduck/storage.py`
- Test: `tests/test_load_result.py`

- [ ] **Step 1: Write failing tests**

```python
from pathlib import Path

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_text_pdf


def test_load_result_restores_profile_quality_document_and_outputs(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    created = Psyduck().process(
        pdf_path,
        goal="summary",
        output_dir=tmp_path / "out",
        return_content=False,
    )

    loaded = Psyduck().load_result(created.output_dir)

    assert loaded.run_id == created.run_id
    assert loaded.profile.page_count == 1
    assert loaded.quality.score == created.quality.score
    assert loaded.document is not None
    assert loaded.document.blocks
    assert loaded.outputs["markdown"].endswith("document.md")


def test_load_result_can_omit_document_content(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    created = Psyduck().process(pdf_path, output_dir=tmp_path / "out")

    loaded = Psyduck().load_result(created.output_dir, return_content=False)

    assert loaded.document is None
    assert loaded.outputs["json"].endswith("document.json")
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_load_result.py -v`

Expected: FAIL with `NotImplementedError`.

- [ ] **Step 3: Implement storage loading helpers**

Add to `src/psyduck/storage.py`:

```python
def read_json(path: str | Path) -> Any:
    source = Path(path)
    return json.loads(source.read_text(encoding="utf-8"))


def discover_outputs(output_dir: str | Path) -> dict[str, str]:
    root = Path(output_dir)
    outputs = {
        "markdown": root / "document.md",
        "json": root / "document.json",
        "quality": root / "quality.json",
        "profile": root / "profile.json",
        "run": root / "run.json",
        "tables_dir": root / "tables",
        "assets_dir": root / "assets",
        "pages_dir": root / "pages",
    }
    return {key: str(path) for key, path in outputs.items() if path.exists()}
```

- [ ] **Step 4: Implement `Psyduck.load_result()`**

Modify `src/psyduck/core.py`:

```python
from psyduck.schema import PsyduckDocument, PsyduckProfile, PsyduckQualityReport
from psyduck.storage import discover_outputs, read_json


def load_result(
    self,
    output_dir: str | Path,
    *,
    return_content: bool = True,
) -> PsyduckResult:
    root = Path(output_dir)
    outputs = discover_outputs(root)
    run_payload = read_json(root / "run.json")
    profile = PsyduckProfile.model_validate(read_json(root / "profile.json"))
    quality = PsyduckQualityReport.model_validate(read_json(root / "quality.json"))
    document = None
    if return_content:
        document = PsyduckDocument.model_validate(read_json(root / "document.json"))

    return PsyduckResult(
        run_id=run_payload["run_id"],
        status="needs_review" if quality.needs_review else "completed",
        output_dir=str(root),
        document=document,
        profile=profile,
        quality=quality,
        outputs=outputs,
    )
```

- [ ] **Step 5: Run tests**

Run: `.venv/bin/pytest tests/test_load_result.py -v`

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/psyduck/core.py src/psyduck/storage.py tests/test_load_result.py
git commit -m "feat: load persisted psyduck results"
```

### Task 2: Make Run Metadata Self-Sufficient

**Files:**
- Modify: `src/psyduck/core.py`
- Test: `tests/test_load_result.py`

- [ ] **Step 1: Write failing test**

```python
from psyduck.storage import read_json


def test_run_metadata_records_source_goal_mode_and_pages(tmp_path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)

    result = Psyduck().process(
        pdf_path,
        goal="qa",
        mode="high_quality",
        pages=[1],
        output_dir=tmp_path / "out",
    )

    run = read_json(Path(result.output_dir) / "run.json")

    assert run["source_path"] == str(pdf_path)
    assert run["config"]["goal"] == "qa"
    assert run["config"]["mode"] == "high_quality"
    assert run["pages"] == [1]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/pytest tests/test_load_result.py::test_run_metadata_records_source_goal_mode_and_pages -v`

Expected: FAIL because `run.json` lacks fields.

- [ ] **Step 3: Persist richer metadata**

Modify `src/psyduck/core.py` where `run.json` is written:

```python
write_json(
    run.path / "run.json",
    {
        "run_id": run.run_id,
        "source_path": str(file_path),
        "config": config.model_dump(),
        "pages": pages,
        "plan": plan.model_dump(),
        "outputs": outputs,
    },
)
```

- [ ] **Step 4: Run test**

Run: `.venv/bin/pytest tests/test_load_result.py::test_run_metadata_records_source_goal_mode_and_pages -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/psyduck/core.py tests/test_load_result.py
git commit -m "feat: persist psyduck run metadata"
```

---

## Chunk 2: SDK Option Semantics

### Task 3: Make Page-Scoped Processing Explicit

**Files:**
- Modify: `src/psyduck/profile.py`
- Modify: `src/psyduck/core.py`
- Modify: `src/psyduck/quality.py`
- Test: `tests/test_sdk_options.py`

- [ ] **Step 1: Write failing tests**

```python
from pathlib import Path

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_text_pdf


def test_pages_option_limits_quality_and_document_blocks_without_redefining_page_count(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=3)

    result = Psyduck().process(
        pdf_path,
        pages=[2],
        tables="off",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert result.profile.page_count == 3
    assert result.profile.selected_pages == [2]
    assert result.profile.processed_page_count == 1
    assert {block.page for block in result.document.blocks} == {2}
    assert not any(w.code == "EMPTY_PAGE" and w.page in {1, 3} for w in result.quality.warnings)


def test_pages_option_rejects_invalid_page_numbers(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    try:
        Psyduck().process(pdf_path, pages=[0], output_dir=tmp_path / "out")
    except ValueError as exc:
        assert "pages must be 1-based" in str(exc)
    else:
        raise AssertionError("expected ValueError")
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_sdk_options.py -v`

Expected: FAIL because selected page metadata does not exist and invalid pages are not rejected.

- [ ] **Step 3: Implement page-aware profiling**

Modify `src/psyduck/profile.py`:

```python
def profile_pdf(file_path: str | Path, pages: list[int] | None = None) -> PsyduckProfile:
    doc = fitz.open(str(file_path))
    selected_pages = _validate_pages(doc, pages)
    ...
    for index in selected_pages:
        page = doc[index - 1]
        ...
    page_count = len(doc)
```

Add helper:

```python
def _validate_pages(doc, pages: list[int] | None) -> list[int]:
    if pages is None:
        return list(range(1, len(doc) + 1))
    if any(page < 1 for page in pages):
        raise ValueError("pages must be 1-based positive integers")
    if any(page > len(doc) for page in pages):
        raise ValueError(f"pages cannot exceed PDF page count {len(doc)}")
    return list(dict.fromkeys(pages))
```

Add fields to `PsyduckProfile` in `src/psyduck/schema.py`:

```python
selected_pages: list[int] | None = None
processed_page_count: int | None = None
```

Return profile metadata without redefining `page_count`:

```python
return PsyduckProfile(
    page_count=len(doc),
    selected_pages=selected_pages if pages is not None else None,
    processed_page_count=len(selected_pages),
    ...
)
```

- [ ] **Step 4: Pass pages into profiling and quality**

Modify `src/psyduck/core.py`:

```python
profile = profile_pdf(file_path, pages=pages)
...
quality = evaluate_quality(
    document,
    profile,
    extractor_warnings=extractor_warnings,
    goal=goal,
    evaluated_pages=pages,
)
```

- [ ] **Step 5: Run tests**

Run: `.venv/bin/pytest tests/test_sdk_options.py -v`

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/psyduck/schema.py src/psyduck/profile.py src/psyduck/core.py tests/test_sdk_options.py
git commit -m "feat: make page scoped processing explicit"
```

### Task 4: Define SDK Semantics for `tables` and `ocr`

**Files:**
- Modify: `src/psyduck/planner.py`
- Modify: `src/psyduck/quality.py`
- Test: `tests/test_sdk_options.py`

- [ ] **Step 1: Write failing tests**

```python
from psyduck.config import PsyduckConfig
from psyduck.planner import plan_extraction
from psyduck.schema import PsyduckProfile


def test_tables_off_suppresses_table_extractors_even_when_table_pages_detected():
    profile = PsyduckProfile(page_count=1, has_text_layer=True, likely_table_pages=[1])

    plan = plan_extraction(profile, PsyduckConfig(goal="rag", tables="off"))

    assert "camelot" not in plan.extractors
    assert "pdfplumber" not in plan.extractors


def test_ocr_off_suppresses_ocr_even_for_scanned_profile():
    profile = PsyduckProfile(page_count=1, has_text_layer=False, scan_ratio=1.0)

    plan = plan_extraction(profile, PsyduckConfig(goal="qa", ocr="off"))

    assert "ocr" not in plan.extractors
```

- [ ] **Step 2: Run tests to verify current behavior**

Run: `.venv/bin/pytest tests/test_sdk_options.py::test_tables_off_suppresses_table_extractors_even_when_table_pages_detected tests/test_sdk_options.py::test_ocr_off_suppresses_ocr_even_for_scanned_profile -v`

Expected: first should PASS if current behavior is correct; second should PASS if current behavior is correct. If either fails, implement the missing branch below.

- [ ] **Step 3: Tighten planner only if tests fail**

Keep planner logic explicit:

```python
wants_tables = config.tables == "force" or (
    config.tables == "auto" and (config.goal == "tables" or bool(profile.likely_table_pages))
)
...
if config.ocr == "force" or (config.ocr == "auto" and profile.scan_ratio > 0.3):
    extractors.append("ocr")
```

- [ ] **Step 4: Run tests**

Run: `.venv/bin/pytest tests/test_sdk_options.py -v`

Expected: PASS.

- [ ] **Step 5: Commit if production code changed**

```bash
git add src/psyduck/planner.py tests/test_sdk_options.py
git commit -m "test: document sdk option semantics"
```

---

## Chunk 3: SDK Recover Actions

### Task 5: Implement Recover for Table Reruns

**Files:**
- Modify: `src/psyduck/core.py`
- Modify: `src/psyduck/storage.py`
- Test: `tests/test_recover.py`

- [ ] **Step 1: Write failing test**

```python
from pathlib import Path

from psyduck import Psyduck
from psyduck.extractors.base import ExtractorOutput
from psyduck.schema import PsyduckBlock, PsyduckTable
from tests.fixtures.make_pdfs import make_text_pdf


class FakeTableExtractor:
    def extract(self, file_path, pages=None):
        return ExtractorOutput(
            source="camelot",
            tables=[
                PsyduckTable(
                    id="recovered_table",
                    page=pages[0],
                    headers=[["A"]],
                    rows=[["1"]],
                    source="camelot:stream",
                    confidence=0.9,
                )
            ],
        )


class FakeTextExtractor:
    def extract(self, file_path, pages=None):
        return ExtractorOutput(
            source="pymupdf",
            blocks=[
                PsyduckBlock(
                    id="p1_b1",
                    type="paragraph",
                    page=1,
                    text="text",
                    source="pymupdf",
                    confidence=1,
                )
            ],
        )


class FailingTableExtractor:
    def extract(self, file_path, pages=None):
        raise RuntimeError("table extractor unavailable")


def test_recover_reruns_table_extraction_and_updates_result(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    duck = Psyduck(
        extractor_registry={
            "pymupdf": lambda: FakeTextExtractor(),
            "camelot": lambda: FailingTableExtractor(),
            "pdfplumber": lambda: FailingTableExtractor(),
        }
    )
    initial = duck.process(
        pdf_path,
        goal="tables",
        tables="force",
        output_dir=tmp_path / "out",
        return_content=True,
    )
    assert initial.status == "needs_review"

    recovered = Psyduck(
        extractor_registry={
            "pymupdf": lambda: FakeTextExtractor(),
            "camelot": lambda: FakeTableExtractor(),
        }
    ).recover(
        initial.output_dir,
        actions=[{"type": "rerun_tables", "pages": [1], "method": "stream"}],
    )

    assert recovered.document.tables[0].id == "recovered_table"
    assert recovered.status == "completed"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/pytest tests/test_recover.py -v`

Expected: FAIL with `NotImplementedError`.

- [ ] **Step 3: Implement recover orchestration**

Implement in `src/psyduck/core.py`:

```python
def recover(self, run_id: str | Path, actions: list[dict] | None = None) -> PsyduckResult:
    loaded = self.load_result(run_id, return_content=True)
    root = Path(loaded.output_dir)
    run_payload = read_json(root / "run.json")
    source_path = run_payload["source_path"]
    actions = actions or loaded.quality.suggested_actions

    extra_outputs = []
    for action in actions:
        if action["type"] == "rerun_tables":
            method = action.get("method", "lattice")
            pages = action.get("pages")
            extra_outputs.extend(self._run_table_recovery(source_path, pages, method))
        elif action["type"] == "run_ocr":
            extra_outputs.extend(self._run_extractors(source_path, ["ocr"], pages=action.get("pages")))

    base_outputs = []
    if loaded.document:
        base_outputs.append(
            ExtractorOutput(
                source="loaded",
                blocks=loaded.document.blocks,
                tables=loaded.document.tables,
            )
        )
    document = normalize_outputs(source_path, loaded.profile, [*base_outputs, *extra_outputs])
    outputs = export_document(document, root)
    extractor_warnings = [
        warning
        for output in extra_outputs
        for warning in output.warnings
    ]
    quality = evaluate_quality(
        document,
        loaded.profile,
        extractor_warnings=extractor_warnings,
        goal=run_payload["config"]["goal"],
        evaluated_pages=run_payload.get("pages"),
    )
    write_json(root / "document.json", document.model_dump())
    write_json(root / "quality.json", quality.model_dump())

    return self.load_result(root, return_content=True)
```

Add helper:

```python
def _run_table_recovery(self, file_path: str | Path, pages: list[int] | None, method: str) -> list[ExtractorOutput]:
    # MVP: method is metadata only until Camelot supports method selection.
    return self._run_extractors(file_path, ["camelot"], pages=pages)
```

- [ ] **Step 4: Run test**

Run: `.venv/bin/pytest tests/test_recover.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/psyduck/core.py tests/test_recover.py
git commit -m "feat: recover table extraction results"
```

### Task 6: Add Recover Behavior for OCR Placeholder

**Files:**
- Modify: `src/psyduck/core.py`
- Modify: `src/psyduck/extractors/ocr.py`
- Test: `tests/test_recover.py`

- [ ] **Step 1: Write failing test**

```python
def test_recover_ocr_placeholder_keeps_warning_visible(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)
    result = Psyduck().process(pdf_path, output_dir=tmp_path / "out")

    recovered = Psyduck().recover(
        result.output_dir,
        actions=[{"type": "run_ocr", "pages": [1]}],
    )

    assert any(w.code == "OCR_UNIMPLEMENTED" for w in recovered.quality.warnings)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/pytest tests/test_recover.py::test_recover_ocr_placeholder_keeps_warning_visible -v`

Expected: FAIL because OCR recover currently raises generic unavailable warning or recover is missing.

- [ ] **Step 3: Make OCR placeholder return structured output**

Modify `src/psyduck/extractors/ocr.py`:

```python
from psyduck.schema import PsyduckWarning


class OcrExtractor:
    source = "ocr"

    def extract(...):
        return ExtractorOutput(
            source=self.source,
            warnings=[
                PsyduckWarning(
                    code="OCR_UNIMPLEMENTED",
                    severity="warning",
                    message="OCR recovery is not implemented in this SDK version.",
                    suggested_action={"type": "install_ocr_extra"},
                )
            ],
        )
```

- [ ] **Step 4: Run test**

Run: `.venv/bin/pytest tests/test_recover.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/psyduck/core.py src/psyduck/extractors/ocr.py tests/test_recover.py
git commit -m "feat: expose ocr recovery placeholder"
```

---

## Chunk 4: Assets and Page Previews

### Task 7: Render Page Previews in SDK High Quality Mode

**Files:**
- Modify: `src/psyduck/extractors/pymupdf.py`
- Modify: `src/psyduck/core.py`
- Test: `tests/test_assets.py`

- [ ] **Step 1: Write failing test**

```python
from pathlib import Path

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_text_pdf


def test_high_quality_mode_renders_page_previews(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=2)

    result = Psyduck().process(
        pdf_path,
        mode="high_quality",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    pages_dir = Path(result.outputs["pages_dir"])
    assert (pages_dir / "page_001.png").exists()
    assert (pages_dir / "page_002.png").exists()
    assert any(asset["type"] == "page_preview" for asset in result.document.assets)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/pytest tests/test_assets.py::test_high_quality_mode_renders_page_previews -v`

Expected: FAIL because page previews are not rendered.

- [ ] **Step 3: Add preview renderer**

Add to `src/psyduck/extractors/pymupdf.py`:

```python
def render_page_previews(
    file_path: str | Path,
    output_dir: str | Path,
    pages: list[int] | None = None,
    zoom: float = 1.5,
) -> list[dict]:
    doc = fitz.open(str(file_path))
    selected = pages or list(range(1, len(doc) + 1))
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    assets = []
    matrix = fitz.Matrix(zoom, zoom)
    for page_number in selected:
        pix = doc[page_number - 1].get_pixmap(matrix=matrix)
        path = root / f"page_{page_number:03d}.png"
        pix.save(str(path))
        assets.append({"type": "page_preview", "page": page_number, "path": str(path)})
    return assets
```

- [ ] **Step 4: Wire high quality mode**

Modify `src/psyduck/core.py` after normalization:

```python
if mode == "high_quality":
    document.assets.extend(render_page_previews(file_path, run.pages_dir, pages=pages))
```

Add `"pages_dir"` to the result output merge in `src/psyduck/core.py`:

```python
"pages_dir": str(run.pages_dir)
```

- [ ] **Step 5: Run test**

Run: `.venv/bin/pytest tests/test_assets.py::test_high_quality_mode_renders_page_previews -v`

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/psyduck/core.py src/psyduck/extractors/pymupdf.py tests/test_assets.py
git commit -m "feat: render sdk page previews"
```

### Task 8: Extract Embedded Images as Assets

**Files:**
- Modify: `src/psyduck/extractors/pymupdf.py`
- Modify: `src/psyduck/core.py`
- Test: `tests/test_assets.py`

- [ ] **Step 1: Write failing test**

```python
def test_archive_goal_extracts_image_assets(tmp_path: Path):
    pdf_path = make_pdf_with_image(tmp_path / "image.pdf")

    result = Psyduck().process(
        pdf_path,
        goal="archive",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert any(asset["type"] == "image" for asset in result.document.assets)
```

Add `make_pdf_with_image()` to `tests/fixtures/make_pdfs.py` using ReportLab and Pillow.

- [ ] **Step 2: Run test to verify it fails**

Run: `.venv/bin/pytest tests/test_assets.py::test_archive_goal_extracts_image_assets -v`

Expected: FAIL because images are not extracted.

- [ ] **Step 3: Implement image extraction**

Add to `src/psyduck/extractors/pymupdf.py`:

```python
def extract_images(
    file_path: str | Path,
    output_dir: str | Path,
    pages: list[int] | None = None,
) -> list[dict]:
    doc = fitz.open(str(file_path))
    selected = pages or list(range(1, len(doc) + 1))
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    assets = []
    for page_number in selected:
        page = doc[page_number - 1]
        for index, image in enumerate(page.get_images(full=True), start=1):
            xref = image[0]
            extracted = doc.extract_image(xref)
            ext = extracted.get("ext", "png")
            path = root / f"page_{page_number:03d}_image_{index:03d}.{ext}"
            path.write_bytes(extracted["image"])
            assets.append({"type": "image", "page": page_number, "path": str(path)})
    return assets
```

- [ ] **Step 4: Wire archive mode**

Modify `src/psyduck/core.py`:

```python
if goal == "archive":
    document.assets.extend(extract_images(file_path, run.assets_dir, pages=pages))
```

- [ ] **Step 5: Run test**

Run: `.venv/bin/pytest tests/test_assets.py -v`

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/psyduck/core.py src/psyduck/extractors/pymupdf.py tests/fixtures/make_pdfs.py tests/test_assets.py
git commit -m "feat: extract image assets"
```

---

## Chunk 5: Optional Integration Boundaries

### Task 9: Add Skipped Integration Tests for Optional Table Extras

**Files:**
- Create: `tests/test_optional_integrations.py`
- Modify: `tests/fixtures/make_pdfs.py`

- [ ] **Step 1: Write skipped integration tests**

```python
import importlib.util
import os
from pathlib import Path

import pytest

from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_ruled_table_pdf


requires_tables = pytest.mark.skipif(
    os.environ.get("PSYDUCK_RUN_OPTIONAL_INTEGRATIONS") != "1"
    or importlib.util.find_spec("camelot") is None,
    reason="set PSYDUCK_RUN_OPTIONAL_INTEGRATIONS=1 and install camelot to run",
)


@requires_tables
def test_tables_extra_extracts_real_table_pdf(tmp_path: Path):
    pdf_path = make_ruled_table_pdf(tmp_path / "table.pdf")

    try:
        result = Psyduck().process(
            pdf_path,
            goal="tables",
            tables="force",
            output_dir=tmp_path / "out",
            return_content=True,
        )
    except Exception as exc:
        pytest.skip(f"camelot runtime dependency unavailable: {exc}")

    assert result.document.tables
    assert result.is_usable_for("tables")
```

- [ ] **Step 2: Add fixture**

Add `make_ruled_table_pdf()` to `tests/fixtures/make_pdfs.py`. Use ReportLab to draw a simple bordered table with line segments, so Camelot lattice has a fair chance to parse it.

- [ ] **Step 3: Run test**

Run: `.venv/bin/pytest tests/test_optional_integrations.py -v`

Expected: SKIPPED unless `PSYDUCK_RUN_OPTIONAL_INTEGRATIONS=1` and Camelot runtime dependencies are available; PASS when enabled and dependencies are present.

- [ ] **Step 4: Commit**

```bash
git add tests/fixtures/make_pdfs.py tests/test_optional_integrations.py
git commit -m "test: add optional table integration boundary"
```

### Task 10: Add Skipped Integration Tests for Docling

**Files:**
- Modify: `tests/test_optional_integrations.py`

- [ ] **Step 1: Add skipped Docling test**

```python
requires_docling = pytest.mark.skipif(
    importlib.util.find_spec("docling") is None,
    reason="docling is not installed",
)


@requires_docling
def test_docling_extra_produces_primary_markdown_block(tmp_path: Path):
    pdf_path = make_text_pdf(tmp_path / "sample.pdf", pages=1)

    result = Psyduck().process(
        pdf_path,
        goal="rag",
        output_dir=tmp_path / "out",
        return_content=True,
    )

    assert any(block.source == "docling" for block in result.document.blocks)
```

- [ ] **Step 2: Run test**

Run: `.venv/bin/pytest tests/test_optional_integrations.py -v`

Expected: SKIPPED when Docling is absent; PASS when installed.

- [ ] **Step 3: Commit**

```bash
git add tests/test_optional_integrations.py
git commit -m "test: add optional docling integration boundary"
```

---

## Final Quality Gate

### Task 11: Run Full Verification

**Files:**
- Modify only files touched by previous tasks if fixes are needed.

- [ ] **Step 1: Run formatter**

Run: `.venv/bin/ruff format .`

Expected: command completes.

- [ ] **Step 2: Run format check**

Run: `.venv/bin/ruff format --check .`

Expected: PASS.

- [ ] **Step 3: Run lint**

Run: `.venv/bin/ruff check .`

Expected: PASS with zero warnings.

- [ ] **Step 4: Run tests**

Run: `.venv/bin/pytest -v`

Expected: PASS. Optional integration tests may be SKIPPED when optional dependencies are absent.

- [ ] **Step 5: Run SDK smoke test**

Run:

```bash
.venv/bin/python - <<'PY'
from pathlib import Path
from psyduck import Psyduck
from tests.fixtures.make_pdfs import make_text_pdf

pdf = make_text_pdf(Path("/tmp/psyduck-sdk-next-smoke.pdf"), pages=2)
result = Psyduck().process(pdf, goal="rag", output_dir="/tmp/psyduck-sdk-next-smoke", return_content=True)
loaded = Psyduck().load_result(result.output_dir)
print(result.status)
print(len(result.document.blocks))
print(loaded.profile.page_count)
PY
```

Expected: prints `completed`, a positive block count, and `2`.

- [ ] **Step 6: Commit final fixes if needed**

```bash
git add <specific changed files>
git commit -m "fix: satisfy sdk next quality gate"
```

Do not use `git add -A` or `git add .`.
