# Psyduck API

Psyduck is a Python SDK for extracting structured content from PDFs. The default runtime uses PyMuPDF only.

## `Psyduck`

```python
from psyduck import Psyduck

duck = Psyduck()
```

### Constructor

```python
Psyduck(extractor_registry: dict[str, Callable[[], object]] | None = None)
```

`extractor_registry` maps extractor names to factories. If omitted, Psyduck registers one extractor:

```python
{"pymupdf": PyMuPDFExtractor}
```

## `process()`

```python
result = duck.process(
    file_path,
    goal="rag",
    mode="balanced",
    ocr="auto",
    tables="auto",
    pages=None,
    extractors=None,
    output_dir=None,
    return_content=False,
)
```

Parameters:

- `file_path`: PDF path.
- `goal`: one of `auto`, `summary`, `qa`, `rag`, `tables`, or `archive`.
- `mode`: one of `fast`, `balanced`, or `high_quality`. `high_quality` renders page preview PNG assets.
- `ocr`: one of `off`, `auto`, or `force`. `force` reports `OCR_ADAPTER_NEEDED` unless a caller-provided extractor handles OCR.
- `tables`: one of `off`, `auto`, or `force`. `force` reports `TABLE_ADAPTER_NEEDED` unless tables are returned.
- `pages`: optional 1-based page list.
- `extractors`: optional list of registered extractor names to run. Defaults to the planner output, currently `["pymupdf"]`.
- `output_dir`: optional output root. Psyduck creates a unique run directory inside it.
- `return_content`: when false, omits the full `document` from the immediate result.

Returns `PsyduckResult`.

## `load_result()`

```python
result = duck.load_result(output_dir, return_content=True)
```

Reloads a previous run from `run.json`, `profile.json`, `quality.json`, and optionally `document.json`.

## `recover()`

```python
result = duck.recover(output_dir)
```

Reloads a run and refreshes its quality report. This alpha release does not run bundled OCR or table recovery.

## Result Schema

`PsyduckResult` contains:

- `run_id`: unique run identifier.
- `status`: `completed`, `needs_review`, or `failed`.
- `output_dir`: run directory path.
- `document`: `PsyduckDocument` or `None`.
- `profile`: `PsyduckProfile`.
- `quality`: `PsyduckQualityReport`.
- `outputs`: artifact paths.

Use `result.is_usable_for(goal)` before trusting output for a task.

## Document Schema

`PsyduckDocument` contains:

- `document_id`
- `source_path`
- `page_count`
- `blocks`
- `tables`
- `assets`
- `metadata`

`PsyduckBlock` contains page-aware text with optional bounding boxes.

`PsyduckTable` is kept for custom table extractors. The default SDK does not create tables.

## Quality Warnings

Common warning codes:

- `EMPTY_PAGE`: no blocks found on an evaluated page.
- `OCR_NEEDED`: profile looks scan-heavy.
- `OCR_ADAPTER_NEEDED`: OCR was forced but no OCR adapter satisfied it.
- `NO_TABLES_EXTRACTED`: `goal="tables"` produced no tables.
- `TABLE_ADAPTER_NEEDED`: table extraction was forced but no table adapter satisfied it.
- `LOW_CONFIDENCE_TABLE`: custom table confidence is low.
- `MALFORMED_TABLE`: custom table rows have inconsistent widths.
- `UNKNOWN_EXTRACTOR`: requested extractor is not registered.
- `EXTRACTOR_UNAVAILABLE`: extractor reported unavailable dependencies.
- `EXTRACTOR_FAILED`: extractor crashed unexpectedly.

If `quality.needs_review` is true, downstream agents should avoid claiming complete extraction.
