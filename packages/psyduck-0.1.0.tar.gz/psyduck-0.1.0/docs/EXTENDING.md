# Extending Psyduck

Psyduck ships with one default extractor, `pymupdf`. Additional extraction behavior is supplied by callers through `extractor_registry`.

## Extractor Protocol

An extractor is any object with:

```python
def extract(self, file_path, pages=None) -> ExtractorOutput:
    ...
```

Return `ExtractorOutput` with blocks, tables, and warnings:

```python
from psyduck.extractors.base import ExtractorOutput
from psyduck.schema import PsyduckBlock, PsyduckWarning


class MyExtractor:
    def extract(self, file_path, pages=None):
        return ExtractorOutput(
            source="my_extractor",
            blocks=[
                PsyduckBlock(
                    id="my_b1",
                    type="paragraph",
                    page=1,
                    text="Extracted text",
                    source="my_extractor",
                    confidence=0.9,
                )
            ],
            warnings=[
                PsyduckWarning(
                    code="MY_EXTRACTOR_NOTE",
                    severity="info",
                    message="Custom extractor ran.",
                )
            ],
        )
```

## Running Custom Extractors

Register the default PyMuPDF extractor plus your custom extractor:

```python
from psyduck import Psyduck
from psyduck.extractors.pymupdf import PyMuPDFExtractor


duck = Psyduck(
    extractor_registry={
        "pymupdf": PyMuPDFExtractor,
        "my_extractor": lambda: MyExtractor(),
    }
)

result = duck.process(
    "report.pdf",
    extractors=["pymupdf", "my_extractor"],
    return_content=True,
)
```

`extractors=[...]` controls which registered extractors run. If omitted, Psyduck runs the planner default, currently `["pymupdf"]`.

## Custom Table Extractors

Return `PsyduckTable` objects from your extractor:

```python
from psyduck.schema import PsyduckTable

ExtractorOutput(
    source="my_table_extractor",
    tables=[
        PsyduckTable(
            id="table_1",
            page=1,
            headers=[["Metric", "Value"]],
            rows=[["Revenue", "100"]],
            source="my_table_extractor",
            confidence=0.9,
        )
    ],
)
```

When `tables="force"` is used, Psyduck expects tables to be present. If no tables are returned, quality includes `TABLE_ADAPTER_NEEDED`.

## Custom OCR Extractors

The default SDK does not include OCR. A custom OCR extractor should return text blocks for scanned pages. In this alpha release, OCR capability is not formally declared, so `ocr="force"` still produces `OCR_ADAPTER_NEEDED` unless future versions add capability signaling.

For now, prefer one of these approaches:

- Use `ocr="auto"` and run your OCR extractor explicitly with `extractors=[...]`.
- Inspect your custom extractor warnings and output in downstream code.

## Error Handling

If an extractor raises `RuntimeError`, Psyduck records `EXTRACTOR_UNAVAILABLE`.

If it raises any other exception, Psyduck records `EXTRACTOR_FAILED`.

Extractor failures do not abort the whole SDK run; they become quality warnings for the caller to inspect.
