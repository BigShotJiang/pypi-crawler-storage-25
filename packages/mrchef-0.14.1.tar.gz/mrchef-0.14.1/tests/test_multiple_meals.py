from pathlib import Path
from typing import Any, cast

import pytest
import rtoml
import tomlkit

from mrchef import lib

from .conftest import SAMPLE_REPOS, get_frozen_config, get_user_config

BUNDLE123 = SAMPLE_REPOS / "123.bundle"


def test_warmup(tmp_path):
    """Generate a kitchen and warm it up."""
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = {lib.CONFIG_VERSION}
        kitchen = "."

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.two]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.three]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals.one]
        last_update = 1776-07-04T08:47:00Z
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals.two]
        last_update = 1936-05-25T07:50:00Z
        rev = "a6cf33141a9f770967e3c132e0aa0071c3db2d43"
        [meals.three]
        last_update = 1985-10-26T01:20:00Z
        rev = "e757a53dccbb5407994f03dc419651275dc6eacf"
        """
    )
    lib.Worker(tmp_path).warmup()
    assert tmp_path.joinpath("one", "file-1.txt").read_text() == "1\n"
    assert not tmp_path.joinpath("one", "file-2.txt").exists()
    assert not tmp_path.joinpath("one", "file-3.txt").exists()
    assert tmp_path.joinpath("two", "file-1.txt").read_text() == "1\n"
    assert tmp_path.joinpath("two", "file-2.txt").read_text() == "2\n"
    assert not tmp_path.joinpath("two", "file-3.txt").exists()
    assert tmp_path.joinpath("three", "file-1.txt").read_text() == "1\n"
    assert tmp_path.joinpath("three", "file-2.txt").read_text() == "2\n"
    assert tmp_path.joinpath("three", "file-3.txt").read_text() == "3\n"


def test_double_warmup_discards_changes(tmp_path: Path):
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = 1
        kitchen = "code"

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        """
        version = 1
        [meals.one]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        """
    )
    code = tmp_path / "code"
    one = code / "one"
    thing = one / "thing"
    nothing = one / "nothing"
    # Warmup
    lib.Worker(tmp_path).warmup()
    # Manual edits
    thing.write_text("stuff")
    _git = lib.git(one)
    _git("add", "thing")
    _git("commit", "-m", "Thing & stuff")
    nothing.write_text("emptiness")
    _git("add", "nothing")
    _git("commit", "-m", "Nothing & emptiness")
    # Warmup again
    lib.Worker(tmp_path).warmup()
    # Things are frozen
    assert one.joinpath("file-1.txt").read_text() == "1\n"
    assert not one.joinpath("file-2.txt").exists()
    assert not one.joinpath("file-3.txt").exists()
    assert not thing.exists()
    assert not nothing.exists()
    assert not list(code.glob("*.patch"))


@pytest.mark.parametrize("updated_meal", ("one", "two", "three"))
def test_single_meal_update(tmp_path, updated_meal: str):
    test_warmup(tmp_path)
    expected = lib.Worker(tmp_path).config_frozen
    lib.Worker(tmp_path).update(tmp_path / updated_meal)
    # It is expected that the updated meal contains the same rev as meal "three"
    meals_dict = cast(dict[str, Any], expected.get("meals", {}))
    meal_config = cast(dict[str, Any], meals_dict.get(updated_meal, {}))
    meal_config["rev"] = "e757a53dccbb5407994f03dc419651275dc6eacf"
    if updated_meal in {"one", "two"}:
        meal_config["last_update"] = lib.now()
    assert expected == lib.Worker(tmp_path).config_frozen


def test_update_preserves_last_update_when_rev_unchanged(tmp_path: Path):
    """Test that last_update is preserved when rev doesn't change."""
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = {lib.CONFIG_VERSION}
        kitchen = "."

        [meals.meal_a]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )

    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals.meal_a]
        last_update = 2020-01-01T00:00:00+00:00
        rev = "e757a53dccbb5407994f03dc419651275dc6eacf"
        """
    )

    lib.Worker(tmp_path).warmup()
    lib.Worker(tmp_path).update(oldest=1)

    freezer = lib.Worker(tmp_path).config_frozen
    meals_dict = cast(dict[str, Any], freezer.get("meals", {}))
    meal_config = cast(dict[str, Any], meals_dict.get("meal_a", {}))

    assert meal_config.get("rev") == "e757a53dccbb5407994f03dc419651275dc6eacf"
    assert meal_config.get("last_update") == lib.datetime.fromisoformat(
        "2020-01-01T00:00:00+00:00"
    )


@pytest.mark.parametrize("oldest", (0, 1, 2, 3))
def test_oldest_meal_update(tmp_path, oldest: int):
    test_warmup(tmp_path)
    lib.Worker(tmp_path).update(oldest=oldest)
    must_update = [
        {"one", "two", "three"},
        {"one"},
        {"one", "two"},
        {"one", "two", "three"},
    ][oldest]
    must_stay = {"one", "two", "three"} - must_update
    freezer = lib.Worker(tmp_path).config_frozen
    meals_dict = cast(dict[str, Any], freezer.get("meals", {}))
    for meal in must_update:
        meal_config = cast(dict[str, Any], meals_dict.get(meal, {}))
        assert meal_config.get("rev") == "e757a53dccbb5407994f03dc419651275dc6eacf"
        last_update = meal_config.get("last_update")
        if last_update is not None:
            assert last_update <= lib.now()
    for meal in must_stay:
        meal_config = cast(dict[str, Any], meals_dict.get(meal, {}))
        last_update = meal_config.get("last_update")
        if last_update is not None:
            assert last_update < lib.now()
        if meal != "three":
            assert meal_config.get("rev") != "e757a53dccbb5407994f03dc419651275dc6eacf"


def test_update_oldest_2_continues_when_first_unchanged(tmp_path: Path):
    """Test that oldest=N continues updating until N meals are actually changed.

    This test verifies the behavior when using oldest=2:
    - Setup: 3 meals where the oldest (one) is already at the latest revision,
      and the other two (two, three) need updates
    - Expected: mrchef should update meals "two" and "three", not just "two"
    - Why: When the oldest meal doesn't need updating, mrchef should continue
      with the next oldest meals until it has updated the requested number (2)
    """
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = {lib.CONFIG_VERSION}
        kitchen = "."

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.two]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.three]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals.one]
        last_update = 1776-07-04T08:47:00Z
        rev = "e757a53dccbb5407994f03dc419651275dc6eacf"
        [meals.two]
        last_update = 1936-05-25T07:50:00Z
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals.three]
        last_update = 1985-10-26T01:20:00Z
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        """
    )
    lib.Worker(tmp_path).warmup()
    lib.Worker(tmp_path).update(oldest=2)

    freezer = lib.Worker(tmp_path).config_frozen
    meals_dict = cast(dict[str, Any], freezer.get("meals", {}))

    one_config = cast(dict[str, Any], meals_dict.get("one", {}))
    two_config = cast(dict[str, Any], meals_dict.get("two", {}))
    three_config = cast(dict[str, Any], meals_dict.get("three", {}))

    # Meal "one" was already up-to-date, so it should remain unchanged
    assert one_config.get("rev") == "e757a53dccbb5407994f03dc419651275dc6eacf"
    one_last_update = one_config.get("last_update")
    assert one_last_update == lib.datetime.fromisoformat("1776-07-04T08:47:00+00:00")

    # Meal "two" should be updated (1st actual update)
    assert two_config.get("rev") == "e757a53dccbb5407994f03dc419651275dc6eacf"
    two_last_update = two_config.get("last_update")
    assert two_last_update is not None and two_last_update <= lib.now()

    # Meal "three" should also be updated (2nd actual update) to reach oldest=2
    assert three_config.get("rev") == "e757a53dccbb5407994f03dc419651275dc6eacf"
    three_last_update = three_config.get("last_update")
    assert three_last_update is not None and three_last_update <= lib.now()


def test_subfolder_add(tmp_path: Path):
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = 1
        kitchen = "kitchen"

        [meals."1/123"]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        """
        version = 1
        [meals."1/123"]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        """
    )
    lib.Worker(tmp_path).warmup()
    lib.Worker(tmp_path).meal_add(
        tmp_path / "kitchen" / "2" / "123", str(BUNDLE123), "main"
    )
    worker = lib.Worker(tmp_path)
    user_meals = cast(dict[str, Any], worker.config_user.get("meals", {}))
    meal_1_123 = cast(dict[str, Any], user_meals.get("1/123", {}))
    meal_2_123 = cast(dict[str, Any], user_meals.get("2/123", {}))
    assert meal_1_123.get("url") == str(BUNDLE123)
    assert meal_1_123.get("branch") == "main"
    assert meal_2_123.get("url") == str(BUNDLE123)
    assert meal_2_123.get("branch") == "main"
    frozen_meals = cast(dict[str, Any], worker.config_frozen.get("meals", {}))
    frozen_1_123 = cast(dict[str, Any], frozen_meals.get("1/123", {}))
    frozen_2_123 = cast(dict[str, Any], frozen_meals.get("2/123", {}))
    assert frozen_1_123.get("rev") == "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
    assert frozen_2_123.get("rev") == "e757a53dccbb5407994f03dc419651275dc6eacf"


def test_similar_patches(tmp_path: Path):
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = 1
        kitchen = "."

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.two]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals.one]
        last_update = 1776-07-04T08:47:00Z
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals.two]
        last_update = 1936-05-25T07:50:00Z
        rev = "a6cf33141a9f770967e3c132e0aa0071c3db2d43"
        """
    )
    lib.Worker(tmp_path).warmup()
    # Make the same change in both meals
    with tmp_path.joinpath("one", "file-1.txt").open("a") as fd:
        fd.write("patched\n")
    with tmp_path.joinpath("two", "file-1.txt").open("a") as fd:
        fd.write("patched\n")
    # Commit the changes
    lib.git(tmp_path / "one")("commit", "-am", "Patched")
    lib.git(tmp_path / "two")("commit", "-am", "Patched")
    # Freeze the changes
    lib.Worker(tmp_path).freeze()
    # Check that both patches are created and frozen
    assert tmp_path.joinpath("mrchef-000.patch").exists()
    assert tmp_path.joinpath("mrchef-001.patch").exists()
    user1 = get_user_config(tmp_path)
    # This is a weird way to check that each meal gets one patch, but the order
    # is not deterministic
    valid_spices = [["mrchef-000.patch"], ["mrchef-001.patch"]]
    valid_spices.remove(user1["meals"]["one"]["spices"])
    valid_spices.remove(user1["meals"]["two"]["spices"])
    assert not valid_spices
    freezer1 = get_frozen_config(tmp_path)
    # Both spices have the same ID, but are for different meals, so they are
    # stored separately
    assert (
        lib.git_get_patch_ids_map(freezer1["spices"]["mrchef-000.patch"]).keys()
        == lib.git_get_patch_ids_map(freezer1["spices"]["mrchef-001.patch"]).keys()
    )
    assert (
        freezer1["spices"]["mrchef-000.patch"] != freezer1["spices"]["mrchef-001.patch"]
    )
    # Freezer entries are always sorted for deterministic output
    assert list(freezer1["meals"].keys()) == sorted(freezer1["meals"].keys())
    assert list(freezer1["spices"].keys()) == sorted(freezer1["spices"].keys())
    # Freezing again changes nothing
    lib.Worker(tmp_path).freeze()
    user2 = get_user_config(tmp_path)
    assert user1 == user2
    freezer2 = get_frozen_config(tmp_path)
    assert freezer1 == freezer2


def test_warmup_warns_untracked_meals(caplog, tmp_path: Path):
    """When there are extra meals in the kitchen not in config, warmup warns about them."""
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = {lib.CONFIG_VERSION}
        kitchen = "."

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.two]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals.one]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals.two]
        rev = "a6cf33141a9f770967e3c132e0aa0071c3db2d43"
        """
    )
    lib.Worker(tmp_path).warmup()
    # Remove meal two from the config, leaving it in the kitchen as untracked
    config = rtoml.load(tmp_path.joinpath(lib.CONFIG_FILE))
    del config["meals"]["two"]
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(tomlkit.dumps(config))
    caplog.clear()
    lib.Worker(tmp_path).warmup()
    warnings = [r for r in caplog.records if r.levelname == "WARNING"]
    assert any("two" in r.message and "--prune" in r.message for r in warnings)
    # The untracked meal should still exist; only --prune removes it
    assert (tmp_path / "two").exists()


def test_warmup_prune_removes_untracked_meals(tmp_path: Path):
    """When prune=True is passed, untracked meals are removed from disk."""
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = {lib.CONFIG_VERSION}
        kitchen = "."

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.two]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals.one]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals.two]
        rev = "a6cf33141a9f770967e3c132e0aa0071c3db2d43"
        """
    )
    lib.Worker(tmp_path).warmup()
    # Remove meal two from the config, leaving it in the kitchen as untracked
    config = rtoml.load(tmp_path.joinpath(lib.CONFIG_FILE))
    del config["meals"]["two"]
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(tomlkit.dumps(config))
    two = tmp_path / "two"
    lib.Worker(tmp_path).warmup(prune=True)
    assert not two.exists()
    assert (tmp_path / "one").exists()


@pytest.mark.filterwarnings("ignore:Freezer file not found.:UserWarning")
def test_warmup_editing_config_manually(tmp_path: Path):
    # User creates a config
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = 1
        kitchen = "code"

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    lib.Worker(tmp_path).warmup()
    lib.Worker(tmp_path).freeze()
    assert tmp_path.joinpath("code", "one", "file-3.txt").read_text() == "3\n"
    assert "one" in get_frozen_config(tmp_path)["meals"]
    # User adds meal two manually
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = 1
        kitchen = "code"

        [meals.one]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.two]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    lib.Worker(tmp_path).warmup()
    lib.Worker(tmp_path).freeze()
    assert tmp_path.joinpath("code", "two", "file-3.txt").read_text() == "3\n"
    assert tmp_path.joinpath(lib.FREEZER_FILE).exists()
    assert "two" in get_frozen_config(tmp_path)["meals"]


def test_freezer_ordering_is_deterministic(tmp_path: Path):
    """Freezer file content is always sorted for reproducibility."""
    tmp_path.joinpath(lib.CONFIG_FILE).write_text(
        f"""
        version = {lib.CONFIG_VERSION}
        kitchen = "."

        [meals.banana]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.apple]
        url = "{BUNDLE123}"
        branch = "main"

        [meals.cherry]
        url = "{BUNDLE123}"
        branch = "main"
        """
    )
    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals.banana]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals.apple]
        rev = "e757a53dccbb5407994f03dc419651275dc6eacf"
        [meals.cherry]
        rev = "a6cf33141a9f770967e3c132e0aa0071c3db2d43"
        """
    )
    lib.Worker(tmp_path).warmup()
    # Make changes in all meals to produce auto-patches
    for meal in ("banana", "apple", "cherry"):
        with tmp_path.joinpath(meal, "file-1.txt").open("a") as fd:
            fd.write("patched\n")
        lib.git(tmp_path / meal)("commit", "-am", f"Patched {meal}")
    lib.Worker(tmp_path).freeze()
    freezer = get_frozen_config(tmp_path)
    # Meals must appear sorted alphabetically
    assert list(freezer["meals"].keys()) == sorted(freezer["meals"].keys())
    assert list(freezer["meals"].keys()) == ["apple", "banana", "cherry"]
    # Spices must appear sorted alphabetically by URL
    assert list(freezer["spices"].keys()) == sorted(freezer["spices"].keys())
