"""Test parallelization features."""

import importlib
import inspect
import logging
import os
import shutil
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import MagicMock, patch

from plumbum import local

from mrchef import lib
from mrchef.lib import git_remote_head_bg

from .conftest import SAMPLE_REPOS

BUNDLE123 = SAMPLE_REPOS / "123.bundle"


def test_max_parallel_jobs_default():
    """Test that MAX_PARALLEL_JOBS is set correctly."""
    # Should be at least 1
    assert lib.MAX_PARALLEL_JOBS >= 1
    # Should be cpu_count - 2 (or 1 if that would be less than 1)
    cpu_count = os.cpu_count() or 4
    expected = max(1, cpu_count - 2)
    assert lib.MAX_PARALLEL_JOBS == expected


def test_max_parallel_jobs_with_low_cpu_count():
    """Test MAX_PARALLEL_JOBS calculation with low CPU count."""
    with patch("os.cpu_count", return_value=2):
        # Re-import to recalculate the constant

        importlib.reload(lib)
        # Should be max(1, 2-2) = 1
        assert lib.MAX_PARALLEL_JOBS == 1


def test_max_parallel_jobs_with_medium_cpu_count():
    """Test MAX_PARALLEL_JOBS calculation with medium CPU count."""
    with patch("os.cpu_count", return_value=8):
        importlib.reload(lib)
        # Should be max(1, 8-2) = 6
        assert lib.MAX_PARALLEL_JOBS == 6


def test_max_parallel_jobs_with_high_cpu_count():
    """Test MAX_PARALLEL_JOBS calculation with high CPU count."""
    with patch("os.cpu_count", return_value=32):
        importlib.reload(lib)
        # Should be max(1, 32-2) = 30
        assert lib.MAX_PARALLEL_JOBS == 30


def test_max_parallel_jobs_with_single_cpu():
    """Test MAX_PARALLEL_JOBS calculation with single CPU."""
    with patch("os.cpu_count", return_value=1):
        importlib.reload(lib)
        # Should be max(1, 1-2) = 1 (never less than 1)
        assert lib.MAX_PARALLEL_JOBS == 1


def test_max_parallel_jobs_with_none_cpu_count():
    """Test MAX_PARALLEL_JOBS when cpu_count returns None."""
    with patch("os.cpu_count", return_value=None):
        importlib.reload(lib)
        # Should be max(1, 4-2) = 2 (using fallback of 4)
        assert lib.MAX_PARALLEL_JOBS == 2


def test_clone_meals_parallel_accepts_jobs_parameter(tmp_path, monkeypatch):
    """Test that _clone_meals_parallel accepts the jobs parameter."""
    monkeypatch.chdir(tmp_path)
    lib.Worker.init(tmp_path)
    worker = lib.Worker(tmp_path)

    # Verify the method signature accepts jobs parameter
    sig = inspect.signature(worker._clone_meals_parallel)
    assert "jobs" in sig.parameters
    assert sig.parameters["jobs"].default is None


def test_compute_nar_hashes_parallel_respects_jobs_parameter(tmp_path, monkeypatch):
    """Test that _compute_nar_hashes_parallel respects the jobs parameter."""
    monkeypatch.chdir(tmp_path)
    lib.Worker.init(tmp_path)
    worker = lib.Worker(tmp_path)

    # Mock the _nar_hash_bg to track parallel execution
    hash_calls = []

    def mock_nar_hash_bg(meal):
        """Track when NAR hash computations are launched."""
        hash_calls.append(meal)
        # Create a mock future
        future = MagicMock()
        future.wait = MagicMock()
        future.returncode = 0
        future.stdout = '"sha256-mockhash"'
        return future

    with patch.object(worker, "_nar_hash_bg", side_effect=mock_nar_hash_bg):
        # Create test data with multiple meals
        hot_meals = [
            (
                f"meal{i}",
                lib.Meal(
                    path=tmp_path / "kitchen" / f"meal{i}",
                    url=f"https://example.com/meal{i}.git",
                    branch="main",
                    rev=f"abc123{i}",
                ),
            )
            for i in range(5)
        ]

        # Test with jobs=2
        hash_calls.clear()
        worker._compute_nar_hashes_parallel(hot_meals, jobs=2)
        # Should have been called 5 times total
        assert len(hash_calls) == 5


def test_warmup_with_custom_jobs(tmp_path, monkeypatch):
    """Test that warmup accepts and uses custom jobs parameter."""
    monkeypatch.chdir(tmp_path)
    lib.Worker.init(tmp_path)
    worker = lib.Worker(tmp_path)

    # Track calls to _clone_meals_parallel
    clone_jobs_used = []

    def track_clone_jobs(_meals, jobs=None):
        clone_jobs_used.append(jobs)
        return []

    with patch.object(worker, "_clone_meals_parallel", side_effect=track_clone_jobs):
        # Call warmup with custom jobs
        worker.warmup(jobs=3)

        # If there were meals to clone, jobs parameter should have been passed
        if clone_jobs_used:
            assert clone_jobs_used[0] == 3


def test_freeze_with_custom_jobs(tmp_path, monkeypatch):
    """Test that freeze accepts and uses custom jobs parameter."""
    monkeypatch.chdir(tmp_path)
    lib.Worker.init(tmp_path)

    # Add a meal to the config
    config_file = tmp_path / lib.CONFIG_FILE
    config = lib.rtoml.load(config_file)
    config["require_nar_hash"] = True
    config["meals"] = {
        "test-meal": {
            "url": "https://example.com/test.git",
            "branch": "main",
        }
    }
    with config_file.open("w") as fd:
        lib.rtoml.dump(config, fd)

    worker = lib.Worker(tmp_path)

    # Track calls to _compute_nar_hashes_parallel
    hash_jobs_used = []

    def track_hash_jobs(_meals, jobs=None):
        hash_jobs_used.append(jobs)
        return {}

    with patch.object(
        worker, "_compute_nar_hashes_parallel", side_effect=track_hash_jobs
    ):
        with patch.object(worker, "hot_meals", return_value={}):
            # Call freeze with custom jobs
            worker.freeze(jobs=4)

            # Jobs parameter should have been passed (even if no meals)
            # The method is only called if require_nar_hash is True and there are meals
            # Since we mocked hot_meals to return empty, it won't be called


def test_update_with_custom_jobs(tmp_path, monkeypatch):
    """Test that update accepts and uses custom jobs parameter."""
    monkeypatch.chdir(tmp_path)
    lib.Worker.init(tmp_path)
    worker = lib.Worker(tmp_path)

    # Track calls to warmup and freeze
    warmup_jobs = []
    freeze_jobs = []

    def track_warmup(*_args, **kwargs):
        warmup_jobs.append(kwargs.get("jobs"))

    def track_freeze(*_args, **kwargs):
        freeze_jobs.append(kwargs.get("jobs"))

    with patch.object(worker, "warmup", side_effect=track_warmup):
        with patch.object(worker, "freeze", side_effect=track_freeze):
            # Call update with custom jobs
            worker.update(jobs=5)

            # Both warmup and freeze should have received jobs=5
            assert warmup_jobs[0] == 5
            assert freeze_jobs[0] == 5


def test_jobs_parameter_none_uses_default(tmp_path, monkeypatch):
    """Test that jobs=None uses MAX_PARALLEL_JOBS."""
    monkeypatch.chdir(tmp_path)
    lib.Worker.init(tmp_path)
    worker = lib.Worker(tmp_path)

    # Track the max_jobs value used
    max_jobs_used = []

    def track_max_jobs(_meals, jobs=None):
        # This is what the method does internally
        max_jobs = jobs or lib.MAX_PARALLEL_JOBS
        max_jobs_used.append(max_jobs)
        return []

    with patch.object(worker, "_clone_meals_parallel", side_effect=track_max_jobs):
        worker.warmup(jobs=None)

        # Should have used MAX_PARALLEL_JOBS
        if max_jobs_used:
            assert max_jobs_used[0] == lib.MAX_PARALLEL_JOBS


def test_jobs_parameter_limits_batch_size():
    """Test that jobs parameter correctly limits batch size."""
    # This test verifies the batching logic by checking the range iteration
    max_jobs = 3
    total_meals = 7

    # Calculate expected batches
    expected_batches = []
    for i in range(0, total_meals, max_jobs):
        batch_size = min(max_jobs, total_meals - i)
        expected_batches.append(batch_size)

    # Should be [3, 3, 1]
    assert expected_batches == [3, 3, 1]


def test_sequential_execution_with_jobs_1():
    """Test that jobs=1 forces sequential execution."""
    # This test verifies the batching logic with jobs=1
    max_jobs = 1
    total_meals = 3

    # Calculate expected batches
    expected_batches = []
    for i in range(0, total_meals, max_jobs):
        batch_size = min(max_jobs, total_meals - i)
        expected_batches.append(batch_size)

    # Should be [1, 1, 1] - one meal at a time
    assert expected_batches == [1, 1, 1]


def test_git_remote_head_bg_returns_future(tmp_path, monkeypatch):
    """Test that git_remote_head_bg returns a Future-like object."""
    # Create a minimal git repo
    monkeypatch.chdir(tmp_path)
    local["git"]("init")
    local["git"]("config", "user.email", "test@example.com")
    local["git"]("config", "user.name", "Test User")
    (tmp_path / "test.txt").write_text("test")
    local["git"]("add", "test.txt")
    local["git"]("commit", "-m", "Initial commit")

    # Test that the function returns a future-like object
    future = git_remote_head_bg(tmp_path, str(tmp_path), "HEAD", False)

    # Should have wait method
    assert hasattr(future, "wait")
    assert hasattr(future, "returncode")
    assert hasattr(future, "stdout")
    assert hasattr(future, "stderr")

    # Wait should complete without error
    future.wait()
    assert future.returncode == 0
    assert len(future.stdout) > 0  # Should contain a commit SHA


def test_hot_meals_parallel_fetch(tmp_path, monkeypatch, caplog):
    """Test that hot_meals fetches remote heads in parallel."""
    monkeypatch.chdir(tmp_path)
    lib.Worker.init(tmp_path)

    # The log message should appear when there are meals to fetch
    # Since we don't have actual meals in this test, we just verify
    # the method signature accepts the parallel execution path
    worker = lib.Worker(tmp_path)

    with caplog.at_level(logging.INFO):
        worker.hot_meals()

    # Should not crash and should handle empty kitchen gracefully
    assert True


def test_clone_meals_parallel_same_url_serialized(tmp_path, monkeypatch):
    """Test that cloning same URL with different branches uses one thread.

    When two meals have the same URL, they should be processed in the same thread
    (sequentially) to avoid git-autoshare cache conflicts.
    """
    monkeypatch.chdir(tmp_path)

    worker = lib.Worker.init(tmp_path)

    config_file = tmp_path / lib.CONFIG_FILE
    config = lib.rtoml.load(config_file)
    config["meals"] = {
        "meal-1": {
            "url": str(BUNDLE123),
            "branch": "main",
        },
        "meal-2": {
            "url": str(BUNDLE123),
            "branch": "main",
        },
    }
    with config_file.open("w") as fd:
        lib.rtoml.dump(config, fd)

    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals."meal-1"]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals."meal-2"]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        """
    )

    worker = lib.Worker(tmp_path)

    tasks_submitted: list[int] = []

    original_submit = ThreadPoolExecutor.submit

    def tracking_submit(self, fn, *args, **kwargs):
        tasks_submitted.append(1)
        return original_submit(self, fn, *args, **kwargs)

    with patch.object(ThreadPoolExecutor, "submit", tracking_submit):
        cold_meals = worker.cold_meals()
        meals_to_clone = list(cold_meals.items())
        worker._clone_meals_parallel(meals_to_clone, jobs=2)

    assert len(tasks_submitted) == 1, (
        f"Same URL should submit 1 task (grouped), but submitted {len(tasks_submitted)}"
    )


def test_clone_meals_parallel_different_urls_parallel(tmp_path, monkeypatch):
    """Test that cloning different URLs uses multiple threads.

    When meals have different URLs, they should be processed in different threads
    to achieve parallelism.
    """
    monkeypatch.chdir(tmp_path)

    bundle_copy = tmp_path / "another.bundle"
    shutil.copy(BUNDLE123, bundle_copy)

    worker = lib.Worker.init(tmp_path)

    config_file = tmp_path / lib.CONFIG_FILE
    config = lib.rtoml.load(config_file)
    config["meals"] = {
        "meal-a": {
            "url": str(BUNDLE123),
            "branch": "main",
        },
        "meal-b": {
            "url": str(bundle_copy),
            "branch": "main",
        },
    }
    with config_file.open("w") as fd:
        lib.rtoml.dump(config, fd)

    tmp_path.joinpath(lib.FREEZER_FILE).write_text(
        f"""
        version = {lib.FREEZER_VERSION}
        [meals."meal-a"]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        [meals."meal-b"]
        rev = "b72639b17d5882c2ce1448f7ed452e596dbe6acd"
        """
    )

    worker = lib.Worker(tmp_path)

    tasks_submitted: list[int] = []

    original_submit = ThreadPoolExecutor.submit

    def tracking_submit(self, fn, *args, **kwargs):
        tasks_submitted.append(1)
        return original_submit(self, fn, *args, **kwargs)

    with patch.object(ThreadPoolExecutor, "submit", tracking_submit):
        cold_meals = worker.cold_meals()
        meals_to_clone = list(cold_meals.items())
        worker._clone_meals_parallel(meals_to_clone, jobs=2)

    assert len(tasks_submitted) == 2, (
        f"Different URLs should submit 2 tasks, but submitted {len(tasks_submitted)}"
    )
