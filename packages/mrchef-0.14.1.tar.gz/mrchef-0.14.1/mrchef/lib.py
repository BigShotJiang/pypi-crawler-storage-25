"""Mr. Chef's core functionality."""

import json
import os
import re
import warnings
from collections.abc import Generator
from concurrent.futures import ThreadPoolExecutor
from contextlib import suppress
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import lru_cache
from logging import DEBUG, ERROR, captureWarnings, getLogger
from pathlib import Path
from shutil import rmtree
from textwrap import dedent
from typing import Any, NamedTuple, cast
from urllib.parse import ParseResult, urlparse

import coloredlogs
import requests
import rtoml
import tomlkit
from git_find_repos import find_repos
from plumbum import BG, TF, local
from plumbum.commands import BaseCommand, Future
from plumbum.commands.processes import CommandNotFound, ProcessExecutionError
from requests.exceptions import HTTPError
from tomlkit.items import Array

# Configuration constants
CONFIG_FILE = "mrchef.toml"
CONFIG_VERSION = 1
FREEZER_FILE = ".mrchef.freezer.toml"
FREEZER_VERSION = 3

# Parallelization settings
# Maximum number of parallel jobs to avoid overwhelming the system
# os.cpu_count() can return None if undetermined, so we use 4 as fallback
# We reserve 2 CPUs for the system to keep it responsive
_cpu_count = os.cpu_count() or 4
MAX_PARALLEL_JOBS = max(1, _cpu_count - 2)


def now() -> datetime:
    """Return tz-aware current datetime.

    If an environment variable `MRCHEF_MOCK_DATE` is set, return that instead.
    It is helpful for testing, or for generating reproducible freezes.
    """
    try:
        return datetime.fromisoformat(os.environ["MRCHEF_MOCK_DATE"])
    except KeyError:
        return datetime.now(tz=timezone.utc)


logger = getLogger("mrchef")
coloredlogs.install(logger=logger, level=0)

# Combine with warnings
warnings_logger = getLogger("py.warnings")
coloredlogs.install(logger=warnings_logger, level=0)
captureWarnings(True)


class MrChefError(Exception):
    """Core MrChef exception.

    It will be handled and pretty-printed when raised to CLI.
    """

    def __init__(self, msg: str, trace_level=DEBUG):
        """Initialize the exception.

        Args:
            msg: The message to present to the user.
            trace_level: Level used to log the exception traceback.
        """
        self.msg = msg
        self.trace_level = trace_level


@dataclass
class Meal:
    """Store warm and frozen configurations for meals (sub-repositories)."""

    # From a human
    path: Path
    url: str
    branch: str

    # From the freezer
    last_update: datetime = field(default_factory=now)
    rev: str | None = None
    spices: list[str] = field(default_factory=list)


class BiMeal(NamedTuple):
    """An item that contains 2 meals: the frozen one and the hot one.

    One of them could be `None`, if not found.
    """

    cold: Meal | None
    hot: Meal | None


class _CachedFuture:
    """Mock future object for cached results.

    Used when a background operation result is already cached,
    avoiding the need to spawn a real background process.
    """

    stdout: str
    returncode: int

    def __init__(self, value: Any) -> None:
        """Initialize with a cached value.

        Args:
            value: The cached value to return.
        """
        self.stdout = json.dumps(value)
        self.returncode = 0

    def wait(self) -> None:
        """No-op wait since result is already available."""
        pass


class Worker:
    """Get meta-repo status and do stuff with it."""

    def __init__(self, starting_folder: Path | None = None):
        """Load configuration from starting path upwards.

        Starts traversing directories upwards, looking for a `mrchef.toml` file,
        and loads it.
        """
        if starting_folder is None:
            starting_folder = Path()
        assert starting_folder.is_dir()
        current = starting_folder.absolute()
        top = Path(current.root)
        while current > top:
            current_file = current / CONFIG_FILE
            try:
                with current_file.open("r") as fd:
                    self.config_user = tomlkit.load(fd)
            except FileNotFoundError:
                current = current.parent
                continue
            self.path = current
            self.config_file = current_file
            break
        else:
            raise MrChefError(f"No {CONFIG_FILE} file found here or in parent folders.")
        # Attempt to merge normal config with frozen one
        self.freezer_file = self.path / FREEZER_FILE
        self.config_frozen = self._parse_freezer()
        if not self.config_frozen:
            warnings.warn("Freezer file not found.", stacklevel=2)
        # Setup self and do some checks
        if self.config_user["version"] != CONFIG_VERSION:
            logger.warning(
                "%s has version %s instead of %s; update it or bad things could happen",
                self.config_file,
                self.config_user["version"],
                CONFIG_VERSION,
            )
        kitchen_value = self.config_user["kitchen"]
        self.kitchen = self.path / str(kitchen_value)
        self.config_frozen.setdefault("meals", {})
        self.config_frozen.setdefault("spices", {})
        if self.config_frozen.get("version", FREEZER_VERSION) != FREEZER_VERSION:
            logger.warning(
                "%s has version %s instead of %s; re-freeze or bad things could happen",
                self.freezer_file,
                self.config_frozen.get("version"),
                FREEZER_VERSION,
            )
        self.config_frozen.setdefault("version", FREEZER_VERSION)
        self._cached_hot_spices: dict[str, str] = {}
        self._cached_patch2spice: dict[str, dict[str, str]] = {}

    def _parse_freezer(self) -> dict[str, Any]:
        """Parse the freezer file."""
        try:
            # Style in the freezer isn't preserved, so we use rtoml it to be faster
            return rtoml.load(self.freezer_file)
        except FileNotFoundError:
            return {}

    def _cache_spices(self) -> None:
        """Make sure all spices cache is updated."""
        for meal_key, meal_value in self.config_user.get("meals", {}).items():
            self._cached_patch2spice.setdefault(meal_key, {})
            for spice_url in meal_value.get("spices", []):
                spice_content = self._get_spice_content(spice_url)
                for spice_patch_id in git_get_patch_ids_map(spice_content):
                    self._cached_patch2spice[meal_key][spice_patch_id] = spice_url

    def _get_meal_key_by_path(self, meal_path: Path) -> str:
        """Get the meal key by its path."""
        meal_abs = meal_path.absolute().resolve()
        kitchen_abs = Path(self.kitchen).absolute().resolve()
        if not meal_abs.is_relative_to(kitchen_abs):
            raise MrChefError(
                f"The meal {meal_path} is not inside the kitchen {self.kitchen}"
            )
        return str(meal_abs.relative_to(kitchen_abs))

    def _get_spice_from_patch_id(self, meal_key: str, patch_id: str) -> str | None:
        """Get the spice URL from a patch ID.

        Make sure to call `self._cache_spices()` before using this method.
        """
        return self._cached_patch2spice.get(meal_key, {}).get(patch_id)

    def _get_spice_content(self, spice_url: str, force_update=False) -> str:
        """Get spice content.

        Return the raw text of the patch.

        If the spice wasn't in the freezer, download it automatically and cache it.

        Args:
            spice_url: Patch URL.
            force_update: Ignore cached contents in the freezer.
        """
        if force_update:
            # Locate local patch
            local_patch = Path(spice_url)
            if not local_patch.is_absolute():
                local_patch = self.path / local_patch
            # Get content from local cache, local file or from the Internet
            try:
                content = self._cached_hot_spices[spice_url]
            except KeyError:
                content = (
                    local_patch.read_text()
                    if local_patch.is_file()
                    else download_spice(spice_url)
                )
            self.config_frozen["spices"][spice_url] = content
        try:
            # Get cached content
            return self._cached_hot_spices.get(
                spice_url, self.config_frozen["spices"][spice_url]
            )
        except KeyError:
            # Cached content not found, get it from the Internet
            logger.info(f"Spice was not frozen, downloading: {spice_url}")
            return self._get_spice_content(spice_url, True)

    def _patches_generator(self) -> Generator[Path, None, None]:
        """A generator that creates new patch file names in the kitchen."""
        num = 0
        while True:
            patch_path = Path(self.kitchen) / f"mrchef-{num:03d}.patch"
            if not patch_path.exists():
                yield patch_path
            num += 1

    def _new_patch(self) -> Path:
        """Generate a new patch file name in the kitchen."""
        try:
            generator: Generator[Path, None, None] = self._cached_patch_generator  # type: ignore[has-type]
        except AttributeError:
            self._cached_patch_generator = self._patches_generator()
            generator = self._cached_patch_generator
        return next(generator)

    def _nar_hash(self, meal: Meal) -> str:
        """Get Nix hash for a meal.

        This will take longer to freeze, but it will make Nix expressions
        faster to evaluate later.

        TODO: Possibly not needed when [Nix's RFC 133 is implemented][1].

        [1]: https://github.com/NixOS/nix/issues/8919
        """
        assert meal.rev
        # Get cached hash if possible
        with suppress(MrChefError, KeyError):
            key = self._get_meal_key_by_path(meal.path)
            cold_config = self.config_frozen["meals"][key]
            if cold_config["rev"] == meal.rev:
                return cold_config["nar_hash"]
        # Get hash from Nix
        logger.info("Getting NAR hash for %s @ %s", meal.url, meal.branch)
        fetcher = Path(__file__).parent / "fetchMeal.nix"
        json_hash = local["nix-instantiate"](
            "--extra-experimental-features",
            "flakes",
            "--json",
            "--eval",
            fetcher,
            "--argstr",
            "returnAttr",
            "narHash",
            "--argstr",
            "url",
            meal.url,
            "--argstr",
            "branch",
            meal.branch,
            "--argstr",
            "rev",
            meal.rev,
        )
        return json.loads(json_hash)

    def _nar_hash_bg(self, meal: Meal) -> _CachedFuture | Future:
        """Get Nix hash for a meal in background.

        Returns a Future object that can be waited on.
        """
        assert meal.rev
        # Get cached hash if possible
        with suppress(MrChefError, KeyError):
            key = self._get_meal_key_by_path(meal.path)
            cold_config = self.config_frozen["meals"][key]
            if cold_config["rev"] == meal.rev:
                # Return a mock future with cached result
                return _CachedFuture(cold_config["nar_hash"])
        # Get hash from Nix in background
        logger.info("Getting NAR hash for %s @ %s", meal.url, meal.branch)
        fetcher = Path(__file__).parent / "fetchMeal.nix"
        return (
            local["nix-instantiate"][
                "--extra-experimental-features",
                "flakes",
                "--json",
                "--eval",
                fetcher,
                "--argstr",
                "returnAttr",
                "narHash",
                "--argstr",
                "url",
                meal.url,
                "--argstr",
                "branch",
                meal.branch,
                "--argstr",
                "rev",
                meal.rev,
            ]
            & BG
        )

    def _is_auto_patch(self, patch_path: Path) -> bool:
        """Check if the patch was generated by MrChef."""
        return (
            patch_path.name.startswith("mrchef-")
            and patch_path.suffix == ".patch"
            and patch_path.parent == self.kitchen
        )

    @classmethod
    def init(cls, where: Path) -> "Worker":
        """Initialize a new kitchen."""
        where.joinpath(CONFIG_FILE).write_text(
            dedent(
                f"""\
                version = {CONFIG_VERSION}
                kitchen = "kitchen"

                # Remove if you don't need Nix integration
                require_nar_hash = true

                # Add meals like this:
                # [meals.starter]
                # url = "https://gitlab.example.com/menu/starter.git"
                # branch = "delicacy"

                # You can add special spices to your version of this meal:
                # spices = [
                #     # Special shared spices for this metarepo
                #     "https://gitlab.example.com/menu/starter/-/merge_requests/1.patch",
                #     "https://gitlab.example.com/menu/starter/-/commit/14ebafa278a28a08b9660e6ccab33fc72bbccd17.patch",
                #     "https://github.com/menu/starter/pull/45.patch",
                #     "https://github.com/menu/starter/commit/430e53b9de9cf986d8236061eeb77ae35fd03f55",
                #     # This special spice is only for us
                #     "./local-extra-spicy.patch",
                # ]

                # Add more meals:
                # [meals.dessert]
                # url = "git@github.com/menu/dessert.git"
                # branch = "pudding"

                # After you're done adding meals, get them:
                # $ mrchef warmup

                # After you're done cooking, put them in the freezer, for reproducibility:
                # $ mrchef freeze
                """
            )
        )
        where.joinpath(FREEZER_FILE).write_text(f"version = {FREEZER_VERSION}\n")
        return cls(where)

    def cold_meals(self) -> dict[str, Meal]:
        """Get meals info from the freezer."""
        return {
            key: Meal(
                path=self.kitchen / key,
                url=value["url"],
                branch=value["branch"],
                rev=value.get(
                    "rev", self.config_frozen["meals"].get(key, {}).get("rev")
                ),
                spices=value.get("spices", []),
            )
            for key, value in self.config_user.get("meals", {}).items()
        }

    def _build_hot_meal(
        self, key: str, meal_path: Path, url: str, branch: str, remote_head: str
    ) -> Meal:
        """Build a hot meal object from repository information.

        Args:
            key: Meal identifier.
            meal_path: Path to the meal repository.
            url: Repository URL.
            branch: Branch name.
            remote_head: Remote HEAD commit SHA.

        Returns:
            Constructed Meal object.
        """
        meal = Meal(
            path=meal_path,
            url=url,
            branch=branch,
            # Revision is not the current commit; it's the closest common
            # parent between local and remote commits
            rev=git_merge_base(meal_path, remote_head, "HEAD"),
        )
        # Get last update date from freezer if possible
        with suppress(KeyError):
            meal.last_update = self.config_frozen["meals"][key]["last_update"]
        # Build spices from local changes
        for hot_commit in git_commits_diff(meal_path, meal.rev, "HEAD"):
            hot_patch_id = git_commit_patch_id(meal_path, hot_commit)
            if not (hot_spice_url := self._get_spice_from_patch_id(key, hot_patch_id)):
                # The patch is new; store it in the kitchen
                local_path = self._new_patch()
                local_contents = git_get_commits_patch(meal_path, hot_commit)
                hot_spice_url = str(local_path.relative_to(self.path))
                self._cached_hot_spices[hot_spice_url] = local_contents
                self._cached_patch2spice[key][hot_patch_id] = hot_spice_url
            # A spice can contain various commits, so it could exist already
            if hot_spice_url not in meal.spices:
                meal.spices.append(hot_spice_url)
        return meal

    def hot_meals(self, *meal_keys: str) -> dict[str, Meal]:
        """Get info from the hot meals found in the kitchen."""
        result: dict[str, Meal] = {}
        if not self.kitchen.is_dir():
            return result
        self._cache_spices()

        # First pass: collect meal info and start parallel remote head fetches
        meal_infos = []
        remote_head_futures = []

        for meal_path in map(Path, find_repos(self.kitchen)):
            key = self._get_meal_key_by_path(meal_path)
            if meal_keys and key not in meal_keys:
                continue
            branch = git_branch(meal_path)
            meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
            url = meals_dict.get(key, {}).get("url") or git_origin(meal_path)
            meal_infos.append((key, meal_path, url, branch))

        # Fetch all remote heads in parallel
        if meal_infos:
            logger.info(
                "Fetching remote heads for %d meals in parallel", len(meal_infos)
            )
            for key, meal_path, url, branch in meal_infos:
                logger.debug("Starting fetch for %s", key)
                future = git_remote_head_bg(meal_path, url, branch, True)
                remote_head_futures.append((key, meal_path, url, branch, future))

        # Second pass: wait for fetches and build meal objects
        for key, meal_path, url, branch, future in remote_head_futures:
            future.wait()
            if future.returncode != 0:
                raise MrChefError(
                    f"Failed to fetch remote head for {key}: {future.stderr}"
                )
            remote_head = future.stdout.strip()
            result[key] = self._build_hot_meal(key, meal_path, url, branch, remote_head)

        if meal_infos:
            logger.debug(
                "Completed fetching remote heads for %d meals", len(meal_infos)
            )

        return result

    def all_meals(self, *meal_paths: Path) -> dict[str, BiMeal]:
        """Obtain all meals, both warmed up and frozen.

        Useful to compare meals in both states.

        Args:
            meal_paths: Filter only meals related to these paths.

        Returns:
            Dict with all meals and their states.

            The dict key will be the meal name (relative path to kitchen root).

            The dict value will be another dict with keys "hot" and "cold".
            Each of those keys will contain `None` if the meal is not found in
            that state, or a [Meal][] object if found.

            !!! example

                ```python
                {
                    "sashimi": {
                        "hot": None,
                        "cold": Meal(...),
                    },
                    "pizza/pepperoni": {
                        "hot": Meal(...),
                        "cold": Meal(...),
                    },
                }
                ```
        """
        cold = self.cold_meals()
        meal_keys = {self._get_meal_key_by_path(meal_path) for meal_path in meal_paths}
        invented_meals = meal_keys - set(cold)
        if invented_meals:
            raise MrChefError(
                f"Couldn't find meal(s) in freezer: {', '.join(sorted(invented_meals))}"
            )
        hot = self.hot_meals(*meal_keys)
        all_keys_set = set(cold) | set(hot)
        if meal_paths:
            all_keys_set &= set(meal_keys)
        all_keys = sorted(all_keys_set)
        return {key: BiMeal(cold.get(key), hot.get(key)) for key in all_keys}

    def update_user_config(self) -> None:
        """Update user config."""
        with self.config_file.open("w") as fd:
            tomlkit.dump(self.config_user, fd)

    def check(self) -> None:
        """Check freezer and oven are in sync."""
        ok = True
        for key, (cold, hot) in self.all_meals().items():
            if cold is None:
                ok = False
                logger.error("Meal %s is hot but not frozen", key)
                continue
            if hot is None:
                ok = False
                logger.error("Meal %s is frozen but not hot", key)
                continue
            if hot.url != cold.url:
                logger.warning(
                    "Meal %s is frozen with origin %s, but hot with origin %s",
                    key,
                    cold.url,
                    hot.url,
                )
            if hot.rev != cold.rev:
                ok = False
                logger.error(
                    "Meal %s is frozen with rev %s, but hot with rev %s",
                    key,
                    cold.rev,
                    hot.rev,
                )
            if hot.spices != cold.spices:
                ok = False
                logger.error(
                    "Meal %s spices are different. frozen=%s warm=%s",
                    key,
                    cold.spices,
                    hot.spices,
                )
        try:
            if self.config_frozen != rtoml.load(self.freezer_file):
                ok = False
                logger.error("Freezer is outdated.")
        except FileNotFoundError:
            ok = False
            logger.error("Freezer not found.")
        if not ok:
            raise MrChefError("🔪 Found errors!")
        logger.info("All frozen and hot meals are ready! 👨‍🍳")

    def _clone_meals_parallel(
        self, meals_to_clone: list[tuple[str, Meal]], jobs: int | None = None
    ) -> list[tuple[str, Meal, None]]:
        """Clone multiple meals in parallel with concurrency control.

        Args:
            meals_to_clone: List of (key, cold_meal) tuples to clone.
            jobs: Maximum number of parallel jobs (None uses MAX_PARALLEL_JOBS).

        Returns:
            List of (key, cold_meal, None) tuples ready for update.
        """
        meals_to_update = []
        max_jobs = jobs or MAX_PARALLEL_JOBS

        logger.info(
            "Cloning %d meals in parallel (max %d jobs)",
            len(meals_to_clone),
            max_jobs,
        )

        # Group meals by URL to avoid git-autoshare cache conflicts
        # when cloning the same repository in parallel
        meals_by_url: dict[str, list[tuple[str, Meal]]] = {}
        for key, cold in meals_to_clone:
            if cold.url not in meals_by_url:
                meals_by_url[cold.url] = []
            meals_by_url[cold.url].append((key, cold))

        # Process clones: serialize by URL, but parallelize across different URLs
        # Each URL group runs sequentially, but different URLs can run in parallel
        def clone_meal(key, cold):
            logger.info("Cloning %s", key)
            local["git-autoshare-clone"](
                "--recursive",
                "--filter",
                "blob:none",
                "--branch",
                cold.branch,
                cold.url,
                cold.path,
            )

        def clone_url_group(url_meals: list[tuple[str, Meal]]):
            """Clone all meals for a single URL sequentially."""
            results = []
            for key, cold in url_meals:
                clone_meal(key, cold)
                cold = self.cold_meals()[key]
                results.append((key, cold, None))
            return results

        with ThreadPoolExecutor(max_workers=max_jobs) as executor:
            url_groups = list(meals_by_url.values())
            futures = [executor.submit(clone_url_group, group) for group in url_groups]

            for future in futures:
                meals_to_update.extend(future.result())

        logger.debug("Completed parallel cloning of %d meals", len(meals_to_clone))
        return meals_to_update

    def _prepare_meal_update(
        self,
        key: str,
        cold: Meal,
        hot: Meal | None,
        force: bool,
        rev_future: Future | None = None,
    ) -> str:
        """Prepare a meal for update by handling dirty state and getting revision.

        Args:
            key: Meal identifier.
            cold: Frozen meal configuration.
            hot: Current hot meal state (None if just cloned).
            force: Continue if meal is dirty.
            rev_future: Optional future with remote head fetch result.

        Returns:
            The revision to switch to.
        """
        _git = git(cold.path)
        was_dirty = git_is_dirty(cold.path)

        if was_dirty:
            if not force:
                raise MrChefError(f"Meal {key} is dirty.")
            logger.info("Stashing dirty changes at %s", key)
            _git(
                "stash",
                "push",
                "--all",
                "--message",
                f"MrChef dirty meal - {hot.branch if hot else cold.branch} - {datetime.now()}",
            )
            # Discard other dirty operations
            _git("am", "--abort", retcode=None)
            _git("cherry-pick", "--abort", retcode=None)
            _git("merge", "--abort", retcode=None)
            _git("rebase", "--abort", retcode=None)

        rev = cold.rev
        if not rev:
            if rev_future:
                # Use pre-fetched result
                rev_future.wait()
                if rev_future.returncode != 0:
                    raise MrChefError(
                        f"Failed to fetch remote head for {key}: {rev_future.stderr}"
                    )
                rev = rev_future.stdout
            else:
                # Fetch synchronously
                rev = git_remote_head(
                    cold.path, cold.url, cold.rev or cold.branch, not cold.rev
                )

        if not rev:
            raise MrChefError(f"Could not determine revision for meal {key}")
        return rev

    def _switch_meals_parallel(
        self,
        meals_to_switch: list[tuple[str, Meal, str]],
        jobs: int | None = None,
    ) -> None:
        """Switch multiple meals to their target revisions in parallel.

        Args:
            meals_to_switch: List of (key, cold_meal, rev) tuples.
            jobs: Maximum number of parallel jobs (None uses MAX_PARALLEL_JOBS).
        """
        if not meals_to_switch:
            return

        max_jobs = jobs or MAX_PARALLEL_JOBS
        logger.info(
            "Switching %d meals to target revisions in parallel (max %d jobs)",
            len(meals_to_switch),
            max_jobs,
        )

        from concurrent.futures import ThreadPoolExecutor

        def switch_meal(key, cold, rev):
            logger.info(
                "Updating %s: remote=%s branch=%s rev=%s",
                key,
                cold.url,
                cold.branch,
                rev,
            )
            git(cold.path)("switch", "--force-create", cold.branch, rev)
            return key

        with ThreadPoolExecutor(max_workers=max_jobs) as executor:
            futures = []
            for key, cold, rev in meals_to_switch:
                future = executor.submit(switch_meal, key, cold, rev)
                futures.append(future)

            # Wait for all to complete
            for future in futures:
                future.result()  # This will raise any exception that occurred

        logger.debug("Completed switching %d meals", len(meals_to_switch))

    def _apply_spices_parallel(
        self,
        meals_with_spices: list[tuple[str, Meal, bool]],
        jobs: int | None = None,
    ) -> None:
        """Apply spices to multiple meals in parallel.

        Args:
            meals_with_spices: List of (key, cold_meal, autoremove_spices) tuples.
            jobs: Maximum number of parallel jobs (None uses MAX_PARALLEL_JOBS).
        """
        if not meals_with_spices:
            return

        max_jobs = jobs or MAX_PARALLEL_JOBS
        total_spices = sum(len(cold.spices) for _, cold, _ in meals_with_spices)

        logger.info(
            "Applying %d spices to %d meals in parallel (max %d jobs)",
            total_spices,
            len(meals_with_spices),
            max_jobs,
        )

        from concurrent.futures import ThreadPoolExecutor

        def apply_meal_spices(key, cold, autoremove_spices):
            """Apply all spices for a meal sequentially."""
            for spice in cold.spices:
                logger.info("Applying spice to %s: %s", key, spice)
                content = self._get_spice_content(spice)
                _git = git(cold.path)
                apply = (
                    _git["am", "--keep-non-patch", "--3way", "--no-gpg-sign"] << content
                )

                # Check if already applied before trying
                if autoremove_spices and self.spice_is_applied(cold.path, content):
                    logger.info("Removing outdated spice %s.", spice)
                    self.spice_rm(cold.path, spice, False)
                    continue

                try:
                    apply()
                except ProcessExecutionError:
                    _git("am", "--abort")
                    raise MrChefError(f"Failed to apply spice {spice} to {key}", ERROR)
            return key

        # Use ThreadPoolExecutor to apply spices to different meals in parallel
        # Each meal's spices are applied sequentially within its thread
        with ThreadPoolExecutor(max_workers=max_jobs) as executor:
            futures = []
            for key, cold, autoremove_spices in meals_with_spices:
                future = executor.submit(
                    apply_meal_spices, key, cold, autoremove_spices
                )
                futures.append(future)

            # Wait for all to complete
            for future in futures:
                future.result()  # This will raise any exception that occurred

        logger.debug("Completed applying spices to %d meals", len(meals_with_spices))

    def _process_meal_warmup(
        self,
        key: str,
        cold: Meal | None,
        hot: Meal | None,
        prune: bool,
        meals_to_clone: list[tuple[str, Meal]],
        meals_to_update: list[tuple[str, Meal, Meal]],
    ) -> None:
        """Categorize a single meal for warmup.

        Args:
            key: Meal identifier.
            cold: Frozen meal configuration (None if not in freezer).
            hot: Current hot meal state (None if not in kitchen).
            prune: Whether to remove untracked meals.
            meals_to_clone: List to append meals that need cloning.
            meals_to_update: List to append meals that need updating.
        """
        if cold is None and hot is not None:
            if prune:
                logger.info("Pruning untracked meal: %s", key)
                rmtree(hot.path)
                return
            logger.warning(
                "Untracked meal %s found in kitchen. "
                "Add --prune to remove it from disk.",
                key,
            )
            return
        if not cold:
            return
        if hot == cold:
            logger.info("Matches frozen status, skipping meal: %s", key)
            return
        if not hot:
            meals_to_clone.append((key, cold))
        else:
            meals_to_update.append((key, cold, hot))

    def warmup(
        self,
        *meal_paths: Path,
        force: bool = False,
        autoremove_spices: bool = False,
        jobs: int | None = None,
        prune: bool = False,
    ) -> None:
        """Get meals out from freezer, warm them up in the kitchen.

        Args:
            *meal_paths: Meals to warm up. Skip to select all.
            force: Continue warming up meal if it is dirty.
            autoremove_spices: Remove outdated spices from the meal.
            jobs: Maximum number of parallel jobs (None uses MAX_PARALLEL_JOBS).
            prune: Remove untracked meals from the kitchen.
        """
        meals_to_clone: list[tuple[str, Meal]] = []
        meals_to_update: list[tuple[str, Meal, Meal]] = []

        for key, (cold, hot) in self.all_meals(*meal_paths).items():
            self._process_meal_warmup(
                key, cold, hot, prune, meals_to_clone, meals_to_update
            )

        # Clone meals in parallel
        if meals_to_clone:
            cloned_meals = self._clone_meals_parallel(meals_to_clone, jobs)
            meals_to_update.extend(cloned_meals)  # type: ignore[arg-type]

        # Pre-fetch remote heads in parallel for meals that need it
        rev_futures = {}
        meals_needing_fetch = [
            (key, cold, hot) for key, cold, hot in meals_to_update if not cold.rev
        ]

        if meals_needing_fetch:
            logger.info(
                "Fetching remote heads for %d meals in parallel",
                len(meals_needing_fetch),
            )
            for key, cold, _hot in meals_needing_fetch:
                logger.debug("Starting fetch for %s", key)
                rev_futures[key] = git_remote_head_bg(
                    cold.path, cold.url, cold.rev or cold.branch, not cold.rev
                )

        # Prepare all meals for update (handle dirty state, get revisions)
        meals_to_switch = []
        for key, cold, hot in meals_to_update:
            rev = self._prepare_meal_update(key, cold, hot, force, rev_futures.get(key))
            meals_to_switch.append((key, cold, rev))

        # Switch all meals to target revisions in parallel
        self._switch_meals_parallel(meals_to_switch, jobs)

        # Apply all spices in parallel
        meals_with_spices = [
            (key, cold, autoremove_spices)
            for key, cold, _ in meals_to_switch
            if cold.spices
        ]
        self._apply_spices_parallel(meals_with_spices, jobs)

        # Some hot meals may have been modified
        git_remote_head.cache_clear()

    def _compute_nar_hashes_parallel(
        self, hot_meals: list[tuple[str, Meal]], jobs: int | None = None
    ) -> dict[str, tuple[Meal, _CachedFuture | Any]]:
        """Compute NAR hashes for multiple meals in parallel with concurrency control.

        Args:
            hot_meals: List of (name, meal) tuples to process.
            jobs: Maximum number of parallel jobs (None uses MAX_PARALLEL_JOBS).

        Returns:
            Dict mapping meal names to (meal, future) tuples with computed hashes.
        """
        nar_hash_futures = {}
        max_jobs = jobs or MAX_PARALLEL_JOBS

        logger.info(
            "Computing NAR hashes for %d meals in parallel (max %d jobs)",
            len(hot_meals),
            max_jobs,
        )

        from concurrent.futures import ThreadPoolExecutor

        def compute_hash(name, meal):
            assert meal.rev
            future = self._nar_hash_bg(meal)
            future.wait()
            if future.returncode != 0:
                stderr_msg = getattr(future, "stderr", "Unknown error")
                raise MrChefError(f"Failed to get NAR hash for {name}: {stderr_msg}")
            return name, meal, future

        with ThreadPoolExecutor(max_workers=max_jobs) as executor:
            futures = []
            for name, meal in hot_meals:
                future = executor.submit(compute_hash, name, meal)
                futures.append(future)

            # Wait for all to complete
            for future in futures:
                name, meal, hash_future = future.result()
                nar_hash_futures[name] = (meal, hash_future)

        logger.debug(
            "Completed parallel NAR hash computation for %d meals", len(hot_meals)
        )
        return nar_hash_futures

    def _freeze_meal(
        self,
        name: str,
        meal: Meal,
        new_freezer: dict[str, Any],
        old_freezer: dict[str, Any],
        all_spices: set[str],
        nar_hash_future: _CachedFuture | Any | None = None,
    ) -> None:
        """Freeze a single meal into the freezer configuration.

        Args:
            name: Meal identifier.
            meal: Hot meal to freeze.
            new_freezer: Freezer configuration being built.
            old_freezer: Old freezer configuration.
            all_spices: Set of all spice URLs to track.
            nar_hash_future: Optional future with NAR hash computation result.
        """
        assert meal.rev

        last_update = meal.last_update
        # Keep last update date from old freezer if rev stays the same
        old_meal = old_freezer.get("meals", {}).get(name, {})
        if old_meal.get("rev") == meal.rev:
            last_update = old_meal.get("last_update", last_update)
        new_freezer["meals"][name] = {
            "last_update": last_update,
            "rev": meal.rev,
        }

        if nar_hash_future:
            new_freezer["meals"][name]["nar_hash"] = json.loads(nar_hash_future.stdout)

        # Force cast to str for compatibility with rtoml.dump
        for spice_url in map(str, meal.spices):
            all_spices.add(spice_url)
            spice_content = self._get_spice_content(spice_url)
            new_freezer["spices"][spice_url] = spice_content
            local_patch = self.path / spice_url
            if self._is_auto_patch(local_patch) and not local_patch.exists():
                local_patch.write_text(spice_content)
            # Store spice in user config
            meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
            meal_config = cast(dict[str, Any], meals_dict.get(name, {}))
            if spice_url not in meal_config.get("spices", []):
                spices_list = cast(list[str], meal_config.setdefault("spices", []))
                spices_list.append(spice_url)

    def freeze(
        self, jobs: int | None = None, old_freezer: dict[str, Any] | None = None
    ) -> None:
        """Get meals from the kitchen and put them in the freezer.

        Args:
            jobs: Maximum number of parallel jobs (None uses MAX_PARALLEL_JOBS).
            old_freezer: Optional old freezer state to preserve last_update dates.
                If not provided, will be read from disk.
        """
        logger.info("Freezing...")
        new_freezer: dict[str, Any] = {
            "version": FREEZER_VERSION,
            "meals": {},
            "spices": {},
        }
        all_spices: set[str] = set()
        for meal in self.config_user.get("meals", {}).values():
            for spice in meal.get("spices", []):
                all_spices.add(str(spice))
        hot_meals = sorted(self.hot_meals().items())
        # Compute NAR hashes in parallel if required
        nar_hash_futures = {}
        if self.config_user.get("require_nar_hash"):
            nar_hash_futures = self._compute_nar_hashes_parallel(hot_meals, jobs)
        # Freeze each meal
        if old_freezer is None:
            old_freezer = self._parse_freezer()
        for name, meal in hot_meals:
            nar_hash_future = nar_hash_futures.get(name, (None, None))[1]
            self._freeze_meal(
                name, meal, new_freezer, old_freezer, all_spices, nar_hash_future
            )
        # Sort entries for deterministic output
        new_freezer["meals"] = dict(sorted(new_freezer["meals"].items()))
        new_freezer["spices"] = dict(sorted(new_freezer["spices"].items()))
        # Write freezer file
        with self.freezer_file.open("w") as fd:
            fd.write("# MrChef's freezer. MANUAL CHANGES WILL BE OVERRIDDEN.\n")
            rtoml.dump(new_freezer, fd, pretty=True)
        self.config_frozen = new_freezer
        # Because maybe we detected hot patches in the mean time
        self.update_user_config()
        # Remove dangling spices
        for spice in self.kitchen.glob("mrchef-*.patch"):
            if str(spice.relative_to(self.path)) not in all_spices:
                spice.unlink()

    def meal_add(
        self, meal_path: Path, url: str, branch: str, rev: str | None = None
    ) -> None:
        """Add a new meal to the kitchen and the freezer."""
        meal_path = meal_path.absolute()
        kitchen = self.kitchen.absolute()
        if not meal_path.is_relative_to(kitchen):
            raise MrChefError(
                f"The meal path must be inside the configured kitchen {kitchen}"
            )
        key = str(meal_path.relative_to(kitchen))
        self.config_user.setdefault("meals", {})
        logger.info(
            "Adding meal %s: remote=%s branch=%s rev=%s",
            key,
            url,
            branch,
            rev,
        )
        meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
        meals_dict[key] = {"url": url, "branch": branch}
        if rev:
            meal_config = cast(dict[str, Any], meals_dict.get(key, {}))
            meal_config["rev"] = rev
        self.warmup(meal_path)
        self.freeze()

    def meal_rm(self, meal_path: Path) -> None:
        """Remove a meal from the kitchen."""
        meals = self.cold_meals()
        key = self._get_meal_key_by_path(meal_path)
        meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
        del meals_dict[key]
        logger.info("Removing meal %s", key)
        with suppress(FileNotFoundError):
            rmtree(meals[key].path)
        self.freeze()

    def spice_add(self, meal_path: Path, url: str) -> None:
        """Download a patch and spice up meal with it."""
        if git_is_dirty(meal_path):
            raise MrChefError("Cannot add spice to dirty meal {meal_path}")
        key = self._get_meal_key_by_path(meal_path)
        meal = self.hot_meals(key)[key]
        content = self._get_spice_content(url, True)
        if self.spice_is_applied(meal.path, content):
            raise MrChefError(f"Spice already exists: {url}")
        self.spice_apply(meal_path, url, content)
        meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
        meal_config = cast(dict[str, Any], meals_dict.get(key, {}))
        meal_config.setdefault("spices", [])
        if self.spice_is_applied(meal.path, content):
            # Add spice directly if it was added cleanly
            spices_list = cast(list[str], meal_config.get("spices", []))
            spices_list.append(url)
        else:
            # If we reach here, it's because Git's 3-way merge applied an
            # auto-fixed patch. In that case, just record the original patch
            # URL as a comment and let `freeze()` auto-create the local patch.
            logger.warning(
                "Spice %s was not applied cleanly; storing local version with modifications",
                url,
            )
            spices_item = cast(Array, meal_config.get("spices"))
            spices_item.add_line(comment=f"Locally modified {url}")
            spices_item.multiline(True)
        self.freeze()

    def spice_rm(self, meal_path: Path, url: str, freeze: bool = True) -> None:
        """Remove a patch from a meal.

        After successfully removing it, the meal will be re-warmed up and the
        config and freezer files will be updated.

        Args:
            meal_path: Where to find the meal.
            url: Spice URL to remove.
            freeze: Update the freezer after removing the spice.
        """
        if git_is_dirty(meal_path):
            raise MrChefError("Cannot remove spice from dirty meal {meal_path}")
        key = self._get_meal_key_by_path(meal_path)
        logger.info("Removing spice from %s: %s", key, url)
        meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
        meal_config = cast(dict[str, Any], meals_dict.get(key, {}))
        spices_list = cast(list[str], meal_config.get("spices", []))
        try:
            spices_list.remove(url)
        except ValueError as error:
            raise MrChefError(
                f"Cannot remove spice, not found in meal {key}: {url}"
            ) from error
        # Remove the spices key if it's empty, to make the config more cute
        if not spices_list:
            meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
            meal_config = cast(dict[str, Any], meals_dict.get(key, {}))
            if "spices" in meal_config:
                del meal_config["spices"]
        # If it was an autogenerated patch file, remove it
        patch_file = self.path / url
        if self._is_auto_patch(patch_file):
            patch_file.unlink(missing_ok=True)
        # Clean the kitchen
        self.warmup(meal_path)
        if freeze:
            self.freeze()

    def spice_export(self, url: str) -> str:
        """Export spice contents from the freezer.

        Args:
            url: The url that was frozen.
        """
        return self.config_frozen["spices"][url]

    def spice_is_applied(self, meal_path: Path, spice_content: str) -> bool:
        """Check if a spice is already applied.

        Args:
            meal_path: Where to find the meal.
            spice_content: The patch content.
        """
        # Start by checking if all spice commits are directly included in
        # current branch history.
        # See https://stackoverflow.com/a/43535203/1468388
        spice_map = git_get_patch_ids_map(spice_content)
        _git = git(meal_path)
        if all(
            _git["merge-base", "--is-ancestor", commit, "HEAD"] & TF
            for commit in spice_map.values()
        ):
            return True
        # Assuming that the spice was just applied and that it can contain more
        # than 1 patches, we also compare patch IDs of the latest n commits
        # where n is the number of patches in the spice. If both patch id sets
        # match, we had a clean apply.
        head_patch = git_get_commits_patch(meal_path, "HEAD", len(spice_map))
        head_map = git_get_patch_ids_map(head_patch)
        if spice_map.keys() == head_map.keys():
            return True
        # Fall back to checking if the spice un-applies cleanly
        # See https://stackoverflow.com/a/66755317/1468388
        check = _git["apply", "--reverse", "--check"] << spice_content
        return check & TF

    def spice_apply(
        self,
        meal_path: Path,
        spice_url: str,
        spice_content: str,
        allow_remove: bool = False,
    ) -> None:
        """Spice up a meal.

        Args:
            meal_path: Where to find the meal.
            spice_url: URL of the spice.
            spice_content: The patch content.
            allow_remove: Remove the spice if it was already applied.
        """
        _git = git(meal_path)
        apply = (
            _git["am", "--keep-non-patch", "--3way", "--no-gpg-sign"] << spice_content
        )
        # We only care about pre-applied status if we can remove the spice
        removable_and_was_applied = allow_remove and self.spice_is_applied(
            meal_path, spice_content
        )
        if not removable_and_was_applied:
            old_head = git_rev(meal_path)
            try:
                apply()
            except ProcessExecutionError as error:
                _git("am", "--abort")
                raise MrChefError("Failed to apply spice.", ERROR) from error
            new_head = git_rev(meal_path)
            removable_and_was_applied = old_head == new_head
        if removable_and_was_applied:
            logger.info("Removing outdated spice %s.", spice_url)
            self.spice_rm(meal_path, spice_url, False)

    def update(
        self,
        *meal_paths: Path,
        force: bool = False,
        oldest: int = 0,
        autocommit: bool = False,
        edit: bool = False,
        jobs: int | None = None,
    ) -> None:
        """Update hot meals, store changes in the freezer.

        Args:
            *meal_paths: Meals to update. Skip to select all.
            force: Continue warming up meal if it is dirty.
            oldest: Update this many oldest ones among found meals. If 0, update all.
            autocommit: Commit changes to the meal after updating.
            edit: Open editor to modify commit message before committing.
            jobs: Maximum number of parallel jobs (None uses MAX_PARALLEL_JOBS).
        """
        if autocommit and git_is_dirty(self.path):
            logger.warning(
                "Repo is dirty; autocommit could contain non-mrchef changes."
            )
        meal_keys = (
            {self._get_meal_key_by_path(meal_path) for meal_path in meal_paths}
            if meal_paths
            else list(self.config_frozen.get("meals", {}).keys())
        )
        sorted_keys = sorted(
            meal_keys,
            key=lambda key: (
                self.config_frozen["meals"]
                .get(key, {})
                .get("last_update", datetime.min)
            ),
        )
        # Start with current freezer state to preserve all data
        old_freezer = self._parse_freezer()
        # Ensure meals and spices dicts exist
        old_freezer.setdefault("meals", {})
        old_freezer.setdefault("spices", {})
        updated_count = 0

        if not oldest:
            # Update all meals in one batch
            self._update_batch(sorted_keys, old_freezer, meal_paths, force, jobs)
        else:
            # Update meals one by one until we reach oldest number of actual updates
            for key in sorted_keys:
                if updated_count >= oldest:
                    break
                batch_updated = self._update_batch(
                    [key], old_freezer, meal_paths, force, jobs
                )
                updated_count += batch_updated

        # Freeze once at the end, using the saved old_freezer to preserve last_update
        self.freeze(jobs=jobs, old_freezer=old_freezer)

        if autocommit:
            self._autocommit(old_freezer, edit)

    def _update_batch(
        self,
        keys_to_update: list[str],
        old_freezer: dict[str, dict[str, Any]],
        meal_paths: tuple[Path, ...],
        force: bool,
        jobs: int | None,
    ) -> int:
        """Update a batch of meals and return how many were actually updated.

        Args:
            keys_to_update: List of meal keys to update in this batch.
            old_freezer: Dict with "meals" and "spices" to store old state.
            meal_paths: Meals to update paths.
            force: Continue warming up meal if it is dirty.
            jobs: Maximum number of parallel jobs.

        Returns:
            Number of meals that were actually updated (revision changed).
        """
        frozen_meals = cast(dict[str, Any], self.config_frozen.get("meals", {}))
        frozen_spices = cast(dict[str, Any], self.config_frozen.get("spices", {}))

        old_hot_revs = {}
        for key in keys_to_update:
            # Save to old_freezer before popping (only if not already saved)
            if key in frozen_meals and key not in old_freezer.get("meals", {}):
                old_freezer["meals"][key] = frozen_meals[key].copy()
            # Pop to force warmup to process this meal
            frozen_meals.pop(key, None)

            user_meals = cast(dict[str, Any], self.config_user.get("meals", {}))
            user_meal = cast(dict[str, Any], user_meals.get(key, {}))
            for spice in user_meal.get("spices", []):
                if spice in frozen_spices and spice not in old_freezer.get(
                    "spices", {}
                ):
                    old_freezer["spices"][spice] = frozen_spices[spice].copy()
                frozen_spices.pop(spice, None)

            # Get current hot revision before warmup
            bimeal = self.all_meals().get(key)
            old_hot_revs[key] = bimeal.hot.rev if bimeal and bimeal.hot else None

        self.warmup(*meal_paths, force=force, autoremove_spices=True, jobs=jobs)

        updated_count = 0
        for key in keys_to_update:
            bimeal = self.all_meals().get(key)
            new_hot_rev = bimeal.hot.rev if bimeal and bimeal.hot else None
            if old_hot_revs[key] != new_hot_rev:
                updated_count += 1

        return updated_count

    def _autocommit(self, old_freezer: dict[str, Any], edit: bool = False) -> None:
        """Get commit message for an update.

        The message respects [Conventional
        Commits](https://www.conventionalcommits.org/).

        Args:
            old_freezer:
                Old freezer state with "meals" dict containing meal data.
                Each meal should have a "rev" key with the old revision.
            edit: Open editor to modify commit message before committing.
        """
        if not git_is_dirty(self.path):
            logger.info("Nothing to commit.")
            return
        lines = ["build(mrchef): update kitchen", ""]
        old_meals = old_freezer.get("meals", {})
        for key, old_meal_data in old_meals.items():
            old_long = old_meal_data.get("rev") if old_meal_data else None
            meals_dict = cast(dict[str, Any], self.config_user.get("meals", {}))
            meal_config = cast(dict[str, Any], meals_dict.get(key, {}))
            repo_url = str(meal_config.get("url", ""))
            frozen_meals = cast(dict[str, Any], self.config_frozen.get("meals", {}))
            frozen_meal = cast(dict[str, Any], frozen_meals.get(key, {}))
            new_long = str(frozen_meal.get("rev", ""))
            new_short = new_long[:8]
            if old_long is None:
                try:
                    lines.append(
                        f"- {key}: Frozen at [{new_short}]({commit_url(repo_url, new_long)})"
                    )
                except NotImplementedError:
                    lines.append(f"- {key}: Frozen at {new_long}")
                continue
            old_short = old_long[:8]
            if old_long == new_long:
                continue
            try:
                lines.append(
                    f"- {key}: [{old_short}..{new_short}]({commit_range_url(repo_url, old_long, new_long)})"
                )
            except NotImplementedError:
                lines.append(f"- {key}: {old_long}..{new_long}")
        logger.info("Committing changes")
        _git = git(self.path)
        _git("add", self.config_file, self.freezer_file, self.kitchen)
        _commit = _git["commit", "-am", "\n".join(lines)]
        if edit:
            _commit = _commit["--edit"]
        # Pre-commit can fail; attempt to commit twice
        try:
            _commit()
        except ProcessExecutionError:
            _commit()


def commit_url(repo_url: str, commit_sha: str) -> str:
    """Get the URL to a commit in a repository."""
    with suppress(TypeError):
        gh_url = github_url(repo_url)
        if gh_url:
            return gh_url + f"/commit/{commit_sha}"
    with suppress(TypeError):
        gl_url = gitlab_url(repo_url)
        if gl_url:
            return gl_url + f"/-/commit/{commit_sha}"
    raise NotImplementedError(f"Unknown repository URL: {repo_url}")


def commit_range_url(repo_url: str, commit_from: str, commit_to: str) -> str:
    """Get the URL to a commit range in a repository."""
    with suppress(TypeError):
        gh_url = github_url(repo_url)
        if gh_url:
            return gh_url + f"/compare/{commit_from}...{commit_to}"
    with suppress(TypeError):
        gl_url = gitlab_url(repo_url)
        if gl_url:
            return gl_url + f"/-/compare/{commit_from}...{commit_to}"
    raise NotImplementedError(f"Unknown repository URL: {repo_url}")


def parse_git_url(url: str) -> ParseResult:
    """Normalize a Git URL and return it parsed."""
    parsed = urlparse(url)
    if not parsed.scheme and not parsed.netloc:
        # SSH URL
        url = "ssh://" + url.replace(":", ":22/", 1)
        return urlparse(url)
    return parsed


@lru_cache
def github_token() -> str | None:
    """Get a Github token from environment or from the gh CLI."""
    try:
        return os.environ["GITHUB_TOKEN"]
    except KeyError:
        with suppress(CommandNotFound, ProcessExecutionError):
            return local["gh"]("auth", "token", "--hostname", "github.com").strip()
    return None


def github_url(url: str) -> str | None:
    """Get browsable URL for a repo, if it is from Github.

    Args:
        url: The URL to check.
    """
    parsed = parse_git_url(url)
    if parsed.hostname != "github.com":
        return None
    owner, repo, *_rest = parsed.path.split("/")[1:]
    repo = repo.removesuffix(".git")
    return f"https://github.com/{owner}/{repo}"


def gitlab_url(url: str) -> str | None:
    """Get browsable URL for a repo, if it is from Gitlab.

    Since Gitlab can be self-hosted, to be sure it is Gitlab, the host name
    must contain the word "gitlab" somewhere.

    Sample URLs supported:
    - https://gitlab.com/owner/repo
    - https://gitlab.example.com/group/subgroup/repo.git
    - https://gitlab.example.com/owner/repo
    - https://gitlab.example.com/owner/repo/-/merge_requests/1
    - https://gitlab.example.com/group/subgroup/repo/-/merge_requests/1
    - git@gitlab.com:group/subgroup/repo.git
    - ssh://git@gitlab.example.com:2222/group/subgroup/repo.git

    Args:
        url: The URL to check.
    """
    url = url.split("/-/")[0].removesuffix(".git")
    parsed = parse_git_url(url)
    if not parsed.hostname or "gitlab" not in parsed.hostname:
        return None
    if parsed.scheme == "ssh":
        return f"https://{parsed.hostname}{parsed.path}"
    return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"


def download_spice(spice_url: str) -> str:
    """Download spice from URL.

    Supports these URL formats:

    - Gitlab merge request, like https://gitlab.com/moduon/mrchef/-/merge_requests/1
    - Gitlab commit, like https://gitlab.com/moduon/mrchef/-/commit/4699372d84f7f67b52fc7548f606e9a42559b5c2
    - Github pull request, like https://github.com/octocat/Hello-World/pull/1
    - Github commit, like https://github.com/octocat/Hello-World/commit/7fd1a60b01f91b314f59955a4e4d4e80d8edf11d
    - Any other URL, downloaded without modifications.
    """
    request_params = {}
    parsed_url = urlparse(spice_url)
    transformed_url = spice_url
    # Get Github spices from API
    if github_url(spice_url):
        mime = "diff" if parsed_url.path.endswith(".diff") else "patch"
        request_params["headers"] = {
            "Accept": f"application/vnd.github.v3.{mime}",
        }
        if token := github_token():
            # Authenticate with Github API
            request_params["headers"]["Authorization"] = f"Bearer {token}"
        else:
            logger.warning(
                f"Downloading spice from Github without authentication: {spice_url}"
            )
        # Alter spice URL to use API
        match (
            parsed_url.path.strip("/")
            .removesuffix(".diff")
            .removesuffix(".patch")
            .split("/")
        ):
            case [org, repo, "pull", pr_number] if pr_number.isdecimal():
                transformed_url = (
                    f"https://api.github.com/repos/{org}/{repo}/pulls/{pr_number}"
                )
            case [org, repo, "commit", commit_sha]:
                transformed_url = (
                    f"https://api.github.com/repos/{org}/{repo}/commits/{commit_sha}"
                )
            case [org, repo, "files", *_]:
                pass  # Download files directly
            case _:
                transformed_url = spice_url.rstrip("/") + f".{mime}"
    elif gitlab_url(spice_url) and not parsed_url.path.endswith(".patch"):
        # TODO Handle Gitlab authentication
        transformed_url = spice_url.rstrip("/") + ".patch"
    # Report transformation
    if transformed_url != spice_url:
        logger.debug(
            "Attempting to download transformed spice URL: %s ➡️ %s",
            spice_url,
            transformed_url,
        )
    try:
        response = requests.get(transformed_url, **request_params)
        response.raise_for_status()
    except HTTPError:
        if transformed_url == spice_url:
            raise
        # Fallback to original URL
        logger.debug("Attempting to download spice from %s", spice_url)
        response = requests.get(spice_url, **request_params)
        response.raise_for_status()
    return response.text


def git(folder: Path | None = None) -> BaseCommand:
    """Get a git executable ready to operate in `folder`."""
    _git = local["git"]
    if folder:
        _git = _git["-C", folder]
    return _git


def git_branch(folder: Path) -> str:
    """Get current branch name in that git folder."""
    return git(folder)("rev-parse", "--abbrev-ref", "HEAD").strip()


def git_commit_patch_id(folder: Path, commit_id: str) -> str:
    """Get the patch ID from a commit ID.

    And what is a patch ID? See https://git-scm.com/docs/git-patch-id

    Args:
        folder: Path to git repo.
        commit_id: Commit ID to get the patch ID from.
    """
    commit_patch = git_get_commits_patch(folder, commit_id)
    patch_id_map = git_get_patch_ids_map(commit_patch)
    assert len(patch_id_map) == 1
    return list(patch_id_map)[0]


def git_commits_diff(folder: Path, rev1: str | None, rev2: str) -> list[str]:
    """Get differential commits between rev1 and rev2."""
    if rev1 is None:
        raise ValueError("rev1 cannot be None")
    return git(folder)(
        "log", "--topo-order", "--reverse", "--format=%H", f"{rev1}...{rev2}"
    ).splitlines()


def git_get_commits_patch(folder: Path, commits: str, amount: int = 1) -> str:
    """Get patch text contents from git commit(s).

    Args:
        folder: Path to git repo.
        commits: Commit ID or range of commits.
        amount: Number of commits to get.
    """
    cmd = git(folder)["format-patch", "--stdout", "--binary", commits]
    if amount > 0:
        cmd = cmd[f"-{amount}"]
    return cmd()


def git_get_patch_ids_map(patch_text: str) -> dict:
    """Get patch ids from patch text."""
    patch_id_map = git()["patch-id", "--stable"] << patch_text
    return {
        patch_id: commit_id
        for patch_id, commit_id in (
            line.split() for line in patch_id_map().splitlines()
        )
    }


def git_is_dirty(folder: Path) -> bool:
    """Know if the folder is a dirty git repository."""
    _git = git(folder)
    if _git("status", "--porcelain"):
        return True
    if _git("am", "--show-current-patch", retcode=None):
        return True
    return False


def git_origin(folder: Path) -> str:
    """Know the git origin URL for Mr. Chef's default origin."""
    _git = git(folder)
    # See https://stackoverflow.com/a/60297250/1468388
    status = _git("status", "--branch", "--porcelain=v2")
    if not (match := re.search(r"^# branch.upstream (.*)/.*$", status, re.MULTILINE)):
        raise MrChefError(
            f"Couldn't guess remote origin for {folder}. "
            "Please make sure it's checked out in a branch with a remote."
        )
    origin = match[1]
    return _git("remote", "get-url", origin).strip()


def git_merge_base(folder: Path, rev1: str, rev2: str) -> str:
    """Know the closest common ancestor commit of 2 git revisions.

    Args:
        folder: Path to git repo.
        rev1: First commit to compare.
        rev2: Second commit to compare.
    """
    return git(folder)("merge-base", rev1, rev2).strip()


def git_remote_head_bg(
    folder: Path, remote_url: str, remote_ref: str, force_fetch: bool = False
) -> Future:
    """Get latest commit sha from remote url and ref combination in background.

    Args:
        folder: Path to git repo.
        remote_url: Absolute URL to remote.
        remote_ref: Branch or revision to query from remote.
        force_fetch: Do not use a locally cached remote head.

    Returns:
        A Future object that will contain the commit SHA in stdout when waited.
    """
    _git = git(folder)
    remote_alias = git_remote_alias(folder, remote_url)

    # Check if we can use cached remote head
    if not force_fetch and remote_alias:
        try:
            result = _git(
                "rev-parse", f"refs/remotes/{remote_alias}/{remote_ref}"
            ).strip()
            # Return a mock future with cached result
            mock_future = type(
                "MockFuture",
                (),
                {
                    "stdout": result,
                    "stderr": "",
                    "returncode": 0,
                    "wait": lambda _: None,
                },
            )()
            return mock_future
        except ProcessExecutionError:
            # Remote ref not found locally, fetch it
            pass

    # Fetch in background
    logger.debug("Fetching remote head %s from %s", remote_ref, remote_url)
    with local.env(LANG="C"):
        fetch_future = (
            _git["fetch", "--write-fetch-head", remote_alias or remote_url, remote_ref]
            & BG
        )

    # Wrap the fetch future to also run rev-parse after fetch completes
    class RevParseFuture:
        def __init__(self, fetch_fut, git_cmd, remote_ref_val, remote_url_val):
            self._fetch_future = fetch_fut
            self._git = git_cmd
            self._remote_ref = remote_ref_val
            self._remote_url = remote_url_val
            self.returncode = 0
            self.stdout = ""
            self.stderr = ""

        def wait(self):
            try:
                self._fetch_future.wait()
                self.returncode = self._fetch_future.returncode
                self.stderr = self._fetch_future.stderr

                if self.returncode != 0:
                    # Check if it's the "couldn't find remote ref" error
                    if (
                        f"fatal: couldn't find remote ref {self._remote_ref}"
                        in self.stderr
                    ):
                        # This local branch has no equivalent remote branch
                        self.stdout = self._git("rev-parse", "HEAD").strip()
                        self.returncode = 0
                        self.stderr = ""
                    return

                # Fetch succeeded, get FETCH_HEAD
                self.stdout = self._git("rev-parse", "FETCH_HEAD").strip()
            except ProcessExecutionError as error:
                # Handle any other git errors
                if (
                    f"fatal: couldn't find remote ref {self._remote_ref}"
                    in error.stderr
                ):
                    # This local branch has no equivalent remote branch
                    self.stdout = self._git("rev-parse", "HEAD").strip()
                    self.returncode = 0
                    self.stderr = ""
                else:
                    raise

    return RevParseFuture(fetch_future, _git, remote_ref, remote_url)


@lru_cache
def git_remote_head(
    folder: Path, remote_url: str, remote_ref: str, force_fetch: bool = False
) -> str:
    """Get latest commit sha from remote url and ref combination.

    Args:
        folder: Path to git repo.
        remote_url: Absolute URL to remote.
        remote_ref: Branch or revision to query from remote.
        force_fetch: Do not use a locally cached remote head.
    """
    future = git_remote_head_bg(folder, remote_url, remote_ref, force_fetch)
    future.wait()
    if future.returncode != 0:
        raise MrChefError(f"Failed to fetch remote head: {future.stderr}")
    return future.stdout


def git_remote_alias(folder: Path, remote_url: str) -> str:
    """Get local alias of a remote URL.

    Args:
        folder: Path to git repo.
        remote_url: Absolute URL to remote.

    Returns:
        Local alias of the remote, or empty string if not found.
    """
    _git = git(folder)
    # Output is like:
    #   origin  https://gitlab.com/moduon/mrchef (fetch) [blob:none]
    for remote in _git("remote", "-v").splitlines():
        alias, url, mode = remote.split()[:3]
        if url == remote_url and mode == "(fetch)":
            return alias
    return ""


def git_rev(folder: Path) -> str:
    """Know the commit where a git repository is currently checked out."""
    return git(folder)("rev-parse", "--verify", "HEAD").strip()


def git_root(folder: Path) -> Path:
    """Know the root of the git repository that owns a folder."""
    return Path(git(folder)("rev-parse", "--show-toplevel").strip())
