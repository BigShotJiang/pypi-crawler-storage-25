"""Tests for notebook editor."""
