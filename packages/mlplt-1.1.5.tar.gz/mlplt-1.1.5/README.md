# mlpilot 🚀

**The complete machine learning toolkit that just works.**  
One import. One goal. No configuration.

[![v1.0.0](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://pypi.org/project/mlplt/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## The Vision
Most ML libraries require hours of setup, API keys, and complex boilerplate. **mlpilot** changes that. It is designed to be **Zero-Config** and **Unbreakable**, whether you are running on a powerful GPU server, a local laptop, or a free Google Colab notebook.

## Quick Start (Truly Zero-Config)

Install the library:
```bash
pip install mlplt
```

Analyze your data in 3 lines (No API keys or setup needed):
```python
import mlpilot as ml
import seaborn as sns

df = sns.load_dataset('titanic')

# Ask anything in plain English
ans = ml.analyst(df)
ans.ask("What was the survival rate by passenger class? Show a bar chart.", auto_run=True)
```

---

## Key Modules

| Module | Description | Example |
| :--- | :--- | :--- |
| **SmartEDA** | Instant 12-section data analysis reports. | `ml.analyze(df)` |
| **AutoCleaner** | One-click missing value and outlier handling. | `ml.clean(df)` |
| **FeatureForge** | Leakage-safe automated feature engineering. | `ml.features(df)` |
| **BaselineBlitz** | Compare 5+ models in 10 seconds. | `ml.baseline(X, y)` |
| **HyperX** | Fast, budget-aware hyperparameter tuning. | `ml.tune('lgbm', X, y)` |
| **AI Analyst** | Natural language interface to your data. | `ml.analyst(df).ask(...)` |
| **LaunchPad** | Generate FastAPI + Docker deployments instantly. | `ml.deploy(model)` |

---

## Why mlpilot?

- **📦 Zero-Config AI**: Built-in local AI engine (Transformers) for when you don't have API keys. 
- **🧹 Unbreakable Paths**: Works perfectly regardless of your OS, drive letter, or notebook environment.
- **🤫 Professional Silence**: No technical clutter. Just clean, actionable answers.
- **🛠️ Batteries Included**: Everything from cleaning to deployment in a single package.

---

## License
MIT © mlpilot contributors
