"""Harbormaster — MCP server that routes Q&A across many projects and SSH hosts.

Part of the FleetQ ecosystem. Standalone OSS works fully; FleetQ integration is opt-in.
"""

__version__ = "22.0.1"
__all__ = ["__version__"]
