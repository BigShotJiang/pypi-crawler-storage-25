from ete3 import Tree

num_list = list(range(1,160))
print(num_list)
n=10


res = [num_list[i:i + n] for i in range(0, len(num_list), n)]
print(res)