from __future__ import annotations

from urllib.parse import quote, urlencode
import base64
import json
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, cast
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .types import (
    ErrorEnvelope,
    PolicyGateRequest,
    PolicyGateResponse,
    RiskScoreRequest,
    RiskScoreResponse,
    SimulateRequest,
    SimulateResponse,
    X402PaymentRequired,
    X402PaymentResponse,
)

PAYMENT_SIGNATURE_HEADER = "PAYMENT-SIGNATURE"
PAYMENT_REQUIRED_HEADER = "PAYMENT-REQUIRED"
PAYMENT_RESPONSE_HEADER = "PAYMENT-RESPONSE"


@dataclass
class ActionGateClientConfig:
    base_url: str = "https://api.actiongate.xyz"
    api_key: Optional[str] = None
    payment_signature: Optional[str] = None
    x402_proof: Optional[str] = None
    timeout_seconds: float = 15.0


class ActionGateError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        code: Optional[str] = None,
        request_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        payment_required: Optional[X402PaymentRequired] = None,
        payment_response: Optional[X402PaymentResponse] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.request_id = request_id
        self.details = details
        self.payment_required = payment_required
        self.payment_response = payment_response


class ActionGateClient:
    def __init__(
        self,
        *,
        base_url: str = "https://api.actiongate.xyz",
        api_key: Optional[str] = None,
        payment_signature: Optional[str] = None,
        x402_proof: Optional[str] = None,
        timeout_seconds: float = 15.0,
        opener: Optional[Callable[[Request, float], Any]] = None,
    ) -> None:
        self._config = ActionGateClientConfig(
            base_url=base_url.rstrip("/"),
            api_key=api_key,
            payment_signature=payment_signature,
            x402_proof=x402_proof,
            timeout_seconds=timeout_seconds,
        )
        self._opener = opener or (lambda request, timeout: urlopen(request, timeout=timeout))
        self.last_payment_response: Optional[X402PaymentResponse] = None

    def risk_score(self, payload: RiskScoreRequest) -> RiskScoreResponse:
        return cast(RiskScoreResponse, self._request("/v1/risk-score", payload))

    def simulate(self, payload: SimulateRequest) -> SimulateResponse:
        return cast(SimulateResponse, self._request("/v1/simulate", payload))

    def policy_gate(self, payload: PolicyGateRequest) -> PolicyGateResponse:
        return cast(PolicyGateResponse, self._request("/v1/policy-gate", payload))

    def proxy_call(
        self,
        tool_name: str,
        payload: Optional[Dict[str, Any]] = None,
        method: str = "POST",
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        return self._request(
            f"/proxy/{quote(tool_name, safe='')}",
            payload,
            method=method,
            headers=headers,
        )

    def _request(
        self,
        path: str,
        payload: Optional[Dict[str, Any]],
        *,
        method: str = "POST",
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        request_headers: Dict[str, str] = {}
        if headers:
            request_headers.update(headers)
        if self._config.api_key:
            request_headers["X-API-Key"] = self._config.api_key

        signature = self._config.payment_signature or self._config.x402_proof
        if signature:
            request_headers[PAYMENT_SIGNATURE_HEADER] = signature

        normalized_method = method.upper()
        request_url = f"{self._config.base_url}{path}"
        body: Optional[bytes] = None

        if normalized_method in {"GET", "DELETE"}:
            query = urlencode(_normalize_query_payload(payload), doseq=True)
            if query:
                request_url = f"{request_url}?{query}"
        elif normalized_method in {"POST", "PUT", "PATCH"}:
            request_headers["Content-Type"] = "application/json"
            body = json.dumps(payload or {}).encode("utf-8")
        else:
            raise ValueError(f"Unsupported proxy method: {method}")

        request = Request(
            request_url,
            data=body,
            headers=request_headers,
            method=normalized_method,
        )

        try:
            raw_response = self._opener(request, self._config.timeout_seconds)
            status_code = getattr(raw_response, "status", 200)
            raw_payload = raw_response.read().decode("utf-8")
            parsed_payload: Any = json.loads(raw_payload) if raw_payload else {}

            payment_required = _decode_base64_json(
                raw_response.headers.get(PAYMENT_REQUIRED_HEADER)
            )
            payment_response = _decode_base64_json(
                raw_response.headers.get(PAYMENT_RESPONSE_HEADER)
            )
            self.last_payment_response = cast(Optional[X402PaymentResponse], payment_response)

            if status_code >= 400:
                raise self._build_error(
                    status_code,
                    parsed_payload,
                    payment_required=cast(Optional[X402PaymentRequired], payment_required),
                    payment_response=cast(Optional[X402PaymentResponse], payment_response),
                )
            return parsed_payload
        except HTTPError as exc:
            error_payload = _safe_load_json(exc.read().decode("utf-8"))
            payment_required = _decode_base64_json(exc.headers.get(PAYMENT_REQUIRED_HEADER))
            payment_response = _decode_base64_json(exc.headers.get(PAYMENT_RESPONSE_HEADER))
            raise self._build_error(
                exc.code,
                error_payload,
                payment_required=cast(Optional[X402PaymentRequired], payment_required),
                payment_response=cast(Optional[X402PaymentResponse], payment_response),
            ) from exc
        except URLError as exc:
            raise ActionGateError(
                f"Network failure: {exc.reason}",
                status_code=0,
                code="NETWORK_ERROR",
            ) from exc

    def _build_error(
        self,
        status_code: int,
        payload: Any,
        *,
        payment_required: Optional[X402PaymentRequired] = None,
        payment_response: Optional[X402PaymentResponse] = None,
    ) -> ActionGateError:
        if _is_error_envelope(payload):
            error_body = payload["error"]
            return ActionGateError(
                error_body.get("message", f"ActionGate request failed ({status_code})."),
                status_code=status_code,
                code=error_body.get("code"),
                request_id=error_body.get("request_id"),
                details=cast(Optional[Dict[str, Any]], error_body.get("details")),
                payment_required=payment_required,
                payment_response=payment_response,
            )
        return ActionGateError(
            f"ActionGate request failed ({status_code}).",
            status_code=status_code,
            code="REQUEST_FAILED",
            payment_required=payment_required,
            payment_response=payment_response,
        )


def _is_error_envelope(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    error = payload.get("error")
    return isinstance(error, dict) and isinstance(error.get("code"), str)


def _safe_load_json(value: str) -> Any:
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return {}


def _decode_base64_json(value: Optional[str]) -> Optional[Dict[str, Any]]:
    if value is None or value == "":
        return None
    try:
        decoded = base64.b64decode(value).decode("utf-8")
        parsed = json.loads(decoded)
        if isinstance(parsed, dict):
            return cast(Dict[str, Any], parsed)
        return None
    except Exception:
        return None


def _normalize_query_payload(payload: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not payload:
        return {}

    normalized: Dict[str, Any] = {}
    for key, value in payload.items():
        normalized[key] = _normalize_query_value(value)
    return normalized


def _normalize_query_value(value: Any) -> Any:
    if isinstance(value, list):
        return [_normalize_query_value(entry) for entry in value]
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float, str)):
        return value
    return json.dumps(value)
