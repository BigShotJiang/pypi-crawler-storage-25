from __future__ import annotations

import base64
import json
import unittest
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qsl, unquote, urlparse

from actiongate_sdk.client import ActionGateClient, ActionGateError


class FakeResponse:
    def __init__(
        self,
        payload: Dict[str, Any],
        *,
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        self._payload = json.dumps(payload).encode("utf-8")
        self.status = status
        self.headers = headers or {}

    def read(self) -> bytes:
        return self._payload


def normalized_headers(request: Any) -> Dict[str, str]:
    return {key.lower(): value for key, value in request.header_items()}


class ProxyCallTests(unittest.TestCase):
    def test_risk_score_still_uses_the_shared_post_request_path(self) -> None:
        seen_requests: List[Any] = []

        def opener(request, timeout):
            seen_requests.append((request, timeout))
            return FakeResponse({"request_id": "req-123", "score": 80})

        client = ActionGateClient(
            base_url="https://api.actiongate.xyz",
            payment_signature="payment-sig-456",
            opener=opener,
        )

        result = client.risk_score(
            {
                "actor": {"actor_id": "treasury-bot"},
                "action": {"action_type": "transfer", "network": "base"},
            }
        )

        request, timeout = seen_requests[0]
        self.assertEqual(result, {"request_id": "req-123", "score": 80})
        self.assertEqual(timeout, 15.0)
        self.assertEqual(request.get_method(), "POST")
        self.assertEqual(request.full_url, "https://api.actiongate.xyz/v1/risk-score")
        self.assertEqual(json.loads(request.data.decode("utf-8"))["actor"], {"actor_id": "treasury-bot"})
        self.assertEqual(normalized_headers(request)["content-type"], "application/json")
        self.assertEqual(normalized_headers(request)["payment-signature"], "payment-sig-456")

    def test_proxy_call_uses_query_string_for_get_and_delete(self) -> None:
        seen_requests: List[Any] = []

        def opener(request, timeout):
            seen_requests.append((request, timeout))
            return FakeResponse({"ok": True})

        client = ActionGateClient(
            base_url="https://api.actiongate.xyz",
            api_key="api-key-123",
            payment_signature="payment-sig-456",
            opener=opener,
        )

        for method, payload, expected_query in (
            ("GET", {"q": "hello world", "limit": 3}, [("q", "hello world"), ("limit", "3")]),
            ("DELETE", {"tool": "archive", "dryRun": True, "cursor": None}, [("tool", "archive"), ("dryRun", "true"), ("cursor", "null")]),
        ):
            with self.subTest(method=method):
                seen_requests.clear()
                result = client.proxy_call(
                    "search_status",
                    payload,
                    method=method,
                    headers={"X-Trace-Id": "trace-123"},
                )

                request, timeout = seen_requests[0]
                self.assertEqual(result, {"ok": True})
                self.assertEqual(timeout, 15.0)
                self.assertEqual(request.get_method(), method)
                self.assertIsNone(request.data)
                self.assertEqual(
                    request.full_url,
                    "https://api.actiongate.xyz/proxy/search_status?q=hello+world&limit=3"
                    if method == "GET"
                    else "https://api.actiongate.xyz/proxy/search_status?tool=archive&dryRun=true&cursor=null",
                )
                self.assertEqual(parse_qsl(urlparse(request.full_url).query), expected_query)
                headers = normalized_headers(request)
                self.assertEqual(headers["x-api-key"], "api-key-123")
                self.assertEqual(headers["payment-signature"], "payment-sig-456")
                self.assertEqual(headers["x-trace-id"], "trace-123")

    def test_proxy_call_json_encodes_nested_query_values_and_tool_name(self) -> None:
        seen_requests: List[Any] = []

        def opener(request, timeout):
            seen_requests.append((request, timeout))
            return FakeResponse({"ok": True})

        client = ActionGateClient(
            base_url="https://api.actiongate.xyz",
            opener=opener,
        )

        result = client.proxy_call(
            "search/status v2",
            {
                "context": {"kind": "active"},
                "tags": ["alpha", {"label": "beta"}],
            },
            method="GET",
        )

        request, _ = seen_requests[0]
        self.assertEqual(result, {"ok": True})
        parsed_url = urlparse(request.full_url)
        self.assertEqual(
            unquote(parsed_url.path),
            "/proxy/search/status v2",
        )
        self.assertEqual(
            parse_qsl(parsed_url.query),
            [
                ("context", '{"kind": "active"}'),
                ("tags", "alpha"),
                ("tags", '{"label": "beta"}'),
            ],
        )

    def test_proxy_call_uses_json_body_for_post_put_patch(self) -> None:
        seen_requests: List[Any] = []

        def opener(request, timeout):
            seen_requests.append((request, timeout))
            return FakeResponse({"ok": True})

        client = ActionGateClient(base_url="https://api.actiongate.xyz", opener=opener)

        for method in ("POST", "PUT", "PATCH"):
            with self.subTest(method=method):
                seen_requests.clear()
                payload = {"text": "hello world", "count": 2}
                result = client.proxy_call("create_post", payload, method=method)

                request, _ = seen_requests[0]
                self.assertEqual(result, {"ok": True})
                self.assertEqual(request.get_method(), method)
                self.assertEqual(request.full_url, "https://api.actiongate.xyz/proxy/create_post")
                self.assertEqual(json.loads(request.data.decode("utf-8")), payload)
                self.assertEqual(normalized_headers(request)["content-type"], "application/json")

    def test_proxy_call_keeps_payment_wrappers_on_error_responses(self) -> None:
        payment_payload = {
            "success": True,
            "payer": "0xabc123",
            "transaction": "0xdeadbeef",
            "network": "base",
        }

        def opener(request, timeout):
            del request, timeout
            return FakeResponse(
                {
                    "error": {
                        "code": "UPSTREAM_REJECTED",
                        "message": "upstream refused the request",
                        "request_id": "req-123",
                        "details": {"reason": "policy"},
                    }
                },
                status=422,
                headers={
                    "PAYMENT-REQUIRED": base64.b64encode(
                        json.dumps({"x402Version": 2, "error": "payment required"}).encode("utf-8")
                    ).decode("utf-8"),
                    "PAYMENT-RESPONSE": base64.b64encode(json.dumps(payment_payload).encode("utf-8")).decode(
                        "utf-8"
                    ),
                },
            )

        client = ActionGateClient(base_url="https://api.actiongate.xyz", opener=opener)

        with self.assertRaises(ActionGateError) as ctx:
            client.proxy_call("create_post", {"title": "Launch"})

        error = ctx.exception
        self.assertEqual(error.status_code, 422)
        self.assertEqual(error.code, "UPSTREAM_REJECTED")
        self.assertEqual(error.request_id, "req-123")
        self.assertEqual(error.details, {"reason": "policy"})
        self.assertEqual(client.last_payment_response, payment_payload)


if __name__ == "__main__":
    unittest.main()
