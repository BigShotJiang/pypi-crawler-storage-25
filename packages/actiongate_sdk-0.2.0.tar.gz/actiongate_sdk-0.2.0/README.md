# actiongate-sdk

Python SDK for the ActionGate API.

## Install

```bash
pip install actiongate-sdk
```

## Custom Proxy Usage

Use `proxy_call(tool_name, payload=None, method="POST", headers=None)` to call a configured `/proxy/:toolName` route.

- `GET` and `DELETE` encode `payload` as query parameters.
- `POST`, `PUT`, and `PATCH` send `payload` as a JSON body.
- `headers` lets you pass custom upstream headers for the proxy call.

```python
from actiongate_sdk import ActionGateClient

client = ActionGateClient(base_url="https://api.actiongate.xyz")
result = client.proxy_call(
    "search_status",
    {"q": "hello world"},
    method="GET",
    headers={"Authorization": "Bearer upstream-secret"},
)
```

## Methods

- `proxy_call(tool_name, payload=None, method="POST", headers=None)`
- `risk_score(payload)`
- `simulate(payload)`
- `policy_gate(payload)`

## Example

```python
from actiongate_sdk import ActionGateClient

client = ActionGateClient(base_url="https://api.actiongate.xyz")
result = client.risk_score({
    "actor": {"actor_id": "treasury-bot"},
    "action": {"action_type": "transfer", "network": "base", "asset_symbol": "USDC", "amount": "2500"},
})
```

## x402 V2 Support

- Sends `PAYMENT-SIGNATURE` when `payment_signature` is configured.
- Parses `PAYMENT-REQUIRED` and `PAYMENT-RESPONSE`.
- Exposes parsed metadata via `ActionGateError` and `client.last_payment_response`.
