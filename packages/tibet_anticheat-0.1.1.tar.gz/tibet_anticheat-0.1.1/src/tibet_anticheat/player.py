"""
Player Profiles — FIR/A trust scoring for gamers.

Each player has a trust profile that evolves over time:
- Play fairly → trust goes up
- Anomalies detected → trust goes down
- Consistent patterns → trust stabilizes

High-trust players get less scrutiny.
Low-trust players get more analysis.
Zero-trust players get flagged for review.
"""

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .detector import Detection, CheatType


@dataclass
class PlayerProfile:
    """
    A player's anti-cheat profile with FIR/A-style trust.

    Trust components:
    - Fair Play Score: ratio of clean sessions
    - Integrity Score: action chain integrity
    - Recency: recent behavior weighs more
    - Anomaly Score: detected anomalies reduce trust
    """
    player_id: str
    trust_score: float = 0.7     # Start with reasonable trust
    total_sessions: int = 0
    clean_sessions: int = 0
    flagged_sessions: int = 0
    total_actions: int = 0
    total_detections: int = 0
    detections_by_type: dict[str, int] = field(default_factory=dict)
    first_seen: str = ""
    last_seen: str = ""
    last_detection: str = ""
    banned: bool = False
    ban_reason: str = ""

    # FIR/A components
    fair_play: float = 1.0
    integrity: float = 1.0
    recency: float = 0.5
    anomaly: float = 1.0

    def record_session(self, detections: list[Detection]) -> float:
        """Record a game session and update trust."""
        now = datetime.now(timezone.utc).isoformat()
        self.total_sessions += 1
        self.last_seen = now
        if not self.first_seen:
            self.first_seen = now

        if detections:
            self.flagged_sessions += 1
            self.total_detections += len(detections)
            self.last_detection = now
            for d in detections:
                key = d.cheat_type.value
                self.detections_by_type[key] = self.detections_by_type.get(key, 0) + 1
        else:
            self.clean_sessions += 1

        self._recalculate_trust()
        return self.trust_score

    def record_actions(self, count: int) -> None:
        """Record action count for stats."""
        self.total_actions += count

    def ban(self, reason: str) -> None:
        """Ban a player."""
        self.banned = True
        self.ban_reason = reason
        self.trust_score = 0.0

    def unban(self) -> None:
        """Unban a player."""
        self.banned = False
        self.ban_reason = ""
        self._recalculate_trust()

    def _recalculate_trust(self) -> None:
        """Recalculate trust using FIR/A-style scoring."""
        # Fair Play: clean sessions / total sessions
        if self.total_sessions > 0:
            self.fair_play = self.clean_sessions / self.total_sessions
        else:
            self.fair_play = 1.0

        # Integrity: inverse of detection rate
        if self.total_actions > 0:
            detection_rate = self.total_detections / self.total_actions
            self.integrity = max(0.0, 1.0 - detection_rate * 100)
        else:
            self.integrity = 1.0

        # Recency: recent clean play recovers trust
        if self.last_detection and self.last_seen:
            last_det = datetime.fromisoformat(self.last_detection)
            last_seen = datetime.fromisoformat(self.last_seen)
            hours_since_detection = (last_seen - last_det).total_seconds() / 3600
            # Trust recovers over 24 hours of clean play
            self.recency = min(1.0, hours_since_detection / 24.0)
        else:
            self.recency = 1.0

        # Anomaly: severe cheats reduce faster
        severe_count = sum(
            self.detections_by_type.get(ct.value, 0)
            for ct in (CheatType.AIMBOT, CheatType.SPEEDHACK, CheatType.TELEPORT)
        )
        self.anomaly = max(0.0, 1.0 - severe_count * 0.15)

        # Weighted score
        self.trust_score = (
            0.30 * self.fair_play
            + 0.30 * self.integrity
            + 0.15 * self.recency
            + 0.25 * self.anomaly
        )
        self.trust_score = max(0.0, min(1.0, self.trust_score))

    def trust_breakdown(self) -> dict:
        return {
            "score": round(self.trust_score, 4),
            "fair_play": round(self.fair_play, 4),
            "integrity": round(self.integrity, 4),
            "recency": round(self.recency, 4),
            "anomaly": round(self.anomaly, 4),
            "total_sessions": self.total_sessions,
            "clean_sessions": self.clean_sessions,
            "flagged_sessions": self.flagged_sessions,
            "total_detections": self.total_detections,
            "banned": self.banned,
        }

    def to_dict(self) -> dict:
        return {
            "player_id": self.player_id,
            **self.trust_breakdown(),
            "detections_by_type": self.detections_by_type,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
        }
