"""
Anomaly Detectors — catch cheats through provenance patterns.

No kernel driver. No signature scanning. No invasive surveillance.
Just mathematical analysis of action provenance chains.

Human players have natural patterns:
- Aim has jitter, acceleration, deceleration
- Movement has inertia and reaction delays
- Reaction time has human limits (150ms+)
- Accuracy varies with distance and stress

Cheaters break these patterns:
- Aimbot: instant aim corrections, zero jitter
- Speedhack: impossible distance/time ratios
- Wallhack: targets players not in line-of-sight (inferred)
- Teleport: position jumps with no movement chain
- Triggerbot: inhuman reaction time on shoot actions
"""

import math
import statistics
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .action import GameAction, ActionType, InputSample


class CheatType(Enum):
    """Types of cheats that can be detected."""
    AIMBOT = "aimbot"
    SPEEDHACK = "speedhack"
    TELEPORT = "teleport"
    TRIGGERBOT = "triggerbot"
    MACRO = "macro"
    INHUMAN_REACTION = "inhuman_reaction"
    CHAIN_TAMPER = "chain_tamper"


@dataclass
class Detection:
    """A detected anomaly."""
    cheat_type: CheatType
    confidence: float       # 0.0 = unlikely, 1.0 = certain
    action_id: str
    player_id: str
    evidence: dict = field(default_factory=dict)
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "cheat_type": self.cheat_type.value,
            "confidence": round(self.confidence, 4),
            "action_id": self.action_id,
            "player_id": self.player_id,
            "evidence": self.evidence,
            "description": self.description,
        }


class AimbotDetector:
    """
    Detect aimbot through input provenance analysis.

    Human aiming characteristics:
    - Angular velocity follows bell curve (accelerate → peak → decelerate)
    - Mouse movements have natural micro-jitter (hand tremor)
    - Aim corrections are gradual, not instant snaps
    - Accuracy decreases with target distance and speed

    Aimbot characteristics:
    - Instant angular corrections (infinite acceleration)
    - Zero or constant jitter (no human variation)
    - Perfect tracking through obstacles
    - Unnaturally high aim_change_rate followed by perfect stillness
    """

    def __init__(
        self,
        max_aim_snap_degrees: float = 60.0,
        min_human_jitter: float = 0.1,
        max_tracking_perfection: float = 0.98,
    ):
        self.max_aim_snap = max_aim_snap_degrees
        self.min_human_jitter = min_human_jitter
        self.max_tracking_perfection = max_tracking_perfection

    def analyze(self, actions: list[GameAction]) -> list[Detection]:
        """Analyze action chain for aimbot patterns."""
        detections = []

        # Get all shoot/hit actions with input samples
        aim_actions = [
            a for a in actions
            if a.action_type in (ActionType.SHOOT, ActionType.HIT, ActionType.KILL)
            and a.input_sample
        ]

        if len(aim_actions) < 3:
            return detections

        # Check 1: Aim snap detection
        for i, action in enumerate(aim_actions):
            if i == 0:
                continue
            prev = aim_actions[i - 1]
            if action.input_sample and prev.input_sample:
                # Handle 360° wraparound: diff of 350° is actually 10°
                raw_diff = abs(action.input_sample.aim_angle - prev.input_sample.aim_angle)
                aim_change = min(raw_diff, 360.0 - raw_diff)
                time_delta = action.time_since_last_ms

                if time_delta > 0:
                    angular_velocity = aim_change / time_delta  # deg/ms

                    # Inhuman aim snap: >60 degrees in <50ms
                    if aim_change > self.max_aim_snap and time_delta < 50:
                        confidence = min(1.0, (aim_change / self.max_aim_snap) * 0.7)
                        detections.append(Detection(
                            cheat_type=CheatType.AIMBOT,
                            confidence=confidence,
                            action_id=action.action_id,
                            player_id=action.player_id,
                            evidence={
                                "aim_change_degrees": round(aim_change, 2),
                                "time_ms": round(time_delta, 2),
                                "angular_velocity": round(angular_velocity, 4),
                            },
                            description=f"Aim snap: {aim_change:.1f}° in {time_delta:.0f}ms "
                                        f"(angular velocity: {angular_velocity:.2f}°/ms)",
                        ))

        # Check 2: Jitter analysis (zero jitter = bot)
        jitter_values = []
        for a in aim_actions:
            if a.input_sample:
                jitter = math.sqrt(a.input_sample.mouse_dx**2 + a.input_sample.mouse_dy**2)
                jitter_values.append(jitter)

        if len(jitter_values) >= 5:
            jitter_std = statistics.stdev(jitter_values)
            if jitter_std < self.min_human_jitter:
                detections.append(Detection(
                    cheat_type=CheatType.AIMBOT,
                    confidence=min(1.0, (self.min_human_jitter / max(0.001, jitter_std)) * 0.6),
                    action_id=aim_actions[-1].action_id,
                    player_id=aim_actions[-1].player_id,
                    evidence={
                        "jitter_std": round(jitter_std, 6),
                        "threshold": self.min_human_jitter,
                        "samples": len(jitter_values),
                    },
                    description=f"Unnaturally low aim jitter: std={jitter_std:.6f} "
                                f"(human minimum: {self.min_human_jitter})",
                ))

        # Check 3: Perfect tracking (headshot ratio analysis)
        hits = sum(1 for a in aim_actions if a.action_type in (ActionType.HIT, ActionType.KILL))
        shots = len(aim_actions)
        if shots >= 10:
            hit_ratio = hits / shots
            if hit_ratio > self.max_tracking_perfection:
                detections.append(Detection(
                    cheat_type=CheatType.AIMBOT,
                    confidence=min(1.0, (hit_ratio - self.max_tracking_perfection) * 5),
                    action_id=aim_actions[-1].action_id,
                    player_id=aim_actions[-1].player_id,
                    evidence={
                        "hit_ratio": round(hit_ratio, 4),
                        "hits": hits,
                        "shots": shots,
                        "threshold": self.max_tracking_perfection,
                    },
                    description=f"Inhuman accuracy: {hit_ratio:.1%} hit rate over {shots} shots",
                ))

        return detections


class SpeedhackDetector:
    """
    Detect speedhack through position/time analysis.

    Every move action has a position and timestamp.
    distance / time = speed. If speed > max_possible → speedhack.

    TIBET provenance makes this unforgeable: the timestamps
    are server-side, and the position chain is hash-linked.
    """

    def __init__(
        self,
        max_speed: float = 15.0,           # Max units/second for running
        max_sprint_speed: float = 25.0,    # Max with sprint
        teleport_threshold: float = 100.0,  # Distance jump = teleport
    ):
        self.max_speed = max_speed
        self.max_sprint_speed = max_sprint_speed
        self.teleport_threshold = teleport_threshold

    def analyze(self, actions: list[GameAction]) -> list[Detection]:
        """Analyze action chain for speedhack/teleport."""
        detections = []

        move_actions = [a for a in actions if a.action_type == ActionType.MOVE]

        for action in move_actions:
            # Teleport detection
            if action.distance_since_last > self.teleport_threshold:
                detections.append(Detection(
                    cheat_type=CheatType.TELEPORT,
                    confidence=min(1.0, action.distance_since_last / (self.teleport_threshold * 2)),
                    action_id=action.action_id,
                    player_id=action.player_id,
                    evidence={
                        "distance": round(action.distance_since_last, 2),
                        "time_ms": round(action.time_since_last_ms, 2),
                        "threshold": self.teleport_threshold,
                    },
                    description=f"Teleport: moved {action.distance_since_last:.1f} units "
                                f"in {action.time_since_last_ms:.0f}ms",
                ))

            # Speedhack detection
            elif action.speed > self.max_sprint_speed:
                over_ratio = action.speed / self.max_sprint_speed
                detections.append(Detection(
                    cheat_type=CheatType.SPEEDHACK,
                    confidence=min(1.0, (over_ratio - 1.0) * 0.5),
                    action_id=action.action_id,
                    player_id=action.player_id,
                    evidence={
                        "speed": round(action.speed, 2),
                        "max_allowed": self.max_sprint_speed,
                        "over_ratio": round(over_ratio, 2),
                        "distance": round(action.distance_since_last, 2),
                        "time_ms": round(action.time_since_last_ms, 2),
                    },
                    description=f"Speed: {action.speed:.1f} u/s "
                                f"(max: {self.max_sprint_speed} u/s, {over_ratio:.1f}x over)",
                ))

        return detections


class ReactionDetector:
    """
    Detect inhuman reaction times.

    Human reaction time to visual stimulus: ~150-250ms
    Professional FPS players: ~130-180ms
    Below 100ms consistently: triggerbot/inhuman

    Analyzes the time between a target appearing (inferred from
    action context) and the shoot action.
    """

    def __init__(
        self,
        min_human_reaction_ms: float = 100.0,
        suspicious_reaction_ms: float = 130.0,
    ):
        self.min_human = min_human_reaction_ms
        self.suspicious = suspicious_reaction_ms

    def analyze(self, actions: list[GameAction]) -> list[Detection]:
        """Analyze reaction times in kill sequences."""
        detections = []

        # Find shoot actions that follow non-shoot actions (reaction events)
        reaction_times = []
        for i, action in enumerate(actions):
            if i == 0:
                continue
            prev = actions[i - 1]

            # Shoot/hit after a non-combat action = reaction event
            if (action.action_type in (ActionType.SHOOT, ActionType.HIT, ActionType.KILL)
                    and prev.action_type not in (ActionType.SHOOT, ActionType.HIT, ActionType.KILL)
                    and action.time_since_last_ms > 0):
                reaction_times.append((action, action.time_since_last_ms))

        # Check for consistently inhuman reactions
        inhuman_reactions = [
            (a, t) for a, t in reaction_times if t < self.min_human
        ]

        for action, reaction_ms in inhuman_reactions:
            detections.append(Detection(
                cheat_type=CheatType.TRIGGERBOT,
                confidence=min(1.0, (self.min_human - reaction_ms) / self.min_human),
                action_id=action.action_id,
                player_id=action.player_id,
                evidence={
                    "reaction_ms": round(reaction_ms, 2),
                    "min_human_ms": self.min_human,
                },
                description=f"Inhuman reaction: {reaction_ms:.0f}ms "
                            f"(human minimum: {self.min_human:.0f}ms)",
            ))

        # Suspicious pattern: consistently fast (even if individually possible)
        if len(reaction_times) >= 5:
            times = [t for _, t in reaction_times]
            avg = statistics.mean(times)
            if avg < self.suspicious:
                detections.append(Detection(
                    cheat_type=CheatType.INHUMAN_REACTION,
                    confidence=min(1.0, (self.suspicious - avg) / self.suspicious),
                    action_id=reaction_times[-1][0].action_id,
                    player_id=reaction_times[-1][0].player_id,
                    evidence={
                        "avg_reaction_ms": round(avg, 2),
                        "samples": len(times),
                        "min_reaction": round(min(times), 2),
                        "max_reaction": round(max(times), 2),
                    },
                    description=f"Consistently fast reactions: avg {avg:.0f}ms "
                                f"over {len(times)} events",
                ))

        return detections


class MacroDetector:
    """
    Detect macro/automation through timing regularity.

    Human input has natural variance in timing.
    Macros produce unnaturally regular intervals.
    """

    def __init__(self, max_regularity: float = 0.95):
        self.max_regularity = max_regularity

    def analyze(self, actions: list[GameAction]) -> list[Detection]:
        """Analyze for macro-like timing patterns."""
        detections = []

        if len(actions) < 10:
            return detections

        # Check timing regularity of same-type action sequences
        type_groups: dict[str, list[float]] = {}
        for action in actions:
            key = action.action_type.value
            if key not in type_groups:
                type_groups[key] = []
            if action.time_since_last_ms > 0:
                type_groups[key].append(action.time_since_last_ms)

        for action_type, intervals in type_groups.items():
            if len(intervals) < 8:
                continue

            mean = statistics.mean(intervals)
            if mean < 1:
                continue
            std = statistics.stdev(intervals)
            cv = std / mean  # Coefficient of variation

            # Very low CV = unnaturally regular timing
            regularity = 1.0 - cv
            if regularity > self.max_regularity:
                detections.append(Detection(
                    cheat_type=CheatType.MACRO,
                    confidence=min(1.0, (regularity - self.max_regularity) * 5),
                    action_id=actions[-1].action_id,
                    player_id=actions[-1].player_id,
                    evidence={
                        "action_type": action_type,
                        "interval_mean_ms": round(mean, 2),
                        "interval_std_ms": round(std, 2),
                        "coefficient_of_variation": round(cv, 6),
                        "regularity": round(regularity, 4),
                        "samples": len(intervals),
                    },
                    description=f"Macro-like regularity in {action_type}: "
                                f"CV={cv:.4f} (regularity: {regularity:.1%})",
                ))

        return detections
