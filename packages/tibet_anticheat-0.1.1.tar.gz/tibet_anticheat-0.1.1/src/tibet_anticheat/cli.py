"""
tibet-anticheat CLI — anti-cheat through provenance, not surveillance.

Usage::

    tibet-anticheat demo
    tibet-anticheat demo --scenario cheater
    tibet-anticheat demo --scenario fair
"""

import argparse
import json
import math
import random
import sys
import time

from .engine import AntiCheatEngine, GameSession
from .action import ActionType, Vec3, InputSample


def _simulate_fair_player(session: GameSession, name: str) -> None:
    """Simulate a fair player with natural human patterns."""
    print(f"    Simulating fair player: {name}")
    pos = Vec3(0, 0, 0)
    current_aim = random.uniform(0, 360)  # Continuous aim direction
    tick = 0

    for i in range(30):
        # Natural movement — within game physics limits
        # max_sprint_speed=25 u/s. At 10 ticks (160ms), max dist = 25*0.16 = 4.0 units
        # Normal walking speed ~8 u/s → ~1.3 units per 160ms step
        tick += random.randint(8, 15)  # Variable tick spacing (128-240ms)
        dx = random.uniform(-0.8, 0.8)
        dz = random.uniform(-0.8, 0.8)
        pos = Vec3(pos.x + dx, 0, pos.z + dz)

        session.record_action(
            ActionType.MOVE,
            position=pos,
            tick=tick,
        )

        # Occasional shooting with human-like aim
        if random.random() < 0.3:
            target = Vec3(pos.x + random.uniform(10, 50), random.uniform(-2, 5), pos.z + random.uniform(10, 50))
            # Human aim: gradual change from current angle, not random snap
            current_aim += random.gauss(0, 10)  # Smooth ±10° adjustments
            current_aim = current_aim % 360

            # Human reaction: 10-20 ticks (160-320ms) after seeing target
            tick += random.randint(10, 20)

            session.record_action(
                ActionType.SHOOT,
                position=pos,
                target_position=target,
                target_player=f"enemy-{random.randint(1,5)}",
                input_sample=InputSample(
                    mouse_dx=random.gauss(0, 5),      # Natural jitter
                    mouse_dy=random.gauss(0, 3),
                    mouse_speed=random.gauss(8, 3),    # Variable speed
                    aim_angle=current_aim,
                    aim_change_rate=random.gauss(0.5, 0.3),  # Gradual aim
                ),
                tick=tick,
            )

            # Sometimes hit (~40% accuracy — normal)
            if random.random() < 0.4:
                tick += random.randint(1, 3)  # Tiny follow-up
                session.record_action(
                    ActionType.HIT,
                    position=pos,
                    target_player=f"enemy-{random.randint(1,5)}",
                    input_sample=InputSample(
                        mouse_dx=random.gauss(0, 4),
                        mouse_dy=random.gauss(0, 2),
                        mouse_speed=random.gauss(6, 2),
                        aim_angle=current_aim + random.gauss(0, 3),
                        aim_change_rate=random.gauss(0.3, 0.2),
                    ),
                    tick=tick,
                )

    print(f"      Actions: {len(session.recorder.chain())}")


def _simulate_cheater(session: GameSession, name: str) -> None:
    """Simulate a cheater — aimbot + speedhack."""
    print(f"    Simulating cheater: {name}")
    pos = Vec3(0, 0, 0)
    tick = 0

    for i in range(30):
        # SPEEDHACK: moving way too fast (10x normal movement)
        tick += random.randint(8, 15)  # Same tick spacing as normal player
        dx = random.uniform(-15, 15)  # But moving 15-20x further per step
        dz = random.uniform(-15, 15)
        pos = Vec3(pos.x + dx, 0, pos.z + dz)

        session.record_action(
            ActionType.MOVE,
            position=pos,
            tick=tick,
        )

        # AIMBOT: shooting with inhuman precision
        if random.random() < 0.5:
            target = Vec3(pos.x + random.uniform(20, 80), random.uniform(0, 3), pos.z + random.uniform(20, 80))
            prev_aim = session.recorder._actions[-1].input_sample.aim_angle if (
                session.recorder._actions and session.recorder._actions[-1].input_sample
            ) else 0
            # Instant snap to target — aimbot signature (stays within 0-360)
            new_aim = (prev_aim + random.uniform(80, 150)) % 360

            # TRIGGERBOT: inhuman reaction time (1-3 ticks = 16-48ms)
            tick += random.randint(1, 3)

            session.record_action(
                ActionType.SHOOT,
                position=pos,
                target_position=target,
                target_player=f"enemy-{random.randint(1,5)}",
                input_sample=InputSample(
                    mouse_dx=0.01,         # Zero jitter — bot signature
                    mouse_dy=0.01,
                    mouse_speed=0.5,       # Constant — not human
                    aim_angle=new_aim,
                    aim_change_rate=5.0,   # Inhuman angular velocity
                ),
                tick=tick,
            )

            # Almost always hit (~95% accuracy — aimbot)
            if random.random() < 0.95:
                tick += 1
                session.record_action(
                    ActionType.HIT,
                    position=pos,
                    target_player=f"enemy-{random.randint(1,5)}",
                    input_sample=InputSample(
                        mouse_dx=0.01,
                        mouse_dy=0.01,
                        mouse_speed=0.5,
                        aim_angle=new_aim,
                        aim_change_rate=0.01,  # Perfect stillness after snap
                    ),
                    tick=tick,
                )

    print(f"      Actions: {len(session.recorder.chain())}")


def _print_report(report: dict) -> None:
    """Pretty-print a session report."""
    verdict = report["verdict"]
    marker = {"CLEAN": "  ", "WATCHLIST": " ?", "SUSPICIOUS": " !", "GUILTY": "!!"}
    print(f"    {marker.get(verdict, '  ')}Verdict: {verdict}")
    print(f"      Trust: {report['trust_score']:.4f}")
    print(f"      Actions: {report['total_actions']}")
    print(f"      Detections: {report['detection_count']}")
    print(f"      Chain valid: {report['chain_valid']}")

    tb = report["trust_breakdown"]
    print(f"      FIR/A: FairPlay={tb['fair_play']:.2f} Integrity={tb['integrity']:.2f} "
          f"Recency={tb['recency']:.2f} Anomaly={tb['anomaly']:.2f}")

    if report["detections"]:
        print(f"      Detections:")
        for d in report["detections"][:5]:
            print(f"        [{d['cheat_type']}] confidence={d['confidence']:.2f} — {d['description']}")
        if len(report["detections"]) > 5:
            print(f"        ... and {len(report['detections']) - 5} more")

    if report.get("auto_banned"):
        print(f"      AUTO-BANNED: trust dropped below threshold")
    print()


def cmd_demo(args: argparse.Namespace) -> int:
    """Run anti-cheat demo."""
    print()
    print("  tibet-anticheat demo — Anti-Cheat Through Provenance")
    print("  =====================================================")
    print()
    print("  No kernel driver. No spyware. No surveillance.")
    print("  Every game action = TIBET token. Math catches cheaters.")
    print()

    engine = AntiCheatEngine(max_speed=15.0, max_sprint_speed=25.0)

    detected = []
    engine.on_detection(lambda d: detected.append(d))

    scenario = args.scenario if hasattr(args, "scenario") and args.scenario else "all"

    if scenario in ("fair", "all"):
        print("  [1] Fair Players")
        print("  -----------------")
        for name in ["alice", "bob", "charlie"]:
            session = engine.start_session(f"player-{name}")
            _simulate_fair_player(session, name)
            report = engine.end_session(session.session_id)
            _print_report(report)

    if scenario in ("cheater", "all"):
        print("  [2] Cheaters")
        print("  -------------")
        for name in ["h4xx0r", "aimgod99"]:
            session = engine.start_session(f"player-{name}")
            _simulate_cheater(session, name)
            report = engine.end_session(session.session_id)
            _print_report(report)

    if scenario == "all":
        # Run fair players a second time to show trust recovery
        print("  [3] Trust Evolution (fair players play again)")
        print("  -----------------------------------------------")
        for name in ["alice", "bob"]:
            session = engine.start_session(f"player-{name}")
            _simulate_fair_player(session, name)
            report = engine.end_session(session.session_id)
            _print_report(report)

        # Cheater plays again — trust drops further
        print("  [4] Repeat Offender (cheater plays again)")
        print("  -------------------------------------------")
        session = engine.start_session("player-h4xx0r")
        _simulate_cheater(session, "h4xx0r (2nd offense)")
        report = engine.end_session(session.session_id)
        _print_report(report)

    # Leaderboard
    print("  [5] Trust Leaderboard")
    print("  ----------------------")
    for i, p in enumerate(engine.leaderboard(), 1):
        status = "BANNED" if p["banned"] else "active"
        print(f"    {i}. {p['player_id']}: trust={p['score']:.4f} "
              f"sessions={p['total_sessions']} detections={p['total_detections']} [{status}]")
    print()

    # Stats
    stats = engine.stats()
    print("  [6] Engine Stats")
    print("  -----------------")
    print(f"    Players: {stats['total_players']}")
    print(f"    Banned: {stats['banned_players']}")
    print(f"    Sessions: {stats['total_sessions']}")
    print(f"    TIBET tokens: {stats['tibet_tokens']}")
    print(f"    Total detections: {len(detected)}")
    print()

    # Key points
    print("  How it works:")
    print("  • Every action = TIBET token (ERIN/ERAAN/EROMHEEN/ERACHTER)")
    print("  • Action chain is hash-linked — tamper one, chain breaks")
    print("  • Aimbot: aim snap analysis, jitter variance, tracking perfection")
    print("  • Speedhack: distance/time impossible for game physics")
    print("  • Triggerbot: reaction times below human limits")
    print("  • Macro: unnatural timing regularity")
    print("  • Player trust: FIR/A scoring evolves over sessions")
    print("  • No kernel driver, no ring-0, no spyware")
    print("  • Indie-friendly: pip install tibet-anticheat")
    print()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="tibet-anticheat",
        description="Anti-cheat through provenance — no kernel driver, no surveillance",
    )
    parser.add_argument("--version", action="version", version="%(prog)s 0.1.0")

    sub = parser.add_subparsers(dest="command", help="Available commands")

    # demo
    p_demo = sub.add_parser("demo", help="Run anti-cheat demo")
    p_demo.add_argument("-s", "--scenario", choices=["fair", "cheater", "all"],
                        default="all", help="Demo scenario")

    args = parser.parse_args(argv)

    if args.command == "demo":
        return cmd_demo(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
