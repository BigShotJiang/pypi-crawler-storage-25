"""
Anti-Cheat Engine — ties it all together.

The engine runs all detectors on player action chains,
manages player trust profiles, and generates TIBET-audited
reports. No kernel driver. No surveillance. Just provenance math.

Usage::

    from tibet_anticheat import AntiCheatEngine, ActionType, Vec3, InputSample

    engine = AntiCheatEngine()
    session = engine.start_session("player-42")

    # Record actions (game server sends these)
    session.record_action(ActionType.MOVE, position=Vec3(10, 0, 5))
    session.record_action(ActionType.SHOOT,
        position=Vec3(10, 0, 5),
        target_position=Vec3(50, 2, 30),
        input_sample=InputSample(aim_angle=45.0, mouse_speed=12.0),
    )

    # End session — runs all detectors
    report = engine.end_session(session.session_id)
    print(report["verdict"])
"""

import hashlib
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Callable

from .action import ActionRecorder, ActionType, GameAction, Vec3, InputSample
from .detector import (
    AimbotDetector,
    SpeedhackDetector,
    ReactionDetector,
    MacroDetector,
    Detection,
    CheatType,
)
from .player import PlayerProfile


@dataclass
class GameSession:
    """An active game session being monitored."""
    session_id: str
    player_id: str
    recorder: ActionRecorder
    started_at: str = ""
    ended_at: str = ""
    active: bool = True

    def record_action(
        self,
        action_type: ActionType,
        position: Vec3 | None = None,
        target_position: Vec3 | None = None,
        target_player: str = "",
        input_sample: InputSample | None = None,
        tick: int | None = None,
        metadata: dict | None = None,
    ) -> GameAction:
        """Record a game action."""
        return self.recorder.record(
            action_type=action_type,
            position=position,
            target_position=target_position,
            target_player=target_player,
            input_sample=input_sample,
            tick=tick,
            metadata=metadata,
        )


class AntiCheatEngine:
    """
    TIBET-based anti-cheat engine.

    No kernel driver. No spyware. No surveillance.
    Just provenance-tracked action chains analyzed with math.

    Features:
    - Aimbot detection (aim snap, jitter, tracking perfection)
    - Speedhack detection (impossible velocity)
    - Teleport detection (position jumps)
    - Triggerbot detection (inhuman reaction times)
    - Macro detection (unnatural timing regularity)
    - Player trust profiles (FIR/A-style scoring)
    - Full TIBET audit trail

    Usage::

        engine = AntiCheatEngine()
        session = engine.start_session("player-42")
        session.record_action(ActionType.MOVE, position=Vec3(10, 0, 5))
        report = engine.end_session(session.session_id)
    """

    def __init__(
        self,
        max_speed: float = 15.0,
        max_sprint_speed: float = 25.0,
        ban_threshold: float = 0.15,
    ):
        # Detectors
        self.aimbot_detector = AimbotDetector()
        self.speed_detector = SpeedhackDetector(
            max_speed=max_speed,
            max_sprint_speed=max_sprint_speed,
        )
        self.reaction_detector = ReactionDetector()
        self.macro_detector = MacroDetector()

        # State
        self._sessions: dict[str, GameSession] = {}
        self._players: dict[str, PlayerProfile] = {}
        self._tokens: list[dict] = []
        self._token_seq = 0
        self._on_detection: list[Callable] = []
        self.ban_threshold = ban_threshold

    def start_session(self, player_id: str) -> GameSession:
        """Start monitoring a player's game session."""
        now = datetime.now(timezone.utc).isoformat()
        raw = f"{player_id}:{now}:{os.urandom(8).hex()}"
        session_id = hashlib.sha256(raw.encode()).hexdigest()[:12]

        recorder = ActionRecorder(player_id=player_id, session_id=session_id)

        session = GameSession(
            session_id=session_id,
            player_id=player_id,
            recorder=recorder,
            started_at=now,
        )

        self._sessions[session_id] = session

        # Ensure player profile exists
        if player_id not in self._players:
            self._players[player_id] = PlayerProfile(player_id=player_id)

        self._create_token(
            action="session_started",
            player_id=player_id,
            details={"session_id": session_id},
            intent=f"Start anti-cheat monitoring for {player_id}",
        )

        return session

    def end_session(self, session_id: str) -> dict:
        """
        End a session and run all detectors.

        Returns a full report with verdicts and evidence.
        """
        session = self._sessions.get(session_id)
        if not session:
            return {"error": "session_not_found"}

        now = datetime.now(timezone.utc).isoformat()
        session.ended_at = now
        session.active = False

        actions = session.recorder.chain()
        player = self._players[session.player_id]

        # Run all detectors
        all_detections: list[Detection] = []
        all_detections.extend(self.aimbot_detector.analyze(actions))
        all_detections.extend(self.speed_detector.analyze(actions))
        all_detections.extend(self.reaction_detector.analyze(actions))
        all_detections.extend(self.macro_detector.analyze(actions))

        # Verify action chain integrity
        chain_result = session.recorder.verify_chain()
        if not chain_result["valid"]:
            for issue in chain_result["issues"]:
                all_detections.append(Detection(
                    cheat_type=CheatType.CHAIN_TAMPER,
                    confidence=1.0,
                    action_id=issue.get("action", ""),
                    player_id=session.player_id,
                    evidence=issue,
                    description="Action chain tampered — provenance broken",
                ))

        # Update player profile
        player.record_actions(len(actions))
        player.record_session(all_detections)

        # Flag actions
        for detection in all_detections:
            for action in actions:
                if action.action_id == detection.action_id:
                    action.flags.append(detection.cheat_type.value)
                    action.suspicion_score = max(action.suspicion_score, detection.confidence)

        # Determine verdict
        max_confidence = max((d.confidence for d in all_detections), default=0.0)
        if max_confidence >= 0.8:
            verdict = "GUILTY"
        elif max_confidence >= 0.5:
            verdict = "SUSPICIOUS"
        elif max_confidence >= 0.2:
            verdict = "WATCHLIST"
        else:
            verdict = "CLEAN"

        # Auto-ban if trust drops below threshold
        auto_banned = False
        if player.trust_score < self.ban_threshold and not player.banned:
            player.ban(f"Trust score below threshold: {player.trust_score:.4f}")
            auto_banned = True

        # Notify handlers
        for detection in all_detections:
            for cb in self._on_detection:
                cb(detection)

        # Create audit token
        self._create_token(
            action="session_analyzed",
            player_id=session.player_id,
            details={
                "session_id": session_id,
                "total_actions": len(actions),
                "detections": len(all_detections),
                "verdict": verdict,
                "max_confidence": round(max_confidence, 4),
                "trust_score": round(player.trust_score, 4),
                "auto_banned": auto_banned,
            },
            intent=f"Analyze session for {session.player_id} — verdict: {verdict}",
        )

        # Build report
        report = {
            "session_id": session_id,
            "player_id": session.player_id,
            "verdict": verdict,
            "trust_score": round(player.trust_score, 4),
            "trust_breakdown": player.trust_breakdown(),
            "total_actions": len(actions),
            "detections": [d.to_dict() for d in all_detections],
            "detection_count": len(all_detections),
            "chain_valid": chain_result["valid"],
            "auto_banned": auto_banned,
            "started_at": session.started_at,
            "ended_at": session.ended_at,
        }

        return report

    def get_player(self, player_id: str) -> Optional[PlayerProfile]:
        """Get a player's trust profile."""
        return self._players.get(player_id)

    def on_detection(self, callback: Callable) -> None:
        """Register handler for cheat detections."""
        self._on_detection.append(callback)

    def leaderboard(self) -> list[dict]:
        """Trust leaderboard — highest trust first."""
        players = sorted(
            self._players.values(),
            key=lambda p: p.trust_score,
            reverse=True,
        )
        return [p.to_dict() for p in players]

    def audit_trail(self) -> list[dict]:
        """Full TIBET audit trail."""
        return list(self._tokens)

    def stats(self) -> dict:
        total_players = len(self._players)
        banned = sum(1 for p in self._players.values() if p.banned)
        active_sessions = sum(1 for s in self._sessions.values() if s.active)
        return {
            "total_players": total_players,
            "banned_players": banned,
            "active_sessions": active_sessions,
            "total_sessions": len(self._sessions),
            "tibet_tokens": len(self._tokens),
        }

    def _create_token(self, action: str, player_id: str, details: dict, intent: str) -> dict:
        now = datetime.now(timezone.utc).isoformat()
        self._token_seq += 1

        raw = f"{action}:{player_id}:{now}:{self._token_seq}"
        token_id = hashlib.sha256(raw.encode()).hexdigest()[:16]

        token = {
            "token_id": token_id,
            "timestamp": now,
            "type": "anticheat",
            "action": action,
            "player_id": player_id,
            "erin": {"action": action, "details": details},
            "eraan": {
                "parent_token": self._tokens[-1]["token_id"] if self._tokens else None,
                "sequence": self._token_seq,
            },
            "eromheen": {
                "node": os.uname().nodename,
                "timestamp": now,
            },
            "erachter": {
                "intent": intent,
                "protocol": "tibet-anticheat/0.1",
            },
        }

        self._tokens.append(token)
        return token
