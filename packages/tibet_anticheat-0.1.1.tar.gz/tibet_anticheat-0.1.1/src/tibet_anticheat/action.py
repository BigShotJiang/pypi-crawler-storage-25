"""
Game Actions — every action is a TIBET token.

A player moves, shoots, picks up an item, opens a door —
each action becomes a provenance-tracked token. The action
chain is cryptographically linked: each action references
the previous one. Break the chain = tampered input.

Aimbot? The input provenance doesn't match human patterns.
Speedhack? The position delta vs time delta is impossible.
Wallhack? The action targets something not in line-of-sight.

No kernel driver. No surveillance. Just math.
"""

import hashlib
import json
import math
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class ActionType(Enum):
    """Types of game actions that can be tracked."""
    MOVE = "move"
    SHOOT = "shoot"
    HIT = "hit"
    KILL = "kill"
    DAMAGE = "damage"
    PICKUP = "pickup"
    USE_ITEM = "use_item"
    INTERACT = "interact"
    SPAWN = "spawn"
    DEATH = "death"
    JUMP = "jump"
    ABILITY = "ability"
    CHAT = "chat"
    CUSTOM = "custom"


@dataclass
class Vec3:
    """3D position vector."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def distance_to(self, other: "Vec3") -> float:
        return math.sqrt(
            (self.x - other.x) ** 2
            + (self.y - other.y) ** 2
            + (self.z - other.z) ** 2
        )

    def to_dict(self) -> dict:
        return {"x": round(self.x, 4), "y": round(self.y, 4), "z": round(self.z, 4)}


@dataclass
class InputSample:
    """
    Raw input sample — mouse/keyboard state at moment of action.

    Human input has natural jitter, acceleration curves, and reaction delays.
    Aimbot input is unnaturally precise with instant corrections.
    """
    mouse_dx: float = 0.0       # Mouse delta X
    mouse_dy: float = 0.0       # Mouse delta Y
    mouse_speed: float = 0.0    # Pixels/ms
    aim_angle: float = 0.0      # Degrees
    aim_change_rate: float = 0.0  # Degrees/ms (angular velocity)
    keys_held: list[str] = field(default_factory=list)
    timestamp_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "mouse_dx": round(self.mouse_dx, 2),
            "mouse_dy": round(self.mouse_dy, 2),
            "mouse_speed": round(self.mouse_speed, 2),
            "aim_angle": round(self.aim_angle, 2),
            "aim_change_rate": round(self.aim_change_rate, 2),
            "keys_held": self.keys_held,
            "timestamp_ms": self.timestamp_ms,
        }


@dataclass
class GameAction:
    """
    A game action — always a TIBET token.

    Every action carries:
    - ERIN:     What happened (action type, position, target)
    - ERAAN:    What it depends on (previous action in chain)
    - EROMHEEN: Context (tick, server state, input sample)
    - ERACHTER: Intent (what the player was trying to do)
    """
    action_id: str
    action_type: ActionType
    player_id: str
    session_id: str
    tick: int                   # Server tick number
    timestamp: str = ""
    position: Vec3 = field(default_factory=Vec3)
    target_position: Optional[Vec3] = None
    target_player: str = ""
    input_sample: Optional[InputSample] = None
    metadata: dict = field(default_factory=dict)
    content_hash: str = ""
    parent_action: Optional[str] = None  # Previous action in chain

    # Computed fields
    time_since_last_ms: float = 0.0
    distance_since_last: float = 0.0
    speed: float = 0.0         # Units/second

    # TIBET provenance
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)

    # Anti-cheat flags
    flags: list[str] = field(default_factory=list)
    suspicion_score: float = 0.0  # 0.0 = clean, 1.0 = definitely cheating

    def to_dict(self) -> dict:
        return {
            "action_id": self.action_id,
            "type": self.action_type.value,
            "player_id": self.player_id,
            "session_id": self.session_id,
            "tick": self.tick,
            "timestamp": self.timestamp,
            "position": self.position.to_dict(),
            "target_position": self.target_position.to_dict() if self.target_position else None,
            "target_player": self.target_player,
            "input_sample": self.input_sample.to_dict() if self.input_sample else None,
            "content_hash": self.content_hash,
            "parent_action": self.parent_action,
            "speed": round(self.speed, 2),
            "time_since_last_ms": round(self.time_since_last_ms, 2),
            "flags": self.flags,
            "suspicion_score": round(self.suspicion_score, 4),
        }


class ActionRecorder:
    """
    Records game actions as TIBET tokens.

    Each action is chained to the previous one via content hashes.
    Break the chain = tampered sequence.
    """

    def __init__(self, player_id: str, session_id: str):
        self.player_id = player_id
        self.session_id = session_id
        self._actions: list[GameAction] = []
        self._tick = 0
        self._seq = 0

    def record(
        self,
        action_type: ActionType,
        position: Vec3 | None = None,
        target_position: Vec3 | None = None,
        target_player: str = "",
        input_sample: InputSample | None = None,
        tick: int | None = None,
        metadata: dict | None = None,
    ) -> GameAction:
        """Record a game action as a TIBET token."""
        now = datetime.now(timezone.utc).isoformat()
        self._seq += 1
        self._tick = tick if tick is not None else self._tick + 1
        position = position or Vec3()

        # Generate action ID
        raw = f"{self.player_id}:{self._seq}:{now}:{os.urandom(4).hex()}"
        action_id = hashlib.sha256(raw.encode()).hexdigest()[:12]

        # Content hash for chain integrity
        content = json.dumps({
            "type": action_type.value,
            "player": self.player_id,
            "tick": self._tick,
            "pos": position.to_dict(),
        }, sort_keys=True)
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:24]

        # Link to previous action
        parent_action = self._actions[-1].action_id if self._actions else None
        parent_hash = self._actions[-1].content_hash if self._actions else ""

        # Compute deltas from previous action
        time_since_last = 0.0
        distance_since_last = 0.0
        speed = 0.0
        if self._actions:
            prev = self._actions[-1]
            # Time delta: prefer wall-clock, fall back to tick delta
            # (1 tick ≈ 16ms at 60Hz server tick rate)
            prev_time = datetime.fromisoformat(prev.timestamp)
            now_time = datetime.fromisoformat(now)
            wall_delta_ms = (now_time - prev_time).total_seconds() * 1000
            tick_delta_ms = (self._tick - prev.tick) * 16.0  # 60Hz tick rate

            # Use wall clock if meaningful (>1ms), otherwise use tick-based time
            time_since_last = wall_delta_ms if wall_delta_ms > 1.0 else max(16.0, tick_delta_ms)
            distance_since_last = position.distance_to(prev.position)
            speed = (distance_since_last / time_since_last) * 1000 if time_since_last > 0 else 0

        action = GameAction(
            action_id=action_id,
            action_type=action_type,
            player_id=self.player_id,
            session_id=self.session_id,
            tick=self._tick,
            timestamp=now,
            position=position,
            target_position=target_position,
            target_player=target_player,
            input_sample=input_sample,
            metadata=metadata or {},
            content_hash=content_hash,
            parent_action=parent_action,
            time_since_last_ms=time_since_last,
            distance_since_last=distance_since_last,
            speed=speed,
            erin={
                "action": action_type.value,
                "position": position.to_dict(),
                "target": target_player or None,
                "content_hash": content_hash,
            },
            eraan={
                "parent_action": parent_action,
                "parent_hash": parent_hash,
                "sequence": self._seq,
            },
            eromheen={
                "session": self.session_id,
                "tick": self._tick,
                "timestamp": now,
                "input": input_sample.to_dict() if input_sample else None,
            },
            erachter={
                "intent": f"Player {action_type.value}",
                "protocol": "tibet-anticheat/0.1",
            },
        )

        self._actions.append(action)
        return action

    def chain(self) -> list[GameAction]:
        """Get full action chain."""
        return list(self._actions)

    def verify_chain(self) -> dict:
        """Verify the integrity of the action chain."""
        issues = []
        for i, action in enumerate(self._actions):
            if i > 0:
                prev = self._actions[i - 1]
                if action.parent_action != prev.action_id:
                    issues.append({
                        "action": action.action_id,
                        "issue": "chain_broken",
                        "expected_parent": prev.action_id,
                        "got": action.parent_action,
                    })
        return {
            "valid": len(issues) == 0,
            "actions_checked": len(self._actions),
            "issues": issues,
        }

    def last_n(self, n: int = 10) -> list[GameAction]:
        """Get last N actions."""
        return self._actions[-n:]

    def stats(self) -> dict:
        return {
            "total_actions": len(self._actions),
            "current_tick": self._tick,
            "player_id": self.player_id,
            "session_id": self.session_id,
        }
