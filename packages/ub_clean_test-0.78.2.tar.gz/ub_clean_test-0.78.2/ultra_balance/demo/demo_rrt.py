"""
RRT 快速扩展随机树路径规划演示

运行方式：
    python -m ultra_balance.demo.demo_rrt
"""

import numpy as np
import random
import os
import sys

# ========== 图形界面智能检测 ==========
try:
    import matplotlib
    if 'DISPLAY' in os.environ or os.name == 'nt':
        try:
            import matplotlib.pyplot as plt
            HAS_PLOT = True
        except:
            HAS_PLOT = False
    else:
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        HAS_PLOT = True
except ImportError:
    HAS_PLOT = False
    plt = None
# =====================================


class SimpleRRT:
    """简化版 RRT 路径规划算法（修复死循环问题）"""
    
    def __init__(self, start, goal, obstacles, bounds, max_iter=500, step=0.5):
        self.start = start
        self.goal = goal
        self.obstacles = obstacles
        self.bounds = bounds
        self.max_iter = max_iter
        self.step = step
        self.nodes = [start]
        self.parents = {tuple(start): None}  # 记录父节点，解决回溯死循环
    
    def plan(self):
        """执行 RRT 路径规划"""
        for i in range(self.max_iter):
            # 随机采样（10% 概率直接采样目标点）
            if random.random() < 0.1:
                rand = self.goal
            else:
                rand = [random.uniform(self.bounds[0], self.bounds[1]),
                        random.uniform(self.bounds[2], self.bounds[3])]
            
            # 找最近节点
            nearest = min(self.nodes, key=lambda n: np.hypot(n[0]-rand[0], n[1]-rand[1]))
            
            # 向随机点扩展
            dx = rand[0] - nearest[0]
            dy = rand[1] - nearest[1]
            dist = np.hypot(dx, dy)
            if dist > self.step:
                dx = dx / dist * self.step
                dy = dy / dist * self.step
            new = [nearest[0] + dx, nearest[1] + dy]
            
            # 边界检查
            if not (self.bounds[0] <= new[0] <= self.bounds[1] and 
                    self.bounds[2] <= new[1] <= self.bounds[3]):
                continue
            
            # 碰撞检测
            collide = False
            for ox, oy, r in self.obstacles:
                if np.hypot(new[0]-ox, new[1]-oy) < r:
                    collide = True
                    break
            if collide:
                continue
            
            # 添加节点
            self.nodes.append(new)
            self.parents[tuple(new)] = tuple(nearest)
            
            # 检查是否到达目标
            if np.hypot(new[0]-self.goal[0], new[1]-self.goal[1]) < self.step:
                # 构建路径（使用 parent 字典，无死循环风险）
                path = [self.goal]
                current = tuple(new)
                while current != tuple(self.start):
                    current = self.parents.get(current)
                    if current is None:
                        break
                    path.append(list(current))
                path.reverse()
                return path, self.nodes
        
        return None, self.nodes


def plot_result(start, goal, obstacles, nodes, path, bounds):
    """绘制 RRT 规划结果"""
    if not HAS_PLOT or plt is None:
        print("?? matplotlib 不可用，跳过绘图")
        return False
    
    fig, ax = plt.subplots(figsize=(8, 8))
    
    # 绘制障碍物
    for ox, oy, r in obstacles:
        ax.add_patch(plt.Circle((ox, oy), r, color='gray', alpha=0.7))
    
    # 绘制搜索树
    for i, node in enumerate(nodes):
        if i > 0:
            parent = min(nodes[:i], key=lambda n: np.hypot(n[0]-node[0], n[1]-node[1]))
            ax.plot([node[0], parent[0]], [node[1], parent[1]], 'b-', alpha=0.3)
    
    # 绘制路径
    if path:
        path = np.array(path)
        ax.plot(path[:, 0], path[:, 1], 'r-', linewidth=2, label='Path')
    
    # 绘制起点和终点
    ax.plot(start[0], start[1], 'go', markersize=10, label='Start')
    ax.plot(goal[0], goal[1], 'ro', markersize=10, label='Goal')
    
    ax.set_xlim(bounds[0], bounds[1])
    ax.set_ylim(bounds[2], bounds[3])
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    ax.legend()
    
    # 智能显示/保存
    try:
        plt.show()
        return True
    except:
        filename = "demo_rrt_output.png"
        plt.savefig(filename, dpi=150, bbox_inches='tight')
        print(f"\n? 图形已保存至: {filename}")
        plt.close()
        return True


def main():
    print("\n" + "=" * 50)
    print("RRT 快速扩展随机树路径规划演示")
    print("=" * 50)
    
    # 参数设置
    start = [1, 1]
    goal = [9, 6]
    obstacles = [[2, 2, 0.5], [3, 4, 0.6], [5, 3, 0.8], [7, 5, 0.5], [8, 2, 0.7]]
    bounds = [0, 10, 0, 10]
    
    print(f"\n? 起点: {start}")
    print(f"? 终点: {goal}")
    print(f"? 障碍物数量: {len(obstacles)}")
    print(f"? 最大迭代次数: 500")
    print("-" * 40)
    
    # 执行 RRT 规划
    print("\n? 正在规划路径...")
    rrt = SimpleRRT(start, goal, obstacles, bounds, max_iter=500, step=0.5)
    path, nodes = rrt.plan()
    
    if path:
        print(f"\n? 路径规划成功！")
        print(f"   ? 路径节点数: {len(path)}")
        print(f"   ? 搜索树节点数: {len(nodes)}")
        
        # 显示前 5 个路径点
        print(f"\n   ? 路径坐标（前5个）:")
        for i, p in enumerate(path[:5]):
            print(f"      {i}: [{p[0]:.2f}, {p[1]:.2f}]")
        if len(path) > 5:
            print(f"      ... 共 {len(path)} 个节点")
    else:
        print(f"\n?? 未找到可行路径")
        print(f"   ? 搜索树节点数: {len(nodes)}")
    
    # 绘制结果
    print("\n? 正在生成图形...")
    plot_result(start, goal, obstacles, nodes, path, bounds)
    
    print("\n" + "=" * 50)
    print("RRT 演示完成！")
    print("=" * 50)


if __name__ == "__main__":
    main()
