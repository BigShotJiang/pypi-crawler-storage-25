"""
PPO 强化学习演示（纯 NumPy 实现）

运行方式：
    python -m ultra_balance.demo.demo_ppo
"""

import numpy as np
import os
import sys

# ========== 图形界面智能检测 ==========
try:
    import matplotlib
    # 设置中文字体，消除警告
    matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
    matplotlib.rcParams['axes.unicode_minus'] = False
    
    if 'DISPLAY' in os.environ or os.name == 'nt':
        try:
            import matplotlib.pyplot as plt
            HAS_PLOT = True
        except:
            HAS_PLOT = False
    else:
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        HAS_PLOT = True
except ImportError:
    HAS_PLOT = False
    plt = None
# =====================================


class PPO:
    """纯 NumPy 实现的 PPO 算法（简化版）"""
    
    def __init__(self, state_dim, action_dim, lr=1e-3, gamma=0.99, clip_epsilon=0.2):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.clip_epsilon = clip_epsilon
        
        # 策略网络参数（两层 MLP）
        hidden = 32
        self.w1 = np.random.randn(state_dim, hidden) * 0.1
        self.b1 = np.zeros(hidden)
        self.w_mean = np.random.randn(hidden, action_dim) * 0.1
        self.b_mean = np.zeros(action_dim)
        self.log_std = np.zeros(action_dim)
        
        # 价值网络参数
        self.w_v1 = np.random.randn(state_dim, hidden) * 0.1
        self.b_v1 = np.zeros(hidden)
        self.w_v2 = np.random.randn(hidden, 1) * 0.1
        self.b_v2 = np.zeros(1)
        
        self.lr = lr
        self.memory = []
    
    def _forward_policy(self, state):
        """策略网络前向传播"""
        h = np.tanh(state @ self.w1 + self.b1)
        mean = h @ self.w_mean + self.b_mean
        std = np.exp(self.log_std)
        return mean, std
    
    def _forward_value(self, state):
        """价值网络前向传播"""
        h = np.tanh(state @ self.w_v1 + self.b_v1)
        return h @ self.w_v2 + self.b_v2
    
    def select_action(self, state):
        """选择动作"""
        state = np.array(state).reshape(1, -1)
        mean, std = self._forward_policy(state)
        action = mean + std * np.random.randn(*mean.shape)
        return action.flatten()
    
    def store_transition(self, transition):
        """存储经验"""
        state, action, reward, done, _ = transition
        state = np.array(state).flatten()
        action = np.array(action).flatten()
        self.memory.append((state, action, reward, done))
    
    def update(self):
        """更新策略（简化版 PPO）"""
        if len(self.memory) < 8:
            return
        
        # 计算折扣回报
        rewards = [t[2] for t in self.memory]
        dones = [t[3] for t in self.memory]
        returns = []
        g = 0
        for r, d in zip(reversed(rewards), reversed(dones)):
            g = r + self.gamma * g * (1 - d)
            returns.insert(0, g)
        returns = np.array(returns)
        returns = (returns - returns.mean()) / (returns.std() + 1e-8)
        
        states = np.array([t[0] for t in self.memory])
        actions = np.array([t[1] for t in self.memory])
        
        # 简单策略梯度更新（PPO 简化版）
        h = np.tanh(states @ self.w1 + self.b1)
        mean = h @ self.w_mean + self.b_mean
        
        # 更新策略网络
        grad_w_mean = h.T @ ((actions - mean) * returns.reshape(-1, 1)) / len(self.memory)
        grad_b_mean = np.mean((actions - mean) * returns.reshape(-1, 1), axis=0)
        self.w_mean += self.lr * grad_w_mean
        self.b_mean += self.lr * grad_b_mean
        
        # 更新价值网络
        values = self._forward_value(states).flatten()
        grad_w_v2 = h.T @ (returns - values).reshape(-1, 1) / len(self.memory)
        grad_b_v2 = np.mean(returns - values)
        self.w_v2 += self.lr * grad_w_v2
        self.b_v2 += self.lr * grad_b_v2
        
        self.memory.clear()


class SimpleEnv:
    """简单测试环境：小车靠近目标"""
    def __init__(self):
        self.target = 5.0
        self.position = 0.0
    
    def reset(self):
        self.position = 0.0
        return np.array([self.position])
    
    def step(self, action):
        self.position += action[0] * 0.5
        reward = -abs(self.position - self.target)
        done = abs(self.position - self.target) < 0.1
        return np.array([self.position]), reward, done


def main():
    print("\n" + "=" * 50)
    print("PPO 强化学习演示（纯 NumPy 实现）")
    print("=" * 50)
    
    env = SimpleEnv()
    ppo = PPO(state_dim=1, action_dim=1, lr=0.01)
    rewards = []
    
    print("\n? 开始训练 PPO 智能体...")
    print(f"? 目标位置: {env.target}")
    print(f"? 训练回合: 100")
    print("-" * 40)
    
    for ep in range(100):
        s = env.reset()
        total = 0
        for _ in range(100):
            a = ppo.select_action(s)
            ns, r, done = env.step(a)
            ppo.store_transition((s, a, r, done, ns))
            s = ns
            total += r
            if done:
                break
        ppo.update()
        rewards.append(total)
        
        if (ep + 1) % 20 == 0:
            avg_reward = np.mean(rewards[-20:])
            print(f"  ? 回合 {ep+1:3d}/100, 平均奖励: {avg_reward:.2f}")
    
    print("-" * 40)
    print(f"\n? 训练完成！")
    print(f"   ? 最终平均奖励: {np.mean(rewards[-20:]):.2f}")
    print(f"   ? 最高奖励: {max(rewards):.2f}")
    
    # 绘制学习曲线
    if HAS_PLOT and plt:
        plt.figure(figsize=(10, 6))
        plt.plot(rewards, 'b-', alpha=0.7, label='每回合奖励')
        
        if len(rewards) >= 10:
            smooth = np.convolve(rewards, np.ones(10)/10, mode='valid')
            plt.plot(range(9, len(rewards)), smooth, 'r-', linewidth=2, label='10回合滑动平均')
        
        plt.xlabel('回合')
        plt.ylabel('奖励')
        plt.title('PPO 学习曲线 (纯 NumPy 实现)')
        plt.grid(True, alpha=0.3)
        plt.legend()
        
        try:
            plt.show()
        except:
            filename = "demo_ppo_output.png"
            plt.savefig(filename, dpi=150, bbox_inches='tight')
            print(f"\n? 学习曲线已保存至: {filename}")
            plt.close()
    else:
        print("\n?? matplotlib 不可用，跳过绘图")


if __name__ == "__main__":
    main()
