```markdown
# ub-clean-test（湘西紫）- 具身智能框架

> 美丽湘西 · 紫气东来 | 全球首个全栈开源具身智能框架

[中文版](#中文版) | [English](#english)

---

## <a id="中文版"></a> 中文版

**湘西紫 (ub-clean-test)** 是一个完整的具身智能框架，从感知到推理、从学习到规划、从协作到通用整合。

### 能力全景

| 层级 | 版本 | 能力 |
|------|------|------|
| 感知层 | 0.40-0.56 | 视觉、听觉、触觉、嗅觉、味觉、时间、距离、速度、重量、温度、亮度、颜色、情感、幽默 |
| 推理层 | 0.58-0.60 | 逻辑推理、常识推理、决策推理 |
| 元认知 | 0.61 | 自知之明、置信度评估、知识溯源 |
| 学习层 | 0.62-0.65 | 主动学习、错误反思、知识更新、迁移学习 |
| 交互层 | 0.66-0.68 | 多轮对话、多机器人协作、人机协作 |
| 规划层 | 0.69 | 策略生成、自主规划 |
| 整合层 | 0.71 | 通用推理、统一调度 |
| 决策层 | 0.77 | 行为树决策、任务状态机、失败重试、暂停恢复 |

### 快速开始

```bash
pip install ub-clean-test
```

验证先进入  python
# 对话示例
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("你好", "dialogue")
print(result.result.get("response"))

# 推理示例
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("所有人都会死，苏格拉底是人", "reasoning")
print(result.result)

# 决策示例
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_dict({"options": [{"name": "公交", "pros": ["便宜"]}]}, "decision")
print(result.result)

# 0.72.2 示例 - 0.74.1 示例
# 查询捡枕头
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("怎么捡枕头", "reasoning")
print("捡枕头:", result.result)

# 查询堆叠积木
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("怎么堆积木", "reasoning")
print("堆叠积木:", result.result)

# 查询擦桌子
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("怎么擦桌子", "reasoning")
print("擦桌子:", result.result)

# 查询叠毛巾
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("怎么叠毛巾", "reasoning")
print("叠毛巾:", result.result)

# 查询倒药水
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("怎么倒药水", "reasoning")
print("倒药水:", result.result)

# 0.75.0使用示例
# 翻译
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("把'我要喝水'翻译成英文", "reasoning")
print(result.result)

# 代码生成
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("用Python写一个冒泡排序", "reasoning")
print(result.result)

# 计算
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("123+456等于多少", "reasoning")
print(result.result)

# 0.77.0使用示例
验证先安装 python  打开powershell 安装 pip install ub-clean-test 直接复制测试即可。
# 通用推理
python -m ultra_balance.demo.demo_universal

# 任务规划（行为树 + 状态机）
python -m ultra_balance.demo.demo_task

# 安全监控
python -m ultra_balance.demo.demo_safety

# 自检系统
python -m ultra_balance.demo.demo_self_diagnosis

# 逻辑推理
python -m ultra_balance.demo.demo_reasoning

# 常识推理
python -m ultra_balance.demo.demo_common_sense

```

示例列表

  测试命令示列 python -m ultra_balance.demo.demo_trajectory
                     
感知与运动控制（0.11-0.56）

· demo_trajectory.py：轨迹规划演示
· demo_rrt.py：RRT路径规划演示
· demo_ppo.py：PPO强化学习演示
· demo_kalman.py：卡尔曼滤波演示
· demo_adaptive.py：自适应控制演示（0.11.0新增）
· demo_lipm.py：线性倒立摆演示（0.12.0新增）
· demo_zmp.py：ZMP稳定性演示（0.13.0新增）
· demo_mpc.py：MPC控制演示（0.14.0新增）
· demo_wbc.py：全身控制演示（0.15.0新增）
· demo_vla.py：VLA演示（0.16.0新增）
· demo_vision.py：视觉感知演示（0.17.0新增）
· demo_task.py：任务规划演示（0.18.1新增）
· demo_experience.py：经验记忆演示（0.19.0新增）
· demo_autotune.py：自动调参演示（0.20.0新增）
· demo_predict.py：状态预测演示（0.21.0新增）
· demo_safety.py：安全规则演示（0.22.0新增）
· demo_self_diagnosis.py：自检系统演示（0.23.0新增）
· demo_fault_recovery.py：故障恢复演示（0.24.0新增）
· demo_causal.py：因果推理演示（0.25.0新增）
· demo_long_term.py：长期记忆演示（0.26.2新增）
· demo_intent.py：意图识别演示（0.27.0新增）
· demo_curiosity.py：好奇机制演示（0.28.0新增）
· demo_imitation.py：模仿学习演示（0.29.0新增）
· demo_reflection.py：自我反思演示（0.30.0新增）
· demo_temporal.py：时序推理演示（0.31.0新增）
· demo_spatial.py：空间推理演示（0.32.0新增）
· demo_emotion.py：情感识别演示（0.33.0新增）
· demo_expression.py：情感表达演示（0.34.0新增）
· demo_personalized.py：个性化记忆演示（0.35.0新增）
· demo_personality.py：人格调节演示（0.36.0新增）
· demo_meta.py：元学习演示（0.37.0新增）
· demo_explain.py：可解释性演示（0.38.0新增）
· demo_active.py：主动学习演示（0.40.1新增）
· demo_compositional.py：组合推理演示（0.41.6新增）
· demo_layout.py：空间布局推理演示（0.42.94新增）
· demo_time.py：时间感知演示（0.43.0新增）
· demo_distance.py：距离感知演示（0.44.0新增）
· demo_speed.py：速度感知演示（0.45.3新增）
· demo_weight.py：重量感知演示（0.46.0新增）
· demo_temperature.py：温度感知演示（0.47.3新增）
· demo_brightness.py：亮度感知演示（0.48.1新增）
· demo_color.py：颜色感知演示（0.49.0新增）
· demo_sound.py：声音感知演示（0.50.3新增）
· demo_touch.py：触觉感知演示（0.51.6新增）
· demo_smell.py：嗅觉感知演示（0.52.0新增）
· demo_taste.py：味觉感知演示（0.53.1新增）


推理与认知（0.58-0.71）

· demo_metaphor.py：比喻理解演示（0.57.0新增）
· demo_reasoning.py：逻辑推理演示（0.58.9新增）
· demo_common_sense.py：常识推理演示（0.59.0新增）
· demo_decision.py：决策推理演示（0.60.1新增）
· demo_metacognition.py：元认知推理演示（0.61.0新增）
· demo_active_learning.py：主动学习演示（0.62.1新增）
· demo_error_reflection.py：错误反思演示（0.63.0新增）
· demo_knowledge_update.py：知识更新演示（0.64.0新增）
· demo_transfer_learning.py：迁移学习演示（0.65.0新增）
· demo_dialogue.py：多轮对话演示（0.66.1新增）
· demo_swarm.py：多机器人协作演示（0.67.0新增）
· demo_human_robot.py：人机协作演示（0.68.0新增）
· demo_strategy.py：策略生成演示（0.69.0新增）
· demo_universal.py：通用推理演示（0.71.0新增）
· 宇树经验: 300个真机操作经验，支持经验查询 (0.72.2新增)
· 宇树双经验：捡枕头 + 堆叠积木，601 次真机操作经验 (0.73.0 新增)
· 宇树五合一经验: 捡枕头、堆叠积木、擦桌子、叠毛巾、倒药水，共 1051 次真机操作经验 (0.74.1 新增)
· phi3:mini 集成：湘西紫自动检测 phi3:mini，有则增强，无则用自己的推理 中英互译，离线运行，隐私安全，代码生成，简单计算增强 完全本地部署 不依赖网络，不上传数据 (0.75.0 新增)
· 五次多项轨迹规划（减少机械冲击和振动）- 电机热监控（实时温度估计、过热预警、自动降额）- 电池电量监控（SOC估计、剩余时间预测、低电保护）- 通信心跳检测（断线检测、丢包率统计）- 电机堵转检测（堵转识别、紧急停止、恢复策略）- 统一安全守护（整合所有监控，状态机管理）(0.76.2 新增)
· demo_task.py：行为树决策、任务状态机、失败重试、暂停恢复 (0.78. 2新增)

版本

当前版本：0.78.2（湘西紫 正式版）

开源协议

Apache 2.0 License

作者

pengyeqin | xxbj433@qq.com  2026.04.05

---

<a id="english"></a> English

ub-clean-test (Xiangxi Purple) - Embodied AI Framework

Mind at one · Purple from the East | World's First Full-Stack Open-Source Embodied AI Framework

Lingxi Purple (ub-clean-test) is a complete embodied AI framework, covering perception, reasoning, learning, planning, collaboration, and universal integration.

Capabilities

Layer Version Capabilities
Perception 0.40-0.56 Vision, hearing, touch, smell, taste, time, distance, speed, weight, temperature, brightness, color, emotion, humor
Reasoning 0.58-0.60 Logical reasoning, common sense, decision reasoning
MetaCognition 0.61 Self-awareness, confidence assessment, knowledge tracing
Learning 0.62-0.65 Active learning, error reflection, knowledge update, transfer learning
Interaction 0.66-0.68 Dialogue management, swarm intelligence, human-robot collaboration
Planning 0.69 Strategy generation, autonomous planning
Integration 0.71 Universal reasoning, unified interface

Quick Start

```bash
pip install ub-clean-test
```
Verify first enter Python
# Dialogue Example
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("Hello", "dialogue")
print(result.result.get("response"))

# Reasoning Example
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("所有人都会死，苏格拉底是人", "reasoning")
print(result.result)

# Decision Example
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_dict({"options": [{"name": "Bus", "pros": ["Cheap"]}]}, "decision")
print(result.result)

0.72.2 Example - 0.74.1 Example
# Query: How to pick up a pillow
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("怎么捡枕头", "reasoning")
print("捡枕头:", result.result)

# Query: How to stack building blocks
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("How to stack building blocks", "reasoning")
print("Stack building blocks:", result.result)

# Query: How to clean a table
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("How to clean a table", "reasoning")
print("Clean table:", result.result)

# Query: How to fold a towel
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("How to fold a towel", "reasoning")
print("Fold towel:", result.result)

# Query: How to pour liquid medicine
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("How to pour liquid medicine", "reasoning")
print("Pour liquid medicine:", result.result)

0.75.0 Usage Example
# Translation
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("把'我要喝水'翻译成英文", "reasoning")
print(result.result)

# Code Generation
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("用Python写一个冒泡排序", "reasoning")
print(result.result)

# Calculation
from ultra_balance.reasoning.universal import UniversalReasoning

ur = UniversalReasoning()
result = ur.reason_text("What is 123 + 456", "reasoning")
print(result.result)

# 0.77.0 Usage Example
To verify, first install Python, open PowerShell, install with pip install ub-clean-test, then copy and test directly.
Universal Reasoning
python -m ultra_balance.demo.demo_universal

python -m ultra_balance.demo.demo_task

python -m ultra_balance.demo.demo_safety

python -m ultra_balance.demo.demo_self_diagnosis

python -m ultra_balance.demo.demo_reasoning

python -m ultra_balance.demo.demo_common_sense

```

Demos

Perception & Control (0.11-0.56)

· demo_trajectory.py: Trajectory planning demo
· demo_rrt.py: RRT path planning demo
· demo_ppo.py: PPO reinforcement learning demo
· demo_kalman.py: Kalman filter demo
· demo_adaptive.py: Adaptive control demo (new in 0.11.0)
· demo_lipm.py: Linear inverted pendulum demo (new in 0.12.0)
· demo_zmp.py: ZMP stability demo (new in 0.13.0)
· demo_mpc.py: MPC control demo (new in 0.14.0)
· demo_wbc.py: Whole body control demo (new in 0.15.0)
· demo_vla.py: VLA demo (new in 0.16.0)
· demo_vision.py: Vision perception demo (new in 0.17.0)
· demo_task.py: Task planning demo (new in 0.18.1)
· demo_experience.py: Experience memory demo (new in 0.19.0)
· demo_autotune.py: Auto-tuning demo (new in 0.20.0)
· demo_predict.py: State prediction demo (new in 0.21.0)
· demo_safety.py: Safety rules demo (new in 0.22.0)
· demo_self_diagnosis.py: Self-diagnosis demo (new in 0.23.0)
· demo_fault_recovery.py: Fault recovery demo (new in 0.24.0)
· demo_causal.py: Causal reasoning demo (new in 0.25.0)
· demo_long_term.py: Long-term memory demo (new in 0.26.2)
· demo_intent.py: Intent recognition demo (new in 0.27.0)
· demo_curiosity.py: Curiosity demo (new in 0.28.0)
· demo_imitation.py: Imitation learning demo (new in 0.29.0)
· demo_reflection.py: Self-reflection demo (new in 0.30.0)
· demo_temporal.py: Temporal reasoning demo (new in 0.31.0)
· demo_spatial.py: Spatial reasoning demo (new in 0.32.0)
· demo_emotion.py: Emotion recognition demo (new in 0.33.0)
· demo_expression.py: Emotional expression demo (new in 0.34.0)
· demo_personalized.py: Personalized memory demo (new in 0.35.0)
· demo_personality.py: Personality tuning demo (new in 0.36.0)
· demo_meta.py: Meta learning demo (new in 0.37.0)
· demo_explain.py: Explainability demo (new in 0.38.0)
· demo_active.py: Active learning demo (new in 0.40.1)
· demo_compositional.py: Compositional reasoning demo (new in 0.41.6)
· demo_layout.py: Spatial layout reasoning demo (new in 0.42.94)
· demo_time.py: Time perception demo (new in 0.43.0)
· demo_distance.py: Distance perception demo (new in 0.44.0)
· demo_speed.py: Speed perception demo (new in 0.45.3)
· demo_weight.py: Weight perception demo (new in 0.46.0)
· demo_temperature.py: Temperature perception demo (new in 0.47.3)
· demo_brightness.py: Brightness perception demo (new in 0.48.1)
· demo_color.py: Color perception demo (new in 0.49.0)
· demo_sound.py: Sound perception demo (new in 0.50.3)
· demo_touch.py: Touch perception demo (new in 0.51.6)
· demo_smell.py: Smell perception demo (new in 0.52.0)
· demo_taste.py: Taste perception demo (new in 0.53.1)

Reasoning & Cognition (0.58-0.71)

· demo_metaphor.py: Metaphor understanding demo (new in 0.57.0)
· demo_reasoning.py: Logical reasoning demo (new in 0.58.9)
· demo_common_sense.py: Common sense demo (new in 0.59.0)
· demo_decision.py: Decision reasoning demo (new in 0.60.1)
· demo_metacognition.py: Meta-cognition demo (new in 0.61.0)
· demo_active_learning.py: Active learning demo (new in 0.62.1)
· demo_error_reflection.py: Error reflection demo (new in 0.63.0)
· demo_knowledge_update.py: Knowledge update demo (new in 0.64.0)
· demo_transfer_learning.py: Transfer learning demo (new in 0.65.0)
· demo_dialogue.py: Dialogue management demo (new in 0.66.1)
· demo_swarm.py: Swarm intelligence demo (new in 0.67.0)
· demo_human_robot.py: Human-robot collaboration demo (new in 0.68.0)
· demo_strategy.py: Strategy generation demo (new in 0.69.0)
· demo_universal.py: Universal reasoning demo (new in 0.71.0)
· Unitree Experiences: 300 practical device operation experiences, supporting experience query (new in 0.72.2)
· Unitree Dual Experiences：Physical device operation experience: 601 successful trials of pillow grasping and block stacking (new in 0.73.0)
· Unitree 5-in-1 Experiences: Picking up pillows, stacking building blocks, wiping tables, folding towels, and pouring liquid medicine, with a total of 1,051 real-machine operation experiences (new in 0.74.1)
· phi3:mini Integration: Xiangxi Purple automatically detects phi3:mini, enhances if present, uses its own reasoning if not. Chinese-English translation, offline operation, privacy and security, code generation, simple calculation enhancement. Fully local deployment, no reliance on network, no data upload (new in 0.75.0)   
· Quintic Polynomial Trajectory Planning (reduce mechanical impact and vibration)
· Motor Thermal Monitoring (real-time temperature estimation, overheating early warning, automatic derating)
· Battery Power Monitoring (SOC estimation, remaining runtime prediction, low-power protection)
· Communication Heartbeat Detection (disconnection detection, packet loss rate statistics)
· Motor Stall Detection (stall identification, emergency stop, recovery strategy)
· Unified Safety Protection (integrate all monitoring functions, state machine management)  (new in 0.76.2)
· demo_task.py：Behavior Tree Decision Making Task State Machine Failure Retry / Retry on Failure Pause and Resume (new in 0.78.2)

Version

Current: 0.78.2 (Xiangxi Purple Official Release)

License

Apache 2.0 License

Author

pengyeqin | xxbj433@qq.com  2026.04.05

```

---

