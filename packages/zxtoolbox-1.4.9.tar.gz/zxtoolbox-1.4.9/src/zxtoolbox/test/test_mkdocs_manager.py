"""Tests for zxtoolbox.mkdocs_manager module."""

import subprocess
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock, mock_open

import pytest

from zxtoolbox.mkdocs_manager import (
    create_project,
    build_project,
    serve_project,
    _load_batch_config,
    batch_build,
    build_project_by_name,
)


class TestCreateProject:
    """Test MkDocs project creation."""

    def test_create_project_basic(self, tmp_path):
        """Test basic project creation."""
        project_dir = tmp_path / "my-docs"
        result = create_project(str(project_dir))

        assert result == project_dir
        assert project_dir.exists()
        assert (project_dir / "docs").exists()
        assert (project_dir / "mkdocs.yml").exists()
        assert (project_dir / "docs" / "index.md").exists()

    def test_create_project_with_site_name(self, tmp_path):
        """Test project creation with custom site name."""
        project_dir = tmp_path / "my-docs"
        create_project(str(project_dir), site_name="My Custom Site")

        mkdocs_yml = project_dir / "mkdocs.yml"
        content = mkdocs_yml.read_text()
        assert "My Custom Site" in content

    def test_create_project_existing_files(self, tmp_path, capsys):
        """Test project creation when files already exist."""
        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("existing")
        (project_dir / "docs").mkdir()
        (project_dir / "docs" / "index.md").write_text("existing")

        create_project(str(project_dir))

        captured = capsys.readouterr()
        assert "已存在" in captured.out or "WARN" in captured.out

    def test_create_project_nested(self, tmp_path):
        """Test creating project in nested directory."""
        project_dir = tmp_path / "a" / "b" / "my-docs"
        result = create_project(str(project_dir))
        assert result.exists()
        assert (result / "mkdocs.yml").exists()


class TestBuildProject:
    """Test MkDocs project building."""

    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_build_success(self, mock_run, tmp_path, capsys):
        """Test successful project build."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        result = build_project(str(project_dir))

        assert result is True
        mock_run.assert_called_once()

    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_build_with_output_dir(self, mock_run, tmp_path):
        """Test build with custom output directory."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")
        output_dir = tmp_path / "output"

        build_project(str(project_dir), output_dir=str(output_dir))

        call_args = mock_run.call_args[0][0]
        assert "-d" in call_args
        assert str(output_dir) in call_args

    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_build_strict_mode(self, mock_run, tmp_path):
        """Test build with strict mode."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        build_project(str(project_dir), strict=True)

        call_args = mock_run.call_args[0][0]
        assert "--strict" in call_args

    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_build_failure(self, mock_run, tmp_path, capsys):
        """Test failed project build."""
        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="Build error")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        result = build_project(str(project_dir))

        assert result is False

    def test_build_missing_config(self, tmp_path, capsys):
        """Test build with missing config file."""
        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()

        result = build_project(str(project_dir), config_file="nonexistent.yml")

        assert result is False

    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_build_custom_config(self, mock_run, tmp_path):
        """Test build with custom config file."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        custom_config = project_dir / "custom.yml"
        custom_config.write_text("site_name: Custom\n")

        build_project(str(project_dir), config_file="custom.yml")

        call_args = mock_run.call_args[0][0]
        assert str(custom_config) in call_args

    @patch("zxtoolbox.mkdocs_manager.importlib.util.find_spec", return_value=None)
    def test_build_mkdocs_not_installed(self, mock_find_spec, tmp_path, capsys):
        """Test build when mkdocs is not installed."""
        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        result = build_project(str(project_dir))

        assert result is False
        captured = capsys.readouterr()
        assert "mkdocs 未安装" in captured.out


class TestLoadBatchConfig:
    """Test batch config loading."""

    def test_load_valid_config(self, tmp_path):
        """Test loading a valid batch config."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[[projects]]\nproject_dir = "/path/1"\noutput_dir = "/out/1"\n'
            '[[projects]]\nproject_dir = "/path/2"\n'
        )

        result = _load_batch_config(str(config_file))

        assert len(result) == 2
        assert result[0]["project_dir"] == "/path/1"
        assert result[0]["output_dir"] == "/out/1"
        assert result[1]["project_dir"] == "/path/2"

    def test_load_missing_config(self, tmp_path):
        """Test loading a non-existent config file."""
        with pytest.raises(FileNotFoundError):
            _load_batch_config(tmp_path / "nonexistent.toml")

    def test_load_empty_projects(self, tmp_path):
        """Test loading config with no projects."""
        config_file = tmp_path / "config.toml"
        config_file.write_text("# empty config\n")

        with pytest.raises(ValueError):
            _load_batch_config(str(config_file))


class TestBatchBuild:
    """Test batch building."""

    @patch("zxtoolbox.mkdocs_manager.build_project", return_value=True)
    @patch("zxtoolbox.mkdocs_manager._load_batch_config")
    def test_batch_build_all_success(self, mock_load, mock_build, tmp_path, capsys):
        """Test batch build where all projects succeed."""
        mock_load.return_value = [
            {"project_dir": "/path/1", "output_dir": "/out/1"},
            {"project_dir": "/path/2"},
        ]

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[[projects]]\nproject_dir = "/path/1"\n'
            '[[projects]]\nproject_dir = "/path/2"\n'
        )

        result = batch_build(str(config_file))

        assert len(result) == 2
        assert all(result.values())
        assert mock_build.call_count == 2

    @patch("zxtoolbox.mkdocs_manager.build_project", side_effect=[True, False, True])
    @patch("zxtoolbox.mkdocs_manager._load_batch_config")
    def test_batch_build_partial_failure(self, mock_load, mock_build, tmp_path):
        """Test batch build with some failures."""
        mock_load.return_value = [
            {"project_dir": "/path/1"},
            {"project_dir": "/path/2"},
            {"project_dir": "/path/3"},
        ]

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[[projects]]\nproject_dir = "/path/1"\n'
            '[[projects]]\nproject_dir = "/path/2"\n'
            '[[projects]]\nproject_dir = "/path/3"\n'
        )

        result = batch_build(str(config_file))

        assert len(result) == 3
        assert result["/path/1"] is True
        assert result["/path/2"] is False
        assert result["/path/3"] is True

    @patch("zxtoolbox.mkdocs_manager._load_batch_config")
    def test_batch_build_missing_config(self, mock_load, tmp_path, capsys):
        """Test batch build with missing config file."""
        mock_load.side_effect = FileNotFoundError("Config not found")

        result = batch_build(tmp_path / "nonexistent.toml")

        assert result == {}

    @patch("zxtoolbox.mkdocs_manager._load_batch_config")
    def test_batch_build_no_projects(self, mock_load, tmp_path, capsys):
        """Test batch build with no projects in config."""
        mock_load.side_effect = ValueError("No projects found")

        result = batch_build(tmp_path / "config.toml")

        assert result == {}

    @patch("zxtoolbox.mkdocs_manager.build_project")
    @patch("zxtoolbox.mkdocs_manager._load_batch_config")
    def test_batch_build_dry_run(self, mock_load, mock_build, tmp_path, capsys):
        """Test batch build dry-run mode."""
        mock_load.return_value = [
            {"project_dir": "/path/1", "output_dir": "/out/1"},
        ]

        config_file = tmp_path / "config.toml"
        config_file.write_text('[[projects]]\nproject_dir = "/path/1"\n')

        result = batch_build(str(config_file), dry_run=True)

        assert len(result) == 1
        mock_build.assert_not_called()

    @patch("zxtoolbox.mkdocs_manager.build_project", return_value=True)
    @patch("zxtoolbox.mkdocs_manager._load_batch_config")
    def test_batch_build_missing_project_dir(self, mock_load, mock_build, tmp_path):
        """Test batch build with missing project_dir."""
        mock_load.return_value = [{"output_dir": "/out/1"}]

        config_file = tmp_path / "config.toml"
        config_file.write_text('[[projects]]\noutput_dir = "/out/1"\n')

        result = batch_build(str(config_file))

        # Should skip the project with missing project_dir
        mock_build.assert_not_called()


class TestServeProject:
    """Test MkDocs project serving."""

    @patch("zxtoolbox.mkdocs_manager.importlib.util.find_spec")
    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_serve_default(self, mock_run, mock_find_spec, tmp_path, capsys):
        """Test serve with default settings."""
        mock_find_spec.return_value = MagicMock()  # mkdocs is installed
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        serve_project(str(project_dir))

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert "-m" in cmd
        assert "mkdocs" in cmd
        assert "serve" in cmd
        assert "--no-livereload" not in cmd

    @patch("zxtoolbox.mkdocs_manager.importlib.util.find_spec")
    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_serve_with_dev_addr(self, mock_run, mock_find_spec, tmp_path, capsys):
        """Test serve with custom dev address."""
        mock_find_spec.return_value = MagicMock()
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        serve_project(str(project_dir), dev_addr="0.0.0.0:8080")

        cmd = mock_run.call_args[0][0]
        assert "--dev-addr" in cmd
        assert "0.0.0.0:8080" in cmd

    @patch("zxtoolbox.mkdocs_manager.importlib.util.find_spec")
    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_serve_no_livereload(self, mock_run, mock_find_spec, tmp_path, capsys):
        """Test serve with livereload disabled."""
        mock_find_spec.return_value = MagicMock()
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        serve_project(str(project_dir), no_livereload=True)

        cmd = mock_run.call_args[0][0]
        assert "--no-livereload" in cmd

    @patch("zxtoolbox.mkdocs_manager.importlib.util.find_spec")
    @patch("zxtoolbox.mkdocs_manager.subprocess.run")
    def test_serve_custom_config(self, mock_run, mock_find_spec, tmp_path, capsys):
        """Test serve with custom config file."""
        mock_find_spec.return_value = MagicMock()
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        custom_config = project_dir / "custom.yml"
        custom_config.write_text("site_name: Custom\n")

        serve_project(str(project_dir), config_file="custom.yml")

        cmd = mock_run.call_args[0][0]
        assert str(custom_config) in cmd

    def test_serve_missing_config(self, tmp_path, capsys):
        """Test serve with missing config file."""
        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()

        result = serve_project(str(project_dir), config_file="nonexistent.yml")

        assert result is None

    @patch("zxtoolbox.mkdocs_manager.importlib.util.find_spec", return_value=None)
    def test_serve_mkdocs_not_installed(self, mock_find_spec, tmp_path, capsys):
        """Test serve when mkdocs is not installed."""
        project_dir = tmp_path / "my-docs"
        project_dir.mkdir()
        (project_dir / "mkdocs.yml").write_text("site_name: Test\n")

        result = serve_project(str(project_dir))

        assert result is None
        captured = capsys.readouterr()
        assert "mkdocs 未安装" in captured.out


class TestBuildProjectByName:
    """Test building project by name from config."""

    @patch("zxtoolbox.mkdocs_manager.build_project", return_value=True)
    @patch("zxtoolbox.mkdocs_manager.load_project_by_name")
    def test_build_by_name_found(self, mock_load, mock_build, capsys):
        """Test building project by name when found in config."""
        mock_load.return_value = {
            "name": "myblog",
            "project_dir": "/path/to/myblog",
            "output_dir": "/site",
            "config_file": "custom.yml",
            "strict": True,
        }

        result = build_project_by_name("myblog")
        assert result is True
        mock_build.assert_called_once_with(
            project_dir="/path/to/myblog",
            output_dir="/site",
            config_file="custom.yml",
            strict=True,
        )

    @patch("zxtoolbox.mkdocs_manager.build_project", return_value=True)
    @patch("zxtoolbox.mkdocs_manager.load_project_by_name")
    def test_build_by_name_with_output_override(self, mock_load, mock_build, capsys):
        """Test building project by name with output_dir override."""
        mock_load.return_value = {
            "name": "myblog",
            "project_dir": "/path/to/myblog",
            "output_dir": "/site",
        }

        result = build_project_by_name("myblog", output_dir="/custom/output")
        assert result is True
        mock_build.assert_called_once_with(
            project_dir="/path/to/myblog",
            output_dir="/custom/output",
            config_file=None,
            strict=False,
        )

    @patch("zxtoolbox.mkdocs_manager.load_project_by_name")
    def test_build_by_name_not_found(self, mock_load, capsys):
        """Test building project by name when name not found in config."""
        mock_load.return_value = None

        result = build_project_by_name("nonexistent")
        assert result is False
        captured = capsys.readouterr()
        assert "未在配置文件中找到" in captured.out

    @patch("zxtoolbox.mkdocs_manager.load_project_by_name")
    def test_build_by_name_no_project_dir(self, mock_load, capsys):
        """Test building project by name when project_dir is missing."""
        mock_load.return_value = {"name": "myblog"}

        result = build_project_by_name("myblog")
        assert result is False
        captured = capsys.readouterr()
        assert "未配置 project_dir" in captured.out

    @patch("zxtoolbox.mkdocs_manager.build_project", return_value=True)
    @patch("zxtoolbox.mkdocs_manager.load_project_by_name")
    def test_build_by_name_stict_from_config(self, mock_load, mock_build, capsys):
        """Test building project by name uses strict from config."""
        mock_load.return_value = {
            "name": "myblog",
            "project_dir": "/path/to/myblog",
            "strict": True,
        }

        result = build_project_by_name("myblog")
        assert result is True
        # strict=True from config should be passed to build_project
        mock_build.assert_called_once_with(
            project_dir="/path/to/myblog",
            output_dir=None,
            config_file=None,
            strict=True,
        )

    @patch("zxtoolbox.mkdocs_manager.build_project", return_value=True)
    @patch("zxtoolbox.mkdocs_manager.load_project_by_name")
    def test_build_by_name_custom_config_path(self, mock_load, mock_build, capsys):
        """Test building project by name with custom config path."""
        mock_load.return_value = {
            "name": "myblog",
            "project_dir": "/path/to/myblog",
        }

        result = build_project_by_name("myblog", config_path="/custom/zxtool.toml")
        assert result is True
        mock_load.assert_called_once_with("myblog", config_path="/custom/zxtool.toml")
