"""
watcher.py — File system watcher for incremental re-indexing.

On supported platforms the default is **event-driven** (Watchdog inotify / ReadDirectoryChangesW
/ FSEvents) with **debounced** batches, so the tree is not re-hashed on a timer.

Use `--use-poll` to restore the legacy rglob+hash+sleep loop (e.g. network / NFS).
"""

from __future__ import annotations

import hashlib
import threading
import time
from collections.abc import Generator
from pathlib import Path
from threading import Event

from rich.console import Console
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from agsuperbrain.analytics.report import generate_report
from agsuperbrain.core.pipeline import CodeGraphPipeline
from agsuperbrain.memory.graph.graph_store import GraphStore
from agsuperbrain.memory.graph.visualizer import visualize as viz
from agsuperbrain.memory.vector.vector_store import VectorStore

console = Console()

_CODE_SUFFIXES: frozenset[str] = frozenset((".py", ".js", ".ts", ".mjs"))


def _file_hash(fp: Path) -> str:
    """Compute MD5 hash of file content."""
    if not fp.exists():
        return ""
    try:
        return hashlib.md5(fp.read_bytes()).hexdigest()
    except OSError:
        return ""


def _norm(p: Path) -> Path:
    try:
        return p.resolve()
    except OSError:
        return p


def _candidates_in_watch(
    watch_paths: list[Path], exclude: frozenset[str], exts: frozenset[str]
) -> Generator[Path, None, None]:
    for wp in watch_paths:
        if not wp.exists():
            continue
        if wp.is_file():
            cands = [wp] if wp.suffix.lower() in exts else []
        else:
            cands = [fp for fp in wp.rglob("*") if fp.is_file() and fp.suffix.lower() in exts]
        for fp in cands:
            if any(part in exclude for part in fp.parts):
                continue
            yield _norm(fp)


class FileWatcher:
    """
    Watch directories for changes and re-index modified files.

    For each change this runs the **Kùzu** ingest pipeline, then an **incremental**
    Qdrant re-embed: only graph nodes for the changed `source_path` values are
    read (Kùzu `IN` — not a full table scan) and embedded — not a whole-repo
    reindex. For a **blank project** you still need an initial
    `agsuperbrain index-vectors` (or `agsuperbrain init`, which runs that). Use
    a **full** `agsuperbrain index-vectors` when you want to rebuild all vectors
    at once.

    **Default (event mode):** kernel file events + debounce. No periodic full-tree hash.

    **Optional `--use-poll` / `use_polling=True`:** legacy rglob+MD5+sleep; use on
    **network shares** (NFS, SMB) where file events are unreliable.
    """

    def __init__(
        self,
        graph_store: GraphStore,
        vector_store: VectorStore,
        watch_paths: list[Path],
        exclude_dirs: frozenset[str] | None = None,
    ) -> None:
        self.gs = graph_store
        self.vs = vector_store
        self.watch_paths = watch_paths
        self.exclude_dirs = exclude_dirs or frozenset()
        self._file_hashes: dict[Path, str] = {}
        self._pipeline = CodeGraphPipeline(graph_store, vector_store)
        self._stop_event = Event()
        self._text_embedder = None
        # Event-driven debounce
        self._pending: set[Path] = set()
        self._pending_lock = threading.Lock()
        self._debounce_s: float = 0.4
        self._debounce_timer: threading.Timer | None = None
        self._timer_lock = threading.Lock()
        self._observer: Observer | None = None
        self._file_only_restrict: set[Path] | None = None  # when watching explicit file path(s)

    def _should_process(self, fp: Path) -> bool:
        if not fp.is_file() or not fp.exists():
            return False
        return fp.suffix.lower() in _CODE_SUFFIXES

    def _is_excluded(self, fp: Path) -> bool:
        return any(part in self.exclude_dirs for part in fp.parts)

    def _get_embedder(self):
        if self._text_embedder is None:
            from agsuperbrain.memory.vector.embedder import TextEmbedder

            self._text_embedder = TextEmbedder()
        return self._text_embedder

    def _get_changed_files_hash_scan(self) -> list[Path]:
        """Find files that have changed since last check (used by `run --once` and poll mode)."""
        changed: list[Path] = []
        for fp in _candidates_in_watch(self.watch_paths, self.exclude_dirs, _CODE_SUFFIXES):
            if self._is_excluded(fp):
                continue
            current = _file_hash(fp)
            if not current:
                continue
            if fp not in self._file_hashes or self._file_hashes[fp] != current:
                self._file_hashes[fp] = current
                changed.append(fp)
        return changed

    def _bootstrap_fingerprints(self) -> None:
        """After startup, learn current hashes so we do not re-process until something changes."""
        n = 0
        for fp in _candidates_in_watch(self.watch_paths, self.exclude_dirs, _CODE_SUFFIXES):
            if self._is_excluded(fp):
                continue
            h = _file_hash(fp)
            if h:
                self._file_hashes[fp] = h
                n += 1
        console.print(f"[dim]Watcher baseline: {n} file(s) fingerprinted (no reingest).[/dim]")

    def _queue_event_path(self, raw: Path) -> None:
        fp = _norm(raw)
        if self._file_only_restrict is not None:
            if fp not in self._file_only_restrict:
                return
        else:
            if not self._should_process(fp) or self._is_excluded(fp):
                return
        with self._pending_lock:
            self._pending.add(fp)
        self._schedule_debounced_flush()

    def _schedule_debounced_flush(self) -> None:
        with self._timer_lock:
            if self._debounce_timer is not None:
                self._debounce_timer.cancel()
            self._debounce_timer = threading.Timer(self._debounce_s, self._flush_pending)
            self._debounce_timer.daemon = True
            self._debounce_timer.start()

    def _cancel_debounce(self) -> None:
        with self._timer_lock:
            if self._debounce_timer is not None:
                self._debounce_timer.cancel()
                self._debounce_timer = None

    def _flush_pending(self) -> None:
        with self._timer_lock:
            if self._debounce_timer is not None:
                self._debounce_timer = None
        with self._pending_lock:
            batch = list(self._pending)
            self._pending.clear()
        if not batch:
            return
        self._reindex_file_list(batch, do_sync=True)

    def _on_deleted(self, p: Path) -> None:
        n = _norm(p)
        self._file_hashes.pop(n, None)
        self._cancel_debounce()
        self._reindex_file_list([], do_sync=True, delete_sweep_only=True)

    def _reindex_file_list(
        self,
        changed: list[Path],
        *,
        do_sync: bool = True,
        delete_sweep_only: bool = False,
    ) -> int:
        n_del = self._pipeline.sync_deleted_files() if (do_sync or delete_sweep_only) else 0
        if delete_sweep_only:
            if n_del and self.watch_paths:
                r = _norm(
                    self.watch_paths[0] if self.watch_paths[0].is_dir() else self.watch_paths[0].parent
                )
                self._generate_reports_at(r)
            return 0

        if not changed:
            if n_del and self.watch_paths:
                r = _norm(
                    self.watch_paths[0] if self.watch_paths[0].is_dir() else self.watch_paths[0].parent
                )
                self._generate_reports_at(r)
            return 0

        # Dedupe, stable order
        unique: list[Path] = list(dict.fromkeys(_norm(p) for p in changed if p))
        for fp in unique:
            h = _file_hash(fp)
            if h:
                self._file_hashes[fp] = h

        console.print(f"[cyan]Re-indexing {len(unique)} file(s):[/cyan]")
        for fp in unique:
            console.print(f"  [green]{fp}[/green]")

        self._pipeline.run(unique, verbose=True)

        try:
            from agsuperbrain.core.index_pipeline import VectorIndexPipeline

            m = VectorIndexPipeline(
                self.gs,
                self.vs,
                self._get_embedder(),
            ).reindex_source_paths(unique)
            if m:
                console.print(
                    f"[green]✓[/green] Qdrant incremental reindex: {m} node(s) — "
                    f"[bold]search_code[/bold] in sync (not a full reindex)"
                )
        except Exception as exc:  # best-effort: graph is already written
            console.print(f"[yellow]Warning: Qdrant re-embed after watch failed:[/yellow] {exc}")
            console.print(
                "[dim]Graph is up to date; run [cyan]agsuperbrain index-vectors[/cyan] to fix vectors manually.[/dim]"
            )

        root = _norm(self.watch_paths[0] if self.watch_paths[0].is_dir() else self.watch_paths[0].parent)
        self._generate_reports_at(root)
        return len(unique)

    def _generate_reports_at(self, project_root: Path) -> None:
        output_dir = project_root / ".agsuperbrain"
        html_path = output_dir / "graph.html"
        report_path = output_dir / "GRAPH_REPORT.md"
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            viz(self.gs, html_path, None, 3)
            console.print(f"[dim]Updated:[/dim] {html_path}")
        except OSError as e:
            console.print(f"[yellow]Warning: failed to generate graph.html: {e}[/yellow]")
        try:
            md = generate_report(self.gs)
            report_path.write_text(md, encoding="utf-8")
            console.print(f"[dim]Updated:[/dim] {report_path}")
        except OSError as e:
            console.print(f"[yellow]Warning: failed to generate GRAPH_REPORT.md: {e}[/yellow]")

    def run_once(self) -> int:
        """
        Single pass: rglob+hash, re-index if anything changed, sweep deleted.
        (Used by `watch --once` and legacy poll mode.)
        """
        self._cancel_debounce()
        changed = self._get_changed_files_hash_scan()
        n_del = self._pipeline.sync_deleted_files()

        if not changed:
            if n_del:
                console.print(f"[dim]Removed {n_del} graph entry(ies) for missing files.[/dim]")
            console.print("[dim]No changes detected[/dim]")
            if self.watch_paths:
                r = _norm(
                    self.watch_paths[0] if self.watch_paths[0].is_dir() else self.watch_paths[0].parent
                )
                if n_del:
                    self._generate_reports_at(r)
            return 0
        return self._reindex_file_list(changed, do_sync=False)

    def _start_polling(self, interval: float) -> None:
        console.print(
            f"[yellow]Using legacy poll mode[/yellow] (interval {interval}s) — rglob+hash. "
            "[dim]On local disks prefer default event+debounce.[/dim]"
        )
        while not self._stop_event.is_set():
            self.run_once()
            self._stop_event.wait(timeout=interval)

    def _start_observer(self, debounce: float) -> None:
        self._debounce_s = debounce
        self._file_only_restrict = None
        self._bootstrap_fingerprints()
        handler = _SuperBrainHandler(self)
        self._observer = Observer()
        n_sched = 0
        file_restrict: set[Path] = set()
        for raw in self.watch_paths:
            if not raw.exists():
                console.print(f"[yellow]Skip missing path:[/yellow] {raw}")
                continue
            w = _norm(raw)
            if w.is_file():
                if self._is_excluded(w):
                    continue
                file_restrict.add(w)
                self._observer.schedule(handler, str(w.parent), recursive=False)
                n_sched += 1
            else:
                if self._is_excluded(w) or not w.is_dir():
                    continue
                self._observer.schedule(handler, str(w), recursive=True)
                n_sched += 1
        if file_restrict:
            self._file_only_restrict = file_restrict
        if n_sched == 0:
            raise RuntimeError("No valid watch path — paths must exist and not be excluded")
        self._observer.start()
        console.print(
            f"[green]Event watcher running[/green] (debounce {self._debounce_s}s) — [dim]Ctrl+C to stop[/dim]"
        )
        try:
            while not self._stop_event.is_set():
                time.sleep(0.3)
        finally:
            obs = self._observer
            if obs is not None:
                alive = getattr(obs, "is_alive", None)
                if callable(alive) and alive():
                    obs.stop()
                    obs.join(timeout=10.0)
            self._cancel_debounce()
            self._flush_pending()
            self._observer = None

    def start(
        self,
        *,
        debounce: float = 0.4,
        use_polling: bool = False,
        poll_interval: float = 2.0,
    ) -> None:
        if use_polling:
            _ = debounce
            self._start_polling(poll_interval)
        else:
            self._start_observer(debounce)

    def stop(self) -> None:
        self._stop_event.set()
        obs = self._observer
        if obs is not None:
            alive = getattr(obs, "is_alive", None)
            if callable(alive) and alive():
                obs.stop()
            join = getattr(obs, "join", None)
            if callable(join):
                join(timeout=10.0)
        self._cancel_debounce()


class _SuperBrainHandler(FileSystemEventHandler):
    def __init__(self, watcher: FileWatcher) -> None:
        self._w = watcher

    def on_modified(self, event: FileSystemEvent) -> None:
        if not event.is_directory and event.src_path:
            self._w._queue_event_path(Path(event.src_path))

    def on_created(self, event: FileSystemEvent) -> None:
        if not event.is_directory and event.src_path:
            self._w._queue_event_path(Path(event.src_path))

    def on_moved(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        if event.src_path:
            self._w._file_hashes.pop(_norm(Path(event.src_path)), None)
        if getattr(event, "dest_path", None):
            self._w._queue_event_path(Path(event.dest_path))  # type: ignore[attr-defined]

    def on_deleted(self, event: FileSystemEvent) -> None:
        if not event.is_directory and event.src_path:
            self._w._on_deleted(Path(event.src_path))
