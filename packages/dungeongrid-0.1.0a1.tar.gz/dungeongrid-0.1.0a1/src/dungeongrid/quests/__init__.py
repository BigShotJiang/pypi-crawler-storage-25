"""Bundled original DungeonGrid quests."""
