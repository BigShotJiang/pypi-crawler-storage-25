import unittest

from licos_agent_runtime.payload import to_stream_input


class PayloadTests(unittest.TestCase):
    def test_openai_messages_are_converted_to_graph_input(self):
        payload = {
            "model": "gpt-test",
            "stream": False,
            "temperature": 0.2,
            "messages": [
                {"role": "system", "content": "be concise"},
                {"role": "user", "content": "hello"},
            ],
        }

        result = to_stream_input(payload)

        self.assertNotIn("model", result)
        self.assertNotIn("temperature", result)
        self.assertEqual(result["messages"], payload["messages"])
        self.assertEqual(result["input"], "hello")
        self.assertEqual(result["text"], "hello")

    def test_plain_prompt_is_supported(self):
        result = to_stream_input({"prompt": "build it", "model": "x"})

        self.assertEqual(result["input"], "build it")
        self.assertEqual(result["text"], "build it")
        self.assertNotIn("model", result)


if __name__ == "__main__":
    unittest.main()
