import os
import unittest
from unittest.mock import patch

from licos_agent_runtime.context import RuntimeIdentity, new_context


class ContextTests(unittest.TestCase):
    def test_new_context_reads_run_id_header_case_insensitively(self):
        ctx = new_context("run", {"X-Run-Id": "run-1"})

        self.assertEqual(ctx.run_id, "run-1")
        self.assertEqual(ctx.header("x-run-id"), "run-1")

    def test_runtime_identity_reads_licos_and_agent_env(self):
        env = {
            "AGENT_USER_ID": "user-1",
            "AGENT_WORKSPACE_ID": "workspace-1",
            "AGENT_PROJECT_ID": "project-1",
            "AGENT_PROJECT_TYPE": "AGENT",
            "LICOS_USER_TOKEN": "user_token",
            "LICOS_RUNTIME_TOKEN": "runtime_token",
        }
        with patch.dict(os.environ, env, clear=True):
            identity = RuntimeIdentity.from_env()

        self.assertEqual(identity.user_id, "user-1")
        self.assertEqual(identity.workspace_id, "workspace-1")
        self.assertEqual(identity.project_id, "project-1")
        self.assertEqual(identity.project_type, "AGENT")
        self.assertEqual(identity.to_headers()["Authorization"], "Bearer runtime_token")


if __name__ == "__main__":
    unittest.main()
