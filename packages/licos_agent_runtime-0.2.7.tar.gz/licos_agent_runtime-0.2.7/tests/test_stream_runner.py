import asyncio
import unittest

from licos_agent_runtime.context import new_context
from licos_agent_runtime.stream_runner import RunOpt, WorkflowStreamRunner


class WorkflowStreamRunnerTests(unittest.TestCase):
    def test_debug_stream_uses_langgraph_v2_events(self):
        class Graph:
            kwargs = None

            def astream_events(self, payload, **kwargs):
                self.kwargs = kwargs

                async def gen():
                    yield {"event": "on_chain_start", "data": payload}

                return gen()

        async def run():
            graph = Graph()
            runner = WorkflowStreamRunner()
            chunks = []
            async for chunk in runner.astream(
                {"input": "x"},
                graph,
                {"configurable": {"run_id": "r1"}},
                new_context("test"),
                RunOpt(workflow_debug=True),
            ):
                chunks.append(chunk)
            return graph.kwargs, chunks

        kwargs, chunks = asyncio.run(run())

        self.assertEqual(kwargs["version"], "v2")
        self.assertEqual(chunks[0][0], "on_chain_start")
        self.assertEqual(chunks[0][1]["data"], {"input": "x"})

    def test_stream_runner_does_not_swallow_internal_type_error(self):
        class Graph:
            async def astream(self, payload, config=None, context=None):
                del payload, config, context
                if False:
                    yield None
                raise TypeError("internal")

        async def run():
            runner = WorkflowStreamRunner()
            async for _ in runner.astream(
                {"input": "x"},
                Graph(),
                {"configurable": {"run_id": "r1"}},
                new_context("test"),
            ):
                pass

        with self.assertRaisesRegex(TypeError, "internal"):
            asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
