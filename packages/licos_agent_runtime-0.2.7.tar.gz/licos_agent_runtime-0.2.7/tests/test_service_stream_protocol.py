import asyncio
import json
import unittest
from unittest.mock import patch

from licos_agent_runtime.context import new_context
from licos_agent_runtime.service import GraphService
from licos_agent_runtime.stream_runner import RunOpt


def _event_data(raw_event):
    for line in raw_event.splitlines():
        if line.startswith("data:"):
            return json.loads(line[5:].strip())
    raise AssertionError(f"No data line in event: {raw_event}")


class ServiceStreamProtocolTests(unittest.TestCase):
    def test_stream_sse_outputs_platform_protocol_events(self):
        class Graph:
            async def astream(self, payload, config=None, context=None):
                del config, context
                yield {"assistant": {"output": f"echo:{payload['input']}"}}

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        payload = {
            "content": {"query": {"prompt": [{"type": "text", "content": {"text": "hello"}}]}},
            "type": "query",
            "session_id": "s1",
            "project_id": 1,
        }

        async def run():
            service = Service()
            ctx = new_context("stream_run")
            events = []
            async for item in service.stream_sse(
                payload,
                ctx=ctx,
                run_opt=RunOpt(platform_stream_protocol=True),
            ):
                events.append(_event_data(item))
            return events

        with patch("licos_agent_runtime.service.is_agent_project", return_value=True):
            events = asyncio.run(run())

        self.assertEqual(events[0]["type"], "message_start")
        self.assertEqual(events[1], {"type": "answer", "content": {"answer": "echo:hello"}})
        self.assertEqual(events[-1]["type"], "message_end")
        self.assertEqual(events[-1]["content"]["message_end"]["code"], "0")


if __name__ == "__main__":
    unittest.main()
