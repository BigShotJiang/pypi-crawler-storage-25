import asyncio
import json
import unittest
from unittest.mock import patch

from licos_agent_runtime.context import new_context
from licos_agent_runtime.service import GraphService
from licos_agent_runtime.stream_runner import RunOpt
from licos_agent_runtime.workflow_canvas import build_query_diff
from licos_agent_runtime.workflow_protocol import (
    workflow_end_event,
    workflow_error_event,
    workflow_node_end_event,
    workflow_node_start_event,
    workflow_ping_event,
    workflow_start_event,
)


def _event_data(raw_event):
    data = None
    event_id = None
    for line in raw_event.splitlines():
        if line.startswith("id:"):
            event_id = int(line[3:].strip())
        if line.startswith("data:"):
            data = json.loads(line[5:].strip())
    if data is None:
        raise AssertionError(f"No data line in event: {raw_event}")
    return event_id, data


class WorkflowProtocolTests(unittest.TestCase):
    def test_workflow_canvas_returns_coze_canvas_shape(self):
        def generate_answer(state):
            return {"answer": state.get("topic", "")}

        class Node:
            metadata = {
                "title": "生成结果",
                "description": "根据输入主题生成结果",
                "dependencies": {"integrations": [{"title": "Python"}]},
            }
            data = generate_answer

        class RawGraph:
            nodes = {"generate_answer": Node()}

        class Graph:
            def get_graph(self):
                return RawGraph()

            def get_input_schema(self):
                class Input:
                    @staticmethod
                    def model_json_schema():
                        return {"type": "object", "properties": {"topic": {"type": "string"}}}

                return Input

            def get_output_schema(self):
                class Output:
                    @staticmethod
                    def model_json_schema():
                        return {"type": "object", "properties": {"answer": {"type": "string"}}}

                return Output

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        with patch("licos_agent_runtime.service.is_agent_project", return_value=False):
            result = Service().agent_canvas()

        self.assertEqual(result["code"], 0)
        self.assertEqual(result["msg"], "")
        canvas = result["data"]
        self.assertEqual(canvas["canvas_data"], "")
        self.assertEqual(canvas["canvas_version"], "")
        self.assertFalse(canvas["data"].startswith("\n"))
        nodes = json.loads(canvas["data"])["nodes"]
        self.assertEqual([node["id"] for node in nodes], ["__start__", "generate_answer", "__end__"])
        self.assertNotIn("blocks", nodes[0])
        self.assertNotIn("blocks", nodes[1])
        self.assertEqual(nodes[0]["definition"]["outputs"]["properties"]["topic"]["type"], "string")
        self.assertEqual(nodes[1]["type"], "task")
        self.assertEqual(nodes[1]["definition"]["info"]["title"], "生成结果")
        self.assertEqual(
            nodes[1]["definition"]["info"]["dependencies"],
            {"integrations": [{"title": "Python"}]},
        )
        self.assertIn("#L", nodes[1]["script"]["content"])
        self.assertEqual(nodes[2]["definition"]["inputs"]["properties"]["answer"]["type"], "string")

    def test_run_node_executes_node_callable_directly(self):
        def generate_answer(state):
            return {"answer": state.get("topic", "")}

        class Node:
            metadata = {"title": "生成结果", "type": "action"}
            data = generate_answer

        class RawGraph:
            nodes = {"generate_answer": Node()}

        class Graph:
            def get_graph(self):
                return RawGraph()

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        result = asyncio.run(
            Service().run_node("generate_answer", {"topic": "单节点测试"}, new_context("test_node_run"))
        )

        self.assertEqual(result, {"answer": "单节点测试"})

    def test_run_node_passes_config_and_runtime_when_supported(self):
        runtime_marker = object()

        def generate_answer(state, config, runtime):
            return {
                "answer": state.get("topic", ""),
                "has_config": "configurable" in config,
                "has_runtime": runtime is runtime_marker,
            }

        class Node:
            metadata = {"title": "生成结果", "type": "action"}
            data = generate_answer

        class RawGraph:
            nodes = {"generate_answer": Node()}

        class Graph:
            def get_graph(self):
                return RawGraph()

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        with patch("licos_agent_runtime.service._runtime_for_context", return_value=runtime_marker):
            result = asyncio.run(
                Service().run_node("generate_answer", {"topic": "单节点测试"}, new_context("test_node_run"))
            )

        self.assertEqual(result["answer"], "单节点测试")
        self.assertTrue(result["has_config"])
        self.assertTrue(result["has_runtime"])

    def test_run_node_coerces_payload_to_node_input_schema(self):
        class Input:
            def __init__(self, topic):
                self.topic = topic

            @classmethod
            def model_validate(cls, payload):
                return cls(payload["topic"])

        class Output:
            def __init__(self, answer):
                self.answer = answer

            def model_dump(self):
                return {"answer": self.answer}

        def generate_answer(state):
            return Output(state.topic)

        generate_answer.input_schema = Input
        generate_answer.output_schema = Output

        class Node:
            metadata = {"title": "生成结果", "type": "action"}
            data = generate_answer

        class RawGraph:
            nodes = {"generate_answer": Node()}

        class Graph:
            def get_graph(self):
                return RawGraph()

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        result = asyncio.run(
            Service().run_node("generate_answer", {"topic": "单节点测试"}, new_context("test_node_run"))
        )

        self.assertEqual(result, {"answer": "单节点测试"})

    def test_canvas_submit_builds_query_diff_for_agent_execution(self):
        before = {
            "nodes": [
                {"id": "__start__", "type": "start", "definition": {"info": {"title": "开始"}}},
                {
                    "id": "generate_answer",
                    "type": "task",
                    "definition": {"info": {"title": "生成结果", "description": "旧描述"}},
                },
                {"id": "__end__", "type": "end", "definition": {"info": {"title": "结束"}}},
            ]
        }
        after = json.loads(json.dumps(before))
        after["nodes"][1]["definition"]["info"]["description"] = "新描述"

        diff = build_query_diff(before["nodes"], after["nodes"])

        self.assertEqual(diff["summary"], "修改，生成结果(generate_answer)")
        self.assertEqual(diff["stats"]["update_nodes"], 1)
        self.assertEqual(diff["stats"]["affected_node_ids"], ["generate_answer"])
        self.assertEqual(diff["updates"][0]["before"]["definition"]["info"]["description"], "旧描述")
        self.assertEqual(diff["updates"][0]["after"]["definition"]["info"]["description"], "新描述")
        self.assertEqual(diff["changes"][0]["kind"], "Update")
        self.assertEqual(diff["changes"][0]["node_id"], "generate_answer")
        self.assertEqual(diff["changes"][0]["location"], "top")
        self.assertEqual(diff["changes"][0]["node_description"], "新描述")

    def test_canvas_submit_response_matches_coze_query_shape(self):
        before = {
            "nodes": [
                {"id": "__start__", "type": "start", "definition": {"info": {"title": "开始"}}},
                {"id": "old_node", "type": "task", "definition": {"info": {"title": "旧节点"}}},
                {"id": "__end__", "type": "end", "definition": {"info": {"title": "结束"}}},
            ]
        }
        after = {
            "nodes": [
                {"id": "__start__", "type": "start", "definition": {"info": {"title": "开始"}}},
                {"id": "new_node", "type": "agent", "blocks": [], "definition": {"info": {"title": "新节点"}}},
                {"id": "__end__", "type": "end", "definition": {"info": {"title": "结束"}}},
            ]
        }

        class Service(GraphService):
            def agent_canvas(self):
                return {"code": 0, "msg": "", "data": {"data": json.dumps(before)}}

        result = Service().agent_canvas_submit({"after_canvas": json.dumps(after)})

        self.assertEqual(result["code"], 0)
        self.assertEqual(result["msg"], "")
        self.assertIn("当前流程结构", result["query"])
        self.assertIn("QueryDiff JSON", result["query"])
        self.assertIn("必须保留 after.type", result["query"])
        self.assertEqual(result["display_text"], "2 个节点变更")
        self.assertEqual(result["draft_text"], "2 个节点已编辑")
        self.assertEqual(result["reference"]["type"], "workflow_canvas_edit")
        self.assertEqual(result["reference"]["display_text"], "2 个节点变更")
        self.assertEqual(result["reference"]["query"], result["query"])
        self.assertEqual(result["reference"]["stats"]["add_nodes"], 1)
        self.assertIn("删除，旧节点(old_node)", result["query"])
        self.assertIn("新增，新节点(new_node)", result["query"])
        diff_text = result["query"].split("QueryDiff JSON:\n", 1)[1]
        diff = json.loads(diff_text)
        self.assertEqual(diff["stats"], {"affected_node_ids": ["new_node", "old_node"], "add_nodes": 1, "remove_nodes": 1})
        self.assertEqual(diff["changes"][0]["node_id"], "old_node")
        self.assertEqual(diff["changes"][0]["location"], "top")
        self.assertEqual(diff["changes"][0]["node_description"], "")
        self.assertNotIn("blocks", diff["adds"][0]["after"])
        self.assertEqual(diff["adds"][0]["after"]["script"], {})

    def test_canvas_submit_preserves_visual_node_definitions_in_query_diff(self):
        before = {
            "nodes": [
                {"id": "__start__", "type": "start", "definition": {"info": {"title": "开始"}}},
                {"id": "__end__", "type": "end", "definition": {"info": {"title": "结束"}}},
            ]
        }
        condition_node = {
            "id": "condition_node",
            "type": "condition",
            "blocks": [],
            "definition": {
                "info": {"title": "条件判断", "description": "按结果分支"},
                "conditions": [{"id": "ok", "expression": "result == 'ok'"}],
                "branches": [{"id": "ok", "target": "action_node"}, {"id": "default", "target": "__end__"}],
            },
        }
        action_node = {
            "id": "action_node",
            "type": "action",
            "blocks": [],
            "definition": {
                "info": {"title": "行为节点", "description": "执行动作"},
                "tool": {"name": "search_weather", "parameters": {"city": "成都"}},
            },
        }
        parallel_node = {
            "id": "parallel_node",
            "type": "parallel",
            "blocks": [],
            "definition": {
                "info": {"title": "并行节点", "description": "并行执行"},
                "branches": [{"id": "a", "target": "task_a"}, {"id": "b", "target": "task_b"}],
                "join": {"mode": "all"},
            },
        }
        after = {"nodes": [before["nodes"][0], condition_node, action_node, parallel_node, before["nodes"][1]]}

        diff = build_query_diff(before["nodes"], after["nodes"])

        added_nodes = {item["node"]["id"]: item["after"] for item in diff["adds"]}
        self.assertEqual(diff["stats"]["add_nodes"], 3)
        self.assertEqual(diff["stats"]["affected_node_ids"], ["action_node", "condition_node", "parallel_node"])
        self.assertEqual(added_nodes["condition_node"]["definition"]["conditions"], condition_node["definition"]["conditions"])
        self.assertEqual(added_nodes["action_node"]["definition"]["tool"], action_node["definition"]["tool"])
        self.assertEqual(added_nodes["parallel_node"]["definition"]["join"], parallel_node["definition"]["join"])
        self.assertNotIn("blocks", added_nodes["condition_node"])

    def test_workflow_canvas_preserves_action_condition_parallel_node_types(self):
        def action_node(state):
            return state

        def condition_node(state):
            return state

        def parallel_node(state):
            return state

        class Node:
            def __init__(self, node_type, func):
                self.metadata = {"title": node_type, "type": node_type}
                self.data = func

        class RawGraph:
            nodes = {
                "action_node": Node("action", action_node),
                "condition_node": Node("condition", condition_node),
                "parallel_node": Node("parallel", parallel_node),
            }

        class Graph:
            def get_graph(self):
                return RawGraph()

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        with patch("licos_agent_runtime.service.is_agent_project", return_value=False):
            result = Service().agent_canvas()

        nodes = {node["id"]: node for node in json.loads(result["data"]["data"])["nodes"]}
        self.assertEqual(nodes["action_node"]["type"], "action")
        self.assertEqual(nodes["condition_node"]["type"], "condition")
        self.assertEqual(nodes["parallel_node"]["type"], "parallel")

    def test_workflow_canvas_preserves_full_node_definition_for_visual_node_types(self):
        def action_node(state):
            return state

        def condition_node(state):
            return state

        def parallel_node(state):
            return state

        class Node:
            def __init__(self, metadata, func):
                self.metadata = metadata
                self.data = func

        action_definition = {
            "info": {"title": "调用工具", "description": "执行外部动作"},
            "inputs": {"type": "object", "properties": {"city": {"type": "string"}}},
            "outputs": {"type": "object", "properties": {"weather": {"type": "string"}}},
            "tool": {"name": "search_weather", "parameters": {"city": "{{city}}"}},
        }
        condition_definition = {
            "info": {"title": "条件判断", "description": "按天气分支"},
            "conditions": [{"id": "rainy", "expression": "weather == 'rain'"}],
            "branches": [{"id": "rainy", "target": "notify_rain"}, {"id": "default", "target": "notify_normal"}],
        }
        parallel_definition = {
            "info": {"title": "并行处理", "description": "同时执行多个动作"},
            "branches": [{"id": "branch_a", "target": "task_a"}, {"id": "branch_b", "target": "task_b"}],
            "join": {"mode": "all"},
        }

        class RawGraph:
            nodes = {
                "action_node": Node({"type": "action", "definition": action_definition}, action_node),
                "condition_node": Node({"type": "condition", "definition": condition_definition}, condition_node),
                "parallel_node": Node({"type": "parallel", "definition": parallel_definition}, parallel_node),
            }

        class Graph:
            def get_graph(self):
                return RawGraph()

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        with patch("licos_agent_runtime.service.is_agent_project", return_value=False):
            result = Service().agent_canvas()

        nodes = {node["id"]: node for node in json.loads(result["data"]["data"])["nodes"]}
        self.assertEqual(nodes["action_node"]["definition"]["tool"], action_definition["tool"])
        self.assertEqual(nodes["condition_node"]["definition"]["conditions"], condition_definition["conditions"])
        self.assertEqual(nodes["parallel_node"]["definition"]["branches"], parallel_definition["branches"])
        self.assertEqual(nodes["action_node"]["definition"]["info"]["title"], "调用工具")
        self.assertEqual(nodes["condition_node"]["script"]["mode"], "link")

    def test_workflow_event_shapes(self):
        self.assertEqual(workflow_start_event(run_id="r1", log_id="l1", timestamp=1)["type"], "workflow_start")
        self.assertEqual(
            workflow_node_start_event(
                run_id="r1",
                log_id="l1",
                node_name="search",
                input={"topic": "x"},
                timestamp=2,
            ),
            {
                "type": "node_start",
                "timestamp": 2,
                "run_id": "r1",
                "log_id": "l1",
                "node_name": "search",
                "input": {"topic": "x"},
            },
        )
        self.assertEqual(
            workflow_node_end_event(
                run_id="r1",
                log_id="l1",
                node_name="search",
                output={"items": []},
                time_cost_ms=3,
                timestamp=4,
            )["type"],
            "node_end",
        )
        self.assertEqual(
            workflow_end_event(
                run_id="r1",
                log_id="l1",
                output={"ok": True},
                time_cost_ms=5,
                timestamp=6,
            )["output"],
            {"ok": True},
        )
        self.assertEqual(workflow_error_event(run_id="r1", log_id="l1", code=201001, message="bad")["type"], "error")
        self.assertEqual(workflow_ping_event(run_id="r1", log_id="l1")["type"], "ping")

    def test_stream_sse_outputs_workflow_protocol_events(self):
        class Node:
            metadata = {"title": "网络搜索"}

        class RawGraph:
            nodes = {"search": Node()}

        class Graph:
            def get_graph(self):
                return RawGraph()

            async def astream(self, payload, **kwargs):
                del kwargs
                yield {"search": {"result": f"node-ok:{payload['topic']}"}}

            async def astream_events(self, payload, **kwargs):
                del kwargs
                yield {
                    "event": "on_chain_start",
                    "name": "search",
                    "run_id": "node-run",
                    "data": {"input": payload},
                }
                yield {
                    "event": "on_chain_end",
                    "name": "search",
                    "run_id": "node-run",
                    "data": {"output": {"result": "node-ok"}},
                }
                yield {
                    "event": "on_chain_end",
                    "name": "LangGraph",
                    "run_id": "graph-run",
                    "data": {"output": {"answer": "done"}},
                }

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        async def run():
            service = Service()
            ctx = new_context("stream_run")
            events = []
            async for item in service.stream_sse(
                {"topic": "AI"},
                ctx=ctx,
                run_opt=RunOpt(platform_stream_protocol=True, workflow_ping_interval_seconds=0),
            ):
                events.append(_event_data(item))
            return events

        with patch("licos_agent_runtime.service.is_agent_project", return_value=False):
            events = asyncio.run(run())

        ids = [event_id for event_id, _data in events]
        types = [data["type"] for _event_id, data in events]
        self.assertEqual(ids, [0, 1])
        self.assertEqual(types, ["workflow_start", "workflow_end"])
        self.assertEqual(events[-1][1]["output"], {"result": "node-ok:AI"})

    def test_debug_stream_sse_outputs_workflow_node_events(self):
        class Node:
            metadata = {"title": "网络搜索"}

        class RawGraph:
            nodes = {"search": Node()}

        class Graph:
            def get_graph(self):
                return RawGraph()

            async def astream_events(self, payload, **kwargs):
                del kwargs
                yield {
                    "event": "on_chain_start",
                    "name": "search",
                    "run_id": "node-run",
                    "data": {"input": payload},
                }
                yield {
                    "event": "on_chain_end",
                    "name": "search",
                    "run_id": "node-run",
                    "data": {"output": {"result": "node-ok"}},
                }
                yield {
                    "event": "on_chain_end",
                    "name": "LangGraph",
                    "run_id": "graph-run",
                    "data": {"output": {"answer": "done"}},
                }

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        async def run():
            service = Service()
            ctx = new_context("stream_run")
            events = []
            async for item in service.stream_sse(
                {"topic": "AI"},
                ctx=ctx,
                run_opt=RunOpt(
                    workflow_debug=True,
                    stream_mode="debug",
                    platform_stream_protocol=True,
                    workflow_ping_interval_seconds=0,
                ),
            ):
                events.append(_event_data(item))
            return events

        with patch("licos_agent_runtime.service.is_agent_project", return_value=False):
            events = asyncio.run(run())

        ids = [event_id for event_id, _data in events]
        types = [data["type"] for _event_id, data in events]
        self.assertEqual(ids, [0, 1, 2, 3])
        self.assertEqual(types, ["workflow_start", "node_start", "node_end", "workflow_end"])
        self.assertEqual(events[1][1]["node_name"], "网络搜索")
        self.assertEqual(events[-1][1]["output"], {"answer": "done"})

    def test_graph_parameter_includes_coze_compatible_status_fields_for_workflow(self):
        class Graph:
            def get_input_schema(self):
                class Input:
                    @staticmethod
                    def model_json_schema():
                        return {"type": "object", "properties": {"topic": {"type": "string"}}}

                return Input

            def get_output_schema(self):
                class Output:
                    @staticmethod
                    def model_json_schema():
                        return {"type": "object", "properties": {"answer": {"type": "string"}}}

                return Output

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        with patch("licos_agent_runtime.service.is_agent_project", return_value=False):
            result = Service().graph_inout_schema()

        self.assertEqual(result["code"], 0)
        self.assertEqual(result["msg"], "")
        self.assertEqual(result["input_schema"]["properties"]["topic"]["type"], "string")

    def test_run_returns_workflow_output_with_run_id(self):
        class Graph:
            async def ainvoke(self, payload, **kwargs):
                del kwargs
                return {"answer": f"done:{payload['topic']}"}

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        async def run():
            service = Service()
            ctx = new_context("run", {"X-Run-Id": "run-1"})
            return await service.run({"topic": "AI"}, ctx)

        with patch("licos_agent_runtime.service.is_agent_project", return_value=False):
            result = asyncio.run(run())

        self.assertEqual(result, {"answer": "done:AI", "run_id": "run-1"})


if __name__ == "__main__":
    unittest.main()
