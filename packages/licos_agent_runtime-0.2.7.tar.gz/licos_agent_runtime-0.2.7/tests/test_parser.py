import unittest

from licos_agent_runtime.parser import LangGraphParser


class InputSchema:
    @classmethod
    def model_json_schema(cls):
        return {"title": "InputSchema"}


class OutputSchema:
    @classmethod
    def model_json_schema(cls):
        return {"title": "OutputSchema"}


class ParserTests(unittest.TestCase):
    def test_nodes_metadata_includes_schema(self):
        def node_func(payload: InputSchema) -> OutputSchema:
            return OutputSchema()

        class Node:
            data = node_func
            metadata = {"description": "demo"}

        class RawGraph:
            nodes = {"node_a": Node()}

        parser = LangGraphParser(RawGraph())
        nodes = parser.get_nodes_metadata()

        self.assertEqual(nodes[0]["id"], "node_a")
        self.assertEqual(nodes[0]["metadata"], {"description": "demo"})
        self.assertEqual(nodes[0]["input_schema"], {"title": "InputSchema"})
        self.assertEqual(nodes[0]["output_schema"], {"title": "OutputSchema"})


if __name__ == "__main__":
    unittest.main()
