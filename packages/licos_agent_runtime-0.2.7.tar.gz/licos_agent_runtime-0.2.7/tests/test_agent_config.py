import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from licos_agent_runtime.agent_canvas import agent_canvas_response
from licos_agent_runtime.agent_config import read_agent_config
from licos_agent_runtime.service import GraphService


class AgentConfigTests(unittest.TestCase):
    def test_agent_canvas_matches_coze_shape(self):
        result = agent_canvas_response()
        canvas = result["data"]
        data = json.loads(canvas["data"])
        nodes = data["nodes"]

        self.assertEqual(result["code"], 0)
        self.assertEqual(result["msg"], "")
        self.assertEqual(canvas["canvas_data"], "")
        self.assertEqual(canvas["canvas_version"], "")
        self.assertEqual([node["id"] for node in nodes], ["__start__", "agent", "__end__"])
        self.assertEqual(nodes[1]["type"], "agent")
        self.assertEqual(nodes[1]["definition"]["info"]["title"], "agent节点")
        self.assertEqual(
            nodes[1]["definition"]["info"]["dependencies"]["llm_config"],
            ["config/agent_llm_config.json"],
        )

    def test_read_agent_config_normalizes_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config_dir = root / "config"
            config_dir.mkdir()
            (config_dir / "agent_llm_config.json").write_text(
                json.dumps(
                    {
                        "config": {"model": "auto", "temperature": 0.7},
                        "sp": "system prompt",
                        "up": "user prompt",
                        "tools": ["search_weather", "", "search_weather", "get_time"],
                    }
                ),
                encoding="utf-8",
            )

            result = read_agent_config(root)

        self.assertTrue(result["exists"])
        self.assertEqual(result["path"], "config/agent_llm_config.json")
        self.assertEqual(result["config"]["model"], "auto")
        self.assertEqual(result["sp"], "system prompt")
        self.assertEqual(result["up"], "user prompt")
        self.assertEqual(result["tools"], ["search_weather", "get_time"])

    def test_read_agent_config_missing_file_returns_empty_payload(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = read_agent_config(Path(tmp))

        self.assertFalse(result["exists"])
        self.assertEqual(result["config"], {})
        self.assertEqual(result["tools"], [])

    def test_agent_config_info_returns_config_without_graph(self):
        class Service(GraphService):
            def _get_graph(self, ctx=None):
                raise AssertionError("agent config endpoint must not load graph")

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config_dir = root / "config"
            config_dir.mkdir()
            (config_dir / "agent_llm_config.json").write_text(
                json.dumps({"config": {"model": "auto"}, "sp": "sp", "tools": ["tool_a"]}),
                encoding="utf-8",
            )
            with patch.dict("os.environ", {"LICOS_PROJECT_PATH": str(root)}):
                body = Service().agent_config_info()

        self.assertEqual(body["code"], 0)
        self.assertEqual(body["msg"], "")
        self.assertTrue(body["exists"])
        self.assertEqual(body["tools"], ["tool_a"])

    def test_graph_parameter_includes_agent_config_for_agent_project(self):
        class RawGraph:
            nodes = {}

        class Graph:
            def get_graph(self):
                return RawGraph()

        class Service(GraphService):
            def _get_graph(self, ctx=None):
                del ctx
                return Graph()

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config_dir = root / "config"
            config_dir.mkdir()
            (config_dir / "agent_llm_config.json").write_text(
                json.dumps({"config": {"model": "auto"}, "sp": "sp", "tools": ["tool_a"]}),
                encoding="utf-8",
            )
            with (
                patch.dict("os.environ", {"LICOS_PROJECT_PATH": str(root)}),
                patch("licos_agent_runtime.service.is_agent_project", return_value=True),
            ):
                result = Service().graph_inout_schema()

        self.assertEqual(result["code"], 0)
        self.assertEqual(result["agent_config"]["tools"], ["tool_a"])


if __name__ == "__main__":
    unittest.main()
