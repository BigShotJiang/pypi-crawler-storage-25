import os
import tempfile
import unittest
from collections import namedtuple
from pathlib import Path
from unittest.mock import patch

from licos_agent_runtime.context import new_context
from licos_agent_runtime.graph_loader import (
    _call_factory,
    _iter_nodes,
    get_graph_node_func_with_inout,
    is_agent_project,
    is_workflow_project,
    project_root,
)


class GraphLoaderTests(unittest.TestCase):
    def test_agent_project_type_env_wins(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict(os.environ, {"AGENT_PROJECT_TYPE": "AGENT"}, clear=True):
                self.assertTrue(is_agent_project(Path(tmp)))

    def test_workflow_project_type_env_wins(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            agent_file = root / "src" / "agents" / "agent.py"
            agent_file.parent.mkdir(parents=True)
            agent_file.write_text("agent = object()\n", encoding="utf-8")

            with patch.dict(os.environ, {"AGENT_PROJECT_TYPE": "WORKFLOW"}, clear=True):
                self.assertFalse(is_agent_project(root))
                self.assertTrue(is_workflow_project(root))

    def test_project_root_derives_from_workspace_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict(os.environ, {"LICOS_WORKSPACE_PATH": tmp}, clear=True):
                self.assertEqual(project_root(), (Path(tmp) / "projects").resolve())

    def test_licos_template_agent_is_agent_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".licos").write_text(
                '[project]\ntemplate = "agent"\n',
                encoding="utf-8",
            )

            with patch.dict(os.environ, {}, clear=True):
                self.assertTrue(is_agent_project(root))

    def test_licos_template_workflow_is_workflow_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".licos").write_text(
                '[project]\ntemplate = "workflow"\n',
                encoding="utf-8",
            )

            with patch.dict(os.environ, {}, clear=True):
                self.assertFalse(is_agent_project(root))
                self.assertTrue(is_workflow_project(root))

    def test_graph_module_marks_workflow_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            graph_file = root / "src" / "graphs" / "graph.py"
            graph_file.parent.mkdir(parents=True)
            graph_file.write_text("graph = object()\n", encoding="utf-8")

            with patch.dict(os.environ, {}, clear=True):
                self.assertFalse(is_agent_project(root))
                self.assertTrue(is_workflow_project(root))

    def test_licos_config_dir_template_agent_is_agent_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = root / ".licos" / "config.toml"
            config.parent.mkdir(parents=True)
            config.write_text('[project]\ntemplate = "agent"\n', encoding="utf-8")

            with patch.dict(os.environ, {}, clear=True):
                self.assertTrue(is_agent_project(root))

    def test_licos_template_is_found_from_project_parent(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp)
            project = workspace / "projects"
            project.mkdir()
            config = workspace / ".licos" / "config.toml"
            config.parent.mkdir()
            config.write_text('[project]\ntemplate = "agent"\n', encoding="utf-8")

            with patch.dict(os.environ, {}, clear=True):
                self.assertTrue(is_agent_project(project))

    def test_agents_module_marks_agent_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            agent_file = root / "src" / "agents" / "agent.py"
            agent_file.parent.mkdir(parents=True)
            agent_file.write_text("agent = object()\n", encoding="utf-8")

            with patch.dict(os.environ, {}, clear=True):
                self.assertTrue(is_agent_project(root))

    def test_get_graph_node_func_extracts_callable_and_schemas(self):
        class InputSchema:
            pass

        class OutputSchema:
            pass

        def node_func(payload: InputSchema) -> OutputSchema:
            return OutputSchema()

        class Node:
            data = node_func
            metadata = {"title": "Node"}

        class RawGraph:
            nodes = {"node_a": Node()}

        func, input_cls, output_cls = get_graph_node_func_with_inout(RawGraph(), "node_a")

        self.assertIs(func, node_func)
        self.assertIs(input_cls, InputSchema)
        self.assertIs(output_cls, OutputSchema)

    def test_get_graph_node_func_matches_callable_name(self):
        def real_node_name(payload):
            return payload

        class Node:
            data = real_node_name

        class RawGraph:
            nodes = {"generated_node_id": Node()}

        func, _input_cls, _output_cls = get_graph_node_func_with_inout(RawGraph(), "real_node_name")

        self.assertIs(func, real_node_name)

    def test_get_graph_node_func_extracts_namedtuple_node_data(self):
        GraphNode = namedtuple("GraphNode", ["id", "name", "data", "metadata"])

        def node_func(payload):
            return payload

        class RawGraph:
            nodes = {"node_a": GraphNode("node_a", "node_a", node_func, {})}

        func, _input_cls, _output_cls = get_graph_node_func_with_inout(RawGraph(), "node_a")

        self.assertIs(func, node_func)

    def test_get_graph_node_func_prefers_wrapped_callable_func(self):
        def node_func(payload):
            return payload

        class RunnableLike:
            func = node_func

            def __call__(self, payload):
                return self.func(payload)

        class Node:
            data = RunnableLike()

        class RawGraph:
            nodes = {"node_a": Node()}

        func, _input_cls, _output_cls = get_graph_node_func_with_inout(RawGraph(), "node_a")

        self.assertIs(func, node_func)

    def test_get_graph_node_func_resolves_future_annotations(self):
        namespace = {}
        exec(
            "from __future__ import annotations\n"
            "class Input: pass\n"
            "class Output: pass\n"
            "def node_func(state: Input) -> Output:\n"
            "    return Output()\n",
            namespace,
        )
        node_func = namespace["node_func"]
        input_cls = namespace["Input"]
        output_cls = namespace["Output"]

        class Node:
            data = node_func

        class RawGraph:
            nodes = {"node_a": Node()}

        func, resolved_input, resolved_output = get_graph_node_func_with_inout(RawGraph(), "node_a")

        self.assertIs(func, node_func)
        self.assertIs(resolved_input, input_cls)
        self.assertIs(resolved_output, output_cls)

    def test_call_factory_does_not_swallow_internal_type_error(self):
        def factory(_ctx):
            raise TypeError("internal")

        with self.assertRaisesRegex(TypeError, "internal"):
            _call_factory(factory, new_context("test"))

    def test_call_factory_supports_keyword_context(self):
        ctx = new_context("test")

        def factory(*, ctx):
            return ctx

        self.assertIs(_call_factory(factory, ctx), ctx)

    def test_iter_nodes_supports_tuple_iterables(self):
        nodes = [("node_a", object())]

        result = _iter_nodes(nodes)

        self.assertEqual(result[0][0], "node_a")


if __name__ == "__main__":
    unittest.main()
