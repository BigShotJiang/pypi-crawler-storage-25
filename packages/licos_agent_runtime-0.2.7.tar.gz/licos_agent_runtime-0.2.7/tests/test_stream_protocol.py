import unittest
from unittest.mock import patch

from licos_agent_runtime.context import new_context
from licos_agent_runtime.stream_protocol import (
    answer_event,
    chunk_to_events,
    error_event,
    extract_prompt_text,
    message_end_event,
    message_start_event,
    normalize_stream_request,
    tool_request_event,
    tool_response_event,
)


class StreamProtocolTests(unittest.TestCase):
    def test_extracts_prompt_array_text(self):
        payload = {
            "content": {
                "query": {
                    "prompt": [
                        {"type": "text", "content": {"text": "hello"}},
                        {"type": "text", "content": {"text": "world"}},
                    ]
                }
            },
            "type": "query",
            "session_id": "s1",
            "project_id": 1,
        }

        self.assertEqual(extract_prompt_text(payload), "hello\nworld")
        normalized = normalize_stream_request(payload)
        self.assertEqual(normalized["input"], "hello\nworld")
        self.assertEqual(normalized["text"], "hello\nworld")
        self.assertEqual(normalized["prompt"], "hello\nworld")
        self.assertEqual(normalized["messages"][0]["content"], "hello\nworld")

    def test_normalizes_upload_file_blocks_as_attachments(self):
        payload = {
            "content": {
                "query": {
                    "prompt": [
                        {"type": "text", "content": {"text": "describe this"}},
                        {
                            "type": "upload_file",
                            "content": {
                                "upload_file": {
                                    "file_name": "spec.png",
                                    "url": "https://files.example.test/spec.png?sign=1",
                                }
                            },
                        },
                    ]
                }
            },
            "type": "query",
            "session_id": "s1",
            "project_id": 1,
        }

        with patch(
            "licos_agent_runtime.stream_protocol.materialize_upload_file",
            return_value={
                "type": "upload_file",
                "file_name": "spec.png",
                "file_path": "assets/spec.png",
                "local_path": "/workspace/projects/assets/spec.png",
                "url": "https://files.example.test/spec.png?sign=1",
                "file_type": "image",
                "status": "saved",
                "size": 123,
            },
        ):
            normalized = normalize_stream_request(payload)

        self.assertEqual(normalized["attachments"], normalized["files"])
        self.assertEqual(normalized["attachments"][0]["file_path"], "assets/spec.png")
        self.assertIn("describe this", normalized["input"])
        self.assertIn("assets/spec.png", normalized["input"])
        message_content = normalized["messages"][0]["content"]
        self.assertIsInstance(message_content, list)
        self.assertEqual(message_content[0], {"type": "text", "text": "describe this"})
        self.assertEqual(message_content[2]["type"], "image_url")

    def test_stream_event_shapes(self):
        self.assertEqual(
            message_start_event("local-1", "msg-1"),
            {
                "type": "message_start",
                "content": {"message_start": {"local_msg_id": "local-1", "msg_id": "msg-1"}},
            },
        )
        self.assertEqual(answer_event("hi"), {"type": "answer", "content": {"answer": "hi"}})
        self.assertEqual(
            error_event("local-1", 105002, "bad"),
            {"type": "error", "content": {"error": {"local_msg_id": "local-1", "code": 105002, "error_msg": "bad"}}},
        )
        self.assertEqual(message_end_event()["content"]["message_end"]["code"], "0")

    def test_tool_event_shapes(self):
        request = tool_request_event(tool_call_id="call-1", tool_name="search", parameters={"q": "x"})
        response = tool_response_event(tool_call_id="call-1", tool_name="search", result={"ok": True})

        self.assertEqual(request["content"]["tool_request"]["tool_call_id"], "call-1")
        self.assertEqual(request["content"]["tool_request"]["parameters"], {"q": "x"})
        self.assertEqual(response["content"]["tool_response"]["result"], '{"ok": true}')

    def test_chunk_to_events_extracts_tool_call_chunks(self):
        class ToolCallChunk:
            id = "call-1"
            name = "search"
            args = '{"q":"x"}'
            index = 0

        class AIMessageChunk:
            content = ""
            tool_call_chunks = [ToolCallChunk()]

        events = chunk_to_events(AIMessageChunk())

        self.assertEqual(len(events), 1)
        request = events[0]["content"]["tool_request"]
        self.assertEqual(request["tool_call_id"], "call-1")
        self.assertEqual(request["tool_name"], "search")
        self.assertEqual(request["parameters"], {"q": "x"})
        self.assertEqual(request["stream_parameters"], '{"q":"x"}')

    def test_chunk_to_events_extracts_object_tool_calls(self):
        class ToolCall:
            id = "call-1"
            name = "search"
            args = {"q": "x"}

        class AIMessage:
            content = ""
            tool_calls = [ToolCall()]

        events = chunk_to_events(AIMessage())

        self.assertEqual(len(events), 1)
        request = events[0]["content"]["tool_request"]
        self.assertEqual(request["tool_call_id"], "call-1")
        self.assertEqual(request["parameters"], {"q": "x"})

    def test_chunk_to_events_does_not_emit_answer_for_tool_response_message(self):
        class ToolMessage:
            tool_call_id = "call-1"
            name = "search"
            content = "tool result"

        events = chunk_to_events(ToolMessage())

        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["type"], "tool_response")
        self.assertEqual(events[0]["content"]["tool_response"]["result"], "tool result")

    def test_chunk_to_events_extracts_answer_from_langgraph_node_update(self):
        events = chunk_to_events({"assistant": {"output": "hello"}})

        self.assertEqual(events, [{"type": "answer", "content": {"answer": "hello"}}])

    def test_context_import_kept_for_runtime(self):
        self.assertTrue(new_context("test").run_id)


if __name__ == "__main__":
    unittest.main()
