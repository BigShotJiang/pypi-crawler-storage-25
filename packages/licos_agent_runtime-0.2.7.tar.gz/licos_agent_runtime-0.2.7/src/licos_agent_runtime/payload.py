from __future__ import annotations

import json
from typing import Any


OPENAI_REQUEST_KEYS = {
    "frequency_penalty",
    "logit_bias",
    "logprobs",
    "max_completion_tokens",
    "max_tokens",
    "model",
    "n",
    "parallel_tool_calls",
    "presence_penalty",
    "response_format",
    "seed",
    "service_tier",
    "stop",
    "stream",
    "stream_options",
    "temperature",
    "tool_choice",
    "tools",
    "top_logprobs",
    "top_p",
    "user",
}


def _stringify_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                if isinstance(item.get("text"), str):
                    parts.append(item["text"])
                elif isinstance(item.get("content"), str):
                    parts.append(item["content"])
                elif item.get("type") == "image_url":
                    image_url = item.get("image_url")
                    if isinstance(image_url, dict) and isinstance(image_url.get("url"), str):
                        parts.append(image_url["url"])
                    elif isinstance(image_url, str):
                        parts.append(image_url)
                else:
                    parts.append(json.dumps(item, ensure_ascii=False, default=str))
            else:
                parts.append(str(item))
        return "\n".join(part for part in parts if part)
    return json.dumps(content, ensure_ascii=False, default=str)


def _message_role(message: Any) -> str:
    if isinstance(message, dict):
        value = message.get("role") or message.get("type") or "user"
        return str(value)
    value = getattr(message, "role", None) or getattr(message, "type", None) or "user"
    return str(value)


def _message_content(message: Any) -> str:
    if isinstance(message, dict):
        return _stringify_content(message.get("content"))
    return _stringify_content(getattr(message, "content", message))


def messages_to_text(messages: list[Any]) -> str:
    lines: list[str] = []
    for message in messages:
        content = _message_content(message)
        if not content:
            continue
        lines.append(f"{_message_role(message)}: {content}")
    return "\n".join(lines)


def last_user_message(messages: list[Any]) -> str:
    for message in reversed(messages):
        if _message_role(message).lower() == "user":
            return _message_content(message)
    if messages:
        return _message_content(messages[-1])
    return ""


def to_stream_input(payload: dict[str, Any]) -> dict[str, Any]:
    """Convert OpenAI-style chat payloads into a LangGraph-friendly input.

    The original payload fields are kept where useful so project code can still
    read `messages`, while OpenAI transport-only options are not forwarded as
    graph state.
    """

    if not isinstance(payload, dict):
        return {"input": payload}

    messages = payload.get("messages")
    if isinstance(messages, list):
        graph_input = {key: value for key, value in payload.items() if key not in OPENAI_REQUEST_KEYS}
        graph_input["messages"] = messages
        text = messages_to_text(messages)
        user_text = last_user_message(messages)
        graph_input.setdefault("input", user_text or text)
        graph_input.setdefault("text", user_text or text)
        graph_input.setdefault("prompt", user_text or text)
        return graph_input

    prompt = payload.get("prompt")
    if isinstance(prompt, str) and "input" not in payload and "text" not in payload:
        graph_input = {key: value for key, value in payload.items() if key not in OPENAI_REQUEST_KEYS}
        graph_input.setdefault("input", prompt)
        graph_input.setdefault("text", prompt)
        return graph_input

    content = payload.get("content")
    if isinstance(content, dict):
        query = content.get("query") or content.get("prompt") or content.get("text")
        if isinstance(query, str) and "input" not in payload and "text" not in payload:
            graph_input = dict(payload)
            graph_input.setdefault("input", query)
            graph_input.setdefault("text", query)
            return graph_input

    return dict(payload)
