from __future__ import annotations

import asyncio
from dataclasses import dataclass
import inspect
from typing import Any, AsyncIterable, Callable, Iterable

from .context import Context


@dataclass(slots=True)
class RunOpt:
    workflow_debug: bool = False
    stream_mode: str | None = None
    platform_stream_protocol: bool = False
    workflow_ping_interval_seconds: float = 30.0


def _call_with_fallback(method: Any, payload: dict[str, Any], kwargs_list: list[dict[str, Any]]) -> Any:
    selected = _select_supported_kwargs(method, kwargs_list)
    if selected is not None:
        return method(payload, **selected)

    last_error: TypeError | None = None
    for kwargs in kwargs_list:
        try:
            return method(payload, **kwargs)
        except TypeError as exc:
            last_error = exc
    if last_error is not None:
        raise last_error
    return method(payload)


def _select_supported_kwargs(method: Any, kwargs_list: list[dict[str, Any]]) -> dict[str, Any] | None:
    try:
        signature = inspect.signature(method)
    except (TypeError, ValueError):
        return None

    parameters = signature.parameters
    accepts_any_keyword = any(parameter.kind == inspect.Parameter.VAR_KEYWORD for parameter in parameters.values())
    if accepts_any_keyword:
        return kwargs_list[0] if kwargs_list else {}

    supported_names = {
        name
        for name, parameter in parameters.items()
        if parameter.kind in {inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY}
    }
    for kwargs in kwargs_list:
        selected = {key: value for key, value in kwargs.items() if key in supported_names}
        if selected:
            return selected
    return {}


class BaseStreamRunner:
    def stream(self, payload: dict[str, Any], graph: Any, run_config: dict[str, Any], ctx: Context) -> Iterable[Any]:
        if hasattr(graph, "stream"):
            stream = _call_with_fallback(
                graph.stream,
                payload,
                [
                    {"config": run_config, "context": ctx},
                    {"config": run_config},
                ],
            )
            yield from stream
            return
        if hasattr(graph, "invoke"):
            result = _call_with_fallback(
                graph.invoke,
                payload,
                [
                    {"config": run_config, "context": ctx},
                    {"config": run_config},
                ],
            )
        else:
            result = graph(payload)
        yield result

    async def astream(
        self,
        payload: dict[str, Any],
        graph: Any,
        run_config: dict[str, Any],
        ctx: Context,
        run_opt: RunOpt | None = None,
    ) -> AsyncIterable[Any]:
        if hasattr(graph, "astream"):
            kwargs_list = [{"config": run_config, "context": ctx}]
            if run_opt and run_opt.stream_mode:
                kwargs_list.insert(0, {"config": run_config, "context": ctx, "stream_mode": run_opt.stream_mode})
                kwargs_list.append({"config": run_config, "stream_mode": run_opt.stream_mode})
            kwargs_list.append({"config": run_config})
            stream = _call_with_fallback(graph.astream, payload, kwargs_list)
            async for chunk in stream:
                yield chunk
            return
        if hasattr(graph, "ainvoke"):
            result = _call_with_fallback(
                graph.ainvoke,
                payload,
                [
                    {"config": run_config, "context": ctx},
                    {"config": run_config},
                ],
            )
            yield await result
            return
        for chunk in self.stream(payload, graph, run_config, ctx):
            yield chunk


class AgentStreamRunner(BaseStreamRunner):
    pass


class WorkflowStreamRunner(BaseStreamRunner):
    async def astream(
        self,
        payload: dict[str, Any],
        graph: Any,
        run_config: dict[str, Any],
        ctx: Context,
        run_opt: RunOpt | None = None,
    ) -> AsyncIterable[Any]:
        if run_opt and run_opt.workflow_debug and hasattr(graph, "astream_events"):
            stream = _call_with_fallback(
                graph.astream_events,
                payload,
                [
                    {"config": run_config, "context": ctx, "version": "v2"},
                    {"config": run_config, "version": "v2"},
                    {"config": run_config, "context": ctx},
                    {"config": run_config},
                ],
            )
            async for event in stream:
                event_id = None
                if isinstance(event, dict):
                    event_id = event.get("event") or event.get("name") or event.get("run_id")
                yield (event_id, event)
            return
        async for chunk in super().astream(payload, graph, run_config, ctx, run_opt):
            yield chunk


async def agent_stream_handler(
    *,
    payload: dict[str, Any],
    ctx: Context,
    run_id: str,
    stream_sse_func: Callable[..., AsyncIterable[str]],
    sse_event_func: Callable[..., str],
    error_classifier: Any,
    register_task_func: Callable[[str, asyncio.Task], None],
    run_opt: RunOpt | None = None,
) -> AsyncIterable[str]:
    async for item in _registered_stream(
        payload=payload,
        ctx=ctx,
        run_id=run_id,
        stream_sse_func=stream_sse_func,
        sse_event_func=sse_event_func,
        error_classifier=error_classifier,
        register_task_func=register_task_func,
        run_opt=run_opt,
    ):
        yield item


async def workflow_stream_handler(
    *,
    payload: dict[str, Any],
    ctx: Context,
    run_id: str,
    stream_sse_func: Callable[..., AsyncIterable[str]],
    sse_event_func: Callable[..., str],
    error_classifier: Any,
    register_task_func: Callable[[str, asyncio.Task], None],
    run_opt: RunOpt | None = None,
) -> AsyncIterable[str]:
    async for item in _registered_stream(
        payload=payload,
        ctx=ctx,
        run_id=run_id,
        stream_sse_func=stream_sse_func,
        sse_event_func=sse_event_func,
        error_classifier=error_classifier,
        register_task_func=register_task_func,
        run_opt=run_opt,
    ):
        yield item


async def _registered_stream(
    *,
    payload: dict[str, Any],
    ctx: Context,
    run_id: str,
    stream_sse_func: Callable[..., AsyncIterable[str]],
    sse_event_func: Callable[..., str],
    error_classifier: Any,
    register_task_func: Callable[[str, asyncio.Task], None],
    run_opt: RunOpt | None = None,
) -> AsyncIterable[str]:
    queue: asyncio.Queue[str | None] = asyncio.Queue()

    async def produce() -> None:
        try:
            kwargs = {"ctx": ctx}
            if run_opt is not None:
                kwargs["run_opt"] = run_opt
            async for item in stream_sse_func(payload, **kwargs):
                await queue.put(item)
        except asyncio.CancelledError:
            await queue.put(sse_event_func({"status": "cancelled", "run_id": run_id}))
            raise
        except Exception as exc:
            await queue.put(sse_event_func(error_classifier.get_error_response(exc, {"run_id": run_id})))
        finally:
            await queue.put(None)

    task = asyncio.create_task(produce())
    register_task_func(run_id, task)

    while True:
        item = await queue.get()
        if item is None:
            break
        yield item

    if task.done():
        try:
            exception = task.exception()
        except asyncio.CancelledError:
            exception = None
        if exception is not None:
            raise exception
