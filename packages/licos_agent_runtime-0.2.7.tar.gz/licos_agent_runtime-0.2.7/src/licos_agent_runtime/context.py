from __future__ import annotations

import os
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any, Mapping
from uuid import uuid4


def _env(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    value = value.strip()
    return value or None


def _headers_to_dict(headers: Mapping[str, Any] | None) -> dict[str, str]:
    if headers is None:
        return {}
    return {str(key).lower(): str(value) for key, value in headers.items()}


@dataclass(slots=True)
class RuntimeIdentity:
    user_id: str | None = None
    workspace_id: str | None = None
    project_id: str | None = None
    project_type: str | None = None
    instance_id: str | None = None
    profile_id: str | None = None
    user_token: str | None = None
    runtime_token: str | None = None

    @classmethod
    def from_env(cls) -> "RuntimeIdentity":
        return cls(
            user_id=_env("AGENT_USER_ID") or _env("LICOS_USER_ID"),
            workspace_id=_env("AGENT_WORKSPACE_ID") or _env("LICOS_WORKSPACE_ID"),
            project_id=_env("AGENT_PROJECT_ID") or _env("LICOS_PROJECT_ID"),
            project_type=_env("AGENT_PROJECT_TYPE") or _env("LICOS_PROJECT_TYPE"),
            instance_id=_env("INSTANCE_ID") or _env("LICOS_INSTANCE_ID"),
            profile_id=_env("AGENT_PROFILE_ID") or _env("LICOS_AGENT_PROFILE_ID"),
            user_token=_env("LICOS_USER_TOKEN"),
            runtime_token=_env("LICOS_RUNTIME_TOKEN"),
        )

    def to_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.user_id:
            headers["X-User-Id"] = self.user_id
        if self.workspace_id:
            headers["X-Workspace-Id"] = self.workspace_id
        if self.project_id:
            headers["X-Project-Id"] = self.project_id
        token = self.runtime_token or self.user_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers


@dataclass(slots=True)
class Context:
    method: str
    run_id: str = field(default_factory=lambda: uuid4().hex)
    headers: dict[str, str] = field(default_factory=dict)
    identity: RuntimeIdentity = field(default_factory=RuntimeIdentity.from_env)
    metadata: dict[str, Any] = field(default_factory=dict)

    def header(self, name: str, default: str | None = None) -> str | None:
        return self.headers.get(name.lower(), default)

    def with_run_id(self, run_id: str | None) -> "Context":
        if run_id and run_id.strip():
            self.run_id = run_id.strip()
        return self


request_context: ContextVar[Context | None] = ContextVar(
    "licos_agent_request_context",
    default=None,
)


def new_context(
    method: str = "run",
    headers: Mapping[str, Any] | None = None,
    **metadata: Any,
) -> Context:
    ctx = Context(method=method, headers=_headers_to_dict(headers), metadata=dict(metadata))
    upstream_run_id = ctx.header("x-run-id")
    if upstream_run_id:
        ctx.run_id = upstream_run_id
    return ctx
