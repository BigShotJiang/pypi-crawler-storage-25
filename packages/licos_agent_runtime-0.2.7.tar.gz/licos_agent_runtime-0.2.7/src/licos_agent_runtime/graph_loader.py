from __future__ import annotations

import importlib
import inspect
import os
import sys
from pathlib import Path
from typing import Any, get_type_hints

from .context import Context


def project_root() -> Path:
    project_path = os.environ.get("LICOS_PROJECT_PATH")
    if project_path:
        return Path(project_path).resolve()

    workspace_path = os.environ.get("LICOS_WORKSPACE_PATH")
    if workspace_path:
        return (Path(workspace_path) / "projects").resolve()

    return Path(os.getcwd()).resolve()


def ensure_project_import_path(root: Path | None = None) -> None:
    root = root or project_root()
    for candidate in (root, root / "src"):
        value = str(candidate)
        if candidate.exists() and value not in sys.path:
            sys.path.insert(0, value)


def _read_project_template(root: Path) -> str | None:
    for current in (root, *root.parents):
        template = _read_project_template_at(current)
        if template:
            return template
    return None


def _read_project_template_at(root: Path) -> str | None:
    candidates = [root / ".licos", root / ".licos.toml", root / "licos.toml"]
    licos_dir = root / ".licos"
    if licos_dir.is_dir():
        candidates.extend([licos_dir / "config.toml", licos_dir / "project.toml"])

    for config in candidates:
        if not config.is_file():
            continue
        try:
            text = config.read_text(encoding="utf-8")
        except OSError:
            continue

        parsed = _read_toml_template(text)
        if parsed:
            return parsed

        for raw_line in text.splitlines():
            line = raw_line.strip()
            if line.startswith("template") and "=" in line:
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None


def _read_toml_template(text: str) -> str | None:
    try:
        import tomllib
    except ModuleNotFoundError:
        return None

    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        return None

    value = data.get("template")
    if isinstance(value, str):
        return value

    project = data.get("project")
    if isinstance(project, dict):
        value = project.get("template")
        if isinstance(value, str):
            return value
    return None


def is_dev_env() -> bool:
    value = os.environ.get("LICOS_PROJECT_ENV") or os.environ.get("AGENT_ENV") or ""
    return value.strip().upper() in {"DEV", "DEVELOPMENT", "LOCAL"}


def is_agent_project(root: Path | None = None) -> bool:
    project_type = (os.environ.get("AGENT_PROJECT_TYPE") or os.environ.get("LICOS_PROJECT_TYPE") or "").strip()
    normalized_type = project_type.upper()
    if normalized_type == "AGENT":
        return True
    if normalized_type == "WORKFLOW":
        return False

    root = root or project_root()
    template = (_read_project_template(root) or "").upper()
    if template == "AGENT":
        return True
    if template == "WORKFLOW":
        return False

    return (root / "src" / "agents" / "agent.py").is_file() or (root / "agents" / "agent.py").is_file()


def is_workflow_project(root: Path | None = None) -> bool:
    project_type = (os.environ.get("AGENT_PROJECT_TYPE") or os.environ.get("LICOS_PROJECT_TYPE") or "").strip()
    normalized_type = project_type.upper()
    if normalized_type == "WORKFLOW":
        return True
    if normalized_type == "AGENT":
        return False

    root = root or project_root()
    template = (_read_project_template(root) or "").upper()
    if template == "WORKFLOW":
        return True
    if template == "AGENT":
        return False

    return (root / "src" / "graphs" / "graph.py").is_file() or (root / "graphs" / "graph.py").is_file()


def _call_factory(factory: Any, ctx: Context | None) -> Any:
    if not callable(factory):
        return factory

    try:
        signature = inspect.signature(factory)
    except (TypeError, ValueError):
        try:
            return factory(ctx)
        except TypeError:
            return factory()

    accepts_positional = any(
        parameter.kind
        in {
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.VAR_POSITIONAL,
        }
        for parameter in signature.parameters.values()
    )
    if not accepts_positional:
        if "ctx" in signature.parameters:
            return factory(ctx=ctx)
        if "context" in signature.parameters:
            return factory(context=ctx)
        return factory()
    return factory(ctx)


def _compile_if_needed(value: Any) -> Any:
    compile_func = getattr(value, "compile", None)
    if callable(compile_func):
        return compile_func()
    return value


def _load_from_module(module_name: str, candidates: tuple[str, ...], ctx: Context | None = None) -> Any:
    ensure_project_import_path()
    module = importlib.import_module(module_name)
    for attr in candidates:
        if hasattr(module, attr):
            return _compile_if_needed(_call_factory(getattr(module, attr), ctx))
    raise AttributeError(f"Module '{module_name}' does not export any of: {', '.join(candidates)}")


def get_agent_instance(module_name: str = "agents.agent", ctx: Context | None = None) -> Any:
    return _load_from_module(
        module_name,
        ("create_agent", "build_agent", "get_agent", "agent", "graph", "app", "builder"),
        ctx,
    )


def get_graph_instance(module_name: str = "graphs.graph", ctx: Context | None = None) -> Any:
    return _load_from_module(
        module_name,
        ("create_graph", "get_graph", "graph", "app", "builder"),
        ctx,
    )


def _iter_nodes(nodes: Any) -> list[tuple[str | None, Any]]:
    if isinstance(nodes, dict):
        return [(str(key), value) for key, value in nodes.items()]
    if nodes is None:
        return []

    items = getattr(nodes, "items", None)
    if callable(items):
        try:
            return [(str(key), value) for key, value in items()]
        except TypeError:
            pass

    result: list[tuple[str | None, Any]] = []
    for item in nodes:
        if isinstance(item, tuple) and len(item) == 2:
            key, value = item
            result.append((str(key), value))
            continue
        node_id = getattr(item, "id", None) or getattr(item, "name", None)
        result.append((str(node_id) if node_id is not None else None, item))
    return result


def _node_data(node: Any) -> Any:
    for attr in ("data", "func", "runnable", "node", "callable"):
        try:
            value = inspect.getattr_static(node, attr)
            if isinstance(value, property) or type(value).__name__ == "_tuplegetter":
                value = getattr(node, attr, None)
        except AttributeError:
            value = getattr(node, attr, None)
        if value is not None:
            return value
    return node


def _resolve_callable(value: Any) -> Any | None:
    if value is None:
        return None
    for attr in ("func", "afunc", "bound", "runnable", "node", "callable"):
        nested = getattr(value, attr, None)
        if inspect.ismethod(nested) and getattr(nested, "__self__", None) is value:
            nested = nested.__func__
        if nested is not None and nested is not value:
            resolved = _resolve_callable(nested)
            if resolved is not None:
                return resolved
    if callable(value) or hasattr(value, "invoke") or hasattr(value, "ainvoke"):
        return value
    return None


def _schema_from_method(value: Any, method_name: str) -> Any | None:
    method = getattr(value, method_name, None)
    if not callable(method):
        return None
    try:
        return method()
    except TypeError:
        return None


def _schema_from_signature(value: Any, kind: str) -> Any | None:
    if not callable(value):
        return None
    try:
        signature = inspect.signature(value)
    except (TypeError, ValueError):
        return None
    try:
        type_hints = get_type_hints(value)
    except Exception:
        type_hints = {}

    if kind == "input":
        for parameter in signature.parameters.values():
            if parameter.name in {"self", "config", "context", "ctx", "runtime"}:
                continue
            annotation = type_hints.get(parameter.name, parameter.annotation)
            if annotation is not inspect.Signature.empty and not isinstance(annotation, str):
                return annotation
            return None
        return None

    annotation = type_hints.get("return", signature.return_annotation)
    if annotation is inspect.Signature.empty or isinstance(annotation, str):
        return None
    return annotation


def _schema_from(value: Any, kind: str) -> Any | None:
    if value is None:
        return None

    method_name = "get_input_schema" if kind == "input" else "get_output_schema"
    schema = _schema_from_method(value, method_name)
    if schema is not None:
        return schema

    attrs = (
        ("input_schema", "Input", "input_type", "input")
        if kind == "input"
        else ("output_schema", "Output", "output_type", "output")
    )
    for attr in attrs:
        schema = getattr(value, attr, None)
        if schema is not None:
            return schema

    return _schema_from_signature(value, kind)


def get_graph_node_func_with_inout(graph: Any, node_id: str) -> tuple[Any | None, Any | None, Any | None]:
    raw_graph = graph.get_graph() if hasattr(graph, "get_graph") else graph
    nodes = getattr(raw_graph, "nodes", None)
    node = None

    for current_id, item in _iter_nodes(nodes):
        if current_id == node_id or getattr(item, "id", None) == node_id or getattr(item, "name", None) == node_id:
            node = item
            break
        data = _node_data(item)
        func = _resolve_callable(data)
        if getattr(func, "__name__", None) == node_id:
            node = item
            break

    if node is None:
        return None, None, None

    data = _node_data(node)
    func = _resolve_callable(data)
    input_cls = _schema_from(node, "input") or _schema_from(func, "input") or _schema_from(data, "input")
    output_cls = _schema_from(node, "output") or _schema_from(func, "output") or _schema_from(data, "output")
    return func, input_cls, output_cls
