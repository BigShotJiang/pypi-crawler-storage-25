from __future__ import annotations

import json
from typing import Any

from .agent_config import AGENT_CONFIG_PATH


def agent_canvas_data() -> dict[str, Any]:
    nodes: list[dict[str, Any]] = [
        {
            "id": "__start__",
            "type": "start",
            "definition": {
                "info": {
                    "title": "开始",
                    "description": "",
                }
            },
            "script": {},
        },
        {
            "id": "agent",
            "type": "agent",
            "definition": {
                "info": {
                    "title": "agent节点",
                    "description": "",
                    "dependencies": {
                        "llm_config": [AGENT_CONFIG_PATH],
                    },
                }
            },
            "script": {},
        },
        {
            "id": "__end__",
            "type": "end",
            "definition": {
                "info": {
                    "title": "结束",
                    "description": "",
                }
            },
            "script": {},
        },
    ]
    return {
        "canvas_data": "",
        "canvas_version": "",
        "data": "\n" + json.dumps({"nodes": nodes}, ensure_ascii=False, indent=4),
    }


def agent_canvas_response() -> dict[str, Any]:
    return {
        "code": 0,
        "data": agent_canvas_data(),
        "msg": "",
    }
