"""LICOS agent runtime.

The top-level package intentionally avoids importing FastAPI/LangGraph-heavy
modules. Import ``create_app`` or ``GraphService`` explicitly when starting a
runtime process.
"""

from .context import Context, RuntimeIdentity, new_context, request_context
from .graph_loader import is_agent_project, is_workflow_project

__all__ = [
    "Context",
    "RuntimeIdentity",
    "is_agent_project",
    "is_workflow_project",
    "new_context",
    "request_context",
]
