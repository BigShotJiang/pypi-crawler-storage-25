from __future__ import annotations

import logging
import logging.handlers
import os
from pathlib import Path

DEFAULT_LOG_FILE = "/tmp/licos-agent-runtime/runtime.log"
DEFAULT_LOG_LEVEL = "INFO"


def setup_logging(
    *,
    log_file: str | None = None,
    max_bytes: int = 100 * 1024 * 1024,
    backup_count: int = 5,
    log_level: str | int | None = None,
    console_output: bool = True,
) -> None:
    level_value = log_level or os.environ.get("LICOS_AGENT_LOG_LEVEL") or DEFAULT_LOG_LEVEL
    level = level_value if isinstance(level_value, int) else getattr(logging, str(level_value).upper(), logging.INFO)

    handlers: list[logging.Handler] = []
    target_log_file = log_file or os.environ.get("LICOS_AGENT_LOG_FILE") or DEFAULT_LOG_FILE
    if target_log_file:
        path = Path(target_log_file)
        path.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(
            logging.handlers.RotatingFileHandler(
                path,
                maxBytes=max_bytes,
                backupCount=backup_count,
                encoding="utf-8",
            )
        )
    if console_output:
        handlers.append(logging.StreamHandler())

    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
        handlers=handlers,
        force=True,
    )
