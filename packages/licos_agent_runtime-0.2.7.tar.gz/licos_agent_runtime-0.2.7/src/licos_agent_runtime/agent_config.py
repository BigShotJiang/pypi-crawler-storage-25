from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .graph_loader import project_root

AGENT_CONFIG_RELATIVE_PATH = Path("config") / "agent_llm_config.json"
AGENT_CONFIG_PATH = AGENT_CONFIG_RELATIVE_PATH.as_posix()


def _empty_payload(*, exists: bool = False) -> dict[str, Any]:
    return {
        "path": AGENT_CONFIG_PATH,
        "exists": exists,
        "config": {},
        "sp": "",
        "up": "",
        "tools": [],
        "raw": {},
    }


def _text(value: Any) -> str:
    if value is None:
        return ""
    return value if isinstance(value, str) else str(value)


def _tools(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []

    result: list[str] = []
    seen: set[str] = set()
    for item in value:
        name = _text(item).strip()
        if not name or name in seen:
            continue
        result.append(name)
        seen.add(name)
    return result


def read_agent_config(root: Path | None = None) -> dict[str, Any]:
    """Read Coze-style agent config metadata without failing runtime APIs."""
    base = root or project_root()
    path = base / AGENT_CONFIG_RELATIVE_PATH
    if not path.is_file():
        return _empty_payload(exists=False)

    payload = _empty_payload(exists=True)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        payload["error"] = str(exc)
        return payload

    if not isinstance(raw, dict):
        payload["error"] = "agent config must be a JSON object"
        return payload

    config = raw.get("config")
    payload["raw"] = raw
    payload["config"] = config if isinstance(config, dict) else {}
    payload["sp"] = _text(raw.get("sp"))
    payload["up"] = _text(raw.get("up"))
    payload["tools"] = _tools(raw.get("tools"))
    return payload
