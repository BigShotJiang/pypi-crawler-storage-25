from __future__ import annotations

import asyncio
from contextlib import suppress
import inspect
import json
import logging
import os
import threading
import time
from typing import Any, AsyncIterable, Iterable

from . import telemetry
from .agent_canvas import agent_canvas_response
from .agent_config import read_agent_config
from .stream_protocol import (
    chunk_to_events,
    elapsed_ms,
    error_event,
    local_msg_id,
    message_end_event,
    message_start_event,
    msg_id,
    normalize_stream_request,
    now_ms,
    stream_error_code,
)
from .context import Context, new_context
from .errors import ErrorClassifier, extract_core_stack
from .graph_loader import (
    _iter_nodes,
    get_agent_instance,
    get_graph_instance,
    get_graph_node_func_with_inout,
    is_agent_project,
)
from .parser import LangGraphParser
from .parser import schema_to_json
from .run_config import init_agent_config, init_run_config
from .stream_runner import AgentStreamRunner, RunOpt, WorkflowStreamRunner
from .workflow_protocol import (
    DEFAULT_ERROR_CODE as WORKFLOW_DEFAULT_ERROR_CODE,
    workflow_end_event,
    workflow_error_event,
    workflow_log_id,
    workflow_node_end_event,
    workflow_node_start_event,
    workflow_ping_event,
    workflow_start_event,
)
from .workflow_canvas import canvas_submit_response, workflow_canvas_response

logger = logging.getLogger(__name__)


def _timeout_seconds() -> float:
    value = os.environ.get("LICOS_AGENT_RUN_TIMEOUT_SECONDS", "900")
    try:
        return float(value)
    except ValueError:
        return 900.0


async def _call_ainvoke(graph: Any, payload: dict[str, Any], run_config: dict[str, Any], ctx: Context) -> Any:
    kwargs = _select_supported_kwargs(
        graph.ainvoke,
        [
            {"config": run_config, "context": ctx},
            {"config": run_config},
        ],
    )
    return await graph.ainvoke(payload, **kwargs)


def _call_astream_events(graph: Any, payload: dict[str, Any], run_config: dict[str, Any], ctx: Context) -> Any:
    return graph.astream_events(
        payload,
        **_select_supported_kwargs(
            graph.astream_events,
            [
                {"config": run_config, "context": ctx, "version": "v2"},
                {"config": run_config, "version": "v2"},
                {"config": run_config, "context": ctx},
                {"config": run_config},
            ],
        ),
    )


def _select_supported_kwargs(method: Any, kwargs_list: list[dict[str, Any]]) -> dict[str, Any]:
    try:
        signature = inspect.signature(method)
    except (TypeError, ValueError):
        return kwargs_list[0] if kwargs_list else {}

    parameters = signature.parameters
    if any(parameter.kind == inspect.Parameter.VAR_KEYWORD for parameter in parameters.values()):
        return kwargs_list[0] if kwargs_list else {}

    supported_names = {
        name
        for name, parameter in parameters.items()
        if parameter.kind in {inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY}
    }
    for kwargs in kwargs_list:
        selected = {key: value for key, value in kwargs.items() if key in supported_names}
        if selected:
            return selected
    return {}


def _runtime_for_context(ctx: Context) -> Any:
    try:
        from langgraph.runtime import Runtime
    except Exception:
        return None
    return Runtime(context=ctx)


def _coerce_node_payload(payload: dict[str, Any], input_cls: Any | None) -> Any:
    if input_cls is None or input_cls is dict or input_cls is Any:
        return payload
    if not isinstance(payload, dict):
        return payload

    validate = getattr(input_cls, "model_validate", None)
    if callable(validate):
        return validate(payload)

    if inspect.isclass(input_cls):
        try:
            return input_cls(**payload)
        except Exception:
            return payload

    return payload


def _normalize_node_result(result: Any) -> Any:
    dump = getattr(result, "model_dump", None)
    if callable(dump):
        return dump()
    return result


async def _call_node_callable(func: Any, payload: Any, run_config: dict[str, Any], ctx: Context) -> Any:
    if hasattr(func, "ainvoke") and callable(func.ainvoke):
        kwargs = _select_supported_kwargs(
            func.ainvoke,
            [
                {"config": run_config, "context": ctx},
                {"config": run_config},
            ],
        )
        return _normalize_node_result(await func.ainvoke(payload, **kwargs))

    if hasattr(func, "invoke") and callable(func.invoke):
        kwargs = _select_supported_kwargs(
            func.invoke,
            [
                {"config": run_config, "context": ctx},
                {"config": run_config},
            ],
        )
        return _normalize_node_result(func.invoke(payload, **kwargs))

    if not callable(func):
        raise TypeError("node is not callable")

    runtime = _runtime_for_context(ctx)
    kwargs = _select_supported_kwargs(
        func,
        [
            {"config": run_config, "runtime": runtime, "context": ctx},
            {"config": run_config, "runtime": runtime},
            {"config": run_config, "context": ctx},
            {"config": run_config},
        ],
    )
    result = func(payload, **kwargs)
    if inspect.isawaitable(result):
        result = await result
    return _normalize_node_result(result)


class GraphService:
    def __init__(
        self,
        *,
        agent_module: str = "agents.agent",
        graph_module: str = "graphs.graph",
    ) -> None:
        self.agent_module = agent_module
        self.graph_module = graph_module
        self.running_tasks: dict[str, asyncio.Task] = {}
        self.error_classifier = ErrorClassifier()
        self._agent_stream_runner = AgentStreamRunner()
        self._workflow_stream_runner = WorkflowStreamRunner()
        self._graph: Any | None = None
        self._graph_lock = threading.Lock()

    def _get_graph(self, ctx: Context | None = None) -> Any:
        if is_agent_project():
            return get_agent_instance(self.agent_module, ctx)

        if self._graph is not None:
            return self._graph
        with self._graph_lock:
            if self._graph is None:
                self._graph = get_graph_instance(self.graph_module, ctx)
            return self._graph

    @staticmethod
    def _sse_event(data: Any, event_id: Any = None) -> str:
        id_line = f"id: {event_id}\n" if event_id is not None else ""
        return f"{id_line}event: message\ndata: {json.dumps(data, ensure_ascii=False, default=str)}\n\n"

    def _get_stream_runner(self) -> AgentStreamRunner | WorkflowStreamRunner:
        return self._agent_stream_runner if is_agent_project() else self._workflow_stream_runner

    def stream(
        self,
        payload: dict[str, Any],
        run_config: dict[str, Any],
        ctx: Context | None = None,
    ) -> Iterable[Any]:
        ctx = ctx or new_context("stream")
        graph = self._get_graph(ctx)
        stream_runner = self._get_stream_runner()
        yield from stream_runner.stream(payload, graph, run_config, ctx)

    async def run(self, payload: dict[str, Any], ctx: Context | None = None) -> dict[str, Any]:
        ctx = ctx or new_context("run")
        run_id = ctx.run_id
        logger.info("Starting run: run_id=%s", run_id)

        try:
            graph = self._get_graph(ctx)
            agent_project = is_agent_project()
            run_config = init_agent_config(graph, ctx) if agent_project else init_run_config(graph, ctx)
            result = await _call_ainvoke(graph, payload, run_config, ctx)
            if not agent_project:
                if result is None:
                    result = {}
                if isinstance(result, dict):
                    result.setdefault("run_id", run_id)
                    return result
                return {"run_id": run_id, "result": result}
            if result is None:
                result = {}
            if isinstance(result, dict):
                result.setdefault("run_id", run_id)
                return result
            return {"run_id": run_id, "result": result}
        except asyncio.CancelledError:
            logger.info("Run cancelled: run_id=%s", run_id)
            return {"status": "cancelled", "run_id": run_id, "message": "Execution was cancelled"}
        except Exception as exc:
            err = self.error_classifier.classify(exc, {"node_name": "run", "run_id": run_id})
            logger.error(
                "GraphService.run failed: [%s] %s\nTraceback:\n%s",
                err.code,
                err.message,
                extract_core_stack(),
            )
            raise
        finally:
            self.running_tasks.pop(run_id, None)
            telemetry.flush()

    async def run_with_timeout(self, payload: dict[str, Any], ctx: Context) -> dict[str, Any]:
        task = asyncio.create_task(self.run(payload, ctx))
        self.running_tasks[ctx.run_id] = task
        try:
            return await asyncio.wait_for(task, timeout=_timeout_seconds())
        except asyncio.TimeoutError:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
            return {
                "status": "timeout",
                "run_id": ctx.run_id,
                "message": f"Execution timeout: exceeded {_timeout_seconds():g} seconds",
            }

    async def stream_sse(
        self,
        payload: dict[str, Any],
        ctx: Context | None = None,
        run_opt: RunOpt | None = None,
    ) -> AsyncIterable[str]:
        ctx = ctx or new_context(method="stream_sse")
        run_opt = run_opt or RunOpt()
        run_id = ctx.run_id
        if run_opt.platform_stream_protocol:
            stream = (
                self._stream_sse_agent_platform(payload, ctx=ctx, run_opt=run_opt)
                if is_agent_project()
                else self._stream_sse_workflow_platform(payload, ctx=ctx, run_opt=run_opt)
            )
            async for item in stream:
                yield item
            return

        graph = self._get_graph(ctx)
        run_config = init_agent_config(graph, ctx) if is_agent_project() else init_run_config(graph, ctx)
        is_workflow = not is_agent_project()

        logger.info("Starting stream: run_id=%s is_workflow=%s", run_id, is_workflow)
        try:
            async for chunk in self.astream(payload, graph, run_config=run_config, ctx=ctx, run_opt=run_opt):
                if is_workflow and isinstance(chunk, tuple):
                    event_id, data = chunk
                    yield self._sse_event(data, event_id)
                else:
                    yield self._sse_event(chunk)
        finally:
            self.running_tasks.pop(run_id, None)
            telemetry.flush()

    async def _stream_sse_agent_platform(
        self,
        payload: dict[str, Any],
        ctx: Context,
        run_opt: RunOpt,
    ) -> AsyncIterable[str]:
        start_ms = now_ms()
        local_message_id = local_msg_id(payload, ctx)
        server_message_id = msg_id(payload, ctx)
        run_id = ctx.run_id

        yield self._sse_event(message_start_event(local_message_id, server_message_id))

        try:
            graph_payload = normalize_stream_request(payload)
            graph = self._get_graph(ctx)
            run_config = init_agent_config(graph, ctx) if is_agent_project() else init_run_config(graph, ctx)

            async for chunk in self.astream(graph_payload, graph, run_config=run_config, ctx=ctx, run_opt=run_opt):
                for event in chunk_to_events(chunk):
                    yield self._sse_event(event)

            yield self._sse_event(
                message_end_event(code="0", message="success", time_cost_ms=elapsed_ms(start_ms))
            )
        except asyncio.CancelledError:
            yield self._sse_event(
                message_end_event(code="1", message="cancelled", time_cost_ms=elapsed_ms(start_ms))
            )
        except Exception as exc:
            code = stream_error_code(exc)
            message = str(exc) or exc.__class__.__name__
            logger.error("Platform stream failed: run_id=%s code=%s message=%s", run_id, code, message, exc_info=True)
            yield self._sse_event(error_event(local_message_id, code, message))
            yield self._sse_event(
                message_end_event(code=str(code), message=message, time_cost_ms=elapsed_ms(start_ms))
            )
        finally:
            self.running_tasks.pop(run_id, None)
            telemetry.flush()

    async def _stream_sse_workflow_platform(
        self,
        payload: dict[str, Any],
        ctx: Context,
        run_opt: RunOpt,
    ) -> AsyncIterable[str]:
        run_id = ctx.run_id
        log_id = workflow_log_id()
        start_perf = time.perf_counter()
        event_index = 0

        yield self._sse_event(workflow_start_event(run_id=run_id, log_id=log_id), event_index)
        event_index += 1

        queue: asyncio.Queue[dict[str, Any] | BaseException | None] = asyncio.Queue()

        async def produce() -> None:
            try:
                async for event in self._workflow_platform_events(payload, ctx, run_opt, log_id, start_perf):
                    await queue.put(event)
            except BaseException as exc:
                await queue.put(exc)
            finally:
                await queue.put(None)

        producer = asyncio.create_task(produce())
        ping_interval = run_opt.workflow_ping_interval_seconds

        try:
            while True:
                try:
                    if ping_interval and ping_interval > 0:
                        item = await asyncio.wait_for(queue.get(), timeout=ping_interval)
                    else:
                        item = await queue.get()
                except asyncio.TimeoutError:
                    yield self._sse_event(workflow_ping_event(run_id=run_id, log_id=log_id), event_index)
                    event_index += 1
                    continue

                if item is None:
                    break
                if isinstance(item, BaseException):
                    if isinstance(item, asyncio.CancelledError):
                        raise item
                    code = stream_error_code(item) or WORKFLOW_DEFAULT_ERROR_CODE
                    message = str(item) or item.__class__.__name__
                    yield self._sse_event(
                        workflow_error_event(run_id=run_id, log_id=log_id, code=code, message=message),
                        event_index,
                    )
                    event_index += 1
                    break

                yield self._sse_event(item, event_index)
                event_index += 1
        except asyncio.CancelledError:
            producer.cancel()
            yield self._sse_event(
                workflow_error_event(run_id=run_id, log_id=log_id, code=1, message="cancelled"),
                event_index,
            )
        finally:
            with suppress(asyncio.CancelledError):
                await producer
            self.running_tasks.pop(run_id, None)
            telemetry.flush()

    async def _workflow_platform_events(
        self,
        payload: dict[str, Any],
        ctx: Context,
        run_opt: RunOpt,
        log_id: str,
        start_perf: float,
    ) -> AsyncIterable[dict[str, Any]]:
        graph = self._get_graph(ctx)
        run_config = init_run_config(graph, ctx)
        node_start_times: dict[str, float] = {}
        final_output: Any = {}

        if run_opt.workflow_debug and hasattr(graph, "astream_events"):
            async for event in _call_astream_events(graph, payload, run_config, ctx):
                if not isinstance(event, dict):
                    continue
                event_type = str(event.get("event") or "")
                name = str(event.get("name") or "")
                event_run_id = str(event.get("run_id") or name or ctx.run_id)
                data = event.get("data") if isinstance(event.get("data"), dict) else {}

                if event_type.endswith("_start") and not _is_workflow_root_event(event):
                    node_start_times[event_run_id] = time.perf_counter()
                    yield workflow_node_start_event(
                        run_id=ctx.run_id,
                        log_id=log_id,
                        node_name=self._workflow_node_name(graph, name),
                        input=data.get("input", {}),
                    )
                    continue

                if event_type.endswith("_end"):
                    output = data.get("output", {})
                    if _is_workflow_root_event(event) or event_run_id not in node_start_times:
                        if output:
                            final_output = output
                        continue
                    node_started = node_start_times.pop(event_run_id, time.perf_counter())
                    yield workflow_node_end_event(
                        run_id=ctx.run_id,
                        log_id=log_id,
                        node_name=self._workflow_node_name(graph, name),
                        output=output,
                        time_cost_ms=_elapsed_perf_ms(node_started),
                    )
                    if output:
                        final_output = output
                    continue

                if event_type.endswith("_error"):
                    error = data.get("error") or data.get("exception") or "workflow node failed"
                    yield workflow_error_event(
                        run_id=ctx.run_id,
                        log_id=log_id,
                        code=WORKFLOW_DEFAULT_ERROR_CODE,
                        message=str(error),
                    )

            yield workflow_end_event(
                run_id=ctx.run_id,
                log_id=log_id,
                output=final_output,
                time_cost_ms=_elapsed_perf_ms(start_perf),
            )
            return

        if hasattr(graph, "astream"):
            stream_opt = RunOpt(stream_mode=run_opt.stream_mode or "updates")
            async for update in self.astream(payload, graph, run_config=run_config, ctx=ctx, run_opt=stream_opt):
                final_output = self._workflow_update_output(graph, update)
            yield workflow_end_event(
                run_id=ctx.run_id,
                log_id=log_id,
                output=final_output,
                time_cost_ms=_elapsed_perf_ms(start_perf),
            )
            return

        result = await _call_ainvoke(graph, payload, run_config, ctx)
        yield workflow_end_event(
            run_id=ctx.run_id,
            log_id=log_id,
            output=result,
            time_cost_ms=_elapsed_perf_ms(start_perf),
        )

    def _workflow_update_output(self, graph: Any, update: Any) -> Any:
        if not isinstance(update, dict):
            return update

        node_ids = self._workflow_node_ids(graph)
        if node_ids and any(str(key) in node_ids for key in update):
            output: Any = {}
            for key, value in update.items():
                if str(key) in node_ids and value:
                    output = value
            return output
        return update

    def _workflow_node_ids(self, graph: Any) -> set[str]:
        raw_graph = graph.get_graph() if hasattr(graph, "get_graph") else graph
        nodes = getattr(raw_graph, "nodes", None)
        return {
            str(key)
            for key, _node in _iter_nodes(nodes)
            if key is not None and str(key) not in {"__start__", "__end__", "START", "END"}
        }

    def _workflow_node_name(self, graph: Any, node_id: str) -> str:
        parser = LangGraphParser(graph)
        metadata = parser.get_node_metadata(node_id) or {}
        for key in ("title", "name", "label"):
            value = metadata.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return node_id or "workflow_node"

    def cancel_run(self, run_id: str, ctx: Context | None = None) -> dict[str, Any]:
        del ctx
        logger.info("Attempting to cancel run_id=%s", run_id)
        task = self.running_tasks.get(run_id)
        if task is None:
            return {
                "status": "not_found",
                "run_id": run_id,
                "message": "No active task found with this run_id.",
            }
        if task.done():
            return {
                "status": "already_completed",
                "run_id": run_id,
                "message": "Task has already completed.",
            }
        task.cancel()
        return {
            "status": "success",
            "run_id": run_id,
            "message": "Cancellation signal sent.",
        }

    async def run_node(self, node_id: str, payload: dict[str, Any], ctx: Context | None = None) -> Any:
        ctx = ctx or new_context(method="node_run")
        graph = self._get_graph(ctx)
        raw_graph = graph.get_graph() if hasattr(graph, "get_graph") else graph
        node_func, input_cls, output_cls = get_graph_node_func_with_inout(raw_graph, node_id)
        if node_func is None:
            raise KeyError(f"node_id '{node_id}' not found")
        del output_cls
        node_payload = _coerce_node_payload(payload, input_cls)
        return await _call_node_callable(node_func, node_payload, init_run_config(graph, ctx), ctx)

    def graph_inout_schema(self) -> dict[str, Any]:
        graph = self._get_graph()
        builder = getattr(graph, "builder", None)
        input_cls = getattr(builder, "input_schema", None) if builder is not None else None
        output_cls = getattr(builder, "output_schema", None) if builder is not None else None
        if input_cls is None and hasattr(graph, "get_input_schema"):
            input_cls = graph.get_input_schema()
        if output_cls is None and hasattr(graph, "get_output_schema"):
            output_cls = graph.get_output_schema()

        result = {
            "input_schema": schema_to_json(input_cls),
            "output_schema": schema_to_json(output_cls),
            "code": 0,
            "msg": "",
        }
        if is_agent_project():
            parser = LangGraphParser(graph)
            result["nodes"] = parser.get_nodes_metadata()
            result["agent_config"] = read_agent_config()
        return result

    def agent_config_info(self) -> dict[str, Any]:
        return {
            "code": 0,
            "msg": "",
            **read_agent_config(),
        }

    def agent_canvas(self) -> dict[str, Any]:
        if is_agent_project():
            return agent_canvas_response()
        return workflow_canvas_response(self._get_graph())

    def agent_canvas_submit(self, payload: dict[str, Any]) -> dict[str, Any]:
        before = self.agent_canvas()["data"]["data"]
        after = payload.get("after_canvas")
        if after is None:
            raise ValueError("after_canvas is required")
        return canvas_submit_response(before, after)

    async def astream(
        self,
        payload: dict[str, Any],
        graph: Any,
        run_config: dict[str, Any],
        ctx: Context,
        run_opt: RunOpt | None = None,
    ) -> AsyncIterable[Any]:
        stream_runner = self._get_stream_runner()
        async for chunk in stream_runner.astream(payload, graph, run_config, ctx, run_opt):
            yield chunk


def _elapsed_perf_ms(start: float) -> int:
    return max(0, int((time.perf_counter() - start) * 1000))


def _is_workflow_root_event(event: dict[str, Any]) -> bool:
    name = str(event.get("name") or "").lower()
    if name.startswith("__"):
        return True
    if name in {"langgraph", "stategraph", "compiledstategraph", "graph", "__root__"}:
        return True
    metadata = event.get("metadata")
    if isinstance(metadata, dict):
        if metadata.get("langgraph_node") in {"__start__", "__end__"}:
            return True
        if metadata.get("langgraph_node") is None and name in {
            "langgraph",
            "graph",
            "stategraph",
        }:
            return True
    return False
