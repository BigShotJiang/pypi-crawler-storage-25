from __future__ import annotations

import json
import time
from typing import Any, AsyncIterable

from fastapi.responses import StreamingResponse

from .context import Context
from .payload import to_stream_input
from .service import GraphService


def _extract_text(result: Any) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result
    if isinstance(result, dict):
        for key in ("content", "text", "message", "output", "answer", "response"):
            value = result.get(key)
            if isinstance(value, str):
                return value
            if isinstance(value, list):
                text = "\n".join(_extract_text(item) for item in value)
                if text.strip():
                    return text
        return json.dumps(result, ensure_ascii=False, default=str)
    content = getattr(result, "content", None)
    if content is not None:
        return _extract_text(content)
    return str(result)


def _extract_sse_text(event: str) -> str:
    data_lines = []
    for line in event.splitlines():
        if line.startswith("data:"):
            data_lines.append(line[5:].strip())
    if not data_lines:
        return event
    raw = "\n".join(data_lines)
    try:
        return _extract_text(json.loads(raw))
    except json.JSONDecodeError:
        return raw


def _chat_response(payload: dict[str, Any], content: str, run_id: str) -> dict[str, Any]:
    model = str(payload.get("model") or "licos-agent-runtime")
    return {
        "id": f"chatcmpl-{run_id}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
    }


class OpenAIChatHandler:
    def __init__(self, service: GraphService) -> None:
        self.service = service

    async def handle(self, payload: dict[str, Any], ctx: Context) -> Any:
        if payload.get("stream") is True:
            return StreamingResponse(
                self._stream_openai(payload, ctx),
                media_type="text/event-stream",
            )

        result = await self.service.run(to_stream_input(payload), ctx)
        return _chat_response(payload, _extract_text(result), ctx.run_id)

    async def _stream_openai(self, payload: dict[str, Any], ctx: Context) -> AsyncIterable[str]:
        model = str(payload.get("model") or "licos-agent-runtime")
        async for item in self.service.stream_sse(to_stream_input(payload), ctx=ctx):
            content = _extract_sse_text(item)
            chunk = {
                "id": f"chatcmpl-{ctx.run_id}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {"content": content},
                        "finish_reason": None,
                    }
                ],
            }
            yield f"data: {json.dumps(chunk, ensure_ascii=False, default=str)}\n\n"
        yield "data: [DONE]\n\n"
