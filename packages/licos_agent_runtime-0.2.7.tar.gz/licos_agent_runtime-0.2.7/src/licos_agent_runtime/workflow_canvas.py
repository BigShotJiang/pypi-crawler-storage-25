from __future__ import annotations

import inspect
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from .graph_loader import get_graph_node_func_with_inout, project_root
from .parser import LangGraphParser, schema_to_json

START_IDS = {"__start__", "START", "start"}
END_IDS = {"__end__", "END", "end"}


def workflow_canvas_response(graph: Any) -> dict[str, Any]:
    return {
        "code": 0,
        "data": workflow_canvas_data(graph),
        "msg": "",
    }


def workflow_canvas_data(graph: Any) -> dict[str, Any]:
    nodes = workflow_canvas_nodes(graph)
    return {
        "canvas_data": "",
        "canvas_version": "",
        "data": json.dumps({"nodes": nodes}, ensure_ascii=False),
    }


def workflow_canvas_nodes(graph: Any) -> list[dict[str, Any]]:
    parser = LangGraphParser(graph)
    graph_input_schema, graph_output_schema = _graph_inout_schema(graph)
    nodes: list[dict[str, Any]] = [_start_node(graph_input_schema)]

    raw_graph = graph.get_graph() if hasattr(graph, "get_graph") else graph
    for item in parser.get_nodes_metadata():
        node_id = str(item.get("id") or item.get("name") or "").strip()
        if not node_id or node_id in START_IDS or node_id in END_IDS:
            continue
        metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
        _func, input_cls, output_cls = get_graph_node_func_with_inout(raw_graph, node_id)
        input_schema = item.get("input_schema") if isinstance(item.get("input_schema"), dict) else {}
        output_schema = item.get("output_schema") if isinstance(item.get("output_schema"), dict) else {}
        if not input_schema:
            input_schema = schema_to_json(input_cls)
        if not output_schema:
            output_schema = schema_to_json(output_cls)
        nodes.append(_workflow_node(node_id, metadata, input_schema, output_schema, _func))

    nodes.append(_end_node(graph_output_schema))
    return nodes


def canvas_submit_response(before_canvas: Any, after_canvas: Any) -> dict[str, Any]:
    before_nodes = _canvas_nodes(before_canvas)
    after_nodes = _canvas_nodes(after_canvas)
    diff = build_query_diff(before_nodes, after_nodes)
    query = build_query_text(before_nodes, diff)
    change_count = _diff_change_count(diff)
    display_text = f"{change_count} 个节点变更"
    return {
        "code": 0,
        "msg": "",
        "query": query,
        "display_text": display_text,
        "draft_text": f"{change_count} 个节点已编辑",
        "reference": {
            "type": "workflow_canvas_edit",
            "display_text": display_text,
            "query": query,
            "summary": diff.get("summary", ""),
            "stats": diff.get("stats", {}),
            "diff": diff,
        },
    }


def build_query_diff(before_nodes: list[dict[str, Any]], after_nodes: list[dict[str, Any]]) -> dict[str, Any]:
    before_nodes = [_normalize_canvas_node(node) for node in before_nodes]
    after_nodes = [_normalize_canvas_node(node) for node in after_nodes]
    before_by_id = {_node_id(node): node for node in before_nodes if _node_id(node)}
    after_by_id = {_node_id(node): node for node in after_nodes if _node_id(node)}
    before_order = [_node_id(node) for node in before_nodes if _node_id(node)]
    after_order = [_node_id(node) for node in after_nodes if _node_id(node)]

    adds: list[dict[str, Any]] = []
    removes: list[dict[str, Any]] = []
    updates: list[dict[str, Any]] = []
    changes: list[dict[str, Any]] = []

    for node_id in before_order:
        if node_id in after_by_id:
            continue
        change = _remove_change(before_by_id[node_id], before_order)
        removes.append(change)
        changes.append(_change_record("Remove", change))

    for node_id in after_order:
        if node_id in before_by_id:
            continue
        change = _add_change(after_by_id[node_id], after_order)
        adds.append(change)
        changes.append(_change_record("Add", change))

    for node_id in after_order:
        if node_id not in before_by_id:
            continue
        before = before_by_id[node_id]
        after = after_by_id[node_id]
        if _canonical_node(before) == _canonical_node(after):
            continue
        change = _update_change(before, after, after_order)
        updates.append(change)
        changes.append(_change_record("Update", change))

    summary_items = [item["summary"] for item in removes + adds + updates]
    affected = sorted({_node_id(change["node"]) for change in changes if _node_id(change["node"])})
    stats: dict[str, Any] = {}
    if adds:
        stats["add_nodes"] = len(adds)
    if removes:
        stats["remove_nodes"] = len(removes)
    if updates:
        stats["update_nodes"] = len(updates)
    stats["affected_node_ids"] = affected

    result: dict[str, Any] = {
        "version": 1,
        "summary": "\n".join(summary_items) if summary_items else "无节点变更",
        "stats": stats,
        "instructions": [_instruction(change) for change in changes],
    }
    if adds:
        result["adds"] = adds
    if removes:
        result["removes"] = removes
    if updates:
        result["updates"] = updates
    result["changes"] = changes
    return result


def build_query_text(before_nodes: list[dict[str, Any]], diff: dict[str, Any]) -> str:
    structure = "\n".join(
        f"{_node_type(node)} {_node_title(node)} ({_node_id(node)})" for node in before_nodes if _node_id(node)
    )
    diff_json = json.dumps(diff, ensure_ascii=False, indent=2)
    return (
        "你需要对当前流程做变更。\n\n"
        "当前流程结构：\n"
        f"{structure}\n\n"
        "下面给出一份 JSON 变更描述（QueryDiff）。\n\n"
        "阅读顺序：\n"
        "1) 先查看上方【当前流程结构】了解现有图的拓扑。\n"
        "2) 阅读 summary / instructions / stats，快速理解总体变更。\n"
        "3) 新增/删除节点：查看 adds/removes 中的 tree（带层级缩进）和 after/before（完整嵌套结构）了解节点详情，node 了解节点基本信息，container/prev_id/next_id 了解位置。\n"
        "4) 字段更新/约束/类型/顺序调整：查看 updates/reorders。\n\n"
        "硬性要求：每个节点都必须保留 after.type / node.type 中的画布节点类型，并同步写入 graph.py 的 add_node metadata.type 与 AGENTS.md 节点清单；"
        "例如 type=parallel 必须保持为 parallel，不能改写成 action。\n\n"
        "注意：prev_id/next_id 表示节点在流程中的前后顺序位置，不代表图的边连接关系。subtree 为辅助信息，以 tree 和 after/before 的层级结构为准。\n\n"
        "QueryDiff JSON:\n"
        f"{diff_json}"
    )


def _graph_inout_schema(graph: Any) -> tuple[dict[str, Any], dict[str, Any]]:
    builder = getattr(graph, "builder", None)
    input_cls = getattr(builder, "input_schema", None) if builder is not None else None
    output_cls = getattr(builder, "output_schema", None) if builder is not None else None
    if input_cls is None and hasattr(graph, "get_input_schema"):
        input_cls = graph.get_input_schema()
    if output_cls is None and hasattr(graph, "get_output_schema"):
        output_cls = graph.get_output_schema()
    return schema_to_json(input_cls), schema_to_json(output_cls)


def _start_node(output_schema: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": "__start__",
        "type": "start",
        "definition": {
            "info": {"title": "开始", "description": ""},
            "outputs": output_schema,
        },
        "script": {},
    }


def _end_node(input_schema: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": "__end__",
        "type": "end",
        "definition": {
            "info": {"title": "结束", "description": ""},
            "inputs": input_schema,
        },
        "script": {},
    }


def _workflow_node(
    node_id: str,
    metadata: dict[str, Any],
    input_schema: dict[str, Any],
    output_schema: dict[str, Any],
    func: Any,
) -> dict[str, Any]:
    raw_definition = metadata.get("definition")
    definition = deepcopy(raw_definition) if isinstance(raw_definition, dict) else {}

    raw_info = definition.get("info")
    info = deepcopy(raw_info) if isinstance(raw_info, dict) else {}
    info.setdefault("title", _metadata_text(metadata, "title") or _metadata_text(metadata, "name") or node_id)
    info.setdefault("description", _metadata_text(metadata, "description"))
    dependencies = _dependencies(metadata)
    if dependencies and "dependencies" not in info:
        info["dependencies"] = dependencies
    definition["info"] = info

    if input_schema and "inputs" not in definition:
        definition["inputs"] = input_schema
    if output_schema and "outputs" not in definition:
        definition["outputs"] = output_schema

    return {
        "id": node_id,
        "type": _workflow_node_type(metadata),
        "definition": definition,
        "script": _script(metadata, func),
    }


def _workflow_node_type(metadata: dict[str, Any]) -> str:
    raw = metadata.get("type") or metadata.get("node_type")
    if isinstance(raw, str) and raw.strip().lower() in {"task", "action", "agent", "condition", "parallel"}:
        return raw.strip().lower()
    dependencies = _dependencies(metadata)
    if dependencies.get("llm_config"):
        return "agent"
    return "task"


def _dependencies(metadata: dict[str, Any]) -> dict[str, Any]:
    raw = metadata.get("dependencies")
    if isinstance(raw, dict):
        return {key: value for key, value in raw.items() if value not in (None, "", [], {})}
    result: dict[str, Any] = {}
    llm_config = metadata.get("llm_config")
    if isinstance(llm_config, str) and llm_config.strip():
        result["llm_config"] = [llm_config.strip()]
    elif isinstance(llm_config, list):
        values = [str(item).strip() for item in llm_config if str(item).strip()]
        if values:
            result["llm_config"] = values
    integrations = metadata.get("integrations")
    if isinstance(integrations, list) and integrations:
        result["integrations"] = integrations
    return result


def _script(metadata: dict[str, Any], func: Any) -> dict[str, Any]:
    raw = metadata.get("script")
    if isinstance(raw, dict):
        return raw
    content = _script_content(func)
    return {"mode": "link", "content": content} if content else {}


def _script_content(func: Any) -> str:
    if func is None:
        return ""
    try:
        source = inspect.getsourcefile(func)
        _, line = inspect.getsourcelines(func)
    except (OSError, TypeError):
        return ""
    if not source:
        return ""
    path = Path(source).resolve()
    try:
        relative = path.relative_to(project_root())
        value = relative.as_posix()
    except ValueError:
        value = path.as_posix()
    return f"{value}#L{line}"


def _canvas_nodes(canvas: Any) -> list[dict[str, Any]]:
    if isinstance(canvas, str):
        canvas = json.loads(canvas)
    if isinstance(canvas, dict) and isinstance(canvas.get("data"), str):
        canvas = json.loads(canvas["data"])
    if isinstance(canvas, dict) and isinstance(canvas.get("nodes"), list):
        return [_normalize_canvas_node(node) for node in canvas["nodes"] if isinstance(node, dict)]
    return []


def _normalize_canvas_node(node: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(node)
    normalized.pop("blocks", None)
    normalized.setdefault("script", {})
    definition = normalized.get("definition")
    if isinstance(definition, dict):
        normalized["definition"] = definition
    else:
        normalized["definition"] = {"info": {"title": _node_id(normalized), "description": ""}}
    return normalized


def _node_id(node: dict[str, Any]) -> str:
    return str(node.get("id") or "").strip()


def _node_type(node: dict[str, Any]) -> str:
    return str(node.get("type") or "task").strip() or "task"


def _node_title(node: dict[str, Any]) -> str:
    info = node.get("definition", {}).get("info", {}) if isinstance(node.get("definition"), dict) else {}
    value = info.get("title") if isinstance(info, dict) else None
    return str(value or _node_id(node) or "未命名节点").strip()


def _node_description(node: dict[str, Any]) -> str:
    info = node.get("definition", {}).get("info", {}) if isinstance(node.get("definition"), dict) else {}
    value = info.get("description") if isinstance(info, dict) else None
    return str(value or "").strip()


def _node_summary(node: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": _node_id(node),
        "type": _node_type(node),
        "title": _node_title(node),
        "description": _node_description(node),
    }


def _tree(node: dict[str, Any]) -> str:
    return f"{_node_type(node)} {_node_title(node)} ({_node_id(node)})"


def _neighbors(node_id: str, order: list[str]) -> tuple[str | None, str | None]:
    try:
        index = order.index(node_id)
    except ValueError:
        return None, None
    prev_id = order[index - 1] if index > 0 else None
    next_id = order[index + 1] if index + 1 < len(order) else None
    return prev_id, next_id


def _base_change(node: dict[str, Any], order: list[str]) -> dict[str, Any]:
    node_id = _node_id(node)
    prev_id, next_id = _neighbors(node_id, order)
    summary = _node_summary(node)
    return {
        "path": f"node[{node_id}]",
        "node": summary,
        "container": "top",
        "prev_id": prev_id,
        "next_id": next_id,
        "tree": _tree(node),
        "subtree": [summary],
        "affected_node_ids": [node_id],
    }


def _change_record(kind: str, change: dict[str, Any]) -> dict[str, Any]:
    node = change["node"]
    record = {
        "kind": kind,
        "path": change["path"],
        "node_id": node["id"],
        "prev_id": change.get("prev_id"),
        "next_id": change.get("next_id"),
        "container": change.get("container"),
        "location": change.get("container"),
        "node_description": node.get("description", ""),
        "summary": change["summary"],
        "node": node,
        "subtree": change["subtree"],
        "tree": change["tree"],
        "affected_node_ids": change["affected_node_ids"],
    }
    if "before" in change:
        record["before"] = change["before"]
    if "after" in change:
        record["after"] = change["after"]
    return record


def _add_change(node: dict[str, Any], order: list[str]) -> dict[str, Any]:
    base = _base_change(node, order)
    return {
        "path": base["path"],
        "summary": f"新增，{_node_title(node)}({_node_id(node)})",
        "node": base["node"],
        "container": base["container"],
        "prev_id": base["prev_id"],
        "next_id": base["next_id"],
        "tree": base["tree"],
        "subtree": base["subtree"],
        "affected_node_ids": base["affected_node_ids"],
        "after": node,
    }


def _remove_change(node: dict[str, Any], order: list[str]) -> dict[str, Any]:
    base = _base_change(node, order)
    return {
        "path": base["path"],
        "summary": f"删除，{_node_title(node)}({_node_id(node)})",
        "node": base["node"],
        "container": base["container"],
        "prev_id": base["prev_id"],
        "next_id": base["next_id"],
        "tree": base["tree"],
        "subtree": base["subtree"],
        "affected_node_ids": base["affected_node_ids"],
        "before": node,
    }


def _update_change(before: dict[str, Any], after: dict[str, Any], order: list[str]) -> dict[str, Any]:
    base = _base_change(after, order)
    return {
        "path": base["path"],
        "summary": f"修改，{_node_title(after)}({_node_id(after)})",
        "node": base["node"],
        "container": base["container"],
        "prev_id": base["prev_id"],
        "next_id": base["next_id"],
        "tree": base["tree"],
        "subtree": base["subtree"],
        "affected_node_ids": base["affected_node_ids"],
        "before": before,
        "after": after,
    }


def _instruction(change: dict[str, Any]) -> str:
    node = change["node"]
    action = {"Add": "新增", "Remove": "删除", "Update": "修改"}.get(change.get("kind"), "修改")
    position = _position_text(change.get("prev_id"), change.get("next_id"))
    return f"{action}，{node['title']}({node['id']})，挂载到主流程{position}"


def _position_text(prev_id: Any, next_id: Any) -> str:
    if prev_id and next_id:
        return f"，插入到 {prev_id} 之后、{next_id} 之前（节点顺序）"
    if prev_id:
        return f"，插入到 {prev_id} 之后（节点顺序）"
    if next_id:
        return f"，插入到 {next_id} 之前（节点顺序）"
    return ""


def _canonical_node(node: dict[str, Any]) -> str:
    return json.dumps(node, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _metadata_text(metadata: dict[str, Any], key: str) -> str:
    value = metadata.get(key)
    return value.strip() if isinstance(value, str) else ""


def _diff_change_count(diff: dict[str, Any]) -> int:
    stats = diff.get("stats")
    if isinstance(stats, dict):
        affected = stats.get("affected_node_ids")
        if isinstance(affected, list):
            return len(affected)
    return len(diff.get("changes", [])) if isinstance(diff.get("changes"), list) else 0
