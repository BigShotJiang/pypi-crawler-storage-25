from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def flush() -> None:
    """Flush platform telemetry when available.

    This is intentionally a no-op until licos-platform-sdk exposes telemetry.
    The function mirrors the runtime flush hook so request handlers can
    keep the same lifecycle shape.
    """
    try:
        from licos_platform_sdk import telemetry  # type: ignore

        flush_func = getattr(telemetry, "flush", None)
        if callable(flush_func):
            flush_func()
    except Exception as exc:
        logger.debug("telemetry flush skipped: %s", exc)
