from __future__ import annotations

import time
import uuid
from typing import Any


DEFAULT_ERROR_CODE = 201001


def workflow_timestamp_ms() -> int:
    return int(time.time() * 1000)


def workflow_log_id(timestamp_ms: int | None = None) -> str:
    timestamp_ms = timestamp_ms if timestamp_ms is not None else workflow_timestamp_ms()
    prefix = time.strftime("%Y%m%d%H%M%S", time.localtime(timestamp_ms / 1000))
    return f"{prefix}{uuid.uuid4().hex[:16].upper()}"


def workflow_start_event(
    *,
    run_id: str,
    log_id: str,
    timestamp: int | None = None,
) -> dict[str, Any]:
    return {
        "type": "workflow_start",
        "timestamp": timestamp if timestamp is not None else workflow_timestamp_ms(),
        "run_id": run_id,
        "log_id": log_id,
    }


def workflow_end_event(
    *,
    run_id: str,
    log_id: str,
    output: Any,
    time_cost_ms: int,
    timestamp: int | None = None,
) -> dict[str, Any]:
    return {
        "type": "workflow_end",
        "timestamp": timestamp if timestamp is not None else workflow_timestamp_ms(),
        "run_id": run_id,
        "log_id": log_id,
        "output": _object_output(output),
        "time_cost_ms": time_cost_ms,
    }


def workflow_node_start_event(
    *,
    run_id: str,
    log_id: str,
    node_name: str,
    input: Any,
    timestamp: int | None = None,
) -> dict[str, Any]:
    return {
        "type": "node_start",
        "timestamp": timestamp if timestamp is not None else workflow_timestamp_ms(),
        "run_id": run_id,
        "log_id": log_id,
        "node_name": node_name,
        "input": _object_output(input),
    }


def workflow_node_end_event(
    *,
    run_id: str,
    log_id: str,
    node_name: str,
    output: Any,
    time_cost_ms: int,
    timestamp: int | None = None,
) -> dict[str, Any]:
    return {
        "type": "node_end",
        "timestamp": timestamp if timestamp is not None else workflow_timestamp_ms(),
        "run_id": run_id,
        "log_id": log_id,
        "node_name": node_name,
        "output": _object_output(output),
        "time_cost_ms": time_cost_ms,
    }


def workflow_error_event(
    *,
    run_id: str,
    log_id: str,
    code: int,
    message: str,
    timestamp: int | None = None,
) -> dict[str, Any]:
    del run_id, log_id
    return {
        "type": "error",
        "code": code,
        "message": message,
        "timestamp": timestamp if timestamp is not None else workflow_timestamp_ms(),
    }


def workflow_ping_event(
    *,
    run_id: str,
    log_id: str,
    timestamp: int | None = None,
) -> dict[str, Any]:
    del run_id, log_id
    return {
        "type": "ping",
        "timestamp": timestamp if timestamp is not None else workflow_timestamp_ms(),
    }


def _object_output(value: Any) -> Any:
    if value is None:
        return {}
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        dumped = model_dump()
        return dumped if isinstance(dumped, dict) else {"value": dumped}
    if isinstance(value, dict):
        return value
    return {"value": value}
