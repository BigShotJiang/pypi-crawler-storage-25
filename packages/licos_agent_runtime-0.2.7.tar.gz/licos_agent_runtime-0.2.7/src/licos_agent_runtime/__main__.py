from __future__ import annotations

import argparse
import asyncio
import json
import logging
from typing import Any

import uvicorn

from .context import new_context
from .graph_loader import is_dev_env
from .logging import setup_logging
from .service import GraphService


def parse_input(input_str: str) -> dict[str, Any]:
    if not input_str:
        return {"text": "你好"}
    try:
        value = json.loads(input_str)
    except json.JSONDecodeError:
        return {"text": input_str}
    return value if isinstance(value, dict) else {"input": value}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Start LICOS agent runtime")
    parser.add_argument("-m", "--mode", default="http", choices=["http", "flow", "node", "agent"])
    parser.add_argument("-n", "--node", default="", help="Node ID for node mode")
    parser.add_argument("-p", "--port", type=int, default=5000, help="HTTP server port")
    parser.add_argument("-i", "--input", default="", help="Input JSON string or plain text")
    parser.add_argument("--host", default="0.0.0.0", help="HTTP bind host")
    return parser.parse_args()


def start_http_server(host: str, port: int) -> None:
    logger = logging.getLogger(__name__)
    reload_enabled = is_dev_env()
    logger.info("Start LICOS agent runtime HTTP server: host=%s port=%s reload=%s", host, port, reload_enabled)
    uvicorn.run("licos_agent_runtime.app:app", host=host, port=port, reload=reload_enabled, workers=1)


def main() -> None:
    setup_logging()
    args = parse_args()
    service = GraphService()

    if args.mode == "http":
        start_http_server(args.host, args.port)
    elif args.mode == "flow":
        payload = parse_input(args.input)
        result = asyncio.run(service.run(payload))
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    elif args.mode == "node":
        if not args.node:
            raise SystemExit("--node is required in node mode")
        payload = parse_input(args.input)
        result = asyncio.run(service.run_node(args.node, payload))
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    elif args.mode == "agent":
        ctx = new_context(method="agent")
        payload = parse_input(args.input)
        for chunk in service.stream(payload, run_config={"configurable": {"session_id": ctx.run_id}}, ctx=ctx):
            print(chunk)


if __name__ == "__main__":
    main()
