from __future__ import annotations

from typing import Any

from .context import Context


def init_run_config(graph: Any, ctx: Context) -> dict[str, Any]:
    del graph
    return {
        "configurable": {
            "thread_id": ctx.run_id,
            "run_id": ctx.run_id,
        },
        "metadata": {
            "method": ctx.method,
            "user_id": ctx.identity.user_id,
            "workspace_id": ctx.identity.workspace_id,
            "project_id": ctx.identity.project_id,
            "project_type": ctx.identity.project_type,
        },
    }


def init_agent_config(graph: Any, ctx: Context) -> dict[str, Any]:
    config = init_run_config(graph, ctx)
    config["configurable"]["session_id"] = ctx.run_id
    return config
