from __future__ import annotations

import json
import time
from typing import Any, Iterable

from .attachments import content_parts_for_attachment, extract_upload_file, materialize_upload_file
from .context import Context
from .payload import to_stream_input


STREAM_EVENT_TYPES = {
    "message_start",
    "message_end",
    "answer",
    "error",
    "tool_request",
    "tool_response",
}

DEFAULT_ERROR_CODE = 105000
PARAM_ERROR_CODE = 105002
TIMEOUT_ERROR_CODE = 105001


def now_ms() -> int:
    return int(time.perf_counter() * 1000)


def elapsed_ms(start_ms: int) -> int:
    return max(0, now_ms() - start_ms)


def local_msg_id(payload: dict[str, Any], ctx: Context) -> str:
    value = payload.get("local_msg_id") or payload.get("local_message_id") or payload.get("client_msg_id")
    if value is None:
        value = ctx.run_id
    return str(value)


def msg_id(payload: dict[str, Any], ctx: Context) -> str:
    value = payload.get("msg_id") or payload.get("message_id") or ctx.run_id
    return str(value)


def normalize_stream_request(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {"input": payload}

    prompt_blocks = extract_prompt_blocks(payload)
    if prompt_blocks is None:
        return to_stream_input(payload)

    result = dict(payload)
    text_parts: list[str] = []
    content_parts: list[dict[str, Any]] = []
    attachments: list[dict[str, Any]] = []

    for item in prompt_blocks:
        text = _prompt_item_text(item)
        if text:
            text_parts.append(text)
            content_parts.append({"type": "text", "text": text})
            continue

        upload_file = extract_upload_file(item)
        if upload_file is None:
            continue
        attachment = materialize_upload_file(upload_file, len(attachments))
        attachments.append(attachment)
        content_parts.extend(content_parts_for_attachment(attachment))

    prompt_text = "\n".join(part for part in text_parts if part)
    attachment_manifest = _attachment_manifest_for_prompt(attachments)
    graph_text = "\n\n".join(part for part in (prompt_text, attachment_manifest) if part)

    message_content: Any = content_parts if attachments else graph_text
    result.setdefault("messages", [{"role": "user", "content": message_content}])
    result["input"] = graph_text
    result["text"] = graph_text
    result["prompt"] = graph_text
    if attachments:
        result["attachments"] = attachments
        result["files"] = attachments
    return result


def extract_prompt_text(payload: dict[str, Any]) -> str | None:
    prompt_blocks = extract_prompt_blocks(payload)
    if prompt_blocks is not None:
        parts = [_prompt_item_text(item) for item in prompt_blocks]
        return "\n".join(part for part in parts if part)

    content = payload.get("content")
    if not isinstance(content, dict):
        return None

    query = content.get("query")
    if isinstance(query, str):
        return query
    if not isinstance(query, dict):
        return None

    for key in ("text", "content"):
        value = query.get(key)
        if isinstance(value, str):
            return value
    return None


def extract_prompt_blocks(payload: dict[str, Any]) -> list[Any] | None:
    content = payload.get("content")
    if not isinstance(content, dict):
        return None

    query = content.get("query")
    if isinstance(query, str):
        return [query]
    if not isinstance(query, dict):
        return None

    prompt = query.get("prompt")
    if isinstance(prompt, str):
        return [prompt]
    if isinstance(prompt, list):
        return prompt
    if isinstance(prompt, dict):
        return [prompt]

    for key in ("text", "content"):
        value = query.get(key)
        if isinstance(value, str):
            return [value]
    return None


def _prompt_item_text(item: Any) -> str:
    if isinstance(item, str):
        return item
    if not isinstance(item, dict):
        return str(item)

    content = item.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        text = content.get("text") or content.get("content")
        if isinstance(text, str):
            return text
    text = item.get("text")
    if isinstance(text, str):
        return text
    return ""


def _attachment_manifest_for_prompt(attachments: list[dict[str, Any]]) -> str:
    if not attachments:
        return ""
    lines = ["附件:"]
    for attachment in attachments:
        file_name = attachment.get("file_name") or ""
        file_path = attachment.get("file_path") or ""
        url = attachment.get("url") or ""
        status = attachment.get("status") or ""
        line = f"- {file_name}"
        if file_path:
            line += f" 本地路径: {file_path}"
        if url:
            line += f" URL: {url}"
        if status and status != "saved":
            line += f" 状态: {status}"
        lines.append(line)
    return "\n".join(lines)


def message_start_event(local_message_id: str, server_message_id: str) -> dict[str, Any]:
    return {
        "type": "message_start",
        "content": {
            "message_start": {
                "local_msg_id": local_message_id,
                "msg_id": server_message_id,
            }
        },
    }


def answer_event(answer: str) -> dict[str, Any]:
    return {"type": "answer", "content": {"answer": answer}}


def message_end_event(
    *,
    code: str = "0",
    message: str = "success",
    time_cost_ms: int = 0,
    token_cost: dict[str, int] | None = None,
) -> dict[str, Any]:
    return {
        "type": "message_end",
        "content": {
            "message_end": {
                "code": code,
                "message": message,
                "token_cost": token_cost
                or {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                },
                "time_cost_ms": time_cost_ms,
            }
        },
    }


def error_event(local_message_id: str, code: int, error_msg: str) -> dict[str, Any]:
    return {
        "type": "error",
        "content": {
            "error": {
                "local_msg_id": local_message_id,
                "code": code,
                "error_msg": error_msg,
            }
        },
    }


def tool_request_event(
    *,
    tool_call_id: str,
    tool_name: str,
    parameters: Any,
    is_parallel: bool = False,
    index: int = 0,
    stream_parameters: str = "",
) -> dict[str, Any]:
    return {
        "type": "tool_request",
        "content": {
            "tool_request": {
                "tool_call_id": tool_call_id,
                "tool_name": tool_name,
                "parameters": parameters if isinstance(parameters, dict) else {"value": parameters},
                "is_parallel": is_parallel,
                "index": index,
                "stream_parameters": stream_parameters,
            }
        },
    }


def tool_response_event(
    *,
    tool_call_id: str,
    tool_name: str,
    result: Any,
    code: str = "0",
    message: str = "success",
    time_cost_ms: int = 0,
) -> dict[str, Any]:
    return {
        "type": "tool_response",
        "content": {
            "tool_response": {
                "tool_call_id": tool_call_id,
                "code": code,
                "message": message,
                "result": result if isinstance(result, str) else json.dumps(result, ensure_ascii=False, default=str),
                "time_cost_ms": time_cost_ms,
                "tool_name": tool_name,
            }
        },
    }


def stream_error_code(error: BaseException) -> int:
    name = error.__class__.__name__
    if name in {"TimeoutError", "asyncio.TimeoutError"}:
        return TIMEOUT_ERROR_CODE
    if isinstance(error, (KeyError, ValueError, TypeError)):
        return PARAM_ERROR_CODE
    return DEFAULT_ERROR_CODE


def chunk_to_events(chunk: Any) -> list[dict[str, Any]]:
    if _is_platform_stream_event(chunk):
        return [chunk]

    events: list[dict[str, Any]] = []
    events.extend(_tool_events_from_chunk(chunk))

    answer = extract_answer(chunk)
    if answer and not _is_tool_only_chunk(chunk):
        events.append(answer_event(answer))
    return events


def _is_platform_stream_event(value: Any) -> bool:
    return isinstance(value, dict) and value.get("type") in STREAM_EVENT_TYPES and isinstance(value.get("content"), dict)


def _tool_events_from_chunk(chunk: Any) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []

    if isinstance(chunk, dict):
        tool_request = chunk.get("tool_request")
        if isinstance(tool_request, dict):
            events.append(_tool_request_from_mapping(tool_request, 0, False))
        tool_response = chunk.get("tool_response")
        if isinstance(tool_response, dict):
            events.append(_tool_response_from_mapping(tool_response))

        tool_calls = chunk.get("tool_calls")
        if isinstance(tool_calls, list):
            events.extend(_tool_requests_from_calls(tool_calls))

        tool_call_chunks = chunk.get("tool_call_chunks")
        if isinstance(tool_call_chunks, list):
            events.extend(_tool_requests_from_calls(tool_call_chunks))

        messages = chunk.get("messages")
        if isinstance(messages, list):
            for message in messages:
                events.extend(_tool_events_from_message(message))
        for value in chunk.values():
            if isinstance(value, dict):
                events.extend(_tool_events_from_chunk(value))
        return events

    events.extend(_tool_events_from_message(chunk))
    return events


def _tool_events_from_message(message: Any) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    tool_calls = None
    tool_call_chunks = None
    if isinstance(message, dict):
        tool_calls = message.get("tool_calls")
        tool_call_chunks = message.get("tool_call_chunks")
        if message.get("tool_call_id") and not tool_calls:
            events.append(
                tool_response_event(
                    tool_call_id=str(message.get("tool_call_id")),
                    tool_name=str(message.get("name") or message.get("tool_name") or ""),
                    result=message.get("content") or message.get("result") or "",
                )
            )
    else:
        tool_calls = getattr(message, "tool_calls", None)
        tool_call_chunks = getattr(message, "tool_call_chunks", None)
        tool_call_id = getattr(message, "tool_call_id", None)
        if tool_call_id:
            events.append(
                tool_response_event(
                    tool_call_id=str(tool_call_id),
                    tool_name=str(getattr(message, "name", None) or getattr(message, "tool_name", None) or ""),
                    result=getattr(message, "content", "") or "",
                )
            )

    if isinstance(tool_calls, list):
        events.extend(_tool_requests_from_calls(tool_calls))
    if isinstance(tool_call_chunks, list):
        events.extend(_tool_requests_from_calls(tool_call_chunks))
    return events


def _tool_requests_from_calls(calls: list[Any]) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    is_parallel = len(calls) > 1
    for index, call in enumerate(calls):
        mapping = _object_to_mapping(call)
        if mapping:
            events.append(_tool_request_from_mapping(mapping, index, is_parallel))
    return events


def _object_to_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value

    mapping: dict[str, Any] = {}
    for name in (
        "tool_call_id",
        "id",
        "tool_name",
        "name",
        "parameters",
        "args",
        "arguments",
        "is_parallel",
        "index",
        "stream_parameters",
        "code",
        "message",
        "result",
        "content",
    ):
        if hasattr(value, name):
            mapping[name] = getattr(value, name)
    return mapping


def _tool_request_from_mapping(value: dict[str, Any], index: int, is_parallel: bool) -> dict[str, Any]:
    parameters = value.get("parameters")
    if parameters is None:
        parameters = value.get("args")
    if parameters is None:
        parameters = value.get("arguments")
    stream_parameters = value.get("stream_parameters")
    if stream_parameters is None and isinstance(parameters, str):
        stream_parameters = parameters
    return tool_request_event(
        tool_call_id=str(value.get("tool_call_id") or value.get("id") or ""),
        tool_name=str(value.get("tool_name") or value.get("name") or ""),
        parameters=_parameters_object(parameters),
        is_parallel=bool(value.get("is_parallel", is_parallel)),
        index=int(value.get("index", index) or 0),
        stream_parameters=str(stream_parameters or ""),
    )


def _tool_response_from_mapping(value: dict[str, Any]) -> dict[str, Any]:
    return tool_response_event(
        tool_call_id=str(value.get("tool_call_id") or value.get("id") or ""),
        tool_name=str(value.get("tool_name") or value.get("name") or ""),
        result=value.get("result") if "result" in value else value.get("content", ""),
        code=str(value.get("code") or "0"),
        message=str(value.get("message") or "success"),
        time_cost_ms=int(value.get("time_cost_ms") or 0),
    )


def _parameters_object(value: Any) -> dict[str, Any]:
    if value is None or value == "":
        return {}
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return {"value": value}
        if isinstance(parsed, dict):
            return parsed
        return {"value": parsed}
    return {"value": value}


def _is_tool_only_chunk(chunk: Any) -> bool:
    if isinstance(chunk, dict):
        if "messages" in chunk:
            return False
        return any(key in chunk for key in ("tool_request", "tool_response", "tool_call_id"))

    if getattr(chunk, "tool_call_id", None):
        return True

    content = getattr(chunk, "content", None)
    has_tool_request = bool(getattr(chunk, "tool_calls", None) or getattr(chunk, "tool_call_chunks", None))
    return has_tool_request and not content


def extract_answer(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value

    content = getattr(value, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(item) for item in content if item)

    if isinstance(value, dict):
        for key in ("answer", "content", "text", "output", "message", "response"):
            current = value.get(key)
            if isinstance(current, str):
                return current

        messages = value.get("messages")
        if isinstance(messages, list):
            answer = _last_assistant_message_text(messages)
            if answer:
                return answer

        for nested in _nested_values(value):
            answer = extract_answer(nested)
            if answer:
                return answer
    return ""


def _nested_values(value: dict[str, Any]) -> Iterable[Any]:
    for key, nested in value.items():
        if key in {"metadata", "config", "run_id"}:
            continue
        if isinstance(nested, (dict, list)) or hasattr(nested, "content"):
            yield nested


def _last_assistant_message_text(messages: list[Any]) -> str:
    for message in reversed(messages):
        role = ""
        if isinstance(message, dict):
            role = str(message.get("role") or message.get("type") or "").lower()
            content = message.get("content")
        else:
            role = str(getattr(message, "role", None) or getattr(message, "type", None) or "").lower()
            content = getattr(message, "content", None)

        if role in {"assistant", "ai"}:
            if isinstance(content, str):
                return content
            if content is not None:
                return json.dumps(content, ensure_ascii=False, default=str)
    return ""
