from __future__ import annotations

import traceback
from dataclasses import dataclass
from enum import Enum
from typing import Any


class ErrorCategory(str, Enum):
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    VALIDATION = "validation"
    RUNTIME = "runtime"
    INTERNAL = "internal"


@dataclass(slots=True)
class ClassifiedError:
    code: str
    message: str
    category: ErrorCategory


class ErrorClassifier:
    def classify(self, error: BaseException, context: dict[str, Any] | None = None) -> ClassifiedError:
        del context
        name = error.__class__.__name__
        if name == "CancelledError":
            return ClassifiedError("RUN_CANCELLED", str(error) or "Execution cancelled", ErrorCategory.CANCELLED)
        if name == "TimeoutError":
            return ClassifiedError("RUN_TIMEOUT", str(error) or "Execution timeout", ErrorCategory.TIMEOUT)
        if isinstance(error, (KeyError, ValueError, TypeError)):
            return ClassifiedError("PARAM_INVALID", str(error), ErrorCategory.VALIDATION)
        return ClassifiedError("RUNTIME_ERROR", str(error) or name, ErrorCategory.RUNTIME)

    def get_error_response(
        self,
        error: BaseException,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        classified = self.classify(error, context)
        return {
            "error_code": classified.code,
            "error_message": classified.message,
            "category": classified.category.value,
        }


def extract_core_stack() -> str:
    return "".join(traceback.format_exc())
