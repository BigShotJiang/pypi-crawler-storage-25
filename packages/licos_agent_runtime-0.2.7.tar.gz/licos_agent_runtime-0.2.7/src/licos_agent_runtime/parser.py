from __future__ import annotations

from typing import Any

from .graph_loader import _iter_nodes, _node_data, _schema_from


def schema_to_json(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    model_json_schema = getattr(value, "model_json_schema", None)
    if callable(model_json_schema):
        schema = model_json_schema()
        return schema if isinstance(schema, dict) else {}
    schema_attr = getattr(value, "schema", None)
    if callable(schema_attr):
        schema = schema_attr()
        return schema if isinstance(schema, dict) else {}
    if isinstance(schema_attr, dict):
        return schema_attr
    return {}


class LangGraphParser:
    def __init__(self, graph: Any) -> None:
        self.graph = graph

    def _raw_graph(self) -> Any:
        raw_graph = self.graph.get_graph() if hasattr(self.graph, "get_graph") else self.graph
        return raw_graph

    def _find_node(self, node_id: str) -> Any | None:
        raw_graph = self._raw_graph()
        nodes = getattr(raw_graph, "nodes", None)
        for current_id, item in _iter_nodes(nodes):
            if current_id == node_id or getattr(item, "id", None) == node_id or getattr(item, "name", None) == node_id:
                return item
        return None

    def get_node_metadata(self, node_id: str) -> dict[str, Any] | None:
        node = self._find_node(node_id)
        if node is None:
            return None
        metadata = getattr(node, "metadata", None)
        return metadata if isinstance(metadata, dict) else None

    def get_nodes_metadata(self) -> list[dict[str, Any]]:
        raw_graph = self._raw_graph()
        result: list[dict[str, Any]] = []
        for current_id, node in _iter_nodes(getattr(raw_graph, "nodes", None)):
            metadata = getattr(node, "metadata", None)
            data = _node_data(node)
            item: dict[str, Any] = {
                "id": current_id or getattr(node, "id", None) or getattr(node, "name", None),
                "name": getattr(node, "name", None) or current_id,
                "metadata": metadata if isinstance(metadata, dict) else {},
                "input_schema": schema_to_json(_schema_from(node, "input") or _schema_from(data, "input")),
                "output_schema": schema_to_json(_schema_from(node, "output") or _schema_from(data, "output")),
            }
            result.append(item)
        return result
