"""Redis stream / consumer-group metrics for application health checks (no HTTP layer)."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Optional

from redis import Redis

# Max pending entries scanned for max idle (PEL may be larger; metric is a lower bound on true max).
XPENDING_RANGE_MAX_SAMPLES = 512


def _coerce_str(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _coerce_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="replace")
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _stream_id_timestamp_ms(stream_id: Optional[str]) -> Optional[int]:
    """
    Parse millisecond timestamp from a Redis stream ID (``<ms>-<seq>``).

    Custom IDs that are not numeric-``-``* return None.
    """
    if not stream_id:
        return None
    sid = stream_id.strip()
    if not sid or "-" not in sid:
        return None
    head = sid.split("-", 1)[0]
    try:
        return int(head)
    except ValueError:
        return None


def _compute_max_lag_ms(
    redis_client: Redis,
    stream_key: str,
    last_delivered_id: Optional[str],
    lag: Optional[int],
) -> Optional[int]:
    """
    Approximate age (ms) of the oldest stream entry not yet delivered to the group.

    Uses ``XRANGE`` to read the first entry strictly after ``last-delivered-id`` and
    subtracts its ID timestamp from local wall clock. Requires default Redis ID shape
    (ms-sequence). Returns None if lag is 0, ID cannot be parsed, or lookup fails.
    """
    if lag is None or lag <= 0:
        return None
    if not last_delivered_id:
        return None
    try:
        min_exclusive = f"({last_delivered_id}"
        entries = redis_client.xrange(
            stream_key,
            min=min_exclusive,
            max="+",
            count=1,
        )
        if not entries:
            return None
        entry_id_raw = entries[0][0]
        entry_id = _coerce_str(entry_id_raw)
        entry_ms = _stream_id_timestamp_ms(entry_id)
        if entry_ms is None:
            return None
        now_ms = int(time.time() * 1000)
        return max(0, now_ms - entry_ms)
    except Exception:
        return None


@dataclass
class StreamCriticalRules:
    """
    Rules for treating stream state as critical (caller maps to HTTP 503, alerts, etc.).

    When ``enabled`` is False, evaluation always returns non-critical.
    """

    enabled: bool = False
    stall_lag_with_zero_consumers: bool = True
    min_group_lag: Optional[int] = None
    min_group_pending: Optional[int] = None
    min_this_consumer_pending: Optional[int] = None
    min_max_pending_idle_ms: Optional[int] = None
    min_max_lag_ms: Optional[int] = None


def get_stream_consumer_metrics(
    redis_client: Redis,
    stream_key: str,
    consumer_group: str,
    consumer_name: str,
) -> dict[str, Any]:
    """
    Best-effort metrics for a Redis stream and consumer group.

    Includes ``max_lag_ms`` (approximate age of the oldest entry not yet delivered to the
    group): first entry after ``last-delivered-id`` via ``XRANGE``, ID ms minus wall clock.
    Requires default stream ID format; None if lag is 0 or IDs are non-numeric.

    Safe with ``decode_responses=False`` (bytes fields from Redis).
    Does not raise; on failure returns partial dict (e.g. stream_exists False).
    """
    out: dict[str, Any] = {
        "stream_exists": False,
        "stream_length": None,
        "group_found": False,
        "group_lag": None,
        "group_pending": None,
        "group_consumer_count": None,
        "last_delivered_id": None,
        "this_consumer_pending": None,
        "max_pending_idle_ms": None,
        "pending_idle_sample_count": None,
        "max_lag_ms": None,
    }

    try:
        out["stream_length"] = int(redis_client.xlen(stream_key))
        out["stream_exists"] = True
    except Exception:
        return out

    try:
        groups = redis_client.xinfo_groups(stream_key)
    except Exception:
        return out

    for g in groups:
        gn = _coerce_str(g.get(b"name", g.get("name")))
        if gn != consumer_group:
            continue
        out["group_found"] = True
        out["group_lag"] = _coerce_int(g.get(b"lag", g.get("lag")))
        out["group_pending"] = _coerce_int(g.get(b"pending", g.get("pending")))
        out["group_consumer_count"] = _coerce_int(
            g.get(b"consumers", g.get("consumers"))
        )
        ldi = g.get(b"last-delivered-id", g.get("last-delivered-id"))
        out["last_delivered_id"] = _coerce_str(ldi)
        break

    if out["group_found"]:
        out["max_lag_ms"] = _compute_max_lag_ms(
            redis_client,
            stream_key,
            out["last_delivered_id"],
            out["group_lag"],
        )
        try:
            pending_entries = redis_client.xpending_range(
                name=stream_key,
                groupname=consumer_group,
                min="-",
                max="+",
                count=XPENDING_RANGE_MAX_SAMPLES,
            )
            if pending_entries:
                max_idle = 0
                for p in pending_entries:
                    raw_idle = p.get("time_since_delivered")
                    if raw_idle is None:
                        raw_idle = p.get(b"time_since_delivered")
                    idle = _coerce_int(raw_idle)
                    if idle is not None and idle > max_idle:
                        max_idle = idle
                out["max_pending_idle_ms"] = max_idle
                out["pending_idle_sample_count"] = len(pending_entries)
        except Exception:
            pass

    try:
        consumers = redis_client.xinfo_consumers(stream_key, consumer_group)
        for c in consumers:
            cn = _coerce_str(c.get(b"name", c.get("name")))
            if cn != consumer_name:
                continue
            out["this_consumer_pending"] = _coerce_int(
                c.get(b"pending", c.get("pending"))
            )
            break
    except Exception:
        pass

    return out


def stream_status_summary(metrics: dict[str, Any]) -> str:
    """Human-readable one-line status from :func:`get_stream_consumer_metrics` output."""
    if not metrics.get("stream_exists"):
        return "stream absent (no XADD / XGROUP yet)"
    if not metrics.get("group_found"):
        return "stream exists; consumer group not registered yet"
    lag = metrics.get("group_lag") or 0
    pending = metrics.get("group_pending") or 0
    gcc = metrics.get("group_consumer_count") or 0
    if lag > 0 and gcc == 0:
        return (
            f"attention: lag={lag} but group_consumer_count=0 "
            "(consumer may not be calling XREADGROUP on this Redis)"
        )
    if lag > 0:
        lag_age = metrics.get("max_lag_ms")
        if lag_age is not None:
            return (
                f"backlog: lag={lag} (entries not yet delivered to the group); "
                f"approx oldest undelivered age={lag_age}ms"
            )
        return f"backlog: lag={lag} (entries not yet delivered to the group)"
    if pending > 0:
        idle = metrics.get("max_pending_idle_ms")
        if idle is not None and idle > 0:
            return (
                f"in_flight: pending={pending} (read, not yet ACK'd); "
                f"max sampled pending idle={idle}ms"
            )
        return f"in_flight: pending={pending} (read, not yet ACK'd)"
    return "ok"


def evaluate_stream_critical(
    metrics: dict[str, Any],
    rules: StreamCriticalRules,
) -> tuple[bool, list[str]]:
    """
    Decide if stream state matches critical rules.

    Only applies when ``rules.enabled`` and stream + group exist.
    """
    if not rules.enabled:
        return False, []

    if not metrics.get("stream_exists") or not metrics.get("group_found"):
        return False, []

    reasons: list[str] = []
    lag = int(metrics.get("group_lag") or 0)
    pending = int(metrics.get("group_pending") or 0)
    gcc = int(metrics.get("group_consumer_count") or 0)
    tcp = metrics.get("this_consumer_pending")
    tcp_i = int(tcp) if tcp is not None else None
    max_idle = metrics.get("max_pending_idle_ms")
    max_idle_i = int(max_idle) if max_idle is not None else None
    max_lag = metrics.get("max_lag_ms")
    max_lag_i = int(max_lag) if max_lag is not None else None

    if rules.stall_lag_with_zero_consumers and lag > 0 and gcc == 0:
        reasons.append(
            "stream_stall: lag>0 with group_consumer_count=0 (no XREADGROUP?)"
        )

    if rules.min_group_lag is not None and lag >= rules.min_group_lag:
        reasons.append(
            f"group_lag_threshold: lag>={rules.min_group_lag} (current={lag})"
        )

    if rules.min_group_pending is not None and pending >= rules.min_group_pending:
        reasons.append(
            "group_pending_threshold: "
            f"pending>={rules.min_group_pending} (current={pending})"
        )

    if (
        rules.min_this_consumer_pending is not None
        and tcp_i is not None
        and tcp_i >= rules.min_this_consumer_pending
    ):
        reasons.append(
            "this_consumer_pending_threshold: "
            f">={rules.min_this_consumer_pending} (current={tcp_i})"
        )

    if (
        rules.min_max_pending_idle_ms is not None
        and max_idle_i is not None
        and max_idle_i >= rules.min_max_pending_idle_ms
    ):
        reasons.append(
            "max_pending_idle_threshold: "
            f"idle_ms>={rules.min_max_pending_idle_ms} (sample_max={max_idle_i})"
        )

    if (
        rules.min_max_lag_ms is not None
        and max_lag_i is not None
        and max_lag_i >= rules.min_max_lag_ms
    ):
        reasons.append(
            "max_lag_ms_threshold: "
            f"approx_oldest_undelivered_age_ms>={rules.min_max_lag_ms} (current={max_lag_i})"
        )

    return bool(reasons), reasons


def consumer_stream_health_payload(
    redis_client: Redis,
    *,
    stream_key: str,
    consumer_group: str,
    consumer_name: str,
    worker_name: str,
    rules: StreamCriticalRules,
) -> dict[str, Any]:
    """
    Build a JSON-friendly dict for merging into an application ``/health`` response.

    Services choose HTTP status codes; this function does not use FastAPI or HTTP.

    Args:
        redis_client: Redis client (``decode_responses=False`` recommended).
        stream_key: Stream key.
        consumer_group: Consumer group name.
        consumer_name: This instance's consumer name.
        worker_name: Logical worker / service label (e.g. app worker_name).
        rules: Critical evaluation rules (``enabled=False`` disables critical flags).
    """
    metrics = get_stream_consumer_metrics(
        redis_client, stream_key, consumer_group, consumer_name
    )
    status = stream_status_summary(metrics)
    critical, critical_reasons = evaluate_stream_critical(metrics, rules)

    out: dict[str, Any] = {
        "worker_name": worker_name,
        "status": status,
        "stream_key": stream_key,
        "consumer_group": consumer_group,
        "consumer_name": consumer_name,
        "stream_exists": metrics.get("stream_exists"),
        "stream_length": metrics.get("stream_length"),
        "group_found": metrics.get("group_found"),
        "group_lag": metrics.get("group_lag"),
        "group_pending": metrics.get("group_pending"),
        "group_consumer_count": metrics.get("group_consumer_count"),
        "last_delivered_id": metrics.get("last_delivered_id"),
        "this_consumer_pending": metrics.get("this_consumer_pending"),
        "max_pending_idle_ms": metrics.get("max_pending_idle_ms"),
        "pending_idle_sample_count": metrics.get("pending_idle_sample_count"),
        "max_lag_ms": metrics.get("max_lag_ms"),
        "critical": critical if rules.enabled else None,
        "critical_reasons": critical_reasons if critical_reasons else None,
    }
    return out
