import json
import threading
import time

import pytest
from modict import modict

from codex_agent import (
    Agent,
    AssistantStepEndEvent,
    AssistantTurnEndEvent,
    AssistantTurnStartEvent,
    ResponseContentDeltaEvent,
    ResponseDoneEvent,
    ToolCallStartEvent,
)
from codex_agent.message import AssistantMessage, MessageChunk


class SequencedAI:
    def __init__(self, messages):
        self.messages = list(messages)
        self.params = []

    def run(self, **params):
        self.params.append(params)
        return self.messages.pop(0)


def test_agent_call_emits_turn_events(monkeypatch):
    agent = Agent(session="new")
    seen = []

    agent.on(AssistantTurnStartEvent, lambda event: seen.append((event.type, event.prompt)))
    agent.on(AssistantTurnEndEvent, lambda event: seen.append((event.type, event.prompt, event.reason)))
    def respond():
        message = AssistantMessage(content="ok")
        agent.sessions_manager.append_message(message)
        return message

    monkeypatch.setattr(agent, "get_response", respond)

    turn = agent("hello")

    assert turn.status == "done"
    assert turn.result == "ok"
    assert turn.command == "turn"
    assert turn.completed is True
    assert turn.reason == "completed"
    assert any(event.type == "assistant_turn_start_event" for event in turn.events)
    assert any(event.type == "assistant_turn_end_event" for event in turn.events)
    assert seen == [
        ("assistant_turn_start_event", None),
        ("assistant_turn_end_event", None, "completed"),
    ]
    agent.stop()


def test_agent_start_turn_is_non_blocking_and_tracks_busy(monkeypatch):
    agent = Agent(session="new")
    monkeypatch.setattr(agent.mainloop_manager, "process", lambda resume=False: modict(type="turn_outcome", completed=True, reason="completed", result=True))

    future = agent.start_turn()

    assert future.command == "turn"
    assert future.id
    assert agent.busy is True
    turn = future.wait()
    assert turn.result is True
    assert turn.completed is True
    assert turn.reason == "completed"
    assert turn.command == "turn"
    assert agent.busy is False
    agent.stop()


def test_mainloop_invoke_tool_timeout_does_not_block_waiting_for_worker():
    agent = Agent(session="new", tool_call_timeout=0.01)
    release = threading.Event()

    class SlowTool:
        name = "slow"

        def __call__(self):
            release.wait(timeout=1)
            return "late"

    started_at = time.monotonic()
    with pytest.raises(TimeoutError, match="Tool 'slow' did not finish"):
        agent.mainloop_manager.invoke_tool(SlowTool(), [], {})

    assert time.monotonic() - started_at < 0.5
    release.set()


def test_agent_stream_yields_events_and_exposes_final_turn(monkeypatch):
    agent = Agent(session="new")

    def respond():
        message = AssistantMessage(name="assistant")
        chunk = MessageChunk(content="ok")
        message.add_chunk(chunk)
        agent.emit(ResponseContentDeltaEvent, delta="ok", content="ok", chunk=chunk, message=message)
        agent.sessions_manager.append_message(message)
        return message

    monkeypatch.setattr(agent, "get_response", respond)

    stream = agent.stream("hello")
    events = list(stream)
    turn = stream.turn

    assert turn.completed is True
    assert turn.reason == "completed"
    assert turn.result == "ok"
    event_types = [event.type for event in events]
    assert event_types[0] == "message_submitted_event"
    assert "assistant_turn_start_event" in event_types
    assert "assistant_step_start_event" in event_types
    assert "response_content_delta_event" in event_types
    assert "assistant_step_end_event" in event_types
    assert event_types[-1] == "assistant_turn_end_event"
    assert event_types.index("assistant_turn_start_event") < event_types.index("response_content_delta_event")
    assert event_types.index("response_content_delta_event") < event_types.index("assistant_turn_end_event")
    assert stream._closed is True
    assert "*" not in agent.events.handlers or stream._handler not in agent.events.handlers.get("*", [])


def test_agent_stream_turn_property_waits_for_final_turn(monkeypatch):
    agent = Agent(session="new")
    release = threading.Event()

    def process(resume=False):
        release.wait(timeout=1.0)
        return modict(type="turn_outcome", completed=True, reason="completed", result="done")

    monkeypatch.setattr(agent.mainloop_manager, "process", process)

    stream = agent.stream()
    results = []
    reader = threading.Thread(target=lambda: results.append(stream.turn), daemon=True)
    reader.start()

    time.sleep(0.05)
    assert results == []
    assert stream.future.turn.completed is False

    release.set()
    reader.join(timeout=1.0)
    list(stream)

    assert len(results) == 1
    assert results[0].completed is True
    assert results[0].result == "done"
    assert results[0] is stream.future.turn


def test_agent_flushes_response_done_before_tool_call_start():
    agent = Agent(session="new", auto_proceed=False)

    @agent.add_tool
    def echo(value):
        return value

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "echo",
        "arguments": json.dumps({"value": "ok"}),
    }]
    order = []
    agent.on(ResponseContentDeltaEvent, lambda event: order.append(("delta", event.delta)))
    agent.on(ResponseDoneEvent, lambda event: order.append(("done", None)))
    agent.on(ToolCallStartEvent, lambda event: order.append(("tool_start", event.tool_call.call_id)))

    def respond():
        agent.emit(ResponseContentDeltaEvent, delta="I will inspect first.")
        agent.emit(ResponseDoneEvent, message=message)
        return message

    agent.get_response = respond

    outcome = agent.mainloop_manager.process()

    assert outcome.completed is False
    assert outcome.reason == "requires_next_step"
    assert order == [
        ("delta", "I will inspect first."),
        ("done", None),
        ("tool_start", "call_1"),
    ]


def test_agentic_loop_continues_from_require_next_step_flag():
    agent = Agent(session="new")

    @agent.add_tool
    def echo(value):
        return value

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "echo",
        "arguments": '{"value": "ok"}',
    }]
    final = AssistantMessage(content="done")
    agent.ai = SequencedAI([tool_call, final])
    seen = []
    agent.on(
        AssistantStepEndEvent,
        lambda event: seen.append((event.called_tools, event.require_next_step, event.stop_agentic_loop)),
    )

    outcome = agent.mainloop_manager.process()

    assert outcome.completed is True
    assert outcome.reason == "completed"
    assert len(agent.ai.params) == 2
    assert seen == [(True, True, False), (False, False, False)]


def test_agent_turn_suspends_when_auto_proceed_is_false_and_resume_turn_continues():
    agent = Agent(session="new", auto_proceed=False)

    @agent.add_tool
    def echo(value):
        return value

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "echo",
        "arguments": '{"value": "ok"}',
    }]
    final = AssistantMessage(content="done")
    agent.ai = SequencedAI([tool_call, final])
    seen = []
    agent.on(AssistantTurnEndEvent, lambda event: seen.append(event.reason))

    turn = agent("start")

    assert turn.completed is False
    assert turn.reason == "requires_next_step"
    assert turn.result is None
    assert seen == []
    assert len(agent.ai.params) == 1

    resumed = agent.resume_turn(turn)

    assert resumed is turn
    assert turn.completed is True
    assert turn.reason == "completed"
    assert turn.result == "done"
    assert seen == ["completed"]
    assert len(agent.ai.params) == 2


def test_agentic_loop_stop_flag_exits_after_current_step():
    agent = Agent(session="new")

    @agent.add_tool
    def stop_now():
        agent.mainloop_manager.stop_loop_after_current_step()
        return "stopped"

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "stop_now",
        "arguments": "{}",
    }]
    final = AssistantMessage(content="should not run")
    agent.ai = SequencedAI([tool_call, final])

    outcome = agent.mainloop_manager.process()

    assert outcome.completed is True
    assert outcome.reason == "completed"
    assert len(agent.ai.params) == 1
    assert agent.mainloop_manager.stop_agentic_loop is True
    assert any(message.content == "stopped" for message in agent.session.messages)


def test_agent_turn_result_falls_back_to_last_assistant_message_content(monkeypatch):
    agent = Agent(session="new")
    def respond():
        message = AssistantMessage(content="final answer")
        agent.sessions_manager.append_message(message)
        return message

    monkeypatch.setattr(agent, "get_response", respond)

    turn = agent("hello")

    assert turn.result == "final answer"
    assert turn.messages[-1].content == "final answer"


def test_agent_set_turn_result_exits_after_current_step_and_sets_result():
    agent = Agent(session="new")

    @agent.add_tool
    def finish():
        agent.set_turn_result({"answer": 42})
        return "reported"

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "finish",
        "arguments": "{}",
    }]
    final = AssistantMessage(content="should not run")
    agent.ai = SequencedAI([tool_call, final])

    turn = agent("run finish")

    assert turn.result == {"answer": 42}
    assert turn.status == "done"
    assert turn.completed is True
    assert turn.reason == "result_set"
    assert turn.command == "turn"
    assert len(agent.ai.params) == 1
    assert agent.mainloop_manager.stop_agentic_loop is True
    assert any(message.content == "reported" for message in agent.session.messages)
