from datetime import timedelta

from codex_agent import Agent, DeveloperMessage
from codex_agent.scheduler import AgentScheduler, utc_now


class FakeFuture:
    id = "future_1"


def test_scheduler_persists_and_loads_jobs(tmp_path):
    agent = Agent(session="new")
    file = tmp_path / "wakeups.json"
    scheduler = AgentScheduler(agent, file=str(file))

    job = scheduler.schedule("say hello", delay_seconds=60, title="hello")

    loaded = AgentScheduler(agent, file=str(file))
    assert job.id in loaded.jobs
    assert loaded.jobs[job.id].prompt == "say hello"
    assert loaded.jobs[job.id].title == "hello"


def test_scheduler_triggers_due_one_shot_job(monkeypatch, tmp_path):
    agent = Agent(session="new")
    scheduler = AgentScheduler(agent, file=str(tmp_path / "wakeups.json"))
    submitted = []
    monkeypatch.setattr(agent, "submit_message", lambda message: submitted.append(message) or {"turn_id": FakeFuture.id})

    job = scheduler.schedule("wake up", delay_seconds=0, title="test")
    scheduler.tick(now=utc_now() + timedelta(seconds=1))

    assert submitted
    assert isinstance(submitted[0], DeveloperMessage)
    assert "Scheduled wakeup (test)" in submitted[0].content
    assert "wake up" in submitted[0].content
    assert scheduler.jobs[job.id].status == "completed"
    assert scheduler.jobs[job.id].run_count == 1


def test_scheduler_reschedules_periodic_job(monkeypatch, tmp_path):
    agent = Agent(session="new")
    scheduler = AgentScheduler(agent, file=str(tmp_path / "wakeups.json"))
    monkeypatch.setattr(agent, "submit_message", lambda message: {"turn_id": FakeFuture.id})

    job = scheduler.schedule("periodic", delay_seconds=0, interval_seconds=60, title="periodic")
    old_run_at = job.run_at
    scheduler.tick(now=utc_now() + timedelta(seconds=1))

    assert scheduler.jobs[job.id].status == "pending"
    assert scheduler.jobs[job.id].run_count == 1
    assert scheduler.jobs[job.id].run_at != old_run_at


def test_agent_schedule_wakeup_api_uses_scheduler(tmp_path):
    agent = Agent(session="new")
    agent.scheduler = AgentScheduler(agent, file=str(tmp_path / "wakeups.json"))

    job = agent.schedule_wakeup(prompt="hello", delay_seconds=10, title="api")
    cancelled = agent.cancel_wakeup(job.id)

    assert job.id in agent.scheduler.jobs
    assert cancelled.status == "cancelled"


def test_scheduler_plugin_uses_agent_wakeup_primitives(tmp_path):
    agent = Agent(session="new")
    agent.scheduler = AgentScheduler(agent, file=str(tmp_path / "wakeups.json"))

    job = agent.plugins.scheduler.schedule("hello", delay_seconds=10, title="plugin")
    cancelled = agent.plugins.scheduler.cancel(job.id)

    assert job.id in agent.scheduler.jobs
    assert cancelled.status == "cancelled"
