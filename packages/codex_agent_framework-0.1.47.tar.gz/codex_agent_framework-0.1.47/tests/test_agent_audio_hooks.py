from codex_agent import Agent, AudioPlaybackEvent, get_agent


def test_agent_keeps_voice_disabled_by_default_with_configured_openai_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    agent = Agent(session="new", openai_api_key="sk-test")

    assert agent.plugins.tts.config.enabled is False
    assert "memory" in agent.plugins


def test_agent_add_hook_decorator_runs_hook_with_agent_context():
    agent = Agent(session="new")
    seen = []

    @agent.add_hook("sample_hook")
    def sample(value):
        seen.append((value, get_agent().config.name))
        return value.upper()

    result = agent.run_hooks("sample_hook", "hello")

    assert seen == [("hello", agent.config.name)]
    assert result == ["HELLO"]


def test_agent_audio_playback_uses_hook_when_declared(monkeypatch):
    agent = Agent(session="new")
    played = []
    hooked = []
    monkeypatch.setattr("codex_agent.builtin_plugins.tts.silent_play", lambda audio: played.append(audio))

    @agent.add_hook("audio_playback_hook")
    def audio_hook(audio):
        hooked.append(audio)

    agent.emit(AudioPlaybackEvent, audio="audio")

    assert hooked == ["audio"]
    assert played == []


def test_agent_audio_playback_falls_back_to_silent_play(monkeypatch):
    agent = Agent(session="new")
    played = []
    monkeypatch.setattr("codex_agent.builtin_plugins.tts.silent_play", lambda audio: played.append(audio))

    agent.emit(AudioPlaybackEvent, audio="audio")

    assert played == ["audio"]


def test_voice_processor_disabled_is_direct_passthrough(monkeypatch):
    agent = Agent(session="new")

    def fail_if_called(_stream):
        raise AssertionError("disabled voice should not enter the voice pipeline")

    monkeypatch.setattr(agent.plugins.tts.voice_processor.mute_tag_processor, "process", fail_if_called)

    assert not hasattr(agent, "voice")
    assert list(agent.plugins.tts.voice_processor(iter(["a", "b"]))) == ["a", "b"]


def test_voice_processor_enabled_uses_voice_stream(monkeypatch):
    agent = Agent(session="new")
    agent.plugins.tts.config.enabled = True
    calls = []

    def voice_stream(stream):
        calls.append(True)
        for token in stream:
            yield token.upper()

    monkeypatch.setattr(agent.plugins.tts.voice_processor, "voice_stream", voice_stream)

    assert not hasattr(agent, "voice")
    assert list(agent.plugins.tts.voice_processor(iter(["a", "b"]))) == ["A", "B"]
    assert calls == [True]


def test_tts_mute_tag_processor_does_not_loop_on_newlines():
    agent = Agent(session="new")

    tokens = list(agent.plugins.tts.voice_processor.mute_tag_processor.process(iter(["a\n"])))

    assert tokens == ["a", "\n"]
