import os
import sys
from types import SimpleNamespace

import codex_agent.utils as utils
import pytest
from modict import modict

from codex_agent import Agent, AssistantInterrupted, AssistantInterruptedEvent, AssistantInterruptRequestedEvent
from codex_agent.message import AssistantMessage, DeveloperMessage, InterruptMessage, ToolResultMessage
from codex_agent.sessions import AgentSession

@pytest.fixture(autouse=True)
def isolate_tts_plugin_config(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.tts import TTSPlugin

    monkeypatch.setattr(TTSPlugin, "config_file_path", tmp_path / "builtins" / "tts.config.json")

def test_agent_manager_shortcuts_follow_replaced_managers():
    agent = Agent(session="new", openai_api_key="sk-test", builtin_plugins=[])

    old_tools = agent.tools
    old_providers = agent.providers
    old_commands = agent.commands
    old_plugins = agent.plugins
    old_stream_processors = agent.stream_processors
    old_stream_processor_owners = agent.stream_processor_owners
    old_config = agent.config

    agent.tools_manager = SimpleNamespace(tools=modict(reloaded_tool="tool"))
    agent.providers_manager = SimpleNamespace(providers=modict(reloaded_provider="provider"))
    agent.command_manager = SimpleNamespace(commands=modict(reloaded_command="command"))
    agent.plugins_manager = SimpleNamespace(plugins=modict(reloaded_plugin="plugin"))
    agent.stream_manager = SimpleNamespace(
        processors=modict(content=["processor"]),
        owners={"content": {"processor": "owner"}},
    )
    agent.config = modict(reloaded_config=True)

    assert agent.tools is agent.tools_manager.tools
    assert agent.providers is agent.providers_manager.providers
    assert agent.commands is agent.command_manager.commands
    assert agent.plugins is agent.plugins_manager.plugins
    assert agent.stream_processors is agent.stream_manager.processors
    assert agent.stream_processor_owners is agent.stream_manager.owners
    assert agent.config is agent.config_manager.config
    assert agent.config_manager.configs.agent is agent.config
    assert agent.tools is not old_tools
    assert agent.providers is not old_providers
    assert agent.commands is not old_commands
    assert agent.plugins is not old_plugins
    assert agent.stream_processors is not old_stream_processors
    assert agent.stream_processor_owners is not old_stream_processor_owners
    assert agent.config is not old_config

class InterruptingAI:
    def __init__(self, agent):
        self.agent = agent

    def run(self, **_params):
        self.agent.interrupt("test")
        raise AssistantInterrupted()

    def abort(self):
        pass

class AbortableAI:
    def __init__(self):
        self.aborted = False

    def abort(self):
        self.aborted = True

class FailingAbortAI:
    def abort(self):
        raise RuntimeError("abort failed")

def test_agent_state_mutations_run_through_mainloop_when_started(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    existing = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="existing")])
    existing.save()
    agent = Agent(session="new")
    agent.start()

    loaded = agent.load_session(existing.session_id)
    config = agent.config_manager.update(name="Queued", save=False)

    assert loaded.session_id == existing.session_id
    assert agent.current_session_id == existing.session_id
    assert config.name == "Queued"
    assert agent.config.name == "Queued"
    agent.stop()

def test_agent_interrupt_emits_request_event():
    agent = Agent(session="new")
    seen = []

    agent.on(AssistantInterruptRequestedEvent, lambda event: seen.append((event.type, event.reason, event.interrupted)))

    assert agent.interrupt("api") is True
    assert seen == [("assistant_interrupt_requested_event", "api", True)]

def test_agent_set_turn_result_requires_active_turn():
    agent = Agent(session="new")

    with pytest.raises(RuntimeError, match="No active agent turn"):
        agent.set_turn_result("outside")

def test_agent_initializes_new_session(isolated_runtime_dir):
    agent = Agent(session="new")

    assert agent.session is not None
    assert agent.current_session_id == agent.session.session_id
    assert " " not in agent.current_session_id
    assert agent.session.session_file.startswith(str(isolated_runtime_dir))
    assert (isolated_runtime_dir / "sessions" / f"{agent.current_session_id}.json").is_file()
    assert agent.session.messages[-1].type == "developer_message"
    assert agent.config.input_token_limit == 200000
    assert agent.config.max_images == 10
    assert agent.config.auto_compact is True
    assert "auto_archive_memory" not in agent.config
    assert agent.plugins.memory.config.auto_archive is False
    assert "token_limit" not in agent.config
    assert {tool.type for tool in agent.tools_manager.get_server_tools()} == {"web_search", "image_generation"}
    assert set(agent.plugins) >= {"browser", "desktop", "image_generation", "memory", "planner", "scheduler"}
    assert "browser_open" in agent.tools
    assert "browser_snapshot" not in agent.tools
    assert "browser_screenshot" not in agent.tools
    assert {method.__name__ for method in agent.plugins.browser.get_tools()} == {
        "open",
        "close",
        "select_tab",
        "previous_page",
        "goto",
        "click",
        "fill",
        "select",
        "press",
    }
    assert "desktop_start_session" in agent.tools
    assert "desktop_stop_session" in agent.tools
    assert "desktop_run_commands" in agent.tools
    assert "desktop" not in agent.tools
    assert [method.__name__ for method in agent.plugins.desktop.get_tools()] == ["run_commands", "start_session", "stop_session"]
    assert "memory_add" in agent.tools
    assert "planner_create" in agent.tools
    assert "planner_add" in agent.tools
    assert "planner_check" in agent.tools
    assert "scheduler_schedule" in agent.tools
    assert "subagents_run" in agent.tools
    assert "subagents_set_result" not in agent.tools
    assert "browser_state" in agent.providers
    assert "desktop_state" in agent.providers
    assert "retrieved_memory" in agent.providers
    assert "current_todos" in agent.providers
    assert "python" in agent.plugins
    assert agent.plugins.python.shell.silent is True
    assert not hasattr(agent, "shell")

def test_agent_keeps_memory_available_without_openai_api_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    agent = Agent(session="new")

    assert agent.plugins.tts.config.enabled is False
    assert "memory" in agent.plugins
    assert "memory_add" in agent.tools
    assert "retrieved_memory" in agent.providers

def test_context_compact_tool_reports_noop(monkeypatch):
    agent = Agent(session="new")
    calls = []
    monkeypatch.setattr(
        agent,
        "compact_session",
        lambda model=None, instructions=None, max_compacted_turns=None: calls.append(max_compacted_turns) or None,
    )

    result = agent.tools.context_compact(max_compacted_turns=1)

    assert calls == [1]
    assert result["status"] == "noop"
    assert result["message"] == "Nothing to compact."
    assert "before" in result
    assert "after" in result

def test_agent_initialization_prefers_project_python_on_process_path(monkeypatch):
    monkeypatch.setenv("PATH", "/usr/bin:/bin")
    agent = Agent(session="new")

    assert os.environ["PATH"].split(os.pathsep)[0] == os.path.dirname(sys.executable)
    assert os.environ["PYTHON"] == sys.executable
    assert agent.execution_env()["PATH"].split(os.pathsep)[0] == os.path.dirname(sys.executable)

def test_agent_can_resume_session_from_file():
    agent = Agent(session="new")
    session_file = agent.session.session_file
    message_count = len(agent.session.messages)

    resumed = Agent(session=session_file)

    assert resumed.current_session_id == agent.current_session_id
    assert len(resumed.session.messages) == message_count + 1
    assert resumed.session.messages[-1].type == "developer_message"

def test_agent_can_resume_latest_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="older")])
    newer = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="newer")])
    older.save()
    newer.save()

    agent = Agent(session="latest")

    assert agent.current_session_id == newer.session_id
    assert any(message.content == "newer" for message in agent.session.messages)

def test_agent_defaults_to_latest_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="older")])
    newer = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="newer")])
    older.save()
    newer.save()

    agent = Agent()

    assert agent.current_session_id == newer.session_id
    assert any(message.content == "newer" for message in agent.session.messages)

def test_agent_interrupt_emits_event_once():
    agent = Agent(session="new")
    abortable = AbortableAI()
    agent.ai = abortable
    seen = []

    agent.on(AssistantInterruptedEvent, lambda event: seen.append(event.reason))

    assert agent.interrupt("test") is True
    assert agent.interrupt("again") is True
    assert agent.is_interrupted() is True
    assert abortable.aborted is True
    assert seen == ["test"]

    agent.clear_interrupt()
    assert agent.is_interrupted() is False

def test_agent_interrupt_does_not_propagate_abort_errors():
    agent = Agent(session="new")
    agent.ai = FailingAbortAI()
    seen = []

    agent.on(AssistantInterruptRequestedEvent, lambda event: seen.append(event.error))

    assert agent.interrupt("api") is True
    assert agent.is_interrupted() is True
    assert seen == ["abort failed"]

def test_agent_process_stops_on_interruption():
    agent = Agent(session="new")
    agent.ai = InterruptingAI(agent)
    before = len(agent.session.messages)

    outcome = agent.mainloop_manager.process()

    assert outcome.completed is True
    assert outcome.reason == "interrupted"
    assert len(agent.session.messages) == before + 1
    assert isinstance(agent.session.messages[-1], InterruptMessage)
    assert agent.session.messages[-1].content == "User interrupted the current turn."

def test_agent_interrupt_after_tool_call_persists_tool_result_before_stopping():
    agent = Agent(session="new")

    @agent.add_tool
    def interrupting_tool():
        agent.interrupt("test")
        return "finished current tool"

    message = AssistantMessage(content="calling")
    message.tool_calls = [{
        "index": 0,
        "type": "function_call",
        "call_id": "call_1",
        "name": "interrupting_tool",
        "arguments": "{}",
    }]

    with pytest.raises(AssistantInterrupted):
        agent.mainloop_manager.call_tools(message)

    assert agent.session.messages[-1].type == "tool_result_message"
    assert agent.session.messages[-1].call_id == "call_1"
    assert "success" in agent.session.messages[-1].content
    assert agent.mainloop_manager.stop_agentic_loop is True

def test_agent_interrupt_after_tool_call_closes_remaining_tool_calls():
    agent = Agent(session="new")

    @agent.add_tool
    def interrupting_tool():
        agent.interrupt("test")
        return "finished current tool"

    @agent.add_tool
    def later_tool():
        raise AssertionError("later tool should not start after interrupt")

    message = AssistantMessage(content="calling")
    message.tool_calls = [
        {
            "index": 0,
            "type": "function_call",
            "call_id": "call_1",
            "name": "interrupting_tool",
            "arguments": "{}",
        },
        {
            "index": 1,
            "type": "function_call",
            "call_id": "call_2",
            "name": "later_tool",
            "arguments": "{}",
        },
    ]

    with pytest.raises(AssistantInterrupted):
        agent.mainloop_manager.call_tools(message)

    results = [msg for msg in agent.session.messages if isinstance(msg, ToolResultMessage)]
    assert [result.call_id for result in results] == ["call_1", "call_2"]
    assert "success" in results[0].content
    assert "not started" in results[1].content
