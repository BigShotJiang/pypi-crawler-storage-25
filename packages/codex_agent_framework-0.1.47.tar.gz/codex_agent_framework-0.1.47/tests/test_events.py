from modict import modict
import pytest

from codex_agent.event import (
    AssistantInterruptedEvent,
    Event,
    EventBus,
    ResponseContentDeltaEvent,
    ResponseDoneEvent,
    ResponseMessageDeltaEvent,
    ResponseOutputItemEvent,
    ServerToolCallEvent,
)


def test_event_type_is_computed_from_hierarchical_types():
    event = ResponseContentDeltaEvent(delta="hi")

    assert event.types == ["event", "response_content_delta_event"]
    assert event.type == "response_content_delta_event"


def test_event_bus_uses_typed_event_classes():
    bus = EventBus()
    seen = []

    @bus.on(ResponseContentDeltaEvent)
    def handle_delta(event):
        seen.append((event.type, event.delta))

    bus.emit(ResponseContentDeltaEvent, delta="hi")

    assert seen == [("response_content_delta_event", "hi")]


def test_event_bus_can_filter_on_intermediate_event_type():
    bus = EventBus()
    seen = []

    bus.on(Event, lambda event: seen.append(event.type))
    bus.emit(ResponseDoneEvent)

    assert seen == ["response_done_event"]


def test_event_bus_rejects_string_events_except_wildcard():
    bus = EventBus()

    with pytest.raises(TypeError):
        bus.on("response_content_delta_event", lambda event: None)

    with pytest.raises(TypeError):
        bus.emit("response_content_delta_event", delta="hi")


def test_event_bus_supports_wildcard_handlers():
    bus = EventBus()
    seen = []

    bus.on("*", lambda event: seen.append(event.type))
    bus.emit(ResponseDoneEvent)

    assert seen == ["response_done_event"]


def test_response_output_item_event_carries_server_side_items():
    bus = EventBus()
    seen = []
    item = modict(type="image_generation_call", id="ig_123", result="Zm9v")

    bus.on(ResponseOutputItemEvent, lambda event: seen.append(event.item))
    bus.emit(ResponseOutputItemEvent, item=item)

    assert seen == [item]


def test_response_message_delta_event_carries_mapping_delta():
    bus = EventBus()
    seen = []
    delta = modict(content="hi", tool_calls=[modict(name="read")])

    bus.on(ResponseMessageDeltaEvent, lambda event: seen.append(event.delta))
    bus.emit(ResponseMessageDeltaEvent, delta=delta)

    assert seen == [delta]


def test_server_tool_call_event_carries_server_tool_summary():
    bus = EventBus()
    seen = []
    item = modict(type="web_search_call", id="ws_123", status="completed")

    bus.on(ServerToolCallEvent, lambda event: seen.append((event.name, event.call_id, event.item)))
    bus.emit(ServerToolCallEvent, name="web_search", call_id="ws_123", item=item)

    assert seen == [("web_search", "ws_123", item)]


def test_assistant_interrupted_event_carries_reason():
    bus = EventBus()
    seen = []

    bus.on(AssistantInterruptedEvent, lambda event: seen.append((event.type, event.reason)))
    bus.emit(AssistantInterruptedEvent, reason="keyboard_interrupt")

    assert seen == [("assistant_interrupted_event", "keyboard_interrupt")]
