import json

import codex_agent.utils as utils
from codex_agent import Agent
from codex_agent.message import DeveloperMessage, ProviderMessage


def test_agent_provider_messages_are_ephemeral():
    agent = Agent(session="new")
    initial_count = len(agent.session.messages)

    @agent.add_provider
    def context_provider():
        return "plain"

    messages = agent.context_manager.get_providers_messages()

    assert "plain" in [message.content for message in messages]
    assert all(isinstance(message, ProviderMessage) for message in messages)
    assert len(agent.session.messages) == initial_count


def test_provider_message_wraps_content_for_api():
    message = ProviderMessage(name="clock", content="It is noon.")

    assert message.to_response_format() == {
        "type": "message",
        "role": "developer",
        "content": [{
            "type": "input_text",
            "text": '<context_provider name="clock">\nIt is noon.\n</context_provider>',
        }],
    }


def test_provider_must_return_supported_context_items():
    agent = Agent(session="new")

    @agent.add_provider
    def bad_provider():
        return {"not": "allowed"}

    try:
        agent.context_manager.get_providers_messages()
    except TypeError as exc:
        assert "items must be str or Message" in str(exc)
    else:
        raise AssertionError("Expected provider contract TypeError")


def test_agent_loads_builtin_date_and_time_provider():
    agent = Agent(session="new")

    assert "date_and_time" in agent.providers
    assert any(
        message.content.startswith("Current date and time:")
        for message in agent.context_manager.get_providers_messages()
    )


def test_agent_config_exposes_stable_system_prompt_infos():
    agent = Agent(session="new")

    assert agent.config.runtime_dir
    assert agent.config.source_dir.endswith("codex-agent")
    assert "Python" in agent.config.platform


def test_agent_config_helpers_persist_in_runtime_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    agent = Agent(session="new")
    agent.config_manager.update(name="Ada", model="gpt-test")

    config_file = tmp_path / "agent.config.json"
    assert config_file.is_file()
    assert json.loads(config_file.read_text())["name"] == "Ada"

    loaded = Agent(session="new")
    assert loaded.config.name == "Ada"
    assert loaded.config.model == "gpt-test"

    loaded.config_manager.update({"name": "Pandora"}, save=False)
    assert json.loads(config_file.read_text())["name"] == "Ada"

    loaded.config_manager.save()
    assert json.loads(config_file.read_text())["name"] == "Pandora"


def test_agent_config_loads_legacy_agent_config_json_and_saves_new_name(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    legacy_file = tmp_path / "agent_config.json"
    new_file = tmp_path / "agent.config.json"
    legacy_file.write_text(json.dumps({"name": "Legacy", "model": "gpt-legacy"}), encoding="utf-8")

    agent = Agent(session="new")

    assert agent.config.name == "Legacy"
    assert agent.config.model == "gpt-legacy"
    agent.config_manager.update(name="Migrated")
    assert json.loads(new_file.read_text())["name"] == "Migrated"
    assert json.loads(legacy_file.read_text())["name"] == "Legacy"


def test_provider_can_return_multiple_separate_messages_without_flattening():
    agent = Agent(session="new")

    @agent.add_provider(name="multi")
    def multi_provider():
        return [
            "plain text",
            DeveloperMessage(content="developer text"),
            DeveloperMessage(content=["first", {"type": "text", "text": "second"}, {"type": "input_image", "image_url": "data:image/png;base64,abc"}]),
        ]

    messages = agent.context_manager.get_providers_messages()
    multi_messages = [message for message in messages if getattr(message, "name", "") == "multi" or "multi" in str(message.get("content"))]

    assert len(multi_messages) == 3
    assert isinstance(multi_messages[0], ProviderMessage)
    assert multi_messages[0].content == "plain text"
    assert isinstance(multi_messages[1], DeveloperMessage)
    assert type(multi_messages[1]) is DeveloperMessage
    assert multi_messages[1].content == '<context_provider name="multi">\ndeveloper text\n</context_provider>'
    assert isinstance(multi_messages[2], DeveloperMessage)
    assert multi_messages[2].content[0] == '<context_provider name="multi">\nfirst\n</context_provider>'
    assert multi_messages[2].content[1]["text"] == '<context_provider name="multi">\nsecond\n</context_provider>'
    assert multi_messages[2].content[2] == {"type": "input_image", "image_url": "data:image/png;base64,abc"}
