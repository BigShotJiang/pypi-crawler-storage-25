import os

from codex_agent import Agent
from codex_agent.sessions import AgentSession


def test_agent_internal_paths_survive_process_cwd_changes(tmp_path, isolated_runtime_dir):
    project = tmp_path / "project"
    hostile = tmp_path / "hostile-cwd"
    project.mkdir()
    hostile.mkdir()
    agent = Agent(session="new", root_dir=str(project))

    previous_cwd = os.getcwd()
    try:
        os.chdir(hostile)

        agent.config_manager.save()
        agent.save_session()
        commands_folder = agent.command_manager.init_folder()
        plugins_folder = agent.plugins_manager.init_folder()
        agent.tools.write({"file_path": "relative.txt", "content": "from logical cwd"})

        assert agent.config_manager.file == str(isolated_runtime_dir / "agent.config.json")
        assert agent.session.session_file == str(isolated_runtime_dir / "sessions" / f"{agent.current_session_id}.json")
        assert commands_folder == str(isolated_runtime_dir / "commands")
        assert plugins_folder == str(isolated_runtime_dir / "plugins")
        assert agent.config.cwd == str(hostile)
        assert agent.session.cwd == str(hostile)
        assert (hostile / "relative.txt").read_text(encoding="utf-8") == "from logical cwd"
        assert not (project / "relative.txt").exists()
        assert not (hostile / "agent.config.json").exists()
        assert not (hostile / "sessions").exists()
        assert not (hostile / "commands").exists()
        assert not (hostile / "plugins").exists()
    finally:
        os.chdir(previous_cwd)


def test_agent_session_persists_root_and_cwd(tmp_path):
    root = tmp_path / "project"
    root.mkdir()

    agent = Agent(session="new", root_dir=str(root))

    assert agent.config.root_dir == str(root)
    assert agent.config.cwd == str(root)
    assert agent.session.root_dir == str(root)
    assert agent.session.cwd == str(root)
    assert AgentSession.load(agent.session.session_id).root_dir == str(root)


def test_agent_loads_builtin_cwd_provider():
    agent = Agent(session="new")

    assert "cwd" in agent.providers
    context = agent.providers.cwd()
    assert f"Session root directory: {agent.config.root_dir}" in context
    assert f"Working directory: {agent.config.cwd}" in context
    assert "Python shell working directory:" not in context
    assert any(
        "Working directory:" in message.content
        for message in agent.context_manager.get_providers_messages()
    )


def test_environment_cwd_provider_reports_unified_cwd_after_python_chdir(tmp_path):
    root = tmp_path / "project"
    python_dir = tmp_path / "python-dir"
    root.mkdir()
    python_dir.mkdir()
    agent = Agent(session="new", root_dir=str(root))

    agent.tools.python(f"import os\nos.chdir({str(python_dir)!r})")

    context = agent.providers.cwd()
    assert f"Session root directory: {root}" in context
    assert f"Working directory: {python_dir}" in context
    assert "Python shell working directory:" not in context


def test_environment_cd_command_changes_agent_cwd_without_changing_root(tmp_path):
    root = tmp_path / "project"
    subdir = root / "subdir"
    root.mkdir()
    subdir.mkdir()
    agent = Agent(session="new", root_dir=str(root))

    result = agent.command_manager.run("/cd subdir")

    assert "Working directory changed to:" in result
    assert agent.config.root_dir == str(root)
    assert agent.config.cwd == str(subdir)
    assert agent.session.root_dir == str(root)
    assert agent.session.cwd == str(subdir)
    assert f"Session root directory: {root}" in agent.providers.cwd()
    assert f"Working directory: {subdir}" in agent.providers.cwd()


def test_environment_cd_command_updates_relative_file_and_bash_cwd(tmp_path):
    root = tmp_path / "project"
    subdir = root / "subdir"
    root.mkdir()
    subdir.mkdir()
    (subdir / "marker.txt").write_text("from subdir", encoding="utf-8")
    agent = Agent(session="new", root_dir=str(root))

    agent.command_manager.run("/cd subdir")

    assert "from subdir" in agent.tools.read({"source": "marker.txt"})[0]
    bash_response = agent.tools.bash("pwd")
    assert str(subdir) in bash_response


def test_environment_cd_command_syncs_python_shell_cwd(tmp_path):
    root = tmp_path / "project"
    subdir = root / "subdir"
    python_dir = root / "python-dir"
    root.mkdir()
    subdir.mkdir()
    python_dir.mkdir()
    agent = Agent(session="new", root_dir=str(root))
    agent.tools.python(f"import os\nos.chdir({str(python_dir)!r})")

    agent.command_manager.run(f"/cd {subdir}")

    assert agent.config.cwd == str(subdir)
    assert agent.plugins.python.shell.cwd == str(subdir)
    context = agent.providers.cwd()
    assert f"Working directory: {subdir}" in context
    assert "Python shell working directory:" not in context


def test_environment_cd_command_without_argument_returns_to_root(tmp_path):
    root = tmp_path / "project"
    subdir = root / "subdir"
    root.mkdir()
    subdir.mkdir()
    agent = Agent(session="new", root_dir=str(root), cwd=str(subdir))

    agent.command_manager.run("/cd")

    assert agent.config.root_dir == str(root)
    assert agent.config.cwd == str(root)
    assert agent.session.root_dir == str(root)
    assert agent.session.cwd == str(root)


def test_environment_cd_command_rejects_non_directory(tmp_path):
    root = tmp_path / "project"
    root.mkdir()
    (root / "file.txt").write_text("not a directory", encoding="utf-8")
    agent = Agent(session="new", root_dir=str(root))

    try:
        agent.command_manager.run("/cd file.txt")
    except NotADirectoryError as exc:
        assert f"Not a directory: {root / 'file.txt'}" in str(exc)
    else:
        raise AssertionError("Expected NotADirectoryError")


def test_environment_pwd_command_reports_working_directories(tmp_path):
    root = tmp_path / "project"
    cwd = root / "work"
    root.mkdir()
    cwd.mkdir()
    agent = Agent(session="new", root_dir=str(root), cwd=str(cwd))

    result = agent.command_manager.run("/pwd")

    assert f"Session root directory: {root}" in result
    assert f"Working directory: {cwd}" in result
    assert "Python shell working directory:" not in result


def test_environment_root_command_without_argument_reports_working_directories(tmp_path):
    root = tmp_path / "project"
    root.mkdir()
    agent = Agent(session="new", root_dir=str(root))

    result = agent.command_manager.run("/root")

    assert f"Session root directory: {root}" in result
    assert f"Working directory: {root}" in result


def test_environment_root_command_changes_anchor_and_moves_cwd_when_at_old_root(tmp_path):
    root = tmp_path / "project"
    new_root = tmp_path / "new-project"
    root.mkdir()
    new_root.mkdir()
    agent = Agent(session="new", root_dir=str(root))

    result = agent.command_manager.run(f"/root {new_root}")

    assert "Session root directory changed to:" in result
    assert agent.config.root_dir == str(new_root)
    assert agent.config.cwd == str(new_root)
    assert agent.session.root_dir == str(new_root)
    assert agent.session.cwd == str(new_root)


def test_environment_root_command_changes_anchor_without_overwriting_distinct_cwd(tmp_path):
    root = tmp_path / "project"
    work = root / "work"
    new_root = tmp_path / "new-project"
    root.mkdir()
    work.mkdir()
    new_root.mkdir()
    agent = Agent(session="new", root_dir=str(root), cwd=str(work))

    agent.command_manager.run(f"/root {new_root}")

    assert agent.config.root_dir == str(new_root)
    assert agent.config.cwd == str(work)
    assert agent.session.root_dir == str(new_root)
    assert agent.session.cwd == str(work)


def test_environment_root_command_rejects_non_directory(tmp_path):
    root = tmp_path / "project"
    root.mkdir()
    (root / "file.txt").write_text("not a directory", encoding="utf-8")
    agent = Agent(session="new", root_dir=str(root))

    try:
        agent.command_manager.run("/root file.txt")
    except NotADirectoryError as exc:
        assert f"Not a directory: {root / 'file.txt'}" in str(exc)
    else:
        raise AssertionError("Expected NotADirectoryError")
