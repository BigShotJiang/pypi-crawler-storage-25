import json

import codex_agent.utils as utils
from codex_agent import Agent, ResponseContentDeltaEvent, SubagentEvent
from codex_agent.message import AssistantMessage


def test_subagents_run_tool_only_exposes_profile_and_task():
    agent = Agent(session="new", builtin_plugins=["subagents"])

    tool_schema = agent.tools.subagents_run.to_response_tool()
    properties = tool_schema["parameters"]["properties"]

    assert set(properties) == {"profile", "task"}
    assert tool_schema["parameters"]["required"] == ["profile", "task"]
    assert "config" not in properties
    assert "builtin_plugins" not in properties
    assert "custom_plugins" not in properties
    assert "keep_session" not in properties


def write_subagent_profile(profiles_dir, profile_file, **profile):
    profiles_dir.mkdir(parents=True, exist_ok=True)
    (profiles_dir / f"{profile_file}.json").write_text(json.dumps(profile), encoding="utf-8")


def test_subagent_plugin_loads_profiles_from_json_folder(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.subagents import SubagentsPlugin

    profiles_dir = tmp_path / "profiles"
    write_subagent_profile(
        profiles_dir,
        "worker",
        id="worker",
        name="Worker",
        description="Focused worker profile.",
        builtin_plugins=["subagents"],
    )
    monkeypatch.setattr(SubagentsPlugin, "profiles_dir", profiles_dir)

    agent = Agent(session="new", builtin_plugins=["subagents"])

    assert set(agent.plugins.subagents.profiles) == {"worker"}
    assert agent.plugins.subagents.profiles.worker.name == "Worker"
    prompt = agent.plugins.subagents.get_system_prompt_sections()[0]
    assert "`worker`: Focused worker profile." in prompt


def test_subagent_plugin_requires_registered_profile():
    agent = Agent(session="new", builtin_plugins=["subagents"])

    result = agent.plugins.subagents.run_subagent("missing", "do work")

    assert result.status == "error"
    assert result.name == "missing"
    assert "Unknown subagent profile: missing" in result.error


def test_subagent_profile_builds_child_system_prompt_from_common_and_profile_sections(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.subagents import SubagentsPlugin

    profiles_dir = tmp_path / "profiles"
    write_subagent_profile(
        profiles_dir,
        "reviewer",
        id="reviewer",
        name="Reviewer",
        role="You review code.",
        goal="Find risky changes.",
        means="Use read-only inspection.",
        objective="Return risks and confidence.",
        system_prompt="Extra reviewer constraints.",
        builtin_plugins=["files"],
    )
    monkeypatch.setattr(SubagentsPlugin, "profiles_dir", profiles_dir)

    parent = Agent(session="new", builtin_plugins=["subagents"])
    profile = parent.plugins.subagents.profile("reviewer")
    config = parent.plugins.subagents.child_config(profile)

    assert "You are a focused subagent" in config.system
    assert "## Role\nYou review code." in config.system
    assert "## Goal\nFind risky changes." in config.system
    assert "## Means\nUse read-only inspection." in config.system
    assert "## Objective\nReturn risks and confidence." in config.system
    assert "Extra reviewer constraints." in config.system
    assert config.builtin_plugins == ["files"]


def test_subagent_profile_can_exclude_tool_surface_via_agent_config(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.subagents import SubagentsPlugin
    from codex_agent.agent import Agent as RealAgent

    profiles_dir = tmp_path / "profiles"
    write_subagent_profile(
        profiles_dir,
        "readonly",
        id="readonly",
        builtin_plugins=["files"],
        exclude_tools=["files.write", "files.edit"],
    )
    monkeypatch.setattr(SubagentsPlugin, "profiles_dir", profiles_dir)

    parent = Agent(session="new", builtin_plugins=["subagents"])
    profile = parent.plugins.subagents.profile("readonly")
    child = RealAgent(session="new", **parent.plugins.subagents.child_config(profile))

    parent.plugins.subagents.install_child_tools(child)

    assert "read" in child.tools
    assert "write" not in child.tools
    assert "edit" not in child.tools
    assert "set_result" in child.tools


def test_subagent_plugin_runs_ephemeral_child_agent_with_structured_result(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.subagents import SubagentsPlugin

    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    profiles_dir = tmp_path / "profiles"
    write_subagent_profile(profiles_dir, "worker", id="worker", name="Worker", builtin_plugins=["subagents"])
    monkeypatch.setattr(SubagentsPlugin, "profiles_dir", profiles_dir)

    class ResultAI:
        def __init__(self, agent):
            self.agent = agent
            self.params = []

        def run(self, **params):
            self.params.append(params)
            if len(self.params) == 1:
                message = AssistantMessage()
                message.tool_calls = [{
                    "type": "function_call",
                    "call_id": "call_1",
                    "name": "set_result",
                    "arguments": json.dumps({"data": {"answer": 42}}),
                }]
                return message
            raise AssertionError("subagent should stop after setting a turn result")

    real_agent = Agent

    class TestAgent(real_agent):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.ai = ResultAI(self)

    import codex_agent.agent as agent_module

    monkeypatch.setattr(agent_module, "Agent", TestAgent)

    parent = Agent(session="new", builtin_plugins=["subagents"])
    result = parent.plugins.subagents.run_subagent("worker", "return the answer")

    assert result.status == "done"
    assert result.name == "Worker"
    assert result.profile == "worker"
    assert result.result == {"answer": 42}
    assert "session_id" not in result
    assert "message_count" not in result
    assert "event_count" not in result
    assert "messages" not in result
    assert sorted(path.stem for path in (tmp_path / "sessions").glob("*.json")) == [parent.current_session_id]


def test_subagent_plugin_relays_child_events_wrapped_for_parent_ui(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.subagents import SubagentsPlugin

    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    profiles_dir = tmp_path / "profiles"
    write_subagent_profile(profiles_dir, "worker", id="worker", name="Worker", builtin_plugins=["subagents"])
    monkeypatch.setattr(SubagentsPlugin, "profiles_dir", profiles_dir)

    class ResultAI:
        def __init__(self, agent):
            self.agent = agent

        def run(self, **params):
            self.agent.emit(ResponseContentDeltaEvent, delta="child-stream")
            message = AssistantMessage()
            message.tool_calls = [{
                "type": "function_call",
                "call_id": "call_1",
                "name": "set_result",
                "arguments": json.dumps({"data": "done"}),
            }]
            return message

    real_agent = Agent

    class TestAgent(real_agent):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.ai = ResultAI(self)

    import codex_agent.agent as agent_module

    monkeypatch.setattr(agent_module, "Agent", TestAgent)

    parent = Agent(session="new", builtin_plugins=["subagents"])
    seen = []
    parent.on(SubagentEvent, lambda event: seen.append(event))

    result = parent.plugins.subagents.run_subagent("worker", "stream some work")

    assert result.status == "done"
    assert seen
    assert all(event.subagent == "worker" for event in seen)
    assert all(event.session_id for event in seen)
    assert "assistant_turn_start_event" in [event.event.type for event in seen]
    assert "response_content_delta_event" in [event.event.type for event in seen]
    assert any(event.event.get("delta") == "child-stream" for event in seen)


def test_subagent_plugin_supports_multi_step_child_turn(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.subagents import SubagentsPlugin

    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    profiles_dir = tmp_path / "profiles"
    write_subagent_profile(profiles_dir, "worker", id="worker", builtin_plugins=["subagents"])
    monkeypatch.setattr(SubagentsPlugin, "profiles_dir", profiles_dir)

    class MultiStepAI:
        def __init__(self, agent):
            self.agent = agent
            self.params = []

        def run(self, **params):
            self.params.append(params)
            message = AssistantMessage()
            if len(self.params) == 1:
                message.tool_calls = [{
                    "type": "function_call",
                    "call_id": "call_1",
                    "name": "echo",
                    "arguments": json.dumps({"value": "intermediate"}),
                }]
            elif len(self.params) == 2:
                message.tool_calls = [{
                    "type": "function_call",
                    "call_id": "call_2",
                    "name": "set_result",
                    "arguments": json.dumps({"data": {"final": True}}),
                }]
            else:
                raise AssertionError("subagent should stop after second step")
            return message

    real_agent = Agent

    class TestAgent(real_agent):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.add_tool(lambda value: value, name="echo")
            self.ai = MultiStepAI(self)

    import codex_agent.agent as agent_module

    monkeypatch.setattr(agent_module, "Agent", TestAgent)

    parent = Agent(session="new", builtin_plugins=["subagents"])
    result = parent.plugins.subagents.run_subagent("worker", "do two steps")

    assert result.status == "done"
    assert result.result == {"final": True}
    assert "messages" not in result
    assert sorted(path.stem for path in (tmp_path / "sessions").glob("*.json")) == [parent.current_session_id]


def test_subagent_plugin_can_keep_child_session_for_debugging(tmp_path, monkeypatch):
    from codex_agent.builtin_plugins.subagents import SubagentsPlugin

    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    profiles_dir = tmp_path / "profiles"
    write_subagent_profile(profiles_dir, "debug", id="debug", builtin_plugins=["subagents"], keep_session=True)
    monkeypatch.setattr(SubagentsPlugin, "profiles_dir", profiles_dir)

    class ResultAI:
        def __init__(self, agent):
            self.agent = agent

        def run(self, **params):
            message = AssistantMessage()
            message.tool_calls = [{
                "type": "function_call",
                "call_id": "call_1",
                "name": "set_result",
                "arguments": json.dumps({"data": "kept"}),
            }]
            return message

    real_agent = Agent

    class TestAgent(real_agent):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.ai = ResultAI(self)

    import codex_agent.agent as agent_module

    monkeypatch.setattr(agent_module, "Agent", TestAgent)

    parent = Agent(session="new", builtin_plugins=["subagents"])
    result = parent.plugins.subagents.run_subagent("debug", "keep the session")

    assert result.status == "done"
    assert result.result == "kept"
    assert "session_id" not in result
    assert len(list((tmp_path / "sessions").glob("*.json"))) == 2
