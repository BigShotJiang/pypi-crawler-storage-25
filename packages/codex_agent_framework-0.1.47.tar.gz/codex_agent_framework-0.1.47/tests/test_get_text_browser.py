import importlib

import requests

get_text_module = importlib.import_module("codex_agent.get_text.get_text")


def test_extract_webpage_content_force_browser_uses_rendered_html(monkeypatch):
    calls = []

    class FakeBrowserController:
        def fetch_rendered_html(self, url, **kwargs):
            calls.append((url, kwargs))
            return "<html><body><main>Rendered browser content with enough words to be accepted by extraction.</main></body></html>"

    monkeypatch.setattr(get_text_module, "get_browser_controller", lambda: FakeBrowserController())

    text = get_text_module.extract_webpage_content("https://example.com", force_browser=True)

    assert "Rendered browser content" in text
    assert calls == [("https://example.com", {"headless": True})]


def test_extract_webpage_content_falls_back_to_browser_when_static_content_is_insufficient(monkeypatch):
    class FakeResponse:
        text = "<html><body>too short</body></html>"

        def raise_for_status(self):
            pass

    monkeypatch.setattr(get_text_module.requests, "get", lambda *args, **kwargs: FakeResponse())
    class FakeBrowserController:
        def fetch_rendered_html(self, url, **kwargs):
            return "<html><body><article>Rendered dynamic page content with many words so the extracted browser fallback text is useful and sufficient for downstream reading.</article></body></html>"

    monkeypatch.setattr(get_text_module, "get_browser_controller", lambda: FakeBrowserController())

    text = get_text_module.extract_webpage_content("https://example.com")

    assert "Rendered dynamic page content" in text


def test_extract_webpage_content_falls_back_to_browser_when_request_fails(monkeypatch):
    def failing_get(*args, **kwargs):
        raise requests.exceptions.ConnectionError("offline")

    monkeypatch.setattr(get_text_module.requests, "get", failing_get)
    class FakeBrowserController:
        def fetch_rendered_html(self, url, **kwargs):
            return "<html><body><main>Browser fallback after request failure with enough textual words to make the extraction meaningful.</main></body></html>"

    monkeypatch.setattr(get_text_module, "get_browser_controller", lambda: FakeBrowserController())

    text = get_text_module.extract_webpage_content("https://example.com")

    assert "Browser fallback after request failure" in text
