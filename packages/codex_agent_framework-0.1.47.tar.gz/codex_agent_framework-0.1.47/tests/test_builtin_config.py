from codex_agent.config import ConfigManager


class DummyAgent:
    pass


def manager_with_builtin_field(field, value):
    agent = DummyAgent()
    manager = ConfigManager(agent)
    setattr(manager.config, field, value)
    return manager


def test_builtin_plugin_enabled_none_loads_everything():
    manager = manager_with_builtin_field("builtin_plugins", None)

    assert manager.builtin_plugin_enabled("bash") is True
    assert manager.builtin_plugin_enabled("anything") is True


def test_builtin_plugin_enabled_empty_list_loads_nothing():
    manager = manager_with_builtin_field("builtin_plugins", [])

    assert manager.builtin_plugin_enabled("bash") is False


def test_builtin_plugin_enabled_list_loads_only_named_builtins():
    manager = manager_with_builtin_field("builtin_plugins", ["memory", "planner"])

    assert manager.builtin_plugin_enabled("memory") is True
    assert manager.builtin_plugin_enabled("planner") is True
    assert manager.builtin_plugin_enabled("browser") is False
