import importlib

cli_main = importlib.import_module("codex_agent.cli.main")


class FakeAgent:
    instances = []

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        FakeAgent.instances.append(self)


def test_cli_starts_local_server_and_chat_by_default(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_local", lambda host, port: calls.append((host, port)))

    cli_main.main([])

    assert calls == [("127.0.0.1", 8765)]


def test_run_local_uses_existing_server_when_available(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "server_is_available", lambda base_url: True)
    monkeypatch.setattr(cli_main, "run_chat", lambda base_url: calls.append(("chat", base_url)))
    monkeypatch.setattr(cli_main, "create_app", lambda *args, **kwargs: calls.append(("create_app", args, kwargs)))

    cli_main.run_local("127.0.0.1", 8765)

    assert calls == [("chat", "http://127.0.0.1:8765")]


def test_run_local_starts_temporary_server_when_no_server_is_available(monkeypatch):
    import uvicorn

    calls = []

    class FakeAgentService:
        def start(self):
            calls.append(("agent_service.start",))

    class FakeState:
        agent_service = FakeAgentService()

    class FakeApp:
        state = FakeState()

    class FakeServer:
        def __init__(self, config):
            self.config = config
            self.should_exit = False
            calls.append(("server.init", config.host, config.port))

        def run(self):
            calls.append(("server.run",))

    monkeypatch.setattr(cli_main, "server_is_available", lambda base_url: False)
    monkeypatch.setattr(cli_main, "create_app", lambda *args, **kwargs: calls.append(("create_app", kwargs)) or FakeApp())
    monkeypatch.setattr(cli_main, "run_chat", lambda base_url: calls.append(("chat", base_url)))
    monkeypatch.setattr(uvicorn, "Server", FakeServer)
    monkeypatch.setattr(cli_main.time, "sleep", lambda delay: calls.append(("sleep", delay))) if hasattr(cli_main, "time") else None

    cli_main.run_local("127.0.0.2", 9999)

    assert ("create_app", {"process_agent": True, **cli_main.default_agent_kwargs("127.0.0.2", 9999)}) in calls
    assert ("agent_service.start",) in calls
    assert ("server.init", "127.0.0.2", 9999) in calls
    assert ("chat", "http://127.0.0.2:9999") in calls


def test_cli_rejects_direct_server_mode():
    import pytest

    with pytest.raises(SystemExit) as exc:
        cli_main.main(["server", "--host", "0.0.0.0", "--port", "9999"])

    assert exc.value.code == 2


def test_cli_chat_mode_uses_existing_server_url(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_chat", lambda base_url: calls.append(base_url))

    cli_main.main(["chat", "--url", "http://agent.local"])

    assert calls == ["http://agent.local"]


def test_cli_rejects_direct_tray_mode():
    import pytest

    with pytest.raises(SystemExit) as exc:
        cli_main.main(["tray", "--url", "http://agent.local"])

    assert exc.value.code == 2


def test_cli_install_system_deps_forwards_installer_args(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_system_deps_installer", lambda args: calls.append(args) or 7)

    try:
        cli_main.main(["install-system-deps", "--", "-y", "--no-tray"])
    except SystemExit as exc:
        assert exc.code == 7
    else:  # pragma: no cover - defensive
        raise AssertionError("install-system-deps should exit with installer status")

    assert calls == [["-y", "--no-tray"]]


def test_cli_bootstrap_installs_deps_then_services(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_system_deps_installer", lambda args: calls.append(("deps", args)) or 0)
    monkeypatch.setattr(
        cli_main,
        "install_user_service",
        lambda host, port, enable, start: calls.append(("service", host, port, enable, start)) or "/service/path",
    )

    try:
        cli_main.main(["bootstrap", "--host", "127.0.0.2", "--port", "9999", "--", "-y"])
    except SystemExit as exc:
        assert exc.code == 0
    else:  # pragma: no cover - defensive
        raise AssertionError("bootstrap should exit with status")

    assert calls == [
        ("deps", ["-y"]),
        ("service", "127.0.0.2", 9999, True, True),
    ]


def test_cli_bootstrap_can_skip_steps(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_system_deps_installer", lambda args: calls.append(("deps", args)) or 0)
    monkeypatch.setattr(
        cli_main,
        "install_user_service",
        lambda host, port, enable, start: calls.append(("service", host, port, enable, start)) or "/service/path",
    )

    try:
        cli_main.main(["bootstrap", "--no-system-deps", "--no-start-service"])
    except SystemExit as exc:
        assert exc.code == 0
    else:  # pragma: no cover - defensive
        raise AssertionError("bootstrap should exit with status")

    assert calls == [("service", "127.0.0.1", 8765, True, False)]


def test_cli_bootstrap_stops_if_system_deps_fail(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_system_deps_installer", lambda args: calls.append(("deps", args)) or 23)
    monkeypatch.setattr(
        cli_main,
        "install_user_service",
        lambda **kwargs: calls.append(("service", kwargs)),
    )

    try:
        cli_main.main(["bootstrap", "--", "--dry-run"])
    except SystemExit as exc:
        assert exc.code == 23
    else:  # pragma: no cover - defensive
        raise AssertionError("bootstrap should exit with status")

    assert calls == [("deps", ["--dry-run"])]
