import json

import pytest
from modict import modict

from codex_agent import Agent
from codex_agent.image import ImageMessage
from codex_agent.message import AssistantMessage


@pytest.fixture(autouse=True)
def fast_desktop_command_settle(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    monkeypatch.setattr(desktop_plugin.DesktopPlugin, "command_settle_seconds", 0)


def test_builtin_desktop_state_provider_only_emits_when_live(tmp_path, monkeypatch):
    from PIL import Image
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    screenshot_path = tmp_path / "live.png"
    grid_path = tmp_path / "live-grid.png"
    Image.new("RGB", (1, 1), color="blue").save(screenshot_path)

    class FakeDesktop:
        live_session = False

        def capture_screen(self, output_path):
            assert output_path.endswith("live_desktop.png")
            return str(screenshot_path)

        def list_windows(self):
            return [modict(
                id="0x123",
                x=10,
                y=20,
                width=800,
                height=600,
                wm_class="app.Class",
                active=True,
                visible=True,
                title="Example window",
            )]

    fake = FakeDesktop()
    monkeypatch.setattr(desktop_plugin, "_draw_desktop_grid", lambda path: str(grid_path))
    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = fake

    assert plugin.desktop_state() is None

    fake.live_session = True
    result = plugin.desktop_state()

    assert "Desktop live session is active" in result[0]
    assert "light 100 px coordinate grid" in result[0]
    assert "0x123 800x600+10+20" in result[0]
    assert "Example window" in result[0]
    assert isinstance(result[1], ImageMessage)
    assert result[1].content == str(grid_path)
    assert result[1].image_name == "live_desktop_grid.png"


def test_builtin_desktop_run_commands_schema_exposes_actions_only():
    agent = Agent(session="new")

    tool_schema = agent.tools.desktop_run_commands.to_response_tool()

    assert tool_schema["type"] == "custom"
    assert "activate_window" in tool_schema["description"]
    assert '"command": "click_drag_release"' in tool_schema["description"]
    assert '"command": "copy", "text": "hello"' in tool_schema["description"]
    assert '"command": "paste"' in tool_schema["description"]
    assert '"command": "press", "keys": "Return"' in tool_schema["description"]
    assert "one simultaneous key chord in xdotool key format" in tool_schema["description"]
    assert '"command": "zoom", "x": 600, "y": 300, "width": 400, "height": 250' in tool_schema["description"]
    assert "grid_step" not in tool_schema["description"]
    assert "scale" not in tool_schema["description"]
    assert "type_text" not in tool_schema["description"]
    assert "load_clipboard" not in tool_schema["description"]
    assert "paste_clipboard" not in tool_schema["description"]
    assert "desktop_start_session" in tool_schema["description"]
    assert "list_windows" not in tool_schema["description"]
    assert "mouse_location" not in tool_schema["description"]
    assert "live_session_status" not in tool_schema["description"]
    assert "capture_region_grid" not in tool_schema["description"]


def test_builtin_desktop_batch_runs_multiple_commands(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = False

        def start_live_session(self):
            self.live_session = True
            calls.append("start")

        def move_mouse(self, x, y):
            calls.append(("move", x, y))

        def press(self, keys):
            calls.append(("press", keys))

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()
    plugin.command_settle_seconds = 1
    sleeps = []
    monkeypatch.setattr(desktop_plugin.time, "sleep", lambda seconds: sleeps.append(seconds))

    start_result = plugin.start_session()
    result = plugin.run_commands("""[
        {"command": "move_mouse", "x": 10, "y": 20},
        {"command": "press", "keys": "Return"}
    ]""")

    assert "Desktop live session started" in start_result
    assert calls == ["start", ("move", 10, 20), ("press", "Return")]
    assert result == ["Moved mouse to 10,20.", "Pressed keys Return."]
    assert sleeps == [1]


def test_builtin_desktop_clipboard_commands_delegate(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = True

        def copy(self, text=None):
            calls.append(("copy", text))

        def paste(self):
            calls.append(("paste",))

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()

    result = plugin.run_commands(json.dumps([
        {"command": "copy", "text": "hello clipboard"},
        {"command": "paste"},
        {"command": "copy"},
    ]))

    assert calls == [("copy", "hello clipboard"), ("paste",), ("copy", None)]
    assert result == [
        "Copied 15 character(s) to the clipboard.",
        "Pasted clipboard at the cursor location.",
        "Copied current selection to the clipboard.",
    ]


def test_agent_calls_builtin_desktop_as_custom_tool(monkeypatch):

    class FakeDesktop:
        live_session = False

        def move_mouse(self, x, y):
            raise AssertionError("desktop action should not run while live session is inactive")

    agent = Agent(session="new", auto_proceed=False)
    agent.plugins.desktop.desktop_controller = FakeDesktop()
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_desktop",
        "name": "desktop_run_commands",
        "input": "{\"command\":\"move_mouse\",\"x\":10,\"y\":20}",
    }]

    assert agent.tools["desktop_run_commands"].to_response_tool()["type"] == "custom"
    assert agent.mainloop_manager.call_tools(message) is True

    assert "success: call_id=call_desktop" in agent.session.messages[-1].content
    assert "failed: desktop live session is not active" in agent.mainloop_manager.pending[-1].content


def test_builtin_desktop_zoom_returns_image(tmp_path):
    from PIL import Image
    from codex_agent.image import ImageMessage
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    screenshot_path = tmp_path / "screen.png"
    Image.new("RGB", (120, 90), color="navy").save(screenshot_path)

    class FakeDesktop:
        live_session = True

        def capture_screen(self, path):
            return str(screenshot_path)

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()
    output_path = tmp_path / "zoom.png"

    result = plugin.run_commands({
        "command": "zoom",
        "x": 10,
        "y": 20,
        "width": 50,
        "height": 40,
        "output_path": str(output_path),
    })

    assert "Zoomed desktop region 50x40+10+20" in result[0]
    assert isinstance(result[1], ImageMessage)
    assert result[1].content == str(output_path)
    assert result[1].image_name == "desktop_zoom_10_20_50x40.png"
    with Image.open(output_path) as image:
        assert image.size == (800, 640)


def test_builtin_desktop_move_resize_window_delegates(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = True

        def move_resize_window(self, window_id, x, y, width, height):
            calls.append((window_id, x, y, width, height))

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()

    result = plugin.run_commands({
        "command": "move_resize_window",
        "window_id": "0xabc",
        "x": 10,
        "y": 20,
        "width": 300,
        "height": 200,
    })

    assert calls == [("0xabc", 10, 20, 300, 200)]
    assert "Moved/resized window 0xabc" in result[0]


def test_builtin_desktop_click_drag_release_delegates(monkeypatch):
    import codex_agent.builtin_plugins.desktop as desktop_plugin

    calls = []

    class FakeDesktop:
        live_session = True

        def click_drag_release(self, **kwargs):
            calls.append(kwargs)

    plugin = desktop_plugin.DesktopPlugin(None)
    plugin.desktop_controller = FakeDesktop()

    result = plugin.run_commands({
        "command": "click_drag_release",
        "x": 10,
        "y": 20,
        "to_x": 30,
        "to_y": 40,
        "button": 1,
    })

    assert calls == [{"x": 10, "y": 20, "to_x": 30, "to_y": 40, "button": 1}]
    assert "Dragged mouse button 1 from 10,20 to 30,40" in result[0]
