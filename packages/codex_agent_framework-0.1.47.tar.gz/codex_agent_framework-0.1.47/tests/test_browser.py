from pathlib import Path

import pytest

from codex_agent import browser


class FakeKeyboard:
    def __init__(self):
        self.press_calls = []

    async def press(self, key, **kwargs):
        self.press_calls.append((key, kwargs))


class FakePage:
    def __init__(self, visibility_state="visible", has_focus=False):
        self.goto_calls = []
        self.screenshot_calls = []
        self.evaluate_calls = []
        self.locators = []
        self.keyboard = FakeKeyboard()
        self.visibility_state = visibility_state
        self.has_focus = has_focus
        self.context = None

    async def goto(self, url, wait_until="domcontentloaded", timeout=30_000):
        self.goto_calls.append({"url": url, "wait_until": wait_until, "timeout": timeout})

    async def content(self):
        return "<html><body>Hello</body></html>"

    def locator(self, selector):
        locator = FakeLocator(selector)
        self.locators.append(locator)
        return locator

    async def evaluate(self, script, arg=None):
        self.evaluate_calls.append((script, arg))
        if arg is None and "visibilityState" in script:
            return {"visibilityState": self.visibility_state, "hasFocus": self.has_focus}
        return {
            "title": "Fake page",
            "url": "https://example.com",
            "elements": [
                {"id": "1", "role": "link", "name": "Home", "href": "https://example.com/home"},
                {"id": "2", "role": "input", "name": "Search", "placeholder": "Query"},
            ],
            "truncated": False,
        }

    async def screenshot(self, path, full_page=True):
        self.screenshot_calls.append({"path": path, "full_page": full_page})
        Path(path).write_bytes(b"fake image")

    async def bring_to_front(self):
        if self.context is not None:
            for page in self.context.pages:
                page.visibility_state = "hidden"
                page.has_focus = False
        self.visibility_state = "visible"
        self.has_focus = True


class FakeLocator:
    def __init__(self, selector):
        self.selector = selector
        self.click_calls = []
        self.fill_calls = []
        self.select_calls = []
        self.press_calls = []

    async def inner_text(self, timeout=30_000):
        return f"text for {self.selector}"

    async def click(self, **kwargs):
        self.click_calls.append(kwargs)

    async def fill(self, text, **kwargs):
        self.fill_calls.append((text, kwargs))

    async def select_option(self, value, **kwargs):
        self.select_calls.append((value, kwargs))
        return [value]

    async def press(self, key, **kwargs):
        self.press_calls.append((key, kwargs))


class FakeContext:
    def __init__(self):
        self.pages = []
        self.closed = False

    async def new_page(self):
        page = FakePage()
        page.context = self
        self.pages.append(page)
        return page

    async def close(self):
        self.closed = True


class FakeChromium:
    def __init__(self):
        self.launch_calls = []
        self.context = FakeContext()

    async def launch_persistent_context(self, **kwargs):
        self.launch_calls.append(kwargs)
        return self.context


class FakePlaywright:
    def __init__(self):
        self.chromium = FakeChromium()
        self.stopped = False

    async def stop(self):
        self.stopped = True


class FakePlaywrightManager:
    def __init__(self):
        self.playwright = FakePlaywright()
        self.started = False

    async def start(self):
        self.started = True
        return self.playwright


@pytest.mark.asyncio
async def test_browser_session_launches_persistent_chromium_profile(isolated_runtime_dir):
    manager = FakePlaywrightManager()
    session = browser.BrowserSession(
        headless=False,
        profile_name="agent",
        extra_args=["--disable-dev-shm-usage"],
        playwright_factory=lambda: manager,
    )

    await session.start()

    assert manager.started is True
    expected_profile = isolated_runtime_dir / "browser" / "agent"
    assert expected_profile.is_dir()
    assert manager.playwright.chromium.launch_calls == [
        {
            "user_data_dir": str(expected_profile),
            "headless": False,
            "viewport": browser.DEFAULT_VIEWPORT,
            "args": ["--disable-dev-shm-usage"],
        }
    ]

    await session.stop()
    assert manager.playwright.chromium.context.closed is True
    assert manager.playwright.stopped is True


@pytest.mark.asyncio
async def test_browser_session_reuses_current_page_for_navigation(isolated_runtime_dir):
    manager = FakePlaywrightManager()
    session = browser.BrowserSession(playwright_factory=lambda: manager)

    html = await session.content("https://example.com", wait_until="networkidle", timeout=12_345)
    text = await session.text_content(selector="main")

    page = manager.playwright.chromium.context.pages[-1]
    assert html == "<html><body>Hello</body></html>"
    assert text == "text for main"
    assert page.goto_calls == [
        {"url": "https://example.com", "wait_until": "networkidle", "timeout": 12_345}
    ]

    await session.stop()


@pytest.mark.asyncio
async def test_browser_session_screenshot_creates_parent_directory(tmp_path):
    manager = FakePlaywrightManager()
    session = browser.BrowserSession(playwright_factory=lambda: manager)
    screenshot_path = tmp_path / "nested" / "page.png"

    saved = await session.screenshot(str(screenshot_path), url="https://example.com")

    assert saved == str(screenshot_path)
    assert screenshot_path.read_bytes() == b"fake image"
    page = manager.playwright.chromium.context.pages[-1]
    assert page.screenshot_calls == [{"path": str(screenshot_path), "full_page": True}]

    await session.stop()


def test_browser_profile_dir_uses_runtime_browser_directory(isolated_runtime_dir):
    assert browser.browser_profile_dir("default") == str(isolated_runtime_dir / "browser" / "default")
    assert browser.ensure_browser_profile_dir("default") == str(isolated_runtime_dir / "browser" / "default")
    assert (isolated_runtime_dir / "browser" / "default").is_dir()


@pytest.mark.asyncio
async def test_browser_snapshot_formats_actionable_elements(isolated_runtime_dir):
    manager = FakePlaywrightManager()
    session = browser.BrowserSession(playwright_factory=lambda: manager)

    snapshot = await session.snapshot(max_elements=50, max_text_length=80)

    page = manager.playwright.chromium.context.pages[-1]
    assert page.evaluate_calls[0][1] == {
        "idAttr": browser.BROWSER_AGENT_ID_ATTR,
        "maxElements": 50,
        "maxTextLength": 80,
    }
    assert "Page: Fake page" in snapshot
    assert "URL: https://example.com" in snapshot
    assert '[1] link "Home" (href=https://example.com/home)' in snapshot
    assert '[2] input "Search" (placeholder="Query")' in snapshot


@pytest.mark.asyncio
async def test_browser_element_actions_target_snapshot_ids(isolated_runtime_dir):
    manager = FakePlaywrightManager()
    session = browser.BrowserSession(playwright_factory=lambda: manager)
    await session.start()
    page = await session.new_page()

    await session.click("7")
    await session.fill("8", "hello")
    selected = await session.select("9", "fr")
    await session.press("Enter", element_id="10")
    await session.press("Escape")

    assert selected == ["fr"]
    selectors = [locator.selector for locator in page.locators]
    assert selectors == [
        '[data-agent-browser-id="7"]',
        '[data-agent-browser-id="8"]',
        '[data-agent-browser-id="9"]',
        '[data-agent-browser-id="10"]',
    ]
    assert page.locators[0].click_calls == [{}]
    assert page.locators[1].fill_calls == [("hello", {})]
    assert page.locators[2].select_calls == [("fr", {})]
    assert page.locators[3].press_calls == [("Enter", {})]
    assert page.keyboard.press_calls == [("Escape", {})]

    await session.stop()


@pytest.mark.asyncio
async def test_browser_session_asks_chromium_for_active_page(isolated_runtime_dir):
    manager = FakePlaywrightManager()
    session = browser.BrowserSession(playwright_factory=lambda: manager)
    await session.start()

    stale_page = FakePage(visibility_state="hidden", has_focus=False)
    foreground_page = FakePage(visibility_state="visible", has_focus=True)
    manager.playwright.chromium.context.pages.extend([stale_page, foreground_page])
    session._active_page = stale_page

    current = await session.current_page()
    await session.click("7")
    snapshot = await session.snapshot()

    assert current is foreground_page
    assert session._active_page is foreground_page
    assert [locator.selector for locator in foreground_page.locators] == ['[data-agent-browser-id="7"]']
    assert stale_page.locators == []
    assert snapshot.startswith("Page: Fake page")

    await session.stop()


@pytest.mark.asyncio
async def test_browser_select_tab_status_respects_explicit_selection_when_focus_is_stale(isolated_runtime_dir):
    manager = FakePlaywrightManager()
    session = browser.BrowserSession(playwright_factory=lambda: manager)
    await session.start()

    old_active_page = FakePage(visibility_state="visible", has_focus=True)
    selected_page = FakePage(visibility_state="hidden", has_focus=False)
    for page in [selected_page, old_active_page]:
        page.context = manager.playwright.chromium.context
    manager.playwright.chromium.context.pages.extend([selected_page, old_active_page])
    session._active_page = old_active_page

    await session.select_tab(0)
    info = await session.tab_info()

    assert session._active_page is selected_page
    assert info[0]["active"] is True
    assert info[1]["active"] is False

    await session.stop()
