import json
import os

from codex_agent import Agent, SessionDeletedEvent, SessionLoadedEvent
from codex_agent.sessions import AgentSession, UNRESOLVED_TOOL_RESULT_CONTENT
from codex_agent.message import (
    AssistantMessage,
    DeveloperMessage,
    ProviderMessage,
    SystemMessage,
    ToolResultMessage,
    ToolResultWrapper,
    UserMessage,
)
import codex_agent.utils as utils


def test_response_input_payload_moves_leading_system_messages_to_instructions():
    agent = Agent(session="new")

    payload = agent.context_manager.response_input_token_payload([
        SystemMessage(content="Base rules."),
        SystemMessage(content="Extra rules."),
        DeveloperMessage(content="visible context"),
        SystemMessage(content="ignored late rules."),
    ])

    assert payload.instructions == "Base rules.\n\nExtra rules."
    assert payload.input == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "visible context"}],
    }]


def test_agent_session_as_string_concatenates_message_strings():
    assistant = AssistantMessage(content="I will inspect it.")
    assistant.tool_calls = [{
        "call_id": "call_1",
        "name": "read",
        "arguments": '{"path": "codex_agent/agent.py"}',
    }]
    session = AgentSession(messages=[
        ProviderMessage(name="cwd", content="/home/baptiste/dev/codex-agent"),
        assistant,
    ])

    text = session.as_string()

    assert "<ProviderMessage " in text
    assert "/home/baptiste/dev/codex-agent" in text
    assert "\n\n<AssistantMessage " in text
    assert "I will inspect it." in text
    assert "<tool_call type='function_call' name='read' call_id='call_1'>" in text
    assert '{"path": "codex_agent/agent.py"}' in text


def test_agent_session_response_history_closes_orphaned_tool_calls_before_user_message():
    assistant = AssistantMessage()
    assistant.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "bash",
        "input": "pytest",
    }]
    user = DeveloperMessage(content="resumed")
    session = AgentSession(messages=[assistant, user])

    history = session.messages_to_response_history(session.messages)

    assert history == [
        {
            "type": "custom_tool_call",
            "call_id": "call_1",
            "name": "bash",
            "input": "pytest",
        },
        {
            "type": "custom_tool_call_output",
            "call_id": "call_1",
            "output": "Tool call was interrupted before an output was recorded.",
        },
        {
            "type": "message",
            "role": "developer",
            "content": [{"type": "input_text", "text": "resumed"}],
        },
    ]


def test_agent_session_response_history_prunes_orphaned_tool_outputs():
    output = ToolResultMessage(
        name="observe",
        call_id="call_missing",
        content="success: full output in ImageMessage id=img_1.",
    )
    user = DeveloperMessage(content="resumed")
    session = AgentSession(messages=[output, user])
    session.save()

    removed = session.prune_orphaned_tool_outputs()
    history = session.messages_to_response_history(session.messages)

    assert removed == [output]
    assert session.messages == [user]
    assert history == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "resumed"}],
    }]
    with open(session.session_file, encoding="utf-8") as f:
        persisted = json.load(f)
    assert [message["id"] for message in persisted["messages"]] == [user.id]


def test_response_input_payload_skips_orphaned_tool_outputs():
    agent = Agent(session="new")

    payload = agent.context_manager.response_input_token_payload([
        ToolResultMessage(
            name="observe",
            call_id="call_missing",
            content="success: full output in ImageMessage id=img_1.",
        ),
        DeveloperMessage(content="resumed"),
    ])

    assert payload.input == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "resumed"}],
    }]


def test_agent_session_is_sane_accepts_api_valid_tool_sequence():
    assistant = AssistantMessage(content="I will call tools")
    assistant.tool_calls = [
        {
            "type": "function_call",
            "call_id": "call_read",
            "name": "read",
            "arguments": "{}",
        },
        {
            "type": "custom_tool_call",
            "call_id": "call_bash",
            "name": "bash",
            "input": "pytest",
        },
    ]
    session = AgentSession(messages=[
        SystemMessage(content="system"),
        DeveloperMessage(content="developer"),
        assistant,
        ToolResultMessage(name="read", call_id="call_read", content="ok"),
        ToolResultMessage(
            name="bash",
            call_id="call_bash",
            tool_call_type="custom_tool_call",
            content="ok",
        ),
        ToolResultWrapper(call_id="call_bash", content="stdout"),
        UserMessage(content="next"),
    ])

    assert session.is_sane() is True
    assert session.sanity_issues() == []


def test_agent_session_is_sane_rejects_system_messages_after_prefix():
    session = AgentSession(messages=[
        UserMessage(content="hello"),
        SystemMessage(content="late system"),
    ])

    assert session.is_sane() is False
    assert [issue.code for issue in session.sanity_issues()] == ["system_message_after_prefix"]


def test_agent_session_is_sane_rejects_orphaned_tool_results():
    session = AgentSession(messages=[
        ToolResultMessage(name="read", call_id="call_missing", content="ok"),
    ])

    assert session.is_sane() is False
    assert [issue.code for issue in session.sanity_issues()] == ["orphaned_tool_result"]


def test_agent_session_is_sane_rejects_unresolved_tool_calls():
    assistant = AssistantMessage(content="running")
    assistant.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_hung",
        "name": "bash",
        "input": "pytest",
    }]
    session = AgentSession(messages=[assistant, DeveloperMessage(content="resumed")])

    assert session.is_sane() is False
    assert [issue.code for issue in session.sanity_issues()] == ["unresolved_tool_calls_before_message"]


def test_agent_session_is_sane_rejects_tool_result_type_mismatch():
    assistant = AssistantMessage(content="running")
    assistant.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_bash",
        "name": "bash",
        "input": "pytest",
    }]
    session = AgentSession(messages=[
        assistant,
        ToolResultMessage(name="bash", call_id="call_bash", content="ok"),
    ])

    assert session.is_sane() is False
    assert [issue.code for issue in session.sanity_issues()] == ["tool_result_type_mismatch"]


def test_agent_get_context_repairs_persisted_orphaned_tool_outputs():
    agent = Agent(session="new")
    output = ToolResultMessage(
        name="observe",
        call_id="call_missing",
        content="success: full output in ImageMessage id=img_1.",
    )
    user = DeveloperMessage(content="resumed")
    agent.session.messages = [output, user]
    agent.save_session()

    context = agent.context_manager.get_context()

    assert output not in agent.session.messages
    assert user in agent.session.messages
    assert user.id in [message.id for message in context]
    with open(agent.session.session_file, encoding="utf-8") as f:
        persisted = json.load(f)
    assert [message["id"] for message in persisted["messages"]] == [user.id]


def test_agent_session_repair_synthesizes_interrupted_terminal_tool_result(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    stable = UserMessage(content="stable")
    assistant = AssistantMessage(content="running tests")
    assistant.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_hung",
        "name": "bash",
        "input": "pytest",
    }]
    session = AgentSession(messages=[stable, assistant])
    session.save()

    repair = session.repair()

    assert repair.repaired is True
    assert repair.removed == 0
    assert repair.added == 1
    assert os.path.isfile(repair.backup_file)
    assert session.messages[:2] == [stable, assistant]
    synthetic = session.messages[-1]
    assert isinstance(synthetic, ToolResultMessage)
    assert synthetic.call_id == "call_hung"
    assert synthetic.tool_call_type == "custom_tool_call"
    assert synthetic.content == UNRESOLVED_TOOL_RESULT_CONTENT
    assert session.is_sane() is True
    loaded = AgentSession.load(session.session_id).messages
    assert [msg.id for msg in loaded] == [msg.id for msg in session.messages]


def test_agent_session_repair_removes_late_system_and_orphaned_tool_result(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    system = SystemMessage(content="system")
    stable = UserMessage(content="stable")
    late_system = SystemMessage(content="late")
    orphan = ToolResultMessage(name="read", call_id="call_missing", content="ok")
    session = AgentSession(messages=[system, stable, late_system, orphan])
    session.save()

    repair = session.repair()

    assert repair.repaired is True
    assert repair.removed == 2
    assert session.messages == [system, stable]
    assert session.is_sane() is True
    assert os.path.isfile(repair.backup_file)


def test_agent_load_repairs_interrupted_tool_call_before_resume_message(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    stable = UserMessage(content="stable")
    assistant = AssistantMessage(content="running tests")
    assistant.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_hung",
        "name": "bash",
        "input": "pytest",
    }]
    stale_resume = DeveloperMessage(content="Resuming chat session after crash.")
    session = AgentSession(messages=[stable, assistant, stale_resume])
    session.save()

    agent = Agent(session=session.session_id)

    assert [msg.id for msg in agent.session.messages[:2]] == [stable.id, assistant.id]
    synthetic = agent.session.messages[2]
    assert isinstance(synthetic, ToolResultMessage)
    assert synthetic.call_id == "call_hung"
    assert synthetic.content == UNRESOLVED_TOOL_RESULT_CONTENT
    assert agent.session.messages[-1].content.startswith("Resuming chat session at ")
    with open(agent.session.session_file, encoding="utf-8") as f:
        persisted = json.load(f)
    assert [message["id"] for message in persisted["messages"][:2]] == [stable.id, assistant.id]
    backups = list((tmp_path / "sessions").glob(f"{session.session_id}.json.broken_*"))
    assert backups


def test_agent_emits_session_events():
    agent = Agent(session="new")
    seen = []

    agent.on(SessionLoadedEvent, lambda event: seen.append((event.type, event.session_id)))
    agent.on(SessionDeletedEvent, lambda event: seen.append((event.type, event.session_id)))

    session = agent.start_new_session()
    deleted_id = agent.delete_session(session.session_id)

    assert ("session_loaded_event", session.session_id) in seen
    assert ("session_deleted_event", deleted_id) in seen
