import json

import pytest

import codex_agent.utils as utils
from codex_agent import (
    Agent,
    SlashCommandDoneEvent,
    SlashCommandStartEvent,
    get_agent,
)
from codex_agent.sessions import AgentSession
from codex_agent.message import CompactionMessage, DeveloperMessage


def agent_result(agent, prompt):
    return agent(prompt).result


def test_slash_command_emits_start_and_done_events():
    agent = Agent(session="new")
    seen = []

    @agent.add_command
    def echo(value="ok"):
        return value

    agent.on(SlashCommandStartEvent, lambda event: seen.append((event.type, event.name, event.args, None)))
    agent.on(SlashCommandDoneEvent, lambda event: seen.append((event.type, event.name, event.args, event.status, event.result, event.error)))

    turn = agent.submit_command("/echo hello").wait()

    assert turn.result == "hello"
    assert seen == [
        ("slash_command_start_event", "echo", "hello", None),
        ("slash_command_done_event", "echo", "hello", "done", "hello", ""),
    ]
    assert [event.type for event in turn.events if event.type.startswith("slash_command_")] == [
        "slash_command_start_event",
        "slash_command_done_event",
    ]
    agent.stop()


def test_slash_command_emits_failed_done_event_on_error():
    agent = Agent(session="new")
    seen = []

    @agent.add_command
    def fail():
        raise RuntimeError("boom")

    agent.on(SlashCommandDoneEvent, lambda event: seen.append((event.name, event.status, event.error)))

    with pytest.raises(RuntimeError, match="boom"):
        agent.submit_command("/fail").wait()

    assert seen == [("fail", "failed", "boom")]
    agent.stop()


def test_slash_compact_accepts_compacted_turn_limit(monkeypatch):
    agent = Agent(session="new")
    calls = []

    def compact_session(model=None, instructions=None, max_compacted_turns=None):
        calls.append(max_compacted_turns)
        return CompactionMessage(compacted_message_count=3)

    monkeypatch.setattr(agent, "compact_session", compact_session)

    result = agent_result(agent, "/compact 1")

    assert calls == [1]
    assert result == "Compacted 3 messages from 1 compacted turn(s)."


def test_agent_add_command_decorator_handles_slash_command():
    agent = Agent(session="new")
    initial_count = len(agent.session.messages)

    @agent.add_command
    def echo(args):
        return f"echo:{args}:{get_agent().config.name}"

    result = agent_result(agent, "/echo hello")

    assert result == f"echo:hello:{agent.config.name}"
    assert len(agent.session.messages) == initial_count


def test_agent_command_can_be_registered_without_args():
    agent = Agent(session="new")

    @agent.add_command
    def ping():
        return "pong"

    assert agent_result(agent, "/ping") == "pong"


def test_agent_command_maps_parsed_arguments_to_signature():
    agent = Agent(session="new")

    @agent.add_command
    def greet(name, greeting="hello", loud=False):
        text = f"{greeting}, {name}"
        return text.upper() if loud else text

    assert agent_result(agent, '/greet Ada greeting=salut --loud') == "SALUT, ADA"


def test_agent_command_supports_varargs_and_kwargs():
    agent = Agent(session="new")

    @agent.add_command
    def collect(*items, **options):
        return f"items={list(items)!r}; options={options!r}"

    assert agent_result(agent, '/collect one "two words" mode=fast --dry-run') == (
        "items=['one', 'two words']; options={'mode': 'fast', 'dry_run': True}"
    )


def test_agent_loads_builtin_commands():
    agent = Agent(session="new")

    assert {"help", "compact", "config", "model", "reasoning", "verbosity", "voice"}.issubset(agent.commands)
    assert "/help" in agent_result(agent, "/help")
    assert "/compact" in agent_result(agent, "/help")


def test_builtin_model_config_commands_update_and_persist(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new")

    assert agent_result(agent, "/model gpt-test") == "Updated config: model='gpt-test'"
    assert agent.config.model == "gpt-test"
    assert json.loads((tmp_path / "agent.config.json").read_text())["model"] == "gpt-test"

    assert agent_result(agent, "/reasoning low") == "Updated config: reasoning=modict({'effort': 'low', 'summary': 'auto'})"
    assert agent_result(agent, "/verbosity high") == "Updated config: text=modict({'verbosity': 'high'})"
    assert agent.config.reasoning == {"effort": "low", "summary": "auto"}
    assert agent.config.text == {"verbosity": "high"}


def test_builtin_voice_command_shows_toggles_and_selects_voice(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new")

    assert agent_result(agent, "/voice") == "voice: off; voice='nova'"
    assert agent_result(agent, "/voice on") == "Updated tts config: enabled=True"
    assert agent.plugins.tts.config.enabled is True
    assert agent_result(agent, "/voice off") == "Updated tts config: enabled=False"
    assert agent.plugins.tts.config.enabled is False
    assert agent_result(agent, "/voice shimmer") == "Updated tts config: voice='shimmer', enabled=True"
    assert agent.plugins.tts.config.voice == "shimmer"
    assert agent.plugins.tts.config.enabled is True

    agent_saved = json.loads((tmp_path / "agent.config.json").read_text()) if (tmp_path / "agent.config.json").exists() else {}
    tts_saved = json.loads((tmp_path / "builtins" / "tts.config.json").read_text())
    assert tts_saved["voice"] == "shimmer"
    assert tts_saved["enabled"] is True
    assert "plugins" not in agent_saved
    assert "voice" not in agent_saved
    assert "voice_enabled" not in agent_saved


def test_builtin_config_command_shows_and_updates_multiple_model_fields(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new")

    display = agent_result(agent, "/config")
    assert "model:" in display
    assert "reasoning:" in display
    assert "text:" in display
    assert "parallel_tool_calls:" in display

    result = agent_result(agent, "/config model=gpt-next input_token_limit=64000 auto_compact=false")

    assert "model='gpt-next'" in result
    assert "input_token_limit=64000" in result
    assert "auto_compact=False" in result
    assert agent.config.model == "gpt-next"
    assert agent.config.input_token_limit == 64000
    assert agent.config.auto_compact is False


def test_builtin_config_command_rejects_unknown_keys():
    agent = Agent(session="new")

    try:
        agent_result(agent, "/config temperature=1")
    except ValueError as exc:
        assert "Unknown model config keys: temperature" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown config key")

    try:
        agent_result(agent, "/config auto_archive_memory=true")
    except ValueError as exc:
        assert "Unknown model config keys: auto_archive_memory" in str(exc)
    else:
        raise AssertionError("Expected ValueError for plugin-owned config key")


def test_builtin_session_commands_list_create_load_delete_and_navigate(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    first = AgentSession(session_id="20260101_100000", messages=[DeveloperMessage(content="first")])
    second = AgentSession(session_id="20260102_100000", messages=[DeveloperMessage(content="second")])
    first.save()
    second.save()

    agent = Agent(session="latest")

    listing = agent_result(agent, "/sessions")
    assert "* 20260102_100000" in listing
    assert "  20260101_100000" in listing

    assert agent_result(agent, "/previous_session") == "Loaded session: 20260101_100000"
    assert agent.current_session_id == "20260101_100000"
    assert agent_result(agent, "/next_session") == "Loaded session: 20260102_100000"

    assert agent_result(agent, "/load_session 20260101_100000") == "Loaded session: 20260101_100000"
    assert agent.current_session_id == "20260101_100000"

    created = agent_result(agent, "/new_session")
    assert created.startswith("Created session: ")
    assert " " not in agent.current_session_id

    assert agent_result(agent, "/delete_session 20260101_100000") == "Deleted session: 20260101_100000"
    assert "20260101_100000" not in agent.get_sessions()


def test_agent_loads_runtime_commands(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    commands_folder = tmp_path / "commands"
    commands_folder.mkdir()
    (commands_folder / "hello.py").write_text(
        "from codex_agent import command\n"
        "from codex_agent import get_agent\n\n"
        "@command(name='hello')\n"
        "def hello(args):\n"
        "    return get_agent().config.name + ':' + args\n",
        encoding="utf-8",
    )

    agent = Agent(session="new", name="Ada")

    assert agent_result(agent, "/hello world") == "Ada:world"


def test_unknown_command_raises_value_error():
    agent = Agent(session="new")

    try:
        agent_result(agent, "/missing")
    except ValueError as exc:
        assert "Unknown command: /missing" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown command")
