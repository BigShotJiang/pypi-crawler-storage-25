from codex_agent import service


def test_install_user_service_writes_server_and_tray_units(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(service, "run_systemctl", lambda *args, **kwargs: calls.append(args))

    path = service.install_user_service(host="127.0.0.2", port=9999, enable=True, start=True)

    tray_path = service.service_file_path(service.TRAY_SERVICE_NAME)
    assert path.name == service.SERVER_SERVICE_NAME
    assert tray_path.exists()
    server_text = path.read_text(encoding="utf-8")
    tray_text = tray_path.read_text(encoding="utf-8")
    assert "codex_agent start server --host 127.0.0.2 --port 9999 --foreground" in server_text
    assert "codex_agent start tray --url http://127.0.0.2:9999 --foreground" in tray_text
    assert "EnvironmentFile=-" in server_text
    assert "EnvironmentFile=-" in tray_text
    assert "Environment=PATH=" in server_text
    assert "Environment=PYTHON=" in server_text
    assert "Environment=PYTHON_EXECUTABLE=" in server_text
    assert "Environment=PATH=" in tray_text
    assert "Environment=PYTHON=" in tray_text
    assert "Environment=PYTHON_EXECUTABLE=" in tray_text
    assert "TimeoutStopSec=6" in server_text
    assert "WantedBy=graphical-session.target" in tray_text
    assert "PartOf=graphical-session.target" in tray_text
    assert "Wants=codex-agent.service" not in tray_text
    assert "After=graphical-session.target codex-agent.service" not in tray_text
    assert "--tray-backend" not in tray_text
    assert ("enable", service.SERVER_SERVICE_NAME) in calls
    assert ("reenable", service.TRAY_SERVICE_NAME) in calls
    assert ("restart", service.SERVER_SERVICE_NAME) in calls
    assert ("restart", service.TRAY_SERVICE_NAME) in calls


def test_uninstall_user_service_removes_server_and_tray_units(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(service, "run_systemctl", lambda *args, **kwargs: calls.append(args))
    service.service_file_path(service.SERVER_SERVICE_NAME).parent.mkdir(parents=True)
    service.service_file_path(service.SERVER_SERVICE_NAME).write_text("server", encoding="utf-8")
    service.service_file_path(service.TRAY_SERVICE_NAME).write_text("tray", encoding="utf-8")

    path = service.uninstall_user_service(disable=True, stop=True)

    assert path.name == service.SERVER_SERVICE_NAME
    assert not service.service_file_path(service.SERVER_SERVICE_NAME).exists()
    assert not service.service_file_path(service.TRAY_SERVICE_NAME).exists()
    assert ("stop", service.TRAY_SERVICE_NAME) in calls
    assert ("stop", service.SERVER_SERVICE_NAME) in calls
    assert ("disable", service.TRAY_SERVICE_NAME) in calls
    assert ("disable", service.SERVER_SERVICE_NAME) in calls


def test_restart_wakeup_file_roundtrip(monkeypatch, tmp_path):
    monkeypatch.setattr(service, "runtime_join", lambda name: str(tmp_path / name))
    payload = service.write_restart_wakeup("continue after restart", title="resume")
    assert payload == {"prompt": "continue after restart", "title": "resume"}
    path = tmp_path / service.RESTART_WAKEUP_FILE
    assert path.is_file()
    assert service.pop_restart_wakeup() == payload
    assert not path.exists()
    assert service.pop_restart_wakeup() is None


def test_restart_server_service_restarts_only_server_non_blocking(monkeypatch):
    calls = []
    monkeypatch.setattr(service, "run_systemctl", lambda *args, **kwargs: calls.append((args, kwargs)) or "ok")
    assert service.restart_server_service() == "ok"
    assert calls == [(("restart", "--no-block", service.SERVER_SERVICE_NAME), {"check": False})]


def test_restart_server_service_can_still_check_when_requested(monkeypatch):
    calls = []
    monkeypatch.setattr(service, "run_systemctl", lambda *args, **kwargs: calls.append((args, kwargs)) or "ok")
    assert service.restart_server_service(check=True) == "ok"
    assert calls == [(("restart", "--no-block", service.SERVER_SERVICE_NAME), {"check": True})]


def test_service_controller_selects_platform_backends():
    assert isinstance(service.service_controller("linux"), service.SystemdServiceController)
    assert isinstance(service.service_controller("darwin"), service.LaunchdServiceController)
    assert isinstance(service.service_controller("win32"), service.UnsupportedServiceController)


def test_launchd_service_controller_writes_plists(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(service, "runtime_join", lambda name: str(tmp_path / "runtime" / name))
    monkeypatch.setattr(
        service.subprocess,
        "run",
        lambda args, **kwargs: calls.append(args) or service.subprocess.CompletedProcess(args, 0, "", ""),
    )

    controller = service.LaunchdServiceController()
    path = controller.install(host="127.0.0.2", port=9999, enable=True, start=True)

    tray_path = service.launchd_file_path(service.TRAY_SERVICE_NAME)
    assert path.name == "dev.codex-agent.server.plist"
    assert tray_path.exists()
    assert b"codex_agent" in path.read_bytes()
    assert b"start" in path.read_bytes()
    assert b"server" in path.read_bytes()
    assert b"--foreground" in path.read_bytes()
    assert b"start" in tray_path.read_bytes()
    assert b"tray" in tray_path.read_bytes()
    assert b"--foreground" in tray_path.read_bytes()
    assert b"PYTHON_EXECUTABLE" in path.read_bytes()
    assert b"PATH" in path.read_bytes()
    assert b"PYTHON_EXECUTABLE" in tray_path.read_bytes()
    assert b"PATH" in tray_path.read_bytes()
    assert any(call[:2] == ["launchctl", "bootstrap"] for call in calls)
    assert any(call[:2] == ["launchctl", "kickstart"] for call in calls)
