import json
import threading

import pytest

from codex_agent import Agent
from codex_agent.message import AssistantMessage, ToolResultWrapper, UserMessage

pytestmark = pytest.mark.local_heavy


class FakeRealtimeSession:
    instances = []

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.ran = threading.Event()
        self.stopped = threading.Event()
        FakeRealtimeSession.instances.append(self)

    @property
    def session_id(self):
        return self.kwargs.get("session_id")

    def run(self):
        self.ran.set()
        self.kwargs["stop_event"].wait(timeout=1)

    def stop_now(self):
        self.stopped.set()
        self.kwargs["stop_event"].set()


def test_realtime_builtin_is_available_but_disabled_by_config():
    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[])

    info = agent.plugins_manager.plugin_info("realtime")

    assert info is not None
    assert info.enabled is False
    assert info.loaded is False
    assert "realtime" not in agent.plugins
    assert info.requirements_file.endswith("builtin_plugins/realtime/requirements.txt")
    assert "websocket-client" in info.requirements
    assert "sounddevice" in info.requirements
    assert info.loadable is True
    assert info.requires_openai is False


def test_realtime_plugin_loads_tools_commands_and_provider(monkeypatch):
    from codex_agent.builtin_plugins.realtime.manager import RealtimeManager

    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.setattr(RealtimeManager, "session_class", FakeRealtimeSession, raising=False)
    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[])

    loaded = agent.load_builtin_plugin("realtime")
    agent.plugins_manager.start()

    assert [plugin.name for plugin in loaded] == ["realtime"]
    assert "realtime" in agent.plugins
    assert "realtime" in agent.commands
    assert "realtime_start" in agent.tools
    assert "realtime_stop" in agent.tools
    assert "realtime_status" in agent.tools
    assert "realtime_status_monitor" in agent.providers
    assert "Realtime voice status" in agent.providers.realtime_status_monitor()
    assert "/realtime" in agent.config_manager.system_message().content or "Realtime voice mode" in agent.config_manager.system_message().content


def test_realtime_manager_start_stop_uses_mocked_session(monkeypatch):
    from codex_agent import RealtimeStartedEvent, RealtimeStartingEvent, RealtimeStoppedEvent
    from codex_agent.builtin_plugins.realtime.manager import RealtimeManager

    FakeRealtimeSession.instances = []
    monkeypatch.setattr(RealtimeManager, "session_class", FakeRealtimeSession, raising=False)
    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[], openai_api_key="test-key")
    agent.load_builtin_plugin("realtime")
    agent.plugins_manager.start()
    seen = []
    agent.on(RealtimeStartingEvent, lambda event: seen.append((event.type, event.session_id, event.audio_enabled)))
    agent.on(RealtimeStartedEvent, lambda event: seen.append((event.type, event.session_id, event.audio_enabled)))
    agent.on(RealtimeStoppedEvent, lambda event: seen.append((event.type, event.session_id, event.reason)))

    started = agent.tools.realtime_start(text="hello", audio=False, close_after_response=True)
    assert started.status == "started"
    assert started.active is True
    assert started.state == "active"
    instance = FakeRealtimeSession.instances[-1]
    assert instance.ran.wait(timeout=1)
    assert instance.kwargs["text_input"] == "hello"
    assert instance.kwargs["audio_io"] is None
    assert instance.kwargs["close_after_response"] is True

    stopped = agent.tools.realtime_stop()
    assert stopped.status == "stopped"
    assert stopped.active is False
    assert instance.stopped.is_set()
    assert seen[0] == ("realtime_starting_event", started.session_id, False)
    assert seen[1] == ("realtime_started_event", started.session_id, False)
    assert seen.count(("realtime_stopped_event", started.session_id, "requested")) == 1


def test_realtime_interrupt_stops_active_session(monkeypatch):
    from codex_agent.builtin_plugins.realtime.manager import RealtimeManager

    FakeRealtimeSession.instances = []
    monkeypatch.setattr(RealtimeManager, "session_class", FakeRealtimeSession, raising=False)
    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[], openai_api_key="test-key")
    agent.load_builtin_plugin("realtime")
    agent.plugins_manager.start()
    agent.tools.realtime_start(audio=False)
    instance = FakeRealtimeSession.instances[-1]
    assert instance.ran.wait(timeout=1)

    agent.interrupt("test")

    assert instance.stopped.wait(timeout=1)
    assert agent.tools.realtime_status().active is False


def test_realtime_manager_rejects_unknown_audio_backend(monkeypatch):
    from codex_agent import RealtimeErrorEvent, RealtimeStoppedEvent
    from codex_agent.builtin_plugins.realtime.manager import RealtimeManager

    FakeRealtimeSession.instances = []
    monkeypatch.setattr(RealtimeManager, "session_class", FakeRealtimeSession, raising=False)
    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[], openai_api_key="test-key")
    agent.load_builtin_plugin("realtime")
    agent.plugins_manager.start()
    agent.plugins.realtime.config.audio_backend = "wat"
    seen = []
    agent.on(RealtimeErrorEvent, lambda event: seen.append((event.type, event.error)))
    agent.on(RealtimeStoppedEvent, lambda event: seen.append((event.type, event.reason)))

    result = agent.tools.realtime_start(audio=True)

    assert result.status == "error"
    assert result.active is False
    assert "Unsupported realtime audio backend" in result.last_error
    assert any(item[0] == "realtime_error_event" and "Unsupported realtime audio backend" in item[1] for item in seen)
    assert not any(item[0] == "realtime_stopped_event" for item in seen)


class FakeRealtimeSocket:
    def __init__(self):
        self.sent = []

    def send(self, payload):
        self.sent.append(json.loads(payload))

    def close(self):
        pass


def test_realtime_session_initial_events_include_dynamic_provider_snapshot():
    from codex_agent.builtin_plugins.realtime.bridge import RealtimeAgentBridge
    from codex_agent.builtin_plugins.realtime.session import HeadlessRealtimeSession

    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[], openai_api_key="test-key")

    @agent.add_provider
    def realtime_snapshot_provider():
        return "dynamic snapshot value"

    bridge = RealtimeAgentBridge(agent, include_context=False)
    session = HeadlessRealtimeSession(
        client=object(),
        model="gpt-realtime-1.5",
        voice="marin",
        instructions="",
        session_id="rt_initial",
        agent_bridge=bridge,
    )

    events = session.initial_events()

    assert events[0]["type"] == "session.update"
    assert any("dynamic snapshot value" in event["item"]["content"][0]["text"] for event in events if event.get("type") == "conversation.item.create")


def test_realtime_session_refreshes_live_on_runtime_state_change(monkeypatch):
    from codex_agent import RealtimeSessionRefreshEvent
    from codex_agent.builtin_plugins.realtime.bridge import RealtimeAgentBridge
    from codex_agent.builtin_plugins.realtime.session import HeadlessRealtimeSession

    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[], openai_api_key="test-key")
    bridge = RealtimeAgentBridge(agent, include_context=False)
    session = HeadlessRealtimeSession(
        client=object(),
        model="gpt-realtime-1.5",
        voice="marin",
        instructions="",
        session_id="rt_test",
        agent_bridge=bridge,
    )
    socket = FakeRealtimeSocket()
    connected = threading.Event()
    connected.set()
    session._socket = socket
    session._connected = connected
    seen = []
    agent.on(RealtimeSessionRefreshEvent, lambda event: seen.append(event))
    unbind = bridge.bind_agent_events(
        lambda event: socket.send(json.dumps(event)),
        refresh_session=lambda event: session.send_refresh(reason=event.reason, debounce_seconds=0),
    )

    try:
        @agent.add_tool
        def live_ping(value: str = "ok"):
            """
            description: Live refresh test tool.
            parameters:
              value:
                type: string
            required: []
            """
            return value
    finally:
        unbind()

    updates = [event for event in socket.sent if event.get("type") == "session.update"]
    assert updates
    assert {tool["name"] for tool in updates[-1]["session"]["tools"]} >= {"live_ping"}
    assert seen
    assert seen[-1].type == "realtime_session_refresh_event"
    assert seen[-1].session_id == "rt_test"
    assert seen[-1].reason == "tool_added"


def test_realtime_bridge_builds_session_tools_and_syncs_transcripts(monkeypatch):
    from codex_agent.builtin_plugins.realtime.bridge import RealtimeAgentBridge

    agent = Agent(session="new", builtin_plugins=[], custom_plugins=[], openai_api_key="test-key")
    agent.load_builtin_plugin("realtime")
    agent.plugins_manager.start()

    @agent.add_tool
    def ping(value: str = "ok"):
        """
        description: Ping test tool.
        parameters:
          value:
            type: string
        required: []
        """
        return {"pong": value}

    bridge = RealtimeAgentBridge(agent, include_context=False)
    session = bridge.build_session(model="gpt-realtime-1.5", voice="marin")

    assert session["type"] == "realtime"
    assert session["model"] == "gpt-realtime-1.5"
    tool_names = {tool["name"] for tool in session["tools"]}
    assert "ping" in tool_names
    assert "web_search" not in tool_names

    result = bridge.handle_event({
        "type": "response.function_call_arguments.done",
        "name": "ping",
        "call_id": "call_rt",
        "arguments": '{"value":"hi"}',
    })
    assert result is not None
    assert result.client_events()[0]["item"]["output"] == '{"pong": "hi"}'
    assert any(isinstance(message, ToolResultWrapper) and message.call_id == "call_rt" for message in agent.session.messages)

    bridge.handle_sync_event({
        "type": "conversation.item.input_audio_transcription.completed",
        "item_id": "item_user",
        "transcript": "bonjour",
    })
    bridge.handle_sync_event({
        "type": "response.output_audio_transcript.done",
        "item_id": "item_assistant",
        "transcript": "salut",
    })

    assert isinstance(agent.session.messages[-2], UserMessage)
    assert agent.session.messages[-2].content == "bonjour"
    assert "realtime" in agent.session.messages[-2].tags
    assert isinstance(agent.session.messages[-1], AssistantMessage)
    assert agent.session.messages[-1].content == "salut"
    assert "realtime" in agent.session.messages[-1].tags
