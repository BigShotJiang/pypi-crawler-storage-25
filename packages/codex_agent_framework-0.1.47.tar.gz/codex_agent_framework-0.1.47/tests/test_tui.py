import signal
from codex_agent.tui import lifecycle as tui


def test_install_tui_cleanup_handlers_clears_registered_pid_on_signal(monkeypatch):
    calls = []
    handlers = {}
    previous_handlers = {}

    def fake_getsignal(signum):
        return previous_handlers.get(signum, signal.SIG_IGN)

    def fake_signal(signum, handler):
        handlers[signum] = handler

    monkeypatch.setattr(tui.atexit, "register", lambda func, **kwargs: calls.append(("atexit", func, kwargs)))
    monkeypatch.setattr(tui.signal, "getsignal", fake_getsignal)
    monkeypatch.setattr(tui.signal, "signal", fake_signal)
    monkeypatch.setattr(tui, "clear_tui", lambda pid=None: calls.append(("clear", pid)))

    tui.install_tui_cleanup_handlers(pid=1234)
    handlers[signal.SIGHUP](signal.SIGHUP, None)

    assert calls == [
        ("atexit", tui.clear_tui, {"pid": 1234}),
        ("clear", 1234),
    ]
    assert set(handlers) == {signal.SIGTERM, signal.SIGHUP, signal.SIGINT}


def test_install_tui_cleanup_handlers_skips_signals_outside_main_thread(monkeypatch):
    calls = []
    worker_thread = object()

    monkeypatch.setattr(tui.atexit, "register", lambda func, **kwargs: calls.append(("atexit", kwargs)))
    monkeypatch.setattr(tui.threading, "current_thread", lambda: worker_thread)
    monkeypatch.setattr(
        tui.signal,
        "signal",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("signal should not be installed")),
    )

    assert tui.install_tui_cleanup_handlers(pid=1234) is False
    assert calls == [("atexit", {"pid": 1234})]


def test_current_tui_clears_stale_pid(monkeypatch):
    calls = []
    data = {"pid": 9999}

    monkeypatch.setattr(tui.os.path, "isfile", lambda path: True)
    monkeypatch.setattr(tui.modict, "load", lambda path: data)
    monkeypatch.setattr(tui, "pid_alive", lambda pid: False)
    monkeypatch.setattr(tui, "clear_tui", lambda pid=None: calls.append(pid))

    assert tui.current_tui() is None
    assert calls == [None]


def test_terminal_command_candidates_include_macos_terminal(monkeypatch):
    monkeypatch.setattr(tui.sys, "platform", "darwin")
    commands = list(tui.terminal_command_candidates("codex-agent chat"))

    assert commands == [["osascript", "-e", 'tell application "Terminal" to do script "codex-agent chat"']]


def test_terminal_command_candidates_include_windows_terminals(monkeypatch):
    monkeypatch.setattr(tui.sys, "platform", "win32")
    commands = list(tui.terminal_command_candidates("codex-agent chat"))

    assert commands[0][:2] == ["wt.exe", "powershell"]
    assert commands[1][:2] == ["powershell", "-NoExit"]
    assert commands[2][:3] == ["cmd", "/c", "start"]


def test_tui_shell_command_exports_runtime_dir(monkeypatch, tmp_path):
    runtime_dir = tmp_path / "runtime"
    monkeypatch.setenv("AGENT_RUNTIME_DIR", str(runtime_dir))

    command = tui.tui_shell_command(base_url="http://agent.local/")

    assert f"AGENT_RUNTIME_DIR={runtime_dir}" in command
    assert "PYTHON_EXECUTABLE=" in command
    assert " exec " in command
    assert "--url http://agent.local" in command


def test_tui_terminal_env_drops_snap_gtk_loader_state(monkeypatch, tmp_path):
    runtime_dir = tmp_path / "runtime"
    monkeypatch.setenv("AGENT_RUNTIME_DIR", str(runtime_dir))
    monkeypatch.setenv("SNAP", "/snap/code/current")
    monkeypatch.setenv("SNAP_NAME", "code")
    monkeypatch.setenv("GTK_PATH", "/snap/code/current/usr/lib/gtk-3.0")
    monkeypatch.setenv("GIO_MODULE_DIR", "/home/user/snap/code/common/.cache/gio-modules")
    monkeypatch.setenv("LD_LIBRARY_PATH", "/snap/core20/current/lib")
    monkeypatch.setenv("XDG_DATA_DIRS", "/snap/code/current/usr/share:/usr/share")
    monkeypatch.setenv("XDG_DATA_DIRS_VSCODE_SNAP_ORIG", "/usr/share/ubuntu:/usr/share")

    env = tui.tui_terminal_env()

    assert env["AGENT_RUNTIME_DIR"] == str(runtime_dir)
    assert "SNAP" not in env
    assert "SNAP_NAME" not in env
    assert "GTK_PATH" not in env
    assert "GIO_MODULE_DIR" not in env
    assert "LD_LIBRARY_PATH" not in env
    assert env["XDG_DATA_DIRS"] == "/usr/share/ubuntu:/usr/share"


def test_linux_terminal_wrappers_do_not_prepend_exec(monkeypatch):
    monkeypatch.setattr(tui.sys, "platform", "linux")
    monkeypatch.delenv("TERMINAL", raising=False)

    commands = list(tui.terminal_command_candidates("AGENT_RUNTIME_DIR=/tmp/runtime exec python -m codex_agent chat"))

    assert commands[0][-1].startswith("AGENT_RUNTIME_DIR=")
    assert not commands[0][-1].startswith("exec AGENT_RUNTIME_DIR=")


def test_open_tui_terminal_passes_runtime_env_to_terminal(monkeypatch, tmp_path):
    calls = []
    runtime_dir = tmp_path / "runtime"
    monkeypatch.setenv("AGENT_RUNTIME_DIR", str(runtime_dir))
    monkeypatch.setattr(tui, "terminal_command_candidates", lambda shell_command: [["terminal", shell_command]])

    class Process:
        pass

    def fake_popen(command, **kwargs):
        calls.append((command, kwargs))
        return Process()

    monkeypatch.setattr(tui.subprocess, "Popen", fake_popen)

    assert isinstance(tui.open_tui_terminal(base_url="http://agent.local"), Process)
    command, kwargs = calls[0]
    assert command[0] == "terminal"
    assert str(runtime_dir) in command[1]
    assert kwargs["env"]["AGENT_RUNTIME_DIR"] == str(runtime_dir)


def test_terminal_process_kwargs_are_platform_aware(monkeypatch):
    monkeypatch.setattr(tui.os, "name", "posix")
    assert tui.terminal_process_kwargs()["start_new_session"] is True

    monkeypatch.setattr(tui.os, "name", "nt")
    monkeypatch.setattr(tui.subprocess, "CREATE_NEW_PROCESS_GROUP", 512, raising=False)
    assert tui.terminal_process_kwargs()["creationflags"] == 512
