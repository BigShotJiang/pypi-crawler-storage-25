import os
import queue
import threading

from fastapi.testclient import TestClient
from modict import modict

import codex_agent.server.core as server_core
from codex_agent import Agent, AgentSession, DeveloperMessage, UserMessage
from codex_agent.agent_runtime import AgentRuntimeError, InProcessAgentRuntime, ProcessAgentRuntime
from codex_agent.event import AssistantTurnEndEvent, AssistantTurnStartEvent, AssistantStepStartEvent, AudioPlaybackEvent, ResponseContentDeltaEvent
from codex_agent.server import AgentServer, create_app, load_server_config, save_server_config, server_config_file, server_events_file


def test_agent_server_publishes_agent_events():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    agent.emit(AssistantStepStartEvent)

    assert service.events[-1]["type"] == "assistant_step_start_event"
    assert "id" in service.events[-1]


def test_agent_server_wildcard_listener_does_not_replace_agent_audio_handler():
    agent = Agent(session="new")
    AgentServer(InProcessAgentRuntime(agent))

    assert agent.events.has_handlers(AudioPlaybackEvent)
    assert agent.events.has_handlers(AudioPlaybackEvent, include_wildcard=False)


def test_agent_server_keeps_slow_subscribers_attached():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    stream = service.subscribe()

    next(stream)
    for index in range(150):
        service.publish(modict(type="response_content_delta_event", delta=str(index)))

    received = [next(stream).delta for _ in range(150)]

    assert received[0] == "0"
    assert received[-1] == "149"
    assert len(service.subscribers) == 1
    stream.close()
    assert len(service.subscribers) == 0


def test_agent_server_refuses_second_event_subscriber(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: modict(pid=1234))
    stream = service.subscribe()

    next(stream)
    try:
        try:
            service.subscribe()
        except RuntimeError as exc:
            assert str(exc) == "an event client is already connected"
        else:
            raise AssertionError("Expected second subscriber to be refused")
    finally:
        stream.close()


def test_agent_server_publishes_response_delta_payloads_directly():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    agent.emit(
        ResponseContentDeltaEvent,
        delta="hello",
    )

    payload = service.events[-1]

    assert payload.type == "response_content_delta_event"
    assert payload.delta == "hello"
    assert payload.session_id == agent.current_session_id
    assert payload.types == ["event", "response_content_delta_event"]
    assert set(payload) == {"types", "type", "timestamp", "delta", "id", "sequence", "session_id"}


def test_agent_server_start_turn_runs_agent_in_background(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    calls = []

    def fake_start_turn():
        calls.append(list(agent.mainloop_manager.pending))
        agent.emit(AssistantTurnStartEvent, prompt=None)
        agent.emit(AssistantTurnEndEvent, prompt=None, reason="completed")
        return modict(id="turn_1")

    monkeypatch.setattr(agent.mainloop_manager, "start_turn", fake_start_turn)

    result = service.submit_prompt("hello")

    assert result.queued is False
    assert result.turn_id == "turn_1"
    assert result.pending_message_id == calls[0][0].id
    assert calls[0][0].content == "hello"
    message_events = [event for event in service.events if event.type == "message_added_event"]
    assert not any(event.message.id == result.pending_message_id for event in message_events)
    submitted_events = [event for event in service.events if event.type == "message_submitted_event"]
    assert submitted_events[-1].message.id == result.pending_message_id
    assert submitted_events[-1].message.content == "hello"
    assert submitted_events[-1].turn_id == result.turn_id
    assert service.busy is False
    assert any(event.type == "assistant_turn_start_event" for event in service.events)
    assert any(event.type == "assistant_turn_end_event" for event in service.events)


def test_agent_server_routes_slash_commands_through_command_turn(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    calls = []

    @agent.add_command
    def ping():
        calls.append("ping")
        return "pong"

    result = service.submit_prompt("/ping")
    future = agent.mainloop_manager.futures[result.turn_id]

    assert result.command is True
    assert result.queued is False
    assert future.wait(timeout=1.0).result == "pong"
    assert calls == ["ping"]
    assert not any(message.content == "/ping" for message in agent.mainloop_manager.pending)
    agent.stop(timeout=1.0)


def test_agent_server_replays_latest_turn_from_backlog():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    agent.emit(AssistantTurnStartEvent, prompt="first")
    agent.emit(AssistantTurnEndEvent, prompt="first", reason="completed")
    agent.emit(AssistantTurnStartEvent, prompt="second")
    agent.emit(ResponseContentDeltaEvent, delta="streaming")

    replay = service.replay_events()

    assert [event.type for event in replay.events] == [
        "assistant_turn_start_event",
        "response_content_delta_event",
    ]
    assert replay.events[0].prompt == "second"
    assert replay.events[1].delta == "streaming"


def test_agent_server_replays_previous_completed_turn_while_idle():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    agent.emit(AssistantTurnStartEvent, prompt="previous")
    agent.emit(ResponseContentDeltaEvent, delta="done")
    agent.emit(AssistantTurnEndEvent, prompt="previous", reason="completed")

    replay = service.replay_events()

    assert [event.type for event in replay.events] == [
        "assistant_turn_start_event",
        "response_content_delta_event",
        "assistant_turn_end_event",
    ]
    assert replay.events[0].prompt == "previous"


def test_agent_server_replay_respects_subscription_cursor():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    agent.emit(AssistantTurnStartEvent, prompt="hello")
    stream = service.subscribe()
    subscribed = next(stream)
    agent.emit(ResponseContentDeltaEvent, delta="after subscribe")

    replay = service.replay_events(before_sequence=subscribed.replay_before_sequence)

    assert [event.type for event in replay.events] == ["assistant_turn_start_event"]
    assert replay.events[0].prompt == "hello"
    stream.close()


def test_agent_server_replay_is_scoped_to_requested_session():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    agent.emit(AssistantTurnStartEvent, prompt="current")
    agent.emit(ResponseContentDeltaEvent, delta="belongs here")

    replay = service.replay_events(session_id="other_session")

    assert replay.events == []


def test_agent_server_queues_concurrent_turn_prompt_as_pending_message():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    agent.mainloop_manager.futures["running"] = modict(id="running", command="turn", status="running")

    result = service.submit_prompt("two")

    assert result.queued is True
    assert result.turn_id == "running"
    assert result.pending_message_id == agent.mainloop_manager.pending[-1].id
    assert isinstance(agent.mainloop_manager.pending[-1], UserMessage)
    assert agent.mainloop_manager.pending[-1].content == "two"
    assert agent.session.messages[-1].content != "two"


def test_create_app_exposes_health_status_and_interrupt():
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app)

    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["ok"] is True
    assert health.json()["session_id"] == agent.current_session_id

    status = client.get("/status")
    assert status.status_code == 200
    assert status.json()["session_id"] == agent.current_session_id
    assert status.json()["busy"] is False

    interrupt = client.post("/interrupt", json={"reason": "test"})
    assert interrupt.status_code == 200
    assert interrupt.json() == {"interrupted": True}


def test_agent_server_status_marks_busy_turn_stale_after_quiet_event_stream():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    agent.status_manager.wham_status_loaded = True
    agent.mainloop_manager.futures["running"] = modict(id="running", command="turn", status="running")
    old_time = server_core.time.time() - 121.5
    old_timestamp = server_core.time.strftime("%Y%m%dT%H%M%S.000", server_core.time.localtime(old_time))
    service.publish(modict(type="assistant_turn_start_event", timestamp=old_timestamp))

    status = service.status()

    assert status.busy is True
    assert status.event_stream.active is True
    assert status.event_stream.last_event_type == "assistant_turn_start_event"
    assert status.event_stream.idle_seconds > 120
    assert status.event_stream.stale is True


def test_create_app_interrupt_returns_200_when_runtime_interrupt_fails(monkeypatch):
    agent = Agent(session="new")
    monkeypatch.setattr(agent, "interrupt", lambda reason="api": (_ for _ in ()).throw(RuntimeError("interrupt transport failed")))
    app = create_app(agent=agent)
    client = TestClient(app)

    response = client.post("/interrupt", json={"reason": "test"})

    assert response.status_code == 200
    assert response.json()["interrupted"] is False
    assert response.json()["interrupt_requested"] is True
    assert "interrupt transport failed" in response.json()["error"]


def test_create_app_queues_turn_prompt_while_busy():
    agent = Agent(session="new")
    agent.mainloop_manager.futures["running"] = modict(id="running", command="turn", status="running")
    app = create_app(agent=agent)
    client = TestClient(app)

    response = client.post("/turns", json={"prompt": "more context"})

    assert response.status_code == 202
    payload = response.json()
    assert payload["accepted"] is True
    assert payload["queued"] is True
    assert payload["turn_id"] == "running"
    assert payload["pending_message_id"] == agent.mainloop_manager.pending[-1].id
    assert agent.mainloop_manager.pending[-1].content == "more context"


def test_create_app_routes_slash_commands_through_command_turn():
    agent = Agent(session="new")
    calls = []

    @agent.add_command
    def ping():
        calls.append("ping")
        return "pong"

    app = create_app(agent=agent)
    client = TestClient(app)

    response = client.post("/turns", json={"prompt": "/ping"})

    assert response.status_code == 202
    payload = response.json()
    assert payload["accepted"] is True
    assert payload["command"] is True
    assert agent.mainloop_manager.futures[payload["turn_id"]].wait(timeout=1.0).result == "pong"
    assert calls == ["ping"]
    agent.stop(timeout=1.0)


def test_create_app_exposes_agent_objects_as_payloads():
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app)

    session = client.get("/session")
    assert session.status_code == 200
    assert session.json()["session_id"] == agent.current_session_id
    assert isinstance(session.json()["messages"], list)

    messages = client.get("/messages")
    assert messages.status_code == 200
    assert messages.json()[-1]["type"] == agent.session.messages[-1].type

    tools = client.get("/tools")
    assert tools.status_code == 200
    assert "read" in tools.json()
    assert tools.json()["read"]["type"] == "tool"
    assert tools.json()["read"]["tool_type"] == "function"
    assert tools.json()["image_generation"]["type"] == "image_generation"


def test_agent_server_open_tui_returns_registered_client(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    tui = modict(pid=4321, base_url="http://agent.local")

    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: tui)
    monkeypatch.setattr(
        "codex_agent.server.core.open_tui_terminal",
        lambda **kwargs: (_ for _ in ()).throw(AssertionError("terminal should not be opened")),
    )

    result = service.open_tui(base_url="http://agent.local")

    assert result.already_open is True
    assert result.tui.pid == 4321


def test_agent_server_open_tui_launches_terminal_when_no_client(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    class Process:
        pid = 9876

    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: None)
    monkeypatch.setattr("codex_agent.server.core.open_tui_terminal", lambda base_url: Process())

    result = service.open_tui(base_url="http://agent.local")

    assert result.opened is True
    assert result.terminal_pid == 9876
    assert result.base_url == "http://agent.local"


def test_agent_server_close_tui_terminates_registered_pid(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    calls = []

    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: modict(pid=2468))
    monkeypatch.setattr("codex_agent.server.core.terminate_tui", lambda pid: calls.append(("terminate", pid)))
    monkeypatch.setattr("codex_agent.server.core.clear_tui", lambda pid=None: calls.append(("clear", pid)))

    result = service.close_tui()

    assert result == {"closed": True, "pid": 2468}
    assert calls == [("terminate", 2468), ("clear", 2468)]


def test_create_app_open_tui_endpoint_uses_request_base_url(monkeypatch):
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app, base_url="http://agent.local")
    service = app.state.agent_service
    calls = []

    monkeypatch.setattr(service, "open_tui", lambda base_url: calls.append(base_url) or modict(opened=True))

    response = client.post("/tui/open")

    assert response.status_code == 200
    assert calls == ["http://agent.local"]


def test_create_app_sse_stream_starts_with_subscription_event():
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app)

    with client.stream("GET", "/events?limit=1") as response:
        assert response.status_code == 200
        lines = response.iter_lines()
        first_line = next(lines)
        assert first_line.startswith("id: ")
        event_line = next(lines)
        assert event_line == "event: server_subscribed"
        data_line = next(lines)
        assert "server_subscribed" in data_line
        assert "replay_before_sequence" in data_line
        response.close()


def test_create_app_exposes_event_replay_endpoint():
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app)

    agent.emit(AssistantTurnStartEvent, prompt="hello")
    agent.emit(ResponseContentDeltaEvent, delta="hi")

    response = client.get("/events/replay")

    assert response.status_code == 200
    payload = response.json()
    assert [event["type"] for event in payload["events"]] == [
        "assistant_turn_start_event",
        "response_content_delta_event",
    ]


def test_agent_server_refuses_second_subscriber_when_tui_is_registered(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    service.subscribers[queue.Queue()] = modict(thread=threading.current_thread())
    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: modict(pid=1234))

    try:
        try:
            service.subscribe()
        except RuntimeError as exc:
            assert str(exc) == "an event client is already connected"
        else:
            raise AssertionError("Expected second subscriber to be refused")
    finally:
        service.subscribers.clear()


def test_agent_server_replaces_stale_subscriber_for_same_tui_pid(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    service.subscribers[queue.Queue()] = modict(thread=threading.current_thread(), client_pid=1234)
    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: modict(pid=1234))

    stream = service.subscribe(client_pid=1234)
    try:
        assert next(stream).type == "server_subscribed"
        assert len(service.subscribers) == 1
        assert next(iter(service.subscribers.values())).client_pid == 1234
    finally:
        stream.close()


def test_agent_server_replaces_stale_subscriber_when_no_tui_is_registered(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    service.subscribers[queue.Queue()] = modict(thread=threading.current_thread())
    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: None)

    stream = service.subscribe()
    try:
        assert next(stream).type == "server_subscribed"
        assert len(service.subscribers) == 1
    finally:
        stream.close()


def test_agent_server_notifies_replaced_subscriber_before_removing_it(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    old_subscriber = queue.Queue()
    service.subscribers[old_subscriber] = modict(thread=threading.current_thread(), client_pid=1234)
    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: modict(pid=1234))

    stream = service.subscribe(client_pid=1234)
    try:
        shutdown = old_subscriber.get_nowait()
        assert shutdown.type == "server_shutdown"
        assert shutdown.reason == "subscription replaced"
        assert next(stream).type == "server_subscribed"
        assert old_subscriber not in service.subscribers
    finally:
        stream.close()


def test_create_app_refuses_second_sse_client(monkeypatch):
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app)
    service = app.state.agent_service
    service.subscribers[queue.Queue()] = modict(thread=threading.current_thread())
    monkeypatch.setattr("codex_agent.server.core.current_tui", lambda: modict(pid=1234))

    try:
        second = client.get("/events?limit=1")
        assert second.status_code == 409
        assert second.json()["detail"] == "an event client is already connected"
    finally:
        service.subscribers.clear()


def test_agent_server_prunes_dead_event_subscribers():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    class DeadThread:
        def is_alive(self):
            return False

    service.subscribers[queue.Queue()] = modict(thread=DeadThread())

    stream = service.subscribe()
    try:
        assert next(stream).type == "server_subscribed"
        assert len(service.subscribers) == 1
    finally:
        stream.close()


def test_agent_server_stop_closes_event_streams(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    monkeypatch.setattr(agent, "stop", lambda timeout=None: agent)
    stream = service.subscribe()

    assert next(stream).type == "server_subscribed"
    service.stop(timeout=0.1)
    shutdown = next(stream)

    assert shutdown.type == "server_shutdown"
    assert shutdown.reason == "server shutdown"
    try:
        next(stream)
    except StopIteration:
        pass
    else:
        raise AssertionError("Expected SSE stream to stop after server_shutdown")
    assert len(service.subscribers) == 0


def test_create_app_sse_ping_has_no_null_id_line():
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app)

    with client.stream("GET", "/events?limit=2") as response:
        assert response.status_code == 200
        text = "".join(response.iter_text())
        assert "id: None" not in text
        assert "event: server_ping" in text
        response.close()


def test_agent_server_consumes_restart_wakeup(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    monkeypatch.setattr(
        "codex_agent.server.core.pop_restart_wakeup",
        lambda: {"prompt": "continue work", "title": "resume"},
    )
    calls = []
    def fake_start_turn():
        calls.extend(agent.mainloop_manager.pending)
        return modict(id="future_1")
    monkeypatch.setattr(agent.mainloop_manager, "start_turn", fake_start_turn)
    result = service.consume_restart_wakeup()
    assert result.triggered is True
    assert result.future_id == "future_1"
    assert isinstance(calls[0], DeveloperMessage)
    assert "Post-restart wakeup (resume)" in calls[0].content
    assert "continue work" in calls[0].content


def test_agent_server_restart_persists_wakeup_and_restarts_service(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    calls = []
    monkeypatch.setattr("codex_agent.server.core.write_restart_wakeup", lambda **kwargs: calls.append(("wakeup", kwargs)))
    monkeypatch.setattr("codex_agent.server.core.time.sleep", lambda delay: calls.append(("sleep", delay)))
    monkeypatch.setattr("codex_agent.server.core.restart_server_service", lambda: calls.append(("restart",)))
    class ImmediateThread:
        def __init__(self, target, **kwargs):
            self.target = target
        def start(self):
            self.target()
    monkeypatch.setattr("codex_agent.server.core.threading.Thread", ImmediateThread)
    result = service.restart(prompt="resume please", title="resume", delay_seconds=0)
    assert result.restarting is True
    assert result.wakeup_persisted is True
    assert ("wakeup", {"prompt": "resume please", "title": "resume"}) in calls
    assert ("restart",) in calls


def test_create_app_exposes_restart_endpoint(monkeypatch):
    agent = Agent(session="new")
    app = create_app(agent=agent)
    client = TestClient(app)
    service = app.state.agent_service
    calls = []
    monkeypatch.setattr(service, "restart", lambda **kwargs: calls.append(kwargs) or modict(restarting=True, wakeup_persisted=True))
    response = client.post("/restart/", json={"prompt": "resume", "title": "after update"})
    assert response.status_code == 200
    assert response.json() == {"restarting": True, "wakeup_persisted": True}
    assert calls == [{"prompt": "resume", "title": "after update"}]


def test_agent_server_restart_waits_for_turn_end_when_busy(monkeypatch):
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    agent.mainloop_manager.futures["running"] = modict(command="turn", status="running")
    calls = []
    monkeypatch.setattr("codex_agent.server.core.write_restart_wakeup", lambda **kwargs: calls.append(("wakeup", kwargs)))
    monkeypatch.setattr("codex_agent.server.core.time.sleep", lambda delay: calls.append(("sleep", delay)))
    monkeypatch.setattr("codex_agent.server.core.restart_server_service", lambda: calls.append(("restart",)))
    class ImmediateThread:
        def __init__(self, target, **kwargs):
            self.target = target
        def start(self):
            self.target()
    monkeypatch.setattr("codex_agent.server.core.threading.Thread", ImmediateThread)

    result = service.restart(prompt="resume please", title="resume", delay_seconds=0)

    assert result.restart_pending is True
    assert service.pending_restart is not None
    assert ("wakeup", {"prompt": "resume please", "title": "resume"}) in calls
    assert ("restart",) not in calls

    service._on_assistant_turn_end(modict(type="assistant_turn_end_event"))

    assert service.pending_restart is None
    assert ("restart",) in calls


def test_create_app_resumes_server_config_session_instead_of_latest():
    older = Agent(session="new")
    older_id = older.current_session_id
    newer = Agent(session="new")
    newer_id = newer.current_session_id
    assert newer_id != older_id
    assert newer.latest_session_id() == newer_id
    save_server_config(current_session_id=older_id)

    app = create_app()
    service = app.state.agent_service

    assert service.runtime.agent.current_session_id == older_id
    assert service.runtime.agent.current_session_id != newer_id

def test_agent_server_persists_current_session_on_session_changes():
    first = Agent(session="new")
    first_id = first.current_session_id
    second = Agent(session="new")
    second_id = second.current_session_id
    service = AgentServer(InProcessAgentRuntime(second))

    assert load_server_config().current_session_id == second_id

    service.load_session(first_id)
    assert service.runtime.agent.current_session_id == first_id
    assert load_server_config().current_session_id == first_id

    service.start_new_session()
    assert service.runtime.agent.current_session_id not in (first_id, second_id)
    assert load_server_config().current_session_id == service.runtime.agent.current_session_id


def test_in_process_server_internal_paths_survive_process_cwd_changes(tmp_path, isolated_runtime_dir):
    project = tmp_path / "project"
    hostile = tmp_path / "hostile-server-cwd"
    project.mkdir()
    hostile.mkdir()
    app = create_app(session="new", root_dir=str(project))
    service = app.state.agent_service
    agent = service.runtime.agent

    previous_cwd = os.getcwd()
    try:
        os.chdir(hostile)

        client = TestClient(app)
        assert client.get("/status").status_code == 200
        service.publish(modict(type="assistant_turn_start_event", prompt="cwd hostile"))
        service.runtime.agent.config_manager.save()
        service.runtime.agent.save_session()
        service.persist_current_session()

        assert server_config_file() == str(isolated_runtime_dir / "server-config.json")
        assert server_events_file() == str(isolated_runtime_dir / "server-events.jsonl")
        assert agent.config_manager.file == str(isolated_runtime_dir / "agent.config.json")
        assert agent.session.session_file == str(isolated_runtime_dir / "sessions" / f"{agent.current_session_id}.json")
        assert load_server_config().current_session_id == agent.current_session_id
        assert (isolated_runtime_dir / "server-config.json").is_file()
        assert (isolated_runtime_dir / "server-events.jsonl").is_file()
        assert not (hostile / "server-config.json").exists()
        assert not (hostile / "server-events.jsonl").exists()
        assert not (hostile / "agent.config.json").exists()
        assert not (hostile / "sessions").exists()
    finally:
        os.chdir(previous_cwd)

def test_create_app_ignores_missing_remembered_session_and_falls_back_to_latest():
    agent = Agent(session="new")
    latest_id = agent.current_session_id
    save_server_config(current_session_id="missing_session")

    app = create_app()
    service = app.state.agent_service

    assert service.runtime.agent.current_session_id == latest_id
    assert service.runtime.agent.current_session_id != "missing_session"


def test_create_app_ignores_corrupt_remembered_and_latest_sessions():
    older = Agent(session="new")
    older_id = older.current_session_id
    corrupt = AgentSession(session_id="29990101_000000", messages=[])
    corrupt.save()
    with open(corrupt.session_file, "w", encoding="utf-8") as f:
        f.write("[")
    save_server_config(current_session_id=corrupt.session_id)

    app = create_app()
    service = app.state.agent_service

    assert service.runtime.agent.current_session_id == older_id
    assert service.runtime.agent.current_session_id != corrupt.session_id


def test_config_patch_updates_agent_config():
    app = create_app()
    client = TestClient(app)

    response = client.patch("/config", json={"values": {"input_token_limit": 12345}, "save": False})

    assert response.status_code == 200
    assert response.json()["input_token_limit"] == 12345
    assert app.state.agent_service.runtime.agent.config.input_token_limit == 12345


def test_create_app_can_run_agent_in_separate_process():
    app = create_app(start_agent=True, process_agent=True)
    client = TestClient(app)
    service = app.state.agent_service

    try:
        health = client.get("/health")
        config = client.get("/config")

        assert health.status_code == 200
        assert health.json()["ok"] is True
        assert service.runtime.process.is_alive()
        assert config.status_code == 200
        assert "plugins" not in config.json()
        assert "voice_enabled" not in config.json()
    finally:
        service.stop(timeout=1.0)


def test_process_agent_runtime_stop_joins_event_thread():
    runtime = ProcessAgentRuntime(command_timeout=1.0, status_timeout=0.2).start()

    runtime.stop(timeout=1.0)

    assert not runtime.running.is_set()
    assert not runtime.process.is_alive()
    assert not runtime.event_thread.is_alive()


def test_process_agent_runtime_discards_timed_out_commands():
    runtime = ProcessAgentRuntime(command_timeout=0.05)
    runtime.process = modict(is_alive=lambda: True)

    try:
        runtime.call("never", timeout=0.01)
    except TimeoutError:
        pass
    else:
        raise AssertionError("Expected command timeout")

    assert runtime.pending == {}


def test_process_agent_runtime_call_can_disable_autostart():
    runtime = ProcessAgentRuntime(command_timeout=0.05)

    try:
        runtime.call("start", timeout=0.01, autostart=False)
    except AgentRuntimeError as exc:
        assert "agent worker process is not running" in str(exc)
    else:
        raise AssertionError("Expected call without autostart to fail when worker is stopped")

    assert runtime.process is None
    assert runtime.pending == {}


def test_process_agent_runtime_updates_cached_status_from_compaction_event():
    runtime = ProcessAgentRuntime()

    runtime._handle_event(modict(
        type="compaction_completed_event",
        status=modict(
            context_current_tokens=123,
            context_limit_tokens=1000,
            context_percent=12.3,
            sent_session_messages=1,
            total_session_messages=52,
            session_id="session_1",
            busy=False,
            source="local_estimate",
        ),
    ))

    assert runtime.cache.status.context_current_tokens == 123
    assert runtime.cache.current_session_id == "session_1"
    assert runtime.cache.busy is False


def test_process_agent_runtime_fallback_status_hydrates_persisted_session_when_worker_busy():
    agent = Agent(session="new")
    session_id = agent.current_session_id
    agent.session.messages.append(DeveloperMessage(content="persistent"))
    agent.session.messages.append(modict(
        type="tool_result_wrapper",
        content="active persisted payload",
        turns_left=2,
        tool_name="read",
        call_id="call_active",
    ))
    agent.session.messages.append(modict(
        type="tool_result_wrapper",
        content="vanished persisted payload",
        turns_left=0,
        tool_name="read",
        call_id="call_vanished",
    ))
    agent.session.save()

    runtime = ProcessAgentRuntime(agent_kwargs={"session": session_id})
    runtime.cache.status = modict(context_current_tokens=1000, context_limit_tokens=10_000)
    runtime.call = lambda *args, **kwargs: (_ for _ in ()).throw(TimeoutError("worker busy"))

    status = runtime.get_status()

    assert runtime.cache.current_session_id == session_id
    assert status.total_session_messages >= 3
    assert status.active_wrapper_messages == 1
    assert status.vanished_wrapper_messages == 1
    assert (
        status.persistent_session_messages
        + status.active_wrapper_messages
        + status.vanished_wrapper_messages
    ) == status.total_session_messages
    assert status.total_wrapper_messages == 2
    assert status.active_wrapper_tokens > 0
    assert status.vanished_wrapper_tokens > 0


def test_process_agent_runtime_fallback_estimates_context_tokens_without_worker_status():
    runtime = ProcessAgentRuntime(agent_kwargs={"session": "missing-session-for-test"})
    runtime.cache.messages = []
    runtime.cache.status = modict(context_limit_tokens=10_000)
    runtime._handle_event(modict(
        type="message_added_event",
        message=modict(type="developer_message", content="persistent base payload"),
    ))
    runtime._handle_event(modict(
        type="message_added_event",
        message=modict(
            type="tool_result_wrapper",
            content="active payload",
            turns_left=2,
            tool_name="read",
            call_id="call_active",
        ),
    ))
    runtime._handle_event(modict(
        type="message_added_event",
        message=modict(
            type="tool_result_wrapper",
            content="vanished payload",
            turns_left=0,
            tool_name="read",
            call_id="call_vanished",
        ),
    ))
    runtime.call = lambda *args, **kwargs: (_ for _ in ()).throw(TimeoutError("worker busy"))

    status = runtime.get_status()

    assert status.context_current_tokens > 0
    assert status.context_limit_tokens == 10_000
    assert status.context_percent > 0
    assert status.base_context_tokens > 0
    assert status.active_wrapper_tokens > 0
    assert status.vanished_wrapper_tokens > 0


def test_process_agent_runtime_replicates_worker_status_update_event():
    runtime = ProcessAgentRuntime(agent_kwargs={"session": "missing-session-for-test"})
    runtime._handle_event(modict(
        type="status_updated_event",
        status=modict(
            context_current_tokens=1234,
            context_limit_tokens=10_000,
            context_percent=12.34,
            source="last_api_call",
            session_id="session_1",
        ),
    ))
    runtime.call = lambda *args, **kwargs: (_ for _ in ()).throw(TimeoutError("worker busy"))

    status = runtime.get_status()

    assert status.context_current_tokens == 1234
    assert status.context_percent == 12.34
    assert status.source == "last_api_call"
    assert status.session_id == "session_1"


def test_process_agent_runtime_message_events_do_not_overwrite_worker_status_percent():
    runtime = ProcessAgentRuntime(agent_kwargs={"session": "missing-session-for-test"})
    runtime._handle_event(modict(
        type="status_updated_event",
        status=modict(context_current_tokens=1234, context_limit_tokens=10_000, context_percent=12.34, source="last_api_call"),
    ))
    runtime._handle_event(modict(
        type="message_added_event",
        message=modict(type="developer_message", content="long " * 500),
    ))
    runtime.call = lambda *args, **kwargs: (_ for _ in ()).throw(TimeoutError("worker busy"))

    status = runtime.get_status()

    assert status.context_current_tokens == 1234
    assert status.context_percent == 12.34


def test_process_agent_runtime_fallback_status_tracks_wrapper_events():
    runtime = ProcessAgentRuntime()
    runtime.cache.status = modict()

    runtime._handle_event(modict(
        type="message_added_event",
        message=modict(
            type="tool_result_wrapper",
            content="active payload",
            turns_left=2,
            tool_name="read",
            call_id="call_active",
        ),
    ))
    runtime._handle_event(modict(
        type="message_added_event",
        message=modict(
            type="tool_result_wrapper",
            content="vanished payload",
            turns_left=0,
            tool_name="read",
            call_id="call_vanished",
        ),
    ))

    runtime.call = lambda *args, **kwargs: (_ for _ in ()).throw(TimeoutError("worker busy"))
    status = runtime.get_status()

    assert status.active_wrapper_messages == 1
    assert status.vanished_wrapper_messages == 1
    assert status.total_wrapper_messages == 2
    assert status.active_wrapper_tokens > 0
    assert status.vanished_wrapper_tokens > 0

    runtime._handle_event(modict(type="assistant_turn_start_event", turn_id="turn_1"))
    runtime._handle_event(modict(type="assistant_turn_start_event", turn_id="turn_2"))

    status = runtime.get_status()

    assert status.active_wrapper_messages == 0
    assert status.vanished_wrapper_messages == 2
    assert status.total_wrapper_messages == 2
    assert (
        status.persistent_session_messages
        + status.active_wrapper_messages
        + status.vanished_wrapper_messages
    ) == status.total_session_messages


def test_process_agent_runtime_event_handler_errors_do_not_stop_other_handlers():
    runtime = ProcessAgentRuntime()
    seen = []

    def broken_handler(event):
        seen.append("broken")
        raise RuntimeError("handler failed")

    runtime.on_event(broken_handler)
    runtime.on_event(lambda event: seen.append(event.type))

    runtime._handle_event(modict(type="assistant_turn_start_event", turn_id="turn_1"))

    assert seen == ["broken", "assistant_turn_start_event"]
    assert runtime.cache.busy is True
    assert runtime.cache.current_turn_id == "turn_1"


def test_agent_server_subscribe_replays_missed_events_after_sequence():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    service.publish({"type": "assistant_turn_start_event", "sequence_marker": "start"})
    first = service.publish({"type": "assistant_message_delta_event", "delta": "first"})
    second = service.publish({"type": "assistant_message_delta_event", "delta": "second"})
    subscription = service.subscribe(after_sequence=first.sequence)
    events = [next(subscription), next(subscription)]
    assert events[0].type == "server_subscribed"
    assert events[0].after_sequence == first.sequence
    assert events[0].replayed_events == 1
    assert events[1].sequence == second.sequence
    assert events[1].delta == "second"
    service.close_subscribers("test")


def test_agent_server_subscribe_does_not_replay_missed_events_from_other_session():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    first = service.publish({"type": "assistant_turn_start_event", "prompt": "old", "session_id": "old_session"})
    service.publish({"type": "assistant_message_delta_event", "delta": "old", "session_id": "old_session"})
    service.publish({"type": "assistant_turn_start_event", "prompt": "current", "session_id": agent.current_session_id})

    subscription = service.subscribe(after_sequence=first.sequence)
    subscribed = next(subscription)
    missed = next(subscription)

    assert subscribed.type == "server_subscribed"
    assert subscribed.session_id == agent.current_session_id
    assert subscribed.replayed_events == 1
    assert missed.prompt == "current"
    subscription.close()


def test_agent_server_persists_current_turn_events_to_jsonl():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    start = service.publish({"type": "assistant_turn_start_event", "prompt": "persist me"})
    delta = service.publish({"type": "assistant_message_delta_event", "delta": "hello"})

    with open(server_events_file(), encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    assert len(lines) == 2
    assert '"assistant_turn_start_event"' in lines[0]
    assert '"assistant_message_delta_event"' in lines[1]
    assert start.sequence < delta.sequence

def test_agent_server_restores_persisted_turn_events_after_restart():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    first = service.publish({"type": "assistant_turn_start_event", "prompt": "before restart"})
    second = service.publish({"type": "assistant_message_delta_event", "delta": "restored"})

    restarted = AgentServer(InProcessAgentRuntime(agent))

    assert restarted.event_sequence == second.sequence
    replay = restarted.replay_events()
    assert [event.type for event in replay.events] == [
        "assistant_turn_start_event",
        "assistant_message_delta_event",
    ]
    assert replay.events[0].sequence == first.sequence
    assert replay.events[1].delta == "restored"

def test_agent_server_subscribe_replays_persisted_missed_events_after_restart():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    first = service.publish({"type": "assistant_turn_start_event", "prompt": "before restart"})
    second = service.publish({"type": "assistant_message_delta_event", "delta": "after cursor"})

    restarted = AgentServer(InProcessAgentRuntime(agent))
    subscription = restarted.subscribe(after_sequence=first.sequence)
    subscribed = next(subscription)
    missed = next(subscription)

    assert subscribed.type == "server_subscribed"
    assert subscribed.replayed_events == 1
    assert missed.sequence == second.sequence
    assert missed.delta == "after cursor"
    subscription.close()

def test_agent_server_rewrites_persisted_events_on_new_turn_start():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    service.publish({"type": "assistant_turn_start_event", "prompt": "old"})
    service.publish({"type": "assistant_message_delta_event", "delta": "old delta"})
    new_start = service.publish({"type": "assistant_turn_start_event", "prompt": "new"})

    restarted = AgentServer(InProcessAgentRuntime(agent))
    replay = restarted.replay_events()

    assert [event.type for event in replay.events] == ["assistant_turn_start_event"]
    assert replay.events[0].prompt == "new"
    assert replay.events[0].sequence == new_start.sequence


def test_agent_server_persisted_rewrite_uses_explicit_event_snapshot():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    start = service.publish({"type": "assistant_turn_start_event", "prompt": "snapshot"})
    service.current_turn_events.append(modict(type="assistant_message_delta_event", delta="late mutation"))

    service.write_persisted_turn_events([start])

    restarted = AgentServer(InProcessAgentRuntime(agent))
    replay = restarted.replay_events()
    assert [event.type for event in replay.events] == ["assistant_turn_start_event"]
    assert replay.events[0].prompt == "snapshot"


def test_agent_server_does_not_append_unrelated_events_after_completed_turn():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    service.publish({"type": "assistant_turn_start_event", "prompt": "done"})
    service.publish({"type": "assistant_turn_end_event", "prompt": "done", "reason": "completed"})
    service.publish({"type": "session_loaded_event", "session_id": "other"})

    replay = service.replay_events()

    assert [event.type for event in replay.events] == [
        "assistant_turn_start_event",
        "assistant_turn_end_event",
    ]


def test_agent_server_does_not_replay_previous_turn_after_session_change():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))

    service.publish({"type": "assistant_turn_start_event", "prompt": "previous"})
    service.publish({"type": "assistant_turn_end_event", "prompt": "previous", "reason": "completed"})
    service.publish({"type": "session_loaded_event", "session_id": "other_session"})

    replay = service.replay_events(session_id="other_session")

    assert replay.events == []


def test_agent_server_restores_active_turn_state_from_persisted_events():
    agent = Agent(session="new")
    service = AgentServer(InProcessAgentRuntime(agent))
    service.publish({"type": "assistant_turn_start_event", "prompt": "active"})
    service.publish({"type": "assistant_message_delta_event", "delta": "before"})

    restarted = AgentServer(InProcessAgentRuntime(agent))
    restarted.publish({"type": "assistant_message_delta_event", "delta": "after"})

    replay = restarted.replay_events()

    assert [event.delta for event in replay.events if event.get("delta")] == ["before", "after"]
