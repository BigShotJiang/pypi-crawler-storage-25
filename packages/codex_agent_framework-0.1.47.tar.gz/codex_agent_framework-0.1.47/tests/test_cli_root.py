import importlib

root = importlib.import_module("codex_agent.cli.root")
cli_main = importlib.import_module("codex_agent.cli.main")


def test_root_help_mentions_public_orchestration_commands(capsys):
    root.dispatch(["--help"], fallback=lambda args: None)

    out = capsys.readouterr().out
    assert "start" in out
    assert "open" in out
    assert "run" in out
    assert "codex-agent start server" in out


def test_root_dispatch_falls_back_to_agent_cli(monkeypatch):
    calls = []
    root.dispatch(["status", "--json"], fallback=lambda args: calls.append(args))
    assert calls == [["status", "--json"]]


def test_root_start_server_detaches_by_default(monkeypatch, tmp_path, capsys):
    calls = []

    class FakePopen:
        def __init__(self, command, **kwargs):
            self.pid = 4321
            calls.append((command, kwargs))

    monkeypatch.setattr(root.subprocess, "Popen", FakePopen)
    monkeypatch.setattr(root, "runtime_join", lambda *parts: str(tmp_path.joinpath(*parts)))

    root.dispatch(["start", "server", "--host", "0.0.0.0", "--port", "9999"], fallback=lambda args: None)

    command, kwargs = calls[0]
    assert command[-5:] == ["--host", "0.0.0.0", "--port", "9999", "--foreground"]
    assert kwargs["stdin"] is root.subprocess.DEVNULL
    assert kwargs["start_new_session"] is True
    assert "Started server in background with PID 4321" in capsys.readouterr().out


def test_root_start_server_foreground_dispatches(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_server", lambda host, port: calls.append((host, port)))

    root.dispatch(["start", "server", "--host", "0.0.0.0", "--port", "9999", "--foreground"], fallback=lambda args: None)

    assert calls == [("0.0.0.0", 9999)]


def test_root_start_tray_detaches_by_default(monkeypatch, tmp_path, capsys):
    calls = []

    class FakePopen:
        def __init__(self, command, **kwargs):
            self.pid = 9876
            calls.append((command, kwargs))

    monkeypatch.setattr(root.subprocess, "Popen", FakePopen)
    monkeypatch.setattr(root, "runtime_join", lambda *parts: str(tmp_path.joinpath(*parts)))

    root.dispatch(["start", "tray", "--url", "http://agent.local"], fallback=lambda args: None)

    command, kwargs = calls[0]
    assert command[-3:] == ["--url", "http://agent.local", "--foreground"]
    assert kwargs["stdin"] is root.subprocess.DEVNULL
    assert kwargs["start_new_session"] is True
    assert "Started tray in background with PID 9876" in capsys.readouterr().out


def test_root_start_tray_foreground_dispatches(monkeypatch):
    calls = []
    monkeypatch.setattr(cli_main, "run_tray_mode", lambda base_url: calls.append(base_url))

    root.dispatch(["start", "tray", "--url", "http://agent.local", "--foreground"], fallback=lambda args: None)

    assert calls == ["http://agent.local"]


def test_root_stop_service_uses_service_controller(monkeypatch):
    calls = []

    class FakeController:
        def run(self, command, name, check=False):
            calls.append((command, name, check))

    monkeypatch.setattr(root, "service_controller", lambda: FakeController())

    root.dispatch(["stop", "server"], fallback=lambda args: None)

    assert calls == [("stop", "codex-agent.service", False)]


def test_root_open_tui_posts_to_server(monkeypatch, capsys):
    calls = []

    class FakeClient:
        def __init__(self, base_url):
            calls.append(("init", base_url))

        def open_tui(self):
            calls.append(("open",))
            return {"opened": True}

    monkeypatch.setattr(root, "AgentClient", FakeClient)

    root.dispatch(["open", "tui", "--url", "http://agent.local"], fallback=lambda args: None)

    assert calls == [("init", "http://agent.local"), ("open",)]
    assert "TUI open requested" in capsys.readouterr().out


def test_root_close_tui_posts_to_server(monkeypatch, capsys):
    calls = []

    class FakeClient:
        def __init__(self, base_url):
            calls.append(("init", base_url))

        def close_tui(self):
            calls.append(("close",))
            return {"closed": True}

    monkeypatch.setattr(root, "AgentClient", FakeClient)

    root.dispatch(["close", "tui"], fallback=lambda args: None)

    assert calls == [("init", "http://127.0.0.1:8765"), ("close",)]
    assert "TUI close requested" in capsys.readouterr().out


def test_root_rejects_direct_service_mode():
    import pytest

    with pytest.raises(SystemExit) as exc:
        root.dispatch(["server"], fallback=lambda args: None)
    assert exc.value.code == 2


def test_root_rejects_direct_interface_mode():
    import pytest

    with pytest.raises(SystemExit) as exc:
        root.dispatch(["tui"], fallback=lambda args: None)
    assert exc.value.code == 2
