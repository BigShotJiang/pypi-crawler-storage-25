//! Type definitions for xlsxturbo

use indexmap::IndexMap;
use pyo3::prelude::*;
use std::collections::HashMap;

/// Date formats by locale/order preference
/// ISO formats (YYYY-MM-DD) are always tried first as they're unambiguous
pub(crate) const DATE_PATTERNS_ISO: &[&str] = &[
    "%Y-%m-%d", // 2024-01-15
    "%Y/%m/%d", // 2024/01/15
];

/// European date formats (day first): DD-MM-YYYY
pub(crate) const DATE_PATTERNS_DMY: &[&str] = &[
    "%d-%m-%Y", // 15-01-2024
    "%d/%m/%Y", // 15/01/2024
];

/// US date formats (month first): MM-DD-YYYY
pub(crate) const DATE_PATTERNS_MDY: &[&str] = &[
    "%m-%d-%Y", // 01-15-2024
    "%m/%d/%Y", // 01/15/2024
];

/// Date order preference for ambiguous dates like 01-02-2024
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub enum DateOrder {
    /// Year-Month-Day first, then Day-Month-Year, then Month-Day-Year (default)
    #[default]
    Auto,
    /// US format: Month-Day-Year (01-02-2024 = January 2)
    MDY,
    /// European format: Day-Month-Year (01-02-2024 = February 1)
    DMY,
}

impl DateOrder {
    /// Parse from string, returns None for invalid input
    pub fn parse(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "auto" => Some(DateOrder::Auto),
            "mdy" | "us" => Some(DateOrder::MDY),
            "dmy" | "eu" | "european" => Some(DateOrder::DMY),
            _ => None,
        }
    }

    /// Get date patterns in order of preference
    pub(crate) fn patterns(&self) -> Vec<&'static str> {
        let mut patterns = Vec::with_capacity(6);
        // ISO formats are always first (unambiguous)
        patterns.extend_from_slice(DATE_PATTERNS_ISO);
        match self {
            DateOrder::Auto | DateOrder::DMY => {
                patterns.extend_from_slice(DATE_PATTERNS_DMY);
                patterns.extend_from_slice(DATE_PATTERNS_MDY);
            }
            DateOrder::MDY => {
                patterns.extend_from_slice(DATE_PATTERNS_MDY);
                patterns.extend_from_slice(DATE_PATTERNS_DMY);
            }
        }
        patterns
    }
}

/// Datetime formats we recognize
pub(crate) const DATETIME_PATTERNS: &[&str] = &[
    "%Y-%m-%dT%H:%M:%S",    // ISO 8601
    "%Y-%m-%d %H:%M:%S",    // Common format
    "%Y-%m-%dT%H:%M:%S%.f", // ISO 8601 with fractional seconds
    "%Y-%m-%d %H:%M:%S%.f", // With fractional seconds
];

/// Represents the detected type of a cell value
#[derive(Debug, Clone)]
pub(crate) enum CellValue {
    Empty,
    Integer(i64),
    Float(f64),
    Boolean(bool),
    Date(f64),     // Excel serial date
    DateTime(f64), // Excel serial datetime
    String(String),
}

/// Type alias for merged range tuple: (range_str, text, optional format_dict)
pub(crate) type MergedRange = (String, String, Option<HashMap<String, Py<PyAny>>>);

/// Type alias for hyperlink tuple: (cell_ref, url, optional display_text)
pub(crate) type Hyperlink = (String, String, Option<String>);

/// Type alias for comment: either simple text or dict with 'text' and optionally 'author'
pub(crate) type Comment = (String, Option<String>); // (text, author)

/// Type alias for validation: column name/pattern -> validation config
pub(crate) type ValidationConfig = HashMap<String, Py<PyAny>>;

/// Type alias for rich text segment: (text, optional format_dict) or just text
pub(crate) type RichTextSegment = (String, Option<HashMap<String, Py<PyAny>>>);

/// Type alias for image config: cell_ref -> image path or config dict
pub(crate) type ImageConfig = (String, Option<HashMap<String, Py<PyAny>>>); // (path, options)

/// Type alias for conditional format configs: column/pattern -> list of format config dicts
pub(crate) type ConditionalFormatConfigs = IndexMap<String, Vec<HashMap<String, Py<PyAny>>>>;

/// Represents a single cell write operation with optional formatting
#[derive(Debug)]
pub(crate) struct CellWrite {
    pub(crate) row: u32,
    pub(crate) col: u16,
    pub(crate) value: Py<PyAny>,
    pub(crate) num_format: Option<String>,
    pub(crate) align_horizontal: Option<String>,
    pub(crate) align_vertical: Option<String>,
    pub(crate) wrap_text: bool,
}

/// Detect whether a Python object is a Polars or Pandas DataFrame.
/// Returns true for Polars, false for Pandas.
/// Errors if the object is neither.
pub(crate) fn is_polars_dataframe(df: &Bound<'_, PyAny>) -> Result<bool, String> {
    // Check the actual module to avoid misidentifying objects that happen to
    // have similar attributes (e.g., Pydantic models with .schema)
    let module = df
        .get_type()
        .getattr("__module__")
        .and_then(|m| m.extract::<String>())
        .unwrap_or_else(|_| String::new());

    if module.starts_with("polars") {
        Ok(true)
    } else if module.starts_with("pandas") {
        Ok(false)
    } else {
        Err(format!(
            "Unsupported DataFrame type: {}.{}. Expected pandas or polars DataFrame.",
            module,
            df.get_type()
                .name()
                .map_or_else(|_| "unknown".to_string(), |n| n.to_string())
        ))
    }
}

/// Extract column names from a DataFrame (Polars or Pandas).
pub(crate) fn extract_columns(
    df: &Bound<'_, PyAny>,
    is_polars: bool,
) -> Result<Vec<String>, String> {
    if is_polars {
        let cols = df.getattr("columns").map_err(|e| e.to_string())?;
        cols.extract().map_err(|e: pyo3::PyErr| e.to_string())
    } else {
        let cols = df.getattr("columns").map_err(|e| e.to_string())?;
        let col_list = cols.call_method0("tolist").map_err(|e| e.to_string())?;
        col_list.extract().map_err(|e: pyo3::PyErr| e.to_string())
    }
}

/// Extracted and validated write options from Python parameters.
/// Used to eliminate duplication between df_to_xlsx and dfs_to_xlsx.
#[derive(Debug, Default)]
pub(crate) struct ExtractedOptions {
    pub(crate) column_widths: Option<HashMap<String, f64>>,
    pub(crate) header_format: Option<HashMap<String, Py<PyAny>>>,
    pub(crate) column_formats: Option<IndexMap<String, HashMap<String, Py<PyAny>>>>,
    pub(crate) conditional_formats: Option<ConditionalFormatConfigs>,
    pub(crate) formula_columns: Option<IndexMap<String, String>>,
    pub(crate) merged_ranges: Option<Vec<MergedRange>>,
    pub(crate) hyperlinks: Option<Vec<Hyperlink>>,
    pub(crate) comments: Option<HashMap<String, Comment>>,
    pub(crate) validations: Option<IndexMap<String, ValidationConfig>>,
    pub(crate) rich_text: Option<HashMap<String, Vec<RichTextSegment>>>,
    pub(crate) images: Option<HashMap<String, ImageConfig>>,
    pub(crate) cells: Option<Vec<CellWrite>>,
}

/// Per-sheet configuration options (all optional, defaults to global settings)
#[derive(Debug, Default)]
pub(crate) struct SheetConfig {
    pub(crate) header: Option<bool>,
    pub(crate) autofit: Option<bool>,
    pub(crate) table_style: Option<Option<String>>, // None = use default, Some(None) = explicitly no style
    pub(crate) freeze_panes: Option<bool>,
    pub(crate) column_widths: Option<HashMap<String, f64>>, // Keys: "0", "1", "_all" for global cap
    pub(crate) table_name: Option<String>,
    pub(crate) header_format: Option<HashMap<String, Py<PyAny>>>,
    pub(crate) row_heights: Option<HashMap<u32, f64>>,
    pub(crate) column_formats: Option<IndexMap<String, HashMap<String, Py<PyAny>>>>, // Pattern -> format dict (ordered)
    pub(crate) conditional_formats: Option<ConditionalFormatConfigs>, // Column/pattern -> list of conditional format configs
    pub(crate) formula_columns: Option<IndexMap<String, String>>, // Column name -> formula template (ordered)
    pub(crate) merged_ranges: Option<Vec<MergedRange>>,           // (range, text, format)
    pub(crate) hyperlinks: Option<Vec<Hyperlink>>, // (cell, url, optional display_text)
    pub(crate) comments: Option<HashMap<String, Comment>>, // cell_ref -> (text, author)
    pub(crate) validations: Option<IndexMap<String, ValidationConfig>>, // column name/pattern -> validation config
    pub(crate) rich_text: Option<HashMap<String, Vec<RichTextSegment>>>, // cell_ref -> segments
    pub(crate) images: Option<HashMap<String, ImageConfig>>, // cell_ref -> (path, options)
    pub(crate) cells: Option<Vec<CellWrite>>,
}

/// Scalar configuration for writing a single sheet.
/// Groups the simple config fields to reduce parameter counts in write_sheet_data
/// and apply_worksheet_features.
pub(crate) struct WriteConfig<'a> {
    pub(crate) include_header: bool,
    pub(crate) autofit: bool,
    pub(crate) table_style: Option<&'a str>,
    pub(crate) freeze_panes: bool,
    pub(crate) table_name: Option<&'a str>,
    pub(crate) row_heights: Option<&'a HashMap<u32, f64>>,
    pub(crate) constant_memory: bool,
}

/// Resolved effective options for writing a single sheet (references only, avoids cloning Py<PyAny>).
/// Built from either ExtractedOptions (single-sheet) or SheetConfig+ExtractedOptions merge (multi-sheet).
pub(crate) struct EffectiveOpts<'a> {
    pub(crate) column_widths: Option<&'a HashMap<String, f64>>,
    pub(crate) header_format: Option<&'a HashMap<String, Py<PyAny>>>,
    pub(crate) column_formats: Option<&'a IndexMap<String, HashMap<String, Py<PyAny>>>>,
    pub(crate) conditional_formats: Option<&'a ConditionalFormatConfigs>,
    pub(crate) formula_columns: Option<&'a IndexMap<String, String>>,
    pub(crate) merged_ranges: Option<&'a Vec<MergedRange>>,
    pub(crate) hyperlinks: Option<&'a Vec<Hyperlink>>,
    pub(crate) comments: Option<&'a HashMap<String, Comment>>,
    pub(crate) validations: Option<&'a IndexMap<String, ValidationConfig>>,
    pub(crate) rich_text: Option<&'a HashMap<String, Vec<RichTextSegment>>>,
    pub(crate) images: Option<&'a HashMap<String, ImageConfig>>,
    pub(crate) cells: Option<&'a Vec<CellWrite>>,
}

impl ExtractedOptions {
    /// Create EffectiveOpts from this ExtractedOptions (all fields as references).
    pub(crate) fn as_effective(&self) -> EffectiveOpts<'_> {
        EffectiveOpts {
            column_widths: self.column_widths.as_ref(),
            header_format: self.header_format.as_ref(),
            column_formats: self.column_formats.as_ref(),
            conditional_formats: self.conditional_formats.as_ref(),
            formula_columns: self.formula_columns.as_ref(),
            merged_ranges: self.merged_ranges.as_ref(),
            hyperlinks: self.hyperlinks.as_ref(),
            comments: self.comments.as_ref(),
            validations: self.validations.as_ref(),
            rich_text: self.rich_text.as_ref(),
            images: self.images.as_ref(),
            cells: self.cells.as_ref(),
        }
    }
}

impl SheetConfig {
    /// Merge per-sheet options with global defaults, returning EffectiveOpts.
    /// Per-sheet values take priority; global defaults are used as fallback.
    pub(crate) fn merge_with<'a>(&'a self, global: &'a ExtractedOptions) -> EffectiveOpts<'a> {
        EffectiveOpts {
            column_widths: self
                .column_widths
                .as_ref()
                .or(global.column_widths.as_ref()),
            header_format: self
                .header_format
                .as_ref()
                .or(global.header_format.as_ref()),
            column_formats: self
                .column_formats
                .as_ref()
                .or(global.column_formats.as_ref()),
            conditional_formats: self
                .conditional_formats
                .as_ref()
                .or(global.conditional_formats.as_ref()),
            formula_columns: self
                .formula_columns
                .as_ref()
                .or(global.formula_columns.as_ref()),
            merged_ranges: self
                .merged_ranges
                .as_ref()
                .or(global.merged_ranges.as_ref()),
            hyperlinks: self.hyperlinks.as_ref().or(global.hyperlinks.as_ref()),
            comments: self.comments.as_ref().or(global.comments.as_ref()),
            validations: self.validations.as_ref().or(global.validations.as_ref()),
            rich_text: self.rich_text.as_ref().or(global.rich_text.as_ref()),
            images: self.images.as_ref().or(global.images.as_ref()),
            cells: self.cells.as_ref().or(global.cells.as_ref()),
        }
    }
}
