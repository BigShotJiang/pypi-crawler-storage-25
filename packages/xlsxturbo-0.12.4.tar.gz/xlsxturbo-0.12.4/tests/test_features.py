"""
Tests for xlsxturbo features (v0.6.0+):
- Global column width cap, table names, header styling (v0.6.0)
- Column formatting with wildcards (v0.7.0)
- Date order for CSV parsing, edge cases (v0.8.0)
- Formula columns, merged cells, hyperlinks (v0.9.0)
- Comments, validations, rich_text, images (v0.10.0)
- Per-side border styles (v0.12.0)
- Text alignment (v0.12.0)
- Rule-based conditional formatting (v0.12.0)
"""

import xlsxturbo
import pandas as pd
import polars as pl
import tempfile
import os

# Only import openpyxl for verification if available
try:
    from openpyxl import load_workbook

    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

import pytest

# Fail loudly if openpyxl is missing -- silent test passes without verification are worse than skips
pytestmark = pytest.mark.skipif(not HAS_OPENPYXL, reason="openpyxl required for content verification")


def get_temp_path():
    """Get a temporary file path that's closed for Windows compatibility"""
    fd, path = tempfile.mkstemp(suffix=".xlsx")
    os.close(fd)
    return path


class TestColumnWidthCap:
    """Tests for column_widths={'_all': value} feature"""

    def test_all_columns_capped(self):
        """'_all' key sets width for all columns"""
        df = pd.DataFrame({"A": ["x" * 100], "B": ["y" * 100], "C": ["z" * 100]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_widths={"_all": 20})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                for col in ["A", "B", "C"]:
                    assert ws.column_dimensions[col].width <= 21
                wb.close()
        finally:
            os.unlink(path)

    def test_specific_overrides_all(self):
        """Specific column width overrides '_all'"""
        df = pd.DataFrame({"A": ["x"], "B": ["y"], "C": ["z"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_widths={0: 30, "_all": 10})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws.column_dimensions["A"].width > 25
                assert ws.column_dimensions["B"].width <= 11
                wb.close()
        finally:
            os.unlink(path)

    def test_all_with_autofit(self):
        """'_all' acts as cap when combined with autofit"""
        df = pd.DataFrame({"Short": ["x"], "VeryLongColumnName": ["y" * 100]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, autofit=True, column_widths={"_all": 25})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Long column should be capped at ~25
                assert ws.column_dimensions["B"].width <= 26
                wb.close()
        finally:
            os.unlink(path)

    def test_dfs_to_xlsx_per_sheet_all(self):
        """Per-sheet '_all' override in dfs_to_xlsx"""
        df1 = pd.DataFrame({"A": ["x" * 50]})
        df2 = pd.DataFrame({"B": ["y" * 50]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [
                    (df1, "Sheet1", {"column_widths": {"_all": 20}}),
                    (df2, "Sheet2", {"column_widths": {"_all": 40}}),
                ],
                path,
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                # Sheet1 should have narrower column than Sheet2
                w1 = wb["Sheet1"].column_dimensions["A"].width or 0
                w2 = wb["Sheet2"].column_dimensions["A"].width or 0
                assert w1 <= 21, f"Sheet1 col A width {w1} should be <= 21"
                assert w2 > 21, f"Sheet2 col A width {w2} should be > 21"
                wb.close()
        finally:
            os.unlink(path)


    def test_autofit_with_all_cap(self):
        """autofit=True + _all caps autofit widths instead of overriding"""
        df = pd.DataFrame({
            "Short": ["ab", "cd"],
            "VeryLong": ["A" * 100, "B" * 80],
            "Medium": ["hello world", "test data"],
        })
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, autofit=True, column_widths={"_all": 25})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                w_short = ws.column_dimensions["A"].width or 0
                w_long = ws.column_dimensions["B"].width or 0
                w_med = ws.column_dimensions["C"].width or 0
                # Short column should be narrow (content-fitted, not inflated to 25)
                assert w_short < 15, f"Short col width {w_short} should be < 15"
                # VeryLong column should be capped at ~25
                assert w_long <= 26, f"VeryLong col width {w_long} should be <= 26"
                # Medium column should be content-fitted (< 25)
                assert w_med < 20, f"Medium col width {w_med} should be < 20"
                wb.close()
        finally:
            os.unlink(path)

    def test_autofit_with_all_cap_polars(self):
        """autofit + _all cap works with polars DataFrames"""
        df = pl.DataFrame({"Short": ["x"], "Long": ["A" * 80]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, autofit=True, column_widths={"_all": 20})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                w_short = ws.column_dimensions["A"].width or 0
                w_long = ws.column_dimensions["B"].width or 0
                assert w_short < 15, f"Short col width {w_short} should be < 15"
                assert w_long <= 21, f"Long col width {w_long} should be <= 21"
                wb.close()
        finally:
            os.unlink(path)


class TestTableName:
    """Tests for table_name parameter"""

    def test_explicit_table_name(self):
        """Explicit table name is applied"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, table_style="Medium2", table_name="MyTable")
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                tables = list(ws.tables.keys())
                assert "MyTable" in tables
                wb.close()
        finally:
            os.unlink(path)

    def test_table_name_sanitization(self):
        """Invalid characters are sanitized"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path, table_style="Medium2", table_name="My Table-2024!"
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                tables = list(ws.tables.keys())
                assert len(tables) == 1
                assert "_" in tables[0]  # Some characters replaced with underscore
                wb.close()
        finally:
            os.unlink(path)

    def test_table_name_starts_with_digit(self):
        """Table names starting with digit get underscore prefix"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, table_style="Medium2", table_name="123Data")
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                tables = list(ws.tables.keys())
                assert tables[0].startswith("_")
                wb.close()
        finally:
            os.unlink(path)

    def test_per_sheet_table_names(self):
        """Different table names per sheet"""
        df1 = pd.DataFrame({"A": [1]})
        df2 = pd.DataFrame({"B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [
                    (df1, "Sheet1", {"table_style": "Medium2", "table_name": "Table1"}),
                    (df2, "Sheet2", {"table_style": "Medium2", "table_name": "Table2"}),
                ],
                path,
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert "Table1" in wb["Sheet1"].tables
                assert "Table2" in wb["Sheet2"].tables
                wb.close()
        finally:
            os.unlink(path)

    def test_no_table_name_without_table_style(self):
        """table_name is ignored if table_style is None"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, table_name="Ignored")
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert len(ws.tables) == 0
                wb.close()
        finally:
            os.unlink(path)


class TestHeaderFormat:
    """Tests for header_format parameter"""

    def test_bold_header(self):
        """Bold header is applied"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format={"bold": True})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].font.bold == True
                assert ws["B1"].font.bold == True
                wb.close()
        finally:
            os.unlink(path)

    def test_header_background_color(self):
        """Background color is applied to header"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format={"bg_color": "#4F81BD"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # openpyxl uses ARGB format
                assert ws["A1"].fill.fgColor.rgb == "FF4F81BD"
                wb.close()
        finally:
            os.unlink(path)

    def test_header_font_color(self):
        """Font color is applied to header"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format={"font_color": "white"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].font.color.rgb == "FFFFFFFF"
                wb.close()
        finally:
            os.unlink(path)

    def test_combined_header_format(self):
        """Multiple format options combined"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                header_format={"bold": True, "bg_color": "#4F81BD", "font_color": "white"},
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].font.bold == True
                assert ws["A1"].fill.fgColor.rgb == "FF4F81BD"
                assert ws["A1"].font.color.rgb == "FFFFFFFF"
                wb.close()
        finally:
            os.unlink(path)

    def test_header_format_no_header(self):
        """header_format ignored when header=False"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header=False, header_format={"bold": True})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # First row should be data, not header
                assert ws["A1"].value == 1
                wb.close()
        finally:
            os.unlink(path)

    def test_per_sheet_header_format(self):
        """Different header formats per sheet"""
        df1 = pd.DataFrame({"A": [1]})
        df2 = pd.DataFrame({"B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [
                    (df1, "Sheet1", {"header_format": {"bold": True}}),
                    (df2, "Sheet2", {"header_format": {"bg_color": "#FF0000"}}),
                ],
                path,
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb["Sheet1"]["A1"].font.bold == True
                assert wb["Sheet2"]["A1"].fill.fgColor.rgb == "FFFF0000"
                wb.close()
        finally:
            os.unlink(path)


class TestBackwardCompatibility:
    """Ensure existing functionality still works"""

    def test_old_column_widths_still_works(self):
        """Integer key column_widths still works"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_widths={0: 20, 1: 30})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws.column_dimensions["A"].width > 15
                assert ws.column_dimensions["B"].width > 25
                wb.close()
        finally:
            os.unlink(path)

    def test_table_style_without_table_name(self):
        """table_style works without table_name (existing behavior)"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, table_style="Medium9")
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert len(ws.tables) == 1
                wb.close()
        finally:
            os.unlink(path)


class TestPolarsSupport:
    """Ensure all features work with polars DataFrames"""

    def test_polars_column_width_cap(self):
        df = pl.DataFrame({"A": ["x" * 100], "B": ["y" * 100]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_widths={"_all": 20})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws.column_dimensions["A"].width <= 21
                wb.close()
        finally:
            os.unlink(path)

    def test_polars_table_name(self):
        df = pl.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, table_style="Medium2", table_name="PolarsTable")
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert "PolarsTable" in ws.tables
                wb.close()
        finally:
            os.unlink(path)

    def test_polars_header_format(self):
        df = pl.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format={"bold": True})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].font.bold == True
                wb.close()
        finally:
            os.unlink(path)


class TestAllFeaturesCombined:
    """Test using all new features together"""

    def test_all_features_df_to_xlsx(self):
        """All features work together in df_to_xlsx"""
        df = pd.DataFrame(
            {"Name": ["Alice", "Bob"], "Score": [95, 87], "Grade": ["A", "B"]}
        )
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                autofit=True,
                table_style="Medium2",
                table_name="StudentScores",
                column_widths={"_all": 30, 0: 20},
                header_format={"bold": True, "bg_color": "#4F81BD", "font_color": "white"},
                freeze_panes=True,
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert "StudentScores" in ws.tables
                # Note: table_style overrides header_format styling
                # This is expected Excel behavior - tables have their own header styles
                wb.close()
        finally:
            os.unlink(path)

    def test_all_features_dfs_to_xlsx(self):
        """All features work together in dfs_to_xlsx"""
        df1 = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        df2 = pd.DataFrame({"X": ["a", "b"], "Y": ["c", "d"]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [
                    (
                        df1,
                        "Numbers",
                        {
                            "table_style": "Medium2",
                            "table_name": "NumbersTable",
                            "header_format": {"bold": True},
                            "column_widths": {"_all": 15},
                        },
                    ),
                    (
                        df2,
                        "Letters",
                        {
                            "table_style": "Medium9",
                            "table_name": "LettersTable",
                            "header_format": {"bg_color": "#FF0000"},
                        },
                    ),
                ],
                path,
                autofit=True,
                freeze_panes=True,
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert "NumbersTable" in wb["Numbers"].tables
                assert "LettersTable" in wb["Letters"].tables
                wb.close()
        finally:
            os.unlink(path)


class TestEdgeCases:
    """Tests for edge cases and error handling"""

    def test_empty_dataframe(self):
        """Empty DataFrame writes successfully"""
        df = pd.DataFrame({"A": [], "B": []})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 1  # Just header
            assert cols == 2
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_empty_dataframe_with_table_style(self):
        """Empty DataFrame with table_style writes without creating table"""
        df = pd.DataFrame({"A": [], "B": []})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path, table_style="Medium2")
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # No table should be created for empty DataFrame
                assert len(ws.tables) == 0
                wb.close()
        finally:
            os.unlink(path)

    def test_invalid_table_style_raises_error(self):
        """Invalid table_style raises ValueError"""
        df = pd.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            try:
                xlsxturbo.df_to_xlsx(df, path, table_style="InvalidStyle")
                assert False, "Expected ValueError for invalid table_style"
            except ValueError as e:
                assert "Unknown table_style" in str(e)
                assert "InvalidStyle" in str(e)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_invalid_hex_color_raises_error(self):
        """Invalid hex color format raises ValueError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            try:
                xlsxturbo.df_to_xlsx(df, path, header_format={"bg_color": "#FF"})
                assert False, "Expected ValueError for invalid hex color"
            except ValueError as e:
                assert "expected 6 characters" in str(e)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_column_formats_order_preserved(self):
        """Column format patterns are matched in order (first match wins)"""
        df = pd.DataFrame({"price_usd": [1.0], "price_eur": [2.0], "other": [3.0]})
        path = get_temp_path()
        try:
            # The more specific pattern should be listed first to take priority
            xlsxturbo.df_to_xlsx(
                df,
                path,
                column_formats={
                    "price_usd": {"bg_color": "#FF0000"},  # Specific - should match first
                    "price_*": {"bg_color": "#0000FF"},  # General - should match price_eur
                },
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # price_usd should be red (specific match)
                assert ws["A2"].fill.fgColor.rgb == "FFFF0000"
                # price_eur should be blue (wildcard match)
                assert ws["B2"].fill.fgColor.rgb == "FF0000FF"
                # other should have no background
                wb.close()
        finally:
            os.unlink(path)

    def test_empty_dataframe_no_header(self):
        """Empty DataFrame with header=False"""
        df = pd.DataFrame({"A": [], "B": []})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path, header=False)
            assert rows == 0
            assert cols == 2
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_table_style_skipped_when_header_false(self):
        """table_style is skipped when header=False (tables require headers)"""
        df = pd.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header=False, table_style="Medium2")
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].value == 1  # data in row 1, no header
                wb.close()
        finally:
            os.unlink(path)

    def test_dfs_per_sheet_header_false_with_global_table_style(self):
        """Per-sheet header=False skips table even with global table_style"""
        df1 = pd.DataFrame({"A": [1]})
        df2 = pd.DataFrame({"B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx([
                (df1, "WithHeader"),
                (df2, "NoHeader", {"header": False}),
            ], path, table_style="Medium2")
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                # WithHeader sheet should have table
                assert wb["WithHeader"]["A1"].value == "A"
                # NoHeader sheet should have data in row 1
                assert wb["NoHeader"]["A1"].value == 2
                wb.close()
        finally:
            os.unlink(path)


class TestDateOrder:
    """Tests for date_order parameter in csv_to_xlsx"""

    def test_date_order_us_parses_mdy(self):
        """US date order parses 01-02-2024 as January 2"""
        import csv
        from datetime import datetime

        # Create CSV with ambiguous date
        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["date", "value"])
                writer.writerow(["01-02-2024", "100"])

            xlsxturbo.csv_to_xlsx(csv_path, xlsx_path, date_order="us")

            if HAS_OPENPYXL:
                wb = load_workbook(xlsx_path)
                ws = wb.active
                cell_value = ws["A2"].value
                # openpyxl returns datetime objects for Excel dates
                assert isinstance(cell_value, datetime), f"Expected datetime, got {type(cell_value)}"
                # US format: 01-02-2024 = January 2, 2024
                assert cell_value.month == 1, f"Expected January (1), got month {cell_value.month}"
                assert cell_value.day == 2, f"Expected day 2, got day {cell_value.day}"
                wb.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_path):
                os.unlink(xlsx_path)

    def test_date_order_eu_parses_dmy(self):
        """European date order parses 01-02-2024 as February 1"""
        import csv
        from datetime import datetime

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["date", "value"])
                writer.writerow(["01-02-2024", "100"])

            xlsxturbo.csv_to_xlsx(csv_path, xlsx_path, date_order="eu")

            if HAS_OPENPYXL:
                wb = load_workbook(xlsx_path)
                ws = wb.active
                cell_value = ws["A2"].value
                assert isinstance(cell_value, datetime), f"Expected datetime, got {type(cell_value)}"
                # EU format: 01-02-2024 = February 1, 2024
                assert cell_value.month == 2, f"Expected February (2), got month {cell_value.month}"
                assert cell_value.day == 1, f"Expected day 1, got day {cell_value.day}"
                wb.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_path):
                os.unlink(xlsx_path)

    def test_date_order_produces_different_results(self):
        """US and EU date orders produce different Excel dates for ambiguous input"""
        import csv
        from datetime import datetime

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_us = get_temp_path()
        xlsx_eu = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["date"])
                writer.writerow(["03-04-2024"])  # Mar 4 (US) vs Apr 3 (EU)

            xlsxturbo.csv_to_xlsx(csv_path, xlsx_us, date_order="us")
            xlsxturbo.csv_to_xlsx(csv_path, xlsx_eu, date_order="eu")

            if HAS_OPENPYXL:
                wb_us = load_workbook(xlsx_us)
                wb_eu = load_workbook(xlsx_eu)
                us_value = wb_us.active["A2"].value
                eu_value = wb_eu.active["A2"].value
                wb_us.close()
                wb_eu.close()

                # Values should be different dates
                assert us_value != eu_value, "US and EU should produce different dates"
                # US: March 4, EU: April 3 (30 days difference)
                diff = abs((us_value - eu_value).days)
                assert diff == 30, f"Expected 30 day difference, got {diff}"
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_us):
                os.unlink(xlsx_us)
            if os.path.exists(xlsx_eu):
                os.unlink(xlsx_eu)

    def test_invalid_date_order_raises(self):
        """Invalid date_order raises ValueError"""
        import csv

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["a"])
                writer.writerow(["1"])

            try:
                xlsxturbo.csv_to_xlsx(csv_path, xlsx_path, date_order="invalid")
                assert False, "Expected ValueError"
            except ValueError as e:
                assert "invalid" in str(e).lower()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_path):
                os.unlink(xlsx_path)


class TestFormulaColumns:
    """Tests for formula_columns feature (v0.9.0)"""

    def test_basic_formula(self):
        """Formula column appended after data columns"""
        df = pd.DataFrame({"price": [100, 200], "quantity": [5, 3]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(
                df, path, formula_columns={"Total": "=A{row}*B{row}"}
            )
            assert cols == 3  # price, quantity, Total
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Header should be "Total"
                assert ws["C1"].value == "Total"
                # Data rows should have formulas (openpyxl shows them as =formula)
                assert ws["C2"].value == "=A2*B2"
                assert ws["C3"].value == "=A3*B3"
                wb.close()
        finally:
            os.unlink(path)

    def test_multiple_formula_columns(self):
        """Multiple formula columns in order"""
        df = pd.DataFrame({"price": [100], "qty": [5], "tax": [0.1]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(
                df,
                path,
                formula_columns={
                    "Subtotal": "=A{row}*B{row}",
                    "TaxAmt": "=D{row}*C{row}",
                },
            )
            assert cols == 5  # price, qty, tax, Subtotal, TaxAmt
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["D1"].value == "Subtotal"
                assert ws["E1"].value == "TaxAmt"
                assert ws["D2"].value == "=A2*B2"
                assert ws["E2"].value == "=D2*C2"
                wb.close()
        finally:
            os.unlink(path)

    def test_formula_row_placeholder(self):
        """The {row} placeholder is correctly replaced per row"""
        df = pd.DataFrame({"A": [10, 20, 30]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path, formula_columns={"Double": "=A{row}*2"}
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["B2"].value == "=A2*2"
                assert ws["B3"].value == "=A3*2"
                assert ws["B4"].value == "=A4*2"
                wb.close()
        finally:
            os.unlink(path)

    def test_formula_with_dfs_to_xlsx(self):
        """Formula columns work in multi-sheet mode"""
        df = pd.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [(df, "Sheet1", {"formula_columns": {"Sum": "=A{row}+10"}})],
                path,
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb["Sheet1"]
                assert ws["B1"].value == "Sum"
                assert ws["B2"].value == "=A2+10"
                wb.close()
        finally:
            os.unlink(path)


class TestMergedRanges:
    """Tests for merged_ranges feature (v0.9.0)"""

    def test_simple_merge(self):
        """Merge a range with text"""
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4], "C": [5, 6]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                merged_ranges=[("A1:C1", "Title Row")],
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Cell A1 should contain the merge text
                assert ws["A1"].value == "Title Row"
                # The range should be merged
                merged = [str(m) for m in ws.merged_cells.ranges]
                assert "A1:C1" in merged
                wb.close()
        finally:
            os.unlink(path)

    def test_merge_with_format(self):
        """Merge a range with custom formatting"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                merged_ranges=[
                    ("A1:B1", "Styled Merge", {"bold": True, "bg_color": "#4F81BD"})
                ],
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].value == "Styled Merge"
                assert ws["A1"].font.bold is True
                merged = [str(m) for m in ws.merged_cells.ranges]
                assert "A1:B1" in merged
                wb.close()
        finally:
            os.unlink(path)

    def test_multiple_merges(self):
        """Multiple merged ranges in same sheet"""
        df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6], "C": [7, 8, 9]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                merged_ranges=[
                    ("A1:C1", "Top Title"),
                    ("A5:C5", "Bottom Title"),
                ],
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                merged = [str(m) for m in ws.merged_cells.ranges]
                assert "A1:C1" in merged
                assert "A5:C5" in merged
                wb.close()
        finally:
            os.unlink(path)

    def test_merge_with_dfs_to_xlsx(self):
        """Merged ranges work per-sheet"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [(df, "Sheet1", {"merged_ranges": [("A1:B1", "Per-Sheet Merge")]})],
                path,
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb["Sheet1"]
                assert ws["A1"].value == "Per-Sheet Merge"
                merged = [str(m) for m in ws.merged_cells.ranges]
                assert "A1:B1" in merged
                wb.close()
        finally:
            os.unlink(path)


class TestHyperlinks:
    """Tests for hyperlinks feature (v0.9.0)"""

    def test_basic_hyperlink(self):
        """Hyperlink with URL and display text"""
        df = pd.DataFrame({"Name": ["Example"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                hyperlinks=[("B2", "https://example.com", "Example Site")],
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["B2"].hyperlink is not None
                assert "example.com" in ws["B2"].hyperlink.target
                wb.close()
        finally:
            os.unlink(path)

    def test_hyperlink_without_display_text(self):
        """Hyperlink with URL only (no display text)"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                hyperlinks=[("A2", "https://example.com")],
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].hyperlink is not None
                wb.close()
        finally:
            os.unlink(path)

    def test_multiple_hyperlinks(self):
        """Multiple hyperlinks in same sheet"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                hyperlinks=[
                    ("B1", "https://one.com", "One"),
                    ("B2", "https://two.com", "Two"),
                    ("B3", "https://three.com", "Three"),
                ],
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["B1"].hyperlink is not None
                assert ws["B2"].hyperlink is not None
                assert ws["B3"].hyperlink is not None
                wb.close()
        finally:
            os.unlink(path)

    def test_hyperlinks_with_dfs_to_xlsx(self):
        """Hyperlinks work per-sheet in multi-sheet mode"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [
                    (
                        df,
                        "Sheet1",
                        {"hyperlinks": [("B1", "https://example.com", "Link")]},
                    )
                ],
                path,
            )
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb["Sheet1"]
                assert ws["B1"].hyperlink is not None
                wb.close()
        finally:
            os.unlink(path)


class TestCsvConversion:
    """Tests for csv_to_xlsx function"""

    def test_basic_csv(self):
        """Basic CSV with header and data rows"""
        import csv

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["name", "age", "score"])
                writer.writerow(["Alice", "30", "95.5"])
                writer.writerow(["Bob", "25", "88.0"])

            rows, cols = xlsxturbo.csv_to_xlsx(csv_path, xlsx_path)
            assert rows == 3
            assert cols == 3
            if HAS_OPENPYXL:
                wb = load_workbook(xlsx_path)
                ws = wb.active
                assert ws["A1"].value == "name"
                assert ws["B2"].value == 30  # should be detected as integer
                assert ws["C2"].value == 95.5  # should be detected as float
                wb.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_path):
                os.unlink(xlsx_path)

    def test_csv_type_detection(self):
        """CSV type detection: int, float, bool, date, string"""
        import csv

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["int", "float", "bool", "date", "text"])
                writer.writerow(["42", "3.14", "true", "2024-01-15", "hello"])

            xlsxturbo.csv_to_xlsx(csv_path, xlsx_path)
            if HAS_OPENPYXL:
                wb = load_workbook(xlsx_path)
                ws = wb.active
                assert ws["A2"].value == 42
                assert abs(ws["B2"].value - 3.14) < 0.001
                assert ws["C2"].value is True
                # Date should be a datetime object in openpyxl
                from datetime import datetime

                assert isinstance(ws["D2"].value, datetime)
                assert ws["E2"].value == "hello"
                wb.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_path):
                os.unlink(xlsx_path)

    def test_csv_special_values(self):
        """CSV with NaN, Inf, empty cells"""
        import csv

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["a", "b", "c"])
                writer.writerow(["NaN", "Inf", ""])
                writer.writerow(["nan", "-Inf", "   "])

            rows, cols = xlsxturbo.csv_to_xlsx(csv_path, xlsx_path)
            assert rows == 3
            if HAS_OPENPYXL:
                wb = load_workbook(xlsx_path)
                ws = wb.active
                # NaN/Inf/empty should become empty strings or None
                # (written as empty string in write_cell for CellValue::Empty)
                wb.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_path):
                os.unlink(xlsx_path)

    def test_csv_parallel(self):
        """CSV parallel mode produces same output"""
        import csv

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_seq = get_temp_path()
        xlsx_par = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["num", "text"])
                for i in range(100):
                    writer.writerow([str(i), f"row_{i}"])

            rows_s, cols_s = xlsxturbo.csv_to_xlsx(csv_path, xlsx_seq, parallel=False)
            rows_p, cols_p = xlsxturbo.csv_to_xlsx(csv_path, xlsx_par, parallel=True)
            assert rows_s == rows_p
            assert cols_s == cols_p
            if HAS_OPENPYXL:
                wb_s = load_workbook(xlsx_seq)
                wb_p = load_workbook(xlsx_par)
                ws_s = wb_s.active
                ws_p = wb_p.active
                # Spot check some cells match
                for row in [1, 2, 50, 101]:
                    assert ws_s[f"A{row}"].value == ws_p[f"A{row}"].value
                    assert ws_s[f"B{row}"].value == ws_p[f"B{row}"].value
                wb_s.close()
                wb_p.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_seq):
                os.unlink(xlsx_seq)
            if os.path.exists(xlsx_par):
                os.unlink(xlsx_par)

    def test_csv_with_sheet_name(self):
        """CSV conversion with custom sheet name"""
        import csv

        csv_path = get_temp_path().replace(".xlsx", ".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["a"])
                writer.writerow(["1"])

            xlsxturbo.csv_to_xlsx(csv_path, xlsx_path, sheet_name="MySheet")
            if HAS_OPENPYXL:
                wb = load_workbook(xlsx_path)
                assert "MySheet" in wb.sheetnames
                wb.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            if os.path.exists(xlsx_path):
                os.unlink(xlsx_path)


class TestComments:
    """Tests for comments/notes feature (v0.10.0)"""

    def test_simple_comment(self):
        """Simple string comment"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, comments={"A1": "This is a header note"})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # openpyxl stores comments in ws.comments
                assert ws["A1"].comment is not None
                assert "header note" in ws["A1"].comment.text
                wb.close()
        finally:
            os.unlink(path)

    def test_comment_with_author(self):
        """Comment with author"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path, comments={"A2": {"text": "Data note", "author": "John"}}
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                comment = ws["A2"].comment
                assert comment is not None
                assert "Data note" in comment.text
                assert comment.author == "John"
                wb.close()
        finally:
            os.unlink(path)

    def test_multiple_comments(self):
        """Multiple comments on different cells"""
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path, comments={"A1": "Column A", "B1": "Column B", "A2": "First value"}
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].comment is not None
                assert ws["B1"].comment is not None
                assert ws["A2"].comment is not None
                assert "Column A" in ws["A1"].comment.text
                wb.close()
        finally:
            os.unlink(path)


class TestValidations:
    """Tests for data validation feature (v0.10.0)"""

    def test_list_validation(self):
        """Dropdown list validation"""
        df = pd.DataFrame({"Status": ["Open", "Closed"], "Value": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                validations={"Status": {"type": "list", "values": ["Open", "Closed", "Pending"]}},
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Check that data validation exists
                assert len(ws.data_validations.dataValidation) > 0
                wb.close()
        finally:
            os.unlink(path)

    def test_number_validation(self):
        """Whole number range validation"""
        df = pd.DataFrame({"Score": [85, 90]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                validations={"Score": {"type": "whole_number", "min": 0, "max": 100}},
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert len(ws.data_validations.dataValidation) > 0
                wb.close()
        finally:
            os.unlink(path)

    def test_validation_with_messages(self):
        """Validation with input and error messages"""
        df = pd.DataFrame({"Value": [50]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                validations={
                    "Value": {
                        "type": "decimal",
                        "min": 0,
                        "max": 100,
                        "input_title": "Enter Value",
                        "input_message": "Must be between 0 and 100",
                        "error_title": "Invalid",
                        "error_message": "Value out of range",
                    }
                },
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert len(ws.data_validations.dataValidation) > 0
                dv = ws.data_validations.dataValidation[0]
                assert dv.promptTitle == "Enter Value"
                assert dv.errorTitle == "Invalid"
                wb.close()
        finally:
            os.unlink(path)

    def test_validation_pattern_matching(self):
        """Validation with column pattern"""
        df = pd.DataFrame({"score_a": [80], "score_b": [90], "name": ["Test"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path, validations={"score_*": {"type": "whole_number", "min": 0, "max": 100}}
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Should have validations on the score columns
                assert len(ws.data_validations.dataValidation) > 0
                wb.close()
        finally:
            os.unlink(path)


class TestRichText:
    """Tests for rich text feature (v0.10.0)"""

    def test_rich_text_bold(self):
        """Rich text with bold formatting"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path, rich_text={"A1": [("Bold", {"bold": True}), " normal"]}
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # openpyxl may have issues reading rich text, just verify file exists
                wb.close()
        finally:
            os.unlink(path)

    def test_rich_text_mixed_formats(self):
        """Rich text with multiple format segments"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                rich_text={
                    "B2": [
                        ("Red text", {"font_color": "red"}),
                        " and ",
                        ("blue text", {"font_color": "blue", "italic": True}),
                    ]
                },
            )
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_rich_text_plain_segments(self):
        """Rich text with plain string segments"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path, rich_text={"A3": ["Plain text ", ("bold", {"bold": True}), " more plain"]}
            )
            assert os.path.exists(path)
        finally:
            os.unlink(path)


class TestImages:
    """Tests for images feature (v0.10.0)"""

    def test_image_simple_path(self):
        """Image with simple path"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        # Create a small test image (1x1 white pixel PNG)
        import base64

        # Smallest valid PNG (1x1 white pixel)
        png_data = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
        )
        img_path = get_temp_path().replace(".xlsx", ".png")
        try:
            with open(img_path, "wb") as f:
                f.write(png_data)

            xlsxturbo.df_to_xlsx(df, path, images={"D1": img_path})
            assert os.path.exists(path)
        finally:
            if os.path.exists(path):
                os.unlink(path)
            if os.path.exists(img_path):
                os.unlink(img_path)

    def test_image_with_options(self):
        """Image with scaling options"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        import base64

        png_data = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
        )
        img_path = get_temp_path().replace(".xlsx", ".png")
        try:
            with open(img_path, "wb") as f:
                f.write(png_data)

            xlsxturbo.df_to_xlsx(
                df,
                path,
                images={"B5": {"path": img_path, "scale_width": 2.0, "scale_height": 2.0}},
            )
            assert os.path.exists(path)
        finally:
            if os.path.exists(path):
                os.unlink(path)
            if os.path.exists(img_path):
                os.unlink(img_path)


class TestV10AllFeatures:
    """Tests combining v0.10.0 features"""

    def test_all_new_features_together(self):
        """All v0.10.0 features work together"""
        df = pd.DataFrame({"Name": ["Alice", "Bob"], "Score": [85, 92]})
        path = get_temp_path()
        import base64

        png_data = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
        )
        img_path = get_temp_path().replace(".xlsx", ".png")
        try:
            with open(img_path, "wb") as f:
                f.write(png_data)

            xlsxturbo.df_to_xlsx(
                df,
                path,
                comments={"A1": "Names column", "B1": {"text": "Scores", "author": "Test"}},
                validations={"Score": {"type": "whole_number", "min": 0, "max": 100}},
                rich_text={"D1": [("Legend:", {"bold": True}), " student scores"]},
                images={"E1": img_path},
            )
            assert os.path.exists(path)
        finally:
            if os.path.exists(path):
                os.unlink(path)
            if os.path.exists(img_path):
                os.unlink(img_path)

    def test_new_features_with_dfs_to_xlsx(self):
        """New features work with dfs_to_xlsx"""
        df1 = pd.DataFrame({"A": [1, 2]})
        df2 = pd.DataFrame({"B": [3, 4]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [
                    (df1, "Sheet1", {"comments": {"A1": "First sheet header"}}),
                    (df2, "Sheet2", {"validations": {"B": {"type": "whole_number", "min": 0, "max": 10}}}),
                ],
                path,
            )
            assert os.path.exists(path)
        finally:
            os.unlink(path)


class TestErrorPaths:
    """Tests for error handling (v0.10.0)"""

    def test_nonexistent_image_file_raises_error(self):
        """Non-existent image file raises clear error"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, images={"B1": "/nonexistent/path/to/image.png"})
            assert False, "Should have raised an error"
        except ValueError as e:
            assert "Failed to load image" in str(e) or "image" in str(e).lower()
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_validation_list_exceeds_255_chars_raises_error(self):
        """Validation list exceeding 255 chars raises clear error"""
        df = pd.DataFrame({"Status": ["A"]})
        path = get_temp_path()
        # Create values that exceed 255 chars total
        long_values = ["A" * 100, "B" * 100, "C" * 100]  # 300+ chars
        try:
            xlsxturbo.df_to_xlsx(
                df, path, validations={"Status": {"type": "list", "values": long_values}}
            )
            assert False, "Should have raised an error"
        except ValueError as e:
            assert "255" in str(e) and "character" in str(e).lower()
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_invalid_validation_config_raises_error(self):
        """Invalid validation config (not a dict) raises clear error"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, validations={"A": "not_a_dict"})
            assert False, "Should have raised an error"
        except TypeError as e:
            assert "expected dict" in str(e).lower()
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_invalid_rich_text_segment_raises_error(self):
        """Invalid rich_text segment (not string or tuple) raises clear error"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, rich_text={"A1": [123]})  # int is invalid
            assert False, "Should have raised an error"
        except TypeError as e:
            assert "segment" in str(e).lower() and ("string" in str(e).lower() or "tuple" in str(e).lower())
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_wrong_type_column_widths_raises_error(self):
        """Passing a list instead of dict for column_widths raises TypeError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_widths=[10, 20])
            assert False, "Should have raised TypeError"
        except TypeError as e:
            assert "expected dict" in str(e).lower()
            assert "column_widths" in str(e)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_wrong_type_header_format_raises_error(self):
        """Passing a string instead of dict for header_format raises TypeError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format="bold")
            assert False, "Should have raised TypeError"
        except TypeError as e:
            assert "expected dict" in str(e).lower()
            assert "header_format" in str(e)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_wrong_type_merged_ranges_raises_error(self):
        """Passing a dict instead of list for merged_ranges raises TypeError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, merged_ranges={"A1:B1": "Title"})
            assert False, "Should have raised TypeError"
        except TypeError as e:
            assert "expected list" in str(e).lower()
            assert "merged_ranges" in str(e)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_wrong_type_hyperlinks_raises_error(self):
        """Passing a dict instead of list for hyperlinks raises TypeError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, hyperlinks={"A1": "https://example.com"})
            assert False, "Should have raised TypeError"
        except TypeError as e:
            assert "expected list" in str(e).lower()
            assert "hyperlinks" in str(e)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_invalid_rich_text_not_list_raises_error(self):
        """Invalid rich_text value (not a list) raises clear error"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, rich_text={"A1": "not_a_list"})
            assert False, "Should have raised an error"
        except TypeError as e:
            assert "expected list" in str(e).lower()
        finally:
            if os.path.exists(path):
                os.unlink(path)


class TestConditionalFormatting:
    """Tests for conditional formatting feature (v0.8.0)"""

    def test_2_color_scale(self):
        """2-color scale conditional format"""
        df = pd.DataFrame({"Score": [10, 50, 90]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                conditional_formats={
                    "Score": {"type": "2_color_scale", "min_color": "#FF0000", "max_color": "#00FF00"}
                },
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # openpyxl reads conditional formats
                assert len(ws.conditional_formatting) > 0
                wb.close()
        finally:
            os.unlink(path)

    def test_3_color_scale(self):
        """3-color scale conditional format"""
        df = pd.DataFrame({"Value": [1, 5, 10]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                conditional_formats={
                    "Value": {
                        "type": "3_color_scale",
                        "min_color": "#F8696B",
                        "mid_color": "#FFEB84",
                        "max_color": "#63BE7B",
                    }
                },
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert len(ws.conditional_formatting) > 0
                wb.close()
        finally:
            os.unlink(path)

    def test_data_bar(self):
        """Data bar conditional format"""
        df = pd.DataFrame({"Progress": [25, 50, 75, 100]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                conditional_formats={
                    "Progress": {"type": "data_bar", "bar_color": "#638EC6"}
                },
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert len(ws.conditional_formatting) > 0
                wb.close()
        finally:
            os.unlink(path)

    def test_icon_set(self):
        """Icon set conditional format"""
        df = pd.DataFrame({"Status": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                conditional_formats={
                    "Status": {"type": "icon_set", "icon_type": "3_traffic_lights"}
                },
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert len(ws.conditional_formatting) > 0
                wb.close()
        finally:
            os.unlink(path)

    def test_conditional_format_with_pattern(self):
        """Conditional format with wildcard column pattern"""
        df = pd.DataFrame({"score_a": [80], "score_b": [60], "name": ["Alice"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df,
                path,
                conditional_formats={
                    "score_*": {"type": "2_color_scale", "min_color": "#FF0000", "max_color": "#00FF00"}
                },
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Should have conditional formats on both score columns
                assert len(ws.conditional_formatting) >= 1
                wb.close()
        finally:
            os.unlink(path)


class TestConstantMemoryMode:
    """Tests for constant_memory mode (v0.4.0)"""

    def test_basic_constant_memory(self):
        """File is created in constant memory mode"""
        df = pd.DataFrame({"A": list(range(100)), "B": list(range(100, 200))})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path, constant_memory=True)
            assert rows > 0
            assert cols == 2
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].value == "A"  # header
                assert ws["A2"].value == 0  # first data row
                assert ws["B2"].value == 100
                wb.close()
        finally:
            os.unlink(path)

    def test_constant_memory_silently_disables_features(self):
        """Features are silently disabled in constant memory mode (no crash)"""
        df = pd.DataFrame({"Score": [1, 2, 3]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(
                df,
                path,
                constant_memory=True,
                # All these should be silently ignored:
                table_style="Medium9",
                freeze_panes=True,
                autofit=True,
                row_heights={0: 30},
                conditional_formats={"Score": {"type": "data_bar", "bar_color": "#638EC6"}},
                formula_columns={"Double": "=A{row}*2"},
                merged_ranges=[("A1:A1", "Merge")],
                hyperlinks=[("A1", "https://example.com", "Link")],
                comments={"A1": "Comment"},
                validations={"Score": {"type": "whole_number", "min": 0, "max": 100}},
                rich_text={"B1": [("Bold", {"bold": True})]},
            )
            assert rows > 0
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Table should NOT be created
                assert len(ws.tables) == 0
                # Data should still be written
                assert ws["A1"].value == "Score"
                assert ws["A2"].value == 1
                wb.close()
        finally:
            os.unlink(path)

    def test_constant_memory_with_column_widths(self):
        """Column widths still work in constant memory mode"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, constant_memory=True, column_widths={0: 25})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws.column_dimensions["A"].width > 20
                wb.close()
        finally:
            os.unlink(path)


class TestRowHeights:
    """Tests for row_heights parameter (v0.4.0)"""

    def test_basic_row_heights(self):
        """Set specific row heights"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, row_heights={0: 30, 2: 40})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # openpyxl is 1-indexed; Excel may round heights slightly
                assert abs(ws.row_dimensions[1].height - 30) < 1
                assert abs(ws.row_dimensions[3].height - 40) < 1
                # Rows without explicit height should not have customHeight
                assert ws.row_dimensions[2].customHeight is False
                wb.close()
        finally:
            os.unlink(path)

    def test_row_heights_with_dfs_to_xlsx(self):
        """Row heights work per-sheet"""
        df = pd.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [(df, "Sheet1", {"row_heights": {0: 25}})],
                path,
            )
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb["Sheet1"]
                assert abs(ws.row_dimensions[1].height - 25) < 1
                wb.close()
        finally:
            os.unlink(path)

    def test_row_heights_ignored_in_constant_memory(self):
        """Row heights silently ignored in constant memory mode"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, constant_memory=True, row_heights={0: 50})
            assert os.path.exists(path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Row height should NOT be set (constant memory ignores it)
                # Default height is ~15, so it should not be 50
                assert ws.row_dimensions[1].height != 50 or ws.row_dimensions[1].height is None
                wb.close()
        finally:
            os.unlink(path)


class TestUnicodeAndSpecialData:
    """Tests for Unicode, mixed types, nulls, and CSV edge cases."""

    def test_unicode_column_names_and_data(self):
        """Unicode characters in column names and cell data"""
        df = pd.DataFrame({
            "\u4ef7\u683c": [100, 200],       # Chinese: "price"
            "Stra\u00dfe": ["Berlin", "M\u00fcnchen"],  # German: street, Munich
            "\u540d\u524d": ["\u592a\u90ce", "\u82b1\u5b50"],           # Japanese names
        })
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 3  # header + 2 data rows
            assert cols == 3
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].value == "\u4ef7\u683c"
                assert ws["B1"].value == "Stra\u00dfe"
                assert ws["C1"].value == "\u540d\u524d"
                assert ws["B2"].value == "Berlin"
                assert ws["C2"].value == "\u592a\u90ce"
                wb.close()
        finally:
            os.unlink(path)

    def test_emoji_in_data(self):
        """Emoji characters in cell values"""
        df = pd.DataFrame({
            "status": ["done", "pending"],
            "icon": ["\U0001f680", "\U0001f525"],
        })
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 3
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["B2"].value == "\U0001f680"
                assert ws["B3"].value == "\U0001f525"
                wb.close()
        finally:
            os.unlink(path)

    def test_mixed_type_column(self):
        """Column with mixed int and string values (pandas object dtype)"""
        df = pd.DataFrame({"mixed": [1, "two", 3, "four", 5.5]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 6  # header + 5 rows
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].value == 1
                assert ws["A3"].value == "two"
                assert ws["A4"].value == 3
                assert ws["A5"].value == "four"
                assert ws["A6"].value == 5.5
                wb.close()
        finally:
            os.unlink(path)

    def test_none_and_nat_values(self):
        """None, NaT, and pd.NA values write as empty cells"""
        df = pd.DataFrame({
            "a": [1, None, 3],
            "b": pd.array([10, pd.NA, 30], dtype="Int64"),
            "c": pd.to_datetime(["2024-01-01", pd.NaT, "2024-03-01"]),
        })
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 4  # header + 3 rows
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # None/NA cells should be empty
                assert ws["A3"].value is None or ws["A3"].value == ""
                assert ws["B3"].value is None or ws["B3"].value == ""
                assert ws["C3"].value is None or ws["C3"].value == ""
                wb.close()
        finally:
            os.unlink(path)

    def test_all_none_column(self):
        """Column with all None values"""
        df = pd.DataFrame({"empty": [None, None, None]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 4
            assert cols == 1
        finally:
            os.unlink(path)

    def test_large_integers_written_as_strings(self):
        """Integers > 2^53 should be written as strings to prevent precision loss"""
        large_int = 9007199254740993  # 2^53 + 1
        df = pd.DataFrame({"id": [large_int, 42]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 3
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                # Large int should be written as string to preserve precision
                assert str(ws["A2"].value) == str(large_int)
                # Normal int should be a number
                assert ws["A3"].value == 42
                wb.close()
        finally:
            os.unlink(path)

    def test_csv_with_bom(self):
        """CSV file with UTF-8 BOM"""
        csv_path = tempfile.mktemp(suffix=".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", encoding="utf-8-sig") as f:
                f.write("name,value\nAlice,1\nBob,2\n")
            rows, cols = xlsxturbo.csv_to_xlsx(csv_path, xlsx_path)
            assert rows == 3  # header + 2 data rows
            assert cols == 2
        finally:
            os.unlink(xlsx_path)
            if os.path.exists(csv_path):
                os.unlink(csv_path)

    def test_csv_with_crlf(self):
        """CSV file with Windows CRLF line endings"""
        csv_path = tempfile.mktemp(suffix=".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "wb") as f:
                f.write(b"a,b\r\n1,2\r\n3,4\r\n")
            rows, cols = xlsxturbo.csv_to_xlsx(csv_path, xlsx_path)
            assert rows == 3
            assert cols == 2
        finally:
            os.unlink(xlsx_path)
            if os.path.exists(csv_path):
                os.unlink(csv_path)

    def test_csv_quoted_fields_with_delimiters(self):
        """CSV with quoted fields containing commas and newlines"""
        csv_path = tempfile.mktemp(suffix=".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", encoding="utf-8") as f:
                f.write('name,address\n"Smith, John","123 Main St"\n"Doe, Jane","456 Oak Ave"\n')
            rows, cols = xlsxturbo.csv_to_xlsx(csv_path, xlsx_path)
            assert rows == 3
            assert cols == 2
            if HAS_OPENPYXL:
                wb = load_workbook(xlsx_path)
                ws = wb.active
                assert ws["A2"].value == "Smith, John"
                assert ws["B2"].value == "123 Main St"
                wb.close()
        finally:
            os.unlink(xlsx_path)
            if os.path.exists(csv_path):
                os.unlink(csv_path)

    def test_polars_unicode(self):
        """Unicode data through Polars DataFrames"""
        df = pl.DataFrame({
            "city": ["T\u00f6ky\u00f6", "Z\u00fcrich", "S\u00e3o Paulo"],
            "pop": [14000000, 420000, 12300000],
        })
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(df, path)
            assert rows == 4
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].value == "T\u00f6ky\u00f6"
                wb.close()
        finally:
            os.unlink(path)


class TestDefinedNames:
    """Tests for workbook-level defined names (v0.11.0)"""

    def test_single_defined_name(self):
        """Single defined name is created in workbook"""
        df = pd.DataFrame({"a": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path,
                defined_names={"MyRange": "=Sheet1!$A$1:$A$4"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                names = {dn.name: dn.attr_text for dn in wb.defined_names.values()}
                assert "MyRange" in names
                assert "$A$1:$A$4" in names["MyRange"]
                wb.close()
        finally:
            os.unlink(path)

    def test_multiple_defined_names(self):
        """Multiple defined names created"""
        df = pd.DataFrame({"a": [1], "b": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, defined_names={
                "Range1": "=Sheet1!$A$1:$A$2",
                "Range2": "=Sheet1!$B$1:$B$2",
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                names = {dn.name for dn in wb.defined_names.values()}
                assert "Range1" in names
                assert "Range2" in names
                wb.close()
        finally:
            os.unlink(path)

    def test_defined_names_dfs_to_xlsx(self):
        """defined_names works in multi-sheet mode"""
        df1 = pd.DataFrame({"x": [1]})
        df2 = pd.DataFrame({"y": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [(df1, "S1"), (df2, "S2")], path,
                defined_names={"AllData": "=S1!$A$1:$A$2"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                names = {dn.name for dn in wb.defined_names.values()}
                assert "AllData" in names
                wb.close()
        finally:
            os.unlink(path)

    def test_defined_name_with_quoted_sheet(self):
        """Defined name with quoted sheet name containing space"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path,
                sheet_name="LCA Calculator Parameters",
                defined_names={"Settings": "='LCA Calculator Parameters'!$B$13:$D$155"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                names = {dn.name for dn in wb.defined_names.values()}
                assert "Settings" in names
                wb.close()
        finally:
            os.unlink(path)


class TestCells:
    """Tests for arbitrary cell writes (v0.11.0)"""

    def test_simple_string_cell(self):
        """Write a string to a specific cell"""
        df = pd.DataFrame({"a": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={"C1": "hello"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb.active["C1"].value == "hello"
                wb.close()
        finally:
            os.unlink(path)

    def test_numeric_cells(self):
        """Write int and float to cells"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={"B5": 42, "C5": 3.14})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb.active["B5"].value == 42
                assert abs(wb.active["C5"].value - 3.14) < 0.001
                wb.close()
        finally:
            os.unlink(path)

    def test_bool_cell(self):
        """Write boolean to cell"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={"B2": True})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb.active["B2"].value is True
                wb.close()
        finally:
            os.unlink(path)

    def test_cell_with_num_format(self):
        """Dict-style cell with num_format preserves text format"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={
                "D6": {"value": "934728173849", "num_format": "@"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb.active["D6"]
                assert cell.value == "934728173849"
                assert cell.number_format == "@"
                wb.close()
        finally:
            os.unlink(path)

    def test_cell_overwrites_dataframe_data(self):
        """cells parameter overwrites existing DataFrame values"""
        df = pd.DataFrame({"a": ["original"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={"A2": "overwritten"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb.active["A2"].value == "overwritten"
                wb.close()
        finally:
            os.unlink(path)

    def test_cell_dict_missing_value_key(self):
        """Dict-style cell without 'value' key raises ValueError"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError, match="missing 'value' key"):
                xlsxturbo.df_to_xlsx(df, path, cells={"A1": {"num_format": "@"}})
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_invalid_cell_ref(self):
        """Invalid cell reference raises ValueError"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError):
                xlsxturbo.df_to_xlsx(df, path, cells={"ZZZZ1": "x"})
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_cells_per_sheet_override(self):
        """Per-sheet cells override global cells in dfs_to_xlsx"""
        df1 = pd.DataFrame({"a": [1]})
        df2 = pd.DataFrame({"b": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [(df1, "S1"), (df2, "S2", {"cells": {"C1": "per-sheet"}})],
                path, cells={"C1": "global"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb["S1"]["C1"].value == "global"
                assert wb["S2"]["C1"].value == "per-sheet"
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_constant_memory_warns(self):
        """cells with constant_memory emits a warning"""
        df = pd.DataFrame({"a": [1, 2]})
        path = get_temp_path()
        try:
            import warnings
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                xlsxturbo.df_to_xlsx(df, path, constant_memory=True,
                    cells={"C1": "test"})
                assert len(w) == 1
                assert "cells" in str(w[0].message)
        finally:
            os.unlink(path)

    def test_num_format_wrong_type_raises(self):
        """Non-string num_format raises TypeError"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(TypeError):
                xlsxturbo.df_to_xlsx(df, path,
                    cells={"A1": {"value": "x", "num_format": 123}})
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_cells_with_polars(self):
        """cells work with polars DataFrames"""
        df = pl.DataFrame({"a": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={"C1": "extra"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb.active["C1"].value == "extra"
                wb.close()
        finally:
            os.unlink(path)


class TestCellsPerSheet:
    """Tests for cells with per-sheet SheetOptions in dfs_to_xlsx (item 6)"""

    def test_cells_per_sheet_3tuple(self):
        """Per-sheet cells override via 3-tuple SheetOptions"""
        df1 = pd.DataFrame({"a": [1, 2]})
        df2 = pd.DataFrame({"b": [3, 4]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx([
                (df1, "Sheet1", {"cells": {"C1": "note1", "C2": 100}}),
                (df2, "Sheet2", {"cells": {"C1": "note2"}}),
            ], path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb["Sheet1"]["C1"].value == "note1"
                assert wb["Sheet1"]["C2"].value == 100
                assert wb["Sheet2"]["C1"].value == "note2"
                assert wb["Sheet2"]["C2"].value is None
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_per_sheet_overrides_global(self):
        """Per-sheet cells replace (not merge with) global cells"""
        df1 = pd.DataFrame({"a": [1]})
        df2 = pd.DataFrame({"a": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx([
                (df1, "S1"),
                (df2, "S2", {"cells": {"D1": "override"}}),
            ], path, cells={"C1": "global"})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                # S1 gets global cells
                assert wb["S1"]["C1"].value == "global"
                # S2 gets per-sheet cells (override replaces global)
                assert wb["S2"]["D1"].value == "override"
                assert wb["S2"]["C1"].value is None
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_per_sheet_with_num_format(self):
        """Per-sheet cells with num_format via SheetOptions"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx([
                (df, "S1", {"cells": {
                    "C1": {"value": "12345", "num_format": "@"}
                }}),
            ], path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb["S1"]["C1"]
                assert str(cell.value) == "12345"
                assert cell.number_format == "@"
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_per_sheet_with_alignment(self):
        """Per-sheet cells with alignment via SheetOptions"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx([
                (df, "S1", {"cells": {
                    "C1": {"value": "centered", "align_horizontal": "center"}
                }}),
            ], path)
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb["S1"]["C1"]
                assert cell.value == "centered"
                assert cell.alignment.horizontal == "center"
                wb.close()
        finally:
            os.unlink(path)


class TestCellsFormatting:
    """Tests for cells with formatting options beyond num_format (item 7)"""

    def test_cells_with_horizontal_alignment(self):
        """cells with align_horizontal"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={
                "C1": {"value": "right-aligned", "align_horizontal": "right"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb.active["C1"]
                assert cell.value == "right-aligned"
                assert cell.alignment.horizontal == "right"
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_with_vertical_alignment(self):
        """cells with align_vertical"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={
                "C1": {"value": "top", "align_vertical": "top"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb.active["C1"]
                assert cell.value == "top"
                assert cell.alignment.vertical == "top"
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_with_wrap_text(self):
        """cells with wrap_text"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={
                "C1": {"value": "long text here", "wrap_text": True}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb.active["C1"]
                assert cell.value == "long text here"
                assert cell.alignment.wrapText is True
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_with_combined_formatting(self):
        """cells with num_format + alignment + wrap_text together"""
        df = pd.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={
                "C1": {
                    "value": 0.15,
                    "num_format": "0.00%",
                    "align_horizontal": "center",
                    "align_vertical": "top",
                    "wrap_text": True
                }
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb.active["C1"]
                assert cell.number_format == "0.00%"
                assert cell.alignment.horizontal == "center"
                assert cell.alignment.vertical == "top"
                assert cell.alignment.wrapText is True
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_formatting_with_polars(self):
        """cells formatting works with polars DataFrames"""
        df = pl.DataFrame({"a": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={
                "C1": {"value": "test", "align_horizontal": "center"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                cell = wb.active["C1"]
                assert cell.value == "test"
                assert cell.alignment.horizontal == "center"
                wb.close()
        finally:
            os.unlink(path)


class TestBorderStyles:
    """Tests for per-side border styles (v0.12.0)"""

    def test_border_bool_backward_compat(self):
        """border=True still applies thin border on all sides"""
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border": True}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.left.style == "thin"
                assert cell.border.right.style == "thin"
                assert cell.border.top.style == "thin"
                assert cell.border.bottom.style == "thin"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_string_all_sides(self):
        """border='thick' applies thick border on all 4 sides"""
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border": "thick"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.left.style == "thick"
                assert cell.border.right.style == "thick"
                assert cell.border.top.style == "thick"
                assert cell.border.bottom.style == "thick"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_right_only(self):
        """border_right='thick' applies thick right border only"""
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border_right": "thick"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.right.style == "thick"
                assert cell.border.left.style is None
                assert cell.border.top.style is None
                assert cell.border.bottom.style is None
                wb.close()
        finally:
            os.unlink(path)

    def test_border_left_and_right(self):
        """Mixed per-side borders"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border_left": "medium", "border_right": "thick"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.left.style == "medium"
                assert cell.border.right.style == "thick"
                assert cell.border.top.style is None
                assert cell.border.bottom.style is None
                wb.close()
        finally:
            os.unlink(path)

    def test_border_all_four_sides_individually(self):
        """All four sides set independently"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {
                    "border_left": "thin",
                    "border_right": "thick",
                    "border_top": "medium",
                    "border_bottom": "dashed",
                }
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.left.style == "thin"
                assert cell.border.right.style == "thick"
                assert cell.border.top.style == "medium"
                assert cell.border.bottom.style == "dashed"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_string_thin(self):
        """border='thin' is equivalent to border=True"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border": "thin"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.left.style == "thin"
                assert cell.border.right.style == "thin"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_with_wildcard_pattern(self):
        """Per-side borders work with wildcard column matching"""
        df = pd.DataFrame({"price_usd": [10], "price_eur": [9], "name": ["x"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "price_*": {"border_right": "thick"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].border.right.style == "thick"
                assert ws["B2"].border.right.style == "thick"
                assert ws["C2"].border.right.style is None
                wb.close()
        finally:
            os.unlink(path)

    def test_border_color(self):
        """border_color sets color for all borders"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border": "thin", "border_color": "red"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.left.style == "thin"
                assert cell.border.left.color is not None
                assert cell.border.left.color.rgb.endswith("FF0000")
                wb.close()
        finally:
            os.unlink(path)

    def test_invalid_border_style_raises(self):
        """Invalid border style string raises ValueError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError, match="Unknown border style"):
                xlsxturbo.df_to_xlsx(df, path, column_formats={
                    "A": {"border": "invalid_style"}
                })
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_border_with_other_formats(self):
        """Border styles combine with other column format options"""
        df = pd.DataFrame({"A": [1.5]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border_right": "thick", "bold": True, "num_format": "0.00"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.right.style == "thick"
                assert cell.font.bold
                assert cell.number_format == "0.00"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_per_side_overrides_all(self):
        """Per-side border overrides all-sides border for that side"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border": "thin", "border_right": "thick"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.left.style == "thin"
                assert cell.border.right.style == "thick"
                assert cell.border.top.style == "thin"
                assert cell.border.bottom.style == "thin"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_medium_style(self):
        """Medium border style works"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border": "medium"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].border.left.style == "medium"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_double_style(self):
        """Double border style works"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border_bottom": "double"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].border.bottom.style == "double"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_with_polars(self):
        """Border styles work with polars DataFrames"""
        df = pl.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border_right": "thick"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].border.right.style == "thick"
                wb.close()
        finally:
            os.unlink(path)

    def test_border_right_bool_treated_as_thin(self):
        """border_right=True (bool) applies thin right border"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"border_right": True}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.border.right.style == "thin"
                assert cell.border.left.style is None
                wb.close()
        finally:
            os.unlink(path)

    def test_header_format_border(self):
        """header_format supports border styles"""
        df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format={
                "bold": True, "border": "thick"
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                header = ws["A1"]
                assert header.border.left.style == "thick"
                assert header.border.right.style == "thick"
                wb.close()
        finally:
            os.unlink(path)

    def test_header_format_border_right_only(self):
        """header_format supports per-side borders"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format={
                "border_bottom": "medium"
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                header = ws["A1"]
                assert header.border.bottom.style == "medium"
                assert header.border.top.style is None
                wb.close()
        finally:
            os.unlink(path)

    def test_border_dfs_to_xlsx_per_sheet(self):
        """Per-side borders work with dfs_to_xlsx per-sheet overrides"""
        df1 = pd.DataFrame({"A": [1]})
        df2 = pd.DataFrame({"A": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx([
                (df1, "S1"),
                (df2, "S2", {"column_formats": {"A": {"border_right": "thick"}}})
            ], path, column_formats={"A": {"border": "thin"}})
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                assert wb["S1"]["A2"].border.left.style == "thin"
                assert wb["S2"]["A2"].border.right.style == "thick"
                wb.close()
        finally:
            os.unlink(path)


class TestTextAlignment:
    """Tests for text alignment (v0.12.0)"""

    def test_column_format_horizontal_center(self):
        """align_horizontal='center' centers cell text"""
        df = pd.DataFrame({"A": ["hello", "world"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"align_horizontal": "center"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].alignment.horizontal == "center"
                wb.close()
        finally:
            os.unlink(path)

    def test_column_format_horizontal_right(self):
        """align_horizontal='right' right-aligns cell text"""
        df = pd.DataFrame({"A": ["hello"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"align_horizontal": "right"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].alignment.horizontal == "right"
                wb.close()
        finally:
            os.unlink(path)

    def test_column_format_vertical_top(self):
        """align_vertical='top' top-aligns cell text"""
        df = pd.DataFrame({"A": ["hello"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"align_vertical": "top"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].alignment.vertical == "top"
                wb.close()
        finally:
            os.unlink(path)

    def test_column_format_vertical_center(self):
        """align_vertical='center' vertically centers cell text"""
        df = pd.DataFrame({"A": ["hello"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"align_vertical": "center"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].alignment.vertical == "center"
                wb.close()
        finally:
            os.unlink(path)

    def test_column_format_wrap_text(self):
        """wrap_text=True enables text wrapping"""
        df = pd.DataFrame({"A": ["hello world this is a long text"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"wrap_text": True}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].alignment.wrapText is True
                wb.close()
        finally:
            os.unlink(path)

    def test_column_format_combined_alignment(self):
        """Horizontal + vertical + wrap_text together"""
        df = pd.DataFrame({"A": ["hello"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"align_horizontal": "center", "align_vertical": "top", "wrap_text": True}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.alignment.horizontal == "center"
                assert cell.alignment.vertical == "top"
                assert cell.alignment.wrapText is True
                wb.close()
        finally:
            os.unlink(path)

    def test_header_format_alignment(self):
        """header_format supports alignment"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, header_format={
                "bold": True, "align_horizontal": "center", "wrap_text": True
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                header = ws["A1"]
                assert header.alignment.horizontal == "center"
                assert header.alignment.wrapText is True
                wb.close()
        finally:
            os.unlink(path)

    def test_merged_range_alignment(self):
        """merged_ranges format supports alignment"""
        df = pd.DataFrame({"A": [1], "B": [2], "C": [3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, merged_ranges=[
                ("A1:C1", "Title", {"bold": True, "align_horizontal": "left"})
            ])
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].alignment.horizontal == "left"
                wb.close()
        finally:
            os.unlink(path)

    def test_merged_range_default_center(self):
        """merged_ranges without format still auto-center"""
        df = pd.DataFrame({"A": [1], "B": [2]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, merged_ranges=[
                ("A1:B1", "Title")
            ])
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A1"].alignment.horizontal == "center"
                wb.close()
        finally:
            os.unlink(path)

    def test_cells_alignment(self):
        """cells parameter supports alignment options"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, cells={
                "C1": {"value": "Header", "align_horizontal": "center", "wrap_text": True}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["C1"]
                assert cell.value == "Header"
                assert cell.alignment.horizontal == "center"
                assert cell.alignment.wrapText is True
                wb.close()
        finally:
            os.unlink(path)

    def test_alignment_with_wildcard(self):
        """Alignment works with wildcard column patterns"""
        df = pd.DataFrame({"desc_a": ["x"], "desc_b": ["y"], "num": [1]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "desc_*": {"align_horizontal": "left", "wrap_text": True}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].alignment.horizontal == "left"
                assert ws["A2"].alignment.wrapText is True
                assert ws["B2"].alignment.horizontal == "left"
                assert ws["C2"].alignment.horizontal is None
                wb.close()
        finally:
            os.unlink(path)

    def test_alignment_with_border(self):
        """Alignment combines with border styles"""
        df = pd.DataFrame({"A": ["hello"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"align_horizontal": "center", "border": "thin"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cell = ws["A2"]
                assert cell.alignment.horizontal == "center"
                assert cell.border.left.style == "thin"
                wb.close()
        finally:
            os.unlink(path)

    def test_invalid_horizontal_alignment_raises(self):
        """Invalid horizontal alignment raises ValueError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError, match="Unknown horizontal alignment"):
                xlsxturbo.df_to_xlsx(df, path, column_formats={
                    "A": {"align_horizontal": "middle"}
                })
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_invalid_vertical_alignment_raises(self):
        """Invalid vertical alignment raises ValueError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError, match="Unknown vertical alignment"):
                xlsxturbo.df_to_xlsx(df, path, column_formats={
                    "A": {"align_vertical": "left"}
                })
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_alignment_with_polars(self):
        """Alignment works with polars DataFrames"""
        df = pl.DataFrame({"A": ["hello"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, column_formats={
                "A": {"align_horizontal": "center"}
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                assert ws["A2"].alignment.horizontal == "center"
                wb.close()
        finally:
            os.unlink(path)


class TestCellConditionalFormat:
    """Tests for rule-based conditional formatting (v0.12.0)"""

    def test_cell_equal_to_string(self):
        """type='cell' with criteria='equal_to' highlights matching string cells"""
        df = pd.DataFrame({"status": ["OK", "ERROR", "OK", "ERROR"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "status": {
                    "type": "cell",
                    "criteria": "equal_to",
                    "value": "ERROR",
                    "format": {"bg_color": "#FF0000", "bold": True}
                }
            })
            assert os.path.exists(path)
            assert os.path.getsize(path) > 0
        finally:
            os.unlink(path)

    def test_cell_equal_to_number(self):
        """type='cell' with numeric value"""
        df = pd.DataFrame({"score": [50, 75, 100, 25]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "score": {
                    "type": "cell",
                    "criteria": "greater_than",
                    "value": 70,
                    "format": {"bg_color": "#00FF00"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_between(self):
        """between criteria with min_value and max_value"""
        df = pd.DataFrame({"temp": [10, 20, 30, 40, 50]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "temp": {
                    "type": "cell",
                    "criteria": "between",
                    "min_value": 20,
                    "max_value": 40,
                    "format": {"bg_color": "#FFFF00"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_not_between(self):
        """not_between criteria"""
        df = pd.DataFrame({"val": [1, 5, 10, 15]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "val": {
                    "type": "cell",
                    "criteria": "not_between",
                    "min_value": 3,
                    "max_value": 12,
                    "format": {"font_color": "red"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_multiple_rules_list(self):
        """Multiple rules on one column via list"""
        df = pd.DataFrame({"severity": ["HIGH", "MEDIUM", "LOW", "HIGH"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "severity": [
                    {"type": "cell", "criteria": "equal_to", "value": "HIGH",
                     "format": {"bg_color": "#FF0000"}},
                    {"type": "cell", "criteria": "equal_to", "value": "MEDIUM",
                     "format": {"bg_color": "#FFA500"}},
                    {"type": "cell", "criteria": "equal_to", "value": "LOW",
                     "format": {"bg_color": "#FFFF00"}},
                ]
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_text_containing(self):
        """criteria='containing' for text match"""
        df = pd.DataFrame({"desc": ["error occurred", "all good", "error found"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "desc": {
                    "type": "cell",
                    "criteria": "containing",
                    "value": "error",
                    "format": {"bg_color": "#FF0000"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_text_begins_with(self):
        """criteria='begins_with' for text match"""
        df = pd.DataFrame({"code": ["ERR-001", "OK-002", "ERR-003"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "code": {
                    "type": "cell",
                    "criteria": "begins_with",
                    "value": "ERR",
                    "format": {"font_color": "red"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_text_ends_with(self):
        """criteria='ends_with' for text match"""
        df = pd.DataFrame({"file": ["report.pdf", "data.csv", "notes.pdf"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "file": {
                    "type": "cell",
                    "criteria": "ends_with",
                    "value": ".pdf",
                    "format": {"italic": True}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_blanks(self):
        """criteria='blanks' highlights blank cells"""
        df = pd.DataFrame({"val": [1, None, 3, None]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "val": {
                    "type": "cell",
                    "criteria": "blanks",
                    "format": {"bg_color": "#CCCCCC"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_no_blanks(self):
        """criteria='no_blanks' highlights non-blank cells"""
        df = pd.DataFrame({"val": [1, None, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "val": {
                    "type": "cell",
                    "criteria": "no_blanks",
                    "format": {"bg_color": "#00FF00"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_backward_compat_single_dict(self):
        """Existing single-dict format still works (backward compat)"""
        df = pd.DataFrame({"score": [10, 50, 90]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "score": {"type": "2_color_scale", "min_color": "#FF0000", "max_color": "#00FF00"}
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_less_than(self):
        """less_than criteria"""
        df = pd.DataFrame({"price": [10.5, 20.0, 5.0]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "price": {
                    "type": "cell",
                    "criteria": "less_than",
                    "value": 15,
                    "format": {"bg_color": "#FF0000"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_with_pattern_matching(self):
        """Cell conditional format works with wildcard patterns"""
        df = pd.DataFrame({"score_a": [50], "score_b": [80], "name": ["x"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "score_*": {
                    "type": "cell",
                    "criteria": "greater_than",
                    "value": 60,
                    "format": {"bold": True}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_format_with_border(self):
        """Cell conditional format can include border styling"""
        df = pd.DataFrame({"val": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "val": {
                    "type": "cell",
                    "criteria": "equal_to",
                    "value": 2,
                    "format": {"bg_color": "#FFFF00", "border": "thin"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_invalid_criteria_raises(self):
        """Invalid criteria raises ValueError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError, match="Unknown criteria"):
                xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                    "A": {"type": "cell", "criteria": "invalid", "value": 1,
                           "format": {"bold": True}}
                })
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_missing_criteria_raises(self):
        """Missing criteria key raises ValueError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError, match="requires 'criteria'"):
                xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                    "A": {"type": "cell", "value": 1, "format": {"bold": True}}
                })
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_cell_with_polars(self):
        """Cell conditional format works with polars"""
        df = pl.DataFrame({"score": [50, 75, 100]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "score": {
                    "type": "cell",
                    "criteria": "greater_than_or_equal_to",
                    "value": 75,
                    "format": {"bg_color": "#00FF00"}
                }
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_not_equal_to(self):
        """not_equal_to criteria"""
        df = pd.DataFrame({"A": ["ok", "fail", "ok"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "A": {"type": "cell", "criteria": "not_equal_to", "value": "ok",
                       "format": {"bg_color": "#FF0000"}}
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_less_than_or_equal_to(self):
        """less_than_or_equal_to criteria"""
        df = pd.DataFrame({"A": [1, 5, 10]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "A": {"type": "cell", "criteria": "less_than_or_equal_to", "value": 5,
                       "format": {"bold": True}}
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_not_containing(self):
        """not_containing criteria"""
        df = pd.DataFrame({"A": ["hello world", "goodbye", "hello"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "A": {"type": "cell", "criteria": "not_containing", "value": "hello",
                       "format": {"italic": True}}
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_without_format_key(self):
        """Cell rule without format key still works (no styling applied)"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "A": {"type": "cell", "criteria": "greater_than", "value": 1}
            })
            assert os.path.exists(path)
        finally:
            os.unlink(path)

    def test_cell_missing_value_raises(self):
        """Missing value key for value-requiring criteria raises ValueError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(ValueError, match="missing 'value'"):
                xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                    "A": {"type": "cell", "criteria": "greater_than",
                           "format": {"bold": True}}
                })
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_cell_numeric_comparison_correct(self):
        """Numeric values produce numeric (not string) comparisons in Excel"""
        df = pd.DataFrame({"score": [8, 50, 70, 100]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "score": {
                    "type": "cell",
                    "criteria": "greater_than",
                    "value": 70,
                    "format": {"bg_color": "#00FF00"}
                }
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cf_rules = ws.conditional_formatting
                assert len(list(cf_rules)) > 0
                rule = list(cf_rules)[0]
                cf = rule.rules[0]
                assert cf.type == "cellIs"
                assert cf.operator == "greaterThan"
                assert cf.formula == ['70']
                wb.close()
        finally:
            os.unlink(path)

    def test_cell_string_comparison_correct(self):
        """String values produce string comparisons in Excel"""
        df = pd.DataFrame({"status": ["OK", "ERROR", "OK"]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                "status": {
                    "type": "cell",
                    "criteria": "equal_to",
                    "value": "ERROR",
                    "format": {"bg_color": "#FF0000"}
                }
            })
            if HAS_OPENPYXL:
                wb = load_workbook(path)
                ws = wb.active
                cf_rules = ws.conditional_formatting
                assert len(list(cf_rules)) > 0
                rule = list(cf_rules)[0]
                cf = rule.rules[0]
                assert cf.type == "cellIs"
                assert cf.operator == "equal"
                assert cf.formula == ['"ERROR"']
                wb.close()
        finally:
            os.unlink(path)

    def test_invalid_list_item_raises(self):
        """Non-dict item in conditional format list raises TypeError"""
        df = pd.DataFrame({"A": [1]})
        path = get_temp_path()
        try:
            import pytest
            with pytest.raises(TypeError, match="list item .* must be a dict"):
                xlsxturbo.df_to_xlsx(df, path, conditional_formats={
                    "A": [{"type": "cell", "criteria": "equal_to", "value": 1,
                            "format": {"bold": True}}, "not_a_dict"]
                })
        finally:
            if os.path.exists(path):
                os.unlink(path)


class TestCsvErrorPaths:
    """Tests for CSV conversion error handling"""

    def test_csv_nonexistent_input_raises_error(self):
        """csv_to_xlsx with nonexistent input file raises ValueError with path info"""
        path = get_temp_path()
        try:
            with pytest.raises(ValueError, match="Failed to open"):
                xlsxturbo.csv_to_xlsx("/nonexistent/file.csv", path)
        finally:
            if os.path.exists(path):
                os.unlink(path)


class TestConstantMemoryWarning:
    """Tests for constant_memory warning emission"""

    def test_constant_memory_warns_on_incompatible_options(self):
        """constant_memory=True with incompatible options emits RuntimeWarning"""
        import warnings

        df = pd.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                xlsxturbo.df_to_xlsx(
                    df, path,
                    constant_memory=True,
                    table_style="Medium2",
                    freeze_panes=True,
                )
                assert len(w) == 1
                assert issubclass(w[0].category, RuntimeWarning)
                assert "table_style" in str(w[0].message)
                assert "freeze_panes" in str(w[0].message)
        finally:
            os.unlink(path)

    def test_constant_memory_no_warning_when_clean(self):
        """constant_memory=True without incompatible options emits no warning"""
        import warnings

        df = pd.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                xlsxturbo.df_to_xlsx(df, path, constant_memory=True)
                assert len(w) == 0
        finally:
            os.unlink(path)


class TestDefinedNamesVerification:
    """Tests for defined_names with content verification"""

    def test_defined_names_written(self):
        """defined_names are written to the workbook"""
        df = pd.DataFrame({"A": [1, 2, 3]})
        path = get_temp_path()
        try:
            xlsxturbo.df_to_xlsx(
                df, path,
                defined_names={"MyRange": "=Sheet1!$A$1:$A$4"},
            )
            wb = load_workbook(path)
            assert "MyRange" in wb.defined_names
            wb.close()
        finally:
            os.unlink(path)

    def test_defined_names_multi_sheet(self):
        """defined_names work with dfs_to_xlsx"""
        df = pd.DataFrame({"A": [1, 2]})
        path = get_temp_path()
        try:
            xlsxturbo.dfs_to_xlsx(
                [(df, "Data")], path,
                defined_names={"Total": "=Data!$A$1:$A$3"},
            )
            wb = load_workbook(path)
            assert "Total" in wb.defined_names
            wb.close()
        finally:
            os.unlink(path)


class TestFormulaColumnsHeaderFalse:
    """Regression tests for formula_columns with header=False (v0.10.5 fix)"""

    def test_formula_columns_header_false(self):
        """Formula columns work correctly when header=False"""
        df = pd.DataFrame({"A": [10, 20], "B": [1, 2]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(
                df, path,
                header=False,
                formula_columns={"Sum": "=A{row}+B{row}"},
            )
            assert cols == 3  # 2 data + 1 formula
            wb = load_workbook(path)
            ws = wb.active
            # Row 1 should have data, not headers
            assert ws["A1"].value == 10
            # Formula column should be in C (0-indexed col 2)
            assert ws["C1"].value is not None
            wb.close()
        finally:
            os.unlink(path)

    def test_formula_columns_header_true(self):
        """Formula columns still work correctly when header=True"""
        df = pd.DataFrame({"A": [10, 20], "B": [1, 2]})
        path = get_temp_path()
        try:
            rows, cols = xlsxturbo.df_to_xlsx(
                df, path,
                header=True,
                formula_columns={"Sum": "=A{row}+B{row}"},
            )
            assert cols == 3
            wb = load_workbook(path)
            ws = wb.active
            # Row 1 should have headers
            assert ws["A1"].value == "A"
            assert ws["C1"].value == "Sum"
            # Row 2 should have data
            assert ws["A2"].value == 10
            wb.close()
        finally:
            os.unlink(path)


class TestPreEpochDates:
    """Tests for dates before Excel epoch (1900-01-01)"""

    def test_pre_epoch_date_csv_becomes_string(self):
        """CSV dates before 1900 are written as strings, not invalid serial numbers"""
        import csv
        import tempfile

        csv_path = tempfile.mktemp(suffix=".csv")
        xlsx_path = get_temp_path()
        try:
            with open(csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["date", "value"])
                writer.writerow(["1899-01-01", "old"])
                writer.writerow(["2024-01-15", "new"])
            xlsxturbo.csv_to_xlsx(csv_path, xlsx_path)
            wb = load_workbook(xlsx_path)
            ws = wb.active
            # Pre-epoch date should be a string
            assert ws["A2"].value == "1899-01-01"
            wb.close()
        finally:
            if os.path.exists(csv_path):
                os.unlink(csv_path)
            os.unlink(xlsx_path)


if __name__ == "__main__":
    import sys

    # Run simple tests without pytest
    test_classes = [
        TestColumnWidthCap,
        TestTableName,
        TestHeaderFormat,
        TestBackwardCompatibility,
        TestPolarsSupport,
        TestAllFeaturesCombined,
        TestEdgeCases,
        TestDateOrder,
        TestFormulaColumns,
        TestMergedRanges,
        TestHyperlinks,
        TestCsvConversion,
        TestComments,
        TestValidations,
        TestRichText,
        TestImages,
        TestV10AllFeatures,
        TestErrorPaths,
        TestConditionalFormatting,
        TestConstantMemoryMode,
        TestRowHeights,
        TestUnicodeAndSpecialData,
        TestDefinedNames,
        TestCells,
        TestCellsPerSheet,
        TestCellsFormatting,
        TestBorderStyles,
        TestTextAlignment,
        TestCellConditionalFormat,
        TestCsvErrorPaths,
        TestConstantMemoryWarning,
        TestDefinedNamesVerification,
        TestFormulaColumnsHeaderFalse,
        TestPreEpochDates,
    ]

    failed = 0
    passed = 0

    for test_class in test_classes:
        instance = test_class()
        for method_name in dir(instance):
            if method_name.startswith("test_"):
                try:
                    getattr(instance, method_name)()
                    print(f"[PASS] {test_class.__name__}.{method_name}")
                    passed += 1
                except Exception as e:
                    print(f"[FAIL] {test_class.__name__}.{method_name}: {e}")
                    failed += 1

    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
