from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, ClassVar, cast

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, SpanExportResult
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import SpanKind, StatusCode

from bentolabs_sdk import BentoLabsTraceExporter


class _Handler(BaseHTTPRequestHandler):
    payloads: ClassVar[list[dict[str, Any]]] = []
    auth_headers: ClassVar[list[str | None]] = []

    def do_POST(self) -> None:
        length = int(self.headers["content-length"])
        body = self.rfile.read(length)
        self.__class__.payloads.append(json.loads(body))
        self.__class__.auth_headers.append(self.headers.get("authorization"))
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.end_headers()
        self.wfile.write(b"{}")

    def log_message(self, format: str, *args: object) -> None:
        return


def _server() -> tuple[ThreadingHTTPServer, str]:
    _Handler.payloads = []
    _Handler.auth_headers = []
    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    host, port = cast(tuple[str, int], server.server_address)
    return server, f"http://{host}:{port}"


def test_exporter_posts_otlp_json() -> None:
    server, base_url = _server()
    provider = TracerProvider()
    exporter = BentoLabsTraceExporter(api_key="bl_pk_test", base_url=base_url)
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    tracer = provider.get_tracer("bentolabs-test", "1.0.0")

    try:
        with (
            tracer.start_as_current_span(
                "agent.run",
                attributes={"input.value": "hello", "session.id": "py-test"},
            ),
            tracer.start_as_current_span(
                "tool.lookup",
                kind=SpanKind.INTERNAL,
                attributes={
                    "openinference.span.kind": "tool",
                    "output.value": json.dumps({"error": "missing"}),
                },
            ) as child,
        ):
            child.set_status(StatusCode.ERROR, "missing")

        assert provider.force_flush()
    finally:
        provider.shutdown()
        server.shutdown()

    assert _Handler.auth_headers == ["Bearer bl_pk_test", "Bearer bl_pk_test"]
    spans = [
        span
        for payload in _Handler.payloads
        for resource_span in payload["resourceSpans"]
        for scope_span in resource_span["scopeSpans"]
        for span in scope_span["spans"]
    ]
    assert {span["name"] for span in spans} == {"agent.run", "tool.lookup"}
    child_payload = next(span for span in spans if span["name"] == "tool.lookup")
    assert child_payload["status"]["code"] == 2
    assert child_payload["attributes"]


def test_exporter_returns_failure_for_bad_endpoint() -> None:
    memory_exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(memory_exporter))
    tracer = provider.get_tracer("bentolabs-test")
    with tracer.start_as_current_span("agent.run"):
        pass
    provider.shutdown()

    exporter = BentoLabsTraceExporter(api_key="bl_pk_test", base_url="http://127.0.0.1:9")

    result = exporter.export(memory_exporter.get_finished_spans())

    assert result is SpanExportResult.FAILURE
