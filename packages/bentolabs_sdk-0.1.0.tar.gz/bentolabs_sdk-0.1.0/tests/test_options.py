from __future__ import annotations

import pytest

from bentolabs_sdk import DEFAULT_BASE_URL, BentoAuthError, resolve_options


def test_resolve_options_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("BENTOLABS_API_KEY", "bl_pk_test")
    monkeypatch.setenv("BENTOLABS_BASE_URL", "http://localhost:8080/")

    cfg = resolve_options()

    assert cfg.api_key == "bl_pk_test"
    assert cfg.base_url == "http://localhost:8080"


def test_explicit_options_override_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("BENTOLABS_API_KEY", "bl_pk_env")
    monkeypatch.setenv("BENTOLABS_BASE_URL", "http://env")

    cfg = resolve_options(api_key="bl_pk_arg", base_url="http://arg/")

    assert cfg.api_key == "bl_pk_arg"
    assert cfg.base_url == "http://arg"


def test_default_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("BENTOLABS_API_KEY", "bl_pk_test")
    monkeypatch.delenv("BENTOLABS_BASE_URL", raising=False)

    assert resolve_options().base_url == DEFAULT_BASE_URL


def test_missing_api_key_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("BENTOLABS_API_KEY", raising=False)

    with pytest.raises(BentoAuthError) as exc:
        resolve_options()

    assert exc.value.code == "missing_api_key"


def test_invalid_api_key_raises() -> None:
    with pytest.raises(BentoAuthError) as exc:
        resolve_options(api_key="bad")

    assert exc.value.code == "invalid_api_key_format"
