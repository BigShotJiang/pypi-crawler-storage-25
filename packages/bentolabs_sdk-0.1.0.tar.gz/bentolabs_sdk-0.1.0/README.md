# bentolabs-sdk

Official [BentoLabs](https://bentolabs.ai) Python SDK. A drop-in OpenTelemetry span processor that ships traces to the BentoLabs ingest API over OTLP/HTTP+JSON.

> **Status:** `0.1.0`. Stable surface for `api_key` / `base_url` resolution and OTel ingest. Higher-level helpers can land on top of this package later.

## Install

```bash
pip install bentolabs-sdk opentelemetry-api opentelemetry-sdk
```

## Usage

```python
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider

from bentolabs_sdk import BentoLabsSpanProcessor

provider = TracerProvider()
provider.add_span_processor(BentoLabsSpanProcessor())
trace.set_tracer_provider(provider)

tracer = trace.get_tracer("example")
with tracer.start_as_current_span("agent.run") as span:
    span.set_attribute("input.value", "Summarize the incident")
    span.set_attribute("output.value", "The incident is resolved.")

provider.force_flush()
provider.shutdown()
```

The processor batches spans with OpenTelemetry defaults and POSTs them to `${base_url}/v1/traces` with `Authorization: Bearer bl_pk_...`. The `bl_pk_` prefix is validated up front.

### Configuration

```python
from bentolabs_sdk import resolve_options

cfg = resolve_options()
```

| Field | Resolution order |
| --- | --- |
| `api_key` | explicit argument -> `BENTOLABS_API_KEY` -> raises `BentoAuthError` |
| `base_url` | explicit argument -> `BENTOLABS_BASE_URL` -> `https://api.bentolabs.ai` |

```python
from bentolabs_sdk import BentoAuthError, BentoLabsSpanProcessor

try:
    processor = BentoLabsSpanProcessor(base_url="http://localhost:8080")
except BentoAuthError as exc:
    if exc.code == "missing_api_key":
        # telemetry disabled or misconfigured
        pass
    raise
```

## Requirements

- Python 3.10+

## License

Proprietary. Copyright (c) 2026 BentoLabs, Inc. All rights reserved. Use is governed by your written agreement with BentoLabs, Inc.
