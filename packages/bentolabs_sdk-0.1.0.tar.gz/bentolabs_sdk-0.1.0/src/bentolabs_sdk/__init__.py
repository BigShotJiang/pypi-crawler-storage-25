"""BentoLabs Python SDK."""

from __future__ import annotations

from bentolabs_sdk.errors import BentoAuthError, BentoAuthErrorCode
from bentolabs_sdk.exporter import BentoLabsSpanProcessor, BentoLabsTraceExporter
from bentolabs_sdk.options import (
    API_KEY_PREFIX,
    DEFAULT_BASE_URL,
    BentoConfig,
    resolve_api_key,
    resolve_base_url,
    resolve_options,
)

SDK_NAME = "bentolabs-sdk"
SDK_VERSION = "0.1.0"

__all__ = [
    "API_KEY_PREFIX",
    "DEFAULT_BASE_URL",
    "SDK_NAME",
    "SDK_VERSION",
    "BentoAuthError",
    "BentoAuthErrorCode",
    "BentoConfig",
    "BentoLabsSpanProcessor",
    "BentoLabsTraceExporter",
    "resolve_api_key",
    "resolve_base_url",
    "resolve_options",
]
