"""OpenTelemetry span exporter for BentoLabs OTLP/JSON ingest."""

from __future__ import annotations

import json
import threading
from collections.abc import Mapping, Sequence
from enum import Enum
from typing import Any, cast
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, SpanExportResult
from opentelemetry.trace import SpanContext, SpanKind, StatusCode

from bentolabs_sdk.options import resolve_options

_JsonValue = dict[str, Any]

_SPAN_KIND_CODE = {
    SpanKind.INTERNAL: 1,
    SpanKind.SERVER: 2,
    SpanKind.CLIENT: 3,
    SpanKind.PRODUCER: 4,
    SpanKind.CONSUMER: 5,
}


class BentoLabsTraceExporter(SpanExporter):
    """OTLP/HTTP+JSON exporter that ships span batches to BentoLabs."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._config = resolve_options(api_key=api_key, base_url=base_url)
        self._endpoint = f"{self._config.base_url}/v1/traces"
        self._timeout = timeout
        self._shutdown = False
        self._lock = threading.Lock()

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        with self._lock:
            if self._shutdown:
                return SpanExportResult.FAILURE

        if not spans:
            return SpanExportResult.SUCCESS

        body = json.dumps(_encode_export_request(spans), separators=(",", ":")).encode("utf-8")
        request = Request(
            self._endpoint,
            data=body,
            headers={
                "Authorization": f"Bearer {self._config.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urlopen(request, timeout=self._timeout) as response:
                return (
                    SpanExportResult.SUCCESS
                    if 200 <= response.status < 300
                    else SpanExportResult.FAILURE
                )
        except (HTTPError, URLError, TimeoutError, OSError):
            return SpanExportResult.FAILURE

    def shutdown(self) -> None:
        with self._lock:
            self._shutdown = True

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return True


class BentoLabsSpanProcessor(BatchSpanProcessor):
    """Drop-in OpenTelemetry span processor backed by BentoLabsTraceExporter."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 10.0,
    ) -> None:
        super().__init__(
            BentoLabsTraceExporter(api_key=api_key, base_url=base_url, timeout=timeout)
        )


def _encode_export_request(spans: Sequence[ReadableSpan]) -> _JsonValue:
    grouped: dict[tuple[int, str, str], list[ReadableSpan]] = {}
    resources: dict[int, Resource] = {}
    scopes: dict[tuple[int, str, str], _JsonValue] = {}

    for span in spans:
        resource_key = id(span.resource)
        resources[resource_key] = span.resource
        scope = getattr(span, "instrumentation_scope", None)
        scope_name = str(getattr(scope, "name", "") or "")
        scope_version = str(getattr(scope, "version", "") or "")
        key = (resource_key, scope_name, scope_version)
        grouped.setdefault(key, []).append(span)
        scopes[key] = {
            "name": scope_name,
            **({"version": scope_version} if scope_version else {}),
        }

    resource_spans: list[_JsonValue] = []
    by_resource: dict[int, list[tuple[tuple[int, str, str], list[ReadableSpan]]]] = {}
    for key, span_group in grouped.items():
        by_resource.setdefault(key[0], []).append((key, span_group))

    for resource_key, scope_groups in by_resource.items():
        resource_spans.append(
            {
                "resource": _encode_resource(resources[resource_key]),
                "scopeSpans": [
                    {
                        "scope": scopes[key],
                        "spans": [_encode_span(span) for span in span_group],
                    }
                    for key, span_group in scope_groups
                ],
            }
        )

    return {"resourceSpans": resource_spans}


def _encode_resource(resource: Resource) -> _JsonValue:
    return {"attributes": _encode_attributes(resource.attributes)}


def _encode_span(span: ReadableSpan) -> _JsonValue:
    context = span.context
    if not isinstance(context, SpanContext):
        raise TypeError("span context is not a SpanContext")

    result: _JsonValue = {
        "traceId": _trace_id(context.trace_id),
        "spanId": _span_id(context.span_id),
        "name": span.name,
        "kind": _SPAN_KIND_CODE.get(span.kind, 1),
        "startTimeUnixNano": str(span.start_time),
        "attributes": _encode_attributes(span.attributes or {}),
        "status": _encode_status(span),
    }
    if span.end_time is not None:
        result["endTimeUnixNano"] = str(span.end_time)
    if span.parent is not None and span.parent.span_id != 0:
        result["parentSpanId"] = _span_id(span.parent.span_id)
    events = [
        {
            "name": event.name,
            "timeUnixNano": str(event.timestamp),
            "attributes": _encode_attributes(event.attributes or {}),
        }
        for event in span.events
    ]
    if events:
        result["events"] = events
    return result


def _encode_status(span: ReadableSpan) -> _JsonValue:
    status = span.status
    if status.status_code is StatusCode.ERROR:
        payload: _JsonValue = {"code": 2}
        if status.description:
            payload["message"] = status.description
        return payload
    if status.status_code is StatusCode.OK:
        return {"code": 1}
    return {}


def _encode_attributes(attrs: Mapping[str, Any]) -> list[_JsonValue]:
    return [{"key": key, "value": _encode_value(value)} for key, value in attrs.items()]


def _encode_value(value: Any) -> _JsonValue:
    if isinstance(value, bool):
        return {"boolValue": value}
    if isinstance(value, int) and not isinstance(value, bool):
        return {"intValue": str(value)}
    if isinstance(value, float):
        return {"doubleValue": value}
    if isinstance(value, str):
        return {"stringValue": value}
    if isinstance(value, bytes):
        return {"stringValue": value.decode("utf-8", errors="replace")}
    if isinstance(value, Enum):
        return {"stringValue": str(value.value)}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        items = cast(Sequence[Any], value)
        return {"arrayValue": {"values": [_encode_value(item) for item in items]}}
    if isinstance(value, Mapping):
        mapping = cast(Mapping[Any, Any], value)
        return {
            "kvlistValue": {
                "values": [
                    {"key": str(key), "value": _encode_value(item)} for key, item in mapping.items()
                ]
            }
        }
    return {"stringValue": str(value)}


def _trace_id(value: int) -> str:
    return f"{value:032x}"


def _span_id(value: int) -> str:
    return f"{value:016x}"
