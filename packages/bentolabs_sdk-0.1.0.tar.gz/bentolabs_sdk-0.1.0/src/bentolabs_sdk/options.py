"""Options and environment resolution for the BentoLabs Python SDK."""

from __future__ import annotations

import os
from dataclasses import dataclass

from bentolabs_sdk.errors import BentoAuthError

API_KEY_PREFIX = "bl_pk_"
DEFAULT_BASE_URL = "https://api.bentolabs.ai"

_API_KEY_ENV = "BENTOLABS_API_KEY"
_BASE_URL_ENV = "BENTOLABS_BASE_URL"


@dataclass(frozen=True, slots=True)
class BentoConfig:
    api_key: str
    base_url: str


def _read_env(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    trimmed = value.strip()
    return trimmed or None


def resolve_api_key(api_key: str | None = None) -> str:
    raw = api_key.strip() if isinstance(api_key, str) else None
    raw = raw or _read_env(_API_KEY_ENV)
    if not raw:
        raise BentoAuthError(
            "missing_api_key",
            f"BentoLabs API key not configured. Pass api_key or set {_API_KEY_ENV}.",
        )
    if not raw.startswith(API_KEY_PREFIX):
        raise BentoAuthError(
            "invalid_api_key_format",
            f'BentoLabs API key must start with "{API_KEY_PREFIX}". Got a key of length {len(raw)}.',
        )
    return raw


def resolve_base_url(base_url: str | None = None) -> str:
    raw = base_url.strip() if isinstance(base_url, str) else None
    raw = raw or _read_env(_BASE_URL_ENV) or DEFAULT_BASE_URL
    return raw[:-1] if raw.endswith("/") else raw


def resolve_options(*, api_key: str | None = None, base_url: str | None = None) -> BentoConfig:
    return BentoConfig(
        api_key=resolve_api_key(api_key),
        base_url=resolve_base_url(base_url),
    )
