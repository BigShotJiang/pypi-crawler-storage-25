"""Typed errors for the BentoLabs Python SDK."""

from __future__ import annotations

from typing import Literal

BentoAuthErrorCode = Literal["missing_api_key", "invalid_api_key_format"]


class BentoAuthError(Exception):
    """Raised when the SDK cannot establish a valid BentoLabs API key."""

    def __init__(self, code: BentoAuthErrorCode, message: str) -> None:
        super().__init__(message)
        self.code = code
