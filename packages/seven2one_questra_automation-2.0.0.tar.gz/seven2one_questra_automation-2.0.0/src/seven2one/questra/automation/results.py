"""Result wrapper for automation query results with optional DataFrame conversion."""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING, Generic, TypeVar, overload

if TYPE_CHECKING:
    import pandas as pd

try:
    import pandas as pd

    _PANDAS_AVAILABLE = True
except ImportError:
    _PANDAS_AVAILABLE = False

T = TypeVar("T")


class PagedQueryResult(Generic[T]):
    """Lazy, re-iterable wrapper for paginated query results with DataFrame support.

    Wraps any ``Iterator[T]`` and fetches pages on demand. Items are cached on
    the first traversal so that subsequent iterations replay from memory without
    hitting the API again.

    Args:
        source: Lazy iterator that yields items. Consumed at most once.

    Example:
        ```python
        result = client.list_executions(where={"domainStatus": {"eq": "SUCCEEDED"}})

        # Iterate directly
        for execution in result:
            print(execution.automation_path)

        # Convert to DataFrame
        df = result.to_df()

        # Index access (materializes all pages)
        first = result[0]
        count = len(result)
        ```
    """

    def __init__(self, source: Iterator[T]) -> None:
        self._source = source
        self._cache: list[T] = []
        self._exhausted = False

    def _materialize(self) -> None:
        """Drain the source iterator into the cache (idempotent)."""
        if not self._exhausted:
            for item in self._source:
                self._cache.append(item)
            self._exhausted = True

    def __iter__(self) -> Iterator[T]:
        idx = 0
        while True:
            if idx < len(self._cache):
                yield self._cache[idx]
                idx += 1
            elif self._exhausted:
                return
            else:
                try:
                    item = next(self._source)  # type: ignore[call-overload]
                    self._cache.append(item)
                    yield self._cache[idx]
                    idx += 1
                except StopIteration:
                    self._exhausted = True
                    return

    def __len__(self) -> int:
        self._materialize()
        return len(self._cache)

    @overload
    def __getitem__(self, index: int) -> T: ...

    @overload
    def __getitem__(self, index: slice) -> list[T]: ...

    def __getitem__(self, index: int | slice) -> T | list[T]:
        self._materialize()
        return self._cache[index]

    def to_df(self) -> pd.DataFrame:
        """Convert results to a pandas DataFrame. Materializes all pages first.

        Returns:
            pandas DataFrame with the query results.

        Raises:
            ImportError: When pandas is not installed.
        """
        if not _PANDAS_AVAILABLE:
            raise ImportError(
                "pandas is not installed. Install it with: pip install pandas"
            )

        self._materialize()

        data_dicts = []
        for item in self._cache:
            if hasattr(item, "model_dump"):
                data_dicts.append(item.model_dump())  # type: ignore[union-attr]
            elif hasattr(item, "__dict__"):
                data_dicts.append(vars(item))
            else:
                data_dicts.append({"value": item})

        return pd.DataFrame(data_dicts)

    def __repr__(self) -> str:
        if self._exhausted:
            return f"PagedQueryResult({self._cache!r})"
        return f"PagedQueryResult(<{len(self._cache)} cached, streaming...>)"

    def __str__(self) -> str:
        if self._exhausted:
            return str(self._cache)
        return repr(self)
