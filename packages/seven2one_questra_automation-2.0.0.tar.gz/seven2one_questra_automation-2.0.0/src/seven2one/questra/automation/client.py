"""Main client class for Questra Automation."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from seven2one.questra.authentication import QuestraAuthentication

from .generated.models import (
    AutomationExecutionView,
    AutomationView,
    CreateRepositoryPayload,
    CreateSchedulePayload,
    CreateWorkspacePayload,
    DeleteRepositoryPayload,
    DeleteSchedulePayload,
    DeleteWorkspacePayload,
    ErrorCodeView,
    ExecutePayload,
    ExecutionInitiator,
    RenewRepositorySshKeyPayload,
    RepositoryAuthenticationMethod,
    RepositoryView,
    ScheduledExecutionView,
    ScheduleView,
    SynchronizeWorkspacePayload,
    UpdateRepositoryPayload,
    UpdateSchedulePayload,
    UpdateWorkspacePayload,
    WorkspaceView,
)
from .pagination import relay_connection_iterator
from .raw_client import _QuestraAutomationCore
from .results import PagedQueryResult

logger = logging.getLogger(__name__)


class QuestraAutomation:
    """
    Client for Questra Automation GraphQL API.

    Provides a Pythonic, task-oriented interface for the Automation service.
    For direct GraphQL access, use the
    [`raw`][seven2one.questra.automation.QuestraAutomation.raw] property.

    Example:
        ```python
        from seven2one.questra.authentication import QuestraAuthentication
        from seven2one.questra.automation import QuestraAutomation, ExecutionInitiator

        auth_client = QuestraAuthentication(
            url="https://authentik.example.com",
            username="ServiceUser",
            password="secret_password",
        )

        automation = QuestraAutomation(
            graphql_url="https://example.com/automation/graphql",
            auth_client=auth_client,
        )

        # Convenience: iterate with automatic pagination
        for workspace in automation.list_workspaces():
            print(f"Workspace: {workspace.name}")

        # Convenience: execute automation
        result = automation.execute_automation(
            workspace_name="my-workspace",
            automation_path="scripts/my_automation.py",
            initiator_type=ExecutionInitiator.MANUAL,
        )
        print(f"Execution ID: {result.id}")

        # Raw access: direct GraphQL operations
        workspaces = automation.raw.queries.get_workspaces(first=10)
        result = automation.raw.mutations.execute_automation(
            workspace_name="my-workspace",
            automation_path="scripts/my_automation.py",
        )
        ```
    """

    def __init__(
        self,
        graphql_url: str | None = None,
        *,
        auth_client: QuestraAuthentication,
    ):
        """
        Initialize the QuestraAutomation client.

        Args:
            graphql_url: URL of the GraphQL endpoint.
            auth_client: Configured and authenticated QuestraAuthentication.

        Raises:
            ValueError: If graphql_url is missing and QUESTRA_AUTOMATION_URL is not set.
            ValueError: If auth_client is not authenticated.

        Environment Variables:
            QUESTRA_AUTOMATION_URL: Fallback for ``graphql_url`` if not passed explicitly.
        """
        logger.info("Initializing QuestraAutomation")
        self._core = _QuestraAutomationCore(
            graphql_url=graphql_url,
            auth_client=auth_client,
        )
        self._auth_client = auth_client
        logger.info("QuestraAutomation initialized successfully")

    @property
    def raw(self) -> _QuestraAutomationCore:
        """Direct access to the underlying GraphQL operations.

        Use this for operations not covered by the convenience methods,
        or when you need 1:1 access to the GraphQL schema.

        Example:
            ```python
            # Direct query access
            workspaces = client.raw.queries.get_workspaces(first=10)
            info = client.raw.queries.get_service_info()

            # Direct mutation access
            result = client.raw.mutations.execute_automation(
                workspace_name="my-workspace",
                automation_path="scripts/example.py",
            )

            # Custom GraphQL escape hatch
            result = client.raw.execute_raw(
                "query { automationServiceInfo { name version } }"
            )
            ```
        """
        return self._core

    def execute_raw(
        self, query: str, variables: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Execute a raw GraphQL query or mutation.

        Args:
            query: GraphQL query or mutation string
            variables: Optional variables

        Returns:
            dict: Raw result of the GraphQL operation

        Example:
            ```python
            result = client.execute_raw(
                "query { automationServiceInfo { name version } }"
            )
            ```
        """
        logger.debug("Executing raw GraphQL operation via QuestraAutomation")
        return self._core.execute_raw(query, variables)

    def is_authenticated(self) -> bool:
        """
        Check if the client is authenticated.

        Returns:
            bool: True if authenticated, False otherwise
        """
        return self._auth_client.is_authenticated()

    def reauthenticate(self) -> None:
        """
        Force reauthentication.

        Useful for authentication problems or when credentials have changed.
        """
        logger.info("Forcing reauthentication")
        self._auth_client.reauthenticate()
        logger.info("Reauthentication completed")

    @property
    def graphql_url(self) -> str:
        """
        GraphQL endpoint URL.

        Returns:
            str: URL of the GraphQL endpoint
        """
        return self._core.graphql_url

    # -------------------------------------------------------------------------
    # Convenience: List (auto-paginated iterators)
    # -------------------------------------------------------------------------

    def list_automations(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[AutomationView]:
        """
        Iterate over all automations with automatic pagination.

        Args:
            where: GraphQL filter conditions (AutomationViewFilterInput).
                Available fields:
                - `workspaceName`, `path`, `description`, `environment` (StringOperationFilterInput):
                  `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`, `startsWith`, `nstartsWith`,
                  `endsWith`, `nendsWith`, `and`, `or`
                - `allowParallelExecution` (BooleanOperationFilterInput): `eq`, `neq`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            AutomationView instances

        Example:
            ```python
            for automation in client.list_automations():
                print(f"Automation: {automation.workspace_name}/{automation.path}")

            for automation in client.list_automations(
                where={"workspaceName": {"eq": "my-workspace"}}
            ):
                print(f"Path: {automation.path}")
            ```
        """
        return PagedQueryResult(
            relay_connection_iterator(
                fetch_page=lambda after: self._core.queries.get_automations(
                    first=page_size, after=after, where=where, order=order
                ),
            )
        )

    def list_executions(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[AutomationExecutionView]:
        """
        Iterate over all automation executions with automatic pagination.

        Args:
            where: GraphQL filter conditions (AutomationExecutionViewFilterInput).
                Available fields:
                - String fields (`branch`, `commit`, `workspaceName`, `repositoryName`,
                  `repositoryUrl`, `automationPath`, `environment`, `initiatorReference`,
                  `output`, `domainStatusMessage`): `eq`, `neq`, `in`, `nin`, `contains`,
                  `ncontains`, `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - `id` (UUID): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`, `ngte`,
                  `lt`, `nlt`, `lte`, `nlte`
                - DateTime fields (`createdAt`, `startedAt`, `finishedAt`): `eq`, `neq`,
                  `in`, `nin`, `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - `duration` (TimeSpan): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            AutomationExecutionView instances

        Example:
            ```python
            for execution in client.list_executions(where={"status": {"eq": "FAILED"}}):
                print(f"Failed: {execution.automation_path}")
            ```
        """
        return PagedQueryResult(
            relay_connection_iterator(
                fetch_page=lambda after: self._core.queries.get_executions(
                    first=page_size, after=after, where=where, order=order
                ),
            )
        )

    def list_error_codes(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[ErrorCodeView]:
        """
        Iterate over all error codes with automatic pagination.

        Args:
            where: GraphQL filter conditions (ErrorCodeViewFilterInput).
                Available fields:
                - `code` (StringOperationFilterInput): `eq`, `neq`, `in`, `nin`,
                  `contains`, `ncontains`, `startsWith`, `nstartsWith`, `endsWith`,
                  `nendsWith`, `and`, `or`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            ErrorCodeView instances

        Example:
            ```python
            for error_code in client.list_error_codes(
                where={"code": {"startsWith": "SCHEDULE_"}}
            ):
                print(f"Error code: {error_code.code}")
            ```
        """
        return PagedQueryResult(
            relay_connection_iterator(
                fetch_page=lambda after: self._core.queries.get_error_codes(
                    first=page_size, after=after, where=where, order=order
                ),
            )
        )

    def list_repositories(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[RepositoryView]:
        """
        Iterate over all repositories with automatic pagination.

        Args:
            where: GraphQL filter conditions (RepositoryViewFilterInput).
                Available fields:
                - String fields (`name`, `url`, `username`, `sshPublicKey`):
                  `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`, `startsWith`,
                  `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - DateTime fields (`createdAt`, `changedAt`): `eq`, `neq`, `in`, `nin`,
                  `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            RepositoryView instances

        Example:
            ```python
            for repository in client.list_repositories(
                where={"name": {"contains": "production"}}
            ):
                print(f"Production repo: {repository.name}")
            ```
        """
        return PagedQueryResult(
            relay_connection_iterator(
                fetch_page=lambda after: self._core.queries.get_repositories(
                    first=page_size, after=after, where=where, order=order
                ),
            )
        )

    def list_schedules(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[ScheduleView]:
        """
        Iterate over all schedules with automatic pagination.

        Args:
            where: GraphQL filter conditions (ScheduleViewFilterInput).
                Available fields:
                - String fields (`automationPath`, `name`, `description`, `cron`, `timezone`):
                  `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`, `startsWith`,
                  `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - `active` (Boolean): `eq`, `neq`
                - `version` (Long): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            ScheduleView instances

        Example:
            ```python
            for schedule in client.list_schedules(where={"active": {"eq": True}}):
                print(f"Active: {schedule.name} - {schedule.cron}")
            ```
        """
        return PagedQueryResult(
            relay_connection_iterator(
                fetch_page=lambda after: self._core.queries.get_schedules(
                    first=page_size, after=after, where=where, order=order
                ),
            )
        )

    def list_scheduled_executions(
        self,
        from_time: datetime | None = None,
        to_time: datetime | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[ScheduledExecutionView]:
        """
        Iterate over scheduled executions with automatic pagination.

        Args:
            from_time: Start time for scheduled executions
            to_time: End time for scheduled executions
            page_size: Number of items per page

        Yields:
            ScheduledExecutionView instances

        Example:
            ```python
            from datetime import datetime, timedelta

            start = datetime.now()
            end = start + timedelta(days=7)
            for scheduled in client.list_scheduled_executions(
                from_time=start, to_time=end
            ):
                print(f"Schedule: {scheduled.name} at {scheduled.fire_time}")
            ```
        """
        return PagedQueryResult(
            relay_connection_iterator(
                fetch_page=lambda after: self._core.queries.get_scheduled_executions(
                    from_time=from_time, to_time=to_time, first=page_size, after=after
                ),
            )
        )

    def list_workspaces(
        self,
        where: dict[str, Any] | None = None,
        order: list[dict[str, str]] | None = None,
        page_size: int = 1000,
    ) -> PagedQueryResult[WorkspaceView]:
        """
        Iterate over all workspaces with automatic pagination.

        Args:
            where: GraphQL filter conditions (WorkspaceViewFilterInput).
                Available fields:
                - String fields (`name`, `repositoryName`, `buildBranch`, `buildCommit`,
                  `activeBranch`, `activeCommit`): `eq`, `neq`, `in`, `nin`, `contains`,
                  `ncontains`, `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - UUID fields (`buildId`, `activeBuildId`): `eq`, `neq`, `in`, `nin`,
                  `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime fields (`buildStartedAt`, `buildFinishedAt`, `createdAt`, `changedAt`):
                  `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - `buildDuration` (TimeSpan): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            order: Sort order
            page_size: Number of items per page

        Yields:
            WorkspaceView instances

        Example:
            ```python
            for workspace in client.list_workspaces(
                where={"name": {"startsWith": "prod-"}}
            ):
                print(f"Production workspace: {workspace.name}")
            ```
        """
        return PagedQueryResult(
            relay_connection_iterator(
                fetch_page=lambda after: self._core.queries.get_workspaces(
                    first=page_size, after=after, where=where, order=order
                ),
            )
        )

    # -------------------------------------------------------------------------
    # Convenience: Mutations
    # -------------------------------------------------------------------------

    def execute_automation(
        self,
        workspace_name: str,
        automation_path: str,
        initiator_type: ExecutionInitiator = ExecutionInitiator.MANUAL,
        arguments: list[dict[str, str]] | None = None,
        initiator_reference: str | None = None,
    ) -> ExecutePayload:
        """
        Execute an automation in a specified workspace.

        Args:
            workspace_name: Name of the workspace containing the automation.
            automation_path: Path to the automation script.
            initiator_type: Type of initiator (Manual, Script, or Schedule).
            arguments: Arguments to pass to the automation.
            initiator_reference: Optional reference to the initiator.

        Returns:
            ExecutePayload with execution ID.

        Example:
            ```python
            result = client.execute_automation(
                workspace_name="my-workspace",
                automation_path="scripts/daily_sync.py",
                initiator_type=ExecutionInitiator.MANUAL,
                arguments=[{"name": "source", "value": "system-a"}],
            )
            print(f"Started execution: {result.id}")
            ```
        """
        return self._core.mutations.execute_automation(
            workspace_name=workspace_name,
            automation_path=automation_path,
            initiator_type=initiator_type,
            arguments=arguments,
            initiator_reference=initiator_reference,
        )

    def create_repository(
        self,
        name: str,
        url: str,
        credentials_method: RepositoryAuthenticationMethod,
        username: str | None = None,
        password: str | None = None,
    ) -> CreateRepositoryPayload:
        """
        Create a new repository.

        Args:
            name: Repository name.
            url: URL of the remote repository.
            credentials_method: Authentication method (UsernamePassword or SshKey).
            username: Username for authentication (optional).
            password: Password or token for authentication (optional).

        Returns:
            CreateRepositoryPayload with repository name.

        Example:
            ```python
            repo = client.create_repository(
                name="my-repo",
                url="https://github.com/example/my-repo.git",
                credentials_method=RepositoryAuthenticationMethod.USERNAME_PASSWORD,
                username="deploy-user",
                password="token",
            )
            print(f"Created: {repo.name}")
            ```
        """
        return self._core.mutations.create_repository(
            name=name,
            url=url,
            credentials_method=credentials_method,
            username=username,
            password=password,
        )

    def update_repository(
        self,
        name: str,
        new_name: str | None = None,
        url: str | None = None,
        credentials_method: RepositoryAuthenticationMethod | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> UpdateRepositoryPayload:
        """
        Update an existing repository.

        Args:
            name: Current repository name.
            new_name: New repository name (optional).
            url: New URL of the remote repository (optional).
            credentials_method: New authentication method (optional).
            username: New username for authentication (optional).
            password: New password or token for authentication (optional).

        Returns:
            UpdateRepositoryPayload with repository name.
        """
        return self._core.mutations.update_repository(
            name=name,
            new_name=new_name,
            url=url,
            credentials_method=credentials_method,
            username=username,
            password=password,
        )

    def delete_repository(self, name: str) -> DeleteRepositoryPayload:
        """
        Delete a repository by name.

        Args:
            name: Repository name.

        Returns:
            DeleteRepositoryPayload with repository name.
        """
        return self._core.mutations.delete_repository(name=name)

    def renew_repository_ssh_key(self, name: str) -> RenewRepositorySshKeyPayload:
        """
        Renew the SSH key for a repository.

        Args:
            name: Repository name.

        Returns:
            RenewRepositorySshKeyPayload with repository name.
        """
        return self._core.mutations.renew_repository_ssh_key(name=name)

    def create_workspace(
        self, repository_name: str, name: str, branch_name: str, commit: str
    ) -> CreateWorkspacePayload:
        """
        Create a new workspace in a repository.

        Args:
            repository_name: Repository name.
            name: Workspace name.
            branch_name: Name of the branch.
            commit: Commit hash to check out.

        Returns:
            CreateWorkspacePayload with workspace name.

        Example:
            ```python
            ws = client.create_workspace(
                repository_name="my-repo",
                name="prod-workspace",
                branch_name="main",
                commit="abc123",
            )
            print(f"Created: {ws.name}")
            ```
        """
        return self._core.mutations.create_workspace(
            repository_name=repository_name,
            name=name,
            branch_name=branch_name,
            commit=commit,
        )

    def update_workspace(
        self,
        name: str,
        new_name: str | None = None,
        branch_name: str | None = None,
        commit: str | None = None,
    ) -> UpdateWorkspacePayload:
        """
        Update an existing workspace.

        Args:
            name: Current workspace name.
            new_name: New workspace name (optional).
            branch_name: New branch name (optional).
            commit: New commit hash (optional).

        Returns:
            UpdateWorkspacePayload with workspace name.
        """
        return self._core.mutations.update_workspace(
            name=name,
            new_name=new_name,
            branch_name=branch_name,
            commit=commit,
        )

    def delete_workspace(self, name: str) -> DeleteWorkspacePayload:
        """
        Delete a workspace by name.

        Args:
            name: Workspace name.

        Returns:
            DeleteWorkspacePayload with workspace name.
        """
        return self._core.mutations.delete_workspace(name=name)

    def synchronize_workspace(self, name: str) -> SynchronizeWorkspacePayload:
        """
        Synchronize a workspace with its remote repository.

        Args:
            name: Workspace name.

        Returns:
            SynchronizeWorkspacePayload with workspace name.
        """
        return self._core.mutations.synchronize_workspace(name=name)

    def create_schedule(
        self,
        workspace_name: str,
        automation_path: str,
        name: str,
        description: str,
        cron: str,
        timezone: str,
        active: bool,
        arguments: list[dict[str, str]] | None = None,
    ) -> CreateSchedulePayload:
        """
        Create a new schedule for automated execution.

        Args:
            workspace_name: Name of the workspace containing the automation.
            automation_path: Path to the automation script.
            name: Name of the schedule.
            description: Description of the schedule.
            cron: Cron expression defining the schedule.
            timezone: Timezone for the schedule.
            active: Whether the schedule is active.
            arguments: Arguments to pass to the automation.

        Returns:
            CreateSchedulePayload with schedule details.

        Example:
            ```python
            sched = client.create_schedule(
                workspace_name="my-workspace",
                automation_path="scripts/daily_sync.py",
                name="daily-run",
                description="Run daily at midnight",
                cron="0 0 * * *",
                timezone="Europe/Berlin",
                active=True,
            )
            print(f"Created: {sched.name}")
            ```
        """
        return self._core.mutations.create_schedule(
            workspace_name=workspace_name,
            automation_path=automation_path,
            name=name,
            description=description,
            cron=cron,
            timezone=timezone,
            active=active,
            arguments=arguments,
        )

    def update_schedule(
        self,
        workspace_name: str,
        automation_path: str,
        name: str,
        new_name: str | None = None,
        description: str | None = None,
        cron: str | None = None,
        timezone: str | None = None,
        active: bool | None = None,
        arguments: list[dict[str, str]] | None = None,
    ) -> UpdateSchedulePayload:
        """
        Update an existing schedule.

        Args:
            workspace_name: Name of the workspace containing the automation.
            automation_path: Path to the automation script.
            name: Current name of the schedule.
            new_name: New name of the schedule (optional).
            description: New description (optional).
            cron: New cron expression (optional).
            timezone: New timezone (optional).
            active: New active state (optional).
            arguments: New arguments (optional).

        Returns:
            UpdateSchedulePayload with schedule details.
        """
        return self._core.mutations.update_schedule(
            workspace_name=workspace_name,
            automation_path=automation_path,
            name=name,
            new_name=new_name,
            description=description,
            cron=cron,
            timezone=timezone,
            active=active,
            arguments=arguments,
        )

    def delete_schedule(
        self, workspace_name: str, automation_path: str, name: str
    ) -> DeleteSchedulePayload:
        """
        Delete a schedule.

        Args:
            workspace_name: Name of the workspace containing the automation.
            automation_path: Path to the automation script.
            name: Name of the schedule.

        Returns:
            DeleteSchedulePayload with schedule details.
        """
        return self._core.mutations.delete_schedule(
            workspace_name=workspace_name,
            automation_path=automation_path,
            name=name,
        )

    def __repr__(self) -> str:
        """String representation of the client."""
        auth_status = (
            "authenticated" if self.is_authenticated() else "not authenticated"
        )
        return (
            f"QuestraAutomation(graphql_url='{self.graphql_url}', "
            f"status='{auth_status}')"
        )
