"""Raw client for Questra Automation.

Provides direct access to the Automation GraphQL operations.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from seven2one.questra.authentication import QuestraAuthentication

from .operations import MutationOperations, QueryOperations
from .transport import GraphQLTransport

logger = logging.getLogger(__name__)


class _QuestraAutomationCore:
    """Low-level GraphQL client for the Questra Automation Service.

    Args:
        graphql_url: URL of the GraphQL endpoint.
        auth_client: Authenticated :class:`~seven2one.questra.authentication.QuestraAuthentication` instance.

    Raises:
        ValueError: If ``graphql_url`` is not provided and ``QUESTRA_AUTOMATION_URL`` is not set.
        ValueError: If ``auth_client`` is not authenticated.

    Environment Variables:
        QUESTRA_AUTOMATION_URL: Fallback for ``graphql_url`` if not passed explicitly.

    Example:
        ```python
        from seven2one.questra.authentication import QuestraAuthentication
        from seven2one.questra.automation import QuestraAutomation

        auth = QuestraAuthentication(url="...", username="svc", password="secret")
        client = QuestraAutomation(
            graphql_url="https://example.com/automation/graphql", auth_client=auth
        )

        # Access raw queries
        workspaces = client.raw.queries.get_workspaces(first=10)

        # Access raw mutations
        result = client.raw.mutations.execute_automation(
            workspace_name="my-workspace",
            automation_path="scripts/example.py",
        )

        # Escape hatch for custom queries
        result = client.raw.execute_raw(
            "query { automationServiceInfo { name version } }"
        )
        ```
    """

    def __init__(
        self,
        graphql_url: str | None = None,
        *,
        auth_client: QuestraAuthentication,
    ) -> None:
        graphql_url = graphql_url or os.getenv("QUESTRA_AUTOMATION_URL")
        if not graphql_url:
            raise ValueError(
                "graphql_url is required. Pass graphql_url= or set QUESTRA_AUTOMATION_URL."
            )

        if not auth_client.is_authenticated():
            raise ValueError(
                "QuestraAuthentication is not authenticated. "
                "Please authenticate the client before passing it."
            )

        logger.debug("Initializing _QuestraAutomationCore for URL: %s", graphql_url)

        self._graphql_url = graphql_url

        self._transport = GraphQLTransport(
            url=graphql_url,
            get_access_token_func=auth_client.get_access_token,
        )

        self._queries = QueryOperations(execute_func=self._transport.execute)
        self._mutations = MutationOperations(execute_func=self._transport.execute)

        logger.debug("_QuestraAutomationCore initialized successfully")

    @property
    def queries(self) -> QueryOperations:
        """Access to query operations (1:1 with GraphQL schema).

        Example:
            ```python
            workspaces = client.raw.queries.get_workspaces(first=10)
            executions = client.raw.queries.get_executions(
                first=10, where={"status": {"eq": "SUCCEEDED"}}
            )
            info = client.raw.queries.get_service_info()
            ```
        """
        return self._queries

    @property
    def mutations(self) -> MutationOperations:
        """Access to mutation operations (1:1 with GraphQL schema).

        Example:
            ```python
            result = client.raw.mutations.execute_automation(
                workspace_name="my-workspace",
                automation_path="scripts/example.py",
            )
            workspace = client.raw.mutations.create_workspace(
                repository_name="my-repo",
                name="my-workspace",
                branch_name="main",
                commit="abc123",
            )
            ```
        """
        return self._mutations

    def execute_raw(
        self, query: str, variables: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute a raw GraphQL query or mutation.

        Useful for custom operations not covered by the typed operations.

        Args:
            query: GraphQL query or mutation string.
            variables: Optional variables dict.

        Returns:
            Raw result dict of the GraphQL operation.

        Example:
            ```python
            result = client.raw.execute_raw(
                "query { automationServiceInfo { name version } }"
            )
            ```
        """
        logger.debug("Executing raw GraphQL operation via _QuestraAutomationCore")
        return self._transport.execute(query, variables)

    @property
    def graphql_url(self) -> str:
        """GraphQL endpoint URL."""
        return self._graphql_url
