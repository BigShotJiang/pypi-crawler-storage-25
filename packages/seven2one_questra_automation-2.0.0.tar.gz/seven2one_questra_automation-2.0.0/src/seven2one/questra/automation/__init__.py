"""
Questra Automation - Python Client for Automation GraphQL API.

Provides a type-safe interface to the Questra Automation service with automatic
OAuth2 token management through QuestraAuthentication.

Example:
    ```python
    from seven2one.questra.authentication import QuestraAuthentication
    from seven2one.questra.automation import QuestraAutomation, ExecutionInitiator

    # Create QuestraAuthentication
    auth = QuestraAuthentication(
        url="https://authentik.example.com",
        username="ServiceUser",
        password="secret_password",
    )

    # Initialize QuestraAutomation
    automation = QuestraAutomation(
        graphql_url="https://dev.example.com/automation/graphql",
        auth_client=auth,
    )

    # Convenience: iterate with automatic pagination
    for workspace in automation.list_workspaces():
        print(f"Workspace: {workspace.name}")

    # Convenience: execute automation
    result = automation.execute_automation(
        workspace_name="my-workspace",
        automation_path="scripts/example.py",
        initiator_type=ExecutionInitiator.MANUAL,
        arguments=[{"name": "param1", "value": "value1"}],
    )
    print(f"Execution ID: {result.id}")

    # Raw access: direct GraphQL operations
    workspaces = automation.raw.queries.get_workspaces(first=10)
    result = automation.raw.mutations.execute_automation(
        workspace_name="my-workspace",
        automation_path="scripts/example.py",
    )
    ```
"""

# Main client
from .client import QuestraAutomation

# Exceptions
from .exceptions import QuestraAutomationError, QuestraAutomationGraphQLError

# Re-export commonly used types from generated models
from .generated.models import (
    AutomationBuildStatusViewData,
    AutomationExecutionDomainStatusViewData,
    AutomationExecutionStatusViewData,
    AutomationInitiatorTypeViewData,
    ExecutionInitiator,
    RepositoryAuthenticationMethod,
    RepositoryAuthenticationMethodViewData,
)

# Result types
from .results import PagedQueryResult

__all__ = [
    # Main client
    "QuestraAutomation",
    # Exceptions
    "QuestraAutomationError",
    "QuestraAutomationGraphQLError",
    # Result types
    "PagedQueryResult",
    # Enums
    "ExecutionInitiator",
    "AutomationBuildStatusViewData",
    "AutomationExecutionDomainStatusViewData",
    "AutomationExecutionStatusViewData",
    "AutomationInitiatorTypeViewData",
    "RepositoryAuthenticationMethod",
    "RepositoryAuthenticationMethodViewData",
]

# Keep backward compatibility: _QuestraAutomationCore accessible via raw_client module
# (not re-exported at package level since it's private by convention)
