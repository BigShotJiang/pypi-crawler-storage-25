"""Pagination utilities for Questra Automation."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from typing import Any, Generic, TypeVar

T = TypeVar("T")


class PagedIterator(Generic[T]):
    """Generic iterator for automatic pagination of API responses.

    Loads pages lazily on demand and iterates efficiently over items
    using index-based access (O(1) per item).

    Examples:
        ```python
        # With Relay-style Connection
        iterator = PagedIterator(
            fetch_page=lambda after: self._queries.get_automations(
                first=100, after=after, where=where, order=order
            ),
            extract_items=lambda conn: [
                edge.node for edge in (conn.edges or []) if edge.node is not None
            ],
            has_next_page=lambda conn: (
                conn.page_info.has_next_page if conn.page_info else False
            ),
            get_cursor=lambda conn: (
                conn.page_info.end_cursor if conn.page_info else None
            ),
        )

        for item in iterator:
            print(item)
        ```
    """

    def __init__(
        self,
        fetch_page: Callable[[str | None], Any],
        extract_items: Callable[[Any], list[T]],
        has_next_page: Callable[[Any], bool],
        get_cursor: Callable[[Any], str | None],
    ):
        """Initialize paged iterator.

        Args:
            fetch_page: Fetches a page. Receives cursor (or None), returns page result.
            extract_items: Extracts items from a page result.
            has_next_page: Returns True if more pages exist.
            get_cursor: Returns the next pagination cursor from a page result.
        """
        self._fetch_page = fetch_page
        self._extract_items = extract_items
        self._has_next_page = has_next_page
        self._get_cursor = get_cursor

        self._current_items: list[T] = []
        self._index = 0
        self._cursor: str | None = None
        self._exhausted = False

    def __iter__(self) -> Iterator[T]:
        return self

    def __next__(self) -> T:
        if self._index < len(self._current_items):
            item = self._current_items[self._index]
            self._index += 1
            return item

        if self._exhausted:
            raise StopIteration

        page_result = self._fetch_page(self._cursor)
        self._current_items = self._extract_items(page_result)

        if not self._current_items:
            self._exhausted = True
            raise StopIteration

        if not self._has_next_page(page_result):
            self._exhausted = True
        else:
            self._cursor = self._get_cursor(page_result)

        self._index = 0
        item = self._current_items[self._index]
        self._index += 1
        return item


def relay_connection_iterator(
    fetch_page: Callable[[str | None], Any],
) -> PagedIterator[Any]:
    """Create an iterator for Relay-style connections with edges.

    Args:
        fetch_page: Function that fetches a connection page. Receives a cursor
            (or None for the first page) and returns a Connection object with
            ``edges`` and ``page_info``.

    Returns:
        Iterator over non-null edge nodes.

    Examples:
        ```python
        iterator = relay_connection_iterator(
            fetch_page=lambda after: self._queries.get_automations(
                first=100, after=after, where=where, order=order
            ),
        )
        for automation in iterator:
            print(automation.path)
        ```
    """
    return PagedIterator(
        fetch_page=fetch_page,
        extract_items=lambda conn: [
            edge.node for edge in (conn.edges or []) if edge.node is not None
        ],
        has_next_page=lambda conn: (
            conn.page_info.has_next_page if conn.page_info else False
        ),
        get_cursor=lambda conn: (conn.page_info.end_cursor if conn.page_info else None),
    )
