"""
Version and authorship information
"""

__author__    = 'Jason Anthony Vander Heiden'
__copyright__ = 'Copyright 2026 Kleinstein Lab, Yale University. All rights reserved.'
__license__   = 'GNU Affero General Public License 3 (AGPL-3)'
__version__   = '0.7.9'
__date__      = '2026.04.14'
