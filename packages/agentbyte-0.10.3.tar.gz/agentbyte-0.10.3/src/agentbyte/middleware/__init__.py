"""Middleware utilities for agent operations."""

import os

from .base import (
    ApprovalMiddleware,
    BaseMiddleware,
    ContextCompactionMiddleware,
    GuardrailMiddleware,
    LoggingMiddleware,
    MetricsMiddleware,
    MiddlewareChain,
    MiddlewareContext,
    OperationType,
    PIIRedactionMiddleware,
    RateLimitMiddleware,
)
from .otel import OTelMiddleware, auto_instrument
from .retry import RetryMiddleware


def init_auto_instrumentation_from_env() -> bool:
    """Initialize OTel auto-instrumentation when enabled via environment.

    Returns:
        ``True`` when instrumentation was requested and attempted,
        otherwise ``False``.
    """
    enabled = os.getenv("AGENTBYTE_ENABLE_OTEL", "false").lower() in ("true", "1", "yes")
    if not enabled:
        return False

    auto_instrument()
    return True

__all__ = [
    "MiddlewareContext",
    "OperationType",
    "BaseMiddleware",
    "MiddlewareChain",
    "ApprovalMiddleware",
    "ContextCompactionMiddleware",
    "LoggingMiddleware",
    "PIIRedactionMiddleware",
    "GuardrailMiddleware",
    "MetricsMiddleware",
    "RateLimitMiddleware",
    "OTelMiddleware",
    "auto_instrument",
    "init_auto_instrumentation_from_env",
    "RetryMiddleware",
]
