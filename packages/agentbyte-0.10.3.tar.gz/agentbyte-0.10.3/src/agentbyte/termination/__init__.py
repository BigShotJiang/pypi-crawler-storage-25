"""Termination conditions for orchestration."""

from .base import BaseTermination
from .cancellation import CancellationTermination
from .composite import CompositeTermination
from .consecutive_agent import ConsecutiveAgentTermination
from .external import ExternalTermination
from .function_call import FunctionCallTermination
from .handoff import HandoffTermination
from .max_message import MaxMessageTermination
from .predicate import PredicateTermination
from .source import SourceTermination
from .text_mention import TextMentionTermination
from .timeout import TimeoutTermination
from .token_usage import TokenUsageTermination

__all__ = [
    "BaseTermination",
    "CancellationTermination",
    "CompositeTermination",
    "ConsecutiveAgentTermination",
    "ExternalTermination",
    "FunctionCallTermination",
    "HandoffTermination",
    "MaxMessageTermination",
    "PredicateTermination",
    "SourceTermination",
    "TextMentionTermination",
    "TimeoutTermination",
    "TokenUsageTermination",
]
