export function formatCost(costEstimate: number): string {
  return costEstimate < 0.01 ? "<$0.01" : `$${costEstimate.toFixed(3)}`;
}
