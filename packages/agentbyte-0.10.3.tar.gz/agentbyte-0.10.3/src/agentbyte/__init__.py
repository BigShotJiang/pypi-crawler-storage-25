"""
Agentbyte - Enterprise-ready agent framework with DDD principles.

Building agents from scratch following Chapter 4 patterns with:
- Async-first architecture
- Event-based streaming
- Clean Architecture (Port/Adapter pattern)
- Domain-Driven Design

Architecture Layers:
- domain/         - Core business logic (entities, value objects, services)
- application/    - Use cases, ports (interfaces)
- infrastructure/ - Adapters, external integrations
"""

from agentbyte.__about__ import VERSION
from agentbyte.agents import Agent
from agentbyte.entity import Entity
from agentbyte.eval import (
    CompositeJudge,
    ContainsJudge,
    EvalResult,
    EvalScore,
    EvalTask,
    EvalTrajectory,
    ExactMatchJudge,
    ExpectedToolCall,
    FuzzyMatchJudge,
    LLMEvalJudge,
)
from agentbyte.middleware import init_auto_instrumentation_from_env
from agentbyte.notebook import configure_notebook_logging
from agentbyte.messages import (
    AssistantMessage,
    Message,
    SystemMessage,
    ToolMessage,
    UserMessage,
)
from agentbyte.orchestration import (
    AIOrchestrator,
    AgentHistoryPolicy,
    BaseOrchestrator,
    ExecutionPlan,
    FinalResultPolicy,
    HandoffOrchestrator,
    HistoryContextPolicy,
    PlanBasedOrchestrator,
    PlanStep,
    ReviewGatePolicy,
    RoundRobinOrchestrator,
    SelectorContextPolicy,
    StepProgressEvaluation,
)
from agentbyte.session_store import (
    CachedFileSessionStore,
    FileSessionStore,
    InMemorySessionStore,
    SessionStore,
)
from agentbyte.presets import (
    build_chat_client,
    get_ai_orchestrator,
    get_orchestrator,
    get_plan_based_orchestrator,
    get_query_rewriter,
    get_researcher,
    get_reviewer,
    get_round_robin_orchestrator,
    get_workflow,
    get_writer,
)
from agentbyte.termination import (
    BaseTermination,
    CancellationTermination,
    CompositeTermination,
    ConsecutiveAgentTermination,
    ExternalTermination,
    FunctionCallTermination,
    HandoffTermination,
    MaxMessageTermination,
    PredicateTermination,
    SourceTermination,
    TextMentionTermination,
    TimeoutTermination,
    TokenUsageTermination,
)
from agentbyte.webui import WebUIServer, create_app, serve

# Auto-instrument with OpenTelemetry if enabled.
# Must be set BEFORE importing agentbyte for transparent instrumentation.
try:
    init_auto_instrumentation_from_env()
except Exception:
    # Gracefully continue if instrumentation setup fails.
    pass


__all__ = [
    "VERSION",
    "Agent",
    "Entity",
    "configure_notebook_logging",
    # Eval
    "ExpectedToolCall",
    "EvalTask",
    "EvalTrajectory",
    "EvalScore",
    "EvalResult",
    "ExactMatchJudge",
    "ContainsJudge",
    "FuzzyMatchJudge",
    "LLMEvalJudge",
    "CompositeJudge",
    # Session stores
    "SessionStore",
    "InMemorySessionStore",
    "FileSessionStore",
    "CachedFileSessionStore",
    # Messages
    "Message",
    "UserMessage",
    "SystemMessage",
    "AssistantMessage",
    "ToolMessage",
    # Orchestration
    "AIOrchestrator",
    "AgentHistoryPolicy",
    "BaseOrchestrator",
    "ExecutionPlan",
    "FinalResultPolicy",
    "HandoffOrchestrator",
    "HistoryContextPolicy",
    "PlanBasedOrchestrator",
    "PlanStep",
    "ReviewGatePolicy",
    "RoundRobinOrchestrator",
    "SelectorContextPolicy",
    "StepProgressEvaluation",
    # Presets
    "build_chat_client",
    "get_query_rewriter",
    "get_researcher",
    "get_writer",
    "get_reviewer",
    "get_orchestrator",
    "get_round_robin_orchestrator",
    "get_ai_orchestrator",
    "get_plan_based_orchestrator",
    "get_workflow",
    # Termination
    "BaseTermination",
    "CancellationTermination",
    "CompositeTermination",
    "ConsecutiveAgentTermination",
    "ExternalTermination",
    "FunctionCallTermination",
    "HandoffTermination",
    "MaxMessageTermination",
    "PredicateTermination",
    "SourceTermination",
    "TextMentionTermination",
    "TimeoutTermination",
    "TokenUsageTermination",
    # WebUI
    "WebUIServer",
    "create_app",
    "serve",
]
