"""Compatibility shim for the legacy flat OpenAI embedding module path.

Canonical imports now live under ``agentbyte.llm.openai`` and
``agentbyte.llm.openai.embedding``.
"""

from .openai.embedding import OpenAIEmbeddingClient, OpenAIEmbeddingClientConfig

__all__ = [
    "OpenAIEmbeddingClient",
    "OpenAIEmbeddingClientConfig",
]
