"""Compatibility shim for the legacy flat settings module path.

Canonical imports now live under ``agentbyte.llm.openai.settings`` and
``agentbyte.llm.azure.settings``.
"""

from .azure.settings import AzureOpenAISettings, AzureServicePrincipalSettings
from .openai.settings import OpenAISettings

__all__ = [
    "OpenAISettings",
    "AzureOpenAISettings",
    "AzureServicePrincipalSettings",
]
