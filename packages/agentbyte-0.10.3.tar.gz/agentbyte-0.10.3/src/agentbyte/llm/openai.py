"""Compatibility shim for the legacy flat OpenAI chat module path.

Canonical imports now live under ``agentbyte.llm.openai`` and
``agentbyte.llm.openai.chat``.
"""

from .openai.chat import OpenAIChatCompletionClient, OpenAIChatCompletionClientConfig

__all__ = [
    "OpenAIChatCompletionClient",
    "OpenAIChatCompletionClientConfig",
]
