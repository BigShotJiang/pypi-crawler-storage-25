"""Azure provider package."""

from .auth import (
    get_default_token_provider,
    get_certificate_token_provider,
    create_token_provider_from_string,
)
from .chat import AzureOpenAIChatCompletionClient, AzureOpenAIChatCompletionClientConfig
from .embedding import AzureOpenAIEmbeddingClient, AzureOpenAIEmbeddingClientConfig
from .settings import AzureOpenAISettings, AzureServicePrincipalSettings

__all__ = [
    "get_default_token_provider",
    "get_certificate_token_provider",
    "create_token_provider_from_string",
    "AzureOpenAIChatCompletionClient",
    "AzureOpenAIChatCompletionClientConfig",
    "AzureOpenAIEmbeddingClient",
    "AzureOpenAIEmbeddingClientConfig",
    "AzureOpenAISettings",
    "AzureServicePrincipalSettings",
]
