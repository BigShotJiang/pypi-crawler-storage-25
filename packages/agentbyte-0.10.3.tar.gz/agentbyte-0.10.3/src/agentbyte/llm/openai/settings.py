"""OpenAI provider settings."""

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class OpenAISettings(BaseSettings):
    """
    OpenAI provider settings.

    Reads from environment variables with the prefix ``OPENAI_``:
    - ``OPENAI_API_KEY``  → ``api_key``
    - ``OPENAI_ORG``      → ``org``
    """

    model_config = SettingsConfigDict(env_prefix="OPENAI_", extra="ignore")

    api_key: SecretStr
    org: str | None = None


__all__ = ["OpenAISettings"]
