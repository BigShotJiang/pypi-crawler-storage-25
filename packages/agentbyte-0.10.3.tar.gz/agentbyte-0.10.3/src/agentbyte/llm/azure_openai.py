"""Compatibility shim for the legacy flat Azure OpenAI chat module path.

Canonical imports now live under ``agentbyte.llm.azure`` and
``agentbyte.llm.azure.chat``.
"""

from .azure.chat import (
    AzureOpenAIChatCompletionClient,
    AzureOpenAIChatCompletionClientConfig,
)

__all__ = [
    "AzureOpenAIChatCompletionClient",
    "AzureOpenAIChatCompletionClientConfig",
]
