"""Compatibility shim for the legacy flat Azure OpenAI embedding module path.

Canonical imports now live under ``agentbyte.llm.azure`` and
``agentbyte.llm.azure.embedding``.
"""

from .azure.embedding import (
    AzureOpenAIEmbeddingClient,
    AzureOpenAIEmbeddingClientConfig,
)

__all__ = [
    "AzureOpenAIEmbeddingClient",
    "AzureOpenAIEmbeddingClientConfig",
]
