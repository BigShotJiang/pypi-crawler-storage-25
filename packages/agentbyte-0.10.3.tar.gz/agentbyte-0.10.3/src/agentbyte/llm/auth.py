"""Compatibility shim for the legacy flat auth module path.

Canonical imports now live under ``agentbyte.llm.azure.auth``.
"""

from .azure.auth import (
    create_token_provider_from_string,
    get_certificate_token_provider,
    get_default_token_provider,
)

__all__ = [
    "get_default_token_provider",
    "get_certificate_token_provider",
    "create_token_provider_from_string",
]
