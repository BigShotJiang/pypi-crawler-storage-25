"""Compatibility re-export for the base evaluation judge."""

from agentbyte.eval.base import BaseEvalJudge

__all__ = ["BaseEvalJudge"]
