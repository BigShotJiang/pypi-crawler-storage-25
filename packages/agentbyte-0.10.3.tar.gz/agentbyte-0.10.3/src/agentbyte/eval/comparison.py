"""Helpers for comparing evaluated configurations."""

from __future__ import annotations

from agentbyte.eval.types import EvalScore


def compare_configurations(
    scores_a: list[EvalScore],
    scores_b: list[EvalScore],
    label_a: str = "baseline",
    label_b: str = "candidate",
) -> dict[str, float | str]:
    """Compare average score between two evaluated configurations."""
    avg_a = _average(scores_a)
    avg_b = _average(scores_b)

    if avg_a == 0:
        improvement_pct = 0.0 if avg_b == 0 else 100.0
    else:
        improvement_pct = ((avg_b - avg_a) / avg_a) * 100.0

    return {
        "label_a": label_a,
        "label_b": label_b,
        "avg_a": avg_a,
        "avg_b": avg_b,
        "improvement_pct": improvement_pct,
    }


def _average(scores: list[EvalScore]) -> float:
    if not scores:
        return 0.0
    return sum(score.overall for score in scores) / len(scores)


__all__ = ["compare_configurations"]
