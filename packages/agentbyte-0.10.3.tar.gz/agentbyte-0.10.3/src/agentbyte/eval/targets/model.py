"""Evaluation target for direct model calls."""

from __future__ import annotations

import time

from agentbyte.cancellation_token import CancellationToken
from agentbyte.llm import BaseChatCompletionClient
from agentbyte.messages import SystemMessage, Usage, UserMessage

from agentbyte.eval.base import BaseEvalTarget
from agentbyte.eval.types import EvalTask, EvalTrajectory


class ModelEvalTarget(BaseEvalTarget):
    """Wrap a raw chat-completion client as an evaluation target."""

    def __init__(
        self,
        client: BaseChatCompletionClient,
        system_message: str | None = None,
        name: str | None = None,
    ) -> None:
        super().__init__(name=name or getattr(client, "model", "Model"))
        self.client = client
        self.system_message = system_message

    async def run(
        self,
        task: EvalTask,
        cancellation_token: CancellationToken | None = None,
    ) -> EvalTrajectory:
        start_time = time.perf_counter()
        if cancellation_token and cancellation_token.is_cancelled():
            return self._build_failed_trajectory(
                task,
                start_time,
                error="Execution cancelled before model call",
            )

        messages = []
        if self.system_message:
            messages.append(SystemMessage(content=self.system_message, source="system"))
        messages.append(UserMessage(content=task.input, source="user"))

        try:
            result = await self.client.create(messages)
            elapsed_ms = int((time.perf_counter() - start_time) * 1000)
            return EvalTrajectory(
                task=task,
                messages=[*messages, result.message],
                success=True,
                error=None,
                usage=result.usage,
                metadata={
                    "target_type": "model",
                    "target_name": self.name,
                    "model": result.model,
                    "finish_reason": result.finish_reason,
                    "execution_time_ms": elapsed_ms,
                },
            )
        except Exception as exc:
            return self._build_failed_trajectory(task, start_time, error=str(exc))

    def _build_failed_trajectory(
        self,
        task: EvalTask,
        start_time: float,
        *,
        error: str,
    ) -> EvalTrajectory:
        elapsed_ms = int((time.perf_counter() - start_time) * 1000)
        return EvalTrajectory(
            task=task,
            messages=[],
            success=False,
            error=error,
            usage=Usage(duration_ms=elapsed_ms),
            metadata={
                "target_type": "model",
                "target_name": self.name,
                "execution_time_ms": elapsed_ms,
            },
        )


__all__ = ["ModelEvalTarget"]
