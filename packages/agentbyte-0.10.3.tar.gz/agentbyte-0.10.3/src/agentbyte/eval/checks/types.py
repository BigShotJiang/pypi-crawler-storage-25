"""Core types for local evaluation checks."""

from __future__ import annotations

from collections.abc import Awaitable, Callable

from pydantic import BaseModel, ConfigDict, Field

from agentbyte.eval.types import EvalTrajectory, ExpectedToolCall


class CheckResult(BaseModel):
    """Result from a single local evaluation check."""

    model_config = ConfigDict(frozen=True)

    passed: bool = Field(..., description="Whether the check passed")
    reason: str = Field(..., description="Human-readable explanation")
    check_name: str = Field(..., description="Check display name")
    score: float | None = Field(
        default=None,
        description="Optional numeric score associated with the check",
    )


EvalCheck = Callable[[EvalTrajectory], CheckResult | Awaitable[CheckResult]]

__all__ = ["ExpectedToolCall", "CheckResult", "EvalCheck"]
