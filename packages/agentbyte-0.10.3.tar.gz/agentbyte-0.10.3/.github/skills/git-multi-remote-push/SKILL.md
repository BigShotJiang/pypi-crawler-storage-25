---
name: git-multi-remote-push
description: Guide for pushing to multiple Git remotes (GitHub, GitLab, Bitbucket) from one local repo using multi-push URLs or a dedicated alias remote. Use this when asked to sync a repo to more than one remote origin.
---

Use this skill when the user wants a single `git push` to reach multiple remote repositories simultaneously.

## Inputs to confirm
- The primary remote URL (default: `origin`)
- Additional remote URLs to push to
- The branch name to push (e.g. `main`)
- Whether to keep `origin` intact or create a new alias remote

## Approach A — Multiple push URLs on `origin`

Best when you want `git push origin <branch>` to broadcast to all remotes.

```bash
# 1. Set the first (primary) push URL explicitly
git remote set-url --add --push origin https://github.com/user/repo.git

# 2. Add every additional remote as another push URL
git remote set-url --add --push origin https://gitlab.com/user/repo.git

# 3. Verify — each push URL appears on its own line
git remote -v

# 4. Push as normal — all URLs receive the push
git push origin main
```

> Fetching still uses only the first URL. Pull from one remote only to avoid
> divergent histories.

## Approach B — Dedicated `all` alias remote

Best when you want to keep `origin` untouched and push everywhere explicitly.

```bash
# 1. Create the alias remote with the primary URL
git remote add all https://github.com/user/repo.git

# 2. Add additional push URLs to the alias
git remote set-url --add --push all https://gitlab.com/user/repo.git
git remote set-url --add --push all https://bitbucket.org/user/repo.git

# 3. Push via the alias
git push all main
```

## Verification

```bash
git remote -v
# Expected output shows each push URL on its own line:
# origin  https://github.com/user/repo.git (fetch)
# origin  https://github.com/user/repo.git (push)
# origin  https://gitlab.com/user/repo.git (push)
```

## Defaults
- If only two remotes are involved, prefer Approach A — fewer moving parts.
- If the user wants to preserve `origin` for single-remote pushes, use Approach B.
- Always specify the branch name explicitly (`git push origin main`, not `git push`).

## Guardrails
- Do not add push URLs without confirming the remote accepts the same commit history.
- Pull from one designated remote only — never configure fetch URLs for all remotes.
- Do not use `--force` push across multiple remotes without explicit user instruction.
- Verify all remote URLs with `git remote -v` after setup before the first push.
