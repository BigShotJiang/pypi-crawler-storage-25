---
name: agentbyte-agent-as-tool
description: Guide for the Orchestrator-Specialist pattern. Use this to wrap an Agentbyte agent as a tool that can be executed by another coordinator agent.
---

Use this skill when building complex agentic teams or delegated workflows.

## Pattern: AgentAsTool
```python
from agentbyte.agents import Agent
from agentbyte.agents.agent_as_tool import AgentAsTool

# 1. Define specialist agent
research_agent = Agent(
    name="researcher",
    description="Research-focused specialist that queries for data.",
    instructions="Research the topic provided and return a summary.",
    model_client=client
)

# 2. Wrap as a tool
research_tool = AgentAsTool(research_agent)

# 3. Add to coordinator agent
coordinator = Agent(
    name="manager",
    description="Orchestrates task execution by delegating to researcher.",
    model_client=client,
    tools=[research_tool] # Coordinator sees researcher as a tool
)

response = await coordinator.run("Tell me about the history of solar panels.")
```

## Key Benefits
- **Specialization:** Specialists have their own instructions, tools, and model client settings.
- **Isolation:** Coordinator only sees the task input/output, keeping context windows cleaner.

## Guardrails
- **Naming:** The name of the `AgentAsTool` must be unique in the coordinator's tool list.
- **Description:** Provide a very clear `description` for the specialist agent; that description is what the coordinator sees to decide when to invoke it.
