---
name: agentbyte-list-memory
description: Guide for adding persistent memory to Agentbyte agents using ListMemory. Use this when you want agents to store, retrieve, and learn from cross-interaction knowledge.
---

Use this skill when implementing local, in-memory knowledge stores for agents.

## Pattern: ListMemory Usage
```python
from agentbyte.memory import ListMemory, MemoryContent
from agentbyte.agents import Agent

# 1. Initialize local memory
user_memory = ListMemory()

# 2. Pre-load knowledge (if needed)
user_memory.add(MemoryContent(content="The user likes coffee and uses Python 3.13."))

# 3. Attach to agent
agent = Agent(
    name="concierge",
    memory=user_memory,
    ...
)

# 4. First turn: Agent 'learns' from the context
response = await agent.run("What is my favorite language?")
print(response.messages[-1].content) # "You use Python 3.13."
```

## Advanced Memory: OperationRecorder
To allow agents to **write** to their own memory during a run, add the recorder middleware:
```python
from agentbyte.middleware import OperationRecorderMiddleware

agent = Agent(
    ...,
    memory=user_memory,
    middlewares=[OperationRecorderMiddleware()]
)
```

## Guardrails
- **In-Memory:** `ListMemory` is not persisted to disk by default.
- **System Prompt:** Memory is automatically injected into the agent's system prompt instructions.
- **Context vs Memory:** `AgentContext` threads messages (short-term); `Memory` stores facts (long-term).
