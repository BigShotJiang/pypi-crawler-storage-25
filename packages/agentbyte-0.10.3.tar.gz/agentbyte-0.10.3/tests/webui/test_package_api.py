"""Tests for WebUI import surfaces."""

from __future__ import annotations


def test_webui_import_paths() -> None:
    from agentbyte import WebUIServer, create_app, serve
    from agentbyte.webui import WebUIServer as FlatWebUIServer
    from agentbyte.webui import create_app as FlatCreateApp
    from agentbyte.webui import serve as FlatServe

    assert WebUIServer is FlatWebUIServer
    assert create_app is FlatCreateApp
    assert serve is FlatServe
