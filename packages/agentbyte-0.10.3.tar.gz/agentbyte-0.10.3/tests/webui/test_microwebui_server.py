"""Tests for the FastAPI microwebui server."""

from __future__ import annotations

import pytest

try:
    from fastapi.testclient import TestClient
except ImportError:  # pragma: no cover - optional dependency path
    TestClient = None

from agentbyte.microwebui import create_app

from .helpers import DummyAgent

pytestmark = pytest.mark.skipif(TestClient is None, reason="fastapi not installed")


def test_microwebui_root_disables_html_caching() -> None:
    client = TestClient(create_app([DummyAgent()]))

    response = client.get("/")

    assert response.status_code == 200
    assert response.headers["cache-control"] == "no-store, no-cache, must-revalidate, max-age=0"
    assert response.headers["pragma"] == "no-cache"
    assert response.headers["expires"] == "0"
