from __future__ import annotations

from types import SimpleNamespace

from agentbyte.presets.agents import (
    get_query_rewriter,
    get_researcher,
    get_reviewer,
    get_writer,
)


def _dummy_client():
    return SimpleNamespace(model="test-model")


def test_get_query_rewriter_returns_plain_llm_agent():
    agent = get_query_rewriter(model_client=_dummy_client())

    assert agent.name == "query_rewriter"
    assert agent.tools == []
    assert agent.output_format is None
    assert "improved query variations" in agent.instructions


def test_role_builders_return_default_llm_only_agents():
    researcher = get_researcher(model_client=_dummy_client())
    writer = get_writer(model_client=_dummy_client())
    reviewer = get_reviewer(model_client=_dummy_client())

    assert researcher.name == "researcher"
    assert writer.name == "writer"
    assert reviewer.name == "reviewer"
    assert researcher.tools == []
    assert writer.tools == []
    assert reviewer.tools == []
    assert "Do not claim live browsing" in researcher.instructions
    assert "TERMINATE" not in writer.instructions
    assert "complete final draft" in writer.instructions
    assert "APPROVED" in reviewer.instructions


def test_writer_builder_can_add_completion_signal():
    writer = get_writer(model_client=_dummy_client(), completion_signal="TERMINATE")

    assert "TERMINATE" in writer.instructions


def test_reviewer_builder_can_disable_approval_keyword():
    reviewer = get_reviewer(model_client=_dummy_client(), approval_signal=None)

    assert "APPROVED" not in reviewer.instructions
    assert "draft is ready" in reviewer.instructions
