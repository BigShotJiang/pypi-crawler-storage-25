import time
from agentbyte.termination.timeout import TimeoutTermination
from agentbyte.messages import UserMessage


class TestTimeoutTermination:
    def test_timeout(self):
        term = TimeoutTermination(timeout_seconds=0.1)
        msg = UserMessage(content="test", source="user")

        # First check starts timer
        assert term.check([msg]) is None
        assert term.start_time is not None

        # Wait for timeout
        time.sleep(0.15)

        stop = term.check([msg])
        assert stop is not None
        assert "Timeout exceeded" in stop.content
        assert term.is_met()

    def test_reset(self):
        term = TimeoutTermination(timeout_seconds=10)
        term.check([UserMessage(content="t", source="u")])
        assert term.start_time is not None

        term.reset()
        assert not term.is_met()
        assert term.start_time is None
