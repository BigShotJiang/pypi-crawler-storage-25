import pytest
from agentbyte.termination.max_message import MaxMessageTermination
from agentbyte.messages import UserMessage


class TestMaxMessageTermination:
    def test_max_messages(self):
        term = MaxMessageTermination(max_messages=3)
        msg = UserMessage(content="test", source="user")

        # Check 1
        assert term.check([msg]) is None
        assert term.message_count == 1

        # Check 2 (delta)
        assert term.check([msg]) is None
        assert term.message_count == 2

        # Check 3 (reaches limit)
        stop = term.check([msg])
        assert stop is not None
        assert "Maximum messages reached" in stop.content
        assert term.message_count == 3
        assert term.is_met()

    def test_invalid_config(self):
        with pytest.raises(ValueError):
            MaxMessageTermination(max_messages=0)
        with pytest.raises(ValueError):
            MaxMessageTermination(max_messages=-1)

    def test_reset(self):
        term = MaxMessageTermination(max_messages=1)
        term.check([UserMessage(content="test", source="user")])
        assert term.is_met()

        term.reset()
        assert not term.is_met()
        assert term.message_count == 0
