import pytest
from agentbyte.termination.cancellation import CancellationTermination
from agentbyte.cancellation_token import CancellationToken
from agentbyte.messages import UserMessage


class TestCancellationTermination:
    def test_cancellation(self):
        token = CancellationToken()
        term = CancellationTermination(token)
        msg = UserMessage(content="test", source="user")

        assert term.check([msg]) is None

        token.cancel()
        stop = term.check([msg])
        assert stop is not None
        assert "Cancellation requested" in stop.content
        assert term.is_met()

    def test_invalid_config(self):
        with pytest.raises(ValueError):
            CancellationTermination(None)  # type: ignore
