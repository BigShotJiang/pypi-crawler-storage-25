"""Tests for additional agent event type parity models."""

from agentbyte.agents import (
    ErrorEvent,
    FatalErrorEvent,
    MemoryRetrievalEvent,
    MemoryUpdateEvent,
    ToolApprovalEvent,
    ToolValidationEvent,
)
from agentbyte.context import ToolApprovalRequest
from agentbyte.messages import ToolCallRequest


def test_tool_approval_event_model() -> None:
    request = ToolApprovalRequest(
        request_id="approval_call-1",
        tool_call_id="call-1",
        tool_name="dangerous_tool",
        parameters={"path": "/tmp/file.txt"},
        original_tool_call=ToolCallRequest(
            tool_name="dangerous_tool",
            parameters={"path": "/tmp/file.txt"},
            call_id="call-1",
        ),
    )

    event = ToolApprovalEvent(source="assistant", approval_request=request)

    assert event.event_type == "tool_approval"
    assert event.approval_request.tool_name == "dangerous_tool"


def test_tool_validation_event_model() -> None:
    event = ToolValidationEvent(
        source="assistant",
        tool_name="calculator",
        is_valid=False,
        errors=["Missing required parameter: expression"],
    )

    assert event.event_type == "tool_validation"
    assert event.is_valid is False
    assert event.errors == ["Missing required parameter: expression"]


def test_memory_update_event_model() -> None:
    event = MemoryUpdateEvent(
        source="assistant",
        operation="add",
        content_summary="Stored user preference for concise responses",
    )

    assert event.event_type == "memory_update"
    assert event.operation == "add"


def test_memory_retrieval_event_model() -> None:
    event = MemoryRetrievalEvent(
        source="assistant",
        query="user communication preferences",
        results_count=3,
    )

    assert event.event_type == "memory_retrieval"
    assert event.query == "user communication preferences"
    assert event.results_count == 3


def test_error_event_model() -> None:
    """Test enhanced ErrorEvent with error_type and is_recoverable."""
    event = ErrorEvent(
        source="assistant",
        error_message="Failed to connect to database",
        error_type="DatabaseConnectionError",
        is_recoverable=True,
    )

    assert event.event_type == "error"
    assert event.error_message == "Failed to connect to database"
    assert event.error_type == "DatabaseConnectionError"
    assert event.is_recoverable is True


def test_fatal_error_event_model() -> None:
    """Test FatalErrorEvent for unrecoverable errors."""
    event = FatalErrorEvent(
        source="assistant",
        error_message="Critical system failure",
        error_type="SystemError",
    )

    assert event.event_type == "fatal_error"
    assert event.error_message == "Critical system failure"
    assert event.error_type == "SystemError"
    assert event.is_recoverable is False  # Always False for fatal errors

