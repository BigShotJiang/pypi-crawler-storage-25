"""Provisioning API for TEE node management."""

from typing import Any, Dict, Optional
import requests


class ProvisioningAPI:
    """API for provisioning and re-provisioning TEE nodes."""

    def __init__(self, base_url: str, verify_ssl: bool = True, timeout: int = 30):
        """
        Initialize ProvisioningAPI client.

        Args:
            base_url: Base URL of the TEE server (e.g., https://localhost:9099)
            verify_ssl: Whether to verify SSL certificates
            timeout: Request timeout in seconds
        """
        self.base_url = base_url
        self.verify_ssl = verify_ssl
        self.timeout = timeout

    def provision(
        self,
        client_id: str,
        num_encryptable: int,
        client_secret: Optional[str] = None,
        admin_token: Optional[str] = None,
        rotation_token: Optional[str] = None,
        client_ssl_cert_hex: Optional[str] = None,
        client_ssl_key_hex: Optional[str] = None,
        root_cert_hex: Optional[str] = None,
        instance_cert_hex: Optional[str] = None,
        instance_key_hex: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Provision the TEE node with client configuration and optional licenses.

        Contacts the License Manager to obtain a signed certificate and activates
        the node. If only client_config is provided (no SSL/license certs), the
        node contacts the License Manager. With out-of-band license, the node
        uses the provided certificate directly.

        Args:
            client_id: Unique client identifier (required)
            num_encryptable: Number of models allowed to encrypt (required)
            client_secret: Optional client secret. When provided, the effective identity
                sent to the TEE and License Manager is '{client_id}:{client_secret}'.
                If None, only client_id is used. (optional)
            admin_token: Admin authentication token (optional)
            rotation_token: Token for credential rotation (optional)
            client_ssl_cert_hex: Client SSL cert, hex-encoded PEM (optional, requires client_ssl_key_hex)
            client_ssl_key_hex: Client SSL key, hex-encoded PEM (optional, requires client_ssl_cert_hex)
            root_cert_hex: Root CA cert, hex-encoded PEM (optional, requires instance_cert_hex + instance_key_hex)
            instance_cert_hex: Instance cert, hex-encoded PEM (optional, requires root_cert_hex + instance_key_hex)
            instance_key_hex: Instance key, hex-encoded PEM (optional, requires root_cert_hex + instance_cert_hex)

        Returns:
            Dict with provisioning status (e.g., {'status': 'Provisioned'})

        Raises:
            ValueError: If SSL certs or out-of-band license parameters are incomplete
            ConnectionError: If unable to connect to the TEE server
            requests.exceptions.HTTPError: If the server returns an error

        Note:
            If provisioned without a valid License Manager certificate, only a
            limited set of endpoints will be available on the node.
        """
        # Validate SSL certs (must be both or neither)
        ssl_provided = [client_ssl_cert_hex, client_ssl_key_hex]
        if any(ssl_provided) and not all(ssl_provided):
            raise ValueError("Both client_ssl_cert_hex and client_ssl_key_hex must be provided together")

        # Validate out-of-band license (all three required if any provided)
        oob_provided = [root_cert_hex, instance_cert_hex, instance_key_hex]
        if any(oob_provided) and not all(oob_provided):
            raise ValueError("root_cert_hex, instance_cert_hex, and instance_key_hex must all be provided together")

        # Compute effective client identity
        effective_client_id = f"{client_id}:{client_secret}" if client_secret else client_id

        # Build payload
        payload: Dict[str, Any] = {
            "client_config": {
                "client_id": effective_client_id,
                "num_encryptable": num_encryptable,
            }
        }

        if admin_token is not None:
            payload["client_config"]["admin_token"] = admin_token
        if rotation_token is not None:
            payload["client_config"]["rotation_token"] = rotation_token

        if all(ssl_provided):
            payload["ssl_certs"] = {
                "client_ssl_cert_hex": client_ssl_cert_hex,
                "client_ssl_key_hex": client_ssl_key_hex,
            }

        if all(oob_provided):
            payload["out_of_band_license"] = {
                "root_cert_hex": root_cert_hex,
                "instance_cert_hex": instance_cert_hex,
                "instance_key_hex": instance_key_hex,
            }

        url = f"{self.base_url}/provision"
        try:
            response = requests.post(url, json=payload, timeout=self.timeout, verify=self.verify_ssl)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Failed to connect to {url}: {e}")
        except requests.exceptions.HTTPError as e:
            try:
                body = e.response.json()
            except Exception:
                body = e.response.text
            raise requests.exceptions.HTTPError(f"HTTP {e.response.status_code}: {body}")

    def reuse_license(self) -> Dict[str, Any]:
        """
        Re-provision using the internal license stored in p2p-auth (TEE).

        Re-provisions the node using the license certificate that was stored
        in p2p-auth during the previous provisioning. Works only after
        ``deprovision`` when the node is in PROVISIONING state. The server
        retrieves the cached license and re-creates the provisioned state
        without contacting the License Manager.

        Returns:
            Dict with provisioning status (e.g., {'status': 'Provisioned'})

        Raises:
            ConnectionError: If unable to connect to the TEE server
            requests.exceptions.HTTPError: If the server returns an error
        """
        url = f"{self.base_url}/provision"
        try:
            response = requests.post(url, json={}, timeout=self.timeout, verify=self.verify_ssl)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Failed to connect to {url}: {e}")
        except requests.exceptions.HTTPError as e:
            try:
                body = e.response.json()
            except Exception:
                body = e.response.text
            raise requests.exceptions.HTTPError(f"HTTP {e.response.status_code}: {body}")
