"""
Main CLI implementation for FHEnom AI.
"""

import click
import logging
import sys
import json
import yaml
import requests
from pathlib import Path
from typing import Optional, Any
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm
from rich.panel import Panel
from rich import print as rprint

from .config import FHEnomConfig
from .admin_api import AdminAPI
from .sftp import SFTPClient
from .exceptions import FHEnomError
from .client import FHEnomClient

# Get version
try:
    from importlib.metadata import version
    __version__ = version("fhenomai")
except Exception:
    __version__ = "1.1.0"

# Setup console with no width limit to prevent truncation
console = Console(width=200, soft_wrap=True)

# Setup logging
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Context object for passing config between commands
class Context:
    def __init__(self):
        self.config: Optional[FHEnomConfig] = None
        self.verbose: bool = False
        self.quiet: bool = False


pass_context = click.make_pass_decorator(Context, ensure=True)


@click.group()
@click.option('--config', '-c', type=click.Path(exists=True), help='Configuration file path')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output')
@click.option('--quiet', '-q', is_flag=True, help='Suppress non-essential output')
@click.version_option(version=__version__)
@pass_context
def cli(ctx: Context, config: Optional[str], verbose: bool, quiet: bool):
    """FHEnom AI Command Line Interface - Manage encrypted AI models and datasets."""
    ctx.verbose = verbose
    ctx.quiet = quiet
    
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    elif quiet:
        logging.getLogger().setLevel(logging.ERROR)
    
    # Load config
    try:
        if config:
            ctx.config = FHEnomConfig.from_file(config)
        else:
            ctx.config = FHEnomConfig.from_file()
    except FileNotFoundError as e:
        if config:
            # User specified a config file but it doesn't exist
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(1)
        # No config specified and no default found - that's okay for init command
        ctx.config = None


# ============================================================================
# CONFIG COMMANDS
# ============================================================================

@cli.group(name='config')
def config_cmd():
    """Configuration management commands."""
    pass


@config_cmd.command()
@click.option('--output', '-o', type=click.Path(), help='Output file path')
@click.option('--tee-ip', '--admin-host', 'admin_host', help='TEE/Admin API host IP')
@click.option('--admin-api-port', '--admin-port', 'admin_port', type=int, help='Admin API port')
@click.option('--user-host', help='User API host')
@click.option('--user-port', type=int, help='User API port')
@click.option('--sftp-host', help='SFTP host')
@click.option('--sftp-port', type=int, help='SFTP port')
@click.option('--sftp-username', help='SFTP username')
@click.option('--sftp-password', help='SFTP password')
@click.option('--workspace', type=click.Path(), help='Local workspace directory path')
@click.option('--timeout', type=int, help='Request timeout in seconds')
@click.option('--max-retries', type=int, help='Maximum number of retries')
@click.option('--use-ssl', is_flag=True, default=None, help='Use HTTPS instead of HTTP')
@click.option('--skip-ssl-checks', is_flag=True, default=None, help='Skip SSL certificate verification (only when --use-ssl)')
@click.option('--auth-token', help='Admin API authentication token')
@pass_context
def init(ctx: Context, output: Optional[str], admin_host: Optional[str],
         admin_port: Optional[int], user_host: Optional[str], user_port: Optional[int],
         sftp_host: Optional[str], sftp_port: Optional[int], sftp_username: Optional[str],
         sftp_password: Optional[str], workspace: Optional[str], timeout: Optional[int],
         max_retries: Optional[int], use_ssl: Optional[bool], skip_ssl_checks: Optional[bool],
         auth_token: Optional[str]):
    """Initialize a new configuration file."""
    # If a config was already loaded via -c, use it as the base
    if ctx.config is not None:
        base = ctx.config
    else:
        base = None

    if output is None:
        output = str(Path.home() / ".fhenomai" / "config.yaml")

    output_path = Path(output)

    # Check if file already exists
    if output_path.exists():
        if not click.confirm(f"Config file already exists at {output_path}. Overwrite?"):
            console.print("[yellow]Cancelled[/yellow]")
            return

    # Create default config
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Build config: CLI args override base config, which overrides hardcoded defaults
    if base:
        default_host = admin_host or base.admin_host
    else:
        default_host = admin_host or '192.168.1.100'

    default_config = {
        'admin_host': default_host,
        'admin_port': admin_port or (base.admin_port if base else 9099),
        'user_host': user_host or (base.user_host if base else default_host),
        'user_port': user_port or (base.user_port if base else 9999),
        'sftp_host': sftp_host or (base.sftp_host if base else default_host),
        'sftp_port': sftp_port or (base.sftp_port if base else 22),
        'sftp_username': sftp_username or (base.sftp_username if base else 'admin'),
        'sftp_password': sftp_password or (base.sftp_password if base else 'your-password'),
        'workspace': workspace or (base.workspace if base and base.workspace else str(Path.home() / 'fhenomai_workspace')),
        'timeout': timeout or (base.timeout if base else 30),
        'max_retries': max_retries or (base.max_retries if base else 3),
        'use_ssl': use_ssl if use_ssl is not None else (base.use_ssl if base else False),
        'skip_ssl_checks': skip_ssl_checks if skip_ssl_checks is not None else (base.skip_ssl_checks if base else False),
        'auth_token': auth_token or (base.auth_token if base else 'default-auth-token-2026'),
    }

    with open(output_path, 'w') as f:
        yaml.dump(default_config, f, default_flow_style=False)

    console.print(f"[green]✓[/green] Created config file: {output_path}")
    if not base and not any([admin_host, admin_port, user_host, user_port, sftp_host, sftp_port, sftp_username, sftp_password]):
        console.print("\n[yellow]Please edit the file to add your credentials:[/yellow]")
        console.print(f"  {output_path}")


@config_cmd.command()
@pass_context
def show(ctx: Context):
    """Show current configuration."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    console.print("\n[bold]Current Configuration:[/bold]\n")
    
    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan", no_wrap=True)
    table.add_column("Value", no_wrap=True, overflow="fold")
    
    table.add_row("Admin URL", ctx.config.admin_url)
    table.add_row("User URL", ctx.config.user_url)
    table.add_row("SFTP Host", f"{ctx.config.sftp_host}:{ctx.config.sftp_port}")
    table.add_row("SFTP User", ctx.config.sftp_username)
    table.add_row("SFTP Password", ctx.config.sftp_password or "Not set")
    table.add_row("Auth Token", ctx.config.auth_token or "Not set")
    table.add_row("Workspace", getattr(ctx.config, 'workspace', 'Not set'))
    table.add_row("Timeout", f"{ctx.config.timeout}s")
    table.add_row("Max Retries", str(ctx.config.max_retries))
    table.add_row("Use SSL", "Yes" if ctx.config.use_ssl else "No")
    if ctx.config.use_ssl:
        table.add_row("SSL Verification", "Disabled" if ctx.config.skip_ssl_checks else "Enabled")
    
    console.print(table)
    console.print()


@config_cmd.command()
@click.argument('key')
@pass_context
def get(ctx: Context, key: str):
    """Get a specific configuration value (machine-readable output)."""
    err_console = Console(stderr=True)

    if ctx.config is None:
        err_console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    # Map of user-friendly keys to config attributes
    key_map = {
        'admin-url': 'admin_url',
        'admin-host': 'admin_host',
        'admin-port': 'admin_port',
        'user-url': 'user_url',
        'user-host': 'user_host',
        'user-port': 'user_port',
        'sftp-host': 'sftp_host',
        'sftp-port': 'sftp_port',
        'sftp-username': 'sftp_username',
        'sftp-password': 'sftp_password',
        'workspace': 'workspace',
        'timeout': 'timeout',
        'max-retries': 'max_retries',
        'use-ssl': 'use_ssl',
        'skip-ssl-checks': 'skip_ssl_checks',
        'auth-token': 'auth_token',
    }

    # Normalize key (allow both - and _)
    normalized_key = key.lower().replace('_', '-')

    if normalized_key not in key_map:
        err_console.print(f"[red]Error:[/red] Unknown key '{key}'")
        err_console.print(f"Available keys: {', '.join(sorted(key_map.keys()))}")
        sys.exit(1)

    attr_name = key_map[normalized_key]
    value = getattr(ctx.config, attr_name, None)

    if value is None:
        err_console.print(f"[red]Error:[/red] Key '{key}' not set")
        sys.exit(1)
    
    # Print raw value without any formatting (stdout only, no rich formatting)
    print(value)


@config_cmd.command()
@pass_context
def validate(ctx: Context):
    """Validate configuration file."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    console.print("[green]✓[/green] Configuration is valid")
    
    # Try to connect to services
    console.print("\nTesting connectivity...")
    
    # Test Admin API
    try:
        client = FHEnomClient(ctx.config)
        client.list_models()
        console.print("  [green]✓[/green] Admin API")
    except Exception as e:
        console.print(f"  [red]✗[/red] Admin API: {e}")
    
    # Test SFTP
    try:
        sftp = SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path,
            auto_connect=True
        )
        sftp.disconnect()
        console.print("  [green]✓[/green] SFTP")
    except Exception as e:
        console.print(f"  [red]✗[/red] SFTP: {e}")


# ============================================================================
# HEALTH CHECK COMMANDS
# ============================================================================

@cli.group()
def health():
    """Health check commands."""
    pass


@health.command()
@pass_context
def check(ctx: Context):
    """Check connectivity to all services."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    console.print("\n[bold]Health Check[/bold]\n")
    
    all_ok = True
    
    # Admin API
    console.print("Testing Admin API...", end=" ")
    try:
        client = FHEnomClient(ctx.config)
        models = client.list_models()
        console.print(f"[green]✓[/green] ({len(models)} models)")
    except Exception as e:
        console.print(f"[red]✗[/red] {e}")
        all_ok = False
    
    # SFTP
    console.print("Testing SFTP...", end=" ")
    try:
        with SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path
        ):
            pass
        console.print("[green]✓[/green]")
    except Exception as e:
        console.print(f"[red]✗[/red] {e}")
        all_ok = False
    
    console.print()
    
    if all_ok:
        console.print("[green]All systems operational[/green]")
        sys.exit(0)
    else:
        console.print("[red]Some systems failed[/red]")
        sys.exit(1)


@health.command()
@pass_context
def admin(ctx: Context):
    """Test Admin API connectivity."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        models = client.list_models()
        console.print(f"[green]✓[/green] Admin API is reachable ({len(models)} models configured)")
    except Exception as e:
        console.print(f"[red]✗[/red] Admin API failed: {e}")
        sys.exit(1)


@health.command()
@pass_context
def sftp(ctx: Context):
    """Test SFTP connectivity."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        with SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path
        ):
            pass
        console.print("[green]✓[/green] SFTP connection successful")
    except Exception as e:
        console.print(f"[red]✗[/red] SFTP failed: {e}")
        sys.exit(1)


@health.command()
@pass_context
def live(ctx: Context):
    """Check service liveness (lightweight check, no authentication required)."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.health_live()
        
        if result.get("status") == "alive":
            console.print("[green]✓[/green] Service is alive")
            console.print(f"Status: {result['status']}")
        else:
            console.print(f"[yellow]⚠[/yellow] Unexpected response: {result}")
    except Exception as e:
        console.print(f"[red]✗[/red] Liveness check failed: {e}")
        sys.exit(1)


@health.command()
@pass_context
def ready(ctx: Context):
    """Check system readiness and subsystem status."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.health_ready()
        
        console.print("\n[bold]System Readiness[/bold]\n")
        
        # Create table
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Subsystem", style="white", no_wrap=True)
        table.add_column("Status", style="white")
        
        all_ready = True
        for subsystem, status in result.items():
            if status.lower() in ["available", "up", "ready"]:
                status_display = f"[green]{status}[/green]"
            elif status.lower() in ["unavailable", "down", "not ready"]:
                status_display = f"[red]{status}[/red]"
                all_ready = False
            else:
                status_display = f"[yellow]{status}[/yellow]"
            
            table.add_row(subsystem, status_display)
        
        console.print(table)
        console.print()
        
        if all_ready:
            console.print("[green]✓[/green] All subsystems ready")
        else:
            console.print("[yellow]⚠[/yellow] Some subsystems not ready")
            sys.exit(1)
            
    except Exception as e:
        console.print(f"[red]✗[/red] Readiness check failed: {e}")
        sys.exit(1)


@health.command()
@click.option('--model-id', '-m', help='Filter metrics for specific model')
@click.option('--json-output', '-j', is_flag=True, help='Output raw JSON')
@pass_context
def status(ctx: Context, model_id: Optional[str], json_output: bool):
    """Get performance metrics and system status."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.health_status()
        
        if json_output:
            console.print(json.dumps(result, indent=2))
            return
        
        console.print("\n[bold]Performance Metrics[/bold]\n")
        
        # Show aggregate metrics
        if 'aggregate' in result:
            agg = result['aggregate']
            console.print("[bold cyan]Aggregate Metrics[/bold cyan]")
            console.print(f"  Latency: {agg.get('latency', 'N/A')}")
            console.print(f"  Tokens/sec: {agg.get('tokens_per_second', 'N/A')}")
            console.print(f"  Total requests: {agg.get('total_requests', 'N/A')}")
            console.print(f"  Last seen: {agg.get('last_seen', 'N/A')}")
            console.print()
        
        # Show per-model metrics
        if 'per_model' in result and result['per_model']:
            console.print("[bold cyan]Per-Model Metrics[/bold cyan]\n")
            
            table = Table(show_header=True, header_style="bold cyan")
            table.add_column("Model ID", style="white", no_wrap=False)
            table.add_column("Latency", justify="right")
            table.add_column("Tokens/sec", justify="right")
            table.add_column("Requests", justify="right")
            table.add_column("Last Seen", style="dim")
            
            for mid, metrics in result['per_model'].items():
                # Filter by model_id if specified
                if model_id and model_id not in mid:
                    continue
                    
                table.add_row(
                    mid,
                    f"{metrics.get('latency', 'N/A')}",
                    f"{metrics.get('tokens_per_second', 'N/A')}",
                    f"{metrics.get('total_requests', 'N/A')}",
                    f"{metrics.get('last_seen', 'N/A')}"
                )
            
            console.print(table)
        else:
            console.print("[dim]No per-model metrics available[/dim]")
        
        # Show timestamp
        if 'timestamp' in result:
            console.print(f"\n[dim]Snapshot: {result['timestamp']}[/dim]")
        
        console.print()
        
    except Exception as e:
        console.print(f"[red]✗[/red] Status check failed: {e}")
        sys.exit(1)


# ============================================================================
# TEST COMMANDS (Alias for health commands)
# ============================================================================

@cli.group()
def test():
    """Test connectivity and functionality."""
    pass


@test.command(name='connection')
@pass_context
def test_connection(ctx: Context):
    """Test connection to all services."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found. Run 'fhenomai config init' first.")
        sys.exit(1)
    
    console.print("\n[bold]Testing Connections[/bold]\n")
    all_ok = True
    
    # Test Admin API
    console.print("Testing Admin API...", end=" ")
    try:
        client = FHEnomClient(ctx.config)
        models = client.list_models()
        console.print(f"[green]✓[/green] Connected ({len(models)} models)")
    except Exception as e:
        console.print(f"[red]✗[/red] {str(e)[:50]}")
        all_ok = False
    
    # Test SFTP
    console.print("Testing SFTP...", end=" ")
    try:
        sftp = SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path,
            auto_connect=True
        )
        sftp.disconnect()
        console.print("[green]✓[/green] Connected")
    except Exception as e:
        console.print(f"[red]✗[/red] {str(e)[:50]}")
        all_ok = False
    
    console.print()
    
    if all_ok:
        console.print("[green]✓ All connections successful[/green]")
        sys.exit(0)
    else:
        console.print("[red]✗ Some connections failed[/red]")
        sys.exit(1)


@test.command(name='admin')
@pass_context
def test_admin(ctx: Context):
    """Test Admin API connectivity."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found. Run 'fhenomai config init' first.")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        models = client.list_models()
        console.print(f"[green]✓[/green] Admin API is reachable ({len(models)} models)")
        sys.exit(0)
    except Exception as e:
        console.print(f"[red]✗[/red] Admin API failed: {e}")
        sys.exit(1)


@test.command(name='sftp')
@pass_context
def test_sftp(ctx: Context):
    """Test SFTP connectivity."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found. Run 'fhenomai config init' first.")
        sys.exit(1)
    
    try:
        sftp = SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path,
            auto_connect=True
        )
        sftp.disconnect()
        console.print("[green]✓[/green] SFTP connection successful")
        sys.exit(0)
    except Exception as e:
        console.print(f"[red]✗[/red] SFTP failed: {e}")
        sys.exit(1)


# ============================================================================
# MODEL COMMANDS
# ============================================================================

@cli.group()
def model():
    """Model management commands."""
    pass


@model.command()
@click.argument('model_id')
@pass_context
def info(ctx: Context, model_id: str):
    """Get detailed model information."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        
        info = client.get_model_info(model_id)
        
        console.print(f"\n[bold]Model:[/bold] {model_id}\n")
        
        table = Table(show_header=False, box=None)
        table.add_column("Key", style="cyan")
        table.add_column("Value")
        
        for key, value in info.items():
            table.add_row(key, str(value))
        
        console.print(table)
        console.print()
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@model.command()
@click.argument('local_path', type=click.Path(exists=True))
@click.argument('model_name')
@click.option('--show-progress/--no-progress', default=True, help='Show upload progress')
@pass_context
def upload(ctx: Context, local_path: str, model_name: str, show_progress: bool):
    """Upload a model to the server."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        remote_path = f"upload/{model_name}"

        console.print(f"Uploading [cyan]{local_path}[/cyan] as [cyan]{model_name}[/cyan]...")

        with SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path
        ) as sftp:
            if Path(local_path).is_file():
                sftp.upload_file(local_path, f"{remote_path}/{Path(local_path).name}")
            else:
                sftp.upload_directory(local_path, remote_path)

        console.print(f"[green]✓[/green] Uploaded to {remote_path}")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@model.command()
@click.argument('model_name')
@click.argument('local_path', type=click.Path())
@click.option('--show-progress/--no-progress', default=True, help='Show download progress')
@pass_context
def download(ctx: Context, model_name: str, local_path: str, show_progress: bool):
    """Download a model from the server."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        remote_path = f"download/{model_name}"

        console.print(f"Downloading [cyan]{model_name}[/cyan] to [cyan]{local_path}[/cyan]...")
        
        with SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path
        ) as sftp:
            sftp.download_directory(remote_path, local_path)
        
        console.print(f"[green]✓[/green] Downloaded to {local_path}")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@model.command()
@click.argument('model_name_or_path')
@click.argument('out_encrypted_model_path')
@click.option('--wait/--no-wait', default=True, help='Wait for completion')
@click.option('--encryption-impl', default='decoder-only-llm', help='Encryption implementation')
@click.option('--dtype', default='bfloat16', help='Data type')
@click.option('--encrypted-model-id', default=None, help='Custom encrypted model ID/name')
@click.option('--symbolic-name', default=None, help='Symbolic name for the encrypted model')
@click.option('--server-ip', default='fhenom_ai_server', help='FHEnom AI Server hostname/IP')
@click.option('--server-port', type=int, default=9100, help='Server admin port')
@click.option('--preprocessing-impl', default='default', help='Preprocessing strategy')
@click.option('--inference-mode', default='double_tokenizer', help='Inference mode')
@click.option('--driver-mode', default='safetensor', help='Model driver mode')
@click.option('--model-key-password', default=None, help='Password for model encryption keys')
@click.option('--show-progress/--no-progress', default=True, help='Show progress')
@click.option('--timeout', type=int, default=3600, help='Timeout in seconds')
@click.option('--force', is_flag=True, help='Skip duplicate name check')
@pass_context
def encrypt(ctx: Context, model_name_or_path: str, out_encrypted_model_path: str, wait: bool,
            encryption_impl: str, dtype: str, encrypted_model_id: Optional[str], symbolic_name: Optional[str],
            server_ip: str, server_port: int, preprocessing_impl: str, inference_mode: str, driver_mode: str,
            model_key_password: Optional[str], show_progress: bool, timeout: int, force: bool):
    """Encrypt a model."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(config=ctx.config)
        
        # Normalize paths: add upload/ or download/ if not present
        if not model_name_or_path.startswith('upload/') and not model_name_or_path.startswith('/models/upload/'):
            model_name_or_path = f"upload/{model_name_or_path}"
        
        if not out_encrypted_model_path.startswith('download/') and not out_encrypted_model_path.startswith('/models/download/'):
            out_encrypted_model_path = f"download/{out_encrypted_model_path}"
        
        # Extract model name for duplicate check
        output_model_name = out_encrypted_model_path.replace('download/', '').replace('/models/download/', '')
        
        # Check for duplicate names unless --force flag is used
        if not force:
            try:
                model_ids = client.admin.list_models()
                existing_names = []
                
                for model_id in model_ids:
                    try:
                        info = client.admin.get_model_info(model_id)
                        server_path = info.get('encrypted_model_server_path', '')
                        if server_path.startswith('/models/download/'):
                            existing_name = server_path.replace('/models/download/', '', 1)
                            if existing_name == output_model_name:
                                existing_names.append(model_id)
                    except:
                        pass
                
                if existing_names:
                    console.print(f"\n[yellow]⚠ Warning:[/yellow] The name '[cyan]{output_model_name}[/cyan]' is already used by {len(existing_names)} model(s):")
                    for existing_id in existing_names[:3]:  # Show first 3
                        console.print(f"  • {existing_id}")
                    if len(existing_names) > 3:
                        console.print(f"  ... and {len(existing_names) - 3} more")
                    
                    console.print("\n[dim]Note: The new encrypted model will have a unique ID, but using the same name may cause confusion when listing models.[/dim]\n")
                    
                    if not click.confirm("Do you want to proceed with this name?", default=False):
                        new_name = click.prompt("Enter a new output name (without download/ prefix)", type=str)
                        out_encrypted_model_path = f"download/{new_name}"
                        output_model_name = new_name
                        console.print(f"\n[green]✓[/green] Using new name: [cyan]{output_model_name}[/cyan]\n")
            except Exception as e:
                # If check fails, just warn and continue
                console.print(f"[yellow]Warning:[/yellow] Could not check for duplicate names: {e}")
        
        console.print(f"Encrypting [cyan]{model_name_or_path}[/cyan] → [cyan]{out_encrypted_model_path}[/cyan]...")
        
        input_path = f"/models/{model_name_or_path}"
        output_path = f"/models/{out_encrypted_model_path}"
        
        job_id = client.encrypt_model(
            model_name_or_path=input_path,
            out_encrypted_model_path=output_path,
            symbolic_name=symbolic_name,
            server_ip=server_ip,
            server_port=server_port,
            encryption_impl=encryption_impl,
            preprocessing_impl=preprocessing_impl,
            inference_mode=inference_mode,
            driver_mode=driver_mode,
            dtype=dtype,
            model_key_password=model_key_password,
            encrypted_model_id=encrypted_model_id
        )
        
        console.print(f"Job started: [cyan]{job_id}[/cyan]")
        
        if wait:
            if show_progress:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=console
                ) as progress:
                    task = progress.add_task("Encrypting...", total=None)
                    
                    def callback(status):
                        progress_pct = status.get('progress', 0) * 100
                        message = status.get('message', '')
                        progress.update(task, description=f"{message} ({progress_pct:.1f}%)")
                    
                    result = client.wait_for_job(job_id, timeout=timeout, callback=callback)
            else:
                console.print("Waiting for completion...")
                result = client.wait_for_job(job_id, timeout=timeout)
            
            console.print(f"[green]✓[/green] Encryption completed")
            
            # Show encrypted model ID if available
            if result.get('status') == 'done' and 'result' in result:
                encrypted_model_id_result = result['result'].get('encrypted_model_id')
                if encrypted_model_id_result:
                    console.print(f"[cyan]Encrypted Model ID:[/cyan] {encrypted_model_id_result}")
        else:
            console.print("Use 'fhenomai job status' to check progress")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@model.command(name='list')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table', help='Output format')
@click.option('--show-status', is_flag=True, help='Show online/offline status (requires additional API call)')
@click.option('--show-details', is_flag=True, help='Show detailed info like encryption impl and dtype (requires API calls per model)')
@pass_context
def list_models_cmd(ctx: Context, output_format: str, show_status: bool, show_details: bool):
    """List all encrypted models on the TEE server."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found. Run 'fhenomai config init' first.")
        sys.exit(1)
    
    try:
        client = FHEnomClient(config=ctx.config)
        model_ids = client.admin.list_models()
        
        # Get online models if status requested
        online_model_ids = set()
        if show_status:
            try:
                online_models = client.admin.list_online_models()
                # Extract model IDs from online models list
                for model in online_models:
                    online_model_ids.add(model.get('name', ''))
            except:
                pass  # If we can't get online status, just continue
        
        # Fetch detailed info for each model if requested
        models = []
        for model_id in model_ids:
            model_data = {
                "encrypted_model_id": model_id,
                "model_name": model_id.split('/')[-1]  # Default fallback
            }
            
            if show_details:
                try:
                    info = client.admin.get_model_info(model_id)
                    # Extract model name from encrypted_model_server_path
                    server_path = info.get('encrypted_model_server_path', '')
                    if server_path.startswith('/models/download/'):
                        model_data["model_name"] = server_path.replace('/models/download/', '', 1)
                    else:
                        model_data["model_name"] = server_path.split('/')[-1] if server_path else model_id.split('/')[-1]
                    
                    model_data["encryption_impl"] = info.get('encryption_impl', 'unknown')
                    model_data["dtype"] = info.get('dtype', 'unknown')
                except:
                    pass  # Use defaults if we can't get info
            
            if show_status:
                model_data["status"] = "online" if model_id in online_model_ids else "offline"
            
            models.append(model_data)
        
        if output_format == 'json':
            import json
            print(json.dumps({"models": models}, indent=2))
        else:
            if not models:
                console.print("[yellow]No encrypted models found[/yellow]")
                return
            
            from rich.table import Table
            table = Table(title="Encrypted Models", show_header=True, header_style="bold magenta")
            table.add_column("Encrypted Model ID", style="cyan")
            
            if show_details:
                table.add_column("Model Name", style="green")
                table.add_column("Encryption", style="yellow")
            
            if show_status:
                table.add_column("Status", style="blue")
            
            for model in models:
                row = [model['encrypted_model_id']]
                
                if show_details:
                    row.append(model['model_name'])
                    row.append(model.get('encryption_impl', 'N/A'))
                
                if show_status:
                    status = model.get('status', 'unknown')
                    if status == 'online':
                        row.append('[green]●[/green] online')
                    else:
                        row.append('[dim]○[/dim] offline')
                
                table.add_row(*row)
            
            console.print(table)
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@model.command(name='encrypt-dataset')
@click.option('--encrypted-model-id', required=True, help='Encrypted model ID to use')
@click.option('--dataset-path', required=True, help='Path to dataset on server (e.g., /models/upload/dataset)')
@click.option('--output-path', required=True, help='Output-path for encrypted dataset (e.g., /models/download/dataset_enc)')
@click.option('--encryption-impl', default='numeric', help='Dataset encryption implementation')
@click.option('--text-fields', multiple=True, help='Text fields to encrypt (can specify multiple times)')
@click.option('--wait/--no-wait', default=True, help='Wait for completion')
@click.option('--show-progress/--no-progress', default=True, help='Show progress')
@click.option('--timeout', type=int, default=3600, help='Timeout in seconds')
@pass_context
def encrypt_dataset(ctx: Context, encrypted_model_id: str, dataset_path: str, output_path: str,
                    encryption_impl: str, text_fields: tuple, wait: bool, show_progress: bool, timeout: int):
    """Encrypt a dataset using an encrypted model."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(config=ctx.config)
        
        # Normalize paths: add upload/ or download/ if not present
        if not dataset_path.startswith('upload/') and not dataset_path.startswith('/models/upload/'):
            dataset_path = f"upload/{dataset_path}"
        
        if not output_path.startswith('download/') and not output_path.startswith('/models/download/'):
            output_path = f"download/{output_path}"
        
        console.print(f"Encrypting dataset [cyan]{dataset_path}[/cyan] → [cyan]{output_path}[/cyan]...")
        console.print(f"Using encrypted model: [cyan]{encrypted_model_id}[/cyan]")
        
        # Convert text_fields tuple to list using list comprehension
        # Note: list(text_fields) causes issues, so we use comprehension instead
        text_fields_list = [x for x in text_fields] if text_fields else ["text"]
        
        job_id = client.admin.encrypt_dataset(
            encrypted_model_id=encrypted_model_id,
            server_ip="fhenom_ai_server",
            server_port=9100,
            dataset_name_or_path=dataset_path,
            out_encrypted_dataset_path=output_path,
            dataset_encryption_impl=encryption_impl,
            text_fields=text_fields_list
        )
        
        console.print(f"Job started: [cyan]{job_id}[/cyan]")
        
        if wait:
            console.print("Waiting for completion...")
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("Encrypting dataset...", total=None)
                
                def callback(status):
                    progress_pct = status.get('progress', 0) * 100
                    message = status.get('message', '')
                    progress.update(task, description=f"{message} ({progress_pct:.1f}%)")
                
                result = client.wait_for_job(job_id, timeout=timeout, callback=callback)
            
            if result.get('status') == 'done':
                console.print(f"[green]✓[/green] Dataset encryption completed")
            else:
                console.print(f"[yellow]⚠[/yellow] Job finished with status: {result.get('status')}")
                if 'error' in result:
                    console.print(f"[red]Error:[/red] {result['error']}")
        else:
            console.print("Use 'fhenomai job status' to check progress")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@model.command()
@click.argument('model_name')
@click.option('--force', is_flag=True, help='Delete without confirmation')
@pass_context
def delete(ctx: Context, model_name: str, force: bool):
    """Delete a model from the server (SFTP-based upload/download directories)."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    if not force:
        if not click.confirm(f"Are you sure you want to delete '{model_name}'?"):
            console.print("[yellow]Cancelled[/yellow]")
            return
    
    try:
        with SFTPClient(
            host=ctx.config.sftp_host,
            port=ctx.config.sftp_port,
            username=ctx.config.sftp_username,
            password=ctx.config.sftp_password,
            key_path=ctx.config.sftp_key_path
        ) as sftp:
            # Try both upload and download directories
            deleted = False
            for prefix in ['upload', 'download']:
                remote_path = f"{prefix}/{model_name}"
                try:
                    sftp.delete(remote_path, recursive=True)
                    console.print(f"[green]✓[/green] Deleted {model_name} from {prefix}/")
                    deleted = True
                except Exception as e:
                    if "Permission denied" in str(e):
                        console.print(f"[red]Error:[/red] Permission denied deleting {model_name} from {prefix}/")
                        console.print("[dim]Hint: Files in download/ are created by the TEE. Use 'model delete-encrypted' to remove encrypted models.[/dim]")
                    else:
                        logger.debug(f"Could not delete {remote_path}: {e}")
            if not deleted:
                console.print(f"[red]Error:[/red] Model '{model_name}' not found in upload/ or download/")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@model.command(name='delete-encrypted')
@click.argument('model_id')
@click.option('--force', is_flag=True, help='Delete without confirmation')
@pass_context
def delete_encrypted(ctx: Context, model_id: str, force: bool):
    """Delete an encrypted model from TEE storage (local only, does not propagate to peers)."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    if not force:
        console.print(f"\n[yellow]Warning:[/yellow] This will delete the encrypted model: [cyan]{model_id}[/cyan]")
        console.print("[dim]Note: This is a local operation and will not propagate to peer instances.[/dim]\n")
        
        if not click.confirm("Are you sure you want to continue?"):
            console.print("[yellow]Cancelled[/yellow]")
            return
    
    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.delete_encrypted_model(model_id)
        
        console.print(f"[green]✓[/green] Deleted encrypted model: {model_id}")
        
        # Show peer response if available
        if 'embedded_server_response_code' in result:
            code = result['embedded_server_response_code']
            if code == -255:
                console.print("[dim]Note: Embedded server not connected (deleted locally only)[/dim]")
            else:
                console.print(f"[dim]Embedded server response code: {code}[/dim]")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ============================================================================
# MODEL CHAT TEMPLATE COMMANDS
# ============================================================================

@model.group(name='chat-template')
def chat_template():
    """Chat template management commands."""
    pass


@chat_template.command(name='set')
@click.argument('model_id')
@click.argument('template_file', type=click.Path())
@click.option('--local', is_flag=True, help='Upload from local filesystem (default: from SFTP upload directory)')
@pass_context
def set_chat_template_cmd(ctx: Context, model_id: str, template_file: str, local: bool):
    """
    Set chat template for an encrypted model.
    
    MODEL_ID: The encrypted model ID
    TEMPLATE_FILE: Path to the Jinja2 template file
    
    By default, uploads from SFTP upload directory. Use --local to upload from local filesystem.
    
    Example:
        # Upload from SFTP upload directory
        fhenomai model chat-template set a180f65d12aa4761a6eb81993c04b890 my_template.jinja
        
        # Upload from local file
        fhenomai model chat-template set a180f65d12aa4761a6eb81993c04b890 ./my_template.jinja --local
    """
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        import os
        from pathlib import Path
        import tempfile
        import shutil
        
        client = FHEnomClient(ctx.config, auto_connect_sftp=True)
        temp_dir = None
        
        if local:
            # Local file
            template_path = Path(template_file)
            if not template_path.exists():
                console.print(f"[red]Error:[/red] File not found: {template_file}")
                sys.exit(1)
            
            if not template_path.is_file():
                console.print(f"[red]Error:[/red] Path is not a file: {template_file}")
                sys.exit(1)
            
            source_file = template_path
            console.print(f"[cyan]Uploading chat template from local file: {template_file}[/cyan]")
        else:
            # SFTP mode - download from SFTP upload directory
            console.print(f"[cyan]Downloading template from SFTP upload directory...[/cyan]")
            
            # Create temp directory for download
            temp_dir = tempfile.mkdtemp()
            temp_download = Path(temp_dir) / Path(template_file).name
            
            try:
                # Download from SFTP upload directory
                remote_path = f"upload/{template_file}" if not template_file.startswith('upload/') else template_file
                client.sftp.get(remote_path, str(temp_download))
                source_file = temp_download
                console.print(f"[green]✓[/green] Downloaded from SFTP")
            except Exception as e:
                console.print(f"[red]Error:[/red] Failed to download from SFTP: {e}")
                if temp_dir:
                    shutil.rmtree(temp_dir)
                sys.exit(1)
        
        # Check if we need to rename to chat_template.jinja
        if source_file.name != 'chat_template.jinja':
            console.print(f"[yellow]Info:[/yellow] Creating temporary copy as 'chat_template.jinja'")
            if temp_dir is None:
                temp_dir = tempfile.mkdtemp()
            temp_template = Path(temp_dir) / 'chat_template.jinja'
            shutil.copy2(source_file, temp_template)
            template_to_upload = str(temp_template)
        else:
            template_to_upload = str(source_file)
        
        try:
            # Upload to API
            result = client.admin.set_chat_template(model_id, template_to_upload)
            
            console.print(f"[green]✓[/green] Chat template set successfully for model: {model_id}")
            if 'response' in result:
                console.print(f"[dim]Server response: {result['response']}[/dim]")
        
        finally:
            # Cleanup temporary files
            if temp_dir:
                try:
                    shutil.rmtree(temp_dir)
                except:
                    pass
    
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    finally:
        # Disconnect SFTP
        try:
            client.sftp.disconnect()
        except:
            pass


# ============================================================================
# SERVE COMMANDS  
# ============================================================================

@cli.group()
def serve():
    """Model serving commands."""
    pass


@serve.command()
@click.argument('encrypted_model_id')
@click.option('--server-url', required=True, help='vLLM/TGI server URL')
@click.option('--api-key', help='Optional API key')
@click.option('--display-model-name', help='Display model name for vLLM --served-model-name')
@pass_context
def start(ctx: Context, encrypted_model_id: str, server_url: str,
          api_key: Optional[str], display_model_name: Optional[str]):
    """Start serving an encrypted model."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        
        console.print(f"Starting serving for [cyan]{encrypted_model_id}[/cyan]...")
        
        response = client.admin.start_serving(
            encrypted_model_id=encrypted_model_id,
            server_url=server_url,
            api_key=api_key,
            display_model_name=display_model_name
        )
        
        response_msg = response.get('response', '')
        if 'error' in response_msg.lower():
            console.print(f"[red]✗[/red] {response_msg}")
            sys.exit(1)
        else:
            console.print(f"[green]✓[/green] {response_msg or 'Serving started'}")
            console.print(f"\n[dim]Note: Startup takes 1-2 minutes for TEE initialization[/dim]")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@serve.command()
@click.argument('encrypted_model_id')
@pass_context
def stop(ctx: Context, encrypted_model_id: str):
    """Stop serving a model."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        
        console.print(f"Stopping serving for [cyan]{encrypted_model_id}[/cyan]...")
        
        response = client.admin.stop_serving(encrypted_model_id)
        
        console.print(f"[green]✓[/green] {response.get('response', 'Serving stopped')}")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@serve.command()
@pass_context
def list(ctx: Context):
    """List currently served models."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        
        models = client.list_online_models()
        
        if not models:
            console.print("[yellow]No models currently served[/yellow]")
            return
        
        table = Table(title=f"Online Models ({len(models)})")
        table.add_column("Model ID", style="cyan")
        table.add_column("Status", style="green")
        
        for model in models:
            table.add_row(model.get('name', 'unknown'), model.get('status', 'online'))
        
        console.print(table)
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ============================================================================
# JOB COMMANDS
# ============================================================================

@cli.group()
def job():
    """Job management commands."""
    pass


@job.command()
@click.argument('job_id')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table')
@pass_context
def status(ctx: Context, job_id: str, output_format: str):
    """Check job status."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        
        status = client.get_job_status(job_id)
        
        if output_format == 'json':
            print(json.dumps(status, indent=2))
        else:
            console.print(f"\n[bold]Job:[/bold] {job_id}\n")
            
            table = Table(show_header=False, box=None)
            table.add_column("Key", style="cyan")
            table.add_column("Value")
            
            table.add_row("Status", status.get('status', 'unknown'))
            table.add_row("Progress", f"{status.get('progress', 0) * 100:.1f}%")
            table.add_row("Message", status.get('message', ''))
            
            if status.get('error'):
                table.add_row("Error", f"[red]{status['error']}[/red]")
            
            console.print(table)
            console.print()
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@job.command()
@click.argument('job_id')
@click.option('--timeout', type=int, default=3600, help='Timeout in seconds')
@pass_context
def wait(ctx: Context, job_id: str, timeout: int):
    """Wait for job completion."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        
        console.print(f"Waiting for job [cyan]{job_id}[/cyan]...")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Processing...", total=None)
            
            def callback(status):
                progress_pct = status.get('progress', 0) * 100
                message = status.get('message', '')
                progress.update(task, description=f"{message} ({progress_pct:.1f}%)")
            
            result = client.wait_for_job(job_id, timeout=timeout, callback=callback)

        console.print(f"[green]✓[/green] Job completed")

    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


_JOB_STATUS_CHOICES = ['pending', 'running', 'done', 'error', 'cancelled', 'running_async']


@job.command(name='list')
@click.option('--status', 'status_filter', type=click.Choice(_JOB_STATUS_CHOICES),
              help='Filter jobs client-side by status')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table')
@pass_context
def list_jobs_cmd(ctx: Context, status_filter: Optional[str], output_format: str):
    """List all jobs known to the server."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    try:
        client = FHEnomClient(ctx.config)
        jobs = client.list_jobs()

        if status_filter:
            jobs = [j for j in jobs if j.get('status') == status_filter]

        if output_format == 'json':
            print(json.dumps(jobs, indent=2))
            return

        if not jobs:
            console.print("[yellow]No jobs found[/yellow]")
            return

        table = Table(title=f"Jobs ({len(jobs)})")
        table.add_column("Job ID", style="cyan", no_wrap=True)
        table.add_column("Status", style="green")
        table.add_column("Progress")
        table.add_column("Message", overflow="fold")

        for j in jobs:
            status_val = j.get('status', 'unknown')
            status_style = {
                'done': 'green',
                'error': 'red',
                'cancelled': 'yellow',
                'running': 'cyan',
                'running_async': 'cyan',
                'pending': 'dim',
            }.get(status_val, 'white')
            progress_pct = (j.get('progress') or 0) * 100
            message = j.get('message') or ''
            if len(message) > 80:
                message = message[:77] + '...'
            table.add_row(
                j.get('job_id', ''),
                f"[{status_style}]{status_val}[/{status_style}]",
                f"{progress_pct:.1f}%",
                message,
            )

        console.print(table)
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@job.command(name='cancel')
@click.argument('job_id')
@click.option('--timeout', type=float, default=30.0,
              help='Seconds the server waits for cancellation. Validated by '
                   'the SDK after command dispatch (not at parse time); '
                   'invalid values (<=0) are reported as a ValidationError.')
@pass_context
def cancel_job_cmd(ctx: Context, job_id: str, timeout: float):
    """Cancel a running job."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    try:
        client = FHEnomClient(ctx.config)
        result = client.cancel_job(job_id, timeout=timeout)
        status_val = result.get('status', 'unknown')
        colour = {
            'successfully_cancelled': 'green',
            'timeout_may_have_been_cancelled': 'yellow',
            'job_not_found': 'red',
            'could_not_cancel': 'red',
        }.get(status_val, 'white')
        console.print(f"[{colour}]{status_val}[/{colour}]")
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ============================================================================
# ADMIN COMMANDS (Advanced Features)
# ============================================================================

@cli.group()
def admin():
    """Advanced administration commands."""
    pass


@admin.group()
def sync():
    """Peer-to-peer synchronization commands."""
    pass


@sync.command()
@click.argument('peer_url')
@click.option('--peer-port', type=int, default=9099, help='Peer admin port (default: 9099)')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table', help='Output format')
@pass_context
def start(ctx: Context, peer_url: str, peer_port: int, output_format: str):
    """
    Start peer-to-peer synchronization with another instance.
    
    Initiates synchronization with a peer FHEnom AI instance, performing mutual
    authentication and exchanging encrypted model inventories.
    
    Prerequisites:
    
        - Both instances must have compatible certificates (same root CA and client_id)
        
        - Bidirectional network connectivity on admin port
        
        - Both instances must be properly provisioned
    
    Examples:
    
        # Synchronize with peer at IP address
        
        fhenomai admin sync start http://192.168.1.100
        
        # Synchronize with peer at custom port
        
        fhenomai admin sync start http://peer.example.com --peer-port 9099
        
        # Get JSON output
        
        fhenomai admin sync start http://192.168.1.100 --format json
    """
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        
        console.print(f"Initiating synchronization with [cyan]{peer_url}:{peer_port}[/cyan]...")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Synchronizing...", total=None)
            
            result = client.admin.sync.start(
                peer_url=peer_url,
                peer_port=peer_port
            )
        
        if output_format == 'json':
            print(json.dumps(result, indent=2))
        else:
            console.print(f"\n[green]✓[/green] Synchronization completed successfully\n")
            
            table = Table(show_header=False, box=None)
            table.add_column("Key", style="cyan")
            table.add_column("Value")
            
            table.add_row("Job ID", result.get('job_id', 'N/A'))
            table.add_row("Status", result.get('status', 'unknown'))
            table.add_row("Peer Identity", result.get('peer_identity', 'N/A'))
            
            if result.get('models_synced') is not None:
                table.add_row("Models Synced", str(result['models_synced']))
            
            if result.get('message'):
                table.add_row("Message", result['message'])
            
            console.print(table)
            console.print()
            
            console.print("[dim]Note: Peers are now neighbors and will automatically notify each other of new models.[/dim]")

    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@sync.group(name='peers')
def sync_peers():
    """Inspect and manage P2P peers."""
    pass


@sync_peers.command(name='list')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table')
@pass_context
def sync_peers_list(ctx: Context, output_format: str):
    """List the current peer-to-peer network topology."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    try:
        client = FHEnomClient(ctx.config)
        nodes = client.admin.sync.list_peers()

        if output_format == 'json':
            print(json.dumps({'nodes': nodes}, indent=2))
            return

        if not nodes:
            console.print("[yellow]No peers known[/yellow]")
            return

        table = Table(title=f"Peers ({len(nodes)})")
        table.add_column("peer_id", style="cyan", no_wrap=True)
        table.add_column("status", style="green")
        table.add_column("address")
        table.add_column("direct")
        table.add_column("seq#")
        table.add_column("neighbors")
        table.add_column("last_seen")

        for n in nodes:
            peer_id = n.get('peer_id') or '-'
            status_val = n.get('status') or '-'
            ip = n.get('ip') or '-'
            port = n.get('port')
            addr = f"{ip}:{port}" if port is not None else ip
            direct = 'yes' if n.get('direct') else 'no'
            seq = str(n.get('sequence_number', ''))
            neighbors = str(len(n.get('neighbors') or []))
            last_seen = str(n.get('last_seen') or '-')
            status_style = {
                'alive': 'green',
                'expired': 'red',
            }.get(status_val, 'white')
            table.add_row(
                peer_id,
                f"[{status_style}]{status_val}[/{status_style}]",
                addr,
                direct,
                seq,
                neighbors,
                last_seen,
            )

        console.print(table)
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@sync_peers.command(name='forget')
@click.argument('peer_id')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@pass_context
def sync_peers_forget(ctx: Context, peer_id: str, force: bool):
    """Drop a direct peer from this node's topology."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    if not force and not Confirm.ask(f"Forget peer [cyan]{peer_id}[/cyan]?", default=False):
        console.print("[yellow]Aborted.[/yellow]")
        return

    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.sync.forget_peer(peer_id)
        console.print(f"[green]✓[/green] {result.get('response', 'forgotten')}")
    except FHEnomError as e:
        from .exceptions import APIError
        if isinstance(e, APIError) and e.status_code == 404:
            console.print("[red]Peer not found.[/red]")
        else:
            console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@sync.command()
@click.argument('sequence_number', type=int)
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@pass_context
def revoke(ctx: Context, sequence_number: int, force: bool):
    """Revoke a sync sequence number and propagate to all known peers."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    if not force and not Confirm.ask(
        f"Revoke sequence number [cyan]{sequence_number}[/cyan]? This will be gossiped to all peers.",
        default=False
    ):
        console.print("[yellow]Aborted.[/yellow]")
        return

    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.sync.revoke_sequence_number(sequence_number)
        console.print(f"[green]✓[/green] {result.get('response', 'revoked')}")
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@admin.command()
@click.option('--output', '-o', type=click.Path(), help='Save attestation report to file')
@click.option('--nonce', help='Custom nonce (128 hex characters). Auto-generated if not provided.')
@click.option('--show-nonce', is_flag=True, help='Display the nonce used')
@click.option('--format', '-f', type=click.Choice(['standard', 'detailed']), default='standard',
              help='Output format (standard=parsed fields, detailed=colored hex dump)')
@pass_context
def attestation(ctx: Context, output: Optional[str], nonce: Optional[str], show_nonce: bool, format: str):
    """
    Request TEE attestation report for verification.
    
    This command generates a TEE attestation report that can be verified to confirm
    the service is running in a genuine Trusted Execution Environment (TEE).
    
    The attestation process:
    
        1. Generate or use provided cryptographic nonce (64 bytes)
        
        2. Request attestation report from TEE with the nonce
        
        3. TEE generates signed report including the nonce
        
        4. Report can be verified using TEE verification libraries
    
    Examples:
    
        # Generate attestation with auto-generated nonce
        
        fhenomai admin attestation --output report.bin
        
        # Use custom nonce and display it
        
        fhenomai admin attestation --nonce "a1b2c3..." --show-nonce
        
        # Save report and show nonce for verification
        
        fhenomai admin attestation -o report.bin --show-nonce
    
    Note:
        Requires TEE hardware (AMD SEV, Intel TDX, etc.) to be available.
        Without TEE, this command will fail with a "TEE not available" error.
    """
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        from .utils import generate_nonce, format_nonce_hex
        
        client = FHEnomClient(ctx.config)
        
        # Generate or validate nonce
        if nonce:
            # Validate custom nonce
            if len(nonce) != 128:
                console.print(f"[red]Error:[/red] Nonce must be exactly 128 hex characters (64 bytes), got {len(nonce)}")
                sys.exit(1)
            try:
                bytes.fromhex(nonce)
            except ValueError:
                console.print("[red]Error:[/red] Nonce must be valid hexadecimal")
                sys.exit(1)
            nonce_hex = nonce
        else:
            # Generate random nonce
            nonce_bytes = generate_nonce(64)
            nonce_hex = format_nonce_hex(nonce_bytes)
        
        if show_nonce:
            console.print(f"\n[cyan]Nonce:[/cyan] {nonce_hex}\n")
        
        console.print("Requesting TEE attestation report...")
        
        report_bytes = client.admin.attestation(nonce_hex)
        
        console.print(f"[green]✓[/green] Received attestation report ({len(report_bytes)} bytes)")
        
        # Always save .bin file and nonce if output is specified
        bin_output = None
        if output:
            ext = Path(output).suffix.lower()
            if ext in ['.html', '.pdf', '.txt']:
                # Infer format from extension and save .bin alongside
                bin_output = str(Path(output).with_suffix('.bin'))
            else:
                # Assume it's the bin file
                bin_output = output
            
            with open(bin_output, 'wb') as f:
                f.write(report_bytes)
            
            # Save nonce alongside
            nonce_file = str(Path(bin_output).with_suffix('.nonce'))
            with open(nonce_file, 'w') as f:
                f.write(nonce_hex)
            
            console.print(f"[green]✓[/green] Report saved to: [cyan]{bin_output}[/cyan]")
            console.print(f"[green]✓[/green] Nonce saved to: [cyan]{nonce_file}[/cyan]")
        
        # Format output based on --format flag
        from fhenomai.attestation_formatter import AttestationReportFormatter
        formatter = AttestationReportFormatter()
        
        if format == 'detailed':
            formatted = formatter.format_detailed(report_bytes, bytes.fromhex(nonce_hex))
            # Use print() directly to preserve ANSI color codes
            print(formatted)
        else:
            # Standard format (parsed fields)
            formatted = formatter.format_standard(report_bytes)
            print(formatted)
        
        # If output specified with recognized extension, save formatted version
        if output:
            ext = Path(output).suffix.lower()
            if ext == '.html':
                html = formatter.format_html(report_bytes, bytes.fromhex(nonce_hex))
                Path(output).write_text(html)
                console.print(f"[green]✓[/green] HTML report saved to: [cyan]{output}[/cyan]")
            elif ext == '.pdf':
                try:
                    formatter.format_pdf(report_bytes, bytes.fromhex(nonce_hex), output_path=output)
                    console.print(f"[green]✓[/green] PDF report saved to: [cyan]{output}[/cyan]")
                except ImportError as e:
                    console.print(f"[red]Error:[/red] PDF generation requires reportlab")
                    console.print(f"[dim]Details: {e}[/dim]")
                    console.print("\nInstall PDF dependency:")
                    console.print("  [cyan]pip install reportlab[/cyan]")
                    sys.exit(1)
            elif ext == '.txt':
                # Save formatted text
                if format == 'detailed':
                    formatted_text = formatter.format_detailed(report_bytes, bytes.fromhex(nonce_hex))
                else:
                    formatted_text = formatter.format_standard(report_bytes)
                # Remove ANSI codes for text file
                import re
                clean_text = re.sub(r'\x1b\[[0-9;]*m', '', formatted_text)
                Path(output).write_text(clean_text)
                console.print(f"[green]✓[/green] Text report saved to: [cyan]{output}[/cyan]")
            elif ext not in ['', '.bin']:
                console.print(f"[yellow]Warning:[/yellow] Unsupported format '{ext}'. Supported: .html, .pdf, .txt, .bin")
        
        # If output specified with recognized extension, save formatted version
        if output:
            ext = Path(output).suffix.lower()
            if ext == '.html':
                html = formatter.format_html(report_bytes, bytes.fromhex(nonce_hex))
                Path(output).write_text(html)
                console.print(f"[green]✓[/green] HTML report saved to: [cyan]{output}[/cyan]")
            elif ext == '.pdf':
                formatter.format_pdf(report_bytes, bytes.fromhex(nonce_hex), output_path=output)
                console.print(f"[green]✓[/green] PDF report saved to: [cyan]{output}[/cyan]")
            elif ext == '.txt':
                # Save formatted text
                if format == 'detailed':
                    formatted_text = formatter.format_detailed(report_bytes, bytes.fromhex(nonce_hex))
                else:
                    formatted_text = formatter.format_standard(report_bytes)
                # Remove ANSI codes for text file
                import re
                clean_text = re.sub(r'\x1b\[[0-9;]*m', '', formatted_text)
                Path(output).write_text(clean_text)
                console.print(f"[green]✓[/green] Text report saved to: [cyan]{output}[/cyan]")
            elif ext not in ['', '.bin']:
                console.print(f"[yellow]Warning:[/yellow] Unsupported format '{ext}'. Supported: .html, .pdf, .txt, .bin")
        
        console.print("\n[bold]Next Steps:[/bold]")
        console.print("  1. Verify the report using 'fhenomai admin verify-attestation'")
        console.print("  2. Confirm the nonce matches your request")
        console.print()
        
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@admin.command(name='verify-attestation')
@click.option('--report', '-r', type=click.Path(exists=True), required=True, help='Path to attestation report file')
@click.option('--nonce', required=False, help='Expected nonce (128 hex characters). Reads from .nonce file if not provided.')
@click.option('--platform', type=click.Choice(['amd_sev_snp', 'intel_tdx']), default='amd_sev_snp', help='TEE platform type')
@click.option('--json-output', '-j', is_flag=True, help='Output as JSON')
@click.option('--format', '-f', type=click.Choice(['standard', 'detailed']), default='standard',
              help='Output format (standard=parsed fields, detailed=colored hex dump)')
@click.option('--output', '-o', type=click.Path(), help='Save formatted output')
@pass_context
def verify_attestation(ctx: Context, report: str, nonce: Optional[str], platform: str, json_output: bool, format: str, output: Optional[str]):
    """
    Verify a TEE attestation report.
    
    This command verifies the cryptographic authenticity of a TEE attestation report,
    ensuring it was generated by genuine TEE hardware and is bound to the expected nonce.
    
    Verification process:
    
        1. Parse the attestation report structure
        
        2. Verify the report signature using TEE platform certificates
        
        3. Validate the certificate chain (AMD KDS for SEV-SNP)
        
        4. Confirm the nonce is correctly bound to the report
    
    Examples:
    
        # Verify an AMD SEV-SNP attestation report
        
        fhenomai admin verify-attestation --report report.bin --nonce "a1b2c3..."
        
        # Verify with JSON output
        
        fhenomai admin verify-attestation -r report.bin --nonce "a1b2..." -j
        
        # Verify Intel TDX report
        
        fhenomai admin verify-attestation -r report.bin --nonce "a1b2..." --platform intel_tdx
    
    Requirements:
        Attestation support is included with fhenomai installation.
    """
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        # Read the report file
        with open(report, 'rb') as f:
            report_bytes = f.read()
        
        if not report_bytes:
            console.print(f"[red]Error:[/red] Report file is empty: {report}")
            sys.exit(1)
        
        # Try to read nonce from .nonce file if not provided
        if not nonce:
            nonce_file = str(Path(report).with_suffix('.nonce'))
            if Path(nonce_file).exists():
                with open(nonce_file, 'r') as f:
                    nonce = f.read().strip()
                console.print(f"[dim]Loaded nonce from: {nonce_file}[/dim]")
            else:
                console.print(f"[red]Error:[/red] Nonce not provided and {nonce_file} not found")
                sys.exit(1)
        
        # Validate nonce
        if len(nonce) != 128:
            console.print(f"[red]Error:[/red] Nonce must be exactly 128 hex characters (64 bytes), got {len(nonce)}")
            sys.exit(1)
        
        try:
            bytes.fromhex(nonce)
        except ValueError:
            console.print("[red]Error:[/red] Nonce must be valid hexadecimal")
            sys.exit(1)
        
        client = FHEnomClient(ctx.config)
        
        console.print(f"\n[bold]Verifying Attestation Report[/bold]\n")
        console.print(f"Report file: [cyan]{report}[/cyan]")
        console.print(f"Report size: {len(report_bytes)} bytes")
        console.print(f"Platform: [cyan]{platform}[/cyan]")
        console.print(f"Nonce: [cyan]{nonce[:32]}...[/cyan]\n")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Verifying...", total=None)
            result = client.admin.verify_attestation(report_bytes, nonce, platform)
        
        if json_output:
            print(json.dumps(result, indent=2))
            sys.exit(0 if result['verified'] else 1)
        
        # Format output
        from fhenomai.attestation_formatter import AttestationReportFormatter
        formatter = AttestationReportFormatter()
        
        if format == 'detailed':
            formatted = formatter.format_detailed(report_bytes, bytes.fromhex(nonce), verification_result=result)
            # Use print() directly to preserve ANSI color codes
            print(formatted)
        else:
            # Standard format (parsed fields)
            formatted = formatter.format_standard(report_bytes, verification_result=result)
            print(formatted)
        
        # If output specified, save formatted version based on extension
        if output:
            ext = Path(output).suffix.lower()
            if ext == '.html':
                html = formatter.format_html(report_bytes, bytes.fromhex(nonce), verification_result=result)
                Path(output).write_text(html)
                console.print(f"[green]✓[/green] HTML verification report saved to: [cyan]{output}[/cyan]")
            elif ext == '.pdf':
                try:
                    formatter.format_pdf(report_bytes, bytes.fromhex(nonce), verification_result=result, output_path=output)
                    console.print(f"[green]✓[/green] PDF verification report saved to: [cyan]{output}[/cyan]")
                except ImportError as e:
                    console.print(f"[red]Error:[/red] PDF generation requires reportlab")
                    console.print(f"[dim]Details: {e}[/dim]")
                    console.print("\nInstall PDF dependency:")
                    console.print("  [cyan]pip install reportlab[/cyan]")
                    sys.exit(1)
            elif ext == '.txt':
                # Save formatted text
                if format == 'detailed':
                    formatted_text = formatter.format_detailed(report_bytes, bytes.fromhex(nonce), verification_result=result)
                else:
                    formatted_text = formatter.format_standard(report_bytes, verification_result=result)
                # Remove ANSI codes for text file
                import re
                clean_text = re.sub(r'\x1b\[[0-9;]*m', '', formatted_text)
                Path(output).write_text(clean_text)
                console.print(f"[green]✓[/green] Text verification report saved to: [cyan]{output}[/cyan]")
            else:
                console.print(f"[yellow]Warning:[/yellow] Unsupported format '{ext}'. Supported: .html, .pdf, .txt")
        
        # If output specified, save formatted version based on extension
        if output:
            ext = Path(output).suffix.lower()
            if ext == '.html':
                html = formatter.format_html(report_bytes, bytes.fromhex(nonce), verification_result=result)
                Path(output).write_text(html)
                console.print(f"[green]✓[/green] HTML verification report saved to: [cyan]{output}[/cyan]")
            elif ext == '.pdf':
                formatter.format_pdf(report_bytes, bytes.fromhex(nonce), verification_result=result, output_path=output)
                console.print(f"[green]✓[/green] PDF verification report saved to: [cyan]{output}[/cyan]")
            elif ext == '.txt':
                # Save formatted text
                if format == 'detailed':
                    formatted_text = formatter.format_detailed(report_bytes, bytes.fromhex(nonce), verification_result=result)
                else:
                    formatted_text = formatter.format_standard(report_bytes, verification_result=result)
                # Remove ANSI codes for text file
                import re
                clean_text = re.sub(r'\x1b\[[0-9;]*m', '', formatted_text)
                Path(output).write_text(clean_text)
                console.print(f"[green]✓[/green] Text verification report saved to: [cyan]{output}[/cyan]")
            else:
                console.print(f"[yellow]Warning:[/yellow] Unsupported format '{ext}'. Supported: .html, .pdf, .txt")
        
        # Exit with appropriate code
        sys.exit(0 if result.get('verified') else 1)
        
    except ImportError as e:
        console.print(f"\n[red]Error:[/red] Attestation library not installed")
        console.print("\nTo use attestation verification, reinstall fhenomai:")
        console.print("  [cyan]pip install --upgrade fhenomai[/cyan]\n")
        console.print("Or install standalone:")
        console.print("  [cyan]pip install dk-tee-attestation[/cyan]\n")
        sys.exit(1)
    except FileNotFoundError:
        console.print(f"[red]Error:[/red] Report file not found: {report}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        if ctx.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


# ---------------------------------------------------------------------------
# Admin: node lifecycle
# ---------------------------------------------------------------------------

@admin.command(name='reload')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@pass_context
def admin_reload(ctx: Context, force: bool):
    """Request a TEE node restart."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    if not force and not Confirm.ask("Reload the TEE node?", default=False):
        console.print("[yellow]Aborted.[/yellow]")
        return

    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.self_reboot()
        console.print(f"[green]✓[/green] {result.get('response', 'reloading')}")
    except FHEnomError as e:
        from .exceptions import APIError
        if isinstance(e, APIError) and e.status_code == 409:
            console.print("[red]Cannot reload: active jobs/models present. "
                          "Drain them first and retry.[/red]")
        else:
            console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@admin.command(name='deprovision')
@click.option('--force', is_flag=True, help='Required to acknowledge destructiveness')
@click.option('--yes-i-understand', 'understand', is_flag=True,
              help='Required second confirmation flag')
@pass_context
def admin_deprovision(ctx: Context, force: bool, understand: bool):
    """Factory-reset this TEE node. Destructive and non-recoverable."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    if not (force and understand):
        console.print(
            "[red]Refusing to deprovision without both --force "
            "and --yes-i-understand. This operation is destructive "
            "and non-recoverable.[/red]"
        )
        sys.exit(2)

    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.deprovision()
        console.print(f"[green]✓[/green] {result.get('response', 'deprovisioned')}")
    except FHEnomError as e:
        from .exceptions import APIError
        if isinstance(e, APIError) and e.status_code == 409:
            console.print("[red]Cannot deprovision: active jobs/models present. "
                          "Drain them first and retry.[/red]")
        else:
            console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@admin.command(name='license')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json']), default='table')
@pass_context
def admin_license(ctx: Context, output_format: str):
    """Show the node's license information."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    try:
        client = FHEnomClient(ctx.config)
        info = client.admin.get_license_info()

        if output_format == 'json':
            print(json.dumps(info, indent=2))
            return

        table = Table(show_header=False, box=None)
        table.add_column("Key", style="cyan")
        table.add_column("Value")
        for key in ('client_id', 'status', 'expiration', 'sequence_number',
                    'locally_encrypted_models', 'available_to_encrypt',
                    'license_error'):
            if key in info and info[key] is not None:
                table.add_row(key, str(info[key]))
        console.print(table)
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Admin: logs
# ---------------------------------------------------------------------------

def _format_log_entry_line(entry: dict) -> str:
    ts = entry.get('timestamp') or ''
    severity = entry.get('severity') or ''
    body = entry.get('body') or ''
    attrs = entry.get('attributes') or {}
    service = attrs.get('service') or attrs.get('service.name') or ''
    prefix = f"{ts} [{severity}]"
    if service:
        prefix += f" {service}"
    return f"{prefix}  {body}"


@admin.command(name='logs')
@click.option('--service', help='Filter by service name')
@click.option('--since', help='Lower-bound timestamp (server-accepted format)')
@click.option('--until', help='Upper-bound timestamp')
@click.option('--level', help='Severity filter (e.g. ERROR)')
@click.option('--contains', help='Substring match on log body')
@click.option('--trace-id', 'trace_id', help='Filter entries by trace ID')
@click.option('--limit', type=click.IntRange(1, 2000), default=200,
              help='Page size (1-2000, default 200). SDK enforces the bound.')
@click.option('--cursor', help='Resume from an opaque server-supplied cursor')
@click.option('--follow/--no-follow', default=False,
              help='Keep polling for new entries. Single cursor, no retries; '
                   'on exit, the last observed cursor is printed as a resume hint.')
@click.option('--interval', type=click.FloatRange(1.0, 60.0), default=5.0,
              help='Seconds between --follow polls (min 1.0).')
@click.option('--format', 'output_format', type=click.Choice(['table', 'json', 'raw']),
              default='table')
@pass_context
def admin_logs(ctx: Context, service: Optional[str], since: Optional[str],
               until: Optional[str], level: Optional[str], contains: Optional[str],
               trace_id: Optional[str], limit: int, cursor: Optional[str],
               follow: bool, interval: float, output_format: str):
    """Query node logs. With --follow, poll continuously."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    filters = dict(service=service, since=since, until=until,
                   level=level, contains=contains, trace_id=trace_id)
    console_err = Console(stderr=True)

    def render_page(entries):
        if output_format == 'json':
            for e in entries:
                print(json.dumps(e))
        elif output_format == 'raw':
            for e in entries:
                print(e.get('body', ''))
        else:
            for e in entries:
                console.print(_format_log_entry_line(e))

    from .exceptions import APIError
    try:
        client = FHEnomClient(ctx.config)

        if not follow:
            # Walk all pages for the current filter set, then exit.
            entries_iter = client.admin.stream_logs(
                page_size=limit, start_cursor=cursor, **filters)
            if output_format == 'table':
                for entry in entries_iter:
                    console.print(_format_log_entry_line(entry))
            else:
                render_page(list(entries_iter))
            return

        # Follow mode — minimal display loop with explicit cursor.
        import time
        last_seen_cursor = cursor
        try:
            while True:
                resp = client.admin.get_logs(limit=limit, cursor=cursor, **filters)
                entries = resp.get('entries') or []
                render_page(entries)
                nxt = resp.get('next_cursor') or ''
                if nxt:
                    cursor = nxt
                    last_seen_cursor = nxt
                time.sleep(max(interval, 1.0))
        except KeyboardInterrupt:
            if last_seen_cursor:
                console_err.print(
                    f"[dim]Last cursor: {last_seen_cursor} — "
                    f"resume with: --follow --cursor {last_seen_cursor}[/dim]"
                )
            sys.exit(0)
    except APIError as e:
        console_err.print(f"[red]Error:[/red] {e}")
        if follow and 'last_seen_cursor' in locals() and last_seen_cursor:
            console_err.print(
                f"[dim]Last cursor: {last_seen_cursor} — "
                f"resume with: --follow --cursor {last_seen_cursor}[/dim]"
            )
        sys.exit(1)
    except FHEnomError as e:
        console_err.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Admin: token rotation
# ---------------------------------------------------------------------------

@admin.group(name='token')
def admin_token():
    """Admin token management."""
    pass


@admin_token.command(name='rotate')
@click.option('--current-rotation-token', prompt='Current rotation token',
              hide_input=True, help='Current rotation token')
@click.option('--new-auth-token', prompt='New auth token',
              hide_input=True, confirmation_prompt=True,
              help='New admin X-Auth-Token to install')
@click.option('--new-rotation-token', prompt='New rotation token',
              hide_input=True, confirmation_prompt=True,
              help='New rotation token for future rotations')
@pass_context
def admin_token_rotate(ctx: Context, current_rotation_token: str,
                       new_auth_token: str, new_rotation_token: str):
    """Rotate the node's admin and rotation tokens."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.rotate_token(
            current_rotation_token=current_rotation_token,
            new_authentication_token=new_auth_token,
            new_rotation_token=new_rotation_token,
        )
        console.print(f"[green]✓[/green] {result.get('response', 'rotated')}")
        console.print(
            "\n[bold yellow]Action required:[/bold yellow] update the "
            "[cyan]auth_token[/cyan] field in your config file "
            "([cyan]~/.fhenomai/config.yaml[/cyan] or your --config path) "
            "to the new auth token. The CLI does NOT auto-write config."
        )
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Admin: SSL
# ---------------------------------------------------------------------------

@admin.group(name='ssl')
def admin_ssl():
    """TLS certificate management."""
    pass


@admin_ssl.command(name='update')
@click.option('--cert', required=True,
              type=click.Path(exists=True, dir_okay=False, readable=True),
              help='Path to PEM certificate file')
@click.option('--key', required=True,
              type=click.Path(exists=True, dir_okay=False, readable=True),
              help='Path to PEM private key file')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@pass_context
def admin_ssl_update(ctx: Context, cert: str, key: str, force: bool):
    """Replace the node's TLS certificate and key (triggers restart)."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    if not force and not Confirm.ask(
            "Update TLS certificate and trigger a restart?", default=False):
        console.print("[yellow]Aborted.[/yellow]")
        return

    from .exceptions import APIError, ValidationError
    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.update_ssl_from_files(cert, key)
        console.print(f"[green]✓[/green] {result.get('response', 'updated')}")
    except ValidationError as e:
        console.print(f"[red]Invalid PEM file (local check):[/red] {e}")
        sys.exit(1)
    except APIError as e:
        if e.status_code == 400:
            console.print(f"[red]Server rejected certificate:[/red] {e}")
        elif e.status_code == 409:
            console.print("[red]Cannot update SSL: active jobs/models present. "
                          "Drain them first and retry.[/red]")
        else:
            console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Admin: Intel Trust Authority (ITA)
# ---------------------------------------------------------------------------

@admin.group(name='ita')
def admin_ita():
    """Intel Trust Authority integration."""
    pass


@admin_ita.command(name='token')
@click.option('--user-data', help='Optional user data to mix into the ITA quote')
@click.option('--output', '-o', type=click.Path(dir_okay=False, writable=True),
              help='Write token to this file')
@click.option('--show/--no-show', default=None,
              help='Print token to stdout (default if --output not given)')
@pass_context
def admin_ita_token(ctx: Context, user_data: Optional[str],
                    output: Optional[str], show: Optional[bool]):
    """Request an ITA attestation token from the node."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    # Default: print if no --output and --show not explicitly False.
    if show is None:
        show = output is None

    try:
        client = FHEnomClient(ctx.config)
        token = client.admin.get_ita_token(user_data=user_data)
        if output:
            Path(output).write_text(token)
            console.print(f"[green]✓[/green] Token written to {output}")
        if show:
            print(token)
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


@admin_ita.command(name='config')
@click.option('--url', 'ita_api_url', help='ITA API base URL')
@click.option('--key', 'ita_api_key', help='ITA API key')
@click.option('--policy-id', 'ita_api_policy_id', help='ITA policy ID')
@pass_context
def admin_ita_config(ctx: Context, ita_api_url: Optional[str],
                     ita_api_key: Optional[str],
                     ita_api_policy_id: Optional[str]):
    """Update the node's ITA configuration (partial update)."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)

    if ita_api_url is None and ita_api_key is None and ita_api_policy_id is None:
        console.print("[yellow]No config fields specified; nothing to do.[/yellow]")
        return

    try:
        client = FHEnomClient(ctx.config)
        result = client.admin.set_ita_config(
            ita_api_url=ita_api_url,
            ita_api_key=ita_api_key,
            ita_api_policy_id=ita_api_policy_id,
        )
        console.print(f"[green]✓[/green] {result.get('response', 'updated')}")
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)


# ============================================================================
# SFTP COMMANDS
# ============================================================================

@cli.group()
def sftp():
    """SFTP file transfer commands."""
    pass


@sftp.command()
@click.argument('local_path')
@click.argument('remote_path')
@click.option('--recursive', '-r', is_flag=True, help='Upload directory recursively')
@click.option('--show-progress/--no-progress', default=True, help='Show upload progress')
@pass_context
def upload(ctx: Context, local_path: str, remote_path: str, recursive: bool, show_progress: bool):
    """Upload a file or directory to the server."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        sftp_manager = client.get_sftp_manager()
        
        # Normalize path: add upload/ prefix if not present
        if not remote_path.startswith('upload/') and not remote_path.startswith('download/') and not remote_path.startswith('/'):
            remote_path = f"upload/{remote_path}"
        
        local = Path(local_path)
        
        if not local.exists():
            console.print(f"[red]Error:[/red] Local path does not exist: {local_path}")
            sys.exit(1)
        
        if local.is_dir():
            if not recursive:
                console.print("[red]Error:[/red] Use --recursive flag to upload directories")
                sys.exit(1)
            
            console.print(f"Uploading directory [cyan]{local_path}[/cyan] to [cyan]{remote_path}[/cyan]...")
            sftp_manager.upload_directory(str(local), remote_path)
            console.print(f"[green]✓[/green] Directory uploaded successfully")
        else:
            console.print(f"Uploading file [cyan]{local_path}[/cyan] to [cyan]{remote_path}[/cyan]...")
            sftp_manager.upload_file(str(local), remote_path)
            console.print(f"[green]✓[/green] File uploaded successfully")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    finally:
        try:
            sftp_manager.disconnect()
        except:
            pass


@sftp.command()
@click.argument('remote_path')
@click.argument('local_path')
@click.option('--recursive', '-r', is_flag=True, help='Download directory recursively')
@click.option('--show-progress/--no-progress', default=True, help='Show download progress')
@pass_context
def download(ctx: Context, remote_path: str, local_path: str, recursive: bool, show_progress: bool):
    """Download a file or directory from the server."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        sftp_manager = client.get_sftp_manager()
        
        # Normalize path: add download/ prefix if not present
        if not remote_path.startswith('upload/') and not remote_path.startswith('download/') and not remote_path.startswith('/'):
            remote_path = f"download/{remote_path}"
        
        console.print(f"Downloading [cyan]{remote_path}[/cyan] to [cyan]{local_path}[/cyan]...")
        
        if recursive:
            sftp_manager.download_directory(remote_path, local_path)
            console.print(f"[green]✓[/green] Directory downloaded successfully")
        else:
            sftp_manager.download_file(remote_path, local_path)
            console.print(f"[green]✓[/green] File downloaded successfully")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    finally:
        try:
            sftp_manager.disconnect()
        except:
            pass


@sftp.command()
@click.argument('remote_path', required=False, default='.')
@pass_context
def list(ctx: Context, remote_path: str):
    """List files in a remote directory."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        sftp_manager = client.get_sftp_manager()
        
        files = sftp_manager.list_files(remote_path)
        
        if not files:
            console.print(f"No files found in [cyan]{remote_path}[/cyan]")
            return
        
        table = Table(title=f"Files in {remote_path}")
        table.add_column("Name", style="cyan")
        table.add_column("Type")
        table.add_column("Size")
        
        for file_info in files:
            name = file_info.name
            is_dir = file_info.is_dir
            size = file_info.size
            
            file_type = "DIR" if is_dir else "FILE"
            size_str = "-" if is_dir else f"{size:,} bytes"
            
            table.add_row(name, file_type, size_str)
        
        console.print(table)
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    finally:
        try:
            sftp_manager.disconnect()
        except:
            pass


@sftp.command()
@click.argument('remote_path')
@click.option('--dry-run', is_flag=True, help='Show what would be deleted without actually deleting')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@pass_context
def clear(ctx: Context, remote_path: str, dry_run: bool, force: bool):
    """Clear all contents of a remote directory."""
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found")
        sys.exit(1)
    
    try:
        client = FHEnomClient(ctx.config)
        sftp_manager = client.get_sftp_manager()
        
        # First, list what will be deleted
        files = sftp_manager.list_files(remote_path)
        
        if not files:
            console.print(f"[yellow]Directory [cyan]{remote_path}[/cyan] is already empty[/yellow]")
            return
        
        # Show what will be deleted
        console.print(f"\n[yellow]Contents of [cyan]{remote_path}[/cyan]:[/yellow]")
        for file_info in files:
            file_type = "DIR" if file_info.is_dir else "FILE"
            console.print(f"  • {file_info.name} ({file_type})")
        
        # Confirm unless force or dry-run
        if not force and not dry_run:
            if not Confirm.ask(f"\n[red]Delete all contents of {remote_path}?[/red]", default=False):
                console.print("[yellow]Cancelled[/yellow]")
                return
        
        # Clear the directory
        files_deleted, dirs_deleted = sftp_manager.clear_directory(remote_path, dry_run=dry_run)
        
        # Count total items that were listed
        total_files = sum(1 for f in files if not f.is_dir)
        total_dirs = sum(1 for f in files if f.is_dir)
        
        if dry_run:
            console.print(f"\n[cyan]Would delete:[/cyan] {files_deleted} files, {dirs_deleted} directories")
        else:
            console.print(f"\n[green]✓ Deleted:[/green] {files_deleted} files, {dirs_deleted} directories")
            
            # Check if some items couldn't be deleted (permission issues)
            if files_deleted < total_files or dirs_deleted < total_dirs:
                failed_files = total_files - files_deleted
                failed_dirs = total_dirs - dirs_deleted
                if failed_files > 0 or failed_dirs > 0:
                    console.print(f"[yellow]⚠ Could not delete:[/yellow] {failed_files} files, {failed_dirs} directories (permission denied)")
                    console.print("[dim]Note: Encrypted files in download/ may have restricted permissions[/dim]")
    
    except FHEnomError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)
    finally:
        try:
            sftp_manager.disconnect()
        except:
            pass


# ─── Provision Command ─────────────────────────────────────────────────────

_PROVISION_REQUIRED = [("client_id", "--client-id"), ("num_encryptable", "--num-encryptable")]
_SSL_CERTS_PARAMS   = ["client_ssl_cert_hex", "client_ssl_key_hex"]
_OOB_LICENSE_PARAMS = ["root_cert_hex", "instance_cert_hex", "instance_key_hex"]


@cli.command("provision")
@click.option("--reuse-license", is_flag=True, default=False,
              help=(
                  "Reuse the internal license stored in p2p-auth (in the TEE). "
                  "Works only if the license is NOT expired. The node must be running "
                  "and in RUNNING_VALID state. Reuses the certificate from p2p-auth without "
                  "contacting the License Manager. Not applicable after 'admin deprovision'."
              ))
@click.option("--admin-host", default=None, envvar="FHENOM_ADMIN_HOST",
              help="TEE node host (default: from config).")
@click.option("--admin-port", default=None, type=int, envvar="FHENOM_ADMIN_PORT",
              help="TEE node admin port (default: from config, typically 9099).")
@click.option("--client-id", default=None,
              help="[client_config] Unique client identifier (UUID).")
@click.option("--client-secret", default=None,
              help=(
                  "[client_config] Optional client secret. When provided, the effective "
                  "client identity sent to the TEE and License Manager is "
                  "'{client_id}:{client_secret}'. Omit for legacy clients that have no secret."
              ))
@click.option("--num-encryptable", default=None, type=int,
              help="[client_config] Number of models the node is allowed to encrypt.")
@click.option("--admin-token", "admin_token_val", default=None,
              help="[client_config] Admin authentication token.")
@click.option("--rotation-token", default=None,
              help="[client_config] Token used for credential rotation.")
@click.option("--client-ssl-cert-hex", default=None,
              help="[ssl_certs] Client SSL certificate, hex-encoded PEM. Required together with --client-ssl-key-hex.")
@click.option("--client-ssl-key-hex", default=None,
              help="[ssl_certs] Client SSL private key, hex-encoded PEM. Required together with --client-ssl-cert-hex.")
@click.option("--root-cert-hex", default=None,
              help="[out_of_band_license] Root CA certificate, hex-encoded PEM.")
@click.option("--instance-cert-hex", default=None,
              help="[out_of_band_license] Instance certificate, hex-encoded PEM.")
@click.option("--instance-key-hex", default=None,
              help="[out_of_band_license] Instance private key, hex-encoded PEM.")
@pass_context
def provision(ctx: Context, reuse_license: bool, admin_host: Optional[str], admin_port: Optional[int],
              client_id: Optional[str], client_secret: Optional[str], num_encryptable: Optional[int],
              admin_token_val: Optional[str], rotation_token: Optional[str],
              client_ssl_cert_hex: Optional[str], client_ssl_key_hex: Optional[str],
              root_cert_hex: Optional[str], instance_cert_hex: Optional[str],
              instance_key_hex: Optional[str]):
    """Provision the TEE node and activate the license.

    Standard flow: sends a JSON payload to POST /provision on the TEE node.
    The node contacts the License Manager automatically unless out-of-band
    license flags are supplied.

    Reuse flow (--reuse-license): targets an already-running node with a valid
    (non-expired) license in p2p-auth. Reports the current license state.
    The internal license (certificate in p2p-auth) is reused without contacting
    the License Manager. Only works if the license is not expired.
    """
    if ctx.config is None:
        console.print("[red]Error:[/red] No configuration found. Run 'fhenomai config init' first.")
        sys.exit(1)

    host   = admin_host or ctx.config.admin_host
    port   = admin_port or ctx.config.admin_port
    scheme = "https" if ctx.config.use_ssl else "http"
    skip_ssl = ctx.config.skip_ssl_checks

    # ── Reuse-license flow ────────────────────────────────────────────────────
    if reuse_license:
        console.print("[yellow]Reusing license from p2p-auth...[/yellow]")

        url = f"{scheme}://{host}:{port}/provision"
        try:
            resp = requests.post(url, json={}, timeout=30, verify=not skip_ssl)
            resp.raise_for_status()
            console.print(Panel(
                f"[green]TEE node re-provisioned with internal license.[/green]\n"
                f"Response: {resp.json()}",
                title="License re-provisioning complete",
                border_style="green",
            ))
        except requests.exceptions.HTTPError as e:
            body: Any = ""
            try:
                body = e.response.json()
            except Exception:
                body = e.response.text
            console.print(f"[red]HTTP Error {e.response.status_code}:[/red] {body}")
            sys.exit(1)
        except requests.exceptions.ConnectionError:
            console.print(f"[red]Error:[/red] Could not connect to {url}")
            sys.exit(1)
        return

    # ── Standard provisioning flow ────────────────────────────────────────────
    local_vars = {
        "client_id": client_id, "num_encryptable": num_encryptable,
        "admin_token_val": admin_token_val, "rotation_token": rotation_token,
        "client_ssl_cert_hex": client_ssl_cert_hex, "client_ssl_key_hex": client_ssl_key_hex,
        "root_cert_hex": root_cert_hex, "instance_cert_hex": instance_cert_hex,
        "instance_key_hex": instance_key_hex,
    }

    missing = [flag for param, flag in _PROVISION_REQUIRED if local_vars[param] is None]
    if missing:
        console.print(
            "[red]Error:[/red] Missing required parameters:\n"
            + "\n".join(f"  • {f}" for f in missing)
            + "\n\nUse --reuse-license to renew an expired license without re-provisioning."
        )
        sys.exit(1)

    ssl_provided = [p for p in _SSL_CERTS_PARAMS if local_vars[p] is not None]
    if 0 < len(ssl_provided) < len(_SSL_CERTS_PARAMS):
        console.print(
            "[red]Error:[/red] --client-ssl-cert-hex and --client-ssl-key-hex "
            "must be provided together or not at all."
        )
        sys.exit(1)

    oob_provided = [p for p in _OOB_LICENSE_PARAMS if local_vars[p] is not None]
    if 0 < len(oob_provided) < len(_OOB_LICENSE_PARAMS):
        console.print(
            "[red]Error:[/red] --root-cert-hex, --instance-cert-hex, and "
            "--instance-key-hex must all be provided together or not at all."
        )
        sys.exit(1)

    effective_client_id = f"{client_id}:{client_secret}" if client_secret else client_id

    client_config_block: Dict[str, Any] = {
        "client_id": effective_client_id,
        "num_encryptable": num_encryptable,
    }
    if admin_token_val is not None:
        client_config_block["admin_token"] = admin_token_val
    if rotation_token is not None:
        client_config_block["rotation_token"] = rotation_token

    payload: Dict[str, Any] = {"client_config": client_config_block}
    if ssl_provided:
        payload["ssl_certs"] = {
            "client_ssl_cert_hex": client_ssl_cert_hex,
            "client_ssl_key_hex": client_ssl_key_hex,
        }
    if oob_provided:
        payload["out_of_band_license"] = {
            "root_cert_hex": root_cert_hex,
            "instance_cert_hex": instance_cert_hex,
            "instance_key_hex": instance_key_hex,
        }

    url = f"{scheme}://{host}:{port}/provision"
    try:
        resp = requests.post(url, json=payload, timeout=30, verify=not skip_ssl)
        resp.raise_for_status()
        console.print(Panel(
            f"[green]TEE node provisioned successfully.[/green]\nResponse: {resp.json()}",
            title="Provisioning complete",
            border_style="green",
        ))
    except requests.exceptions.HTTPError as e:
        body: Any = ""
        try:
            body = e.response.json()
        except Exception:
            body = e.response.text
        console.print(f"[red]HTTP Error {e.response.status_code}:[/red] {body}")
        sys.exit(1)
    except requests.exceptions.ConnectionError:
        console.print(f"[red]Error:[/red] Could not connect to {url}")
        sys.exit(1)


def main():
    """Entry point for CLI."""
    try:
        cli(obj=Context())
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"\n[red]Unexpected error:[/red] {e}")
        if logging.getLogger().level == logging.DEBUG:
            raise
        sys.exit(1)


if __name__ == '__main__':
    main()
