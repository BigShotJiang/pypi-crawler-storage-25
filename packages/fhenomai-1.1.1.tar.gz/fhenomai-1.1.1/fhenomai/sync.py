"""
Peer-to-peer synchronization manager for FHEnom AI.

Provides functionality for synchronizing encrypted models between peer instances
through certificate-based mutual authentication.
"""

import requests
import logging
from typing import Any, Dict, List, Optional
from urllib.parse import quote, urljoin
import warnings

from .exceptions import SyncError, ConnectionError, APIError

logger = logging.getLogger(__name__)


class SyncManager:
    """
    Manager for peer-to-peer synchronization operations.
    
    This class provides methods for synchronizing encrypted model keys, artifacts, and metadata
    between FHEnom AI instances. Synchronization uses certificate-based mutual authentication
    to securely exchange encrypted data required for inference.
    
    Prerequisites:
        - Both peers must have certificates from the same Certificate Authority
        - Both peers must use the same client_id
        - Bidirectional network connectivity on admin port (default 9099)
        - Both peers must be properly provisioned and running
    
    Example:
        ```python
        # Initialize client
        client = FHEnomClient(admin_url="http://localhost:9099")
        
        # Start synchronization with peer
        result = client.admin.sync.start(
            peer_url="http://192.168.1.100",
            peer_port=9099
        )
        
        print(f"Synchronization job: {result['job_id']}")
        print(f"Status: {result['status']}")
        ```
    """
    
    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        verify_ssl: bool = True,
        auth_token: str = "default-auth-token-2026"
    ):
        """
        Initialize SyncManager.
        
        Args:
            base_url: Base URL of the admin interface (e.g., "http://localhost:9099")
            timeout: Request timeout in seconds
            verify_ssl: Whether to verify SSL certificates
            auth_token: Authentication token for X-Auth-Token header
        """
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.auth_token = auth_token
        
        # Suppress SSL warnings if verification is disabled
        if not self.verify_ssl:
            warnings.filterwarnings('ignore', message='Unverified HTTPS request')
            # Also suppress urllib3 warnings
            try:
                import urllib3
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            except ImportError:
                pass
        
        logger.info(f"Initialized SyncManager for {self.base_url}")
    
    def _safe_json(self, response: requests.Response) -> Any:
        """
        Safely parse JSON from response with proper error handling.
        
        Args:
            response: Response object to parse
            
        Returns:
            Parsed JSON data
            
        Raises:
            SyncError: If response is not valid JSON or empty
        """
        # Check if response has content
        if not response.content:
            raise SyncError(
                f"Empty response from server (status {response.status_code})"
            )
        
        # Try to parse JSON
        try:
            return response.json()
        except requests.exceptions.JSONDecodeError as e:
            # Provide helpful error message with response text
            response_text = response.text[:500] if response.text else "(empty)"
            raise SyncError(
                f"Invalid JSON response from server (status {response.status_code}): {e}. "
                f"Response content: {response_text}"
            )
    
    def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> requests.Response:
        """
        Make HTTP request with error handling.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            **kwargs: Additional arguments for requests
            
        Returns:
            Response object
            
        Raises:
            SyncError: If the request fails
            ConnectionError: If connection fails
        """
        url = urljoin(self.base_url + '/', endpoint.lstrip('/'))
        
        # Add authentication header
        headers = kwargs.pop('headers', {})
        headers['X-Auth-Token'] = self.auth_token
        
        # Set timeout if not specified
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self.timeout
        
        # Set SSL verification
        kwargs['verify'] = self.verify_ssl
        
        try:
            logger.debug(f"{method} {url}")
            response = requests.request(method, url, headers=headers, **kwargs)
            response.raise_for_status()
            return response
            
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Failed to connect to {url}: {str(e)}")
        except requests.exceptions.Timeout as e:
            raise SyncError(f"Request timeout: {str(e)}")
        except requests.exceptions.HTTPError as e:
            error_msg = f"Sync request failed: {e.response.status_code}"
            try:
                error_data = e.response.json()
                error_msg += f" - {error_data.get('error', str(error_data))}"
            except:
                error_msg += f" - {e.response.text}"
            raise SyncError(error_msg)
        except Exception as e:
            raise SyncError(f"Unexpected error during sync operation: {str(e)}")
    
    def start(
        self,
        peer_url: str,
        peer_port: int = 9099
    ) -> Dict[str, Any]:
        """
        Initiate peer-to-peer synchronization with another FHEnom AI instance.
        
        This method starts the synchronization process with a peer instance. The process
        includes:
        1. Mutual authentication using certificates and challenge-response
        2. Exchange of encrypted model inventories
        3. Automatic exchange of missing encrypted keys, artifacts, and metadata
        
        After successful synchronization, both peers are registered in the cluster and will
        automatically exchange information about new encrypted models.
        
        Prerequisites:
            - Peer must be reachable at the specified URL and port
            - Both instances must have certificates from the same Certificate Authority
            - Both instances must use the same client_id
            - Bidirectional network connectivity (both peers must reach each other)
        
        Args:
            peer_url: Base URL of the peer instance (e.g., "http://192.168.1.100" or "https://peer.example.com")
            peer_port: Admin port of the peer instance (default: 9099)
            
        Returns:
            Dictionary containing synchronization result:
            - job_id: Synchronization job identifier
            - status: Job status ('completed', 'running', 'failed')
            - peer_identity: Identity information of the peer
            - models_synced: Number of models synchronized (if completed)
            - message: Status message
            
        Raises:
            SyncError: If synchronization fails
            ConnectionError: If peer is unreachable
            ValidationError: If parameters are invalid
            
        Example:
            ```python
            # Synchronize with a peer
            result = client.admin.sync.start(
                peer_url="http://192.168.1.100",
                peer_port=9099
            )
            
            if result['status'] == 'completed':
                print(f"Successfully synced {result['models_synced']} models")
                print(f"Peer identity: {result['peer_identity']}")
            ```
            
        Note:
            - Synchronization is bidirectional: both peers will exchange models
            - If either peer restarts, call this method again to re-establish the connection
            - Network firewalls must allow bidirectional traffic on the admin port
        """
        # Validate inputs
        if not peer_url:
            raise SyncError("peer_url cannot be empty")
        
        peer_url = peer_url.rstrip('/')
        
        # Parse the peer_url to extract IP/hostname
        from urllib.parse import urlparse
        
        # Handle URLs with or without scheme
        if not peer_url.startswith(('http://', 'https://')):
            # Add http:// for parsing
            parsed = urlparse(f"http://{peer_url}")
        else:
            parsed = urlparse(peer_url)
        
        # Extract hostname/IP
        peer_ip = parsed.hostname if parsed.hostname else peer_url.split(':')[0].replace('http://', '').replace('https://', '')
        
        # Use port from URL if present, otherwise use the peer_port parameter
        if parsed.port:
            peer_port = parsed.port
        
        logger.info(f"Starting synchronization with peer: {peer_ip}:{peer_port}")
        
        try:
            # Call the admin sync start endpoint
            response = self._request(
                method='POST',
                endpoint='/admin/sync/start',
                json={
                    'peer_ip': peer_ip,
                    'peer_port': peer_port
                }
            )
            
            result = self._safe_json(response)
            logger.info(f"Synchronization initiated successfully: {result.get('job_id')}")
            
            return result
            
        except (SyncError, ConnectionError):
            raise
        except Exception as e:
            raise SyncError(
                f"Failed to start synchronization with {peer_ip}:{peer_port}: {str(e)}",
                peer_url=f"{peer_ip}:{peer_port}"
            )

    def list_peers(self) -> List[Dict[str, Any]]:
        """
        Return the current peer-to-peer network topology.

        The server responds with ``{"nodes": [...]}``
        (``NetworkTopologyResponse``). This method returns the ``nodes``
        list directly to match the SDK's list-endpoint convention
        (same shape as ``AdminAPI.list_models``).

        Returns:
            A list of node dicts. For direct peers each entry has
            ``peer_id``, ``status`` (``"alive"`` or ``"expired"``),
            ``ip``, ``port``, ``last_seen``; all entries have
            ``sequence_number``, ``direct``, ``neighbors`` and
            optionally ``lsa_sequence_number``. Pass a direct peer's
            ``peer_id`` to :meth:`forget_peer`.
        """
        response = self._request("GET", "/admin/sync/peers")
        return self._safe_json(response)["nodes"]

    def forget_peer(self, peer_id: str) -> Dict[str, Any]:
        """
        Drop a direct peer from this node's view of the network.

        Args:
            peer_id: The opaque ``peer_id`` returned by :meth:`list_peers`
                for a direct peer.

        Raises:
            SyncError: Server returned 404 (unknown peer) or any other
                non-2xx status.

        Returns:
            CommandResponse dict from the server.
        """
        endpoint = f"/admin/sync/peers/{quote(peer_id, safe='')}/forget"
        response = self._request("POST", endpoint)
        return self._safe_json(response)

    def revoke_sequence_number(self, sequence_number: int) -> Dict[str, Any]:
        """
        Revoke a sync sequence number and propagate the revocation to all known peers.

        Use this to invalidate a specific sync operation across the P2P network.
        The revocation is gossiped automatically to all peers known to this node.

        Args:
            sequence_number: The sequence number to revoke, as returned by a
                sync job response.

        Raises:
            SyncError: Server returned a non-2xx status.

        Returns:
            CommandResponse dict from the server, including a ``response``
            message confirming whether the sequence number was newly revoked
            or had already been revoked.
        """
        response = self._request(
            "POST",
            "/admin/sync/revoke",
            json={"sequence_number": sequence_number}
        )
        return self._safe_json(response)
