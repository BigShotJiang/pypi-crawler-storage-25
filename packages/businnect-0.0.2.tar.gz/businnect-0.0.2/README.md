# Businnect Python

The official Python SDK for the [Businnect](https://businnect.com) API.

## Installation

```bash
pip install businnect
```

## Setup

Find your API token at [https://businnect.com/settings/developer](https://businnect.com/settings/developer) after creating an account at [https://businnect.com/register](https://businnect.com/register).

```python
from businnect import Businnect

client = Businnect(api_token="your_api_token_here")
```

---

## Micropost

### Create a post

```python
from businnect.schemas.micropost import PostType

# Text post
post = client.micropost.client_create_micropost(
    title="Hello World",
    body="This is my first post.",
)
print(post.public_id)
print(post.link)

# Media post
with open("photo.png", "rb") as f:
    post = client.micropost.client_create_micropost(
        title="My photo",
        body="Check this out",
        post_type=PostType.MEDIA,
        file=("photo.png", f, "image/png"),
    )

# Reply to a post
reply = client.micropost.client_create_micropost(
    body="Great post!",
    parent_micropost_public_id="post_public_id_here",
)

# Nested reply (reply to a comment)
nested = client.micropost.client_create_micropost(
    body="I agree!",
    parent_micropost_public_id="post_public_id_here",
    parent_micropost_comment_public_id="comment_public_id_here",
)
```

### Delete a post

```python
client.micropost.client_delete_micropost(public_id="post_public_id_here")
```

### Vote on a post (toggle)

```python
result = client.micropost.client_vote_micropost(public_id="post_public_id_here")
print(result.user_voted)  # True or False
```

---

## Blog

### Get admin article

```python
article = client.blog.client_get_admin_blog()
if article:
    print(article.title)
    print(article.body)
```

### List admin articles

```python
result = client.blog.client_list_admin_blogs()
print(result.total_list)
for article in result.list:
    print(article.title, article.slug)
```

---

## API Reference

### `Businnect(api_token, base_url?)`

| Parameter | Type | Description |
|-----------|------|-------------|
| `api_token` | `str` | Your API token |
| `base_url` | `str` | API base URL (default: `https://api.businnect.com`) |

---

### `client.micropost.client_create_micropost(...)`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `body` | `str` | required | Content of the post |
| `title` | `str` | `None` | Required for original posts |
| `post_type` | `PostType` | `PostType.TEXT` | `TEXT` or `MEDIA` |
| `community_name` | `str` | `None` | Community to post in |
| `parent_micropost_public_id` | `str` | `None` | For replies |
| `parent_micropost_comment_public_id` | `str` | `None` | For nested replies |
| `allow_comments` | `bool` | `True` | Whether comments are allowed |
| `is_draft` | `bool` | `False` | Save as draft |
| `file` | `tuple` | `None` | `(filename, file_object, mime_type)` for MEDIA posts |

**Returns:** `CreatedWithPublicIdAndLinkResponse` with `public_id` and `link`

---

### `client.micropost.client_delete_micropost(public_id)`

| Parameter | Type | Description |
|-----------|------|-------------|
| `public_id` | `str` | Public ID of the post to delete |

**Returns:** `None` (204 on success)

---

### `client.micropost.client_vote_micropost(public_id)`

| Parameter | Type | Description |
|-----------|------|-------------|
| `public_id` | `str` | Public ID of the post to vote on |

**Returns:** `VoteResponse` with `user_voted` (bool)

---

### `client.blog.client_get_admin_blog()`

**Returns:** `BlogResponse` or `None`

---

### `client.blog.client_list_admin_blogs()`

**Returns:** `BlogListResponse` with `list`, `total_list` and `total_pages`

---

## Development

```bash
# Install in editable mode
pip install -e .

# Run unit tests
python -m pytest businnect/tests/test_businnect_unit.py -v

# Run integration tests (requires real API token)
BUSINNECT_API_TOKEN=your_token python -m pytest businnect/tests/test_businnect_integration.py -v -s
```

## License

MIT