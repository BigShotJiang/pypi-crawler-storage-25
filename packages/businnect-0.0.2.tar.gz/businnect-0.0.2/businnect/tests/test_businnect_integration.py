# Unit tests

import httpx
import pytest
from unittest.mock import MagicMock, patch

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from client import Businnect

# $pip install -e .
# $BUSINNECT_API_TOKEN=yours python -m pytest businnect/tests/test_businnect_integration.py -v -s
# @pytest.mark.skip(reason="already tested")
def test_client_create_micropost():
    client = Businnect(api_token=os.environ["BUSINNECT_API_TOKEN"])
    try:
        response = client.micropost.client_create_micropost(title="Test", body="Hello")
        assert response.public_id is not None
    except Exception as e:
        if hasattr(e, 'response'):
            print(repr(e.response.text))
        raise