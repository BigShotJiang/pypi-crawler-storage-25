Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  DataSecOps Framework CLI Setup" -ForegroundColor Green
Write-Host "============================================================================" -ForegroundColor Green
Write-Host ""

# --- Step 1: Check prerequisites ---

# Check for uv
try {
    $uvVersion = uv --version 2>$null
    Write-Host "[OK] uv $uvVersion" -ForegroundColor Green
} catch {
    Write-Host "uv not found. Installing..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri "https://astral.sh/uv/install.ps1" -OutFile "$env:TEMP\install-uv.ps1"
    & "$env:TEMP\install-uv.ps1"
    $env:Path = "$env:USERPROFILE\.local\bin;$env:Path"
}

# Check for dbt
try {
    $null = Get-Command dbt -ErrorAction Stop
    Write-Host "[OK] dbt found" -ForegroundColor Green
} catch {
    Write-Host "WARNING: dbt not found on PATH." -ForegroundColor Yellow
    Write-Host "  Install dbt Fusion or: pip install dbt-snowflake" -ForegroundColor Yellow
}

# Check for cortex (optional)
try {
    $null = Get-Command cortex -ErrorAction Stop
    Write-Host "[OK] Cortex Code found" -ForegroundColor Green
} catch {
    Write-Host "[INFO] Cortex Code not found (optional)" -ForegroundColor Cyan
}

# Check for node (optional - needed for GitHub/Azure DevOps MCP servers)
try {
    $nodeVersion = node --version 2>$null
    Write-Host "[OK] Node.js $nodeVersion found" -ForegroundColor Green
} catch {
    Write-Host "[INFO] Node.js not found (optional - needed for GitHub/Azure DevOps MCP servers)" -ForegroundColor Cyan
}

# --- Step 2: Select Snowflake connection ---

Write-Host ""
Write-Host "--- Snowflake Connection ---" -ForegroundColor Green
Write-Host ""

$connectionsFile = Join-Path $env:USERPROFILE ".snowflake\connections.toml"
$connectionNames = @()
$defaultConnection = $null

if (Test-Path $connectionsFile) {
    # Parse default connection name
    $defaultLine = Get-Content $connectionsFile | Select-String '^default_connection_name\s*=' | Select-Object -First 1
    if ($defaultLine) {
        $defaultConnection = ($defaultLine -replace '.*=\s*', '').Trim().Trim('"').Trim("'")
    }

    # Parse connection section names
    $connectionNames = @(Get-Content $connectionsFile | Select-String '^\[([^\]]+)\]' | ForEach-Object { $_.Matches[0].Groups[1].Value })
}

if ($connectionNames.Count -gt 0) {
    Write-Host "Available connections:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $connectionNames.Count; $i++) {
        $marker = ""
        if ($connectionNames[$i] -eq $defaultConnection) { $marker = " (default)" }
        Write-Host "  [$($i + 1)] $($connectionNames[$i])$marker"
    }
    Write-Host ""

    $defaultIndex = -1
    if ($defaultConnection) {
        $defaultIndex = [array]::IndexOf($connectionNames, $defaultConnection)
    }

    if ($defaultIndex -ge 0) {
        $prompt = "Select connection [1-$($connectionNames.Count)] (default: $($defaultIndex + 1))"
    } else {
        $prompt = "Select connection [1-$($connectionNames.Count)]"
    }

    $selection = Read-Host $prompt
    if ([string]::IsNullOrWhiteSpace($selection) -and $defaultIndex -ge 0) {
        $connectionName = $defaultConnection
    } elseif ($selection -match '^\d+$' -and [int]$selection -ge 1 -and [int]$selection -le $connectionNames.Count) {
        $connectionName = $connectionNames[[int]$selection - 1]
    } else {
        Write-Host "ERROR: Invalid selection" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "No connections found in $connectionsFile" -ForegroundColor Yellow
    $connectionName = Read-Host "Enter connection name"
    if ([string]::IsNullOrWhiteSpace($connectionName)) {
        Write-Host "ERROR: Connection name is required" -ForegroundColor Red
        exit 1
    }
}

Write-Host "[OK] Using connection: $connectionName" -ForegroundColor Green

# --- Step 3: Enter native app database name ---

Write-Host ""
$appDatabase = Read-Host "Enter native app database name (e.g. DATA_ENGINEERS_DATASECOPS_FRAMEWORK)"
if ([string]::IsNullOrWhiteSpace($appDatabase)) {
    Write-Host "ERROR: App database name is required" -ForegroundColor Red
    exit 1
}

# --- Step 4: Create venv ---

Write-Host ""
Write-Host "Creating virtual environment..." -ForegroundColor Cyan
uv venv .venv
Write-Host "[OK] Virtual environment created at .venv\" -ForegroundColor Green

# --- Step 5: Install CLI package with MCP support ---

Write-Host ""
Write-Host "Installing datasecops-cli with MCP server..." -ForegroundColor Cyan
uv pip install "datasecops-cli[mcp]"
Write-Host "[OK] datasecops-cli installed (with MCP server)" -ForegroundColor Green

# --- Step 6: Install dbt MCP server (optional) ---

Write-Host ""
$installDbtMcp = Read-Host "Install dbt MCP server? (y/N)"
if ($installDbtMcp -eq 'y') {
    uv pip install dbt-mcp
    Write-Host "[OK] dbt-mcp installed" -ForegroundColor Green
}

# --- Write config ---

@"
# DataSecOps Framework CLI Configuration
# Generated by setup.ps1
connection_name: "$connectionName"
app_database: "$appDatabase"
profile_name: ""
"@ | Out-File -FilePath ".datasecops.yml" -Encoding utf8

# --- Step 7: Configure MCP servers for AI tools ---

Write-Host ""
Write-Host "--- MCP Server Configuration ---" -ForegroundColor Green
Write-Host ""

$configureMcp = Read-Host "Configure MCP servers for your AI tool? (y/N)"
if ($configureMcp -eq 'y') {

    Write-Host ""
    Write-Host "Which source control platform do you use?" -ForegroundColor Cyan
    Write-Host "  [1] GitHub"
    Write-Host "  [2] Azure DevOps"
    Write-Host "  [3] Neither / skip"
    $platformChoice = Read-Host "Choice (1/2/3)"

    Write-Host ""
    Write-Host "Which AI tool are you configuring?" -ForegroundColor Cyan
    Write-Host "  [1] VS Code (Copilot)"
    Write-Host "  [2] Cursor"
    Write-Host "  [3] Cortex Code"
    Write-Host "  [4] Skip (I'll configure manually)"
    $toolChoice = Read-Host "Choice (1/2/3/4)"

    $mcpFile = $null

    if ($toolChoice -eq '1') {
        $mcpDir = ".vscode"
        $mcpFile = Join-Path $mcpDir "mcp.json"
        New-Item -ItemType Directory -Path $mcpDir -Force | Out-Null
    }
    elseif ($toolChoice -eq '2') {
        $mcpDir = ".cursor"
        $mcpFile = Join-Path $mcpDir "mcp.json"
        New-Item -ItemType Directory -Path $mcpDir -Force | Out-Null
    }
    elseif ($toolChoice -eq '3') {
        # Cortex Code uses cortex mcp add commands
        Write-Host ""
        Write-Host "Adding MCP servers to Cortex Code..." -ForegroundColor Cyan

        try { cortex mcp add datasecops-framework -- datasecops-mcp 2>$null }
        catch { Write-Host "  (run manually: cortex mcp add datasecops-framework -- datasecops-mcp)" -ForegroundColor Yellow }

        if ($installDbtMcp -eq 'y') {
            try { cortex mcp add dbt -- uvx dbt-mcp 2>$null }
            catch { Write-Host "  (run manually: cortex mcp add dbt -- uvx dbt-mcp)" -ForegroundColor Yellow }
        }

        if ($platformChoice -eq '1') {
            $githubToken = Read-Host "Enter your GitHub PAT (or press Enter to skip)"
            if (-not [string]::IsNullOrWhiteSpace($githubToken)) {
                try {
                    cortex mcp add github -e "GITHUB_PERSONAL_ACCESS_TOKEN=$githubToken" -- npx -y @modelcontextprotocol/server-github 2>$null
                } catch {
                    Write-Host "  (run manually: cortex mcp add github -e GITHUB_PERSONAL_ACCESS_TOKEN=`$GITHUB_TOKEN -- npx -y @modelcontextprotocol/server-github)" -ForegroundColor Yellow
                }
            }
        }
        elseif ($platformChoice -eq '2') {
            $azureOrg = Read-Host "Enter your Azure DevOps org URL (e.g. https://dev.azure.com/myorg)"
            $azurePat = Read-Host "Enter your Azure DevOps PAT (or press Enter to skip)"
            if (-not [string]::IsNullOrWhiteSpace($azurePat)) {
                try {
                    cortex mcp add azure-devops -e "AZURE_DEVOPS_ORG_URL=$azureOrg" -e "AZURE_DEVOPS_AUTH_METHOD=pat" -e "AZURE_DEVOPS_PAT=$azurePat" -- npx -y @tiberriver256/mcp-server-azure-devops 2>$null
                } catch {
                    Write-Host "  (run manually with cortex mcp add)" -ForegroundColor Yellow
                }
            }
        }

        Write-Host "[OK] Cortex Code MCP servers configured" -ForegroundColor Green
    }

    # Write JSON config for VS Code / Cursor
    if ($null -ne $mcpFile) {
        $servers = [ordered]@{
            "datasecops-framework" = [ordered]@{
                command = "datasecops-mcp"
                args = @()
            }
        }

        if ($installDbtMcp -eq 'y') {
            $servers["dbt"] = [ordered]@{
                command = "uvx"
                args = @("dbt-mcp")
            }
        }

        if ($platformChoice -eq '1') {
            $servers["github"] = [ordered]@{
                command = "npx"
                args = @("-y", "@modelcontextprotocol/server-github")
                env = [ordered]@{
                    GITHUB_PERSONAL_ACCESS_TOKEN = '${GITHUB_TOKEN}'
                }
            }
        }
        elseif ($platformChoice -eq '2') {
            $servers["azure-devops"] = [ordered]@{
                command = "npx"
                args = @("-y", "@tiberriver256/mcp-server-azure-devops")
                env = [ordered]@{
                    AZURE_DEVOPS_ORG_URL = '${AZURE_DEVOPS_ORG_URL}'
                    AZURE_DEVOPS_AUTH_METHOD = "pat"
                    AZURE_DEVOPS_PAT = '${AZURE_DEVOPS_PAT}'
                }
            }
        }

        $mcpConfig = [ordered]@{ mcpServers = $servers }
        $mcpConfig | ConvertTo-Json -Depth 5 | Out-File -FilePath $mcpFile -Encoding utf8
        Write-Host "[OK] MCP config written to $mcpFile" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  Setup complete!" -ForegroundColor Green
Write-Host "============================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Config written to: .datasecops.yml"
Write-Host ""
Write-Host "  To get started:" -ForegroundColor Cyan
Write-Host "    .\.venv\Scripts\Activate.ps1" -ForegroundColor White
Write-Host "    datasecops" -ForegroundColor White
Write-Host ""
Write-Host "  MCP server (for AI tools):" -ForegroundColor Cyan
Write-Host "    datasecops-mcp" -ForegroundColor White
Write-Host ""
Write-Host "  Documentation:" -ForegroundColor Cyan
Write-Host "    docs/getting-started.md   - full setup guide" -ForegroundColor White
Write-Host "    docs/mcp-server.md        - MCP server reference" -ForegroundColor White
Write-Host ""
