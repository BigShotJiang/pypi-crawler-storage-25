# Getting Started Guide

A step-by-step guide to install the DataSecOps Framework CLI and configure MCP servers for use with VS Code, Cursor, Cortex Code, and other AI coding tools — integrated with Snowflake, dbt, and GitHub/Azure DevOps.

## Prerequisites

Before you begin, ensure you have:

- **Python 3.10+** installed
- **Node.js 18+** installed (for GitHub/Azure DevOps MCP servers)
- **A Snowflake account** with the DataSecOps Framework Native App installed
- **A Snowflake connection** configured in `~/.snowflake/connections.toml`
- **A project profile** created in the native app
- **Git** configured with access to your repository

Optional:
- **dbt Fusion** (or dbt-core with dbt-snowflake) for dbt commands
- **A GitHub Personal Access Token** (for GitHub MCP server)
- **An Azure DevOps PAT** (for Azure DevOps MCP server)

---

## Step 1: Install the CLI

```bash
pip install "datasecops-cli[mcp]"
```

This installs:
- `datasecops` — the interactive CLI for dbt development, git operations, and config downloads
- `datasecops-mcp` — the MCP server that exposes framework governance rules to AI tools

### Verify installation

```bash
datasecops --version
datasecops-mcp --help
```

---

## Step 2: Configure your project

Navigate to your dbt project root and run the setup script:

**Windows (PowerShell):**

```powershell
.\setup.ps1
```

**Linux / macOS:**

```bash
chmod +x setup.sh && ./setup.sh
```

This creates `.datasecops.yml` in your project root:

```yaml
connection_name: "my_connection"
app_database: "DATA_ENGINEERS_DATASECOPS_FRAMEWORK"
```

If you prefer to create it manually, the two required fields are:
- `connection_name` — your Snowflake connection name from `~/.snowflake/connections.toml`
- `app_database` — the database where the native app is installed

---

## Step 3: Configure your Snowflake connection

If you don't already have a connection in `~/.snowflake/connections.toml`:

```toml
[my_connection]
account = "your_account.region"
user = "your_user@company.com"
authenticator = "externalbrowser"
warehouse = "DEV_WH"
role = "DEVELOPERS"
```

Test the connection:

```bash
datasecops
```

You should see the main menu, confirming the CLI can reach the native app.

---

## Step 4: Install MCP servers

### 4a. DataSecOps Framework MCP Server (included)

Already installed with the CLI. No extra steps needed.

### 4b. dbt MCP Server

```bash
pip install dbt-mcp
```

Or run via uvx (no install required):

```bash
uvx dbt-mcp
```

### 4c. GitHub MCP Server

Requires a [Personal Access Token](https://github.com/settings/tokens) with `repo`, `read:org`, and `workflow` scopes.

```bash
# Set your token as an environment variable
# Windows PowerShell:
$env:GITHUB_TOKEN = "ghp_your_token_here"

# Linux/macOS:
export GITHUB_TOKEN="ghp_your_token_here"
```

The server runs via npx (no install required).

### 4d. Azure DevOps MCP Server

Requires a [Personal Access Token](https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate) with Code, Build, and Work Items scopes.

```bash
# Set your credentials
# Windows PowerShell:
$env:AZURE_DEVOPS_ORG_URL = "https://dev.azure.com/your-org"
$env:AZURE_DEVOPS_PAT = "your_pat_here"

# Linux/macOS:
export AZURE_DEVOPS_ORG_URL="https://dev.azure.com/your-org"
export AZURE_DEVOPS_PAT="your_pat_here"
```

The server runs via npx (no install required).

---

## Step 5: Configure your AI tool

Choose your editor and add the MCP server configuration.

### VS Code (Copilot)

Create `.vscode/mcp.json` in your project root:

```json
{
  "mcpServers": {
    "datasecops-framework": {
      "command": "datasecops-mcp",
      "args": []
    },
    "dbt": {
      "command": "uvx",
      "args": ["dbt-mcp"],
      "env": {
        "DBT_HOST": "your_account.snowflakecomputing.com",
        "DBT_ENV_ID": "your_environment_id",
        "DBT_TOKEN": "${DBT_TOKEN}"
      }
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

For Azure DevOps instead of GitHub:

```json
{
  "mcpServers": {
    "datasecops-framework": {
      "command": "datasecops-mcp",
      "args": []
    },
    "dbt": {
      "command": "uvx",
      "args": ["dbt-mcp"],
      "env": {
        "DBT_HOST": "your_account.snowflakecomputing.com",
        "DBT_ENV_ID": "your_environment_id",
        "DBT_TOKEN": "${DBT_TOKEN}"
      }
    },
    "azure-devops": {
      "command": "npx",
      "args": ["-y", "@tiberriver256/mcp-server-azure-devops"],
      "env": {
        "AZURE_DEVOPS_ORG_URL": "${AZURE_DEVOPS_ORG_URL}",
        "AZURE_DEVOPS_AUTH_METHOD": "pat",
        "AZURE_DEVOPS_PAT": "${AZURE_DEVOPS_PAT}"
      }
    }
  }
}
```

### Cursor

Create `.cursor/mcp.json` in your project root with the same format as above.

### Cortex Code (CoCo)

Add servers from the command line:

```bash
# DataSecOps Framework
cortex mcp add datasecops-framework -- datasecops-mcp

# dbt
cortex mcp add dbt -- uvx dbt-mcp

# GitHub
cortex mcp add github -e GITHUB_PERSONAL_ACCESS_TOKEN=$GITHUB_TOKEN -- npx -y @modelcontextprotocol/server-github

# OR Azure DevOps
cortex mcp add azure-devops -e AZURE_DEVOPS_ORG_URL=$AZURE_DEVOPS_ORG_URL -e AZURE_DEVOPS_AUTH_METHOD=pat -e AZURE_DEVOPS_PAT=$AZURE_DEVOPS_PAT -- npx -y @tiberriver256/mcp-server-azure-devops
```

Verify all servers are connected:

```bash
cortex mcp list
```

### Claude Code

```bash
claude mcp add datasecops-framework -- datasecops-mcp
claude mcp add dbt -- uvx dbt-mcp
claude mcp add github -e GITHUB_PERSONAL_ACCESS_TOKEN=$GITHUB_TOKEN -- npx -y @modelcontextprotocol/server-github
```

---

## Step 6: Configure the dbt MCP server

The dbt MCP server supports two modes:

### Local mode (dbt CLI tools only — no Cloud required)

If you only need local dbt commands (build, run, test, compile), no extra configuration is needed. The server reads your `dbt_project.yml` from the working directory.

```json
{
  "dbt": {
    "command": "uvx",
    "args": ["dbt-mcp", "--local"]
  }
}
```

### Platform mode (Cloud features: Discovery, Semantic Layer, Jobs)

For full dbt Cloud integration, set these environment variables:

| Variable | Description |
|----------|-------------|
| `DBT_HOST` | Your dbt Cloud host (e.g., `cloud.getdbt.com`) |
| `DBT_TOKEN` | A dbt Cloud [service token](https://docs.getdbt.com/docs/dbt-cloud-apis/service-tokens) |
| `DBT_ENV_ID` | Your dbt Cloud environment ID |
| `DBT_PROJECT_ID` | Your dbt Cloud project ID (optional if only one project) |

---

## Step 7: Verify everything works

Open your editor, start a chat with your AI assistant, and try these prompts:

### Test the Framework server

> "What branch types are allowed in this project?"

Expected: Returns your framework's branching rules (feature, hotfix, bugfix, etc.)

### Test the dbt server

> "Show me the lineage for the orders model"

Expected: Returns model dependencies from your dbt project

### Test GitHub/Azure DevOps

> "Create a pull request for this branch"

Expected: Creates a PR on your platform with the correct base branch

---

## What Each MCP Server Provides

| Server | What your AI assistant can do |
|--------|-------------------------------|
| **datasecops-framework** | Check branching rules, linting config, approved packages, deployment workflow, project settings |
| **dbt** | Run/build/test models, explore lineage, generate YAML, query metrics, search documentation |
| **github** | Create PRs, check CI status, manage issues, review code, create releases |
| **azure-devops** | Create PRs, check pipeline status, manage work items, view boards |

---

## Troubleshooting

### MCP server not connecting

1. Check the server runs manually:
   ```bash
   datasecops-mcp
   ```
   If it errors about `.datasecops.yml`, make sure you're in your project directory.

2. Check Node.js is available (for GitHub/Azure DevOps servers):
   ```bash
   node --version
   npx --version
   ```

3. In Cortex Code, run `/mcp list` to see server status and error messages.

### Authentication issues

- **Snowflake**: Verify your connection works: `snowsql -c my_connection` or run `datasecops`
- **GitHub**: Check your PAT hasn't expired and has the required scopes
- **Azure DevOps**: Ensure your PAT has Code (Read & Write), Build (Read), and Work Items (Read & Write)

### dbt MCP server not finding project

The dbt MCP server looks for `dbt_project.yml` in the current working directory. Make sure your editor is opened at the dbt project root, or set the `DBT_PROJECT_DIR` environment variable.

---

## Recommended Workflow

Once configured, your daily workflow with an AI assistant looks like:

1. **Start work** — ask the AI to create a branch following framework conventions
2. **Develop** — write models; the AI checks linting rules and uses approved packages
3. **Test** — ask the AI to run dbt build and check test results
4. **Deploy** — ask the AI to create a PR; it knows which base branch to target
5. **Monitor** — ask about CI status; the AI checks pipeline results

All governance rules are enforced automatically through the MCP server — no manual lookups needed.
