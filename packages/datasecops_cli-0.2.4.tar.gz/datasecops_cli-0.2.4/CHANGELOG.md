# Changelog

All notable changes to the DataSecOps CLI are documented in this file.

## [0.2.4] - 2026-05-11

### Fixed

- **Use `uv pip` instead of `pip`** for all package operations — `get_installed_versions()`, `install_requirements()`, and bootstrap hints now use `uv pip show` / `uv pip install` to match the framework's `uv`-based toolchain
- **Pin sqlfluff versions from native app** — the lint menu now fetches the framework-mandated `sqlfluff` and `sqlfluff-templater-dbt` versions from `DBT_VERSIONS` config and installs/upgrades to those exact versions before linting

## [0.2.3] - 2026-05-11

### Fixed

- **Stripped invalid `dbt_skip_compilation_error` option** from the generated `[sqlfluff:templater:dbt]` section — this native app field is not a valid sqlfluff config key and caused parse errors
- **`profiles_dir = ${DBT_PROFILES_DIR}` no longer leaks** into generated config — the raw value from the native app is now always replaced with the resolved local path or removed entirely
- **Empty string values** (e.g. `warnings = ""`) now emit `None` instead of blank, matching sqlfluff's expected INI format

### Added

- **Auto-install `sqlfluff-templater-dbt`** — the lint menu now checks for missing sqlfluff packages before linting and installs them automatically

## [0.2.2] - 2026-05-10

### Fixed

- **Full SQLFluff config generation** — `download_sqlfluff_config()` now generates all sections from the native app config: core, templater, indentation, layout types, global rules, and all rule bundles (aliasing, ambiguous, capitalisation, convention, jinja, layout, references, structure)
- Previously only `core` and `indentation` sections were emitted, missing ~90% of the config

### Added

- **Setup script connection selector** — `setup.ps1` and `setup.sh` now parse `~/.snowflake/connections.toml`, display a numbered list of connections with the default highlighted, and let the user select by number instead of typing the name manually
- Rule code to section name mapping (`RULE_SECTION_MAP`) for all sqlfluff rule bundles (AL01-AL09, AM01-AM08, CP01-CP05, CV01-CV12, JJ01, LT01-LT15, RF01-RF06, ST01-ST11)
- Value formatting helper (`_format_value`) for correct INI output of bools, lists, nulls, and empty strings

## [0.2.1] - 2026-05-10

### Fixed

- **SQLFluff config now includes `[sqlfluff:templater:dbt]` section** with `project_dir` and `profiles_dir` when downloaded from the framework, eliminating the need for `${DBT_PROFILES_DIR}` environment variable substitution
- **Auto-download `.sqlfluff` before linting** — the lint menu now automatically downloads the config from the framework if it doesn't exist locally, instead of failing silently or erroring
- **CI lint action handles missing `.sqlfluffconfig`** — the `tasks/lint-sql` action now only runs `envsubst` if `.sqlfluffconfig` exists, and accepts a pre-generated `.sqlfluff` file directly

### Changed

- `download_sqlfluff_config()` accepts an optional `profiles_dir` parameter to embed in the generated config
- `DevelopmentMenu` and `DownloadsMenu` pass the resolved `profiles_dir` through to the download service
- `.sqlfluff` no longer needs to be committed to client repos — it is generated on-the-fly from the framework

## [0.2.0] - 2026-05-09

### Added

- **MCP Server** — new `datasecops-mcp` server exposes framework governance config to AI coding tools (VS Code, Cursor, Cortex Code, Claude Code)
  - `get_branching_rules` — branch types, naming conventions, ticket requirements
  - `get_linting_rules` — SQLFluff rules from the native app
  - `get_dbt_packages` — approved packages with pinned versions
  - `get_pipeline_config` — CI/CD pipeline templates (GitHub/Azure DevOps)
  - `get_dbt_versions` — mandated dbt and SQLFluff versions
  - `get_project_settings` — project paths, execution mode, targets
  - `get_project_profiles` — all registered dbt projects
  - `get_deployment_targets` — environment targets with roles and warehouses
  - `get_available_skills` — Cortex Code skills metadata
  - `get_default_macros` — default macros for a project profile
  - `validate_branch_name` — validates branch names against framework conventions
  - `get_deployment_workflow` — environment promotion flow
  - `lint_sql` — lint a SQL file using project's SQLFluff config
  - `fix_sql` — auto-fix linting issues in a SQL file
  - `lint_project` — lint or fix all models in the project

- **Bootstrap command** — `datasecops bootstrap` sets up a new dbt project in one step:
  1. Runs `dbtf init` and generates `profiles.yml` from framework targets
  2. Downloads default macros for the project profile
  3. Downloads `.sqlfluff` linting configuration
  4. Downloads CI/CD pipeline files (GitHub Actions or Azure DevOps)
  5. Downloads `packages.yml` with approved versions
  6. Runs `dbt deps`
  7. Checks SQLFluff version requirements
  8. Installs Cortex Code skills
  - Also available from main menu as option [4]

- **Macro downloads** — new `api.get_macros_for_profile` integration
  - Downloads default macros (e.g., `generate_schema_name`) to `macros/` directory
  - Available in downloads menu as option [4]
  - Included in bootstrap process

- **MCP server configuration in setup scripts** — `setup.sh` and `setup.ps1` now:
  - Check for Node.js (needed for GitHub/Azure DevOps MCP servers)
  - Install with MCP support (`datasecops-cli[mcp]`)
  - Optionally install `dbt-mcp`
  - Interactively configure MCP servers for VS Code, Cursor, or Cortex Code
  - Support GitHub and Azure DevOps PAT configuration

- **MCP server integration guide** (`mcp-servers.json`) — example config for running framework, dbt, GitHub, and Azure DevOps MCP servers together

### Changed

- `pyproject.toml` — added `mcp` optional dependency group and `datasecops-mcp` script entry point
- Main menu now shows option [4] for bootstrap
- Downloads menu reordered: macros is option [4], skills is [5], new project is [6]
- Setup scripts install `datasecops-cli[mcp]` by default instead of `datasecops-cli`

### Documentation

- `docs/getting-started.md` — full setup guide for CLI + MCP servers with VS Code, Cursor, Cortex Code
- `docs/mcp-server.md` — MCP server reference with tool documentation, architecture, and usage examples
- `README.md` — updated with MCP server section, recommended server stack, and new documentation links

## [0.1.0] - 2025-03-05

### Added

- Initial release of the DataSecOps CLI
- Interactive menu-driven interface for dbt development, git operations, and configuration downloads
- dbt commands via dbt Fusion subprocess (run, build, test, lint, compile, snapshot, freshness, docs, seed, deps, clean, debug, list, retry)
- Git operations via GitPython (branching, commit, push, pull, rebase, squash, deploy, cherry-pick)
- Configuration downloads from native app (SQLFluff rules, CI/CD pipelines, dbt packages, Cortex Code skills)
- Framework-enforced branch naming conventions
- Environment branch deployment (dev/test/prod)
- SQLFluff linting with framework-managed rules
- Snowflake Native App integration via stored procedures
- Cross-platform support (Windows, Linux, macOS)
- PyPI distribution with GitHub Actions OIDC publishing
