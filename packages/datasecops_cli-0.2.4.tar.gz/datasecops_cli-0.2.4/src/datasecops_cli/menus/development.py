from pathlib import Path

from datasecops_cli.services.dbt_runner import DbtRunner
from datasecops_cli.services.linting_service import LintingService
from datasecops_cli.services.download_service import DownloadService
from datasecops_cli.services.git_service import GitService
from datasecops_cli.utilities.display import (
    clear, section_header, display_action_header, menu_option, 
    get_input_number, get_input_string, get_input_true_false, complete_action,
    info_line, error_line
)


class DevelopmentMenu:
    def __init__(self, dbt_runner: DbtRunner, linting_service: LintingService, 
                 git_service: GitService, profile_name: str,
                 download_service: DownloadService = None,
                 profiles_dir: str = None):
        self.dbt = dbt_runner
        self.linting = linting_service
        self.git = git_service
        self.profile_name = profile_name
        self.downloads = download_service
        self.profiles_dir = profiles_dir
    
    def show(self) -> None:
        self._menu()
        option = get_input_number("Choose an option: ")
        while option != 0:
            if option == 1:
                self._run_menu()
            elif option == 2:
                self._test_menu()
            elif option == 3:
                self._lint_menu()
            elif option == 4:
                display_action_header("dbt docs")
                self.dbt.docs_generate()
                if get_input_true_false("Serve docs?"):
                    self.dbt.docs_serve()
                complete_action()
            elif option == 5:
                display_action_header("dbt seed")
                self.dbt.seed()
                complete_action()
            elif option == 6:
                display_action_header("dbt deps")
                self.dbt.deps()
                complete_action()
            elif option == 7:
                display_action_header("dbt compile")
                self.dbt.compile()
                complete_action()
            elif option == 8:
                display_action_header("dbt snapshot")
                self.dbt.snapshot()
                complete_action()
            elif option == 9:
                display_action_header("dbt source freshness")
                self.dbt.source_freshness()
                complete_action()
            elif option == 10:
                display_action_header("dbt clean")
                self.dbt.clean()
                complete_action()
            elif option == 11:
                display_action_header("dbt debug")
                self.dbt.debug()
                complete_action()
            elif option == 12:
                display_action_header("dbt list")
                self.dbt.list_models()
                complete_action()
            elif option == 13:
                display_action_header("dbt retry")
                self.dbt.retry()
                complete_action()
            self._menu()
            option = get_input_number("Choose an option: ")
    
    def _menu(self) -> None:
        clear()
        section_header("Development Menu", self.profile_name, self.git.get_current_branch() if self.git else None)
        menu_option(1,  "run           - Run dbt models")
        menu_option(2,  "test          - Run dbt tests")
        menu_option(3,  "lint          - SQLFluff linting")
        menu_option(4,  "docs          - Generate & serve dbt docs")
        menu_option(5,  "seed          - Load seed data")
        menu_option(6,  "deps          - Install dbt packages")
        menu_option(7,  "compile       - Compile dbt models")
        menu_option(8,  "snapshot      - Run dbt snapshots")
        menu_option(9,  "freshness     - Check source freshness")
        menu_option(10, "clean         - Clean dbt target")
        menu_option(11, "debug         - Debug dbt connection")
        menu_option(12, "list          - List dbt resources")
        menu_option(13, "retry         - Retry failed dbt run")
        menu_option(0,  "back          - Return to main menu")
    
    def _run_menu(self) -> None:
        clear()
        display_action_header("dbt Run Options")
        menu_option(1, "full run      - Run all models")
        menu_option(2, "modified      - Run modified models only (state:modified+)")
        menu_option(3, "specific      - Run specific model(s)")
        menu_option(4, "macro         - Run a dbt macro")
        menu_option(5, "retry         - Retry failed run")
        menu_option(0, "back          - Return to development menu")
        option = get_input_number("Choose an option: ")
        if option == 1:
            full_refresh = get_input_true_false("Full refresh?", "n")
            self.dbt.run(full_refresh=full_refresh)
        elif option == 2:
            full_refresh = get_input_true_false("Full refresh?", "n")
            self.dbt.run(modified_only=True, full_refresh=full_refresh)
        elif option == 3:
            select = get_input_string("Enter model selector: ")
            if select != "0":
                self.dbt.run(select=select)
        elif option == 4:
            macro = get_input_string("Enter macro name: ")
            if macro != "0":
                args_str = get_input_string("Enter args (JSON or empty): ", allow_empty=True)
                self.dbt.run_operation(macro, args_str if args_str else None)
        elif option == 5:
            self.dbt.retry()
        complete_action()
    
    def _test_menu(self) -> None:
        clear()
        display_action_header("dbt Test Options")
        menu_option(1, "all tests     - Run all tests")
        menu_option(2, "specific      - Run specific test(s)")
        menu_option(0, "back          - Return to development menu")
        option = get_input_number("Choose an option: ")
        if option == 1:
            self.dbt.test()
        elif option == 2:
            select = get_input_string("Enter test selector: ")
            if select != "0":
                self.dbt.test(select=select)
        complete_action()
    
    def _ensure_sqlfluff_config(self) -> bool:
        """Download .sqlfluff from the framework if it doesn't exist locally, and ensure correct versions are installed."""
        config_path = self.linting.project_dir / ".sqlfluff"
        if not config_path.exists():
            if not self.downloads:
                error_line("No .sqlfluff config found and download service not available")
                return False
            info_line("No .sqlfluff config found — downloading from framework...")
            if not self.downloads.download_sqlfluff_config(profiles_dir=self.profiles_dir):
                return False
        # Fetch pinned versions from the native app and ensure they're installed
        required = self.downloads.get_sqlfluff_requirements() if self.downloads else None
        return self.linting.ensure_templater_installed(required_packages=required or None)
    
    def _lint_menu(self) -> None:
        clear()
        display_action_header("SQLFluff Linting Options")
        menu_option(1, "find modified - Lint modified SQL files")
        menu_option(2, "fix modified  - Fix modified SQL files")
        menu_option(3, "find all      - Lint all SQL files")
        menu_option(4, "fix all       - Fix all SQL files")
        menu_option(5, "specific      - Lint specific file")
        menu_option(6, "install       - Install SQLFluff requirements from framework")
        menu_option(0, "back          - Return to development menu")
        option = get_input_number("Choose an option: ")
        if option in (1, 2, 3, 4, 5) and not self._ensure_sqlfluff_config():
            complete_action()
            return
        if option == 1:
            changed = [f.file for f in self.git.get_changed_files()] if self.git else []
            self.linting.lint_modified(fix=False, changed_files=changed)
        elif option == 2:
            changed = [f.file for f in self.git.get_changed_files()] if self.git else []
            self.linting.lint_modified(fix=True, changed_files=changed)
        elif option == 3:
            self.linting.lint_file(fix=False)
        elif option == 4:
            self.linting.lint_file(fix=True)
        elif option == 5:
            path = get_input_string("Enter file path: ")
            if path != "0":
                self.linting.lint_file(file_path=path, fix=False)
        elif option == 6:
            self._install_sqlfluff_requirements()
        complete_action()
    
    def _install_sqlfluff_requirements(self) -> None:
        """Install SQLFluff packages at versions defined by the framework."""
        if not self.downloads:
            error_line("Download service not available")
            return
        
        # Show current versions
        installed = self.linting.get_installed_versions()
        info_line("Currently installed:")
        for pkg, ver in installed.items():
            info_line(f"  {pkg}: {ver or 'not installed'}")
        
        # Fetch required versions from framework
        packages = self.downloads.get_sqlfluff_requirements()
        if not packages:
            return
        
        info_line("")
        info_line("Framework requires:")
        for pkg in packages:
            info_line(f"  {pkg}")
        
        info_line("")
        self.linting.install_requirements(packages)
