from pathlib import Path

from datasecops_cli.models.project_config import ProjectProfile, ProjectSettings
from datasecops_cli.services.download_service import DownloadService
from datasecops_cli.services.skill_service import SkillService
from datasecops_cli.services.dbt_runner import DbtRunner
from datasecops_cli.utilities.display import (
    clear, section_header, display_action_header, menu_option,
    get_input_number, get_input_true_false, complete_action,
    info_line, select_from_list
)


class DownloadsMenu:
    def __init__(self, download_service: DownloadService, skill_service: SkillService,
                 dbt_runner: DbtRunner, profile_name: str, dbt_project_dir: Path,
                 project_settings: ProjectSettings = None, profile: ProjectProfile = None):
        self.downloads = download_service
        self.skills = skill_service
        self.dbt = dbt_runner
        self.profile_name = profile_name
        self.dbt_project_dir = dbt_project_dir
        self.project_settings = project_settings
        self.profile = profile
    
    def show(self) -> None:
        self._menu()
        option = get_input_number("Choose an option: ")
        while option != 0:
            if option == 1:
                display_action_header("Download SQLFluff Config")
                profiles_dir = str(Path(self.project_settings.profile_dir).expanduser()) if self.project_settings else None
                self.downloads.download_sqlfluff_config(profiles_dir=profiles_dir)
                complete_action()
            elif option == 2:
                display_action_header("Download Pipeline Files")
                platform = select_from_list(["github", "azuredevops"], "platform", add_back=False)
                self.downloads.download_pipelines(platform=platform)
                complete_action()
            elif option == 3:
                display_action_header("Download dbt Packages")
                self.downloads.download_dbt_packages(self.dbt_project_dir)
                if get_input_true_false("Run dbt deps now?"):
                    self.dbt.deps()
                complete_action()
            elif option == 4:
                display_action_header("Download Macros")
                self.downloads.download_macros(self.profile_name, self.dbt_project_dir)
                complete_action()
            elif option == 5:
                self._skills_menu()
            elif option == 6:
                display_action_header("New dbt Project")
                self.downloads.init_dbt_project(
                    self.project_settings, self.profile
                )
                complete_action()
            self._menu()
            option = get_input_number("Choose an option: ")
    
    def _menu(self) -> None:
        clear()
        section_header("Downloads", self.profile_name)
        menu_option(1, "sqlfluff      - Download SQLFluff configuration")
        menu_option(2, "pipelines     - Download CI/CD pipeline files")
        menu_option(3, "dbt packages  - Download dbt package versions")
        menu_option(4, "macros        - Download default macros for this profile")
        menu_option(5, "skills        - Cortex Code skills")
        menu_option(6, "new project   - Initialize a new dbt project with framework profiles")
        menu_option(0, "back          - Return to main menu")
    
    def _skills_menu(self) -> None:
        clear()
        display_action_header("Cortex Code Skills")
        menu_option(1, "list          - List available skills")
        menu_option(2, "install       - Install a specific skill")
        menu_option(3, "install all   - Install all available skills")
        menu_option(4, "update        - Update installed skills")
        menu_option(0, "back          - Return to downloads menu")
        option = get_input_number("Choose an option: ")
        if option == 1:
            self.skills.list_skills()
        elif option == 2:
            available = self.skills.get_available_skills()
            if available:
                names = {s.name: s for s in available}
                selected = select_from_list(list(names.keys()), "skill")
                if selected != "back" and selected in names:
                    self.skills.install_skill(names[selected])
            else:
                info_line("No skills available")
        elif option == 3:
            self.skills.install_all()
        elif option == 4:
            self.skills.update_skills()
        complete_action()
