import sys
from pathlib import Path

from datasecops_cli.config import Config
from datasecops_cli.services.snowflake_service import SnowflakeService
from datasecops_cli.services.dbt_runner import DbtRunner
from datasecops_cli.services.git_service import GitService
from datasecops_cli.services.linting_service import LintingService
from datasecops_cli.services.download_service import DownloadService
from datasecops_cli.services.skill_service import SkillService
from datasecops_cli.services.bootstrap_service import BootstrapService
from datasecops_cli.menus.development import DevelopmentMenu
from datasecops_cli.menus.git_operations import GitOperationsMenu
from datasecops_cli.menus.downloads import DownloadsMenu
from datasecops_cli.utilities.display import (
    clear, section_header, menu_option, get_input_number,
    info_line, error_line, success_line
)


def main():
    """Main entry point for the datasecops CLI."""
    config = Config()

    # Handle 'bootstrap' subcommand
    if len(sys.argv) > 1 and sys.argv[1] == "bootstrap":
        _run_bootstrap(config)
        return

    if not config.load():
        sys.exit(1)
    
    # Connect to Snowflake
    sf_config = config.datasecops
    sf_service = SnowflakeService(sf_config)
    
    try:
        info_line(f"Connecting to Snowflake ({sf_config.connection_name})...")
        sf_service.connect()
        success_line("Connected")
    except Exception as e:
        error_line(f"Failed to connect to Snowflake: {e}")
        sys.exit(1)
    
    try:
        # Load config from native app
        info_line("Loading framework configuration...")
        config.load_from_native_app(sf_service)
        
        if not config.profile:
            error_line(f"Profile '{config.profile_name}' not found in native app")
            sys.exit(1)
        
        success_line(f"Profile: {config.profile.project_name} ({config.profile_name})")
        
        # Initialize services
        dbt_runner = DbtRunner(
            project_dir=config.dbt_project_dir,
            profiles_dir=config.get_dbt_profiles_dir(),
            target=config.project_settings.get_default_target().target_name if config.get_default_target() else "dev"
        )
        
        try:
            git_service = GitService(config.project_dir)
        except Exception:
            git_service = None
        
        linting_service = LintingService(config.dbt_project_dir)
        download_service = DownloadService(sf_service, config.project_dir)
        skill_service = SkillService(sf_service)
        
        # Main menu loop
        _main_menu(config, dbt_runner, git_service, linting_service, 
                    download_service, skill_service, sf_service)
    
    finally:
        sf_service.close()


def _main_menu(config: Config, dbt_runner: DbtRunner, git_service: GitService,
               linting_service: LintingService, download_service: DownloadService,
               skill_service: SkillService, sf_service: SnowflakeService):
    """Main menu loop."""
    profile_name = config.profile_name
    
    _show_main_menu(profile_name, git_service)
    option = get_input_number("Choose an option: ")
    
    while option != 0:
        if option == 1:
            profiles_dir = str(config.get_dbt_profiles_dir())
            if git_service:
                dev_menu = DevelopmentMenu(dbt_runner, linting_service, git_service, profile_name,
                                          download_service=download_service, profiles_dir=profiles_dir)
            else:
                dev_menu = DevelopmentMenu(dbt_runner, linting_service, None, profile_name,
                                          download_service=download_service, profiles_dir=profiles_dir)
            dev_menu.show()
        
        elif option == 2 and git_service:
            git_menu = GitOperationsMenu(
                git_service, config.source_control,
                config.get_deployment_branches(), profile_name
            )
            git_menu.show()
        
        elif option == 3:
            dl_menu = DownloadsMenu(
                download_service, skill_service, dbt_runner,
                profile_name, config.dbt_project_dir,
                project_settings=config.project_settings,
                profile=config.profile,
            )
            dl_menu.show()
        
        elif option == 4:
            from datasecops_cli.utilities.display import select_from_list, get_input_true_false
            platform = select_from_list(["github", "azuredevops"], "source control platform", add_back=False)
            install_skills = get_input_true_false("Install Cortex Code skills?")
            run_deps = get_input_true_false("Run dbt deps after downloading packages?")
            bootstrap = BootstrapService(
                snowflake_service=sf_service,
                project_dir=config.project_dir,
                project_settings=config.project_settings,
                profile=config.profile,
            )
            bootstrap.run(platform=platform, install_skills=install_skills, run_deps=run_deps)
        
        _show_main_menu(profile_name, git_service)
        option = get_input_number("Choose an option: ")
    
    info_line("Exiting DataSecOps Framework CLI")


def _show_main_menu(profile_name: str, git_service: GitService = None):
    clear()
    branch = git_service.get_current_branch() if git_service else None
    section_header("DataSecOps Framework CLI", profile_name, branch)
    menu_option(1, "development   - dbt Development Commands")
    menu_option(2, "git           - Source Control Operations")
    menu_option(3, "downloads     - Download Configs & Skills")
    menu_option(4, "bootstrap     - Set up a new dbt project with all framework config")
    menu_option(0, "exit          - Exit")


def _run_bootstrap(config: Config):
    """Run the bootstrap command to initialise a new project."""
    from datasecops_cli.utilities.display import select_from_list, get_input_true_false

    if not config.load():
        sys.exit(1)

    sf_config = config.datasecops
    sf_service = SnowflakeService(sf_config)

    try:
        info_line(f"Connecting to Snowflake ({sf_config.connection_name})...")
        sf_service.connect()
        success_line("Connected")
    except Exception as e:
        error_line(f"Failed to connect to Snowflake: {e}")
        sys.exit(1)

    try:
        info_line("Loading framework configuration...")
        config.load_from_native_app(sf_service)

        if not config.profile:
            error_line(f"Profile '{config.profile_name}' not found in native app")
            sys.exit(1)

        success_line(f"Profile: {config.profile.project_name} ({config.profile_name})")
        info_line("")

        # Ask for platform
        platform = select_from_list(["github", "azuredevops"], "source control platform", add_back=False)

        # Ask about optional steps
        install_skills = get_input_true_false("Install Cortex Code skills?")
        run_deps = get_input_true_false("Run dbt deps after downloading packages?")

        bootstrap = BootstrapService(
            snowflake_service=sf_service,
            project_dir=config.project_dir,
            project_settings=config.project_settings,
            profile=config.profile,
        )
        success = bootstrap.run(platform=platform, install_skills=install_skills, run_deps=run_deps)
        sys.exit(0 if success else 1)

    finally:
        sf_service.close()


if __name__ == "__main__":
    main()
