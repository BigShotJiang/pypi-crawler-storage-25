import subprocess
from pathlib import Path

from datasecops_cli.utilities.display import info_line, error_line, success_line, warning_line


class LintingService:
    """SQLFluff linting operations."""
    
    def __init__(self, project_dir: Path):
        self.project_dir = project_dir
    
    def get_installed_versions(self) -> dict[str, str]:
        """Get currently installed versions of sqlfluff packages."""
        versions = {}
        for package in ["sqlfluff", "sqlfluff-templater-dbt"]:
            result = subprocess.run(
                ["uv", "pip", "show", package],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    if line.startswith("Version:"):
                        versions[package] = line.split(":", 1)[1].strip()
                        break
            else:
                versions[package] = None
        return versions
    
    def install_requirements(self, packages: list[str]) -> bool:
        """Install sqlfluff packages at specified versions."""
        if not packages:
            warning_line("No packages to install")
            return False
        
        cmd = ["uv", "pip", "install"] + packages
        info_line(f"Installing: {', '.join(packages)}")
        result = subprocess.run(cmd, capture_output=False)
        if result.returncode == 0:
            success_line("SQLFluff requirements installed successfully")
            return True
        else:
            error_line(f"uv pip install failed with exit code {result.returncode}")
            return False
    
    def ensure_templater_installed(self, required_packages: list[str] = None) -> bool:
        """Check sqlfluff packages are installed at the required versions.
        
        Args:
            required_packages: Pinned packages from the framework, e.g. ["sqlfluff==3.4.0", "sqlfluff-templater-dbt==3.4.0"].
                               If None, just checks that the packages are present (any version).
        """
        installed = self.get_installed_versions()

        if required_packages:
            # Build a map of package -> required version from "pkg==ver" strings
            required: dict[str, str | None] = {}
            for spec in required_packages:
                if "==" in spec:
                    name, ver = spec.split("==", 1)
                    required[name] = ver
                else:
                    required[spec] = None

            to_install: list[str] = []
            for name, req_ver in required.items():
                cur_ver = installed.get(name)
                if not cur_ver:
                    to_install.append(f"{name}=={req_ver}" if req_ver else name)
                elif req_ver and cur_ver != req_ver:
                    info_line(f"  {name}: installed {cur_ver}, framework requires {req_ver}")
                    to_install.append(f"{name}=={req_ver}")

            if not to_install:
                return True
            return self.install_requirements(to_install)

        # No pinned versions — just ensure packages are present
        missing = [pkg for pkg in ["sqlfluff", "sqlfluff-templater-dbt"] if not installed.get(pkg)]
        if not missing:
            return True
        warning_line(f"Missing packages: {', '.join(missing)}")
        return self.install_requirements(missing)
    
    def lint_file(self, file_path: str = None, fix: bool = False) -> subprocess.CompletedProcess:
        action = "fix" if fix else "lint"
        cmd = ["sqlfluff", action]
        if file_path:
            cmd.append(file_path)
        else:
            cmd.append(str(self.project_dir / "models"))
        
        config_path = self.project_dir / ".sqlfluff"
        if config_path.exists():
            cmd += ["--config", str(config_path)]
        
        info_line(f"Running: sqlfluff {action}")
        result = subprocess.run(cmd, capture_output=False, cwd=str(self.project_dir))
        if result.returncode == 0:
            success_line(f"SQLFluff {action} completed — no issues found")
        elif result.returncode == 1 and not fix:
            info_line(f"SQLFluff {action} found linting issues")
        else:
            error_line(f"SQLFluff {action} failed with exit code {result.returncode}")
        return result
    
    def lint_modified(self, fix: bool = False, changed_files: list[str] = None) -> None:
        if not changed_files:
            info_line("No modified SQL files to lint")
            return
        
        sql_files = [f for f in changed_files if f.endswith(".sql")]
        if not sql_files:
            info_line("No modified SQL files to lint")
            return
        
        info_line(f"Linting {len(sql_files)} modified SQL file(s)...")
        for f in sql_files:
            self.lint_file(f, fix=fix)
