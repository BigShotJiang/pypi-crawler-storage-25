import subprocess
import shutil
from pathlib import Path
from typing import Optional

from datasecops_cli.utilities.display import info_line, error_line, success_line


class DbtRunner:
    """Runs dbt commands via subprocess (dbt Fusion)."""
    
    def __init__(self, project_dir: Path, profiles_dir: Path, target: str = "dev"):
        self.project_dir = project_dir
        self.profiles_dir = profiles_dir
        self.target = target
    
    def _default_args(self) -> list[str]:
        return [
            f"--project-dir={self.project_dir}",
            f"--profiles-dir={self.profiles_dir}",
        ]
    
    def _run_command(self, command: str, extra_args: list[str] = None) -> subprocess.CompletedProcess:
        cmd = ["dbt", command] + (extra_args or []) + self._default_args()
        info_line(f"Running: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=False)
        if result.returncode != 0:
            error_line(f"dbt {command} failed with exit code {result.returncode}")
        else:
            success_line(f"dbt {command} completed successfully")
        return result
    
    def run(self, select: str = None, exclude: str = None, full_refresh: bool = False,
            modified_only: bool = False) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if modified_only and (self.project_dir / "manifest.json").exists():
            args += ["--select", "state:modified+", "--state", str(self.project_dir)]
        elif select:
            args += ["--select", select]
        if exclude:
            args += ["--exclude", exclude]
        if full_refresh:
            args.append("--full-refresh")
        result = self._run_command("run", args)
        self._copy_manifest()
        return result
    
    def build(self, select: str = None, exclude: str = None) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if select:
            args += ["--select", select]
        if exclude:
            args += ["--exclude", exclude]
        result = self._run_command("build", args)
        self._copy_manifest()
        return result
    
    def test(self, select: str = None) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if select:
            args += ["--select", select]
        return self._run_command("test", args)
    
    def compile(self, select: str = None) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if select:
            args += ["--select", select]
        return self._run_command("compile", args)
    
    def deps(self) -> subprocess.CompletedProcess:
        return self._run_command("deps")
    
    def seed(self, select: str = None, full_refresh: bool = False) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if select:
            args += ["--select", select]
        if full_refresh:
            args.append("--full-refresh")
        return self._run_command("seed", args)
    
    def snapshot(self, select: str = None) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if select:
            args += ["--select", select]
        return self._run_command("snapshot", args)
    
    def source_freshness(self, select: str = None) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if select:
            args += ["--select", select]
        return self._run_command("source", ["freshness"] + args)
    
    def docs_generate(self) -> subprocess.CompletedProcess:
        return self._run_command("docs", ["generate", f"--target={self.target}"])
    
    def docs_serve(self) -> subprocess.Popen:
        cmd = ["dbt", "docs", "serve"] + self._default_args()
        info_line(f"Running: {' '.join(cmd)}")
        return subprocess.Popen(cmd)
    
    def clean(self) -> subprocess.CompletedProcess:
        return self._run_command("clean")
    
    def debug(self) -> subprocess.CompletedProcess:
        return self._run_command("debug", [f"--target={self.target}"])
    
    def list_models(self, select: str = None, resource_type: str = None) -> subprocess.CompletedProcess:
        args = [f"--target={self.target}"]
        if select:
            args += ["--select", select]
        if resource_type:
            args += ["--resource-type", resource_type]
        return self._run_command("list", args)
    
    def retry(self) -> subprocess.CompletedProcess:
        result = self._run_command("retry", [f"--target={self.target}"])
        self._copy_manifest()
        return result
    
    def run_operation(self, macro: str, args_str: str = None) -> subprocess.CompletedProcess:
        cmd_args = [f"--target={self.target}"]
        if args_str:
            cmd_args += ["--args", args_str]
        return self._run_command("run-operation", [macro] + cmd_args)
    
    def _copy_manifest(self) -> None:
        manifest = self.project_dir / "target" / "manifest.json"
        dest = self.project_dir / "manifest.json"
        if manifest.exists():
            shutil.copy2(manifest, dest)
