"""Bootstrap service - initialise a new dbt project with all framework configuration in one step."""

from pathlib import Path

from datasecops_cli.models.project_config import ProjectProfile, ProjectSettings
from datasecops_cli.services.snowflake_service import SnowflakeService
from datasecops_cli.services.download_service import DownloadService
from datasecops_cli.services.skill_service import SkillService
from datasecops_cli.services.dbt_runner import DbtRunner
from datasecops_cli.utilities.display import info_line, success_line, error_line, section_header


class BootstrapService:
    """Bootstraps a new dbt project with all framework configuration."""

    def __init__(self, snowflake_service: SnowflakeService, project_dir: Path,
                 project_settings: ProjectSettings, profile: ProjectProfile):
        self.sf = snowflake_service
        self.project_dir = project_dir
        self.project_settings = project_settings
        self.profile = profile
        self.download_service = DownloadService(snowflake_service, project_dir)
        self.skill_service = SkillService(snowflake_service)

    def run(self, platform: str = "github", install_skills: bool = True,
            run_deps: bool = True) -> bool:
        """Run the full bootstrap process.

        Args:
            platform: Source control platform - "github" or "azuredevops".
            install_skills: Whether to install Cortex Code skills.
            run_deps: Whether to run dbt deps after downloading packages.

        Returns True if all steps succeeded.
        """
        section_header("Bootstrap New dbt Project", self.profile.profile_name)
        info_line(f"Project: {self.profile.project_name}")
        info_line(f"Database: {self.profile.target_database}")
        info_line(f"Platform: {platform}")
        info_line("")

        steps_passed = 0
        total_steps = 6 + (1 if install_skills else 0) + (1 if run_deps else 0)

        # Step 1: Init dbt project
        info_line("[1] Initialising dbt project...")
        if not self.download_service.init_dbt_project(self.project_settings, self.profile):
            error_line("Bootstrap failed at: init dbt project")
            return False
        steps_passed += 1

        # Resolve the dbt project directory after init
        dbt_project_dir = self.project_dir
        for candidate in [self.project_dir / "dbt", self.project_dir]:
            if (candidate / "dbt_project.yml").exists():
                dbt_project_dir = candidate
                break

        # Step 2: Download default macros
        info_line("")
        info_line("[2] Downloading default macros...")
        if self.download_service.download_macros(self.profile.profile_name, dbt_project_dir):
            steps_passed += 1
        else:
            info_line("  (skipped - no macros configured for this profile)")
            steps_passed += 1

        # Step 3: Download SQLFluff config
        info_line("")
        info_line("[3] Downloading SQLFluff configuration...")
        profiles_dir = str(Path(self.project_settings.profile_dir).expanduser())
        if self.download_service.download_sqlfluff_config(profiles_dir=profiles_dir):
            steps_passed += 1
        else:
            info_line("  (skipped - no SQLFluff config in native app)")
            steps_passed += 1

        # Step 4: Download CI/CD pipelines
        info_line("")
        info_line(f"[4] Downloading {platform} pipeline files...")
        if self.download_service.download_pipelines(platform=platform):
            steps_passed += 1
        else:
            info_line("  (skipped - no pipeline config in native app)")
            steps_passed += 1

        # Step 5: Download dbt packages
        info_line("")
        info_line("[5] Downloading dbt packages...")
        if self.download_service.download_dbt_packages(dbt_project_dir):
            steps_passed += 1
        else:
            info_line("  (skipped - no dbt packages config in native app)")
            steps_passed += 1

        # Step 6: Run dbt deps
        if run_deps:
            info_line("")
            info_line("[6] Running dbt deps...")
            dbt_runner = DbtRunner(
                project_dir=dbt_project_dir,
                profiles_dir=Path(self.project_settings.profile_dir).expanduser(),
                target=self.project_settings.get_default_target().target_name if self.project_settings.get_default_target() else "dev"
            )
            result = dbt_runner.deps()
            if result.returncode == 0:
                steps_passed += 1
            else:
                info_line("  (dbt deps failed - run manually after fixing packages.yml)")
                steps_passed += 1

        # Step 7: Download SQLFluff requirements
        info_line("")
        step_num = 7 if run_deps else 6
        info_line(f"[{step_num}] Checking SQLFluff version requirements...")
        requirements = self.download_service.get_sqlfluff_requirements()
        if requirements:
            info_line(f"  Required: {', '.join(requirements)}")
            info_line("  (install with: uv pip install " + " ".join(requirements) + ")")
        steps_passed += 1

        # Step 8: Install Cortex Code skills
        if install_skills:
            info_line("")
            step_num += 1
            info_line(f"[{step_num}] Installing Cortex Code skills...")
            count = self.skill_service.install_all()
            steps_passed += 1

        # Done
        info_line("")
        success_line(f"Bootstrap complete! ({steps_passed}/{total_steps} steps passed)")
        info_line("")
        info_line("Your project is ready. Next steps:")
        info_line(f"  cd {dbt_project_dir}")
        info_line("  datasecops          — run the framework CLI")
        info_line("  dbt debug           — verify Snowflake connection")
        info_line("  dbt run             — run your first models")
        info_line("")
        return True
