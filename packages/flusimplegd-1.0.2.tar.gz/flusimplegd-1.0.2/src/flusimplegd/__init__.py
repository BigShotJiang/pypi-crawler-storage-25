from .core import (
    code,
    code_file
)

__version__ = "1.0.2"
__author__ = "Flu3f"