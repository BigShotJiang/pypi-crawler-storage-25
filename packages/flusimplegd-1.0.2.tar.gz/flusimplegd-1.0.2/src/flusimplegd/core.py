"""Stack Machine"""

## Errors

class GoToError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class MathError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')
    
class CycleError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class AddressError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class IfError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class QuantityError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class DefineError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class VariableError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class FormatError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

## Lexer

class Lexer:
    def __init__(self, data):
        self.data = data
    
    @property
    def form(self):
        result = []
        
        for line in self.data.strip().split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                string_val = parts[0]
                second_val = parts[1]
                
                if second_val.startswith('(') and second_val.endswith(')'):
                    tuple_content = second_val[1:-1].strip()
                    if tuple_content:
                        tuple_parts = []
                        current_part = []
                        in_quotes = False
                        quote_char = None
                        
                        for char in tuple_content:
                            if char in ('"', "'") and not in_quotes:
                                in_quotes = True
                                quote_char = char
                                current_part.append(char)
                            elif char == quote_char and in_quotes:
                                in_quotes = False
                                quote_char = None
                                current_part.append(char)
                            elif char == ',' and not in_quotes:
                                part = ''.join(current_part).strip()
                                tuple_parts.append(part)
                                current_part = []
                            else:
                                current_part.append(char)
                        
                        if current_part:
                            part = ''.join(current_part).strip()
                            tuple_parts.append(part)
                        
                        converted = []
                        for p in tuple_parts:
                            if (p.startswith('"') and p.endswith('"')) or (p.startswith("'") and p.endswith("'")):
                                converted.append(p[1:-1])
                            else:
                                try:
                                    num = float(p)
                                    if num.is_integer():
                                        num = int(num)
                                    converted.append(num)
                                except ValueError:
                                    converted.append(p)
                        
                        second_val = converted
                    else:
                        second_val = []
                
                else:
                    try:
                        number_val = float(second_val)
                        if number_val.is_integer():
                            number_val = int(number_val)
                        second_val = number_val
                    except ValueError:
                        pass
                
                result.append(string_val)
                result.append(second_val)
            else:
                raise QuantityError(f'Invalid line format: {line}')
        
        return result
    
    @property
    def start(self):
        result = []
        if len(self.data) % 2 != 0:
            raise QuantityError(f'There is an unfinished "Operation-Value" pair in the code')
        for i in range(0, len(self.data), 2):
            result.append([self.data[i], self.data[i+1]])
        return result

## Operations

change_list = ['change', 'jump', 'to', 'goto']
add_list = ['add', 'plus', 'sum']
sub_list = ['sub', 'subtract', 'minus']
copy_list = ['copy', 'move']
set_list = ['set', 'make']
output_list = ['output', 'print', 'write']
cycle_start_list = ['[', 'cycle_start']
cycle_end_list = [']', 'cycle_end']
if_list = ['if', 'when']
def_start_list = ['fun', 'function', 'op', 'operation', 'def']
def_end_list = ['fun_end', 'end', 'op_end']
read_list = ['read', 'check', 'var']
input_list = ['input']  # <--- БЕЗ STOP

# Все встроенные операции (БЕЗ STOP)
ALL_BUILTIN_OPS = (change_list + add_list + sub_list + copy_list + set_list + 
                   output_list + cycle_start_list + cycle_end_list + if_list + 
                   def_start_list + def_end_list + read_list + input_list)

## Parser

class Parser:
    def __init__(self, data, len, num_cells=6):
        if num_cells < 1 or not isinstance(num_cells, int):
            raise QuantityError(f'The number of cells must be natural and greater than 1')
        self.data = data
        self.current_cell = 1
        self.pos = 1
        self.cells = [0 for i in range(num_cells)]
        self.output = []
        self.cycles = [[] for i in range(len)]
        self.code_len = len
        self.address_to = -1
        self.num_cells = num_cells
        self.fun_names = []
        self.fun_pos = []
        self.read_def = False
        self.num_op = 0
        self.value = []
        self.in_fun = False
        self.call_stack = []
        self.value_stack = []
        self.cell_stack = []  # Стек для current_cell
        self.variables = {}

    def to(self, address_to=-1):
        if address_to == -1:
            self.pos += 1
        elif address_to == -2:
            self.pos -= 1
        else:
            self.pos = address_to
    
    def get_value(self, value):
        """Получение значения из числа, переменной или val-аргумента"""
        if isinstance(value, list):
            return [self.get_value(v) for v in value]
        
        if isinstance(value, str):
            if value.startswith('val'):
                try:
                    return self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements in val stack')
            elif value in self.variables:
                return self.variables[value]
        return value
    
    @property
    def do(self):
        operation = self.data[self.pos-1][0]
        value = self.data[self.pos-1][1]
        
        resolved_value = self.get_value(value)
        
        if operation in change_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Cell number must be a number, got {type(resolved_value)}')
            if 1 <= resolved_value <= self.num_cells:
                self.current_cell = int(resolved_value)
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')

        elif operation in add_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Cannot add non-numeric value: {resolved_value}')
            if resolved_value >= 0:
                self.cells[self.current_cell-1] += resolved_value
            else:
                if resolved_value < -self.num_cells:
                    raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
                self.cells[self.current_cell-1] += self.cells[-1-int(resolved_value)]

        elif operation in sub_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Cannot subtract non-numeric value: {resolved_value}')
            if resolved_value >= 0:
                self.cells[self.current_cell-1] -= resolved_value
            else:
                if resolved_value < -self.num_cells:
                    raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
                self.cells[self.current_cell-1] -= self.cells[-1-int(resolved_value)]
        
        elif operation in copy_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Cell number must be a number, got {type(resolved_value)}')
            if self.num_cells >= resolved_value >= 1:
                self.cells[int(resolved_value)-1] = self.cells[self.current_cell-1]
            elif -self.num_cells <= resolved_value <= -1:
                self.cells[self.current_cell-1] = self.cells[-int(resolved_value)-1]
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
        
        elif operation in set_list:
            self.cells[self.current_cell-1] = resolved_value
        
        elif operation in output_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Cell number must be a number, got {type(resolved_value)}')
            if 1 <= resolved_value <= self.num_cells:
                self.output.append(self.cells[int(resolved_value)-1])
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
        
        elif operation in cycle_start_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Cycle count must be a number, got {type(resolved_value)}')
            if resolved_value < -2:
                raise CycleError(f'Cannot repeat the cycle {resolved_value} times')
            
            if resolved_value > 0:
                self.cycles[self.pos-1] = [int(resolved_value)]
            elif resolved_value == 0:
                self.cycles[self.pos-1] = ['=']
            elif resolved_value == -1:
                self.cycles[self.pos-1] = ['>']
            elif resolved_value == -2:
                self.cycles[self.pos-1] = ['<']
        
        elif operation in cycle_end_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Address must be a number, got {type(resolved_value)}')
            if resolved_value > self.code_len or resolved_value < 1:
                raise AddressError(f'Cannot go beyond the code boundary')
            
            if int(resolved_value)-1 >= len(self.cycles):
                raise CycleError(f'Cycle start not found at address {resolved_value}')
            
            cycle_data = self.cycles[int(resolved_value)-1]
            if not cycle_data:
                raise CycleError(f'Cycle not initialized at address {resolved_value}')
            
            cycle_type = cycle_data[0]
            
            if cycle_type == '=':
                if self.cells[self.current_cell-1] == 0:
                    self.address_to = -1
                else:
                    self.address_to = int(resolved_value)+1
            elif cycle_type == '>':
                if self.cells[self.current_cell-1] > 0:
                    self.address_to = -1
                else:
                    self.address_to = int(resolved_value)+1
            elif cycle_type == '<':
                if self.cells[self.current_cell-1] < 0:
                    self.address_to = -1
                else:
                    self.address_to = int(resolved_value)+1
            else:
                if cycle_type > 1:
                    self.address_to = int(resolved_value)+1
                    self.cycles[int(resolved_value)-1][0] -= 1
                else:
                    self.address_to = -1
        
        elif operation in if_list:
            # if =N   -> переход, если ячейка == 0
            # if +N   -> переход, если ячейка > 0
            # if -N   -> переход, если ячейка < 0
            
            if isinstance(value, str) and value.startswith('='):
                target = int(value[1:])
                if not (1 <= target <= self.code_len):
                    raise AddressError(f'Cannot go beyond the code boundary. Address: {target}')
                if self.cells[self.current_cell-1] == 0:
                    self.address_to = target
                else:
                    self.address_to = -1
            
            else:
                if not isinstance(resolved_value, (int, float)):
                    raise MathError(f'Address must be a number, got {type(resolved_value)}')
                
                target = abs(int(resolved_value))
                if not (1 <= target <= self.code_len):
                    raise AddressError(f'Cannot go beyond the code boundary. Address: {target}')
                
                if resolved_value > 0 and self.cells[self.current_cell-1] > 0:
                    self.address_to = target
                elif resolved_value < 0 and self.cells[self.current_cell-1] < 0:
                    self.address_to = target
                else:
                    self.address_to = -1
        
        elif operation in read_list:
            if not isinstance(value, str):
                raise VariableError(f'Variable name must be a string, got {type(value)}')
            
            if value.startswith('val'):
                raise VariableError(f'Variable name cannot start with "val" (reserved for function arguments)')
            
            if value in ALL_BUILTIN_OPS:
                raise VariableError(f'Cannot use reserved word "{value}" as variable name')
            
            self.variables[value] = self.cells[self.current_cell-1]
        
        elif operation in def_start_list:
            if not self.in_fun:
                if value in (self.fun_names + ALL_BUILTIN_OPS):
                    raise NameError(f'Operation "{value}" already exists')
                self.fun_names.append(value)
                self.fun_pos.append(self.pos+1)
                self.read_def = True
            else:
                raise DefineError(f'Cannot define function inside another function')

        elif operation in def_end_list:
            if self.call_stack:
                self.address_to = self.call_stack.pop()
                self.value = self.value_stack.pop() if self.value_stack else []
                self.current_cell = self.cell_stack.pop() if self.cell_stack else 1
                self.in_fun = False
            else:
                self.address_to = -1
                self.in_fun = False
                self.value = []

        elif operation in self.fun_names:
            self.call_stack.append(self.pos + 1)
            self.value_stack.append(self.value.copy() if self.value else [])
            self.cell_stack.append(self.current_cell)
            
            self.num_op = self.pos
            self.address_to = self.fun_pos[self.fun_names.index(operation)]
            
            if not isinstance(value, list):
                args = [value]
            else:
                args = value
            
            new_value = []
            for arg in args:
                resolved_arg = self.get_value(arg)
                new_value.append(resolved_arg)
            self.value = new_value
            
            self.in_fun = True

        elif operation in input_list:
            if not isinstance(resolved_value, (int, float)):
                raise MathError(f'Address must be a number, got {type(resolved_value)}')
            if 1 <= resolved_value <= self.num_cells:
                self.cells[int(resolved_value)-1] = int(input('Input: '))
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')

        else:
            raise NameError(f'Invalid operation name: {operation}')

    @property    
    def start(self):
        while self.pos <= self.code_len:
            self.do
            if self.read_def:
                while not self.data[self.pos-1][0] in def_end_list:
                    self.to()
                self.read_def = False
            self.to(self.address_to)
            self.address_to = -1
        for i in range(self.num_cells-1, -1, -1):
            print(f'C:{i+1}: {self.cells[i]}')
        print(f'Output: {self.output}')

def code_file(num_cells=10):
    with open('C:/Users/nikita/Documents/Никита/FluSimpleGD/FluSimpleGD v.1.0.2/src/flusimplegd/code.txt', 'r', encoding='utf-8') as file:
        code_str = file.read()
    lexer = Lexer(code_str)
    formatted = lexer.form
    start = Lexer(formatted).start
    Parser(start, len(start), num_cells).start

def code(code_str, num_cells=10):
    lexer = Lexer(code_str)
    formatted = lexer.form
    start = Lexer(formatted).start
    Parser(start, len(start), num_cells).start