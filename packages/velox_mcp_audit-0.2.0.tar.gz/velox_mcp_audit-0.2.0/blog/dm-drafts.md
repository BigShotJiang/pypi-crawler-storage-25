# DM Drafts — mcp-scan launch

Target: AI security researchers / practitioners who've published on MCP, agent security, or tool-use attacks.

---

## DM 1 — To someone who published MCP attack research (e.g., Trail of Bits researcher)

> Hey [name] — loved the line-jumping writeup. We built an open-source scanner that catches exactly that pattern (ANSI-hidden payloads in tool descriptions) plus 5 other MCP server checks — path traversal, shell injection, SSRF with dataflow-tracked guards, hardcoded secrets.
>
> Ships with a deliberately vulnerable MCP server so you can see what it catches in 30 seconds: github.com/veloxlabsio/mcp-audit
>
> Would genuinely appreciate any feedback — especially on the SSRF guard detection, which took 6 review rounds to get right.

---

## DM 2 — To someone building MCP tooling (e.g., Invariant Labs, Docker MCP team)

> Hey [name] — we just shipped mcp-scan, an open-source security scanner for MCP servers. Different angle from [their tool] — ours does AST-level source analysis (path traversal, shell injection, SSRF sinks) on top of the protocol-level description checks.
>
> Deliberately designed to complement, not compete — we cite your work in our docs. Thought you might find the SSRF dataflow tracking interesting: traces url → urlparse → hostname membership with fail-closed container trust.
>
> github.com/veloxlabsio/mcp-audit — feedback welcome.

---

## DM 3 — To an AI security content creator / newsletter author

> Hey [name] — just open-sourced mcp-scan, a security scanner for MCP servers. 6 deterministic checks (no LLM required), catches the Trail of Bits line-jumping attack + EscapeRoute CVEs + Anthropic Git MCP injection.
>
> Ships with a reference vulnerable server — 5 planted vulns, all caught, zero false positives. pip install velox-mcp-scan and try it in 30 seconds.
>
> Thought it might be relevant for [their newsletter/channel]. Happy to share more context if useful.

---

## DM 4 — To a platform engineer running MCP in production

> Hey [name] — saw your post about running MCP servers in [prod/staging]. We just shipped an open-source scanner that checks MCP servers for the common security issues — prompt injection in descriptions, path traversal, shell injection, SSRF, hardcoded secrets.
>
> All deterministic AST analysis, no cloud calls, runs in 2 seconds, non-zero exit on findings so it drops into CI. github.com/veloxlabsio/mcp-audit
>
> Would be curious if you find it useful — or if there are checks you'd want that we haven't built yet.

---

## DM 5 — To an AI security researcher / academic

> Hey [name] — we built an open-source MCP security scanner and tried to do the SSRF guard detection properly — dataflow tracking from URL variables through urlparse to hostname membership checks, with fail-closed container trust analysis.
>
> The interesting part is what doesn't count: urlparse alone, equality comparisons, membership against function parameters or attribute containers. 4 documented limitations where AST-level analysis can't go further.
>
> Paper and code: github.com/veloxlabsio/mcp-audit. Would value your perspective on the detection model — especially if there are bypass patterns we missed.

---

## Who to send these to (research targets)

1. **Trail of Bits** — Caleb Fenton or whoever wrote the line-jumping / ANSI posts
2. **Invariant Labs** — they built mcp-scan (the other one), tool poisoning research
3. **Simon Willison** — wrote the "lethal trifecta" post on SSRF + MCP
4. **Eknath / LLM security Twitter** — active in agent security discourse
5. **Practical AI security newsletter** — or equivalent content aggregator

Personalize each DM with their specific work. Never send the template verbatim.
