import json
import warnings

from typing_extensions import deprecated
from typing import Union, Literal, get_args, Annotated, Any, Optional
from pydantic import BaseModel, Field, TypeAdapter
from .types import E164PhoneNumber

class BaseEvent(BaseModel):
    sequence: int | None = None

@deprecated("This event is no longer used, but retained for comaptibility with older SDK versions.")
class OutboundSessionStartedEvent(BaseEvent):
    event_type: Literal["session-started"] = "session-started"
    session_id: str


class InboundCallEvent(BaseEvent):
    event_type: Literal["inbound-call"] = "inbound-call"
    caller_number: Optional[E164PhoneNumber] = None
    agent_number: Optional[E164PhoneNumber] = None

class SocketHealthEvent(BaseEvent):
    event_type: Literal["socket-health"] = "socket-health"


class CallerSpeechEvent(BaseEvent):
    """
    The caller has said something.
    For utterances with the same id,
    All but the latest is out of date.
    """

    event_type: Literal["caller-speech"] = "caller-speech"
    utterance: str
    utterance_id: Optional[str] = None


class AgentSpeechEvent(BaseEvent):
    """The agent has said something."""

    event_type: Literal["agent-speech"] = "agent-speech"
    utterance: str
    interrupted: bool = False


class ErrorEvent(BaseEvent):
    """An error happened during the call."""

    event_type: Literal["error"] = "error"
    content: str


class WarningEvent(BaseEvent):
    """A warning happened during the call."""

    event_type: Literal["warning"] = "warning"
    content: str


class AgentQuestionEvent(BaseEvent):
    """
    The caller has asked the agent a question that it cannot answer.
    The question is being relayed to the developer's system.
    Expects an `AnswerQuestionCommand` in return.
    """

    event_type: Literal["agent-question"] = "agent-question"
    question_id: str
    question: str

class IntentEvent(BaseEvent):
    """
    The caller declared an intent or requested some new task or action that they need help doing.
    The intent is being relayed to the developer's system.
    """
    event_type: Literal["intent"] = "intent"
    intent_id: str
    intent_summary: str

class ActionRequestEvent(BaseEvent):
    """
    The caller declared an intent or requested some new task or action that they need help doing.
    The intent is being relayed to the developer's system.
    Expects an `ActionSuggestionCommand` in return.
    """
    event_type: Literal["action-request"] = "action-request"
    intent_id: str
    intent_summary: str

class ActionItemCompletedEvent(BaseEvent):
    event_type: Literal["action-item-done"] = "action-item-done"
    key: str
    payload: Any # will be the attributes in GuavaField model in smoothbrain/fields.py

class TaskCompletedEvent(BaseEvent):
    event_type: Literal["task-done"] = "task-done"
    task_id : str

class ExecuteActionEvent(BaseEvent):
    event_type: Literal["execute-action"] = "execute-action"
    action_key: str

class OutboundCallConnected(BaseEvent):
    event_type: Literal["outbound-call-connected"] = "outbound-call-connected"
    
class OutboundCallFailed(BaseEvent):
    event_type: Literal["outbound-call-failed"] = "outbound-call-failed"
    error_code: int
    error_reason: str


class BotSessionEnded(BaseEvent):
    event_type: Literal["bot-session-ended"] = "bot-session-ended"
    termination_reason: Literal["user-hangup", "bot-hangup", "bot-failure", "bot-transfer"]

class ChoiceQueryEvent(BaseEvent):
    event_type: Literal["choice-query"] = "choice-query"
    field_key: str
    query: str
    query_id: str

class EscalateEvent(BaseEvent):
    event_type: Literal['escalate'] = 'escalate'
    requested_by: Literal['human', 'agent'] = 'human'


Event = Annotated[
    Union[
        OutboundSessionStartedEvent,
        CallerSpeechEvent,
        AgentSpeechEvent,
        ErrorEvent,
        WarningEvent,
        AgentQuestionEvent,
        IntentEvent,
        ActionRequestEvent,
        ExecuteActionEvent,
        InboundCallEvent,
        TaskCompletedEvent,
        ActionItemCompletedEvent,
        OutboundCallConnected,
        OutboundCallFailed,
        BotSessionEnded,
        ChoiceQueryEvent,
        SocketHealthEvent,
        EscalateEvent,
    ],
    Field(discriminator="event_type"),
]

# Known event types for this version of the SDK.
_KNOWN_EVENT_TYPES = {
    get_args(event_type.model_fields["event_type"].annotation)[0]
    for event_type in get_args(get_args(Event)[0])
}

def decode_event(serialized_event: str | bytes) -> Optional[Event]:
    event_dict = json.loads(serialized_event)
    return decode_event_dict(event_dict)

def decode_event_dict(event_dict: dict) -> Optional[Event]:
    assert "event_type" in event_dict, "Missing event_type in event data"
    
    if event_dict["event_type"] not in _KNOWN_EVENT_TYPES:
        warnings.warn(
            f"Received an unknown event type {event_dict['event_type']}. Update to a newer version of this SDK, or suppress this warning."
        )
        return None

    return TypeAdapter(Event).validate_python(event_dict)

class InboundTunnelEvent(BaseModel):
    call_id: str
    event: Event
