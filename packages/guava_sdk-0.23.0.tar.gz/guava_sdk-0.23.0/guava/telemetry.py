import os
import time
import queue
import httpx
import threading
import inspect
import functools
import atexit
import logging

from typing import Tuple
from urllib.parse import urljoin
from enum import Enum
from .utils import get_base_url, NoOpLogger, check_response

if os.getenv("GUAVA_DEBUG_TELEMETRY", "false").lower().strip() in ['yes', 'true']:
    logger = logging.getLogger("guava.telemetry")
else:
    logger = NoOpLogger()

class TelemetryEvent(str, Enum):
    METHOD_CALL = "method-call"
    EXCEPTION_RAISED = "exception-raised"

class BaseTelemetryClient:
    def __init__(self):
        self._sdk_headers = {}

    def send_event(self, event: TelemetryEvent, data: dict = {}):
        raise NotImplementedError()
    
    def _wrap_callable(self, func, track_calls: bool = True):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                if track_calls:
                    self.send_event(TelemetryEvent.METHOD_CALL, {
                        "function_name": func.__qualname__,
                    })
                return func(*args, **kwargs)
            except Exception as e:
                self.send_event(TelemetryEvent.EXCEPTION_RAISED, {
                    "function_name": func.__qualname__,
                    "exception": repr(e),
                })
                raise
            
        return wrapper
        
    def track_class(self, only_exceptions: set[str] = set()):
        def decorator(cls):
            for name, value in list(vars(cls).items()):
                track_calls = name not in only_exceptions
                
                # Instrument calls to __init__
                if name in {"__init__"}:
                    setattr(cls, name, self._wrap_callable(value, track_calls=track_calls))
                    continue

                # Skip private and other dunder methods.
                if name.startswith("_"):
                    continue

                # Skip static and class methods.
                if isinstance(value, staticmethod) or isinstance(value, classmethod):
                    continue

                # Regular function defined on the class
                if inspect.isfunction(value):
                    setattr(cls, name, self._wrap_callable(value, track_calls=track_calls))
                    continue

            return cls
        
        return decorator
    
    def set_sdk_headers(self, sdk_headers: dict):
        self._sdk_headers = sdk_headers
    

class TelemetryClient(BaseTelemetryClient):
    QUEUE_MAX_SIZE = 100 # TODO: Maybe we could do reservoir sampling?
    UPLOAD_INTERVAL_SECONDS = 10
    
    def __init__(self):
        super().__init__()

        self._base_url = get_base_url()
        self._event_queue: queue.Queue[Tuple[int, TelemetryEvent, dict]] = queue.Queue(maxsize=TelemetryClient.QUEUE_MAX_SIZE)
        self._upload_thread = threading.Thread(target=self._upload_events, daemon=True)
        self._shutdown_event = threading.Event()
        self._upload_thread.start()
        
    def _get_telemetry_endpoint(self) -> str:
        return urljoin(self._base_url, "v1/upload-telemetry")
        
    def _get_timestamp_ms(self) -> int:
        return int(time.time() * 1000)
    
    def _prepare_payload(self) -> list[dict]:
        json_payload = []
        
        while True:
            try:
                timestamp_ms, event, data = self._event_queue.get_nowait()
            except queue.Empty:
                break
            
            json_payload.append({
                "timestamp_ms": timestamp_ms,
                "event_type": event,
                "data": data
            })
            
        return json_payload
    
    def _upload_events(self):
        logger.debug("Starting telemetry upload thread...")

        while not self._shutdown_event.is_set():
            self._shutdown_event.wait(timeout=TelemetryClient.UPLOAD_INTERVAL_SECONDS)

            try:
                payload = self._prepare_payload()
                if payload:
                    logger.debug("Uploading %d telemetry events.", len(payload))
                    r = httpx.post(self._get_telemetry_endpoint(), headers=self._sdk_headers,
                        json={ 'events': payload })
                    check_response(r)
                else:
                    logger.debug("No events to upload.")
            except Exception:
                logger.exception("Telemetry upload failed.")
                pass

        logger.debug("Ending telemetry upload thread...")
                
    def send_event(self, event: TelemetryEvent, data: dict = {}):
        try:
            logger.debug("Sending telemetry event %s, %r", event, data)
            self._event_queue.put_nowait((self._get_timestamp_ms(), event, data))
        except queue.Full:
            # Just drop events if the queue is full.
            pass

    def shutdown(self):
        self._shutdown_event.set()
        self._upload_thread.join()
        
class NoOpTelemetryClient(BaseTelemetryClient):
    def send_event(self, event: TelemetryEvent, data: dict = {}): pass
    
    
# Initalize the global telemetry client based off an env variable.
if os.getenv("GUAVA_DISABLE_TELEMETRY", "false").lower().strip() in ['yes', 'true']:
    telemetry_client = NoOpTelemetryClient()
else:
    telemetry_client = TelemetryClient()
    atexit.register(telemetry_client.shutdown)