import os
import sys
import logging
import logging.config
import warnings

from typing import Any

ANSI_RESET = "\x1b[0m"
ANSI_GRAY = "\x1b[38;5;245m"
ANSI_BLUE = "\x1b[38;5;39m"
ANSI_ORANGE = "\x1b[38;5;214m"
ANSI_RED = "\x1b[38;5;196m"
ANSI_BOLD_RED = "\x1b[1;38;5;196m"

LEVEL_COLORS = {
    "DEBUG": ANSI_GRAY,
    "INFO": "",
    "WARNING": ANSI_ORANGE,
    "ERROR": ANSI_RED,
    "CRITICAL": ANSI_BOLD_RED,
}

class ColorFormatter(logging.Formatter):
    def __init__(self, fmt: str, datefmt: str = "%H:%M:%S", use_color: bool = True):
        super().__init__(fmt=fmt, datefmt=datefmt)
        self.use_color = use_color

    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        if not self.use_color:
            return msg
        color = LEVEL_COLORS.get(record.levelname, "")
        return f"{color}{msg}{ANSI_RESET}" if color else msg
    

def format_warning(message: Any, category: Any, filename: Any, lineno: Any, line: Any = None) -> str:
    short_file = filename.split("/")[-1]
    return f"{category.__name__}: {message} ({short_file}:{lineno})"

def configure_logging():
    level = os.getenv("LOG_LEVEL", "INFO").upper()
    if level not in LEVEL_COLORS.keys():
        raise ValueError(f"Unknown log level: {level}")

    use_color = sys.stderr.isatty() and os.getenv("NO_COLOR") is None
    
    warnings.formatwarning = format_warning # type: ignore

    logging.captureWarnings(True)
    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "pretty": {
                    "()": ColorFormatter,
                    "fmt": "[%(levelname)-5s %(asctime)s] (%(name)s) %(filename)s:%(lineno)d - %(message)s",
                    "use_color": use_color,
                },
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": level,
                    "formatter": "pretty",
                    "stream": "ext://sys.stderr",
                }
            },
            "root": {"level": level, "handlers": ["console"]},
            "loggers": {
                "httpx": {"level": "WARNING"},
                "aioice":  {"level": "WARNING"},
            },
        }
    )