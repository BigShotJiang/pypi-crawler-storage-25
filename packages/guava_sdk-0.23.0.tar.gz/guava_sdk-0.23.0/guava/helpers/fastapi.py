import asyncio
import logging
import secrets
from typing import Type, TypeVar
import threading

from fastapi import APIRouter, HTTPException, WebSocket
from guava.commands import Command
from guava.events import Event, decode_event
from starlette.websockets import WebSocketState

from guava import CallController
from guava.call_controller import CommandQueueEnd

U = TypeVar("U", bound=CallController)


def create_router(
    controller_class: Type[U], inbound_token: str, path: str = "/inbound-call"
) -> APIRouter:
    router = APIRouter(tags=["guava"])
    logger = logging.getLogger("guava.fastapi")

    @router.websocket("/inbound-call")
    async def inbound_call(websocket: WebSocket):
        logger.info("Received inbound WebSocket connection. Verifying token...")

        # Verify authorization header.
        authorization = websocket.headers.get("Authorization", None)
        if not authorization:
            raise HTTPException(status_code=401, detail="Authorization header required.")

        auth_parts = authorization.split()
        if auth_parts[0].lower() != "bearer":
            raise HTTPException(status_code=401, detail="Only bearer auth is supported.")

        if len(auth_parts) != 2:
            raise HTTPException(status_code=401, detail="Malformed bearer auth.")

        if not secrets.compare_digest(auth_parts[1], inbound_token):
            raise HTTPException(status_code=401, detail="Invalid token.")

        await websocket.accept()
        call_controller = controller_class()

        async def process_events() -> None:
            while websocket.client_state == WebSocketState.CONNECTED:
                try:
                    serialized_data = await websocket.receive_text()
                    event: Event | None = decode_event(serialized_data)
                    if event is not None:
                        threading.Thread(
                            target=call_controller.on_event, daemon=True, args=(event,)
                        ).start()
                except Exception:
                    logger.exception("Error processing event")
                    break

        async def process_commands() -> None:
            while websocket.client_state == WebSocketState.CONNECTED:
                try:
                    command: Command | CommandQueueEnd = await asyncio.to_thread(
                        call_controller._command_queue.get
                    )
                    if isinstance(command, CommandQueueEnd):
                        logger.debug("Queue has been shut down. Ending command drain loop.")
                        break

                    await websocket.send_text(command.model_dump_json())
                    call_controller._command_queue.task_done()
                except Exception:
                    logger.exception("Error sending command")
                    break

        try:
            await asyncio.gather(process_events(), process_commands())
        finally:
            call_controller.shutdown()
            if websocket.client_state == WebSocketState.CONNECTED:
                await websocket.close()

    return router
