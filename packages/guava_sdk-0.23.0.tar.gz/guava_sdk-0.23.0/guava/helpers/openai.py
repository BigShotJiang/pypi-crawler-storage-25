import time
import openai
import logging
import hashlib
from datetime import date
from pydantic import create_model, Field
from typing import Optional, Literal
from . import beta
from guava.telemetry import telemetry_client

logger = logging.getLogger("guava.helpers.openai")


@telemetry_client.track_class()
class IntentRecognizer:
    def __init__(
        self,
        intent_choices: list[str] | dict[str, str],
        client: Optional[openai.OpenAI] = None,
    ):
        if client:
            self.client = client
        else:
            # TODO: Remove after beta.
            logger.debug("Creating beta OpenAI client.")
            self.client = beta.create_openai_client()

        self.intent_choices = intent_choices
        self.choice_model = create_model(
            "ChoiceModel",
            caller_choice=(
                Optional[Literal[tuple([x for x in intent_choices])]],  # type: ignore
                Field(
                    ...,
                    description="The choice in the list best matching the caller's request.",
                ),
            ),
            __config__={"extra": "forbid"},
        )

    def classify(self, intent: str) -> str:
        input_prompt = f"""
Pick the choice in the list of choices that best reflects the given intent.
Intent: "{intent}".
Possible Choices: {[x for x in self.intent_choices]}.
"""
        if isinstance(self.intent_choices, dict):
            description_string = "\n  ".join(
                [f"{key}: {val}" for key, val in self.intent_choices.items()]
            )
            input_prompt += f"""Detailed descriptions of each choice: \n  {description_string}"""

        response = self.client.responses.parse(
            model="gpt-5-mini",
            input=input_prompt.strip(),
            text_format=self.choice_model,  # type: ignore
            reasoning={"effort": "low"},
        )
        return response.output_parsed.caller_choice  # type: ignore


@telemetry_client.track_class()
class IntentClarifier:
    def __init__(
        self,
        intent_choices: list[str] | dict[str, str],
        client: Optional[openai.OpenAI] = None,
    ):
        if client:
            self.client = client
        else:
            # TODO: Remove after beta.
            logger.debug("Creating beta OpenAI client.")
            self.client = beta.create_openai_client()

        self.intent_choices = intent_choices

        # Create a dynamic model that allows a list of choices
        choice_list = [x for x in intent_choices]
        self.clarification_model = create_model(
            "ClarificationModel",
            possible_matches=(
                list[Literal[tuple(choice_list)]],  # type: ignore
                Field(
                    ...,
                    description="A list of choices that could match the caller's intent, ordered by likelihood. Include all plausible matches.",
                ),
            ),
            reasoning=(
                Optional[str],
                Field(
                    None,
                    description="Brief explanation of why these choices were selected.",
                ),
            ),
            __config__={"extra": "forbid"},
        )

    def propose_choices(self, intent: str) -> list[str]:
        """
        Analyzes the given intent and returns a subset of choices that could match.

        Args:
            intent: The user's intent/request to analyze

        Returns:
            A list of choices from intent_choices that could match the intent.
            Returns a single choice if the match is clear, multiple choices if clarification is needed,
            or an empty list if no choices match the intent.
        """
        input_prompt = f"""
Analyze the given intent and identify which choices from the list could potentially match.

Intent: "{intent}"
Available Choices: {[x for x in self.intent_choices]}

Rules:
- If the intent clearly matches ONE choice, return only that choice
- If the intent could match MULTIPLE choices, return all plausible matches (ordered by likelihood)
- If the intent does NOT match any of the available choices, return an empty list
"""

        if isinstance(self.intent_choices, dict):
            description_string = "\n  ".join(
                [f"{key}: {val}" for key, val in self.intent_choices.items()]
            )
            input_prompt += f"""\n\nDetailed descriptions of each choice:\n  {description_string}"""

        response = self.client.responses.parse(
            model="gpt-5-mini",
            input=input_prompt.strip(),
            text_format=self.clarification_model,  # type: ignore
            reasoning={"effort": "low"},
        )

        return response.output_parsed.possible_matches  # type: ignore


@telemetry_client.track_class()
class DocumentQA:
    def __init__(
        self,
        vector_store_name: str,
        document: str,
        client: Optional[openai.OpenAI] = None,
    ):
        if client:
            self.client = client
        else:
            # TODO: Remove after beta.
            logger.debug("Creating beta OpenAI client.")
            self.client = beta.create_openai_client()

        self.vector_store = self.get_or_create_vector_store(vector_store_name, document)

    def get_or_create_vector_store(self, vector_store_name: str, document: str):
        document_hash: str = hashlib.sha256(document.encode()).hexdigest()

        for vs in self.client.vector_stores.list():
            if (
                vs.name == vector_store_name
                and vs.metadata
                and vs.metadata.get("document_hash") == document_hash
            ):
                logger.info("Re-using existing vector store...")
                return vs

        logger.info("Creating vector store...")
        vector_store = self.client.vector_stores.create(
            name=vector_store_name,
            expires_after={"anchor": "last_active_at", "days": 7},
        )

        logger.info("Uploading file...")
        self.client.vector_stores.files.upload_and_poll(
            vector_store_id=vector_store.id,
            file=("document.txt", document.encode()),
        )

        logger.info("Updating vector store metadata...")
        self.client.vector_stores.update(vector_store.id, metadata={"document_hash": document_hash})

        return vector_store

    def ask(self, question: str) -> str:
        response = self.client.responses.create(
            model="gpt-5-mini",
            instructions="You are a virtual contact center agent. Your task is to answer questions using the provided supporting document. Just answer the question - do not offer any follow-ups.",
            input=question,
            tools=[
                {
                    "type": "file_search",
                    "vector_store_ids": [self.vector_store.id],
                }
            ],
            reasoning={"effort": "low"},
        )
        return response.output_text


@telemetry_client.track_class()
class DatetimeFilter:
    def __init__(self, source_list: list[str], client: Optional[openai.OpenAI] = None):
        if client:
            self.client = client
        else:
            # TODO: Remove after beta.
            logger.debug("Creating beta OpenAI client.")
            self.client = beta.create_openai_client()

        self.source_list = source_list
        self.filter_model = create_model(
            "FilterModel",
            matching_appointments=(
                list[str],
                Field(..., description="List of datetimes matching the query. "),
            ),
            other_appointments=(
                list[str],
                Field(
                    ...,
                    description="If no datetimes match the query, list of datetimes to suggest",
                ),
            ),
            __config__={"extra": "forbid"},
        )

    def filter(self, query: str, max_results=5):
        print(f"datetimefilter query: {query}")
        tick = time.time()
        assert isinstance(max_results, int)
        appointment_times_str = "\n".join(self.source_list)
        prompt = [
            {
                "role": "system",
                "content": f"""
Return a few datetimes in the list matching the query. If no datetimes match the query, return a few other datetimes times from the list that can be used as close suggestions.
NEVER HALLUCINATE DATETIMES THAT ARE NOT IN THE LIST.
Query:{query}
Today's Date: {date.today().strftime("%B %d, %Y")}
Appointment Times:
{appointment_times_str}
==================
You must return at most {max_results} options per list.
""",
            }
        ]
        response = self.client.responses.parse(
            model="gpt-5-mini",
            input=prompt,  # type: ignore
            text_format=self.filter_model,  # type: ignore
            reasoning={"effort": "medium"},
        )

        output = response.output_parsed
        tock = time.time()
        print(f"datetimefilter took {(tock - tick):.3f} s")
        print(f"datetimefilter output: {output}")
        return output.matching_appointments[:max_results], output.other_appointments[:max_results]  # type: ignore
