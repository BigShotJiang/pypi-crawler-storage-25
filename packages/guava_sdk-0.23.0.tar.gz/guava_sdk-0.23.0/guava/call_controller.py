import logging
import queue
import threading
import uuid
import json
import warnings

from functools import partial

from .events import (
    CallerSpeechEvent,
    AgentSpeechEvent,
    Event,
    AgentQuestionEvent,
    InboundCallEvent,
    ErrorEvent,
    ActionItemCompletedEvent,
    TaskCompletedEvent,
    IntentEvent,
    ActionRequestEvent,
    BotSessionEnded,
    OutboundCallConnected,
    ChoiceQueryEvent,
    ExecuteActionEvent
)
from .commands import (
    Command,
    AnswerQuestionCommand,
    RejectInboundCallCommand,
    AcceptInboundCallCommand,
    SetLanguageMode,
    SetTaskCommand,
    SetPersona,
    ReadScriptCommand,
    SendInstructionCommand,
    TransferCommand,
    ChoiceResultCommand,
    RegisteredHooksCommand,
    ActionSuggestionCommand
)
from . import types
from .types import Field, Language, Say, ReachPersonOutcome

from typing import Optional, Union, Callable, Any
from websockets.sync.client import ClientConnection
from guava.telemetry import telemetry_client

logger = logging.getLogger("guava.call_controller")

class CommandQueueEnd:
    pass

@telemetry_client.track_class(only_exceptions={"on_event", "on_caller_speech", "on_agent_speech"})
class CallController:
    _command_queue: queue.Queue[Command | CommandQueueEnd]
    _on_complete_current_task: Optional[Callable]
    _field_values: dict[str, Any]
    _search_functions_by_key: dict[str, Callable]
    _current_task_id: Optional[str]
    _started: bool
    
    def __init__(self, data: Any = None) -> None:
        # Don't initialize anything here. Initialize vars in __new__.
        pass

    def __new__(cls, *args, **kwargs):
        # These variables are defined in __new__ so that if a subclass
        # forgets to call super().__init__(), they will still exist.
        # type definitions for them should go above.
        instance = super().__new__(cls)
        instance._command_queue = queue.Queue()
        instance._on_complete_current_task = None
        instance._field_values = {}
        instance._search_functions_by_key = {}
        instance._current_task_id = None
        instance._started = False
        registered_hooks = RegisteredHooksCommand(
            has_on_question=instance.on_question.__func__ is not CallController.on_question,
            has_on_intent=instance.on_intent.__func__ is not CallController.on_intent,
            has_on_action_requested=instance.on_action_request.__func__ is not CallController.on_action_request,
        )
        instance.send_command(registered_hooks)
        if registered_hooks.has_on_intent:
            if not registered_hooks.has_on_action_requested:
                warnings.warn(
                        f"Your call controller {cls.__name__} overrides `on_intent`. Use `on_action_requested` and `on_execute_action instead`",
                        UserWarning)
            else:
                warnings.warn(
                        f"Your call controller {cls.__name__} overrides both on_intent and on_action_requested. `on_intent` will be disabled.",
                        UserWarning)

        if instance.on_incoming_call.__func__ is not CallController.on_incoming_call:
            warnings.warn(
                f"Your call controller {cls.__name__} overrides on_incoming_call, which is deprecated - this function may be removed in the future. Use listen_inbound(controller_factory=...) instead to receive information about the inbound caller.",
                UserWarning)

        return instance

    def on_incoming_call(self, from_number: Optional[str]):
        pass

    def on_session_done(self):
        pass
    
    def accept_call(self):
        self.send_command(AcceptInboundCallCommand())
        
    def read_script(self, script: str):
        self.send_command(ReadScriptCommand(script=script))

    def reject_call(self):
        self.send_command(RejectInboundCallCommand())

    def add_info(self, label: str, info: Any):
        self.send_instruction(f"Here is some information about the following topic {label}:\n{json.dumps(info, indent=2)}")

    def on_intent(self, intent: str) -> Optional[str]:
        return "Unfortunately I'm not able to help with that."
    
    def on_action_request(self, action_summary: str) -> Optional[tuple[str, str]]:
        return None
    
    def on_execute_action(self, action_key: str):
        pass

    def set_persona(
            self,
            organization_name: Optional[str] = None,
            agent_name: Optional[str] = None,
            agent_purpose: Optional[str] = None,
            voice: Optional[str] = None
    ):
        self.send_command(
            SetPersona(
                organization_name=organization_name,
                agent_name=agent_name,
                agent_purpose=agent_purpose,
                voice=voice
            )
        )

    def set_language_mode(
            self,
            primary: Language = "english",
            secondary: Optional[list[Language]] = None,
    ):
        if secondary is None:
            secondary = []
        self.send_command(
            SetLanguageMode(
                primary=primary,
                secondary=secondary,
            )
        )

    def await_task(self, objective: str='', checklist: Optional[list[Union[Field, Say, str]]] = None):
        """Sets a task and synchronously waits for it to finish."""
        if not self._started:
            warnings.warn("Await task was called before the first event - it may hang. If called inside the constructor, move it out of the constructor or use set_task instead.", category=UserWarning)

        task_complete_event = threading.Event()
        self.set_task(objective, checklist, on_complete=lambda: task_complete_event.set())
        task_complete_event.wait()

    def set_task(
        self,
        objective: str = "",
        checklist: Optional[list[Union[Field, Say, str]]] = None,
        completion_criteria: Optional[str] = "",
        on_complete: Callable = lambda: None,
        **on_complete_kwargs,
    ):
        assert objective or checklist, "At least one of args ['objective','checklist'] must be provided."
        self._current_task_id = uuid.uuid4().hex[:6]
        if not checklist:
            checklist = []
        action_items : list[Union[types.Todo, types.SerializableField, Say]] = []
        for item in checklist:
            if isinstance(item, str):
                action_items.append(types.Todo(item))
            elif isinstance(item, Field):
                is_search_field = False
                if item.choice_generator:
                    is_search_field = True
                    self._search_functions_by_key[item.key] = item.choice_generator
                action_items.append(types.SerializableField(
                    item_type=item.item_type,
                    key=item.key,
                    description=item.description,
                    question=item.question,
                    field_type=item.field_type,
                    required=item.required,
                    choices=item.choices,
                    is_search_field=is_search_field
                ))
            else:
                action_items.append(item)

        self._on_complete_current_task = partial(on_complete, **on_complete_kwargs)
        self.send_command(
            SetTaskCommand(
                task_id=self._current_task_id,
                objective=objective,
                action_items=action_items,
                completion_criteria=completion_criteria,
            )
        )

    def hangup(self, final_instructions: str =''):
        if final_instructions:
            instructions = f"Start ending the conversation. Here are your final instructions: {final_instructions} Once you've completed the final instructions, naturally end the conversation and hang up the call."
        else:
            instructions = "Naturally end the conversation and hang up the call."
        self.send_instruction(instructions)
    
    def transfer(self, to_number: str = '', transfer_message: str = '', sip_address: str = '', transfer_instructions=''):
        # `transfer_message` will be said word-for-word and transfer immediately.
        # `transfer_instructions` lets the bot decide what to say and when it makes sense to transfer.
        if not to_number and not sip_address:
            logger.error("One of 'to_number' or 'sip_address' must be provided.")

        if transfer_message and transfer_instructions:
            logger.warning("`transfer_instructions` ignored when `transfer_message` provided in CallController.transfer()")
            
        soft_transfer = None
        msg = ''
        if transfer_message:
            msg = transfer_message
            soft_transfer = False
        elif transfer_instructions:
            msg = transfer_instructions
            soft_transfer = True
        else:
            msg = "I'm transferring you now"
            soft_transfer = False

        self.send_command(
            TransferCommand(
                transfer_message=msg,
                to_number=to_number or sip_address,
                soft_transfer=soft_transfer
            )
        )
        
    # fmt: off
    # Event handlers for developers to override.
    def on_caller_speech(self, event: CallerSpeechEvent): pass
    def on_agent_speech(self, event: AgentSpeechEvent): pass
    # fmt: on

    def on_question(self, question: str) -> str:
        return "I don't have an answer to that question."

    def send_command(self, command: Command):
        self._command_queue.put(command)
        logger.debug("Command queued: %r", command)
        
    def send_instruction(self, instruction: str):
        self.send_command(SendInstructionCommand(instruction=instruction))

    def on_event(self, event: Event):
        self._started = True

        if isinstance(event, CallerSpeechEvent):
            self.on_caller_speech(event)
        elif isinstance(event, AgentSpeechEvent):
            self.on_agent_speech(event)
        elif isinstance(event, AgentQuestionEvent):
            try:
                logger.info("Received question from bot: %s", event.question)
                answer = self.on_question(question=event.question)
                self.send_command(
                    AnswerQuestionCommand(question_id=event.question_id, answer=answer)
                )
            except Exception:
                logger.exception("Error occurred while answering question.")
                self.send_command(
                    AnswerQuestionCommand(
                        question_id=event.question_id,
                        answer="An error occurred and the question could not be answered.",
                    )
                )
        elif isinstance(event, IntentEvent):
            logger.info("Received intent %s from bot: %s", event.intent_id, event.intent_summary)
            intent_response = self.on_intent(event.intent_summary)
            if intent_response:
                logger.info("Responding to intent %s: %s", event.intent_id, intent_response)
                self.send_instruction(f"Responding to intent {event.intent_id}: {intent_response}")

        elif isinstance(event, ActionRequestEvent):
            logger.info("Received intent %s from bot: %s", event.intent_id, event.intent_summary)

            intent_response = self.on_action_request(event.intent_summary)
            logger.info("Responding to intent %s: %s", event.intent_id, intent_response)

            if intent_response is not None:
                action_key, action_description = intent_response[0], intent_response[1]
                self.send_command(ActionSuggestionCommand(
                    intent_id=event.intent_id,
                    action_key=action_key,
                    action_description=action_description
                ))
            else:
                self.send_command(ActionSuggestionCommand(
                    intent_id=event.intent_id,
                    action_key=None,
                ))
        elif isinstance(event, ExecuteActionEvent):
            self.on_execute_action(event.action_key)
        elif isinstance(event, ChoiceQueryEvent):
            logger.info("Received caller choice query: %s", event.query)
            try:
                choice_generator = self._search_functions_by_key[event.field_key]
            except KeyError:
                logger.warning("Choice search query '%s' arrived for field '%s', wich had no choice generator attached."\
                               "Ignore this warning if no choice generator is needed for this field.", event.query, event.field_key)
            else:
                choices, other_choices = choice_generator(event.query)
                self.send_command(ChoiceResultCommand(
                    field_key=event.field_key,
                    query_id=event.query_id,
                    matched_choices=choices,
                    other_choices=other_choices
                ))
        elif isinstance(event, TaskCompletedEvent):
            # ignore obsolete task_completed events
            if event.task_id == self._current_task_id:
                assert self._on_complete_current_task is not None
                on_complete : Callable = self._on_complete_current_task
                # important to reset to None before calling on_complete() and not after
                # since there's a high chance the callback sets a new task
                self._on_complete_current_task = None
                on_complete()
        elif isinstance(event, ActionItemCompletedEvent):
            self._field_values[event.key] = event.payload
            if event.key and event.payload:
                logger.info("Field %s updated with value: %r", event.key, event.payload)
        elif isinstance(event, InboundCallEvent):
            self.on_incoming_call(event.caller_number)
        elif isinstance(event, OutboundCallConnected):
            # Catch events that we expect to get but don't do anything with yet.
            # Don't spam warnings.
            pass
        elif isinstance(event, BotSessionEnded):
            self.on_session_done()
        elif isinstance(event, ErrorEvent):
            logger.error("The Guava agent reported an error: %s", event.content)
        else:
            logger.warning("Unhandled event: %r", event)

    def get_field(self, field_key: str, default: Any = None) -> Any:
        """
        Use get_field() to retrieve field values by their key.
        Can be called at any time, but most commonly as part of a Task's on_complete callback.
        """
        return self._field_values.get(field_key, default)

    def has_field(self, field_key: str):
        return field_key in self._field_values

    def shutdown(self):
        self._command_queue.put(CommandQueueEnd())

    def _drain_command_queue_thread(self, websocket: ClientConnection):
        while True:
            command = self._command_queue.get(block=True)
            if isinstance(command, CommandQueueEnd):
                logger.debug("Queue has been shut down. Ending command drain loop.")
                break

            logger.debug("Sending command: %r", command)
            websocket.send(command.model_dump_json())

    def reach_person(
        self,
        contact_full_name: str,
        *,
        greeting: str | None = None,
        on_success: Callable[[], None] | None = None,
        on_failure: Callable[[], None] | None = None,
        outcomes: list[ReachPersonOutcome] | None = None,
    ):
        """
        Helper function for reaching a specific contact on an outbound call and
        recording their availability.

        This provides a standard, tested pattern for the initial contact phase of
        a call. For production usage, prefer the `outcomes` argument; the
        `on_success` / `on_failure` callbacks are provided for simple flows and
        demos.

        This helper is optional and provided as a convenience. Users can define
        their own client-side tasks to implement more complex or fully custom
        reach scenarios.

        The function will:
            1. Greet the person who answers
            2. Ask for the specific contact if they're not the one who answered
            3. Record the contact's availability based on the provided outcomes
            4. Execute the appropriate outcome handler
        
        Usage:
            Simple binary case (available/unavailable)

                reach_person(
                    contact_full_name="John Smith",
                    on_success=self.start_survey,
                    on_failure=self.end_call
                )
            
            Complex case with multiple outcomes

                reach_person(
                    contact_full_name="John Smith",
                    outcomes=[
                        ReachPersonOutcome(key='available', on_outcome=self.start_survey),
                        ReachPersonOutcome(key='callback', on_outcome=self.schedule_callback),
                        ReachPersonOutcome(key='wrong_number', on_outcome=self.handle_wrong_number),
                    ]
                )

        Args:
            contact_full_name: Full name of the person to reach
            greeting: Optional custom greeting message. If not provided, uses a standard greeting
                that asks to speak with the contact.
            on_success: Callback for when contact is available (simple mode). Must be paired with `on_failure`.
            on_failure: Callback for when contact is unavailable (simple mode). Must be paired with `on_success`.
            outcomes: List of possible availability outcomes with handlers (advanced mode). Use this for
                scenarios with more than two possible outcomes. Mutually exclusive with `on_success`/`on_failure`.

        Raises:
            ValueError: If both outcomes and callbacks are provided, or if neither mode is fully specified.
        """
        ## 1) Assert valid arguments
        has_outcomes = outcomes is not None
        has_on_success = on_success is not None
        has_on_failure = on_failure is not None
        has_any_callback = has_on_success or has_on_failure
        has_both_callbacks = has_on_success and has_on_failure

        if has_outcomes and has_any_callback:
            raise ValueError("Specify either 'outcomes' OR ('on_success' and 'on_failure'), not both")

        if not has_outcomes and not has_both_callbacks:
            if has_on_success and not has_on_failure:
                raise ValueError("'on_success' requires 'on_failure' to also be specified")
            if has_on_failure and not has_on_success:
                raise ValueError("'on_failure' requires 'on_success' to also be specified")
            raise ValueError("You must specify either 'outcomes', or both 'on_success' and 'on_failure'")

        if not has_outcomes:
            assert (on_success is not None) and (on_failure is not None)
            outcomes = [
                ReachPersonOutcome(key='contact_available', on_outcome=on_success, description="The contact is available to speak."),
                ReachPersonOutcome(key='contact_unavailable', on_outcome=on_failure, description="The contact is not available to speak. This includes reaching a wrong number."),
            ]

        ## 2) Prepare task data from outcomes
        # Extract outcome data structures
        assert outcomes is not None
        outcome_keys = [outcome.key for outcome in outcomes]
        outcome_handlers = {outcome.key: outcome.on_outcome for outcome in outcomes}

        # Build choice descriptions for the Multiple Choice field
        availability_field_description = f"The availability of {contact_full_name}"
        choice_lines = [
            f" - {outcome.key}: {outcome.description}" 
            for outcome in outcomes
            if outcome.description is not None
        ]
        if choice_lines:
            availability_field_description += (
                "\nDetailed descriptions of each choice:\n" + "\n".join(choice_lines)
            )

        # Build transition instructions
        next_action_lines = [
            f"- {outcome.key} → {outcome.next_action_preview}"
            for outcome in outcomes
            if outcome.next_action_preview is not None
        ]
        transition_instructions: Optional[str] = None
        if next_action_lines:
            transition_instructions = (
                "If a next action is defined below for the value of `contact_availability`, briefly ask the contact to wait just a second while you perform it."
                '\n'.join(next_action_lines)
            )

        ## 3) Define the "Reach Person" task
        # Define objective
        objective = f"""
OBJECTIVE:
Your goal is to reach {contact_full_name} and determine their availability to proceed with this call.

RULES:
1. If the initial respondent is NOT {contact_full_name}:
   - Politely ask to speak with {contact_full_name}
   - Wait to be transferred or for {contact_full_name} to come to the phone
2. Once you have {contact_full_name} on the line:
   - Briefly restate who you are and the purpose of your call
   - Determine and record their current availability status
3. DO NOT hang up the call under any circumstances, unless it's a wrong number.

TASK COMPLETION REQUIREMENTS:
- The availability of {contact_full_name} must be recorded in `contact_availability`.
"""

        # Build checklist
        initial_greeting = (
            Say(greeting) if greeting is not None
            else f"Greet the person who answered the phone. "
                f"Notify them who you are calling on behalf of and the purpose of the call. "
                f"Ask to speak with {contact_full_name}"
        )
        availability_field = Field(
            key='contact_availability',
            description=availability_field_description,
            field_type='multiple_choice',
            choices=outcome_keys,
            required=True,
        )
        checklist = [initial_greeting, availability_field]
        if transition_instructions:
            checklist.append(transition_instructions)

        # Define task completion handler
        def on_reach_complete():
            contact_availability: str = self.get_field('contact_availability')
            handler = outcome_handlers.get(contact_availability)
            if handler is None:
                logger.error("Unhandled contact_availability value: %s", contact_availability)
                return
            logger.info(
                "Contact availability recorded: %s → %s",
                contact_availability,
                getattr(handler, '__name__', repr(handler))
            )
            handler()

        ## 4) Set the "Reach Person" task
        self.set_task(objective, checklist, on_complete=on_reach_complete)
