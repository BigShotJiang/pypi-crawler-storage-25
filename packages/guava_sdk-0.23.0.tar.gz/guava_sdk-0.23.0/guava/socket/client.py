import secrets
import time
import logging
import random

from websockets.exceptions import ConnectionClosed, InvalidStatus
from pydantic import TypeAdapter
from typing import Generic, TypeVar, Literal, Tuple, Callable, Union
from websockets.sync.client import connect as ws_connect, ClientConnection
from .protocol import GuavaOpen, GuavaOpenAck, GuavaMessage, GuavaClose, GuavaPing, GuavaPong, GuavaAck, CloseReason, now_ms
from threading import Lock, Thread, Event
from queue import Queue, Empty
from guava.telemetry import telemetry_client
from .utils import EventCounter

class GuavaSocketClosedError(Exception):
    """The socket is permanently closed."""
    def __init__(self, reason: CloseReason | None = None, description: str | None = None):
        self.reason: CloseReason = reason or "unknown"
        self.description: str = description or "No description provided."
        super().__init__(f"Guava socket closed. Reason: {self.reason}. Description: {self.description}")


class GuavaSocketConnectionFailed(Exception):
    """We couldn't connect to the peer even after retrying many times."""
    pass


SendT = TypeVar("SendT")
RecvT = TypeVar("RecvT")

@telemetry_client.track_class()
class GuavaSocket(Generic[SendT, RecvT]):
    """A higher-level websocket wrapper that supports reconnections."""
    
    def __init__(
        self,
        name: str,
        connection_url: str,
        headers: dict,
        serializer: Callable[[SendT], dict],
        deserializer: Callable[[dict], RecvT],
        max_age_seconds: float | None = None
    ):
        self._name = name
        self._connection_url = connection_url
        self._headers = headers
        
        self._logger = logging.getLogger(f"guava.socket.{name}")
        
        self._max_age_seconds = max_age_seconds
        # Sockets are always connected immediately after creating, so just use this time to compare against max age
        self._socket_create_time = time.time()
        
        self._serializer = serializer
        self._deserializer = deserializer

        self._max_reconnect_attempts = 10

        # Unique ID for this connection that persists across reconnects
        self._connection_id: str = secrets.token_hex(10)

        # The last sequence number we've seen. Only update this on the reconnect thread.
        self._last_seen_sequence = 0
        
        # The last sequence num we've sent.
        self._last_sent_sequence = 0
        
        # The retransmission buffer. Payloads can be dropped on Ack messages.
        self._rtx_buffer: list[Tuple[int, dict]] = []

        # This is the state of the higher-level GuavaSocket, not the websocket.
        # Should only be mutated on the reconnect thread.
        self._state: Literal["never-opened", "open", "closed"] = "never-opened"

        # The thread that handles reconnecting the socket, receving messages, responding to pings, etc
        self._reconnect_thread: Thread | None = None

        self._should_reconnect = Event() # Set this to signal that the socket needs reconnection. Cleared once the socket is ready.
        self._should_close = Event() # Set this to tell the reconnect loop to close the socket. This event is set once and never cleared.
        self._websocket_ready = Event() # Reconnect thread sends this to signal that the socket is ready for sending. Set once and never cleared.
        self._recv_queue: Queue[dict] = Queue()

        self._websocket: ClientConnection | None = None # Set this value when the websocket is actually ready to be used.
        self._ws_lock = Lock() # A lock used for guarding the websocket, and also any mutations to the rtx_buffer
        
        self._close_reason: CloseReason | None = None
        self._close_description: str | None = None
        
        # Count the number of connection opens in the last minute.
        self._open_counter = EventCounter(window_seconds=60.0)
        
    def _set_close_reason(self, reason: CloseReason, description: str):
        # First close reason wins. There's a possible race here, but not a big deal since this is only debugging info.
        if self._close_reason is None:
            self._close_reason = reason
            self._close_description = description

    def _reconnect_timeout(self, attempt_num: int) -> float:
        """First try reconnecting quickly - then backoff."""
        if attempt_num <= 3:
            return 1.0 + random.uniform(-0.5, 0.5)
        elif attempt_num <= 5:
            return 5.0 + random.uniform(-2, 2)
        else:
            return 10.0 + random.uniform(-5, 5)
        
    def is_open(self) -> bool:
        return self._state == "open"
    
    def _try_close_websocket(self, websocket: ClientConnection | None):
        try:
            if websocket:
                websocket.close()
        except Exception: # TODO: Narrow down this error?
            pass
        
    def _prune_rtx_buffer(self, peer_last_seen_sequence: int):
        """Prune messages from the RTX buffer that the peer has alredy seen."""
        # This lock also guards the RTX buffer.
        assert self._ws_lock.locked()
        
        while self._rtx_buffer and self._rtx_buffer[0][0] <= peer_last_seen_sequence:
            self._rtx_buffer.pop(0)
    
    def _establish_socket(self, is_reopen: bool) -> ClientConnection:
        assert self._ws_lock.locked()

        num_attempts = 0
        websocket = None

        while True:
            # Cap number of reconnect-attempts and just fail.
            if num_attempts >= self._max_reconnect_attempts:
                self._logger.error("Couldn't connect to server after %d attempts.", num_attempts)
                self._set_close_reason("reconnection-failed", f"Couldn't connect to server after {num_attempts} attempts.")
                raise GuavaSocketConnectionFailed()
            
            num_attempts += 1
            
            try:
                websocket = ws_connect(self._connection_url, additional_headers=self._headers, open_timeout=10, close_timeout=10)
                websocket.send(
                    GuavaOpen(
                        name=self._name,
                        connection_id=self._connection_id,
                        last_seen_sequence=self._last_seen_sequence,
                        is_reopen=is_reopen,
                    ).model_dump_json()
                )

                # If we don't get a response back in 10 seconds, the socket is probably invalid.
                response: GuavaOpenAck | GuavaClose = TypeAdapter(Union[GuavaOpenAck, GuavaClose]).validate_json(websocket.recv(timeout=10))
                
                match response:
                    case GuavaClose():
                        self._set_close_reason(response.reason, response.description)
                        raise GuavaSocketClosedError(response.reason, response.description)
                    case GuavaOpenAck():
                        # Retransmit messages that the server hasn't seen yet
                        for seq, payload in self._rtx_buffer:
                            if seq > response.last_seen_sequence:
                                websocket.send(GuavaMessage(sequence=seq, payload=payload).model_dump_json())
                                
                        # Prune RTX buffer.
                        self._prune_rtx_buffer(response.last_seen_sequence)

                        # The socket is now ready.
                        return websocket
                    case _:
                        self._logger.error("Received unexpected response from server: %r", response)
                        self._set_close_reason("server-error", f"Received unexpected response from server: {response}")
                        raise GuavaSocketConnectionFailed()
            except GuavaSocketClosedError:
                # Peer explicitly closed connection. We cannot re-connect. Raise to caller.
                self._try_close_websocket(websocket)
                raise
            except Exception as e:
                # Close the websocket if it's still open for some reason.
                self._try_close_websocket(websocket)
                
                match e:
                    case InvalidStatus():
                        body = e.response.body.decode() if e.response.body else "No response body."
                        status_interpretation = "HTTP error"
                        if e.response.status_code in (401, 403):
                            status_interpretation = "Authentication Failure"
                        
                        self._logger.error("Failed to connect to websocket endpoint %s due to %s. HTTP %d, Body: %s. Trying again in a few seconds...", self._connection_url, status_interpretation, e.response.status_code, body)
                    case _:
                        self._logger.exception("Failed to open Guava socket after %d attempts. Trying again in a few seconds...", num_attempts)
                    
                time.sleep(self._reconnect_timeout(num_attempts))


    def _reconnect_loop(self) -> None :
        assert self._state == "never-opened"

        try:
            while not self._should_close.is_set():
                with self._ws_lock:
                    # Try to close websocket if it exists.
                    self._try_close_websocket(self._websocket)

                    # Establish a new websocket connection.
                    self._websocket = self._establish_socket(self._state == "open")
                    self._open_counter.add_event()
                    self._logger.debug("GuavaSocket connection established.")
                    self._websocket_ready.set()
                    self._should_reconnect.clear()
                    self._state = "open"
                    
                if self._open_counter.count() >= 15:
                    # We've had many supposedly "successful" connections in the last minute.
                    # That probably means the server is in a bad state and just looping.
                    self._set_close_reason("server-error", "Too many connections in the last minute. The server is probably in a bad state.")
                    return
                    

                while not self._should_close.is_set() and not self._should_reconnect.is_set():
                    if self._max_age_seconds and time.time() > self._socket_create_time + self._max_age_seconds:
                        self._set_close_reason("other", "The socket hit its max age limit.")
                        self._logger.warning("Socket hit max age limit. Exiting...")
                        return
                    
                    try:
                        try:
                            message = TypeAdapter(GuavaMessage | GuavaClose | GuavaPing | GuavaPong | GuavaAck).validate_json(self._websocket.recv(timeout=10))
                        except TimeoutError:
                            with self._ws_lock:
                                self._websocket.send(GuavaPing(ping_timestamp=now_ms()).model_dump_json())
                                continue

                        match message:
                            case GuavaPing():
                                with self._ws_lock:
                                    self._websocket.send(GuavaPong(
                                        ping_timestamp=message.ping_timestamp,
                                        pong_timestamp=now_ms()
                                    ).model_dump_json())
                            case GuavaPong():
                                pass
                            case GuavaClose():
                                # The server closed this socket. Break out of the loop and exit.
                                self._set_close_reason(message.reason, message.description)
                                self._should_close.set()
                                break
                            case GuavaMessage():
                                if message.sequence <= self._last_seen_sequence:
                                    self._logger.warning("Got a message corresponding to sequence we've already seen. Skipping...")
                                else:
                                    if message.sequence != self._last_seen_sequence + 1:
                                        self._logger.warning("A sequence number has been skipped?")
                                        
                                    self._last_seen_sequence = message.sequence
                                    self._recv_queue.put(message.payload)
                                    
                                # TODO: We can afford to send this less frequently.
                                with self._ws_lock:
                                    self._websocket.send(GuavaAck(last_seen_sequence=self._last_seen_sequence).model_dump_json())
                            case GuavaAck():
                                with self._ws_lock:
                                    self._prune_rtx_buffer(message.last_seen_sequence)
                    except ConnectionClosed:
                        # Break out of this loop and reconnect.
                        time.sleep(self._reconnect_timeout(1)) # Sleep a bit before reconnecting.
                        break
        except Exception:
            self._logger.exception("Exception in reconnection thread. Connection must be closed.")
            raise
        finally:
            self._state = "closed"
            self._logger.debug("Closing GuavaSocket for good...")

            # Try to close websocket, if it exists.
            with self._ws_lock:
                self._try_close_websocket(self._websocket)


    def connect(self) -> None:
        assert self._state == "never-opened"
        assert self._reconnect_thread is None
        self._logger.debug("Starting websocket reconnection thread...")

        self._reconnect_thread = Thread(target=self._reconnect_loop, daemon=True)
        self._reconnect_thread.start()
        
        # Return once the websocket is ready for the first time.
        while True:
            if self._state == "open":
                return
            if self._state == "closed":
                raise GuavaSocketClosedError(self._close_reason, self._close_description)
            
            self._websocket_ready.wait(timeout=5)

    def close(self) -> None:
        # It's safe to call this multiple times.
        # Should only call after connect has finished.
        assert self._reconnect_thread
        self._set_close_reason("done", "The socket was closed by the client.")
        self._should_close.set()
        self._reconnect_thread.join()

    def send(self, message: SendT) -> None:
        assert self._state != "never-opened"

        # If the socket is closed, we can't send anything.
        if self._state == "closed":
            raise GuavaSocketClosedError(self._close_reason, self._close_description)

        payload = self._serializer(message)

        with self._ws_lock:
            # Add the payload to the retransmission buffer.
            self._last_sent_sequence += 1
            self._rtx_buffer.append((self._last_sent_sequence, payload))

            # Try to send on this websocket. Signal for a reconnect if not.
            # Reconnect will handle any retransmissions.
            try:
                if self._websocket:
                    self._websocket.send(
                        GuavaMessage(sequence=self._last_sent_sequence, payload=payload).model_dump_json()
                    )
            except ConnectionClosed:
                self._should_reconnect.set()

    def recv(self) -> RecvT:
        assert self._state != "never-opened"
        
        # Keep running in a loop until the socket is closed or we get an actual message.
        while True:
            if self._state == "closed":
                raise GuavaSocketClosedError(self._close_reason, self._close_description)
            
            try:
                message = self._recv_queue.get(block=True, timeout=1)
                return self._deserializer(message)
            except Empty:
                continue

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
