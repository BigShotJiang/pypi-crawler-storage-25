# src/binho_sdk/events.py
"""Public event types yielded by query().

Events form a discriminated union by `type`. The final event of any query()
invocation is always a Result, after which the iterator exhausts.

Stop reasons (Result.stop_reason):
  - "end_turn"        — assistant returned no tool calls
  - "max_turns"       — Options.max_turns exceeded
  - "tool_terminate"  — every runnable tool in a batch returned terminate=True
  - "context_full"    — token estimate exceeded Options.context_window * margin
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from binho_sdk.messages import Message


@dataclass
class Usage:
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    cost_usd: float | None = None

    def __add__(self, other: Usage) -> Usage:
        cost: float | None
        if self.cost_usd is None and other.cost_usd is None:
            cost = None
        else:
            cost = (self.cost_usd or 0.0) + (other.cost_usd or 0.0)
        return Usage(
            input_tokens=self.input_tokens + other.input_tokens,
            output_tokens=self.output_tokens + other.output_tokens,
            cache_read_tokens=self.cache_read_tokens + other.cache_read_tokens,
            cache_write_tokens=self.cache_write_tokens + other.cache_write_tokens,
            cost_usd=cost,
        )


@dataclass
class TextDelta:
    delta: str
    type: Literal["text_delta"] = "text_delta"


@dataclass
class ToolUse:
    id: str
    name: str
    arguments: dict[str, object]
    type: Literal["tool_use"] = "tool_use"


@dataclass
class ToolResult:
    id: str
    content: str
    is_error: bool
    type: Literal["tool_result"] = "tool_result"


@dataclass
class TurnStart:
    turn: int
    type: Literal["turn_start"] = "turn_start"


@dataclass
class TurnEnd:
    turn: int
    type: Literal["turn_end"] = "turn_end"


@dataclass
class SubagentStart:
    agent_type: str
    agent_id: str
    type: Literal["subagent_start"] = "subagent_start"


@dataclass
class SubagentEnd:
    agent_id: str
    result: str
    type: Literal["subagent_end"] = "subagent_end"


StopReason = Literal["end_turn", "max_turns", "tool_terminate", "context_full"]


@dataclass
class Result:
    messages: list[Message]
    usage: Usage
    stop_reason: StopReason
    type: Literal["result"] = "result"


Event = (
    TextDelta | ToolUse | ToolResult | TurnStart | TurnEnd | SubagentStart | SubagentEnd | Result
)
