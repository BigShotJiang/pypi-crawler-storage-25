# src/binho_sdk/permissions/modes.py
"""Permission modes, callback shape, and the v1 default policy.

The full permission engine (allowlist rules, persistent storage, interactive
ask resolution) is a v2 concern. v1 ships:
- PermissionMode enum (final values)
- CanUseTool callback signature (final shape)
- PermissionUpdate type (final shape; ignored in v1)
- default_decide() — a tiny policy keyed on permission_mode

This is enough for callers to plug their own can_use_tool callback today,
and for the loop to behave sensibly when no callback is supplied.
"""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Literal

PermissionMode = Literal["default", "acceptEdits", "bypassPermissions", "plan"]


@dataclass
class PermissionUpdate:
    """v1 placeholder; v2 will wire allowlist persistence without API change."""

    type: Literal["addRules", "removeRules", "setMode"]
    rules: list[str] | None = None
    mode: PermissionMode | None = None


@dataclass
class CanUseToolInput:
    tool_name: str
    tool_input: dict[str, object]
    tool_use_id: str
    agent_id: str | None
    agent_type: str | None
    permission_mode: PermissionMode
    suggestions: list[PermissionUpdate] = field(default_factory=list)


@dataclass
class PermissionResult:
    behavior: Literal["allow", "deny", "ask"]
    updated_input: dict[str, object] | None = None
    message: str | None = None
    # Accepted but ignored in v1; v2 will respect.
    updated_permissions: list[PermissionUpdate] | None = None


CanUseTool = Callable[[CanUseToolInput], Awaitable[PermissionResult]]


_READ_ONLY_BUILTINS = frozenset({"Read", "Glob", "Grep"})
_READ_AND_EDIT_BUILTINS = frozenset({"Read", "Write", "Edit", "Glob", "Grep"})


def default_decide(inp: CanUseToolInput) -> PermissionResult:
    """The v1 fallback policy when caller doesn't supply can_use_tool.

    See spec §9. MCP-served tools (mcp__*) are denied in plan and acceptEdits
    because the SDK can't infer their read/write semantics.
    """
    is_mcp = inp.tool_name.startswith("mcp__")

    if inp.permission_mode == "bypassPermissions":
        return PermissionResult(behavior="allow")

    if inp.permission_mode == "plan":
        if not is_mcp and inp.tool_name in _READ_ONLY_BUILTINS:
            return PermissionResult(behavior="allow")
        return PermissionResult(
            behavior="deny", message=f"{inp.tool_name} not permitted in plan mode"
        )

    if inp.permission_mode == "acceptEdits":
        if is_mcp:
            return PermissionResult(
                behavior="deny",
                message=(
                    "MCP tools denied in acceptEdits mode"
                    " (use bypassPermissions or a custom can_use_tool)"
                ),
            )
        if inp.tool_name == "Bash":
            return PermissionResult(behavior="ask")
        if inp.tool_name in _READ_AND_EDIT_BUILTINS:
            return PermissionResult(behavior="allow")
        return PermissionResult(behavior="allow")

    # mode == "default"
    return PermissionResult(behavior="allow")
