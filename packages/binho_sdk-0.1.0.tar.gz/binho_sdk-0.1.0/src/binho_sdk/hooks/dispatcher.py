"""Hook firing logic.

The dispatcher does not interpret the meaning of decision="deny" — that's the
caller's job (the loop). It just chains hooks, threads modified inputs and
outputs through, and short-circuits on the first deny.

Exceptions inside a hook propagate up to the caller. The loop layer is
responsible for converting them into ToolResult(is_error=True) for tool-related
events; for Stop, the loop logs and treats as None (see spec §8).
"""
from __future__ import annotations

from dataclasses import replace

from binho_sdk.hooks.events import (
    HookCallback,
    HookContext,
    HookEvent,
    HookResult,
)


class HookDispatcher:
    def __init__(self, hooks: dict[HookEvent, list[HookCallback]] | None) -> None:
        self._hooks: dict[HookEvent, list[HookCallback]] = hooks or {}

    async def fire(self, event: HookEvent, ctx: HookContext) -> HookResult | None:
        """Run hooks for `event` in registration order. Return the final
        non-None result, or None if all hooks pass through.

        Semantics:
          - First decision="deny" short-circuits remaining hooks.
          - decision="modify" mutates ctx for the next hook in the chain
            (modified_input -> ctx.tool_input; modified_output -> ctx.tool_result).
          - decision="allow" or None is pass-through.
        """
        callbacks = self._hooks.get(event, [])
        final: HookResult | None = None

        for cb in callbacks:
            result = await cb(ctx)
            if result is None:
                continue

            if result.decision == "deny":
                return result

            if result.decision == "modify":
                if result.modified_input is not None:
                    ctx = replace(ctx, tool_input=result.modified_input)
                if result.modified_output is not None:
                    ctx = replace(ctx, tool_result=result.modified_output)

            final = result

        return final
