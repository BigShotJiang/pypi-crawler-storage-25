"""Hook event names, context, and result types.

Five events in v1: PreToolUse, PostToolUse, Stop, SubagentStart, SubagentStop.
The HookCallback signature is final; the dispatcher (next file) is what
actually fires them.
"""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from binho_sdk.messages import Message

if TYPE_CHECKING:
    from binho_sdk.options import Options


HookEvent = Literal[
    "PreToolUse",
    "PostToolUse",
    "Stop",
    "SubagentStart",
    "SubagentStop",
]


@dataclass
class HookContext:
    event: HookEvent
    messages: list[Message]
    cwd: str
    options: Options
    tool_name: str | None = None
    tool_input: dict[str, Any] | None = None
    tool_use_id: str | None = None
    tool_result: str | None = None      # PostToolUse only
    is_error: bool | None = None        # PostToolUse only
    agent_type: str | None = None       # subagent events only
    agent_id: str | None = None


@dataclass
class HookResult:
    decision: Literal["allow", "deny", "modify"] | None = None
    reason: str | None = None
    modified_input: dict[str, Any] | None = None      # PreToolUse modify
    modified_output: str | None = None      # PostToolUse / SubagentStop modify


HookCallback = Callable[[HookContext], Awaitable[HookResult | None]]
