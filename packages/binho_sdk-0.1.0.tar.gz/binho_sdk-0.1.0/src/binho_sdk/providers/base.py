"""Provider protocol and event types.

The loop talks to the provider through this narrow interface. The provider
emits a stream of typed events; the loop consumes them and never sees HTTP,
the openai SDK, or per-provider quirks.
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, Protocol, runtime_checkable

from binho_sdk.events import Usage
from binho_sdk.messages import Message

if TYPE_CHECKING:
    from binho_sdk.options import Options
    from binho_sdk.tools.base import Tool

ToolSchema = dict  # OpenAI function schema dict


@dataclass
class ProviderTextDelta:
    delta: str
    type: Literal["text_delta"] = "text_delta"


@dataclass
class ProviderToolCall:
    id: str
    name: str
    arguments: dict[str, object]
    type: Literal["tool_call"] = "tool_call"
    # When the provider cannot parse the model's JSON, raw_arguments carries the
    # broken string so the runner can store it verbatim in the assistant message's
    # tool_calls; the dispatcher's JSON-decode path then produces a _BlockedPlan.
    raw_arguments: str | None = None


@dataclass
class ProviderUsage:
    usage: Usage
    type: Literal["usage"] = "usage"


@dataclass
class ProviderDone:
    finish_reason: str
    type: Literal["done"] = "done"


ProviderEvent = ProviderTextDelta | ProviderToolCall | ProviderUsage | ProviderDone


@runtime_checkable
class Provider(Protocol):
    def stream(
        self,
        messages: list[Message],
        tools: list[Tool],
        options: Options,
    ) -> AsyncIterator[ProviderEvent]: ...
