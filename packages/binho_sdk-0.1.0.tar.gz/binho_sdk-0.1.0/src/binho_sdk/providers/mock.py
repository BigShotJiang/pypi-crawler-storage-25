"""MockProvider — scriptable Provider for loop tests.

Each entry in `scripted_responses` is the list of ProviderEvents to yield
on the corresponding call to stream(). The provider records each call's
inputs in `recorded_calls` so tests can assert on them.
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass

from binho_sdk.messages import Message
from binho_sdk.options import Options
from binho_sdk.providers.base import ProviderEvent
from binho_sdk.tools.base import Tool


@dataclass
class ProviderCallRecord:
    messages: list[Message]
    tools: list[Tool]
    model: str


class MockProvider:
    def __init__(self, scripted_responses: list[list[ProviderEvent]]) -> None:
        self._responses = scripted_responses
        self._index = 0
        self.recorded_calls: list[ProviderCallRecord] = []

    async def stream(
        self,
        messages: list[Message],
        tools: list[Tool],
        options: Options,
    ) -> AsyncIterator[ProviderEvent]:
        if self._index >= len(self._responses):
            raise IndexError(
                f"MockProvider script exhausted: {len(self._responses)} responses scripted, "
                f"call #{self._index + 1} requested."
            )
        self.recorded_calls.append(
            ProviderCallRecord(messages=list(messages), tools=list(tools), model=options.model)
        )
        events = self._responses[self._index]
        self._index += 1
        for ev in events:
            yield ev
