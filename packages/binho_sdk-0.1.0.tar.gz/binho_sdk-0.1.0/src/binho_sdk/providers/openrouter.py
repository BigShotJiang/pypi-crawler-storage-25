"""OpenRouter provider (streaming, with retries)."""
from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import openai

from binho_sdk.errors import AuthError, QuotaError, RateLimitError, TransportError
from binho_sdk.events import Usage
from binho_sdk.messages import Message
from binho_sdk.options import Options
from binho_sdk.providers._retry import (
    RetryPolicy,
    classify_error,
    compute_backoff,
)
from binho_sdk.providers.base import (
    Provider,
    ProviderDone,
    ProviderEvent,
    ProviderTextDelta,
    ProviderToolCall,
    ProviderUsage,
)
from binho_sdk.tools.base import Tool

logger = logging.getLogger("binho_sdk.providers.openrouter")


@dataclass
class _ToolCallAccum:
    id: str | None = None
    name: str | None = None
    arguments: str = ""

    def is_complete(self, finish_reason: str | None) -> bool:
        return self.id is not None and self.name is not None and finish_reason is not None


def _serialize_tool(tool: Tool) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.parameters_schema,
        },
    }


class OpenRouterProvider(Provider):
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://openrouter.ai/api/v1",
        http_referer: str | None = None,
        app_title: str | None = None,
        retry_policy: RetryPolicy | None = None,
        _client: Any | None = None,  # for tests; real callers pass api_key
    ) -> None:
        self._policy = retry_policy or RetryPolicy()
        if _client is not None:
            self._client = _client
        else:
            headers: dict[str, str] = {}
            if http_referer:
                headers["HTTP-Referer"] = http_referer
            if app_title:
                headers["X-Title"] = app_title
            self._client = openai.AsyncOpenAI(
                api_key=api_key,
                base_url=base_url,
                default_headers=headers or None,
            )

    async def stream(
        self,
        messages: list[Message],
        tools: list[Tool],
        options: Options,
    ) -> AsyncIterator[ProviderEvent]:
        async for ev in self._stream_with_retries(messages, tools, options):
            yield ev

    async def _stream_with_retries(
        self,
        messages: list[Message],
        tools: list[Tool],
        options: Options,
    ) -> AsyncIterator[ProviderEvent]:
        for attempt in range(self._policy.max_attempts):
            emitted = False
            try:
                async for ev in self._stream_once(messages, tools, options):
                    emitted = True
                    yield ev
                return
            except Exception as exc:
                kind = classify_error(exc)
                if kind == "auth":
                    raise AuthError(str(exc)) from exc
                if kind == "quota":
                    raise QuotaError(str(exc)) from exc
                # Mid-stream failures cannot be retried: events have already been
                # delivered to the caller and appended to history. Replaying would
                # duplicate text and tool-call accumulators.
                if emitted:
                    raise TransportError(
                        f"stream interrupted after partial output: {exc}"
                    ) from exc
                if attempt + 1 >= self._policy.max_attempts:
                    if kind == "rate_limited":
                        raise RateLimitError(str(exc)) from exc
                    raise TransportError(str(exc)) from exc
                delay = compute_backoff(attempt, exc, self._policy)
                logger.warning(
                    "openrouter retry attempt %d after %.2fs: %s", attempt + 1, delay, exc
                )
                await asyncio.sleep(delay)

    async def _stream_once(
        self,
        messages: list[Message],
        tools: list[Tool],
        options: Options,
    ) -> AsyncIterator[ProviderEvent]:
        kwargs: dict[str, Any] = {
            "model": options.model,
            "messages": messages,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if options.max_tokens is not None:
            kwargs["max_tokens"] = options.max_tokens
        if tools:
            kwargs["tools"] = [_serialize_tool(t) for t in tools]
        extra_body: dict[str, Any] = {}
        if options.allow_provider_fallback:
            extra_body["route"] = "fallback"
        if options.provider_routing is not None:
            extra_body["provider"] = options.provider_routing
        if extra_body:
            kwargs["extra_body"] = extra_body

        stream = await self._client.chat.completions.create(**kwargs)
        # Tool-call deltas are keyed by ``index`` per OpenAI's spec, but
        # Google's OpenAI-compat endpoint emits each parallel tool call as
        # one *complete* delta with ``index=None`` and a unique ``id``. Fall
        # back to ``id`` (or a monotonic counter) when index is missing so
        # parallel calls don't all collapse into a single accumulator slot
        # (which produced concatenated argument strings that failed
        # ``json.loads`` and surfaced as a single _BlockedPlan instead of N
        # successful tool invocations).
        accum: dict[Any, _ToolCallAccum] = {}
        fallback_counter = 0

        async for chunk in stream:
            choice = chunk.choices[0] if chunk.choices else None
            if choice is not None:
                delta = choice.delta
                if getattr(delta, "content", None):
                    yield ProviderTextDelta(delta=delta.content)

                tool_call_deltas = getattr(delta, "tool_calls", None) or []
                for tcd in tool_call_deltas:
                    if tcd.index is not None:
                        key: Any = ("idx", tcd.index)
                    elif getattr(tcd, "id", None):
                        key = ("id", tcd.id)
                    else:
                        fallback_counter += 1
                        key = ("fb", fallback_counter)
                    a = accum.setdefault(key, _ToolCallAccum())
                    if getattr(tcd, "id", None):
                        a.id = tcd.id
                    fn = getattr(tcd, "function", None)
                    if fn is not None:
                        if getattr(fn, "name", None):
                            a.name = fn.name
                        if getattr(fn, "arguments", None):
                            a.arguments += fn.arguments

                if choice.finish_reason:
                    # Emit any complete tool calls we've accumulated. Sort by
                    # the original key tuple so OpenAI's index-ordered calls
                    # remain in order; Gemini's id-keyed calls are sorted by
                    # id which is stable but arbitrary — order doesn't matter
                    # for parallel calls.
                    for _, a in sorted(accum.items(), key=lambda kv: str(kv[0])):
                        if a.id and a.name:
                            try:
                                args = json.loads(a.arguments) if a.arguments else {}
                            except json.JSONDecodeError as exc:
                                logger.warning("malformed tool args from provider: %s", exc)
                                # Preserve the broken string via raw_arguments so the
                                # runner stores it verbatim in the assistant message's
                                # tool_calls; the dispatcher's JSON-decode path then
                                # produces a _BlockedPlan with a clear reason.
                                yield ProviderToolCall(
                                    id=a.id, name=a.name,
                                    arguments={},
                                    raw_arguments=a.arguments,
                                )
                                continue
                            yield ProviderToolCall(id=a.id, name=a.name, arguments=args)
                    yield ProviderDone(finish_reason=choice.finish_reason)
                    accum.clear()

            usage = getattr(chunk, "usage", None)
            if usage is not None:
                yield ProviderUsage(
                    usage=Usage(
                        input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
                        output_tokens=getattr(usage, "completion_tokens", 0) or 0,
                        cost_usd=getattr(usage, "cost", None),
                    )
                )
