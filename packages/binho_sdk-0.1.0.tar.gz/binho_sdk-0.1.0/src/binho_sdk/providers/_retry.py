"""Error classification and backoff for the OpenRouter provider.

Ported from apps/doc-worker/llm/client.py, narrowed to what the SDK needs.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Literal

import openai

ErrorClass = Literal["auth", "quota", "rate_limited", "transient", "fatal"]


@dataclass
class RetryPolicy:
    max_attempts: int = 5
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 60.0
    jitter: bool = True


_AUTH_MARKERS = ("invalid api key", "unauthorized", "invalid_api_key", "incorrect api key")
_QUOTA_MARKERS = ("insufficient_quota", "payment required", "budget exceeded", "quota exceeded")
_RATE_LIMIT_MARKERS = ("429", "rate limit", "resource_exhausted", "too many requests")


def _status(exc: Exception) -> int | None:
    return getattr(exc, "status_code", None)


def classify_error(exc: Exception) -> ErrorClass:
    if isinstance(exc, openai.AuthenticationError) or _status(exc) == 401:
        return "auth"
    msg = str(exc).lower()
    if any(m in msg for m in _AUTH_MARKERS):
        return "auth"
    if _status(exc) == 402 or any(m in msg for m in _QUOTA_MARKERS):
        return "quota"
    if (
        isinstance(exc, openai.RateLimitError)
        or _status(exc) == 429
        or any(m in msg for m in _RATE_LIMIT_MARKERS)
    ):
        return "rate_limited"
    return "transient"


def extract_retry_after(exc: Exception) -> float | None:
    for attr in ("retry_after", "retry_after_seconds"):
        v = getattr(exc, attr, None)
        if isinstance(v, (int, float)) and v > 0:
            return float(v)
    return None


def compute_backoff(attempt: int, exc: Exception, policy: RetryPolicy) -> float:
    explicit = extract_retry_after(exc)
    if explicit is not None:
        return float(min(explicit, policy.max_delay_seconds))
    delay = float(min(policy.base_delay_seconds * (2**attempt), policy.max_delay_seconds))
    if policy.jitter:
        delay *= 0.5 + random.random() * 0.5
    return delay
