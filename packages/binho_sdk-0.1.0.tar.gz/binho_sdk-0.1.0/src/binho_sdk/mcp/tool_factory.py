# src/binho_sdk/mcp/tool_factory.py
"""Build Tool proxies from MCP server descriptors."""
from __future__ import annotations

import asyncio
from typing import Any

from binho_sdk.mcp.client import (
    McpProtocolError,
    McpToolDescriptor,
    McpTransportError,
)
from binho_sdk.tools.base import Tool, ToolContext, ToolReturn


def build_mcp_tool(server_name: str, desc: McpToolDescriptor) -> Tool:
    full_name = f"mcp__{server_name}__{desc.name}"

    async def handler(arguments: dict[str, Any], ctx: ToolContext) -> ToolReturn:
        client = ctx.mcp_clients[server_name]
        cfg = ctx.options.mcp_servers.get(server_name)
        timeout = cfg.timeout_seconds if cfg is not None else 30.0
        try:
            result = await asyncio.wait_for(
                client.call_tool(desc.name, arguments),
                timeout=timeout,
            )
        except TimeoutError:
            return ToolReturn(
                content=f"MCP call to {full_name} timed out after {timeout}s",
                is_error=True,
            )
        except McpTransportError as exc:
            return ToolReturn(content=f"MCP transport error: {exc}", is_error=True)
        except McpProtocolError as exc:
            return ToolReturn(content=f"MCP protocol error: {exc}", is_error=True)

        return ToolReturn(content=result.text, is_error=result.is_error)

    return Tool(
        name=full_name,
        description=desc.description,
        parameters_schema=desc.input_schema,
        handler=handler,
        execution_mode="parallel",
        source="mcp",
        mcp_server=server_name,
    )
