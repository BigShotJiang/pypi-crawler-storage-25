# src/binho_sdk/mcp/client.py
"""HTTP MCP client (JSON-RPC 2.0 over POST).

Supports the streamable-HTTP transport (POST for client->server requests).
The client:
  - Advertises ``Accept: application/json, text/event-stream`` on every POST.
  - Parses either a single JSON response or a single-message SSE stream.
  - Round-trips ``Mcp-Session-Id`` once the server assigns one.
  - Validates the server's ``protocolVersion`` matches the client at init.

Server-initiated streaming (GET) and multi-message SSE are out of scope for v1.
The initialize handshake advertises only the ``tools`` capability — see spec §7.
"""
from __future__ import annotations

import itertools
import json
from dataclasses import dataclass
from typing import Any

import httpx

from binho_sdk.errors import BinhoConfigError, ProviderError
from binho_sdk.options import McpServerConfig  # noqa: F401 — re-exported for tests

try:
    import importlib.metadata as _importlib_metadata
    __version__ = _importlib_metadata.version("binho-sdk")
except _importlib_metadata.PackageNotFoundError:
    __version__ = "0.1.0"

PROTOCOL_VERSION = "2025-06-18"


class McpTransportError(ProviderError):
    """Network or transport-level failure talking to an MCP server."""


class McpProtocolError(ProviderError):
    """Server returned a JSON-RPC error response."""


@dataclass
class McpToolDescriptor:
    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass
class McpToolResult:
    text: str
    is_error: bool


class McpClient:
    def __init__(self, name: str, config: McpServerConfig) -> None:
        self.name = name
        self.config = config
        self._http = httpx.AsyncClient(headers=config.headers, timeout=config.timeout_seconds)
        self._id_counter = itertools.count(1)
        self._initialized = False
        self._tools_cache: list[McpToolDescriptor] | None = None
        self._session_id: str | None = None

    async def initialize(self) -> None:
        try:
            init_resp = await self._request(
                "initialize",
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {"tools": {}},
                    "clientInfo": {"name": "binho-sdk", "version": __version__},
                },
                timeout=self.config.init_timeout_seconds,
            )
        except (httpx.ConnectError, httpx.ConnectTimeout) as exc:
            raise BinhoConfigError(f"MCP server {self.name!r} unreachable: {exc}") from exc

        server_version = init_resp.get("protocolVersion")
        if server_version != PROTOCOL_VERSION:
            raise BinhoConfigError(
                f"MCP server {self.name!r} speaks protocol {server_version!r}, "
                f"client speaks {PROTOCOL_VERSION!r}"
            )

        caps = init_resp.get("capabilities", {})
        if "tools" not in caps:
            raise BinhoConfigError(
                f"MCP server {self.name!r} does not advertise the 'tools' capability "
                f"(advertised: {sorted(caps)})"
            )

        # Send the initialized notification.
        await self._notify("notifications/initialized", {})
        self._initialized = True

        # Eagerly fetch and cache the tool list as part of initialization.
        result = await self._request("tools/list", {})
        self._tools_cache = []
        for t in result.get("tools", []):
            self._tools_cache.append(
                McpToolDescriptor(
                    name=t["name"],
                    description=t.get("description", ""),
                    input_schema=t.get("inputSchema", {"type": "object"}),
                )
            )

    async def list_tools(self) -> list[McpToolDescriptor]:
        if not self._initialized:
            raise RuntimeError("McpClient.list_tools called before initialize()")
        if self._tools_cache is not None:
            return self._tools_cache
        # Fallback: fetch if cache not populated (should not happen after initialize()).
        result = await self._request("tools/list", {})
        out: list[McpToolDescriptor] = []
        for t in result.get("tools", []):
            out.append(
                McpToolDescriptor(
                    name=t["name"],
                    description=t.get("description", ""),
                    input_schema=t.get("inputSchema", {"type": "object"}),
                )
            )
        self._tools_cache = out
        return out

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> McpToolResult:
        result = await self._request("tools/call", {"name": name, "arguments": arguments})
        content_parts = result.get("content", []) or []
        text = "\n".join(p.get("text", "") for p in content_parts if p.get("type") == "text")
        return McpToolResult(text=text, is_error=bool(result.get("isError", False)))

    async def close(self) -> None:
        await self._http.aclose()

    # --- internals ---

    def _post_headers(self) -> dict[str, str]:
        h = {"Accept": "application/json, text/event-stream"}
        if self._session_id is not None:
            h["Mcp-Session-Id"] = self._session_id
        return h

    def _capture_session_id(self, resp: httpx.Response) -> None:
        sid = resp.headers.get("mcp-session-id") or resp.headers.get("Mcp-Session-Id")
        if sid and self._session_id is None:
            self._session_id = sid

    async def _request(
        self,
        method: str,
        params: dict[str, Any],
        *,
        timeout: float | None = None,  # noqa: ASYNC109
    ) -> dict[str, Any]:
        rid = next(self._id_counter)
        body: dict[str, Any] = {
            "jsonrpc": "2.0", "id": rid, "method": method, "params": params
        }
        effective_timeout = timeout or self.config.timeout_seconds
        try:
            resp = await self._http.post(
                self.config.url,
                json=body,
                headers=self._post_headers(),
                timeout=effective_timeout,
            )
        except httpx.HTTPError as exc:
            raise McpTransportError(f"{method}: {exc}") from exc
        if resp.status_code >= 400:
            raise McpTransportError(f"{method}: HTTP {resp.status_code}")
        self._capture_session_id(resp)
        data = _decode_jsonrpc_response(resp, expected_id=rid, method=method)
        if "error" in data:
            err = data["error"]
            raise McpProtocolError(f"{method}: {err.get('message')} (code {err.get('code')})")
        return dict(data.get("result", {}))

    async def _notify(self, method: str, params: dict[str, Any]) -> None:
        body: dict[str, Any] = {"jsonrpc": "2.0", "method": method, "params": params}
        try:
            resp = await self._http.post(
                self.config.url, json=body, headers=self._post_headers()
            )
        except httpx.HTTPError as exc:
            raise McpTransportError(f"{method}: {exc}") from exc
        self._capture_session_id(resp)


def _decode_jsonrpc_response(
    resp: httpx.Response, *, expected_id: int, method: str
) -> dict[str, Any]:
    """Decode a JSON-RPC response body, handling both JSON and SSE content types."""
    ctype = resp.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if ctype == "text/event-stream":
        payload = _extract_jsonrpc_from_sse(resp.text, expected_id=expected_id)
        if payload is None:
            raise McpTransportError(
                f"{method}: SSE response contained no JSON-RPC payload"
            )
        return payload
    # Default to JSON for application/json or unset content-type.
    try:
        data = resp.json()
    except ValueError as exc:
        raise McpTransportError(f"{method}: malformed JSON response: {exc}") from exc
    if not isinstance(data, dict):
        raise McpTransportError(f"{method}: expected JSON object, got {type(data).__name__}")
    return data


def _extract_jsonrpc_from_sse(text: str, *, expected_id: int) -> dict[str, Any] | None:
    """Extract the JSON-RPC response matching ``expected_id`` from an SSE body.

    Falls back to the last decodable ``data:`` payload when no id matches — some
    servers stream a single anonymous event. Robust enough for one-shot request /
    response usage; multi-message streaming is not supported.
    """
    last: dict[str, Any] | None = None
    for block in text.split("\n\n"):
        data_lines: list[str] = []
        for line in block.splitlines():
            if line.startswith("data:"):
                data_lines.append(line[5:].lstrip())
        if not data_lines:
            continue
        payload_str = "\n".join(data_lines)
        try:
            obj = json.loads(payload_str)
        except json.JSONDecodeError:
            continue
        if not isinstance(obj, dict):
            continue
        if obj.get("id") == expected_id:
            return obj
        last = obj
    return last
