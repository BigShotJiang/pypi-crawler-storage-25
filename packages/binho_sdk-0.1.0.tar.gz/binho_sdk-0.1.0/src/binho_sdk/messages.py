# src/binho_sdk/messages.py
"""OpenAI-shaped message types (TypedDicts).

These match the wire format `openai.AsyncOpenAI` accepts and returns.
The library intentionally exposes the OpenAI shape rather than Anthropic
content-blocks; consumers of this SDK can pass these dicts directly.
"""
from __future__ import annotations

from typing import Literal, TypedDict


class FunctionCall(TypedDict):
    name: str
    arguments: str  # JSON-encoded string


class ToolCall(TypedDict):
    id: str
    type: Literal["function"]
    function: FunctionCall


class Message(TypedDict, total=False):
    role: Literal["system", "user", "assistant", "tool"]
    content: str | None
    tool_calls: list[ToolCall]      # assistant only
    tool_call_id: str               # tool only
    name: str                       # tool only (the called tool's name)
