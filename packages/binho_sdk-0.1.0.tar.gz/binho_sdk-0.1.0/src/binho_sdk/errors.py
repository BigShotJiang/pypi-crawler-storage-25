# src/binho_sdk/errors.py
"""binho-sdk exception hierarchy.

All errors raised by binho-sdk inherit from BinhoError. Errors related to
talking to the LLM provider inherit from ProviderError; everything else is
either configuration (BinhoConfigError) or a generic BinhoError.
"""
from __future__ import annotations


class BinhoError(Exception):
    """Base class for all binho-sdk errors."""


class BinhoConfigError(BinhoError):
    """Raised at query() start when the configuration is invalid.

    Examples: unknown built-in tool name, MCP server unreachable at initialize,
    referenced MCP tool not in the server's catalog, mcp__<server>__<tool>
    naming a server that isn't configured.
    """


class ProviderError(BinhoError):
    """Base for errors talking to the LLM provider (OpenRouter)."""


class AuthError(ProviderError):
    """Authentication / authorization failed (401, invalid key)."""


class QuotaError(ProviderError):
    """Quota / billing limit reached (402, insufficient_quota)."""


class RateLimitError(ProviderError):
    """Rate limited (429). Caller-visible only after retries are exhausted."""


class TransportError(ProviderError):
    """Generic transport / network failure (connection reset, timeout)."""
