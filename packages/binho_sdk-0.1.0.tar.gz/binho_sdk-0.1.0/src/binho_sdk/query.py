# src/binho_sdk/query.py
"""Public entry point: async def query() -> AsyncIterator[Event]."""
from __future__ import annotations

import os
import re
from collections.abc import AsyncIterator

from binho_sdk.errors import BinhoConfigError
from binho_sdk.events import Event
from binho_sdk.hooks.dispatcher import HookDispatcher
from binho_sdk.loop.runner import run_loop
from binho_sdk.mcp.client import McpClient
from binho_sdk.mcp.tool_factory import build_mcp_tool
from binho_sdk.messages import Message
from binho_sdk.options import Options
from binho_sdk.providers.base import Provider
from binho_sdk.providers.openrouter import OpenRouterProvider
from binho_sdk.tools.base import Tool
from binho_sdk.tools.builtin import BUILTIN_TOOLS

_MCP_NAME_RE = re.compile(r"^mcp__([^_]+(?:_[^_]+)*)__(.+)$")


def _normalize_prompt(prompt: str | list[Message], options: Options) -> list[Message]:
    if isinstance(prompt, str):
        msgs: list[Message] = []
        if options.system_prompt:
            msgs.append({"role": "system", "content": options.system_prompt})
        msgs.append({"role": "user", "content": prompt})
        return msgs
    # list form: caller threads context. Insert system_prompt at front if not already there.
    msgs = list(prompt)
    if options.system_prompt and not (msgs and msgs[0].get("role") == "system"):
        msgs.insert(0, {"role": "system", "content": options.system_prompt})
    return msgs


def _split_mcp(name: str) -> tuple[str, str] | None:
    m = _MCP_NAME_RE.match(name)
    if m is None:
        return None
    return m.group(1), m.group(2)


async def _resolve_tools(
    options: Options,
    mcp_clients: dict[str, McpClient],
) -> dict[str, Tool]:
    resolved: dict[str, Tool] = {}
    sources: list[str | Tool] = list(options.tools)
    for ad in options.agents.values():
        if ad.tools is not None:
            sources.extend(ad.tools)

    # Phase 1: collect required MCP servers from string-form references.
    required_mcp_servers: set[str] = set()
    for entry in sources:
        if isinstance(entry, str):
            split = _split_mcp(entry)
            if split is not None:
                server, _ = split
                if server not in options.mcp_servers:
                    raise BinhoConfigError(
                        f"Tool {entry!r} references MCP server {server!r}"
                        " which is not in Options.mcp_servers."
                    )
                required_mcp_servers.add(server)

    # Phase 2: connect each required server, fetch its catalog, build proxies.
    server_catalogs: dict[str, dict[str, Tool]] = {}
    for server_name in required_mcp_servers:
        cfg = options.mcp_servers[server_name]
        client = McpClient(name=server_name, config=cfg)
        await client.initialize()
        descs = await client.list_tools()
        catalog: dict[str, Tool] = {}
        for d in descs:
            t = build_mcp_tool(server_name, d)
            catalog[t.name] = t
        server_catalogs[server_name] = catalog
        mcp_clients[server_name] = client

    # Phase 3: resolve every entry in `sources` to a Tool.
    seen: set[str] = set()
    for entry in sources:
        if isinstance(entry, str):
            split = _split_mcp(entry)
            if split is not None:
                server, _ = split
                catalog = server_catalogs[server]
                tool = catalog.get(entry)
                if tool is None:
                    available = sorted(catalog.keys())
                    raise BinhoConfigError(
                        f"MCP server {server!r} does not advertise {entry!r}."
                        f" Available: {available}"
                    )
            else:
                tool = BUILTIN_TOOLS.get(entry)
                if tool is None:
                    raise BinhoConfigError(f"Unknown built-in tool: {entry!r}")
        elif isinstance(entry, Tool):
            tool = entry
        else:
            raise BinhoConfigError(
                f"Options.tools entries must be str or Tool, got {type(entry).__name__}"
            )
        if tool.name in seen:
            continue
        seen.add(tool.name)
        resolved[tool.name] = tool
    return resolved


async def query(
    prompt: str | list[Message],
    options: Options,
    *,
    _provider: Provider | None = None,    # injected for tests
) -> AsyncIterator[Event]:
    cwd = options.cwd if options.cwd is not None else os.getcwd()

    api_key = options.api_key or os.environ.get("OPENROUTER_API_KEY")
    if _provider is None:
        if not api_key:
            raise BinhoConfigError("api_key not supplied and OPENROUTER_API_KEY env not set")
        provider: Provider = OpenRouterProvider(
            api_key=api_key,
            base_url=options.base_url,
            http_referer=options.http_referer,
            app_title=options.app_title,
        )
    else:
        provider = _provider

    mcp_clients: dict[str, McpClient] = {}
    try:
        resolved = await _resolve_tools(options, mcp_clients)
        hooks = HookDispatcher(options.hooks)
        messages = _normalize_prompt(prompt, options)
        async for ev in run_loop(
            messages=messages,
            options=options,
            resolved_tools=resolved,
            hooks=hooks,
            provider=provider,
            cwd=cwd,
            mcp_clients=mcp_clients,
        ):
            yield ev
    finally:
        for client in mcp_clients.values():
            await client.close()
