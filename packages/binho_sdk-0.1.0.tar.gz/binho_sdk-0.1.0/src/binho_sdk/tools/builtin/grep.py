# src/binho_sdk/tools/builtin/grep.py
"""Grep tool — shells out to ripgrep (`rg`)."""
from __future__ import annotations

import asyncio
import shutil
from typing import Literal

from pydantic import BaseModel

from binho_sdk.tools.base import Tool, ToolContext, ToolReturn
from binho_sdk.tools.builtin._paths import deny_outside_allowed_paths, resolve_path


class GrepArgs(BaseModel):
    pattern: str
    path: str | None = None
    glob: str | None = None
    type: str | None = None
    output_mode: Literal["content", "files_with_matches", "count"] = "files_with_matches"
    head_limit: int | None = None
    case_insensitive: bool = False


async def _handler(raw_args: dict[str, object], ctx: ToolContext) -> ToolReturn:
    args = GrepArgs.model_validate(raw_args)
    if shutil.which("rg") is None:
        return ToolReturn(
            content="ripgrep (`rg`) is not installed; install it to use the Grep tool.",
            is_error=True,
        )

    target = resolve_path(ctx.cwd, args.path) if args.path else None
    if target is not None:
        err = deny_outside_allowed_paths(target, ctx.options)
        if err:
            return ToolReturn(content=err, is_error=True)

    rg_cmd: list[str] = ["rg", "--no-heading"]
    if args.case_insensitive:
        rg_cmd.append("-i")
    if args.glob:
        rg_cmd.extend(["--glob", args.glob])
    if args.type:
        rg_cmd.extend(["--type", args.type])

    if args.output_mode == "files_with_matches":
        rg_cmd.append("-l")
    elif args.output_mode == "count":
        rg_cmd.append("-c")
    # "content" mode: default rg output

    rg_cmd.append("--")
    rg_cmd.append(args.pattern)
    if target is not None:
        rg_cmd.append(str(target))

    proc = await asyncio.create_subprocess_exec(
        *rg_cmd,
        cwd=ctx.cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()
    out = stdout.decode("utf-8", errors="replace")

    # rg exits 1 when there are no matches — that's not an error from our perspective.
    if proc.returncode not in (0, 1):
        return ToolReturn(content=stderr.decode("utf-8", errors="replace"), is_error=True)

    if args.head_limit is not None:
        lines = out.splitlines()[: args.head_limit]
        out = "\n".join(lines)

    return ToolReturn(content=out)


grep_tool = Tool(
    name="Grep",
    description=(
        "Search files for a regex pattern via ripgrep. "
        "output_mode: 'files_with_matches' (default), 'content', or 'count'."
    ),
    parameters_schema=GrepArgs.model_json_schema(),
    handler=_handler,
    source="builtin",
)
