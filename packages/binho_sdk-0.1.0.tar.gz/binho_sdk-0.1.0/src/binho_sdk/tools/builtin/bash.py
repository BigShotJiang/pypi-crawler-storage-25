# src/binho_sdk/tools/builtin/bash.py
"""Bash tool — runs a command via /bin/sh -c."""
from __future__ import annotations

import asyncio

from pydantic import BaseModel, Field

from binho_sdk.tools.base import Tool, ToolContext, ToolReturn

MAX_OUTPUT_CHARS = 30_000
DEFAULT_TIMEOUT_MS = 120_000
MAX_TIMEOUT_MS = 600_000


class BashArgs(BaseModel):
    command: str
    timeout_ms: int = Field(default=DEFAULT_TIMEOUT_MS, ge=1, le=MAX_TIMEOUT_MS)
    description: str | None = None


def _truncate(text: str) -> str:
    if len(text) <= MAX_OUTPUT_CHARS:
        return text
    cutoff = MAX_OUTPUT_CHARS // 2
    head = text[:cutoff]
    tail = text[-cutoff:]
    truncated_chars = len(text) - len(head) - len(tail)
    return f"{head}\n[output truncated: {truncated_chars} chars]\n{tail}"


async def _handler(raw_args: dict[str, object], ctx: ToolContext) -> ToolReturn:
    args = BashArgs.model_validate(raw_args)
    timeout_s = args.timeout_ms / 1000.0

    proc = await asyncio.create_subprocess_exec(
        "/bin/sh", "-c", args.command,
        cwd=ctx.cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
    except TimeoutError:
        proc.kill()
        await proc.wait()
        return ToolReturn(
            content=f"Command timed out after {args.timeout_ms} ms.",
            is_error=True,
        )

    body = stdout.decode("utf-8", errors="replace")
    if proc.returncode != 0:
        body = f"{body}\n(exit code {proc.returncode})"
    return ToolReturn(content=_truncate(body))


bash_tool = Tool(
    name="Bash",
    description=(
        "Run a shell command via /bin/sh -c. Captures stdout+stderr (combined). "
        "Non-zero exit codes are not errors — the output and code are returned to the model. "
        "Default timeout 2 min, max 10 min."
    ),
    parameters_schema=BashArgs.model_json_schema(),
    handler=_handler,
    source="builtin",
)
