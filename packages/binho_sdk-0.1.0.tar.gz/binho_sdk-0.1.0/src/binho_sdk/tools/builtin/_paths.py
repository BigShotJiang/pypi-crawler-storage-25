# src/binho_sdk/tools/builtin/_paths.py
"""Shared path-resolution helpers for the file/bash built-ins."""
from __future__ import annotations

from pathlib import Path

from binho_sdk.options import Options


def resolve_path(cwd: str, file_path: str) -> Path:
    """Resolve a possibly-relative path against the tool context's cwd."""
    p = Path(file_path)
    if not p.is_absolute():
        p = Path(cwd) / p
    return p.resolve()


def is_inside_allowed(path: Path, allowed: list[Path] | None) -> bool:
    """Return True if `path` is inside any of the configured allowed roots
    (or if no allow-list is configured)."""
    if allowed is None:
        return True
    for root in allowed:
        try:
            path.relative_to(root.resolve())
            return True
        except ValueError:
            continue
    return False


def deny_outside_allowed_paths(path: Path, options: Options) -> str | None:
    """Return an error message if `path` violates Options.allowed_paths,
    otherwise None.
    """
    if not is_inside_allowed(path, options.allowed_paths):
        return f"Path {path} is outside Options.allowed_paths; refusing to access."
    return None
