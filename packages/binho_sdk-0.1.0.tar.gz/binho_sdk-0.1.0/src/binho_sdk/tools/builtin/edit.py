# src/binho_sdk/tools/builtin/edit.py
"""Edit tool — exact string replacement with Read-before-Edit invariant."""
from __future__ import annotations

from pydantic import BaseModel

from binho_sdk.tools.base import Tool, ToolContext, ToolReturn
from binho_sdk.tools.builtin._paths import deny_outside_allowed_paths, resolve_path


class EditArgs(BaseModel):
    file_path: str
    old_string: str
    new_string: str
    replace_all: bool = False


async def _handler(raw_args: dict[str, object], ctx: ToolContext) -> ToolReturn:
    args = EditArgs.model_validate(raw_args)
    path = resolve_path(ctx.cwd, args.file_path)

    err = deny_outside_allowed_paths(path, ctx.options)
    if err:
        return ToolReturn(content=err, is_error=True)

    if not path.is_file():
        return ToolReturn(content=f"File not found: {path}", is_error=True)

    stat = path.stat()
    if not ctx.read_tracker.was_read(str(path), current_mtime_ns=stat.st_mtime_ns):
        return ToolReturn(
            content=(
                f"Cannot edit {path}: file was not Read within this session, "
                "or it has changed on disk since the last Read. Read it first."
            ),
            is_error=True,
        )

    text = path.read_text(encoding="utf-8")
    occurrences = text.count(args.old_string)
    if occurrences == 0:
        return ToolReturn(content=f"old_string not found in {path}.", is_error=True)
    if occurrences > 1 and not args.replace_all:
        return ToolReturn(
            content=(
                f"old_string is not unique in {path} ({occurrences} matches). "
                "Pass replace_all=true to replace every occurrence, or supply more "
                "surrounding context to make old_string unique."
            ),
            is_error=True,
        )

    new_text = (
        text.replace(args.old_string, args.new_string)
        if args.replace_all
        else text.replace(args.old_string, args.new_string, 1)
    )
    path.write_text(new_text, encoding="utf-8")
    ctx.read_tracker.register(str(path), mtime_ns=path.stat().st_mtime_ns)

    n_replaced = occurrences if args.replace_all else 1
    return ToolReturn(content=f"Edited {path}: replaced {n_replaced} occurrence(s).")


edit_tool = Tool(
    name="Edit",
    description=(
        "Replace exact string content in a file. "
        "By default replaces a single unique occurrence; pass replace_all=true to replace all. "
        "Requires a prior Read of the file (and the file must not have changed on disk since)."
    ),
    parameters_schema=EditArgs.model_json_schema(),
    handler=_handler,
    source="builtin",
)
