# src/binho_sdk/tools/builtin/read.py
"""Read tool — numbered-line file reader."""
from __future__ import annotations

from pydantic import BaseModel, Field

from binho_sdk.tools.base import Tool, ToolContext, ToolReturn
from binho_sdk.tools.builtin._paths import deny_outside_allowed_paths, resolve_path

MAX_BYTES = 5 * 1024 * 1024


class ReadArgs(BaseModel):
    file_path: str
    offset: int | None = Field(default=None, description="1-indexed line number to start at")
    limit: int | None = Field(default=None, description="max lines to return")


async def _handler(raw_args: dict[str, object], ctx: ToolContext) -> ToolReturn:
    args = ReadArgs.model_validate(raw_args)
    path = resolve_path(ctx.cwd, args.file_path)

    err = deny_outside_allowed_paths(path, ctx.options)
    if err:
        return ToolReturn(content=err, is_error=True)

    if not path.exists():
        return ToolReturn(content=f"File not found: {path}", is_error=True)
    if not path.is_file():
        return ToolReturn(content=f"Not a regular file: {path}", is_error=True)

    stat = path.stat()
    if stat.st_size > MAX_BYTES:
        return ToolReturn(
            content=f"File {path} is too large ({stat.st_size} bytes; cap is {MAX_BYTES}).",
            is_error=True,
        )

    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return ToolReturn(content=f"File {path} is not valid UTF-8 (binary?).", is_error=True)

    lines = text.splitlines()
    start = (args.offset - 1) if args.offset and args.offset > 0 else 0
    end = (start + args.limit) if args.limit else len(lines)

    rendered = "\n".join(f"{i + 1}\t{line}" for i, line in enumerate(lines[start:end], start=start))
    ctx.read_tracker.register(str(path), mtime_ns=stat.st_mtime_ns)
    return ToolReturn(content=rendered)


read_tool = Tool(
    name="Read",
    description=(
        "Read a file from disk. Returns numbered-line content. "
        "Use `offset` (1-indexed) and `limit` to read large files in chunks. "
        "Edits to a file require a prior Read of that file."
    ),
    parameters_schema=ReadArgs.model_json_schema(),
    handler=_handler,
    source="builtin",
)
