# src/binho_sdk/tools/builtin/glob.py
"""Glob tool — pathlib-backed file finder, sorted by mtime descending."""
from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel

from binho_sdk.tools.base import Tool, ToolContext, ToolReturn
from binho_sdk.tools.builtin._paths import deny_outside_allowed_paths, resolve_path


class GlobArgs(BaseModel):
    pattern: str
    path: str | None = None


async def _handler(raw_args: dict[str, object], ctx: ToolContext) -> ToolReturn:
    args = GlobArgs.model_validate(raw_args)
    base = resolve_path(ctx.cwd, args.path) if args.path else Path(ctx.cwd).resolve()  # noqa: ASYNC240

    err = deny_outside_allowed_paths(base, ctx.options)
    if err:
        return ToolReturn(content=err, is_error=True)

    if not base.is_dir():
        return ToolReturn(content=f"Glob base is not a directory: {base}", is_error=True)

    # pathlib's glob handles both `**/x` and `x` forms.
    matches = list(base.glob(args.pattern))
    matches = [m for m in matches if m.is_file()]
    matches.sort(key=lambda p: p.stat().st_mtime_ns, reverse=True)
    return ToolReturn(content="\n".join(str(m) for m in matches))


glob_tool = Tool(
    name="Glob",
    description=(
        "Find files matching a glob pattern (e.g. '**/*.py'). "
        "Returns absolute paths sorted by modification time descending (newest first)."
    ),
    parameters_schema=GlobArgs.model_json_schema(),
    handler=_handler,
    source="builtin",
)
