# src/binho_sdk/tools/builtin/__init__.py
"""Built-in tools.

After all built-in modules are imported, BUILTIN_TOOLS maps tool name to Tool.
The loop resolves string-form tool names in Options.tools against this dict.
"""
from binho_sdk.tools.base import Tool
from binho_sdk.tools.builtin.bash import bash_tool
from binho_sdk.tools.builtin.edit import edit_tool
from binho_sdk.tools.builtin.glob import glob_tool
from binho_sdk.tools.builtin.grep import grep_tool
from binho_sdk.tools.builtin.read import read_tool
from binho_sdk.tools.builtin.write import write_tool
from binho_sdk.tools.task import task_tool

BUILTIN_TOOLS: dict[str, Tool] = {
    "Read": read_tool,
    "Write": write_tool,
    "Edit": edit_tool,
    "Glob": glob_tool,
    "Grep": grep_tool,
    "Bash": bash_tool,
    "Task": task_tool,
}

__all__ = ["BUILTIN_TOOLS"]
