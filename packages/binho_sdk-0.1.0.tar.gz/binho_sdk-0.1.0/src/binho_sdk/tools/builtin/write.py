# src/binho_sdk/tools/builtin/write.py
"""Write tool — creates or overwrites a file.

Refuses to overwrite an existing file that wasn't Read first (within the same
ToolContext). New file creation is always allowed (subject to allowed_paths).
"""
from __future__ import annotations

from pydantic import BaseModel

from binho_sdk.tools.base import Tool, ToolContext, ToolReturn
from binho_sdk.tools.builtin._paths import deny_outside_allowed_paths, resolve_path


class WriteArgs(BaseModel):
    file_path: str
    content: str


async def _handler(raw_args: dict[str, object], ctx: ToolContext) -> ToolReturn:
    args = WriteArgs.model_validate(raw_args)
    path = resolve_path(ctx.cwd, args.file_path)

    err = deny_outside_allowed_paths(path, ctx.options)
    if err:
        return ToolReturn(content=err, is_error=True)

    if path.exists():
        if not path.is_file():
            return ToolReturn(content=f"{path} exists and is not a regular file.", is_error=True)
        current_mtime_ns = path.stat().st_mtime_ns
        if not ctx.read_tracker.was_read(str(path), current_mtime_ns=current_mtime_ns):
            return ToolReturn(
                content=(
                    f"Refusing to overwrite {path}: file was not Read within this session "
                    "(or has changed on disk since the last Read). Read it first."
                ),
                is_error=True,
            )

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(args.content, encoding="utf-8")
    # Update tracker so subsequent Edits don't re-fail.
    ctx.read_tracker.register(str(path), mtime_ns=path.stat().st_mtime_ns)
    return ToolReturn(content=f"Wrote {len(args.content)} bytes to {path}.")


write_tool = Tool(
    name="Write",
    description=(
        "Write content to a file. Creates parent directories as needed. "
        "Overwriting an existing file requires it to have been Read first within this session."
    ),
    parameters_schema=WriteArgs.model_json_schema(),
    handler=_handler,
    source="builtin",
)
