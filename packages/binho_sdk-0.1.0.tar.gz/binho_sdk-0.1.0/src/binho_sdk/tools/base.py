# src/binho_sdk/tools/base.py
"""Tool definition, decorator, and tool-context shape.

Tools store parameters as a JSON Schema dict (already in the form OpenRouter
expects). The @tool decorator generates a thin wrapper handler that validates
incoming args via Pydantic, then calls the user function with a typed instance.

ReadTracker enforces the "Read before Edit" invariant for built-ins. It lives
in ToolContext rather than as module-level state because each query() call
gets its own tracker (no cross-call leakage).
"""
from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, get_type_hints

from pydantic import BaseModel

from binho_sdk.events import Event
from binho_sdk.messages import Message

if TYPE_CHECKING:
    from binho_sdk.hooks.dispatcher import HookDispatcher
    from binho_sdk.mcp.client import McpClient
    from binho_sdk.options import Options


ExecutionMode = Literal["parallel", "sequential"]
ToolSource = Literal["builtin", "user", "mcp"]


@dataclass
class ToolReturn:
    content: str
    is_error: bool = False
    terminate: bool = False


@dataclass
class Tool:
    name: str
    description: str
    parameters_schema: dict[str, Any]
    handler: Callable[[dict[str, Any], ToolContext], Awaitable[str | ToolReturn]]
    execution_mode: ExecutionMode = "parallel"
    source: ToolSource = "user"
    mcp_server: str | None = None


class ReadTracker:
    """Tracks (path -> mtime_ns) reads within a single query() call.

    Used by Edit/Write to refuse mutating a file that wasn't Read first
    (or has changed on disk since the recorded Read).
    """

    def __init__(self) -> None:
        self._reads: dict[str, int] = {}

    def register(self, path: str, mtime_ns: int) -> None:
        self._reads[path] = mtime_ns

    def was_read(self, path: str, current_mtime_ns: int) -> bool:
        recorded = self._reads.get(path)
        return recorded is not None and recorded == current_mtime_ns


class _UsageAccumulator:
    """Forward declaration for typing — concrete class lives in loop/."""


@dataclass
class ToolContext:
    # Public — user-defined handlers may rely on these:
    cwd: str
    options: Options
    agent_id: str | None
    agent_type: str | None
    tool_use_id: str
    tool_name: str
    messages: list[Message]
    read_tracker: ReadTracker

    # Internal — used by built-in Task and MCP proxy handlers only:
    hook_dispatcher: HookDispatcher
    usage_accumulator: Any  # binho_sdk.loop.runner.UsageAccumulator
    emit: Callable[[Event], None]
    tool_mcp_server: str | None
    mcp_clients: dict[str, McpClient]
    provider: Any  # binho_sdk.providers.base.Provider — used by Task tool to recurse
    resolved_tools: dict[str, Tool]  # loop's resolved tool table — used by Task tool to inherit


# NOTE: tests across all subsequent chunks construct ToolContext directly via a
# `make_ctx` helper. Every such helper must populate the seven internal fields,
# even if the test doesn't exercise subagents. Use `provider=None` (type: ignore)
# and `resolved_tools={}` for tests that aren't subagent-related.


def tool(
    *,
    name: str,
    description: str,
    execution_mode: ExecutionMode = "parallel",
) -> Callable[[Callable[..., Awaitable[str | ToolReturn]]], Tool]:
    """Decorator that turns an async function into a Tool.

    The function's first argument must be type-annotated with a Pydantic
    BaseModel subclass; that becomes the tool's input schema. The second
    argument must be ToolContext.

    Usage:
        class GrepArgs(BaseModel):
            pattern: str

        @tool(name="grep", description="...")
        async def grep(args: GrepArgs, ctx: ToolContext) -> str:
            ...
    """

    def decorator(fn: Callable[..., Awaitable[str | ToolReturn]]) -> Tool:
        sig = inspect.signature(fn)
        params = list(sig.parameters.values())
        if len(params) != 2:
            raise TypeError(
                f"@tool function {fn.__name__} must have exactly two parameters (args, ctx)"
            )

        # Resolve the first-parameter annotation. When `from __future__ import annotations`
        # is active, all annotations become strings (PEP 563). We try three strategies:
        # 1. Direct: annotation is already a type object (common when not using PEP 563).
        # 2. get_type_hints: resolves string annotations via fn.__globals__ (module-level).
        # 3. Frame locals: resolves locally-defined classes by walking up the call stack.
        first_param = params[0]
        ann = first_param.annotation
        args_type: type | None
        if ann is inspect.Parameter.empty:
            args_type = None
        elif isinstance(ann, type) and issubclass(ann, BaseModel):
            args_type = ann
        elif isinstance(ann, str):
            # Strategy 2: module-level resolution
            resolved: Any = None
            try:
                hints = get_type_hints(fn)
                resolved = hints.get(first_param.name)
            except Exception:  # noqa: BLE001
                pass
            if resolved is None or not (
                isinstance(resolved, type) and issubclass(resolved, BaseModel)
            ):
                # Strategy 3: walk up caller frames looking for the name in locals.
                # decorator() is called directly from user code (the @tool(...) site),
                # so f_back is the frame that applied the decorator.
                frame = inspect.currentframe()
                caller = frame.f_back if frame else None  # caller of decorator()
                while caller is not None:
                    candidate = caller.f_locals.get(ann)
                    if (
                        candidate is not None
                        and isinstance(candidate, type)
                        and issubclass(candidate, BaseModel)
                    ):
                        resolved = candidate
                        break
                    caller = caller.f_back
            args_type = (
                resolved
                if (
                    resolved is not None
                    and isinstance(resolved, type)
                    and issubclass(resolved, BaseModel)
                )
                else None
            )
        else:
            args_type = None

        if args_type is None or not (
            isinstance(args_type, type) and issubclass(args_type, BaseModel)
        ):
            raise TypeError(
                f"@tool function {fn.__name__}: first parameter must be type-annotated "
                "with a Pydantic BaseModel subclass"
            )

        schema = args_type.model_json_schema()

        async def wrapper(raw_args: dict[str, Any], ctx: ToolContext) -> ToolReturn:
            validated = args_type.model_validate(raw_args)
            result = await fn(validated, ctx)
            if isinstance(result, ToolReturn):
                return result
            return ToolReturn(content=result)

        return Tool(
            name=name,
            description=description,
            parameters_schema=schema,
            handler=wrapper,
            execution_mode=execution_mode,
            source="user",
        )

    return decorator
