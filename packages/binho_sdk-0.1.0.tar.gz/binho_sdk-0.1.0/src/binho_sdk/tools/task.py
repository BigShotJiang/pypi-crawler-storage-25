# src/binho_sdk/tools/task.py
"""Task tool — spawns a registered subagent via a recursive run_loop call."""
from __future__ import annotations

import uuid

from pydantic import BaseModel

from binho_sdk.events import Event, Result, SubagentEnd, SubagentStart
from binho_sdk.messages import Message
from binho_sdk.tools.base import Tool, ToolContext, ToolReturn


class TaskArgs(BaseModel):
    subagent_type: str
    description: str
    prompt: str


def _last_assistant_text(messages: list[Message]) -> str:
    for m in reversed(messages):
        if m.get("role") == "assistant":
            content = m.get("content")
            if isinstance(content, str) and content:
                return content
    return ""


async def _handler(raw_args: dict[str, object], ctx: ToolContext) -> ToolReturn:
    args = TaskArgs.model_validate(raw_args)

    agent_def = ctx.options.agents.get(args.subagent_type)
    if agent_def is None:
        return ToolReturn(
            content=f"Unknown agent type: {args.subagent_type!r}. "
                    f"Configured agents: {sorted(ctx.options.agents)}",
            is_error=True,
        )

    # Avoid circular import.
    from binho_sdk.loop.runner import run_loop  # noqa: PLC0415
    from binho_sdk.tools.builtin import BUILTIN_TOOLS  # noqa: PLC0415

    # Resolve subagent's tools.
    # - If agent_def.tools is None: inherit ALL of the parent's resolved tools
    #   (including MCP-served tools, which the parent's query() already
    #   initialized and built proxies for — they live in ctx.resolved_tools).
    # - If agent_def.tools is set: each entry is either a built-in name string,
    #   an mcp__server__tool string (looked up in ctx.resolved_tools — already
    #   resolved by the parent's query() since the parent's tool list or another
    #   agent's tool list referenced the same server), or a Tool object.
    if agent_def.tools is None:
        sub_resolved: dict[str, Tool] = dict(ctx.resolved_tools)
    else:
        sub_resolved = {}
        for entry in agent_def.tools:
            if isinstance(entry, str):
                if entry.startswith("mcp__"):
                    t = ctx.resolved_tools.get(entry)
                    if t is None:
                        return ToolReturn(
                            content=(
                                f"Subagent {args.subagent_type!r} references MCP tool"
                                f" {entry!r}, but it was not resolved at query() start."
                                " Add it to Options.tools or to another agent's tools"
                                " list so the parent connects to its server."
                            ),
                            is_error=True,
                        )
                    sub_resolved[t.name] = t
                else:
                    t = BUILTIN_TOOLS.get(entry)
                    if t is None:
                        return ToolReturn(
                            content=f"Subagent tool not found: {entry!r}",
                            is_error=True,
                        )
                    sub_resolved[t.name] = t
            elif isinstance(entry, Tool):
                sub_resolved[entry.name] = entry

    sub_options = ctx.options.with_overrides(
        model=agent_def.model or ctx.options.model,
        tools=list(sub_resolved.values()),
        max_turns=agent_def.max_turns,
        permission_mode=agent_def.permission_mode or ctx.options.permission_mode,
        system_prompt=None,
    )

    sub_messages: list[Message] = [
        {"role": "system", "content": agent_def.prompt},
        {"role": "user", "content": args.prompt},
    ]

    sub_id = uuid.uuid4().hex[:12]
    ctx.emit(SubagentStart(agent_type=args.subagent_type, agent_id=sub_id))

    final_text = ""

    def _on_sub_event(ev: Event) -> None:
        ctx.emit(ev)

    async for ev in run_loop(
        messages=sub_messages,
        options=sub_options,
        resolved_tools=sub_resolved,
        hooks=ctx.hook_dispatcher,
        provider=ctx.provider,
        cwd=ctx.cwd,
        agent_id=sub_id,
        agent_type=args.subagent_type,
        usage_acc=ctx.usage_accumulator,
        mcp_clients=ctx.mcp_clients,
        on_event=_on_sub_event,
    ):
        if isinstance(ev, Result):
            final_text = _last_assistant_text(ev.messages)
            ctx.emit(SubagentEnd(agent_id=sub_id, result=final_text))
        else:
            ctx.emit(ev)

    return ToolReturn(content=final_text)


task_tool = Tool(
    name="Task",
    description=(
        "Spawn a registered subagent (a fresh agent with its own system prompt and tool set). "
        "subagent_type names an entry in Options.agents. "
        "The subagent runs to completion; only its final assistant text is returned to you"
        " as the tool result."
    ),
    parameters_schema=TaskArgs.model_json_schema(),
    handler=_handler,
    source="builtin",
)
