# src/binho_sdk/loop/tool_dispatch.py
"""Tool dispatcher: preflight + parallel/sequential execution.

Spec §4 reference. Source-order ToolResult emission, BlockedPlan synthesis,
hook firing points.
"""
from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass

import jsonschema  # type: ignore[import-untyped]

from binho_sdk.events import Event, ToolResult, ToolUse
from binho_sdk.hooks.dispatcher import HookDispatcher
from binho_sdk.hooks.events import HookContext
from binho_sdk.messages import ToolCall
from binho_sdk.options import Options
from binho_sdk.permissions.modes import (
    CanUseToolInput,
    PermissionResult,
    default_decide,
)
from binho_sdk.tools.base import Tool, ToolContext, ToolReturn

CtxFactory = Callable[[Options, HookDispatcher], ToolContext]


@dataclass
class _RunnablePlan:
    tool: Tool
    args: dict[str, object]
    tool_use_id: str
    source_index: int


@dataclass
class _BlockedPlan:
    tool_name: str
    args: dict[str, object]
    tool_use_id: str
    source_index: int
    reason: str


_Plan = _RunnablePlan | _BlockedPlan


async def _resolve_can_use_tool(options: Options, inp: CanUseToolInput) -> PermissionResult:
    if options.can_use_tool is not None:
        return await options.can_use_tool(inp)
    return default_decide(inp)


async def _preflight_one(
    tc: ToolCall,
    source_index: int,
    resolved: dict[str, Tool],
    options: Options,
    hooks: HookDispatcher,
    ctx_factory: CtxFactory,
) -> _Plan:
    name = tc["function"]["name"]
    raw_args_str = tc["function"].get("arguments") or "{}"
    try:
        raw_args = json.loads(raw_args_str)
    except json.JSONDecodeError as exc:
        return _BlockedPlan(
            tool_name=name, args={}, tool_use_id=tc["id"], source_index=source_index,
            reason=f"malformed JSON arguments: {exc}",
        )

    tool = resolved.get(name)
    if tool is None:
        return _BlockedPlan(
            tool_name=name, args=raw_args, tool_use_id=tc["id"], source_index=source_index,
            reason=f"unknown tool: {name}",
        )

    # Shallow JSON Schema validation (uniform across builtin/user/mcp).
    try:
        jsonschema.validate(raw_args, tool.parameters_schema)
    except jsonschema.ValidationError as exc:
        return _BlockedPlan(
            tool_name=name, args=raw_args, tool_use_id=tc["id"], source_index=source_index,
            reason=f"argument validation failed: {exc.message}",
        )

    # PreToolUse hooks.
    base_ctx = ctx_factory(options, hooks)
    hook_ctx = HookContext(
        event="PreToolUse", messages=base_ctx.messages, cwd=base_ctx.cwd,
        options=options,
        tool_name=name, tool_input=raw_args, tool_use_id=tc["id"],
        agent_type=base_ctx.agent_type, agent_id=base_ctx.agent_id,
    )
    hook_result = await hooks.fire("PreToolUse", hook_ctx)
    if hook_result and hook_result.decision == "deny":
        return _BlockedPlan(
            tool_name=name, args=raw_args, tool_use_id=tc["id"], source_index=source_index,
            reason=hook_result.reason or "denied by PreToolUse hook",
        )
    if hook_result and hook_result.modified_input is not None:
        raw_args = hook_result.modified_input

    # can_use_tool gate.
    cu_inp = CanUseToolInput(
        tool_name=name, tool_input=raw_args, tool_use_id=tc["id"],
        agent_id=base_ctx.agent_id, agent_type=base_ctx.agent_type,
        permission_mode=options.permission_mode, suggestions=[],
    )
    cu_res = await _resolve_can_use_tool(options, cu_inp)
    if cu_res.behavior == "deny":
        return _BlockedPlan(
            tool_name=name, args=raw_args, tool_use_id=tc["id"], source_index=source_index,
            reason=cu_res.message or "denied by can_use_tool",
        )
    if cu_res.behavior == "ask":
        mode = options.permission_mode
        return _BlockedPlan(
            tool_name=name, args=raw_args, tool_use_id=tc["id"], source_index=source_index,
            reason=(
                f"Tool '{name}' is gated under permission_mode={mode!r} "
                f"(no interactive UI in v1; supply Options.can_use_tool to override)."
            ),
        )
    if cu_res.updated_input is not None:
        raw_args = cu_res.updated_input

    return _RunnablePlan(tool=tool, args=raw_args, tool_use_id=tc["id"], source_index=source_index)


async def _execute_runnable(
    plan: _RunnablePlan,
    options: Options,
    hooks: HookDispatcher,
    ctx_factory: CtxFactory,
) -> tuple[ToolResult, bool]:
    """Execute a runnable plan; return (public ToolResult, terminate-flag).

    The terminate-flag is `ToolReturn.terminate AND not is_error`. The runner
    uses these flags to evaluate the all-runnable-results-terminate condition.
    """
    base_ctx = ctx_factory(options, hooks)
    tool_ctx = ToolContext(
        cwd=base_ctx.cwd, options=base_ctx.options,
        agent_id=base_ctx.agent_id, agent_type=base_ctx.agent_type,
        tool_use_id=plan.tool_use_id, tool_name=plan.tool.name,
        messages=base_ctx.messages, read_tracker=base_ctx.read_tracker,
        hook_dispatcher=hooks, usage_accumulator=base_ctx.usage_accumulator,
        emit=base_ctx.emit,
        tool_mcp_server=plan.tool.mcp_server,
        mcp_clients=base_ctx.mcp_clients,
        provider=base_ctx.provider,
        resolved_tools=base_ctx.resolved_tools,
    )
    try:
        ret = await plan.tool.handler(plan.args, tool_ctx)
    except Exception as exc:  # noqa: BLE001 - explicit envelope into ToolReturn
        return ToolResult(id=plan.tool_use_id, content=str(exc), is_error=True), False

    if isinstance(ret, ToolReturn):
        content, is_error, terminate = ret.content, ret.is_error, ret.terminate
    else:
        content, is_error, terminate = str(ret), False, False

    # PostToolUse hooks.
    post_ctx = HookContext(
        event="PostToolUse", messages=base_ctx.messages, cwd=base_ctx.cwd,
        options=options,
        tool_name=plan.tool.name, tool_input=plan.args, tool_use_id=plan.tool_use_id,
        tool_result=content, is_error=is_error,
        agent_type=base_ctx.agent_type, agent_id=base_ctx.agent_id,
    )
    hook_result = await hooks.fire("PostToolUse", post_ctx)
    if hook_result and hook_result.modified_output is not None:
        content = hook_result.modified_output

    return (
        ToolResult(id=plan.tool_use_id, content=content, is_error=is_error),
        terminate and not is_error,
    )


async def dispatch_tools(
    tool_calls: list[ToolCall],
    resolved: dict[str, Tool],
    options: Options,
    hooks: HookDispatcher,
    ctx_factory: CtxFactory,
    *,
    terminates_out: list[bool] | None = None,
) -> AsyncIterator[Event]:
    """Dispatch a batch of tool calls.

    Yields ToolUse events in source order, then ToolResult events in source
    order (regardless of completion order). If `terminates_out` is provided,
    one boolean is appended per *runnable* plan: True iff the underlying
    handler returned `ToolReturn(terminate=True)` and the result was not an
    error. Blocked plans contribute nothing to `terminates_out`.
    """
    plans: list[_Plan] = []
    for i, tc in enumerate(tool_calls):
        plans.append(await _preflight_one(tc, i, resolved, options, hooks, ctx_factory))

    sequential = any(
        isinstance(p, _RunnablePlan) and p.tool.execution_mode == "sequential"
        for p in plans
    )

    # Pre-emit ToolUse events in source order for ALL plans (blocked or runnable),
    # so consumers always see the call before the result.
    tool_use_events: dict[int, ToolUse] = {}
    for p in plans:
        name = p.tool.name if isinstance(p, _RunnablePlan) else p.tool_name
        tool_use_events[p.source_index] = ToolUse(id=p.tool_use_id, name=name, arguments=p.args)
    for i in sorted(tool_use_events):
        yield tool_use_events[i]

    # Execute and collect results, keyed by source_index for ordered emission.
    results: dict[int, ToolResult] = {}
    runnable_terminates_by_index: dict[int, bool] = {}
    if sequential:
        for p in sorted(plans, key=lambda x: x.source_index):
            if isinstance(p, _BlockedPlan):
                results[p.source_index] = ToolResult(
                    id=p.tool_use_id, content=p.reason, is_error=True
                )
            else:
                res, term = await _execute_runnable(p, options, hooks, ctx_factory)
                results[p.source_index] = res
                runnable_terminates_by_index[p.source_index] = term
    else:
        sem = asyncio.Semaphore(options.max_tool_concurrency)

        async def run_one(p: _Plan) -> tuple[int, ToolResult, bool | None]:
            if isinstance(p, _BlockedPlan):
                return (
                    p.source_index,
                    ToolResult(id=p.tool_use_id, content=p.reason, is_error=True),
                    None,
                )
            async with sem:
                res, term = await _execute_runnable(p, options, hooks, ctx_factory)
                return p.source_index, res, term

        completed = await asyncio.gather(*(run_one(p) for p in plans))
        for idx, res, maybe_term in completed:
            results[idx] = res
            if maybe_term is not None:
                runnable_terminates_by_index[idx] = maybe_term

    for i in sorted(results):
        yield results[i]

    if terminates_out is not None:
        for i in sorted(runnable_terminates_by_index):
            terminates_out.append(runnable_terminates_by_index[i])
