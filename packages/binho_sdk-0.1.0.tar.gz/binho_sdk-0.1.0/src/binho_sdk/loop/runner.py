# src/binho_sdk/loop/runner.py
"""Turn loop. Yields the public Event stream; final event is always Result."""
from __future__ import annotations

import json
import logging
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from binho_sdk.mcp.client import McpClient

from binho_sdk.events import (
    Event,
    Result,
    TextDelta,
    ToolResult,
    TurnEnd,
    TurnStart,
    Usage,
)
from binho_sdk.hooks.dispatcher import HookDispatcher
from binho_sdk.hooks.events import HookContext
from binho_sdk.loop.token_budget import estimate_tokens
from binho_sdk.loop.tool_dispatch import dispatch_tools
from binho_sdk.messages import Message, ToolCall
from binho_sdk.options import Options
from binho_sdk.providers.base import (
    Provider,
    ProviderDone,
    ProviderTextDelta,
    ProviderToolCall,
    ProviderUsage,
)
from binho_sdk.tools.base import ReadTracker, Tool, ToolContext

logger = logging.getLogger("binho_sdk.loop.runner")


@dataclass
class UsageAccumulator:
    total: Usage = field(default_factory=lambda: Usage(input_tokens=0, output_tokens=0))

    def add(self, u: Usage) -> None:
        self.total = self.total + u


def _make_tool_call_dict(
    id_: str, name: str, args: dict[str, object], raw_arguments: str | None = None
) -> ToolCall:
    # When raw_arguments is set the provider couldn't parse the model's JSON.
    # Store the broken string verbatim so the dispatcher's json.loads raises
    # JSONDecodeError and produces a _BlockedPlan with a clear reason.
    arguments_str = raw_arguments if raw_arguments is not None else json.dumps(args)
    return {
        "id": id_,
        "type": "function",
        "function": {"name": name, "arguments": arguments_str},
    }


async def run_loop(
    *,
    messages: list[Message],
    options: Options,
    resolved_tools: dict[str, Tool],
    hooks: HookDispatcher,
    provider: Provider,
    cwd: str,
    agent_id: str | None = None,
    agent_type: str | None = None,
    read_tracker: ReadTracker | None = None,
    usage_acc: UsageAccumulator | None = None,
    mcp_clients: dict[str, McpClient] | None = None,
    on_event: Callable[[Event], None] | None = None,
) -> AsyncIterator[Event]:
    """The turn loop. Yields events; final event is always Result.

    `on_event` is an internal callback used by the Task tool to forward
    subagent events into the parent's outer stream.
    """
    read_tracker = read_tracker or ReadTracker()
    usage_acc = usage_acc or UsageAccumulator()
    mcp_clients = mcp_clients or {}
    hist = list(messages)

    # Events emitted synchronously by tool handlers (e.g. SubagentStart/End)
    # are buffered here so the runner can yield them after dispatch_tools.
    _emitted: list[Event] = []

    def _emit(ev: Event) -> None:
        if on_event is not None:
            on_event(ev)
        else:
            _emitted.append(ev)

    def _ctx_factory(opts: Options, hd: HookDispatcher) -> ToolContext:
        return ToolContext(
            cwd=cwd, options=opts,
            agent_id=agent_id, agent_type=agent_type,
            tool_use_id="", tool_name="",
            messages=hist, read_tracker=read_tracker,
            hook_dispatcher=hd, usage_accumulator=usage_acc,
            emit=_emit, tool_mcp_server=None, mcp_clients=mcp_clients,
            provider=provider, resolved_tools=resolved_tools,
        )

    turn = 0
    while True:
        turn += 1
        if turn > options.max_turns:
            yield Result(messages=hist, usage=usage_acc.total, stop_reason="max_turns")
            return

        yield TurnStart(turn=turn)

        # Streamed LLM call.
        text_buf = ""
        tool_calls: list[ToolCall] = []
        async for pev in provider.stream(
            messages=hist, tools=list(resolved_tools.values()), options=options
        ):
            if isinstance(pev, ProviderTextDelta):
                text_buf += pev.delta
                yield TextDelta(delta=pev.delta)
            elif isinstance(pev, ProviderToolCall):
                tc = _make_tool_call_dict(pev.id, pev.name, pev.arguments, pev.raw_arguments)
                tool_calls.append(tc)
            elif isinstance(pev, ProviderUsage):
                usage_acc.add(pev.usage)
            elif isinstance(pev, ProviderDone):
                pass  # finish reason consumed implicitly

        assistant_msg: Message = {
            "role": "assistant",
            "content": text_buf or None,
        }
        if tool_calls:
            assistant_msg["tool_calls"] = tool_calls
        hist.append(assistant_msg)

        if not tool_calls:
            stop_ctx = HookContext(
                event="Stop", messages=hist, cwd=cwd, options=options,
                agent_type=agent_type, agent_id=agent_id,
            )
            try:
                stop_result = await hooks.fire("Stop", stop_ctx)
            except Exception:
                logger.exception("Stop hook raised")
                stop_result = None
            if stop_result and stop_result.decision == "deny":
                yield TurnEnd(turn=turn)
                continue
            yield TurnEnd(turn=turn)
            yield Result(messages=hist, usage=usage_acc.total, stop_reason="end_turn")
            return

        # Dispatch tools. The dispatcher fills `terminates_out` with one
        # boolean per runnable plan (non-error AND ToolReturn.terminate=True).
        # Blocked plans don't contribute. The runner uses this to evaluate the
        # all-runnable-results-terminate stop condition.
        terminates: list[bool] = []
        tool_use_evs: list[Event] = []
        tool_result_evs: list[ToolResult] = []
        async for ev in dispatch_tools(
            tool_calls=tool_calls,
            resolved=resolved_tools,
            options=options,
            hooks=hooks,
            ctx_factory=_ctx_factory,
            terminates_out=terminates,
        ):
            if isinstance(ev, ToolResult):
                tool_result_evs.append(ev)
            else:
                tool_use_evs.append(ev)

        # Emit ToolUse events first (source order), then any events buffered by
        # tool handlers via ctx.emit (e.g. SubagentStart/End from the Task tool),
        # then ToolResult events. This ensures subagent envelopes appear BEFORE
        # the parent's ToolResult for that Task call, matching spec ordering.
        for ev in tool_use_evs:
            yield ev
        for ev in _emitted:
            yield ev
        _emitted.clear()
        for ev in tool_result_evs:
            yield ev
            hist.append({"role": "tool", "tool_call_id": ev.id, "content": ev.content})

        yield TurnEnd(turn=turn)

        # If every runnable tool's underlying ToolReturn set terminate=True, stop.
        if terminates and all(terminates):
            yield Result(messages=hist, usage=usage_acc.total, stop_reason="tool_terminate")
            return

        if options.context_window is not None:
            estimated = estimate_tokens(hist)
            if estimated > options.context_window * options.context_safety_margin:
                yield Result(messages=hist, usage=usage_acc.total, stop_reason="context_full")
                return
