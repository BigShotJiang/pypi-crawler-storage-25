# src/binho_sdk/loop/token_budget.py
"""Fast heuristic token estimator: chars/4 plus a small per-message overhead.

We never call a real tokenizer in the loop hot path. This is a safety check
to bail out before we exceed the model's context window, not an accounting
mechanism. Real token counts come from the provider via Usage events.
"""
from __future__ import annotations

from binho_sdk.messages import Message

_PER_MESSAGE_OVERHEAD = 4


def estimate_tokens(messages: list[Message]) -> int:
    total = 0
    for msg in messages:
        total += _PER_MESSAGE_OVERHEAD
        content = msg.get("content")
        if isinstance(content, str):
            total += len(content) // 4
        for tc in msg.get("tool_calls", []) or []:
            fn = tc.get("function", {})
            total += len(fn.get("name", "")) // 4
            total += len(fn.get("arguments", "")) // 4
    return total
