# src/binho_sdk/__init__.py
"""binho-sdk: Python agent SDK on top of OpenRouter with MCP client support."""
from binho_sdk.errors import (
    AuthError,
    BinhoConfigError,
    BinhoError,
    ProviderError,
    QuotaError,
    RateLimitError,
    TransportError,
)
from binho_sdk.events import (
    Event,
    Result,
    SubagentEnd,
    SubagentStart,
    TextDelta,
    ToolResult,
    ToolUse,
    TurnEnd,
    TurnStart,
    Usage,
)
from binho_sdk.hooks import HookCallback, HookContext, HookEvent, HookResult
from binho_sdk.messages import Message, ToolCall
from binho_sdk.options import AgentDefinition, McpServerConfig, Options
from binho_sdk.permissions import (
    CanUseTool,
    CanUseToolInput,
    PermissionMode,
    PermissionResult,
    PermissionUpdate,
)
from binho_sdk.query import query
from binho_sdk.tools import Tool, ToolContext, ToolReturn, tool

__version__ = "0.1.0"

__all__ = [
    # version
    "__version__",
    # events
    "Event",
    "Result",
    "SubagentEnd",
    "SubagentStart",
    "TextDelta",
    "ToolResult",
    "ToolUse",
    "TurnEnd",
    "TurnStart",
    "Usage",
    # errors
    "AuthError",
    "BinhoConfigError",
    "BinhoError",
    "ProviderError",
    "QuotaError",
    "RateLimitError",
    "TransportError",
    # messages
    "Message",
    "ToolCall",
    # options
    "AgentDefinition",
    "McpServerConfig",
    "Options",
    # permissions
    "CanUseTool",
    "CanUseToolInput",
    "PermissionMode",
    "PermissionResult",
    "PermissionUpdate",
    # hooks
    "HookCallback",
    "HookContext",
    "HookEvent",
    "HookResult",
    # tools
    "Tool",
    "ToolContext",
    "ToolReturn",
    "tool",
    # entry point
    "query",
]
