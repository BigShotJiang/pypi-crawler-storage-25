# src/binho_sdk/options.py
"""Public Options, AgentDefinition, and McpServerConfig.

These are the primary public surfaces for configuring a query() call.
Field names and types are part of the v1 stability promise.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

from binho_sdk.permissions.modes import CanUseTool, PermissionMode

if TYPE_CHECKING:
    # Forward-only imports to avoid cycles. tools.base and hooks.events depend on
    # nothing that imports options.py.
    from binho_sdk.hooks.events import HookCallback, HookEvent
    from binho_sdk.tools.base import Tool


@dataclass
class McpServerConfig:
    url: str
    headers: dict[str, str] = field(default_factory=dict)
    timeout_seconds: float = 30.0
    init_timeout_seconds: float = 10.0


@dataclass
class AgentDefinition:
    description: str
    prompt: str
    tools: list[str | Tool] | None = None
    model: str | None = None
    max_turns: int = 25
    permission_mode: PermissionMode | None = None


@dataclass
class Options:
    # Required
    model: str

    # Auth and transport
    api_key: str | None = None
    base_url: str = "https://openrouter.ai/api/v1"
    http_referer: str | None = None
    app_title: str | None = None
    extra_headers: dict[str, str] = field(default_factory=dict)

    # Conversation shape
    system_prompt: str | None = None
    tools: list[str | Tool] = field(default_factory=list)
    agents: dict[str, AgentDefinition] = field(default_factory=dict)
    hooks: dict[HookEvent, list[HookCallback]] = field(default_factory=dict)

    # MCP
    mcp_servers: dict[str, McpServerConfig] = field(default_factory=dict)

    # Permissions
    permission_mode: PermissionMode = "default"
    can_use_tool: CanUseTool | None = None

    # Loop knobs
    max_turns: int = 50
    max_tool_concurrency: int = 10
    context_window: int | None = None
    context_safety_margin: float = 0.95
    cwd: str | None = None
    allowed_paths: list[Path] | None = None

    # Per-request output cap. When set, passed through as the OpenAI
    # ``max_tokens`` field on every chat/completions call. Useful to keep
    # OpenRouter's per-request credit reservation small — by default the
    # provider reserves the model's full output context, which can exhaust
    # an account's available credit at high concurrency. Leave None to use
    # the model's default ceiling.
    max_tokens: int | None = None

    # OpenRouter routing
    allow_provider_fallback: bool = False
    provider_routing: dict[str, Any] | None = None

    def with_overrides(self, **kwargs: Any) -> Options:
        """Shallow-replace fields and return a new Options.

        Used by the Task tool to derive a subagent's options without mutating
        the parent's. Mutable collections are inherited by reference, which is
        safe because the loop never mutates Options after query() start.
        """
        return replace(self, **kwargs)
