"""Sanity tests for the public Message type alias and ToolCall dict."""
from binho_sdk.messages import Message, ToolCall


def test_user_message_round_trips():
    msg: Message = {"role": "user", "content": "hello"}
    assert msg["role"] == "user"
    assert msg["content"] == "hello"


def test_assistant_message_with_tool_call():
    tc: ToolCall = {
        "id": "call_1",
        "type": "function",
        "function": {"name": "Read", "arguments": '{"file_path": "x.py"}'},
    }
    msg: Message = {"role": "assistant", "content": None, "tool_calls": [tc]}
    assert msg["tool_calls"][0]["id"] == "call_1"


def test_tool_message_carries_call_id():
    msg: Message = {"role": "tool", "tool_call_id": "call_1", "content": "result"}
    assert msg["tool_call_id"] == "call_1"
