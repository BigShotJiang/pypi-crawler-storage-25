"""HookDispatcher precedence and exception semantics (spec §8)."""
from __future__ import annotations

import pytest

from binho_sdk.hooks.dispatcher import HookDispatcher
from binho_sdk.hooks.events import HookContext, HookResult
from binho_sdk.options import Options


def make_ctx(event="PreToolUse", **kw):
    return HookContext(
        event=event,
        messages=[],
        cwd="/tmp",
        options=Options(model="m"),
        tool_name=kw.get("tool_name", "Read"),
        tool_input=kw.get("tool_input", {}),
        tool_use_id=kw.get("tool_use_id", "t1"),
    )


@pytest.mark.asyncio
async def test_no_hooks_returns_none():
    d = HookDispatcher({})
    assert await d.fire("PreToolUse", make_ctx()) is None


@pytest.mark.asyncio
async def test_single_allow_passthrough_returns_none():
    async def hook(_ctx):
        return None

    d = HookDispatcher({"PreToolUse": [hook]})
    assert await d.fire("PreToolUse", make_ctx()) is None


@pytest.mark.asyncio
async def test_first_deny_short_circuits_remaining_hooks():
    calls: list[str] = []

    async def deny_hook(_ctx):
        calls.append("deny")
        return HookResult(decision="deny", reason="nope")

    async def should_not_run(_ctx):
        calls.append("after")
        return None

    d = HookDispatcher({"PreToolUse": [deny_hook, should_not_run]})
    r = await d.fire("PreToolUse", make_ctx())
    assert r is not None and r.decision == "deny"
    assert r.reason == "nope"
    assert calls == ["deny"]


@pytest.mark.asyncio
async def test_modify_chains_input_through_subsequent_hooks():
    seen: list[dict] = []

    async def first(_ctx):
        return HookResult(decision="modify", modified_input={"file_path": "1"})

    async def second(ctx):
        seen.append(dict(ctx.tool_input or {}))
        return HookResult(decision="modify", modified_input={"file_path": "2"})

    d = HookDispatcher({"PreToolUse": [first, second]})
    r = await d.fire("PreToolUse", make_ctx(tool_input={"file_path": "0"}))
    assert seen == [{"file_path": "1"}]              # second saw first's modification
    assert r is not None and r.modified_input == {"file_path": "2"}


@pytest.mark.asyncio
async def test_post_tool_use_modify_chains_output():
    async def first(_ctx):
        return HookResult(decision="modify", modified_output="A")

    async def second(ctx):
        # second sees first's modified_output via ctx.tool_result
        assert ctx.tool_result == "A"
        return HookResult(decision="modify", modified_output="B")

    d = HookDispatcher({"PostToolUse": [first, second]})
    r = await d.fire("PostToolUse", make_ctx(event="PostToolUse"))
    assert r is not None and r.modified_output == "B"


@pytest.mark.asyncio
async def test_exception_in_hook_propagates_with_event_attached():
    async def boom(_ctx):
        raise ValueError("kaboom")

    d = HookDispatcher({"PreToolUse": [boom]})
    with pytest.raises(ValueError, match="kaboom"):
        await d.fire("PreToolUse", make_ctx())
