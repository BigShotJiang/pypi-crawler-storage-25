"""Snapshot helpers for transcript regression tests.

A "snapshot" is a JSON file under tests/snapshots/data/<name>.json containing
the list of (event-type, ev-dict) pairs from a query() run. The helper compares
a live run to the stored file. Update with `pytest --snapshot-update`.
"""
from __future__ import annotations

import dataclasses
import json
from pathlib import Path

import pytest

DATA_DIR = Path(__file__).parent / "data"


def _to_jsonable(ev) -> dict:
    if dataclasses.is_dataclass(ev):
        return dataclasses.asdict(ev)
    return dict(ev)


def pytest_addoption(parser):
    parser.addoption("--snapshot-update", action="store_true", help="Update snapshot fixtures")


@pytest.fixture
def snapshot(request):
    update = request.config.getoption("--snapshot-update", default=False)

    def _check(name: str, events: list) -> None:
        path = DATA_DIR / f"{name}.json"
        actual = [_to_jsonable(e) for e in events]
        if update or not path.exists():
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(actual, indent=2))
            return
        expected = json.loads(path.read_text())
        assert actual == expected, (
            f"snapshot {name} mismatch; rerun with --snapshot-update if intentional"
        )

    return _check
