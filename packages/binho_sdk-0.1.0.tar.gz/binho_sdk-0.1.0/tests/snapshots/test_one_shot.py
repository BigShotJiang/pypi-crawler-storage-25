import pytest

from binho_sdk.events import Usage
from binho_sdk.options import Options
from binho_sdk.providers.base import (
    ProviderDone,
    ProviderTextDelta,
    ProviderUsage,
)
from binho_sdk.providers.mock import MockProvider
from binho_sdk.query import query


@pytest.mark.asyncio
async def test_one_shot_no_tools(snapshot):
    provider = MockProvider([
        [
            ProviderTextDelta(delta="hello"),
            ProviderDone(finish_reason="stop"),
            ProviderUsage(usage=Usage(input_tokens=4, output_tokens=2)),
        ]
    ])
    events = []
    async for ev in query(prompt="hi", options=Options(model="mock"), _provider=provider):
        events.append(ev)
    snapshot("one_shot_no_tools", events)
