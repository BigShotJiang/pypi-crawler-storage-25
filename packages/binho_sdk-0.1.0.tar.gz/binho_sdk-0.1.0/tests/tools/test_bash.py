import sys

import pytest

from binho_sdk.options import Options
from binho_sdk.tools.base import ReadTracker, ToolContext
from binho_sdk.tools.builtin.bash import bash_tool

pytestmark = pytest.mark.skipif(sys.platform == "win32", reason="Bash tool is Unix-only in v1")


def make_ctx(cwd):
    return ToolContext(
        cwd=str(cwd), options=Options(model="m"),
        agent_id=None, agent_type=None, tool_use_id="t1", tool_name="Bash",
        messages=[], read_tracker=ReadTracker(),
        hook_dispatcher=None, usage_accumulator=None,  # type: ignore[arg-type]
        emit=lambda _e: None, tool_mcp_server=None, mcp_clients={},
        provider=None, resolved_tools={},  # type: ignore[arg-type]
    )


@pytest.mark.asyncio
async def test_bash_captures_stdout(tmp_path):
    r = await bash_tool.handler({"command": "echo hello"}, make_ctx(tmp_path))
    assert not r.is_error
    assert "hello" in r.content


@pytest.mark.asyncio
async def test_bash_runs_in_cwd(tmp_path):
    (tmp_path / "marker.txt").write_text("")
    r = await bash_tool.handler({"command": "ls"}, make_ctx(tmp_path))
    assert "marker.txt" in r.content


@pytest.mark.asyncio
async def test_bash_nonzero_exit_is_not_tool_error(tmp_path):
    """Non-zero exit codes are not tool errors; the model sees the code."""
    r = await bash_tool.handler({"command": "exit 7"}, make_ctx(tmp_path))
    assert not r.is_error
    assert "exit code 7" in r.content.lower() or "exit 7" in r.content.lower()


@pytest.mark.asyncio
async def test_bash_combines_stdout_and_stderr(tmp_path):
    r = await bash_tool.handler({"command": "echo out; echo err 1>&2"}, make_ctx(tmp_path))
    assert "out" in r.content
    assert "err" in r.content


@pytest.mark.asyncio
async def test_bash_truncates_very_long_output(tmp_path):
    # MAX_OUTPUT_CHARS is 30000; produce well over that.
    cmd = "yes a | head -c 80000 | tr -d '\\n'"
    r = await bash_tool.handler({"command": cmd}, make_ctx(tmp_path))
    assert "[output truncated" in r.content


@pytest.mark.asyncio
async def test_bash_timeout_returns_error(tmp_path):
    r = await bash_tool.handler({"command": "sleep 5", "timeout_ms": 100}, make_ctx(tmp_path))
    assert r.is_error
    assert "timed out" in r.content.lower()
