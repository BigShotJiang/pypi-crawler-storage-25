import shutil

import pytest

from binho_sdk.options import Options
from binho_sdk.tools.base import ReadTracker, ToolContext
from binho_sdk.tools.builtin.grep import grep_tool

pytestmark = pytest.mark.skipif(shutil.which("rg") is None, reason="ripgrep not installed")


def make_ctx(cwd):
    return ToolContext(
        cwd=str(cwd), options=Options(model="m"),
        agent_id=None, agent_type=None, tool_use_id="t1", tool_name="Grep",
        messages=[], read_tracker=ReadTracker(),
        hook_dispatcher=None, usage_accumulator=None,  # type: ignore[arg-type]
        emit=lambda _e: None, tool_mcp_server=None, mcp_clients={},
        provider=None, resolved_tools={},  # type: ignore[arg-type]
    )


@pytest.mark.asyncio
async def test_grep_files_with_matches_default(tmp_path):
    (tmp_path / "a.py").write_text("def foo():\n    pass\n")
    (tmp_path / "b.py").write_text("def bar():\n    pass\n")
    r = await grep_tool.handler({"pattern": "foo"}, make_ctx(tmp_path))
    assert not r.is_error
    assert "a.py" in r.content
    assert "b.py" not in r.content


@pytest.mark.asyncio
async def test_grep_content_mode_returns_match_lines(tmp_path):
    (tmp_path / "x.py").write_text("alpha\nfoo here\ngamma\n")
    r = await grep_tool.handler({"pattern": "foo", "output_mode": "content"}, make_ctx(tmp_path))
    assert "foo here" in r.content


@pytest.mark.asyncio
async def test_grep_count_mode(tmp_path):
    (tmp_path / "x.py").write_text("foo\nfoo\nbar\n")
    r = await grep_tool.handler({"pattern": "foo", "output_mode": "count"}, make_ctx(tmp_path))
    assert "2" in r.content


@pytest.mark.asyncio
async def test_grep_no_matches_returns_empty_no_error(tmp_path):
    (tmp_path / "x.py").write_text("alpha\n")
    r = await grep_tool.handler({"pattern": "nope"}, make_ctx(tmp_path))
    assert not r.is_error
    assert r.content.strip() == ""


@pytest.mark.asyncio
async def test_grep_case_insensitive(tmp_path):
    (tmp_path / "x.py").write_text("FOO\n")
    r = await grep_tool.handler(
        {"pattern": "foo", "case_insensitive": True, "output_mode": "content"},
        make_ctx(tmp_path),
    )
    assert "FOO" in r.content
