import pytest

from binho_sdk.options import Options
from binho_sdk.tools.base import ReadTracker, ToolContext
from binho_sdk.tools.builtin.edit import edit_tool
from binho_sdk.tools.builtin.read import read_tool


def make_ctx(cwd, rt=None):
    return ToolContext(
        cwd=str(cwd),
        options=Options(model="m"),
        agent_id=None,
        agent_type=None,
        tool_use_id="t1",
        tool_name="Edit",
        messages=[],
        read_tracker=rt or ReadTracker(),
        hook_dispatcher=None,             # type: ignore[arg-type]
        usage_accumulator=None,
        emit=lambda _e: None,
        tool_mcp_server=None,
        mcp_clients={},
        provider=None,                    # type: ignore[arg-type]
        resolved_tools={},
    )


@pytest.mark.asyncio
async def test_edit_requires_prior_read(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("hello world")
    r = await edit_tool.handler(
        {"file_path": str(f), "old_string": "hello", "new_string": "bye"},
        make_ctx(tmp_path),
    )
    assert r.is_error
    assert "read" in r.content.lower()
    assert f.read_text() == "hello world"


@pytest.mark.asyncio
async def test_edit_replaces_unique_match(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("hello world")
    ctx = make_ctx(tmp_path)
    await read_tool.handler({"file_path": str(f)}, ctx)
    r = await edit_tool.handler(
        {"file_path": str(f), "old_string": "hello", "new_string": "bye"}, ctx,
    )
    assert not r.is_error
    assert f.read_text() == "bye world"


@pytest.mark.asyncio
async def test_edit_fails_on_nonunique_match_without_replace_all(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("hi hi hi")
    ctx = make_ctx(tmp_path)
    await read_tool.handler({"file_path": str(f)}, ctx)
    r = await edit_tool.handler(
        {"file_path": str(f), "old_string": "hi", "new_string": "ok"}, ctx,
    )
    assert r.is_error
    assert "unique" in r.content.lower() or "multiple" in r.content.lower()


@pytest.mark.asyncio
async def test_edit_replace_all_replaces_every_match(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("hi hi hi")
    ctx = make_ctx(tmp_path)
    await read_tool.handler({"file_path": str(f)}, ctx)
    r = await edit_tool.handler(
        {"file_path": str(f), "old_string": "hi", "new_string": "ok", "replace_all": True}, ctx,
    )
    assert not r.is_error
    assert f.read_text() == "ok ok ok"


@pytest.mark.asyncio
async def test_edit_fails_when_old_string_not_found(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("hello")
    ctx = make_ctx(tmp_path)
    await read_tool.handler({"file_path": str(f)}, ctx)
    r = await edit_tool.handler(
        {"file_path": str(f), "old_string": "missing", "new_string": "x"}, ctx,
    )
    assert r.is_error
    assert "not found" in r.content.lower()


@pytest.mark.asyncio
async def test_edit_fails_when_file_changed_on_disk_since_read(tmp_path):
    """Mtime-based stale-Read detection."""
    import os
    import time
    f = tmp_path / "x.py"
    f.write_text("hello")
    ctx = make_ctx(tmp_path)
    await read_tool.handler({"file_path": str(f)}, ctx)
    # Modify the file on disk after the Read.
    time.sleep(0.01)  # noqa: ASYNC251
    f.write_text("hello again")
    os.utime(f, ns=(f.stat().st_atime_ns, f.stat().st_mtime_ns + 10_000_000))
    r = await edit_tool.handler(
        {"file_path": str(f), "old_string": "hello", "new_string": "bye"}, ctx,
    )
    assert r.is_error
    assert "changed" in r.content.lower() or "read" in r.content.lower()
