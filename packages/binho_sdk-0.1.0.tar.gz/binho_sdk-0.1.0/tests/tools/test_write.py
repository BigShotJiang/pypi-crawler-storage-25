import pytest

from binho_sdk.options import Options
from binho_sdk.tools.base import ReadTracker, ToolContext
from binho_sdk.tools.builtin.read import read_tool
from binho_sdk.tools.builtin.write import write_tool


def make_ctx(cwd, read_tracker=None):
    return ToolContext(
        cwd=str(cwd),
        options=Options(model="m"),
        agent_id=None,
        agent_type=None,
        tool_use_id="t1",
        tool_name="Write",
        messages=[],
        read_tracker=read_tracker or ReadTracker(),
        hook_dispatcher=None,             # type: ignore[arg-type]
        usage_accumulator=None,
        emit=lambda _e: None,
        tool_mcp_server=None,
        mcp_clients={},
        provider=None,                    # type: ignore[arg-type]
        resolved_tools={},
    )


@pytest.mark.asyncio
async def test_write_creates_new_file(tmp_path):
    target = tmp_path / "new.txt"
    r = await write_tool.handler({"file_path": str(target), "content": "hello"}, make_ctx(tmp_path))
    assert not r.is_error
    assert target.read_text() == "hello"


@pytest.mark.asyncio
async def test_write_creates_parent_directories(tmp_path):
    target = tmp_path / "a" / "b" / "c.txt"
    r = await write_tool.handler({"file_path": str(target), "content": "x"}, make_ctx(tmp_path))
    assert not r.is_error
    assert target.read_text() == "x"


@pytest.mark.asyncio
async def test_write_refuses_overwrite_without_prior_read(tmp_path):
    target = tmp_path / "existing.txt"
    target.write_text("old")
    r = await write_tool.handler({"file_path": str(target), "content": "new"}, make_ctx(tmp_path))
    assert r.is_error
    assert "read" in r.content.lower()
    assert target.read_text() == "old"


@pytest.mark.asyncio
async def test_write_overwrites_after_prior_read(tmp_path):
    target = tmp_path / "existing.txt"
    target.write_text("old")
    rt = ReadTracker()
    ctx = make_ctx(tmp_path, read_tracker=rt)
    await read_tool.handler({"file_path": str(target)}, ctx)
    r = await write_tool.handler({"file_path": str(target), "content": "new"}, ctx)
    assert not r.is_error
    assert target.read_text() == "new"
