import os
import time

import pytest

from binho_sdk.options import Options
from binho_sdk.tools.base import ReadTracker, ToolContext
from binho_sdk.tools.builtin.glob import glob_tool


def make_ctx(cwd):
    return ToolContext(
        cwd=str(cwd),
        options=Options(model="m"),
        agent_id=None, agent_type=None,
        tool_use_id="t1", tool_name="Glob",
        messages=[], read_tracker=ReadTracker(),
        hook_dispatcher=None, usage_accumulator=None,  # type: ignore[arg-type]
        emit=lambda _e: None, tool_mcp_server=None, mcp_clients={},
        provider=None, resolved_tools={},  # type: ignore[arg-type]
    )


@pytest.mark.asyncio
async def test_glob_returns_matching_paths(tmp_path):
    (tmp_path / "a.py").write_text("")
    (tmp_path / "b.py").write_text("")
    (tmp_path / "c.txt").write_text("")
    r = await glob_tool.handler({"pattern": "*.py"}, make_ctx(tmp_path))
    assert not r.is_error
    paths = r.content.strip().splitlines()
    assert len(paths) == 2
    assert all(p.endswith(".py") for p in paths)


@pytest.mark.asyncio
async def test_glob_recursive(tmp_path):
    (tmp_path / "a.py").write_text("")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "b.py").write_text("")
    r = await glob_tool.handler({"pattern": "**/*.py"}, make_ctx(tmp_path))
    assert not r.is_error
    paths = r.content.strip().splitlines()
    assert len(paths) == 2


@pytest.mark.asyncio
async def test_glob_orders_by_mtime_descending(tmp_path):
    older = tmp_path / "old.py"
    older.write_text("")
    time.sleep(0.01)  # noqa: ASYNC251
    newer = tmp_path / "new.py"
    newer.write_text("")
    # Force ordering even on coarse filesystems:
    os.utime(older, ns=(older.stat().st_atime_ns, older.stat().st_mtime_ns - 10_000_000))
    r = await glob_tool.handler({"pattern": "*.py"}, make_ctx(tmp_path))
    paths = r.content.strip().splitlines()
    assert paths[0].endswith("new.py")
    assert paths[1].endswith("old.py")


@pytest.mark.asyncio
async def test_glob_empty_when_no_matches(tmp_path):
    r = await glob_tool.handler({"pattern": "*.nonexistent"}, make_ctx(tmp_path))
    assert not r.is_error
    assert r.content.strip() == ""
