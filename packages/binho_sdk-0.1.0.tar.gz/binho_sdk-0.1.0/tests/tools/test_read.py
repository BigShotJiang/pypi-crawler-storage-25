# tests/tools/test_read.py
from __future__ import annotations

import pytest

from binho_sdk.options import Options
from binho_sdk.tools.base import ReadTracker, ToolContext
from binho_sdk.tools.builtin.read import read_tool


def make_ctx(cwd, **kw):
    return ToolContext(
        cwd=str(cwd),
        options=Options(model="m"),
        agent_id=None,
        agent_type=None,
        tool_use_id="t1",
        tool_name="Read",
        messages=[],
        read_tracker=kw.get("read_tracker", ReadTracker()),
        hook_dispatcher=None,             # type: ignore[arg-type]
        usage_accumulator=None,
        emit=lambda _e: None,
        tool_mcp_server=None,
        mcp_clients={},
        provider=None,                    # type: ignore[arg-type]
        resolved_tools={},
    )


@pytest.mark.asyncio
async def test_read_returns_numbered_lines(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("alpha\nbeta\ngamma\n")
    result = await read_tool.handler({"file_path": str(f)}, make_ctx(tmp_path))
    assert not result.is_error
    assert "1\talpha" in result.content
    assert "2\tbeta" in result.content
    assert "3\tgamma" in result.content


@pytest.mark.asyncio
async def test_read_offset_and_limit(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("\n".join(f"line{i}" for i in range(1, 11)))
    result = await read_tool.handler(
        {"file_path": str(f), "offset": 3, "limit": 2}, make_ctx(tmp_path)
    )
    assert "3\tline3" in result.content
    assert "4\tline4" in result.content
    assert "5\tline5" not in result.content
    assert "1\tline1" not in result.content


@pytest.mark.asyncio
async def test_read_relative_resolves_against_cwd(tmp_path):
    (tmp_path / "rel.txt").write_text("hi")
    result = await read_tool.handler({"file_path": "rel.txt"}, make_ctx(tmp_path))
    assert not result.is_error


@pytest.mark.asyncio
async def test_read_missing_file_returns_error(tmp_path):
    result = await read_tool.handler(
        {"file_path": str(tmp_path / "missing.py")}, make_ctx(tmp_path)
    )
    assert result.is_error


@pytest.mark.asyncio
async def test_read_too_large_returns_error(tmp_path):
    f = tmp_path / "big.bin"
    f.write_bytes(b"x" * (5 * 1024 * 1024 + 1))
    result = await read_tool.handler({"file_path": str(f)}, make_ctx(tmp_path))
    assert result.is_error
    assert "too large" in result.content.lower()


@pytest.mark.asyncio
async def test_read_registers_in_read_tracker(tmp_path):
    f = tmp_path / "x.py"
    f.write_text("hi")
    rt = ReadTracker()
    await read_tool.handler({"file_path": str(f)}, make_ctx(tmp_path, read_tracker=rt))
    assert rt.was_read(str(f.resolve()), current_mtime_ns=f.stat().st_mtime_ns) is True


@pytest.mark.asyncio
async def test_read_refuses_paths_outside_allowed(tmp_path):
    inside = tmp_path / "in.py"
    inside.write_text("ok")
    outside = tmp_path.parent / "out.py"
    outside.write_text("nope")
    ctx = ToolContext(
        cwd=str(tmp_path),
        options=Options(model="m", allowed_paths=[tmp_path]),
        agent_id=None,
        agent_type=None,
        tool_use_id="t1",
        tool_name="Read",
        messages=[],
        read_tracker=ReadTracker(),
        hook_dispatcher=None,             # type: ignore[arg-type]
        usage_accumulator=None,
        emit=lambda _e: None,
        tool_mcp_server=None,
        mcp_clients={},
        provider=None,                    # type: ignore[arg-type]
        resolved_tools={},
    )
    r = await read_tool.handler({"file_path": str(outside)}, ctx)
    assert r.is_error
    assert "allowed_paths" in r.content.lower() or "outside" in r.content.lower()
    outside.unlink()
