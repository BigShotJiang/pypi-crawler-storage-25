import pytest

from binho_sdk.errors import (
    AuthError,
    BinhoConfigError,
    BinhoError,
    ProviderError,
    QuotaError,
    RateLimitError,
)


def test_subclasses_inherit_from_binho_error():
    assert issubclass(BinhoConfigError, BinhoError)
    assert issubclass(ProviderError, BinhoError)
    assert issubclass(AuthError, ProviderError)
    assert issubclass(QuotaError, ProviderError)
    assert issubclass(RateLimitError, ProviderError)


def test_can_raise_and_catch():
    with pytest.raises(BinhoConfigError, match="bad"):
        raise BinhoConfigError("bad")

    with pytest.raises(ProviderError):  # AuthError matches as a ProviderError
        raise AuthError("nope")
