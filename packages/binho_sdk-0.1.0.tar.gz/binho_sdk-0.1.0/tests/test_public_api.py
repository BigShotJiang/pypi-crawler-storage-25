"""Smoke test: the v1 public API is importable from the top-level package."""


def test_top_level_imports():
    from binho_sdk import (
        AgentDefinition,
        AuthError,
        BinhoConfigError,
        BinhoError,
        CanUseToolInput,
        HookCallback,
        HookContext,
        HookEvent,
        HookResult,
        McpServerConfig,
        Message,
        Options,
        PermissionMode,
        PermissionResult,
        ProviderError,
        QuotaError,
        RateLimitError,
        Result,
        TextDelta,
        Tool,
        ToolContext,
        ToolResult,
        ToolReturn,
        ToolUse,
        TransportError,
        TurnEnd,
        TurnStart,
        Usage,
        __version__,
        tool,
    )
    # Reference each import so ruff doesn't strip them; the imports above are the
    # actual surface check (importing a missing name raises ImportError).
    referenced = (
        AgentDefinition, AuthError, BinhoConfigError, BinhoError, CanUseToolInput,
        HookCallback, HookContext, HookEvent, HookResult,
        McpServerConfig, Message, Options, PermissionMode, PermissionResult,
        ProviderError, QuotaError, RateLimitError, Result, TextDelta,
        Tool, ToolContext, ToolResult, ToolReturn, ToolUse,
        TransportError, TurnEnd, TurnStart, Usage, tool,
    )
    assert __version__ == "0.1.0"
    assert AgentDefinition is not None
    assert all(s is not None for s in referenced)
