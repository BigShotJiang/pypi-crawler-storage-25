from binho_sdk.events import (
    Event,
    Result,
    SubagentEnd,
    SubagentStart,
    TextDelta,
    ToolResult,
    ToolUse,
    TurnEnd,
    TurnStart,
    Usage,
)


def test_text_delta_carries_string():
    ev = TextDelta(delta="hello")
    assert ev.type == "text_delta"
    assert ev.delta == "hello"


def test_usage_addition_aggregates_tokens_and_cost():
    a = Usage(input_tokens=10, output_tokens=5, cost_usd=0.001)
    b = Usage(input_tokens=20, output_tokens=15, cost_usd=0.002)
    c = a + b
    assert c.input_tokens == 30
    assert c.output_tokens == 20
    assert c.cost_usd == 0.003


def test_usage_addition_when_one_side_lacks_cost():
    a = Usage(input_tokens=1, output_tokens=1, cost_usd=None)
    b = Usage(input_tokens=2, output_tokens=2, cost_usd=0.005)
    c = a + b
    assert c.cost_usd == 0.005


def test_result_carries_messages_and_stop_reason():
    msgs = [{"role": "user", "content": "hi"}]
    r = Result(messages=msgs, usage=Usage(input_tokens=1, output_tokens=1), stop_reason="end_turn")
    assert r.type == "result"
    assert r.stop_reason == "end_turn"
    assert r.messages is msgs


def test_event_union_membership():
    # Smoke check: Event is the discriminated union; instances satisfy it.
    events: list[Event] = [
        TextDelta(delta="x"),
        ToolUse(id="t1", name="Read", arguments={}),
        ToolResult(id="t1", content="", is_error=False),
        TurnStart(turn=1),
        TurnEnd(turn=1),
        SubagentStart(agent_type="explorer", agent_id="a1"),
        SubagentEnd(agent_id="a1", result="done"),
        Result(messages=[], usage=Usage(input_tokens=0, output_tokens=0), stop_reason="end_turn"),
    ]
    assert len({e.type for e in events}) == 8
