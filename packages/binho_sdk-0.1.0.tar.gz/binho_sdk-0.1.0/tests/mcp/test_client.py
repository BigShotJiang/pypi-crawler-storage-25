# tests/mcp/test_client.py
"""HTTP MCP client: initialize handshake + tools/list + tools/call."""
from __future__ import annotations

import json

import pytest
import respx
from httpx import Response

from binho_sdk.mcp.client import McpClient, McpServerConfig


def _ok(result: dict, request_id) -> Response:
    return Response(200, json={"jsonrpc": "2.0", "id": request_id, "result": result})


def _error(code: int, message: str, request_id) -> Response:
    return Response(
        200,
        json={"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}},
    )


@respx.mock
@pytest.mark.asyncio
async def test_initialize_advertises_only_tools_capability():
    seen_init: dict = {}
    seen_initialized: list = []

    def init_route(request):
        body = json.loads(request.content.decode())
        seen_init.update(body)
        return _ok(
            {
                "protocolVersion": "2025-06-18",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "fake", "version": "1"},
            },
            body["id"],
        )

    def initialized_route(request):
        body = json.loads(request.content.decode())
        seen_initialized.append(body)
        return Response(202)

    def tools_list_route(request):
        body = json.loads(request.content.decode())
        return _ok({"tools": []}, body["id"])

    respx.post("https://x/mcp").mock(side_effect=[init_route, initialized_route, tools_list_route])

    cfg = McpServerConfig(url="https://x/mcp")
    client = McpClient(name="docworker", config=cfg)
    await client.initialize()
    await client.close()

    assert seen_init["method"] == "initialize"
    caps = seen_init["params"]["capabilities"]
    assert "tools" in caps
    # No resources/prompts/elicitation/sampling advertised:
    assert "resources" not in caps
    assert "prompts" not in caps
    assert "elicitation" not in caps
    assert "sampling" not in caps
    # initialized notification was sent:
    assert any(n.get("method") == "notifications/initialized" for n in seen_initialized)


@respx.mock
@pytest.mark.asyncio
async def test_initialize_fails_when_server_lacks_tools_capability():
    from binho_sdk.errors import BinhoConfigError

    def init_route(request):
        body = json.loads(request.content.decode())
        return _ok(
            {
                "protocolVersion": "2025-06-18",
                "capabilities": {"resources": {}},
                "serverInfo": {"name": "fake", "version": "1"},
            },
            body["id"],
        )

    respx.post("https://x/mcp").mock(side_effect=[init_route])

    cfg = McpServerConfig(url="https://x/mcp")
    client = McpClient(name="docworker", config=cfg)
    with pytest.raises(BinhoConfigError, match="tools"):
        await client.initialize()
    await client.close()


@respx.mock
@pytest.mark.asyncio
async def test_list_tools_parses_descriptors():
    def init_route(request):
        body = json.loads(request.content.decode())
        return _ok({"protocolVersion": "2025-06-18", "capabilities": {"tools": {}}}, body["id"])

    def initialized_route(request):
        return Response(202)

    def tools_list_route(request):
        body = json.loads(request.content.decode())
        return _ok(
            {
                "tools": [
                    {
                        "name": "bm25_search",
                        "description": "Search.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"q": {"type": "string"}},
                            "required": ["q"],
                        },
                    },
                    {
                        "name": "read_symbol",
                        "description": "Read a symbol.",
                        "inputSchema": {"type": "object"},
                    },
                ]
            },
            body["id"],
        )

    respx.post("https://x/mcp").mock(side_effect=[init_route, initialized_route, tools_list_route])

    client = McpClient(name="docworker", config=McpServerConfig(url="https://x/mcp"))
    await client.initialize()
    descs = await client.list_tools()
    names = [d.name for d in descs]
    assert names == ["bm25_search", "read_symbol"]
    await client.close()


@respx.mock
@pytest.mark.asyncio
async def test_call_tool_returns_text_content():
    def init_route(request):
        body = json.loads(request.content.decode())
        return _ok({"protocolVersion": "2025-06-18", "capabilities": {"tools": {}}}, body["id"])

    def initialized_route(_request):
        return Response(202)

    def tools_list_route(request):
        body = json.loads(request.content.decode())
        return _ok(
            {"tools": [{"name": "echo", "description": "...", "inputSchema": {"type": "object"}}]},
            body["id"],
        )

    def tools_call_route(request):
        body = json.loads(request.content.decode())
        assert body["params"]["name"] == "echo"
        assert body["params"]["arguments"] == {"x": 1}
        return _ok({"content": [{"type": "text", "text": "RESULT"}], "isError": False}, body["id"])

    respx.post("https://x/mcp").mock(
        side_effect=[init_route, initialized_route, tools_list_route, tools_call_route]
    )

    client = McpClient(name="docworker", config=McpServerConfig(url="https://x/mcp"))
    await client.initialize()
    result = await client.call_tool("echo", {"x": 1})
    assert result.is_error is False
    assert result.text == "RESULT"
    await client.close()


@respx.mock
@pytest.mark.asyncio
async def test_initialize_rejects_protocol_version_mismatch():
    from binho_sdk.errors import BinhoConfigError

    def init_route(request):
        body = json.loads(request.content.decode())
        return _ok(
            {"protocolVersion": "1999-01-01", "capabilities": {"tools": {}}},
            body["id"],
        )

    respx.post("https://x/mcp").mock(side_effect=[init_route])

    client = McpClient(name="docworker", config=McpServerConfig(url="https://x/mcp"))
    with pytest.raises(BinhoConfigError, match="protocol"):
        await client.initialize()
    await client.close()


@respx.mock
@pytest.mark.asyncio
async def test_post_advertises_accept_header_and_sse_response_is_parsed():
    """Server replies with text/event-stream; client must accept and parse it."""
    seen_accept: list[str] = []

    def init_route(request):
        seen_accept.append(request.headers.get("accept", ""))
        body = json.loads(request.content.decode())
        payload = json.dumps(
            {
                "jsonrpc": "2.0",
                "id": body["id"],
                "result": {
                    "protocolVersion": "2025-06-18",
                    "capabilities": {"tools": {}},
                },
            }
        )
        sse = f"data: {payload}\n\n"
        return Response(200, headers={"content-type": "text/event-stream"}, text=sse)

    def initialized_route(_request):
        return Response(202)

    def tools_list_route(request):
        body = json.loads(request.content.decode())
        return _ok({"tools": []}, body["id"])

    respx.post("https://x/mcp").mock(
        side_effect=[init_route, initialized_route, tools_list_route]
    )

    client = McpClient(name="docworker", config=McpServerConfig(url="https://x/mcp"))
    await client.initialize()
    assert seen_accept, "client made no POST"
    assert "application/json" in seen_accept[0]
    assert "text/event-stream" in seen_accept[0]
    await client.close()


@respx.mock
@pytest.mark.asyncio
async def test_session_id_is_captured_and_round_tripped():
    seen_session_ids: list[str | None] = []

    def init_route(request):
        seen_session_ids.append(request.headers.get("mcp-session-id"))
        body = json.loads(request.content.decode())
        return Response(
            200,
            headers={"Mcp-Session-Id": "sess-abc"},
            json={
                "jsonrpc": "2.0",
                "id": body["id"],
                "result": {
                    "protocolVersion": "2025-06-18",
                    "capabilities": {"tools": {}},
                },
            },
        )

    def initialized_route(request):
        seen_session_ids.append(request.headers.get("mcp-session-id"))
        return Response(202)

    def tools_list_route(request):
        seen_session_ids.append(request.headers.get("mcp-session-id"))
        body = json.loads(request.content.decode())
        return _ok({"tools": []}, body["id"])

    respx.post("https://x/mcp").mock(
        side_effect=[init_route, initialized_route, tools_list_route]
    )

    client = McpClient(name="docworker", config=McpServerConfig(url="https://x/mcp"))
    await client.initialize()
    # Initial POST has no session id; subsequent POSTs carry the assigned one.
    assert seen_session_ids[0] is None
    assert seen_session_ids[1] == "sess-abc"
    assert seen_session_ids[2] == "sess-abc"
    await client.close()


@respx.mock
@pytest.mark.asyncio
async def test_call_tool_protocol_error_surfaces():
    from binho_sdk.mcp.client import McpProtocolError

    def init_route(request):
        body = json.loads(request.content.decode())
        return _ok({"protocolVersion": "2025-06-18", "capabilities": {"tools": {}}}, body["id"])

    def initialized_route(_request):
        return Response(202)

    def tools_list_route(request):
        body = json.loads(request.content.decode())
        return _ok(
            {"tools": [{"name": "x", "description": "", "inputSchema": {"type": "object"}}]},
            body["id"],
        )

    def tools_call_route(request):
        body = json.loads(request.content.decode())
        return _error(-32602, "bad params", body["id"])

    respx.post("https://x/mcp").mock(
        side_effect=[init_route, initialized_route, tools_list_route, tools_call_route]
    )

    client = McpClient(name="docworker", config=McpServerConfig(url="https://x/mcp"))
    await client.initialize()
    with pytest.raises(McpProtocolError, match="bad params"):
        await client.call_tool("x", {})
    await client.close()
