# tests/mcp/test_tool_factory.py
import asyncio

import pytest

from binho_sdk.mcp.client import McpToolDescriptor, McpToolResult
from binho_sdk.mcp.tool_factory import build_mcp_tool
from binho_sdk.options import Options
from binho_sdk.tools.base import ReadTracker, ToolContext


class _FakeClient:
    def __init__(self):
        self.calls: list[tuple[str, dict]] = []
        self.next_result = McpToolResult(text="ok", is_error=False)

    async def call_tool(self, name, arguments):
        self.calls.append((name, arguments))
        return self.next_result


def make_ctx(client):
    return ToolContext(
        cwd="/tmp", options=Options(model="m"),
        agent_id=None, agent_type=None, tool_use_id="t1",
        tool_name="mcp__docworker__bm25_search",
        messages=[], read_tracker=ReadTracker(),
        hook_dispatcher=None, usage_accumulator=None,  # type: ignore[arg-type]
        emit=lambda _e: None,
        tool_mcp_server="docworker", mcp_clients={"docworker": client},
        provider=None, resolved_tools={},  # type: ignore[arg-type]
    )


@pytest.mark.asyncio
async def test_build_mcp_tool_full_qualified_name_and_schema():
    desc = McpToolDescriptor(
        name="bm25_search", description="Search.", input_schema={"type": "object"},
    )
    tool = build_mcp_tool(server_name="docworker", desc=desc)
    assert tool.name == "mcp__docworker__bm25_search"
    assert tool.description == "Search."
    assert tool.parameters_schema == {"type": "object"}
    assert tool.source == "mcp"
    assert tool.mcp_server == "docworker"


@pytest.mark.asyncio
async def test_handler_forwards_to_client_with_bare_tool_name():
    desc = McpToolDescriptor(name="bm25_search", description="", input_schema={"type": "object"})
    tool = build_mcp_tool("docworker", desc)
    fake = _FakeClient()
    r = await tool.handler({"q": "alpha"}, make_ctx(fake))
    assert not r.is_error
    assert r.content == "ok"
    assert fake.calls == [("bm25_search", {"q": "alpha"})]


@pytest.mark.asyncio
async def test_handler_returns_error_on_transport_failure():
    from binho_sdk.mcp.client import McpTransportError

    class _BoomClient:
        async def call_tool(self, name, arguments):
            raise McpTransportError("connection reset")

    desc = McpToolDescriptor(name="x", description="", input_schema={"type": "object"})
    tool = build_mcp_tool("docworker", desc)
    r = await tool.handler({}, make_ctx(_BoomClient()))
    assert r.is_error
    assert "connection reset" in r.content


@pytest.mark.asyncio
async def test_handler_times_out_per_server_config():
    class _SlowClient:
        async def call_tool(self, name, arguments):
            await asyncio.sleep(1.0)
            return McpToolResult(text="late", is_error=False)

    from binho_sdk.options import McpServerConfig

    desc = McpToolDescriptor(name="x", description="", input_schema={"type": "object"})
    tool = build_mcp_tool("docworker", desc)
    ctx = make_ctx(_SlowClient())
    # Override per-server timeout via Options.mcp_servers
    ctx.options.mcp_servers["docworker"] = McpServerConfig(url="http://x", timeout_seconds=0.05)
    r = await tool.handler({}, ctx)
    assert r.is_error
    assert "timed out" in r.content.lower() or "timeout" in r.content.lower()
