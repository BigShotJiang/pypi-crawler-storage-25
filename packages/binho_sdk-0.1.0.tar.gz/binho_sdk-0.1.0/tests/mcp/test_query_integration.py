# tests/mcp/test_query_integration.py
"""End-to-end: query() resolves mcp__docworker__* through a mocked MCP server."""
from __future__ import annotations

import json

import pytest
import respx
from httpx import Response

from binho_sdk.events import ToolResult
from binho_sdk.options import McpServerConfig, Options
from binho_sdk.providers.base import (
    ProviderDone,
    ProviderTextDelta,
    ProviderToolCall,
)
from binho_sdk.providers.mock import MockProvider
from binho_sdk.query import query


def _ok(result: dict, rid):
    return Response(200, json={"jsonrpc": "2.0", "id": rid, "result": result})


def _seq_handler(handlers):
    """Return an httpx side_effect that dispatches by JSON-RPC method."""
    def handler(request):
        body = json.loads(request.content.decode())
        method = body.get("method", "")
        if method == "notifications/initialized":
            return Response(202)
        return handlers[method](body)
    return handler


@respx.mock
@pytest.mark.asyncio
async def test_mcp_tool_resolved_and_called(respx_mock):
    def init(body):
        return _ok({"protocolVersion": "2025-06-18", "capabilities": {"tools": {}}}, body["id"])

    def list_tools(body):
        return _ok({"tools": [{"name": "bm25_search", "description": "search",
                               "inputSchema": {"type": "object",
                                               "properties": {"q": {"type": "string"}},
                                               "required": ["q"]}}]}, body["id"])

    def call_tool(body):
        assert body["params"]["name"] == "bm25_search"
        assert body["params"]["arguments"] == {"q": "alpha"}
        return _ok({"content": [{"type": "text", "text": "match!"}], "isError": False}, body["id"])

    respx_mock.post("https://x/mcp").mock(side_effect=_seq_handler({
        "initialize": init, "tools/list": list_tools, "tools/call": call_tool,
    }))

    provider = MockProvider([
        [
            ProviderToolCall(id="t1", name="mcp__docworker__bm25_search", arguments={"q": "alpha"}),
            ProviderDone(finish_reason="tool_calls"),
        ],
        [
            ProviderTextDelta(delta="done"),
            ProviderDone(finish_reason="stop"),
        ],
    ])

    options = Options(
        model="m",
        tools=["mcp__docworker__bm25_search"],
        mcp_servers={"docworker": McpServerConfig(url="https://x/mcp")},
    )

    events = []
    async for ev in query(prompt="search", options=options, _provider=provider):
        events.append(ev)
    res = next(e for e in events if isinstance(e, ToolResult) and e.id == "t1")
    assert not res.is_error
    assert "match!" in res.content


@respx.mock
@pytest.mark.asyncio
async def test_mcp_unknown_tool_fails_at_query_start(respx_mock):
    from binho_sdk.errors import BinhoConfigError

    def init(body):
        return _ok({"protocolVersion": "2025-06-18", "capabilities": {"tools": {}}}, body["id"])

    def list_tools(body):
        tools = [{"name": "real_tool", "description": "", "inputSchema": {"type": "object"}}]
        return _ok({"tools": tools}, body["id"])

    respx_mock.post("https://x/mcp").mock(side_effect=_seq_handler({
        "initialize": init, "tools/list": list_tools,
    }))

    provider = MockProvider([[ProviderDone(finish_reason="stop")]])
    options = Options(
        model="m",
        tools=["mcp__docworker__nonexistent"],
        mcp_servers={"docworker": McpServerConfig(url="https://x/mcp")},
    )
    with pytest.raises(BinhoConfigError, match="nonexistent"):
        async for _ in query(prompt="hi", options=options, _provider=provider):
            pass


@respx.mock
@pytest.mark.asyncio
async def test_mcp_undefined_server_in_tools_string_fails(respx_mock):
    from binho_sdk.errors import BinhoConfigError

    options = Options(
        model="m",
        tools=["mcp__missing__x"],
        mcp_servers={},  # no "missing" server configured
    )
    with pytest.raises(BinhoConfigError, match="missing"):
        async for _ in query(prompt="hi", options=options, _provider=MockProvider([])):
            pass
