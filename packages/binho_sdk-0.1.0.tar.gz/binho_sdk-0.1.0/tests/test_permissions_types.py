from binho_sdk.permissions.modes import (
    CanUseToolInput,
    PermissionMode,
    PermissionResult,
    PermissionUpdate,
    default_decide,
)


def test_permission_mode_literal_values():
    valid: list[PermissionMode] = ["default", "acceptEdits", "bypassPermissions", "plan"]
    assert "default" in valid
    assert "acceptEdits" in valid


def test_can_use_tool_input_default_suggestions_empty():
    inp = CanUseToolInput(
        tool_name="Read",
        tool_input={},
        tool_use_id="t1",
        agent_id=None,
        agent_type=None,
        permission_mode="default",
        suggestions=[],
    )
    assert inp.suggestions == []


def test_default_decide_bypass_permissions_allows():
    inp = CanUseToolInput("Bash", {}, "t1", None, None, "bypassPermissions", [])
    r = default_decide(inp)
    assert r.behavior == "allow"


def test_default_decide_plan_mode_allows_read_only():
    for tool in ("Read", "Glob", "Grep"):
        inp = CanUseToolInput(tool, {}, "t1", None, None, "plan", [])
        assert default_decide(inp).behavior == "allow"
    for tool in ("Write", "Edit", "Bash"):
        inp = CanUseToolInput(tool, {}, "t1", None, None, "plan", [])
        assert default_decide(inp).behavior == "deny"


def test_default_decide_plan_mode_denies_mcp_tools():
    inp = CanUseToolInput("mcp__docworker__bm25_search", {}, "t1", None, None, "plan", [])
    assert default_decide(inp).behavior == "deny"


def test_default_decide_accept_edits_denies_mcp_tools():
    inp = CanUseToolInput("mcp__docworker__bm25_search", {}, "t1", None, None, "acceptEdits", [])
    assert default_decide(inp).behavior == "deny"


def test_default_decide_accept_edits_asks_for_bash():
    inp = CanUseToolInput("Bash", {}, "t1", None, None, "acceptEdits", [])
    assert default_decide(inp).behavior == "ask"


def test_default_decide_default_mode_allows():
    inp = CanUseToolInput("Bash", {}, "t1", None, None, "default", [])
    assert default_decide(inp).behavior == "allow"


def test_permission_update_shape():
    pu = PermissionUpdate(type="addRules", rules=["Bash(npm test:*)"])
    assert pu.type == "addRules"
    assert pu.rules == ["Bash(npm test:*)"]


def test_permission_result_minimal():
    r = PermissionResult(behavior="allow")
    assert r.behavior == "allow"
    assert r.updated_input is None
    assert r.updated_permissions is None
