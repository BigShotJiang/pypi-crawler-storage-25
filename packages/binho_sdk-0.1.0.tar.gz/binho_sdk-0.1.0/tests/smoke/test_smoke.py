"""Smoke tests against real OpenRouter. Gated by OPENROUTER_API_KEY.

Run explicitly: `pytest -m smoke`
"""
import os
from typing import cast

import pytest

from binho_sdk import Options, Result, query

pytestmark = [
    pytest.mark.smoke,
    pytest.mark.skipif(
        not os.environ.get("OPENROUTER_API_KEY"), reason="OPENROUTER_API_KEY not set"
    ),
]

SMOKE_MODEL = os.environ.get("BINHO_SMOKE_MODEL", "anthropic/claude-haiku-4-5")


@pytest.mark.asyncio
async def test_basic_completion_returns_text():
    final: Result | None = None
    async for ev in query(
        prompt="Reply with the single word OK.", options=Options(model=SMOKE_MODEL)
    ):
        if ev.type == "result":
            final = cast(Result, ev)
    assert final is not None
    assert final.stop_reason in {"end_turn", "max_turns"}
    assert final.usage.input_tokens > 0
    assert final.usage.output_tokens > 0


@pytest.mark.asyncio
async def test_tool_use_round_trip(tmp_path):
    """Ask the model to read a file via the Read built-in."""
    sample = tmp_path / "secret.txt"
    sample.write_text("the magic word is rumpelstiltskin")
    final: Result | None = None
    prompt = (
        f"Use the Read tool to read the file at {sample}. "
        "Then reply with only the magic word from that file."
    )
    async for ev in query(
        prompt=prompt,
        options=Options(model=SMOKE_MODEL, tools=["Read"], cwd=str(tmp_path)),
    ):
        if ev.type == "result":
            final = cast(Result, ev)
    assert final is not None
    assistant_text = "".join(
        m.get("content") or "" for m in final.messages if m.get("role") == "assistant"
    )
    assert "rumpelstiltskin" in assistant_text.lower()


@pytest.mark.asyncio
async def test_cost_usd_present_when_available():
    final: Result | None = None
    async for ev in query(prompt="Say 'hi'.", options=Options(model=SMOKE_MODEL)):
        if ev.type == "result":
            final = cast(Result, ev)
    assert final is not None
    # OpenRouter populates `cost` in the usage payload when supported.
    # We don't fail if it's None — some providers omit it.
    if final.usage.cost_usd is not None:
        assert final.usage.cost_usd >= 0
