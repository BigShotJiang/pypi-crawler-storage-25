# tests/test_tools_base.py
"""Tool dataclass, ToolReturn, ToolContext, ReadTracker, @tool decorator."""
from __future__ import annotations

import pytest
from pydantic import BaseModel

from binho_sdk.options import Options
from binho_sdk.tools.base import (
    ReadTracker,
    Tool,
    ToolContext,
    ToolReturn,
    tool,
)


def make_ctx(**overrides) -> ToolContext:
    base = dict(
        cwd="/tmp",
        options=Options(model="m"),
        agent_id=None,
        agent_type=None,
        tool_use_id="t1",
        tool_name="grep",
        messages=[],
        read_tracker=ReadTracker(),
        hook_dispatcher=None,             # type: ignore[arg-type]
        usage_accumulator=None,           # type: ignore[arg-type]
        emit=lambda _e: None,
        tool_mcp_server=None,
        mcp_clients={},
        provider=None,                    # type: ignore[arg-type]
        resolved_tools={},
    )
    base.update(overrides)
    return ToolContext(**base)


def test_tool_dataclass_required_fields():
    t = Tool(
        name="x",
        description="...",
        parameters_schema={"type": "object"},
        handler=lambda args, ctx: ToolReturn(content=""),  # type: ignore[arg-type]
    )
    assert t.execution_mode == "parallel"
    assert t.source == "user"
    assert t.mcp_server is None


def test_tool_return_defaults():
    r = ToolReturn(content="ok")
    assert r.is_error is False
    assert r.terminate is False


def test_read_tracker_register_and_check():
    rt = ReadTracker()
    rt.register("/a/b.py", mtime_ns=12345)
    assert rt.was_read("/a/b.py", current_mtime_ns=12345) is True
    assert rt.was_read("/a/b.py", current_mtime_ns=99999) is False
    assert rt.was_read("/never/read.py", current_mtime_ns=1) is False


@pytest.mark.asyncio
async def test_tool_decorator_wraps_pydantic_model():
    class Args(BaseModel):
        x: int
        y: str = "default"

    @tool(name="add", description="adds")
    async def my_tool(args: Args, ctx: ToolContext) -> str:
        return f"{args.x}-{args.y}"

    assert isinstance(my_tool, Tool)
    assert my_tool.name == "add"
    assert my_tool.description == "adds"
    assert my_tool.parameters_schema["type"] == "object"
    assert "x" in my_tool.parameters_schema["properties"]

    # Handler accepts dict, validates via Pydantic, calls the user function:
    result = await my_tool.handler({"x": 7, "y": "z"}, make_ctx())
    assert isinstance(result, ToolReturn)
    assert result.content == "7-z"


@pytest.mark.asyncio
async def test_tool_decorator_handler_returns_str_wrapped_to_tool_return():
    class Args(BaseModel):
        x: int

    @tool(name="echo", description="echoes")
    async def echo(args: Args, ctx: ToolContext) -> str:
        return str(args.x)

    r = await echo.handler({"x": 5}, make_ctx())
    assert r.content == "5"
    assert r.is_error is False


@pytest.mark.asyncio
async def test_tool_decorator_handler_raises_on_invalid_args():
    """Pydantic validation errors propagate; the dispatcher catches them."""
    class Args(BaseModel):
        x: int

    @tool(name="strict", description="strict")
    async def strict(args: Args, ctx: ToolContext) -> str:
        return ""

    with pytest.raises(Exception):  # noqa: B017
        await strict.handler({"x": "not an int"}, make_ctx())


def test_tool_decorator_supports_execution_mode_sequential():
    class Args(BaseModel):
        pass

    @tool(name="seq", description="...", execution_mode="sequential")
    async def seq(args: Args, ctx: ToolContext) -> str:
        return ""

    assert seq.execution_mode == "sequential"
