"""OpenRouter provider unit tests with a fake openai client.

HTTP-level retry tests are in test_openrouter_http.py (Task 4.5).
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass

import pytest

from binho_sdk.events import Usage  # noqa: F401
from binho_sdk.options import Options
from binho_sdk.providers.openrouter import OpenRouterProvider

# --- Fakes that mimic openai's streaming chunk shape ---

@dataclass
class _Delta:
    content: str | None = None
    tool_calls: list | None = None


@dataclass
class _Choice:
    delta: _Delta
    finish_reason: str | None = None
    index: int = 0


@dataclass
class _OpenAIUsage:
    prompt_tokens: int
    completion_tokens: int


@dataclass
class _Chunk:
    choices: list[_Choice]
    usage: _OpenAIUsage | None = None


@dataclass
class _ToolCallFunctionDelta:
    name: str | None = None
    arguments: str | None = None


@dataclass
class _ToolCallDelta:
    index: int | None
    id: str | None = None
    type: str = "function"
    function: _ToolCallFunctionDelta = None  # type: ignore[assignment]


class _FakeStream:
    def __init__(self, chunks: list[_Chunk]) -> None:
        self._chunks = chunks

    def __aiter__(self) -> AsyncIterator[_Chunk]:
        return self._gen()

    async def _gen(self):
        for c in self._chunks:
            yield c


class _FakeCompletions:
    def __init__(self, chunks: list[_Chunk]) -> None:
        self._chunks = chunks
        self.create_calls: list[dict] = []

    async def create(self, **kwargs):
        self.create_calls.append(kwargs)
        return _FakeStream(self._chunks)


class _FakeChat:
    def __init__(self, chunks: list[_Chunk]) -> None:
        self.completions = _FakeCompletions(chunks)


class _FakeOpenAI:
    def __init__(self, chunks: list[_Chunk]) -> None:
        self.chat = _FakeChat(chunks)


@pytest.mark.asyncio
async def test_text_delta_passthrough():
    chunks = [
        _Chunk(choices=[_Choice(delta=_Delta(content="hello"))]),
        _Chunk(choices=[_Choice(delta=_Delta(), finish_reason="stop")]),
    ]
    fake = _FakeOpenAI(chunks)
    provider = OpenRouterProvider(api_key="x", _client=fake)
    out = []
    async for ev in provider.stream(messages=[], tools=[], options=Options(model="m")):
        out.append(ev)
    assert out[0].type == "text_delta" and out[0].delta == "hello"
    assert out[-1].type == "done" and out[-1].finish_reason == "stop"


@pytest.mark.asyncio
async def test_tool_call_accumulation_across_chunks():
    """Tool call args stream as JSON fragments; provider accumulates and emits once."""
    chunks = [
        _Chunk(choices=[_Choice(delta=_Delta(tool_calls=[
            _ToolCallDelta(
                index=0,
                id="call_1",
                function=_ToolCallFunctionDelta(name="Read", arguments='{"file_'),
            )
        ]))]),
        _Chunk(choices=[_Choice(delta=_Delta(tool_calls=[
            _ToolCallDelta(
                index=0,
                function=_ToolCallFunctionDelta(arguments='path": "x.py"}'),
            )
        ]))]),
        _Chunk(choices=[_Choice(delta=_Delta(), finish_reason="tool_calls")]),
    ]
    fake = _FakeOpenAI(chunks)
    provider = OpenRouterProvider(api_key="x", _client=fake)
    events = [ev async for ev in provider.stream(messages=[], tools=[], options=Options(model="m"))]
    tool_events = [e for e in events if e.type == "tool_call"]
    assert len(tool_events) == 1
    assert tool_events[0].id == "call_1"
    assert tool_events[0].name == "Read"
    assert tool_events[0].arguments == {"file_path": "x.py"}


@pytest.mark.asyncio
async def test_parallel_tool_calls_with_index_none():
    """Gemini's OpenAI-compat endpoint emits each parallel tool call as one
    complete delta with ``index=None`` and a unique ``id``. Without the id-
    based fallback key, all three calls would collapse into a single
    accumulator slot, producing concatenated argument strings that fail
    json.loads — yielding one _BlockedPlan instead of three valid calls.
    """
    chunks = [
        _Chunk(choices=[_Choice(delta=_Delta(tool_calls=[
            _ToolCallDelta(
                index=None, id="call_a",
                function=_ToolCallFunctionDelta(name="register", arguments='{"slug":"a"}'),
            ),
            _ToolCallDelta(
                index=None, id="call_b",
                function=_ToolCallFunctionDelta(name="register", arguments='{"slug":"b"}'),
            ),
            _ToolCallDelta(
                index=None, id="call_c",
                function=_ToolCallFunctionDelta(name="register", arguments='{"slug":"c"}'),
            ),
        ]))]),
        _Chunk(choices=[_Choice(delta=_Delta(), finish_reason="tool_calls")]),
    ]
    fake = _FakeOpenAI(chunks)
    provider = OpenRouterProvider(api_key="x", _client=fake)
    events = [ev async for ev in provider.stream(messages=[], tools=[], options=Options(model="m"))]
    tool_events = [e for e in events if e.type == "tool_call"]
    assert len(tool_events) == 3
    by_id = {e.id: e for e in tool_events}
    assert by_id["call_a"].arguments == {"slug": "a"}
    assert by_id["call_b"].arguments == {"slug": "b"}
    assert by_id["call_c"].arguments == {"slug": "c"}
    assert all(e.name == "register" for e in tool_events)


@pytest.mark.asyncio
async def test_malformed_tool_args_sets_raw_arguments():
    """When the model produces non-JSON tool args, raw_arguments carries the broken string."""
    chunks = [
        _Chunk(choices=[_Choice(delta=_Delta(tool_calls=[
            _ToolCallDelta(
                index=0,
                id="bad_call",
                function=_ToolCallFunctionDelta(name="Read", arguments="<<<not-json>>>"),
            )
        ]))]),
        _Chunk(choices=[_Choice(delta=_Delta(), finish_reason="tool_calls")]),
    ]
    fake = _FakeOpenAI(chunks)
    provider = OpenRouterProvider(api_key="x", _client=fake)
    events = [ev async for ev in provider.stream(messages=[], tools=[], options=Options(model="m"))]
    tool_events = [e for e in events if e.type == "tool_call"]
    assert len(tool_events) == 1
    ev = tool_events[0]
    assert ev.id == "bad_call"
    assert ev.raw_arguments == "<<<not-json>>>"
    # arguments dict is empty (not the broken string) — the raw_arguments field carries it
    assert ev.arguments == {}


@pytest.mark.asyncio
async def test_usage_emission():
    chunks = [
        _Chunk(
            choices=[_Choice(delta=_Delta(content="hi"), finish_reason="stop")],
            usage=_OpenAIUsage(prompt_tokens=10, completion_tokens=2),
        ),
    ]
    fake = _FakeOpenAI(chunks)
    provider = OpenRouterProvider(api_key="x", _client=fake)
    events = [ev async for ev in provider.stream(messages=[], tools=[], options=Options(model="m"))]
    usage = [e for e in events if e.type == "usage"]
    assert len(usage) == 1
    assert usage[0].usage.input_tokens == 10
    assert usage[0].usage.output_tokens == 2
