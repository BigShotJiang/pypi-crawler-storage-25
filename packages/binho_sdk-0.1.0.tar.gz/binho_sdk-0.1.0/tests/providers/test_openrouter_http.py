"""HTTP-level tests: retry and error-wrapping.

These tests go through the real openai SDK against a respx-mocked endpoint,
exercising the retry path end-to-end.
"""
import pytest
import respx
from httpx import Response

from binho_sdk.errors import AuthError, TransportError
from binho_sdk.options import Options
from binho_sdk.providers._retry import RetryPolicy
from binho_sdk.providers.openrouter import OpenRouterProvider

_SSE_BODY = (
    "data: "
    '{"id":"x","choices":[{"delta":{"content":"hi"},"finish_reason":"stop","index":0}],"usage":null}'
    "\n\n"
    "data: [DONE]\n\n"
)


@respx.mock(assert_all_called=True)
@pytest.mark.asyncio
async def test_429_then_200_is_retried(respx_mock):
    route = respx_mock.post("https://openrouter.ai/api/v1/chat/completions").mock(
        side_effect=[
            Response(429, headers={"Retry-After": "0"}, json={"error": "rate"}),
            Response(200, headers={"content-type": "text/event-stream"}, text=_SSE_BODY),
        ]
    )
    provider = OpenRouterProvider(
        api_key="x",
        retry_policy=RetryPolicy(max_attempts=3, base_delay_seconds=0.001, jitter=False),
    )
    out = []
    async for ev in provider.stream(
        messages=[{"role": "user", "content": "hi"}], tools=[], options=Options(model="m")
    ):
        out.append(ev)
    assert any(e.type == "text_delta" for e in out)
    assert route.call_count == 2


@respx.mock(assert_all_called=True)
@pytest.mark.asyncio
async def test_sustained_401_raises_auth_error(respx_mock):
    """A 401 response must be wrapped as binho_sdk.errors.AuthError, not openai.*."""
    respx_mock.post("https://openrouter.ai/api/v1/chat/completions").mock(
        return_value=Response(
            401,
            json={"error": {"message": "Invalid API key", "type": "invalid_request_error"}},
        )
    )
    provider = OpenRouterProvider(
        api_key="bad-key",
        retry_policy=RetryPolicy(max_attempts=1),
    )
    with pytest.raises(AuthError):
        async for _ in provider.stream(
            messages=[{"role": "user", "content": "hi"}], tools=[], options=Options(model="m")
        ):
            pass


_PARTIAL_SSE_THEN_BROKEN = (
    "data: "
    '{"id":"x","choices":[{"delta":{"content":"par"},"finish_reason":null,"index":0}],"usage":null}'
    "\n\n"
    # malformed second event — triggers a parse error mid-stream inside the openai SDK
    "data: {not json"
    "\n\n"
)


@respx.mock(assert_all_called=True)
@pytest.mark.asyncio
async def test_midstream_failure_is_not_retried(respx_mock):
    """If any event has been delivered, a subsequent failure must NOT replay."""
    full_sse = (
        "data: "
        '{"id":"x","choices":[{"delta":{"content":"hi"},'
        '"finish_reason":"stop","index":0}],"usage":null}'
        "\n\ndata: [DONE]\n\n"
    )
    route = respx_mock.post("https://openrouter.ai/api/v1/chat/completions").mock(
        side_effect=[
            Response(
                200, headers={"content-type": "text/event-stream"}, text=_PARTIAL_SSE_THEN_BROKEN
            ),
            Response(200, headers={"content-type": "text/event-stream"}, text=full_sse),
        ]
    )
    provider = OpenRouterProvider(
        api_key="x",
        retry_policy=RetryPolicy(max_attempts=3, base_delay_seconds=0.001, jitter=False),
    )
    out = []
    with pytest.raises(TransportError, match="partial output"):
        async for ev in provider.stream(
            messages=[{"role": "user", "content": "hi"}],
            tools=[],
            options=Options(model="m"),
        ):
            out.append(ev)
    # First chunk delivered before the parse error, then surfaced — not replayed.
    assert any(getattr(e, "delta", None) == "par" for e in out)
    assert route.call_count == 1
