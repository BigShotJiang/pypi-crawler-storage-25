from binho_sdk.providers._retry import (
    RetryPolicy,
    classify_error,
    compute_backoff,
    extract_retry_after,
)


class FakeHTTPError(Exception):
    def __init__(self, status: int, retry_after: float | None = None) -> None:
        super().__init__(f"http {status}")
        self.status_code = status
        if retry_after is not None:
            self.retry_after = retry_after


def test_classify_auth():
    assert classify_error(FakeHTTPError(401)) == "auth"
    assert classify_error(Exception("Invalid API key")) == "auth"


def test_classify_quota():
    assert classify_error(FakeHTTPError(402)) == "quota"
    assert classify_error(Exception("insufficient_quota")) == "quota"


def test_classify_rate_limited():
    assert classify_error(FakeHTTPError(429)) == "rate_limited"


def test_classify_transient_otherwise():
    assert classify_error(FakeHTTPError(500)) == "transient"
    assert classify_error(ConnectionError("reset")) == "transient"


def test_extract_retry_after_from_attr():
    e = FakeHTTPError(429, retry_after=5.0)
    assert extract_retry_after(e) == 5.0


def test_compute_backoff_respects_retry_after():
    p = RetryPolicy(base_delay_seconds=1.0, jitter=False)
    e = FakeHTTPError(429, retry_after=12.0)
    assert compute_backoff(attempt=0, exc=e, policy=p) == 12.0


def test_compute_backoff_exponential_when_no_retry_after():
    p = RetryPolicy(base_delay_seconds=1.0, jitter=False, max_delay_seconds=60.0)
    e = FakeHTTPError(429)
    # attempt=0 -> 1s, 1->2s, 2->4s, 3->8s, 4->16s
    assert compute_backoff(0, e, p) == 1.0
    assert compute_backoff(2, e, p) == 4.0
    assert compute_backoff(10, e, p) == 60.0  # capped
