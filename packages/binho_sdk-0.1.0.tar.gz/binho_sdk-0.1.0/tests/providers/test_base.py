from binho_sdk.events import Usage
from binho_sdk.providers.base import (
    Provider,
    ProviderDone,
    ProviderEvent,
    ProviderTextDelta,
    ProviderToolCall,
    ProviderUsage,
)


def test_provider_event_dataclasses():
    td = ProviderTextDelta(delta="hi")
    tc = ProviderToolCall(id="t1", name="Read", arguments={"file_path": "x"})
    pu = ProviderUsage(usage=Usage(input_tokens=1, output_tokens=2))
    pd = ProviderDone(finish_reason="stop")
    assert td.type == "text_delta"
    assert tc.type == "tool_call"
    assert pu.type == "usage"
    assert pd.type == "done"
    events: list[ProviderEvent] = [td, tc, pu, pd]
    assert len(events) == 4


def test_provider_protocol_is_runtime_checkable():
    assert hasattr(Provider, "stream")
