import pytest

from binho_sdk.events import Usage
from binho_sdk.options import Options
from binho_sdk.providers.base import (
    ProviderDone,
    ProviderTextDelta,
    ProviderToolCall,  # noqa: F401
    ProviderUsage,
)
from binho_sdk.providers.mock import MockProvider, ProviderCallRecord  # noqa: F401


@pytest.mark.asyncio
async def test_mock_yields_scripted_events_in_order():
    provider = MockProvider([
        [
            ProviderTextDelta(delta="hi"),
            ProviderDone(finish_reason="stop"),
            ProviderUsage(usage=Usage(input_tokens=1, output_tokens=1)),
        ]
    ])
    seen = []
    async for ev in provider.stream(messages=[], tools=[], options=Options(model="m")):
        seen.append(ev)
    assert [e.type for e in seen] == ["text_delta", "done", "usage"]


@pytest.mark.asyncio
async def test_mock_records_calls():
    p = MockProvider([
        [ProviderDone(finish_reason="stop")],
        [ProviderDone(finish_reason="stop")],
    ])
    async for _ in p.stream(
        messages=[{"role": "user", "content": "a"}], tools=[], options=Options(model="m")
    ):
        pass
    async for _ in p.stream(
        messages=[{"role": "user", "content": "b"}], tools=[], options=Options(model="m")
    ):
        pass
    assert len(p.recorded_calls) == 2
    assert p.recorded_calls[0].messages[0]["content"] == "a"
    assert p.recorded_calls[1].messages[0]["content"] == "b"


@pytest.mark.asyncio
async def test_mock_raises_when_script_exhausted():
    p = MockProvider([[ProviderDone(finish_reason="stop")]])
    async for _ in p.stream(messages=[], tools=[], options=Options(model="m")):
        pass
    with pytest.raises(IndexError):
        async for _ in p.stream(messages=[], tools=[], options=Options(model="m")):
            pass
