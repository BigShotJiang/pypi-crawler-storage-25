from pathlib import Path

from binho_sdk.options import AgentDefinition, McpServerConfig, Options


def test_options_minimal_construction():
    opts = Options(model="anthropic/claude-sonnet-4-5")
    assert opts.model == "anthropic/claude-sonnet-4-5"
    assert opts.tools == []
    assert opts.agents == {}
    assert opts.hooks == {}
    assert opts.mcp_servers == {}
    assert opts.permission_mode == "default"
    assert opts.max_turns == 50
    assert opts.context_window is None  # disables context_full check by default


def test_options_with_overrides_returns_new_instance():
    a = Options(model="m1", tools=["Read"])
    b = a.with_overrides(model="m2")
    assert a.model == "m1"
    assert b.model == "m2"
    assert b.tools == ["Read"]  # inherited


def test_options_with_overrides_does_not_share_mutable_collections():
    a = Options(model="m", tools=["Read"], mcp_servers={"x": McpServerConfig(url="http://x")})
    b = a.with_overrides(model="m2")
    # MCP servers inherited (shallow shared is fine for read-only consumption)
    assert "x" in b.mcp_servers


def test_agent_definition_defaults():
    ad = AgentDefinition(description="Explores code", prompt="You are an explorer.")
    assert ad.tools is None  # inherit
    assert ad.model is None
    assert ad.max_turns == 25
    assert ad.permission_mode is None


def test_mcp_server_config_defaults():
    cfg = McpServerConfig(url="https://x/mcp")
    assert cfg.headers == {}
    assert cfg.timeout_seconds == 30.0
    assert cfg.init_timeout_seconds == 10.0


def test_options_allowed_paths_optional():
    opts = Options(model="m", allowed_paths=[Path("/tmp")])
    assert opts.allowed_paths == [Path("/tmp")]
