from binho_sdk.loop.token_budget import estimate_tokens


def test_estimate_empty():
    assert estimate_tokens([]) == 0


def test_estimate_simple_user_message():
    msgs = [{"role": "user", "content": "hello world"}]
    n = estimate_tokens(msgs)
    assert n > 0
    assert n < 20  # generous upper bound


def test_estimate_grows_with_content():
    a = estimate_tokens([{"role": "user", "content": "x" * 100}])
    b = estimate_tokens([{"role": "user", "content": "x" * 1000}])
    assert b > a * 5


def test_estimate_includes_tool_call_arguments():
    msgs = [{
        "role": "assistant",
        "content": None,
        "tool_calls": [{"id": "1", "type": "function",
                        "function": {"name": "Read", "arguments": '{"file_path": "x"}'}}],
    }]
    n = estimate_tokens(msgs)
    assert n > 0
