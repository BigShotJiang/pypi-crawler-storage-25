# tests/loop/test_runner.py
"""End-to-end loop tests with MockProvider + a single fake tool."""
from __future__ import annotations

from typing import cast

import pytest
from pydantic import BaseModel

from binho_sdk.events import Result, TextDelta, ToolResult, ToolUse, TurnStart, Usage
from binho_sdk.options import Options
from binho_sdk.providers.base import (
    ProviderDone,
    ProviderTextDelta,
    ProviderToolCall,
    ProviderUsage,
)
from binho_sdk.providers.mock import MockProvider
from binho_sdk.query import query
from binho_sdk.tools.base import ToolContext, ToolReturn, tool


class _ReadArgs(BaseModel):
    file_path: str


@tool(name="Read", description="(test fake)")
async def fake_read(args: _ReadArgs, ctx: ToolContext) -> str:
    return f"contents of {args.file_path}"


@pytest.mark.asyncio
async def test_one_turn_no_tool_calls():
    provider = MockProvider([
        [
            ProviderTextDelta(delta="hello"),
            ProviderDone(finish_reason="stop"),
            ProviderUsage(usage=Usage(input_tokens=1, output_tokens=1)),
        ]
    ])
    events = []
    async for ev in query(prompt="hi", options=Options(model="m"), _provider=provider):
        events.append(ev)
    assert isinstance(events[0], TurnStart)
    text = "".join(e.delta for e in events if isinstance(e, TextDelta))
    assert text == "hello"
    final = cast(Result, events[-1])
    assert final.stop_reason == "end_turn"
    assert final.messages[0]["role"] == "user"
    assert final.messages[-1]["role"] == "assistant"


@pytest.mark.asyncio
async def test_two_turns_with_tool_call():
    provider = MockProvider([
        # Turn 1: model calls Read
        [
            ProviderToolCall(id="t1", name="Read", arguments={"file_path": "x.py"}),
            ProviderDone(finish_reason="tool_calls"),
        ],
        # Turn 2: model produces final text
        [
            ProviderTextDelta(delta="done."),
            ProviderDone(finish_reason="stop"),
        ],
    ])
    events = []
    async for ev in query(
        prompt="read x.py", options=Options(model="m", tools=[fake_read]), _provider=provider
    ):
        events.append(ev)
    assert any(isinstance(e, ToolUse) and e.name == "Read" for e in events)
    assert any(isinstance(e, ToolResult) and not e.is_error for e in events)
    final = cast(Result, events[-1])
    assert final.stop_reason == "end_turn"
    # Turn 2 saw the tool result message:
    assert any(
        m.get("role") == "tool" and m.get("tool_call_id") == "t1"
        for m in provider.recorded_calls[1].messages
    )


@pytest.mark.asyncio
async def test_max_turns_cap():
    """Looping forever stops at max_turns."""
    # Build 5 turns each emitting a tool call:
    provider = MockProvider([
        [
            ProviderToolCall(id=f"t{i}", name="Read", arguments={"file_path": "x"}),
            ProviderDone(finish_reason="tool_calls"),
        ]
        for i in range(5)
    ])
    events = []
    async for ev in query(
        prompt="loop",
        options=Options(model="m", tools=[fake_read], max_turns=3),
        _provider=provider,
    ):
        events.append(ev)
    final = cast(Result, events[-1])
    assert final.stop_reason == "max_turns"


@pytest.mark.asyncio
async def test_terminate_true_stops_when_all_tools_terminate():
    @tool(name="Halt", description="t")
    async def halt(args: _ReadArgs, ctx: ToolContext) -> ToolReturn:
        return ToolReturn(content="bye", terminate=True)

    provider = MockProvider([
        [
            ProviderToolCall(id="t1", name="Halt", arguments={"file_path": "x"}),
            ProviderDone(finish_reason="tool_calls"),
        ],
    ])
    events = []
    async for ev in query(
        prompt="stop", options=Options(model="m", tools=[halt]), _provider=provider
    ):
        events.append(ev)
    final = cast(Result, events[-1])
    assert final.stop_reason == "tool_terminate"


@pytest.mark.asyncio
async def test_unknown_string_tool_name_fails_at_start():
    """Strings in Options.tools must resolve to a built-in or be `mcp__...`."""
    from binho_sdk.errors import BinhoConfigError
    provider = MockProvider([
        [ProviderDone(finish_reason="stop")]  # never reached
    ])
    with pytest.raises(BinhoConfigError):
        async for _ in query(
            prompt="hi", options=Options(model="m", tools=["NotABuiltin"]), _provider=provider
        ):
            pass


@pytest.mark.asyncio
async def test_malformed_tool_args_become_blocked_tool_result():
    """When the provider cannot parse tool arguments, the result must be an error ToolResult
    with a reason that mentions malformed/JSON, not a silent empty-args invocation."""
    provider = MockProvider([
        # Turn 1: model emits tool call with broken JSON args (raw_arguments set)
        [
            ProviderToolCall(
                id="t1", name="Read", arguments={}, raw_arguments="<<<not-json>>>"
            ),
            ProviderDone(finish_reason="tool_calls"),
        ],
        # Turn 2: model ends after seeing the error tool result
        [
            ProviderTextDelta(delta="done"),
            ProviderDone(finish_reason="stop"),
        ],
    ])
    events = []
    async for ev in query(
        prompt="hi", options=Options(model="m", tools=[fake_read]), _provider=provider
    ):
        events.append(ev)
    tool_results = [e for e in events if isinstance(e, ToolResult)]
    assert len(tool_results) == 1
    tr = tool_results[0]
    assert tr.is_error
    # The reason must mention malformed or JSON (case-insensitive)
    reason_lower = tr.content.lower()
    assert "malformed" in reason_lower or "json" in reason_lower


@pytest.mark.asyncio
async def test_usage_aggregates_across_turns():
    provider = MockProvider([
        [
            ProviderToolCall(id="t1", name="Read", arguments={"file_path": "x"}),
            ProviderDone(finish_reason="tool_calls"),
            ProviderUsage(usage=Usage(input_tokens=10, output_tokens=5)),
        ],
        [
            ProviderTextDelta(delta="done"),
            ProviderDone(finish_reason="stop"),
            ProviderUsage(usage=Usage(input_tokens=20, output_tokens=8)),
        ],
    ])
    events = []
    async for ev in query(
        prompt="hi", options=Options(model="m", tools=[fake_read]), _provider=provider
    ):
        events.append(ev)
    final = cast(Result, events[-1])
    assert final.usage.input_tokens == 30
    assert final.usage.output_tokens == 13
