# tests/loop/test_tool_dispatch.py
"""Tool dispatcher: preflight, BlockedPlan/RunnablePlan, parallel vs sequential."""
from __future__ import annotations

import asyncio

import pytest
from pydantic import BaseModel

from binho_sdk.events import ToolResult, ToolUse
from binho_sdk.hooks.dispatcher import HookDispatcher
from binho_sdk.hooks.events import HookResult
from binho_sdk.loop.tool_dispatch import dispatch_tools
from binho_sdk.messages import ToolCall
from binho_sdk.options import Options
from binho_sdk.permissions.modes import PermissionResult
from binho_sdk.tools.base import ReadTracker, ToolContext, ToolReturn, tool


class _Args(BaseModel):
    x: int = 0


def make_tool(name: str, behavior, *, execution_mode="parallel"):
    @tool(name=name, description="t", execution_mode=execution_mode)
    async def fn(args: _Args, ctx: ToolContext) -> str | ToolReturn:
        return await behavior(args, ctx) if callable(behavior) else behavior

    return fn


def make_ctx_factory():
    def make(opts: Options, hd: HookDispatcher):
        return ToolContext(
            cwd="/tmp", options=opts,
            agent_id=None, agent_type=None, tool_use_id="dummy", tool_name="dummy",
            messages=[], read_tracker=ReadTracker(),
            hook_dispatcher=hd, usage_accumulator=None,  # type: ignore[arg-type]
            emit=lambda _e: None, tool_mcp_server=None, mcp_clients={},
        provider=None, resolved_tools={},  # type: ignore[arg-type]
        )

    return make


def make_tool_call(tid: str, name: str, args: dict) -> ToolCall:
    import json
    return {
        "id": tid,
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(args)},
    }


@pytest.mark.asyncio
async def test_runnable_plan_emits_tool_use_then_tool_result():
    a = make_tool("A", "ok")
    opts = Options(model="m")
    hd = HookDispatcher({})
    ctx_for = make_ctx_factory()
    events = []
    async for ev in dispatch_tools(
        tool_calls=[make_tool_call("c1", "A", {})],
        resolved={"A": a},
        options=opts,
        hooks=hd,
        ctx_factory=ctx_for,
    ):
        events.append(ev)
    assert any(isinstance(e, ToolUse) for e in events)
    assert any(isinstance(e, ToolResult) for e in events)
    last = next(e for e in events if isinstance(e, ToolResult))
    assert last.id == "c1"
    assert not last.is_error


@pytest.mark.asyncio
async def test_unknown_tool_name_blocks_with_synthetic_result():
    opts = Options(model="m")
    events = []
    async for ev in dispatch_tools(
        tool_calls=[make_tool_call("c1", "Nope", {})],
        resolved={},
        options=opts,
        hooks=HookDispatcher({}),
        ctx_factory=make_ctx_factory(),
    ):
        events.append(ev)
    res = next(e for e in events if isinstance(e, ToolResult))
    assert res.is_error
    assert "Nope" in res.content


@pytest.mark.asyncio
async def test_pre_tool_use_deny_blocks_execution():
    ran = []
    async def behavior(_args, _ctx):
        ran.append(True)
        return "should not run"

    a = make_tool("A", behavior)
    opts = Options(model="m")

    async def deny_hook(_ctx):
        return HookResult(decision="deny", reason="nope")

    hd = HookDispatcher({"PreToolUse": [deny_hook]})

    events = []
    async for ev in dispatch_tools(
        tool_calls=[make_tool_call("c1", "A", {})],
        resolved={"A": a},
        options=opts,
        hooks=hd,
        ctx_factory=make_ctx_factory(),
    ):
        events.append(ev)
    res = next(e for e in events if isinstance(e, ToolResult))
    assert res.is_error and "nope" in res.content
    assert ran == []


@pytest.mark.asyncio
async def test_can_use_tool_deny_blocks_execution():
    a = make_tool("A", "ran")

    async def deny_cb(_inp):
        return PermissionResult(behavior="deny", message="permission says no")

    opts = Options(model="m", can_use_tool=deny_cb)

    events = []
    async for ev in dispatch_tools(
        tool_calls=[make_tool_call("c1", "A", {})],
        resolved={"A": a},
        options=opts,
        hooks=HookDispatcher({}),
        ctx_factory=make_ctx_factory(),
    ):
        events.append(ev)
    res = next(e for e in events if isinstance(e, ToolResult))
    assert res.is_error and "permission says no" in res.content


@pytest.mark.asyncio
async def test_results_are_emitted_in_source_order_despite_reverse_completion():
    """Tool A finishes after tool B; ToolResult events must still come out A then B."""
    a_done = asyncio.Event()

    async def slow_a(_args, _ctx):
        await asyncio.sleep(0.05)
        a_done.set()
        return "A"

    async def fast_b(_args, _ctx):
        return "B"

    a = make_tool("A", slow_a)
    b = make_tool("B", fast_b)

    opts = Options(model="m")
    events = []
    async for ev in dispatch_tools(
        tool_calls=[make_tool_call("c1", "A", {}), make_tool_call("c2", "B", {})],
        resolved={"A": a, "B": b},
        options=opts,
        hooks=HookDispatcher({}),
        ctx_factory=make_ctx_factory(),
    ):
        events.append(ev)
    results = [e for e in events if isinstance(e, ToolResult)]
    assert results[0].id == "c1"
    assert results[1].id == "c2"


@pytest.mark.asyncio
async def test_sequential_execution_when_any_tool_is_sequential():
    """When any tool in the batch has execution_mode='sequential', the whole batch runs serially."""
    order = []

    async def a_fn(_args, _ctx):
        order.append("a-start")
        await asyncio.sleep(0.02)
        order.append("a-end")
        return "A"

    async def b_fn(_args, _ctx):
        order.append("b-start")
        order.append("b-end")
        return "B"

    a = make_tool("A", a_fn, execution_mode="sequential")
    b = make_tool("B", b_fn)
    opts = Options(model="m")

    async for _ in dispatch_tools(
        tool_calls=[make_tool_call("c1", "A", {}), make_tool_call("c2", "B", {})],
        resolved={"A": a, "B": b},
        options=opts,
        hooks=HookDispatcher({}),
        ctx_factory=make_ctx_factory(),
    ):
        pass
    # Sequential: a-start,a-end then b-start,b-end (no interleaving).
    assert order == ["a-start", "a-end", "b-start", "b-end"]


@pytest.mark.asyncio
async def test_handler_exception_becomes_error_tool_result():
    async def boom(_args, _ctx):
        raise RuntimeError("oops")
    a = make_tool("A", boom)
    opts = Options(model="m")
    events = []
    async for ev in dispatch_tools(
        tool_calls=[make_tool_call("c1", "A", {})],
        resolved={"A": a},
        options=opts,
        hooks=HookDispatcher({}),
        ctx_factory=make_ctx_factory(),
    ):
        events.append(ev)
    res = next(e for e in events if isinstance(e, ToolResult))
    assert res.is_error and "oops" in res.content


@pytest.mark.asyncio
async def test_invalid_args_per_jsonschema_blocks():
    a = make_tool("A", "x")
    opts = Options(model="m")
    # Invalid: the tool expects an int x; we send a string.
    events = []
    async for ev in dispatch_tools(
        tool_calls=[make_tool_call("c1", "A", {"x": "not int"})],
        resolved={"A": a},
        options=opts,
        hooks=HookDispatcher({}),
        ctx_factory=make_ctx_factory(),
    ):
        events.append(ev)
    res = next(e for e in events if isinstance(e, ToolResult))
    assert res.is_error
