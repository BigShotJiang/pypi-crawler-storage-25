# tests/loop/test_subagents.py
"""Subagent (Task tool) tests: fresh context, hook propagation, usage aggregation."""
from __future__ import annotations

from typing import cast

import pytest
from pydantic import BaseModel

from binho_sdk.events import Result, SubagentEnd, SubagentStart, Usage
from binho_sdk.options import AgentDefinition, Options
from binho_sdk.providers.base import (
    ProviderDone,
    ProviderTextDelta,
    ProviderToolCall,
    ProviderUsage,
)
from binho_sdk.providers.mock import MockProvider
from binho_sdk.query import query
from binho_sdk.tools.base import ToolContext, tool


class _A(BaseModel):
    file_path: str = "x.py"


@tool(name="Read", description="(test fake)")
async def fake_read(args: _A, ctx: ToolContext) -> str:
    return f"content of {args.file_path}"


@pytest.mark.asyncio
async def test_subagent_starts_with_fresh_context():
    """Subagent's first call to provider has only [system, user] messages."""
    provider = MockProvider([
        # Parent turn 1: spawns Task
        [
            ProviderToolCall(id="t1", name="Task",
                             arguments={"subagent_type": "explorer", "description": "explore",
                                        "prompt": "Find foo"}),
            ProviderDone(finish_reason="tool_calls"),
        ],
        # Subagent turn 1: produces final text
        [
            ProviderTextDelta(delta="found foo"),
            ProviderDone(finish_reason="stop"),
        ],
        # Parent turn 2: ends
        [
            ProviderTextDelta(delta="ok"),
            ProviderDone(finish_reason="stop"),
        ],
    ])

    explorer = AgentDefinition(description="explorer", prompt="You are an explorer.")
    options = Options(
        model="m",
        tools=["Task"],
        agents={"explorer": explorer},
    )
    events = []
    async for ev in query(prompt="please find foo", options=options, _provider=provider):
        events.append(ev)

    # Subagent envelopes are visible to caller:
    assert any(isinstance(e, SubagentStart) and e.agent_type == "explorer" for e in events)
    assert any(isinstance(e, SubagentEnd) and "found foo" in e.result for e in events)

    # Subagent's first call: [system, user] only — no parent history.
    sub_call = provider.recorded_calls[1]
    assert sub_call.messages[0]["role"] == "system"
    assert sub_call.messages[0]["content"] == "You are an explorer."
    assert sub_call.messages[1]["role"] == "user"
    assert sub_call.messages[1]["content"] == "Find foo"
    assert len(sub_call.messages) == 2


@pytest.mark.asyncio
async def test_parent_model_sees_subagent_result_as_one_tool_message():
    provider = MockProvider([
        [
            ProviderToolCall(id="t1", name="Task",
                             arguments={"subagent_type": "x", "description": "d", "prompt": "p"}),
            ProviderDone(finish_reason="tool_calls"),
        ],
        [
            ProviderTextDelta(delta="SUBRESULT"),
            ProviderDone(finish_reason="stop"),
        ],
        [
            ProviderTextDelta(delta="parent done"),
            ProviderDone(finish_reason="stop"),
        ],
    ])
    options = Options(model="m", tools=["Task"],
                      agents={"x": AgentDefinition(description="x", prompt="x")})
    async for _ in query(prompt="hi", options=options, _provider=provider):
        pass

    parent_turn2 = provider.recorded_calls[2]
    tool_msgs = [m for m in parent_turn2.messages if m.get("role") == "tool"]
    assert len(tool_msgs) == 1
    assert tool_msgs[0]["content"] == "SUBRESULT"
    assert tool_msgs[0]["tool_call_id"] == "t1"


@pytest.mark.asyncio
async def test_subagent_usage_aggregates_into_parent_total():
    provider = MockProvider([
        [
            ProviderToolCall(id="t1", name="Task",
                             arguments={"subagent_type": "x", "description": "d", "prompt": "p"}),
            ProviderDone(finish_reason="tool_calls"),
            ProviderUsage(usage=Usage(input_tokens=10, output_tokens=5)),
        ],
        [
            ProviderTextDelta(delta="ok"),
            ProviderDone(finish_reason="stop"),
            ProviderUsage(usage=Usage(input_tokens=100, output_tokens=20)),
        ],
        [
            ProviderTextDelta(delta="done"),
            ProviderDone(finish_reason="stop"),
            ProviderUsage(usage=Usage(input_tokens=15, output_tokens=2)),
        ],
    ])
    options = Options(model="m", tools=["Task"],
                      agents={"x": AgentDefinition(description="x", prompt="x")})
    events = []
    async for ev in query(prompt="hi", options=options, _provider=provider):
        events.append(ev)
    final = cast(Result, events[-1])
    # 10+100+15 = 125 input; 5+20+2 = 27 output
    assert final.usage.input_tokens == 125
    assert final.usage.output_tokens == 27


@pytest.mark.asyncio
async def test_subagent_start_event_precedes_task_tool_result():
    """SubagentStart must be emitted BEFORE the ToolResult for the parent Task call."""
    provider = MockProvider([
        # Parent turn 1: spawns Task
        [
            ProviderToolCall(id="t1", name="Task",
                             arguments={"subagent_type": "explorer", "description": "d",
                                        "prompt": "Find foo"}),
            ProviderDone(finish_reason="tool_calls"),
        ],
        # Subagent turn 1: produces final text
        [
            ProviderTextDelta(delta="found it"),
            ProviderDone(finish_reason="stop"),
        ],
        # Parent turn 2: ends
        [
            ProviderTextDelta(delta="ok"),
            ProviderDone(finish_reason="stop"),
        ],
    ])
    explorer = AgentDefinition(description="explorer", prompt="You are an explorer.")
    options = Options(model="m", tools=["Task"], agents={"explorer": explorer})
    events = []
    async for ev in query(prompt="find foo", options=options, _provider=provider):
        events.append(ev)

    from binho_sdk.events import ToolResult
    start_indices = [i for i, e in enumerate(events) if isinstance(e, SubagentStart)]
    task_result_indices = [
        i for i, e in enumerate(events) if isinstance(e, ToolResult) and e.id == "t1"
    ]
    assert start_indices, "No SubagentStart event found"
    assert task_result_indices, "No ToolResult for Task found"
    assert start_indices[0] < task_result_indices[0], (
        f"SubagentStart (idx {start_indices[0]}) must precede "
        f"ToolResult-for-Task (idx {task_result_indices[0]})"
    )


@pytest.mark.asyncio
async def test_subagent_unknown_agent_type_returns_error():
    provider = MockProvider([
        [
            ProviderToolCall(
                id="t1", name="Task",
                arguments={"subagent_type": "missing", "description": "d", "prompt": "p"},
            ),
            ProviderDone(finish_reason="tool_calls"),
        ],
        [
            ProviderTextDelta(delta="ok"),
            ProviderDone(finish_reason="stop"),
        ],
    ])
    options = Options(model="m", tools=["Task"], agents={})
    events = []
    async for ev in query(prompt="hi", options=options, _provider=provider):
        events.append(ev)
    # Parent's tool result for this call should be is_error=True.
    from binho_sdk.events import ToolResult
    res = next(e for e in events if isinstance(e, ToolResult) and e.id == "t1")
    assert res.is_error
