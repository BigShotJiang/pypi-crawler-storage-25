from binho_sdk.hooks.events import HookContext, HookEvent, HookResult


def test_hook_event_literal_values():
    valid: list[HookEvent] = [
        "PreToolUse",
        "PostToolUse",
        "Stop",
        "SubagentStart",
        "SubagentStop",
    ]
    assert "PreToolUse" in valid
    assert "Stop" in valid


def test_hook_context_minimal():
    ctx = HookContext(
        event="PreToolUse",
        messages=[],
        cwd="/tmp",
        options=None,  # type: ignore[arg-type]
        tool_name="Read",
        tool_input={"file_path": "x"},
        tool_use_id="t1",
    )
    assert ctx.event == "PreToolUse"
    assert ctx.tool_name == "Read"


def test_hook_result_modify_with_input():
    r = HookResult(decision="modify", modified_input={"file_path": "y"})
    assert r.decision == "modify"
    assert r.modified_input == {"file_path": "y"}


def test_hook_result_deny_with_reason():
    r = HookResult(decision="deny", reason="blocked by policy")
    assert r.decision == "deny"
    assert r.reason == "blocked by policy"
