# binho-sdk → PyPI Release: Design

**Date:** 2026-05-08
**Status:** Approved
**Repo:** github.com/unlegacy/binho-sdk
**Target:** First public release as `binho-sdk` on PyPI at version `0.1.0`

## Problem & Goals

Publish `binho-sdk` to PyPI so external users can `pip install binho-sdk`, and so the two known consumers can pin a stable distribution. The release pipeline must be:

- **Tokenless** — no long-lived `PYPI_API_TOKEN` in GitHub secrets.
- **Tag-driven** — `git tag v0.1.0 && git push --tags` is the only manual trigger.
- **Reproducible** — anyone can run `uv build` locally and get the same artifacts the workflow uploads.

## Pre-flight Findings (already verified)

- `binho-sdk` is unclaimed on PyPI (`https://pypi.org/pypi/binho-sdk/json` → 404).
- License is MIT (`LICENSE` + `pyproject.toml` classifier).
- No `TODO`/`FIXME`/`HACK` markers in source.
- No leaked secrets: `OPENROUTER_API_KEY` references are the documented public env var; test fixtures use obvious fakes (`"x"`, `"bad-key"`).
- One real corruption: README header (`README.md:3,5`) has the tagline jammed mid-sentence — must repair.
- One inconsistency: README clone URL (`README.md:239`) points at `olin-med/binho-sdk` but the canonical repo is `unlegacy/binho-sdk`.

## Decisions

| Question | Decision |
|---|---|
| Author/copyright on PyPI | `Unlegacy, Inc.` (org), maintainer email `zolin@unlegacy.ai` |
| Canonical GitHub repo | `unlegacy/binho-sdk` |
| Versioning policy | SemVer; pre-1.0 minor releases may break API; patch is bug-fix only |
| Initial version | `0.1.0` (current value in `pyproject.toml`) |
| PyPI auth | Trusted publishing via GitHub OIDC (PEP 740); no API token |
| GitHub Environment | `pypi` (gate, off by default; can later require manual approval) |
| TestPyPI dry-run | **Out of scope** — first publish is 0.1.0; yank acceptable if needed |

## Section 1 — Metadata Cleanup

Edits to existing files (no new modules):

1. **`LICENSE`** line 3 — `Copyright (c) 2026 olin-med` → `Copyright (c) 2026 Unlegacy, Inc.`
2. **`pyproject.toml`** `authors` — replace `[{ name = "olin-med" }]` with `[{ name = "Unlegacy, Inc.", email = "zolin@unlegacy.ai" }]`
3. **`pyproject.toml`** — add `[project.urls]` block:
   ```toml
   [project.urls]
   Homepage = "https://github.com/unlegacy/binho-sdk"
   Repository = "https://github.com/unlegacy/binho-sdk"
   Issues = "https://github.com/unlegacy/binho-sdk/issues"
   ```
4. **`README.md`** — repair corrupted header. Final form:
   ```
   # binho-sdk

   **A Python agent SDK with Claude Code-style loop semantics on top of OpenRouter, with first-class MCP support — developed by Unlegacy.**

   Build agents that *think* like Claude Code — same turn loop, same tool dispatch model, same hooks and permission surface — but pointed at any of the 300+ models OpenRouter exposes (Claude, GPT, Gemini, Llama, DeepSeek, Qwen, …). The public API is a single `async def query() -> AsyncIterator[Event]`. No frameworks, no graphs, no DSL.
   ```
5. **`README.md`** line 239 clone URL — `github.com/olin-med/binho-sdk` → `github.com/unlegacy/binho-sdk`
6. **`README.md`** line 106 example — `https://doc-worker.internal/mcp` → `https://example.com/mcp`
7. **`README.md`** — add a short **Versioning** section near the bottom stating the SemVer policy (see "Versioning Policy" below for exact text).

## Section 2 — Release Workflow

New file: `.github/workflows/release.yml`. Two jobs:

**`build`**
- Trigger: `on: push: tags: ['v*']`
- Steps: checkout → install `uv` → `uv build` → `actions/upload-artifact@v4` of `dist/`
- Runner: `ubuntu-latest`
- Python: 3.11 (matches min supported)

**`publish`**
- `needs: build`
- `environment: pypi`
- `permissions: { id-token: write, contents: read }`
- Steps: `actions/download-artifact@v4` → `pypa/gh-action-pypi-publish@release/v1` (no `password` field; the action uses OIDC by default when `id-token: write` is present)

The action emits PEP 740 attestations automatically — no extra config needed.

## Section 3 — PyPI-Side Setup (manual, by the user)

Pre-publish, on pypi.org:

1. Log in → "Your account" → "Publishing".
2. "Add a new pending publisher" with:
   - **PyPI Project Name:** `binho-sdk`
   - **Owner:** `unlegacy`
   - **Repository name:** `binho-sdk`
   - **Workflow name:** `release.yml`
   - **Environment name:** `pypi`
3. On GitHub: repo → Settings → Environments → create `pypi` (no required reviewers, no secrets — just the named environment).

The first successful run of `release.yml` claims the project name on PyPI.

## Section 4 — Versioning Policy (text for README)

> **Versioning.** This project follows [SemVer](https://semver.org/). While the version is `0.x`, the public API may change in minor releases (`0.1 → 0.2`); patch releases (`0.1.0 → 0.1.1`) contain bug fixes only and remain API-compatible. Pin `binho-sdk>=0.1,<0.2` if you want patch updates without surprise. The version will move to `1.0.0` once the public surface is considered stable.

## Section 5 — Release Procedure (text for `README.md` "Releasing" section or a separate `RELEASING.md` — TBD by writing-plans)

1. Bump `version` in `pyproject.toml` (SemVer).
2. `uv build` locally; inspect `dist/*.whl` and `dist/*.tar.gz` (e.g. `unzip -l dist/*.whl`).
3. Commit version bump on `main`.
4. `git tag v0.1.0 && git push origin v0.1.0`.
5. Watch the workflow; if the `publish` job succeeds, verify at `https://pypi.org/project/binho-sdk/`.
6. Create a GitHub Release from the tag (optional, for changelog visibility).

## Out of Scope (explicit YAGNI)

- TestPyPI dry-run job
- Automated changelog generation (e.g., release-please, towncrier)
- Multi-Python-version matrix in the release workflow (CI already covers test matrix)
- Signing/SBOM beyond the default attestations from `pypa/gh-action-pypi-publish`
- Renaming `OPENROUTER_API_KEY` env var or other API-surface changes

## Acceptance Criteria

- [ ] `pip install binho-sdk` from a clean venv installs `0.1.0` and `from binho_sdk import query` succeeds.
- [ ] PyPI project page shows: project name `binho-sdk`, MIT license, Homepage/Repository/Issues links to `unlegacy/binho-sdk`, author `Unlegacy, Inc.`.
- [ ] No PyPI API token exists in GitHub repo secrets.
- [ ] `git tag vX.Y.Z && git push --tags` is sufficient to ship the next release.
- [ ] README header renders cleanly with the new tagline; no clone-URL mismatches; no `*.internal` placeholders.
