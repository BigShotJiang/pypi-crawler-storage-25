# binho-sdk PyPI Release Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Publish `binho-sdk 0.1.0` to PyPI via tag-driven, tokenless GitHub Actions (OIDC trusted publishing), with cleaned-up metadata and a documented versioning policy.

**Architecture:** Three layers of work, in order: (1) metadata scrub of `LICENSE`, `pyproject.toml`, `README.md`; (2) new `release.yml` workflow that builds with `uv build` and publishes via `pypa/gh-action-pypi-publish` using OIDC; (3) manual PyPI Pending Trusted Publisher registration by the user, then a tag push.

**Tech Stack:** Python 3.11+, hatchling build backend, `uv`, GitHub Actions, PyPI trusted publishing (PEP 740 attestations).

**Spec:** `docs/superpowers/specs/2026-05-08-binho-sdk-pypi-release-design.md`

---

## File Map

| File | Action | Responsibility |
|---|---|---|
| `LICENSE` | modify line 3 | Copyright holder |
| `pyproject.toml` | modify `authors`, add `[project.urls]` | PyPI metadata |
| `README.md` | repair header, fix clone URL, fix example URL, add Versioning section | Public-facing docs |
| `.github/workflows/release.yml` | create | Tag-triggered build + publish |

No source code under `src/binho_sdk/` is touched. No tests are added (this is metadata + CI work; verification is via `uv build` artifact inspection and a real PyPI publish).

---

## Chunk 1: Metadata Scrub

### Task 1: Update LICENSE copyright holder

**Files:**
- Modify: `LICENSE` (line 3)

- [ ] **Step 1: Edit LICENSE line 3**

Replace `Copyright (c) 2026 olin-med` with `Copyright (c) 2026 Unlegacy, Inc.`

- [ ] **Step 2: Verify**

Run: `grep -n "Copyright" LICENSE`
Expected: `3:Copyright (c) 2026 Unlegacy, Inc.`

- [ ] **Step 3: Commit**

```bash
git add LICENSE
git commit -m "chore(license): update copyright holder to Unlegacy, Inc."
```

### Task 2: Update pyproject.toml authors and add project URLs

**Files:**
- Modify: `pyproject.toml` (line 12, and add new `[project.urls]` block)

- [ ] **Step 1: Replace `authors` line**

Find line 12: `authors = [{ name = "olin-med" }]`
Replace with: `authors = [{ name = "Unlegacy, Inc.", email = "zolin@unlegacy.ai" }]`

- [ ] **Step 2: Add `[project.urls]` table**

Insert after the `classifiers = [...]` block (before `dependencies = [...]`), separated by a blank line:

```toml
[project.urls]
Homepage = "https://github.com/unlegacy/binho-sdk"
Repository = "https://github.com/unlegacy/binho-sdk"
Issues = "https://github.com/unlegacy/binho-sdk/issues"
```

Note: `[project.urls]` is a TOML table and must NOT be inside the `[project]` table when written this way — but since `[project]` is the active table, this needs care. Two valid placements:

- **Inline form** (preferred — keeps it inside `[project]` cleanly): add `urls = { Homepage = "...", Repository = "...", Issues = "..." }` as a key under `[project]`.
- **Section form**: place `[project.urls]` AFTER all bare `key = value` lines of `[project]` but BEFORE `[project.optional-dependencies]`.

Use the **section form**, placed immediately before `[project.optional-dependencies]` on line 26.

- [ ] **Step 3: Verify TOML parses**

Run: `python -c "import tomllib; data = tomllib.loads(open('pyproject.toml').read()); print(data['project']['authors']); print(data['project']['urls'])"`
Expected: prints the new authors list and the URLs dict; no `TomlDecodeError`.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml
git commit -m "chore(pyproject): set Unlegacy author + add project URLs for PyPI"
```

### Task 3: Repair README header and add Unlegacy attribution

**Files:**
- Modify: `README.md` (lines 1-5)

- [ ] **Step 1: Replace lines 1-5**

The current header is corrupted (line 3 is `**.**`, line 5 has the tagline jammed mid-sentence). Replace lines 1 through 5 with:

```markdown
# binho-sdk

**A Python agent SDK with Claude Code-style loop semantics on top of OpenRouter, with first-class MCP support — developed by Unlegacy.**

Build agents that *think* like Claude Code — same turn loop, same tool dispatch model, same hooks and permission surface — but pointed at any of the 300+ models OpenRouter exposes (Claude, GPT, Gemini, Llama, DeepSeek, Qwen, …). The public API is a single `async def query() -> AsyncIterator[Event]`. No frameworks, no graphs, no DSL.
```

- [ ] **Step 2: Verify**

Run: `head -5 README.md`
Expected: clean header with no stray `**.**`, no jammed tagline, includes "developed by Unlegacy."

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "docs(readme): repair corrupted header and add Unlegacy attribution"
```

### Task 4: Fix README clone URL and example URL

**Files:**
- Modify: `README.md` (line 106 example URL, line 239 clone URL — line numbers may shift after Task 3)

- [ ] **Step 1: Replace stale clone URL**

Run: `git grep -n "olin-med/binho-sdk" README.md`

For each match, replace `olin-med/binho-sdk` with `unlegacy/binho-sdk`.

- [ ] **Step 2: Replace `*.internal` example URL**

Run: `git grep -n "doc-worker.internal" README.md`

Replace `https://doc-worker.internal/mcp` with `https://example.com/mcp`.

- [ ] **Step 3: Verify**

Run: `git grep -nE "olin-med|doc-worker.internal" README.md`
Expected: no output (zero matches).

- [ ] **Step 4: Commit**

```bash
git add README.md
git commit -m "docs(readme): use canonical unlegacy/binho-sdk URL and remove .internal example"
```

### Task 5: Add Versioning section to README

**Files:**
- Modify: `README.md` (append a new section before the final `---` or at end)

- [ ] **Step 1: Locate insertion point**

Run: `grep -n "^## " README.md`
Identify the section ordering. Insert the new `## Versioning` section directly before the existing `## Development` section (Development should stay last so first-time contributors find it easily; Versioning is reference info).

- [ ] **Step 2: Insert section**

```markdown
## Versioning

This project follows [SemVer](https://semver.org/). While the version is `0.x`, the public API may change in minor releases (`0.1 → 0.2`); patch releases (`0.1.0 → 0.1.1`) contain bug fixes only and remain API-compatible. Pin `binho-sdk>=0.1,<0.2` if you want patch updates without surprise. The version will move to `1.0.0` once the public surface is considered stable.

---
```

- [ ] **Step 3: Verify**

Run: `grep -n "^## Versioning" README.md`
Expected: one match.

- [ ] **Step 4: Commit**

```bash
git add README.md
git commit -m "docs(readme): document SemVer versioning policy"
```

### Task 6: Smoke-build the package locally

**Files:** none modified — verification only

- [ ] **Step 1: Clean build**

Run: `rm -rf dist/ && uv build`
Expected: produces `dist/binho_sdk-0.1.0-py3-none-any.whl` and `dist/binho_sdk-0.1.0.tar.gz`. No warnings about missing license / authors.

- [ ] **Step 2: Inspect wheel metadata**

Run: `unzip -p dist/binho_sdk-0.1.0-py3-none-any.whl '*METADATA' | head -40`
Expected: `Author-email` shows `Unlegacy, Inc. <zolin@unlegacy.ai>`; `Project-URL: Homepage, https://github.com/unlegacy/binho-sdk` (and Repository, Issues) present; `License: MIT` or License-Expression present.

- [ ] **Step 3: Smoke-install in a throwaway venv**

```bash
python -m venv /tmp/binho-test-venv
/tmp/binho-test-venv/bin/pip install dist/binho_sdk-0.1.0-py3-none-any.whl
/tmp/binho-test-venv/bin/python -c "from binho_sdk import query, Options; print('import OK')"
rm -rf /tmp/binho-test-venv
```
Expected: prints `import OK`. No errors.

- [ ] **Step 4: No commit — `dist/` is untracked**

Confirm `dist/` is in `.gitignore`. If not, add it:

```bash
grep -q "^dist/" .gitignore || echo "dist/" >> .gitignore
git diff --quiet .gitignore || (git add .gitignore && git commit -m "chore: ignore dist/ build output")
```

---

## Chunk 2: Release Workflow

### Task 7: Create `.github/workflows/release.yml`

**Files:**
- Create: `.github/workflows/release.yml`

- [ ] **Step 1: Write the workflow file**

```yaml
name: Release to PyPI

on:
  push:
    tags:
      - 'v*'

jobs:
  build:
    name: Build distributions
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v3

      - name: Set up Python
        run: uv python install 3.11

      - name: Build sdist and wheel
        run: uv build

      - name: Upload distributions
        uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/

  publish:
    name: Publish to PyPI
    needs: build
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
      contents: read
    steps:
      - name: Download distributions
        uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/

      - name: Publish via Trusted Publishing
        uses: pypa/gh-action-pypi-publish@release/v1
```

- [ ] **Step 2: Lint the YAML syntax**

Run: `python -c "import yaml; yaml.safe_load(open('.github/workflows/release.yml'))"`
Expected: no exception.

- [ ] **Step 3: Commit**

```bash
git add .github/workflows/release.yml
git commit -m "ci(release): add tag-triggered PyPI publish via OIDC trusted publishing"
```

---

## Chunk 3: PyPI-Side Setup + First Release

### Task 8: Create the GitHub Environment named `pypi`

**Files:** none — manual GitHub UI step

- [ ] **Step 1: Create environment**

Browser → `https://github.com/unlegacy/binho-sdk/settings/environments` → "New environment" → name `pypi` → Configure environment.

Leave all options at defaults:
- No required reviewers (turn on later if you want a manual approval gate)
- No deployment branches restriction
- No environment secrets (this is what makes it tokenless)

- [ ] **Step 2: Verify**

Run: `gh api repos/unlegacy/binho-sdk/environments | python -c "import sys, json; envs=json.load(sys.stdin); print([e['name'] for e in envs.get('environments', [])])"`
Expected: list contains `'pypi'`.

### Task 9: Register Pending Trusted Publisher on PyPI

**Files:** none — manual PyPI UI step

- [ ] **Step 1: Add pending publisher**

Browser → `https://pypi.org/manage/account/publishing/` (log in) → "Add a new pending publisher" → "GitHub" tab → fill:

| Field | Value |
|---|---|
| PyPI Project Name | `binho-sdk` |
| Owner | `unlegacy` |
| Repository name | `binho-sdk` |
| Workflow name | `release.yml` |
| Environment name | `pypi` |

Submit.

- [ ] **Step 2: Verify**

Same page → "Pending publishers" list should show `binho-sdk` with the four fields above.

### Task 10: Push tag `v0.1.0` and verify publish

**Files:** none modified — release operation only

- [ ] **Step 1: Confirm clean working tree on `main`**

Run: `git status && git rev-parse --abbrev-ref HEAD`
Expected: `nothing to commit, working tree clean` and branch `main`. If you've been working in a worktree, merge to `main` first per `superpowers:finishing-a-development-branch`.

- [ ] **Step 2: Confirm version in `pyproject.toml`**

Run: `grep "^version" pyproject.toml`
Expected: `version = "0.1.0"`.

- [ ] **Step 3: Tag and push**

```bash
git tag v0.1.0
git push origin v0.1.0
```

- [ ] **Step 4: Watch the workflow**

Run: `gh run watch` (or `gh run list --workflow=release.yml`)
Expected: `build` job succeeds; `publish` job succeeds. Total runtime ~1-2 min.

If `publish` fails with `invalid-publisher`: pending publisher fields don't match the workflow run claims. Re-check Owner / Repo / workflow filename / environment name — these must match EXACTLY.

- [ ] **Step 5: Verify on PyPI**

Run: `curl -s https://pypi.org/pypi/binho-sdk/json | python -c "import sys, json; d=json.load(sys.stdin); print(d['info']['version'], d['info']['author_email']); print(d['info']['project_urls'])"`
Expected: prints `0.1.0 Unlegacy, Inc. <zolin@unlegacy.ai>` and the project URLs dict.

- [ ] **Step 6: Smoke-install from PyPI**

```bash
python -m venv /tmp/binho-pypi-test
/tmp/binho-pypi-test/bin/pip install binho-sdk
/tmp/binho-pypi-test/bin/python -c "from binho_sdk import query; print('PyPI install OK')"
rm -rf /tmp/binho-pypi-test
```
Expected: prints `PyPI install OK`.

- [ ] **Step 7: Create GitHub Release (optional but recommended)**

```bash
gh release create v0.1.0 --title "v0.1.0 — initial PyPI release" --generate-notes
```

---

## Acceptance (final check)

- [ ] `pip install binho-sdk` from a clean venv installs `0.1.0` and `from binho_sdk import query` succeeds.
- [ ] PyPI project page shows project name `binho-sdk`, MIT license, Homepage/Repository/Issues links to `unlegacy/binho-sdk`, author `Unlegacy, Inc.` with email `zolin@unlegacy.ai`.
- [ ] `gh secret list -R unlegacy/binho-sdk` shows NO `PYPI_API_TOKEN` (tokenless).
- [ ] README header renders cleanly with the new tagline; no `olin-med/binho-sdk` or `*.internal` strings remain.
- [ ] Future releases require only: bump version → commit → `git tag vX.Y.Z && git push --tags`.

## Notes for the Implementer

- Tasks 1-7 are pure code/config edits and are safe to run in a worktree.
- Tasks 8-10 are intentionally **manual user actions** — do not attempt to automate browser-based PyPI/GitHub UI work. The plan executor should pause and explicitly hand control back to the user for these tasks, then resume verification (`gh api`, `curl pypi.org`) once the user confirms.
- If `uv build` in Task 6 fails with "license expression vs license file" deprecation warnings on hatchling, that's informational — `license = { file = "LICENSE" }` is still valid in PEP 621. Do not change to `license-expression` as part of this plan; that's a separate cleanup.
- If the publish job fails because the Pending Publisher hasn't been created yet, re-run the `publish` job (do not re-tag) once Task 9 is complete.
