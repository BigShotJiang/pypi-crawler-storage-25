"""Git worktree lifecycle management."""

import asyncio
import logging
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


async def _run_git(
    *args: str, cwd: Path | None = None
) -> tuple[int, str, str]:
    """Run a git command and return (returncode, stdout, stderr)."""
    proc = await asyncio.create_subprocess_exec(
        "git",
        *args,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()
    return proc.returncode, stdout.decode().strip(), stderr.decode().strip()


async def create_worktree(
    repo_path: Path,
    workspace_root: Path,
    issue_identifier: str,
    branch_prefix: str,
) -> Path:
    """Create a git worktree for an issue.

    Returns the path to the created worktree.
    """
    workspace_root.mkdir(parents=True, exist_ok=True)
    worktree_path = workspace_root / issue_identifier
    branch_name = f"{branch_prefix}/{issue_identifier}" if branch_prefix else issue_identifier

    if worktree_path.exists():
        logger.info(f"Worktree already exists: {worktree_path}")
        await _update_worktree(repo_path, worktree_path)
        return worktree_path

    # Fetch latest from origin
    returncode, _, stderr = await _run_git("fetch", "origin", cwd=repo_path)
    if returncode != 0:
        logger.warning(f"git fetch failed: {stderr}")

    # Try creating worktree with a new branch from origin/main
    returncode, stdout, stderr = await _run_git(
        "worktree",
        "add",
        str(worktree_path),
        "-b",
        branch_name,
        "origin/main",
        cwd=repo_path,
    )
    if returncode != 0 and "already exists" in stderr:
        # Branch exists from a previous run — reuse it
        returncode, stdout, stderr = await _run_git(
            "worktree",
            "add",
            str(worktree_path),
            branch_name,
            cwd=repo_path,
        )
    if returncode != 0:
        raise WorkspaceError(
            f"Failed to create worktree for {issue_identifier}: {stderr}"
        )

    logger.info(f"Created worktree: {worktree_path} (branch: {branch_name})")
    return worktree_path


async def remove_worktree(
    repo_path: Path,
    workspace_root: Path,
    issue_identifier: str,
) -> None:
    """Remove a git worktree for an issue."""
    worktree_path = workspace_root / issue_identifier

    if not worktree_path.exists():
        logger.debug(f"Worktree already gone: {worktree_path}")
        return

    returncode, _, stderr = await _run_git(
        "worktree", "remove", str(worktree_path), "--force", cwd=repo_path
    )
    if returncode != 0:
        logger.warning(f"Failed to remove worktree {worktree_path}: {stderr}")
    else:
        logger.info(f"Removed worktree: {worktree_path}")

    # Clean up Claude Code's project metadata cache for this worktree.
    _remove_claude_project_cache(worktree_path)


def worktree_exists(workspace_root: Path, issue_identifier: str) -> bool:
    """Check if a worktree exists for the given issue."""
    return (workspace_root / issue_identifier).exists()


def _remove_claude_project_cache(worktree_path: Path) -> None:
    """Remove Claude Code's ~/.claude/projects/ metadata dir for a worktree."""
    # Claude Code uses the absolute path with slashes replaced by dashes as the dir name.
    cache_name = str(worktree_path).replace("/", "-")
    cache_dir = Path.home() / ".claude" / "projects" / cache_name
    if cache_dir.exists():
        try:
            shutil.rmtree(cache_dir)
            logger.info(f"Removed Claude project cache: {cache_dir}")
        except Exception:
            logger.debug(f"Failed to remove Claude project cache: {cache_dir}", exc_info=True)


async def _update_worktree(repo_path: Path, worktree_path: Path) -> None:
    """Pull latest origin/main into an existing worktree."""
    returncode, _, stderr = await _run_git("fetch", "origin", cwd=repo_path)
    if returncode != 0:
        logger.warning(f"git fetch failed: {stderr}")
        return

    returncode, _, stderr = await _run_git(
        "rebase", "origin/main", cwd=worktree_path,
    )
    if returncode != 0:
        logger.warning(f"Rebase failed in {worktree_path}, aborting: {stderr}")
        await _run_git("rebase", "--abort", cwd=worktree_path)


class WorkspaceError(Exception):
    pass
