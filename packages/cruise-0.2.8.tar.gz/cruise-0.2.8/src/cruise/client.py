"""WebSocket client for connecting the daemon to the Cruise cloud service."""

import asyncio
import json
import logging
import platform
import subprocess
from dataclasses import asdict
from pathlib import Path
from typing import AsyncIterator

import websockets
from websockets.asyncio.client import ClientConnection

from cruise.protocol import (
    AgentCompletedMessage,
    AgentFailedMessage,
    AgentStartedMessage,
    CancelMessage,
    CloudMessage,
    DaemonConnectedMessage,
    DispatchMessage,
    HeartbeatMessage,
    InjectCommentMessage,
    ProgressMessage,
    QuestionMessage,
    QuestionReplyMessage,
)

logger = logging.getLogger(__name__)

_HEARTBEAT_INTERVAL = 30
_RECONNECT_BASE = 1
_RECONNECT_MAX = 60


class CloudClient:
    """Maintains a persistent WebSocket connection to the Cruise cloud service.

    Handles auto-reconnect with exponential backoff, heartbeats, and
    message send/receive.
    """

    def __init__(self, server_url: str, auth_token: str, repo_path: str):
        self.server_url = server_url
        self.auth_token = auth_token
        self.repo_path = repo_path
        self._ws: ClientConnection | None = None
        self._stop = asyncio.Event()
        self._send_queue: asyncio.Queue[dict] = asyncio.Queue()

    async def connect(self) -> AsyncIterator[CloudMessage]:
        """Connect to the cloud and yield incoming messages.

        Automatically reconnects on disconnect with exponential backoff.
        Yields DispatchMessage, CancelMessage, InjectCommentMessage, or
        QuestionReplyMessage objects.
        """
        backoff = _RECONNECT_BASE

        while not self._stop.is_set():
            try:
                url = f"{self.server_url}?token={self.auth_token}"
                async with websockets.connect(url) as ws:
                    self._ws = ws
                    backoff = _RECONNECT_BASE
                    logger.info(f"Connected to {self.server_url}")

                    await self._send_connected_info()

                    heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                    sender_task = asyncio.create_task(self._sender_loop())

                    try:
                        async for raw in ws:
                            msg = self._parse_message(raw)
                            if msg:
                                yield msg
                    finally:
                        heartbeat_task.cancel()
                        sender_task.cancel()
                        self._ws = None

            except (websockets.ConnectionClosed, OSError) as e:
                if self._stop.is_set():
                    break
                logger.warning(f"Disconnected: {e}. Reconnecting in {backoff}s...")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, _RECONNECT_MAX)

    async def send(self, message) -> None:
        """Queue a message to send to the cloud."""
        await self._send_queue.put(asdict(message))

    def stop(self) -> None:
        """Signal the client to disconnect and stop reconnecting."""
        self._stop.set()
        if self._ws:
            asyncio.create_task(self._ws.close())

    async def send_agent_started(self, issue_id: str, session_id: str) -> None:
        await self.send(AgentStartedMessage(
            issue_id=issue_id, session_id=session_id,
        ))

    async def send_progress(self, issue_id: str, last_event: str, turns_used: int) -> None:
        await self.send(ProgressMessage(
            issue_id=issue_id, last_event=last_event, turns_used=turns_used,
        ))

    async def send_agent_completed(
        self, issue_id: str, session_id: str, success: bool,
        cost_usd: float, num_turns: int, duration_ms: int, hit_turn_limit: bool,
    ) -> None:
        await self.send(AgentCompletedMessage(
            issue_id=issue_id, session_id=session_id, success=success,
            cost_usd=cost_usd, num_turns=num_turns,
            duration_ms=duration_ms, hit_turn_limit=hit_turn_limit,
        ))

    async def send_agent_failed(self, issue_id: str, error: str) -> None:
        await self.send(AgentFailedMessage(issue_id=issue_id, error=error))

    async def send_question(self, issue_id: str, question: str, options: list[str]) -> None:
        await self.send(QuestionMessage(
            issue_id=issue_id, question=question, options=options,
        ))

    async def _send_connected_info(self) -> None:
        """Send daemon info on initial connect."""
        repo_remote = _get_git_remote(self.repo_path)
        machine = f"{platform.system()} {platform.release()} {platform.machine()}"
        await self.send(DaemonConnectedMessage(
            repo_path=self.repo_path,
            repo_remote=repo_remote,
            machine_info=machine,
        ))

    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeats to keep the connection alive."""
        while not self._stop.is_set():
            await asyncio.sleep(_HEARTBEAT_INTERVAL)
            await self.send(HeartbeatMessage())

    async def _sender_loop(self) -> None:
        """Drain the send queue and write messages to the WebSocket."""
        while not self._stop.is_set():
            msg = await self._send_queue.get()
            if self._ws:
                try:
                    await self._ws.send(json.dumps(msg))
                except websockets.ConnectionClosed:
                    break

    def _parse_message(self, raw: str | bytes) -> CloudMessage | None:
        """Parse a raw WebSocket message into a typed CloudMessage."""
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning(f"Invalid JSON from cloud: {raw[:200]}")
            return None

        msg_type = data.get("type")
        if msg_type == "dispatch":
            return _dict_to_dispatch(data)
        elif msg_type == "cancel":
            return CancelMessage(issue_id=data.get("issue_id", ""), reason=data.get("reason", ""))
        elif msg_type == "comment":
            return InjectCommentMessage(issue_id=data.get("issue_id", ""), body=data.get("body", ""))
        elif msg_type == "question_reply":
            return QuestionReplyMessage(issue_id=data.get("issue_id", ""), reply=data.get("reply", ""))
        else:
            logger.warning(f"Unknown message type from cloud: {msg_type}")
            return None


def _dict_to_dispatch(data: dict) -> DispatchMessage:
    """Convert a raw dict to a DispatchMessage with nested dataclasses."""
    from cruise.protocol import CommentPayload, IssuePayload

    issue_data = data.get("issue", {})
    issue = IssuePayload(
        id=issue_data.get("id", ""),
        identifier=issue_data.get("identifier", ""),
        title=issue_data.get("title", ""),
        state=issue_data.get("state", ""),
        description=issue_data.get("description", ""),
        url=issue_data.get("url", ""),
        labels=issue_data.get("labels", []),
        branch_name=issue_data.get("branch_name", ""),
    )
    comments = [
        CommentPayload(body=c.get("body", ""), created_at=c.get("created_at", ""))
        for c in data.get("comments", [])
    ]
    return DispatchMessage(
        issue=issue,
        comments=comments,
        images=data.get("images", []),
        resume_session_id=data.get("resume_session_id"),
        linear_access_token=data.get("linear_access_token", ""),
    )


def _get_git_remote(repo_path: str) -> str:
    """Get the origin remote URL for a repo path."""
    try:
        result = subprocess.run(
            ["git", "-C", repo_path, "remote", "get-url", "origin"],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else ""
    except Exception:
        return ""
