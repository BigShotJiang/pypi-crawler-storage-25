"""CLI entry point for Cruise."""

import argparse
import asyncio
import json
import logging
import signal
import subprocess
import sys
from importlib.metadata import version
from pathlib import Path

logger = logging.getLogger(__name__)

_CONFIG_DIR = Path.home() / ".cruise"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_LOG_DIR = _CONFIG_DIR / "logs"
_DEFAULT_SERVER = "wss://cruise.sh/ws"


def configure_logging(verbose: bool, log_file: str | None) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    logging.basicConfig(level=level, format=fmt, datefmt=datefmt)
    logging.getLogger().setLevel(level)

    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        file_handler.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
        logging.getLogger().addHandler(file_handler)

    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("websockets").setLevel(logging.WARNING)


def _load_daemon_config() -> dict:
    """Load daemon config from ~/.cruise/config.json."""
    if not _CONFIG_FILE.exists():
        print(f"No config found at {_CONFIG_FILE}")
        print("Run 'cruise login <setup-token>' first.")
        sys.exit(1)
    return json.loads(_CONFIG_FILE.read_text())


def _save_daemon_config(config: dict) -> None:
    """Save daemon config to ~/.cruise/config.json."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(config, indent=2))


# -- Subcommands --


def _cmd_daemon(args) -> None:
    """Main daemon loop: connect to cloud, process dispatch commands."""
    config = _load_daemon_config()
    configure_logging(verbose=args.verbose, log_file=str(_LOG_DIR / "daemon.log"))

    from cruise.client import CloudClient
    from cruise.worker import Worker

    client = CloudClient(
        server_url=config.get("server_url", _DEFAULT_SERVER),
        auth_token=config["auth_token"],
        repo_path=config["repo_path"],
    )
    worker = Worker(
        client=client,
        repo_path=config["repo_path"],
        workspace_root=config.get("workspace_root", str(Path.home() / "cruise-workspaces")),
        branch_prefix=config.get("branch_prefix", ""),
        permission_mode=config.get("permission_mode", "bypassPermissions"),
        model=config.get("model"),
        max_turns=config.get("max_turns", 100),
    )

    async def run():
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, lambda: (client.stop(),))

        async for message in client.connect():
            await worker.handle_message(message)

        await worker.cancel_all()

    asyncio.run(run())


def _cmd_login(args) -> None:
    """Exchange a setup token for a daemon auth token."""
    import httpx

    token = args.setup_token
    # The setup token encodes the server URL as a prefix, or we use default
    server_base = args.server or "https://cruise.sh"

    try:
        resp = httpx.get(
            f"{server_base}/api/setup-token/{token}",
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"Login failed: {e}")
        sys.exit(1)

    config = _load_daemon_config() if _CONFIG_FILE.exists() else {}
    config["auth_token"] = data["auth_token"]
    config["server_url"] = data.get("server_ws_url", _DEFAULT_SERVER)
    config.update({k: v for k, v in data.items() if k not in ("auth_token", "server_ws_url")})
    _save_daemon_config(config)
    print(f"Logged in. Config saved to {_CONFIG_FILE}")


def _prompt_tty(prompt: str) -> str:
    """Read input from /dev/tty so prompts work even when stdin is piped."""
    try:
        with open("/dev/tty") as tty:
            sys.stdout.write(prompt)
            sys.stdout.flush()
            return tty.readline().strip()
    except OSError:
        return input(prompt).strip()


def _is_git_repo(path: str) -> tuple[bool, str]:
    """Check if path is a git repo. Returns (is_repo, remote_url)."""
    result = subprocess.run(
        ["git", "-C", path, "remote", "get-url", "origin"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return True, result.stdout.strip()
    return False, ""


def _ask_repo_path() -> str:
    """Prompt for a repo path. Accepts absolute or ~/relative paths."""
    home = str(Path.home())
    raw = _prompt_tty(f"Full path to repo (e.g. {home}/repos/myproject): ").strip()
    if not raw:
        print("No path provided.")
        sys.exit(1)
    return str(Path(raw).expanduser().resolve())


def _cmd_setup(args) -> None:
    """Configure the local repo path and validate it."""
    config = _load_daemon_config() if _CONFIG_FILE.exists() else {}

    if args.repo_path:
        repo_path = str(Path(args.repo_path).expanduser().resolve())
    else:
        cwd = str(Path.cwd())
        is_repo, remote = _is_git_repo(cwd)

        if is_repo:
            choice = _prompt_tty(
                f"Use current directory?\n  {cwd}\n  ({remote})\n[Y/n]: "
            )
            if choice.lower() not in ("", "y", "yes"):
                repo_path = _ask_repo_path()
            else:
                repo_path = cwd
        else:
            repo_path = _ask_repo_path()

    if not Path(repo_path).is_dir():
        print(f"Not a directory: {repo_path}")
        sys.exit(1)

    is_repo, remote = _is_git_repo(repo_path)
    if is_repo:
        print(f"Git remote: {remote}")
    else:
        print("Warning: could not read git remote. Is this a git repo?")

    config["repo_path"] = repo_path
    config["workspace_root"] = args.workspace_root or str(Path.home() / "cruise-workspaces")

    if args.branch_prefix is not None:
        config["branch_prefix"] = args.branch_prefix

    _save_daemon_config(config)
    print(f"Config saved to {_CONFIG_FILE}")


def _cmd_install(args) -> None:
    """Install the daemon as a background service."""
    from cruise.installer import install
    install()


def _cmd_uninstall(args) -> None:
    """Uninstall the daemon background service."""
    from cruise.installer import uninstall
    uninstall()


def _cmd_start(args) -> None:
    """Start the daemon service."""
    from cruise.installer import start
    start()


def _cmd_stop(args) -> None:
    """Stop the daemon service."""
    from cruise.installer import stop
    stop()


def _cmd_status(args) -> None:
    """Show daemon status."""
    from cruise.installer import status
    info = status()
    state = "running" if info["running"] else "stopped"
    print(f"Cruise daemon: {state} ({info['platform']})")

    if _CONFIG_FILE.exists():
        config = json.loads(_CONFIG_FILE.read_text())
        print(f"Repo: {config.get('repo_path', 'not set')}")
        print(f"Server: {config.get('server_url', _DEFAULT_SERVER)}")


def _cmd_logs(args) -> None:
    """Tail daemon logs."""
    log_file = _LOG_DIR / "daemon.log"
    if not log_file.exists():
        print(f"No log file at {log_file}")
        sys.exit(1)
    import subprocess
    subprocess.run(["tail", "-f", str(log_file)])


def _cmd_local(args) -> None:
    """Run in local mode (original polling loop, no cloud connection)."""
    from cruise.config import load_config
    from cruise.poller import Poller

    configure_logging(verbose=args.verbose, log_file=args.log_file)

    try:
        config = load_config(args.config)
    except (FileNotFoundError, ValueError, KeyError) as e:
        logging.error(f"Failed to load config: {e}")
        sys.exit(1)

    async def run(use_status: bool):
        poller = Poller(config)
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(
                sig,
                lambda s=sig: (
                    logging.info(f"Received {signal.Signals(s).name}, shutting down..."),
                    poller.stop(),
                ),
            )
        if use_status:
            from cruise.status import StatusDisplay
            logging.getLogger().handlers.clear()
            logging.getLogger().addHandler(logging.NullHandler())
            with StatusDisplay() as display:
                await poller.run(status=display)
        elif args.dry_run:
            await poller.poll_once_dry()
        else:
            await poller.run()

    asyncio.run(run(args.status))


# -- Main --


def main():
    parser = argparse.ArgumentParser(
        prog="cruise",
        description="Cruise: dispatch Claude Code agents from Linear tickets",
    )
    parser.add_argument(
        "--version", action="version",
        version=f"cruise {version('cruise')}",
    )
    subparsers = parser.add_subparsers(dest="command")

    # cruise daemon
    p_daemon = subparsers.add_parser("daemon", help="Run the daemon (used by the background service)")
    p_daemon.add_argument("-v", "--verbose", action="store_true")
    p_daemon.set_defaults(func=_cmd_daemon)

    # cruise login <setup-token>
    p_login = subparsers.add_parser("login", help="Authenticate with a setup token from the web UI")
    p_login.add_argument("setup_token", help="One-time setup token from cruise.sh")
    p_login.add_argument("--server", default=None, help="Cloud server base URL")
    p_login.set_defaults(func=_cmd_login)

    # cruise setup
    p_setup = subparsers.add_parser("setup", help="Configure the local repo path")
    p_setup.add_argument("--repo-path", default=None, help="Path to git repo")
    p_setup.add_argument("--workspace-root", default=None, help="Worktree directory")
    p_setup.add_argument("--branch-prefix", default=None, help="Git branch prefix")
    p_setup.set_defaults(func=_cmd_setup)

    # cruise install / uninstall / start / stop / status / logs
    subparsers.add_parser("install", help="Install as a background service").set_defaults(func=_cmd_install)
    subparsers.add_parser("uninstall", help="Remove the background service").set_defaults(func=_cmd_uninstall)
    subparsers.add_parser("start", help="Start the background service").set_defaults(func=_cmd_start)
    subparsers.add_parser("stop", help="Stop the background service").set_defaults(func=_cmd_stop)
    p_status = subparsers.add_parser("status", help="Show daemon status")
    p_status.set_defaults(func=_cmd_status)
    subparsers.add_parser("logs", help="Tail daemon logs").set_defaults(func=_cmd_logs)

    # cruise local --config ... (preserves the original CLI)
    p_local = subparsers.add_parser("local", help="Run in local mode (no cloud, original polling loop)")
    p_local.add_argument("--config", default="config.yaml", help="Path to config file")
    p_local.add_argument("-v", "--verbose", action="store_true")
    p_local.add_argument("--dry-run", action="store_true")
    p_local.add_argument("--status", action="store_true")
    p_local.add_argument("--log-file", default=None)
    p_local.set_defaults(func=_cmd_local)

    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
