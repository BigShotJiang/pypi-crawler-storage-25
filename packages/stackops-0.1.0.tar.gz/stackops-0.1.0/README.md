# stackops

Minimal Python package and CLI published as `stackops`.

## Install

```bash
pip install stackops
```

## Use

```bash
stackops
stackops alex
python -m stackops
```

```python
from stackops import hello

print(hello("alex"))
```

## Release

```bash
uv build
UV_PUBLISH_TOKEN=pypi-... uv publish
```
