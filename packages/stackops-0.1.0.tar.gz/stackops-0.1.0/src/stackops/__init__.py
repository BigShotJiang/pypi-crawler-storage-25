"""Minimal public interface for the stackops package."""

__version__ = "0.1.0"


def hello(name: str = "world") -> str:
    """Return a friendly greeting from stackops."""
    return f"Hello, {name}. This is stackops."
