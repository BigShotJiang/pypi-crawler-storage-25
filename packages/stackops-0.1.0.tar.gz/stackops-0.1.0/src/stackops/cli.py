"""Command-line interface for stackops."""

from __future__ import annotations

import argparse

from . import __version__, hello


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Minimal CLI for the stackops package."
    )
    parser.add_argument("name", nargs="?", default="world", help="Optional name to greet.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    print(hello(args.name))
    return 0
