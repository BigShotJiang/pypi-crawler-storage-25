# Motus CLI Licensing (Quick FAQ)

Motus CLI is licensed under the Apache License 2.0.

## What Apache 2.0 allows

- Commercial and internal use
- Modification and redistribution
- Sublicensing and private forks
- Use in hosted products and services

## What you must do

- Keep the Apache 2.0 license text with redistributions
- Mark modified files when you distribute modified versions
- Retain required copyright, patent, and attribution notices
- Preserve NOTICE content if a NOTICE file is included in a distribution

## Trademarks

Apache 2.0 does not grant trademark rights. See `TRADEMARKS.md` for Motus
name and branding rules.

## Protocol Specifications

Some protocol specifications and schemas may be released under MIT License to
encourage ecosystem adoption and standardization. When published, they will
live in a clearly marked `specs/` directory (or an explicitly referenced
location in this repository).

## Third-Party Dependencies

Motus includes third-party dependencies under their respective licenses.
See NOTICE for details.

## Questions?

Open an issue at https://github.com/motus-os/motus/issues
