# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Parser registration for release evidence and release-workflow commands."""

from __future__ import annotations

import argparse


def register_release_parsers(subparsers: argparse._SubParsersAction) -> argparse.ArgumentParser:
    release_parser = subparsers.add_parser(
        "release",
        help="Release evidence gates",
    )
    release_subparsers = release_parser.add_subparsers(dest="release_command", help="Release commands")

    check_parser = release_subparsers.add_parser(
        "check",
        help="Run release evidence checks (fail-closed)",
    )
    check_parser.add_argument("--json", action="store_true", help="Emit JSON output")

    bundle_parser = release_subparsers.add_parser(
        "bundle",
        help="Generate release evidence bundle JSON",
    )
    bundle_parser.add_argument(
        "--output",
        default="packages/cli/artifacts/quality/release-evidence.json",
        help="Output path for release evidence bundle",
    )
    bundle_parser.add_argument("--json", action="store_true", help="Emit JSON output")

    scaffold_parser = release_subparsers.add_parser(
        "scaffold",
        help="Generate a reference release workflow scaffold",
    )
    scaffold_parser.add_argument(
        "--release-id",
        required=True,
        help="Release identifier slug for the scaffolded workflow (letters, digits, '.', '_' or '-')",
    )
    scaffold_parser.add_argument(
        "--output-dir",
        default=".motus/releases",
        help="Output root for the release workflow workspace",
    )
    scaffold_parser.add_argument(
        "--force",
        action="store_true",
        help="Refresh generated outputs in an existing non-finalized release workspace",
    )
    scaffold_parser.add_argument("--json", action="store_true", help="Emit JSON output")

    sync_parser = release_subparsers.add_parser(
        "sync",
        help="Regenerate derived release workflow artifacts from release-source.json",
    )
    sync_parser.add_argument(
        "--release-id",
        required=True,
        help="Release identifier slug for the existing workflow workspace",
    )
    sync_parser.add_argument(
        "--output-dir",
        default=".motus/releases",
        help="Output root for the release workflow workspace",
    )
    sync_parser.add_argument("--json", action="store_true", help="Emit JSON output")

    validate_parser = release_subparsers.add_parser(
        "validate",
        help="Validate the release workflow workspace without writing files",
    )
    validate_parser.add_argument(
        "--release-id",
        required=True,
        help="Release identifier slug for the existing workflow workspace",
    )
    validate_parser.add_argument(
        "--output-dir",
        default=".motus/releases",
        help="Output root for the release workflow workspace",
    )
    validate_parser.add_argument(
        "--final",
        action="store_true",
        help="Require strict final receipt validation in addition to draft workspace checks",
    )
    validate_parser.add_argument("--json", action="store_true", help="Emit JSON output")

    finalize_parser = release_subparsers.add_parser(
        "finalize",
        help="Emit one strict immutable final receipt from release-source closeout",
    )
    finalize_parser.add_argument(
        "--release-id",
        required=True,
        help="Release identifier slug for the existing workflow workspace",
    )
    finalize_parser.add_argument(
        "--output-dir",
        default=".motus/releases",
        help="Output root for the release workflow workspace",
    )
    finalize_parser.add_argument("--json", action="store_true", help="Emit JSON output")

    return release_parser
