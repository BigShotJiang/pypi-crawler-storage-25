# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Release evidence CLI commands."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from rich.console import Console

from motus.cli.exit_codes import EXIT_ERROR, EXIT_SUCCESS
from motus.observability.audit import AuditEvent, AuditLogger
from motus.release.evidence_gate import run_release_evidence, write_release_bundle
from motus.release.scaffold import (
    finalize_release_workflow,
    scaffold_release_workflow,
    sync_release_workflow,
    validate_release_workflow,
)

console = Console()
DEFAULT_RELEASE_BUNDLE_PATH = Path("packages/cli/artifacts/quality/release-evidence.json")
DEFAULT_RELEASE_WORKFLOW_ROOT = Path(".motus/releases")


def _repo_root() -> Path:
    cwd = Path.cwd()
    if (cwd / "packages/cli").exists():
        return cwd
    if (cwd / "pyproject.toml").exists() and cwd.name == "cli":
        return cwd.parent.parent
    return cwd


def _emit_audit(action: str, payload: dict[str, Any]) -> None:
    try:
        AuditLogger().emit(
            AuditEvent(
                event_type="release_evidence",
                actor="user",
                action=action,
                resource_type="release",
                resource_id=None,
                context=payload,
            )
        )
    except Exception:
        pass


def release_check_command(args: Any) -> int:
    repo_root = _repo_root()
    result = run_release_evidence(repo_root)
    payload = result.to_dict()
    _emit_audit("check", payload)

    if getattr(args, "json", False):
        console.print_json(json.dumps(payload, sort_keys=True))
    else:
        for check in payload["checks"]:
            status = "PASS" if check["passed"] else "FAIL"
            console.print(f"[{status}] {check['name']}: {check['message']}")
        console.print(f"\nOverall: {'PASS' if payload['passed'] else 'FAIL'}")
        if payload["blocked"]:
            console.print(f"Blocked by: {payload['blocked']}")

    return EXIT_SUCCESS if payload["passed"] else EXIT_ERROR


def release_bundle_command(args: Any) -> int:
    repo_root = _repo_root()
    result = run_release_evidence(repo_root)
    payload = result.to_dict()

    output_path = Path(getattr(args, "output", str(DEFAULT_RELEASE_BUNDLE_PATH))).expanduser()
    if not output_path.is_absolute():
        output_path = repo_root / output_path
    write_release_bundle(output_path, result)
    payload["bundle_path"] = str(output_path)

    _emit_audit("bundle", payload)

    if getattr(args, "json", False):
        console.print_json(json.dumps(payload, sort_keys=True))
    else:
        console.print(f"Release evidence bundle: {output_path}", markup=False)
        console.print(f"Overall: {'PASS' if payload['passed'] else 'FAIL'}")

    return EXIT_SUCCESS if payload["passed"] else EXIT_ERROR


def release_scaffold_command(args: Any) -> int:
    repo_root = _repo_root()
    release_id = str(getattr(args, "release_id"))
    output_root = Path(getattr(args, "output_dir", str(DEFAULT_RELEASE_WORKFLOW_ROOT))).expanduser()
    if not output_root.is_absolute():
        output_root = repo_root / output_root

    try:
        payload = scaffold_release_workflow(
            release_id=release_id,
            output_root=output_root,
            force=bool(getattr(args, "force", False)),
        )
    except ValueError as exc:
        console.print(str(exc), style="red", markup=False)
        return EXIT_ERROR
    _emit_audit("scaffold", payload)

    if getattr(args, "json", False):
        console.print_json(json.dumps(payload, sort_keys=True))
    else:
        console.print(f"Release workflow scaffold: {payload['output_dir']}", markup=False)
        console.print(f"Stages: {payload['stage_count']}")

    return EXIT_SUCCESS


def release_sync_command(args: Any) -> int:
    repo_root = _repo_root()
    release_id = str(getattr(args, "release_id"))
    output_root = Path(getattr(args, "output_dir", str(DEFAULT_RELEASE_WORKFLOW_ROOT))).expanduser()
    if not output_root.is_absolute():
        output_root = repo_root / output_root

    try:
        payload = sync_release_workflow(release_id=release_id, output_root=output_root)
    except ValueError as exc:
        console.print(str(exc), style="red", markup=False)
        return EXIT_ERROR
    _emit_audit("sync", payload)

    if getattr(args, "json", False):
        console.print_json(json.dumps(payload, sort_keys=True))
    else:
        console.print(f"Release workflow synchronized: {payload['output_dir']}", markup=False)
        console.print(f"Stages: {payload['stage_count']}")

    return EXIT_SUCCESS


def release_validate_command(args: Any) -> int:
    repo_root = _repo_root()
    release_id = str(getattr(args, "release_id"))
    output_root = Path(getattr(args, "output_dir", str(DEFAULT_RELEASE_WORKFLOW_ROOT))).expanduser()
    if not output_root.is_absolute():
        output_root = repo_root / output_root

    try:
        payload = validate_release_workflow(
            release_id=release_id,
            output_root=output_root,
            final=bool(getattr(args, "final", False)),
        )
    except ValueError as exc:
        console.print(str(exc), style="red", markup=False)
        return EXIT_ERROR
    _emit_audit("validate", payload)

    if getattr(args, "json", False):
        console.print_json(json.dumps(payload, sort_keys=True))
    else:
        console.print(f"Release workflow valid: {payload['output_dir']}", markup=False)
        console.print(f"Stages validated: {payload['schema_validation']['validated_stage_packets']}")
        if payload.get("final_receipt_path"):
            console.print(f"Final receipt: {payload['final_receipt_path']}", markup=False)

    return EXIT_SUCCESS


def release_finalize_command(args: Any) -> int:
    repo_root = _repo_root()
    release_id = str(getattr(args, "release_id"))
    output_root = Path(getattr(args, "output_dir", str(DEFAULT_RELEASE_WORKFLOW_ROOT))).expanduser()
    if not output_root.is_absolute():
        output_root = repo_root / output_root

    try:
        payload = finalize_release_workflow(release_id=release_id, output_root=output_root)
    except ValueError as exc:
        console.print(str(exc), style="red", markup=False)
        return EXIT_ERROR
    _emit_audit("finalize", payload)

    if getattr(args, "json", False):
        console.print_json(json.dumps(payload, sort_keys=True))
    else:
        console.print(f"Final receipt: {payload['final_receipt_path']}", markup=False)
        console.print(f"Receipt id: {payload['receipt_id']}", markup=False)

    return EXIT_SUCCESS
