# Copyright (c) 2024-2025 Veritas Collaborative, LLC
# SPDX-License-Identifier: Apache-2.0

"""Release workflow lifecycle for the `.13` release packet compiler."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import jsonschema

WORKFLOW_FAMILY = "release-reference-pilot-v1"
SCHEMA_VERSION = "0.3.13"
GENERATOR_VERSION = SCHEMA_VERSION
SOURCE_SCHEMA_REF = "packages/cli/docs/standards/schemas/release-source.json"
PACKET_SCHEMA_REF = "packages/cli/docs/standards/schemas/release-work-packet.json"
TEMPLATE_SCHEMA_REF = "packages/cli/docs/standards/schemas/release-receipt-template.json"
FINAL_RECEIPT_SCHEMA_REF = "packages/cli/docs/standards/schemas/release-work-receipt.json"
METRIC_NAMES = (
    "time_to_form_work",
    "time_to_first_usable_output",
    "time_to_final_receipt",
    "time_to_reconstruct_what_happened",
    "missing_evidence_rate",
    "stale_or_orphaned_work_rate",
    "explicit_acceptance_rate",
    "linked_next_step_rate",
)
RELEASE_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PACKAGE_ROOT / "data"
SOURCE_SCHEMA_PATH = DATA_DIR / "release-source.schema.json"
PACKET_SCHEMA_PATH = DATA_DIR / "release-work-packet.schema.json"
TEMPLATE_SCHEMA_PATH = DATA_DIR / "release-receipt-template.schema.json"
FINAL_RECEIPT_SCHEMA_PATH = DATA_DIR / "release-work-receipt.schema.json"
RELEASE_SOURCE_NAME = "release-source.json"
GENERATED_DIRNAME = "generated"
WORKFLOW_NAME = "workflow.json"
PACKETS_DIRNAME = "packets"
RECEIPT_TEMPLATE_NAME = "receipt-template.json"
METRICS_TEMPLATE_NAME = "metrics-template.json"
FINAL_RECEIPT_NAME = "final-receipt.json"


@dataclass(frozen=True)
class ReleaseStage:
    order: int
    stage_id: str
    display_name: str
    capability_class: str
    intent_template: str
    scope: tuple[str, ...]
    constraints: tuple[str, ...]
    required_evidence: tuple[str, ...]
    acceptance_criteria: tuple[str, ...]
    allowed_actions: tuple[str, ...]


STAGES: tuple[ReleaseStage, ...] = (
    ReleaseStage(
        order=1,
        stage_id="release-scoping",
        display_name="Release Scoping",
        capability_class="synthesis_planning",
        intent_template="Define the release thesis, included work, excluded work, and risks for {release_id}.",
        scope=("release thesis", "included slices", "excluded work", "risks and constraints"),
        constraints=(
            "keep the release bounded to one thesis",
            "record what is explicitly out of scope",
            "do not widen into server or orchestration work",
        ),
        required_evidence=(
            "release thesis recorded",
            "included slices recorded",
            "excluded work recorded",
            "risk notes recorded",
        ),
        acceptance_criteria=("scope is locked", "release thesis is explicit", "next stage is release-development"),
        allowed_actions=("define_scope", "record_risks", "route_next_work"),
    ),
    ReleaseStage(
        order=2,
        stage_id="release-development",
        display_name="Release Development",
        capability_class="change_execution",
        intent_template="Implement the bounded changes included in {release_id}.",
        scope=("code changes", "docs changes", "schema changes", "tests for release surface"),
        constraints=(
            "keep changes within the release scope",
            "attach evidence as work progresses",
            "link outputs to verification inputs",
        ),
        required_evidence=("code diff", "docs diff", "test additions", "implementation notes"),
        acceptance_criteria=(
            "bounded changes implemented",
            "tests added for changed release surface",
            "next stage is release-verification",
        ),
        allowed_actions=("implement_changes", "attach_evidence", "route_next_work"),
    ),
    ReleaseStage(
        order=3,
        stage_id="release-verification",
        display_name="Release Verification",
        capability_class="verification_review",
        intent_template="Verify that {release_id} passes the required checks and that evidence is complete.",
        scope=("tests", "gates", "evidence review", "smoke execution"),
        constraints=(
            "fail closed on missing evidence",
            "use explicit verification outputs",
            "record exceptions rather than hiding them",
        ),
        required_evidence=("targeted test results", "smoke execution output", "gate results", "evidence completeness notes"),
        acceptance_criteria=(
            "required checks pass or explicit exceptions exist",
            "verification evidence is attached",
            "next stage is release-approval",
        ),
        allowed_actions=("verify", "record_exception", "route_next_work"),
    ),
    ReleaseStage(
        order=4,
        stage_id="release-approval",
        display_name="Release Approval",
        capability_class="verification_review",
        intent_template="Record the approval decision for {release_id} using the verification evidence.",
        scope=("approval decision", "approval rationale", "release disposition"),
        constraints=(
            "approval must be explicit",
            "approval must cite verification evidence",
            "rejection or needs-changes must route back cleanly",
        ),
        required_evidence=("approval decision", "approval rationale", "referenced verification evidence"),
        acceptance_criteria=("decision is explicit", "route after decision is explicit", "next stage is release-publication on approval"),
        allowed_actions=("approve", "reject", "request_changes", "route_next_work"),
    ),
    ReleaseStage(
        order=5,
        stage_id="release-publication",
        display_name="Release Publication",
        capability_class="change_execution",
        intent_template="Publish or merge the approved release work for {release_id}.",
        scope=("merge or publish action", "release artifact output", "post-publication verification"),
        constraints=(
            "publish only after approval",
            "record the publication artifact or merge commit",
            "link follow-up work explicitly",
        ),
        required_evidence=("merge or publish reference", "release artifact reference", "post-publication verification note"),
        acceptance_criteria=(
            "publication action recorded",
            "release output or merge reference recorded",
            "next stage is post-release-follow-up",
        ),
        allowed_actions=("publish", "record_output", "route_next_work"),
    ),
    ReleaseStage(
        order=6,
        stage_id="post-release-follow-up",
        display_name="Post-Release Follow-Up",
        capability_class="synthesis_planning",
        intent_template="Capture what {release_id} improved, what friction appeared, and what should happen next.",
        scope=("release learnings", "follow-up work", "measured improvement"),
        constraints=(
            "capture one concrete improvement from the release",
            "capture at least one friction or exception if it occurred",
            "link next work explicitly",
        ),
        required_evidence=("measured improvement statement", "captured friction or exception note", "linked next work reference"),
        acceptance_criteria=("follow-up is receipted", "next work is linked or explicitly terminal", "release cycle is inspectable end to end"),
        allowed_actions=("record_learnings", "link_next_work", "close_release"),
    ),
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _canonical_bytes(payload: dict[str, Any], *, exclude: tuple[str, ...] = ()) -> bytes:
    def normalize(value: Any) -> Any:
        if isinstance(value, dict):
            return {
                key: normalize(child)
                for key, child in sorted(value.items())
                if key not in exclude
            }
        if isinstance(value, list):
            return [normalize(child) for child in value]
        return value

    return json.dumps(normalize(payload), separators=(",", ":"), sort_keys=True).encode("utf-8")


def _sha256(payload: dict[str, Any], *, exclude: tuple[str, ...] = ()) -> str:
    return "sha256:" + hashlib.sha256(_canonical_bytes(payload, exclude=exclude)).hexdigest()


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_schema(path: Path) -> dict[str, Any]:
    return _load_json(path)


def _validate_payload(payload: dict[str, Any], schema: dict[str, Any], *, kind: str) -> None:
    validator = jsonschema.Draft202012Validator(
        schema,
        format_checker=jsonschema.Draft202012Validator.FORMAT_CHECKER,
    )
    errors = sorted(validator.iter_errors(payload), key=lambda error: list(error.absolute_path))
    if not errors:
        return
    joined = "; ".join(error.message for error in errors)
    raise ValueError(f"{kind} failed schema validation: {joined}")


def _validate_release_id(release_id: str) -> str:
    if not release_id:
        raise ValueError(
            "invalid release_id: expected a non-empty slug using only letters, digits, '.', '_' or '-'"
        )
    candidate = release_id.strip()
    if candidate != release_id:
        raise ValueError(
            "invalid release_id: expected a canonical slug without leading or trailing whitespace"
        )
    if not RELEASE_ID_PATTERN.fullmatch(candidate):
        raise ValueError(
            "invalid release_id: expected a slug using only letters, digits, '.', '_' or '-'"
        )
    return candidate


def _release_dir(output_root: Path, release_id: str) -> Path:
    return output_root / release_id


def _release_source_path(release_dir: Path) -> Path:
    return release_dir / RELEASE_SOURCE_NAME


def _generated_dir(release_dir: Path) -> Path:
    return release_dir / GENERATED_DIRNAME


def _workflow_path(release_dir: Path) -> Path:
    return _generated_dir(release_dir) / WORKFLOW_NAME


def _packet_path(release_dir: Path, stage: ReleaseStage) -> Path:
    return _generated_dir(release_dir) / PACKETS_DIRNAME / f"{stage.order:02d}-{stage.stage_id}.json"


def _receipt_template_path(release_dir: Path) -> Path:
    return _generated_dir(release_dir) / RECEIPT_TEMPLATE_NAME


def _metrics_template_path(release_dir: Path) -> Path:
    return _generated_dir(release_dir) / METRICS_TEMPLATE_NAME


def _final_receipt_path(release_dir: Path) -> Path:
    return release_dir / FINAL_RECEIPT_NAME


def _generated_metadata(*, action: str, generated_at: str, source_hash: str) -> dict[str, str]:
    return {
        "generated_by": action,
        "generated_at": generated_at,
        "generator_version": GENERATOR_VERSION,
        "schema_version": SCHEMA_VERSION,
        "source_ref": RELEASE_SOURCE_NAME,
        "source_hash": source_hash,
    }


def _default_release_source(release_id: str) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "release_id": release_id,
        "thesis": "<state bounded release thesis>",
        "included_work": [],
        "excluded_work": [],
        "risk_notes": [],
        "acceptance_policy": {
            "required_checks": [
                "targeted-tests",
                "review-packet-preflight",
                "self-review",
                "independent-review",
            ],
            "allow_exceptions": False,
        },
        "publication_expectations": {
            "mode": "merge",
            "expected_outputs": [],
        },
        "next_work_judgment": {
            "on_complete": "complete",
            "notes": "<capture next work or explicit terminal outcome>",
        },
        "stage_overrides": {},
        "closeout": {
            "disposition": "<accepted|rejected|needs_changes|partial|aborted|superseded>",
            "decision_ref": "<decision-ref>",
            "evidence_refs": ["<evidence-ref>"],
            "output_refs": ["<output-ref>"],
            "route_taken": "<route-name>",
            "next_work_ref": "complete",
            "summary": "<closeout-summary>",
        },
    }


def _load_release_source(release_dir: Path) -> dict[str, Any]:
    source_path = _release_source_path(release_dir)
    if not source_path.exists():
        raise ValueError(f"release source missing: {source_path}")
    source = _load_json(source_path)
    _validate_payload(source, _load_schema(SOURCE_SCHEMA_PATH), kind="release source")
    return source


def _stage_work_id(release_id: str, stage: ReleaseStage) -> str:
    return f"REL-{release_id}-{stage.order:02d}-{stage.stage_id}"


def _stage_override(source: dict[str, Any], stage_id: str, key: str, default: list[str] | str) -> list[str] | str:
    overrides = source.get("stage_overrides", {})
    stage_override = overrides.get(stage_id, {})
    value = stage_override.get(key)
    if value is None:
        return default
    return value


def _route_options(source: dict[str, Any], current_index: int, release_id: str) -> list[dict[str, str]]:
    current_stage = STAGES[current_index]
    options: list[dict[str, str]] = []
    if current_index + 1 < len(STAGES):
        next_stage = STAGES[current_index + 1]
        options.append({"when": "complete", "next_work_ref": _stage_work_id(release_id, next_stage)})
    else:
        next_work_ref = str(source.get("next_work_judgment", {}).get("on_complete", "complete"))
        options.append({"when": "complete", "next_work_ref": next_work_ref})

    if current_stage.stage_id == "release-approval":
        options.append({"when": "needs_changes", "next_work_ref": _stage_work_id(release_id, STAGES[1])})
    elif current_index > 0:
        previous_stage = STAGES[current_index - 1]
        options.append({"when": "needs_changes", "next_work_ref": _stage_work_id(release_id, previous_stage)})
    else:
        options.append({"when": "needs_changes", "next_work_ref": _stage_work_id(release_id, current_stage)})
    return options


def _build_stage_packet(
    source: dict[str, Any],
    current_index: int,
    generated_metadata: dict[str, str],
) -> dict[str, Any]:
    stage = STAGES[current_index]
    release_id = str(source["release_id"])
    work_id = _stage_work_id(release_id, stage)
    upstream = []
    if current_index > 0:
        upstream.append(_stage_work_id(release_id, STAGES[current_index - 1]))
    return {
        "schema_version": SCHEMA_VERSION,
        "packet_id": work_id,
        "release_id": release_id,
        "stage_id": stage.stage_id,
        "stage_order": stage.order,
        "work_id": work_id,
        "workflow_family": WORKFLOW_FAMILY,
        "intent": str(
            _stage_override(
                source,
                stage.stage_id,
                "intent",
                stage.intent_template.format(release_id=release_id, thesis=source["thesis"]),
            )
        ),
        "scope": list(_stage_override(source, stage.stage_id, "scope", list(stage.scope))),
        "constraints": list(
            _stage_override(source, stage.stage_id, "constraints", list(stage.constraints))
        ),
        "inputs": [
            f"release_id={release_id}",
            f"thesis={source['thesis']}",
            f"included_work_count={len(source.get('included_work', []))}",
            f"excluded_work_count={len(source.get('excluded_work', []))}",
            f"capability_class={stage.capability_class}",
        ],
        "required_evidence": list(
            _stage_override(source, stage.stage_id, "required_evidence", list(stage.required_evidence))
        ),
        "acceptance_criteria": list(
            _stage_override(
                source,
                stage.stage_id,
                "acceptance_criteria",
                list(stage.acceptance_criteria),
            )
        ),
        "allowed_actions": list(
            _stage_override(source, stage.stage_id, "allowed_actions", list(stage.allowed_actions))
        ),
        "upstream_lineage": upstream,
        "next_route_options": _route_options(source, current_index, release_id),
        "assigned_capability_class": stage.capability_class,
        "generated_metadata": generated_metadata,
    }


def _build_receipt_template(source: dict[str, Any], generated_metadata: dict[str, str]) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "release_id": str(source["release_id"]),
        "receipt_id": "<receipt-id>",
        "workflow_ref": f"{GENERATED_DIRNAME}/{WORKFLOW_NAME}",
        "packet_refs": [
            f"{GENERATED_DIRNAME}/{PACKETS_DIRNAME}/{stage.order:02d}-{stage.stage_id}.json"
            for stage in STAGES
        ],
        "source_ref": RELEASE_SOURCE_NAME,
        "source_hash": generated_metadata["source_hash"],
        "disposition": "<accepted|rejected|needs_changes|partial|aborted|superseded>",
        "decision_ref": "<decision-ref>",
        "evidence_refs": ["<evidence-ref>"],
        "output_refs": ["<output-ref>"],
        "route_taken": "<route-name>",
        "next_work_ref": "<next-work-ref-or-complete>",
        "summary": "<closeout-summary>",
        "timestamp": "<ISO-8601>",
        "ledger_commitment": {
            "mode": "file_backed",
            "status": "<pending_ledger_write>",
            "source_hash": generated_metadata["source_hash"],
            "ledger_entry_id": None,
        },
        "generated_metadata": generated_metadata,
    }


def _build_metrics_template(source: dict[str, Any], generated_metadata: dict[str, str]) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "release_id": str(source["release_id"]),
        "workflow_family": WORKFLOW_FAMILY,
        "authoritative": False,
        "generated_metadata": generated_metadata,
        "metrics": [
            {
                "name": name,
                "unit": "count" if name.endswith("_rate") else "minutes",
                "value": None,
                "source": "capture during release execution",
            }
            for name in METRIC_NAMES
        ],
    }


def _build_manifest(
    source: dict[str, Any],
    generated_metadata: dict[str, str],
    stage_records: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "release_id": str(source["release_id"]),
        "workflow_family": WORKFLOW_FAMILY,
        "packet_schema_ref": PACKET_SCHEMA_REF,
        "template_schema_ref": TEMPLATE_SCHEMA_REF,
        "final_receipt_schema_ref": FINAL_RECEIPT_SCHEMA_REF,
        "source_schema_ref": SOURCE_SCHEMA_REF,
        "generated_metadata": generated_metadata,
        "stages": stage_records,
        "receipt_template_ref": f"{GENERATED_DIRNAME}/{RECEIPT_TEMPLATE_NAME}",
        "metrics_template_ref": f"{GENERATED_DIRNAME}/{METRICS_TEMPLATE_NAME}",
    }


def _build_generated_outputs(
    source: dict[str, Any],
    release_dir: Path,
    *,
    action: str,
    generated_at: str,
) -> dict[Path, dict[str, Any]]:
    source_hash = _sha256(source)
    metadata = _generated_metadata(action=action, generated_at=generated_at, source_hash=source_hash)

    outputs: dict[Path, dict[str, Any]] = {}
    stage_records: list[dict[str, Any]] = []
    packet_schema = _load_schema(PACKET_SCHEMA_PATH)
    template_schema = _load_schema(TEMPLATE_SCHEMA_PATH)

    for idx, stage in enumerate(STAGES):
        packet = _build_stage_packet(source, idx, metadata)
        _validate_payload(packet, packet_schema, kind=f"{stage.stage_id} packet")
        packet_path = _packet_path(release_dir, stage)
        outputs[packet_path] = packet
        stage_records.append(
            {
                "packet_id": packet["packet_id"],
                "stage_id": stage.stage_id,
                "stage_order": stage.order,
                "display_name": stage.display_name,
                "capability_class": stage.capability_class,
                "packet_ref": str(Path(GENERATED_DIRNAME) / PACKETS_DIRNAME / packet_path.name),
            }
        )

    receipt_template = _build_receipt_template(source, metadata)
    _validate_payload(receipt_template, template_schema, kind="receipt template")
    outputs[_receipt_template_path(release_dir)] = receipt_template
    outputs[_metrics_template_path(release_dir)] = _build_metrics_template(source, metadata)
    outputs[_workflow_path(release_dir)] = _build_manifest(source, metadata, stage_records)
    return outputs


def _write_generated_outputs(outputs: dict[Path, dict[str, Any]]) -> None:
    for path, payload in outputs.items():
        _write_json(path, payload)


def _validate_source_identity(source: dict[str, Any], release_id: str) -> None:
    if str(source.get("release_id")) != release_id:
        raise ValueError(
            f"release source mismatch: expected release_id={release_id}, found {source.get('release_id')}"
        )


def _workspace_exists_with_content(release_dir: Path) -> bool:
    return release_dir.exists() and any(release_dir.iterdir())


def scaffold_release_workflow(release_id: str, output_root: Path, *, force: bool = False) -> dict[str, Any]:
    release_id = _validate_release_id(release_id)
    release_dir = _release_dir(output_root, release_id)
    source_path = _release_source_path(release_dir)
    final_receipt_path = _final_receipt_path(release_dir)

    if _workspace_exists_with_content(release_dir) and not force:
        raise ValueError(
            f"release workspace already exists: {release_dir}. Use `motus release sync` or rerun scaffold with --force."
        )
    if final_receipt_path.exists():
        raise ValueError(f"final receipt already exists: {final_receipt_path}")

    source_schema = _load_schema(SOURCE_SCHEMA_PATH)
    if source_path.exists():
        source = _load_json(source_path)
        _validate_payload(source, source_schema, kind="release source")
        _validate_source_identity(source, release_id)
    else:
        source = _default_release_source(release_id)
        _validate_payload(source, source_schema, kind="release source")
        _write_json(source_path, source)

    outputs = _build_generated_outputs(source, release_dir, action="motus release scaffold", generated_at=_now_iso())
    _write_generated_outputs(outputs)
    return _payload_summary(release_dir, outputs)


def sync_release_workflow(release_id: str, output_root: Path) -> dict[str, Any]:
    release_id = _validate_release_id(release_id)
    release_dir = _release_dir(output_root, release_id)
    if _final_receipt_path(release_dir).exists():
        raise ValueError(f"cannot sync finalized release workspace: {_final_receipt_path(release_dir)}")
    source = _load_release_source(release_dir)
    _validate_source_identity(source, release_id)
    try:
        _validate_generated_outputs(source, release_dir)
        return _payload_summary(release_dir, {})
    except ValueError:
        pass
    outputs = _build_generated_outputs(source, release_dir, action="motus release sync", generated_at=_now_iso())
    _write_generated_outputs(outputs)
    return _payload_summary(release_dir, outputs)


def _payload_summary(release_dir: Path, outputs: dict[Path, dict[str, Any]]) -> dict[str, Any]:
    return {
        "release_id": release_dir.name,
        "workflow_family": WORKFLOW_FAMILY,
        "output_dir": str(release_dir),
        "source_schema_ref": SOURCE_SCHEMA_REF,
        "packet_schema_ref": PACKET_SCHEMA_REF,
        "template_schema_ref": TEMPLATE_SCHEMA_REF,
        "final_receipt_schema_ref": FINAL_RECEIPT_SCHEMA_REF,
        "generated_files": [str(path) for path in sorted(outputs)],
        "stage_count": len(STAGES),
    }


def _validate_generated_payload(
    *,
    actual: dict[str, Any],
    expected: dict[str, Any],
    path: Path,
    schema: dict[str, Any] | None = None,
    kind: str,
) -> None:
    if schema is not None:
        _validate_payload(actual, schema, kind=kind)
    if actual != expected:
        raise ValueError(f"generated artifact drift detected: {path}")


def _validate_generated_outputs(source: dict[str, Any], release_dir: Path) -> dict[str, int]:
    workflow_path = _workflow_path(release_dir)
    receipt_template_path = _receipt_template_path(release_dir)
    metrics_path = _metrics_template_path(release_dir)
    if not workflow_path.exists():
        raise ValueError(f"generated workflow manifest missing: {workflow_path}")
    if not receipt_template_path.exists():
        raise ValueError(f"generated receipt template missing: {receipt_template_path}")
    if not metrics_path.exists():
        raise ValueError(f"generated metrics template missing: {metrics_path}")

    source_hash = _sha256(source)
    validated_packets = 0
    packet_schema = _load_schema(PACKET_SCHEMA_PATH)
    template_schema = _load_schema(TEMPLATE_SCHEMA_PATH)

    for stage in STAGES:
        packet_path = _packet_path(release_dir, stage)
        if not packet_path.exists():
            raise ValueError(f"generated stage packet missing: {packet_path}")
        actual_packet = _load_json(packet_path)
        metadata = dict(actual_packet.get("generated_metadata", {}))
        if metadata.get("source_hash") != source_hash:
            raise ValueError(f"generated stage packet source hash is stale: {packet_path}")
        expected_packet = _build_stage_packet(source, stage.order - 1, metadata)
        _validate_generated_payload(
            actual=actual_packet,
            expected=expected_packet,
            path=packet_path,
            schema=packet_schema,
            kind=f"{stage.stage_id} packet",
        )
        validated_packets += 1

    actual_template = _load_json(receipt_template_path)
    template_metadata = dict(actual_template.get("generated_metadata", {}))
    if template_metadata.get("source_hash") != source_hash:
        raise ValueError(f"generated receipt template source hash is stale: {receipt_template_path}")
    expected_template = _build_receipt_template(source, template_metadata)
    _validate_generated_payload(
        actual=actual_template,
        expected=expected_template,
        path=receipt_template_path,
        schema=template_schema,
        kind="receipt template",
    )

    actual_metrics = _load_json(metrics_path)
    metrics_metadata = dict(actual_metrics.get("generated_metadata", {}))
    if metrics_metadata.get("source_hash") != source_hash:
        raise ValueError(f"generated metrics template source hash is stale: {metrics_path}")
    expected_metrics = _build_metrics_template(source, metrics_metadata)
    _validate_generated_payload(
        actual=actual_metrics,
        expected=expected_metrics,
        path=metrics_path,
        kind="metrics template",
    )

    actual_workflow = _load_json(workflow_path)
    workflow_metadata = dict(actual_workflow.get("generated_metadata", {}))
    if workflow_metadata.get("source_hash") != source_hash:
        raise ValueError(f"generated workflow manifest source hash is stale: {workflow_path}")
    stage_records = [
        {
            "packet_id": _stage_work_id(str(source["release_id"]), stage),
            "stage_id": stage.stage_id,
            "stage_order": stage.order,
            "display_name": stage.display_name,
            "capability_class": stage.capability_class,
            "packet_ref": str(Path(GENERATED_DIRNAME) / PACKETS_DIRNAME / f"{stage.order:02d}-{stage.stage_id}.json"),
        }
        for stage in STAGES
    ]
    expected_workflow = _build_manifest(source, workflow_metadata, stage_records)
    _validate_generated_payload(
        actual=actual_workflow,
        expected=expected_workflow,
        path=workflow_path,
        kind="workflow manifest",
    )
    return {"validated_stage_packets": validated_packets, "validated_receipt_templates": 1}


def _build_final_receipt(source: dict[str, Any], release_dir: Path, *, timestamp: str) -> dict[str, Any]:
    closeout = dict(source["closeout"])
    workflow_path = _workflow_path(release_dir)
    if not workflow_path.exists():
        raise ValueError(f"generated workflow manifest missing: {workflow_path}")
    workflow = _load_json(workflow_path)
    source_hash = _sha256(source)
    receipt = {
        "schema_version": SCHEMA_VERSION,
        "receipt_id": f"receipt-{source['release_id']}",
        "release_id": str(source["release_id"]),
        "workflow_family": WORKFLOW_FAMILY,
        "workflow_ref": str(Path(GENERATED_DIRNAME) / WORKFLOW_NAME),
        "packet_refs": [stage["packet_ref"] for stage in workflow["stages"]],
        "source_ref": RELEASE_SOURCE_NAME,
        "source_hash": source_hash,
        "disposition": closeout["disposition"],
        "decision_ref": closeout["decision_ref"],
        "evidence_refs": list(closeout["evidence_refs"]),
        "output_refs": list(closeout["output_refs"]),
        "route_taken": closeout["route_taken"],
        "next_work_ref": closeout["next_work_ref"],
        "summary": closeout["summary"],
        "timestamp": timestamp,
        "ledger_commitment": {
            "mode": "file_backed",
            "status": "pending_ledger_write",
            "source_hash": source_hash,
            "ledger_entry_id": None,
        },
    }
    receipt["receipt_hash"] = _sha256(receipt, exclude=("receipt_hash",))
    return receipt


def validate_release_workflow(release_id: str, output_root: Path, *, final: bool = False) -> dict[str, Any]:
    release_id = _validate_release_id(release_id)
    release_dir = _release_dir(output_root, release_id)
    source = _load_release_source(release_dir)
    _validate_source_identity(source, release_id)
    schema_validation = _validate_generated_outputs(source, release_dir)

    payload = {
        "release_id": release_id,
        "workflow_family": WORKFLOW_FAMILY,
        "output_dir": str(release_dir),
        "source_schema_ref": SOURCE_SCHEMA_REF,
        "packet_schema_ref": PACKET_SCHEMA_REF,
        "template_schema_ref": TEMPLATE_SCHEMA_REF,
        "final_receipt_schema_ref": FINAL_RECEIPT_SCHEMA_REF,
        "schema_validation": schema_validation,
        "final": final,
    }

    if final:
        final_receipt_path = _final_receipt_path(release_dir)
        if not final_receipt_path.exists():
            raise ValueError(f"final receipt missing: {final_receipt_path}")
        actual_receipt = _load_json(final_receipt_path)
        final_schema = _load_schema(FINAL_RECEIPT_SCHEMA_PATH)
        _validate_payload(actual_receipt, final_schema, kind="final receipt")
        if actual_receipt["source_hash"] != _sha256(source):
            raise ValueError(f"final receipt source hash is stale: {final_receipt_path}")
        expected_receipt = _build_final_receipt(
            source,
            release_dir,
            timestamp=str(actual_receipt["timestamp"]),
        )
        if actual_receipt != expected_receipt:
            raise ValueError(f"final receipt drift detected: {final_receipt_path}")
        expected_hash = _sha256(actual_receipt, exclude=("receipt_hash",))
        if actual_receipt["receipt_hash"] != expected_hash:
            raise ValueError(f"final receipt hash mismatch: {final_receipt_path}")
        payload["final_receipt_path"] = str(final_receipt_path)
    return payload


def finalize_release_workflow(release_id: str, output_root: Path) -> dict[str, Any]:
    release_id = _validate_release_id(release_id)
    release_dir = _release_dir(output_root, release_id)
    final_receipt_path = _final_receipt_path(release_dir)
    if final_receipt_path.exists():
        raise ValueError(f"final receipt already exists: {final_receipt_path}")
    validate_release_workflow(release_id, output_root, final=False)
    source = _load_release_source(release_dir)
    receipt = _build_final_receipt(source, release_dir, timestamp=_now_iso())
    _validate_payload(receipt, _load_schema(FINAL_RECEIPT_SCHEMA_PATH), kind="final receipt")
    _write_json(final_receipt_path, receipt)
    return {
        "release_id": release_id,
        "workflow_family": WORKFLOW_FAMILY,
        "output_dir": str(release_dir),
        "final_receipt_path": str(final_receipt_path),
        "receipt_id": receipt["receipt_id"],
        "receipt_hash": receipt["receipt_hash"],
    }
