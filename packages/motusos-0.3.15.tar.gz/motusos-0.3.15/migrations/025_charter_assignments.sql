-- Migration: 025_charter_assignments
-- Version: 25
-- Description: Link charters to programs/products/releases
-- Date: 2026-01-18
-- CR: CR-2026-01-18-003
--
-- CHANGE SUMMARY:
-- 1. Add charter_assignments table

-- =========================================================================
-- UP
-- =========================================================================

CREATE TABLE IF NOT EXISTS charter_assignments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    charter_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    deleted_at TEXT,
    FOREIGN KEY (charter_id) REFERENCES charter_docs(id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_charter_assignments_unique
ON charter_assignments(charter_id, entity_type, entity_id)
WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_charter_assignments_entity
ON charter_assignments(entity_type, entity_id)
WHERE deleted_at IS NULL;

-- =========================================================================
-- AUDIT LOG
-- =========================================================================

INSERT INTO audit_log (event_type, actor, resource_type, action, new_value, instance_id, protocol_version)
SELECT
    'schema_change',
    'migration:025_charter_assignments',
    'charter_assignments',
    'create_table',
    json_object('table', 'charter_assignments'),
    COALESCE((SELECT value FROM instance_config WHERE key = 'instance_id'), 'unknown'),
    1;

-- =========================================================================
-- DOWN
-- =========================================================================
-- NOTE: SQLite doesn't support DROP COLUMN easily.
-- Rollback requires table recreation.
--
-- DROP TABLE charter_assignments;
