-- Migration: 023_workflow_requirements
-- Version: 23
-- Description: Add workflow requirements and pinned required sets
-- Date: 2026-01-18
-- CR: CR-2026-01-18-001
--
-- CHANGE SUMMARY:
-- 1. Add workflow_definitions + workflow_requirements tables
-- 2. Add release_required_sets + release_required_set_items tables
-- 3. Add terminology for workflow statuses and requirement types

-- =========================================================================
-- UP
-- =========================================================================

-- Terminology: workflow statuses
INSERT OR IGNORE INTO terminology (domain, internal_key, display_name, description, sort_order) VALUES
('workflow_status', 'draft', 'Draft', 'Workflow definition not yet active', 1),
('workflow_status', 'active', 'Active', 'Workflow definition in use', 2),
('workflow_status', 'deprecated', 'Deprecated', 'Workflow definition no longer recommended', 3);

-- Terminology: requirement types
INSERT OR IGNORE INTO terminology (domain, internal_key, display_name, description, sort_order) VALUES
('requirement_type', 'cr', 'Change Request', 'Required CR for a workflow', 1),
('requirement_type', 'work_item', 'Work Item', 'Required work item for a workflow', 2),
('requirement_type', 'checklist', 'Checklist', 'Required checklist item', 3);

-- Terminology: required set statuses
INSERT OR IGNORE INTO terminology (domain, internal_key, display_name, description, sort_order) VALUES
('required_set_status', 'draft', 'Draft', 'Required set not yet locked', 1),
('required_set_status', 'locked', 'Locked', 'Required set is pinned for release', 2),
('required_set_status', 'superseded', 'Superseded', 'Replaced by a newer required set', 3);

-- Terminology: required set item statuses
INSERT OR IGNORE INTO terminology (domain, internal_key, display_name, description, sort_order) VALUES
('required_set_item_status', 'open', 'Open', 'Not yet started', 1),
('required_set_item_status', 'in_progress', 'In Progress', 'Work underway', 2),
('required_set_item_status', 'done', 'Done', 'Requirement satisfied', 3),
('required_set_item_status', 'skipped', 'Skipped', 'Explicitly skipped with justification', 4);

CREATE TABLE IF NOT EXISTS workflow_definitions (
    workflow_id TEXT NOT NULL,
    version TEXT NOT NULL,
    name TEXT NOT NULL,
    owner TEXT NOT NULL,
    status_key TEXT NOT NULL DEFAULT 'draft',
    description TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    deleted_at TEXT,
    PRIMARY KEY (workflow_id, version)
);

CREATE INDEX IF NOT EXISTS idx_workflow_definitions_status
ON workflow_definitions(status_key)
WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS workflow_requirements (
    workflow_id TEXT NOT NULL,
    version TEXT NOT NULL,
    requirement_type TEXT NOT NULL,
    requirement_id TEXT NOT NULL,
    blocking INTEGER NOT NULL DEFAULT 1,
    depends_on TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    deleted_at TEXT,
    PRIMARY KEY (workflow_id, version, requirement_type, requirement_id),
    FOREIGN KEY (workflow_id, version) REFERENCES workflow_definitions(workflow_id, version)
);

CREATE INDEX IF NOT EXISTS idx_workflow_requirements_type
ON workflow_requirements(requirement_type)
WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS release_required_sets (
    required_set_id TEXT PRIMARY KEY,
    release_id TEXT NOT NULL,
    workflow_id TEXT NOT NULL,
    version TEXT NOT NULL,
    status_key TEXT NOT NULL DEFAULT 'draft',
    locked_at TEXT,
    locked_by TEXT,
    supersedes_id TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    deleted_at TEXT,
    FOREIGN KEY (release_id) REFERENCES releases(id),
    FOREIGN KEY (workflow_id, version) REFERENCES workflow_definitions(workflow_id, version)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_required_sets_active
ON release_required_sets(release_id)
WHERE deleted_at IS NULL AND status_key != 'superseded';

CREATE TABLE IF NOT EXISTS release_required_set_items (
    required_set_id TEXT NOT NULL,
    requirement_type TEXT NOT NULL,
    requirement_id TEXT NOT NULL,
    blocking INTEGER NOT NULL DEFAULT 1,
    status_key TEXT NOT NULL DEFAULT 'open',
    satisfied_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    deleted_at TEXT,
    PRIMARY KEY (required_set_id, requirement_type, requirement_id),
    FOREIGN KEY (required_set_id) REFERENCES release_required_sets(required_set_id)
);

CREATE INDEX IF NOT EXISTS idx_required_set_items_status
ON release_required_set_items(status_key)
WHERE deleted_at IS NULL;

-- =========================================================================
-- AUDIT LOG
-- =========================================================================

INSERT INTO audit_log (event_type, actor, resource_type, action, new_value, instance_id, protocol_version)
SELECT
    'schema_change',
    'migration:023_workflow_requirements',
    'workflow_requirements',
    'create_tables',
    json_object(
        'tables', json_array(
            'workflow_definitions',
            'workflow_requirements',
            'release_required_sets',
            'release_required_set_items'
        ),
        'terminology', json_array(
            'workflow_status',
            'requirement_type',
            'required_set_status',
            'required_set_item_status'
        )
    ),
    COALESCE((SELECT value FROM instance_config WHERE key = 'instance_id'), 'unknown'),
    1;

-- =========================================================================
-- DOWN
-- =========================================================================
-- NOTE: SQLite doesn't support DROP COLUMN easily.
-- Rollback requires table recreation.
--
-- DROP TABLE release_required_set_items;
-- DROP TABLE release_required_sets;
-- DROP TABLE workflow_requirements;
-- DROP TABLE workflow_definitions;
