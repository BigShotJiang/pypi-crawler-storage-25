-- Migration: 024_entity_links_metadata
-- Version: 24
-- Description: Add external links and UDF metadata tables
-- Date: 2026-01-18
-- CR: CR-2026-01-18-002
--
-- CHANGE SUMMARY:
-- 1. Add entity_links for external system mapping
-- 2. Add entity_metadata for user-defined fields
-- 3. Add terminology for metadata value types

-- =========================================================================
-- UP
-- =========================================================================

-- Terminology: metadata value types
INSERT OR IGNORE INTO terminology (domain, internal_key, display_name, description, sort_order) VALUES
('metadata_value_type', 'string', 'String', 'Text value', 1),
('metadata_value_type', 'number', 'Number', 'Numeric value', 2),
('metadata_value_type', 'boolean', 'Boolean', 'True/false', 3),
('metadata_value_type', 'json', 'JSON', 'Structured JSON string', 4);

CREATE TABLE IF NOT EXISTS entity_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    system TEXT NOT NULL,
    external_id TEXT,
    external_url TEXT,
    metadata_json TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    deleted_at TEXT,
    CHECK (external_id IS NOT NULL OR external_url IS NOT NULL)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_entity_links_unique
ON entity_links(entity_type, entity_id, system)
WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_entity_links_system
ON entity_links(system, external_id)
WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS entity_metadata (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    namespace TEXT NOT NULL DEFAULT 'userland',
    key TEXT NOT NULL,
    value TEXT,
    value_type TEXT NOT NULL DEFAULT 'string',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    deleted_at TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_entity_metadata_unique
ON entity_metadata(entity_type, entity_id, namespace, key)
WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_entity_metadata_namespace
ON entity_metadata(namespace)
WHERE deleted_at IS NULL;

-- =========================================================================
-- AUDIT LOG
-- =========================================================================

INSERT INTO audit_log (event_type, actor, resource_type, action, new_value, instance_id, protocol_version)
SELECT
    'schema_change',
    'migration:024_entity_links_metadata',
    'entity_metadata',
    'create_tables',
    json_object(
        'tables', json_array('entity_links', 'entity_metadata'),
        'terminology', json_array('metadata_value_type')
    ),
    COALESCE((SELECT value FROM instance_config WHERE key = 'instance_id'), 'unknown'),
    1;

-- =========================================================================
-- DOWN
-- =========================================================================
-- NOTE: SQLite doesn't support DROP COLUMN easily.
-- Rollback requires table recreation.
--
-- DROP TABLE entity_metadata;
-- DROP TABLE entity_links;
