# crewai-forge

Forge Verify tools and guardrails for [CrewAI](https://github.com/crewAIInc/crewAI). Verify every AI agent action against your policies **before** execution.

## Install

```bash
pip install crewai-forge
```

## Quick Start

```python
import os
from crewai import Agent, Task, Crew
from forge_crewai import ForgeVerifyTool, forge_task_guardrail

os.environ["VERITERA_API_KEY"] = "vt_live_..."

# Create a Forge verification tool
verify = ForgeVerifyTool(policy="finance-controls")

# Give it to your agent
analyst = Agent(
    role="Financial Analyst",
    goal="Process financial transactions safely",
    tools=[verify],
)

# Add a task guardrail for output validation
task = Task(
    description="Process the refund for order #12345",
    agent=analyst,
    guardrail=forge_task_guardrail(policy="finance-controls"),
    guardrail_max_retries=3,
)

crew = Crew(agents=[analyst], tasks=[task])
result = crew.kickoff()
```

## Three Integration Points

### 1. Agent Tool — verify before acting

```python
from forge_crewai import ForgeVerifyTool

tool = ForgeVerifyTool(policy="finance-controls")
agent = Agent(role="Analyst", tools=[tool])
```

The agent calls `forge_verify(action="payment.create", params='{"amount": 500}')` before executing sensitive actions.

### 2. Task Guardrail — validate output

```python
from forge_crewai import forge_task_guardrail

task = Task(
    description="Draft customer email",
    agent=support_agent,
    guardrail=forge_task_guardrail(policy="communication-policy"),
    guardrail_max_retries=3,
)
```

If the output violates your policy, CrewAI automatically retries the task.

### 3. LLM Hooks — intercept at the model level

```python
from forge_crewai import forge_before_llm, forge_after_llm

# Block LLM calls that violate policy
forge_before_llm(policy="safety-controls", max_iterations=10)

# Audit all LLM responses
forge_after_llm(policy="audit-trail")
```

## License

MIT — [Veritera AI](https://veritera.ai)
