import asyncio
import difflib
import importlib
import logging
import os
import re
import sys
import textwrap
import traceback
import warnings
from collections.abc import Sequence
from typing import Annotated, Optional, Union

import click
import coloredlogs
import typer
import typer.core
from packaging.version import Version
from typer.core import TyperGroup
from i_search_app_mac.typer_injector import InjectingTyper

from i_search_app_mac.cli.cli_common import TUNNEL_ENV_VAR, isatty, set_color_flag, set_verbosity
from i_search_app_mac.exceptions import (
    NoDeviceConnectedError,
    PasswordRequiredError,
    
)

coloredlogs.install(level=logging.INFO)

logger = logging.getLogger(__name__)


INVALID_SERVICE_MESSAGE = "Failed to start service"

CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"], "max_content_width": 400}

# Mapping of index options to import file names
CLI_GROUPS = {
    "backup2": "backup",
}

# Set if used the `--reconnect` option
RECONNECT = False


class TyperGroup3(TyperGroup):
    def list_commands(self, ctx: click.Context) -> list[str]:
        return list(CLI_GROUPS.keys())

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command:
        if cmd_name not in CLI_GROUPS:
            self.handle_invalid_command(ctx, cmd_name)
        return self.import_and_get_command(ctx, cmd_name)

    @staticmethod
    def import_and_get_command(ctx: click.Context, name: str) -> click.Command:
        module_name = f"i_search_app_mac.cli.{CLI_GROUPS[name]}"
        mod = importlib.import_module(module_name)
        cli: typer.Typer = mod.cli
        return typer.main.get_command(cli)

    @staticmethod
    def highlight_keyword(text: str, keyword: str) -> str:
        return re.sub(f"({keyword})", typer.style("\\1", bold=True), text, flags=re.IGNORECASE)

    @staticmethod
    def collect_commands(command: Union[TyperGroup, click.Command]) -> Union[str, list[str]]:
        if isinstance(command, TyperGroup):  # group
            cmds = []
            for v in command.commands.values():
                child = TyperGroup3.collect_commands(v)
                if isinstance(child, list):
                    cmds.extend([f"{command.name} {c}" for c in child])
                else:
                    cmds.append(f"{command.name} {child}")
            return cmds
        return command.name or ""

    @staticmethod
    def search_commands(pattern: str) -> list[str]:
        all_commands = TyperGroup3.load_all_commands()
        matched = sorted(filter(lambda cmd: re.search(pattern, cmd), all_commands))
        if not matched:
            matched = difflib.get_close_matches(pattern, all_commands, n=20, cutoff=0.4)
        if isatty():
            matched = [TyperGroup3.highlight_keyword(cmd, pattern) for cmd in matched]
        return matched

    @staticmethod
    def load_all_commands() -> list[str]:
        all_commands: list[str] = []
        for key in CLI_GROUPS:
            module_name = f"i_search_app_mac.cli.{CLI_GROUPS[key]}"
            mod = importlib.import_module(module_name)
            if isinstance(mod.cli, typer.Typer):
                cmd = TyperGroup3.collect_commands(typer.main.get_group(mod.cli))
            else:
                cmd = TyperGroup3.collect_commands(mod.cli.commands[key])
            if isinstance(cmd, list):
                all_commands.extend(cmd)
            else:
                all_commands.append(cmd)
        return all_commands

    def resolve_command(
        self, ctx: click.Context, args: list[str]
    ) -> tuple[Optional[str], Optional[click.Command], list[str]]:
        return super().resolve_command(ctx, args)


app = InjectingTyper(
    cls=TyperGroup3,
    context_settings=CONTEXT_SETTINGS,
    no_args_is_help=True,
    # add_completion=False,
    rich_markup_mode="markdown",
    help=(
        "Swiss-army CLI"
    ),
)


@app.callback()
def _root(
    reconnect: Annotated[
        bool,
        typer.Option(
            "--reconnect",
            help="Automatically reconnect if the device disconnects mid-command.",
            show_default=False,
        ),
    ] = False,
    verbosity: Annotated[
        int,
        typer.Option(
            "--verbose",
            "-v",
            count=True,
            help="Increase logging verbosity (repeat for more detail).",
        ),
    ] = 0,
    color: Annotated[
        bool,
        typer.Option(help=""),
    ] = True,
) -> None:

    global RECONNECT
    RECONNECT = reconnect
    set_verbosity(verbosity)
    set_color_flag(color)


class PossiblyMisplacedOption(click.NoSuchOption):
    def __init__(
        self,
        option_name: str,
        message: Optional[str] = None,
        possibilities: Optional[Sequence[str]] = None,
        ctx: Optional[click.Context] = None,
        suggested_ctx: Optional[click.Context] = None,
    ) -> None:
        super().__init__(option_name, message, possibilities, ctx)
        if suggested_ctx is not None:
            if ctx is not None:
                self.message += f" for subcommand: {ctx.command_path}"

            suggestion = f"{suggested_ctx.command_path} {option_name}"
            suggestion += ctx.command_path.removeprefix(suggested_ctx.command_path) if ctx is not None else " ..."

            self.message += f"\nDid you mean: {suggestion}?"

    @staticmethod
    def from_no_such_option(e: click.NoSuchOption) -> "PossiblyMisplacedOption":
        ctx = e.ctx
        while ctx:
            for param in ctx.command.params:
                if isinstance(param, typer.core.TyperOption) and (
                    e.option_name in param.opts or e.option_name in param.secondary_opts
                ):
                    break
            else:
                ctx = ctx.parent
                continue
            break

        return PossiblyMisplacedOption(e.option_name, e.message, e.possibilities, e.ctx, ctx)


def invoke_cli_with_error_handling() -> bool:

    try:
        try:
            app(standalone_mode=False)
        except click.NoSuchOption as e:
            raise PossiblyMisplacedOption.from_no_such_option(e) from e
    except NoDeviceConnectedError:
        logger.error("Device is not connected")
        return True
    except PasswordRequiredError:
        logger.error("Device is password protected. Please unlock and retry")

    return False


def main() -> None:
    while invoke_cli_with_error_handling():
        if not RECONNECT:
            break
        try:
            lockdown = asyncio.run(retry_create_using_usbmux(None))
            asyncio.run(lockdown.close())
        except KeyboardInterrupt:
            break


if __name__ == "__main__":
    main()
