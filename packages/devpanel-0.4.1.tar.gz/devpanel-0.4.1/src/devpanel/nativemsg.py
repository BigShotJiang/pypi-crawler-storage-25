"""Chrome native messaging: one-shot daemon launcher.

Wire format: 4-byte LE uint32 length prefix + JSON payload on stdin/stdout.
Reads a single message, ensures daemon is running, returns port, exits.
"""

from __future__ import annotations

import json
import os
import struct
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

SPILL_DIR = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "devpanel"
LOCK_FILE = SPILL_DIR / "daemon.lock"


def read() -> dict:
    """Read one native message from stdin."""
    raw_len = sys.stdin.buffer.read(4)
    if not raw_len or len(raw_len) < 4:
        raise EOFError
    length = struct.unpack("<I", raw_len)[0]
    payload = sys.stdin.buffer.read(length)
    return json.loads(payload)


def write(msg: dict) -> None:
    """Write one native message to stdout."""
    payload = json.dumps(msg).encode()
    sys.stdout.buffer.write(struct.pack("<I", len(payload)))
    sys.stdout.buffer.write(payload)
    sys.stdout.buffer.flush()


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _probe_health(port: int) -> bool:
    """Check if daemon at given port is healthy."""
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/controls")
        with urllib.request.urlopen(req, timeout=1) as resp:
            return resp.status == 200
    except Exception:
        return False


def _read_lock() -> dict | None:
    """Read and validate the lock file. Returns {pid, port} or None."""
    try:
        data = json.loads(LOCK_FILE.read_text())
        if _pid_alive(data.get("pid", 0)):
            return data
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return None


def _spawn_daemon() -> None:
    """Spawn daemon as a fully detached process via repld for live introspection.

    Uses `uv run --project <root> repld --init repl.py` so repld runs with
    devpanel's venv active (devpanel + aiohttp importable in the init script).
    Socket pinned to $XDG_RUNTIME_DIR/devpanel/repld.sock so `repld bridge`
    can find it.
    """
    # Derive project root from source tree: src/devpanel/nativemsg.py → project root
    project_root = Path(__file__).resolve().parent.parent.parent
    socket_path = str(SPILL_DIR / "repld.sock")
    repl_path = str(Path(__file__).resolve().parent / "repl.py")
    cmd = [
        "uv",
        "run",
        "--project",
        str(project_root),
        "repld",
        "--socket",
        socket_path,
        "--init",
        repl_path,
    ]

    subprocess.Popen(
        cmd,
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=True,
    )


def _wait_for_ready(timeout: float = 5.0) -> int | None:
    """Poll lock file until daemon is ready. Returns port or None."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        lock = _read_lock()
        port = lock.get("port") if lock else None
        if port and _probe_health(port):
            return port
        time.sleep(0.1)
    return None


def _ensure_daemon() -> dict:
    """Ensure daemon is running. Returns {"port": int}."""
    lock = _read_lock()
    if lock:
        port = lock.get("port")
        if port and _probe_health(port):
            return {"port": port}
        # Stale lock — daemon crashed
        LOCK_FILE.unlink(missing_ok=True)

    _spawn_daemon()
    port = _wait_for_ready()
    if port is None:
        raise RuntimeError("daemon failed to start")
    return {"port": port}


def serve() -> None:
    """One-shot native messaging handler. Read message, ensure daemon, return port, exit."""
    try:
        msg = read()
    except EOFError:
        return

    msg_type = msg.get("type", "")

    if msg_type == "spawn":
        try:
            result = _ensure_daemon()
            write({"type": "ready", "port": result["port"]})
        except Exception as e:
            write({"type": "error", "message": str(e)})

    elif msg_type == "status":
        lock = _read_lock()
        if lock and _probe_health(lock["port"]):
            write({"type": "status", "running": True, "port": lock["port"]})
        else:
            write({"type": "status", "running": False, "port": None})

    else:
        write({"type": "error", "message": f"unknown message type: {msg_type}"})
