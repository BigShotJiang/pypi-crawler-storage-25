"""Hand-rolled MCP JSON-RPC dispatcher for DevPanel.

Streamable HTTP transport: POST /mcp for requests, GET /mcp for SSE notifications.
No SDK dependency — minimal JSON-RPC over aiohttp.
"""

from __future__ import annotations

import asyncio
import base64
import json
import time
import uuid
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from devpanel.server import PtySession

PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "devpanel"
SERVER_VERSION = "0.4.0"

TOOLS = [
    {
        "name": "context",
        "description": "Get current browser context (selected elements, network captures, screenshots). Does not clear the stack.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "drain",
        "description": "Drain browser context stack. Returns formatted text and clears the stack.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "js",
        "description": (
            "Evaluate JavaScript in the inspected tab. "
            "Returns the result as text. Use var (not let/const) for variables that persist across calls. "
            "_ is the last result, _1/_2/etc for numbered history. "
            "sendChannel(msg) is available in evals to push channel notifications. "
            "defer=true returns immediately with {task_id}; result arrives via channel. "
            "every=N runs code every N seconds; js.cancel(task_id) stops it."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "JavaScript to evaluate in the page",
                },
                "defer": {
                    "type": "boolean",
                    "description": "Run asynchronously; returns task_id immediately, result via channel",
                },
                "every": {
                    "type": "number",
                    "description": "Run every N seconds (>= 1); returns task_id, results via channel",
                },
            },
            "required": ["code"],
        },
    },
    {
        "name": "js.cancel",
        "description": "Cancel a deferred or recurring js task by id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task id returned by js(defer=true) or js(every=N)",
                },
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "screenshot",
        "description": (
            "Capture a screenshot of the inspected tab. "
            "With no args: viewport. With selector: just that element, even if "
            "off-screen (no scrolling, no page mutation). "
            "Returns a base64 PNG. Selectors: CSS, text=, role=, label=."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "selector": {
                    "type": "string",
                    "description": "Element selector to clip to (CSS / text= / role= / label=).",
                },
            },
        },
    },
    {
        "name": "network",
        "description": (
            "Get recent network requests from the inspected tab. "
            "Returns the last 20 HAR entries by default. "
            "Optional filters: url (substring or glob), method (GET/POST/etc), "
            "status (exact int or range like '4xx'/'5xx'), since (epoch ms)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL substring or glob pattern (e.g. */api/*)",
                },
                "method": {
                    "type": "string",
                    "description": "HTTP method filter (GET, POST, etc)",
                },
                "status": {
                    "type": ["string", "integer"],
                    "description": "Exact status code (e.g. 404) or range (e.g. '4xx')",
                },
                "since": {
                    "type": "number",
                    "description": "Filter by startedDateTime (epoch ms)",
                },
            },
        },
    },
    {
        "name": "console",
        "description": (
            "Recent console messages from the inspected page (log/warn/error + exceptions + "
            "browser-level entries like network errors). Errors are also auto-pushed as channel notifications."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "since": {
                    "type": "number",
                    "description": "Filter by timestamp (epoch ms)",
                },
                "level": {
                    "type": "string",
                    "enum": ["debug", "info", "log", "warning", "error"],
                    "description": "Minimum severity level",
                },
            },
        },
    },
    {
        "name": "watch",
        "description": (
            "Watch network requests matching a URL pattern. "
            "Each matching request pushes a channel notification. Returns {watch_id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url_pattern": {
                    "type": "string",
                    "description": "Substring or glob pattern to match against request URLs (e.g. '/api/' or '*/api/*')",
                },
            },
            "required": ["url_pattern"],
        },
    },
    {
        "name": "watch.cancel",
        "description": "Stop a network watcher by id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "watch_id": {
                    "type": "string",
                    "description": "Watch id returned by watch()",
                },
            },
            "required": ["watch_id"],
        },
    },
    {
        "name": "tree",
        "description": "Get the page's accessibility tree. Compact text format: role, name, state. Use to understand page structure before clicking or typing.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "depth": {
                    "type": "integer",
                    "description": "Max tree depth (default 6)",
                }
            },
        },
    },
    {
        "name": "click",
        "description": (
            "Click an element. Settles after network quiet, returns accessibility tree + network delta. "
            'Selectors: CSS (#id, .class), text=Submit, role=button[name="OK"], label=Email.'
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "Element selector"}
            },
            "required": ["selector"],
        },
    },
    {
        "name": "type",
        "description": (
            "Type text into a field, REPLACING any existing content. The element is focused, its content "
            "is selected, then text is typed (overwriting the selection). To append, read the field's "
            "current value first and type the concatenation. "
            "Settles after network quiet, returns tree + network delta. "
            "Selectors: CSS, text=, role=, label=."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "Element to type into"},
                "text": {
                    "type": "string",
                    "description": "Text to type (replaces existing field content)",
                },
                "press_enter": {
                    "type": "boolean",
                    "description": "Press Enter after typing",
                },
            },
            "required": ["selector", "text"],
        },
    },
    {
        "name": "navigate",
        "description": (
            "Navigate to a URL, or reload/go back/forward. "
            "Settles after page load, returns accessibility tree."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to navigate to"},
                "action": {
                    "type": "string",
                    "enum": ["reload", "back", "forward"],
                    "description": "Navigation action (alternative to url)",
                },
            },
        },
    },
]


def _result(rid: Any, result: Any) -> dict:
    return {"jsonrpc": "2.0", "id": rid, "result": result}


def _error(rid: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}}


def _resp_error(rid: Any, resp: dict) -> dict | None:
    """Return MCP tool error result if resp contains an error, else None."""
    if "error" in resp:
        return _result(
            rid,
            {
                "content": [{"type": "text", "text": f"Error: {resp['error']}"}],
                "isError": True,
            },
        )
    return None


class McpSession:
    """Per-MCP-client state. Queues channel notifications until initialized."""

    def __init__(self) -> None:
        self.session_id = uuid.uuid4().hex
        self.initialized = False
        self.pending: list[dict] = []
        self.queue: asyncio.Queue[dict | None] = asyncio.Queue()
        self.last_active = time.monotonic()

    def touch(self) -> None:
        self.last_active = time.monotonic()

    def push_notification(self, notification: dict) -> None:
        """Queue a server notification for delivery via SSE."""
        if not self.initialized:
            self.pending.append(notification)
        else:
            self.queue.put_nowait(notification)

    def push_channel(self, content: str) -> None:
        """Push a claude/channel notification with browser context."""
        self.push_notification(
            {
                "jsonrpc": "2.0",
                "method": "notifications/claude/channel",
                "params": {"content": content},
            }
        )

    def set_initialized(self) -> None:
        """Mark session as initialized, flush pending notifications."""
        self.initialized = True
        self.touch()
        for msg in self.pending:
            self.queue.put_nowait(msg)
        self.pending.clear()

    def close(self) -> None:
        """Signal the SSE loop to stop."""
        self.queue.put_nowait(None)


async def dispatch(req: dict, session: McpSession, pty: PtySession) -> dict | None:
    """Dispatch a JSON-RPC request. Returns response dict or None for notifications."""
    method = req.get("method")
    rid = req.get("id")

    match method:
        case "initialize":
            return _result(
                rid,
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
                    "capabilities": {
                        "tools": {},
                        "experimental": {"claude/channel": {}},
                    },
                    "instructions": (
                        'Browser context arrives as <channel source="devpanel"> blocks. '
                        "These are notifications — respond in chat, no tool call needed. "
                        "Use the `context` tool to peek the stack, `drain` to clear it. "
                        "Use `js` to evaluate JavaScript in the page, `screenshot` to capture the viewport, "
                        "`network` to get recent requests."
                    ),
                },
            )

        case "notifications/initialized":
            session.set_initialized()
            asyncio.create_task(pty.broadcast({"type": "mcp-status", "active": True}))
            return None

        case "tools/list":
            return _result(rid, {"tools": TOOLS})

        case "tools/call":
            return await _tools_call(rid, req.get("params", {}), session, pty)

        case "ping":
            return _result(rid, {})

        case _ if rid is None:
            return None  # unknown notification, ignore

        case _:
            return _error(rid, -32601, f"method not found: {method}")


async def _tools_call(rid: Any, params: dict, mcp: McpSession, pty: PtySession) -> dict:
    name = params.get("name")
    args = params.get("arguments", {})
    match name:
        case "context":
            return await _tool_context(rid, pty)
        case "drain":
            return await _tool_drain(rid, pty)
        case "js":
            return await _tool_js(rid, args, mcp, pty)
        case "js.cancel":
            return await _tool_js_cancel(rid, args, pty)
        case "screenshot":
            return await _tool_screenshot(rid, args, pty)
        case "network":
            return await _tool_network(rid, args, pty)
        case "console":
            return await _tool_console(rid, args, pty)
        case "tree":
            return await _tool_tree(rid, args, pty)
        case "click":
            return await _tool_click(rid, args, pty)
        case "type":
            return await _tool_type(rid, args, pty)
        case "navigate":
            return await _tool_navigate(rid, args, pty)
        case "watch":
            return await _tool_watch(rid, args, pty)
        case "watch.cancel":
            return await _tool_watch_cancel(rid, args, pty)
        case _:
            return _error(rid, -32602, f"unknown tool: {name}")


async def _tool_context(rid: Any, pty: PtySession) -> dict:
    from devpanel.server import _format_for_agent

    async with pty.stack_lock:
        items = list(pty.stack)
    text = _format_for_agent(items) if items else "No browser context available."
    return _result(rid, {"content": [{"type": "text", "text": text}]})


async def _tool_drain(rid: Any, pty: PtySession) -> dict:
    from devpanel.server import _format_for_agent

    async with pty.stack_lock:
        items = list(pty.stack)
        pty.stack.clear()
    if items:
        await pty.broadcast({"type": "stack-drained", "size": 0})
    text = _format_for_agent(items) if items else "Stack is empty."
    return _result(rid, {"content": [{"type": "text", "text": text}]})


def _format_eval_result(resp: dict, prefix: str = "") -> str:
    """Format an eval response into display text (with optional prefix for async tasks)."""
    from devpanel.server import _spill

    value = resp.get("result", {}).get("value")
    text = json.dumps(value, indent=2) if value is not None else "undefined"
    if len(text) > 4000:
        path = _spill(text, "eval_result", "json")
        preview = text[:2000] + "\n\n… truncated …\n\n" + text[-500:]
        text = f"{preview}\n\nFull result → {path}"
    if prefix:
        text = f"{prefix} {text}"
    return text


async def _defer_task(
    task_id: str, code: str, mcp: McpSession, pty: PtySession
) -> None:
    from devpanel.server import send_command

    try:
        resp = await send_command(pty, "eval", timeout=30.0, code=pty.wrap_eval(code))
        if "error" in resp:
            text = f"[{task_id}] Error: {resp['error']}"
        else:
            text = _format_eval_result(resp, prefix=f"[{task_id}]")
        mcp.push_channel(text)
    except asyncio.CancelledError:
        pass
    except Exception as e:
        mcp.push_channel(f"[{task_id}] Error: {e}")
    finally:
        async with pty.async_tasks_lock:
            pty.async_tasks.pop(task_id, None)


async def _every_task(
    task_id: str, code: str, interval: int, mcp: McpSession, pty: PtySession
) -> None:
    from devpanel.server import send_command

    try:
        while True:
            await asyncio.sleep(interval)
            try:
                resp = await send_command(
                    pty, "eval", timeout=30.0, code=pty.wrap_eval(code)
                )
                if "error" in resp:
                    text = f"[{task_id}] Error: {resp['error']}"
                else:
                    text = _format_eval_result(resp, prefix=f"[{task_id}]")
            except Exception as e:
                text = f"[{task_id}] Error: {e}"
            mcp.push_channel(text)
    except asyncio.CancelledError:
        pass
    finally:
        async with pty.async_tasks_lock:
            pty.async_tasks.pop(task_id, None)


async def _tool_js(rid: Any, args: dict, mcp: McpSession, pty: PtySession) -> dict:
    from devpanel.server import send_command, _spill, AsyncTask

    code = args.get("code", "")
    defer = args.get("defer", False)
    every = args.get("every")

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    # Async modes — spawn background task
    if defer or (every is not None and every > 0):
        task_id = await pty.alloc_task_id()
        if every is not None and every > 0:
            interval = max(1, int(every))
            at = asyncio.create_task(_every_task(task_id, code, interval, mcp, pty))
            kind = "every"
        else:
            at = asyncio.create_task(_defer_task(task_id, code, mcp, pty))
            kind = "defer"
        async with pty.async_tasks_lock:
            pty.async_tasks[task_id] = AsyncTask(
                task_id=task_id,
                kind=kind,
                code=code,
                interval=int(every) if every is not None else None,
                task=at,
            )
        return _result(
            rid, {"content": [{"type": "text", "text": f"Started {task_id}"}]}
        )

    # Synchronous eval
    is_async = args.get("async", False) or "await " in code
    wrapped = pty.wrap_eval(code)
    cmd_params: dict[str, Any] = {"code": wrapped}
    if is_async:
        cmd_params["async"] = True
    try:
        resp = await send_command(pty, "eval", timeout=5.0, **cmd_params)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Eval timed out (5s)")

    if err := _resp_error(rid, resp):
        return err

    value = resp.get("result", {}).get("value")  # type: ignore[union-attr]
    text = json.dumps(value, indent=2) if value is not None else "undefined"

    # History (skip oversized results, cap at 20 to bound wrap_eval preamble)
    if len(text) <= 1000:
        pty.eval_history.append(value)
    else:
        pty.eval_history.append("[large result]")
    pty.eval_history = pty.eval_history[-20:]

    # Spill if >4KB
    if len(text) > 4000:
        path = _spill(text, "eval_result", "json")
        preview = text[:2000] + "\n\n… truncated …\n\n" + text[-500:]
        text = f"{preview}\n\nFull result → {path}"

    return _result(rid, {"content": [{"type": "text", "text": text}]})


async def _tool_js_cancel(rid: Any, args: dict, pty: PtySession) -> dict:
    task_id = args.get("task_id", "")
    async with pty.async_tasks_lock:
        at = pty.async_tasks.pop(task_id, None)
    if at is None:
        return _result(
            rid,
            {
                "content": [{"type": "text", "text": f"No such task: {task_id}"}],
                "isError": True,
            },
        )
    at.task.cancel()
    return _result(rid, {"content": [{"type": "text", "text": f"Cancelled {task_id}"}]})


async def _tool_screenshot(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command, _spill

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    cmd_params: dict[str, Any] = {}
    if "selector" in args:
        cmd_params["selector"] = args["selector"]

    try:
        resp = await send_command(pty, "screenshot", timeout=10.0, **cmd_params)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Screenshot timed out")

    if err := _resp_error(rid, resp):
        return err

    data = resp.get("result", {}).get("data", "")  # type: ignore[union-attr]
    # Spill PNG to disk for reference
    _spill(base64.b64decode(data), "screenshot", "png")
    return _result(
        rid,
        {
            "content": [{"type": "image", "data": data, "mimeType": "image/png"}],
        },
    )


async def _tool_network(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command, _spill

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    # Pass filters to panel handler
    cmd_params: dict[str, Any] = {}
    for key in ("url", "method", "status", "since"):
        if key in args:
            cmd_params[key] = args[key]

    try:
        resp = await send_command(pty, "network", timeout=10.0, **cmd_params)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Network capture timed out")

    if err := _resp_error(rid, resp):
        return err

    result = resp.get("result", {})  # type: ignore[union-attr]
    count = result.get("count", 0)
    entries = result.get("entries", [])
    text = json.dumps(entries, indent=2)

    if len(text) > 4000:
        path = _spill(text, "network", "json")
        preview = text[:2000] + "\n\n… truncated …\n\n" + text[-500:]
        text = f"{count} requests captured\n\n{preview}\n\nFull HAR → {path}"
    else:
        text = f"{count} requests captured\n\n{text}"

    return _result(rid, {"content": [{"type": "text", "text": text}]})


def _format_console_entry(entry: dict) -> str:
    level = entry.get("level", "log").upper()
    text = entry.get("text", "")
    url = entry.get("url", "")
    stack = entry.get("stackTrace", "")
    parts = [f"[{level}] {text}"]
    if url:
        parts.append(f"  {url}")
    if stack and stack != text:
        # Only first line of stack to avoid very long outputs
        first_line = stack.split("\n")[0] if "\n" in stack else stack
        if first_line and first_line != text:
            parts.append(f"  {first_line}")
    return "\n".join(parts)


async def _tool_console(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command, _spill

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    cmd_params: dict[str, Any] = {}
    if "since" in args:
        cmd_params["since"] = args["since"]
    if "level" in args:
        cmd_params["level"] = args["level"]

    try:
        resp = await send_command(pty, "console", timeout=5.0, **cmd_params)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Console fetch timed out")

    if err := _resp_error(rid, resp):
        return err

    result = resp.get("result", {})  # type: ignore[union-attr]
    entries = result.get("entries", [])

    if not entries:
        return _result(
            rid, {"content": [{"type": "text", "text": "No console entries."}]}
        )

    formatted = "\n".join(_format_console_entry(e) for e in entries)

    if len(formatted) > 4000:
        path = _spill(formatted, "console", "json")
        preview = formatted[:2000] + "\n\n… truncated …\n\n" + formatted[-500:]
        formatted = f"{preview}\n\nFull console → {path}"

    return _result(rid, {"content": [{"type": "text", "text": formatted}]})


async def _tool_watch(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    url_pattern = args.get("url_pattern", "")
    watch_id = await pty.alloc_watch_id()
    pty.watchers[watch_id] = url_pattern

    try:
        await send_command(
            pty, "register_watcher", timeout=5.0, wid=watch_id, pattern=url_pattern
        )
    except asyncio.TimeoutError:
        pty.watchers.pop(watch_id, None)
        return _error(rid, -32000, "Watcher registration timed out")

    return _result(
        rid, {"content": [{"type": "text", "text": f"watch_id: {watch_id}"}]}
    )


async def _tool_watch_cancel(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command

    watch_id = args.get("watch_id", "")
    pty.watchers.pop(watch_id, None)

    if not pty.clients:
        return _result(
            rid,
            {"content": [{"type": "text", "text": f"Cancelled {watch_id} (no panel)"}]},
        )

    try:
        await send_command(pty, "unregister_watcher", timeout=5.0, wid=watch_id)
    except asyncio.TimeoutError:
        pass  # Best-effort unregister

    return _result(
        rid, {"content": [{"type": "text", "text": f"Cancelled {watch_id}"}]}
    )


def _format_mutation_result(rid: Any, resp: dict) -> dict:
    """Shared formatter for mutation tools (click/type/navigate)."""
    if err := _resp_error(rid, resp):
        return err
    r = resp.get("result", {})
    parts = [f"url: {r.get('url', '?')} (settled in {r.get('settleMs', '?')}ms)\n"]
    if r.get("tree"):
        parts.append(f"tree ({r.get('nodeCount', '?')} nodes):")
        parts.append(r["tree"])
        parts.append("")
    network = r.get("network", [])
    if network:
        parts.append(f"network ({len(network)} requests):")
        for entry in network:
            parts.append(
                f"  {entry.get('method', '?')} {entry.get('status', '?')} "
                f"{entry.get('url', '?')} {entry.get('time', '?')}ms {entry.get('size', '?')}"
            )
    return _result(rid, {"content": [{"type": "text", "text": "\n".join(parts)}]})


async def _tool_tree(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    try:
        resp = await send_command(pty, "tree", timeout=10.0, **args)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Tree capture timed out")

    if err := _resp_error(rid, resp):
        return err
    r = resp.get("result", {})
    text = r.get("text", "")
    return _result(rid, {"content": [{"type": "text", "text": text}]})


async def _tool_click(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    try:
        resp = await send_command(pty, "click", timeout=15.0, **args)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Click timed out")

    return _format_mutation_result(rid, resp)


async def _tool_type(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    try:
        resp = await send_command(pty, "type", timeout=15.0, **args)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Type timed out")

    return _format_mutation_result(rid, resp)


async def _tool_navigate(rid: Any, args: dict, pty: PtySession) -> dict:
    from devpanel.server import send_command

    if not pty.clients:
        return _error(rid, -32000, "No panel connected — open DevTools")

    try:
        resp = await send_command(pty, "navigate", timeout=20.0, **args)
    except asyncio.TimeoutError:
        return _error(rid, -32000, "Navigate timed out")

    return _format_mutation_result(rid, resp)
