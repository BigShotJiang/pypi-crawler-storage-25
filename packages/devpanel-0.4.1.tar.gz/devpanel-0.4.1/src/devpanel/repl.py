"""repld init script: starts devpanel daemon on repld's asyncio loop.

Usage:
    repld --socket $XDG_RUNTIME_DIR/devpanel/repld.sock --init src/devpanel/repl.py

All daemon state is accessible via repld exec():
    exec("list(_sessions.keys())")
    exec("[s.stack for s in _sessions.values()]")
"""

from devpanel.server import run, _sessions, PtySession  # noqa: F401

port = await run()  # noqa: F704  # top-level await — repld init script runs in kernel's loop
print(f"devpanel daemon on :{port}")
