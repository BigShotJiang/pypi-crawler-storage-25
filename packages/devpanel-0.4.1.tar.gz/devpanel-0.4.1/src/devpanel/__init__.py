"""DevPanel CLI entry point."""

from __future__ import annotations

import asyncio
import sys


def main() -> None:
    args = sys.argv[1:]

    # Native messaging mode: Chrome invokes as `devpanel chrome-extension://ID/`
    if args and args[0].startswith("chrome-extension://"):
        from devpanel.nativemsg import serve

        serve()
        return

    cmd = args[0] if args else "start"

    if cmd == "start":
        port = 0
        for i, a in enumerate(args[1:], 1):
            if a == "--port" and i + 1 < len(args):
                port = int(args[i + 1])
        _run_server(port)

    elif cmd == "install":
        ext_id = None
        for i, a in enumerate(args[1:], 1):
            if a.startswith("--extension-id="):
                ext_id = a.split("=", 1)[1]
            elif a == "--extension-id" and i + 1 < len(args):
                ext_id = args[i + 1]
        from devpanel.install import install

        install(ext_id)

    else:
        print("Usage: devpanel [start|install]", file=sys.stderr)
        sys.exit(1)


def _run_server(port: int) -> None:
    async def _main() -> None:
        from devpanel.server import run

        actual_port = await run(port)
        if sys.stdout.isatty():
            print(f"devpanel daemon listening on http://127.0.0.1:{actual_port}")
            print(f"  WebSocket PTY: ws://127.0.0.1:{actual_port}/ws")
            print(f"  MCP:           http://127.0.0.1:{actual_port}/mcp")
            print(f"  Controls:      http://127.0.0.1:{actual_port}/controls")
            print(f"  Stack:         http://127.0.0.1:{actual_port}/stack")
        # Block forever
        await asyncio.Event().wait()

    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        pass
