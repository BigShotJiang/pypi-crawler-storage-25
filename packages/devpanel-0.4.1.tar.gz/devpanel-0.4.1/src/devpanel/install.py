"""Register native messaging host manifest for Chrome/Chromium."""

from __future__ import annotations

import json
import sys
from pathlib import Path

NMH_NAME = "dev.devpanel.pty"

NMH_DIRS = [
    Path.home() / ".config" / "google-chrome" / "NativeMessagingHosts",
    Path.home() / ".config" / "chromium" / "NativeMessagingHosts",
]


def _find_binary() -> str:
    """Find the devpanel binary path."""
    import shutil

    path = shutil.which("devpanel")
    if path:
        return path
    print(
        "Error: 'devpanel' not found in PATH. Install with: uv tool install devpanel",
        file=sys.stderr,
    )
    sys.exit(1)


def _extension_path() -> Path | None:
    """Find the bundled extension directory."""
    # Check package data location (uv tool install)
    data_dir = Path(sys.prefix) / "share" / "devpanel" / "extension"
    if data_dir.is_dir():
        return data_dir
    # Check source tree (dev mode)
    src_ext = Path(__file__).parent / "extension"
    if src_ext.is_dir():
        return src_ext
    return None


def install(extension_id: str | None = None) -> None:
    binary = _find_binary()

    manifest = {
        "name": NMH_NAME,
        "description": "DevPanel PTY daemon",
        "type": "stdio",
        "path": binary,
    }

    if extension_id:
        manifest["allowed_origins"] = [f"chrome-extension://{extension_id}/"]
    else:
        print(
            "Warning: no --extension-id provided, manifest will need manual editing",
            file=sys.stderr,
        )
        manifest["allowed_origins"] = ["chrome-extension://EXTENSION_ID_HERE/"]

    for nmh_dir in NMH_DIRS:
        nmh_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = nmh_dir / f"{NMH_NAME}.json"
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        print(f"Wrote {manifest_path}")

    ext_path = _extension_path()
    if ext_path:
        print(f"\nExtension path (load unpacked in chrome://extensions):\n  {ext_path}")
    else:
        print(
            "\nExtension files not found — build with 'make build' first",
            file=sys.stderr,
        )
