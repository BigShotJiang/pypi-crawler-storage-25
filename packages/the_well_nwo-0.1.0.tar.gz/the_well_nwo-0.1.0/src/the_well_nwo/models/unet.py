"""U-Net model implementation for acoustic scattering."""

from typing import Any, Dict

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..types import PredictionResult, ModelInfo


class UNetModel(nn.Module):
    """U-Net architecture for acoustic wave propagation.
    
    Adapted for acoustic scattering predictions from The Well dataset.
    """
    
    def __init__(self, model_info: Dict[str, Any]):
        super().__init__()
        self.model_info = model_info
        
        # Encoder
        self.enc1 = self._make_encoder_block(1, 64)
        self.enc2 = self._make_encoder_block(64, 128)
        self.enc3 = self._make_encoder_block(128, 256)
        self.enc4 = self._make_encoder_block(256, 512)
        
        # Bottleneck
        self.bottleneck = self._make_encoder_block(512, 1024)
        
        # Decoder
        self.dec4 = self._make_decoder_block(1024, 512)
        self.dec3 = self._make_decoder_block(512, 256)
        self.dec2 = self._make_decoder_block(256, 128)
        self.dec1 = self._make_decoder_block(128, 64)
        
        # Output
        self.output = nn.Conv2d(64, 1, kernel_size=1)
    
    def _make_encoder_block(self, in_channels: int, out_channels: int) -> nn.Module:
        """Create encoder block."""
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
    
    def _make_decoder_block(self, in_channels: int, out_channels: int) -> nn.Module:
        """Create decoder block."""
        return nn.Sequential(
            nn.ConvTranspose2d(in_channels, out_channels, 2, stride=2),
            nn.Conv2d(out_channels * 2, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass."""
        # Encoder
        e1 = self.enc1(x)
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        e4 = self.enc4(F.max_pool2d(e3, 2))
        
        # Bottleneck
        b = self.bottleneck(F.max_pool2d(e4, 2))
        
        # Decoder with skip connections
        d4 = self.dec4(b)
        d4 = torch.cat([d4, e4], dim=1)
        
        d3 = self.dec3(d4)
        d3 = torch.cat([d3, e3], dim=1)
        
        d2 = self.dec2(d3)
        d2 = torch.cat([d2, e2], dim=1)
        
        d1 = self.dec1(d2)
        d1 = torch.cat([d1, e1], dim=1)
        
        # Output
        return self.output(d1)
    
    def preprocess(self, scenario: str, kwargs: Dict[str, Any]) -> torch.Tensor:
        """Preprocess input for acoustic model."""
        if scenario == "sonar_navigation":
            # Create sonar source map
            grid_size = 128
            sonar_map = torch.zeros(1, 1, grid_size, grid_size)
            
            # Add sonar source at robot position
            robot_pos = kwargs.get("robot_state", {}).get("position", [0, 0, 0])
            x_idx = int((robot_pos[0] + 50) / 100 * grid_size)
            y_idx = int((robot_pos[1] + 50) / 100 * grid_size)
            
            if 0 <= x_idx < grid_size and 0 <= y_idx < grid_size:
                sonar_map[0, 0, y_idx, x_idx] = 1.0
            
            return sonar_map
        
        raise ValueError(f"Unknown scenario: {scenario}")
    
    def postprocess(
        self,
        output: torch.Tensor,
        scenario: str,
        kwargs: Dict[str, Any],
    ) -> PredictionResult:
        """Postprocess acoustic model output."""
        pred_np = output.detach().cpu().numpy()
        
        if scenario == "sonar_navigation":
            return PredictionResult(
                prediction=pred_np,
                latency_ms=0.0,
                confidence=0.90,
                echo_map=pred_np[0, 0],
                obstacle_locations=self._detect_obstacles(pred_np),
                confidence_map=self._compute_confidence(pred_np),
                optimal_heading=self._compute_heading(pred_np, kwargs),
            )
        
        return PredictionResult(
            prediction=pred_np,
            latency_ms=0.0,
            confidence=0.85,
        )
    
    def _detect_obstacles(self, pred: torch.Tensor) -> list:
        """Detect obstacles from sonar returns."""
        # Threshold-based detection
        threshold = 0.5
        obstacles = []
        
        # Find local maxima above threshold
        for i in range(pred.shape[2]):
            for j in range(pred.shape[3]):
                if pred[0, 0, i, j] > threshold:
                    obstacles.append({
                        "position": [j, i, 0],
                        "confidence": float(pred[0, 0, i, j]),
                    })
        
        return obstacles[:10]  # Return top 10 obstacles
    
    def _compute_confidence(self, pred: torch.Tensor) -> torch.Tensor:
        """Compute confidence map."""
        return torch.sigmoid(pred).numpy()[0, 0]
    
    def _compute_heading(self, pred: torch.Tensor, kwargs: dict) -> float:
        """Compute optimal heading."""
        # Find direction with least obstacles
        return 0.0  # Placeholder
    
    def get_info(self) -> ModelInfo:
        """Get model information."""
        return ModelInfo(
            name=self.model_info.get("dataset", "unknown"),
            version="1.0.0",
            dataset=self.model_info.get("dataset", "unknown"),
            parameters=self.model_info.get("parameters", 0),
            input_shape=self.model_info.get("input_shape", (0,)),
            output_shape=self.model_info.get("output_shape", (0,)),
            latency_ms=self.model_info.get("latency_ms", 0.0),
            architecture=self.model_info.get("architecture", "unknown"),
            description=self.model_info.get("description", ""),
        )