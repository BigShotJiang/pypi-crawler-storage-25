"""Model registry and loader for The Well pre-trained models."""

from typing import Dict, List, Optional
import torch
import torch.nn as nn

from ..exceptions import ModelNotFoundError


# Model registry
_MODEL_REGISTRY: Dict[str, Dict] = {
    "FNO-fluid_dynamics": {
        "architecture": "FNO",
        "dataset": "fluid_dynamics",
        "parameters": 12_500_000,
        "input_shape": (64, 64, 64),
        "output_shape": (64, 64, 64),
        "latency_ms": 15,
        "description": "Fluid dynamics for drones and underwater robots",
    },
    "FNO-active_matter": {
        "architecture": "FNO",
        "dataset": "active_matter",
        "parameters": 8_200_000,
        "input_shape": (None, 6),  # Variable number of agents
        "output_shape": (None, 6),
        "latency_ms": 12,
        "description": "Swarm coordination and active matter dynamics",
    },
    "U-Net-acoustic_scattering": {
        "architecture": "U-Net",
        "dataset": "acoustic_scattering",
        "parameters": 15_700_000,
        "input_shape": (128, 128),
        "output_shape": (128, 128),
        "latency_ms": 18,
        "description": "Sonar navigation and acoustic imaging",
    },
    "FNO-magneto_hydrodynamics": {
        "architecture": "FNO",
        "dataset": "magneto_hydrodynamics",
        "parameters": 18_300_000,
        "input_shape": (64, 64, 64, 4),
        "output_shape": (64, 64, 64, 4),
        "latency_ms": 20,
        "description": "Space robotics and magnetic manipulation",
    },
    "TFNO-turbulence": {
        "architecture": "TFNO",
        "dataset": "turbulence",
        "parameters": 25_100_000,
        "input_shape": (128, 128, 128),
        "output_shape": (128, 128, 128),
        "latency_ms": 22,
        "description": "High-speed navigation in turbulent flows",
    },
}


def list_models() -> List[str]:
    """List all available model IDs."""
    return list(_MODEL_REGISTRY.keys())


def get_model_info(model_id: str) -> Dict:
    """Get information about a model."""
    if model_id not in _MODEL_REGISTRY:
        raise ModelNotFoundError(model_id, list_models())
    return _MODEL_REGISTRY[model_id]


def get_model(
    model_id: str,
    device: torch.device,
    precision: str = "float32",
    cache_dir: Optional[str] = None,
) -> nn.Module:
    """Load a pre-trained model.
    
    Args:
        model_id: Model identifier
        device: Device to load model on
        precision: Numerical precision
        cache_dir: Directory to cache models
        
    Returns:
        Loaded PyTorch model
    """
    if model_id not in _MODEL_REGISTRY:
        raise ModelNotFoundError(model_id, list_models())
    
    model_info = _MODEL_REGISTRY[model_id]
    architecture = model_info["architecture"]
    
    # Import architecture-specific model
    if architecture == "FNO":
        from .fno import FNOModel
        model = FNOModel(model_info)
    elif architecture == "TFNO":
        from .tfno import TFNOModel
        model = TFNOModel(model_info)
    elif architecture == "U-Net":
        from .unet import UNetModel
        model = UNetModel(model_info)
    else:
        raise ModelNotFoundError(f"Unknown architecture: {architecture}")
    
    # Load weights (placeholder - actual loading would download from The Well)
    # model.load_state_dict(torch.load(weights_path, map_location=device))
    
    model = model.to(device)
    
    if precision == "float16":
        model = model.half()
    
    model.eval()
    
    return model