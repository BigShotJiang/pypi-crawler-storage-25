"""Type definitions for The Well × NWO Robotics integration."""

from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
import numpy as np


@dataclass
class PredictionResult:
    """Result from a physics prediction."""
    
    prediction: np.ndarray
    latency_ms: float
    confidence: float
    turbulence_zones: Optional[List[Dict[str, Any]]] = None
    optimal_path: Optional[List[List[float]]] = None
    drag_coefficient: Optional[float] = None
    pressure_field: Optional[np.ndarray] = None
    coordinated_commands: Optional[Dict[str, str]] = None
    formation_stability: Optional[float] = None
    collision_risk: Optional[List[Tuple[str, str]]] = None
    emergent_behaviors: Optional[List[str]] = None
    echo_map: Optional[np.ndarray] = None
    obstacle_locations: Optional[List[Dict[str, Any]]] = None
    confidence_map: Optional[np.ndarray] = None
    optimal_heading: Optional[float] = None
    magnetic_forces: Optional[List[float]] = None
    plasma_density: Optional[float] = None
    docking_trajectory: Optional[List[List[float]]] = None
    stability_analysis: Optional[Dict[str, Any]] = None
    turbulence_intensity: Optional[np.ndarray] = None
    gust_prediction: Optional[List[Dict[str, Any]]] = None
    safe_corridors: Optional[List[Dict[str, Any]]] = None
    energy_optimal_path: Optional[List[List[float]]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_context(self) -> Dict[str, Any]:
        """Convert prediction to physics context for NWO API."""
        context = {
            "confidence": self.confidence,
            "latency_ms": self.latency_ms,
        }
        
        # Add available fields
        if self.turbulence_zones is not None:
            context["turbulence_zones"] = self.turbulence_zones
        if self.optimal_path is not None:
            context["optimal_path"] = self.optimal_path
        if self.drag_coefficient is not None:
            context["drag_coefficient"] = self.drag_coefficient
        if self.coordinated_commands is not None:
            context["coordinated_commands"] = self.coordinated_commands
        if self.obstacle_locations is not None:
            context["obstacle_locations"] = self.obstacle_locations
        if self.optimal_heading is not None:
            context["optimal_heading"] = self.optimal_heading
        if self.magnetic_forces is not None:
            context["magnetic_forces"] = self.magnetic_forces
        if self.docking_trajectory is not None:
            context["docking_trajectory"] = self.docking_trajectory
        if self.gust_prediction is not None:
            context["gust_prediction"] = self.gust_prediction
        if self.safe_corridors is not None:
            context["safe_corridors"] = self.safe_corridors
        if self.energy_optimal_path is not None:
            context["energy_optimal_path"] = self.energy_optimal_path
            
        return context


@dataclass
class ModelInfo:
    """Information about a loaded model."""
    
    name: str
    version: str
    dataset: str
    parameters: int
    input_shape: Tuple[int, ...]
    output_shape: Tuple[int, ...]
    latency_ms: float
    architecture: str
    description: str = ""


@dataclass
class RobotState:
    """Current state of a robot."""
    
    robot_id: str
    position: List[float]
    velocity: List[float]
    orientation: List[float]
    battery_percent: float
    status: str
    joint_angles: Optional[List[float]] = None
    timestamp: Optional[float] = None


@dataclass
class CommandResponse:
    """Response from a robot command."""
    
    success: bool
    execution_id: str
    status: str
    message: str
    estimated_duration_ms: Optional[int] = None
    physics_context: Optional[Dict[str, Any]] = None


@dataclass
class HealthStatus:
    """API health status."""
    
    status: str
    version: str
    uptime_seconds: Optional[int] = None
    models_loaded: Optional[List[str]] = None


# Type alias for physics context
PhysicsContext = Dict[str, Any]