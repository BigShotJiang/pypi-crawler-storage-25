"""NWO Robotics API client."""

from typing import Any, Dict, Optional
import requests

from .types import RobotState, CommandResponse, HealthStatus
from .exceptions import NWOAPIError


class NWOClient:
    """Client for NWO Robotics API.
    
    Provides methods to interact with the NWO Robotics API,
    including sending commands and querying robot state.
    
    Args:
        api_key: NWO Robotics API key
        base_url: Base URL for NWO API
        timeout: Request timeout in seconds
        
    Example:
        >>> client = NWOClient(api_key="your_key")
        >>> response = client.send_command(
        ...     robot_id="drone_01",
        ...     command="navigate_through_turbulence",
        ...     physics_context={...}
        ... )
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://nwo.capital/webapp",
        timeout: int = 30,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        })
    
    def send_command(
        self,
        robot_id: str,
        command: str,
        physics_context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> CommandResponse:
        """Send a command to a robot with optional physics context.
        
        Args:
            robot_id: Robot identifier
            command: Natural language command
            physics_context: Physics prediction context
            **kwargs: Additional command parameters
            
        Returns:
            CommandResponse with execution details
            
        Raises:
            NWOAPIError: If API request fails
        """
        url = f"{self.base_url}/api-robotics.php"
        
        payload = {
            "action": "inference",
            "robot_id": robot_id,
            "instruction": command,
        }
        
        if physics_context:
            payload["physics_context"] = physics_context
            
        payload.update(kwargs)
        
        try:
            response = self.session.post(
                url,
                json=payload,
                timeout=self.timeout,
            )
            response.raise_for_status()
            data = response.json()
            
            return CommandResponse(
                success=data.get("success", False),
                execution_id=data.get("execution_id", ""),
                status=data.get("status", "unknown"),
                message=data.get("message", ""),
                estimated_duration_ms=data.get("estimated_duration_ms"),
                physics_context=physics_context,
            )
            
        except requests.exceptions.RequestException as e:
            raise NWOAPIError(
                message=str(e),
                status_code=getattr(e.response, "status_code", None),
            ) from e
    
    def query_state(self, robot_id: str) -> RobotState:
        """Query current robot state.
        
        Args:
            robot_id: Robot identifier
            
        Returns:
            RobotState with current robot information
        """
        url = f"{self.base_url}/api-robotics.php"
        
        payload = {
            "action": "query_state",
            "agent_id": robot_id,
        }
        
        try:
            response = self.session.get(
                url,
                params=payload,
                timeout=self.timeout,
            )
            response.raise_for_status()
            data = response.json()
            
            return RobotState(
                robot_id=robot_id,
                position=data.get("position", [0, 0, 0]),
                velocity=data.get("velocity", [0, 0, 0]),
                orientation=data.get("orientation", [1, 0, 0, 0]),
                battery_percent=data.get("battery_percent", 100),
                status=data.get("status", "unknown"),
                joint_angles=data.get("joint_angles"),
            )
            
        except requests.exceptions.RequestException as e:
            raise NWOAPIError(message=str(e)) from e
    
    def health_check(self) -> HealthStatus:
        """Check API health status.
        
        Returns:
            HealthStatus with API information
        """
        url = f"{self.base_url}/api-agent-discovery.php"
        
        try:
            response = self.session.get(
                url,
                params={"action": "health"},
                timeout=self.timeout,
            )
            response.raise_for_status()
            data = response.json()
            
            return HealthStatus(
                status=data.get("status", "unknown"),
                version=data.get("version", "unknown"),
                uptime_seconds=data.get("uptime_seconds"),
                models_loaded=data.get("models_loaded"),
            )
            
        except requests.exceptions.RequestException as e:
            raise NWOAPIError(message=str(e)) from e


class AsyncNWOClient:
    """Async version of NWOClient.
    
    Provides async/await support for non-blocking API operations.
    
    Example:
        >>> client = AsyncNWOClient(api_key="your_key")
        >>> response = await client.send_command(...)
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://nwo.capital/webapp",
        timeout: int = 30,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client = None
    
    async def _get_client(self):
        """Get or create aiohttp client."""
        if self._client is None:
            import aiohttp
            self._client = aiohttp.ClientSession(
                headers={
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                }
            )
        return self._client
    
    async def send_command(
        self,
        robot_id: str,
        command: str,
        physics_context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> CommandResponse:
        """Async send command."""
        client = await self._get_client()
        
        url = f"{self.base_url}/api-robotics.php"
        payload = {
            "action": "inference",
            "robot_id": robot_id,
            "instruction": command,
        }
        
        if physics_context:
            payload["physics_context"] = physics_context
        payload.update(kwargs)
        
        try:
            async with client.post(url, json=payload, timeout=self.timeout) as response:
                data = await response.json()
                return CommandResponse(
                    success=data.get("success", False),
                    execution_id=data.get("execution_id", ""),
                    status=data.get("status", "unknown"),
                    message=data.get("message", ""),
                    estimated_duration_ms=data.get("estimated_duration_ms"),
                    physics_context=physics_context,
                )
        except Exception as e:
            raise NWOAPIError(message=str(e)) from e
    
    async def query_state(self, robot_id: str) -> RobotState:
        """Async query state."""
        client = await self._get_client()
        
        url = f"{self.base_url}/api-robotics.php"
        params = {"action": "query_state", "agent_id": robot_id}
        
        try:
            async with client.get(url, params=params, timeout=self.timeout) as response:
                data = await response.json()
                return RobotState(
                    robot_id=robot_id,
                    position=data.get("position", [0, 0, 0]),
                    velocity=data.get("velocity", [0, 0, 0]),
                    orientation=data.get("orientation", [1, 0, 0, 0]),
                    battery_percent=data.get("battery_percent", 100),
                    status=data.get("status", "unknown"),
                    joint_angles=data.get("joint_angles"),
                )
        except Exception as e:
            raise NWOAPIError(message=str(e)) from e
    
    async def close(self):
        """Close async client."""
        if self._client:
            await self._client.close()
            self._client = None
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()