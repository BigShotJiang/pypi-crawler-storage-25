"""The Well × NWO Robotics Integration.

Physics-informed robotics control using pre-trained surrogate models
from The Well dataset (Polymathic AI).
"""

__version__ = "0.1.0"
__author__ = "NWO Robotics"
__email__ = "support@nworobotics.cloud"

from .predictor import PhysicsPredictor, AsyncPhysicsPredictor
from .client import NWOClient, AsyncNWOClient
from .types import (
    PredictionResult,
    ModelInfo,
    RobotState,
    CommandResponse,
    PhysicsContext,
)
from .exceptions import (
    PhysicsPredictionError,
    NWOAPIError,
    ModelNotFoundError,
)

__all__ = [
    "PhysicsPredictor",
    "AsyncPhysicsPredictor",
    "NWOClient",
    "AsyncNWOClient",
    "PredictionResult",
    "ModelInfo",
    "RobotState",
    "CommandResponse",
    "PhysicsContext",
    "PhysicsPredictionError",
    "NWOAPIError",
    "ModelNotFoundError",
]