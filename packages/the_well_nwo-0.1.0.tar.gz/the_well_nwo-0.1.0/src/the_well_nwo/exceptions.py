"""Custom exceptions for The Well × NWO Robotics integration."""


class TheWellNWOError(Exception):
    """Base exception for the package."""
    pass


class PhysicsPredictionError(TheWellNWOError):
    """Raised when physics prediction fails."""
    
    def __init__(self, message: str, model_id: str = None, scenario: str = None):
        super().__init__(message)
        self.model_id = model_id
        self.scenario = scenario


class NWOAPIError(TheWellNWOError):
    """Raised when NWO API request fails."""
    
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ModelNotFoundError(TheWellNWOError):
    """Raised when requested model is not found."""
    
    def __init__(self, model_id: str, available_models: list = None):
        message = f"Model '{model_id}' not found"
        if available_models:
            message += f". Available models: {', '.join(available_models)}"
        super().__init__(message)
        self.model_id = model_id
        self.available_models = available_models


class ConfigurationError(TheWellNWOError):
    """Raised when configuration is invalid."""
    pass


class CacheError(TheWellNWOError):
    """Raised when cache operation fails."""
    pass