"""Physics predictor using The Well pre-trained models."""

import time
from typing import Any, Dict, List, Optional, Union

import numpy as np
import torch
import torch.nn as nn

from .types import PredictionResult, ModelInfo
from .exceptions import PhysicsPredictionError, ModelNotFoundError
from .models import get_model, list_models


class PhysicsPredictor:
    """Main class for physics predictions using pre-trained models.
    
    This class loads pre-trained models from The Well dataset and provides
    an interface for making physics predictions for robotics applications.
    
    Args:
        model: Model identifier (e.g., "FNO-fluid_dynamics")
        device: Device to run on ("auto", "cpu", "cuda", etc.)
        precision: Numerical precision ("float32", "float16")
        cache_dir: Directory to cache downloaded models
        
    Example:
        >>> predictor = PhysicsPredictor(model="FNO-fluid_dynamics")
        >>> result = predictor.predict(
        ...     scenario="fluid_interaction",
        ...     robot_state={"position": [0, 0, 10], "velocity": [5, 0, 0]}
        ... )
        >>> print(f"Latency: {result.latency_ms}ms")
    """
    
    def __init__(
        self,
        model: str,
        device: str = "auto",
        precision: str = "float32",
        cache_dir: Optional[str] = None,
    ):
        self.model_id = model
        self.device = self._get_device(device)
        self.precision = precision
        self.cache_dir = cache_dir
        
        # Load model
        self.model = self._load_model()
        self.model_info = self._get_model_info()
        
    def _get_device(self, device: str) -> torch.device:
        """Determine the device to use."""
        if device == "auto":
            return torch.device("cuda" if torch.cuda.is_available() else "cpu")
        return torch.device(device)
    
    def _load_model(self) -> nn.Module:
        """Load the pre-trained model."""
        try:
            model = get_model(
                self.model_id,
                device=self.device,
                precision=self.precision,
                cache_dir=self.cache_dir,
            )
            return model
        except Exception as e:
            available = list_models()
            raise ModelNotFoundError(self.model_id, available) from e
    
    def _get_model_info(self) -> ModelInfo:
        """Get information about the loaded model."""
        return self.model.get_info()
    
    def predict(self, scenario: str, **kwargs) -> PredictionResult:
        """Make a physics prediction.
        
        Args:
            scenario: Scenario type (e.g., "fluid_interaction", "swarm_coordination")
            **kwargs: Scenario-specific parameters
            
        Returns:
            PredictionResult with prediction outputs and metadata
            
        Raises:
            PhysicsPredictionError: If prediction fails
        """
        start_time = time.time()
        
        try:
            # Preprocess input
            input_data = self._preprocess_input(scenario, kwargs)
            
            # Run inference
            with torch.no_grad():
                output = self.model(input_data)
            
            # Postprocess output
            result = self._postprocess_output(output, scenario, kwargs)
            
            # Calculate latency
            latency_ms = (time.time() - start_time) * 1000
            result.latency_ms = latency_ms
            
            return result
            
        except Exception as e:
            raise PhysicsPredictionError(
                message=str(e),
                model_id=self.model_id,
                scenario=scenario,
            ) from e
    
    def predict_batch(self, scenarios: List[Dict[str, Any]]) -> List[PredictionResult]:
        """Make batch predictions for multiple scenarios.
        
        Args:
            scenarios: List of scenario dictionaries
            
        Returns:
            List of PredictionResult objects
        """
        results = []
        for scenario_data in scenarios:
            scenario = scenario_data.pop("scenario")
            result = self.predict(scenario, **scenario_data)
            results.append(result)
        return results
    
    def _preprocess_input(self, scenario: str, kwargs: Dict[str, Any]) -> torch.Tensor:
        """Preprocess input data for the model."""
        # Implementation depends on model type
        return self.model.preprocess(scenario, kwargs)
    
    def _postprocess_output(
        self,
        output: torch.Tensor,
        scenario: str,
        kwargs: Dict[str, Any],
    ) -> PredictionResult:
        """Postprocess model output into PredictionResult."""
        # Implementation depends on model type
        return self.model.postprocess(output, scenario, kwargs)
    
    def get_model_info(self) -> ModelInfo:
        """Get information about the loaded model.
        
        Returns:
            ModelInfo with model metadata
        """
        return self.model_info


class AsyncPhysicsPredictor:
    """Async version of PhysicsPredictor.
    
    Provides the same functionality as PhysicsPredictor but with
    async/await support for non-blocking operations.
    
    Example:
        >>> predictor = AsyncPhysicsPredictor(model="FNO-fluid_dynamics")
        >>> result = await predictor.predict(...)
    """
    
    def __init__(
        self,
        model: str,
        device: str = "auto",
        precision: str = "float32",
        cache_dir: Optional[str] = None,
    ):
        self._predictor = PhysicsPredictor(model, device, precision, cache_dir)
    
    async def predict(self, scenario: str, **kwargs) -> PredictionResult:
        """Async prediction."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self._predictor.predict(scenario, **kwargs)
        )
    
    async def predict_batch(self, scenarios: List[Dict[str, Any]]) -> List[PredictionResult]:
        """Async batch prediction."""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self._predictor.predict_batch(scenarios)
        )
    
    def get_model_info(self) -> ModelInfo:
        """Get model info."""
        return self._predictor.get_model_info()