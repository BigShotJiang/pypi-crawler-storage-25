"""Utility functions for The Well × NWO Robotics integration."""

import os
from typing import List, Optional
from pathlib import Path

from .exceptions import CacheError
from .models import list_models as _list_models, get_model_info


def download_model(model_id: str, cache_dir: Optional[str] = None) -> str:
    """Download a pre-trained model.
    
    Args:
        model_id: Model identifier
        cache_dir: Directory to cache model (default: ~/.cache/the_well_nwo)
        
    Returns:
        Path to downloaded model
        
    Raises:
        ModelNotFoundError: If model doesn't exist
        CacheError: If download fails
    """
    if cache_dir is None:
        cache_dir = os.path.expanduser("~/.cache/the_well_nwo")
    
    cache_path = Path(cache_dir)
    cache_path.mkdir(parents=True, exist_ok=True)
    
    # Get model info
    info = get_model_info(model_id)
    
    # Construct model path
    model_path = cache_path / f"{model_id}.pt"
    
    if model_path.exists():
        print(f"Model {model_id} already cached at {model_path}")
        return str(model_path)
    
    # Download model (placeholder - actual implementation would download from The Well)
    print(f"Downloading model {model_id}...")
    print(f"Dataset: {info['dataset']}")
    print(f"Architecture: {info['architecture']}")
    print(f"Parameters: {info['parameters']:,}")
    
    # In real implementation, download from The Well repository
    # For now, create a placeholder file
    try:
        model_path.touch()
        print(f"Model downloaded to {model_path}")
        return str(model_path)
    except Exception as e:
        raise CacheError(f"Failed to download model: {e}") from e


def list_available_models() -> List[dict]:
    """List all available models with their information.
    
    Returns:
        List of model information dictionaries
    """
    models = []
    for model_id in _list_models():
        info = get_model_info(model_id)
        models.append({
            "id": model_id,
            "architecture": info["architecture"],
            "dataset": info["dataset"],
            "parameters": info["parameters"],
            "latency_ms": info["latency_ms"],
            "description": info["description"],
        })
    return models


def clear_cache(cache_dir: Optional[str] = None) -> None:
    """Clear downloaded model cache.
    
    Args:
        cache_dir: Cache directory (default: ~/.cache/the_well_nwo)
    """
    if cache_dir is None:
        cache_dir = os.path.expanduser("~/.cache/the_well_nwo")
    
    cache_path = Path(cache_dir)
    
    if not cache_path.exists():
        print("Cache directory doesn't exist")
        return
    
    # Remove all .pt files
    count = 0
    for model_file in cache_path.glob("*.pt"):
        try:
            model_file.unlink()
            count += 1
        except Exception as e:
            print(f"Failed to remove {model_file}: {e}")
    
    print(f"Cleared {count} models from cache")


def get_cache_size(cache_dir: Optional[str] = None) -> str:
    """Get total size of model cache.
    
    Args:
        cache_dir: Cache directory (default: ~/.cache/the_well_nwo)
        
    Returns:
        Human-readable cache size
    """
    if cache_dir is None:
        cache_dir = os.path.expanduser("~/.cache/the_well_nwo")
    
    cache_path = Path(cache_dir)
    
    if not cache_path.exists():
        return "0 B"
    
    total_size = sum(f.stat().st_size for f in cache_path.glob("*.pt") if f.is_file())
    
    # Convert to human-readable
    for unit in ["B", "KB", "MB", "GB"]:
        if total_size < 1024:
            return f"{total_size:.2f} {unit}"
        total_size /= 1024
    
    return f"{total_size:.2f} TB"


def print_model_table():
    """Print a formatted table of available models."""
    models = list_available_models()
    
    print("\n" + "=" * 100)
    print(f"{'Model ID':<30} {'Architecture':<15} {'Parameters':<15} {'Latency':<10} {'Description'}")
    print("=" * 100)
    
    for model in models:
        params = f"{model['parameters']:,}"
        latency = f"{model['latency_ms']}ms"
        print(f"{model['id']:<30} {model['architecture']:<15} {params:<15} {latency:<10} {model['description']}")
    
    print("=" * 100)
    print(f"\nTotal models: {len(models)}")
    print(f"Cache size: {get_cache_size()}")