"""Tests for PhysicsPredictor."""

import pytest
import numpy as np
import torch

from the_well_nwo import PhysicsPredictor
from the_well_nwo.exceptions import ModelNotFoundError


class TestPhysicsPredictor:
    """Test suite for PhysicsPredictor."""
    
    def test_initialization(self):
        """Test predictor initialization."""
        predictor = PhysicsPredictor(model="FNO-fluid_dynamics")
        assert predictor.model_id == "FNO-fluid_dynamics"
        assert predictor.model is not None
        
    def test_invalid_model(self):
        """Test initialization with invalid model."""
        with pytest.raises(ModelNotFoundError):
            PhysicsPredictor(model="invalid_model")
    
    def test_predict(self):
        """Test prediction."""
        predictor = PhysicsPredictor(model="FNO-fluid_dynamics")
        
        result = predictor.predict(
            scenario="fluid_interaction",
            robot_state={
                "position": [0, 0, 10],
                "velocity": [5, 0, 0],
            }
        )
        
        assert result is not None
        assert result.latency_ms > 0
        assert 0 <= result.confidence <= 1
        assert result.prediction is not None
    
    def test_predict_batch(self):
        """Test batch prediction."""
        predictor = PhysicsPredictor(model="FNO-active_matter")
        
        scenarios = [
            {
                "scenario": "swarm_coordination",
                "robots": [
                    {"id": "bot_1", "position": [0, 0], "velocity": [1, 0]},
                ]
            },
            {
                "scenario": "swarm_coordination",
                "robots": [
                    {"id": "bot_1", "position": [5, 0], "velocity": [1, 0]},
                ]
            }
        ]
        
        results = predictor.predict_batch(scenarios)
        
        assert len(results) == 2
        for result in results:
            assert result.latency_ms > 0
            assert result.confidence > 0
    
    def test_get_model_info(self):
        """Test getting model info."""
        predictor = PhysicsPredictor(model="FNO-fluid_dynamics")
        
        info = predictor.get_model_info()
        
        assert info.name == "fluid_dynamics"
        assert info.architecture == "FNO"
        assert info.parameters > 0
        assert info.latency_ms > 0
    
    def test_to_context(self):
        """Test converting prediction to context."""
        predictor = PhysicsPredictor(model="FNO-fluid_dynamics")
        
        result = predictor.predict(
            scenario="fluid_interaction",
            robot_state={"position": [0, 0, 10], "velocity": [5, 0, 0]}
        )
        
        context = result.to_context()
        
        assert "confidence" in context
        assert "latency_ms" in context
        assert context["confidence"] == result.confidence