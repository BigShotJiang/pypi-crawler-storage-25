"""Tests for NWOClient."""

import pytest
from unittest.mock import Mock, patch

from the_well_nwo import NWOClient
from the_well_nwo.exceptions import NWOAPIError


class TestNWOClient:
    """Test suite for NWOClient."""
    
    def test_initialization(self):
        """Test client initialization."""
        client = NWOClient(api_key="test_key")
        assert client.api_key == "test_key"
        assert client.base_url == "https://nwo.capital/webapp"
        
    def test_custom_base_url(self):
        """Test initialization with custom base URL."""
        client = NWOClient(
            api_key="test_key",
            base_url="https://custom.nwo.capital"
        )
        assert client.base_url == "https://custom.nwo.capital"
    
    @patch('the_well_nwo.client.requests.Session')
    def test_send_command(self, mock_session):
        """Test sending command."""
        # Mock response
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "execution_id": "exec_123",
            "status": "accepted",
            "message": "Command accepted",
        }
        mock_response.raise_for_status = Mock()
        
        mock_session_instance = Mock()
        mock_session_instance.post.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        client = NWOClient(api_key="test_key")
        response = client.send_command(
            robot_id="drone_01",
            command="test_command",
        )
        
        assert response.success is True
        assert response.execution_id == "exec_123"
    
    @patch('the_well_nwo.client.requests.Session')
    def test_send_command_with_physics_context(self, mock_session):
        """Test sending command with physics context."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "success": True,
            "execution_id": "exec_456",
            "status": "accepted",
        }
        mock_response.raise_for_status = Mock()
        
        mock_session_instance = Mock()
        mock_session_instance.post.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        client = NWOClient(api_key="test_key")
        response = client.send_command(
            robot_id="drone_01",
            command="navigate",
            physics_context={
                "turbulence_zones": [],
                "optimal_path": [],
                "confidence": 0.95,
            }
        )
        
        assert response.success is True
        # Verify physics context was included
        call_args = mock_session_instance.post.call_args
        assert "physics_context" in call_args[1]["json"]
    
    @patch('the_well_nwo.client.requests.Session')
    def test_query_state(self, mock_session):
        """Test querying robot state."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "position": [1, 2, 3],
            "velocity": [0, 0, 0],
            "orientation": [1, 0, 0, 0],
            "battery_percent": 85,
            "status": "active",
        }
        mock_response.raise_for_status = Mock()
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        client = NWOClient(api_key="test_key")
        state = client.query_state("drone_01")
        
        assert state.robot_id == "drone_01"
        assert state.battery_percent == 85
        assert state.status == "active"
    
    @patch('the_well_nwo.client.requests.Session')
    def test_health_check(self, mock_session):
        """Test health check."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "status": "healthy",
            "version": "2.0.0",
            "uptime_seconds": 3600,
        }
        mock_response.raise_for_status = Mock()
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        client = NWOClient(api_key="test_key")
        health = client.health_check()
        
        assert health.status == "healthy"
        assert health.version == "2.0.0"
        assert health.uptime_seconds == 3600
    
    @patch('the_well_nwo.client.requests.Session')
    def test_api_error(self, mock_session):
        """Test handling API errors."""
        from requests.exceptions import HTTPError
        
        mock_response = Mock()
        mock_response.raise_for_status.side_effect = HTTPError("500 Server Error")
        mock_response.status_code = 500
        
        mock_session_instance = Mock()
        mock_session_instance.post.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        client = NWOClient(api_key="test_key")
        
        with pytest.raises(NWOAPIError):
            client.send_command("drone_01", "test")