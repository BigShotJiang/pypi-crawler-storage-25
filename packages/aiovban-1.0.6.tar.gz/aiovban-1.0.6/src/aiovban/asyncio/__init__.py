import asyncio
import locale
import logging
import platform
import socket
from dataclasses import dataclass, field
from typing import Any

from .device import VBANDevice
from .streams import VBANOutgoingStream
from .voicemeeter import VoicemeeterRemote
from .. import VBANApplicationData
from ..packet import ServiceType, VBANPacket
from ..packet.body.service import DeviceType, Features
from ..packet.headers.service import PingFunctions, VBANServiceHeader

logger = logging.getLogger(__name__)


def _default_application_data():
    return VBANApplicationData(
        device_type=DeviceType.Unknown,
        features=Features.NoFeatures,
        version="0.0.1",
        application_name="aiovban",
        lang_code=locale.getdefaultlocale()[0],
    )


@dataclass
class AsyncVBANClient(asyncio.DatagramProtocol):
    application_data: VBANApplicationData = field(
        default_factory=_default_application_data
    )
    ignore_audio_streams: bool = True
    default_queue_size: int = 200

    _registered_devices: dict = field(default_factory=dict, repr=False)

    _transport: Any = field(default=None, init=False, repr=False)
    raw_packets_received: int = field(default=0, init=False, repr=False)

    async def listen(self, address="0.0.0.0", port=6980, loop=None):
        loop = loop or asyncio.get_running_loop()

        from .protocol import VBANListenerProtocol

        self._transport, proto = await loop.create_datagram_endpoint(
            lambda: VBANListenerProtocol(self),
            local_addr=(address, port),
            allow_broadcast=not self.ignore_audio_streams,
        )

        return proto.done

    def send_datagram(self, data: bytes, addr: tuple) -> None:
        """Send raw bytes via the listener socket so the source port matches the listening port."""
        if self._transport:
            self._transport.sendto(data, addr)

    def close(self):
        if self._transport:
            self._transport.close()
            self._transport = None

    @staticmethod
    def _get_device_name():
        name = platform.system()
        if name == "Darwin":
            name = "MacOS"
        elif not name:
            name = "Unknown"
        return f"{name} Device"

    def get_ping_response(self):
        from ..packet.body.service import Ping

        return Ping(
            **self.application_data.__dict__,
            device_name=self._get_device_name(),
            host_name=platform.node(),
        )

    def quick_reject(self, address):
        return address not in self._registered_devices

    async def process_packet(self, address, port, packet):
        if self.process_packet_nowait(address, port, packet):
            return

        device: VBANDevice = self._registered_devices.get(address)
        if packet.header.streamname == "VBAN Service":
            if packet.header.service == ServiceType.Identification:
                if packet.header.function == PingFunctions.Request:
                    await self.send_ping(address, port, type=PingFunctions.Response)

        if device:
            await device.handle_packet(address, packet)

    def process_packet_nowait(self, address, port, packet) -> bool:
        device: VBANDevice = self._registered_devices.get(address)
        if device:
            return device.handle_packet_nowait(address, packet)
        return False

    async def send_ping(
        self, address, port, type: PingFunctions = PingFunctions.Request
    ):
        logger.debug(f"Sending ping to {address}:{port}")
        response_body = self.get_ping_response()
        packet = VBANPacket(
            header=VBANServiceHeader(
                streamname="VBAN Service",
                service=ServiceType.Identification,
                function=type,
            ),
            body=response_body.pack(),
        )
        logger.info(f"Sending ping response {response_body}")
        out_stream = VBANOutgoingStream(name="VBAN Service", _client=self)
        await out_stream.connect(address, port)
        await out_stream.send_packet(packet)

    async def register_device(self, address: str, port: int = 6980):
        # Use async DNS resolution to avoid blocking
        loop = asyncio.get_running_loop()
        try:
            # getaddrinfo returns (family, type, proto, canonname, sockaddr) tuples
            addrinfo = await loop.getaddrinfo(address, None, family=socket.AF_INET)
            if not addrinfo:
                raise ValueError(f"Could not resolve address: {address}")
            ip_address = addrinfo[0][4][0]  # Extract IP from sockaddr
        except (socket.gaierror, OSError) as e:
            raise ValueError(f"Invalid address '{address}': {e}")

        # Validate port range
        if not (0 <= port <= 65535):
            raise ValueError(f"Invalid port {port}: must be between 0 and 65535")

        if ip_address in self._registered_devices:
            return self._registered_devices[ip_address]

        logger.info(f"Registering device at {ip_address}:{port}")
        self._registered_devices[ip_address] = VBANDevice(
            address=ip_address,
            default_port=port,
            _client=self,
            default_stream_size=self.default_queue_size,
        )
        return self._registered_devices[ip_address]

    def devices(self):
        return list(self._registered_devices.values())
