# Talk-to-Tux Website

Astro static website for `https://www.talk-to-tux.com`.

## Routes

- `/` landing page
- `/apply` beta application form
- `/beta` application-gated beta status guidance
- `/privacy` self-drafted privacy policy
- `/terms` self-drafted terms
- `/billing` beta billing status page; paid billing is inactive
- `/beta-terms` self-drafted beta addendum
- `/security` security page linked to repo `SECURITY.md`

## Local Development

```bash
npm install
npm run dev
```

## Checks

```bash
npm run check
npm run build
```

`npm run check` runs Astro type checking plus deterministic tests for beta
application request building and response-state mapping.

## Environment

Copy `.env.example` to `.env` for local builds that need real public values.

| Variable | Purpose |
|---|---|
| `PUBLIC_BETA_APPLY_ENDPOINT` | Supabase Edge Function URL for `v1-beta-apply`. |
| `PUBLIC_TURNSTILE_SITE_KEY` | Cloudflare Turnstile public site key for `/apply`. |

Only public values belong in Astro environment variables. Turnstile secret keys,
Supabase service keys, GitHub OAuth secrets, Groq keys, and Sentry server DSNs
stay outside the website build.

## Deployment

Cloudflare Pages settings:

- Build command: `npm ci && npm run build`
- Build output directory: `dist`
- Production domain: `https://www.talk-to-tux.com`
- Root domain: redirect `https://talk-to-tux.com/*` to the `www` host
- Raw Pages hosts, including `talk-to-tux-website.pages.dev` and hash preview
  hosts such as `<deployment>.talk-to-tux-website.pages.dev`, are redirected by
  `public/_worker.js` to the canonical `www` host so they inherit the
  Cloudflare Access gate.
- Older immutable Pages deployments that predate `public/_worker.js` are covered
  by the Cloudflare Access application `Talk-to-Tux Raw Pages URLs`.

Preview and staging origins must either be added intentionally to the
`v1-beta-apply` CORS allowlist or use a non-production beta endpoint. The
current backend CORS contract only allows the production website origin.

## Source of Truth

Public claims must stay aligned with:

- `specs/beta-readiness-truth-table.md`
- `backend/supabase/functions/_shared/types.ts`
- `backend/supabase/functions/v1-beta-apply/index.ts`
- `README.md`
- `SECURITY.md`

Website legal and billing routes consume the contracts in the truth table.
Update the source docs alongside any future public claim or legal-route change.
