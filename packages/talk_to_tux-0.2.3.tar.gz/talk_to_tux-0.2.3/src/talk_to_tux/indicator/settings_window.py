from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, Callable
from urllib.parse import urlparse

from talk_to_tux.providers import BYOK_PROVIDER_IDS, BYOK_SECRET_ENV_NAMES
from talk_to_tux.settings import (
    PaidFallbackWarningState,
    SecretSettingsPatch,
    SettingsApplyResult,
    SettingsFieldState,
    SettingsPatch,
    SettingsState,
)


PatchCallback = Callable[[SettingsPatch], None]
SecretPatchCallback = Callable[[SecretSettingsPatch], None]
ResetCallback = Callable[[str], None]
UrlCallback = Callable[[str], None]
DesktopToggleCallback = Callable[[bool], None]
ProbeLocalInferenceCallback = Callable[[list[str] | None], None]

_TAB_TITLES = [
    "Providers",
    "Local Inference",
    "Capture & Context",
    "Trigger & Paste",
    "Learning",
    "Desktop",
    "Diagnostics",
]

_ENDPOINT_LABELS = {
    "gpu_server": "GPU STT server",
    "local_whisper": "Local Whisper STT",
    "ollama": "Ollama rewrite",
    "local_ai": "LocalAI rewrite",
}

_INTENTIONAL_NON_INPUT_PATHS: frozenset[str] = frozenset()


def render_settings_state(state: SettingsState) -> list[str]:
    provider_labels = [f"{p.name}: {p.status}" for p in state.providers]
    adapter_labels = [
        f"{name}: {backend}" for name, backend in sorted(state.desktop.selected_adapters.items())
    ]
    lines = [
        f"API mode: {state.api_mode}",
        f"Hosted signed in: {state.hosted_signed_in}",
        f"Hosted base URL: {state.hosted_base_url}",
        "Providers: " + ", ".join(provider_labels),
        f"Screenshot/context: {state.screenshot_enabled}",
        f"Local cache: {state.local_cache_enabled}",
        f"Desktop display: {state.desktop.display_server}",
        f"Desktop confidence: {state.desktop.confidence}",
        f"Tray/settings backend: {state.desktop.tray_support}",
        "Backends: " + (", ".join(adapter_labels) or "unknown"),
        "Warnings: " + ("; ".join(state.desktop.warnings) or "none"),
        "Privacy notes: " + ("; ".join(state.desktop.privacy_notes) or "none"),
        f"Launcher installed: {state.desktop_integration.launcher_installed}",
        f"Start on login: {state.desktop_integration.autostart_enabled}",
        "Desktop integration warnings: "
        + ("; ".join(state.desktop_integration.warnings) or "none"),
        f"Learning enabled: {state.learning.enabled}",
        f"Learning scope: {state.learning.scope_policy}",
        f"Phrase hints: {state.learning.phrase_hints_enabled}",
        f"Rewrite steering: {state.learning.rewrite_steering_enabled}",
        "Disabled apps: " + (", ".join(state.learning.disabled_apps) or "none"),
    ]
    lines.extend(_paid_fallback_warning_lines(state.paid_fallback_warning))
    lines.extend(f"{name}: {url}" for name, url in state.legal_urls.items())
    return lines


def _format_timestamp(timestamp: float | None) -> str:
    if timestamp is None:
        return "never"
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")


def _paid_fallback_warning_lines(state: PaidFallbackWarningState | None) -> list[str]:
    if state is None:
        return []
    parts = [f"Paid fallback warning: {'active' if state.active else 'inactive'}"]
    if state.stage:
        parts.append(f"stage={'transcription' if state.stage == 'stt' else 'rewrite'}")
    if state.local_label:
        parts.append(f"local={state.local_label}")
    if state.fallback_compute_class:
        parts.append(f"fallback={state.fallback_compute_class}")
    if state.fallback_provider:
        parts.append(f"provider={state.fallback_provider}")
    if state.reason:
        parts.append(f"reason={state.reason}")
    if state.effective_chain:
        parts.append(f"effective_chain={','.join(state.effective_chain)}")
    return [
        "; ".join(parts),
        "Last paid warning: "
        f"{_format_timestamp(state.last_notified_at)}; "
        f"suppressed until {_format_timestamp(state.suppressed_until)}",
    ]


class SettingsWindow:
    """Tabbed GTK settings window with callback-only mutation hooks."""

    def __init__(
        self,
        state: SettingsState,
        *,
        on_apply_patch: PatchCallback,
        on_apply_secret_patch: SecretPatchCallback,
        on_probe_local_inference: ProbeLocalInferenceCallback,
        on_reset_learning: ResetCallback,
        on_open_url: UrlCallback,
        on_launcher_toggle: DesktopToggleCallback | None = None,
        on_autostart_toggle: DesktopToggleCallback | None = None,
        gtk: Any | None = None,
    ) -> None:
        self.state = state
        self.on_apply_patch = on_apply_patch
        self.on_apply_secret_patch = on_apply_secret_patch
        self.on_probe_local_inference = on_probe_local_inference
        self.on_reset_learning = on_reset_learning
        self.on_open_url = on_open_url
        self.on_launcher_toggle = on_launcher_toggle
        self.on_autostart_toggle = on_autostart_toggle
        self._Gtk = gtk or _import_gtk()
        self._field_by_path = self._index_fields(state)
        self._feedback_labels: dict[str, Any] = {}
        self._field_inputs: dict[str, Any] = {}
        self._field_notes: dict[str, Any] = {}
        self._secret_entries: dict[str, Any] = {}
        self._secret_status_labels: dict[str, Any] = {}
        self._health_labels: dict[str, Any] = {}
        self._tab_labels: list[str] = []
        self._notebook: Any | None = None
        self._learning_app_entry: Any | None = None
        self._window = self._build()

    @property
    def tab_titles(self) -> list[str]:
        return list(self._tab_labels)

    def select_tab(self, tab: int | str) -> str:
        if isinstance(tab, str):
            try:
                index = self._tab_labels.index(tab)
            except ValueError as exc:
                raise ValueError(f"unsupported settings tab: {tab}") from exc
        elif isinstance(tab, int):
            index = tab
        else:
            raise ValueError(f"unsupported settings tab: {tab}")
        if index < 0 or index >= len(self._tab_labels):
            raise ValueError(f"unsupported settings tab: {tab}")
        if self._notebook is not None and hasattr(self._notebook, "set_current_page"):
            self._notebook.set_current_page(index)
        return self._tab_labels[index]

    def show(self) -> None:
        if hasattr(self._window, "show_all"):
            self._window.show_all()
        elif hasattr(self._window, "present"):
            self._window.present()

    def present(self) -> None:
        if hasattr(self._window, "show_all"):
            self._window.show_all()
        if hasattr(self._window, "present"):
            self._window.present()
        else:
            self.show()

    def refresh_state(self, state: SettingsState) -> None:
        self.state = state
        self._field_by_path = self._index_fields(state)
        self._feedback_labels.clear()
        self._field_inputs.clear()
        self._field_notes.clear()
        self._secret_entries.clear()
        self._secret_status_labels.clear()
        self._health_labels.clear()
        self._tab_labels.clear()
        content = self._build_content()
        self._replace_content(content)
        if hasattr(self._window, "show_all"):
            self._window.show_all()

    def apply_toggle(self, path: str, value: bool) -> None:
        self._set_feedback(path, "Saving...")
        self.on_apply_patch(SettingsPatch(path=path, value=value))

    def save_field(self, path: str, raw_value: Any) -> bool:
        try:
            parsed = self._coerce_field_value(self._field_by_path[path], raw_value)
        except ValueError as exc:
            self._set_feedback(path, str(exc))
            return False
        self._set_feedback(path, "Saving...")
        self.on_apply_patch(SettingsPatch(path=path, value=parsed))
        return True

    def save_secret(self, provider_id: str, value: str) -> bool:
        secret_path = f"{provider_id}_api_key"
        if secret_path not in BYOK_SECRET_ENV_NAMES:
            raise ValueError(f"unsupported provider secret: {provider_id}")
        cleaned = value.strip()
        if not cleaned:
            self._set_secret_feedback(provider_id, "Enter a key before saving")
            return False
        self._set_secret_feedback(provider_id, "Saving...")
        self.on_apply_secret_patch(SecretSettingsPatch(path=secret_path, value=cleaned))
        entry = self._secret_entries.get(provider_id)
        if entry is not None and hasattr(entry, "set_text"):
            entry.set_text("")
        return True

    def clear_secret(self, provider_id: str) -> None:
        secret_path = f"{provider_id}_api_key"
        if secret_path not in BYOK_SECRET_ENV_NAMES:
            raise ValueError(f"unsupported provider secret: {provider_id}")
        self._set_secret_feedback(provider_id, "Saving...")
        self.on_apply_secret_patch(SecretSettingsPatch(path=secret_path, value=None))
        entry = self._secret_entries.get(provider_id)
        if entry is not None and hasattr(entry, "set_text"):
            entry.set_text("")

    def probe_local_inference(self, endpoints: list[str] | None = None) -> None:
        self.on_probe_local_inference(endpoints)

    def reset_global_learning(self) -> None:
        self.on_reset_learning("global")

    def reset_app_learning(self, app_id: str) -> bool:
        cleaned = app_id.strip()
        if not cleaned:
            self._set_feedback("learning.reset_app", "Enter an app id")
            return False
        self._set_feedback("learning.reset_app", f"Reset queued for {cleaned}")
        self.on_reset_learning(f"app:{cleaned}")
        return True

    def open_legal_url(self, name: str) -> None:
        self.on_open_url(self.state.legal_urls[name])

    def set_launcher_installed(self, enabled: bool) -> None:
        if self.on_launcher_toggle is not None:
            self.on_launcher_toggle(enabled)

    def set_autostart_enabled(self, enabled: bool) -> None:
        if self.on_autostart_toggle is not None:
            self.on_autostart_toggle(enabled)

    def _build(self) -> Any:
        Gtk = self._Gtk
        window = Gtk.Window(title="Talk to Tux Settings")
        if hasattr(window, "set_default_size"):
            window.set_default_size(760, 720)
        if hasattr(window, "connect"):
            window.connect("delete-event", self._on_delete)
        container = Gtk.Box(orientation=getattr(Gtk.Orientation, "VERTICAL", 1), spacing=8)
        if hasattr(container, "set_border_width"):
            container.set_border_width(12)
        if hasattr(window, "add"):
            window.add(container)
        self._content_host = container
        container.pack_start(self._build_content(), True, True, 0)
        return window

    def _build_content(self) -> Any:
        Gtk = self._Gtk
        notebook = Gtk.Notebook()
        self._notebook = notebook
        for title, builder in (
            ("Providers", self._build_providers_tab),
            ("Local Inference", self._build_local_inference_tab),
            ("Capture & Context", self._build_capture_context_tab),
            ("Trigger & Paste", self._build_trigger_paste_tab),
            ("Learning", self._build_learning_tab),
            ("Desktop", self._build_desktop_tab),
            ("Diagnostics", self._build_diagnostics_tab),
        ):
            page = builder()
            label = Gtk.Label(label=title)
            notebook.append_page(self._wrap_notebook_page(page), label)
            self._tab_labels.append(title)
        return notebook

    def _replace_content(self, content: Any) -> None:
        host = self._content_host
        if hasattr(host, "get_children") and hasattr(host, "remove"):
            for child in list(host.get_children()):
                host.remove(child)
        elif hasattr(host, "children"):
            host.children = []
        if hasattr(host, "pack_start"):
            host.pack_start(content, True, True, 0)
        elif hasattr(host, "add"):
            host.add(content)

    def _build_providers_tab(self) -> Any:
        box = self._new_page_box()
        box.pack_start(self._section_header("Provider controls"), False, False, 0)
        box.pack_start(self._enum_row("API mode", "api_mode"), False, False, 0)
        box.pack_start(self._text_row("Hosted base URL", "hosted.base_url"), False, False, 0)
        box.pack_start(self._provider_selector_row("STT providers", "stt.providers"), False, False, 0)
        box.pack_start(self._model_selector_row("OpenAI STT model", "stt.openai_model"), False, False, 0)
        box.pack_start(self._model_selector_row("Groq STT model", "stt.groq_model"), False, False, 0)
        box.pack_start(self._model_selector_row("ElevenLabs STT model", "stt.elevenlabs_model"), False, False, 0)
        box.pack_start(self._model_selector_row("Google STT model", "stt.google_model"), False, False, 0)
        box.pack_start(self._model_selector_row("Groq rewrite model", "rewrite.groq_model"), False, False, 0)
        box.pack_start(self._model_selector_row("Gemini rewrite model", "rewrite.gemini_model"), False, False, 0)
        box.pack_start(self._model_selector_row("OpenAI rewrite model", "rewrite.openai_model"), False, False, 0)
        box.pack_start(self._toggle_row("Rewrite enabled", "rewrite.enabled"), False, False, 0)
        box.pack_start(self._section_header("Rewrite tuning"), False, False, 0)
        box.pack_start(self._numeric_row("Rewrite context budget (%)", "rewrite.context_budget_pct"), False, False, 0)
        box.pack_start(self._numeric_row("Rewrite model context tokens", "rewrite.model_context_tokens"), False, False, 0)
        box.pack_start(self._section_header("BYOK provider keys"), False, False, 0)
        for provider_id in BYOK_PROVIDER_IDS:
            box.pack_start(self._secret_row(provider_id), False, False, 0)
        return box

    def _build_local_inference_tab(self) -> Any:
        box = self._new_page_box()
        box.pack_start(self._section_header("Local endpoints"), False, False, 0)
        box.pack_start(self._section_header("GPU STT server"), False, False, 0)
        box.pack_start(self._text_row("GPU server URL", "stt.gpu_server.url"), False, False, 0)
        box.pack_start(self._numeric_row("GPU server inference timeout (s)", "stt.gpu_server.timeout"), False, False, 0)
        box.pack_start(self._numeric_row("GPU server probe timeout (s)", "stt.gpu_server.probe_timeout_s"), False, False, 0)
        box.pack_start(
            self._numeric_row("GPU server unhealthy cooldown (s)", "stt.gpu_server.unhealthy_cooldown_s"),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row("GPU server probe interval (s)", "stt.gpu_server.probe_interval_s"),
            False,
            False,
            0,
        )
        box.pack_start(self._section_header("Local Whisper STT"), False, False, 0)
        box.pack_start(self._text_row("Local Whisper URL", "stt.local_whisper.url"), False, False, 0)
        box.pack_start(
            self._numeric_row("Local Whisper inference timeout (s)", "stt.local_whisper.timeout"),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row("Local Whisper probe timeout (s)", "stt.local_whisper.probe_timeout_s"),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row(
                "Local Whisper unhealthy cooldown (s)",
                "stt.local_whisper.unhealthy_cooldown_s",
            ),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row("Local Whisper probe interval (s)", "stt.local_whisper.probe_interval_s"),
            False,
            False,
            0,
        )
        box.pack_start(self._model_selector_row("Local Whisper model", "stt.local_whisper_model"), False, False, 0)
        box.pack_start(self._section_header("Ollama rewrite"), False, False, 0)
        box.pack_start(self._text_row("Ollama base URL", "rewrite.ollama_base_url"), False, False, 0)
        box.pack_start(
            self._numeric_row("Ollama inference timeout (s)", "rewrite.ollama_timeout_s"),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row("Ollama probe timeout (s)", "rewrite.ollama_probe_timeout_s"),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row(
                "Ollama unhealthy cooldown (s)",
                "rewrite.ollama_unhealthy_cooldown_s",
            ),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row("Ollama probe interval (s)", "rewrite.ollama_probe_interval_s"),
            False,
            False,
            0,
        )
        box.pack_start(self._model_selector_row("Ollama model", "rewrite.ollama_model"), False, False, 0)
        box.pack_start(self._section_header("LocalAI rewrite"), False, False, 0)
        box.pack_start(self._text_row("LocalAI URL", "rewrite.local_ai_url"), False, False, 0)
        box.pack_start(
            self._numeric_row("LocalAI inference timeout (s)", "rewrite.local_ai_timeout_s"),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row("LocalAI probe timeout (s)", "rewrite.local_ai_probe_timeout_s"),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row(
                "LocalAI unhealthy cooldown (s)",
                "rewrite.local_ai_unhealthy_cooldown_s",
            ),
            False,
            False,
            0,
        )
        box.pack_start(
            self._numeric_row("LocalAI probe interval (s)", "rewrite.local_ai_probe_interval_s"),
            False,
            False,
            0,
        )
        box.pack_start(self._model_selector_row("LocalAI model", "rewrite.local_ai_model"), False, False, 0)
        box.pack_start(self._button_row("Probe all endpoints", lambda *_: self.probe_local_inference(None)), False, False, 0)
        for endpoint_id in ("gpu_server", "local_whisper", "ollama", "local_ai"):
            box.pack_start(self._health_row(endpoint_id), False, False, 0)
        for line in _paid_fallback_warning_lines(self.state.paid_fallback_warning):
            box.pack_start(self._label(line, wrap=True), False, False, 0)
        return box

    def _build_capture_context_tab(self) -> Any:
        box = self._new_page_box()
        box.pack_start(self._section_header("Capture"), False, False, 0)
        box.pack_start(self._toggle_row("Screenshot/context capture", "context.screenshot_enabled"), False, False, 0)
        box.pack_start(self._toggle_row("Local cache", "cache.enabled"), False, False, 0)
        box.pack_start(self._numeric_row("Screenshot max width", "context.screenshot_max_width"), False, False, 0)
        box.pack_start(self._numeric_row("Screenshot JPEG quality", "context.screenshot_jpeg_quality"), False, False, 0)
        box.pack_start(self._numeric_row("Cache max age (hours)", "cache.max_age_hours"), False, False, 0)
        box.pack_start(self._numeric_row("Cache max runs", "cache.max_runs"), False, False, 0)
        box.pack_start(self._numeric_row("Cache analysis threshold", "cache.analysis_threshold"), False, False, 0)
        return box

    def _build_trigger_paste_tab(self) -> Any:
        box = self._new_page_box()
        box.pack_start(self._section_header("Trigger"), False, False, 0)
        box.pack_start(self._enum_row("Trigger mode", "trigger.mode"), False, False, 0)
        box.pack_start(self._enum_row("Record mode", "trigger.record_mode"), False, False, 0)
        box.pack_start(self._numeric_row("Chord timeout (ms)", "trigger.chord_timeout_ms"), False, False, 0)
        box.pack_start(self._numeric_row("Chord debounce (ms)", "trigger.chord_debounce_ms"), False, False, 0)
        box.pack_start(self._numeric_row("Silence timeout (s)", "trigger.silence_timeout_s"), False, False, 0)
        box.pack_start(self._section_header("Paste"), False, False, 0)
        box.pack_start(self._toggle_row("Paste enabled", "paste.enabled"), False, False, 0)
        box.pack_start(self._numeric_row("Clipboard delay (ms)", "paste.clipboard_delay_ms"), False, False, 0)
        box.pack_start(self._enum_row("Wayland keystroke tool", "paste.wayland_keystroke_tool"), False, False, 0)
        return box

    def _build_learning_tab(self) -> Any:
        box = self._new_page_box()
        box.pack_start(self._toggle_row("Learning enabled", "learning.enabled"), False, False, 0)
        box.pack_start(self._enum_row("Learning scope", "learning.scope_policy"), False, False, 0)
        box.pack_start(self._toggle_row("Phrase hints", "learning.phrase_hints_enabled"), False, False, 0)
        box.pack_start(self._toggle_row("Rewrite steering", "learning.rewrite_steering_enabled"), False, False, 0)
        box.pack_start(self._text_row("Disabled apps", "learning.disabled_apps"), False, False, 0)
        box.pack_start(self._button_row("Reset global learning", lambda *_: self.reset_global_learning()), False, False, 0)

        row = self._new_row()
        row.pack_start(self._label("Reset app learning"), False, False, 0)
        entry = self._Gtk.Entry()
        if hasattr(entry, "set_placeholder_text"):
            entry.set_placeholder_text("App id")
        row.pack_start(entry, True, True, 0)
        button = self._Gtk.Button(label="Reset App")
        button.connect("clicked", lambda *_: self.reset_app_learning(entry.get_text()))
        row.pack_start(button, False, False, 0)
        feedback = self._feedback_label("")
        row.pack_start(feedback, False, False, 0)
        self._feedback_labels["learning.reset_app"] = feedback
        self._learning_app_entry = entry
        box.pack_start(row, False, False, 0)
        return box

    def _build_desktop_tab(self) -> Any:
        box = self._new_page_box()
        box.pack_start(self._section_header("Desktop integration"), False, False, 0)
        launcher = self._Gtk.CheckButton(label="Install app launcher")
        launcher.set_active(self.state.desktop_integration.launcher_installed)
        launcher.connect("toggled", lambda widget: self.set_launcher_installed(widget.get_active()))
        box.pack_start(launcher, False, False, 0)

        autostart = self._Gtk.CheckButton(label="Start on login")
        autostart.set_active(self.state.desktop_integration.autostart_enabled)
        autostart.connect("toggled", lambda widget: self.set_autostart_enabled(widget.get_active()))
        box.pack_start(autostart, False, False, 0)

        for line in (
            f"Display server: {self.state.desktop.display_server}",
            f"Tray/settings backend: {self.state.desktop.tray_support}",
            f"Desktop confidence: {self.state.desktop.confidence}",
            "Desktop warnings: " + ("; ".join(self.state.desktop.warnings) or "none"),
            f"Launcher path: {self.state.desktop_integration.launcher_path or 'not installed'}",
            f"Autostart path: {self.state.desktop_integration.autostart_path or 'not installed'}",
            "Desktop integration warnings: "
            + ("; ".join(self.state.desktop_integration.warnings) or "none"),
        ):
            box.pack_start(self._label(line, wrap=True), False, False, 0)
        return box

    def _build_diagnostics_tab(self) -> Any:
        box = self._new_page_box()
        box.pack_start(self._section_header("Read-only diagnostics"), False, False, 0)
        for line in render_settings_state(self.state):
            label = self._label(line, wrap=True)
            box.pack_start(label, False, False, 0)
        if self.state.local_inference_health:
            box.pack_start(self._label("Local inference health:", wrap=True), False, False, 0)
            for endpoint_id in ("gpu_server", "local_whisper", "ollama", "local_ai"):
                result = self.state.local_inference_health.get(endpoint_id)
                if result is None:
                    continue
                box.pack_start(self._label(self._health_summary(endpoint_id), wrap=True), False, False, 0)
        box.pack_start(self._section_header("Legal"), False, False, 0)
        for name in ("privacy", "terms", "beta_terms", "security"):
            button = self._Gtk.Button(label=f"Open {name.replace('_', ' ').title()}")
            button.connect("clicked", lambda _, key=name: self.open_legal_url(key))
            box.pack_start(button, False, False, 0)
        return box

    def _toggle_row(self, label_text: str, path: str) -> Any:
        row = self._new_row()
        toggle = self._Gtk.CheckButton(label=label_text)
        toggle.set_active(bool(self._field_by_path[path].value))
        toggle.connect("toggled", lambda widget: self.apply_toggle(path, widget.get_active()))
        row.pack_start(toggle, False, False, 0)
        row.pack_start(self._apply_mode_label(path), False, False, 0)
        feedback = self._feedback_label("")
        row.pack_start(feedback, False, False, 0)
        self._feedback_labels[path] = feedback
        self._field_inputs[path] = toggle
        return row

    def _enum_row(self, label_text: str, path: str) -> Any:
        field = self._field_by_path[path]
        row = self._new_row()
        row.pack_start(self._label(label_text), False, False, 0)
        combo = self._Gtk.ComboBoxText()
        options = field.validation.enum_options or []
        for option in options:
            combo.append_text(option)
        if field.value in options:
            combo.set_active(options.index(field.value))
        row.pack_start(combo, True, True, 0)
        save = self._Gtk.Button(label="Save")
        save.connect("clicked", lambda *_: self.save_field(path, combo.get_active_text()))
        row.pack_start(save, False, False, 0)
        row.pack_start(self._apply_mode_label(path), False, False, 0)
        feedback = self._feedback_label("")
        row.pack_start(feedback, False, False, 0)
        self._feedback_labels[path] = feedback
        self._field_inputs[path] = combo
        return row

    def _provider_selector_row(self, label_text: str, path: str) -> Any:
        field = self._field_by_path[path]
        row = self._new_row()
        row.pack_start(self._label(label_text), False, False, 0)
        selector_box = self._new_page_box()
        toggles: list[tuple[str, Any]] = []
        option_ids = field.validation.enum_options or []
        option_labels = field.validation.option_labels or option_ids
        selected = set(field.value if isinstance(field.value, list) else [])
        for provider_id, provider_label in zip(option_ids, option_labels, strict=False):
            toggle = self._Gtk.CheckButton(label=provider_label)
            toggle.set_active(provider_id in selected)
            selector_box.pack_start(toggle, False, False, 0)
            toggles.append((provider_id, toggle))
        row.pack_start(selector_box, True, True, 0)
        save = self._Gtk.Button(label="Save")
        save.connect("clicked", lambda *_: self._save_provider_selection(path))
        row.pack_start(save, False, False, 0)
        row.pack_start(self._apply_mode_label(path), False, False, 0)
        feedback = self._feedback_label("")
        row.pack_start(feedback, False, False, 0)
        self._feedback_labels[path] = feedback
        self._field_inputs[path] = toggles
        return row

    def _model_selector_row(self, label_text: str, path: str) -> Any:
        field = self._field_by_path[path]
        row = self._new_row()
        row.pack_start(self._label(label_text), False, False, 0)
        combo = self._Gtk.ComboBoxText()
        option_ids = field.validation.enum_options or []
        option_labels = field.validation.option_labels or option_ids
        for label in option_labels:
            combo.append_text(label)
        if field.value in option_ids:
            combo.set_active(option_ids.index(field.value))
        row.pack_start(combo, True, True, 0)
        save = self._Gtk.Button(label="Save")
        save.connect("clicked", lambda *_: self._save_model_selection(path))
        row.pack_start(save, False, False, 0)
        row.pack_start(self._apply_mode_label(path), False, False, 0)
        note = self._feedback_label(self._field_note_text(field))
        row.pack_start(note, False, False, 0)
        feedback = self._feedback_label("")
        row.pack_start(feedback, False, False, 0)
        self._field_notes[path] = note
        self._feedback_labels[path] = feedback
        self._field_inputs[path] = combo
        return row

    def _text_row(self, label_text: str, path: str) -> Any:
        field = self._field_by_path[path]
        row = self._new_row()
        row.pack_start(self._label(label_text), False, False, 0)
        entry = self._Gtk.Entry()
        if isinstance(field.value, list):
            entry.set_text(", ".join(field.value))
        else:
            entry.set_text(str(field.value))
        row.pack_start(entry, True, True, 0)
        save = self._Gtk.Button(label="Save")
        save.connect("clicked", lambda *_: self.save_field(path, entry.get_text()))
        row.pack_start(save, False, False, 0)
        row.pack_start(self._apply_mode_label(path), False, False, 0)
        feedback = self._feedback_label("")
        row.pack_start(feedback, False, False, 0)
        self._feedback_labels[path] = feedback
        self._field_inputs[path] = entry
        return row

    def _numeric_row(self, label_text: str, path: str) -> Any:
        field = self._field_by_path[path]
        row = self._new_row()
        row.pack_start(self._label(label_text), False, False, 0)
        spin = self._numeric_spin(field)
        row.pack_start(spin, True, True, 0)
        save = self._Gtk.Button(label="Save")
        save.connect("clicked", lambda *_: self.save_field(path, self._read_spin_value(path, spin)))
        row.pack_start(save, False, False, 0)
        row.pack_start(self._apply_mode_label(path), False, False, 0)
        feedback = self._feedback_label("")
        row.pack_start(feedback, False, False, 0)
        self._feedback_labels[path] = feedback
        self._field_inputs[path] = spin
        return row

    def _numeric_spin(self, field: SettingsFieldState) -> Any:
        value = float(field.value)
        digits = self._numeric_digits(field)
        step_increment = self._numeric_step_increment(digits, field.validation.kind)
        lower = field.validation.min_value
        upper = field.validation.max_value
        if lower is None:
            lower = min(value, 0.0)
        if upper is None:
            upper = max(value, lower + step_increment)
        if upper <= lower:
            upper = lower + step_increment
        adjustment = self._Gtk.Adjustment(
            value=value,
            lower=lower,
            upper=upper,
            step_increment=step_increment,
            page_increment=step_increment * 10,
            page_size=0.0,
        )
        spin = self._Gtk.SpinButton(adjustment=adjustment, climb_rate=0.0, digits=digits)
        if hasattr(spin, "set_digits"):
            spin.set_digits(digits)
        if hasattr(spin, "set_increments"):
            spin.set_increments(step_increment, step_increment * 10)
        if hasattr(spin, "set_value"):
            spin.set_value(value)
        return spin

    def _secret_row(self, provider_id: str) -> Any:
        row = self._new_row()
        provider_status = next(provider for provider in self.state.providers if provider.name == provider_id)
        row.pack_start(self._label(provider_id.title()), False, False, 0)
        entry = self._Gtk.Entry()
        entry.set_text("")
        if hasattr(entry, "set_visibility"):
            entry.set_visibility(False)
        if hasattr(entry, "set_placeholder_text"):
            entry.set_placeholder_text("Paste new key")
        row.pack_start(entry, True, True, 0)
        save = self._Gtk.Button(label="Save")
        save.connect("clicked", lambda *_: self.save_secret(provider_id, entry.get_text()))
        clear = self._Gtk.Button(label="Clear")
        clear.connect("clicked", lambda *_: self.clear_secret(provider_id))
        row.pack_start(save, False, False, 0)
        row.pack_start(clear, False, False, 0)
        feedback = self._feedback_label(provider_status.status)
        row.pack_start(feedback, False, False, 0)
        self._secret_entries[provider_id] = entry
        self._secret_status_labels[provider_id] = feedback
        return row

    def _health_row(self, endpoint_id: str) -> Any:
        row = self._new_row()
        row.pack_start(self._label(_ENDPOINT_LABELS[endpoint_id]), False, False, 0)
        probe = self._Gtk.Button(label="Probe")
        probe.connect("clicked", lambda *_: self.probe_local_inference([endpoint_id]))
        row.pack_start(probe, False, False, 0)
        status = self._feedback_label(self._health_summary(endpoint_id))
        row.pack_start(status, False, False, 0)
        self._health_labels[endpoint_id] = status
        return row

    def rendered_editable_paths(self) -> set[str]:
        return set(self._field_inputs) | set(_INTENTIONAL_NON_INPUT_PATHS)

    def _button_row(self, label_text: str, callback: Callable[..., Any]) -> Any:
        row = self._new_row()
        button = self._Gtk.Button(label=label_text)
        button.connect("clicked", callback)
        row.pack_start(button, False, False, 0)
        return row

    def _health_summary(self, endpoint_id: str) -> str:
        result = (self.state.local_inference_health or {}).get(endpoint_id)
        if result is None:
            return "Not checked"
        latency = f" ({result.latency_ms} ms)" if result.latency_ms is not None else ""
        reason = f" - {result.reason}" if result.reason else ""
        summary = f"{result.status}{latency}{reason}"
        detail_parts: list[str] = []
        if result.last_checked_at is not None:
            checked_at = datetime.fromtimestamp(result.last_checked_at).strftime("%Y-%m-%d %H:%M:%S")
            detail_parts.append(f"checked {checked_at}")
        if result.stale:
            detail_parts.append("stale")
        if result.skip_eligible:
            detail_parts.append("skip eligible")
        elif result.cooldown_until is not None:
            cooldown_until = datetime.fromtimestamp(result.cooldown_until).strftime("%Y-%m-%d %H:%M:%S")
            detail_parts.append(f"cooldown until {cooldown_until}")
        metadata_parts = [
            f"{key}={value}"
            for key, value in sorted(result.metadata.items())
            if key != "url"
        ]
        if metadata_parts:
            detail_parts.append(", ".join(metadata_parts))
        unselectable = [
            model.label if not model.reason else f"{model.label} ({model.reason})"
            for model in result.discovered_models
            if not model.selectable
        ]
        if detail_parts:
            summary = f"{summary}; {'; '.join(detail_parts)}"
        if unselectable:
            summary = f"{summary}; read-only models: {', '.join(unselectable)}"
        return summary

    def _apply_mode_label(self, path: str) -> Any:
        field = self._field_by_path[path]
        if field.applies_live:
            text = "Applies live"
        elif field.rebuilds_provider:
            text = "Rebuilds provider"
        else:
            text = "Restart required"
        return self._feedback_label(text, wrap=True)

    def _feedback_label(self, text: str, *, wrap: bool = True) -> Any:
        label = self._Gtk.Label(label=text)
        if hasattr(label, "set_xalign"):
            label.set_xalign(0)
        if wrap and hasattr(label, "set_line_wrap"):
            label.set_line_wrap(True)
        return label

    def _label(self, text: str, *, wrap: bool = False) -> Any:
        return self._feedback_label(text, wrap=wrap)

    def _section_header(self, text: str) -> Any:
        return self._label(text)

    def _new_page_box(self) -> Any:
        box = self._Gtk.Box(orientation=getattr(self._Gtk.Orientation, "VERTICAL", 1), spacing=8)
        if hasattr(box, "set_border_width"):
            box.set_border_width(8)
        return box

    def _wrap_notebook_page(self, child: Any) -> Any:
        scrolled = self._Gtk.ScrolledWindow()
        if hasattr(scrolled, "add"):
            scrolled.add(child)
        if hasattr(scrolled, "set_policy"):
            policy_type = getattr(self._Gtk, "PolicyType", None)
            automatic = getattr(policy_type, "AUTOMATIC", 0) if policy_type is not None else 0
            scrolled.set_policy(automatic, automatic)
        if hasattr(scrolled, "set_hexpand"):
            scrolled.set_hexpand(True)
        if hasattr(scrolled, "set_vexpand"):
            scrolled.set_vexpand(True)
        return scrolled

    def _new_row(self) -> Any:
        return self._Gtk.Box(orientation=getattr(self._Gtk.Orientation, "HORIZONTAL", 0), spacing=8)

    def _set_feedback(self, path: str, text: str) -> None:
        label = self._feedback_labels.get(path)
        if label is not None and hasattr(label, "set_text"):
            label.set_text(text)

    def _clear_feedback(self, path: str) -> None:
        self._set_feedback(path, "")

    def _set_secret_feedback(self, provider_id: str, text: str) -> None:
        label = self._secret_status_labels.get(provider_id)
        if label is not None and hasattr(label, "set_text"):
            label.set_text(text)

    def set_apply_feedback(self, result: SettingsApplyResult) -> None:
        text = result.message or ""
        if result.path in BYOK_SECRET_ENV_NAMES:
            self._set_secret_feedback(result.path.removesuffix("_api_key"), text)
            return
        self._set_feedback(result.path, text)

    def _save_provider_selection(self, path: str) -> bool:
        toggles = self._field_inputs[path]
        selected = [provider_id for provider_id, toggle in toggles if toggle.get_active()]
        return self.save_field(path, selected)

    def _save_model_selection(self, path: str) -> bool:
        field = self._field_by_path[path]
        combo = self._field_inputs[path]
        active_index = combo.get_active() if hasattr(combo, "get_active") else None
        if active_index is None or active_index < 0:
            return self.save_field(path, None)
        option_ids = field.validation.enum_options or []
        return self.save_field(path, option_ids[active_index])

    def _field_note_text(self, field: SettingsFieldState) -> str:
        if field.value_supported is False and field.unsupported_legacy_value:
            return f"Current value unsupported: {field.unsupported_legacy_value}"
        return ""

    def _read_spin_value(self, path: str, spin: Any) -> int | float:
        field = self._field_by_path[path]
        if field.validation.kind == "integer" and hasattr(spin, "get_value_as_int"):
            return spin.get_value_as_int()
        if hasattr(spin, "get_value"):
            return spin.get_value()
        raise ValueError(f"missing numeric getter for {path}")

    def _numeric_digits(self, field: SettingsFieldState) -> int:
        if field.validation.kind == "integer":
            return 0
        candidates = [field.value, field.validation.min_value, field.validation.max_value]
        return max(1, max(self._decimal_places(value) for value in candidates if value is not None))

    def _numeric_step_increment(self, digits: int, kind: str) -> float:
        if kind == "integer" or digits <= 0:
            return 1.0
        return 10 ** (-digits)

    def _decimal_places(self, value: Any) -> int:
        exponent = Decimal(str(value)).normalize().as_tuple().exponent
        return max(0, -exponent)

    def _coerce_field_value(self, field: SettingsFieldState, raw_value: Any) -> Any:
        validation = field.validation
        kind = validation.kind
        if kind == "boolean":
            if not isinstance(raw_value, bool):
                raise ValueError(f"{field.path} requires a boolean value")
            return raw_value
        if kind == "enum":
            if not isinstance(raw_value, str) or raw_value not in (validation.enum_options or []):
                raise ValueError(f"{field.path} must be one of {validation.enum_options or []}")
            return raw_value
        if kind == "integer":
            value = int(raw_value)
            self._validate_numeric_range(field.path, value, validation.min_value, validation.max_value)
            return value
        if kind == "number":
            value = float(raw_value)
            self._validate_numeric_range(field.path, value, validation.min_value, validation.max_value)
            return value
        if kind == "string":
            return self._validate_string(field.path, raw_value, validation.min_length, validation.allow_blank)
        if kind == "url":
            value = self._validate_string(field.path, raw_value, validation.min_length, validation.allow_blank)
            parsed = urlparse(value)
            if parsed.scheme not in set(validation.schemes or []) or not parsed.netloc:
                raise ValueError(f"{field.path} must be a valid {'/'.join(validation.schemes or ['http', 'https'])} URL")
            return value
        if kind == "string_list":
            if isinstance(raw_value, str):
                values = [item.strip() for item in raw_value.split(",")]
            elif isinstance(raw_value, list):
                values = [str(item).strip() for item in raw_value]
            else:
                raise ValueError(f"{field.path} requires a list of strings")
            if validation.allow_blank is False:
                values = [value for value in values if value]
                if not values:
                    raise ValueError(f"{field.path} must not be empty")
            if validation.min_length and len(values) < validation.min_length:
                raise ValueError(f"{field.path} must include at least {validation.min_length} value(s)")
            enum_options = validation.enum_options or []
            unknown = sorted(set(values) - set(enum_options))
            if unknown:
                raise ValueError(f"{field.path} contains unsupported values: {unknown}")
            return values
        return raw_value

    def _validate_numeric_range(
        self,
        path: str,
        value: int | float,
        min_value: float | None,
        max_value: float | None,
    ) -> None:
        if min_value is not None and value < min_value:
            raise ValueError(f"{path} must be >= {min_value}")
        if max_value is not None and value > max_value:
            raise ValueError(f"{path} must be <= {max_value}")

    def _validate_string(
        self,
        path: str,
        raw_value: Any,
        min_length: int | None,
        allow_blank: bool | None,
    ) -> str:
        if not isinstance(raw_value, str):
            raise ValueError(f"{path} requires a string value")
        value = raw_value.strip()
        if allow_blank is False and not value:
            raise ValueError(f"{path} must not be blank")
        if min_length is not None and len(value) < min_length:
            raise ValueError(f"{path} must be at least {min_length} character(s)")
        return value

    def _index_fields(self, state: SettingsState) -> dict[str, SettingsFieldState]:
        return {
            field.path: field
            for fields in state.sections.values()
            for field in fields
        }

    def _on_delete(self, _widget, _event) -> bool:
        if hasattr(self._window, "hide"):
            self._window.hide()
        return True


def _import_gtk() -> Any:
    import gi

    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk

    return Gtk
