"""AppIndicator3 tray icon with dropdown menu."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def _import_gtk():
    """Lazy import GTK3 + AppIndicator3 (or Ayatana fork)."""
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk
    try:
        gi.require_version("AppIndicator3", "0.1")
        from gi.repository import AppIndicator3
    except ValueError:
        gi.require_version("AyatanaAppIndicator3", "0.1")
        from gi.repository import AyatanaAppIndicator3 as AppIndicator3
    return Gtk, AppIndicator3


class TrayIcon:
    """AppIndicator3 tray icon with status-driven menu."""

    def __init__(
        self,
        on_record_toggle: Callable[[], None],
        on_retry: Callable[[], None],
        on_history: Callable[[], None],
        on_quit: Callable[[], None],
        on_show_last: Callable[[], None] | None = None,
        on_recent_selected: Callable[[str], None] | None = None,
        on_recent_show: Callable[[], None] | None = None,
        on_sign_in: Callable[[], None] | None = None,
        on_upgrade: Callable[[], None] | None = None,
        on_settings: Callable[[], None] | None = None,
    ) -> None:
        Gtk, AppIndicator3 = _import_gtk()
        self._Gtk = Gtk
        from talk_to_tux.indicator.icons import ICON_IDLE, ICON_THEME_PATH

        self._indicator = AppIndicator3.Indicator.new(
            "talk-to-tux",
            ICON_IDLE,
            AppIndicator3.IndicatorCategory.APPLICATION_STATUS,
        )
        if hasattr(self._indicator, "set_icon_theme_path"):
            self._indicator.set_icon_theme_path(ICON_THEME_PATH)
        self._indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)

        self._on_record_toggle = on_record_toggle
        self._on_retry = on_retry
        self._on_history = on_history
        self._on_quit = on_quit
        self._on_show_last = on_show_last
        self._on_recent_selected = on_recent_selected
        self._on_recent_show = on_recent_show
        self._on_sign_in = on_sign_in
        self._on_upgrade = on_upgrade
        self._on_settings = on_settings

        self._status = "idle"
        self._has_last_transcript = False
        self._recent_menu_items: list = []  # track current submenu recent items
        self._menu = self._build_menu()
        self._indicator.set_menu(self._menu)
        self.set_status("idle")

    def _build_menu(self):
        Gtk = self._Gtk
        menu = Gtk.Menu()

        self._record_item = Gtk.MenuItem(label="Start Recording")
        self._record_item.connect("activate", lambda _: self._on_record_toggle())
        menu.append(self._record_item)

        menu.append(Gtk.SeparatorMenuItem())

        self._retry_item = Gtk.MenuItem(label="Retry Last")
        self._retry_item.connect("activate", lambda _: self._on_retry())
        self._retry_item.set_sensitive(False)
        menu.append(self._retry_item)

        self._show_last_item = Gtk.MenuItem(label="Show Last Transcript")
        if self._on_show_last is not None:
            self._show_last_item.connect("activate", lambda _: self._on_show_last())
        self._show_last_item.set_sensitive(False)
        menu.append(self._show_last_item)

        # --- History submenu ---
        menu.append(Gtk.SeparatorMenuItem())

        history_item = Gtk.MenuItem(label="History")
        self._history_submenu = Gtk.Menu()
        history_item.set_submenu(self._history_submenu)

        self._recent_placeholder = Gtk.MenuItem(label="(no recent transcripts)")
        self._recent_placeholder.set_sensitive(False)
        self._history_submenu.append(self._recent_placeholder)
        self._recent_menu_items = [self._recent_placeholder]

        self._history_sep = Gtk.SeparatorMenuItem()
        self._history_submenu.append(self._history_sep)

        self._view_all_item = Gtk.MenuItem(label="View All...")
        self._view_all_item.connect("activate", lambda _: self._on_history())
        self._history_submenu.append(self._view_all_item)

        menu.append(history_item)

        menu.append(Gtk.SeparatorMenuItem())

        # --- Hosted-mode account items (SL-0 stubs; hidden until SL-4 wires them) ---
        self._signin_item = Gtk.MenuItem(label="Sign in")
        if self._on_sign_in is not None:
            self._signin_item.connect("activate", lambda _: self._on_sign_in())
        menu.append(self._signin_item)

        self._quota_item = Gtk.MenuItem(label="Usage: —")
        self._quota_item.set_sensitive(False)
        menu.append(self._quota_item)

        self._capability_item = Gtk.MenuItem(label="Capabilities: unknown")
        self._capability_item.set_sensitive(False)
        menu.append(self._capability_item)

        self._upgrade_item = Gtk.MenuItem(label="Upgrade…")
        if self._on_upgrade is not None:
            self._upgrade_item.connect("activate", lambda _: self._on_upgrade())
        self._upgrade_item.set_no_show_all(True)
        self._upgrade_item.hide()
        menu.append(self._upgrade_item)

        menu.append(Gtk.SeparatorMenuItem())

        self._settings_item = Gtk.MenuItem(label="Settings...")
        if self._on_settings is not None:
            self._settings_item.connect("activate", lambda _: self._on_settings())
        menu.append(self._settings_item)

        menu.append(Gtk.SeparatorMenuItem())

        quit_item = Gtk.MenuItem(label="Quit")
        quit_item.connect("activate", lambda _: self._on_quit())
        menu.append(quit_item)

        # Populate recent items when History submenu is shown
        if self._on_recent_show is not None:
            self._history_submenu.connect("show", lambda _: self._on_recent_show())

        menu.show_all()
        # upgrade_item starts hidden; show_all would un-hide it, so re-hide after
        self._upgrade_item.hide()
        return menu

    def set_status(self, status: str) -> None:
        """Update icon and menu labels based on status."""
        from talk_to_tux.indicator.icons import STATUS_ICONS

        self._status = status
        icon_path = STATUS_ICONS.get(status)
        if icon_path:
            self._indicator.set_icon_full(icon_path, status)

        if status == "recording":
            self._record_item.set_label("Stop Recording")
            self._retry_item.set_sensitive(False)
            self._show_last_item.set_sensitive(False)
        elif status == "processing":
            self._record_item.set_label("Processing...")
            self._record_item.set_sensitive(False)
            self._retry_item.set_sensitive(False)
            self._show_last_item.set_sensitive(False)
        elif status == "error":
            self._record_item.set_label("Start Recording")
            self._record_item.set_sensitive(True)
            self._retry_item.set_sensitive(True)
            self._show_last_item.set_sensitive(self._has_last_transcript)
        else:  # idle
            self._record_item.set_label("Start Recording")
            self._record_item.set_sensitive(True)
            self._retry_item.set_sensitive(False)
            self._show_last_item.set_sensitive(self._has_last_transcript)

    def enable_show_last(self) -> None:
        """Enable the 'Show Last Transcript' menu item."""
        self._has_last_transcript = True
        if self._status in ("idle", "error"):
            self._show_last_item.set_sensitive(True)

    def populate_recent_items(self, items: list[tuple[str, str]]) -> None:
        """Populate the History submenu with (timestamp_label, full_text) items."""
        Gtk = self._Gtk
        submenu = self._history_submenu

        # Remove old dynamic items from the submenu
        for old_item in self._recent_menu_items:
            submenu.remove(old_item)
        self._recent_menu_items.clear()

        if not items:
            placeholder = Gtk.MenuItem(label="(no recent transcripts)")
            placeholder.set_sensitive(False)
            submenu.insert(placeholder, 0)
            placeholder.show()
            self._recent_menu_items.append(placeholder)
        else:
            for i, (ts_label, text) in enumerate(items):
                preview = text[:60] + "..." if len(text) > 60 else text
                preview = preview.replace("\n", " ")
                item = Gtk.MenuItem(label=f"{ts_label}  {preview}")
                final_text = text
                item.connect("activate", lambda _, t=final_text: self._on_recent_activated(t))
                submenu.insert(item, i)
                item.show()
                self._recent_menu_items.append(item)

    def _on_recent_activated(self, text: str) -> None:
        """Handle click on a Recent submenu entry."""
        if self._on_recent_selected is not None:
            self._on_recent_selected(text)

    @property
    def status(self) -> str:
        return self._status

    # --- Hosted-mode update methods (SL-0 stubs; SL-4 fills bodies) ---

    def update_hosted(self, identity: Any, api_mode: Any) -> None:
        """Mutate sign-in label and upgrade-item visibility. Runs on GTK thread."""
        try:
            from talk_to_tux.config import ApiMode
            if identity is not None and hasattr(identity, "email"):
                self._signin_item.set_label(f"Signed in as: {identity.email}")
            else:
                self._signin_item.set_label("Sign in")
            if api_mode == ApiMode.HOSTED:
                self._upgrade_item.show()
            else:
                self._upgrade_item.hide()
        except Exception:
            logger.debug("update_hosted failed", exc_info=True)

    def update_quota(self, snapshot: Any) -> None:
        """Format quota snapshot into _quota_item label. Runs on GTK thread.

        SL-0 stub: sets basic label.
        """
        try:
            if snapshot is None:
                self._quota_item.set_label("Usage: —")
            else:
                used = getattr(snapshot, "stt_hours_used", 0.0)
                limit = getattr(snapshot, "stt_hours_limit", None)
                if limit is None:
                    self._quota_item.set_label(f"Usage: {used:.1f} / unlimited")
                else:
                    self._quota_item.set_label(f"Usage: {used:.1f} / {limit:.1f} hrs")
        except Exception:
            logger.debug("update_quota failed", exc_info=True)

    def update_capabilities(self, summary: Any) -> None:
        """Update a compact desktop capability status row."""
        try:
            display_server = getattr(summary, "display_server", "unknown")
            confidence = getattr(summary, "confidence", "unknown")
            warnings = list(getattr(summary, "warnings", []) or [])
            suffix = "degraded" if warnings else confidence
            self._capability_item.set_label(f"Capabilities: {display_server} ({suffix})")
        except Exception:
            logger.debug("update_capabilities failed", exc_info=True)
