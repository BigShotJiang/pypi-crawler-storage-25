"""PNG icon paths for the GNOME panel indicator."""
from __future__ import annotations

from pathlib import Path

_ICON_DIR = Path(__file__).parent / "icons"

ICON_THEME_PATH = str(_ICON_DIR)

ICON_IDLE = str(_ICON_DIR / "ttt-idle.png")
ICON_RECORDING = str(_ICON_DIR / "ttt-recording.png")
ICON_PROCESSING = str(_ICON_DIR / "ttt-processing.png")
ICON_ERROR = str(_ICON_DIR / "ttt-error.png")
ICON_ARMED = str(_ICON_DIR / "ttt-armed.png")

STATUS_ICONS: dict[str, str] = {
    "idle": ICON_IDLE,
    "recording": ICON_RECORDING,
    "processing": ICON_PROCESSING,
    "error": ICON_ERROR,
    "armed": ICON_ARMED,
}
