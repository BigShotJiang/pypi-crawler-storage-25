from __future__ import annotations

import io
import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field

import httpx

from talk_to_tux.local_inference_health import LocalInferenceHealthResult
from talk_to_tux.providers import DEFAULT_STT_PROVIDER_CHAIN, STT_PROVIDER_IDS

logger = logging.getLogger(__name__)

_LOCAL_STT_PROVIDERS = {"gpu_server", "local_whisper"}


def _error_type(exc: Exception) -> str:
    return exc.__class__.__name__


@dataclass
class TranscriptionResult:
    text: str
    source: str  # provider name from the chain
    chain_position: int = 0
    chain_length: int = 1
    failures: list[str] = field(default_factory=list)
    configured_chain: list[str] = field(default_factory=list)
    effective_chain: list[str] = field(default_factory=list)
    skipped_providers: list[dict[str, object]] = field(default_factory=list)
    routing_local_health: dict[str, dict[str, object]] = field(default_factory=dict)


class STTClient:
    def __init__(
        self,
        gpu_server_url: str = "http://localhost:8000",
        gpu_server_timeout: float = 10.0,
        openai_api_key: str | None = None,
        openai_model: str = "whisper-1",
        groq_api_key: str | None = None,
        groq_model: str = "whisper-large-v3-turbo",
        google_api_key: str | None = None,
        google_model: str = "gemini-2.5-flash",
        elevenlabs_api_key: str | None = None,
        elevenlabs_model: str = "scribe_v2",
        local_whisper_url: str = "http://win:8003/v1",
        local_whisper_timeout: float = 5.0,
        local_whisper_model: str = "whisper-1",
        stt_providers: str | list[str] | None = None,
        gpu_server_probe_timeout: float = 1.0,
        local_whisper_probe_timeout: float = 1.0,
        local_health_snapshot: Callable[[], dict[str, LocalInferenceHealthResult]] | None = None,
    ) -> None:
        self._gpu_server_url = gpu_server_url.rstrip("/")
        self._gpu_server_timeout = gpu_server_timeout
        self._gpu_server_probe_timeout = gpu_server_probe_timeout
        self._openai_api_key = openai_api_key
        self._openai_model = openai_model
        self._groq_api_key = groq_api_key
        self._groq_model = groq_model
        self._google_api_key = google_api_key
        self._google_model = google_model
        self._elevenlabs_api_key = elevenlabs_api_key
        self._elevenlabs_model = elevenlabs_model
        self._local_whisper_model = local_whisper_model
        self._local_whisper_url = local_whisper_url.rstrip("/")
        self._local_whisper_probe_timeout = local_whisper_probe_timeout
        self._local_health_snapshot = local_health_snapshot
        self._http = httpx.AsyncClient(timeout=gpu_server_timeout)
        self._elevenlabs_http = httpx.AsyncClient(timeout=30.0) if elevenlabs_api_key else None
        self._local_whisper_http: httpx.AsyncClient | None = None
        self._openai_client = None
        self._groq_client = None

        self._configured_chain = self._normalize_provider_list(stt_providers)

        self._chain: list[tuple[str, Callable]] = []
        for provider in self._configured_chain:
            if provider == "gpu_server":
                self._chain.append((provider, self._transcribe_gpu))
            elif provider == "local_whisper":
                self._local_whisper_http = httpx.AsyncClient(timeout=local_whisper_timeout)
                self._chain.append((provider, self._transcribe_local_whisper))
            elif provider == "elevenlabs" and elevenlabs_api_key:
                self._chain.append((provider, self._transcribe_elevenlabs))
            elif provider == "groq" and groq_api_key:
                from openai import AsyncOpenAI

                self._groq_client = AsyncOpenAI(
                    base_url="https://api.groq.com/openai/v1",
                    api_key=groq_api_key,
                )
                self._chain.append((provider, self._transcribe_groq))
            elif provider == "openai" and openai_api_key:
                from openai import AsyncOpenAI

                self._openai_client = AsyncOpenAI(api_key=openai_api_key)
                self._chain.append((provider, self._transcribe_openai))
            elif provider == "google" and google_api_key:
                self._chain.append((provider, self._transcribe_google))

    def _snapshot_local_health(self) -> dict[str, LocalInferenceHealthResult]:
        if self._local_health_snapshot is None:
            return {}
        snapshot = self._local_health_snapshot()
        return {
            provider: result
            for provider, result in snapshot.items()
            if provider in _LOCAL_STT_PROVIDERS and isinstance(result, LocalInferenceHealthResult)
        }

    @staticmethod
    def _health_metadata(result: LocalInferenceHealthResult | None) -> dict[str, object]:
        if result is None:
            return {
                "status": "unknown",
                "stale": True,
                "skip_eligible": False,
            }
        return {
            "status": result.status,
            "stale": result.stale,
            "skip_eligible": result.skip_eligible,
            "latency_ms": result.latency_ms,
            "last_checked_at": result.last_checked_at,
            "cooldown_until": result.cooldown_until,
            "reason": result.reason,
        }

    @staticmethod
    def _skip_entry(provider: str, result: LocalInferenceHealthResult | None, reason: str) -> dict[str, object]:
        entry = {
            "provider": provider,
            "reason": reason,
            "status": "unknown" if result is None else result.status,
            "stale": True if result is None else result.stale,
            "skip_eligible": False if result is None else result.skip_eligible,
        }
        if result is not None and result.cooldown_until is not None:
            entry["cooldown_until"] = result.cooldown_until
        return entry

    def _build_effective_chain(
        self,
    ) -> tuple[list[tuple[str, Callable]], list[dict[str, object]], dict[str, dict[str, object]]]:
        snapshot = self._snapshot_local_health()
        skipped: list[dict[str, object]] = []
        effective: list[tuple[str, Callable]] = []
        routing_local_health = {
            provider: self._health_metadata(snapshot.get(provider))
            for provider in self._configured_chain
            if provider in _LOCAL_STT_PROVIDERS
        }
        for provider, method in self._chain:
            health = snapshot.get(provider)
            if provider in _LOCAL_STT_PROVIDERS and health is not None and not health.stale and health.skip_eligible:
                skipped.append(self._skip_entry(provider, health, "cooldown"))
                continue
            effective.append((provider, method))
        return effective, skipped, routing_local_health

    async def _preflight_local_provider(self, provider: str) -> bool:
        started = time.perf_counter()
        try:
            if provider == "gpu_server":
                response = await self._http.get(
                    f"{self._gpu_server_url}/health",
                    timeout=self._gpu_server_probe_timeout,
                )
            elif provider == "local_whisper":
                if self._local_whisper_http is None:
                    return False
                response = await self._local_whisper_http.get(
                    f"{self._local_whisper_url}/models",
                    timeout=self._local_whisper_probe_timeout,
                )
            else:
                return True
            ok = response.status_code == 200
            logger.debug(
                "STT local preflight provider=%s ok=%s duration_ms=%.1f",
                provider,
                ok,
                (time.perf_counter() - started) * 1000,
            )
            return ok
        except Exception:
            logger.debug("STT local preflight failed provider=%s", provider, exc_info=True)
            return False

    @staticmethod
    def _normalize_provider_list(stt_providers: str | list[str] | None) -> list[str]:
        if stt_providers is None:
            return list(DEFAULT_STT_PROVIDER_CHAIN)
        if isinstance(stt_providers, str):
            provider_list = [p.strip() for p in stt_providers.split(",") if p.strip()]
        else:
            provider_list = list(stt_providers)
        if not provider_list:
            raise ValueError("stt_providers must not be empty")
        unknown = sorted(set(provider_list) - set(STT_PROVIDER_IDS))
        if unknown:
            raise ValueError(f"Unknown STT providers: {unknown}")
        return provider_list

    async def _transcribe_elevenlabs(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._elevenlabs_api_key is None or self._elevenlabs_http is None:
            raise ValueError("ElevenLabs client not configured (no API key provided)")
        data: dict[str, str] = {"model_id": self._elevenlabs_model}
        if keyterms:
            data["keyterms"] = json.dumps(keyterms)
        response = await self._elevenlabs_http.post(
            "https://api.elevenlabs.io/v1/speech-to-text",
            headers={"xi-api-key": self._elevenlabs_api_key},
            files={"file": ("audio.wav", wav_bytes, "audio/wav")},
            data=data,
        )
        response.raise_for_status()
        return response.json()["text"]

    async def _transcribe_local_whisper(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._local_whisper_http is None:
            raise ValueError("local_whisper client not configured")
        data: dict[str, str] = {"model": self._local_whisper_model}
        if keyterms:
            data["prompt"] = "Terms: " + ", ".join(keyterms)
        response = await self._local_whisper_http.post(
            f"{self._local_whisper_url}/audio/transcriptions",
            files={"file": ("audio.wav", wav_bytes, "audio/wav")},
            data=data,
        )
        response.raise_for_status()
        return response.json()["text"]

    async def _transcribe_gpu(
        self,
        wav_bytes: bytes,
        keyterms: list[str] | None = None,
        on_partial: Callable[[str], None] | None = None,
        initial_prompt: str | None = None,
    ) -> str:
        form_data: dict[str, str] = {}
        if initial_prompt:
            form_data["initial_prompt"] = initial_prompt

        # Try SSE streaming endpoint first
        stream_url = f"{self._gpu_server_url}/transcribe/stream"
        try:
            accumulated: list[str] = []
            async with self._http.stream(
                "POST",
                stream_url,
                files={"file": ("audio.wav", wav_bytes, "audio/wav")},
                data=form_data,
            ) as response:
                if response.status_code == 404:
                    # Old server — fall through to batch
                    raise httpx.HTTPStatusError(
                        "404", request=response.request, response=response
                    )
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:]
                    if payload == "[DONE]":
                        break
                    if payload.startswith("{"):
                        seg = json.loads(payload)
                        accumulated.append(seg["text"])
                        if on_partial and accumulated:
                            on_partial(" ".join(accumulated))
            return " ".join(accumulated)
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code != 404:
                raise
            logger.debug("GPU server has no /transcribe/stream, falling back to batch")
        except Exception:
            raise

        # Batch fallback
        response = await self._http.post(
            f"{self._gpu_server_url}/transcribe",
            files={"file": ("audio.wav", wav_bytes, "audio/wav")},
            data=form_data,
        )
        response.raise_for_status()
        return response.json()["text"]

    async def _transcribe_openai(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._openai_client is None:
            raise ValueError("OpenAI client not configured (no API key provided)")
        buf = io.BytesIO(wav_bytes)
        buf.name = "audio.wav"
        kwargs: dict = {"model": self._openai_model, "file": buf}
        if keyterms:
            kwargs["prompt"] = "Terms: " + ", ".join(keyterms)
        transcript = await self._openai_client.audio.transcriptions.create(**kwargs)
        return transcript.text

    async def _transcribe_groq(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        if self._groq_client is None:
            raise ValueError("Groq client not configured (no API key provided)")
        buf = io.BytesIO(wav_bytes)
        buf.name = "audio.wav"
        kwargs: dict = {"model": self._groq_model, "file": buf}
        if keyterms:
            kwargs["prompt"] = "Terms: " + ", ".join(keyterms)
        transcript = await self._groq_client.audio.transcriptions.create(**kwargs)
        return transcript.text

    async def _transcribe_google(
        self, wav_bytes: bytes, keyterms: list[str] | None = None,
    ) -> str:
        import base64

        import baml_py
        from talk_to_tux.baml_client.async_client import b

        audio_b64 = base64.b64encode(wav_bytes).decode("ascii")
        audio = baml_py.Audio.from_base64("audio/wav", audio_b64)
        registry = baml_py.ClientRegistry()
        registry.add_llm_client(
            name="GeminiSTT",
            provider="google-ai",
            options={
                "model": self._google_model,
                "api_key": self._google_api_key,
            },
        )
        return await b.TranscribeAudio(
            audio=audio,
            hint=None,
            baml_options={
                "client_registry": registry,
                "client": "GeminiSTT",
            },
        )

    async def transcribe(
        self,
        wav_bytes: bytes,
        keyterms: list[str] | None = None,
        on_partial: Callable[[str], None] | None = None,
        initial_prompt: str | None = None,
    ) -> TranscriptionResult:
        if not self._chain:
            raise RuntimeError("No STT providers configured")
        configured_chain = [name for name, _ in self._chain]
        effective_chain, skipped_providers, routing_local_health = self._build_effective_chain()
        effective_names = [name for name, _ in effective_chain]
        errors: list[tuple[str, Exception]] = []
        for name, method in list(effective_chain):
            try:
                health = None
                if name in _LOCAL_STT_PROVIDERS:
                    health = self._snapshot_local_health().get(name)
                if (
                    self._local_health_snapshot is not None
                    and name in _LOCAL_STT_PROVIDERS
                    and (health is None or health.stale)
                ):
                    if not await self._preflight_local_provider(name):
                        effective_names = [provider for provider in effective_names if provider != name]
                        skipped_providers.append(self._skip_entry(name, health, "preflight_failed"))
                        continue
                if name == "gpu_server":
                    text = await method(
                        wav_bytes,
                        keyterms=keyterms,
                        on_partial=on_partial,
                        initial_prompt=initial_prompt,
                    )
                else:
                    text = await method(wav_bytes, keyterms=keyterms)
                chain_position = effective_names.index(name)
                return TranscriptionResult(
                    text=text,
                    source=name,
                    chain_position=chain_position,
                    chain_length=len(effective_names),
                    failures=[n for n, _ in errors],
                    configured_chain=configured_chain,
                    effective_chain=effective_names,
                    skipped_providers=skipped_providers,
                    routing_local_health=routing_local_health,
                )
            except Exception as exc:
                logger.warning("STT provider failed provider=%s error_type=%s", name, _error_type(exc))
                errors.append((name, exc))
        if not errors and not effective_names:
            raise RuntimeError("No STT providers available after health routing")
        detail = ", ".join(f"{name}: {_error_type(exc)}" for name, exc in errors)
        raise RuntimeError(f"All STT providers failed. {detail}")

    async def health_check(self) -> bool:
        try:
            response = await self._http.get(f"{self._gpu_server_url}/health")
            return response.status_code == 200
        except Exception:
            return False

    async def close(self) -> None:
        await self._http.aclose()
        if self._elevenlabs_http is not None:
            await self._elevenlabs_http.aclose()
        if self._local_whisper_http is not None:
            await self._local_whisper_http.aclose()
