"""Side-button (e.g. BTN_SIDE/BTN_EXTRA thumb buttons) listener via evdev.

Supports dual-button trigger: pressing EITHER button starts recording,
releasing ALL buttons stops recording.  Optionally grabs the physical device
and forwards non-target events through a uinput virtual device so the side
buttons don't leak to the desktop (browser back/forward, etc.).
"""
from __future__ import annotations

import asyncio
import atexit
import glob
import logging
import time
from typing import Awaitable, Callable

from evdev import InputDevice, UInput, ecodes

logger = logging.getLogger(__name__)

# Default buttons: BTN_SIDE (275) + BTN_EXTRA (276)
_DEFAULT_BUTTON_CODES = [ecodes.BTN_SIDE, ecodes.BTN_EXTRA]


class SideButtonListener:
    """Listens for configurable mouse side buttons (default BTN_SIDE + BTN_EXTRA).

    Either button starts recording; ALL buttons released stops recording.
    When ``grab=True``, the physical device is grabbed exclusively and all
    non-target events are forwarded via a uinput virtual device so normal
    mouse operation (movement, clicks, scroll) is preserved.

    Satisfies the InputListener protocol.
    """

    _HEARTBEAT_INTERVAL = 2.0  # seconds between stuck-button checks

    def __init__(
        self,
        on_start: Callable[[], Awaitable[None]],
        on_stop: Callable[[], Awaitable[None]],
        device_path: str | None = None,
        device_name: str | None = None,
        button_codes: list[int] | None = None,
        grab: bool = True,
        on_disconnect: Callable[[], Awaitable[None]] | None = None,
        on_reconnect: Callable[[], Awaitable[None]] | None = None,
    ) -> None:
        self._on_start = on_start
        self._on_stop = on_stop
        self._button_codes: set[int] = set(button_codes or _DEFAULT_BUTTON_CODES)
        self._grab = grab
        self._grab_orig = grab  # remember original intent for reconnect
        self._on_disconnect_cb = on_disconnect
        self._on_reconnect_cb = on_reconnect
        self._device_name = device_name

        # Per-button pressed state
        self._btn_states: dict[int, bool] = {code: False for code in self._button_codes}
        self.last_trigger_ts: float = 0.0  # perf_counter timestamp of last button DOWN
        self.last_trigger_kernel_ts: float = 0.0  # kernel event timestamp

        # Resolve device path eagerly so callers can catch RuntimeError
        # during construction and fall back to keyboard.
        # Priority: explicit path > name-based lookup > auto-detect
        self._device_path = device_path or self._find_mouse_with_buttons(
            self._button_codes, device_name=device_name,
        )
        # Remember actual device name for reconnect (survives path changes)
        if self._device_name is None:
            try:
                _probe = InputDevice(self._device_path)
                self._device_name = _probe.name
                _probe.close()
            except OSError:
                pass

        self._device: InputDevice | None = None
        self._uinput: UInput | None = None
        self._task: asyncio.Task | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._started = False
        self._restart_lock: asyncio.Lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Legacy compat: accept single button_code kwarg
    # ------------------------------------------------------------------

    @classmethod
    def _from_legacy(
        cls,
        on_start: Callable[[], Awaitable[None]],
        on_stop: Callable[[], Awaitable[None]],
        device_path: str | None = None,
        button_code: int = ecodes.BTN_EXTRA,
        grab: bool = True,
    ) -> SideButtonListener:
        return cls(
            on_start=on_start,
            on_stop=on_stop,
            device_path=device_path,
            button_codes=[button_code],
            grab=grab,
        )

    # ------------------------------------------------------------------
    # Device discovery
    # ------------------------------------------------------------------

    # Virtual device names created by talk-to-tux uinput passthrough
    _VIRTUAL_DEVICE_NAMES = {"talk-to-tux-mouse", "Mouse passthrough", "Mouse passthrough (absolute)"}

    @staticmethod
    def _find_mouse_with_buttons(
        button_codes: set[int],
        *,
        device_name: str | None = None,
        strict: bool = False,
    ) -> str:
        """Find mouse device with target buttons.

        When *device_name* is given, only devices whose name contains
        that substring (case-insensitive) are considered.  This is
        stable across reboots/USB-port changes unlike /dev/input/eventN
        paths.

        When *strict* is True and *device_name* is set, raise RuntimeError
        instead of falling back to auto-detect.  Used during reconnect to
        avoid grabbing the wrong device.

        Virtual passthrough devices (our own uinput) are always excluded.
        """
        candidates: list[tuple[str, str]] = []
        for path in sorted(glob.glob("/dev/input/event*")):
            try:
                dev = InputDevice(path)
                name = dev.name
                caps = dev.capabilities()
                keys = caps.get(ecodes.EV_KEY, [])
                dev.close()
                # Skip our own virtual passthrough devices
                if name in SideButtonListener._VIRTUAL_DEVICE_NAMES:
                    continue
                if (
                    ecodes.EV_REL in caps
                    and ecodes.REL_X in caps.get(ecodes.EV_REL, [])
                    and button_codes & set(keys)
                ):
                    candidates.append((path, name))
            except (PermissionError, OSError):
                continue

        # If device_name filter provided, narrow candidates
        if device_name:
            needle = device_name.lower()
            filtered = [(p, n) for p, n in candidates if needle in n.lower()]
            if filtered:
                candidates = filtered
            elif strict:
                raise RuntimeError(
                    f"No mouse device matching name {device_name!r} found"
                )
            else:
                logger.warning(
                    "No mouse device matching name %r found; falling back to auto-detect",
                    device_name,
                )

        if not candidates:
            btn_names = [ecodes.BTN.get(c, str(c)) for c in sorted(button_codes)]
            raise RuntimeError(
                f"No mouse device found with buttons {btn_names}"
            )
        # Prefer physical devices with "Mouse" in the name
        candidates.sort(key=lambda c: ("Mouse" not in c[1], c[0]))
        path, name = candidates[0]
        logger.info("Side-button device: %s (%s)", path, name)
        return path

    # Keep old static method name for backward compat in tests
    @staticmethod
    def _find_mouse_with_button(button_code: int) -> str:
        return SideButtonListener._find_mouse_with_buttons({button_code})

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    async def _safe_callback(self, fn: Callable[[], Awaitable[None]], name: str) -> None:
        """Run an async callback, catching exceptions to prevent unhandled task errors."""
        try:
            await fn()
        except Exception:
            logger.exception("%s callback failed", name)

    # ------------------------------------------------------------------
    # Event loop
    # ------------------------------------------------------------------

    async def _on_disconnect(self) -> None:
        """Handle device disconnection: cancel in-flight recording, clean up, notify."""
        # If any buttons were held, fire on_stop to cancel in-flight recording
        if any(self._btn_states.values()):
            logger.warning("Device disconnected while buttons held — firing on_stop")
            for code in self._button_codes:
                self._btn_states[code] = False
            await self._safe_callback(self._on_stop, "on_stop")
        # Reset button states
        self._btn_states = {code: False for code in self._button_codes}
        self._cleanup_device()
        if self._on_disconnect_cb is not None:
            await self._safe_callback(self._on_disconnect_cb, "on_disconnect")

    async def _event_loop(self) -> None:
        if self._device is None:
            raise RuntimeError("Cannot run event loop without a device; call start() first")
        while True:  # outer reconnect loop
            try:
                async for event in self._device.async_read_loop():
                    if event.type == ecodes.EV_KEY and event.code in self._button_codes:
                        btn_name = ecodes.BTN.get(event.code, event.code)
                        if event.value == 1:  # button down
                            was_any_down = any(self._btn_states.values())
                            self._btn_states[event.code] = True
                            if not was_any_down:
                                logger.debug("Button %s DOWN → on_start", btn_name)
                                self.last_trigger_ts = time.perf_counter()
                                # Kernel event timestamp for measuring true latency
                                self.last_trigger_kernel_ts = event.timestamp()
                                asyncio.create_task(self._safe_callback(self._on_start, "on_start"))
                            else:
                                logger.debug("Button %s DOWN (already held)", btn_name)
                        elif event.value == 0:  # button up
                            self._btn_states[event.code] = False
                            if not any(self._btn_states.values()):
                                logger.debug("Button %s UP → on_stop", btn_name)
                                asyncio.create_task(self._safe_callback(self._on_stop, "on_stop"))
                            else:
                                logger.debug("Button %s UP (others still held)", btn_name)
                        elif event.value == 2:  # autorepeat
                            logger.debug("Button %s REPEAT (ignored)", btn_name)
                        # Target button events are NOT forwarded (swallowed)
                        continue

                    # Forward all non-target events to virtual device
                    if self._uinput is not None:
                        self._uinput.write_event(event)
                        self._uinput.syn()
                # Generator exhausted — only happens in tests; real async_read_loop blocks forever
                return
            except OSError as e:
                logger.error("Side-button device disconnected: %s", e)
                await self._on_disconnect()
                # Poll for reconnection
                while True:
                    await asyncio.sleep(2)
                    try:
                        self._device_path = self._find_mouse_with_buttons(
                            self._button_codes,
                            device_name=self._device_name,
                            strict=True,
                        )
                        self._open_and_grab()
                        logger.info("Side-button device reconnected: %s", self._device_path)
                        if self._on_reconnect_cb is not None:
                            await self._safe_callback(self._on_reconnect_cb, "on_reconnect")
                        break  # back to outer event-reading loop
                    except (RuntimeError, OSError):
                        pass  # device not back yet

    def _verify_button_state(self) -> None:
        """Reconcile shadow button state with kernel ground truth via active_keys()."""
        if self._device is None:
            return
        try:
            active = set(self._device.active_keys())
        except OSError:
            return
        actually_held = active & self._button_codes
        expected_held = {c for c, v in self._btn_states.items() if v}
        if actually_held != expected_held:
            logger.warning(
                "Shadow state drift: expected %s held, kernel reports %s",
                expected_held, actually_held,
            )
            for code in self._button_codes:
                self._btn_states[code] = code in actually_held

    # ------------------------------------------------------------------
    # Heartbeat
    # ------------------------------------------------------------------

    async def _heartbeat(self) -> None:
        """Periodic check: detect stuck recording from lost UP events."""
        while True:
            await asyncio.sleep(self._HEARTBEAT_INTERVAL)
            await self._check_stuck_buttons()

    async def _check_stuck_buttons(self) -> None:
        """If we think buttons are held but kernel disagrees, force stop."""
        if not any(self._btn_states.values()):
            return
        if self._device is None:
            return
        try:
            active = set(self._device.active_keys())
        except OSError:
            return
        if not (active & self._button_codes):
            # Grace period: let pending UP events drain from the event queue
            # before forcing stop — avoids false positive on quick taps
            await asyncio.sleep(0.1)
            # Re-check: if natural UP event corrected shadow state, no action needed
            if not any(self._btn_states.values()):
                return
            logger.warning("Heartbeat: buttons not held, forcing stop")
            for code in self._button_codes:
                self._btn_states[code] = False
            asyncio.create_task(self._safe_callback(self._on_stop, "on_stop"))

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _open_and_grab(self) -> None:
        """Open the evdev device and optionally grab + create uinput passthrough."""
        self._device = InputDevice(self._device_path)
        self._grab = self._grab_orig  # restore original grab intent on reconnect

        if self._grab:
            try:
                self._uinput = UInput.from_device(
                    self._device, name="talk-to-tux-mouse"
                )
                self._device.grab()
                atexit.register(self._atexit_cleanup)
                logger.info("Grabbed device %s, forwarding via uinput", self._device_path)
            except (OSError, PermissionError) as e:
                logger.warning(
                    "Cannot grab device (uinput unavailable): %s — "
                    "side buttons may leak to desktop",
                    e,
                )
                self._uinput = None
                self._grab = False

    async def start(self) -> None:
        self._open_and_grab()
        self._task = asyncio.create_task(self._event_loop())
        self._heartbeat_task = asyncio.create_task(self._heartbeat())
        self._started = True

    async def stop(self) -> None:
        self._started = False
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
            self._heartbeat_task = None
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        self._cleanup_device()

    def grab_path_needs_recovery(self) -> bool:
        """Return True when a grabbed listener has lost its active passthrough path."""
        if not self._started or not self._grab_orig:
            return False
        if self._device is None or self._uinput is None:
            return True
        return self._task is None or self._task.done()

    async def restart_grab_path(self) -> bool:
        """Rebuild the grabbed device + uinput passthrough without restarting the app."""
        if not self._started or not self._grab_orig:
            return False
        if any(self._btn_states.values()):
            logger.debug("Skipping side-button restart while buttons are held")
            return False

        async with self._restart_lock:
            current = asyncio.current_task()
            if self._task is not None and self._task is current:
                logger.debug("Skipping side-button restart from listener task itself")
                return False

            old_task = self._task
            self._task = None
            if old_task is not None:
                old_task.cancel()
                try:
                    await old_task
                except asyncio.CancelledError:
                    pass

            self._cleanup_device()
            self._btn_states = {code: False for code in self._button_codes}
            try:
                self._open_and_grab()
            except Exception:
                logger.warning("Failed to restart side-button passthrough", exc_info=True)
                return False

            self._task = asyncio.create_task(self._event_loop())
            logger.info("Restarted side-button passthrough on %s", self._device_path)
            return True

    def _cleanup_device(self) -> None:
        """Ungrab and close device + uinput (idempotent)."""
        if self._device is not None:
            try:
                if self._grab:
                    self._device.ungrab()
            except OSError:
                pass
            self._device.close()
            self._device = None
        if self._uinput is not None:
            try:
                self._uinput.close()
            except OSError:
                pass
            self._uinput = None

    def _atexit_cleanup(self) -> None:
        """Safety net: ungrab on interpreter shutdown / crash."""
        self._cleanup_device()
