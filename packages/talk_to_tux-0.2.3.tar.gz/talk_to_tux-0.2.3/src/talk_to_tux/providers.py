from __future__ import annotations

from dataclasses import dataclass
from typing import Any

BYOK_PROVIDER_IDS = ("groq", "openai", "google", "elevenlabs")
STT_PROVIDER_IDS = ("gpu_server", "local_whisper", "groq", "openai", "google", "elevenlabs")
REWRITE_PROVIDER_IDS = ("local_ai", "groq", "gemini", "ollama")

DEFAULT_STT_PROVIDER_CHAIN = ("gpu_server", "groq", "openai", "google")
REWRITE_FALLBACK_CHAIN = ("local_ai", "groq", "gemini", "ollama")

BYOK_PROVIDER_SECRET_FIELDS = {
    "groq": "groq_api_key",
    "openai": "openai_api_key",
    "google": "google_api_key",
    "elevenlabs": "elevenlabs_api_key",
}

BYOK_SECRET_ENV_NAMES = {
    "groq_api_key": "TTT_GROQ_API_KEY",
    "openai_api_key": "TTT_OPENAI_API_KEY",
    "google_api_key": "TTT_GOOGLE_API_KEY",
    "elevenlabs_api_key": "TTT_ELEVENLABS_API_KEY",
}

REWRITE_PROVIDER_CLIENT_NAMES = {
    "local_ai": "LocalAI",
    "groq": "Groq",
    "gemini": "Gemini",
    "ollama": "Ollama",
}

REWRITE_PROVIDER_ENV_VARS = {
    "groq": "GROQ_API_KEY",
    "gemini": "GOOGLE_API_KEY",
}

_STT_PROVIDER_SECRET_FIELDS = {
    "gpu_server": None,
    "local_whisper": None,
    "groq": "groq_api_key",
    "openai": "openai_api_key",
    "google": "google_api_key",
    "elevenlabs": "elevenlabs_api_key",
}


@dataclass(frozen=True, slots=True)
class ModelOption:
    provider_id: str
    model_id: str
    label: str
    purpose: str
    input_modalities: tuple[str, ...]
    output_modalities: tuple[str, ...]
    default_rank: int
    is_preview: bool
    is_deprecated: bool
    source_note: str


_MODEL_OPTIONS = (
    ModelOption(
        provider_id="openai",
        model_id="gpt-4o-transcribe",
        label="GPT-4o Transcribe",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="OpenAI speech-to-text guide and model docs",
    ),
    ModelOption(
        provider_id="openai",
        model_id="gpt-4o-mini-transcribe",
        label="GPT-4o mini Transcribe",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="OpenAI speech-to-text guide and model docs",
    ),
    ModelOption(
        provider_id="openai",
        model_id="whisper-1",
        label="Whisper-1",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=2,
        is_preview=False,
        is_deprecated=False,
        source_note="OpenAI speech-to-text guide legacy-compatible model",
    ),
    ModelOption(
        provider_id="groq",
        model_id="whisper-large-v3-turbo",
        label="Whisper Large V3 Turbo",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="Groq speech-to-text docs",
    ),
    ModelOption(
        provider_id="groq",
        model_id="whisper-large-v3",
        label="Whisper Large V3",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="Groq speech-to-text docs",
    ),
    ModelOption(
        provider_id="elevenlabs",
        model_id="scribe_v2",
        label="Scribe v2",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="ElevenLabs speech-to-text docs",
    ),
    ModelOption(
        provider_id="elevenlabs",
        model_id="scribe_v1",
        label="Scribe v1",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="ElevenLabs model guide marks v1 as outclassed by v2",
    ),
    ModelOption(
        provider_id="google",
        model_id="gemini-2.5-flash",
        label="Gemini 2.5 Flash",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="Gemini audio understanding and model docs",
    ),
    ModelOption(
        provider_id="google",
        model_id="gemini-2.5-flash-lite",
        label="Gemini 2.5 Flash-Lite",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="Gemini audio understanding and model docs",
    ),
    ModelOption(
        provider_id="google",
        model_id="gemini-2.5-pro",
        label="Gemini 2.5 Pro",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=2,
        is_preview=False,
        is_deprecated=False,
        source_note="Gemini audio understanding and model docs",
    ),
    ModelOption(
        provider_id="local_whisper",
        model_id="whisper-1",
        label="Whisper-1",
        purpose="stt",
        input_modalities=("audio",),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="Local OpenAI-compatible transcription default suggestion",
    ),
    ModelOption(
        provider_id="openai",
        model_id="gpt-4.1",
        label="GPT-4.1",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="OpenAI model docs",
    ),
    ModelOption(
        provider_id="openai",
        model_id="gpt-4.1-mini",
        label="GPT-4.1 mini",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="OpenAI model docs",
    ),
    ModelOption(
        provider_id="openai",
        model_id="gpt-4.5-preview",
        label="GPT-4.5 Preview",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=2,
        is_preview=True,
        is_deprecated=True,
        source_note="OpenAI model docs",
    ),
    ModelOption(
        provider_id="groq",
        model_id="meta-llama/llama-4-scout-17b-16e-instruct",
        label="Llama 4 Scout 17B 16E",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=0,
        is_preview=True,
        is_deprecated=False,
        source_note="Groq model docs",
    ),
    ModelOption(
        provider_id="gemini",
        model_id="gemini-2.5-flash-lite",
        label="Gemini 2.5 Flash-Lite",
        purpose="rewrite",
        input_modalities=("text", "image", "audio", "video", "pdf"),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="Gemini model docs",
    ),
    ModelOption(
        provider_id="gemini",
        model_id="gemini-2.5-flash",
        label="Gemini 2.5 Flash",
        purpose="rewrite",
        input_modalities=("text", "image", "audio", "video"),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="Gemini model docs",
    ),
    ModelOption(
        provider_id="gemini",
        model_id="gemini-2.5-pro",
        label="Gemini 2.5 Pro",
        purpose="rewrite",
        input_modalities=("text", "image", "audio", "video", "pdf"),
        output_modalities=("text",),
        default_rank=2,
        is_preview=False,
        is_deprecated=False,
        source_note="Gemini model docs",
    ),
    ModelOption(
        provider_id="gemini",
        model_id="gemini-2.5-flash-lite-preview-09-2025",
        label="Gemini 2.5 Flash-Lite Preview",
        purpose="rewrite",
        input_modalities=("text", "image", "audio", "video", "pdf"),
        output_modalities=("text",),
        default_rank=3,
        is_preview=True,
        is_deprecated=False,
        source_note="Gemini model docs",
    ),
    ModelOption(
        provider_id="local_ai",
        model_id="qwen3-vl:8b",
        label="Qwen3-VL 8B",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="Ollama library vision model family",
    ),
    ModelOption(
        provider_id="local_ai",
        model_id="llama3.2-vision:11b",
        label="Llama 3.2 Vision 11B",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="Ollama library vision model family",
    ),
    ModelOption(
        provider_id="ollama",
        model_id="qwen3-vl:8b",
        label="Qwen3-VL 8B",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=0,
        is_preview=False,
        is_deprecated=False,
        source_note="Ollama library vision model family",
    ),
    ModelOption(
        provider_id="ollama",
        model_id="llama3.2-vision:11b",
        label="Llama 3.2 Vision 11B",
        purpose="rewrite",
        input_modalities=("text", "image"),
        output_modalities=("text",),
        default_rank=1,
        is_preview=False,
        is_deprecated=False,
        source_note="Ollama library vision model family",
    ),
)

_MODEL_OPTIONS_BY_PROVIDER_PURPOSE: dict[tuple[str, str], tuple[ModelOption, ...]] = {}
_MODEL_OPTIONS_BY_PROVIDER_PURPOSE_MODEL: dict[tuple[str, str, str], ModelOption] = {}
_MODEL_OPTIONS_BY_PROVIDER_MODEL: dict[tuple[str, str], ModelOption] = {}

for _option in _MODEL_OPTIONS:
    provider_purpose_key = (_option.provider_id, _option.purpose)
    _MODEL_OPTIONS_BY_PROVIDER_PURPOSE[provider_purpose_key] = (
        *_MODEL_OPTIONS_BY_PROVIDER_PURPOSE.get(provider_purpose_key, ()),
        _option,
    )
    _MODEL_OPTIONS_BY_PROVIDER_PURPOSE_MODEL[(*provider_purpose_key, _option.model_id)] = _option
    _MODEL_OPTIONS_BY_PROVIDER_MODEL[(_option.provider_id, _option.model_id)] = _option

_MODEL_OPTIONS_BY_PROVIDER_PURPOSE = {
    key: tuple(sorted(options, key=lambda option: option.default_rank))
    for key, options in _MODEL_OPTIONS_BY_PROVIDER_PURPOSE.items()
}


def byok_secret_field_for_provider(provider_id: str) -> str:
    return BYOK_PROVIDER_SECRET_FIELDS[provider_id]


def byok_secret_env_name_for_provider(provider_id: str) -> str:
    return BYOK_SECRET_ENV_NAMES[byok_secret_field_for_provider(provider_id)]


def get_provider_secret(settings: Any, provider_id: str) -> str | None:
    secret_field = _STT_PROVIDER_SECRET_FIELDS.get(provider_id)
    if secret_field is None:
        return None
    value = getattr(settings, secret_field, None)
    if isinstance(value, str) and value.strip():
        return value
    return None


def stt_provider_is_available(settings: Any, provider_id: str) -> bool:
    return provider_id in {"gpu_server", "local_whisper"} or bool(get_provider_secret(settings, provider_id))


def configured_stt_provider_ids(settings: Any, provider_ids: list[str] | tuple[str, ...]) -> list[str]:
    return [provider_id for provider_id in provider_ids if stt_provider_is_available(settings, provider_id)]


def models_for_provider_purpose(provider_id: str, purpose: str) -> tuple[ModelOption, ...]:
    return _MODEL_OPTIONS_BY_PROVIDER_PURPOSE.get((provider_id, purpose), ())


def default_model_for(provider_id: str, purpose: str) -> ModelOption | None:
    options = models_for_provider_purpose(provider_id, purpose)
    return options[0] if options else None


def model_option_for(provider_id: str, purpose: str, model_id: str) -> ModelOption | None:
    return _MODEL_OPTIONS_BY_PROVIDER_PURPOSE_MODEL.get((provider_id, purpose, model_id))


def model_supports_images(provider_id: str, model_id: str) -> bool:
    option = _MODEL_OPTIONS_BY_PROVIDER_MODEL.get((provider_id, model_id))
    return option is not None and "image" in option.input_modalities
