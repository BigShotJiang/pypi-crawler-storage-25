"""Interactive setup wizard for talk-to-tux first-time configuration."""
from __future__ import annotations

import atexit
import grp
import os
import select
import shutil as _shutil
import signal
import subprocess
import sys
import sys as _sys
import termios
import tomllib as _tomllib
from pathlib import Path
from pathlib import Path as _Path
from typing import IO as _IO, Awaitable as _Awaitable, Callable as _Callable

from talk_to_tux.config import write_secrets_env
from talk_to_tux.providers import BYOK_SECRET_ENV_NAMES, byok_secret_env_name_for_provider

ENV_FILE = ".env"

# Save terminal state at import time so we can always restore it
_saved_termios = None
try:
    _saved_termios = termios.tcgetattr(sys.stdin.fileno())
except Exception:
    pass


def _restore_terminal() -> None:
    """Restore terminal to saved state, with stty sane fallback."""
    if _saved_termios is not None:
        try:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, _saved_termios)
        except Exception:
            pass
    # Nuclear fallback — stty sane resets everything even if tcsetattr failed
    try:
        subprocess.run(
            ["stty", "sane"], stdin=sys.stdin,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False,
        )
    except Exception:
        pass


def _save_terminal() -> None:
    """Re-capture terminal state (call before evdev/GTK sections)."""
    global _saved_termios
    try:
        _saved_termios = termios.tcgetattr(sys.stdin.fileno())
    except Exception:
        pass


atexit.register(_restore_terminal)

# Also restore on signals that might kill us mid-select
for _sig in (signal.SIGINT, signal.SIGTERM):
    _prev = signal.getsignal(_sig)

    def _handler(signum, frame, _prev=_prev):
        _restore_terminal()
        if callable(_prev) and _prev not in (signal.SIG_DFL, signal.SIG_IGN):
            _prev(signum, frame)
        elif _prev == signal.SIG_DFL:
            signal.signal(signum, signal.SIG_DFL)
            os.kill(os.getpid(), signum)

    signal.signal(_sig, _handler)


def _read_env(path: Path) -> dict[str, str]:
    """Read a .env file into a dict (simple KEY=VALUE parser)."""
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            result[key.strip()] = value.strip()
    return result


def _write_env(path: Path, values: dict[str, str]) -> None:
    """Merge values into an existing .env file (or create one)."""
    existing = _read_env(path)
    existing.update(values)
    lines = [f"{k}={v}" for k, v in sorted(existing.items())]
    path.write_text("\n".join(lines) + "\n")


def _print(msg: str = "") -> None:
    print(msg)


def _show_click_target(message: str):
    """Show a GTK window as a click target. Returns the window or None."""
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        gi.require_version("Gdk", "3.0")
        from gi.repository import Gtk, Gdk
    except Exception:
        return None

    window = Gtk.Window(title="Talk-to-Tux Setup")
    window.set_default_size(500, 250)
    window.set_position(Gtk.WindowPosition.CENTER)
    window.set_keep_above(True)
    window.set_resizable(False)
    window.set_urgency_hint(True)
    window.set_type_hint(Gdk.WindowTypeHint.DIALOG)
    window.set_opacity(0.95)
    window.stick()  # visible on all workspaces

    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
    box.set_margin_top(40)
    box.set_margin_bottom(40)
    box.set_margin_start(40)
    box.set_margin_end(40)

    icon_label = Gtk.Label()
    icon_label.set_markup('<span size="60000">🖱</span>')
    box.pack_start(icon_label, False, False, 0)

    text_label = Gtk.Label()
    text_label.set_markup(
        f'<span size="x-large" weight="bold">{message}</span>'
    )
    text_label.set_line_wrap(True)
    box.pack_start(text_label, False, False, 0)

    hint_label = Gtk.Label()
    hint_label.set_markup(
        '<span size="medium" foreground="#aaa">'
        'The input will be detected automatically'
        '</span>'
    )
    box.pack_start(hint_label, False, False, 0)

    window.add(box)

    # Style with high-contrast colors and border
    try:
        css = b"""
        window {
            background-color: #1a1a2e;
            border: 3px solid #e94560;
            border-radius: 12px;
        }
        label { color: #eee; }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        screen = Gdk.Screen.get_default()
        if screen:
            Gtk.StyleContext.add_provider_for_screen(
                screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
    except Exception:
        pass

    window.show_all()
    window.present()  # raise to top and demand attention

    # Process GTK events so the window actually appears and repaints
    import time as _time
    deadline = _time.monotonic() + 0.3
    while _time.monotonic() < deadline:
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
        _time.sleep(0.01)

    return window


def _dismiss_click_target(window) -> None:
    """Close the click target window if it exists."""
    if window is None:
        return
    try:
        from gi.repository import Gtk
        window.hide()
        window.destroy()
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
    except Exception:
        pass


async def step_input_group() -> bool:
    """Check input group membership. Returns True if OK to continue."""
    _print("\n=== Step 1: Input Group Check ===")
    try:
        input_gid = grp.getgrnam("input").gr_gid
    except KeyError:
        _print("  'input' group does not exist — skipping")
        return True

    if input_gid in os.getgroups():
        _print(f"  OK: 'input' group is active (gid={input_gid})")
        return True
    else:
        _print(f"  WARNING: You are NOT in the 'input' group (gid={input_gid})")
        _print("  Run: sudo usermod -aG input $USER")
        _print("  Then log out and back in (or: newgrp input)")
        return False


async def step_mouse_device() -> tuple[str, str] | None:
    """Detect mouse device interactively. Returns (path, name) or None."""
    _print("\n=== Step 2: Mouse Device Detection ===")
    try:
        from evdev import InputDevice, ecodes
        import glob as glob_mod
    except ImportError:
        _print("  evdev not installed — skipping mouse detection")
        return None

    candidates: list[tuple[str, str]] = []
    for path in sorted(glob_mod.glob("/dev/input/event*")):
        try:
            dev = InputDevice(path)
            caps = dev.capabilities()
            has_rel = (
                ecodes.EV_REL in caps
                and ecodes.REL_X in caps.get(ecodes.EV_REL, [])
            )
            has_buttons = (
                ecodes.EV_KEY in caps
                and ecodes.BTN_LEFT in caps.get(ecodes.EV_KEY, [])
                and ecodes.BTN_RIGHT in caps.get(ecodes.EV_KEY, [])
            )
            if has_rel and has_buttons:
                candidates.append((path, dev.name))
            dev.close()
        except (PermissionError, OSError):
            continue

    if not candidates:
        _print("  No mouse devices found. Check input group membership.")
        return None

    if len(candidates) == 1:
        _print(f"  Found 1 mouse: {candidates[0][0]} ({candidates[0][1]})")
        return candidates[0]

    _print(f"  Found {len(candidates)} mouse candidates:")
    for i, (path, name) in enumerate(candidates, 1):
        _print(f"    [{i}] {path} ({name})")

    _print("\n  A click target window will appear — click it to auto-detect...")

    # Save terminal state before GTK/evdev section
    _save_terminal()
    popup = _show_click_target("Click here with your LEFT mouse button")
    detected = await _detect_mouse_events(candidates, timeout=120.0)
    _dismiss_click_target(popup)
    if detected:
        _print(f"  Detected: {detected[0]} ({detected[1]})")
        return detected

    _print("  No click detected. Enter device number manually:")
    try:
        choice = input("  > ").strip()
        idx = int(choice) - 1
        if 0 <= idx < len(candidates):
            return candidates[idx]
    except (ValueError, EOFError, KeyboardInterrupt):
        pass

    _print("  Using first candidate as default")
    return candidates[0]


async def _detect_mouse_events(
    candidates: list[tuple[str, str]], timeout: float = 5.0,
) -> tuple[str, str] | None:
    """Listen on all candidate devices for mouse click events."""
    try:
        from evdev import InputDevice, ecodes
    except ImportError:
        return None

    devices: list[tuple[InputDevice, str, str]] = []
    for path, name in candidates:
        try:
            dev = InputDevice(path)
            devices.append((dev, path, name))
        except (PermissionError, OSError):
            continue

    if not devices:
        return None

    try:
        fd_map = {dev.fd: (dev, path, name) for dev, path, name in devices}
        fds = list(fd_map.keys())

        import time
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            remaining = max(0, deadline - time.monotonic())
            readable, _, _ = select.select(fds, [], [], min(remaining, 0.1))
            for fd in readable:
                dev, path, name = fd_map[fd]
                for event in dev.read():
                    if (
                        event.type == ecodes.EV_KEY
                        and event.code == ecodes.BTN_LEFT
                        and event.value == 1
                    ):
                        return (path, name)
    finally:
        for dev, _, _ in devices:
            try:
                dev.close()
            except Exception:
                pass
        _restore_terminal()

    return None


async def step_keyboard_device(hotkey: str) -> tuple[str, str] | None:
    """Detect keyboard device for chord hotkeys. Returns (path, name) or None."""
    if "+" not in hotkey:
        return None

    _print("\n=== Step 3: Keyboard Device Detection ===")
    try:
        from evdev import InputDevice, ecodes
        import glob as glob_mod
    except ImportError:
        _print("  evdev not installed — skipping keyboard detection")
        return None

    parts = hotkey.split("+", 1)
    key_a = ecodes.ecodes.get(parts[0].strip())
    key_b = ecodes.ecodes.get(parts[1].strip())
    if key_a is None or key_b is None:
        _print(f"  Unknown key(s) in hotkey: {hotkey}")
        return None

    candidates: list[tuple[str, str]] = []
    for path in sorted(glob_mod.glob("/dev/input/event*")):
        try:
            dev = InputDevice(path)
            caps = dev.capabilities()
            keys = caps.get(ecodes.EV_KEY, [])
            if key_a in keys and key_b in keys:
                candidates.append((path, dev.name))
            dev.close()
        except (PermissionError, OSError):
            continue

    if not candidates:
        _print("  No keyboard device found with those keys")
        return None

    if len(candidates) == 1:
        _print(f"  Found: {candidates[0][0]} ({candidates[0][1]})")
        return candidates[0]

    _print(f"  Found {len(candidates)} keyboard candidates:")
    for i, (path, name) in enumerate(candidates, 1):
        _print(f"    [{i}] {path} ({name})")

    key_name = parts[0].strip()
    _print(f"\n  A prompt window will appear — press {key_name} to auto-detect...")

    _save_terminal()
    popup = _show_click_target(f"Press {key_name} on your keyboard")
    detected = await _detect_keyboard_events(candidates, key_a, timeout=120.0)
    _dismiss_click_target(popup)
    if detected:
        _print(f"  Detected: {detected[0]} ({detected[1]})")
        return detected

    _print("  Using first candidate as default")
    return candidates[0]


async def _detect_keyboard_events(
    candidates: list[tuple[str, str]], key_code: int, timeout: float = 5.0,
) -> tuple[str, str] | None:
    """Listen on all candidate devices for a specific key press."""
    try:
        from evdev import InputDevice, ecodes
    except ImportError:
        return None

    devices: list[tuple[InputDevice, str, str]] = []
    for path, name in candidates:
        try:
            dev = InputDevice(path)
            devices.append((dev, path, name))
        except (PermissionError, OSError):
            continue

    if not devices:
        return None

    try:
        fd_map = {dev.fd: (dev, path, name) for dev, path, name in devices}
        fds = list(fd_map.keys())

        import time
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            remaining = max(0, deadline - time.monotonic())
            readable, _, _ = select.select(fds, [], [], min(remaining, 0.1))
            for fd in readable:
                dev, path, name = fd_map[fd]
                for event in dev.read():
                    if (
                        event.type == ecodes.EV_KEY
                        and event.code == key_code
                        and event.value == 1
                    ):
                        return (path, name)
    finally:
        for dev, _, _ in devices:
            try:
                dev.close()
            except Exception:
                pass
        _restore_terminal()

    return None


async def step_test_triggers(
    mouse_device: tuple[str, str] | None,
    kbd_device: tuple[str, str] | None,
    hotkey: str,
) -> None:
    """Test trigger combos (L+R chord, keyboard chord, single key) on detected devices."""
    _print("\n=== Step 4: Trigger Test ===")

    mouse_path = mouse_device[0] if mouse_device else None
    kbd_path = kbd_device[0] if kbd_device else None

    if not mouse_path and not kbd_path:
        _print("  No devices detected — skipping trigger test")
        return

    # Test 1: L+R mouse chord
    if mouse_path:
        _print(f"\n  [4a] L+R mouse chord on {mouse_path}...")
        _save_terminal()
        popup = _show_click_target(
            "Press LEFT + RIGHT mouse buttons together"
        )
        chord_ok = await _detect_chord(mouse_path, timeout=120.0)
        _dismiss_click_target(popup)
        if chord_ok:
            _print("  OK: L+R mouse chord detected!")
        else:
            _print("  WARNING: L+R chord not detected within timeout")
            _print("  Tip: Press both buttons simultaneously, then release")

    # Test 2: Keyboard chord (if hotkey has +)
    if kbd_path and "+" in hotkey:
        parts = hotkey.split("+", 1)
        label_a = parts[0].strip().replace("KEY_", "")
        label_b = parts[1].strip().replace("KEY_", "")
        _print(f"\n  [4b] Keyboard chord {label_a}+{label_b} on {kbd_path}...")
        _save_terminal()
        popup = _show_click_target(
            f"Press {label_a} + {label_b} together"
        )
        kbd_ok = await _detect_kbd_chord(kbd_path, hotkey, timeout=120.0)
        _dismiss_click_target(popup)
        if kbd_ok:
            _print(f"  OK: {label_a}+{label_b} keyboard chord detected!")
        else:
            _print(f"  WARNING: {label_a}+{label_b} chord not detected within timeout")

    # Test 3: Single-key hotkey fallback (keyboard mode)
    if "+" not in hotkey:
        key_label = hotkey.replace("KEY_", "")
        _print(f"\n  [4b] Single-key hotkey {key_label}...")
        kbd_dev = await _find_keyboard_for_key(hotkey)
        if kbd_dev:
            _print(f"  Found keyboard: {kbd_dev[0]} ({kbd_dev[1]})")
            _save_terminal()
            popup = _show_click_target(f"Press {key_label} on your keyboard")
            key_ok = await _detect_single_key(kbd_dev[0], hotkey, timeout=120.0)
            _dismiss_click_target(popup)
            if key_ok:
                _print(f"  OK: {key_label} key press detected!")
            else:
                _print(f"  WARNING: {key_label} not detected within timeout")
        else:
            _print(f"  No keyboard found with {key_label} key")

    _print("  Trigger test complete.")


async def _detect_chord(device_path: str, timeout: float = 120.0) -> bool:
    """Listen for L+R mouse button chord on a single device."""
    try:
        from evdev import InputDevice, ecodes
    except ImportError:
        return False

    try:
        dev = InputDevice(device_path)
    except (PermissionError, OSError):
        return False

    try:
        left_down = False
        right_down = False

        import time
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            remaining = max(0, deadline - time.monotonic())
            readable, _, _ = select.select([dev.fd], [], [], min(remaining, 0.1))
            if not readable:
                continue
            for event in dev.read():
                if event.type != ecodes.EV_KEY:
                    continue
                if event.code == ecodes.BTN_LEFT:
                    left_down = event.value == 1
                elif event.code == ecodes.BTN_RIGHT:
                    right_down = event.value == 1
                if left_down and right_down:
                    return True
    finally:
        try:
            dev.close()
        except Exception:
            pass
        _restore_terminal()

    return False


async def _detect_kbd_chord(
    device_path: str, hotkey: str, timeout: float = 120.0,
) -> bool:
    """Listen for a two-key keyboard chord on a single device."""
    try:
        from evdev import InputDevice, ecodes
    except ImportError:
        return False

    parts = hotkey.split("+", 1)
    key_a = ecodes.ecodes.get(parts[0].strip())
    key_b = ecodes.ecodes.get(parts[1].strip())
    if key_a is None or key_b is None:
        return False

    try:
        dev = InputDevice(device_path)
    except (PermissionError, OSError):
        return False

    try:
        a_down = False
        b_down = False

        import time
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            remaining = max(0, deadline - time.monotonic())
            readable, _, _ = select.select([dev.fd], [], [], min(remaining, 0.1))
            if not readable:
                continue
            for event in dev.read():
                if event.type != ecodes.EV_KEY:
                    continue
                if event.code == key_a:
                    a_down = event.value == 1
                elif event.code == key_b:
                    b_down = event.value == 1
                if a_down and b_down:
                    return True
    finally:
        try:
            dev.close()
        except Exception:
            pass
        _restore_terminal()

    return False


async def _find_keyboard_for_key(hotkey: str) -> tuple[str, str] | None:
    """Find the first keyboard device that has the given key."""
    try:
        from evdev import InputDevice, ecodes
        import glob as glob_mod
    except ImportError:
        return None

    key_code = ecodes.ecodes.get(hotkey.strip())
    if key_code is None:
        return None

    for path in sorted(glob_mod.glob("/dev/input/event*")):
        try:
            dev = InputDevice(path)
            caps = dev.capabilities()
            keys = caps.get(ecodes.EV_KEY, [])
            has_key = key_code in keys
            # Must be a keyboard (has common keys like KEY_A), not just a mouse
            has_letters = ecodes.KEY_A in keys and ecodes.KEY_Z in keys
            name = dev.name
            dev.close()
            if has_key and has_letters:
                return (path, name)
        except (PermissionError, OSError):
            continue

    return None


async def _detect_single_key(
    device_path: str, hotkey: str, timeout: float = 120.0,
) -> bool:
    """Listen for a single key press on a device."""
    try:
        from evdev import InputDevice, ecodes
    except ImportError:
        return False

    key_code = ecodes.ecodes.get(hotkey.strip())
    if key_code is None:
        return False

    try:
        dev = InputDevice(device_path)
    except (PermissionError, OSError):
        return False

    try:
        import time
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            remaining = max(0, deadline - time.monotonic())
            readable, _, _ = select.select([dev.fd], [], [], min(remaining, 0.1))
            if not readable:
                continue
            for event in dev.read():
                if (
                    event.type == ecodes.EV_KEY
                    and event.code == key_code
                    and event.value == 1
                ):
                    return True
    finally:
        try:
            dev.close()
        except Exception:
            pass
        _restore_terminal()

    return False


async def step_stt_server(gpu_server_url: str) -> bool:
    """Check GPU STT server health. Returns True if healthy."""
    _print("\n=== Step 5: STT Server Check ===")
    import httpx
    url = gpu_server_url.rstrip("/")
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{url}/health")
            if resp.status_code == 200:
                data = resp.json()
                _print(f"  OK: {url} (model={data.get('model', '?')}, gpu={data.get('gpu_available', '?')})")
                return True
            else:
                _print(f"  FAIL: {url} returned status {resp.status_code}")
    except Exception as e:
        _print(f"  FAIL: {url} unreachable ({e})")
    return False


async def step_api_keys(env_values: dict[str, str]) -> dict[str, str]:
    """Prompt for missing API keys. Returns dict of keys to write."""
    _print("\n=== Step 6: API Keys ===")
    new_keys: dict[str, str] = {}

    groq_key = env_values.get(byok_secret_env_name_for_provider("groq"), "")
    openai_key = env_values.get(byok_secret_env_name_for_provider("openai"), "")
    google_key = env_values.get(byok_secret_env_name_for_provider("google"), "")

    configured = []
    if groq_key:
        configured.append("groq")
    if openai_key:
        configured.append("openai")
    if google_key:
        configured.append("google")

    if configured:
        _print(f"  Configured fallback providers: {', '.join(configured)}")
    else:
        _print("  No fallback STT API keys configured.")
        _print("  Groq offers free Whisper API (recommended fallback).")
        try:
            key = input("  Enter Groq API key (or press Enter to skip): ").strip()
            if key:
                new_keys[byok_secret_env_name_for_provider("groq")] = key
        except (EOFError, KeyboardInterrupt):
            pass

    return new_keys


def detect_display_server() -> str:
    """Detect if running on X11 or Wayland."""
    if os.environ.get("WAYLAND_DISPLAY"):
        return "wayland"
    if os.environ.get("DISPLAY"):
        return "x11"
    return "auto"


# Well-known terminal emulators and their WM_CLASS values
_KNOWN_TERMINALS: dict[str, dict] = {
    "gnome-terminal": {"match": "gnome-terminal-server", "paste_shortcut": "ctrl+shift+v"},
    "konsole": {"match": "konsole", "paste_shortcut": "ctrl+shift+v"},
    "xfce4-terminal": {"match": "Xfce4-terminal", "paste_shortcut": "ctrl+shift+v"},
    "alacritty": {"match": "Alacritty", "paste_shortcut": "ctrl+shift+v"},
    "kitty": {"match": "kitty", "paste_shortcut": "ctrl+shift+v"},
    "tilix": {"match": "Tilix", "paste_shortcut": "ctrl+shift+v"},
    "wezterm": {"match": "org.wezfurlong.wezterm", "paste_shortcut": "ctrl+shift+v"},
    "foot": {"match": "foot", "paste_shortcut": "ctrl+shift+v"},
    "xterm": {"match": "XTerm", "paste_shortcut": "shift+insert"},
    "terminator": {"match": "Terminator", "paste_shortcut": "ctrl+shift+v"},
}

# Well-known editors
_KNOWN_EDITORS: dict[str, dict] = {
    "code": {"match": "Code", "rewrite_hint": "Output syntactically valid code matching the file's language."},
    "codium": {"match": "VSCodium", "rewrite_hint": "Output syntactically valid code matching the file's language."},
    "idea": {"match": "jetbrains-*", "rewrite_hint": "Output syntactically valid code."},
    "gedit": {"match": "Gedit", "rewrite_hint": None},
}

# Well-known apps
_KNOWN_APPS: dict[str, dict] = {
    "slack": {"match": "Slack", "rewrite_hint": "Casual, conversational prose."},
    "discord": {"match": "discord", "rewrite_hint": "Casual, conversational prose."},
    "firefox": {"match": "firefox", "rewrite_hint": None},
    "chromium": {"match": "Chromium-browser", "rewrite_hint": None},
    "google-chrome": {"match": "Google-chrome", "rewrite_hint": None},
}

def detect_installed_apps() -> list[dict]:
    """Detect installed terminals, editors, and apps. Returns list of app rule dicts."""
    rules: list[dict] = []

    for binary, info in _KNOWN_TERMINALS.items():
        if _shutil.which(binary):
            rule: dict = {
                "match": info["match"],
                "is_terminal": True,
                "paste_shortcut": info["paste_shortcut"],
            }
            rules.append(rule)

    for binary, info in _KNOWN_EDITORS.items():
        if _shutil.which(binary):
            rule = {"match": info["match"]}
            if info.get("rewrite_hint"):
                rule["rewrite_hint"] = info["rewrite_hint"]
            rules.append(rule)

    for binary, info in _KNOWN_APPS.items():
        if _shutil.which(binary):
            rule = {"match": info["match"]}
            if info.get("rewrite_hint"):
                rule["rewrite_hint"] = info["rewrite_hint"]
            rules.append(rule)

    return rules


def _format_toml_value(value: object) -> str:
    """Format a Python value as a TOML value string."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        # Use repr for exact float representation, but strip trailing zeros
        return repr(value)
    if isinstance(value, str):
        # Escape backslashes and quotes
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    if isinstance(value, list):
        items = ", ".join(_format_toml_value(v) for v in value)
        return f"[{items}]"
    return repr(value)


def _build_config_toml(
    *,
    display_server: str | None = None,
    mouse_name: str | None = None,
    kbd_name: str | None = None,
    hotkey: str | None = None,
    gpu_server_url: str | None = None,
    app_rules: list[dict] | None = None,
) -> str:
    """Build config.toml content from detected settings."""
    lines: list[str] = ["# Talk-to-Tux configuration", "# Generated by --setup", ""]

    if display_server and display_server != "auto":
        lines.append("[display]")
        lines.append(f"server = {_format_toml_value(display_server)}")
        lines.append("")

    has_trigger = mouse_name or kbd_name or hotkey
    if has_trigger:
        lines.append("[trigger]")
        lines.append("")
        if mouse_name:
            lines.append("[trigger.mouse]")
            lines.append(f"device_name = {_format_toml_value(mouse_name)}")
            lines.append("")
        if kbd_name or hotkey:
            lines.append("[trigger.keyboard]")
            if hotkey:
                lines.append(f"hotkey = {_format_toml_value(hotkey)}")
            if kbd_name:
                lines.append(f"device_name = {_format_toml_value(kbd_name)}")
            lines.append("")

    if gpu_server_url and gpu_server_url != "http://localhost:8000":
        lines.append("[stt.gpu_server]")
        lines.append(f"url = {_format_toml_value(gpu_server_url)}")
        lines.append("")

    if app_rules:
        lines.append("# Per-app rules (first match wins)")
        for rule in app_rules:
            lines.append("")
            lines.append("[[app]]")
            for key, value in rule.items():
                lines.append(f"{key} = {_format_toml_value(value)}")

    # Ensure trailing newline
    if lines and lines[-1] != "":
        lines.append("")
    return "\n".join(lines)


def _write_secrets_env(path: Path, keys: dict[str, str]) -> None:
    """Write API keys to secrets.env through the shared config-layer helper."""
    write_secrets_env(path, keys)


async def run_setup() -> None:
    """Run the interactive setup wizard."""
    try:
        await _run_setup_inner()
    except (KeyboardInterrupt, EOFError):
        _print("\n  Setup cancelled.")
    finally:
        _restore_terminal()


async def _run_setup_inner() -> None:
    """Inner setup logic, wrapped by run_setup for terminal safety."""
    from talk_to_tux.config import _config_dir, _config_toml_path, _secrets_env_path

    _print("=== Talk-to-Tux Setup Wizard ===")

    env_path = Path(ENV_FILE)
    env_values = _read_env(env_path)
    secret_keys: dict[str, str] = {}

    # Step 1: Input group
    group_ok = await step_input_group()
    if not group_ok:
        _print("\n  Please fix the input group issue and re-run --setup.")
        return

    # Step 2: Mouse device
    mouse_device = await step_mouse_device()

    # Step 3: Keyboard device (only for chord hotkeys)
    hotkey = env_values.get("TTT_HOTKEY", "KEY_RIGHTCTRL")
    kbd_device = await step_keyboard_device(hotkey)

    # Step 4: Test trigger combos
    await step_test_triggers(mouse_device, kbd_device, hotkey)

    # Step 5: STT server
    gpu_url = env_values.get("TTT_GPU_SERVER_URL", "http://localhost:8000")
    await step_stt_server(gpu_url)

    # Step 6: API keys
    api_keys = await step_api_keys(env_values)
    secret_keys.update(api_keys)

    # Step 7: Detect display server
    _print("\n=== Step 7: Display Server ===")
    ds = detect_display_server()
    _print(f"  Detected: {ds}")

    # Step 8: Detect installed apps
    _print("\n=== Step 8: App Detection ===")
    app_rules = detect_installed_apps()
    if app_rules:
        _print(f"  Found {len(app_rules)} known apps:")
        for rule in app_rules:
            terminal_tag = " (terminal)" if rule.get("is_terminal") else ""
            _print(f"    - {rule['match']}{terminal_tag}")
    else:
        _print("  No known apps detected (you can add rules manually)")

    # Step 9: Write config.toml + secrets.env
    _print("\n=== Step 9: Writing Configuration ===")
    config_dir = _config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    toml_path = _config_toml_path()
    toml_content = _build_config_toml(
        display_server=ds,
        mouse_name=mouse_device[1] if mouse_device else None,
        kbd_name=kbd_device[1] if kbd_device else None,
        hotkey=hotkey if hotkey != "KEY_RIGHTCTRL" else None,
        gpu_server_url=gpu_url,
        app_rules=app_rules or None,
    )
    toml_path.write_text(toml_content)
    _print(f"  Config: {toml_path}")

    if secret_keys:
        secrets_path = _secrets_env_path()
        _write_secrets_env(secrets_path, secret_keys)
        for k, v in sorted(secret_keys.items()):
            display = v[:4] + "****" if len(v) > 8 else v
            _print(f"  Secret: {k}={display}")
        _print(f"  Secrets: {secrets_path} (chmod 600)")
    else:
        _print("  No new API keys to write.")

    _print("\nSetup complete! Run 'talk-to-tux --doctor' to verify.")


def migrate_config() -> None:
    """Migrate flat .env config to TOML config + secrets.env."""
    from talk_to_tux.config import _config_dir, _config_toml_path, _secrets_env_path

    env_path = Path(ENV_FILE)
    if not env_path.exists():
        _print(f"No {ENV_FILE} found — nothing to migrate.")
        return

    env_values = _read_env(env_path)
    if not env_values:
        _print(f"{ENV_FILE} is empty — nothing to migrate.")
        return

    # Separate secrets from config
    _SECRET_KEYS = set(BYOK_SECRET_ENV_NAMES.values())
    secrets = {k: v for k, v in env_values.items() if k in _SECRET_KEYS}
    config_vals = {k: v for k, v in env_values.items() if k not in _SECRET_KEYS}

    # Map flat keys to TOML structure
    mouse_name = config_vals.get("TTT_MOUSE_DEVICE_NAME")
    kbd_name = config_vals.get("TTT_EVDEV_DEVICE_NAME")
    hotkey = config_vals.get("TTT_HOTKEY")
    gpu_url = config_vals.get("TTT_GPU_SERVER_URL")

    toml_content = _build_config_toml(
        display_server=None,
        mouse_name=mouse_name,
        kbd_name=kbd_name,
        hotkey=hotkey,
        gpu_server_url=gpu_url,
    )

    config_dir = _config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    toml_path = _config_toml_path()
    if toml_path.exists():
        _print(f"  WARNING: {toml_path} already exists, will not overwrite.")
        _print("  Remove it first if you want to re-migrate.")
        return

    toml_path.write_text(toml_content)
    _print(f"  Config written to: {toml_path}")

    if secrets:
        secrets_path = _secrets_env_path()
        _write_secrets_env(secrets_path, secrets)
        _print(f"  Secrets written to: {secrets_path} (chmod 600)")

    _print(f"\n  Migration complete. You can now remove {ENV_FILE} if desired.")
    _print("  (The old .env will still be read as a fallback.)")


# ---------------------------------------------------------------------------
# P5 — SetupWizard class, _needs_first_run, set_api_mode  (SL-0 skeleton)
# ---------------------------------------------------------------------------

_SENTINEL = object()


def set_api_mode(
    mode: str,
    *,
    config_path: _Path | None = None,
) -> None:
    """Write api_mode to config.toml, preserving all other keys. Creates 0600 if absent.

    `api_mode` MUST live at the top level of the TOML document. Naively appending
    the line at the end of the file places it inside whatever `[section]` was
    most recently opened (TOML carries section context until the next header),
    so the parsed config sees `[<section>].api_mode` and the top-level field
    stays at its default. The line-based rewrite below preserves comments and
    formatting while guaranteeing the key lands at the document root.
    """
    from talk_to_tux.config import _config_toml_path

    path = config_path or _config_toml_path()

    if path.exists():
        text = path.read_text()
        new_lines: list[str] = []
        found_top_level = False
        in_section = False
        for line in text.splitlines():
            stripped = line.strip()
            # Section header: [section] or [section.sub]. Once we cross one,
            # any subsequent api_mode line is nested, not top-level.
            if stripped.startswith("[") and stripped.endswith("]") and not stripped.startswith("[["):
                in_section = True
                new_lines.append(line)
                continue
            if stripped.startswith("api_mode") and "=" in stripped:
                if not in_section and not found_top_level:
                    new_lines.append(f'api_mode = "{mode}"')
                    found_top_level = True
                    continue
                # Nested or duplicate api_mode — drop it; the canonical value
                # will be written at the top of the file below.
                continue
            new_lines.append(line)
        if not found_top_level:
            # Prepend at the top so api_mode is parsed as a top-level key
            # (a leading blank line separates it from the first section header).
            new_lines = [f'api_mode = "{mode}"', ""] + new_lines
        content = "\n".join(new_lines) + "\n"
    else:
        content = f'api_mode = "{mode}"\n'

    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    # Write atomically
    import tempfile as _tempfile
    import os as _os
    fd, tmp = _tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        _os.chmod(tmp, 0o600)
        with _os.fdopen(fd, "w") as f:
            f.write(content)
        _os.replace(tmp, path)
    except Exception:
        try:
            _os.unlink(tmp)
        except OSError:
            pass
        raise


def _needs_first_run(settings: object) -> bool:
    """Return True iff this looks like a fresh install with no config."""
    import os as _os
    from talk_to_tux.config import _config_toml_path, _secrets_env_path

    if _config_toml_path().exists():
        return False
    if _os.environ.get("TTT_API_MODE"):
        return False
    if _secrets_env_path().exists():
        return False
    try:
        if settings.has_hosted_token():  # type: ignore[union-attr]
            return False
    except Exception:
        pass
    return True


class SetupWizard:
    """Interactive first-run wizard for hosted vs BYO-key mode selection. (SL-0 skeleton)"""

    def __init__(
        self,
        *,
        stdin: _IO = _SENTINEL,  # type: ignore[assignment]
        stdout: _IO = _SENTINEL,  # type: ignore[assignment]
        token_store: object | None = None,
        config_path: _Path | None = None,
        hosted_config: object | None = None,
        login_fn: _Callable[..., _Awaitable] | None = None,
    ) -> None:
        self._stdin = _sys.stdin if stdin is _SENTINEL else stdin
        self._stdout = _sys.stdout if stdout is _SENTINEL else stdout
        self._token_store = token_store
        self._config_path = config_path
        self._hosted_config = hosted_config
        self._login_fn = login_fn

    async def run(self) -> int:
        """Prompt hosted vs BYO, run login if hosted, write config.toml.

        Returns 0 on success, 1 on user cancel, 2 on OAuth failure.
        """
        from talk_to_tux.auth.oauth_flow import login_interactive
        from talk_to_tux.config import _secrets_env_path

        login_fn = self._login_fn if self._login_fn is not None else login_interactive

        _HOSTED = {"hosted", "h", "1"}
        _BYO = {"byo", "byo-key", "b", "2"}

        def _prompt() -> str | None:
            self._stdout.write(
                "\nChoose API mode:\n"
                "  [1] hosted  — Talk-to-Tux hosted account (OAuth login)\n"
                "  [2] byo-key — Bring your own API keys\n"
                "Choice [hosted/byo-key]: "
            )
            self._stdout.flush()
            try:
                return self._stdin.readline().strip()
            except (EOFError, KeyboardInterrupt):
                return None

        def _yes_no(prompt: str, *, default: bool) -> bool:
            suffix = "Y/n" if default else "y/N"
            self._stdout.write(f"{prompt} [{suffix}]: ")
            self._stdout.flush()
            try:
                line = self._stdin.readline()
            except (EOFError, KeyboardInterrupt):
                return False
            if line == "":
                return False
            raw = line.strip().lower()
            if not raw:
                return default
            return raw in {"y", "yes", "1", "true"}

        self._stdout.write(
            "\nTalk-to-Tux captures your voice, screen, and app context to "
            "power voice-to-paste.\n\n"
            "Hosted mode: audio, transcript, app/window context, and optional "
            "screenshots are sent to our Supabase backend; Groq provides STT "
            "and text rewrite by default. Account email, quota, and audit rows "
            "are stored. "
            "Full privacy policy: https://www.talk-to-tux.com/privacy\n"
            "BYO-key mode: the same data is sent only to the providers whose "
            "keys you configure; nothing hits our servers.\n"
            "Local cache (audio, transcripts, screenshots, rewrites) is OFF "
            "by default. Enable with TTT_CACHE_ENABLED=true to help debug "
            "issues.\n"
        )
        self._stdout.flush()

        choice = _prompt()
        if choice is None:
            return 1

        if choice not in _HOSTED and choice not in _BYO:
            # Re-prompt once
            choice = _prompt()
            if choice is None:
                return 1
            if choice not in _HOSTED and choice not in _BYO:
                self._stdout.write("Invalid choice. Exiting.\n")
                self._stdout.flush()
                return 1

        if choice in _HOSTED:
            try:
                await login_fn(self._hosted_config, self._token_store)
            except Exception as exc:
                self._stdout.write(f"OAuth login failed: {exc}\n")
                self._stdout.flush()
                return 2
            set_api_mode("hosted", config_path=self._config_path)
            self._stdout.write("Signed in and config written.\n")
            self._stdout.flush()
        else:
            set_api_mode("byo_key", config_path=self._config_path)
            secrets_path = _secrets_env_path()
            self._stdout.write(
                f"Config written with api_mode = byo_key.\n"
                f"Fill in your API keys in: {secrets_path}\n"
            )
            self._stdout.flush()

        try:
            from talk_to_tux.desktop_integration import enable_autostart, install_launcher

            if _yes_no("Install app launcher?", default=True):
                path = install_launcher()
                self._stdout.write(f"Installed launcher: {path}\n")
            if _yes_no("Start Talk-to-Tux on login?", default=False):
                path = enable_autostart()
                self._stdout.write(f"Enabled autostart: {path}\n")
            self._stdout.flush()
        except Exception as exc:
            self._stdout.write(f"Desktop integration skipped: {exc}\n")
            self._stdout.flush()

        return 0
