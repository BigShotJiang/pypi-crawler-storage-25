from __future__ import annotations

import asyncio
import re
import time
from collections.abc import Awaitable, Callable
from typing import Any, Literal
from urllib.parse import urlsplit, urlunsplit

import httpx
from pydantic import BaseModel, Field

from talk_to_tux.config import Settings
from talk_to_tux.providers import model_option_for, model_supports_images

LocalInferenceEndpointId = Literal["gpu_server", "local_whisper", "ollama", "local_ai"]
LocalInferenceStatus = Literal["ok", "degraded", "unreachable"]
SafeMetadataValue = str | int | float | bool
ModelPurpose = Literal["stt", "rewrite"]

_ENDPOINT_IDS: tuple[LocalInferenceEndpointId, ...] = (
    "gpu_server",
    "local_whisper",
    "ollama",
    "local_ai",
)
_ENDPOINT_LABELS: dict[LocalInferenceEndpointId, str] = {
    "gpu_server": "GPU STT server",
    "local_whisper": "Local Whisper STT",
    "ollama": "Ollama rewrite",
    "local_ai": "LocalAI rewrite",
}
_URL_PATTERN = re.compile(r"https?://[^\s)]+")
_BEARER_PATTERN = re.compile(r"Bearer\s+[A-Za-z0-9._-]+", flags=re.IGNORECASE)
_TOKEN_PATTERN = re.compile(r"\b(?:gsk|sk|ghp|hf)_[A-Za-z0-9_-]+\b")
_MAX_DISCOVERED_MODELS = 32


class DiscoveredLocalModel(BaseModel):
    model_id: str
    label: str
    provider_id: str
    purpose: ModelPurpose
    supports_images: bool
    selectable: bool
    source: str
    reason: str | None = None


class LocalInferenceHealthResult(BaseModel):
    endpoint_id: LocalInferenceEndpointId
    label: str
    status: LocalInferenceStatus
    latency_ms: int | None = None
    reason: str | None = None
    last_checked_at: float | None = None
    stale: bool = False
    cooldown_until: float | None = None
    skip_eligible: bool = False
    metadata: dict[str, SafeMetadataValue] = Field(default_factory=dict)
    discovered_models: list[DiscoveredLocalModel] = Field(default_factory=list)


ProbeLocalInferenceHealth = Callable[
    [Settings, tuple[LocalInferenceEndpointId, ...] | list[LocalInferenceEndpointId] | None, float | None],
    Awaitable[dict[LocalInferenceEndpointId, LocalInferenceHealthResult]],
]


class LocalInferenceHealthMonitor:
    def __init__(
        self,
        settings_or_provider: Settings | Callable[[], Settings],
        *,
        probe: ProbeLocalInferenceHealth | None = None,
        now: Callable[[], float] = time.time,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        if callable(settings_or_provider):
            self._settings_provider = settings_or_provider
        else:
            self._settings_provider = lambda: settings_or_provider
        self._probe = probe or probe_local_inference_health
        self._now = now
        self._sleep = sleep
        self._snapshot: dict[LocalInferenceEndpointId, LocalInferenceHealthResult] = {}
        self._next_refresh_at: dict[LocalInferenceEndpointId, float] = {}
        self._task: asyncio.Task[None] | None = None
        self._refresh_lock = asyncio.Lock()

    def snapshot(self) -> dict[LocalInferenceEndpointId, LocalInferenceHealthResult]:
        return {
            endpoint_id: result.model_copy(deep=True)
            for endpoint_id, result in self._snapshot.items()
        }

    async def refresh(
        self,
        endpoints: tuple[LocalInferenceEndpointId, ...] | list[LocalInferenceEndpointId] | None = None,
        *,
        force: bool = False,
    ) -> dict[LocalInferenceEndpointId, LocalInferenceHealthResult]:
        endpoint_ids = _normalize_endpoint_ids(endpoints)
        async with self._refresh_lock:
            now = self._now()
            settings = self._settings_provider()
            probe_endpoints = tuple(
                endpoint_id
                for endpoint_id in endpoint_ids
                if force or not _should_skip_refresh(self._snapshot.get(endpoint_id), now)
            )
            if probe_endpoints:
                results = await self._probe(settings, probe_endpoints, None)
                checked_at = self._now()
                for endpoint_id, result in results.items():
                    self._snapshot[endpoint_id] = _apply_runtime_state(
                        result,
                        checked_at=checked_at,
                        cooldown_s=_cooldown_s(settings, endpoint_id),
                    )
            current_now = self._now()
            for endpoint_id in endpoint_ids:
                cached = self._snapshot.get(endpoint_id)
                if cached is None:
                    continue
                self._snapshot[endpoint_id] = _recompute_runtime_state(
                    cached,
                    now=current_now,
                    cooldown_s=_cooldown_s(settings, endpoint_id),
                )
                self._next_refresh_at[endpoint_id] = current_now + _probe_interval_s(settings, endpoint_id)
            return {
                endpoint_id: self._snapshot[endpoint_id].model_copy(deep=True)
                for endpoint_id in endpoint_ids
                if endpoint_id in self._snapshot
            }

    def mark_stale(
        self,
        endpoints: tuple[LocalInferenceEndpointId, ...] | list[LocalInferenceEndpointId],
    ) -> None:
        for endpoint_id in _normalize_endpoint_ids(endpoints):
            cached = self._snapshot.get(endpoint_id)
            if cached is None:
                continue
            stale_result = cached.model_copy(deep=True)
            stale_result.stale = True
            self._snapshot[endpoint_id] = stale_result

    def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        if self._task is None:
            return
        self._task.cancel()
        try:
            await self._task
        except asyncio.CancelledError:
            pass
        self._task = None

    async def _run(self) -> None:
        try:
            while True:
                settings = self._settings_provider()
                now = self._now()
                for endpoint_id in _ENDPOINT_IDS:
                    self._next_refresh_at.setdefault(
                        endpoint_id,
                        now + _probe_interval_s(settings, endpoint_id),
                    )
                delay_s = max(
                    min(self._next_refresh_at[endpoint_id] - now for endpoint_id in _ENDPOINT_IDS),
                    0.001,
                )
                await self._sleep(delay_s)
                due_now = self._now()
                due_endpoints = [
                    endpoint_id
                    for endpoint_id in _ENDPOINT_IDS
                    if self._next_refresh_at.get(endpoint_id, due_now) <= due_now
                ]
                if due_endpoints:
                    await self.refresh(due_endpoints)
        except asyncio.CancelledError:
            pass


async def probe_local_inference_health(
    settings: Settings,
    endpoints: tuple[LocalInferenceEndpointId, ...] | list[LocalInferenceEndpointId] | None = None,
    timeout_s: float | None = None,
) -> dict[LocalInferenceEndpointId, LocalInferenceHealthResult]:
    endpoint_ids = _normalize_endpoint_ids(endpoints)
    results: dict[LocalInferenceEndpointId, LocalInferenceHealthResult] = {}
    async with httpx.AsyncClient(follow_redirects=True) as client:
        for endpoint_id in endpoint_ids:
            started = time.perf_counter()
            request_url = _fallback_request_url(settings, endpoint_id)
            request_timeout = max(timeout_s or _default_timeout_s(settings, endpoint_id), 0.001)
            try:
                request_url = _request_url(settings, endpoint_id)
                response = await client.get(
                    request_url,
                    timeout=request_timeout,
                )
                latency_ms = max(int((time.perf_counter() - started) * 1000), 0)
                results[endpoint_id] = await _response_result(
                    client=client,
                    endpoint_id=endpoint_id,
                    settings=settings,
                    request_url=request_url,
                    response=response,
                    latency_ms=latency_ms,
                    timeout_s=request_timeout,
                )
            except httpx.TimeoutException:
                results[endpoint_id] = _error_result(
                    endpoint_id=endpoint_id,
                    request_url=request_url,
                    latency_ms=max(int((time.perf_counter() - started) * 1000), 0),
                    reason="timed out",
                )
            except (httpx.HTTPError, ValueError) as exc:
                results[endpoint_id] = _error_result(
                    endpoint_id=endpoint_id,
                    request_url=_fallback_request_url(settings, endpoint_id),
                    latency_ms=max(int((time.perf_counter() - started) * 1000), 0),
                    reason=_sanitize_text(str(exc)) or "unreachable",
                )
    return results


def _normalize_endpoint_ids(
    endpoints: tuple[LocalInferenceEndpointId, ...] | list[LocalInferenceEndpointId] | None,
) -> tuple[LocalInferenceEndpointId, ...]:
    if endpoints is None:
        return _ENDPOINT_IDS
    endpoint_ids = tuple(endpoints)
    unknown = sorted(set(endpoint_ids) - set(_ENDPOINT_IDS))
    if unknown:
        raise ValueError(f"unsupported local inference endpoint(s): {', '.join(unknown)}")
    return endpoint_ids


def _default_timeout_s(settings: Settings, endpoint_id: LocalInferenceEndpointId) -> float:
    if endpoint_id == "gpu_server":
        return settings.stt.gpu_server.probe_timeout_s
    if endpoint_id == "local_whisper":
        return settings.stt.local_whisper.probe_timeout_s
    if endpoint_id == "local_ai":
        return settings.rewrite.local_ai_probe_timeout_s
    return settings.rewrite.ollama_probe_timeout_s


def _cooldown_s(settings: Settings, endpoint_id: LocalInferenceEndpointId) -> float:
    if endpoint_id == "gpu_server":
        return settings.stt.gpu_server.unhealthy_cooldown_s
    if endpoint_id == "local_whisper":
        return settings.stt.local_whisper.unhealthy_cooldown_s
    if endpoint_id == "local_ai":
        return settings.rewrite.local_ai_unhealthy_cooldown_s
    return settings.rewrite.ollama_unhealthy_cooldown_s


def _probe_interval_s(settings: Settings, endpoint_id: LocalInferenceEndpointId) -> float:
    if endpoint_id == "gpu_server":
        return settings.stt.gpu_server.probe_interval_s
    if endpoint_id == "local_whisper":
        return settings.stt.local_whisper.probe_interval_s
    if endpoint_id == "local_ai":
        return settings.rewrite.local_ai_probe_interval_s
    return settings.rewrite.ollama_probe_interval_s


def _request_url(settings: Settings, endpoint_id: LocalInferenceEndpointId) -> str:
    if endpoint_id == "gpu_server":
        return _join_url(settings.stt.gpu_server.url, "health")
    if endpoint_id == "local_whisper":
        return _join_url(settings.stt.local_whisper.url, "models")
    if endpoint_id == "local_ai":
        return _join_url(settings.rewrite.local_ai_url, "models")
    return _ollama_tags_url(settings.rewrite.ollama_base_url)


def _fallback_request_url(settings: Settings, endpoint_id: LocalInferenceEndpointId) -> str:
    if endpoint_id == "gpu_server":
        return _sanitize_url(f"{settings.stt.gpu_server.url.rstrip('/')}/health")
    if endpoint_id == "local_whisper":
        return _sanitize_url(f"{settings.stt.local_whisper.url.rstrip('/')}/models")
    if endpoint_id == "local_ai":
        return _sanitize_url(f"{settings.rewrite.local_ai_url.rstrip('/')}/models")
    base_url = settings.rewrite.ollama_base_url.rstrip("/")
    if base_url.endswith("/v1"):
        base_url = base_url[:-3]
    return _sanitize_url(f"{base_url}/api/tags")


def _join_url(base_url: str, suffix: str) -> str:
    sanitized_base = _sanitize_url(base_url)
    parsed = urlsplit(sanitized_base)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("invalid endpoint URL")
    path = parsed.path.rstrip("/")
    return urlunsplit((parsed.scheme, parsed.netloc, f"{path}/{suffix}", "", ""))


def _ollama_tags_url(base_url: str) -> str:
    sanitized_base = _sanitize_url(base_url)
    parsed = urlsplit(sanitized_base)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("invalid endpoint URL")
    path = parsed.path.rstrip("/")
    if path.endswith("/v1"):
        path = path[:-3]
    return urlunsplit((parsed.scheme, parsed.netloc, f"{path}/api/tags", "", ""))


async def _response_result(
    *,
    client: httpx.AsyncClient,
    endpoint_id: LocalInferenceEndpointId,
    settings: Settings,
    request_url: str,
    response: httpx.Response,
    latency_ms: int,
    timeout_s: float,
) -> LocalInferenceHealthResult:
    metadata: dict[str, SafeMetadataValue] = {"url": _sanitize_url(request_url)}
    if response.status_code != 200:
        return LocalInferenceHealthResult(
            endpoint_id=endpoint_id,
            label=_ENDPOINT_LABELS[endpoint_id],
            status="degraded",
            latency_ms=latency_ms,
            reason=f"HTTP {response.status_code}",
            metadata=metadata,
        )

    try:
        payload = response.json()
    except Exception:
        return LocalInferenceHealthResult(
            endpoint_id=endpoint_id,
            label=_ENDPOINT_LABELS[endpoint_id],
            status="degraded",
            latency_ms=latency_ms,
            reason="malformed response",
            metadata=metadata,
        )

    if endpoint_id == "gpu_server":
        model = payload.get("model")
        gpu_available = payload.get("gpu_available")
        if isinstance(model, str) and model.strip():
            metadata["model"] = _sanitize_text(model.strip())
        if isinstance(gpu_available, bool):
            metadata["gpu_available"] = gpu_available
        return LocalInferenceHealthResult(
            endpoint_id=endpoint_id,
            label=_ENDPOINT_LABELS[endpoint_id],
            status="ok",
            latency_ms=latency_ms,
            metadata=metadata,
        )

    discovered_models = await _discovered_models_for_endpoint(
        client=client,
        endpoint_id=endpoint_id,
        settings=settings,
        payload=payload,
        timeout_s=timeout_s,
    )
    if discovered_models is None:
        return LocalInferenceHealthResult(
            endpoint_id=endpoint_id,
            label=_ENDPOINT_LABELS[endpoint_id],
            status="degraded",
            latency_ms=latency_ms,
            reason="malformed response",
            metadata=metadata,
        )
    metadata.update(_discovery_metadata(endpoint_id, discovered_models))
    return LocalInferenceHealthResult(
        endpoint_id=endpoint_id,
        label=_ENDPOINT_LABELS[endpoint_id],
        status="ok",
        latency_ms=latency_ms,
        metadata=metadata,
        discovered_models=discovered_models,
    )


def _error_result(
    *,
    endpoint_id: LocalInferenceEndpointId,
    request_url: str,
    latency_ms: int,
    reason: str,
) -> LocalInferenceHealthResult:
    return LocalInferenceHealthResult(
        endpoint_id=endpoint_id,
        label=_ENDPOINT_LABELS[endpoint_id],
        status="unreachable",
        latency_ms=latency_ms,
        reason=_sanitize_text(reason) or "unreachable",
        metadata={"url": _sanitize_url(request_url)},
    )


def _apply_runtime_state(
    result: LocalInferenceHealthResult,
    *,
    checked_at: float,
    cooldown_s: float,
) -> LocalInferenceHealthResult:
    runtime_result = _sanitize_cached_result(result)
    runtime_result.last_checked_at = checked_at
    runtime_result.stale = False
    if runtime_result.status == "ok":
        runtime_result.cooldown_until = None
    else:
        runtime_result.cooldown_until = checked_at + max(cooldown_s, 0.0)
    runtime_result.skip_eligible = bool(
        runtime_result.cooldown_until is not None and runtime_result.cooldown_until > checked_at
    )
    return runtime_result


def _sanitize_cached_result(result: LocalInferenceHealthResult) -> LocalInferenceHealthResult:
    sanitized = result.model_copy(deep=True)
    if sanitized.reason:
        sanitized.reason = _sanitize_text(sanitized.reason)
    sanitized.metadata = {
        key: _sanitize_text(value) if isinstance(value, str) else value
        for key, value in sanitized.metadata.items()
    }
    for model in sanitized.discovered_models:
        model.model_id = _sanitize_text(model.model_id)
        model.label = _sanitize_text(model.label)
        model.source = _sanitize_text(model.source)
        if model.reason:
            model.reason = _sanitize_text(model.reason)
    return sanitized


def _recompute_runtime_state(
    result: LocalInferenceHealthResult,
    *,
    now: float,
    cooldown_s: float,
) -> LocalInferenceHealthResult:
    refreshed = result.model_copy(deep=True)
    if refreshed.last_checked_at is None:
        refreshed.skip_eligible = False
        return refreshed
    if refreshed.status == "ok":
        refreshed.cooldown_until = None
        refreshed.skip_eligible = False
        return refreshed
    refreshed.cooldown_until = refreshed.last_checked_at + max(cooldown_s, 0.0)
    refreshed.skip_eligible = refreshed.cooldown_until > now
    return refreshed


def _should_skip_refresh(result: LocalInferenceHealthResult | None, now: float) -> bool:
    return bool(result and not result.stale and result.skip_eligible and (result.cooldown_until or 0.0) > now)


def _sanitize_url(url: str) -> str:
    try:
        parsed = urlsplit(url)
    except ValueError:
        return url.split("?", 1)[0].split("#", 1)[0]
    host = parsed.hostname or ""
    netloc = host
    if parsed.port is not None:
        netloc = f"{host}:{parsed.port}"
    if not parsed.scheme:
        return parsed.path.split("?", 1)[0].split("#", 1)[0]
    return urlunsplit((parsed.scheme, netloc, parsed.path, "", ""))


def _sanitize_text(text: str) -> str:
    redacted = _URL_PATTERN.sub(lambda match: _sanitize_url(match.group(0)), text)
    redacted = _BEARER_PATTERN.sub("Bearer [redacted]", redacted)
    redacted = _TOKEN_PATTERN.sub("[redacted]", redacted)
    return redacted.strip()


def _discovery_metadata(
    endpoint_id: LocalInferenceEndpointId,
    discovered_models: list[DiscoveredLocalModel],
) -> dict[str, SafeMetadataValue]:
    metadata: dict[str, SafeMetadataValue] = {"model_count": len(discovered_models)}
    selectable_count = sum(1 for model in discovered_models if model.selectable)
    if selectable_count:
        metadata["selectable_model_count"] = selectable_count
    if endpoint_id in {"ollama", "local_ai"}:
        vision_count = sum(1 for model in discovered_models if model.supports_images)
        if vision_count:
            metadata["vision_model_count"] = vision_count
    return metadata


async def _discovered_models_for_endpoint(
    *,
    client: httpx.AsyncClient,
    endpoint_id: LocalInferenceEndpointId,
    settings: Settings,
    payload: Any,
    timeout_s: float,
) -> list[DiscoveredLocalModel] | None:
    if endpoint_id == "local_whisper":
        return _openai_compatible_discovered_models("local_whisper", payload)
    if endpoint_id == "local_ai":
        return _openai_compatible_discovered_models("local_ai", payload)
    if endpoint_id == "ollama":
        return await _ollama_discovered_models(client, settings, payload, timeout_s)
    return []


def _openai_compatible_discovered_models(
    endpoint_id: Literal["local_whisper", "local_ai"],
    payload: Any,
) -> list[DiscoveredLocalModel] | None:
    models = payload.get("data")
    if not isinstance(models, list):
        return None
    discovered: list[DiscoveredLocalModel] = []
    for model_id in _unique_sanitized_model_ids(item.get("id") for item in models if isinstance(item, dict)):
        if endpoint_id == "local_whisper":
            option = model_option_for("local_whisper", "stt", model_id)
            discovered.append(
                DiscoveredLocalModel(
                    model_id=model_id,
                    label=option.label if option else model_id,
                    provider_id="local_whisper",
                    purpose="stt",
                    supports_images=False,
                    selectable=True,
                    source="openai_models",
                )
            )
            continue
        option = model_option_for("local_ai", "rewrite", model_id)
        supports_images = option is not None and model_supports_images("local_ai", model_id)
        discovered.append(
            DiscoveredLocalModel(
                model_id=model_id,
                label=option.label if option else model_id,
                provider_id="local_ai",
                purpose="rewrite",
                supports_images=supports_images,
                selectable=supports_images,
                source="openai_models",
                reason=None if supports_images else "image capability unverified",
            )
        )
    return discovered


async def _ollama_discovered_models(
    client: httpx.AsyncClient,
    settings: Settings,
    payload: Any,
    timeout_s: float,
) -> list[DiscoveredLocalModel] | None:
    models = payload.get("models")
    if not isinstance(models, list):
        return None
    discovered: list[DiscoveredLocalModel] = []
    show_url = _ollama_show_url(settings.rewrite.ollama_base_url)
    for model_id in _unique_sanitized_model_ids(
        item.get("name") for item in models if isinstance(item, dict)
    ):
        option = model_option_for("ollama", "rewrite", model_id)
        if option is not None and model_supports_images("ollama", model_id):
            discovered.append(
                DiscoveredLocalModel(
                    model_id=model_id,
                    label=option.label,
                    provider_id="ollama",
                    purpose="rewrite",
                    supports_images=True,
                    selectable=True,
                    source="catalog",
                )
            )
            continue
        show_payload = await _safe_ollama_show(client, show_url, model_id, timeout_s)
        supports_images = _ollama_payload_supports_images(show_payload)
        discovered.append(
            DiscoveredLocalModel(
                model_id=model_id,
                label=option.label if option else model_id,
                provider_id="ollama",
                purpose="rewrite",
                supports_images=supports_images,
                selectable=supports_images,
                source="ollama_show" if show_payload is not None else "ollama_tags",
                reason=None if supports_images else "image capability unverified",
            )
        )
    return discovered


async def _safe_ollama_show(
    client: httpx.AsyncClient,
    show_url: str,
    model_id: str,
    timeout_s: float,
) -> Any | None:
    try:
        response = await client.post(show_url, json={"name": model_id}, timeout=timeout_s)
    except httpx.HTTPError:
        return None
    if response.status_code != 200:
        return None
    try:
        payload = response.json()
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _ollama_show_url(base_url: str) -> str:
    sanitized_base = _sanitize_url(base_url)
    parsed = urlsplit(sanitized_base)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("invalid endpoint URL")
    path = parsed.path.rstrip("/")
    if path.endswith("/v1"):
        path = path[:-3]
    return urlunsplit((parsed.scheme, parsed.netloc, f"{path}/api/show", "", ""))


def _ollama_payload_supports_images(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    capabilities = payload.get("capabilities")
    if isinstance(capabilities, list):
        normalized = {str(value).strip().lower() for value in capabilities if str(value).strip()}
        if {"vision", "image"} & normalized:
            return True
    details = payload.get("details")
    if isinstance(details, dict):
        families = details.get("families")
        if isinstance(families, list):
            normalized = " ".join(str(value).strip().lower() for value in families if str(value).strip())
            if any(token in normalized for token in ("vision", "vl")):
                return True
    return False


def _unique_sanitized_model_ids(values: Any) -> list[str]:
    discovered: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str):
            continue
        model_id = _sanitize_text(value)
        if not model_id or model_id in seen:
            continue
        seen.add(model_id)
        discovered.append(model_id)
        if len(discovered) >= _MAX_DISCOVERED_MODELS:
            break
    return discovered
