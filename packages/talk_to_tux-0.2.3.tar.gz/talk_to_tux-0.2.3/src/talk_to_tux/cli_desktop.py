from __future__ import annotations

import argparse

from talk_to_tux import desktop_integration as desktop


def run(args: argparse.Namespace) -> int:
    action = getattr(args, "desktop_action", None)
    if action == "status":
        print(format_status(desktop.get_status()))
        return 0
    if action == "install-launcher":
        path = desktop.install_launcher()
        print(f"Installed launcher: {path}")
        return 0
    if action == "remove-launcher":
        removed = desktop.remove_launcher()
        print("Removed launcher" if removed else "Launcher was not installed")
        return 0
    if action == "enable-autostart":
        path = desktop.enable_autostart()
        print(f"Enabled autostart: {path}")
        return 0
    if action == "disable-autostart":
        removed = desktop.disable_autostart()
        print("Disabled autostart" if removed else "Autostart was not enabled")
        return 0
    print("desktop error: unknown action")
    return 2


def format_status(status: desktop.DesktopIntegrationStatus) -> str:
    warnings = "; ".join(status.warnings) or "none"
    return "\n".join([
        "Talk to Tux Desktop Integration",
        f"Launcher installed: {status.launcher_installed}",
        f"Autostart enabled: {status.autostart_enabled}",
        f"Launcher path: {status.launcher_path}",
        f"Autostart path: {status.autostart_path}",
        f"Command: {status.command}",
        f"Icon: {status.icon_path}",
        f"Warnings: {warnings}",
    ])
