from __future__ import annotations

import asyncio
import argparse
import json
from pathlib import Path
from typing import Any

from talk_to_tux.config import Settings
from talk_to_tux.local_inference_health import probe_local_inference_health
from talk_to_tux.learning_settings import (
    export_learning,
    forget_learning,
    import_learning,
    learning_stats,
    reset_learning,
)
from talk_to_tux.settings import (
    SettingsApplyResult,
    SettingsPatch,
    collect_settings_state,
    save_settings_patch,
)


def run(args: argparse.Namespace, settings: Settings) -> int:
    try:
        pending_patches = [parse_set_value(raw) for raw in getattr(args, "set_values", None) or []]
        persistence_health = _probe_local_inference_for_patches(settings, pending_patches)
        apply_results: list[SettingsApplyResult] = []
        for patch in pending_patches:
            apply_results.append(save_settings_patch(patch, local_inference_health=persistence_health))
        if getattr(args, "reset_learning", False):
            reset_learning("global")
        app_id = getattr(args, "reset_learning_app", None)
        if app_id:
            reset_learning(f"app:{app_id}")
        reset_scope = getattr(args, "learning_reset", None)
        if reset_scope:
            reset_learning(reset_scope)
        forget_target = getattr(args, "learning_forget", None)
        if forget_target:
            forget_learning(forget_target)
        export_path = getattr(args, "learning_export", None)
        if export_path:
            export_learning(Path(export_path))
        import_path = getattr(args, "learning_import", None)
        if import_path:
            import_learning(Path(import_path))

        from talk_to_tux.context.display import probe_desktop_capabilities

        current_settings = Settings()
        local_inference_health = None
        if getattr(args, "check_local_inference", False):
            local_inference_health = asyncio.run(probe_local_inference_health(current_settings))
        state = collect_settings_state(
            current_settings,
            capability_report=probe_desktop_capabilities(fix_display=False),
            local_inference_health=local_inference_health,
        )
        state_dict = state.model_dump(exclude_none=True)
        state_dict["learning"]["stats"] = learning_stats()
        if apply_results:
            state_dict["applied_changes"] = [result.model_dump(mode="json") for result in apply_results]
            state_dict["apply_note"] = (
                "CLI writes local settings only; it does not reconfigure another running Talk-to-Tux process."
            )
        if getattr(args, "json", False):
            print(json.dumps(state_dict, indent=2, sort_keys=True))
        else:
            print(format_settings_text(state, apply_results=apply_results))
        return 0
    except Exception as exc:
        print(f"settings error: {exc}")
        return 2


def parse_set_value(raw: str) -> SettingsPatch:
    if "=" not in raw:
        raise ValueError("--set values must use path=value")
    path, raw_value = raw.split("=", 1)
    path = path.strip()
    if not path:
        raise ValueError("--set path cannot be empty")
    return SettingsPatch(path=path, value=_parse_value(raw_value.strip()))


def format_settings_text(state: Any, apply_results: list[SettingsApplyResult] | None = None) -> str:
    providers = ", ".join(f"{p.name}:{p.status}" for p in state.providers)
    adapters = ", ".join(
        f"{name}:{backend}" for name, backend in sorted(state.desktop.selected_adapters.items())
    ) or "unknown"
    warnings = "; ".join(state.desktop.warnings) or "none"
    notes = "; ".join(state.desktop.privacy_notes) or "none"
    desktop_warnings = "; ".join(state.desktop_integration.warnings) or "none"
    legal = ", ".join(f"{name}={url}" for name, url in state.legal_urls.items())
    disabled_apps = ", ".join(state.learning.disabled_apps) or "none"
    lines = [
        "Talk to Tux Settings",
        f"API mode: {state.api_mode}",
        f"Hosted signed in: {state.hosted_signed_in}",
        f"Hosted base URL: {state.hosted_base_url}",
        f"Providers: {providers}",
        f"Screenshot/context enabled: {state.screenshot_enabled}",
        f"Local cache enabled: {state.local_cache_enabled}",
        f"Secrets: provider_api_keys={state.secrets['provider_api_keys']}, hosted_tokens={state.secrets['hosted_tokens']}",
        f"Desktop: display_server={state.desktop.display_server}, confidence={state.desktop.confidence}, tray={state.desktop.tray_support}",
        f"Launcher installed: {state.desktop_integration.launcher_installed}",
        f"Autostart enabled: {state.desktop_integration.autostart_enabled}",
        f"Desktop integration warnings: {desktop_warnings}",
        f"Backends: {adapters}",
        f"Capability warnings: {warnings}",
        f"Privacy notes: {notes}",
        f"Learning: enabled={state.learning.enabled}, scope={state.learning.scope_policy}, phrase_hints={state.learning.phrase_hints_enabled}, rewrite_steering={state.learning.rewrite_steering_enabled}, disabled_apps={disabled_apps}",
        f"Legal: {legal}",
        "Fallback: run talk-to-tux settings on systems without a usable tray settings backend.",
    ]
    if apply_results:
        lines[1:1] = [
            "Applied changes:",
            *[
                f"- {result.path}: {result.apply_mode.value}"
                + (" (restart required)" if result.restart_required else "")
                for result in apply_results
            ],
            "CLI writes local settings only; it does not reconfigure another running Talk-to-Tux process.",
        ]
    if state.local_inference_health:
        summaries = []
        for endpoint_id in ("gpu_server", "local_whisper", "ollama", "local_ai"):
            result = state.local_inference_health.get(endpoint_id)
            if result is None:
                continue
            detail = _local_inference_summary_text(result)
            summaries.append(f"{result.label}={detail}")
        if summaries:
            lines.insert(-1, f"Local inference health: {'; '.join(summaries)}")
    return "\n".join(lines)


def _parse_value(value: str) -> Any:
    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [part.strip() for part in inner.split(",")]
    return value


def _local_inference_summary_text(result: Any) -> str:
    extras: list[str] = []
    model_count = result.metadata.get("model_count")
    selectable_count = result.metadata.get("selectable_model_count")
    vision_count = result.metadata.get("vision_model_count")
    if isinstance(model_count, int):
        extras.append(f"models={model_count}")
    if isinstance(selectable_count, int):
        extras.append(f"selectable={selectable_count}")
    if isinstance(vision_count, int):
        extras.append(f"vision={vision_count}")
    if result.reason:
        extras.append(result.reason)
    return f"{result.status} ({', '.join(extras)})" if extras else result.status


def _probe_local_inference_for_patches(
    settings: Settings,
    patches: list[SettingsPatch],
) -> dict[str, Any] | None:
    endpoint_ids = []
    for patch in patches:
        if patch.path == "stt.local_whisper_model":
            endpoint_ids.append("local_whisper")
        elif patch.path == "rewrite.local_ai_model":
            endpoint_ids.append("local_ai")
        elif patch.path == "rewrite.ollama_model":
            endpoint_ids.append("ollama")
    if not endpoint_ids:
        return None
    return asyncio.run(probe_local_inference_health(settings, endpoints=sorted(set(endpoint_ids))))
