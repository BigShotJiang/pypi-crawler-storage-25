from __future__ import annotations

import enum
import json
import re
from pathlib import Path
from typing import Any

from talk_to_tux.pipeline.learning_store import LocalLearningStore


class LearningScopePolicy(str, enum.Enum):
    GLOBAL = "global"
    PER_APP = "per_app"
    OFF = "off"


RESET_SCOPES = frozenset({"all", "global", "app", "context", "phrase", "name"})


def reset_learning(scope: str = "global", config_dir: Path | None = None) -> list[Path]:
    """Remove local learning artifacts for *scope* without touching secrets."""
    if config_dir is None:
        from talk_to_tux.config import _config_dir

        config_dir = _config_dir()

    removed: list[Path] = []
    targets = _reset_targets(scope, config_dir, removed)
    for path in targets:
        try:
            if path.is_file():
                path.unlink()
                removed.append(path)
            elif path.is_dir() and not any(path.iterdir()):
                path.rmdir()
                removed.append(path)
        except OSError:
            continue
    return removed


def export_learning(path: Path, config_dir: Path | None = None) -> Path:
    """Write a redacted local learning export JSON file."""
    if config_dir is None:
        from talk_to_tux.config import _config_dir

        config_dir = _config_dir()
    path = _safe_user_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    store = LocalLearningStore(config_dir)
    path.write_text(
        json.dumps(store.export_learning(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return path


def import_learning(path: Path, config_dir: Path | None = None) -> None:
    """Import a validated local learning JSON export."""
    if config_dir is None:
        from talk_to_tux.config import _config_dir

        config_dir = _config_dir()
    path = _safe_user_path(path)
    if not path.is_file():
        raise ValueError(f"learning import file does not exist: {path}")
    LocalLearningStore(config_dir).import_learning(path)


def forget_learning(target: str, config_dir: Path | None = None) -> list[Path]:
    """Forget a scoped learning target without touching non-learning config."""
    if config_dir is None:
        from talk_to_tux.config import _config_dir

        config_dir = _config_dir()
    if not target or ".." in target or "/" in target or "\\" in target:
        raise ValueError("invalid learning forget target")
    return LocalLearningStore(config_dir).forget(target)


def learning_stats(config_dir: Path | None = None) -> dict[str, Any]:
    if config_dir is None:
        from talk_to_tux.config import _config_dir

        config_dir = _config_dir()
    stats = LocalLearningStore(config_dir).stats()
    return {
        "schema_version": stats.schema_version,
        "entry_count": stats.entry_count,
        "observation_count": stats.observation_count,
        "scopes": stats.scopes,
    }


def _reset_targets(scope: str, config_dir: Path, removed: list[Path] | None = None) -> list[Path]:
    removed = removed if removed is not None else []
    if scope in {"all", "global"}:
        store = LocalLearningStore(config_dir)
        removed.extend(store.reset(scope))
        targets = [
            config_dir / "corrections.toml",
            config_dir / "keyterms.toml",
            config_dir / "learning.toml",
            config_dir / "learning" / "global.toml",
            config_dir / "learning" / "corrections.toml",
            config_dir / "learning" / "keyterms.toml",
        ]
        if scope == "all":
            targets.append(config_dir / "learning" / "store.json")
        return targets

    if scope.startswith("app:"):
        app_id = scope.removeprefix("app:")
        if not app_id:
            raise ValueError("app reset scope requires an app id")
        LocalLearningStore(config_dir).forget(f"app:{app_id}")
        safe = _safe_app_id(app_id)
        app_dir = config_dir / "learning" / "apps"
        return [
            app_dir / f"{safe}.toml",
            app_dir / f"{safe}-corrections.toml",
            app_dir / f"{safe}-keyterms.toml",
        ]

    raise ValueError(f"unsupported learning reset scope: {scope}")


def _safe_app_id(app_id: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", app_id.strip())
    return safe.strip("._") or "app"


def _safe_user_path(path: Path) -> Path:
    if any(part == ".." for part in path.parts):
        raise ValueError("learning file path must not contain '..'")
    return path.expanduser()
