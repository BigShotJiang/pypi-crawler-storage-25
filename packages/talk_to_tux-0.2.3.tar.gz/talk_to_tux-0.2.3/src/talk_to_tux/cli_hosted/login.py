"""cli_hosted.login — 'talk-to-tux login' subcommand."""
from __future__ import annotations

import argparse
import asyncio
from typing import TYPE_CHECKING

from talk_to_tux.auth import AuthFailed, HostedError
from talk_to_tux.auth.oauth_flow import login_interactive
from talk_to_tux.auth.token_store import KeyringTokenStore

if TYPE_CHECKING:
    from talk_to_tux.config import Settings


async def _run(args: argparse.Namespace, settings: Settings) -> int:
    token_store = KeyringTokenStore()
    try:
        tokens = await login_interactive(settings.hosted, token_store)
    except AuthFailed as exc:
        if exc.reason == "not_approved_for_beta":
            print(
                "Your beta application is not yet approved. "
                "Check https://www.talk-to-tux.com/beta for status or "
                "re-apply with the GitHub account you want to use."
            )
            return 1
        print(f"Login failed: {exc}")
        return 1
    except HostedError as exc:
        print(f"Login failed: {exc}")
        return 1
    except Exception as exc:
        print(f"Login failed: {exc}")
        return 1

    email = tokens.user_email or "(unknown)"
    print(f"Signed in as {email}.")
    return 0


def run(args: argparse.Namespace, settings: Settings) -> int:
    return asyncio.run(_run(args, settings))
