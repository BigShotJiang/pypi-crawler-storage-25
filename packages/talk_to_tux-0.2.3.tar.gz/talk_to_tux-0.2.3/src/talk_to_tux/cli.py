from __future__ import annotations

import argparse
import sys

from talk_to_tux import __version__
from talk_to_tux.config import DebugConfig, Settings, TooltipConfig, TriggerConfig, ValidationConfig


def main() -> int | None:
    from talk_to_tux.main import main as _main
    return _main()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="talk-to-tux",
        description="Voice-to-smart-paste pipeline for Linux",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    parser.add_argument(
        "--debug", action="store_true", help="Enable debug logging"
    )
    parser.add_argument(
        "--show-config",
        action="store_true",
        help="Print current configuration and exit",
    )
    parser.add_argument(
        "--trigger",
        choices=["auto", "mouse", "keyboard"],
        help="Trigger mode (default: auto)",
    )
    parser.add_argument(
        "--record-mode",
        choices=["toggle", "hold"],
        help="Record mode (default: hold)",
    )
    parser.add_argument(
        "--no-indicator",
        action="store_true",
        help="Disable GNOME panel indicator",
    )
    parser.add_argument(
        "--no-tooltip",
        action="store_true",
        help="Disable tooltip confirmation (auto-paste instead)",
    )
    parser.add_argument(
        "--retry",
        nargs="?",
        const="latest",
        metavar="RUN_ID",
        help="Retry from cached run (default: latest)",
    )
    parser.add_argument(
        "--doctor",
        action="store_true",
        help="Run diagnostic checks and exit",
    )
    parser.add_argument(
        "--repair-input",
        action="store_true",
        help="Ask a running instance to rebuild the mouse grab path and exit",
    )
    parser.add_argument(
        "--setup",
        action="store_true",
        help="Run interactive setup wizard and exit",
    )
    parser.add_argument(
        "--migrate-config",
        action="store_true",
        help="Migrate .env to config.toml + secrets.env and exit",
    )
    parser.add_argument(
        "--no-validation",
        action="store_true",
        help="Disable pre-recording cursor validation",
    )

    subparsers = parser.add_subparsers(dest="command", required=False)
    settings_parser = subparsers.add_parser(
        "settings",
        help="Show or update non-secret settings",
    )
    settings_parser.add_argument("--json", action="store_true", help="Render settings as JSON")
    settings_parser.add_argument(
        "--check-local-inference",
        action="store_true",
        help="Probe local inference endpoints and include safe health summaries",
    )
    settings_parser.add_argument(
        "--set",
        action="append",
        default=[],
        dest="set_values",
        metavar="PATH=VALUE",
        help="Apply an allowlisted non-secret settings value",
    )
    settings_parser.add_argument(
        "--reset-learning",
        action="store_true",
        help="Remove local global learning artifacts",
    )
    settings_parser.add_argument(
        "--reset-learning-app",
        metavar="APP_ID",
        help="Remove local per-app learning artifacts for an app id",
    )
    settings_parser.add_argument(
        "--learning-export",
        metavar="PATH",
        help="Write a redacted local learning JSON export",
    )
    settings_parser.add_argument(
        "--learning-import",
        metavar="PATH",
        help="Import a validated local learning JSON export",
    )
    settings_parser.add_argument(
        "--learning-reset",
        metavar="SCOPE",
        help="Reset local learning scope: all, global, app:<id>, context:<id>, phrase:<hash>",
    )
    settings_parser.add_argument(
        "--learning-forget",
        metavar="TARGET",
        help="Forget local learning target: app:<id>, context:<id>, phrase:<hash>, or all",
    )
    desktop_parser = subparsers.add_parser(
        "desktop",
        help="Install launcher and login autostart integration",
    )
    desktop_subparsers = desktop_parser.add_subparsers(dest="desktop_action", required=True)
    desktop_subparsers.add_parser("status", help="Show desktop integration status")
    desktop_subparsers.add_parser("install-launcher", help="Install app launcher")
    desktop_subparsers.add_parser("remove-launcher", help="Remove app launcher")
    desktop_subparsers.add_parser("enable-autostart", help="Start Talk-to-Tux on login")
    desktop_subparsers.add_parser("disable-autostart", help="Disable login autostart")

    from talk_to_tux.cli_hosted import add_hosted_subparsers
    add_hosted_subparsers(subparsers)

    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)


def apply_overrides(settings: Settings, args: argparse.Namespace) -> Settings:
    overrides: dict = {}
    trigger_overrides: dict = {}
    indicator_overrides: dict = {}
    tooltip_overrides: dict = {}
    validation_overrides: dict = {}
    debug_overrides: dict = {}

    if args.trigger is not None:
        trigger_overrides["mode"] = args.trigger
    if args.record_mode is not None:
        trigger_overrides["record_mode"] = args.record_mode
    if args.no_indicator:
        indicator_overrides["enabled"] = False
    if args.no_tooltip:
        tooltip_overrides["enabled"] = False
    if getattr(args, "no_validation", False):
        validation_overrides["enabled"] = False
    if getattr(args, "debug", False):
        debug_overrides["tooltip_enabled"] = True

    if trigger_overrides:
        overrides["trigger"] = settings.trigger.model_copy(update=trigger_overrides)
    if indicator_overrides:
        overrides["indicator"] = settings.indicator.model_copy(update=indicator_overrides)
    if tooltip_overrides:
        overrides["tooltip"] = settings.tooltip.model_copy(update=tooltip_overrides)
    if validation_overrides:
        overrides["validation"] = settings.validation.model_copy(update=validation_overrides)
    if debug_overrides:
        overrides["debug"] = settings.debug.model_copy(update=debug_overrides)

    if overrides:
        return settings.model_copy(update=overrides)
    return settings


_SECRET_FIELDS = {
    "openai_api_key",
    "google_api_key",
    "groq_api_key",
    "elevenlabs_api_key",
}


def show_config(settings: Settings) -> str:
    lines: list[str] = []
    data = settings.model_dump(exclude_none=True)
    _render_dict(data, lines, indent=2)
    return "Configuration:\n" + "\n".join(lines)


def _render_dict(data: dict, lines: list[str], indent: int = 2) -> None:
    prefix = " " * indent
    for key, value in data.items():
        if key in _SECRET_FIELDS and value:
            display = str(value)[:4] + "****"
            lines.append(f"{prefix}{key}: {display}")
        elif isinstance(value, dict):
            lines.append(f"{prefix}{key}:")
            _render_dict(value, lines, indent + 2)
        elif isinstance(value, list):
            if value and isinstance(value[0], dict):
                for i, item in enumerate(value):
                    lines.append(f"{prefix}{key}[{i}]:")
                    _render_dict(item, lines, indent + 2)
            else:
                lines.append(f"{prefix}{key}: {value}")
        else:
            lines.append(f"{prefix}{key}: {value}")
