"""Local, privacy-minimized learning persistence."""
from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from talk_to_tux.context.adapters import AdapterConfidence

SCHEMA_VERSION = 1
MAX_TEXT_CHARS = 160
DEFAULT_TTL_SECONDS = 90 * 24 * 60 * 60
SECRET_RE = re.compile(
    r"(bearer\s+[A-Za-z0-9._~+/=-]+|"
    r"(?:gsk|sk|ttt)_[A-Za-z0-9._-]{12,}|"
    r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}|"
    r"https?://\S+)",
    re.IGNORECASE,
)


class LearningScope(str, Enum):
    GLOBAL = "global"
    APP = "app"
    ACCOUNT_WORKSPACE = "account_workspace"
    CONVERSATION_CONTACT = "conversation_contact"
    SESSION = "session"


@dataclass(frozen=True)
class LearningContextKey:
    scope: LearningScope = LearningScope.GLOBAL
    identifier: str = "global"
    confidence: str = AdapterConfidence.UNKNOWN.value
    app_id: str | None = None
    source: str | None = None
    ephemeral: bool = False

    @property
    def storage_key(self) -> str:
        return f"{self.scope.value}:{self.identifier}"


@dataclass
class LearningObservation:
    pasted_text: str
    submitted_text: str
    stt_text: str | None = None
    capture_method: str | None = None
    context_key: LearningContextKey = field(default_factory=LearningContextKey)
    widget_role: str | None = None
    app_id: str | None = None
    backend: str | None = None
    provenance: list[str] = field(default_factory=list)
    confidence: str = AdapterConfidence.UNKNOWN.value
    timestamp: float = field(default_factory=time.time)
    substitutions: list[tuple[str, str]] = field(default_factory=list)


@dataclass
class LearningEntry:
    kind: str
    value: str
    replacement: str | None = None
    scope: LearningScope = LearningScope.GLOBAL
    context_id: str = "global"
    app_id: str | None = None
    context_confidence: str = AdapterConfidence.UNKNOWN.value
    adapter_confidence: str = AdapterConfidence.UNKNOWN.value
    backend: str | None = None
    provenance: list[str] = field(default_factory=list)
    capture_methods: list[str] = field(default_factory=list)
    widget_roles: list[str] = field(default_factory=list)
    count: int = 0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    expires_at: float | None = None
    text_hashes: list[str] = field(default_factory=list)
    redaction: dict[str, Any] = field(default_factory=dict)

    @property
    def context_key(self) -> LearningContextKey:
        return LearningContextKey(
            scope=self.scope,
            identifier=self.context_id,
            confidence=self.context_confidence,
            app_id=self.app_id,
        )


@dataclass
class LearningStoreStats:
    schema_version: int
    entry_count: int
    observation_count: int
    scopes: dict[str, int]


@dataclass
class LearningStoreSnapshot:
    schema_version: int
    entries: list[LearningEntry]
    stats: LearningStoreStats


class LocalLearningStore:
    """Inspectable local learning store under ``config_dir / "learning"``."""

    def __init__(self, config_dir: Path, settings: Any | None = None) -> None:
        self.config_dir = Path(config_dir)
        self.settings = settings
        self.learning_dir = self.config_dir / "learning"
        self.path = self.learning_dir / "store.json"
        self._data = self._load()

    def record_observation(self, observation: LearningObservation) -> None:
        if observation.context_key.scope == LearningScope.SESSION:
            return
        self._expire_old()
        now = float(observation.timestamp or time.time())
        entries = self._data.setdefault("entries", {})
        observations = self._data.setdefault("observations", [])
        safe_obs = _safe_observation(observation)
        observations.append(safe_obs)
        del observations[:-200]

        for old, new in observation.substitutions:
            old_safe = _minimize_text(old)
            new_safe = _minimize_text(new)
            if not old_safe or not new_safe:
                continue
            key = _entry_key("substitution", old_safe, new_safe, observation.context_key)
            raw = entries.get(key)
            if raw is None:
                raw = {
                    "kind": "substitution",
                    "value": old_safe.lower(),
                    "replacement": new_safe,
                    "scope": observation.context_key.scope.value,
                    "context_id": observation.context_key.identifier,
                    "app_id": observation.context_key.app_id or observation.app_id,
                    "context_confidence": observation.context_key.confidence,
                    "adapter_confidence": observation.confidence,
                    "backend": _minimize_label(observation.backend),
                    "provenance": [],
                    "capture_methods": [],
                    "widget_roles": [],
                    "count": 0,
                    "first_seen": now,
                    "last_seen": now,
                    "expires_at": None,
                    "text_hashes": [],
                    "redaction": {
                        "text_bounded": True,
                        "raw_screenshots_persisted": False,
                        "secrets_redacted": True,
                    },
                }
            raw["count"] = int(raw.get("count", 0)) + 1
            raw["last_seen"] = now
            raw["expires_at"] = None if raw["count"] >= 2 else now + DEFAULT_TTL_SECONDS
            raw["adapter_confidence"] = observation.confidence
            raw["context_confidence"] = observation.context_key.confidence
            _append_unique(raw["provenance"], [_minimize_label(p) for p in observation.provenance])
            if observation.capture_method:
                _append_unique(raw["capture_methods"], [_minimize_label(observation.capture_method)])
            if observation.widget_role:
                _append_unique(raw["widget_roles"], [_minimize_label(observation.widget_role)])
            _append_unique(
                raw["text_hashes"],
                [_hash_text(observation.pasted_text), _hash_text(observation.submitted_text)],
                limit=12,
            )
            entries[key] = raw

            phrase_key = _entry_key("phrase", new_safe, None, observation.context_key)
            phrase = entries.get(phrase_key)
            if phrase is None:
                phrase = dict(raw)
                phrase["kind"] = "phrase"
                phrase["value"] = new_safe
                phrase["replacement"] = None
                phrase["count"] = 0
                phrase["first_seen"] = now
            phrase["count"] = int(phrase.get("count", 0)) + 1
            phrase["last_seen"] = now
            entries[phrase_key] = phrase

        self._save()

    def query_entries(
        self,
        *,
        context_key: LearningContextKey | None = None,
        kind: str | None = None,
        min_count: int = 1,
        include_global: bool = True,
    ) -> list[LearningEntry]:
        self._expire_old(save=True)
        keys: set[str] | None = None
        if context_key is not None:
            keys = {context_key.storage_key}
            if include_global:
                keys.add("global:global")
        entries = []
        for raw in self._data.get("entries", {}).values():
            if kind is not None and raw.get("kind") != kind:
                continue
            if int(raw.get("count", 0)) < min_count:
                continue
            if keys is not None and f"{raw.get('scope')}:{raw.get('context_id')}" not in keys:
                continue
            entries.append(_entry_from_raw(raw))
        return sorted(entries, key=lambda e: (-e.count, e.scope.value, e.value, e.replacement or ""))

    def export_learning(self) -> dict[str, Any]:
        self._expire_old(save=True)
        return _redacted_payload(self._data)

    def import_learning(self, payload: dict[str, Any] | str | Path) -> None:
        if isinstance(payload, Path):
            payload = json.loads(payload.read_text(encoding="utf-8"))
        elif isinstance(payload, str):
            payload = json.loads(payload)
        if not isinstance(payload, dict):
            raise ValueError("learning import requires a JSON object")
        text = json.dumps(payload, sort_keys=True)
        if _payload_has_forbidden_data(text):
            raise ValueError("learning import contains raw screenshot or secret-looking data")
        if int(payload.get("schema_version", 0)) != SCHEMA_VERSION:
            raise ValueError("unsupported learning export schema")
        entries = payload.get("entries", {})
        if isinstance(entries, list):
            entries = {
                _entry_key(
                    str(item.get("kind", "entry")),
                    str(item.get("value", "")),
                    item.get("replacement"),
                    LearningContextKey(
                        scope=LearningScope(str(item.get("scope", "global"))),
                        identifier=str(item.get("context_id", "global")),
                    ),
                ): item
                for item in entries
                if isinstance(item, dict)
            }
        if not isinstance(entries, dict):
            raise ValueError("learning import entries must be an object or list")
        self._data = {
            "schema_version": SCHEMA_VERSION,
            "entries": entries,
            "observations": payload.get("observations", []),
        }
        self._save()

    def reset(self, scope: str = "all") -> list[Path]:
        if scope in {"all", "global"}:
            removed: list[Path] = []
            if scope == "all":
                for path in (self.path,):
                    if path.exists():
                        path.unlink()
                        removed.append(path)
                self._data = self._empty_data()
                return removed
            before = json.dumps(self._data, sort_keys=True)
            self._delete_matching(lambda raw: raw.get("scope") == LearningScope.GLOBAL.value)
            after = json.dumps(self._data, sort_keys=True)
            if before != after and self.path.exists():
                self._save()
                return [self.path]
            return []
        return self.forget(scope)

    def forget(self, target: str) -> list[Path]:
        if target.startswith("app:"):
            wanted = target.removeprefix("app:")
            if not wanted:
                raise ValueError("app forget target requires an app id")
            self._delete_matching(lambda raw: raw.get("app_id") == wanted or raw.get("context_id") == wanted)
        elif target.startswith("context:"):
            wanted = target.removeprefix("context:")
            if not wanted:
                raise ValueError("context forget target requires an id")
            self._delete_matching(lambda raw: raw.get("context_id") == wanted)
        elif target.startswith(("phrase:", "name:")):
            wanted = target.split(":", 1)[1]
            if not wanted:
                raise ValueError("phrase forget target requires a value or hash")
            self._delete_matching(
                lambda raw: raw.get("value") == wanted
                or raw.get("replacement") == wanted
                or _hash_text(str(raw.get("value", ""))) == wanted
                or _hash_text(str(raw.get("replacement", ""))) == wanted
            )
        elif target == "global":
            return self.reset("global")
        elif target == "all":
            return self.reset("all")
        else:
            raise ValueError(f"unsupported learning forget target: {target}")
        self._save()
        return [self.path] if self.path.exists() else []

    def stats(self) -> LearningStoreStats:
        entries = self.query_entries()
        scopes: dict[str, int] = {}
        for entry in entries:
            scopes[entry.scope.value] = scopes.get(entry.scope.value, 0) + 1
        return LearningStoreStats(
            schema_version=SCHEMA_VERSION,
            entry_count=len(entries),
            observation_count=len(self._data.get("observations", [])),
            scopes=scopes,
        )

    def snapshot(self) -> LearningStoreSnapshot:
        return LearningStoreSnapshot(
            schema_version=SCHEMA_VERSION,
            entries=self.query_entries(),
            stats=self.stats(),
        )

    def _delete_matching(self, predicate: Any) -> None:
        entries = self._data.setdefault("entries", {})
        for key in list(entries):
            if predicate(entries[key]):
                del entries[key]
        self._data["observations"] = [
            obs for obs in self._data.get("observations", []) if not predicate(obs)
        ]

    def _expire_old(self, *, save: bool = False) -> None:
        now = time.time()
        entries = self._data.setdefault("entries", {})
        changed = False
        for key in list(entries):
            expires_at = entries[key].get("expires_at")
            if expires_at is not None and float(expires_at) < now:
                del entries[key]
                changed = True
        if changed and save:
            self._save()

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return self._empty_data()
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if int(data.get("schema_version", 0)) != SCHEMA_VERSION:
                return self._migrate(data)
            if _payload_has_forbidden_data(json.dumps(data)):
                return self._empty_data()
            data.setdefault("entries", {})
            data.setdefault("observations", [])
            return data
        except Exception:
            backup = self.path.with_suffix(".malformed.json")
            try:
                self.path.replace(backup)
            except OSError:
                pass
            return self._empty_data()

    def _migrate(self, data: dict[str, Any]) -> dict[str, Any]:
        migrated = self._empty_data()
        entries = data.get("entries", {})
        if isinstance(entries, list):
            for item in entries:
                if not isinstance(item, dict):
                    continue
                item["scope"] = item.get("scope", LearningScope.GLOBAL.value)
                item["context_id"] = item.get("context_id", "global")
                item["redaction"] = item.get("redaction", {"migrated": True})
                key = _entry_key(
                    str(item.get("kind", "substitution")),
                    str(item.get("value", "")),
                    item.get("replacement"),
                    LearningContextKey(
                        scope=LearningScope(str(item["scope"])),
                        identifier=str(item["context_id"]),
                    ),
                )
                migrated["entries"][key] = item
        return migrated

    def _save(self) -> None:
        self.learning_dir.mkdir(parents=True, exist_ok=True)
        payload = _redacted_payload(self._data)
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        self._data = payload

    @staticmethod
    def _empty_data() -> dict[str, Any]:
        return {"schema_version": SCHEMA_VERSION, "entries": {}, "observations": []}


def _entry_from_raw(raw: dict[str, Any]) -> LearningEntry:
    data = dict(raw)
    data["scope"] = LearningScope(str(data.get("scope", LearningScope.GLOBAL.value)))
    return LearningEntry(**{k: data[k] for k in LearningEntry.__dataclass_fields__ if k in data})


def _safe_observation(observation: LearningObservation) -> dict[str, Any]:
    return {
        "scope": observation.context_key.scope.value,
        "context_id": observation.context_key.identifier,
        "app_id": observation.context_key.app_id or observation.app_id,
        "capture_method": _minimize_label(observation.capture_method),
        "widget_role": _minimize_label(observation.widget_role),
        "backend": _minimize_label(observation.backend),
        "provenance": [_minimize_label(p) for p in observation.provenance[:8]],
        "confidence": observation.confidence,
        "context_confidence": observation.context_key.confidence,
        "timestamp": observation.timestamp,
        "text_hashes": [_hash_text(observation.pasted_text), _hash_text(observation.submitted_text)],
        "stt_text_hash": _hash_text(observation.stt_text) if observation.stt_text else None,
        "redaction": {
            "text_bounded": True,
            "raw_screenshots_persisted": False,
            "full_transcripts_persisted": False,
            "secrets_redacted": True,
        },
    }


def _redacted_payload(data: dict[str, Any]) -> dict[str, Any]:
    clean = json.loads(json.dumps(data))
    clean["schema_version"] = SCHEMA_VERSION
    for raw in clean.get("entries", {}).values():
        raw["value"] = _minimize_text(raw.get("value"))
        if raw.get("replacement") is not None:
            raw["replacement"] = _minimize_text(raw.get("replacement"))
        raw.pop("screenshot_png", None)
        raw.pop("screenshot_base64", None)
    for obs in clean.get("observations", []):
        obs.pop("pasted_text", None)
        obs.pop("submitted_text", None)
        obs.pop("stt_text", None)
        obs.pop("screenshot_png", None)
    return clean


def _payload_has_forbidden_data(text: str) -> bool:
    lowered = text.lower()
    return (
        "screenshot_png" in lowered
        or "screenshot_base64" in lowered
        or "access_token" in lowered
        or "refresh_token" in lowered
        or "secrets.env" in lowered
        or "tokens.json" in lowered
        or "api_key" in lowered
        or SECRET_RE.search(text) is not None
    )


def _entry_key(
    kind: str,
    value: str,
    replacement: str | None,
    context_key: LearningContextKey,
) -> str:
    digest = _hash_text("|".join([kind, value.lower(), replacement or "", context_key.storage_key]))
    return f"{kind}:{digest}"


def _hash_text(value: str | None) -> str:
    return hashlib.sha256((value or "").encode("utf-8")).hexdigest()[:16]


def _minimize_text(value: Any) -> str:
    text = str(value or "").strip()
    text = SECRET_RE.sub("[redacted]", text)
    if len(text) > MAX_TEXT_CHARS:
        text = text[:MAX_TEXT_CHARS].rstrip() + "..."
    return text


def _minimize_label(value: Any) -> str | None:
    if value is None:
        return None
    return re.sub(r"[^A-Za-z0-9_.:-]+", "_", str(value).strip())[:80] or None


def _append_unique(target: list[str], values: list[str | None], *, limit: int = 8) -> None:
    for value in values:
        if value and value not in target:
            target.append(value)
    del target[limit:]


def entry_to_dict(entry: LearningEntry) -> dict[str, Any]:
    data = asdict(entry)
    data["scope"] = entry.scope.value
    return data
