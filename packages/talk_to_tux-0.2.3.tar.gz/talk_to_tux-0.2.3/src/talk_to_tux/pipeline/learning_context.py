"""Derive conservative local learning context keys."""
from __future__ import annotations

import hashlib
import re
from typing import Any

from talk_to_tux.context.adapters import AdapterConfidence
from talk_to_tux.context.models import AppContext
from talk_to_tux.learning_settings import LearningScopePolicy
from talk_to_tux.pipeline.learning_store import LearningContextKey, LearningScope

HIGH_CONFIDENCE = {AdapterConfidence.HIGH.value, "high"}
LOW_CONFIDENCE = {AdapterConfidence.LOW.value, AdapterConfidence.UNKNOWN.value, "low", "unknown"}


def normalize_app_id(app_context: AppContext | None) -> str | None:
    if app_context is None:
        return None
    raw = app_context.window_class or app_context.window_instance
    if not raw:
        return None
    value = raw.split(".")[-1].strip().lower()
    value = re.sub(r"[^a-z0-9_.-]+", "-", value).strip(".-")
    return value or None


def derive_conversation_contact_key(app_context: AppContext | None) -> str | None:
    if app_context is None:
        return None
    app_id = normalize_app_id(app_context) or ""
    title = _clean_title(app_context.window_title)
    widget = _clean_title(app_context.widget_name or app_context.cursor_widget_name)
    source = " ".join(part for part in (app_id, title, widget) if part)
    if not source:
        return None
    if not _looks_like_conversation(app_id, source):
        return None
    return _hash(source)


def derive_learning_context_key(
    app_context: AppContext | None,
    settings: Any | None = None,
) -> LearningContextKey:
    learning = getattr(settings, "learning", settings)
    policy = str(getattr(learning, "scope_policy", LearningScopePolicy.GLOBAL.value))
    app_id = normalize_app_id(app_context)
    confidence = _confidence(app_context)

    if policy == LearningScopePolicy.OFF.value:
        return LearningContextKey(
            scope=LearningScope.SESSION,
            identifier="session",
            confidence=confidence,
            app_id=app_id,
            source="learning_off",
            ephemeral=True,
        )
    disabled = {str(app).lower() for app in getattr(learning, "disabled_apps", []) or []}
    if app_id and app_id.lower() in disabled:
        return LearningContextKey(
            scope=LearningScope.SESSION,
            identifier="disabled_app",
            confidence=confidence,
            app_id=app_id,
            source="disabled_app",
            ephemeral=True,
        )
    if app_context is None or confidence in LOW_CONFIDENCE:
        return LearningContextKey(
            scope=LearningScope.GLOBAL if policy == LearningScopePolicy.GLOBAL.value else LearningScope.SESSION,
            identifier="global" if policy == LearningScopePolicy.GLOBAL.value else "session",
            confidence=confidence,
            app_id=app_id,
            source="low_confidence",
            ephemeral=policy != LearningScopePolicy.GLOBAL.value,
        )
    if policy == LearningScopePolicy.GLOBAL.value:
        return LearningContextKey(
            scope=LearningScope.GLOBAL,
            identifier="global",
            confidence=confidence,
            app_id=app_id,
            source="policy_global",
        )

    if app_id is None:
        return LearningContextKey(
            scope=LearningScope.SESSION,
            identifier="unknown_app",
            confidence=confidence,
            source="unknown_app",
            ephemeral=True,
        )

    narrow = _derive_narrow_key(app_context, app_id, confidence)
    if narrow is not None:
        return narrow
    return LearningContextKey(
        scope=LearningScope.APP,
        identifier=app_id,
        confidence=confidence,
        app_id=app_id,
        source="app",
    )


def _derive_narrow_key(
    app_context: AppContext,
    app_id: str,
    confidence: str,
) -> LearningContextKey | None:
    if confidence not in HIGH_CONFIDENCE:
        return None
    title = _clean_title(app_context.window_title)
    if _looks_like_workspace(app_id, title):
        return LearningContextKey(
            scope=LearningScope.ACCOUNT_WORKSPACE,
            identifier=_hash(f"{app_id}:workspace:{title}"),
            confidence=confidence,
            app_id=app_id,
            source="window_title_workspace",
        )
    contact = derive_conversation_contact_key(app_context)
    if contact is not None:
        return LearningContextKey(
            scope=LearningScope.CONVERSATION_CONTACT,
            identifier=contact,
            confidence=confidence,
            app_id=app_id,
            source="window_title_contact",
        )
    return None


def _confidence(app_context: AppContext | None) -> str:
    if app_context is None:
        return AdapterConfidence.UNKNOWN.value
    value = getattr(app_context.confidence, "value", app_context.confidence)
    if value == AdapterConfidence.UNKNOWN.value:
        value = getattr(app_context.window_confidence, "value", app_context.window_confidence)
    return str(value or AdapterConfidence.UNKNOWN.value)


def _clean_title(value: str | None) -> str:
    text = str(value or "").strip().lower()
    text = re.sub(r"https?://\S+", "[url]", text)
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "[email]", text)
    text = re.sub(r"\s+", " ", text)
    return text[:120]


def _looks_like_workspace(app_id: str, title: str) -> bool:
    if app_id in {"slack", "discord", "chrome", "chromium", "firefox"}:
        return any(marker in title for marker in ("workspace", "team", "notion", "github", "linear"))
    return False


def _looks_like_conversation(app_id: str, source: str) -> bool:
    if app_id in {"slack", "discord", "signal", "telegram", "element", "teams"}:
        return bool(source and len(source) > len(app_id) + 3)
    return any(marker in source for marker in (" chat ", " dm ", " conversation ", "#"))


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]
