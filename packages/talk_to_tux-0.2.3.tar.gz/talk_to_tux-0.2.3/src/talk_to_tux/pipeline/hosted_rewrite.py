"""HostedBamlRouter — posts packed BAML kwargs to the hosted /v1-rewrite endpoint."""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


class HostedBamlRouter:
    def __init__(
        self,
        hosted_config,
        token_store,
        *,
        app_rules: list | None = None,
        context_packer=None,
        screenshot_config=None,
        screenshot_forwarding_enabled: bool = True,
        http_client=None,
        timeout: float = 30.0,
    ) -> None:
        from .rewrite import SmartRewriter

        self._hosted_config = hosted_config
        self._token_store = token_store
        self._timeout = timeout
        self._screenshot_forwarding_enabled = screenshot_forwarding_enabled
        self._packer = SmartRewriter(
            enabled=False,
            app_rules=app_rules,
            context_packer=context_packer,
            screenshot_config=screenshot_config,
        )
        self._http_client = http_client
        self._owns_client = http_client is None

    def _get_http_client(self):
        if self._http_client is None:
            import httpx
            self._http_client = httpx.AsyncClient()
        return self._http_client

    async def rewrite(
        self,
        transcription: str,
        context=None,
        all_windows=None,
    ):
        from .rewrite import RewriteOutput

        tokens = self._token_store.load()
        if tokens is None:
            from talk_to_tux.auth import AuthFailed
            raise AuthFailed("no_tokens")

        body = self._packer.build_hosted_rewrite_body(
            transcription,
            context,
            all_windows,
            screenshot_forwarding_enabled=self._screenshot_forwarding_enabled,
        )

        url = f"{self._hosted_config.base_url}/functions/v1/v1-rewrite"
        headers = {"Authorization": f"Bearer {tokens.access_token}"}

        http = self._get_http_client()
        response = await http.post(url, json=body, headers=headers, timeout=self._timeout)
        self._raise_for_status(response)

        data = response.json()
        text = data.get("text", "")
        fmt = data.get("format", "plain")
        reasoning = data.get("reasoning", "")
        member = data.get("member") or data.get("provider")
        model = data.get("model")
        mode = data.get("mode")
        degraded_reason = data.get("degraded_reason")
        return RewriteOutput(
            text=text,
            format=fmt,
            reasoning=reasoning,
            source="llm",
            provider=member,
            model=model if isinstance(model, str) else None,
            mode=mode if isinstance(mode, str) else None,
            degraded_reason=degraded_reason if isinstance(degraded_reason, str) else None,
        )

    @staticmethod
    def _raise_for_status(response) -> None:
        from talk_to_tux.auth import AuthFailed, TokenInvalid, TierLocked, QuotaExhausted, HostedError

        status = response.status_code
        if status == 401:
            raise TokenInvalid("access token rejected")
        if status == 402:
            try:
                data = response.json()
                code = data.get("code", "")
            except Exception:
                code = ""
            if code == "tier_locked":
                raise TierLocked("operation not permitted on current tier")
            if code == "quota_exhausted":
                reset_at = None
                remaining_stt_seconds = None
                remaining_rewrites = None
                if isinstance(data, dict):
                    reset_at = data.get("reset_at")
                    remaining_stt_seconds = data.get("remaining_stt_seconds")
                    remaining_rewrites = data.get("remaining_rewrites")
                raise QuotaExhausted(reset_at, remaining_stt_seconds, remaining_rewrites)
            raise HostedError(f"server_error {status}")
        if status == 429:
            try:
                data = response.json()
                err = data.get("error", "")
            except Exception:
                err = ""
            if err == "rewrite_in_progress":
                raise HostedError("rewrite_in_progress")
            raise HostedError(f"server_error {status}")
        if status >= 400:
            raise HostedError(f"server_error {status}")

    async def close(self) -> None:
        if self._owns_client and self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None
