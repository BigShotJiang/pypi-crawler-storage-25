from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class StageTiming:
    stage: str
    duration_ms: float
    ok: bool = True
    detail: str | None = None


@dataclass
class PipelineTelemetry:
    run_id: str | None = None
    stages: list[StageTiming] = field(default_factory=list)
    stt_provider: str | None = None
    stt_chain_position: int | None = None
    stt_chain_length: int | None = None
    stt_failures: list[str] = field(default_factory=list)
    stt_configured_chain: list[str] = field(default_factory=list)
    stt_effective_chain: list[str] = field(default_factory=list)
    stt_skipped_providers: list[dict[str, object]] = field(default_factory=list)
    stt_compute_class: str | None = None
    rewrite_source: str | None = None
    rewrite_provider: str | None = None
    rewrite_configured_chain: list[str] = field(default_factory=list)
    rewrite_effective_chain: list[str] = field(default_factory=list)
    rewrite_skipped_providers: list[dict[str, object]] = field(default_factory=list)
    rewrite_compute_class: str | None = None
    local_inference_health: dict[str, dict[str, object]] = field(default_factory=dict)
    audio_duration_ms: float | None = None
    stt_audio_duration_ms: float | None = None
    total_ms: float | None = None
    outcome: str = "unknown"
    tooltip_shown_ms: float | None = None
    tooltip_rewrites_count: int | None = None
    tooltip_confirm_method: str | None = None
    paste_decision_action: str | None = None
    paste_decision_reason: str | None = None
    trigger_to_record_ms: float | None = None

    def add_stage(
        self,
        stage: str,
        duration_ms: float,
        ok: bool = True,
        detail: str | None = None,
    ) -> None:
        self.stages.append(StageTiming(stage=stage, duration_ms=duration_ms, ok=ok, detail=detail))

    def to_dict(self) -> dict:
        stages_dict: dict = {}
        for s in self.stages:
            entry: dict = {"ms": s.duration_ms, "ok": s.ok}
            if s.detail is not None:
                entry["detail"] = s.detail
            stages_dict[s.stage] = entry

        d: dict = {
            "event": "pipeline_run",
            "run_id": self.run_id,
            "total_ms": self.total_ms,
            "outcome": self.outcome,
            "audio_duration_ms": self.audio_duration_ms,
            "stt_audio_duration_ms": self.stt_audio_duration_ms,
            "stt_provider": self.stt_provider,
            "stt_chain_position": self.stt_chain_position,
            "stt_chain_length": self.stt_chain_length,
            "stt_failures": self.stt_failures,
            "stt_configured_chain": self.stt_configured_chain,
            "stt_effective_chain": self.stt_effective_chain,
            "stt_skipped_providers": self.stt_skipped_providers,
            "stt_compute_class": self.stt_compute_class,
            "rewrite_source": self.rewrite_source,
            "rewrite_provider": self.rewrite_provider,
            "rewrite_configured_chain": self.rewrite_configured_chain,
            "rewrite_effective_chain": self.rewrite_effective_chain,
            "rewrite_skipped_providers": self.rewrite_skipped_providers,
            "rewrite_compute_class": self.rewrite_compute_class,
            "local_inference_health": self.local_inference_health,
            "stages": stages_dict,
            "tooltip_shown_ms": self.tooltip_shown_ms,
            "tooltip_rewrites_count": self.tooltip_rewrites_count,
            "tooltip_confirm_method": self.tooltip_confirm_method,
            "paste_decision_action": self.paste_decision_action,
            "paste_decision_reason": self.paste_decision_reason,
            "trigger_to_record_ms": self.trigger_to_record_ms,
        }
        return d

    def emit(self) -> None:
        logger.info("TELEMETRY %s", json.dumps(self.to_dict()))
