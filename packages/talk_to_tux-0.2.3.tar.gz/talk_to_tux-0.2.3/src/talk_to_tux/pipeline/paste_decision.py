"""Paste Decision Engine — context-change-aware routing.

Compares original context (at record time) with current context (at paste time)
to decide whether to auto-paste or offer multiple options.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from talk_to_tux.context.adapters import AdapterConfidence
from talk_to_tux.context.models import AppContext


@dataclass
class PasteDecision:
    action: Literal["auto_paste", "offer_both"]
    reason: str


class PasteDecider:
    """Decide paste routing based on context comparison."""

    def decide(
        self,
        original_ctx: AppContext | None,
        current_ctx: AppContext | None,
    ) -> PasteDecision:
        if original_ctx is None or current_ctx is None:
            return PasteDecision("auto_paste", "no context to compare")
        # If window detection failed at recording time, can't compare — auto-paste
        if not original_ctx.window_class:
            return PasteDecision("auto_paste", "no window detected at recording time")
        if (
            original_ctx.window_confidence == AdapterConfidence.LOW
            or current_ctx.window_confidence == AdapterConfidence.LOW
        ):
            if original_ctx.window_class == current_ctx.window_class:
                return PasteDecision("auto_paste", "low-confidence same window class")
            return PasteDecision("offer_both", "low-confidence desktop context changed")
        if original_ctx.window_id == current_ctx.window_id:
            return PasteDecision("auto_paste", "same window")
        if original_ctx.window_class == current_ctx.window_class:
            return PasteDecision("auto_paste", "same window class")
        # Our own UI (indicator, tooltip, debug) should not count as a context switch
        if current_ctx.window_class and current_ctx.window_class.startswith("talk-to-tux"):
            return PasteDecision("auto_paste", "current window is own UI")
        return PasteDecision(
            "offer_both",
            f"context changed: {original_ctx.window_class} -> {current_ctx.window_class}",
        )
