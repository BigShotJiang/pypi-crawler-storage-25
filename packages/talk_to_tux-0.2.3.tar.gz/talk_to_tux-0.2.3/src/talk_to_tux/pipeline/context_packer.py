"""Builds deterministic, layered context blocks for KV cache optimization.

Context is structured in layers ordered by change frequency:
  Layer 1: Immutable rules (in BAML prompt)
  Layer 2: Static app info (rarely changes — windows open/close)
  Layer 3: Semi-static window state (changes on tab switch, cd, etc.)
  Layer 4: Dynamic internal context (AT-SPI text content, on-change)
  Layer 5: Screenshots (periodic, for windows lacking metadata)
  Layer 6: Per-request (active window + transcription)

Deterministic sorting by window_id ensures identical prefix across requests
when nothing changes, maximizing KV cache hits on local LLM backends.
"""
from __future__ import annotations

import hashlib
import logging

from talk_to_tux.context.adapters import AdapterConfidence
from talk_to_tux.context.browser_contract import (
    APPROVED_BROWSER_METADATA_KEYS,
    BROWSER_WINDOW_CLASSES,
)
from talk_to_tux.context.models import AppContext, ScreenshotCropInfo

logger = logging.getLogger(__name__)

_SHELLS = frozenset({"bash", "zsh", "fish", "sh", "dash", "ksh", "tcsh", "csh", "nu"})

# Map window class to human-readable app type
_APP_TYPES: dict[str, str] = {
    # Terminals
    "kitty": "terminal",
    "Alacritty": "terminal",
    "alacritty": "terminal",
    "gnome-terminal-server": "terminal",
    "Gnome-terminal": "terminal",
    "foot": "terminal",
    "wezterm": "terminal",
    "Wezterm": "terminal",
    "konsole": "terminal",
    "Konsole": "terminal",
    "xterm": "terminal",
    "XTerm": "terminal",
    "Terminator": "terminal",
    "Tilix": "terminal",
    "st-256color": "terminal",
    "urxvt": "terminal",
    "URxvt": "terminal",
    "rio": "terminal",
    "sakura": "terminal",
    "lxterminal": "terminal",
    "mate-terminal": "terminal",
    "Xfce4-terminal": "terminal",
    # Code editors / IDEs
    "Code": "code-editor",
    "code": "code-editor",
    "vscodium": "code-editor",
    "VSCodium": "code-editor",
    "Sublime_text": "code-editor",
    "jetbrains-idea": "code-editor",
    "jetbrains-pycharm": "code-editor",
    "jetbrains-clion": "code-editor",
    "jetbrains-goland": "code-editor",
    "jetbrains-webstorm": "code-editor",
    "jetbrains-rider": "code-editor",
    "Emacs": "code-editor",
    "emacs": "code-editor",
    "Neovide": "code-editor",
    "neovide": "code-editor",
    # Chat / messaging
    "Slack": "chat",
    "discord": "chat",
    "Discord": "chat",
    "Element": "chat",
    "Telegram": "chat",
    "telegram-desktop": "chat",
    "Signal": "chat",
    # Text editors
    "Gedit": "text-editor",
    "gedit": "text-editor",
    "org.gnome.TextEditor": "text-editor",
    "mousepad": "text-editor",
    # Document / office
    "libreoffice": "document",
    "Soffice": "document",
    # File managers
    "Nautilus": "file-manager",
    "nautilus": "file-manager",
    "Thunar": "file-manager",
}
_APP_TYPES.update({browser_class: "browser" for browser_class in BROWSER_WINDOW_CLASSES})

_UNSAFE_METADATA_KEYS = frozenset(
    {
        "screenshot",
        "screenshot_png",
        "screenshot_base64",
        "bytes",
        "raw_bytes",
        "transcript",
        "transcription",
        "audio",
        "prompt",
        "authorization",
        "token",
        "api_key",
        "apikey",
        "provider_key",
    }
)
_UNSAFE_CROP_TEXT_MARKERS = _UNSAFE_METADATA_KEYS | frozenset(
    {"stderr", "environment", "env=", "ocr", "pane_text", "raw_pane_text"}
)


def classify_window(w: AppContext) -> str:
    """Return the app-type classification string for a window.

    For terminals with a /proc-detected `terminal_info`, expands the classification
    to reflect what's actually running (TUI app, SSH session, multiplexer). Used by
    both `build_static` (KNOWN APPLICATIONS list) and the TARGET WINDOW line so the
    enriched tag is salient next to the active window, not buried in a list.
    """
    app_type = _APP_TYPES.get(w.window_class or "", "unknown")
    if app_type == "terminal" and w.terminal_info:
        ti = w.terminal_info
        if _has_high_confidence_mux_context(w):
            mux = _active_mux_source(w)
            app_type = f"terminal ({mux} active pane text)"
        elif ti.tui_apps:
            primary = ti.tui_apps[0]
            app_type = f"terminal running {primary[0]} ({primary[1]})"
            if len(ti.tui_apps) > 1:
                others = ", ".join(f"{n} ({t})" for n, t in ti.tui_apps[1:])
                app_type += f" [also: {others}]"
        elif ti.active_pane_command and ti.active_pane_command in _SHELLS:
            app_type = "terminal (shell prompt)"
        elif ti.has_ssh:
            host = f" to {ti.ssh_remote_host}" if ti.ssh_remote_host else ""
            if ti.remote_multiplexer_hint:
                app_type = f"terminal (SSH{host} — remote {ti.remote_multiplexer_hint} detected, use screenshot)"
            else:
                app_type = f"terminal (SSH{host} — use screenshot)"
        elif ti.multiplexer:
            app_type = f"terminal ({ti.multiplexer} multiplexer — use screenshot)"
    elif app_type == "browser":
        target = _browser_target(w)
        if target == "address-bar":
            app_type = "browser (address bar)"
        elif target == "form-field":
            app_type = "browser (form field)"
        elif target == "page":
            app_type = "browser (page)"
    return app_type



class ContextPacker:
    """Builds layered context blocks with on-change hash tracking.

    Args:
        budget_tokens: Maximum token budget for context layers (estimated as len//4).
    """

    def __init__(self, budget_tokens: int = 4900) -> None:
        self._budget = budget_tokens
        self._hashes: dict[str, str] = {}  # window_id -> hash of dynamic context

    def build_static(self, windows: list[AppContext]) -> str:
        """Layer 2: App classification. Rarely changes."""
        if not windows:
            return "(no windows)"
        sorted_wins = sorted(windows, key=lambda w: w.window_id or "")
        lines = []
        for i, w in enumerate(sorted_wins, 1):
            lines.append(f"[{i}] {w.window_class or '?'} — {classify_window(w)}")
        return "\n".join(lines)

    def build_dynamic(self, windows: list[AppContext]) -> str:
        """Layer 3: Window state. Updated on-change."""
        if not windows:
            return ""
        sorted_wins = sorted(windows, key=lambda w: w.window_id or "")
        lines = []
        for i, w in enumerate(sorted_wins, 1):
            parts = [f"[{i}] {w.window_class or '?'}:"]
            if w.window_title:
                parts.append(f'title="{w.window_title}"')
            if w.widget_role:
                widget = w.widget_role
                if w.widget_name:
                    widget += f" ({w.widget_name})"
                parts.append(f"widget={widget}")
            if w.cursor_widget_role:
                parts.append(f"cursor_at={w.cursor_widget_role}")
            notes = [
                r for r in getattr(w, "degraded_reasons", [])
                if "screenshot" not in r.lower() and "text" not in r.lower()
            ][:2]
            if notes:
                parts.append("desktop_notes=" + "; ".join(notes))
            crop = _render_screenshot_crop(w.screenshot_crop)
            if crop:
                parts.append(crop)
            lines.append(" ".join(parts))
        return "\n".join(lines)

    def build_internal_context(self, windows: list[AppContext]) -> str:
        """Layer 4: Dynamic internal context from app adapters and AT-SPI text."""
        parts = []
        for w in sorted(windows, key=lambda w: w.window_id or ""):
            structured = _render_structured_context(w)
            if structured:
                parts.append(structured)
            text_around = getattr(w, "text_around_caret", None)
            text_content = getattr(w, "text_content", None)
            if text_around:
                parts.append(f"[{w.window_class}] near cursor:\n{text_around[:500]}")
            elif text_content:
                parts.append(f"[{w.window_class}] visible:\n{text_content[-500:]}")
        return "\n---\n".join(parts) if parts else ""

    def has_changed(self, window: AppContext) -> bool:
        """Check if this window's dynamic context changed since last pack."""
        text = self.build_dynamic([window])
        h = hashlib.sha1(text.encode()).hexdigest()[:12]
        wid = window.window_id or ""
        old = self._hashes.get(wid)
        self._hashes[wid] = h
        return old != h

    def trim_to_budget(
        self,
        static: str,
        dynamic: str,
        internal: str = "",
        screenshot_tokens: int = 0,
    ) -> tuple[str, str, str, bool]:
        """Trim context to fit budget.

        Returns (static, dynamic, internal, include_screenshot).
        Trimming priority: screenshots first, then internal context, then dynamic.
        """
        est = (len(static) + len(dynamic) + len(internal)) // 4 + screenshot_tokens
        if est <= self._budget:
            return static, dynamic, internal, True
        # Drop screenshot first (largest token cost)
        est -= screenshot_tokens
        if est <= self._budget:
            return static, dynamic, internal, False
        # Drop internal context
        if internal:
            est -= len(internal) // 4
            if est <= self._budget:
                return static, dynamic, "", False
        # Trim dynamic context: remove lines from the end (oldest windows)
        while est > self._budget and dynamic:
            lines = dynamic.split("\n")
            if len(lines) <= 1:
                break
            lines.pop()
            dynamic = "\n".join(lines)
            est = (len(static) + len(dynamic)) // 4
        return static, dynamic, "", False


def _render_structured_context(window: AppContext) -> str:
    entries = sorted(
        getattr(window, "structured_context", []),
        key=lambda c: (
            window.window_id or "",
            c.kind or "",
            c.source or "",
            c.label or "",
        ),
    )
    rendered = []
    for entry in entries:
        if entry.kind == "terminal-pane" and entry.source in {"zellij", "tmux"}:
            lines = [f"[{window.window_class}] active terminal pane ({entry.source}):"]
        elif entry.source == "browser-baseline" and entry.kind in {
            "browser-page",
            "browser-field",
        }:
            target = entry.metadata.get("target") or entry.label or "unknown"
            lines = [f"[{window.window_class}] browser {target} ({entry.kind}):"]
        else:
            label = f" {entry.label}" if entry.label else ""
            lines = [f"[{window.window_class}] {entry.kind}/{entry.source}{label}:"]
        if entry.text:
            lines.append(entry.text[:1000])
        metadata = _safe_metadata(entry.metadata, kind=entry.kind, source=entry.source)
        if metadata:
            lines.append("metadata: " + ", ".join(f"{k}={v}" for k, v in metadata))
        notes = [n for n in entry.degraded_reasons if n][:3]
        if notes:
            lines.append("degraded: " + "; ".join(notes))
        privacy = [n for n in entry.privacy_notes if n][:3]
        if privacy:
            lines.append("privacy: " + "; ".join(privacy))
        rendered.append("\n".join(lines))
    return "\n---\n".join(rendered)


def _render_screenshot_crop(crop: ScreenshotCropInfo | None) -> str:
    if crop is None:
        return ""
    mode = _safe_crop_scalar(crop.mode)
    source = _safe_crop_scalar(crop.source)
    if not mode:
        return ""
    parts = [f"screenshot_crop={mode}"]
    if source:
        parts.append(f"source={source}")
    reason = _safe_crop_scalar(crop.degraded_reason)
    if reason:
        parts.append(f"reason={reason}")
    return " ".join(parts)


def _safe_crop_scalar(value: str | None) -> str | None:
    if not value:
        return None
    lowered = value.lower()
    if any(marker in lowered for marker in _UNSAFE_CROP_TEXT_MARKERS):
        return None
    compact = "-".join(value.split())
    return compact[:120] or None


def _has_high_confidence_mux_context(window: AppContext) -> bool:
    return any(
        entry.kind == "terminal-pane"
        and entry.source in {"zellij", "tmux"}
        and entry.confidence == AdapterConfidence.HIGH
        and bool(entry.text)
        for entry in getattr(window, "structured_context", [])
    )


def _active_mux_source(window: AppContext) -> str:
    for entry in getattr(window, "structured_context", []):
        if entry.kind == "terminal-pane" and entry.source in {"zellij", "tmux"}:
            return entry.source
    return "mux"


def _browser_target(window: AppContext) -> str | None:
    for entry in getattr(window, "structured_context", []):
        if entry.source == "browser-baseline" and entry.kind in {
            "browser-page",
            "browser-field",
        }:
            target = entry.metadata.get("target")
            if isinstance(target, str):
                return target
    return None


def _safe_metadata(
    metadata: dict[str, str | int | float | bool | None],
    *,
    kind: str | None = None,
    source: str | None = None,
) -> list[tuple[str, str | int | float | bool]]:
    safe = []
    approved = (
        APPROVED_BROWSER_METADATA_KEYS
        if source == "browser-baseline" and kind in {"browser-page", "browser-field"}
        else None
    )
    for key in sorted(metadata):
        value = metadata[key]
        lowered = key.lower()
        if approved is not None and key not in approved:
            continue
        if not value or lowered in _UNSAFE_METADATA_KEYS:
            continue
        if any(unsafe in lowered for unsafe in _UNSAFE_METADATA_KEYS):
            continue
        if isinstance(value, (str, int, float, bool)):
            safe.append((key, value if not isinstance(value, str) else value[:120]))
    return safe
