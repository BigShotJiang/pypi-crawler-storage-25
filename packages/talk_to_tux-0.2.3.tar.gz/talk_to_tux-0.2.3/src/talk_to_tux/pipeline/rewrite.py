from __future__ import annotations

import base64
import logging
import os
import time
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field

import httpx

from talk_to_tux.context.models import AppContext
from talk_to_tux.local_inference_health import LocalInferenceHealthResult
from talk_to_tux.pipeline.context_packer import ContextPacker, classify_window
from talk_to_tux.providers import (
    REWRITE_FALLBACK_CHAIN,
    REWRITE_PROVIDER_CLIENT_NAMES,
    REWRITE_PROVIDER_ENV_VARS,
    default_model_for,
    model_option_for,
    model_supports_images,
)

logger = logging.getLogger(__name__)
_LOCAL_REWRITE_PROVIDERS = {"local_ai", "ollama"}
_REWRITE_CLIENT_BY_CHAIN = {
    ("local_ai", "groq", "gemini", "ollama"): "SmartRewriteClient",
    ("groq", "gemini", "ollama"): "SmartRewriteNoLocalAIClient",
    ("local_ai", "groq", "gemini"): "SmartRewriteNoOllamaClient",
    ("groq", "gemini"): "SmartRewriteCloudOnlyClient",
}

_REWRITE_MEMBER_TO_PROVIDER_ID = {
    "LocalAI": "local_ai",
    "Groq": "groq",
    "Gemini": "gemini",
    "Ollama": "ollama",
}


class UnsupportedRewriteModelError(ValueError):
    pass


@dataclass
class RewriteOutput:
    text: str
    format: str
    reasoning: str
    source: str  # "llm", "llm_partial", or "passthrough"
    provider: str | None = None  # e.g. "Groq", "Gemini", "Ollama"
    model: str | None = None
    mode: str | None = None  # "visual" or "text" for hosted responses
    degraded_reason: str | None = None
    configured_chain: list[str] = field(default_factory=list)
    effective_chain: list[str] = field(default_factory=list)
    skipped_providers: list[dict[str, object]] = field(default_factory=list)
    routing_local_health: dict[str, dict[str, object]] = field(default_factory=dict)


SMART_REWRITE_HOSTED_FIELDS = (
    "transcription",
    "static_context",
    "dynamic_context",
    "internal_context",
    "active_window",
    "rewrite_hint",
    "thinking_directive",
)


def _build_provider_registry(
    groq_model: str = "meta-llama/llama-4-scout-17b-16e-instruct",
    gemini_model: str = "gemini-3.1-flash-lite-preview",
    local_ai_url: str = "http://ai:8002/v1",
    local_ai_model: str = "cyankiwi/gemma-4-26B-A4B-it-AWQ-4bit",
    ollama_base_url: str = "http://localhost:11434/v1",
    ollama_model: str = "qwen3-vl:8b",
) -> tuple | None:
    """Build a BAML ClientRegistry that overrides individual clients by name.

    BAML's `SmartRewriteClient` (in baml_src/clients.baml) declares the
    fallback chain LocalAI → Groq → Gemini → Ollama. This registry injects
    user-configured models / URLs for each member but does NOT call
    `set_primary` — doing so would bypass the fallback strategy and force
    single-client mode. Returns None only if the ClientRegistry import fails.
    """
    groq_key = os.environ.get(REWRITE_PROVIDER_ENV_VARS["groq"], "")
    google_key = os.environ.get(REWRITE_PROVIDER_ENV_VARS["gemini"], "")
    try:
        from baml_py import ClientRegistry
    except ImportError:
        return None

    cr = ClientRegistry()
    cr.add_llm_client(
        name=REWRITE_PROVIDER_CLIENT_NAMES["local_ai"],
        provider="openai-generic",
        options={
            "base_url": local_ai_url,
            "model": local_ai_model,
        },
    )
    if groq_key:
        cr.add_llm_client(
            name=REWRITE_PROVIDER_CLIENT_NAMES["groq"],
            provider="openai-generic",
            options={
                "base_url": "https://api.groq.com/openai/v1",
                "model": groq_model,
                "api_key": groq_key,
            },
        )
    if google_key:
        cr.add_llm_client(
            name=REWRITE_PROVIDER_CLIENT_NAMES["gemini"],
            provider="google-ai",
            options={
                "model": gemini_model,
                "api_key": google_key,
            },
        )
    cr.add_llm_client(
        name=REWRITE_PROVIDER_CLIENT_NAMES["ollama"],
        provider="openai-generic",
        options={
            "base_url": ollama_base_url,
            "model": ollama_model,
        },
    )
    if tuple(REWRITE_FALLBACK_CHAIN) != ("local_ai", "groq", "gemini", "ollama"):
        raise RuntimeError("rewrite fallback chain no longer matches the BAML client order")
    # Primary is SmartRewriteClient (BAML-defined fallback chain).
    return cr, "SmartRewriteClient"


class SmartRewriter:
    def __init__(
        self,
        enabled: bool = True,
        app_rules: list | None = None,
        context_packer: ContextPacker | None = None,
        rewrite_config: object | None = None,
        screenshot_config: object | None = None,
        local_health_snapshot: Callable[[], dict[str, LocalInferenceHealthResult]] | None = None,
    ) -> None:
        self._enabled = enabled
        self._client = None
        self._app_rules = app_rules
        self._matcher = None
        self._packer = context_packer or ContextPacker()
        self._rewrite_config = rewrite_config
        self._screenshot_config = screenshot_config
        self._registry = None
        self._registry_built = False
        self._primary_provider: str | None = None
        self._active_client_name: str | None = None
        self._selected_models: dict[str, str] = {}
        self._local_health_snapshot = local_health_snapshot
        if app_rules:
            from talk_to_tux.config import AppRuleMatcher
            self._matcher = AppRuleMatcher(app_rules)

    def _selected_model_for_provider(self, provider_id: str) -> str:
        field_name = {
            "local_ai": "local_ai_model",
            "groq": "groq_model",
            "gemini": "gemini_model",
            "ollama": "ollama_model",
        }[provider_id]
        if self._rewrite_config is not None and hasattr(self._rewrite_config, field_name):
            value = getattr(self._rewrite_config, field_name)
            if isinstance(value, str) and value.strip():
                return value
        default = default_model_for(provider_id, "rewrite")
        if default is None:
            raise UnsupportedRewriteModelError(f"Missing default rewrite model for provider {provider_id}")
        return default.model_id

    def _validate_selected_models(self) -> dict[str, str]:
        selected_models = {
            provider_id: self._selected_model_for_provider(provider_id)
            for provider_id in REWRITE_FALLBACK_CHAIN
        }
        for provider_id, model_id in selected_models.items():
            option = model_option_for(provider_id, "rewrite", model_id)
            if option is None:
                raise UnsupportedRewriteModelError(
                    f"Unsupported rewrite model for {provider_id}: {model_id}"
                )
            if not model_supports_images(provider_id, model_id):
                raise UnsupportedRewriteModelError(
                    f"Rewrite model for {provider_id} does not support images: {model_id}"
                )
        return selected_models

    def _metadata_for_member(self, member_name: str | None) -> tuple[str | None, str | None, str | None]:
        if member_name is None:
            return None, None, None
        provider_id = _REWRITE_MEMBER_TO_PROVIDER_ID.get(member_name)
        if provider_id is None:
            return member_name, None, None
        return member_name, self._selected_models.get(provider_id), "visual"

    def _get_client(self):
        """Lazy import of BAML async client — avoids crash if baml_client/ missing."""
        if self._client is None:
            from talk_to_tux.baml_client.async_client import b

            self._client = b
        return self._client

    def _ensure_registry(self) -> None:
        """Lazily build ClientRegistry for optimal provider routing."""
        if self._registry_built:
            return
        self._registry_built = True
        self._selected_models = self._validate_selected_models()
        try:
            build_kwargs = {}
            if self._rewrite_config is not None:
                for field in (
                    "groq_model",
                    "gemini_model",
                    "local_ai_url",
                    "local_ai_model",
                    "ollama_base_url",
                    "ollama_model",
                ):
                    if hasattr(self._rewrite_config, field):
                        build_kwargs[field] = getattr(self._rewrite_config, field)
            result = _build_provider_registry(**build_kwargs)
            if result is not None:
                self._registry, self._primary_provider = result
                self._active_client_name = self._primary_provider
                logger.debug("Provider routing: %s primary", self._primary_provider)
            else:
                self._primary_provider = None
                self._active_client_name = None
        except UnsupportedRewriteModelError:
            raise
        except Exception:
            logger.debug("Failed to build ClientRegistry, using defaults", exc_info=True)

    def _snapshot_local_health(self) -> dict[str, LocalInferenceHealthResult]:
        if self._local_health_snapshot is None:
            return {}
        snapshot = self._local_health_snapshot()
        return {
            provider: result
            for provider, result in snapshot.items()
            if provider in _LOCAL_REWRITE_PROVIDERS and isinstance(result, LocalInferenceHealthResult)
        }

    @staticmethod
    def _health_metadata(result: LocalInferenceHealthResult | None) -> dict[str, object]:
        if result is None:
            return {
                "status": "unknown",
                "stale": True,
                "skip_eligible": False,
            }
        return {
            "status": result.status,
            "stale": result.stale,
            "skip_eligible": result.skip_eligible,
            "latency_ms": result.latency_ms,
            "last_checked_at": result.last_checked_at,
            "cooldown_until": result.cooldown_until,
            "reason": result.reason,
        }

    @staticmethod
    def _skip_entry(provider: str, result: LocalInferenceHealthResult | None, reason: str) -> dict[str, object]:
        entry = {
            "provider": provider,
            "reason": reason,
            "status": "unknown" if result is None else result.status,
            "stale": True if result is None else result.stale,
            "skip_eligible": False if result is None else result.skip_eligible,
        }
        if result is not None and result.cooldown_until is not None:
            entry["cooldown_until"] = result.cooldown_until
        return entry

    async def _preflight_local_provider(self, provider_id: str) -> bool:
        if self._rewrite_config is None:
            return True
        try:
            if provider_id == "local_ai":
                url = f"{self._rewrite_config.local_ai_url.rstrip('/')}/models"
                timeout = self._rewrite_config.local_ai_probe_timeout_s
            elif provider_id == "ollama":
                base_url = self._rewrite_config.ollama_base_url.rstrip("/")
                if base_url.endswith("/v1"):
                    base_url = base_url[:-3]
                url = f"{base_url}/api/tags"
                timeout = self._rewrite_config.ollama_probe_timeout_s
            else:
                return True
            started = time.perf_counter()
            async with httpx.AsyncClient(follow_redirects=True) as client:
                response = await client.get(url, timeout=timeout)
            ok = response.status_code == 200
            logger.debug(
                "Rewrite local preflight provider=%s ok=%s duration_ms=%.1f",
                provider_id,
                ok,
                (time.perf_counter() - started) * 1000,
            )
            return ok
        except Exception:
            logger.debug("Rewrite local preflight failed provider=%s", provider_id, exc_info=True)
            return False

    async def _resolve_effective_chain(
        self,
    ) -> tuple[list[str], list[dict[str, object]], dict[str, dict[str, object]], str | None]:
        configured_chain = list(REWRITE_FALLBACK_CHAIN)
        snapshot = self._snapshot_local_health()
        effective_chain = list(configured_chain)
        skipped_providers: list[dict[str, object]] = []
        routing_local_health = {
            provider: self._health_metadata(snapshot.get(provider))
            for provider in configured_chain
            if provider in _LOCAL_REWRITE_PROVIDERS
        }
        for provider in list(effective_chain):
            if provider not in _LOCAL_REWRITE_PROVIDERS:
                continue
            health = snapshot.get(provider)
            if health is not None and not health.stale and health.skip_eligible:
                effective_chain.remove(provider)
                skipped_providers.append(self._skip_entry(provider, health, "cooldown"))
                continue
            if health is None or health.stale:
                if not await self._preflight_local_provider(provider):
                    effective_chain.remove(provider)
                    skipped_providers.append(self._skip_entry(provider, health, "preflight_failed"))
        client_name = _REWRITE_CLIENT_BY_CHAIN.get(tuple(effective_chain))
        if client_name is None:
            raise RuntimeError(f"Unsupported effective rewrite chain: {effective_chain}")
        return effective_chain, skipped_providers, routing_local_health, client_name

    def _build_kwargs(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
        *,
        primary_provider_id: str | None = None,
    ) -> dict:
        """Build kwargs for SmartRewrite BAML call with layered context."""
        windows = list(all_windows or [])
        if context is not None:
            replaced = False
            if context.window_id:
                for i, w in enumerate(windows):
                    if w.window_id == context.window_id:
                        windows[i] = context
                        replaced = True
                        break
            if not replaced:
                windows.append(context)
        static_ctx = self._packer.build_static(windows)
        dynamic_ctx = self._packer.build_dynamic(windows)
        internal_ctx = self._packer.build_internal_context(windows)
        static_ctx, dynamic_ctx, internal_ctx, include_ss = self._packer.trim_to_budget(
            static_ctx, dynamic_ctx, internal_ctx,
        )

        # Screenshots always included when available (context stuffing for LLM)
        screenshot = None
        if (
            include_ss
            and context is not None
            and context.screenshot_png is not None
        ):
            try:
                import baml_py
                from talk_to_tux.context.screenshot import ScreenshotCapturer
                preprocess_kwargs = {}
                if self._screenshot_config is not None:
                    if hasattr(self._screenshot_config, "preprocess_max_width"):
                        preprocess_kwargs["max_width"] = self._screenshot_config.preprocess_max_width
                    if hasattr(self._screenshot_config, "preprocess_jpeg_quality"):
                        preprocess_kwargs["jpeg_quality"] = self._screenshot_config.preprocess_jpeg_quality
                preprocessed = ScreenshotCapturer.preprocess_for_llm(context.screenshot_png, **preprocess_kwargs)
                encoded = base64.b64encode(preprocessed).decode()
                screenshot = baml_py.Image.from_base64("image/jpeg", encoded)
                logger.debug("Screenshot preprocessed: %d -> %d bytes", len(context.screenshot_png), len(preprocessed))
            except Exception:
                logger.debug("Failed to encode screenshot for BAML", exc_info=True)

        # Per-app rewrite hint from matched rule
        rewrite_hint = None
        if self._matcher is not None and context is not None:
            rule = self._matcher.find(context.window_class, context.window_title)
            if rule is not None and rule.rewrite_hint:
                rewrite_hint = rule.rewrite_hint

        # /no_think is Qwen-specific — only include for Ollama (Qwen) provider
        self._ensure_registry()
        effective_primary = primary_provider_id
        if effective_primary is None and self._primary_provider == "Ollama":
            effective_primary = "ollama"
        thinking = "/no_think" if effective_primary == "ollama" else None

        active_window_label: str | None = None
        if context is not None and context.window_class:
            active_window_label = f"{context.window_class} — {classify_window(context)}"

        return {
            "static_context": static_ctx,
            "dynamic_context": dynamic_ctx,
            "internal_context": internal_ctx or None,
            "screenshot": screenshot,
            "active_window": active_window_label,
            "transcription": transcription,
            "rewrite_hint": rewrite_hint,
            "thinking_directive": thinking,
        }

    def build_hosted_rewrite_body(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
        *,
        screenshot_forwarding_enabled: bool = True,
    ) -> dict:
        """Build the hosted JSON body from the BAML SmartRewrite kwargs.

        Hosted requests cannot carry BAML runtime objects, so the screenshot is
        represented as explicit forwarding state plus optional preprocessed JPEG
        bytes encoded as base64.
        """
        kwargs = self._build_kwargs(transcription, context, all_windows)
        body: dict = {}
        for field_name in SMART_REWRITE_HOSTED_FIELDS:
            val = kwargs.get(field_name)
            if val is not None:
                body[field_name] = val

        body["screenshot_forwarding_enabled"] = bool(screenshot_forwarding_enabled)
        if not screenshot_forwarding_enabled:
            return body

        if kwargs.get("screenshot") is None:
            return body

        encoded = self._hosted_screenshot_base64(context)
        if encoded is not None:
            body["screenshot_base64"] = encoded
            body["screenshot_media_type"] = "image/jpeg"
        return body

    def _hosted_screenshot_base64(self, context: AppContext | None) -> str | None:
        if context is None or context.screenshot_png is None:
            return None
        try:
            from talk_to_tux.context.screenshot import ScreenshotCapturer
            preprocess_kwargs = {}
            if self._screenshot_config is not None:
                if hasattr(self._screenshot_config, "preprocess_max_width"):
                    preprocess_kwargs["max_width"] = self._screenshot_config.preprocess_max_width
                if hasattr(self._screenshot_config, "preprocess_jpeg_quality"):
                    preprocess_kwargs["jpeg_quality"] = self._screenshot_config.preprocess_jpeg_quality
            preprocessed = ScreenshotCapturer.preprocess_for_llm(
                context.screenshot_png,
                **preprocess_kwargs,
            )
            return base64.b64encode(preprocessed).decode()
        except Exception:
            logger.debug("Failed to encode hosted screenshot", exc_info=True)
            return None

    async def rewrite(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
    ) -> RewriteOutput:
        if not self._enabled:
            return self._passthrough(transcription)
        try:
            return await self._call_baml(transcription, context, all_windows)
        except UnsupportedRewriteModelError:
            raise
        except Exception:
            logger.exception("Smart rewrite failed, falling back to passthrough")
            return self._passthrough(transcription)

    def _get_baml_options(self, collector=None) -> dict:
        """Return baml_options with provider registry + optional per-call collector."""
        self._ensure_registry()
        opts: dict = {}
        if self._registry is not None:
            opts["client_registry"] = self._registry
        if self._active_client_name is not None:
            opts["client"] = self._active_client_name
        if collector is not None:
            opts["collector"] = collector
        return opts

    @staticmethod
    def _new_collector():
        """Create a per-call BAML Collector, or None if baml_py unavailable."""
        try:
            import baml_py
            return baml_py.Collector(name="rewrite")
        except Exception:
            return None

    @staticmethod
    def _selected_member(collector) -> str | None:
        """Return the actual fallback member name BAML routed to (e.g. 'Groq')."""
        if collector is None:
            return None
        try:
            log = collector.last
            if log is None:
                return None
            call = getattr(log, "selected_call", None)
            if call is None:
                return None
            return getattr(call, "client_name", None)
        except Exception:
            return None

    async def _call_baml(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
    ) -> RewriteOutput:
        client = self._get_client()
        effective_chain, skipped_providers, routing_local_health, client_name = await self._resolve_effective_chain()
        primary_provider_id = effective_chain[0] if effective_chain else None
        kwargs = self._build_kwargs(
            transcription,
            context,
            all_windows,
            primary_provider_id=primary_provider_id,
        )
        collector = self._new_collector()
        self._active_client_name = client_name
        baml_options = self._get_baml_options(collector)

        if baml_options:
            result = await client.SmartRewrite(**kwargs, baml_options=baml_options)
        else:
            result = await client.SmartRewrite(**kwargs)

        fmt = result.format
        fmt_str = fmt.value if hasattr(fmt, "value") else str(fmt)
        provider_name = self._selected_member(collector) or self._primary_provider or "default"
        provider, model, mode = self._metadata_for_member(provider_name)
        logger.info("Rewrite completed provider=%s model=%s mode=%s", provider, model, mode)

        return RewriteOutput(
            text=result.text,
            format=fmt_str,
            reasoning=result.reasoning,
            source="llm",
            provider=provider,
            model=model,
            mode=mode,
            configured_chain=list(REWRITE_FALLBACK_CHAIN),
            effective_chain=effective_chain,
            skipped_providers=skipped_providers,
            routing_local_health=routing_local_health,
        )

    async def rewrite_stream(
        self,
        transcription: str,
        context: AppContext | None = None,
        all_windows: list[AppContext] | None = None,
    ) -> AsyncIterator[RewriteOutput]:
        """Streaming rewrite — yields partial text, then final RewriteOutput."""
        if not self._enabled:
            yield self._passthrough(transcription)
            return
        try:
            client = self._get_client()
            effective_chain, skipped_providers, routing_local_health, client_name = await self._resolve_effective_chain()
            primary_provider_id = effective_chain[0] if effective_chain else None
            kwargs = self._build_kwargs(
                transcription,
                context,
                all_windows,
                primary_provider_id=primary_provider_id,
            )
            collector = self._new_collector()
            self._active_client_name = client_name
            baml_options = self._get_baml_options(collector)
            fallback_provider = self._primary_provider or "default"

            if baml_options:
                stream = client.stream.SmartRewrite(**kwargs, baml_options=baml_options)
            else:
                stream = client.stream.SmartRewrite(**kwargs)

            async for partial in stream:
                if hasattr(partial, "text") and partial.text:
                    yield RewriteOutput(
                        text=partial.text, format="", reasoning="", source="llm_partial",
                        provider=fallback_provider,
                    )
            final = await stream.get_final_response()
            fmt = final.format
            fmt_str = fmt.value if hasattr(fmt, "value") else str(fmt)
            provider_name = self._selected_member(collector) or fallback_provider
            provider, model, mode = self._metadata_for_member(provider_name)
            logger.info("Rewrite completed provider=%s model=%s mode=%s", provider, model, mode)
            yield RewriteOutput(
                text=final.text,
                format=fmt_str,
                reasoning=final.reasoning,
                source="llm",
                provider=provider,
                model=model,
                mode=mode,
                configured_chain=list(REWRITE_FALLBACK_CHAIN),
                effective_chain=effective_chain,
                skipped_providers=skipped_providers,
                routing_local_health=routing_local_health,
            )
        except UnsupportedRewriteModelError:
            raise
        except Exception:
            logger.exception("Streaming rewrite failed, falling back to passthrough")
            yield self._passthrough(transcription)

    @staticmethod
    def _passthrough(transcription: str) -> RewriteOutput:
        return RewriteOutput(
            text=transcription,
            format="plain",
            reasoning="",
            source="passthrough",
            configured_chain=[],
            effective_chain=[],
            skipped_providers=[],
            routing_local_health={},
        )
