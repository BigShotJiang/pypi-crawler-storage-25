from __future__ import annotations

import enum
import json
import tomllib
from pathlib import Path
from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict, Field, model_validator

from talk_to_tux.config import (
    ApiMode,
    Settings,
    _config_toml_path,
    _secrets_env_path,
    write_secrets_env,
)
from talk_to_tux.context.models import DesktopCapabilityReport
from talk_to_tux.learning_settings import LearningScopePolicy
from talk_to_tux.local_inference_health import LocalInferenceHealthResult
from talk_to_tux.providers import (
    BYOK_PROVIDER_IDS,
    BYOK_SECRET_ENV_NAMES,
    STT_PROVIDER_IDS,
    get_provider_secret,
    models_for_provider_purpose,
)

PRIVACY_URL = "https://www.talk-to-tux.com/privacy"
TERMS_URL = "https://www.talk-to-tux.com/terms"
BETA_TERMS_URL = "https://www.talk-to-tux.com/beta-terms"
SECURITY_URL = "https://www.talk-to-tux.com/security"
LEGAL_URLS = {
    "privacy": PRIVACY_URL,
    "terms": TERMS_URL,
    "beta_terms": BETA_TERMS_URL,
    "security": SECURITY_URL,
}


class ProviderStatus(BaseModel):
    name: str
    configured: bool
    status: str
    secret: str = "redacted"


class DesktopCapabilitySummary(BaseModel):
    display_server: str = "unknown"
    selected_adapters: dict[str, str] = Field(default_factory=dict)
    confidence: str = "unknown"
    tray_support: str = "unknown"
    missing_dependencies: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    privacy_notes: list[str] = Field(default_factory=list)


class DesktopIntegrationSettingsState(BaseModel):
    launcher_installed: bool = False
    autostart_enabled: bool = False
    launcher_path: str = ""
    autostart_path: str = ""
    command: str = ""
    icon_path: str = ""
    warnings: list[str] = Field(default_factory=list)


class LearningSettingsState(BaseModel):
    enabled: bool = True
    scope_policy: str = LearningScopePolicy.GLOBAL.value
    phrase_hints_enabled: bool = True
    rewrite_steering_enabled: bool = True
    disabled_apps: list[str] = Field(default_factory=list)
    reset_scopes: list[str] = Field(default_factory=lambda: ["global", "app:<app_id>"])


class SettingsFieldValidation(BaseModel):
    kind: str
    enum_options: list[str] | None = None
    option_labels: list[str] | None = None
    provider_id: str | None = None
    purpose: str | None = None
    min_value: float | None = None
    max_value: float | None = None
    min_length: int | None = None
    allow_blank: bool | None = None
    schemes: list[str] | None = None


class SettingsFieldState(BaseModel):
    path: str
    value: Any
    validation: SettingsFieldValidation
    value_supported: bool | None = None
    unsupported_legacy_value: str | None = None
    applies_live: bool = False
    rebuilds_provider: bool = False
    restart_required: bool = False

    @model_validator(mode="after")
    def _require_single_apply_behavior(self) -> SettingsFieldState:
        flags = [self.applies_live, self.rebuilds_provider, self.restart_required]
        if sum(1 for flag in flags if flag) != 1:
            raise ValueError("settings field must declare exactly one apply behavior")
        return self


class ApplyMode(str, enum.Enum):
    LIVE = "live"
    PROVIDER_REBUILD = "provider_rebuild"
    RESTART_REQUIRED = "restart_required"


class RuntimeApplyStatus(str, enum.Enum):
    PENDING = "pending"
    APPLIED = "applied"
    RESTART_REQUIRED = "restart_required"
    FAILED = "failed"


class SettingsApplyResult(BaseModel):
    path: str
    apply_mode: ApplyMode
    restart_required: bool
    runtime_status: RuntimeApplyStatus = RuntimeApplyStatus.PENDING
    message: str | None = None


class PaidFallbackWarningState(BaseModel):
    active: bool
    stage: str | None = None
    local_provider: str | None = None
    local_label: str | None = None
    fallback_compute_class: str | None = None
    fallback_provider: str | None = None
    effective_chain: list[str] = Field(default_factory=list)
    last_notified_at: float | None = None
    suppressed_until: float | None = None
    reason: str | None = None


class SettingsState(BaseModel):
    api_mode: str
    hosted_signed_in: bool
    hosted_base_url: str
    providers: list[ProviderStatus]
    screenshot_enabled: bool
    context_enabled: bool
    local_cache_enabled: bool
    legal_urls: dict[str, str]
    secrets: dict[str, str]
    desktop: DesktopCapabilitySummary
    desktop_integration: DesktopIntegrationSettingsState
    learning: LearningSettingsState
    local_inference_health: dict[str, LocalInferenceHealthResult] | None = None
    paid_fallback_warning: PaidFallbackWarningState | None = None
    sections: dict[str, list[SettingsFieldState]]


class SettingsPatch(BaseModel):
    path: str
    value: Any

    model_config = ConfigDict(arbitrary_types_allowed=True)

    ALLOWED_PATHS: ClassVar[frozenset[str]] = frozenset(
        {
            "api_mode",
            "hosted.base_url",
            "context.screenshot_enabled",
            "context.screenshot_max_width",
            "context.screenshot_jpeg_quality",
            "cache.enabled",
            "cache.max_age_hours",
            "cache.max_runs",
            "cache.analysis_threshold",
            "trigger.mode",
            "trigger.record_mode",
            "trigger.chord_timeout_ms",
            "trigger.chord_debounce_ms",
            "trigger.silence_timeout_s",
            "paste.enabled",
            "paste.clipboard_delay_ms",
            "paste.wayland_keystroke_tool",
            "learning.enabled",
            "learning.scope_policy",
            "learning.phrase_hints_enabled",
            "learning.rewrite_steering_enabled",
            "learning.disabled_apps",
            "stt.providers",
            "stt.gpu_server.url",
            "stt.gpu_server.timeout",
            "stt.gpu_server.probe_timeout_s",
            "stt.gpu_server.unhealthy_cooldown_s",
            "stt.gpu_server.probe_interval_s",
            "stt.local_whisper.url",
            "stt.local_whisper.timeout",
            "stt.local_whisper.probe_timeout_s",
            "stt.local_whisper.unhealthy_cooldown_s",
            "stt.local_whisper.probe_interval_s",
            "stt.openai_model",
            "stt.groq_model",
            "stt.elevenlabs_model",
            "stt.google_model",
            "stt.local_whisper_model",
            "rewrite.enabled",
            "rewrite.ollama_base_url",
            "rewrite.ollama_timeout_s",
            "rewrite.ollama_probe_timeout_s",
            "rewrite.ollama_unhealthy_cooldown_s",
            "rewrite.ollama_probe_interval_s",
            "rewrite.local_ai_url",
            "rewrite.local_ai_timeout_s",
            "rewrite.local_ai_probe_timeout_s",
            "rewrite.local_ai_unhealthy_cooldown_s",
            "rewrite.local_ai_probe_interval_s",
            "rewrite.local_ai_model",
            "rewrite.groq_model",
            "rewrite.gemini_model",
            "rewrite.openai_model",
            "rewrite.ollama_model",
            "rewrite.context_budget_pct",
            "rewrite.model_context_tokens",
        }
    )

    SECRET_PATH_PARTS: ClassVar[tuple[str, ...]] = (
        "api_key",
        "access_token",
        "refresh_token",
        "token",
        "secret",
        "password",
    )


class SecretSettingsPatch(BaseModel):
    path: str
    value: str | None = None

    ALLOWED_PATHS: ClassVar[frozenset[str]] = frozenset(BYOK_SECRET_ENV_NAMES)


_MODEL_FIELD_REGISTRY: dict[str, dict[str, str]] = {
    "stt.openai_model": {"section": "providers", "provider_id": "openai", "purpose": "stt"},
    "stt.groq_model": {"section": "providers", "provider_id": "groq", "purpose": "stt"},
    "stt.elevenlabs_model": {"section": "providers", "provider_id": "elevenlabs", "purpose": "stt"},
    "stt.google_model": {"section": "providers", "provider_id": "google", "purpose": "stt"},
    "stt.local_whisper_model": {
        "section": "local_inference",
        "provider_id": "local_whisper",
        "purpose": "stt",
    },
    "rewrite.openai_model": {"section": "providers", "provider_id": "openai", "purpose": "rewrite"},
    "rewrite.groq_model": {"section": "providers", "provider_id": "groq", "purpose": "rewrite"},
    "rewrite.gemini_model": {"section": "providers", "provider_id": "gemini", "purpose": "rewrite"},
    "rewrite.local_ai_model": {"section": "local_inference", "provider_id": "local_ai", "purpose": "rewrite"},
    "rewrite.ollama_model": {"section": "local_inference", "provider_id": "ollama", "purpose": "rewrite"},
}

_STT_PROVIDER_OPTION_LABELS: dict[str, str] = {
    "gpu_server": "GPU STT server",
    "local_whisper": "Local Whisper STT",
    "groq": "Groq",
    "openai": "OpenAI",
    "google": "Google",
    "elevenlabs": "ElevenLabs",
}


def _model_option_label(option: Any) -> str:
    qualifiers: list[str] = []
    if option.is_preview and "preview" not in option.label.lower():
        qualifiers.append("preview")
    if option.is_deprecated:
        qualifiers.append("deprecated")
    if not qualifiers:
        return option.label
    return f"{option.label} ({', '.join(qualifiers)})"


def _model_field_spec(path: str) -> dict[str, Any]:
    metadata = _MODEL_FIELD_REGISTRY[path]
    options = models_for_provider_purpose(metadata["provider_id"], metadata["purpose"])
    return {
        "section": metadata["section"],
        "validation": {
            "kind": "enum",
            "provider_id": metadata["provider_id"],
            "purpose": metadata["purpose"],
            "enum_options": [option.model_id for option in options],
            "option_labels": [_model_option_label(option) for option in options],
        },
        "rebuilds_provider": True,
    }


_FIELD_SPECS: dict[str, dict[str, Any]] = {
    "api_mode": {
        "section": "providers",
        "validation": {"kind": "enum", "enum_options": [mode.value for mode in ApiMode]},
        "restart_required": True,
    },
    "hosted.base_url": {
        "section": "providers",
        "validation": {
            "kind": "url",
            "schemes": ["http", "https"],
            "min_length": 1,
            "allow_blank": False,
        },
        "restart_required": True,
    },
    "stt.providers": {
        "section": "providers",
        "validation": {
            "kind": "string_list",
            "enum_options": list(STT_PROVIDER_IDS),
            "option_labels": [_STT_PROVIDER_OPTION_LABELS[provider_id] for provider_id in STT_PROVIDER_IDS],
            "min_length": 1,
            "allow_blank": False,
        },
        "rebuilds_provider": True,
    },
    "stt.gpu_server.url": {
        "section": "local_inference",
        "validation": {
            "kind": "url",
            "schemes": ["http", "https"],
            "min_length": 1,
            "allow_blank": False,
        },
        "rebuilds_provider": True,
    },
    "stt.gpu_server.timeout": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "stt.gpu_server.probe_timeout_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "stt.gpu_server.unhealthy_cooldown_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "stt.gpu_server.probe_interval_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "stt.local_whisper.url": {
        "section": "local_inference",
        "validation": {
            "kind": "url",
            "schemes": ["http", "https"],
            "min_length": 1,
            "allow_blank": False,
        },
        "rebuilds_provider": True,
    },
    "stt.local_whisper.timeout": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "stt.local_whisper.probe_timeout_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "stt.local_whisper.unhealthy_cooldown_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "stt.local_whisper.probe_interval_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.ollama_base_url": {
        "section": "local_inference",
        "validation": {
            "kind": "url",
            "schemes": ["http", "https"],
            "min_length": 1,
            "allow_blank": False,
        },
        "rebuilds_provider": True,
    },
    "rewrite.ollama_timeout_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.ollama_probe_timeout_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.ollama_unhealthy_cooldown_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.ollama_probe_interval_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.local_ai_url": {
        "section": "local_inference",
        "validation": {
            "kind": "url",
            "schemes": ["http", "https"],
            "min_length": 1,
            "allow_blank": False,
        },
        "rebuilds_provider": True,
    },
    "rewrite.local_ai_timeout_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.local_ai_probe_timeout_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.local_ai_unhealthy_cooldown_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "rewrite.local_ai_probe_interval_s": {
        "section": "local_inference",
        "validation": {"kind": "number", "min_value": 0.000001},
        "rebuilds_provider": True,
    },
    "context.screenshot_enabled": {
        "section": "booleans",
        "validation": {"kind": "boolean"},
        "applies_live": True,
    },
    "cache.enabled": {
        "section": "booleans",
        "validation": {"kind": "boolean"},
        "applies_live": True,
    },
    "paste.enabled": {
        "section": "booleans",
        "validation": {"kind": "boolean"},
        "applies_live": True,
    },
    "learning.enabled": {
        "section": "booleans",
        "validation": {"kind": "boolean"},
        "applies_live": True,
    },
    "learning.phrase_hints_enabled": {
        "section": "booleans",
        "validation": {"kind": "boolean"},
        "applies_live": True,
    },
    "learning.rewrite_steering_enabled": {
        "section": "booleans",
        "validation": {"kind": "boolean"},
        "applies_live": True,
    },
    "rewrite.enabled": {
        "section": "booleans",
        "validation": {"kind": "boolean"},
        "rebuilds_provider": True,
    },
    "context.screenshot_max_width": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 1},
        "restart_required": True,
    },
    "context.screenshot_jpeg_quality": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 1, "max_value": 100},
        "restart_required": True,
    },
    "cache.max_age_hours": {
        "section": "numeric_tuning",
        "validation": {"kind": "number", "min_value": 0},
        "applies_live": True,
    },
    "cache.max_runs": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 1},
        "applies_live": True,
    },
    "cache.analysis_threshold": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 1},
        "applies_live": True,
    },
    "trigger.chord_timeout_ms": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 1},
        "restart_required": True,
    },
    "trigger.chord_debounce_ms": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 1},
        "restart_required": True,
    },
    "trigger.silence_timeout_s": {
        "section": "numeric_tuning",
        "validation": {"kind": "number", "min_value": 0},
        "restart_required": True,
    },
    "paste.clipboard_delay_ms": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 0},
        "applies_live": True,
    },
    "rewrite.context_budget_pct": {
        "section": "numeric_tuning",
        "validation": {"kind": "number", "min_value": 0.000001, "max_value": 1.0},
        "rebuilds_provider": True,
    },
    "rewrite.model_context_tokens": {
        "section": "numeric_tuning",
        "validation": {"kind": "integer", "min_value": 1},
        "rebuilds_provider": True,
    },
    "trigger.mode": {
        "section": "trigger_paste",
        "validation": {"kind": "enum", "enum_options": ["auto", "mouse", "keyboard"]},
        "restart_required": True,
    },
    "trigger.record_mode": {
        "section": "trigger_paste",
        "validation": {"kind": "enum", "enum_options": ["toggle", "hold"]},
        "restart_required": True,
    },
    "paste.wayland_keystroke_tool": {
        "section": "trigger_paste",
        "validation": {"kind": "enum", "enum_options": ["auto", "wtype", "ydotool", "xdotool"]},
        "restart_required": True,
    },
    "learning.scope_policy": {
        "section": "learning",
        "validation": {
            "kind": "enum",
            "enum_options": [policy.value for policy in LearningScopePolicy],
        },
        "applies_live": True,
    },
    "learning.disabled_apps": {
        "section": "learning",
        "validation": {"kind": "string_list", "allow_blank": False},
        "applies_live": True,
    },
}

_FIELD_SPECS.update({path: _model_field_spec(path) for path in _MODEL_FIELD_REGISTRY})

_SECTION_KEYS = (
    "providers",
    "local_inference",
    "booleans",
    "numeric_tuning",
    "trigger_paste",
    "learning",
    "desktop",
    "diagnostics",
)

def collect_settings_state(
    settings: Settings,
    token_store: Any | None = None,
    capability_report: DesktopCapabilityReport | None = None,
    learning_store: Any | None = None,
    local_inference_health: dict[str, LocalInferenceHealthResult] | None = None,
    paid_fallback_warning: PaidFallbackWarningState | None = None,
) -> SettingsState:
    signed_in = _hosted_signed_in(settings, token_store)
    return SettingsState(
        api_mode=_enum_value(settings.api_mode),
        hosted_signed_in=signed_in,
        hosted_base_url=settings.hosted.base_url,
        providers=_provider_statuses(settings),
        screenshot_enabled=settings.context.screenshot_enabled,
        context_enabled=settings.context.screenshot_enabled,
        local_cache_enabled=settings.cache.enabled,
        legal_urls=dict(LEGAL_URLS),
        secrets={
            "provider_api_keys": "redacted",
            "hosted_tokens": "stored" if signed_in else "missing",
            "secrets_env": "present" if _secrets_env_path().exists() else "missing",
        },
        desktop=_desktop_summary(capability_report),
        desktop_integration=_desktop_integration_state(),
        learning=_learning_state(settings, learning_store),
        local_inference_health=local_inference_health,
        paid_fallback_warning=paid_fallback_warning,
        sections=_build_sections_with_discovery(settings, local_inference_health),
    )


def save_settings_patch(
    patch: SettingsPatch | dict[str, Any],
    *,
    local_inference_health: dict[str, LocalInferenceHealthResult] | None = None,
) -> SettingsApplyResult:
    patch = patch if isinstance(patch, SettingsPatch) else SettingsPatch(**patch)
    _validate_patch_path(patch.path)

    path = _config_toml_path()
    data = _load_config_toml(path)
    candidate = json.loads(json.dumps(data))
    _set_nested(
        candidate,
        patch.path.split("."),
        _coerce_patch_value(
            patch.path,
            patch.value,
            local_inference_health=local_inference_health,
        ),
    )

    validated_settings = Settings(**candidate)
    _set_nested(data, patch.path.split("."), _normalized_leaf_value(validated_settings, patch.path))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_dump_toml(data), encoding="utf-8")
    return build_apply_result(patch.path)


def save_secret_settings_patch(patch: SecretSettingsPatch | dict[str, Any]) -> SettingsApplyResult:
    patch = patch if isinstance(patch, SecretSettingsPatch) else SecretSettingsPatch(**patch)
    if patch.path not in SecretSettingsPatch.ALLOWED_PATHS:
        raise ValueError(f"unsupported secret settings path: {patch.path}")
    if patch.value is not None and not isinstance(patch.value, str):
        raise ValueError(f"{patch.path} requires a string or null value")
    secret_value = patch.value.strip() if isinstance(patch.value, str) else None
    write_secrets_env(_secrets_env_path(), {BYOK_SECRET_ENV_NAMES[patch.path]: secret_value or None})
    return build_apply_result(patch.path)


def _build_sections(settings: Settings) -> dict[str, list[SettingsFieldState]]:
    return _build_sections_with_discovery(settings, local_inference_health=None)


def _build_sections_with_discovery(
    settings: Settings,
    local_inference_health: dict[str, LocalInferenceHealthResult] | None,
) -> dict[str, list[SettingsFieldState]]:
    sections = {key: [] for key in _SECTION_KEYS}
    for path, spec in _FIELD_SPECS.items():
        value = _normalized_leaf_value(settings, path)
        validation_data = _validation_data_for_path(path, local_inference_health)
        validation = SettingsFieldValidation(**validation_data)
        value_supported = None
        unsupported_legacy_value = None
        if path in _MODEL_FIELD_REGISTRY:
            allowed = set(validation.enum_options or [])
            value_supported = isinstance(value, str) and value in allowed
            unsupported_legacy_value = None if value_supported else value
        sections[spec["section"]].append(
            SettingsFieldState(
                path=path,
                value=value,
                validation=validation,
                value_supported=value_supported,
                unsupported_legacy_value=unsupported_legacy_value,
                applies_live=bool(spec.get("applies_live", False)),
                rebuilds_provider=bool(spec.get("rebuilds_provider", False)),
                restart_required=bool(spec.get("restart_required", False)),
            )
        )
    return sections


def _validation_data_for_path(
    path: str,
    local_inference_health: dict[str, LocalInferenceHealthResult] | None,
) -> dict[str, Any]:
    validation_data = dict(_FIELD_SPECS[path]["validation"])
    _apply_local_discovery_overlay(path, validation_data, local_inference_health)
    return validation_data


def _apply_local_discovery_overlay(
    path: str,
    validation_data: dict[str, Any],
    local_inference_health: dict[str, LocalInferenceHealthResult] | None,
) -> None:
    endpoint_id = _local_model_endpoint_id(path)
    if endpoint_id is None or local_inference_health is None:
        return
    result = local_inference_health.get(endpoint_id)
    if result is None:
        return
    enum_options = list(validation_data.get("enum_options") or [])
    option_labels = list(validation_data.get("option_labels") or [])
    for model in result.discovered_models:
        if not model.selectable or model.model_id in enum_options:
            continue
        enum_options.append(model.model_id)
        option_labels.append(model.label)
    validation_data["enum_options"] = enum_options
    validation_data["option_labels"] = option_labels


def _local_model_endpoint_id(path: str) -> str | None:
    return {
        "stt.local_whisper_model": "local_whisper",
        "rewrite.local_ai_model": "local_ai",
        "rewrite.ollama_model": "ollama",
    }.get(path)


def apply_mode_for_path(path: str) -> ApplyMode:
    if path in SecretSettingsPatch.ALLOWED_PATHS:
        return ApplyMode.PROVIDER_REBUILD
    spec = _FIELD_SPECS.get(path)
    if spec is None:
        raise ValueError(f"unsupported settings path: {path}")
    if spec.get("applies_live", False):
        return ApplyMode.LIVE
    if spec.get("rebuilds_provider", False):
        return ApplyMode.PROVIDER_REBUILD
    return ApplyMode.RESTART_REQUIRED


def build_apply_result(path: str) -> SettingsApplyResult:
    apply_mode = apply_mode_for_path(path)
    runtime_status = (
        RuntimeApplyStatus.RESTART_REQUIRED
        if apply_mode == ApplyMode.RESTART_REQUIRED
        else RuntimeApplyStatus.PENDING
    )
    return SettingsApplyResult(
        path=path,
        apply_mode=apply_mode,
        restart_required=apply_mode == ApplyMode.RESTART_REQUIRED,
        runtime_status=runtime_status,
    )


def _validate_patch_path(path: str) -> None:
    lowered = path.lower()
    if path not in SettingsPatch.ALLOWED_PATHS:
        if any(part in lowered for part in SettingsPatch.SECRET_PATH_PARTS):
            raise ValueError(f"refusing to write secret setting path: {path}")
        raise ValueError(f"unsupported settings path: {path}")


def _coerce_patch_value(
    path: str,
    value: Any,
    *,
    local_inference_health: dict[str, LocalInferenceHealthResult] | None = None,
) -> Any:
    spec = _validation_data_for_path(path, local_inference_health)
    kind = spec["kind"]
    if isinstance(value, enum.Enum):
        value = value.value
    if kind == "boolean":
        if isinstance(value, bool):
            return value
        if isinstance(value, str) and value.lower() in {"true", "false"}:
            return value.lower() == "true"
        raise ValueError(f"{path} requires a boolean value")
    if kind == "enum":
        if not isinstance(value, str):
            raise ValueError(f"{path} requires a string value")
        allowed = set(spec["enum_options"])
        if value not in allowed:
            raise ValueError(f"{path} must be one of {sorted(allowed)}")
        return value
    if kind == "integer":
        if isinstance(value, bool):
            raise ValueError(f"{path} requires an integer value")
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            return int(value)
        raise ValueError(f"{path} requires an integer value")
    if kind == "number":
        if isinstance(value, bool):
            raise ValueError(f"{path} requires a numeric value")
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            return float(value)
        raise ValueError(f"{path} requires a numeric value")
    if kind == "string":
        if not isinstance(value, str):
            raise ValueError(f"{path} requires a string value")
        return value
    if kind == "url":
        if not isinstance(value, str):
            raise ValueError(f"{path} requires a URL string")
        return value
    if kind == "string_list":
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            raise ValueError(f"{path} requires a list of strings")
        if not spec.get("allow_blank", True) and any(not item.strip() for item in value):
            raise ValueError(f"{path} must not contain blank values")
        enum_options = spec.get("enum_options")
        if enum_options is not None:
            unknown = sorted(set(value) - set(enum_options))
            if unknown:
                raise ValueError(f"{path} contains unsupported values: {unknown}")
        return value
    return value


def _provider_statuses(settings: Settings) -> list[ProviderStatus]:
    return [
        ProviderStatus(
            name=provider_id,
            configured=bool(get_provider_secret(settings, provider_id)),
            status="configured" if get_provider_secret(settings, provider_id) else "missing",
        )
        for provider_id in BYOK_PROVIDER_IDS
    ]


def _hosted_signed_in(settings: Settings, token_store: Any | None) -> bool:
    if token_store is not None:
        try:
            return token_store.load() is not None
        except Exception:
            return False
    return settings.has_hosted_token()


def _desktop_summary(report: DesktopCapabilityReport | None) -> DesktopCapabilitySummary:
    if report is None:
        return DesktopCapabilitySummary(
            privacy_notes=[
                "Desktop capability was not probed for this render; no screenshots, text, transcripts, tokens, or provider keys were captured."
            ]
        )
    return DesktopCapabilitySummary(
        display_server=report.display_server,
        selected_adapters=dict(report.selected_adapters),
        confidence=_enum_value(report.confidence),
        tray_support=report.tray_support,
        missing_dependencies=list(report.missing_dependencies),
        warnings=list(report.warnings),
        privacy_notes=list(report.privacy_notes),
    )


def _desktop_integration_state() -> DesktopIntegrationSettingsState:
    try:
        from talk_to_tux.desktop_integration import get_status

        status = get_status()
        return DesktopIntegrationSettingsState(
            launcher_installed=status.launcher_installed,
            autostart_enabled=status.autostart_enabled,
            launcher_path=str(status.launcher_path),
            autostart_path=str(status.autostart_path),
            command=status.command,
            icon_path=str(status.icon_path),
            warnings=list(status.warnings),
        )
    except Exception as exc:
        return DesktopIntegrationSettingsState(warnings=[f"desktop integration unavailable: {exc}"])


def _learning_state(settings: Settings, learning_store: Any | None) -> LearningSettingsState:
    learning = getattr(settings, "learning", None)
    disabled_apps = list(getattr(learning, "disabled_apps", []) or [])
    if learning_store is not None and hasattr(learning_store, "disabled_apps"):
        disabled_apps = list(getattr(learning_store, "disabled_apps") or disabled_apps)
    return LearningSettingsState(
        enabled=bool(getattr(learning, "enabled", settings.correction.enabled)),
        scope_policy=_enum_value(getattr(learning, "scope_policy", LearningScopePolicy.GLOBAL)),
        phrase_hints_enabled=bool(getattr(learning, "phrase_hints_enabled", True)),
        rewrite_steering_enabled=bool(getattr(learning, "rewrite_steering_enabled", True)),
        disabled_apps=disabled_apps,
    )


def _enum_value(value: Any) -> str:
    return value.value if isinstance(value, enum.Enum) else str(value)


def _load_config_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as fh:
        return tomllib.load(fh)


def _normalized_leaf_value(settings: Settings, path: str) -> Any:
    value = _get_nested_attr(settings, path.split("."))
    if isinstance(value, enum.Enum):
        return value.value
    if isinstance(value, list):
        return [
            item.value if isinstance(item, enum.Enum) else item
            for item in value
        ]
    return value


def _get_nested_attr(value: Any, keys: list[str]) -> Any:
    node = value
    for key in keys:
        node = getattr(node, key)
    return node


def _set_nested(data: dict[str, Any], keys: list[str], value: Any) -> None:
    node = data
    for key in keys[:-1]:
        child = node.setdefault(key, {})
        if not isinstance(child, dict):
            raise ValueError(f"cannot write nested setting through non-table: {key}")
        node = child
    node[keys[-1]] = value


def _dump_toml(data: dict[str, Any]) -> str:
    lines: list[str] = []
    scalars = {
        k: v
        for k, v in data.items()
        if not isinstance(v, dict) and (not isinstance(v, list) or _is_scalar_list(v))
    }
    tables = {k: v for k, v in data.items() if isinstance(v, dict)}
    arrays = {k: v for k, v in data.items() if isinstance(v, list) and not _is_scalar_list(v)}
    for key, value in scalars.items():
        lines.append(f"{_toml_key(key)} = {_toml_value(value)}")
    if scalars and (tables or arrays):
        lines.append("")
    for key, value in tables.items():
        _dump_table(lines, [key], value)
    for key, value in arrays.items():
        for item in value:
            if isinstance(item, dict):
                lines.append(f"[[{_toml_key(key)}]]")
                for child_key, child_value in item.items():
                    lines.append(f"{_toml_key(child_key)} = {_toml_value(child_value)}")
                lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _dump_table(lines: list[str], path: list[str], table: dict[str, Any]) -> None:
    scalar_items = {k: v for k, v in table.items() if not isinstance(v, dict)}
    child_tables = {k: v for k, v in table.items() if isinstance(v, dict)}
    lines.append(f"[{'.'.join(_toml_key(p) for p in path)}]")
    for key, value in scalar_items.items():
        lines.append(f"{_toml_key(key)} = {_toml_value(value)}")
    lines.append("")
    for key, value in child_tables.items():
        _dump_table(lines, path + [key], value)


def _is_scalar_list(value: list[Any]) -> bool:
    return all(not isinstance(item, dict) for item in value)


def _toml_key(key: str) -> str:
    if key.replace("_", "").replace("-", "").isalnum():
        return key
    return json.dumps(key)


def _toml_value(value: Any) -> str:
    if isinstance(value, enum.Enum):
        value = value.value
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int | float):
        return str(value)
    if isinstance(value, list):
        return "[" + ", ".join(_toml_value(v) for v in value) + "]"
    if value is None:
        return '""'
    return json.dumps(str(value))


def state_contains_secret(state: SettingsState, secret: str) -> bool:
    return secret in json.dumps(state.model_dump(), sort_keys=True)
