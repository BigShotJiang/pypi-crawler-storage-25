"""GitHub OAuth PKCE loopback flow for hosted mode."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import secrets
import socket
import webbrowser
from datetime import datetime
from typing import Callable
from urllib.parse import parse_qs, urlencode, urlsplit

import httpx

from talk_to_tux.auth import AuthFailed, TokenStore, Tokens, parse_access_token
from talk_to_tux.config import HostedConfig


def _pick_free_port() -> int:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    return port


def _pkce_pair() -> tuple[str, str]:
    """Return (verifier, challenge)."""
    verifier = secrets.token_urlsafe(64)[:128]
    challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
        .rstrip(b"=")
        .decode()
    )
    return verifier, challenge


_HTML_OK = (
    b"HTTP/1.1 200 OK\r\n"
    b"Content-Type: text/html\r\n"
    b"Connection: close\r\n"
    b"\r\n"
    b"<html><body><h1>You can close this tab.</h1></body></html>"
)


async def login_interactive(
    hosted_config: HostedConfig,
    token_store: TokenStore,
    *,
    open_browser: Callable[[str], None] = webbrowser.open,
    http_client: httpx.AsyncClient | None = None,
    loopback_timeout_s: float = 120.0,
) -> Tokens:
    """Run the GitHub OAuth PKCE flow and return saved Tokens."""
    code_verifier, code_challenge = _pkce_pair()
    port = _pick_free_port()

    callback_future: asyncio.Future[str] = asyncio.get_event_loop().create_future()

    async def _handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            request_line = await reader.readline()
            # consume remaining headers
            while True:
                line = await reader.readline()
                if line in (b"\r\n", b"\n", b""):
                    break

            parts = request_line.decode(errors="replace").split()
            if len(parts) < 2:
                writer.close()
                return

            path = parts[1]
            parsed = urlsplit(path)
            qs = parse_qs(parsed.query)
            got_code = qs.get("code", [None])[0]

            writer.write(_HTML_OK)
            await writer.drain()
            writer.close()

            if not callback_future.done():
                callback_future.set_result(got_code or "")
        except Exception as exc:
            if not callback_future.done():
                callback_future.set_exception(exc)

    server = await asyncio.start_server(_handle, "127.0.0.1", port)
    async with server:
        redirect_uri = f"http://127.0.0.1:{port}/oauth/callback"
        params = urlencode({
            "redirect_to": redirect_uri,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "provider": "github",
        })
        auth_url = f"{hosted_config.base_url}/functions/v1/auth-start?{params}"

        open_browser(auth_url)

        try:
            code = await asyncio.wait_for(
                asyncio.shield(callback_future),
                timeout=loopback_timeout_s,
            )
        except asyncio.TimeoutError:
            raise AuthFailed("loopback_timeout")
        except AuthFailed:
            raise

    owns_client = http_client is None
    if owns_client:
        http_client = httpx.AsyncClient(timeout=30.0)

    try:
        resp = await http_client.post(
            f"{hosted_config.base_url}/functions/v1/auth-callback",
            json={
                "code": code,
                "code_verifier": code_verifier,
                "device_label": "desktop-linux",
            },
        )
        if resp.status_code == 401:
            raise AuthFailed("code_exchange_rejected")
        if resp.status_code == 403:
            raise AuthFailed("not_approved_for_beta")

        data = resp.json()
        access_token = data["access_token"]

        try:
            parse_access_token(access_token)
        except ValueError:
            raise AuthFailed("bad_token_format")

        tokens = Tokens(
            access_token=access_token,
            refresh_token=data.get("refresh_token"),
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
            user_email=data["user"]["email"],
            tier=data["user"]["tier"],
        )
        token_store.save(tokens)
        return tokens
    finally:
        if owns_client:
            await http_client.aclose()
