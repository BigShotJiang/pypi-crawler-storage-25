"""Boot-resilient display detection.

After reboot the inherited DISPLAY / WAYLAND_DISPLAY env vars may be stale
(e.g. :0 when the actual X server is at :1).  This module validates the
current value and, if broken, probes the system for a working display so
downstream X11 tools (xdotool, xclip, scrot, xprop) work immediately.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
from pathlib import Path

from talk_to_tux.context.adapters import AdapterConfidence
from talk_to_tux.context.models import DesktopCapabilityReport, DesktopToolStatus

logger = logging.getLogger(__name__)

_PROBE_TIMEOUT = 2  # seconds per candidate

_TOOL_PURPOSES: dict[str, str] = {
    "gdbus": "portal, GNOME Shell extension, and D-Bus checks",
    "busctl": "desktop portal state checks",
    "dbus-send": "AT-SPI bus checks",
    "xdotool": "X11 window and keystroke control",
    "xprop": "X11 window metadata",
    "grim": "Wayland screenshot capture",
    "scrot": "X11 screenshot capture fallback",
    "import": "ImageMagick X11 window screenshot capture",
    "wl-copy": "Wayland clipboard writes",
    "wl-paste": "Wayland clipboard reads",
    "xclip": "X11 clipboard writes",
    "wtype": "Wayland keystroke injection",
    "ydotool": "evdev keystroke injection",
    "ydotoold": "ydotool daemon",
}


def _validate_wayland(runtime_dir: str, wayland_display: str) -> bool:
    """Return True if the WAYLAND_DISPLAY socket exists."""
    sock = Path(runtime_dir) / wayland_display
    return sock.exists()


def _probe_wayland_sockets(runtime_dir: str) -> str | None:
    """Scan XDG_RUNTIME_DIR for wayland-* sockets; return first found or None."""
    rd = Path(runtime_dir)
    if not rd.is_dir():
        return None
    for entry in sorted(rd.iterdir()):
        if entry.name.startswith("wayland-") and not entry.name.endswith(".lock"):
            return entry.name
    return None


def _validate_x11(display: str) -> bool:
    """Return True if xdotool can reach the given DISPLAY."""
    env = {**os.environ, "DISPLAY": display}
    try:
        result = subprocess.run(
            ["xdotool", "getactivewindow"],
            env=env,
            capture_output=True,
            timeout=_PROBE_TIMEOUT,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False


def _probe_x11_sockets() -> str | None:
    """Scan /tmp/.X11-unix/ for X* sockets and return first working `:N`."""
    x11_dir = Path("/tmp/.X11-unix")
    if not x11_dir.is_dir():
        return None
    for entry in sorted(x11_dir.iterdir()):
        name = entry.name
        if not name.startswith("X"):
            continue
        display_num = name[1:]
        if not display_num.isdigit():
            continue
        candidate = f":{display_num}"
        if _validate_x11(candidate):
            return candidate
    return None


def detect_and_fix_display() -> str | None:
    """Ensure DISPLAY/WAYLAND_DISPLAY points to a working server.

    Validates the current env vars and, if stale, probes the system for a
    working display.  Fixes ``os.environ`` in-place so all downstream code
    inherits the corrected value.

    Returns the display string (e.g. ``":1"`` or ``"wayland-0"``) on success,
    or ``None`` if no working display could be found.
    """
    runtime_dir = os.environ.get("XDG_RUNTIME_DIR", "")

    # --- Wayland path ---
    wayland = os.environ.get("WAYLAND_DISPLAY", "")
    if wayland:
        if runtime_dir and _validate_wayland(runtime_dir, wayland):
            return wayland
        # Socket missing — try probing
        if runtime_dir:
            found = _probe_wayland_sockets(runtime_dir)
            if found:
                logger.warning(
                    "Stale WAYLAND_DISPLAY=%s — fixed to %s", wayland, found,
                )
                os.environ["WAYLAND_DISPLAY"] = found
                return found

    # --- X11 path ---
    display = os.environ.get("DISPLAY", "")
    if display:
        if _validate_x11(display):
            return display
        # Current DISPLAY is stale — probe sockets
        found = _probe_x11_sockets()
        if found:
            logger.warning(
                "Stale DISPLAY=%s — fixed to %s", display, found,
            )
            os.environ["DISPLAY"] = found
            return found

    # --- DISPLAY not set — probe from scratch ---
    if not display and not wayland:
        # Try Wayland first
        if runtime_dir:
            found_wl = _probe_wayland_sockets(runtime_dir)
            if found_wl:
                logger.warning("WAYLAND_DISPLAY unset — discovered %s", found_wl)
                os.environ["WAYLAND_DISPLAY"] = found_wl
                return found_wl
        # Then X11
        found_x = _probe_x11_sockets()
        if found_x:
            logger.warning("DISPLAY unset — discovered %s", found_x)
            os.environ["DISPLAY"] = found_x
            return found_x

    return None


def _portal_available() -> bool | None:
    if shutil.which("busctl") is None:
        return None
    try:
        result = subprocess.run(
            ["busctl", "--user", "list"],
            capture_output=True,
            text=True,
            timeout=_PROBE_TIMEOUT,
        )
        if result.returncode != 0:
            return False
        return "org.freedesktop.portal.Desktop" in result.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def _atspi_available() -> bool | None:
    try:
        from talk_to_tux.context.accessibility import _check_atspi_bus

        return _check_atspi_bus()
    except Exception:
        logger.debug("AT-SPI capability probe failed", exc_info=True)
        return None


def _tool_statuses(selected: set[str]) -> dict[str, DesktopToolStatus]:
    statuses: dict[str, DesktopToolStatus] = {}
    for name, purpose in _TOOL_PURPOSES.items():
        statuses[name] = DesktopToolStatus(
            name=name,
            installed=shutil.which(name) is not None,
            purpose=purpose,
            selected=name in selected,
        )
    return statuses


def _selected_adapters(display_server: str, tools: dict[str, DesktopToolStatus]) -> dict[str, str]:
    selected: dict[str, str] = {}
    if display_server == "wayland":
        selected["window"] = "ttt-gnome-dbus" if tools["gdbus"].installed else "unavailable"
        if tools["grim"].installed:
            selected["screenshot"] = "grim"
        elif tools["gdbus"].installed:
            selected["screenshot"] = "portal"
        elif tools["scrot"].installed:
            selected["screenshot"] = "scrot"
        else:
            selected["screenshot"] = "unavailable"
        selected["clipboard"] = "wl-copy" if tools["wl-copy"].installed else "unavailable"
        for backend in ("wtype", "ydotool", "xdotool"):
            if tools[backend].installed:
                selected["keystroke"] = backend
                break
        selected.setdefault("keystroke", "unavailable")
    elif display_server == "x11":
        selected["window"] = "wnck-or-xdotool"
        selected["screenshot"] = "import-window" if tools["import"].installed else ("scrot" if tools["scrot"].installed else "unavailable")
        selected["clipboard"] = "xclip" if tools["xclip"].installed else "unavailable"
        selected["keystroke"] = "xdotool" if tools["xdotool"].installed else "unavailable"
    else:
        selected["window"] = "unavailable"
        selected["screenshot"] = "unavailable"
        selected["clipboard"] = "unavailable"
        selected["keystroke"] = "unavailable"
    selected["text_context"] = "atspi-subprocess" if tools["dbus-send"].installed else "unavailable"
    selected["tray_settings"] = "unknown"
    return selected


def probe_desktop_capabilities(*, fix_display: bool = True) -> DesktopCapabilityReport:
    """Return a normalized, side-effect-light desktop capability report."""
    original_display = os.environ.get("DISPLAY") or None
    original_wayland = os.environ.get("WAYLAND_DISPLAY") or None
    fixed = detect_and_fix_display() if fix_display else (original_wayland or original_display)
    display = os.environ.get("DISPLAY") or None
    wayland = os.environ.get("WAYLAND_DISPLAY") or None

    if wayland:
        display_server = "wayland"
    elif display:
        display_server = "x11"
    else:
        display_server = "unknown"

    xdg_current_desktop = os.environ.get("XDG_CURRENT_DESKTOP") or None
    session_type = os.environ.get("XDG_SESSION_TYPE") or None
    desktop_lower = (xdg_current_desktop or "").lower()
    compositor_hints = []
    if "gnome" in desktop_lower:
        compositor_hints.append("gnome-shell")
    if "kde" in desktop_lower or "plasma" in desktop_lower:
        compositor_hints.append("kwin")
    if display_server == "wayland" and not compositor_hints:
        compositor_hints.append("unknown-wayland")

    selected_names: set[str] = set()
    tools = _tool_statuses(selected_names)
    selected_adapters = _selected_adapters(display_server, tools)
    for name in selected_adapters.values():
        if name in tools:
            tools[name].selected = True
        if name == "import-window":
            tools["import"].selected = True
        if name == "wnck-or-xdotool":
            tools["xdotool"].selected = True

    missing: list[str] = []
    warnings: list[str] = []
    for adapter in ("window", "screenshot", "clipboard", "keystroke"):
        if selected_adapters.get(adapter) == "unavailable":
            missing.append(adapter)
    if display_server == "unknown":
        warnings.append("no working display found")
    if fixed and fixed not in {original_display, original_wayland}:
        warnings.append(f"stale display fixed to {fixed}")
    if display_server == "wayland":
        if "gnome-shell" in compositor_hints:
            warnings.append("GNOME Wayland may need the Talk-to-Tux Shell extension for window context")
        elif "unknown-wayland" in compositor_hints:
            warnings.append("unknown Wayland compositor; window context may be degraded")

    portal = _portal_available() if display_server == "wayland" else None
    atspi = _atspi_available()
    if atspi is False:
        warnings.append("AT-SPI bus unreachable; widget text context disabled")

    return DesktopCapabilityReport(
        display_server=display_server,
        display=display,
        wayland_display=wayland,
        xdg_current_desktop=xdg_current_desktop,
        session_type=session_type,
        compositor_hints=compositor_hints,
        tools=tools,
        portal_available=portal,
        atspi_available=atspi,
        tray_support="unknown",
        selected_adapters=selected_adapters,
        missing_dependencies=missing,
        warnings=warnings,
        privacy_notes=[
            "Capability probing records tool/session state only; it does not capture screenshots, text, transcripts, tokens, or provider keys."
        ],
        confidence=AdapterConfidence.MEDIUM if display_server != "unknown" else AdapterConfidence.LOW,
    )
