from __future__ import annotations

import json
import logging
import os
import re
import subprocess

from talk_to_tux.context.adapters import (
    AdapterConfidence,
    AdapterKind,
    AdapterResult,
    WINDOW_BACKENDS,
    WINDOW_BACKENDS_EXECUTOR_SAFE,
    adapter_degraded,
    adapter_missing,
    adapter_success,
)
from talk_to_tux.context.models import WindowInfo

logger = logging.getLogger(__name__)

_wnck_warned: bool = False
_wnck_logged: bool = False
_dbus_ttt_warned: bool = False
_dbus_gnome_warned: bool = False
_wayland_limit_logged: bool = False


_force_xdotool: bool = False


def force_xdotool_backend() -> None:
    """Force xdotool backend (avoids Wnck thread-safety issues with GTK)."""
    global _force_xdotool
    _force_xdotool = True


def get_window_info() -> WindowInfo | None:
    """Get active window metadata.

    Tries: Wnck → TTT D-Bus → window-calls-extended D-Bus → xdotool → warning.
    """
    result = get_window_result(executor_safe=_force_xdotool)
    if result.usable:
        return result.value
    if os.environ.get("WAYLAND_DISPLAY"):
        _log_wayland_limitation()
    return None


def get_window_result(*, executor_safe: bool = False) -> AdapterResult[WindowInfo]:
    """Get active window metadata with backend provenance and diagnostics."""
    attempted: list[str] = []
    if not executor_safe:
        attempted.append("wnck")
        result = _window_backend_result("wnck", _get_via_wnck)
        if result.usable:
            return result
    if os.environ.get("WAYLAND_DISPLAY"):
        for backend, fn in (
            ("ttt-gnome-dbus", _get_via_dbus_ttt),
            ("window-calls-extended", _get_via_dbus_gnome),
        ):
            attempted.append(backend)
            result = _window_backend_result(backend, fn)
            if result.usable:
                return result
    attempted.append("xdotool")
    result = _window_backend_result("xdotool", _get_via_xdotool)
    if result.usable:
        return result
    expected = WINDOW_BACKENDS_EXECUTOR_SAFE if executor_safe else WINDOW_BACKENDS
    missing = ["gdbus"] if os.environ.get("WAYLAND_DISPLAY") and "ttt-gnome-dbus" in attempted else []
    return adapter_degraded(
        AdapterKind.ACTIVE_WINDOW,
        "none",
        reason="no focused window metadata available",
        provenance=[b for b in expected if b in attempted],
        missing_tools=missing,
        diagnostics={"wayland": bool(os.environ.get("WAYLAND_DISPLAY"))},
    )


def _window_backend_result(
    backend: str, fn,
) -> AdapterResult[WindowInfo]:
    try:
        info = fn()
    except Exception as exc:
        return adapter_degraded(
            AdapterKind.ACTIVE_WINDOW,
            backend,
            reason=f"{backend} raised {exc.__class__.__name__}",
            diagnostics={"exception": str(exc)},
        )
    if info is None:
        missing = []
        if backend in {"ttt-gnome-dbus", "window-calls-extended"}:
            missing = ["gdbus"]
        elif backend == "xdotool":
            missing = ["xdotool", "xprop"]
        return adapter_missing(
            AdapterKind.ACTIVE_WINDOW,
            backend,
            missing,
            reason=f"{backend} returned no focused window",
        )
    info.backend = backend
    info.provenance = [backend]
    info.confidence = AdapterConfidence.HIGH
    if info.geometry is None and backend in {"ttt-gnome-dbus", "window-calls-extended"}:
        info.confidence = AdapterConfidence.MEDIUM
        info.degraded_reason = "geometry unavailable"
    return adapter_success(
        AdapterKind.ACTIVE_WINDOW,
        backend,
        info,
        confidence=info.confidence,
        diagnostics={"has_geometry": info.geometry is not None},
    )


def _get_via_wnck() -> WindowInfo | None:
    """Get window info via libwnck (GObject introspection)."""
    try:
        import gi

        gi.require_version("Wnck", "3.0")
        from gi.repository import Wnck
    except (ImportError, ValueError):
        global _wnck_warned
        if not _wnck_warned:
            logger.debug("Wnck not available, falling back to xdotool")
            _wnck_warned = True
        return None

    global _wnck_logged
    if not _wnck_logged:
        logger.debug("Using Wnck for window detection")
        _wnck_logged = True

    screen = Wnck.Screen.get_default()
    if screen is None:
        return None

    screen.force_update()
    window = screen.get_active_window()
    if window is None:
        return None

    xid = window.get_xid()
    return WindowInfo(
        title=window.get_name(),
        wm_class=window.get_class_group_name(),
        wm_instance=window.get_class_instance_name(),
        pid=window.get_pid(),
        window_id=str(xid) if xid else None,
    )


def _get_via_dbus_ttt() -> WindowInfo | None:
    """Try the bundled Talk-to-Tux GNOME Shell extension for window info.

    Queries our own extension's GetFocusedWindow D-Bus method.
    Returns None if the extension is v1 (no window support) or not running.
    """
    global _dbus_ttt_warned
    try:
        result = subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", "org.gnome.shell.extensions.TalkToTux",
                "--object-path", "/org/gnome/shell/extensions/TalkToTux/Window",
                "--method", "org.gnome.shell.extensions.TalkToTux.Window.GetFocusedWindow",
            ],
            capture_output=True,
            text=True,
            timeout=1.0,
        )
        if result.returncode != 0:
            if not _dbus_ttt_warned:
                logger.debug(
                    "Talk-to-Tux extension window D-Bus not available "
                    "(v1 or not running)"
                )
                _dbus_ttt_warned = True
            return None
        # Response format: ('{"wm_class":"Code",...}',)
        # gdbus escapes single quotes as \' in GVariant text — unescape
        # before JSON parsing (e.g. window titles with apostrophes).
        raw = result.stdout.strip()
        m = re.search(r"\('(.*)',\)", raw, re.DOTALL)
        if not m:
            return None
        data = json.loads(m.group(1).replace("\\'", "'"))
        if not data or not data.get("wm_class"):
            return None
        geometry = None
        if all(k in data for k in ("x", "y", "width", "height")):
            geometry = (data["x"], data["y"], data["width"], data["height"])
        return WindowInfo(
            title=data.get("title"),
            wm_class=data.get("wm_class"),
            wm_instance=data.get("wm_class_instance"),
            pid=data.get("pid"),
            window_id=str(data["id"]) if "id" in data else None,
            geometry=geometry,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        if not _dbus_ttt_warned:
            logger.debug("Talk-to-Tux D-Bus window query failed: %s", e)
            _dbus_ttt_warned = True
        return None
    except (ValueError, KeyError):
        logger.debug("Failed to parse Talk-to-Tux extension response")
        return None


def _get_via_dbus_gnome() -> WindowInfo | None:
    """Try GNOME Shell window extension for active window info on Wayland.

    Queries the 'window-calls-extended' GNOME Shell extension via D-Bus.
    Returns None if the extension is not installed (the common case).
    Install from: https://extensions.gnome.org/extension/4974/window-calls-extended/
    """
    global _dbus_gnome_warned
    try:
        result = subprocess.run(
            [
                "gdbus", "call", "--session",
                "--dest", "org.gnome.Shell",
                "--object-path", "/org/gnome/Shell/Extensions/Windows",
                "--method", "org.gnome.Shell.Extensions.Windows.List",
            ],
            capture_output=True,
            text=True,
            timeout=1.0,
        )
        if result.returncode != 0:
            if not _dbus_gnome_warned:
                logger.info(
                    "GNOME Shell window extension not found; "
                    "window context unavailable on pure Wayland"
                )
                _dbus_gnome_warned = True
            return None
        # Response: ('[ {"id":1, "title":"...", "wm_class":"...", "focus":true} ]',)
        # gdbus escapes single quotes as \' in GVariant text — unescape
        # before JSON parsing (e.g. window titles with apostrophes).
        raw = result.stdout.strip()
        m = re.search(r"\('(.*)',\)", raw, re.DOTALL)
        if not m:
            return None
        data = json.loads(m.group(1).replace("\\'", "'"))
        for win in data:
            if win.get("focus"):
                geometry = None
                if all(k in win for k in ("x", "y", "width", "height")):
                    geometry = (win["x"], win["y"], win["width"], win["height"])
                return WindowInfo(
                    title=win.get("title"),
                    wm_class=win.get("wm_class"),
                    wm_instance=win.get("wm_class_instance"),
                    pid=win.get("pid"),
                    geometry=geometry,
                )
        return None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        if not _dbus_gnome_warned:
            logger.debug("GNOME D-Bus window query failed: %s", e)
            _dbus_gnome_warned = True
        return None
    except (ValueError, KeyError):
        logger.debug("Failed to parse GNOME Shell extension response")
        return None


def _log_wayland_limitation() -> None:
    """Log a one-time warning about Wayland window detection limitations."""
    global _wayland_limit_logged
    if not _wayland_limit_logged:
        logger.warning(
            "Window detection unavailable on Wayland — "
            "app context and terminal detection will be limited. "
            "Restart GNOME Shell (log out/in) to activate the "
            "bundled Talk-to-Tux extension."
        )
        _wayland_limit_logged = True


def _get_via_xdotool() -> WindowInfo | None:
    """Get window info via xdotool + xprop subprocess calls."""
    try:
        # Get active window ID
        result = subprocess.run(
            ["xdotool", "getactivewindow"],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        if result.returncode != 0:
            logger.debug("xdotool getactivewindow failed: %s", result.stderr)
            return None
        wid = result.stdout.strip()

        # Get window title
        title_result = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowname"],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        title = title_result.stdout.strip() if title_result.returncode == 0 else None

        # Get window PID
        pid_result = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowpid"],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        pid = int(pid_result.stdout.strip()) if pid_result.returncode == 0 else None

        # Get WM_CLASS via xprop
        xprop_result = subprocess.run(
            ["xprop", "-id", wid, "WM_CLASS"],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        wm_instance = None
        wm_class = None
        if xprop_result.returncode == 0:
            wm_instance, wm_class = _parse_wm_class(xprop_result.stdout)

        return WindowInfo(
            title=title,
            wm_class=wm_class,
            wm_instance=wm_instance,
            pid=pid,
            window_id=wid,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        logger.debug("xdotool/xprop failed: %s", e)
        return None


def get_window_info_by_id(window_id: str) -> WindowInfo | None:
    """Get window metadata for a specific window ID via xdotool + xprop."""
    try:
        # Get window title
        title_result = subprocess.run(
            ["xdotool", "getwindowname", window_id],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        title = title_result.stdout.strip() if title_result.returncode == 0 else None

        # Get window PID
        pid_result = subprocess.run(
            ["xdotool", "getwindowpid", window_id],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        pid_str = pid_result.stdout.strip() if pid_result.returncode == 0 else ""
        pid = int(pid_str) if pid_str else None

        # Get WM_CLASS via xprop
        xprop_result = subprocess.run(
            ["xprop", "-id", window_id, "WM_CLASS"],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        wm_instance = None
        wm_class = None
        if xprop_result.returncode == 0:
            wm_instance, wm_class = _parse_wm_class(xprop_result.stdout)

        return WindowInfo(
            title=title,
            wm_class=wm_class,
            wm_instance=wm_instance,
            pid=pid,
            window_id=window_id,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        logger.debug("get_window_info_by_id failed for %s: %s", window_id, e)
        return None


def get_window_under_cursor() -> str | None:
    """Get the X11 window ID under the mouse cursor via xdotool."""
    try:
        result = subprocess.run(
            ["xdotool", "getmouselocation", "--shell"],
            capture_output=True,
            text=True,
            timeout=0.5,
        )
        if result.returncode != 0:
            logger.debug("xdotool getmouselocation failed: %s", result.stderr)
            return None
        for line in result.stdout.splitlines():
            if line.startswith("WINDOW="):
                return line.split("=", 1)[1].strip()
        return None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        logger.debug("xdotool getmouselocation failed: %s", e)
        return None


def _parse_wm_class(raw: str) -> tuple[str | None, str | None]:
    """Parse xprop WM_CLASS output.

    Example: WM_CLASS(STRING) = "gnome-terminal-server", "Gnome-terminal"
    Returns: (instance, class)
    """
    match = re.search(r'"([^"]*)",\s*"([^"]*)"', raw)
    if match:
        return match.group(1), match.group(2)
    return None, None
