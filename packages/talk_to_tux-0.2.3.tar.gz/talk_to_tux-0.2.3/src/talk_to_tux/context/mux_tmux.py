from __future__ import annotations

import subprocess

from talk_to_tux.context.models import AppContext
from talk_to_tux.context.mux import MuxPaneContext, MuxProbeError, normalize_pane_text

TMUX_FORMAT = "\t".join(
    (
        "#{session_name}",
        "#{window_id}",
        "#{window_index}",
        "#{window_name}",
        "#{pane_id}",
        "#{pane_index}",
        "#{pane_current_command}",
        "#{pane_current_path}",
        "#{pane_title}",
        "#{pane_width}",
        "#{pane_height}",
    )
)


def capture_tmux_pane(
    context: AppContext, *, timeout_seconds: float = 0.35
) -> MuxPaneContext:
    metadata = _get_tmux_metadata(timeout_seconds=timeout_seconds)
    pane_id = metadata.get("pane_id")
    if not isinstance(pane_id, str) or not pane_id:
        raise MuxProbeError("tmux active pane missing pane id")

    try:
        result = subprocess.run(
            ["tmux", "capture-pane", "-p", "-t", pane_id],
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
    except FileNotFoundError as exc:
        raise MuxProbeError("tmux not available", missing_tool="tmux") from exc
    except subprocess.TimeoutExpired as exc:
        raise MuxProbeError("tmux capture-pane timed out") from exc
    except OSError as exc:
        raise MuxProbeError("tmux capture-pane failed") from exc
    if result.returncode != 0:
        raise MuxProbeError("tmux capture-pane failed")

    text, truncated = normalize_pane_text(result.stdout)
    if not text.strip():
        raise MuxProbeError("tmux active pane text was empty")

    metadata["mux"] = "tmux"
    metadata["text_truncated"] = truncated
    return MuxPaneContext(
        source="tmux",
        text=text,
        metadata=metadata,
        provenance=[
            "tmux display-message -p <mux-pane-format>",
            f"tmux capture-pane -p -t {pane_id}",
        ],
    )


def parse_tmux_display_message(
    output: str,
) -> dict[str, str | int | bool | None]:
    fields = output.rstrip("\n").split("\t")
    if len(fields) != 11:
        raise ValueError("tmux display-message field count mismatch")
    (
        session,
        window_id,
        window_index,
        window_name,
        pane_id,
        pane_index,
        pane_command,
        cwd,
        pane_title,
        pane_width,
        pane_height,
    ) = fields
    metadata: dict[str, str | int | bool | None] = {
        "session": session or None,
        "window": window_name or window_id or None,
        "window_index": _to_int(window_index),
        "pane_id": pane_id or None,
        "pane_index": _to_int(pane_index),
        "pane_command": pane_command or None,
        "cwd": cwd or None,
        "pane_title": pane_title or None,
        "cell_columns": _to_int(pane_width),
        "cell_rows": _to_int(pane_height),
    }
    return metadata


def _get_tmux_metadata(*, timeout_seconds: float) -> dict[str, str | int | bool | None]:
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-p", TMUX_FORMAT],
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
    except FileNotFoundError as exc:
        raise MuxProbeError("tmux not available", missing_tool="tmux") from exc
    except subprocess.TimeoutExpired as exc:
        raise MuxProbeError("tmux display-message timed out") from exc
    except OSError as exc:
        raise MuxProbeError("tmux display-message failed") from exc
    if result.returncode != 0:
        raise MuxProbeError("tmux display-message failed")
    try:
        return parse_tmux_display_message(result.stdout)
    except ValueError as exc:
        raise MuxProbeError("tmux display-message returned malformed output") from exc


def _to_int(value: str) -> int | None:
    try:
        return int(value) if value != "" else None
    except ValueError:
        return None
