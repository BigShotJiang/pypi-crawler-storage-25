from __future__ import annotations

from talk_to_tux.context.adapters import (
    AdapterConfidence,
    AdapterKind,
    AdapterResult,
    adapter_degraded,
    adapter_success,
)
from talk_to_tux.context.browser_contract import (
    BROWSER_TEXT_LIMIT_CHARS,
    BrowserTarget,
    domain_from_visible_url,
    is_browser_window_class,
    page_title_from_window_title,
    safe_browser_metadata,
    sanitize_visible_url,
)
from talk_to_tux.context.models import AppContext, StructuredAppContext

_PRIVACY_NOTE = (
    "Browser baseline context comes from desktop/window/accessibility surfaces, "
    "not a browser extension, CDP, cookies, or DOM capture."
)

_EDITABLE_STATE_MARKERS = frozenset({"editable", "focused"})
_EDITABLE_ROLE_MARKERS = frozenset({"entry", "text", "edit", "search", "textbox"})
_ADDRESS_MARKERS = frozenset(
    {"address", "location", "url", "omnibox", "navigation", "search or enter address"}
)


class BrowserBaselineAppContextAdapter:
    name = "browser-baseline"

    def can_handle(self, context: AppContext) -> bool:
        return is_browser_window_class(context.window_class)

    async def capture(
        self, context: AppContext
    ) -> AdapterResult[list[StructuredAppContext]]:
        if not self.can_handle(context):
            return adapter_success(AdapterKind.APP_CONTEXT, self.name, [])
        entries = build_browser_baseline_context(context)
        if entries:
            confidence = _combine_entry_confidence(entries)
            return adapter_success(
                AdapterKind.APP_CONTEXT,
                self.name,
                entries,
                confidence=confidence,
                provenance=[self.name],
                privacy_notes=[_PRIVACY_NOTE],
            )
        return adapter_degraded(
            AdapterKind.APP_CONTEXT,
            self.name,
            [],
            reason="browser baseline metadata unavailable",
            confidence=AdapterConfidence.LOW,
            privacy_notes=[_PRIVACY_NOTE],
        )


def build_browser_baseline_context(context: AppContext) -> list[StructuredAppContext]:
    if not is_browser_window_class(context.window_class):
        return []

    title = page_title_from_window_title(context.window_title)
    target = classify_browser_target(context)
    field_text, text_source, text_truncated = _focused_field_text(context)
    url_source_text = field_text if target == "address-bar" else None
    url = sanitize_visible_url(url_source_text)
    domain = domain_from_visible_url(url_source_text)

    entries: list[StructuredAppContext] = []
    if title or url or domain:
        page_metadata = safe_browser_metadata(
            {
                "browser_class": context.window_class,
                "page_title": title,
                "url": url,
                "domain": domain,
                "url_source": "focused-address-bar" if url else None,
                "target": target if target != "form-field" else "page",
            }
        )
        entries.append(
            StructuredAppContext(
                kind="browser-page",
                source="browser-baseline",
                label="active-tab",
                metadata=page_metadata,
                confidence=AdapterConfidence.HIGH
                if target == "address-bar" and url
                else AdapterConfidence.MEDIUM,
                provenance=[self_name()],
                privacy_notes=[_PRIVACY_NOTE],
            )
        )

    if target in {"address-bar", "form-field"}:
        protected = _is_protected_field(context)
        label = "focused-address-bar" if target == "address-bar" else "focused-form-field"
        metadata = safe_browser_metadata(
            {
                "browser_class": context.window_class,
                "target": target,
                "field_role": context.widget_role,
                "field_name": context.widget_name,
                "field_placeholder": context.widget_placeholder,
                "field_state": _field_state(context),
                "caret_offset": context.caret_offset,
                "text_source": None if protected else text_source,
                "has_selection": bool(context.selected_text) if not protected else False,
                "text_truncated": text_truncated,
                "url": url if target == "address-bar" else None,
                "domain": domain if target == "address-bar" else None,
                "url_source": "focused-address-bar" if target == "address-bar" and url else None,
            }
        )
        entries.append(
            StructuredAppContext(
                kind="browser-field",
                source="browser-baseline",
                label=label,
                text=None if protected else field_text,
                metadata=metadata,
                confidence=AdapterConfidence.HIGH
                if field_text and not protected
                else AdapterConfidence.LOW,
                provenance=[self_name()],
                degraded_reasons=["focused field text unavailable"]
                if not field_text or protected
                else [],
                privacy_notes=[_PRIVACY_NOTE],
            )
        )
    elif not entries and context.window_title:
        entries.append(
            StructuredAppContext(
                kind="browser-page",
                source="browser-baseline",
                label="focused-page" if target == "page" else "focused-unknown",
                metadata=safe_browser_metadata(
                    {
                        "browser_class": context.window_class,
                        "target": target,
                    }
                ),
                confidence=AdapterConfidence.LOW,
                provenance=[self_name()],
                degraded_reasons=["browser page metadata limited to visible window class"],
                privacy_notes=[_PRIVACY_NOTE],
            )
        )
    return entries


def classify_browser_target(context: AppContext) -> BrowserTarget:
    if not is_browser_window_class(context.window_class):
        return "unknown"
    if _is_address_bar_like(context):
        return "address-bar"
    if _is_editable_field(context):
        return "form-field"
    if context.window_title:
        return "page"
    return "unknown"


def _focused_field_text(context: AppContext) -> tuple[str | None, str | None, bool]:
    for source, value in (
        ("selected-text", context.selected_text),
        ("near-caret", context.text_around_caret),
        ("visible-text", context.text_content),
    ):
        if value:
            text = value.strip()
            if text:
                if len(text) > BROWSER_TEXT_LIMIT_CHARS:
                    return text[:BROWSER_TEXT_LIMIT_CHARS], source, True
                return text, source, False
    return None, None, False


def _is_address_bar_like(context: AppContext) -> bool:
    text = " ".join(
        part
        for part in (
            context.widget_role,
            context.widget_name,
            context.widget_placeholder,
        )
        if part
    ).lower()
    if any(marker in text for marker in _ADDRESS_MARKERS):
        return True
    field_text, _source, _truncated = _focused_field_text(context)
    return sanitize_visible_url(field_text) is not None


def _is_editable_field(context: AppContext) -> bool:
    text = " ".join(
        part
        for part in (
            context.widget_role,
            context.widget_name,
            context.widget_placeholder,
            context.text_around_caret,
            context.text_content,
        )
        if part
    ).lower()
    if any(marker in text for marker in _EDITABLE_ROLE_MARKERS):
        return True
    state = _field_state(context)
    return bool(state and any(marker in state for marker in _EDITABLE_STATE_MARKERS))


def _is_protected_field(context: AppContext) -> bool:
    text = " ".join(
        part
        for part in (
            context.widget_role,
            context.widget_name,
            context.widget_placeholder,
            _field_state(context),
        )
        if part
    ).lower()
    return any(marker in text for marker in ("password", "protected", "secret"))


def _field_state(context: AppContext) -> str | None:
    role = context.widget_role or ""
    name = context.widget_name or ""
    if not role and not name:
        return None
    values = [value for value in (role, name) if value]
    return " ".join(values)


def _combine_entry_confidence(entries: list[StructuredAppContext]) -> AdapterConfidence:
    if any(entry.confidence == AdapterConfidence.HIGH for entry in entries):
        return AdapterConfidence.HIGH
    if any(entry.confidence == AdapterConfidence.MEDIUM for entry in entries):
        return AdapterConfidence.MEDIUM
    if any(entry.confidence == AdapterConfidence.LOW for entry in entries):
        return AdapterConfidence.LOW
    return AdapterConfidence.UNKNOWN


def self_name() -> str:
    return "browser-baseline"
