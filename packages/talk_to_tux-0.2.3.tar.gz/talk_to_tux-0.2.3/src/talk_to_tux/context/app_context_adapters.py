from __future__ import annotations

from talk_to_tux.context.adapters import AppContextAdapter
from talk_to_tux.context.browser import BrowserBaselineAppContextAdapter
from talk_to_tux.context.mux import TerminalMuxAppContextAdapter


def default_app_context_adapters() -> tuple[AppContextAdapter, ...]:
    return (TerminalMuxAppContextAdapter(), BrowserBaselineAppContextAdapter())
