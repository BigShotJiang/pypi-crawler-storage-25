from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal
from urllib.parse import urlsplit, urlunsplit

from talk_to_tux.context.adapters import AdapterConfidence

BrowserTarget = Literal["address-bar", "form-field", "page", "unknown"]

BROWSER_WINDOW_CLASSES = frozenset(
    {
        "Google-chrome",
        "google-chrome",
        "Chromium",
        "chromium",
        "Chromium-browser",
        "chromium-browser",
        "Brave-browser",
        "brave-browser",
        "Firefox",
        "firefox",
    }
)

APPROVED_BROWSER_METADATA_KEYS = frozenset(
    {
        "browser_class",
        "page_title",
        "url",
        "domain",
        "url_source",
        "target",
        "field_role",
        "field_name",
        "field_placeholder",
        "field_state",
        "caret_offset",
        "text_source",
        "has_selection",
        "text_truncated",
    }
)

BROWSER_TEXT_LIMIT_CHARS = 1000
BROWSER_URL_LIMIT_CHARS = 300

_BROWSER_TITLE_SUFFIXES = (
    "Google Chrome",
    "Chromium",
    "Brave",
    "Brave Browser",
    "Mozilla Firefox",
    "Firefox",
)


@dataclass
class BrowserBaselineContext:
    target: BrowserTarget = "unknown"
    page_title: str | None = None
    url: str | None = None
    domain: str | None = None
    text: str | None = None
    text_source: str | None = None
    metadata: dict[str, str | int | float | bool | None] = field(default_factory=dict)
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    provenance: list[str] = field(default_factory=list)
    degraded_reasons: list[str] = field(default_factory=list)
    privacy_notes: list[str] = field(default_factory=list)


def is_browser_window_class(window_class: str | None) -> bool:
    return bool(window_class and window_class in BROWSER_WINDOW_CLASSES)


def page_title_from_window_title(title: str | None) -> str | None:
    if not title:
        return None
    value = " ".join(title.split())
    if not value:
        return None
    for suffix in _BROWSER_TITLE_SUFFIXES:
        for separator in (" - ", " – ", " — "):
            marker = f"{separator}{suffix}"
            if value.endswith(marker):
                page = value[: -len(marker)].strip()
                return page or None
    return value


def sanitize_visible_url(text: str | None) -> str | None:
    if not text:
        return None
    value = text.strip()
    if not value or any(ch.isspace() for ch in value):
        return None
    has_scheme = "://" in value
    if not has_scheme and "@" in value:
        return None
    candidate = value if has_scheme else f"https://{value}"
    try:
        parsed = urlsplit(candidate)
    except ValueError:
        return None
    if parsed.scheme not in {"http", "https"}:
        return None
    if not parsed.hostname:
        return None
    host = parsed.hostname.lower()
    if not _is_plausible_host(host):
        return None
    netloc = host
    if parsed.port is not None:
        netloc = f"{netloc}:{parsed.port}"
    path = parsed.path or ""
    sanitized = urlunsplit((parsed.scheme, netloc, path, "", ""))
    if len(sanitized) > BROWSER_URL_LIMIT_CHARS:
        sanitized = sanitized[:BROWSER_URL_LIMIT_CHARS]
    return sanitized


def domain_from_visible_url(text: str | None) -> str | None:
    url = sanitize_visible_url(text)
    if not url:
        return None
    try:
        return urlsplit(url).hostname.lower()  # type: ignore[union-attr]
    except (AttributeError, ValueError):
        return None


def safe_browser_metadata(
    metadata: dict[str, str | int | float | bool | None]
) -> dict[str, str | int | float | bool | None]:
    return {
        key: value
        for key, value in metadata.items()
        if key in APPROVED_BROWSER_METADATA_KEYS
        and value is not None
        and isinstance(value, (str, int, float, bool))
    }


def _is_plausible_host(host: str) -> bool:
    if host == "localhost":
        return True
    if ":" in host:
        return bool(host.replace(":", ""))
    if all(part.isdecimal() for part in host.split(".")):
        parts = host.split(".")
        return len(parts) == 4 and all(0 <= int(part) <= 255 for part in parts)
    return "." in host and all(part for part in host.split("."))
