from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

from talk_to_tux.context.adapters import (
    AdapterConfidence,
    AdapterKind,
    AdapterResult,
    adapter_degraded,
    adapter_success,
)
from talk_to_tux.context.models import AppContext, StructuredAppContext

MAX_PANE_TEXT_CHARS = 8000

APPROVED_MUX_METADATA_KEYS = frozenset(
    {
        "mux",
        "session",
        "window",
        "window_index",
        "pane_id",
        "pane_index",
        "pane_title",
        "pane_command",
        "cwd",
        "tab_id",
        "tab_name",
        "cell_x",
        "cell_y",
        "cell_rows",
        "cell_columns",
        "text_truncated",
    }
)

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


class MuxProbeError(RuntimeError):
    def __init__(self, reason: str, *, missing_tool: str | None = None) -> None:
        super().__init__(reason)
        self.reason = reason
        self.missing_tool = missing_tool


@dataclass
class MuxPaneContext:
    source: str
    text: str
    metadata: dict[str, str | int | float | bool | None] = field(default_factory=dict)
    confidence: AdapterConfidence = AdapterConfidence.HIGH
    provenance: list[str] = field(default_factory=list)
    degraded_reasons: list[str] = field(default_factory=list)
    privacy_notes: list[str] = field(default_factory=list)

    def to_structured_context(self) -> StructuredAppContext:
        return StructuredAppContext(
            kind="terminal-pane",
            source=self.source,
            label="active",
            text=self.text,
            metadata=safe_mux_metadata(self.metadata),
            confidence=self.confidence,
            provenance=self.provenance or [self.source],
            degraded_reasons=self.degraded_reasons,
            privacy_notes=self.privacy_notes
            or ["Mux diagnostics exclude stderr, screenshots, transcripts, and environment payloads."],
        )


def normalize_pane_text(text: str) -> tuple[str, bool]:
    normalized = _ANSI_RE.sub("", text).replace("\r\n", "\n").replace("\r", "\n")
    if len(normalized) > MAX_PANE_TEXT_CHARS:
        return normalized[-MAX_PANE_TEXT_CHARS:], True
    return normalized, False


def safe_mux_metadata(
    metadata: dict[str, str | int | float | bool | None]
) -> dict[str, str | int | float | bool | None]:
    return {
        key: value
        for key, value in metadata.items()
        if key in APPROVED_MUX_METADATA_KEYS
        and value is not None
        and isinstance(value, (str, int, float, bool))
    }


class TerminalMuxAppContextAdapter:
    name = "terminal-mux"

    def __init__(
        self,
        *,
        zellij_capture: Callable[..., MuxPaneContext] | None = None,
        tmux_capture: Callable[..., MuxPaneContext] | None = None,
        timeout_seconds: float = 0.35,
    ) -> None:
        self._zellij_capture = zellij_capture
        self._tmux_capture = tmux_capture
        self._timeout_seconds = timeout_seconds

    def can_handle(self, context: AppContext) -> bool:
        terminal_info = context.terminal_info
        if terminal_info is None:
            return False
        return bool(
            terminal_info.multiplexer
            or terminal_info.has_ssh
            or terminal_info.remote_multiplexer_hint
        )

    async def capture(
        self, context: AppContext
    ) -> AdapterResult[list[StructuredAppContext]]:
        terminal_info = context.terminal_info
        if terminal_info is None:
            return adapter_success(AdapterKind.APP_CONTEXT, self.name, [])

        if terminal_info.has_ssh or terminal_info.remote_multiplexer_hint:
            mux = terminal_info.remote_multiplexer_hint
            reason = "remote terminal session; mux pane capture skipped"
            if mux:
                reason = f"remote {mux} detected; mux pane capture skipped"
            return adapter_degraded(
                AdapterKind.APP_CONTEXT,
                self.name,
                reason=reason,
                privacy_notes=["Remote mux introspection is skipped without diagnostics payloads."],
            )

        mux = terminal_info.multiplexer
        if mux == "zellij":
            capture = self._zellij_capture or _capture_zellij
        elif mux == "tmux":
            capture = self._tmux_capture or _capture_tmux
        elif mux:
            return adapter_degraded(
                AdapterKind.APP_CONTEXT,
                self.name,
                reason=f"unsupported terminal multiplexer: {mux}",
                privacy_notes=["Unsupported mux capture records no terminal text diagnostics."],
            )
        else:
            return adapter_success(AdapterKind.APP_CONTEXT, self.name, [])

        try:
            pane = capture(context, timeout_seconds=self._timeout_seconds)
        except MuxProbeError as exc:
            missing = [exc.missing_tool] if exc.missing_tool else None
            return adapter_degraded(
                AdapterKind.APP_CONTEXT,
                self.name,
                reason=exc.reason,
                missing_tools=missing,
                privacy_notes=["Mux probe failures exclude stderr and captured pane text."],
            )
        return adapter_success(
            AdapterKind.APP_CONTEXT,
            self.name,
            [pane.to_structured_context()],
            confidence=pane.confidence,
            provenance=pane.provenance,
            privacy_notes=pane.privacy_notes,
        )


def default_app_context_adapters() -> tuple[TerminalMuxAppContextAdapter, ...]:
    return (TerminalMuxAppContextAdapter(),)


def _capture_zellij(context: AppContext, *, timeout_seconds: float) -> MuxPaneContext:
    from talk_to_tux.context.mux_zellij import capture_zellij_pane

    return capture_zellij_pane(context, timeout_seconds=timeout_seconds)


def _capture_tmux(context: AppContext, *, timeout_seconds: float) -> MuxPaneContext:
    from talk_to_tux.context.mux_tmux import capture_tmux_pane

    return capture_tmux_pane(context, timeout_seconds=timeout_seconds)
