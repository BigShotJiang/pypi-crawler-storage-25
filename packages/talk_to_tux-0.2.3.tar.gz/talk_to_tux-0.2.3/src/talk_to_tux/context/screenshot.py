from __future__ import annotations

import asyncio
import hashlib
import inspect
import logging
import os
import re
import shutil
import tempfile
from io import BytesIO
from pathlib import Path
from typing import Any, Iterable, Mapping
from urllib.parse import unquote, urlparse

from PIL import Image

from talk_to_tux.context.adapters import (
    AdapterConfidence,
    AdapterKind,
    AdapterResult,
    adapter_degraded,
    adapter_success,
)
from talk_to_tux.context.models import ScreenshotCropInfo, ScreenshotRegion

logger = logging.getLogger(__name__)

WINDOW_LOCAL_SCREENSHOT_BACKENDS = frozenset({"import-window", "scrot-focused"})
SCREEN_COORDINATE_SCREENSHOT_BACKENDS = frozenset({"grim", "portal", "scrot"})
SETTINGS_SMOKE_AUTHORITATIVE_BACKEND = "gtk-notebook-snapshot"
SETTINGS_SMOKE_NON_AUTHORITATIVE_BACKENDS = frozenset(
    {"grim", "gnome-screenshot", "gdk-window-surface", "import-window", "portal", "scrot"}
)


def settings_smoke_backend_verdict(backend: str, display_server: str) -> tuple[bool, str | None]:
    if backend == SETTINGS_SMOKE_AUTHORITATIVE_BACKEND:
        return True, None
    if display_server == "wayland" and backend in SETTINGS_SMOKE_NON_AUTHORITATIVE_BACKENDS:
        return False, f"{backend} is non-authoritative for GNOME Wayland settings smoke"
    return False, f"{backend} is not an authoritative settings smoke backend"


def screenshot_sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def validate_distinct_settings_captures(records: Iterable[Mapping[str, Any]]) -> None:
    digest_to_tab: dict[str, str] = {}
    for record in records:
        tab = str(record["tab"])
        digest = str(record["sha256"])
        trusted = bool(record["trusted"])
        reason = record.get("reason")
        captured_tab = record.get("captured_tab")
        if captured_tab is not None and str(captured_tab) != tab:
            raise ValueError(f"tab label mismatch: expected {tab}, captured {captured_tab}")
        if not trusted:
            raise ValueError(str(reason or f"untrusted settings capture for {tab}"))
        previous = digest_to_tab.get(digest)
        if previous is not None and previous != tab:
            raise ValueError(f"duplicate trusted digest across tabs: {previous} and {tab}")
        digest_to_tab[digest] = tab


def _crop_info_for_region(region: ScreenshotRegion) -> ScreenshotCropInfo:
    return ScreenshotCropInfo(
        mode=_crop_mode_for_kind(region.kind),
        rect=(region.x, region.y, region.width, region.height),
        source=region.source,
        confidence=region.confidence,
        provenance=region.provenance or [region.source],
        degraded_reason=region.degraded_reason,
    )


def _crop_mode_for_kind(kind: str) -> str:
    if kind in {"pane-crop", "window-crop", "full-screen"}:
        return kind
    if kind in {"pane", "terminal-pane"}:
        return "pane-crop"
    if kind == "window":
        return "window-crop"
    return "full-screen"


def _clamp_region(
    region: ScreenshotRegion, image_width: int, image_height: int
) -> tuple[int, int, int, int] | None:
    if region.width <= 0 or region.height <= 0:
        return None
    x2 = min(region.x + region.width, image_width)
    y2 = min(region.y + region.height, image_height)
    x1 = max(0, region.x)
    y1 = max(0, region.y)
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


class ScreenshotCapturer:
    """Captures and processes screenshots for LLM context."""

    def __init__(self, max_width: int = 1024, jpeg_quality: int = 85) -> None:
        self._max_width = max_width
        self._jpeg_quality = jpeg_quality
        self._failed_methods: set[str] = set()

    async def capture(self, window_id: str | None = None) -> tuple[bytes, int, int]:
        """Capture a screenshot and return (jpeg_bytes, width, height)."""
        path = await self._capture_screenshot(window_id=window_id)
        try:
            # Run PIL processing in executor — avoids blocking the event loop
            # and ensures PIL's C extensions don't overlap with GTK's gdk-pixbuf
            # (both link against libjpeg/libz).
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None, self._resize_and_compress, path
            )
        finally:
            path.unlink(missing_ok=True)

    async def capture_raw(self, window_id: str | None = None) -> Path:
        """Capture screenshot to temp file. Caller must unlink."""
        return await self._capture_screenshot(window_id=window_id)

    async def capture_raw_result(
        self, window_id: str | None = None,
    ) -> AdapterResult[Path]:
        try:
            path, backend = await self._capture_screenshot_with_backend(window_id=window_id)
            return adapter_success(
                AdapterKind.SCREENSHOT,
                backend,
                path,
                confidence=AdapterConfidence.HIGH,
                privacy_notes=["Screenshot bytes are returned only as the adapter value, never in diagnostics."],
                diagnostics={
                    "window_targeted": window_id is not None,
                    "coordinate_space": (
                        "window"
                        if backend in WINDOW_LOCAL_SCREENSHOT_BACKENDS
                        else "screen"
                    ),
                    "window_local": backend in WINDOW_LOCAL_SCREENSHOT_BACKENDS,
                },
            )
        except RuntimeError as exc:
            return adapter_degraded(
                AdapterKind.SCREENSHOT,
                "none",
                reason=str(exc),
                missing_tools=["grim", "gdbus", "scrot", "import"],
                privacy_notes=["No screenshot bytes are included in diagnostics."],
            )

    def crop_and_compress(
        self, path: Path, crop_rect: tuple[int, int, int, int] | None = None
    ) -> tuple[bytes, int, int]:
        """Open image, optionally crop to (x, y, w, h), resize, compress to JPEG."""
        region = None
        if crop_rect:
            x, y, width, height = crop_rect
            region = ScreenshotRegion(
                x=x,
                y=y,
                width=width,
                height=height,
                kind="window",
                coordinate_space="image",
                source="legacy-crop-rect",
                provenance=["legacy-crop-rect"],
            )
        result = self.crop_and_compress_result(path, region=region)
        return result[0], result[1], result[2]

    def crop_and_compress_result(
        self,
        path: Path,
        region: ScreenshotRegion | None = None,
        *,
        fallback_mode: str = "full-screen",
        fallback_source: str = "screenshot-backend",
    ) -> tuple[bytes, int, int, ScreenshotCropInfo]:
        """Open image, crop a typed region when valid, resize, and report metadata."""
        img = Image.open(path)
        crop_info = ScreenshotCropInfo(
            mode=fallback_mode,
            rect=(0, 0, img.width, img.height),
            source=fallback_source,
            provenance=[fallback_source],
        )
        if region is not None:
            crop_info = _crop_info_for_region(region)
            clamped = _clamp_region(region, img.width, img.height)
            if clamped is None:
                crop_info = ScreenshotCropInfo(
                    mode="full-screen",
                    rect=(0, 0, img.width, img.height),
                    source=fallback_source,
                    confidence=AdapterConfidence.LOW,
                    provenance=(region.provenance or [region.source]) + [fallback_source],
                    degraded_reason=(
                        f"invalid {region.kind} crop region; fell back to full-screen"
                    ),
                )
            else:
                x, y, x2, y2 = clamped
                img = img.crop((x, y, x2, y2))
                crop_info.rect = (x, y, x2 - x, y2 - y)
        w, h = img.size
        if w > self._max_width:
            ratio = self._max_width / w
            img = img.resize((self._max_width, int(h * ratio)), Image.LANCZOS)
            w, h = img.size
        buf = BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=self._jpeg_quality)
        return buf.getvalue(), w, h, crop_info

    async def _capture_screenshot(self, window_id: str | None = None) -> Path:
        path, _backend = await self._capture_screenshot_with_backend(window_id=window_id)
        return path

    async def _capture_screenshot_with_backend(
        self, window_id: str | None = None,
    ) -> tuple[Path, str]:
        """Dispatch to grim/portal (Wayland) or scrot (X11) based on display server.

        Failed methods are cached in ``_failed_methods`` so subsequent captures
        skip them immediately (avoids repeated 2s portal timeouts, etc.).
        """
        if os.environ.get("WAYLAND_DISPLAY"):
            if "grim" not in self._failed_methods:
                try:
                    return await self._capture_grim(), "grim"
                except RuntimeError:
                    self._failed_methods.add("grim")
                    logger.info("grim failed on Wayland, trying xdg-desktop-portal")
            if "portal" not in self._failed_methods:
                try:
                    return await self._capture_portal(), "portal"
                except RuntimeError:
                    self._failed_methods.add("portal")
                    logger.info("portal failed on Wayland, falling back to scrot")
            return await self._capture_scrot_with_backend(window_id=window_id)
        return await self._capture_scrot_with_backend(window_id=window_id)

    async def _capture_grim(self) -> Path:
        """Capture full screen via grim (Wayland)."""
        tmp = tempfile.mktemp(suffix=".png")
        proc = await asyncio.create_subprocess_exec(
            "grim", tmp,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()
        if proc.returncode == 0 and Path(tmp).exists():
            return Path(tmp)

        Path(tmp).unlink(missing_ok=True)
        raise RuntimeError("Screenshot capture failed: grim not available or failed")

    async def _capture_portal(self) -> Path:
        """Capture via xdg-desktop-portal Screenshot (Wayland).

        Uses the freedesktop Screenshot portal, which works on GNOME and KDE
        Wayland sessions. Starts a gdbus monitor to capture the async Response
        signal containing the screenshot file URI.
        """
        # Monitor for the async Response signal
        monitor = await asyncio.create_subprocess_exec(
            "gdbus", "monitor", "--session",
            "--dest", "org.freedesktop.portal.Desktop",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            await asyncio.sleep(0.05)  # let monitor subscribe

            proc = await asyncio.create_subprocess_exec(
                "gdbus", "call", "--session",
                "--dest", "org.freedesktop.portal.Desktop",
                "--object-path", "/org/freedesktop/portal/desktop",
                "--method", "org.freedesktop.portal.Screenshot.Screenshot",
                "", '{"interactive": <false>}',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=2)
            if proc.returncode != 0:
                raise RuntimeError(
                    f"Portal call failed: {stderr.decode().strip()}"
                )

            # Read monitor output until we find the file URI in the Response
            buf = b""
            try:
                while True:
                    chunk = await asyncio.wait_for(
                        monitor.stdout.read(4096), timeout=2
                    )
                    if not chunk:
                        break
                    buf += chunk
                    text = buf.decode(errors="replace")
                    m = re.search(r"'uri':\s*<'(file://[^']+)'>", text)
                    if m:
                        parsed = urlparse(m.group(1))
                        src = Path(unquote(parsed.path))
                        if not src.exists():
                            raise RuntimeError(
                                f"Portal screenshot not found: {src}"
                            )
                        # Copy to our temp (portal may save to user-visible dir)
                        tmp = tempfile.mktemp(suffix=".png")
                        shutil.copy2(str(src), tmp)
                        return Path(tmp)
            except asyncio.TimeoutError:
                pass

            raise RuntimeError("Portal screenshot: no URI in response")
        finally:
            try:
                terminated = monitor.terminate()
                if inspect.isawaitable(terminated):
                    await terminated
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(monitor.wait(), timeout=1)
            except (asyncio.TimeoutError, ProcessLookupError):
                try:
                    killed = monitor.kill()
                    if inspect.isawaitable(killed):
                        await killed
                except ProcessLookupError:
                    pass

    async def _capture_scrot(self, window_id: str | None = None) -> Path:
        path, _backend = await self._capture_scrot_with_backend(window_id=window_id)
        return path

    async def _capture_scrot_with_backend(
        self, window_id: str | None = None,
    ) -> tuple[Path, str]:
        """Capture via import -window (if window_id), else scrot -u, else scrot."""
        tmp = tempfile.mktemp(suffix=".png")

        # Try ImageMagick import -window when we know the target window
        if window_id:
            try:
                proc = await asyncio.create_subprocess_exec(
                    "import", "-window", window_id, tmp,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
                if proc.returncode == 0 and Path(tmp).exists():
                    logger.debug("Screenshot via import -window %s", window_id)
                    return Path(tmp), "import-window"
            except FileNotFoundError:
                pass  # import not installed
            logger.info("import -window failed, falling back to scrot")

        # Try focused window first
        proc = await asyncio.create_subprocess_exec(
            "scrot", "-u", tmp,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()
        if proc.returncode == 0 and Path(tmp).exists():
            return Path(tmp), "scrot-focused"

        # Fallback: full screen
        logger.info("scrot -u failed, trying full screen")
        proc = await asyncio.create_subprocess_exec(
            "scrot", tmp,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()
        if proc.returncode == 0 and Path(tmp).exists():
            return Path(tmp), "scrot"

        raise RuntimeError("Screenshot capture failed: scrot not available or failed")

    @staticmethod
    def preprocess_for_llm(png_bytes: bytes, max_width: int = 800, jpeg_quality: int = 60) -> bytes:
        """Downscale + grayscale + contrast-enhance for minimal LLM tokens.

        Optimizes for readability of text and UI borders while minimizing
        image tokens. Grayscale removes color info (irrelevant for text/border
        detection). Contrast + sharpness boost sharpens text edges.
        """
        from PIL import ImageEnhance

        img = Image.open(BytesIO(png_bytes))

        # Adaptive downscaling: maintain text readability
        if img.width > max_width:
            ratio = max_width / img.width
            img = img.resize((max_width, int(img.height * ratio)), Image.LANCZOS)

        # Grayscale: color is irrelevant for text/border structure
        img = img.convert("L")

        # Contrast boost: sharpen text edges, make borders crisper
        img = ImageEnhance.Contrast(img).enhance(1.5)
        img = ImageEnhance.Sharpness(img).enhance(1.3)

        buf = BytesIO()
        img.save(buf, format="JPEG", quality=jpeg_quality)
        return buf.getvalue()

    def _resize_and_compress(self, path: Path) -> tuple[bytes, int, int]:
        """Open image, resize to max_width if needed, return JPEG bytes."""
        img = Image.open(path)
        w, h = img.size

        if w > self._max_width:
            ratio = self._max_width / w
            new_w = self._max_width
            new_h = int(h * ratio)
            img = img.resize((new_w, new_h), Image.LANCZOS)
            w, h = new_w, new_h

        buf = BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=self._jpeg_quality)
        return buf.getvalue(), w, h
