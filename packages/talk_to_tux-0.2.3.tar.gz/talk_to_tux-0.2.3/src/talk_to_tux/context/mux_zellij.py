from __future__ import annotations

import json
import subprocess
from typing import Any

from talk_to_tux.context.models import AppContext
from talk_to_tux.context.mux import MuxPaneContext, MuxProbeError, normalize_pane_text


def capture_zellij_pane(
    context: AppContext, *, timeout_seconds: float = 0.35
) -> MuxPaneContext:
    pane = _get_active_zellij_pane(timeout_seconds=timeout_seconds)
    pane_id = pane.get("id")
    if pane_id is None:
        raise MuxProbeError("zellij focused pane missing pane id")

    try:
        result = subprocess.run(
            ["zellij", "action", "dump-screen", "--pane-id", str(pane_id)],
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
    except FileNotFoundError as exc:
        raise MuxProbeError("zellij not available", missing_tool="zellij") from exc
    except subprocess.TimeoutExpired as exc:
        raise MuxProbeError("zellij dump-screen timed out") from exc
    except OSError as exc:
        raise MuxProbeError("zellij dump-screen failed") from exc
    if result.returncode != 0:
        raise MuxProbeError("zellij dump-screen failed")

    text, truncated = normalize_pane_text(result.stdout)
    if not text.strip():
        raise MuxProbeError("zellij active pane text was empty")

    metadata = _pane_metadata(pane)
    metadata["mux"] = "zellij"
    metadata["text_truncated"] = truncated
    return MuxPaneContext(
        source="zellij",
        text=text,
        metadata=metadata,
        provenance=[
            "zellij action list-panes --json",
            f"zellij action dump-screen --pane-id {pane_id}",
        ],
    )


def parse_zellij_panes(payload: str) -> list[dict[str, Any]]:
    data = json.loads(payload)
    if isinstance(data, list):
        return [pane for pane in data if isinstance(pane, dict)]
    if isinstance(data, dict) and isinstance(data.get("panes"), dict):
        panes: list[dict[str, Any]] = []
        for tab_name, tab_panes in data["panes"].items():
            if not isinstance(tab_panes, list):
                continue
            for pane in tab_panes:
                if isinstance(pane, dict):
                    normalized = dict(pane)
                    normalized.setdefault("tab_name", str(tab_name))
                    panes.append(normalized)
        return panes
    raise ValueError("unsupported zellij list-panes shape")


def select_focused_zellij_pane(panes: list[dict[str, Any]]) -> dict[str, Any] | None:
    for pane in panes:
        if pane.get("is_focused") and not pane.get("is_plugin"):
            return pane
    return None


def _get_active_zellij_pane(*, timeout_seconds: float) -> dict[str, Any]:
    try:
        result = subprocess.run(
            ["zellij", "action", "list-panes", "--json"],
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
    except FileNotFoundError as exc:
        raise MuxProbeError("zellij not available", missing_tool="zellij") from exc
    except subprocess.TimeoutExpired as exc:
        raise MuxProbeError("zellij list-panes timed out") from exc
    except OSError as exc:
        raise MuxProbeError("zellij list-panes failed") from exc
    if result.returncode != 0:
        raise MuxProbeError("zellij list-panes failed")
    try:
        panes = parse_zellij_panes(result.stdout)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise MuxProbeError("zellij list-panes returned malformed JSON") from exc
    pane = select_focused_zellij_pane(panes)
    if pane is None:
        raise MuxProbeError("zellij focused non-plugin pane not found")
    return pane


def _pane_metadata(pane: dict[str, Any]) -> dict[str, str | int | bool | None]:
    mapping = {
        "id": "pane_id",
        "pane_id": "pane_id",
        "pane_index": "pane_index",
        "title": "pane_title",
        "pane_title": "pane_title",
        "pane_command": "pane_command",
        "command": "pane_command",
        "pane_cwd": "cwd",
        "cwd": "cwd",
        "tab_id": "tab_id",
        "tab_name": "tab_name",
        "pane_content_x": "cell_x",
        "pane_content_y": "cell_y",
        "pane_content_rows": "cell_rows",
        "pane_content_columns": "cell_columns",
    }
    metadata: dict[str, str | int | bool | None] = {}
    for source, target in mapping.items():
        value = pane.get(source)
        if isinstance(value, (str, int, bool)):
            metadata[target] = value
    return metadata
