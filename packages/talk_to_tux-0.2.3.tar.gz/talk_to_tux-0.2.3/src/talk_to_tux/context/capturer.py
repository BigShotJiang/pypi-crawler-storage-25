from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path

from PIL import Image

from talk_to_tux.context.accessibility import query_widgets_subprocess

from talk_to_tux.context.adapters import (
    AdapterConfidence,
    AdapterKind,
    AdapterResult,
    AppContextAdapter,
    adapter_degraded,
    adapter_success,
    run_app_context_adapters,
)
from talk_to_tux.context.models import (
    AppContext,
    ScreenshotCropInfo,
    ScreenshotRegion,
    StructuredAppContext,
    WidgetInfo,
    WindowInfo,
)
from talk_to_tux.context.app_context_adapters import default_app_context_adapters
from talk_to_tux.context.screenshot import (
    ScreenshotCapturer,
    WINDOW_LOCAL_SCREENSHOT_BACKENDS,
)
from talk_to_tux.context.window import get_window_result

logger = logging.getLogger(__name__)


class ContextCapturer:
    """Orchestrates screenshot + window metadata capture."""

    def __init__(
        self,
        screenshot_capturer: ScreenshotCapturer | None = None,
        max_width: int = 1024,
        jpeg_quality: int = 85,
        app_context_adapters: tuple[AppContextAdapter, ...] | list[AppContextAdapter] | None = None,
        use_default_app_context_adapters: bool = True,
        terminal_cell_pixel_size: tuple[int, int] | None = None,
    ) -> None:
        self._screenshot = screenshot_capturer or ScreenshotCapturer(
            max_width=max_width, jpeg_quality=jpeg_quality
        )
        self._terminal_cell_pixel_size = terminal_cell_pixel_size
        if app_context_adapters is None:
            self._app_context_adapters = (
                default_app_context_adapters()
                if use_default_app_context_adapters
                else ()
            )
            self._suppress_app_context_no_match = use_default_app_context_adapters
        else:
            self._app_context_adapters = tuple(app_context_adapters)
            self._suppress_app_context_no_match = False

    async def capture(self, cursor_window_id: str | None = None) -> AppContext:
        """Capture screenshot, window info, and widget context concurrently."""
        loop = asyncio.get_event_loop()

        raw_task = asyncio.create_task(self._capture_raw_result(cursor_window_id))
        window_task = loop.run_in_executor(None, self._capture_window)
        widget_task = asyncio.create_task(self._capture_widgets_result_async())

        raw_result, window_result, widget_result = await asyncio.gather(
            raw_task, window_task, widget_task, return_exceptions=True
        )

        raw_path = raw_result.value if isinstance(raw_result, AdapterResult) and raw_result.usable else None
        screenshot_backend = raw_result.backend if isinstance(raw_result, AdapterResult) else None
        screenshot_confidence = (
            raw_result.confidence if isinstance(raw_result, AdapterResult)
            else AdapterConfidence.UNKNOWN
        )
        degraded_reasons: list[str] = []
        missing_tools: list[str] = []
        privacy_notes: list[str] = []
        provenance: list[str] = []
        if isinstance(raw_result, AdapterResult):
            provenance.extend(raw_result.provenance)
            missing_tools.extend(raw_result.missing_tools)
            privacy_notes.extend(raw_result.privacy_notes)
            if raw_result.degraded_reason:
                degraded_reasons.append(raw_result.degraded_reason)
        elif isinstance(raw_result, BaseException):
            logger.warning("Screenshot capture failed: %s", raw_result)
            degraded_reasons.append(str(raw_result))

        # Unpack window info
        window_info = None
        window_title = None
        window_class = None
        window_instance = None
        window_pid = None
        window_id = None
        window_backend = None
        window_confidence = AdapterConfidence.UNKNOWN
        if isinstance(window_result, AdapterResult):
            window_backend = window_result.backend
            window_confidence = window_result.confidence
            provenance.extend(window_result.provenance)
            missing_tools.extend(window_result.missing_tools)
            privacy_notes.extend(window_result.privacy_notes)
            if window_result.degraded_reason:
                degraded_reasons.append(window_result.degraded_reason)
            window_result = window_result.value
        if isinstance(window_result, BaseException):
            logger.warning("Window info capture failed: %s", window_result)
        elif isinstance(window_result, WindowInfo):
            window_info = window_result
            window_title = window_result.title
            window_class = window_result.wm_class
            window_instance = window_result.wm_instance
            window_pid = window_result.pid
            window_id = window_result.window_id

        # Unpack widget context
        widget_role = None
        widget_name = None
        caret_offset = None
        cursor_widget_role = None
        cursor_widget_name = None
        widget_backend = None
        widget_confidence = AdapterConfidence.UNKNOWN
        widget_pair: tuple[WidgetInfo | None, WidgetInfo | None] | None = None
        if isinstance(widget_result, AdapterResult):
            widget_backend = widget_result.backend
            widget_confidence = widget_result.confidence
            provenance.extend(widget_result.provenance)
            missing_tools.extend(widget_result.missing_tools)
            privacy_notes.extend(widget_result.privacy_notes)
            if widget_result.degraded_reason:
                degraded_reasons.append(widget_result.degraded_reason)
            widget_result = widget_result.value
        if isinstance(widget_result, BaseException):
            logger.warning("Widget context capture failed: %s", widget_result)
        elif isinstance(widget_result, tuple):
            widget_pair = widget_result
            focused, cursor = widget_result
            if focused is not None:
                widget_role = focused.role
                widget_name = focused.name
                caret_offset = focused.caret_offset
            if cursor is not None:
                cursor_widget_role = cursor.role
                cursor_widget_name = cursor.name

        # Thread text content from focused widget
        text_content = None
        text_around_caret = None
        selected_text = None
        widget_placeholder = None
        if widget_pair is not None:
            focused, _ = widget_pair
            if focused is not None:
                text_content = focused.text_content
                text_around_caret = focused.text_around_caret
                selected_text = focused.selected_text
                widget_placeholder = focused.placeholder

        # Detect TUI apps for terminal windows via /proc
        terminal_info = None
        if window_pid and self._is_terminal_class(window_class):
            terminal_info = self._detect_terminal(window_pid, window_title)

        context = AppContext(
            timestamp=time.time(),
            window_title=window_title,
            window_class=window_class,
            window_instance=window_instance,
            window_pid=window_pid,
            window_id=window_id,
            widget_role=widget_role,
            widget_name=widget_name,
            caret_offset=caret_offset,
            cursor_widget_role=cursor_widget_role,
            cursor_widget_name=cursor_widget_name,
            text_content=text_content,
            text_around_caret=text_around_caret,
            selected_text=selected_text,
            widget_placeholder=widget_placeholder,
            terminal_info=terminal_info,
            desktop_backend=window_backend or screenshot_backend or widget_backend,
            window_backend=window_backend,
            screenshot_backend=screenshot_backend,
            widget_backend=widget_backend,
            provenance=provenance,
            confidence=_combine_confidence(
                window_confidence, screenshot_confidence, widget_confidence,
            ),
            window_confidence=window_confidence,
            screenshot_confidence=screenshot_confidence,
            widget_confidence=widget_confidence,
            degraded_reasons=degraded_reasons,
            missing_tools=sorted(set(missing_tools)),
            privacy_notes=privacy_notes,
        )
        if self._app_context_adapters:
            app_result = await run_app_context_adapters(
                context, self._app_context_adapters
            )
            if app_result.value:
                context.structured_context.extend(app_result.value)
            context.provenance.extend(app_result.provenance)
            context.missing_tools = sorted(
                set(context.missing_tools + app_result.missing_tools)
            )
            context.privacy_notes.extend(app_result.privacy_notes)
            if app_result.degraded_reason and not (
                self._suppress_app_context_no_match
                and app_result.degraded_reason == "no app-context adapters matched"
            ):
                context.degraded_reasons.append(app_result.degraded_reason)
            context.confidence = _combine_confidence(
                context.confidence, app_result.confidence
            )
        if isinstance(raw_path, Path):
            region, fallback_mode, fallback_source, crop_notes = (
                self._select_screenshot_region(
                    context,
                    window_info=window_info,
                    screenshot_backend=screenshot_backend,
                    raw_path=raw_path,
                )
            )
            context.degraded_reasons.extend(crop_notes)
            try:
                (
                    context.screenshot_png,
                    context.screenshot_width,
                    context.screenshot_height,
                    context.screenshot_crop,
                ) = await loop.run_in_executor(
                    None,
                    lambda: self._crop_and_compress_result(
                        raw_path,
                        region=region,
                        fallback_mode=fallback_mode,
                        fallback_source=fallback_source,
                    ),
                )
                if context.screenshot_crop.degraded_reason:
                    context.degraded_reasons.append(
                        context.screenshot_crop.degraded_reason
                    )
            except Exception as e:
                logger.warning("Screenshot processing failed: %s", e)
                context.degraded_reasons.append("screenshot processing failed")
            finally:
                raw_path.unlink(missing_ok=True)
        return context

    def _select_screenshot_region(
        self,
        context: AppContext,
        *,
        window_info: WindowInfo | None,
        screenshot_backend: str | None,
        raw_path: Path,
    ) -> tuple[ScreenshotRegion | None, str, str, list[str]]:
        fallback_source = screenshot_backend or "screenshot-backend"
        crop_notes: list[str] = []

        pane_region, pane_reason = self._pane_region(
            context,
            window_info=window_info,
            screenshot_backend=screenshot_backend,
            raw_path=raw_path,
        )
        if pane_region is not None:
            return pane_region, "full-screen", fallback_source, crop_notes
        if pane_reason:
            crop_notes.append(f"pane crop unavailable: {pane_reason}")

        if screenshot_backend in WINDOW_LOCAL_SCREENSHOT_BACKENDS:
            return None, "window-crop", fallback_source, crop_notes

        if window_info and window_info.geometry:
            x, y, width, height = window_info.geometry
            source = window_info.backend or "active-window"
            region = ScreenshotRegion(
                x=x,
                y=y,
                width=width,
                height=height,
                kind="window",
                coordinate_space="screen",
                source=source,
                confidence=window_info.confidence,
                provenance=window_info.provenance or [source],
            )
            return region, "full-screen", fallback_source, crop_notes

        if window_info is not None:
            crop_notes.append(
                "window geometry unavailable; screenshot crop fell back to full-screen"
            )
        return None, "full-screen", fallback_source, crop_notes

    def _pane_region(
        self,
        context: AppContext,
        *,
        window_info: WindowInfo | None,
        screenshot_backend: str | None,
        raw_path: Path,
    ) -> tuple[ScreenshotRegion | None, str | None]:
        entry = _active_mux_entry(context.structured_context)
        if entry is None:
            return None, None
        if entry.confidence != AdapterConfidence.HIGH:
            return None, "mux pane confidence is not high"

        metadata = entry.metadata
        missing = [
            key
            for key in ("cell_x", "cell_y", "cell_rows", "cell_columns")
            if key not in metadata
        ]
        if missing:
            return None, "missing " + ", ".join(missing)

        cell_x = _metadata_int(metadata, "cell_x")
        cell_y = _metadata_int(metadata, "cell_y")
        rows = _metadata_int(metadata, "cell_rows")
        columns = _metadata_int(metadata, "cell_columns")
        if cell_x is None or cell_y is None or rows is None or columns is None:
            return None, "pane cell metadata is not integral"
        if cell_x < 0 or cell_y < 0 or rows <= 0 or columns <= 0:
            return None, "pane cell metadata has invalid bounds"

        cell_metrics = _trusted_cell_metrics(self._terminal_cell_pixel_size)
        if cell_metrics is None:
            return None, "terminal cell pixel metrics unavailable"
        cell_width, cell_height = cell_metrics

        x = cell_x * cell_width
        y = cell_y * cell_height
        width = columns * cell_width
        height = rows * cell_height
        if screenshot_backend not in WINDOW_LOCAL_SCREENSHOT_BACKENDS:
            if window_info is None or window_info.geometry is None:
                return None, "window geometry unavailable for screen-coordinate pane crop"
            window_x, window_y, _window_width, _window_height = window_info.geometry
            x += window_x
            y += window_y

        raw_size = _image_size(raw_path)
        if raw_size and not _rect_overlaps((x, y, width, height), raw_size):
            return None, "pane crop outside screenshot bounds"

        return ScreenshotRegion(
            x=x,
            y=y,
            width=width,
            height=height,
            kind="pane",
            coordinate_space="image",
            source=entry.source,
            confidence=entry.confidence,
            provenance=entry.provenance or [entry.source],
        ), None

    def _crop_and_compress_result(
        self,
        raw_path: Path,
        *,
        region: ScreenshotRegion | None,
        fallback_mode: str,
        fallback_source: str,
    ) -> tuple[bytes, int, int, ScreenshotCropInfo]:
        crop_method = getattr(self._screenshot, "crop_and_compress_result", None)
        if callable(crop_method):
            result = crop_method(
                raw_path,
                region=region,
                fallback_mode=fallback_mode,
                fallback_source=fallback_source,
            )
            if isinstance(result, tuple) and len(result) == 4:
                return result

        crop_rect = None
        if region is not None:
            crop_rect = (region.x, region.y, region.width, region.height)
        jpeg, width, height = self._screenshot.crop_and_compress(raw_path, crop_rect)
        return (
            jpeg,
            width,
            height,
            ScreenshotCropInfo(
                mode=_crop_mode_for_region(region, fallback_mode),
                rect=crop_rect or (0, 0, width, height),
                source=region.source if region else fallback_source,
                confidence=region.confidence if region else AdapterConfidence.UNKNOWN,
                provenance=(region.provenance or [region.source])
                if region
                else [fallback_source],
            ),
        )

    async def _capture_raw(self, window_id: str | None = None) -> Path:
        return await self._screenshot.capture_raw(window_id=window_id)

    async def _capture_raw_result(self, window_id: str | None = None):
        if type(self._screenshot) is ScreenshotCapturer:
            return await self._screenshot.capture_raw_result(window_id=window_id)
        path = await self._screenshot.capture_raw(window_id=window_id)
        return adapter_success(
            AdapterKind.SCREENSHOT,
            "mock-or-legacy",
            path,
            confidence=AdapterConfidence.UNKNOWN,
            privacy_notes=["Screenshot bytes are not included in diagnostics."],
        )

    @staticmethod
    def _capture_window():
        return get_window_result(executor_safe=True)

    @staticmethod
    async def _capture_widgets_async() -> tuple[WidgetInfo | None, WidgetInfo | None, bool]:
        """Capture focused widget and widget under cursor via subprocess."""
        return await query_widgets_subprocess()

    @staticmethod
    async def _capture_widgets_result_async():
        focused, cursor, available = await ContextCapturer._capture_widgets_async()
        if available:
            return adapter_success(
                AdapterKind.TEXT_CONTEXT,
                "atspi-subprocess",
                (focused, cursor),
                confidence=AdapterConfidence.HIGH,
                privacy_notes=["Widget diagnostics exclude captured text."],
            )
        return adapter_degraded(
            AdapterKind.TEXT_CONTEXT,
            "atspi-subprocess",
            (focused, cursor) if focused or cursor else None,
            reason="AT-SPI unavailable or widget subprocess failed",
            confidence=AdapterConfidence.LOW,
            privacy_notes=["Widget diagnostics exclude captured text."],
        )

    @staticmethod
    def _is_terminal_class(window_class: str | None) -> bool:
        """Check if window class is a known terminal emulator."""
        if not window_class:
            return False
        from talk_to_tux.pipeline.context_packer import _APP_TYPES

        return _APP_TYPES.get(window_class) == "terminal"

    @staticmethod
    def _detect_terminal(window_pid: int, window_title: str | None):
        """Detect TUI apps via /proc process tree. Returns TerminalProcessInfo or None."""
        try:
            from talk_to_tux.context.process import detect_terminal_apps

            return detect_terminal_apps(window_pid, window_title)
        except Exception:
            logger.debug("Process tree detection failed", exc_info=True)
            return None


def _combine_confidence(*values: AdapterConfidence) -> AdapterConfidence:
    if any(v == AdapterConfidence.HIGH for v in values):
        return AdapterConfidence.HIGH
    if any(v == AdapterConfidence.MEDIUM for v in values):
        return AdapterConfidence.MEDIUM
    if any(v == AdapterConfidence.LOW for v in values):
        return AdapterConfidence.LOW
    return AdapterConfidence.UNKNOWN


def _active_mux_entry(
    entries: list[StructuredAppContext],
) -> StructuredAppContext | None:
    for entry in entries:
        if entry.kind == "terminal-pane" and entry.source in {"zellij", "tmux"}:
            return entry
    return None


def _metadata_int(
    metadata: dict[str, str | int | float | bool | None], key: str
) -> int | None:
    value = metadata.get(key)
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdecimal():
        return int(value)
    return None


def _trusted_cell_metrics(
    metrics: tuple[int, int] | None,
) -> tuple[int, int] | None:
    if metrics is None:
        return None
    cell_width, cell_height = metrics
    if (
        isinstance(cell_width, bool)
        or isinstance(cell_height, bool)
        or not isinstance(cell_width, int)
        or not isinstance(cell_height, int)
        or cell_width <= 0
        or cell_height <= 0
    ):
        return None
    return cell_width, cell_height


def _image_size(path: Path) -> tuple[int, int] | None:
    try:
        with Image.open(path) as img:
            return img.width, img.height
    except Exception:
        return None


def _rect_overlaps(
    rect: tuple[int, int, int, int], image_size: tuple[int, int]
) -> bool:
    x, y, width, height = rect
    image_width, image_height = image_size
    if width <= 0 or height <= 0:
        return False
    return x < image_width and y < image_height and x + width > 0 and y + height > 0


def _crop_mode_for_region(
    region: ScreenshotRegion | None, fallback_mode: str
) -> str:
    if region is None:
        return fallback_mode
    if region.kind in {"pane", "terminal-pane", "pane-crop"}:
        return "pane-crop"
    if region.kind in {"window", "window-crop"}:
        return "window-crop"
    return fallback_mode
