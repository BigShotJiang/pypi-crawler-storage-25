from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from talk_to_tux.context.adapters import AdapterConfidence

if TYPE_CHECKING:
    from talk_to_tux.context.process import TerminalProcessInfo


@dataclass
class WindowInfo:
    """Intermediate result from window metadata capture."""

    title: str | None = None
    wm_class: str | None = None
    wm_instance: str | None = None
    pid: int | None = None
    window_id: str | None = None
    geometry: tuple[int, int, int, int] | None = None  # (x, y, width, height)
    backend: str | None = None
    provenance: list[str] = field(default_factory=list)
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    degraded_reason: str | None = None
    missing_tools: list[str] = field(default_factory=list)
    diagnostics: dict[str, str | int | float | bool | None] = field(default_factory=dict)


@dataclass
class WidgetInfo:
    """Accessibility info about a single widget."""

    role: str | None = None
    name: str | None = None
    states: list[str] | None = None
    caret_offset: int | None = None
    text_content: str | None = None
    text_around_caret: str | None = None
    selected_text: str | None = None
    placeholder: str | None = None


@dataclass
class StructuredAppContext:
    """Generic app-specific context supplied by optional adapters."""

    kind: str
    source: str
    label: str | None = None
    text: str | None = None
    metadata: dict[str, str | int | float | bool | None] = field(default_factory=dict)
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    provenance: list[str] = field(default_factory=list)
    degraded_reasons: list[str] = field(default_factory=list)
    privacy_notes: list[str] = field(default_factory=list)


@dataclass
class ScreenshotRegion:
    """A proposed relevant rectangle for screenshot processing."""

    x: int
    y: int
    width: int
    height: int
    kind: str
    coordinate_space: str
    source: str
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    provenance: list[str] = field(default_factory=list)
    degraded_reason: str | None = None


@dataclass
class ScreenshotCropInfo:
    """Metadata for the crop applied to a processed screenshot."""

    mode: str
    rect: tuple[int, int, int, int]
    source: str
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    provenance: list[str] = field(default_factory=list)
    degraded_reason: str | None = None


@dataclass
class AppContext:
    """Complete captured application context."""

    timestamp: float = field(default_factory=time.time)
    window_title: str | None = None
    window_class: str | None = None
    window_instance: str | None = None
    window_pid: int | None = None
    screenshot_png: bytes | None = None
    screenshot_width: int = 0
    screenshot_height: int = 0
    screenshot_crop: ScreenshotCropInfo | None = None
    widget_role: str | None = None
    widget_name: str | None = None
    caret_offset: int | None = None
    window_id: str | None = None
    cursor_widget_role: str | None = None
    cursor_widget_name: str | None = None
    text_content: str | None = None
    text_around_caret: str | None = None
    selected_text: str | None = None
    widget_placeholder: str | None = None
    terminal_info: TerminalProcessInfo | None = None
    structured_context: list[StructuredAppContext] = field(default_factory=list)
    desktop_backend: str | None = None
    window_backend: str | None = None
    screenshot_backend: str | None = None
    widget_backend: str | None = None
    paste_backend: str | None = None
    provenance: list[str] = field(default_factory=list)
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    window_confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    screenshot_confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    widget_confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    degraded_reasons: list[str] = field(default_factory=list)
    missing_tools: list[str] = field(default_factory=list)
    privacy_notes: list[str] = field(default_factory=list)


@dataclass
class DesktopToolStatus:
    name: str
    installed: bool
    purpose: str
    selected: bool = False
    degraded_reason: str | None = None


@dataclass
class DesktopCapabilityReport:
    display_server: str = "unknown"
    display: str | None = None
    wayland_display: str | None = None
    xdg_current_desktop: str | None = None
    session_type: str | None = None
    compositor_hints: list[str] = field(default_factory=list)
    tools: dict[str, DesktopToolStatus] = field(default_factory=dict)
    portal_available: bool | None = None
    atspi_available: bool | None = None
    tray_support: str = "unknown"
    selected_adapters: dict[str, str] = field(default_factory=dict)
    missing_dependencies: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    privacy_notes: list[str] = field(default_factory=list)
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
