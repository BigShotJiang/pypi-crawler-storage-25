from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Generic, Protocol, TypeVar

if TYPE_CHECKING:
    from talk_to_tux.context.models import AppContext, StructuredAppContext


class AdapterKind(str, Enum):
    ACTIVE_WINDOW = "active_window"
    SCREENSHOT = "screenshot"
    TEXT_CONTEXT = "text_context"
    APP_CONTEXT = "app_context"
    PASTE = "paste"
    KEYSTROKE = "keystroke"
    TRAY_SETTINGS = "tray_settings"


class AdapterConfidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"


T = TypeVar("T")


@dataclass
class AdapterResult(Generic[T]):
    kind: AdapterKind
    backend: str
    value: T | None = None
    ok: bool = False
    confidence: AdapterConfidence = AdapterConfidence.UNKNOWN
    provenance: list[str] = field(default_factory=list)
    degraded_reason: str | None = None
    missing_tools: list[str] = field(default_factory=list)
    privacy_notes: list[str] = field(default_factory=list)
    diagnostics: dict[str, str | int | float | bool | None] = field(default_factory=dict)

    @property
    def usable(self) -> bool:
        return self.ok and self.value is not None


class DesktopAdapter(Protocol[T]):
    name: str
    kind: AdapterKind

    def run(self) -> AdapterResult[T]:
        ...


class AppContextAdapter(Protocol):
    name: str

    def can_handle(self, context: AppContext) -> bool:
        ...

    async def capture(
        self, context: AppContext
    ) -> AdapterResult[list[StructuredAppContext]]:
        ...


WINDOW_BACKENDS = ("wnck", "ttt-gnome-dbus", "window-calls-extended", "xdotool")
WINDOW_BACKENDS_EXECUTOR_SAFE = ("ttt-gnome-dbus", "window-calls-extended", "xdotool")
SCREENSHOT_BACKENDS_WAYLAND = ("grim", "portal", "scrot")
SCREENSHOT_BACKENDS_X11 = ("import-window", "scrot-focused", "scrot")
TEXT_CONTEXT_BACKENDS = ("atspi-subprocess",)
PASTE_BACKENDS_X11 = ("xclip", "xdotool")
PASTE_BACKENDS_WAYLAND = ("wl-copy", "wtype", "ydotool", "xdotool", "evdev-uinput")
TRAY_SETTINGS_BACKENDS = ("appindicator", "gtk-status-icon", "none")
APP_CONTEXT_BACKENDS: tuple[str, ...] = ()

ADAPTER_REGISTRY: dict[AdapterKind, tuple[str, ...]] = {
    AdapterKind.ACTIVE_WINDOW: WINDOW_BACKENDS,
    AdapterKind.SCREENSHOT: SCREENSHOT_BACKENDS_WAYLAND + SCREENSHOT_BACKENDS_X11,
    AdapterKind.TEXT_CONTEXT: TEXT_CONTEXT_BACKENDS,
    AdapterKind.APP_CONTEXT: APP_CONTEXT_BACKENDS,
    AdapterKind.PASTE: PASTE_BACKENDS_WAYLAND + PASTE_BACKENDS_X11,
    AdapterKind.KEYSTROKE: ("wtype", "ydotool", "xdotool", "evdev-uinput"),
    AdapterKind.TRAY_SETTINGS: TRAY_SETTINGS_BACKENDS,
}


def adapter_success(
    kind: AdapterKind,
    backend: str,
    value: T,
    *,
    confidence: AdapterConfidence = AdapterConfidence.HIGH,
    provenance: list[str] | None = None,
    privacy_notes: list[str] | None = None,
    diagnostics: dict[str, str | int | float | bool | None] | None = None,
) -> AdapterResult[T]:
    return AdapterResult(
        kind=kind,
        backend=backend,
        value=value,
        ok=True,
        confidence=confidence,
        provenance=provenance or [backend],
        privacy_notes=privacy_notes or [],
        diagnostics=diagnostics or {},
    )


def adapter_degraded(
    kind: AdapterKind,
    backend: str,
    value: T | None = None,
    *,
    reason: str,
    confidence: AdapterConfidence = AdapterConfidence.LOW,
    provenance: list[str] | None = None,
    missing_tools: list[str] | None = None,
    privacy_notes: list[str] | None = None,
    diagnostics: dict[str, str | int | float | bool | None] | None = None,
) -> AdapterResult[T]:
    return AdapterResult(
        kind=kind,
        backend=backend,
        value=value,
        ok=value is not None,
        confidence=confidence,
        provenance=provenance or [backend],
        degraded_reason=reason,
        missing_tools=missing_tools or [],
        privacy_notes=privacy_notes or [],
        diagnostics=diagnostics or {},
    )


def adapter_missing(
    kind: AdapterKind,
    backend: str,
    missing_tools: list[str],
    *,
    reason: str | None = None,
    diagnostics: dict[str, str | int | float | bool | None] | None = None,
) -> AdapterResult[T]:
    return AdapterResult(
        kind=kind,
        backend=backend,
        ok=False,
        confidence=AdapterConfidence.UNKNOWN,
        provenance=[backend],
        degraded_reason=reason or f"missing tools: {', '.join(missing_tools)}",
        missing_tools=missing_tools,
        diagnostics=diagnostics or {},
    )


async def run_app_context_adapters(
    context: AppContext,
    adapters: tuple[AppContextAdapter, ...] | list[AppContextAdapter],
    *,
    timeout_seconds: float = 0.5,
) -> AdapterResult[list[StructuredAppContext]]:
    values: list[StructuredAppContext] = []
    provenance: list[str] = []
    degraded_reasons: list[str] = []
    missing_tools: list[str] = []
    privacy_notes: list[str] = []
    confidences: list[AdapterConfidence] = []

    for adapter in adapters:
        name = adapter.name
        try:
            if not adapter.can_handle(context):
                provenance.append(f"{name}:unsupported")
                continue
        except Exception:
            provenance.append(name)
            degraded_reasons.append(f"{name}: can_handle failed")
            continue

        try:
            result = await asyncio.wait_for(
                adapter.capture(context), timeout=timeout_seconds
            )
        except TimeoutError:
            provenance.append(name)
            degraded_reasons.append(f"{name}: timed out")
            privacy_notes.append("App-context adapter timed out without diagnostics payloads.")
            continue
        except Exception:
            provenance.append(name)
            degraded_reasons.append(f"{name}: capture failed")
            privacy_notes.append("App-context adapter failed without diagnostics payloads.")
            continue

        provenance.extend(result.provenance or [name])
        missing_tools.extend(result.missing_tools)
        privacy_notes.extend(result.privacy_notes)
        confidences.append(result.confidence)
        if result.degraded_reason:
            degraded_reasons.append(result.degraded_reason)
        if result.value:
            values.extend(result.value)

    if adapters and not values and not degraded_reasons:
        degraded_reasons.append("no app-context adapters matched")

    return AdapterResult(
        kind=AdapterKind.APP_CONTEXT,
        backend="app-context",
        value=values,
        ok=not degraded_reasons or bool(values),
        confidence=_combine_confidence(confidences),
        provenance=provenance,
        degraded_reason="; ".join(degraded_reasons) if degraded_reasons else None,
        missing_tools=sorted(set(missing_tools)),
        privacy_notes=privacy_notes,
    )


def _combine_confidence(values: list[AdapterConfidence]) -> AdapterConfidence:
    if any(v == AdapterConfidence.HIGH for v in values):
        return AdapterConfidence.HIGH
    if any(v == AdapterConfidence.MEDIUM for v in values):
        return AdapterConfidence.MEDIUM
    if any(v == AdapterConfidence.LOW for v in values):
        return AdapterConfidence.LOW
    return AdapterConfidence.UNKNOWN
