from __future__ import annotations

import os
import shlex
from dataclasses import dataclass, field
from pathlib import Path


APP_ID = "talk-to-tux"
APP_NAME = "Talk to Tux"
DESKTOP_FILENAME = f"{APP_ID}.desktop"


@dataclass
class DesktopIntegrationStatus:
    launcher_installed: bool
    autostart_enabled: bool
    launcher_path: Path
    autostart_path: Path
    command: str
    icon_path: Path
    warnings: list[str] = field(default_factory=list)


def data_home() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))


def config_home() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))


def launcher_path() -> Path:
    return data_home() / "applications" / DESKTOP_FILENAME


def autostart_path() -> Path:
    return config_home() / "autostart" / DESKTOP_FILENAME


def icon_path() -> Path:
    from talk_to_tux.indicator.icons import ICON_IDLE

    return Path(ICON_IDLE)


def launch_command() -> str:
    repo_root = Path(__file__).resolve().parents[2]
    if (repo_root / "pyproject.toml").exists() and (repo_root / "uv.lock").exists():
        venv_command = repo_root / ".venv" / "bin" / "talk-to-tux"
        app_command = shlex.quote(str(venv_command)) if venv_command.exists() else "uv run talk-to-tux"
        cache_dir = '"${XDG_CACHE_HOME:-$HOME/.cache}/talk-to-tux"'
        script = (
            f"cd {shlex.quote(str(repo_root))} && "
            f"mkdir -p {cache_dir} && "
            f"setsid -f {app_command} >>{cache_dir}/talk-to-tux.log 2>&1 < /dev/null"
        )
        return f"bash -lc {shlex.quote(script)}"
    return "talk-to-tux"


def build_desktop_entry(*, autostart: bool = False) -> str:
    command = launch_command()
    lines = [
        "[Desktop Entry]",
        "Type=Application",
        f"Name={APP_NAME}",
        "Comment=Voice-to-smart-paste pipeline for Linux",
        f"Exec={command}",
        f"Icon={icon_path()}",
        "Terminal=false",
        "Categories=Utility;Accessibility;",
        "StartupNotify=false",
    ]
    if autostart:
        lines.extend([
            "X-GNOME-Autostart-enabled=true",
            "X-KDE-autostart-after=panel",
        ])
    return "\n".join(lines) + "\n"


def install_launcher() -> Path:
    path = launcher_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(build_desktop_entry(), encoding="utf-8")
    path.chmod(0o644)
    return path


def remove_launcher() -> bool:
    return _remove_file(launcher_path())


def enable_autostart() -> Path:
    path = autostart_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(build_desktop_entry(autostart=True), encoding="utf-8")
    path.chmod(0o644)
    return path


def disable_autostart() -> bool:
    return _remove_file(autostart_path())


def get_status() -> DesktopIntegrationStatus:
    command = launch_command()
    icon = icon_path()
    warnings: list[str] = []
    if not icon.exists():
        warnings.append(f"icon missing: {icon}")
    if "uv run" in command and _which("uv") is None:
        warnings.append("uv not found on PATH")
    if "setsid -f" in command and _which("setsid") is None:
        warnings.append("setsid not found on PATH")
    return DesktopIntegrationStatus(
        launcher_installed=launcher_path().exists(),
        autostart_enabled=autostart_path().exists(),
        launcher_path=launcher_path(),
        autostart_path=autostart_path(),
        command=command,
        icon_path=icon,
        warnings=warnings,
    )


def _remove_file(path: Path) -> bool:
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False


def _which(name: str) -> str | None:
    paths = os.environ.get("PATH", "").split(os.pathsep)
    for raw in paths:
        candidate = Path(raw) / name
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None
