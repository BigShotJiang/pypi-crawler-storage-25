# Changelog

All notable changes to Talk-to-Tux are documented here.

## [Unreleased]

## [0.2.3] — 2026-05-12

### Fixed
- Paste into terminals (kitty, alacritty, foot, ...) on Wayland was
  emitting Ctrl+V instead of Ctrl+Shift+V when the recording-time
  window context was missing (`None`) or its `wm_class` arrived in an
  unexpected casing (e.g. `Kitty`, `Wezterm`). The per-app rule matcher
  in `AppRuleMatcher._pattern_matches` and `is_terminal()` are now
  case-insensitive (literal patterns only — globs and `~regex` stay
  byte-exact). The Wayland safety-net in `Paster.paste()` now defaults
  to Ctrl+Shift+V whenever no rule matched and the window class can't
  be positively identified as a non-terminal — Ctrl+V is reserved for
  apps the matcher has explicitly recognized. `org.kitty.kitty` and
  `xterm-kitty` were added to the recognized terminal set for
  compositors that report kitty under those identifiers.
- Hosted-mode recordings were spamming an
  `AttributeError: 'HostedSttProvider' object has no attribute '_chain'`
  traceback on every `on_record_start` callback. The error was caught
  by the side-button wrapper so the pipeline still completed, but the
  noise polluted logs and the speculative-transcription branch never
  ran. `_begin_recording_session` now reads `_chain` via `getattr` —
  the speculative loop is a GPU-path optimization that doesn't apply
  to hosted STT and is correctly skipped without raising.

### Added
- Two `[paste] keystroke ...` INFO log lines record the resolved
  backend + shortcut + argv on every paste keystroke. A future
  regression of the kitty paste bug surfaces in
  `~/.cache/talk-to-tux/talk-to-tux.log` on the first attempt without
  needing a debug rebuild.

## [0.2.2] — 2026-04-29

### Fixed
- `talk-to-tux switch-mode hosted` (and the setup-wizard hosted path) was
  appending `api_mode = "hosted"` to the end of an existing `config.toml`.
  Because TOML carries section context until the next header, the line was
  parsed as part of whatever `[section]` happened to be the last one in the
  file (e.g. `[stt.local_whisper].api_mode`). The top-level `api_mode` field
  stayed at the default and the desktop client kept routing through BYO-key
  providers. `set_api_mode` now prepends the line at the document root and
  drops any stale nested duplicates.
- Backend (no client release): `requireBearerToken` in `_shared/auth.ts`
  used `raw.split("_")` to parse `ttt_<id>_<secret>`. The b64url charset
  includes `_`, so any token whose 22-char id segment contained an
  underscore (~50% of randomly generated tokens) split into more than 3
  parts and was rejected as `malformed`. Replaced with the same anchored
  regex used by `parse_access_token` on the client. Also added
  `verify_jwt = false` for `v1-quota`, `v1-stt`, `v1-rewrite` in
  `config.toml`; previously the Supabase edge gateway rejected our
  `ttt_*` bearers as malformed JWTs before the function code ran.

## [0.2.1] — 2026-04-29

### Fixed
- Hosted-mode login was completely broken since v0.2.0 because `auth-start`
  forwarded the client's `state` query param to GoTrue's `/auth/v1/authorize`,
  overriding the `flow_state.id` UUID GoTrue uses for callback lookup (per
  upstream commit #2331). Stopped forwarding `state` from `auth-start`;
  stopped generating/validating client state in `oauth_flow.py`. PKCE
  `code_verifier` was and remains the actual CSRF defense. See
  `plans/dryrun-2026-04-29-findings.md`.

### Documentation
- Architecture diagram in `specs/architecture.mmd` now declares `LIH`,
  `PROV`, `BC`, `ACA` for modules added in PROVIDERS / EFFCHAIN /
  context-adapters phases (`local_inference_health.py`, `providers.py`,
  `context/browser_contract.py`, `context/app_context_adapters.py`).
  `scripts/check_architecture.py::_FILE_TO_NODES` updated accordingly.

## [0.2.0] — 2026-04-27

### Added
- First-run privacy disclosure in the setup wizard covering hosted-vs-BYO
  data flow and the default-off local cache.

### Security
- Hosted-mode OAuth now gated on an approved beta application. New
  `auth-start` edge function bridges the desktop PKCE flow to Supabase
  GoTrue `/authorize`; `auth-callback` rejects unapproved GitHub users with
  HTTP 403 / `unapproved_beta_applicant`. Migration `0004_auth_admission.sql`
  adds a `github_id` column to `beta_applications` so the admission lookup
  matches on either `github_id` or `email` (with backfill on first login).

### Changed
- `cache.enabled` default flipped from `true` to `false`. Local run artifacts
  (audio, transcripts, screenshots, rewrites) no longer persist by default;
  opt in with `TTT_CACHE_ENABLED=true` or `[cache] enabled = true`. Feedback
  and correction-learning paths are unaffected.

### Fixed
- **BYO-key crash on first rewrite**: Generated BAML client is now shipped
  inside the wheel. v0.1.0 wrote the generator output to `src/baml_client/`
  (gitignored, outside the packaged tree), so the published wheel contained
  no client code and BYO-key users hit
  `ModuleNotFoundError: No module named 'baml_client'` the moment the smart
  rewrite path executed. Hosted-mode users were unaffected (`HostedBamlRouter`
  calls the API over HTTP). Fix: BAML generator output relocated to
  `src/talk_to_tux/baml_client/`, picked up automatically by
  `packages = ["src/talk_to_tux"]`. The four production import sites
  (`pipeline/rewrite.py`, `stt/client.py`, `pipeline/analysis.py`,
  `doctor.py`) now use the fully-qualified `talk_to_tux.baml_client.*` path.
  CI release workflow regenerates the client and fails on staleness
  (`git diff --exit-code src/talk_to_tux/baml_client/`). New
  `tests/test_baml_smoke.py` does a real (un-mocked) import of
  `talk_to_tux.baml_client.async_client.b` as a regression guard.
- **`baml-py` runtime version coupling**: Generated client enforces an exact
  `baml-py` version match at import time. Previous `baml-py>=0.218.0` allowed
  pip to resolve a newer runtime, which then refused to load the
  `0.218.1`-generated client. Tightened to `baml-py==0.221.0` (regenerated
  against latest) so the runtime and generated client always ship as a
  locked pair. Bumping the pin requires regenerating the client
  (`baml_src/generators.baml` `version` field must match) and re-publishing.

## [0.1.0] — 2026-04-19

### Added — P7: PyPI release pipeline

- `pyproject.toml` switched to dynamic version (`[tool.hatch.version].path`) — single writable source is `src/talk_to_tux/__init__.py` `__version__`.
- Full PyPI Trove classifier set, including `Environment :: X11 Applications :: Gnome`, `Operating System :: POSIX :: Linux`, and Python 3.11/3.12 version classifiers.
- `[tool.hatch.build.targets.sdist]` target ensures README, LICENSE, CHANGELOG, pyproject ship in sdist.
- Wheel ships `gnome-extension/` and `default_app_rules.toml` via the `packages = ["src/talk_to_tux"]` tree (no `force-include` — it would duplicate entries and trigger a PyPI 400 on upload).
- Entry point `talk-to-tux = talk_to_tux.cli:main` via a delegating shim in `cli.py`.
- `README.md` Prerequisites rewritten with apt/pacman/dnf package matrix + `ydotool` v1.0+ build-from-source pointer + `uv run talk-to-tux --doctor` self-verify.
- `.github/workflows/release.yml` tag-triggered OIDC publish to PyPI via `pypa/gh-action-pypi-publish@release/v1` (Trusted Publishing, no long-lived secret).

### Added
- **Production-readiness hardening** (reviewer findings):
  - `PipelineCache.finalize_run()` — releases the in-memory run handle so
    post-failure operations can't write into a stale run dir.
  - `App._track()` helper for fire-and-forget `asyncio.create_task()` call
    sites. Tasks are registered in a set with a `done_callback` to self-clear
    and are cancelled on shutdown (prevents GC of live background tasks).
  - `systemd` unit hardening: `NoNewPrivileges`, `ProtectSystem=strict`,
    `ProtectHome=read-only`, `PrivateTmp`, `ReadWritePaths` scoped to
    `~/.config/talk-to-tux` and `~/.cache/talk-to-tux`, plus kernel and
    namespace protections. `/dev/input` left accessible for evdev.
  - Regression tests for background-task tracking, cache finalization after
    STT errors, `elevenlabs_api_key` masking, `local_whisper` timeout default,
    and CWD `.env` isolation.
- **Pre-recording ring buffer**: Microphone runs continuously with a 2-second
  circular buffer. Speech spoken before the button press is captured
  automatically — no more lost first words.
- **Audio stream watchdog**: Detects stale PortAudio streams (callback stalled
  or all-silent for >60s) and auto-recreates them. Prevents the app from going
  silent after long uptimes due to PipeWire suspend/profile changes.
- **Trigger-to-record telemetry**: `trigger_to_record_ms` in pipeline telemetry
  measures the true latency from physical button press to recording start.
- **ElevenLabs STT support**: Added as a provider in the STT chain with native
  `keyterms` parameter support for correction learning.
- **Correction learning** (Phase 19): Automatic word-level correction via
  `CorrectionLearner`. Learns from user edits after paste, applies corrections
  pre-rewrite, and injects keyterms into STT providers.
- **SECURITY.md**: Vulnerability reporting policy and security scope documentation.
- **AGPL-3.0-only license**: Switched from MIT so the open-source distribution
  has an explicit network-copyleft license.
- **Beta signup backend** (Phase P6): Public beta application flow and cron-driven
  screening automation. Includes `POST /v1/beta/apply` (with Cloudflare Turnstile
  validation), `GET /v1/beta/status` (unauthenticated status + screener verdict),
  `cron-screen-applications` (LLM-judged pass/reject/borderline with invite email),
  `cron-reset-quota` (monthly quota reset + 30-day tombstone hard-delete), and
  `cron-anomaly-watchdog` (weekly median+σ outlier detection with admin alert).

### Changed
- **VAD now trims silence before STT**: Previously VAD only decided *whether*
  to call STT; the raw recording was uploaded in full. STT providers now
  receive speech-only audio, so cost scales with spoken seconds rather than
  held-button seconds (10-minute hold with 90s of speech → ~90s of billed
  audio, not 10 minutes). `telemetry.audio_duration_ms` remains the raw hold
  duration for UX analytics; new `telemetry.stt_audio_duration_ms` reports
  what was actually sent to STT.
- **Confirmation tooltip default off**: `tooltip.enabled` now defaults to
  `false` — the rewrite result auto-pastes straight into the focused app with
  no confirm-before-paste popup. Re-enable with `[tooltip] enabled = true` in
  `config.toml` or `TTT_TOOLTIP__ENABLED=true`.
- **Recording dot decoupled from tooltip**: The red recording dot next to
  the cursor (mic-is-hot feedback) now shows regardless of `tooltip.enabled`.
  Previously it was gated on the same flag, so disabling the tooltip also
  hid the dot.
- **Transcript logs redacted**: INFO-level logs no longer emit raw STT /
  rewrite text. Char counts only at INFO; full text still logged at DEBUG.
- **`config.toml` `.env` precedence**: Secrets loader now reads only from
  `~/.config/talk-to-tux/secrets.env`, not the current working directory.
  Prevents a rogue CWD `.env` from overriding user secrets.
- **`LocalWhisperConfig.timeout`**: Default reduced from 30s to 5s so the
  provider fails fast into the fallback chain when the local server is down.

### Fixed
- **API key masking in `--show-config`**: `elevenlabs_api_key` is now included
  in the secret-redaction set alongside `openai_api_key`, `google_api_key`,
  and `groq_api_key`.
- **Transcription truncation**: Multiple causes identified and fixed:
  - Double-VAD trimming (our VAD + provider VAD) was cutting first words.
    Now sends raw audio to STT providers.
  - Double-tap hold detection consumed button presses meant for recording,
    losing 2–5 seconds of speech. Now uses speculative recording with VAD
    speech-detection override via the ring buffer.
  - 300ms hold-detection delay eliminated by starting recorder immediately
    on button press (speculative recording).
  - Event loop contention from 500ms focus poll reduced by pausing the poll
    during recording/processing states.
- **GVariant quote parsing**: Window titles with apostrophes (e.g. ChatGPT
  "Let's discuss...") broke D-Bus JSON parsing. Fixed by unescaping `\'`
  before `json.loads()`.
- **Paste into own UI window**: The talk-to-tux indicator/debug window was
  triggering false context-change detection. Now excluded from paste decision.
- **Paste with failed window detection**: When window detection fails at
  recording time (`window_class=None`), auto-paste instead of blocking with
  `offer_both` notification.
- **Rewrite prompt**: Added rules to never add escape characters (`\'`) and
  to preserve interrogative form (questions stay questions).
- **Per-member rewrite provider attribution**: `RewriteOutput.provider` now
  reports the actual BAML fallback chain member that answered
  (`LocalAI`, `Groq`, `Gemini`, `Ollama`) instead of the generic
  `SmartRewriteClient`. A `baml_py.Collector` is attached per-call and the
  `selected_call.client_name` is read after the response. Telemetry, debug
  tooltip, feedback analysis, and the new `INFO Rewrite member: <name>` log
  line all attribute outputs to the real member so future regressions are
  traceable. Falls back to the chain name if the collector is unavailable.
- **TARGET WINDOW salience**: The `TARGET WINDOW` line now includes the
  enriched app-type classification (`kitty — terminal (SSH to claw — remote
  zellij detected, use screenshot)`) instead of just the window class
  (`kitty`). Previously the SSH/TUI tag sat two blocks up in the
  `KNOWN APPLICATIONS` list and got out-weighted by branch-shaped titles
  in `WINDOW STATE`, producing shell commands (`git push`) from prose in
  SSH'd zellij sessions. Extracted `classify_window()` from `build_static`
  so both the list and the target line render from the same classifier.
- **TUI detection lost on fallback models**: `SmartRewriter._build_kwargs()`
  was discarding the fresh active-window `AppContext` (enriched with
  `terminal_info` via /proc walk) whenever the indicator's poll-cached
  `all_windows` was non-empty. Fallback rewrite models (Groq, Gemini) then
  saw `[1] kitty — terminal` instead of `[1] kitty — terminal running claude
  (chat)` and inserted shell commands inside TUIs. Fresh context now replaces
  the matching `window_id` entry in `all_windows` before context blocks are
  built.

### Changed
- **Default server URLs**: Changed from `http://ai:8000` / `http://ai:11434`
  to `http://localhost:8000` / `http://localhost:11434` for open-source
  distribution.
- **Wayland paste tool**: Documentation updated from `wtype` (which doesn't
  work on GNOME/Mutter) to `ydotool` v1.0+ with `ydotoold` daemon.
- **VAD role**: VAD now only gates (no-speech detection to skip STT). Raw
  audio is sent to STT providers which have their own VAD. Configurable
  `pre_pad_ms` and `post_pad_ms` retained but defaulted to 0.

### Removed
- **`.env.op`**: 1Password vault reference file removed from git tracking.
