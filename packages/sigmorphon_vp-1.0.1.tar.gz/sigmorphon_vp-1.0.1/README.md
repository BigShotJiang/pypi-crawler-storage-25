# sigmorphon

SigMorphon dataset downloader, TSV parser, and in-memory dataset with CUDA stream prefetch.

## Installation

```bash
pip install sigmorphon
```

Requires Python >= 3.14, PyTorch >= 2.0, and `chartoken >= 1.0.0`.

## Features

- **Download** SigMorphon 2021 Task 0 data for 11+ languages
- **TSV parsing** with MD5-based deduplication and column reordering
- **MorphDataset** — pre-encoded tensors in RAM with pinned memory and CUDA stream prefetch
- **Merge** multiple TSV files into a single training set

## Quick Start

```python
from sigmorphon import download_all, load_tsv, MorphDataset
from chartoken import CharVocab, FeatureVocab
from pathlib import Path

# Download Russian and German data
download_all(["rus", "deu"], Path("data/collections"))

# Load and encode
rows = load_tsv("data/collections/rus_train.tsv")
char_vocab = CharVocab.from_texts([r[0] for r in rows] + [r[2] for r in rows])
feat_vocab = FeatureVocab.from_tags([r[1] for r in rows])
lang_to_id = {"rus": 0}

dataset = MorphDataset(rows, char_vocab, feat_vocab, lang_to_id)
```

## License

See LICENSE file in the repository root.
