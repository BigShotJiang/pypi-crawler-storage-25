'''
Module: bground.points.ifunc
----------------------------
Functions definig interactive plot for semi-automated background subtraction.

* Semi-automatic method: user defines the bkg points in the interactive plot.
* Computer does the rest: the bkg definition, visualization and subtraction.

The interactive plot is defined in three levels/steps:
    
* Level 1 = func yielding the interactive plot = the plot linked with events.
* Level 2 = funcs for event types (such as key_press_event, close_event, ...).
* Level 3 = funcs for individual sub-events (such as specific keypress events).

Important technical notes:

* We keep the (very reasonable) mouse events from Matplotlib UI.
* We define just *key_press_events*, with which we can do the whole job.
* We can define additional simple events (here: *close_event* = on closing).
'''

import numpy as np
import matplotlib.pyplot as plt

from bground.points import bfunc
import warnings; warnings.filterwarnings("ignore")

# =============================================================================
# Level 1: Create plot with events

def interactive_plot(iplot):
    '''
    Create interactive plot from {iplot} object.

    * The basic interactivity is set here ('keypress_event', 'close_event').
    * The individual events are specified in the following funcs of the module.
    * This method is not used directly;
      usually it is called from bground.api.InteractivePlot object.

    Parameters
    ----------
    iplot : bground.api.InteractivePlot object
        InteractivePlot object contains all data to run interactive plot.
        This object is to be pre-defined within simple bground.api interface.
    
    Returns
    -------
    fig, ax : maptplotlib.pyplot objects
        The figure and axis of the interactive plot which shows XY-data.    
    '''
    
    # (0) Initialize
    # -----
    # (a) close all previous plots - to avoid mess in Jupyter
    plt.close('all')  
    # (b) store original plot params and initialize interactive plot params
    # (original_plot_params are restored when the plot is closed => on_close
    # (the on_close event/function is defined below
    original_plot_params = plt.rcParams.copy()
    initialize_interactive_plot_params()
    # (c) print introductory help message to stdout
    print_brief_help(iplot)
    
    # (1) Prepare the plot: fig,ax including window title
    # (num argument below can take both integers and strings
    fig,ax = plt.subplots(num='Background correction')

    # (2) Read XY data and create the plot
    # Get XY data from the function argument data
    X,Y = (iplot.data[0],iplot.data[1])
    # Plot XY data
    ax.plot(X,Y, 'b-')
    # Set the remaining plot parameters
    ax.set_xlim(iplot.pars.xlim)
    ax.set_ylim(iplot.pars.ylim)
    ax.set_xlabel(iplot.pars.xlabel)
    ax.set_ylabel(iplot.pars.ylabel)
    
    # (3) Connect the plot with event(s)
    #   => link fig.canvas event(s) to a callback function(s).
    # Here: two types of events:
    #   key_press_event -> callback function = on_keypress.
    #   close_event     -> callback function = on_close
    # The callback function links the events to further user-defind funcs.
    #   Note1: all is based on standard matplotlib function canvas.mpl_connect
    #   Note2: the individual functions are defined below.
    # Trick: If we need an event with multiple arguments => lambda functions.
    #   GoogleSearch: python calback with multiple arguments 
    
    # (3a) Connect plot with key_press_event (= when a key is pressed)
    fig.canvas.mpl_connect('key_press_event',
        lambda event: on_keypress(event, fig, ax, iplot))
    
    # (3b) Connect plot with close_event (= when the window is closed)
    fig.canvas.mpl_connect('close_event',
        lambda event: on_close(event, original_plot_params))
    
    # (4) Optimize the plot layout
    plt.tight_layout()
    
    # (5) Return fig,ax
    # (This is necessary, among others, fof Jupyter + %matplotlib widget
    return(fig,ax)


# =============================================================================
# Level 2: Callback functions for all events

def on_keypress(event, fig, ax, iplot):
    '''
    Definition of key_press_events for a plot.
    
    * The callback function, which defines all keypress events.
    * The functions for the individual keypress events are defined below.
    '''
    # Step 3 in defining interactive plot
    # = defining individual functions for specific pressed keys.
    # -----
    # Read pressed key and mouse coordinates
    key = event.key
    xm,ym = event.xdata,event.ydata
    # Mouse outside graph area - just print warning!
    if xm == None or ym == None:
        if iplot.pars.messages:
            print(f'Key [{key}] mouse outside plot area - no action!')
    # Mouse inside graph area, run corresponding function.
    else:
        if iplot.pars.messages:
            print(f'Key [{key:s}] mouse [{xm:.1f},{ym:.1f}]', end=' ')
        # Functions run by means try-except
        # Reason: to ignore nonsense actions...
        #  such as delete/draw points if no points are defined
        # NOW : working, raising exceptions with descriptions and continuing
        # TODO: better treatment of exceptions directly in the individual funcs
        try:
            if   key == '1': add_bkg_point(ax, iplot, xm, ym)
            elif key == '2': del_bkg_point_close_to_mouse(ax, iplot, xm, ym)
            elif key == '3': replot_with_bkg_points(ax, iplot)
            elif key == '4': replot_with_bkg_curve(ax, iplot, 'linear')
            elif key == '5': replot_with_bkg_curve(ax, iplot, 'quadratic')
            elif key == '6': replot_with_bkg_curve(ax, iplot, 'cubic')
            elif key == 'a': load_bkg_points(ax, iplot)
            elif key == 'b': save_bkg_points(iplot)
            elif key == 's': save_PNG_image(iplot) 
            elif key == 't': subtract_bkg_and_save(iplot)
            elif iplot.pars.messages: print()  # any other key => empty line
        except Exception as err:
            print()  # allways start error message in a new line  
            raise Exception(err)


def on_close(event, original_plot_params):
    '''
    Definition of on_close event of the plot.
    
    * The simple callback function, which runs
      when the interactive plot window is closed.
    * The function
      restores the original plot parameters
      and prints concluding remarks on stdout.
    '''
    
    # (1) Restore original plot parameters
    plt.rcParams.update(original_plot_params)
    
    # (2) Print "close" message on stdout
    print()
    print('The interactive plot was closed.')
    print('If you followed the documentation and instructions,')
    print('the results are saved in the calling object and')
    print('(optionally) in the TXT, TXT.BP, and TXT.PNG files.')


# =============================================================================
# Level 3: Functions for individual keypress events       

def add_bkg_point(ax, iplot, xm, ym):
    '''
    Function for keypress = '1'.
    
    * Add background point at current mouse position.
    * More precisely: add a background point at the the XY-curve,
      whose X-coordinate is the closest to the mouse X-coordinate.
    '''
    idx = find_nearest(iplot.data[0],xm)
    xm,ym = (iplot.data[0,idx],iplot.data[1,idx])
    iplot.background.points.add_point(xm,ym)
    ax.plot(xm,ym,'r+')
    plt.draw()
    if iplot.pars.messages: print('background point added.')
    

def del_bkg_point_close_to_mouse(ax, iplot, xm, ym):
    '''
    Function for keypress = '2'.
    
    * Remove the background point close to mouse cursor position.
    * More precisely: remove the background point from the XY-curve,
      whose X-coordinate is the closest to the mouse cursor X-coordinate.
    '''
    # a) Sort bkg points (sorted array is necessary for the next step)
    iplot.background.points.sort_acc_to_X()
    # b) Find index of background point closest to the mouse X-position
    idx = find_nearest(np.array(iplot.background.points.X), xm)
    # c) Remove element with given index from X,Y-lists (save coordinates)
    xr = iplot.background.points.X.pop(idx)
    yr = iplot.background.points.Y.pop(idx)
    # d) Redraw removed element with background color
    ax.plot(xr,yr, 'w+')
    # e) Redraw plot
    plt.draw()
    # f) Print message to stdout.
    if iplot.pars.messages: print('background point deleted.')


def replot_with_bkg_points(ax, iplot, points_reloaded=False):
    '''
    Function for keypress = '3'.
    
    * Re-draw plot with backround points.
    * Additional keyword parameter (points_reloaded=False),
      is employed if the function is called from load_bkg_points function.
    * The load_bkg_points function uses its own short message
      and sets points_reloaded=True to avoid additional confusing messages.
    '''
    clear_plot()
    ax.plot(iplot.data[0], iplot.data[1], 'b-')
    ax.plot(iplot.background.points.X, iplot.background.points.Y, 'r+')
    plt.draw()
    if iplot.pars.messages == True and points_reloaded == False:
        # Print message to stdout.
        print('backround points re-drawn.')

def replot_with_bkg_curve(ax, iplot, btype):
    '''
    Function for keypress = '4,5,6'.
    
    * Re-draw plot with backround points and background curve.
    * Type of the curve (linear, quadratic, cubic) is given by {btype} arg.
    * For key = 4/5/6 the function called with btype = linear/quadratic/cubic.
    * Moreover, the {btype} is saved inside {iplot} - for a possible replot.
    '''
    # Sort background points + calculate background
    iplot.background.points.sort_acc_to_X()
    iplot.background.btype = btype
    bfunc.calculate_baseline(iplot)
    # Clear plot + re-draw it with the background points
    clear_plot()
    ax.plot(iplot.data[0], iplot.data[1], 'b-')
    ax.plot(iplot.background.points.X, iplot.background.points.Y, 'r+')
    ax.plot(iplot.background.curve.X, iplot.background.curve.Y,'r:')
    plt.draw()
    # Print a brief message on stdout if requested
    if iplot.pars.messages:
        if iplot.background.btype == 'linear':
            print('linear background displayed.')
        elif iplot.background.btype == 'quadratic':
            print('quadratic background displayed.')
        elif iplot.background.btype == 'cubic':
            print('cubic background displayed.')
        else:
            print('unknown background type!')

def load_bkg_points(ax, iplot):
    '''
    Function for keypress = 'a'.

    * Load background points from previously saved file.
    * Assumption: the file has been saved with save_bkg_points function,
      which means that its name is fixed/known/saved in: 
      iplot.background.bname + '.bp'.
    '''
    # a) get input file with previously saved background points
    # (the filename is fixed to {bname}.bp
    # (the {bname} is stored in {bkg_object} = here {bkgr} argument
    # (reason: to insert a name during an interactive plot session is a hassle
    input_filename = iplot.background.bname + '.bp'
    # b) read input file to DataFrame
    bfunc.load_bkg_points(iplot)
    # c) print message if requested
    if iplot.pars.messages:
        print(f'bkg points read from: [{input_filename}].')
    # d) replot with currently loaded background
    replot_with_bkg_points(ax, iplot, points_reloaded=True)


def save_bkg_points(iplot):
    '''
    Function for keypress = 'b'.
    
    * Save background points to file.
    * The output file name will beL iplot.background.bname + '.bp'.
    '''
    # Treat the special case when the user presses 'b'
    # but there are no background points defined at the moment.
    if len(iplot.background.points.X) == 0:
        print('no background points defined!')
        return()
    # ALWAYS sort the background points.
    iplot.background.points.sort_acc_to_X()
    # OPTIONALLY save the points to file => if saveTXT is True
    # (saving to file is default, but we may not need it
    # (in some auto-scripts it is enough to keep the points in the object
    if iplot.pars.saveTXT is True: 
        bfunc.save_bkg_points(iplot)
    # Print the final message
    if iplot.pars.messages:
        if iplot.pars.saveTXT is False:
            # Data ALWAYS saved in self.data and self.background
            # and OPTIONALLY in self.diff1D if the input is Diffractogram1D.
            print('bkg points saved in the calling object.')
        else:
            # If saveTXT argument True (default, but it could be changed),
            # the data are saved ALSO in TXT file (4 cols: X, Iraw, Ibkg, I).
            print(f'bkg points saved in: [{iplot.background.bname+".bp"}]')
    

def subtract_bkg_and_save(iplot):
    '''
    Function for keypress 't'.
    
    This is the final function which:
    
    * Recalculates recently defined background.
    * Calculates background-corrected data = subtracts bkg from data.
    * Saves results in TXT-file with 4 cols[X, Y=Iraw, Ibkg, I=(Iraw-Ibkg)].
    * If iplot.diff1D = ediff.io.Diffractogram1D object is defined,
      it is updated as well.
    '''
    # Subtract recently defined background and save results
    # (a) Calculate baseline = background curve
    # (the complete background is saved in iplot.background
    bfunc.calculate_baseline(iplot)
    # (b) Calculate complete data = X, Y=Iraw, Ibkg, I=(Iraw-Ibkg)
    # (the complete data are saved in iplot.data
    bfunc.calculate_bkg_data(iplot)
    # (c) Save the data to a TXT-file
    # (name of the ouput file is in iplot.pars.out_file
    # (the following functions tests this and save the data
    if iplot.pars.saveTXT is True: 
        bfunc.save_bkg_data(iplot)
    # (d) Save the data also to iplot.diff1D if it is defined
    # {diff1D} is a Diffractogram1D object from EDIFF package
    # {diff1D} can be used instead of data file to initialize iplot
    # {diff1D} is updated only if it was used = if iplot.diff1D is not None
    if iplot.diff1D is not None:
        iplot.diff1D['Ibkg'] = iplot.data[2]
        iplot.diff1D['I']    = iplot.data[3]
    # (e) Print final message if requested
    if iplot.pars.messages:
        if iplot.pars.saveTXT is False:
            # Data ALWAYS saved in self.data and self.background
            # and OPTIONALLY in self.diff1D if the input is Diffractogram1D.
            print('data saved in the calling object.')
        else:
            # If saveTXT argument True (default, but it could be changed),
            # the data are saved ALSO in TXT file (4 cols: X, Iraw, Ibkg, I).
            print(f'data saved in: [{iplot.pars.bkg_file}]')
            
            
def save_PNG_image(iplot):
    '''
    Function for keypress 's'.
    
    Special case - 's' is Matplotlib UI shortcut,
    which saves PNG image of the current (interactive) plot.
    
    As the {key_press_event} ~ 's' was NOT disconnected from the plot,
    the following two things are going to happen:
    
    * At first, the default event (saving as PNG) will take place.
    * At second, this function prints a message on stdout (if requested).
    '''
    
    # (1) If 's' was pressed the current plot is saved automatically.
    # (Note: default Matplotlib UI shortcut
    
    # (2) We just print the message that the plot was saved
    # (Note: we add the info about the recommended filename
    if iplot.pars.messages:
        print('plot saved to a PNG file.')


# =============================================================================
# Level 4: Auxiliary functions for the interactive plot


def initialize_interactive_plot_params():
    '''
    Initialize parameters of the interactive plot.
    '''
    plt.rcParams.update({
        'figure.figsize' : (6,4),
        'figure.dpi' : 100,
        'font.size' : 12,
        'lines.linewidth' : 1.0})
        

def print_brief_help(iplot):
    '''
    Print ultra-brief help before activating the interactive plot.
    
    Parameters
    ----------
    ppar : 
        It is used just to get the value of ppar.messages.
        If ppar.messages == True, additional empty line is printed.
        Reason: To separate the introductory help from the following messages.
    
    Returns
    -------
    None
        The output is the brief help printed on stdout.
    '''
    print('(0) Click on the newly-opened window {Background correction},')
    print('    which is a Matplotlib interative figure with extra shortcuts.')
    print('(1) Use Matplotlib UI + keyboard shortcuts to define a background:')
    print('    1,2 = add/delete a background point close to the mouse cursor')
    print('    3,4,5,6 = show bkg points + linear/quadratic/cubic background')
    print('(2) Save the results + close the window when you are done:')
    print('    a,b = read/save background points from/to BKG-file')
    print('    s,t = save background data in PNG-file/TXT-file-and-object')
    print('(3) Detailed help, complete documentation, and worked examples:')
    print('    https://mirekslouf.github.io/bground/docs')
    # Add an extra empty line if short messages to stdoud should be printed.
    if iplot.pars.messages: print()


def find_nearest(arr, value):
    '''
    Auxiliary function:
    Find the index of the element with the nearest {value} in 1D-array.
    
    Parameters
    ----------
    arr : 1D numpy array
        The array, in which we search the element with closest value.
        Important prerequisite: the array must be sorted.
    value : float
        The value, for which we search the closest element.

    Returns
    -------
    idx : int
        Index of the element with the closest value.
    '''
    # Find index of the element with nearest value in 1D-array.
    # Important prerequisite: the array must be sorted.
    # https://stackoverflow.com/q/2566412
    # 1) Key step = np.searchsorted
    idx = np.searchsorted(arr, value, side="left")
    # 2) finalization = consider special cases and return final value
    if idx > 0 and (
            idx == len(arr) or abs(value-arr[idx-1]) < abs(value-arr[idx])):
        return(idx-1)
    else:
        return(idx)


def clear_plot():
    '''
    Auxilliary function: clear interactive plot before re-drawing.
    
    Key feature of the function:
    It keeps current labels and XY-limits of the plot.
    '''
    my_xlabel = plt.gca().get_xlabel()
    my_ylabel = plt.gca().get_ylabel()
    my_xlim = plt.xlim()
    my_ylim = plt.ylim()
    plt.cla()
    plt.xlabel(my_xlabel)
    plt.ylabel(my_ylabel)
    plt.xlim(my_xlim)
    plt.ylim(my_ylim)
