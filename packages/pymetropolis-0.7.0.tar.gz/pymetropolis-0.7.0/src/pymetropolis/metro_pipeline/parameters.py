from datetime import time, timedelta
from pathlib import Path
from typing import Any, Generic, overload

from typing_extensions import TypeVar

from pymetropolis.metro_common.errors import error_context

from .config import Config
from .types import (
    Bool,
    CustomValidator,
    Duration,
    Enum,
    Float,
    Int,
    List,
    PathType,
    String,
    Time,
    Type,
)

T = TypeVar("T", default=Any)


class Parameter(Generic[T]):
    key: list[str]
    validator: Type
    description: str
    example: str
    note: str

    def __init__(
        self,
        key: str,
        validator: Type,
        default: Any = None,
        description: str = "",
        note: str = "",
        example: str = "",
    ):
        self.key = key.split(".")
        self.validator = validator
        self._value = None
        self.description = description
        self.note = note
        self.example = example
        if default is not None:
            self._value = self.validator.validate(default)

    def __str__(self) -> str:
        return ".".join(self.key)

    def _md_doc(self) -> str:
        key_str = ".".join(self.key)
        doc = f"### `{key_str}`\n\n"
        if self.description:
            doc += f"- **Description:** {self.description}\n"
        doc += f"- **Allowed values:** {self.validator._describe()}\n"
        if self.example:
            doc += f"- **Example:** {self.example}\n"
        if self.note:
            doc += f"- **Note:** {self.note}\n"
        return doc

    @overload
    def __get__(self, instance: None, owner: Any) -> "Parameter[T]": ...

    @overload
    def __get__(self, instance: Any, owner: Any) -> T: ...

    def __get__(self, instance: Any, owner: Any) -> Any:
        return self

    @error_context("Cannot validate parameter `{}`", fmt_args=[0])
    def from_config(self, config: Config) -> T | None:
        x = config.dict
        for k in self.key:
            if k in x:
                x = x[k]
            else:
                # The key is not defined in the config.
                break
        else:
            # At this point, the key was found and `x` is equal to its value.
            self._value = self.validator.validate(x)
        return self._value


class CustomParameter(Parameter):
    def __init__(self, *args, validator, **kwargs):
        kwargs["validator"] = CustomValidator(
            fn=validator, description=kwargs.pop("validator_description")
        )
        super().__init__(*args, **kwargs)


class BoolParameter(Parameter[bool]):
    def __init__(self, *args, **kwargs):
        kwargs["validator"] = Bool()
        super().__init__(*args, **kwargs)


class IntParameter(Parameter[int]):
    def __init__(self, *args, **kwargs):
        kwargs["validator"] = Int()
        super().__init__(*args, **kwargs)


class FloatParameter(Parameter[float]):
    def __init__(
        self, *args, lower_bound: float | None = None, upper_bound: float | None = None, **kwargs
    ):
        kwargs["validator"] = Float(lb=lower_bound, ub=upper_bound)
        super().__init__(*args, **kwargs)


class FractionParameter(FloatParameter):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, lower_bound=0.0, upper_bound=1.0, **kwargs)


class StringParameter(Parameter[str]):
    def __init__(self, *args, **kwargs):
        kwargs["validator"] = String()
        super().__init__(*args, **kwargs)


class TimeParameter(Parameter[time]):
    def __init__(self, *args, **kwargs):
        kwargs["validator"] = Time()
        super().__init__(*args, **kwargs)


class DurationParameter(Parameter[timedelta]):
    def __init__(self, *args, **kwargs):
        kwargs["validator"] = Duration()
        super().__init__(*args, **kwargs)


class EnumParameter(Parameter[Any]):
    def __init__(self, *args, values: list[Any], **kwargs):
        kwargs["validator"] = Enum(values=values)
        super().__init__(*args, **kwargs)


class PathParameter(Parameter[Path]):
    def __init__(
        self,
        *args,
        check_file_exists: bool = False,
        check_dir_exists: bool = False,
        extensions: list[str] | None = None,
        **kwargs,
    ):
        kwargs["validator"] = PathType(
            check_file_exists=check_file_exists,
            check_dir_exists=check_dir_exists,
            extensions=extensions,
        )
        super().__init__(*args, **kwargs)


class ListParameter(Parameter[list[Any]]):
    def __init__(
        self,
        *args,
        inner: Type,
        length: int | None = None,
        min_length: int | None = None,
        max_length: int | None = None,
        **kwargs,
    ):
        kwargs["validator"] = List(inner, length, min_length, max_length)
        super().__init__(*args, **kwargs)
