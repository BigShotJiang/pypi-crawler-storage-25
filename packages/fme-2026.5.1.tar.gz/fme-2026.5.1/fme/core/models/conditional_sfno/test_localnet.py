import os

import pytest
import torch
from torch import nn

from fme.core.device import get_device
from fme.core.testing.regression import validate_tensor

from .layers import Context, ContextConfig
from .localnet import LocalNetConfig, get_lat_lon_localnet
from .sfnonet import DiscreteContinuousConvS2, _compute_cutoff_radius

DIR = os.path.dirname(os.path.abspath(__file__))


@pytest.mark.parametrize(
    "conditional_embed_dim_scalar, conditional_embed_dim_labels, "
    "conditional_embed_dim_noise, "
    "conditional_embed_dim_pos",
    [
        (0, 0, 0, 0),
        (16, 8, 0, 0),
        (16, 0, 16, 0),
        (16, 15, 14, 13),
        (0, 0, 0, 16),
        (0, 0, 16, 0),
    ],
)
def test_can_call_localnet_disco(
    conditional_embed_dim_scalar: int,
    conditional_embed_dim_labels: int,
    conditional_embed_dim_noise: int,
    conditional_embed_dim_pos: int,
):
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 4
    device = get_device()
    params = LocalNetConfig(
        embed_dim=16,
        block_types=["disco", "disco"],
    )
    model = get_lat_lon_localnet(
        params=params,
        img_shape=img_shape,
        in_chans=input_channels,
        out_chans=output_channels,
        context_config=ContextConfig(
            embed_dim_scalar=conditional_embed_dim_scalar,
            embed_dim_labels=conditional_embed_dim_labels,
            embed_dim_noise=conditional_embed_dim_noise,
            embed_dim_pos=conditional_embed_dim_pos,
        ),
    ).to(device)
    x = torch.randn(n_samples, input_channels, *img_shape, device=device)
    context_embedding = torch.randn(
        n_samples, conditional_embed_dim_scalar, device=device
    )
    context_embedding_labels = torch.randn(
        n_samples, conditional_embed_dim_labels, device=device
    )
    context_embedding_noise = torch.randn(
        n_samples, conditional_embed_dim_noise, *img_shape, device=device
    )
    context_embedding_pos = torch.randn(
        n_samples, conditional_embed_dim_pos, *img_shape, device=device
    )
    context = Context(
        embedding_scalar=context_embedding,
        labels=context_embedding_labels,
        noise=context_embedding_noise,
        embedding_pos=context_embedding_pos,
    )
    output = model(x, context)
    assert output.shape == (n_samples, output_channels, *img_shape)


def test_can_call_localnet_conv1x1():
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 4
    device = get_device()
    params = LocalNetConfig(
        embed_dim=16,
        block_types=["conv1x1", "conv1x1"],
    )
    model = get_lat_lon_localnet(
        params=params,
        img_shape=img_shape,
        in_chans=input_channels,
        out_chans=output_channels,
    ).to(device)
    x = torch.randn(n_samples, input_channels, *img_shape, device=device)
    context = Context(
        embedding_scalar=torch.randn(n_samples, 0, device=device),
        labels=torch.randn(n_samples, 0, device=device),
        noise=torch.randn(n_samples, 0, *img_shape, device=device),
        embedding_pos=torch.randn(n_samples, 0, *img_shape, device=device),
    )
    output = model(x, context)
    assert output.shape == (n_samples, output_channels, *img_shape)


def test_can_call_localnet_mixed_blocks():
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 4
    device = get_device()
    params = LocalNetConfig(
        embed_dim=16,
        block_types=["disco", "conv1x1", "disco", "conv1x1"],
    )
    model = get_lat_lon_localnet(
        params=params,
        img_shape=img_shape,
        in_chans=input_channels,
        out_chans=output_channels,
    ).to(device)
    x = torch.randn(n_samples, input_channels, *img_shape, device=device)
    context = Context(
        embedding_scalar=torch.randn(n_samples, 0, device=device),
        labels=torch.randn(n_samples, 0, device=device),
        noise=torch.randn(n_samples, 0, *img_shape, device=device),
        embedding_pos=torch.randn(n_samples, 0, *img_shape, device=device),
    )
    output = model(x, context)
    assert output.shape == (n_samples, output_channels, *img_shape)


@pytest.mark.parametrize("normalize_big_skip", [True, False])
def test_all_inputs_get_layer_normed(normalize_big_skip: bool):
    torch.manual_seed(0)
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 4
    conditional_embed_dim_scalar = 8
    conditional_embed_dim_noise = 16
    conditional_embed_dim_labels = 3
    conditional_embed_dim_pos = 12
    device = get_device()

    class SetToZero(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def forward(self, x):
            return torch.zeros_like(x)

    original_layer_norm = nn.LayerNorm
    try:
        nn.LayerNorm = SetToZero
        params = LocalNetConfig(
            embed_dim=16,
            block_types=["disco", "disco"],
            normalize_big_skip=normalize_big_skip,
            global_layer_norm=True,  # so it uses nn.LayerNorm
        )
        model = get_lat_lon_localnet(
            params=params,
            img_shape=img_shape,
            in_chans=input_channels,
            out_chans=output_channels,
            context_config=ContextConfig(
                embed_dim_scalar=conditional_embed_dim_scalar,
                embed_dim_noise=conditional_embed_dim_noise,
                embed_dim_labels=conditional_embed_dim_labels,
                embed_dim_pos=conditional_embed_dim_pos,
            ),
        ).to(device)
    finally:
        nn.LayerNorm = original_layer_norm
    x = torch.full((n_samples, input_channels, *img_shape), torch.nan).to(device)
    context_embedding = torch.randn(n_samples, conditional_embed_dim_scalar).to(device)
    context_embedding_noise = torch.randn(
        n_samples, conditional_embed_dim_noise, *img_shape
    ).to(device)
    context_embedding_labels = torch.randn(n_samples, conditional_embed_dim_labels).to(
        device
    )
    context_embedding_pos = torch.randn(
        n_samples, conditional_embed_dim_pos, *img_shape
    ).to(device)
    context = Context(
        embedding_scalar=context_embedding,
        embedding_pos=context_embedding_pos,
        noise=context_embedding_noise,
        labels=context_embedding_labels,
    )
    with torch.no_grad():
        output = model(x, context)
    if normalize_big_skip:
        assert not torch.isnan(output).any()
    else:
        assert torch.isnan(output).any()


def test_no_big_skip():
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 4
    device = get_device()
    params = LocalNetConfig(
        embed_dim=16,
        block_types=["disco", "disco"],
        big_skip=False,
    )
    model = get_lat_lon_localnet(
        params=params,
        img_shape=img_shape,
        in_chans=input_channels,
        out_chans=output_channels,
    ).to(device)
    x = torch.randn(n_samples, input_channels, *img_shape, device=device)
    context = Context(
        embedding_scalar=torch.randn(n_samples, 0, device=device),
        labels=torch.randn(n_samples, 0, device=device),
        noise=torch.randn(n_samples, 0, *img_shape, device=device),
        embedding_pos=torch.randn(n_samples, 0, *img_shape, device=device),
    )
    output = model(x, context)
    assert output.shape == (n_samples, output_channels, *img_shape)


@pytest.mark.parametrize(
    "kernel_shape, basis_type",
    [
        ((1, 1), "morlet"),
        ((5, 1), "morlet"),
        ((3, 5), "morlet"),
        ((3, 3), "piecewise linear"),
        ((3, 1), "piecewise linear"),
    ],
)
def test_can_call_localnet_with_kernel_shape(kernel_shape, basis_type):
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 4
    device = get_device()
    params = LocalNetConfig(
        embed_dim=16,
        kernel_shape=kernel_shape,
        basis_type=basis_type,
        block_types=["disco", "disco"],
    )
    model = get_lat_lon_localnet(
        params=params,
        img_shape=img_shape,
        in_chans=input_channels,
        out_chans=output_channels,
    ).to(device)
    x = torch.randn(n_samples, input_channels, *img_shape, device=device)
    context = Context(
        embedding_scalar=torch.randn(n_samples, 0, device=device),
        labels=torch.randn(n_samples, 0, device=device),
        noise=torch.randn(n_samples, 0, *img_shape, device=device),
        embedding_pos=torch.randn(n_samples, 0, *img_shape, device=device),
    )
    output = model(x, context)
    assert output.shape == (n_samples, output_channels, *img_shape)


def test_isotropic_disco_conv_commutes_with_latitude_reflection():
    """An isotropic DISCO conv must commute with latitude reflection.

    Latitude reflection (θ → π−θ) is an isometry of the sphere that maps
    equiangular grid points exactly onto other grid points.  For an
    isotropic filter the convolution kernel depends only on geodesic
    distance, which is preserved by the reflection, so
    ``flip(conv(x)) == conv(flip(x))``.  An anisotropic filter also
    depends on the local azimuthal angle, which the reflection reverses,
    so the equality generally fails.
    """
    torch.manual_seed(0)
    img_shape = (16, 32)
    embed_dim = 4
    kernel_shape = (3, 3)
    data_grid = "equiangular"
    lat_dim = 2  # dimension index for latitude in (batch, channel, lat, lon)

    def make_disco_conv(basis_type):
        theta_cutoff = 2 * _compute_cutoff_radius(
            nlat=img_shape[0],
            kernel_shape=kernel_shape,
            basis_type=basis_type,
        )
        return DiscreteContinuousConvS2(
            embed_dim,
            embed_dim,
            in_shape=img_shape,
            out_shape=img_shape,
            kernel_shape=kernel_shape,
            basis_type=basis_type,
            basis_norm_mode="mean",
            groups=1,
            grid_in=data_grid,
            grid_out=data_grid,
            bias=False,
            theta_cutoff=theta_cutoff,
        )

    x = torch.randn(1, embed_dim, *img_shape)
    x_flipped = torch.flip(x, dims=[lat_dim])

    # Isotropic basis: convolution must commute with the reflection.
    iso_conv = make_disco_conv("isotropic morlet")
    with torch.no_grad():
        out, _ = iso_conv(x)
        out_from_flipped, _ = iso_conv(x_flipped)
    torch.testing.assert_close(
        torch.flip(out, dims=[lat_dim]),
        out_from_flipped,
    )

    # Anisotropic basis: convolution should NOT commute (random weights
    # activate the azimuthal modes that break the symmetry).
    aniso_conv = make_disco_conv("morlet")
    with torch.no_grad():
        out, _ = aniso_conv(x)
        out_from_flipped, _ = aniso_conv(x_flipped)
    assert not torch.allclose(
        torch.flip(out, dims=[lat_dim]),
        out_from_flipped,
        atol=1e-5,
    )


def test_unknown_filter_type_raises():
    with pytest.raises(ValueError, match="Invalid block type"):
        LocalNetConfig(block_types=["spectral"])  # type: ignore[list-item]


def test_backward_pass():
    """Test that gradients flow through the network."""
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 2
    device = get_device()
    params = LocalNetConfig(
        embed_dim=16,
        block_types=["disco", "disco"],
    )
    model = get_lat_lon_localnet(
        params=params,
        img_shape=img_shape,
        in_chans=input_channels,
        out_chans=output_channels,
    ).to(device)
    x = torch.randn(n_samples, input_channels, *img_shape, device=device)
    context = Context(
        embedding_scalar=torch.randn(n_samples, 0, device=device),
        labels=torch.randn(n_samples, 0, device=device),
        noise=torch.randn(n_samples, 0, *img_shape, device=device),
        embedding_pos=torch.randn(n_samples, 0, *img_shape, device=device),
    )
    output = model(x, context)
    loss = output.sum()
    loss.backward()
    for name, param in model.named_parameters():
        assert param.grad is not None, f"No gradient for {name}"


def setup_localnet():
    input_channels = 2
    output_channels = 3
    img_shape = (9, 18)
    n_samples = 4
    device = get_device()
    params = LocalNetConfig(
        embed_dim=16,
        block_types=["disco", "disco"],
    )
    model = get_lat_lon_localnet(
        params=params,
        img_shape=img_shape,
        in_chans=input_channels,
        out_chans=output_channels,
    ).to(device)
    # must initialize on CPU to get the same results on GPU
    x = torch.randn(n_samples, input_channels, *img_shape).to(device)
    context = Context(
        embedding_scalar=torch.randn(n_samples, 0).to(device),
        labels=torch.randn(n_samples, 0).to(device),
        noise=torch.randn(n_samples, 0, *img_shape).to(device),
        embedding_pos=torch.randn(n_samples, 0, *img_shape).to(device),
    )
    return model, x, context


def test_localnet_output_is_unchanged():
    torch.manual_seed(0)
    model, x, context = setup_localnet()
    with torch.no_grad():
        output = model(x, context)
    validate_tensor(
        output,
        os.path.join(DIR, "testdata/test_localnet_output.pt"),
    )
