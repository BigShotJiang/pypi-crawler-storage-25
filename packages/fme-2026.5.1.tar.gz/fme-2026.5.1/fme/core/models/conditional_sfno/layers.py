# flake8: noqa
# Copied from https://github.com/ai2cm/modulus/commit/22df4a9427f5f12ff6ac891083220e7f2f54d229
# Copyright (c) 2023, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import dataclasses
from typing import Tuple

import torch
import torch.fft
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from fme.core.benchmark.timer import Timer, NullTimer
from fme.core.models.conditional_sfno.lora import LoRAConv2d

from .activations import ComplexReLU
from .contractions import compl_mul2d_fwd, compl_muladd2d_fwd


@dataclasses.dataclass
class ContextConfig:
    """
    Configuration for the context.
    """

    embed_dim_scalar: int
    embed_dim_labels: int
    embed_dim_noise: int
    embed_dim_pos: int


@dataclasses.dataclass
class Context:
    """
    Context for the conditional layer normalization.

    Parameters:
        embedding_scalar: The scalar embedding to condition on. The
            last dimension is the channel dimension.
        embedding_pos: The positional embedding to condition on. The last
            three dimensions are (channels, height, width).
        labels: The labels to condition on, of shape (batch_size, n_labels).
        noise: The 2D noise embedding to condition on. The last
            three dimensions are (channels, height, width).
    """

    embedding_scalar: torch.Tensor | None
    embedding_pos: torch.Tensor | None
    labels: torch.Tensor | None
    noise: torch.Tensor | None

    def __post_init__(self):
        if (
            self.embedding_scalar is not None
            and self.noise is not None
            and self.noise.ndim != self.embedding_scalar.ndim + 2
        ):
            raise ValueError("noise must have 2 more dimensions than embedding_scalar")
        if self.labels is not None and self.labels.ndim != 2:
            raise ValueError("labels must have 2 dimensions")

    def asdict(self) -> dict[str, torch.Tensor | None]:
        return {
            "embedding_scalar": self.embedding_scalar,
            "embedding_pos": self.embedding_pos,
            "labels": self.labels,
            "noise": self.noise,
        }

    @classmethod
    def from_dict(cls, data: dict[str, torch.Tensor | None]) -> "Context":
        return cls(
            embedding_scalar=data.get("embedding_scalar"),
            embedding_pos=data.get("embedding_pos"),
            labels=data.get("labels"),
            noise=data.get("noise"),
        )


class ChannelLayerNorm(nn.Module):
    """
    Layer Normalization over third-last channel dimension.
    """

    def __init__(
        self, n_channels: int, eps: float = 1e-5, elementwise_affine: bool = False
    ):
        super(ChannelLayerNorm, self).__init__()
        self.n_channels = n_channels
        self.eps = eps
        self.elementwise_affine = elementwise_affine
        if self.elementwise_affine:
            self.weight = nn.Parameter(torch.ones(n_channels))
            self.bias = nn.Parameter(torch.zeros(n_channels))
        else:
            self.weight = None
            self.bias = None
        self.reset_parameters()

    def reset_parameters(self):
        if self.elementwise_affine:
            torch.nn.init.constant_(self.weight, 1.0)
            torch.nn.init.constant_(self.bias, 0.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() < 2:
            raise ValueError(
                f"Expected at least 3D input with channel at dim=-3, got shape {tuple(x.shape)}"
            )
        if x.size(-3) != self.n_channels:
            raise ValueError(
                f"Channel dimension mismatch: got C={x.size(-3)}, expected {self.n_channels}"
            )

        # Compute per-pixel mean/var across channels without transposing
        mean = x.mean(dim=-3, keepdim=True)
        var = x.var(dim=-3, keepdim=True, unbiased=False)
        inv_std = torch.rsqrt(var + self.eps)
        y = (x - mean) * inv_std

        if self.weight is not None and self.bias is not None:
            # Broadcast [C] over [N, C, *spatial]
            shape = [1, -1] + [1] * (x.dim() - 2)
            y = y * self.weight.view(*shape) + self.bias.view(*shape)
        return y


class ConditionalLayerNorm(nn.Module):
    """
    Conditional Layer Normalization as described in "AdaSpeech: Adaptive
    Text to Speech for Custom Voice" https://arxiv.org/abs/2103.00993.

    Assumes that the input has shape (batch_size, channels, height, width).
    """

    def __init__(
        self,
        n_channels: int,
        img_shape: Tuple[int, int],
        context_config: ContextConfig,
        global_layer_norm: bool = False,
        epsilon: float = 1e-5,
        elementwise_affine: bool = False,
    ):
        super(ConditionalLayerNorm, self).__init__()
        self.n_channels = n_channels
        self.embed_dim_scalar = context_config.embed_dim_scalar
        self.embed_dim_labels = context_config.embed_dim_labels
        self.embed_dim_pos = context_config.embed_dim_pos
        self.embed_dim_noise = context_config.embed_dim_noise
        self.epsilon = epsilon
        if self.embed_dim_scalar > 0:
            self.W_scale: nn.Linear | None = nn.Linear(
                self.embed_dim_scalar, self.n_channels
            )
            self.W_bias: nn.Linear | None = nn.Linear(
                self.embed_dim_scalar, self.n_channels
            )
        else:
            self.W_scale = None
            self.W_bias = None
        if self.embed_dim_labels > 0:
            self.W_scale_labels = nn.Linear(self.embed_dim_labels, self.n_channels)
            self.W_bias_labels = nn.Linear(self.embed_dim_labels, self.n_channels)
        else:
            self.W_scale_labels = None
            self.W_bias_labels = None
        if self.embed_dim_noise > 0:
            # no bias as it is already handled in the non-2d layers
            self.W_scale_2d = nn.Conv2d(
                self.embed_dim_noise, self.n_channels, kernel_size=1, bias=False
            )
            self.W_bias_2d = nn.Conv2d(
                self.embed_dim_noise, self.n_channels, kernel_size=1, bias=False
            )
        else:
            self.W_scale_2d = None
            self.W_bias_2d = None
        if self.embed_dim_pos > 0:
            # no bias as it is already handled in the non-2d layers
            self.W_scale_pos = nn.Conv2d(
                self.embed_dim_pos, self.n_channels, kernel_size=1, bias=False
            )
            self.W_bias_pos = nn.Conv2d(
                self.embed_dim_pos, self.n_channels, kernel_size=1, bias=False
            )
        else:
            self.W_scale_pos = None
            self.W_bias_pos = None
        if global_layer_norm:
            self.norm = nn.LayerNorm(
                (self.n_channels, img_shape[0], img_shape[1]),
                eps=epsilon,
                elementwise_affine=elementwise_affine,
            )
        else:
            self.norm = ChannelLayerNorm(
                self.n_channels,
                eps=epsilon,
                elementwise_affine=elementwise_affine,
            )
        self._global_layer_norm = global_layer_norm
        self.reset_parameters()

    def reset_parameters(self):
        if self.W_scale is not None:
            torch.nn.init.constant_(self.W_scale.weight, 0.0)
            torch.nn.init.constant_(self.W_scale.bias, 1.0)
        if self.W_bias is not None:
            torch.nn.init.constant_(self.W_bias.weight, 0.0)
            torch.nn.init.constant_(self.W_bias.bias, 0.0)
        if self.W_scale_labels is not None:
            torch.nn.init.constant_(self.W_scale_labels.weight, 0.0)
            # bias starts at 1 for the first scale, we don't want to add more.
            torch.nn.init.constant_(self.W_scale_labels.bias, 0.0)
        if self.W_bias_labels is not None:
            torch.nn.init.constant_(self.W_bias_labels.weight, 0.0)
            torch.nn.init.constant_(self.W_bias_labels.bias, 0.0)
        # no bias on 2d layers as it is already handled in the non-2d layers
        if self.W_scale_2d is not None:
            torch.nn.init.constant_(self.W_scale_2d.weight, 0.0)
        if self.W_bias_2d is not None:
            torch.nn.init.constant_(self.W_bias_2d.weight, 0.0)
        if self.W_scale_pos is not None:
            torch.nn.init.constant_(self.W_scale_pos.weight, 0.0)
        if self.W_bias_pos is not None:
            torch.nn.init.constant_(self.W_bias_pos.weight, 0.0)
        # no bias on 2d layers as it is already handled in the non-2d layers

    def forward(
        self,
        x: torch.Tensor,
        context: Context,
        timer: Timer = NullTimer(),
    ) -> torch.Tensor:
        """
        Conditional Layer Normalization

        This is a modified version of LayerNorm that allows the scale and bias to be
        conditioned on a context embedding.

        Args:
            x: The input tensor to normalize, of shape
                (batch_size, channels, height, width).
            context: The context to condition on.

        Returns:
            The normalized tensor, of shape (batch_size, channels, height, width).
        """
        if context.labels is None and (
            self.W_scale_labels is not None or self.W_bias_labels is not None
        ):
            raise ValueError("labels must be provided")
        with timer.child("compute_scaling_and_bias"):
            if self.W_scale is not None:
                if context.embedding_scalar is None:
                    raise ValueError("embedding_scalar must be provided")
                scale: torch.Tensor = (
                    self.W_scale(context.embedding_scalar).unsqueeze(-1).unsqueeze(-1)
                )
            else:
                scale = torch.ones(
                    list(x.shape[:-2]) + [1, 1], device=x.device, dtype=x.dtype
                )

            if self.W_scale_2d is not None:
                if context.noise is None:
                    raise ValueError("embedding_2d must be provided")
                scale = scale + self.W_scale_2d(context.noise)
            if self.W_bias is not None:
                if context.embedding_scalar is None:
                    raise ValueError("embedding_scalar must be provided")
                bias: torch.Tensor = (
                    self.W_bias(context.embedding_scalar).unsqueeze(-1).unsqueeze(-1)
                )
            else:
                bias = torch.zeros(
                    list(x.shape[:-2]) + [1, 1], device=x.device, dtype=x.dtype
                )

            if self.W_scale_labels is not None:
                scale = scale + self.W_scale_labels(context.labels).unsqueeze(
                    -1
                ).unsqueeze(-1)
            if self.W_bias_labels is not None:
                bias = bias + self.W_bias_labels(context.labels).unsqueeze(
                    -1
                ).unsqueeze(-1)
            if self.W_bias_2d is not None:
                if context.noise is None:
                    raise ValueError("embedding_2d must be provided")
                bias = bias + self.W_bias_2d(context.noise)
            if self.W_scale_pos is not None:
                if context.embedding_pos is None:
                    raise ValueError("embedding_pos must be provided")
                scale = scale + self.W_scale_pos(context.embedding_pos)
            if self.W_bias_pos is not None:
                if context.embedding_pos is None:
                    raise ValueError("embedding_pos must be provided")
                bias = bias + self.W_bias_pos(context.embedding_pos)
        with timer.child("normalize"):
            x_norm: torch.Tensor = self.norm(x)
        with timer.child("apply_scaling_and_bias"):
            return_value = x_norm * scale + bias
        return return_value


@torch.jit.script
def drop_path(
    x: torch.Tensor, drop_prob: float = 0.0, training: bool = False
) -> torch.Tensor:  # pragma: no cover
    """Drop paths (Stochastic Depth) per sample (when applied in main path of
    residual blocks).
    This is the same as the DropConnect impl for EfficientNet, etc networks, however,
    the original name is misleading as 'Drop Connect' is a different form of dropout in
    a separate paper. See discussion:
        https://github.com/tensorflow/tpu/issues/494#issuecomment-532968956
    We've opted for changing the layer and argument names to 'drop path' rather than
    mix DropConnect as a layer name and use 'survival rate' as the argument.
    """
    if drop_prob == 0.0 or not training:
        return x
    keep_prob = 1.0 - drop_prob
    shape = (x.shape[0],) + (1,) * (
        x.ndim - 1
    )  # work with diff dim tensors, not just 2d ConvNets
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    random_tensor.floor_()  # binarize
    output = x.div(keep_prob) * random_tensor
    return output


class DropPath(nn.Module):
    """
    Drop paths (Stochastic Depth) per sample (when applied in main path of residual
    blocks).
    """

    def __init__(self, drop_prob=None):  # pragma: no cover
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):  # pragma: no cover
        return drop_path(x, self.drop_prob, self.training)


class MLP(nn.Module):
    """
    Basic CNN with support for gradient checkpointing
    """

    def __init__(
        self,
        in_features,
        hidden_features=None,
        out_features=None,
        act_layer=nn.GELU,
        output_bias=True,
        drop_rate=0.0,
        checkpointing=0,
        lora_rank: int = 0,
        lora_alpha: float | None = None,
    ):  # pragma: no cover
        super(MLP, self).__init__()
        self.checkpointing = checkpointing
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        fc1 = LoRAConv2d(
            in_features,
            hidden_features,
            1,
            bias=True,
            lora_rank=lora_rank,
            lora_alpha=lora_alpha,
        )
        act = act_layer()
        fc2 = LoRAConv2d(
            hidden_features,
            out_features,
            1,
            bias=output_bias,
            lora_rank=lora_rank,
            lora_alpha=lora_alpha,
        )
        if drop_rate > 0.0:
            drop = nn.Dropout(drop_rate)
            self.fwd = nn.Sequential(fc1, act, drop, fc2, drop)
        else:
            self.fwd = nn.Sequential(fc1, act, fc2)

        # by default, all weights are shared

    @torch.jit.ignore
    def checkpoint_forward(self, x):  # pragma: no cover
        """Forward method with support for gradient checkpointing"""
        return checkpoint(self.fwd, x)

    def forward(self, x):  # pragma: no cover
        if self.checkpointing >= 2:
            return self.checkpoint_forward(x)
        else:
            return self.fwd(x)


class SpectralAttentionS2(nn.Module):
    """
    geometrical Spectral Attention layer
    """

    def __init__(
        self,
        forward_transform,
        inverse_transform,
        embed_dim,
        sparsity_threshold=0.0,
        hidden_size_factor=2,
        use_complex_network=True,
        use_complex_kernels=False,
        complex_activation="real",
        bias=False,
        spectral_layers=1,
        drop_rate=0.0,
    ):  # pragma: no cover
        super(SpectralAttentionS2, self).__init__()

        self.embed_dim = embed_dim
        self.sparsity_threshold = sparsity_threshold
        self.hidden_size = int(hidden_size_factor * self.embed_dim)
        self.scale = 0.02
        if use_complex_kernels:
            raise NotImplementedError("complex kernels not supported")
        self.mul_add_handle = compl_muladd2d_fwd
        self.mul_handle = compl_mul2d_fwd
        self.spectral_layers = spectral_layers

        self.modes_lat = forward_transform.lmax
        self.modes_lon = forward_transform.mmax

        # only storing the forward handle to be able to call it
        self.forward_transform = forward_transform.forward
        self.inverse_transform = inverse_transform.forward

        assert inverse_transform.lmax == self.modes_lat
        assert inverse_transform.mmax == self.modes_lon

        # weights
        w = [self.scale * torch.randn(self.embed_dim, self.hidden_size, 2)]
        # w = [self.scale * torch.randn(self.embed_dim + 4*self.embed_freqs, self.hidden_size, 2)]
        for l in range(1, self.spectral_layers):
            w.append(self.scale * torch.randn(self.hidden_size, self.hidden_size, 2))
        self.w = nn.ParameterList(w)

        if bias:
            self.b = nn.ParameterList(
                [
                    self.scale * torch.randn(2 * self.hidden_size, 1, 1, 2)
                    for _ in range(self.spectral_layers)
                ]
            )

        self.wout = nn.Parameter(
            self.scale * torch.randn(self.hidden_size, self.embed_dim, 2)
        )

        self.drop = nn.Dropout(drop_rate) if drop_rate > 0.0 else nn.Identity()

        self.activation = ComplexReLU(
            mode=complex_activation, bias_shape=(self.hidden_size, 1, 1)
        )

    def forward_mlp(self, xr):  # pragma: no cover
        """forward method for the MLP part of the network"""
        for l in range(self.spectral_layers):
            if hasattr(self, "b"):
                xr = self.mul_add_handle(
                    xr, self.w[l].to(xr.dtype), self.b[l].to(xr.dtype)
                )
            else:
                xr = self.mul_handle(xr, self.w[l].to(xr.dtype))
            xr = torch.view_as_complex(xr)
            xr = self.activation(xr)
            xr = self.drop(xr)
            xr = torch.view_as_real(xr)

        # final MLP
        xr = self.mul_handle(xr, self.wout)

        return xr

    def forward(self, x):  # pragma: no cover
        dtype = x.dtype
        # x = x.to(torch.float32)

        # FWD transform
        with torch.amp.autocast("cuda", enabled=False):
            x = x.to(torch.float32)
            x = x.contiguous()
            x = self.forward_transform(x)
            x = torch.view_as_real(x)

        # MLP
        x = self.forward_mlp(x)

        # BWD transform
        with torch.amp.autocast("cuda", enabled=False):
            x = torch.view_as_complex(x)
            x = x.contiguous()
            x = self.inverse_transform(x)
            x = x.to(dtype)

        return x
