from .mlp import MLPConfig
