import dataclasses
import datetime
import pathlib
import tempfile
import unittest
import unittest.mock
from collections.abc import Callable

import dacite
import pytest
import torch
from torch import nn

import fme
from fme.ace.registry.stochastic_sfno import NoiseConditionedSFNOBuilder
from fme.ace.step.fcn3 import FCN3Config, FCN3Selector, FCN3StepConfig
from fme.ace.testing.fv3gfs_data import get_scalar_dataset
from fme.core.coordinates import HybridSigmaPressureCoordinate, LatLonCoordinates
from fme.core.corrector.atmosphere import AtmosphereCorrectorConfig, EnergyBudgetConfig
from fme.core.dataset_info import DatasetInfo
from fme.core.distributed.distributed import Distributed
from fme.core.distributed.non_distributed import DummyWrapper
from fme.core.labels import BatchLabels
from fme.core.normalizer import NetworkAndLossNormalizationConfig, NormalizationConfig
from fme.core.registry import ModuleSelector
from fme.core.step.args import StepArgs
from fme.core.step.multi_call import MultiCallConfig, MultiCallStepConfig
from fme.core.step.secondary_decoder import SecondaryDecoderConfig
from fme.core.step.secondary_module import SecondaryModuleStepConfig
from fme.core.step.single_module import SingleModuleStepConfig
from fme.core.step.step import StepABC, StepSelector
from fme.core.typing_ import TensorDict

from .radiation import SeparateRadiationStepConfig

DEFAULT_IMG_SHAPE = (45, 90)


def get_network_and_loss_normalization_config(
    names: list[str],
    dir: pathlib.Path | None = None,
) -> NetworkAndLossNormalizationConfig:
    if dir is None:
        return NetworkAndLossNormalizationConfig(
            network=NormalizationConfig(
                means={name: 0.0 for name in names},
                stds={name: 1.0 for name in names},
            ),
        )
    else:
        return NetworkAndLossNormalizationConfig(
            network=NormalizationConfig(
                global_means_path=dir / "means.nc",
                global_stds_path=dir / "stds.nc",
            ),
        )


def get_separate_radiation_config(
    dir: pathlib.Path | None = None,
) -> SeparateRadiationStepConfig:
    normalization = get_network_and_loss_normalization_config(
        names=[
            "prog_a",
            "prog_b",
            "forcing_shared",
            "forcing_rad",
            "diagnostic_rad",
            "diagnostic_main",
        ],
        dir=dir,
    )

    return SeparateRadiationStepConfig(
        builder=ModuleSelector(
            type="SphericalFourierNeuralOperatorNet",
            config={
                "scale_factor": 1,
                "embed_dim": 4,
                "num_layers": 2,
            },
        ),
        radiation_builder=ModuleSelector(
            type="SphericalFourierNeuralOperatorNet",
            config={
                "scale_factor": 1,
                "embed_dim": 4,
                "num_layers": 2,
            },
        ),
        main_prognostic_names=["prog_a", "prog_b"],
        shared_forcing_names=["forcing_shared"],
        radiation_only_forcing_names=["forcing_rad"],
        radiation_diagnostic_names=["diagnostic_rad"],
        main_diagnostic_names=["diagnostic_main"],
        normalization=normalization,
    )


def get_separate_radiation_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    return StepSelector(
        type="separate_radiation",
        config=dataclasses.asdict(get_separate_radiation_config(dir)),
    )


def get_single_module_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    normalization = get_network_and_loss_normalization_config(
        names=[
            "forcing_shared",
            "forcing_rad",
            "diagnostic_main",
            "diagnostic_rad",
        ],
        dir=dir,
    )
    return StepSelector(
        type="single_module",
        config=dataclasses.asdict(
            SingleModuleStepConfig(
                builder=ModuleSelector(
                    type="SphericalFourierNeuralOperatorNet",
                    config={
                        "scale_factor": 1,
                        "embed_dim": 4,
                        "num_layers": 2,
                    },
                ),
                in_names=["forcing_shared", "forcing_rad"],
                out_names=["diagnostic_main", "diagnostic_rad"],
                normalization=normalization,
            ),
        ),
    )


def get_single_module_noise_conditioned_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    normalization = get_network_and_loss_normalization_config(
        names=[
            "forcing_shared",
            "forcing_rad",
            "diagnostic_main",
            "diagnostic_rad",
        ],
        dir=dir,
    )
    return StepSelector(
        type="single_module",
        config=dataclasses.asdict(
            SingleModuleStepConfig(
                builder=ModuleSelector(
                    type="NoiseConditionedSFNO",
                    config=dataclasses.asdict(
                        NoiseConditionedSFNOBuilder(
                            embed_dim=4,
                            noise_embed_dim=4,
                            noise_type="isotropic",
                            filter_type="linear",
                            filter_num_groups=2,
                            context_pos_embed_dim=2,
                            pos_embed=False,
                            num_layers=2,
                            local_blocks=[0],
                            affine_norms=True,
                        )
                    ),
                ),
                in_names=["forcing_shared", "forcing_rad"],
                out_names=["diagnostic_main"],
                secondary_decoder=SecondaryDecoderConfig(
                    secondary_diagnostic_names=["diagnostic_rad"],
                    network=ModuleSelector(type="MLP", config={}),
                ),
                normalization=normalization,
            ),
        ),
    )


def get_label_conditioned_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    normalization = get_network_and_loss_normalization_config(
        names=[
            "forcing_shared",
            "forcing_rad",
            "diagnostic_main",
            "diagnostic_rad",
        ],
        dir=dir,
    )
    return StepSelector(
        type="single_module",
        config=dataclasses.asdict(
            SingleModuleStepConfig(
                builder=ModuleSelector(
                    type="NoiseConditionedSFNO",
                    conditional=True,
                    config=dataclasses.asdict(
                        NoiseConditionedSFNOBuilder(
                            embed_dim=4,
                            noise_embed_dim=4,
                            noise_type="isotropic",
                            num_layers=2,
                            local_blocks=[0],
                        )
                    ),
                ),
                in_names=["forcing_shared", "forcing_rad"],
                out_names=["diagnostic_main", "diagnostic_rad"],
                normalization=normalization,
            ),
        ),
    )


def get_single_module_with_atmosphere_corrector_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    in_names = [
        "DSWRFtoa",
        "HGTsfc",
        "air_temperature_0",
        "air_temperature_1",
        "air_temperature_2",
        "air_temperature_3",
        "air_temperature_4",
        "air_temperature_5",
        "specific_total_water_0",
        "specific_total_water_1",
        "specific_total_water_2",
        "specific_total_water_3",
        "specific_total_water_4",
        "specific_total_water_5",
        "PRESsfc",
        "PRATEsfc",
    ]
    out_names = [
        "air_temperature_0",
        "air_temperature_1",
        "air_temperature_2",
        "air_temperature_3",
        "air_temperature_4",
        "air_temperature_5",
        "specific_total_water_0",
        "specific_total_water_1",
        "specific_total_water_2",
        "specific_total_water_3",
        "specific_total_water_4",
        "specific_total_water_5",
        "PRESsfc",
        "PRATEsfc",
        "LHTFLsfc",
        "SHTFLsfc",
        "ULWRFsfc",
        "ULWRFtoa",
        "DLWRFsfc",
        "DSWRFsfc",
        "USWRFtoa",
        "USWRFsfc",
        "tendency_of_total_water_path_due_to_advection",
    ]
    normalization = get_network_and_loss_normalization_config(
        names=list(set(in_names).union(out_names)),
        dir=dir,
    )
    return StepSelector(
        type="single_module",
        config=dataclasses.asdict(
            SingleModuleStepConfig(
                builder=ModuleSelector(
                    type="SphericalFourierNeuralOperatorNet",
                    config={
                        "scale_factor": 1,
                        "embed_dim": 4,
                        "num_layers": 2,
                    },
                ),
                in_names=in_names,
                out_names=out_names,
                normalization=normalization,
                corrector=AtmosphereCorrectorConfig(
                    conserve_dry_air=True,
                    zero_global_mean_moisture_advection=True,
                    moisture_budget_correction="advection_and_precipitation",
                    force_positive_names=["PRATEsfc"],
                    total_energy_budget_correction=EnergyBudgetConfig(
                        "constant_temperature"
                    ),
                ),
            ),
        ),
    )


def get_fcn3_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    forcing_names = [
        "DSWRFtoa",
        "HGTsfc",
    ]
    atmosphere_prognostic_names = [
        "air_temperature",
        "specific_total_water",
    ]
    atmosphere_diagnostic_names = [
        "radiative_heating",
    ]
    atmosphere_levels = 6
    surface_prognostic_names = [
        "PRESsfc",
    ]
    surface_diagnostic_names = [
        "PRATEsfc",
        "LHTFLsfc",
        "SHTFLsfc",
        "ULWRFsfc",
        "ULWRFtoa",
        "DLWRFsfc",
        "DSWRFsfc",
        "USWRFtoa",
        "USWRFsfc",
        "tendency_of_total_water_path_due_to_advection",
    ]
    atmosphere_packed_names = []
    for i in range(atmosphere_levels):
        atmosphere_packed_names.append(f"air_temperature_{i}")
        atmosphere_packed_names.append(f"specific_total_water_{i}")
        atmosphere_packed_names.append(f"radiative_heating_{i}")
    normalization = get_network_and_loss_normalization_config(
        names=list(
            set(forcing_names)
            .union(atmosphere_packed_names)
            .union(surface_prognostic_names)
            .union(surface_diagnostic_names)
        ),
        dir=dir,
    )
    step_config = FCN3StepConfig(
        builder=FCN3Selector(
            type="FCN3",
            config=FCN3Config(
                scale_factor=1,
                atmo_embed_dim=2,
                surf_embed_dim=2,
                aux_embed_dim=2,
                num_layers=2,
            ),
        ),
        forcing_names=forcing_names,
        atmosphere_prognostic_names=atmosphere_prognostic_names,
        atmosphere_diagnostic_names=atmosphere_diagnostic_names,
        atmosphere_levels=atmosphere_levels,
        surface_prognostic_names=surface_prognostic_names,
        surface_diagnostic_names=surface_diagnostic_names,
        normalization=normalization,
        corrector=AtmosphereCorrectorConfig(
            conserve_dry_air=True,
            zero_global_mean_moisture_advection=True,
            moisture_budget_correction="advection_and_precipitation",
            force_positive_names=["PRATEsfc"],
            total_energy_budget_correction=EnergyBudgetConfig("constant_temperature"),
        ),
    )
    return StepSelector(
        type="FCN3",
        config=dataclasses.asdict(step_config),
    )


def get_secondary_module_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    normalization = get_network_and_loss_normalization_config(
        names=[
            "forcing_a",
            "prog_a",
            "prog_b",
            "diag_a",
        ],
        dir=dir,
    )
    return StepSelector(
        type="secondary_module",
        config=dataclasses.asdict(
            SecondaryModuleStepConfig(
                builder=ModuleSelector(
                    type="SphericalFourierNeuralOperatorNet",
                    config={
                        "scale_factor": 1,
                        "embed_dim": 4,
                        "num_layers": 2,
                    },
                ),
                in_names=["forcing_a", "prog_a", "prog_b"],
                out_names=["prog_a", "prog_b"],
                normalization=normalization,
                secondary_builder=ModuleSelector(type="MLP", config={}),
                secondary_out_names=["diag_a"],
                secondary_residual_out_names=["prog_a"],
            ),
        ),
    )


def get_multi_call_selector(
    dir: pathlib.Path | None = None,
) -> StepSelector:
    return StepSelector(
        type="multi_call",
        config=dataclasses.asdict(
            MultiCallStepConfig(
                wrapped_step=StepSelector(
                    type="separate_radiation",
                    config=dataclasses.asdict(get_separate_radiation_config(dir)),
                ),
                config=MultiCallConfig(
                    forcing_name="forcing_rad",
                    forcing_multipliers={"double": 2.0},
                    output_names=["diagnostic_rad"],
                ),
            ),
        ),
    )


SEPARATE_RADIATION_CONFIG = get_separate_radiation_config()

SELECTOR_GETTERS = [
    get_fcn3_selector,
    get_single_module_with_atmosphere_corrector_selector,
    get_separate_radiation_selector,
    get_single_module_selector,
    get_single_module_noise_conditioned_selector,
    get_secondary_module_selector,
    get_multi_call_selector,
]

SELECTOR_CONFIG_CASES = [
    pytest.param(
        getter(),
        id=getter.__name__,
    )
    for getter in SELECTOR_GETTERS
]

HAS_NEXT_STEP_FORCING_NAME_CASES = [
    pytest.param(
        StepSelector(
            type="separate_radiation",
            config=dataclasses.asdict(SEPARATE_RADIATION_CONFIG),
        ),
        id="multi_call_separate_radiation",
    ),
]

HAS_NEXT_STEP_FORCING_NAME_CASES = [
    pytest.param(
        StepSelector(
            type="separate_radiation",
            config=dataclasses.asdict(SEPARATE_RADIATION_CONFIG),
        ),
        id="separate_radiation",
    ),
]
TIMESTEP = datetime.timedelta(hours=6)


def get_tensor_dict(
    names: list[str], img_shape: tuple[int, int], n_samples: int
) -> TensorDict:
    data_dict = {}
    device = fme.get_device()
    for name in names:
        data_dict[name] = torch.rand(
            n_samples,
            *img_shape,
            device=device,
        )
    return data_dict


def get_step(
    selector: StepSelector,
    img_shape: tuple[int, int],
    init_weights: Callable[[list[nn.Module]], None] = lambda _: None,
    all_labels: set[str] | None = None,
) -> StepABC:
    device = fme.get_device()
    horizontal_coordinate = LatLonCoordinates(
        lat=torch.zeros(img_shape[0], device=device),
        lon=torch.zeros(img_shape[1], device=device),
    )
    vertical_coordinate = HybridSigmaPressureCoordinate(
        ak=torch.arange(7, device=device), bk=torch.arange(7, device=device)
    )
    dataset_info = DatasetInfo(
        horizontal_coordinates=horizontal_coordinate,
        vertical_coordinate=vertical_coordinate,
        timestep=TIMESTEP,
        all_labels=all_labels,
    )
    return selector.get_step(dataset_info, init_weights)


@pytest.mark.parallel
def test_label_conditioned_step():
    dist = Distributed.get_instance()
    selector = get_label_conditioned_selector()
    step = get_step(selector, DEFAULT_IMG_SHAPE, all_labels={"a", "b"})
    input_data = get_tensor_dict(step.input_names, DEFAULT_IMG_SHAPE, n_samples=1)
    next_step_input_data = get_tensor_dict(
        step.next_step_input_names, DEFAULT_IMG_SHAPE, n_samples=1
    )
    input_data = dist.scatter_spatial(input_data, DEFAULT_IMG_SHAPE)
    next_step_input_data = dist.scatter_spatial(next_step_input_data, DEFAULT_IMG_SHAPE)
    output = step.step(
        args=StepArgs(
            input=input_data,
            next_step_input_data=next_step_input_data,
            labels=BatchLabels.new_from_set(
                {"a", "b"}, n_samples=1, device=fme.get_device()
            ),
        ),
        wrapper=lambda x: x,
    )
    h_sl, w_sl = dist.get_local_slices(DEFAULT_IMG_SHAPE)
    local_h = DEFAULT_IMG_SHAPE[0] if h_sl == slice(None) else h_sl.stop - h_sl.start
    local_w = DEFAULT_IMG_SHAPE[1] if w_sl == slice(None) else w_sl.stop - w_sl.start
    assert output["diagnostic_main"].shape == (1, local_h, local_w)
    assert output["diagnostic_rad"].shape == (1, local_h, local_w)


@pytest.mark.parametrize("config", HAS_NEXT_STEP_FORCING_NAME_CASES)
def test_next_step_forcing_names_is_forcing(config: StepSelector):
    data = dataclasses.asdict(config)
    img_shape = DEFAULT_IMG_SHAPE
    step = get_step(config, img_shape)
    forcing_names = set(step.input_names).difference(step.output_names)
    data["config"]["next_step_forcing_names"] = [list(forcing_names)[0]]
    dacite.from_dict(config.__class__, data, config=dacite.Config(strict=True))


@pytest.mark.parametrize("config", HAS_NEXT_STEP_FORCING_NAME_CASES)
def test_next_step_forcing_names_is_prognostic(config: StepSelector):
    data = dataclasses.asdict(config)
    img_shape = DEFAULT_IMG_SHAPE
    step = get_step(config, img_shape)
    prognostic_names = set(step.output_names).intersection(step.input_names)
    name = list(prognostic_names)[0]
    data["config"]["next_step_forcing_names"] = [name]
    with pytest.raises(ValueError) as err:
        dacite.from_dict(config.__class__, data, config=dacite.Config(strict=True))
    assert "next_step_forcing_name" in str(err.value)
    assert name in str(err.value)


@pytest.mark.parametrize("config", HAS_NEXT_STEP_FORCING_NAME_CASES)
def test_next_step_forcing_names_is_diagnostic(config: StepSelector):
    data = dataclasses.asdict(config)
    img_shape = DEFAULT_IMG_SHAPE
    step = get_step(config, img_shape)
    diagnostic_names = set(step.output_names).difference(step.input_names)
    name = list(diagnostic_names)[0]
    data["config"]["next_step_forcing_names"] = [name]
    with pytest.raises(ValueError) as err:
        dacite.from_dict(config.__class__, data, config=dacite.Config(strict=True))
    assert "next_step_forcing_name" in str(err.value)
    assert name in str(err.value)


@pytest.mark.parametrize("config", SELECTOR_CONFIG_CASES)
def test_step_applies_wrapper(config: StepSelector):
    torch.manual_seed(0)
    img_shape = DEFAULT_IMG_SHAPE
    n_samples = 5
    step = get_step(config, img_shape)
    input_data = get_tensor_dict(step.input_names, img_shape, n_samples)
    next_step_input_data = get_tensor_dict(
        step.next_step_input_names, img_shape, n_samples
    )
    multi_calls = 1
    if isinstance(config._step_config_instance, MultiCallStepConfig):
        if config._step_config_instance.config is not None:
            multi_calls += len(config._step_config_instance.config.forcing_multipliers)

    wrapper = unittest.mock.MagicMock(side_effect=lambda x: x)
    step.step(
        args=StepArgs(
            input=input_data, next_step_input_data=next_step_input_data, labels=None
        ),
        wrapper=wrapper,
    )
    assert wrapper.call_count == multi_calls * len(step.modules)
    for module in step.modules:
        wrapper.assert_any_call(module)


@pytest.mark.parametrize("config", SELECTOR_CONFIG_CASES)
def test_step_initializes_weights(config: StepSelector):
    torch.manual_seed(0)
    img_shape = DEFAULT_IMG_SHAPE
    init_weights = unittest.mock.MagicMock(side_effect=lambda x: x)
    step = get_step(config, img_shape, init_weights)
    assert init_weights.called
    call_args, call_kwargs = init_weights.call_args
    assert len(call_args) == 1
    assert len(call_kwargs) == 0
    assert isinstance(call_args[0], list | nn.ModuleList)
    assert len(call_args[0]) == len(step.modules)
    for i, module in enumerate(step.modules):
        assert isinstance(module, DummyWrapper)
        assert call_args[0][i] is module.module


@pytest.mark.parametrize(
    "get_config",
    SELECTOR_GETTERS,
)
def test_load_config(
    get_config: Callable[[pathlib.Path | None], StepSelector],
):
    non_path_config: StepSelector = get_config(
        None
    )  # doesn't depend on files, use to get names
    all_names = set(non_path_config.input_names).union(non_path_config.output_names)
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = pathlib.Path(temp_dir)
        get_scalar_dataset(all_names, fill_value=0.1).to_netcdf(temp_path / "means.nc")
        get_scalar_dataset(all_names, fill_value=1.1).to_netcdf(temp_path / "stds.nc")
        config = get_config(temp_path)
        config.load()
    img_shape = DEFAULT_IMG_SHAPE
    step = get_step(config, img_shape)
    normalizer = step.normalizer
    assert normalizer.means.keys() == all_names
    assert normalizer.stds.keys() == all_names
    assert all(normalizer.means[name] == 0.1 for name in all_names)
    assert all(normalizer.stds[name] == 1.1 for name in all_names)


@pytest.mark.parametrize(
    "get_config",
    SELECTOR_GETTERS,
)
def test_load_is_required_for_path_config(
    get_config: Callable[[pathlib.Path | None], StepSelector],
):
    non_path_config: StepSelector = get_config(
        None
    )  # doesn't depend on files, use to get names
    all_names = set(non_path_config.input_names).union(non_path_config.output_names)
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = pathlib.Path(temp_dir)
        get_scalar_dataset(all_names, fill_value=0.1).to_netcdf(temp_path / "means.nc")
        get_scalar_dataset(all_names, fill_value=1.1).to_netcdf(temp_path / "stds.nc")
        config = get_config(temp_path)
    img_shape = DEFAULT_IMG_SHAPE
    with pytest.raises(FileNotFoundError):
        get_step(config, img_shape)


@pytest.mark.parametrize(
    ["conflict"],
    [
        pytest.param(
            "output",
            id="conflict_with_output",
        ),
        pytest.param(
            "input",
            id="conflict_with_input",
        ),
    ],
)
@pytest.mark.parallel
def test_input_output_names_secondary_decoder_conflict(conflict: str):
    input_names = ["input"]
    output_names = ["output"]
    secondary_decoder_names = [conflict]
    normalization = get_network_and_loss_normalization_config(
        names=input_names + output_names + secondary_decoder_names,
        dir=None,
    )
    with pytest.raises(ValueError) as err:
        SingleModuleStepConfig(
            normalization=normalization,
            in_names=input_names,
            out_names=output_names,
            builder=ModuleSelector(type="MLP", config={}),
            secondary_decoder=SecondaryDecoderConfig(
                secondary_diagnostic_names=secondary_decoder_names,
                network=ModuleSelector(type="MLP", config={}),
            ),
        )
    assert f"secondary_diagnostic_name is an {conflict} variable:" in str(err.value)


def test_step_with_prescribed_prognostic_overwrites_output():
    normalization = get_network_and_loss_normalization_config(
        names=["forcing_shared", "forcing_rad", "diagnostic_main", "diagnostic_rad"],
    )
    config = StepSelector(
        type="single_module",
        config=dataclasses.asdict(
            SingleModuleStepConfig(
                builder=ModuleSelector(
                    type="SphericalFourierNeuralOperatorNet",
                    config={
                        "scale_factor": 1,
                        "embed_dim": 4,
                        "num_layers": 2,
                    },
                ),
                in_names=["forcing_shared", "forcing_rad"],
                out_names=["diagnostic_main", "diagnostic_rad"],
                normalization=normalization,
                prescribed_prognostic_names=["diagnostic_main"],
            ),
        ),
    )
    img_shape = DEFAULT_IMG_SHAPE
    n_samples = 2
    step = get_step(config, img_shape)
    input_data = get_tensor_dict(step.input_names, img_shape, n_samples)
    next_step_input_data = get_tensor_dict(
        step.next_step_input_names, img_shape, n_samples
    )
    prescribed_value = torch.full(
        (n_samples,) + img_shape, 42.0, device=fme.get_device()
    )
    next_step_input_data["diagnostic_main"] = prescribed_value
    output = step.step(
        args=StepArgs(
            input=input_data,
            next_step_input_data=next_step_input_data,
            labels=None,
        ),
        wrapper=lambda x: x,
    )
    torch.testing.assert_close(output["diagnostic_main"], prescribed_value)


def test_secondary_module_empty_names_raises():
    normalization = get_network_and_loss_normalization_config(
        names=["a", "b"],
    )
    with pytest.raises(ValueError, match="at least one of"):
        SecondaryModuleStepConfig(
            builder=ModuleSelector(type="MLP", config={}),
            in_names=["a"],
            out_names=["b"],
            normalization=normalization,
            secondary_builder=ModuleSelector(type="MLP", config={}),
        )


def test_secondary_module_out_name_overlaps_out_names_raises():
    normalization = get_network_and_loss_normalization_config(
        names=["a", "b"],
    )
    with pytest.raises(ValueError, match="secondary_out_names must not overlap"):
        SecondaryModuleStepConfig(
            builder=ModuleSelector(type="MLP", config={}),
            in_names=["a"],
            out_names=["b"],
            normalization=normalization,
            secondary_builder=ModuleSelector(type="MLP", config={}),
            secondary_out_names=["b"],
        )


def test_secondary_module_out_name_overlaps_residual_out_names_raises():
    normalization = get_network_and_loss_normalization_config(
        names=["a", "b", "c"],
    )
    with pytest.raises(
        ValueError, match="secondary_out_names must not overlap.*residual"
    ):
        SecondaryModuleStepConfig(
            builder=ModuleSelector(type="MLP", config={}),
            in_names=["a"],
            out_names=["b"],
            normalization=normalization,
            secondary_builder=ModuleSelector(type="MLP", config={}),
            secondary_out_names=["c"],
            secondary_residual_out_names=["c"],
        )


def test_secondary_module_residual_out_name_not_in_out_or_in_names_raises():
    normalization = get_network_and_loss_normalization_config(
        names=["a", "b", "c"],
    )
    with pytest.raises(ValueError, match="secondary_residual_out_name 'c'"):
        SecondaryModuleStepConfig(
            builder=ModuleSelector(type="MLP", config={}),
            in_names=["a"],
            out_names=["b"],
            normalization=normalization,
            secondary_builder=ModuleSelector(type="MLP", config={}),
            secondary_residual_out_names=["c"],
        )


def test_secondary_module_output_names_full_field_only():
    """secondary_out_names appear in output_names."""
    normalization = get_network_and_loss_normalization_config(
        names=["a", "b", "c"],
    )
    config = SecondaryModuleStepConfig(
        builder=ModuleSelector(type="MLP", config={}),
        in_names=["a"],
        out_names=["b"],
        normalization=normalization,
        secondary_builder=ModuleSelector(type="MLP", config={}),
        secondary_out_names=["c"],
    )
    assert "c" in config.output_names
    assert "b" in config.output_names


def test_secondary_module_output_names_residual_only():
    """secondary_residual_out_names that are in out_names appear in output_names."""
    normalization = get_network_and_loss_normalization_config(
        names=["a", "b"],
    )
    config = SecondaryModuleStepConfig(
        builder=ModuleSelector(type="MLP", config={}),
        in_names=["a"],
        out_names=["b"],
        normalization=normalization,
        secondary_builder=ModuleSelector(type="MLP", config={}),
        secondary_residual_out_names=["b"],
    )
    assert "b" in config.output_names


def test_secondary_module_output_names_residual_on_input_only():
    """secondary_residual_out_names on input-only name adds to output_names."""
    normalization = get_network_and_loss_normalization_config(
        names=["a", "b"],
    )
    config = SecondaryModuleStepConfig(
        builder=ModuleSelector(type="MLP", config={}),
        in_names=["a", "b"],
        out_names=["b"],
        normalization=normalization,
        secondary_builder=ModuleSelector(type="MLP", config={}),
        secondary_residual_out_names=["a"],
    )
    assert "a" in config.output_names
    assert "b" in config.output_names


@pytest.mark.parallel
def test_secondary_module_full_field_and_residual():
    """Test secondary_out_names and secondary_residual_out_names together."""
    torch.manual_seed(0)
    normalization = get_network_and_loss_normalization_config(
        names=["forcing", "prog", "diag"],
    )
    config = StepSelector(
        type="secondary_module",
        config=dataclasses.asdict(
            SecondaryModuleStepConfig(
                builder=ModuleSelector(
                    type="SphericalFourierNeuralOperatorNet",
                    config={
                        "scale_factor": 1,
                        "embed_dim": 4,
                        "num_layers": 2,
                    },
                ),
                in_names=["forcing", "prog"],
                out_names=["prog"],
                normalization=normalization,
                secondary_builder=ModuleSelector(type="MLP", config={}),
                secondary_out_names=["diag"],
                secondary_residual_out_names=["prog"],
            ),
        ),
    )
    img_shape = DEFAULT_IMG_SHAPE
    step = get_step(config, img_shape)
    assert "prog" in step.output_names
    assert "diag" in step.output_names
    assert "prog" in step.prognostic_names
    input_data = get_tensor_dict(step.input_names, img_shape, n_samples=2)
    next_step_input_data = get_tensor_dict(
        step.next_step_input_names, img_shape, n_samples=2
    )
    output = step.step(
        args=StepArgs(
            input=input_data, next_step_input_data=next_step_input_data, labels=None
        ),
    )
    assert "prog" in output
    assert "diag" in output
    assert output["prog"].shape == (2, *img_shape)
    assert output["diag"].shape == (2, *img_shape)


@pytest.mark.parallel
def test_secondary_module_state_round_trip():
    """Test get_state/load_state with secondary module."""
    torch.manual_seed(0)
    normalization = get_network_and_loss_normalization_config(
        names=["forcing", "prog", "diag"],
    )
    config = SecondaryModuleStepConfig(
        builder=ModuleSelector(
            type="SphericalFourierNeuralOperatorNet",
            config={
                "scale_factor": 1,
                "embed_dim": 4,
                "num_layers": 2,
            },
        ),
        in_names=["forcing", "prog"],
        out_names=["prog"],
        normalization=normalization,
        secondary_builder=ModuleSelector(type="MLP", config={}),
        secondary_out_names=["diag"],
        secondary_residual_out_names=["prog"],
    )
    img_shape = DEFAULT_IMG_SHAPE
    step1 = get_step(
        StepSelector(type="secondary_module", config=dataclasses.asdict(config)),
        img_shape,
    )
    state = step1.get_state()
    assert "secondary_module" in state

    step2 = get_step(
        StepSelector(type="secondary_module", config=dataclasses.asdict(config)),
        img_shape,
    )
    step2.load_state(state)

    input_data = get_tensor_dict(step1.input_names, img_shape, n_samples=1)
    next_step_input_data = get_tensor_dict(
        step1.next_step_input_names, img_shape, n_samples=1
    )
    args = StepArgs(
        input=input_data, next_step_input_data=next_step_input_data, labels=None
    )
    out1 = step1.step(args=args)
    out2 = step2.step(args=args)
    for name in out1:
        torch.testing.assert_close(out1[name], out2[name])


@pytest.mark.parallel
def test_secondary_module_residual_on_input_only_with_residual_prediction():
    """When residual_prediction=True and secondary_residual_out_name is in in_names
    but not out_names, the input should not be added twice."""
    torch.manual_seed(0)
    normalization = get_network_and_loss_normalization_config(
        names=["forcing", "prog_a", "prog_b"],
    )
    config = StepSelector(
        type="secondary_module",
        config=dataclasses.asdict(
            SecondaryModuleStepConfig(
                builder=ModuleSelector(
                    type="SphericalFourierNeuralOperatorNet",
                    config={
                        "scale_factor": 1,
                        "embed_dim": 4,
                        "num_layers": 2,
                    },
                ),
                in_names=["forcing", "prog_a", "prog_b"],
                out_names=["prog_a", "prog_b"],
                normalization=normalization,
                residual_prediction=True,
                secondary_builder=ModuleSelector(type="MLP", config={}),
                secondary_residual_out_names=["prog_a"],
            ),
        ),
    )
    img_shape = DEFAULT_IMG_SHAPE
    step = get_step(config, img_shape)
    assert "prog_a" in step.output_names
    input_data = get_tensor_dict(step.input_names, img_shape, n_samples=2)
    next_step_input_data = get_tensor_dict(
        step.next_step_input_names, img_shape, n_samples=2
    )
    output = step.step(
        args=StepArgs(
            input=input_data, next_step_input_data=next_step_input_data, labels=None
        ),
    )
    assert output["prog_a"].shape == (2, *img_shape)
    assert output["prog_b"].shape == (2, *img_shape)
