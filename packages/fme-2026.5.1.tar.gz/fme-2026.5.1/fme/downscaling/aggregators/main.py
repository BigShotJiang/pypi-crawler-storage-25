"""Contains classes for aggregating evaluation metrics and various statistics."""

from collections.abc import Collection, Mapping
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import torch
import xarray as xr

from fme.ace.aggregator.one_step.snapshot import (
    SnapshotAggregator as CoreSnapshotAggregator,
)
from fme.ace.aggregator.plotting import get_cmap_limits, plot_imshow
from fme.core import metrics
from fme.core.coordinates import LatLonCoordinates
from fme.core.dataset.data_typing import VariableMetadata
from fme.core.device import get_device
from fme.core.distributed import Distributed
from fme.core.histogram import ComparedDynamicTailsHistograms
from fme.core.tensor_dict_accumulator import TensorDictAccumulator
from fme.core.typing_ import TensorDict, TensorMapping
from fme.core.wandb import WandB
from fme.downscaling.aggregators.adapters import ComparedDynamicTailsHistogramsAdapter
from fme.downscaling.data import PairedBatchData

from ..metrics_and_maths import (
    compute_zonal_power_spectrum,
    filter_tensor_mapping,
    interpolate,
    map_tensor_mapping,
)
from ..models import ModelOutputs
from .shape_helpers import _check_batch_dims_for_recording
from .typing import (
    ComparisonInputFunc,
    SingleInputFunc,
    _CoarseComparisonAggregator,
    _ComparisonAggregator,
    _DynamicMetricComparisonAggregator,
)


def ensure_trailing_slash(key: str) -> str:
    if key and not key.endswith("/"):
        key += "/"
    return key


def _tensor_mapping_to_numpy(data: TensorMapping) -> TensorMapping:
    return {k: v.cpu().numpy() for k, v in data.items()}


class LossVsNoiseAggregator:
    """
    Aggregates binned diffusion losses as a function of sampled noise level.
    """

    def __init__(
        self,
        name: str = "metrics/loss_vs_noise",
        n_bins: int = 40,
        log10_sigma_min: float = -3.0,
        log10_sigma_max: float = 3.5,
    ) -> None:
        if n_bins < 1:
            raise ValueError("n_bins must be >= 1")
        if log10_sigma_min >= log10_sigma_max:
            raise ValueError("log10_sigma_min must be less than log10_sigma_max")
        self._dist = Distributed.get_instance()

        self._name = ensure_trailing_slash(name)
        self._n_bins = n_bins
        self._log10_sigma_min = log10_sigma_min
        self._log10_sigma_max = log10_sigma_max
        edges = torch.linspace(
            log10_sigma_min, log10_sigma_max, n_bins + 1, device=get_device()
        )
        self._inner_edges = edges[1:-1]
        self._bin_centers = ((edges[:-1] + edges[1:]) / 2).cpu().numpy()

        self._total_sum = torch.zeros(n_bins, dtype=torch.float32, device=get_device())
        self._total_count = torch.zeros(n_bins, dtype=torch.int64, device=get_device())
        self._channel_sum: dict[str, torch.Tensor] = {}
        self._channel_count: dict[str, torch.Tensor] = {}

    def _accumulate(
        self, values: torch.Tensor, bin_indices: torch.Tensor, name: str
    ) -> None:
        if name not in self._channel_sum:
            self._channel_sum[name] = torch.zeros(
                self._n_bins, dtype=torch.float32, device=get_device()
            )
            self._channel_count[name] = torch.zeros(
                self._n_bins, dtype=torch.int64, device=get_device()
            )
        self._channel_sum[name].scatter_add_(0, bin_indices, values.to(torch.float32))
        self._channel_count[name].scatter_add_(
            0, bin_indices, torch.ones_like(bin_indices, dtype=torch.int64)
        )

    @torch.no_grad()
    def record_batch(self, outputs: ModelOutputs) -> None:
        if outputs.sigma is None or not outputs.per_sample_channel_loss:
            return

        sigma = outputs.sigma.detach().flatten()
        if torch.any(sigma <= 0):
            raise ValueError("Sigma must be strictly positive for log10 binning")
        log_sigma = torch.log10(sigma)
        in_range = (log_sigma >= self._log10_sigma_min) & (
            log_sigma <= self._log10_sigma_max
        )
        if not torch.any(in_range):
            return
        # Indices in [0, n_bins-1] for values within the configured sigma range.
        bin_indices = torch.bucketize(log_sigma[in_range], self._inner_edges)

        per_channel: TensorDict = {}
        for name, loss in outputs.per_sample_channel_loss.items():
            channel_loss = loss.detach().flatten()
            if channel_loss.shape != sigma.shape:
                raise ValueError(
                    "Expected per-sample channel losses and sigma to share batch shape"
                )
            per_channel[name] = channel_loss[in_range]

        stacked = torch.stack(list(per_channel.values()), dim=-1)
        total_loss = torch.mean(stacked, dim=-1)
        self._total_sum.scatter_add_(0, bin_indices, total_loss)
        self._total_count.scatter_add_(
            0, bin_indices, torch.ones_like(bin_indices, dtype=torch.int64)
        )
        for name, values in per_channel.items():
            self._accumulate(values=values, bin_indices=bin_indices, name=name)

    def _plot_binned(self, y_values: np.ndarray, counts: np.ndarray, title: str) -> Any:
        wandb = WandB.get_instance()
        fig, ax = plt.subplots()
        mask = counts > 0
        ax.plot(
            self._bin_centers[mask],
            y_values[mask],
            marker="o",
            linewidth=1.0,
            label="loss",
        )
        ax.set_xlabel("log10(sigma)")
        ax.set_ylabel("mean weighted loss")
        ax.set_title(title)
        ax.grid(True, alpha=0.3)

        ax2 = ax.twinx()
        bin_width = float(self._bin_centers[1] - self._bin_centers[0])
        ax2.bar(
            self._bin_centers[mask],
            counts[mask].astype(float),
            width=bin_width * 0.6,
            alpha=0.25,
            color="gray",
            label="bin count",
        )
        ax2.set_ylabel("bin count")

        lines, labels = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines + lines2, labels + labels2)

        image = wandb.Image(fig)
        plt.close(fig)
        return image

    def _get(self):
        means, counts = {}, {}

        total_sum = self._dist.reduce_sum(self._total_sum)
        total_count = self._dist.reduce_sum(self._total_count)
        if total_sum is None or total_count is None:
            return {}
        total_sum = total_sum.cpu().numpy()
        total_count = total_count.cpu().numpy()

        total_mean = np.divide(
            total_sum,
            total_count,
            out=np.zeros_like(total_sum),
            where=total_count > 0,
        )

        means["all_channels"] = total_mean
        counts["all_channels"] = total_count

        for name in sorted(self._channel_sum):
            ch_sum = self._dist.reduce_sum(self._channel_sum[name])
            ch_count = self._dist.reduce_sum(self._channel_count[name])
            if ch_sum is None or ch_count is None:
                continue
            ch_sum = ch_sum.cpu().numpy()
            ch_count = ch_count.cpu().numpy()
            ch_mean = np.divide(
                ch_sum,
                ch_count,
                out=np.zeros_like(ch_sum),
                where=ch_count > 0,
            )
            means[name] = ch_mean
            counts[name] = ch_count

        return means, counts

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        prefix = ensure_trailing_slash(prefix)
        means, counts = self._get()
        ret: dict[str, Any] = {}
        if sum(counts["all_channels"]) == 0:
            return ret

        for name in sorted(means):
            ret[f"{prefix}{self._name}{name}"] = self._plot_binned(
                y_values=means[name],
                counts=counts[name],
                title=f"{name} weighted loss vs noise",
            )
        return ret


def _get_spectrum_metrics(
    gen_spectrum: Mapping[str, np.ndarray],
    target_spectrum: Mapping[str, np.ndarray],
    prefix: str = "",
) -> Mapping[str, float]:
    """
    Compute metrics for the spectrum.

    Args:
        gen_spectrum: Dictionary of 1-dimensional generated mean power spectra.
        target_spectrum: Dictionary of 1-dimensional target mean power spectra.
        prefix: Prefix to use for the metric names.

    Returns:
        Dictionary of metrics.
    """
    prefix = ensure_trailing_slash(prefix)
    metrics = {}
    for name in gen_spectrum:
        if len(gen_spectrum[name].shape) != 1:
            raise ValueError(
                f"Expected 1-dimensional power spectrum for {name}, "
                f"got {gen_spectrum[name].shape}"
            )
        ratio = gen_spectrum[name] / target_spectrum[name] - 1
        positive_bias = float(ratio[ratio > 0].sum() / target_spectrum[name].shape[0])
        negative_bias = float(ratio[ratio < 0].sum() / target_spectrum[name].shape[0])

        metrics[f"{prefix}positive_norm_bias/{name}"] = positive_bias
        metrics[f"{prefix}negative_norm_bias/{name}"] = negative_bias
        metrics[f"{prefix}mean_abs_norm_bias/{name}"] = abs(positive_bias) + abs(
            negative_bias
        )
    return metrics


class Mean:
    """
    Tracks a running average of a metric over multiple batches.

    Args:
        metric: The metric function to be calculated and added to the running average.
        name: The name to use for the metric in the wandb output.
    """

    def __init__(
        self,
        metric: SingleInputFunc,
        name: str = "",
    ) -> None:
        self._mapped_metric = map_tensor_mapping(metric)
        self._accumulator = TensorDictAccumulator()
        self._name = ensure_trailing_slash(name)

    @property
    def count(self) -> int:
        return self._accumulator.count

    @torch.no_grad()
    def record_batch(self, data: TensorMapping) -> None:
        """
        Record the metric for the current batch.
        """
        self._accumulator.add(self._mapped_metric(data))

    def get(self) -> TensorMapping:
        """
        Calculates and return the current mean of the metric values.
        """
        return self._accumulator.get_distributed_mean()

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        """
        Get the running average metric logs for wandb.
        """
        prefix = ensure_trailing_slash(prefix)
        return {
            f"{prefix}{self._name}{k}": v.detach().cpu().numpy()
            for k, v in self.get().items()
        }


class SumComparison:
    """
    Tracks a running sum of a comparison metric over multiple batches.

    Args:
        metric: The metric function to be summed which compares two tensors
        (e.g. target and prediction)
        name: The name to use for the metric in the wandb output.
    """

    def __init__(
        self,
        metric: ComparisonInputFunc,
        name: str = "",
    ) -> None:
        self._mapped_metric = map_tensor_mapping(metric)
        self._accumulator = TensorDictAccumulator()
        self._name = ensure_trailing_slash(name)

    @property
    def count(self) -> int:
        return self._accumulator.count

    @torch.no_grad()
    def record_batch(self, target: TensorMapping, prediction: TensorMapping) -> None:
        """
        Record the metric for the current target and prediction batch.
        """
        self._accumulator.add(self._mapped_metric(target, prediction))

    def get(self) -> TensorMapping:
        """
        Calculates and return the current sum of the metric values.
        """
        return self._accumulator.get_distributed_sum()

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        """
        Get the running sum comparison metric logs for wandb.
        """
        prefix = ensure_trailing_slash(prefix)
        return {
            f"{prefix}{self._name}{k}": v.cpu().numpy() for k, v in self.get().items()
        }


class MeanComparison:
    """
    Tracks a running average of a comparison metric over multiple batches.

    Args:
        metric: The metric function to be averaged which compares two tensors
        (e.g. target and prediction) If not provided, you must provide a
        dynamic metric to the record_batch method.

    Raises:
        ValueError: If no values have been added to the running average or if
            no default metric or dynamic metric is provided.
    """

    def __init__(
        self,
        metric: ComparisonInputFunc | None = None,
        name: str = "",
    ) -> None:
        self._mapped_metric = map_tensor_mapping(metric) if metric is not None else None
        self._accumulator = TensorDictAccumulator()
        self._name = ensure_trailing_slash(name)

    @property
    def count(self) -> int:
        return self._accumulator.count

    @torch.no_grad()
    def record_batch(
        self,
        target: TensorMapping,
        prediction: TensorMapping,
        dynamic_metric: ComparisonInputFunc | None = None,
    ) -> None:
        """
        Record the metric for the current target and prediction batch.

        Args:
            target: the 'truth' target values.
            prediction: the predicted values.
            dynamic_metric: a metric that changes with the batch. overrides the
                default metric if both are provided.
        """
        if dynamic_metric is not None:
            metric = map_tensor_mapping(dynamic_metric)(target, prediction)
        elif self._mapped_metric is not None:
            metric = self._mapped_metric(target, prediction)
        else:
            raise ValueError("No metric function provided to MeanComparisonAggregator")
        self._accumulator.add(metric)

    def get(self) -> TensorMapping:
        """
        Calculates and returns the current mean of the comparison metric values.
        """
        return self._accumulator.get_distributed_mean()

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        """
        Get the running average comparison metric logs for wandb.
        """
        prefix = ensure_trailing_slash(prefix)
        return {
            f"{prefix}{self._name}{k}": v.cpu().numpy() for k, v in self.get().items()
        }


def _compute_zonal_mean_power_spectrum(x):
    if not len(x.shape) == 3:
        raise ValueError(
            f"Expected input (batch, height, width) but received {x.shape}"
        )

    # (batch, wavenumber) -> (wavenumber,)
    return compute_zonal_power_spectrum(x).mean(axis=0)


class ZonalPowerSpectrumAggregator:
    """
    Record the mean zonal power spectrum for the input coarse data
    and the predicted fine data.  Coarse data is interpolated to
    the fine grid before calculating the spectrum.

    Args:
        downscale_factor: The factor by which the coarse data has been downscaled.
        name: The name to use for the spectrum in the wandb output.
    """

    def __init__(self, downscale_factor: int, name: str = "") -> None:
        self.wandb = WandB.get_instance()
        self._name = ensure_trailing_slash(name)
        self._coarse_spectrum = Mean(_compute_zonal_mean_power_spectrum)
        self._fine_spectrum = Mean(_compute_zonal_mean_power_spectrum)
        self.downscale_factor = downscale_factor

    def _interpolate(
        self, data: TensorMapping, keys: Collection[str] | None = None
    ) -> TensorMapping:
        # interpolate expects 4D input (batch, channel, height, width)
        # for 2D - bicubic interpolation, so we need to expand below
        # https://pytorch.org/docs/stable/generated/torch.nn.functional.interpolate.html
        channel_dim = -3
        keys = keys if keys is not None else data.keys()
        return {
            k: interpolate(v.unsqueeze(channel_dim), self.downscale_factor).squeeze(
                channel_dim
            )
            for k, v in data.items()
            if k in keys
        }

    @torch.no_grad()
    def record_batch(self, prediction: TensorMapping, coarse: TensorMapping) -> None:
        """
        Record the zonal power spectrum for the current batch.
        """
        self._fine_spectrum.record_batch(prediction)
        self._coarse_spectrum.record_batch(
            self._interpolate(coarse, keys=list(prediction.keys()))
        )

    def get(self) -> tuple[TensorMapping, TensorMapping]:
        """
        Get the mean zonal power spectrum tensors for the fine and coarse data.
        """
        fine = self._fine_spectrum.get()
        coarse = self._coarse_spectrum.get()
        return fine, coarse

    def _plot_spectrum(self, prediction: np.ndarray, coarse: np.ndarray) -> Any:
        fig = plt.figure()
        plt.loglog(prediction, linestyle="--", label="prediction")
        plt.loglog(coarse, linestyle="-.", label="coarse")
        plt.legend()
        plt.grid()
        plt.close(fig)
        return fig

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        """
        Get the zonal power spectrum logs for wandb.
        """
        prefix = ensure_trailing_slash(prefix)
        fine, coarse = self.get()
        fine = _tensor_mapping_to_numpy(fine)
        coarse = _tensor_mapping_to_numpy(coarse)
        ret = {}
        for name, values in fine.items():
            ret[f"{prefix}{self._name}{name}"] = self._plot_spectrum(
                values, coarse[name]
            )
        return ret

    def get_dataset(self) -> xr.Dataset:
        """
        Get the zonal power spectrum dataset.
        """
        fine, coarse = self.get()
        fine = {k: v.cpu().numpy() for k, v in fine.items()}
        coarse = {k: v.cpu().numpy() for k, v in coarse.items()}
        coords = {"wavenumber": np.arange(len(next(iter(fine.values()))))}
        data = {}
        for var_key in fine:
            data[f"{self._name}coarse.{var_key}"] = (("wavenumber"), coarse[var_key])
            data[f"{self._name}fine.{var_key}"] = (("wavenumber"), fine[var_key])
        return xr.Dataset(data, coords=coords)


class ZonalPowerSpectrumComparison:
    """
    Record the zonal power spectrum for the interpolated input coarse data, and
    the predicted and target fine data.  Coarse data is interpolated to the fine
    grid before calculating the spectrum.

    Args:
        downscale_factor: The factor by which the data has been downscaled.
        name: The name to use for the spectrum in the wandb output.
    """

    def __init__(self, downscale_factor: int, name: str = "") -> None:
        self._name = ensure_trailing_slash(name)
        self._mean_target_aggregator = Mean(_compute_zonal_mean_power_spectrum)
        # power spectrum for prediction and coarse data
        self._mean_prediction_aggregator = ZonalPowerSpectrumAggregator(
            downscale_factor, name=name
        )

    @torch.no_grad()
    def record_batch(
        self, target: TensorMapping, prediction: TensorMapping, coarse: TensorMapping
    ) -> None:
        """
        Record the zonal power spectrum for the current batch.

        Args:
            target: The target fine data for the current batch.
            prediction: The predicted fine data for the current batch.
            coarse: The coarse data for the current batch.
        """
        self._mean_prediction_aggregator.record_batch(prediction, coarse)
        self._mean_target_aggregator.record_batch(target)

    def _plot_spectrum_all(
        self, target: np.ndarray, prediction: np.ndarray, coarse: np.ndarray
    ) -> Any:
        fig = plt.figure()
        plt.loglog(target, label="target")
        plt.loglog(prediction, linestyle="--", label="prediction")
        plt.loglog(coarse, linestyle="-.", label="coarse")
        plt.legend()
        plt.grid()
        plt.close(fig)
        return fig

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        """
        Get the zonal power spectrum logs for wandb.
        """
        prefix = ensure_trailing_slash(prefix)
        prediction, coarse = self._mean_prediction_aggregator.get()
        target = self._mean_target_aggregator.get()
        prediction = _tensor_mapping_to_numpy(prediction)
        coarse = _tensor_mapping_to_numpy(coarse)
        target = _tensor_mapping_to_numpy(target)
        ret = {}
        for name, values in target.items():
            ret[f"{prefix}{self._name}{name}"] = self._plot_spectrum_all(
                values, prediction[name], coarse[name]
            )
        scalar_metrics = _get_spectrum_metrics(
            prediction, target, prefix=f"{prefix}{self._name}"
        )
        ret.update(scalar_metrics)
        return ret

    def get_dataset(self) -> xr.Dataset:
        ds = self._mean_prediction_aggregator.get_dataset()
        target = self._mean_target_aggregator.get()
        target = {k: v.cpu().numpy() for k, v in target.items()}
        ds.update(
            {f"{self._name}target.{k}": (("wavenumber"), target[k]) for k in target}
        )
        return ds


class SnapshotAggregator:
    """
    Records a snapshot of the target and prediction tensors for visualization.

    Args:
        variable_metadata: metadata for the variables to use for snapshot caption
    """

    def __init__(
        self,
        dims: list[str],
        variable_metadata: Mapping[str, VariableMetadata] | None,
        name: str = "",
    ) -> None:
        self._snapshot_aggregator = CoreSnapshotAggregator(dims, variable_metadata)
        self._name = ensure_trailing_slash(name)

    def _tile_time_dim(self, x: torch.Tensor) -> torch.Tensor:
        time_dim = -3
        return x.unsqueeze(time_dim).repeat_interleave(2, dim=time_dim)

    @torch.no_grad()
    def record_batch(self, target: TensorMapping, prediction: TensorMapping) -> None:
        """
        Record values for a snapshot of the target and prediction tensors.
        """
        # core SnapshotAggregator expects a time dimension of length two, so we
        # provide it by tiling the data.
        target = map_tensor_mapping(self._tile_time_dim)(target)
        prediction = map_tensor_mapping(self._tile_time_dim)(prediction)
        self._snapshot_aggregator.record_batch(-1.0, target, prediction, {}, {})

    def _get(self, label: str = "") -> Mapping[str, Any]:
        label = ensure_trailing_slash(label)
        logs = self._snapshot_aggregator.get_logs(label)
        ret = {}
        for k, v in logs.items():
            k = k.removeprefix("/")
            # residual is meaningless for single steps
            if "residual" not in k:
                # The core SnapshotAggregator returns {label}/{key} even when
                # label == "". In this case, removing the leading slash.
                ret[f"{label}maps/{self._name}{k}"] = v
        return ret

    def get_wandb(self, label: str = "") -> Mapping[str, Any]:
        """
        Retrieve a snapshot from the currently stored batch for wandb.
        """
        label = ensure_trailing_slash(label)
        return self._get(label)


def batch_mean(x: torch.Tensor, dim: int = 0) -> torch.Tensor:
    assert (
        len(x.shape) == 3
    ), f"Expected input (batch, height, width) but got {x.shape}."
    return x.mean(dim=0)


class MeanMapAggregator:
    """
    Aggregates time mean maps of target and prediction tensors, time mean
    bias, and a log10-scaled relative mean bias to the target data.

    Args:
        variable_metadata: metadata for the variables.
        gap_width: Width between the prediction and target images.
        name: The name to use for the maps in the wandb output.
    """

    def __init__(
        self,
        variable_metadata: Mapping[str, VariableMetadata] | None = None,
        gap_width: int = 4,
        name: str = "",
    ):
        self.gap_width = gap_width
        if variable_metadata is None:
            self._variable_metadata: Mapping[str, VariableMetadata] = {}
        else:
            self._variable_metadata = variable_metadata
        self._name = ensure_trailing_slash(name)
        self._mean_target = Mean(batch_mean)
        self._mean_prediction = Mean(batch_mean)
        # corresponds to 40 x 80 deg at 3km resolution, in comparison CONUS is 28x65 deg
        self.max_img_upload_size = 3276800

    @torch.no_grad()
    def record_batch(self, target: TensorMapping, prediction: TensorMapping) -> None:
        """
        Record the running average maps for the current batch.

        Args:
            target: Tensor of shape (n_examples, n_lat, n_lon)
            prediction: Tensor of shape (n_examples, n_lat, n_lon)
        """
        assert set(target.keys()) == set(prediction.keys()), "Keys do not match"
        self._mean_target.record_batch(target)
        self._mean_prediction.record_batch(prediction)

    def _get(self) -> tuple[TensorMapping, TensorMapping]:
        target = self._mean_target.get()
        prediction = self._mean_prediction.get()
        return target, prediction

    def _plot_spectrum(self, prediction: np.ndarray, target: np.ndarray) -> Any:
        fig = plt.figure()
        plt.loglog(prediction, linestyle="--", label="prediction")
        plt.loglog(target, linestyle="-.", label="target")
        plt.legend()
        plt.grid()
        plt.close(fig)
        return fig

    def _get_metrics_and_maps(
        self,
    ) -> tuple[TensorMapping, TensorMapping, Mapping[str, Any]]:
        target, prediction = self._get()

        def get_relative_mean(target, prediction):
            return torch.log10(torch.abs(prediction / target))

        relative = map_tensor_mapping(get_relative_mean)(target, prediction)

        target_power_spectrum = map_tensor_mapping(compute_zonal_power_spectrum)(target)
        prediction_power_spectrum = map_tensor_mapping(compute_zonal_power_spectrum)(
            prediction
        )
        target_power_spectrum = _tensor_mapping_to_numpy(target_power_spectrum)
        prediction_power_spectrum = _tensor_mapping_to_numpy(prediction_power_spectrum)

        maps = {}
        metrics = {}
        spectra = {}
        for var_name in target.keys():
            error = prediction[var_name] - target[var_name]
            if target[var_name].nelement() < self.max_img_upload_size:
                gap = torch.full(
                    (target[var_name].shape[-2], self.gap_width),
                    float(target[var_name].min()),
                    device=target[var_name].device,
                )
                maps[f"maps/{self._name}full-field/{var_name}"] = torch.cat(
                    (prediction[var_name], gap, target[var_name]), dim=1
                )
                maps[f"maps/{self._name}log10_relative_mean/{var_name}"] = relative[
                    var_name
                ]
                maps[f"maps/{self._name}error/{var_name}"] = error
            metrics[f"metrics/{self._name}bias/{var_name}"] = error.mean()

            spectra_prefix = ensure_trailing_slash(f"power_spectrum_of_{self._name}")
            spectra[f"{spectra_prefix}{var_name}"] = self._plot_spectrum(
                prediction_power_spectrum[var_name], target_power_spectrum[var_name]
            )
            spectrum_metrics = _get_spectrum_metrics(
                gen_spectrum=prediction_power_spectrum,
                target_spectrum=target_power_spectrum,
                prefix=spectra_prefix,
            )
            spectra.update(spectrum_metrics)
        return metrics, maps, spectra

    _captions = {
        "full-field": (
            "{name}  mean full field; (left) generated and (right) target [{units}]"
        ),
        "error": "{name} mean full field error (generated - target) [{units}]",
        "log10_relative_mean": "{name} log10(prediction/target) of mean full field",
    }

    def _get_caption(self, key: str, name: str, vmin: float, vmax: float) -> str:
        if name in self._variable_metadata:
            caption_name = self._variable_metadata[name].long_name
            units = self._variable_metadata[name].units
        else:
            caption_name, units = name, "unknown_units"
        caption = self._captions[key].format(name=caption_name, units=units)
        if "error" in key:
            caption += f" vmin={vmin:.4g} (blue), vmax={vmax:.4g} (red)."
        else:
            caption += f" vmin={vmin:.4g}, vmax={vmax:.4g}."
        return caption

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        """
        Get all time average map logs for wandb.
        """
        prefix = ensure_trailing_slash(prefix)
        ret = {}
        wandb = WandB.get_instance()
        metrics, maps, spectra = self._get_metrics_and_maps()
        ret.update({f"{prefix}{k}": v.cpu().numpy() for k, v in metrics.items()})
        for key, data in maps.items():
            if "error" in key:
                diverging, cmap = True, "RdBu_r"
            else:
                diverging, cmap = False, None
            data = data.cpu().numpy()
            vmin, vmax = get_cmap_limits(data, diverging=diverging)
            map_name, var_name = key.split("/")[-2:]
            caption = self._get_caption(map_name, var_name, vmin, vmax)
            fig = plot_imshow(data, vmin=vmin, vmax=vmax, cmap=cmap)
            ret[f"{prefix}{key}"] = wandb.Image(fig, caption=caption)
            plt.close(fig)
        for key, value in spectra.items():
            ret[f"{prefix}{key}"] = value
        return ret

    def get_dataset(self) -> xr.Dataset:
        """
        Get the time mean maps dataset.
        """
        target, prediction = self._get()
        data = {}
        for key in prediction:
            data[f"{self._name}target.{key}"] = target[key].cpu().numpy()
            data[f"{self._name}prediction.{key}"] = prediction[key].cpu().numpy()
        ds = xr.Dataset({k: (("lat", "lon"), v) for k, v in data.items()})
        return ds


class RelativeMSEInterpAggregator:
    """
    Records the running relative mean squared error (MSE) of the prediction and the
    interpolated coarse field.

    Args:
        downscale_factor: The factor by which the data has been downscaled.
        name: The name to use for the metric in the wandb output.
    """

    def __init__(self, downscale_factor: int, name: str = "") -> None:
        self.downscale_factor = downscale_factor
        self._prediction_mse = MeanComparison(torch.nn.MSELoss())
        self._interpolated_mse = MeanComparison(torch.nn.MSELoss())
        self._name = ensure_trailing_slash(name)

    def _interpolate(
        self, data: TensorMapping, keys: Collection[str] | None = None
    ) -> TensorMapping:
        channel_dim = -3
        keys = keys if keys is not None else data.keys()
        return {
            k: interpolate(v.unsqueeze(channel_dim), self.downscale_factor).squeeze(
                channel_dim
            )
            for k, v in data.items()
            if k in keys
        }

    @torch.no_grad()
    def record_batch(
        self, target: TensorMapping, prediction: TensorMapping, coarse: TensorMapping
    ) -> None:
        """
        Record the relative MSE for the current batch.
        """
        self._prediction_mse.record_batch(target, prediction)
        self._interpolated_mse.record_batch(
            target, self._interpolate(coarse, keys=target.keys())
        )

    def get_wandb(self, prefix: str = "") -> Mapping[str, Any]:
        """
        Get the relative MSE logs for wandb.
        """
        prefix = ensure_trailing_slash(prefix)
        prediction_mse = self._prediction_mse.get()
        interpolated_mse = self._interpolated_mse.get()
        return {
            f"{prefix}{self._name}{k}": prediction_mse[k] / interpolated_mse[k]
            for k in prediction_mse
        }


class Aggregator:
    """
    Class for aggregating evaluation for training/validation batch predictions
    for 3D data. E.g., the case in training/validation where there is no sample
    dimension, or for folded generation data where the batch and samples are
    folded into the first dimension.

    For generation metrics, where the leading dimensions are [batch, sample],
    use GenerationAggregator instead.

    Args:
        dims: Spatial dimensions of the data (e.g. [lat, lon]). Used by the
            CoreSnapshotAggregator to output a dataset of map metrics.
        downscale_factor: the scale factor for going from coarse to fine data.
        n_histogram_bins: Number of bins for the histogram.
        percentiles: List of percentiles to compute for the histogram.
        ssim_kwargs: Keyword arguments for SSIM computation.
        variable_metadata: Metadata for each variable.
        include_positional_comparisons: Include comparison metrics that output
            positional maps (e.g. mean maps).  This should be disabled when
            using random subsetting because averaged maps won't make sense.
        two_tailed_variables: List of variables to compute two-tailed metrics for
            if present in the data. Defaults to
            ["eastward_wind_at_ten_meters", "northward_wind_at_ten_meters"].
        left_tailed_variables: List of variables to compute left-tailed metrics for
            if present in the data. Defaults to ["PRMSL", "PRESsfc"].
    """

    def __init__(
        self,
        dims: list[str],
        downscale_factor: int,
        n_histogram_bins: int = 300,
        percentiles: list[float] | None = None,
        ssim_kwargs: Mapping[str, Any] | None = None,
        variable_metadata: Mapping[str, VariableMetadata] | None = None,
        include_positional_comparisons: bool = True,
        log_loss_vs_noise: bool = False,
        two_tailed_variables: list[str] | None = None,
        left_tailed_variables: list[str] | None = None,
    ) -> None:
        self.downscale_factor = downscale_factor

        if ssim_kwargs is None:
            ssim_kwargs = {}
        if two_tailed_variables is None:
            two_tailed_variables = [
                "eastward_wind_at_ten_meters",
                "northward_wind_at_ten_meters",
            ]
        if left_tailed_variables is None:
            left_tailed_variables = ["PRMSL", "PRESsfc"]

        # Folded samples into batch dimension
        self._comparisons: list[_ComparisonAggregator] = [
            MeanComparison(metrics.root_mean_squared_error, name="metrics/rmse"),
            SnapshotAggregator(dims, variable_metadata, name="snapshot"),
            ComparedDynamicTailsHistogramsAdapter(
                histograms=ComparedDynamicTailsHistograms(
                    n_bins=n_histogram_bins,
                    percentiles=percentiles,
                    compute_percentile_frac=True,
                    two_tailed_variables=two_tailed_variables,
                    left_tailed_variables=left_tailed_variables,
                ),
                name="histogram",
            ),
        ]
        self._area_weighted: list[_DynamicMetricComparisonAggregator] = [
            MeanComparison(name="metrics/area_weighted_rmse"),
        ]

        # Includes coarse input ontop of target/prediction
        self._coarse_comparisons: list[_CoarseComparisonAggregator] = [
            RelativeMSEInterpAggregator(
                downscale_factor, name="metrics/relative_mse_bicubic"
            ),
            ZonalPowerSpectrumComparison(downscale_factor, name="power_spectrum"),
        ]

        # Turned off for random subsetting where average maps don't make sense
        self.include_positional_comparisons = include_positional_comparisons
        if include_positional_comparisons:
            self._comparisons += [
                MeanMapAggregator(variable_metadata, name="time_mean"),
            ]

        self.loss = Mean(torch.mean)
        self.channel_loss = Mean(torch.mean)
        self.log_loss_vs_noise = log_loss_vs_noise
        self.loss_vs_noise = LossVsNoiseAggregator() if self.log_loss_vs_noise else None
        self._fine_latlon_coordinates: LatLonCoordinates | None = None

    @torch.no_grad()
    def record_batch(
        self,
        outputs: ModelOutputs,
        coarse: TensorMapping,
        batch: PairedBatchData,
    ) -> None:
        """
        Records a batch of target and prediction tensors for metric computation.
        Expects (batch, ...) shaped tensors.

        Args:
            outputs: The model outputs from a downscaling prediction step.
            coarse: The coarse data for the current batch.
            batch: Paired batch data with spatial information.
        """
        _check_batch_dims_for_recording(outputs, coarse, 3)
        if self.include_positional_comparisons:
            self._fine_latlon_coordinates = batch.fine.latlon_coordinates[0]
        target, prediction = outputs.target, outputs.prediction
        target = filter_tensor_mapping(target, prediction.keys())

        for comparison_aggregator in self._comparisons:
            comparison_aggregator.record_batch(target, prediction)

        for weighted_aggregator in self._area_weighted:
            area_weights = batch.fine.latlon_coordinates.area_weights.to(get_device())

            def weighted_rmse(truth, pred):
                return metrics.root_mean_squared_error(truth, pred, area_weights)

            weighted_aggregator.record_batch(
                target, prediction, dynamic_metric=weighted_rmse
            )

        for coarse_comparison_aggregator in self._coarse_comparisons:
            coarse_comparison_aggregator.record_batch(target, prediction, coarse)

        self.loss.record_batch({"loss": outputs.loss})
        if outputs.channel_losses:
            self.channel_loss.record_batch(outputs.channel_losses)
        if self.loss_vs_noise is not None:
            self.loss_vs_noise.record_batch(outputs)

    def get_wandb(
        self,
        prefix: str = "",
    ) -> Mapping[str, Any]:
        """
        Get the wandb output to log from all sub aggregators.
        """
        prefix = ensure_trailing_slash(prefix)

        ret: dict[str, Any] = {}
        ret.update(self.loss.get_wandb(prefix))
        if self.channel_loss.count > 0:
            ret.update(self.channel_loss.get_wandb(f"{prefix}channel_loss/"))
        if self.loss_vs_noise is not None:
            ret.update(self.loss_vs_noise.get_wandb(prefix))
        for comparison in self._comparisons:
            ret.update(comparison.get_wandb(prefix))
        for coarse_comparison in self._coarse_comparisons:
            ret.update(coarse_comparison.get_wandb(prefix))

        return ret

    def get_dataset(self) -> xr.Dataset:
        """
        Get the dataset from all sub aggregators.
        """
        ds = xr.Dataset()
        for comparison in self._comparisons:
            if hasattr(comparison, "get_dataset"):
                ds = ds.merge(comparison.get_dataset())
        for coarse_comparison in self._coarse_comparisons:
            if hasattr(coarse_comparison, "get_dataset"):
                ds = ds.merge(coarse_comparison.get_dataset())
        if self._fine_latlon_coordinates is not None:
            ds = ds.assign_coords(self._fine_latlon_coordinates.coords)
        return ds
