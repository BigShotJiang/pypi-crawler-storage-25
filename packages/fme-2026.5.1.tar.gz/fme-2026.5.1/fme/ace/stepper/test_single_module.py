import dataclasses
import datetime
import gc
import os
import pathlib
import unittest
import unittest.mock
from collections import namedtuple
from collections.abc import Iterable, Mapping
from typing import Literal
from unittest.mock import patch

import cftime
import numpy as np
import pytest
import torch
import xarray as xr

import fme
from fme.ace.aggregator import OneStepAggregator
from fme.ace.aggregator.plotting import plot_paneled_data
from fme.ace.data_loading.batch_data import BatchData, PrognosticState
from fme.ace.inference.test_evaluator import (
    save_plus_one_stepper,
    validate_stepper_config,
    validate_stepper_multi_call,
    validate_stepper_ocean,
)
from fme.ace.registry.sfno import SphericalFourierNeuralOperatorBuilder
from fme.ace.stepper.derived_forcings import DerivedForcingsConfig, ForcingDeriver
from fme.ace.stepper.insolation.config import InsolationConfig, NameConfig, ValueConfig
from fme.ace.stepper.single_module import (
    AtmosphereCorrectorConfig,
    CheckpointStepperConfig,
    EpochNotProvidedError,
    SingleModuleStepperConfig,
    Stepper,
    StepperConfig,
    StepperOverrideConfig,
    TrainOutput,
    TrainStepper,
    TrainStepperConfig,
    get_serialized_stepper_vertical_coordinate,
    load_stepper,
    load_stepper_config,
    load_stepper_config_with_override,
)
from fme.ace.stepper.time_length_probabilities import (
    TimeLength,
    TimeLengthMilestone,
    TimeLengthProbabilities,
    TimeLengthProbability,
    TimeLengthSchedule,
)
from fme.ace.testing import DimSizes, save_stepper_checkpoint
from fme.core import AtmosphereData
from fme.core.benchmark.memory import benchmark_memory
from fme.core.coordinates import (
    DepthCoordinate,
    DimSize,
    HybridSigmaPressureCoordinate,
    LatLonCoordinates,
    VerticalCoordinate,
)
from fme.core.dataset_info import DatasetInfo, MissingDatasetInfo
from fme.core.device import get_device
from fme.core.generics.optimization import OptimizationABC
from fme.core.loss import StepLossConfig
from fme.core.mask_provider import MaskProvider
from fme.core.masking import StaticMaskingConfig
from fme.core.normalizer import NetworkAndLossNormalizationConfig, NormalizationConfig
from fme.core.ocean import OceanConfig
from fme.core.optimization import (
    CheckpointConfig,
    NullOptimization,
    Optimization,
    OptimizationConfig,
)
from fme.core.registry.corrector import CorrectorSelector
from fme.core.registry.module import ModuleSelector
from fme.core.step import SingleModuleStepConfig, StepSelector
from fme.core.step.args import StepArgs
from fme.core.step.multi_call import MultiCallConfig
from fme.core.step.single_module import SingleModuleStep
from fme.core.testing.regression import validate_tensor_dict
from fme.core.training_history import TrainingJob
from fme.core.typing_ import EnsembleTensorDict

DIR = os.path.abspath(os.path.dirname(__file__))

SphericalData = namedtuple("SphericalData", ["data", "area_weights", "vertical_coord"])
TIMESTEP = datetime.timedelta(hours=6)
DEVICE = fme.get_device()
OCEAN_CONFIG = OceanConfig(surface_temperature_name="a", ocean_fraction_name="b")
MULTI_CALL_CONFIG = MultiCallConfig(
    forcing_name="co2", forcing_multipliers={"_b": 0.5}, output_names=["ULWRFtoa"]
)
INSOLATION_NAME = "DSWRFtoa"
SOLAR_CONSTANT_NAME = "solar_constant"
S0 = 1360.0
SOLAR_CONSTANT_AS_NAME = NameConfig(SOLAR_CONSTANT_NAME)
SOLAR_CONSTANT_AS_VALUE = ValueConfig(S0)
INSOLATION_CONFIG = InsolationConfig(INSOLATION_NAME, SOLAR_CONSTANT_AS_VALUE)
DERIVED_FORCINGS_CONFIG = DerivedForcingsConfig(insolation=INSOLATION_CONFIG)
EMPTY_DERIVED_FORCINGS_CONFIG = DerivedForcingsConfig()


def get_data(names: Iterable[str], n_samples, n_time, epoch: int = 0) -> SphericalData:
    data_dict = {}
    n_lat, n_lon, nz = 5, 5, 7

    lats = torch.linspace(-89.5, 89.5, n_lat)  # arbitary choice
    for name in names:
        data_dict[name] = torch.rand(n_samples, n_time, n_lat, n_lon, device=DEVICE)
    area_weights = fme.spherical_area_weights(lats, n_lon).to(DEVICE)
    ak, bk = torch.arange(nz), torch.arange(nz)
    vertical_coord = HybridSigmaPressureCoordinate(ak, bk)
    data = BatchData.new_on_device(
        data=data_dict,
        time=xr.DataArray(
            np.zeros((n_samples, n_time)),
            dims=["sample", "time"],
        ),
        labels=None,
        epoch=epoch,
    )
    return SphericalData(data, area_weights, vertical_coord)


def get_dataset_info(
    img_shape=(5, 5),
    mask_provider=None,
    vertical_coordinate=None,
    horizontal_coordinate=None,
) -> DatasetInfo:
    if horizontal_coordinate is None:
        horizontal_coordinate = LatLonCoordinates(
            lat=torch.zeros(img_shape[-2]),
            lon=torch.zeros(img_shape[-1]),
        )
    if vertical_coordinate is None:
        vertical_coordinate = HybridSigmaPressureCoordinate(
            ak=torch.arange(7), bk=torch.arange(7)
        )
    return DatasetInfo(
        horizontal_coordinates=horizontal_coordinate,
        vertical_coordinate=vertical_coordinate,
        timestep=TIMESTEP,
        mask_provider=mask_provider,
    )


def get_scalar_data(names, value):
    return {n: float(value) for n in names}


def test_stepper_no_train_step_specified():
    stepper = _init_train_stepper(loss=StepLossConfig(type="MSE"))
    stepper._init_for_epoch(0)
    assert stepper._n_forward_steps_sampler is None


def test_stepper_step_int():
    stepper = _init_train_stepper(n_forward_steps=2, loss=StepLossConfig(type="MSE"))
    assert stepper._n_forward_steps_schedule is not None
    stepper._init_for_epoch(0)
    assert stepper._n_forward_steps_sampler is not None


def test_stepper_step_probabilities():
    stepper = _init_train_stepper(
        n_forward_steps=TimeLengthProbabilities(
            outcomes=[
                TimeLengthProbability(steps=1, probability=0.5),
                TimeLengthProbability(steps=2, probability=0.5),
            ]
        ),
        loss=StepLossConfig(type="MSE"),
    )
    assert stepper._n_forward_steps_schedule is not None
    stepper._init_for_epoch(0)
    assert stepper._n_forward_steps_sampler is not None


def test_stepper_step_schedule():
    stepper = _init_train_stepper(
        n_forward_steps=TimeLengthSchedule(
            start_value=1,
            milestones=[
                TimeLengthMilestone(
                    epoch=1,
                    value=TimeLengthProbabilities(
                        outcomes=[
                            TimeLengthProbability(steps=1, probability=0.5),
                            TimeLengthProbability(steps=2, probability=0.5),
                        ]
                    ),
                ),
            ],
        ),
        loss=StepLossConfig(type="MSE"),
    )
    assert stepper._n_forward_steps_schedule is not None
    stepper._init_for_epoch(0)
    assert stepper._n_forward_steps_sampler is not None


def test_train_on_batch_normalizer_changes_only_norm_data():
    torch.manual_seed(0)
    data = get_data(["a", "b"], n_samples=5, n_time=2).data
    normalization_config = NormalizationConfig(
        means=get_scalar_data(["a", "b"], 0.0),
        stds=get_scalar_data(["a", "b"], 1.0),
    )

    def get_stepper_config(normalization_config: NetworkAndLossNormalizationConfig):
        return StepperConfig(
            step=StepSelector(
                type="single_module",
                config=dataclasses.asdict(
                    SingleModuleStepConfig(
                        builder=ModuleSelector(
                            type="prebuilt", config={"module": torch.nn.Identity()}
                        ),
                        in_names=["a", "b"],
                        out_names=["a", "b"],
                        normalization=normalization_config,
                    )
                ),
            ),
        )

    config = get_stepper_config(
        NetworkAndLossNormalizationConfig(network=normalization_config)
    )
    dataset_info = get_dataset_info()
    stepper = _get_train_stepper(config, dataset_info, loss=StepLossConfig(type="MSE"))
    stepped = stepper.train_on_batch(data=data, optimization=NullOptimization())
    assert torch.allclose(
        stepped.gen_data["a"], stepped.normalize(stepped.gen_data)["a"]
    )  # as std=1, mean=0, no change
    config = get_stepper_config(
        NetworkAndLossNormalizationConfig(
            network=NormalizationConfig(
                means=get_scalar_data(["a", "b"], 0.0),
                stds=get_scalar_data(["a", "b"], 2.0),
            ),
            loss=NormalizationConfig(
                means=get_scalar_data(["a", "b"], 0.0),
                stds=get_scalar_data(["a", "b"], 3.0),
            ),
        )
    )
    stepper = _get_train_stepper(config, dataset_info, loss=StepLossConfig(type="MSE"))
    stepped_double_std = stepper.train_on_batch(
        data=data, optimization=NullOptimization()
    )
    assert torch.allclose(
        stepped.gen_data["a"], stepped_double_std.gen_data["a"], rtol=1e-4
    )
    assert torch.allclose(
        stepped.gen_data["a"],
        2.0 * stepped_double_std.normalize(stepped_double_std.gen_data)["a"],
        rtol=1e-4,
    )
    assert torch.allclose(
        stepped.target_data["a"],
        2.0 * stepped_double_std.normalize(stepped_double_std.target_data)["a"],
        rtol=1e-4,
    )
    assert torch.allclose(
        stepped.metrics["loss"], 9.0 * stepped_double_std.metrics["loss"], rtol=1e-4
    )  # mse scales with std**2


def test_train_on_batch_addition_series():
    torch.manual_seed(0)

    n_steps = 4
    data_with_ic: BatchData = get_data(["a", "b"], n_samples=5, n_time=n_steps + 1).data
    config = _get_stepper_config(["a", "b"], ["a", "b"])
    stepper = _get_train_stepper(config, loss=StepLossConfig(type="MSE"))
    stepped = stepper.train_on_batch(data=data_with_ic, optimization=NullOptimization())
    # output of train_on_batch does not include the initial condition
    assert stepped.gen_data["a"].shape == (5, 1, n_steps + 1, 5, 5)

    for i in range(n_steps - 1):
        assert torch.allclose(
            stepped.normalize(stepped.gen_data)["a"][:, :, i] + 1,
            stepped.normalize(stepped.gen_data)["a"][:, :, i + 1],
        )
        assert torch.allclose(
            stepped.normalize(stepped.gen_data)["b"][:, :, i] + 1,
            stepped.normalize(stepped.gen_data)["b"][:, :, i + 1],
        )
        assert torch.allclose(
            stepped.gen_data["a"][:, :, i] + 1, stepped.gen_data["a"][:, :, i + 1]
        )
        assert torch.allclose(
            stepped.gen_data["b"][:, :, i] + 1, stepped.gen_data["b"][:, :, i + 1]
        )
    assert torch.allclose(
        stepped.normalize(stepped.target_data)["a"],
        data_with_ic.data["a"][:, None],
    )
    assert torch.allclose(
        stepped.normalize(stepped.target_data)["b"],
        data_with_ic.data["b"][:, None],
    )


def test_train_on_batch_crps_loss():
    torch.manual_seed(0)

    class AddOne(torch.nn.Module):
        def forward(self, x):
            return x + 1

    n_steps = 4
    data_with_ic: BatchData = get_data(["a", "b"], n_samples=5, n_time=n_steps + 1).data

    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="prebuilt", config={"module": AddOne()}
                    ),
                    in_names=["a", "b"],
                    out_names=["a", "b"],
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means=get_scalar_data(["a", "b"], 0.0),
                            stds=get_scalar_data(["a", "b"], 1.0),
                        ),
                    ),
                )
            ),
        ),
    )
    stepper = _get_train_stepper(
        config,
        n_ensemble=2,
        loss=StepLossConfig(
            type="EnsembleLoss",
            kwargs={
                "crps_weight": 0.1,
                "energy_score_weight": 0.9,
            },
        ),
    )
    stepped = stepper.train_on_batch(data=data_with_ic, optimization=NullOptimization())
    # output of train_on_batch does not include the initial condition
    assert stepped.gen_data["a"].shape == (5, 2, n_steps + 1, 5, 5)


@pytest.mark.parametrize("optimize_last_step_only", [True, False])
def test_train_on_batch_optimize_last_step_only(optimize_last_step_only: bool):
    torch.manual_seed(0)

    forward_calls_grad_enabled = []

    class AddOne(torch.nn.Module):
        def forward(self, x):
            forward_calls_grad_enabled.append(torch.is_grad_enabled())
            return x + 1

    n_steps = 4
    data_with_ic: BatchData = get_data(["a", "b"], n_samples=5, n_time=n_steps + 1).data

    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="prebuilt", config={"module": AddOne()}
                    ),
                    in_names=["a", "b"],
                    out_names=["a", "b"],
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means=get_scalar_data(["a", "b"], 0.0),
                            stds=get_scalar_data(["a", "b"], 1.0),
                        ),
                    ),
                )
            ),
        ),
    )
    stepper = _get_train_stepper(
        config,
        optimize_last_step_only=optimize_last_step_only,
        n_ensemble=2,
        loss=StepLossConfig(
            type="EnsembleLoss",
            kwargs={
                "crps_weight": 0.1,
                "energy_score_weight": 0.9,
            },
        ),
    )
    optimization = unittest.mock.Mock(wraps=NullOptimization())
    stepper.train_on_batch(data=data_with_ic, optimization=optimization)
    if optimize_last_step_only:
        assert len(optimization.accumulate_loss.call_args_list) == 1
        assert forward_calls_grad_enabled[-1]
        assert not any(forward_calls_grad_enabled[:-1])
    else:
        assert len(optimization.accumulate_loss.call_args_list) == n_steps
        assert all(forward_calls_grad_enabled)


def test_train_on_batch_with_prescribed_ocean():
    torch.manual_seed(0)

    n_steps = 3
    data: BatchData = get_data(["a", "b", "mask"], n_samples=5, n_time=n_steps + 1).data
    data.data["mask"][:] = 0
    data.data["mask"][:, :, :, 0] = 1
    config = _get_stepper_config(
        ["a", "b"], ["a", "b"], ocean_config=OceanConfig("b", "mask")
    )
    stepper = _get_train_stepper(config)
    stepped = stepper.train_on_batch(data, optimization=NullOptimization())
    for i in range(n_steps - 1):
        # "a" should be increasing by 1 according to AddOne
        torch.testing.assert_close(
            stepped.normalize(stepped.gen_data)["a"][:, :, i] + 1,
            stepped.normalize(stepped.gen_data)["a"][:, :, i + 1],
        )
        # "b" should be increasing by 1 where the mask says don't prescribe
        # note the 1: selection for the last dimension in following two assertions
        torch.testing.assert_close(
            stepped.normalize(stepped.gen_data)["b"][:, :, i, :, 1:] + 1,
            stepped.normalize(stepped.gen_data)["b"][:, :, i + 1, :, 1:],
        )
        # now check that the 0th index in last dimension has been overwritten
        torch.testing.assert_close(
            stepped.normalize(stepped.gen_data)["b"][:, :, i, :, 0],
            stepped.normalize({"b": stepped.target_data["b"]})["b"][:, :, i, :, 0],
        )


def test_reloaded_stepper_gives_same_prediction():
    torch.manual_seed(0)

    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="SphericalFourierNeuralOperatorNet",
                        config={"scale_factor": 1},
                    ),
                    in_names=["a", "b"],
                    out_names=["a", "b"],
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means=get_scalar_data(["a", "b"], 0.0),
                            stds=get_scalar_data(["a", "b"], 1.0),
                        ),
                    ),
                )
            ),
        ),
    )
    dataset_info = get_dataset_info()
    stepper = config.get_stepper(dataset_info)
    new_stepper = Stepper.from_state(stepper.get_state())
    data = get_data(["a", "b"], n_samples=5, n_time=2).data
    first_result = _init_train_stepper(
        stepper=stepper, loss=StepLossConfig(type="MSE")
    ).train_on_batch(
        data=data,
        optimization=NullOptimization(),
    )
    second_result = _init_train_stepper(
        stepper=new_stepper, loss=StepLossConfig(type="MSE")
    ).train_on_batch(
        data=data,
        optimization=NullOptimization(),
    )
    assert torch.allclose(first_result.metrics["loss"], second_result.metrics["loss"])
    assert torch.allclose(first_result.gen_data["a"], second_result.gen_data["a"])
    assert torch.allclose(first_result.gen_data["b"], second_result.gen_data["b"])
    assert torch.allclose(first_result.target_data["a"], second_result.target_data["a"])
    assert torch.allclose(first_result.target_data["b"], second_result.target_data["b"])


def test_reloaded_stepper_has_metadata():
    stepper = _get_stepper(["a", "b"], ["a", "c"])
    # set the metadata manually for testing
    training_job_metadata = TrainingJob(
        git_sha="1234567890abcdef",
        job_id="some_run_id",
    )
    stepper.training_history.append(training_job_metadata)
    stepper_state = stepper.get_state()
    new_stepper = Stepper.from_state(stepper_state)
    assert new_stepper.training_history == stepper.training_history


def test_stepper_update_training_history():
    stepper = _get_stepper(["a"], ["b"], module_name="Linear")
    assert len(stepper.training_history) == 0

    # first update
    git_sha = "1234567890abcdef"
    job_id = "some_run_id_456"
    training_job = TrainingJob(git_sha=git_sha, job_id=job_id)
    stepper.update_training_history(training_job)
    assert len(stepper.training_history) == 1
    assert stepper.training_history[0].git_sha == git_sha
    assert stepper.training_history[0].job_id == job_id

    # second update with changed stepper module weights
    git_sha_2 = "9876543210fedcba"
    job_id_2 = "some_run_id_789"
    training_job_2 = TrainingJob(git_sha=git_sha_2, job_id=job_id_2)
    stepper._step_obj.modules[0].module.linear.weight.data.add_(0.01)
    stepper.update_training_history(training_job_2)
    assert len(stepper.training_history) == 2
    for i, job in enumerate([training_job, training_job_2]):
        assert stepper.training_history[i].git_sha == job.git_sha
        assert stepper.training_history[i].job_id == job.job_id


class ReturnZerosModule(torch.nn.Module):
    """
    Returns zeros with the correct number of out channels. Creates an unused
    parameter so that optimization has something to gnaw on.
    """

    def __init__(self, n_in_channels, n_out_channels) -> None:
        super().__init__()
        self.n_in_channels = n_in_channels
        self.n_out_channels = n_out_channels
        self._param = torch.nn.Parameter(
            torch.tensor(0.0, device=get_device())
        )  # unused

    def forward(self, x):
        assert torch.all(~torch.isnan(x))
        batch_size, n_channels, nlat, nlon = x.shape
        assert n_channels == self.n_in_channels
        zero = torch.zeros(
            batch_size, self.n_out_channels, nlat, nlon, device=get_device()
        )
        return zero + self._param


def _setup_and_train_on_batch(
    data: BatchData,
    in_names,
    out_names,
    ocean_config: OceanConfig | None,
    optimization_config: OptimizationConfig | None,
    stepper_config_kwargs,
):
    """Sets up the requisite classes to run train_on_batch."""
    module = ReturnZerosModule(len(in_names), len(out_names))

    if optimization_config is None:
        optimization: NullOptimization | Optimization = NullOptimization()
    else:
        optimization = optimization_config.build(modules=[module], max_epochs=2)

    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(type="prebuilt", config={"module": module}),
                    in_names=in_names,
                    out_names=out_names,
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means=get_scalar_data(set(in_names + out_names), 0.0),
                            stds=get_scalar_data(set(in_names + out_names), 1.0),
                        ),
                    ),
                    ocean=ocean_config,
                    **stepper_config_kwargs,
                )
            ),
        ),
    )

    stepper = _get_train_stepper(config, loss=StepLossConfig(type="MSE"))
    return stepper.train_on_batch(data, optimization=optimization)


@pytest.mark.parametrize("has_epoch", [True, False])
@pytest.mark.parametrize("uses_scheduling", [True, False])
def test_train_on_batch_requires_epoch(has_epoch: bool, uses_scheduling: bool):
    in_names, out_names = ["a"], ["a"]
    data = BatchData.new_for_testing(
        names=["a"], n_samples=2, n_timesteps=3, epoch=0 if has_epoch else None
    ).to_device()
    module = ReturnZerosModule(len(in_names), len(out_names))

    optimization_config = OptimizationConfig()
    optimization = optimization_config.build(modules=[module], max_epochs=2)

    if uses_scheduling:
        n_forward_steps: TimeLengthSchedule | TimeLength = TimeLengthSchedule(
            start_value=2,
            milestones=[
                TimeLengthMilestone(epoch=1, value=3),
            ],
        )
    else:
        n_forward_steps = 2

    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(type="prebuilt", config={"module": module}),
                    in_names=in_names,
                    out_names=out_names,
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means=get_scalar_data(set(in_names + out_names), 0.0),
                            stds=get_scalar_data(set(in_names + out_names), 1.0),
                        ),
                    ),
                )
            ),
        ),
    )

    stepper = _get_train_stepper(
        config,
        n_forward_steps=n_forward_steps,
        loss=StepLossConfig(type="MSE"),
    )
    if uses_scheduling and not has_epoch:
        with pytest.raises(EpochNotProvidedError):
            stepper.train_on_batch(data, optimization=optimization)
    else:
        stepper.train_on_batch(data, optimization=optimization)


@pytest.mark.parametrize(
    "is_input,is_output,is_prescribed",
    [
        pytest.param(True, True, True, id="in_out_prescribed"),
        pytest.param(True, True, False, id="in_out_not_prescribed"),
        pytest.param(False, True, False, id="out_only_not_prescribed"),
    ],
)
@pytest.mark.parametrize("n_forward_steps", [1, 2, 3], ids=lambda p: f"k={p}")
@pytest.mark.parametrize("is_train", [True, False], ids=["is_train", ""])
@pytest.mark.parametrize(
    "with_activation_checkpointing", [True, False], ids=["act_ckpt", ""]
)
def test_train_on_batch(
    n_forward_steps,
    is_input,
    is_output,
    is_train,
    is_prescribed,
    with_activation_checkpointing,
):
    in_names, out_names = ["a"], ["a"]
    if is_input:
        in_names.append("b")
    if is_output:
        out_names.append("b")
    all_names = sorted(list(set(in_names).union(set(out_names))))

    if is_prescribed:
        mask_name = "mask"
        all_names.append(mask_name)
        in_names.append(mask_name)
        ocean_config = OceanConfig("b", mask_name)
    else:
        ocean_config = None

    data, _, _ = get_data(all_names, 3, n_forward_steps + 1)

    if is_train:
        if with_activation_checkpointing:
            optimization = OptimizationConfig(
                checkpoint=CheckpointConfig(after_n_forward_steps=n_forward_steps - 1)
            )
        else:
            optimization = OptimizationConfig()
    else:
        optimization = None

    with patch("torch.utils.checkpoint.checkpoint") as mock_checkpoint:
        # have the mock call the module and return the step
        mock_checkpoint.side_effect = lambda f, x, **_: f(x)
        _setup_and_train_on_batch(
            data, in_names, out_names, ocean_config, optimization, {}
        )

        if is_train and with_activation_checkpointing:
            # should be called exactly once, for the final forward step
            mock_checkpoint.assert_called_once()
        else:
            mock_checkpoint.assert_not_called()


@pytest.mark.parametrize("n_forward_steps", [1, 2, 3])
def test_train_on_batch_one_step_aggregator(n_forward_steps):
    in_names, out_names, all_names = ["a"], ["a"], ["a"]
    data, _, _ = get_data(all_names, 3, n_forward_steps + 1)
    nx, ny = 5, 5
    config = _get_stepper_config(
        in_names, out_names, ocean_config=None, module_name="AddOne"
    )
    lat_lon_coordinates = LatLonCoordinates(torch.arange(nx), torch.arange(ny))
    # keep area weights ones for simplicity
    lat_lon_coordinates._area_weights = torch.ones(nx, ny)
    ds_info = DatasetInfo(horizontal_coordinates=lat_lon_coordinates)
    aggregator = OneStepAggregator(ds_info, save_diagnostics=False)

    train_stepper = _get_train_stepper(config)
    stepped = train_stepper.train_on_batch(data, optimization=NullOptimization())
    assert stepped.gen_data["a"].shape[2] == n_forward_steps + 1

    aggregator.record_batch(stepped)
    logs = aggregator.get_logs("one_step")

    gen = data.data["a"].select(dim=1, index=0) + 1
    tar = data.data["a"].select(dim=1, index=1)

    bias = torch.mean(gen - tar)
    assert np.isclose(bias.item(), logs["one_step/mean/weighted_bias/a"])

    residual_gen = torch.ones((5, 5))
    residual_tar = tar[0] - data.data["a"].select(dim=1, index=0)[0]
    residual_imgs = [[residual_gen.cpu().numpy()], [residual_tar.cpu().numpy()]]
    residual_plot = plot_paneled_data(residual_imgs, diverging=True)
    assert np.allclose(
        residual_plot.to_data_array(),
        logs["one_step/snapshot/image-residual/a"].to_data_array(),
    )

    full_field_gen = gen.mean(dim=0)
    full_field_tar = tar.mean(dim=0)
    full_field_plot = plot_paneled_data(
        [
            [full_field_gen.cpu().numpy()],
            [full_field_tar.cpu().numpy()],
        ],
        diverging=False,
    )
    assert np.allclose(
        full_field_plot.to_data_array(),
        logs["one_step/mean_map/image-full-field/a"].to_data_array(),
    )


class Multiply(torch.nn.Module):
    def __init__(self, factor):
        super().__init__()
        self.factor = factor

    def forward(self, x):
        return x * self.factor


@pytest.mark.parametrize(
    "global_only, terms_to_modify, force_positive",
    [
        (True, None, False),
        (True, "precipitation", False),
        (True, "evaporation", False),
        (False, "advection_and_precipitation", False),
        (False, "advection_and_evaporation", False),
        (False, "advection_and_precipitation", True),
    ],
)
@pytest.mark.parametrize("compute_derived_in_train_on_batch", [False, True])
def test_stepper_corrector(
    global_only: bool,
    terms_to_modify,
    force_positive: bool,
    compute_derived_in_train_on_batch: bool,
):
    torch.random.manual_seed(0)
    n_forward_steps = 5
    device = get_device()
    data = {
        "PRESsfc": 10.0 + torch.rand(size=(3, n_forward_steps + 1, 5, 5)),
        "specific_total_water_0": -0.2
        + torch.rand(size=(3, n_forward_steps + 1, 5, 5)),
        "specific_total_water_1": torch.rand(size=(3, n_forward_steps + 1, 5, 5)),
        "PRATEsfc": torch.rand(size=(3, n_forward_steps + 1, 5, 5)),
        "LHTFLsfc": torch.rand(size=(3, n_forward_steps + 1, 5, 5)),
        "tendency_of_total_water_path_due_to_advection": torch.rand(
            size=(3, n_forward_steps + 1, 5, 5)
        ),
    }
    vertical_coordinate = HybridSigmaPressureCoordinate(
        ak=torch.asarray([3.0, 1.0, 0.0]), bk=torch.asarray([0.0, 0.6, 1.0])
    ).to(device)
    horizontal_coordinate = LatLonCoordinates(
        lat=torch.linspace(-89.5, 89.5, 5, device=device),
        lon=torch.linspace(-179.5, 179.5, 5, device=device),
    )
    dataset_info = get_dataset_info(
        vertical_coordinate=vertical_coordinate,
        horizontal_coordinate=horizontal_coordinate,
    )
    gridded_ops = dataset_info.gridded_operations

    if force_positive:
        force_positive_names = ["specific_total_water_0"]
    else:
        force_positive_names = []

    corrector_config = AtmosphereCorrectorConfig(
        conserve_dry_air=True,
        zero_global_mean_moisture_advection=True,
        moisture_budget_correction=terms_to_modify,
        force_positive_names=force_positive_names,
    )

    mean_advection = gridded_ops.area_weighted_mean(
        data["tendency_of_total_water_path_due_to_advection"].to(device)
    )
    assert (mean_advection.abs() > 0.0).all()

    stepper_config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="prebuilt",
                        config={
                            "module": Multiply(1.5).to(device),
                        },
                    ),
                    in_names=list(data.keys()),
                    out_names=list(data.keys()),
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means={key: 0.0 for key in data.keys()},
                            stds={key: 1.0 for key in data.keys()},
                        ),
                    ),
                    corrector=corrector_config,
                )
            ),
        ),
    )
    stepper = _get_train_stepper(stepper_config, dataset_info)
    time = xr.DataArray(
        [
            [
                cftime.DatetimeProlepticGregorian(
                    2000, 1, int(i * 6 // 24) + 1, i * 6 % 24
                )
                for i in range(n_forward_steps + 1)
            ]
            for _ in range(3)
        ],
        dims=["sample", "time"],
    )
    batch_data = BatchData.new_on_cpu(
        data=data,
        time=time,
        labels=None,
        epoch=0,
    ).to_device()
    # run the stepper on the data
    with torch.no_grad():
        stepped = stepper.train_on_batch(
            data=batch_data,
            optimization=NullOptimization(),
            compute_derived_variables=compute_derived_in_train_on_batch,
        )
    if not compute_derived_in_train_on_batch:
        stepped = stepped.compute_derived_variables()
    # check that the budget residual is zero
    budget_residual = stepped.gen_data["total_water_path_budget_residual"]
    if global_only:
        budget_residual = gridded_ops.area_weighted_mean(budget_residual)
    budget_residual = budget_residual.cpu().numpy()
    if terms_to_modify is not None:
        if global_only:
            mean_axis: tuple[int, ...] = (0,)
        else:
            mean_axis = (0, 2, 3)
        # first assert on timeseries, easier to look at
        np.testing.assert_almost_equal(
            np.abs(budget_residual).mean(axis=mean_axis), 0.0, decimal=6
        )
        np.testing.assert_almost_equal(budget_residual, 0.0, decimal=5)

    # check there is no mean advection
    mean_advection = (
        gridded_ops.area_weighted_mean(
            stepped.gen_data["tendency_of_total_water_path_due_to_advection"]
        )
        .cpu()
        .numpy()
    )
    np.testing.assert_almost_equal(mean_advection[:, 1:], 0.0, decimal=6)

    # check that the dry air is conserved
    dry_air = (
        gridded_ops.area_weighted_mean(
            AtmosphereData(
                stepped.gen_data, vertical_coordinate
            ).surface_pressure_due_to_dry_air
        )
        .cpu()
        .numpy()
    )
    dry_air_nonconservation = np.abs(dry_air[:, 1:] - dry_air[:, :-1])
    np.testing.assert_almost_equal(dry_air_nonconservation, 0.0, decimal=3)

    # check that positive forcing is enforced
    if force_positive:
        for name in force_positive_names:
            assert stepped.gen_data[name][:, :, 1:].min() >= 0.0


def _get_stepper_config(
    in_names: list[str],
    out_names: list[str],
    ocean_config: OceanConfig | None = None,
    module_name: Literal["AddOne", "ChannelSum", "RepeatChannel", "Linear"] = "AddOne",
    norm_mean: float = 0.0,
    derived_forcings: DerivedForcingsConfig | None = None,
    **kwargs,
) -> StepperConfig:
    if module_name == "AddOne":

        class AddOne(torch.nn.Module):
            def forward(self, x):
                return x + 1

        module_config = {"module": AddOne()}
    elif module_name == "ChannelSum":
        # convenient for testing stepper with more inputs than outputs
        class ChannelSum(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.last_input: torch.Tensor | None = None

            def forward(self, x):
                self.last_input = x
                return x.sum(dim=-3, keepdim=True)

        module_config = {"module": ChannelSum()}
    elif module_name == "RepeatChannel":
        # convenient for testing stepper with more outputs than inputs
        class RepeatChannel(torch.nn.Module):
            def forward(self, x):
                return x.repeat(1, 2, 1, 1)

        module_config = {"module": RepeatChannel()}
    elif module_name == "Linear":
        # convenient for testing a stepper with parameters
        class Linear(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = torch.nn.Linear(1, 1)

            def forward(self, x):
                return self.linear(x)

        module_config = {"module": Linear()}

    if derived_forcings is None:
        derived_forcings = DerivedForcingsConfig()

    return StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(type="prebuilt", config=module_config),
                    in_names=in_names,
                    out_names=out_names,
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means=get_scalar_data(set(in_names + out_names), norm_mean),
                            stds=get_scalar_data(set(in_names + out_names), 1.0),
                        ),
                    ),
                    ocean=ocean_config,
                    **kwargs,
                )
            ),
        ),
        derived_forcings=derived_forcings,
    )


def _get_stepper(
    in_names: list[str],
    out_names: list[str],
    **kwargs,
) -> Stepper:
    config = _get_stepper_config(in_names, out_names, **kwargs)
    dataset_info = get_dataset_info()
    return config.get_stepper(dataset_info)


def _init_train_stepper(
    stepper: Stepper | None = None,
    **train_config_kwargs,
) -> TrainStepper:
    if stepper is None:
        stepper = unittest.mock.Mock()
    config = TrainStepperConfig(**train_config_kwargs)
    return TrainStepper(stepper=stepper, config=config)


def _get_train_stepper(
    stepper_config: StepperConfig,
    dataset_info: DatasetInfo | None = None,
    **train_config_kwargs,
) -> TrainStepper:
    if dataset_info is None:
        dataset_info = get_dataset_info()
    train_config = TrainStepperConfig(**train_config_kwargs)
    return train_config.get_train_stepper(stepper_config, dataset_info)


def test_step():
    stepper = _get_stepper(["a", "b"], ["a", "b"])
    n_samples = 3
    input_data = {x: torch.rand(n_samples, 5, 5).to(DEVICE) for x in ["a", "b"]}

    output = stepper.step(
        StepArgs(input=input_data, next_step_input_data={}, labels=None)
    )

    torch.testing.assert_close(output["a"], input_data["a"] + 1)
    torch.testing.assert_close(output["b"], input_data["b"] + 1)


def test_step_with_diagnostic():
    stepper = _get_stepper(["a"], ["a", "c"], module_name="RepeatChannel")
    n_samples = 3
    input_data = {"a": torch.rand(n_samples, 5, 5).to(DEVICE)}
    output = stepper.step(
        StepArgs(input=input_data, next_step_input_data={}, labels=None)
    )
    torch.testing.assert_close(output["a"], input_data["a"])
    torch.testing.assert_close(output["c"], input_data["a"])


@pytest.mark.parametrize("residual_prediction", [False, True])
def test_step_with_forcing_and_diagnostic(residual_prediction):
    norm_mean = 2.0
    stepper = _get_stepper(
        ["a", "b"],
        ["a", "c"],
        norm_mean=norm_mean,
        residual_prediction=residual_prediction,
    )
    n_samples = 3
    input_data = {x: torch.rand(n_samples, 5, 5).to(DEVICE) for x in ["a", "b"]}
    output = stepper.step(
        StepArgs(input=input_data, next_step_input_data={}, labels=None)
    )
    if residual_prediction:
        expected_a_output = 2 * input_data["a"] + 1 - norm_mean
    else:
        expected_a_output = input_data["a"] + 1
    torch.testing.assert_close(output["a"], expected_a_output)
    assert "b" not in output
    assert "c" in output


def test_step_with_prescribed_ocean():
    stepper = _get_stepper(
        ["a", "b"], ["a", "b"], ocean_config=OceanConfig("a", "mask")
    )
    input_data = {x: torch.rand(3, 5, 5).to(DEVICE) for x in ["a", "b"]}
    ocean_data = {x: torch.rand(3, 5, 5).to(DEVICE) for x in ["a", "mask"]}
    output = stepper.step(
        StepArgs(input=input_data, next_step_input_data=ocean_data, labels=None)
    )
    expected_a_output = torch.where(
        torch.round(ocean_data["mask"]).to(int) == 1,
        ocean_data["a"],
        input_data["a"] + 1,
    )
    torch.testing.assert_close(output["a"], expected_a_output)
    torch.testing.assert_close(output["b"], input_data["b"] + 1)
    assert set(output) == {"a", "b"}


def test_prescribe_sst_integration():
    """Test that prescribe_sst produces the same prescription as step method."""
    stepper = _get_stepper(
        ["a", "b"], ["a", "b"], ocean_config=OceanConfig("a", "mask")
    )
    input_data = {x: torch.rand(3, 5, 5).to(DEVICE) for x in ["a", "b"]}
    ocean_data = {x: torch.rand(3, 5, 5).to(DEVICE) for x in ["a", "mask"]}
    prescribed_data = stepper.prescribe_sst(
        mask_data=ocean_data,
        gen_data=input_data,
        target_data=ocean_data,
    )
    expected_prescribed_a = torch.where(
        torch.round(ocean_data["mask"]).to(int) == 1,
        ocean_data["a"],
        input_data["a"],  # no +1
    )
    torch.testing.assert_close(prescribed_data["a"], expected_prescribed_a)
    torch.testing.assert_close(prescribed_data["b"], input_data["b"])
    assert set(prescribed_data) == {"a", "b"}


def get_data_for_predict(
    n_steps,
    forcing_names: list[str],
    n_ensemble: int = 1,
) -> tuple[PrognosticState, BatchData]:
    n_samples = 3
    index = xr.date_range("2000", freq="6h", periods=n_steps + 1, use_cftime=True)
    forcing_time = xr.DataArray(np.stack(n_samples * [index]), dims=["sample", "time"])
    input_time = forcing_time.isel(time=[0])

    input_data = (
        BatchData.new_on_device(
            data={"a": torch.rand(n_samples, 1, 5, 5).to(DEVICE)},
            time=input_time,
            labels=None,
        )
        .broadcast_ensemble(n_ensemble)
        .get_start(
            prognostic_names=["a"],
            n_ic_timesteps=1,
        )
    )

    forcing_data = BatchData.new_on_device(
        data={
            name: torch.rand(3, n_steps + 1, 5, 5).to(DEVICE) for name in forcing_names
        },
        time=forcing_time,
        labels=None,
    ).broadcast_ensemble(n_ensemble)
    return input_data, forcing_data


def test_predict():
    stepper = _get_stepper(["a"], ["a"])
    n_steps = 3
    input_data, forcing_data = get_data_for_predict(n_steps, forcing_names=[])
    forcing_data.data = {}
    output, new_input_data = stepper.predict(input_data, forcing_data)
    xr.testing.assert_allclose(forcing_data.time[:, 1:], output.time)
    variable = "a"
    assert output.data[variable].size(dim=1) == n_steps
    torch.testing.assert_close(
        output.data[variable][:, -1],
        input_data.as_batch_data().data[variable][:, 0] + n_steps,
    )
    assert isinstance(new_input_data, PrognosticState)
    new_input_state = new_input_data.as_batch_data()
    assert isinstance(new_input_state, BatchData)
    torch.testing.assert_close(
        new_input_state.data[variable][:, 0], output.data[variable][:, -1]
    )
    assert new_input_state.time.equals(output.time[:, -1:])


@pytest.mark.parametrize("n_ensemble", [1, 3])
def test_predict_with_forcing(n_ensemble):
    stepper = _get_stepper(["a", "b"], ["a"], module_name="ChannelSum")
    n_steps = 3
    input_data, forcing_data = get_data_for_predict(
        n_steps, forcing_names=["b"], n_ensemble=n_ensemble
    )
    output, new_input_data = stepper.predict(input_data, forcing_data)
    assert "b" not in output.data
    assert output.data["a"].size(dim=1) == n_steps
    xr.testing.assert_allclose(forcing_data.time[:, 1:], output.time)
    torch.testing.assert_close(
        output.data["a"][:, 0],
        input_data.as_batch_data().data["a"][:, 0] + forcing_data.data["b"][:, 0],
    )
    assert isinstance(new_input_data, PrognosticState)
    new_input_state = new_input_data.as_batch_data()
    assert isinstance(new_input_state, BatchData)
    torch.testing.assert_close(new_input_state.data["a"][:, 0], output.data["a"][:, -1])
    assert "b" not in new_input_state.data
    for n in range(1, n_steps):
        expected_a_output = output.data["a"][:, n - 1] + forcing_data.data["b"][:, n]
        torch.testing.assert_close(output.data["a"][:, n], expected_a_output)
    xr.testing.assert_equal(output.time, forcing_data.time[:, 1:])
    assert new_input_state.time.equals(output.time[:, -1:])


@pytest.mark.parametrize(
    "in_names,out_names,prescribed,module_name",
    [
        (["a", "b"], ["a"], ["a"], "AddOne"),
    ],
)
def test_predict_with_prescribed_prognostic(
    in_names, out_names, prescribed, module_name
):
    n_steps = 3
    stepper = _get_stepper(
        in_names,
        out_names,
        module_name=module_name,
        prescribed_prognostic_names=prescribed,
    )

    input_data, forcing_data = get_data_for_predict(
        n_steps, forcing_names=list(set(in_names + out_names))
    )

    output, _ = stepper.predict(input_data, forcing_data)

    # Shape check
    for name in prescribed:
        assert output.data[name].size(1) == n_steps

    # Value check
    for name in prescribed:
        torch.testing.assert_close(
            output.data[name], forcing_data.data[name][:, 1 : n_steps + 1]
        )


def test_prescribed_prognostic_config_validation_raises():
    with pytest.raises(ValueError) as err:
        SingleModuleStepperConfig(
            builder=ModuleSelector(
                type="prebuilt", config={"module": torch.nn.Identity()}
            ),
            in_names=["a"],
            out_names=["a"],
            normalization=NormalizationConfig(means={"a": 0.0}, stds={"a": 1.0}),
            prescribed_prognostic_names=["b"],
        )
    assert "prescribed_prognostic_name" in str(err.value)
    assert "out_names" in str(err.value)


def test_get_forcing_window_data_requirements_includes_prescribed_names():
    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="prebuilt", config={"module": torch.nn.Identity()}
                    ),
                    in_names=["a", "b"],
                    out_names=["a"],
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means={"a": 0.0, "b": 0.0},
                            stds={"a": 1.0, "b": 1.0},
                        ),
                    ),
                    prescribed_prognostic_names=["a"],
                )
            ),
        ),
        derived_forcings=DerivedForcingsConfig(),
    )
    requirements = config.get_forcing_window_data_requirements(n_forward_steps=5)
    assert "a" in requirements.names
    assert "b" in requirements.names


def test_predict_with_ocean():
    stepper = _get_stepper(["a"], ["a"], ocean_config=OceanConfig("a", "mask"))
    n_steps = 3
    input_data, forcing_data = get_data_for_predict(
        n_steps, forcing_names=["a", "mask"]
    )
    output, new_input_data = stepper.predict(input_data, forcing_data)
    xr.testing.assert_allclose(forcing_data.time[:, 1:], output.time)
    assert "mask" not in output.data
    assert output.data["a"].size(dim=1) == n_steps
    for n in range(n_steps):
        previous_a = (
            input_data.as_batch_data().data["a"][:, 0]
            if n == 0
            else output.data["a"][:, n - 1]
        )
        expected_a_output = torch.where(
            torch.round(forcing_data.data["mask"][:, n + 1]).to(int) == 1,
            forcing_data.data["a"][:, n + 1],
            previous_a + 1,
        )
        torch.testing.assert_close(output.data["a"][:, n], expected_a_output)
    assert isinstance(new_input_data, PrognosticState)
    new_input_state = new_input_data.as_batch_data()
    assert isinstance(new_input_state, BatchData)
    torch.testing.assert_close(new_input_state.data["a"][:, 0], output.data["a"][:, -1])
    assert new_input_state.time.equals(output.time[:, -1:])


def test_next_step_forcing_names():
    stepper = _get_stepper(
        ["a", "b", "c"],
        ["a"],
        module_name="ChannelSum",
        next_step_forcing_names=["c"],
    )
    input_data, forcing_data = get_data_for_predict(n_steps=1, forcing_names=["b", "c"])
    stepper.predict(input_data, forcing_data)
    assert len(stepper.modules) == 1
    torch.testing.assert_close(
        stepper.modules[0].module.last_input[:, 1, :],
        forcing_data.data["b"][:, 0],
    )
    torch.testing.assert_close(
        stepper.modules[0].module.last_input[:, 2, :],
        forcing_data.data["c"][:, 1],
    )


def test_prepend_initial_condition():
    nt = 3
    batch_size = 3
    n_ensemble = 2
    x = torch.rand(3, n_ensemble, nt, 5).to(DEVICE)

    def normalize(x):
        result = {k: (v - 1) / 2 for k, v in x.items()}
        return result

    stepped = TrainOutput(
        gen_data=EnsembleTensorDict({"a": x, "b": x + 1}),
        target_data=EnsembleTensorDict({"a": x[:, :1] + 2, "b": x[:, :1] + 3}),
        time=xr.DataArray(np.zeros((batch_size, nt)), dims=["sample", "time"]),
        metrics={"loss": torch.tensor(0.0)},
        normalize=normalize,
    )
    ic_data = {
        # no sample dim in initial condition
        "a": torch.rand(batch_size, 1, 5).to(DEVICE),
        "b": torch.rand(batch_size, 1, 5).to(DEVICE),
    }
    ic = BatchData.new_on_device(
        data=ic_data,
        time=xr.DataArray(np.zeros((batch_size, 1)), dims=["sample", "time"]),
        labels=None,
    ).get_start(
        prognostic_names=["a", "b"],
        n_ic_timesteps=1,
    )
    prepended = stepped.prepend_initial_condition(ic)
    for v in ["a", "b"]:
        assert torch.allclose(prepended.gen_data[v][:, :, :1], ic_data[v][:, None, ...])
        assert torch.allclose(
            prepended.target_data[v][:, :, :1], ic_data[v][:, None, ...]
        )


def test_stepper_from_state_using_resnorm_has_correct_normalizer():
    # If originally configured with a residual normalizer, the
    # stepper loaded from state should have the appropriately combined
    # full field and residual values in its loss_normalizer
    torch.manual_seed(0)
    full_field_means = {"a": 0.0, "b": 0.0, "diagnostic": 0.0}
    full_field_stds = {"a": 1.0, "b": 1.0, "diagnostic": 1.0}
    # residual scalings might have diagnostic variables but the stepper
    # should detect which prognostic variables to use from the set
    residual_means = {"a": 1.0, "b": 1.0, "diagnostic": 1.0}
    residual_stds = {"a": 2.0, "b": 2.0, "diagnostic": 2.0}
    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="SphericalFourierNeuralOperatorNet",
                        config={"scale_factor": 1},
                    ),
                    in_names=["a", "b"],
                    out_names=["a", "b", "diagnostic"],
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means=full_field_means, stds=full_field_stds
                        ),
                        residual=NormalizationConfig(
                            means=residual_means, stds=residual_stds
                        ),
                    ),
                )
            ),
        )
    )
    orig_stepper = config.get_stepper(dataset_info=get_dataset_info())
    stepper_from_state = Stepper.from_state(orig_stepper.get_state())

    for stepper in [orig_stepper, stepper_from_state]:
        loss = stepper.build_loss(StepLossConfig())
        assert loss._normalizer.means == {
            **residual_means,
            "diagnostic": full_field_means["diagnostic"],
        }
        assert loss._normalizer.stds == {
            **residual_stds,
            "diagnostic": full_field_stds["diagnostic"],
        }
        assert stepper.normalizer.means == full_field_means
        assert stepper.normalizer.stds == full_field_stds


LOAD_STEPPER_TESTS = {
    "override-ocean": (
        None,
        None,
        EMPTY_DERIVED_FORCINGS_CONFIG,
        OCEAN_CONFIG,
        "keep",
        "keep",
        OCEAN_CONFIG,
        None,
        EMPTY_DERIVED_FORCINGS_CONFIG,
    ),
    "persist-ocean": (
        OCEAN_CONFIG,
        None,
        EMPTY_DERIVED_FORCINGS_CONFIG,
        "keep",
        "keep",
        "keep",
        OCEAN_CONFIG,
        None,
        EMPTY_DERIVED_FORCINGS_CONFIG,
    ),
    "override-multi-call": (
        None,
        None,
        EMPTY_DERIVED_FORCINGS_CONFIG,
        "keep",
        MULTI_CALL_CONFIG,
        "keep",
        None,
        MULTI_CALL_CONFIG,
        EMPTY_DERIVED_FORCINGS_CONFIG,
    ),
    "persist-multi-call": (
        None,
        MULTI_CALL_CONFIG,
        EMPTY_DERIVED_FORCINGS_CONFIG,
        "keep",
        "keep",
        "keep",
        None,
        MULTI_CALL_CONFIG,
        EMPTY_DERIVED_FORCINGS_CONFIG,
    ),
    "override-all": (
        None,
        None,
        EMPTY_DERIVED_FORCINGS_CONFIG,
        OCEAN_CONFIG,
        MULTI_CALL_CONFIG,
        DERIVED_FORCINGS_CONFIG,
        OCEAN_CONFIG,
        MULTI_CALL_CONFIG,
        DERIVED_FORCINGS_CONFIG,
    ),
    "persist-all": (
        OCEAN_CONFIG,
        MULTI_CALL_CONFIG,
        DERIVED_FORCINGS_CONFIG,
        "keep",
        "keep",
        "keep",
        OCEAN_CONFIG,
        MULTI_CALL_CONFIG,
        DERIVED_FORCINGS_CONFIG,
    ),
}


@pytest.mark.parametrize(
    (
        "serialized_ocean_config",
        "serialized_multi_call_config",
        "serialized_derived_forcings_config",
        "overriding_ocean_config",
        "overriding_multi_call_config",
        "overriding_derived_forcings_config",
        "expected_ocean_config",
        "expected_multi_call_config",
        "expected_derived_forcings_config",
    ),
    list(LOAD_STEPPER_TESTS.values()),
    ids=list(LOAD_STEPPER_TESTS.keys()),
)
def test_load_stepper_and_load_stepper_config(
    tmp_path: pathlib.Path,
    serialized_ocean_config: OceanConfig | None,
    serialized_multi_call_config: MultiCallConfig | None,
    serialized_derived_forcings_config: DerivedForcingsConfig,
    overriding_ocean_config: Literal["keep"] | OceanConfig | None,
    overriding_multi_call_config: Literal["keep"] | MultiCallConfig | None,
    overriding_derived_forcings_config: Literal["keep"] | DerivedForcingsConfig,
    expected_ocean_config: OceanConfig | None,
    expected_multi_call_config: MultiCallConfig | None,
    expected_derived_forcings_config: DerivedForcingsConfig,
    very_fast_only: bool,
):
    if very_fast_only:
        pytest.skip("Skipping non-fast tests")
    in_names = ["co2", "var", "a", "b"]
    fluxes = ["ULWRFtoa"]
    out_names = ["var", "a"] + fluxes
    stepper_path = tmp_path / "stepper"
    n_forward_steps = 8

    horizontal = [DimSize("grid_yt", 4), DimSize("grid_xt", 8)]
    dim_sizes = DimSizes(
        n_time=n_forward_steps + 1,
        horizontal=horizontal,
        nz_interface=4,
    )
    if serialized_multi_call_config is not None:
        multi_call_names = serialized_multi_call_config.names
    else:
        multi_call_names = []
    if (
        overriding_multi_call_config is not None
        and overriding_multi_call_config != "keep"
    ):
        multi_call_names += overriding_multi_call_config.names
    save_plus_one_stepper(
        stepper_path,
        in_names,
        out_names,
        normalization_names=set(in_names + out_names + multi_call_names),
        mean=0.0,
        std=1.0,
        data_shape=dim_sizes.shape_nd,
        ocean=serialized_ocean_config,
        multi_call=serialized_multi_call_config,
        derived_forcings=serialized_derived_forcings_config,
    )

    # First check that load_stepper_config and load_stepper functions load
    # the unmodified stepper when no StepperOverrideConfig is passed.
    stepper_config = load_stepper_config_with_override(stepper_path)
    validate_stepper_config(
        stepper_config, serialized_ocean_config, serialized_multi_call_config
    )

    stepper = load_stepper(stepper_path)
    validate_stepper_ocean(stepper, serialized_ocean_config)
    validate_stepper_multi_call(stepper, serialized_multi_call_config)
    assert stepper.config.derived_forcings == serialized_derived_forcings_config

    # Then check that they load the appropriately modified config and
    # stepper when provided with a StepperOverrideConfig.
    stepper_override = StepperOverrideConfig(
        ocean=overriding_ocean_config,
        multi_call=overriding_multi_call_config,
        derived_forcings=overriding_derived_forcings_config,
    )

    stepper_config = load_stepper_config_with_override(stepper_path, stepper_override)
    validate_stepper_config(
        stepper_config, expected_ocean_config, expected_multi_call_config
    )

    stepper = load_stepper(stepper_path, stepper_override)
    validate_stepper_ocean(stepper, expected_ocean_config)
    validate_stepper_multi_call(stepper, expected_multi_call_config)
    assert stepper.config.derived_forcings == expected_derived_forcings_config
    assert isinstance(stepper.forcing_deriver, ForcingDeriver)


def _get_inner_single_module_config(stepper: Stepper):
    """Get the inner SingleModuleStep config from a stepper
    (MultiCallStep or single)."""
    from fme.core.step.multi_call import MultiCallStep

    if isinstance(stepper._step_obj, MultiCallStep):
        return stepper._step_obj._wrapped_step.config
    return stepper._step_obj.config


def validate_stepper_prescribed_prognostic_names(
    stepper: Stepper, expected: list[str]
) -> None:
    """Assert the stepper's inner step config has the given
    prescribed_prognostic_names."""
    config = _get_inner_single_module_config(stepper)
    assert config.prescribed_prognostic_names == expected


def test_load_stepper_with_prescribed_prognostic_override(
    tmp_path: pathlib.Path, very_fast_only: bool
):
    """Loading with StepperOverrideConfig(prescribed_prognostic_names=...) applies the
    override."""
    if very_fast_only:
        pytest.skip("Skipping non-fast tests")
    in_names = ["co2", "var", "a", "b"]
    out_names = ["var", "a"]
    stepper_path = tmp_path / "stepper"
    horizontal = [DimSize("grid_yt", 4), DimSize("grid_xt", 8)]
    dim_sizes = DimSizes(
        n_time=9,
        horizontal=horizontal,
        nz_interface=4,
    )
    save_plus_one_stepper(
        stepper_path,
        in_names,
        out_names,
        normalization_names=set(in_names + out_names),
        mean=0.0,
        std=1.0,
        data_shape=dim_sizes.shape_nd,
    )

    # Load without override: prescribed_prognostic_names should be [] (default).
    stepper = load_stepper(stepper_path)
    validate_stepper_prescribed_prognostic_names(stepper, [])

    # Load with override: prescribed_prognostic_names should be ["var"].
    stepper_override = StepperOverrideConfig(prescribed_prognostic_names=["var"])
    stepper = load_stepper(stepper_path, stepper_override)
    validate_stepper_prescribed_prognostic_names(stepper, ["var"])

    # Predict with forcing including "var"; output "var" should come from forcing.
    n_steps = 2
    n_samples = 3
    index = xr.date_range("2000", freq="6h", periods=n_steps + 1, use_cftime=True)
    forcing_time = xr.DataArray(np.stack(n_samples * [index]), dims=["sample", "time"])
    input_time = forcing_time.isel(time=[0])
    input_data = BatchData.new_on_device(
        data={
            "var": torch.rand(n_samples, 1, 4, 8).to(DEVICE),
            "a": torch.rand(n_samples, 1, 4, 8).to(DEVICE),
        },
        time=input_time,
        labels=None,
    ).get_start(prognostic_names=["var", "a"], n_ic_timesteps=1)
    forcing_data = BatchData.new_on_device(
        data={
            name: torch.rand(3, n_steps + 1, 4, 8).to(DEVICE)
            for name in ["co2", "var", "a", "b"]
        },
        time=forcing_time,
        labels=None,
    )
    output, _ = stepper.predict(input_data, forcing_data)
    expected_var = forcing_data.data["var"][:, 1 : n_steps + 1]
    torch.testing.assert_close(output.data["var"], expected_var)


class _LargeLinear(torch.nn.Module):
    """Module defined at module scope so it can be pickled by torch.save."""

    def __init__(self, size: int):
        super().__init__()
        self.linear = torch.nn.Linear(size, size)

    def forward(self, x):
        return self.linear(x)


@pytest.mark.skipif(
    not torch.cuda.is_available(), reason="measures peak GPU memory allocation"
)
def test_load_stepper_does_not_double_buffer_on_gpu(tmp_path: pathlib.Path):
    """Loading a stepper should not briefly hold two copies of its weights
    on GPU.

    Before changing torch.load to map_location="cpu", the checkpoint was
    loaded directly to GPU, and Stepper.from_state then created new on-device
    tensors that temporarily coexisted with the originals. Peak GPU allocation
    during load_stepper should stay close to the stepper's on-device size.
    """

    in_names = ["var"]
    out_names = ["var"]
    size = 1024  # ~4 MiB of float32 weights
    # Keep img_shape small so grid-sized allocations inside
    # LatLonOperations (area_weights buffers, validation temporaries) do not
    # dominate the peak and obscure what this test is checking.
    img_shape = (5, 5)
    stepper_path = tmp_path / "stepper"

    # Build and save the stepper inside a helper so its locals are released
    # before we start measuring. In particular, StepperConfig pins on-device
    # copies of the module via StepSelector._step_config_instance and (after
    # get_state()'s call to as_loaded_dict) via the re-assigned
    # StepSelector.config dict. pytest's assertion rewriting keeps test-body
    # locals alive past `del`, so we stash them in a separate frame.
    def _save_stepper():
        config = StepperConfig(
            step=StepSelector(
                type="single_module",
                config=dataclasses.asdict(
                    SingleModuleStepConfig(
                        builder=ModuleSelector(
                            type="prebuilt", config={"module": _LargeLinear(size)}
                        ),
                        in_names=in_names,
                        out_names=out_names,
                        normalization=NetworkAndLossNormalizationConfig(
                            network=NormalizationConfig(
                                means={n: 0.0 for n in in_names + out_names},
                                stds={n: 1.0 for n in in_names + out_names},
                            ),
                        ),
                    ),
                ),
            ),
        )
        dataset_info = get_dataset_info(img_shape=img_shape)
        stepper = config.get_stepper(dataset_info=dataset_info)
        torch.save({"stepper": stepper.get_state()}, stepper_path)

    _save_stepper()
    gc.collect()
    torch.cuda.empty_cache()

    # Some tensors from the save phase persist in PyTorch's C++ layer past
    # `del` + `gc.collect()` and aren't reachable via `gc.get_objects()`.
    # Measure peak growth during load relative to this baseline rather than
    # assuming it starts at zero.
    baseline_alloc = torch.cuda.memory_allocated()

    with benchmark_memory() as bm:
        loaded = load_stepper(stepper_path)

    step_obj = loaded._step_obj
    assert isinstance(step_obj, SingleModuleStep)
    torch_module = step_obj.module.torch_module
    model_size = sum(
        p.element_size() * p.nelement() for p in torch_module.parameters()
    ) + sum(b.element_size() * b.nelement() for b in torch_module.buffers())

    # Before the fix, peak growth would be ~2x the model size because
    # torch.load placed one copy on GPU and Stepper.from_state created a
    # second copy on GPU before the first was released.
    peak_growth = bm.result.max_alloc - baseline_alloc
    assert peak_growth < 1.5 * model_size, (
        f"peak GPU alloc growth during load_stepper ({peak_growth} bytes, "
        f"peak={bm.result.max_alloc}, baseline={baseline_alloc}) exceeded 1.5x "
        f"the loaded model size ({model_size} bytes), "
        "suggesting a second copy of the weights was briefly held on GPU"
    )


def get_regression_stepper_and_data(
    crps_training: bool = False,
) -> tuple[TrainStepper, BatchData]:
    in_names = ["a", "b"]
    out_names = ["b", "c"]
    n_forward_steps = 2
    n_samples = 3
    img_shape = (9, 18)
    device = get_device()

    all_names = list(set(in_names + out_names))

    if crps_training:
        loss = StepLossConfig(
            type="EnsembleLoss",
            kwargs={"crps_weight": 1.0, "energy_score_weight": 0.0},
        )
        n_ensemble: int = 2
    else:
        loss = StepLossConfig(type="MSE")
        n_ensemble = 1

    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="SphericalFourierNeuralOperatorNet",
                        config=dataclasses.asdict(
                            SphericalFourierNeuralOperatorBuilder(
                                embed_dim=16,
                                num_layers=2,
                            )
                        ),
                    ),
                    in_names=in_names,
                    out_names=out_names,
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means={n: 0.1 for n in all_names},
                            stds={n: 1.1 for n in all_names},
                        ),
                    ),
                    ocean=None,
                )
            ),
        ),
    )

    dataset_info = get_dataset_info(img_shape=img_shape)
    train_stepper = _get_train_stepper(
        config, dataset_info, loss=loss, n_ensemble=n_ensemble
    )
    data = BatchData.new_on_device(
        data={
            "a": torch.randn(n_samples, n_forward_steps + 1, *img_shape).to(device),
            "b": torch.randn(n_samples, n_forward_steps + 1, *img_shape).to(device),
            "c": torch.randn(n_samples, n_forward_steps + 1, *img_shape).to(device),
        },
        time=xr.DataArray(
            np.zeros((n_samples, n_forward_steps + 1)),
            dims=["sample", "time"],
        ),
        labels=None,
        epoch=0,
        horizontal_dims=["lat", "lon"],
    )
    return train_stepper, data


@pytest.mark.parametrize(
    "use_optimization",
    [
        pytest.param(True, id="optimization"),
        pytest.param(False, id="no_optimization"),
    ],
)
@pytest.mark.parametrize(
    "crps_training",
    [
        pytest.param(True, id="crps_training"),
        pytest.param(False, id="no_crps_training"),
    ],
)
def test_stepper_train_on_batch_regression(use_optimization: bool, crps_training: bool):
    torch.manual_seed(0)
    train_stepper, data = get_regression_stepper_and_data(crps_training=crps_training)
    if use_optimization:
        optimization_config = OptimizationConfig(
            optimizer_type="Adam",
            lr=0.0001,
        )
        optimization: OptimizationABC = optimization_config.build(
            train_stepper.modules, max_epochs=1
        )
    else:
        optimization = NullOptimization()
    result1 = train_stepper.train_on_batch(data, optimization)
    result2 = train_stepper.train_on_batch(data, optimization)
    output_dict = get_train_outputs_tensor_dict(result1, result2)
    filename = f"testdata/stepper_train_on_batch_regression-{use_optimization}.pt"
    if crps_training:
        filename = filename.replace(".pt", "-crps.pt")
    validate_tensor_dict(
        output_dict,
        os.path.join(
            DIR,
            filename,
        ),
    )


def test_stepper_predict_regression():
    torch.manual_seed(0)
    train_stepper, data = get_regression_stepper_and_data()
    stepper = train_stepper._stepper
    initial_condition = data.get_start(
        prognostic_names=["b"],
        n_ic_timesteps=1,
    )
    output, next_state = stepper.predict(
        initial_condition, data, compute_derived_variables=True
    )
    output_dict = get_predict_output_tensor_dict(output, next_state)
    validate_tensor_dict(
        output_dict,
        os.path.join(DIR, f"testdata/stepper_predict_regression.pt"),
    )


def get_predict_output_tensor_dict(
    output: BatchData, next_state: PrognosticState
) -> dict[str, torch.Tensor]:
    return flatten_dict(
        {
            "output": output.data,
            "next_state": next_state.as_batch_data().data,
        }
    )


def get_train_outputs_tensor_dict(
    step_1: TrainOutput, step_2: TrainOutput
) -> dict[str, torch.Tensor]:
    return flatten_dict(
        {
            "step_1": _get_train_output_tensor_dict(step_1),
            "step_2": _get_train_output_tensor_dict(step_2),
        }
    )


def flatten_dict(
    d: Mapping[str, Mapping[str, torch.Tensor]],
) -> dict[str, torch.Tensor]:
    return_dict = {}
    for k, v in d.items():
        for k2, v2 in v.items():
            return_dict[f"{k}.{k2}"] = v2
    return return_dict


def _get_train_output_tensor_dict(data: TrainOutput) -> dict[str, torch.Tensor]:
    return_dict = {}
    for k, v in data.metrics.items():
        return_dict[f"metrics.{k}"] = v
    for k, v in data.gen_data.items():
        return_dict[f"gen_data.{k}"] = v
    for k, v in data.target_data.items():
        assert v.shape[1] == 1
        return_dict[f"target_data.{k}"] = v
    return return_dict


def test_set_train_eval():
    stepper = _get_stepper(["a"], ["a"])
    for module in stepper.modules:
        assert module.training
    stepper.set_eval()
    for module in stepper.modules:
        assert not module.training
    stepper.set_train()
    for module in stepper.modules:
        assert module.training


def test_get_serialized_stepper_vertical_coordinate():
    stepper = _get_stepper(["a"], ["a"])
    state = stepper.get_state()
    vertical_coordinate = get_serialized_stepper_vertical_coordinate(state)
    assert isinstance(vertical_coordinate, VerticalCoordinate)


def _get_stepper_with_input_masking(dataset_info_has_mask_provider: bool = True):
    # basic StepperConfig with input_masking configured
    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="prebuilt", config={"module": torch.nn.Identity()}
                    ),
                    in_names=["a"],
                    out_names=["a"],
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means={"a": 0.0},
                            stds={"a": 1.0},
                        ),
                    ),
                )
            ),
        ),
        input_masking=StaticMaskingConfig(mask_value=0, fill_value=0.0),
    )
    mask_provider: MaskProvider | None = None
    if dataset_info_has_mask_provider:
        mask_provider = MaskProvider()
    return config.get_stepper(get_dataset_info(mask_provider=mask_provider))


def test_get_stepper_with_input_masking():
    # check that no error is raised when building a stepper with input_masking
    # configured when the vertical coordinate is a mask_provider

    # no error raised
    _ = _get_stepper_with_input_masking(dataset_info_has_mask_provider=True)


def test_get_stepper_with_input_masking_raises():
    # no get_mask_tensor_for method on vertical coordinate raises error when
    # input_masking provided in config
    with pytest.raises(MissingDatasetInfo, match="mask_provider"):
        _ = _get_stepper_with_input_masking(dataset_info_has_mask_provider=False)


@pytest.mark.parametrize("n_ensemble", [1, 3])
def test_predict_with_derived_forcing(n_ensemble):
    insolation = InsolationConfig(INSOLATION_NAME, SOLAR_CONSTANT_AS_NAME)
    derived_forcings = DerivedForcingsConfig(insolation=insolation)
    in_names = [SOLAR_CONSTANT_NAME, INSOLATION_NAME]
    out_names = ["a"]
    stepper = _get_stepper(
        in_names,
        out_names,
        derived_forcings=derived_forcings,
    )
    n_steps = 3
    forcing_names = [SOLAR_CONSTANT_NAME]
    input_data, forcing_data = get_data_for_predict(
        n_steps, forcing_names=forcing_names, n_ensemble=n_ensemble
    )
    # Given that insolation is an input, but is not in the provided forcing data
    # this test would fail if it was not derived. Since insolation does not end
    # up in the output of predict, there is nothing else we can really test
    # here.
    _, _ = stepper.predict(input_data, forcing_data)


@pytest.mark.parametrize("n_ensemble", [1, 3])
def test_predict_paired_with_derived_forcing(n_ensemble):
    insolation = InsolationConfig(INSOLATION_NAME, SOLAR_CONSTANT_AS_NAME)
    derived_forcings = DerivedForcingsConfig(insolation=insolation)
    in_names = [SOLAR_CONSTANT_NAME, INSOLATION_NAME]
    out_names = ["a"]
    stepper = _get_stepper(
        in_names,
        out_names,
        derived_forcings=derived_forcings,
    )
    n_steps = 3
    forcing_names = [SOLAR_CONSTANT_NAME]
    input_data, forcing_data = get_data_for_predict(
        n_steps, forcing_names=forcing_names, n_ensemble=n_ensemble
    )
    output, _ = stepper.predict_paired(input_data, forcing_data)
    assert INSOLATION_NAME in output.forcing


def test_reloaded_stepper_has_derived_forcings():
    in_names = [INSOLATION_NAME]
    out_names = ["a"]
    stepper = _get_stepper(
        in_names,
        out_names,
        derived_forcings=DERIVED_FORCINGS_CONFIG,
    )
    stepper_state = stepper.get_state()
    new_stepper = Stepper.from_state(stepper_state)
    assert new_stepper.config.derived_forcings == stepper.config.derived_forcings


def test_replace_derived_forcings_error():
    in_names = [INSOLATION_NAME]
    out_names = ["a"]
    stepper = _get_stepper(
        in_names,
        out_names,
        derived_forcings=DERIVED_FORCINGS_CONFIG,
    )
    replacement_insolation = InsolationConfig("foo", SOLAR_CONSTANT_AS_VALUE)
    replacement = DerivedForcingsConfig(insolation=replacement_insolation)

    with pytest.raises(ValueError, match="insolation_name"):
        stepper.config.replace_derived_forcings(replacement)


OCEAN_TIMESTEP = datetime.timedelta(days=5)
N_OCEAN_LEVELS = 2


def _get_ocean_dataset_info(
    img_shape=(5, 5),
) -> DatasetInfo:
    """Create a DatasetInfo with DepthCoordinate for ocean testing."""
    horizontal_coordinate = LatLonCoordinates(
        lat=torch.linspace(-89.5, 89.5, img_shape[0], device=DEVICE),
        lon=torch.linspace(0, 360, img_shape[1], device=DEVICE),
    )
    # Create depth coordinate with 2 levels
    idepth = torch.tensor([0.0, 10.0, 50.0], device=DEVICE)  # interface depths
    mask = torch.ones(*img_shape, N_OCEAN_LEVELS, device=DEVICE)  # all ocean
    depth_coordinate = DepthCoordinate(idepth=idepth, mask=mask)

    return DatasetInfo(
        horizontal_coordinates=horizontal_coordinate,
        vertical_coordinate=depth_coordinate,
        timestep=OCEAN_TIMESTEP,
    )


def _get_ocean_stepper(
    in_names: list[str],
    out_names: list[str],
    next_step_forcing_names: list[str],
) -> Stepper:
    """Create an ocean stepper for testing derived variables.

    Args:
        in_names: Input variable names.
        out_names: Output variable names.
        next_step_forcing_names: Names of forcing variables taken from next timestep.

    Returns:
        A configured ocean Stepper.
    """

    class PlusOne(torch.nn.Module):
        """Adds 1 to the input."""

        def forward(self, x):
            return x + 1

    all_names = list(set(in_names + out_names))
    kwargs = {}
    if next_step_forcing_names is not None:
        kwargs["next_step_forcing_names"] = next_step_forcing_names

    config = StepperConfig(
        step=StepSelector(
            type="single_module",
            config=dataclasses.asdict(
                SingleModuleStepConfig(
                    builder=ModuleSelector(
                        type="prebuilt", config={"module": PlusOne()}
                    ),
                    in_names=in_names,
                    out_names=out_names,
                    normalization=NetworkAndLossNormalizationConfig(
                        network=NormalizationConfig(
                            means={name: 0.0 for name in all_names},
                            stds={name: 1.0 for name in all_names},
                        ),
                    ),
                    corrector=CorrectorSelector("ocean_corrector", {}),
                    next_step_forcing_names=next_step_forcing_names,
                )
            ),
        ),
    )
    dataset_info = _get_ocean_dataset_info()
    return config.get_stepper(dataset_info)


def _get_ocean_data_for_predict_paired(
    n_steps: int,
    in_names: list[str],
    out_names: list[str],
    n_samples: int = 2,
    img_shape: tuple[int, int] = (5, 5),
) -> tuple[PrognosticState, BatchData]:
    """Create test data for ocean stepper prediction.

    Args:
        n_steps: Number of forward steps.
        in_names: Input variable names.
        out_names: Output variable names.
        n_samples: Number of samples in batch.
        img_shape: Shape of spatial dimensions.

    Returns:
        Tuple of (initial_condition, data).
    """
    n_ic_timesteps = 1
    total_timesteps = n_ic_timesteps + n_steps

    # Create data with a time dimension
    data_dict = {}
    all_names = list(set(in_names + out_names))
    for name in all_names:
        # Use deterministic values so we can verify derived variables
        data_dict[name] = torch.rand(
            n_samples, total_timesteps, *img_shape, device=DEVICE
        )

    # Set thetao values to known values for testing OHC computation
    # This ensures OHC is predictable and we can verify tendency computation
    if "thetao_0" in data_dict:
        # Temperature at level 0: constant 20°C
        data_dict["thetao_0"] = torch.full(
            (n_samples, total_timesteps, *img_shape), 20.0, device=DEVICE
        )
    if "thetao_1" in data_dict:
        # Temperature at level 1: constant 15°C
        data_dict["thetao_1"] = torch.full(
            (n_samples, total_timesteps, *img_shape), 15.0, device=DEVICE
        )

    # Set forcing variables to known values
    if "hfds_forcing" in data_dict:
        data_dict["hfds_forcing"] = torch.full(
            (n_samples, total_timesteps, *img_shape), 99.0, device=DEVICE
        ) + torch.arange(total_timesteps, device=DEVICE).view(
            total_timesteps, 1, 1
        )  # add a trend
    if "hfds" in data_dict:
        data_dict["hfds"] = torch.full(
            (n_samples, total_timesteps, *img_shape), 100.0, device=DEVICE
        )
    if "hfgeou" in data_dict:
        data_dict["hfgeou"] = torch.full(
            (n_samples, total_timesteps, *img_shape), 0.05, device=DEVICE
        )
    if "sea_surface_fraction" in data_dict:
        data_dict["sea_surface_fraction"] = torch.ones(
            n_samples, total_timesteps, *img_shape, device=DEVICE
        )
    if "land_fraction" in data_dict:
        data_dict["land_fraction"] = torch.ones(
            n_samples, total_timesteps, *img_shape, device=DEVICE
        )

    time = xr.DataArray(
        np.broadcast_to(np.arange(total_timesteps), (n_samples, total_timesteps)),
        dims=["sample", "time"],
    )

    data = BatchData.new_on_device(
        data=data_dict,
        time=time,
        labels=None,
    )

    prognostic_names = [n for n in out_names if n in in_names]
    input_data = data.get_start(prognostic_names, n_ic_timesteps)

    return input_data, data


@pytest.mark.parametrize(
    "in_names,out_names,hfds_role",
    [
        pytest.param(
            ["thetao_0", "thetao_1", "hfds", "hfgeou", "sea_surface_fraction"],
            ["thetao_0", "thetao_1"],
            "next_step_forcing",
            id="hfds_next_step_forcing",
        ),
        pytest.param(
            ["thetao_0", "thetao_1", "hfds", "sea_surface_fraction"],
            ["thetao_0", "thetao_1"],
            "next_step_forcing",
            id="hfds_next_step_forcing_no_hfgeou",
        ),
        pytest.param(
            ["thetao_0", "thetao_1", "hfds", "land_fraction"],
            ["thetao_0", "thetao_1"],
            "next_step_forcing",
            id="hfds_next_step_forcing_land_fraction",
        ),
        pytest.param(
            [
                "thetao_0",
                "thetao_1",
                "hfds_forcing",
                "hfgeou",
                "sea_surface_fraction",
            ],
            ["thetao_0", "thetao_1", "hfds"],
            "diagnostic",
            id="hfds_diagnostic",
        ),
    ],
)
def test_ocean_derived_variables_integration(
    in_names,
    out_names,
    hfds_role,
):
    next_step_forcing_names = []
    if hfds_role == "next_step_forcing":
        next_step_forcing_names.append("hfds")
    stepper = _get_ocean_stepper(  # creates a PlusOne stepper
        in_names=in_names,
        out_names=out_names,
        next_step_forcing_names=next_step_forcing_names,
    )

    n_steps = 3
    input_data, data = _get_ocean_data_for_predict_paired(
        n_steps=n_steps,
        in_names=in_names,
        out_names=out_names,
    )
    derived_data = data.compute_derived_variables(
        derive_func=stepper.derive_func, forcing_data=data
    )

    paired_output, _ = stepper.predict_paired(
        input_data,
        data,
        compute_derived_variables=True,
    )

    for derived_var in [
        "ocean_heat_content",
        "ocean_heat_content_tendency",
        "net_energy_flux_into_ocean_column",
        "implied_tendency_of_ocean_heat_content_due_to_advection",
    ]:
        assert derived_var in derived_data.data
        assert derived_var in paired_output.prediction
        assert derived_var in paired_output.reference

    ic_ohc = derived_data.data["ocean_heat_content"][:, 0]
    pred_ohc = paired_output.prediction["ocean_heat_content"]
    ref_ohc = paired_output.reference["ocean_heat_content"]

    pred_tendency = paired_output.prediction["ocean_heat_content_tendency"]
    ref_tendency = paired_output.reference["ocean_heat_content_tendency"]

    pred_flux = paired_output.prediction["net_energy_flux_into_ocean_column"]
    ref_flux = paired_output.reference["net_energy_flux_into_ocean_column"]

    pred_imbalance = paired_output.prediction[
        "implied_tendency_of_ocean_heat_content_due_to_advection"
    ]
    ref_imbalance = paired_output.reference[
        "implied_tendency_of_ocean_heat_content_due_to_advection"
    ]

    dt = OCEAN_TIMESTEP.total_seconds()

    # check that the first step uses the initial condition correctly
    expected_pred_tendency_step1 = (pred_ohc[:, 0] - ic_ohc) / dt
    torch.testing.assert_close(
        pred_tendency[:, 0],
        expected_pred_tendency_step1,
        msg="Unexpected pred OHC tendency at step 1",
    )
    expected_ref_tendency_step1 = (ref_ohc[:, 0] - ic_ohc) / dt
    torch.testing.assert_close(
        ref_tendency[:, 0],
        expected_ref_tendency_step1,
        msg="Unexpected reference OHC tendency at step 1",
    )
    # check imbalance for forward steps
    for i in range(n_steps):
        expected_pred_imbalance = pred_tendency[:, i] - pred_flux[:, i]
        torch.testing.assert_close(
            pred_imbalance[:, i],
            expected_pred_imbalance,
            msg=f"Unexpected pred OHC imbalance at step {i + 1}",
        )
        expected_ref_imbalance = ref_tendency[:, i] - ref_flux[:, i]
        torch.testing.assert_close(
            ref_imbalance[:, i],
            expected_ref_imbalance,
            msg=f"Unexpected reference OHC imbalance at step {i + 1}",
        )

    if hfds_role == "next_step_forcing":
        # hfds is a forcing, so net_energy_flux_into_ocean_column in prediction
        # and reference are the same
        torch.testing.assert_close(pred_flux, ref_flux)
    elif hfds_role == "diagnostic":
        # hfds is diagnostic, so the generated net_energy_flux_into_ocean
        # differs from the reference
        assert not torch.allclose(pred_flux, ref_flux)


def test_load_stepper_config_from_checkpoint(tmp_path: pathlib.Path):
    checkpoint_path = tmp_path / "checkpoint.tar"
    original_config = save_stepper_checkpoint(checkpoint_path)
    loaded_config = load_stepper_config(checkpoint_path)
    assert isinstance(loaded_config, StepperConfig)
    assert loaded_config.derived_forcings == original_config.derived_forcings
    assert loaded_config.step.type == original_config.step.type


def test_checkpoint_stepper_config_to_stepper_config(tmp_path: pathlib.Path):
    checkpoint_path = tmp_path / "checkpoint.tar"
    original_config = save_stepper_checkpoint(checkpoint_path)
    checkpoint_config = CheckpointStepperConfig(
        checkpoint_path=str(checkpoint_path),
    )
    loaded_config = checkpoint_config.to_stepper_config()
    assert isinstance(loaded_config, StepperConfig)
    assert loaded_config.derived_forcings == original_config.derived_forcings
    assert loaded_config.step.type == original_config.step.type
