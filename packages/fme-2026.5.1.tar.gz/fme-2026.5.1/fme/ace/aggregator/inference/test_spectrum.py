import matplotlib.pyplot as plt
import numpy as np
import pytest
import torch
import torch_harmonics
import xarray as xr

import fme
from fme.ace.aggregator.inference.data import InferenceBatchData, make_dummy_time
from fme.ace.aggregator.inference.spectrum import (
    PairedSphericalPowerSpectrumAggregator,
    SphericalPowerSpectrumAggregator,
    get_positive_and_negative_power_bias,
    get_smallest_scale_power_bias,
)
from fme.core.dataset.data_typing import VariableMetadata
from fme.core.gridded_ops import LatLonOperations
from fme.core.metrics import spherical_power_spectrum

DEVICE = fme.get_device()


def get_gridded_operations(nlat: int, nlon: int):
    return LatLonOperations(torch.ones(nlat, nlon))


@pytest.mark.parametrize("report_plot", [True, False])
def test_spherical_power_spectrum_aggregator(report_plot: bool):
    nlat = 8
    nlon = 16
    grid = "legendre-gauss"
    gridded_operations = get_gridded_operations(nlat, nlon)
    agg = SphericalPowerSpectrumAggregator(gridded_operations, report_plot=report_plot)
    data = {"a": torch.randn(2, 2, nlat, nlon, device=fme.get_device())}
    data2 = {"a": torch.randn(2, 3, nlat, nlon, device=fme.get_device())}
    agg.record_batch(
        InferenceBatchData(
            prediction=data,
            prediction_norm={},
            target=None,
            target_norm=None,
            time=make_dummy_time(2, 2),
            i_time_start=0,
        )
    )
    agg.record_batch(
        InferenceBatchData(
            prediction=data2,
            prediction_norm={},
            target=None,
            target_norm=None,
            time=make_dummy_time(2, 3),
            i_time_start=0,
        )
    )
    result = agg.get_mean()
    assert "a" in result
    assert result["a"].shape == (nlat,)

    sht = torch_harmonics.RealSHT(nlat, nlon, grid=grid).to(fme.get_device())
    data_concat = torch.cat([data["a"], data2["a"]], dim=1)
    expected_value = torch.mean(spherical_power_spectrum(data_concat, sht), dim=(0, 1))
    torch.testing.assert_close(result["a"], expected_value)

    logs = agg.get_logs("spectrum")
    if report_plot:
        assert isinstance(logs["spectrum/a"], plt.Figure)
    else:
        assert "spectrum/a" not in logs


def test_spherical_power_spectrum_aggregator_get_dataset():
    nlat, nlon = 8, 16
    grid = "legendre-gauss"
    gridded_operations = get_gridded_operations(nlat, nlon)
    metadata = {"a": VariableMetadata(units="K", long_name="temperature")}
    agg = SphericalPowerSpectrumAggregator(
        gridded_operations, report_plot=False, variable_metadata=metadata
    )
    data = {"a": torch.randn(2, 3, nlat, nlon, device=DEVICE)}
    agg.record_batch(
        InferenceBatchData(
            prediction=data,
            prediction_norm={},
            target=None,
            target_norm=None,
            time=make_dummy_time(2, 3),
            i_time_start=0,
        )
    )
    result = agg.get_dataset()
    sht = torch_harmonics.RealSHT(nlat, nlon, grid=grid).to(DEVICE)
    expected_values = torch.mean(spherical_power_spectrum(data["a"], sht), dim=(0, 1))
    expected_attrs = {
        "long_name": "spherical power spectrum of temperature",
        "units": "(K)^2",
    }
    expected_wavenumber = np.arange(nlat)
    expected_da = xr.DataArray(
        expected_values.cpu().numpy(),
        dims=["wavenumber"],
        coords={"wavenumber": expected_wavenumber},
        attrs=expected_attrs,
    )
    expected = xr.Dataset({"a": expected_da})
    xr.testing.assert_identical(result, expected)


def test_paired_spherical_power_spectrum_aggregator_get_dataset():
    nlat, nlon = 8, 16
    grid = "legendre-gauss"
    gridded_operations = get_gridded_operations(nlat, nlon)
    agg = PairedSphericalPowerSpectrumAggregator(gridded_operations, report_plot=False)
    gen_data = {"a": torch.randn(2, 3, nlat, nlon, device=DEVICE)}
    target_data = {"a": torch.randn(2, 3, nlat, nlon, device=DEVICE)}
    agg.record_batch(
        InferenceBatchData(
            prediction=gen_data,
            prediction_norm={},
            target=target_data,
            target_norm={},
            time=make_dummy_time(2, 3),
            i_time_start=0,
        )
    )
    result = agg.get_dataset()
    sht = torch_harmonics.RealSHT(nlat, nlon, grid=grid).to(DEVICE)
    expected_gen = torch.mean(spherical_power_spectrum(gen_data["a"], sht), dim=(0, 1))
    expected_target = torch.mean(
        spherical_power_spectrum(target_data["a"], sht), dim=(0, 1)
    )
    expected_values = np.stack(
        [expected_gen.cpu().numpy(), expected_target.cpu().numpy()]
    )
    expected_wavenumber = np.arange(nlat)
    expected_da = xr.DataArray(
        expected_values,
        dims=["source", "wavenumber"],
        coords={"source": ["prediction", "target"], "wavenumber": expected_wavenumber},
        attrs={"long_name": "spherical power spectrum of a", "units": "unknown_units"},
    )
    expected = xr.Dataset({"a": expected_da})

    # Check the source coordinate is a unicode dtype (kind "U") rather than a
    # string dtype (kind "T"). Xarray currently does not support serializing
    # string dtype values to netCDF, but will in the future:
    # https://github.com/pydata/xarray/pull/11218.
    assert result.source.dtype.kind == "U"
    xr.testing.assert_identical(result, expected)


def test_paired_spherical_power_spectrum_aggregator_get_dataset_no_data():
    nlat, nlon = 8, 16
    gridded_operations = get_gridded_operations(nlat, nlon)
    agg = PairedSphericalPowerSpectrumAggregator(gridded_operations, report_plot=False)
    xr.testing.assert_identical(agg.get_dataset(), xr.Dataset())


@pytest.mark.parametrize("report_plot", [True, False])
def test_paired_spherical_power_spectrum_aggregator(report_plot: bool):
    nlat = 8
    nlon = 16
    gridded_operations = get_gridded_operations(nlat, nlon)
    agg = PairedSphericalPowerSpectrumAggregator(
        gridded_operations, report_plot=report_plot
    )
    data = {"a": torch.randn(2, 3, nlat, nlon, device=fme.get_device())}
    agg.record_batch(
        InferenceBatchData(
            prediction=data,
            prediction_norm={},
            target=data,
            target_norm={},
            time=make_dummy_time(2, 3),
            i_time_start=0,
        )
    )
    result = agg.get_logs("spectrum")
    if report_plot:
        assert isinstance(result["spectrum/a"], plt.Figure)
    else:
        assert "spectrum/a" not in result


@pytest.mark.parametrize(
    "gen_spectrum, target_spectrum, expected_positive_bias, expected_negative_bias",
    [
        pytest.param(
            torch.tensor([1.0, 1.2, 1.4], device=DEVICE),
            torch.tensor([1, 1, 1], device=DEVICE),
            0.2,
            0.0,
            id="positive_bias",
        ),
        pytest.param(
            torch.tensor([1.0, 0.8, 0.6], device=DEVICE),
            torch.tensor([1, 1, 1], device=DEVICE),
            0.0,
            -0.2,
            id="negative_bias",
        ),
        pytest.param(
            torch.tensor([1.6, 0.8, 0.6], device=DEVICE),
            torch.tensor([1, 1, 1], device=DEVICE),
            0.2,
            -0.2,
            id="both_bias",
        ),
        pytest.param(
            torch.tensor([2.0, 2.4, 2.8], device=DEVICE),
            torch.tensor([2, 2, 2], device=DEVICE),
            0.2,
            0.0,
            id="positive_bias_with_scale",
        ),
    ],
)
def test_get_positive_and_negative_power_bias(
    gen_spectrum: torch.Tensor,
    target_spectrum: torch.Tensor,
    expected_positive_bias: float,
    expected_negative_bias: float,
):
    positive_bias, negative_bias = get_positive_and_negative_power_bias(
        gen_spectrum, target_spectrum
    )
    torch.testing.assert_close(positive_bias, expected_positive_bias)
    torch.testing.assert_close(negative_bias, expected_negative_bias)


@pytest.mark.parametrize(
    "gen_spectrum, target_spectrum, expected_bias",
    [
        pytest.param(
            torch.tensor([1.0, 1.2, 1.4], device=DEVICE),
            torch.tensor([1, 1, 1], device=DEVICE),
            0.4,
            id="positive_bias",
        ),
        pytest.param(
            torch.tensor([1.0, 0.8, 1.3], device=DEVICE),
            torch.tensor([1, 1, 1.3], device=DEVICE),
            0.0,
            id="no_bias",
        ),
    ],
)
def test_get_smallest_scale_power_bias(
    gen_spectrum: torch.Tensor,
    target_spectrum: torch.Tensor,
    expected_bias: float,
):
    bias = get_smallest_scale_power_bias(gen_spectrum, target_spectrum)
    torch.testing.assert_close(bias, expected_bias)
