import datetime

import cftime
import numpy as np
import pytest
import torch
import xarray as xr

from fme.ace.inference.data_writer.test_data_writer import get_initial_condition_times
from fme.ace.inference.data_writer.zarr import (
    SeparateICZarrWriterAdapter,
    ZarrWriterAdapter,
    _get_ace_time_coords,
    ensure_numpy_coords,
)


def get_batch_time(n_batch_times, n_initial_conditions, calendar="julian"):
    times = xr.date_range(
        "2020-01-01",
        freq="6h",
        periods=n_batch_times,
        calendar=calendar,
        use_cftime=True,
    )
    batch_time = xr.DataArray(times, dims="time")
    return xr.concat(
        [
            batch_time + i * datetime.timedelta(hours=6)
            for i in range(n_initial_conditions)
        ],
        dim="sample",
    )


CALENDARS = {
    "julian": cftime.DatetimeJulian,
    "proleptic_gregorian": cftime.DatetimeProlepticGregorian,
    "noleap": cftime.DatetimeNoLeap,
}


@pytest.mark.parametrize("calendar", ["julian", "proleptic_gregorian", "noleap"])
def test__get_ace_time_coords(calendar):
    n_batch_times = 3
    n_timesteps = 6
    n_samples = 2
    timestep = datetime.timedelta(hours=6)
    start_time = (2020, 1, 1, 0, 0, 0)
    initial_condition_times = get_initial_condition_times(
        start_time, calendar, n_samples, separation_timedelta=timestep
    )
    batch_time = get_batch_time(
        n_batch_times=n_batch_times, n_initial_conditions=n_samples, calendar=calendar
    )
    lead_times_coord, init_times_coord, valid_times_coord = _get_ace_time_coords(
        initial_condition_times, batch_time, timestep, n_timesteps=n_timesteps
    )

    assert lead_times_coord.dims == ("time",)
    assert lead_times_coord.size == n_timesteps
    assert lead_times_coord.dtype == np.int64

    assert init_times_coord.dims == ("sample",)
    assert init_times_coord.size == n_samples
    assert init_times_coord.dtype == np.int64

    assert valid_times_coord.dims == ("sample", "time")
    assert valid_times_coord.shape == (n_samples, n_timesteps)
    assert valid_times_coord.dtype == np.int64

    start = CALENDARS[calendar](2020, 1, 1, 0)
    np.testing.assert_array_equal(
        lead_times_coord.values, np.arange(1, n_timesteps + 1) * 6 * 3600 * 1e6
    )
    np.testing.assert_array_equal(
        init_times_coord.values,
        cftime.date2num(
            initial_condition_times,
            units="microseconds since 1970-01-01",
            calendar=calendar,
        ),
    )

    reference = CALENDARS[calendar](1970, 1, 1)

    # check the first sample which is 6h init after sample 0
    expected_valid_times = []
    for i in range(n_timesteps):
        dt = (start + (i + 1) * datetime.timedelta(hours=6)) - reference
        expected_valid_times.append(
            dt.days * 86_400_000_000 + dt.seconds * 1_000_000 + dt.microseconds
        )
    np.testing.assert_array_equal(
        valid_times_coord.isel(sample=1), expected_valid_times
    )


@pytest.mark.parametrize("writer_cls", [ZarrWriterAdapter, SeparateICZarrWriterAdapter])
def test_zarr_adapter_can_overwrite(tmpdir, writer_cls):
    data = {"foo": torch.zeros((1, 2, 2, 2))}
    timestep = datetime.timedelta(days=1)
    initial_condition_times = np.array([cftime.datetime(2019, 12, 31)])
    time = xr.DataArray(
        [[cftime.datetime(2020, 1, 1), cftime.datetime(2020, 1, 2)]],
        dims=("sample", "time"),
    )
    args = dict(
        path=str(tmpdir / "test.zarr"),
        dims=("sample", "time", "lat", "lon")
        if writer_cls == ZarrWriterAdapter
        else ("time", "lat", "lon"),
        data_coords=ensure_numpy_coords(
            {
                "lat": xr.DataArray([0, 1], dims=["lat"]),
                "lon": xr.DataArray([0, 1], dims=["lon"]),
                "ak": xr.DataArray([0, 1], dims=["z_interface"]),
            }
        ),
        timestep=timestep,
        n_timesteps=2,
        initial_condition_times=initial_condition_times,
    )
    adapter = writer_cls(**args)  # type: ignore
    adapter.append_batch(data, time)
    adapter = writer_cls(**args)  # type: ignore
    adapter.append_batch(data, time)


def test_zarr_adapter_single_timestep_data(
    tmpdir,
):
    data = {"foo": torch.zeros((1, 1, 2, 2))}
    timestep = datetime.timedelta(days=1)
    initial_condition_times = np.array([cftime.datetime(2019, 12, 31)])
    time = xr.DataArray(
        [
            [
                cftime.datetime(2020, 1, 1),
            ]
        ],
        dims=("sample", "time"),
    )
    args = dict(
        path=str(tmpdir / "test.zarr"),
        dims=("sample", "time", "lat", "lon"),
        data_coords=ensure_numpy_coords(
            {
                "lat": xr.DataArray([0, 1], dims=["lat"]),
                "lon": xr.DataArray([0, 1], dims=["lon"]),
                "ak": xr.DataArray([0, 1], dims=["z_interface"]),
            }
        ),
        timestep=timestep,
        n_timesteps=1,
        initial_condition_times=initial_condition_times,
    )
    adapter = ZarrWriterAdapter(**args)  # type: ignore
    adapter.append_batch(data, time)

    ds = xr.open_zarr(str(tmpdir / "test.zarr"))
    assert ds.time.size == 1
