"""A/B testing and batch testing for prompt evaluation."""

from __future__ import annotations

import time
from typing import Any

from promptforge.engine import get_provider
from promptforge.models import (
    ABTestConfig,
    ABTestResult,
    ABTestSummary,
    BatchTestConfig,
    BatchTestResult,
    ModelProvider,
)
from promptforge.quality import QualityScorer
from promptforge.store import PromptStore
from promptforge.token_counter import estimate_cost


class ABTester:
    """A/B testing framework for comparing two prompts."""

    def __init__(self, store: PromptStore | None = None):
        self.store = store or PromptStore()
        self.scorer = QualityScorer()

    def run_test(
        self,
        config: ABTestConfig,
        variables: dict[str, str] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> tuple[list[ABTestResult], ABTestSummary]:
        """Run an A/B test, comparing prompt A vs prompt B on test inputs.

        Returns individual results and an aggregated summary.
        """
        prompt_a = self.store.get_prompt(config.prompt_a_id)
        prompt_b = self.store.get_prompt(config.prompt_b_id)

        if prompt_a is None:
            raise ValueError(f"Prompt A not found: {config.prompt_a_id}")
        if prompt_b is None:
            raise ValueError(f"Prompt B not found: {config.prompt_b_id}")

        provider = get_provider(
            config.provider,
            model=config.model,
        )

        rendered_a = prompt_a.render(variables)
        rendered_b = prompt_b.render(variables)

        results: list[ABTestResult] = []
        wins_a = 0
        wins_b = 0
        ties = 0

        all_scores_a: dict[str, list[float]] = {
            "coherence": [],
            "relevance": [],
            "safety": [],
            "completeness": [],
            "clarity": [],
        }
        all_scores_b: dict[str, list[float]] = {
            "coherence": [],
            "relevance": [],
            "safety": [],
            "completeness": [],
            "clarity": [],
        }

        for input_text in config.test_inputs:
            full_prompt_a = f"{rendered_a}\n\nInput: {input_text}"
            full_prompt_b = f"{rendered_b}\n\nInput: {input_text}"

            try:
                resp_a = provider.generate(
                    full_prompt_a, temperature=temperature, max_tokens=max_tokens
                )
                resp_b = provider.generate(
                    full_prompt_b, temperature=temperature, max_tokens=max_tokens
                )
            except Exception as e:
                results.append(
                    ABTestResult(
                        test_id=config.id,
                        input_text=input_text,
                        output_a=f"ERROR: {e}",
                        output_b=f"ERROR: {e}",
                    )
                )
                ties += 1
                continue

            scores_a = self.scorer.score_all(resp_a.text, full_prompt_a)
            scores_b = self.scorer.score_all(resp_b.text, full_prompt_b)

            overall_a = scores_a["overall"]
            overall_b = scores_b["overall"]

            if overall_a > overall_b + 0.05:
                winner = "A"
                wins_a += 1
            elif overall_b > overall_a + 0.05:
                winner = "B"
                wins_b += 1
            else:
                winner = "tie"
                ties += 1

            for metric in all_scores_a:
                all_scores_a[metric].append(scores_a.get(metric, 0))
                all_scores_b[metric].append(scores_b.get(metric, 0))

            results.append(
                ABTestResult(
                    test_id=config.id,
                    input_text=input_text,
                    output_a=resp_a.text,
                    output_b=resp_b.text,
                    scores_a=scores_a,
                    scores_b=scores_b,
                    winner=winner,
                    reasoning=f"A={overall_a:.3f}, B={overall_b:.3f}",
                )
            )

        avg_a = {k: round(sum(v) / len(v), 3) for k, v in all_scores_a.items() if v}
        avg_b = {k: round(sum(v) / len(v), 3) for k, v in all_scores_b.items() if v}

        recommendation = "No clear winner"
        if wins_a > wins_b:
            recommendation = f"Prompt A wins ({wins_a}/{len(results)} runs)"
        elif wins_b > wins_a:
            recommendation = f"Prompt B wins ({wins_b}/{len(results)} runs)"

        summary = ABTestSummary(
            test_id=config.id,
            total_runs=len(results),
            wins_a=wins_a,
            wins_b=wins_b,
            ties=ties,
            avg_score_a=avg_a,
            avg_score_b=avg_b,
            recommendation=recommendation,
        )

        self.store.save_ab_results(config.id, results, summary)
        return results, summary


class BatchTester:
    """Batch testing — run many inputs through a single prompt."""

    def __init__(self, store: PromptStore | None = None):
        self.store = store or PromptStore()
        self.scorer = QualityScorer()

    def run_batch(
        self,
        config: BatchTestConfig,
        variables: dict[str, str] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> BatchTestResult:
        """Run a batch of inputs through a prompt and collect statistics."""
        prompt = self.store.get_prompt(config.prompt_id)
        if prompt is None:
            raise ValueError(f"Prompt not found: {config.prompt_id}")

        provider = get_provider(config.provider, model=config.model)
        rendered = prompt.render(variables)

        successful = 0
        failed = 0
        total_tokens = 0
        total_latency = 0.0
        individual_results: list[dict[str, Any]] = []

        for i, input_text in enumerate(config.inputs):
            full_prompt = f"{rendered}\n\nInput: {input_text}"

            try:
                start = time.monotonic()
                response = provider.generate(
                    full_prompt, temperature=temperature, max_tokens=max_tokens
                )
                latency = (time.monotonic() - start) * 1000

                quality = self.scorer.score_all(response.text, full_prompt)

                individual_results.append(
                    {
                        "index": i,
                        "input": input_text,
                        "output": response.text,
                        "tokens": response.total_tokens,
                        "latency_ms": round(latency, 1),
                        "quality": quality,
                        "status": "success",
                    }
                )
                successful += 1
                total_tokens += response.total_tokens
                total_latency += latency

            except Exception as e:
                individual_results.append(
                    {
                        "index": i,
                        "input": input_text,
                        "output": f"ERROR: {e}",
                        "tokens": 0,
                        "latency_ms": 0,
                        "quality": {},
                        "status": "error",
                        "error": str(e),
                    }
                )
                failed += 1

        avg_latency = total_latency / max(successful, 1)
        estimated_cost = estimate_cost(total_tokens, 0, config.model)

        result = BatchTestResult(
            prompt_id=config.prompt_id,
            total_inputs=len(config.inputs),
            successful=successful,
            failed=failed,
            results=individual_results,
            avg_latency_ms=round(avg_latency, 1),
            total_tokens_used=total_tokens,
            estimated_cost_usd=estimated_cost,
        )

        self.store.save_batch_result(result)
        return result
