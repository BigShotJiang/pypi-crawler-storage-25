"""LLM provider integrations — OpenAI, Anthropic, Google, and local models."""

from __future__ import annotations

import os
import time
from abc import ABC, abstractmethod
from typing import Any

from promptforge.models import ModelProvider
from promptforge.token_counter import count_tokens


class LLMResponse:
    """Standardized response from any LLM provider."""

    def __init__(
        self,
        text: str,
        provider: str,
        model: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        latency_ms: float = 0.0,
        raw: dict[str, Any] | None = None,
    ):
        self.text = text
        self.provider = provider
        self.model = model
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.latency_ms = latency_ms
        self.raw = raw or {}

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "provider": self.provider,
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "latency_ms": self.latency_ms,
        }


class BaseProvider(ABC):
    """Abstract base class for LLM providers."""

    def __init__(self, model: str = "", api_key: str | None = None):
        self.model = model
        self.api_key = api_key

    @abstractmethod
    def generate(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> LLMResponse:
        ...

    def _validate_api_key(self, env_var: str) -> str:
        key = self.api_key or os.environ.get(env_var)
        if not key:
            raise ValueError(
                f"API key not found. Set {env_var} environment variable "
                f"or pass api_key parameter."
            )
        return key


class OpenAIProvider(BaseProvider):
    """OpenAI API provider."""

    def __init__(self, model: str = "gpt-4o-mini", api_key: str | None = None):
        super().__init__(model, api_key)

    def generate(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> LLMResponse:
        import openai

        api_key = self._validate_api_key("OPENAI_API_KEY")
        client = openai.OpenAI(api_key=api_key)

        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        start = time.monotonic()
        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        latency_ms = (time.monotonic() - start) * 1000

        choice = response.choices[0]
        usage = response.usage

        return LLMResponse(
            text=choice.message.content or "",
            provider="openai",
            model=self.model,
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
            latency_ms=latency_ms,
            raw=response.model_dump() if hasattr(response, "model_dump") else {},
        )


class AnthropicProvider(BaseProvider):
    """Anthropic API provider."""

    def __init__(self, model: str = "claude-3-5-sonnet-20241022", api_key: str | None = None):
        super().__init__(model, api_key)

    def generate(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> LLMResponse:
        import anthropic

        api_key = self._validate_api_key("ANTHROPIC_API_KEY")
        client = anthropic.Anthropic(api_key=api_key)

        start = time.monotonic()
        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [{"role": "user", "content": prompt}],
        }
        if system:
            kwargs["system"] = system

        response = client.messages.create(**kwargs)
        latency_ms = (time.monotonic() - start) * 1000

        text = ""
        if response.content:
            for block in response.content:
                if hasattr(block, "text"):
                    text += block.text

        usage = response.usage
        return LLMResponse(
            text=text,
            provider="anthropic",
            model=self.model,
            input_tokens=usage.input_tokens if usage else 0,
            output_tokens=usage.output_tokens if usage else 0,
            latency_ms=latency_ms,
            raw=response.model_dump() if hasattr(response, "model_dump") else {},
        )


class GoogleProvider(BaseProvider):
    """Google Gemini API provider (uses OpenAI-compatible endpoint)."""

    def __init__(self, model: str = "gemini-2.0-flash", api_key: str | None = None):
        super().__init__(model, api_key)

    def generate(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> LLMResponse:
        import httpx

        api_key = self._validate_api_key("GOOGLE_API_KEY")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={api_key}"

        contents: list[dict[str, Any]] = []
        if system:
            contents.append({"role": "user", "parts": [{"text": system}]})
            contents.append({"role": "model", "parts": [{"text": "Understood."}]})
        contents.append({"role": "user", "parts": [{"text": prompt}]})

        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }

        start = time.monotonic()
        resp = httpx.post(url, json=payload, timeout=60.0)
        latency_ms = (time.monotonic() - start) * 1000
        resp.raise_for_status()
        data = resp.json()

        text = ""
        candidates = data.get("candidates", [])
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            for part in parts:
                text += part.get("text", "")

        usage_meta = data.get("usageMetadata", {})
        input_tokens = usage_meta.get("promptTokenCount", 0)
        output_tokens = usage_meta.get("candidatesTokenCount", 0)

        return LLMResponse(
            text=text,
            provider="google",
            model=self.model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            raw=data,
        )


class LocalProvider(BaseProvider):
    """Local model provider (Ollama, LM Studio, etc.)."""

    def __init__(self, model: str = "llama3.1", base_url: str | None = None):
        super().__init__(model)
        self.base_url = base_url or os.environ.get(
            "LOCAL_LLM_URL", "http://localhost:11434"
        )

    def generate(
        self,
        prompt: str,
        system: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> LLMResponse:
        import httpx

        url = f"{self.base_url}/api/generate"
        payload: dict[str, Any] = {
            "model": self.model,
            "prompt": prompt,
            "system": system or "",
            "temperature": temperature,
            "stream": False,
            "options": {"num_predict": max_tokens},
        }

        start = time.monotonic()
        resp = httpx.post(url, json=payload, timeout=120.0)
        latency_ms = (time.monotonic() - start) * 1000
        resp.raise_for_status()
        data = resp.json()

        text = data.get("response", "")
        input_tokens = count_tokens(prompt, "cl100k_base")
        output_tokens = count_tokens(text, "cl100k_base")

        return LLMResponse(
            text=text,
            provider="local",
            model=self.model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            raw=data,
        )


PROVIDERS: dict[ModelProvider, type[BaseProvider]] = {
    ModelProvider.OPENAI: OpenAIProvider,
    ModelProvider.ANTHROPIC: AnthropicProvider,
    ModelProvider.GOOGLE: GoogleProvider,
    ModelProvider.LOCAL: LocalProvider,
}


def get_provider(
    provider: ModelProvider | str,
    model: str = "",
    api_key: str | None = None,
    **kwargs: Any,
) -> BaseProvider:
    """Factory function to create an LLM provider instance."""
    if isinstance(provider, str):
        provider = ModelProvider(provider)

    cls = PROVIDERS.get(provider)
    if cls is None:
        raise ValueError(f"Unsupported provider: {provider}")

    if provider == ModelProvider.LOCAL:
        return cls(model=model or "llama3.1", **kwargs)
    return cls(model=model, api_key=api_key, **kwargs)
