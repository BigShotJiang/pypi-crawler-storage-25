"""Chain-of-thought builder — sequential prompt chaining with variable passing."""

from __future__ import annotations

import time
from typing import Any

from promptforge.engine import get_provider
from promptforge.models import (
    ChainPipeline,
    ChainRunResult,
    ChainStep,
    ModelProvider,
)
from promptforge.store import PromptStore


class ChainBuilder:
    """Build and execute chain-of-thought pipelines.

    Each step's output can be injected into subsequent steps via
    {{step_N_output}} variables.
    """

    def __init__(self, store: PromptStore | None = None):
        self.store = store or PromptStore()

    def create_pipeline(
        self,
        name: str,
        description: str = "",
        step_prompt_ids: list[str] | None = None,
    ) -> ChainPipeline:
        """Create a new chain pipeline with ordered steps."""
        pipeline = ChainPipeline(
            name=name,
            description=description,
        )

        if step_prompt_ids:
            for i, pid in enumerate(step_prompt_ids):
                step = ChainStep(
                    prompt_id=pid,
                    name=f"Step {i + 1}",
                    output_variable=f"step_{i + 1}_output",
                )
                if i < len(step_prompt_ids) - 1:
                    step.next_step_id = f"step_{i + 2}"
                pipeline.steps.append(step)

            # Link steps
            for i in range(len(pipeline.steps) - 1):
                pipeline.steps[i].next_step_id = pipeline.steps[i + 1].id

        self.store.save_chain(pipeline)
        return pipeline

    def add_step(
        self,
        pipeline_id: str,
        prompt_id: str,
        name: str = "",
        output_variable: str = "",
    ) -> ChainPipeline:
        """Add a step to an existing pipeline."""
        pipeline = self.store.get_chain(pipeline_id)
        if pipeline is None:
            raise ValueError(f"Pipeline not found: {pipeline_id}")

        step_num = len(pipeline.steps) + 1
        step = ChainStep(
            prompt_id=prompt_id,
            name=name or f"Step {step_num}",
            output_variable=output_variable or f"step_{step_num}_output",
        )

        if pipeline.steps:
            pipeline.steps[-1].next_step_id = step.id

        pipeline.steps.append(step)
        self.store.save_chain(pipeline)
        return pipeline

    def run_pipeline(
        self,
        pipeline_id: str,
        initial_variables: dict[str, str] | None = None,
        provider: ModelProvider = ModelProvider.OPENAI,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> ChainRunResult:
        """Execute a chain pipeline sequentially, passing outputs between steps."""
        pipeline = self.store.get_chain(pipeline_id)
        if pipeline is None:
            raise ValueError(f"Pipeline not found: {pipeline_id}")

        if not pipeline.steps:
            raise ValueError(f"Pipeline has no steps: {pipeline_id}")

        llm = get_provider(provider, model=model)
        variables: dict[str, str] = dict(initial_variables or {})
        step_results: list[dict[str, Any]] = []
        total_tokens = 0
        total_latency = 0.0

        for step in pipeline.steps:
            prompt = self.store.get_prompt(step.prompt_id)
            if prompt is None:
                raise ValueError(f"Step prompt not found: {step.prompt_id}")

            rendered = prompt.render(variables)

            start = time.monotonic()
            try:
                response = llm.generate(
                    rendered,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                latency = (time.monotonic() - start) * 1000

                output_text = response.text
                tokens = response.total_tokens
                total_tokens += tokens
                total_latency += latency

                if step.output_variable:
                    variables[step.output_variable] = output_text

                step_results.append(
                    {
                        "step_id": step.id,
                        "step_name": step.name,
                        "prompt_id": step.prompt_id,
                        "output": output_text,
                        "tokens": tokens,
                        "latency_ms": round(latency, 1),
                        "status": "success",
                    }
                )

            except Exception as e:
                step_results.append(
                    {
                        "step_id": step.id,
                        "step_name": step.name,
                        "prompt_id": step.prompt_id,
                        "output": f"ERROR: {e}",
                        "tokens": 0,
                        "latency_ms": 0,
                        "status": "error",
                        "error": str(e),
                    }
                )
                break

        final_output = step_results[-1]["output"] if step_results else ""

        result = ChainRunResult(
            pipeline_id=pipeline_id,
            step_results=step_results,
            final_output=final_output,
            total_tokens_used=total_tokens,
            total_latency_ms=round(total_latency, 1),
        )

        self.store.save_chain_result(result)
        return result

    def list_pipelines(self) -> list[ChainPipeline]:
        """List all saved pipelines."""
        return self.store.list_chains()
