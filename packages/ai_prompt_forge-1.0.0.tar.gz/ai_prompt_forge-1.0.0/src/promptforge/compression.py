"""Prompt compression — reduce tokens while preserving quality and intent."""

from __future__ import annotations

import re
from typing import Any


class PromptCompressor:
    """Compress prompts to use fewer tokens while maintaining effectiveness.

    Applies a series of deterministic transformations that reduce token count
    without changing the semantic meaning of the prompt.
    """

    def compress(self, text: str, aggression: float = 0.5) -> dict[str, Any]:
        """Compress a prompt string.

        Args:
            text: The prompt text to compress.
            aggression: Compression level 0.0 (minimal) to 1.0 (aggressive).

        Returns:
            Dict with compressed text and compression stats.
        """
        original = text
        original_len = len(text)
        steps_applied: list[str] = []

        # Step 1: Remove redundant whitespace
        text = self._collapse_whitespace(text)
        steps_applied.append("collapse_whitespace")

        # Step 2: Remove filler phrases
        text = self._remove_fillers(text, aggression)
        steps_applied.append("remove_fillers")

        # Step 3: Shorten verbose instructions
        text = self._shorten_instructions(text, aggression)
        steps_applied.append("shorten_instructions")

        # Step 4: Remove redundant qualifiers
        if aggression >= 0.4:
            text = self._remove_qualifiers(text)
            steps_applied.append("remove_qualifiers")

        # Step 5: Compress numbered lists
        if aggression >= 0.3:
            text = self._compress_lists(text)
            steps_applied.append("compress_lists")

        # Step 6: Remove empty lines
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = text.strip()

        compressed_len = len(text)
        reduction_pct = (
            round((1 - compressed_len / original_len) * 100, 1)
            if original_len > 0
            else 0
        )

        return {
            "original": original,
            "compressed": text,
            "original_length": original_len,
            "compressed_length": compressed_len,
            "reduction_pct": reduction_pct,
            "steps_applied": steps_applied,
        }

    def _collapse_whitespace(self, text: str) -> str:
        """Collapse multiple spaces/newlines into single ones."""
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n[ \t]*\n", "\n\n", text)
        return text

    def _remove_fillers(self, text: str, aggression: float) -> str:
        """Remove common filler phrases that add tokens but not meaning."""
        fillers = [
            (r"(?i)\bplease\s+note\s+that\b", "note"),
            (r"(?i)\bit\s+is\s+important\s+to\s+(note|remember|understand)\b", "note"),
            (r"(?i)\bkindly\b", ""),
            (r"(?i)\bplease\b", ""),
            (r"(?i)\byou\s+should\b", ""),
            (r"(?i)\bmake\s+sure\s+to\b", ""),
            (r"(?i)\bkeep\s+in\s+mind\s+that\b", ""),
            (r"(?i)\bas\s+a\s+reminder\b", ""),
            (r"(?i)\bin\s+order\s+to\b", "to"),
            (r"(?i)\bat\s+this\s+point\s+in\s+time\b", "now"),
            (r"(?i)\bdue\s+to\s+the\s+fact\s+that\b", "because"),
            (r"(?i)\bfor\s+the\s+purpose\s+of\b", "for"),
            (r"(?i)\bin\s+the\s+event\s+that\b", "if"),
            (r"(?i)\bwith\s+regard\s+to\b", "about"),
            (r"(?i)\bprior\s+to\b", "before"),
        ]

        if aggression >= 0.7:
            fillers.extend([
                (r"(?i)\bvery\s+", ""),
                (r"(?i)\breally\s+", ""),
                (r"(?i)\bquite\s+", ""),
                (r"(?i)\bactually\s+", ""),
                (r"(?i)\bbasically\s+", ""),
                (r"(?i)\bliterally\s+", ""),
            ])

        for pattern, replacement in fillers:
            text = re.sub(pattern, replacement, text)

        text = re.sub(r"\s{2,}", " ", text)
        return text

    def _shorten_instructions(self, text: str, aggression: float) -> str:
        """Replace verbose instruction phrases with concise equivalents."""
        shortenings = [
            (r"(?i)\byou\s+are\s+a\s+helpful\s+assistant\b", "You are an assistant"),
            (r"(?i)\byou\s+are\s+an\s+expert\s+in\b", "Expert in"),
            (r"(?i)\byour\s+task\s+is\s+to\b", "Task"),
            (r"(?i)\byour\s+goal\s+is\s+to\b", "Goal"),
            (r"(?i)\bthe\s+following\s+text\b", "This text"),
            (r"(?i)\bthe\s+following\s+information\b", "This info"),
            (r"(?i)\bprovide\s+a\s+detailed\b", "Give a detailed"),
            (r"(?i)\bprovide\s+an\s+in-depth\b", "Give an in-depth"),
            (r"(?i)\bwrite\s+a\s+comprehensive\b", "Write a comprehensive"),
        ]

        if aggression >= 0.6:
            shortenings.extend([
                (r"(?i)\brespond\s+in\s+(?:a\s+)?(?:professional|formal)\s+(?:tone|manner)\b", "Be professional"),
                (r"(?i)\brespond\s+in\s+(?:a\s+)?(?:casual|informal|friendly)\s+(?:tone|manner)\b", "Be casual"),
            ])

        for pattern, replacement in shortenings:
            text = re.sub(pattern, replacement, text)

        return text

    def _remove_qualifiers(self, text: str) -> str:
        """Remove hedging qualifiers."""
        qualifiers = [
            r"(?i)\bsomewhat\s+",
            r"(?i)\brather\s+",
            r"(?i)\bfairly\s+",
            r"(?i)\bsomewhat\s+",
            r"(?i)\bperhaps\s+",
            r"(?i)\bmaybe\s+",
            r"(?i)\bpossibly\s+",
        ]
        for q in qualifiers:
            text = re.sub(q, "", text)
        return text

    def _compress_lists(self, text: str) -> str:
        """Compress numbered/bulleted lists into compact format."""
        text = re.sub(r"^\d+\.\s+", "- ", text, flags=re.MULTILINE)
        text = re.sub(r"^[•]\s+", "- ", text, flags=re.MULTILINE)
        return text
