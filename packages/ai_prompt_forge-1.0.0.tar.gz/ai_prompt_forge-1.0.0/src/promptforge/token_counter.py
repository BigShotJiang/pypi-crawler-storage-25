"""Token counting and cost estimation for different LLM models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import tiktoken


@dataclass
class ModelPricing:
    """Pricing information for a model (per 1M tokens)."""

    input_cost_per_m: float
    output_cost_per_m: float
    context_window: int
    encoding_name: str


PRICING_TABLE: dict[str, ModelPricing] = {
    "gpt-4o": ModelPricing(2.50, 10.00, 128_000, "o200k_base"),
    "gpt-4o-mini": ModelPricing(0.15, 0.60, 128_000, "o200k_base"),
    "gpt-4-turbo": ModelPricing(10.00, 30.00, 128_000, "cl100k_base"),
    "gpt-4": ModelPricing(30.00, 60.00, 8_192, "cl100k_base"),
    "gpt-4-32k": ModelPricing(60.00, 120.00, 32_768, "cl100k_base"),
    "gpt-3.5-turbo": ModelPricing(0.50, 1.50, 16_385, "cl100k_base"),
    "claude-3.5-sonnet": ModelPricing(3.00, 15.00, 200_000, "cl100k_base"),
    "claude-3-opus": ModelPricing(15.00, 75.00, 200_000, "cl100k_base"),
    "claude-3-haiku": ModelPricing(0.25, 1.25, 200_000, "cl100k_base"),
    "claude-3.5-haiku": ModelPricing(1.00, 5.00, 200_000, "cl100k_base"),
    "gemini-1.5-pro": ModelPricing(3.50, 10.50, 2_097_152, "cl100k_base"),
    "gemini-1.5-flash": ModelPricing(0.075, 0.30, 1_048_576, "cl100k_base"),
    "gemini-2.0-flash": ModelPricing(0.10, 0.40, 1_048_576, "cl100k_base"),
    "llama-3.1-70b": ModelPricing(0.00, 0.00, 128_000, "cl100k_base"),
    "llama-3.1-8b": ModelPricing(0.00, 0.00, 128_000, "cl100k_base"),
    "mistral-large": ModelPricing(2.00, 6.00, 128_000, "cl100k_base"),
    "mixtral-8x7b": ModelPricing(0.24, 0.24, 32_000, "cl100k_base"),
}


def get_encoding(model: str) -> tiktoken.Encoding:
    """Get the tiktoken encoding for a model."""
    pricing = PRICING_TABLE.get(model)
    enc_name = pricing.encoding_name if pricing else "cl100k_base"
    try:
        return tiktoken.get_encoding(enc_name)
    except KeyError:
        return tiktoken.get_encoding("cl100k_base")


def count_tokens(text: str, model: str = "gpt-4o") -> int:
    """Count the number of tokens in text for a given model."""
    encoding = get_encoding(model)
    return len(encoding.encode(text))


def estimate_cost(
    input_tokens: int,
    output_tokens: int,
    model: str = "gpt-4o",
) -> float:
    """Estimate cost in USD for given token counts and model."""
    pricing = PRICING_TABLE.get(model)
    if not pricing:
        return 0.0
    input_cost = (input_tokens / 1_000_000) * pricing.input_cost_per_m
    output_cost = (output_tokens / 1_000_000) * pricing.output_cost_per_m
    return round(input_cost + output_cost, 6)


def analyze_text(
    text: str, model: str = "gpt-4o", estimated_output_tokens: int = 0
) -> dict[str, Any]:
    """Full token and cost analysis of a text string."""
    input_tokens = count_tokens(text, model)
    char_count = len(text)
    word_count = len(text.split())
    sentence_count = max(1, len([c for c in text if c in ".!?"]))

    pricing = PRICING_TABLE.get(model)
    context_window = pricing.context_window if pricing else 4096
    encoding_name = pricing.encoding_name if pricing else "cl100k_base"
    input_cost = estimate_cost(input_tokens, 0, model)
    output_cost = estimate_cost(0, estimated_output_tokens, model) if estimated_output_tokens > 0 else 0.0
    total_cost = input_cost + output_cost

    return {
        "model": model,
        "input_tokens": input_tokens,
        "estimated_output_tokens": estimated_output_tokens,
        "total_tokens": input_tokens + estimated_output_tokens,
        "char_count": char_count,
        "word_count": word_count,
        "sentence_count": sentence_count,
        "context_window": context_window,
        "context_usage_pct": round((input_tokens / context_window) * 100, 2) if context_window > 0 else 0,
        "input_cost_usd": input_cost,
        "output_cost_usd": output_cost,
        "total_cost_usd": total_cost,
        "encoding": encoding_name,
    }


def compare_models(text: str, estimated_output_tokens: int = 500) -> list[dict[str, Any]]:
    """Compare token counts and costs across all supported models."""
    results: list[dict[str, Any]] = []
    for model_name in PRICING_TABLE:
        analysis = analyze_text(text, model_name, estimated_output_tokens)
        results.append(analysis)
    results.sort(key=lambda x: x["total_cost_usd"])
    return results


def get_supported_models() -> list[str]:
    """Return list of all supported model names."""
    return list(PRICING_TABLE.keys())
