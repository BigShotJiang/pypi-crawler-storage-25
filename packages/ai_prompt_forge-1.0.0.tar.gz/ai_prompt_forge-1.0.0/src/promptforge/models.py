"""Pydantic models for PromptForge data structures."""

from __future__ import annotations

import re
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class PromptCategory(str, Enum):
    CODING = "coding"
    WRITING = "writing"
    ANALYSIS = "analysis"
    CREATIVE = "creative"
    BUSINESS = "business"
    EDUCATION = "education"
    MARKETING = "marketing"
    DATA_SCIENCE = "data_science"
    CONVERSATION = "conversation"
    REASONING = "reasoning"
    EXTRACTION = "extraction"
    SUMMARIZATION = "summarization"
    TRANSLATION = "translation"
    SYSTEM = "system"
    SAFETY = "safety"


class ModelProvider(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    LOCAL = "local"


class ExportFormat(str, Enum):
    JSON = "json"
    YAML = "yaml"
    LANGCHAIN = "langchain"


class QualityMetric(str, Enum):
    COHERENCE = "coherence"
    RELEVANCE = "relevance"
    SAFETY = "safety"
    COMPLETENESS = "completeness"
    CLARITY = "clarity"


class VariableDefinition(BaseModel):
    """A single variable definition within a prompt template."""

    name: str
    description: str = ""
    default: str | None = None
    required: bool = True
    example: str | None = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", v):
            raise ValueError(
                f"Variable name '{v}' must start with a letter or underscore "
                "and contain only letters, digits, and underscores."
            )
        return v


class PromptTemplate(BaseModel):
    """A prompt template with variable injection support."""

    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str
    description: str = ""
    category: PromptCategory = PromptCategory.CODING
    template: str
    variables: list[VariableDefinition] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    model_hint: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    created_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    updated_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    version: int = 1
    parent_id: str | None = None

    @field_validator("template")
    @classmethod
    def validate_template(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Template cannot be empty.")
        if len(v) > 100_000:
            raise ValueError("Template exceeds maximum length of 100,000 characters.")
        return v

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Name cannot be empty.")
        if len(v) > 200:
            raise ValueError("Name exceeds maximum length of 200 characters.")
        return v

    def extract_variables(self) -> list[str]:
        """Extract {{variable}} placeholders from the template string."""
        return sorted(set(re.findall(r"\{\{(\w+)\}\}", self.template)))

    def render(self, values: dict[str, str] | None = None) -> str:
        """Render the template by injecting variable values.

        Raises ValueError if any required variable is missing.
        """
        values = values or {}
        template_vars = self.extract_variables()
        errors = []

        for var_name in template_vars:
            if var_name not in values:
                var_def = next(
                    (v for v in self.variables if v.name == var_name), None
                )
                if var_def and var_def.default is not None:
                    values[var_name] = var_def.default
                elif var_def and not var_def.required:
                    values[var_name] = ""
                else:
                    errors.append(var_name)

        if errors:
            raise ValueError(
                f"Missing required variables: {', '.join(errors)}"
            )

        result = self.template
        for key, val in values.items():
            result = result.replace("{{" + key + "}}", str(val))
        return result

    @model_validator(mode="after")
    def sync_variables(self) -> "PromptTemplate":
        """Ensure variables list stays in sync with template placeholders."""
        extracted = self.extract_variables()
        existing_names = {v.name for v in self.variables}
        for var_name in extracted:
            if var_name not in existing_names:
                self.variables.append(
                    VariableDefinition(name=var_name, description=f"Auto-detected variable: {var_name}")
                )
        return self


class VersionDiff(BaseModel):
    """Represents a diff between two prompt versions."""

    old_version: int
    new_version: int
    old_template: str
    new_template: str
    additions: list[str] = Field(default_factory=list)
    deletions: list[str] = Field(default_factory=list)
    summary: str = ""


class ABTestConfig(BaseModel):
    """Configuration for an A/B test comparing prompts."""

    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str
    prompt_a_id: str
    prompt_b_id: str
    test_inputs: list[str] = Field(default_factory=list)
    provider: ModelProvider = ModelProvider.OPENAI
    model: str = "gpt-4o-mini"
    judge_prompt: str | None = None
    created_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class ABTestResult(BaseModel):
    """Result of a single A/B test run."""

    test_id: str
    input_text: str
    output_a: str
    output_b: str
    scores_a: dict[str, float] = Field(default_factory=dict)
    scores_b: dict[str, float] = Field(default_factory=dict)
    winner: str | None = None
    reasoning: str = ""


class ABTestSummary(BaseModel):
    """Summary across all runs of an A/B test."""

    test_id: str
    total_runs: int
    wins_a: int
    wins_b: int
    ties: int
    avg_score_a: dict[str, float] = Field(default_factory=dict)
    avg_score_b: dict[str, float] = Field(default_factory=dict)
    recommendation: str = ""


class BatchTestConfig(BaseModel):
    """Configuration for batch testing a prompt."""

    prompt_id: str
    inputs: list[str] = Field(default_factory=list)
    provider: ModelProvider = ModelProvider.OPENAI
    model: str = "gpt-4o-mini"
    expected_outputs: list[str] | None = None


class BatchTestResult(BaseModel):
    """Result of a batch test run."""

    prompt_id: str
    total_inputs: int
    successful: int
    failed: int
    results: list[dict[str, Any]] = Field(default_factory=list)
    avg_latency_ms: float = 0.0
    total_tokens_used: int = 0
    estimated_cost_usd: float = 0.0


class ChainStep(BaseModel):
    """A single step in a chain-of-thought pipeline."""

    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:8])
    prompt_id: str
    name: str = ""
    output_variable: str = ""
    next_step_id: str | None = None


class ChainPipeline(BaseModel):
    """A chain-of-thought pipeline linking multiple prompts."""

    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str
    description: str = ""
    steps: list[ChainStep] = Field(default_factory=list)
    created_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class ChainRunResult(BaseModel):
    """Result of running a chain pipeline."""

    pipeline_id: str
    step_results: list[dict[str, Any]] = Field(default_factory=list)
    final_output: str = ""
    total_tokens_used: int = 0
    total_latency_ms: float = 0.0


class TokenCount(BaseModel):
    """Token count result for a specific model."""

    model: str
    token_count: int
    char_count: int
    estimated_cost_usd: float = 0.0


class QualityScore(BaseModel):
    """Quality scores for a prompt output."""

    coherence: float = Field(ge=0.0, le=1.0)
    relevance: float = Field(ge=0.0, le=1.0)
    safety: float = Field(ge=0.0, le=1.0)
    completeness: float = Field(ge=0.0, le=1.0)
    clarity: float = Field(ge=0.0, le=1.0)
    overall: float = Field(ge=0.0, le=1.0)
