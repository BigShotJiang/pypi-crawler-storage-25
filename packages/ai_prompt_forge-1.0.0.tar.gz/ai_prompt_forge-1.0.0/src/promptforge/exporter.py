"""Export prompts to JSON, YAML, and LangChain format."""

from __future__ import annotations

import json
from typing import Any

import yaml

from promptforge.models import ExportFormat, PromptTemplate
from promptforge.store import PromptStore


class PromptExporter:
    """Export prompt templates in various formats."""

    def __init__(self, store: PromptStore | None = None):
        self.store = store or PromptStore()

    def export_prompt(
        self,
        prompt: PromptTemplate,
        fmt: ExportFormat | str = ExportFormat.JSON,
    ) -> str:
        """Export a single prompt template to the specified format."""
        if isinstance(fmt, str):
            fmt = ExportFormat(fmt)

        if fmt == ExportFormat.JSON:
            return self._to_json(prompt)
        elif fmt == ExportFormat.YAML:
            return self._to_yaml(prompt)
        elif fmt == ExportFormat.LANGCHAIN:
            return self._to_langchain(prompt)
        else:
            raise ValueError(f"Unsupported export format: {fmt}")

    def export_all(
        self, fmt: ExportFormat | str = ExportFormat.JSON
    ) -> str:
        """Export all prompts to the specified format."""
        prompts = self.store.list_prompts()
        if isinstance(fmt, str):
            fmt = ExportFormat(fmt)

        if fmt == ExportFormat.JSON:
            return json.dumps(
                {"prompts": [p.model_dump() for p in prompts]}, indent=2
            )
        elif fmt == ExportFormat.YAML:
            return yaml.dump(
                {"prompts": [p.model_dump() for p in prompts]},
                default_flow_style=False,
                allow_unicode=True,
            )
        elif fmt == ExportFormat.LANGCHAIN:
            chains = [self._langchain_format(p) for p in prompts]
            return json.dumps(
                {"prompt_templates": chains}, indent=2
            )
        else:
            raise ValueError(f"Unsupported export format: {fmt}")

    def export_by_ids(
        self,
        prompt_ids: list[str],
        fmt: ExportFormat | str = ExportFormat.JSON,
    ) -> str:
        """Export selected prompts by ID."""
        prompts: list[PromptTemplate] = []
        for pid in prompt_ids:
            p = self.store.get_prompt(pid)
            if p:
                prompts.append(p)

        if isinstance(fmt, str):
            fmt = ExportFormat(fmt)

        if fmt == ExportFormat.JSON:
            return json.dumps(
                {"prompts": [p.model_dump() for p in prompts]}, indent=2
            )
        elif fmt == ExportFormat.YAML:
            return yaml.dump(
                {"prompts": [p.model_dump() for p in prompts]},
                default_flow_style=False,
                allow_unicode=True,
            )
        elif fmt == ExportFormat.LANGCHAIN:
            chains = [self._langchain_format(p) for p in prompts]
            return json.dumps({"prompt_templates": chains}, indent=2)
        else:
            raise ValueError(f"Unsupported export format: {fmt}")

    def _to_json(self, prompt: PromptTemplate) -> str:
        return json.dumps(prompt.model_dump(), indent=2)

    def _to_yaml(self, prompt: PromptTemplate) -> str:
        return yaml.dump(
            prompt.model_dump(),
            default_flow_style=False,
            allow_unicode=True,
        )

    def _to_langchain(self, prompt: PromptTemplate) -> str:
        return json.dumps(self._langchain_format(prompt), indent=2)

    def _langchain_format(self, prompt: PromptTemplate) -> dict[str, Any]:
        """Convert to LangChain PromptTemplate format."""
        return {
            "name": prompt.name,
            "template": prompt.template,
            "input_variables": prompt.extract_variables(),
            "template_format": "jinja2",
            "partial_variables": {
                v.name: v.default
                for v in prompt.variables
                if v.default is not None
            },
            "metadata": {
                "description": prompt.description,
                "category": prompt.category.value,
                "tags": prompt.tags,
                "model_hint": prompt.model_hint,
                "temperature": prompt.temperature,
                "max_tokens": prompt.max_tokens,
            },
        }
