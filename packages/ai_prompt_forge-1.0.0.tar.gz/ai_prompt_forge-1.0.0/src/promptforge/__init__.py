"""PromptForge — Advanced prompt engineering toolkit and playground."""

__version__ = "1.0.0"
__author__ = "PromptForge Contributors"
