"""Storage layer for PromptForge — handles persistence of templates and versions."""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from promptforge.models import (
    ABTestConfig,
    ABTestResult,
    ABTestSummary,
    BatchTestConfig,
    BatchTestResult,
    ChainPipeline,
    ChainRunResult,
    PromptTemplate,
    VersionDiff,
)

DEFAULT_DATA_DIR = Path.home() / ".promptforge" / "data"


class PromptStore:
    """File-based storage for prompt templates, versions, and test results."""

    def __init__(self, data_dir: Path | str | None = None):
        if data_dir is None:
            data_dir = os.environ.get("PROMPTFORGE_DATA_DIR")
            if data_dir:
                data_dir = Path(data_dir)
            else:
                data_dir = DEFAULT_DATA_DIR
        else:
            data_dir = Path(data_dir)

        self.data_dir = data_dir
        self.prompts_dir = data_dir / "prompts"
        self.versions_dir = data_dir / "versions"
        self.tests_dir = data_dir / "tests"
        self.chains_dir = data_dir / "chains"
        self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        for d in [
            self.prompts_dir,
            self.versions_dir,
            self.tests_dir,
            self.chains_dir,
        ]:
            d.mkdir(parents=True, exist_ok=True)

    def _prompt_path(self, prompt_id: str) -> Path:
        safe_id = "".join(c for c in prompt_id if c.isalnum() or c in "-_")
        if not safe_id:
            raise ValueError(f"Invalid prompt ID: {prompt_id}")
        return self.prompts_dir / f"{safe_id}.json"

    def _version_path(self, prompt_id: str, version: int) -> Path:
        safe_id = "".join(c for c in prompt_id if c.isalnum() or c in "-_")
        return self.versions_dir / f"{safe_id}_v{version}.json"

    # --- Prompt CRUD ---

    def save_prompt(self, prompt: PromptTemplate) -> PromptTemplate:
        """Save a prompt template, creating a version snapshot."""
        path = self._prompt_path(prompt.id)
        prompt.updated_at = datetime.now(timezone.utc).isoformat()
        path.write_text(prompt.model_dump_json(indent=2), encoding="utf-8")

        self._save_version(prompt)
        return prompt

    def get_prompt(self, prompt_id: str) -> PromptTemplate | None:
        """Retrieve a prompt template by ID."""
        path = self._prompt_path(prompt_id)
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return PromptTemplate(**data)

    def list_prompts(
        self,
        category: str | None = None,
        tag: str | None = None,
        search: str | None = None,
    ) -> list[PromptTemplate]:
        """List all prompts with optional filtering."""
        prompts: list[PromptTemplate] = []
        for path in sorted(self.prompts_dir.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                prompt = PromptTemplate(**data)
            except (json.JSONDecodeError, Exception):
                continue

            if category and prompt.category.value != category:
                continue
            if tag and tag not in prompt.tags:
                continue
            if search:
                search_lower = search.lower()
                if (
                    search_lower not in prompt.name.lower()
                    and search_lower not in prompt.description.lower()
                    and search_lower not in prompt.template.lower()
                ):
                    continue
            prompts.append(prompt)
        return prompts

    def delete_prompt(self, prompt_id: str) -> bool:
        """Delete a prompt template and all its versions."""
        path = self._prompt_path(prompt_id)
        if not path.exists():
            return False
        path.unlink()
        safe_id = "".join(c for c in prompt_id if c.isalnum() or c in "-_")
        for vpath in self.versions_dir.glob(f"{safe_id}_v*.json"):
            vpath.unlink()
        return True

    # --- Versioning ---

    def _save_version(self, prompt: PromptTemplate) -> None:
        """Save a version snapshot of the prompt."""
        path = self._version_path(prompt.id, prompt.version)
        path.write_text(prompt.model_dump_json(indent=2), encoding="utf-8")

    def get_version(self, prompt_id: str, version: int) -> PromptTemplate | None:
        """Retrieve a specific version of a prompt."""
        path = self._version_path(prompt_id, version)
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return PromptTemplate(**data)

    def list_versions(self, prompt_id: str) -> list[int]:
        """List all version numbers for a prompt."""
        safe_id = "".join(c for c in prompt_id if c.isalnum() or c in "-_")
        versions: list[int] = []
        for vpath in self.versions_dir.glob(f"{safe_id}_v*.json"):
            try:
                ver_str = vpath.stem.split("_v")[1]
                versions.append(int(ver_str))
            except (IndexError, ValueError):
                continue
        return sorted(versions)

    def diff_versions(
        self, prompt_id: str, old_ver: int, new_ver: int
    ) -> VersionDiff:
        """Compute a diff between two prompt versions."""
        old = self.get_version(prompt_id, old_ver)
        new = self.get_version(prompt_id, new_ver)
        if old is None:
            raise ValueError(f"Version {old_ver} not found for prompt {prompt_id}")
        if new is None:
            raise ValueError(f"Version {new_ver} not found for prompt {prompt_id}")

        old_lines = old.template.splitlines()
        new_lines = new.template.splitlines()

        additions: list[str] = []
        deletions: list[str] = []

        old_set = set(old_lines)
        new_set = set(new_lines)

        for line in new_lines:
            if line not in old_set:
                additions.append(line)
        for line in old_lines:
            if line not in new_set:
                deletions.append(line)

        summary_parts: list[str] = []
        if additions:
            summary_parts.append(f"+{len(additions)} lines")
        if deletions:
            summary_parts.append(f"-{len(deletions)} lines")
        summary = ", ".join(summary_parts) if summary_parts else "No changes"

        return VersionDiff(
            old_version=old_ver,
            new_version=new_ver,
            old_template=old.template,
            new_template=new.template,
            additions=additions,
            deletions=deletions,
            summary=summary,
        )

    def fork_version(self, prompt_id: str, version: int, new_name: str) -> PromptTemplate:
        """Create a new prompt from a specific version of an existing one."""
        source = self.get_version(prompt_id, version)
        if source is None:
            raise ValueError(f"Version {version} not found for prompt {prompt_id}")

        new_prompt = PromptTemplate(
            name=new_name,
            description=f"Forked from {source.name} v{version}",
            category=source.category,
            template=source.template,
            variables=[v.model_dump() for v in source.variables],
            tags=source.tags + ["forked"],
            model_hint=source.model_hint,
            temperature=source.temperature,
            max_tokens=source.max_tokens,
            parent_id=prompt_id,
        )
        return self.save_prompt(new_prompt)

    # --- A/B Testing ---

    def save_ab_test_config(self, config: ABTestConfig) -> None:
        path = self.tests_dir / f"ab_config_{config.id}.json"
        path.write_text(config.model_dump_json(indent=2), encoding="utf-8")

    def get_ab_test_config(self, test_id: str) -> ABTestConfig | None:
        path = self.tests_dir / f"ab_config_{test_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return ABTestConfig(**data)

    def save_ab_results(
        self, test_id: str, results: list[ABTestResult], summary: ABTestSummary
    ) -> None:
        results_path = self.tests_dir / f"ab_results_{test_id}.json"
        payload = {
            "results": [r.model_dump() for r in results],
            "summary": summary.model_dump(),
        }
        results_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def get_ab_results(self, test_id: str) -> dict[str, Any] | None:
        path = self.tests_dir / f"ab_results_{test_id}.json"
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    # --- Batch Testing ---

    def save_batch_result(self, result: BatchTestResult) -> None:
        path = self.tests_dir / f"batch_{result.prompt_id}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}.json"
        path.write_text(result.model_dump_json(indent=2), encoding="utf-8")

    # --- Chain Pipelines ---

    def save_chain(self, chain: ChainPipeline) -> ChainPipeline:
        path = self.chains_dir / f"{chain.id}.json"
        path.write_text(chain.model_dump_json(indent=2), encoding="utf-8")
        return chain

    def get_chain(self, chain_id: str) -> ChainPipeline | None:
        path = self.chains_dir / f"{chain_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return ChainPipeline(**data)

    def list_chains(self) -> list[ChainPipeline]:
        chains: list[ChainPipeline] = []
        for path in sorted(self.chains_dir.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                chains.append(ChainPipeline(**data))
            except (json.JSONDecodeError, Exception):
                continue
        return chains

    def save_chain_result(self, result: ChainRunResult) -> None:
        path = self.chains_dir / f"run_{result.pipeline_id}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}.json"
        path.write_text(result.model_dump_json(indent=2), encoding="utf-8")

    # --- Export ---

    def export_all(self) -> dict[str, Any]:
        """Export all prompts to a dictionary."""
        prompts = self.list_prompts()
        return {
            "version": "1.0.0",
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "prompts": [p.model_dump() for p in prompts],
        }
