"""
CLI Entry Point mapping
"""
import argparse
import asyncio
import sys
from .scraper import scrape_page
from .formatter import format_html

def main():
    parser = argparse.ArgumentParser(
        description="Ironcrawl CLI: Powerful terminal-first web scraping and AI extraction."
    )
    
    subparsers = parser.add_subparsers(dest="command", required=True, help="Available subcommands")
    
    # Scrape target command execution
    scrape_parser = subparsers.add_parser("scrape", help="Extract and structurally format data from a target URL.")
    scrape_parser.add_argument("url", type=str, help="Target URL (e.g., https://example.com)")
    scrape_parser.add_argument("--format", type=str, choices=["markdown", "json"], default="markdown", help="Target structural output format.")
    scrape_parser.add_argument("--out", type=str, help="Save to physical file rather than stdout.")
    scrape_parser.add_argument("--wait-network-idle", action="store_true", help="Tell Playwright to wait for JS networks to quiet.")
    scrape_parser.add_argument("--stealth", action="store_true", help="Implement playwright-stealth to bypass rigid WAF checks.")

    args = parser.parse_args()

    if args.command == "scrape":
        # 1. Pipeline: Scrape the page locally
        try:
            raw_html = asyncio.run(scrape_page(
                url=args.url,
                stealth=args.stealth,
                wait_idle=args.wait_network_idle
            ))
        except Exception as e:
            print(f"[-] Critical scraping error: {e}", file=sys.stderr)
            sys.exit(1)
            
        # 2. Pipeline: Route natively via Multi-Agent AI
        try:
            formatted_data = format_html(raw_html, output_format=args.format)
        except Exception as e:
            print(f"[-] Formatting failed during LLM evaluation: {e}", file=sys.stderr)
            sys.exit(1)
            
        # 3. Pipeline: Return Output Structure
        if args.out:
            try:
                with open(args.out, "w", encoding="utf-8") as f:
                    f.write(formatted_data)
                print(f"[+] Extraction complete and fully saved to {args.out}", file=sys.stderr)
            except Exception as e:
                print(f"[-] Save to disk failed: {e}", file=sys.stderr)
                sys.exit(1)
        else:
            # We strictly print clean data to stdout for CLI manipulation piping
            print(formatted_data)

if __name__ == "__main__":
    main()
