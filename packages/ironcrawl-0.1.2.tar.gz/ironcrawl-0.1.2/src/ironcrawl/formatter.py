import sys
import tempfile
import os
from bs4 import BeautifulSoup
from markitdown import MarkItDown
from nixagent import Agent
from dotenv import load_dotenv

load_dotenv()

def extract_chunks_with_bs4(html: str) -> str:
    soup = BeautifulSoup(html, 'html.parser')
    for doc_struct in soup(["script", "style", "noscript", "meta", "header", "footer", "nav", "aside"]):
        doc_struct.decompose()
    return soup.get_text(separator=' ', strip=True)


def format_html(raw_html: str, output_format: str = "markdown") -> str:
    print(f"[*] Initiating chunking protocols using Microsoft MarkItDown...", file=sys.stderr)
    try:
        md = MarkItDown()
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w", encoding="utf-8") as temp_file:
            temp_file.write(raw_html)
            temp_path = temp_file.name
            
        result = md.convert(temp_path)
        os.remove(temp_path)
        extracted_text = result.text_content
        print("[+] MarkItDown successfully stripped payload natively!", file=sys.stderr)
    except Exception as e:
        print(f"[-] MarkItDown string parse failed ({e}). Falling back to BeautifulSoup...", file=sys.stderr)
        extracted_text = extract_chunks_with_bs4(raw_html)
        
    print(f"[*] Dispatching contextual formatting to nixagent in dynamic N line chunks...", file=sys.stderr)
    
    # Python-level exact extraction map instead of relying on unreliable LLM tool loops
    lines = extracted_text.splitlines()
    chunk_size = 200 # Processing N lines dynamically
    
    active_agent = os.environ.get("ACTIVE_AGENT", "nixagent").lower()
    system_prompt = f"You are a Documentation Formatter processing partial structural strings sequentially."
    
    if active_agent == "ocode":
        import ocode
        print("[*] Launching execution engine via Native OpenCode client (ocode)...", file=sys.stderr)
        formatter_agent = ocode.Agent(
            name="DocumentationRefiner",
            system_prompt=system_prompt,
            base_url=os.environ.get("OPENCODE_BASE_URL"),
            project_path=os.environ.get("OPENCODE_PROJECT_PATH")
        )
    else:
        print("[*] Launching execution engine via Nixagent Core...", file=sys.stderr)
        formatter_agent = Agent(
            name="DocumentationRefiner",
            system_prompt=system_prompt,
            use_builtin_tools=False
        )
    
    final_output = []
    json_master_array = []
    
    for i in range(0, len(lines), chunk_size):
        chunk = "\n".join(lines[i:i+chunk_size])
        if not chunk.strip():
            continue
            
        print(f"[*] Formatting chunk {i} to {i+chunk_size}...", file=sys.stderr)
        
        if output_format == "json":
            prompt = f"Extract the primary data items from the following web text chunk into a strict JSON array of objects. Output EXACTLY a serialized JSON array (`[]`) and absolutely no other text, preambles, or markdown formatting.\n\n[CHUNK]\n{chunk}"
            chunk_response = formatter_agent.run(user_prompt=prompt)
            # Try to safely extract and parse the JSON string from the LLM output
            try:
                import json
                import re
                
                # Use robust regex to find the outermost JSON array structure 
                # (to ignore any LLM chatter like 'Here is the JSON:')
                match = re.search(r'\[\s*(.*)\s*\]', chunk_response, re.DOTALL)
                
                if match:
                    json_str = match.group(0) # Grab exactly the bracket mapping
                    parsed_json = json.loads(json_str)
                    
                    if isinstance(parsed_json, list):
                        json_master_array.extend(parsed_json)
                    else:
                        json_master_array.append(parsed_json)
                else:
                    raise Exception("No JSON array logic block found")
                    
            except Exception as e:
                print(f"[-] Warning: Failed to parse JSON chunk {i} ({e}). Skipping.", file=sys.stderr)
        else:
            prompt = f"Format and clean the following chunk of web extracted text into professional {output_format}:\n\n{chunk}"
            chunk_response = formatter_agent.run(user_prompt=prompt)
            final_output.append(chunk_response)

    if output_format == "json":
        import json
        return json.dumps(json_master_array, indent=4)
    return "\n\n".join(final_output)
