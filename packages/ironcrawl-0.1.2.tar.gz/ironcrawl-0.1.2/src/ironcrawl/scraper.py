"""
Scraping Engine using Playwright and Stealth.
"""
import sys
from playwright.async_api import async_playwright

async def scrape_page(url: str, stealth: bool = False, wait_idle: bool = True) -> str:
    """
    Navigates to URL, bypasses WAF using stealth (optionally),
    waits for network idle, and returns raw HTML.
    """
    async with async_playwright() as p:
        # Launch headless browser
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        
        if stealth:
            try:
                from playwright_stealth import Stealth
                page = await context.new_page()
                await Stealth().apply_stealth_async(page)
                print("[*] Stealth mode enabled.", file=sys.stderr)
            except ImportError:
                print("[-] Warning: playwright-stealth not installed. Continuing normally...", file=sys.stderr)
                page = await context.new_page()
        else:
            page = await context.new_page()
            
        wait_until = "networkidle" if wait_idle else "domcontentloaded"
        
        print(f"[*] Navigating to {url} (Wait Target: {wait_until})...", file=sys.stderr)
        try:
            # Add timeout to prevent perpetual hanging on infinite-ping sites like Amazon/Flipkart
            await page.goto(url, wait_until=wait_until, timeout=20000)
        except Exception as e:
            print(f"[-] Warning during navigation wait: {e}", file=sys.stderr)
        
        print(f"[*] Extracting raw HTML content...", file=sys.stderr)
        html_content = await page.content()
        await browser.close()
        
        return html_content
