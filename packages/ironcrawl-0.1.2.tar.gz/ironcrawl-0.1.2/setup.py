from setuptools import setup, find_packages

setup(
    name="ironcrawl",
    version="0.1.2",
    description="Powerful terminal-first web scraping and AI extraction tool.",
    author="Ironcrawl Contributors",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "nixagent",
        "python-dotenv",
        "playwright",
        "playwright-stealth",
        "beautifulsoup4",
        "markitdown",
        "ocode"
    ],
    entry_points={
        "console_scripts": [
            "ironcrawl=ironcrawl.cli:main",
        ]
    },
    python_requires=">=3.10",
)
