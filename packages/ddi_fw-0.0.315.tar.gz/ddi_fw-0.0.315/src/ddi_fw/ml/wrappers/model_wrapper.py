from typing import Any, Dict, List, Optional, Tuple
import time

import numpy as np

from ddi_fw.ml.evaluation_helper import Metrics, evaluate


class ModelWrapper:
    def __init__(self, date, descriptor, model_func, **kwargs):
        self.date = date
        self.descriptor = descriptor
        self.model_func = model_func
        self.kwargs = kwargs

        self.elapsed_time: float | None = None

        # Optional multi-test support:
        # {"kk": (X_kk, y_kk), "ku": (X_ku, y_ku), "uu": (X_uu, y_uu)}
        self.test_sets: Dict[str, Tuple[Any, Any]] = kwargs.get("test_sets", {})

        # Default dataset slots (set via set_data)
        self.train_idx_arr = None
        self.val_idx_arr = None
        self.train_data = None
        self.train_label = None
        self.test_data = None
        self.test_label = None

    def set_data(self, train_idx_arr, val_idx_arr, train_data, train_label, test_data, test_label):
        self.train_idx_arr = train_idx_arr
        self.val_idx_arr = val_idx_arr
        self.train_data = train_data
        self.train_label = train_label
        self.test_data = test_data
        self.test_label = test_label

    
    def set_test_sets(self, test_sets: Dict[str, Tuple[Any, Any]]):
        validated: Dict[str, Tuple[Any, Any]] = {}
        for k, v in (test_sets or {}).items():
            if not isinstance(v, tuple) or len(v) != 2:
                raise ValueError(
                    f"Invalid test_sets['{k}'] payload. Expected tuple: (X_test, y_test)."
                )
            validated[k] = v
        self.test_sets = validated

    def _resolve_test_payload(self, scenario: Optional[str] = None) -> Tuple[Any, Any]:
        """
        Always returns (X_test, y_test).
        """
        if scenario is None:
            payload = (self.test_data, self.test_label)
        else:
            if scenario not in self.test_sets:
                raise KeyError(
                    f"Scenario '{scenario}' not found in test_sets. "
                    f"Available: {list(self.test_sets.keys())}"
                )
            payload = self.test_sets[scenario]

        if not isinstance(payload, tuple) or len(payload) != 2:
            raise ValueError(
                f"Invalid test payload for scenario={scenario!r}. "
                "Expected tuple: (X_test, y_test)."
            )

        return payload

    def _predict(self, model, X) -> Any:
        raise NotImplementedError("_predict must be implemented in subclasses")

    def predict(self, scenario: Optional[str] = None) -> Any:
        """
        Two supported usages:
        - predict()                  -> default single test set
        - predict('kk'/'ku'/'uu')    -> scenario test set
        """
        raise NotImplementedError("predict must be implemented in subclasses")

    def predict_for_scenario(self, scenario: str) -> Any:
        return self.predict(scenario=scenario)

    def fit_model(self, X_train, y_train, X_valid, y_valid) -> Any:
        raise NotImplementedError("fit_model must be implemented in subclasses")

    def fit(self) -> Any:
        raise NotImplementedError("fit must be implemented in subclasses")

    def fit_and_evaluate(self, print_detail: bool = False):
        raise NotImplementedError

    def _prepare_eval_arrays(self, actual: Any, pred: Any) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generic conversion for evaluate():
        - supports label-vs-proba mismatches
        - supports one-hot-vs-label mismatches
        """
        y_true = np.asarray(actual)
        y_pred = np.asarray(pred)

        # Case A: y_true is one-hot, y_pred are class labels -> one-hot encode y_pred
        if y_true.ndim == 2 and y_pred.ndim == 1:
            num_classes = y_true.shape[1]
            y_pred = np.eye(num_classes, dtype=y_true.dtype)[y_pred.astype(int)]

        # Case B: y_true is labels, y_pred are probabilities/logits -> argmax y_pred
        elif y_true.ndim == 1 and y_pred.ndim == 2:
            y_pred = np.argmax(y_pred, axis=1)

        # Case C: both 2D but different class dims -> reduce pred to labels if needed
        elif y_true.ndim == 2 and y_pred.ndim == 2 and y_true.shape[1] != y_pred.shape[1]:
            y_pred = np.argmax(y_pred, axis=1)
            y_true = np.argmax(y_true, axis=1)

        return y_true, y_pred

    def fit_and_evaluate_scenarios(
        self,
        scenarios: List[str],
        print_detail: bool = False
    ) -> Dict[str, Tuple[dict[str, Any], Metrics, Any]]:
        """
        Train once, evaluate many test scenarios.
        Works for wrappers that implement:
          - fit() returning best model as first item or single return value
          - predict(scenario=...)
        """
        if not scenarios:
            raise ValueError("scenarios cannot be empty")

        # Ensure model is trained once
        best_model = getattr(self, "best_model", None)
        if best_model is None:
            fit_result = self.fit()
            if isinstance(fit_result, tuple):
                best_model = fit_result[0]
            else:
                best_model = fit_result
            self.best_model = best_model

        results: Dict[str, Tuple[dict[str, Any], Metrics, Any]] = {}

        for scenario in scenarios:
            pred = self.predict(scenario=scenario)
            _, actual = self._resolve_test_payload(scenario=scenario)

            y_true_eval, y_pred_eval = self._prepare_eval_arrays(actual, pred)

            logs, metrics = evaluate(
                actual=y_true_eval,
                pred=y_pred_eval,
                info=f"{self.descriptor}_{scenario}",
                print_detail=print_detail
            )
            if hasattr(metrics, "format_float"):
                metrics.format_float()

            results[scenario] = (logs, metrics, pred)

            tracking_service = getattr(self, "tracking_service", None)
            if tracking_service is not None:
                tracking_service.log_metrics({f"{scenario}_{k}": v for k, v in logs.items()})

        return results

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)

        if hasattr(cls, "fit"):
            original_method = cls.fit

            def timed_fit(self, *args, **kwargs):
                start = time.perf_counter()
                result = original_method(self, *args, **kwargs)
                self.elapsed_time = time.perf_counter() - start
                return result

            cls.fit = timed_fit