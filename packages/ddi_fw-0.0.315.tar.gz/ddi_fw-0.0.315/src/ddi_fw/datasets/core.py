import abc
from collections import defaultdict
import glob
import logging
from typing import Any, Dict, List, Optional, Type,Tuple
import os
# import chromadb
# from chromadb.api.types import IncludeEnum
import numpy as np
import pandas as pd
from pydantic import BaseModel, Field, PrivateAttr, computed_field, model_validator
from ddi_fw.datasets.dataset_splitter import DatasetSplitter
from ddi_fw.langchain.faiss_storage import BaseVectorStoreManager
from ddi_fw.utils.utils import create_folder_if_not_exists
from sklearn.metrics.pairwise import cosine_similarity


try:
    from ddi_fw.vectorization import SimilarityMatrixGenerator, VectorGenerator
except ImportError:
    raise ImportError(
        "Failed to import vectorization module. Ensure that the module exists and is correctly installed. ")

try:
    from ddi_fw.langchain.embeddings import PoolingStrategy
except ImportError:
    raise ImportError(
        "Failed to import langchain.embeddings module. ")

logger = logging.getLogger(__name__)

def stack(df_column):
    return np.stack(df_column.values)


def generate_vectors(df, columns):
    vectorGenerator = VectorGenerator(df)
    generated_vectors = vectorGenerator.generate_feature_vectors(
        columns)
    return generated_vectors


def generate_sim_matrices_new(df, generated_vectors, columns, similarity_type='jaccard', key_column="id"):
    """
    Generate similarity matrices for given columns.

    similarity_type: either a string ('jaccard' or 'cosine') or a callable that accepts a matrix and returns
    a square similarity matrix (numpy array / array-like). Strings are mapped to methods on SimilarityMatrixGenerator.
    """
    sim_matrix_gen = SimilarityMatrixGenerator()

    # registry of built-in similarity names -> callable
    registry = {
        'jaccard': sim_matrix_gen.create_jaccard_similarity_matrices,
        'cosine': sim_matrix_gen.create_cosine_similarity_matrices,
    }

    # resolve similarity function
    if callable(similarity_type):
        sim_func = similarity_type
    elif isinstance(similarity_type, str):
        sim_func = registry.get(similarity_type.lower())
        if sim_func is None:
            raise ValueError(f"Unknown similarity_type '{similarity_type}'. Available: {list(registry.keys())}")
    else:
        raise TypeError("similarity_type must be a string or a callable")

    sim_dict = {}
    for column in columns:
        key = column
        matrix = generated_vectors[key]
        sim_dict[column] = sim_func(matrix)

    # convert to DataFrame with original keys as row/col labels
    similarity_matrices = {}
    keys = df[key_column].to_list()
    new_columns = {idx: keys[idx] for idx in range(len(keys))}

    for column in columns:
        new_df = pd.DataFrame.from_dict(sim_dict[column])
        new_df = new_df.rename(index=new_columns, columns=new_columns)
        similarity_matrices[column] = new_df

    return similarity_matrices

class BaseDataset(BaseModel, abc.ABC):
    dataset_name: str
    index_path: Optional[str] = None
    dataset_splitter_type: Type[DatasetSplitter]
    class_column: str = 'class'
    dataframe: Optional[pd.DataFrame] = None
    X_train: Optional[np.ndarray] = None
    X_test: Optional[np.ndarray] = None
    y_train: Optional[np.ndarray] = None
    y_test: Optional[np.ndarray] = None
    train_indexes: Optional[pd.Index] = None
    test_indexes: Optional[pd.Index] = None
    train_idx_arr: Optional[List[np.ndarray]] = None
    val_idx_arr: Optional[List[np.ndarray]] = None
    columns: List[str] = []
    additional_config: Optional[Dict[str, Any]] = None
    input_processing: Optional[List[Dict[str, Any]]] = None

    scenario: str = Field(
        default="kk", description="The scenario to load (e.g., 'kk', 'ku', 'uu').")
    test_scenarios: List[str] = Field(
        default_factory=lambda: ["kk", "ku", "uu"],
        description="Optional scenario names (e.g., ['kk','ku','uu']) to cache test sets for."
    )
    cached_test_sets: Dict[str, Tuple[np.ndarray, np.ndarray]] = Field(default_factory=dict)

    _dataset_splitter_instance: Optional[DatasetSplitter] = PrivateAttr(default=None)
    _prepared_once: bool = PrivateAttr(default=False)

    # 1. Add the private cache attribute
    _dataset_splitter_instance: Optional[DatasetSplitter] = PrivateAttr(default=None)

    class Config:
        arbitrary_types_allowed = True
        
    def process_input_data(self,data, processing_config=None):
        
        if not processing_config:
            return data
        if processing_config.get("flatten", False):
            print("Flattening data...")
            data = np.array(data).flatten()
            print(f"Data shape after flattening: {data.shape}")
        
        if processing_config.get("stack", False):
            print("Stacking data...")
            data = np.stack(data)
            print(f"Data shape after stacking: {data.shape}")
        if not isinstance(data, np.ndarray):
            data = np.array(data)
        # if processing_config.get("flatten", False):
        #     data = np.stack(data.flatten().tolist())
        # Ensure we start with a NumPy array
       

        # Normalize input
        if processing_config.get("normalize", False):
            data = data.astype(np.float32)
            max_val = np.max(data)
            if max_val > 1:
                data /= max_val

        # Reshape input (for images etc.)
        if "reshape" in processing_config:
            try:
                target_shape = tuple(processing_config["reshape"])
                data = data.reshape((-1, *target_shape))
            except Exception as e:
                raise ValueError(f"Reshape failed for data with shape {data.shape}: {e}")


        return data

    # TODO columns yoksa tüm feature'lar alınıyor, bu pipeline'da nasıl yapılacak?
    # TODO processor sınıfı kullanılsın
    def produce_inputs(self):
        # Grouping the list by "column" key
        grouped_data = defaultdict(dict)

        if self.input_processing:
            for item in self.input_processing:
                grouped_data[item["column"]] = item
                
        items = []
        if self.X_train is None or self.X_test is None:
            raise Exception("There is no data to produce inputs")
        y_train_label, y_test_label = np.array(
            self.y_train), np.array(self.y_test)

        if self.columns is None or len(self.columns) == 0 or len(self.columns) == 1:
            # If no columns or only one column are provided, do not change the data
            # and use the entire dataset as a single input.
            column = self.columns[0] if self.columns else 'default'
            train_data, test_data = self.X_train[:, :], self.X_test[:, :]
            processing_config = grouped_data[column]
            train_data = self.process_input_data(train_data, processing_config)
            test_data = self.process_input_data(test_data, processing_config)
            # train_data,test_data = np.stack(train_data.flatten().tolist()), np.stack(test_data.flatten().tolist())
            items.append([f'{column}', np.nan_to_num(train_data),
                          y_train_label, np.nan_to_num(test_data), y_test_label])
        else:
            for index, column in enumerate(self.columns):
                processing_config = grouped_data[column]
                train_data, test_data = self.X_train[:,
                                                     index], self.X_test[:, index]
                #TODO üstteki satır ile alttaki tek satır olsun, tolist() ile numpy array'e çevrilmesin, numpy array zaten ama uyarı verdiği için böyle
                train_data = self.process_input_data(train_data, processing_config)
                test_data = self.process_input_data(test_data, processing_config)
                # train_data,test_data = np.stack(train_data.tolist()), np.stack(test_data.tolist())
                items.append([f'{column}', np.nan_to_num(train_data),
                              y_train_label, np.nan_to_num(test_data), y_test_label])

                # items.append([f'{column}_embedding', train_data,
                #             y_train_label, test_data, y_test_label])
        return items
 

    @computed_field
    @property
    def dataset_splitter(self) -> DatasetSplitter:
        return self.dataset_splitter_type()

    def set_dataframe(self, dataframe: pd.DataFrame):
        self.dataframe = dataframe

    @abc.abstractmethod
    def prep(self):
        """Prepare the dataset. This method should be overridden in subclasses."""
        

    def handle_mixins(self):
        """Handle mixin-specific logic."""
        if isinstance(self, TextDatasetMixin):
            self.process_text()
        # if isinstance(self, ImageDatasetMixin):
        #     self.process_image_data()
        # Add other mixin-specific logic here
        
    def _ensure_prepared(self):
        if not self._prepared_once:
            self.handle_mixins()
            self.prep()
            self._prepared_once = True

    def _load_test_only_for_scenario(self, scenario_name: str, columns_to_keep: List[str]) -> Tuple[np.ndarray, np.ndarray]:
        scenario_path = os.path.join(self.index_path, scenario_name)
        if not os.path.isdir(scenario_path):
            raise FileNotFoundError(f"Scenario folder not found: {scenario_path}")

        test_idx = self.__read_raw_indexes_file__(os.path.join(scenario_path, "test_indexes.txt"))
        dataframe_index_set = set(self.dataframe.index)
        valid_te_all = [x for x in test_idx if x in dataframe_index_set]

        test_df = self.dataframe.loc[valid_te_all, columns_to_keep]
        X_test = np.array(test_df.drop(self.class_column, axis=1))
        y_test = np.array(test_df[self.class_column].tolist())
        return X_test, y_test    
        
    def load(self):
        """
        Loads train/val/test for self.scenario.
        Optionally caches additional test sets (kk/ku/uu) without full reload.
        """
        self._ensure_prepared()
        
        # 1. Normalize scenario name and validate path
        scenario_name = self.scenario.lower() if self.scenario else ""
        target_path = os.path.join(self.index_path, scenario_name) if scenario_name else self.index_path

        if scenario_name and not os.path.isdir(target_path):
            logger.warning(f"Scenario folder '{target_path}' not found! Falling back to root.")
            target_path = self.index_path

        is_entity_scenario = scenario_name in ['kk', 'ku', 'uu'] and os.path.basename(target_path) == scenario_name
        
        if is_entity_scenario:
            tr_all, te_all, tr_folds, val_folds = self.__get_raw_indexes__(target_path)
        else:
            tr_all, te_all, tr_folds, val_folds = self.__get_indexes__(target_path)

        # 2. Prevent KeyError via Data Drift Filtering
        dataframe_index_set = set(self.dataframe.index)
        valid_tr_all = [x for x in tr_all if x in dataframe_index_set]
        valid_te_all = [x for x in te_all if x in dataframe_index_set]

        # 3. YOUR FIX: Filter by Feature Columns
        columns_to_keep = self.columns + [self.class_column]
        train_df = self.dataframe.loc[valid_tr_all, columns_to_keep]
        test_df = self.dataframe.loc[valid_te_all, columns_to_keep]

        # 4. COLD START CONCATENATION (Critical for UU/KU Validation!)
        if is_entity_scenario and scenario_name in ['ku', 'uu']:
            combined_df = pd.concat([train_df, test_df])
            print(f"[{scenario_name.upper()}] Appending test set to training array for validation access.")
        else:
            combined_df = train_df

        # 5. Convert to NumPy arrays for the framework
        X_train = combined_df.drop(self.class_column, axis=1)
        y_train = combined_df[self.class_column]
        
        X_test = test_df.drop(self.class_column, axis=1)
        y_test = test_df[self.class_column]

        self.X_train = np.array(X_train)
        self.y_train = np.array(y_train.tolist())
        
        self.X_test = np.array(X_test)
        self.y_test = np.array(y_test.tolist())

        # 6. SAFE MAPPING: Translate global row labels -> relative NumPy positions
        combined_index = pd.Index(combined_df.index)

        self.train_idx_arr = []
        self.val_idx_arr = []

        for fold_idx, (f_tr, f_val) in enumerate(zip(tr_folds, val_folds)):
            mapped_tr = combined_index.get_indexer(pd.Index(f_tr))
            mapped_val = combined_index.get_indexer(pd.Index(f_val))

            missing_tr = int((mapped_tr < 0).sum())
            missing_val = int((mapped_val < 0).sum())
            if missing_tr or missing_val:
                logger.warning(
                    "Fold %s (%s): dropped missing labels from index files "
                    "(train=%s, val=%s)",
                    fold_idx,
                    scenario_name if scenario_name else "default",
                    missing_tr,
                    missing_val,
                )

            self.train_idx_arr.append(mapped_tr[mapped_tr >= 0].astype(np.int64, copy=False))
            self.val_idx_arr.append(mapped_val[mapped_val >= 0].astype(np.int64, copy=False))

        # 7. Defensive bounds sanitization for downstream numpy indexing
        self.train_idx_arr, self.val_idx_arr = self.__sanitize_fold_indexes__(
            self.train_idx_arr,
            self.val_idx_arr,
            len(self.X_train), # This is critical
            f"{scenario_name}_load" if scenario_name else "default_load",
        )
        # 8. Set final framework metadata
        # IMPORTANT: index space must match self.X_train (combined_df for KU/UU).
        self.train_indexes = combined_df.index
        self.test_indexes = test_df.index
        
        self.cached_test_sets = {}
        selected_scenarios = [s.lower() for s in (self.test_scenarios or [])]

        if scenario_name:
            self.cached_test_sets[scenario_name] = (self.X_test, self.y_test)

        for sc in selected_scenarios:
            if sc in self.cached_test_sets:
                continue
            if not self.index_path:
                continue
            scenario_dir = os.path.join(self.index_path, sc)
            if not os.path.isdir(scenario_dir):
                continue
            try:
                self.cached_test_sets[sc] = self._load_test_only_for_scenario(sc, columns_to_keep)
            except Exception as ex:
                logger.warning("Skipping scenario '%s' test cache: %s", sc, ex)

        
        
        print(f"✅ Loaded {scenario_name if scenario_name else 'default'} scenario.")
        print(f"   Train Shape: {self.X_train.shape}, Test Shape: {self.X_test.shape}")

    def __sanitize_fold_indexes__(self, train_folds, val_folds, train_size, context):
        sanitized_tr, sanitized_val = [], []
        for i, (tr, val) in enumerate(zip(train_folds, val_folds)):
            # Filter indices to ensure they are within [0, train_size - 1]
            # tr = tr.astype(int)
            valid_tr = tr[(tr >= 0) & (tr < train_size)]
            valid_val = val[(val >= 0) & (val < train_size)]
            
            if len(valid_tr) < len(tr) or len(valid_val) < len(val):
                logger.warning(f"Context [{context}] Fold {i}: Dropped {len(tr)-len(valid_tr)} OOB indices.")
                
            sanitized_tr.append(valid_tr)
            sanitized_val.append(valid_val)
        return sanitized_tr, sanitized_val

    @staticmethod
    def __save_raw_indexes__(path: str, file_name: str, values: Any):
        arr = np.asarray(values).reshape(-1)
        np.savetxt(os.path.join(path, file_name), arr, fmt='%d')

    @staticmethod
    def __read_raw_indexes_file__(file_path: str) -> np.ndarray:
        data = np.loadtxt(file_path, dtype=np.int64)
        if np.isscalar(data):
            return np.array([int(data)], dtype=np.int64)
        return np.asarray(data, dtype=np.int64)

    @staticmethod
    def __save_indexes__(path: str, file_name: str, values: Any):
        arr = np.asarray(values).reshape(-1)
        np.savetxt(os.path.join(path, file_name), arr, fmt='%d')

    def __get_indexes__(self, path: str) -> Tuple[np.ndarray, np.ndarray, List[np.ndarray], List[np.ndarray]]:
        """
        Backward-compatible index loader for standard (non-scenario) datasets.
        Uses the same raw index files as __get_raw_indexes__.
        """
        return self.__get_raw_indexes__(path)

    def __get_raw_indexes__(self, path: str) -> Tuple[np.ndarray, np.ndarray, List[np.ndarray], List[np.ndarray]]:
        train_all = self.__read_raw_indexes_file__(os.path.join(path, 'train_indexes.txt'))
        test_all = self.__read_raw_indexes_file__(os.path.join(path, 'test_indexes.txt'))

        train_folds: List[np.ndarray] = []
        val_folds: List[np.ndarray] = []
        for i in range(self.dataset_splitter.fold_size):
            train_folds.append(self.__read_raw_indexes_file__(os.path.join(path, f'train_fold_{i}.txt')))
            val_folds.append(self.__read_raw_indexes_file__(os.path.join(path, f'validation_fold_{i}.txt')))

        return train_all, test_all, train_folds, val_folds
    
    def split_dataset(self, save_indexes: bool = False):
        """
        Overrides core split_dataset to support entity-disjoint scenario folders.
        """
        if self.X_train is not None or self.X_test is not None:
            raise Exception("X_train and X_test are already present.")

        self.prep()
        if self.dataframe is None:
            raise Exception("There is no dataframe to split.")
 
        X = self.dataframe.drop(self.class_column, axis=1)
        y = self.dataframe[self.class_column]

        # 1. Standard 8-item unpack from the cached splitter
        # !!control it
        X_tr, X_te, y_tr, y_te, tr_idx, te_idx, tr_arr, val_arr = self.dataset_splitter.split(X=X, y=y)
        
        # 2. Assign attributes (X_train is 80% KK, X_test is UU)
        self.X_train, self.X_test = np.array(X_tr), np.array(X_te)
        self.y_train, self.y_test = np.array(y_tr.tolist()), np.array(y_te.tolist())
        self.train_indexes, self.test_indexes = tr_idx, te_idx
        self.train_idx_arr, self.val_idx_arr = tr_arr, val_arr

        self.train_idx_arr, self.val_idx_arr = self.__sanitize_fold_indexes__(
            self.train_idx_arr,
            self.val_idx_arr,
            len(self.X_train),
            "split_dataset",
        )

        if save_indexes:
            base_path = self.index_path
            splitter = self.dataset_splitter

            # 3. Check if using EntityDisjointSplitter with scenarios
            if hasattr(splitter, "scenarios") and splitter.scenarios:
                print(f"Detected {len(splitter.scenarios)} scenarios. Creating subfolders...")
                
                # Master training indices for ALL folders (the 80% KK pool)
                master_train_indices = tr_idx.values 

                for name, data in splitter.scenarios.items():
                    scenario_path = os.path.join(base_path, name)
                    create_folder_if_not_exists(scenario_path)
                    
                    # Save Master Scenario indices
                    self.__save_raw_indexes__(scenario_path, 'train_indexes.txt', master_train_indices)
                    self.__save_raw_indexes__(scenario_path, 'test_indexes.txt', data["test_idx"])

                    # Save specific folds
                    for i, (f_train, f_val) in enumerate(zip(data["train"], data["val"])):
                        self.__save_raw_indexes__(scenario_path, f'train_fold_{i}.txt', f_train)
                        self.__save_raw_indexes__(scenario_path, f'validation_fold_{i}.txt', f_val)
                
                print(f"✅ Indices successfully saved to: {list(splitter.scenarios.keys())}")
            else:
                # Fallback to standard single-folder logic
                print("Using standard splitter. Saving to root index folder.")
                self.__save_indexes__(base_path, 'train_indexes.txt', self.train_indexes.values)
                self.__save_indexes__(base_path, 'test_indexes.txt', self.test_indexes.values)
                for i, (tr_fold, val_fold) in enumerate(zip(self.train_idx_arr, self.val_idx_arr)):
                    self.__save_indexes__(base_path, f'train_fold_{i}.txt', tr_fold)
                    self.__save_indexes__(base_path, f'validation_fold_{i}.txt', val_fold)


class TextDatasetMixin(BaseModel):
    embedding_dict: Dict[str, Any] | None = Field(
        default_factory=dict, description="Dictionary for embeddings")
    pooling_strategy: PoolingStrategy | None = None
    column_embedding_configs: Optional[List] = None
    vector_store_manager: BaseVectorStoreManager| None = None  # <-- NEW

    vector_db_persist_directory: Optional[str] = None
    vector_db_collection_name: Optional[str] = None
    _embedding_size: int

    @computed_field
    @property
    def embedding_size(self) -> int:
        return self._embedding_size

    class Config:
        arbitrary_types_allowed = True
 
    def __calculate_embedding_size(self):
        if not self.embedding_dict:
            raise ValueError("Embedding dictionary is not initialized, embedding size cannot be calculated.")
            
        key, value = next(iter(self.embedding_dict.items()))
        self._embedding_size = value[next(iter(value))][0].shape[0]

    def process_text(self):
        logging.info("Processing text data...")
 
      
        if not self.embedding_dict:
            if self.vector_store_manager is not None:
                self.embedding_dict = self.vector_store_manager.initialize_embedding_dict()
            else:
                raise ValueError("Either embedding_dict or vector_store_manager must be provided for text processing.")
        self.__calculate_embedding_size()
         


# class ImageDatasetMixin(BaseModel):
#     image_size: tuple[int, int] = Field(default=(224, 224))
#     augmentations: list[str] = Field(default_factory=list)

#     def process_image_data(self):
#         print(
#             f"Processing image data with size {self.image_size} and augmentations {self.augmentations}...")
