import os

import pytest

torch = pytest.importorskip("torch")


def test_cuda_availability():
    available = torch.cuda.is_available()
    if os.getenv("REQUIRE_CUDA") == "1":
        assert available is True
    else:
        assert isinstance(available, bool)