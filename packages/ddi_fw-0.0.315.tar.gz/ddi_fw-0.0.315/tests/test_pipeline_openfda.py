import json
import os
from pathlib import Path

import pytest

from ddi_fw.pipeline import MultiPipeline
def _load_dotenv_if_available() -> None:
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv()

@pytest.fixture(scope="session")
def kaggle_dataset_path():
    """
    Downloads the Kaggle dataset if not present and returns the local path.
    'kagglehub' automatically checks if the dataset is already downloaded.
    """
    kagglehub = pytest.importorskip("kagglehub")
    _load_dotenv_if_available()
    # Ensure credentials are in environment for kagglehub/kaggle
    os.environ['KAGGLE_USERNAME'] = os.getenv('KAGGLE_USERNAME', '')
    os.environ['KAGGLE_KEY'] = os.getenv('KAGGLE_KEY', '')
    if not os.environ['KAGGLE_USERNAME'] or not os.environ['KAGGLE_KEY']:
        pytest.skip("Kaggle credentials not set.")
    
    dataset_handle = "kivancbayraktar/96b9dbee-754d-4a80-a903-bcdc957c2098"
    path = kagglehub.dataset_download(dataset_handle)
    print(f"\n[INFO] Dataset path: {path}")
    return path


@pytest.mark.integration
def test_pipeline_creation_openfda2(kaggle_dataset_path):
    print(f"\n[INFO] Using dataset from: {kaggle_dataset_path}")
    if os.getenv("RUN_INTEGRATION_TESTS") != "1":
        pytest.skip("Set RUN_INTEGRATION_TESTS=1 to enable pipeline tests.")

    config_path = Path("./tests/config/pipeline_kk_all_mpnet.json")
    if not config_path.exists():
        pytest.skip("OpenFDA pipeline config missing.")

    with open(config_path, "r") as f:
        config = json.load(f)

    mp = MultiPipeline(experiments_config=config).build()
    mp.run()
    assert mp.results()