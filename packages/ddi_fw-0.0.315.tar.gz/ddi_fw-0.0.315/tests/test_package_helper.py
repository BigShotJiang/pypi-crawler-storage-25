import pytest
from ddi_fw.utils import get_import  # replace your_module with actual module name
from tests.config.models import DNN  # replace with actual path to DNN class

def test_valid_import():
    func = get_import("os.path.join")
    import os
    assert func == os.path.join

def test_valid_model_import():
    func = get_import("tests.config.models.DNN")
    import os
    assert func == DNN

def test_invalid_module():
    with pytest.raises(ModuleNotFoundError):
        get_import("nonexistent.module.Class")

def test_invalid_attribute():
    with pytest.raises(AttributeError):
        get_import("os.path.nonexistent_func")