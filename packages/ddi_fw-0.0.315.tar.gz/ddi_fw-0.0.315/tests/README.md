# Tests

## Quick start

```bash
pytest -q
```

## Unit tests only (default)

Unit tests run by default without external datasets or GPU.

```bash
pytest -q tests/test_utils_core.py tests/test_vectorization.py tests/test_dataset_splitter.py
```

## Integration tests

Integration tests are opt-in and may require large datasets, TensorFlow, or Kaggle credentials.

You can set `RUN_INTEGRATION_TESTS=1` in a local `.env` file (see `.env.example`).

```bash
RUN_INTEGRATION_TESTS=1 pytest -q -m integration
```

## OpenFDA pipeline test

This test requires Kaggle credentials and the OpenFDA dataset.

```bash
RUN_INTEGRATION_TESTS=1 KAGGLE_USERNAME=... KAGGLE_KEY=... pytest -q -k openfda
```

## GPU checks

CUDA checks are opt-in and skip if CUDA is not required.

```bash
REQUIRE_CUDA=1 pytest -q tests/cuda_test.py
```

## Notes

- Use `pytest.importorskip` for optional heavy dependencies.
- Keep unit tests deterministic and fast.
- Use `@pytest.mark.integration` for dataset or long-running tests.
