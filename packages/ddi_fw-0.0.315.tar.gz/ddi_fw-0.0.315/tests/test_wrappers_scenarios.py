import os

import numpy as np
import pytest

sklearn = pytest.importorskip("sklearn")

from ddi_fw.ml.wrappers.logistic_regression_wrapper import LogisticRegressionModelWrapper
from ddi_fw.ml.wrappers.mnb_wrapper import MultinomialNBModelWrapper
from ddi_fw.ml.wrappers.random_forest_wrapper import RandomForestModelWrapper


def _make_classification_data():
    X_train = np.array(
        [
            [0.1, 0.2],
            [0.2, 0.1],
            [0.9, 0.8],
            [0.8, 0.9],
        ]
    )
    y_train = np.array([[1, 0], [1, 0], [0, 1], [0, 1]])

    X_test = np.array([[0.15, 0.2], [0.85, 0.95]])
    y_test = np.array([[1, 0], [0, 1]])

    X_ku = np.array([[0.12, 0.18], [0.82, 0.88]])
    y_ku = np.array([[1, 0], [0, 1]])

    X_uu = np.array([[0.11, 0.19], [0.9, 0.7]])
    y_uu = np.array([[1, 0], [0, 1]])

    return X_train, y_train, X_test, y_test, {"kk": (X_test, y_test), "ku": (X_ku, y_ku), "uu": (X_uu, y_uu)}


def _run_scenario_eval(wrapper_cls, **kwargs):
    X_train, y_train, X_test, y_test, test_sets = _make_classification_data()
    wrapper = wrapper_cls("20240101", wrapper_cls.__name__, None, **kwargs)
    wrapper.set_data([], [], X_train, y_train, X_test, y_test)
    wrapper.set_test_sets(test_sets)

    results = wrapper.fit_and_evaluate_scenarios(["kk", "ku", "uu"])
    assert set(results.keys()) == {"kk", "ku", "uu"}

    for scenario, payload in results.items():
        logs, metrics, pred = payload
        assert logs is not None
        assert metrics is not None
        assert pred is not None


def test_logistic_regression_scenarios():
    _run_scenario_eval(LogisticRegressionModelWrapper)


def test_multinomial_nb_scenarios():
    _run_scenario_eval(MultinomialNBModelWrapper)


def test_random_forest_scenarios_and_fit_tuple():
    X_train, y_train, X_test, y_test, test_sets = _make_classification_data()
    wrapper = RandomForestModelWrapper("20240101", "rf", None)
    wrapper.set_data([], [], X_train, y_train, X_test, y_test)
    wrapper.set_test_sets(test_sets)

    fit_result = wrapper.fit()
    assert isinstance(fit_result, tuple)
    assert len(fit_result) == 3

    results = wrapper.fit_and_evaluate_scenarios(["kk", "ku", "uu"])
    assert set(results.keys()) == {"kk", "ku", "uu"}


def test_xgboost_scenarios():
    if os.getenv("RUN_XGBOOST_TESTS") != "1":
        pytest.skip("Set RUN_XGBOOST_TESTS=1 to enable XGBoost wrapper test.")
    pytest.importorskip("xgboost")
    from ddi_fw.ml.wrappers.xgboost_wrapper import XGBoostModelWrapper

    _run_scenario_eval(XGBoostModelWrapper)


def test_catboost_scenarios():
    if os.getenv("RUN_CATBOOST_TESTS") != "1":
        pytest.skip("Set RUN_CATBOOST_TESTS=1 to enable CatBoost wrapper test.")
    pytest.importorskip("catboost")
    from ddi_fw.ml.wrappers.catboost_wrapper import CatBoostModelWrapper

    _run_scenario_eval(CatBoostModelWrapper)
