import numpy as np

import pytest

from ddi_fw.vectorization import SimilarityMatrixGenerator


def test_compute_jaccard_similarity():
    generator = SimilarityMatrixGenerator()
    matrix = np.array([[1, 0, 1], [1, 1, 0], [0, 0, 1]])

    sim = generator.create_jaccard_similarity_matrices(matrix)

    assert sim.shape == (3, 3)
    assert np.isclose(sim[0, 0], 1.0)
    assert np.isclose(sim[0, 1], 1 / 3)
    assert np.isclose(sim[0, 2], 1 / 2)


def test_compute_jaccard_similarity_rejects_non_binary():
    generator = SimilarityMatrixGenerator()
    matrix = np.array([[1, 2], [0, 1]])

    with pytest.raises(ValueError):
        generator.create_jaccard_similarity_matrices(matrix)