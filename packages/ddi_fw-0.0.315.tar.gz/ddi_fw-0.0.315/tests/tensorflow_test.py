import os

import numpy as np
import pytest

tf = pytest.importorskip("tensorflow")
pytest.importorskip("sklearn")

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Sequential

from ddi_fw.ml import TFModelWrapper
from ddi_fw.ml.evaluation_helper import Metrics

os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")


@pytest.mark.integration
def test_fit_and_evaluate():
    if os.getenv("RUN_TF_TESTS") != "1":
        pytest.skip("Set RUN_TF_TESTS=1 to enable TensorFlow tests.")

    iris = load_iris()
    X = iris.data
    y = iris.target.reshape(-1, 1)

    encoder = OneHotEncoder(sparse_output=False)
    y = encoder.fit_transform(y)

    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.4, random_state=42
    )
    _, X_test, _, y_test = train_test_split(
        X_temp, y_temp, test_size=0.5, random_state=42
    )

    def create_model(input_shape, num_classes=None, **_kwargs):
        output_classes = num_classes or 3
        model = Sequential(
            [
                Dense(128, activation="relu", input_shape=(input_shape[1],)),
                Dense(64, activation="relu"),
                Dense(output_classes, activation="softmax"),
            ]
        )
        model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
        return model

    tf_model_wrapper = TFModelWrapper(
        date="2021-09-01",
        model_func=create_model,
        descriptor="iris_test"
    )
    tf_model_wrapper.set_data(None, None, X_train, y_train, X_test, y_test)

    logs, metrics, pred = tf_model_wrapper.fit_and_evaluate(print_detail=False)

    assert isinstance(logs, dict)
    assert isinstance(metrics, Metrics)
    assert isinstance(pred, np.ndarray)