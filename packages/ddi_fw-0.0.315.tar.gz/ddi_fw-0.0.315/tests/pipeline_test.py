import json
import os
from pathlib import Path
import importlib

import pytest

from ddi_fw.pipeline import MultiPipeline


def _load_dotenv_if_available() -> None:
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv()

# --- Helpers ---

def run_and_report_pipeline(config: dict):
    """Executes the pipeline and prints formatted metrics."""
    mp = MultiPipeline(experiments_config=config).build()
    mp.run()
    
    print(f'\nname\t accuracy\tf-score\tprecision\trecall')
    results = mp.results()
    for key in results.keys():
        for m in results[key].metric_dict:
            metrics = results[key].metric_dict[m]
            print(f'{m}: {metrics.accuracy:.4f}\t'
                  f'{metrics.f1_score["macro"]:.4f}\t'
                  f'{metrics.precision["macro"]:.4f}\t'
                  f'{metrics.recall["macro"]:.4f}')

# --- Fixtures ---

@pytest.fixture(scope="module")
def base_config():
    _load_dotenv_if_available()
    config_path = Path('./tests/config/pipeline_test.json')
    if not config_path.exists():
        pytest.skip("Pipeline config missing.")
    with open(config_path, 'r') as f:
        return json.load(f)

@pytest.fixture(scope="session")
def kaggle_dataset_path():
    """
    Downloads the Kaggle dataset if not present and returns the local path.
    'kagglehub' automatically checks if the dataset is already downloaded.
    """
    kagglehub = pytest.importorskip("kagglehub")
    _load_dotenv_if_available()
    # Ensure credentials are in environment for kagglehub/kaggle
    os.environ['KAGGLE_USERNAME'] = os.getenv('KAGGLE_USERNAME', '')
    os.environ['KAGGLE_KEY'] = os.getenv('KAGGLE_KEY', '')
    if not os.environ['KAGGLE_USERNAME'] or not os.environ['KAGGLE_KEY']:
        pytest.skip("Kaggle credentials not set.")
    
    dataset_handle = "kivancbayraktar/c8c6ab09-dbbd-4a57-8241-c81209bcbfcd"
    path = kagglehub.dataset_download(dataset_handle)
    print(f"\n[INFO] Dataset path: {path}")
    return path

# --- Tests ---

@pytest.mark.integration
def test_pipeline_creation(base_config):
    if os.getenv("RUN_INTEGRATION_TESTS") != "1":
        pytest.skip("Set RUN_INTEGRATION_TESTS=1 to enable pipeline tests.")
    run_and_report_pipeline(base_config)

@pytest.mark.integration
def test_pipeline_creation_mnist():
    if os.getenv("RUN_INTEGRATION_TESTS") != "1":
        pytest.skip("Set RUN_INTEGRATION_TESTS=1 to enable pipeline tests.")
    x_config_path = Path('./tests/config/pipeline_test.json')
    if not x_config_path.exists():
        pytest.skip("Pipeline config missing.")
    with open(x_config_path, 'r') as f:
        config = json.load(f)
    run_and_report_pipeline(config)

@pytest.mark.integration
def test_pipeline_creation_openfda(kaggle_dataset_path):
    """
    Refactored openfda test:
    1. Checks GPU availability.
    2. Uses the downloaded Kaggle dataset path.
    3. Initializes FaissVectorStoreManager.
    """
    if os.getenv("RUN_INTEGRATION_TESTS") != "1":
        pytest.skip("Set RUN_INTEGRATION_TESTS=1 to enable pipeline tests.")

    tf = pytest.importorskip("tensorflow")
    FaissVectorStoreManager = pytest.importorskip("ddi_fw.langchain").FaissVectorStoreManager
    print(f"\nNum GPUs Available: {len(tf.config.list_physical_devices('GPU'))}")

    # 1. Initialize FAISS using the path from the fixture
    persist_dir = Path(kaggle_dataset_path) / "faiss" / "openfda-deneme-all-mpnet-base-v2" / "no_op"
    if not persist_dir.exists():
        pytest.skip("FAISS persistence directory not found in dataset.")
    
    faiss_manager = FaissVectorStoreManager(persist_directory=str(persist_dir))
    
    # 2. Trigger embedding dict initialization
    _ = faiss_manager.initialize_embedding_dict()
    
    # 3. Validation: Ensure index is loaded and has data
    index_count = faiss_manager.vector_store.index.ntotal
    print(f"[INFO] FAISS Index Total: {index_count}")
    assert index_count > 0, "FAISS index is empty or failed to load."

    # 4. Run the actual pipeline
    x_config_path = Path('./tests/config/pipeline_test_openfda_2.json')
    if not x_config_path.exists():
        pytest.skip("OpenFDA pipeline config missing.")
    with open(x_config_path, 'r') as f:
        config = json.load(f)

    dataset_type = config.get("experiments", [{}])[0].get("dataset", {}).get("dataset_type")
    if dataset_type:
        module_name, _, attr_name = dataset_type.rpartition(".")
        try:
            module = importlib.import_module(module_name)
            getattr(module, attr_name)
        except Exception:
            pytest.skip(f"Dataset type '{dataset_type}' is not importable.")

    run_and_report_pipeline(config)