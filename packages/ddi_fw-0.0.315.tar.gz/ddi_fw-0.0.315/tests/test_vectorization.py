import numpy as np
import pandas as pd
import pytest

pytest.importorskip("sklearn")

from ddi_fw.vectorization.idf_helper import IDF
from ddi_fw.vectorization.feature_vector_generation import (
    SimilarityMatrixGenerator,
    VectorGenerator,
)


def test_idf_calculate_values():
    df = pd.DataFrame(
        {
            "tokens": [
                ["a", "b"],
                ["a"],
                ["b", "c"],
            ]
        }
    )
    idf = IDF(dataframe=df, columns=["tokens"])
    idf.calculate()

    scores = idf.idf_scores["tokens"]
    assert np.isclose(scores["a"], np.log(3 / 2))
    assert np.isclose(scores["b"], np.log(3 / 2))
    assert np.isclose(scores["c"], np.log(3 / 1))


def test_similarity_jaccard_binary_matrix():
    matrix = np.array([[1, 0, 1], [1, 1, 0], [0, 0, 0]])
    generator = SimilarityMatrixGenerator()
    sim = generator.create_jaccard_similarity_matrices(matrix)

    assert sim.shape == (3, 3)
    assert np.isclose(sim[0, 0], 1.0)
    assert np.isclose(sim[0, 1], 1 / 3)
    assert np.isclose(sim[0, 2], 0.0)
    assert np.isclose(sim[2, 2], 1.0)


def test_similarity_jaccard_rejects_non_binary():
    matrix = np.array([[1, 2], [0, 1]])
    generator = SimilarityMatrixGenerator()
    with pytest.raises(ValueError):
        generator.create_jaccard_similarity_matrices(matrix)


def test_similarity_cosine_zero_vectors():
    matrix = np.array([[0, 0, 0], [0, 0, 0], [1, 0, 0]], dtype=float)
    generator = SimilarityMatrixGenerator()
    sim = generator.create_cosine_similarity_matrices(matrix)

    assert np.isclose(sim[0, 1], 1.0)
    assert np.isclose(sim[0, 2], 0.0)


def test_vector_generator_with_external_map():
    df = pd.DataFrame({"col": [["x", "y"], ["y"], ["z"]]})
    generator = VectorGenerator(df)
    feature_map = {"x": 0, "y": 1}

    vectors, used_map = generator.generate_feature_vector("col", external_map=feature_map)
    assert used_map == feature_map
    assert vectors.shape == (3, 2)
    assert np.array_equal(vectors[0], np.array([1, 1]))
    assert np.array_equal(vectors[2], np.array([0, 0]))


def test_vector_generator_with_fixed_size():
    df = pd.DataFrame({"col": [["x", "y"], ["y"], ["z"]]})
    generator = VectorGenerator(df)

    vectors, used_map = generator.generate_feature_vector("col", fixed_size=4)
    assert vectors.shape == (3, 4)
    assert len(used_map) <= 4
