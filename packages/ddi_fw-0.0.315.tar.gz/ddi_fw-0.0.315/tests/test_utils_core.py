import json
from pathlib import Path

import numpy as np

from ddi_fw.utils.json_helper import minify
from ddi_fw.utils.numpy_utils import adjust_array_dims
from ddi_fw.utils.utils import compress_and_save_data, decompress


def test_adjust_array_dims_expand_and_shrink():
    arr_1d = np.array([1, 2, 3])
    arr_3d = adjust_array_dims(arr_1d, final_ndim=3)
    assert arr_3d.ndim == 3
    assert arr_3d.shape == (3, 1, 1)

    arr_2d = adjust_array_dims(arr_3d, final_ndim=2)
    assert arr_2d.ndim == 2
    assert arr_2d.shape == (3, 1)


def test_compress_and_decompress_roundtrip(tmp_path: Path):
    payload = {"a": 1, "b": [1, 2, 3], "c": {"x": "y"}}
    compress_and_save_data(payload, str(tmp_path), "data.gzip")

    restored = decompress(str(tmp_path / "data.gzip"))
    assert restored == payload


def test_json_minify(tmp_path: Path):
    data = {"name": "ddi", "values": [1, 2, 3]}
    file_path = tmp_path / "sample.json"
    file_path.write_text(json.dumps(data, indent=2))

    minify(str(tmp_path), "sample.json")
    minified = tmp_path / "sample_minify.json"

    assert minified.exists()
    assert minified.read_text() == json.dumps(data, separators=(",", ":"))
