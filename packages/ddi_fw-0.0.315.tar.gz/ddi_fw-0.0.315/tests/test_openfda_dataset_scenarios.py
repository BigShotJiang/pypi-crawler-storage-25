import os

import pytest

from tests.datasets.openfda import OpenFDADataset
from tests.datasets.openfda.entity_disjoint_splitter import EntityDisjointSplitter


@pytest.mark.integration
def test_openfda_dataset_loads_and_caches_scenarios():
    if os.getenv("RUN_OPENFDA_TESTS") != "1":
        pytest.skip("Set RUN_OPENFDA_TESTS=1 to enable OpenFDA dataset test.")

    dataset = OpenFDADataset(
        dataset_splitter_type=EntityDisjointSplitter,
        columns=[
            "description",
            "clinical_pharmacology",
            "markdown_content",
            "enzymes_polypeptides",
            "targets_polypeptides",
            "smile",
        ],
        additional_config={
            "min_event_category_count": 5,
            "symmetric": True,
            "scenario": "kk",
            "test_scenarios": ["kk", "ku", "uu"],
            "filter_columns": ["enzymes_polypeptides", "targets_polypeptides", "smile"],
            "concat_strategy_param": "tests.datasets.openfda.concat_strategies.PairConcatStrategy",
        },
    )

    dataset.load()

    assert dataset.X_train is not None
    assert dataset.X_test is not None
    assert dataset.cached_test_sets

    for scenario in dataset.test_scenarios:
        if scenario in dataset.cached_test_sets:
            X_sc, y_sc = dataset.cached_test_sets[scenario]
            assert X_sc is not None
            assert y_sc is not None
