import itertools

import pytest

from ddi_fw.pipeline.multi_modal_combination_strategy import CustomCombinationStrategy


def test_pure_combinations():
    items = ["e1", "e2", "e3", "e4", "e5"]
    all_combinations = []
    for i in range(2, len(items) + 1):
        all_combinations.extend(list(itertools.combinations(items, i)))

    assert len(all_combinations) == (2 ** len(items) - len(items) - 1)
    assert ("e1", "e2") in all_combinations


def test_combination_strategy():
    group_1 = ["a", "b", "c"]
    group_2 = [1, 2, 3]
    strategy = CustomCombinationStrategy(group_1=group_1, group_2=group_2)
    combinations = strategy.generate()

    assert any("a" in combo for combo in combinations)
    assert any(1 in combo for combo in combinations)


def test_combination_strategy_rejects_empty_groups():
    with pytest.raises(ValueError):
        CustomCombinationStrategy(group_1=[], group_2=[1]).generate()
