import numpy as np
import pandas as pd
import pytest

sklearn = pytest.importorskip("sklearn")

from ddi_fw.datasets.dataset_splitter import DatasetSplitter


def _make_one_hot_labels(n_per_class: int = 10) -> pd.Series:
    labels = [np.array([1, 0])] * n_per_class + [np.array([0, 1])] * n_per_class
    return pd.Series(labels)


def test_dataset_splitter_shapes_and_folds():
    X = pd.DataFrame({"a": range(20), "b": range(20, 40)})
    y = _make_one_hot_labels(10)

    splitter = DatasetSplitter(fold_size=4, test_size=0.25, shuffle=True, random_state=123)
    X_train, X_test, y_train, y_test, train_index, test_index, train_folds, val_folds = splitter.split(X, y)

    assert len(X_train) + len(X_test) == len(X)
    assert len(y_train) + len(y_test) == len(y)
    assert len(train_index) == len(X_train)
    assert len(test_index) == len(X_test)
    assert len(train_folds) == splitter.fold_size
    assert len(val_folds) == splitter.fold_size

    for train_idx, val_idx in zip(train_folds, val_folds):
        assert set(train_idx).isdisjoint(set(val_idx))
        assert len(train_idx) + len(val_idx) == len(X_train)
