import json
import os
from pathlib import Path

import pytest

from ddi_fw.pipeline import MultiPipeline


@pytest.mark.integration
def test_pipeline_creation_mnist():
    if os.getenv("RUN_INTEGRATION_TESTS") != "1":
        pytest.skip("Set RUN_INTEGRATION_TESTS=1 to enable pipeline tests.")

    config_path = Path("./tests/config/pipeline_test_mnist.json")
    if not config_path.exists():
        pytest.skip("MNIST pipeline config missing.")

    with open(config_path, "r") as f:
        config = json.load(f)

    mp = MultiPipeline(experiments_config=config).build()
    mp.run()
    assert mp.results()