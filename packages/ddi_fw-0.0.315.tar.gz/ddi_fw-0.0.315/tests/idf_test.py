import numpy as np
import pandas as pd

from ddi_fw.vectorization import IDF


def test_calculate_idf_values():
    item1 = "T001|T002|T001|T001"
    item2 = "T002|T003"
    item3 = "T004|T005"

    all_data = [item1, item2, item3]
    df = pd.DataFrame(all_data, columns=["tui_description"])
    df["tui_description"] = df["tui_description"].apply(
        lambda x: x.split("|") if x is not None else []
    )

    idf = IDF(dataframe=df, columns=["tui_description"])
    idf.calculate()

    scores = idf.idf_scores["tui_description"]
    assert set(scores.keys()) == {"T001", "T002", "T003", "T004", "T005"}
    assert np.isclose(scores["T001"], np.log(3 / 3))
    assert np.isclose(scores["T002"], np.log(3 / 2))
    assert np.isclose(scores["T004"], np.log(3 / 1))
