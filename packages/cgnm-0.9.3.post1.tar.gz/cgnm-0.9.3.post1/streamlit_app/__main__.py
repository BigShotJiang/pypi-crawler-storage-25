from __future__ import annotations

import pathlib
import subprocess
import sys


def main() -> int:
    app_path = pathlib.Path(__file__).with_name("app.py")
    cmd = [sys.executable, "-m", "streamlit", "run", str(app_path)]
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())

