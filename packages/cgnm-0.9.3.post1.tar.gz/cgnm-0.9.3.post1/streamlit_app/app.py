"""
Streamlit CGNM App
==================
Python equivalent of shinyCGNM.

Six-step workflow:
  Step 1 – Specify ODE system
  Step 2 – Dosing information
  Step 3 – Parameter ranges & bounds
  Step 4 – Observed data
  Step 5 – Generate Python code, test model, run CGNM
  Step 6 – Simulation

Run:
    streamlit run streamlit_app/app.py

(From python_cgnm/ with the venv active.)
"""

from __future__ import annotations

import io
import json
import sys
import os
import textwrap
import traceback
import warnings
from copy import deepcopy
from typing import Any, Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

# ── path so we can import cgnm / rxode_compat / ode_solver from parent dir ──
_HERE = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_HERE)
if _PARENT not in sys.path:
    sys.path.insert(0, _PARENT)

from rxode_compat import parse_rxode, ParsedModel, EventTable, rxode_solve
import cgnm


# ─────────────────────────────────────────────────────────────────────────────
# Page config
# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="CGNM – Cluster Gauss-Newton Method",
    page_icon="🧬",
    layout="wide",
)

# ─────────────────────────────────────────────────────────────────────────────
# Session-state initialisation
# ─────────────────────────────────────────────────────────────────────────────

def _init_state() -> None:
    defaults: Dict[str, Any] = {
        # Step 1
        "ode_text": "",
        "parsed_model": None,        # ParsedModel | None
        "state_names": [],
        "param_names_ode": [],
        "compile_message": "",

        # Step 2 – dosing
        "dose_df": pd.DataFrame(columns=["ID", "dose", "dosing_to",
                                          "start_time", "rate",
                                          "nbr_doses", "dosing_interval"]),

        # Step 3 – parameter info
        "param_df": pd.DataFrame(columns=["ParameterName",
                                           "Initial_lower_range",
                                           "Initial_upper_range",
                                           "Lower_bound",
                                           "Upper_bound",
                                           "VaryByID",
                                           "MO_weight",
                                           "MO_value",
                                           "Unit"]),

        # Step 4 – observations
        "obs_df": pd.DataFrame(columns=["ID", "time",
                                          "Observation_expression",
                                          "Observed_value",
                                          "ResidualError_model",
                                          "Memo"]),

        # Step 5 – results
        "cgnm_result": None,
        "run_log": "",

        # Step 6 – simulation dosing / obs skeleton
        "sim_dose_df": pd.DataFrame(columns=["ID", "dose", "dosing_to",
                                               "start_time", "rate",
                                               "nbr_doses", "dosing_interval"]),
        "sim_obs_df": pd.DataFrame(columns=["ID", "time",
                                              "Observation_expression",
                                              "Memo"]),
        "sim_result_df": None,

        # navigation
        "step": "Step 1: Specify ODE",
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

STEPS = [
    "Step 1: Specify ODE",
    "Step 2: Dosing information",
    "Step 3: Parameter info",
    "Step 4: Observed data",
    "Step 5: Generate code & run",
    "Step 6: Simulation",
]

EXAMPLE_ODE = textwrap.dedent("""\
    ## Pitavastatin-Rifampicin PBPK (simplified 1-cpt oral)
    ## Replace with your own ODE system.
    d/dt(A_gut)   = -Ka*A_gut
    d/dt(C_plasma) = Ka*A_gut/Vd - (CL/Vd)*C_plasma
""")

EXAMPLE_DOSE = pd.DataFrame({
    "ID":               [1],
    "dose":             [4.0],
    "dosing_to":        [1],
    "start_time":       [0.0],
    "rate":             [0.0],
    "nbr_doses":        [1],
    "dosing_interval":  [None],
})

EXAMPLE_OBS = pd.DataFrame({
    "ID":                    [1]*7,
    "time":                  [0.5, 1, 2, 4, 6, 8, 12],
    "Observation_expression":["C_plasma"]*7,
    "Observed_value":        [np.log10(x) for x in [4.91, 8.65, 12.4, 18.7, 14.3, 8.4, 2.66]],
    "ResidualError_model":   [0]*7,
    "Memo":                  [""]*7,
})

EXAMPLE_PARAMS = pd.DataFrame({
    "ParameterName":      ["Ka", "Vd", "CL"],
    "Initial_lower_range":[0.1,  1.0,  0.1],
    "Initial_upper_range":[5.0,  50.0, 10.0],
    "Lower_bound":        [0.0,  0.0,  0.0],
    "Upper_bound":        [None, None, None],
    "VaryByID":           [0,    0,    0],
    "MO_weight":          [0.0,  0.0,  0.0],
    "MO_value":           [None, None, None],
    "Unit":               ["1/h", "L", "L/h"],
})


def _try_parse_ode(text: str):
    """Try parse_rxode; return (model, message)."""
    try:
        model = parse_rxode(text)
        msg = (f"✅ ODE compiled successfully.  "
               f"States: {model.state_names}  |  "
               f"Parameters: {model.param_names}")
        return model, msg
    except Exception as exc:
        return None, f"❌ {exc}"


def _sync_param_table() -> None:
    """Keep param_df rows in sync with ODE/dose detected parameter names."""
    ode_params = st.session_state.get("param_names_ode", [])
    if not ode_params:
        return
    current = st.session_state["param_df"]
    existing = list(current["ParameterName"]) if len(current) else []
    new_names = [p for p in ode_params if p not in existing]
    if new_names:
        new_rows = pd.DataFrame({
            "ParameterName":      new_names,
            "Initial_lower_range":[None]*len(new_names),
            "Initial_upper_range":[None]*len(new_names),
            "Lower_bound":        [0.0]*len(new_names),
            "Upper_bound":        [None]*len(new_names),
            "VaryByID":           [0]*len(new_names),
            "MO_weight":          [0.0]*len(new_names),
            "MO_value":           [None]*len(new_names),
            "Unit":               [""]*len(new_names),
        })
        st.session_state["param_df"] = pd.concat(
            [current, new_rows], ignore_index=True)


def _build_model_function(parsed: ParsedModel,
                           param_df: pd.DataFrame,
                           dose_df: pd.DataFrame,
                           obs_df: pd.DataFrame):
    """
    Build a Python nonlinear_function(x) -> np.ndarray usable by CGNM.
    Returns (fn, param_names_ordered, error_msg).
    """
    param_rows = param_df[param_df["Initial_lower_range"].notna()].reset_index(drop=True)
    param_names = list(param_rows["ParameterName"])

    # unique IDs from obs data
    unique_ids = sorted(obs_df["ID"].unique()) if len(obs_df) else [1]

    # VaryByID expansion
    vary_flags = dict(zip(param_rows["ParameterName"],
                          param_rows["VaryByID"].fillna(0).astype(int)))
    expanded_params: List[str] = []
    for pn in param_names:
        if vary_flags.get(pn, 0):
            for uid in unique_ids:
                expanded_params.append(f"{pn}_ID{uid}")
        else:
            expanded_params.append(pn)

    # Build event table per ID  {id: EventTable}
    def _make_ev(dose_sub, obs_sub):
        ev = EventTable()
        for _, row in dose_sub.iterrows():
            amt   = float(row["dose"])  if pd.notna(row.get("dose"))  else 0.0
            cmt   = int(row["dosing_to"]) if pd.notna(row.get("dosing_to")) else 1
            rate  = float(row["rate"])  if pd.notna(row.get("rate")) and float(row.get("rate", 0)) > 0 else 0.0
            n     = int(row["nbr_doses"]) if pd.notna(row.get("nbr_doses")) else 1
            ii    = float(row["dosing_interval"]) if pd.notna(row.get("dosing_interval")) else None
            t0    = float(row["start_time"]) if pd.notna(row.get("start_time")) else 0.0
            ev.add_dosing(dose=amt, nbr_doses=n, dosing_interval=ii,
                          start_time=t0, dosing_to=cmt, rate=rate)
        for _, row in obs_sub.iterrows():
            ev.add_sampling([float(row["time"])])
        return ev

    # Build target vector (observation vector – ordered by appearance in obs_df)
    target = np.array(obs_df["Observed_value"].astype(float))
    obs_expressions = list(obs_df["Observation_expression"])
    obs_ids          = list(obs_df["ID"])
    obs_times_list   = list(obs_df["time"].astype(float))

    # Determine state index for each observation expression
    state_names = parsed.state_names
    def _expr_to_idx(expr):
        expr = expr.strip()
        if expr in state_names:
            return state_names.index(expr)
        return 0  # fall back to first state

    obs_state_idx = [_expr_to_idx(e) for e in obs_expressions]

    # Capture for closure
    _parsed      = parsed
    _dose_df     = dose_df.copy()
    _obs_df      = obs_df.copy()
    _param_names = param_names
    _vary_flags  = vary_flags
    _unique_ids  = unique_ids

    def nonlinear_function(x):
        x = np.asarray(x, dtype=float)
        # Build param dict for each ID
        out_pieces = []
        idx = 0
        global_params = {}
        per_id_params = {uid: {} for uid in _unique_ids}

        for pn in _param_names:
            if _vary_flags.get(pn, 0):
                for uid in _unique_ids:
                    per_id_params[uid][pn] = x[idx]; idx += 1
            else:
                global_params[pn] = x[idx]; idx += 1

        for uid in _unique_ids:
            params_uid = {**global_params, **per_id_params[uid]}
            dose_sub = _dose_df[_dose_df["ID"] == uid].copy()
            obs_sub  = _obs_df[_obs_df["ID"] == uid].copy()
            if len(obs_sub) == 0:
                continue
            ev = _make_ev(dose_sub, obs_sub)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df = rxode_solve(_parsed, params_uid, ev)
            except Exception:
                out_pieces.extend([np.nan] * len(obs_sub))
                continue
            # Extract values in obs order
            for _, row in obs_sub.iterrows():
                t   = float(row["time"])
                expr = str(row["Observation_expression"]).strip()
                sidx = _expr_to_idx(expr)
                matched = df[df["time"].round(10) == round(t, 10)]
                if len(matched) == 0:
                    # Use the state column name directly if it exists
                    matched = df.iloc[(df["time"] - t).abs().argsort()[:1]]
                val = float(matched.iloc[0, sidx + 1]) if len(matched) > 0 else np.nan
                out_pieces.append(val)

        return np.array(out_pieces)

    return nonlinear_function, expanded_params, ""


def _generate_python_code(ode_text, param_df, dose_df, obs_df,
                           run_name="CGNM_result", num_minimizers=100,
                           num_iteration=15) -> str:
    """Generate a standalone Python script that reproduces the CGNM run."""
    param_rows = param_df[param_df["Initial_lower_range"].notna()].reset_index(drop=True)
    LR = list(param_rows["Initial_lower_range"].astype(float))
    UR = list(param_rows["Initial_upper_range"].astype(float))
    LB = [float(v) if pd.notna(v) else "None" for v in param_rows["Lower_bound"]]
    UB = [float(v) if pd.notna(v) else "None" for v in param_rows["Upper_bound"]]
    pnames = list(param_rows["ParameterName"])
    obs_vals = list(obs_df["Observed_value"].astype(float))
    obs_expr = list(obs_df["Observation_expression"])
    obs_time = list(obs_df["time"].astype(float))
    obs_id   = list(obs_df["ID"])
    dose_rows_str = dose_df.to_json(orient="records")

    ode_escaped = ode_text.replace('"""', "'''")

    code = f'''\
"""
Auto-generated CGNM Python script
==================================
Generated by Streamlit CGNM App.
"""
import numpy as np
import warnings
import sys, os
# Adjust path if needed
sys.path.insert(0, os.path.dirname(__file__) or ".")

from rxode_compat import parse_rxode, EventTable, rxode_solve
import cgnm

# ── ODE model ─────────────────────────────────────────────────────────────────
ode_text = """
{ode_text}
"""
parsed_model = parse_rxode(ode_text)

# ── Dosing table ──────────────────────────────────────────────────────────────
import pandas as pd, json
dose_df = pd.DataFrame(json.loads(\'\'\'{dose_rows_str}\'\'\'))

# ── Observed data ─────────────────────────────────────────────────────────────
obs_times   = {obs_time}
obs_ids     = {obs_id}
obs_expr    = {obs_expr}
observation = np.array({obs_vals})

# ── Model function ─────────────────────────────────────────────────────────────
def _expr_to_idx(expr, state_names):
    expr = expr.strip()
    return state_names.index(expr) if expr in state_names else 0

def model_function(x):
    x = np.asarray(x, dtype=float)
    param_names = {pnames}
    params = dict(zip(param_names, x))
    unique_ids = sorted(set(obs_ids))
    out = []
    for uid in unique_ids:
        ev = EventTable()
        for _, row in dose_df[dose_df["ID"] == uid].iterrows():
            amt  = float(row["dose"])       if pd.notna(row.get("dose")) else 0.0
            cmt  = int(row["dosing_to"])    if pd.notna(row.get("dosing_to")) else 1
            rate = float(row["rate"])       if pd.notna(row.get("rate")) and float(row.get("rate", 0)) > 0 else 0.0
            n    = int(row["nbr_doses"])    if pd.notna(row.get("nbr_doses")) else 1
            ii   = float(row["dosing_interval"]) if pd.notna(row.get("dosing_interval")) else None
            t0   = float(row["start_time"]) if pd.notna(row.get("start_time")) else 0.0
            ev.add_dosing(dose=amt, nbr_doses=n, dosing_interval=ii,
                          start_time=t0, dosing_to=cmt, rate=rate)
        obs_sub_times = [t for t, i in zip(obs_times, obs_ids) if i == uid]
        ev.add_sampling(obs_sub_times)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            df = rxode_solve(parsed_model, params, ev)
        for t, expr in zip(obs_sub_times,
                           [e for e, i in zip(obs_expr, obs_ids) if i == uid]):
            sidx = _expr_to_idx(expr, parsed_model.state_names)
            row  = df.iloc[(df["time"] - t).abs().argsort().iloc[0]]
            out.append(float(row.iloc[sidx + 1]))
    return np.array(out)

# ── CGNM ─────────────────────────────────────────────────────────────────────
result = cgnm.cluster_gauss_newton_method(
    nonlinear_function   = model_function,
    target_vector        = observation,
    initial_lower_range  = {LR},
    initial_upper_range  = {UR},
    lower_bound          = {LB},
    upper_bound          = {UB},
    num_minimizers_to_find = {num_minimizers},
    num_iteration        = {num_iteration},
    parameter_names      = {pnames},
    save_log             = True,
    run_name             = "{run_name}",
)

print(cgnm.accepted_approximate_minimizers(result))
print(cgnm.table_parameter_summary(result))
'''
    return code


def _serialize_state() -> str:
    """Serialize session state to JSON for save/load."""
    s = {}
    for k in ["ode_text", "state_names", "param_names_ode"]:
        s[k] = st.session_state.get(k, "")
    for k in ["dose_df", "param_df", "obs_df", "sim_dose_df", "sim_obs_df"]:
        df = st.session_state.get(k)
        s[k] = df.to_json(orient="records") if df is not None else "[]"
    return json.dumps(s, indent=2)


def _load_state(json_str: str) -> None:
    data = json.loads(json_str)
    st.session_state["ode_text"]        = data.get("ode_text", "")
    st.session_state["state_names"]     = data.get("state_names", [])
    st.session_state["param_names_ode"] = data.get("param_names_ode", [])
    for k in ["dose_df", "param_df", "obs_df", "sim_dose_df", "sim_obs_df"]:
        raw = data.get(k, "[]")
        st.session_state[k] = pd.read_json(io.StringIO(raw), orient="records")
    # Re-parse ODE
    if st.session_state["ode_text"]:
        model, msg = _try_parse_ode(st.session_state["ode_text"])
        st.session_state["parsed_model"]    = model
        st.session_state["compile_message"] = msg


# ─────────────────────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("🧬 CGNM")
    st.caption("Cluster Gauss-Newton Method")

    st.session_state["step"] = st.radio(
        "Navigation", STEPS,
        index=STEPS.index(st.session_state["step"]),
    )

    st.divider()
    # Live model summary
    st.markdown("**Model variables**")
    snames = st.session_state.get("state_names", [])
    pnames = st.session_state.get("param_names_ode", [])
    st.caption("States: " + (", ".join(snames) if snames else "–"))
    st.caption("Parameters: " + (", ".join(pnames) if pnames else "–"))

    st.divider()
    st.markdown("**Save / Load session**")
    if st.button("💾 Download session JSON"):
        st.download_button(
            "Click to download",
            data=_serialize_state(),
            file_name="cgnm_session.json",
            mime="application/json",
        )
    uploaded_session = st.file_uploader("Load session JSON", type=["json"],
                                         label_visibility="collapsed")
    if uploaded_session is not None:
        _load_state(uploaded_session.read().decode())
        st.success("Session loaded.")

    st.divider()
    if st.button("📂 Load example model"):
        st.session_state["ode_text"]  = EXAMPLE_ODE
        st.session_state["dose_df"]  = EXAMPLE_DOSE.copy()
        st.session_state["obs_df"]   = EXAMPLE_OBS.copy()
        st.session_state["param_df"] = EXAMPLE_PARAMS.copy()
        model, msg = _try_parse_ode(EXAMPLE_ODE)
        st.session_state["parsed_model"]    = model
        st.session_state["compile_message"] = msg
        if model:
            st.session_state["state_names"]     = model.state_names
            st.session_state["param_names_ode"] = model.param_names
        st.rerun()


# ─────────────────────────────────────────────────────────────────────────────
# Main panel
# ─────────────────────────────────────────────────────────────────────────────

step = st.session_state["step"]

# ═════════════════════════════════════════════════════════════════════════════
if step == "Step 1: Specify ODE":
# ═════════════════════════════════════════════════════════════════════════════
    st.header("Step 1 – Specify ODE system")
    st.markdown(
        "Enter your ODE system using **rxODE syntax** — one equation per line, "
        "using `d/dt(state) = expression`.  "
        "Algebraic intermediate variables (`Cp = C/V`) are also supported."
    )
    st.code(
        "d/dt(A_gut)    = -Ka*A_gut\n"
        "d/dt(C_plasma) =  Ka*A_gut/Vd - (CL/Vd)*C_plasma",
        language="r",
    )

    ode_text = st.text_area(
        "ODE system (rxODE syntax)",
        value=st.session_state["ode_text"],
        height=260,
        key="ode_text_widget",
    )
    st.session_state["ode_text"] = ode_text

    col_compile, col_clear = st.columns([1, 5])
    with col_compile:
        if st.button("▶ Parse ODE", type="primary"):
            model, msg = _try_parse_ode(ode_text)
            st.session_state["parsed_model"]    = model
            st.session_state["compile_message"] = msg
            if model:
                st.session_state["state_names"]     = model.state_names
                st.session_state["param_names_ode"] = model.param_names
                _sync_param_table()

    msg = st.session_state.get("compile_message", "")
    if msg:
        if msg.startswith("✅"):
            st.success(msg)
        else:
            st.error(msg)

    if st.session_state.get("parsed_model"):
        model = st.session_state["parsed_model"]
        from rxode_compat import show_rhs
        import io as _io
        buf = _io.StringIO()
        old_stdout = sys.stdout; sys.stdout = buf
        show_rhs(model)
        sys.stdout = old_stdout
        with st.expander("Generated Python RHS function (for debugging)"):
            st.code(buf.getvalue(), language="python")


# ═════════════════════════════════════════════════════════════════════════════
elif step == "Step 2: Dosing information":
# ═════════════════════════════════════════════════════════════════════════════
    st.header("Step 2 – Dosing information")
    st.markdown(
        "Fill in one row per dosing event. `dosing_to` is the **1-indexed** "
        "compartment number (state order from Step 1). "
        "`rate > 0` triggers infusion; `rate = 0` is bolus. "
        "`nbr_doses > 1` requires `dosing_interval`."
    )
    st.markdown(
        "| Column | Description |\n"
        "|---|---|\n"
        "| ID | Subject/group ID |\n"
        "| dose | Amount given |\n"
        "| dosing_to | State index receiving drug (1-indexed) |\n"
        "| start_time | First dose time |\n"
        "| rate | Infusion rate (0 = bolus) |\n"
        "| nbr_doses | Number of repeated doses |\n"
        "| dosing_interval | Time between doses |\n"
    )

    if len(st.session_state["dose_df"]) == 0:
        st.session_state["dose_df"] = pd.DataFrame([{
            "ID": 1, "dose": None, "dosing_to": 1,
            "start_time": 0.0, "rate": 0.0, "nbr_doses": 1,
            "dosing_interval": None,
        }])

    edited_dose = st.data_editor(
        st.session_state["dose_df"],
        num_rows="dynamic",
        use_container_width=True,
        key="dose_editor",
    )
    st.session_state["dose_df"] = edited_dose

    col_dl, col_ul = st.columns(2)
    with col_dl:
        csv = edited_dose.to_csv(index=False)
        st.download_button("⬇ Download as CSV", csv,
                            "cgnm_dose.csv", "text/csv")
    with col_ul:
        f = st.file_uploader("⬆ Upload dose CSV", type=["csv"])
        if f:
            st.session_state["dose_df"] = pd.read_csv(f)
            st.rerun()


# ═════════════════════════════════════════════════════════════════════════════
elif step == "Step 3: Parameter info":
# ═════════════════════════════════════════════════════════════════════════════
    st.header("Step 3 – Parameter information")
    st.markdown(
        "Row order matches the parameter vector `x` passed to the model. "
        "`Lower_bound` / `Upper_bound` are optional constraints (leave empty = unconstrained). "
        "`VaryByID = 1` creates one copy of the parameter per subject ID. "
        "`MO_weight > 0` activates middle-out for that parameter."
    )
    _sync_param_table()

    if len(st.session_state["param_df"]) == 0:
        st.info("Parse the ODE in Step 1 first — parameter names are auto-populated.")
    else:
        edited_param = st.data_editor(
            st.session_state["param_df"],
            num_rows="dynamic",
            use_container_width=True,
            key="param_editor",
            column_config={
                "ParameterName": st.column_config.TextColumn("ParameterName", disabled=True),
            },
        )
        st.session_state["param_df"] = edited_param

        col_dl, col_ul = st.columns(2)
        with col_dl:
            csv = edited_param.to_csv(index=False)
            st.download_button("⬇ Download as CSV", csv,
                                "cgnm_params.csv", "text/csv")
        with col_ul:
            f = st.file_uploader("⬆ Upload parameter CSV", type=["csv"])
            if f:
                st.session_state["param_df"] = pd.read_csv(f)
                st.rerun()


# ═════════════════════════════════════════════════════════════════════════════
elif step == "Step 4: Observed data":
# ═════════════════════════════════════════════════════════════════════════════
    st.header("Step 4 – Observed data")
    st.markdown(
        "`Observation_expression` should be the **exact state variable name** "
        "from your ODE (e.g. `C_plasma`). "
        "`Observed_value` is the measured value at that time point. "
        "`ResidualError_model`: 0 = additive, 1 = proportional."
    )

    if len(st.session_state["obs_df"]) == 0:
        st.session_state["obs_df"] = pd.DataFrame([{
            "ID": 1, "time": None,
            "Observation_expression": "",
            "Observed_value": None,
            "ResidualError_model": 0,
            "Memo": "",
        }])

    state_hint = ", ".join(st.session_state.get("state_names", []))
    if state_hint:
        st.caption(f"Available state variables: **{state_hint}**")

    edited_obs = st.data_editor(
        st.session_state["obs_df"],
        num_rows="dynamic",
        use_container_width=True,
        key="obs_editor",
    )
    st.session_state["obs_df"] = edited_obs

    col_dl, col_ul = st.columns(2)
    with col_dl:
        csv = edited_obs.to_csv(index=False)
        st.download_button("⬇ Download as CSV", csv,
                            "cgnm_obs.csv", "text/csv")
    with col_ul:
        f = st.file_uploader("⬆ Upload observation CSV", type=["csv"])
        if f:
            st.session_state["obs_df"] = pd.read_csv(f)
            st.rerun()


# ═════════════════════════════════════════════════════════════════════════════
elif step == "Step 5: Generate code & run":
# ═════════════════════════════════════════════════════════════════════════════
    st.header("Step 5 – Generate code & run CGNM")

    parsed   = st.session_state.get("parsed_model")
    param_df = st.session_state["param_df"]
    dose_df  = st.session_state["dose_df"]
    obs_df   = st.session_state["obs_df"]

    if parsed is None:
        st.warning("⚠ Parse the ODE in Step 1 first.")
        st.stop()
    if len(param_df) == 0 or param_df["Initial_lower_range"].isna().all():
        st.warning("⚠ Fill in parameter ranges in Step 3 first.")
        st.stop()
    if len(obs_df) == 0 or obs_df["Observed_value"].isna().all():
        st.warning("⚠ Enter observed data in Step 4 first.")
        st.stop()

    # ── CGNM settings ────────────────────────────────────────────────────────
    with st.expander("⚙ CGNM settings", expanded=True):
        col1, col2, col3 = st.columns(3)
        num_min  = col1.number_input("num_minimizers_to_find", 10, 2000, 100, 10)
        num_iter = col2.number_input("num_iteration", 5, 200, 15, 5)
        run_name = col3.text_input("run_name", "CGNM_result")
        save_log = st.checkbox("save_log (saves iteration pkl files)", value=True)

    # ── Test 1: generate Python code ────────────────────────────────────────
    st.subheader("Test 1 — Generated Python code")
    code_str = _generate_python_code(
        ode_text=st.session_state["ode_text"],
        param_df=param_df, dose_df=dose_df, obs_df=obs_df,
        run_name=run_name,
        num_minimizers=int(num_min), num_iteration=int(num_iter),
    )
    st.code(code_str, language="python")
    st.download_button("⬇ Download Python script", code_str,
                        f"{run_name}.py", "text/plain")

    # ── Test 2: evaluate model at midpoint ──────────────────────────────────
    st.subheader("Test 2 — Test model evaluation")
    if st.button("▶ Test model function"):
        fn, exp_params, err = _build_model_function(
            parsed, param_df, dose_df, obs_df)
        if err:
            st.error(err)
        else:
            param_rows = param_df[param_df["Initial_lower_range"].notna()].reset_index(drop=True)
            LR = param_rows["Initial_lower_range"].astype(float).values
            UR = param_rows["Initial_upper_range"].astype(float).values
            x_mid = (LR + UR) / 2
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    y = fn(x_mid)
                if np.all(np.isnan(y)):
                    st.error("❌ Model returned all NaN at midpoint. Check ODE, dosing, and observation expressions.")
                else:
                    st.success(f"✅ Model evaluated successfully at midpoint. Output: {np.round(y, 4)}")
            except Exception as e:
                st.error(f"❌ {traceback.format_exc()}")

    # ── Test 3 / Run CGNM ───────────────────────────────────────────────────
    st.subheader("Test 3 — Run CGNM")
    if st.button("🚀 Run CGNM", type="primary"):
        fn, exp_params, err = _build_model_function(
            parsed, param_df, dose_df, obs_df)
        if err:
            st.error(err)
        else:
            param_rows = param_df[param_df["Initial_lower_range"].notna()].reset_index(drop=True)
            LR = list(param_rows["Initial_lower_range"].astype(float))
            UR = list(param_rows["Initial_upper_range"].astype(float))
            LB = [float(v) if pd.notna(v) else None
                  for v in param_rows["Lower_bound"]]
            UB = [float(v) if pd.notna(v) else None
                  for v in param_rows["Upper_bound"]]
            target = obs_df["Observed_value"].astype(float).values

            log_placeholder = st.empty()
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    result = cgnm.cluster_gauss_newton_method(
                        nonlinear_function    = fn,
                        target_vector         = target,
                        initial_lower_range   = LR,
                        initial_upper_range   = UR,
                        lower_bound           = LB,
                        upper_bound           = UB,
                        num_minimizers_to_find= int(num_min),
                        num_iteration         = int(num_iter),
                        parameter_names       = exp_params,
                        save_log              = save_log,
                        run_name              = run_name,
                    )
                st.session_state["cgnm_result"] = result
                st.success("✅ CGNM completed.")
            except Exception:
                st.error(f"❌ CGNM error:\n{traceback.format_exc()}")

    # ── Display results if available ────────────────────────────────────────
    result = st.session_state.get("cgnm_result")
    if result is not None:
        st.divider()
        st.subheader("Results")

        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("**Accepted approximate minimisers**")
            try:
                accepted = cgnm.accepted_approximate_minimizers(result)
                st.dataframe(accepted, use_container_width=True)
            except Exception as e:
                st.warning(f"Could not compute accepted minimisers: {e}")

        with col_b:
            st.markdown("**Parameter summary**")
            try:
                summary = cgnm.table_parameter_summary(result)
                st.dataframe(summary, use_container_width=True)
            except Exception as e:
                st.warning(f"Could not build summary table: {e}")

        st.markdown("**Plots**")
        tab_rank, tab_hist, tab_fit = st.tabs(
            ["SSR Rank", "Parameter distribution", "Goodness of fit"])

        with tab_rank:
            try:
                fig = cgnm.plot_rank_ssr(result)
                st.pyplot(fig)
                plt.close(fig)
            except Exception as e:
                st.warning(str(e))

        with tab_hist:
            try:
                fig = cgnm.plot_para_distribution_by_histogram(result)
                st.pyplot(fig)
                plt.close(fig)
            except Exception as e:
                st.warning(str(e))

        with tab_fit:
            try:
                obs_times_arr = obs_df["time"].astype(float).values
                fig = cgnm.plot_goodness_of_fit(
                    result, plot_type=1, plot_rank=[1],
                    independent_variable_vector=obs_times_arr)
                st.pyplot(fig)
                plt.close(fig)
            except Exception as e:
                st.warning(str(e))


# ═════════════════════════════════════════════════════════════════════════════
elif step == "Step 6: Simulation":
# ═════════════════════════════════════════════════════════════════════════════
    st.header("Step 6 – Simulation")
    parsed = st.session_state.get("parsed_model")
    result = st.session_state.get("cgnm_result")

    if parsed is None:
        st.warning("⚠ Parse the ODE in Step 1 first.")
        st.stop()

    st.markdown("Define dosing and a dense time grid for simulation, then generate predictions with confidence intervals from the accepted minimisers.")

    # ── Simulation dosing ────────────────────────────────────────────────────
    st.subheader("Simulation dosing schedule")
    col_copy, _ = st.columns([1, 4])
    with col_copy:
        if st.button("Copy from Step 2"):
            st.session_state["sim_dose_df"] = st.session_state["dose_df"].copy()
            st.rerun()

    if len(st.session_state["sim_dose_df"]) == 0:
        st.session_state["sim_dose_df"] = pd.DataFrame([{
            "ID": 1, "dose": None, "dosing_to": 1,
            "start_time": 0.0, "rate": 0.0, "nbr_doses": 1,
            "dosing_interval": None,
        }])

    sim_dose_edited = st.data_editor(
        st.session_state["sim_dose_df"],
        num_rows="dynamic", use_container_width=True, key="sim_dose_editor")
    st.session_state["sim_dose_df"] = sim_dose_edited

    # ── Simulation time skeleton ─────────────────────────────────────────────
    st.subheader("Simulation time points")
    col_copy2, _ = st.columns([1, 4])
    with col_copy2:
        if st.button("Copy from Step 4"):
            sim_obs_copy = st.session_state["obs_df"][
                ["ID", "time", "Observation_expression", "Memo"]].copy()
            st.session_state["sim_obs_df"] = sim_obs_copy
            st.rerun()

    if len(st.session_state["sim_obs_df"]) == 0:
        st.session_state["sim_obs_df"] = pd.DataFrame([{
            "ID": 1, "time": None,
            "Observation_expression": "",
            "Memo": "",
        }])

    sim_obs_edited = st.data_editor(
        st.session_state["sim_obs_df"],
        num_rows="dynamic", use_container_width=True, key="sim_obs_editor")
    st.session_state["sim_obs_df"] = sim_obs_edited

    # ── Run simulation ───────────────────────────────────────────────────────
    st.subheader("Run simulation")
    param_df = st.session_state["param_df"]

    if st.button("▶ Run simulation", type="primary"):
        sim_dose = st.session_state["sim_dose_df"]
        sim_obs  = st.session_state["sim_obs_df"]

        if len(sim_obs) == 0:
            st.warning("Add simulation time points first.")
        else:
            param_rows = param_df[param_df["Initial_lower_range"].notna()].reset_index(drop=True)
            param_names_sim = list(param_rows["ParameterName"])

            # If CGNM was run, use accepted minimisers
            if result is not None:
                try:
                    accepted = cgnm.accepted_approximate_minimizers(result)
                    param_matrix = accepted[param_names_sim].values
                except Exception:
                    param_matrix = None
            else:
                param_matrix = None

            if param_matrix is None or len(param_matrix) == 0:
                # Fall back to midpoint
                LR = param_rows["Initial_lower_range"].astype(float).values
                UR = param_rows["Initial_upper_range"].astype(float).values
                param_matrix = [(LR + UR) / 2]

            all_dfs = []
            for param_row in param_matrix:
                params_dict = dict(zip(param_names_sim, param_row))
                uid = sim_dose["ID"].iloc[0] if len(sim_dose) > 0 else 1
                ev  = EventTable()
                for _, drow in sim_dose[sim_dose["ID"] == uid].iterrows():
                    amt  = float(drow["dose"])        if pd.notna(drow.get("dose")) else 0.0
                    cmt  = int(drow["dosing_to"])     if pd.notna(drow.get("dosing_to")) else 1
                    rate = float(drow["rate"])        if pd.notna(drow.get("rate")) and float(drow.get("rate", 0)) > 0 else 0.0
                    n    = int(drow["nbr_doses"])     if pd.notna(drow.get("nbr_doses")) else 1
                    ii   = float(drow["dosing_interval"]) if pd.notna(drow.get("dosing_interval")) else None
                    t0   = float(drow["start_time"])  if pd.notna(drow.get("start_time")) else 0.0
                    ev.add_dosing(dose=amt, nbr_doses=n, dosing_interval=ii,
                                  start_time=t0, dosing_to=cmt, rate=rate)
                obs_sub = sim_obs[sim_obs["ID"] == uid]
                times   = sorted(obs_sub["time"].astype(float).unique())
                ev.add_sampling(times)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    df = rxode_solve(parsed, params_dict, ev)
                all_dfs.append(df)

            if all_dfs:
                st.session_state["sim_result_df"] = all_dfs

    sim_results = st.session_state.get("sim_result_df")
    if sim_results:
        st.subheader("Simulation results")
        state_names = parsed.state_names
        obs_expr_sim = st.session_state["sim_obs_df"]["Observation_expression"].unique()

        plot_states = [s for s in state_names if s in obs_expr_sim] or state_names[:1]

        all_times = sim_results[0]["time"].values
        for sname in plot_states:
            if sname not in sim_results[0].columns:
                continue
            fig, ax = plt.subplots(figsize=(8, 4))
            stack = np.array([df[sname].values for df in sim_results])
            lo   = np.nanpercentile(stack, 5,  axis=0)
            mid  = np.nanpercentile(stack, 50, axis=0)
            hi   = np.nanpercentile(stack, 95, axis=0)
            ax.fill_between(all_times, lo, hi, alpha=0.25, label="5–95% CI")
            ax.plot(all_times, mid, lw=2, label="Median")

            # Overlay observations if available
            obs_df = st.session_state["obs_df"]
            obs_match = obs_df[obs_df["Observation_expression"] == sname]
            if len(obs_match) > 0:
                ax.scatter(obs_match["time"].astype(float),
                           obs_match["Observed_value"].astype(float),
                           color="red", zorder=5, label="Observed", s=40)

            ax.set_xlabel("Time")
            ax.set_ylabel(sname)
            ax.set_title(f"Simulation: {sname}")
            ax.legend()
            st.pyplot(fig)
            plt.close(fig)

        # Download simulation as CSV
        combined = sim_results[0][["time"]].copy()
        for sname in state_names:
            if sname in sim_results[0].columns:
                stack = np.array([df[sname].values for df in sim_results])
                combined[f"{sname}_p50"] = np.nanpercentile(stack, 50, axis=0)
                combined[f"{sname}_p5"]  = np.nanpercentile(stack,  5, axis=0)
                combined[f"{sname}_p95"] = np.nanpercentile(stack, 95, axis=0)
        st.download_button("⬇ Download simulation CSV",
                            combined.to_csv(index=False),
                            "cgnm_simulation.csv", "text/csv")
