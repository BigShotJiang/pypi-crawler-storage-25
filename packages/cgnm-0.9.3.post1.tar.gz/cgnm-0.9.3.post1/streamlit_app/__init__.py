"""Streamlit app package for CGNM."""

