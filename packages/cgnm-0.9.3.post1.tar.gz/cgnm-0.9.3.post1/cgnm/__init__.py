"""
CGNM – Cluster Gauss-Newton Method (Python port)
=================================================
Translated from the R package CGNM by Yasunori Aoki.

Reference:
  Aoki et al. (2020). Cluster Gauss-Newton method.
  Optimization and Engineering. doi:10.1007/s11081-020-09571-2

Public API
----------
Core:
  cluster_gauss_newton_method          – find multiple minimisers of a NLS problem
  cluster_gauss_newton_bootstrap_method – bootstrap uncertainty quantification

Post-processing:
  accepted_max_ssr                     – maximum accepted SSR threshold
  accepted_approximate_minimizers      – accepted minimiser DataFrame
  accepted_indices                     – integer indices of accepted minimisers
  accepted_indices_binary              – boolean mask of accepted minimisers
  top_indices                          – indices of best-N minimisers
  best_approximate_minimizers          – best-N minimisers DataFrame
  table_parameter_summary              – summary statistics table

Plotting:
  plot_rank_ssr
  plot_para_distribution_by_histogram
  plot_para_distribution_by_violin_plots
  plot_goodness_of_fit
  plot_profile_likelihood              (requires save_log=True)
  plot_ssr_surface                     (requires save_log=True)
  plot_ssr_parameter_value
  plot_simulation_with_ci
  plot_simulation_matrix_with_ci
  table_profile_likelihood_confidence_interval (requires save_log=True)
"""

from .core import (
    cluster_gauss_newton_method,
    cluster_gauss_newton_bootstrap_method,
)

from .postprocess import (
    accepted_max_ssr,
    accepted_approximate_minimizers,
    accepted_indices,
    accepted_indices_binary,
    top_indices,
    best_approximate_minimizers,
    table_parameter_summary,
    table_profile_likelihood_confidence_interval,
    load_cgnm_log,
)

from .plot import (
    plot_rank_ssr,
    plot_para_distribution_by_histogram,
    plot_para_distribution_by_violin_plots,
    plot_goodness_of_fit,
    plot_profile_likelihood,
    plot_ssr_surface,
    plot_ssr_parameter_value,
    plot_simulation_with_ci,
    plot_simulation_matrix_with_ci,
)

__version__ = "0.9.3.post1"
__author__ = "Yasunori Aoki (R original); Python port"

__all__ = [
    # Core
    "cluster_gauss_newton_method",
    "cluster_gauss_newton_bootstrap_method",
    # Post-processing
    "accepted_max_ssr",
    "accepted_approximate_minimizers",
    "accepted_indices",
    "accepted_indices_binary",
    "top_indices",
    "best_approximate_minimizers",
    "table_parameter_summary",
    "table_profile_likelihood_confidence_interval",
    "load_cgnm_log",
    # Plotting
    "plot_rank_ssr",
    "plot_para_distribution_by_histogram",
    "plot_para_distribution_by_violin_plots",
    "plot_goodness_of_fit",
    "plot_profile_likelihood",
    "plot_ssr_surface",
    "plot_ssr_parameter_value",
    "plot_simulation_with_ci",
    "plot_simulation_matrix_with_ci",
]
