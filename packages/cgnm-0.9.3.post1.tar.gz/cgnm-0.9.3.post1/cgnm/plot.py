"""
Plotting functions for CGNM results using matplotlib/seaborn.
Translated from R/PostProcess.R (ggplot2-based plots -> matplotlib equivalents).
"""

import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from .postprocess import (
    accepted_indices_binary, accepted_max_ssr,
    prep_ssr_surface_data, _get_param_names,
)
from ._utils import optimal_kmeans


# ---------------------------------------------------------------------------
# Rank-SSR plot
# ---------------------------------------------------------------------------

def plot_rank_ssr(cgnm_result, indices_to_include=None, ax=None):
    """
    Plot SSR vs rank of approximate minimisers.  Shows accepted vs rejected.

    Parameters
    ----------
    cgnm_result : dict
    indices_to_include : array-like[int] or None
        If None, uses the automatic acceptance criterion.
    ax : matplotlib Axes or None

    Returns
    -------
    matplotlib Figure
    """
    SSR_vec = cgnm_result["residual_history"][:, -1]
    n = len(SSR_vec)

    if indices_to_include is not None:
        accepted_b = np.zeros(n, dtype=bool)
        accepted_b[np.asarray(indices_to_include)] = True
    else:
        accepted_b = accepted_indices_binary(cgnm_result)

    ranks = np.argsort(np.argsort(SSR_vec)) + 1
    n_acc = np.sum(accepted_b)
    acc_max = np.max(SSR_vec[accepted_b]) if np.any(accepted_b) else np.nan
    min_ssr = np.min(SSR_vec)

    fig, ax = (plt.subplots() if ax is None else (ax.get_figure(), ax))
    colors = np.where(accepted_b, "steelblue", "salmon")
    ax.scatter(ranks, SSR_vec, c=colors, s=20, alpha=0.7)
    ax.axvline(n_acc, color="grey", linestyle="--")
    ax.set_ylim(0, acc_max * 2 if np.isfinite(acc_max) else None)
    ax.annotate(
        f"Accepted: {n_acc}\nMax accepted SSR: {acc_max:.4g}",
        xy=(n_acc, acc_max * 0.5 if np.isfinite(acc_max) else 0),
        xytext=(n_acc + n * 0.02, acc_max * 0.5 if np.isfinite(acc_max) else 0),
        fontsize=9, color="grey",
    )
    ax.annotate(
        f"Min SSR: {min_ssr:.4g}",
        xy=(n * 0.1, min_ssr * 1.1),
        fontsize=9, color="navy",
    )
    ax.set_xlabel("Rank")
    ax.set_ylabel("SSR")
    ax.set_title("Rank vs SSR")
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# Parameter distribution – histogram
# ---------------------------------------------------------------------------

def plot_para_distribution_by_histogram(cgnm_result, indices_to_include=None,
                                         parameter_names=None, bins=30):
    """
    Histograms of initial vs accepted-final parameter distributions.

    Returns
    -------
    matplotlib Figure
    """
    pnames = _get_param_names(cgnm_result, parameter_names)
    n_params = len(pnames)

    if indices_to_include is not None:
        mask = np.zeros(cgnm_result["X"].shape[0], dtype=bool)
        mask[np.asarray(indices_to_include)] = True
    else:
        mask = accepted_indices_binary(cgnm_result)

    init_X = _get_param_values(cgnm_result, "initial", pnames)
    final_X = _get_param_values(cgnm_result, "final", pnames, mask)

    ncols = min(n_params, 4)
    nrows = int(np.ceil(n_params / ncols))
    fig, axes = plt.subplots(2, n_params, figsize=(3 * n_params, 5),
                              constrained_layout=True)
    if n_params == 1:
        axes = axes.reshape(2, 1)

    for i, pname in enumerate(pnames):
        ax_init = axes[0, i]
        ax_fin = axes[1, i]
        ax_init.hist(init_X[:, i], bins=bins, color="grey", alpha=0.7)
        ax_init.set_title(f"{pname}\nInitial", fontsize=9)
        ax_fin.hist(final_X[:, i], bins=bins, color="steelblue", alpha=0.7)
        ax_fin.set_title("Final Accepted", fontsize=9)
        ax_init.set_ylabel("Count")
        ax_fin.set_ylabel("Count")

    fig.suptitle("Parameter distributions: Initial vs Final Accepted")
    return fig


# ---------------------------------------------------------------------------
# Parameter distribution – violin plots
# ---------------------------------------------------------------------------

def plot_para_distribution_by_violin_plots(cgnm_result, indices_to_include=None,
                                            parameter_names=None):
    """
    Violin plots showing initial vs accepted-final parameter distributions.

    Returns
    -------
    matplotlib Figure
    """
    try:
        from matplotlib.patches import FancyArrowPatch
    except ImportError:
        pass

    pnames = _get_param_names(cgnm_result, parameter_names)
    n_params = len(pnames)

    if indices_to_include is not None:
        mask = np.zeros(cgnm_result["X"].shape[0], dtype=bool)
        mask[np.asarray(indices_to_include)] = True
    else:
        mask = accepted_indices_binary(cgnm_result)

    init_X = _get_param_values(cgnm_result, "initial", pnames)
    final_X = _get_param_values(cgnm_result, "final", pnames, mask)

    fig, axes = plt.subplots(1, n_params, figsize=(3.5 * n_params, 5),
                              constrained_layout=True)
    if n_params == 1:
        axes = [axes]

    for i, pname in enumerate(pnames):
        ax = axes[i]
        data_init = init_X[:, i][np.isfinite(init_X[:, i])]
        data_fin = final_X[:, i][np.isfinite(final_X[:, i])]
        parts = ax.violinplot([data_init, data_fin], positions=[0, 1],
                              showmedians=True, showextrema=False)
        for pc in parts["bodies"]:
            pc.set_alpha(0.5)
            pc.set_facecolor("grey")
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Initial", "Final\nAccepted"], fontsize=8)
        ax.set_title(pname, fontsize=9)
        ax.set_ylabel("Value")

    fig.suptitle("Parameter distributions")
    return fig


# ---------------------------------------------------------------------------
# Goodness-of-fit plot
# ---------------------------------------------------------------------------

def plot_goodness_of_fit(cgnm_result, plot_type=1, plot_rank=None,
                          independent_variable_vector=None,
                          dependent_variable_type_vector=None,
                          abs_residual=False):
    """
    Goodness-of-fit diagnostics.

    plot_type : int
        1 – model fit vs data (observation vs independent variable)
        2 – residual vs model fit (fitted values)
        3 – residual histogram (or vs independent variable if provided)
        4 – residual vs target (observed values)

    Returns
    -------
    matplotlib Figure
    """
    if plot_rank is None:
        plot_rank = [1]

    target_vec = np.asarray(
        cgnm_result["run_setting"]["target_vector"], dtype=float
    )
    SSR_vec = cgnm_result["residual_history"][:, -1]
    rank_vals = np.argsort(np.argsort(SSR_vec)) + 1
    indices = [np.where(rank_vals == r)[0][0] for r in plot_rank
               if np.any(rank_vals == r)]

    m = len(target_vec)
    if independent_variable_vector is None or len(independent_variable_vector) != m:
        ind_var = np.arange(1, m + 1, dtype=float)
    else:
        ind_var = np.asarray(independent_variable_vector, dtype=float)

    fig, ax = plt.subplots(figsize=(7, 4))

    if plot_type == 1:
        for idx in indices:
            y_sim = cgnm_result["Y"][idx, :]
            valid = np.isfinite(y_sim) & np.isfinite(target_vec)
            ax.plot(ind_var[valid], y_sim[valid],
                    label=f"Rank {rank_vals[idx]}", alpha=0.7)
        ax.scatter(ind_var[np.isfinite(target_vec)],
                   target_vec[np.isfinite(target_vec)],
                   color="red", zorder=5, label="Observed", s=20)
        ax.set_xlabel("Independent variable")
        ax.set_ylabel("Dependent variable")
        ax.legend(fontsize=8)

    elif plot_type in (2, 4):
        for idx in indices:
            y_sim = cgnm_result["Y"][idx, :]
            resid = y_sim - target_vec
            if abs_residual:
                resid = np.abs(resid)
            valid = np.isfinite(resid)
            x_axis = y_sim[valid] if plot_type == 2 else target_vec[valid]
            ax.scatter(x_axis, resid[valid], s=15, alpha=0.6,
                       label=f"Rank {rank_vals[idx]}")
        ax.axhline(0, color="black", linewidth=0.8)
        ax.set_xlabel("Simulated" if plot_type == 2 else "Observed")
        ax.set_ylabel("|Residual|" if abs_residual else "Residual")

    elif plot_type == 3:
        all_resid = []
        for idx in indices:
            r = cgnm_result["Y"][idx, :] - target_vec
            r = r[np.isfinite(r)]
            if abs_residual:
                r = np.abs(r)
            all_resid.extend(r)
        if independent_variable_vector is None:
            ax.hist(all_resid, bins=30, color="steelblue", alpha=0.8)
            ax.set_xlabel("|Residual|" if abs_residual else "Residual")
        else:
            for idx in indices:
                r = cgnm_result["Y"][idx, :] - target_vec
                valid = np.isfinite(r)
                ax.scatter(ind_var[valid], r[valid] if not abs_residual
                           else np.abs(r[valid]), s=15, alpha=0.6)
            ax.axhline(0, color="black", linewidth=0.8)
            ax.set_xlabel("Independent variable")
            ax.set_ylabel("|Residual|" if abs_residual else "Residual")

    ax.set_title("Goodness of fit")
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# Profile likelihood / SSR surface
# ---------------------------------------------------------------------------

def plot_profile_likelihood(log_location, alpha=0.25, num_bins=None,
                             parameter_names=None, show_initial_range=True):
    """
    Profile likelihood plot using saved log files.
    Requires save_log=True when running cluster_gauss_newton_method().

    Returns
    -------
    matplotlib Figure
    """
    from scipy.stats import chi2
    data = prep_ssr_surface_data(log_location, parameter_names, num_bins)
    X_mat = data["X_matrix"]
    n2ll = data["neg2_log_likelihood"]
    pnames = data["parameter_names"]
    nbins = data["num_bins"]
    min_n2ll = np.nanmin(n2ll)
    threshold = chi2.ppf(1 - alpha, 1) + min_n2ll

    n_params = len(pnames)
    ncols = min(n_params, 4)
    nrows = int(np.ceil(n_params / ncols))
    fig, axes = plt.subplots(nrows, ncols,
                              figsize=(4 * ncols, 3.5 * nrows),
                              constrained_layout=True)
    axes_flat = np.array(axes).flatten() if n_params > 1 else [axes]

    for i, col in enumerate(pnames):
        ax = axes_flat[i]
        x_vals = X_mat[col].values
        # Bin into nbins quantile bins, take min n2ll per bin
        bin_edges = np.percentile(x_vals, np.linspace(0, 100, nbins + 1))
        xs, ys = [], []
        for b in range(nbins):
            mask = (x_vals >= bin_edges[b]) & (x_vals <= bin_edges[b + 1])
            if np.any(mask):
                xs.append(x_vals[mask][np.argmin(n2ll[mask])])
                ys.append(n2ll[mask].min())
        if xs:
            order = np.argsort(xs)
            xs_s, ys_s = np.array(xs)[order], np.array(ys)[order]
            ax.plot(xs_s, ys_s, "o-", markersize=4)
        ax.axhline(threshold, color="grey", linestyle="--",
                   label=f"{(1-alpha)*100:.0f}% CI threshold")
        ax.set_xlim(x_vals.min(), x_vals.max())
        ylim_lo = min_n2ll - 3.84
        ylim_hi = min_n2ll + 4 * 3.84
        ax.set_ylim(ylim_lo, ylim_hi)
        if show_initial_range:
            init_X = data["initial_X"]
            ax.axvline(init_X[:, i].min(), color="lightgrey", linestyle=":")
            ax.axvline(init_X[:, i].max(), color="lightgrey", linestyle=":")
        ax.set_title(col, fontsize=9)
        ax.set_xlabel("Parameter value")
        ax.set_ylabel("-2 log likelihood")

    # Hide unused axes
    for j in range(n_params, len(axes_flat)):
        axes_flat[j].set_visible(False)

    fig.suptitle(f"Profile likelihood  (horizontal line = {(1-alpha)*100:.0f}% CI)")
    return fig


def plot_ssr_surface(log_location, num_bins=None, parameter_names=None,
                      show_initial_range=False):
    """
    SSR surface plot (minimum SSR per parameter bin).
    Requires save_log=True.

    Returns
    -------
    matplotlib Figure
    """
    data = prep_ssr_surface_data(log_location, parameter_names, num_bins)
    X_mat = data["X_matrix"]
    R_vec = data["R_vec"]
    pnames = data["parameter_names"]
    nbins = data["num_bins"]

    n_params = len(pnames)
    ncols = min(n_params, 4)
    nrows = int(np.ceil(n_params / ncols))
    fig, axes = plt.subplots(nrows, ncols,
                              figsize=(4 * ncols, 3.5 * nrows),
                              constrained_layout=True)
    axes_flat = np.array(axes).flatten() if n_params > 1 else [axes]

    for i, col in enumerate(pnames):
        ax = axes_flat[i]
        x_vals = X_mat[col].values
        bin_edges = np.percentile(x_vals, np.linspace(0, 100, nbins + 1))
        xs, ys = [], []
        for b in range(nbins):
            mask = (x_vals >= bin_edges[b]) & (x_vals <= bin_edges[b + 1])
            if np.any(mask):
                xs.append(x_vals[mask][np.argmin(R_vec[mask])])
                ys.append(R_vec[mask].min())
        if xs:
            order = np.argsort(xs)
            ax.plot(np.array(xs)[order], np.array(ys)[order], "o-", markersize=4)
        if show_initial_range:
            init_X = data["initial_X"]
            ax.axvline(init_X[:, i].min(), color="lightgrey", linestyle=":")
            ax.axvline(init_X[:, i].max(), color="lightgrey", linestyle=":")
        ax.set_title(col, fontsize=9)
        ax.set_xlabel("Parameter value")
        ax.set_ylabel("Min SSR")

    for j in range(n_params, len(axes_flat)):
        axes_flat[j].set_visible(False)

    fig.suptitle("SSR surface")
    return fig


# ---------------------------------------------------------------------------
# SSR vs parameter value scatter
# ---------------------------------------------------------------------------

def plot_ssr_parameter_value(cgnm_result, indices_to_include=None,
                              parameter_names=None, show_initial_range=True):
    """
    SSR vs parameter value scatter for accepted minimisers.

    Returns
    -------
    matplotlib Figure
    """
    pnames = _get_param_names(cgnm_result, parameter_names)
    n_params = len(pnames)
    SSR_vec = cgnm_result["residual_history"][:, -1]

    if indices_to_include is not None:
        mask = np.zeros(len(SSR_vec), dtype=bool)
        mask[np.asarray(indices_to_include)] = True
    else:
        mask = accepted_indices_binary(cgnm_result)

    X_acc = _get_param_values(cgnm_result, "final", pnames, mask)
    SSR_acc = SSR_vec[mask]

    ncols = min(n_params, 4)
    nrows = int(np.ceil(n_params / ncols))
    fig, axes = plt.subplots(nrows, ncols,
                              figsize=(4 * ncols, 3.5 * nrows),
                              constrained_layout=True)
    axes_flat = np.array(axes).flatten() if n_params > 1 else [axes]

    for i, pname in enumerate(pnames):
        ax = axes_flat[i]
        ax.scatter(X_acc[:, i], SSR_acc, s=15, alpha=0.5, color="steelblue")
        if show_initial_range:
            rs = cgnm_result["run_setting"]
            lr = np.asarray(rs["initial_lower_range"], dtype=float)
            ur = np.asarray(rs["initial_upper_range"], dtype=float)
            ax.axvline(lr[i], color="lightgrey", linestyle=":")
            ax.axvline(ur[i], color="lightgrey", linestyle=":")
        ax.set_xlabel(pname)
        ax.set_ylabel("SSR")

    for j in range(n_params, len(axes_flat)):
        axes_flat[j].set_visible(False)

    fig.suptitle("SSR vs parameter value (accepted minimisers)")
    return fig


# ---------------------------------------------------------------------------
# Simulation confidence interval plot
# ---------------------------------------------------------------------------

def plot_simulation_with_ci(simulation_function, parameter_matrix,
                             independent_variable_vector=None,
                             confidence_levels=(0.25, 0.75),
                             observation_vector=None,
                             observation_ind_var=None):
    """
    Simulate with each row of parameter_matrix and plot confidence interval.

    Parameters
    ----------
    simulation_function : callable  f(param_vec) -> 1-D array
    parameter_matrix : array-like, shape (n_samples, n_params)
    independent_variable_vector : array-like or None
    confidence_levels : tuple (lower, upper)  in [0,1]
    observation_vector : array-like or None
    observation_ind_var : array-like or None

    Returns
    -------
    matplotlib Figure
    """
    parameter_matrix = np.asarray(parameter_matrix, dtype=float)
    n_samples = parameter_matrix.shape[0]
    sim = simulation_function(parameter_matrix[0])
    m = len(sim)
    sim_matrix = np.zeros((n_samples, m))
    sim_matrix[0, :] = sim
    for i in range(1, n_samples):
        try:
            sim_matrix[i, :] = simulation_function(parameter_matrix[i])
        except Exception:
            sim_matrix[i, :] = np.nan

    return plot_simulation_matrix_with_ci(
        sim_matrix,
        independent_variable_vector=independent_variable_vector,
        confidence_levels=confidence_levels,
        observation_vector=observation_vector,
        observation_ind_var=observation_ind_var,
    )


def plot_simulation_matrix_with_ci(simulation_matrix,
                                    independent_variable_vector=None,
                                    confidence_levels=(0.25, 0.75),
                                    observation_vector=None,
                                    observation_ind_var=None):
    """
    Plot confidence interval from a pre-computed simulation matrix.

    Parameters
    ----------
    simulation_matrix : ndarray (n_samples, m)
    independent_variable_vector : array-like length m or None
    confidence_levels : tuple (lower_prob, upper_prob)
    observation_vector : array-like or None
    observation_ind_var : array-like or None

    Returns
    -------
    matplotlib Figure
    """
    sim = np.asarray(simulation_matrix, dtype=float)
    m = sim.shape[1]

    if independent_variable_vector is None or len(independent_variable_vector) != m:
        ind_var = np.arange(1, m + 1, dtype=float)
        warnings.warn("independent_variable_vector not provided; using 1,2,...,m")
    else:
        ind_var = np.asarray(independent_variable_vector, dtype=float)

    lo, hi = confidence_levels
    q_lo = np.nanpercentile(sim, lo * 100, axis=0)
    q_med = np.nanpercentile(sim, 50, axis=0)
    q_hi = np.nanpercentile(sim, hi * 100, axis=0)

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(ind_var, q_med, color="steelblue", label="Median")
    ax.fill_between(ind_var, q_lo, q_hi, alpha=0.25, color="steelblue",
                    label=f"{lo*100:.0f}–{hi*100:.0f}% CI")

    if observation_vector is not None:
        obs = np.asarray(observation_vector, dtype=float)
        obs_x = (np.asarray(observation_ind_var, dtype=float)
                 if observation_ind_var is not None else ind_var)
        if len(obs) == len(obs_x):
            ax.scatter(obs_x, obs, color="red", zorder=5, s=25, label="Observed")
        else:
            warnings.warn("observation_vector and observation_ind_var lengths differ; "
                          "observations not plotted.")

    ax.set_xlabel("Independent variable")
    ax.set_ylabel("Dependent variable")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_param_values(cgnm_result, kind, pnames, mask=None):
    """Extract param values array (n_samples, n_params) from result dict."""
    if kind == "initial":
        X_raw = cgnm_result["initialX"]
    else:
        X_raw = cgnm_result["X"]
        if mask is not None:
            X_raw = X_raw[mask, :]

    # If final_parameter_combos available, use it (already back-transformed)
    if kind == "final" and "final_parameter_combos" in cgnm_result:
        df = cgnm_result["final_parameter_combos"]
        if mask is not None:
            df = df.iloc[mask]
        df.columns = pnames[:df.shape[1]]
        return df.values

    return X_raw
