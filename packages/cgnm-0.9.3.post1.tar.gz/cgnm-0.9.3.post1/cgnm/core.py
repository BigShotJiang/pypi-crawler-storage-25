"""
Core Cluster Gauss-Newton Method algorithm.
Translated from R/Cluster_Gauss_Newton_method.R.

Reference:
  Aoki et al. (2020). Cluster Gauss-Newton method.
  Optimization and Engineering. doi:10.1007/s11081-020-09571-2
"""

import os
import time
import pickle
import warnings
from datetime import datetime

import numpy as np
from numpy.linalg import pinv
from sklearn.cluster import KMeans

from ._utils import (
    col_normalize, col_max, col_min, col_sd,
    optimal_kmeans,
    cgnr_ATAx_ATb, cgnr_ATAx_ATb_with_weight,
    cgnr_ATAx_ATb_with_reg, cgnr_ATAx_ATb_with_reg_weight,
    _try_nonlinear_function, _evaluate_batch, cgnm_input_test,
)


# ---------------------------------------------------------------------------
# Parameter-transformation helpers
# ---------------------------------------------------------------------------

def _build_transform_indices(lower_bound, upper_bound):
    """
    Build boolean index arrays for three kinds of parameter transforms:
      LB_index: only lower-bound given  -> log(theta - lb)
      UB_index: only upper-bound given  -> log(ub - theta)
      BB_index: both bounds given       -> logit( (theta - lb)/(ub - lb) )
    """
    lb = np.asarray(lower_bound, dtype=object)
    ub = np.asarray(upper_bound, dtype=object)

    def _is_finite(arr):
        out = np.zeros(len(arr), dtype=bool)
        for i, v in enumerate(arr):
            try:
                out[i] = v is not None and not np.isnan(float(v))
            except (TypeError, ValueError):
                out[i] = False
        return out

    has_lb = _is_finite(lb)
    has_ub = _is_finite(ub)
    LB_index = has_lb & ~has_ub
    UB_index = ~has_lb & has_ub
    BB_index = has_lb & has_ub
    return LB_index, UB_index, BB_index


def _transform_to_unconstrained(theta, lower_bound, upper_bound,
                                 LB_index, UB_index, BB_index):
    """Map from original (theta) space to unconstrained (x) space."""
    lb = np.array([float(v) if v is not None else np.nan for v in lower_bound])
    ub = np.array([float(v) if v is not None else np.nan for v in upper_bound])
    x = np.asarray(theta, dtype=float).copy()
    x[LB_index] = np.log(theta[LB_index] - lb[LB_index])
    x[UB_index] = np.log(-theta[UB_index] + ub[UB_index])
    x[BB_index] = np.log(
        (theta[BB_index] - lb[BB_index])
        / (ub[BB_index] - theta[BB_index])
    )
    return x


def _transform_to_original(x, lower_bound, upper_bound,
                             LB_index, UB_index, BB_index):
    """Map from unconstrained (x) space back to original (theta) space.

    x can be 1-D (single parameter set) or 2-D (rows = parameter sets).
    """
    lb = np.array([float(v) if v is not None else np.nan for v in lower_bound])
    ub = np.array([float(v) if v is not None else np.nan for v in upper_bound])
    x = np.asarray(x, dtype=float)
    is_vector = (x.ndim == 1)
    if is_vector:
        theta = x.copy()
        if np.any(LB_index):
            theta[LB_index] = np.exp(x[LB_index]) + lb[LB_index]
        if np.any(UB_index):
            theta[UB_index] = ub[UB_index] - np.exp(x[UB_index])
        if np.any(BB_index):
            ex = np.exp(x[BB_index])
            theta[BB_index] = (ub[BB_index] - lb[BB_index]) * (ex / (ex + 1)) + lb[BB_index]
    else:
        theta = x.copy()
        if np.any(LB_index):
            theta[:, LB_index] = np.exp(x[:, LB_index]) + lb[LB_index]
        if np.any(UB_index):
            theta[:, UB_index] = ub[UB_index] - np.exp(x[:, UB_index])
        if np.any(BB_index):
            ex = np.exp(x[:, BB_index])
            theta[:, BB_index] = (
                (ub[BB_index] - lb[BB_index]) * (ex / (ex + 1)) + lb[BB_index]
            )
    return theta


# ---------------------------------------------------------------------------
# Main iteration functions
# ---------------------------------------------------------------------------

def _main_iteration_v3_fast(X_in_original, Y_in, lambda_vec, minX_original,
                              maxX_original, target_matrix, gamma,
                              stay_in_initial_range=False,
                              keep_initial_distribution=None,
                              weight_matrix=None):
    """
    One CGNM iteration (version 3, fast implementation).
    Returns delta_X of same shape as X_in_original.
    """
    n_minimizers, n_params_orig = X_in_original.shape
    n_obs = Y_in.shape[1]

    # Only columns where X varies
    valid_x_col = (col_max(X_in_original) != col_min(X_in_original))
    X_in = X_in_original[:, valid_x_col]
    minX = minX_original[valid_x_col]
    maxX = maxX_original[valid_x_col]
    n_params = X_in.shape[1]

    # NaN check for Y rows
    Y_is_valid = np.all(np.isfinite(Y_in), axis=1)  # shape (n_minimizers,)

    # K-means clustering
    km = optimal_kmeans(X_in)
    # Ensure each cluster has >= n_params points and non-zero within-cluster SS
    while True:
        labels = km.labels_
        counts = np.bincount(labels, minlength=km.n_clusters)
        # per-cluster inertia
        per_inertia = []
        X_norm = col_normalize(X_in)
        for c in range(km.n_clusters):
            mask = labels == c
            if mask.sum() > 0:
                per_inertia.append(np.sum((X_norm[mask] - km.cluster_centers_[c])**2))
            else:
                per_inertia.append(0.0)
        if np.min(counts) >= n_params and min(per_inertia) > 0:
            break
        new_k = len(np.unique(labels)) - 1
        if new_k < 1:
            new_k = 1
            km = KMeans(n_clusters=1, n_init=10, random_state=0)
            km.fit(col_normalize(X_in))
            break
        km = KMeans(n_clusters=new_k, n_init=10, random_state=0)
        km.fit(col_normalize(X_in))

    labels = km.labels_
    # Clusters whose size == 1 are not acceptable
    counts = np.bincount(labels, minlength=km.n_clusters)
    not_acceptable_clusters = set(np.where(counts == 1)[0])

    # Compute per-cluster standard deviation matrix: shape (n_params, n_minimizers)
    n_clusters = km.n_clusters
    sd_matrix = np.zeros((n_params, n_minimizers))
    for c in range(n_clusters):
        mask = labels == c
        for j in range(n_params):
            sd_matrix[j, mask] = np.std(X_in[mask, j], ddof=1)
    sd_matrix = np.maximum(sd_matrix, 1e-9)

    # Pairwise distances within cluster (upper triangle, then symmetrise)
    rec_rel_dist = np.zeros((n_minimizers, n_minimizers))
    tX = X_in.T  # shape (n_params, n_minimizers)
    for i in range(n_minimizers):
        same_cluster = (labels == labels[i])
        diff = tX[:, same_cluster] - tX[:, i:i+1]   # (n_params, k_same)
        scale = sd_matrix[:, same_cluster]            # (n_params, k_same)
        sq_dist = np.sum((diff / scale)**2, axis=0)  # (k_same,)
        idx_same = np.where(same_cluster)[0]
        for jj, j in enumerate(idx_same):
            if i != j:
                rec_rel_dist[i, j] = 0.0 if sq_dist[jj] == 0 else 1.0 / sq_dist[jj]

    delta_X = np.zeros((n_minimizers, n_params))

    for k in range(n_minimizers):
        if lambda_vec[k] >= 1e10 or labels[k] in not_acceptable_clusters:
            continue

        # Weighted linear approximation: A s.t. A @ (x_i - x_k) ≈ y_i - y_k
        delta_X_rows = X_in - X_in[k, :]   # shape (n_minimizers, n_params)
        delta_Y = Y_in - Y_in[k, :]         # shape (n_minimizers, n_obs)

        try:
            with np.errstate(divide="ignore", overflow="ignore", invalid="ignore"):
                w = rec_rel_dist[:, k] ** gamma
                inf_mask = np.isinf(w)
                if np.any(inf_mask):
                    finite_max = np.max(w[~inf_mask]) if np.any(~inf_mask) else 1e10
                    w[inf_mask] = max(1e10, finite_max)
                w = np.nan_to_num(w, nan=0.0, posinf=1e10)

                W = np.diag(w)
                AT = (W @ delta_X_rows).T       # (n_params, n_minimizers)
                ATA = AT @ AT.T
                ATA_inv = pinv(ATA)             # (n_params, n_params)
                # A shape: (n_obs, n_params)
                A = (ATA_inv @ (AT @ W @ delta_Y)).T  # (n_obs, n_params)

            if keep_initial_distribution is not None:
                keep = np.asarray(keep_initial_distribution, dtype=bool)
                if len(keep) == n_params:
                    A[:, keep] = 0.0

        except Exception:
            # Fall back to CGNR per observation
            A = np.zeros((n_obs, n_params))
            w = rec_rel_dist[:, k] ** gamma
            for obs_i in range(n_obs):
                A[obs_i, :] = cgnr_ATAx_ATb_with_weight(
                    delta_X_rows, delta_Y[:, obs_i], w
                )
            if keep_initial_distribution is not None:
                keep = np.asarray(keep_initial_distribution, dtype=bool)
                if len(keep) == n_params:
                    A[:, keep] = 0.0

        rhs = (target_matrix[k, :] - Y_in[k, :])
        if weight_matrix is not None and weight_matrix.shape == Y_in.shape:
            dk = cgnr_ATAx_ATb_with_reg_weight(A, rhs, lambda_vec[k], weight_matrix[k, :])
        else:
            dk = cgnr_ATAx_ATb_with_reg(A, rhs, lambda_vec[k])

        if stay_in_initial_range:
            scale_vec = np.ones(n_params)
            denom_min = minX - X_in[k, :]
            denom_max = maxX - X_in[k, :]
            with np.errstate(divide='ignore', invalid='ignore'):
                r_min = np.where(denom_min != 0, dk / denom_min, 0.0)
                r_max = np.where(denom_max != 0, dk / denom_max, 0.0)
            scale_vec[r_min > 1] = r_min[r_min > 1] * 2
            scale_vec[r_max > 1] = r_max[r_max > 1] * 2
            dk = dk / scale_vec

        delta_X[k, :] = dk

    delta_X_out = np.zeros((n_minimizers, n_params_orig))
    delta_X_out[:, valid_x_col] = delta_X
    return delta_X_out


def _main_iteration_v1(X_in, Y_in, lambda_vec, minX, maxX, target_matrix, gamma):
    """Version 1 CGNM iteration (global distance, no k-means)."""
    n_minimizers, n_params = X_in.shape
    n_obs = Y_in.shape[1]
    x_width = maxX - minX
    x_width = np.where(x_width == 0, 1e-9, x_width)

    Y_valid = np.all(np.isfinite(Y_in), axis=1)

    # Pairwise normalised distances
    rec_rel_dist = np.zeros((n_minimizers, n_minimizers))
    for i in range(n_minimizers):
        for j in range(i):
            if Y_valid[i] and Y_valid[j]:
                d = np.sum(((X_in[i, :] - X_in[j, :]) / x_width) ** 2)
                if d > 0:
                    rec_rel_dist[i, j] = 1.0 / d
                    rec_rel_dist[j, i] = rec_rel_dist[i, j]

    delta_X = np.zeros_like(X_in)
    for k in range(n_minimizers):
        if lambda_vec[k] >= 1e10:
            continue
        delta_X_rows = X_in - X_in[k, :]
        delta_Y = Y_in - Y_in[k, :]
        w = rec_rel_dist[:, k] ** gamma
        A = np.zeros((n_obs, n_params))
        for obs_i in range(n_obs):
            A[obs_i, :] = cgnr_ATAx_ATb_with_weight(delta_X_rows, delta_Y[:, obs_i], w)
        rhs = target_matrix[k, :] - Y_in[k, :]
        delta_X[k, :] = cgnr_ATAx_ATb_with_reg(A, rhs, lambda_vec[k])
    return delta_X


# ---------------------------------------------------------------------------
# Core loop
# ---------------------------------------------------------------------------

def _cgnm_core(nonlinear_function, target_vector,
               initial_lower_range, initial_upper_range,
               lower_bound, upper_bound,
               stay_in_initial_range=False,
               num_minimizers_to_find=250, num_iteration=25,
               save_log=False, run_name="", text_memo="",
               algorithm_parameter_initial_lambda=1.0,
               algorithm_parameter_gamma=2.0,
               algorithm_version=3.0,
               initial_iterate_matrix=None, target_matrix=None,
               keep_initial_distribution=None, weight_matrix=None,
               parameter_names=None,
               folder_suffix="",
               **kwargs):
    """
    Low-level CGNM iteration loop (operates in unconstrained space).
    Returns a result dict.
    """
    target_vector = np.asarray(target_vector, dtype=float)
    initial_lower_range = np.asarray(initial_lower_range, dtype=float)
    initial_upper_range = np.asarray(initial_upper_range, dtype=float)

    if np.any(np.isnan(target_vector)):
        raise ValueError("target_vector contains NaN values.")
    if np.all(initial_lower_range == initial_upper_range):
        raise ValueError("All initial_lower_range and initial_upper_range values are the same.")

    start_time = time.time()

    # Determine whether matrices were provided
    dim_target_matrix = (0, 0)
    dim_init_matrix = (0, 0)
    if initial_iterate_matrix is not None:
        initial_iterate_matrix = np.asarray(initial_iterate_matrix, dtype=float)
        dim_init_matrix = initial_iterate_matrix.shape
    if target_matrix is not None:
        target_matrix = np.asarray(target_matrix, dtype=float)
        dim_target_matrix = target_matrix.shape

    if dim_init_matrix[0] > 0 and dim_target_matrix[0] > 0:
        num_minimizers_to_find = min(dim_init_matrix[0], dim_target_matrix[0])
        initial_iterate_matrix = initial_iterate_matrix[:num_minimizers_to_find, :]
        target_matrix = target_matrix[:num_minimizers_to_find, :]
    elif dim_target_matrix[0] > 0:
        num_minimizers_to_find = dim_target_matrix[0]
    elif dim_init_matrix[0] > 0:
        num_minimizers_to_find = dim_init_matrix[0]

    n_obs = len(target_vector)
    n_params = len(initial_lower_range)

    # Weight matrix
    if weight_matrix is not None:
        weight_matrix = np.asarray(weight_matrix, dtype=float)
        if weight_matrix.shape != (num_minimizers_to_find, n_obs):
            warnings.warn("Wrong weight_matrix shape; using uniform weights.")
            weight_matrix = None

    weight_matrix_for_res = (weight_matrix if weight_matrix is not None
                              else np.ones((num_minimizers_to_find, n_obs)))

    # Valid observation mask
    valid_target = ~np.isnan(target_vector)
    target_vector_clean = target_vector.copy()
    target_vector_clean[~valid_target] = 0.0

    if dim_target_matrix[0] == 0:
        target_mat = np.tile(target_vector_clean, (num_minimizers_to_find, 1))
    else:
        target_mat = target_matrix.copy()
        target_mat[:, ~valid_target] = 0.0

    X_bounds = np.vstack([initial_lower_range, initial_upper_range])

    # Save folder
    save_folder = "CGNM_log"
    if run_name == "TIME":
        run_name = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    if run_name:
        save_folder = f"{run_name}_{save_folder}"
    if folder_suffix:
        save_folder = f"{save_folder}_{folder_suffix}"
    print(f"Log folder: {save_folder}")
    if save_log:
        os.makedirs(save_folder, exist_ok=True)

    # Run settings dict (nonlinear_function excluded – local closures are not picklable)
    run_setting = dict(
        target_vector=target_vector,
        initial_lower_range=initial_lower_range,
        initial_upper_range=initial_upper_range,
        stay_in_initial_range=stay_in_initial_range,
        algorithm_parameter_initial_lambda=algorithm_parameter_initial_lambda,
        algorithm_parameter_gamma=algorithm_parameter_gamma,
        num_minimizers_to_find=num_minimizers_to_find,
        num_iteration=num_iteration,
        save_log=save_log,
        run_name=run_name,
        text_memo=text_memo,
        algorithm_version=algorithm_version,
        parameter_names=parameter_names,
        lower_bound=lower_bound,
        upper_bound=upper_bound,
        keep_initial_distribution=keep_initial_distribution,
        weight_matrix=weight_matrix,
    )

    # Test whether function accepts matrix input
    print("Testing nonlinear_function …")
    can_take_matrix = cgnm_input_test(nonlinear_function, target_vector,
                                      initial_lower_range, initial_upper_range,
                                      **kwargs)

    # -----------------------------------------------------------------------
    # 1. Generate initial cluster
    # -----------------------------------------------------------------------
    X = np.zeros((num_minimizers_to_find, n_params))
    Y = np.ones((num_minimizers_to_find, n_obs))
    lambda_vec = np.full(num_minimizers_to_find, float(algorithm_parameter_initial_lambda))
    is_alive = np.zeros(num_minimizers_to_find, dtype=bool)

    user_init_available = (dim_init_matrix[0] > 0)

    while not np.all(is_alive):
        if user_init_available:
            X_temp = initial_iterate_matrix.copy()
            user_init_available = False
        else:
            X_temp = (
                np.random.uniform(0, 1, (num_minimizers_to_find, n_params))
                * (X_bounds[1] - X_bounds[0])
                + X_bounds[0]
            )

        not_alive_idx = ~is_alive
        X[not_alive_idx, :] = X_temp[not_alive_idx, :]

        X_to_compute = X[not_alive_idx, :]
        if X_to_compute.shape[0] == 1:
            X_to_compute = X_to_compute[0, :]  # 1-D for vector call if needed

        Y_computed = _evaluate_batch(
            np.atleast_2d(X_to_compute), n_obs,
            nonlinear_function, valid_target, can_take_matrix, **kwargs
        )
        Y[not_alive_idx, :] = Y_computed

        residual = np.sum(
            (weight_matrix_for_res * (Y - target_mat)) ** 2, axis=1
        )
        is_alive = np.isfinite(residual) & ~np.isnan(residual)
        n_alive = np.sum(is_alive)
        print(f"  Generating initial cluster: {n_alive}/{num_minimizers_to_find} done")

        if n_alive == 0:
            raise RuntimeError(
                "Could not generate any valid initial iterates. "
                "Check nonlinear_function, initial ranges, and target_vector."
            )

    residual = np.sum((weight_matrix_for_res * (Y - target_mat)) ** 2, axis=1)
    residual_history = residual.copy().reshape(-1, 1)   # (n_min, 1) then grow horizontally
    initial_X = X.copy()
    initial_Y = Y.copy()
    lambda_history = lambda_vec.copy().reshape(1, -1)    # (1, n_min)
    prev_residual = residual.copy()

    result = dict(X=X, Y=Y, residual_history=residual_history,
                  initialX=initial_X, initialY=initial_Y,
                  lambda_history=lambda_history, run_setting=run_setting)
    if save_log:
        with open(os.path.join(save_folder, "iteration_0.pkl"), "wb") as fh:
            pickle.dump(result, fh)

    # -----------------------------------------------------------------------
    # 2. Main iteration
    # -----------------------------------------------------------------------
    for k in range(1, num_iteration + 1):
        iter_start = time.time()

        gamma_use = algorithm_parameter_gamma

        if algorithm_version == 3 or algorithm_version >= 3.0:
            delta_X = _main_iteration_v3_fast(
                X, Y, lambda_vec,
                X_bounds[0], X_bounds[1],
                target_mat, gamma_use,
                stay_in_initial_range=stay_in_initial_range,
                keep_initial_distribution=keep_initial_distribution,
                weight_matrix=weight_matrix,
            )
        else:
            delta_X = _main_iteration_v1(
                X, Y, lambda_vec,
                X_bounds[0], X_bounds[1],
                target_mat, gamma_use,
            )

        X_new = X + delta_X

        # Only recompute rows where lambda is not saturated
        to_update = lambda_vec < algorithm_parameter_initial_lambda * 1e10
        Y_new = Y.copy()
        if np.any(to_update):
            X_to_compute = X_new[to_update, :]
            Y_computed = _evaluate_batch(
                X_to_compute, n_obs,
                nonlinear_function, valid_target, can_take_matrix, **kwargs
            )
            Y_new[to_update, :] = Y_computed
        else:
            break

        residual_new = np.sum((weight_matrix_for_res * (Y_new - target_mat)) ** 2, axis=1)

        # Accept / reject each iterate individually (Levenberg-Marquardt-like)
        residual = prev_residual.copy()
        for i in range(num_minimizers_to_find):
            if (np.isfinite(residual_new[i]) and np.isfinite(prev_residual[i])
                    and prev_residual[i] > residual_new[i]):
                X[i, :] = X[i, :] + delta_X[i, :]
                residual[i] = residual_new[i]
                Y[i, :] = Y_new[i, :]
                lambda_vec[i] = lambda_vec[i] / 10.0
            else:
                if lambda_vec[i] < algorithm_parameter_initial_lambda * 1e10:
                    lambda_vec[i] = lambda_vec[i] * 10.0

        residual_history = np.hstack([residual_history, residual.reshape(-1, 1)])
        lambda_history = np.vstack([lambda_history, lambda_vec.reshape(1, -1)])
        prev_residual = residual.copy()

        print(f"  Iteration {k:3d}  Median SSR = {np.median(prev_residual):.6g}")

        result = dict(X=X, Y=Y, residual_history=residual_history,
                      initialX=initial_X, initialY=initial_Y,
                      lambda_history=lambda_history, run_setting=run_setting)
        if save_log:
            with open(os.path.join(save_folder, f"iteration_{k}.pkl"), "wb") as fh:
                pickle.dump(result, fh)

        if k == 1:
            iter_elapsed = time.time() - iter_start
            est_remaining = iter_elapsed * (num_iteration - 1) / 60
            print(f"  Estimated remaining time: {est_remaining:.1f} min")

        if np.median(prev_residual) == 0:
            break

    total_time = (time.time() - start_time) / 60
    print(f"CGNM completed in {total_time:.1f} min")

    result = dict(X=X, Y=Y, residual_history=residual_history,
                  initialX=initial_X, initialY=initial_Y,
                  lambda_history=lambda_history, run_setting=run_setting)
    if save_log:
        with open(os.path.join(save_folder, "iteration_final.pkl"), "wb") as fh:
            pickle.dump(result, fh)

    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def cluster_gauss_newton_method(
    nonlinear_function,
    target_vector,
    initial_lower_range,
    initial_upper_range,
    lower_bound=None,
    upper_bound=None,
    parameter_names=None,
    stay_in_initial_range=False,
    num_minimizers_to_find=250,
    num_iteration=25,
    save_log=True,
    run_name="",
    text_memo="",
    algorithm_parameter_initial_lambda=1.0,
    algorithm_parameter_gamma=2.0,
    algorithm_version=3.0,
    initial_iterate_matrix=None,
    target_matrix=None,
    weight_matrix=None,
    keep_initial_distribution=None,
    mo_weights=None,
    mo_values=None,
    **kwargs,
):
    """
    Cluster Gauss-Newton Method: find multiple minimisers of the nonlinear
    least-squares problem  argmin_x ||f(x) - y*||.

    Parameters
    ----------
    nonlinear_function : callable
        f(x, **kwargs) -> 1-D array of length m.
        May also accept a 2-D array X (rows = parameter sets) and return a
        2-D array Y (rows = model outputs), enabling batch evaluation.
    target_vector : array-like of shape (m,)
        Observed data y*.
    initial_lower_range : array-like of shape (n,)
        Lower bound of the initial search range for each parameter.
    initial_upper_range : array-like of shape (n,)
        Upper bound of the initial search range for each parameter.
    lower_bound : array-like of shape (n,) or None
        Hard lower bounds. Triggers log-transform internally.
    upper_bound : array-like of shape (n,) or None
        Hard upper bounds.
    parameter_names : list of str or None
    stay_in_initial_range : bool
        If True, keep iterates within [initial_lower, initial_upper].
    num_minimizers_to_find : int  (default 250)
    num_iteration : int           (default 25)
    save_log : bool               (default True)
        Save intermediate results as pickle files in CGNM_log/.
    run_name : str
    text_memo : str
    algorithm_parameter_initial_lambda : float (default 1.0)
    algorithm_parameter_gamma : float           (default 2.0)
    algorithm_version : float                   (default 3.0)
    initial_iterate_matrix : ndarray or None
    target_matrix : ndarray or None
    weight_matrix : ndarray or None
    keep_initial_distribution : array-like of bool or None
    mo_weights, mo_values : array-like or None  (Middle-out, experimental)
    **kwargs : passed through to nonlinear_function.

    Returns
    -------
    dict with keys:
      X                       ndarray (num_minimizers, n)
      Y                       ndarray (num_minimizers, m)
      residual_history        ndarray (num_minimizers, num_iteration+1)
      initialX                ndarray (num_minimizers, n)
      initialY                ndarray (num_minimizers, m)
      lambda_history          ndarray (num_iteration+1, num_minimizers)
      final_parameter_combos  DataFrame (num_minimizers, n)  – original space
      run_setting             dict
    """
    import pandas as pd

    target_vector = np.asarray(target_vector, dtype=float)
    initial_lower_range = np.asarray(initial_lower_range, dtype=float)
    initial_upper_range = np.asarray(initial_upper_range, dtype=float)
    n_params = len(initial_lower_range)

    # Normalise bounds to None-padded arrays
    if lower_bound is None:
        lower_bound = [None] * n_params
    else:
        lower_bound = [float(v) if v is not None and not np.isnan(float(v))
                       else None for v in np.asarray(lower_bound, dtype=object)]
    if upper_bound is None:
        upper_bound = [None] * n_params
    else:
        upper_bound = [float(v) if v is not None and not np.isnan(float(v))
                       else None for v in np.asarray(upper_bound, dtype=object)]

    if parameter_names is None:
        parameter_names = [f"theta_{i+1}" for i in range(n_params)]

    LB_index, UB_index, BB_index = _build_transform_indices(lower_bound, upper_bound)
    lb_arr = np.array([float(v) if v is not None else np.nan for v in lower_bound])
    ub_arr = np.array([float(v) if v is not None else np.nan for v in upper_bound])

    # ---- Middle-out (MO) ---------------------------------------------------
    if mo_weights is None:
        mo_weights_arr = np.zeros(n_params)
        mo_values_arr = (initial_lower_range + initial_upper_range) / 2
    else:
        mo_weights_arr = np.asarray(mo_weights, dtype=float)
        mo_values_arr = np.asarray(mo_values, dtype=float) if mo_values is not None \
            else (initial_lower_range + initial_upper_range) / 2

    mo_index = mo_weights_arr != 0

    # Convert to unconstrained space
    X_LR = initial_lower_range.copy()
    X_UR = initial_upper_range.copy()
    if np.any(LB_index):
        X_LR[LB_index] = np.log(initial_lower_range[LB_index] - lb_arr[LB_index])
        X_UR[LB_index] = np.log(initial_upper_range[LB_index] - lb_arr[LB_index])
    if np.any(UB_index):
        X_LR[UB_index] = np.log(-initial_lower_range[UB_index] + ub_arr[UB_index])
        X_UR[UB_index] = np.log(-initial_upper_range[UB_index] + ub_arr[UB_index])
    if np.any(BB_index):
        X_LR[BB_index] = np.log(
            (initial_lower_range[BB_index] - lb_arr[BB_index])
            / (ub_arr[BB_index] - initial_lower_range[BB_index])
        )
        X_UR[BB_index] = np.log(
            (initial_upper_range[BB_index] - lb_arr[BB_index])
            / (ub_arr[BB_index] - initial_upper_range[BB_index])
        )

    # Transform initial_iterate_matrix if provided
    if initial_iterate_matrix is not None:
        init_it = np.asarray(initial_iterate_matrix, dtype=float).copy()
        if np.any(LB_index):
            init_it[:, LB_index] = np.log(init_it[:, LB_index] - lb_arr[LB_index])
        if np.any(UB_index):
            init_it[:, UB_index] = np.log(-init_it[:, UB_index] + ub_arr[UB_index])
        if np.any(BB_index):
            init_it[:, BB_index] = np.log(
                (init_it[:, BB_index] - lb_arr[BB_index])
                / (ub_arr[BB_index] - init_it[:, BB_index])
            )
    else:
        init_it = None

    # Wrap nonlinear_function to undo the transform before calling user's function
    def nonlinear_function_transformed(x_unc, **kw):
        x_unc = np.asarray(x_unc, dtype=float)
        theta = _transform_to_original(x_unc, lower_bound, upper_bound,
                                        LB_index, UB_index, BB_index)
        out = nonlinear_function(theta, **kw)
        out = np.asarray(out, dtype=float)
        # Append MO terms if any
        if np.any(mo_index):
            mo_vals_x = (np.asarray([float(v) if v is not None else np.nan
                                     for v in lower_bound + upper_bound][:n_params])
                         if False else mo_values_arr)
            # convert mo_values to unconstrained space
            mo_vals_unc = _transform_to_unconstrained(
                mo_values_arr, lower_bound, upper_bound, LB_index, UB_index, BB_index
            )
            if x_unc.ndim == 1:
                extra = x_unc[mo_index] * mo_weights_arr[mo_index]
                out = np.concatenate([out, extra])
            else:
                extra = x_unc[:, mo_index] * mo_weights_arr[mo_index]
                out = np.hstack([out, extra])
        return out

    target_vec_ext = target_vector.copy()
    if np.any(mo_index):
        mo_vals_unc = _transform_to_unconstrained(
            mo_values_arr, lower_bound, upper_bound, LB_index, UB_index, BB_index
        )
        target_vec_ext = np.concatenate(
            [target_vector, mo_vals_unc[mo_index] * mo_weights_arr[mo_index]]
        )

    # ---- Run core ----------------------------------------------------------
    out = _cgnm_core(
        nonlinear_function=nonlinear_function_transformed,
        target_vector=target_vec_ext,
        initial_lower_range=X_LR,
        initial_upper_range=X_UR,
        lower_bound=lower_bound,
        upper_bound=upper_bound,
        stay_in_initial_range=stay_in_initial_range,
        num_minimizers_to_find=num_minimizers_to_find,
        num_iteration=num_iteration,
        save_log=save_log,
        run_name=run_name,
        text_memo=text_memo,
        algorithm_parameter_initial_lambda=algorithm_parameter_initial_lambda,
        algorithm_parameter_gamma=algorithm_parameter_gamma,
        algorithm_version=algorithm_version,
        initial_iterate_matrix=init_it,
        target_matrix=target_matrix,
        weight_matrix=weight_matrix,
        keep_initial_distribution=keep_initial_distribution,
        parameter_names=parameter_names,
        **kwargs,
    )

    # Map X back to original parameter space
    Theta = _transform_to_original(
        out["X"], lower_bound, upper_bound, LB_index, UB_index, BB_index
    )
    out["final_parameter_combos"] = pd.DataFrame(Theta, columns=parameter_names)

    # Store additional metadata in run_setting
    out["run_setting"].update(dict(
        lower_bound=lower_bound,
        upper_bound=upper_bound,
        parameter_names=parameter_names,
        mo_weights=mo_weights,
        mo_values=mo_values,
    ))

    if save_log:
        folder = "CGNM_log"
        if run_name not in ("", "TIME"):
            folder = f"{run_name}_{folder}"
        with open(os.path.join(folder, "iteration_final.pkl"), "wb") as fh:
            pickle.dump(out, fh)

    return out


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

def cluster_gauss_newton_bootstrap_method(
    cgnm_result,
    nonlinear_function,
    num_bootstrap_sample=200,
    indices_to_use_as_initial_iterates=None,
    bootstrap_type=1,
    **kwargs,
):
    """
    Residual-resampling (type 1), case-sampling (type 2), or random-weight (type 3)
    bootstrap analysis using CGNM.

    Parameters
    ----------
    cgnm_result : dict  returned by cluster_gauss_newton_method()
    nonlinear_function : callable  (original, untransformed)
    num_bootstrap_sample : int
    indices_to_use_as_initial_iterates : array-like[int] or None
    bootstrap_type : 1, 2, or 3
    **kwargs : passed to nonlinear_function

    Returns
    -------
    Updated cgnm_result dict with additional keys:
      bootstrapX, bootstrapY, bootstrapTheta (DataFrame)
    """
    import pandas as pd
    from .postprocess import accepted_indices

    rs = cgnm_result["run_setting"]
    target_vector = np.asarray(rs["target_vector"], dtype=float)
    initial_lower_range = np.asarray(rs["initial_lower_range"], dtype=float)
    initial_upper_range = np.asarray(rs["initial_upper_range"], dtype=float)
    lower_bound = rs.get("lower_bound")
    upper_bound = rs.get("upper_bound")
    parameter_names = rs.get("parameter_names")
    n_params = len(initial_lower_range)

    if indices_to_use_as_initial_iterates is None:
        accept_idx = accepted_indices(cgnm_result)
    else:
        accept_idx = np.asarray(indices_to_use_as_initial_iterates)
        accept_idx = accept_idx[accept_idx < cgnm_result["X"].shape[0]]

    if len(accept_idx) < 10:
        warnings.warn("Very few accepted parameters; using top-100 iterates for bootstrap.")
        from .postprocess import accepted_indices as ai
        accept_idx = ai(cgnm_result, use_accepted_approximate_minimizers=False,
                        num_parameters_included=100)

    # Build bootstrap target matrix and initial matrix
    bootstrap_target_matrix = np.full((num_bootstrap_sample, len(target_vector)), np.nan)
    valid = ~np.isnan(target_vector)
    residuals_at_best = (target_vector[valid]
                         - cgnm_result["Y"][accept_idx[0], valid])

    bootstrap_init_matrix = cgnm_result["X"][
        np.random.choice(accept_idx, num_bootstrap_sample, replace=True), :
    ]

    if bootstrap_type == 1:  # residual resampling
        for i in range(num_bootstrap_sample):
            resampled = np.random.choice(residuals_at_best,
                                         len(residuals_at_best), replace=True)
            bootstrap_target_matrix[i, valid] = target_vector[valid] + resampled
        bstrap_weight_matrix = None
    elif bootstrap_type == 2:  # case sampling
        bootstrap_target_matrix = np.tile(target_vector, (num_bootstrap_sample, 1))
        bstrap_weight_matrix = np.zeros((num_bootstrap_sample, len(target_vector)))
        for i in range(num_bootstrap_sample):
            sample = np.random.choice(len(target_vector), len(target_vector), replace=True)
            counts = np.bincount(sample, minlength=len(target_vector))
            bstrap_weight_matrix[i, :] = counts.astype(float)
    elif bootstrap_type == 3:  # random weights
        bootstrap_target_matrix = np.tile(target_vector, (num_bootstrap_sample, 1))
        bstrap_weight_matrix = np.random.uniform(
            0, 1, (num_bootstrap_sample, len(target_vector))
        )
    else:
        raise ValueError(f"bootstrap_type must be 1, 2, or 3; got {bootstrap_type}")

    bstrap_result = cluster_gauss_newton_method(
        nonlinear_function=nonlinear_function,
        target_vector=target_vector,
        initial_lower_range=initial_lower_range,
        initial_upper_range=initial_upper_range,
        lower_bound=lower_bound,
        upper_bound=upper_bound,
        parameter_names=parameter_names,
        stay_in_initial_range=rs.get("stay_in_initial_range", False),
        num_minimizers_to_find=num_bootstrap_sample,
        num_iteration=rs.get("num_iteration", 25),
        save_log=rs.get("save_log", False),
        run_name=rs.get("run_name", ""),
        text_memo=rs.get("text_memo", ""),
        algorithm_parameter_initial_lambda=rs.get("algorithm_parameter_initial_lambda", 1.0),
        algorithm_parameter_gamma=rs.get("algorithm_parameter_gamma", 2.0),
        algorithm_version=rs.get("algorithm_version", 3.0),
        initial_iterate_matrix=bootstrap_init_matrix,
        target_matrix=bootstrap_target_matrix,
        weight_matrix=bstrap_weight_matrix if bootstrap_type > 1 else None,
        **kwargs,
    )

    cgnm_result = dict(cgnm_result)          # shallow copy
    cgnm_result["bootstrapX"] = bstrap_result["X"]
    cgnm_result["bootstrapY"] = bstrap_result["Y"]
    cgnm_result["bootstrapTheta"] = bstrap_result["final_parameter_combos"]
    cgnm_result["bootstrapParameterCombinations"] = bstrap_result["final_parameter_combos"]
    cgnm_result["run_setting"] = dict(cgnm_result["run_setting"])
    cgnm_result["run_setting"]["num_bootstrap_sample"] = num_bootstrap_sample
    cgnm_result["run_setting"]["indices_to_use_as_initial_iterates"] = (
        indices_to_use_as_initial_iterates
    )
    return cgnm_result
