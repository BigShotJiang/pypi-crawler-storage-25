"""
Post-processing functions for CGNM results.
Translated from R/PostProcess.R.
"""

import warnings
import numpy as np
import pandas as pd
from scipy.stats import chi2, t as t_dist


# ---------------------------------------------------------------------------
# SSR acceptance helpers
# ---------------------------------------------------------------------------

def accepted_max_ssr(cgnm_result, cutoff_pvalue=0.05,
                     num_parameters_included=None,
                     use_accepted_approximate_minimizers=True,
                     algorithm=2):
    """
    Determine the maximum accepted sum-of-squares residual (SSR).

    Uses Grubbs' outlier test (algorithm=2, default) or elbow method
    (algorithm=1) to select which approximate minimisers to accept.

    Parameters
    ----------
    cgnm_result : dict   returned by cluster_gauss_newton_method()
    cutoff_pvalue : float
    num_parameters_included : int or None
    use_accepted_approximate_minimizers : bool
    algorithm : 1 or 2

    Returns
    -------
    float  maximum accepted SSR
    """
    residual_hist = cgnm_result["residual_history"]
    SSR_vec = residual_hist[:, -1]          # final-iteration SSR per iterate
    min_SSR = np.nanmin(SSR_vec)

    if use_accepted_approximate_minimizers:

        if algorithm == 2:
            # Grubbs' Test for Outliers on the cumulative residual trace
            n = len(SSR_vec)
            ordered = np.argsort(SSR_vec)
            cum_res = []
            best_Y = cgnm_result["Y"][ordered[0], :]

            for i in range(1, n):
                cum_res.append(np.sum(best_Y - cgnm_result["Y"][ordered[i - 1], :]))

            ptest = [False] * (n - 1)
            for i in range(3, n - 1):
                num_in_sample = i
                t_stat = t_dist.ppf(
                    1 - cutoff_pvalue / (2 * num_in_sample),
                    df=num_in_sample - 2
                )
                grubbs_crit = (
                    (num_in_sample - 1) / np.sqrt(num_in_sample)
                    * np.sqrt(t_stat ** 2 / (num_in_sample - 2 + t_stat ** 2))
                )
                sub = cum_res[:i]
                z = abs(sub[-1] - np.mean(sub)) / (np.std(sub, ddof=1) + 1e-300)
                ptest[i - 1] = bool(z > grubbs_crit)

            first_outlier = next((i for i, v in enumerate(ptest) if v), None)
            if first_outlier is not None:
                accept_max_ssr = float(np.sort(SSR_vec)[first_outlier + 1])
            else:
                accept_max_ssr = float(np.nanmax(SSR_vec))

        else:
            # Algorithm 1: chi-squared threshold + elbow
            target_vector = np.asarray(
                cgnm_result["run_setting"]["target_vector"], dtype=float
            )
            best_idx = int(np.nanargmin(SSR_vec))
            residuals = cgnm_result["Y"][best_idx, :] - target_vector
            residuals = residuals[np.isfinite(residuals)]
            threshold = (chi2.ppf(1 - cutoff_pvalue, df=len(residuals))
                         * np.var(residuals, ddof=1) + min_SSR)
            accept_max_ssr = max(threshold, min_SSR + np.sqrt(np.finfo(float).eps))

            accepted_SSR = SSR_vec[SSR_vec < accept_max_ssr]
            if num_parameters_included is not None and len(accepted_SSR) > num_parameters_included:
                accepted_SSR = np.sort(accepted_SSR)[:num_parameters_included]
            else:
                accepted_SSR = np.sort(accepted_SSR)

            n_acc = len(accepted_SSR)
            if n_acc > 1:
                area = []
                for i in range(n_acc - 1):
                    a = ((accepted_SSR[0] + accepted_SSR[i]) * i
                         + (accepted_SSR[i + 1] + accepted_SSR[-1]) * (n_acc - 1 - i))
                    area.append(a)
                elbow = int(np.argmin(area))
                accept_max_ssr = float(accepted_SSR[elbow])

    elif num_parameters_included is None or num_parameters_included > len(SSR_vec):
        accept_max_ssr = float(np.nanmax(SSR_vec))
    else:
        accept_max_ssr = float(np.sort(SSR_vec)[int(num_parameters_included) - 1])

    accept_max_ssr = max(accept_max_ssr, min_SSR + np.sqrt(np.finfo(float).eps))
    return accept_max_ssr


def accepted_indices(cgnm_result, cutoff_pvalue=0.05,
                     num_parameters_included=None,
                     use_accepted_approximate_minimizers=True,
                     algorithm=2):
    """
    Return integer indices of accepted approximate minimisers.

    Returns
    -------
    ndarray of int
    """
    max_ssr = accepted_max_ssr(cgnm_result, cutoff_pvalue,
                               num_parameters_included,
                               use_accepted_approximate_minimizers,
                               algorithm)
    SSR_vec = cgnm_result["residual_history"][:, -1]
    return np.where(SSR_vec <= max_ssr)[0]


def accepted_indices_binary(cgnm_result, cutoff_pvalue=0.05,
                             num_parameters_included=None,
                             use_accepted_approximate_minimizers=True,
                             algorithm=2):
    """
    Return boolean mask of accepted approximate minimisers.

    Returns
    -------
    ndarray of bool, shape (num_minimizers,)
    """
    max_ssr = accepted_max_ssr(cgnm_result, cutoff_pvalue,
                               num_parameters_included,
                               use_accepted_approximate_minimizers,
                               algorithm)
    SSR_vec = cgnm_result["residual_history"][:, -1]
    return SSR_vec <= max_ssr


def top_indices(cgnm_result, num_top_indices):
    """
    Return indices of the num_top_indices best (lowest SSR) approximate minimisers.

    Returns
    -------
    ndarray of int
    """
    SSR_vec = cgnm_result["residual_history"][:, -1]
    sorted_SSR = np.sort(SSR_vec)
    cutoff = sorted_SSR[int(num_top_indices) - 1]
    return np.where(SSR_vec <= cutoff)[0]


# ---------------------------------------------------------------------------
# Minimiser extraction
# ---------------------------------------------------------------------------

def accepted_approximate_minimizers(cgnm_result, cutoff_pvalue=0.05,
                                     num_parameters_included=None,
                                     use_accepted_approximate_minimizers=True,
                                     algorithm=2,
                                     parameter_names=None):
    """
    Return accepted approximate minimisers as a DataFrame in original parameter space.

    Returns
    -------
    pandas.DataFrame  shape (n_accepted, n_params)
    """
    idx = accepted_indices(cgnm_result, cutoff_pvalue,
                           num_parameters_included,
                           use_accepted_approximate_minimizers,
                           algorithm)
    pnames = _get_param_names(cgnm_result, parameter_names)

    if "final_parameter_combos" in cgnm_result:
        out = cgnm_result["final_parameter_combos"].iloc[idx].reset_index(drop=True)
        out.columns = pnames
        return out

    X_acc = cgnm_result["X"][idx, :]
    return pd.DataFrame(X_acc, columns=pnames)


def best_approximate_minimizers(cgnm_result, num_parameter_set=1,
                                 parameter_names=None):
    """
    Return the num_parameter_set approximate minimisers with the lowest SSR.

    Returns
    -------
    pandas.DataFrame
    """
    SSR_vec = cgnm_result["residual_history"][:, -1]
    ordered = np.argsort(SSR_vec)[:int(num_parameter_set)]
    pnames = _get_param_names(cgnm_result, parameter_names)

    if "final_parameter_combos" in cgnm_result:
        out = cgnm_result["final_parameter_combos"].iloc[ordered].reset_index(drop=True)
        out.columns = pnames
        return out

    return pd.DataFrame(cgnm_result["X"][ordered, :], columns=pnames)


# ---------------------------------------------------------------------------
# Summary tables
# ---------------------------------------------------------------------------

def table_parameter_summary(cgnm_result, indices_to_include=None,
                              parameter_names=None):
    """
    Return a summary DataFrame of accepted minimisers (quantiles + optional RSE).

    Returns
    -------
    pandas.DataFrame
    """
    pnames = _get_param_names(cgnm_result, parameter_names)

    if indices_to_include is not None:
        mask = np.zeros(cgnm_result["X"].shape[0], dtype=bool)
        mask[np.asarray(indices_to_include)] = True
    else:
        mask = accepted_indices_binary(cgnm_result)

    use_bootstrap = ("bootstrapX" in cgnm_result and
                     cgnm_result["bootstrapX"] is not None)

    if use_bootstrap:
        source = cgnm_result.get("bootstrapTheta")
        if source is None:
            source = pd.DataFrame(cgnm_result["bootstrapX"], columns=pnames)
        rows = []
        for col in pnames:
            vals = source[col].dropna().values
            q = np.percentile(vals, [0, 25, 50, 75, 100])
            rse = np.std(vals, ddof=1) / abs(np.mean(vals)) * 100 if np.mean(vals) != 0 else np.nan
            rows.append(list(q) + [rse])
        cols = ["Bootstrap Min", "Q25", "Median", "Q75", "Max", "RSE (%)"]
    else:
        if "final_parameter_combos" in cgnm_result:
            source = cgnm_result["final_parameter_combos"]
        else:
            source = pd.DataFrame(cgnm_result["X"], columns=pnames)
        rows = []
        for col in pnames:
            vals = source[col].values[mask]
            vals = vals[np.isfinite(vals)]
            q = np.percentile(vals, [0, 25, 50, 75, 100]) if len(vals) else [np.nan] * 5
            rows.append(list(q))
        cols = ["Min", "Q25", "Median", "Q75", "Max"]

    return pd.DataFrame(rows, index=pnames, columns=cols)


# ---------------------------------------------------------------------------
# Profile-likelihood helpers  (log-file based)
# ---------------------------------------------------------------------------

def load_cgnm_log(log_location):
    """
    Load CGNM result dicts from a log directory (created with save_log=True).

    Parameters
    ----------
    log_location : str  path to the CGNM_log folder

    Returns
    -------
    list of dicts  (one per saved iteration, plus 'final')
    """
    import os
    import pickle
    results = []
    i = 0
    while True:
        path = os.path.join(log_location, f"iteration_{i}.pkl")
        if not os.path.isfile(path):
            break
        with open(path, "rb") as fh:
            results.append(pickle.load(fh))
        i += 1
    final_path = os.path.join(log_location, "iteration_final.pkl")
    if os.path.isfile(final_path):
        with open(final_path, "rb") as fh:
            results.append(pickle.load(fh))
    return results


def prep_ssr_surface_data(log_location, parameter_names=None, num_bins=None):
    """
    Collect all (X, SSR) pairs from a saved log directory for surface plotting.

    Returns
    -------
    dict with keys: X_matrix, R_vec, neg2_log_likelihood, parameter_names,
                    num_bins, initial_X
    """
    import os
    import pickle

    if isinstance(log_location, str):
        dir_names = [log_location]
    else:
        # assume it's a cgnm_result dict
        rs = log_location.get("run_setting", {})
        rn = rs.get("run_name", "")
        dir_names = [f"{rn}_CGNM_log" if rn else "CGNM_log"]

    # Load first iteration to get metadata
    first_path = os.path.join(dir_names[0], "iteration_0.pkl")
    if not os.path.isfile(first_path):
        first_path = os.path.join(dir_names[0], "iteration_1.pkl")
    with open(first_path, "rb") as fh:
        first_result = pickle.load(fh)

    rs = first_result["run_setting"]
    if parameter_names is None:
        parameter_names = rs.get(
            "parameter_names",
            [f"x{i+1}" for i in range(first_result["X"].shape[1])]
        )

    raw_X = first_result["initialX"].copy()
    target_vec = np.asarray(rs["target_vector"], dtype=float)
    valid = ~np.isnan(target_vec)

    def _compute_ssr(result):
        Y_clean = result["Y"][:, valid]
        t_clean = target_vec[valid]
        return np.sum((Y_clean - t_clean) ** 2, axis=1)

    R_vec = _compute_ssr(first_result)
    n_params = raw_X.shape[1]

    for dir_name in dir_names:
        for i in range(1, rs.get("num_iteration", 25) + 1):
            p = os.path.join(dir_name, f"iteration_{i}.pkl")
            if os.path.isfile(p):
                with open(p, "rb") as fh:
                    res = pickle.load(fh)
                raw_X = np.vstack([raw_X, res["X"]])
                R_vec = np.concatenate([R_vec, _compute_ssr(res)])

    # Deduplicate
    combined = np.unique(np.column_stack([raw_X, R_vec]), axis=0)
    raw_X = combined[:, :n_params]
    R_vec = combined[:, n_params]

    neg2_ll = n_params * np.log(np.maximum(R_vec, 1e-300))

    if num_bins is None:
        num_bins = max(1, round(raw_X.shape[0] / 100))

    return dict(
        X_matrix=pd.DataFrame(raw_X, columns=parameter_names),
        R_vec=R_vec,
        neg2_log_likelihood=neg2_ll,
        parameter_names=parameter_names,
        num_bins=num_bins,
        initial_X=first_result["initialX"],
    )


def table_profile_likelihood_confidence_interval(
    log_location, alpha=0.25, num_bins=None, parameter_names=None, silent=False
):
    """
    Confidence intervals approximated from the profile likelihood surface.
    Always inspect the profile likelihood plot before relying on this table.

    Returns
    -------
    pandas.DataFrame  with columns: parameter, CI_lower, best_fit, CI_upper
    """
    if not silent:
        print("WARNING: Always inspect the profile likelihood plot first "
              "(plot_profile_likelihood). Do NOT use this table in isolation.")

    data = prep_ssr_surface_data(log_location, parameter_names, num_bins)
    X_mat = data["X_matrix"]
    R_vec = data["R_vec"]
    n2ll = data["neg2_log_likelihood"]
    pnames = data["parameter_names"]
    nbins = data["num_bins"]
    min_n2ll = np.nanmin(n2ll)
    cutoff = chi2.ppf(1 - alpha, 1) + min_n2ll

    rows = []
    for col in pnames:
        x_vals = X_mat[col].values
        # bin by quantile
        surface_df = pd.DataFrame({"x": x_vals, "n2ll": n2ll, "R": R_vec})
        bin_edges = np.percentile(x_vals, np.linspace(0, 100, nbins + 1))
        profile = []
        for i in range(nbins):
            lo, hi = bin_edges[i], bin_edges[i + 1]
            mask = (x_vals >= lo) & (x_vals <= hi)
            if np.any(mask):
                best = n2ll[mask].min()
                best_x = x_vals[mask][np.argmin(n2ll[mask])]
                profile.append((best_x, best))
        if not profile:
            rows.append((col, np.nan, np.nan, np.nan))
            continue
        profile.sort(key=lambda t: t[0])
        profile_x = np.array([t[0] for t in profile])
        profile_y = np.array([t[1] for t in profile])
        below = profile_y <= cutoff
        if not np.any(below):
            rows.append((col, np.nan, np.nan, np.nan))
            continue
        lb = profile_x[below].min()
        ub = profile_x[below].max()
        best_x = profile_x[np.argmin(profile_y)]
        rows.append((col, lb, best_x, ub))

    df = pd.DataFrame(rows, columns=[
        "parameter",
        f"{alpha * 100:.0f}th percentile",
        "best-fit",
        f"{(1 - alpha) * 100:.0f}th percentile",
    ])
    return df


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_param_names(cgnm_result, parameter_names=None):
    """Resolve parameter names from result dict or auto-generate."""
    if parameter_names is not None and len(parameter_names) > 0:
        return list(parameter_names)
    rs = cgnm_result.get("run_setting", {})
    names = rs.get("parameter_names")
    if names is not None:
        return list(names)
    n = cgnm_result["X"].shape[1]
    return [f"theta_{i+1}" for i in range(n)]
