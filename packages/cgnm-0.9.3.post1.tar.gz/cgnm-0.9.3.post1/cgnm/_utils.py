"""
Internal helper functions for the CGNM Python package.
Translated from R/Cluster_Gauss_Newton_method.R.
"""

import numpy as np
from sklearn.cluster import KMeans
import warnings


# ---------------------------------------------------------------------------
# Matrix / array helpers
# ---------------------------------------------------------------------------

def col_normalize(data_in):
    """Column-wise standardisation (zero mean, unit std, ddof=1)."""
    data_in = np.asarray(data_in, dtype=float)
    out = data_in.copy()
    for i in range(data_in.shape[1]):
        s = np.std(data_in[:, i], ddof=1)
        if s != 0:
            out[:, i] = (data_in[:, i] - np.mean(data_in[:, i])) / s
    return out


def col_sd(data_in):
    return np.nanstd(np.asarray(data_in, dtype=float), axis=0, ddof=1)


def col_max(data_in):
    return np.nanmax(np.asarray(data_in, dtype=float), axis=0)


def col_min(data_in):
    return np.nanmin(np.asarray(data_in, dtype=float), axis=0)


def col_mean(data_in):
    return np.nanmean(np.asarray(data_in, dtype=float), axis=0)


def col_median(data_in):
    return np.nanmedian(np.asarray(data_in, dtype=float), axis=0)


def col_quantile(data_in, prob):
    """Column-wise quantile; prob in [0, 1]."""
    return np.nanpercentile(np.asarray(data_in, dtype=float), prob * 100, axis=0)


# ---------------------------------------------------------------------------
# Elbow / k-means helpers
# ---------------------------------------------------------------------------

def _elbow_index(vec_in):
    """Return 0-based index of elbow point."""
    n = len(vec_in)
    area = []
    for i in range(n - 1):
        a = (vec_in[0] + vec_in[i]) * i + (vec_in[i + 1] + vec_in[n - 1]) * (n - 1 - i)
        area.append(a)
    return int(np.argmin(area))


def optimal_kmeans(data_in):
    """
    Fit KMeans with number of clusters chosen by the elbow method.
    Returns a fitted sklearn KMeans object.
    """
    data_in = np.asarray(data_in, dtype=float)
    n_samples, n_features = data_in.shape
    normalized = col_normalize(data_in)
    num_max_cluster = min(max(1, round(n_samples / max(n_features, 1) / 2)), 10)

    if num_max_cluster > 1:
        residuals = []
        for k in range(2, num_max_cluster + 1):
            km = KMeans(n_clusters=k, n_init=10, random_state=0)
            km.fit(normalized)
            residuals.append(km.inertia_)
        elbow_ind = _elbow_index(residuals)
        k_opt = elbow_ind + 2   # starts from k=2
        km = KMeans(n_clusters=k_opt, n_init=10, random_state=0)
        km.fit(normalized)
    else:
        km = KMeans(n_clusters=1, n_init=10, random_state=0)
        km.fit(normalized)
    return km


# ---------------------------------------------------------------------------
# CGNR linear solvers
# ---------------------------------------------------------------------------

def cgnr_ATAx_ATb(A, b):
    """Solve A^T A x = A^T b via CGNR (Conjugate Gradient on Normal Equations)."""
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float).flatten()
    m, n = A.shape
    x = np.zeros(n)
    if m != len(b):
        warnings.warn(f"cgnr_ATAx_ATb: A has {m} rows but b has {len(b)} elements.")
        return x
    r = A.T @ b
    p = r.copy()
    inner_old = float(r @ r)
    for _ in range(n):
        tv = A @ p
        td = float(tv @ tv)
        if np.isnan(td) or td == 0:
            break
        alpha = inner_old / td
        x = x + alpha * p
        r = r - alpha * (A.T @ tv)
        inner_new = float(r @ r)
        beta = inner_new / inner_old
        inner_old = inner_new
        if inner_old == 0:
            break
        p = r + beta * p
    return x


def cgnr_ATAx_ATb_with_weight(A, b, weight):
    """Weighted CGNR: scale rows by weight before solving."""
    A = np.asarray(A, dtype=float).copy()
    b = np.asarray(b, dtype=float).flatten().copy()
    weight = np.asarray(weight, dtype=float).flatten()
    for i in range(min(len(weight), A.shape[0])):
        if weight[i] == 0:
            A[i, :] = 0.0
            b[i] = 0.0
        else:
            A[i, :] *= weight[i]
            b[i] *= weight[i]
    mask = weight != 0
    if not np.any(mask):
        return np.zeros(A.shape[1])
    return cgnr_ATAx_ATb(A[mask, :], b[mask])


def cgnr_ATAx_ATb_with_reg(A, b, lambda_val):
    """Solve (A^T A + lambda I) x = A^T b via CG."""
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float).flatten()
    m, n = A.shape
    x = np.zeros(n)
    if m != len(b):
        warnings.warn(f"cgnr_ATAx_ATb_with_reg: A has {m} rows but b has {len(b)} elements.")
        return x
    with np.errstate(invalid="ignore", over="ignore", divide="ignore"):
        r = A.T @ b
        p = r.copy()
        inner_old = float(r @ r)
        AtA_reg = A.T @ A + lambda_val * np.eye(n)
        for _ in range(m):
            td = float(p @ (AtA_reg @ p))
            if np.isnan(td) or td == 0:
                break
            alpha = inner_old / td
            x = x + alpha * p
            r = r - alpha * (AtA_reg @ p)
            inner_new = float(r @ r)
            beta = inner_new / inner_old
            inner_old = inner_new
            if inner_old == 0:
                break
            p = r + beta * p
    return x


def cgnr_ATAx_ATb_with_reg_weight(A, b, lambda_val, weight):
    """Weighted CGNR with regularisation."""
    A = np.asarray(A, dtype=float).copy()
    b = np.asarray(b, dtype=float).flatten().copy()
    weight = np.asarray(weight, dtype=float).flatten()
    for i in range(min(len(weight), A.shape[0])):
        if weight[i] == 0:
            A[i, :] = 0.0
            b[i] = 0.0
        else:
            A[i, :] *= weight[i]
            b[i] *= weight[i]
    mask = weight != 0
    if not np.any(mask):
        return np.zeros(A.shape[1])
    return cgnr_ATAx_ATb_with_reg(A[mask, :], b[mask], lambda_val)


# ---------------------------------------------------------------------------
# Safe evaluation of the user-supplied nonlinear function
# ---------------------------------------------------------------------------

def _try_nonlinear_function(x, num_observations, nonlinear_function, valid_target, **kwargs):
    """
    Evaluate nonlinear_function at x.
    x: 1-D array (single parameter set) or 2-D array (rows = parameter sets).
    Returns array of same leading shape with model predictions.
    NaN rows / invalid outputs are set to all-NaN.
    """
    x = np.asarray(x, dtype=float)
    is_vector = (x.ndim == 1)
    num_x_rows = 1 if is_vector else x.shape[0]

    try:
        out = nonlinear_function(x, **kwargs)
        out = np.asarray(out, dtype=float)
    except Exception:
        if is_vector:
            return np.full(num_observations, np.nan)
        return np.full((num_x_rows, num_observations), np.nan)

    if is_vector:
        out = out.flatten()
        if len(out) != num_observations:
            return np.full(num_observations, np.nan)
        if not np.isfinite(np.nansum(out)):
            return np.full(num_observations, np.nan)
        out[~valid_target] = 0.0
        return out
    else:
        if out.ndim == 1:
            # function returned a 1-D array for a matrix input – handle gracefully
            out = np.tile(out, (num_x_rows, 1))
        if out.shape[1] != num_observations:
            return np.full((num_x_rows, num_observations), np.nan)
        bad_rows = ~np.isfinite(np.nansum(out, axis=1))
        out[bad_rows, :] = np.nan
        out[:, ~valid_target] = 0.0
        return out


def _evaluate_batch(X_subset, num_observations, nonlinear_function,
                    valid_target, can_take_matrix_input, **kwargs):
    """
    Evaluate nonlinear function over a subset of X.
    Returns Y matrix, shape (len(X_subset), num_observations).
    """
    if can_take_matrix_input:
        return _try_nonlinear_function(
            X_subset, num_observations, nonlinear_function, valid_target, **kwargs
        )
    # row-by-row evaluation
    rows = []
    for i in range(X_subset.shape[0]):
        row = _try_nonlinear_function(
            X_subset[i, :], num_observations, nonlinear_function, valid_target, **kwargs
        )
        rows.append(row)
    return np.vstack(rows)


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

def cgnm_input_test(nonlinear_function, target_vector, initial_lower_range,
                    initial_upper_range, **kwargs):
    """
    Test whether the nonlinear function can be called with a matrix argument
    (rows = parameter sets). Returns True if matrix input is supported,
    False otherwise.
    """
    n = len(initial_upper_range)
    test_X = np.tile(initial_upper_range, (2, 1))          # shape (2, n)
    try:
        out = nonlinear_function(test_X, **kwargs)
        out = np.asarray(out, dtype=float)
        can_take_matrix = (out.ndim == 2 and out.shape[0] == 2)
    except Exception:
        can_take_matrix = False

    if len(initial_lower_range) != len(initial_upper_range):
        raise ValueError("initial_lower_range and initial_upper_range must have the same length.")

    mid = (np.asarray(initial_upper_range) + np.asarray(initial_lower_range)) / 2

    for label, x_test in [("initial_lower_range", initial_lower_range),
                           ("midpoint", mid),
                           ("initial_upper_range", initial_upper_range)]:
        try:
            y = nonlinear_function(np.asarray(x_test, dtype=float), **kwargs)
            y = np.asarray(y, dtype=float).flatten()
            if len(y) == len(target_vector) and np.isfinite(np.nansum(y)):
                print(f"  nonlinear_function evaluation at {label}: OK")
            else:
                print(f"  WARNING: nonlinear_function evaluation at {label} returned "
                      f"unexpected size or NaN/Inf.")
        except Exception as e:
            print(f"  WARNING: nonlinear_function evaluation at {label} failed: {e}")

    if can_take_matrix:
        print("  nonlinear_function accepts matrix (batch) input.")
    else:
        print("  nonlinear_function evaluated row-by-row.")

    return can_take_matrix
