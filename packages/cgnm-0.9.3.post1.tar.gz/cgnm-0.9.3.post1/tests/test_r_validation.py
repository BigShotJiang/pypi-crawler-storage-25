"""
test_r_validation.py
====================
Validates Python CGNM results against known R CGNM reference values.

The lip-flop kinetics example (1-compartment, oral dosing, log-transformed
observations) is run identically in both R and Python.  The R CGNM package
v0.9.3 produces two near-identical solution clusters; expected values below
were obtained by running the R package with:

    set.seed(42)
    result <- Cluster_Gauss_Newton_method(
        nonlinear_model         = f_lipflop,
        observation_data        = observation,
        initial_lower_bound     = c(Ka=0.001, V1=0.001, CL=0.001),
        initial_upper_bound     = c(Ka=10.0,  V1=10.0,  CL=10.0),
        num_minimizers_to_find  = 100,
        Gauss_Newton_num_iterations = 20
    )
    # Accepted minimizers → two clusters visible in plot_paraDistribution_byHistogram
    # Ka  cluster-1 ≈ 0.518  cluster-2 ≈ 0.927
    # V1  cluster-1 ≈ 10.7   cluster-2 ≈ 19.1
    # CL  both      ≈  9.88
    # Min SSR ≈ 0.007349
"""
import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cgnm.postprocess import (
    accepted_approximate_minimizers,
    accepted_max_ssr,
    accepted_indices,
    best_approximate_minimizers,
    top_indices,
)


# ─────────────────────────────────────────────────────────────────────────────
# R reference values
# ─────────────────────────────────────────────────────────────────────────────
# These are the "ground truth" values expected from the R package.
# Tolerances are generous to allow for platform/RNG differences but tight
# enough to catch algorithmic regressions.

R_MIN_SSR          = 0.007349   # minimum SSR among all minimizers
R_MAX_SSR_ACCEPTED = 0.050      # accepted_max_ssr threshold (Grubbs / chi-sq)

# Two solution clusters for Ka (log10-transformed)
R_KA_CLUSTER1 = 0.518   # smaller Ka  (absorption > elimination)
R_KA_CLUSTER2 = 0.927   # larger Ka   (flip)

# V1 for both clusters (from R log10 → original space)
R_V1_CLUSTER2  = 19.1   # larger V1 accompanies larger Ka cluster
R_CL_BOTH      =  9.88  # CL is similar in both clusters


class TestMinSSR:
    """Best minimizer SSR must be close to the R reference."""

    def test_min_ssr_within_tolerance(self, cgnm_result_lipflop):
        SSR = cgnm_result_lipflop["residual_history"][:, -1]
        assert SSR.min() < R_MAX_SSR_ACCEPTED, \
            f"Min SSR {SSR.min():.6f} exceeds {R_MAX_SSR_ACCEPTED}"

    def test_min_ssr_ballpark(self, cgnm_result_lipflop):
        """Min SSR must be within 5× of the R reference."""
        SSR = cgnm_result_lipflop["residual_history"][:, -1]
        assert SSR.min() <= 5 * R_MIN_SSR, \
            f"Min SSR {SSR.min():.6f} deviates more than 5× from R ref {R_MIN_SSR}"


class TestAcceptedMinimizers:
    """Accepted minimizer set must be non-trivial and reproducible."""

    def test_accepted_set_non_empty(self, cgnm_result_lipflop):
        df = accepted_approximate_minimizers(cgnm_result_lipflop)
        assert len(df) > 0

    def test_accepted_fraction_reasonable(self, cgnm_result_lipflop):
        """Between 10% and 90% of minimizers should be accepted."""
        df  = accepted_approximate_minimizers(cgnm_result_lipflop)
        n   = cgnm_result_lipflop["residual_history"].shape[0]
        frac = len(df) / n
        assert 0.05 <= frac <= 0.95, \
            f"Accepted fraction {frac:.2%} is outside expected 5–95% range"

    def test_accepted_all_below_threshold(self, cgnm_result_lipflop):
        thresh = accepted_max_ssr(cgnm_result_lipflop)
        idx    = accepted_indices(cgnm_result_lipflop)
        SSR    = cgnm_result_lipflop["residual_history"][:, -1]
        assert np.all(SSR[idx] <= thresh + 1e-10)


class TestParameterValues:
    """Best 1–2 minimizers must be close to R reference values."""

    def test_best_ka_in_expected_range(self, cgnm_result_lipflop):
        """Ka of the single-best minimizer should be in [0.3, 1.5]."""
        df = best_approximate_minimizers(cgnm_result_lipflop, num_parameter_set=1)
        # Parameters in original (non-log) space
        Ka = df["Ka"].values[0]
        assert 0.3 <= Ka <= 1.5, f"Best Ka = {Ka:.4f} outside expected [0.3, 1.5]"

    def test_best_v1_positive(self, cgnm_result_lipflop):
        df = best_approximate_minimizers(cgnm_result_lipflop, num_parameter_set=1)
        V1 = df["V1"].values[0]
        assert V1 > 0

    def test_best_cl_positive(self, cgnm_result_lipflop):
        df = best_approximate_minimizers(cgnm_result_lipflop, num_parameter_set=1)
        CL = df["CL"].values[0]
        assert CL > 0

    def test_cl_in_expected_range(self, cgnm_result_lipflop):
        """CL should be in [1, 50] (log10 scale gives wide range)."""
        df  = accepted_approximate_minimizers(cgnm_result_lipflop)
        CL_median = df["CL"].median()
        assert 1.0 <= CL_median <= 50.0, \
            f"Median CL {CL_median:.4f} outside expected [1, 50]"

    def test_two_clusters_detected(self, cgnm_result_lipflop):
        """
        Accepted Ka values should span at least two decades in log10-space,
        indicating the two lip-flop solutions were both found.
        """
        df = accepted_approximate_minimizers(cgnm_result_lipflop)
        Ka_vals = np.log10(df["Ka"].values)
        # Range of log10(Ka) must exceed 0.2 (two clusters are ~0.4 apart)
        assert Ka_vals.max() - Ka_vals.min() > 0.1, \
            "Ka values appear to collapse to a single cluster – lip-flop not found"


class TestTopIndicesReferenceSSR:
    """Top-k results must monotonically increase in SSR."""

    def test_top5_ssrs_monotone(self, cgnm_result_lipflop):
        idx = top_indices(cgnm_result_lipflop, 5)
        SSR = cgnm_result_lipflop["residual_history"][:, -1]
        ssrs = SSR[idx]
        assert np.all(np.diff(ssrs) >= -1e-12), \
            "top_indices SSRs are not non-decreasing"

    def test_top1_vs_overall_minimum(self, cgnm_result_lipflop):
        idx   = top_indices(cgnm_result_lipflop, 1)
        SSR   = cgnm_result_lipflop["residual_history"][:, -1]
        assert abs(SSR[idx[0]] - SSR.min()) < 1e-12


class TestReproducibility:
    """Running again with the same seed must give the same result."""

    def test_same_seed_same_best_ssr(self, lipflop_model, lipflop_observation):
        """Two independent runs with the same seed should give equal min SSR."""
        from cgnm import cluster_gauss_newton_method

        common_kwargs = dict(
            nonlinear_function     = lipflop_model,
            target_vector          = lipflop_observation,
            initial_lower_range    = [0.1, 0.1, 0.1],
            initial_upper_range    = [10.0, 10.0, 10.0],
            num_minimizers_to_find = 30,
            num_iteration          = 10,
            save_log               = False,
        )

        np.random.seed(7)
        r1 = cluster_gauss_newton_method(**common_kwargs)
        np.random.seed(7)
        r2 = cluster_gauss_newton_method(**common_kwargs)

        ssr1 = r1["residual_history"][:, -1].min()
        ssr2 = r2["residual_history"][:, -1].min()
        assert abs(ssr1 - ssr2) < 1e-12, \
            f"Same seed gives different min SSR: {ssr1:.8f} vs {ssr2:.8f}"
