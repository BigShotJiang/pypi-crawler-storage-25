"""
test_utils.py
=============
Unit tests for cgnm/_utils.py
"""
import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cgnm._utils import (
    col_normalize,
    optimal_kmeans,
    cgnr_ATAx_ATb,
    cgnr_ATAx_ATb_with_reg,
    cgnr_ATAx_ATb_with_weight,
    cgnr_ATAx_ATb_with_reg_weight,
    cgnm_input_test,
)


class TestColNormalize:
    def test_zero_mean_unit_std(self):
        # col_normalize divides by ddof=1 std; verify zero mean and unit ddof=1 std
        rng = np.random.default_rng(0)
        X = rng.normal(5, 2, (50, 3))
        Xn = col_normalize(X)
        assert Xn.shape == X.shape
        np.testing.assert_allclose(Xn.mean(axis=0), 0, atol=1e-10)
        np.testing.assert_allclose(np.std(Xn, axis=0, ddof=1), 1, atol=1e-10)

    def test_constant_column_unchanged(self):
        # constant column has std=0 so col_normalize leaves it as-is
        X = np.ones((10, 2))
        Xn = col_normalize(X)
        np.testing.assert_array_equal(Xn, X)

    def test_single_row_returns_nan_or_original(self):
        # single-row: ddof=1 std is NaN; implementation leaves column unchanged or NaN
        X = np.array([[1.0, 2.0, 3.0]])
        Xn = col_normalize(X)
        # either NaN (divide by NaN std) or unchanged – both are acceptable
        for i in range(3):
            assert np.isnan(Xn[0, i]) or Xn[0, i] == X[0, i]


class TestOptimalKmeans:
    # optimal_kmeans returns a fitted sklearn KMeans object; use .labels_ for labels

    def test_two_clear_clusters(self):
        rng = np.random.default_rng(1)
        c1 = rng.normal(0, 0.1, (30, 2))
        c2 = rng.normal(10, 0.1, (30, 2))
        X = np.vstack([c1, c2])
        km = optimal_kmeans(X)
        # Elbow method may select more than 2 clusters, but at least 2 should appear
        n_clusters_found = len(np.unique(km.labels_))
        assert n_clusters_found >= 2, f"Expected >=2 clusters, got {n_clusters_found}"

    def test_returns_kmeans_object(self):
        X = np.random.default_rng(2).normal(0, 1, (20, 3))
        km = optimal_kmeans(X)
        assert hasattr(km, "labels_") and hasattr(km, "inertia_")

    def test_labels_length_matches_input(self):
        X = np.random.default_rng(2).normal(0, 1, (20, 3))
        km = optimal_kmeans(X)
        assert len(km.labels_) == 20


class TestCGNRSolvers:
    """
    All four CGNR variants solve variants of A^T A x = A^T b.
    We verify against numpy least-squares.
    """
    def _random_overdetermined(self, m=30, n=5, seed=99):
        rng = np.random.default_rng(seed)
        A = rng.normal(0, 1, (m, n))
        x_true = rng.normal(0, 1, n)
        b = A @ x_true + rng.normal(0, 0.01, m)
        return A, b, x_true

    def test_basic(self):
        A, b, x_true = self._random_overdetermined()
        x = cgnr_ATAx_ATb(A, b)
        np.testing.assert_allclose(x, x_true, atol=0.1)

    def test_with_reg(self):
        A, b, x_true = self._random_overdetermined()
        x = cgnr_ATAx_ATb_with_reg(A, b, lambda_val=1e-6)
        np.testing.assert_allclose(x, x_true, atol=0.1)

    def test_with_weight(self):
        A, b, x_true = self._random_overdetermined()
        w = np.ones(len(b))
        x = cgnr_ATAx_ATb_with_weight(A, b, weight=w)
        np.testing.assert_allclose(x, x_true, atol=0.1)

    def test_with_reg_weight(self):
        A, b, x_true = self._random_overdetermined()
        w = np.ones(len(b))
        x = cgnr_ATAx_ATb_with_reg_weight(A, b, lambda_val=1e-6, weight=w)
        np.testing.assert_allclose(x, x_true, atol=0.1)

    def test_zero_weight_rows_ignored(self):
        A, b, _ = self._random_overdetermined()
        w = np.ones(len(b))
        w[:5] = 0
        x_full = cgnr_ATAx_ATb_with_weight(A, b, weight=np.ones(len(b)))
        x_zero = cgnr_ATAx_ATb_with_weight(A, b, weight=w)
        # The solutions differ but neither should crash or return NaN
        assert np.all(np.isfinite(x_zero))

    def test_nan_input_returns_finite_or_zeros(self):
        A = np.full((5, 3), np.nan)
        b = np.ones(5)
        x = cgnr_ATAx_ATb_with_reg(A, b, lambda_val=1.0)
        # Should not raise; result may be zeros or NaN-propagated but finite shape
        assert x.shape == (3,)

    def test_reg_suppresses_warning(self, recwarn):
        """np.errstate wrapper must prevent RuntimeWarning leaking."""
        A = np.full((4, 2), 1e300)
        b = np.ones(4)
        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            cgnr_ATAx_ATb_with_reg(A, b, 1.0)
        runtime_warns = [x for x in w if issubclass(x.category, RuntimeWarning)]
        assert len(runtime_warns) == 0


class TestCgnmInputTest:
    def test_vector_only_model(self):
        def model(x):
            return np.array([x[0] + x[1], x[0] * x[1]])
        can = cgnm_input_test(model, np.array([1.0, 2.0]),
                               [0.0, 0.0], [1.0, 1.0])
        assert isinstance(can, bool)

    def test_matrix_model_detected(self):
        def model(X):
            if X.ndim == 2:
                return X @ np.array([[1.0], [2.0]])
            return np.array([X[0] + 2 * X[1]])
        can = cgnm_input_test(model, np.array([1.0, 2.0]),
                               [0.0, 0.0], [1.0, 1.0])
        assert isinstance(can, bool)
