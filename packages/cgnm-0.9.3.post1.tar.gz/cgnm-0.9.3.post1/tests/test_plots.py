"""
test_plots.py
=============
Smoke tests for cgnm/plot.py.
Each test verifies the function can be called without raising and returns a
matplotlib Figure.  The 'Agg' backend is used so no display is needed.
"""
import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from cgnm.plot import (
    plot_rank_ssr,
    plot_para_distribution_by_histogram,
    plot_para_distribution_by_violin_plots,
    plot_goodness_of_fit,
    plot_ssr_parameter_value,
)
from cgnm.postprocess import accepted_indices, top_indices


@pytest.fixture(autouse=True)
def close_figures():
    """Close all matplotlib figures after each test."""
    yield
    plt.close("all")


class TestPlotRankSSR:
    def test_returns_figure(self, cgnm_result_lipflop):
        fig = plot_rank_ssr(cgnm_result_lipflop)
        assert isinstance(fig, plt.Figure)

    def test_with_custom_indices(self, cgnm_result_lipflop):
        idx = top_indices(cgnm_result_lipflop, 10)
        fig = plot_rank_ssr(cgnm_result_lipflop, indices_to_include=idx)
        assert isinstance(fig, plt.Figure)


class TestPlotParaHistogram:
    def test_returns_figure(self, cgnm_result_lipflop):
        fig = plot_para_distribution_by_histogram(cgnm_result_lipflop)
        assert isinstance(fig, plt.Figure)

    def test_with_custom_indices(self, cgnm_result_lipflop):
        idx = top_indices(cgnm_result_lipflop, 20)
        fig = plot_para_distribution_by_histogram(
            cgnm_result_lipflop, indices_to_include=idx
        )
        assert isinstance(fig, plt.Figure)


class TestPlotParaViolin:
    def test_returns_figure(self, cgnm_result_lipflop):
        fig = plot_para_distribution_by_violin_plots(cgnm_result_lipflop)
        assert isinstance(fig, plt.Figure)


class TestPlotGoodnessOfFit:
    def test_returns_figure(self, cgnm_result_lipflop):
        fig = plot_goodness_of_fit(cgnm_result_lipflop)
        assert isinstance(fig, plt.Figure)

    def test_with_plot_rank(self, cgnm_result_lipflop):
        # plot_goodness_of_fit uses plot_rank (list of SSR rank numbers)
        fig = plot_goodness_of_fit(cgnm_result_lipflop, plot_rank=[1, 2, 3])
        assert isinstance(fig, plt.Figure)


class TestPlotSSRParameterValue:
    def test_returns_figure(self, cgnm_result_lipflop):
        fig = plot_ssr_parameter_value(cgnm_result_lipflop)
        assert isinstance(fig, plt.Figure)

    def test_with_accepted_indices(self, cgnm_result_lipflop):
        idx = accepted_indices(cgnm_result_lipflop)
        fig = plot_ssr_parameter_value(
            cgnm_result_lipflop, indices_to_include=idx
        )
        assert isinstance(fig, plt.Figure)
