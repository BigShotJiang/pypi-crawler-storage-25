"""
test_postprocess.py
===================
Unit tests for cgnm/postprocess.py
"""
import numpy as np
import pandas as pd
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cgnm
from cgnm.postprocess import (
    accepted_max_ssr,
    accepted_indices,
    accepted_indices_binary,
    top_indices,
    accepted_approximate_minimizers,
    best_approximate_minimizers,
    table_parameter_summary,
)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers: construct minimal synthetic CGNM result dicts
# ─────────────────────────────────────────────────────────────────────────────

def _make_result(n_min=20, n_obs=5, n_par=2, seed=0):
    """
    Synthetic result where X[:, 0] = final SSR (so we can predict acceptance).
    residual_history[:, -1] = SSR_vec.
    """
    rng = np.random.default_rng(seed)
    X = rng.uniform(0, 1, (n_min, n_par))
    Y = rng.normal(0, 1, (n_min, n_obs))
    # SSR: first 10 small, last 10 large
    SSR_vec = np.concatenate([rng.uniform(0.01, 0.1, 10),
                               rng.uniform(10.0, 100.0, 10)])
    residual_history = np.column_stack([SSR_vec * 2, SSR_vec])
    target = rng.normal(0, 1, n_obs)
    return {
        "X": X,
        "Y": Y,
        "residual_history": residual_history,
        "initialX": X.copy(),
        "initialY": Y.copy(),
        "run_setting": {
            "target_vector": target,
            "parameter_names": [f"p{i}" for i in range(n_par)],
            "num_minimizers_to_find": n_min,
        },
    }


class TestAcceptedMaxSSR:
    def test_returns_float(self):
        r = _make_result()
        v = accepted_max_ssr(r)
        assert isinstance(v, float)

    def test_above_minimum_ssr(self):
        r = _make_result()
        min_ssr = r["residual_history"][:, -1].min()
        assert accepted_max_ssr(r) >= min_ssr

    def test_algorithm1_vs_algorithm2(self):
        r = _make_result()
        v1 = accepted_max_ssr(r, algorithm=1)
        v2 = accepted_max_ssr(r, algorithm=2)
        # Both must be >= min SSR
        min_ssr = r["residual_history"][:, -1].min()
        assert v1 >= min_ssr
        assert v2 >= min_ssr

    def test_num_parameters_limit(self):
        r = _make_result()
        v = accepted_max_ssr(r, use_accepted_approximate_minimizers=False,
                              num_parameters_included=5)
        SSR_sorted = np.sort(r["residual_history"][:, -1])
        assert abs(v - SSR_sorted[4]) < 1e-10


class TestAcceptedIndices:
    def test_returns_ndarray(self):
        r = _make_result()
        idx = accepted_indices(r)
        assert isinstance(idx, np.ndarray)

    def test_all_accepted_have_small_ssr(self):
        r = _make_result()
        idx = accepted_indices(r)
        max_ssr = accepted_max_ssr(r)
        SSR = r["residual_history"][:, -1]
        assert np.all(SSR[idx] <= max_ssr + 1e-10)

    def test_binary_mask_consistency(self):
        r = _make_result()
        idx  = accepted_indices(r)
        mask = accepted_indices_binary(r)
        assert len(mask) == r["residual_history"].shape[0]
        assert np.all(mask[idx])
        assert not np.any(mask[~np.isin(np.arange(len(mask)), idx)])


class TestTopIndices:
    def test_correct_number(self):
        r = _make_result()
        idx = top_indices(r, 5)
        assert len(idx) == 5

    def test_are_lowest_ssr(self):
        r = _make_result()
        idx = top_indices(r, 3)
        SSR = r["residual_history"][:, -1]
        assert np.all(SSR[idx] <= np.sort(SSR)[2] + 1e-10)

    def test_top1_is_best(self):
        r = _make_result()
        idx = top_indices(r, 1)
        SSR = r["residual_history"][:, -1]
        assert idx[0] == np.argmin(SSR)


class TestAcceptedApproximateMinimizers:
    def test_returns_dataframe(self, cgnm_result_lipflop):
        df = accepted_approximate_minimizers(cgnm_result_lipflop)
        assert isinstance(df, pd.DataFrame)

    def test_columns_are_parameter_names(self, cgnm_result_lipflop):
        df = accepted_approximate_minimizers(cgnm_result_lipflop)
        for col in ["Ka", "V1", "CL"]:
            assert col in df.columns

    def test_has_no_extra_columns(self, cgnm_result_lipflop):
        # accepted_approximate_minimizers returns only parameter columns
        df = accepted_approximate_minimizers(cgnm_result_lipflop)
        assert list(df.columns) == ["Ka", "V1", "CL"]

    def test_non_empty(self, cgnm_result_lipflop):
        df = accepted_approximate_minimizers(cgnm_result_lipflop)
        assert len(df) > 0

    def test_all_positive_parameters(self, cgnm_result_lipflop):
        """Ka, V1, CL must all be positive."""
        df = accepted_approximate_minimizers(cgnm_result_lipflop)
        assert np.all(df[["Ka", "V1", "CL"]].values > 0)


class TestBestApproximateMinimizers:
    def test_returns_n_rows(self, cgnm_result_lipflop):
        df = best_approximate_minimizers(cgnm_result_lipflop, num_parameter_set=2)
        assert len(df) == 2

    def test_best_has_lowest_ssr(self, cgnm_result_lipflop):
        # Verify top-1 param set corresponds to lowest SSR row
        SSR = cgnm_result_lipflop["residual_history"][:, -1]
        df1 = best_approximate_minimizers(cgnm_result_lipflop, num_parameter_set=1)
        df5 = best_approximate_minimizers(cgnm_result_lipflop, num_parameter_set=5)
        # top-1 Ka should equal the Ka of the single lowest-SSR row
        best_idx = np.argmin(SSR)
        Theta = cgnm_result_lipflop["final_parameter_combos"]
        assert abs(df1["Ka"].values[0] - Theta["Ka"].values[best_idx]) < 1e-8
        # top-5 SSR range >= top-1 SSR range
        assert len(df5) == 5


class TestTableParameterSummary:
    def test_returns_dataframe(self, cgnm_result_lipflop):
        tbl = table_parameter_summary(cgnm_result_lipflop)
        assert isinstance(tbl, pd.DataFrame)

    def test_has_quantile_columns(self, cgnm_result_lipflop):
        tbl = table_parameter_summary(cgnm_result_lipflop)
        # Should contain at least median (p50) or similar
        cols = " ".join(tbl.columns.astype(str)).lower()
        assert any(q in cols for q in ["50", "median", "0.5"])

    def test_rows_match_parameters(self, cgnm_result_lipflop):
        tbl = table_parameter_summary(cgnm_result_lipflop)
        # One row per parameter
        assert len(tbl) == 3

    def test_accepts_index_subset(self, cgnm_result_lipflop):
        idx = top_indices(cgnm_result_lipflop, 5)
        tbl = table_parameter_summary(cgnm_result_lipflop, indices_to_include=idx)
        assert len(tbl) == 3
