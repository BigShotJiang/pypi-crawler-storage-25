"""
test_core.py
============
Unit tests for cgnm/core.py — parameter transforms and main algorithm.
"""
import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from cgnm.core import (
    _build_transform_indices,
    _transform_to_unconstrained,
    _transform_to_original,
)
import cgnm

# ─────────────────────────────────────────────────────────────────────────────
# Parameter transform round-trips
# ─────────────────────────────────────────────────────────────────────────────

class TestBuildTransformIndices:
    def test_lower_bound_only(self):
        lb = [0.0, None, 0.0]
        ub = [None, None, None]
        LB, UB, BB = _build_transform_indices(lb, ub)
        np.testing.assert_array_equal(LB, [True,  False, True])
        np.testing.assert_array_equal(UB, [False, False, False])
        np.testing.assert_array_equal(BB, [False, False, False])

    def test_upper_bound_only(self):
        lb = [None, None]
        ub = [1.0,  None]
        LB, UB, BB = _build_transform_indices(lb, ub)
        np.testing.assert_array_equal(LB, [False, False])
        np.testing.assert_array_equal(UB, [True,  False])
        np.testing.assert_array_equal(BB, [False, False])

    def test_both_bounds(self):
        lb = [0.0, 0.0]
        ub = [1.0, 10.0]
        LB, UB, BB = _build_transform_indices(lb, ub)
        np.testing.assert_array_equal(BB, [True, True])
        np.testing.assert_array_equal(LB, [False, False])
        np.testing.assert_array_equal(UB, [False, False])

    def test_no_bounds(self):
        lb = [None, None, None]
        ub = [None, None, None]
        LB, UB, BB = _build_transform_indices(lb, ub)
        assert not np.any(LB | UB | BB)


class TestParameterTransformRoundTrip:
    """
    _transform_to_unconstrained followed by _transform_to_original
    should recover the original theta to machine precision.
    """

    def _roundtrip(self, theta, lb, ub):
        LB, UB, BB = _build_transform_indices(lb, ub)
        x     = _transform_to_unconstrained(np.array(theta), lb, ub, LB, UB, BB)
        theta2 = _transform_to_original(x, lb, ub, LB, UB, BB)
        np.testing.assert_allclose(theta2, theta, rtol=1e-10, atol=1e-12)

    def test_lower_bound_only(self):
        self._roundtrip([2.0, 5.0], [0.0, 0.0], [None, None])

    def test_upper_bound_only(self):
        self._roundtrip([0.3, 8.0], [None, None], [1.0, 10.0])

    def test_both_bounds(self):
        self._roundtrip([0.5, 3.0], [0.0, 0.0], [1.0, 5.0])

    def test_no_bounds(self):
        self._roundtrip([1.0, -2.0, 100.0], [None]*3, [None]*3)

    def test_mixed_bounds(self):
        theta = [2.0, 0.4, -5.0]
        lb    = [0.0, 0.0, None]
        ub    = [None, 1.0, None]
        self._roundtrip(theta, lb, ub)

    def test_batch_roundtrip(self):
        """2-D array of parameter sets should also round-trip."""
        lb = [0.0, 0.0]
        ub = [None, 10.0]
        LB, UB, BB = _build_transform_indices(lb, ub)
        rng = np.random.default_rng(7)
        theta = rng.uniform([0.01, 0.01], [5.0, 9.99], (20, 2))
        X = np.column_stack([
            np.log(theta[:, 0] - 0.0),                 # LB transform
            np.log((theta[:, 1] - 0.0) / (10.0 - theta[:, 1])),  # BB transform
        ])
        theta2 = _transform_to_original(X, lb, ub, LB, UB, BB)
        np.testing.assert_allclose(theta2, theta, rtol=1e-10)


# ─────────────────────────────────────────────────────────────────────────────
# Bounds enforcement
# ─────────────────────────────────────────────────────────────────────────────

class TestBoundsEnforcement:
    """Results should stay within specified bounds across all accepted minimisers."""

    def test_lower_bound_respected(self):
        # Model: single output to avoid batch-detection ambiguity
        def model(x):
            return np.array([float(x[0])**2 + float(x[1])**2])

        np.random.seed(0)
        result = cgnm.cluster_gauss_newton_method(
            nonlinear_function    = model,
            target_vector         = np.array([8.0]),
            initial_lower_range   = [0.5, 0.5],   # must be > lower_bound for LB transform
            initial_upper_range   = [5.0, 5.0],
            lower_bound           = [0.0, 0.0],
            upper_bound           = [None, None],
            num_minimizers_to_find= 30,
            num_iteration         = 10,
            save_log              = False,
        )
        Theta = result["final_parameter_combos"].values
        assert np.all(Theta[:, 0] >= 0 - 1e-6)
        assert np.all(Theta[:, 1] >= 0 - 1e-6)

    def test_both_bounds_respected(self):
        # initial range MUST be strictly inside [lower_bound, upper_bound]
        def model(x):
            return np.array([float(x[0])])

        np.random.seed(1)
        result = cgnm.cluster_gauss_newton_method(
            nonlinear_function    = model,
            target_vector         = np.array([3.0]),
            initial_lower_range   = [1.5],   # inside [1.0, 5.0]
            initial_upper_range   = [4.5],   # inside [1.0, 5.0]
            lower_bound           = [1.0],
            upper_bound           = [5.0],
            num_minimizers_to_find= 20,
            num_iteration         = 5,
            save_log              = False,
        )
        Theta = result["final_parameter_combos"].values
        assert np.all(Theta[:, 0] >= 1.0 - 1e-4)
        assert np.all(Theta[:, 0] <= 5.0 + 1e-4)


# ─────────────────────────────────────────────────────────────────────────────
# Simple 1-D quadratic: known unique solution
# ─────────────────────────────────────────────────────────────────────────────

class TestSimpleQuadratic:
    """f(x) = x^2, y* = 4 → unique solution x = ±2."""

    @pytest.fixture(autouse=True)
    def run_cgnm(self):
        np.random.seed(10)
        self.result = cgnm.cluster_gauss_newton_method(
            nonlinear_function    = lambda x: np.array([x[0]**2]),
            target_vector         = np.array([4.0]),
            initial_lower_range   = [-10.0],
            initial_upper_range   = [10.0],
            num_minimizers_to_find= 50,
            num_iteration         = 20,
            save_log              = False,
        )

    def test_result_is_dict(self):
        assert isinstance(self.result, dict)

    def test_required_keys(self):
        for k in ("X", "Y", "residual_history", "initialX", "initialY",
                  "lambda_history", "run_setting"):
            assert k in self.result, f"Missing key: {k}"

    def test_residual_history_shape(self):
        rh = self.result["residual_history"]
        assert rh.shape[0] == 50
        # algorithm may converge before all iterations; column count <= num_iteration + 1
        assert 2 <= rh.shape[1] <= 21

    def test_finds_solution_near_two(self):
        X_final = self.result["X"]
        best_idx = int(np.argmin(self.result["residual_history"][:, -1]))
        x_best = abs(X_final[best_idx, 0])
        assert abs(x_best - 2.0) < 0.1

    def test_minimum_ssr_near_zero(self):
        min_ssr = self.result["residual_history"][:, -1].min()
        assert min_ssr < 1e-8


# ─────────────────────────────────────────────────────────────────────────────
# Result dict structure & dtype tests
# ─────────────────────────────────────────────────────────────────────────────

class TestResultStructure:
    def test_X_shape(self, cgnm_result_lipflop):
        n_min = 100
        n_par = 3
        assert cgnm_result_lipflop["X"].shape == (n_min, n_par)

    def test_Y_shape(self, cgnm_result_lipflop):
        n_min = 100
        n_obs = 9
        assert cgnm_result_lipflop["Y"].shape == (n_min, n_obs)

    def test_residual_history_monotone_median(self, cgnm_result_lipflop):
        """Median SSR must be non-increasing across iterations."""
        rh = cgnm_result_lipflop["residual_history"]
        medians = np.median(rh, axis=0)
        # Allow tiny floating-point violations; overall trend must be downward
        assert medians[-1] < medians[0]

    def test_run_setting_keys(self, cgnm_result_lipflop):
        rs = cgnm_result_lipflop["run_setting"]
        for k in ("target_vector", "initial_lower_range", "initial_upper_range",
                  "num_minimizers_to_find", "num_iteration", "parameter_names"):
            assert k in rs

    def test_parameter_names_stored(self, cgnm_result_lipflop):
        assert cgnm_result_lipflop["run_setting"]["parameter_names"] == ["Ka", "V1", "CL"]
