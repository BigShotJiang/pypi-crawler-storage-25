"""
conftest.py – shared pytest fixtures for the CGNM test suite.
"""
import sys, os
import numpy as np
import pytest

# Ensure cgnm and companion modules are importable from any working directory
_PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PARENT not in sys.path:
    sys.path.insert(0, _PARENT)

import cgnm


# ─────────────────────────────────────────────────────────────────────────────
# Shared model: 1-compartment oral (Bateman) on log10-scale
# ─────────────────────────────────────────────────────────────────────────────
OBS_TIME = np.array([0.1, 0.2, 0.4, 0.6, 1.0, 2.0, 3.0, 6.0, 12.0])

# True parameters for Solution 1 (standard flip-flop example)
TRUE_KA_1  = 0.518
TRUE_V1_1  = 10.661
TRUE_CL_1  = 9.877
TRUE_KA_2  = 0.927
TRUE_V1_2  = 19.072


def _bateman_log10(ka, V1, CL, t=OBS_TIME, Dose=1000.0):
    k_el = CL / V1
    if abs(ka - k_el) < 1e-10:
        return np.full(len(t), np.nan)
    Cp = ka * Dose / (V1 * (ka - k_el)) * (np.exp(-k_el * t) - np.exp(-ka * t))
    Cp = np.where(Cp > 0, Cp, np.nan)
    return np.log10(Cp)


@pytest.fixture(scope="session")
def lipflop_observation():
    """Observed data from the lip-flop kinetics R vignette."""
    return np.log10(np.array([4.91, 8.65, 12.4, 18.7, 24.3, 24.5, 18.4, 4.66, 0.238]))


@pytest.fixture(scope="session")
def lipflop_model():
    """One-compartment oral model function for lip-flop kinetics."""
    def _model(x):
        ka, V1, CL = x[0], x[1], x[2]
        return _bateman_log10(ka, V1, CL)
    return _model


@pytest.fixture(scope="session")
def cgnm_result_lipflop(lipflop_model, lipflop_observation):
    """
    Pre-computed (seeded, deterministic) CGNM result for the lip-flop example.
    Runs only once per test session.
    """
    np.random.seed(42)
    result = cgnm.cluster_gauss_newton_method(
        nonlinear_function     = lipflop_model,
        target_vector          = lipflop_observation,
        initial_lower_range    = [0.1, 0.1, 0.1],
        initial_upper_range    = [10.0, 10.0, 10.0],
        num_minimizers_to_find = 100,
        num_iteration          = 20,
        save_log               = False,
        parameter_names        = ["Ka", "V1", "CL"],
    )
    return result
