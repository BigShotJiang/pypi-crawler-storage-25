"""
ode_solver.py
-------------
Generic multi-dose ODE wrapper for arbitrary user-defined systems.

This module provides :class:`MultiDoseODESolver` — a solver that integrates
any user-supplied ODE system piecewise over an arbitrary dosing schedule,
returning state values at requested observation times.

Why piecewise?
~~~~~~~~~~~~~~
``scipy.integrate.solve_ivp`` handles one continuous interval at a time.
Instantaneous dose events (bolus) or infusion start/stop transitions make
the RHS discontinuous.  The solver splits the time axis at every such event,
applies the transition to the state / forcing, and integrates each smooth
segment independently.

Dosing API
~~~~~~~~~~
Each dose is described by four per-event vectors:

* ``dose_times``        – when the dose occurs
* ``dose_amounts``      – how much drug is given
* ``dose_compartments`` – *which state index* receives the drug
                          (scalar applies the same to all doses)
* ``dose_durations``    – ``0`` → instantaneous bolus  (``state[cpt] += amount``)
                          ``> 0`` → zero-order infusion lasting that many time units
                          (``dxdt[cpt] += amount / duration``  over the duration)

Set-value events
~~~~~~~~~~~~~~~~
Use ``set_events`` to force a state variable to an exact value at an
arbitrary time::

    set_events = [(10.0, 2, 0.0)]   # at t=10 set state[2] = 0

Usage example
~~~~~~~~~~~~~
::

    import numpy as np
    from poped_lite.ode_solver import MultiDoseODESolver

    # 2-state oral PK model: [gut, central]
    def pk_rhs(t, x, params):
        Ka, V, CL = params
        return [-Ka*x[0],  Ka*x[0] - (CL/V)*x[1]]

    # Two oral doses, a 2-hour IV infusion into central (cpt=1), and a reset
    solver = MultiDoseODESolver(
        rhs              = pk_rhs,
        n_states         = 2,
        ic               = [0.0, 0.0],
        dose_times       = [0.0,   24.0,  48.0],
        dose_amounts     = [100.0, 100.0, 200.0],
        dose_compartments= [0,     0,     1   ],   # oral, oral, IV infusion
        dose_durations   = [0.0,   0.0,   2.0 ],   # bolus, bolus, 2-h infusion
        set_events       = [(72.0, 1, 0.0)],        # flush central at t=72
    )
    result = solver.solve([1,4,12,24,26,48,50,72,96], params=(1.0, 10.0, 2.0))
    # result.y[state_idx, time_idx]
    print(result.y[1])   # central compartment concentrations
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
from scipy.integrate import solve_ivp  # type: ignore


# ══════════════════════════════════════════════════════════════════════════════
# Return type
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ODESolution:
    """
    Container returned by :meth:`MultiDoseODESolver.solve`.

    Attributes
    ----------
    t : np.ndarray, shape (n_obs,)
        Requested observation times.
    y : np.ndarray, shape (n_states, n_obs)
        State vector at each observation time.
    success : bool
        True if all integration segments converged.
    messages : list[str]
        Per-segment status messages from scipy (non-empty on failure).
    """
    t: np.ndarray
    y: np.ndarray
    success: bool = True
    messages: List[str] = field(default_factory=list)


# ══════════════════════════════════════════════════════════════════════════════
# Built-in dose applicators
# ══════════════════════════════════════════════════════════════════════════════

def bolus_to_depot(state: np.ndarray,
                   amount: float,
                   params: Any) -> np.ndarray:
    """
    Add *amount* to ``state[0]`` (the gut/depot compartment).
    Standard applicator for oral dosing or IV bolus via depot.
    """
    new = state.copy()
    new[0] += amount
    return new


def bolus_to_central(state: np.ndarray,
                     amount: float,
                     params: Any) -> np.ndarray:
    """
    Add *amount* directly to ``state[1]`` (the central compartment).
    Use for true IV bolus models where absorption is instantaneous.
    """
    new = state.copy()
    new[1] += amount
    return new


def bolus_to_compartment(compartment: int) -> Callable:
    """
    Factory: returns an applicator that adds the dose to ``state[compartment]``.

    Example::

        applicator = bolus_to_compartment(2)  # dose goes to state[2]
    """
    def _apply(state: np.ndarray, amount: float, params: Any) -> np.ndarray:
        new = state.copy()
        new[compartment] += amount
        return new
    _apply.__name__ = f"bolus_to_compartment_{compartment}"
    return _apply


def reset_compartment(compartment: int) -> Callable:
    """
    Factory: returns an applicator that *sets* ``state[compartment]`` to the
    dose amount (instead of adding to it).  Useful when an external
    variable is reloaded to a fixed concentration.
    """
    def _apply(state: np.ndarray, amount: float, params: Any) -> np.ndarray:
        new = state.copy()
        new[compartment] = amount
        return new
    _apply.__name__ = f"reset_compartment_{compartment}"
    return _apply


def infusion_rhs_wrapper(base_rhs: Callable,
                         infusion_compartment: int = 1) -> Callable:
    """
    Wraps a base RHS function to add a time-varying infusion rate into
    ``state[infusion_compartment]``.

    The infusion rate is passed via the *params* sequence as its **last**
    element.  This keeps the wrapper compatible with any existing RHS.

    Example::

        def my_rhs(t, x, params):
            Ka, V, CL = params[:3]
            ...

        infusion_rhs = infusion_rhs_wrapper(my_rhs, infusion_compartment=1)

        # params to pass: [...base params..., current_infusion_rate]
    """
    def _rhs(t: float, x: np.ndarray, params: Any) -> np.ndarray:
        rate = float(params[-1])
        dxdt = np.array(base_rhs(t, x, params[:-1]), dtype=float)
        dxdt[infusion_compartment] += rate
        return dxdt
    _rhs.__name__ = f"infusion_wrapped_{getattr(base_rhs, '__name__', 'rhs')}"
    return _rhs


# ══════════════════════════════════════════════════════════════════════════════
# Main solver
# ══════════════════════════════════════════════════════════════════════════════

class MultiDoseODESolver:
    """
    Integrate an arbitrary ODE system piecewise over multiple dosing events.

    Parameters
    ----------
    rhs : callable
        Right-hand side with signature ``dxdt = rhs(t, x, params)``.
        *x* is ``np.ndarray`` of length ``n_states``; return must be
        array_like of the same length.

    n_states : int
        Dimension of the state vector.

    ic : array_like, length n_states
        Default initial conditions at the start of the simulation (``t = 0``).

    dose_times : array_like
        Times at which dosing events occur.

    dose_amounts : array_like, same length as *dose_times*
        Amount of drug given at each event.

    dose_compartments : int or sequence of int, default ``0``
        State index that receives the drug at each event.
        A scalar applies the same compartment to every dose.

    dose_durations : float or sequence of float, default ``0.0``
        ``0``   → instantaneous bolus: ``state[cpt] += amount``
        ``> 0`` → zero-order infusion over this time span:
                  ``dxdt[cpt] += amount / duration``  while active.
        A scalar applies the same duration to every dose.

    set_events : sequence of (time, compartment, value), optional
        At each specified time, force ``state[compartment] = value``
        before proceeding with the next integration segment.
        Example: ``set_events = [(10.0, 2, 0.0)]`` zeros out state[2] at t=10.

    method : str
        scipy solver method: ``"RK45"`` (default, non-stiff) or ``"Radau"``
        (stiff).  Any method accepted by ``solve_ivp`` is valid.

    rtol, atol : float
        Relative and absolute tolerances for the ODE solver.

    Notes
    -----
    * Dose events at ``t == 0`` modify the IC **before** any integration.
    * At each dose transition ``t > 0``:

      - Observations **at exactly that time** return the **pre-dose** state.
      - The IC for the next segment carries the dose.

    * Overlapping infusions into the same compartment are handled correctly
      (rates are summed).
    * Multiple events at the same time are applied in insertion order.
    """

    def __init__(self,
                 rhs: Callable,
                 n_states: int,
                 ic: Sequence[float],
                 dose_times: Sequence[float],
                 dose_amounts: Sequence[float],
                 dose_compartments: Union[int, Sequence[int]] = 0,
                 dose_durations: Union[float, Sequence[float]] = 0.0,
                 set_events: Optional[Sequence[Tuple]] = None,
                 method: str = "RK45",
                 rtol: float = 1e-6,
                 atol: float = 1e-9) -> None:

        self.rhs        = rhs
        self.n_states   = n_states
        self.default_ic = np.array(ic, dtype=float)
        self.method     = method
        self.rtol       = rtol
        self.atol       = atol

        n_doses = len(dose_times)
        if len(dose_amounts) != n_doses:
            raise ValueError("dose_times and dose_amounts must be the same length.")

        # Normalise scalars → per-dose lists
        if isinstance(dose_compartments, (int, np.integer)):
            _comps: List[int] = [int(dose_compartments)] * n_doses
        else:
            _comps = [int(c) for c in dose_compartments]
            if len(_comps) != n_doses:
                raise ValueError("dose_compartments length must match dose_times.")

        if isinstance(dose_durations, (int, float, np.floating)):
            _durs: List[float] = [float(dose_durations)] * n_doses
        else:
            _durs = [float(d) for d in dose_durations]
            if len(_durs) != n_doses:
                raise ValueError("dose_durations length must match dose_times.")

        # Validate compartment indices
        for cpt in _comps:
            if not (0 <= cpt < n_states):
                raise ValueError(
                    f"dose_compartment {cpt} is out of range [0, {n_states-1}].")
        for dur in _durs:
            if dur < 0:
                raise ValueError("dose_durations must be >= 0.")

        # Sort by dose time
        order = list(np.argsort(dose_times, kind="stable"))
        self._dose_times   = np.array(dose_times,   dtype=float)[order]
        self._dose_amounts = np.array(dose_amounts, dtype=float)[order]
        self._dose_comps   = [_comps[i] for i in order]
        self._dose_durs    = [_durs[i]  for i in order]

        # Set events: list of (time, compartment, value)
        self._set_events: List[Tuple[float, int, float]] = []
        for ev in (set_events or []):
            if len(ev) != 3:
                raise ValueError(
                    "Each set_event must be a 3-tuple (time, compartment, value).")
            t_ev, cpt_ev, val_ev = float(ev[0]), int(ev[1]), float(ev[2])
            if not (0 <= cpt_ev < n_states):
                raise ValueError(
                    f"set_event compartment {cpt_ev} is out of range "
                    f"[0, {n_states-1}].")
            self._set_events.append((t_ev, cpt_ev, val_ev))

    # ──────────────────────────────────────────────────────────────────────
    def solve(self,
              obs_times: Sequence[float],
              params: Any = (),
              ic: Optional[Sequence[float]] = None) -> ODESolution:
        """
        Integrate and return state values at every requested observation time.

        Parameters
        ----------
        obs_times : sequence of float
            Absolute observation times (unsorted is fine; order is preserved
            in the returned ``ODESolution.y`` columns).

        params : any
            Passed as the third argument to *rhs* on every call.

        ic : array_like of length n_states, optional
            Override the default initial conditions for this call only.

        Returns
        -------
        ODESolution
            ``.t``        — observation times as supplied, shape (n_obs,)
            ``.y``        — state matrix, shape (n_states, n_obs)
            ``.success``  — False if any integration segment failed
            ``.messages`` — list of solver messages on failure
        """
        obs_arr  = np.array(obs_times, dtype=float)
        sort_idx = np.argsort(obs_arr, kind="stable")
        obs_sorted = obs_arr[sort_idx]

        n_obs = len(obs_sorted)
        y_out = np.full((self.n_states, n_obs), np.nan)
        messages: List[str] = []
        overall_success = True

        # Per-call IC override
        current_ic: np.ndarray = (np.array(ic, dtype=float) if ic is not None
                                  else self.default_ic.copy())

        if n_obs == 0:
            return ODESolution(t=obs_arr, y=y_out, success=True)

        t_last_obs = float(obs_sorted[-1])

        # ── Build event timeline ───────────────────────────────────────────
        # Four internal event types (all keyed by absolute time):
        #   'bolus'     : state[cpt] += amount
        #   'inf_start' : add constant rate to dxdt[cpt]
        #   'inf_end'   : remove that rate from dxdt[cpt]
        #   'set'       : state[cpt] = value
        events_at: Dict[float, List[Tuple]] = defaultdict(list)

        for t_d, amt, cpt, dur in zip(self._dose_times, self._dose_amounts,
                                       self._dose_comps, self._dose_durs):
            t_d = float(t_d)
            if dur == 0.0:
                events_at[t_d].append(('bolus', cpt, float(amt)))
            else:
                rate = float(amt) / float(dur)
                events_at[t_d].append(('inf_start', cpt, rate))
                events_at[t_d + dur].append(('inf_end', cpt, rate))

        for t_ev, cpt_ev, val_ev in self._set_events:
            events_at[float(t_ev)].append(('set', cpt_ev, float(val_ev)))

        # ── Build sorted breakpoints ──────────────────────────────────────
        # Add a sentinel one step beyond the last observation to ensure the
        # main loop always covers it without special-casing.
        sentinel = max((max(events_at.keys()) if events_at else 0.0),
                       t_last_obs) + 1e-10
        all_bp = sorted(set([0.0] + list(events_at.keys()) + [sentinel]))

        # ── Active infusion state (per-compartment cumulative rate) ───────
        active_inf: Dict[int, float] = defaultdict(float)

        # ── Helper: apply all events registered at time t_val ─────────────
        def _apply(t_val: float) -> None:
            nonlocal current_ic
            for etype, cpt, val in events_at.get(t_val, []):
                if etype == 'bolus':
                    current_ic = current_ic.copy()
                    current_ic[cpt] += val
                elif etype == 'set':
                    current_ic = current_ic.copy()
                    current_ic[cpt] = val
                elif etype == 'inf_start':
                    active_inf[cpt] += val
                elif etype == 'inf_end':
                    active_inf[cpt] -= val
                    if abs(active_inf[cpt]) < 1e-15:
                        del active_inf[cpt]

        # ── t=0 events modify the IC before any integration ───────────────
        _apply(0.0)

        # Fill observations at t=0 with the (post-dose) IC
        for oi in range(n_obs):
            if obs_sorted[oi] <= 0.0:
                y_out[:, oi] = current_ic

        # ── Integrate segment by segment ──────────────────────────────────
        for seg_start, seg_end in zip(all_bp[:-1], all_bp[1:]):
            if seg_end - seg_start < 1e-14:
                continue

            # Observations strictly inside (seg_start, seg_end]
            in_seg = (obs_sorted > seg_start) & (obs_sorted <= seg_end)
            obs_in_seg_idx = np.where(in_seg)[0]

            # Explicit t_eval for dense output at requested times
            t_req = obs_sorted[in_seg]
            # Only keep times that are real observations
            t_req_real = t_req[t_req <= t_last_obs + 1e-11]
            t_eval = t_req_real if len(t_req_real) > 0 else None

            # Per-segment constant forcing from active infusions
            _forcing = np.zeros(self.n_states)
            for cpt, rate in active_inf.items():
                _forcing[cpt] += rate

            # Capture loop variables for the closure
            _f = _forcing.copy()
            _p = params

            def _rhs(t, x, __f=_f, __p=_p):  # noqa: E741
                return np.asarray(self.rhs(t, x, __p), dtype=float) + __f

            _ic = current_ic.copy()
            sol = solve_ivp(
                _rhs,
                [seg_start, seg_end],
                _ic,
                method       = self.method,
                t_eval       = t_eval,
                rtol         = self.rtol,
                atol         = self.atol,
                dense_output = True,
            )

            if not sol.success:
                overall_success = False
                messages.append(
                    f"[{seg_start:.4g}, {seg_end:.4g}]: {sol.message}")

            # Record observations for this segment
            for oi in obs_in_seg_idx:
                t_req_i = obs_sorted[oi]
                if t_req_i > t_last_obs:
                    continue
                if sol.success and sol.sol is not None:
                    y_out[:, oi] = sol.sol(t_req_i)
                elif len(sol.t) > 0:
                    y_out[:, oi] = np.array([
                        np.interp(t_req_i, sol.t, sol.y[k])
                        for k in range(self.n_states)
                    ])

            # Carry terminal state forward
            if sol.success and sol.sol is not None:
                current_ic = np.asarray(sol.sol(seg_end), dtype=float)
            elif len(sol.t) > 0:
                current_ic = sol.y[:, -1].copy()

            # Apply events at seg_end → these take effect at the start of
            # the NEXT segment (transitions happen at breakpoint boundaries)
            _apply(seg_end)

        # Restore caller's original (possibly unsorted) order
        y_final = np.full((self.n_states, len(obs_arr)), np.nan)
        y_final[:, sort_idx] = y_out

        return ODESolution(
            t        = obs_arr,
            y        = y_final,
            success  = overall_success,
            messages = messages,
        )

    # ──────────────────────────────────────────────────────────────────────
    def update_doses(self,
                     dose_times: Sequence[float],
                     dose_amounts: Sequence[float],
                     dose_compartments: Optional[Union[int, Sequence[int]]] = None,
                     dose_durations: Optional[Union[float, Sequence[float]]] = None,
                     set_events: Optional[Sequence[Tuple]] = None,
                     ) -> None:
        """
        Replace the dosing schedule in-place.

        Parameters
        ----------
        dose_times, dose_amounts
            Required; same semantics as the constructor.
        dose_compartments
            If ``None``, reuse the first existing compartment for all new doses.
        dose_durations
            If ``None``, default to instantaneous bolus (0.0) for all doses.
        set_events
            If ``None``, the existing set-events list is unchanged.
        """
        n_doses = len(dose_times)
        if len(dose_amounts) != n_doses:
            raise ValueError("dose_times and dose_amounts must be the same length.")

        if dose_compartments is None:
            _comps: List[int] = [self._dose_comps[0] if self._dose_comps else 0] * n_doses
        elif isinstance(dose_compartments, (int, np.integer)):
            _comps = [int(dose_compartments)] * n_doses
        else:
            _comps = [int(c) for c in dose_compartments]

        if dose_durations is None:
            _durs: List[float] = [0.0] * n_doses
        elif isinstance(dose_durations, (int, float, np.floating)):
            _durs = [float(dose_durations)] * n_doses
        else:
            _durs = [float(d) for d in dose_durations]

        order = list(np.argsort(dose_times, kind="stable"))
        self._dose_times   = np.array(dose_times,   dtype=float)[order]
        self._dose_amounts = np.array(dose_amounts, dtype=float)[order]
        self._dose_comps   = [_comps[i] for i in order]
        self._dose_durs    = [_durs[i]  for i in order]

        if set_events is not None:
            self._set_events = [(float(e[0]), int(e[1]), float(e[2]))
                                for e in set_events]

    def add_set_event(self, time: float, compartment: int,
                      value: float) -> None:
        """Append a single set-value event without rebuilding everything."""
        if not (0 <= compartment < self.n_states):
            raise ValueError(
                f"compartment {compartment} out of range [0, {self.n_states-1}].")
        self._set_events.append((float(time), compartment, float(value)))

    def clear_set_events(self) -> None:
        """Remove all set-value events."""
        self._set_events = []


# ══════════════════════════════════════════════════════════════════════════════
# Convenience factory
# ══════════════════════════════════════════════════════════════════════════════

def make_pk_solver(rhs: Callable,
                   n_states: int,
                   ic: Sequence[float],
                   dose_times: Sequence[float],
                   dose_amounts: Sequence[float],
                   dose_compartments: Union[int, Sequence[int]] = 0,
                   dose_durations: Union[float, Sequence[float]] = 0.0,
                   set_events: Optional[Sequence[Tuple]] = None,
                   method: str = "RK45",
                   rtol: float = 1e-6,
                   atol: float = 1e-9) -> MultiDoseODESolver:
    """
    Thin convenience wrapper around :class:`MultiDoseODESolver`.

    Parameters
    ----------
    dose_compartments : int or sequence of int, default ``0``
        Which state index receives each dose.
        Common conventions:

        * ``0`` — gut/depot compartment (oral / SC / IM)
        * ``1`` — central compartment  (IV bolus)
        * Any other index — arbitrary target compartment

    dose_durations : float or sequence of float, default ``0.0``
        Duration per dose.  ``0`` = bolus; ``> 0`` = infusion.

    set_events : sequence of (time, compartment, value), optional
        Force ``state[compartment] = value`` at the given times.

    All other parameters are forwarded to :class:`MultiDoseODESolver`.

    Examples
    --------
    Oral bolus every 12 h::

        solver = make_pk_solver(rhs, 2, [0,0],
                                dose_times=[0,12,24],
                                dose_amounts=[100,100,100],
                                dose_compartments=0)

    IV bolus followed by a 2-h infusion at t=24::

        solver = make_pk_solver(rhs, 2, [0,0],
                                dose_times=[0,   24],
                                dose_amounts=[100, 200],
                                dose_compartments=[1, 1],
                                dose_durations=[0,  2.0])
    """
    return MultiDoseODESolver(
        rhs               = rhs,
        n_states          = n_states,
        ic                = ic,
        dose_times        = dose_times,
        dose_amounts      = dose_amounts,
        dose_compartments = dose_compartments,
        dose_durations    = dose_durations,
        set_events        = set_events,
        method            = method,
        rtol              = rtol,
        atol              = atol,
    )
