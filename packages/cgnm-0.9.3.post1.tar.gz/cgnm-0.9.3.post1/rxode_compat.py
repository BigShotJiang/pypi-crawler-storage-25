"""
rxode_compat.py
===============
Helpers for translating rxODE (R) ODE models to Python MultiDoseODESolver.

Provides
--------
* :func:`parse_rxode`    – parse an rxODE ODE-text string → :class:`ParsedModel`
* :class:`EventTable`    – mirrors rxODE/rxode2 ``eventTable()`` / ``et()`` API
* :func:`et`             – shorthand constructor (mirrors rxode2 ``et()``)
* :func:`rxode_solve`    – one-call solve returning a pandas DataFrame
* :func:`show_rhs`       – pretty-print the generated Python RHS for debugging

Typical usage
-------------
::

    from rxode_compat import parse_rxode, EventTable, rxode_solve

    model = parse_rxode(\"\"\"
        d/dt(A_gut) = -Ka*A_gut
        d/dt(C)     =  Ka*A_gut/V - (CL/V)*C
    \"\"\")

    ev = EventTable()
    ev.add_dosing(dose=1000, nbr_doses=1, dosing_to=1)
    ev.add_sampling([0.5, 1, 2, 4, 8, 12, 24])

    result = rxode_solve(model, params={"Ka": 1.2, "V": 20, "CL": 3}, events=ev)
    print(result)   # pandas DataFrame: columns = time, A_gut, C

Equivalent R / rxODE code
--------------------------
::

    library(rxode2)
    ode <- RxODE("
        d/dt(A_gut) = -Ka*A_gut
        d/dt(C)     =  Ka*A_gut/V - (CL/V)*C
    ")
    ev  <- et(amt=1000, cmt=1) |> add.sampling(c(0.5,1,2,4,8,12,24))
    rxSolve(ode, list(Ka=1.2, V=20, CL=3), ev)

Conversion reference
--------------------
.. code-block:: text

    rxODE (R)                           Python (rxode_compat)
    ─────────────────────────────────── ─────────────────────────────────────────
    RxODE("d/dt(…) = expr")             parse_rxode("d/dt(…) = expr")
    rxSolve(mod, params, ev)            rxode_solve(model, params, ev)
    et(amt=…, cmt=N)                    et(amt=…, cmt=N)   (or EventTable())
    add.dosing(dose, nbr.doses, ii)     .add_dosing(dose, nbr_doses, dosing_interval)
    add.sampling(times)                 .add_sampling(times)
    dosing.to=N  (1-indexed)            dosing_to=N  (1-indexed, converted internally)
    rate=R  (infusion)                  rate=R  (duration = dose/rate)
    evid=2  (reset + dose)              evid=2  (set_event to 0 then dose)
    evid=3  (reset only)                evid=3  (set_event to 0, no dose)
    rxSolve(…)$stateName                result["stateName"]
    ^  (exponentiation)                 **  (auto-converted)
    exp(), log(), sqrt() …              np.exp(), np.log(), np.sqrt() … (auto-converted)
"""

from __future__ import annotations

import keyword
import re
from dataclasses import dataclass, field
from typing import (
    Any, Callable, Dict, List, Optional, Sequence, Tuple, Union,
)

import numpy as np
import pandas as pd

# Import from companion module
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ode_solver import MultiDoseODESolver, ODESolution  # noqa: E402


# ─────────────────────────────────────────────────────────────────────────────
# R → Python expression conversion
# ─────────────────────────────────────────────────────────────────────────────

# Mapping of R function/constant names → Python/NumPy equivalents
_R_FN_MAP: Dict[str, str] = {
    "exp":     "np.exp",
    "log":     "np.log",
    "log10":   "np.log10",
    "log2":    "np.log2",
    "sqrt":    "np.sqrt",
    "abs":     "abs",
    "sin":     "np.sin",
    "cos":     "np.cos",
    "tan":     "np.tan",
    "asin":    "np.arcsin",
    "acos":    "np.arccos",
    "atan":    "np.arctan",
    "atan2":   "np.arctan2",
    "ceiling": "np.ceil",
    "floor":   "np.floor",
    "round":   "round",
    "max":     "max",
    "min":     "min",
    "TRUE":    "True",
    "FALSE":   "False",
    "pi":      "np.pi",
    "Inf":     "np.inf",
    "NaN":     "np.nan",
    "NA":      "np.nan",
}

# Pre-compute sorted keys (longest first) to avoid partial replacements
_R_FN_KEYS_SORTED = sorted(_R_FN_MAP.keys(), key=len, reverse=True)


def _r_to_python_expr(expr: str) -> str:
    """
    Convert a scalar R arithmetic expression to equivalent Python.

    Transformations applied
    -----------------------
    * ``^`` → ``**``
    * R math function names → NumPy equivalents (``exp`` → ``np.exp``, etc.)
    * Boolean / special literals (``TRUE``, ``FALSE``, ``Inf``, ``NaN``, ``NA``, ``pi``)

    Parameters
    ----------
    expr : str

    Returns
    -------
    str
        Python-compatible expression string.
    """
    # Exponentiation
    expr = expr.replace("^", "**")
    # Replace R function/constant names (word-boundary match to avoid partial hits)
    for r_name in _R_FN_KEYS_SORTED:
        py_name = _R_FN_MAP[r_name]
        expr = re.sub(rf"\b{re.escape(r_name)}\b", py_name, expr)
    return expr


# ─────────────────────────────────────────────────────────────────────────────
# ODE text parser
# ─────────────────────────────────────────────────────────────────────────────

# Matches: d/dt(varname) = expression
_DT_RE  = re.compile(r"d/dt\s*\(\s*(\w+)\s*\)\s*=\s*(.+)", re.IGNORECASE)
# Matches: varname = expression  (algebraic / intermediate)
_LHS_RE = re.compile(r"^(\w+)\s*=\s*(.+)")
# Finds all Python identifiers in an expression
_IDENT  = re.compile(r"\b([A-Za-z_]\w*)\b")

# Identifiers that are definitely NOT user parameters
_BUILTINS: set = (
    {"t", "True", "False", "None", "np", "abs", "round", "max", "min",
     "int", "float", "str", "len", "range", "enumerate", "zip"}
    | set(_R_FN_MAP.keys())
    | {v.split(".")[-1] for v in _R_FN_MAP.values()}
)


@dataclass
class ParsedModel:
    """
    Container produced by :func:`parse_rxode`.

    Attributes
    ----------
    state_names : list of str
        State variable names in the order they appear in the ODE system.
        These correspond to row indices in ``ODESolution.y``.
    param_names : list of str
        Free parameter names (inferred or user-supplied).
    intermediate_names : list of str
        Algebraic (LHS) intermediate variable names (computed before ODEs).
    rhs : callable
        ``rhs(t, x, params)`` compatible with :class:`MultiDoseODESolver`.
        *params* may be:

        * a ``dict`` mapping name → value, OR
        * a sequence aligned with ``param_names``.
    ode_text : str
        Original ODE text stored for reference.
    """
    state_names:        List[str]
    param_names:        List[str]
    intermediate_names: List[str]
    rhs:                Callable
    ode_text:           str = field(repr=False)

    def __repr__(self) -> str:
        return (
            f"ParsedModel(\n"
            f"  states        = {self.state_names},\n"
            f"  params        = {self.param_names},\n"
            f"  intermediates = {self.intermediate_names}\n"
            f")"
        )


def parse_rxode(
    ode_text: str,
    param_names: Optional[List[str]] = None,
) -> ParsedModel:
    """
    Parse an rxODE-style ODE system string and return a :class:`ParsedModel`.

    Parameters
    ----------
    ode_text : str
        ODE system in rxODE / rxode2 format.

        Supported syntax::

            # ODE lines
            d/dt(A_gut) = -Ka*A_gut
            d/dt(C)     =  Ka*A_gut/V - (CL/V)*C

            # Algebraic (intermediate) lines — evaluated before ODEs
            Cp = C / V1
            d/dt(C1) = -Cp*CL

            # Comments (lines starting with #) and blank lines are ignored

        The following R→Python conversions are applied automatically:

        * ``^`` → ``**``
        * ``exp``, ``log``, ``sqrt``, ``sin``, ``cos``, … → ``np.*``
        * ``TRUE`` / ``FALSE`` → ``True`` / ``False``
        * ``pi``, ``Inf``, ``NaN``, ``NA``

    param_names : list of str, optional
        Explicit list of free parameter names.
        If omitted, parameters are **inferred** as any identifier appearing
        in the expressions that is not a state variable, an intermediate
        variable, the time variable ``t``, or a known math symbol.
        Specify explicitly when auto-detection is ambiguous.

    Returns
    -------
    ParsedModel

    Examples
    --------
    ::

        model = parse_rxode(\"\"\"
            d/dt(A_gut) = -Ka*A_gut
            d/dt(C)     =  Ka*A_gut/V - (CL/V)*C
        \"\"\")
        # model.state_names  → ['A_gut', 'C']
        # model.param_names  → ['CL', 'Ka', 'V']   (sorted)

        # Call the generated RHS directly (for debugging):
        print(model.rhs(0.0, [1000.0, 0.0], {"Ka": 1.2, "V": 20, "CL": 3}))

    Equivalent R::

        RxODE("
            d/dt(A_gut) = -Ka*A_gut
            d/dt(C)     =  Ka*A_gut/V - (CL/V)*C
        ")
    """
    state_names:     List[str] = []
    ode_exprs_raw:   List[str] = []
    inter_names:     List[str] = []
    inter_exprs_raw: List[str] = []

    for raw_line in ode_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue

        m_dt = _DT_RE.match(line)
        if m_dt:
            state_names.append(m_dt.group(1))
            ode_exprs_raw.append(m_dt.group(2).strip())
            continue

        m_lhs = _LHS_RE.match(line)
        if m_lhs:
            inter_names.append(m_lhs.group(1))
            inter_exprs_raw.append(m_lhs.group(2).strip())
            continue
        # Unrecognised lines (e.g. multi-line comments) are silently skipped.

    if not state_names:
        raise ValueError(
            "No d/dt(...) = ... equations found in ode_text.\n"
            "Each ODE line must have the form:  d/dt(name) = expression"
        )

    # Convert R expressions to Python
    ode_exprs   = [_r_to_python_expr(e) for e in ode_exprs_raw]
    inter_exprs = [_r_to_python_expr(e) for e in inter_exprs_raw]

    # Infer free parameter names if not supplied
    all_reserved = (
        set(state_names) | set(inter_names) | _BUILTINS | {"np"}
        | {str(i) for i in range(100)}
    )
    if param_names is None:
        all_identifiers: set = set()
        for expr in ode_exprs + inter_exprs:
            all_identifiers |= set(_IDENT.findall(expr))
        param_names = sorted(
            ident for ident in all_identifiers
            if ident not in all_reserved and not keyword.iskeyword(ident)
        )

    # -------------------------------------------------------------------------
    # Generate the RHS function as a source-code string, then exec() it.
    # This keeps the function readable / debuggable (see show_rhs()).
    # -------------------------------------------------------------------------
    fn_lines: List[str] = [
        "def _generated_rhs(t, x, params):",
        "    # Accept params as dict or positional sequence",
        "    if not isinstance(params, dict):",
        f"        p = dict(zip({param_names!r}, params))",
        "    else:",
        "        p = params",
        "    # State variable aliases",
    ]
    for i, sn in enumerate(state_names):
        fn_lines.append(f"    {sn} = x[{i}]")
    fn_lines.append("    # Parameter aliases")
    for pn in param_names:
        fn_lines.append(f"    {pn} = p[{pn!r}]")
    if inter_names:
        fn_lines.append("    # Algebraic intermediate variables (evaluated in order)")
        for name, expr in zip(inter_names, inter_exprs):
            fn_lines.append(f"    {name} = {expr}")
    fn_lines.append("    # Differential equations")
    fn_lines.append("    return [")
    for expr in ode_exprs:
        fn_lines.append(f"        {expr},")
    fn_lines.append("    ]")

    fn_code = "\n".join(fn_lines)
    _ns: Dict = {"np": np}
    try:
        exec(fn_code, _ns)  # noqa: S102
    except SyntaxError as exc:
        raise SyntaxError(
            f"Failed to compile generated RHS.\n"
            f"Generated source:\n{fn_code}\n\nOriginal error: {exc}"
        ) from exc

    rhs_fn = _ns["_generated_rhs"]
    rhs_fn.__source__ = fn_code  # attach source for show_rhs()

    return ParsedModel(
        state_names=state_names,
        param_names=param_names,
        intermediate_names=inter_names,
        rhs=rhs_fn,
        ode_text=ode_text,
    )


# ─────────────────────────────────────────────────────────────────────────────
# EventTable
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class _DoseRecord:
    time:        float
    amount:      float
    compartment: int    # 0-indexed
    duration:    float  # 0 = bolus; >0 = zero-order infusion
    evid:        int    # 1 = dose, 2 = reset+dose, 3 = reset only


class EventTable:
    """
    Dosing and sampling schedule — mirrors the rxODE / rxode2 API.

    Correspondence with rxODE
    -------------------------
    .. code-block:: text

        R (rxode2)                              Python
        ─────────────────────────────────────── ────────────────────────────────────────
        eventTable()                            EventTable()
        et(amt=100, cmt=1)                      et(amt=100, cmt=1)
        add.dosing(dose, nbr.doses, ii,         .add_dosing(dose, nbr_doses,
                   dosing.to, rate, start.time)            dosing_interval, dosing_to,
                                                           rate, start_time)
        add.sampling(times)                     .add_sampling(times)
        dosing.to = N  (1-indexed)              dosing_to = N  (converted to 0-indexed)
        rate = R                                rate = R   (duration = dose/rate)
        evid = 2  (reset + dose)                evid = 2
        evid = 3  (reset only)                  evid = 3

    Example
    -------
    ::

        ev = EventTable()
        ev.add_dosing(dose=100, nbr_doses=3, dosing_interval=12, dosing_to=1)
        ev.add_sampling(np.arange(0, 37, 2))

        # Chaining (same as rxode2 pipe syntax):
        ev = (EventTable()
              .add_dosing(dose=100, nbr_doses=3, dosing_interval=12, dosing_to=1)
              .add_sampling(np.arange(0, 37, 2)))
    """

    def __init__(self) -> None:
        self._doses:   List[_DoseRecord] = []
        self._samples: List[float]       = []

    # ------------------------------------------------------------------
    def add_dosing(
        self,
        dose:             float,
        nbr_doses:        int            = 1,
        dosing_interval:  Optional[float] = None,
        start_time:       float          = 0.0,
        dosing_to:        int            = 1,   # 1-indexed (rxODE convention)
        rate:             float          = 0.0,
        duration:         Optional[float] = None,
        evid:             int            = 1,
    ) -> "EventTable":
        """
        Add one or more dosing events.

        Parameters
        ----------
        dose : float
            Amount per dose.
        nbr_doses : int
            Number of doses (default 1).
        dosing_interval : float, optional
            Time between successive doses.  Required when ``nbr_doses > 1``.
        start_time : float
            Time of the first dose (default 0).
        dosing_to : int
            Compartment number **1-indexed** (rxODE convention).
            Internally converted to 0-indexed.
        rate : float
            Infusion rate (amount/time).  Duration = ``dose / rate``.
        duration : float, optional
            Explicit infusion duration (overrides ``rate``).
            ``0`` or ``None`` → instantaneous bolus.
        evid : int
            | 1 – normal dose (default)
            | 2 – reset compartment to 0, then apply dose
            | 3 – reset compartment to 0 only (``dose`` is ignored)

        Returns
        -------
        self — supports method chaining.

        Examples
        --------
        ::

            # Oral bolus every 12 h for 5 doses
            ev.add_dosing(dose=500, nbr_doses=5, dosing_interval=12, dosing_to=1)

            # 30-min IV infusion (total 200 mg, rate = 400 mg/h)
            ev.add_dosing(dose=200, dosing_to=2, rate=400)

        Equivalent R::

            add.dosing(dose=500, nbr.doses=5, dosing.interval=12, dosing.to=1)
            add.dosing(dose=200, dosing.to=2, rate=400)
        """
        if nbr_doses > 1 and dosing_interval is None:
            raise ValueError("dosing_interval is required when nbr_doses > 1.")

        cpt_0 = int(dosing_to) - 1   # rxODE 1-indexing → 0-indexing

        if duration is not None:
            dur = float(duration)
        elif rate > 0:
            dur = float(dose) / float(rate)
        else:
            dur = 0.0

        tau = float(dosing_interval) if dosing_interval is not None else 0.0
        for i in range(nbr_doses):
            self._doses.append(_DoseRecord(
                time=float(start_time) + i * tau,
                amount=float(dose),
                compartment=cpt_0,
                duration=dur,
                evid=int(evid),
            ))
        return self

    # ------------------------------------------------------------------
    def add_sampling(
        self,
        times: Union[Sequence[float], np.ndarray],
    ) -> "EventTable":
        """
        Add observation times.

        Parameters
        ----------
        times : array-like of float
            Absolute observation times.

        Returns
        -------
        self — supports method chaining.

        Examples
        --------
        ::

            ev.add_sampling([0.5, 1, 2, 4, 8, 12, 24])
            ev.add_sampling(np.arange(0, 25, 0.5))

        Equivalent R::

            add.sampling(c(0.5, 1, 2, 4, 8, 12, 24))
            add.sampling(seq(0, 24, by=0.5))
        """
        for t in times:
            self._samples.append(float(t))
        return self

    # ------------------------------------------------------------------
    def to_solver_args(self) -> Dict:
        """
        Convert to constructor/solve keyword-argument dicts for
        :class:`MultiDoseODESolver`.

        Returns
        -------
        dict with keys:
            ``dose_times``, ``dose_amounts``, ``dose_compartments``,
            ``dose_durations``, ``set_events``, ``obs_times``
        """
        dose_times:   List[float]                    = []
        dose_amounts: List[float]                    = []
        dose_comps:   List[int]                      = []
        dose_durs:    List[float]                    = []
        set_events:   List[Tuple[float, int, float]] = []

        for rec in self._doses:
            if rec.evid == 3:
                # State reset only — no drug input
                set_events.append((rec.time, rec.compartment, 0.0))
            elif rec.evid == 2:
                # Reset to 0, then dose (evid=2 in rxODE)
                set_events.append((rec.time, rec.compartment, 0.0))
                dose_times.append(rec.time)
                dose_amounts.append(rec.amount)
                dose_comps.append(rec.compartment)
                dose_durs.append(rec.duration)
            else:
                # evid == 1: normal dose
                dose_times.append(rec.time)
                dose_amounts.append(rec.amount)
                dose_comps.append(rec.compartment)
                dose_durs.append(rec.duration)

        return dict(
            dose_times=dose_times,
            dose_amounts=dose_amounts,
            dose_compartments=dose_comps,
            dose_durations=dose_durs,
            set_events=set_events if set_events else None,
            obs_times=sorted(set(self._samples)),
        )

    def get_sampling_times(self) -> List[float]:
        """Return sorted unique observation times."""
        return sorted(set(self._samples))

    def __repr__(self) -> str:
        return (
            f"EventTable(n_doses={len(self._doses)}, "
            f"n_sample_times={len(set(self._samples))})"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Convenience constructor (mirrors rxode2 et())
# ─────────────────────────────────────────────────────────────────────────────

def et(
    amt:      Optional[float] = None,
    cmt:      int             = 1,
    **kwargs,
) -> EventTable:
    """
    Create an :class:`EventTable`, optionally adding a first dose.

    Mirrors the rxode2 ``et()`` shorthand.

    Parameters
    ----------
    amt : float, optional
        If given, calls ``add_dosing(dose=amt, dosing_to=cmt, **kwargs)``.
    cmt : int
        Compartment number 1-indexed (default 1).
    **kwargs
        Passed to :meth:`EventTable.add_dosing` (e.g. ``nbr_doses``,
        ``dosing_interval``, ``rate``).

    Returns
    -------
    EventTable

    Examples
    --------
    ::

        # Single oral dose into compartment 1
        ev = et(amt=1000, cmt=1)

        # Then chain additional calls
        ev.add_sampling([0.5, 1, 2, 4, 8, 12, 24])

    Equivalent R::

        et(amt=1000, cmt=1)
    """
    ev = EventTable()
    if amt is not None:
        ev.add_dosing(dose=amt, dosing_to=cmt, **kwargs)
    return ev


# ─────────────────────────────────────────────────────────────────────────────
# One-call solver
# ─────────────────────────────────────────────────────────────────────────────

def rxode_solve(
    model:   ParsedModel,
    params:  Union[Dict[str, float], Sequence[float]],
    events:  EventTable,
    method:  str            = "RK45",
    rtol:    float          = 1e-6,
    atol:    float          = 1e-9,
    ic:      Optional[Sequence[float]] = None,
) -> pd.DataFrame:
    """
    Solve a parsed rxODE model and return a tidy DataFrame.

    Parameters
    ----------
    model : ParsedModel
        Output of :func:`parse_rxode`.
    params : dict or sequence
        Parameter values.  A ``dict`` keyed by parameter name is preferred.
        A sequence is accepted when aligned with ``model.param_names``.
    events : EventTable
        Dosing and sampling schedule built with :class:`EventTable` / :func:`et`.
    method : str
        Solver method: ``"RK45"`` (non-stiff, default) or ``"Radau"`` (stiff).
    rtol, atol : float
        Relative and absolute solver tolerances.
    ic : array-like, optional
        Initial conditions, length ``len(model.state_names)``.
        Defaults to **all zeros** (typical PK: everything empty at t=0).

    Returns
    -------
    pandas.DataFrame
        Columns: ``time`` followed by one column per state variable.

    Examples
    --------
    ::

        result = rxode_solve(model, {"Ka":1.2, "V":20, "CL":3}, ev)
        print(result[["time", "C"]])

    Equivalent R::

        rxSolve(model, list(Ka=1.2, V=20, CL=3), ev)
    """
    args       = events.to_solver_args()
    obs_times  = args.pop("obs_times")

    if not obs_times:
        raise ValueError(
            "EventTable has no sampling times. "
            "Call .add_sampling(times) before rxode_solve()."
        )

    n_states   = len(model.state_names)
    default_ic = [0.0] * n_states if ic is None else list(ic)

    solver = MultiDoseODESolver(
        rhs               = model.rhs,
        n_states          = n_states,
        ic                = default_ic,
        dose_times        = args["dose_times"],
        dose_amounts      = args["dose_amounts"],
        dose_compartments = args["dose_compartments"],
        dose_durations    = args["dose_durations"],
        set_events        = args["set_events"],
        method            = method,
        rtol              = rtol,
        atol              = atol,
    )

    sol = solver.solve(obs_times, params=params)

    data: Dict = {"time": sol.t}
    for i, name in enumerate(model.state_names):
        data[name] = sol.y[i]

    return pd.DataFrame(data)


# ─────────────────────────────────────────────────────────────────────────────
# Debugging helper
# ─────────────────────────────────────────────────────────────────────────────

def show_rhs(model: ParsedModel) -> None:
    """
    Print the auto-generated Python RHS function source code.

    Useful for verifying the translation from rxODE syntax, and for
    understanding the state/parameter indexing.

    Example
    -------
    ::

        model = parse_rxode("d/dt(C) = -(CL/V)*C")
        show_rhs(model)
        # def _generated_rhs(t, x, params):
        #     ...
    """
    src = getattr(model.rhs, "__source__", None)
    if src:
        print(src)
    else:
        print(repr(model.rhs))
