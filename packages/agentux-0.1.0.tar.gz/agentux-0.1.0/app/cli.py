from __future__ import annotations

import argparse
import getpass
import os
import subprocess
import sys
from pathlib import Path

import yaml

from app.engine.project_profile import infer_project_profile, write_project_profile


def _workspace() -> Path:
    return Path.cwd().resolve()


def _parse_env_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    result: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def _write_env_file(path: Path, values: dict[str, str]) -> None:
    lines = [f"{k}={v}" for k, v in values.items()]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _prompt_for_openai_key(env_path: Path) -> None:
    # Avoid blocking in non-interactive flows (CI/tests/scripts).
    if not sys.stdin.isatty() or os.getenv("AGENTUX_NO_PROMPT") == "1":
        return

    existing = _parse_env_file(env_path)
    current = existing.get("OPENAI_API_KEY", "").strip()
    if current:
        print("OPENAI_API_KEY already configured in .agentux/.env (leaving unchanged).")
        return

    print("Set your OpenAI API key for AgentUX.")
    key = getpass.getpass("OPENAI_API_KEY (input hidden, press Enter to skip): ").strip()
    if not key:
        print("Skipped key setup. You can set it later in .agentux/.env.")
        return

    existing["OPENAI_API_KEY"] = key
    existing.setdefault("TARGET_BASE_URL", "http://localhost:3000")
    _write_env_file(env_path, existing)
    print("Saved OPENAI_API_KEY to .agentux/.env")


def _prompt_for_target_base_url(env_path: Path) -> None:
    if not sys.stdin.isatty() or os.getenv("AGENTUX_NO_PROMPT") == "1":
        return

    existing = _parse_env_file(env_path)
    current = existing.get("TARGET_BASE_URL", "").strip()
    if current:
        return

    raw = input("TARGET_BASE_URL [http://localhost:3000]: ").strip()
    target = raw or "http://localhost:3000"
    existing["TARGET_BASE_URL"] = target
    _write_env_file(env_path, existing)
    print("Saved TARGET_BASE_URL to .agentux/.env")


def _require_initialized(workspace: Path) -> tuple[bool, Path]:
    base = workspace / ".agentux"
    env_path = base / ".env"
    config_path = base / "config.yaml"
    scenario_path = base / "scenarios" / "default.yaml"
    missing = [
        str(p.relative_to(workspace))
        for p in (config_path, scenario_path, env_path)
        if not p.exists()
    ]
    if missing:
        print("AgentUX is not initialized for this project.")
        print("Run `agentux init` first. Missing files:")
        for item in missing:
            print(f"- {item}")
        return False, env_path
    return True, env_path


def _ensure_playwright_browser() -> int:
    cmd = [sys.executable, "-m", "playwright", "install", "chromium"]
    return subprocess.call(cmd)


def cmd_init(_: argparse.Namespace) -> int:
    workspace = _workspace()
    base = workspace / ".agentux"
    base.mkdir(parents=True, exist_ok=True)
    scenarios_dir = base / "scenarios"
    scenarios_dir.mkdir(parents=True, exist_ok=True)

    config_path = base / "config.yaml"
    env_example = base / ".env.example"
    env_path = base / ".env"
    scenario_path = scenarios_dir / "default.yaml"
    gitignore_path = workspace / ".gitignore"

    if not config_path.exists():
        config_path.write_text(
            """run:
  max_steps_per_agent: 30
  max_runtime_minutes: 12
  max_retries_per_step: 2
  screenshot_fps_cap: 1
  persona_count: 3
  max_consecutive_low_confidence: 3
  low_confidence_threshold: 0.45
models:
  vision_model: \"gpt-4o\"
  reasoning_model: \"gpt-4o-mini\"
paths:
  artifacts_root: \".agentux/artifacts\"
  scenario_file: \".agentux/scenarios/default.yaml\"
""",
            encoding="utf-8",
        )

    if not env_example.exists():
        env_example.write_text(
            """OPENAI_API_KEY=your_key_here
TARGET_BASE_URL=http://localhost:3000
""",
            encoding="utf-8",
        )

    profile = infer_project_profile(workspace)
    write_project_profile(base / "project_profile.json", profile)

    if not scenario_path.exists():
        scenario_payload = {
            "default_scenario": profile["primary_scenario"],
            "persona_overrides": {},
        }
        scenario_path.write_text(
            yaml.safe_dump(scenario_payload, sort_keys=False),
            encoding="utf-8",
        )

    if gitignore_path.exists():
        existing = gitignore_path.read_text(encoding="utf-8")
    else:
        existing = ""

    additions = [".agentux/artifacts/", ".agentux/.env", "credentials.json"]
    lines = existing.splitlines()
    changed = False
    for item in additions:
        if item not in lines:
            lines.append(item)
            changed = True
    if changed or not gitignore_path.exists():
        gitignore_path.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")

    print("Initialized AgentUX in .agentux/")
    print("Next: copy .agentux/.env.example to .agentux/.env and set values.")
    print(
        f"Inferred scenario '{profile['primary_scenario']['name']}' from project files "
        f"({profile['file_count_scanned']} scanned)."
    )
    _prompt_for_openai_key(env_path)
    _prompt_for_target_base_url(env_path)
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    workspace = _workspace()
    ok, _env_path = _require_initialized(workspace)
    if not ok:
        return 2
    if not args.skip_browser_install:
        rc = _ensure_playwright_browser()
        if rc != 0:
            return rc

    env = os.environ.copy()
    env["AGENTUX_WORKSPACE"] = str(workspace)
    env["AGENTUX_AUTO_START"] = "1" if args.auto else "0"

    app_path = Path(__file__).with_name("main.py")
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(app_path),
        "--server.port",
        str(args.port),
        "--server.address",
        "0.0.0.0",
    ]
    return subprocess.call(cmd, env=env)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentux",
        description="Portable AgentUX CLI",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    init_p = sub.add_parser("init", help="Initialize AgentUX config in current project")
    init_p.set_defaults(func=cmd_init)

    run_p = sub.add_parser("run", help="Run Streamlit cockpit against current project")
    run_p.add_argument("--port", type=int, default=8501, help="Port for dashboard")
    run_p.add_argument(
        "--no-auto",
        action="store_true",
        help="Disable automatic audit start on dashboard load.",
    )
    run_p.add_argument(
        "--skip-browser-install",
        action="store_true",
        help="Skip Playwright browser installation check.",
    )
    run_p.set_defaults(func=cmd_run)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    if getattr(args, "command", None) == "run":
        args.auto = not args.no_auto
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
