from __future__ import annotations

import os
import threading
import time
from pathlib import Path

import plotly.graph_objects as go
import streamlit as st

from app.engine.config import load_config
from app.engine.orchestrator import Orchestrator


st.set_page_config(
    page_title="AgentUX",
    page_icon="AX",
    layout="wide",
)


def _inject_styles() -> None:
    st.markdown(
        """
        <style>
        :root {
          --surface: #0a1118;
          --surface-2: #111c27;
          --accent: #00e5ff;
          --danger: #ff4d6d;
          --success: #22c55e;
          --warning: #f59e0b;
          --text-primary: #e6f1ff;
          --text-muted: #9fb3c8;
        }
        .block-container { padding-top: 1.2rem; }
        .title-banner {
          background: linear-gradient(90deg, rgba(0,229,255,0.12), rgba(17,28,39,0.6));
          border: 1px solid rgba(0,229,255,0.28);
          border-radius: 14px;
          padding: 14px 18px;
          margin-bottom: 14px;
        }
        .status-chip {
          display: inline-block;
          border-radius: 999px;
          padding: 4px 10px;
          font-size: 0.8rem;
          border: 1px solid rgba(0,229,255,0.35);
          background: rgba(0,229,255,0.12);
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _init_state() -> None:
    st.session_state.setdefault("orchestrator", None)
    st.session_state.setdefault("run_thread", None)
    st.session_state.setdefault("last_status", None)


def _start_run(target_url: str) -> None:
    config = load_config()
    config.target_base_url = target_url.strip()
    orchestrator = Orchestrator(config)

    st.session_state["orchestrator"] = orchestrator

    def _worker() -> None:
        status = orchestrator.run()
        st.session_state["last_status"] = status

    thread = threading.Thread(target=_worker, daemon=True)
    st.session_state["run_thread"] = thread
    st.session_state["last_status"] = orchestrator.status
    thread.start()


def _render_header() -> None:
    st.markdown(
        """
        <div class="title-banner">
          <h2 style="margin:0;">AgentUX Mission Control</h2>
          <p style="margin:6px 0 0 0;color:#9fb3c8;">Multi-agent UX stress testing cockpit</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _status_color(state: str) -> str:
    return {
        "running": "#f59e0b",
        "completed": "#22c55e",
        "partial": "#f59e0b",
        "failed": "#ff4d6d",
        "idle": "#00e5ff",
    }.get(state, "#9fb3c8")


def _render_setup() -> None:
    config = load_config()
    st.subheader("Run Setup")

    col1, col2 = st.columns([2, 1])
    with col1:
        target = st.text_input("Target URL", value=config.target_base_url)
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)
        can_start = not (st.session_state.get("run_thread") and st.session_state["run_thread"].is_alive())
        if st.button("Start Audit", type="primary", disabled=not can_start):
            _start_run(target)


def _auto_start_if_requested() -> None:
    auto = os.getenv("AGENTUX_AUTO_START", "0") == "1"
    if not auto:
        return
    if st.session_state.get("orchestrator") is not None:
        return
    if st.session_state.get("run_thread") is not None:
        return
    config = load_config()
    _start_run(config.target_base_url)


def _render_kpis(status: dict) -> None:
    state = status.get("state", "idle")
    run_id = status.get("run_id") or "-"
    results = status.get("agent_results", [])
    errors = [r for r in results if r.get("last_error")]
    completed = [r for r in results if r.get("completed")]

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Run State", state.upper())
    c2.metric("Agents", len(results))
    c3.metric("Completed", len(completed))
    c4.metric("Errors", len(errors))

    st.markdown(
        f"<span class='status-chip' style='border-color:{_status_color(state)};color:{_status_color(state)}'>run_id: {run_id}</span>",
        unsafe_allow_html=True,
    )


def _render_fleet(status: dict) -> None:
    st.subheader("Fleet Overview")
    results = status.get("agent_results", [])
    if not results:
        st.info("No agent results yet. Start a run to populate the fleet.")
        return

    cols = st.columns(3)
    for i, result in enumerate(results):
        with cols[i % 3]:
            st.markdown(f"**{result['persona_name']}**")
            st.write(f"Status: `{result['status']}`")
            if result.get("scenario_id"):
                st.write(f"Scenario: `{result['scenario_id']}`")
            st.write(f"Stop reason: `{result['stop_reason']}`")
            st.write(f"Steps: `{result['steps']}` | Retries: `{result['retries']}`")
            st.write(f"Assertion pass rate: `{int(result.get('assertion_pass_rate', 0) * 100)}%`")
            if result.get("last_error"):
                st.error(result["last_error"])
            run_dir = status.get("run_dir")
            if run_dir:
                screenshot_dir = (
                    Path(run_dir)
                    / "agents"
                    / result["agent_id"]
                    / "screenshots"
                )
                shots = sorted(screenshot_dir.glob("*.png"))
                if shots:
                    st.image(str(shots[-1]), caption="Latest screenshot", use_container_width=True)


def _render_agent_detail(status: dict) -> None:
    results = status.get("agent_results", [])
    if not results:
        return

    st.subheader("Agent Detail")
    persona_names = [r["persona_name"] for r in results]
    selected = st.selectbox("Select Agent", persona_names)
    result = next(r for r in results if r["persona_name"] == selected)

    st.json(result)
    assertions = result.get("assertion_summary", [])
    if assertions:
        st.markdown("**Latest Assertion Results**")
        st.table(assertions)

    confidence = result.get("confidence_series", [])
    if confidence:
        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=list(range(1, len(confidence) + 1)),
                y=confidence,
                mode="lines+markers",
                line={"color": "#00e5ff", "width": 3},
                marker={"size": 6},
                name="Confidence",
            )
        )
        fig.update_layout(
            template="plotly_dark",
            title="Confidence Trend",
            xaxis_title="Step",
            yaxis_title="Confidence",
            yaxis_range=[0, 1],
            margin={"l": 10, "r": 10, "t": 40, "b": 10},
            height=280,
        )
        st.plotly_chart(fig, use_container_width=True)


def _render_report(status: dict) -> None:
    report = status.get("report")
    if not report:
        return

    st.subheader("UX Friction Report")
    c1, c2, c3 = st.columns(3)
    c1.metric("UX Score", report["ux_score"])
    c2.metric("Completion", f"{int(report['completion_rate'] * 100)}%")
    c3.metric("Frustration", report["total_frustration_events"])

    st.markdown("**Critical Friction Points**")
    for item in report["critical_friction_points"]:
        st.write(f"- {item}")

    st.markdown("**Actionable Fixes**")
    for item in report["actionable_fixes"]:
        st.write(f"- {item}")

    persona_insights = report.get("persona_insights", [])
    if persona_insights:
        st.markdown("**Persona Insights**")
        for insight in persona_insights:
            st.markdown(
                f"- **{insight['persona_name']}** ({insight.get('scenario_id') or 'default'}): "
                f"{insight['summary']}"
            )
            st.write(f"  Dominant sentiment: `{insight.get('dominant_sentiment')}`")
            st.write(f"  Frustration events: `{insight.get('frustration_events')}`")
            thoughts = insight.get("notable_thoughts", [])
            if thoughts:
                st.write("  Notable thoughts:")
                for thought in thoughts:
                    st.write(f"  - {thought}")

    run_dir = status.get("run_dir")
    if run_dir:
        report_path = Path(run_dir) / "aggregate" / "report.md"
        if report_path.exists():
            st.download_button(
                label="Download report.md",
                data=report_path.read_text(encoding="utf-8"),
                file_name=report_path.name,
                mime="text/markdown",
            )


def main() -> None:
    _inject_styles()
    _init_state()
    _render_header()
    _render_setup()
    _auto_start_if_requested()

    orchestrator = st.session_state.get("orchestrator")
    thread = st.session_state.get("run_thread")

    status = st.session_state.get("last_status") or {
        "state": "idle",
        "agent_results": [],
    }

    if orchestrator is not None:
        status = orchestrator.status

    _render_kpis(status)
    _render_fleet(status)
    _render_agent_detail(status)
    _render_report(status)

    if thread and thread.is_alive():
        st.info("Run in progress. Dashboard auto-refreshing...")
        time.sleep(1)
        st.rerun()


if __name__ == "__main__":
    main()
