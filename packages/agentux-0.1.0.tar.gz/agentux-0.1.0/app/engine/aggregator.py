from __future__ import annotations

import collections
import json
from pathlib import Path

from app.engine.artifacts import ArtifactManager
from app.engine.schemas import AgentResult, AggregateReport, RunStatus


def _score(results: list[AgentResult]) -> tuple[float, float, int]:
    if not results:
        return 0.0, 0.0, 0

    completed = sum(1 for r in results if r.completed)
    completion_rate = completed / len(results)
    frustration = sum(r.frustration_events for r in results)
    retries = sum(r.retries for r in results)

    raw = 10.0 * completion_rate
    raw -= min(3.0, frustration * 0.1)
    raw -= min(2.0, retries * 0.2)
    return max(1.0, round(raw, 2)), round(completion_rate, 2), frustration


def _build_persona_insights(run_dir: Path, results: list[AgentResult]) -> list[dict]:
    insights: list[dict] = []
    for result in results:
        decisions_file = run_dir / "agents" / result.agent_id / "decisions.jsonl"
        sentiments: collections.Counter[str] = collections.Counter()
        intents: collections.Counter[str] = collections.Counter()
        reasons: list[str] = []

        if decisions_file.exists():
            with decisions_file.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        payload = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    sentiment = str(payload.get("sentiment", "")).strip()
                    if sentiment:
                        sentiments[sentiment] += 1
                    intent = str(payload.get("intent", "")).strip()
                    if intent:
                        intents[intent] += 1
                    reason = str(payload.get("reason", "")).strip()
                    if reason:
                        reasons.append(reason)

        dominant_sentiment = sentiments.most_common(1)[0][0] if sentiments else "unknown"
        top_intents = [item[0] for item in intents.most_common(2)]
        insight = {
            "agent_id": result.agent_id,
            "persona_name": result.persona_name,
            "scenario_id": result.scenario_id,
            "goal_status": "completed" if result.completed else "partial",
            "dominant_sentiment": dominant_sentiment,
            "frustration_events": result.frustration_events,
            "top_intents": top_intents,
            "notable_thoughts": reasons[:3],
            "summary": (
                f"{result.persona_name} was mostly {dominant_sentiment} while pursuing "
                f"scenario '{result.scenario_id or 'default'}'."
            ),
        }
        insights.append(insight)

    return insights


def aggregate_run(run_id: str, run_dir: Path, results: list[AgentResult]) -> AggregateReport:
    ux_score, completion_rate, frustration_total = _score(results)
    report_status = RunStatus.COMPLETED
    if any(not r.completed for r in results):
        report_status = RunStatus.PARTIAL
    if not results:
        report_status = RunStatus.FAILED

    friction_points: list[str] = []
    for result in results:
        if result.stop_reason not in (
            "goal_confidently_completed",
            "scenario_assertions_passed",
        ):
            friction_points.append(
                f"{result.persona_name}: stop_reason={result.stop_reason}; last_error={result.last_error or 'none'}"
            )

    if not friction_points:
        friction_points = ["No severe shared friction point detected in this run."]

    fixes = [
        "Standardize CTA labels and placements on primary task screens.",
        "Add stronger visual hierarchy for next-step actions.",
        "Ensure key interactive elements are keyboard-focusable and clearly labeled.",
    ]

    reliability = {
        "agents_total": len(results),
        "agents_completed": sum(1 for r in results if r.completed),
        "agents_partial": sum(1 for r in results if not r.completed),
        "total_retries": sum(r.retries for r in results),
        "top_stop_reasons": [r.stop_reason for r in results],
        "avg_assertion_pass_rate": (
            round(sum(r.assertion_pass_rate for r in results) / len(results), 2)
            if results
            else 0.0
        ),
    }
    persona_insights = _build_persona_insights(run_dir, results)

    report = AggregateReport(
        run_id=run_id,
        status=report_status,
        ux_score=ux_score,
        completion_rate=completion_rate,
        total_frustration_events=frustration_total,
        critical_friction_points=friction_points,
        persona_insights=persona_insights,
        actionable_fixes=fixes,
        reliability_summary=reliability,
    )

    aggregate_dir = run_dir / "aggregate"
    merged_events_path = aggregate_dir / "merged_events.jsonl"
    merged_events: list[dict] = []
    for result in results:
        events_file = run_dir / "agents" / result.agent_id / "events.jsonl"
        if events_file.exists():
            with events_file.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        merged_events.append(json.loads(line))
    merged_events.sort(key=lambda e: e.get("ts", ""))
    for event in merged_events:
        ArtifactManager.append_jsonl(merged_events_path, event)

    ArtifactManager.write_json(aggregate_dir / "report.json", report.model_dump())
    ArtifactManager.write_json(
        aggregate_dir / "metrics.json",
        {
            "ux_score": report.ux_score,
            "completion_rate": report.completion_rate,
            "frustration_events": report.total_frustration_events,
        },
    )

    md = [
        f"# UX Friction Report - {run_id}",
        "",
        f"- Status: **{report.status.value}**",
        f"- UX Score: **{report.ux_score}/10**",
        f"- Completion Rate: **{int(report.completion_rate * 100)}%**",
        f"- Total Frustration Events: **{report.total_frustration_events}**",
        "",
        "## Critical Friction Points",
    ]
    for point in report.critical_friction_points:
        md.append(f"- {point}")

    md.append("\n## Actionable Fixes")
    for fix in report.actionable_fixes:
        md.append(f"- {fix}")

    md.append("\n## Persona Insights")
    for insight in report.persona_insights:
        md.append(
            "- "
            f"{insight['persona_name']} ({insight['scenario_id']}): "
            f"{insight['summary']} "
            f"Frustration events={insight['frustration_events']}, "
            f"Top intents={insight['top_intents']}"
        )
        for thought in insight.get("notable_thoughts", []):
            md.append(f"  - Thought: {thought}")

    md.append("\n## Reliability Summary")
    for k, v in report.reliability_summary.items():
        md.append(f"- {k}: {v}")

    ArtifactManager.write_text(aggregate_dir / "report.md", "\n".join(md))
    return report
