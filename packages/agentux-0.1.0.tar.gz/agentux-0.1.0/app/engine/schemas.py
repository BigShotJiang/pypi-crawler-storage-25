from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class RunStatus(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"


class ErrorType(str, Enum):
    CONFIG_ERROR = "CONFIG_ERROR"
    CONNECTIVITY_ERROR = "CONNECTIVITY_ERROR"
    AUTOMATION_ERROR = "AUTOMATION_ERROR"
    MODEL_ERROR = "MODEL_ERROR"
    RESOURCE_ERROR = "RESOURCE_ERROR"
    GUARDRAIL_EXIT = "GUARDRAIL_EXIT"


class Persona(BaseModel):
    id: str
    name: str
    archetype: str
    goal: str
    traits: list[str] = Field(default_factory=list)
    risk_tolerance: str = Field(default="medium")
    accessibility_needs: list[str] = Field(default_factory=list)
    enabled: bool = True


class Action(BaseModel):
    type: str = Field(pattern=r"^(click|type|scroll|navigate|wait|back)$")
    target: str = ""
    value: str = ""


class Decision(BaseModel):
    sentiment: str = Field(pattern=r"^(confused|neutral|satisfied)$")
    confidence: float = Field(ge=0.0, le=1.0)
    intent: str
    action: Action
    fallback: str = "wait"
    reason: str


class EventRecord(BaseModel):
    ts: str
    run_id: str
    agent_id: str
    phase: str = Field(pattern=r"^(discovery|synthesis|audit|aggregate)$")
    step: int
    event_type: str
    latency_ms: int
    status: str = Field(pattern=r"^(ok|warn|error)$")
    error_type: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class DiscoverySummary(BaseModel):
    title: str
    headings: list[str]
    primary_nav: list[str]
    ctas: list[str]
    forms: list[str]


class AgentResult(BaseModel):
    agent_id: str
    persona_name: str
    scenario_id: str | None = None
    status: str
    completed: bool
    stop_reason: str
    steps: int
    retries: int
    last_error: str | None = None
    frustration_events: int = 0
    confidence_series: list[float] = Field(default_factory=list)
    assertion_pass_rate: float = 0.0
    assertion_summary: list[dict[str, Any]] = Field(default_factory=list)


class AggregateReport(BaseModel):
    run_id: str
    status: RunStatus
    ux_score: float
    completion_rate: float
    total_frustration_events: int
    critical_friction_points: list[str]
    persona_insights: list[dict[str, Any]] = Field(default_factory=list)
    actionable_fixes: list[str]
    reliability_summary: dict[str, Any]
