from __future__ import annotations

import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from app.engine.aggregator import aggregate_run
from app.engine.artifacts import ArtifactManager
from app.engine.audit import AuditContext, run_persona_audit
from app.engine.config import AppConfig
from app.engine.discovery import run_discovery
from app.engine.preflight import PreflightError, run_preflight
from app.engine.scenarios import load_scenarios
from app.engine.synthesis import synthesize_personas


class Orchestrator:
    def __init__(self, config: AppConfig):
        self.config = config
        self.artifacts = ArtifactManager(config.paths.artifacts_root)
        self.status: dict[str, Any] = {
            "run_id": None,
            "state": "idle",
            "error": None,
            "report": None,
            "agent_results": [],
            "personas": [],
            "scenarios": {},
            "run_dir": None,
        }

    def run(self) -> dict[str, Any]:
        run_id, run_dir = self.artifacts.new_run()
        self.status.update(
            {
                "run_id": run_id,
                "state": "running",
                "error": None,
                "report": None,
                "agent_results": [],
                "personas": [],
                "scenarios": {},
                "run_dir": str(run_dir),
            }
        )

        ArtifactManager.write_json(run_dir / "config_snapshot.json", self.config.model_dump())

        try:
            run_preflight(self.config)

            discovery = run_discovery(self.config, run_dir)
            personas = [p for p in synthesize_personas(self.config, discovery) if p.enabled]
            scenarios = load_scenarios(self.config, personas)
            self.status["personas"] = [p.model_dump() for p in personas]
            self.status["scenarios"] = {
                k: v.model_dump() for k, v in scenarios.items()
            }

            results = []
            with ThreadPoolExecutor(max_workers=max(1, len(personas))) as executor:
                futures = {
                    executor.submit(
                        run_persona_audit,
                        AuditContext(
                            run_id=run_id,
                            run_dir=Path(run_dir),
                            config=self.config,
                            persona=persona,
                            scenario=scenarios[persona.id],
                        ),
                    ): persona
                    for persona in personas
                }
                for future in as_completed(futures):
                    result = future.result()
                    results.append(result)
                    self.status["agent_results"] = [r.model_dump() for r in results]

            report = aggregate_run(run_id, Path(run_dir), results)
            final_state = "completed" if all(r.completed for r in results) else "partial"
            self.status.update({"state": final_state, "report": report.model_dump()})
        except PreflightError as exc:
            self.status.update(
                {
                    "state": "failed",
                    "error": {
                        "type": exc.error_type.value,
                        "message": str(exc),
                    },
                }
            )
        except Exception as exc:  # broad to preserve diagnostics
            self.status.update(
                {
                    "state": "failed",
                    "error": {
                        "type": "UNHANDLED_ERROR",
                        "message": str(exc),
                        "traceback": traceback.format_exc(),
                    },
                }
            )
        return self.status
