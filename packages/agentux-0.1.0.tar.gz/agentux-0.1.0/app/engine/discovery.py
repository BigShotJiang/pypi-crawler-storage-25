from __future__ import annotations

from pathlib import Path

from playwright.sync_api import Browser, sync_playwright

from app.engine.artifacts import ArtifactManager
from app.engine.config import AppConfig
from app.engine.schemas import DiscoverySummary


def run_discovery(config: AppConfig, run_dir: Path) -> DiscoverySummary:
    screenshot_path = run_dir / "discovery" / "landing.png"
    with sync_playwright() as p:
        browser: Browser = p.chromium.launch(headless=True)
        context = browser.new_context()
        page = context.new_page()
        page.goto(config.target_base_url, wait_until="domcontentloaded", timeout=15000)
        page.screenshot(path=str(screenshot_path), full_page=True)

        title = page.title() or "Untitled"
        headings = page.eval_on_selector_all(
            "h1, h2, h3",
            "els => els.slice(0, 12).map(e => e.textContent?.trim()).filter(Boolean)",
        )
        primary_nav = page.eval_on_selector_all(
            "nav a, header a",
            "els => els.slice(0, 12).map(e => e.textContent?.trim()).filter(Boolean)",
        )
        ctas = page.eval_on_selector_all(
            "button, a[role='button'], input[type='submit']",
            "els => els.slice(0, 16).map(e => (e.innerText || e.value || '').trim()).filter(Boolean)",
        )
        forms = page.eval_on_selector_all(
            "label, input[placeholder]",
            "els => els.slice(0, 20).map(e => (e.textContent || e.getAttribute('placeholder') || '').trim()).filter(Boolean)",
        )

        browser.close()

    summary = DiscoverySummary(
        title=title,
        headings=headings,
        primary_nav=primary_nav,
        ctas=ctas,
        forms=forms,
    )
    ArtifactManager.write_json(run_dir / "discovery" / "discovery_summary.json", summary.model_dump())
    return summary
