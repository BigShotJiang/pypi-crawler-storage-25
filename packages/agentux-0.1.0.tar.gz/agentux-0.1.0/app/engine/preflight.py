from __future__ import annotations

import socket
import urllib.error
import urllib.parse
import urllib.request

from app.engine.config import AppConfig
from app.engine.schemas import ErrorType


class PreflightError(RuntimeError):
    def __init__(self, message: str, error_type: ErrorType):
        super().__init__(message)
        self.error_type = error_type


def _check_url_reachable(url: str, timeout_seconds: int = 5) -> None:
    parsed = urllib.parse.urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        raise PreflightError(
            f"Invalid target URL: {url}",
            ErrorType.CONFIG_ERROR,
        )

    host = parsed.hostname
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        with socket.create_connection((host, port), timeout=timeout_seconds):
            pass
    except OSError as exc:
        raise PreflightError(
            f"Target host is unreachable: {host}:{port}",
            ErrorType.CONNECTIVITY_ERROR,
        ) from exc

    try:
        request = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            if response.status >= 500:
                raise PreflightError(
                    f"Target URL responded with status {response.status}",
                    ErrorType.CONNECTIVITY_ERROR,
                )
    except urllib.error.URLError as exc:
        raise PreflightError(
            f"Target URL is unreachable: {url}",
            ErrorType.CONNECTIVITY_ERROR,
        ) from exc


def run_preflight(config: AppConfig) -> None:
    if not config.openai_api_key:
        raise PreflightError(
            "OPENAI_API_KEY is missing. Create .env with OPENAI_API_KEY set.",
            ErrorType.CONFIG_ERROR,
        )
    _check_url_reachable(config.target_base_url)
