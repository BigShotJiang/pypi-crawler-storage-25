from __future__ import annotations

from app.engine.config import AppConfig
from app.engine.llm import LLMService
from app.engine.schemas import DiscoverySummary, Persona


def synthesize_personas(config: AppConfig, discovery_summary: DiscoverySummary) -> list[Persona]:
    service = LLMService(config)
    personas = service.synthesize_personas(
        discovery_summary=discovery_summary.model_dump(),
        count=config.run.persona_count,
    )
    return personas
