from __future__ import annotations

import os
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

try:
    from dotenv import load_dotenv
except ModuleNotFoundError:  # pragma: no cover - fallback for minimal envs
    def load_dotenv(*_args, **_kwargs) -> bool:
        return False


class RunConfig(BaseModel):
    max_steps_per_agent: int = 30
    max_runtime_minutes: int = 12
    max_retries_per_step: int = 2
    screenshot_fps_cap: int = 1
    persona_count: int = 3
    max_consecutive_low_confidence: int = 3
    low_confidence_threshold: float = 0.45


class ModelConfig(BaseModel):
    vision_model: str = "gpt-4o"
    reasoning_model: str = "gpt-4o-mini"


class PathConfig(BaseModel):
    artifacts_root: str = ".agentux/artifacts"
    scenario_file: str = ".agentux/scenarios/default.yaml"


class AppConfig(BaseModel):
    openai_api_key: str = ""
    target_base_url: str = "http://host.docker.internal:3000"
    run: RunConfig = Field(default_factory=RunConfig)
    models: ModelConfig = Field(default_factory=ModelConfig)
    paths: PathConfig = Field(default_factory=PathConfig)


DEFAULT_CONFIG_PATH = Path(".agentux/config.yaml")


def get_workspace_root() -> Path:
    return Path(
        os.getenv("AGENTUX_WORKSPACE", os.getenv("MA_UXST_WORKSPACE", Path.cwd()))
    ).resolve()


def load_config(config_path: Path = DEFAULT_CONFIG_PATH) -> AppConfig:
    workspace = get_workspace_root()
    preferred_env = workspace / ".agentux/.env"
    legacy_env = workspace / ".ma-uxst/.env"
    root_env = workspace / ".env"
    if preferred_env.exists():
        load_dotenv(preferred_env)
    elif legacy_env.exists():
        load_dotenv(legacy_env)
    elif root_env.exists():
        load_dotenv(root_env)
    else:
        load_dotenv()

    file_cfg: dict = {}
    resolved_config = config_path
    if not resolved_config.is_absolute():
        resolved_config = workspace / config_path
    if not resolved_config.exists():
        for fallback in (
            workspace / ".ma-uxst/config.yaml",
            workspace / "config.yaml",
        ):
            if fallback.exists():
                resolved_config = fallback
                break
    if resolved_config.exists():
        with resolved_config.open("r", encoding="utf-8") as f:
            file_cfg = yaml.safe_load(f) or {}

    cfg = AppConfig(
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
        target_base_url=os.getenv(
            "TARGET_BASE_URL",
            file_cfg.get("target_base_url", "http://host.docker.internal:3000"),
        ),
        run=RunConfig(**file_cfg.get("run", {})),
        models=ModelConfig(**file_cfg.get("models", {})),
        paths=PathConfig(**file_cfg.get("paths", {})),
    )

    artifacts_root = Path(
        os.getenv("AGENTUX_ARTIFACTS_ROOT", cfg.paths.artifacts_root)
    )
    if not artifacts_root.is_absolute():
        cfg.paths.artifacts_root = str((workspace / artifacts_root).resolve())
    scenario_file = Path(cfg.paths.scenario_file)
    if not scenario_file.is_absolute():
        cfg.paths.scenario_file = str((workspace / scenario_file).resolve())

    return cfg
