from __future__ import annotations

from datetime import datetime, timezone

from app.engine.schemas import ErrorType, EventRecord


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def make_event(
    *,
    run_id: str,
    agent_id: str,
    phase: str,
    step: int,
    event_type: str,
    latency_ms: int = 0,
    status: str = "ok",
    error_type: ErrorType | None = None,
    payload: dict | None = None,
) -> EventRecord:
    return EventRecord(
        ts=utc_now_iso(),
        run_id=run_id,
        agent_id=agent_id,
        phase=phase,
        step=step,
        event_type=event_type,
        latency_ms=latency_ms,
        status=status,
        error_type=error_type.value if error_type else None,
        payload=payload or {},
    )
