from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

from playwright.sync_api import Browser, Page, sync_playwright

from app.engine.artifacts import ArtifactManager
from app.engine.config import AppConfig
from app.engine.llm import LLMService
from app.engine.logging_utils import make_event
from app.engine.scenarios import Scenario, evaluate_assertions
from app.engine.schemas import AgentResult, Decision, ErrorType, Persona


@dataclass
class AuditContext:
    run_id: str
    run_dir: Path
    config: AppConfig
    persona: Persona
    scenario: Scenario


def _collect_observation(page: Page, screenshot_path: Path) -> dict:
    page.screenshot(path=str(screenshot_path), full_page=True)
    buttons = page.eval_on_selector_all(
        "button, a[role='button'], input[type='submit']",
        "els => els.slice(0, 8).map(e => (e.innerText || e.value || '').trim()).filter(Boolean)",
    )
    inputs = page.eval_on_selector_all(
        "input, textarea",
        "els => els.slice(0, 8).map(e => e.getAttribute('name') || e.getAttribute('placeholder') || e.id || '').filter(Boolean)",
    )
    return {
        "url": page.url,
        "title": page.title(),
        "buttons": buttons,
        "inputs": inputs,
    }


def _execute_action(page: Page, decision: Decision) -> str:
    action = decision.action.type
    target = decision.action.target.strip()
    value = decision.action.value

    if action == "wait":
        time.sleep(1)
        return "waited"

    if action == "navigate":
        if target:
            page.goto(target, wait_until="domcontentloaded", timeout=10000)
            return f"navigated to {target}"
        return "navigate skipped (missing target)"

    if action == "back":
        page.go_back(timeout=5000)
        return "went back"

    if action == "scroll":
        page.mouse.wheel(0, 800)
        return "scrolled"

    if action == "type":
        if not target:
            fields = page.locator("input, textarea")
            if fields.count() > 0:
                fields.first.fill(value or "test")
                return "typed into first field"
            return "type skipped (no field found)"

        locator = page.get_by_label(target)
        if locator.count() == 0:
            locator = page.get_by_placeholder(target)
        if locator.count() == 0:
            locator = page.locator(target)
        locator.first.fill(value or "test")
        return f"typed into {target}"

    if action == "click":
        if target:
            locator = page.get_by_role("button", name=target)
            if locator.count() == 0:
                locator = page.get_by_text(target)
            if locator.count() == 0:
                locator = page.locator(target)
            locator.first.click(timeout=5000)
            return f"clicked {target}"

        buttons = page.locator("button, a[role='button'], input[type='submit']")
        if buttons.count() > 0:
            buttons.first.click(timeout=5000)
            return "clicked first available button"
        return "click skipped (no button found)"

    return f"unsupported action {action}"


def run_persona_audit(ctx: AuditContext) -> AgentResult:
    cfg = ctx.config
    run = cfg.run
    agent_id = ctx.persona.id
    agent_dirs = ArtifactManager(cfg.paths.artifacts_root).ensure_agent_dirs(ctx.run_dir, agent_id)

    llm = LLMService(cfg)
    retries = 0
    frustrations = 0
    low_conf_streak = 0
    confidence_series: list[float] = []
    stop_reason = "unknown"
    completed = False
    last_error: str | None = None
    executed_steps = 0
    latest_assertions: list[dict] = []
    assertion_checks = 0
    assertion_passes = 0

    started = time.time()
    max_steps = (
        ctx.scenario.max_steps
        if ctx.scenario.max_steps is not None
        else run.max_steps_per_agent
    )

    with sync_playwright() as p:
        browser: Browser = p.chromium.launch(headless=True)
        context = browser.new_context()
        context.tracing.start(screenshots=True, snapshots=True)
        page = context.new_page()
        page.goto(cfg.target_base_url, wait_until="domcontentloaded", timeout=15000)

        for step in range(max_steps):
            executed_steps = step + 1
            elapsed_min = (time.time() - started) / 60
            if elapsed_min >= run.max_runtime_minutes:
                stop_reason = "max_runtime_minutes_exceeded"
                break

            screenshot_path = agent_dirs["screenshots"] / f"step_{step:03d}.png"

            obs_started = time.time()
            observation = _collect_observation(page, screenshot_path)
            obs_latency = int((time.time() - obs_started) * 1000)
            observe_event = make_event(
                run_id=ctx.run_id,
                agent_id=agent_id,
                phase="audit",
                step=step,
                event_type="observe",
                latency_ms=obs_latency,
                payload=observation,
            )
            ArtifactManager.append_jsonl(agent_dirs["events"], observe_event.model_dump())

            assertions_passed, assertion_details = evaluate_assertions(
                page,
                ctx.scenario.success_assertions,
            )
            if assertion_details:
                latest_assertions = assertion_details
                assertion_checks += len(assertion_details)
                assertion_passes += sum(
                    1 for item in assertion_details if item.get("passed")
                )
                assertion_event = make_event(
                    run_id=ctx.run_id,
                    agent_id=agent_id,
                    phase="audit",
                    step=step,
                    event_type="assertions",
                    latency_ms=0,
                    status="ok" if assertions_passed else "warn",
                    payload={"scenario_id": ctx.scenario.id, "details": assertion_details},
                )
                ArtifactManager.append_jsonl(
                    agent_dirs["events"], assertion_event.model_dump()
                )
                if assertions_passed:
                    completed = True
                    stop_reason = "scenario_assertions_passed"
                    break

            dec_started = time.time()
            decision = llm.decide_action(ctx.persona, ctx.scenario.goal, observation)
            dec_latency = int((time.time() - dec_started) * 1000)
            confidence_series.append(decision.confidence)
            if decision.sentiment == "confused":
                frustrations += 1

            if decision.confidence < run.low_confidence_threshold:
                low_conf_streak += 1
            else:
                low_conf_streak = 0

            decision_event = make_event(
                run_id=ctx.run_id,
                agent_id=agent_id,
                phase="audit",
                step=step,
                event_type="decision",
                latency_ms=dec_latency,
                status="warn" if decision.sentiment == "confused" else "ok",
                payload=decision.model_dump(),
            )
            ArtifactManager.append_jsonl(agent_dirs["events"], decision_event.model_dump())
            ArtifactManager.append_jsonl(agent_dirs["decisions"], decision.model_dump())

            if low_conf_streak >= run.max_consecutive_low_confidence:
                stop_reason = "low_confidence_guardrail"
                break

            try:
                exec_started = time.time()
                result = _execute_action(page, decision)
                exec_latency = int((time.time() - exec_started) * 1000)
                act_event = make_event(
                    run_id=ctx.run_id,
                    agent_id=agent_id,
                    phase="audit",
                    step=step,
                    event_type="action",
                    latency_ms=exec_latency,
                    payload={"action": decision.action.model_dump(), "result": result},
                )
                ArtifactManager.append_jsonl(agent_dirs["events"], act_event.model_dump())

                if (
                    not ctx.scenario.success_assertions
                    and decision.sentiment == "satisfied"
                    and decision.confidence >= 0.75
                ):
                    completed = True
                    stop_reason = "goal_confidently_completed"
                    break
            except Exception as exc:  # broad on purpose to keep run alive
                retries += 1
                last_error = str(exc)
                err_event = make_event(
                    run_id=ctx.run_id,
                    agent_id=agent_id,
                    phase="audit",
                    step=step,
                    event_type="error",
                    latency_ms=0,
                    status="error",
                    error_type=ErrorType.AUTOMATION_ERROR,
                    payload={"message": last_error},
                )
                ArtifactManager.append_jsonl(agent_dirs["events"], err_event.model_dump())

                if retries > run.max_retries_per_step:
                    stop_reason = "retry_budget_exhausted"
                    break
                time.sleep(1.2)

        if stop_reason == "unknown":
            stop_reason = "max_steps_reached"

        context.tracing.stop(path=str(agent_dirs["trace"]))
        browser.close()

    summary = AgentResult(
        agent_id=agent_id,
        persona_name=ctx.persona.name,
        scenario_id=ctx.scenario.id,
        status="completed" if completed else "partial",
        completed=completed,
        stop_reason=stop_reason,
        steps=executed_steps,
        retries=retries,
        last_error=last_error,
        frustration_events=frustrations,
        confidence_series=confidence_series,
        assertion_pass_rate=(
            round(assertion_passes / assertion_checks, 2) if assertion_checks else 0.0
        ),
        assertion_summary=latest_assertions,
    )
    ArtifactManager.write_json(agent_dirs["summary"], summary.model_dump())
    return summary
