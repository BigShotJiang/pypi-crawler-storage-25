from __future__ import annotations

import json
from pathlib import Path
from typing import Any

EXCLUDED_DIRS = {
    ".git",
    ".agentux",
    ".ma-uxst",
    "node_modules",
    ".venv",
    "venv",
    "dist",
    "build",
    "__pycache__",
    "artifacts",
}


def _iter_project_files(workspace: Path, max_files: int = 2500) -> list[str]:
    files: list[str] = []
    for path in workspace.rglob("*"):
        if len(files) >= max_files:
            break
        if path.is_dir() and path.name in EXCLUDED_DIRS:
            continue
        if path.is_file():
            rel = path.relative_to(workspace).as_posix().lower()
            if any(part in EXCLUDED_DIRS for part in rel.split("/")):
                continue
            files.append(rel)
    return files


def _has_any(files: list[str], needles: list[str]) -> bool:
    return any(any(n in f for n in needles) for f in files)


def infer_project_profile(workspace: Path) -> dict[str, Any]:
    files = _iter_project_files(workspace)

    signals: dict[str, bool] = {
        "auth": _has_any(files, ["login", "signin", "signup", "auth", "session"]),
        "checkout": _has_any(files, ["checkout", "cart", "payment", "order", "product"]),
        "onboarding": _has_any(files, ["onboarding", "welcome", "getting-started", "tutorial"]),
        "dashboard": _has_any(files, ["dashboard", "analytics", "overview", "home"]),
        "settings": _has_any(files, ["settings", "profile", "account"]),
        "docs": _has_any(files, ["docs", "documentation", "readme"]),
        "learning": _has_any(files, ["course", "lesson", "assignment", "student", "teacher", "lms"]),
        "deadlines": _has_any(files, ["deadline", "due-date", "assignment", "calendar"]),
    }

    candidates: list[dict[str, Any]] = []

    if signals["learning"] and signals["deadlines"]:
        candidates.append(
            {
                "id": "student-deadlines",
                "name": "Student Deadline Overview",
                "goal": "As a student, quickly find and understand upcoming deadlines.",
                "success_assertions": [
                    {"type": "url_contains", "value": "/courses/deadlines"},
                    {"type": "text_visible", "value": "Deadlines"},
                ],
            }
        )

    if signals["checkout"]:
        candidates.append(
            {
                "id": "checkout",
                "name": "Checkout Flow",
                "goal": "Find a product and complete checkout without confusion.",
                "success_assertions": [
                    {"type": "url_contains", "value": "checkout"},
                ],
            }
        )

    if signals["auth"]:
        candidates.append(
            {
                "id": "auth",
                "name": "Sign-In Flow",
                "goal": "Sign in successfully and reach the post-login area.",
                "success_assertions": [
                    {"type": "url_contains", "value": "dashboard"},
                ],
            }
        )

    if signals["onboarding"]:
        candidates.append(
            {
                "id": "onboarding",
                "name": "Onboarding Flow",
                "goal": "Complete onboarding and reach a first success moment.",
                "success_assertions": [
                    {"type": "title_contains", "value": "welcome"},
                ],
            }
        )

    if signals["dashboard"]:
        candidates.append(
            {
                "id": "dashboard",
                "name": "Core Navigation",
                "goal": "Reach the main dashboard and navigate core sections confidently.",
                "success_assertions": [
                    {"type": "url_contains", "value": "dashboard"},
                ],
            }
        )

    if not candidates:
        candidates.append(
            {
                "id": "generic",
                "name": "Primary User Journey",
                "goal": "Navigate the primary flow and complete the app's core task.",
                "success_assertions": [
                    {"type": "url_contains", "value": "/"},
                ],
            }
        )

    primary = candidates[0]
    return {
        "detected_signals": signals,
        "primary_scenario": primary,
        "scenario_candidates": candidates,
        "file_count_scanned": len(files),
    }


def write_project_profile(path: Path, profile: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
