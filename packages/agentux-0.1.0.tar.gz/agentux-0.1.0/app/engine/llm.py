from __future__ import annotations

import json
from typing import Any

from pydantic import ValidationError

from app.engine.config import AppConfig
from app.engine.schemas import Decision, Persona

try:
    from openai import OpenAI
except ModuleNotFoundError:  # pragma: no cover - optional runtime dependency
    OpenAI = None


class LLMService:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.client = OpenAI(api_key=config.openai_api_key) if OpenAI else None

    def _json_response(self, model: str, prompt: str) -> dict[str, Any]:
        if self.client is None:
            raise RuntimeError("OpenAI client unavailable")
        response = self.client.responses.create(
            model=model,
            input=prompt,
            temperature=0.2,
        )
        text = response.output_text.strip()
        return json.loads(text)

    def synthesize_personas(self, discovery_summary: dict[str, Any], count: int) -> list[Persona]:
        prompt = (
            "You are generating UX testing personas for a web app. "
            "Return ONLY JSON as an array."
            "Each item must include: id,name,archetype,goal,traits,risk_tolerance,accessibility_needs,enabled."
            f"Generate exactly {count} personas based on this summary: {json.dumps(discovery_summary)}"
        )
        try:
            raw = self._json_response(self.config.models.reasoning_model, prompt)
            if isinstance(raw, dict):
                raw = raw.get("personas", [])
            personas = [Persona.model_validate(item) for item in raw]
            if not personas:
                raise ValueError("No personas returned")
            return personas[:count]
        except Exception:
            return self._fallback_personas(count)

    def decide_action(
        self,
        persona: Persona,
        goal: str,
        observation: dict[str, Any],
    ) -> Decision:
        prompt = (
            "You are a UX audit agent controlling a browser. Return ONLY JSON with keys:"
            "sentiment,confidence,intent,action{type,target,value},fallback,reason."
            f"Persona: {persona.model_dump_json()} Goal: {goal} Observation: {json.dumps(observation)}"
            "Prefer safe actions when uncertain."
        )
        try:
            raw = self._json_response(self.config.models.vision_model, prompt)
            return Decision.model_validate(raw)
        except Exception:
            return Decision(
                sentiment="confused",
                confidence=0.2,
                intent="Recover from uncertainty",
                action={"type": "wait", "target": "", "value": ""},
                fallback="back",
                reason="Fallback decision after invalid model output.",
            )

    @staticmethod
    def _fallback_personas(count: int) -> list[Persona]:
        base = [
            Persona(
                id="p1",
                name="Task-Focused Professional",
                archetype="Efficiency seeker",
                goal="Complete a critical primary flow quickly.",
                traits=["impatient", "goal-oriented"],
                risk_tolerance="medium",
                accessibility_needs=[],
                enabled=True,
            ),
            Persona(
                id="p2",
                name="Cautious First-Time User",
                archetype="Trust-sensitive explorer",
                goal="Complete onboarding without confusion.",
                traits=["careful", "detail-oriented"],
                risk_tolerance="low",
                accessibility_needs=["larger text"],
                enabled=True,
            ),
            Persona(
                id="p3",
                name="Distracted Multitasker",
                archetype="Low-attention navigator",
                goal="Finish task with minimal cognitive load.",
                traits=["easily distracted", "mobile habits"],
                risk_tolerance="high",
                accessibility_needs=[],
                enabled=True,
            ),
        ]
        return base[:count]
