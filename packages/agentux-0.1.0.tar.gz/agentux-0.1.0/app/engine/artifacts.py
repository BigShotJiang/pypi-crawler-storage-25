from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4


class ArtifactManager:
    def __init__(self, artifacts_root: str) -> None:
        self.root = Path(artifacts_root)
        self.root.mkdir(parents=True, exist_ok=True)

    def new_run(self) -> tuple[str, Path]:
        run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + f"_{uuid4().hex[:8]}"
        run_dir = self.root / run_id
        (run_dir / "discovery").mkdir(parents=True, exist_ok=True)
        (run_dir / "aggregate").mkdir(parents=True, exist_ok=True)
        return run_id, run_dir

    def ensure_agent_dirs(self, run_dir: Path, agent_id: str) -> dict[str, Path]:
        base = run_dir / "agents" / agent_id
        screenshots = base / "screenshots"
        screenshots.mkdir(parents=True, exist_ok=True)
        return {
            "base": base,
            "screenshots": screenshots,
            "trace": base / "trace.zip",
            "events": base / "events.jsonl",
            "decisions": base / "decisions.jsonl",
            "summary": base / "summary.json",
        }

    @staticmethod
    def write_json(path: Path, payload: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)

    @staticmethod
    def append_jsonl(path: Path, payload: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=True) + "\n")

    @staticmethod
    def write_text(path: Path, text: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
