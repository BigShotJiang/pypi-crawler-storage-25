from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml
from pydantic import BaseModel, Field

from app.engine.config import AppConfig, get_workspace_root
from app.engine.schemas import Persona

if TYPE_CHECKING:
    from playwright.sync_api import Page
else:
    Page = Any


class SuccessAssertion(BaseModel):
    type: str = Field(pattern=r"^(url_contains|text_visible|selector_visible|title_contains)$")
    value: str
    timeout_ms: int = 1500


class Scenario(BaseModel):
    id: str
    name: str
    goal: str
    success_assertions: list[SuccessAssertion] = Field(default_factory=list)
    max_steps: int | None = None


class ScenarioFile(BaseModel):
    default_scenario: Scenario
    persona_overrides: dict[str, Scenario] = Field(default_factory=dict)


def _default_scenario_for_persona(persona: Persona) -> Scenario:
    return Scenario(
        id=f"default-{persona.id}",
        name="Default Persona Scenario",
        goal=persona.goal,
        success_assertions=[],
    )


def load_scenarios(config: AppConfig, personas: list[Persona]) -> dict[str, Scenario]:
    workspace = get_workspace_root()
    scenario_path = Path(config.paths.scenario_file)
    if not scenario_path.is_absolute():
        scenario_path = (workspace / scenario_path).resolve()

    if not scenario_path.exists():
        return {persona.id: _default_scenario_for_persona(persona) for persona in personas}

    with scenario_path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    parsed = ScenarioFile.model_validate(raw)
    result: dict[str, Scenario] = {}
    for persona in personas:
        result[persona.id] = parsed.persona_overrides.get(persona.id, parsed.default_scenario)
    return result


def evaluate_assertions(page: Page, assertions: list[SuccessAssertion]) -> tuple[bool, list[dict]]:
    if not assertions:
        return False, []

    details: list[dict] = []
    all_passed = True

    for assertion in assertions:
        passed = False
        message = ""
        try:
            if assertion.type == "url_contains":
                passed = assertion.value in page.url
                message = f"url contains '{assertion.value}'"
            elif assertion.type == "title_contains":
                passed = assertion.value.lower() in (page.title() or "").lower()
                message = f"title contains '{assertion.value}'"
            elif assertion.type == "text_visible":
                locator = page.get_by_text(assertion.value)
                passed = locator.first.is_visible(timeout=assertion.timeout_ms)
                message = f"text visible '{assertion.value}'"
            elif assertion.type == "selector_visible":
                locator = page.locator(assertion.value)
                passed = locator.first.is_visible(timeout=assertion.timeout_ms)
                message = f"selector visible '{assertion.value}'"
            else:
                message = f"unsupported assertion type {assertion.type}"
        except Exception as exc:
            message = f"assertion error: {exc}"
            passed = False

        details.append(
            {
                "type": assertion.type,
                "value": assertion.value,
                "passed": passed,
                "message": message,
            }
        )
        if not passed:
            all_passed = False

    return all_passed, details
