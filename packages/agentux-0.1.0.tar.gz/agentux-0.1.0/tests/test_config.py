from __future__ import annotations

from pathlib import Path

from app.engine.config import load_config


def test_load_config_from_workspace(monkeypatch, tmp_path: Path) -> None:
    workspace = tmp_path
    cfg_dir = workspace / ".agentux"
    cfg_dir.mkdir(parents=True)

    (cfg_dir / "config.yaml").write_text(
        """run:\n  persona_count: 2\npaths:\n  artifacts_root: .agentux/artifacts\n""",
        encoding="utf-8",
    )
    monkeypatch.setenv("AGENTUX_WORKSPACE", str(workspace))
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("TARGET_BASE_URL", "http://localhost:3000")

    cfg = load_config()
    assert cfg.run.persona_count == 2
    assert cfg.openai_api_key == "test-key"
    assert cfg.paths.artifacts_root == str((workspace / ".agentux/artifacts").resolve())
    assert cfg.paths.scenario_file == str(
        (workspace / ".agentux/scenarios/default.yaml").resolve()
    )
