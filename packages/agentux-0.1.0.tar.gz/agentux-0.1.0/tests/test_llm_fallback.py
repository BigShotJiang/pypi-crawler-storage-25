from __future__ import annotations

from app.engine.config import AppConfig
from app.engine.llm import LLMService
from app.engine.schemas import Persona


def test_llm_persona_fallback_on_exception(monkeypatch) -> None:
    service = LLMService(AppConfig(openai_api_key="test"))

    def _boom(_model: str, _prompt: str):
        raise RuntimeError("api down")

    monkeypatch.setattr(service, "_json_response", _boom)
    personas = service.synthesize_personas({"title": "x"}, 2)
    assert len(personas) == 2


def test_llm_decision_fallback_on_exception(monkeypatch) -> None:
    service = LLMService(AppConfig(openai_api_key="test"))

    def _boom(_model: str, _prompt: str):
        raise RuntimeError("api down")

    monkeypatch.setattr(service, "_json_response", _boom)
    persona = Persona(id="p1", name="A", archetype="a", goal="g")
    decision = service.decide_action(persona, "goal", {"url": "http://localhost"})
    assert decision.action.type == "wait"
    assert decision.sentiment == "confused"
