from __future__ import annotations

from pathlib import Path

from app.engine.config import load_config
from app.engine.scenarios import load_scenarios
from app.engine.schemas import Persona


def test_load_scenarios_from_workspace_file(monkeypatch, tmp_path: Path) -> None:
    workspace = tmp_path
    cfg_dir = workspace / ".agentux"
    scenario_dir = cfg_dir / "scenarios"
    scenario_dir.mkdir(parents=True)

    (cfg_dir / "config.yaml").write_text(
        """paths:\n  scenario_file: .agentux/scenarios/default.yaml\n""",
        encoding="utf-8",
    )
    (scenario_dir / "default.yaml").write_text(
        """default_scenario:\n  id: default\n  name: Primary\n  goal: Complete task\n  success_assertions:\n    - type: url_contains\n      value: /dashboard\npersona_overrides:\n  p2:\n    id: p2-override\n    name: Specialized\n    goal: Reach account\n    success_assertions:\n      - type: title_contains\n        value: Account\n""",
        encoding="utf-8",
    )

    monkeypatch.setenv("AGENTUX_WORKSPACE", str(workspace))
    cfg = load_config()

    personas = [
        Persona(id="p1", name="A", archetype="a", goal="g"),
        Persona(id="p2", name="B", archetype="b", goal="g"),
    ]

    scenarios = load_scenarios(cfg, personas)

    assert scenarios["p1"].id == "default"
    assert scenarios["p1"].success_assertions[0].type == "url_contains"
    assert scenarios["p2"].id == "p2-override"
    assert scenarios["p2"].success_assertions[0].type == "title_contains"
