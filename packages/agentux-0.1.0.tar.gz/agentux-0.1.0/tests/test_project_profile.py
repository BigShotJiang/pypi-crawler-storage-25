from __future__ import annotations

from pathlib import Path

from app.engine.project_profile import infer_project_profile


def test_infer_project_profile_checkout_signal(tmp_path: Path) -> None:
    (tmp_path / "src" / "pages").mkdir(parents=True)
    (tmp_path / "src" / "pages" / "checkout.tsx").write_text("export default function(){}", encoding="utf-8")

    profile = infer_project_profile(tmp_path)

    assert profile["detected_signals"]["checkout"] is True
    assert profile["primary_scenario"]["id"] == "checkout"
    assert profile["primary_scenario"]["success_assertions"][0]["type"] == "url_contains"


def test_infer_project_profile_learning_deadlines_signal(tmp_path: Path) -> None:
    (tmp_path / "src" / "features").mkdir(parents=True)
    (tmp_path / "src" / "features" / "student-assignment-deadline.ts").write_text(
        "export const x = 1;",
        encoding="utf-8",
    )

    profile = infer_project_profile(tmp_path)

    assert profile["detected_signals"]["learning"] is True
    assert profile["detected_signals"]["deadlines"] is True
    assert profile["primary_scenario"]["id"] == "student-deadlines"
    assert profile["primary_scenario"]["success_assertions"][0]["type"] == "url_contains"
