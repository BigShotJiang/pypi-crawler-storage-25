from __future__ import annotations

import yaml
from pathlib import Path

from app.cli import cmd_init
from app.cli import cmd_run


class _Args:
    pass


def test_cli_init_creates_project_files(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("AGENTUX_NO_PROMPT", "1")
    monkeypatch.chdir(tmp_path)
    rc = cmd_init(_Args())
    assert rc == 0
    assert (tmp_path / ".agentux" / "config.yaml").exists()
    assert (tmp_path / ".agentux" / ".env.example").exists()
    assert (tmp_path / ".agentux" / "scenarios" / "default.yaml").exists()
    assert (tmp_path / ".agentux" / "project_profile.json").exists()
    assert (tmp_path / ".gitignore").exists()


def test_cli_init_infers_checkout_goal(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("AGENTUX_NO_PROMPT", "1")
    (tmp_path / "app" / "routes").mkdir(parents=True)
    (tmp_path / "app" / "routes" / "checkout.tsx").write_text("x", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    rc = cmd_init(_Args())
    assert rc == 0

    scenario = yaml.safe_load(
        (tmp_path / ".agentux" / "scenarios" / "default.yaml").read_text(encoding="utf-8")
    )
    assert scenario["default_scenario"]["id"] == "checkout"


def test_cli_init_prompts_and_saves_openai_key(monkeypatch, tmp_path: Path) -> None:
    class _TTY:
        @staticmethod
        def isatty() -> bool:
            return True

    monkeypatch.delenv("AGENTUX_NO_PROMPT", raising=False)
    monkeypatch.setattr("app.cli.sys.stdin", _TTY())
    monkeypatch.setattr("app.cli.getpass.getpass", lambda _prompt: "sk-test-key")
    monkeypatch.chdir(tmp_path)

    rc = cmd_init(_Args())
    assert rc == 0

    env_path = tmp_path / ".agentux" / ".env"
    assert env_path.exists()
    text = env_path.read_text(encoding="utf-8")
    assert "OPENAI_API_KEY=sk-test-key" in text


def test_cli_run_requires_init(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.chdir(tmp_path)
    args = _Args()
    args.skip_browser_install = True
    args.port = 8501
    args.auto = True
    rc = cmd_run(args)
    assert rc == 2
