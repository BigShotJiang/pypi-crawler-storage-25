from app.engine.aggregator import _score
from app.engine.schemas import AgentResult


def test_score_bounds() -> None:
    results = [
        AgentResult(
            agent_id="p1",
            persona_name="A",
            status="completed",
            completed=True,
            stop_reason="goal_confidently_completed",
            steps=4,
            retries=0,
            frustration_events=1,
            confidence_series=[0.8, 0.9],
        ),
        AgentResult(
            agent_id="p2",
            persona_name="B",
            status="partial",
            completed=False,
            stop_reason="max_steps_reached",
            steps=30,
            retries=2,
            frustration_events=4,
            confidence_series=[0.2, 0.3],
        ),
    ]
    score, completion_rate, frustration = _score(results)
    assert 1.0 <= score <= 10.0
    assert completion_rate == 0.5
    assert frustration == 5
