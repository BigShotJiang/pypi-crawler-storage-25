from __future__ import annotations

import json
from pathlib import Path

from app.engine.aggregator import aggregate_run
from app.engine.schemas import AgentResult


def test_aggregate_generates_persona_insights(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    decisions_dir = run_dir / "agents" / "p1"
    decisions_dir.mkdir(parents=True)
    decisions_file = decisions_dir / "decisions.jsonl"
    decisions_file.write_text(
        "\n".join(
            [
                json.dumps({"sentiment": "confused", "intent": "find deadlines", "reason": "I cannot see deadlines in top nav."}),
                json.dumps({"sentiment": "neutral", "intent": "open menu", "reason": "I opened a side menu to continue."}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    results = [
        AgentResult(
            agent_id="p1",
            persona_name="Student",
            scenario_id="deadlines",
            status="partial",
            completed=False,
            stop_reason="max_steps_reached",
            steps=10,
            retries=0,
            frustration_events=2,
            confidence_series=[0.3, 0.4],
            assertion_pass_rate=0.4,
        )
    ]

    report = aggregate_run("run1", run_dir, results)

    assert report.persona_insights
    assert report.persona_insights[0]["persona_name"] == "Student"
    assert report.persona_insights[0]["dominant_sentiment"] == "confused"
