from __future__ import annotations

import typing
from ssl import SSLError

import httpx
from typing_extensions import Self, TypeAlias

from faceit.utils import StrEnum, representation

if typing.TYPE_CHECKING:
    import tenacity

    from faceit.types import EndpointParam

    _RetryHook: TypeAlias = typing.Callable[
        [tenacity.RetryCallState], typing.Union[typing.Awaitable[None], None]
    ]


@typing.final
class RetryArgs(typing.TypedDict, total=False):
    sleep: typing.Callable[
        [typing.Union[int, float]], typing.Union[typing.Awaitable[None], None]
    ]
    stop: typing.Union[
        tenacity.stop.stop_base, typing.Callable[[tenacity.RetryCallState], bool]
    ]
    wait: typing.Union[
        tenacity.wait.wait_base,
        typing.Callable[[tenacity.RetryCallState], typing.Union[float, int]],
    ]
    retry: typing.Union[
        tenacity.retry_base,
        typing.Callable[
            [tenacity.RetryCallState], typing.Union[typing.Awaitable[bool], bool]
        ],
    ]
    before: _RetryHook
    after: _RetryHook
    before_sleep: typing.Optional[_RetryHook]
    reraise: bool
    retry_error_cls: typing.Type[tenacity.RetryError]
    retry_error_callback: typing.Optional[
        typing.Callable[[tenacity.RetryCallState], typing.Any]
    ]


@typing.runtime_checkable
class SupportsExceptionPredicate(typing.Protocol):
    predicate: typing.Callable[
        [BaseException], typing.Union[typing.Awaitable[bool], bool]
    ]


class SupportedMethod(StrEnum):
    GET = "GET"
    POST = "POST"


@typing.final
@representation(use_str=True)
class Endpoint:
    __slots__ = ("base", "path_parts")

    def __init__(self, *path_parts: str, base: typing.Optional[str] = None) -> None:
        self.path_parts = list(filter(None, path_parts))
        self.base = base

    def add(self, *path_parts: str) -> Self:
        return self.__class__(*self.path_parts, *path_parts, base=self.base)

    def with_base(self, base: str, /) -> Self:
        return self.__class__(*self.path_parts, base=base)

    def __str__(self) -> str:
        return "/".join(
            part.strip("/") for part in [self.base, *self.path_parts] if part
        )

    def __truediv__(self, other: EndpointParam) -> Self:
        if not isinstance(other, self.__class__):
            return self.add(str(other))
        return self.__class__(*self.path_parts, *other.path_parts, base=self.base)

    def __itruediv__(self, other: EndpointParam) -> Self:
        if isinstance(other, self.__class__):
            self.path_parts.extend(other.path_parts)
            return self
        other_str = str(other)
        if other_str:
            self.path_parts.append(other_str)
        return self


def is_ssl_error(exception: BaseException, /) -> bool:
    return isinstance(exception, SSLError) or (
        isinstance(exception, httpx.ConnectError)
        and ("SSL" in str(exception) or "TLS" in str(exception))
    )


def is_retryable_status(code: int, /) -> bool:
    return code == httpx.codes.TOO_MANY_REQUESTS or httpx.codes.is_server_error(code)
