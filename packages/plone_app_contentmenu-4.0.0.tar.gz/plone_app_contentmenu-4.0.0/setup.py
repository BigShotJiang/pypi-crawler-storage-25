from setuptools import setup

version = "4.0.0"
long_description = open("README.rst").read() + "\n"
long_description += open("CHANGES.rst").read()

setup(
    name="plone.app.contentmenu",
    version=version,
    description="Plone's content menu implementation",
    long_description=long_description,
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: Web Environment",
        "Framework :: Plone",
        "Framework :: Plone :: 6.2",
        "Framework :: Plone :: Core",
        "Framework :: Zope :: 5",
        "License :: OSI Approved :: GNU General Public License v2 (GPLv2)",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
    ],
    keywords="plone contentmenu menu",
    author="Plone Foundation",
    author_email="plone-developers@lists.sourceforge.net",
    url="https://pypi.org/project/plone.app.contentmenu",
    license="GPL version 2",
    include_package_data=True,
    zip_safe=False,
    python_requires=">=3.10",
    extras_require=dict(
        test=[
            "plone.app.testing",
            "plone.app.contenttypes[test]",
        ]
    ),
    install_requires=[
        "plone.base",
        "plone.locking",
        "plone.memoize",
        "plone.app.content >= 2.0",
        "plone.protect >= 3.0.0",
        "plone.portlets",
        "plone.registry",
        "Zope",
    ],
)
