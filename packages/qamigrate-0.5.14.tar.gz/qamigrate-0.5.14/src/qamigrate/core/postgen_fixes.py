"""
Deterministic post-generation fixups for known Playwright Java migration gaps.

These are rule-based, zero-LLM-cost transformations applied to every generated
file after the Coder runs but before the first compile attempt. They target
patterns the LLM consistently gets wrong regardless of provider or prompt.

v0.5.8:
  - @Listeners({X.class}) → @ExtendWith(X.class) (TestNG → JUnit5)
  - ScreenshotOptions import fix (inner class, not a top-level type)

v0.5.9:
  - @Listeners guard: only apply @ExtendWith when the listener class is
    likely to implement Extension. Otherwise remove the broken annotation
    and emit a compile-safe stub so javac can proceed.
  - Locator.WaitForOptions.setState(Locator.State.*) →
    setState(WaitForSelectorState.*)

v0.5.11:
  - Strip AssertJ imports from non-test files; replace with Playwright assertThat
  - Strip leftover Selenium imports from generated Playwright files
  - Ensure WaitForSelectorState import present when the type is referenced
"""

from __future__ import annotations

import re

import structlog

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Fix 1 — @Listeners → @ExtendWith
# ---------------------------------------------------------------------------
#
# TestNG uses @Listeners({MyListener.class}) on test classes.
# JUnit 5 equivalent: @ExtendWith(MyListener.class) (no array, no braces).
# The Coder copies the TestNG form verbatim, which javac rejects because
# org.testng.annotations.Listeners doesn't exist in the JUnit5 classpath.
#
# The import also changes:
#   import org.testng.annotations.Listeners; → REMOVE
#   ADD import org.junit.jupiter.api.extension.ExtendWith;
#
# We only rewrite the annotation form -- not arbitrary class references.

_LISTENERS_ANNOTATION_RE = re.compile(
    r"@Listeners\s*\(\s*\{([^}]+)\}\s*\)",
    re.MULTILINE,
)

# Remove these TestNG-specific imports; they have no JUnit5 equivalent.
_TESTNG_LISTENER_IMPORTS = re.compile(
    r"^\s*import\s+org\.testng\.annotations\.Listeners\s*;\s*\n?",
    re.MULTILINE,
)

_EXTENDWITH_IMPORT = "import org.junit.jupiter.api.extension.ExtendWith;"


def _fix_listeners_annotation(
    code: str,
    extension_classes: set[str] | None = None,
) -> tuple[str, bool]:
    """Rewrite @Listeners({X.class}) → @ExtendWith(X.class).

    v0.5.9 guard: @ExtendWith requires the listener to implement
    org.junit.jupiter.api.extension.Extension. If the listener implements
    ITestListener (TestNG), applying @ExtendWith blindly causes a type error:
      "Class<TestListener> cannot be converted to Class<? extends Extension>"

    We apply @ExtendWith only when the listener class name is in
    `extension_classes` (a caller-supplied set of class names known to
    implement Extension). When we can't confirm, we remove the @Listeners
    annotation and replace it with a safe no-op comment -- this eliminates
    the "cannot find symbol: @Listeners" error without introducing a new
    type error. The Fixer's LLM can then address the cross-file migration
    in a subsequent pass with full context.

    `extension_classes=None` uses the conservative path (always safe-remove)
    since we can't verify. Callers who have cross-file class info can pass
    the set of confirmed Extension implementors.

    Returns (new_code, changed).
    """
    if "@Listeners" not in code:
        return code, False

    known_extensions = extension_classes or set()
    changed = False
    result = code

    def _replace_listeners(m: re.Match) -> str:
        inner = m.group(1)  # "TestListener.class" or "A.class, B.class"
        classes = [c.strip() for c in inner.split(",") if c.strip()]
        # Extract simple names (strip ".class" suffix).
        names = [cls.replace(".class", "").strip() for cls in classes]

        if known_extensions and all(n in known_extensions for n in names):
            # All listeners confirmed as Extension implementors -- safe to rewrite.
            return "\n".join(f"@ExtendWith({cls})" for cls in classes)

        # Cannot confirm: remove the broken annotation and leave a TODO.
        # This makes javac happy (no unknown symbol) without introducing a
        # type error. The Fixer or a human can address the cross-file migration.
        todo = (
            "// TODO: @Listeners removed -- listener class(es) must implement\n"
            "// org.junit.jupiter.api.extension.Extension before @ExtendWith\n"
            "// can be used. Migrate "
            + ", ".join(names)
            + " to implement BeforeEachCallback/AfterEachCallback."
        )
        return todo

    new_result, count = _LISTENERS_ANNOTATION_RE.subn(_replace_listeners, result)
    if count:
        changed = True
        result = new_result
        # Remove old TestNG import regardless of path taken above.
        result = _TESTNG_LISTENER_IMPORTS.sub("", result)
        # Only add ExtendWith import if we actually emitted @ExtendWith.
        if "@ExtendWith(" in result and _EXTENDWITH_IMPORT not in result:
            result = _insert_import(result, _EXTENDWITH_IMPORT)

    return result, changed


# ---------------------------------------------------------------------------
# Fix 2 — ScreenshotOptions import
# ---------------------------------------------------------------------------
#
# The LLM hallucinates `import com.microsoft.playwright.options.ScreenshotOptions;`
# which does not exist. The correct type is `Page.ScreenshotOptions` (an inner
# class of Page). Fix:
#   1. Remove the non-existent import.
#   2. Replace standalone `ScreenshotOptions` type references with
#      `Page.ScreenshotOptions` so the code compiles.
#   3. Ensure `import com.microsoft.playwright.Page;` is present.
#
# We only fix the specific hallucinated path. Other options.* imports are left
# alone (AriaRole, SelectOption, etc. are legitimately in that package).

_FAKE_SCREENSHOT_IMPORT = re.compile(
    r"^\s*import\s+com\.microsoft\.playwright\.options\.ScreenshotOptions\s*;\s*\n?",
    re.MULTILINE,
)

_PAGE_IMPORT = "import com.microsoft.playwright.Page;"


def _fix_screenshot_options_import(code: str) -> tuple[str, bool]:
    """Remove the non-existent ScreenshotOptions import and fix usages.

    Returns (new_code, changed).
    """
    if "ScreenshotOptions" not in code:
        return code, False

    # Only act if the hallucinated import is present.
    if not _FAKE_SCREENSHOT_IMPORT.search(code):
        return code, False

    result = _FAKE_SCREENSHOT_IMPORT.sub("", code)
    # Replace bare `ScreenshotOptions` with `Page.ScreenshotOptions`.
    # Use word-boundary match to avoid touching `Page.ScreenshotOptions`
    # that a previous run may have already fixed.
    result = re.sub(
        r"(?<!Page\.)\bScreenshotOptions\b",
        "Page.ScreenshotOptions",
        result,
    )
    # Ensure Page is imported.
    if _PAGE_IMPORT not in result:
        result = _insert_import(result, _PAGE_IMPORT)

    return result, True


# ---------------------------------------------------------------------------
# Fix 3 — Locator.WaitForOptions.setState enum type
# ---------------------------------------------------------------------------
#
# The LLM generates:
#   .waitFor(new Locator.WaitForOptions().setState(Locator.State.HIDDEN))
#
# But setState() takes a WaitForSelectorState, not Locator.State. The correct
# Playwright Java API is:
#   import com.microsoft.playwright.options.WaitForSelectorState;
#   .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN))

_LOCATOR_STATE_RE = re.compile(
    r"\bLocator\.State\.([A-Z_]+)\b",
    re.MULTILINE,
)

_WAIT_FOR_SELECTOR_STATE_IMPORT = (
    "import com.microsoft.playwright.options.WaitForSelectorState;"
)


def _fix_locator_state_enum(code: str) -> tuple[str, bool]:
    """Replace Locator.State.X with WaitForSelectorState.X.

    Returns (new_code, changed).
    """
    if "Locator.State." not in code:
        return code, False

    result = _LOCATOR_STATE_RE.sub(r"WaitForSelectorState.\1", code)
    changed = result != code
    if changed and _WAIT_FOR_SELECTOR_STATE_IMPORT not in result:
        result = _insert_import(result, _WAIT_FOR_SELECTOR_STATE_IMPORT)
    return result, changed


# ---------------------------------------------------------------------------
# Fix 4 — AssertJ imports stripped from non-test files
# ---------------------------------------------------------------------------
#
# The LLM sometimes adds `import static org.assertj.core.api.Assertions.assertThat;`
# to utility/page-object files. AssertJ is not injected by `qamigrate init` and
# almost never a project dependency in the source tree. When it appears in
# src/main/java files, Maven fails with "package org.assertj.core.api does not exist".
#
# Fix: remove the static AssertJ import and replace any assertThat(x).isTrue()
# style calls with Playwright's assertThat(locator).isVisible() equivalent.
# Also ensures `import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;`
# is present when Playwright assertThat is used.

_ASSERTJ_STATIC_IMPORT_RE = re.compile(
    r"^\s*import\s+static\s+org\.assertj\.[^;]+;\s*\n?",
    re.MULTILINE,
)
_ASSERTJ_PACKAGE_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.assertj\.[^;]+;\s*\n?",
    re.MULTILINE,
)

# Playwright's assertThat import
_PW_ASSERT_IMPORT = "import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;"

# Common AssertJ boolean wrappers → Playwright equivalents.
# assertThat(locator.isVisible()).isTrue() → assertThat(locator).isVisible()
# assertThat(locator.isVisible()).isFalse() → assertThat(locator).isHidden()
_ASSERTJ_BOOL_PATTERNS = [
    (re.compile(r"assertThat\(([^)]+)\.isVisible\(\)\)\.isTrue\(\)"), r"assertThat(\1).isVisible()"),
    (re.compile(r"assertThat\(([^)]+)\.isVisible\(\)\)\.isFalse\(\)"), r"assertThat(\1).isHidden()"),
    (re.compile(r"assertThat\(([^)]+)\.isHidden\(\)\)\.isTrue\(\)"), r"assertThat(\1).isHidden()"),
    (re.compile(r"assertThat\(([^)]+)\.isEnabled\(\)\)\.isTrue\(\)"), r"assertThat(\1).isEnabled()"),
    (re.compile(r"assertThat\(([^)]+)\.isEnabled\(\)\)\.isFalse\(\)"), r"assertThat(\1).isDisabled()"),
]


def _fix_assertj_imports(code: str) -> tuple[str, bool]:
    """Remove AssertJ imports and rewrite boolean assertions to Playwright form.

    Only fires when org.assertj imports are present. Does not touch test files
    that legitimately use AssertJ for non-Playwright assertions — the fix only
    replaces patterns that have a direct Playwright equivalent.

    Returns (new_code, changed).
    """
    if "org.assertj" not in code:
        return code, False

    result = code
    result = _ASSERTJ_STATIC_IMPORT_RE.sub("", result)
    result = _ASSERTJ_PACKAGE_IMPORT_RE.sub("", result)

    # Rewrite boolean wrapper patterns to Playwright assertThat.
    for pattern, replacement in _ASSERTJ_BOOL_PATTERNS:
        result = pattern.sub(replacement, result)

    # If Playwright assertThat is now used but not imported, add the import.
    if "assertThat(" in result and _PW_ASSERT_IMPORT not in result:
        result = _insert_import(result, _PW_ASSERT_IMPORT)

    return result, result != code


# ---------------------------------------------------------------------------
# Fix 5 — Strip leftover Selenium imports from generated files
# ---------------------------------------------------------------------------
#
# Generated files occasionally retain `import org.openqa.selenium.*` lines that
# were in the original source. These cause "package org.openqa.selenium does not
# exist" if selenium-java is not on the Playwright-only classpath.
#
# We remove the entire org.openqa.selenium.* import block. We also remove
# org.testng.* imports that aren't @Test/@BeforeMethod (those are already handled
# by the TestNG→JUnit5 migration; stragglers get cleaned here).

_SELENIUM_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.openqa\.selenium[^;]*;\s*\n?",
    re.MULTILINE,
)
_TESTNG_IMPORT_RE = re.compile(
    # Remove all TestNG imports. JUnit5 equivalents are added by the Coder.
    r"^\s*import\s+org\.testng(?!\.annotations\.Test\b)[^;]*;\s*\n?",
    re.MULTILINE,
)
# Also remove TestNG Assert static imports (replaced by JUnit5/Playwright assertions).
_TESTNG_ASSERT_IMPORT_RE = re.compile(
    r"^\s*import\s+static\s+org\.testng\.Assert[^;]*;\s*\n?",
    re.MULTILINE,
)


def _simple_name_from_import(import_line: str) -> str | None:
    """Extract the simple class name from a Java import line.

    'import org.testng.ITestListener;' -> 'ITestListener'
    'import static org.testng.Assert.assertEquals;' -> 'assertEquals'
    Returns None when the import ends in '.*' (wildcard).
    """
    # Strip leading whitespace and 'import [static] '
    m = re.search(r"import\s+(?:static\s+)?([\w.]+)\s*;", import_line)
    if not m:
        return None
    fq = m.group(1)
    last = fq.rsplit(".", 1)[-1]
    return None if last == "*" else last


def _import_is_still_used(import_line: str, code: str) -> bool:
    """Return True if the simple class name from `import_line` appears in
    the file body (i.e., the file still references the imported type/method).

    This guards the strip rule: we must NOT remove an import whose class is
    still referenced (e.g. `implements ITestListener` keeps the import).
    """
    name = _simple_name_from_import(import_line)
    if name is None:
        return False  # wildcard -- always safe to remove
    # Remove the import line itself before searching so we don't count the
    # import declaration as a "reference".
    body = code.replace(import_line, "", 1)
    return bool(re.search(rf"\b{re.escape(name)}\b", body))


def _fix_leftover_selenium_imports(
    code: str,
    strip_testng: bool = True,
) -> tuple[str, bool]:
    """Strip residual Selenium (and optionally TestNG) imports from a generated file.

    Args:
        strip_testng: When False (TestNG target framework), skip the TestNG
            import strip entirely. org.testng.* imports are intentional on
            the TestNG path. Selenium imports are still removed regardless.

    v0.5.12 guard: only remove an import if the imported class name is no longer
    referenced anywhere in the file body.

    Returns (new_code, changed).
    """
    result = code
    changed = False

    # Process Selenium imports line-by-line with the guard (always).
    for m in list(_SELENIUM_IMPORT_RE.finditer(code)):
        line = m.group(0)
        if not _import_is_still_used(line, result):
            result = result.replace(line, "", 1)
            changed = True

    if strip_testng:
        # On JUnit5 path: remove orphaned TestNG lifecycle/annotation imports
        # (they were replaced by JUnit5 equivalents by the Coder).
        for m in list(_TESTNG_IMPORT_RE.finditer(code)):
            line = m.group(0)
            if not _import_is_still_used(line, result):
                result = result.replace(line, "", 1)
                changed = True

        # TestNG Assert static imports are always safe to remove on the JUnit5
        # path — those calls are rewritten to JUnit5/Playwright assertions.
        for m in list(_TESTNG_ASSERT_IMPORT_RE.finditer(code)):
            line = m.group(0)
            result = result.replace(line, "", 1)
            changed = True

    return result, changed


# ---------------------------------------------------------------------------
# Fix 6 — Ensure WaitForSelectorState import when type is referenced
# ---------------------------------------------------------------------------
#
# After Fix 3 rewrites Locator.State.X → WaitForSelectorState.X, the import
# is added. But the Fixer may regenerate sections of the file without the import.
# This guard ensures the import is always present when the type appears.


def _ensure_wait_for_selector_state_import(code: str) -> tuple[str, bool]:
    """Add WaitForSelectorState import if the type is used but not imported."""
    if "WaitForSelectorState" not in code:
        return code, False
    if _WAIT_FOR_SELECTOR_STATE_IMPORT in code:
        return code, False
    return _insert_import(code, _WAIT_FOR_SELECTOR_STATE_IMPORT), True


# ---------------------------------------------------------------------------
# Shared helper
# ---------------------------------------------------------------------------


def _insert_import(code: str, import_stmt: str) -> str:
    """Insert `import_stmt` after the last existing import line.

    Falls back to inserting after the package declaration if there are no
    existing imports.
    """
    # Find the last import line.
    last_import = -1
    for m in re.finditer(r"^\s*import\s+[^;]+;\s*$", code, re.MULTILINE):
        last_import = m.end()

    if last_import != -1:
        return code[:last_import] + f"\n{import_stmt}" + code[last_import:]

    # No imports found -- insert after package declaration.
    pkg_match = re.search(r"^\s*package\s+[^;]+;\s*$", code, re.MULTILINE)
    if pkg_match:
        pos = pkg_match.end()
        return code[:pos] + f"\n\n{import_stmt}" + code[pos:]

    # Default: prepend.
    return f"{import_stmt}\n\n{code}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def apply_all_postgen_fixes(
    code: str,
    file_path: str = "",
    extension_classes: set[str] | None = None,
    target_framework: str = "junit5",
) -> str:
    """Apply all deterministic post-generation fixes to `code`.

    Args:
        code: Java source to fix.
        file_path: Used for logging only.
        extension_classes: Optional set of class names confirmed to implement
            org.junit.jupiter.api.extension.Extension. When provided, the
            @Listeners→@ExtendWith rewrite is applied for those classes only;
            others get a safe TODO comment. When None (default), the rewrite
            is always replaced with a TODO (conservative safe path).
            Ignored when target_framework == "testng".
        target_framework: The test framework the generated code targets.
            "testng"  — generated code uses TestNG; @Listeners must NOT be
                        rewritten, org.testng imports must NOT be stripped.
            "junit5"  — generated code uses JUnit5 (default behaviour).
            "junit4"  — generated code uses JUnit4; same as junit5 for postgen.

    Returns the fixed source. If nothing changed, returns the original object
    unchanged (identity comparison safe).
    """
    is_testng = target_framework == "testng"
    result = code
    any_changed = False

    # @Listeners rewrite: JUnit5 only.
    # On TestNG, @Listeners({X.class}) is a valid TestNG annotation and MUST
    # be preserved. Rewriting it would break the TestNG listener mechanism.
    if not is_testng:
        result, changed = _fix_listeners_annotation(result, extension_classes)
        if changed:
            logger.info("postgen_fixes: rewrote @Listeners annotation", file=file_path)
            any_changed = True

    # These fixes are framework-neutral — apply on all paths.
    result, changed = _fix_screenshot_options_import(result)
    if changed:
        logger.info("postgen_fixes: fixed ScreenshotOptions import", file=file_path)
        any_changed = True

    result, changed = _fix_locator_state_enum(result)
    if changed:
        logger.info("postgen_fixes: fixed Locator.State -> WaitForSelectorState", file=file_path)
        any_changed = True

    result, changed = _ensure_wait_for_selector_state_import(result)
    if changed:
        logger.info("postgen_fixes: added missing WaitForSelectorState import", file=file_path)
        any_changed = True

    result, changed = _fix_assertj_imports(result)
    if changed:
        logger.info("postgen_fixes: removed AssertJ imports, rewrote assertions", file=file_path)
        any_changed = True

    # Selenium import strip: on TestNG, org.testng imports are intentional
    # (TestNG API is the target framework).  Only strip Selenium imports;
    # the TestNG-import strip blocks inside _fix_leftover_selenium_imports
    # are already individually guarded by _import_is_still_used, but we
    # pass a flag so the function can skip the TestNG strip pass entirely
    # when target is TestNG for a cleaner separation of concerns.
    result, changed = _fix_leftover_selenium_imports(result, strip_testng=not is_testng)
    if changed:
        logger.info("postgen_fixes: stripped leftover Selenium/TestNG imports", file=file_path)
        any_changed = True

    return result if any_changed else code
