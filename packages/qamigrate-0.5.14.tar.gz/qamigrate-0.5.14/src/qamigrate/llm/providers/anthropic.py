"""
Anthropic provider (reference implementation).

This is a straight port of the code that used to live in CoderAgent and
FixerAgent. It's the contract every other provider must match: given a
system prompt, user prompt, and tool schema, return a dict matching the
schema.
"""

from __future__ import annotations

import os
from typing import Any

import structlog

from qamigrate.llm.base import LLMProvider, StructuredResponse, ToolSchema
from qamigrate.llm.errors import LLMConfigError, LLMMalformedOutput, LLMUnavailable
from qamigrate.llm.sanitize import sanitize_fields

logger = structlog.get_logger(__name__)


# Default model used when the caller didn't specify one.
DEFAULT_MODEL = "claude-sonnet-4-20250514"


class AnthropicProvider(LLMProvider):
    """
    Uses Claude's native tool-use with forced tool_choice. Exactly the
    same behavior the product has shipped with since v0.1.0 -- moved here
    so we can plug in other providers without touching agent code.
    """

    name = "anthropic"
    supports_tool_use = True

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        *,
        api_key: str | None = None,
        api_key_env: str = "ANTHROPIC_API_KEY",
    ) -> None:
        self.model = model
        self._api_key = api_key or os.environ.get(api_key_env)

        if not self._api_key:
            raise LLMConfigError(
                f"Anthropic API key not found. Set the {api_key_env} environment "
                f"variable or pass api_key= explicitly."
            )

        # Lazy-import the SDK so the package can be installed without
        # Anthropic as a hard dependency if we ever go optional. For now
        # anthropic is a required dep, but the pattern makes swapping easy.
        try:
            from anthropic import Anthropic
        except ImportError as e:  # pragma: no cover
            raise LLMConfigError(
                "The `anthropic` package is not installed. Run "
                "`pip install qamigrate[anthropic]` or `pip install anthropic`."
            ) from e

        self._client = Anthropic(api_key=self._api_key)

    def __repr__(self) -> str:
        key_hint = f"...{self._api_key[-4:]}" if self._api_key else "NOT SET"
        return f"AnthropicProvider(model={self.model!r}, key={key_hint})"

    def generate_structured(
        self,
        system: str,
        user: str,
        tool: ToolSchema,
        *,
        max_tokens: int = 4096,
        temperature: float = 0.0,
    ) -> StructuredResponse:
        tools = [{
            "name": tool.name,
            "description": tool.description,
            "input_schema": tool.input_schema,
        }]

        try:
            response = self._client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system,
                messages=[{"role": "user", "content": user}],
                tools=tools,
                tool_choice={"type": "tool", "name": tool.name},
            )
        except Exception as e:
            # Anthropic SDK raises a handful of different classes for
            # connection / timeout problems. Normalize into our hierarchy
            # so agents don't have to import anthropic to catch them.
            msg = str(e)
            if "connection" in msg.lower() or "timed out" in msg.lower():
                raise LLMUnavailable(f"Anthropic API unreachable: {msg}") from e
            raise

        tool_use_block = self._find_tool_use_block(response)
        if tool_use_block is None:
            raw = _extract_text(response)
            raise LLMMalformedOutput(
                "Anthropic response contained no tool_use block.",
                raw_text=raw,
            )

        data = sanitize_fields(dict(tool_use_block.input))
        usage = _extract_usage(response)

        return StructuredResponse(
            data=data,
            raw_text=None,
            provider=self.name,
            model=self.model,
            usage=usage,
        )

    @staticmethod
    def _find_tool_use_block(response: Any) -> Any:
        for block in getattr(response, "content", []) or []:
            if getattr(block, "type", None) == "tool_use":
                return block
        return None


def _extract_text(response: Any) -> str | None:
    """Best-effort text extraction for malformed-output debugging."""
    parts = []
    for block in getattr(response, "content", []) or []:
        text = getattr(block, "text", None)
        if text:
            parts.append(text)
    return "\n".join(parts) if parts else None


def _extract_usage(response: Any) -> dict[str, int]:
    usage = getattr(response, "usage", None)
    if usage is None:
        return {}
    return {
        "input_tokens": int(getattr(usage, "input_tokens", 0)),
        "output_tokens": int(getattr(usage, "output_tokens", 0)),
    }
