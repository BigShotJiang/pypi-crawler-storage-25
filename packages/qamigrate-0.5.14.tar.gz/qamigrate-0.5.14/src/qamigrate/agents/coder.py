"""
Coder Agent.

LLM-powered Playwright code generation.
Uses the pluggable `LLMProvider` abstraction for structured output;
defaults to Anthropic to preserve v0.3.x behavior exactly.
"""

import json
from pathlib import Path
from typing import Any

import structlog
from pydantic import BaseModel, Field

from qamigrate.core.config import CoderConfig
from qamigrate.llm.base import LLMProvider, ToolSchema
from qamigrate.llm.sanitize import escape_for_code_fence

logger = structlog.get_logger(__name__)


class MethodDefinition(BaseModel):
    """Generated method with migration notes."""

    name: str = Field(description="Method name")
    signature: str = Field(description="Full method signature with return type and parameters")
    implementation: str = Field(description="Complete method implementation")
    migration_note: str | None = Field(default=None, description="Note about migration changes")


class PlaywrightCode(BaseModel):
    """Structured output schema for generated Playwright code."""

    package_name: str = Field(description="Java package name")
    imports: list[str] = Field(description="Required import statements")
    class_declaration: str = Field(description="Class signature with extends/implements")
    fields: list[str] = Field(description="Class field declarations")
    constructor: str = Field(description="Constructor with Page injection")
    methods: list[MethodDefinition] = Field(description="Method implementations")


def _build_system_prompt(target_framework: str = "junit5") -> str:
    """Build the system prompt for the Coder, adapted to the target test framework.

    v0.5.13: QAMigrate preserves the source project's test framework.
    - "testng"  → Keep all TestNG annotations; only migrate Selenium API → Playwright API.
    - "junit5"  → Migrate TestNG → JUnit5 AND Selenium → Playwright (original behaviour).
    - "junit4"  → Migrate TestNG → JUnit4 AND Selenium → Playwright.
    """
    is_testng = target_framework == "testng"
    is_junit4 = target_framework == "junit4"

    if is_testng:
        lifecycle_section = """### TestNG Lifecycle — KEEP AS-IS (target framework is TestNG)
- @Test stays @Test (from org.testng.annotations.Test)
- @BeforeMethod stays @BeforeMethod
- @AfterMethod stays @AfterMethod
- @BeforeClass stays @BeforeClass
- @AfterClass stays @AfterClass
- @DataProvider stays @DataProvider — DATA-DRIVEN TESTS ARE PRESERVED EXACTLY
- @Parameters stays @Parameters
- @Listeners({X.class}) stays @Listeners({X.class})
- Assert.assertEquals/assertTrue stay as TestNG assertions for VALUE checks
- For UI state assertions, ADD Playwright assertThat(locator).isVisible() etc.
- Do NOT import org.junit.*; keep org.testng.* imports
- Do NOT convert to @BeforeEach, @AfterEach, @ExtendWith or any JUnit5 annotation"""

        test_class_scaffold = """### Test Class Structure
For TEST CLASSES (not page objects):
```java
import com.microsoft.playwright.*;
import org.testng.annotations.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import static org.testng.Assert.*;

public class ExampleTest {
    Playwright playwright;
    Browser browser;
    BrowserContext context;
    Page page;

    @BeforeClass
    public void beforeClass() {
        playwright = Playwright.create();
        browser = playwright.chromium().launch();
    }

    @AfterClass
    public void afterClass() {
        playwright.close();
    }

    @BeforeMethod
    public void setUp() {
        context = browser.newContext();
        page = context.newPage();
    }

    @AfterMethod
    public void tearDown() {
        context.close();
    }

    @Test
    public void testExample() {
        // Test implementation
    }

    @DataProvider(name = "loginData")
    public Object[][] loginData() {
        return new Object[][] { { "user", "pass" } };
    }

    @Test(dataProvider = "loginData")
    public void testLogin(String user, String pass) {
        // Data-driven test
    }
}
```"""

    elif is_junit4:
        lifecycle_section = """### JUnit 4 Lifecycle → Playwright/JUnit 4
- @Test stays @Test (from org.junit.Test)
- @Before → @Before (setUp)
- @After → @After (tearDown)
- @BeforeClass → @BeforeClass static
- @AfterClass → @AfterClass static
- Keep junit.Assert imports; add PlaywrightAssertions for UI assertions"""

        test_class_scaffold = """### Test Class Structure
For TEST CLASSES (not page objects):
```java
import com.microsoft.playwright.*;
import org.junit.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class ExampleTest {
    static Playwright playwright;
    static Browser browser;
    BrowserContext context;
    Page page;

    @BeforeClass
    public static void beforeClass() {
        playwright = Playwright.create();
        browser = playwright.chromium().launch();
    }

    @AfterClass
    public static void afterClass() {
        playwright.close();
    }

    @Before
    public void setUp() {
        context = browser.newContext();
        page = context.newPage();
    }

    @After
    public void tearDown() {
        context.close();
    }

    @Test
    public void testExample() {
        // Test implementation
    }
}
```"""

    else:  # junit5 (default)
        lifecycle_section = """### TestNG Lifecycle → Playwright/JUnit 5
- @BeforeClass → @BeforeAll static void beforeAll() { ... }
- @AfterClass → @AfterAll static void afterAll() { ... }
- @BeforeMethod → @BeforeEach void setUp() { ... }
- @AfterMethod → @AfterEach void tearDown() { ... }
- @Test → @Test (from org.junit.jupiter.api.Test)
- Remove testng.Assert imports → use org.junit.jupiter.api.Assertions or PlaywrightAssertions"""

        test_class_scaffold = """### Test Class Structure
For TEST CLASSES (not page objects):
```java
import com.microsoft.playwright.*;
import org.junit.jupiter.api.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class ExampleTest {
    static Playwright playwright;
    static Browser browser;
    BrowserContext context;
    Page page;

    @BeforeAll
    static void beforeAll() {
        playwright = Playwright.create();
        browser = playwright.chromium().launch();
    }

    @AfterAll
    static void afterAll() {
        playwright.close();
    }

    @BeforeEach
    void setUp() {
        context = browser.newContext();
        page = context.newPage();
    }

    @AfterEach
    void tearDown() {
        context.close();
    }

    @Test
    void testExample() {
        // Test implementation
    }
}
```"""

    # Build by string concatenation to avoid f-string / .format() conflicts
    # with Java code blocks that contain literal { and } characters.
    _PART1 = """You are an expert Java developer specializing in test automation migration.
Your task is to convert Selenium test code to Playwright Java, following these principles:

## Playwright Java Patterns

1. **Page Object Model**: All page objects receive `Page` via constructor injection
2. **Locators**: Use `page.locator()` with CSS selectors (preferred) or XPath
3. **Auto-waiting**: Remove all explicit waits - Playwright handles automatically
4. **Assertions**: Use Playwright's `assertThat()` with expect-style assertions
5. **Actions**: Replace Selenium Actions with `locator.click()`, `locator.fill()`, etc.

## Migration Rules

### Locators
- @FindBy(id="x") → private Locator fieldName; (initialized in constructor as page.locator("#x"))
- @FindBy(css="x") → page.locator("x")
- @FindBy(xpath="x") → page.locator("xpath=x")
- By.id("x") → page.locator("#x")
- By.className("x") → page.locator(".x")
- By.name("x") → page.locator("[name='x']")
- By.linkText("x") → page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("x"))

### Interactions
- element.sendKeys("text") → locator.fill("text")
- element.click() → locator.click()
- element.clear() → (removed, fill() clears automatically)
- new Select(element).selectByValue("x") → locator.selectOption("x")
- element.getText() → locator.textContent()
- element.getAttribute("x") → locator.getAttribute("x")

### Waits (REMOVE - Playwright auto-waits)
- WebDriverWait → REMOVE entirely
- ExpectedConditions.visibilityOf() → REMOVE
- ExpectedConditions.elementToBeClickable() → REMOVE
- Thread.sleep() → REMOVE (or page.waitForTimeout() only if absolutely necessary)

### Assertions
- assertTrue(element.isDisplayed()) → assertThat(locator).isVisible()
- assertEquals(expected, element.getText()) → assertThat(locator).hasText(expected)
- assertFalse(element.isDisplayed()) → assertThat(locator).isHidden()

### Driver Management
- WebDriver driver → Page page (injected via constructor)
- driver.get(url) → page.navigate(url)
- driver.findElement(By.x) → page.locator(selector)
- driver.getTitle() → page.title()
- driver.getCurrentUrl() → page.url()

LIFECYCLE_PLACEHOLDER

TEST_CLASS_PLACEHOLDER

### Page Object Structure
For PAGE OBJECTS (not test classes):
```java
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class ExamplePage {
    private final Page page;
    private final Locator someElement;

    public ExamplePage(Page page) {
        this.page = page;
        this.someElement = page.locator("#selector");
    }

    public void doAction() {
        someElement.click();
    }
}
```

## Code Style Requirements

- Use meaningful variable names
- Add brief comments explaining significant migration decisions
- Preserve original test intent and business logic
- Follow Java naming conventions (camelCase for methods/variables, PascalCase for classes)
- Use proper indentation (4 spaces)

## ⚠️ CRITICAL OUTPUT RULES - READ CAREFULLY ⚠️

1. **EXACTLY ONE class declaration** - Never repeat the class definition
2. **EXACTLY ONE constructor** - Generate only a single constructor, never duplicates
3. **Each field declared EXACTLY ONCE** - No duplicate field declarations
4. **Each method implemented EXACTLY ONCE** - No repeated method implementations
5. **COMPLETE, COMPILABLE code** - All braces must match, all semicolons included
6. **Package statement MUST append `.playwright`** - If the original is
   `com.example.pages`, the generated file MUST declare
   `package com.example.pages.playwright;`. Never copy the original
   package verbatim -- always add the `.playwright` suffix so generated
   files occupy a separate package from the originals.
7. **NO PARTIAL CODE** - Every method body must be complete
8. **NO PLACEHOLDER COMMENTS** - Replace all "..." or "// implementation" with actual code

## Pre-Output Checklist (VERIFY BEFORE RESPONDING)

Before generating output, mentally verify:
☐ Is there only ONE constructor?
☐ Is each field declared only ONCE?
☐ Is each method defined only ONCE?
☐ Are all braces {} properly matched?
☐ Does every statement end with a semicolon?
☐ Is the package name correct?

If any answer is NO, fix it before outputting."""

    return (
        _PART1
        .replace("LIFECYCLE_PLACEHOLDER", lifecycle_section)
        .replace("TEST_CLASS_PLACEHOLDER", test_class_scaffold)
    )


# Module-level default prompt (junit5) kept for tests and single-file path
# that doesn't go through run_project_migration.
SYSTEM_PROMPT = _build_system_prompt("junit5")


def _coder_tool_schema() -> ToolSchema:
    """Wrap `CoderAgent._TOOL_SCHEMA` in the provider-agnostic ToolSchema."""
    schema = CoderAgent._TOOL_SCHEMA
    return ToolSchema(
        name=schema["name"],
        description=schema["description"],
        input_schema=schema["input_schema"],
    )


class CoderAgent:
    """
    LLM-powered Playwright code generation.

    Uses a pluggable `LLMProvider` (default: Anthropic) for structured output.
    """

    # Tool schema for structured output via Anthropic tool use
    _TOOL_SCHEMA = {
        "name": "generate_playwright_code",
        "description": "Generate structured Playwright Java code from Selenium source.",
        "input_schema": {
            "type": "object",
            "required": [
                "package_name",
                "imports",
                "class_declaration",
                "fields",
                "constructor",
                "methods",
            ],
            "properties": {
                "package_name": {
                    "type": "string",
                    "description": (
                        "Java package name for the GENERATED file. "
                        "MUST end with '.playwright'. "
                        "Example: if original is 'com.example.pages', "
                        "use 'com.example.pages.playwright'."
                    ),
                },
                "imports": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Required import statements",
                },
                "class_declaration": {
                    "type": "string",
                    "description": "Class signature with extends/implements",
                },
                "fields": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Class field declarations",
                },
                "constructor": {
                    "type": "string",
                    "description": "Constructor with Page injection",
                },
                "methods": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "signature", "implementation"],
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Method name",
                            },
                            "signature": {
                                "type": "string",
                                "description": "Full method signature",
                            },
                            "implementation": {
                                "type": "string",
                                "description": "Complete method implementation",
                            },
                            "migration_note": {
                                "type": "string",
                                "description": "Note about migration changes",
                            },
                        },
                    },
                    "description": "Method implementations",
                },
            },
        },
    }

    def __init__(
        self,
        config: CoderConfig | None = None,
        *,
        llm_provider: LLMProvider | None = None,
    ) -> None:
        """
        Initialize coder agent.

        Args:
            config: CoderConfig with model / temperature / max_tokens.
            llm_provider: Optional pre-built LLMProvider. If None, builds
                an AnthropicProvider using `config.model` (back-compat path).

        Injecting an LLMProvider lets the pipeline choose any provider
        (OpenAI, Ollama, FakeProvider for tests) without the agent caring.
        """
        self.config = config or CoderConfig()
        self.model = self.config.model

        if llm_provider is None:
            # Back-compat: construct Anthropic as the default so v0.3.x
            # callers keep working unchanged.
            from qamigrate.llm.providers.anthropic import AnthropicProvider
            llm_provider = AnthropicProvider(model=self.model)
        self.provider: LLMProvider = llm_provider

    # Back-compat shims. The real implementations live in
    # `qamigrate.llm.sanitize` so every provider benefits equally.
    # Keeping these as classmethods so v0.3.x callers and older tests
    # keep working.

    @staticmethod
    def _unescape_llm_string(value: Any) -> Any:
        from qamigrate.llm.sanitize import unescape_llm_string
        return unescape_llm_string(value)

    @classmethod
    def _sanitize_fields(cls, data: dict) -> dict:
        from qamigrate.llm.sanitize import sanitize_fields
        return sanitize_fields(data)

    @classmethod
    def _dict_to_playwright_code(cls, data: dict[str, Any]) -> PlaywrightCode:
        """
        Build a PlaywrightCode model from a provider-returned dict.

        The dict comes from `LLMProvider.generate_structured()` and has
        already been run through the provider's sanitizer. This helper
        does the type coercion into our Pydantic model -- it's the only
        place that knows the tool schema -> PlaywrightCode mapping.
        """
        methods = [
            MethodDefinition(
                name=m["name"],
                signature=m["signature"],
                implementation=m["implementation"],
                migration_note=m.get("migration_note"),
            )
            for m in data.get("methods", [])
        ]
        return PlaywrightCode(
            package_name=data["package_name"],
            imports=data["imports"],
            class_declaration=data["class_declaration"],
            fields=data["fields"],
            constructor=data["constructor"],
            methods=methods,
        )

    def generate(self, utom: dict[str, Any], original_code: str) -> PlaywrightCode:
        """
        Generate Playwright code from UTOM representation.

        Args:
            utom: UTOM JSON representation of the test/page object
            original_code: Original Selenium source code

        Returns:
            PlaywrightCode structured output
        """
        logger.info(
            "Generating Playwright code",
            test_id=utom.get("test_id") or utom.get("page_id"),
        )

        prompt = self._build_prompt(utom, original_code)
        tool = _coder_tool_schema()

        try:
            response = self.provider.generate_structured(
                system=SYSTEM_PROMPT,
                user=prompt,
                tool=tool,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
            )
            result = self._dict_to_playwright_code(response.data)
            logger.info(
                "Code generation successful",
                provider=response.provider,
                model=response.model,
            )
            return result

        except Exception as e:
            logger.error("Code generation failed", error=str(e))
            raise

    def generate_from_class_info(
        self,
        class_info: dict[str, Any],
        original_code: str,
        patterns: list[dict[str, Any]],
        sibling_signatures: dict[str, list[str]] | None = None,
        project_context: str | None = None,
        target_framework: str = "junit5",
    ) -> PlaywrightCode:
        """
        Generate Playwright code directly from class info.

        Args:
            class_info: Parsed class information from Scanner
            original_code: Original Selenium source code
            patterns: Detected Selenium patterns
            sibling_signatures: Optional map of {class_name: [method_signature, ...]}
                for sibling classes already migrated in this run. Lets the
                Coder call the real methods on the generated Playwright
                classes instead of inventing names.
            project_context: Optional pre-formatted project intelligence
                block (from qamigrate.intelligence.prompt_context). When
                supplied, it's prepended to the prompt so the LLM knows
                the project's conventions, infrastructure, and siblings.

        Returns:
            PlaywrightCode structured output
        """
        # Build context from class info
        context = {
            "class_name": class_info.get("class_name"),
            "package": class_info.get("package"),
            "is_page_object": any(
                "@FindBy" in str(f.get("annotations", [])) for f in class_info.get("fields", [])
            ),
            "methods": class_info.get("methods", []),
            "fields": class_info.get("fields", []),
            "patterns_detected": [p.get("pattern_type") for p in patterns],
        }

        sibling_block = ""
        if sibling_signatures:
            lines = [
                "## STRICT: Available methods on sibling classes",
                "",
                "These are the ONLY methods you may call on objects of these",
                "classes. If you need behavior that isn't listed, either use",
                "Playwright APIs directly on the Page/Locator, or skip that",
                "assertion. DO NOT invent method names that are not in this",
                "list -- invented methods will cause compile errors.",
                "",
                "⚠️ IMPORT RULE: Each class below has been migrated to a",
                "`.playwright` sub-package. When you import any of them,",
                "append `.playwright` to the package path shown in the Class",
                "Context block. Example: `com.example.pages.LoginPage` →",
                "`import com.example.pages.playwright.LoginPage;`.",
                "",
            ]
            for cls, sigs in sibling_signatures.items():
                lines.append(f"### class {cls}")
                if not sigs:
                    lines.append("(no public methods)")
                else:
                    for sig in sigs:
                        lines.append(f"  {sig}")
                lines.append("")
            sibling_block = "\n".join(lines)

        # Escape any stray triple-backticks in the user's source so they
        # can't break out of the code fence we embed them in below. This
        # isn't a security fix (users migrate their own files) -- it's a
        # robustness fix so files containing ``` in text blocks don't
        # confuse the model.
        safe_original_code = escape_for_code_fence(original_code)

        # v0.5+: the project intelligence block tells the LLM about the
        # whole project's conventions, infrastructure, and how this file
        # relates to its siblings. The block can be empty for projects
        # without detected conventions (e.g. a single-file sample).
        intelligence_block = (project_context or "").strip()
        if intelligence_block:
            intelligence_block = intelligence_block + "\n\n"

        # Framework-specific note for requirement 6 in the prompt.
        if target_framework == "testng":
            framework_note = (
                "**Keep all TestNG annotations unchanged** — this project stays "
                "on TestNG. Do NOT emit @BeforeEach, @AfterEach, @ExtendWith or "
                "any org.junit.* import. @DataProvider and @Parameters are "
                "preserved verbatim. For UI assertions use Playwright "
                "assertThat(locator); for value assertions keep TestNG Assert.*."
            )
        elif target_framework == "junit4":
            framework_note = (
                "This class is migrated from TestNG to **JUnit 4**. "
                "@BeforeMethod → @Before, @AfterMethod → @After, "
                "@BeforeClass → @BeforeClass static, @AfterClass → @AfterClass static, "
                "@Test stays @Test (org.junit.Test). Use junit.Assert for values."
            )
        else:
            framework_note = (
                "If this is a test class being migrated from TestNG to JUnit 5: "
                "`@Test(priority=..., description=\"X\")` becomes `@Test` plus "
                "`@DisplayName(\"X\")` on a separate line. JUnit 5 `@Test` takes NO "
                "arguments. `Assert.assertTrue(cond, \"msg\")` becomes "
                "`org.junit.jupiter.api.Assertions.assertTrue(cond, \"msg\")` or a "
                "Playwright `assertThat(...)` call. "
                "`@BeforeMethod` → `@BeforeEach`; `@AfterMethod` → `@AfterEach`; "
                "`@BeforeClass` → `@BeforeAll static`; `@AfterClass` → `@AfterAll static`."
            )

        prompt = "Convert this Selenium Java class to Playwright Java.\n\n"
        prompt += f"""

{intelligence_block}## Class Context
```json
{json.dumps(context, indent=2)}
```

## Original Selenium Code
```java
{safe_original_code}
```

## Detected Patterns Requiring Migration
{chr(10).join(f"- {p.get('pattern_type')}: {p.get('migration_strategy')}" for p in patterns[:10])}

{sibling_block}

## Requirements
1. Generate complete, compilable Playwright Java code.
2. Preserve all business logic and test intent.
3. Use Page Object pattern with constructor injection.
4. Only call methods that exist on Playwright types OR in the sibling
   signatures above. NEVER invent methods like `getSuccessIndicator()` or
   `getErrorElement()` just because they would be convenient -- if the
   sibling does not expose that method, use Playwright APIs on `page`
   directly (e.g. `assertThat(page.locator(selector)).isVisible()`).
5. **Prefer inherited helpers over infrastructure classes.** If this
   class extends a base class (BaseTest, BasePage, etc.) and that base
   class exposes a helper like `getPage()`, `getDriver()`, `getBrowser()`,
   or `getContext()`, call the INHERITED helper directly. Do NOT reach
   into `DriverManager.getPage()`, `ThreadLocalDriver.get()`, or any
   static-factory style access when an inherited method exists for the
   same thing. The base class owns the lifecycle; calling through
   DriverManager in a subclass bypasses that and breaks per-test
   isolation. Example: inside a test that extends BaseTest with
   `protected Page getPage()`, write `getPage().locator(...)`, NOT
   `DriverManager.getPage().locator(...)`.
6. {framework_note}
7. **Import paths for sibling classes MUST use the `.playwright` suffix.**
   Every class listed in the sibling signatures above has been migrated
   into a `.playwright` sub-package. When you import any of them, append
   `.playwright` to their package:
   - `import com.example.pages.LoginPage;`
     → `import com.example.pages.playwright.LoginPage;`
   - `import com.example.browser.BrowserFactory;`
     → `import com.example.browser.playwright.BrowserFactory;`
   The package in the `## Class Context` block shows the ORIGINAL package.
   Always add `.playwright` when importing sibling project classes.
   Do NOT add `.playwright` to Playwright API imports
   (`com.microsoft.playwright.*`), JUnit, or any third-party library.
8. Add migration comments for significant changes.
9. Follow Playwright Java idioms.

Generate the Playwright code now using the generate_playwright_code tool."""

        tool = _coder_tool_schema()

        try:
            response = self.provider.generate_structured(
                system=_build_system_prompt(target_framework),
                user=prompt,
                tool=tool,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
            )
            return self._dict_to_playwright_code(response.data)

        except Exception as e:
            logger.error("Code generation failed", error=str(e))
            raise

    def _build_prompt(self, utom: dict[str, Any], original_code: str) -> str:
        """Construct the generation prompt with full context."""
        safe_original_code = escape_for_code_fence(original_code)
        return f"""Convert this Selenium test to Playwright Java.

## UTOM (Universal Test Object Model)
```json
{json.dumps(utom, indent=2)}
```

## Original Selenium Code
```java
{safe_original_code}
```

## Requirements
1. Generate complete, compilable Playwright Java code
2. Preserve all test logic and assertions
3. Use Page Object pattern with constructor injection
4. Add migration comments for significant changes
5. Follow Playwright Java idioms
6. Generate EXACTLY ONE constructor - no duplicates
7. Generate each method EXACTLY ONCE - no repeated implementations

Generate the Playwright code now."""

    def validate_generated_code(self, code: PlaywrightCode) -> list[str]:
        """
        Validate generated code for common issues.
        
        Returns:
            List of error messages, empty if valid
        """
        errors: list[str] = []

        # Check for duplicate method names
        method_names = [m.name for m in code.methods]
        seen_methods = set()
        for name in method_names:
            if name in seen_methods:
                errors.append(f"Duplicate method: {name}")
            seen_methods.add(name)

        # Check constructor for duplicates (multiple constructor definitions)
        constructor_count = code.constructor.count("public " + code.class_declaration.split()[-1].rstrip("{").strip() + "(")
        if constructor_count > 1:
            errors.append(f"Multiple constructor definitions found: {constructor_count}")

        # Check for unmatched braces in constructor
        open_braces = code.constructor.count("{")
        close_braces = code.constructor.count("}")
        if open_braces != close_braces:
            errors.append(f"Unmatched braces in constructor: {open_braces} open, {close_braces} close")

        # Check each method for unmatched braces
        for method in code.methods:
            open_b = method.implementation.count("{")
            close_b = method.implementation.count("}")
            if open_b != close_b:
                errors.append(f"Unmatched braces in method {method.name}: {open_b} open, {close_b} close")

        return errors

    @staticmethod
    def extract_signatures(code: "PlaywrightCode") -> list[str]:
        """Return the public method signatures (including constructor) of a generated class."""
        sigs: list[str] = []
        ctor = code.constructor.strip()
        # pull first line as the constructor signature
        first_line = ctor.split("\n", 1)[0].strip().rstrip("{").strip()
        if first_line:
            sigs.append(first_line)
        for m in code.methods:
            sig = m.signature.strip()
            # If the signature is just an annotation, merge with implementation's first line
            if sig.startswith("@") and "\n" not in sig:
                impl_first = m.implementation.strip().split("\n", 1)[0].strip().rstrip("{").strip()
                sigs.append(f"{sig} {impl_first}")
            else:
                # strip trailing { if any, split newlines
                for line in sig.split("\n"):
                    line = line.strip().rstrip("{").strip()
                    if line:
                        sigs.append(line)
        return sigs

    @staticmethod
    def _reindent_block(text: str, base_indent: int = 1) -> list[str]:
        """
        Reindent a Java code block using brace-depth tracking.

        Args:
            text: Java source code block (constructor, method, etc.)
            base_indent: Starting indent level (1 = class member level = 4 spaces)

        Returns:
            List of properly indented lines
        """
        # Defensive: LLMs sometimes emit literal `\n` (backslash-n, two chars)
        # inside JSON tool_use string fields instead of real newlines, which
        # collapses the whole block onto one line. Unescape them so we can
        # reindent properly.
        if "\\n" in text and "\n" not in text:
            text = text.replace("\\n", "\n").replace("\\t", "\t").replace('\\"', '"')

        result: list[str] = []
        depth = base_indent

        for raw_line in text.split("\n"):
            stripped = raw_line.strip()
            if not stripped:
                continue

            # Closing brace decreases depth before printing
            close_count = stripped.count("}")
            open_count = stripped.count("{")

            # Lines that start with } should be at the outer depth
            if stripped.startswith("}"):
                depth -= 1

            indent = "    " * max(depth, 0)
            result.append(f"{indent}{stripped}")

            # Adjust depth after the line
            depth += open_count - close_count
            # If we already decremented for a leading }, undo the double-count
            if stripped.startswith("}"):
                depth += 1  # we pre-decremented, the close_count handles it

        return result

    def assemble_file(self, code: PlaywrightCode) -> str:
        """
        Assemble structured output into complete Java file.
        Includes deduplication logic to prevent common LLM output issues.

        Args:
            code: PlaywrightCode structured output

        Returns:
            Complete Java source file as string
        """
        lines: list[str] = []

        # Package declaration.
        # v0.5.3: generated files live in a .playwright sub-package so they
        # don't collide with the original Selenium classes during mvn compile.
        # The LLM is instructed to append .playwright, but we enforce it here
        # as a safety net so a mistaken LLM response can't produce duplicate
        # class errors.
        pkg = code.package_name
        if pkg and not pkg.endswith(".playwright"):
            pkg = f"{pkg}.playwright"
        lines.append(f"package {pkg};")
        lines.append("")

        # Deduplicate imports
        unique_imports = []
        seen_imports = set()
        for imp in code.imports:
            # Normalize import
            if not imp.startswith("import "):
                imp = f"import {imp}"
            if not imp.endswith(";"):
                imp = f"{imp};"

            # Extract the import path for deduplication
            import_path = imp.replace("import ", "").replace(";", "").strip()
            if import_path not in seen_imports:
                seen_imports.add(import_path)
                unique_imports.append(imp)

        for imp in unique_imports:
            lines.append(imp)
        lines.append("")

        # Class declaration - ensure no duplicates
        class_decl = code.class_declaration.strip()
        if not class_decl.endswith("{"):
            lines.append(class_decl + " {")
        else:
            lines.append(class_decl)
        lines.append("")

        # Deduplicate fields
        unique_fields = []
        seen_field_names = set()
        for field_def in code.fields:
            # Extract field name (last word before = or ;)
            field_parts = field_def.replace(";", "").replace("=", " ").split()
            field_name = field_parts[-1] if field_parts else field_def

            if field_name not in seen_field_names:
                seen_field_names.add(field_name)
                field_line = field_def.strip()
                if not field_line.endswith(";"):
                    field_line += ";"
                unique_fields.append(field_line)

        for field_def in unique_fields:
            lines.append(f"    {field_def}")
        if unique_fields:
            lines.append("")

        # Constructor - reindent using brace-depth tracking
        lines.extend(self._reindent_block(code.constructor, base_indent=1))
        lines.append("")

        # Deduplicate methods
        seen_method_names = set()
        for method in code.methods:
            if method.name in seen_method_names:
                logger.warning(f"Skipping duplicate method: {method.name}")
                continue
            seen_method_names.add(method.name)

            if method.migration_note:
                lines.append(f"    // Migration: {method.migration_note}")

            # Build full method text: signature + implementation
            impl = method.implementation.strip()
            sig = method.signature.strip() if method.signature else ""

            # If implementation doesn't start with a method keyword or annotation,
            # it's just the body -- prepend the signature.
            impl_starts_with_sig = (
                impl.startswith("public ")
                or impl.startswith("private ")
                or impl.startswith("protected ")
                or impl.startswith("static ")
                or impl.startswith("void ")
                or impl.startswith("@")
            )

            if not impl_starts_with_sig and sig:
                full_method = f"{sig} {impl}"
            else:
                full_method = impl

            lines.extend(self._reindent_block(full_method, base_indent=1))
            lines.append("")

        lines.append("}")

        return "\n".join(lines)

    def save_generated_code(
        self,
        code: PlaywrightCode,
        output_path: Path,
    ) -> Path:
        """
        Save generated code to file.

        Args:
            code: PlaywrightCode structured output
            output_path: Path to save the file

        Returns:
            Path to the saved file
        """
        content = self.assemble_file(code)

        # Ensure directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Write file
        output_path.write_text(content, encoding="utf-8")

        logger.info("Saved generated code", path=str(output_path))
        return output_path
