use bytes::Bytes;
use flate2::write::GzEncoder;
use flate2::Compression;
use http_body_util::{BodyExt, Full};
use hyper::body::Body as HyperBody;
use hyper::body::Incoming;
use hyper::header::{
    HeaderName, HeaderValue, CONNECTION, CONTENT_ENCODING, CONTENT_LENGTH, CONTENT_TYPE,
};
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::{Request as HyperRequest, Response as HyperResponse, StatusCode};
use hyper_util::rt::TokioIo;
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyBytes, PyDict, PyDictMethods, PyFrozenSet, PyList, PySet, PyTuple};
use serde_json::{Map as JsonMap, Value as JsonValue};
use socket2::{Domain, Protocol, Socket, Type};
use std::cell::RefCell;
use std::collections::HashMap;
use std::convert::Infallible;
use std::fs;
use std::future::pending;
#[cfg(test)]
use std::io::Read;
use std::io::Write;
use std::net::{SocketAddr, TcpListener, ToSocketAddrs};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::task::{Context, Poll, Waker};
use std::thread;
use tokio::net::TcpListener as TokioTcpListener;
use tokio::sync::Notify;
use tokio::time::{timeout, Duration};

struct ThreadLocalAsyncioLoop {
    loop_obj: Option<Py<PyAny>>,
}

impl Drop for ThreadLocalAsyncioLoop {
    fn drop(&mut self) {
        let Some(loop_obj) = self.loop_obj.take() else {
            return;
        };
        Python::try_attach(|py| {
            let loop_obj = loop_obj.bind(py);
            let _ = loop_obj.call_method0("close");
        });
    }
}

thread_local! {
    static PY_ASYNCIO_LOOP: RefCell<ThreadLocalAsyncioLoop> = const { RefCell::new(ThreadLocalAsyncioLoop { loop_obj: None }) };
}

#[pyfunction]
fn core_version() -> &'static str {
    "0.1.1"
}

#[pyfunction]
fn match_route(pattern: &str, path: &str) -> Option<HashMap<String, String>> {
    match_route_inner(pattern, path).map(|captures| captures.into_iter().collect())
}

#[pyfunction]
fn parse_query_string(query: &str) -> HashMap<String, Vec<String>> {
    parse_query_string_inner(query)
        .into_iter()
        .fold(HashMap::new(), |mut params, (key, value)| {
            params.entry(key).or_default().push(value);
            params
        })
}

#[pyfunction]
fn normalize_headers(headers: Vec<(String, String)>) -> Vec<(String, Vec<String>)> {
    normalize_headers_inner(headers)
}

#[pyfunction]
fn parse_cookie_header(header: &str) -> HashMap<String, String> {
    parse_cookie_header_inner(header).into_iter().collect()
}

#[pyfunction]
fn serve_once(app: Py<PyAny>, host: &str, port: u16) -> PyResult<u16> {
    serve(app, host, port, 1)
}

#[pyfunction]
fn serve(app: Py<PyAny>, host: &str, port: u16, max_requests: usize) -> PyResult<u16> {
    raise_file_descriptor_limit();
    let listener = bind_tcp_listener(host, port)?;
    let bound_port = listener.local_addr()?.port();
    listener.set_nonblocking(true)?;
    let fast_path = build_fast_path_registry(&app);
    thread::spawn(move || run_http_server(app, fast_path, listener, max_requests));
    Ok(bound_port)
}

#[pyfunction]
fn dispatch_raw(
    app: Py<PyAny>,
    method: &str,
    target: &str,
    headers: Vec<(String, String)>,
    body: Option<Vec<u8>>,
) -> PyResult<(u16, Vec<(String, String)>, Vec<u8>, bool)> {
    let fast_path = build_fast_path_registry(&app);
    let state = ServerState {
        fast_path,
        app,
        max_requests: 0,
        served: AtomicUsize::new(0),
        active_connections: AtomicUsize::new(0),
        shutdown: Notify::new(),
        drained: Notify::new(),
    };
    let request = HttpRequest {
        method: method.to_string(),
        target: target.to_string(),
        headers,
        body,
    };
    let (response, used_fast_path) =
        if let Some(response) = try_fast_path_response(&state, &request) {
            (response, true)
        } else {
            (dispatch_http_response(&state.app, request)?, false)
        };
    hyper_response_parts(response, used_fast_path)
}

#[cfg(unix)]
fn raise_file_descriptor_limit() {
    const TARGET_NOFILE: libc::rlim_t = 4096;
    let mut limit = libc::rlimit {
        rlim_cur: 0,
        rlim_max: 0,
    };
    // SAFETY: getrlimit and setrlimit are called with a valid pointer to a stack
    // allocated rlimit struct. Failure is non-fatal; the server can still bind.
    unsafe {
        if libc::getrlimit(libc::RLIMIT_NOFILE, &mut limit) != 0 {
            return;
        }
        if limit.rlim_cur >= TARGET_NOFILE {
            return;
        }
        let desired = TARGET_NOFILE.min(limit.rlim_max);
        if desired > limit.rlim_cur {
            limit.rlim_cur = desired;
            let _ = libc::setrlimit(libc::RLIMIT_NOFILE, &limit);
        }
    }
}

#[cfg(not(unix))]
fn raise_file_descriptor_limit() {}

fn bind_tcp_listener(host: &str, port: u16) -> std::io::Result<TcpListener> {
    let address = (host, port).to_socket_addrs()?.next().ok_or_else(|| {
        std::io::Error::new(std::io::ErrorKind::AddrNotAvailable, "no socket address")
    })?;
    let domain = match address {
        SocketAddr::V4(_) => Domain::IPV4,
        SocketAddr::V6(_) => Domain::IPV6,
    };
    let socket = Socket::new(domain, Type::STREAM, Some(Protocol::TCP))?;
    socket.set_reuse_address(true)?;
    socket.bind(&address.into())?;
    socket.listen(4096)?;
    Ok(socket.into())
}

#[pymodule]
fn _superduperfastapi_core(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(core_version, module)?)?;
    module.add_function(wrap_pyfunction!(match_route, module)?)?;
    module.add_function(wrap_pyfunction!(parse_query_string, module)?)?;
    module.add_function(wrap_pyfunction!(normalize_headers, module)?)?;
    module.add_function(wrap_pyfunction!(parse_cookie_header, module)?)?;
    module.add_function(wrap_pyfunction!(serve_once, module)?)?;
    module.add_function(wrap_pyfunction!(serve, module)?)?;
    module.add_function(wrap_pyfunction!(dispatch_raw, module)?)?;
    Ok(())
}

struct HttpRequest {
    method: String,
    target: String,
    headers: Vec<(String, String)>,
    body: Option<Vec<u8>>,
}

struct FastPathRegistry {
    routes: Vec<FastPathRoute>,
    route_index: RouteIndex,
    has_body_routes: bool,
    middleware: Vec<FastPathMiddleware>,
    static_mounts: Vec<FastPathStaticMount>,
}

struct FastPathStaticMount {
    prefix: String,
    directory: PathBuf,
}

struct RouteIndex {
    root: RouteIndexNode,
}

#[derive(Default)]
struct RouteIndexNode {
    static_children: HashMap<String, RouteIndexNode>,
    param_children: Vec<RouteIndexParamChild>,
    path_param_routes: Vec<RouteIndexPathParamRoute>,
    route_indices: Vec<usize>,
}

struct RouteIndexParamChild {
    name: String,
    node: RouteIndexNode,
}

struct RouteIndexPathParamRoute {
    name: String,
    route_index: usize,
}

struct RouteIndexMatch {
    route_index: usize,
    path_params: Vec<(String, String)>,
}

struct FastPathRoute {
    path: String,
    methods: Vec<String>,
    route_index: usize,
    has_user_middleware: bool,
    has_custom_asgi_middleware: bool,
    endpoint: Py<PyAny>,
    endpoint_is_async: bool,
    status_code: u16,
    params: Vec<FastPathParam>,
    dependencies: Vec<FastPathDependency>,
    response_param: Option<String>,
    response_state_class: Py<PyAny>,
    request_param: Option<String>,
    request_class: Py<PyAny>,
    headers_class: Py<PyAny>,
    app: Py<PyAny>,
    app_state: Py<PyAny>,
    background_tasks_param: Option<String>,
    background_tasks_class: Py<PyAny>,
    response_class: Py<PyAny>,
    body_param: Option<FastPathBodyParam>,
    response_model: Option<FastPathResponseModel>,
    response_kind: FastPathResponseKind,
    static_body: Option<Vec<u8>>,
    needs_background_tasks: bool,
    needs_request: bool,
    needs_form: bool,
}

struct FastPathDependency {
    target: Option<String>,
    call: Py<PyAny>,
    call_is_async: bool,
    call_is_yield: bool,
    call_is_async_yield: bool,
    params: Vec<FastPathParam>,
    dependencies: Vec<FastPathDependency>,
    background_tasks_param: Option<String>,
    request_param: Option<String>,
    security_scopes_param: Option<String>,
    security_scopes_class: Py<PyAny>,
    security_scopes: Vec<String>,
    uses_security_scopes: bool,
    needs_background_tasks: bool,
    needs_request: bool,
    needs_form: bool,
    cleanup_scope: String,
    use_cache: bool,
    cache_key: usize,
}

struct FastPathDependencyFinalizer {
    finalizer: Py<PyAny>,
    is_async: bool,
    cleanup_scope: String,
}

struct FastPathBodyParam {
    name: String,
    adapter: Py<PyAny>,
    validator: Option<Py<PyAny>>,
}

struct FastPathResponseModel {
    adapter: Py<PyAny>,
    validator: Option<Py<PyAny>>,
    serializer: Option<Py<PyAny>>,
    validate_kwargs: Py<PyDict>,
    dump_kwargs: Py<PyDict>,
}

enum FastPathResponseKind {
    Json,
    Html,
    PlainText,
    Redirect,
    Streaming,
    File,
}

enum FastPathMiddleware {
    Cors(FastPathCorsMiddleware),
    GZip(FastPathGZipMiddleware),
    HttpsRedirect,
    TrustedHost(FastPathTrustedHostMiddleware),
}

struct FastPathCorsMiddleware {
    allow_origins: Vec<String>,
    allow_methods: Vec<String>,
    allow_headers: Vec<String>,
    allow_credentials: bool,
}

struct FastPathTrustedHostMiddleware {
    allowed_hosts: Vec<String>,
}

struct FastPathGZipMiddleware {
    minimum_size: usize,
    compresslevel: u32,
}

struct FastPathParam {
    name: String,
    source: FastPathParamSource,
    wire_name: String,
    kind: FastPathParamKind,
    required: bool,
    default: Option<Py<PyAny>>,
    upload_file_class: Option<Py<PyAny>>,
}

#[derive(Clone, Copy)]
enum FastPathParamSource {
    Path,
    Query,
    Header,
    Cookie,
    Form,
}

#[derive(Clone, Copy)]
enum FastPathParamKind {
    Str,
    Bytes,
    UploadFile,
    ListBytes,
    ListUploadFile,
    Int,
    Float,
    Bool,
}

struct MultipartPart {
    content: Vec<u8>,
    filename: Option<String>,
    content_type: Option<String>,
}

struct FastPathParamFailure {
    source: FastPathParamSource,
    wire_name: String,
    issue: FastPathParamIssue,
}

enum FastPathParamIssue {
    Missing,
    Parsing {
        raw_value: String,
        kind: FastPathParamKind,
    },
}

fn run_http_server(
    app: Py<PyAny>,
    fast_path: Option<FastPathRegistry>,
    listener: TcpListener,
    max_requests: usize,
) {
    let runtime = match tokio::runtime::Builder::new_multi_thread()
        .worker_threads(16)
        .max_blocking_threads(1024)
        .enable_all()
        .build()
    {
        Ok(runtime) => runtime,
        Err(_) => return,
    };
    runtime.block_on(async move {
        let listener = match TokioTcpListener::from_std(listener) {
            Ok(listener) => listener,
            Err(_) => return,
        };
        let state = Arc::new(ServerState {
            fast_path,
            app,
            max_requests,
            served: AtomicUsize::new(0),
            active_connections: AtomicUsize::new(0),
            shutdown: Notify::new(),
            drained: Notify::new(),
        });
        run_tokio_http_server(listener, state).await;
    });
}

struct ServerState {
    fast_path: Option<FastPathRegistry>,
    app: Py<PyAny>,
    max_requests: usize,
    served: AtomicUsize,
    active_connections: AtomicUsize,
    shutdown: Notify,
    drained: Notify,
}

impl ServerState {
    fn should_stop(&self) -> bool {
        self.max_requests > 0 && self.served.load(Ordering::SeqCst) >= self.max_requests
    }

    fn mark_served(&self) -> bool {
        if self.max_requests == 0 {
            self.served.fetch_add(1, Ordering::SeqCst);
            return false;
        }
        let served = self.served.fetch_add(1, Ordering::SeqCst) + 1;
        if served >= self.max_requests {
            self.shutdown.notify_waiters();
            true
        } else {
            false
        }
    }

    fn connection_started(&self) {
        self.active_connections.fetch_add(1, Ordering::SeqCst);
    }

    fn connection_finished(&self) {
        let active = self.active_connections.fetch_sub(1, Ordering::SeqCst) - 1;
        if active == 0 && self.should_stop() {
            self.drained.notify_waiters();
        }
    }
}

struct ConnectionGuard {
    state: Arc<ServerState>,
}

impl ConnectionGuard {
    fn new(state: Arc<ServerState>) -> Self {
        state.connection_started();
        Self { state }
    }
}

impl Drop for ConnectionGuard {
    fn drop(&mut self) {
        self.state.connection_finished();
    }
}

async fn run_tokio_http_server(listener: TokioTcpListener, state: Arc<ServerState>) {
    let listener = Arc::new(listener);
    for _ in 0..16 {
        let accept_listener = Arc::clone(&listener);
        let accept_state = Arc::clone(&state);
        tokio::spawn(async move {
            accept_loop(accept_listener, accept_state).await;
        });
    }
    if state.max_requests == 0 {
        pending::<()>().await;
    } else {
        state.shutdown.notified().await;
        while state.active_connections.load(Ordering::SeqCst) > 0 {
            state.drained.notified().await;
        }
    }
}

async fn accept_loop(listener: Arc<TokioTcpListener>, state: Arc<ServerState>) {
    loop {
        if state.should_stop() {
            break;
        }
        let Ok(result) = timeout(Duration::from_millis(100), listener.accept()).await else {
            continue;
        };
        let Ok((stream, _peer_addr)) = result else {
            continue;
        };
        let _ = stream.set_nodelay(true);
        let connection_state = Arc::clone(&state);
        tokio::spawn(async move {
            let _guard = ConnectionGuard::new(Arc::clone(&connection_state));
            let service = service_fn(move |request| {
                handle_hyper_request(request, Arc::clone(&connection_state))
            });
            if let Err(error) = http1::Builder::new()
                .half_close(true)
                .keep_alive(true)
                .max_buf_size(128 * 1024)
                .pipeline_flush(true)
                .serve_connection(TokioIo::new(stream), service)
                .await
            {
                eprintln!("superduperfastapi connection error: {error}");
            }
        });
        if state.should_stop() {
            break;
        }
    }
}

async fn handle_hyper_request(
    request: HyperRequest<Incoming>,
    state: Arc<ServerState>,
) -> Result<HyperResponse<Full<Bytes>>, Infallible> {
    let request_wants_close = hyper_request_wants_close(&request);
    let request = match hyper_to_http_request(request).await {
        Ok(request) => request,
        Err(error) => {
            return Ok(error_response(
                StatusCode::BAD_REQUEST,
                format!("Bad Request: {error}"),
                true,
            ));
        }
    };
    if let Some(response) = try_fast_path_response(&state, &request) {
        let is_last_response = state.mark_served();
        return Ok(with_connection_policy(
            response,
            request_wants_close || is_last_response,
        ));
    }
    let app = Python::attach(|py| state.app.clone_ref(py));
    let response = tokio::task::spawn_blocking(move || dispatch_http_response(&app, request))
        .await
        .unwrap_or_else(|error| {
            Ok(error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                format!("Internal Server Error: {error}"),
                true,
            ))
        })
        .unwrap_or_else(|error| {
            error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                format!("Internal Server Error: {error}"),
                true,
            )
        });
    let is_last_response = state.mark_served();
    Ok(with_connection_policy(
        response,
        request_wants_close || is_last_response,
    ))
}

fn build_fast_path_registry(app: &Py<PyAny>) -> Option<FastPathRegistry> {
    Python::attach(|py| {
        let specs = app
            .bind(py)
            .call_method0("__superduperfastapi_rust_route_specs__")
            .ok()?;
        let middleware_specs = app
            .bind(py)
            .call_method0("__superduperfastapi_rust_middleware_specs__")
            .ok()?;
        let mount_specs = app
            .bind(py)
            .call_method0("__superduperfastapi_rust_mount_specs__")
            .ok()?;
        let mut middleware = Vec::new();
        for spec in middleware_specs.try_iter().ok()? {
            middleware.push(parse_fast_path_middleware(spec.ok()?)?);
        }
        let mut static_mounts = Vec::new();
        for spec in mount_specs.try_iter().ok()? {
            static_mounts.push(parse_fast_path_mount(spec.ok()?)?);
        }
        let mut routes = Vec::new();
        for spec in specs.try_iter().ok()? {
            let spec = spec.ok()?;
            let path = spec.get_item("path").ok()?.extract::<String>().ok()?;
            let methods = spec
                .get_item("methods")
                .ok()?
                .extract::<Vec<String>>()
                .ok()?;
            let route_index = spec.get_item("route_index").ok()?.extract::<usize>().ok()?;
            let has_user_middleware = spec
                .get_item("has_user_middleware")
                .ok()?
                .extract::<bool>()
                .ok()?;
            let has_custom_asgi_middleware = spec
                .get_item("has_custom_asgi_middleware")
                .ok()
                .and_then(|value| value.extract::<bool>().ok())
                .unwrap_or(false);
            let endpoint = spec.get_item("endpoint").ok()?.unbind();
            let endpoint_is_async = spec
                .get_item("endpoint_is_async")
                .ok()?
                .extract::<bool>()
                .ok()?;
            let status_code = spec.get_item("status_code").ok()?.extract::<u16>().ok()?;
            let response_param = spec
                .get_item("response_param")
                .ok()
                .and_then(|value| (!value.is_none()).then(|| value.extract::<String>().ok()))
                .flatten();
            let response_state_class = spec.get_item("response_state_class").ok()?.unbind();
            let request_param = spec
                .get_item("request_param")
                .ok()
                .and_then(|value| (!value.is_none()).then(|| value.extract::<String>().ok()))
                .flatten();
            let request_class = spec.get_item("request_class").ok()?.unbind();
            let headers_class = spec.get_item("headers_class").ok()?.unbind();
            let app = spec.get_item("app").ok()?.unbind();
            let app_state = spec.get_item("app_state").ok()?.unbind();
            let background_tasks_param = spec
                .get_item("background_tasks_param")
                .ok()
                .and_then(|value| (!value.is_none()).then(|| value.extract::<String>().ok()))
                .flatten();
            let background_tasks_class = spec.get_item("background_tasks_class").ok()?.unbind();
            let response_class = spec.get_item("response_class").ok()?.unbind();
            let static_body = spec
                .get_item("static_body")
                .ok()
                .and_then(|value| value.extract::<String>().ok())
                .map(String::into_bytes);
            let body_param = spec.get_item("body_param").ok().and_then(|value| {
                if value.is_none() {
                    return None;
                }
                Some(FastPathBodyParam {
                    name: value.get_item("name").ok()?.extract::<String>().ok()?,
                    adapter: value.get_item("adapter").ok()?.unbind(),
                    validator: value
                        .get_item("validator")
                        .ok()
                        .and_then(|value| (!value.is_none()).then(|| value.unbind())),
                })
            });
            let response_adapter = spec
                .get_item("response_adapter")
                .ok()
                .and_then(|value| (!value.is_none()).then(|| value.unbind()));
            let response_validator = spec
                .get_item("response_validator")
                .ok()
                .and_then(|value| (!value.is_none()).then(|| value.unbind()));
            let response_serializer = spec
                .get_item("response_serializer")
                .ok()
                .and_then(|value| (!value.is_none()).then(|| value.unbind()));
            let response_validate_kwargs =
                spec.get_item("response_validate_kwargs")
                    .ok()
                    .and_then(|value| {
                        if value.is_none() {
                            None
                        } else {
                            value.cast_into::<PyDict>().ok().map(|dict| dict.unbind())
                        }
                    });
            let response_dump_kwargs =
                spec.get_item("response_dump_kwargs")
                    .ok()
                    .and_then(|value| {
                        if value.is_none() {
                            None
                        } else {
                            value.cast_into::<PyDict>().ok().map(|dict| dict.unbind())
                        }
                    });
            let response_kind_value = spec
                .get_item("response_kind")
                .ok()?
                .extract::<String>()
                .ok()?;
            let response_kind = match response_kind_value.as_str() {
                "json" => FastPathResponseKind::Json,
                "html" => FastPathResponseKind::Html,
                "plain_text" => FastPathResponseKind::PlainText,
                "redirect" => FastPathResponseKind::Redirect,
                "streaming" => FastPathResponseKind::Streaming,
                "file" => FastPathResponseKind::File,
                _ => return None,
            };
            let response_model = response_adapter.map(|adapter| FastPathResponseModel {
                adapter,
                validator: response_validator,
                serializer: response_serializer,
                validate_kwargs: response_validate_kwargs
                    .expect("response_validate_kwargs missing"),
                dump_kwargs: response_dump_kwargs.expect("response_dump_kwargs missing"),
            });
            let mut params = Vec::new();
            let param_specs = spec.get_item("params").ok()?;
            for param in param_specs.try_iter().ok()? {
                params.push(parse_fast_path_param(param.ok()?)?);
            }
            let mut dependencies = Vec::new();
            let dependency_specs = spec.get_item("dependencies").ok()?;
            for dependency in dependency_specs.try_iter().ok()? {
                dependencies.push(parse_fast_path_dependency(dependency.ok()?)?);
            }
            let needs_background_tasks = background_tasks_param.is_some()
                || dependencies
                    .iter()
                    .any(|dependency| dependency.needs_background_tasks);
            let needs_request = has_user_middleware
                || has_custom_asgi_middleware
                || request_param.is_some()
                || dependencies
                    .iter()
                    .any(|dependency| dependency.needs_request);
            let needs_form = params
                .iter()
                .any(|param| matches!(param.source, FastPathParamSource::Form))
                || dependencies.iter().any(|dependency| dependency.needs_form);
            routes.push(FastPathRoute {
                path,
                methods,
                route_index,
                has_user_middleware,
                has_custom_asgi_middleware,
                endpoint,
                endpoint_is_async,
                status_code,
                params,
                dependencies,
                response_param,
                response_state_class,
                request_param,
                request_class,
                headers_class,
                app,
                app_state,
                background_tasks_param,
                background_tasks_class,
                response_class,
                body_param,
                response_model,
                response_kind,
                static_body,
                needs_background_tasks,
                needs_request,
                needs_form,
            });
        }
        let route_index = RouteIndex::new(&routes);
        let has_body_routes = routes
            .iter()
            .any(|route| route.body_param.is_some() || route.needs_form);
        Some(FastPathRegistry {
            routes,
            route_index,
            has_body_routes,
            middleware,
            static_mounts,
        })
    })
}

fn parse_fast_path_mount(spec: Bound<'_, PyAny>) -> Option<FastPathStaticMount> {
    let kind = spec.get_item("kind").ok()?.extract::<String>().ok()?;
    if kind != "static" {
        return None;
    }
    Some(FastPathStaticMount {
        prefix: spec.get_item("prefix").ok()?.extract::<String>().ok()?,
        directory: PathBuf::from(spec.get_item("directory").ok()?.extract::<String>().ok()?),
    })
}

fn parse_fast_path_middleware(spec: Bound<'_, PyAny>) -> Option<FastPathMiddleware> {
    let kind = spec.get_item("kind").ok()?.extract::<String>().ok()?;
    match kind.as_str() {
        "cors" => Some(FastPathMiddleware::Cors(FastPathCorsMiddleware {
            allow_origins: spec
                .get_item("allow_origins")
                .ok()?
                .extract::<Vec<String>>()
                .ok()?,
            allow_methods: spec
                .get_item("allow_methods")
                .ok()?
                .extract::<Vec<String>>()
                .ok()?,
            allow_headers: spec
                .get_item("allow_headers")
                .ok()?
                .extract::<Vec<String>>()
                .ok()?,
            allow_credentials: spec
                .get_item("allow_credentials")
                .ok()?
                .extract::<bool>()
                .ok()?,
        })),
        "https_redirect" => Some(FastPathMiddleware::HttpsRedirect),
        "trusted_host" => Some(FastPathMiddleware::TrustedHost(
            FastPathTrustedHostMiddleware {
                allowed_hosts: spec
                    .get_item("allowed_hosts")
                    .ok()?
                    .extract::<Vec<String>>()
                    .ok()?,
            },
        )),
        "gzip" => Some(FastPathMiddleware::GZip(FastPathGZipMiddleware {
            minimum_size: spec
                .get_item("minimum_size")
                .ok()?
                .extract::<usize>()
                .ok()?,
            compresslevel: spec.get_item("compresslevel").ok()?.extract::<u32>().ok()?,
        })),
        _ => None,
    }
}

fn parse_fast_path_param(param: Bound<'_, PyAny>) -> Option<FastPathParam> {
    let source_value = param.get_item("source").ok()?.extract::<String>().ok()?;
    let source = match source_value.as_str() {
        "path" => FastPathParamSource::Path,
        "query" => FastPathParamSource::Query,
        "header" => FastPathParamSource::Header,
        "cookie" => FastPathParamSource::Cookie,
        "form" => FastPathParamSource::Form,
        _ => return None,
    };
    let kind_value = param.get_item("kind").ok()?.extract::<String>().ok()?;
    let kind = match kind_value.as_str() {
        "str" => FastPathParamKind::Str,
        "bytes" => FastPathParamKind::Bytes,
        "upload_file" => FastPathParamKind::UploadFile,
        "list_bytes" => FastPathParamKind::ListBytes,
        "list_upload_file" => FastPathParamKind::ListUploadFile,
        "int" => FastPathParamKind::Int,
        "float" => FastPathParamKind::Float,
        "bool" => FastPathParamKind::Bool,
        _ => return None,
    };
    let default = param
        .get_item("default")
        .ok()
        .and_then(|value| (!value.is_none()).then(|| value.unbind()));
    let upload_file_class = param
        .get_item("upload_file_class")
        .ok()
        .and_then(|value| (!value.is_none()).then(|| value.unbind()));
    Some(FastPathParam {
        name: param.get_item("name").ok()?.extract::<String>().ok()?,
        source,
        wire_name: param.get_item("wire_name").ok()?.extract::<String>().ok()?,
        kind,
        required: param.get_item("required").ok()?.extract::<bool>().ok()?,
        default,
        upload_file_class,
    })
}

fn parse_fast_path_dependency(dependency: Bound<'_, PyAny>) -> Option<FastPathDependency> {
    let target = dependency
        .get_item("target")
        .ok()
        .and_then(|value| (!value.is_none()).then(|| value.extract::<String>().ok()))
        .flatten();
    let mut params = Vec::new();
    let param_specs = dependency.get_item("params").ok()?;
    for param in param_specs.try_iter().ok()? {
        params.push(parse_fast_path_param(param.ok()?)?);
    }
    let mut dependencies = Vec::new();
    let dependency_specs = dependency.get_item("dependencies").ok()?;
    for child in dependency_specs.try_iter().ok()? {
        dependencies.push(parse_fast_path_dependency(child.ok()?)?);
    }
    let background_tasks_param = dependency
        .get_item("background_tasks_param")
        .ok()
        .and_then(|value| (!value.is_none()).then(|| value.extract::<String>().ok()))
        .flatten();
    let request_param = dependency
        .get_item("request_param")
        .ok()
        .and_then(|value| (!value.is_none()).then(|| value.extract::<String>().ok()))
        .flatten();
    let security_scopes_param = dependency
        .get_item("security_scopes_param")
        .ok()
        .and_then(|value| (!value.is_none()).then(|| value.extract::<String>().ok()))
        .flatten();
    let security_scopes = dependency
        .get_item("security_scopes")
        .ok()
        .and_then(|value| value.extract::<Vec<String>>().ok())
        .unwrap_or_default();
    let needs_background_tasks = background_tasks_param.is_some()
        || dependencies
            .iter()
            .any(|dependency| dependency.needs_background_tasks);
    let needs_request = request_param.is_some()
        || dependencies
            .iter()
            .any(|dependency| dependency.needs_request);
    let needs_form = params
        .iter()
        .any(|param| matches!(param.source, FastPathParamSource::Form))
        || dependencies.iter().any(|dependency| dependency.needs_form);
    Some(FastPathDependency {
        target,
        call: dependency.get_item("call").ok()?.unbind(),
        call_is_async: dependency
            .get_item("call_is_async")
            .ok()?
            .extract::<bool>()
            .ok()?,
        call_is_yield: dependency
            .get_item("call_is_yield")
            .ok()
            .and_then(|value| value.extract::<bool>().ok())
            .unwrap_or(false),
        call_is_async_yield: dependency
            .get_item("call_is_async_yield")
            .ok()
            .and_then(|value| value.extract::<bool>().ok())
            .unwrap_or(false),
        params,
        dependencies,
        background_tasks_param,
        request_param,
        security_scopes_param,
        security_scopes_class: dependency.get_item("security_scopes_class").ok()?.unbind(),
        security_scopes,
        uses_security_scopes: dependency
            .get_item("uses_security_scopes")
            .ok()
            .and_then(|value| value.extract::<bool>().ok())
            .unwrap_or(false),
        needs_background_tasks,
        needs_request,
        needs_form,
        cleanup_scope: dependency
            .get_item("cleanup_scope")
            .ok()
            .and_then(|value| value.extract::<String>().ok())
            .unwrap_or_else(|| "request".to_string()),
        use_cache: dependency
            .get_item("use_cache")
            .ok()?
            .extract::<bool>()
            .ok()?,
        cache_key: dependency
            .get_item("cache_key")
            .ok()?
            .extract::<usize>()
            .ok()?,
    })
}

impl RouteIndex {
    fn new(routes: &[FastPathRoute]) -> Self {
        let mut root = RouteIndexNode::default();
        for (route_index, route) in routes.iter().enumerate() {
            root.insert(&route.path, route_index);
        }
        Self { root }
    }

    fn match_path(
        &self,
        routes: &[FastPathRoute],
        method: &str,
        path: &str,
    ) -> Option<RouteIndexMatch> {
        let segments = split_path(path);
        let mut matches = Vec::new();
        self.root
            .collect_matches(&segments, 0, &mut Vec::new(), &mut matches);
        matches
            .into_iter()
            .filter(|route_match| route_allows_method(&routes[route_match.route_index], method))
            .min_by_key(|route_match| route_match.route_index)
    }
}

impl RouteIndexNode {
    fn insert(&mut self, path: &str, route_index: usize) {
        let mut node = self;
        for segment in split_path(path) {
            if let Some((name, captures_path)) = parameter_name(segment) {
                if captures_path {
                    node.path_param_routes.push(RouteIndexPathParamRoute {
                        name: name.to_string(),
                        route_index,
                    });
                    return;
                }
                let child_index = node
                    .param_children
                    .iter()
                    .position(|child| child.name == name)
                    .unwrap_or_else(|| {
                        node.param_children.push(RouteIndexParamChild {
                            name: name.to_string(),
                            node: RouteIndexNode::default(),
                        });
                        node.param_children.len() - 1
                    });
                node = &mut node.param_children[child_index].node;
            } else {
                node = node.static_children.entry(segment.to_string()).or_default();
            }
        }
        node.route_indices.push(route_index);
    }

    fn collect_matches(
        &self,
        segments: &[&str],
        index: usize,
        captures: &mut Vec<(String, String)>,
        matches: &mut Vec<RouteIndexMatch>,
    ) {
        for route in &self.path_param_routes {
            let mut path_captures = captures.clone();
            let remainder = segments[index..].join("/");
            path_captures.push((route.name.clone(), percent_decode(&remainder)));
            matches.push(RouteIndexMatch {
                route_index: route.route_index,
                path_params: path_captures,
            });
        }

        if index == segments.len() {
            for route_index in &self.route_indices {
                matches.push(RouteIndexMatch {
                    route_index: *route_index,
                    path_params: captures.clone(),
                });
            }
            return;
        }

        let segment = segments[index];
        if let Some(child) = self.static_children.get(segment) {
            child.collect_matches(segments, index + 1, captures, matches);
        }

        for child in &self.param_children {
            captures.push((child.name.clone(), percent_decode(segment)));
            child
                .node
                .collect_matches(segments, index + 1, captures, matches);
            captures.pop();
        }
    }
}

fn route_allows_method(route: &FastPathRoute, method: &str) -> bool {
    route
        .methods
        .iter()
        .any(|route_method| route_method.eq_ignore_ascii_case(method))
}

fn try_fast_path_response(
    state: &ServerState,
    request: &HttpRequest,
) -> Option<HyperResponse<Full<Bytes>>> {
    let registry = state.fast_path.as_ref()?;
    let (path, query_string) = request
        .target
        .split_once('?')
        .map_or((request.target.as_str(), ""), |(path, query)| (path, query));
    if let Some(response) =
        preflight_middleware_response(&registry.middleware, request, path, query_string)
    {
        return Some(response);
    }
    if let Some(response) = static_mount_response(&registry.static_mounts, path) {
        return Some(apply_response_middleware(
            &registry.middleware,
            request,
            response,
        ));
    }
    if request.body.is_some() && !registry.has_body_routes {
        return None;
    }
    let query_params = parse_query_string_inner(query_string);
    if let Some(route_match) =
        registry
            .route_index
            .match_path(&registry.routes, &request.method, path)
    {
        let route = &registry.routes[route_match.route_index];
        let form_params = if route.needs_form {
            form_params_for_request(request)
        } else {
            Vec::new()
        };
        return dispatch_fast_path_route(
            route,
            request,
            path,
            query_string,
            route_match.path_params,
            &query_params,
            &form_params,
        )
        .map(|response| apply_response_middleware(&registry.middleware, request, response))
        .ok();
    }
    None
}

fn static_mount_response(
    mounts: &[FastPathStaticMount],
    path: &str,
) -> Option<HyperResponse<Full<Bytes>>> {
    for mount in mounts {
        if path != mount.prefix && !path.starts_with(&(mount.prefix.clone() + "/")) {
            continue;
        }
        let child_path = path
            .strip_prefix(&mount.prefix)
            .filter(|value| !value.is_empty())
            .unwrap_or("/");
        return Some(static_file_response(&mount.directory, child_path));
    }
    None
}

fn static_file_response(directory: &Path, child_path: &str) -> HyperResponse<Full<Bytes>> {
    let Some(path) = safe_static_file_path(directory, child_path) else {
        return static_not_found_response();
    };
    let Ok(metadata) = fs::metadata(&path) else {
        return static_not_found_response();
    };
    if !metadata.is_file() {
        return static_not_found_response();
    }
    let Ok(body) = fs::read(path) else {
        return static_not_found_response();
    };
    hyper_response(
        200,
        vec![(
            CONTENT_TYPE.as_str().to_string(),
            "text/plain; charset=utf-8".to_string(),
        )],
        body,
    )
}

fn safe_static_file_path(directory: &Path, child_path: &str) -> Option<PathBuf> {
    let root = fs::canonicalize(directory).ok()?;
    let mut relative = PathBuf::new();
    for component in Path::new(child_path.trim_start_matches('/')).components() {
        match component {
            Component::Normal(part) => relative.push(part),
            Component::CurDir => {}
            Component::Prefix(_) | Component::RootDir | Component::ParentDir => return None,
        }
    }
    let full_path = root.join(relative);
    let canonical = fs::canonicalize(&full_path).ok()?;
    if canonical == root || canonical.starts_with(&root) {
        Some(canonical)
    } else {
        None
    }
}

fn static_not_found_response() -> HyperResponse<Full<Bytes>> {
    hyper_response(
        404,
        vec![(
            CONTENT_TYPE.as_str().to_string(),
            "application/json".to_string(),
        )],
        br#"{"detail":"Not Found"}"#.to_vec(),
    )
}

fn preflight_middleware_response(
    middleware: &[FastPathMiddleware],
    request: &HttpRequest,
    path: &str,
    query_string: &str,
) -> Option<HyperResponse<Full<Bytes>>> {
    for item in middleware {
        match item {
            FastPathMiddleware::Cors(cors) => {
                if !request.method.eq_ignore_ascii_case("OPTIONS") {
                    continue;
                }
                let origin = header_value(&request.headers, "origin")?;
                let requested_method =
                    header_value(&request.headers, "access-control-request-method")?;
                if !cors_allowed_origin(cors, origin) {
                    continue;
                }
                let mut headers = vec![
                    (
                        "access-control-allow-origin".to_string(),
                        origin.to_string(),
                    ),
                    (
                        "access-control-allow-methods".to_string(),
                        if cors.allow_methods.iter().any(|method| method == "*") {
                            requested_method.to_string()
                        } else {
                            cors.allow_methods.join(", ")
                        },
                    ),
                    (
                        CONTENT_TYPE.as_str().to_string(),
                        "text/plain; charset=utf-8".to_string(),
                    ),
                ];
                if let Some(requested_headers) =
                    header_value(&request.headers, "access-control-request-headers")
                {
                    headers.push((
                        "access-control-allow-headers".to_string(),
                        if cors.allow_headers.iter().any(|header| header == "*") {
                            requested_headers.to_string()
                        } else {
                            cors.allow_headers.join(", ")
                        },
                    ));
                }
                if cors.allow_credentials {
                    headers.push((
                        "access-control-allow-credentials".to_string(),
                        "true".to_string(),
                    ));
                }
                return Some(hyper_response(200, headers, b"OK".to_vec()));
            }
            FastPathMiddleware::GZip(_) => {}
            FastPathMiddleware::HttpsRedirect => {
                let host = header_value(&request.headers, "host").unwrap_or("testserver");
                let target = path.to_string()
                    + if query_string.is_empty() { "" } else { "?" }
                    + query_string;
                return Some(hyper_response(
                    307,
                    vec![("location".to_string(), format!("https://{host}{target}"))],
                    Vec::new(),
                ));
            }
            FastPathMiddleware::TrustedHost(trusted_host) => {
                let host = header_value(&request.headers, "host").unwrap_or("");
                if !trusted_host_allowed(trusted_host, host) {
                    return Some(hyper_response(
                        400,
                        vec![(
                            CONTENT_TYPE.as_str().to_string(),
                            "text/plain; charset=utf-8".to_string(),
                        )],
                        b"Invalid host header".to_vec(),
                    ));
                }
            }
        }
    }
    None
}

fn apply_response_middleware(
    middleware: &[FastPathMiddleware],
    request: &HttpRequest,
    mut response: HyperResponse<Full<Bytes>>,
) -> HyperResponse<Full<Bytes>> {
    for item in middleware {
        match item {
            FastPathMiddleware::Cors(cors) => {
                let Some(origin) = header_value(&request.headers, "origin") else {
                    continue;
                };
                if !cors_allowed_origin(cors, origin) {
                    continue;
                }
                if let Ok(value) = HeaderValue::from_str(origin) {
                    response.headers_mut().insert(
                        HeaderName::from_static("access-control-allow-origin"),
                        value,
                    );
                }
                if cors.allow_credentials {
                    response.headers_mut().insert(
                        HeaderName::from_static("access-control-allow-credentials"),
                        HeaderValue::from_static("true"),
                    );
                }
            }
            FastPathMiddleware::GZip(gzip) => {
                response = apply_gzip_response(gzip, request, response);
            }
            FastPathMiddleware::HttpsRedirect | FastPathMiddleware::TrustedHost(_) => {}
        }
    }
    response
}

fn apply_gzip_response(
    gzip: &FastPathGZipMiddleware,
    request: &HttpRequest,
    response: HyperResponse<Full<Bytes>>,
) -> HyperResponse<Full<Bytes>> {
    let accept_encoding = header_value(&request.headers, "accept-encoding").unwrap_or("");
    if !accept_encoding
        .split(',')
        .any(|value| value.trim().eq_ignore_ascii_case("gzip"))
    {
        return response;
    }
    if response.headers().contains_key(CONTENT_ENCODING) {
        return response;
    }
    let status = response.status();
    if status == StatusCode::NO_CONTENT || status == StatusCode::NOT_MODIFIED {
        return response;
    }
    let (mut parts, body) = response.into_parts();
    let Some(body) = full_body_bytes(body) else {
        return HyperResponse::from_parts(parts, Full::new(Bytes::new()));
    };
    if body.len() < gzip.minimum_size {
        return HyperResponse::from_parts(parts, Full::new(Bytes::from(body)));
    }
    let Some(compressed) = gzip_compress(&body, gzip.compresslevel) else {
        return HyperResponse::from_parts(parts, Full::new(Bytes::from(body)));
    };
    parts.headers.remove(CONTENT_LENGTH);
    parts
        .headers
        .insert(CONTENT_ENCODING, HeaderValue::from_static("gzip"));
    let body_len = compressed.len();
    let mut response = HyperResponse::from_parts(parts, Full::new(Bytes::from(compressed)));
    response.headers_mut().insert(
        CONTENT_LENGTH,
        HeaderValue::from_str(&body_len.to_string())
            .unwrap_or_else(|_| HeaderValue::from_static("0")),
    );
    response
}

fn full_body_bytes(body: Full<Bytes>) -> Option<Vec<u8>> {
    let mut body = Box::pin(body);
    let waker = Waker::noop();
    let mut context = Context::from_waker(waker);
    match body.as_mut().poll_frame(&mut context) {
        Poll::Ready(Some(Ok(frame))) => frame.into_data().ok().map(|bytes| bytes.to_vec()),
        Poll::Ready(None) => Some(Vec::new()),
        _ => None,
    }
}

fn gzip_compress(body: &[u8], compresslevel: u32) -> Option<Vec<u8>> {
    let mut encoder = GzEncoder::new(Vec::new(), Compression::new(compresslevel.min(9)));
    encoder.write_all(body).ok()?;
    encoder.finish().ok()
}

fn python_await<'py>(py: Python<'py>, value: &Bound<'py, PyAny>) -> PyResult<Bound<'py, PyAny>> {
    PY_ASYNCIO_LOOP.with(|slot| {
        let mut slot = slot.borrow_mut();
        if slot.loop_obj.is_none() {
            let asyncio = py.import("asyncio")?;
            let loop_obj = asyncio.call_method0("new_event_loop")?;
            asyncio.call_method1("set_event_loop", (&loop_obj,))?;
            slot.loop_obj.replace(loop_obj.unbind());
        }
        let loop_obj = slot
            .loop_obj
            .as_ref()
            .expect("thread-local asyncio loop should be initialized")
            .bind(py);
        loop_obj.call_method1("run_until_complete", (value,))
    })
}

fn header_value<'a>(headers: &'a [(String, String)], name: &str) -> Option<&'a str> {
    headers
        .iter()
        .rev()
        .find(|(header_name, _)| header_name.eq_ignore_ascii_case(name))
        .map(|(_, value)| value.as_str())
}

fn request_media_type(request: &HttpRequest) -> Option<String> {
    header_value(&request.headers, "content-type").map(|content_type| {
        content_type
            .split_once(';')
            .map_or(content_type, |(value, _)| value)
            .trim()
            .to_ascii_lowercase()
    })
}

fn form_params_for_request(request: &HttpRequest) -> Vec<(String, String)> {
    if request_media_type(request).as_deref() != Some("application/x-www-form-urlencoded") {
        return Vec::new();
    }
    let Some(body) = &request.body else {
        return Vec::new();
    };
    let Ok(text) = std::str::from_utf8(body) else {
        return Vec::new();
    };
    parse_query_string_inner(text)
}

fn multipart_part_for_request(request: &HttpRequest, name: &str) -> Option<MultipartPart> {
    multipart_parts_for_request(request, name)
        .into_iter()
        .next()
}

fn multipart_parts_for_request(request: &HttpRequest, name: &str) -> Vec<MultipartPart> {
    let Some(content_type) = header_value(&request.headers, "content-type") else {
        return Vec::new();
    };
    let media_type = content_type
        .split_once(';')
        .map_or(content_type, |(value, _)| value)
        .trim()
        .to_ascii_lowercase();
    if media_type != "multipart/form-data" {
        return Vec::new();
    }
    let Some(boundary) = content_type.split(';').find_map(|part| {
        let (key, value) = part.trim().split_once('=')?;
        key.trim()
            .eq_ignore_ascii_case("boundary")
            .then(|| value.trim().trim_matches('"').as_bytes().to_vec())
    }) else {
        return Vec::new();
    };
    let Some(body) = request.body.as_ref() else {
        return Vec::new();
    };
    multipart_parts(body, &boundary, name)
}

fn multipart_parts(body: &[u8], boundary: &[u8], name: &str) -> Vec<MultipartPart> {
    let mut delimiter = Vec::with_capacity(boundary.len() + 2);
    delimiter.extend_from_slice(b"--");
    delimiter.extend_from_slice(boundary);
    let mut parts = Vec::new();
    let mut offset = 0;
    while let Some(start) = find_subslice(&body[offset..], &delimiter) {
        let part_start = offset + start + delimiter.len();
        if body.get(part_start..part_start + 2) == Some(b"--") {
            break;
        }
        let part_start = if body.get(part_start..part_start + 2) == Some(b"\r\n") {
            part_start + 2
        } else {
            part_start
        };
        let next_search = part_start;
        let next_delimiter = find_subslice(&body[next_search..], &delimiter)
            .map(|index| next_search + index)
            .unwrap_or(body.len());
        let mut part = &body[part_start..next_delimiter];
        if part.ends_with(b"\r\n") {
            part = &part[..part.len() - 2];
        }
        if let Some((headers, content)) = split_multipart_part(part) {
            if multipart_part_name(headers).as_deref() == Some(name) {
                parts.push(MultipartPart {
                    content: content.to_vec(),
                    filename: multipart_part_filename(headers),
                    content_type: multipart_part_content_type(headers),
                });
            }
        }
        offset = next_delimiter;
    }
    parts
}

fn split_multipart_part(part: &[u8]) -> Option<(&[u8], &[u8])> {
    let separator = b"\r\n\r\n";
    let index = find_subslice(part, separator)?;
    Some((&part[..index], &part[index + separator.len()..]))
}

fn multipart_part_name(headers: &[u8]) -> Option<String> {
    multipart_content_disposition_value(headers, "name")
}

fn multipart_part_filename(headers: &[u8]) -> Option<String> {
    multipart_content_disposition_value(headers, "filename")
}

fn multipart_content_disposition_value(headers: &[u8], target: &str) -> Option<String> {
    let headers = std::str::from_utf8(headers).ok()?;
    for line in headers.lines() {
        let (key, value) = line.split_once(':')?;
        if !key.trim().eq_ignore_ascii_case("content-disposition") {
            continue;
        }
        for item in value.split(';') {
            let Some((item_key, item_value)) = item.trim().split_once('=') else {
                continue;
            };
            if item_key.trim().eq_ignore_ascii_case(target) {
                return Some(item_value.trim().trim_matches('"').to_string());
            }
        }
    }
    None
}

fn multipart_part_content_type(headers: &[u8]) -> Option<String> {
    let headers = std::str::from_utf8(headers).ok()?;
    for line in headers.lines() {
        let (key, value) = line.split_once(':')?;
        if key.trim().eq_ignore_ascii_case("content-type") {
            return Some(value.trim().to_string());
        }
    }
    None
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() {
        return Some(0);
    }
    haystack
        .windows(needle.len())
        .position(|window| window == needle)
}

fn cors_allowed_origin(cors: &FastPathCorsMiddleware, origin: &str) -> bool {
    cors.allow_origins
        .iter()
        .any(|allowed| allowed == "*" || allowed == origin)
}

fn trusted_host_allowed(middleware: &FastPathTrustedHostMiddleware, host: &str) -> bool {
    let hostname = host.split_once(':').map_or(host, |(name, _)| name);
    middleware
        .allowed_hosts
        .iter()
        .any(|pattern| pattern == "*" || wildcard_match(pattern, hostname))
}

fn wildcard_match(pattern: &str, value: &str) -> bool {
    if pattern == value {
        return true;
    }
    let Some((prefix, suffix)) = pattern.split_once('*') else {
        return false;
    };
    value.starts_with(prefix) && value.ends_with(suffix)
}

fn dispatch_fast_path_route(
    route: &FastPathRoute,
    request: &HttpRequest,
    path: &str,
    query_string: &str,
    path_params: Vec<(String, String)>,
    query_params: &[(String, String)],
    form_params: &[(String, String)],
) -> PyResult<HyperResponse<Full<Bytes>>> {
    if route.has_custom_asgi_middleware {
        return dispatch_fast_path_custom_asgi_middleware_route(
            route,
            request,
            path,
            query_string,
            &path_params,
        );
    }
    if route.has_user_middleware {
        if request.body.is_some()
            && request_media_type(request).as_deref() == Some("multipart/form-data")
        {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "multipart body with user middleware requires Python fallback",
            ));
        }
        return dispatch_fast_path_user_middleware_route(
            route,
            request,
            path,
            query_string,
            &path_params,
        );
    }
    if let Some(body) = &route.static_body {
        return Ok(hyper_response(
            route.status_code,
            vec![(
                CONTENT_TYPE.as_str().to_string(),
                "application/json".to_string(),
            )],
            body.clone(),
        ));
    }
    Python::attach(|py| {
        let kwargs = PyDict::new(py);
        let response_state = if route.response_param.is_some() {
            let response_kwargs = PyDict::new(py);
            response_kwargs.set_item("status_code", route.status_code)?;
            Some(
                route
                    .response_state_class
                    .bind(py)
                    .call((), Some(&response_kwargs))?,
            )
        } else {
            None
        };
        if let (Some(name), Some(response_state)) = (&route.response_param, &response_state) {
            kwargs.set_item(name.as_str(), response_state)?;
        }
        let background_tasks = if route.needs_background_tasks {
            Some(route.background_tasks_class.bind(py).call0()?)
        } else {
            None
        };
        if let (Some(name), Some(background_tasks)) =
            (&route.background_tasks_param, &background_tasks)
        {
            kwargs.set_item(name.as_str(), background_tasks)?;
        }
        let request_object = if route.needs_request {
            Some(build_fast_path_request(
                py,
                route,
                request,
                path,
                query_string,
                &path_params,
            )?)
        } else {
            None
        };
        if let (Some(name), Some(request_object)) = (&route.request_param, &request_object) {
            kwargs.set_item(name.as_str(), request_object)?;
        }
        let mut dependency_cache = HashMap::<String, Py<PyAny>>::new();
        let mut dependency_finalizers = Vec::<FastPathDependencyFinalizer>::new();
        let security_scopes = Vec::<String>::new();
        for dependency in &route.dependencies {
            let dependency_result = call_fast_path_dependency(
                py,
                dependency,
                request,
                &path_params,
                query_params,
                form_params,
                &mut dependency_cache,
                &mut dependency_finalizers,
                background_tasks.as_ref(),
                request_object.as_ref(),
                &security_scopes,
            );
            let value = match dependency_result {
                Ok(Ok(value)) => value,
                Ok(Err(error)) => {
                    finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
                    return param_validation_error_response(py, &error);
                }
                Err(error) => {
                    finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
                    return python_exception_response(
                        py,
                        route,
                        request,
                        path,
                        query_string,
                        &path_params,
                        &error,
                    );
                }
            };
            if let Some(target) = &dependency.target {
                kwargs.set_item(target.as_str(), value.bind(py))?;
            }
        }
        for param in &route.params {
            if let Err(error) = set_fast_path_param(
                py,
                &kwargs,
                param,
                request,
                &path_params,
                query_params,
                form_params,
            )? {
                finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
                return param_validation_error_response(py, &error);
            }
        }
        if let Some(body_param) = &route.body_param {
            let Some(body) = &request.body else {
                finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
                return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    "request body unavailable",
                ));
            };
            let py_body = PyBytes::new(py, body);
            let value_result = if let Some(validator) = &body_param.validator {
                validator.bind(py).call_method1("validate_json", (py_body,))
            } else {
                body_param
                    .adapter
                    .bind(py)
                    .call_method1("validate_json", (py_body,))
            };
            let value = match value_result {
                Ok(value) => value,
                Err(error) => {
                    finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
                    return validation_error_response(py, error, "body");
                }
            };
            kwargs.set_item(body_param.name.as_str(), value)?;
        } else if request.body.is_some() && !route.needs_form {
            finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "request body unsupported by fast path",
            ));
        }
        let result = match route.endpoint.bind(py).call((), Some(&kwargs)) {
            Ok(result) => result,
            Err(error) => {
                finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
                return python_exception_response(
                    py,
                    route,
                    request,
                    path,
                    query_string,
                    &path_params,
                    &error,
                );
            }
        };
        let result = if route.endpoint_is_async {
            match python_await(py, &result) {
                Ok(result) => result,
                Err(error) => {
                    finalize_fast_path_dependencies(py, &mut dependency_finalizers, None)?;
                    return python_exception_response(
                        py,
                        route,
                        request,
                        path,
                        query_string,
                        &path_params,
                        &error,
                    );
                }
            }
        } else {
            result
        };
        if let Some(response) = python_response_instance(&result)? {
            finalize_fast_path_dependencies(py, &mut dependency_finalizers, Some("function"))?;
            run_background_tasks(&background_tasks)?;
            finalize_fast_path_dependencies(py, &mut dependency_finalizers, Some("request"))?;
            return Ok(response);
        }
        let status_code = response_status_code(&response_state)?.unwrap_or(route.status_code);
        if matches!(
            route.response_kind,
            FastPathResponseKind::Streaming | FastPathResponseKind::File
        ) {
            let response_kwargs = PyDict::new(py);
            response_kwargs.set_item("status_code", status_code)?;
            let response = route
                .response_class
                .bind(py)
                .call((&result,), Some(&response_kwargs))?;
            let response = python_response_instance(&response)?.ok_or_else(|| {
                PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    "fast path response class did not produce a response",
                )
            })?;
            finalize_fast_path_dependencies(py, &mut dependency_finalizers, Some("function"))?;
            run_background_tasks(&background_tasks)?;
            finalize_fast_path_dependencies(py, &mut dependency_finalizers, Some("request"))?;
            return Ok(response);
        }
        let body = if let Some(response_model) = &route.response_model {
            response_model_json(py, response_model, &result)?
        } else {
            match route.response_kind {
                FastPathResponseKind::Json => python_json_bytes(&result)?,
                FastPathResponseKind::Html => python_text_bytes(&result)?,
                FastPathResponseKind::PlainText => python_text_bytes(&result)?,
                FastPathResponseKind::Redirect => Vec::new(),
                FastPathResponseKind::Streaming | FastPathResponseKind::File => unreachable!(),
            }
        };
        let mut headers = match route.response_kind {
            FastPathResponseKind::Json => vec![(
                CONTENT_TYPE.as_str().to_string(),
                "application/json".to_string(),
            )],
            FastPathResponseKind::Html => vec![(
                CONTENT_TYPE.as_str().to_string(),
                "text/html; charset=utf-8".to_string(),
            )],
            FastPathResponseKind::PlainText => vec![(
                CONTENT_TYPE.as_str().to_string(),
                "text/plain; charset=utf-8".to_string(),
            )],
            FastPathResponseKind::Redirect => {
                vec![("location".to_string(), result.extract::<String>()?)]
            }
            FastPathResponseKind::Streaming | FastPathResponseKind::File => unreachable!(),
        };
        if let Some(response_state) = &response_state {
            headers.extend(response_headers(response_state)?);
        }
        let response = hyper_response(status_code, headers, body);
        finalize_fast_path_dependencies(py, &mut dependency_finalizers, Some("function"))?;
        run_background_tasks(&background_tasks)?;
        finalize_fast_path_dependencies(py, &mut dependency_finalizers, Some("request"))?;
        Ok(response)
    })
}

fn dispatch_fast_path_user_middleware_route(
    route: &FastPathRoute,
    request: &HttpRequest,
    path: &str,
    query_string: &str,
    path_params: &[(String, String)],
) -> PyResult<HyperResponse<Full<Bytes>>> {
    Python::attach(|py| {
        let request_object =
            build_fast_path_request(py, route, request, path, query_string, path_params)?;
        let response = route.app.bind(py).call_method1(
            "_dispatch_rust_user_middleware_route",
            (route.route_index, request_object),
        )?;
        python_response_instance(&response)?.ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "user middleware route did not produce a response",
            )
        })
    })
}

fn dispatch_fast_path_custom_asgi_middleware_route(
    route: &FastPathRoute,
    request: &HttpRequest,
    path: &str,
    query_string: &str,
    path_params: &[(String, String)],
) -> PyResult<HyperResponse<Full<Bytes>>> {
    Python::attach(|py| {
        let request_object =
            build_fast_path_request(py, route, request, path, query_string, path_params)?;
        let response = route.app.bind(py).call_method1(
            "_dispatch_rust_custom_asgi_middleware_route",
            (route.route_index, request_object),
        )?;
        python_response_instance(&response)?.ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "custom ASGI middleware route did not produce a response",
            )
        })
    })
}

fn python_response_instance(
    response: &Bound<'_, PyAny>,
) -> PyResult<Option<HyperResponse<Full<Bytes>>>> {
    let Ok(status_code) = response.getattr("status_code") else {
        return Ok(None);
    };
    let Ok(body) = response.getattr("body") else {
        return Ok(None);
    };
    let Ok(headers) = response.getattr("headers") else {
        return Ok(None);
    };
    let status = status_code.extract::<u16>()?;
    let body = body.extract::<Vec<u8>>()?;
    let raw_headers = headers.call_method0("raw_items")?;
    let mut headers = Vec::new();
    for item in raw_headers.try_iter()? {
        headers.push(item?.extract::<(String, String)>()?);
    }
    Ok(Some(hyper_response(status, headers, body)))
}

fn python_exception_response(
    py: Python<'_>,
    route: &FastPathRoute,
    request: &HttpRequest,
    path: &str,
    query_string: &str,
    path_params: &[(String, String)],
    error: &PyErr,
) -> PyResult<HyperResponse<Full<Bytes>>> {
    let request_object =
        build_fast_path_request(py, route, request, path, query_string, path_params)?;
    let kwargs = PyDict::new(py);
    kwargs.set_item("raise_server_exceptions", false)?;
    let response = route.app.bind(py).call_method(
        "_handle_exception",
        (request_object, error.value(py)),
        Some(&kwargs),
    )?;
    python_response_instance(&response)?.ok_or_else(|| {
        PyErr::new::<pyo3::exceptions::PyValueError, _>(
            "exception handler did not produce a response",
        )
    })
}

fn build_fast_path_request<'py>(
    py: Python<'py>,
    route: &FastPathRoute,
    request: &HttpRequest,
    path: &str,
    query_string: &str,
    path_params: &[(String, String)],
) -> PyResult<Bound<'py, PyAny>> {
    let headers = route
        .headers_class
        .bind(py)
        .call1((request.headers.clone(),))?;
    let cookies = PyDict::new(py);
    for (_, cookie_header) in request
        .headers
        .iter()
        .filter(|(name, _)| name.eq_ignore_ascii_case("cookie"))
    {
        for (name, value) in parse_cookie_header_inner(cookie_header) {
            cookies.set_item(name, value)?;
        }
    }
    let path_params_dict = PyDict::new(py);
    for (name, value) in path_params {
        path_params_dict.set_item(name, value)?;
    }
    let scope = PyDict::new(py);
    scope.set_item("root_path", "")?;
    scope.set_item("scheme", "http")?;
    scope.set_item("state", route.app_state.bind(py))?;
    scope.set_item("method", request.method.as_str())?;
    scope.set_item("path", path)?;
    scope.set_item("query_string", PyBytes::new(py, query_string.as_bytes()))?;
    scope.set_item("headers_obj", &headers)?;
    scope.set_item("cookies", &cookies)?;
    scope.set_item("app", route.app.bind(py))?;
    scope.set_item("path_params", path_params_dict)?;
    let kwargs = PyDict::new(py);
    kwargs.set_item("method", request.method.as_str())?;
    kwargs.set_item("path", path)?;
    kwargs.set_item("query_string", query_string)?;
    if let Some(body) = &request.body {
        let py_body = PyBytes::new(py, body);
        kwargs.set_item("raw_body", &py_body)?;
        scope.set_item("raw_body", py_body)?;
        match request_media_type(request).as_deref() {
            Some("application/json") => {
                let text = std::str::from_utf8(body).map_err(json_serialization_error)?;
                let json_body = py.import("json")?.call_method1("loads", (text,))?;
                kwargs.set_item("json_body", &json_body)?;
                scope.set_item("json_body", json_body)?;
            }
            Some("application/x-www-form-urlencoded") => {
                let text = std::str::from_utf8(body).map_err(json_serialization_error)?;
                let form_body = PyDict::new(py);
                let grouped = parse_query_string_inner(text).into_iter().fold(
                    HashMap::<String, Vec<String>>::new(),
                    |mut params, (key, value)| {
                        params.entry(key).or_default().push(value);
                        params
                    },
                );
                for (name, values) in grouped {
                    if values.len() == 1 {
                        form_body.set_item(name, &values[0])?;
                    } else {
                        form_body.set_item(name, values)?;
                    }
                }
                kwargs.set_item("form_body", &form_body)?;
                scope.set_item("form_body", form_body)?;
            }
            _ if !body.is_empty() => {
                let text = std::str::from_utf8(body).map_err(json_serialization_error)?;
                kwargs.set_item("json_body", text)?;
                scope.set_item("json_body", text)?;
            }
            _ => {}
        }
    }
    kwargs.set_item("headers", headers)?;
    kwargs.set_item("cookies", cookies)?;
    kwargs.set_item("app", route.app.bind(py))?;
    kwargs.set_item("scope", scope)?;
    route.request_class.bind(py).call((), Some(&kwargs))
}

fn run_background_tasks(background_tasks: &Option<Bound<'_, PyAny>>) -> PyResult<()> {
    if let Some(background_tasks) = background_tasks {
        background_tasks.call0()?;
    }
    Ok(())
}

fn response_status_code(response: &Option<Bound<'_, PyAny>>) -> PyResult<Option<u16>> {
    response
        .as_ref()
        .map(|response| response.getattr("status_code")?.extract::<u16>())
        .transpose()
}

fn response_headers(response: &Bound<'_, PyAny>) -> PyResult<Vec<(String, String)>> {
    let raw_headers = response.getattr("headers")?.call_method0("raw_items")?;
    let mut headers = Vec::new();
    for item in raw_headers.try_iter()? {
        headers.push(item?.extract::<(String, String)>()?);
    }
    Ok(headers)
}

fn response_model_json(
    py: Python<'_>,
    response_model: &FastPathResponseModel,
    result: &Bound<'_, PyAny>,
) -> PyResult<Vec<u8>> {
    let validated = match validate_response_model_python(py, response_model, result) {
        Ok(validated) => validated,
        Err(error) => {
            let Ok(dumped) = result.call_method0("model_dump") else {
                return Err(error);
            };
            validate_response_model_python(py, response_model, &dumped)?
        }
    };
    let dump_kwargs = response_model.dump_kwargs.bind(py);
    let json = if let Some(serializer) = &response_model.serializer {
        serializer
            .bind(py)
            .call_method("to_json", (&validated,), Some(&dump_kwargs))?
    } else {
        response_model.adapter.bind(py).call_method(
            "dump_json",
            (&validated,),
            Some(&dump_kwargs),
        )?
    };
    json.extract::<Vec<u8>>()
}

fn validate_response_model_python<'py>(
    py: Python<'py>,
    response_model: &FastPathResponseModel,
    result: &Bound<'py, PyAny>,
) -> PyResult<Bound<'py, PyAny>> {
    let validate_kwargs = response_model.validate_kwargs.bind(py);
    if let Some(validator) = &response_model.validator {
        validator
            .bind(py)
            .call_method("validate_python", (result,), Some(&validate_kwargs))
    } else {
        response_model.adapter.bind(py).call_method(
            "validate_python",
            (result,),
            Some(&validate_kwargs),
        )
    }
}

fn validation_error_response(
    py: Python<'_>,
    error: PyErr,
    source: &str,
) -> PyResult<HyperResponse<Full<Bytes>>> {
    let body = validation_error_body(py, error, source)?;
    Ok(hyper_response(
        StatusCode::UNPROCESSABLE_ENTITY.as_u16(),
        vec![(
            CONTENT_TYPE.as_str().to_string(),
            "application/json".to_string(),
        )],
        body,
    ))
}

fn param_validation_error_response(
    py: Python<'_>,
    error: &FastPathParamFailure,
) -> PyResult<HyperResponse<Full<Bytes>>> {
    let body = param_validation_error_body(error).map_err(|error| {
        PyErr::new::<pyo3::exceptions::PyValueError, _>(format!(
            "validation error serialization failed: {error}"
        ))
    })?;
    let _ = py;
    Ok(hyper_response(
        StatusCode::UNPROCESSABLE_ENTITY.as_u16(),
        vec![(
            CONTENT_TYPE.as_str().to_string(),
            "application/json".to_string(),
        )],
        body,
    ))
}

fn param_validation_error_body(error: &FastPathParamFailure) -> Result<Vec<u8>, serde_json::Error> {
    let mut detail = JsonMap::new();
    match &error.issue {
        FastPathParamIssue::Missing => {
            detail.insert("type".to_string(), JsonValue::String("missing".to_string()));
            detail.insert(
                "msg".to_string(),
                JsonValue::String("Field required".to_string()),
            );
            detail.insert("input".to_string(), JsonValue::Null);
        }
        FastPathParamIssue::Parsing { raw_value, kind } => {
            let (error_type, message) = match kind {
                FastPathParamKind::Int => (
                    "int_parsing",
                    "Input should be a valid integer, unable to parse string as an integer",
                ),
                FastPathParamKind::Float => (
                    "float_parsing",
                    "Input should be a valid number, unable to parse string as a number",
                ),
                FastPathParamKind::Bool => (
                    "bool_parsing",
                    "Input should be a valid boolean, unable to interpret input",
                ),
                FastPathParamKind::Str => ("string_type", "Input should be a valid string"),
                FastPathParamKind::Bytes => ("bytes_type", "Input should be a valid bytes"),
                FastPathParamKind::UploadFile => ("missing", "Field required"),
                FastPathParamKind::ListBytes | FastPathParamKind::ListUploadFile => {
                    ("list_type", "Input should be a valid list")
                }
            };
            detail.insert(
                "type".to_string(),
                JsonValue::String(error_type.to_string()),
            );
            detail.insert("msg".to_string(), JsonValue::String(message.to_string()));
            detail.insert("input".to_string(), JsonValue::String(raw_value.clone()));
        }
    }
    detail.insert(
        "loc".to_string(),
        JsonValue::Array(vec![
            JsonValue::String(param_source_name(error.source).to_string()),
            JsonValue::String(error.wire_name.clone()),
        ]),
    );
    let mut body = JsonMap::new();
    body.insert(
        "detail".to_string(),
        JsonValue::Array(vec![JsonValue::Object(detail)]),
    );
    serde_json::to_vec(&JsonValue::Object(body))
}

fn param_source_name(source: FastPathParamSource) -> &'static str {
    match source {
        FastPathParamSource::Path => "path",
        FastPathParamSource::Query => "query",
        FastPathParamSource::Header => "header",
        FastPathParamSource::Cookie => "cookie",
        FastPathParamSource::Form => "body",
    }
}

fn validation_error_body(py: Python<'_>, error: PyErr, source: &str) -> PyResult<Vec<u8>> {
    let raw_errors = error.value(py).call_method0("errors")?;
    let mut body = Vec::new();
    body.write_all(b"{\"detail\":[")
        .map_err(json_serialization_error)?;
    let mut first_error = true;
    for item in raw_errors.try_iter()? {
        let item = item?;
        let error_dict = item.cast::<PyDict>()?;
        if first_error {
            first_error = false;
        } else {
            body.write_all(b",").map_err(json_serialization_error)?;
        }
        body.write_all(b"{").map_err(json_serialization_error)?;
        let mut first_field = true;
        let mut wrote_loc = false;
        for (key, value) in error_dict.iter() {
            let key_name = key.extract::<String>()?;
            if key_name == "url" {
                continue;
            }
            if first_field {
                first_field = false;
            } else {
                body.write_all(b",").map_err(json_serialization_error)?;
            }
            serde_json::to_writer(&mut body, &key_name).map_err(json_serialization_error)?;
            body.write_all(b":").map_err(json_serialization_error)?;
            if key_name == "loc" {
                wrote_loc = true;
                write_validation_error_loc(&value, source, &mut body)?;
            } else {
                write_python_json(&value, &mut body)?;
            }
        }
        if !wrote_loc {
            if !first_field {
                body.write_all(b",").map_err(json_serialization_error)?;
            }
            body.write_all(b"\"loc\":")
                .map_err(json_serialization_error)?;
            write_validation_error_loc_without_raw(source, &mut body)?;
        }
        body.write_all(b"}").map_err(json_serialization_error)?;
    }
    body.write_all(b"]}").map_err(json_serialization_error)?;
    Ok(body)
}

fn write_validation_error_loc(
    raw_loc: &Bound<'_, PyAny>,
    source: &str,
    output: &mut Vec<u8>,
) -> PyResult<()> {
    output.write_all(b"[").map_err(json_serialization_error)?;
    serde_json::to_writer(&mut *output, source).map_err(json_serialization_error)?;
    for loc_item in raw_loc.try_iter()? {
        output.write_all(b",").map_err(json_serialization_error)?;
        write_python_json(&loc_item?, output)?;
    }
    output.write_all(b"]").map_err(json_serialization_error)?;
    Ok(())
}

fn write_validation_error_loc_without_raw(source: &str, output: &mut Vec<u8>) -> PyResult<()> {
    output.write_all(b"[").map_err(json_serialization_error)?;
    serde_json::to_writer(&mut *output, source).map_err(json_serialization_error)?;
    output.write_all(b"]").map_err(json_serialization_error)?;
    Ok(())
}

fn call_fast_path_dependency(
    py: Python<'_>,
    dependency: &FastPathDependency,
    request: &HttpRequest,
    path_params: &[(String, String)],
    query_params: &[(String, String)],
    form_params: &[(String, String)],
    dependency_cache: &mut HashMap<String, Py<PyAny>>,
    dependency_finalizers: &mut Vec<FastPathDependencyFinalizer>,
    background_tasks: Option<&Bound<'_, PyAny>>,
    request_object: Option<&Bound<'_, PyAny>>,
    inherited_security_scopes: &[String],
) -> PyResult<Result<Py<PyAny>, FastPathParamFailure>> {
    let active_security_scopes = active_security_scopes(inherited_security_scopes, dependency);
    let cache_key = fast_path_dependency_cache_key(dependency, &active_security_scopes);
    if dependency.use_cache {
        if let Some(value) = dependency_cache.get(&cache_key) {
            return Ok(Ok(value.clone_ref(py)));
        }
    }
    let kwargs = PyDict::new(py);
    for child in &dependency.dependencies {
        let value = match call_fast_path_dependency(
            py,
            child,
            request,
            path_params,
            query_params,
            form_params,
            dependency_cache,
            dependency_finalizers,
            background_tasks,
            request_object,
            &active_security_scopes,
        )? {
            Ok(value) => value,
            Err(error) => return Ok(Err(error)),
        };
        if let Some(target) = &child.target {
            kwargs.set_item(target.as_str(), value.bind(py))?;
        }
    }
    if let (Some(name), Some(background_tasks)) =
        (&dependency.background_tasks_param, background_tasks)
    {
        kwargs.set_item(name.as_str(), background_tasks)?;
    }
    if let (Some(name), Some(request_object)) = (&dependency.request_param, request_object) {
        kwargs.set_item(name.as_str(), request_object)?;
    }
    if let Some(name) = &dependency.security_scopes_param {
        let scopes = PyList::new(py, &active_security_scopes)?;
        let security_scopes = dependency.security_scopes_class.bind(py).call1((scopes,))?;
        kwargs.set_item(name.as_str(), security_scopes)?;
    }
    for param in &dependency.params {
        if let Err(error) = set_fast_path_param(
            py,
            &kwargs,
            param,
            request,
            path_params,
            query_params,
            form_params,
        )? {
            return Ok(Err(error));
        }
    }
    let value = dependency.call.bind(py).call((), Some(&kwargs))?;
    let value = if dependency.call_is_yield {
        let yielded = if dependency.call_is_async_yield {
            let next_value = value.call_method0("__anext__")?;
            python_await(py, &next_value)?
        } else {
            value.call_method0("__next__")?
        };
        dependency_finalizers.push(FastPathDependencyFinalizer {
            finalizer: value.unbind(),
            is_async: dependency.call_is_async_yield,
            cleanup_scope: dependency.cleanup_scope.clone(),
        });
        yielded
    } else if dependency.call_is_async {
        python_await(py, &value)?
    } else {
        value
    };
    let value = value.unbind();
    if dependency.use_cache {
        dependency_cache.insert(cache_key, value.clone_ref(py));
    }
    Ok(Ok(value))
}

fn active_security_scopes(
    inherited_security_scopes: &[String],
    dependency: &FastPathDependency,
) -> Vec<String> {
    let mut active =
        Vec::with_capacity(inherited_security_scopes.len() + dependency.security_scopes.len());
    active.extend_from_slice(inherited_security_scopes);
    active.extend(dependency.security_scopes.iter().cloned());
    active
}

fn fast_path_dependency_cache_key(
    dependency: &FastPathDependency,
    active_security_scopes: &[String],
) -> String {
    if dependency.uses_security_scopes || !dependency.security_scopes.is_empty() {
        format!(
            "{}|{}",
            dependency.cache_key,
            active_security_scopes.join("\x1f")
        )
    } else {
        dependency.cache_key.to_string()
    }
}

fn finalize_fast_path_dependencies(
    py: Python<'_>,
    finalizers: &mut Vec<FastPathDependencyFinalizer>,
    scope: Option<&str>,
) -> PyResult<()> {
    let mut remaining = Vec::<FastPathDependencyFinalizer>::new();
    while let Some(finalizer) = finalizers.pop() {
        if scope.is_some_and(|scope| scope != finalizer.cleanup_scope) {
            remaining.push(finalizer);
            continue;
        }
        let finalizer_obj = finalizer.finalizer.bind(py);
        let result = if finalizer.is_async {
            finalizer_obj
                .call_method0("__anext__")
                .and_then(|awaitable| python_await(py, &awaitable).map(|_| ()))
        } else {
            finalizer_obj.call_method0("__next__").map(|_| ())
        };
        if let Err(error) = result {
            if error
                .matches(py, py.get_type::<pyo3::exceptions::PyStopIteration>())
                .unwrap_or(false)
                || error
                    .matches(py, py.get_type::<pyo3::exceptions::PyStopAsyncIteration>())
                    .unwrap_or(false)
            {
                continue;
            }
            return Err(error);
        }
    }
    while let Some(finalizer) = remaining.pop() {
        finalizers.push(finalizer);
    }
    Ok(())
}

fn set_fast_path_param(
    py: Python<'_>,
    kwargs: &Bound<'_, PyDict>,
    param: &FastPathParam,
    request: &HttpRequest,
    path_params: &[(String, String)],
    query_params: &[(String, String)],
    form_params: &[(String, String)],
) -> PyResult<Result<(), FastPathParamFailure>> {
    if matches!(
        (param.source, param.kind),
        (FastPathParamSource::Form, FastPathParamKind::Bytes)
    ) {
        if let Some(part) = multipart_part_for_request(request, &param.wire_name) {
            kwargs.set_item(param.name.as_str(), PyBytes::new(py, &part.content))?;
            return Ok(Ok(()));
        }
    }
    if matches!(
        (param.source, param.kind),
        (FastPathParamSource::Form, FastPathParamKind::UploadFile)
    ) {
        if let (Some(part), Some(upload_file_class)) = (
            multipart_part_for_request(request, &param.wire_name),
            &param.upload_file_class,
        ) {
            let upload_file = upload_file_from_part(py, upload_file_class, part)?;
            kwargs.set_item(param.name.as_str(), upload_file)?;
            return Ok(Ok(()));
        }
    }
    if matches!(
        (param.source, param.kind),
        (FastPathParamSource::Form, FastPathParamKind::ListBytes)
    ) {
        let parts = multipart_parts_for_request(request, &param.wire_name);
        if !parts.is_empty() {
            let values = PyList::empty(py);
            for part in parts {
                values.append(PyBytes::new(py, &part.content))?;
            }
            kwargs.set_item(param.name.as_str(), values)?;
            return Ok(Ok(()));
        }
    }
    if matches!(
        (param.source, param.kind),
        (FastPathParamSource::Form, FastPathParamKind::ListUploadFile)
    ) {
        if let Some(upload_file_class) = &param.upload_file_class {
            let parts = multipart_parts_for_request(request, &param.wire_name);
            if !parts.is_empty() {
                let values = PyList::empty(py);
                for part in parts {
                    values.append(upload_file_from_part(py, upload_file_class, part)?)?;
                }
                kwargs.set_item(param.name.as_str(), values)?;
                return Ok(Ok(()));
            }
        }
    }
    let raw_value = match param.source {
        FastPathParamSource::Path => path_params
            .iter()
            .find(|(name, _)| name == &param.wire_name)
            .map(|(_, value)| value.as_str()),
        FastPathParamSource::Query => query_params
            .iter()
            .rev()
            .find(|(name, _)| name == &param.wire_name)
            .map(|(_, value)| value.as_str()),
        FastPathParamSource::Header => request
            .headers
            .iter()
            .rev()
            .find(|(name, _)| name.eq_ignore_ascii_case(&param.wire_name))
            .map(|(_, value)| value.as_str()),
        FastPathParamSource::Cookie => cookie_value(&request.headers, &param.wire_name),
        FastPathParamSource::Form => form_params
            .iter()
            .rev()
            .find(|(name, _)| name == &param.wire_name)
            .map(|(_, value)| value.as_str()),
    };
    let Some(raw_value) = raw_value else {
        if let Some(default) = &param.default {
            kwargs.set_item(param.name.as_str(), default.bind(py))?;
            return Ok(Ok(()));
        }
        if param.required {
            return Ok(Err(FastPathParamFailure {
                source: param.source,
                wire_name: param.wire_name.clone(),
                issue: FastPathParamIssue::Missing,
            }));
        }
        return Ok(Ok(()));
    };
    match param.kind {
        FastPathParamKind::Str => kwargs.set_item(param.name.as_str(), raw_value)?,
        FastPathParamKind::Bytes => {
            kwargs.set_item(param.name.as_str(), PyBytes::new(py, raw_value.as_bytes()))?
        }
        FastPathParamKind::ListBytes => {
            let values = PyList::empty(py);
            values.append(PyBytes::new(py, raw_value.as_bytes()))?;
            kwargs.set_item(param.name.as_str(), values)?;
        }
        FastPathParamKind::UploadFile => {
            if let Some(upload_file_class) = &param.upload_file_class {
                let kwargs_for_file = PyDict::new(py);
                kwargs_for_file.set_item("filename", "")?;
                kwargs_for_file.set_item("file", PyBytes::new(py, raw_value.as_bytes()))?;
                let upload_file = upload_file_class
                    .bind(py)
                    .call((), Some(&kwargs_for_file))?;
                kwargs.set_item(param.name.as_str(), upload_file)?;
            }
        }
        FastPathParamKind::ListUploadFile => {
            if let Some(upload_file_class) = &param.upload_file_class {
                let values = PyList::empty(py);
                let kwargs_for_file = PyDict::new(py);
                kwargs_for_file.set_item("filename", "")?;
                kwargs_for_file.set_item("file", PyBytes::new(py, raw_value.as_bytes()))?;
                values.append(
                    upload_file_class
                        .bind(py)
                        .call((), Some(&kwargs_for_file))?,
                )?;
                kwargs.set_item(param.name.as_str(), values)?;
            }
        }
        FastPathParamKind::Int => {
            let Ok(value) = raw_value.parse::<i64>() else {
                return Ok(Err(FastPathParamFailure {
                    source: param.source,
                    wire_name: param.wire_name.clone(),
                    issue: FastPathParamIssue::Parsing {
                        raw_value: raw_value.to_string(),
                        kind: param.kind,
                    },
                }));
            };
            kwargs.set_item(param.name.as_str(), value)?;
        }
        FastPathParamKind::Float => {
            let Ok(value) = raw_value.parse::<f64>() else {
                return Ok(Err(FastPathParamFailure {
                    source: param.source,
                    wire_name: param.wire_name.clone(),
                    issue: FastPathParamIssue::Parsing {
                        raw_value: raw_value.to_string(),
                        kind: param.kind,
                    },
                }));
            };
            kwargs.set_item(param.name.as_str(), value)?;
        }
        FastPathParamKind::Bool => {
            let Some(value) = parse_bool(raw_value) else {
                return Ok(Err(FastPathParamFailure {
                    source: param.source,
                    wire_name: param.wire_name.clone(),
                    issue: FastPathParamIssue::Parsing {
                        raw_value: raw_value.to_string(),
                        kind: param.kind,
                    },
                }));
            };
            kwargs.set_item(param.name.as_str(), value)?;
        }
    }
    Ok(Ok(()))
}

fn upload_file_from_part<'py>(
    py: Python<'py>,
    upload_file_class: &Py<PyAny>,
    part: MultipartPart,
) -> PyResult<Bound<'py, PyAny>> {
    let kwargs_for_file = PyDict::new(py);
    kwargs_for_file.set_item("filename", part.filename.unwrap_or_else(|| "".to_string()))?;
    kwargs_for_file.set_item("file", PyBytes::new(py, &part.content))?;
    if let Some(content_type) = part.content_type {
        kwargs_for_file.set_item("content_type", content_type)?;
    }
    upload_file_class.bind(py).call((), Some(&kwargs_for_file))
}

fn cookie_value<'a>(headers: &'a [(String, String)], name: &str) -> Option<&'a str> {
    for (_, header_value) in headers
        .iter()
        .rev()
        .filter(|(header_name, _)| header_name.eq_ignore_ascii_case("cookie"))
    {
        for part in header_value.split(';') {
            let trimmed = part.trim();
            let Some((cookie_name, cookie_value)) = trimmed.split_once('=') else {
                continue;
            };
            if cookie_name.trim() == name {
                return Some(cookie_value.trim());
            }
        }
    }
    None
}

fn parse_bool(value: &str) -> Option<bool> {
    match value.to_ascii_lowercase().as_str() {
        "1" | "true" | "on" | "yes" => Some(true),
        "0" | "false" | "off" | "no" => Some(false),
        _ => None,
    }
}

fn python_json_bytes(value: &Bound<'_, PyAny>) -> PyResult<Vec<u8>> {
    let mut bytes = Vec::new();
    write_python_json(value, &mut bytes)?;
    Ok(bytes)
}

fn python_text_bytes(value: &Bound<'_, PyAny>) -> PyResult<Vec<u8>> {
    if value.is_none() {
        return Ok(Vec::new());
    }
    if let Ok(value) = value.extract::<Vec<u8>>() {
        return Ok(value);
    }
    if let Ok(value) = value.extract::<String>() {
        return Ok(value.into_bytes());
    }
    Ok(value.str()?.extract::<String>()?.into_bytes())
}

fn write_python_json(value: &Bound<'_, PyAny>, output: &mut Vec<u8>) -> PyResult<()> {
    if value.is_none() {
        output.extend_from_slice(b"null");
        return Ok(());
    }
    if let Ok(value) = value.extract::<bool>() {
        serde_json::to_writer(&mut *output, &value).map_err(json_serialization_error)?;
        return Ok(());
    }
    if let Ok(value) = value.extract::<i64>() {
        serde_json::to_writer(&mut *output, &value).map_err(json_serialization_error)?;
        return Ok(());
    }
    if let Ok(value) = value.extract::<u64>() {
        serde_json::to_writer(&mut *output, &value).map_err(json_serialization_error)?;
        return Ok(());
    }
    if let Ok(value) = value.extract::<f64>() {
        if value.is_finite() {
            serde_json::to_writer(&mut *output, &value).map_err(json_serialization_error)?;
            return Ok(());
        }
    }
    if let Ok(value) = value.extract::<String>() {
        serde_json::to_writer(&mut *output, &value).map_err(json_serialization_error)?;
        return Ok(());
    }
    if let Ok(bytes) = value.cast::<PyBytes>() {
        let text = std::str::from_utf8(bytes.as_bytes()).map_err(json_serialization_error)?;
        serde_json::to_writer(&mut *output, text).map_err(json_serialization_error)?;
        return Ok(());
    }
    if is_python_instance(value, "datetime", "timedelta")? {
        let seconds = value.call_method0("total_seconds")?.extract::<f64>()?;
        serde_json::to_writer(&mut *output, &seconds).map_err(json_serialization_error)?;
        return Ok(());
    }
    if is_python_instance(value, "datetime", "date")?
        || is_python_instance(value, "datetime", "time")?
    {
        let text = value.call_method0("isoformat")?.extract::<String>()?;
        serde_json::to_writer(&mut *output, &text).map_err(json_serialization_error)?;
        return Ok(());
    }
    if is_python_instance(value, "uuid", "UUID")?
        || is_python_instance(value, "pathlib", "PurePath")?
    {
        let text = value.str()?.extract::<String>()?;
        serde_json::to_writer(&mut *output, &text).map_err(json_serialization_error)?;
        return Ok(());
    }
    if is_python_instance(value, "enum", "Enum")? {
        let enum_value = value.getattr("value")?;
        write_python_json(&enum_value, output)?;
        return Ok(());
    }
    if is_python_instance(value, "builtins", "BaseException")? {
        output.write_all(b"{}").map_err(json_serialization_error)?;
        return Ok(());
    }
    if let Ok(dict) = value.cast::<PyDict>() {
        output.write_all(b"{").map_err(json_serialization_error)?;
        let mut first = true;
        for (key, value) in dict.iter() {
            if first {
                first = false;
            } else {
                output.write_all(b",").map_err(json_serialization_error)?;
            }
            serde_json::to_writer(&mut *output, &python_json_key(&key)?)
                .map_err(json_serialization_error)?;
            output.write_all(b":").map_err(json_serialization_error)?;
            write_python_json(&value, output)?;
        }
        output.write_all(b"}").map_err(json_serialization_error)?;
        return Ok(());
    }
    if let Ok(list) = value.cast::<PyList>() {
        write_python_iterable_json(list, output)?;
        return Ok(());
    }
    if let Ok(tuple) = value.cast::<PyTuple>() {
        write_python_iterable_json(tuple, output)?;
        return Ok(());
    }
    if let Ok(set) = value.cast::<PySet>() {
        write_python_iterable_json(set, output)?;
        return Ok(());
    }
    if let Ok(frozen_set) = value.cast::<PyFrozenSet>() {
        write_python_iterable_json(frozen_set, output)?;
        return Ok(());
    }
    if is_python_instance(value, "collections", "deque")? {
        write_python_iterable_json(value, output)?;
        return Ok(());
    }
    if write_python_jsonable_object(value, output)? {
        return Ok(());
    }
    Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
        "unsupported fast path JSON value",
    ))
}

fn write_python_iterable_json(value: &Bound<'_, PyAny>, output: &mut Vec<u8>) -> PyResult<()> {
    output.write_all(b"[").map_err(json_serialization_error)?;
    let mut first = true;
    for item in value.try_iter()? {
        if first {
            first = false;
        } else {
            output.write_all(b",").map_err(json_serialization_error)?;
        }
        write_python_json(&item?, output)?;
    }
    output.write_all(b"]").map_err(json_serialization_error)?;
    Ok(())
}

fn write_python_jsonable_object(value: &Bound<'_, PyAny>, output: &mut Vec<u8>) -> PyResult<bool> {
    if value.hasattr("model_dump")? {
        let kwargs = PyDict::new(value.py());
        kwargs.set_item("mode", "json")?;
        kwargs.set_item("by_alias", true)?;
        let dumped = value.call_method("model_dump", (), Some(&kwargs))?;
        write_python_json(&dumped, output)?;
        return Ok(true);
    }
    if !is_known_jsonable_object(value)? {
        return Ok(false);
    }
    let jsonable = value
        .py()
        .import("superduperfastapi.responses")?
        .getattr("_jsonable")?
        .call1((value,))?;
    write_python_json(&jsonable, output)?;
    Ok(true)
}

fn is_known_jsonable_object(value: &Bound<'_, PyAny>) -> PyResult<bool> {
    let py = value.py();
    let datetime = py.import("datetime")?;
    let date_type = datetime.getattr("date")?;
    let time_type = datetime.getattr("time")?;
    let timedelta_type = datetime.getattr("timedelta")?;
    if value.is_instance(&date_type)?
        || value.is_instance(&time_type)?
        || value.is_instance(&timedelta_type)?
    {
        return Ok(true);
    }
    let enum_type = py.import("enum")?.getattr("Enum")?;
    if value.is_instance(&enum_type)? {
        return Ok(true);
    }
    let uuid_type = py.import("uuid")?.getattr("UUID")?;
    if value.is_instance(&uuid_type)? {
        return Ok(true);
    }
    let pure_path_type = py.import("pathlib")?.getattr("PurePath")?;
    if value.is_instance(&pure_path_type)? {
        return Ok(true);
    }
    let decimal_type = py.import("decimal")?.getattr("Decimal")?;
    if value.is_instance(&decimal_type)? {
        return Ok(true);
    }
    let builtins = py.import("builtins")?;
    let base_exception_type = builtins.getattr("BaseException")?;
    if value.is_instance(&base_exception_type)? {
        return Ok(true);
    }
    let dataclasses = py.import("dataclasses")?;
    let is_dataclass = dataclasses
        .call_method1("is_dataclass", (value,))?
        .extract::<bool>()?;
    let type_type = builtins.getattr("type")?;
    if is_dataclass && !value.is_instance(&type_type)? {
        return Ok(true);
    }
    Ok(false)
}

fn is_python_instance(value: &Bound<'_, PyAny>, module: &str, type_name: &str) -> PyResult<bool> {
    let type_object = value.py().import(module)?.getattr(type_name)?;
    value.is_instance(&type_object)
}

fn python_json_key(key: &Bound<'_, PyAny>) -> PyResult<String> {
    if let Ok(value) = key.extract::<String>() {
        return Ok(value);
    }
    if key.is_none() {
        return Ok("null".to_string());
    }
    if let Ok(value) = key.extract::<bool>() {
        return Ok(if value { "true" } else { "false" }.to_string());
    }
    if let Ok(value) = key.extract::<i64>() {
        return Ok(value.to_string());
    }
    if let Ok(value) = key.extract::<u64>() {
        return Ok(value.to_string());
    }
    if let Ok(value) = key.extract::<f64>() {
        if value.is_finite() {
            return key.str()?.extract::<String>();
        }
    }
    Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
        "unsupported fast path JSON object key",
    ))
}

fn json_serialization_error(error: impl std::fmt::Display) -> PyErr {
    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("json serialization failed: {error}"))
}

async fn hyper_to_http_request(request: HyperRequest<Incoming>) -> Result<HttpRequest, String> {
    let (parts, body) = request.into_parts();
    let method = parts.method.as_str().to_string();
    let target = parts
        .uri
        .path_and_query()
        .map(|path_and_query| path_and_query.as_str().to_string())
        .unwrap_or_else(|| "/".to_string());
    let headers = parts
        .headers
        .iter()
        .map(|(name, value)| {
            (
                name.as_str().to_string(),
                value.to_str().unwrap_or("").to_string(),
            )
        })
        .collect();
    let collected = body.collect().await.map_err(|error| error.to_string())?;
    let body = collected.to_bytes();
    Ok(HttpRequest {
        method,
        target,
        headers,
        body: if body.is_empty() {
            None
        } else {
            Some(body.to_vec())
        },
    })
}

#[cfg(test)]
fn read_http_request(stream: &mut impl Read) -> std::io::Result<HttpRequest> {
    let mut received = Vec::new();
    let mut buffer = [0_u8; 8192];
    let (header_end, delimiter_len) = loop {
        let bytes_read = stream.read(&mut buffer)?;
        if bytes_read == 0 {
            return Err(std::io::Error::new(
                std::io::ErrorKind::UnexpectedEof,
                "missing request headers",
            ));
        }
        received.extend_from_slice(&buffer[..bytes_read]);
        if let Some(bounds) = find_header_end(&received) {
            break bounds;
        }
        if received.len() > 64 * 1024 {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "request headers too large",
            ));
        }
    };

    let request_head = String::from_utf8_lossy(&received[..header_end]);
    let mut request = parse_http_request_head(&request_head)?;
    let content_length = content_length(&request.headers)?;
    let body_start = header_end + delimiter_len;
    let mut body = received[body_start..].to_vec();
    while body.len() < content_length {
        let remaining = content_length - body.len();
        let read_len = remaining.min(buffer.len());
        let bytes_read = stream.read(&mut buffer[..read_len])?;
        if bytes_read == 0 {
            return Err(std::io::Error::new(
                std::io::ErrorKind::UnexpectedEof,
                "request body shorter than content-length",
            ));
        }
        body.extend_from_slice(&buffer[..bytes_read]);
    }
    if body.len() > content_length {
        body.truncate(content_length);
    }
    if has_content_length(&request.headers) {
        request.body = Some(body);
    }
    Ok(request)
}

#[cfg(test)]
fn parse_http_request_head(head: &str) -> std::io::Result<HttpRequest> {
    let mut lines = head.lines();
    let request_line = lines.next().ok_or_else(|| {
        std::io::Error::new(std::io::ErrorKind::InvalidData, "missing request line")
    })?;
    let mut request_parts = request_line.split_whitespace();
    let method = request_parts
        .next()
        .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::InvalidData, "missing method"))?;
    let target = request_parts
        .next()
        .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::InvalidData, "missing target"))?;
    let headers = lines
        .filter_map(|line| {
            let (key, value) = line.split_once(':')?;
            Some((key.trim().to_string(), value.trim().to_string()))
        })
        .collect();
    Ok(HttpRequest {
        method: method.to_string(),
        target: target.to_string(),
        headers,
        body: None,
    })
}

fn dispatch_http_response(
    app: &Py<PyAny>,
    request: HttpRequest,
) -> PyResult<HyperResponse<Full<Bytes>>> {
    Python::attach(|py| {
        let kwargs = PyDict::new(py);
        kwargs.set_item("headers", request.headers)?;
        if let Some(body) = request.body {
            kwargs.set_item("raw_body", PyBytes::new(py, &body))?;
        }
        let response = app.bind(py).call_method(
            "handle_request",
            (request.method, request.target),
            Some(&kwargs),
        )?;
        let status = response.getattr("status_code")?.extract::<u16>()?;
        let body = response.getattr("body")?.extract::<Vec<u8>>()?;
        let raw_headers = response.getattr("headers")?.call_method0("raw_items")?;
        let mut headers = Vec::new();
        for item in raw_headers.try_iter()? {
            headers.push(item?.extract::<(String, String)>()?);
        }
        Ok(hyper_response(status, headers, body))
    })
}

fn hyper_response(
    status: u16,
    headers: Vec<(String, String)>,
    body: Vec<u8>,
) -> HyperResponse<Full<Bytes>> {
    let body_len = body.len();
    let mut response = HyperResponse::new(Full::new(Bytes::from(body)));
    *response.status_mut() = StatusCode::from_u16(status).unwrap_or(StatusCode::OK);
    let mut has_content_length = false;
    for (key, value) in headers {
        let Ok(name) = HeaderName::from_bytes(key.as_bytes()) else {
            continue;
        };
        let Ok(header_value) = HeaderValue::from_str(&value) else {
            continue;
        };
        if name == CONTENT_LENGTH {
            has_content_length = true;
        }
        response.headers_mut().append(name, header_value);
    }
    if !has_content_length {
        response.headers_mut().insert(
            CONTENT_LENGTH,
            HeaderValue::from_str(&body_len.to_string())
                .unwrap_or_else(|_| HeaderValue::from_static("0")),
        );
    }
    response
}

fn hyper_response_parts(
    response: HyperResponse<Full<Bytes>>,
    used_fast_path: bool,
) -> PyResult<(u16, Vec<(String, String)>, Vec<u8>, bool)> {
    let status = response.status().as_u16();
    let headers = response
        .headers()
        .iter()
        .filter_map(|(name, value)| {
            value
                .to_str()
                .ok()
                .map(|value| (name.as_str().to_string(), value.to_string()))
        })
        .collect();
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|error| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                "failed to collect response body: {error}"
            ))
        })?;
    let collected = match runtime.block_on(response.into_body().collect()) {
        Ok(collected) => collected,
        Err(error) => match error {},
    };
    Ok((
        status,
        headers,
        collected.to_bytes().to_vec(),
        used_fast_path,
    ))
}

fn error_response(
    status: StatusCode,
    message: String,
    force_connection_close: bool,
) -> HyperResponse<Full<Bytes>> {
    let mut response = hyper_response(
        status.as_u16(),
        vec![(
            CONTENT_TYPE.as_str().to_string(),
            "text/plain; charset=utf-8".to_string(),
        )],
        message.into_bytes(),
    );
    if force_connection_close {
        response
            .headers_mut()
            .insert(CONNECTION, HeaderValue::from_static("close"));
    }
    response
}

fn with_connection_policy(
    mut response: HyperResponse<Full<Bytes>>,
    close: bool,
) -> HyperResponse<Full<Bytes>> {
    response.headers_mut().insert(
        CONNECTION,
        if close {
            HeaderValue::from_static("close")
        } else {
            HeaderValue::from_static("keep-alive")
        },
    );
    response
}

fn hyper_request_wants_close(request: &HyperRequest<Incoming>) -> bool {
    request.headers().get_all(CONNECTION).iter().any(|value| {
        value
            .to_str()
            .map(|text| {
                text.split(',')
                    .any(|token| token.trim().eq_ignore_ascii_case("close"))
            })
            .unwrap_or(false)
    })
}

#[cfg(test)]
fn find_header_end(buffer: &[u8]) -> Option<(usize, usize)> {
    if let Some(index) = buffer.windows(4).position(|window| window == b"\r\n\r\n") {
        return Some((index, 4));
    }
    buffer
        .windows(2)
        .position(|window| window == b"\n\n")
        .map(|index| (index, 2))
}

#[cfg(test)]
fn content_length(headers: &[(String, String)]) -> std::io::Result<usize> {
    let Some(value) = headers
        .iter()
        .rev()
        .find(|(key, _)| key.eq_ignore_ascii_case("content-length"))
        .map(|(_, value)| value)
    else {
        return Ok(0);
    };
    value.parse::<usize>().map_err(|_| {
        std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "invalid content-length header",
        )
    })
}

#[cfg(test)]
fn has_content_length(headers: &[(String, String)]) -> bool {
    headers
        .iter()
        .any(|(key, _)| key.eq_ignore_ascii_case("content-length"))
}

fn match_route_inner(pattern: &str, path: &str) -> Option<Vec<(String, String)>> {
    let pattern_segments = split_path(pattern);
    let path_segments = split_path(path);

    let mut captures = Vec::new();
    let mut pattern_index = 0;
    let mut path_index = 0;
    while pattern_index < pattern_segments.len() {
        let pattern_segment = pattern_segments[pattern_index];
        if let Some((name, captures_path)) = parameter_name(pattern_segment) {
            if captures_path {
                let remainder = path_segments[path_index..].join("/");
                captures.push((name.to_string(), percent_decode(&remainder)));
                return Some(captures);
            }
            let path_segment = path_segments.get(path_index)?;
            captures.push((name.to_string(), percent_decode(path_segment)));
            path_index += 1;
        } else {
            let path_segment = path_segments.get(path_index)?;
            if pattern_segment != *path_segment {
                return None;
            }
            path_index += 1;
        }
        pattern_index += 1;
    }
    if path_index != path_segments.len() {
        return None;
    }
    Some(captures)
}

fn parameter_name(segment: &str) -> Option<(&str, bool)> {
    if segment.len() < 3 || !segment.starts_with('{') || !segment.ends_with('}') {
        return None;
    }
    let inner = &segment[1..segment.len() - 1];
    if inner.is_empty() {
        return None;
    }
    if let Some((name, converter)) = inner.split_once(':') {
        if name.is_empty() {
            return None;
        }
        return Some((name, converter == "path"));
    }
    Some((inner, false))
}

fn split_path(path: &str) -> Vec<&str> {
    let trimmed = path.trim_matches('/');
    if trimmed.is_empty() {
        Vec::new()
    } else {
        trimmed.split('/').collect()
    }
}

fn percent_decode(value: &str) -> String {
    percent_decode_inner(value, false)
}

fn query_decode(value: &str) -> String {
    percent_decode_inner(value, true)
}

fn percent_decode_inner(value: &str, plus_as_space: bool) -> String {
    let bytes = value.as_bytes();
    let mut decoded = Vec::with_capacity(bytes.len());
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index] == b'%' && index + 2 < bytes.len() {
            if let (Some(high), Some(low)) =
                (hex_value(bytes[index + 1]), hex_value(bytes[index + 2]))
            {
                decoded.push((high << 4) | low);
                index += 3;
                continue;
            }
        }
        if plus_as_space && bytes[index] == b'+' {
            decoded.push(b' ');
        } else {
            decoded.push(bytes[index]);
        }
        index += 1;
    }
    String::from_utf8_lossy(&decoded).into_owned()
}

fn parse_query_string_inner(query: &str) -> Vec<(String, String)> {
    if query.is_empty() {
        return Vec::new();
    }

    query
        .split('&')
        .map(|part| {
            let (key, value) = part.split_once('=').unwrap_or((part, ""));
            (query_decode(key), query_decode(value))
        })
        .collect()
}

fn normalize_headers_inner(headers: Vec<(String, String)>) -> Vec<(String, Vec<String>)> {
    let mut normalized = Vec::<(String, Vec<String>)>::new();
    let mut indexes = HashMap::<String, usize>::new();

    for (key, value) in headers {
        let normalized_key = key.to_lowercase();
        if let Some(index) = indexes.get(&normalized_key) {
            normalized[*index].1.push(value);
        } else {
            indexes.insert(normalized_key.clone(), normalized.len());
            normalized.push((normalized_key, vec![value]));
        }
    }

    normalized
}

fn parse_cookie_header_inner(header: &str) -> Vec<(String, String)> {
    let mut cookies = Vec::new();

    for part in header.split(';') {
        let trimmed = part.trim();
        if trimmed.is_empty() {
            continue;
        }
        let Some((name, value)) = trimmed.split_once('=') else {
            continue;
        };
        let name = name.trim();
        if name.is_empty() {
            continue;
        }
        cookies.push((name.to_string(), normalize_cookie_value(value.trim())));
    }

    cookies
}

fn normalize_cookie_value(value: &str) -> String {
    if value.len() >= 2 && value.starts_with('"') && value.ends_with('"') {
        value[1..value.len() - 1].to_string()
    } else {
        value.to_string()
    }
}

fn hex_value(value: u8) -> Option<u8> {
    match value {
        b'0'..=b'9' => Some(value - b'0'),
        b'a'..=b'f' => Some(value - b'a' + 10),
        b'A'..=b'F' => Some(value - b'A' + 10),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::{
        match_route_inner, normalize_headers_inner, parse_cookie_header_inner,
        parse_query_string_inner, read_http_request, split_path, RouteIndexMatch, RouteIndexNode,
    };
    use std::io::Cursor;

    fn route_index_matches(root: &RouteIndexNode, path: &str) -> Vec<RouteIndexMatch> {
        let segments = split_path(path);
        let mut matches = Vec::new();
        root.collect_matches(&segments, 0, &mut Vec::new(), &mut matches);
        matches
    }

    #[test]
    fn matches_static_path() {
        assert_eq!(match_route_inner("/items", "/items"), Some(vec![]));
        assert_eq!(match_route_inner("/items", "/users"), None);
    }

    #[test]
    fn captures_path_params() {
        assert_eq!(
            match_route_inner("/items/{item_id}", "/items/abc%20123"),
            Some(vec![("item_id".to_string(), "abc 123".to_string())])
        );
    }

    #[test]
    fn captures_path_converter_params() {
        assert_eq!(
            match_route_inner("/files/{file_path:path}", "/files//home/user/report.txt"),
            Some(vec![(
                "file_path".to_string(),
                "/home/user/report.txt".to_string()
            )])
        );
    }

    #[test]
    fn route_index_preserves_registration_order_for_overlapping_routes() {
        let mut root = RouteIndexNode::default();
        root.insert("/{item_id}", 0);
        root.insert("/health", 1);

        let best = route_index_matches(&root, "/health")
            .into_iter()
            .min_by_key(|route_match| route_match.route_index)
            .unwrap();

        assert_eq!(best.route_index, 0);
        assert_eq!(
            best.path_params,
            vec![("item_id".to_string(), "health".to_string())]
        );
    }

    #[test]
    fn route_index_uses_route_specific_parameter_names() {
        let mut root = RouteIndexNode::default();
        root.insert("/items/{item_id}/detail", 0);
        root.insert("/items/{slug}/summary", 1);

        let best = route_index_matches(&root, "/items/book/summary")
            .into_iter()
            .min_by_key(|route_match| route_match.route_index)
            .unwrap();

        assert_eq!(best.route_index, 1);
        assert_eq!(
            best.path_params,
            vec![("slug".to_string(), "book".to_string())]
        );
    }

    #[test]
    fn route_index_captures_path_converter_remainder() {
        let mut root = RouteIndexNode::default();
        root.insert("/files/{file_path:path}", 0);

        let best = route_index_matches(&root, "/files//home/user/report.txt")
            .into_iter()
            .min_by_key(|route_match| route_match.route_index)
            .unwrap();

        assert_eq!(
            best.path_params,
            vec![("file_path".to_string(), "/home/user/report.txt".to_string())]
        );
    }

    #[test]
    fn parses_query_params() {
        assert_eq!(
            parse_query_string_inner("q=hello+world&q=again&empty=&encoded=a%2Fb"),
            vec![
                ("q".to_string(), "hello world".to_string()),
                ("q".to_string(), "again".to_string()),
                ("empty".to_string(), "".to_string()),
                ("encoded".to_string(), "a/b".to_string()),
            ]
        );
    }

    #[test]
    fn parses_query_param_without_equals() {
        assert_eq!(
            parse_query_string_inner("flag"),
            vec![("flag".to_string(), "".to_string())]
        );
    }

    #[test]
    fn normalizes_header_names() {
        assert_eq!(
            normalize_headers_inner(vec![(
                "Content-Type".to_string(),
                "application/json".to_string()
            )]),
            vec![(
                "content-type".to_string(),
                vec!["application/json".to_string()]
            )]
        );
    }

    #[test]
    fn merges_repeated_headers_in_order() {
        assert_eq!(
            normalize_headers_inner(vec![
                ("X-Token".to_string(), "first".to_string()),
                ("x-token".to_string(), "second".to_string()),
                ("Accept".to_string(), "application/json".to_string()),
            ]),
            vec![
                (
                    "x-token".to_string(),
                    vec!["first".to_string(), "second".to_string()]
                ),
                ("accept".to_string(), vec!["application/json".to_string()]),
            ]
        );
    }

    #[test]
    fn parses_cookie_header() {
        assert_eq!(
            parse_cookie_header_inner("session=abc; theme=dark; quoted=\"hello world\""),
            vec![
                ("session".to_string(), "abc".to_string()),
                ("theme".to_string(), "dark".to_string()),
                ("quoted".to_string(), "hello world".to_string()),
            ]
        );
    }

    #[test]
    fn skips_invalid_cookie_parts() {
        assert_eq!(
            parse_cookie_header_inner("session=abc; ; flag; =empty; spaced = value"),
            vec![
                ("session".to_string(), "abc".to_string()),
                ("spaced".to_string(), "value".to_string()),
            ]
        );
    }

    #[test]
    fn reads_content_length_body() {
        let mut request = Cursor::new(
            b"POST /items HTTP/1.1\r\n\
              Host: 127.0.0.1\r\n\
              Content-Type: application/json\r\n\
              Content-Length: 12\r\n\r\n\
              {\"name\":\"x\"}"
                .to_vec(),
        );

        let parsed = read_http_request(&mut request).unwrap();

        assert_eq!(parsed.method, "POST");
        assert_eq!(parsed.target, "/items");
        assert_eq!(parsed.body, Some(b"{\"name\":\"x\"}".to_vec()));
    }
}
