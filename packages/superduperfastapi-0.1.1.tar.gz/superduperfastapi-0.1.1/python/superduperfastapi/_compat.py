from __future__ import annotations

import sys
import types
from collections import deque
from collections.abc import Sequence
from typing import Any, Union, get_args, get_origin

from pydantic import __version__ as PYDANTIC_VERSION
from pydantic_core import PydanticUndefined as Undefined

from .datastructures import UploadFile


def _version_tuple(version: str) -> tuple[int, int]:
    major, minor, *_ = version.split(".")
    return int(major), int(minor)


PYDANTIC_VERSION_MINOR_TUPLE = _version_tuple(PYDANTIC_VERSION)

sequence_annotation_to_type = {
    Sequence: list,
    list: list,
    tuple: tuple,
    set: set,
    frozenset: frozenset,
    deque: deque,
}
sequence_types = tuple(sequence_annotation_to_type)


def _is_union(annotation: Any) -> bool:
    return get_origin(annotation) in (Union, types.UnionType)


def _lenient_issubclass(annotation: Any, class_or_tuple: Any) -> bool:
    try:
        return isinstance(annotation, type) and issubclass(annotation, class_or_tuple)
    except TypeError:
        return False


def field_annotation_is_sequence(annotation: Any) -> bool:
    if _is_union(annotation):
        return any(field_annotation_is_sequence(arg) for arg in get_args(annotation))
    if _lenient_issubclass(annotation, (str, bytes)):
        return False
    origin = get_origin(annotation)
    return _lenient_issubclass(annotation, sequence_types) or _lenient_issubclass(origin, sequence_types)


def is_bytes_or_nonable_bytes_annotation(annotation: Any) -> bool:
    if _lenient_issubclass(annotation, bytes):
        return True
    if _is_union(annotation):
        return any(_lenient_issubclass(arg, bytes) for arg in get_args(annotation))
    return False


def is_uploadfile_or_nonable_uploadfile_annotation(annotation: Any) -> bool:
    if _lenient_issubclass(annotation, UploadFile):
        return True
    if _is_union(annotation):
        return any(_lenient_issubclass(arg, UploadFile) for arg in get_args(annotation))
    return False


def is_bytes_sequence_annotation(annotation: Any) -> bool:
    if _is_union(annotation):
        return any(is_bytes_sequence_annotation(arg) for arg in get_args(annotation))
    return field_annotation_is_sequence(annotation) and all(
        is_bytes_or_nonable_bytes_annotation(arg) for arg in get_args(annotation)
    )


def is_uploadfile_sequence_annotation(annotation: Any) -> bool:
    if _is_union(annotation):
        return any(is_uploadfile_sequence_annotation(arg) for arg in get_args(annotation))
    return field_annotation_is_sequence(annotation) and all(
        is_uploadfile_or_nonable_uploadfile_annotation(arg) for arg in get_args(annotation)
    )


class ModelField:
    def __init__(self, name: str, field_info: Any) -> None:
        self.name = name
        self.field_info = field_info

    @property
    def default(self) -> Any:
        return getattr(self.field_info, "default", Undefined)


def serialize_sequence_value(*, field: ModelField, value: Any) -> Sequence[Any]:
    annotation = field.field_info.annotation
    origin_type = get_origin(annotation) or annotation
    if _is_union(annotation):
        for union_arg in get_args(annotation):
            if union_arg is type(None):
                continue
            origin_type = get_origin(union_arg) or union_arg
            break
    return sequence_annotation_to_type[origin_type](value)


shared = types.ModuleType("fastapi._compat.shared")
shared.sequence_annotation_to_type = sequence_annotation_to_type
shared.sequence_types = sequence_types
shared.field_annotation_is_sequence = field_annotation_is_sequence
shared.is_bytes_or_nonable_bytes_annotation = is_bytes_or_nonable_bytes_annotation
shared.is_bytes_sequence_annotation = is_bytes_sequence_annotation
shared.is_uploadfile_or_nonable_uploadfile_annotation = is_uploadfile_or_nonable_uploadfile_annotation
shared.is_uploadfile_sequence_annotation = is_uploadfile_sequence_annotation

v2 = types.ModuleType("fastapi._compat.v2")
v2.ModelField = ModelField
v2.serialize_sequence_value = serialize_sequence_value
v2.Undefined = Undefined

__path__: list[str] = []
sys.modules.setdefault("fastapi._compat.shared", shared)
sys.modules.setdefault("fastapi._compat.v2", v2)
sys.modules.setdefault("superduperfastapi._compat.shared", shared)
sys.modules.setdefault("superduperfastapi._compat.v2", v2)

__all__ = [
    "PYDANTIC_VERSION",
    "PYDANTIC_VERSION_MINOR_TUPLE",
    "Undefined",
    "is_bytes_sequence_annotation",
    "is_uploadfile_sequence_annotation",
    "shared",
    "v2",
]
