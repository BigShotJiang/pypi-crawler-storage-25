from typing import Literal

from pydantic import BaseModel

SchemaType = Literal["array", "boolean", "integer", "null", "number", "object", "string"]


class Schema(BaseModel):
    type: SchemaType | list[SchemaType] | None = None
