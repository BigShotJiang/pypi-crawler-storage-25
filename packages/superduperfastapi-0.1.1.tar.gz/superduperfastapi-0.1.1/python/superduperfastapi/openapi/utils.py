from __future__ import annotations

from typing import Any, Sequence


def get_openapi(
    *,
    title: str,
    version: str,
    routes: Sequence[Any],
    openapi_version: str = "3.1.0",
    summary: str | None = None,
    description: str | None = None,
    webhooks: Sequence[Any] | None = None,
    tags: list[dict[str, Any]] | None = None,
    servers: list[dict[str, Any]] | None = None,
    terms_of_service: str | None = None,
    contact: dict[str, Any] | None = None,
    license_info: dict[str, Any] | None = None,
    external_docs: dict[str, Any] | None = None,
    **_: Any,
) -> dict[str, Any]:
    from ..applications import FastAPI

    app = FastAPI(
        title=title,
        version=version,
        summary=summary,
        description=description,
        terms_of_service=terms_of_service,
        contact=contact,
        license_info=license_info,
        openapi_tags=tags,
        servers=servers,
        openapi_external_docs=external_docs,
    )
    app.routes = list(routes)
    if webhooks is not None:
        app.webhooks.routes = list(webhooks)
    schema = app.openapi()
    schema["openapi"] = openapi_version
    return schema
