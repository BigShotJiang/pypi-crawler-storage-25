from __future__ import annotations

import json
from typing import Any

from ..responses import Response


swagger_ui_default_parameters: dict[str, Any] = {
    "dom_id": "#swagger-ui",
    "layout": "BaseLayout",
    "deepLinking": True,
    "showExtensions": True,
    "showCommonExtensions": True,
}


def get_swagger_ui_html(
    *,
    openapi_url: str,
    title: str,
    swagger_js_url: str = "https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js",
    swagger_css_url: str = "https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css",
    swagger_favicon_url: str = "https://fastapi.tiangolo.com/img/favicon.png",
    oauth2_redirect_url: str | None = None,
    init_oauth: dict[str, Any] | None = None,
    swagger_ui_parameters: dict[str, Any] | None = None,
    **_: Any,
) -> Response:
    current_swagger_ui_parameters = dict(swagger_ui_default_parameters)
    if swagger_ui_parameters:
        current_swagger_ui_parameters.update(swagger_ui_parameters)

    parts = [
        "<!DOCTYPE html>",
        "<html>",
        "<head>",
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">',
        f'<link type="text/css" rel="stylesheet" href="{swagger_css_url}">',
        f'<link rel="shortcut icon" href="{swagger_favicon_url}">',
        f"<title>{title}</title>",
        "</head>",
        "<body>",
        '<div id="swagger-ui"></div>',
        f'<script src="{swagger_js_url}"></script>',
        "<script>",
        "const ui = SwaggerUIBundle({",
        f"url: '{openapi_url}',",
    ]
    for key, value in current_swagger_ui_parameters.items():
        parts.append(f"{_safe_json(key)}: {_safe_json(value)},")
    if oauth2_redirect_url:
        parts.append(f"oauth2RedirectUrl: window.location.origin + '{oauth2_redirect_url}',")
    parts.extend(
        [
            "presets: [",
            "SwaggerUIBundle.presets.apis,",
            "SwaggerUIBundle.SwaggerUIStandalonePreset",
            "],",
            "})",
        ]
    )
    if init_oauth:
        parts.append("ui.initOAuth(" + _safe_json(init_oauth) + ")")
    parts.extend(["</script>", "</body>", "</html>"])
    return Response("\n".join(parts), media_type="text/html; charset=utf-8")


def get_swagger_ui_oauth2_redirect_html() -> Response:
    return Response(
        """
<!doctype html>
<html lang="en-US">
<head>
    <title>Swagger UI: OAuth2 Redirect</title>
</head>
<body>
<script>
    'use strict';
    function run () {
        var oauth2 = window.opener.swaggerUIRedirectOauth2;
    }
</script>
</body>
</html>
""",
        media_type="text/html; charset=utf-8",
    )


def get_redoc_html(
    *,
    openapi_url: str,
    title: str,
    redoc_js_url: str = "https://cdn.jsdelivr.net/npm/redoc@2/bundles/redoc.standalone.js",
    redoc_favicon_url: str = "https://fastapi.tiangolo.com/img/favicon.png",
    with_google_fonts: bool = True,
) -> Response:
    parts = [
        "<!DOCTYPE html>",
        "<html>",
        "<head>",
        f"<title>{title}</title>",
        '<meta charset="utf-8"/>',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
    ]
    if with_google_fonts:
        parts.append(
            '<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,700|Roboto:300,400,700" rel="stylesheet">'
        )
    parts.extend(
        [
            f'<link rel="shortcut icon" href="{redoc_favicon_url}">',
            "</head>",
            "<body>",
            '<noscript>ReDoc requires Javascript to function. Please enable it to browse the documentation.</noscript>',
            f'<redoc spec-url="{openapi_url}"></redoc>',
            f'<script src="{redoc_js_url}"> </script>',
            "</body>",
            "</html>",
        ]
    )
    return Response("\n".join(parts), media_type="text/html; charset=utf-8")


def _safe_json(value: Any) -> str:
    return (
        json.dumps(value)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )
