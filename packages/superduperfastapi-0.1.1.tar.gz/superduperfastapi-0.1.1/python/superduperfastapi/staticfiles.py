from __future__ import annotations


class StaticFiles:
    def __init__(self, *, directory: str) -> None:
        self.directory = directory


__all__ = ["StaticFiles"]
