class FastAPIError(RuntimeError):
    pass


class FastAPIDeprecationWarning(DeprecationWarning):
    pass


class PydanticV1NotSupportedError(RuntimeError):
    pass


class HTTPException(Exception):
    def __init__(
        self,
        status_code: int,
        detail: object = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status_code = status_code
        self.detail = detail if detail is not None else {404: "Not Found"}.get(status_code)
        self.headers = headers


class WebSocketException(Exception):
    def __init__(self, code: int, reason: str | None = None) -> None:
        self.code = code
        self.reason = reason or ""


class RequestValidationError(Exception):
    def __init__(
        self,
        errors: list[dict[str, object]],
        body: object = None,
        endpoint_ctx: dict[str, object] | None = None,
        **_: object,
    ) -> None:
        self._errors = [_normalize_error(error) for error in errors]
        self.body = body
        self.endpoint_ctx = endpoint_ctx or {}

    def errors(self) -> list[dict[str, object]]:
        return self._errors

    def __str__(self) -> str:
        return _validation_error_text(self._errors, self.endpoint_ctx)


class WebSocketRequestValidationError(RequestValidationError):
    pass


def _normalize_error(error: dict[str, object]) -> dict[str, object]:
    normalized = dict(error)
    loc = normalized.get("loc")
    if isinstance(loc, list):
        normalized["loc"] = tuple(loc)
    return normalized


class ResponseValidationError(Exception):
    def __init__(
        self,
        errors: list[dict[str, object]],
        body: object = None,
        endpoint_ctx: dict[str, object] | None = None,
    ) -> None:
        self._errors = errors
        self.body = body
        self.endpoint_ctx = endpoint_ctx or {}
        super().__init__(self.__str__())

    def errors(self) -> list[dict[str, object]]:
        return self._errors

    def __str__(self) -> str:
        return _validation_error_text(self._errors, self.endpoint_ctx)


def _validation_error_text(errors: list[dict[str, object]], endpoint_ctx: dict[str, object]) -> str:
    count = len(errors)
    label = "validation error" if count == 1 else "validation errors"
    lines = [f"{count} {label}:"]
    path = endpoint_ctx.get("path")
    if path:
        lines.append(f"Endpoint: {path}")
    name = endpoint_ctx.get("name")
    if name:
        lines.append(f"Function: {name}")
    file = endpoint_ctx.get("file")
    line = endpoint_ctx.get("line")
    if file and line:
        lines.append(f'File "{file}", line {line}')
    lines.append(str(errors))
    return "\n".join(lines)
