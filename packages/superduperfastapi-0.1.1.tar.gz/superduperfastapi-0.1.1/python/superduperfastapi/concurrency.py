from __future__ import annotations

from collections.abc import AsyncIterator, Callable, Iterator
from typing import Any, TypeVar

T = TypeVar("T")


async def run_in_threadpool(func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    return func(*args, **kwargs)


async def iterate_in_threadpool(iterator: Iterator[T]) -> AsyncIterator[T]:
    for item in iterator:
        yield item
