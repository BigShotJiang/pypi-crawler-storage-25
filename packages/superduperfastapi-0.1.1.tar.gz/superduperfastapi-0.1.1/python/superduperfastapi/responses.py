from __future__ import annotations

import asyncio
import importlib
import inspect
import json
import mimetypes
import sys
import time as time_module
import warnings
from dataclasses import asdict, is_dataclass
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from http.cookies import SimpleCookie
from enum import Enum
from pathlib import PurePath
from typing import Any
from uuid import UUID

from ._core import core
from .exceptions import FastAPIDeprecationWarning

try:
    ujson = importlib.import_module("ujson")
except ModuleNotFoundError:  # pragma: no cover
    ujson = None


try:
    orjson = importlib.import_module("orjson")
except ModuleNotFoundError:  # pragma: no cover
    orjson = None


class Headers(dict[str, Any]):
    def __init__(self, headers: dict[str, str] | list[tuple[str, str]] | None = None) -> None:
        super().__init__()
        items = (headers or {}).items() if hasattr(headers or {}, "items") else headers or []
        normalized = core.normalize_headers([(str(key), str(value)) for key, value in items])
        for key, values in normalized:
            super().__setitem__(key, values[0] if len(values) == 1 else values)

    def __getitem__(self, key: str) -> str:
        value = super().__getitem__(key.lower())
        return value[-1] if isinstance(value, list) else value

    def __setitem__(self, key: str, value: str) -> None:
        super().__setitem__(key.lower(), value)

    def __contains__(self, key: object) -> bool:
        if isinstance(key, str):
            return super().__contains__(key.lower())
        return super().__contains__(key)

    def add(self, key: str, value: str) -> None:
        normalized = key.lower()
        existing = super().get(normalized)
        if existing is None:
            super().__setitem__(normalized, value)
        elif isinstance(existing, list):
            existing.append(value)
        else:
            super().__setitem__(normalized, [existing, value])

    def get(self, key: str, default: Any = None) -> Any:
        value = super().get(key.lower(), default)
        return value[-1] if isinstance(value, list) else value

    def getlist(self, key: str) -> list[str]:
        value = super().get(key.lower())
        if value is None:
            return []
        if isinstance(value, list):
            return value
        return [value]

    def items(self) -> Any:
        for key, value in super().items():
            if isinstance(value, list):
                yield key, ", ".join(value)
            else:
                yield key, value

    def raw_items(self) -> Any:
        for key, value in super().items():
            if isinstance(value, list):
                for item in value:
                    yield key, item
            else:
                yield key, value


class Response:
    media_type: str | None = None

    def __init__(
        self,
        content: Any = b"",
        status_code: int = 200,
        media_type: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.content = content
        self.status_code = status_code
        if media_type is not None:
            self.media_type = media_type
        self.raw_headers = Headers(headers)
        if self.media_type is not None:
            self.raw_headers.setdefault("content-type", self.media_type)
        self._body = b"" if self.status_code in {204, 304} else self.render(self.content)

    @property
    def body(self) -> bytes:
        return self._body

    def render(self, content: Any) -> bytes:
        if isinstance(content, bytes):
            return content
        if content is None:
            return b""
        return str(content).encode("utf-8")

    @property
    def headers(self) -> Headers:
        return self.raw_headers

    def set_cookie(
        self,
        key: str,
        value: str = "",
        max_age: int | None = None,
        expires: int | str | None = None,
        path: str | None = "/",
        domain: str | None = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: str | None = "lax",
    ) -> None:
        if samesite is not None and samesite.lower() not in {"strict", "lax", "none"}:
            raise AssertionError("samesite must be either 'strict', 'lax' or 'none'")
        cookie = SimpleCookie()
        cookie[key] = value
        morsel = cookie[key]
        if max_age is not None:
            morsel["max-age"] = str(max_age)
        if expires is not None:
            morsel["expires"] = str(expires)
        if path is not None:
            morsel["path"] = path
        if domain is not None:
            morsel["domain"] = domain
        if secure:
            morsel["secure"] = True
        if httponly:
            morsel["httponly"] = True
        if samesite is not None:
            morsel["samesite"] = samesite
        self.raw_headers.add("set-cookie", morsel.OutputString())

    def delete_cookie(
        self,
        key: str,
        path: str = "/",
        domain: str | None = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: str | None = "lax",
    ) -> None:
        self.set_cookie(
            key,
            max_age=0,
            expires=0,
            path=path,
            domain=domain,
            secure=secure,
            httponly=httponly,
            samesite=samesite,
        )


class JSONResponse(Response):
    media_type = "application/json"

    def render(self, content: Any) -> bytes:
        return json.dumps(_jsonable(content), separators=(",", ":")).encode("utf-8")


class UJSONResponse(JSONResponse):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        warnings.warn(
            "UJSONResponse is deprecated",
            FastAPIDeprecationWarning,
            stacklevel=2,
        )
        super().__init__(*args, **kwargs)

    def render(self, content: Any) -> bytes:
        assert ujson is not None, "ujson must be installed to use UJSONResponse"
        return ujson.dumps(content, ensure_ascii=False).encode("utf-8")


class ORJSONResponse(JSONResponse):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        warnings.warn(
            "ORJSONResponse is deprecated",
            FastAPIDeprecationWarning,
            stacklevel=2,
        )
        super().__init__(*args, **kwargs)

    def render(self, content: Any) -> bytes:
        assert orjson is not None, "orjson must be installed to use ORJSONResponse"
        return orjson.dumps(
            content,
            option=orjson.OPT_NON_STR_KEYS | orjson.OPT_SERIALIZE_NUMPY,
        )


class PlainTextResponse(Response):
    media_type = "text/plain; charset=utf-8"


class HTMLResponse(Response):
    media_type = "text/html; charset=utf-8"


class RedirectResponse(Response):
    def __init__(
        self,
        url: str,
        status_code: int = 307,
        headers: dict[str, str] | None = None,
    ) -> None:
        response_headers = {**(headers or {}), "location": url}
        super().__init__(b"", status_code=status_code, headers=response_headers)


class FileResponse(Response):
    def __init__(
        self,
        path: str,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        media_type: str | None = None,
        filename: str | None = None,
        *_: Any,
        **__: Any,
    ) -> None:
        guessed_media_type = media_type or mimetypes.guess_type(path)[0] or "text/plain"
        response_headers = dict(headers or {})
        if filename is not None:
            response_headers.setdefault(
                "content-disposition",
                f'attachment; filename="{filename}"',
            )
        with open(path, "rb") as file:
            content = file.read()
        super().__init__(
            content,
            status_code=status_code,
            media_type=guessed_media_type,
            headers=response_headers,
        )


class StreamingResponse(Response):
    def __init__(
        self,
        content: Any = b"",
        status_code: int = 200,
        media_type: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.content = content
        self.status_code = status_code
        if media_type is not None:
            self.media_type = media_type
        self.raw_headers = Headers(headers)
        if self.media_type is not None:
            self.raw_headers.setdefault("content-type", self.media_type)
        self._body: bytes | None = None

    @property
    def body(self) -> bytes:
        if self._body is None:
            self._body = b"" if self.status_code in {204, 304} else self.render(self.content)
        return self._body

    def render(self, content: Any) -> bytes:
        if isinstance(content, (bytes, str)) or content is None:
            return super().render(content)
        if inspect.isasyncgen(content):
            async def collect() -> bytes:
                chunks: list[bytes] = []
                async for item in content:
                    chunks.append(item if isinstance(item, bytes) else str(item).encode("utf-8"))
                return b"".join(chunks)

            return asyncio.run(collect())
        if inspect.isawaitable(content):
            return self.render(asyncio.run(content))
        return b"".join(
            item if isinstance(item, bytes) else str(item).encode("utf-8")
            for item in content
        )


class ServerSentEvent:
    def __init__(
        self,
        data: Any = None,
        *,
        event: str | None = None,
        id: str | None = None,
        retry: int | None = None,
        comment: str | None = None,
        raw_data: str | None = None,
    ) -> None:
        if data is not None and raw_data is not None:
            raise ValueError("Cannot set both data and raw_data")
        if id is not None and "\0" in id:
            raise ValueError("id cannot contain null characters")
        if retry is not None and (not isinstance(retry, int) or retry < 0):
            raise ValueError("retry must be a non-negative integer")
        self.data = data
        self.event = event
        self.id = id
        self.retry = retry
        self.comment = comment
        self.raw_data = raw_data

    def encode(self) -> str:
        lines: list[str] = []
        if self.comment is not None:
            lines.append(f": {self.comment}")
        if self.event is not None:
            lines.append(f"event: {self.event}")
        if self.id is not None:
            lines.append(f"id: {self.id}")
        if self.retry is not None:
            lines.append(f"retry: {self.retry}")
        if self.raw_data is not None:
            lines.append(f"data: {self.raw_data}")
        elif self.data is not None:
            lines.append(f"data: {json.dumps(_jsonable(self.data))}")
        return "\n".join(lines) + "\n\n"


class EventSourceResponse(StreamingResponse):
    media_type = "text/event-stream; charset=utf-8"

    def __init__(
        self,
        content: Any,
        status_code: int = 200,
        media_type: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        response_headers = {
            "cache-control": "no-cache",
            "x-accel-buffering": "no",
            **(headers or {}),
        }
        super().__init__(
            content,
            status_code=status_code,
            media_type=media_type or self.media_type,
            headers=response_headers,
        )

    def render(self, content: Any) -> bytes:
        events = _collect_sse_events(content)
        return "".join(_sse_event_text(item) for item in events).encode("utf-8")


def _collect_sse_events(content: Any) -> list[Any]:
    if inspect.isasyncgen(content):
        async def collect() -> list[Any]:
            events: list[Any] = []
            last_event = time_module.monotonic()
            first = True
            async for item in content:
                now = time_module.monotonic()
                if not first and now - last_event >= _sse_ping_interval():
                    events.append(ServerSentEvent(comment="ping"))
                events.append(item)
                last_event = time_module.monotonic()
                first = False
            return events

        return asyncio.run(collect())
    if inspect.isawaitable(content):
        return _collect_sse_events(asyncio.run(content))
    if isinstance(content, (str, bytes, dict)) or hasattr(content, "model_dump"):
        return [content]
    try:
        events: list[Any] = []
        last_event = time_module.monotonic()
        first = True
        for item in content:
            now = time_module.monotonic()
            if not first and now - last_event >= _sse_ping_interval():
                events.append(ServerSentEvent(comment="ping"))
            events.append(item)
            last_event = time_module.monotonic()
            first = False
        return events
    except TypeError:
        return [content]


def _sse_event_text(item: Any) -> str:
    if isinstance(item, ServerSentEvent):
        return item.encode()
    return ServerSentEvent(data=item).encode()


def _sse_ping_interval() -> float:
    fastapi_routing = sys.modules.get("fastapi.routing")
    if fastapi_routing is not None and hasattr(fastapi_routing, "_PING_INTERVAL"):
        return float(getattr(fastapi_routing, "_PING_INTERVAL"))
    superduperfastapi_routing = sys.modules.get("superduperfastapi.routing")
    if superduperfastapi_routing is not None and hasattr(superduperfastapi_routing, "_PING_INTERVAL"):
        return float(getattr(superduperfastapi_routing, "_PING_INTERVAL"))
    return 15.0


def _jsonable(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json", by_alias=True)
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonable(asdict(value))
    if isinstance(value, bytes):
        return value.decode("utf-8")
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, PurePath):
        return str(value)
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, timedelta):
        return value.total_seconds()
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return int(value) if value.as_tuple().exponent >= 0 else float(value)
    if isinstance(value, BaseException):
        return {}
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_jsonable(item) for item in value]
    return value
