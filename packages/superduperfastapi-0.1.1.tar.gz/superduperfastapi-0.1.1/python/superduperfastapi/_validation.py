from __future__ import annotations

from typing import Any

from pydantic import TypeAdapter
from pydantic_core import SchemaSerializer, SchemaValidator, ValidationError


class CoreSchemaAdapter:
    def __init__(self, annotation: Any) -> None:
        self.type_adapter = TypeAdapter(annotation)
        core_schema = getattr(self.type_adapter, "core_schema", None)
        self.validator = SchemaValidator(core_schema) if core_schema is not None else None
        self.serializer = SchemaSerializer(core_schema) if core_schema is not None else None

    def validate_python(self, value: Any, *, from_attributes: bool | None = None) -> Any:
        if self.validator is None:
            return self.type_adapter.validate_python(value, from_attributes=from_attributes)
        return self.validator.validate_python(value, from_attributes=from_attributes)

    def validate_json(self, value: bytes | str) -> Any:
        if self.validator is None:
            return self.type_adapter.validate_json(value)
        return self.validator.validate_json(value)

    def dump_python(
        self,
        value: Any,
        *,
        mode: str = "python",
        by_alias: bool | None = None,
        include: Any = None,
        exclude: Any = None,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
    ) -> Any:
        if self.serializer is None:
            return self.type_adapter.dump_python(
                value,
                mode=mode,
                by_alias=by_alias,
                include=include,
                exclude=exclude,
                exclude_unset=exclude_unset,
                exclude_defaults=exclude_defaults,
                exclude_none=exclude_none,
            )
        return self.serializer.to_python(
            value,
            mode=mode,
            by_alias=by_alias,
            include=include,
            exclude=exclude,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
        )

    def dump_json(
        self,
        value: Any,
        *,
        by_alias: bool | None = None,
        include: Any = None,
        exclude: Any = None,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
    ) -> bytes:
        if self.serializer is None:
            return self.type_adapter.dump_json(
                value,
                by_alias=by_alias,
                include=include,
                exclude=exclude,
                exclude_unset=exclude_unset,
                exclude_defaults=exclude_defaults,
                exclude_none=exclude_none,
            )
        return self.serializer.to_json(
            value,
            by_alias=by_alias,
            include=include,
            exclude=exclude,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
        )


_adapter_cache: dict[Any, CoreSchemaAdapter] = {}


def core_schema_adapter(annotation: Any) -> CoreSchemaAdapter:
    try:
        adapter = _adapter_cache.get(annotation)
    except TypeError:
        return CoreSchemaAdapter(annotation)
    if adapter is None:
        adapter = CoreSchemaAdapter(annotation)
        _adapter_cache[annotation] = adapter
    return adapter
