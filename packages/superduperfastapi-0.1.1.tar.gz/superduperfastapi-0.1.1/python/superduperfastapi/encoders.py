from __future__ import annotations

from collections import deque
from dataclasses import asdict, is_dataclass
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from enum import Enum
from pathlib import PurePath
from typing import Any
from uuid import UUID

from pydantic import BaseModel

from ._compat import Undefined
from .exceptions import PydanticV1NotSupportedError


def jsonable_encoder(
    obj: Any,
    include: set[str] | list[str] | dict[str, Any] | None = None,
    exclude: set[str] | list[str] | dict[str, Any] | None = None,
    by_alias: bool = True,
    exclude_unset: bool = False,
    exclude_defaults: bool = False,
    exclude_none: bool = False,
    custom_encoder: dict[type[Any], Any] | None = None,
    sqlalchemy_safe: bool = True,
) -> Any:
    custom_encoder = custom_encoder or {}
    for encoder_type, encoder in custom_encoder.items():
        if isinstance(obj, encoder_type):
            return encoder(obj)

    if _is_pydantic_v1_model(obj):
        raise PydanticV1NotSupportedError("Pydantic v1 models are not supported")

    if obj is Undefined:
        return None
    if isinstance(obj, BaseModel):
        data = obj.model_dump(
            mode="json",
            include=_normalize_filter(include),
            exclude=_normalize_filter(exclude),
            by_alias=by_alias,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
        )
        return jsonable_encoder(data, custom_encoder=custom_encoder, sqlalchemy_safe=sqlalchemy_safe)
    if is_dataclass(obj) and not isinstance(obj, type):
        return jsonable_encoder(
            asdict(obj),
            include=include,
            exclude=exclude,
            custom_encoder=custom_encoder,
            sqlalchemy_safe=sqlalchemy_safe,
        )
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, PurePath):
        return str(obj)
    if isinstance(obj, (datetime, date, time)):
        return obj.isoformat()
    if isinstance(obj, timedelta):
        return obj.total_seconds()
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, Decimal):
        if not obj.is_finite():
            return float(obj)
        return int(obj) if obj.as_tuple().exponent >= 0 else float(obj)
    if isinstance(obj, bytes):
        return obj.decode("utf-8")
    if isinstance(obj, BaseException):
        return {}
    if obj.__class__.__name__ == "Color":
        return str(obj)
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    if isinstance(obj, dict):
        include_filter = _filter_keys(include)
        exclude_filter = _filter_keys(exclude)
        encoded = {}
        for key, value in obj.items():
            if sqlalchemy_safe and isinstance(key, str) and key.startswith("_sa"):
                continue
            if include_filter is not None and key not in include_filter:
                continue
            if exclude_filter is not None and key in exclude_filter:
                continue
            if exclude_none and value is None:
                continue
            encoded[jsonable_encoder(key, custom_encoder=custom_encoder)] = jsonable_encoder(
                value,
                custom_encoder=custom_encoder,
                sqlalchemy_safe=sqlalchemy_safe,
            )
        return encoded
    if isinstance(obj, (list, tuple, set, frozenset, deque)):
        return [
            jsonable_encoder(
                item,
                custom_encoder=custom_encoder,
                sqlalchemy_safe=sqlalchemy_safe,
            )
            for item in obj
        ]

    try:
        data = dict(obj)
    except Exception as dict_error:
        try:
            data = vars(obj)
        except Exception as vars_error:
            raise ValueError([dict_error, vars_error]) from vars_error
    return jsonable_encoder(
        data,
        include=include,
        exclude=exclude,
        custom_encoder=custom_encoder,
        sqlalchemy_safe=sqlalchemy_safe,
    )


def _filter_keys(value: set[str] | list[str] | dict[str, Any] | None) -> set[str] | None:
    if value is None:
        return None
    return set(value)


def _normalize_filter(value: set[str] | list[str] | dict[str, Any] | None) -> Any:
    if value is None or isinstance(value, dict):
        return value
    return set(value)


def _is_pydantic_v1_model(obj: Any) -> bool:
    try:
        from pydantic import v1
    except Exception:
        return False
    return isinstance(obj, v1.BaseModel)
