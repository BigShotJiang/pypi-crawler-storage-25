from __future__ import annotations

from typing import Any


try:
    from . import _superduperfastapi_core
except ImportError as exc:  # pragma: no cover - exercised before extension install
    raise RuntimeError(
        "Rust core extension not installed. Run: "
        ".venv/bin/python -m pip install maturin && .venv/bin/maturin develop"
    ) from exc


class RustCore:
    def version(self) -> str:
        return _superduperfastapi_core.core_version()

    def match_route(self, pattern: str, path: str) -> dict[str, str] | None:
        result: Any = _superduperfastapi_core.match_route(pattern, path)
        if result is None:
            return None
        return dict(result)

    def parse_query_string(self, query: str) -> dict[str, list[str]]:
        result: Any = _superduperfastapi_core.parse_query_string(query)
        return {str(key): list(values) for key, values in dict(result).items()}

    def normalize_headers(self, headers: list[tuple[str, str]]) -> list[tuple[str, list[str]]]:
        result: Any = _superduperfastapi_core.normalize_headers(headers)
        return [(str(key), [str(value) for value in values]) for key, values in result]

    def parse_cookie_header(self, header: str) -> dict[str, str]:
        result: Any = _superduperfastapi_core.parse_cookie_header(header)
        return {str(key): str(value) for key, value in dict(result).items()}

    def serve_once(self, app: Any, host: str = "127.0.0.1", port: int = 0) -> int:
        return int(_superduperfastapi_core.serve_once(app, host, port))

    def serve(
        self,
        app: Any,
        host: str = "127.0.0.1",
        port: int = 0,
        max_requests: int = 0,
    ) -> int:
        return int(_superduperfastapi_core.serve(app, host, port, max_requests))

    def dispatch_raw(
        self,
        app: Any,
        method: str,
        target: str,
        headers: list[tuple[str, str]] | None = None,
        body: bytes | None = None,
    ) -> tuple[int, list[tuple[str, str]], bytes, bool]:
        status, response_headers, response_body, used_fast_path = _superduperfastapi_core.dispatch_raw(
            app,
            method,
            target,
            headers or [],
            body,
        )
        return (
            int(status),
            [(str(key), str(value)) for key, value in response_headers],
            bytes(response_body),
            bool(used_fast_path),
        )


core = RustCore()
