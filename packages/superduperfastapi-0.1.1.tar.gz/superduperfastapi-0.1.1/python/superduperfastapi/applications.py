from __future__ import annotations

import asyncio
import contextvars
import copy
import inspect
import json
import os
import re
import threading
import types
import warnings
from collections.abc import AsyncIterable as ABCAsyncIterable
from collections.abc import Iterable as ABCIterable
from dataclasses import is_dataclass
from datetime import date, datetime, time, timedelta
from enum import Enum
from http import HTTPStatus
from typing import Annotated, Any, Callable, Union, get_args, get_origin
from uuid import UUID

from ._core import core
from .exceptions import FastAPIError, HTTPException, RequestValidationError
from .middleware import CORSMiddleware, GZipMiddleware, HTTPSRedirectMiddleware, Middleware, TrustedHostMiddleware
from .params import BodyParam, CookieParam, DependsParam, FileParam, FormParam, HeaderParam, Param, PathParam, QueryParam, _MISSING
from .responses import Headers, JSONResponse, PlainTextResponse, RedirectResponse, Response, StreamingResponse
from .routing import APIRouter, HTTPConnection, Request, Route, normalize_status_code
from .routing import RESPONSE_MODEL_UNSET, _resolve_response_model
from .routing import WebSocket, WebSocketDisconnect, WebSocketRoute, _finalize_dependencies, _prepare_response_body, _router_lifespans, _url_path_for, _validate_dependency_scopes, _validate_path_operation_params, _validate_response_models
from ._validation import core_schema_adapter


_MODEL_SCHEMA_MODES_DIFFER_CACHE: dict[Any, bool] = {}
_MODEL_READONLY_SERIALIZATION_FIELD_CACHE: dict[Any, bool] = {}
_MODEL_JSON_SCHEMA_COMPONENT_CACHE: dict[tuple[Any, str, str], list[tuple[str, dict[str, Any]]]] = {}


class FastAPI:
    def __init__(
        self,
        *,
        title: str = "FastAPI",
        version: str = "0.1.0",
        summary: str | None = None,
        description: str | None = None,
        terms_of_service: str | None = None,
        contact: dict[str, Any] | None = None,
        license_info: dict[str, Any] | None = None,
        openapi_tags: list[dict[str, Any]] | None = None,
        openapi_external_docs: dict[str, Any] | None = None,
        servers: list[dict[str, Any]] | None = None,
        openapi_url: str | None = "/openapi.json",
        docs_url: str | None = "/docs",
        redoc_url: str | None = "/redoc",
        root_path: str = "",
        openapi_prefix: str = "",
        root_path_in_servers: bool = True,
        default_response_class: type[Response] = JSONResponse,
        swagger_ui_oauth2_redirect_url: str | None = "/docs/oauth2-redirect",
        swagger_ui_init_oauth: dict[str, Any] | None = None,
        swagger_ui_parameters: dict[str, Any] | None = None,
        redirect_slashes: bool = True,
        dependencies: list[DependsParam] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        callbacks: list[Route] | None = None,
        exception_handlers: dict[type[Exception], Callable[..., Response]] | None = None,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        strict_content_type: bool = True,
        middleware: list[Any] | None = None,
        lifespan: Callable[..., Any] | None = None,
        on_startup: list[Callable[..., Any]] | None = None,
        on_shutdown: list[Callable[..., Any]] | None = None,
        **_: Any,
    ) -> None:
        self.title = title
        self.version = version
        self.summary = summary
        self.description = description
        self.terms_of_service = terms_of_service
        self.contact = contact
        self.license_info = license_info
        self.openapi_tags = list(openapi_tags or [])
        self.openapi_external_docs = openapi_external_docs
        self.servers = list(servers) if servers is not None else None
        self.openapi_url = openapi_url or None
        self.docs_url = docs_url if self.openapi_url else None
        self.redoc_url = redoc_url if self.openapi_url else None
        self.root_path = root_path or openapi_prefix
        self.root_path_in_servers = root_path_in_servers
        self.default_response_class = default_response_class
        self.swagger_ui_oauth2_redirect_url = swagger_ui_oauth2_redirect_url
        self.swagger_ui_init_oauth = swagger_ui_init_oauth
        self.swagger_ui_parameters = swagger_ui_parameters
        self.redirect_slashes = redirect_slashes
        self.dependencies = dependencies or []
        self.responses = responses or {}
        self.callbacks = callbacks or []
        self.generate_unique_id_function = generate_unique_id_function
        self.strict_content_type = strict_content_type
        self.separate_input_output_schemas = bool(_.get("separate_input_output_schemas", True))
        self.exception_handlers = exception_handlers or {}
        self.dependency_overrides: dict[Any, Callable[..., Any]] = {}
        self.state = State()
        self.app_state: dict[str, Any] = {}
        self.lifespan = lifespan
        self.on_startup = list(on_startup or [])
        self.on_shutdown = list(on_shutdown or [])
        self.lifespan_contexts: list[Callable[..., Any]] = []
        self._lifespan_exits: list[Callable[[], Any]] = []
        self.routes: list[Route] = []
        self.mounts: list[tuple[str, Any, str | None]] = []
        self.router = self
        self.route_class: type[Route] = Route
        self.websocket_routes: list[WebSocketRoute] = []
        self.webhooks = APIRouter()
        self.user_middleware: list[Callable[..., Any]] = []
        self.asgi_middleware: list[Middleware] = list(middleware or [])
        self.websocket_middleware = self.asgi_middleware
        self.openapi_schema: dict[str, Any] | None = None

    def api_route(
        self,
        path: str,
        *,
        methods: list[str] | None = None,
        status_code: int = 200,
        dependencies: list[DependsParam] | None = None,
        response_class: type[Response] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        response_model: Any = RESPONSE_MODEL_UNSET,
        response_model_by_alias: bool = True,
        response_model_include: Any = None,
        response_model_exclude: Any = None,
        response_model_exclude_unset: bool = False,
        response_model_exclude_defaults: bool = False,
        response_model_exclude_none: bool = False,
        tags: list[str] | None = None,
        callbacks: list[Route] | None = None,
        deprecated: bool | None = None,
        summary: str | None = None,
        description: str | None = None,
        response_description: str | None = None,
        openapi_extra: dict[str, Any] | None = None,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        strict_content_type: bool | None = None,
        **_: Any,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        operation_id = _.get("operation_id")
        include_in_schema = bool(_.get("include_in_schema", True))

        def decorator(endpoint: Callable[..., Any]) -> Callable[..., Any]:
            self.add_api_route(
                path,
                endpoint,
                methods=methods,
                status_code=status_code,
                dependencies=dependencies,
                response_class=response_class,
                responses=responses,
                response_model=response_model,
                response_model_by_alias=response_model_by_alias,
                response_model_include=response_model_include,
                response_model_exclude=response_model_exclude,
                response_model_exclude_unset=response_model_exclude_unset,
                response_model_exclude_defaults=response_model_exclude_defaults,
                response_model_exclude_none=response_model_exclude_none,
                tags=tags,
                callbacks=callbacks,
                deprecated=deprecated,
                summary=summary,
                description=description,
                response_description=response_description,
                openapi_extra=openapi_extra,
                operation_id=operation_id,
                include_in_schema=include_in_schema,
                generate_unique_id_function=generate_unique_id_function,
                strict_content_type=strict_content_type,
            )
            return endpoint

        return decorator

    def route(
        self,
        path: str,
        *,
        methods: list[str] | None = None,
        **kwargs: Any,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=methods or ["GET"], **kwargs)

    def add_api_route(
        self,
        path: str,
        endpoint: Callable[..., Any],
        *,
        methods: list[str] | None = None,
        status_code: int = 200,
        dependencies: list[DependsParam] | None = None,
        response_class: type[Response] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        response_model: Any = RESPONSE_MODEL_UNSET,
        response_model_by_alias: bool = True,
        response_model_include: Any = None,
        response_model_exclude: Any = None,
        response_model_exclude_unset: bool = False,
        response_model_exclude_defaults: bool = False,
        response_model_exclude_none: bool = False,
        tags: list[str] | None = None,
        callbacks: list[Route] | None = None,
        deprecated: bool | None = None,
        summary: str | None = None,
        description: str | None = None,
        response_description: str | None = None,
        openapi_extra: dict[str, Any] | None = None,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        strict_content_type: bool | None = None,
        **_: Any,
    ) -> None:
        operation_id = _.get("operation_id")
        include_in_schema = bool(_.get("include_in_schema", True))
        route_methods = {method.upper() for method in (methods or ["GET"])}
        route_dependencies = [*self.dependencies, *(dependencies or [])]
        _validate_path_operation_params(endpoint, path)
        _validate_dependency_scopes(endpoint, route_dependencies)
        route_response_class = response_class or self.default_response_class
        route_status_code = (
            307
            if route_response_class is RedirectResponse and status_code == 200
            else status_code
        )
        resolved_response_model = _resolve_response_model(
            endpoint,
            response_model,
            route_response_class,
        )
        _validate_response_models(resolved_response_model, responses or {})
        self.routes.append(
            self.route_class(
                path=path,
                endpoint=endpoint,
                methods=route_methods,
                status_code=normalize_status_code(route_status_code),
                dependencies=route_dependencies,
                response_class=route_response_class,
                responses={**self.responses, **(responses or {})},
                response_model=resolved_response_model,
                response_model_by_alias=response_model_by_alias,
                response_model_include=response_model_include,
                response_model_exclude=response_model_exclude,
                response_model_exclude_unset=response_model_exclude_unset,
                response_model_exclude_defaults=response_model_exclude_defaults,
                response_model_exclude_none=response_model_exclude_none,
                tags=tags or [],
                callbacks=[*self.callbacks, *(callbacks or [])],
                deprecated=deprecated,
                summary=summary,
                description=description,
                response_description=response_description,
                openapi_extra=openapi_extra,
                operation_id=operation_id,
                include_in_schema=include_in_schema,
                generate_unique_id_function=(
                    generate_unique_id_function or self.generate_unique_id_function
                ),
                generate_unique_id_explicit=generate_unique_id_function is not None,
                strict_content_type=(
                    strict_content_type
                    if strict_content_type is not None
                    else self.strict_content_type
                ),
                separate_input_output_schemas=self.separate_input_output_schemas,
                response_class_explicit=response_class is not None,
            )
        )

    def get(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["GET"], **kwargs)

    def post(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["POST"], **kwargs)

    def put(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["PUT"], **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["DELETE"], **kwargs)

    def head(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["HEAD"], **kwargs)

    def options(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["OPTIONS"], **kwargs)

    def patch(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["PATCH"], **kwargs)

    def trace(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["TRACE"], **kwargs)

    def url_path_for(self, name: str, **path_params: Any) -> str:
        return _url_path_for(self.routes, name, **path_params)

    def websocket(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        route_dependencies = [*self.dependencies, *list(kwargs.get("dependencies") or [])]

        def decorator(endpoint: Callable[..., Any]) -> Callable[..., Any]:
            _validate_dependency_scopes(endpoint, route_dependencies)
            self.websocket_routes.append(
                WebSocketRoute(path=path, endpoint=endpoint, dependencies=route_dependencies)
            )
            return endpoint

        return decorator

    def websocket_route(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.websocket(path, **kwargs)

    def exception_handler(
        self,
        exc_class: type[Exception],
    ) -> Callable[[Callable[..., Response]], Callable[..., Response]]:
        def decorator(func: Callable[..., Response]) -> Callable[..., Response]:
            self.exception_handlers[exc_class] = func
            return func

        return decorator

    def on_event(self, event_type: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        warnings.warn(
            "on_event is deprecated, use lifespan event handlers instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        if event_type not in {"startup", "shutdown"}:
            raise ValueError("event_type must be 'startup' or 'shutdown'")

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            if event_type == "startup":
                self.on_startup.append(func)
            else:
                self.on_shutdown.append(func)
            return func

        return decorator

    def middleware(self, middleware_type: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        if middleware_type != "http":
            raise FastAPIError("Only HTTP middleware is supported")

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            self.user_middleware.append(func)
            return func

        return decorator

    def add_middleware(self, middleware_class: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
        self.asgi_middleware.append(Middleware(middleware_class, *args, **kwargs))

    def mount(self, path: str, app: Any, name: str | None = None) -> None:
        self.mounts.append((path.rstrip("/") or "/", app, name))

    def include_router(
        self,
        router: APIRouter,
        *,
        prefix: str = "",
        default_response_class: type[Response] | None = None,
        dependencies: list[DependsParam] | None = None,
        tags: list[str] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        callbacks: list[Route] | None = None,
        deprecated: bool | None = None,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        **_: Any,
    ) -> None:
        effective_default = default_response_class or self.default_response_class
        self.on_startup.extend(router.on_startup)
        self.on_shutdown.extend(router.on_shutdown)
        self.lifespan_contexts.extend(_router_lifespans(router))
        for route in router.websocket_routes:
            for path in _included_route_paths(prefix, route.path):
                self.websocket_routes.append(
                    WebSocketRoute(
                        path=path,
                        endpoint=route.endpoint,
                        dependencies=[*self.dependencies, *list(dependencies or []), *route.dependencies],
                    )
                )
        for route in router.routes:
            if not prefix and route.path in {"", "/"}:
                raise FastAPIError("Prefix and path cannot be both empty")
            for path in _included_route_paths(prefix, route.path):
                self.routes.append(
                    route.__class__(
                        path=path,
                        endpoint=route.endpoint,
                        methods=set(route.methods),
                        status_code=route.status_code,
                        dependencies=[
                            *self.dependencies,
                            *(dependencies or []),
                            *route.dependencies,
                        ],
                        response_class=_included_response_class(
                            route.response_class,
                            router.default_response_class,
                            effective_default,
                        ),
                        responses={**self.responses, **(responses or {}), **route.responses},
                        response_model=route.response_model,
                        response_model_by_alias=route.response_model_by_alias,
                        response_model_include=route.response_model_include,
                        response_model_exclude=route.response_model_exclude,
                        response_model_exclude_unset=route.response_model_exclude_unset,
                        response_model_exclude_defaults=route.response_model_exclude_defaults,
                        response_model_exclude_none=route.response_model_exclude_none,
                        tags=[*(tags or []), *route.tags],
                        callbacks=[*self.callbacks, *(callbacks or []), *route.callbacks],
                        deprecated=route.deprecated if route.deprecated is not None else deprecated,
                        summary=route.summary,
                        description=route.description,
                        response_description=route.response_description,
                        openapi_extra=route.openapi_extra,
                        operation_id=route.operation_id,
                        include_in_schema=route.include_in_schema,
                        generate_unique_id_function=(
                            route.generate_unique_id_function
                            or generate_unique_id_function
                            or self.generate_unique_id_function
                        ),
                        generate_unique_id_explicit=(
                            route.generate_unique_id_explicit
                            or generate_unique_id_function is not None
                        ),
                        strict_content_type=(
                            route.strict_content_type
                            if route.strict_content_type is not None
                            else router.strict_content_type
                            if router.strict_content_type is not None
                            else self.strict_content_type
                        ),
                        separate_input_output_schemas=self.separate_input_output_schemas,
                        response_class_explicit=route.response_class_explicit,
                    )
                )

    def handle_request(
        self,
        method: str,
        target: str,
        json_body: Any = None,
        *,
        raw_body: bytes | None = None,
        form_body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        raise_server_exceptions: bool = True,
        root_path: str | None = None,
        scheme: str = "http",
        client: tuple[str, int] | None = None,
        _skip_asgi_middleware: bool = False,
    ) -> Response:
        path, _, query_string = target.partition("?")
        effective_root_path = self.root_path if root_path is None else root_path
        request_headers = Headers(headers)
        if (
            raw_body is not None
            and json_body is None
            and "gzip" not in request_headers.get("content-encoding", "").lower()
        ):
            if _is_json_content_type(request_headers.get("content-type", "")):
                try:
                    json_body = json.loads(raw_body.decode("utf-8")) if raw_body else None
                except json.JSONDecodeError as exc:
                    return _json_decode_response(exc)
                except Exception:
                    return JSONResponse({"detail": "There was an error parsing the body"}, status_code=400)
            elif raw_body:
                raw_text = raw_body.decode("utf-8")
                if form_body is None and _is_urlencoded_form_content_type(
                    request_headers.get("content-type", "")
                ):
                    form_body = _urlencoded_form_body(raw_text)
                json_body = raw_text
        request_cookies = core.parse_cookie_header(request_headers.get("cookie", ""))
        request_cookies.update(cookies or {})
        request = Request(
            method=method.upper(),
            path=path,
            query_string=query_string,
            raw_body=raw_body,
            json_body=json_body,
            form_body=form_body,
            headers=request_headers,
            cookies=request_cookies,
            app=self,
            scope={
                "root_path": effective_root_path,
                "scheme": scheme,
                "state": self.app_state,
                "method": method.upper(),
                "path": path,
                "query_string": query_string.encode("latin-1"),
                "raw_body": raw_body,
                "json_body": json_body,
                "form_body": form_body,
                "headers_obj": request_headers,
                "cookies": request_cookies,
                "app": self,
                "raise_server_exceptions": raise_server_exceptions,
                "client": client or ("", 0),
            },
            raise_server_exceptions=raise_server_exceptions,
        )
        if not _skip_asgi_middleware and self._custom_asgi_middleware:
            return self._dispatch_asgi_middleware(
                request,
                method=method.upper(),
                path=path,
                query_string=query_string,
                raw_body=raw_body,
                raise_server_exceptions=raise_server_exceptions,
                root_path=effective_root_path,
                scheme=scheme,
                client=client,
            )
        middleware_response = self._preflight_middleware_response(request, path, query_string)
        if middleware_response is not None:
            return middleware_response
        mounted_response = self._handle_mount(path, query_string, request_headers, request)
        if mounted_response is not None:
            return self._apply_response_middleware(request, mounted_response)
        builtin_response: Response | None = None
        if self.openapi_url is not None and path == self.openapi_url:
            builtin_response = JSONResponse(_call_openapi(self, effective_root_path))
        elif self.docs_url is not None and path == self.docs_url:
            from .openapi.docs import get_swagger_ui_html

            builtin_response = get_swagger_ui_html(
                openapi_url=self.openapi_url,
                title=f"{self.title} - Swagger UI",
                oauth2_redirect_url=self.swagger_ui_oauth2_redirect_url,
                init_oauth=self.swagger_ui_init_oauth,
                swagger_ui_parameters=self.swagger_ui_parameters,
            )
        elif path == self.swagger_ui_oauth2_redirect_url and self.swagger_ui_oauth2_redirect_url is not None:
            from .openapi.docs import get_swagger_ui_oauth2_redirect_html

            builtin_response = get_swagger_ui_oauth2_redirect_html()
        elif self.redoc_url is not None and path == self.redoc_url:
            from .openapi.docs import get_redoc_html

            builtin_response = get_redoc_html(
                openapi_url=self.openapi_url or "",
                title=f"{self.title} - ReDoc",
            )
        if builtin_response is not None:
            if self.user_middleware:
                return self._apply_response_middleware(
                    request,
                    self._dispatch_middleware(request, lambda _: builtin_response),
                )
            return self._apply_response_middleware(request, builtin_response)

        for route in self.routes:
            path_params = route.match(request.method, path)
            if path_params is not None:
                request.scope["path_params"] = path_params
                try:
                    if self.user_middleware:
                        request.defer_response_cleanup = True
                        response = self._dispatch_middleware(
                            request,
                            lambda current_request: _handle_route(route, current_request, path_params),
                        )
                        function_error = _finalize_dependencies(request, None, scope="function")
                        if function_error is not None:
                            raise function_error
                        streaming_error = _prepare_response_body(response)
                        if streaming_error is not None and raise_server_exceptions:
                            finalizer_error = _finalize_dependencies(request, streaming_error)
                            raise finalizer_error or streaming_error
                        if request.background_tasks is not None:
                            request.background_tasks()
                        finalizer_error = _finalize_dependencies(
                            request,
                            streaming_error,
                            scope="request",
                        )
                        if finalizer_error is not None and raise_server_exceptions:
                            raise finalizer_error
                        return self._apply_response_middleware(request, response)
                    return self._apply_response_middleware(
                        request,
                        _handle_route(route, request, path_params),
                    )
                except HTTPException as exc:
                    return self._apply_response_middleware(
                        request,
                        self._handle_exception(request, exc, raise_server_exceptions=False),
                    )
                except RequestValidationError as exc:
                    return self._apply_response_middleware(
                        request,
                        self._handle_exception(request, exc, raise_server_exceptions=False),
                    )
                except Exception as exc:
                    handler_class = _lookup_exception_handler_class(self.exception_handlers, exc)
                    if handler_class is not None and (
                        not raise_server_exceptions or handler_class is not Exception
                    ):
                        return self._apply_response_middleware(
                            request,
                            self._handle_exception(
                                request,
                                exc,
                                raise_server_exceptions=False,
                            ),
                        )
                    if raise_server_exceptions:
                        raise
                    return self._apply_response_middleware(
                        request,
                        self._handle_exception(
                            request,
                            exc,
                            raise_server_exceptions=False,
                        ),
                    )
        if any(route.path_matches(path) for route in self.routes):
            return self._apply_response_middleware(
                request,
                JSONResponse({"detail": "Method Not Allowed"}, status_code=405),
            )
        redirect_path = _toggle_trailing_slash(path)
        if self.redirect_slashes and any(route.path_matches(redirect_path) for route in self.routes):
            location = _redirect_location(request, redirect_path, query_string)
            return Response(b"", status_code=307, media_type=None, headers={"location": location})
        return self._apply_response_middleware(
            request,
            JSONResponse({"detail": "Not Found"}, status_code=404),
        )

    def __superduperfastapi_rust_route_specs__(self) -> list[dict[str, Any]]:
        if self._rust_static_mount_specs() is None:
            return []
        specs: list[dict[str, Any]] = []
        for route_index, route in enumerate(self.routes):
            spec = route.rust_fast_path_spec(self.dependency_overrides)
            if spec is not None:
                spec["app"] = self
                spec["app_state"] = self.app_state
                spec["route_index"] = route_index
                spec["has_user_middleware"] = bool(self.user_middleware)
                spec["has_custom_asgi_middleware"] = bool(self._custom_asgi_middleware)
                specs.append(spec)
        return specs

    def __superduperfastapi_rust_middleware_specs__(self) -> list[dict[str, Any]]:
        return self._rust_middleware_specs() or []

    def __superduperfastapi_rust_mount_specs__(self) -> list[dict[str, Any]]:
        return self._rust_static_mount_specs() or []

    def _dispatch_rust_user_middleware_route(
        self,
        route_index: int,
        request: Request,
    ) -> Response:
        route = self.routes[route_index]
        path_params = dict(request.scope.get("path_params") or {})
        request.defer_response_cleanup = True
        try:
            response = self._dispatch_middleware(
                request,
                lambda current_request: _handle_route(route, current_request, path_params),
            )
            function_error = _finalize_dependencies(request, None, scope="function")
            if function_error is not None:
                raise function_error
            streaming_error = _prepare_response_body(response)
            if streaming_error is not None and request.raise_server_exceptions:
                finalizer_error = _finalize_dependencies(request, streaming_error)
                raise finalizer_error or streaming_error
            if request.background_tasks is not None:
                request.background_tasks()
            finalizer_error = _finalize_dependencies(
                request,
                streaming_error,
                scope="request",
            )
            if finalizer_error is not None and request.raise_server_exceptions:
                raise finalizer_error
            return response
        except HTTPException as exc:
            return self._handle_exception(request, exc, raise_server_exceptions=False)
        except RequestValidationError as exc:
            return self._handle_exception(request, exc, raise_server_exceptions=False)
        except Exception as exc:
            handler_class = _lookup_exception_handler_class(self.exception_handlers, exc)
            if handler_class is not None and (
                not request.raise_server_exceptions or handler_class is not Exception
            ):
                return self._handle_exception(request, exc, raise_server_exceptions=False)
            if request.raise_server_exceptions:
                raise
            return self._handle_exception(request, exc, raise_server_exceptions=False)

    def _dispatch_rust_custom_asgi_middleware_route(
        self,
        route_index: int,
        request: Request,
    ) -> Response:
        method = request.method
        path = request.path
        query_string = request.query_string
        raw_body = _request_body_bytes(request)
        root_path = str((request.scope or {}).get("root_path", ""))
        scheme = str((request.scope or {}).get("scheme", "http"))
        client = (request.scope or {}).get("client")
        scope = _http_asgi_scope(
            request,
            method=method,
            path=path,
            query_string=query_string,
            root_path=root_path,
            scheme=scheme,
            client=client,
        )
        messages: list[dict[str, Any]] = []
        body_sent = False

        async def receive() -> dict[str, Any]:
            nonlocal body_sent
            if body_sent:
                return {"type": "http.disconnect"}
            body_sent = True
            return {"type": "http.request", "body": raw_body, "more_body": False}

        async def send(message: dict[str, Any]) -> None:
            messages.append(message)

        async def terminal_app(
            terminal_scope: dict[str, Any],
            terminal_receive: Any,
            terminal_send: Any,
        ) -> None:
            terminal_query = terminal_scope.get("query_string", b"")
            if isinstance(terminal_query, bytes):
                terminal_query_string = terminal_query.decode("latin-1")
            else:
                terminal_query_string = str(terminal_query)
            terminal_path = terminal_scope.get("path", path)
            terminal_method = terminal_scope.get("method", method)
            terminal_body = await _read_asgi_body(terminal_receive)
            if (
                terminal_method == method
                and terminal_path == path
                and terminal_query_string == query_string
                and terminal_body == raw_body
            ):
                response = self._dispatch_rust_user_middleware_route(route_index, request)
            else:
                target = terminal_path + (
                    f"?{terminal_query_string}" if terminal_query_string else ""
                )
                terminal_headers = [
                    (key.decode("latin-1"), value.decode("latin-1"))
                    for key, value in terminal_scope.get("headers", [])
                ]
                response = self.handle_request(
                    terminal_method,
                    target,
                    raw_body=terminal_body,
                    headers=terminal_headers,
                    cookies=request.cookies,
                    raise_server_exceptions=request.raise_server_exceptions,
                    root_path=terminal_scope.get("root_path", root_path),
                    scheme=terminal_scope.get("scheme", scheme),
                    client=terminal_scope.get("client", client),
                    _skip_asgi_middleware=True,
                )
            await _send_response_asgi(response, terminal_send)

        app = terminal_app
        for middleware in reversed(self._custom_asgi_middleware):
            app = middleware.cls(app, *middleware.args, **middleware.kwargs)
        try:
            _run_asgi_awaitable(app(scope, receive, send))
        except (HTTPException, RequestValidationError) as exc:
            return self._handle_exception(request, exc, raise_server_exceptions=False)
        except Exception:
            if request.raise_server_exceptions:
                raise
            return Response(
                "Internal Server Error",
                status_code=500,
                media_type="text/plain; charset=utf-8",
            )
        return _response_from_asgi_messages(messages)

    def _rust_static_mount_specs(self) -> list[dict[str, Any]] | None:
        specs: list[dict[str, Any]] = []
        for prefix, mounted_app, _ in self.mounts:
            directory = getattr(mounted_app, "directory", None)
            if directory is None:
                return None
            specs.append({"kind": "static", "prefix": prefix, "directory": directory})
        return specs

    def _rust_middleware_specs(self) -> list[dict[str, Any]] | None:
        specs: list[dict[str, Any]] = []
        for middleware in self.asgi_middleware:
            try:
                instance = middleware.cls(None, *middleware.args, **middleware.kwargs)
            except Exception:
                continue
            if isinstance(instance, CORSMiddleware):
                specs.append(
                    {
                        "kind": "cors",
                        "allow_origins": instance.allow_origins,
                        "allow_methods": instance.allow_methods,
                        "allow_headers": instance.allow_headers,
                        "allow_credentials": instance.allow_credentials,
                    }
                )
            elif isinstance(instance, HTTPSRedirectMiddleware):
                specs.append({"kind": "https_redirect"})
            elif isinstance(instance, TrustedHostMiddleware):
                specs.append(
                    {
                        "kind": "trusted_host",
                        "allowed_hosts": instance.allowed_hosts,
                        "www_redirect": instance.www_redirect,
                    }
                )
            elif isinstance(instance, GZipMiddleware):
                specs.append(
                    {
                        "kind": "gzip",
                        "minimum_size": instance.minimum_size,
                        "compresslevel": instance.compresslevel,
                    }
                )
            else:
                continue
        return specs

    @property
    def _custom_asgi_middleware(self) -> list[Middleware]:
        custom: list[Middleware] = []
        for middleware in self.asgi_middleware:
            try:
                instance = middleware.cls(None, *middleware.args, **middleware.kwargs)
            except Exception:
                custom.append(middleware)
                continue
            if isinstance(
                instance,
                (
                    CORSMiddleware,
                    GZipMiddleware,
                    HTTPSRedirectMiddleware,
                    TrustedHostMiddleware,
                ),
            ):
                continue
            custom.append(middleware)
        return custom

    def _handle_mount(
        self,
        path: str,
        query_string: str,
        headers: Headers,
        request: Request,
    ) -> Response | None:
        for prefix, mounted_app, _ in self.mounts:
            if path != prefix and not path.startswith(prefix + "/"):
                continue
            child_path = path[len(prefix):] or "/"
            handler = getattr(mounted_app, "handle_request", None)
            if handler is not None:
                child_target = child_path + (f"?{query_string}" if query_string else "")
                if not isinstance(mounted_app, FastAPI):
                    return handler(child_path, query_string=query_string, headers=headers)
                return handler(
                    request.method,
                    child_target,
                    json_body=request.json_body,
                    raw_body=request.raw_body,
                    form_body=request.form_body,
                    headers=headers,
                    cookies=request.cookies,
                    raise_server_exceptions=request.raise_server_exceptions,
                    root_path=prefix,
                    client=(request.scope or {}).get("client"),
                )
            directory = getattr(mounted_app, "directory", None)
            if directory is not None:
                return _static_file_response(directory, child_path)
        return None

    def _preflight_middleware_response(
        self,
        request: Request,
        path: str,
        query_string: str,
    ) -> Response | None:
        for middleware in self.asgi_middleware:
            instance = middleware.cls(None, *middleware.args, **middleware.kwargs)
            max_content_size = getattr(instance, "max_content_size", None)
            if max_content_size is not None and request.form_body is not None:
                if _form_body_size(request.form_body) > max_content_size:
                    return JSONResponse(
                        {
                            "detail": {
                                "name": "ContentSizeLimitExceeded",
                                "code": 999,
                                "message": "File limit exceeded",
                            }
                        },
                        status_code=422,
                    )
            if isinstance(instance, CORSMiddleware) and request.method == "OPTIONS":
                headers = request.headers or Headers()
                origin = headers.get("origin")
                requested_method = headers.get("access-control-request-method")
                if origin and requested_method and instance.is_allowed_origin(origin):
                    response_headers = {
                        "access-control-allow-origin": origin,
                        "access-control-allow-methods": requested_method
                        if "*" in instance.allow_methods
                        else ", ".join(instance.allow_methods),
                    }
                    requested_headers = headers.get("access-control-request-headers")
                    if requested_headers:
                        response_headers["access-control-allow-headers"] = (
                            requested_headers
                            if "*" in instance.allow_headers
                            else ", ".join(instance.allow_headers)
                        )
                    if instance.allow_credentials:
                        response_headers["access-control-allow-credentials"] = "true"
                    return PlainTextResponse("OK", headers=response_headers)
            if isinstance(instance, HTTPSRedirectMiddleware):
                if request.scope.get("scheme") in {"http", "ws"}:
                    host = (request.headers or Headers()).get("host", "testserver")
                    target = path + (f"?{query_string}" if query_string else "")
                    return RedirectResponse(f"https://{host}{target}")
            elif isinstance(instance, TrustedHostMiddleware):
                host = (request.headers or Headers()).get("host", "")
                if not instance.is_allowed(host):
                    return PlainTextResponse("Invalid host header", status_code=400)
        return None

    def _apply_response_middleware(self, request: Request, response: Response) -> Response:
        for middleware in self.asgi_middleware:
            instance = middleware.cls(None, *middleware.args, **middleware.kwargs)
            if not isinstance(instance, GZipMiddleware):
                if isinstance(instance, CORSMiddleware):
                    origin = (request.headers or Headers()).get("origin")
                    if origin and instance.is_allowed_origin(origin):
                        response.headers["access-control-allow-origin"] = origin
                        if instance.allow_credentials:
                            response.headers["access-control-allow-credentials"] = "true"
                continue
            accept_encoding = (request.headers or Headers()).get("accept-encoding", "")
            if "gzip" not in accept_encoding.lower():
                continue
            body = response.body
            if len(body) < instance.minimum_size:
                continue
            response.headers["content-encoding"] = "gzip"
            response.headers["content-length"] = str(instance.compressed_size(body))
        return response

    def _dispatch_middleware(
        self,
        request: Request,
        endpoint: Callable[[Request], Response],
    ) -> Response:
        def dispatch(index: int, current_request: Request) -> Response:
            if index >= len(self.user_middleware):
                return endpoint(current_request)

            middleware = self.user_middleware[index]

            def call_next(next_request: Request) -> ImmediateAwaitable:
                return ImmediateAwaitable(lambda: dispatch(index + 1, next_request))

            return _run_sync_awaitable(middleware(current_request, call_next))

        return dispatch(0, request)

    def _dispatch_asgi_middleware(
        self,
        request: Request,
        *,
        method: str,
        path: str,
        query_string: str,
        raw_body: bytes | None,
        raise_server_exceptions: bool,
        root_path: str,
        scheme: str,
        client: tuple[str, int] | None,
    ) -> Response:
        body = raw_body if raw_body is not None else _request_body_bytes(request)
        scope = _http_asgi_scope(
            request,
            method=method,
            path=path,
            query_string=query_string,
            root_path=root_path,
            scheme=scheme,
            client=client,
        )
        messages: list[dict[str, Any]] = []
        body_sent = False

        async def receive() -> dict[str, Any]:
            nonlocal body_sent
            if body_sent:
                return {"type": "http.disconnect"}
            body_sent = True
            return {"type": "http.request", "body": body, "more_body": False}

        async def send(message: dict[str, Any]) -> None:
            messages.append(message)

        async def terminal_app(
            terminal_scope: dict[str, Any],
            terminal_receive: Any,
            terminal_send: Any,
        ) -> None:
            terminal_query = terminal_scope.get("query_string", b"")
            if isinstance(terminal_query, bytes):
                terminal_query_string = terminal_query.decode("latin-1")
            else:
                terminal_query_string = str(terminal_query)
            terminal_path = terminal_scope.get("path", path)
            target = terminal_path + (f"?{terminal_query_string}" if terminal_query_string else "")
            terminal_headers = [
                (key.decode("latin-1"), value.decode("latin-1"))
                for key, value in terminal_scope.get("headers", [])
            ]
            terminal_body = await _read_asgi_body(terminal_receive)
            terminal_form_body = (
                request.form_body
                if request.form_body is not None and terminal_body == body
                else None
            )
            response = self.handle_request(
                terminal_scope.get("method", method),
                target,
                raw_body=terminal_body,
                form_body=terminal_form_body,
                headers=terminal_headers,
                cookies=request.cookies,
                raise_server_exceptions=raise_server_exceptions,
                root_path=terminal_scope.get("root_path", root_path),
                scheme=terminal_scope.get("scheme", scheme),
                client=terminal_scope.get("client", client),
                _skip_asgi_middleware=True,
            )
            await _send_response_asgi(response, terminal_send)

        app = terminal_app
        for middleware in reversed(self._custom_asgi_middleware):
            app = middleware.cls(app, *middleware.args, **middleware.kwargs)
        try:
            _run_asgi_awaitable(app(scope, receive, send))
        except (HTTPException, RequestValidationError) as exc:
            return self._apply_response_middleware(
                request,
                self._handle_exception(request, exc, raise_server_exceptions=False),
            )
        except Exception:
            if raise_server_exceptions:
                raise
            return Response(
                "Internal Server Error",
                status_code=500,
                media_type="text/plain; charset=utf-8",
            )
        return _response_from_asgi_messages(messages)

    def _handle_exception(
        self,
        request: Request,
        exc: Exception,
        *,
        raise_server_exceptions: bool,
    ) -> Response:
        handler = _lookup_exception_handler(self.exception_handlers, exc)
        if handler is not None:
            return _run_maybe_async(handler(request, exc))
        if isinstance(exc, HTTPException):
            headers = exc.headers or {}
            if not _status_allows_body(exc.status_code):
                return Response(b"", status_code=exc.status_code, media_type=None, headers=headers)
            return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=headers)
        if isinstance(exc, RequestValidationError):
            return JSONResponse({"detail": exc.errors()}, status_code=422)
        return Response("Internal Server Error", status_code=500, media_type="text/plain; charset=utf-8")

    def handle_websocket(
        self,
        path: str,
        root_path: str = "",
        headers: dict[str, str] | list[tuple[str, str]] | None = None,
    ) -> Any:
        route_path, _, query_string = path.partition("?")
        for prefix, mounted_app, _ in self.mounts:
            if route_path != prefix and not route_path.startswith(prefix + "/"):
                continue
            child_path = route_path[len(prefix):] or "/"
            child_target = child_path + (f"?{query_string}" if query_string else "")
            handler = getattr(mounted_app, "handle_websocket", None)
            if handler is not None:
                return handler(child_target, root_path=f"{root_path}{prefix}", headers=headers)
        for route in self.websocket_routes:
            path_params = route.match(route_path)
            if path_params is not None:
                close_state: dict[str, Any] = {}
                holder: dict[str, Any] = {}
                ready = threading.Event()
                worker_error: dict[str, BaseException] = {}
                caller_context = contextvars.copy_context()
                scope = {
                    "type": "websocket",
                    "path": route_path,
                    "query_string": query_string.encode("latin-1"),
                    "headers": [
                        (
                            str(key).encode("latin-1"),
                            str(value).encode("latin-1"),
                        )
                        for key, value in (
                            headers.items() if hasattr(headers, "items") else headers or []
                        )
                    ],
                    "app": self,
                    "route": route,
                    "root_path": root_path,
                }

                async def receive() -> dict[str, Any]:
                    return {"type": "websocket.receive"}

                async def send(message: dict[str, Any]) -> None:
                    if message.get("type") == "websocket.close":
                        close_state["code"] = message.get("code", 1000)
                        close_state["reason"] = message.get("reason", "")

                async def endpoint_app(scope: dict[str, Any], receive: Any, send: Any) -> None:
                    websocket = WebSocket(
                        scope,
                        receive=receive,
                        send=send,
                        close_state=close_state,
                    )
                    holder["websocket"] = websocket
                    websocket._worker_error = worker_error
                    ready.set()
                    try:
                        holder["websocket"] = await asyncio.to_thread(
                            route.handle,
                            self,
                            route_path,
                            path_params,
                            query_string=query_string,
                            close_state=close_state,
                            websocket=websocket,
                        )
                    except Exception as exc:
                        handler = _lookup_exception_handler(self.exception_handlers, exc)
                        if handler is None:
                            raise
                        result = handler(websocket, exc)
                        if inspect.isawaitable(result):
                            await result

                app = endpoint_app
                for middleware in reversed(self.websocket_middleware):
                    app = middleware.cls(app, *middleware.args, **middleware.kwargs)
                def run_app() -> None:
                    try:
                        caller_context.run(_run_maybe_async, app(scope, receive, send))
                    except BaseException as exc:
                        worker_error["error"] = exc

                worker = threading.Thread(target=run_app, daemon=True)
                worker.start()
                ready.wait(timeout=1.0)
                websocket = holder.get("websocket")
                if websocket is not None:
                    websocket._worker = worker
                    if not websocket._accepted.is_set() and not close_state and worker.is_alive():
                        websocket._accepted.wait(timeout=1.0)
                    if close_state and worker.is_alive():
                        worker.join(timeout=1.0)
                    if worker_error and not close_state:
                        raise worker_error["error"]
                if close_state and (websocket is None or not websocket._messages):
                    raise WebSocketDisconnect(
                        close_state.get("code", 1000),
                        close_state.get("reason", ""),
                    )
                return websocket
        raise WebSocketDisconnect(1000)

    def startup(self) -> dict[str, Any]:
        self.app_state = {}
        self._lifespan_exits = []
        for handler in self.on_startup:
            _run_maybe_async(handler())
        for lifespan in [*self.lifespan_contexts, *([self.lifespan] if self.lifespan is not None else [])]:
            state_update, exit_func = _enter_lifespan(lifespan, self)
            if state_update:
                self.app_state.update(state_update)
            self._lifespan_exits.append(exit_func)
        return self.app_state

    def shutdown(self) -> None:
        for exit_func in reversed(self._lifespan_exits):
            _run_maybe_async(exit_func())
        self._lifespan_exits = []
        for handler in self.on_shutdown:
            _run_maybe_async(handler())

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            raise RuntimeError("Only HTTP ASGI scopes are supported in the first slice")
        query = scope.get("query_string", b"").decode("latin-1")
        target = scope["path"] + (f"?{query}" if query else "")
        headers = [
            (key.decode("latin-1"), value.decode("latin-1"))
            for key, value in scope.get("headers", [])
        ]
        raw_body = await _read_asgi_body(receive)
        response = self.handle_request(
            scope["method"],
            target,
            raw_body=raw_body,
            headers=headers,
            root_path=scope.get("root_path"),
            scheme=scope.get("scheme", "http"),
            client=scope.get("client"),
        )
        await send(
            {
                "type": "http.response.start",
                "status": response.status_code,
                "headers": [
                    (key.encode("latin-1"), value.encode("latin-1"))
                    for key, value in response.headers.raw_items()
                ],
            }
        )
        if isinstance(response, StreamingResponse):
            await _send_streaming_asgi_body(response, send)
            return
        await send({"type": "http.response.body", "body": response.body})

    def openapi(self, *, root_path: str = "") -> dict[str, Any]:
        root_path = root_path or self.root_path
        cacheable = root_path == self.root_path
        if cacheable and self.openapi_schema is not None:
            return self.openapi_schema
        paths: dict[str, Any] = {}
        needs_validation_error = False
        components: dict[str, Any] = {}
        security_schemes: dict[str, Any] = {}
        operation_ids: set[str] = set()
        for route in self.routes:
            if not route.include_in_schema:
                continue
            if _is_duplicate_slash_schema_route(route, self.routes):
                continue
            for method in sorted(route.methods):
                parameters = _openapi_parameters(route, components)
                request_body = _openapi_request_body(route, components)
                security_requirements = _openapi_security_requirements(route, security_schemes)
                has_validation_parameters = bool(parameters) or _has_validation_parameters(route)
                successful_response = {
                    "description": route.response_description or "Successful Response"
                }
                response_content = _response_content(route, method, components)
                if _status_allows_body(route.status_code) and response_content:
                    successful_response["content"] = response_content
                operation_id = _operation_id(route, method)
                if operation_id in operation_ids:
                    warnings.warn(f"Duplicate Operation ID {operation_id}", UserWarning)
                operation_ids.add(operation_id)
                operation: dict[str, Any] = {
                    "responses": {
                        str(route.status_code): successful_response
                    },
                    "summary": route.summary or _summary(route.endpoint),
                    "operationId": operation_id,
                }
                description = route.description or _docstring_description(route.endpoint)
                if description:
                    operation["description"] = description
                if route.tags:
                    operation["tags"] = _openapi_tags(route.tags)
                if route.callbacks:
                    operation["callbacks"] = _openapi_callbacks(route.callbacks, components, operation_ids)
                    needs_validation_error = True
                if route.deprecated:
                    operation["deprecated"] = True
                if security_requirements:
                    operation["security"] = security_requirements
                for status_code, response_spec in route.responses.items():
                    response_code = _openapi_response_code(status_code)
                    additional_response = _openapi_response(
                        response_code,
                        response_spec,
                        _response_media_type(route.response_class) or "application/json",
                        components,
                        route,
                        method,
                    )
                    if response_code in operation["responses"]:
                        operation["responses"][response_code] = _merge_openapi_response(
                            operation["responses"][response_code],
                            additional_response,
                            response_spec,
                        )
                    else:
                        operation["responses"][response_code] = additional_response
                if parameters:
                    operation["parameters"] = parameters
                if has_validation_parameters and "422" not in operation["responses"]:
                    operation["responses"]["422"] = {
                        "description": "Validation Error",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/HTTPValidationError"}
                            }
                        },
                    }
                    needs_validation_error = True
                if request_body is not None:
                    operation["requestBody"] = request_body
                    if "422" not in operation["responses"]:
                        operation["responses"]["422"] = {
                            "description": "Validation Error",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/HTTPValidationError"}
                                }
                            },
                        }
                        needs_validation_error = True
                if route.openapi_extra:
                    _merge_openapi_extra(operation, route.openapi_extra)
                paths.setdefault(_openapi_path(route.path), {})[method.lower()] = operation
        webhooks = _openapi_webhooks(
            self.webhooks.routes,
            components,
            security_schemes,
            operation_ids,
        )
        if webhooks:
            needs_validation_error = True
        info: dict[str, Any] = {"title": self.title, "version": self.version}
        if self.summary:
            info["summary"] = self.summary
        if self.description:
            info["description"] = self.description
        if self.terms_of_service:
            info["termsOfService"] = self.terms_of_service
        if self.contact:
            info["contact"] = self.contact
        if self.license_info:
            info["license"] = self.license_info
        schema: dict[str, Any] = {
            "openapi": "3.1.0",
            "info": info,
            "paths": paths,
        }
        if webhooks:
            schema["webhooks"] = webhooks
        servers = _openapi_servers(self.servers, root_path, self.root_path_in_servers)
        if servers:
            schema["servers"] = servers
        if self.openapi_tags:
            schema["tags"] = self.openapi_tags
        if needs_validation_error:
            components.update(
                {
                    "ValidationError": {
                        "title": "ValidationError",
                        "required": ["loc", "msg", "type"],
                        "type": "object",
                        "properties": {
                            "loc": {
                                "title": "Location",
                                "type": "array",
                                "items": {
                                    "anyOf": [{"type": "string"}, {"type": "integer"}]
                                },
                            },
                            "msg": {"title": "Message", "type": "string"},
                            "type": {"title": "Error Type", "type": "string"},
                            "input": {"title": "Input"},
                            "ctx": {"title": "Context", "type": "object"},
                        },
                    },
                    "HTTPValidationError": {
                        "title": "HTTPValidationError",
                        "type": "object",
                        "properties": {
                            "detail": {
                                "title": "Detail",
                                "type": "array",
                                "items": {"$ref": "#/components/schemas/ValidationError"},
                            }
                        },
                    },
                }
            )
        component_groups: dict[str, Any] = {}
        if components:
            component_groups["schemas"] = components
        if security_schemes:
            component_groups["securitySchemes"] = security_schemes
        if component_groups:
            schema["components"] = component_groups
        if self.openapi_external_docs is not None:
            schema["externalDocs"] = self.openapi_external_docs
        result = schema
        if cacheable:
            self.openapi_schema = result
        return result


def _docs_html(marker: str) -> str:
    return f"<!doctype html><html><head><title>FastAPI - Swagger UI</title></head><body>{marker}</body></html>"


def _handle_route(route: Route, request: Request, path_params: dict[str, str]) -> Response:
    if type(route) is Route:
        return route.handle(request, path_params)
    request.scope["path_params"] = path_params
    request.scope["background_tasks"] = request.background_tasks
    request.scope["dependency_cache"] = request.dependency_cache
    request.scope["dependency_finalizers"] = request.dependency_finalizers
    request.scope["dependency_loop"] = request.dependency_loop
    request.scope["body_param_names"] = request.body_param_names
    request.scope["defer_response_cleanup"] = request.defer_response_cleanup
    return _run_maybe_async(route.get_route_handler()(request))


def _call_openapi(app: FastAPI, root_path: str) -> dict[str, Any]:
    signature = inspect.signature(app.openapi)
    if "root_path" in signature.parameters:
        return app.openapi(root_path=root_path)
    return app.openapi()


def _merge_openapi_extra(operation: dict[str, Any], extra: dict[str, Any]) -> None:
    for key, value in extra.items():
        if key == "parameters" and isinstance(value, list):
            operation.setdefault("parameters", [])
            operation["parameters"].extend(value)
            continue
        existing = operation.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            _merge_openapi_extra(existing, value)
        else:
            operation[key] = value


def _openapi_servers(
    configured_servers: list[dict[str, Any]] | None,
    root_path: str,
    root_path_in_servers: bool = True,
) -> list[dict[str, Any]]:
    servers = [dict(server) for server in (configured_servers or [])]
    if root_path_in_servers and root_path and not any(server.get("url") == root_path for server in servers):
        return [{"url": root_path}, *servers]
    return servers


def _redirect_location(request: Request, path: str, query_string: str) -> str:
    target = path + (f"?{query_string}" if query_string else "")
    scheme = request.scope.get("scheme", "http") if request.scope else "http"
    host = (request.headers or Headers()).get("host")
    if not host:
        return target
    root_path = (request.scope or {}).get("root_path") or ""
    if root_path and not target.startswith(root_path + "/"):
        target = root_path.rstrip("/") + target
    return f"{scheme}://{host}{target}"


def _lookup_exception_handler(
    handlers: dict[type[Exception], Callable[..., Response]],
    exc: Exception,
) -> Callable[..., Response] | None:
    handler_class = _lookup_exception_handler_class(handlers, exc)
    if handler_class is None:
        return None
    return handlers[handler_class]


def _lookup_exception_handler_class(
    handlers: dict[type[Exception], Callable[..., Response]],
    exc: Exception,
) -> type[Exception] | None:
    for exc_class in type(exc).__mro__:
        if exc_class in handlers:
            return exc_class
    return None


def _run_maybe_async(value: Any) -> Any:
    if inspect.isawaitable(value):
        import asyncio

        return asyncio.run(value)
    return value


def _enter_lifespan(
    lifespan: Callable[..., Any],
    app: FastAPI,
) -> tuple[dict[str, Any] | None, Callable[[], Any]]:
    context = lifespan(app)
    if hasattr(context, "__aenter__") and hasattr(context, "__aexit__"):
        loop = asyncio.new_event_loop()
        state = loop.run_until_complete(context.__aenter__())

        def exit_context() -> Any:
            try:
                return loop.run_until_complete(context.__aexit__(None, None, None))
            finally:
                loop.close()

        return state, exit_context
    if hasattr(context, "__enter__") and hasattr(context, "__exit__"):
        state = context.__enter__()

        def exit_context() -> Any:
            return context.__exit__(None, None, None)

        return state, exit_context
    if inspect.isasyncgen(context):
        loop = asyncio.new_event_loop()
        state = loop.run_until_complete(context.__anext__())

        def exit_context() -> Any:
            try:
                loop.run_until_complete(context.__anext__())
            except StopAsyncIteration:
                pass
            finally:
                loop.close()

        return state, exit_context
    if inspect.isgenerator(context):
        state = next(context)

        def exit_context() -> Any:
            try:
                next(context)
            except StopIteration:
                return None

        return state, exit_context
    return None, lambda: None


def _form_body_size(value: Any) -> int:
    if isinstance(value, dict):
        return sum(_form_body_size(item) for item in value.values())
    if isinstance(value, list):
        return sum(_form_body_size(item) for item in value)
    if isinstance(value, bytes):
        return len(value)
    if isinstance(value, str):
        return len(value.encode("utf-8"))
    if hasattr(value, "file"):
        if getattr(value, "size", None) is not None:
            return int(value.size)
        return _form_body_size(value.file)
    if hasattr(value, "tell") and hasattr(value, "seek"):
        try:
            position = value.tell()
            value.seek(0, 2)
            size = value.tell()
            value.seek(position)
            return int(size)
        except Exception:
            return 0
    return 0


def _static_file_response(directory: str, child_path: str) -> Response:
    relative = child_path.lstrip("/")
    full_path = os.path.abspath(os.path.join(directory, relative))
    root = os.path.abspath(directory)
    if not (full_path == root or full_path.startswith(root + os.sep)):
        return JSONResponse({"detail": "Not Found"}, status_code=404)
    if not os.path.isfile(full_path):
        return JSONResponse({"detail": "Not Found"}, status_code=404)
    with open(full_path, "rb") as file:
        return Response(file.read(), media_type="text/plain; charset=utf-8")


class ImmediateAwaitable:
    def __init__(self, func: Callable[[], Response]) -> None:
        self.func = func

    def __await__(self) -> Any:
        result = self.func()
        if False:
            yield None
        return result


def _run_sync_awaitable(value: Any) -> Any:
    if not inspect.isawaitable(value):
        return value
    iterator = value.__await__()
    try:
        next(iterator)
    except StopIteration as exc:
        return exc.value
    raise RuntimeError("Async middleware yielded an unsupported awaitable")


def _get_annotations(call: Any) -> dict[str, Any]:
    try:
        annotations = inspect.get_annotations(call, eval_str=True)
    except Exception:
        annotations = inspect.get_annotations(call)
    if inspect.isclass(call):
        init = getattr(call, "__init__", None)
        if init is None:
            return annotations
        try:
            init_annotations = inspect.get_annotations(init, eval_str=True)
        except Exception:
            init_annotations = inspect.get_annotations(init)
        return init_annotations or annotations
    if inspect.isfunction(call) or inspect.ismethod(call) or inspect.isclass(call):
        return annotations
    call_method = getattr(call, "__call__", None)
    if call_method is None:
        return annotations
    try:
        call_annotations = inspect.get_annotations(call_method, eval_str=True)
    except Exception:
        call_annotations = inspect.get_annotations(call_method)
    return call_annotations or annotations


def _join_paths(prefix: str, path: str) -> str:
    if not prefix:
        return path
    joined = f"/{prefix.strip('/')}/{path.strip('/')}"
    if path.endswith("/") and joined != "/" and not joined.endswith("/"):
        joined += "/"
    return "/" if joined == "//" else joined


def _included_route_paths(prefix: str, path: str) -> list[str]:
    if prefix and path == "":
        base = prefix if prefix.startswith("/") else f"/{prefix}"
        base = base.rstrip("/") or "/"
        return [base, f"{base}/" if base != "/" else "/"]
    return [_join_paths(prefix, path)]


def _included_response_class(
    route_response_class: type[Response],
    router_default_response_class: type[Response],
    effective_default_response_class: type[Response],
) -> type[Response]:
    if route_response_class is router_default_response_class and router_default_response_class is JSONResponse:
        return effective_default_response_class
    return route_response_class


def _toggle_trailing_slash(path: str) -> str:
    if path == "/":
        return path
    if path.endswith("/"):
        return path.rstrip("/")
    return path + "/"


def _openapi_parameters(route: Route, components: dict[str, Any]) -> list[dict[str, Any]]:
    path_param_names = set(re.findall(r"{([^}:]+)(?::[^}]+)?}", route.path))
    parameters: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    def collect(endpoint: Callable[..., Any]) -> None:
        signature = inspect.signature(endpoint)
        hints = _get_annotations(endpoint)
        for name, parameter in signature.parameters.items():
            collect_parameter(name, parameter, hints.get(name, Any))

    def collect_parameter(name: str, parameter: inspect.Parameter, annotation: object) -> None:
        default = parameter.default
        field_info = _annotated_field_info(annotation)
        annotation, annotated_default = _unpack_annotated(annotation)
        if annotated_default is not inspect.Signature.empty:
            _apply_signature_default(annotated_default, default)
            default = annotated_default
        if isinstance(default, DependsParam):
            dependency = _dependency_target(default, annotation)
            if dependency is not None and not _is_security_dependency(dependency):
                collect(dependency)
            return
        if annotation is Response:
            return
        if annotation is Request:
            return
        if annotation is HTTPConnection:
            return
        if getattr(annotation, "__name__", None) == "SecurityScopes":
            return
        if _contains_upload_file_annotation(annotation):
            return
        if isinstance(default, (QueryParam, HeaderParam, CookieParam)) and _is_model_like_annotation(annotation):
            if isinstance(default, Param) and not getattr(default, "include_in_schema", True):
                return
            collect_model_parameter_fields(
                annotation,
                _openapi_param_in(name, name, default, path_param_names),
                default,
            )
            return
        if isinstance(default, (BodyParam, FormParam)):
            return
        if not isinstance(default, (PathParam, QueryParam, HeaderParam, CookieParam)) and _is_body_annotation(annotation):
            return
        if isinstance(default, Param) and not getattr(default, "include_in_schema", True):
            return
        raw_param_name = _param_name(name, default)
        param_in = _openapi_param_in(name, raw_param_name, default, path_param_names)
        param_name = _openapi_param_name(name, raw_param_name, default, param_in)
        key = (param_in, param_name)
        if key in seen:
            return
        seen.add(key)
        schema = _schema_for_annotation(annotation, components)
        if "$ref" not in schema and "title" not in schema:
            schema = {"title": _title(param_name), **schema}
        if field_info is not None and getattr(field_info, "description", None) is not None:
            schema.setdefault("description", str(getattr(field_info, "description")))
        if isinstance(default, Param):
            _apply_param_schema(schema, default)
            if not default.required and default.default is not None:
                schema["default"] = default.default
        elif default is not inspect.Signature.empty and default is not None:
            schema["default"] = default
        parameter_spec = {
            "required": param_in == "path" or _required(default),
            "schema": schema,
            "name": param_name,
            "in": param_in,
        }
        if isinstance(default, Param):
            if getattr(default, "description", None) is not None:
                parameter_spec["description"] = str(getattr(default, "description"))
            if getattr(default, "deprecated", None) is not None:
                parameter_spec["deprecated"] = bool(getattr(default, "deprecated"))
            if getattr(default, "example", None) is not None:
                parameter_spec["example"] = getattr(default, "example")
            if getattr(default, "openapi_examples", None) is not None:
                parameter_spec["examples"] = getattr(default, "openapi_examples")
        parameters.append(parameter_spec)

    def collect_model_parameter_fields(annotation: object, param_in: str, default: object) -> None:
        model_schema = {}
        if hasattr(annotation, "model_json_schema"):
            model_schema = annotation.model_json_schema(ref_template="#/components/schemas/{model}")
        properties = model_schema.get("properties", {}) if isinstance(model_schema, dict) else {}
        for field_name, field in getattr(annotation, "model_fields", {}).items():
            param_name = _model_field_openapi_name(field_name, field, param_in, default)
            key = (param_in, param_name)
            if key in seen:
                continue
            seen.add(key)
            schema = dict(properties.get(param_name) or properties.get(field_name) or {})
            if not schema:
                schema = _schema_for_annotation(field.annotation)
            if "title" not in schema:
                schema["title"] = _title(param_name)
            parameters.append(
                {
                    "required": field.is_required(),
                    "schema": _strip_none_defaults(schema),
                    "name": param_name,
                    "in": param_in,
                }
            )
    for dependency in route.dependencies:
        dependency_target = _dependency_target(dependency, Any)
        if dependency_target is not None and not _is_security_dependency(dependency_target):
            collect(dependency_target)
    collect(route.endpoint)
    return sorted(parameters, key=_openapi_parameter_sort_key)


def _annotated_field_info(annotation: object) -> object | None:
    while get_origin(annotation) is Annotated:
        args = get_args(annotation)
        for item in args[1:]:
            if getattr(item, "description", None) is not None:
                return item
        annotation = args[0] if args else Any
    return None


def _has_validation_parameters(route: Route) -> bool:
    path_param_names = set(re.findall(r"{([^}:]+)(?::[^}]+)?}", route.path))
    seen: set[Callable[..., Any]] = set()

    def scan(endpoint: Callable[..., Any]) -> bool:
        if endpoint in seen:
            return False
        seen.add(endpoint)
        signature = inspect.signature(endpoint)
        hints = _get_annotations(endpoint)
        for name, parameter in signature.parameters.items():
            default = parameter.default
            annotation = hints.get(name, Any)
            annotation, annotated_default = _unpack_annotated(annotation)
            if annotated_default is not inspect.Signature.empty:
                _apply_signature_default(annotated_default, default)
                default = annotated_default
            if isinstance(default, DependsParam):
                dependency = _dependency_target(default, annotation)
                if (
                    dependency is not None
                    and not _is_security_dependency(dependency)
                    and scan(dependency)
                ):
                    return True
                continue
            if annotation in {Response, Request, HTTPConnection}:
                continue
            if getattr(annotation, "__name__", None) == "SecurityScopes":
                continue
            if (
                isinstance(default, (BodyParam, FormParam))
                or _contains_upload_file_annotation(annotation)
                or (
                    not isinstance(default, (PathParam, QueryParam, HeaderParam, CookieParam))
                    and _is_body_annotation(annotation)
                )
            ):
                continue
            param_name = _param_name(name, default)
            if _openapi_param_in(name, param_name, default, path_param_names) in {
                "path",
                "query",
                "header",
                "cookie",
            }:
                return True
        return False

    return any(
        dependency_target is not None
        and not _is_security_dependency(dependency_target)
        and scan(dependency_target)
        for dependency_target in (
            _dependency_target(dependency, Any) for dependency in route.dependencies
        )
    ) or scan(route.endpoint)


def _openapi_security_requirements(
    route: Route,
    security_schemes: dict[str, Any],
) -> list[dict[str, list[str]]]:
    requirements: list[dict[str, list[str]]] = []
    seen_requirements: dict[str, int] = {}
    seen_calls: set[tuple[Callable[..., Any], tuple[str, ...]]] = set()

    def collect_dependency(dependency: DependsParam, inherited_scopes: list[str]) -> None:
        if dependency.dependency is None:
            return
        active_scopes = [*inherited_scopes, *dependency.scopes]
        scheme_name = getattr(dependency.dependency, "scheme_name", None)
        openapi_scheme = getattr(dependency.dependency, "openapi_scheme", None)
        if scheme_name is not None and callable(openapi_scheme):
            security_schemes.setdefault(scheme_name, openapi_scheme())
            index = seen_requirements.get(scheme_name)
            if index is None:
                requirements.append({scheme_name: active_scopes})
                seen_requirements[scheme_name] = len(requirements) - 1
            elif len(active_scopes) > len(requirements[index].get(scheme_name, [])):
                requirements[index] = {scheme_name: active_scopes}
            return
        collect_call(dependency.dependency, active_scopes)

    def collect_call(call: Callable[..., Any], inherited_scopes: list[str]) -> None:
        cache_key = (call, tuple(inherited_scopes))
        if cache_key in seen_calls:
            return
        seen_calls.add(cache_key)
        signature = inspect.signature(call)
        hints = _get_annotations(call)
        for name, parameter in signature.parameters.items():
            default = parameter.default
            annotation = hints.get(name, Any)
            annotation, annotated_default = _unpack_annotated(annotation)
            if annotated_default is not inspect.Signature.empty:
                _apply_signature_default(annotated_default, default)
                default = annotated_default
            if isinstance(default, DependsParam):
                dependency = _dependency_target(default, annotation)
                if dependency is not None:
                    collect_dependency(
                        DependsParam(
                            dependency,
                            use_cache=default.use_cache,
                            scopes=list(default.scopes),
                            scope=default.scope,
                        ),
                        inherited_scopes,
                    )

    for dependency in route.dependencies:
        collect_dependency(dependency, [])
    collect_call(route.endpoint, [])
    return requirements


def _is_security_dependency(dependency: Any) -> bool:
    return getattr(dependency, "scheme_name", None) is not None and callable(
        getattr(dependency, "openapi_scheme", None)
    )


def _dependency_target(dependency: DependsParam, annotation: object) -> Any | None:
    if dependency.dependency is not None:
        return dependency.dependency
    if annotation in (Any, inspect.Signature.empty):
        return None
    return annotation


def _openapi_parameter_sort_key(parameter: dict[str, Any]) -> tuple[int, int]:
    order = {"path": 0, "query": 1, "header": 2, "cookie": 3}
    return (order.get(str(parameter.get("in")), 99), 0)


def _openapi_param_in(
    name: str,
    param_name: str,
    default: object,
    path_param_names: set[str],
) -> str:
    if isinstance(default, PathParam):
        return "path"
    if isinstance(default, HeaderParam):
        return "header"
    if isinstance(default, CookieParam):
        return "cookie"
    if isinstance(default, FormParam):
        return "form"
    if isinstance(default, QueryParam):
        return "query"
    if name in path_param_names or param_name in path_param_names:
        return "path"
    return "query"


def _openapi_param_name(name: str, param_name: str, default: object, param_in: str) -> str:
    if param_in != "header":
        return param_name
    if isinstance(default, HeaderParam) and (
        getattr(default, "alias", None) or getattr(default, "validation_alias", None)
    ):
        return param_name
    if isinstance(default, HeaderParam) and getattr(default, "convert_underscores", True) is False:
        return param_name
    return name.replace("_", "-")


def _unpack_annotated(annotation: object) -> tuple[object, object]:
    annotation = _unwrap_type_alias(annotation)
    if get_origin(annotation) is not Annotated:
        return annotation, inspect.Signature.empty
    args = get_args(annotation)
    param = inspect.Signature.empty
    remaining_metadata = []
    for item in args[1:]:
        if isinstance(item, (DependsParam, Param)):
            item = copy.copy(item)
            setattr(item, "_superduperfastapi_from_annotated", True)
            param = item
        else:
            remaining_metadata.append(item)
    inner = Annotated[args[0], *remaining_metadata] if remaining_metadata else args[0]
    return inner, param


def _unwrap_type_alias(annotation: object) -> object:
    while hasattr(annotation, "__value__"):
        annotation = annotation.__value__
    return annotation


def _apply_signature_default(default: object, signature_default: object) -> None:
    if (
        isinstance(default, Param)
        and default.default is _MISSING
        and signature_default is not inspect.Signature.empty
    ):
        default.default = signature_default


def _openapi_request_body(route: Route, components: dict[str, Any]) -> dict[str, Any] | None:
    body_fields_by_name: dict[str, tuple[str, object, object]] = {}
    seen: set[Any] = set()

    def collect(call: Callable[..., Any]) -> None:
        if call in seen:
            return
        seen.add(call)
        signature = inspect.signature(call)
        hints = _get_annotations(call)
        for name, parameter in signature.parameters.items():
            annotation = hints.get(name, Any)
            annotation, annotated_default = _unpack_annotated(annotation)
            default = parameter.default
            if annotated_default is not inspect.Signature.empty:
                _apply_signature_default(annotated_default, default)
                default = annotated_default
            if isinstance(default, DependsParam):
                dependency = _dependency_target(default, annotation)
                if dependency is not None and not _is_security_dependency(dependency):
                    collect(dependency)
                continue
            if annotation in {Response, Request, HTTPConnection}:
                continue
            if isinstance(default, (QueryParam, HeaderParam, CookieParam)):
                continue
            if (
                not isinstance(default, (BodyParam, FormParam))
                and not _is_body_annotation(annotation)
                and not _contains_upload_file_annotation(annotation)
            ):
                continue
            body_fields_by_name.setdefault(_param_name(name, default), (name, annotation, default))

    for dependency in route.dependencies:
        if dependency.dependency is not None:
            collect(dependency.dependency)
    collect(route.endpoint)
    body_fields = list(body_fields_by_name.values())
    if not body_fields:
        return None

    media_type = _body_media_type(body_fields)
    if len(body_fields) == 1:
        name, annotation, default = body_fields[0]
        if (
            (not isinstance(default, Param) or not getattr(default, "embed", False))
            and not (isinstance(default, FormParam) and not _is_model_like_annotation(annotation))
            and not _contains_upload_file_annotation(annotation)
        ):
            schema = _schema_for_body_annotation(annotation, components, route, default)
            if "$ref" not in schema and "title" not in schema:
                schema = {"title": _title(_param_name(name, default)), **schema}
            content_entry = {"schema": schema}
            _apply_body_content_examples(content_entry, default)
            request_body = {"content": {media_type: content_entry}}
            if _required(default):
                request_body["required"] = True
            return request_body

    component_name = f"Body_{_operation_id(route, next(iter(sorted(route.methods))))}"
    required = []
    properties = {}
    for name, annotation, default in body_fields:
        param_name = _param_name(name, default)
        if _required(default):
            required.append(param_name)
        properties[param_name] = _schema_for_body_property(param_name, annotation, default, components, route)
    schema: dict[str, Any] = {
        "title": component_name,
        "type": "object",
        "properties": properties,
    }
    if required:
        schema["required"] = required
    components.setdefault(component_name, schema)
    request_body = {
        "content": {media_type: {"schema": {"$ref": f"#/components/schemas/{component_name}"}}},
    }
    if required:
        request_body["required"] = True
    return request_body


def _body_media_type(body_fields: list[tuple[str, object, object]]) -> str:
    if any(isinstance(default, FileParam) or _contains_upload_file_annotation(annotation) for _, annotation, default in body_fields):
        return "multipart/form-data"
    default = body_fields[0][2]
    if isinstance(default, Param) and getattr(default, "media_type", None):
        return str(default.media_type)
    if isinstance(default, FormParam):
        return "application/x-www-form-urlencoded"
    return "application/json"


def _apply_body_content_examples(content_entry: dict[str, Any], default: object) -> None:
    if not isinstance(default, Param):
        return
    schema = content_entry.get("schema")
    if isinstance(schema, dict):
        if getattr(default, "examples", None) is not None:
            schema["examples"] = getattr(default, "examples")
    if getattr(default, "example", None) is not None:
        content_entry["example"] = getattr(default, "example")
    openapi_examples = getattr(default, "openapi_examples", None)
    if openapi_examples is not None:
        content_entry["examples"] = openapi_examples


def _schema_for_body_annotation(
    annotation: object,
    components: dict[str, Any],
    route: Route | None = None,
    default: object = inspect.Signature.empty,
) -> dict[str, Any]:
    if get_origin(annotation) is Annotated:
        schema = _schema_from_type_adapter(annotation, components)
        if isinstance(default, BodyParam) and not getattr(default, "_superduperfastapi_from_annotated", False):
            schema = _assignment_body_schema(schema)
        return schema
    if _allows_none(annotation):
        inner = _unwrap_optional(annotation)
        return {"anyOf": [_schema_for_body_annotation(inner, components, route, default), {"type": "null"}]}
    if hasattr(annotation, "model_json_schema"):
        suffix = _schema_component_suffix(annotation, "validation", route, components)
        _collect_model_schema(annotation, components, mode="validation", name_suffix=suffix)
        return {"$ref": f"#/components/schemas/{annotation.__name__}{suffix}"}
    if is_dataclass(annotation):
        suffix = _schema_component_suffix(annotation, "validation", route, components)
        _collect_model_schema(annotation, components, mode="validation", name_suffix=suffix)
        return {"$ref": f"#/components/schemas/{annotation.__name__}{suffix}"}
    origin = get_origin(annotation)
    if origin in (types.UnionType, Union):
        return _schema_from_type_adapter(annotation, components)
    if origin is tuple:
        return _schema_from_type_adapter(annotation, components)
    if origin in (list, set, frozenset, tuple):
        args = get_args(annotation)
        item_schema = _schema_for_body_annotation(args[0], components, route) if args and args[0] is not Ellipsis else {}
        schema: dict[str, Any] = {
            "type": "array",
            "items": item_schema,
        }
        if origin in (set, frozenset):
            schema["uniqueItems"] = True
        return schema
    if origin is dict:
        args = get_args(annotation)
        value_schema = _schema_for_body_annotation(args[1], components, route) if len(args) > 1 else {}
        return {"type": "object", "additionalProperties": value_schema}
    return _schema_for_annotation(annotation)


def _schema_from_type_adapter(annotation: object, components: dict[str, Any]) -> dict[str, Any]:
    schema = core_schema_adapter(annotation).type_adapter.json_schema(
        ref_template="#/components/schemas/{model}"
    )
    _trim_formfeed_descriptions(schema)
    _normalize_openapi31_schema(schema)
    for name, definition in schema.pop("$defs", {}).items():
        _trim_formfeed_descriptions(definition)
        _normalize_openapi31_schema(definition)
        components.setdefault(name, _strip_none_defaults(definition))
    return _strip_none_defaults(schema)


def _assignment_body_schema(schema: dict[str, Any]) -> dict[str, Any]:
    schema = copy.deepcopy(schema)
    if "oneOf" in schema:
        schema["anyOf"] = schema.pop("oneOf")
    schema.pop("discriminator", None)
    return schema


def _schema_for_body_property(
    name: str,
    annotation: object,
    default: object,
    components: dict[str, Any],
    route: Route | None = None,
) -> dict[str, Any]:
    schema = _schema_for_body_annotation(annotation, components, route, default)
    if "$ref" not in schema and "title" not in schema:
        schema["title"] = _title(name)
    if isinstance(default, Param):
        _apply_param_schema(schema, default)
    if isinstance(default, Param) and not default.required and default.default is not None:
        schema["default"] = default.default
    return schema


def _schema_for_annotation(annotation: object, components: dict[str, Any] | None = None) -> dict[str, Any]:
    if get_origin(annotation) is Annotated:
        args = get_args(annotation)
        return _schema_for_annotation(args[0], components) if args else {}
    if _allows_none(annotation):
        inner = _unwrap_optional(annotation)
        return {"anyOf": [_schema_for_annotation(inner, components), {"type": "null"}]}
    origin = get_origin(annotation)
    if annotation is list:
        return {"type": "array", "items": {}}
    if origin in (list, set, frozenset, tuple):
        args = get_args(annotation)
        schema: dict[str, Any] = {
            "type": "array",
            "items": _schema_for_annotation(args[0], components) if args and args[0] is not Ellipsis else {},
        }
        if origin in (set, frozenset):
            schema["uniqueItems"] = True
        return schema
    if origin is dict:
        args = get_args(annotation)
        if len(args) > 1 and args[1] is not Any:
            value_schema: Any = _schema_for_annotation(args[1], components)
        else:
            value_schema = True
        return {"type": "object", "additionalProperties": value_schema}
    if isinstance(annotation, type) and issubclass(annotation, Enum):
        schema = _schema_for_enum(annotation)
        if components is not None:
            components.setdefault(annotation.__name__, schema)
            return {"$ref": f"#/components/schemas/{annotation.__name__}"}
        return schema
    if is_dataclass(annotation):
        if components is not None:
            _collect_model_schema(annotation, components)
            return {"$ref": f"#/components/schemas/{annotation.__name__}"}
        return core_schema_adapter(annotation).type_adapter.json_schema(ref_template="#/components/schemas/{model}")
    types = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        type(None): "null",
    }
    formatted_types = {
        UUID: ("string", "uuid"),
        datetime: ("string", "date-time"),
        date: ("string", "date"),
        time: ("string", "time"),
        timedelta: ("string", "duration"),
    }
    if annotation in formatted_types:
        schema_type, schema_format = formatted_types[annotation]
        return {"type": schema_type, "format": schema_format}
    if getattr(annotation, "__name__", None) == "HttpUrl":
        return {"type": "string", "format": "uri", "minLength": 1, "maxLength": 2083}
    if annotation is bytes or getattr(annotation, "__name__", None) == "UploadFile":
        return {"type": "string", "contentMediaType": "application/octet-stream"}
    if annotation in types:
        return {"type": types[annotation]}
    return {}


def _is_upload_file_annotation(annotation: object) -> bool:
    return getattr(annotation, "__name__", None) == "UploadFile"


def _contains_upload_file_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    if _is_upload_file_annotation(annotation):
        return True
    origin = get_origin(annotation)
    if origin in (list, set, frozenset, tuple):
        return any(_contains_upload_file_annotation(arg) for arg in get_args(annotation))
    return False


def _schema_for_enum(annotation: type[Enum]) -> dict[str, Any]:
    values = [item.value for item in annotation]
    value_type = "string" if all(isinstance(value, str) for value in values) else "integer"
    return {"title": annotation.__name__, "enum": values, "type": value_type}


def _is_body_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    if _is_model_like_annotation(annotation):
        return True
    if annotation in (dict, list, set, frozenset, tuple):
        return True
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        return bool(args and _is_body_annotation(args[0]))
    if origin in (dict, list, set, frozenset, tuple):
        return True
    if origin in (types.UnionType, Union):
        return any(_is_body_annotation(arg) for arg in get_args(annotation))
    return False


def _is_model_like_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        return bool(args and _is_model_like_annotation(args[0]))
    if origin in (types.UnionType, Union):
        return any(_is_model_like_annotation(arg) for arg in get_args(annotation))
    return hasattr(annotation, "model_validate") or is_dataclass(annotation)


def _openapi_response(
    status_code: str,
    response_spec: dict[str, Any],
    media_type: str | None,
    components: dict[str, Any],
    route: Route,
    method: str,
) -> dict[str, Any]:
    response = {"description": response_spec.get("description", _default_response_description(status_code))}
    content = copy.deepcopy(response_spec.get("content", {}))
    model = response_spec.get("model")
    if model is not None and media_type is not None:
        title = _response_title(route, method, status_code=status_code)
        media_content = content.setdefault(media_type, {})
        media_content["schema"] = _schema_for_model_type(model, route, method, components, title=title)
    if content:
        response["content"] = content
    return response


def _merge_openapi_response(
    base: dict[str, Any],
    additional: dict[str, Any],
    response_spec: dict[str, Any],
) -> dict[str, Any]:
    merged = copy.deepcopy(base)
    if "description" in response_spec:
        merged["description"] = additional["description"]
    if "content" in additional:
        content = merged.setdefault("content", {})
        for media_type, media_spec in additional["content"].items():
            existing_media = content.setdefault(media_type, {})
            if isinstance(existing_media, dict) and isinstance(media_spec, dict):
                existing_media.update(copy.deepcopy(media_spec))
            else:
                content[media_type] = copy.deepcopy(media_spec)
    return merged


def _openapi_response_code(status_code: int | str) -> str:
    code = str(status_code)
    if len(code) == 3 and code[1:].lower() == "xx":
        return code.upper()
    if code == "default":
        return code
    if code.isdigit() and 100 <= int(code) <= 599:
        return code
    raise ValueError(f"Invalid response status code {status_code!r}")


def _default_response_description(status_code: str) -> str:
    if status_code == "default":
        return "Default Response"
    if status_code == "5XX":
        return "Server Error"
    if status_code == "500":
        return "Internal Server Error"
    if status_code.isdigit():
        try:
            return HTTPStatus(int(status_code)).phrase
        except ValueError:
            pass
    return "Additional Response"


def _openapi_callbacks(
    callbacks: list[Route],
    components: dict[str, Any],
    operation_ids: set[str],
) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for callback in callbacks:
        callback_paths: dict[str, Any] = {}
        for method in sorted(callback.methods):
            operation_id = _operation_id(callback, method)
            if operation_id in operation_ids:
                warnings.warn(f"Duplicate Operation ID {operation_id}", UserWarning)
            operation_ids.add(operation_id)
            response_schema = _response_schema(callback, method, components)
            media_type = _response_media_type(callback.response_class) or "application/json"
            operation: dict[str, Any] = {
                "summary": callback.summary or _summary(callback.endpoint),
                "operationId": operation_id,
                "responses": {
                    str(callback.status_code): {
                        "description": callback.response_description or "Successful Response",
                        "content": {media_type: {"schema": response_schema}},
                    }
                },
            }
            description = callback.description or _docstring_description(callback.endpoint)
            if description:
                operation["description"] = description
            if callback.tags:
                operation["tags"] = _openapi_tags(callback.tags)
            parameters = _openapi_parameters(callback, components)
            if parameters:
                operation["parameters"] = parameters
            for status_code, response_spec in callback.responses.items():
                response_code = _openapi_response_code(status_code)
                operation["responses"][response_code] = _openapi_response(
                    response_code,
                    response_spec,
                    _response_media_type(callback.response_class) or "application/json",
                    components,
                    callback,
                    method,
                )
            request_body = _openapi_request_body(callback, components)
            if request_body is not None:
                operation["requestBody"] = request_body
            if parameters or request_body is not None:
                operation["responses"]["422"] = {
                    "description": "Validation Error",
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/HTTPValidationError"}
                        }
                    },
                }
            callback_paths.setdefault(_openapi_path(callback.path), {})[method.lower()] = operation
        result[callback.endpoint.__name__] = callback_paths
    return result


def _webhook_operation_id(route: Route, method: str) -> str:
    if route.generate_unique_id_function is not None:
        return str(route.generate_unique_id_function(route))
    path_part = re.sub(r"\W", "_", _openapi_path(route.path).strip("/"))
    return f"{route.endpoint.__name__}{path_part}_{method.lower()}"


def _openapi_webhooks(
    routes: list[Route],
    components: dict[str, Any],
    security_schemes: dict[str, Any],
    operation_ids: set[str],
) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for route in routes:
        for method in sorted(route.methods):
            operation_id = _webhook_operation_id(route, method)
            if operation_id in operation_ids:
                warnings.warn(f"Duplicate Operation ID {operation_id}", UserWarning)
            operation_ids.add(operation_id)
            media_type = _response_media_type(route.response_class) or "application/json"
            security_requirements = _openapi_security_requirements(route, security_schemes)
            operation: dict[str, Any] = {
                "summary": route.summary or _summary(route.endpoint),
                "operationId": operation_id,
                "responses": {
                    str(route.status_code): {
                        "description": route.response_description or "Successful Response",
                        "content": {media_type: {"schema": _response_schema(route, method, components)}},
                    }
                },
            }
            description = route.description or _docstring_description(route.endpoint)
            if description:
                operation["description"] = description
            if security_requirements:
                operation["security"] = security_requirements
            request_body = _openapi_request_body(route, components)
            if request_body is not None:
                operation["requestBody"] = request_body
                operation["responses"]["422"] = {
                    "description": "Validation Error",
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/HTTPValidationError"}
                        }
                    },
                }
            result.setdefault(_openapi_path(route.path), {})[method.lower()] = operation
    return result


def _collect_model_schema(
    model: Any,
    components: dict[str, Any],
    *,
    mode: str = "validation",
    name_suffix: str = "",
) -> None:
    for component_name, schema in _model_json_schema_component_entries(model, mode, name_suffix):
        if mode == "serialization":
            components[component_name] = copy.deepcopy(schema)
        else:
            components.setdefault(component_name, copy.deepcopy(schema))


def _model_json_schema_component_entries(
    model: Any,
    mode: str,
    name_suffix: str,
) -> list[tuple[str, dict[str, Any]]]:
    cache_key = (model, mode, name_suffix)
    cached = _MODEL_JSON_SCHEMA_COMPONENT_CACHE.get(cache_key)
    if cached is not None:
        return cached

    ref_template = f"#/components/schemas/{{model}}{name_suffix}"
    if hasattr(model, "model_json_schema"):
        schema = model.model_json_schema(
            ref_template=ref_template,
            mode=mode,
        )
    elif is_dataclass(model):
        schema = core_schema_adapter(model).type_adapter.json_schema(
            ref_template=ref_template,
            mode=mode,
        )
    else:
        return []
    _trim_formfeed_descriptions(schema)
    _normalize_openapi31_schema(schema)
    entries: list[tuple[str, dict[str, Any]]] = []
    for name, definition in schema.pop("$defs", {}).items():
        _trim_formfeed_descriptions(definition)
        _normalize_openapi31_schema(definition)
        component_name = f"{name}{name_suffix}"
        entries.append((component_name, _strip_none_defaults(definition)))
    component_name = f"{model.__name__}{name_suffix}"
    entries.append((component_name, _strip_none_defaults(schema)))
    _MODEL_JSON_SCHEMA_COMPONENT_CACHE[cache_key] = entries
    return entries


def _schema_component_suffix(
    model: Any,
    mode: str,
    route: Route | None,
    components: dict[str, Any] | None = None,
) -> str:
    if not hasattr(model, "model_json_schema"):
        return ""
    if not _model_schema_modes_differ(model):
        return ""
    input_component_exists = components is not None and f"{model.__name__}-Input" in components
    output_component_exists = components is not None and f"{model.__name__}-Output" in components
    route_body_uses_model = route is not None and _route_body_uses_model(route, model)
    route_response_uses_model = route is not None and _route_response_uses_model(route, model)
    if mode == "validation":
        has_peer_schema = output_component_exists or route_response_uses_model
    else:
        has_peer_schema = input_component_exists or route_body_uses_model
    force_split = route is not None and route.separate_input_output_schemas and has_peer_schema
    if not force_split and not (_model_has_readonly_serialization_field(model) and has_peer_schema):
        return ""
    return "-Output" if mode == "serialization" else "-Input"


def _response_schema_mode(model: Any, route: Route, suffix: str) -> str:
    if suffix:
        return "serialization"
    if (
        not route.separate_input_output_schemas
        and _model_schema_modes_differ(model)
        and not _model_has_readonly_serialization_field(model)
    ):
        return "validation"
    return "serialization"


def _route_body_uses_model(route: Route, model: Any) -> bool:
    signature = inspect.signature(route.endpoint)
    hints = _get_annotations(route.endpoint)
    for name, parameter in signature.parameters.items():
        annotation = hints.get(name, Any)
        annotation, annotated_default = _unpack_annotated(annotation)
        default = parameter.default
        if annotated_default is not inspect.Signature.empty:
            _apply_signature_default(annotated_default, default)
            default = annotated_default
        if isinstance(default, (QueryParam, HeaderParam, CookieParam)):
            continue
        if (
            isinstance(default, (BodyParam, FormParam))
            or _is_body_annotation(annotation)
            or _contains_upload_file_annotation(annotation)
        ) and _annotation_contains_model(annotation, model):
            return True
    return False


def _route_response_uses_model(route: Route, model: Any) -> bool:
    if _annotation_contains_model(route.response_model, model):
        return True
    return any(
        _annotation_contains_model(response_spec.get("model"), model)
        for response_spec in route.responses.values()
        if isinstance(response_spec, dict)
    )


def _annotation_contains_model(annotation: Any, model: Any) -> bool:
    annotation = _unwrap_type_alias(_unwrap_optional(annotation))
    if annotation is model:
        return True
    return any(_annotation_contains_model(arg, model) for arg in get_args(annotation) if arg is not Ellipsis)


def _model_schema_modes_differ(model: Any) -> bool:
    if not hasattr(model, "model_json_schema"):
        return False
    cached = _MODEL_SCHEMA_MODES_DIFFER_CACHE.get(model)
    if cached is not None:
        return cached
    validation_schema = model.model_json_schema(
        ref_template="#/components/schemas/{model}",
        mode="validation",
    )
    serialization_schema = model.model_json_schema(
        ref_template="#/components/schemas/{model}",
        mode="serialization",
    )
    result = _strip_schema_title_copy(validation_schema) != _strip_schema_title_copy(serialization_schema)
    _MODEL_SCHEMA_MODES_DIFFER_CACHE[model] = result
    return result


def _model_has_readonly_serialization_field(model: Any) -> bool:
    if not hasattr(model, "model_json_schema"):
        return False
    cached = _MODEL_READONLY_SERIALIZATION_FIELD_CACHE.get(model)
    if cached is not None:
        return cached
    validation_schema = model.model_json_schema(mode="validation")
    serialization_schema = model.model_json_schema(mode="serialization")
    validation_properties = validation_schema.get("properties", {})
    serialization_properties = serialization_schema.get("properties", {})
    result = any(
        isinstance(schema, dict)
        and schema.get("readOnly") is True
        and name not in validation_properties
        for name, schema in serialization_properties.items()
    )
    _MODEL_READONLY_SERIALIZATION_FIELD_CACHE[model] = result
    return result


def _strip_schema_title_copy(schema: Any) -> Any:
    value = copy.deepcopy(schema)
    if isinstance(value, dict):
        value.pop("title", None)
        for item in value.values():
            _strip_schema_titles(item)
    return value


def _strip_schema_titles(value: Any) -> None:
    if isinstance(value, dict):
        value.pop("title", None)
        for item in value.values():
            _strip_schema_titles(item)
    elif isinstance(value, list):
        for item in value:
            _strip_schema_titles(item)


def _normalize_openapi31_schema(schema: Any) -> None:
    if isinstance(schema, dict):
        if schema.get("type") == "string" and schema.get("format") in {"binary", "base64url"}:
            schema.pop("format", None)
            schema.setdefault("contentEncoding", "base64")
            schema.setdefault("contentMediaType", "application/octet-stream")
        for value in schema.values():
            _normalize_openapi31_schema(value)
    elif isinstance(schema, list):
        for item in schema:
            _normalize_openapi31_schema(item)


def _trim_formfeed_descriptions(value: Any) -> None:
    if isinstance(value, dict):
        description = value.get("description")
        if isinstance(description, str) and "\f" in description:
            value["description"] = description.split("\f", 1)[0]
        for item in value.values():
            _trim_formfeed_descriptions(item)
    elif isinstance(value, list):
        for item in value:
            _trim_formfeed_descriptions(item)


def _strip_none_defaults(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: _strip_none_defaults(item)
            for key, item in value.items()
            if not (key == "default" and item is None)
        }
    if isinstance(value, list):
        return [_strip_none_defaults(item) for item in value]
    return value


def _apply_param_schema(schema: dict[str, Any], param: Param) -> None:
    if getattr(param, "title", None) is not None:
        schema["title"] = str(getattr(param, "title"))
    if getattr(param, "description", None) is not None:
        schema["description"] = str(getattr(param, "description"))
    if getattr(param, "format", None) is not None:
        schema["format"] = str(getattr(param, "format"))
    if getattr(param, "deprecated", None) is not None:
        schema["deprecated"] = bool(getattr(param, "deprecated"))
    if getattr(param, "examples", None) is not None:
        schema["examples"] = getattr(param, "examples")
    constrained_schema = _constraint_schema_target(schema)
    if param.min_length is not None:
        constrained_schema["minLength"] = param.min_length
    if param.max_length is not None:
        constrained_schema["maxLength"] = param.max_length
    pattern = getattr(param, "pattern", None) or getattr(param, "regex", None)
    if pattern is not None:
        constrained_schema["pattern"] = str(pattern)
    if param.gt is not None:
        constrained_schema["exclusiveMinimum"] = param.gt
    if param.ge is not None:
        constrained_schema["minimum"] = param.ge
    if param.lt is not None:
        constrained_schema["exclusiveMaximum"] = param.lt
    if param.le is not None:
        constrained_schema["maximum"] = param.le


def _constraint_schema_target(schema: dict[str, Any]) -> dict[str, Any]:
    any_of = schema.get("anyOf")
    if isinstance(any_of, list) and any_of and isinstance(any_of[0], dict):
        return any_of[0]
    return schema


def _required(default: object) -> bool:
    if isinstance(default, Param):
        return default.required
    return default is inspect.Signature.empty


def _param_name(name: str, default: object) -> str:
    if isinstance(default, Param) and getattr(default, "validation_alias", None):
        return str(default.validation_alias)
    if isinstance(default, Param) and getattr(default, "alias", None):
        return str(default.alias)
    return name


def _field_param_name(name: str, field: Any) -> str:
    validation_alias = getattr(field, "validation_alias", None)
    if isinstance(validation_alias, str):
        return validation_alias
    if field.alias:
        return str(field.alias)
    return name


def _model_field_openapi_name(name: str, field: Any, param_in: str, default: object) -> str:
    param_name = _field_param_name(name, field)
    if param_name != name:
        return param_name
    if param_in == "header" and isinstance(default, HeaderParam):
        return _openapi_param_name(name, param_name, default, param_in)
    return param_name


def _summary(endpoint: Callable[..., Any]) -> str:
    return endpoint.__name__.replace("_", " ").title()


def _docstring_description(endpoint: Callable[..., Any]) -> str | None:
    doc = inspect.getdoc(endpoint)
    if not doc:
        return None
    return doc.split("\f", 1)[0].strip()


def _openapi_tags(tags: list[Any]) -> list[Any]:
    return [tag.value if hasattr(tag, "value") else tag for tag in tags]


def _operation_id(route: Route, method: str) -> str:
    if route.operation_id:
        return route.operation_id
    if route.generate_unique_id_function is not None:
        return str(route.generate_unique_id_function(route))
    openapi_path = _openapi_path(route.path)
    path_part = openapi_path.strip("/")
    path_part = path_part.replace("{$request", "{_$request")
    path_part = path_part.replace("$", "")
    path_part = re.sub(r"\W", "_", path_part)
    if openapi_path.endswith("/") and openapi_path != "/":
        path_part += "_"
    return f"{route.endpoint.__name__}_{path_part}_{method.lower()}"


def _response_title(route: Route, method: str, *, status_code: str | None = None) -> str:
    if route.generate_unique_id_function is not None:
        title = f"Response {_title(_operation_id(route, method))}"
    else:
        title = f"Response {_summary(route.endpoint)} {_path_title(route.path)} {method.title()}"
    if status_code is not None:
        return title.replace("Response ", f"Response {status_code} ", 1)
    return title


def _openapi_path(path: str) -> str:
    return re.sub(r"{([^}:]+):[^}]+}", r"{\1}", path)


def _title(name: str) -> str:
    if "-" in name:
        return "-".join(part.replace("_", " ").title() for part in name.split("-"))
    return name.replace("_", " ").title()


def _allows_none(annotation: object) -> bool:
    if get_origin(annotation) is Annotated:
        args = get_args(annotation)
        return bool(args and _allows_none(args[0]))
    return type(None) in get_args(annotation)


def _unwrap_optional(annotation: object) -> object:
    origin = get_origin(annotation)
    if origin not in (types.UnionType, Union):
        return annotation
    args = [arg for arg in get_args(annotation) if arg is not type(None)]
    if len(args) == 1:
        return args[0]
    return annotation


def _response_schema(route: Route, method: str, components: dict[str, Any]) -> dict[str, Any]:
    if route.response_model is not None:
        return _schema_for_model_type(route.response_model, route, method, components)
    media_type = _response_media_type(route.response_class)
    if media_type is not None and issubclass(route.response_class, StreamingResponse):
        return {"type": "string"}
    if media_type is not None and media_type.startswith("text/"):
        return {"type": "string"}
    return {}


def _response_content(route: Route, method: str, components: dict[str, Any]) -> dict[str, Any] | None:
    stream_item_model = _route_stream_item_model(route)
    if route.response_class is JSONResponse and _has_bare_stream_return(route):
        return {
            "application/jsonl": {
                "itemSchema": _stream_item_schema(stream_item_model, route, method, components),
            }
        }
    media_type = _response_media_type(route.response_class)
    if media_type is None:
        return None
    if media_type == "text/event-stream":
        return {
            media_type: {
                "itemSchema": _sse_item_schema(stream_item_model, route, method, components),
            }
        }
    return {media_type: {"schema": _response_schema(route, method, components)}}


def _route_stream_item_model(route: Route) -> Any:
    annotation = inspect.get_annotations(route.endpoint, eval_str=True).get(
        "return",
        inspect.Signature.empty,
    )
    annotation = _unwrap_type_alias(annotation)
    if not _is_bare_stream_annotation(annotation):
        return None
    args = get_args(annotation)
    if not args or args[0] is Any:
        return None
    return _unwrap_type_alias(args[0])


def _has_bare_stream_return(route: Route) -> bool:
    if inspect.isgeneratorfunction(route.endpoint) or inspect.isasyncgenfunction(route.endpoint):
        return True
    annotation = inspect.get_annotations(route.endpoint, eval_str=True).get(
        "return",
        inspect.Signature.empty,
    )
    return _is_bare_stream_annotation(_unwrap_type_alias(annotation))


def _is_bare_stream_annotation(annotation: object) -> bool:
    origin = get_origin(annotation)
    return annotation in (ABCIterable, ABCAsyncIterable) or origin in (ABCIterable, ABCAsyncIterable)


def _stream_item_schema(
    item_model: Any,
    route: Route,
    method: str,
    components: dict[str, Any],
) -> dict[str, Any]:
    if item_model is None:
        return {}
    return _schema_for_model_type(item_model, route, method, components, include_title=False)


def _sse_item_schema(
    item_model: Any,
    route: Route,
    method: str,
    components: dict[str, Any],
) -> dict[str, Any]:
    schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "data": {"type": "string"},
            "event": {"type": "string"},
            "id": {"type": "string"},
            "retry": {"type": "integer", "minimum": 0},
        },
    }
    if item_model is None or getattr(item_model, "__name__", None) == "ServerSentEvent":
        return schema
    content_schema = _stream_item_schema(item_model, route, method, components)
    if content_schema:
        schema["properties"]["data"] = {
            "type": "string",
            "contentMediaType": "application/json",
            "contentSchema": content_schema,
        }
        schema["required"] = ["data"]
    return schema


def _schema_for_model_type(
    model_type: Any,
    route: Route,
    method: str,
    components: dict[str, Any],
    title: str | None = None,
    include_title: bool = True,
) -> dict[str, Any]:
    title = title or _response_title(route, method)
    effective_title = title if include_title else None
    if model_type is type(None):
        schema = {"type": "null"}
        if effective_title:
            schema = {"title": effective_title, **schema}
        return schema
    if model_type is list:
        schema = {
            "type": "array",
            "items": {},
        }
        if effective_title:
            schema = {"title": effective_title, **schema}
        return schema
    origin = get_origin(model_type)
    if origin in (types.UnionType, Union):
        schema = {
            "anyOf": [
                _schema_for_model_type(arg, route, method, components, include_title=False)
                for arg in get_args(model_type)
            ],
        }
        if effective_title:
            schema = {"title": effective_title, **schema}
        return schema
    if origin in (list, set, frozenset, tuple):
        args = get_args(model_type)
        item_type = args[0] if args and args[0] is not Ellipsis else Any
        schema = {
            "type": "array",
            "items": _schema_for_model_type(item_type, route, method, components, include_title=False),
        }
        if origin in (set, frozenset):
            schema["uniqueItems"] = True
        if effective_title:
            schema = {"title": effective_title, **schema}
        return schema
    if hasattr(model_type, "model_json_schema") or is_dataclass(model_type):
        suffix = _schema_component_suffix(model_type, "serialization", route, components)
        schema_mode = _response_schema_mode(model_type, route, suffix)
        _collect_model_schema(
            model_type,
            components,
            mode=schema_mode,
            name_suffix=suffix,
        )
        return {"$ref": f"#/components/schemas/{model_type.__name__}{suffix}"}
    schema = _schema_for_annotation(model_type)
    if effective_title and schema:
        schema = {"title": effective_title, **schema}
    return schema


def _path_title(path: str) -> str:
    openapi_path = _openapi_path(path)
    title = (
        openapi_path.strip("/")
        .replace("/", " ")
        .replace("{", " ")
        .replace("}", " ")
        .replace("_", " ")
        .replace("-", " ")
        .title()
    )
    if openapi_path.endswith("/") and openapi_path != "/":
        return title + " "
    return title


def _status_allows_body(status_code: int) -> bool:
    return status_code not in {204, 304}


def _response_media_type(response_class: type[Response]) -> str | None:
    if response_class is Response:
        return None
    media_type = getattr(response_class, "media_type", None)
    if media_type is None:
        return None
    return media_type.split(";", 1)[0]


def _is_json_content_type(content_type: str) -> bool:
    media_type = content_type.split(";", 1)[0].strip().lower()
    return media_type == "application/json" or media_type.endswith("+json")


def _is_urlencoded_form_content_type(content_type: str) -> bool:
    media_type = content_type.split(";", 1)[0].strip().lower()
    return media_type == "application/x-www-form-urlencoded"


def _urlencoded_form_body(body: str) -> dict[str, Any]:
    parsed = core.parse_query_string(body)
    return {key: values if len(values) != 1 else values[0] for key, values in parsed.items()}


def _json_decode_response(exc: json.JSONDecodeError) -> JSONResponse:
    return JSONResponse(
        {
            "detail": [
                {
                    "type": "json_invalid",
                    "loc": ["body", exc.pos],
                    "msg": "JSON decode error",
                    "input": {},
                    "ctx": {"error": exc.msg},
                }
            ]
        },
        status_code=422,
    )


def _is_duplicate_slash_schema_route(route: Route, routes: list[Route]) -> bool:
    if route.path == "/" or not route.path.endswith("/"):
        return False
    sibling_path = route.path.rstrip("/") or "/"
    return any(
        other is not route
        and other.path == sibling_path
        and other.endpoint is route.endpoint
        and other.methods == route.methods
        for other in routes
    )


async def _read_asgi_body(receive: Any) -> bytes:
    body = bytearray()
    while True:
        message = await receive()
        if message.get("type") != "http.request":
            break
        body.extend(message.get("body", b""))
        if not message.get("more_body", False):
            break
    return bytes(body)


def _http_asgi_scope(
    request: Request,
    *,
    method: str,
    path: str,
    query_string: str,
    root_path: str,
    scheme: str,
    client: tuple[str, int] | None,
) -> dict[str, Any]:
    headers = request.headers or Headers()
    host = headers.get("host", "testserver")
    return {
        "type": "http",
        "http_version": "1.1",
        "method": method,
        "path": path,
        "raw_path": path.encode("latin-1"),
        "query_string": query_string.encode("latin-1"),
        "headers": [
            (str(key).lower().encode("latin-1"), str(value).encode("latin-1"))
            for key, value in headers.raw_items()
        ],
        "scheme": scheme,
        "root_path": root_path,
        "client": client or ("", 0),
        "server": _asgi_server(host, scheme),
        "app": request.app,
        "state": (request.scope or {}).get("state", {}),
    }


def _asgi_server(host: str, scheme: str) -> tuple[str, int]:
    if ":" in host:
        hostname, port = host.rsplit(":", 1)
        try:
            return hostname, int(port)
        except ValueError:
            return host, 443 if scheme == "https" else 80
    return host, 443 if scheme == "https" else 80


def _request_body_bytes(request: Request) -> bytes:
    if request.raw_body is not None:
        return request.raw_body
    if request.json_body is not None:
        return json.dumps(request.json_body, separators=(",", ":")).encode("utf-8")
    if isinstance(request.form_body, dict):
        return b"x" * _form_body_size(request.form_body)
    return b""


def _run_asgi_awaitable(value: Any) -> Any:
    if not inspect.isawaitable(value):
        return value
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(value)
    result: dict[str, Any] = {}
    error: dict[str, BaseException] = {}
    caller_context = contextvars.copy_context()

    def run() -> None:
        try:
            result["value"] = caller_context.run(asyncio.run, value)
        except BaseException as exc:
            error["error"] = exc

    worker = threading.Thread(target=run, daemon=True)
    worker.start()
    worker.join()
    if error:
        raise error["error"]
    return result.get("value")


async def _send_response_asgi(response: Response, send: Any) -> None:
    await send(
        {
            "type": "http.response.start",
            "status": response.status_code,
            "headers": [
                (key.encode("latin-1"), value.encode("latin-1"))
                for key, value in response.headers.raw_items()
            ],
        }
    )
    if isinstance(response, StreamingResponse):
        await _send_streaming_asgi_body(response, send)
        return
    await send({"type": "http.response.body", "body": response.body})


def _response_from_asgi_messages(messages: list[dict[str, Any]]) -> Response:
    status_code = 500
    headers: list[tuple[str, str]] = []
    body = bytearray()
    for message in messages:
        message_type = message.get("type")
        if message_type == "http.response.start":
            status_code = int(message.get("status", status_code))
            headers = [
                (
                    key.decode("latin-1") if isinstance(key, bytes) else str(key),
                    value.decode("latin-1") if isinstance(value, bytes) else str(value),
                )
                for key, value in message.get("headers", [])
            ]
        elif message_type == "http.response.body":
            chunk = message.get("body", b"")
            body.extend(chunk if isinstance(chunk, bytes) else str(chunk).encode("utf-8"))
    return Response(bytes(body), status_code=status_code, media_type=None, headers=headers)


async def _send_streaming_asgi_body(response: StreamingResponse, send: Any) -> None:
    async def send_chunk(item: Any) -> None:
        chunk = item if isinstance(item, bytes) else str(item).encode("utf-8")
        await send({"type": "http.response.body", "body": chunk, "more_body": True})
        await asyncio.sleep(0)

    content = response.content
    if isinstance(content, (bytes, str)) or content is None:
        await send({"type": "http.response.body", "body": response.body})
        return
    if inspect.isasyncgen(content):
        async for item in content:
            await send_chunk(item)
    elif inspect.isawaitable(content):
        await send_chunk(await content)
    else:
        for item in content:
            await send_chunk(item)
    await send({"type": "http.response.body", "body": b"", "more_body": False})


class State:
    pass
