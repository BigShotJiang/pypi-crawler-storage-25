from __future__ import annotations

from typing import Any

from .exceptions import HTTPException, RequestValidationError, WebSocketRequestValidationError
from .responses import JSONResponse, Response


async def http_exception_handler(request: Any, exc: HTTPException) -> Response:
    headers = exc.headers or {}
    if exc.status_code in {204, 304}:
        return Response(b"", status_code=exc.status_code, media_type=None, headers=headers)
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=headers)


async def request_validation_exception_handler(
    request: Any,
    exc: RequestValidationError,
) -> JSONResponse:
    return JSONResponse({"detail": exc.errors()}, status_code=422)


async def websocket_request_validation_exception_handler(
    websocket: Any,
    exc: WebSocketRequestValidationError,
) -> None:
    await websocket.close(code=1008, reason=str(exc.errors()))
