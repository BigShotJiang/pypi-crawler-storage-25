from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .responses import HTMLResponse


class Jinja2Templates:
    def __init__(self, directory: str) -> None:
        self.directory = Path(directory)

    def TemplateResponse(
        self,
        *,
        request: Any,
        name: str,
        context: dict[str, Any] | None = None,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        media_type: str | None = None,
        **_: Any,
    ) -> HTMLResponse:
        data = dict(context or {})
        data.setdefault("request", request)
        template = (self.directory / name).read_text()
        rendered = _render_template(template, request, data)
        return HTMLResponse(
            rendered,
            status_code=status_code,
            headers=headers,
            media_type=media_type,
        )


def _render_template(template: str, request: Any, context: dict[str, Any]) -> str:
    def replace_url(match: re.Match[str]) -> str:
        route_name = match.group("name")
        args = match.group("args")
        kwargs = _parse_template_kwargs(args, context)
        return _url_for(request, route_name, kwargs)

    rendered = re.sub(
        r"\{\{\s*url_for\('(?P<name>[^']+)'\s*,\s*(?P<args>[^}]*)\)\s*\}\}",
        replace_url,
        template,
    )

    def replace_value(match: re.Match[str]) -> str:
        key = match.group("key")
        return str(context.get(key, ""))

    return re.sub(r"\{\{\s*(?P<key>[A-Za-z_][A-Za-z0-9_]*)\s*\}\}", replace_value, rendered)


def _parse_template_kwargs(text: str, context: dict[str, Any]) -> dict[str, Any]:
    kwargs: dict[str, Any] = {}
    for item in text.split(","):
        if "=" not in item:
            continue
        key, value = item.split("=", 1)
        key = key.strip()
        value = value.strip()
        if value.startswith("'") and value.endswith("'"):
            kwargs[key] = value[1:-1]
        else:
            kwargs[key] = context.get(value, value)
    return kwargs


def _url_for(request: Any, route_name: str, kwargs: dict[str, Any]) -> str:
    app = getattr(request, "app", None)
    if route_name == "static":
        path = str(kwargs.get("path", ""))
        prefix = _mount_prefix(app, route_name)
        return f"{prefix}{path}"
    route_path = _route_path(app, route_name)
    for key, value in kwargs.items():
        route_path = route_path.replace("{" + key + "}", str(value))
    scheme = (getattr(request, "scope", {}) or {}).get("scheme", "http")
    host = (getattr(request, "headers", {}) or {}).get("host", "testserver")
    return f"{scheme}://{host}{route_path}"


def _mount_prefix(app: Any, name: str) -> str:
    for prefix, _mounted_app, mount_name in getattr(app, "mounts", []):
        if mount_name == name:
            return prefix
    return f"/{name}"


def _route_path(app: Any, name: str) -> str:
    for route in getattr(app, "routes", []):
        if getattr(route, "name", None) == name:
            return route.path
    return f"/{name}"
