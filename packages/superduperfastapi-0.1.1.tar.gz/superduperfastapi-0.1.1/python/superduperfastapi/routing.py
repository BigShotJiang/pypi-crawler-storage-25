from __future__ import annotations

import asyncio
import ast
import copy
import inspect
import json
import math
import queue
import re
import threading
import types
from collections.abc import AsyncIterable as ABCAsyncIterable
from collections.abc import Iterable as ABCIterable
from dataclasses import dataclass, field, is_dataclass
from enum import Enum, IntEnum
from typing import Annotated, Any, Callable, Union, get_args, get_origin

from ._core import core
from .background import BackgroundTasks
from .datastructures import UploadFile
from .dependencies.utils import ensure_multipart_is_installed
from .exceptions import FastAPIError, HTTPException, PydanticV1NotSupportedError, RequestValidationError, ResponseValidationError, WebSocketException, WebSocketRequestValidationError
from .params import BodyParam, CookieParam, DependsParam, FileParam, FormParam, HeaderParam, Param, PathParam, QueryParam, _MISSING
from .responses import FileResponse, Headers, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response, StreamingResponse
from ._validation import ValidationError, core_schema_adapter

RESPONSE_MODEL_UNSET = object()
_PING_INTERVAL = 15.0


@dataclass
class DependencyFinalizer:
    finalizer: Any
    scope: str


class HTTPConnection:
    def __init__(self, *, app: Any = None, scope: dict[str, Any] | None = None) -> None:
        self.app = app
        self.scope = scope or {}

    @property
    def query_params(self) -> dict[str, list[str]]:
        return {}

    @property
    def state(self) -> Any:
        return ScopeState(self.scope.setdefault("state", {}))


class ScopeState:
    def __init__(self, state: dict[str, Any]) -> None:
        object.__setattr__(self, "_state", state)

    def __getattr__(self, name: str) -> Any:
        try:
            return self._state[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def __setattr__(self, name: str, value: Any) -> None:
        self._state[name] = value


@dataclass
class Request(HTTPConnection):
    method: str
    path: str
    query_string: str = ""
    raw_body: bytes | None = None
    json_body: Any = None
    form_body: dict[str, Any] | None = None
    headers: Headers | None = None
    cookies: dict[str, str] | None = None
    app: Any = None
    scope: dict[str, Any] | None = None
    background_tasks: BackgroundTasks | None = None
    dependency_cache: dict[tuple[Any, tuple[str, ...]], Any] | None = None
    dependency_finalizers: list[DependencyFinalizer] | None = None
    dependency_loop: asyncio.AbstractEventLoop | None = None
    body_param_names: set[str] | None = None
    raise_server_exceptions: bool = True
    defer_response_cleanup: bool = False

    def __init__(
        self,
        method: str | dict[str, Any],
        path: str | Any = "",
        query_string: str = "",
        raw_body: bytes | None = None,
        json_body: Any = None,
        form_body: dict[str, Any] | None = None,
        headers: Headers | None = None,
        cookies: dict[str, str] | None = None,
        app: Any = None,
        scope: dict[str, Any] | None = None,
        background_tasks: BackgroundTasks | None = None,
        dependency_cache: dict[tuple[Any, tuple[str, ...]], Any] | None = None,
        dependency_finalizers: list[DependencyFinalizer] | None = None,
        dependency_loop: asyncio.AbstractEventLoop | None = None,
        body_param_names: set[str] | None = None,
        raise_server_exceptions: bool = True,
        defer_response_cleanup: bool = False,
    ) -> None:
        if isinstance(method, dict):
            scope = method
            receive = path
            method = scope.get("method", "GET")
            path = scope.get("path", "")
            query_value = scope.get("query_string", b"")
            query_string = query_value.decode("latin-1") if isinstance(query_value, bytes) else str(query_value)
            raw_body = scope.get("raw_body")
            json_body = scope.get("json_body")
            form_body = scope.get("form_body")
            headers = scope.get("headers_obj")
            cookies = scope.get("cookies")
            app = scope.get("app")
            background_tasks = scope.get("background_tasks")
            dependency_cache = scope.get("dependency_cache")
            dependency_finalizers = scope.get("dependency_finalizers")
            dependency_loop = scope.get("dependency_loop")
            body_param_names = scope.get("body_param_names")
            raise_server_exceptions = scope.get("raise_server_exceptions", True)
            defer_response_cleanup = scope.get("defer_response_cleanup", False)
        else:
            receive = None
            scope = scope or {}
        self.method = str(method)
        self.path = str(path)
        self.query_string = query_string
        self.raw_body = raw_body
        self.json_body = json_body
        self.form_body = form_body
        self.headers = headers
        self.cookies = cookies
        self.app = app
        self.scope = scope
        self.background_tasks = background_tasks
        self.dependency_cache = dependency_cache
        self.dependency_finalizers = dependency_finalizers
        self.dependency_loop = dependency_loop
        self.body_param_names = body_param_names
        self.raise_server_exceptions = raise_server_exceptions
        self.defer_response_cleanup = defer_response_cleanup
        self.receive = receive

    @property
    def query_params(self) -> dict[str, list[str]]:
        return core.parse_query_string(self.query_string)

    @property
    def url(self) -> Any:
        return types.SimpleNamespace(path=self.path)

    @property
    def client(self) -> Any:
        client = (self.scope or {}).get("client") or ("", 0)
        return types.SimpleNamespace(host=client[0], port=client[1])

    async def body(self) -> bytes:
        if self.raw_body is not None:
            return self.raw_body
        if self.json_body is None:
            return b""
        if isinstance(self.json_body, bytes):
            return self.json_body
        if isinstance(self.json_body, str):
            return self.json_body.encode("utf-8")
        return json.dumps(self.json_body).encode("utf-8")


class WebSocketDisconnect(Exception):
    def __init__(self, code: int = 1000, reason: str = "") -> None:
        super().__init__(code, reason)
        self.code = code
        self.reason = reason


class WebSocket(HTTPConnection):
    def __init__(
        self,
        scope: dict[str, Any] | None = None,
        receive: Any = None,
        send: Any = None,
        *,
        app: Any = None,
        path: str = "",
        route: Any = None,
        query_string: str = "",
        headers: Headers | dict[str, str] | None = None,
        close_state: dict[str, Any] | None = None,
    ) -> None:
        if scope is not None:
            app = scope.get("app", app)
            path = scope.get("path", path)
            route = scope.get("route", route)
            raw_query = scope.get("query_string", b"")
            query_string = raw_query.decode("latin-1") if isinstance(raw_query, bytes) else str(raw_query)
            raw_headers = scope.get("headers", [])
            headers = Headers(
                [
                    (
                        key.decode("latin-1") if isinstance(key, bytes) else str(key),
                        value.decode("latin-1") if isinstance(value, bytes) else str(value),
                    )
                    for key, value in raw_headers
                ]
            )
        super().__init__(app=app, scope={**(scope or {}), "route": route})
        self.path = path
        self.query_string = query_string
        self.headers = headers if isinstance(headers, Headers) else Headers(headers)
        self.cookies = core.parse_cookie_header(self.headers.get("cookie", ""))
        self._messages: list[Any] = []
        self.dependency_cache: dict[tuple[Any, tuple[str, ...], str], Any] = {}
        self.dependency_finalizers: list[DependencyFinalizer] = []
        self.dependency_loop: asyncio.AbstractEventLoop | None = None
        self.background_tasks: BackgroundTasks | None = None
        self.body_param_names: set[str] | None = set()
        self.raise_server_exceptions = True
        self.defer_response_cleanup = False
        self._send = send
        self._close_state = close_state if close_state is not None else {}
        self._incoming_messages: queue.Queue[Any] = queue.Queue()
        self._outgoing_messages: queue.Queue[Any] = queue.Queue()
        self._accepted = threading.Event()
        self._worker: threading.Thread | None = None
        self._worker_error: dict[str, BaseException] | None = None

    @property
    def query_params(self) -> dict[str, list[str]]:
        return core.parse_query_string(self.query_string)

    async def accept(self) -> None:
        self._accepted.set()
        return None

    async def send_text(self, data: str) -> None:
        self._messages.append(data)
        self._outgoing_messages.put(data)

    async def send_json(self, data: Any) -> None:
        self._messages.append(data)
        self._outgoing_messages.put(data)

    async def close(self, code: int = 1000, reason: str = "") -> None:
        self._close_state["code"] = code
        self._close_state["reason"] = reason
        if self._send is not None:
            await self._send({"type": "websocket.close", "code": code, "reason": reason})

    async def receive_json(self) -> Any:
        return json.loads(await self.receive_text())

    async def receive_text(self) -> str:
        message = self._incoming_messages.get()
        if isinstance(message, WebSocketDisconnect):
            raise message
        return str(message)

    def _client_send_text(self, data: str) -> None:
        self._incoming_messages.put(data)

    def _client_send_json(self, data: Any) -> None:
        self._incoming_messages.put(json.dumps(data))

    def _client_receive_text(self, timeout: float = 1.0) -> str:
        return str(self._client_receive_raw(timeout=timeout))

    def _client_receive_raw(self, timeout: float = 1.0) -> Any:
        try:
            return self._outgoing_messages.get(timeout=timeout)
        except queue.Empty:
            if self._worker_error and "error" in self._worker_error:
                raise self._worker_error["error"]
            raise WebSocketDisconnect(
                self._close_state.get("code", 1000),
                self._close_state.get("reason", ""),
            )

    def _client_receive_json(self) -> Any:
        message = self._client_receive_raw()
        if isinstance(message, str):
            return json.loads(message)
        return message

    def _client_close(self, code: int = 1000, reason: str = "") -> None:
        self._close_state["code"] = code
        self._close_state["reason"] = reason
        self._incoming_messages.put(WebSocketDisconnect(code, reason))
        if self._worker is not None:
            self._worker.join(timeout=1.0)


@dataclass
class Route:
    path: str
    endpoint: Callable[..., Any]
    methods: set[str]
    status_code: int
    dependencies: list[DependsParam]
    response_class: type[Response]
    responses: dict[int | str, dict[str, Any]]
    response_model: Any
    response_model_by_alias: bool
    response_model_include: Any
    response_model_exclude: Any
    response_model_exclude_unset: bool
    response_model_exclude_defaults: bool
    response_model_exclude_none: bool
    tags: list[str]
    callbacks: list["Route"]
    deprecated: bool | None
    summary: str | None = None
    description: str | None = None
    response_description: str | None = None
    openapi_extra: dict[str, Any] | None = None
    operation_id: str | None = None
    include_in_schema: bool = True
    generate_unique_id_function: Callable[[Any], str] | None = None
    generate_unique_id_explicit: bool = False
    strict_content_type: bool | None = None
    separate_input_output_schemas: bool = True
    response_class_explicit: bool = False

    @property
    def name(self) -> str:
        return self.endpoint.__name__

    def match(self, method: str, path: str) -> dict[str, str] | None:
        if method.upper() not in self.methods:
            return None
        if not _same_trailing_slash(self.path, path):
            return None
        return core.match_route(self.path, path)

    def path_matches(self, path: str) -> bool:
        if not _same_trailing_slash(self.path, path):
            return False
        return core.match_route(self.path, path) is not None

    def rust_fast_path_spec(
        self,
        dependency_overrides: dict[Any, Callable[..., Any]] | None = None,
    ) -> dict[str, Any] | None:
        if self.response_class not in {
            JSONResponse,
            HTMLResponse,
            PlainTextResponse,
            RedirectResponse,
            StreamingResponse,
            FileResponse,
        }:
            return None
        if self.response_class in {
            HTMLResponse,
            PlainTextResponse,
            RedirectResponse,
            StreamingResponse,
            FileResponse,
        } and self.response_model is not None:
            return None

        signature = inspect.signature(self.endpoint)
        static_body = None
        if self.response_class is JSONResponse and not signature.parameters and self.response_model is None:
            static_body = _rust_static_json_body(self.endpoint)
        hints = _get_annotations(self.endpoint)
        path_params = set(re.findall(r"{([^}:]+)(?::[^}]+)?}", self.path))
        response_adapter = core_schema_adapter(self.response_model) if self.response_model is not None else None
        params: list[dict[str, Any]] = []
        body_param: dict[str, Any] | None = None
        dependencies: list[dict[str, Any]] = []
        response_param: str | None = None
        request_param: str | None = None
        background_tasks_param: str | None = None
        dependency_overrides = dependency_overrides or {}
        for dependency in self.dependencies:
            dependency_spec = _rust_fast_path_dependency_spec(
                None,
                dependency,
                path_params,
                dependency_overrides,
            )
            if dependency_spec is None:
                return None
            dependencies.append(dependency_spec)
        for name, parameter in signature.parameters.items():
            annotation = hints.get(name, Any)
            default = parameter.default
            annotation, annotated_default = _unpack_annotated(annotation)
            if annotated_default is not inspect.Signature.empty:
                _apply_signature_default(annotated_default, default)
                default = annotated_default
            if isinstance(default, DependsParam):
                dependency = _effective_dependency(default, annotation)
                dependency_spec = _rust_fast_path_dependency_spec(
                    name,
                    dependency,
                    path_params,
                    dependency_overrides,
                )
                if dependency_spec is None:
                    return None
                dependencies.append(dependency_spec)
                continue
            if annotation is Response:
                if response_param is not None:
                    return None
                response_param = name
                continue
            if annotation is Request:
                if request_param is not None:
                    return None
                request_param = name
                continue
            if annotation is BackgroundTasks:
                if background_tasks_param is not None:
                    return None
                background_tasks_param = name
                continue
            source = _param_source(name, default, annotation, {key: "" for key in path_params})
            if source == "body":
                if body_param is not None or not _is_body_annotation(annotation):
                    return None
                if isinstance(default, BodyParam) and getattr(default, "embed", False):
                    return None
                adapter = core_schema_adapter(annotation)
                body_param = {
                    "name": name,
                    "adapter": adapter,
                    "validator": adapter.validator,
                }
                continue
            param_spec = _rust_fast_path_param_spec(
                name,
                default,
                annotation,
                source,
            )
            if param_spec is None:
                return None
            params.append(param_spec)
        return {
            "path": self.path,
            "methods": sorted(self.methods),
            "endpoint": self.endpoint,
            "endpoint_is_async": inspect.iscoroutinefunction(self.endpoint),
            "status_code": self.status_code,
            "params": params,
            "dependencies": dependencies,
            "response_param": response_param,
            "response_state_class": Response,
            "request_param": request_param,
            "request_class": Request,
            "headers_class": Headers,
            "background_tasks_param": background_tasks_param,
            "background_tasks_class": BackgroundTasks,
            "http_exception_class": HTTPException,
            "response_class": self.response_class,
            "body_param": body_param,
            "response_adapter": response_adapter,
            "response_validator": response_adapter.validator if response_adapter is not None else None,
            "response_serializer": response_adapter.serializer if response_adapter is not None else None,
            "response_validate_kwargs": {"from_attributes": True} if response_adapter is not None else None,
            "response_dump_kwargs": (
                _response_model_dump_kwargs(
                    by_alias=self.response_model_by_alias,
                    include=self.response_model_include,
                    exclude=self.response_model_exclude,
                    exclude_unset=self.response_model_exclude_unset,
                    exclude_defaults=self.response_model_exclude_defaults,
                    exclude_none=self.response_model_exclude_none,
                )
                if response_adapter is not None
                else None
            ),
            "response_model_by_alias": self.response_model_by_alias,
            "response_model_include": self.response_model_include,
            "response_model_exclude": self.response_model_exclude,
            "response_model_exclude_unset": self.response_model_exclude_unset,
            "response_model_exclude_defaults": self.response_model_exclude_defaults,
            "response_model_exclude_none": self.response_model_exclude_none,
            "response_kind": (
                "plain_text"
                if self.response_class is PlainTextResponse
                else "html"
                if self.response_class is HTMLResponse
                else "redirect"
                if self.response_class is RedirectResponse
                else "streaming"
                if self.response_class is StreamingResponse
                else "file"
                if self.response_class is FileResponse
                else "json"
            ),
            "static_body": static_body,
        }

    def handle(self, request: Request, path_params: dict[str, str]) -> Response:
        request.scope = {**(request.scope or {}), "route": self}
        _parse_request_body_if_needed(self, request)
        _maybe_parse_lax_json_body(self, request)
        if request.dependency_cache is None:
            request.dependency_cache = {}
        if request.dependency_finalizers is None:
            request.dependency_finalizers = []
        request.body_param_names = _collect_route_body_param_names(self, request)
        response_state = Response(status_code=self.status_code)
        if request.background_tasks is None:
            request.background_tasks = BackgroundTasks()
        errors: list[dict[str, Any]] = []
        for dependency in self.dependencies:
            _, dependency_errors = _solve_dependency(dependency, request, path_params, response_state)
            errors.extend(dependency_errors)
        values, argument_errors = _solve_arguments(self.endpoint, request, path_params, response_state)
        errors.extend(argument_errors)
        if errors:
            validation_error = RequestValidationError(
                errors,
                body=request.json_body,
                endpoint_ctx=_endpoint_context(self, request),
            )
            finalizer_error = _finalize_dependencies(request, validation_error)
            raise finalizer_error or validation_error
        try:
            result = _run_maybe_async(self.endpoint(**values))
        except Exception as exc:
            finalizer_error = _finalize_dependencies(request, exc)
            raise finalizer_error or exc
        if isinstance(result, Response):
            if request.defer_response_cleanup:
                return result
            function_error = _finalize_dependencies(request, None, scope="function")
            if function_error is not None:
                raise function_error
            streaming_error = _prepare_response_body(result)
            if streaming_error is not None:
                finalizer_error = _finalize_dependencies(request, streaming_error)
                if request.raise_server_exceptions:
                    raise finalizer_error or streaming_error
                return result
            request.background_tasks()
            finalizer_error = _finalize_dependencies(request, None, scope="request")
            if finalizer_error is not None and request.raise_server_exceptions:
                raise finalizer_error
            return result
        if self.response_model is not None:
            if self.response_class is JSONResponse and not self.response_class_explicit:
                response = Response(
                    _serialize_response_model_json(
                        self.response_model,
                        result,
                        endpoint_ctx=_endpoint_context(self, request),
                        by_alias=self.response_model_by_alias,
                        include=self.response_model_include,
                        exclude=self.response_model_exclude,
                        exclude_unset=self.response_model_exclude_unset,
                        exclude_defaults=self.response_model_exclude_defaults,
                        exclude_none=self.response_model_exclude_none,
                    ),
                    status_code=response_state.status_code,
                    media_type=JSONResponse.media_type,
                )
                response.headers.update(response_state.headers)
                if request.defer_response_cleanup:
                    return response
                function_error = _finalize_dependencies(request, None, scope="function")
                if function_error is not None:
                    raise function_error
                request.background_tasks()
                finalizer_error = _finalize_dependencies(request, None, scope="request")
                if finalizer_error is not None and request.raise_server_exceptions:
                    raise finalizer_error
                return response
            result = _serialize_response_model(
                self.response_model,
                result,
                endpoint_ctx=_endpoint_context(self, request),
                by_alias=self.response_model_by_alias,
                include=self.response_model_include,
                exclude=self.response_model_exclude,
                exclude_unset=self.response_model_exclude_unset,
                exclude_defaults=self.response_model_exclude_defaults,
                exclude_none=self.response_model_exclude_none,
            )
        if _is_bare_stream_result(result) and self.response_class is JSONResponse:
            response = StreamingResponse(
                _json_line_stream(result, _stream_item_model(self.endpoint)),
                status_code=response_state.status_code,
                media_type="application/jsonl",
            )
            response.headers.update(response_state.headers)
            if request.defer_response_cleanup:
                return response
            function_error = _finalize_dependencies(request, None, scope="function")
            if function_error is not None:
                raise function_error
            streaming_error = _prepare_response_body(response)
            if streaming_error is not None:
                finalizer_error = _finalize_dependencies(request, streaming_error)
                if request.raise_server_exceptions:
                    raise finalizer_error or streaming_error
                return response
            request.background_tasks()
            finalizer_error = _finalize_dependencies(request, None, scope="request")
            if finalizer_error is not None and request.raise_server_exceptions:
                raise finalizer_error
            return response
        response = self.response_class(result, status_code=response_state.status_code)
        response.headers.update(response_state.headers)
        if request.defer_response_cleanup:
            return response
        function_error = _finalize_dependencies(request, None, scope="function")
        if function_error is not None:
            raise function_error
        streaming_error = _prepare_response_body(response)
        if streaming_error is not None:
            finalizer_error = _finalize_dependencies(request, streaming_error)
            if request.raise_server_exceptions:
                raise finalizer_error or streaming_error
            return response
        request.background_tasks()
        finalizer_error = _finalize_dependencies(request, None, scope="request")
        if finalizer_error is not None and request.raise_server_exceptions:
            raise finalizer_error
        return response

    def get_route_handler(self) -> Callable[[Request], Any]:
        async def route_handler(request: Request) -> Response:
            path_params = (request.scope or {}).get("path_params", {})
            return await asyncio.to_thread(self.handle, request, path_params)

        return route_handler


class APIRouter:
    def __init__(
        self,
        *,
        prefix: str = "",
        default_response_class: type[Response] = JSONResponse,
        dependencies: list[DependsParam] | None = None,
        tags: list[str] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        callbacks: list["Route"] | None = None,
        deprecated: bool | None = None,
        route_class: type[Route] = Route,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        strict_content_type: bool | None = None,
        lifespan: Callable[..., Any] | None = None,
        on_startup: list[Callable[..., Any]] | None = None,
        on_shutdown: list[Callable[..., Any]] | None = None,
        **_: Any,
    ) -> None:
        self.prefix = prefix
        self.default_response_class = default_response_class
        self.dependencies = dependencies or []
        self.tags = tags or []
        self.responses = responses or {}
        self.callbacks = callbacks or []
        self.deprecated = deprecated
        self.route_class = route_class
        self.generate_unique_id_function = generate_unique_id_function
        self.strict_content_type = strict_content_type
        self.lifespan = lifespan
        self.on_startup = list(on_startup or [])
        self.on_shutdown = list(on_shutdown or [])
        self.lifespan_contexts: list[Callable[..., Any]] = []
        self.routes: list[Route] = []
        self.websocket_routes: list[WebSocketRoute] = []

    def on_event(self, event_type: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        if event_type not in {"startup", "shutdown"}:
            raise ValueError("event_type must be 'startup' or 'shutdown'")

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            if event_type == "startup":
                self.on_startup.append(func)
            else:
                self.on_shutdown.append(func)
            return func

        return decorator

    def api_route(
        self,
        path: str,
        *,
        methods: list[str] | None = None,
        status_code: int = 200,
        dependencies: list[DependsParam] | None = None,
        response_class: type[Response] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        response_model: Any = RESPONSE_MODEL_UNSET,
        response_model_by_alias: bool = True,
        response_model_include: Any = None,
        response_model_exclude: Any = None,
        response_model_exclude_unset: bool = False,
        response_model_exclude_defaults: bool = False,
        response_model_exclude_none: bool = False,
        tags: list[str] | None = None,
        callbacks: list[Route] | None = None,
        deprecated: bool | None = None,
        summary: str | None = None,
        description: str | None = None,
        response_description: str | None = None,
        openapi_extra: dict[str, Any] | None = None,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        strict_content_type: bool | None = None,
        **_: Any,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        operation_id = _.get("operation_id")
        include_in_schema = bool(_.get("include_in_schema", True))

        def decorator(endpoint: Callable[..., Any]) -> Callable[..., Any]:
            self.add_api_route(
                path,
                endpoint,
                methods=methods,
                status_code=status_code,
                dependencies=dependencies,
                response_class=response_class,
                responses=responses,
                response_model=response_model,
                response_model_by_alias=response_model_by_alias,
                response_model_include=response_model_include,
                response_model_exclude=response_model_exclude,
                response_model_exclude_unset=response_model_exclude_unset,
                response_model_exclude_defaults=response_model_exclude_defaults,
                response_model_exclude_none=response_model_exclude_none,
                tags=tags,
                callbacks=callbacks,
                deprecated=deprecated,
                summary=summary,
                description=description,
                response_description=response_description,
                openapi_extra=openapi_extra,
                operation_id=operation_id,
                include_in_schema=include_in_schema,
                generate_unique_id_function=generate_unique_id_function,
                strict_content_type=strict_content_type,
            )
            return endpoint

        return decorator

    def route(
        self,
        path: str,
        *,
        methods: list[str] | None = None,
        **kwargs: Any,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=methods or ["GET"], **kwargs)

    def add_api_route(
        self,
        path: str,
        endpoint: Callable[..., Any],
        *,
        methods: list[str] | None = None,
        status_code: int = 200,
        dependencies: list[DependsParam] | None = None,
        response_class: type[Response] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        response_model: Any = RESPONSE_MODEL_UNSET,
        response_model_by_alias: bool = True,
        response_model_include: Any = None,
        response_model_exclude: Any = None,
        response_model_exclude_unset: bool = False,
        response_model_exclude_defaults: bool = False,
        response_model_exclude_none: bool = False,
        tags: list[str] | None = None,
        callbacks: list[Route] | None = None,
        deprecated: bool | None = None,
        summary: str | None = None,
        description: str | None = None,
        response_description: str | None = None,
        openapi_extra: dict[str, Any] | None = None,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        strict_content_type: bool | None = None,
        **_: Any,
    ) -> None:
        operation_id = _.get("operation_id")
        include_in_schema = bool(_.get("include_in_schema", True))
        route_methods = {method.upper() for method in (methods or ["GET"])}
        route_dependencies = [*self.dependencies, *(dependencies or [])]
        _validate_path_operation_params(endpoint, _join_paths(self.prefix, path))
        _validate_dependency_scopes(endpoint, route_dependencies)
        route_response_class = response_class or self.default_response_class
        route_status_code = (
            307
            if route_response_class is RedirectResponse and status_code == 200
            else status_code
        )
        resolved_response_model = _resolve_response_model(
            endpoint,
            response_model,
            route_response_class,
        )
        _validate_response_models(resolved_response_model, responses or {})
        self.routes.append(
            self.route_class(
                path=_join_paths(self.prefix, path),
                endpoint=endpoint,
                methods=route_methods,
                status_code=normalize_status_code(route_status_code),
                dependencies=route_dependencies,
                response_class=route_response_class,
                responses={**self.responses, **(responses or {})},
                response_model=resolved_response_model,
                response_model_by_alias=response_model_by_alias,
                response_model_include=response_model_include,
                response_model_exclude=response_model_exclude,
                response_model_exclude_unset=response_model_exclude_unset,
                response_model_exclude_defaults=response_model_exclude_defaults,
                response_model_exclude_none=response_model_exclude_none,
                tags=[*self.tags, *(tags or [])],
                callbacks=[*self.callbacks, *(callbacks or [])],
                deprecated=deprecated if deprecated is not None else self.deprecated,
                summary=summary,
                description=description,
                response_description=response_description,
                openapi_extra=openapi_extra,
                operation_id=operation_id,
                include_in_schema=include_in_schema,
                generate_unique_id_function=(
                    generate_unique_id_function or self.generate_unique_id_function
                ),
                generate_unique_id_explicit=generate_unique_id_function is not None,
                strict_content_type=(
                    strict_content_type
                    if strict_content_type is not None
                    else self.strict_content_type
                ),
                response_class_explicit=response_class is not None,
            )
        )

    def get(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["GET"], **kwargs)

    def post(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["POST"], **kwargs)

    def put(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["PUT"], **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["DELETE"], **kwargs)

    def head(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["HEAD"], **kwargs)

    def options(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["OPTIONS"], **kwargs)

    def patch(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["PATCH"], **kwargs)

    def trace(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.api_route(path, methods=["TRACE"], **kwargs)

    def url_path_for(self, name: str, **path_params: Any) -> str:
        return _url_path_for(self.routes, name, **path_params)

    def websocket_route(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        route_dependencies = [*self.dependencies, *list(kwargs.get("dependencies") or [])]

        def decorator(endpoint: Callable[..., Any]) -> Callable[..., Any]:
            _validate_dependency_scopes(endpoint, route_dependencies)
            self.websocket_routes.append(
                WebSocketRoute(
                    path=_join_paths(self.prefix, path),
                    endpoint=endpoint,
                    dependencies=route_dependencies,
                )
            )
            return endpoint

        return decorator

    def websocket(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self.websocket_route(path, **kwargs)

    def include_router(
        self,
        router: "APIRouter",
        *,
        prefix: str = "",
        default_response_class: type[Response] | None = None,
        dependencies: list[DependsParam] | None = None,
        tags: list[str] | None = None,
        responses: dict[int | str, dict[str, Any]] | None = None,
        callbacks: list[Route] | None = None,
        deprecated: bool | None = None,
        generate_unique_id_function: Callable[[Any], str] | None = None,
        **_: Any,
    ) -> None:
        assert router is not self, (
            "Cannot include the same APIRouter instance into itself. "
            "Did you mean to include a different router?"
        )
        effective_default = default_response_class or self.default_response_class
        websocket_prefix = _join_paths(self.prefix, prefix)
        self.on_startup.extend(router.on_startup)
        self.on_shutdown.extend(router.on_shutdown)
        self.lifespan_contexts.extend(_router_lifespans(router))
        for route in router.websocket_routes:
            for path in _included_route_paths(websocket_prefix, route.path):
                self.websocket_routes.append(
                    WebSocketRoute(
                        path=path,
                        endpoint=route.endpoint,
                        dependencies=[*self.dependencies, *list(dependencies or []), *route.dependencies],
                    )
                )
        for route in router.routes:
            for path in _included_route_paths(websocket_prefix, route.path):
                self.routes.append(
                    route.__class__(
                        path=path,
                        endpoint=route.endpoint,
                        methods=set(route.methods),
                        status_code=route.status_code,
                        dependencies=[
                            *self.dependencies,
                            *(dependencies or []),
                            *route.dependencies,
                        ],
                        response_class=_included_response_class(
                            route.response_class,
                            router.default_response_class,
                            effective_default,
                        ),
                        responses={**self.responses, **(responses or {}), **route.responses},
                        response_model=route.response_model,
                        response_model_by_alias=route.response_model_by_alias,
                        response_model_include=route.response_model_include,
                        response_model_exclude=route.response_model_exclude,
                        response_model_exclude_unset=route.response_model_exclude_unset,
                        response_model_exclude_defaults=route.response_model_exclude_defaults,
                        response_model_exclude_none=route.response_model_exclude_none,
                        tags=[*self.tags, *(tags or []), *route.tags],
                        callbacks=[*self.callbacks, *(callbacks or []), *route.callbacks],
                        deprecated=(
                            route.deprecated
                            if route.deprecated is not None
                            else deprecated if deprecated is not None else self.deprecated
                        ),
                        summary=route.summary,
                        description=route.description,
                        response_description=route.response_description,
                        openapi_extra=route.openapi_extra,
                        operation_id=route.operation_id,
                        include_in_schema=route.include_in_schema,
                        generate_unique_id_function=(
                            route.generate_unique_id_function
                            or generate_unique_id_function
                            or self.generate_unique_id_function
                        ),
                        generate_unique_id_explicit=(
                            route.generate_unique_id_explicit
                            or generate_unique_id_function is not None
                        ),
                        strict_content_type=(
                            route.strict_content_type
                            if route.strict_content_type is not None
                            else router.strict_content_type
                            if router.strict_content_type is not None
                            else self.strict_content_type
                        ),
                        response_class_explicit=route.response_class_explicit,
                    )
                )


def _solve_arguments(
    endpoint: Callable[..., Any],
    request: Request,
    path_params: dict[str, str],
    response_state: Response,
    security_scopes: list[str] | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    signature = inspect.signature(endpoint)
    hints = _get_annotations(endpoint)
    values: dict[str, Any] = {}
    errors: list[dict[str, Any]] = []

    for name, parameter in signature.parameters.items():
        annotation = hints.get(name, Any)
        default = parameter.default
        annotation, annotated_default = _unpack_annotated(annotation)
        if annotated_default is not inspect.Signature.empty:
            _apply_signature_default(annotated_default, default)
            default = annotated_default
        if isinstance(default, DependsParam):
            default = _effective_dependency(default, annotation)
            value, dependency_errors = _solve_dependency(
                default,
                request,
                path_params,
                response_state,
                security_scopes=security_scopes,
            )
            if dependency_errors:
                errors.extend(dependency_errors)
            else:
                values[name] = value
            continue
        if annotation is Response:
            values[name] = response_state
            continue
        if annotation is WebSocket:
            values[name] = request
            continue
        if annotation is Request:
            values[name] = request
            continue
        if annotation is HTTPConnection:
            values[name] = request
            continue
        if getattr(annotation, "__name__", None) == "SecurityScopes":
            from .security import SecurityScopes

            values[name] = SecurityScopes(security_scopes)
            continue
        if annotation is BackgroundTasks:
            if request.background_tasks is None:
                request.background_tasks = BackgroundTasks()
            values[name] = request.background_tasks
            continue
        source = _param_source(name, default, annotation, path_params)
        raw_value, missing = _raw_value(name, source, default, annotation, request, path_params)
        if missing:
            param_name = _source_param_name(name, source, default)
            if (
                source == "body"
                and _is_body_annotation(annotation)
                and not (isinstance(default, BodyParam) and getattr(default, "embed", False))
                and not (request.body_param_names and len(request.body_param_names) > 1)
            ):
                errors.append(_missing_error("body", "", _missing_input(source, request, default), loc=["body"]))
                continue
            errors.append(
                _missing_error(
                    _error_source(source),
                    param_name,
                    _missing_input(source, request, default),
                )
            )
            continue
        param_name = _source_param_name(name, source, default)
        value, error = _convert_value(raw_value, annotation, source, param_name)
        if error is not None:
            error = _prefix_embedded_body_errors(
                error,
                source,
                param_name,
                default,
                request,
            )
            if isinstance(error, list):
                errors.extend(error)
            else:
                errors.append(error)
            continue
        constraint_error = _validate_constraints(value, raw_value, source, param_name, default)
        if constraint_error is not None:
            errors.append(constraint_error)
            continue
        values[name] = value

    return values, errors


def _solve_dependency(
    dependency: DependsParam,
    request: Request,
    path_params: dict[str, str],
    response_state: Response,
    security_scopes: list[str] | None = None,
) -> tuple[Any, list[dict[str, Any]]]:
    if dependency.dependency is None:
        return None, []
    original_dependency = dependency.dependency
    call = _dependency_override(original_dependency, request)
    dependency_scope = _dependency_cleanup_scope(dependency)
    active_scopes = [*(security_scopes or []), *dependency.scopes]
    cache_scopes = tuple(active_scopes) if dependency.scopes or _uses_security_scopes(call) else ()
    cache_key = (original_dependency, cache_scopes, dependency_scope)
    if dependency.use_cache and request.dependency_cache is not None and cache_key in request.dependency_cache:
        return request.dependency_cache[cache_key], []
    values, errors = _solve_arguments(
        call,
        request,
        path_params,
        response_state,
        security_scopes=active_scopes,
    )
    if errors:
        return None, errors
    value = call(**values)
    if inspect.isgenerator(value):
        result = next(value)
    elif inspect.isasyncgen(value):
        result = _run_async_gen_next(request, value)
    else:
        result = _run_maybe_async(value)
    if inspect.isgenerator(value) or inspect.isasyncgen(value):
        if request.dependency_finalizers is None:
            request.dependency_finalizers = []
        request.dependency_finalizers.append(DependencyFinalizer(value, dependency_scope))
    if dependency.use_cache and request.dependency_cache is not None:
        request.dependency_cache[cache_key] = result
    return result, []


def _dependency_override(dependency: Any, request: Request) -> Any:
    overrides = getattr(request.app, "dependency_overrides", {}) if request.app is not None else {}
    overrides = overrides or {}
    return overrides.get(dependency, dependency)


def _dependency_cleanup_scope(dependency: DependsParam) -> str:
    return dependency.scope or "request"


def _effective_dependency(dependency: DependsParam, annotation: object) -> DependsParam:
    if dependency.dependency is not None:
        return dependency
    if annotation in (Any, inspect.Signature.empty):
        return dependency
    return DependsParam(
        annotation,
        use_cache=dependency.use_cache,
        scopes=list(dependency.scopes),
        scope=dependency.scope,
    )


def _uses_security_scopes(call: Any, seen: set[Any] | None = None) -> bool:
    if seen is None:
        seen = set()
    if call in seen:
        return False
    seen.add(call)
    signature = inspect.signature(call)
    hints = _get_annotations(call)
    for name, parameter in signature.parameters.items():
        annotation = hints.get(name, Any)
        default = parameter.default
        annotation, annotated_default = _unpack_annotated(annotation)
        if annotated_default is not inspect.Signature.empty:
            _apply_signature_default(annotated_default, default)
            default = annotated_default
        if getattr(annotation, "__name__", None) == "SecurityScopes":
            return True
        if isinstance(default, DependsParam):
            default = _effective_dependency(default, annotation)
            if default.dependency is not None and _uses_security_scopes(default.dependency, seen):
                return True
    return False


def _collect_route_body_param_names(route: Route, request: Request) -> set[str]:
    names: set[str] = set()
    seen: set[Any] = set()
    for dependency in route.dependencies:
        _collect_dependency_body_param_names(dependency, request, names, seen)
    _collect_callable_body_param_names(route.endpoint, request, names, seen)
    return names


def _collect_dependency_body_param_names(
    dependency: DependsParam,
    request: Request,
    names: set[str],
    seen: set[Any],
) -> None:
    if dependency.dependency is None:
        return
    _collect_callable_body_param_names(
        _dependency_override(dependency.dependency, request),
        request,
        names,
        seen,
    )


def _collect_callable_body_param_names(
    call: Any,
    request: Request,
    names: set[str],
    seen: set[Any],
) -> None:
    if call in seen:
        return
    seen.add(call)
    signature = inspect.signature(call)
    hints = _get_annotations(call)
    for name, parameter in signature.parameters.items():
        annotation = hints.get(name, Any)
        default = parameter.default
        annotation, annotated_default = _unpack_annotated(annotation)
        if annotated_default is not inspect.Signature.empty:
            _apply_signature_default(annotated_default, default)
            default = annotated_default
        if annotation in {Response, Request, HTTPConnection}:
            continue
        if isinstance(default, DependsParam):
            default = _effective_dependency(default, annotation)
            _collect_dependency_body_param_names(default, request, names, seen)
            continue
        if _param_source(name, default, annotation, {}) == "body":
            names.add(_param_name(name, default))


def _validate_dependency_scopes(
    endpoint: Callable[..., Any],
    dependencies: list[DependsParam],
) -> None:
    seen: set[tuple[Any, str]] = set()
    for dependency in dependencies:
        _validate_dependency_scope(dependency, None, None, seen)
    for dependency in _callable_dependencies(endpoint):
        _validate_dependency_scope(dependency, None, None, seen)


def _validate_dependency_scope(
    dependency: DependsParam,
    parent_call: Any | None,
    parent_scope: str | None,
    seen: set[tuple[Any, str]],
) -> None:
    if dependency.dependency is None:
        return
    call = dependency.dependency
    dependency_scope = _dependency_cleanup_scope(dependency)
    if (
        parent_call is not None
        and parent_scope == "request"
        and dependency_scope == "function"
        and _is_yield_callable(parent_call)
        and _is_yield_callable(call)
    ):
        raise FastAPIError(
            f'The dependency "{_callable_name(parent_call)}" has a scope of "request", '
            'it cannot depend on dependencies with scope "function"'
        )
    key = (call, dependency_scope)
    if key in seen:
        return
    seen.add(key)
    for child_dependency in _callable_dependencies(call):
        _validate_dependency_scope(child_dependency, call, dependency_scope, seen)


def _callable_dependencies(call: Any) -> list[DependsParam]:
    dependencies: list[DependsParam] = []
    signature = inspect.signature(call)
    hints = _get_annotations(call)
    for name, parameter in signature.parameters.items():
        annotation = hints.get(name, Any)
        default = parameter.default
        annotation, annotated_default = _unpack_annotated(annotation)
        if annotated_default is not inspect.Signature.empty:
            _apply_signature_default(annotated_default, default)
            default = annotated_default
        if isinstance(default, DependsParam):
            dependencies.append(_effective_dependency(default, annotation))
    return dependencies


def _is_yield_callable(call: Any) -> bool:
    if inspect.isgeneratorfunction(call) or inspect.isasyncgenfunction(call):
        return True
    dunder_call = getattr(call, "__call__", None)
    return inspect.isgeneratorfunction(dunder_call) or inspect.isasyncgenfunction(dunder_call)


def _is_async_yield_callable(call: Any) -> bool:
    if inspect.isasyncgenfunction(call):
        return True
    dunder_call = getattr(call, "__call__", None)
    return inspect.isasyncgenfunction(dunder_call)


def _is_async_callable(call: Any) -> bool:
    if inspect.iscoroutinefunction(call):
        return True
    dunder_call = getattr(call, "__call__", None)
    return inspect.iscoroutinefunction(dunder_call)


def _callable_name(call: Any) -> str:
    return getattr(call, "__name__", call.__class__.__name__)


def _endpoint_context(route: Any, request: Request | WebSocket | None = None, method: str | None = None) -> dict[str, object]:
    root_path = ""
    if request is not None:
        root_path = str((request.scope or {}).get("root_path") or "")
    route_path = getattr(route, "path", "")
    if method is None:
        methods = getattr(route, "methods", None)
        method = next(iter(sorted(methods))) if methods else "WebSocket"
    endpoint = getattr(route, "endpoint", None)
    return {
        "path": f"{method} {root_path}{route_path}",
        "name": _callable_name(endpoint),
    }


def _unpack_annotated(annotation: object) -> tuple[object, object]:
    annotation = _unwrap_type_alias(annotation)
    if get_origin(annotation) is not Annotated:
        return annotation, inspect.Signature.empty
    args = get_args(annotation)
    param = inspect.Signature.empty
    remaining_metadata = []
    for item in args[1:]:
        if isinstance(item, (DependsParam, Param)):
            item = copy.copy(item)
            if isinstance(param, Param) and isinstance(item, Param):
                _merge_param_metadata(item, param)
            param = item
        else:
            remaining_metadata.append(item)
    inner = Annotated[args[0], *remaining_metadata] if remaining_metadata else args[0]
    return inner, param


def _merge_param_metadata(target: Param, source: Param) -> None:
    for name in (
        "min_length",
        "max_length",
        "gt",
        "ge",
        "lt",
        "le",
    ):
        if getattr(target, name, None) is None and getattr(source, name, None) is not None:
            setattr(target, name, getattr(source, name))


def _unwrap_type_alias(annotation: object) -> object:
    while hasattr(annotation, "__value__"):
        annotation = annotation.__value__
    return annotation


def _apply_signature_default(default: object, signature_default: object) -> None:
    if (
        isinstance(default, Param)
        and default.default is _MISSING
        and signature_default is not inspect.Signature.empty
    ):
        default.default = signature_default


def _validate_path_operation_params(endpoint: Callable[..., Any], path: str) -> None:
    path_param_names = set(re.findall(r"{([^}:]+)(?::[^}]+)?}", path))
    signature = inspect.signature(endpoint)
    hints = _get_annotations(endpoint)
    for name, parameter in signature.parameters.items():
        annotation = hints.get(name, Any)
        if _contains_pydantic_v1_model(annotation):
            raise PydanticV1NotSupportedError("Pydantic v1 models are not supported")
        raw_default = parameter.default
        annotation, annotated_default = _unpack_annotated(annotation)
        effective_form_default = annotated_default if annotated_default is not inspect.Signature.empty else raw_default
        if isinstance(effective_form_default, FormParam) or _contains_upload_file_annotation(annotation):
            ensure_multipart_is_installed()
        if isinstance(annotated_default, PathParam) and annotated_default.default is not _MISSING:
            raise AssertionError("Path parameters cannot have a default value")
        if (
            isinstance(annotated_default, Param)
            and not isinstance(annotated_default, PathParam)
            and annotated_default.default is not _MISSING
        ):
            raise AssertionError(
                f"`{annotated_default.__class__.__name__.removesuffix('Param')}` default value "
                f"cannot be set in `Annotated` for '{name}'. Set the default value with `=` instead."
            )
        if isinstance(annotated_default, DependsParam) and isinstance(raw_default, DependsParam):
            raise AssertionError(
                f"Cannot specify `Depends` in `Annotated` and default value together for '{name}'"
            )
        if isinstance(annotated_default, Param) and isinstance(raw_default, DependsParam):
            raise AssertionError(
                "Cannot specify a FastAPI annotation in `Annotated` and `Depends` as a "
                f"default value together for '{name}'"
            )
        effective_default = annotated_default if annotated_default is not inspect.Signature.empty else raw_default
        if name in path_param_names and _invalid_path_param_annotation(annotation):
            raise AssertionError("Path params must be of one of the supported types")
        if isinstance(effective_default, QueryParam) and not _valid_query_param_annotation(annotation):
            raise AssertionError(f"Query parameter '{name}' must be one of the supported types")


def _invalid_path_param_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    origin = get_origin(annotation)
    return annotation in (list, tuple, set, frozenset, dict) or origin in (
        list,
        tuple,
        set,
        frozenset,
        dict,
    )


def _valid_query_param_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    if hasattr(annotation, "model_validate"):
        return True
    if annotation is list:
        return True
    origin = get_origin(annotation)
    if origin in (list, set, frozenset):
        args = get_args(annotation)
        return bool(args) and _valid_query_scalar_annotation(args[0])
    if origin in (tuple, dict):
        return False
    if annotation in (list, set, frozenset, tuple, dict):
        return False
    return _valid_query_scalar_annotation(annotation)


def _valid_query_scalar_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    if annotation in (Any, inspect.Signature.empty, str, int, float, bool, bytes):
        return True
    if isinstance(annotation, type) and issubclass(annotation, Enum):
        return True
    return not (
        hasattr(annotation, "model_validate")
        or is_dataclass(annotation)
        or get_origin(annotation) in (list, set, frozenset, tuple, dict)
        or annotation in (list, set, frozenset, tuple, dict)
    )


def _run_maybe_async(value: Any) -> Any:
    if not inspect.isawaitable(value):
        return value
    return asyncio.run(value)


def _run_async_gen_next(request: Request, value: Any) -> Any:
    return _run_sync_awaitable(value.__anext__())


def _finalize_dependencies(
    request: Request,
    exc: Exception | None,
    *,
    scope: str | None = None,
) -> Exception | None:
    finalizers = request.dependency_finalizers or []
    selected: list[DependencyFinalizer] = []
    remaining: list[DependencyFinalizer] = []
    while finalizers:
        item = finalizers.pop()
        if scope is None or item.scope == scope:
            selected.append(item)
        else:
            remaining.append(item)
    request.dependency_finalizers = list(reversed(remaining))
    error: Exception | None = None
    for item in selected:
        finalizer = item.finalizer
        try:
            if inspect.isasyncgen(finalizer):
                _finalize_async_gen(request, finalizer, exc)
            elif exc is not None:
                finalizer.throw(exc)
            else:
                next(finalizer)
        except (StopIteration, StopAsyncIteration):
            if exc is not None and error is None:
                error = FastAPIError(
                    "Response not returned. There was an exception while "
                    "raising an exception and a dependency with yield swallowed it."
                )
            continue
        except Exception as finalizer_error:
            if error is None:
                error = finalizer_error
    if not request.dependency_finalizers and request.dependency_loop is not None:
        request.dependency_loop.close()
        request.dependency_loop = None
    return error


def _prepare_response_body(response: Response) -> Exception | None:
    if not isinstance(response, StreamingResponse):
        return None
    try:
        response.body
    except Exception as exc:
        response._body = b""
        return exc
    return None


def _finalize_async_gen(request: Request, finalizer: Any, exc: Exception | None) -> None:
    if exc is not None:
        _run_sync_awaitable(finalizer.athrow(exc))
    else:
        _run_sync_awaitable(finalizer.__anext__())


def _dependency_loop(request: Request) -> asyncio.AbstractEventLoop:
    if request.dependency_loop is None:
        request.dependency_loop = asyncio.new_event_loop()
    return request.dependency_loop


def _run_sync_awaitable(value: Any) -> Any:
    iterator = value.__await__()
    try:
        next(iterator)
    except StopIteration as exc:
        return exc.value
    raise RuntimeError("Async generator dependencies that await before yielding are not supported yet")


def _get_annotations(call: Any) -> dict[str, Any]:
    try:
        annotations = inspect.get_annotations(call, eval_str=True)
    except Exception:
        annotations = inspect.get_annotations(call)
    if inspect.isclass(call):
        init = getattr(call, "__init__", None)
        if init is None:
            return annotations
        try:
            init_annotations = inspect.get_annotations(init, eval_str=True)
        except Exception:
            init_annotations = inspect.get_annotations(init)
        return init_annotations or annotations
    if inspect.isfunction(call) or inspect.ismethod(call) or inspect.isclass(call):
        return annotations
    call_method = getattr(call, "__call__", None)
    if call_method is None:
        return annotations
    try:
        call_annotations = inspect.get_annotations(call_method, eval_str=True)
    except Exception:
        call_annotations = inspect.get_annotations(call_method)
    return call_annotations or annotations


def _serialize_response_model(
    response_model: Any,
    result: Any,
    *,
    endpoint_ctx: dict[str, object] | None = None,
    by_alias: bool,
    include: Any = None,
    exclude: Any = None,
    exclude_unset: bool = False,
    exclude_defaults: bool = False,
    exclude_none: bool = False,
) -> Any:
    adapter = core_schema_adapter(response_model)
    try:
        validated = adapter.validate_python(result, from_attributes=True)
    except ValidationError as exc:
        if hasattr(result, "model_dump"):
            try:
                validated = adapter.validate_python(result.model_dump(), from_attributes=True)
            except ValidationError as dumped_exc:
                raise ResponseValidationError(
                    _response_validation_errors(dumped_exc),
                    body=result,
                    endpoint_ctx=endpoint_ctx,
                ) from dumped_exc
            return adapter.dump_python(
                validated,
                mode="json",
                by_alias=by_alias,
                include=include,
                exclude=exclude,
                exclude_unset=exclude_unset,
                exclude_defaults=exclude_defaults,
                exclude_none=exclude_none,
            )
        raise ResponseValidationError(
            _response_validation_errors(exc),
            body=result,
            endpoint_ctx=endpoint_ctx,
        ) from exc
    return adapter.dump_python(
        validated,
        mode="json",
        by_alias=by_alias,
        include=include,
        exclude=exclude,
        exclude_unset=exclude_unset,
        exclude_defaults=exclude_defaults,
        exclude_none=exclude_none,
    )


def _serialize_response_model_json(
    response_model: Any,
    result: Any,
    *,
    endpoint_ctx: dict[str, object] | None = None,
    by_alias: bool,
    include: Any = None,
    exclude: Any = None,
    exclude_unset: bool = False,
    exclude_defaults: bool = False,
    exclude_none: bool = False,
) -> bytes:
    adapter = core_schema_adapter(response_model)
    try:
        validated = adapter.validate_python(result, from_attributes=True)
    except ValidationError as exc:
        if hasattr(result, "model_dump"):
            try:
                validated = adapter.validate_python(result.model_dump(), from_attributes=True)
            except ValidationError as dumped_exc:
                raise ResponseValidationError(
                    _response_validation_errors(dumped_exc),
                    body=result,
                    endpoint_ctx=endpoint_ctx,
                ) from dumped_exc
        else:
            raise ResponseValidationError(
                _response_validation_errors(exc),
                body=result,
                endpoint_ctx=endpoint_ctx,
            ) from exc
    return adapter.dump_json(
        validated,
        by_alias=by_alias,
        include=include,
        exclude=exclude,
        exclude_unset=exclude_unset,
        exclude_defaults=exclude_defaults,
        exclude_none=exclude_none,
    )


def _response_model_dump_kwargs(
    *,
    by_alias: bool,
    include: Any = None,
    exclude: Any = None,
    exclude_unset: bool = False,
    exclude_defaults: bool = False,
    exclude_none: bool = False,
) -> dict[str, Any]:
    dump_kwargs: dict[str, Any] = {"by_alias": by_alias}
    if include is not None:
        dump_kwargs["include"] = include
    if exclude is not None:
        dump_kwargs["exclude"] = exclude
    if exclude_unset:
        dump_kwargs["exclude_unset"] = True
    if exclude_defaults:
        dump_kwargs["exclude_defaults"] = True
    if exclude_none:
        dump_kwargs["exclude_none"] = True
    return dump_kwargs


def _resolve_response_model(
    endpoint: Callable[..., Any],
    response_model: Any,
    response_class: type[Response] | None = None,
) -> Any:
    if response_model is not RESPONSE_MODEL_UNSET:
        return response_model
    if response_class is not None and issubclass(response_class, StreamingResponse):
        return None
    annotation = inspect.get_annotations(endpoint, eval_str=True).get("return", inspect.Signature.empty)
    if annotation is inspect.Signature.empty:
        return None
    if _is_response_annotation(annotation):
        return None
    if _is_bare_stream_annotation(annotation):
        return None
    if _contains_response_annotation(annotation):
        raise FastAPIError(
            "Invalid args for response field! Hint: check that the return annotation is a valid "
            "Pydantic field type. If you are using a return type annotation that is not a valid "
            "Pydantic field, you can disable generating the response model from the type "
            "annotation with the path operation decorator parameter response_model=None."
        )
    return annotation


def _validate_response_models(response_model: Any, responses: dict[int | str, dict[str, Any]]) -> None:
    if _contains_pydantic_v1_model(response_model):
        raise PydanticV1NotSupportedError("Pydantic v1 models are not supported")
    if response_model is not None and not _is_valid_response_model_type(response_model):
        raise FastAPIError(
            "Invalid args for response field! Hint: check that the response_model is a valid "
            "Pydantic field type."
        )
    for response_spec in responses.values():
        model = response_spec.get("model")
        if _contains_pydantic_v1_model(model):
            raise PydanticV1NotSupportedError("Pydantic v1 models are not supported")
        if model is not None and not _is_valid_response_model_type(model):
            raise FastAPIError(
                "Invalid args for response field! Hint: check that the response model is a valid "
                "Pydantic field type."
            )


def _is_valid_response_model_type(annotation: Any) -> bool:
    annotation = _unwrap_type_alias(annotation)
    if annotation in (Any, object, None, type(None), inspect.Signature.empty):
        return True
    if hasattr(annotation, "model_json_schema"):
        return True
    if is_dataclass(annotation):
        return True
    if annotation in (str, int, float, bool, bytes, dict, list):
        return True
    origin = get_origin(annotation)
    if origin in (list, set, frozenset, tuple):
        return all(_is_valid_response_model_type(arg) for arg in get_args(annotation) if arg is not Ellipsis)
    if origin in (types.UnionType, Union):
        return all(_is_valid_response_model_type(arg) for arg in get_args(annotation))
    if origin is not None:
        return all(_is_valid_response_model_type(arg) for arg in get_args(annotation))
    return False


def _contains_pydantic_v1_model(annotation: Any) -> bool:
    annotation = _unwrap_type_alias(annotation)
    if annotation in (None, inspect.Signature.empty):
        return False
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        return bool(args and _contains_pydantic_v1_model(args[0]))
    if origin in (types.UnionType, Union, list, set, frozenset, tuple, dict):
        return any(_contains_pydantic_v1_model(arg) for arg in get_args(annotation) if arg is not Ellipsis)
    if origin is not None:
        return any(_contains_pydantic_v1_model(arg) for arg in get_args(annotation))
    try:
        from pydantic import v1
    except Exception:
        return False
    try:
        return isinstance(annotation, type) and issubclass(annotation, v1.BaseModel)
    except TypeError:
        return False


def _is_response_annotation(annotation: object) -> bool:
    return isinstance(annotation, type) and issubclass(annotation, Response)


def _is_bare_stream_annotation(annotation: object) -> bool:
    origin = get_origin(annotation)
    return annotation in (ABCIterable, ABCAsyncIterable) or origin in (ABCIterable, ABCAsyncIterable)


def _is_bare_stream_result(result: object) -> bool:
    return inspect.isgenerator(result) or inspect.isasyncgen(result)


def _stream_item_model(endpoint: Callable[..., Any]) -> Any:
    annotation = inspect.get_annotations(endpoint, eval_str=True).get("return", inspect.Signature.empty)
    if not _is_bare_stream_annotation(annotation):
        return None
    args = get_args(annotation)
    if not args or args[0] is Any:
        return None
    return args[0]


def _json_line_stream(content: Any, item_model: Any = None) -> Any:
    def encode_item(item: Any) -> bytes:
        if item_model is not None:
            item = _serialize_response_model(
                item_model,
                item,
                by_alias=True,
                include=None,
                exclude=None,
                exclude_unset=False,
                exclude_defaults=False,
                exclude_none=False,
            )
        return JSONResponse(item).body + b"\n"

    if inspect.isasyncgen(content):
        async def generate() -> Any:
            async for item in content:
                yield encode_item(item)

        return generate()

    def generate_sync() -> Any:
        for item in content:
            yield encode_item(item)

    return generate_sync()


def _contains_response_annotation(annotation: object) -> bool:
    if _is_response_annotation(annotation):
        return True
    return any(_contains_response_annotation(arg) for arg in get_args(annotation))


def _param_source(name: str, default: object, annotation: object, path_params: dict[str, str]) -> str:
    if isinstance(default, PathParam) or name in path_params:
        return "path"
    if isinstance(default, QueryParam):
        return "query"
    if isinstance(default, HeaderParam):
        return "header"
    if isinstance(default, CookieParam):
        return "cookie"
    if isinstance(default, FormParam):
        return "form"
    if isinstance(default, BodyParam):
        return "body"
    if _contains_upload_file_annotation(annotation):
        return "form"
    if _is_body_annotation(annotation):
        return "body"
    return "query"


def _rust_fast_path_kind(annotation: object) -> str | None:
    annotation = _unwrap_optional(annotation)
    origin = get_origin(annotation)
    if origin is list:
        args = get_args(annotation)
        if args and args[0] is bytes:
            return "list_bytes"
        if args and _is_upload_file_annotation(args[0]):
            return "list_upload_file"
    if annotation in (inspect.Signature.empty, Any, str):
        return "str"
    if annotation is bytes:
        return "bytes"
    if _is_upload_file_annotation(annotation):
        return "upload_file"
    if annotation is int:
        return "int"
    if annotation is float:
        return "float"
    if annotation is bool:
        return "bool"
    return None


def _rust_fast_path_param_spec(
    name: str,
    default: object,
    annotation: object,
    source: str,
) -> dict[str, Any] | None:
    if source not in {"path", "query", "header", "cookie", "form"}:
        return None
    kind = _rust_fast_path_kind(annotation)
    if kind is None:
        return None
    return {
        "name": name,
        "source": source,
        "wire_name": _source_param_name(name, source, default),
        "kind": kind,
        "required": _rust_fast_path_required(default),
        "default": _rust_fast_path_default(default),
        "upload_file_class": UploadFile if kind in {"upload_file", "list_upload_file"} else None,
    }


def _rust_fast_path_dependency_spec(
    target_name: str | None,
    dependency: DependsParam,
    path_params: set[str],
    dependency_overrides: dict[Any, Callable[..., Any]] | None = None,
) -> dict[str, Any] | None:
    if dependency.dependency is None:
        return None
    original_call = dependency.dependency
    dependency_overrides = dependency_overrides or {}
    call = dependency_overrides.get(original_call, original_call)
    signature = inspect.signature(call)
    hints = _get_annotations(call)
    params: list[dict[str, Any]] = []
    dependencies: list[dict[str, Any]] = []
    background_tasks_param: str | None = None
    request_param: str | None = None
    security_scopes_param: str | None = None
    for name, parameter in signature.parameters.items():
        annotation = hints.get(name, Any)
        default = parameter.default
        annotation, annotated_default = _unpack_annotated(annotation)
        if annotated_default is not inspect.Signature.empty:
            _apply_signature_default(annotated_default, default)
            default = annotated_default
        if isinstance(default, DependsParam):
            child_dependency = _effective_dependency(default, annotation)
            child_spec = _rust_fast_path_dependency_spec(
                name,
                child_dependency,
                path_params,
                dependency_overrides,
            )
            if child_spec is None:
                return None
            dependencies.append(child_spec)
            continue
        if annotation is BackgroundTasks:
            if background_tasks_param is not None:
                return None
            background_tasks_param = name
            continue
        if annotation is Request:
            if request_param is not None:
                return None
            request_param = name
            continue
        if getattr(annotation, "__name__", None) == "SecurityScopes":
            if security_scopes_param is not None:
                return None
            security_scopes_param = name
            continue
        if annotation in {Response, HTTPConnection}:
            return None
        source = _param_source(name, default, annotation, {key: "" for key in path_params})
        param_spec = _rust_fast_path_param_spec(name, default, annotation, source)
        if param_spec is None:
            return None
        params.append(param_spec)
    from .security import SecurityScopes

    return {
        "target": target_name,
        "call": call,
        "call_is_async": _is_async_callable(call),
        "call_is_yield": _is_yield_callable(call),
        "call_is_async_yield": _is_async_yield_callable(call),
        "params": params,
        "dependencies": dependencies,
        "background_tasks_param": background_tasks_param,
        "request_param": request_param,
        "security_scopes_param": security_scopes_param,
        "security_scopes_class": SecurityScopes,
        "security_scopes": list(dependency.scopes),
        "uses_security_scopes": _uses_security_scopes(call),
        "cleanup_scope": _dependency_cleanup_scope(dependency),
        "use_cache": dependency.use_cache,
        "cache_key": id(original_call),
    }


def _rust_fast_path_required(default: object) -> bool:
    if isinstance(default, Param):
        return bool(default.required)
    return default is inspect.Signature.empty


def _rust_fast_path_default(default: object) -> object:
    if isinstance(default, Param):
        if default.required:
            return None
        return default.default
    if default is inspect.Signature.empty:
        return None
    return default


def _rust_static_json_body(endpoint: Callable[..., Any]) -> str | None:
    try:
        source = inspect.getsource(endpoint)
    except (OSError, TypeError):
        return None
    try:
        module = ast.parse(inspect.cleandoc(source))
    except SyntaxError:
        return None
    function = next(
        (node for node in module.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))),
        None,
    )
    if (
        function is None
        or len(function.body) != 1
        or not isinstance(function.body[0], ast.Return)
    ):
        return None
    try:
        value = _rust_literal_json_value(function.body[0].value)
    except ValueError:
        return None
    try:
        return json.dumps(value, separators=(",", ":"))
    except (TypeError, ValueError):
        return None


def _rust_literal_json_value(node: ast.AST | None) -> Any:
    if node is None:
        return None
    if isinstance(node, ast.Constant):
        if node.value is None or isinstance(node.value, (str, int, float, bool)):
            return node.value
        raise ValueError
    if isinstance(node, (ast.List, ast.Tuple)):
        return [_rust_literal_json_value(item) for item in node.elts]
    if isinstance(node, ast.Dict):
        result: dict[str, Any] = {}
        for key, value in zip(node.keys, node.values):
            key_value = _rust_literal_json_value(key)
            if not isinstance(key_value, str):
                raise ValueError
            result[key_value] = _rust_literal_json_value(value)
        return result
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        value = _rust_literal_json_value(node.operand)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return -value
    raise ValueError


def _raw_value(
    name: str,
    source: str,
    default: object,
    annotation: object,
    request: Request,
    path_params: dict[str, str],
) -> tuple[Any, bool]:
    param_name = _param_name(name, default)
    if source == "path":
        if param_name in path_params:
            return path_params[param_name], False
        return None, True
    if source == "body":
        if request.json_body is None:
            if isinstance(default, Param) and not default.required:
                return default.default, False
            if not isinstance(default, Param) and default is not inspect.Signature.empty:
                return default, False
            return None, True
        if request.body_param_names and len(request.body_param_names) > 1:
            if not isinstance(request.json_body, dict) or param_name not in request.json_body:
                if isinstance(default, Param) and not default.required:
                    return default.default, False
                return None, True
            return request.json_body[param_name], False
        if isinstance(default, BodyParam) and getattr(default, "embed", False):
            if not isinstance(request.json_body, dict) or param_name not in request.json_body:
                if not default.required:
                    return default.default, False
                return None, True
            return request.json_body[param_name], False
        return request.json_body, False
    if source == "header":
        if _is_model_like_annotation(annotation):
            return _param_model_input(request.headers or {}, annotation, default, source), False
        header_name = _header_lookup_name(param_name, default)
        headers = request.headers or Headers()
        values = headers.getlist(header_name) if hasattr(headers, "getlist") else []
        if values:
            return values if _expects_collection(annotation) else values[-1], False
        if isinstance(default, Param):
            if default.required:
                return None, True
            return default.default, False
        if default is inspect.Signature.empty:
            return None, True
        return default, False
    if source == "cookie":
        if _is_model_like_annotation(annotation):
            return _param_model_input(request.cookies or {}, annotation, default, source), False
        value = (request.cookies or {}).get(param_name)
        if value is not None:
            return value, False
        if isinstance(default, Param):
            if default.required:
                return None, True
            return default.default, False
        if default is inspect.Signature.empty:
            return None, True
        return default, False
    if source == "form":
        if _is_model_like_annotation(annotation):
            return _form_model_input(annotation, request.form_body or {}), False
        value = (request.form_body or {}).get(param_name)
        if value is not None:
            return value, False
        if isinstance(default, Param):
            if default.required:
                return None, True
            return default.default, False
        if default is inspect.Signature.empty:
            return None, True
        return default, False

    if source == "query" and _is_model_like_annotation(annotation):
        return _param_model_input(request.query_params, annotation, default, source), False
    query_values = request.query_params.get(param_name)
    if query_values:
        return query_values if _expects_collection(annotation) else query_values[-1], False

    if isinstance(default, Param):
        if default.required:
            return None, True
        return default.default, False
    if default is inspect.Signature.empty:
        return None, True
    return default, False


def _param_name(name: str, default: object) -> str:
    if isinstance(default, Param) and getattr(default, "validation_alias", None):
        return str(default.validation_alias)
    if isinstance(default, Param) and getattr(default, "alias", None):
        return str(default.alias)
    return name


def _source_param_name(name: str, source: str, default: object) -> str:
    param_name = _param_name(name, default)
    if source == "header":
        return _header_lookup_name(param_name, default)
    return param_name


def _header_lookup_name(name: str, default: object) -> str:
    if isinstance(default, HeaderParam) and (
        getattr(default, "alias", None) or getattr(default, "validation_alias", None)
    ):
        return name
    if isinstance(default, HeaderParam) and getattr(default, "convert_underscores", True) is False:
        return name
    return name.replace("_", "-")


def _expects_collection(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    return annotation in (list, set, frozenset) or get_origin(annotation) in (list, set, frozenset)


def _convert_value(
    value: Any,
    annotation: object,
    source: str,
    name: str,
) -> tuple[Any, dict[str, Any] | list[dict[str, Any]] | None]:
    if source == "form" and value == "" and _allows_none(annotation):
        return None, None
    if value is None and _allows_none(annotation):
        return None, None
    if get_origin(annotation) is Annotated:
        try:
            return core_schema_adapter(annotation).validate_python(value), None
        except ValidationError as exc:
            return None, _pydantic_errors(exc, _error_source(source), name=name)
    annotation = _unwrap_optional(annotation)
    origin = get_origin(annotation)
    if source == "body" and origin in (list, dict, set, frozenset, tuple, types.UnionType, Union):
        try:
            return core_schema_adapter(annotation).validate_python(value), None
        except ValidationError as exc:
            return None, _pydantic_errors(exc, _error_source(source))
    if origin in (list, frozenset):
        inner_annotation = get_args(annotation)[0] if get_args(annotation) else Any
        converted_items = []
        item_errors: list[dict[str, Any]] = []
        for index, item in enumerate(value):
            converted, error = _convert_value(item, inner_annotation, source, name)
            if error is not None:
                errors = error if isinstance(error, list) else [error]
                for item_error in errors:
                    item_error["loc"] = [*item_error["loc"], index]
                    item_errors.append(item_error)
                continue
            converted_items.append(converted)
        if item_errors:
            return None, item_errors
        if origin is frozenset:
            return frozenset(converted_items), None
        return converted_items, None
    if annotation is list:
        if isinstance(value, list):
            return value, None
        return [value], None
    if annotation in (inspect.Signature.empty, Any):
        return value, None
    if annotation is str:
        return str(value), None
    if annotation is bytes:
        return _bytes_value(value), None
    if _is_upload_file_annotation(annotation):
        return _upload_file_value(value), None
    if annotation is int:
        try:
            if isinstance(value, str) and value.strip().lower() in {"true", "false"}:
                raise ValueError
            return int(value), None
        except (TypeError, ValueError):
            return None, _parsing_error("int_parsing", source, name, value)
    if annotation is float:
        try:
            return float(value), None
        except (TypeError, ValueError):
            return None, _parsing_error("float_parsing", source, name, value)
    if annotation is bool:
        lowered = str(value).lower()
        if lowered in {"1", "true", "on", "yes"}:
            return True, None
        if lowered in {"0", "false", "off", "no"}:
            return False, None
        return None, _parsing_error("bool_parsing", source, name, value)
    if isinstance(annotation, type) and issubclass(annotation, Enum):
        try:
            return annotation(value), None
        except ValueError:
            expected = _enum_expected(annotation)
            return None, {
                "type": "enum",
                "loc": [source, name],
                "msg": f"Input should be {expected}",
                "input": value,
                "ctx": {"expected": expected},
            }
    if _is_body_annotation(annotation):
        try:
            return core_schema_adapter(annotation).validate_python(value), None
        except ValidationError as exc:
            return None, _pydantic_errors(exc, _error_source(source))
        except Exception:
            return None, {
                "type": "model_attributes_type",
                "loc": ["body"],
                "msg": "Input should be a valid dictionary or object to extract fields from",
                "input": value,
            }
    try:
        return core_schema_adapter(annotation).validate_python(value), None
    except ValidationError as exc:
        return None, _pydantic_errors(exc, _error_source(source), name=name)
    except Exception:
        pass
    return value, None


def _enum_expected(annotation: type[Enum]) -> str:
    values = [repr(item.value) for item in annotation]
    if len(values) == 1:
        return values[0]
    return f"{', '.join(values[:-1])} or {values[-1]}"


def _is_body_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    if _is_model_like_annotation(annotation):
        return True
    if annotation in (dict, list, set, frozenset, tuple):
        return True
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        return bool(args and _is_body_annotation(args[0]))
    if origin in (dict, list, set, frozenset, tuple):
        return True
    if origin in (types.UnionType, Union):
        return any(_is_body_annotation(arg) for arg in get_args(annotation))
    return False


def _is_model_like_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        return bool(args and _is_model_like_annotation(args[0]))
    if origin in (types.UnionType, Union):
        return any(_is_model_like_annotation(arg) for arg in get_args(annotation))
    return hasattr(annotation, "model_validate") or is_dataclass(annotation)


def _maybe_parse_lax_json_body(route: Route, request: Request) -> None:
    if route.strict_content_type is not False:
        return
    if not isinstance(request.json_body, str):
        return
    headers = request.headers or Headers()
    if headers.get("content-type"):
        return
    try:
        request.json_body = json.loads(request.json_body)
    except json.JSONDecodeError:
        return


def _parse_request_body_if_needed(route: Route, request: Request) -> None:
    if request.raw_body is None or request.json_body is not None:
        return
    content_type = (request.headers or Headers()).get("content-type", "")
    if _is_json_content_type(content_type):
        body = _run_sync_awaitable(request.body())
        request.raw_body = body
        request.scope["raw_body"] = body
        request.json_body = json.loads(body.decode("utf-8")) if body else None
        request.scope["json_body"] = request.json_body
    elif _is_urlencoded_form_content_type(content_type):
        body = _run_sync_awaitable(request.body())
        text = body.decode("utf-8")
        request.form_body = _urlencoded_form_body(text)
        request.json_body = text
        request.scope["form_body"] = request.form_body
        request.scope["json_body"] = request.json_body


def _is_json_content_type(content_type: str) -> bool:
    media_type = content_type.split(";", 1)[0].strip().lower()
    return media_type == "application/json" or media_type.endswith("+json")


def _is_urlencoded_form_content_type(content_type: str) -> bool:
    media_type = content_type.split(";", 1)[0].strip().lower()
    return media_type == "application/x-www-form-urlencoded"


def _urlencoded_form_body(body: str) -> dict[str, Any]:
    parsed = core.parse_query_string(body)
    return {key: values if len(values) != 1 else values[0] for key, values in parsed.items()}


def _is_upload_file_annotation(annotation: object) -> bool:
    return getattr(annotation, "__name__", None) == "UploadFile"


def _contains_upload_file_annotation(annotation: object) -> bool:
    annotation = _unwrap_optional(annotation)
    if _is_upload_file_annotation(annotation):
        return True
    origin = get_origin(annotation)
    if origin in (list, set, frozenset, tuple):
        return any(_contains_upload_file_annotation(arg) for arg in get_args(annotation))
    return False


def _bytes_value(value: Any) -> bytes:
    if isinstance(value, bytes):
        return value
    if _is_upload_file_instance(value):
        position = value.file.tell() if hasattr(value.file, "tell") else None
        content = value.file.read()
        if position is not None and hasattr(value.file, "seek"):
            value.file.seek(position)
        return content
    return bytes(value)


def _upload_file_value(value: Any) -> Any:
    if _is_upload_file_instance(value):
        return value
    from starlette.datastructures import UploadFile

    return UploadFile(filename="", file=_bytes_value(value))


def _is_upload_file_instance(value: Any) -> bool:
    return getattr(value.__class__, "__name__", None) == "UploadFile"


def _form_model_input(annotation: object, form_body: dict[str, Any]) -> dict[str, Any]:
    data = dict(form_body)
    model_fields = getattr(annotation, "model_fields", {})
    for field_name, field in model_fields.items():
        aliases = [str(alias) for alias in (field.alias, getattr(field, "validation_alias", None)) if alias]
        key = aliases[0] if aliases else field_name
        if key in data or field_name in data:
            continue
        if not field.is_required():
            default = field.get_default(call_default_factory=True)
            if default is not None:
                data[key] = default
    return data


def _param_model_input(
    values: dict[str, Any],
    annotation: object | None = None,
    default: object | None = None,
    source: str = "",
) -> dict[str, Any]:
    data: dict[str, Any] = {}
    if hasattr(values, "getlist"):
        for key in values.keys():
            items = values.getlist(key)
            data[key] = items if len(items) != 1 else items[-1]
    else:
        for key, value in values.items():
            if isinstance(value, list):
                data[key] = value if len(value) != 1 else value[-1]
            else:
                data[key] = value
    return _model_param_input_with_defaults(data, annotation, default, source)


def _model_param_input_with_defaults(
    data: dict[str, Any],
    annotation: object | None,
    default: object | None,
    source: str,
) -> dict[str, Any]:
    model_fields = getattr(annotation, "model_fields", {})
    if not model_fields:
        return data
    result = dict(data)
    for field_name, field in model_fields.items():
        key = _model_field_input_key(field_name, field, default, source)
        aliases = {key, field_name, str(field.alias) if field.alias else ""}
        if any(alias and alias in result for alias in aliases):
            continue
        if source == "header" and isinstance(default, HeaderParam):
            raw_name = field_name if getattr(default, "convert_underscores", True) is False else field_name.replace("_", "-")
            if raw_name in result:
                result[key] = result.pop(raw_name)
                continue
        if not field.is_required():
            default_value = field.get_default(call_default_factory=True)
            if default_value is not None:
                result[key] = default_value
    return result


def _model_field_input_key(field_name: str, field: Any, default: object | None, source: str) -> str:
    aliases = [str(alias) for alias in (field.alias, getattr(field, "validation_alias", None)) if alias]
    if aliases:
        return aliases[0]
    if source == "header" and isinstance(default, HeaderParam) and getattr(default, "convert_underscores", True):
        return field_name
    return field_name


def _pydantic_errors(exc: Exception, source: str, name: str | None = None) -> list[dict[str, Any]]:
    result = []
    for error in exc.errors():
        cleaned = {key: value for key, value in error.items() if key != "url"}
        if source == "body" and cleaned.get("type") == "model_type":
            cleaned["type"] = "model_attributes_type"
            cleaned["msg"] = "Input should be a valid dictionary or object to extract fields from"
            cleaned.pop("ctx", None)
        loc = list(cleaned.get("loc", ()))
        if name is not None and not loc:
            cleaned["loc"] = [source, name]
        else:
            cleaned["loc"] = [source, *loc]
        result.append(cleaned)
    return result


def _response_validation_errors(exc: Exception) -> list[dict[str, Any]]:
    result = []
    for error in exc.errors():
        cleaned = {key: value for key, value in error.items() if key != "url"}
        loc = tuple(cleaned.get("loc", ()))
        cleaned["loc"] = ("response", *loc)
        result.append(cleaned)
    return result


def _prefix_embedded_body_errors(
    error: dict[str, Any] | list[dict[str, Any]],
    source: str,
    name: str,
    default: object,
    request: Request,
) -> dict[str, Any] | list[dict[str, Any]]:
    if source != "body":
        return error
    if not _uses_embedded_body_value(name, default, request):
        return error
    errors = error if isinstance(error, list) else [error]
    for item in errors:
        loc = item.get("loc")
        if not isinstance(loc, list) or not loc or loc[0] != "body":
            continue
        if len(loc) > 1 and loc[1] == name:
            continue
        item["loc"] = ["body", name, *loc[1:]]
    return error


def _uses_embedded_body_value(name: str, default: object, request: Request) -> bool:
    if isinstance(default, BodyParam) and getattr(default, "embed", False):
        return True
    return bool(request.body_param_names and len(request.body_param_names) > 1 and name in request.body_param_names)


def _unwrap_optional(annotation: object) -> object:
    origin = get_origin(annotation)
    if origin is None:
        return annotation
    if origin not in (types.UnionType, Union):
        return annotation
    args = [arg for arg in get_args(annotation) if arg is not type(None)]
    if len(args) == 1:
        return args[0]
    return annotation


def _allows_none(annotation: object) -> bool:
    if get_origin(annotation) is Annotated:
        args = get_args(annotation)
        return bool(args and _allows_none(args[0]))
    return type(None) in get_args(annotation)


def _validate_constraints(
    value: Any,
    raw_value: Any,
    source: str,
    name: str,
    default: object,
) -> dict[str, Any] | None:
    if not isinstance(default, Param):
        return None
    if value is None:
        return None
    if getattr(default, "allow_inf_nan", None) is False and isinstance(value, float) and not math.isfinite(value):
        return {
            "type": "finite_number",
            "loc": [source, name],
            "msg": "Input should be a finite number",
            "input": raw_value,
        }
    if default.min_length is not None and len(value) < default.min_length:
        characters = "character" if default.min_length == 1 else "characters"
        return {
            "type": "string_too_short",
            "loc": [source, name],
            "msg": f"String should have at least {default.min_length} {characters}",
            "input": value,
            "ctx": {"min_length": default.min_length},
        }
    if default.max_length is not None and len(value) > default.max_length:
        return {
            "type": "string_too_long",
            "loc": [source, name],
            "msg": f"String should have at most {default.max_length} characters",
            "input": value,
            "ctx": {"max_length": default.max_length},
        }
    pattern = getattr(default, "pattern", None) or getattr(default, "regex", None)
    if pattern is not None and re.match(str(pattern), str(value)) is None:
        return {
            "type": "string_pattern_mismatch",
            "loc": [_error_source(source), name],
            "msg": f"String should match pattern '{pattern}'",
            "input": value,
            "ctx": {"pattern": str(pattern)},
        }
    comparisons = [
        ("greater_than", "gt", default.gt, lambda item, limit: item > limit),
        ("greater_than_equal", "ge", default.ge, lambda item, limit: item >= limit),
        ("less_than", "lt", default.lt, lambda item, limit: item < limit),
        ("less_than_equal", "le", default.le, lambda item, limit: item <= limit),
    ]
    for error_type, key, limit, predicate in comparisons:
        if limit is not None and not predicate(value, limit):
            return {
                "type": error_type,
                "loc": [_error_source(source), name],
                "msg": _comparison_message(key, limit),
                "input": raw_value,
                "ctx": {key: float(limit)},
            }
    return None


def _comparison_message(key: str, limit: float) -> str:
    messages = {
        "gt": "Input should be greater than",
        "ge": "Input should be greater than or equal to",
        "lt": "Input should be less than",
        "le": "Input should be less than or equal to",
    }
    return f"{messages[key]} {limit:g}"


def _error_source(source: str) -> str:
    return "body" if source == "form" else source


def _missing_input(source: str, request: Request, default: object) -> Any:
    return None


def _missing_error(
    source: str,
    name: str,
    input_value: Any = None,
    *,
    loc: list[Any] | None = None,
) -> dict[str, Any]:
    return {
        "type": "missing",
        "loc": loc or [source, name],
        "msg": "Field required",
        "input": input_value,
    }


def _parsing_error(error_type: str, source: str, name: str, value: Any) -> dict[str, Any]:
    messages = {
        "int_parsing": "Input should be a valid integer, unable to parse string as an integer",
        "float_parsing": "Input should be a valid number, unable to parse string as a number",
        "bool_parsing": "Input should be a valid boolean, unable to interpret input",
    }
    return {
        "type": error_type,
        "loc": [_error_source(source), name],
        "msg": messages[error_type],
        "input": value,
    }


def normalize_status_code(status_code: int | IntEnum) -> int:
    return int(status_code)


def _join_paths(prefix: str, path: str) -> str:
    if not prefix:
        return path
    if not path:
        return prefix if prefix.startswith("/") else f"/{prefix}"
    joined = f"/{prefix.strip('/')}/{path.strip('/')}"
    if path.endswith("/") and joined != "/" and not joined.endswith("/"):
        joined += "/"
    return joined


def _included_route_paths(prefix: str, path: str) -> list[str]:
    if prefix and path == "":
        base = prefix if prefix.startswith("/") else f"/{prefix}"
        base = base.rstrip("/") or "/"
        return [base, f"{base}/" if base != "/" else "/"]
    return [_join_paths(prefix, path)]


def _included_response_class(
    route_response_class: type[Response],
    router_default_response_class: type[Response],
    effective_default_response_class: type[Response],
) -> type[Response]:
    if route_response_class is router_default_response_class and router_default_response_class is JSONResponse:
        return effective_default_response_class
    return route_response_class


def _url_path_for(routes: list[Route], name: str, **path_params: Any) -> str:
    for route in routes:
        if route.name != name:
            continue
        path_param_names = re.findall(r"{([^}:]+)(?::[^}]+)?}", route.path)
        if any(param_name not in path_params for param_name in path_param_names):
            continue

        def replace(match: re.Match[str]) -> str:
            return str(path_params[match.group(1)])

        return re.sub(r"{([^}:]+)(?::[^}]+)?}", replace, route.path)
    raise LookupError(f"No route exists for name {name!r} and params {path_params!r}")


def _same_trailing_slash(left: str, right: str) -> bool:
    if left == "/" or right == "/":
        return left == right
    return left.endswith("/") == right.endswith("/")


def _router_lifespans(router: APIRouter) -> list[Callable[..., Any]]:
    lifespans = [*router.lifespan_contexts]
    if router.lifespan is not None:
        lifespans.append(router.lifespan)
    return lifespans


@dataclass
class WebSocketRoute:
    path: str
    endpoint: Callable[..., Any]
    dependencies: list[DependsParam] = field(default_factory=list)

    def match(self, path: str) -> dict[str, str] | None:
        return core.match_route(self.path, path)

    def handle(
        self,
        app: Any,
        path: str,
        path_params: dict[str, str],
        *,
        query_string: str = "",
        headers: dict[str, str] | None = None,
        close_state: dict[str, Any] | None = None,
        websocket: WebSocket | None = None,
    ) -> WebSocket:
        websocket = websocket or WebSocket(
            app=app,
            path=path,
            route=self,
            query_string=query_string,
            headers=headers,
            close_state=close_state,
        )
        response_state = Response()
        errors: list[dict[str, Any]] = []
        try:
            for dependency in self.dependencies:
                _, dependency_errors = _solve_dependency(dependency, websocket, path_params, response_state)
                errors.extend(dependency_errors)
            values, argument_errors = _solve_arguments(self.endpoint, websocket, path_params, response_state)
        except WebSocketException as exc:
            _run_maybe_async(websocket.close(code=exc.code, reason=exc.reason))
            return websocket
        errors.extend(argument_errors)
        if errors:
            _run_maybe_async(websocket.close(code=1008))
            exc = WebSocketRequestValidationError(
                errors,
                endpoint_ctx=_endpoint_context(self, websocket, method="WebSocket"),
            )
            if _has_exception_handler(getattr(app, "exception_handlers", {}), exc):
                raise exc
            return websocket
        try:
            _run_maybe_async(self.endpoint(**values))
        except WebSocketException as exc:
            _run_maybe_async(websocket.close(code=exc.code, reason=exc.reason))
            return websocket
        except Exception as exc:
            finalizer_error = _finalize_dependencies(websocket, exc)
            raise finalizer_error or exc
        finalizer_error = _finalize_dependencies(websocket, None)
        if finalizer_error is not None:
            raise finalizer_error
        return websocket


APIRoute = Route
APIWebSocketRoute = WebSocketRoute


def _has_exception_handler(handlers: dict[type[Exception], Any], exc: Exception) -> bool:
    return any(isinstance(exc, exc_class) for exc_class in handlers)
