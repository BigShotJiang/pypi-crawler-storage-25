from __future__ import annotations

import fnmatch
import gzip
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class Middleware:
    cls: Callable[..., Any]
    args: tuple[Any, ...] = field(default_factory=tuple)
    kwargs: dict[str, Any] = field(default_factory=dict)

    def __init__(self, cls: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
        self.cls = cls
        self.args = args
        self.kwargs = kwargs


class HTTPSRedirectMiddleware:
    def __init__(self, app: Any) -> None:
        self.app = app


class TrustedHostMiddleware:
    def __init__(
        self,
        app: Any,
        allowed_hosts: list[str] | None = None,
        www_redirect: bool = True,
    ) -> None:
        self.app = app
        self.allowed_hosts = allowed_hosts or ["*"]
        self.www_redirect = www_redirect

    def is_allowed(self, host: str) -> bool:
        hostname = host.split(":", 1)[0]
        return any(pattern == "*" or fnmatch.fnmatch(hostname, pattern) for pattern in self.allowed_hosts)


class GZipMiddleware:
    def __init__(
        self,
        app: Any,
        minimum_size: int = 500,
        compresslevel: int = 9,
    ) -> None:
        self.app = app
        self.minimum_size = minimum_size
        self.compresslevel = compresslevel

    def compressed_size(self, body: bytes) -> int:
        return len(gzip.compress(body, compresslevel=self.compresslevel))


class CORSMiddleware:
    def __init__(
        self,
        app: Any,
        allow_origins: list[str] | None = None,
        allow_methods: list[str] | None = None,
        allow_headers: list[str] | None = None,
        allow_credentials: bool = False,
        **_: Any,
    ) -> None:
        self.app = app
        self.allow_origins = allow_origins or []
        self.allow_methods = allow_methods or ["GET"]
        self.allow_headers = allow_headers or []
        self.allow_credentials = allow_credentials

    def is_allowed_origin(self, origin: str) -> bool:
        return "*" in self.allow_origins or origin in self.allow_origins
