from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass

from .exceptions import HTTPException
from .params import Form, Header
from .routing import Request


@dataclass
class HTTPAuthorizationCredentials:
    scheme: str
    credentials: str


@dataclass
class HTTPBasicCredentials:
    username: str
    password: str


class SecurityScopes:
    def __init__(self, scopes: list[str] | None = None) -> None:
        self.scopes = scopes or []

    @property
    def scope_str(self) -> str:
        return " ".join(self.scopes)


class OAuth2PasswordBearer:
    def __init__(
        self,
        tokenUrl: str,
        *,
        scopes: dict[str, str] | None = None,
        scheme_name: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.tokenUrl = tokenUrl
        self.scopes = scopes or {}
        self.scheme_name = scheme_name or self.__class__.__name__
        self.description = description
        self.auto_error = auto_error

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {
            "type": "oauth2",
            "flows": {"password": {"tokenUrl": self.tokenUrl, "scopes": self.scopes}},
        }
        if self.description is not None:
            scheme["description"] = self.description
        return scheme

    async def __call__(self, authorization: str | None = Header(None)) -> str | None:
        credentials = _authorization_credentials(authorization)
        if credentials is not None and credentials.scheme.lower() == "bearer":
            return credentials.credentials
        if self.auto_error:
            raise HTTPException(
                status_code=401,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return None


class OAuth2:
    def __init__(
        self,
        *,
        flows: dict[str, object],
        scheme_name: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.flows = flows
        self.scheme_name = scheme_name or self.__class__.__name__
        self.description = description
        self.auto_error = auto_error

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {"type": "oauth2", "flows": self.flows}
        if self.description is not None:
            scheme["description"] = self.description
        return scheme

    async def __call__(self, authorization: str | None = Header(None)) -> str | None:
        if authorization:
            return authorization.strip()
        if self.auto_error:
            raise HTTPException(
                status_code=401,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return None


class OAuth2AuthorizationCodeBearer(OAuth2PasswordBearer):
    def __init__(
        self,
        *,
        authorizationUrl: str,
        tokenUrl: str,
        refreshUrl: str | None = None,
        scopes: dict[str, str] | None = None,
        scheme_name: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.authorizationUrl = authorizationUrl
        self.refreshUrl = refreshUrl
        super().__init__(
            tokenUrl,
            scopes=scopes,
            scheme_name=scheme_name or self.__class__.__name__,
            description=description,
            auto_error=auto_error,
        )

    def openapi_scheme(self) -> dict[str, object]:
        flow: dict[str, object] = {
            "authorizationUrl": self.authorizationUrl,
            "tokenUrl": self.tokenUrl,
            "scopes": self.scopes,
        }
        if self.refreshUrl is not None:
            flow["refreshUrl"] = self.refreshUrl
        scheme: dict[str, object] = {
            "type": "oauth2",
            "flows": {"authorizationCode": flow},
        }
        if self.description is not None:
            scheme["description"] = self.description
        return scheme


class OpenIdConnect(OAuth2):
    def __init__(
        self,
        *,
        openIdConnectUrl: str,
        scheme_name: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.openIdConnectUrl = openIdConnectUrl
        self.scheme_name = scheme_name or self.__class__.__name__
        self.description = description
        self.auto_error = auto_error

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {
            "type": "openIdConnect",
            "openIdConnectUrl": self.openIdConnectUrl,
        }
        if self.description is not None:
            scheme["description"] = self.description
        return scheme


class HTTPBearer:
    def __init__(
        self,
        *,
        scheme_name: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.scheme_name = scheme_name or self.__class__.__name__
        self.description = description
        self.auto_error = auto_error

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {"type": "http", "scheme": "bearer"}
        if self.description is not None:
            scheme["description"] = self.description
        return scheme

    async def __call__(self, authorization: str | None = Header(None)) -> HTTPAuthorizationCredentials | None:
        credentials = _authorization_credentials(authorization)
        if credentials is not None and credentials.scheme.lower() == "bearer":
            return credentials
        if self.auto_error:
            raise self.make_not_authenticated_error()
        return None

    def make_not_authenticated_error(self) -> HTTPException:
        return HTTPException(
            status_code=401,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )


class HTTPBase:
    def __init__(
        self,
        *,
        scheme: str,
        scheme_name: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.scheme = scheme
        self.scheme_name = scheme_name or self.__class__.__name__
        self.description = description
        self.auto_error = auto_error

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {"type": "http", "scheme": self.scheme}
        if self.description is not None:
            scheme["description"] = self.description
        return scheme

    async def __call__(self, authorization: str | None = Header(None)) -> HTTPAuthorizationCredentials | None:
        credentials = _authorization_credentials(authorization)
        if credentials is not None and credentials.scheme.lower() == self.scheme.lower():
            return credentials
        if self.auto_error:
            raise self.make_not_authenticated_error()
        return None

    def make_not_authenticated_error(self) -> HTTPException:
        return HTTPException(
            status_code=401,
            detail="Not authenticated",
            headers={"WWW-Authenticate": self.scheme},
        )


class HTTPDigest(HTTPBase):
    def __init__(self, *, scheme_name: str | None = None, description: str | None = None, auto_error: bool = True, **kwargs: object) -> None:
        super().__init__(
            scheme="Digest",
            scheme_name=scheme_name or self.__class__.__name__,
            description=description,
            auto_error=auto_error,
            **kwargs,
        )

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {"type": "http", "scheme": "digest"}
        if self.description is not None:
            scheme["description"] = self.description
        return scheme


class HTTPBasic:
    def __init__(
        self,
        *,
        scheme_name: str | None = None,
        realm: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.scheme_name = scheme_name or self.__class__.__name__
        self.realm = realm
        self.description = description
        self.auto_error = auto_error

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {"type": "http", "scheme": "basic"}
        if self.description is not None:
            scheme["description"] = self.description
        return scheme

    async def __call__(self, authorization: str | None = Header(None)) -> HTTPBasicCredentials | None:
        credentials = _authorization_credentials(authorization)
        if credentials is None or credentials.scheme.lower() != "basic":
            if self.auto_error:
                raise self._not_authenticated()
            return None
        try:
            decoded = base64.b64decode(credentials.credentials).decode("ascii")
        except (binascii.Error, UnicodeDecodeError):
            raise self._not_authenticated()
        username, separator, password = decoded.partition(":")
        if not separator:
            raise self._not_authenticated()
        return HTTPBasicCredentials(username=username, password=password)

    def _not_authenticated(self) -> HTTPException:
        authenticate = "Basic"
        if self.realm is not None:
            authenticate = f'Basic realm="{self.realm}"'
        return HTTPException(
            status_code=401,
            detail="Not authenticated",
            headers={"WWW-Authenticate": authenticate},
        )


class _APIKeyBase:
    location: str

    def __init__(
        self,
        *,
        name: str,
        scheme_name: str | None = None,
        description: str | None = None,
        auto_error: bool = True,
        **_: object,
    ) -> None:
        self.name = name
        self.scheme_name = scheme_name or self.__class__.__name__
        self.description = description
        self.auto_error = auto_error

    def openapi_scheme(self) -> dict[str, object]:
        scheme: dict[str, object] = {
            "type": "apiKey",
            "name": self.name,
            "in": self.location,
        }
        if self.description is not None:
            scheme["description"] = self.description
        return scheme

    def _missing(self) -> str | None:
        if self.auto_error:
            raise HTTPException(
                status_code=401,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "APIKey"},
            )
        return None


class APIKeyCookie(_APIKeyBase):
    location = "cookie"

    async def __call__(self, request: Request) -> str | None:
        value = (request.cookies or {}).get(self.name)
        if value is not None:
            return value
        return self._missing()


class APIKeyHeader(_APIKeyBase):
    location = "header"

    async def __call__(self, request: Request) -> str | None:
        value = request.headers.get(self.name) if request.headers is not None else None
        if value is not None:
            return value
        return self._missing()


class APIKeyQuery(_APIKeyBase):
    location = "query"

    async def __call__(self, request: Request) -> str | None:
        values = request.query_params.get(self.name, [])
        if values:
            return values[-1]
        return self._missing()


class OAuth2PasswordRequestFormStrict:
    def __init__(
        self,
        grant_type: str = Form(pattern="^password$"),
        username: str = Form(),
        password: str = Form(),
        scope: str = Form(""),
        client_id: str | None = Form(None),
        client_secret: str | None = Form(None),
    ) -> None:
        self.grant_type = grant_type
        self.username = username
        self.password = password
        self.scopes = scope.split()
        self.client_id = client_id
        self.client_secret = client_secret

    def model_dump(self, **_: object) -> dict[str, object]:
        return {
            "grant_type": self.grant_type,
            "username": self.username,
            "password": self.password,
            "scopes": self.scopes,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }


class OAuth2PasswordRequestForm(OAuth2PasswordRequestFormStrict):
    def __init__(
        self,
        grant_type: str | None = Form(None, pattern="^password$"),
        username: str = Form(),
        password: str = Form(format="password"),
        scope: str = Form(""),
        client_id: str | None = Form(None),
        client_secret: str | None = Form(None, format="password"),
    ) -> None:
        super().__init__(
            grant_type=grant_type,
            username=username,
            password=password,
            scope=scope,
            client_id=client_id,
            client_secret=client_secret,
        )


__all__ = [
    "APIKeyCookie",
    "APIKeyHeader",
    "APIKeyQuery",
    "HTTPAuthorizationCredentials",
    "HTTPBase",
    "HTTPBasic",
    "HTTPBasicCredentials",
    "HTTPBearer",
    "HTTPDigest",
    "OAuth2",
    "OAuth2AuthorizationCodeBearer",
    "OAuth2PasswordBearer",
    "OAuth2PasswordRequestForm",
    "OAuth2PasswordRequestFormStrict",
    "OpenIdConnect",
    "SecurityScopes",
]


def _authorization_credentials(authorization: str | None) -> HTTPAuthorizationCredentials | None:
    if not authorization:
        return None
    scheme, _, credentials = authorization.partition(" ")
    credentials = credentials.strip()
    if not scheme or not credentials:
        return None
    return HTTPAuthorizationCredentials(scheme=scheme, credentials=credentials)
