from __future__ import annotations

import json
import os
from base64 import b64encode
from dataclasses import dataclass
from http.cookies import SimpleCookie
from typing import Any
from urllib.parse import urlencode
from urllib.parse import urlparse


@dataclass
class ClientResponse:
    status_code: int
    content: bytes
    headers: dict[str, str]

    @property
    def text(self) -> str:
        return self.content.decode("utf-8")

    def json(self) -> Any:
        return json.loads(self.text)

    def raise_for_status(self) -> None:
        if 400 <= self.status_code:
            raise RuntimeError(f"HTTP error response {self.status_code}")

    @property
    def cookies(self) -> "CookieJar":
        jar = CookieJar()
        values = self.headers.getlist("set-cookie") if hasattr(self.headers, "getlist") else []
        for value in values:
            cookie = SimpleCookie()
            cookie.load(value)
            for key, morsel in cookie.items():
                jar[key] = morsel.value
        return jar


class TestClient:
    def __init__(
        self,
        app: Any,
        raise_server_exceptions: bool = True,
        cookies: dict[str, str] | None = None,
        root_path: str | None = None,
        base_url: str = "http://testserver",
        follow_redirects: bool = True,
    ) -> None:
        self.app = app
        self.raise_server_exceptions = raise_server_exceptions
        self.root_path = root_path
        self.base_url = base_url
        self.follow_redirects = follow_redirects
        self.headers: dict[str, str] = {
            "accept": "*/*",
            "accept-encoding": "gzip, deflate",
            "connection": "keep-alive",
            "user-agent": "testclient",
        }
        self.cookies = CookieJar()
        self.cookies.update(cookies or {})
        self.app_state: dict[str, Any] = {}

    def __enter__(self) -> "TestClient":
        if hasattr(self.app, "startup"):
            self.app_state = self.app.startup()
        return self

    def __exit__(self, *args: object) -> None:
        if hasattr(self.app, "shutdown"):
            self.app.shutdown()
        return None

    def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        auth: tuple[str, str] | None = None,
        follow_redirects: bool | None = None,
        **_: Any,
    ) -> ClientResponse:
        return self.request("GET", path, params=params, headers=headers, auth=auth, follow_redirects=follow_redirects)

    def post(
        self,
        path: str | None = None,
        json: Any = None,
        content: str | bytes | None = None,
        data: dict[str, Any] | None = None,
        files: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        follow_redirects: bool | None = None,
        url: str | None = None,
        **_: Any,
    ) -> ClientResponse:
        return self.request(
            "POST",
            path or url or "/",
            json=json,
            content=content,
            data=data,
            files=files,
            params=params,
            headers=headers,
            follow_redirects=follow_redirects,
        )

    def put(
        self,
        path: str,
        json: Any = None,
        content: str | bytes | None = None,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        follow_redirects: bool | None = None,
        **_: Any,
    ) -> ClientResponse:
        return self.request(
            "PUT",
            path,
            json=json,
            content=content,
            data=data,
            params=params,
            headers=headers,
            follow_redirects=follow_redirects,
        )

    def delete(
        self,
        path: str,
        json: Any = None,
        content: str | bytes | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        follow_redirects: bool | None = None,
        **_: Any,
    ) -> ClientResponse:
        return self.request(
            "DELETE",
            path,
            json=json,
            content=content,
            params=params,
            headers=headers,
            follow_redirects=follow_redirects,
        )

    def head(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        follow_redirects: bool | None = None,
        **_: Any,
    ) -> ClientResponse:
        return self.request("HEAD", path, params=params, headers=headers, follow_redirects=follow_redirects)

    def options(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        follow_redirects: bool | None = None,
        **_: Any,
    ) -> ClientResponse:
        return self.request("OPTIONS", path, params=params, headers=headers, follow_redirects=follow_redirects)

    def patch(
        self,
        path: str,
        json: Any = None,
        content: str | bytes | None = None,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        follow_redirects: bool | None = None,
        **_: Any,
    ) -> ClientResponse:
        return self.request(
            "PATCH",
            path,
            json=json,
            content=content,
            data=data,
            params=params,
            headers=headers,
            follow_redirects=follow_redirects,
        )

    def websocket_connect(self, path: str) -> Any:
        headers = _with_cookie_header(None, self.cookies)
        return WebSocketSession(self.app.handle_websocket(path, headers=headers))

    def request(
        self,
        method: str,
        path: str,
        json: Any = None,
        content: str | bytes | None = None,
        data: dict[str, Any] | None = None,
        files: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        auth: tuple[str, str] | None = None,
        follow_redirects: bool | None = None,
    ) -> ClientResponse:
        follow_redirects = self.follow_redirects if follow_redirects is None else follow_redirects
        path = _normalized_path(path)
        path = _with_params(path, params)
        form_body = _merge_form_and_files(data, files)
        headers = _merged_headers(self.headers, headers)
        request_headers = _with_cookie_header(headers, self.cookies)
        request_headers = _with_basic_auth(request_headers, auth)
        request_headers = _with_default_header(request_headers, "host", _host_from_url(self.base_url))
        raw_body = _raw_body(content)
        json_body = None
        if json is not None:
            raw_body = json_module_dumps(json)
            request_headers = _with_default_header(
                request_headers,
                "content-type",
                "application/json",
            )
        if raw_body is None and data is not None:
            raw_body = urlencode(data, doseq=True).encode("utf-8")
            request_headers = _with_default_header(
                request_headers,
                "content-type",
                "application/x-www-form-urlencoded",
            )
        try:
            response = self.app.handle_request(
                method,
                path,
                json_body=json_body,
                raw_body=raw_body,
                form_body=form_body,
                headers=request_headers,
                raise_server_exceptions=self.raise_server_exceptions,
                root_path=self.root_path,
                scheme=_scheme_from_url(self.base_url),
                client=("testclient", 50000),
            )
            redirects_remaining = 10
            while (
                follow_redirects
                and response.status_code in {301, 302, 303, 307, 308}
                and "location" in response.headers
                and redirects_remaining > 0
            ):
                redirects_remaining -= 1
                path = _normalized_path(response.headers["location"])
                response = self.app.handle_request(
                    method,
                    path,
                    json_body=json_body,
                    raw_body=raw_body,
                    form_body=form_body,
                    headers=request_headers,
                    raise_server_exceptions=self.raise_server_exceptions,
                    root_path=self.root_path,
                    scheme=_scheme_from_url(self.base_url),
                    client=("testclient", 50000),
                )
            return ClientResponse(
                status_code=response.status_code,
                content=response.body,
                headers=response.headers,
            )
        finally:
            _close_form_files(form_body)


class WebSocketSession:
    def __init__(self, websocket: Any) -> None:
        self.websocket = websocket

    def __enter__(self) -> Any:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
        error = self.websocket._worker_error.get("error") if self.websocket._worker_error else None
        if error is not None:
            raise error
        return None

    def send_text(self, data: str) -> None:
        self.websocket._client_send_text(data)

    def send_json(self, data: Any) -> None:
        self.websocket._client_send_json(data)

    def receive_text(self) -> str:
        return self.websocket._client_receive_text()

    def receive_json(self) -> Any:
        return self.websocket._client_receive_json()

    def close(self, code: int = 1000, reason: str = "") -> None:
        self.websocket._client_close(code=code, reason=reason)


def _with_params(path: str, params: dict[str, Any] | None) -> str:
    if not params:
        return path
    separator = "&" if "?" in path else "?"
    return path + separator + urlencode(params, doseq=True)


def _merged_headers(
    client_headers: dict[str, str],
    request_headers: dict[str, str] | list[tuple[str, str]] | None,
) -> dict[str, str] | list[tuple[str, str]] | None:
    if not client_headers:
        return request_headers
    if request_headers is None:
        return dict(client_headers)
    if hasattr(request_headers, "items"):
        return {**client_headers, **request_headers}
    return [*client_headers.items(), *request_headers]


def _normalized_path(path: str) -> str:
    if path.startswith(("http://", "https://")):
        parsed = urlparse(path)
        normalized = parsed.path or "/"
        if parsed.query:
            normalized += "?" + parsed.query
        return normalized
    if path.startswith("/"):
        return path
    return "/" + path


def _host_from_url(base_url: str) -> str:
    parsed = urlparse(base_url)
    return parsed.netloc or "testserver"


def _scheme_from_url(base_url: str) -> str:
    parsed = urlparse(base_url)
    return parsed.scheme or "http"


def _with_cookie_header(
    headers: dict[str, str] | list[tuple[str, str]] | None,
    cookies: dict[str, str] | list[tuple[str, str]],
) -> dict[str, str] | list[tuple[str, str]] | None:
    if not cookies or _has_cookie_header(headers):
        return headers
    cookie_items = cookies.items() if hasattr(cookies, "items") else cookies
    cookie_header = "; ".join(f"{key}={value}" for key, value in cookie_items)
    if headers is None:
        return {"cookie": cookie_header}
    if hasattr(headers, "items"):
        return {**headers, "cookie": cookie_header}
    return [*headers, ("cookie", cookie_header)]


def _with_basic_auth(
    headers: dict[str, str] | list[tuple[str, str]] | None,
    auth: tuple[str, str] | None,
) -> dict[str, str] | list[tuple[str, str]] | None:
    if auth is None or _has_header(headers, "authorization"):
        return headers
    encoded = b64encode(f"{auth[0]}:{auth[1]}".encode("latin-1")).decode("ascii")
    if headers is None:
        return {"authorization": f"Basic {encoded}"}
    if hasattr(headers, "items"):
        return {**headers, "authorization": f"Basic {encoded}"}
    return [*headers, ("authorization", f"Basic {encoded}")]


def _has_cookie_header(headers: dict[str, str] | list[tuple[str, str]] | None) -> bool:
    return _has_header(headers, "cookie")


def _has_header(headers: dict[str, str] | list[tuple[str, str]] | None, name: str) -> bool:
    if headers is None:
        return False
    items = headers.items() if hasattr(headers, "items") else headers
    lowered = name.lower()
    return any(str(key).lower() == lowered for key, _ in items)


def _with_default_header(
    headers: dict[str, str] | list[tuple[str, str]] | None,
    key: str,
    value: str,
) -> dict[str, str] | list[tuple[str, str]]:
    if _has_header(headers, key):
        return headers or {}
    if headers is None:
        return {key: value}
    if hasattr(headers, "items"):
        return {**headers, key: value}
    return [*headers, (key, value)]


def _raw_body(content: str | bytes | None) -> bytes | None:
    if content is None:
        return None
    if isinstance(content, bytes):
        return content
    return content.encode("utf-8")


def json_module_dumps(value: Any) -> bytes:
    return json.dumps(value).encode("utf-8")


def _merge_form_and_files(data: dict[str, Any] | None, files: Any) -> dict[str, Any] | None:
    if data is None and files is None:
        return None
    form: dict[str, Any] = dict(data or {})
    for key, file_info in _iter_files(files):
        content = _file_content(key, file_info)
        if key in form:
            existing = form[key]
            if isinstance(existing, list):
                existing.append(content)
            else:
                form[key] = [existing, content]
        else:
            form[key] = content
    return form


def _iter_files(files: Any) -> list[tuple[str, Any]]:
    if files is None:
        return []
    if isinstance(files, dict):
        return list(files.items())
    return list(files)


def _file_content(key: str, file_info: Any) -> Any:
    from starlette.datastructures import UploadFile

    filename = key
    content_type = None
    if isinstance(file_info, tuple) and len(file_info) >= 2:
        file_tuple = file_info
        filename = str(file_info[0])
        file_info = file_tuple[1]
        if len(file_tuple) >= 3:
            content_type = str(file_tuple[2])
    elif hasattr(file_info, "name"):
        filename = os.path.basename(str(file_info.name))
    if isinstance(file_info, UploadFile):
        return file_info
    if hasattr(file_info, "read"):
        return UploadFile(filename=filename, file=file_info, content_type=content_type)
    if isinstance(file_info, str):
        file_info = file_info.encode("utf-8")
    return UploadFile(filename=filename, file=bytes(file_info), content_type=content_type)


def _close_form_files(form_body: dict[str, Any] | None) -> None:
    if not form_body:
        return
    for value in form_body.values():
        values = value if isinstance(value, list) else [value]
        for item in values:
            if getattr(item.__class__, "__name__", None) == "UploadFile" and hasattr(item, "file"):
                item.file.close()


class CookieJar(dict[str, str]):
    def set(self, key: str, value: str) -> None:
        self[key] = value
