from __future__ import annotations

from typing import Any, TypeVar

from starlette.datastructures import UploadFile


class DefaultPlaceholder:
    def __init__(self, value: Any) -> None:
        self.value = value

    def __bool__(self) -> bool:
        return bool(self.value)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, DefaultPlaceholder) and other.value == self.value


DefaultType = TypeVar("DefaultType")


def Default(value: DefaultType) -> DefaultType:
    return DefaultPlaceholder(value)  # type: ignore[return-value]


__all__ = ["Default", "DefaultPlaceholder", "UploadFile"]
