from __future__ import annotations

import warnings

from .exceptions import FastAPIDeprecationWarning

_MISSING = object()


class Param:
    def __init__(
        self,
        default: object = _MISSING,
        *,
        min_length: int | None = None,
        max_length: int | None = None,
        gt: float | None = None,
        ge: float | None = None,
        lt: float | None = None,
        le: float | None = None,
        **extra: object,
    ) -> None:
        self.default = default
        self.min_length = min_length
        self.max_length = max_length
        self.gt = gt
        self.ge = ge
        self.lt = lt
        self.le = le
        if "example" in extra:
            warnings.warn(
                "`example` is deprecated, use `examples` or `openapi_examples` instead.",
                FastAPIDeprecationWarning,
                stacklevel=2,
            )
        if "regex" in extra:
            warnings.warn(
                "`regex` is deprecated, use `pattern` instead.",
                FastAPIDeprecationWarning,
                stacklevel=2,
            )
        for key, value in extra.items():
            setattr(self, key, value)

    @property
    def required(self) -> bool:
        return self.default is _MISSING or self.default is Ellipsis

    def __repr__(self) -> str:
        name = self.__class__.__name__.removesuffix("Param") or "Param"
        return f"{name}({_repr_default(self.default)})"


class PathParam(Param):
    source = "path"


class QueryParam(Param):
    source = "query"


class HeaderParam(Param):
    source = "header"


class CookieParam(Param):
    source = "cookie"


class BodyParam(Param):
    source = "body"


class FormParam(Param):
    source = "form"


class FileParam(FormParam):
    source = "form"


class DependsParam:
    def __init__(
        self,
        dependency: object = None,
        *,
        use_cache: bool = True,
        scopes: list[str] | None = None,
        scope: str | None = None,
    ) -> None:
        self.dependency = dependency
        self.use_cache = use_cache
        self.scopes = scopes or []
        self.scope = scope

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, DependsParam):
            return NotImplemented
        return (
            self.dependency,
            self.use_cache,
            tuple(self.scopes),
            self.scope,
        ) == (
            other.dependency,
            other.use_cache,
            tuple(other.scopes),
            other.scope,
        )

    def __hash__(self) -> int:
        return hash((self.dependency, self.use_cache, tuple(self.scopes), self.scope))


def Path(default: object = _MISSING, **kwargs: object) -> PathParam:
    return PathParam(default, **kwargs)


def Query(default: object = _MISSING, **kwargs: object) -> QueryParam:
    return QueryParam(default, **kwargs)


def Header(default: object = _MISSING, **kwargs: object) -> HeaderParam:
    return HeaderParam(default, **kwargs)


def Cookie(default: object = _MISSING, **kwargs: object) -> CookieParam:
    return CookieParam(default, **kwargs)


def Body(default: object = _MISSING, **kwargs: object) -> BodyParam:
    return BodyParam(default, **kwargs)


def Form(default: object = _MISSING, **kwargs: object) -> FormParam:
    return FormParam(default, **kwargs)


def File(default: object = _MISSING, **kwargs: object) -> FileParam:
    return FileParam(default, **kwargs)


def Depends(
    dependency: object = None,
    *,
    use_cache: bool = True,
    scope: str | None = None,
    **_: object,
) -> DependsParam:
    return DependsParam(dependency, use_cache=use_cache, scope=scope)


def Security(
    dependency: object = None,
    *,
    scopes: list[str] | None = None,
    use_cache: bool = True,
    **_: object,
) -> DependsParam:
    return DependsParam(dependency, use_cache=use_cache, scopes=scopes)


def _repr_default(default: object) -> str:
    if default is _MISSING or default is Ellipsis:
        return "PydanticUndefined"
    return str(default)
