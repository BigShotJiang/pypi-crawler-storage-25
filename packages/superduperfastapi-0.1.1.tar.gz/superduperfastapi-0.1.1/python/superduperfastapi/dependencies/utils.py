from __future__ import annotations

from typing import Any


multipart_not_installed_error = "Form data requires python-multipart to be installed."
multipart_incorrect_install_error = "python-multipart is installed incorrectly."


def get_typed_annotation(annotation: Any, globalns: dict[str, Any]) -> Any:
    if isinstance(annotation, str):
        return eval(annotation, globalns)
    return annotation


def ensure_multipart_is_installed() -> None:
    try:
        import multipart
    except ImportError as exc:
        raise RuntimeError(multipart_not_installed_error) from exc
    if not hasattr(multipart, "__version__"):
        raise RuntimeError(multipart_not_installed_error)

    try:
        from multipart.multipart import parse_options_header
    except ImportError as exc:
        raise RuntimeError(multipart_incorrect_install_error) from exc
    if parse_options_header is None:
        raise RuntimeError(multipart_incorrect_install_error)

