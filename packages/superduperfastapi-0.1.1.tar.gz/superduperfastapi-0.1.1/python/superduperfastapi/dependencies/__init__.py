"""Dependency helper compatibility package."""

