from __future__ import annotations

import io
import os
from typing import Any


class UploadFile:
    def __init__(
        self,
        filename: str | None = None,
        file: Any = b"",
        size: int | None = None,
        content_type: str | None = None,
        **_: Any,
    ) -> None:
        self.filename = filename
        if isinstance(file, bytes):
            file = io.BytesIO(file)
        self.file = file
        self.size = _file_size(file) if size is None else size
        self.content_type = content_type

    async def read(self, size: int = -1) -> bytes:
        return self.file.read(size)

    async def write(self, data: bytes) -> None:
        self.file.write(data)
        if self.size is not None:
            self.size += len(data)

    async def seek(self, offset: int) -> None:
        self.file.seek(offset)

    async def close(self) -> None:
        self.file.close()

    @classmethod
    def _validate(cls, value: Any, _: Any) -> "UploadFile":
        if not isinstance(value, UploadFile):
            raise ValueError(f"Expected UploadFile, received: {type(value)}")
        return value


def _file_size(file: Any) -> int | None:
    try:
        return os.fstat(file.fileno()).st_size
    except Exception:
        pass
    if not hasattr(file, "tell") or not hasattr(file, "seek"):
        return None
    try:
        position = file.tell()
        file.seek(0, os.SEEK_END)
        size = file.tell()
        file.seek(position)
        return size
    except Exception:
        return None


__all__ = ["UploadFile"]
