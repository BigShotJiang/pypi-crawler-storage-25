from superduperfastapi.routing import Route

__all__ = ["Route"]
