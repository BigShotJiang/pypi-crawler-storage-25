# fastapi compatibility shim

This package is not the implementation. It exists so upstream FastAPI tests that
import `fastapi` exercise the from-scratch implementation in `python/superduperfastapi`.

Do not add framework code here. Add implementation code under `python/superduperfastapi`
and re-export only the compatibility surface needed by tests.
