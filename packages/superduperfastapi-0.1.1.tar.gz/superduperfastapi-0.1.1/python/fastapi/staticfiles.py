from superduperfastapi.staticfiles import StaticFiles

__all__ = ["StaticFiles"]
