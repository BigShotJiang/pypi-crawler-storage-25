from superduperfastapi.routing import *  # noqa: F403

_PING_INTERVAL = 15.0
