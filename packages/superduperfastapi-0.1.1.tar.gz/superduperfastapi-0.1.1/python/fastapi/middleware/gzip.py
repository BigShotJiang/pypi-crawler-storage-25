from superduperfastapi.middleware import GZipMiddleware

__all__ = ["GZipMiddleware"]
