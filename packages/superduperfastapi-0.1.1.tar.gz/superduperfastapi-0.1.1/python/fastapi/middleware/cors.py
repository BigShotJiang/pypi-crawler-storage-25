from superduperfastapi.middleware import CORSMiddleware

__all__ = ["CORSMiddleware"]
