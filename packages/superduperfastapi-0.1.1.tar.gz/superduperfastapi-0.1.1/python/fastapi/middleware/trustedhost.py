from superduperfastapi.middleware import TrustedHostMiddleware

__all__ = ["TrustedHostMiddleware"]
