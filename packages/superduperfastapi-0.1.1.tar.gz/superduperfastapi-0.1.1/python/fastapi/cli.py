from __future__ import annotations

import sys
from pathlib import Path


def _default_cli_main(args: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if args is None else args)
    if len(args) >= 2 and args[0] == "dev":
        path = Path(args[1])
        if not path.exists():
            print(f"Path does not exist {path}")
            return 1
    return 0


cli_main = _default_cli_main


def main() -> int:
    if cli_main is None:
        raise RuntimeError("To use the fastapi command, please install fastapi[standard].")
    return cli_main()

