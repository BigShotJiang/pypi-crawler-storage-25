def get_userprofile_pksk_from_slug(slug: str):
    pksk = "userprofile#" + slug
    return {
        "pk": pksk,
        "sk": pksk
    }