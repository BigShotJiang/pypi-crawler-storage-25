from .make_post_sk import make_post_sk
def get_post_pksk(parent_pksk, post_url):
    return {
        "pk": parent_pksk,
        "sk": make_post_sk(post_url)
    }

