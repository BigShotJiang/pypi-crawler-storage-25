def get_entity_from_str(entity):
 
    # Translate the more obvious names to our 
    # obscure internal ones - sorry about that!
    if entity == 'branch':
        entity = 'subwiki'
    elif entity == 'user':
        entity = 'userprofile'
    elif entity == 'follow':
        entity = 'relfollow'
    elif entity == 'trust':
        entity = 'reltrust'
    elif entity == 'block':
        entity = 'userblock'
    elif entity == 'mute':
        entity = 'usermute'


    valid = [
        'comment',
        'post', 
        'reaction',
        'relfollow',
        'reltrust',
        'subwiki', 
        'userblock',
        'usermute',
        'userprofile', 
        'vote',
    ]
    if entity not in valid:
        raise ValueError(f"Invalid entity: {entity}. Must be one of {', '.join(valid)}.")

    return entity
