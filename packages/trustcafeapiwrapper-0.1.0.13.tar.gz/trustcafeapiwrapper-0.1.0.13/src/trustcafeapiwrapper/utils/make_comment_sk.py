def make_comment_sk(comment_url):
    """
    Generates the sk for a comment given the comment url.
    Args:
        comment_url (str): The url of the comment.
    Returns:
        str: The sk for the comment.
    """
    comment_slug = comment_url.strip('/comment/')
    return f"comment#{comment_slug}"