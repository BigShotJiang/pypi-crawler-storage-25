def make_post_sk(post_url):
    """
    Generates the sk for a post given the post url.
    Args:
        post_url (str): The url of the post.

    Returns:
        str: The sk for the post.
    """
    post_slug = post_url.strip('/post/')
    return f"post#{post_slug}"
