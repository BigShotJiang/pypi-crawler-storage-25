from trustcafeapiwrapper.utils import get_parent_pksk_from_path, get_post_pksk, make_comment_sk, make_post_sk

def get_child_spksk_from_paths(parent_path: str, item_path: str):
    
    '''

    If it's a post we want to create a pk/sk like: 
        '{entity}#{parent_slug}' / 'post#{post_slug}'

    If it's a comment we want to create a pk/sk like:
        'post#{post_slug}' / 'comment#{comment_slug}'


    '''
    slug = item_path.split('/')[-1]
    if item_path.startswith('/post'):
        # It's a reaction on a post
        top_level_parent_pk = get_parent_pksk_from_path(parent_path)
        item_pksk = get_post_pksk(top_level_parent_pk, item_path)
        entity = 'post'
    else:
        # It's a reaction on a comment
        item_pksk = {
            'pk': make_post_sk(parent_path),
            'sk': make_comment_sk(item_path)
        }
        entity = 'comment'
        
    return {
        "pk": item_pksk.get('pk', None),
        "sk": item_pksk.get('sk', None),
        "entity": entity,
        "slug": slug
    }