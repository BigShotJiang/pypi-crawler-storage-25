def get_user_slug_from_path(path: str):
    """
    Extracts the user slug from a given path.

    Args:
        path (str): The path from which to extract the user slug.

    Returns:
        str: The extracted user slug.
    """
    if not isinstance(path, str):
        raise ValueError("Input path must be a string.")
    
    if '/userprofile/' in path:
        return path.split('/userprofile/')[-1]
    elif '/user/' in path:
        return path.split('/user/')[-1]
    elif '/' not in path:
        return path
    else:
        return None