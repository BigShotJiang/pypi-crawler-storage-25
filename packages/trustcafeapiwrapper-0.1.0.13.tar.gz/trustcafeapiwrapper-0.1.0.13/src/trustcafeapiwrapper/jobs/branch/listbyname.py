def listbyname(API, lastEvaluatedKey=None) -> dict:
    """
    Fetches a list of branchs from the API by name.

    Returns:
        dict: The list of comments for the post.
    """
    branch_list = API.make_request("GET", "content", f"subwiki", authenticate=True, query_params=lastEvaluatedKey)
    return branch_list