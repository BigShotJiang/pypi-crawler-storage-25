def get(API, branch_slug: str,) -> dict:
    """
    Fetches the branch/subwiki data from the API.

    Args:
        branch_slug (str): Slug of the user whose branch/subwiki to fetch.
    Returns:
        dict: The branch/subwiki data.
    """
    branch_data = API.make_request("GET", "content", f"subwiki/{branch_slug}", authenticate=True)
    return branch_data