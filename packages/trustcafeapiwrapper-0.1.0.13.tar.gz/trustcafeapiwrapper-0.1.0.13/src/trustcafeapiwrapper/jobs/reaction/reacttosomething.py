def reacttosomething(API, payload: dict) -> dict:
    """
    Creates a new reaction in the API.

    Args:
        payload (dict): The data for the new reaction.

        Returns:
            dict: The reaction data.
    """
    reaction_data = API.make_request("POST", "content", "reacttosomething", data=payload, authenticate=True)
    return reaction_data