def getbyparent(API, parent_sk: str) -> dict:
    """
    Fetches the users reactions for a given parent from the API. 
    Args:
        parent_sk (str): sk of the parent to fetch reactions for.
        Returns:
            dict: The list of reactions.
    """
    reaction_list = API.make_request("GET", "content", f"getreactionbysk/{parent_sk}", authenticate=True)
    return reaction_list