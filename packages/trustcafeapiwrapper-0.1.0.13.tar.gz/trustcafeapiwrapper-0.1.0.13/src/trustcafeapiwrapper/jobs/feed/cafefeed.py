def cafefeed(API, lastEvaluatedKey=None):
    """
    List all of a token's user's feed items from their Cafe Feed
    
    Returns:
        A list of feed items.
    """
    feed = API.make_request("GET", "audrey", "feed/foryou", authenticate=True, query_params=lastEvaluatedKey)
    return feed
