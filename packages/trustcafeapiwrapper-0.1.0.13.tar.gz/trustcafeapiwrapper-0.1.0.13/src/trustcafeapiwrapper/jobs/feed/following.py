def followingfeed(API, lastEvaluatedKey=None):
    """
    List all of a token's user's feed items from the users and branches they are following.
    
    Returns:
        A list of feed items.
    """

    
    feed = API.make_request("GET", "audrey", "feed/following", authenticate=True, query_params=lastEvaluatedKey)
    return feed
