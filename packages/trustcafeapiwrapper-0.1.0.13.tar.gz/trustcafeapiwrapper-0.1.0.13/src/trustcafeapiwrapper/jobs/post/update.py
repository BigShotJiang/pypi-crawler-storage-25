def update(API, payload: dict) -> dict:
    """
    Updates an existing post in the API.

    Args:
        payload (dict): The data for the post update.

        Returns:
            dict: The post data.
    """
    post_data = API.make_request("PUT", "content", "post/update", data=payload, authenticate=True)
    return post_data