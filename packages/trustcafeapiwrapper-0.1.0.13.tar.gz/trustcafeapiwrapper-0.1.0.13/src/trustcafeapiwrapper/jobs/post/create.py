def create(API, payload: dict) -> dict:
    """
    Creates a new post in the API.

    Args:
        payload (dict): The data for the new post.

        Returns:
            dict: The post data.
    """
    post_data = API.make_request("POST", "content", "post", data=payload, authenticate=True)
    return post_data