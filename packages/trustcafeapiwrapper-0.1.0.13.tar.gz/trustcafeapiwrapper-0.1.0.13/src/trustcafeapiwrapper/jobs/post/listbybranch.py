def listbybranch(API, branch_slug: str, lastEvaluatedKey=None) -> dict:
    """
    Fetches the list of posts for a given branch from the API.

    Args:
        branch_slug (str): Slug of the branch to fetch posts for.
        lastEvaluatedKey (dict, optional): Key to start fetching posts from.
        Returns:
            dict: The list of posts for the branch.
    """
    post_list = API.make_request("GET", "content", f"post/ref-subwiki/{branch_slug}", authenticate=True, query_params=lastEvaluatedKey)
    return post_list