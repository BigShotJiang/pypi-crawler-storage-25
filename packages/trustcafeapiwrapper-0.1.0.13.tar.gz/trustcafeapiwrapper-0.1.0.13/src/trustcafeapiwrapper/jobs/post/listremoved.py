def listremoved(API, lastEvaluatedKey=None) -> dict:
    """
    Fetches the list of removed posts from the API.

    Args:
        lastEvaluatedKey (dict, optional): Key to start fetching posts from.
        Returns:
            dict: The list of removed posts.
    """
    post_list = API.make_request("GET", "content", f"post/removed", authenticate=True, query_params=lastEvaluatedKey)
    return post_list