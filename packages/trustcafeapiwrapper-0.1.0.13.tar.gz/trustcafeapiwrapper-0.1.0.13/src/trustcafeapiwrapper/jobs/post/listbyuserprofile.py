def listbyuserprofile(API, user_slug: str, lastEvaluatedKey=None) -> dict:
    """
    Fetches the list of posts for a given user profile from the API.

    Args:
        user_slug (str): Slug of the user profile to fetch posts for.
        lastEvaluatedKey (dict, optional): Key to start fetching posts from.
        Returns:
            dict: The list of posts for the user profile.
    """
    # Note there is actually a reference to `/branch` in the API url 
    # and it should be considered for removal because that's confusing
    post_list = API.make_request("GET", "content", f"post/ref-userprofile/branch/{user_slug}", authenticate=True, query_params=lastEvaluatedKey)
    return post_list