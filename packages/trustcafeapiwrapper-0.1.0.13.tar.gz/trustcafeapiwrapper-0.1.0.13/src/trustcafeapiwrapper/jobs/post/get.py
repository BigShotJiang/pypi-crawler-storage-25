def get(API, post_slug: str,) -> dict:
    """
    Fetches the post data from the API.

    Args:
        post_slug (str): Slug of the post to fetch data for.

        Returns:
            dict: The post data.
    """
    post_data = API.make_request("GET", "content", f"post/id/{post_slug}", authenticate=True)
    return post_data