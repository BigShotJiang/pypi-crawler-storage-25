def follow(API, payload: dict) -> dict:
    """
    Creates or updates a follow relationship in the API.

    Args:
        payload (dict): The data for the follow relationship.

        Returns:
            dict: The follow relationship data.
    """
    follow_data = API.make_request("POST", "content", "relfollow", data=payload, authenticate=True)
    return follow_data