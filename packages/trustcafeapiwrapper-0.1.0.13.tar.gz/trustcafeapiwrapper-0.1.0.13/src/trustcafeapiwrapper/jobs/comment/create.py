def create(API, payload: dict) -> dict:
    """
    Creates a new comment in the API.

    Args:
        payload (dict): The data for the new post.

        Returns:
            dict: The comment data.
    """
    comment_data = API.make_request("POST", "content", "commentcreate", data=payload, authenticate=True)
    return comment_data