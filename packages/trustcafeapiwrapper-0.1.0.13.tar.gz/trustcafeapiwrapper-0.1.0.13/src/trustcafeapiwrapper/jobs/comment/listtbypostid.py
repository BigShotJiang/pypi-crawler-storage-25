def listtbypostid(API, post_id: str,) -> dict:
    """
    Fetches the list of comments for a given post ID from the API.

    Args:
        post_id (str): ID of the post to fetch comments for.
        Returns:
            dict: The list of comments for the post.
    """
    comment_list = API.make_request("GET", "content", f"comment/bypostid/{post_id}", authenticate=True)
    return comment_list