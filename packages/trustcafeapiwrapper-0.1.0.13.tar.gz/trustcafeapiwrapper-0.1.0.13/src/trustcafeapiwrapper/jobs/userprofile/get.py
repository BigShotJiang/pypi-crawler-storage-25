def get(API, user_slug: str,) -> dict:
    """
    Fetches the user profile data from the API.

    Args:
        user_slug (str): Slug of the user whose profile to fetch.
    Returns:
        dict: The user profile data.
    """
    profile_data = API.make_request("GET", "content", f"userprofile/{user_slug}", authenticate=True)
    return profile_data