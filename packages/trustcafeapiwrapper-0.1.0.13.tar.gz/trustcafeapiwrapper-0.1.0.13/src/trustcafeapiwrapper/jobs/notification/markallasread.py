def markallasread(API):
    """
    Mark all notifications as read.

    Returns:

    """
    API.make_request("POST", "megaphone", "inbox/markallread", authenticate=True)