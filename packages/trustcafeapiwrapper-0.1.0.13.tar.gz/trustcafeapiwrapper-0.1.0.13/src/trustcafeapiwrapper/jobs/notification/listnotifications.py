def listnotifications(API):
    """
    List all of a token's user's notifications.
    
    Returns:
        A list of notifications.
    """
    notifications = API.make_request("GET", "megaphone", "inbox/notifications", authenticate=True)
    return notifications
