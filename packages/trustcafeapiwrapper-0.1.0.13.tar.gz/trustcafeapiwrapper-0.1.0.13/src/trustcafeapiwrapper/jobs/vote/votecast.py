def votecast(API, payload: dict) -> dict:
    """
    Casts a vote in the API.

    Args:
        payload (dict): The data for the vote.

        Returns:
            dict: The vote data.
    """
    vote_data = API.make_request("POST", "content", "votecast", data=payload, authenticate=True)
    return vote_data