def listbyuserinit(API, userId, lastEvaluatedKey=None) -> dict:
    """
    Fetches a list of a user's trusted users from the API by name.

    Returns:
        dict: The list of trusted users for the user.
    """
    trusted_users_list = API.make_request("GET", "content", f"reltrust/userinit/{userId}", authenticate=True, query_params=lastEvaluatedKey)
    return trusted_users_list