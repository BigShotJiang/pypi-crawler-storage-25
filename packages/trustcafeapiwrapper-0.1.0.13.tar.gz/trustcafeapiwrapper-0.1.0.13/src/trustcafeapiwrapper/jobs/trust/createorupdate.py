def createorupdate(API, payload: dict) -> dict:
    """
    Creates or updates a trust relationship in the API.

    Args:
        payload (dict): The data for the trust relationship.

        Returns:
            dict: The trust relationship data.
    """
    trust_data = API.make_request("PUT", "content", "reltrust", data=payload, authenticate=True)
    return trust_data