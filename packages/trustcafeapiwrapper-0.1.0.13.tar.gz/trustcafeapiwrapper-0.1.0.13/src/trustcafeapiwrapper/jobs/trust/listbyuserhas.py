def listbyuserhas(API, userId, lastEvaluatedKey=None) -> dict:
    """
    Fetches a list of users who have trusted a specific user from the API by name.

    Returns:
        dict: The list of users who have trusted the user.

    """
    trusted_users_list = API.make_request("GET", "content", f"reltrust/userhas/{userId}", authenticate=True, query_params=lastEvaluatedKey)
    return trusted_users_list