from trustcafeapiwrapper.utils.get_entity_from_str import get_entity_from_str

def follow(
        entity: str,
        is_following: bool,
        parent_slug: str,
    ):
    """
    Creates new or update existing follow entry in the API.

    Args:
        entity (str): The type of entity to follow (userprofile | subwiki).
        is_following (bool): Indicates whether the entity is being followed.
        parent_slug (str): The slug of the parent entity.

    Returns:
        dict: A dictionary containing the job name and payload for creating the post 
        that will be processed by the API client wrapper function.
    """
    entity = get_entity_from_str(entity)

    itemPKSK = f"{entity}#{parent_slug}"

    return {
            "job_function": "follow.follow",            
            "payload": {
                "isFollowing": is_following,
                "parent": {
                    "pk": itemPKSK,
                    "sk": itemPKSK
                },
                "followType": entity,
                "parentSlug": parent_slug,
                "preferences": {
                    "notification": True,
                    "emailNew": False,
                    "emailDigest": True
                }
            }
        }
