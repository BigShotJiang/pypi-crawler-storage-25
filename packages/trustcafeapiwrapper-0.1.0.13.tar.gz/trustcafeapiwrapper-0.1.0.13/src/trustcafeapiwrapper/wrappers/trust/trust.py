from trustcafeapiwrapper.utils import get_user_slug_from_path, get_userprofile_pksk_from_slug

def trust(
        trustLevel: str, 
        userprofile_path: str
    ):
    """
    Creates new or update existing trust entry in the API.

    Args:
        
    Returns:
        dict: A dictionary containing the job name and payload for creating the post 
        that will be processed by the API client wrapper function.
    """
    userProfileSlug = get_user_slug_from_path(userprofile_path)
    userPKSK = get_userprofile_pksk_from_slug(userProfileSlug)
    return {
            "job_function": "trust.createorupdate",            
            "payload": {
                "trustLevel": trustLevel,                
                "parentSlug": userProfileSlug,
                "parent": userPKSK
            }
        }
