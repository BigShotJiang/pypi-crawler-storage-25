
from trustcafeapiwrapper.utils.get_parent_pksk_from_path import get_parent_pksk_from_path
from trustcafeapiwrapper.utils.get_post_pksk import get_post_pksk
def create_comment(
        comment_text:str, 
        post_slug:str|None=None, 
        parent_path:str|None=None, 
        post_key:dict|None=None, 
        blur_label:str|None=None, 
        version:int=3
    ):
    """
    Creates a new comment.

    Args:

        comment_text (str): The text content of the comment.
        post_slug (str, optional): The slug of the post to which the comment belongs.
        parent_path (str, optional): The parent path for the comment, in the format 'userprofile/slug' or 'subwiki/slug'.
        post_key (dict, optional): A dictionary containing the primary key (pk) and sort key (sk) of the post.
        blur_label (str, optional): An optional label for blurring the comment content.
        version (int, optional): The version of the comment structure to use, default is 3.

    Returns:
        dict: A dictionary containing the job name and payload for creating the comment 
        that will be processed by the API client wrapper function.
    """
    if post_key is not None:
        post_pksk = {
            "pk": post_key.get('pk'),
            "sk": post_key.get('sk')
        }
    elif parent_path is not None and post_slug is not None:
        parent_pksk = get_parent_pksk_from_path(parent_path)
        post_pksk = get_post_pksk(parent_pksk, post_slug)
    else:
        raise ValueError("Either post_key or both parent_path and post_slug must be provided.")
    
    if comment_text is None or comment_text.strip() == "":
        raise ValueError("Comment text cannot be empty.")
    
    return {
            "job_function": "comment.create",            
            "payload": {
                "blurLabel": blur_label,
                "commentText": comment_text,
                "parent": {
                    "pk": post_pksk['pk'],
                    "sk": post_pksk['sk'],
                    "slug": post_pksk.get('sk', '').replace('post#', ''),
                },
                "topLevel": {
                    "pk": post_pksk['pk'],
                    "sk": post_pksk['sk']
                },
                "version": version
            }
        }