from trustcafeapiwrapper.utils.get_parent_pksk_from_path import get_parent_pksk_from_path

def create_post(
        post_text:str, 
        parent_path:str|None='/', 
        blur_label:str|None=None, 
        card_url:str|None=None, 
        collaborative:bool=False
    ):
    """
    Creates a new post.

    Args:
        post_text (str): The text content of the post.
        parent_path (str, optional): The parent path for the post, default is None.
        blur_label (str, optional): An optional label for blurring the post content.
        card_url (str, optional): An optional URL to include as a card in the post.
        collaborative (bool, optional): Whether the post is collaborative, default is False.

    Returns:
        dict: A dictionary containing the job name and payload for creating the post 
        that will be processed by the API client wrapper function.
    """

    parent_pksk = get_parent_pksk_from_path(parent_path)


    return {
            "job_function": "post.create",            
            "payload": {
                "blurLabel": blur_label,
                "cardUrl": card_url,
                "postText": post_text,
                "collaborative": collaborative,
                "parent": {
                    "pk": parent_pksk,
                    "sk": parent_pksk
                }
            }
        }