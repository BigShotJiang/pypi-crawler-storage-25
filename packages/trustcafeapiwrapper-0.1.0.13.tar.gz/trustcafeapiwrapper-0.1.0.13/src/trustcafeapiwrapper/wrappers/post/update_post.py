from trustcafeapiwrapper.utils import get_post_pksk, get_parent_pksk_from_path

def update_post( 
        post_text:str, 
        post_path:str|None=None,
        parent_path:str|None='/',
        post_key:dict|None=None, 
        blur_label:str|None=None, 
        card_url:str|None=None, 
        collaborative:bool=False
    ):
    """
    Updates an existing post.
    
    Args:
        post_slug (str): The slug of the post to update.
        post_text (str): The new text for the post.
        post_path (str, optional): The path of the post to update. Defaults to None.
        parent_path (str, optional): The parent path for the post. Defaults to '/'.
        post_key (dict, optional): A dictionary containing the primary key (pk) and sort key (sk) of the post. Defaults to None.
        blur_label (str, optional): The blur label for the post. Defaults to None.
        card_url (str, optional): The card URL for the post. Defaults to None.
        collaborative (bool, optional): Whether the post is collaborative. Defaults to False.

        Returns:
            dict: The updated post data.
    """
    if post_key is not None:
        post_pksk = {
            'pk': post_key.get('pk', None),
            'sk': post_key.get('sk', None)
        }
    elif post_path is not None and parent_path is not None:
        parent_pksk = get_parent_pksk_from_path(parent_path)
        post_pksk = get_post_pksk(parent_pksk, post_path)
    else:
        raise ValueError("Either post_path and parent_path or post_key must be provided.")
        

    if post_text is None:
        raise ValueError("post_text is required.")
    

    payload = {
        "key": {
            "pk": post_pksk.get('pk', None),
            "sk": post_pksk.get('sk', None)
        },
        "postSlug": post_pksk.get('sk', '').replace('post#', ''),
        "postText": post_text
    }
    if collaborative is not None:
        payload["collaborative"] = collaborative

    if blur_label is not None:
        payload["blurLabel"] = blur_label
    
    if card_url is not None:
        payload["cardUrl"] = card_url

    return {
            "job_function": "post.update",            
            "payload": payload
        }