from trustcafeapiwrapper.utils import get_child_spksk_from_paths

def votecast(
        vote: str, 
        parent_path: str|None=None, 
        item_path: str|None=None,
        item_key: dict|None=None
    ):
    """
    Creates a new vote in the API.

    Args:
        
    Returns:
        dict: A dictionary containing the job name and payload for creating the post 
        that will be processed by the API client wrapper function.
    """
    if item_key is not None:
        parent = {
            'pk': item_key.get('pk', None),
            'sk': item_key.get('sk', None),
            'slug': item_key.get('sk', '').split('#')[-1],
            'entity': item_key.get('sk', '').split('#')[0]
        }
    else:
        parent = get_child_spksk_from_paths(parent_path, item_path)
    
    return {
            "job_function": "vote.votecast",            
            "payload": {
                "vote": vote,                
                "parent": parent
            }
        }
