
from trustcafeapiwrapper.utils import get_child_spksk_from_paths
def react(
        reaction_type: str, 
        parent_path: str|None=None, 
        item_path: str|None=None, 
        item_key: dict|None=None
    ):
    """
    React to something.  ie a post or a comment.
    This is one endpoint for creating, updating and deleting reactions.  
    The logic is handled in the backend.

    Args:
        
    Returns:
        dict: A dictionary containing the job name and payload for creating the post 
        that will be processed by the API client wrapper function.
    """
    if item_key is not None:
        parent = {
            'pk': item_key.get('pk', None),
            'sk': item_key.get('sk', None)
        }
    else:
        parent = get_child_spksk_from_paths(parent_path, item_path)
    return {
            "job_function": "reaction.reacttosomething",            
            "payload": {
                "reaction": reaction_type,                
                "parent": parent
            }
        }
