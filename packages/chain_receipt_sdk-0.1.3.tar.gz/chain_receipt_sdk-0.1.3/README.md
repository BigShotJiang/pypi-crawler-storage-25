# chain-receipt-sdk

Emit, verify, replay, and chain **Chain-Receipts** (v1.0.0) from any
Python LLM-agent loop. Drop-in callback for LangChain, plus a
framework-agnostic `ReceiptBuilder` for raw API loops.

Verifiable record of every LLM call: emit a signed Receipt, replay it
against any vendor, and check whether the chain holds.

```bash
pip install chain-receipt-sdk
chain-receipt verify sha256:<hash>
chain-receipt replay sha256:<hash> --n 10
```

## 60-second demo

```python
from chain_receipt_sdk import ReceiptBuilder, ClientInfo, Interaction
from chain_receipt_core import compute_text_hash, compute_tool_calls_hash, generate_keypair

sk, pub = generate_keypair()
client = ClientInfo(
    name="my-agent",
    version="0.1.0",
    platform="python-3.12",
    emitter_pubkey=f"ed25519:{pub}",
)
b = ReceiptBuilder(client=client, private_key=sk, chain_seed=pub.encode())

inter = Interaction(
    vendor="anthropic",
    model="claude-sonnet-4-5",
    temperature=0.0,
    system_prompt_hash=compute_text_hash("you are helpful"),
    prompt_hash=compute_text_hash("hello"),
    response_hash=compute_text_hash("hi"),
    tool_calls_hash=compute_tool_calls_hash([]),
    n_tool_calls=0,
    latency_ms=120,
)
r = b.build(interaction=inter)
print(r.receipt_id, r.chain.sequence_number)
```

## LangChain callback

```python
from langchain_core.runnables import RunnableLambda
from chain_receipt_sdk.callback import ReceiptCallback

cb = ReceiptCallback(
    client_name="my-langchain-agent",
    vendor="anthropic",
    model="claude-sonnet-4-5",
)
chain = RunnableLambda(lambda x: f"echo: {x}")
chain.invoke("hello", config={"callbacks": [cb]})

receipts = cb.receipts
print(f"emitted {len(receipts)} Receipts")
```

## CLI

```bash
chain-receipt status                       # local chain head + count
chain-receipt verify sha256:<hash>         # validate signature + chain link
chain-receipt replay sha256:<hash> --n 10  # re-run captured prompt N times
chain-receipt chain --since 2026-04-25     # list Receipts since timestamp
chain-receipt publish sha256:<hash>        # push to chain-determinism.org
```

## Local chain storage

Receipts are written to `~/.chain-receipt/chain.jsonl` (one JSON per line)
when emitted via `ReceiptCallback` or `ReceiptBuilder.build(persist=True)`.
The `chain_receipt_sdk.chain.LocalChain` reader/writer is the public API
for that file.

## Replay determinism

`chain_receipt_sdk.replay` re-runs the captured prompt against the
same vendor + model + temperature N times and reports
`final_answer_consistent`, `tool_seq_identical`, `tool_args_identical`,
and a Wilson 95% CI for the divergence rate. Integration test gate
in `tests/test_replay.py`.

## License

MIT — see `LICENSE`.
