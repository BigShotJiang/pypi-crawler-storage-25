"""Smoke tests for ReceiptCallback.

Tests the callback in two modes:
  1. Manual emit (no LangChain dependency)
  2. LangChain BaseCallbackHandler hooks (only if langchain-core installed)
"""
from __future__ import annotations

import pytest

from chain_receipt_core import (
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
    verify_chain,
)


# ----------------------------------------------------------------------------
# Manual emit path (always available)
# ----------------------------------------------------------------------------


def test_callback_manual_emit():
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        temperature=0.0,
    )
    r = cb.emit(prompt="hello", response="hi", system_prompt="be brief")
    assert r.interaction.vendor == "anthropic"
    assert r.interaction.model == "claude-sonnet-4-5"
    assert r.interaction.prompt_hash == compute_text_hash("hello")
    assert r.interaction.response_hash == compute_text_hash("hi")
    assert r.interaction.system_prompt_hash == compute_text_hash("be brief")
    assert r.interaction.n_tool_calls == 0
    assert r.signature is not None
    assert len(cb.receipts) == 1


def test_callback_chain_links():
    """Sequential emits MUST chain: prev_receipt_hash == receipt_hash(prev)."""
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="openai",
        model="gpt-4.1",
    )
    r0 = cb.emit(prompt="q1", response="a1")
    r1 = cb.emit(prompt="q2", response="a2")
    r2 = cb.emit(prompt="q3", response="a3")

    assert r0.chain.sequence_number == 0
    assert r1.chain.sequence_number == 1
    assert r2.chain.sequence_number == 2

    assert r1.chain.prev_receipt_hash == receipt_hash(r0)
    assert r2.chain.prev_receipt_hash == receipt_hash(r1)
    assert r0.chain.chain_root_hash == r1.chain.chain_root_hash == r2.chain.chain_root_hash

    res = verify_chain([r0, r1, r2])
    assert res.ok, res.errors


def test_callback_with_tool_calls():
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    seq = [
        {"name": "lookup", "args": {"q": "x"}},
        {"name": "final_answer", "args": {"answer": "42"}},
    ]
    r = cb.emit(prompt="?", response="42", tool_calls=seq)
    assert r.interaction.n_tool_calls == 2
    assert r.interaction.tool_calls_hash == compute_tool_calls_hash(seq)


def test_callback_persist_to_local_chain(tmp_path, monkeypatch):
    """persist=True must write to ~/.chain-receipt/chain.jsonl."""
    monkeypatch.setenv("CHAIN_RECEIPT_DIR", str(tmp_path / "chain"))

    from chain_receipt_sdk.callback import ReceiptCallback
    from chain_receipt_sdk.chain import LocalChain

    chain = LocalChain()
    cb = ReceiptCallback(
        client_name="test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        persist=True,
        local_chain=chain,
    )
    cb.emit(prompt="q1", response="a1")
    cb.emit(prompt="q2", response="a2")

    persisted = chain.read_all()
    assert len(persisted) == 2
    assert persisted[1].chain.sequence_number == 1


def test_callback_capture_payload():
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        capture_payload=True,
    )
    r = cb.emit(prompt="hello", response="world", system_prompt="sys")
    assert r.optional_payload is not None
    assert r.optional_payload["prompt"] == "hello"
    assert r.optional_payload["response"] == "world"
    assert r.optional_payload["system_prompt"] == "sys"


# ----------------------------------------------------------------------------
# LangChain hook path (skipped if langchain-core missing)
# ----------------------------------------------------------------------------


lc = pytest.importorskip("langchain_core")


def test_callback_runnable_smoke():
    """Wrap a fake LangChain runnable and confirm a Receipt is emitted."""
    from langchain_core.runnables import RunnableLambda
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="lc-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )

    # RunnableLambda doesn't trigger on_llm_start / on_llm_end on its own —
    # those fire when an actual LLM is invoked. We exercise the hooks
    # directly to keep the test free of vendor SDK + network calls.

    cb.on_llm_start(
        serialized={"name": "FakeLLM"},
        prompts=["hello world"],
    )
    # Simulate one tool call between LLM start and end
    cb.on_tool_start(serialized={"name": "calc"}, input_str='{"x": 1}')

    # Simulate an LLMResult-shaped response
    class _Gen:
        text = "the answer is 42"

    class _LLMResult:
        generations = [[_Gen()]]

    cb.on_llm_end(_LLMResult())

    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.n_tool_calls == 1
    assert r.interaction.prompt_hash == compute_text_hash("hello world")
