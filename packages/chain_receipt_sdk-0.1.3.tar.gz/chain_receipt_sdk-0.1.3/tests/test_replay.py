"""CRITICAL integration test: replay hash logic must be byte-identical
to the harness's reference replay implementation.

Receipts emitted via the SDK must be byte-identical to Receipts measured
by the reference harness, or downstream comparisons silently break.

Skips gracefully if the reference jsonl is not in the checkout.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from chain_receipt_core import (
    Interaction,
    ReceiptBuilder,
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
    verify_chain,
)
from chain_receipt_sdk.replay import (
    ReplayResult,
    _seq_full,
    _seq_op_keys,
    compare_runs,
    replay_receipt,
)

JSONL = (
    Path(__file__).resolve().parents[2]
    / "results/benchmarks/replay/multivendor_anthropic.jsonl"
)


def _harness_seq_full(seq):
    """Reproduce the reference `_seq_full` algorithm byte-for-byte."""
    parts = []
    for s in seq:
        args = s.get("args") or {}
        parts.append(s.get("name") + ":" + json.dumps(args, sort_keys=True, default=str))
    return "||".join(parts)


def _harness_hash(seq):
    s = _harness_seq_full(seq)
    return "sha256:" + hashlib.sha256(s.encode("utf-8")).hexdigest()


# ----------------------------------------------------------------------------
# Pure unit tests on _seq_full / _seq_op_keys
# ----------------------------------------------------------------------------


def test_seq_full_empty():
    assert _seq_full([]) == ""


def test_seq_full_simple():
    seq = [{"name": "add", "args": {"x": 1, "y": 2}}]
    # sort_keys=True → x first, y second
    assert _seq_full(seq) == 'add:{"x": 1, "y": 2}'


def test_seq_full_separator():
    seq = [
        {"name": "a", "args": {}},
        {"name": "b", "args": {}},
    ]
    assert _seq_full(seq) == "a:{}||b:{}"


def test_seq_full_matches_harness_signature():
    """Mirror of paper4 _seq_full byte-for-byte for a representative case."""
    seq = [
        {"name": "intersect", "args": {"a": "x", "b": "y"}, "bound_to": "v1"},
        {"name": "final_answer", "args": {"answer": "42"}},
    ]
    assert _seq_full(seq) == _harness_seq_full(seq)


def test_compute_tool_calls_hash_matches_seq_full():
    """SDK's compute_tool_calls_hash must match the harness's hash output."""
    seq = [
        {"name": "intersect", "args": {"a": "x", "b": "y"}},
        {"name": "final_answer", "args": {"answer": "42"}},
    ]
    assert compute_tool_calls_hash(seq) == _harness_hash(seq)


def test_seq_op_keys_dict():
    seq = [{"name": "f", "args": {"b": 2, "a": 1}}]
    assert _seq_op_keys(seq) == (("f", ("a", "b")),)


def test_seq_op_keys_list():
    seq = [{"name": "f", "args": [1, 2, 3]}]
    assert _seq_op_keys(seq) == (("f", ("<list>", 3)),)


# ----------------------------------------------------------------------------
# CRITICAL: byte-identical against real paper5 rows
# ----------------------------------------------------------------------------


@pytest.mark.skipif(not JSONL.exists(), reason="paper5 jsonl not in checkout")
def test_replay_hash_byte_identical_paper5():
    """SDK's _seq_full and compute_tool_calls_hash must match the paper5
    harness on real per-run rows. This is the methodology gate."""
    rows: list[dict] = []
    with JSONL.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
            if len(rows) >= 5:
                break

    assert len(rows) == 5, "expected 5 rows from paper5 jsonl"

    for row in rows:
        seq = row.get("tool_call_sequence", [])

        # 1. _seq_full string is byte-identical
        sdk_str = _seq_full(seq)
        harness_str = _harness_seq_full(seq)
        assert sdk_str == harness_str, (
            f"SDK _seq_full diverges for query_id={row.get('query_id')}\n"
            f"  sdk:     {sdk_str!r}\n"
            f"  harness: {harness_str!r}"
        )

        # 2. compute_tool_calls_hash hash is byte-identical
        sdk_hash = compute_tool_calls_hash(seq)
        harness_hash_v = _harness_hash(seq)
        assert sdk_hash == harness_hash_v, (
            f"compute_tool_calls_hash diverges for query_id={row.get('query_id')}\n"
            f"  sdk:     {sdk_hash}\n"
            f"  harness: {harness_hash_v}"
        )


@pytest.mark.skipif(not JSONL.exists(), reason="paper5 jsonl not in checkout")
def test_compare_runs_matches_harness_semantics():
    """compare_runs() should match paper4 semantics on a real (model, query) cell."""
    rows: list[dict] = []
    with JSONL.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
            if len(rows) >= 50:  # gather enough to find a duplicated cell
                break

    # Group by (model, query_id, temperature) — same key paper5 uses
    by_key: dict[tuple, list] = {}
    for r in rows:
        key = (r.get("model"), r.get("query_id"), float(r.get("temperature", 0.0)))
        by_key.setdefault(key, []).append(r)

    # Pick the largest cell
    cell = max(by_key.values(), key=len)
    assert len(cell) >= 2, "need at least 2 runs to compare"

    cmp = compare_runs(cell)
    # Sanity: keys should match the paper4 contract
    for k in (
        "final_answer_consistent",
        "tool_seq_identical",
        "tool_args_identical",
        "rationale_identical",
        "tool_count_min",
        "tool_count_max",
        "tool_count_range",
        "unique_answers",
        "n_runs",
    ):
        assert k in cmp, f"compare_runs missing key {k!r}"
    assert cmp["n_runs"] == len(cell)

    # Each tool_args_identical → all _seq_full strings equal
    seqs = [_seq_full(r.get("tool_call_sequence", [])) for r in cell]
    assert cmp["tool_args_identical"] == all(s == seqs[0] for s in seqs)


# ----------------------------------------------------------------------------
# replay_receipt without runner — privacy-preserving fallback
# ----------------------------------------------------------------------------


def test_replay_skipped_when_no_payload(client_info, keypair):
    """A Receipt with optional_payload=None cannot be replayed."""
    sk, _pub = keypair
    b = ReceiptBuilder(
        client=client_info,
        private_key=sk,
        verifier_url=None,
        chain_seed=b"test",
    )
    inter = Interaction(
        vendor="anthropic",
        model="claude-sonnet-4-5",
        temperature=0.0,
        system_prompt_hash=compute_text_hash(""),
        prompt_hash=compute_text_hash("hi"),
        response_hash=compute_text_hash("hello"),
        tool_calls_hash=compute_tool_calls_hash([]),
        n_tool_calls=0,
        latency_ms=10,
    )
    r = b.build(interaction=inter, optional_payload=None)

    res = replay_receipt(r, n=5)
    assert isinstance(res, ReplayResult)
    assert res.method == "replay-skipped"
    assert res.divergence_rate is None
    assert "privacy-preserving" in (res.note or "")


def test_replay_skipped_when_no_runner(client_info, keypair):
    """A Receipt WITH a payload but no runner also reports replay-skipped."""
    sk, _pub = keypair
    b = ReceiptBuilder(
        client=client_info,
        private_key=sk,
        verifier_url=None,
        chain_seed=b"test",
    )
    inter = Interaction(
        vendor="anthropic",
        model="claude-sonnet-4-5",
        temperature=0.0,
        system_prompt_hash=compute_text_hash("sys"),
        prompt_hash=compute_text_hash("hi"),
        response_hash=compute_text_hash("hello"),
        tool_calls_hash=compute_tool_calls_hash([]),
        n_tool_calls=0,
        latency_ms=10,
    )
    r = b.build(interaction=inter, optional_payload={"prompt": "hi", "system_prompt": "sys"})

    res = replay_receipt(r, n=5)
    assert res.method == "replay-skipped"
    assert "no runner" in (res.note or "")


def test_replay_with_injected_runner(client_info, keypair):
    """Smoke: synthetic runner returns identical outputs N times."""
    sk, _pub = keypair
    b = ReceiptBuilder(
        client=client_info,
        private_key=sk,
        verifier_url=None,
        chain_seed=b"test",
    )
    inter = Interaction(
        vendor="anthropic",
        model="claude-sonnet-4-5",
        temperature=0.0,
        system_prompt_hash=compute_text_hash(""),
        prompt_hash=compute_text_hash("hi"),
        response_hash=compute_text_hash("hello"),
        tool_calls_hash=compute_tool_calls_hash([]),
        n_tool_calls=0,
        latency_ms=10,
    )
    r = b.build(interaction=inter, optional_payload={"prompt": "hi"})

    def _det_runner(payload):
        return {
            "final_answer_norm": "42",
            "rationale": "the answer is 42",
            "tool_call_sequence": [{"name": "calc", "args": {"x": 1}}],
            "n_tool_calls": 1,
        }

    res = replay_receipt(r, n=4, runner=_det_runner)
    assert res.method == "byok-replay-v1"
    assert res.n_replays == 4
    assert res.divergence_rate == 0.0
    assert res.final_answer_consistent is True
    assert res.tool_args_identical is True


def test_replay_with_diverging_runner(client_info, keypair):
    """Runner returns different outputs → divergence_rate > 0."""
    sk, _pub = keypair
    b = ReceiptBuilder(
        client=client_info,
        private_key=sk,
        verifier_url=None,
        chain_seed=b"test",
    )
    inter = Interaction(
        vendor="anthropic",
        model="claude-sonnet-4-5",
        temperature=0.0,
        system_prompt_hash=compute_text_hash(""),
        prompt_hash=compute_text_hash("hi"),
        response_hash=compute_text_hash("hello"),
        tool_calls_hash=compute_tool_calls_hash([]),
        n_tool_calls=0,
        latency_ms=10,
    )
    r = b.build(interaction=inter, optional_payload={"prompt": "hi"})

    counter = {"i": 0}

    def _diverge_runner(payload):
        counter["i"] += 1
        return {
            "final_answer_norm": str(counter["i"] % 2),
            "rationale": "...",
            "tool_call_sequence": [{"name": "calc", "args": {"x": counter["i"] % 2}}],
            "n_tool_calls": 1,
        }

    res = replay_receipt(r, n=4, runner=_diverge_runner)
    assert res.divergence_rate is not None
    assert res.divergence_rate > 0.0
    assert res.tool_args_identical is False
