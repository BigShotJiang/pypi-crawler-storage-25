#!/usr/bin/env python3
"""Core utilities for folder synchronization."""

import hashlib
from pathlib import Path


def get_all_folders(repo_path, source, ignore_hidden=False):
    """Get all subdirectories and top-level files in source folder.

    Args:
        repo_path: Path to the repository
        source: Subdirectory name within the repo
        ignore_hidden: If True, skip hidden files and directories (starting with '.')
    """
    source_path = Path(repo_path) / source
    if not source_path.exists():
        return []
    return [d.name for d in source_path.iterdir() if not (ignore_hidden and _is_hidden(d))]


def _is_hidden(path):
    """Check if a path is hidden (starts with dot)."""
    return path.name.startswith(".")


def dir_hash(path, ignore_hidden=False):
    """Compute a hash of all files in a directory (recursive), or a single file.

    Args:
        path: Path to file or directory
        ignore_hidden: If True, skip hidden files and directories (starting with '.')
    """
    path = Path(path)
    if not path.exists():
        return None
    hasher = hashlib.sha256()
    if path.is_file():
        if ignore_hidden and _is_hidden(path):
            return hasher.hexdigest()
        hasher.update(path.name.encode())
        hasher.update(path.read_bytes())
    else:
        for item in sorted(path.rglob("*")):
            if ignore_hidden and _is_hidden(item):
                continue
            if item.is_file():
                hasher.update(item.name.encode())
                hasher.update(item.read_bytes())
    return hasher.hexdigest()


def has_changed(src, dst, ignore_hidden=False):
    """Check if source directory has changed compared to destination."""
    src_hash = dir_hash(src, ignore_hidden)
    dst_hash = dir_hash(dst, ignore_hidden)
    if src_hash is None:
        return False
    if dst_hash is None:
        return True
    return src_hash != dst_hash


def resolve_folders(repo_config, ignore_hidden=False):
    """Resolve folder/item list from config, handling wildcard."""
    # Support both "items" (new) and "folders" (legacy) keys
    folders = repo_config.get("items", repo_config.get("folders", []))
    if folders == "*" or (
        isinstance(folders, list) and "*" in folders and len(folders) == 1
    ):
        return get_all_folders(
            repo_config["path"], repo_config.get("source", repo_config.get("entry", "")), ignore_hidden
        )
    return folders


def expand_sources(repo_config, ignore_hidden=False):
    """Expand a repo config into (source, folder, target_override) tuples.

    Supports two formats:
    - Legacy: repo has single 'source' and 'items' keys
    - New: repo has a 'sources' list, each with 'source', 'items', and optional 'target'

    Args:
        repo_config: Repository configuration dict
        ignore_hidden: If True, skip hidden files and directories when expanding wildcards

    Yields:
        tuples of (source_path, folder_name, target_override_or_None)
    """
    if "sources" in repo_config:
        # New multi-source format
        repo_path = repo_config["path"]
        for src_cfg in repo_config["sources"]:
            source = src_cfg.get("source", "")
            items = src_cfg.get("items", [])
            target_override = src_cfg.get("target")
            if items == "*" or (isinstance(items, list) and "*" in items and len(items) == 1):
                items = get_all_folders(repo_path, source, ignore_hidden)
            for folder in items:
                yield source, folder, target_override
    else:
        # Legacy single-source format
        source = repo_config.get("source", repo_config.get("entry", ""))
        for folder in resolve_folders(repo_config, ignore_hidden):
            yield source, folder, None
