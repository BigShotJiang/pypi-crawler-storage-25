#!/usr/bin/env python3
"""Sync operations for folder synchronization."""

import os
import shutil
import subprocess
from pathlib import Path
from shutil import ignore_patterns

from syncware.core import dir_hash, expand_sources, has_changed
from syncware.git import resolve_repo_path
from syncware.logging_ import print_msg


def _is_hidden(path):
    """Check if a path is hidden (starts with dot)."""
    return path.name.startswith(".")


def _clean_extra_files(source_path, dest_path, dry=False, ignore_hidden=False):
    """Remove files in dest that don't exist in source (recursive).

    Args:
        source_path: Source directory
        dest_path: Destination directory
        dry: If True, only report what would be removed
        ignore_hidden: If True, skip hidden files and directories
    """
    if not dest_path.exists():
        return
    # Collect extra files and directories recursively
    # Use rglob to find all items, sort in reverse to process files before dirs
    items = sorted(dest_path.rglob("*"), reverse=True)
    for item in items:
        if ignore_hidden and _is_hidden(item):
            continue
        src_item = source_path / item.relative_to(dest_path)
        if not src_item.exists():
            print_msg(f"remove extra: {item}", "warning")
            if not dry:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()


def sync_repo(repo, config, global_target, dry=False):
    """Sync a single repo's folders to its target(s)."""
    repo_path = resolve_repo_path(repo)
    repo_target_str = repo.get("target", global_target)

    # Normalize target to a list (support both string and list formats)
    if isinstance(repo_target_str, str):
        repo_targets = [repo_target_str]
    else:
        repo_targets = list(repo_target_str)

    repo_targets = [os.path.expanduser(t) for t in repo_targets]
    repo_name = repo.get("name", "unknown")

    # Get ignore_hidden settings (default False)
    ignore_hidden_file = repo.get(
        "ignore_hidden_file", config.get("ignore_hidden_file", False)
    )
    ignore_hidden_folder = repo.get(
        "ignore_hidden_folder", config.get("ignore_hidden_folder", False)
    )
    ignore_hidden = ignore_hidden_file and ignore_hidden_folder

    if not repo_path.exists():
        print_msg(f"Repo not found: {repo_path}", "warning")
        return 0

    if not dry:
        for target in repo_targets:
            Path(target).mkdir(parents=True, exist_ok=True)

    configured = []

    for source, folder, target_override in expand_sources(repo, ignore_hidden):
        folder_path = repo_path / source / folder

        if not folder_path.exists():
            print_msg(f"Folder not found: {folder_path}", "warning")
            continue

        # Per-source target override, else fall back to repo/global target
        if target_override:
            effective_targets = [os.path.expanduser(target_override)]
        else:
            effective_targets = repo_targets

        for target in effective_targets:
            dest = Path(target) / folder
            dest_display = f"{target}/{folder}"
            configured.append((dest, folder_path))

            # Determine if sync is needed and cache the result
            if not dest.exists():
                needs_sync = True
                status = "create"
            else:
                changed = has_changed(folder_path, dest, ignore_hidden)
                needs_sync = changed
                status = "update" if changed else "unchanged"

            print_msg(
                f"{status}: {dest_display}",
                "success"
                if status == "create"
                else "warning"
                if status == "update"
                else "info",
            )

            if not dry and needs_sync:
                if folder_path.is_file():
                    if not (ignore_hidden and _is_hidden(folder_path)):
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(folder_path, dest)
                else:
                    copy_kwargs = {"dirs_exist_ok": True}
                    if ignore_hidden:
                        copy_kwargs["ignore"] = ignore_patterns(".*", "*/*/.*")
                    shutil.copytree(folder_path, dest, **copy_kwargs)

            # Clean extra files in target that don't exist in source
            clean_item_content = repo.get("clean_item_content", config.get("clean_item_content", False))
            if clean_item_content and dest.exists() and dest.is_dir():
                _clean_extra_files(folder_path, dest, dry, ignore_hidden)

    keep_existing_item = repo.get("keep_existing_item", config.get("keep_existing_item", True))

    if not keep_existing_item:
        for target in repo_targets:
            target_path = Path(target)
            if not target_path.exists():
                continue
            existing_dirs = []
            for item in target_path.iterdir():
                if item.is_dir():
                    existing_dirs.append(item)

            for existing in existing_dirs:
                is_configured = any(
                    dest.name == existing.name for dest, _ in configured
                )
                if not is_configured:
                    print_msg(f"remove {target}/{existing.name}", "warning")
                    if not dry:
                        shutil.rmtree(existing)

    return len(configured)


def cmd_sync(config, dry=False, verbose=False):
    """Sync all configured repos to their targets."""
    global_target = config.get("target", "./output")

    total = 0
    for repo in config.get("repos", []):
        repo_name = repo.get("name", "unknown")
        repo_target = repo.get("target", global_target)
        if isinstance(repo_target, list):
            target_display = ", ".join(repo_target)
        else:
            target_display = repo_target
        print_msg(f"Syncing {repo_name} -> {target_display}...", "info")
        total += sync_repo(repo, config, global_target, dry=dry)

    if dry:
        print_msg("Dry run complete - no changes made", "info")
    else:
        print_msg(f"Synced {total} folder(s)", "success")


def cmd_update(config, dry=False, verbose=False):
    """Update repos via git pull and sync."""
    for repo in config.get("repos", []):
        repo_path = resolve_repo_path(repo)
        repo_name = repo["name"]

        if not repo_path.exists():
            print_msg(f"Repo not found: {repo_path}", "warning")
            continue

        print_msg(f"Updating {repo_name}...", "info")

        try:
            result = subprocess.run(
                ["git", "pull", "--ff-only"],
                cwd=repo_path,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                print_msg(f"Updated {repo_name}", "success")
                if verbose:
                    print(result.stdout.strip())
            else:
                print_msg(
                    f"Git pull failed for {repo_name}: {result.stderr.strip()}", "error"
                )
        except Exception as e:
            print_msg(f"Error updating {repo_name}: {e}", "error")

    print()
    cmd_sync(config, dry=dry, verbose=verbose)
