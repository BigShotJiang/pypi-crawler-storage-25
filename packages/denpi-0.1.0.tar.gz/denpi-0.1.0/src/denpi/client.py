import requests

def call(key: str, keyword: str):
    prefix = "DenPI-GD2.2081-"
    if not key or prefix not in key:
        raise ValueError(
            "Invalid DenPI key. Expected format: DenPI-GD2.2081-127.0.0.1:<port>"
        )

    try:
        r = requests.get(f"http://{key.replace(prefix, '')}/api/data", timeout=2)
        r.raise_for_status()
    except requests.exceptions.ConnectionError:
        raise ConnectionError(
            "Could not connect to DenPI. Make sure Geometry Dash is running "
            "with the DenPI mod loaded."
        )
    except requests.exceptions.Timeout:
        raise TimeoutError("DenPI did not respond within 2 seconds.")

    data = r.json()

    if keyword not in data:
        raise KeyError(f"Unknown keyword '{keyword}'.")

    return data[keyword]