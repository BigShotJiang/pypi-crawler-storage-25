import urllib.parse

import requests
from bs4 import BeautifulSoup

from mcp.server.fastmcp import FastMCP


# Initialize FastMCP server
mcp = FastMCP("daum_news_crawler")


@mcp.tool()
def get_crawling(keyword: str, numofpages: int) -> list:
    """
    Daum News titles are collected and stored in a list based on the number of news article pages related to the keywords requested by the user.

    Args:
        keyword (str): Keywords requested by users for Daum News search.
        numofpages (int): Number of Daum news pages to collect as requested by the user.

    Returns:
        list: Collected Daum News Titles.
    """

    base_url = (
        'https://search.daum.net/search?w=news&nil_search=btn&DA=PGD&enc=utf8'
        '&cluster=y&cluster_page=1&q=' + urllib.parse.quote(keyword) + '&p='
    )

    daum_crawling = []

    for p in range(1, numofpages + 1):
        url = base_url + str(p)

        response = requests.get(
            url,
            headers={
                'User-Agent': (
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                    'AppleWebKit/537.36 (KHTML, like Gecko) '
                    'Chrome/126.0.0.0 Safari/537.36'
                )
            },
        )

        soup = BeautifulSoup(response.content, 'html.parser')

        headlines = soup.find_all(class_='item-title')

        for headline in headlines:
            title = headline.get_text(strip=True)
            daum_crawling.append(title)

    return daum_crawling


@mcp.tool()
def get_textwriter(contents: str) -> str:
    """
    Save the text entered by the user as daum-news-title.txt on the C: drive of the user's computer.

    Args:
        contents (str): Text entered by the user (e.g. the list of collected news titles joined with newlines).

    Returns:
        str: Result message including the saved file path.
    """
    path = "C:/daum-news-title.txt"
    with open(path, "a", encoding="utf-8") as file:
        file.write(contents)
        file.write("\n\n")  # Ensure the file ends with a newline
    print(f"Text saved to {path}")
    return f"Text saved to {path}"


def main() -> None:
    # Initialize and run the server
    print("Starting Daum News Crawler server...")
    mcp.run(transport='stdio')


if __name__ == "__main__":
    main()
