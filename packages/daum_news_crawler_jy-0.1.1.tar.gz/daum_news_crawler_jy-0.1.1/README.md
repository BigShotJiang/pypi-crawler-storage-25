# daum-news-crawler-jy

키워드로 Daum 뉴스(`search.daum.net`)를 검색해 헤드라인을 수집하고, 결과를 텍스트 파일로 저장하는 **MCP 서버**.

## Tools

- `get_crawling(keyword: str, numofpages: int) -> list[str]`
  - Daum 뉴스에서 `keyword`로 검색해 `numofpages` 페이지만큼 헤드라인을 수집해 list 반환
  - 페이지네이션은 `&p=1,2,3,...` 파라미터, 각 페이지당 약 10개
- `get_textwriter(contents: str) -> str`
  - 전달받은 문자열을 `D:/daum-news-title.txt` (UTF-8, append 모드)에 저장

## Install (사용자 입장)

```powershell
uvx daum-news-crawler-jy
```

`claude_desktop_config.json` 예시:
```json
{
  "mcpServers": {
    "daum_news_crawler": {
      "command": "uvx",
      "args": ["daum-news-crawler-jy", "--version", "0.1.0"]
    }
  }
}
```
