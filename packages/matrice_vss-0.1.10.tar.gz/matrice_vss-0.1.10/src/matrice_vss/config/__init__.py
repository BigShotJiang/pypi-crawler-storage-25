"""
matrice_vss.config
==================
Configuration management and logging setup for the VSS service.

This sub-package provides:

* **Settings** — Pydantic ``BaseSettings`` model (``VSSSettings``) that reads
  all configuration from environment variables or a ``.env`` file with the
  ``VSS_`` prefix.  Nested models (``ClickHouseConfig``, ``LLMConfig``,
  ``VLMConfig``) allow clean grouping of per-component settings.

* **Logging** — Structured rotating-file + console logging with three separate
  log streams (app, trace, errors) plus per-request/per-node helpers for the
  LangGraph orchestrator.

Public API
----------
.. code-block:: python

    from config.settings import get_settings, VSSSettings
    from config.settings import ClickHouseConfig, LLMConfig, VLMConfig
    from config.logging_config import setup_logging, log_node_step, log_request_trace

Environment variables
---------------------
All settings are prefixed with ``VSS_``.  Nested fields use ``__`` as the
delimiter, e.g.::

    VSS_API_PORT=9090
    VSS_LOG_LEVEL=DEBUG
    VSS_CLICKHOUSE__HOST=db.internal
    VSS_CLICKHOUSE__PASSWORD=s3cr3t
    VSS_LLM__ENDPOINT=http://gpu01:11434
    VSS_VLM_ENABLED=true
    VSS_CORS_ALLOWED_ORIGINS='["https://app.example.com"]'
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# ---------------------------------------------------------------------------
# Lazy public imports
# ---------------------------------------------------------------------------
# Imported lazily to avoid loading pydantic-settings (and the entire settings
# validation chain) unless explicitly needed.

def __getattr__(name: str):  # noqa: N807 — PEP 562 module __getattr__
    """Lazy-load public symbols from child modules on first access."""
    import importlib

    _symbol_map: dict[str, str] = {
        # config.settings
        "VSSSettings": "settings",
        "ClickHouseConfig": "settings",
        "LLMConfig": "settings",
        "VLMConfig": "settings",
        "get_settings": "settings",
        # config.logging_config
        "setup_logging": "logging_config",
        "log_node_step": "logging_config",
        "log_request_trace": "logging_config",
    }

    if name in _symbol_map:
        module = importlib.import_module(
            f".{_symbol_map[name]}", package=__name__
        )
        value = getattr(module, name)
        # Cache on the module object so subsequent access is O(1)
        globals()[name] = value
        return value

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# ---------------------------------------------------------------------------
# TYPE_CHECKING — static analysers see full types without runtime cost
# ---------------------------------------------------------------------------

if TYPE_CHECKING:  # pragma: no cover
    from .settings import (  # noqa: F401
        ClickHouseConfig,
        LLMConfig,
        VLMConfig,
        VSSSettings,
        get_settings,
    )
    from .logging_config import (  # noqa: F401
        log_node_step,
        log_request_trace,
        setup_logging,
    )

__all__: list[str] = [
    # settings
    "VSSSettings",
    "ClickHouseConfig",
    "LLMConfig",
    "VLMConfig",
    "get_settings",
    # logging_config
    "setup_logging",
    "log_node_step",
    "log_request_trace",
]
