"""Allow ``python -m autoheal`` to run the scaffold (same as ``autoheal-init``)."""

from autoheal.bootstrap import main

if __name__ == "__main__":
    main()
