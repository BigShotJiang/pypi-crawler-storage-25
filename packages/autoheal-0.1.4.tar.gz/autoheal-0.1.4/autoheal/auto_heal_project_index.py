"""Build a compact project index for AI-assisted healing prompts."""

from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any, Dict, List, Set


def _read_selectors(selectors_path: Path) -> Dict[str, Any]:
    try:
        with open(selectors_path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _page_constant_map(pages_dir: Path) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    if not pages_dir.exists():
        return out
    for py_path in sorted(pages_dir.glob("*_page.py")):
        if py_path.name == "base_page.py":
            continue
        try:
            tree = ast.parse(py_path.read_text(encoding="utf-8"), filename=str(py_path))
        except Exception:
            continue
        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue
            names: Set[str] = set()
            for sub in node.body:
                if not isinstance(sub, ast.Assign) or not sub.targets:
                    continue
                if not isinstance(sub.targets[0], ast.Name):
                    continue
                if sub.targets[0].id.isupper():
                    names.add(sub.targets[0].id)
            if names:
                out[node.name] = sorted(names)
    return out


def build_project_index(selectors_path: Path, pages_dir: Path) -> Dict[str, Any]:
    """Return a lightweight, stable index to keep LLM suggestions project-aware."""
    registry = _read_selectors(selectors_path)
    constants = _page_constant_map(pages_dir)
    pages: List[Dict[str, Any]] = []
    for page_name, values in sorted(registry.items()):
        if not isinstance(values, dict):
            continue
        keys = sorted(values.keys())
        pages.append(
            {
                "page_name": page_name,
                "element_keys": keys[:120],
                "constant_names": constants.get(page_name, [])[:200],
            }
        )
    return {
        "schema_version": 1,
        "selectors_path": str(selectors_path),
        "pages_dir": str(pages_dir),
        "known_page_names": [p["page_name"] for p in pages],
        "known_element_keys": sorted(
            {k for p in pages for k in p.get("element_keys", [])}
        )[:500],
        "pages": pages[:120],
    }
