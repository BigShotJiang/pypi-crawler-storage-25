"""Wrap Behave ``before_step`` / ``after_step`` to publish auto-heal step context.

Safe to call once per process; idempotent via a flag on the environment module.
"""

from __future__ import annotations

import os
from typing import Any, Callable, Dict, List, Optional


def _minimal_step_data(context: Any) -> Dict[str, Any]:
    """Best-effort context snapshot for AI (no secrets heuristics — keep small)."""
    data: Dict[str, Any] = {}
    for attr in (
        "tenant_id",
        "username",
        "scenario_name",
        "user_type",
        "test_data",
        "base_url",
    ):
        if not hasattr(context, attr):
            continue
        try:
            val = getattr(context, attr)
            if val is not None and not callable(val):
                if isinstance(val, dict):
                    for k, v in val.items():
                        if v is not None and not callable(v):
                            data[f"{attr}.{k}"] = v
                else:
                    data[attr] = val
        except Exception:
            continue
    return data


def _publish_step_context(context: Any, step: Any) -> None:
    try:
        from autoheal.auto_heal_integration import build_step_context, publish_step_context
    except Exception:
        return
    if os.getenv("AUTO_HEAL_ENABLED", "true").lower() not in ("1", "true", "yes"):
        return
    try:
        scenario = getattr(step, "scenario", None) or getattr(context, "scenario", None)
        feature = getattr(scenario, "feature", None) if scenario is not None else None
        scenario_steps: List[str] = []
        try:
            for s in getattr(scenario, "steps", []) or []:
                scenario_steps.append(f"{getattr(s, 'keyword', '')} {getattr(s, 'name', '')}".strip())
        except Exception:
            scenario_steps = []
        try:
            data = _minimal_step_data(context)
        except Exception:
            data = {}
        ctx = build_step_context(
            step_keyword=getattr(step, "keyword", "") or "",
            step_name=getattr(step, "name", "") or "",
            scenario_name=getattr(scenario, "name", "") or getattr(context, "scenario_name", "") or "",
            scenario_steps=scenario_steps,
            feature_name=getattr(feature, "name", "") if feature is not None else "",
            feature_path=getattr(feature, "filename", "") if feature is not None else "",
            data=data,
        )
        publish_step_context(ctx)
    except Exception as e:
        print(f"[autoheal] before_step context publish failed: {e}")


def _clear_step_context() -> None:
    try:
        from autoheal.auto_heal_integration import clear_step_context

        clear_step_context()
    except Exception:
        pass


def _safe_step_status(step: Any) -> str:
    st = getattr(step, "status", None)
    if st is None:
        return ""
    name = getattr(st, "name", None)
    return str(name or st).lower()


def patch_behave_environment_module(mod: Any) -> bool:
    """
    Wrap ``mod.before_step`` / ``mod.after_step`` (typically ``features.environment``).

    Returns True if patching was applied, False if already patched or nothing to do.
    """
    if getattr(mod, "_autoheal_behave_wrapped", False):
        return False

    orig_before: Optional[Callable[..., Any]] = getattr(mod, "before_step", None)
    orig_after: Optional[Callable[..., Any]] = getattr(mod, "after_step", None)

    def before_step(context: Any, step: Any) -> Any:
        try:
            from autoheal.behave_vision_hooks import ensure_context_healer

            ensure_context_healer(context)
        except Exception:
            pass
        _publish_step_context(context, step)
        if orig_before is not None:
            return orig_before(context, step)
        return None

    def after_step(context: Any, step: Any) -> Any:
        out = None
        try:
            if orig_after is not None:
                out = orig_after(context, step)
            try:
                from autoheal.behave_vision_hooks import maybe_run_step_failure_vision

                maybe_run_step_failure_vision(context, step)
            except Exception as _vision_exc:
                print(f"[autoheal] vision hook skipped: {_vision_exc}")
        finally:
            # Clear after framework hooks; keeps AI context from leaking across steps.
            if os.getenv("AUTO_HEAL_ENABLED", "true").lower() in ("1", "true", "yes"):
                _clear_step_context()
        return out

    mod.before_step = before_step
    mod.after_step = after_step
    mod._autoheal_behave_wrapped = True
    return True
