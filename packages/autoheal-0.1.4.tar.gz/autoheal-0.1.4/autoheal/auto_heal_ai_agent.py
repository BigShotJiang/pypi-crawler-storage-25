"""
OpenAI / Azure / OpenAI-compatible helper for auto-heal: locators from DOM + BDD context,
screenshot diagnosis, and workspace-wide selectors.json proposals.

Configuration (environment variables only — do not commit API keys):

  AUTO_HEAL_AI_ENABLED       true/false — must be true to call the model
  AUTO_HEAL_AI_BACKEND       azure/openai (default azure)
  AZURE_OPENAI_ENDPOINT      e.g. https://<resource>.openai.azure.com/
  AZURE_OPENAI_API_KEY        subscription key
  AZURE_OPENAI_DEPLOYMENT     deployment name (often same as model name)
  AZURE_OPENAI_API_VERSION    e.g. 2024-12-01-preview
  OPENAI_API_KEY              API key for OpenAI or compatible server
  OPENAI_MODEL                model name (default gpt-4.1)
  OPENAI_BASE_URL             optional — use for local OpenAI-compatible APIs (e.g. Ollama ``/v1``)
  AUTO_HEAL_AI_MAX_TOKENS     optional (completion token budget; workspace bootstrap may need more)

Vision screenshot diagnosis requires a **multimodal** model on your chosen backend.
"""

from __future__ import annotations

import base64
import json
import os
import re
from typing import Any, Dict, List, Optional

try:
    from autoheal.dotenv_bootstrap import load_project_dotenv

    load_project_dotenv()
except Exception:
    pass

def _env_val(key: str) -> str:
    """Read env var and trim whitespace / wrapping quotes (common in .env files)."""
    raw = (os.getenv(key) or "").strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ('"', "'"):
        raw = raw[1:-1].strip()
    return raw


_SYSTEM_PROMPT = """You are an expert in Playwright test automation and resilient DOM locators.
You receive:
- the failing BDD step text and the surrounding scenario steps (step_context.intent),
- the action the test wants to perform (click, fill, is_visible, get_text, get_attribute),
- test data values for the step (step_context.data, e.g. tenant_id, username, user_type),
- the page name, registry element_key, attempted_selectors, exclude_selectors,
- previous_attempts: selectors that were visible but performing the action did NOT advance the UI
  (false positives), each with the model's reason and an evidence note,
- project_index: compact repository map with known page classes, element keys, and selector registry
  metadata. Use it to keep output aligned with this project when possible.
- a JSON list of interactive elements from the live page (dom_inventory).

Your job is to propose ONE Playwright-compatible locator string (CSS or xpath=...) that best targets
the element the BDD step is acting on, taking step intent, action, data values, and prior failures
into account.

Rules:
- VALUE-SCOPED LOCATORS. If the step refers to a specific data value present in step_context.data
  (e.g. tenant_id "P-MSCI-00001", a username, a label), the locator MUST scope to that exact value.
  Use text=, :has-text("..."), [aria-label="..."], or attribute selectors that include the value.
  Picking the wrong row/option that "looks right" is worse than returning {"selector": "", ...}.
- USE PRIOR FAILURES TO PIVOT. If previous_attempts contains a visible selector for the SAME action
  that did not advance the UI, the prerequisite is likely missing (a tenant option not selected, an
  accordion not opened, a dropdown not expanded, a checkbox not ticked). PREFER suggesting the
  prerequisite control instead of yet another variant of the same submit/save button. Examples:
    * action=click on "*submit*" repeatedly visible-but-no-effect → suggest the listbox option,
      radio, or row that must be selected first.
    * action=click on a save/apply repeatedly visible-but-no-effect → suggest the form field that
      must be filled or the validation message control that must be acknowledged.
- Use the step text and scenario steps to disambiguate which control the user really means
  (e.g. "Submit" on a tenant panel vs a generic submit elsewhere).
- Prefer stable attributes: data-testid, name, id, aria-label, type, role-appropriate tags.
- Avoid brittle long chains; avoid index-only selectors unless necessary.
- The locator must resolve to exactly one visible actionable element in typical cases.
- For action="click": prefer real clickable controls (button, [role=button], a, input[type=button|submit]).
- For action="fill": prefer form controls (input, textarea, [contenteditable=true]).
- If xpath is clearly better, use the prefix xpath= with a single valid XPath.
- NEVER return any selector listed in exclude_selectors. Those were already tried and failed,
  or verified visible but performing the action did not advance the UI (false positives).
- If project_index.known_page_names / known_element_keys are present, keep page_name + element_key
  aligned to those known values unless the context strongly indicates a new key is needed.
- Respond with ONLY a JSON object (no markdown fences), shape:
  {"selector": "<string>", "confidence": <0.0-1.0>, "reason": "<short>"}
- If you cannot suggest a safe locator, respond: {"selector": "", "confidence": 0, "reason": "..."}
"""


def _azure_config() -> Dict[str, str]:
    dep = _env_val("AZURE_OPENAI_DEPLOYMENT")
    return {
        "endpoint": _env_val("AZURE_OPENAI_ENDPOINT").rstrip("/"),
        "api_key": _env_val("AZURE_OPENAI_API_KEY"),
        "deployment": dep or "gpt-5.2",
        "api_version": _env_val("AZURE_OPENAI_API_VERSION") or "2024-12-01-preview",
    }


def _openai_config() -> Dict[str, str]:
    return {
        "api_key": _env_val("OPENAI_API_KEY"),
        "model": _env_val("OPENAI_MODEL") or "gpt-4.1",
        "base_url": _env_val("OPENAI_BASE_URL"),
    }


def _ai_backend() -> str:
    raw = _env_val("AUTO_HEAL_AI_BACKEND").lower()
    return raw if raw in ("azure", "openai") else "azure"


def _get_llm_client() -> Optional[Dict[str, Any]]:
    try:
        from openai import AzureOpenAI, OpenAI
    except ImportError:
        print("[AUTOHEAL][AI] openai package not installed; pip install openai")
        return None
    backend = _ai_backend()
    if backend == "openai":
        cfg = _openai_config()
        if not cfg["api_key"] or not cfg["model"]:
            return None
        kwargs: Dict[str, Any] = {"api_key": cfg["api_key"]}
        if cfg["base_url"]:
            kwargs["base_url"] = cfg["base_url"]
        return {"backend": backend, "model": cfg["model"], "client": OpenAI(**kwargs)}
    cfg = _azure_config()
    if not cfg["endpoint"] or not cfg["api_key"] or not cfg["deployment"]:
        return None
    return {
        "backend": backend,
        "model": cfg["deployment"],
        "client": AzureOpenAI(
            api_version=cfg["api_version"],
            azure_endpoint=cfg["endpoint"],
            api_key=cfg["api_key"],
        ),
    }


def is_ai_heal_enabled() -> bool:
    if _env_val("AUTO_HEAL_AI_ENABLED").lower() not in ("1", "true", "yes"):
        return False
    if _ai_backend() == "openai":
        c = _openai_config()
        return bool(c["api_key"] and c["model"])
    c = _azure_config()
    return bool(c["endpoint"] and c["api_key"] and c["deployment"])


def _parse_json_object(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    t = text.strip()
    fence = re.search(r"```(?:json)?\s*([\s\S]*?)```", t, re.IGNORECASE)
    if fence:
        t = fence.group(1).strip()
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass
    m = re.search(r"\{[\s\S]*\}\s*$", t)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            return None
    return None


def suggest_selector_via_llm(
    page_name: str,
    element_key: str,
    text_hint: str,
    attempted_selectors: List[str],
    dom_inventory_json: str,
    exclude_selectors: Optional[List[str]] = None,
    step_context: Optional[Dict[str, Any]] = None,
    action_hint: Optional[str] = None,
    previous_attempts: Optional[List[Dict[str, Any]]] = None,
    project_index: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Call configured LLM backend; return dict with selector, confidence, reason or None on failure.

    ``step_context`` (optional) carries the failing BDD step text, surrounding scenario steps, the
    feature/scenario names, AND a ``data`` dict of test values (e.g. ``tenant_id``, ``username``,
    ``user_type``) so the model can scope locators to specific values rather than picking
    the first visible match.
    ``action_hint`` (optional) is the Playwright-style action the test wants to perform (click, fill, ...).
    ``previous_attempts`` (optional) is a list of ``{"selector", "model_reason", "fp_evidence"}`` dicts
    describing earlier suggestions that were visible but did not advance the UI (false positives).
    The model is instructed to consider prerequisite controls instead of repeating variants.
    """
    if not is_ai_heal_enabled():
        return None

    llm = _get_llm_client()
    if not llm:
        print("[AUTOHEAL][AI] backend config missing")
        return None
    client = llm["client"]
    model = llm["model"]
    backend = llm["backend"]
    max_tokens = int(os.getenv("AUTO_HEAL_AI_MAX_TOKENS", "2048"))
    user_payload = {
        "page_name": page_name,
        "element_key": element_key,
        "text_hint": text_hint or "",
        "action": (action_hint or "").strip(),
        "step_context": step_context or {},
        "previous_attempts": list(previous_attempts or []),
        "attempted_selectors": attempted_selectors,
        "exclude_selectors": list(exclude_selectors or []),
        "project_index": project_index or {},
        "dom_inventory": dom_inventory_json[:120000],
    }
    user_text = json.dumps(user_payload, ensure_ascii=True)

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": (
                        "Pick the best locator for this automation target. Context JSON follows.\n"
                        + user_text
                    ),
                },
            ],
            max_completion_tokens=max_tokens,
        )
    except Exception as e:
        print(f"[AUTOHEAL][AI] {backend} request failed: {e}")
        return None

    try:
        content = (response.choices[0].message.content or "").strip()
    except (AttributeError, IndexError) as e:
        print(f"[AUTOHEAL][AI] Unexpected response shape: {e}")
        return None

    parsed = _parse_json_object(content)
    if not parsed or "selector" not in parsed:
        print("[AUTOHEAL][AI] Could not parse model JSON")
        return None

    selector = (parsed.get("selector") or "").strip()
    try:
        confidence = float(parsed.get("confidence", 0))
    except (TypeError, ValueError):
        confidence = 0.0
    reason = str(parsed.get("reason", ""))[:500]
    if not selector:
        return None
    return {"selector": selector, "confidence": max(0.0, min(1.0, confidence)), "reason": reason}


def suggest_selector_via_azure(
    page_name: str,
    element_key: str,
    text_hint: str,
    attempted_selectors: List[str],
    dom_inventory_json: str,
    exclude_selectors: Optional[List[str]] = None,
    step_context: Optional[Dict[str, Any]] = None,
    action_hint: Optional[str] = None,
    previous_attempts: Optional[List[Dict[str, Any]]] = None,
    project_index: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """Backward-compatible alias kept for existing callers/tests."""
    return suggest_selector_via_llm(
        page_name,
        element_key,
        text_hint,
        attempted_selectors,
        dom_inventory_json,
        exclude_selectors,
        step_context,
        action_hint,
        previous_attempts,
        project_index,
    )


_SCREENSHOT_DIAGNOSIS_PROMPT = """You are an expert Playwright test debugger.

You receive:
- a screenshot of the page captured the moment a BDD step failed,
- the failing step text (step_keyword + step_name),
- the surrounding scenario steps (so you can see the test's intent),
- the test data values for the step (step_context.data, e.g. tenant_id, username),
- the page object's class name (page_name) and the element_key the page object thinks failed,
- the locator hint the page-object author wrote for the placeholder (text_hint),
- a heal_trace: every selector that was attempted plus its outcome (parse_error / not_visible /
  visible_no_effect / timeout) so you understand what was already ruled out,
- project_index: compact repository map with known page classes and element keys that should be
  preferred when selecting patch targets,
- optionally a JSON inventory of interactive DOM elements (dom_inventory) seen at the moment
  of failure.

Your job is to produce ONE diagnosis that tells the test framework two things:
  1. ROOT CAUSE: in 1 short sentence, what visually went wrong (e.g. "tenant dropdown never
     opened, so no option was selectable"; "submit button is disabled because the email field
     shows a validation error"; "element_key=tenant_option targets the option, but the AI saw
     no open listbox in the screenshot").
  2. HEAL CANDIDATE: the best Playwright-compatible locator string (CSS or xpath=...) for the
     element the step actually needed to act on. The locator MUST scope to the data values
     in step_context.data when relevant (use text=, :has-text("..."), [aria-label="..."], etc.).
     If the screenshot shows the prerequisite control (e.g. an unopened dropdown) is what
     really needs to be clicked first, return THAT element's locator and a different
     prerequisite_element_key (e.g. "tenant_dropdown" instead of "tenant_option").

Rules:
- NEVER suggest a selector that appears in heal_trace with outcome visible_no_effect (those
  were already proven to be the wrong target).
- Prefer stable attributes (data-testid, name, id, aria-label, role) over CSS chains.
- Confidence ≥ 0.85 only when the screenshot makes the target unambiguous.
- Respond with ONLY a JSON object (no markdown fences), shape:
  {
    "root_cause": "<short sentence>",
    "page_name": "<*Page class to patch, e.g. LoginPage>",
    "element_key": "<registry key to patch, e.g. tenant_dropdown>",
    "selector": "<Playwright locator string>",
    "confidence": <0.0-1.0>,
    "reason": "<why this locator from the screenshot>",
    "needs_prerequisite": <true|false>
  }
- If you cannot suggest a safe locator from the screenshot:
  {"root_cause": "<...>", "page_name": "<...>", "element_key": "<...>",
   "selector": "", "confidence": 0, "reason": "<...>", "needs_prerequisite": false}
"""


def _encode_image_data_url(image_path: str) -> Optional[str]:
    """Read an image file and base64-encode it as a data: URL for the Azure Vision API."""
    try:
        with open(image_path, "rb") as fh:
            raw = fh.read()
    except (OSError, IOError) as e:
        print(f"[AUTOHEAL][VISION] Could not read screenshot {image_path}: {e}")
        return None
    if not raw:
        return None
    ext = (os.path.splitext(image_path)[1] or ".png").lower().lstrip(".")
    mime = "image/png" if ext not in ("jpg", "jpeg", "webp", "gif", "png") else (
        "image/jpeg" if ext in ("jpg", "jpeg") else f"image/{ext}"
    )
    encoded = base64.b64encode(raw).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def analyze_failure_screenshot(
    image_path: str,
    *,
    page_name: str,
    element_key: str,
    text_hint: str,
    step_context: Optional[Dict[str, Any]] = None,
    heal_trace: Optional[List[Dict[str, Any]]] = None,
    dom_inventory_json: Optional[str] = None,
    project_index: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """Send the failure screenshot + BDD context to Azure OpenAI vision; return diagnosis dict.

    Returns ``None`` when AI healing is disabled, the deployment is unconfigured, the file
    cannot be read, or the model produced no parseable JSON. On success returns::

        {
          "root_cause": str,
          "page_name": str,
          "element_key": str,
          "selector": str,                # may be "" if model has no candidate
          "confidence": float,            # 0..1
          "reason": str,
          "needs_prerequisite": bool,
        }

    The orchestrator (``AutoHealAsync.diagnose_step_failure``) is responsible for verifying
    the suggested locator on the live page and committing the heal only when verification
    passes (FP guard equivalent for the screenshot path).
    """
    if not is_ai_heal_enabled():
        return None

    llm = _get_llm_client()
    if not llm:
        print("[AUTOHEAL][VISION] backend config missing")
        return None

    data_url = _encode_image_data_url(image_path)
    if not data_url:
        return None

    client = llm["client"]
    model = llm["model"]
    backend = llm["backend"]
    max_tokens = int(os.getenv("AUTO_HEAL_AI_MAX_TOKENS", "2048"))
    user_payload = {
        "page_name": page_name,
        "element_key": element_key,
        "text_hint": text_hint or "",
        "step_context": step_context or {},
        "heal_trace": list(heal_trace or []),
        "project_index": project_index or {},
        "dom_inventory": (dom_inventory_json or "")[:80000],
    }
    user_text = json.dumps(user_payload, ensure_ascii=True)

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": _SCREENSHOT_DIAGNOSIS_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": (
                                "Diagnose this failed step from the screenshot. "
                                "Context JSON follows.\n" + user_text
                            ),
                        },
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                },
            ],
            max_completion_tokens=max_tokens,
        )
    except Exception as e:
        print(f"[AUTOHEAL][VISION] {backend} vision request failed: {e}")
        return None

    try:
        content = (response.choices[0].message.content or "").strip()
    except (AttributeError, IndexError) as e:
        print(f"[AUTOHEAL][VISION] Unexpected vision response shape: {e}")
        return None

    parsed = _parse_json_object(content)
    if not parsed:
        print("[AUTOHEAL][VISION] Could not parse vision model JSON")
        return None

    selector = (parsed.get("selector") or "").strip()
    try:
        confidence = float(parsed.get("confidence", 0))
    except (TypeError, ValueError):
        confidence = 0.0
    return {
        "root_cause": str(parsed.get("root_cause", ""))[:500],
        "page_name": str(parsed.get("page_name", page_name) or page_name),
        "element_key": str(parsed.get("element_key", element_key) or element_key),
        "selector": selector,
        "confidence": max(0.0, min(1.0, confidence)),
        "reason": str(parsed.get("reason", ""))[:500],
        "needs_prerequisite": bool(parsed.get("needs_prerequisite", False)),
    }


_WORKSPACE_BOOTSTRAP_PROMPT = """You prepare a Playwright Python BDD workspace for auto-healing (AutoHeal).
You receive JSON with:
- feature_files: list of { "path", "content" } — Gherkin source (may be truncated)
- page_objects: list of { "path", "classes": [ { "name", "constants": ["UPPER_CASE", ...] } ] }
- selectors_registry: current pages/selectors.json object (may be empty)
- project_index: compact map of known page names and element keys

Task: propose selectors.json-style entries so runtime healing can resolve locators using:
  * BDD step wording (When/Then) as text_hint in metadata,
  * page class names exactly as in page_objects,
  * element keys aligned to page-object UPPER_SNAKE constants when present.

Output ONLY JSON (no markdown fences):
{
  "selectors": {
    "SomePage": {
      "SOME_BUTTON": {
        "primary": "",
        "fallbacks": [],
        "metadata": { "text_hint": "short natural language from the scenario" }
      }
    }
  },
  "notes": ["optional bullets"],
  "confidence": 0.0
}

Rules:
- Only use page class names that appear in page_objects or project_index.known_page_names.
- primary may be \"\" when the DOM is unknown; never guess brittle CSS without evidence.
- Prefer element_key names that match constants[] for that class.
- confidence is 0.0-1.0 for the overall proposal quality.
"""


def suggest_workspace_registry_updates(snapshot: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Call the configured LLM to propose ``selectors.json`` entries from features + page objects.

    Requires ``AUTO_HEAL_AI_ENABLED`` and Azure or OpenAI-compatible credentials
    (``OPENAI_BASE_URL`` works for local OpenAI-compatible servers).
    """
    if not is_ai_heal_enabled():
        print("[AUTOHEAL][WORKSPACE] Set AUTO_HEAL_AI_ENABLED=true and configure the LLM backend.")
        return None
    llm = _get_llm_client()
    if not llm:
        print("[AUTOHEAL][WORKSPACE] LLM client not configured (keys / endpoint).")
        return None
    client = llm["client"]
    model = llm["model"]
    backend = llm["backend"]
    max_tokens = int(os.getenv("AUTO_HEAL_AI_MAX_TOKENS", "4096"))
    user_text = json.dumps(snapshot, ensure_ascii=True)[:200000]
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": _WORKSPACE_BOOTSTRAP_PROMPT},
                {
                    "role": "user",
                    "content": "Propose selectors registry updates. Workspace JSON follows.\n" + user_text,
                },
            ],
            max_completion_tokens=max_tokens,
        )
    except Exception as e:
        print(f"[AUTOHEAL][WORKSPACE] {backend} request failed: {e}")
        return None
    try:
        content = (response.choices[0].message.content or "").strip()
    except (AttributeError, IndexError) as e:
        print(f"[AUTOHEAL][WORKSPACE] Unexpected response shape: {e}")
        return None
    parsed = _parse_json_object(content)
    if not parsed or "selectors" not in parsed:
        print("[AUTOHEAL][WORKSPACE] Could not parse model JSON (expected 'selectors' key).")
        return None
    if not isinstance(parsed.get("selectors"), dict):
        return None
    try:
        conf = float(parsed.get("confidence", 0))
    except (TypeError, ValueError):
        conf = 0.0
    return {
        "selectors": parsed["selectors"],
        "notes": list(parsed.get("notes") or []) if isinstance(parsed.get("notes"), list) else [],
        "confidence": max(0.0, min(1.0, conf)),
    }
