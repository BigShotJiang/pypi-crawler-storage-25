"""Scaffold auto-heal layout and config templates in a consumer project.

Run after installing the wheel::

    autoheal-init
    autoheal-init --workspace /path/to/my-tests

This does not install secrets or modify your test runner; it only creates files and dirs.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict, List


ENV_EXAMPLE = """# Auto-heal — copy to `.env` and adjust (never commit real secrets).
#
# Core
AUTO_HEAL_ENABLED=true
AUTO_HEAL_APPLY=true
AUTO_HEAL_MIN_CONFIDENCE=0.7
AUTO_HEAL_DEBUG=false
AUTO_HEAL_AUDIT_ALL=true
AUTO_HEAL_AUDIT_MIN_CONFIDENCE=0.8
AUTO_HEAL_INCLUDE_PROJECT_INDEX=true

# Paths (relative to process cwd when tests run)
AUTO_HEAL_REPORTS_DIR=reports/heal_audit
AUTO_HEAL_SELECTORS_PATH=pages/selectors.json
AUTO_HEAL_BACKUP_DIR=pages/backups
AUTO_HEAL_PAGES_DIR=pages

# AI locator suggestions (optional)
AUTO_HEAL_AI_ENABLED=false
AUTO_HEAL_AI_BACKEND=azure
AUTO_HEAL_AI_MAX_TOKENS=2048
AUTO_HEAL_AI_MAX_ROUNDS=4

# Azure OpenAI (when AUTO_HEAL_AI_BACKEND=azure)
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_DEPLOYMENT=
AZURE_OPENAI_API_VERSION=2024-12-01-preview

# Public OpenAI API (when AUTO_HEAL_AI_BACKEND=openai)
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1
# Local / OpenAI-compatible (Ollama, vLLM, etc.): set backend to openai and point base URL to .../v1
# OPENAI_BASE_URL=http://127.0.0.1:11434/v1

# Screenshot diagnosis after failed step (Behave hook pattern in originating framework)
AUTO_HEAL_SCREENSHOT_DIAGNOSIS=true
"""


SELECTORS_STUB = """{}"""


INTEGRATION_README = """# Auto-heal integration (scaffolded)

## What was created

- `pages/selectors.json` — selector registry (empty `{}` until you add pages)
- `pages/backups/` — JSON backups when registry is updated
- `reports/heal_audit/` — audit logs and JSONL
- `.env.example` — copy to `.env` and set API keys if using AI

Install Playwright browsers once per machine (e.g. `playwright install chromium`) before running tests that open a real browser.

## Minimal code

```python
from autoheal import AutoHealAsync, HealerConfig

cfg = HealerConfig.from_env()
healer = AutoHealAsync(page, config=cfg)

result = await healer.locate(
    page_name="YourPage",
    element_key="submit_button",
    action="click",
    text_hint="Submit",
)
```

## Step context (recommended for AI)

```python
from autoheal import build_step_context, publish_step_context, clear_step_context

publish_step_context(build_step_context(
    step_keyword="When",
    step_name="I submit the form",
    scenario_name="My scenario",
    scenario_steps=["Given ...", "When ..."],
    data={"tenant_id": "example"},
))
# ... run step ...
clear_step_context()
```

Wire `publish_step_context` / `clear_step_context` to your runner's before/after step hooks.

## Automated wiring (Behave + BasePage)

After `pip install autoheal`, you can apply default wiring without hand-editing every file:

```bash
autoheal-init --wire
# or scaffold only, then:
autoheal-wire --workspace .
```

This appends a small block to `features/environment.py` that wraps `before_step` / `after_step` for step-context publishing, and injects `self.healer = AutoHealAsync(...)` into `pages/base_page.py` when a `BasePage.__init__(self, page)` + `self.page = page` pattern is found.

Use `autoheal-wire --dry-run` to preview. If your paths differ: `autoheal-wire --env-file path/to/environment.py`.

### AI: workspace selectors + vision on failure

With ``AUTO_HEAL_AI_ENABLED=true`` and your LLM configured (Azure, OpenAI, or OpenAI-compatible ``OPENAI_BASE_URL``):

- **Bootstrap registry from features + page objects:** ``autoheal-workspace-ai`` (dry-run by default; add ``--apply`` to merge into ``pages/selectors.json``).
- **On failure:** wired Behave hooks call **screenshot + vision diagnosis** when ``AUTO_HEAL_SCREENSHOT_DIAGNOSIS=true`` (default in ``.env.example``), using the same backend as locator healing. Use a **vision** model if you rely on screenshot analysis.
- **During a step:** ``AutoHealAsync.locate`` already performs **DOM inventory** and **LLM** rounds when AI is enabled.

Re-run **`autoheal-init`** only if you need to recreate templates; use `--force` to overwrite `.env.example` and this file.
"""


def bootstrap_workspace(
    root: Path,
    *,
    force: bool = False,
) -> Dict[str, Any]:
    """Create default dirs and template files under ``root``."""
    root = root.resolve()
    created: List[str] = []
    skipped: List[str] = []

    dirs = [
        root / "reports" / "heal_audit",
        root / "pages" / "backups",
        root / "screenshots",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        if d.exists():
            created.append(str(d.relative_to(root)))

    selectors = root / "pages" / "selectors.json"
    selectors.parent.mkdir(parents=True, exist_ok=True)
    if selectors.exists() and not force:
        skipped.append(str(selectors.relative_to(root)))
    else:
        selectors.write_text(SELECTORS_STUB.strip() + "\n", encoding="utf-8")
        created.append(str(selectors.relative_to(root)))

    env_example = root / ".env.example"
    if env_example.exists() and not force:
        skipped.append(str(env_example.relative_to(root)))
    else:
        env_example.write_text(ENV_EXAMPLE, encoding="utf-8")
        created.append(str(env_example.relative_to(root)))

    readme = root / "AUTO_HEAL_INTEGRATION.md"
    if readme.exists() and not force:
        skipped.append(str(readme.relative_to(root)))
    else:
        readme.write_text(INTEGRATION_README, encoding="utf-8")
        created.append(str(readme.relative_to(root)))

    return {"root": str(root), "created": created, "skipped_existing": skipped}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create auto-heal directories and template files in the target project."
    )
    parser.add_argument(
        "--workspace",
        default=".",
        help="Project root (default: current directory)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite .env.example, selectors.json stub, and AUTO_HEAL_INTEGRATION.md if present",
    )
    parser.add_argument(
        "--wire",
        action="store_true",
        help="After scaffold, run autoheal-wire (Behave hooks + BasePage healer injection)",
    )
    parser.add_argument(
        "--wire-dry-run",
        action="store_true",
        help="With --wire, only print wire actions without editing files",
    )
    args = parser.parse_args()
    root = Path(args.workspace)
    out = bootstrap_workspace(root, force=args.force)
    print("Auto-heal scaffold:")
    for line in out["created"]:
        print(f"  + {line}")
    if out["skipped_existing"]:
        print("Skipped (already exist, use --force to overwrite):")
        for line in out["skipped_existing"]:
            print(f"  - {line}")
    if args.wire:
        from autoheal.wire_cli import wire_workspace

        print("Auto-heal wire:")
        for line in wire_workspace(root, dry_run=args.wire_dry_run):
            print(f"  {line}")


if __name__ == "__main__":
    main()
