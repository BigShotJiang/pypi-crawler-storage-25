"""
Patch page object Python files when auto-heal promotes a locator.

By default, patching runs only when confidence is strictly above
``AUTO_HEAL_PAGE_OBJECT_THRESHOLD`` (default ``0.7``). When ``bypass_confidence_threshold`` is true
(for example after a Behave scenario passed), that gate is skipped.

Supported class-level assignments (optional trailing ``#`` comment):

- Single-line strings: ``CONST = '...'`` / ``CONST = "..."``
- Single-line lists of string literals: ``CONST = ['a', 'b']``

Matching uses the registry's previous ``primary`` (when set) and/or **generic** name rules
derived from ``element_key`` (e.g. ``username_input`` → ``USERNAME_INPUT`` and ``USERNAME_FIELD``).
There are no per-page force maps: any class-level string or list-of-strings line that matches
those rules is updated when a heal is promoted to the page object.
"""

from __future__ import annotations

import ast
import os
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set

_RESOLVED_PATH: Dict[str, Optional[Path]] = {}


def _constant_name_candidates(element_key: str) -> Set[str]:
    """
    Map ``element_key`` (snake_case) to likely class constant names (SCREAMING_SNAKE_CASE).

    Includes ``element_key.upper()`` and a small generic ``_INPUT`` / ``_FIELD`` swap so
    ``username_input`` matches ``USERNAME_FIELD`` without a per-page table.
    """
    k = (element_key or "").strip()
    if not k:
        return set()
    u = k.upper()
    out: Set[str] = {u}
    if u.endswith("_INPUT") and len(u) > 6:
        out.add(u[:-6] + "_FIELD")
    if u.endswith("_FIELD") and len(u) > 6:
        out.add(u[:-6] + "_INPUT")
    return out


def _pages_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "pages"


def resolve_page_object_py(page_name: str, pages_dir: Optional[Path] = None) -> Optional[Path]:
    """Return path to ``*_page.py`` defining ``class PageName``."""
    if page_name in ("BasePage",):
        return None
    if page_name in _RESOLVED_PATH:
        return _RESOLVED_PATH[page_name]
    root = pages_dir or _pages_dir()
    for path in sorted(root.glob("*_page.py")):
        if path.name == "base_page.py":
            continue
        try:
            txt = path.read_text(encoding="utf-8")
        except OSError:
            continue
        if re.search(rf"^\s*class\s+{re.escape(page_name)}\s*\(", txt, re.MULTILINE):
            _RESOLVED_PATH[page_name] = path
            return path
    _RESOLVED_PATH[page_name] = None
    return None


def _page_object_patch_threshold() -> float:
    try:
        return float(os.getenv("AUTO_HEAL_PAGE_OBJECT_THRESHOLD", "0.7"))
    except ValueError:
        return 0.7


def _split_rhs_literal_and_comment(rhs_all: str) -> Tuple[str, str]:
    """
    Split ``rhs`` into the literal expression and a trailing comment.

    Uses ``" #"`` as the comment delimiter so ``#`` inside selectors (e.g. ``#id`` or ``['#a']``)
    is not treated as starting a comment.
    """
    rhs_all = rhs_all.rstrip()
    idx = rhs_all.find(" #")
    if idx != -1:
        return rhs_all[:idx].strip(), rhs_all[idx:].lstrip()
    return rhs_all.strip(), ""


def _parse_string_rhs(rhs_all: str) -> Optional[Tuple[str, str]]:
    """
    Return (decoded_string_value, comment_suffix) where comment_suffix is like ``# foo`` or ``""``.
    """
    lit, comment = _split_rhs_literal_and_comment(rhs_all)
    try:
        val = ast.literal_eval(lit)
    except (SyntaxError, ValueError, TypeError):
        return None
    if not isinstance(val, str):
        return None
    return val, comment


def _parse_list_of_strings_rhs(rhs_all: str) -> Optional[Tuple[List[str], str]]:
    """If RHS is a list literal of strings, return (items, comment_suffix)."""
    lit, comment = _split_rhs_literal_and_comment(rhs_all)
    try:
        val = ast.literal_eval(lit)
    except (SyntaxError, ValueError, TypeError):
        return None
    if not isinstance(val, list):
        return None
    if not all(isinstance(x, str) for x in val):
        return None
    return val, comment


def _rewrite_string_assignment_line(
    line: str, const_name: str, new_selector: str
) -> Optional[str]:
    """Replace RHS of ``CONST = "..."`` with ``new_selector`` if ``CONST`` matches."""
    raw = line.rstrip("\r\n")
    if not raw.strip() or raw.lstrip().startswith("#"):
        return None
    m = re.match(rf"^(\s*){re.escape(const_name)}\s*=\s*(.*)$", raw)
    if not m:
        return None
    indent, rhs_all = m.groups()
    parsed = _parse_string_rhs(rhs_all)
    if not parsed:
        return None
    _, comment = parsed
    nl = "\r\n" if line.endswith("\r\n") else ("\n" if line.endswith("\n") else "")
    rhs_out = repr(new_selector)
    if comment.strip():
        rhs_out = f"{rhs_out}  {comment}"
    return f"{indent}{const_name} = {rhs_out}{nl}"


def _rewrite_list_assignment_line(
    line: str, const_name: str, new_items: List[str]
) -> Optional[str]:
    """Replace RHS list of strings for ``CONST = [...]`` when parseable as list of strings."""
    raw = line.rstrip("\r\n")
    if not raw.strip() or raw.lstrip().startswith("#"):
        return None
    m = re.match(rf"^(\s*){re.escape(const_name)}\s*=\s*(.*)$", raw)
    if not m:
        return None
    indent, rhs_all = m.groups()
    parsed = _parse_list_of_strings_rhs(rhs_all)
    if not parsed:
        return None
    _, comment = parsed
    nl = "\r\n" if line.endswith("\r\n") else ("\n" if line.endswith("\n") else "")
    rhs_out = repr(new_items)
    if comment.strip():
        rhs_out = f"{rhs_out}  {comment}"
    return f"{indent}{const_name} = {rhs_out}{nl}"


def _try_patch_line(
    line: str,
    *,
    page_name: str,
    new_selector: str,
    previous_primary: Optional[str],
    element_key: str,
) -> Optional[str]:
    """
    Return replacement line if this line should change; ``None`` if the line is unchanged.
    """
    raw = line.rstrip("\r\n")
    if not raw.strip() or raw.lstrip().startswith("#"):
        return None
    m = re.match(r"^(\s*)([A-Z][A-Z0-9_]*)\s*=\s*(.*)$", raw)
    if not m:
        return None
    indent, name, rhs_all = m.groups()
    if name.startswith("_"):
        return None

    parsed = _parse_string_rhs(rhs_all)
    if not parsed:
        return None
    current_val, comment = parsed

    names_ok = _constant_name_candidates(element_key)
    if previous_primary:
        if current_val != previous_primary and name not in names_ok:
            return None
    else:
        if name not in names_ok:
            return None

    nl = "\r\n" if line.endswith("\r\n") else ("\n" if line.endswith("\n") else "")
    rhs_out = repr(new_selector)
    if comment.strip():
        rhs_out = f"{rhs_out}  {comment}"
    return f"{indent}{name} = {rhs_out}{nl}"


def _try_patch_line_list(
    line: str,
    *,
    page_name: str,
    new_selector: str,
    previous_primary: Optional[str],
    element_key: str,
) -> Optional[str]:
    """Patch a class-level ``CONST = ['str', ...]`` line when it matches the heal."""
    raw = line.rstrip("\r\n")
    if not raw.strip() or raw.lstrip().startswith("#"):
        return None
    m = re.match(r"^(\s*)([A-Z][A-Z0-9_]*)\s*=\s*(.*)$", raw)
    if not m:
        return None
    indent, name, rhs_all = m.groups()
    if name.startswith("_"):
        return None

    parsed = _parse_list_of_strings_rhs(rhs_all)
    if not parsed:
        return None
    current_list, comment = parsed

    names_ok = _constant_name_candidates(element_key)

    if previous_primary:
        if previous_primary in current_list:
            new_list = [new_selector if x == previous_primary else x for x in current_list]
        elif name in names_ok:
            new_list = [new_selector]
        else:
            return None
    else:
        if name not in names_ok:
            return None
        new_list = [new_selector]

    nl = "\r\n" if line.endswith("\r\n") else ("\n" if line.endswith("\n") else "")
    rhs_out = repr(new_list)
    if comment.strip():
        rhs_out = f"{rhs_out}  {comment}"
    return f"{indent}{name} = {rhs_out}{nl}"


def patch_page_object_locator(
    page_name: str,
    element_key: str,
    new_selector: str,
    previous_primary: Optional[str],
    confidence_for_page_patch: float,
    *,
    pages_dir: Optional[Path] = None,
    bypass_confidence_threshold: bool = False,
) -> bool:
    """
    If ``bypass_confidence_threshold`` is false, update only when ``confidence_for_page_patch`` is
    **strictly greater** than ``AUTO_HEAL_PAGE_OBJECT_THRESHOLD`` (default ``0.7``). When true,
    the confidence gate is skipped (used when the enclosing test scenario passed).

    Returns True when the file was written.
    """
    threshold = _page_object_patch_threshold()
    if not bypass_confidence_threshold and confidence_for_page_patch <= threshold:
        return False
    if os.getenv("AUTO_HEAL_PATCH_PAGE_OBJECTS", "true").lower() not in ("1", "true", "yes"):
        return False

    path = resolve_page_object_py(page_name, pages_dir)
    if path is None:
        return False

    try:
        original = path.read_text(encoding="utf-8")
    except OSError:
        return False

    lines = original.splitlines(keepends=True)
    new_lines: list[str] = []
    changed = 0
    for line in lines:
        patched = _try_patch_line(
            line,
            page_name=page_name,
            new_selector=new_selector,
            previous_primary=previous_primary,
            element_key=element_key,
        )
        if patched is not None and patched != line:
            new_lines.append(patched)
            changed += 1
        else:
            new_lines.append(line)

    if changed == 0:
        new_lines = []
        for line in lines:
            patched = _try_patch_line_list(
                line,
                page_name=page_name,
                new_selector=new_selector,
                previous_primary=previous_primary,
                element_key=element_key,
            )
            if patched is not None and patched != line:
                new_lines.append(patched)
                changed += 1
            else:
                new_lines.append(line)

    if changed == 0:
        return False

    backup_dir = (pages_dir or _pages_dir()) / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    shutil.copy2(path, backup_dir / f"{path.stem}_{ts}.py")

    path.write_text("".join(new_lines), encoding="utf-8")
    if bypass_confidence_threshold:
        print(
            f"[AUTOHEAL] Page object updated ({changed} line(s)): {path.name} "
            f"({page_name}.{element_key}, scenario passed — confidence threshold bypassed, "
            f"confidence={confidence_for_page_patch:.3f})"
        )
    else:
        print(
            f"[AUTOHEAL] Page object updated ({changed} line(s)): {path.name} "
            f"({page_name}.{element_key}, confidence={confidence_for_page_patch:.3f} > {threshold})"
        )
    return True
