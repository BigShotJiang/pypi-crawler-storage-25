"""Behave integration: scenario healer, failure screenshots, vision-based locator diagnosis.

Requires ``context.page`` (async Playwright), ``context.loop`` (asyncio loop), and optionally
``context.healer`` — use :func:`ensure_context_healer` early in the step lifecycle when the page exists.

Enable with ``AUTO_HEAL_AI_ENABLED=true`` and a vision-capable model for screenshot diagnosis.
``AUTO_HEAL_SCREENSHOT_DIAGNOSIS`` (default true) gates capture + :meth:`AutoHealAsync.diagnose_step_failure`.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any, List, Optional


def _vision_diagnosis_enabled() -> bool:
    if os.getenv("AUTO_HEAL_ENABLED", "true").lower() not in ("1", "true", "yes"):
        return False
    return os.getenv("AUTO_HEAL_SCREENSHOT_DIAGNOSIS", "true").lower() in ("1", "true", "yes")


def _safe_step_status(step: Any) -> str:
    st = getattr(step, "status", None)
    if st is None:
        return ""
    name = getattr(st, "name", None)
    return str(name or st).lower()


def ensure_context_healer(context: Any) -> None:
    """Attach ``context.healer`` (:class:`~autoheal.auto_heal_async.AutoHealAsync`) if missing."""
    if getattr(context, "healer", None) is not None:
        return
    page = getattr(context, "page", None)
    if page is None:
        return
    if os.getenv("AUTO_HEAL_ENABLED", "true").lower() not in ("1", "true", "yes"):
        return
    try:
        from autoheal.auto_heal_async import AutoHealAsync, HealerConfig

        raw = page._page if hasattr(page, "_page") else page
        context.healer = AutoHealAsync(
            raw,
            config=HealerConfig.from_env(reporters_dir=os.getenv("AUTO_HEAL_REPORTS_DIR", "reports/heal_audit")),
        )
    except Exception as e:
        print(f"[autoheal] could not create scenario healer: {e}")


def capture_step_failure_screenshot(context: Any, step: Any) -> Optional[str]:
    """Save a full-page PNG after a failed step; return path or ``None``."""
    page = getattr(context, "page", None)
    if page is None:
        return None
    try:
        if hasattr(page, "is_closed") and page.is_closed():
            return None
    except Exception:
        return None
    try:
        os.makedirs("screenshots", exist_ok=True)
    except Exception:
        return None
    safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in (getattr(step, "name", None) or "step"))[:60]
    path = os.path.join(
        "screenshots",
        f"autoheal_step_fail_{int(time.time() * 1000)}_{safe}.png",
    )

    async def _shoot() -> None:
        await page.screenshot(path=path, full_page=True)

    try:
        loop = getattr(context, "loop", None) or asyncio.get_event_loop()
        loop.run_until_complete(_shoot())
    except Exception as e:
        print(f"[autoheal][vision] screenshot failed: {e}")
        return None
    return os.path.abspath(path) if os.path.isfile(path) else None


def _heal_trace_for_scenario(step_context: dict, log_path: str, max_lines: int = 40) -> List[dict]:
    trace: List[dict] = []
    if not os.path.isfile(log_path):
        return trace
    scenario_name = (step_context or {}).get("scenario_name") or ""
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            tail = f.readlines()[-max_lines:]
        for line in tail:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if scenario_name and rec.get("scenario_name") not in (None, "", scenario_name):
                continue
            trace.append(rec)
    except Exception:
        pass
    return trace


def run_failure_vision_diagnose(context: Any, step: Any, screenshot_path: str) -> None:
    """Call :meth:`AutoHealAsync.diagnose_step_failure` using heal audit tail + step context."""
    healer = getattr(context, "healer", None)
    if healer is None or not screenshot_path:
        return
    try:
        from autoheal.auto_heal_async import get_current_step_context
    except Exception:
        get_current_step_context = lambda: {}  # type: ignore[misc, assignment]

    try:
        step_ctx = dict(get_current_step_context() or {})
    except Exception:
        step_ctx = {}

    log_path = os.path.join(
        os.getenv("AUTO_HEAL_REPORTS_DIR", "reports/heal_audit"),
        "failed_locators.jsonl",
    )
    heal_trace = _heal_trace_for_scenario(step_ctx, log_path)
    page_name = ""
    element_key = ""
    for rec in reversed(heal_trace):
        if not page_name and rec.get("page_name"):
            page_name = str(rec["page_name"])
        if not element_key and rec.get("element_key"):
            element_key = str(rec["element_key"])
        if page_name and element_key:
            break
    page_name = page_name or "UnknownPage"
    element_key = element_key or "unknown_element"
    text_hint = (getattr(step, "name", None) or "").strip()

    async def _run() -> Any:
        return await healer.diagnose_step_failure(
            screenshot_path,
            page_name=page_name,
            element_key=element_key,
            text_hint=text_hint,
            step_context=step_ctx,
            heal_trace=heal_trace,
            action="click",
            verify=True,
        )

    try:
        loop = getattr(context, "loop", None) or asyncio.get_event_loop()
        loop.run_until_complete(_run())
    except Exception as e:
        print(f"[autoheal][vision] diagnose_step_failure failed: {e}")


def maybe_run_step_failure_vision(context: Any, step: Any) -> None:
    """If the step failed and vision diagnosis is enabled, screenshot + diagnose."""
    if not _vision_diagnosis_enabled():
        return
    try:
        from autoheal.auto_heal_ai_agent import is_ai_heal_enabled
    except Exception:
        return
    if not is_ai_heal_enabled():
        return
    if _safe_step_status(step) != "failed":
        return
    ensure_context_healer(context)
    path = capture_step_failure_screenshot(context, step)
    if path:
        run_failure_vision_diagnose(context, step, path)
