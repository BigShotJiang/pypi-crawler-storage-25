"""
Load a ``.env`` file for auto-heal and other tooling.

When this package is **installed as a wheel**, there is no fixed "repo root" next to
``autoheal/``; we therefore search **from the process current working directory** upward
for a file named ``.env`` (up to 12 parent directories).

When running from a **source checkout**, we also try the directory two levels above
``autoheal/dotenv_bootstrap.py`` (often the project root) so behavior matches the legacy
``config.dotenv_bootstrap`` layout.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

_MAX_WALK = 12


def _search_roots() -> List[Path]:
    ordered: List[Path] = []
    seen: set = set()

    def add(p: Path) -> None:
        p = p.resolve()
        if p in seen:
            return
        seen.add(p)
        ordered.append(p)

    # 1) Prefer a source-tree project root (…/autoheal/dotenv_bootstrap.py -> parent.parent)
    here = Path(__file__).resolve()
    if here.name == "dotenv_bootstrap.py" and here.parent.name == "autoheal":
        add(here.parent.parent)

    # 2) Walk up from cwd (works in consumer projects after ``pip install``)
    cur = Path.cwd().resolve()
    add(cur)
    for p in list(cur.parents)[:_MAX_WALK]:
        add(p)

    return ordered


def project_root() -> Path:
    """
    Return the first directory in the search list that contains a ``.env`` file,
    else the current working directory.
    """
    for base in _search_roots():
        if (base / ".env").is_file():
            return base
    return Path.cwd().resolve()


def load_project_dotenv(*, override: bool = False) -> bool:
    """
    Load the first ``.env`` found in the search path. Safe to call multiple times.

    Returns True if a file was loaded.
    """
    try:
        from dotenv import load_dotenv
    except ImportError:
        return False

    for base in _search_roots():
        env_path = base / ".env"
        if env_path.is_file():
            load_dotenv(dotenv_path=env_path, override=override)
            return True
    return False
