# What is installed with the `autoheal` distribution (AutoHeal on PyPI)

## Python packages (importable)

| Package | Purpose |
|--------|---------|
| `autoheal` | Full engine and public API: `AutoHeal`, `AutoHealAsync`, `HealerConfig`, step-context helpers (`build_step_context`, `publish_step_context`, `clear_step_context`), `build_project_index`, `bootstrap_workspace`, `dotenv_bootstrap`, updaters, registry helpers, `summarize_failed_locators`, and console entrypoints (`autoheal-init`, `autoheal-init --wire`, `autoheal-wire`, `autoheal-agent`). |

Submodules live under the same namespace (for example `autoheal.auto_heal_async`, `autoheal.auto_heal_integration`); prefer the stable exports from `import autoheal` where possible.

## Documentation (bundled under `autoheal/bundled_docs/`)

- `AUTO_HEAL.md` — runtime healing behavior
- `AUTO_HEAL_EXPORT_GUIDE.md` — build, install, scaffold, troubleshooting, quick start, publishing
- `auto_heal_updater_README.md` — updater utilities

Locate them after install:

```python
import importlib.resources as ir
import autoheal

# Python 3.9+: ir.files(autoheal).joinpath("bundled_docs", "AUTO_HEAL.md")
```

Or open `site-packages/autoheal/bundled_docs/` under your environment.

## Console scripts

- `autoheal-init` — scaffold dirs + `.env.example` + templates in a consumer project
- `autoheal-wire` — append Behave hook wiring + inject `AutoHealAsync` into `pages/base_page.py` when detected
- `autoheal-workspace-ai` — LLM proposes `selectors.json` from `features/` + `pages/` (`--apply` to write)
- `autoheal-agent` — registry probe / agent helper JSON output

## Not included

Application-specific code in this repository (`pages/`, `features/`, `rm_ui_utils/`, `config/environment_config.py`, etc.) is not part of the wheel. Consume this distribution as a **library dependency** and keep your page objects and BDD features in your own project.
