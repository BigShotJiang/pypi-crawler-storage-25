#!/usr/bin/env python3
"""
Summarize auto-heal failed/healed locators from reports/heal_audit/failed_locators.jsonl.

Usage:
  python -m autoheal.summarize_failed_locators [path_to_jsonl]

Default path: reports/heal_audit/failed_locators.jsonl

This gives a generic view of which locators failed and how they were fixed across all pages.
"""

import json
import sys
from pathlib import Path


def main():
    default_path = Path("reports/heal_audit/failed_locators.jsonl")
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else default_path
    if not path.exists():
        print(f"File not found: {path}")
        print("Run tests with AUTO_HEAL_ENABLED=true to generate this log.")
        return 1
    failed = []
    healed = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                if rec.get("event") == "locator_failed":
                    failed.append(rec)
                elif rec.get("event") == "locator_healed":
                    healed.append(rec)
            except json.JSONDecodeError:
                continue
    print("=" * 60)
    print("AUTO-HEAL FAILED / HEALED LOCATORS SUMMARY")
    print("=" * 60)
    print(f"Source: {path}")
    print(f"Locator failures (attempts): {len(failed)}")
    print(f"Locators healed:             {len(healed)}")
    print()
    if failed:
        print("--- FAILED (page.element_key | action | selectors) ---")
        for r in failed[:30]:
            page_key = f"{r.get('page_name', '')}.{r.get('element_key', '')}"
            action = r.get("action", "")
            selectors = r.get("failed_selectors", [])[:3]
            print(f"  {page_key} | {action} | {selectors}")
        if len(failed) > 30:
            print(f"  ... and {len(failed) - 30} more")
        print()
    if healed:
        print("--- HEALED (page.element_key | method | healed_with) ---")
        for r in healed[:30]:
            page_key = f"{r.get('page_name', '')}.{r.get('element_key', '')}"
            method = r.get("method", "")
            sel = r.get("healed_with", "")
            if len(sel) > 60:
                sel = sel[:57] + "..."
            print(f"  {page_key} | {method} | {sel}")
        if len(healed) > 30:
            print(f"  ... and {len(healed) - 30} more")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
