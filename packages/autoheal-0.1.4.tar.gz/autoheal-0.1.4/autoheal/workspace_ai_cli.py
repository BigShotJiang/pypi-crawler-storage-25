"""CLI: use the configured LLM to propose / merge selectors.json from features + pages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from autoheal.workspace_ai import collect_workspace_snapshot, run_workspace_ai


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Use AUTO_HEAL AI (Azure OpenAI or OpenAI-compatible) to propose selectors.json "
            "from Gherkin features and page object stubs."
        )
    )
    parser.add_argument("--workspace", default=".", help="Project root")
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Write merged selectors.json (default is dry-run)",
    )
    parser.add_argument(
        "--dump-snapshot",
        action="store_true",
        help="Print collected snapshot JSON to stdout and exit (no LLM call)",
    )
    parser.add_argument("--selectors-path", default="pages/selectors.json")
    parser.add_argument("--pages-dir", default="pages")
    args = parser.parse_args()
    root = Path(args.workspace).resolve()

    if args.dump_snapshot:
        snap = collect_workspace_snapshot(
            root,
            selectors_path=args.selectors_path,
        )
        print(json.dumps(snap, indent=2)[:500000])
        return

    proposal, msg = run_workspace_ai(
        root,
        dry_run=not args.apply,
        selectors_path=args.selectors_path,
    )
    print(msg)
    if proposal:
        print("--- model notes ---")
        for n in proposal.get("notes") or []:
            print(f"  - {n}")
        print(f"confidence: {proposal.get('confidence', 0):.2f}")


if __name__ == "__main__":
    main()
