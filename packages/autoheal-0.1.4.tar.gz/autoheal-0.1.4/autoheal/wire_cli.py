"""CLI: wire autoheal into a consumer test project (Behave + optional BasePage)."""

from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path
from typing import Any, List

from autoheal.base_page_wire import wire_base_page
from autoheal.behave_wire import patch_behave_environment_module

ENV_MARK_START = "# BEGIN_AUTOHEAL_WIRE (autoheal behave patch)"
ENV_MARK_END = "# END_AUTOHEAL_WIRE (autoheal behave patch)"

ENV_SNIPPET = """
{0}
import sys
import autoheal.behave_wire as _autoheal_bw
_autoheal_bw.patch_behave_environment_module(sys.modules[__name__])
{1}
""".strip()


def _append_environment_snippet(
    root: Path,
    env_rel: str,
    *,
    dry_run: bool,
) -> tuple[bool, str]:
    env_path = root / env_rel
    if not env_path.is_file():
        return False, f"missing {env_path} — create Behave environment or pass --env-file"
    text = env_path.read_text(encoding="utf-8")
    if ENV_MARK_START in text:
        return False, f"skip {env_rel}: snippet already present"
    if "publish_step_context" in text and "before_step" in text:
        return (
            False,
            f"skip {env_rel}: already calls publish_step_context in before_step (manual wiring)",
        )
    snippet = ENV_SNIPPET.format(ENV_MARK_START, ENV_MARK_END) + "\n"
    if dry_run:
        return True, f"dry-run: would append Behave patch to {env_path}"
    env_path.write_text(text.rstrip() + "\n\n" + snippet, encoding="utf-8")
    return True, f"appended Behave patch to {env_path}"


def _load_environment_module(env_path: Path) -> Any:
    spec = importlib.util.spec_from_file_location("autoheal_wire_target_env", env_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {env_path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def wire_workspace(
    root: Path,
    *,
    env_file: str = "features/environment.py",
    skip_behave: bool = False,
    skip_base_page: bool = False,
    dry_run: bool = False,
    apply_runtime_patch: bool = False,
) -> List[str]:
    root = root.resolve()
    lines: List[str] = []
    if not skip_behave:
        ok, msg = _append_environment_snippet(root, env_file, dry_run=dry_run)
        lines.append(msg)
        if apply_runtime_patch and ok and not dry_run:
            env_path = root / env_file
            try:
                mod = _load_environment_module(env_path)
                if patch_behave_environment_module(mod):
                    lines.append("runtime: patched loaded environment module (dev check only)")
            except Exception as e:
                lines.append(f"runtime patch note: {e}")
    if not skip_base_page:
        changed, msg = wire_base_page(root / "pages", dry_run=dry_run)
        lines.append(msg)
    return lines


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Wire autoheal into a project: append Behave hook patch to features/environment.py "
            "and inject healer into pages/base_page.py when BasePage.__init__(self, page) exists."
        )
    )
    parser.add_argument("--workspace", default=".", help="Project root (default: cwd)")
    parser.add_argument(
        "--env-file",
        default="features/environment.py",
        help="Path relative to workspace for Behave environment module",
    )
    parser.add_argument("--skip-behave", action="store_true", help="Do not modify environment.py")
    parser.add_argument("--skip-base-page", action="store_true", help="Do not modify base_page.py")
    parser.add_argument("--dry-run", action="store_true", help="Print actions without writing files")
    parser.add_argument(
        "--apply-runtime-patch",
        action="store_true",
        help="After editing, try importlib-loading environment and apply patch once (optional smoke test)",
    )
    args = parser.parse_args()
    root = Path(args.workspace)
    for line in wire_workspace(
        root,
        env_file=args.env_file,
        skip_behave=args.skip_behave,
        skip_base_page=args.skip_base_page,
        dry_run=args.dry_run,
        apply_runtime_patch=args.apply_runtime_patch,
    ):
        print(line)


if __name__ == "__main__":
    main()
