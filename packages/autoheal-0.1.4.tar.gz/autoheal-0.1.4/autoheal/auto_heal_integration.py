"""Runner-agnostic helpers for publishing step context to auto-heal AI.

This module is intentionally independent from Behave. Any runner can call:

1) ``build_step_context(...)`` to construct context payload.
2) ``publish_step_context(payload)`` before step execution.
3) ``clear_step_context()`` after step execution.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def build_step_context(
    *,
    step_keyword: str,
    step_name: str,
    scenario_name: str = "",
    scenario_steps: Optional[List[str]] = None,
    feature_name: str = "",
    feature_path: str = "",
    data: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    step_text = f"{step_keyword or ''} {step_name or ''}".strip()
    return {
        "step_keyword": step_keyword or "",
        "step_name": step_name or "",
        "step_text": step_text,
        "scenario_name": scenario_name or "",
        "scenario_steps": list(scenario_steps or []),
        "feature_name": feature_name or "",
        "feature_path": feature_path or "",
        "data": dict(data or {}),
    }


def publish_step_context(payload: Dict[str, Any]) -> None:
    """Publish step context to AutoHealAsync global state."""
    from autoheal.auto_heal_async import set_current_step_context

    set_current_step_context(dict(payload or {}))


def clear_step_context() -> None:
    """Clear step context from AutoHealAsync global state."""
    from autoheal.auto_heal_async import clear_current_step_context

    clear_current_step_context()
