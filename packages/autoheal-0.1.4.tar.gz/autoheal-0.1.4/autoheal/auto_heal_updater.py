import argparse
import difflib
import getpass
import hashlib
import json
import pprint
import re
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from playwright.sync_api import sync_playwright

SELECTORS_PATH = Path("pages/selectors.json")
AUDIT_DIR = Path("reports/heal_audit")
BACKUP_DIR = Path("pages/backups")

DEFAULT_MIN_CONFIDENCE = 0.9
DEFAULT_TIMEOUT_MS = 2000


def load_selectors(path: Path = SELECTORS_PATH) -> dict:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def backup_selectors(
    path: Path = SELECTORS_PATH, backup_dir: Path = BACKUP_DIR
) -> Path:
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    short_hash = hashlib.md5(str(time.time()).encode("utf-8")).hexdigest()[:8]
    backup_path = backup_dir / f"{path.stem}_{timestamp}_{short_hash}{path.suffix}"
    shutil.copy2(path, backup_path)
    return backup_path


def save_selectors(data: dict, path: Path = SELECTORS_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)


def save_audit(audit_record: dict, audit_dir: Path = AUDIT_DIR) -> Path:
    audit_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    short_hash = hashlib.md5(json.dumps(audit_record, sort_keys=True).encode("utf-8")).hexdigest()[:8]
    audit_path = audit_dir / f"audit_{timestamp}_{short_hash}.json"
    with audit_path.open("w", encoding="utf-8") as handle:
        json.dump(audit_record, handle, indent=2, sort_keys=True)
    return audit_path


def text_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def _safe_inner_text(node_handle) -> str:
    try:
        return node_handle.inner_text().strip()
    except Exception:
        return ""


def _safe_attr(node_handle, name: str) -> str:
    try:
        value = node_handle.get_attribute(name)
        return value.strip() if value else ""
    except Exception:
        return ""


def _normalize_text(value: str, max_len: int = 40) -> str:
    cleaned = re.sub(r"\s+", " ", value.strip())
    return cleaned[:max_len] if len(cleaned) > max_len else cleaned


def _selector_prefix_xpath(selector: str) -> str:
    trimmed = selector.strip()
    if trimmed.startswith("xpath="):
        return trimmed
    if trimmed.startswith("//") or trimmed.startswith("(") or trimmed.startswith("/"):
        return f"xpath={trimmed}"
    return trimmed


def candidate_selectors_for_element(page, node_handle) -> List[str]:
    selectors: List[str] = []
    tag = node_handle.evaluate("el => el.tagName.toLowerCase()")
    data_testid = _safe_attr(node_handle, "data-testid")
    element_id = _safe_attr(node_handle, "id")
    name = _safe_attr(node_handle, "name")
    aria_label = _safe_attr(node_handle, "aria-label")
    role = _safe_attr(node_handle, "role")
    text = _safe_inner_text(node_handle)
    text_snippet = _normalize_text(text, max_len=30)

    if data_testid:
        selectors.append(f"{tag}[data-testid='{data_testid}']")
    if element_id:
        if re.match(r"^[A-Za-z_][\w\-\:\.]*$", element_id):
            selectors.append(f"#{element_id}")
        selectors.append(f"{tag}[id='{element_id}']")
    if name:
        selectors.append(f"{tag}[name='{name}']")
    if aria_label:
        selectors.append(f"{tag}[aria-label='{aria_label}']")
    if role and text_snippet:
        selectors.append(f"[role='{role}']:has-text('{text_snippet}')")
    if text_snippet:
        selectors.append(f"{tag}:has-text('{text_snippet}')")

    class_list = node_handle.evaluate("el => Array.from(el.classList || [])")
    class_list = [cls for cls in class_list if cls and len(cls) <= 30]
    if class_list:
        selectors.append(f"{tag}.{class_list[0]}")
        if len(class_list) >= 2:
            selectors.append(f"{tag}.{class_list[0]}.{class_list[1]}")

    css_path = compute_simple_css_path(node_handle)
    if css_path:
        selectors.append(css_path)

    xpath = compute_xpath(node_handle)
    if xpath:
        selectors.append(xpath)

    seen = set()
    deduped: List[str] = []
    for selector in selectors:
        if selector not in seen:
            seen.add(selector)
            deduped.append(selector)
    return deduped


def compute_simple_css_path(node_handle) -> Optional[str]:
    try:
        path = node_handle.evaluate(
            """el => {
                const escape = (value) => {
                  if (window.CSS && CSS.escape) {
                    return CSS.escape(value);
                  }
                  return value.replace(/[^a-zA-Z0-9_-]/g, '\\\\$&');
                };
                const parts = [];
                let current = el;
                let depth = 0;
                while (current && current.nodeType === 1 && depth < 5) {
                  const tag = current.tagName.toLowerCase();
                  if (current.id) {
                    parts.push(`#${escape(current.id)}`);
                    break;
                  }
                  let segment = tag;
                  if (current.classList && current.classList.length > 0) {
                    const cls = current.classList[0];
                    if (cls) {
                      segment += `.${escape(cls)}`;
                    }
                  }
                  const parent = current.parentElement;
                  if (parent) {
                    const siblings = Array.from(parent.children).filter(
                      child => child.tagName === current.tagName
                    );
                    if (siblings.length > 1) {
                      const index = siblings.indexOf(current) + 1;
                      segment += `:nth-of-type(${index})`;
                    }
                  }
                  parts.push(segment);
                  current = parent;
                  depth += 1;
                }
                return parts.reverse().join(" > ");
            }"""
        )
        return path if path else None
    except Exception:
        return None


def compute_xpath(node_handle) -> Optional[str]:
    try:
        return node_handle.evaluate(
            """el => {
                const getIndex = (node) => {
                  let index = 1;
                  let sibling = node.previousSibling;
                  while (sibling) {
                    if (sibling.nodeType === 1 && sibling.tagName === node.tagName) {
                      index += 1;
                    }
                    sibling = sibling.previousSibling;
                  }
                  return index;
                };
                const segments = [];
                let current = el;
                while (current && current.nodeType === 1) {
                  const tag = current.tagName.toLowerCase();
                  const index = getIndex(current);
                  segments.unshift(`${tag}[${index}]`);
                  if (current.tagName.toLowerCase() === 'html') {
                    break;
                  }
                  current = current.parentNode;
                }
                return '/' + segments.join('/');
            }"""
        )
    except Exception:
        return None


def uniqueness_score_for_selector(page, selector: str) -> int:
    resolved = _selector_prefix_xpath(selector)
    try:
        return len(page.query_selector_all(resolved))
    except Exception:
        return 0


def _extract_text_for_element(page, element) -> str:
    text = ""
    try:
        text = element.inner_text().strip()
    except Exception:
        text = ""
    if not text:
        try:
            text = element.get_attribute("aria-label") or ""
            text = text.strip()
        except Exception:
            text = ""
    if not text:
        try:
            text = element.get_attribute("placeholder") or ""
            text = text.strip()
        except Exception:
            text = ""
    if not text:
        try:
            element_id = element.get_attribute("id")
            if element_id:
                label = page.query_selector(f"label[for='{element_id}']")
                if label:
                    text = label.inner_text().strip()
        except Exception:
            text = ""
    return text


def score_candidate(page, candidate: str, text_hint: Optional[str]) -> float:
    if uniqueness_score_for_selector(page, candidate) != 1:
        return 0.0

    selector = _selector_prefix_xpath(candidate)
    element = page.query_selector(selector)
    if element is None:
        return 0.0

    text_sim = 0.0
    if text_hint:
        element_text = _extract_text_for_element(page, element)
        text_sim = text_similarity(text_hint.lower(), element_text.lower())

    bonus = 0.0
    if "data-testid" in candidate:
        bonus = 0.25
    elif "#" in candidate or "[id=" in candidate:
        bonus = 0.15

    score = 0.5 + (text_sim * 0.4) + bonus
    return min(score, 1.0)


def _element_matches_hint(node_handle, text_hint: str) -> bool:
    if not text_hint:
        return False
    hint = text_hint.lower()
    for value in (
        _safe_inner_text(node_handle),
        _safe_attr(node_handle, "aria-label"),
        _safe_attr(node_handle, "placeholder"),
        _safe_attr(node_handle, "name"),
        _safe_attr(node_handle, "id"),
    ):
        if value and hint in value.lower():
            return True
    return False


def find_best_selector_for_hint(
    page, text_hint: Optional[str], max_candidates: int = 8
) -> Optional[dict]:
    selector_query = "input, textarea, button, a, label, [role='button'], [role='textbox'], [aria-label]"
    nodes = page.query_selector_all(selector_query)

    matching_nodes = []
    other_nodes = []
    for node in nodes:
        if text_hint and _element_matches_hint(node, text_hint):
            matching_nodes.append(node)
        else:
            other_nodes.append(node)

    ordered_nodes = matching_nodes + other_nodes
    ordered_nodes = ordered_nodes[:200]

    candidate_scores: Dict[str, float] = {}
    for node in ordered_nodes:
        for candidate in candidate_selectors_for_element(page, node):
            if candidate in candidate_scores:
                continue
            score = score_candidate(page, candidate, text_hint)
            if score > 0:
                candidate_scores[candidate] = score

    if not candidate_scores:
        return None

    sorted_candidates = sorted(
        candidate_scores.items(), key=lambda item: item[1], reverse=True
    )
    top_candidates = dict(sorted_candidates[:max_candidates])
    best_selector, best_score = sorted_candidates[0]
    return {
        "selector": best_selector,
        "confidence": best_score,
        "all_candidates": top_candidates,
    }


def update_selector_registry(
    page_name: str,
    element_key: str,
    new_selector: str,
    confidence: float,
    user: str = "auto-scan",
    apply: bool = False,
    min_confidence: float = DEFAULT_MIN_CONFIDENCE,
) -> dict:
    selectors = load_selectors()
    page_entry = selectors.setdefault(page_name, {})
    element_entry = page_entry.setdefault(
        element_key,
        {"primary": new_selector, "fallbacks": [], "metadata": {}, "history": []},
    )

    now_iso = datetime.now(timezone.utc).isoformat()
    previous_primary = element_entry.get("primary")
    if previous_primary and previous_primary != new_selector:
        element_entry["previous_primary"] = previous_primary
        history = element_entry.setdefault("history", [])
        history.append(
            {
                "selector": previous_primary,
                "timestamp": now_iso,
                "updated_by": user,
            }
        )

    element_entry["primary"] = new_selector
    element_entry.setdefault("fallbacks", [])
    metadata = element_entry.setdefault("metadata", {})
    metadata["last_auto_updated_by"] = user
    metadata["last_auto_updated_on"] = now_iso
    metadata["last_auto_confidence"] = confidence
    metadata["last_auto_applied"] = apply

    if apply:
        if confidence < min_confidence:
            raise ValueError("Confidence below minimum threshold for apply.")
        backup_path = backup_selectors()
        save_selectors(selectors)
        return {"status": "applied", "backup": str(backup_path)}

    return {
        "status": "proposed",
        "proposed_selector": new_selector,
        "confidence": confidence,
    }


def run_single_update(
    url: str,
    page_name: str,
    element_key: str,
    text_hint: Optional[str] = None,
    dry_run: bool = True,
    apply: bool = False,
    min_confidence: float = DEFAULT_MIN_CONFIDENCE,
    headless: bool = True,
    screenshots: bool = True,
    user: Optional[str] = None,
) -> dict:
    user = user or getpass.getuser()
    audit = {
        "url": url,
        "page_name": page_name,
        "element_key": element_key,
        "text_hint": text_hint,
        "before_screenshot": None,
        "after_screenshot": None,
        "candidates": {},
        "chosen_selector": None,
        "confidence": 0.0,
        "verification_ok": False,
        "dry_run": dry_run,
        "apply_requested": apply,
        "min_confidence": min_confidence,
        "user": user,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=headless)
    page = browser.new_page()
    page.set_default_timeout(DEFAULT_TIMEOUT_MS)

    try:
        page.goto(url, wait_until="load", timeout=60000)
        if screenshots:
            AUDIT_DIR.mkdir(parents=True, exist_ok=True)
            before_name = hashlib.md5(
                f"{url}-{page_name}-{element_key}-before".encode("utf-8")
            ).hexdigest()[:10]
            before_path = AUDIT_DIR / f"before_{before_name}.png"
            page.screenshot(path=str(before_path), full_page=True)
            audit["before_screenshot"] = str(before_path)

        result = find_best_selector_for_hint(page, text_hint)
        if not result:
            audit_path = save_audit(audit)
            return {"audit": audit, "audit_path": str(audit_path)}

        chosen_selector = result["selector"]
        confidence = result["confidence"]
        audit["candidates"] = result["all_candidates"]
        audit["chosen_selector"] = chosen_selector
        audit["confidence"] = confidence

        verification_ok = False
        if uniqueness_score_for_selector(page, chosen_selector) == 1:
            selector = _selector_prefix_xpath(chosen_selector)
            element = page.query_selector(selector)
            if element:
                try:
                    tag = element.evaluate("el => el.tagName.toLowerCase()")
                except Exception:
                    tag = ""
                if tag in ("input", "textarea"):
                    marker = "auto-heal-marker"
                    try:
                        element.fill(marker)
                        value = element.input_value()
                        verification_ok = value == marker
                    except Exception:
                        verification_ok = False
                else:
                    try:
                        element.hover()
                        verification_ok = True
                    except Exception:
                        verification_ok = False

        audit["verification_ok"] = verification_ok

        if screenshots:
            after_name = hashlib.md5(
                f"{url}-{page_name}-{element_key}-after".encode("utf-8")
            ).hexdigest()[:10]
            after_path = AUDIT_DIR / f"after_{after_name}.png"
            page.screenshot(path=str(after_path), full_page=True)
            audit["after_screenshot"] = str(after_path)

        if apply and confidence >= min_confidence:
            audit["update_result"] = update_selector_registry(
                page_name=page_name,
                element_key=element_key,
                new_selector=chosen_selector,
                confidence=confidence,
                user=user,
                apply=True,
                min_confidence=min_confidence,
            )

        audit_path = save_audit(audit)

        try:
            import allure  # type: ignore

            allure.attach(
                json.dumps(audit, indent=2, sort_keys=True),
                name="auto-heal-audit",
                attachment_type=allure.attachment_type.JSON,
            )
            if audit.get("before_screenshot"):
                allure.attach.file(
                    audit["before_screenshot"],
                    name="auto-heal-before",
                    attachment_type=allure.attachment_type.PNG,
                )
            if audit.get("after_screenshot"):
                allure.attach.file(
                    audit["after_screenshot"],
                    name="auto-heal-after",
                    attachment_type=allure.attachment_type.PNG,
                )
        except Exception:
            pass

        return {"audit": audit, "audit_path": str(audit_path)}
    finally:
        browser.close()
        playwright.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Auto-heal selector updater")
    parser.add_argument("--url", required=True)
    parser.add_argument("--page-name", required=True)
    parser.add_argument("--element-key", required=True)
    parser.add_argument("--text-hint")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--min-confidence", type=float, default=DEFAULT_MIN_CONFIDENCE)
    parser.add_argument("--headless", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--no-screenshots", action="store_true")
    parser.add_argument("--user")
    parser.add_argument("--timeout-ms", type=int)

    args = parser.parse_args()
    if args.timeout_ms:
        DEFAULT_TIMEOUT_MS = args.timeout_ms

    result = run_single_update(
        url=args.url,
        page_name=args.page_name,
        element_key=args.element_key,
        text_hint=args.text_hint,
        dry_run=not args.apply,
        apply=args.apply,
        min_confidence=args.min_confidence,
        headless=args.headless,
        screenshots=not args.no_screenshots,
        user=args.user,
    )
    pprint.pprint(result)
