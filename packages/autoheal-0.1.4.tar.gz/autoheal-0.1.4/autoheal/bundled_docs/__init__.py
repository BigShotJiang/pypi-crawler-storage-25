"""User documentation files shipped with the wheel (Markdown)."""
