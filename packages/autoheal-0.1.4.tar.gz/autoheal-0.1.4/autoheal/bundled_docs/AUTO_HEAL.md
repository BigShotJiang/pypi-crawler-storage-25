# Auto-Heal: How It Works

When a locator fails (element not found, click/fill times out), auto-heal finds a working selector and optionally updates the registry so the next run uses it.

## Flow (latest order)

When a step fails, the healer runs strategies in this order:

1. **Registry primary** – Try the primary selector from `pages/selectors.json` for this page + element key.
2. **Registry fallbacks** – Try each fallback selector from the registry.
3. **DOM scan** – Scrape the DOM using the **selector name / text hint** and heuristics; build candidates from `name`, `placeholder`, `aria-label`, `data-testid`, `id`; score and pick the best. *(Preferred when fallbacks fail.)*
4. **Fuzzy text** – Match visible text to the hint (with form-field heuristics and non-interactive elements filtered out).
5. **DOM proximity** – Find interactive elements (input, button, etc.) near text that contains the hint.

Any result that passes the **confidence threshold** (default 0.7) and is not a **bad selector** (e.g. script/style) is used; the step is retried and the registry can be updated.

---

## Text hint and element key

When the failed selector is **not** in the registry, the system still needs a **text hint** and an **element key** for DOM scan / fuzzy / proximity.

- **Text hint** is derived from the failed selector string:
  - From attributes: `[name="username"]` → `"username"`, `[placeholder="Email"]` → `"Email"`, `[aria-label="..."]`, `[data-testid="..."]`, `[title="..."]`
  - From `#id` and `.class` (e.g. `#login-btn` → `"login btn"`)
  - From `text=...` and `has-text("...")`
  - Fallback: first word of a sanitized slice of the selector
- **Element key** is derived from that hint (e.g. `"username"` → `username`) or from the optional `element_key` passed by the step (e.g. `username_input`).

This allows auto-heal to work for **any** failed locator, even if it was never in the registry.

---

## Confidence score

Confidence is a number between 0 and 1. A result is accepted only if it is **≥ confidence threshold** (default **0.7**, overridable with `AUTO_HEAL_MIN_CONFIDENCE`). Registry updates are applied only when confidence ≥ threshold.

| Method        | Confidence |
|---------------|------------|
| Primary       | **1.0** (exact registry match). |
| Fallback      | **1.0** (registry fallback worked). |
| DOM scan      | **score** (see formula below). |
| Fuzzy text    | **min(1.0, similarity + form bonus)**. |
| DOM proximity | **0.6** if element text equals hint, else **0.5**. |

**DOM scan score** (per candidate):

- Only candidates that match **exactly one** element are kept.
- `sim` = text similarity (SequenceMatcher) between `text_hint` and the element’s inner text (0–1).
- **Bonus** by selector type (semantic selectors preferred):
  - `[name=...]` or `[placeholder=...]`: **+0.3**
  - `data-testid`: **+0.25**
  - `[aria-label=...]`: **+0.2**
  - `#id` or `[id=...]`: **+0.1**
- **Formula:** `score = 0.5 + (sim × 0.4) + bonus`, capped at 1.0.

**Fuzzy text confidence:**

- `similarity` = SequenceMatcher between `text_hint` and the element’s **inner text** (0–1).
- If the element key / text hint suggests a **form field** (username, password, email, etc.) and the tag is `input`, `button`, `select`, or `textarea`, a **+0.2** bonus is applied.
- `confidence = min(1.0, similarity + bonus)`.

---

## Fuzzy text search (details)

- **Input:** `text_hint` (e.g. from the failed selector) and optional `element_key` (e.g. `username_input`).
- **Process:**
  - Query all elements under `body`.
  - **Skip** non-interactive tags: `script`, `style`, `link`, `noscript`, `head`, `meta`, `svg`.
  - For each remaining element with non-empty inner text, compute **SequenceMatcher**(`text_hint`, element text). Ratio is the similarity (0–1).
  - Keep only elements with similarity **≥ threshold** (default 0.7).
  - **Heuristic:** If `element_key` or `text_hint` suggests a form field (username, password, email, login, search), **prefer** `input`, `button`, `select`, `textarea` (add +0.2 to score) and **ignore** other tags except `a` and `label`.
  - Pick the element with the **highest score**; build a **stable selector** (prefer `tag#id`, else short CSS path). If that selector is in the **bad-selector** list (e.g. script/style), discard and return nothing.
- **Output:** `{ "selector": "...", "confidence": ... }` or `None`.

---

## Heuristics

- **Bad selector filter** – These are never returned: `#client-scripts`, any selector containing `script`, `style`, `noscript`, `link#`, etc. Ensures we don’t heal onto script/style elements.
- **Form-field hint** – If `element_key` or `text_hint` contains one of: `username`, `password`, `email`, `user_name`, `password_input`, `login`, `search`, then fuzzy search prefers input-like tags and DOM scan prioritizes semantic attributes (`name`, `placeholder`).
- **DOM scan** – Only considers elements whose combined text (text content, `aria-label`, `placeholder`, `name`) contains the hint; skips `script`, `style`, `link`, `noscript`, `head`, `meta`; and drops candidates whose selector is bad (e.g. script-like ids).

---

## Example: Login username field

- **Scenario:** `LoginPage` step uses a wrong selector (e.g. `input[name="wrong"]`); no fallbacks or they fail.
- **Detection:** Failure is passed to the healer with `page_name=LoginPage`, failed selectors `["input[name=\"wrong\"]"]`.
- **Text hint:** From `[name="wrong"]` we get `"wrong"`, or the step may pass `text_hint="Username"` and `element_key="username_input"`.
- **DOM scan (Step 3):**
  - Scan DOM for elements whose text/name/placeholder/aria-label contains `"username"` (or the derived hint).
  - Collect candidates such as `input[name="username"]`, `input[placeholder="Email address"]`, etc.; skip script/style and bad ids.
  - For `input[name="username"]`: count = 1, text similarity to "username" high, bonus +0.3 for `[name=...]` → e.g. **score ≈ 0.5 + 0.36 + 0.3 = 1.0** (capped).
  - Return `{ "selector": "input[name=\"username\"]", "confidence": 1.0, "method": "dom_scan" }`.
- **If DOM scan didn’t return:** Fuzzy (Step 4) would look for an element whose inner text matches "Username" and prefer `input`/`button`; proximity (Step 5) would look for an interactive element near that text.
- **Outcome:** Step is retried with `input[name="username"]`; if `AUTO_HEAL_APPLY` is true, `pages/selectors.json` is updated and a backup is written to `pages/backups/`.

**Runs without auto-heal:** Page objects (e.g. `LoginPage`) use **registry-first** selectors: they call `_get_selectors_for_element(element_key, default_list)`, which returns the primary + fallbacks from `pages/selectors.json` when present, otherwise the hardcoded default. So after one successful run with auto-heal, the registry contains the healed locator; the next run (with or without `--auto-heal`) loads that from the registry and uses it first. The page object file (`.py`) is not rewritten; the single source of truth for healed selectors is `pages/selectors.json`.

---

## Logs generated by auto-heal

| What | Location |
|------|----------|
| **Failed / healed locators** (one JSON line per event) | [reports/heal_audit/failed_locators.jsonl](../reports/heal_audit/failed_locators.jsonl) |
| **Per-heal audit** (JSON + before/after screenshots) | [reports/heal_audit/](../reports/heal_audit/) |
| **DOM scan audits** | `reports/heal_audit/dom_scan_*.json` |
| **Diagnostic trace** (healer created, username/password heal steps) | [reports/autoheal_diagnostic.log](../reports/autoheal_diagnostic.log) |
| **Selector registry** (updated after heal) | [pages/selectors.json](../pages/selectors.json) |
| **Backups before registry updates** | [pages/backups/](../pages/backups/) |

**Quick summary of failures/heals:**

```bash
python -m autoheal.summarize_failed_locators
```

Reads [reports/heal_audit/failed_locators.jsonl](../reports/heal_audit/failed_locators.jsonl) and prints which locators failed and which were healed.

---

## Enabling / disabling

- **Enable:** run with `--auto-heal` or set `AUTO_HEAL_ENABLED=true`.
- **Do not persist updates:** set `AUTO_HEAL_APPLY=false`.
- **Minimum confidence:** set `AUTO_HEAL_MIN_CONFIDENCE` (e.g. `0.8`).
- **More console output:** set `AUTO_HEAL_DEBUG=true`.
