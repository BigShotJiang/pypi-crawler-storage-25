# Auto-heal Export Guide

This repository ships **AutoHeal** as the **`autoheal`** distribution on PyPI: a single importable package, also named **`autoheal`**, with no top-level `utils` name (safe to use alongside your own project layout).

## Quick start (consumer project)

1. Install Python 3.10+ and this package (wheel, sdist, or Git URL — see below).
2. Install Playwright browsers (required before any heal that drives a real browser):

   ```bash
   playwright install chromium
   ```

3. Scaffold defaults from your project root:

   ```bash
   autoheal-init
   ```

4. In your test code, construct a healer and call `locate` (see **Public imports** and `AUTO_HEAL_INTEGRATION.md` from the scaffold).

## Install options

- **Local wheel or sdist** (after `python -m build`):

  ```bash
  python -m pip install "dist/autoheal-<version>-py3-none-any.whl"
  ```

- **Git URL** (replace with your repository and ref):

  ```bash
  python -m pip install "git+https://github.com/your-org/your-repo.git@main#subdirectory=."
  ```

  If the library lives at the repo root with `pyproject.toml` as here, omit `subdirectory` or set it to the folder that contains `pyproject.toml`.

- **PyPI** — after maintainers publish the project:

  ```bash
  python -m pip install autoheal
  ```

## Publishing to PyPI (maintainers)

1. Bump `version` in `pyproject.toml`.
2. `python -m pip install build twine`
3. `python -m build`
4. `python -m twine check dist/*`
5. `python -m twine upload dist/*` (configure [PyPI API token](https://pypi.org/help/) first; scope the token to the **`autoheal`** project on PyPI).

## Build

```bash
python -m pip install build
python -m build
```

Build artifacts are created under `dist/`:

- `autoheal-<version>-py3-none-any.whl`
- `autoheal-<version>.tar.gz`

## Scaffold (automatic file layout in the consumer project)

After install, run once from your test project root (or pass `--workspace`):

```bash
autoheal-init
# or
autoheal-init --workspace C:\path\to\other-project
```

This creates directories and templates:

- `pages/selectors.json` (empty registry `{}`)
- `pages/backups/`
- `reports/heal_audit/`
- `screenshots/`
- `.env.example` (all auto-heal and AI variables; copy to `.env` and add secrets)
- `AUTO_HEAL_INTEGRATION.md` (copy-paste code snippets)

Use `--force` to overwrite templates that already exist.

### Wire Behave + `BasePage` automatically

To append hook wiring to `features/environment.py` and inject `AutoHealAsync` into `pages/base_page.py` (when a standard `BasePage` pattern is detected), run:

```bash
autoheal-init --wire
# or after scaffold only:
autoheal-wire --workspace .
```

Preview changes: `autoheal-wire --dry-run`. Non-standard layouts may still need manual edits (see `AUTO_HEAL_INTEGRATION.md`).

### AI-assisted workspace and failure diagnosis

With `AUTO_HEAL_AI_ENABLED=true` and a configured LLM (Azure, OpenAI, or OpenAI-compatible `OPENAI_BASE_URL` for local servers):

1. **Propose `selectors.json` from Gherkin + page objects** (dry-run prints the plan; `--apply` writes):

   ```bash
   autoheal-workspace-ai --workspace .
   autoheal-workspace-ai --workspace . --apply
   ```

2. **Runtime:** `AutoHealAsync.locate` already uses **DOM crawling** (inventory) + **LLM** rounds when AI is on.

3. **After a failed Behave step:** the wired hooks capture a screenshot and call **vision diagnosis** (`diagnose_step_failure`) when `AUTO_HEAL_SCREENSHOT_DIAGNOSIS=true`, using a **multimodal** model on your backend.

Programmatic: `from autoheal import collect_workspace_snapshot, run_workspace_ai`.

Same behavior without the console script:

```bash
python -m autoheal
python -m autoheal --workspace C:\path\to\project
```

### Troubleshooting: `ModuleNotFoundError: No module named 'autoheal'`

That means the **wheel is not installed** in the Python environment that runs `autoheal-init`, or **two different Pythons** are in play (script from user `Scripts`, packages in a venv).

Fix:

1. Use one interpreter for everything:

   ```powershell
   cd C:\path\to\your-test-project
   python -m pip show autoheal
   ```

   If it prints nothing, install (or reinstall) the wheel:

   ```powershell
   python -m pip install --force-reinstall "C:\full\path\to\autoheal-0.1.0-py3-none-any.whl"
   ```

2. Confirm imports:

   ```powershell
   python -c "import autoheal; print(autoheal.__file__)"
   ```

3. Run scaffold with that same `python`:

   ```powershell
   python -m autoheal
   ```

`python -m build` does **not** run this; only `autoheal-init` / `python -m autoheal` (or `bootstrap_workspace` in code) does.

You still wire `AutoHealAsync` and step-context hooks into your test runner yourself; that cannot be guessed safely for every framework.

## Public imports

```python
from autoheal import AutoHeal, AutoHealAsync, HealerConfig
from autoheal import build_step_context, publish_step_context, clear_step_context
from autoheal import build_project_index
from autoheal import bootstrap_workspace
```

Programmatic scaffold (same as CLI):

```python
from pathlib import Path
from autoheal import bootstrap_workspace

bootstrap_workspace(Path("."), force=False)
```

## Agentic helper CLI

The package exposes:

```bash
autoheal-agent --help
```

This wraps the offline tool loop for proposing and applying locator updates:
read/search/project-index/probe/sanity-check.

## Environment variables (portable config)

- `AUTO_HEAL_REPORTS_DIR`
- `AUTO_HEAL_SELECTORS_PATH`
- `AUTO_HEAL_BACKUP_DIR`
- `AUTO_HEAL_PAGES_DIR`
- `AUTO_HEAL_AI_BACKEND` (`azure` or `openai`)
- `AUTO_HEAL_AI_ENABLED`
- Azure: `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_DEPLOYMENT`
- OpenAI: `OPENAI_API_KEY`, `OPENAI_MODEL`, optional `OPENAI_BASE_URL`

