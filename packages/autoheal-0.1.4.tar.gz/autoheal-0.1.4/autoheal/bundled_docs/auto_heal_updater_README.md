AUTO-HEAL Overview:

The auto-heal updater scans a page DOM with Playwright and proposes a best-fit selector for a given page and element key. 
It writes an audit JSON (plus optional before/after screenshots) under `reports/heal_audit/`, and only updates `pages/selectors.json` when `--apply` is used and confidence meets `--min-confidence`.

Example usage: `python -m autoheal.auto_heal_updater --url file:///C:/path/to/test_login.html --page-name LoginPage --element-key username_input --text-hint "Username"` for a dry run, or add `--apply --min-confidence 0.9` to write after a backup is created in `pages/backups/`.

## Generic auto-heal for all locators

Auto-heal is applied generically whenever a locator fails in any page that uses `BasePage` methods (`wait_and_click`, `wait_and_fill`, `is_element_visible`, `try_multiple_selectors`, etc.):

1. **Detect failure** – The failed selector(s) are passed to the healer with the current page class name.
2. **Find replacement** – The healer uses, in order: registry primary/fallbacks, fuzzy text search, DOM proximity, and DOM scan (scraping by text_hint). Text hints are derived from the failed selector (e.g. `[name="x"]`, `[aria-label="x"]`, `#id`, placeholder).
3. **Update locator** – When a replacement is found with sufficient confidence, it is written to `pages/selectors.json` (with backup in `pages/backups/`) so future runs use the fixed locator.

**Failed / healed audit:** All failures and heals are appended to `reports/heal_audit/failed_locators.jsonl` (one JSON object per line). To see which locators failed and how they were fixed, run:

  `python -m autoheal.summarize_failed_locators`
