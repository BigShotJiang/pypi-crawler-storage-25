"""
Async Auto-Healing Engine for Playwright Test Automation.

This module provides an async auto-healing system that detects selector failures
and attempts to recover using fallback selectors, fuzzy text matching, and
DOM proximity heuristics. This is the async version for use with async Playwright API.
"""

import asyncio
import json
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Dict, List, Any, Tuple
from difflib import SequenceMatcher
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError

try:
    import allure
    ALLURE_AVAILABLE = True
except ImportError:
    ALLURE_AVAILABLE = False

try:
    from autoheal.auto_heal_ai_agent import (
        is_ai_heal_enabled,
        suggest_selector_via_llm,
        suggest_selector_via_azure,
    )
except ImportError:
    is_ai_heal_enabled = lambda: False  # type: ignore[misc, assignment]

    def suggest_selector_via_llm(*_a, **_k):  # type: ignore[misc]
        return None

    def suggest_selector_via_azure(*_a, **_k):  # type: ignore[misc]
        return None

try:
    from autoheal.auto_heal_project_index import build_project_index
except ImportError:
    build_project_index = None  # type: ignore[assignment]

_ELEMENT_KEY_DEFAULT_HINTS: Dict[str, str] = {
    "username_input": "Username or email",
    "password_input": "Password",
    "login_button": "Continue submit login",
    "tenant_dropdown": "Tenant dropdown",
    "tenant_option": "Tenant option",
    "tenant_submit": "Tenant submit",
    "tenant_submit_selectors": "Tenant apply submit",
    "tenant_submit_button": "Tenant submit",
}


def _default_text_hint_for_element_key(element_key: str) -> str:
    """Stable hint when callers omit ``text_hint`` (e.g. LoginPage after stripping hints)."""
    if not element_key:
        return ""
    k = element_key.strip()
    if k in _ELEMENT_KEY_DEFAULT_HINTS:
        return _ELEMENT_KEY_DEFAULT_HINTS[k]
    return k.replace("_", " ").title()


_CURRENT_STEP_CONTEXT: Dict[str, Any] = {}


def set_current_step_context(ctx: Optional[Dict[str, Any]]) -> None:
    """Set the current BDD step context (called from ``features/environment.py.before_step``)."""
    global _CURRENT_STEP_CONTEXT
    _CURRENT_STEP_CONTEXT = dict(ctx or {})


def get_current_step_context() -> Dict[str, Any]:
    """Return the current BDD step context (or {} if not set)."""
    return dict(_CURRENT_STEP_CONTEXT)


def clear_current_step_context() -> None:
    """Clear the current BDD step context (called after each step)."""
    global _CURRENT_STEP_CONTEXT
    _CURRENT_STEP_CONTEXT = {}


@dataclass(frozen=True)
class HealerConfig:
    """Runtime configuration for AutoHealAsync, independent of repository layout."""

    reporters_dir: str = "reports/heal_audit"
    selectors_path: str = "pages/selectors.json"
    backup_dir: str = "pages/backups"
    pages_dir: str = "pages"
    confidence_threshold: float = 0.7
    audit_all: bool = True
    audit_min_confidence: float = 0.8
    debug_enabled: bool = False
    apply_updates: bool = True
    include_project_index: bool = True

    @classmethod
    def from_env(
        cls,
        *,
        reporters_dir: Optional[str] = None,
        confidence_threshold: Optional[float] = None,
    ) -> "HealerConfig":
        env_confidence = confidence_threshold
        if env_confidence is None:
            raw_conf = os.getenv("AUTO_HEAL_MIN_CONFIDENCE")
            if raw_conf:
                try:
                    env_confidence = float(raw_conf)
                except ValueError:
                    env_confidence = None
        if env_confidence is None:
            env_confidence = 0.7
        selectors_path = os.getenv("AUTO_HEAL_SELECTORS_PATH", "pages/selectors.json")
        backup_dir = os.getenv("AUTO_HEAL_BACKUP_DIR", "pages/backups")
        pages_dir = os.getenv("AUTO_HEAL_PAGES_DIR", "pages")
        return cls(
            reporters_dir=reporters_dir or os.getenv("AUTO_HEAL_REPORTS_DIR", "reports/heal_audit"),
            selectors_path=selectors_path,
            backup_dir=backup_dir,
            pages_dir=pages_dir,
            confidence_threshold=env_confidence,
            audit_all=os.getenv("AUTO_HEAL_AUDIT_ALL", "true").lower() in ("1", "true", "yes"),
            audit_min_confidence=float(os.getenv("AUTO_HEAL_AUDIT_MIN_CONFIDENCE", "0.8")),
            debug_enabled=os.getenv("AUTO_HEAL_DEBUG", "false").lower() in ("1", "true", "yes"),
            apply_updates=os.getenv("AUTO_HEAL_APPLY", "true").lower() in ("1", "true", "yes"),
            include_project_index=os.getenv("AUTO_HEAL_INCLUDE_PROJECT_INDEX", "true").lower()
            in ("1", "true", "yes"),
        )


class AutoHealAsync:
    """
    Async auto-healing engine for Playwright page interactions.
    
    Provides intelligent selector recovery when primary selectors fail,
    with audit logging and verification capabilities.
    """
    
    def __init__(
        self,
        page: Page,
        reporters_dir: str = "reports/heal_audit",
        confidence_threshold: float = 0.7,
        config: Optional[HealerConfig] = None,
    ):
        """
        Initialize the AutoHealAsync engine.
        
        Args:
            page: Playwright async API Page instance
            reporters_dir: Directory for audit reports and screenshots
            confidence_threshold: Minimum confidence score for fuzzy matching (0-1)
        """
        self.page = page
        self.config = config or HealerConfig.from_env(
            reporters_dir=reporters_dir, confidence_threshold=confidence_threshold
        )
        self.reporters_dir = Path(self.config.reporters_dir)
        self.confidence_threshold = self.config.confidence_threshold
        self.audit_all = self.config.audit_all
        self.audit_min_confidence = self.config.audit_min_confidence
        self.debug_enabled = self.config.debug_enabled
        self.apply_updates = self.config.apply_updates
        self.selectors_path = Path(self.config.selectors_path)
        self.backup_dir = Path(self.config.backup_dir)
        self.pages_dir = Path(self.config.pages_dir)
        self.selectors_registry = self._load_selectors_registry()
        self.audit_counter = 0
        self.project_index = self._build_project_index()
        # (page_name, element_key) -> (healed selector, registry primary before this heal)
        self._page_object_scenario_patch_queue: Dict[Tuple[str, str], Tuple[str, Optional[str]]] = {}

        # Ensure audit directory exists
        self.reporters_dir.mkdir(parents=True, exist_ok=True)
        self._failed_locators_log = self.reporters_dir / "failed_locators.jsonl"

    def _build_project_index(self) -> Dict[str, Any]:
        """Best-effort project index for LLM constraint/context."""
        if not self.config.include_project_index or build_project_index is None:
            return {}
        try:
            return build_project_index(self.selectors_path, self.pages_dir)
        except Exception as e:
            self._debug(f"Project index build failed: {e}")
            return {}

    def record_locator_failure(
        self, page_name: str, element_key: str, failed_selectors: List[str], action: str = ""
    ) -> None:
        """Record that a locator failed (generic audit for all pages/locators)."""
        try:
            record = {
                "event": "locator_failed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "page_name": page_name,
                "element_key": element_key,
                "failed_selectors": failed_selectors,
                "action": action,
            }
            with open(self._failed_locators_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=True) + "\n")
        except Exception as e:
            self._debug(f"Failed to log locator failure: {e}")

    def record_locator_healed(
        self,
        page_name: str,
        element_key: str,
        failed_selectors: List[str],
        healed_with: str,
        method: str,
        confidence: float = 0.0,
    ) -> None:
        """Record that a failed locator was healed (generic audit)."""
        try:
            record = {
                "event": "locator_healed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "page_name": page_name,
                "element_key": element_key,
                "failed_selectors": failed_selectors,
                "healed_with": healed_with,
                "method": method,
                "confidence": confidence,
            }
            with open(self._failed_locators_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=True) + "\n")
        except Exception as e:
            self._debug(f"Failed to log locator healed: {e}")

    def _debug(self, message: str) -> None:
        if self.debug_enabled:
            print(f"[AUTOHEAL][DEBUG] {message}")
    
    def _load_selectors_registry(self) -> Dict[str, Any]:
        """
        Load selector registry from pages/selectors.json.
        
        Tries multiple possible locations to find the registry file.
        
        Returns:
            Dictionary containing selector registry data
        """
        # Try configured registry first, then common fallbacks
        possible_paths = [
            self.selectors_path,
            Path("pages/selectors.json"),  # Relative to current working directory
            Path(__file__).parent.parent / "pages" / "selectors.json",  # Relative to this file
        ]
        
        for registry_path in possible_paths:
            if registry_path.exists():
                try:
                    with open(registry_path, 'r', encoding='utf-8') as f:
                        return json.load(f)
                except (json.JSONDecodeError, IOError) as e:
                    print(f"Error loading selectors registry from {registry_path}: {e}")
                    continue
        
        # If none found, return empty dict
        print(f"Warning: Selectors registry not found. Tried: {[str(p) for p in possible_paths]}")
        return {}
    
    @staticmethod
    def _selector_not_excluded(selector: Optional[str], exclude: Optional[List[str]]) -> bool:
        if not selector or not exclude:
            return True
        norm = selector.strip()
        blocked = {(x or "").strip() for x in exclude if x}
        return norm not in blocked

    async def locate(
        self,
        page_name: str,
        element_key: str,
        timeout_ms: int = 2000,
        confidence_threshold: Optional[float] = None,
        text_hint: Optional[str] = None,
        exclude_selectors: Optional[List[str]] = None,
        action: Optional[str] = None,
        previous_attempts: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Locate an element using primary, fallback, then (when enabled) Azure OpenAI,
        then DOM scan, fuzzy text, and proximity heuristics.
        
        Args:
            page_name: Name of the page (e.g., "IssuerDetailsPage")
            element_key: Key for the element in the registry (e.g., "ai_summary_generate_button")
            timeout_ms: Timeout in milliseconds for selector attempts
            confidence_threshold: Override default confidence threshold
            exclude_selectors: Selectors that must not be returned (e.g. failed post-verify heal).
            
        Returns:
            Dictionary with "selector" and "confidence" keys, or None if not found
        """
        if confidence_threshold is None:
            confidence_threshold = self.confidence_threshold
        
        self._debug(f"Locate request: {page_name}.{element_key} (timeout={timeout_ms}ms)")

        # Get selector metadata from registry
        element_config = self._get_element_config(page_name, element_key)
        if not element_config:
            hint = (text_hint or "").strip() or _default_text_hint_for_element_key(element_key)
            if not hint:
                print(f"No configuration found for {page_name}.{element_key}")
                return None
            element_config = {
                "primary": "",
                "fallbacks": [],
                "metadata": {"text_hint": hint},
            }
        
        primary = element_config.get("primary", "")
        fallbacks = element_config.get("fallbacks", [])
        metadata = element_config.get("metadata", {})
        text_hint = (text_hint or metadata.get("text_hint", "") or "").strip()
        if not text_hint:
            text_hint = _default_text_hint_for_element_key(element_key)
        
        attempted_selectors = []
        
        # Step 1: Try primary selector
        if primary:
            attempted_selectors.append(primary)
            self._debug(f"Trying primary selector: {primary}")
            result = await self._try_selector(primary, timeout_ms)
            if result and self._selector_not_excluded(primary, exclude_selectors):
                self._debug("Primary selector succeeded")
                if self.audit_all:
                    await self._create_audit(
                        page_name=page_name,
                        element_key=element_key,
                        attempted_selectors=attempted_selectors,
                        healed_with=primary,
                        confidence=1.0,
                        method="primary"
                    )
                return {"selector": primary, "confidence": 1.0, "method": "primary"}
            if result and not self._selector_not_excluded(primary, exclude_selectors):
                self._debug("Primary selector matched but is excluded; skipping")
            self._debug("Primary selector failed")
        
        # Step 2: Try fallback selectors
        for fallback in fallbacks:
            attempted_selectors.append(fallback)
            self._debug(f"Trying fallback selector: {fallback}")
            result = await self._try_selector(fallback, timeout_ms)
            if result and self._selector_not_excluded(fallback, exclude_selectors):
                self._debug("Fallback selector succeeded")
                if self.audit_all or self.audit_min_confidence >= 1.0:
                    await self._create_audit(
                        page_name=page_name,
                        element_key=element_key,
                        attempted_selectors=attempted_selectors,
                        healed_with=fallback,
                        confidence=1.0,
                        method="fallback"
                    )
                return {"selector": fallback, "confidence": 1.0, "method": "fallback"}
            self._debug("Fallback selector failed")

        # Step 3: Azure OpenAI first among recovery strategies (when enabled + configured)
        ai_result = await self._ai_assisted_locate(
            page_name=page_name,
            element_key=element_key,
            text_hint=text_hint or "",
            attempted_selectors=list(attempted_selectors),
            confidence_threshold=confidence_threshold,
            timeout_ms=timeout_ms,
            exclude_selectors=exclude_selectors,
            action=action,
            previous_attempts=previous_attempts,
        )
        if ai_result:
            return ai_result
        
        # Step 4: DOM scan (DOM scraping by selector name / heuristics)
        if text_hint:
            self._debug(f"Trying DOM scan with text_hint='{text_hint}' (selector name / heuristics)")
            dom_scan_result = await self._dom_scan_for_locator_change(
                page_name,
                element_key,
                text_hint,
                attempted_selectors,
                confidence_threshold,
            )
            if dom_scan_result:
                selector = dom_scan_result.get("selector")
                if (
                    selector
                    and not self._is_bad_selector(selector)
                    and self._selector_not_excluded(selector, exclude_selectors)
                ):
                    return dom_scan_result
                self._debug("DOM scan returned bad or excluded selector, trying next strategy")
        
        # Step 5: Fuzzy text search if text_hint exists (with interactive-element filter)
        if text_hint:
            self._debug(f"Trying fuzzy search with text_hint='{text_hint}'")
            fuzzy_result = await self._fuzzy_text_search(
                text_hint, confidence_threshold, element_key=element_key
            )
            if fuzzy_result:
                selector = fuzzy_result["selector"]
                if self._is_bad_selector(selector):
                    self._debug(f"Fuzzy returned bad selector {selector}, skipping")
                elif not self._selector_not_excluded(selector, exclude_selectors):
                    self._debug(f"Fuzzy matched excluded selector {selector}, skipping")
                else:
                    confidence = fuzzy_result["confidence"]
                    attempted_selectors.append(f"fuzzy:{selector}")
                    self._debug(
                        f"Fuzzy match succeeded: selector={selector}, confidence={confidence:.2f}"
                    )
                    if self.audit_all or confidence < self.audit_min_confidence:
                        await self._create_audit(
                            page_name=page_name,
                            element_key=element_key,
                            attempted_selectors=attempted_selectors,
                            healed_with=selector,
                            confidence=confidence,
                            method="fuzzy_text"
                        )
                    if self.apply_updates and confidence >= self.confidence_threshold:
                        self._update_registry(page_name, element_key, selector, confidence)
                    return {"selector": selector, "confidence": confidence, "method": "fuzzy_text"}
            self._debug("Fuzzy match failed")
        
        # Step 6: DOM proximity heuristic
        if text_hint:
            self._debug(f"Trying DOM proximity with text_hint='{text_hint}'")
            proximity_result = await self._dom_proximity_search(text_hint)
            if proximity_result:
                selector = proximity_result["selector"]
                if self._is_bad_selector(selector):
                    self._debug(f"Proximity returned bad selector {selector}, skipping")
                elif not self._selector_not_excluded(selector, exclude_selectors):
                    self._debug(f"Proximity matched excluded selector {selector}, skipping")
                else:
                    confidence = proximity_result["confidence"]
                    attempted_selectors.append(f"proximity:{selector}")
                    self._debug(
                        f"Proximity match succeeded: selector={selector}, confidence={confidence:.2f}"
                    )
                    if self.audit_all or confidence < self.audit_min_confidence:
                        await self._create_audit(
                            page_name=page_name,
                            element_key=element_key,
                            attempted_selectors=attempted_selectors,
                            healed_with=selector,
                            confidence=confidence,
                            method="dom_proximity"
                        )
                    if self.apply_updates and confidence >= self.confidence_threshold:
                        self._update_registry(page_name, element_key, selector, confidence)
                    return {"selector": selector, "confidence": confidence, "method": "dom_proximity"}
            self._debug("Proximity match failed")

        # No selector found
        self._debug("No selector found after all strategies")
        return None

    async def _gather_dom_inventory_json(self, text_hint: str) -> str:
        """Collect a compact JSON array of actionable elements for the AI healing agent."""
        script = """
        (hint) => {
          const h = (hint || '').toLowerCase();
          const acc = new Set();
          const addAll = (nodes) => {
            nodes.forEach((el) => acc.add(el));
          };
          addAll(document.querySelectorAll(
            'input, button, select, textarea, a[href], [role="button"], [role="link"], ' +
            '[role="combobox"], [role="listbox"], [role="menu"], [data-testid], label'
          ));
          if (h) {
            const maxWalk = 600;
            let count = 0;
            const tree = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, null);
            let node = tree.currentNode;
            while (node && count < maxWalk) {
              count++;
              if (node.nodeType === 1) {
                const el = node;
                const t = ((el.innerText || el.textContent || '') + '').toLowerCase();
                if (t.includes(h)) acc.add(el);
              }
              node = tree.nextNode();
            }
          }
          const out = [];
          let i = 0;
          for (const el of acc) {
            if (i++ >= 90) break;
            try {
              out.push({
                tag: el.tagName.toLowerCase(),
                id: el.id || null,
                name: el.getAttribute('name'),
                type: el.getAttribute('type'),
                placeholder: el.getAttribute('placeholder'),
                ariaLabel: el.getAttribute('aria-label'),
                dataTestId: el.getAttribute('data-testid'),
                role: el.getAttribute('role'),
                href: el.getAttribute('href'),
                text: ((el.innerText || '') + '').slice(0, 120).replace(/\\s+/g, ' ').trim(),
              });
            } catch (e) {}
          }
          return JSON.stringify(out);
        }
        """
        try:
            raw = await self.page.evaluate(script, text_hint or "")
            return raw if isinstance(raw, str) else json.dumps(raw)
        except Exception as e:
            self._debug(f"DOM inventory gather failed: {e}")
            return "[]"

    async def _ai_assisted_locate(
        self,
        page_name: str,
        element_key: str,
        text_hint: str,
        attempted_selectors: List[str],
        confidence_threshold: float,
        timeout_ms: int,
        exclude_selectors: Optional[List[str]] = None,
        action: Optional[str] = None,
        previous_attempts: Optional[List[Dict[str, Any]]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Priority healing after registry: send DOM inventory + locator context to LLM, verify on page.

        Persistence (selectors.json + page-object patch + ``record_locator_healed``) is now performed
        by the orchestrator (``BasePage._auto_heal_action`` via ``commit_heal``) only AFTER the action
        verifies. This call merely returns a verified-visible suggestion plus its model metadata.
        """
        if not is_ai_heal_enabled():
            return None
        self._debug("Trying LLM-assisted locator recovery")
        dom_json = await self._gather_dom_inventory_json(text_hint)
        excl: List[str] = list(exclude_selectors or [])
        max_ai_rounds = int(os.getenv("AUTO_HEAL_AI_MAX_ROUNDS", "4"))
        step_ctx = get_current_step_context()
        prior_attempts: List[Dict[str, Any]] = list(previous_attempts or [])
        for ai_round in range(max_ai_rounds):
            payload_attempted = list(attempted_selectors) + [f"exclude:{x}" for x in excl]
            try:
                suggestion = await asyncio.to_thread(
                    suggest_selector_via_azure,
                    page_name,
                    element_key,
                    text_hint,
                    payload_attempted,
                    dom_json,
                    excl,
                    step_ctx,
                    action or "",
                    prior_attempts,
                    self.project_index,
                )
            except Exception as e:
                self._debug(f"AI heal invocation error: {e}")
                return None
            if not suggestion:
                return None
            selector = suggestion.get("selector", "")
            if not selector or self._is_bad_selector(selector):
                self._debug("AI suggestion missing or rejected as unsafe selector")
                print(
                    f"[AUTOHEAL][AI] rejected {page_name}.{element_key}: "
                    f"unsafe_or_empty suggestion={selector!r}"
                )
                return None
            if not self._selector_not_excluded(selector, excl):
                print(
                    f"[AUTOHEAL][AI] retry {page_name}.{element_key}: model repeated excluded "
                    f"selector={selector!r} (round {ai_round + 1}/{max_ai_rounds})"
                )
                excl.append(selector)
                continue
            visible = await self._try_selector(selector, timeout_ms)
            if not visible:
                self._debug("AI-suggested selector did not become visible in time")
                print(
                    f"[AUTOHEAL][AI] not_verified {page_name}.{element_key}: "
                    f"model_suggested={selector!r} (not visible within timeout)"
                )
                excl.append(selector)
                continue
            try:
                model_conf = float(suggestion.get("confidence", 0.72))
            except (TypeError, ValueError):
                model_conf = 0.72
            confidence = min(0.88, max(0.72, model_conf, confidence_threshold))
            attempted_selectors.append(f"ai:{selector}")
            model_reason = str(suggestion.get("reason") or "").strip()
            prior = [s for s in attempted_selectors if not str(s).startswith("ai:")]
            prev_preview = ", ".join(repr(x) for x in prior[:8])
            if len(prior) > 8:
                prev_preview += f", ... (+{len(prior) - 8} more)"
            print(
                f"[AUTOHEAL][AI] suggested {page_name}.{element_key}: "
                f"new_selector={selector!r} model_confidence={model_conf:.3f} "
                f"applied_confidence={confidence:.3f} verified=visible "
                f"(ai_round={ai_round + 1}, persistence=DEFERRED until action verifies)"
            )
            if model_reason:
                print(f"[AUTOHEAL][AI]   model_reason: {model_reason[:400]}")
            if prev_preview:
                print(f"[AUTOHEAL][AI]   failed_before_ai: {prev_preview}")
            if self.audit_all or confidence < self.audit_min_confidence:
                await self._create_audit(
                    page_name=page_name,
                    element_key=element_key,
                    attempted_selectors=attempted_selectors,
                    healed_with=selector,
                    confidence=confidence,
                    method="azure_openai",
                )
            return {
                "selector": selector,
                "confidence": confidence,
                "method": "azure_openai",
                "model_confidence": model_conf,
                "model_reason": model_reason,
                "verified": False,
            }
        print(
            f"[AUTOHEAL][AI] exhausted {page_name}.{element_key} after {max_ai_rounds} "
            f"round(s) (visibility or excluded repeats)"
        )
        return None

    def commit_heal(
        self,
        page_name: str,
        element_key: str,
        original_selectors: List[str],
        selector: str,
        confidence: float,
        method: str,
        *,
        model_confidence: Optional[float] = None,
        model_reason: Optional[str] = None,
    ) -> None:
        """Persist a heal AFTER the orchestrator confirms the action advanced UI state.

        Writes the audit log, updates ``pages/selectors.json``, and patches the page object source.
        Called by ``BasePage._auto_heal_action`` once post-action verification succeeds, so
        false-positive heals (visible but no UI change) are never written to the registry or page object.
        """
        try:
            if hasattr(self, "record_locator_healed"):
                self.record_locator_healed(
                    page_name, element_key, list(original_selectors or []), selector, method, confidence
                )
        except Exception as e:
            self._debug(f"commit_heal record_locator_healed skipped: {e}")
        try:
            confidence_threshold = self.confidence_threshold
            if self.apply_updates and confidence >= confidence_threshold:
                po_conf = model_confidence if model_confidence is not None else confidence
                self._update_registry(
                    page_name,
                    element_key,
                    selector,
                    confidence,
                    page_object_confidence=po_conf,
                )
                print(
                    f"[AUTOHEAL] committed {page_name}.{element_key}: "
                    f"selectors.json + page object updated (verified=action_advanced_state, "
                    f"confidence {confidence:.3f} >= {confidence_threshold})"
                )
            else:
                print(
                    f"[AUTOHEAL] committed {page_name}.{element_key}: skipped registry write "
                    f"(apply={self.apply_updates}, confidence {confidence:.3f} vs min {confidence_threshold})"
                )
        except Exception as e:
            self._debug(f"commit_heal _update_registry failed: {e}")

    async def diagnose_step_failure(
        self,
        screenshot_path: str,
        *,
        page_name: str,
        element_key: str,
        text_hint: str = "",
        step_context: Optional[Dict[str, Any]] = None,
        heal_trace: Optional[List[Dict[str, Any]]] = None,
        action: str = "click",
        verify: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """Diagnose a failed BDD step from its screenshot and (optionally) commit a verified heal.

        Flow:
          1. Send screenshot + step context to Azure OpenAI vision (``analyze_failure_screenshot``).
          2. If a candidate selector is returned and ``verify=True``, check it on the live page
             (visible + locator count > 0). If the page is closed or the selector cannot be
             verified, log to ``failed_locators.jsonl`` for human review and return the diagnosis
             without writing to the registry.
          3. Only when the selector verifies do we ``commit_heal`` (selectors.json + page object
             patch), tagging the method as ``screenshot_vision``.

        Returns the diagnosis dict (with an extra ``committed`` boolean) or ``None`` when
        diagnosis was skipped or unparseable.
        """
        try:
            from autoheal.auto_heal_ai_agent import analyze_failure_screenshot
        except Exception as e:
            self._debug(f"diagnose_step_failure import failed: {e}")
            return None

        try:
            dom_inventory_json = await self._get_dom_inventory_json()
        except Exception:
            dom_inventory_json = ""

        diagnosis = await asyncio.to_thread(
            analyze_failure_screenshot,
            screenshot_path,
            page_name=page_name,
            element_key=element_key,
            text_hint=text_hint,
            step_context=step_context,
            heal_trace=heal_trace,
            dom_inventory_json=dom_inventory_json,
            project_index=self.project_index,
        )
        if not diagnosis:
            return None

        diagnosis = dict(diagnosis)
        diagnosis["committed"] = False
        suggested = (diagnosis.get("selector") or "").strip()
        suggested_page = diagnosis.get("page_name") or page_name
        suggested_key = diagnosis.get("element_key") or element_key

        log_entry = {
            "event": "screenshot_diagnosis",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "page_name": suggested_page,
            "element_key": suggested_key,
            "screenshot": screenshot_path,
            "root_cause": diagnosis.get("root_cause", ""),
            "selector": suggested,
            "confidence": diagnosis.get("confidence", 0.0),
            "reason": diagnosis.get("reason", ""),
            "needs_prerequisite": diagnosis.get("needs_prerequisite", False),
            "action": action,
        }
        try:
            with open(self._failed_locators_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry, ensure_ascii=True) + "\n")
        except Exception as e:
            self._debug(f"diagnose_step_failure log skipped: {e}")

        if not suggested:
            print(
                f"[AUTOHEAL][VISION] Diagnosis for {suggested_page}.{suggested_key}: "
                f"root_cause={diagnosis.get('root_cause', '')!r} (no heal candidate)"
            )
            return diagnosis

        if not verify:
            print(
                f"[AUTOHEAL][VISION] Diagnosis (no verify) for {suggested_page}.{suggested_key}: "
                f"selector={suggested!r} confidence={diagnosis.get('confidence', 0.0):.2f}"
            )
            return diagnosis

        page_closed = False
        try:
            if hasattr(self.page, "is_closed"):
                page_closed = self.page.is_closed()
        except Exception:
            page_closed = True
        if page_closed:
            print(
                f"[AUTOHEAL][VISION] Page already closed; cannot verify suggested selector "
                f"{suggested!r} for {suggested_page}.{suggested_key}. Logged for review."
            )
            return diagnosis

        try:
            verified = await self._verify_selector_present(suggested)
        except Exception as e:
            self._debug(f"diagnose_step_failure verify failed: {e}")
            verified = False
        if not verified:
            print(
                f"[AUTOHEAL][VISION] Suggested {suggested!r} not present on the page; "
                f"refusing to patch {suggested_page}.{suggested_key}. Logged for review."
            )
            return diagnosis

        try:
            self.commit_heal(
                suggested_page,
                suggested_key,
                [],
                suggested,
                float(diagnosis.get("confidence", 0.0)),
                "screenshot_vision",
                model_confidence=float(diagnosis.get("confidence", 0.0)),
                model_reason=diagnosis.get("reason", ""),
            )
            diagnosis["committed"] = True
            print(
                f"[AUTOHEAL][VISION] Committed screenshot heal {suggested_page}.{suggested_key} -> "
                f"{suggested!r} (confidence {diagnosis.get('confidence', 0.0):.2f})"
            )
        except Exception as e:
            self._debug(f"diagnose_step_failure commit failed: {e}")
        return diagnosis

    async def _verify_selector_present(self, selector: str, timeout_ms: int = 1500) -> bool:
        """Confirm the suggested selector resolves to >=1 element and is visible on the live page."""
        try:
            loc = self.page.locator(selector).first
        except Exception:
            return False
        try:
            count = await loc.count()
        except Exception:
            count = 0
        if count <= 0:
            return False
        try:
            return await loc.is_visible(timeout=timeout_ms)
        except Exception:
            return False

    async def _get_dom_inventory_json(self) -> str:
        """Best-effort DOM inventory string for the vision agent (small, never raises)."""
        try:
            return await self._gather_dom_inventory_json("")
        except Exception:
            return ""

    def report_false_positive(
        self,
        page_name: str,
        element_key: str,
        selector: str,
        action: str,
        evidence: str = "no_observable_change",
        model_reason: str = "",
    ) -> None:
        """Record a verified-visible heal that did not advance UI state. Used by the orchestrator.

        The record is appended to ``failed_locators.jsonl`` so retraining/diagnostics can see it,
        and the next AI round (within the same step) is given this as ``previous_attempts``.
        """
        try:
            record = {
                "event": "locator_false_positive",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "page_name": page_name,
                "element_key": element_key,
                "selector": selector,
                "action": action,
                "evidence": evidence,
                "model_reason": model_reason or "",
            }
            with open(self._failed_locators_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=True) + "\n")
        except Exception as e:
            self._debug(f"report_false_positive log skipped: {e}")
    
    def _get_element_config(self, page_name: str, element_key: str) -> Optional[Dict[str, Any]]:
        """Get element configuration from registry."""
        page_config = self.selectors_registry.get(page_name, {})
        return page_config.get(element_key)

    def _is_bad_selector(self, selector: str) -> bool:
        """Reject selectors that point at non-interactive or known-bad elements (e.g. script, style)."""
        if not selector or len(selector) > 500:
            return True
        s = selector.lower()
        bad_patterns = (
            "#client-scripts",
            "script#",
            "script.",
            "[id*='script']",
            "[id*='style']",
            "style#",
            "style.",
            "noscript",
            "link#",
        )
        for pat in bad_patterns:
            if pat in s:
                return True
        return False

    def _element_key_suggests_input(self, element_key: str, text_hint: str) -> bool:
        """True if element_key or text_hint suggests a form input (username, password, email, etc.)."""
        combined = f"{element_key} {text_hint}".lower()
        return any(
            x in combined
            for x in ("username", "password", "email", "user_name", "password_input", "login", "search")
        )
    
    async def _try_selector(self, selector: str, timeout_ms: int) -> bool:
        """
        Try to locate an element using the given selector.
        
        Args:
            selector: CSS or XPath selector
            timeout_ms: Timeout in milliseconds
            
        Returns:
            True if element is found and visible, False otherwise
        """
        try:
            # Handle XPath selectors
            if selector.startswith("//") or selector.startswith("(//"):
                locator = self.page.locator(f"xpath={selector}")
            else:
                locator = self.page.locator(selector)
            
            await locator.wait_for(state="visible", timeout=timeout_ms)
            return True
        except PlaywrightTimeoutError:
            return False
        except Exception:
            return False
    
    async def _fuzzy_text_search(
        self,
        text_hint: str,
        threshold: float,
        element_key: str = "",
    ) -> Optional[Dict[str, Any]]:
        """
        Perform fuzzy text search to find elements matching text_hint.
        Skips non-interactive elements (script, style, etc.) and prefers
        input/button when element_key suggests a form field (username, password).
        """
        try:
            non_interactive_tags = {"script", "style", "link", "noscript", "head", "meta", "svg"}
            prefer_input = self._element_key_suggests_input(element_key, text_hint)
            all_elements = await self.page.query_selector_all("body *")
            best_match = None
            best_score = 0.0

            for element in all_elements:
                try:
                    tag_name = await element.evaluate("el => el.tagName.toLowerCase()")
                    if tag_name in non_interactive_tags:
                        continue
                    text_content = await element.inner_text()
                    if not text_content:
                        continue
                    similarity = SequenceMatcher(
                        None, text_hint.lower(), text_content.lower()
                    ).ratio()
                    if similarity < threshold:
                        continue
                    score = similarity
                    if prefer_input and tag_name in ("input", "button", "select", "textarea"):
                        score += 0.2
                    elif prefer_input and tag_name not in ("input", "button", "select", "textarea", "a", "label"):
                        continue
                    if score > best_score:
                        best_score = score
                        best_match = element
                except Exception:
                    continue

            if best_match and best_score >= threshold:
                selector = await self._compute_stable_selector(best_match)
                if self._is_bad_selector(selector):
                    return None
                confidence = min(best_score, 1.0)
                return {"selector": selector, "confidence": confidence}
            return None
        except Exception as e:
            print(f"Fuzzy text search error: {e}")
            return None
    
    async def _dom_proximity_search(self, text_hint: str) -> Optional[Dict[str, Any]]:
        """
        Perform DOM proximity search for elements near text containing text_hint.
        
        Args:
            text_hint: Text hint to search for
            
        Returns:
            Dictionary with "selector" and "confidence" or None
        """
        try:
            # Find nodes containing the text (case-insensitive)
            text_hint_lower = text_hint.lower()
            
            # Try to find text nodes or elements containing the hint
            all_elements = await self.page.query_selector_all("body *")
            
            for element in all_elements:
                try:
                    element_text = await element.inner_text()
                    if text_hint_lower in element_text.lower():
                        # Search for nearby clickable/interactive elements
                        nearby_element = await self._find_nearby_interactive_element(element)
                        if nearby_element:
                            selector = await self._compute_stable_selector(nearby_element)
                            # Lower confidence for proximity matches
                            confidence = 0.6 if text_hint_lower == element_text.lower() else 0.5
                            return {"selector": selector, "confidence": confidence}
                except Exception:
                    continue
            
            return None
        except Exception as e:
            print(f"DOM proximity search error: {e}")
            return None
    
    async def _find_nearby_interactive_element(self, element) -> Optional[Any]:
        """
        Find a nearby interactive element (input, button, etc.).
        
        Args:
            element: Playwright element handle
            
        Returns:
            Interactive element handle or None
        """
        try:
            # Check if element itself is interactive
            tag_name = await element.evaluate("el => el.tagName.toLowerCase()")
            if tag_name in ["input", "button", "select", "textarea", "a"]:
                return element
            
            # Check parent using XPath
            try:
                parent_xpath = await element.evaluate("""
                    el => {
                        const parent = el.parentElement;
                        if (!parent) return null;
                        let path = '';
                        let current = parent;
                        while (current && current !== document.body) {
                            const tag = current.tagName.toLowerCase();
                            const id = current.id ? '#' + current.id : '';
                            const classes = current.className ? '.' + current.className.split(' ')[0] : '';
                            path = tag + id + classes + (path ? ' > ' + path : '');
                            current = current.parentElement;
                        }
                        return path;
                    }
                """)
                if parent_xpath:
                    parent_elements = await self.page.query_selector_all(parent_xpath)
                    if parent_elements:
                        parent = parent_elements[0]
                        parent_tag = await parent.evaluate("el => el.tagName.toLowerCase()")
                        if parent_tag in ["input", "button", "select", "textarea", "a"]:
                            return parent
            except Exception:
                pass
            
            # Check children
            children = await element.query_selector_all("input, button, select, textarea, a")
            if children:
                return children[0]
            
            return None
        except Exception:
            return None
    
    async def _compute_stable_selector(self, element) -> str:
        """
        Compute a stable CSS selector for an element.
        
        Prefers ID-based selectors, otherwise builds a short CSS path.
        
        Args:
            element: Playwright element handle
            
        Returns:
            CSS selector string
        """
        try:
            # Prefer ID if present
            element_id = await element.get_attribute("id")
            if element_id:
                tag_name = await element.evaluate("el => el.tagName.toLowerCase()")
                return f"{tag_name}#{element_id}"
            
            # Use evaluate to build path in one call (more efficient)
            selector = await element.evaluate("""
                (el) => {
                    if (el.id) {
                        return el.tagName.toLowerCase() + '#' + el.id;
                    }
                    
                    const path = [];
                    let current = el;
                    
                    while (current && current !== document.body) {
                        const tag = current.tagName.toLowerCase();
                        const id = current.id ? '#' + current.id : '';
                        const classes = current.className && typeof current.className === 'string' 
                            ? '.' + current.className.split(' ')[0] 
                            : '';
                        
                        path.unshift(tag + id + classes);
                        current = current.parentElement;
                        
                        // Limit depth to avoid very long selectors
                        if (path.length > 5) break;
                    }
                    
                    return path.join(' > ') || el.tagName.toLowerCase();
                }
            """)
            
            return selector if selector else "body"
            
        except Exception as e:
            print(f"Error computing selector: {e}")
            # Fallback: try simple approach
            try:
                tag_name = await element.evaluate("el => el.tagName.toLowerCase()")
                element_id = await element.get_attribute("id")
                if element_id:
                    return f"{tag_name}#{element_id}"
                return tag_name
            except Exception:
                return "body"
    
    async def _create_audit(self, page_name: str, element_key: str, 
                           attempted_selectors: List[str], healed_with: str,
                           confidence: float, method: str, test_name: Optional[str] = None):
        """
        Create an audit record for a healing operation.
        
        Args:
            page_name: Name of the page
            element_key: Element key
            attempted_selectors: List of selectors that were tried
            healed_with: Selector that succeeded
            confidence: Confidence score
            method: Healing method used ("fuzzy_text" or "dom_proximity")
            test_name: Optional test name for context
        """
        self.audit_counter += 1
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        
        # Create audit record
        audit_data = {
            "test_name": test_name or "unknown",
            "page_name": page_name,
            "element_key": element_key,
            "attempted_selectors": attempted_selectors,
            "healed_with": healed_with,
            "confidence": confidence,
            "method": method,
            "timestamp": timestamp
        }
        
        # Save audit JSON
        audit_filename = f"{self.audit_counter:04d}_{page_name}_{element_key}_{timestamp}.json"
        audit_path = self.reporters_dir / audit_filename
        audit_data["audit_path"] = str(audit_path)
        
        try:
            with open(audit_path, 'w', encoding='utf-8') as f:
                json.dump(audit_data, f, indent=2)
            
            # Take screenshots
            screenshot_before = self.reporters_dir / f"{self.audit_counter:04d}_before.png"
            screenshot_after = self.reporters_dir / f"{self.audit_counter:04d}_after.png"
            
            await self.page.screenshot(path=str(screenshot_before))
            audit_data["screenshot_before"] = str(screenshot_before)
            audit_data["screenshot_after"] = str(screenshot_after)
            
            # Update audit JSON with screenshot paths
            with open(audit_path, 'w', encoding='utf-8') as f:
                json.dump(audit_data, f, indent=2)
            
            # Attach to Allure if available
            if ALLURE_AVAILABLE:
                try:
                    allure.attach.file(
                        str(audit_path),
                        name="auto_heal_audit",
                        attachment_type=allure.attachment_type.JSON
                    )
                    allure.attach.file(
                        str(screenshot_before),
                        name="auto_heal_before",
                        attachment_type=allure.attachment_type.PNG
                    )
                except Exception as e:
                    print(f"Allure attachment error: {e}")
            
            print(f"Auto-heal audit saved: {audit_path}")
            
        except Exception as e:
            print(f"Error creating audit: {e}")

    async def _dom_scan_for_locator_change(
        self,
        page_name: str,
        element_key: str,
        text_hint: str,
        attempted_selectors: List[str],
        threshold: float,
    ) -> Optional[Dict[str, Any]]:
        """Scan DOM for a better selector and update registry if applicable."""
        self._debug(f"Running DOM scan for '{text_hint}'")
        candidates = await self._scan_dom_candidates(text_hint)
        if not candidates:
            self._debug("DOM scan found no candidates")
            return None

        scored = []
        for candidate in candidates:
            selector = candidate["selector"]
            if self._is_bad_selector(selector):
                continue
            score = await self._score_candidate(
                selector, candidate.get("text_hint"), allow_without_text=candidate.get("allow_without_text", False)
            )
            if score > 0:
                scored.append((selector, score))

        if not scored:
            self._debug("DOM scan candidates not unique/valid")
            return None

        scored.sort(key=lambda item: item[1], reverse=True)
        best_selector, best_score = scored[0]
        audit_payload = {
            "page_name": page_name,
            "element_key": element_key,
            "text_hint": text_hint,
            "attempted_selectors": attempted_selectors,
            "candidates": dict(scored[:8]),
            "selected_selector": best_selector,
            "confidence": best_score,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._save_dom_scan_audit(audit_payload)

        if best_score >= threshold and self.apply_updates:
            self._update_registry(page_name, element_key, best_selector, best_score)
        else:
            self._debug("DOM scan candidate below threshold or apply disabled")

        return {"selector": best_selector, "confidence": best_score, "method": "dom_scan"}

    async def _scan_dom_candidates(self, text_hint: str) -> List[Dict[str, Any]]:
        """Collect candidate selectors for elements containing the text hint."""
        hint = text_hint.lower()
        candidates: List[Dict[str, Any]] = []

        try:
            elements = await self.page.query_selector_all(
                "body *"
            )
        except Exception:
            elements = []

        for element in elements[:800]:
            try:
                text_content = await element.text_content()
                aria_label = await element.get_attribute("aria-label")
                placeholder = await element.get_attribute("placeholder")
                name = await element.get_attribute("name")
                combined = " ".join(
                    value for value in [text_content, aria_label, placeholder, name] if value
                )
                if hint not in combined.lower():
                    continue

                tag = await element.evaluate("el => el.tagName.toLowerCase()")
                if tag in ("script", "style", "link", "noscript", "head", "meta"):
                    continue
                data_testid = await element.get_attribute("data-testid")
                element_id = await element.get_attribute("id")

                if data_testid:
                    candidates.append(
                        {"selector": f"{tag}[data-testid='{data_testid}']", "text_hint": text_hint}
                    )
                if element_id and not self._is_bad_selector(f"#{element_id}"):
                    candidates.append({"selector": f"#{element_id}", "text_hint": text_hint})
                    candidates.append(
                        {"selector": f"{tag}[id='{element_id}']", "text_hint": text_hint}
                    )
                if name:
                    candidates.append(
                        {"selector": f"{tag}[name='{name}']", "text_hint": text_hint}
                    )
                if aria_label:
                    candidates.append(
                        {"selector": f"{tag}[aria-label='{aria_label}']", "text_hint": text_hint}
                    )

                selector = await self._compute_stable_selector(element)
                if selector and not self._is_bad_selector(selector):
                    candidates.append({"selector": selector, "text_hint": text_hint})

                value_selector = await self._compute_value_selector_from_label(element)
                if value_selector:
                    candidates.append(
                        {
                            "selector": value_selector,
                            "text_hint": None,
                            "allow_without_text": True,
                        }
                    )
            except Exception:
                continue

        deduped = []
        seen = set()
        for selector in candidates:
            key = selector["selector"]
            if key not in seen:
                seen.add(key)
                deduped.append(selector)
        return deduped

    async def _score_candidate(
        self, selector: str, text_hint: Optional[str], allow_without_text: bool = False
    ) -> float:
        """Score selector candidate by uniqueness and text similarity."""
        try:
            count = await self.page.locator(selector).count()
        except Exception:
            return 0.0
        if count != 1:
            return 0.0

        try:
            element = self.page.locator(selector).first
            text = await element.inner_text()
        except Exception:
            text = ""

        if text_hint:
            sim = SequenceMatcher(None, text_hint.lower(), (text or "").lower()).ratio()
        elif allow_without_text:
            sim = 0.3
        else:
            sim = 0.0
        bonus = 0.0
        if "[name=" in selector or "[placeholder=" in selector:
            bonus = 0.3
        elif "data-testid" in selector:
            bonus = 0.25
        elif "[aria-label=" in selector:
            bonus = 0.2
        elif selector.startswith("#") or "[id=" in selector:
            bonus = 0.1
        score = 0.5 + (sim * 0.4) + bonus
        return min(score, 1.0)

    async def _compute_value_selector_from_label(self, label_element) -> Optional[str]:
        """Attempt to compute selector for a value element near a label element."""
        try:
            value_handle = await label_element.evaluate_handle(
                """el => {
                    const hasText = (node) => {
                      if (!node) return false;
                      const text = (node.textContent || '').trim();
                      return text.length > 0;
                    };
                    const parent = el.parentElement;
                    if (!parent) return null;

                    // Check next siblings
                    let sibling = el.nextElementSibling;
                    while (sibling) {
                      if (hasText(sibling)) return sibling;
                      sibling = sibling.nextElementSibling;
                    }

                    // Check parent's next sibling
                    let parentSibling = parent.nextElementSibling;
                    while (parentSibling) {
                      if (hasText(parentSibling)) return parentSibling;
                      parentSibling = parentSibling.nextElementSibling;
                    }

                    // Check within parent for value-like nodes
                    const candidates = parent.querySelectorAll('span, div, dd, td');
                    for (const node of candidates) {
                      if (node !== el && hasText(node)) return node;
                    }
                    return null;
                }"""
            )
            if not value_handle:
                return None
            value_element = value_handle.as_element()
            if not value_element:
                return None
            selector = await self._compute_stable_selector(value_element)
            return selector
        except Exception:
            return None

    def _save_dom_scan_audit(self, payload: Dict[str, Any]) -> None:
        try:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            audit_path = self.reporters_dir / f"dom_scan_{timestamp}_{self.audit_counter:04d}.json"
            payload.setdefault("scan_mode", "text_content")
            with open(audit_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, sort_keys=True)
            self._debug(f"DOM scan audit saved: {audit_path}")
        except Exception as e:
            self._debug(f"Failed to save DOM scan audit: {e}")

    @staticmethod
    def _is_valid_registry_page_name(page_name: str) -> bool:
        """Reject generic / proxy-derived page names that pollute the registry.

        Real page objects are *Page subclasses (LoginPage, RatingAssessmentPage, ...).
        Anything else (PlaywrightPage, Page, Locator, _foo, page-name with whitespace,
        empty, or starting with a digit) means the heal call site did not have a
        proper page object context and we should refuse to persist it.
        """
        if not isinstance(page_name, str):
            return False
        s = page_name.strip()
        if not s:
            return False
        denylist = {"PlaywrightPage", "Page", "Locator", "Frame", "ElementHandle", "BasePage"}
        if s in denylist:
            return False
        if not s[0].isalpha():
            return False
        if " " in s or "/" in s or "\\" in s:
            return False
        if not s.endswith("Page"):
            return False
        return True

    def _update_registry(
        self,
        page_name: str,
        element_key: str,
        selector: str,
        confidence: float,
        *,
        page_object_confidence: Optional[float] = None,
    ) -> None:
        if not self._is_valid_registry_page_name(page_name):
            print(
                f"[AUTOHEAL][REGISTRY] Refusing to persist heal under invalid page_name "
                f"{page_name!r} (element_key={element_key!r}). The call site lacks a real "
                f"page object context — fix the caller to pass the *Page class name."
            )
            return
        try:
            self.selectors_registry.setdefault(page_name, {})
            page_bucket = self.selectors_registry[page_name]
            if element_key not in page_bucket:
                page_bucket[element_key] = {
                    "primary": "",
                    "fallbacks": [],
                    "metadata": {},
                    "history": [],
                }
            entry = page_bucket[element_key]
            raw_prev = entry.get("primary")
            previous_primary = (raw_prev or "").strip() or None

            now_iso = datetime.now(timezone.utc).isoformat()
            if previous_primary and previous_primary != selector:
                entry["previous_primary"] = previous_primary
                entry.setdefault("history", []).append(
                    {"selector": previous_primary, "timestamp": now_iso, "updated_by": "auto_heal"}
                )

            entry["primary"] = selector
            entry.setdefault("fallbacks", [])
            metadata = entry.setdefault("metadata", {})
            metadata["last_auto_updated_by"] = "auto_heal"
            metadata["last_auto_updated_on"] = now_iso
            metadata["last_auto_confidence"] = confidence
            metadata["last_auto_applied"] = True

            if self.selectors_path.exists():
                self.backup_dir.mkdir(parents=True, exist_ok=True)
                backup_name = f"{self.selectors_path.stem}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
                shutil.copy2(self.selectors_path, self.backup_dir / backup_name)

            with open(self.selectors_path, "w", encoding="utf-8") as handle:
                json.dump(self.selectors_registry, handle, indent=2, sort_keys=True)
            self._debug(f"Selector registry updated for {page_name}.{element_key}")

            try:
                from autoheal.auto_heal_page_object_patch import patch_page_object_locator

                po_conf = (
                    page_object_confidence
                    if page_object_confidence is not None
                    else confidence
                )
                patch_page_object_locator(
                    page_name,
                    element_key,
                    selector,
                    previous_primary,
                    po_conf,
                    pages_dir=self.pages_dir,
                )
            except Exception as pe:
                self._debug(f"Page object auto-patch skipped: {pe}")

            # Defer page-object rewrite until scenario passes (ignores confidence threshold).
            if os.getenv("AUTO_HEAL_PATCH_PAGE_OBJECTS_ON_SCENARIO_PASS", "true").lower() in (
                "1",
                "true",
                "yes",
            ):
                self._page_object_scenario_patch_queue[(page_name, element_key)] = (
                    selector,
                    previous_primary,
                )
        except Exception as e:
            self._debug(f"Failed to update selector registry: {e}")

    def apply_page_object_patches_after_passed_scenario(self) -> int:
        """
        Apply queued page-object patches without requiring confidence above
        ``AUTO_HEAL_PAGE_OBJECT_THRESHOLD``. Intended when the Behave scenario passed so any
        locator that was healed and persisted to the registry is promoted to ``*_page.py``.

        Returns how many ``patch_page_object_locator`` calls returned True (a file was written).
        """
        if os.getenv("AUTO_HEAL_PATCH_PAGE_OBJECTS_ON_SCENARIO_PASS", "true").lower() not in (
            "1",
            "true",
            "yes",
        ):
            return 0
        if os.getenv("AUTO_HEAL_PATCH_PAGE_OBJECTS", "true").lower() not in (
            "1",
            "true",
            "yes",
        ):
            self._page_object_scenario_patch_queue.clear()
            return 0
        try:
            from autoheal.auto_heal_page_object_patch import patch_page_object_locator
        except Exception as e:
            self._debug(f"Page object scenario-pass patch import failed: {e}")
            return 0

        applied = 0
        items = list(self._page_object_scenario_patch_queue.items())
        self._page_object_scenario_patch_queue.clear()
        for (page_name, element_key), (selector, previous_primary) in items:
            try:
                if patch_page_object_locator(
                    page_name,
                    element_key,
                    selector,
                    previous_primary,
                    1.0,
                    pages_dir=self.pages_dir,
                    bypass_confidence_threshold=True,
                ):
                    applied += 1
            except Exception as e:
                self._debug(f"Scenario-pass page patch failed for {page_name}.{element_key}: {e}")
        return applied
    
    async def verify_fill(self, selector: str, expected_value: str, timeout_ms: int = 2000) -> bool:
        """
        Verify that a fill operation was successful by reading back the value.
        
        Args:
            selector: Selector for the input element
            expected_value: Expected value in the input
            timeout_ms: Timeout in milliseconds
            
        Returns:
            True if value matches, False otherwise
        """
        try:
            if selector.startswith("//") or selector.startswith("(//"):
                locator = self.page.locator(f"xpath={selector}")
            else:
                locator = self.page.locator(selector)
            
            await locator.wait_for(state="visible", timeout=timeout_ms)
            actual_value = await locator.input_value()
            return actual_value == expected_value
        except Exception:
            return False
    
    async def verify_click(self, verify_selector: Optional[str] = None, timeout_ms: int = 5000) -> bool:
        """
        Verify that a click operation had the intended effect.
        
        Args:
            verify_selector: Optional selector for an element that should appear after click
            timeout_ms: Timeout in milliseconds
            
        Returns:
            True if verification passes, False otherwise
        """
        if verify_selector is None:
            # No verification selector provided, assume success
            return True
        
        try:
            if verify_selector.startswith("//") or verify_selector.startswith("(//"):
                locator = self.page.locator(f"xpath={verify_selector}")
            else:
                locator = self.page.locator(verify_selector)
            
            await locator.wait_for(state="visible", timeout=timeout_ms)
            return True
        except PlaywrightTimeoutError:
            return False
        except Exception:
            return False
