"""Inject AutoHealAsync setup into ``pages/base_page.py`` when a ``BasePage`` pattern exists."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional, Tuple

MARKER_START = "# BEGIN_AUTOHEAL_WIRE (base_page healer)"
MARKER_END = "# END_AUTOHEAL_WIRE (base_page healer)"

HEALER_BLOCK = f"""
        {MARKER_START}
        try:
            from autoheal.auto_heal_async import AutoHealAsync, HealerConfig
            _autoheal_available = True
        except Exception:
            _autoheal_available = False
        _autoheal_enabled = __import__("os").getenv("AUTO_HEAL_ENABLED", "true").lower() == "true"
        _page_for_healer = getattr(page, "_page", page)
        _healer_cfg = (
            HealerConfig.from_env(reporters_dir="reports/heal_audit")
            if _autoheal_available
            else None
        )
        self.healer = (
            AutoHealAsync(_page_for_healer, config=_healer_cfg)
            if _autoheal_available and _autoheal_enabled and _healer_cfg is not None
            else None
        )
        {MARKER_END}
"""


def _find_basepage_init_body_start(src: str) -> Optional[int]:
    """Return index after the first ``self.page = page`` (or similar) inside ``class BasePage``."""
    class_m = re.search(r"^class\s+BasePage\b.*?:\s*$", src, re.MULTILINE)
    if not class_m:
        return None
    after = src[class_m.end() :]
    init_m = re.search(
        r"^\s{4}def\s+__init__\s*\(\s*self\s*,\s*page\b",
        after,
        re.MULTILINE,
    )
    if not init_m:
        return None
    body = after[init_m.end() :]
    # find first assignment to self.page in __init__ (next lines)
    assign_m = re.search(r"^\s{8}self\.page\s*=\s*page\s*$", body, re.MULTILINE)
    if not assign_m:
        assign_m = re.search(r"^\s{8}self\.page\s*=\s*page\s*#", body, re.MULTILINE)
    if not assign_m:
        return None
    line_end = body.find("\n", assign_m.end())
    if line_end == -1:
        line_end = assign_m.end()
    abs_pos = class_m.end() + init_m.end() + line_end + 1
    return abs_pos


def wire_base_page(pages_dir: Path, *, dry_run: bool = False) -> Tuple[bool, str]:
    """
    Insert healer block into ``base_page.py`` after ``self.page = page`` if ``BasePage`` exists.

    Returns (changed, message).
    """
    path = pages_dir / "base_page.py"
    if not path.is_file():
        return False, f"skip base_page: not found {path}"
    text = path.read_text(encoding="utf-8")
    if MARKER_START in text:
        return False, "skip base_page: already contains AUTOHEAL_WIRE markers"
    if "self.healer" in text and "AutoHealAsync" in text:
        return False, "skip base_page: healer already present"
    insert_at = _find_basepage_init_body_start(text)
    if insert_at is None:
        return (
            False,
            "skip base_page: no `class BasePage` + `def __init__(self, page` + `self.page = page` pattern",
        )
    new_text = text[:insert_at] + HEALER_BLOCK + text[insert_at:]
    if dry_run:
        return True, f"dry-run: would patch {path}"
    path.write_text(new_text, encoding="utf-8")
    return True, f"patched {path}"
