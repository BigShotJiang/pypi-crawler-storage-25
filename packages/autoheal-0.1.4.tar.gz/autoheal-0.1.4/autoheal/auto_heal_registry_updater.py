"""
Auto-heal registry updater.

Reads auto-heal audit files and updates pages/selectors.json so future runs
use healed selectors as fallbacks.
"""

import json
from pathlib import Path
from typing import Dict, Any, List


def _load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def _save_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=True)


def update_selectors_from_audit(
    audit_dir: str = "reports/heal_audit",
    registry_path: str = "pages/selectors.json",
    processed_path: str = "reports/heal_audit/processed.json",
    max_fallbacks: int = 10,
    promote_threshold: float = 0.9,
) -> bool:
    """Update selectors.json with healed selectors from audit files."""
    audit_path = Path(audit_dir)
    registry_file = Path(registry_path)
    processed_file = Path(processed_path)

    if not audit_path.exists():
        print(f"[AUTOHEAL] No audit directory found: {audit_path}")
        return False

    registry = _load_json(registry_file)
    processed = _load_json(processed_file).get("processed_files", [])
    processed_set = set(processed)

    updated = False
    audit_files = sorted(audit_path.glob("*.json"))

    for audit_file in audit_files:
        if audit_file.name in processed_set:
            continue

        audit_data = _load_json(audit_file)
        page_name = audit_data.get("page_name")
        element_key = audit_data.get("element_key")
        healed_with = audit_data.get("healed_with")
        confidence = float(audit_data.get("confidence", 0))

        if not page_name or not element_key or not healed_with:
            processed.append(audit_file.name)
            continue

        page_registry = registry.setdefault(page_name, {})
        element_registry = page_registry.setdefault(
            element_key,
            {"primary": healed_with, "fallbacks": [], "metadata": {"created_by": "auto_heal"}}
        )

        primary = element_registry.get("primary")
        fallbacks: List[str] = element_registry.get("fallbacks", [])

        if confidence >= promote_threshold and healed_with != primary:
            # Promote healed selector to primary and keep old primary in fallbacks
            if primary and primary not in fallbacks:
                fallbacks.append(primary)
            element_registry["primary"] = healed_with
            updated = True
        elif healed_with != primary and healed_with not in fallbacks:
            fallbacks.append(healed_with)
            updated = True

        element_registry["fallbacks"] = fallbacks[-max_fallbacks:]

        processed.append(audit_file.name)

    if updated:
        _save_json(registry_file, registry)
        print(f"[AUTOHEAL] Updated selector registry: {registry_file}")

    _save_json(processed_file, {"processed_files": processed})
    return updated


if __name__ == "__main__":
    update_selectors_from_audit()
