"""Console entrypoint for the auto-heal agentic helper."""

from __future__ import annotations

import argparse
import asyncio
import compileall
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from playwright.async_api import async_playwright

from autoheal.auto_heal_project_index import build_project_index


def read_file(path: str, max_chars: int = 8000) -> str:
    text = Path(path).read_text(encoding="utf-8")
    return text[:max_chars]


def search_repo(root: str, regex: str, max_hits: int = 50) -> List[Dict[str, Any]]:
    compiled = re.compile(regex)
    hits: List[Dict[str, Any]] = []
    for py in Path(root).rglob("*.py"):
        try:
            lines = py.read_text(encoding="utf-8").splitlines()
        except Exception:
            continue
        for idx, line in enumerate(lines, start=1):
            if compiled.search(line):
                hits.append({"path": str(py), "line": idx, "content": line.strip()[:300]})
                if len(hits) >= max_hits:
                    return hits
    return hits


def propose_registry_update(
    *,
    page_name: str,
    element_key: str,
    selector: str,
    confidence: float,
    reason: str,
) -> Dict[str, Any]:
    selector = (selector or "").strip()
    if not selector:
        raise ValueError("selector must be non-empty")
    if confidence < 0.0 or confidence > 1.0:
        raise ValueError("confidence must be between 0 and 1")
    return {
        "page_name": page_name.strip(),
        "element_key": element_key.strip(),
        "selector": selector,
        "confidence": confidence,
        "reason": (reason or "")[:500],
    }


def apply_registry_update(selectors_path: str, proposal: Dict[str, Any]) -> None:
    path = Path(selectors_path)
    payload = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    page_name = proposal["page_name"]
    element_key = proposal["element_key"]
    payload.setdefault(page_name, {})
    payload[page_name].setdefault(element_key, {"primary": "", "fallbacks": [], "metadata": {}, "history": []})
    entry = payload[page_name][element_key]
    previous = entry.get("primary")
    if previous and previous != proposal["selector"]:
        entry.setdefault("history", []).append({"selector": previous, "updated_by": "agent_cli"})
    entry["primary"] = proposal["selector"]
    meta = entry.setdefault("metadata", {})
    meta["last_auto_updated_by"] = "agent_cli"
    meta["last_auto_confidence"] = proposal["confidence"]
    meta["last_auto_reason"] = proposal["reason"]
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


async def run_playwright_probe(url: str, selector: str, timeout_ms: int = 5000) -> Dict[str, Any]:
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        ctx = await browser.new_context(ignore_https_errors=True)
        page = await ctx.new_page()
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            loc = page.locator(selector)
            count = await loc.count()
            visible = False
            if count > 0:
                try:
                    visible = await loc.first.is_visible(timeout=timeout_ms)
                except Exception:
                    visible = False
            return {"count": count, "visible": visible}
        finally:
            await browser.close()


def run_sanity_checks(root: str) -> bool:
    return compileall.compile_dir(root, force=False, quiet=1)


def tool_manifest() -> Dict[str, Any]:
    return {
        "tools": [
            "read_file(path,max_chars)",
            "search_repo(root,regex,max_hits)",
            "propose_registry_update(page_name,element_key,selector,confidence,reason)",
            "apply_registry_update(selectors_path,proposal)",
            "run_playwright_probe(url,selector,timeout_ms)",
            "run_sanity_checks(root)",
        ]
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Agentic helper for auto-heal registry/page-object workflows.")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--selectors-path", default="pages/selectors.json")
    parser.add_argument("--pages-dir", default="pages")
    parser.add_argument("--page-name")
    parser.add_argument("--element-key")
    parser.add_argument("--selector")
    parser.add_argument("--confidence", type=float, default=0.8)
    parser.add_argument("--reason", default="agentic proposal")
    parser.add_argument("--probe-url", default="")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    index = build_project_index(Path(args.selectors_path), Path(args.pages_dir))
    out: Dict[str, Any] = {
        "manifest": tool_manifest(),
        "project_index_summary": {
            "known_pages": len(index.get("known_page_names", [])),
            "known_keys": len(index.get("known_element_keys", [])),
        },
        "proposal": None,
        "probe": None,
        "applied": False,
        "sanity": None,
    }

    if args.page_name and args.element_key and args.selector:
        proposal = propose_registry_update(
            page_name=args.page_name,
            element_key=args.element_key,
            selector=args.selector,
            confidence=args.confidence,
            reason=args.reason,
        )
        out["proposal"] = proposal
        if args.probe_url:
            out["probe"] = asyncio.run(run_playwright_probe(args.probe_url, args.selector))
        if args.apply:
            apply_registry_update(args.selectors_path, proposal)
            out["sanity"] = run_sanity_checks(args.workspace)
            out["applied"] = True

    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
