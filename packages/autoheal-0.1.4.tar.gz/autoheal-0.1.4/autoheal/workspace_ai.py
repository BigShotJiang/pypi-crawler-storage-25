"""Collect repository context and merge AI-proposed ``selectors.json`` updates."""

from __future__ import annotations

import ast
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from autoheal.auto_heal_ai_agent import suggest_workspace_registry_updates
from autoheal.auto_heal_project_index import build_project_index


def _truncate(text: str, limit: int) -> str:
    text = text or ""
    if len(text) <= limit:
        return text
    return text[: limit - 20] + "\n... [truncated]"


def _parse_page_file(py_path: Path) -> List[Dict[str, Any]]:
    """Extract class names and UPPER_SNAKE constants per class."""
    try:
        tree = ast.parse(py_path.read_text(encoding="utf-8"), filename=str(py_path))
    except Exception:
        return []
    out: List[Dict[str, Any]] = []
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        constants: List[str] = []
        for sub in node.body:
            if not isinstance(sub, ast.Assign) or not sub.targets:
                continue
            if not isinstance(sub.targets[0], ast.Name):
                continue
            name = sub.targets[0].id
            if name.isupper():
                constants.append(name)
        out.append({"name": node.name, "constants": sorted(set(constants))})
    return out


def collect_workspace_snapshot(
    root: Path,
    *,
    features_dir: str = "features",
    pages_dir: str = "pages",
    selectors_path: str = "pages/selectors.json",
    max_feature_chars: int = 12000,
    max_page_files: int = 40,
) -> Dict[str, Any]:
    """Build a JSON-serializable snapshot for :func:`suggest_workspace_registry_updates`."""
    root = root.resolve()
    pages_path = root / pages_dir
    sel_path = root / selectors_path
    feat_root = root / features_dir

    feature_files: List[Dict[str, str]] = []
    total = 0
    feature_iter: List[Path] = []
    if feat_root.is_dir():
        feature_iter = sorted(feat_root.rglob("*.feature"))
    for feat in feature_iter:
        if not feat.is_file():
            continue
        try:
            raw = feat.read_text(encoding="utf-8")
        except Exception:
            continue
        chunk = _truncate(raw, min(4000, max_feature_chars - total))
        if not chunk.strip():
            continue
        feature_files.append({"path": str(feat.relative_to(root)).replace("\\", "/"), "content": chunk})
        total += len(chunk)
        if total >= max_feature_chars:
            break

    page_objects: List[Dict[str, Any]] = []
    if pages_path.is_dir():
        for i, py_path in enumerate(sorted(pages_path.glob("*.py"))):
            if i >= max_page_files:
                break
            if py_path.name == "__init__.py":
                continue
            classes = _parse_page_file(py_path)
            if not classes:
                continue
            page_objects.append(
                {
                    "path": str(py_path.relative_to(root)).replace("\\", "/"),
                    "classes": classes,
                }
            )

    registry: Dict[str, Any] = {}
    if sel_path.is_file():
        try:
            registry = json.loads(sel_path.read_text(encoding="utf-8"))
            if not isinstance(registry, dict):
                registry = {}
        except Exception:
            registry = {}

    project_index = build_project_index(sel_path, pages_path)

    return {
        "schema_version": 1,
        "workspace_root": str(root),
        "feature_files": feature_files,
        "page_objects": page_objects,
        "selectors_registry": registry,
        "project_index": project_index,
    }


def merge_selectors_delta(base: Dict[str, Any], delta: Dict[str, Any]) -> Dict[str, Any]:
    """Deep-merge page and element entries from ``delta`` into ``base`` (copy)."""
    out: Dict[str, Any] = dict(base) if isinstance(base, dict) else {}
    for page_name, elements in (delta or {}).items():
        if not isinstance(elements, dict):
            continue
        cur = out.get(page_name)
        if not isinstance(cur, dict):
            cur = {}
        for elem_key, entry in elements.items():
            if isinstance(entry, dict):
                cur[elem_key] = entry
        out[page_name] = cur
    return out


def run_workspace_ai(
    root: Path,
    *,
    dry_run: bool = True,
    selectors_path: str = "pages/selectors.json",
    backup_dir: str = "pages/backups",
) -> Tuple[Optional[Dict[str, Any]], str]:
    """
    Collect snapshot, call LLM, optionally write merged ``selectors.json``.

    Returns (proposal dict or None, status message).
    """
    root = root.resolve()
    snap = collect_workspace_snapshot(root, selectors_path=selectors_path)
    proposal = suggest_workspace_registry_updates(snap)
    if not proposal:
        return None, "no proposal (AI disabled or request failed)"
    delta = proposal.get("selectors") or {}
    if not isinstance(delta, dict) or not delta:
        return proposal, "empty selectors delta from model"

    sel_file = root / selectors_path
    base: Dict[str, Any] = {}
    if sel_file.is_file():
        try:
            base = json.loads(sel_file.read_text(encoding="utf-8"))
            if not isinstance(base, dict):
                base = {}
        except Exception:
            base = {}

    merged = merge_selectors_delta(base, delta)
    if dry_run:
        return proposal, f"dry-run: would write {len(merged)} page keys to {sel_file}"

    sel_file.parent.mkdir(parents=True, exist_ok=True)
    backup_root = root / backup_dir
    backup_root.mkdir(parents=True, exist_ok=True)
    if sel_file.is_file():
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        bak = backup_root / f"selectors.json.bak.{ts}"
        shutil.copy2(sel_file, bak)

    sel_file.write_text(json.dumps(merged, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return proposal, f"wrote {sel_file} (merged {len(delta)} page keys from model)"
