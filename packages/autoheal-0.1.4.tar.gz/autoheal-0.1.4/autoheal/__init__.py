"""Public package API for reusable Playwright auto-heal components."""

from autoheal.auto_heal import AutoHeal
from autoheal.auto_heal_integration import (
    build_step_context,
    clear_step_context,
    publish_step_context,
)
from autoheal.auto_heal_project_index import build_project_index
from autoheal.bootstrap import bootstrap_workspace
from autoheal.core import AutoHealAsync, HealerConfig
from autoheal.workspace_ai import collect_workspace_snapshot, run_workspace_ai

__all__ = [
    "AutoHeal",
    "AutoHealAsync",
    "HealerConfig",
    "build_step_context",
    "publish_step_context",
    "clear_step_context",
    "build_project_index",
    "bootstrap_workspace",
    "collect_workspace_snapshot",
    "run_workspace_ai",
]
