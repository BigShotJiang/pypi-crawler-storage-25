"""
Auto-Healing Engine for Playwright Test Automation.

This module provides an auto-healing system that detects selector failures
and attempts to recover using fallback selectors, fuzzy text matching, and
DOM proximity heuristics.
"""

import json
import os
import time
from pathlib import Path
from typing import Optional, Dict, List, Any
from difflib import SequenceMatcher
from playwright.sync_api import Page, TimeoutError as PlaywrightTimeoutError

try:
    import allure
    ALLURE_AVAILABLE = True
except ImportError:
    ALLURE_AVAILABLE = False


class AutoHeal:
    """
    Auto-healing engine for Playwright page interactions.
    
    Provides intelligent selector recovery when primary selectors fail,
    with audit logging and verification capabilities.
    """
    
    def __init__(self, page: Page, reporters_dir: str = "reports/heal_audit", 
                 confidence_threshold: float = 0.7):
        """
        Initialize the AutoHeal engine.
        
        Args:
            page: Playwright sync API Page instance
            reporters_dir: Directory for audit reports and screenshots
            confidence_threshold: Minimum confidence score for fuzzy matching (0-1)
        """
        self.page = page
        self.reporters_dir = Path(reporters_dir)
        self.confidence_threshold = confidence_threshold
        self.selectors_registry = self._load_selectors_registry()
        self.audit_counter = 0
        
        # Ensure audit directory exists
        self.reporters_dir.mkdir(parents=True, exist_ok=True)
    
    def _load_selectors_registry(self) -> Dict[str, Any]:
        """
        Load selector registry from pages/selectors.json.
        
        Tries multiple possible locations to find the registry file.
        
        Returns:
            Dictionary containing selector registry data
        """
        # Try multiple possible paths
        possible_paths = [
            Path("pages/selectors.json"),  # Relative to current working directory
            Path(__file__).parent.parent / "pages" / "selectors.json",  # Relative to this file
        ]
        
        for registry_path in possible_paths:
            if registry_path.exists():
                try:
                    with open(registry_path, 'r', encoding='utf-8') as f:
                        return json.load(f)
                except (json.JSONDecodeError, IOError) as e:
                    print(f"Error loading selectors registry from {registry_path}: {e}")
                    continue
        
        # If none found, return empty dict
        print(f"Warning: Selectors registry not found. Tried: {[str(p) for p in possible_paths]}")
        return {}
    
    def locate(self, page_name: str, element_key: str, 
               timeout_ms: int = 2000, 
               confidence_threshold: Optional[float] = None) -> Optional[Dict[str, Any]]:
        """
        Locate an element using primary, fallback, fuzzy, or proximity heuristics.
        
        Args:
            page_name: Name of the page (e.g., "LoginPage")
            element_key: Key for the element in the registry (e.g., "username_input")
            timeout_ms: Timeout in milliseconds for selector attempts
            confidence_threshold: Override default confidence threshold
            
        Returns:
            Dictionary with "selector" and "confidence" keys, or None if not found
        """
        if confidence_threshold is None:
            confidence_threshold = self.confidence_threshold
        
        # Get selector metadata from registry
        element_config = self._get_element_config(page_name, element_key)
        if not element_config:
            print(f"No configuration found for {page_name}.{element_key}")
            return None
        
        primary = element_config.get("primary", "")
        fallbacks = element_config.get("fallbacks", [])
        metadata = element_config.get("metadata", {})
        text_hint = metadata.get("text_hint", "")
        
        attempted_selectors = []
        
        # Step 1: Try primary selector
        if primary:
            attempted_selectors.append(primary)
            result = self._try_selector(primary, timeout_ms)
            if result:
                return {"selector": primary, "confidence": 1.0}
        
        # Step 2: Try fallback selectors
        for fallback in fallbacks:
            attempted_selectors.append(fallback)
            result = self._try_selector(fallback, timeout_ms)
            if result:
                return {"selector": fallback, "confidence": 1.0}
        
        # Step 3: Fuzzy text search if text_hint exists
        if text_hint:
            fuzzy_result = self._fuzzy_text_search(text_hint, confidence_threshold)
            if fuzzy_result:
                selector = fuzzy_result["selector"]
                confidence = fuzzy_result["confidence"]
                attempted_selectors.append(f"fuzzy:{selector}")
                
                # Create audit record for fuzzy match
                self._create_audit(
                    page_name=page_name,
                    element_key=element_key,
                    attempted_selectors=attempted_selectors,
                    healed_with=selector,
                    confidence=confidence,
                    method="fuzzy_text"
                )
                
                return {"selector": selector, "confidence": confidence}
        
        # Step 4: DOM proximity heuristic
        if text_hint:
            proximity_result = self._dom_proximity_search(text_hint)
            if proximity_result:
                selector = proximity_result["selector"]
                confidence = proximity_result["confidence"]
                attempted_selectors.append(f"proximity:{selector}")
                
                # Create audit record for proximity match
                self._create_audit(
                    page_name=page_name,
                    element_key=element_key,
                    attempted_selectors=attempted_selectors,
                    healed_with=selector,
                    confidence=confidence,
                    method="dom_proximity"
                )
                
                return {"selector": selector, "confidence": confidence}
        
        # No selector found
        return None
    
    def _get_element_config(self, page_name: str, element_key: str) -> Optional[Dict[str, Any]]:
        """Get element configuration from registry."""
        page_config = self.selectors_registry.get(page_name, {})
        return page_config.get(element_key)
    
    def _try_selector(self, selector: str, timeout_ms: int) -> bool:
        """
        Try to locate an element using the given selector.
        
        Args:
            selector: CSS or XPath selector
            timeout_ms: Timeout in milliseconds
            
        Returns:
            True if element is found and visible, False otherwise
        """
        try:
            # Handle XPath selectors
            if selector.startswith("//") or selector.startswith("(//"):
                locator = self.page.locator(f"xpath={selector}")
            else:
                locator = self.page.locator(selector)
            
            locator.wait_for(state="visible", timeout=timeout_ms)
            return True
        except PlaywrightTimeoutError:
            return False
        except Exception:
            return False
    
    def _fuzzy_text_search(self, text_hint: str, threshold: float) -> Optional[Dict[str, Any]]:
        """
        Perform fuzzy text search to find elements matching text_hint.
        
        Args:
            text_hint: Text to search for
            threshold: Minimum similarity score (0-1)
            
        Returns:
            Dictionary with "selector" and "confidence" or None
        """
        try:
            # Get all elements in body
            all_elements = self.page.query_selector_all("body *")
            best_match = None
            best_score = 0.0
            
            for element in all_elements:
                try:
                    # Get text content safely
                    text_content = element.inner_text()
                    if not text_content:
                        continue
                    
                    # Compute similarity
                    similarity = SequenceMatcher(None, text_hint.lower(), 
                                                text_content.lower()).ratio()
                    
                    if similarity > best_score and similarity >= threshold:
                        best_score = similarity
                        best_match = element
                except Exception:
                    continue
            
            if best_match and best_score >= threshold:
                selector = self._compute_stable_selector(best_match)
                return {"selector": selector, "confidence": best_score}
            
            return None
        except Exception as e:
            print(f"Fuzzy text search error: {e}")
            return None
    
    def _dom_proximity_search(self, text_hint: str) -> Optional[Dict[str, Any]]:
        """
        Perform DOM proximity search for elements near text containing text_hint.
        
        Args:
            text_hint: Text hint to search for
            
        Returns:
            Dictionary with "selector" and "confidence" or None
        """
        try:
            # Find nodes containing the text (case-insensitive)
            text_hint_lower = text_hint.lower()
            
            # Try to find text nodes or elements containing the hint
            all_elements = self.page.query_selector_all("body *")
            
            for element in all_elements:
                try:
                    element_text = element.inner_text()
                    if text_hint_lower in element_text.lower():
                        # Search for nearby clickable/interactive elements
                        nearby_element = self._find_nearby_interactive_element(element)
                        if nearby_element:
                            selector = self._compute_stable_selector(nearby_element)
                            # Lower confidence for proximity matches
                            confidence = 0.6 if text_hint_lower == element_text.lower() else 0.5
                            return {"selector": selector, "confidence": confidence}
                except Exception:
                    continue
            
            return None
        except Exception as e:
            print(f"DOM proximity search error: {e}")
            return None
    
    def _find_nearby_interactive_element(self, element) -> Optional[Any]:
        """
        Find a nearby interactive element (input, button, etc.).
        
        Args:
            element: Playwright element handle
            
        Returns:
            Interactive element handle or None
        """
        try:
            # Check if element itself is interactive
            tag_name = element.evaluate("el => el.tagName.toLowerCase()")
            if tag_name in ["input", "button", "select", "textarea", "a"]:
                return element
            
            # Check parent using XPath
            try:
                parent_xpath = element.evaluate("""
                    el => {
                        const parent = el.parentElement;
                        if (!parent) return null;
                        let path = '';
                        let current = parent;
                        while (current && current !== document.body) {
                            const tag = current.tagName.toLowerCase();
                            const id = current.id ? '#' + current.id : '';
                            const classes = current.className ? '.' + current.className.split(' ')[0] : '';
                            path = tag + id + classes + (path ? ' > ' + path : '');
                            current = current.parentElement;
                        }
                        return path;
                    }
                """)
                if parent_xpath:
                    parent_elements = self.page.query_selector_all(parent_xpath)
                    if parent_elements:
                        parent = parent_elements[0]
                        parent_tag = parent.evaluate("el => el.tagName.toLowerCase()")
                        if parent_tag in ["input", "button", "select", "textarea", "a"]:
                            return parent
            except Exception:
                pass
            
            # Check children
            children = element.query_selector_all("input, button, select, textarea, a")
            if children:
                return children[0]
            
            return None
        except Exception:
            return None
    
    def _compute_stable_selector(self, element) -> str:
        """
        Compute a stable CSS selector for an element.
        
        Prefers ID-based selectors, otherwise builds a short CSS path.
        
        Args:
            element: Playwright element handle
            
        Returns:
            CSS selector string
        """
        try:
            # Prefer ID if present
            element_id = element.get_attribute("id")
            if element_id:
                tag_name = element.evaluate("el => el.tagName.toLowerCase()")
                return f"{tag_name}#{element_id}"
            
            # Use evaluate to build path in one call (more efficient)
            selector = element.evaluate("""
                (el) => {
                    if (el.id) {
                        return el.tagName.toLowerCase() + '#' + el.id;
                    }
                    
                    const path = [];
                    let current = el;
                    
                    while (current && current !== document.body) {
                        const tag = current.tagName.toLowerCase();
                        const id = current.id ? '#' + current.id : '';
                        const classes = current.className && typeof current.className === 'string' 
                            ? '.' + current.className.split(' ')[0] 
                            : '';
                        
                        path.unshift(tag + id + classes);
                        current = current.parentElement;
                        
                        // Limit depth to avoid very long selectors
                        if (path.length > 5) break;
                    }
                    
                    return path.join(' > ') || el.tagName.toLowerCase();
                }
            """)
            
            return selector if selector else "body"
            
        except Exception as e:
            print(f"Error computing selector: {e}")
            # Fallback: try simple approach
            try:
                tag_name = element.evaluate("el => el.tagName.toLowerCase()")
                element_id = element.get_attribute("id")
                if element_id:
                    return f"{tag_name}#{element_id}"
                return tag_name
            except Exception:
                return "body"
    
    def _create_audit(self, page_name: str, element_key: str, 
                     attempted_selectors: List[str], healed_with: str,
                     confidence: float, method: str, test_name: Optional[str] = None):
        """
        Create an audit record for a healing operation.
        
        Args:
            page_name: Name of the page
            element_key: Element key
            attempted_selectors: List of selectors that were tried
            healed_with: Selector that succeeded
            confidence: Confidence score
            method: Healing method used ("fuzzy_text" or "dom_proximity")
            test_name: Optional test name for context
        """
        self.audit_counter += 1
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        
        # Create audit record
        audit_data = {
            "test_name": test_name or "unknown",
            "page_name": page_name,
            "element_key": element_key,
            "attempted_selectors": attempted_selectors,
            "healed_with": healed_with,
            "confidence": confidence,
            "method": method,
            "timestamp": timestamp
        }
        
        # Save audit JSON
        audit_filename = f"{self.audit_counter:04d}_{page_name}_{element_key}_{timestamp}.json"
        audit_path = self.reporters_dir / audit_filename
        audit_data["audit_path"] = str(audit_path)
        
        try:
            with open(audit_path, 'w', encoding='utf-8') as f:
                json.dump(audit_data, f, indent=2)
            
            # Take screenshots
            screenshot_before = self.reporters_dir / f"{self.audit_counter:04d}_before.png"
            screenshot_after = self.reporters_dir / f"{self.audit_counter:04d}_after.png"
            
            self.page.screenshot(path=str(screenshot_before))
            audit_data["screenshot_before"] = str(screenshot_before)
            audit_data["screenshot_after"] = str(screenshot_after)
            
            # Update audit JSON with screenshot paths
            with open(audit_path, 'w', encoding='utf-8') as f:
                json.dump(audit_data, f, indent=2)
            
            # Attach to Allure if available
            if ALLURE_AVAILABLE:
                try:
                    allure.attach.file(
                        str(audit_path),
                        name="auto_heal_audit",
                        attachment_type=allure.attachment_type.JSON
                    )
                    allure.attach.file(
                        str(screenshot_before),
                        name="auto_heal_before",
                        attachment_type=allure.attachment_type.PNG
                    )
                except Exception as e:
                    print(f"Allure attachment error: {e}")
            
            print(f"Auto-heal audit saved: {audit_path}")
            
        except Exception as e:
            print(f"Error creating audit: {e}")
    
    def verify_fill(self, selector: str, expected_value: str, timeout_ms: int = 2000) -> bool:
        """
        Verify that a fill operation was successful by reading back the value.
        
        Args:
            selector: Selector for the input element
            expected_value: Expected value in the input
            timeout_ms: Timeout in milliseconds
            
        Returns:
            True if value matches, False otherwise
        """
        try:
            if selector.startswith("//") or selector.startswith("(//"):
                locator = self.page.locator(f"xpath={selector}")
            else:
                locator = self.page.locator(selector)
            
            locator.wait_for(state="visible", timeout=timeout_ms)
            actual_value = locator.input_value()
            return actual_value == expected_value
        except Exception:
            return False
    
    def verify_click(self, verify_selector: Optional[str] = None, timeout_ms: int = 5000) -> bool:
        """
        Verify that a click operation had the intended effect.
        
        Args:
            verify_selector: Optional selector for an element that should appear after click
            timeout_ms: Timeout in milliseconds
            
        Returns:
            True if verification passes, False otherwise
        """
        if verify_selector is None:
            # No verification selector provided, assume success
            return True
        
        try:
            if verify_selector.startswith("//") or verify_selector.startswith("(//"):
                locator = self.page.locator(f"xpath={verify_selector}")
            else:
                locator = self.page.locator(verify_selector)
            
            locator.wait_for(state="visible", timeout=timeout_ms)
            return True
        except PlaywrightTimeoutError:
            return False
        except Exception:
            return False
