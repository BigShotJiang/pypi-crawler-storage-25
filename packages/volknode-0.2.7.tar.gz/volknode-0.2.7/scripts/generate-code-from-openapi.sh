#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
OPENAPI_SPEC="$PROJECT_DIR/../openapi/api.yml"
OUTPUT_DIR="$PROJECT_DIR/volknode/src/http_client"

rm -rf "$OUTPUT_DIR"

"$PROJECT_DIR/.venv/bin/openapi-python-client" generate \
  --path "$OPENAPI_SPEC" \
  --output-path "$OUTPUT_DIR"
