#!/bin/bash
set -e
INSTALL_SCRIPT_VERSION=0.1

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

printf "%b\n" "${GREEN}This script's version: ${INSTALL_VERSION}${NC}"

# Configuration
PYTHON_VERSION="3.12"
CUDA_VERSION="12.8"
USER_HOME=$(getent passwd "$(whoami)" | cut -d: -f6)
export HOME="$USER_HOME"

echo -e "${GREEN}=== Installation Script ===${NC}"
echo "This script will install:"
echo "  - Python ${PYTHON_VERSION}"
echo "  - NVIDIA Drivers"
echo "  - CUDA ${CUDA_VERSION}"
echo "  - uv package manager"
echo "  - volknode CLI"
echo "  - vLLM"
echo ""

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo -e "${RED}Error: This script should not be run as root${NC}"
   echo "Please run as a regular user with sudo privileges"
   exit 1
fi

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    VERSION=$VERSION_ID
else
    echo -e "${RED}Error: Cannot detect OS${NC}"
    exit 1
fi

if [[ "$OS" != "ubuntu" && "$OS" != "debian" ]]; then
    echo -e "${RED}Error: This script only supports Ubuntu and Debian${NC}"
    exit 1
fi

echo -e "${GREEN}Detected OS: $OS $VERSION${NC}"
echo ""

# Update package lists
echo -e "${YELLOW}[1/7] Updating package lists...${NC}"
sudo apt-get update

# Install system dependencies for vLLM (OpenCV requires libxcb)
echo -e "${YELLOW}[1.5/7] Installing system dependencies...${NC}"
sudo apt-get install -y libxcb1 libgl1-mesa-glx libglib2.0-0

# Install Python 3.12
echo -e "${YELLOW}[2/7] Installing Python ${PYTHON_VERSION}...${NC}"
if command -v python${PYTHON_VERSION} &> /dev/null; then
    echo "Python ${PYTHON_VERSION} is already installed"
else
    if [[ "$OS" == "ubuntu" ]]; then
        # Add deadsnakes PPA manually. `add-apt-repository ppa:...` calls
        # api.launchpad.net via launchpadlib, which intermittently times out.
        # Fetch the signing key over HTTPS rather than via `gpg --recv-keys`
        # so we don't depend on dirmngr being installed and running.
        DEADSNAKES_PPA_SIGNING_KEY_FINGERPRINT="F23C5A6CF475977595C89F51BA6932366A755776"
        sudo apt-get install -y gnupg ca-certificates curl
        sudo install -d -m 0700 /root/.gnupg
        curl -fsSL "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x${DEADSNAKES_PPA_SIGNING_KEY_FINGERPRINT}" \
            | sudo gpg --dearmor -o /usr/share/keyrings/deadsnakes.gpg
        echo "deb [signed-by=/usr/share/keyrings/deadsnakes.gpg] http://ppa.launchpad.net/deadsnakes/ppa/ubuntu $(lsb_release -cs) main" | \
            sudo tee /etc/apt/sources.list.d/deadsnakes.list
        sudo apt-get update
    elif [[ "$OS" == "debian" ]]; then
        # Add backports for Python 3.12 on Debian
        echo "deb http://deb.debian.org/debian ${VERSION_CODENAME}-backports main" | sudo tee /etc/apt/sources.list.d/backports.list
        sudo apt-get update
    fi

    if [[ "$OS" == "debian" ]]; then
        sudo apt-get install -y -t ${VERSION_CODENAME}-backports \
            python${PYTHON_VERSION} \
            python${PYTHON_VERSION}-dev \
            python${PYTHON_VERSION}-venv \
            python3-pip
    else
        sudo apt-get install -y \
            python${PYTHON_VERSION} \
            python${PYTHON_VERSION}-dev \
            python${PYTHON_VERSION}-venv \
            python3-pip
    fi
fi

python${PYTHON_VERSION} --version

# Install NVIDIA drivers
echo -e "${YELLOW}[3/7] Installing NVIDIA drivers...${NC}"

# Detect if running in a container (Vast.ai, Docker, etc.)
if [ -f /.dockerenv ] || grep -q 'docker\|lxc\|kubepods' /proc/1/cgroup 2>/dev/null; then
    echo "Running in container environment - GPU drivers provided by host"
    # Just verify GPU is accessible
    if nvidia-smi &> /dev/null; then
        nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
    else
        echo -e "${YELLOW}Warning: nvidia-smi not available, but container should have GPU access${NC}"
    fi
elif command -v nvidia-smi &> /dev/null && nvidia-smi &> /dev/null; then
    echo "NVIDIA drivers already installed:"
    nvidia-smi --query-gpu=driver_version --format=csv,noheader
else
    echo "Installing NVIDIA drivers..."
    if [[ "$OS" == "ubuntu" ]]; then
        sudo apt-get install -y ubuntu-drivers-common
        sudo ubuntu-drivers autoinstall
    else
        # For Debian
        sudo apt-get install -y nvidia-driver firmware-misc-nonfree
    fi

    echo ""
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${RED}REBOOT REQUIRED${NC}"
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "NVIDIA drivers have been installed."
    echo "A reboot is required to load the drivers."
    echo ""
    echo "Please reboot and run this script again to continue installation:"
    echo "  sudo reboot"
    echo "  # After reboot:"
    echo "  ./install.sh"
    echo ""
    exit 0
fi

# Install CUDA
echo -e "${YELLOW}[4/7] Installing CUDA ${CUDA_VERSION}...${NC}"

# Check for existing CUDA installation (in PATH or standard locations) 
CUDA_FOUND=false
if command -v nvcc &> /dev/null; then
    CUDA_FOUND=true
    echo "CUDA is already installed:"
    nvcc --version
elif [ -x /usr/local/cuda/bin/nvcc ]; then
    CUDA_FOUND=true
    echo "CUDA found at /usr/local/cuda:"
    /usr/local/cuda/bin/nvcc --version
fi

if [ "$CUDA_FOUND" = false ]; then
    if [ -f /.dockerenv ] || grep -q 'docker\|lxc\|kubepods' /proc/1/cgroup 2>/dev/null; then
        echo -e "${YELLOW}Warning: CUDA not found in container. Expected container image to include CUDA.${NC}"
        exit 1
    else
        echo "Installing CUDA ${CUDA_VERSION}..."

        # Download CUDA keyring
        wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb -O /tmp/cuda-keyring.deb
        sudo dpkg -i /tmp/cuda-keyring.deb
        rm /tmp/cuda-keyring.deb

        sudo apt-get update
        sudo apt-get install -y cuda-toolkit-12-8

        # Add CUDA to PATH
        if [ -f "$USER_HOME/.bashrc" ] && ! grep -q "/usr/local/cuda/bin" "$USER_HOME/.bashrc"; then
            echo 'export PATH=/usr/local/cuda/bin:$PATH' >> "$USER_HOME/.bashrc"
            echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> "$USER_HOME/.bashrc"
        fi
    fi
fi

# Export CUDA paths for current session
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH

# Install uv
echo -e "${YELLOW}[5/7] Installing uv package manager...${NC}"
if command -v uv &> /dev/null || [ -x "$USER_HOME/.local/bin/uv" ]; then
    echo "uv is already installed:"
    "$USER_HOME/.local/bin/uv" --version 2>/dev/null || uv --version
else
    echo "Installing uv..."
    echo "HOME=$HOME, USER_HOME=$USER_HOME"

    # Ensure home directory and .local/bin exist
    mkdir -p "$USER_HOME/.local/bin"

    # Install uv
    curl -LsSf https://astral.sh/uv/install.sh | sh

    # Verify installation
    if [ ! -x "$USER_HOME/.local/bin/uv" ]; then
        echo -e "${RED}Error: uv installation failed${NC}"
        echo "Checking alternate locations..."
        find /home -name "uv" -type f 2>/dev/null || true
        find /root -name "uv" -type f 2>/dev/null || true
        exit 1
    fi

    # Source the env to make uv available immediately
    if [ -f "$USER_HOME/.local/bin/env" ]; then
        . "$USER_HOME/.local/bin/env"
    fi
fi


echo "The user HOME: $USER_HOME"

# Ensure uv is in PATH for current session
export PATH="$USER_HOME/.local/bin:$PATH"

# Add ~/.local/bin to PATH and set HF_HOME in shell config files for future sessions
# This ensures volknode and other uv tools are available after SSH login
# HF_HOME ensures HuggingFace models are cached in user's home directory
if [ -f "$USER_HOME/.bashrc" ] && ! grep -q '\.local/bin' "$USER_HOME/.bashrc"; then
    echo '' >> "$USER_HOME/.bashrc"
    echo '# Added by volknode installer - uv tools path and HuggingFace cache' >> "$USER_HOME/.bashrc"
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$USER_HOME/.bashrc"
    echo 'export HF_HOME="$HOME/.cache/huggingface"' >> "$USER_HOME/.bashrc"
fi

if [ -f "$USER_HOME/.profile" ] && ! grep -q '\.local/bin' "$USER_HOME/.profile"; then
    echo '' >> "$USER_HOME/.profile"
    echo '# Added by volknode installer - uv tools path and HuggingFace cache' >> "$USER_HOME/.profile"
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$USER_HOME/.profile"
    echo 'export HF_HOME="$HOME/.cache/huggingface"' >> "$USER_HOME/.profile"
fi

# Create HuggingFace cache directory with correct permissions
mkdir -p "$USER_HOME/.cache/huggingface"

uv --version

# Install volknode CLI from PyPI
echo -e "${YELLOW}[6/7] Installing volknode CLI...${NC}"
uv tool install --python python${PYTHON_VERSION} volknode

# Create symlink in /usr/local/bin so volknode is available for all sessions (including non-interactive SSH)
if [ -x "$USER_HOME/.local/bin/volknode" ]; then
    sudo ln -sf "$USER_HOME/.local/bin/volknode" /usr/local/bin/volknode
    echo "Created symlink: /usr/local/bin/volknode -> $USER_HOME/.local/bin/volknode"
fi

volknode --help
volknode --version

# Install vLLM
echo -e "${YELLOW}[7/7] Installing vLLM with uv...${NC}"
sudo "$USER_HOME/.local/bin/uv" pip install --system 'vllm>=0.19.1,<0.20.0' 'huggingface_hub>=0.34.0,<1.0'

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}Installation Complete!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "Summary:"
echo "  ✓ Python ${PYTHON_VERSION}"
echo "  ✓ NVIDIA drivers"
echo "  ✓ CUDA ${CUDA_VERSION}"
echo "  ✓ uv package manager"
echo "  ✓ volknode CLI"
echo "  ✓ vLLM"
echo ""
echo -e "${GREEN}All components installed successfully!${NC}"
echo ""
echo -e "${YELLOW}To use the newly installed tools in your current shell:${NC}"
echo "  source ~/.bashrc"
echo "  # or"
echo "  source ~/.local/bin/env"
echo ""
echo "After that, you can use vLLM with:"
echo "  python${PYTHON_VERSION} -m vllm.entrypoints.openai.api_server --model <model-name>"
echo ""








