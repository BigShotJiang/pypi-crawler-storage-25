#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${CI_PROJECT_DIR:-$(cd "$SCRIPT_DIR/../../../.." && pwd)}"

# ─── Netlify configuration ───
NETLIFY_AUTH_TOKEN=${NETLIFY_AUTH_TOKEN:?"NETLIFY_AUTH_TOKEN must be set"}
NETLIFY_LLM_NODE_INSTALLSH_TEST_SITE_ID=${NETLIFY_LLM_NODE_INSTALLSH_TEST_SITE_ID:?"NETLIFY_LLM_NODE_INSTALLSH_TEST_SITE_ID must be set"}

# ─── GCloud configuration ───
GCLOUD_PROJECT=${GCLOUD_PROJECT:-"llm-node-testing-479012-f6"}
GCLOUD_ZONES=${GCLOUD_ZONES:-"us-central1-a us-central1-b us-central1-c us-central1-f us-east1-b us-east1-c us-east4-a us-east4-b us-east4-c us-west1-a us-west1-b us-west4-a us-west4-b europe-west1-b europe-west1-c europe-west4-a europe-west4-b europe-west4-c"}
GCLOUD_MACHINE_TYPE=${GCLOUD_MACHINE_TYPE:-"g2-standard-8"}
GCLOUD_GPU_TYPE=${GCLOUD_GPU_TYPE:-"nvidia-l4"}
GCLOUD_GPU_COUNT=${GCLOUD_GPU_COUNT:-1}
GCLOUD_DISK_SIZE_GB=${GCLOUD_DISK_SIZE_GB:-200}
GCLOUD_IMAGE_FAMILY=${GCLOUD_IMAGE_FAMILY:-"ubuntu-2204-lts"}
GCLOUD_IMAGE_PROJECT=${GCLOUD_IMAGE_PROJECT:-"ubuntu-os-cloud"}
GCLOUD_SERVICE_ACCOUNT_KEY=${GCLOUD_SERVICE_ACCOUNT_KEY:-""}

# ─── Step 1: Deploy install.sh to Netlify test site ───
echo "=== Deploying install.sh to Netlify test site ==="
cd "$REPO_ROOT/ai-suite/llm-node" && task build
netlify deploy --prod --dir="$REPO_ROOT/ai-suite/llm-node/installsh/dist" --site="$NETLIFY_LLM_NODE_INSTALLSH_TEST_SITE_ID"

# ─── Step 2: Authenticate with gcloud ───
echo "=== Authenticating with gcloud ==="
if [[ -n "$GCLOUD_SERVICE_ACCOUNT_KEY" ]]; then
    echo "$GCLOUD_SERVICE_ACCOUNT_KEY" > /tmp/gcloud-sa-key.json
    gcloud auth activate-service-account --key-file=/tmp/gcloud-sa-key.json
    rm -f /tmp/gcloud-sa-key.json
else
    echo "Warning: \$GCLOUD_SERVICE_ACCOUNT_KEY not set, assuming gcloud is already authenticated"
fi
gcloud config set project "$GCLOUD_PROJECT" --quiet

# ─── Instance variables (used by cleanup trap) ───
instance_name=""
GCLOUD_ZONE=""

random_unique_tmp_dir_name=$(tr -dc 'a-zA-Z' </dev/urandom | head -c 16)
gpu_instance_provision_tmp_dir=/tmp/test-installsh/$random_unique_tmp_dir_name
gpu_instance_user_private_key_path=$gpu_instance_provision_tmp_dir/gpu_instance_key
gpu_instance_user_public_key_path=$gpu_instance_provision_tmp_dir/gpu_instance_key.pub

cleanup() {
    echo "=== Cleaning up ==="
    if [[ -n "$instance_name" && -n "$GCLOUD_ZONE" ]]; then
        echo "Deleting GCP instance: $instance_name (zone: $GCLOUD_ZONE)"
        gcloud compute instances delete "$instance_name" \
            --project="$GCLOUD_PROJECT" \
            --zone="$GCLOUD_ZONE" \
            --quiet || true
        echo "Instance deleted"
    fi
    if [[ -n "$gpu_instance_provision_tmp_dir" ]]; then
        rm -rf "$gpu_instance_provision_tmp_dir" || true
    fi
}

trap cleanup EXIT

# ─── Step 3: Create GCP GPU instance ───
rm -rf $gpu_instance_provision_tmp_dir
mkdir -p $gpu_instance_provision_tmp_dir

ssh-keygen -b 2048 -t rsa -f $gpu_instance_user_private_key_path -q -N ""
llmnode_runner_user_public_key=$(cat $gpu_instance_user_public_key_path)
chmod 600 $gpu_instance_user_private_key_path

instance_name="test-installsh-$(tr -dc 'a-z0-9' </dev/urandom | head -c 8)"

startup_script=$(cat <<'STARTUP'
#!/bin/bash
exec > /var/log/startup-script.log 2>&1
set -x

# Phase 1: Install NVIDIA drivers and reboot
if [[ ! -f /var/log/nvidia-driver-installed ]]; then
    apt-get update
    apt-get install -y build-essential linux-headers-$(uname -r) openssh-server sudo curl python3 python3-pip python3-venv

    curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
    distribution=$(. /etc/os-release; echo $ID$VERSION_ID)
    curl -sL "https://nvidia.github.io/libnvidia-container/$distribution/libnvidia-container.list" | \
        sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
        tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

    apt-get update
    apt-get install -y nvidia-driver-550
    apt-get install -y cuda-toolkit-12-8

    echo 'export PATH=/usr/local/cuda/bin:$PATH' >> /etc/profile.d/cuda.sh
    echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> /etc/profile.d/cuda.sh

    touch /var/log/nvidia-driver-installed
    echo "NVIDIA driver installed, rebooting to load kernel module..."
    reboot
    exit 0
fi

# Phase 2: After reboot — set up user and signal readiness
if ! id llmnode-runner &>/dev/null; then
    useradd -m -s /bin/bash llmnode-runner
fi
echo 'llmnode-runner ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers

mkdir -p /home/llmnode-runner/.ssh
echo 'PUBLIC_KEY_PLACEHOLDER' >> /home/llmnode-runner/.ssh/authorized_keys
chmod 700 /home/llmnode-runner/.ssh
chmod 600 /home/llmnode-runner/.ssh/authorized_keys
chown -R llmnode-runner:llmnode-runner /home/llmnode-runner/.ssh

nvidia-smi
echo "GPU setup complete"
touch /var/log/startup-script-done
STARTUP
)

startup_script="${startup_script//PUBLIC_KEY_PLACEHOLDER/$llmnode_runner_user_public_key}"
echo "$startup_script" > $gpu_instance_provision_tmp_dir/startup-script.sh

echo "=== Creating GCP GPU instance ==="
echo "  Project: $GCLOUD_PROJECT"
echo "  Machine type: $GCLOUD_MACHINE_TYPE"
echo "  GPU: ${GCLOUD_GPU_COUNT}x $GCLOUD_GPU_TYPE"
echo "  Disk size: ${GCLOUD_DISK_SIZE_GB}GB"
echo "  Instance name: $instance_name"
echo "  Zones to try: $GCLOUD_ZONES"

for zone in $GCLOUD_ZONES; do
    echo "Trying zone: $zone..."
    if gcloud compute instances create "$instance_name" \
        --project="$GCLOUD_PROJECT" \
        --zone="$zone" \
        --machine-type="$GCLOUD_MACHINE_TYPE" \
        --accelerator="type=$GCLOUD_GPU_TYPE,count=$GCLOUD_GPU_COUNT" \
        --maintenance-policy=TERMINATE \
        --boot-disk-size="${GCLOUD_DISK_SIZE_GB}GB" \
        --image-family="$GCLOUD_IMAGE_FAMILY" \
        --image-project="$GCLOUD_IMAGE_PROJECT" \
        --metadata-from-file=startup-script=$gpu_instance_provision_tmp_dir/startup-script.sh 2>&1; then
        GCLOUD_ZONE="$zone"
        echo "Created instance: $instance_name in zone: $GCLOUD_ZONE"
        break
    else
        echo "Zone $zone unavailable, trying next..."
    fi
done

if [[ -z "$GCLOUD_ZONE" ]]; then
    echo "Error: Could not create instance in any zone"
    exit 1
fi

# ─── Step 4: Wait for instance to be ready ───
echo "=== Waiting for instance to be running ==="
max_attempts=60
attempt=0
while [ $attempt -lt $max_attempts ]; do
    status=$(gcloud compute instances describe "$instance_name" \
        --project="$GCLOUD_PROJECT" \
        --zone="$GCLOUD_ZONE" \
        --format="value(status)")

    if [[ "$status" == "RUNNING" ]]; then
        echo "Instance is running"
        break
    fi

    echo "Instance status: $status (attempt $((attempt+1))/$max_attempts)"
    sleep 10
    attempt=$((attempt+1))
done

if [[ "$status" != "RUNNING" ]]; then
    echo "Error: Instance did not become ready"
    exit 1
fi

ssh_host=$(gcloud compute instances describe "$instance_name" \
    --project="$GCLOUD_PROJECT" \
    --zone="$GCLOUD_ZONE" \
    --format="value(networkInterfaces[0].accessConfigs[0].natIP)")

echo "Instance external IP: $ssh_host"

SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 -i $gpu_instance_user_private_key_path"

echo "=== Waiting for SSH to be available ==="
attempt=0
while [ $attempt -lt 30 ]; do
    if ssh $SSH_OPTS llmnode-runner@$ssh_host "echo 'SSH ready'" 2>/dev/null; then
        echo "SSH is ready"
        break
    fi
    echo "Waiting for SSH... (attempt $((attempt+1))/30)"
    sleep 10
    attempt=$((attempt+1))
done

echo "=== Waiting for startup script to complete ==="
attempt=0
while [ $attempt -lt 60 ]; do
    if ssh $SSH_OPTS llmnode-runner@$ssh_host "test -f /var/log/startup-script-done" 2>/dev/null; then
        echo "Startup script completed"
        break
    fi
    echo "Waiting for startup script to finish... (attempt $((attempt+1))/60)"
    sleep 15
    attempt=$((attempt+1))
done

if ! ssh $SSH_OPTS llmnode-runner@$ssh_host "test -f /var/log/startup-script-done" 2>/dev/null; then
    echo "Error: Startup script did not complete"
    echo "=== Startup script log ==="
    ssh $SSH_OPTS llmnode-runner@$ssh_host "sudo cat /var/log/startup-script.log" 2>/dev/null || true
    exit 1
fi

# ─── Step 5: Copy files and install volknode via install.sh ───
echo "=== Copying llm-node to GPU instance ==="
rsync -av --progress \
    -e "ssh $SSH_OPTS" \
    "$REPO_ROOT/ai-suite/llm-node/" \
    llmnode-runner@$ssh_host:~/volksai-llm-node

echo "=== Installing volknode via install.sh ==="
ssh $SSH_OPTS llmnode-runner@$ssh_host \
    "curl -sSL https://llmnode-test.volksai.io/install.sh | bash"

# ─── Step 6: Start vLLM and wait for health ───
cat > /tmp/read_vllm_port.py << 'PYEOF'
import sqlite3, pathlib
db = pathlib.Path.home() / ".volknode" / "volknode.db"
try:
    conn = sqlite3.connect(str(db))
    row = conn.execute("SELECT port FROM running_vllm_config ORDER BY id DESC LIMIT 1").fetchone()
    print(row[0] if row else "")
except Exception:
    print("")
PYEOF

scp $SSH_OPTS /tmp/read_vllm_port.py llmnode-runner@$ssh_host:/tmp/read_vllm_port.py

echo "=== Starting volknode and waiting for vLLM to be healthy ==="
ssh $SSH_OPTS llmnode-runner@$ssh_host "
    nvidia-smi || echo 'nvidia-smi not available'
    df -h /dev/shm || echo '/dev/shm not available'

    volknode pull Qwen/Qwen2.5-1.5B-Instruct
    PYTHONUNBUFFERED=1 volknode run --model Qwen/Qwen2.5-1.5B-Instruct > ~/vllm.log 2>&1 &
    VOLKNODE_PID=\$!

    echo 'Waiting for port to be written to database...'
    max_attempts=30
    attempt=0
    vllm_port=''
    while [ \$attempt -lt \$max_attempts ]; do
        vllm_port=\$(python3.12 /tmp/read_vllm_port.py 2>/dev/null || true)
        if [ -n \"\$vllm_port\" ]; then
            echo \"Found vLLM port: \$vllm_port\"
            break
        fi
        sleep 2
        attempt=\$((attempt + 1))
    done

    if [ -z \"\$vllm_port\" ]; then
        echo 'Error: Could not read vLLM port from database'
        ls -la ~/.volknode/ 2>/dev/null || echo 'No .volknode directory'
        cat ~/vllm.log
        exit 1
    fi

    echo \"Waiting for vLLM health on port \$vllm_port...\"
    max_attempts=100
    attempt=0
    while [ \$attempt -lt \$max_attempts ]; do
        if curl -s http://127.0.0.1:\$vllm_port/health > /dev/null 2>&1; then
            echo 'vLLM server is ready!'
            cat ~/vllm.log
            echo \"VLLM_PORT=\$vllm_port\"
            exit 0
        fi
        if ! kill -0 \$VOLKNODE_PID 2>/dev/null; then
            echo 'volknode process died'
            cat ~/vllm.log
            exit 1
        fi
        attempt=\$((attempt + 1))
        echo \"Waiting for server... (\$attempt/\$max_attempts)\"
        tail -n 10 ~/vllm.log 2>/dev/null
        sleep 15
    done
    echo 'Timeout waiting for vLLM server'
    cat ~/vllm.log
    exit 1"

vllm_port=$(ssh $SSH_OPTS llmnode-runner@$ssh_host "python3.12 /tmp/read_vllm_port.py")

echo "vLLM server running at http://$ssh_host:$vllm_port"

# ─── Step 7: Test the API via SSH tunnel ───
echo "=== Testing streaming chat completion API ==="
ssh $SSH_OPTS \
    -L 8000:localhost:$vllm_port \
    -N \
    -f \
    llmnode-runner@$ssh_host
sleep 2

cat > /tmp/request.json << 'EOF'
{
  "messages": [
    {"role": "system", "content": "You are a helpful assistant that formats the answers as plain text."},
    {"role": "user", "content": "Say hello in one sentence."}
  ],
  "stream": true
}
EOF

echo "Request payload:"
cat /tmp/request.json
echo ""
echo "Sending request..."
curl -sN --max-time 120 -X POST http://localhost:8000/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d @/tmp/request.json > /tmp/response.txt

echo "Response:"
cat /tmp/response.txt

if grep -q "data:" /tmp/response.txt; then
    echo "Received streaming response from vLLM API"
    echo "Content received:"
    grep "^data:" /tmp/response.txt | grep -v "\[DONE\]" | sed 's/^data: //' | jq -r '.choices[0].delta.content // empty' 2>/dev/null | tr -d '\n'
    echo ""
else
    echo "Failed to receive streaming response"
    exit 1
fi

echo "=== install.sh test completed successfully ==="
