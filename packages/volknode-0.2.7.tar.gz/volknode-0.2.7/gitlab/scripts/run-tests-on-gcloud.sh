#!/bin/bash
set -e

# GCLOUD_PROJECT=${GCLOUD_PROJECT:?"\$GCLOUD_PROJECT must be set"}
GCLOUD_PROJECT=${GCLOUD_PROJECT:-"llm-node-testing-479012-f6"}
GCLOUD_ZONES=${GCLOUD_ZONES:-"us-central1-a us-central1-b us-central1-c us-central1-f us-east1-b us-east1-c us-east4-a us-east4-b us-east4-c us-west1-a us-west1-b us-west4-a us-west4-b europe-west1-b europe-west1-c europe-west4-a europe-west4-b europe-west4-c"}
GCLOUD_MACHINE_TYPE=${GCLOUD_MACHINE_TYPE:-"g2-standard-8"}
GCLOUD_GPU_TYPE=${GCLOUD_GPU_TYPE:-"nvidia-l4"}
GCLOUD_GPU_COUNT=${GCLOUD_GPU_COUNT:-1}
GCLOUD_DISK_SIZE_GB=${GCLOUD_DISK_SIZE_GB:-200}
GCLOUD_IMAGE_FAMILY=${GCLOUD_IMAGE_FAMILY:-"ubuntu-2204-lts"}
GCLOUD_IMAGE_PROJECT=${GCLOUD_IMAGE_PROJECT:-"ubuntu-os-cloud"}

GCLOUD_SERVICE_ACCOUNT_KEY=${GCLOUD_SERVICE_ACCOUNT_KEY:-""}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${CI_PROJECT_DIR:-$(cd "$SCRIPT_DIR/../../../.." && pwd)}"

# Authenticate with gcloud
echo "=== Authenticating with gcloud ==="
if [[ -n "$GCLOUD_SERVICE_ACCOUNT_KEY" ]]; then
    echo "$GCLOUD_SERVICE_ACCOUNT_KEY" > /tmp/gcloud-sa-key.json
    gcloud auth activate-service-account --key-file=/tmp/gcloud-sa-key.json
    rm -f /tmp/gcloud-sa-key.json
else
    echo "Warning: \$GCLOUD_SERVICE_ACCOUNT_KEY not set, assuming gcloud is already authenticated"
fi
gcloud config set project "$GCLOUD_PROJECT" --quiet

instance_name=""
GCLOUD_ZONE=""

cleanup() {
    echo "=== Cleaning up ==="
    if [[ -n "$instance_name" && -n "$GCLOUD_ZONE" ]]; then
        echo "Deleting GCP instance: $instance_name (zone: $GCLOUD_ZONE)"
        gcloud compute instances delete "$instance_name" \
            --project="$GCLOUD_PROJECT" \
            --zone="$GCLOUD_ZONE" \
            --quiet || true
        echo "Instance deleted"
    fi
    if [[ -n "$gpu_instance_provision_tmp_dir" ]]; then
        rm -rf "$gpu_instance_provision_tmp_dir" || true
    fi
}

trap cleanup EXIT

random_unique_tmp_dir_name=$(tr -dc 'a-zA-Z' </dev/urandom | head -c 16)
gpu_instance_provision_tmp_dir=/tmp/vllm-integration-tests/$random_unique_tmp_dir_name
gpu_instance_user_private_key_path=$gpu_instance_provision_tmp_dir/gpu_instance_key
gpu_instance_user_public_key_path=$gpu_instance_provision_tmp_dir/gpu_instance_key.pub

rm -rf $gpu_instance_provision_tmp_dir
mkdir -p $gpu_instance_provision_tmp_dir

# Generate SSH key pair
ssh-keygen -b 2048 -t rsa -f $gpu_instance_user_private_key_path -q -N ""
llmnode_runner_user_public_key=$(cat $gpu_instance_user_public_key_path)
chmod 600 $gpu_instance_user_private_key_path

instance_name="vllm-integration-test-$(tr -dc 'a-z0-9' </dev/urandom | head -c 8)"

# Create startup script that installs NVIDIA drivers, CUDA, and sets up the user.
# GCP startup scripts run on every boot. After installing NVIDIA drivers, a reboot
# is required to load the kernel module. The script uses a marker file to track
# whether the driver install + reboot has already happened.
startup_script=$(cat <<'STARTUP'
#!/bin/bash
exec > /var/log/startup-script.log 2>&1
set -x

# Phase 1: Install NVIDIA drivers and reboot
if [[ ! -f /var/log/nvidia-driver-installed ]]; then
    apt-get update
    apt-get install -y build-essential linux-headers-$(uname -r) openssh-server sudo curl python3 python3-pip python3-venv

    curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
    distribution=$(. /etc/os-release; echo $ID$VERSION_ID)
    curl -sL "https://nvidia.github.io/libnvidia-container/$distribution/libnvidia-container.list" | \
        sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
        tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

    apt-get update
    apt-get install -y nvidia-driver-550
    apt-get install -y cuda-toolkit-12-8

    echo 'export PATH=/usr/local/cuda/bin:$PATH' >> /etc/profile.d/cuda.sh
    echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> /etc/profile.d/cuda.sh

    touch /var/log/nvidia-driver-installed
    echo "NVIDIA driver installed, rebooting to load kernel module..."
    reboot
    exit 0
fi

# Phase 2: After reboot — set up user and signal readiness
if ! id llmnode-runner &>/dev/null; then
    useradd -m -s /bin/bash llmnode-runner
fi
echo 'llmnode-runner ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers

mkdir -p /home/llmnode-runner/.ssh
echo 'PUBLIC_KEY_PLACEHOLDER' >> /home/llmnode-runner/.ssh/authorized_keys
chmod 700 /home/llmnode-runner/.ssh
chmod 600 /home/llmnode-runner/.ssh/authorized_keys
chown -R llmnode-runner:llmnode-runner /home/llmnode-runner/.ssh

nvidia-smi
echo "GPU setup complete"
touch /var/log/startup-script-done
STARTUP
)

startup_script="${startup_script//PUBLIC_KEY_PLACEHOLDER/$llmnode_runner_user_public_key}"

echo "$startup_script" > $gpu_instance_provision_tmp_dir/startup-script.sh

# Create the instance, trying each zone until one succeeds
echo "=== Creating GCP GPU instance ==="
echo "  Project: $GCLOUD_PROJECT"
echo "  Machine type: $GCLOUD_MACHINE_TYPE"
echo "  GPU: ${GCLOUD_GPU_COUNT}x $GCLOUD_GPU_TYPE"
echo "  Disk size: ${GCLOUD_DISK_SIZE_GB}GB"
echo "  Instance name: $instance_name"
echo "  Zones to try: $GCLOUD_ZONES"

for zone in $GCLOUD_ZONES; do
    echo "Trying zone: $zone..."
    if gcloud compute instances create "$instance_name" \
        --project="$GCLOUD_PROJECT" \
        --zone="$zone" \
        --machine-type="$GCLOUD_MACHINE_TYPE" \
        --accelerator="type=$GCLOUD_GPU_TYPE,count=$GCLOUD_GPU_COUNT" \
        --maintenance-policy=TERMINATE \
        --boot-disk-size="${GCLOUD_DISK_SIZE_GB}GB" \
        --image-family="$GCLOUD_IMAGE_FAMILY" \
        --image-project="$GCLOUD_IMAGE_PROJECT" \
        --metadata-from-file=startup-script=$gpu_instance_provision_tmp_dir/startup-script.sh 2>&1; then
        GCLOUD_ZONE="$zone"
        echo "Created instance: $instance_name in zone: $GCLOUD_ZONE"
        break
    else
        echo "Zone $zone unavailable, trying next..."
    fi
done

if [[ -z "$GCLOUD_ZONE" ]]; then
    echo "Error: Could not create instance in any zone"
    exit 1
fi

# Wait for instance to be running
echo "=== Waiting for instance to be running ==="
max_attempts=60
attempt=0
while [ $attempt -lt $max_attempts ]; do
    status=$(gcloud compute instances describe "$instance_name" \
        --project="$GCLOUD_PROJECT" \
        --zone="$GCLOUD_ZONE" \
        --format="value(status)")

    if [[ "$status" == "RUNNING" ]]; then
        echo "Instance is running"
        break
    fi

    echo "Instance status: $status (attempt $((attempt+1))/$max_attempts)"
    sleep 10
    attempt=$((attempt+1))
done

if [[ "$status" != "RUNNING" ]]; then
    echo "Error: Instance did not become ready"
    exit 1
fi

ssh_host=$(gcloud compute instances describe "$instance_name" \
    --project="$GCLOUD_PROJECT" \
    --zone="$GCLOUD_ZONE" \
    --format="value(networkInterfaces[0].accessConfigs[0].natIP)")

echo "Instance external IP: $ssh_host"

# Wait for SSH
echo "=== Waiting for SSH to be available ==="
attempt=0
while [ $attempt -lt 30 ]; do
    if ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o ConnectTimeout=5 -i $gpu_instance_user_private_key_path \
        llmnode-runner@$ssh_host "echo 'SSH ready'" 2>/dev/null; then
        echo "SSH is ready"
        break
    fi
    echo "Waiting for SSH... (attempt $((attempt+1))/30)"
    sleep 10
    attempt=$((attempt+1))
done

# Wait for startup script to finish (NVIDIA drivers, CUDA)
echo "=== Waiting for startup script to complete ==="
attempt=0
while [ $attempt -lt 60 ]; do
    if ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o ConnectTimeout=5 -i $gpu_instance_user_private_key_path \
        llmnode-runner@$ssh_host "test -f /var/log/startup-script-done" 2>/dev/null; then
        echo "Startup script completed"
        break
    fi
    echo "Waiting for startup script to finish... (attempt $((attempt+1))/60)"
    sleep 15
    attempt=$((attempt+1))
done

if ! ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o ConnectTimeout=5 -i $gpu_instance_user_private_key_path \
    llmnode-runner@$ssh_host "test -f /var/log/startup-script-done" 2>/dev/null; then
    echo "Error: Startup script did not complete"
    echo "=== Startup script log ==="
    ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -i $gpu_instance_user_private_key_path \
        llmnode-runner@$ssh_host "sudo cat /var/log/startup-script.log" 2>/dev/null || true
    exit 1
fi

# Copy test files to instance
echo "=== Copying test files to GPU instance ==="
rsync -az --progress \
    -e "ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i $gpu_instance_user_private_key_path" \
    --exclude='.venv' \
    --exclude='__pycache__' \
    --exclude='.pytest_cache' \
    --exclude='.mypy_cache' \
    --exclude='gitlab' \
    $REPO_ROOT/ai-suite/llm-node/ \
    llmnode-runner@$ssh_host:~/llm-node

# Run integration tests
echo "=== Running vLLM integration tests ==="
ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -i $gpu_instance_user_private_key_path \
    llmnode-runner@$ssh_host \
    "pip install uv && \
     export PATH=\$HOME/.local/bin:/usr/local/cuda/bin:\$PATH && \
     export LD_LIBRARY_PATH=/usr/local/cuda/lib64:\$LD_LIBRARY_PATH && \
     cd ~/llm-node && \
     uv sync --extra gpu && \
     uv run pytest volknode/src/llm/llm_integration_test.py -v"

echo "=== vLLM integration tests completed successfully ==="
