import os
import pwd
from importlib.metadata import version
from pathlib import Path

import typer

from volknode.src.dependency_resolver import DependencyResolver
from volknode.src.repository import CsrCredentialsRepository, LlmModelRepository, LlmNodeCertificateRepository, NexusCertificateRepository, RunningVllmConfigRepository
from volknode.src.usecases.pull_model.input import PullModelInput
from volknode.src.usecases.pull_model.interactor import PullModelInteractor
from volknode.src.usecases.register_llm_node.input import RegisterLlmNodeInput
from volknode.src.usecases.register_llm_node.interactor import RegisterLlmNodeInteractor
from volknode.src.usecases.run_llm_node.input import RunLlmNodeInput
from volknode.src.usecases.run_llm_node.interactor import RunLlmNodeInteractor
from volknode.src.usecases.serve_llm.input import ServeLlmInput
from volknode.src.usecases.serve_llm.interactor import ServeLlmInteractor


def get_user_home() -> Path:
    """Get actual user's home directory, ignoring HOME env var."""
    return Path(pwd.getpwuid(os.getuid()).pw_dir)

def _get_db_path() -> Path:
    db_dir = get_user_home() / ".volknode"
    db_dir.mkdir(parents=True, exist_ok=True)
    return db_dir / "volknode.db"


app = typer.Typer()


def version_callback(value: bool):
    if value:
        print(f"volknode {version('volknode')}")
        raise typer.Exit()


@app.callback()
def callback(
    version: bool = typer.Option(
        None, "--version", "-v", callback=version_callback, is_eager=True,
        help="Show version and exit."
    ),
):
    """Volknode CLI application."""
    pass

@app.command("pull")
def pull_command(
    model_name: str = typer.Argument(..., help="The name of the model to pull."),
):
    """Pull a model from Hugging Face."""
    user_home = get_user_home()
    os.environ["HOME"] = str(user_home)

    input_data, validation = PullModelInput.create(model_name)
    if validation.has_errors():
        for err in validation.errors():
            print(f"Error: {err}")
        raise typer.Exit(1)

    db_path = _get_db_path()
    llm = DependencyResolver.from_env().llm_runner(cache_dir=user_home / ".cache")
    llm_model_repo = LlmModelRepository(db_path)

    interactor = PullModelInteractor(llm, llm_model_repo)

    print(f"Pulling model: {model_name}")

    try:
        interactor.execute(input_data)
        print(f"Successfully pulled model: {model_name}")
    except Exception as e:
        print(f"Error pulling model: {e}")
        raise typer.Exit(1)

@app.command("run")
def run_command(
    model: str = typer.Option(..., help="Model to serve"),
):
    """Run vLLM server with the specified model."""
    user_home = get_user_home()
    os.environ["HOME"] = str(user_home)

    input_data, validation = RunLlmNodeInput.create(model)
    if validation.has_errors():
        for err in validation.errors():
            print(f"Error: {err}")
        raise typer.Exit(1)

    db_path = _get_db_path()
    llm = DependencyResolver.from_env().llm_runner(cache_dir=user_home / ".cache")
    llm_model_repo = LlmModelRepository(db_path)
    running_vllm_config_repo = RunningVllmConfigRepository(db_path)

    interactor = RunLlmNodeInteractor(llm, llm_model_repo, running_vllm_config_repo)

    print(f"Starting vLLM server with model: {model}")

    try:
        interactor.execute(input_data)
        print("vLLM server is ready.")
        import signal
        signal.pause()
    except KeyboardInterrupt:
        print("\nShutting down vLLM server...")
        llm.stop()
    except RuntimeError as e:
        print(f"Error: {e}")
        raise typer.Exit(1)


@app.command("register") 
def register_command(
    nexus_url: str = typer.Option(..., "--nexus-url", help="The URL of the nexus server."),
    url: str = typer.Option(..., "--url", help="The URL that the nexus can reach this LLM node with."),
    personal_access_token: str = typer.Option(..., "--personal-access-token", help="Personal access token for authentication."),
    llm_model_name: str = typer.Option(..., "--llm-model-name", help="The organization friendly name for the LLM model."),
    trust_insecure_remote_app_url: bool = typer.Option(False, "--trust-insecure-url", help="Skip TLS certificate verification for the nexus URL (e.g. self-signed certificates)."),
):
    """Register this LLM node with the nexus."""
    input_data, validation = RegisterLlmNodeInput.create(url, personal_access_token, llm_model_name)

    if validation.has_errors():
        for err in validation.errors():
            print(f"Error: {err}")
        raise typer.Exit(1)


    db_path = _get_db_path()
    nexus = DependencyResolver.from_env().nexus(nexus_url=nexus_url, verify_ssl=not trust_insecure_remote_app_url)
    llm_model_repo = LlmModelRepository(db_path)
    csr_credentials_repo = CsrCredentialsRepository(db_path)
    llm_node_certificate_repo = LlmNodeCertificateRepository(db_path)
    nexus_certificate_repo = NexusCertificateRepository(db_path)

    interactor = RegisterLlmNodeInteractor(
        nexus=nexus,
        llm_model_repository=llm_model_repo,
        csr_credentials_repository=csr_credentials_repo,
        llm_node_certificate_repository=llm_node_certificate_repo,
        nexus_certificate_repository=nexus_certificate_repo,
    )

    print(f"Registering LLM node with model name '{input_data.llm_model_name}' with nexus at {nexus_url}")

    try:
        interactor.execute(input_data)
        print("Registration successful.")
    except RuntimeError as e:
        print(f"Error: {e}")
        raise typer.Exit(1)


@app.command("serve")
def serve_command(
    port: int = typer.Option(..., "--port", help="Port for the secure server that will serve LLM requests."),
    with_test_cert_pem: str = typer.Option(None, "--with-test-cert-pem", hidden=True),
    with_test_priv_key_pem: str = typer.Option(None, "--with-test-priv-key-pem", hidden=True),
    with_test_ca_cert_pem: str = typer.Option(None, "--with-test-ca-cert-pem", hidden=True),
):
    """Start the secure server to expose the LLM to the nexus."""
    from volknode.src.mtls.mtls_reverse_proxy import MtlsReverseProxy

    input_data, validation = ServeLlmInput.create(
        port,
        test_cert_pem=with_test_cert_pem,
        test_priv_key_pem=with_test_priv_key_pem,
        test_ca_cert_pem=with_test_ca_cert_pem,
    )
    if validation.has_errors():
        for err in validation.errors():
            print(f"Error: {err}")
        raise typer.Exit(1)

    db_path = _get_db_path()
    csr_credentials_repo = CsrCredentialsRepository(db_path)
    llm_node_certificate_repo = LlmNodeCertificateRepository(db_path)
    nexus_certificate_repo = NexusCertificateRepository(db_path)

    if input_data.test_cert_pem is not None:
        from volknode.src.domain.csr_credentials import CsrCredentials
        from volknode.src.domain.llm_node_certificate import LlmNodeCertificate
        from volknode.src.domain.nexus_certificate import NexusCertificate

        csr_credentials_repo.save(CsrCredentials(private_key_pem=input_data.test_priv_key_pem, csr_pem=""))
        llm_node_certificate_repo.save(LlmNodeCertificate(certificate_pem=input_data.test_cert_pem))
        nexus_certificate_repo.save(NexusCertificate(certificate_pem=input_data.test_ca_cert_pem))

    interactor = ServeLlmInteractor(
        csr_credentials_repository=csr_credentials_repo,
        llm_node_certificate_repository=llm_node_certificate_repo,
        nexus_certificate_repository=nexus_certificate_repo,
        running_vllm_config_repository=RunningVllmConfigRepository(db_path),
        mtls_reverse_proxy=MtlsReverseProxy(),
    )

    print(f"Starting secure server on port {port}")

    try:
        interactor.execute(input_data)
        print("Secure server is running.")
        import signal
        signal.pause()
    except KeyboardInterrupt:
        print("\nShutting down secure server...")
    except RuntimeError as e:
        print(f"Error: {e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
