from dataclasses import dataclass


@dataclass
class PulledModelInfo:
    name: str
    context_window: int
    quantization: str
    supports_chat_completions: bool
