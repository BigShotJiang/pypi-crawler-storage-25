import json
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer


class VllmHandler(BaseHTTPRequestHandler):
    model_name: str = ""

    def log_message(self, format, *args):  # noqa: A002
        """Suppress HTTP server logging."""

    def do_POST(self):
        if self.path == "/v1/chat/completions":
            self._handle_chat_completions()
        else:
            self.send_error(404, "Not Found")

    def _send_json_error(self, code: int, message: str, error_type: str) -> None:
        error_body = json.dumps({
            "error": {"message": message, "type": error_type, "param": None, "code": code}
        }).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(error_body)))
        self.end_headers()
        self.wfile.write(error_body)

    def _handle_chat_completions(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)
        request = json.loads(body)

        if "chat_template" in request:
            self._send_json_error(
                400,
                "Chat template is passed with request, but --trust-request-chat-template is not set. Refused request with untrusted chat template.",
                "BadRequestError",
            )
            return

        messages = request.get("messages", [])
        last_message = messages[-1]["content"] if messages else ""

        if request.get("stream", False):
            self._handle_streaming(last_message)
        else:
            self._handle_non_streaming(last_message)

    def _handle_streaming(self, last_message: str):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        completion_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
        created = int(time.time())
        response_text = f"Fake response to: {last_message}"

        for word in response_text.split(" "):
            chunk = {
                "id": completion_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": self.model_name,
                "choices": [
                    {
                        "index": 0,
                        "delta": {"content": word + " "},
                        "finish_reason": None,
                    }
                ],
            }
            self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
            self.wfile.flush()

        done_chunk = {
            "id": completion_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": self.model_name,
            "choices": [
                {
                    "index": 0,
                    "delta": {},
                    "finish_reason": "stop",
                }
            ],
        }
        self.wfile.write(f"data: {json.dumps(done_chunk)}\n\n".encode())
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()

    def _handle_non_streaming(self, last_message: str):
        response = {
            "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": self.model_name,
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": f"Fake response to: {last_message}",
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": len(last_message.split()),
                "completion_tokens": 10,
                "total_tokens": len(last_message.split()) + 10,
            },
        }

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(response).encode())


class FakeVllmServer:
    def __init__(self, model_name: str, host: str, port: int):
        self._model_name = model_name
        self._host = host
        self._port = port
        self._server: HTTPServer | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        handler = type(
            "Handler",
            (VllmHandler,),
            {"model_name": self._model_name},
        )
        self._server = HTTPServer((self._host, self._port), handler)
        self._thread = threading.Thread(target=self._server.serve_forever)
        self._thread.daemon = True
        self._thread.start()

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server = None
        if self._thread:
            self._thread.join(timeout=1)
            self._thread = None

    @property
    def is_running(self) -> bool:
        return self._server is not None
