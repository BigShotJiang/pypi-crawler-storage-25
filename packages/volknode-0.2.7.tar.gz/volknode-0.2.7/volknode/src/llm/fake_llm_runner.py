from volknode.src.llm.allowed_models import ALLOWED_MODELS, ModelNotAllowedError
from volknode.src.llm.fake_vllm_server import FakeVllmServer
from volknode.src.llm.llm_runner import LlmRunner
from volknode.src.llm.pulled_model_info import PulledModelInfo

class FakeLlmRunner(LlmRunner):
    def __init__(self):
        self._pulled_models: list[str] = []
        self._server: FakeVllmServer | None = None

    def pull_model(self, model_name: str) -> PulledModelInfo:
        if model_name not in ALLOWED_MODELS:
            raise ModelNotAllowedError(model_name)
        self._pulled_models.append(model_name)
        return ALLOWED_MODELS[model_name]

    def run_pulled_model(self, model_name: str, host: str, port: int) -> None:
        self._server = FakeVllmServer(model_name, host, port)
        self._server.start()

    def stop(self) -> None:
        if self._server:
            self._server.stop()
            self._server = None

    @property
    def pulled_models(self) -> list[str]:
        return self._pulled_models

    @property
    def is_running(self) -> bool:
        return self._server is not None and self._server.is_running
