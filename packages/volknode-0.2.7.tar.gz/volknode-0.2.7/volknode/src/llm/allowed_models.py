from volknode.src.llm.pulled_model_info import PulledModelInfo

ALLOWED_MODELS: dict[str, PulledModelInfo] = {
    "hf-internal-testing/tiny-random-gpt2": PulledModelInfo(
        name="hf-internal-testing/tiny-random-gpt2",
        context_window=512,
        quantization="f32",
        supports_chat_completions=False,
    ),
    "gpt2": PulledModelInfo(
        name="gpt2",
        context_window=1024,
        quantization="f32",
        supports_chat_completions=False,
    ),
    "Qwen/Qwen2.5-1.5B-Instruct": PulledModelInfo(
        name="Qwen/Qwen2.5-1.5B-Instruct",
        context_window=32768,
        quantization="f16",
        supports_chat_completions=True,
    ),
}

CHAT_MODELS: dict[str, PulledModelInfo] = {
    k: v for k, v in ALLOWED_MODELS.items() if v.supports_chat_completions
}

BASE_MODELS: dict[str, PulledModelInfo] = {
    k: v for k, v in ALLOWED_MODELS.items() if not v.supports_chat_completions
}

class ModelNotAllowedError(Exception):
    def __init__(self, model_name: str):
        self.model_name = model_name
        super().__init__(f"Model '{model_name}' is not in the allowed models list")
