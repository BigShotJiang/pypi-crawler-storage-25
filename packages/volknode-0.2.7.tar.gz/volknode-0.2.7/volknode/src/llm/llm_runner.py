from abc import ABC, abstractmethod

from volknode.src.llm.pulled_model_info import PulledModelInfo


class LlmRunner(ABC):
    @abstractmethod
    def pull_model(self, model_name: str) -> PulledModelInfo:
        """Pull a model from the registry."""
        pass

    @abstractmethod
    def run_pulled_model(self, model_name: str, host: str, port: int) -> None:
        """Run a previously pulled model."""
        pass
