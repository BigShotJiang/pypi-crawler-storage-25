import os
import subprocess
import time
from pathlib import Path

import requests
from huggingface_hub import snapshot_download

from volknode.src.llm.allowed_models import ALLOWED_MODELS, ModelNotAllowedError
from volknode.src.llm.llm_runner import LlmRunner
from volknode.src.llm.pulled_model_info import PulledModelInfo


class RealLlmRunner(LlmRunner):
    def __init__(self, cache_dir: Path):
        self._cache_dir = cache_dir
        self._process: subprocess.Popen | None = None
        self._host: str = ""
        self._port: int = 0
        self._setup_environment()

    def _setup_environment(self) -> None:
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        os.environ["XDG_CACHE_HOME"] = str(self._cache_dir)

        hf_home = self._cache_dir / "huggingface"
        hf_home.mkdir(parents=True, exist_ok=True)
        os.environ["HF_HOME"] = str(hf_home)

    def pull_model(self, model_name: str) -> PulledModelInfo:
        if model_name not in ALLOWED_MODELS:
            raise ModelNotAllowedError(model_name)
        snapshot_download(repo_id=model_name)
        return ALLOWED_MODELS[model_name]

    def run_pulled_model(self, model_name: str, host: str, port: int) -> None:
        cmd = [
            "vllm",
            "serve",
            model_name,
            "--host",
            host,
            "--port",
            str(port),
            "--trust-remote-code",
        ]
        self._host = host
        self._port = port
        self._process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        self._wait_for_server_ready()

    def _wait_for_server_ready(self, timeout: int = 300) -> None:
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                response = requests.get(f"http://{self._host}:{self._port}/health")
                if response.status_code == 200:
                    return
            except requests.ConnectionError:
                pass
            if self._process and self._process.poll() is not None:
                stderr_output = ""
                if self._process.stderr:
                    stderr_output = self._process.stderr.read().decode()
                raise RuntimeError(f"vLLM process exited unexpectedly: {stderr_output}")
            time.sleep(1)
        raise TimeoutError(f"vLLM server did not become ready within {timeout} seconds")

    def stop(self) -> None:
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None

    @property
    def is_running(self) -> bool:
        return self._process is not None and self._process.poll() is None
