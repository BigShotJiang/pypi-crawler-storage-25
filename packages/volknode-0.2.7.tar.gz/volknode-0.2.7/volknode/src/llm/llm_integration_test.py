import json
from pathlib import Path

import pytest
import requests

from volknode.src.llm.allowed_models import BASE_MODELS, CHAT_MODELS, ModelNotAllowedError
from volknode.src.llm.fake_llm_runner import FakeLlmRunner
from volknode.src.llm.real_llm_runner import RealLlmRunner


def parse_sse_chunks(response):
    chunks = []
    for line in response.iter_lines(decode_unicode=True):
        if line.startswith("data: "):
            data = line[len("data: "):]
            if data == "[DONE]":
                break
            chunks.append(json.loads(data))
    return chunks


@pytest.fixture
def temp_cache_dir(tmp_path: Path) -> Path:
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    return cache_dir


class TestPullModelReturnsEquivalentResponse:
    def test_pull_model_returns_equivalent_info_for_allowed_model(
        self, temp_cache_dir: Path
    ):
        model_name = next(iter(BASE_MODELS))
        expected_info = BASE_MODELS[model_name]

        real_llm_runner = RealLlmRunner(cache_dir=temp_cache_dir)
        fake_llm_runner = FakeLlmRunner()

        real_result = real_llm_runner.pull_model(model_name)
        fake_result = fake_llm_runner.pull_model(model_name)

        assert real_result.name == fake_result.name == model_name
        assert real_result.context_window == fake_result.context_window == expected_info.context_window

    def test_pull_model_raises_error_for_disallowed_model(
        self, temp_cache_dir: Path
    ):
        model_name = "some-org/not-allowed-model"

        real_llm_runner = RealLlmRunner(cache_dir=temp_cache_dir)
        fake_llm_runner = FakeLlmRunner()

        with pytest.raises(ModelNotAllowedError):
            real_llm_runner.pull_model(model_name)

        with pytest.raises(ModelNotAllowedError):
            fake_llm_runner.pull_model(model_name)



class TestVllmServerReturnsEquivalentBehavior:
    def test_real_and_fake_vllm_return_equivalent_chat_completion_response(
        self, temp_cache_dir: Path
    ):
        model_name = next(iter(CHAT_MODELS))
        host = "127.0.0.1"
        real_port = 18080
        fake_port = 18081

        real_llm_runner = RealLlmRunner(cache_dir=temp_cache_dir)
        fake_llm_runner = FakeLlmRunner()

        real_llm_runner.pull_model(model_name)
        fake_llm_runner.pull_model(model_name)

        real_llm_runner.run_pulled_model(model_name, host, real_port)
        fake_llm_runner.run_pulled_model(model_name, host, fake_port)

        try:
            assert real_llm_runner.is_running
            assert fake_llm_runner.is_running

            request_payload = {
                "model": model_name,
                "messages": [{"role": "user", "content": "Hello"}],
            }

            real_response = requests.post(
                f"http://{host}:{real_port}/v1/chat/completions",
                json=request_payload,
            )
            fake_response = requests.post(
                f"http://{host}:{fake_port}/v1/chat/completions",
                json=request_payload,
            )

            assert real_response.status_code == 200, f"Real vLLM returned {real_response.status_code}: {real_response.text}"
            assert fake_response.status_code == 200, f"Fake vLLM returned {fake_response.status_code}: {fake_response.text}"

            real_data = real_response.json()
            fake_data = fake_response.json()

            assert real_data["model"] == fake_data["model"] == model_name
            assert len(real_data["choices"]) == len(fake_data["choices"]) == 1
            assert (
                real_data["choices"][0]["message"]["role"]
                == fake_data["choices"][0]["message"]["role"]
                == "assistant"
            )
            assert "content" in real_data["choices"][0]["message"]
            assert "content" in fake_data["choices"][0]["message"]

        finally:
            real_llm_runner.stop()
            fake_llm_runner.stop()

    def test_real_and_fake_vllm_return_equivalent_multi_turn_conversation(
        self, temp_cache_dir: Path
    ):
        model_name = next(iter(CHAT_MODELS))
        host = "127.0.0.1"
        real_port = 18084
        fake_port = 18085

        real_llm_runner = RealLlmRunner(cache_dir=temp_cache_dir)
        fake_llm_runner = FakeLlmRunner()

        real_llm_runner.pull_model(model_name)
        fake_llm_runner.pull_model(model_name)

        real_llm_runner.run_pulled_model(model_name, host, real_port)
        fake_llm_runner.run_pulled_model(model_name, host, fake_port)

        real_url = f"http://{host}:{real_port}/v1/chat/completions"
        fake_url = f"http://{host}:{fake_port}/v1/chat/completions"

        try:
            messages = [{"role": "user", "content": "Hello, what is your name?"}]

            # Turn 1
            real_resp_1 = requests.post(real_url, json={"model": model_name, "messages": messages})
            fake_resp_1 = requests.post(fake_url, json={"model": model_name, "messages": messages})

            assert real_resp_1.status_code == 200, f"Real vLLM returned {real_resp_1.status_code}: {real_resp_1.text}"
            assert fake_resp_1.status_code == 200, f"Fake vLLM returned {fake_resp_1.status_code}: {fake_resp_1.text}"

            real_assistant_1 = real_resp_1.json()["choices"][0]["message"]
            fake_assistant_1 = fake_resp_1.json()["choices"][0]["message"]

            assert real_assistant_1["role"] == fake_assistant_1["role"] == "assistant"
            assert "content" in real_assistant_1
            assert "content" in fake_assistant_1

            # Turn 2: include previous assistant response in history
            messages.append(real_assistant_1)
            messages.append({"role": "user", "content": "Tell me more about that."})

            real_resp_2 = requests.post(real_url, json={"model": model_name, "messages": messages})
            fake_resp_2 = requests.post(fake_url, json={"model": model_name, "messages": messages})

            assert real_resp_2.status_code == 200, f"Real vLLM returned {real_resp_2.status_code}: {real_resp_2.text}"
            assert fake_resp_2.status_code == 200, f"Fake vLLM returned {fake_resp_2.status_code}: {fake_resp_2.text}"

            real_assistant_2 = real_resp_2.json()["choices"][0]["message"]
            fake_assistant_2 = fake_resp_2.json()["choices"][0]["message"]

            assert real_assistant_2["role"] == fake_assistant_2["role"] == "assistant"
            assert "content" in real_assistant_2
            assert "content" in fake_assistant_2

            # Turn 3: full 3-turn history
            messages.append(real_assistant_2)
            messages.append({"role": "user", "content": "Can you summarize everything?"})

            real_resp_3 = requests.post(real_url, json={"model": model_name, "messages": messages})
            fake_resp_3 = requests.post(fake_url, json={"model": model_name, "messages": messages})

            assert real_resp_3.status_code == 200, f"Real vLLM returned {real_resp_3.status_code}: {real_resp_3.text}"
            assert fake_resp_3.status_code == 200, f"Fake vLLM returned {fake_resp_3.status_code}: {fake_resp_3.text}"

            real_assistant_3 = real_resp_3.json()["choices"][0]["message"]
            fake_assistant_3 = fake_resp_3.json()["choices"][0]["message"]

            assert real_assistant_3["role"] == fake_assistant_3["role"] == "assistant"
            assert "content" in real_assistant_3
            assert "content" in fake_assistant_3

        finally:
            real_llm_runner.stop()
            fake_llm_runner.stop()

    def test_real_and_fake_vllm_return_equivalent_streaming_response(
        self, temp_cache_dir: Path
    ):
        model_name = next(iter(CHAT_MODELS))
        host = "127.0.0.1"
        real_port = 18086
        fake_port = 18087

        real_llm_runner = RealLlmRunner(cache_dir=temp_cache_dir)
        fake_llm_runner = FakeLlmRunner()

        real_llm_runner.pull_model(model_name)
        fake_llm_runner.pull_model(model_name)

        real_llm_runner.run_pulled_model(model_name, host, real_port)
        fake_llm_runner.run_pulled_model(model_name, host, fake_port)

        try:
            assert real_llm_runner.is_running
            assert fake_llm_runner.is_running

            request_payload = {
                "model": model_name,
                "messages": [{"role": "user", "content": "Hello"}],
                "stream": True,
            }

            real_response = requests.post(
                f"http://{host}:{real_port}/v1/chat/completions",
                json=request_payload,
                stream=True,
            )
            fake_response = requests.post(
                f"http://{host}:{fake_port}/v1/chat/completions",
                json=request_payload,
                stream=True,
            )

            assert real_response.status_code == 200, f"Real vLLM returned {real_response.status_code}: {real_response.text}"
            assert fake_response.status_code == 200, f"Fake vLLM returned {fake_response.status_code}: {fake_response.text}"

            real_chunks = parse_sse_chunks(real_response)
            fake_chunks = parse_sse_chunks(fake_response)

            assert len(real_chunks) > 0
            assert len(fake_chunks) > 0

            for real_chunk in real_chunks:
                assert real_chunk["object"] == "chat.completion.chunk"
                assert real_chunk["model"] == model_name
                assert len(real_chunk["choices"]) == 1
                assert "delta" in real_chunk["choices"][0]

            for fake_chunk in fake_chunks:
                assert fake_chunk["object"] == "chat.completion.chunk"
                assert fake_chunk["model"] == model_name
                assert len(fake_chunk["choices"]) == 1
                assert "delta" in fake_chunk["choices"][0]

            real_last = real_chunks[-1]
            fake_last = fake_chunks[-1]
            assert real_last["choices"][0]["finish_reason"] == "stop"
            assert fake_last["choices"][0]["finish_reason"] == "stop"

            real_content = "".join(
                c["choices"][0]["delta"].get("content", "") for c in real_chunks
            )
            fake_content = "".join(
                c["choices"][0]["delta"].get("content", "") for c in fake_chunks
            )
            assert len(real_content) > 0
            assert len(fake_content) > 0

        finally:
            real_llm_runner.stop()
            fake_llm_runner.stop()

    def test_real_and_fake_vllm_stop_server(self, temp_cache_dir: Path):
        model_name = next(iter(CHAT_MODELS))
        host = "127.0.0.1"
        real_port = 18082
        fake_port = 18083

        real_llm_runner = RealLlmRunner(cache_dir=temp_cache_dir)
        fake_llm_runner = FakeLlmRunner()

        real_llm_runner.pull_model(model_name)
        fake_llm_runner.pull_model(model_name)

        real_llm_runner.run_pulled_model(model_name, host, real_port)
        fake_llm_runner.run_pulled_model(model_name, host, fake_port)

        assert real_llm_runner.is_running
        assert fake_llm_runner.is_running

        real_llm_runner.stop()
        fake_llm_runner.stop()

        assert not real_llm_runner.is_running
        assert not fake_llm_runner.is_running


class TestChatTemplateRejection:
    def test_real_and_fake_reject_requests_with_chat_template(self, temp_cache_dir: Path):
        model_name = next(iter(CHAT_MODELS))
        host = "127.0.0.1"
        real_port = 18090
        fake_port = 18091

        real_llm_runner = RealLlmRunner(cache_dir=temp_cache_dir)
        fake_llm_runner = FakeLlmRunner()

        real_llm_runner.pull_model(model_name)
        fake_llm_runner.pull_model(model_name)

        real_llm_runner.run_pulled_model(model_name, host, real_port)
        fake_llm_runner.run_pulled_model(model_name, host, fake_port)

        try:
            request_payload = {
                "model": model_name,
                "messages": [{"role": "user", "content": "Hello"}],
                "chat_template": "{% for message in messages %}{{ message['content'] }}{% endfor %}",
            }

            real_response = requests.post(
                f"http://{host}:{real_port}/v1/chat/completions",
                json=request_payload,
            )
            fake_response = requests.post(
                f"http://{host}:{fake_port}/v1/chat/completions",
                json=request_payload,
            )

            assert real_response.status_code == 400, f"Real vLLM should reject chat_template, got {real_response.status_code}: {real_response.text}"
            assert fake_response.status_code == 400, f"Fake vLLM should reject chat_template, got {fake_response.status_code}: {fake_response.text}"
        finally:
            real_llm_runner.stop()
            fake_llm_runner.stop()
