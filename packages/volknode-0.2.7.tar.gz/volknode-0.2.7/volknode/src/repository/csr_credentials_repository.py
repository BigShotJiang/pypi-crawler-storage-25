import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from volknode.src.domain.csr_credentials import CsrCredentials


class CsrCredentialsRepository:
    def __init__(self, db_path: Path):
        self._db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS csr_credentials (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    private_key_pem TEXT NOT NULL,
                    csr_pem TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
            """)
            conn.commit()

    def save(self, credentials: CsrCredentials) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                INSERT INTO csr_credentials (private_key_pem, csr_pem, created_at)
                VALUES (?, ?, ?)
                """,
                (credentials.private_key_pem, credentials.csr_pem, datetime.now(timezone.utc).isoformat()),
            )
            conn.commit()

    def find_latest(self) -> CsrCredentials | None:
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute(
                "SELECT private_key_pem, csr_pem FROM csr_credentials ORDER BY id DESC LIMIT 1"
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return CsrCredentials(private_key_pem=row[0], csr_pem=row[1])
