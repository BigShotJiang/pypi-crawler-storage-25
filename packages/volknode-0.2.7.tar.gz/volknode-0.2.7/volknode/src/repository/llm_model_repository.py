import sqlite3
from pathlib import Path

from volknode.src.domain.llm_model import LlmModel


class LlmModelRepository:
    def __init__(self, db_path: Path):
        self._db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS llm_models (
                    name TEXT PRIMARY KEY,
                    context_window INTEGER NOT NULL,
                    quantization TEXT NOT NULL,
                    running INTEGER NOT NULL DEFAULT 0
                )
            """)
            conn.commit()

    def save(self, model: LlmModel) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO llm_models (name, context_window, quantization, running)
                VALUES (?, ?, ?, ?)
                """,
                (model.name, model.context_window, model.quantization, int(model.running)),
            )
            conn.commit()

    def find_by_name(self, name: str) -> LlmModel | None:
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute(
                "SELECT name, context_window, quantization, running FROM llm_models WHERE name = ?",
                (name,),
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return LlmModel(name=row[0], context_window=row[1], quantization=row[2], running=bool(row[3]))

    def find_all(self) -> list[LlmModel]:
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute("SELECT name, context_window, quantization, running FROM llm_models")
            return [LlmModel(name=row[0], context_window=row[1], quantization=row[2], running=bool(row[3])) for row in cursor.fetchall()]

    def find_running(self) -> LlmModel | None:
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute(
                "SELECT name, context_window, quantization, running FROM llm_models WHERE running = 1 LIMIT 1"
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return LlmModel(name=row[0], context_window=row[1], quantization=row[2], running=bool(row[3]))

    def update(self, model: LlmModel) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                UPDATE llm_models SET context_window = ?, quantization = ?, running = ?
                WHERE name = ?
                """,
                (model.context_window, model.quantization, int(model.running), model.name),
            )
            conn.commit()
