import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from volknode.src.domain.nexus_certificate import NexusCertificate


class NexusCertificateRepository:
    def __init__(self, db_path: Path):
        self._db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS nexus_certificate (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    certificate_pem TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
            """)
            conn.commit()

    def save(self, cert: NexusCertificate) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                INSERT INTO nexus_certificate (certificate_pem, created_at)
                VALUES (?, ?)
                """,
                (cert.certificate_pem, datetime.now(timezone.utc).isoformat()),
            )
            conn.commit()

    def find_latest(self) -> NexusCertificate | None:
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute(
                "SELECT certificate_pem FROM nexus_certificate ORDER BY id DESC LIMIT 1"
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return NexusCertificate(certificate_pem=row[0])
