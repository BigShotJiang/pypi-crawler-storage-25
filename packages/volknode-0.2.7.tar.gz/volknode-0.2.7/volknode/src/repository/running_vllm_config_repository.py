import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from volknode.src.domain.running_vllm_config import RunningVllmConfig


class RunningVllmConfigRepository:
    def __init__(self, db_path: Path):
        self._db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS running_vllm_config (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    host TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    created_at TEXT NOT NULL
                )
            """)
            conn.commit()

    def save(self, config: RunningVllmConfig) -> None:
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                """
                INSERT INTO running_vllm_config (host, port, created_at)
                VALUES (?, ?, ?)
                """,
                (config.host, config.port, datetime.now(timezone.utc).isoformat()),
            )
            conn.commit()

    def find_latest(self) -> RunningVllmConfig | None:
        with sqlite3.connect(self._db_path) as conn:
            cursor = conn.execute(
                "SELECT host, port FROM running_vllm_config ORDER BY id DESC LIMIT 1"
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return RunningVllmConfig(host=row[0], port=row[1])
