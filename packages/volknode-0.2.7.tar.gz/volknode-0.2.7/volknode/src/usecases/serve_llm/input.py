from dataclasses import dataclass

from volknode.src.core.validation import Validation


@dataclass
class ServeLlmInput:
    port: int
    test_cert_pem: str | None = None
    test_priv_key_pem: str | None = None
    test_ca_cert_pem: str | None = None

    @staticmethod
    def create(
        port: int,
        test_cert_pem: str | None = None,
        test_priv_key_pem: str | None = None,
        test_ca_cert_pem: str | None = None,
    ) -> tuple["ServeLlmInput | None", Validation]:
        validation = Validation()

        if port <= 0:
            validation.add_error("port must be greater than 0")

        test_params = [test_cert_pem, test_priv_key_pem, test_ca_cert_pem]
        provided_count = sum(1 for p in test_params if p is not None)
        if provided_count > 0 and provided_count < 3:
            validation.add_error("--with-test-cert-pem, --with-test-priv-key-pem, and --with-test-ca-cert-pem must all be provided together")

        if validation.has_errors():
            return None, validation

        return ServeLlmInput(
            port=port,
            test_cert_pem=test_cert_pem,
            test_priv_key_pem=test_priv_key_pem,
            test_ca_cert_pem=test_ca_cert_pem,
        ), validation
