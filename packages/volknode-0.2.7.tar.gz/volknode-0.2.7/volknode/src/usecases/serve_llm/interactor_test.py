import socket
from pathlib import Path

import pytest

from volknode.src.llm.fake_llm_runner import FakeLlmRunner
from volknode.src.mtls.mtls_client import MtlsClient
from volknode.src.mtls.mtls_reverse_proxy import MtlsReverseProxy
from volknode.src.nexus.fake_nexus import FakeNexus
from volknode.src.repository import CsrCredentialsRepository, LlmModelRepository, LlmNodeCertificateRepository, NexusCertificateRepository, RunningVllmConfigRepository
from volknode.src.usecases.pull_model.input import PullModelInput
from volknode.src.usecases.pull_model.interactor import PullModelInteractor
from volknode.src.usecases.register_llm_node.input import RegisterLlmNodeInput
from volknode.src.usecases.register_llm_node.interactor import RegisterLlmNodeInteractor
from volknode.src.usecases.run_llm_node.input import RunLlmNodeInput
from volknode.src.usecases.run_llm_node.interactor import RunLlmNodeInteractor
from volknode.src.usecases.serve_llm.input import ServeLlmInput
from volknode.src.usecases.serve_llm.interactor import ServeLlmInteractor


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _make_repos(db_path):
    return (
        LlmModelRepository(db_path),
        CsrCredentialsRepository(db_path),
        LlmNodeCertificateRepository(db_path),
        NexusCertificateRepository(db_path),
        RunningVllmConfigRepository(db_path),
    )


def _make_serve_llm_interactor(db_path):
    llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo = _make_repos(db_path)
    interactor = ServeLlmInteractor(
        csr_credentials_repository=csr_repo,
        llm_node_certificate_repository=llm_node_cert_repo,
        nexus_certificate_repository=nexus_cert_repo,
        running_vllm_config_repository=vllm_config_repo,
        mtls_reverse_proxy=MtlsReverseProxy(),
    )
    return interactor, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo


def _pull_and_run_model(fake_llm, llm_model_repo, running_vllm_config_repo, model_name="gpt2"):
    pull_input, _ = PullModelInput.create(model_name)
    PullModelInteractor(fake_llm, llm_model_repo).execute(pull_input)

    run_input, _ = RunLlmNodeInput.create(model_name)
    RunLlmNodeInteractor(fake_llm, llm_model_repo, running_vllm_config_repo).execute(run_input)


def _register_node(fake_llm, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo, proxy_port):
    fake_nexus = FakeNexus()
    register_interactor = RegisterLlmNodeInteractor(
        nexus=fake_nexus,
        llm_model_repository=llm_model_repo,
        csr_credentials_repository=csr_repo,
        llm_node_certificate_repository=llm_node_cert_repo,
        nexus_certificate_repository=nexus_cert_repo,
    )

    register_input, _ = RegisterLlmNodeInput.create(
        url=f"https://localhost:{proxy_port}",
        personal_access_token="some-token",
        llm_model_name="integration-node",
    )

    return register_interactor.execute(register_input)


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "test.db"


class TestServeLlmInteractor:
    def test_forwards_requests_to_vllm(self, db_path: Path):
        proxy_port = _find_free_port()
        fake_llm = FakeLlmRunner()
        serve_interactor, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo = _make_serve_llm_interactor(db_path)

        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)
        registration = _register_node(fake_llm, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo, proxy_port)

        serve_input, _ = ServeLlmInput.create(proxy_port)

        try:
            serve_interactor.execute(serve_input)

            csr_credentials = csr_repo.find_latest()
            mtls_client = MtlsClient(
                certificate_pem=registration.certificate,
                private_key_pem=csr_credentials.private_key_pem,
                ca_certificate_pem=registration.ca_certificate,
            )

            response = mtls_client.post(
                f"https://localhost:{proxy_port}/v1/chat/completions",
                {"model": "gpt2", "messages": [{"role": "user", "content": "Hello"}]},
            )

            assert response["model"] == "gpt2"
            assert response["choices"][0]["message"]["content"] == "Fake response to: Hello"
        finally:
            fake_llm.stop()

    def test_raises_error_when_no_csr_credentials(self, db_path: Path):
        serve_interactor, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo = _make_serve_llm_interactor(db_path)

        serve_input, _ = ServeLlmInput.create(_find_free_port())

        with pytest.raises(RuntimeError, match="No CSR credentials found"):
            serve_interactor.execute(serve_input)

    def test_raises_error_when_no_node_certificate(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        serve_interactor, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo = _make_serve_llm_interactor(db_path)

        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        # Manually save CSR credentials without registering (no node certificate)
        from volknode.src.domain.csr_credentials import CsrCredentials
        csr_repo.save(CsrCredentials(private_key_pem="fake-key", csr_pem="fake-csr"))

        serve_input, _ = ServeLlmInput.create(_find_free_port())

        try:
            with pytest.raises(RuntimeError, match="No node certificate found"):
                serve_interactor.execute(serve_input)
        finally:
            fake_llm.stop()

    def test_raises_error_when_no_nexus_certificate(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        serve_interactor, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo = _make_serve_llm_interactor(db_path)

        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        from volknode.src.domain.csr_credentials import CsrCredentials
        from volknode.src.domain.llm_node_certificate import LlmNodeCertificate
        csr_repo.save(CsrCredentials(private_key_pem="fake-key", csr_pem="fake-csr"))
        llm_node_cert_repo.save(LlmNodeCertificate(certificate_pem="fake-cert"))

        serve_input, _ = ServeLlmInput.create(_find_free_port())

        try:
            with pytest.raises(RuntimeError, match="No nexus certificate found"):
                serve_interactor.execute(serve_input)
        finally:
            fake_llm.stop()

    def test_raises_error_when_no_vllm_config(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        serve_interactor, llm_model_repo, csr_repo, llm_node_cert_repo, nexus_cert_repo, vllm_config_repo = _make_serve_llm_interactor(db_path)

        from volknode.src.domain.csr_credentials import CsrCredentials
        from volknode.src.domain.llm_node_certificate import LlmNodeCertificate
        from volknode.src.domain.nexus_certificate import NexusCertificate
        csr_repo.save(CsrCredentials(private_key_pem="fake-key", csr_pem="fake-csr"))
        llm_node_cert_repo.save(LlmNodeCertificate(certificate_pem="fake-cert"))
        nexus_cert_repo.save(NexusCertificate(certificate_pem="fake-ca-cert"))

        serve_input, _ = ServeLlmInput.create(_find_free_port())

        try:
            with pytest.raises(RuntimeError, match="No running vLLM config found"):
                serve_interactor.execute(serve_input)
        finally:
            fake_llm.stop()
