from volknode.src.usecases.serve_llm.input import ServeLlmInput


class TestServeLlmInput:
    def test_valid_with_no_test_certs(self):
        input_data, validation = ServeLlmInput.create(8080)
        assert not validation.has_errors()
        assert input_data.test_cert_pem is None
        assert input_data.test_priv_key_pem is None
        assert input_data.test_ca_cert_pem is None

    def test_valid_with_all_test_certs(self):
        input_data, validation = ServeLlmInput.create(
            8080,
            test_cert_pem="cert",
            test_priv_key_pem="key",
            test_ca_cert_pem="ca",
        )
        assert not validation.has_errors()
        assert input_data.test_cert_pem == "cert"
        assert input_data.test_priv_key_pem == "key"
        assert input_data.test_ca_cert_pem == "ca"

    def test_invalid_when_only_cert_pem_provided(self):
        _, validation = ServeLlmInput.create(8080, test_cert_pem="cert")
        assert validation.has_errors()
        assert "--with-test-cert-pem, --with-test-priv-key-pem, and --with-test-ca-cert-pem must all be provided together" in validation.errors()

    def test_invalid_when_only_priv_key_pem_provided(self):
        _, validation = ServeLlmInput.create(8080, test_priv_key_pem="key")
        assert validation.has_errors()
        assert "--with-test-cert-pem, --with-test-priv-key-pem, and --with-test-ca-cert-pem must all be provided together" in validation.errors()

    def test_invalid_when_only_ca_cert_pem_provided(self):
        _, validation = ServeLlmInput.create(8080, test_ca_cert_pem="ca")
        assert validation.has_errors()
        assert "--with-test-cert-pem, --with-test-priv-key-pem, and --with-test-ca-cert-pem must all be provided together" in validation.errors()

    def test_invalid_when_two_of_three_provided(self):
        _, validation = ServeLlmInput.create(8080, test_cert_pem="cert", test_priv_key_pem="key")
        assert validation.has_errors()
        assert "--with-test-cert-pem, --with-test-priv-key-pem, and --with-test-ca-cert-pem must all be provided together" in validation.errors()
