from volknode.src.mtls.mtls_reverse_proxy import MtlsReverseProxy
from volknode.src.repository import CsrCredentialsRepository, LlmNodeCertificateRepository, NexusCertificateRepository, RunningVllmConfigRepository
from volknode.src.usecases.serve_llm.input import ServeLlmInput


class ServeLlmInteractor:
    def __init__(
        self,
        csr_credentials_repository: CsrCredentialsRepository,
        llm_node_certificate_repository: LlmNodeCertificateRepository,
        nexus_certificate_repository: NexusCertificateRepository,
        running_vllm_config_repository: RunningVllmConfigRepository,
        mtls_reverse_proxy: MtlsReverseProxy,
    ):
        self._csr_credentials_repository = csr_credentials_repository
        self._llm_node_certificate_repository = llm_node_certificate_repository
        self._nexus_certificate_repository = nexus_certificate_repository
        self._running_vllm_config_repository = running_vllm_config_repository
        self._mtls_reverse_proxy = mtls_reverse_proxy

    def execute(self, input: ServeLlmInput) -> None:
        csr_credentials = self._csr_credentials_repository.find_latest()
        if csr_credentials is None:
            raise RuntimeError("No CSR credentials found. Register the LLM node first.")

        node_certificate = self._llm_node_certificate_repository.find_latest()
        if node_certificate is None:
            raise RuntimeError("No node certificate found. Register the LLM node first.")

        nexus_certificate = self._nexus_certificate_repository.find_latest()
        if nexus_certificate is None:
            raise RuntimeError("No nexus certificate found. Register the LLM node first.")

        vllm_config = self._running_vllm_config_repository.find_latest()
        if vllm_config is None:
            raise RuntimeError("No running vLLM config found. Run a model first.")

        self._mtls_reverse_proxy.start(
            private_key_pem=csr_credentials.private_key_pem,
            certificate_pem=node_certificate.certificate_pem,
            ca_certificate_pem=nexus_certificate.certificate_pem,
            listen_host="0.0.0.0",
            listen_port=input.port,
            upstream_url=f"http://{vllm_config.host}:{vllm_config.port}",
        )
