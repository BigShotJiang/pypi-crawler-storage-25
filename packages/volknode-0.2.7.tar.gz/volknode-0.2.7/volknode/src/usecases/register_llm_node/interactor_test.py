import socket
from pathlib import Path

import pytest

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.x509 import ObjectIdentifier

from volknode.src.llm.fake_llm_runner import FakeLlmRunner
from volknode.src.nexus.fake_nexus import FakeNexus
from volknode.src.repository import CsrCredentialsRepository, LlmModelRepository, LlmNodeCertificateRepository, NexusCertificateRepository, RunningVllmConfigRepository
from volknode.src.usecases.pull_model.input import PullModelInput
from volknode.src.usecases.pull_model.interactor import PullModelInteractor
from volknode.src.usecases.register_llm_node.input import RegisterLlmNodeInput
from volknode.src.usecases.register_llm_node.interactor import RegisterLlmNodeInteractor
from volknode.src.usecases.run_llm_node.input import RunLlmNodeInput
from volknode.src.usecases.run_llm_node.interactor import RunLlmNodeInteractor

_OID_LLM_MODEL_NAME = ObjectIdentifier("1.3.6.1.4.1.99999.1.1")
_OID_LLM_NODE_MODEL_ID = ObjectIdentifier("1.3.6.1.4.1.99999.1.2")
_OID_LLM_NODE_MODEL_CONTEXT_WINDOW = ObjectIdentifier("1.3.6.1.4.1.99999.1.5")
_OID_LLM_NODE_LLM_NODE_URL = ObjectIdentifier("1.3.6.1.4.1.99999.1.10")


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _get_subject_attr(subject: x509.Name, oid: ObjectIdentifier) -> str:
    attrs = subject.get_attributes_for_oid(oid)
    assert len(attrs) == 1
    return attrs[0].value


def _make_interactor(db_path, fake_nexus=None):
    fake_llm = FakeLlmRunner()
    llm_model_repository = LlmModelRepository(db_path)
    csr_credentials_repository = CsrCredentialsRepository(db_path)
    llm_node_certificate_repository = LlmNodeCertificateRepository(db_path)
    nexus_certificate_repository = NexusCertificateRepository(db_path)
    running_vllm_config_repository = RunningVllmConfigRepository(db_path)
    if fake_nexus is None:
        fake_nexus = FakeNexus()
    interactor = RegisterLlmNodeInteractor(
        nexus=fake_nexus,
        llm_model_repository=llm_model_repository,
        csr_credentials_repository=csr_credentials_repository,
        llm_node_certificate_repository=llm_node_certificate_repository,
        nexus_certificate_repository=nexus_certificate_repository,
    )
    return interactor, fake_nexus, fake_llm, llm_model_repository, csr_credentials_repository, llm_node_certificate_repository, nexus_certificate_repository, running_vllm_config_repository


def _pull_and_run_model(fake_llm, llm_model_repository, running_vllm_config_repository, model_name="gpt2"):
    pull_input, _ = PullModelInput.create(model_name)
    PullModelInteractor(fake_llm, llm_model_repository).execute(pull_input)

    run_input, _ = RunLlmNodeInput.create(model_name)
    RunLlmNodeInteractor(fake_llm, llm_model_repository, running_vllm_config_repository).execute(run_input)


def _make_input(
    url=None,
    personal_access_token="some-token",
    llm_model_name="my-llm-node",
):
    if url is None:
        url = f"https://localhost:{_find_free_port()}"
    input_data, _ = RegisterLlmNodeInput.create(
        url=url,
        personal_access_token=personal_access_token,
        llm_model_name=llm_model_name,
    )
    return input_data


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "test.db"


class TestRegisterLlmNodeInteractor:
    def test_generates_csr_stores_credentials_and_registers(self, db_path: Path):
        interactor, fake_nexus, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        registration = interactor.execute(_make_input())

        assert len(fake_nexus.registered_llm_nodes) == 1
        assert registration.model_name == "my-llm-node"

        csr_credentials = csr_repo.find_latest()
        assert csr_credentials is not None
        assert "BEGIN RSA PRIVATE KEY" in csr_credentials.private_key_pem
        assert "BEGIN CERTIFICATE REQUEST" in csr_credentials.csr_pem

        fake_llm.stop()

    def test_raises_error_when_no_running_model(self, db_path: Path):
        interactor, _, _, _, _, _, _, _ = _make_interactor(db_path)

        with pytest.raises(RuntimeError, match="No running model found"):
            interactor.execute(_make_input())

    def test_csr_contains_llm_model_name_from_input(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        interactor.execute(_make_input(llm_model_name="alpha-node"))

        csr_credentials = csr_repo.find_latest()
        certificate_signing_request = x509.load_pem_x509_csr(csr_credentials.csr_pem.encode("utf-8"))
        assert _get_subject_attr(certificate_signing_request.subject, _OID_LLM_MODEL_NAME) == "alpha-node"

        fake_llm.stop()

    def test_csr_contains_model_name_from_running_model(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo, model_name="Qwen/Qwen2.5-1.5B-Instruct")

        interactor.execute(_make_input())

        csr_credentials = csr_repo.find_latest()
        certificate_signing_request = x509.load_pem_x509_csr(csr_credentials.csr_pem.encode("utf-8"))
        assert _get_subject_attr(certificate_signing_request.subject, _OID_LLM_NODE_MODEL_ID) == "Qwen/Qwen2.5-1.5B-Instruct"

        fake_llm.stop()

    def test_csr_contains_context_window_from_running_model(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo, model_name="Qwen/Qwen2.5-1.5B-Instruct")

        interactor.execute(_make_input())

        csr_credentials = csr_repo.find_latest()
        certificate_signing_request = x509.load_pem_x509_csr(csr_credentials.csr_pem.encode("utf-8"))
        assert _get_subject_attr(certificate_signing_request.subject, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "32768"

        fake_llm.stop()

    def test_csr_contains_llm_node_url_from_input(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        proxy_port = _find_free_port()
        url = f"https://localhost:{proxy_port}"
        interactor.execute(_make_input(url=url))

        csr_credentials = csr_repo.find_latest()
        certificate_signing_request = x509.load_pem_x509_csr(csr_credentials.csr_pem.encode("utf-8"))
        assert _get_subject_attr(certificate_signing_request.subject, _OID_LLM_NODE_LLM_NODE_URL) == url

        fake_llm.stop()

    def test_response_certificate_is_valid_pem_signed_by_ca(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, _, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        registration = interactor.execute(_make_input())

        node_certificate = x509.load_pem_x509_certificate(registration.certificate.encode("utf-8"))
        ca_certificate = x509.load_pem_x509_certificate(registration.ca_certificate.encode("utf-8"))
        assert node_certificate.issuer == ca_certificate.subject

        fake_llm.stop()

    def test_response_certificate_subject_matches_csr(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, _, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo, model_name="Qwen/Qwen2.5-1.5B-Instruct")

        proxy_port = _find_free_port()
        url = f"https://localhost:{proxy_port}"
        registration = interactor.execute(_make_input(
            url=url,
            llm_model_name="prod-node",
        ))

        node_certificate = x509.load_pem_x509_certificate(registration.certificate.encode("utf-8"))
        assert _get_subject_attr(node_certificate.subject, _OID_LLM_MODEL_NAME) == "prod-node"
        assert _get_subject_attr(node_certificate.subject, _OID_LLM_NODE_MODEL_ID) == "Qwen/Qwen2.5-1.5B-Instruct"
        assert _get_subject_attr(node_certificate.subject, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "32768"
        assert _get_subject_attr(node_certificate.subject, _OID_LLM_NODE_LLM_NODE_URL) == url

        fake_llm.stop()

    def test_stored_private_key_matches_certificate_public_key(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        registration = interactor.execute(_make_input())

        csr_credentials = csr_repo.find_latest()
        private_key = serialization.load_pem_private_key(
            csr_credentials.private_key_pem.encode("utf-8"), password=None,
        )
        node_certificate = x509.load_pem_x509_certificate(registration.certificate.encode("utf-8"))

        private_key_public_pem = private_key.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        certificate_public_pem = node_certificate.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        assert private_key_public_pem == certificate_public_pem

        fake_llm.stop()

    def test_each_execution_generates_unique_key_pairs(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        first_registration = interactor.execute(_make_input(llm_model_name="node-1"))
        first_csr_credentials = csr_repo.find_latest()

        second_registration = interactor.execute(_make_input(llm_model_name="node-2"))
        second_csr_credentials = csr_repo.find_latest()

        assert first_csr_credentials.private_key_pem != second_csr_credentials.private_key_pem
        assert first_csr_credentials.csr_pem != second_csr_credentials.csr_pem
        assert first_registration.certificate != second_registration.certificate

        fake_llm.stop()

    def test_uses_running_model_when_multiple_models_exist(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, csr_repo, _, _, vllm_config_repo = _make_interactor(db_path)

        pull_input, _ = PullModelInput.create("gpt2")
        PullModelInteractor(fake_llm, llm_model_repo).execute(pull_input)

        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo, model_name="Qwen/Qwen2.5-1.5B-Instruct")

        interactor.execute(_make_input())

        csr_credentials = csr_repo.find_latest()
        certificate_signing_request = x509.load_pem_x509_csr(csr_credentials.csr_pem.encode("utf-8"))
        assert _get_subject_attr(certificate_signing_request.subject, _OID_LLM_NODE_MODEL_ID) == "Qwen/Qwen2.5-1.5B-Instruct"
        assert _get_subject_attr(certificate_signing_request.subject, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "32768"

        fake_llm.stop()

    def test_does_not_store_credentials_when_no_running_model(self, db_path: Path):
        interactor, _, _, _, csr_repo, _, _, _ = _make_interactor(db_path)

        with pytest.raises(RuntimeError):
            interactor.execute(_make_input())

        assert csr_repo.find_latest() is None

    def test_stores_node_certificate_after_registration(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, _, llm_node_cert_repo, _, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        registration = interactor.execute(_make_input())

        stored_node_certificate = llm_node_cert_repo.find_latest()
        assert stored_node_certificate is not None
        assert stored_node_certificate.certificate_pem == registration.certificate

        fake_llm.stop()

    def test_stores_nexus_certificate_after_registration(self, db_path: Path):
        interactor, _, fake_llm, llm_model_repo, _, _, nexus_cert_repo, vllm_config_repo = _make_interactor(db_path)
        _pull_and_run_model(fake_llm, llm_model_repo, vllm_config_repo)

        registration = interactor.execute(_make_input())

        stored_nexus_certificate = nexus_cert_repo.find_latest()
        assert stored_nexus_certificate is not None
        assert stored_nexus_certificate.certificate_pem == registration.ca_certificate

        fake_llm.stop()

    def test_does_not_store_certificates_when_no_running_model(self, db_path: Path):
        interactor, _, _, _, _, llm_node_cert_repo, nexus_cert_repo, _ = _make_interactor(db_path)

        with pytest.raises(RuntimeError):
            interactor.execute(_make_input())

        assert llm_node_cert_repo.find_latest() is None
        assert nexus_cert_repo.find_latest() is None
