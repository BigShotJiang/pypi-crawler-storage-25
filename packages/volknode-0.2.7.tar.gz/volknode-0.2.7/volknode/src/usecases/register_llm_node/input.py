from dataclasses import dataclass
from urllib.parse import urlparse

from volknode.src.core.validation import Validation


def _validate_url(url: str, param_name: str, validation: Validation) -> None:
    """Validate that a string is a valid URL."""
    parsed = urlparse(url)
    if not parsed.scheme:
        validation.add_error(f"{param_name} must include a scheme (e.g., http:// or https://)")
        return
    if parsed.scheme != "https":
        validation.add_error(f"{param_name} must use https scheme")
        return
    if not parsed.netloc:
        validation.add_error(f"{param_name} must include a host")


def _validate_not_empty(value: str, param_name: str, validation: Validation) -> None:
    """Validate that a string is not empty or whitespace."""
    if not value.strip():
        validation.add_error(f"{param_name} cannot be empty")


@dataclass
class RegisterLlmNodeInput:
    url: str
    personal_access_token: str
    llm_model_name: str

    @staticmethod
    def create(
        url: str,
        personal_access_token: str,
        llm_model_name: str,
    ) -> tuple["RegisterLlmNodeInput | None", Validation]:
        """Validate and create a RegisterLlmNodeInput."""
        validation = Validation()

        _validate_url(url, "--url", validation)
        _validate_not_empty(personal_access_token, "--personal-access-token", validation)
        _validate_not_empty(llm_model_name, "--llm-model-name", validation)

        if validation.has_errors():
            return None, validation

        return RegisterLlmNodeInput(
            url=url,
            personal_access_token=personal_access_token,
            llm_model_name=llm_model_name,
        ), validation
