from volknode.src.csr.csr_service import CsrService, LlmNodeCsr
from volknode.src.csr.key_pair_generator import KeyPairGenerator
from volknode.src.domain.csr_credentials import CsrCredentials
from volknode.src.domain.llm_node_certificate import LlmNodeCertificate
from volknode.src.domain.nexus_certificate import NexusCertificate
from volknode.src.http_client.ai_suite_client.models.register_llm_node_request import RegisterLlmNodeRequest
from volknode.src.http_client.ai_suite_client.models.register_llm_node_response import RegisterLlmNodeResponse
from volknode.src.nexus.nexus import Nexus
from volknode.src.repository import CsrCredentialsRepository, LlmModelRepository, LlmNodeCertificateRepository, NexusCertificateRepository
from volknode.src.usecases.register_llm_node.input import RegisterLlmNodeInput


class RegisterLlmNodeInteractor:
    def __init__(
        self,
        nexus: Nexus,
        llm_model_repository: LlmModelRepository,
        csr_credentials_repository: CsrCredentialsRepository,
        llm_node_certificate_repository: LlmNodeCertificateRepository,
        nexus_certificate_repository: NexusCertificateRepository,
    ):
        self._nexus = nexus
        self._llm_model_repository = llm_model_repository
        self._csr_credentials_repository = csr_credentials_repository
        self._llm_node_certificate_repository = llm_node_certificate_repository
        self._nexus_certificate_repository = nexus_certificate_repository

    def execute(self, input: RegisterLlmNodeInput) -> RegisterLlmNodeResponse:
        running_model = self._llm_model_repository.find_running()
        if running_model is None:
            raise RuntimeError("No running model found. Run a model first.")

        private_key = KeyPairGenerator().generate()

        llm_node_csr = LlmNodeCsr(
            model_name=input.llm_model_name,
            model_id=running_model.name,
            model_quantization=running_model.quantization,
            model_context_window=running_model.context_window,
            llm_node_url=input.url,
        )

        csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

        credentials = CsrCredentials(private_key_pem=private_key.pem, csr_pem=csr_pem)
        self._csr_credentials_repository.save(credentials)

        request = RegisterLlmNodeRequest(
            personal_access_token=input.personal_access_token,
            model_name=input.llm_model_name,
            csr=csr_pem,
            model_id=running_model.name,
            quantization=running_model.quantization,
            context_window=running_model.context_window,
            llm_node_url=input.url,
        )
        response = self._nexus.register_llm_node(request)

        self._llm_node_certificate_repository.save(LlmNodeCertificate(certificate_pem=response.certificate))
        self._nexus_certificate_repository.save(NexusCertificate(certificate_pem=response.ca_certificate))

        return response
