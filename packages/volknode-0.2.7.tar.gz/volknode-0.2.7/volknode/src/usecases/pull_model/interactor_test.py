from pathlib import Path

import pytest

from volknode.src.llm.allowed_models import ModelNotAllowedError
from volknode.src.llm.fake_llm_runner import FakeLlmRunner
from volknode.src.repository import LlmModelRepository
from volknode.src.usecases.pull_model.input import PullModelInput
from volknode.src.usecases.pull_model.interactor import PullModelInteractor


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "test.db"


class TestPullModelInteractor:
    def test_pulls_model_and_saves_to_repository(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        interactor = PullModelInteractor(fake_llm, repository)

        input_data, _ = PullModelInput.create("hf-internal-testing/tiny-random-gpt2")

        result = interactor.execute(input_data)

        assert result.name == "hf-internal-testing/tiny-random-gpt2"
        assert result.context_window == 512

        saved_model = repository.find_by_name("hf-internal-testing/tiny-random-gpt2")
        assert saved_model is not None
        assert saved_model.name == "hf-internal-testing/tiny-random-gpt2"
        assert saved_model.context_window == 512

    def test_raises_error_when_model_not_allowed(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        interactor = PullModelInteractor(fake_llm, repository)

        input_data, _ = PullModelInput.create("not-a-real-model")

        with pytest.raises(ModelNotAllowedError, match="not-a-real-model"):
            interactor.execute(input_data)

        assert repository.find_by_name("not-a-real-model") is None

    def test_pulling_same_model_twice_overwrites_in_repository(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        interactor = PullModelInteractor(fake_llm, repository)

        input_data, _ = PullModelInput.create("gpt2")

        interactor.execute(input_data)
        interactor.execute(input_data)

        all_models = repository.find_all()
        assert len(all_models) == 1
        assert all_models[0].name == "gpt2"

    def test_saves_correct_context_window_for_each_model(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        interactor = PullModelInteractor(fake_llm, repository)

        input_gpt2, _ = PullModelInput.create("gpt2")
        input_qwen, _ = PullModelInput.create("Qwen/Qwen2.5-1.5B-Instruct")

        interactor.execute(input_gpt2)
        interactor.execute(input_qwen)

        gpt2 = repository.find_by_name("gpt2")
        qwen = repository.find_by_name("Qwen/Qwen2.5-1.5B-Instruct")

        assert gpt2.context_window == 1024
        assert qwen.context_window == 32768

