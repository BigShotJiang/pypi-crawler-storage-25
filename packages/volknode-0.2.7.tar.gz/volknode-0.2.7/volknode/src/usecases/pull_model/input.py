from dataclasses import dataclass

from volknode.src.core.validation import Validation


@dataclass
class PullModelInput:
    model_name: str

    @staticmethod
    def create(model_name: str) -> tuple["PullModelInput | None", Validation]:
        """Validate and create a PullModelInput."""
        validation = Validation()

        if not model_name.strip():
            validation.add_error("model_name cannot be empty")

        if validation.has_errors():
            return None, validation

        return PullModelInput(model_name=model_name), validation
