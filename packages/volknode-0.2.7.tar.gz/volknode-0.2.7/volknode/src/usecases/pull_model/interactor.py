from volknode.src.domain.llm_model import LlmModel
from volknode.src.llm.llm_runner import LlmRunner
from volknode.src.repository import LlmModelRepository
from volknode.src.usecases.pull_model.input import PullModelInput


class PullModelInteractor:
    def __init__(self, llm: LlmRunner, repository: LlmModelRepository):
        self._llm = llm
        self._repository = repository

    def execute(self, input: PullModelInput) -> LlmModel:
        pulled_info = self._llm.pull_model(input.model_name)
        model = LlmModel(
            name=pulled_info.name,
            context_window=pulled_info.context_window,
            quantization=pulled_info.quantization,
        )
        self._repository.save(model)
        return model
