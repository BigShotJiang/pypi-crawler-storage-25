from pathlib import Path

import pytest

from volknode.src.llm.fake_llm_runner import FakeLlmRunner
from volknode.src.repository import LlmModelRepository, RunningVllmConfigRepository
from volknode.src.usecases.pull_model.input import PullModelInput
from volknode.src.usecases.pull_model.interactor import PullModelInteractor
from volknode.src.usecases.run_llm_node.input import RunLlmNodeInput
from volknode.src.usecases.run_llm_node.interactor import RunLlmNodeInteractor


def _pull_model(fake_llm: FakeLlmRunner, repository: LlmModelRepository) -> None:
    pull_input, _ = PullModelInput.create("gpt2")
    PullModelInteractor(fake_llm, repository).execute(pull_input)


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "test.db"


class TestRunLlmNodeInteractor:
    def test_marks_model_as_running_and_runs_it(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        running_vllm_config_repo = RunningVllmConfigRepository(db_path)
        _pull_model(fake_llm, repository)
        interactor = RunLlmNodeInteractor(fake_llm, repository, running_vllm_config_repo)

        input_data, _ = RunLlmNodeInput.create("gpt2")

        interactor.execute(input_data)

        model = repository.find_by_name("gpt2")
        assert model is not None
        assert model.running is True
        assert fake_llm.is_running

        fake_llm.stop()

    def test_raises_error_when_model_not_in_repository(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        running_vllm_config_repo = RunningVllmConfigRepository(db_path)
        interactor = RunLlmNodeInteractor(fake_llm, repository, running_vllm_config_repo)

        input_data, _ = RunLlmNodeInput.create("nonexistent-model")

        with pytest.raises(RuntimeError, match="not found in repository"):
            interactor.execute(input_data)

    def test_running_an_already_running_model_keeps_it_running(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        running_vllm_config_repo = RunningVllmConfigRepository(db_path)
        _pull_model(fake_llm, repository)

        first_interactor = RunLlmNodeInteractor(fake_llm, repository, running_vllm_config_repo)
        first_input, _ = RunLlmNodeInput.create("gpt2")
        first_interactor.execute(first_input)

        input_data, _ = RunLlmNodeInput.create("gpt2")
        interactor = RunLlmNodeInteractor(fake_llm, repository, running_vllm_config_repo)

        interactor.execute(input_data)

        saved = repository.find_by_name("gpt2")
        assert saved.running is True
        assert fake_llm.is_running

        fake_llm.stop()

    def test_runs_on_localhost(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        running_vllm_config_repo = RunningVllmConfigRepository(db_path)
        _pull_model(fake_llm, repository)
        interactor = RunLlmNodeInteractor(fake_llm, repository, running_vllm_config_repo)

        input_data, _ = RunLlmNodeInput.create("gpt2")

        interactor.execute(input_data)

        assert fake_llm._server is not None
        assert fake_llm._server._host == "127.0.0.1"

        fake_llm.stop()

    def test_stores_vllm_config_after_running(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        running_vllm_config_repo = RunningVllmConfigRepository(db_path)
        _pull_model(fake_llm, repository)
        interactor = RunLlmNodeInteractor(fake_llm, repository, running_vllm_config_repo)

        input_data, _ = RunLlmNodeInput.create("gpt2")

        interactor.execute(input_data)

        config = running_vllm_config_repo.find_latest()
        assert config is not None
        assert config.host == "127.0.0.1"
        assert config.port > 0

        fake_llm.stop()

    def test_does_not_store_vllm_config_when_model_not_found(self, db_path: Path):
        fake_llm = FakeLlmRunner()
        repository = LlmModelRepository(db_path)
        running_vllm_config_repo = RunningVllmConfigRepository(db_path)
        interactor = RunLlmNodeInteractor(fake_llm, repository, running_vllm_config_repo)

        input_data, _ = RunLlmNodeInput.create("nonexistent-model")

        with pytest.raises(RuntimeError):
            interactor.execute(input_data)

        assert running_vllm_config_repo.find_latest() is None
