from dataclasses import dataclass

from volknode.src.core.validation import Validation


@dataclass
class RunLlmNodeInput:
    model_name: str

    @staticmethod
    def create(
        model_name: str,
    ) -> tuple["RunLlmNodeInput | None", Validation]:
        validation = Validation()

        if not model_name.strip():
            validation.add_error("model_name cannot be empty")

        if validation.has_errors():
            return None, validation

        return RunLlmNodeInput(model_name=model_name), validation
