import socket

from volknode.src.domain.running_vllm_config import RunningVllmConfig
from volknode.src.llm.llm_runner import LlmRunner
from volknode.src.repository import LlmModelRepository, RunningVllmConfigRepository
from volknode.src.usecases.run_llm_node.input import RunLlmNodeInput

HOST = "127.0.0.1"


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


class RunLlmNodeInteractor:
    def __init__(self, llm: LlmRunner, repository: LlmModelRepository, running_vllm_config_repository: RunningVllmConfigRepository):
        self._llm = llm
        self._repository = repository
        self._running_vllm_config_repository = running_vllm_config_repository

    def execute(self, input: RunLlmNodeInput) -> None:
        model = self._repository.find_by_name(input.model_name)
        if model is None:
            raise RuntimeError(
                f"Model '{input.model_name}' not found in repository. Pull it first."
            )
        port = _find_free_port()
        model.mark_as_running()
        self._repository.update(model)
        self._running_vllm_config_repository.save(RunningVllmConfig(host=HOST, port=port))
        self._llm.run_pulled_model(input.model_name, HOST, port)
