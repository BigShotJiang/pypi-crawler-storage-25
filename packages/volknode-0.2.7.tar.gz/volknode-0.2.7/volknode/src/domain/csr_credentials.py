from dataclasses import dataclass


@dataclass
class CsrCredentials:
    private_key_pem: str
    csr_pem: str
