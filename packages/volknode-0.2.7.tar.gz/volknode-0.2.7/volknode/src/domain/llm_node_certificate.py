from dataclasses import dataclass


@dataclass
class LlmNodeCertificate:
    certificate_pem: str
