from dataclasses import dataclass


@dataclass
class NexusCertificate:
    certificate_pem: str
