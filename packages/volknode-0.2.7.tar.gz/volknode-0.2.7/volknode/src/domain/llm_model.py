from dataclasses import dataclass


@dataclass
class LlmModel:
    name: str
    context_window: int
    quantization: str
    running: bool = False

    def mark_as_running(self) -> None:
        self.running = True
