from dataclasses import dataclass


@dataclass
class RunningVllmConfig:
    host: str
    port: int
