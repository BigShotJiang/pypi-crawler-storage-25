import os
from pathlib import Path

from volknode.src.llm.llm_runner import LlmRunner
from volknode.src.nexus.nexus import Nexus


class DependencyResolver:
    def __init__(self, *, use_fake_llm: bool = False, use_fake_nexus: bool = False):
        self._use_fake_llm = use_fake_llm
        self._use_fake_nexus = use_fake_nexus

    @staticmethod
    def from_env() -> "DependencyResolver":
        truthy = {"1", "true", "yes"}
        return DependencyResolver(
            use_fake_llm=os.environ.get("USE_FAKE_LLM", "").lower() in truthy,
            use_fake_nexus=os.environ.get("USE_FAKE_NEXUS", "").lower() in truthy,
        )

    def llm_runner(self, cache_dir: Path) -> LlmRunner:
        if self._use_fake_llm:
            from volknode.src.llm.fake_llm_runner import FakeLlmRunner
            return FakeLlmRunner()
        from volknode.src.llm.real_llm_runner import RealLlmRunner
        return RealLlmRunner(cache_dir)

    def nexus(self, nexus_url: str, verify_ssl: bool = True) -> Nexus:
        if self._use_fake_nexus:
            from volknode.src.nexus.fake_nexus import FakeNexus
            return FakeNexus()
        from volknode.src.nexus.real_nexus import RealNexus
        return RealNexus(nexus_url, verify_ssl=verify_ssl)
