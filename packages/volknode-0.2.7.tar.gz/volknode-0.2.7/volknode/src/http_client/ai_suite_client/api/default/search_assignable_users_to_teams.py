from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error import Error
from ...models.search_assignable_users_response import SearchAssignableUsersResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    term: str | Unset = UNSET,
    offset: int,
    limit: int,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["term"] = term

    params["offset"] = offset

    params["limit"] = limit


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/iam/teams/search-assignable-users",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | SearchAssignableUsersResponse | None:
    if response.status_code == 200:
        response_200 = SearchAssignableUsersResponse.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())



        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())



        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Error | SearchAssignableUsersResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    term: str | Unset = UNSET,
    offset: int,
    limit: int,

) -> Response[Error | SearchAssignableUsersResponse]:
    """ 
    Args:
        term (str | Unset):
        offset (int):
        limit (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | SearchAssignableUsersResponse]
     """


    kwargs = _get_kwargs(
        term=term,
offset=offset,
limit=limit,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    term: str | Unset = UNSET,
    offset: int,
    limit: int,

) -> Error | SearchAssignableUsersResponse | None:
    """ 
    Args:
        term (str | Unset):
        offset (int):
        limit (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | SearchAssignableUsersResponse
     """


    return sync_detailed(
        client=client,
term=term,
offset=offset,
limit=limit,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    term: str | Unset = UNSET,
    offset: int,
    limit: int,

) -> Response[Error | SearchAssignableUsersResponse]:
    """ 
    Args:
        term (str | Unset):
        offset (int):
        limit (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | SearchAssignableUsersResponse]
     """


    kwargs = _get_kwargs(
        term=term,
offset=offset,
limit=limit,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    term: str | Unset = UNSET,
    offset: int,
    limit: int,

) -> Error | SearchAssignableUsersResponse | None:
    """ 
    Args:
        term (str | Unset):
        offset (int):
        limit (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | SearchAssignableUsersResponse
     """


    return (await asyncio_detailed(
        client=client,
term=term,
offset=offset,
limit=limit,

    )).parsed
