from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.edit_sent_message_request import EditSentMessageRequest
from ...models.edit_sent_message_response_server_event import EditSentMessageResponseServerEvent
from typing import cast



def _get_kwargs(
    id: str,
    *,
    body: EditSentMessageRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/chat-backend/message/{id}/edit".format(id=quote(str(id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> EditSentMessageResponseServerEvent | None:
    if response.status_code == 200:
        response_200 = EditSentMessageResponseServerEvent.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[EditSentMessageResponseServerEvent]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: EditSentMessageRequest,

) -> Response[EditSentMessageResponseServerEvent]:
    """  Edit a sent message. Deletes all messages after the edited message, updates its content,
    and streams back the new AI response. Returns a Server-Sent Events stream.

    Args:
        id (str):
        body (EditSentMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EditSentMessageResponseServerEvent]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    *,
    client: AuthenticatedClient,
    body: EditSentMessageRequest,

) -> EditSentMessageResponseServerEvent | None:
    """  Edit a sent message. Deletes all messages after the edited message, updates its content,
    and streams back the new AI response. Returns a Server-Sent Events stream.

    Args:
        id (str):
        body (EditSentMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EditSentMessageResponseServerEvent
     """


    return sync_detailed(
        id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: EditSentMessageRequest,

) -> Response[EditSentMessageResponseServerEvent]:
    """  Edit a sent message. Deletes all messages after the edited message, updates its content,
    and streams back the new AI response. Returns a Server-Sent Events stream.

    Args:
        id (str):
        body (EditSentMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EditSentMessageResponseServerEvent]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient,
    body: EditSentMessageRequest,

) -> EditSentMessageResponseServerEvent | None:
    """  Edit a sent message. Deletes all messages after the edited message, updates its content,
    and streams back the new AI response. Returns a Server-Sent Events stream.

    Args:
        id (str):
        body (EditSentMessageRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EditSentMessageResponseServerEvent
     """


    return (await asyncio_detailed(
        id=id,
client=client,
body=body,

    )).parsed
