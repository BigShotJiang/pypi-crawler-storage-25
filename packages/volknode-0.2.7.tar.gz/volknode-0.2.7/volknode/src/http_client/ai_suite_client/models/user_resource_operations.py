from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="UserResourceOperations")



@_attrs_define
class UserResourceOperations:
    """ 
        Attributes:
            can_delete (bool): Indicates if the authenticated user can delete the resource.
            can_edit (bool): Indicates if the authenticated user can edit the resource.
     """

    can_delete: bool
    can_edit: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        can_delete = self.can_delete

        can_edit = self.can_edit


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "canDelete": can_delete,
            "canEdit": can_edit,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        can_delete = d.pop("canDelete")

        can_edit = d.pop("canEdit")

        user_resource_operations = cls(
            can_delete=can_delete,
            can_edit=can_edit,
        )


        user_resource_operations.additional_properties = d
        return user_resource_operations

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
