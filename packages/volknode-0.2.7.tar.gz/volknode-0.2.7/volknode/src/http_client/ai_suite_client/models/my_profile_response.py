from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.my_profile_team import MyProfileTeam





T = TypeVar("T", bound="MyProfileResponse")



@_attrs_define
class MyProfileResponse:
    """ 
        Attributes:
            id (str): The unique identifier of the user
            name (str): The name of the user
            email (str): The email address of the user
            role (str): The role of the user (e.g., Superadmin, Regular)
            username (str): The username of the user
            registered_at (datetime.datetime): The date and time when the user registered
            teams (list[MyProfileTeam]): The teams the user belongs to, with the LLMs each team has access to
     """

    id: str
    name: str
    email: str
    role: str
    username: str
    registered_at: datetime.datetime
    teams: list[MyProfileTeam]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.my_profile_team import MyProfileTeam
        id = self.id

        name = self.name

        email = self.email

        role = self.role

        username = self.username

        registered_at = self.registered_at.isoformat()

        teams = []
        for teams_item_data in self.teams:
            teams_item = teams_item_data.to_dict()
            teams.append(teams_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "email": email,
            "role": role,
            "username": username,
            "registeredAt": registered_at,
            "teams": teams,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.my_profile_team import MyProfileTeam
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        email = d.pop("email")

        role = d.pop("role")

        username = d.pop("username")

        registered_at = isoparse(d.pop("registeredAt"))




        teams = []
        _teams = d.pop("teams")
        for teams_item_data in (_teams):
            teams_item = MyProfileTeam.from_dict(teams_item_data)



            teams.append(teams_item)


        my_profile_response = cls(
            id=id,
            name=name,
            email=email,
            role=role,
            username=username,
            registered_at=registered_at,
            teams=teams,
        )


        my_profile_response.additional_properties = d
        return my_profile_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
