from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.assigned_llm import AssignedLlm
  from ..models.team_member import TeamMember





T = TypeVar("T", bound="GetTeamResponse")



@_attrs_define
class GetTeamResponse:
    """ 
        Attributes:
            id (str):
            name (str):
            description (str): Free-text description of the team's purpose.
            members (list[TeamMember]):
            assigned_llms (list[AssignedLlm]):
     """

    id: str
    name: str
    description: str
    members: list[TeamMember]
    assigned_llms: list[AssignedLlm]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.team_member import TeamMember
        from ..models.assigned_llm import AssignedLlm
        id = self.id

        name = self.name

        description = self.description

        members = []
        for members_item_data in self.members:
            members_item = members_item_data.to_dict()
            members.append(members_item)



        assigned_llms = []
        for assigned_llms_item_data in self.assigned_llms:
            assigned_llms_item = assigned_llms_item_data.to_dict()
            assigned_llms.append(assigned_llms_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "description": description,
            "members": members,
            "assignedLlms": assigned_llms,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.assigned_llm import AssignedLlm
        from ..models.team_member import TeamMember
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        description = d.pop("description")

        members = []
        _members = d.pop("members")
        for members_item_data in (_members):
            members_item = TeamMember.from_dict(members_item_data)



            members.append(members_item)


        assigned_llms = []
        _assigned_llms = d.pop("assignedLlms")
        for assigned_llms_item_data in (_assigned_llms):
            assigned_llms_item = AssignedLlm.from_dict(assigned_llms_item_data)



            assigned_llms.append(assigned_llms_item)


        get_team_response = cls(
            id=id,
            name=name,
            description=description,
            members=members,
            assigned_llms=assigned_llms,
        )


        get_team_response.additional_properties = d
        return get_team_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
