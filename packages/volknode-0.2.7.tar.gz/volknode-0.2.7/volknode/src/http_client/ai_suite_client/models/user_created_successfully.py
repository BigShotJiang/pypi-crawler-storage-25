from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.user_role import UserRole





T = TypeVar("T", bound="UserCreatedSuccessfully")



@_attrs_define
class UserCreatedSuccessfully:
    """ 
        Attributes:
            id (str):
            username (str):
            name (str):
            role (UserRole):
     """

    id: str
    username: str
    name: str
    role: UserRole
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.user_role import UserRole
        id = self.id

        username = self.username

        name = self.name

        role = self.role.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "username": username,
            "name": name,
            "role": role,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_role import UserRole
        d = dict(src_dict)
        id = d.pop("id")

        username = d.pop("username")

        name = d.pop("name")

        role = UserRole.from_dict(d.pop("role"))




        user_created_successfully = cls(
            id=id,
            username=username,
            name=name,
            role=role,
        )


        user_created_successfully.additional_properties = d
        return user_created_successfully

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
