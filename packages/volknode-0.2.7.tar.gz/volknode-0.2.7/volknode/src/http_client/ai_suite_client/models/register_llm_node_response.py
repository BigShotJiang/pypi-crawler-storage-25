from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="RegisterLlmNodeResponse")



@_attrs_define
class RegisterLlmNodeResponse:
    """ 
        Attributes:
            id (str): The unique identifier of the registered LLM node
            model_name (str): The organization-friendly name for the LLM model
            certificate (str): PEM-encoded client certificate signed by the Nexus CA
            ca_certificate (str): PEM-encoded CA certificate so the node can verify Nexus
     """

    id: str
    model_name: str
    certificate: str
    ca_certificate: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        model_name = self.model_name

        certificate = self.certificate

        ca_certificate = self.ca_certificate


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "modelName": model_name,
            "certificate": certificate,
            "caCertificate": ca_certificate,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        model_name = d.pop("modelName")

        certificate = d.pop("certificate")

        ca_certificate = d.pop("caCertificate")

        register_llm_node_response = cls(
            id=id,
            model_name=model_name,
            certificate=certificate,
            ca_certificate=ca_certificate,
        )


        register_llm_node_response.additional_properties = d
        return register_llm_node_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
