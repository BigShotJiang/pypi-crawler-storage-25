from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.logged_in_user import LoggedInUser





T = TypeVar("T", bound="SuccessfulLoginResponse")



@_attrs_define
class SuccessfulLoginResponse:
    """ 
        Attributes:
            logged_in_user (LoggedInUser):
     """

    logged_in_user: LoggedInUser
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.logged_in_user import LoggedInUser
        logged_in_user = self.logged_in_user.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "loggedInUser": logged_in_user,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.logged_in_user import LoggedInUser
        d = dict(src_dict)
        logged_in_user = LoggedInUser.from_dict(d.pop("loggedInUser"))




        successful_login_response = cls(
            logged_in_user=logged_in_user,
        )


        successful_login_response.additional_properties = d
        return successful_login_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
