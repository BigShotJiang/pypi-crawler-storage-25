from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.user_role_name import UserRoleName






T = TypeVar("T", bound="CreateUserRequest")



@_attrs_define
class CreateUserRequest:
    """ 
        Attributes:
            name (str):
            username (str):
            email (str):
            password1 (str):
            password2 (str):
            role (UserRoleName):
     """

    name: str
    username: str
    email: str
    password1: str
    password2: str
    role: UserRoleName
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        username = self.username

        email = self.email

        password1 = self.password1

        password2 = self.password2

        role = self.role.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "username": username,
            "email": email,
            "password1": password1,
            "password2": password2,
            "role": role,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        username = d.pop("username")

        email = d.pop("email")

        password1 = d.pop("password1")

        password2 = d.pop("password2")

        role = UserRoleName(d.pop("role"))




        create_user_request = cls(
            name=name,
            username=username,
            email=email,
            password1=password1,
            password2=password2,
            role=role,
        )


        create_user_request.additional_properties = d
        return create_user_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
