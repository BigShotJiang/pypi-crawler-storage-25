from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ViewOneLlmNode")



@_attrs_define
class ViewOneLlmNode:
    """ 
        Attributes:
            id (str): The unique identifier of the LLM node
            node_url (str): The URL of the LLM node
            model_name (str): The organization-friendly name for the LLM model
            model_id (str): The identifier of the model
            context_window (int): The context window size in tokens
     """

    id: str
    node_url: str
    model_name: str
    model_id: str
    context_window: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        node_url = self.node_url

        model_name = self.model_name

        model_id = self.model_id

        context_window = self.context_window


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "nodeUrl": node_url,
            "modelName": model_name,
            "modelId": model_id,
            "contextWindow": context_window,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        node_url = d.pop("nodeUrl")

        model_name = d.pop("modelName")

        model_id = d.pop("modelId")

        context_window = d.pop("contextWindow")

        view_one_llm_node = cls(
            id=id,
            node_url=node_url,
            model_name=model_name,
            model_id=model_id,
            context_window=context_window,
        )


        view_one_llm_node.additional_properties = d
        return view_one_llm_node

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
