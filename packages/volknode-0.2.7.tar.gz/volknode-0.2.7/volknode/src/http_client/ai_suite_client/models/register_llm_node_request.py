from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="RegisterLlmNodeRequest")



@_attrs_define
class RegisterLlmNodeRequest:
    """ 
        Attributes:
            personal_access_token (str): The personal access token with llm:manage scope
            model_name (str): An organization-friendly name for the LLM model
            csr (str): PEM-encoded Certificate Signing Request (CSR) containing the node's public key
            model_id (str): The identifier of the model
            quantization (str): The quantization level of the model
            context_window (int): The context window size in tokens
            llm_node_url (str): The full URL of the LLM node (e.g., https://host:port/path)
     """

    personal_access_token: str
    model_name: str
    csr: str
    model_id: str
    quantization: str
    context_window: int
    llm_node_url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        personal_access_token = self.personal_access_token

        model_name = self.model_name

        csr = self.csr

        model_id = self.model_id

        quantization = self.quantization

        context_window = self.context_window

        llm_node_url = self.llm_node_url


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "personalAccessToken": personal_access_token,
            "modelName": model_name,
            "csr": csr,
            "modelId": model_id,
            "quantization": quantization,
            "contextWindow": context_window,
            "llmNodeUrl": llm_node_url,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        personal_access_token = d.pop("personalAccessToken")

        model_name = d.pop("modelName")

        csr = d.pop("csr")

        model_id = d.pop("modelId")

        quantization = d.pop("quantization")

        context_window = d.pop("contextWindow")

        llm_node_url = d.pop("llmNodeUrl")

        register_llm_node_request = cls(
            personal_access_token=personal_access_token,
            model_name=model_name,
            csr=csr,
            model_id=model_id,
            quantization=quantization,
            context_window=context_window,
            llm_node_url=llm_node_url,
        )


        register_llm_node_request.additional_properties = d
        return register_llm_node_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
