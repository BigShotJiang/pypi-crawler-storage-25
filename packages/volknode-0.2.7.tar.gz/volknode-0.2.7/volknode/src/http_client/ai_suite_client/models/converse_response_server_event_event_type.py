from enum import Enum

class ConverseResponseServerEventEventType(str, Enum):
    AIASSISTANTSTARTEDTYPING = "aiAssistantStartedTyping"
    ERROR = "error"
    MODELNOTAVAILABLE = "modelNotAvailable"
    NEWCONVERSATIONSTARTED = "newConversationStarted"
    NOAVAILABLEMODELS = "noAvailableModels"
    PROMPTEDMESSAGESAVED = "promptedMessageSaved"
    REPLYCHUNK = "replyChunk"

    def __str__(self) -> str:
        return str(self.value)
