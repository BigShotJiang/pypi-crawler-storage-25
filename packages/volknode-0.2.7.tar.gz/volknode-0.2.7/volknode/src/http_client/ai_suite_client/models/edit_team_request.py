from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="EditTeamRequest")



@_attrs_define
class EditTeamRequest:
    """ 
        Attributes:
            name (str):
            users_to_assign (list[str]): List of user IDs that should be members of the team after the edit.
            llms_to_assign (list[str]): List of LLM model IDs (the user-facing model_id, not the internal UUID) that should
                be assigned to the team after the edit.
            description (str | Unset): Free-text description of the team's purpose. Replaces the existing description on
                save.
     """

    name: str
    users_to_assign: list[str]
    llms_to_assign: list[str]
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        users_to_assign = self.users_to_assign



        llms_to_assign = self.llms_to_assign



        description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "usersToAssign": users_to_assign,
            "llmsToAssign": llms_to_assign,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        users_to_assign = cast(list[str], d.pop("usersToAssign"))


        llms_to_assign = cast(list[str], d.pop("llmsToAssign"))


        description = d.pop("description", UNSET)

        edit_team_request = cls(
            name=name,
            users_to_assign=users_to_assign,
            llms_to_assign=llms_to_assign,
            description=description,
        )


        edit_team_request.additional_properties = d
        return edit_team_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
