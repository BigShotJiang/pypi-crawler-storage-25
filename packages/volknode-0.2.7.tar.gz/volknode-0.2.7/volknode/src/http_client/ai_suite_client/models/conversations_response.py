from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.conversation import Conversation





T = TypeVar("T", bound="ConversationsResponse")



@_attrs_define
class ConversationsResponse:
    """ 
        Attributes:
            conversations (list[Conversation]):
            offset (int):
            limit (int):
            total (int):
     """

    conversations: list[Conversation]
    offset: int
    limit: int
    total: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.conversation import Conversation
        conversations = []
        for conversations_item_data in self.conversations:
            conversations_item = conversations_item_data.to_dict()
            conversations.append(conversations_item)



        offset = self.offset

        limit = self.limit

        total = self.total


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "conversations": conversations,
            "offset": offset,
            "limit": limit,
            "total": total,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.conversation import Conversation
        d = dict(src_dict)
        conversations = []
        _conversations = d.pop("conversations")
        for conversations_item_data in (_conversations):
            conversations_item = Conversation.from_dict(conversations_item_data)



            conversations.append(conversations_item)


        offset = d.pop("offset")

        limit = d.pop("limit")

        total = d.pop("total")

        conversations_response = cls(
            conversations=conversations,
            offset=offset,
            limit=limit,
            total=total,
        )


        conversations_response.additional_properties = d
        return conversations_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
