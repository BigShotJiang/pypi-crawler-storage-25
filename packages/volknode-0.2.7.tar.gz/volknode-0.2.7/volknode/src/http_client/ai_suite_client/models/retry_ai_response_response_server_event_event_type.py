from enum import Enum

class RetryAiResponseResponseServerEventEventType(str, Enum):
    AIASSISTANTSTARTEDTYPING = "aiAssistantStartedTyping"
    AIRETRYSTARTED = "aiRetryStarted"
    ERROR = "error"
    MODELNOTAVAILABLE = "modelNotAvailable"
    NOAVAILABLEMODELS = "noAvailableModels"
    REPLYCHUNK = "replyChunk"

    def __str__(self) -> str:
        return str(self.value)
