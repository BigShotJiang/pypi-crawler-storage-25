from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field
import json
from .. import types

from ..types import UNSET, Unset

from ..types import File, FileTypes
from ..types import UNSET, Unset
from io import BytesIO
from typing import cast






T = TypeVar("T", bound="ConverseRequest")



@_attrs_define
class ConverseRequest:
    """ 
        Attributes:
            prompt (str):
            conversation_id (str | Unset):
            model_id (str | Unset): The identifier of the language model to use for this message
            files (list[File] | Unset):
     """

    prompt: str
    conversation_id: str | Unset = UNSET
    model_id: str | Unset = UNSET
    files: list[File] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        prompt = self.prompt

        conversation_id = self.conversation_id

        model_id = self.model_id

        files: list[FileTypes] | Unset = UNSET
        if not isinstance(self.files, Unset):
            files = []
            for files_item_data in self.files:
                files_item = files_item_data.to_tuple()

                files.append(files_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "prompt": prompt,
        })
        if conversation_id is not UNSET:
            field_dict["conversationId"] = conversation_id
        if model_id is not UNSET:
            field_dict["modelId"] = model_id
        if files is not UNSET:
            field_dict["files"] = files

        return field_dict


    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("prompt", (None, str(self.prompt).encode(), "text/plain")))



        if not isinstance(self.conversation_id, Unset):
            files.append(("conversationId", (None, str(self.conversation_id).encode(), "text/plain")))



        if not isinstance(self.model_id, Unset):
            files.append(("modelId", (None, str(self.model_id).encode(), "text/plain")))



        if not isinstance(self.files, Unset):
            for files_item_element in self.files:
                files.append(("files", files_item_element.to_tuple()))





        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))



        return files


    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        prompt = d.pop("prompt")

        conversation_id = d.pop("conversationId", UNSET)

        model_id = d.pop("modelId", UNSET)

        _files = d.pop("files", UNSET)
        files: list[File] | Unset = UNSET
        if _files is not UNSET:
            files = []
            for files_item_data in _files:
                files_item = File(
                     payload = BytesIO(files_item_data)
                )



                files.append(files_item)


        converse_request = cls(
            prompt=prompt,
            conversation_id=conversation_id,
            model_id=model_id,
            files=files,
        )


        converse_request.additional_properties = d
        return converse_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
