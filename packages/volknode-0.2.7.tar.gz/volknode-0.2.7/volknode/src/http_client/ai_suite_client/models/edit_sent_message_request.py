from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="EditSentMessageRequest")



@_attrs_define
class EditSentMessageRequest:
    """ 
        Attributes:
            new_content (str): The new content for the message.
            model_id (str | Unset): The id of the language model to use for the regenerated response.
     """

    new_content: str
    model_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        new_content = self.new_content

        model_id = self.model_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "newContent": new_content,
        })
        if model_id is not UNSET:
            field_dict["modelId"] = model_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        new_content = d.pop("newContent")

        model_id = d.pop("modelId", UNSET)

        edit_sent_message_request = cls(
            new_content=new_content,
            model_id=model_id,
        )


        edit_sent_message_request.additional_properties = d
        return edit_sent_message_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
