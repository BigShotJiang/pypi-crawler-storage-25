from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="BusinessConstraints")



@_attrs_define
class BusinessConstraints:
    """ 
        Attributes:
            max_personal_access_token_expiration_days (int): Maximum number of days a personal access token can be valid for
            allowed_file_types_to_add_in_message (list[str]): List of file extensions that can be attached to a message
            max_message_sent_file_bytes (int): Maximum file size in bytes that can be attached to a message
            max_allowed_file_attachments (int): Maximum number of files that can be attached to a message
     """

    max_personal_access_token_expiration_days: int
    allowed_file_types_to_add_in_message: list[str]
    max_message_sent_file_bytes: int
    max_allowed_file_attachments: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        max_personal_access_token_expiration_days = self.max_personal_access_token_expiration_days

        allowed_file_types_to_add_in_message = self.allowed_file_types_to_add_in_message



        max_message_sent_file_bytes = self.max_message_sent_file_bytes

        max_allowed_file_attachments = self.max_allowed_file_attachments


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "maxPersonalAccessTokenExpirationDays": max_personal_access_token_expiration_days,
            "allowedFileTypesToAddInMessage": allowed_file_types_to_add_in_message,
            "maxMessageSentFileBytes": max_message_sent_file_bytes,
            "maxAllowedFileAttachments": max_allowed_file_attachments,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        max_personal_access_token_expiration_days = d.pop("maxPersonalAccessTokenExpirationDays")

        allowed_file_types_to_add_in_message = cast(list[str], d.pop("allowedFileTypesToAddInMessage"))


        max_message_sent_file_bytes = d.pop("maxMessageSentFileBytes")

        max_allowed_file_attachments = d.pop("maxAllowedFileAttachments")

        business_constraints = cls(
            max_personal_access_token_expiration_days=max_personal_access_token_expiration_days,
            allowed_file_types_to_add_in_message=allowed_file_types_to_add_in_message,
            max_message_sent_file_bytes=max_message_sent_file_bytes,
            max_allowed_file_attachments=max_allowed_file_attachments,
        )


        business_constraints.additional_properties = d
        return business_constraints

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
