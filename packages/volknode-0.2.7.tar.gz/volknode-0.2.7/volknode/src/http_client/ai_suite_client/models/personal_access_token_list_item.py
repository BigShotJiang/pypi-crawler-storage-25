from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="PersonalAccessTokenListItem")



@_attrs_define
class PersonalAccessTokenListItem:
    """ 
        Attributes:
            id (str):
            name (str):
            scopes (list[str]):
            created_at (datetime.datetime):
            expires_at (datetime.datetime):
     """

    id: str
    name: str
    scopes: list[str]
    created_at: datetime.datetime
    expires_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        scopes = self.scopes



        created_at = self.created_at.isoformat()

        expires_at = self.expires_at.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "scopes": scopes,
            "createdAt": created_at,
            "expiresAt": expires_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        scopes = cast(list[str], d.pop("scopes"))


        created_at = isoparse(d.pop("createdAt"))




        expires_at = isoparse(d.pop("expiresAt"))




        personal_access_token_list_item = cls(
            id=id,
            name=name,
            scopes=scopes,
            created_at=created_at,
            expires_at=expires_at,
        )


        personal_access_token_list_item.additional_properties = d
        return personal_access_token_list_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
