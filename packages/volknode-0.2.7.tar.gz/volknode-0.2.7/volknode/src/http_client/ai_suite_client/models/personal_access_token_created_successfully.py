from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PersonalAccessTokenCreatedSuccessfully")



@_attrs_define
class PersonalAccessTokenCreatedSuccessfully:
    """ 
        Attributes:
            id (str):
            name (str):
            plaintext_token (str): The plaintext token value. This is only shown once and cannot be retrieved again.
     """

    id: str
    name: str
    plaintext_token: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        plaintext_token = self.plaintext_token


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "plaintextToken": plaintext_token,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        plaintext_token = d.pop("plaintextToken")

        personal_access_token_created_successfully = cls(
            id=id,
            name=name,
            plaintext_token=plaintext_token,
        )


        personal_access_token_created_successfully.additional_properties = d
        return personal_access_token_created_successfully

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
