from enum import Enum

class UserRoleName(str, Enum):
    REGULAR = "Regular"
    SUPERADMIN = "Superadmin"

    def __str__(self) -> str:
        return str(self.value)
