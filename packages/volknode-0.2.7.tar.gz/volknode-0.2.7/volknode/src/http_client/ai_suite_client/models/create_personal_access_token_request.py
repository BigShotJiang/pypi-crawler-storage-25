from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="CreatePersonalAccessTokenRequest")



@_attrs_define
class CreatePersonalAccessTokenRequest:
    """ 
        Attributes:
            name (str): A descriptive name for the personal access token
            scope_codes (list[str]): List of scope codes to grant to this token
            expires_at (datetime.datetime): The expiration date and time for the token (ISO 8601 format)
     """

    name: str
    scope_codes: list[str]
    expires_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        scope_codes = self.scope_codes



        expires_at = self.expires_at.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "scopeCodes": scope_codes,
            "expiresAt": expires_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        scope_codes = cast(list[str], d.pop("scopeCodes"))


        expires_at = isoparse(d.pop("expiresAt"))




        create_personal_access_token_request = cls(
            name=name,
            scope_codes=scope_codes,
            expires_at=expires_at,
        )


        create_personal_access_token_request.additional_properties = d
        return create_personal_access_token_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
