from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.reply_chunk_content import ReplyChunkContent





T = TypeVar("T", bound="ReplyChunk")



@_attrs_define
class ReplyChunk:
    """ 
        Attributes:
            message_id (str):
            conversation_id (str):
            content (ReplyChunkContent):
     """

    message_id: str
    conversation_id: str
    content: ReplyChunkContent
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.reply_chunk_content import ReplyChunkContent
        message_id = self.message_id

        conversation_id = self.conversation_id

        content = self.content.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "messageId": message_id,
            "conversationId": conversation_id,
            "content": content,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.reply_chunk_content import ReplyChunkContent
        d = dict(src_dict)
        message_id = d.pop("messageId")

        conversation_id = d.pop("conversationId")

        content = ReplyChunkContent.from_dict(d.pop("content"))




        reply_chunk = cls(
            message_id=message_id,
            conversation_id=conversation_id,
            content=content,
        )


        reply_chunk.additional_properties = d
        return reply_chunk

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
