from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.user_resource_operations import UserResourceOperations





T = TypeVar("T", bound="ViewOneUser")



@_attrs_define
class ViewOneUser:
    """ 
        Attributes:
            id (str):
            name (str):
            username (str):
            email (str):
            role (str):
            registered_at (str):
            operations (UserResourceOperations):
     """

    id: str
    name: str
    username: str
    email: str
    role: str
    registered_at: str
    operations: UserResourceOperations
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.user_resource_operations import UserResourceOperations
        id = self.id

        name = self.name

        username = self.username

        email = self.email

        role = self.role

        registered_at = self.registered_at

        operations = self.operations.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "username": username,
            "email": email,
            "role": role,
            "registeredAt": registered_at,
            "operations": operations,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_resource_operations import UserResourceOperations
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        username = d.pop("username")

        email = d.pop("email")

        role = d.pop("role")

        registered_at = d.pop("registeredAt")

        operations = UserResourceOperations.from_dict(d.pop("operations"))




        view_one_user = cls(
            id=id,
            name=name,
            username=username,
            email=email,
            role=role,
            registered_at=registered_at,
            operations=operations,
        )


        view_one_user.additional_properties = d
        return view_one_user

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
