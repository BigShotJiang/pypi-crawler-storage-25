from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="Permissions")



@_attrs_define
class Permissions:
    """ 
        Attributes:
            can_view_users (bool):
            can_create_user (bool):
            can_create_personal_access_token (bool):
            can_create_team (bool):
     """

    can_view_users: bool
    can_create_user: bool
    can_create_personal_access_token: bool
    can_create_team: bool
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        can_view_users = self.can_view_users

        can_create_user = self.can_create_user

        can_create_personal_access_token = self.can_create_personal_access_token

        can_create_team = self.can_create_team


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "canViewUsers": can_view_users,
            "canCreateUser": can_create_user,
            "canCreatePersonalAccessToken": can_create_personal_access_token,
            "canCreateTeam": can_create_team,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        can_view_users = d.pop("canViewUsers")

        can_create_user = d.pop("canCreateUser")

        can_create_personal_access_token = d.pop("canCreatePersonalAccessToken")

        can_create_team = d.pop("canCreateTeam")

        permissions = cls(
            can_view_users=can_view_users,
            can_create_user=can_create_user,
            can_create_personal_access_token=can_create_personal_access_token,
            can_create_team=can_create_team,
        )


        permissions.additional_properties = d
        return permissions

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
