from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.retry_ai_response_response_server_event_event_type import RetryAiResponseResponseServerEventEventType
from typing import cast

if TYPE_CHECKING:
  from ..models.ai_assistant_started_typing_event import AiAssistantStartedTypingEvent
  from ..models.ai_retry_started_event import AiRetryStartedEvent
  from ..models.error_event import ErrorEvent
  from ..models.model_not_available_event import ModelNotAvailableEvent
  from ..models.no_available_models_event import NoAvailableModelsEvent
  from ..models.reply_chunk import ReplyChunk





T = TypeVar("T", bound="RetryAiResponseResponseServerEvent")



@_attrs_define
class RetryAiResponseResponseServerEvent:
    """ 
        Attributes:
            event_type (RetryAiResponseResponseServerEventEventType):
            data (AiAssistantStartedTypingEvent | AiRetryStartedEvent | ErrorEvent | ModelNotAvailableEvent |
                NoAvailableModelsEvent | ReplyChunk):
     """

    event_type: RetryAiResponseResponseServerEventEventType
    data: AiAssistantStartedTypingEvent | AiRetryStartedEvent | ErrorEvent | ModelNotAvailableEvent | NoAvailableModelsEvent | ReplyChunk
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.no_available_models_event import NoAvailableModelsEvent
        from ..models.error_event import ErrorEvent
        from ..models.ai_assistant_started_typing_event import AiAssistantStartedTypingEvent
        from ..models.reply_chunk import ReplyChunk
        from ..models.model_not_available_event import ModelNotAvailableEvent
        from ..models.ai_retry_started_event import AiRetryStartedEvent
        event_type = self.event_type.value

        data: dict[str, Any]
        if isinstance(self.data, AiRetryStartedEvent):
            data = self.data.to_dict()
        elif isinstance(self.data, AiAssistantStartedTypingEvent):
            data = self.data.to_dict()
        elif isinstance(self.data, ReplyChunk):
            data = self.data.to_dict()
        elif isinstance(self.data, NoAvailableModelsEvent):
            data = self.data.to_dict()
        elif isinstance(self.data, ModelNotAvailableEvent):
            data = self.data.to_dict()
        else:
            data = self.data.to_dict()



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "eventType": event_type,
            "data": data,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.ai_assistant_started_typing_event import AiAssistantStartedTypingEvent
        from ..models.ai_retry_started_event import AiRetryStartedEvent
        from ..models.error_event import ErrorEvent
        from ..models.model_not_available_event import ModelNotAvailableEvent
        from ..models.no_available_models_event import NoAvailableModelsEvent
        from ..models.reply_chunk import ReplyChunk
        d = dict(src_dict)
        event_type = RetryAiResponseResponseServerEventEventType(d.pop("eventType"))




        def _parse_data(data: object) -> AiAssistantStartedTypingEvent | AiRetryStartedEvent | ErrorEvent | ModelNotAvailableEvent | NoAvailableModelsEvent | ReplyChunk:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_0 = AiRetryStartedEvent.from_dict(data)



                return data_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_1 = AiAssistantStartedTypingEvent.from_dict(data)



                return data_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_2 = ReplyChunk.from_dict(data)



                return data_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_3 = NoAvailableModelsEvent.from_dict(data)



                return data_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_4 = ModelNotAvailableEvent.from_dict(data)



                return data_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            data_type_5 = ErrorEvent.from_dict(data)



            return data_type_5

        data = _parse_data(d.pop("data"))


        retry_ai_response_response_server_event = cls(
            event_type=event_type,
            data=data,
        )


        retry_ai_response_response_server_event.additional_properties = d
        return retry_ai_response_response_server_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
