from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ViewOneTeam")



@_attrs_define
class ViewOneTeam:
    """ 
        Attributes:
            id (str): The unique identifier of the team.
            name (str): The name of the team.
            description (str): Free-text description of the team's purpose.
            user_count (int): The number of users assigned to the team.
            llm_count (int): The number of language models assigned to the team.
     """

    id: str
    name: str
    description: str
    user_count: int
    llm_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        description = self.description

        user_count = self.user_count

        llm_count = self.llm_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "description": description,
            "userCount": user_count,
            "llmCount": llm_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        description = d.pop("description")

        user_count = d.pop("userCount")

        llm_count = d.pop("llmCount")

        view_one_team = cls(
            id=id,
            name=name,
            description=description,
            user_count=user_count,
            llm_count=llm_count,
        )


        view_one_team.additional_properties = d
        return view_one_team

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
