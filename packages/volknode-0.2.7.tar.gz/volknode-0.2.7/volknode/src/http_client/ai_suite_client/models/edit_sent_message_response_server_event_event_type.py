from enum import Enum

class EditSentMessageResponseServerEventEventType(str, Enum):
    AIASSISTANTSTARTEDTYPING = "aiAssistantStartedTyping"
    ERROR = "error"
    MESSAGEEDITED = "messageEdited"
    MODELNOTAVAILABLE = "modelNotAvailable"
    NOAVAILABLEMODELS = "noAvailableModels"
    REPLYCHUNK = "replyChunk"

    def __str__(self) -> str:
        return str(self.value)
