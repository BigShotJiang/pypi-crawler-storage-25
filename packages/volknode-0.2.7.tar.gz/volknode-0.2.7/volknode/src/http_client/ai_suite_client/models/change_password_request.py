from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ChangePasswordRequest")



@_attrs_define
class ChangePasswordRequest:
    """ 
        Attributes:
            current_password (str): The user's current password
            new_password_1 (str): The new password
            new_password_2 (str): Confirmation of the new password
     """

    current_password: str
    new_password_1: str
    new_password_2: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        current_password = self.current_password

        new_password_1 = self.new_password_1

        new_password_2 = self.new_password_2


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "currentPassword": current_password,
            "newPassword1": new_password_1,
            "newPassword2": new_password_2,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        current_password = d.pop("currentPassword")

        new_password_1 = d.pop("newPassword1")

        new_password_2 = d.pop("newPassword2")

        change_password_request = cls(
            current_password=current_password,
            new_password_1=new_password_1,
            new_password_2=new_password_2,
        )


        change_password_request.additional_properties = d
        return change_password_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
