from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.message_author import MessageAuthor
from typing import cast

if TYPE_CHECKING:
  from ..models.attached_file import AttachedFile





T = TypeVar("T", bound="Message")



@_attrs_define
class Message:
    """ 
        Attributes:
            id (str): Unique identifier for the message.
            conversation_id (str): Identifier for the conversation the message belongs to.
            author (MessageAuthor): The type of author who sent the message.
            content (str): The content of the message.
            is_liked (bool): Whether the message has been liked.
            is_disliked (bool): Whether the message has been disliked.
            attached_files (list[AttachedFile]): Files attached to this message.
     """

    id: str
    conversation_id: str
    author: MessageAuthor
    content: str
    is_liked: bool
    is_disliked: bool
    attached_files: list[AttachedFile]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.attached_file import AttachedFile
        id = self.id

        conversation_id = self.conversation_id

        author = self.author.value

        content = self.content

        is_liked = self.is_liked

        is_disliked = self.is_disliked

        attached_files = []
        for attached_files_item_data in self.attached_files:
            attached_files_item = attached_files_item_data.to_dict()
            attached_files.append(attached_files_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "conversationId": conversation_id,
            "author": author,
            "content": content,
            "isLiked": is_liked,
            "isDisliked": is_disliked,
            "attachedFiles": attached_files,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.attached_file import AttachedFile
        d = dict(src_dict)
        id = d.pop("id")

        conversation_id = d.pop("conversationId")

        author = MessageAuthor(d.pop("author"))




        content = d.pop("content")

        is_liked = d.pop("isLiked")

        is_disliked = d.pop("isDisliked")

        attached_files = []
        _attached_files = d.pop("attachedFiles")
        for attached_files_item_data in (_attached_files):
            attached_files_item = AttachedFile.from_dict(attached_files_item_data)



            attached_files.append(attached_files_item)


        message = cls(
            id=id,
            conversation_id=conversation_id,
            author=author,
            content=content,
            is_liked=is_liked,
            is_disliked=is_disliked,
            attached_files=attached_files,
        )


        message.additional_properties = d
        return message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
