from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="Error")



@_attrs_define
class Error:
    """ 
        Attributes:
            http_status_code (int): The HTTP status code. Included in the payload, to make sure that the response status
                code is not modified in transit by a proxy, load balancer, or other intermediary.
            description (str): A description of the error. This field may contain a generic or technical message intended
                for debugging or logging purposes. It is not meant to be displayed to end users.
            user_friendly_messages (list[str]): A message intended to be shown to end users. It should be clear, concise,
                and free of technical jargon,
                providing a helpful explanation or guidance related to the error or response. It may be translated to the user's
                language.
     """

    http_status_code: int
    description: str
    user_friendly_messages: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        http_status_code = self.http_status_code

        description = self.description

        user_friendly_messages = self.user_friendly_messages




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "httpStatusCode": http_status_code,
            "description": description,
            "userFriendlyMessages": user_friendly_messages,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        http_status_code = d.pop("httpStatusCode")

        description = d.pop("description")

        user_friendly_messages = cast(list[str], d.pop("userFriendlyMessages"))


        error = cls(
            http_status_code=http_status_code,
            description=description,
            user_friendly_messages=user_friendly_messages,
        )


        error.additional_properties = d
        return error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
