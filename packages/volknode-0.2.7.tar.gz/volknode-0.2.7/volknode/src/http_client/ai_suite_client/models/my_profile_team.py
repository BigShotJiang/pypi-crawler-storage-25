from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.my_profile_team_llm import MyProfileTeamLlm





T = TypeVar("T", bound="MyProfileTeam")



@_attrs_define
class MyProfileTeam:
    """ 
        Attributes:
            id (str): The unique identifier of the team
            name (str): The name of the team
            description (str): The description of the team
            llms (list[MyProfileTeamLlm]): The LLMs assigned to this team
     """

    id: str
    name: str
    description: str
    llms: list[MyProfileTeamLlm]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.my_profile_team_llm import MyProfileTeamLlm
        id = self.id

        name = self.name

        description = self.description

        llms = []
        for llms_item_data in self.llms:
            llms_item = llms_item_data.to_dict()
            llms.append(llms_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "description": description,
            "llms": llms,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.my_profile_team_llm import MyProfileTeamLlm
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        description = d.pop("description")

        llms = []
        _llms = d.pop("llms")
        for llms_item_data in (_llms):
            llms_item = MyProfileTeamLlm.from_dict(llms_item_data)



            llms.append(llms_item)


        my_profile_team = cls(
            id=id,
            name=name,
            description=description,
            llms=llms,
        )


        my_profile_team.additional_properties = d
        return my_profile_team

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
