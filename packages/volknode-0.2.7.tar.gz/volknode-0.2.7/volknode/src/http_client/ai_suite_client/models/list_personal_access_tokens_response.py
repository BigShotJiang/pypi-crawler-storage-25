from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.personal_access_token_list_item import PersonalAccessTokenListItem





T = TypeVar("T", bound="ListPersonalAccessTokensResponse")



@_attrs_define
class ListPersonalAccessTokensResponse:
    """ 
        Attributes:
            tokens (list[PersonalAccessTokenListItem]):
     """

    tokens: list[PersonalAccessTokenListItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.personal_access_token_list_item import PersonalAccessTokenListItem
        tokens = []
        for tokens_item_data in self.tokens:
            tokens_item = tokens_item_data.to_dict()
            tokens.append(tokens_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "tokens": tokens,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.personal_access_token_list_item import PersonalAccessTokenListItem
        d = dict(src_dict)
        tokens = []
        _tokens = d.pop("tokens")
        for tokens_item_data in (_tokens):
            tokens_item = PersonalAccessTokenListItem.from_dict(tokens_item_data)



            tokens.append(tokens_item)


        list_personal_access_tokens_response = cls(
            tokens=tokens,
        )


        list_personal_access_tokens_response.additional_properties = d
        return list_personal_access_tokens_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
