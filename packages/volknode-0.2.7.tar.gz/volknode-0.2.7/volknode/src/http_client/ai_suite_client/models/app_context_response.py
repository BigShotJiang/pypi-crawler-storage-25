from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.available_model import AvailableModel
  from ..models.business_constraints import BusinessConstraints
  from ..models.permissions import Permissions





T = TypeVar("T", bound="AppContextResponse")



@_attrs_define
class AppContextResponse:
    """ 
        Attributes:
            available_models (list[AvailableModel]):
            business_constraints (BusinessConstraints):
            permissions (Permissions):
     """

    available_models: list[AvailableModel]
    business_constraints: BusinessConstraints
    permissions: Permissions
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.permissions import Permissions
        from ..models.available_model import AvailableModel
        from ..models.business_constraints import BusinessConstraints
        available_models = []
        for available_models_item_data in self.available_models:
            available_models_item = available_models_item_data.to_dict()
            available_models.append(available_models_item)



        business_constraints = self.business_constraints.to_dict()

        permissions = self.permissions.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "availableModels": available_models,
            "businessConstraints": business_constraints,
            "permissions": permissions,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.available_model import AvailableModel
        from ..models.business_constraints import BusinessConstraints
        from ..models.permissions import Permissions
        d = dict(src_dict)
        available_models = []
        _available_models = d.pop("availableModels")
        for available_models_item_data in (_available_models):
            available_models_item = AvailableModel.from_dict(available_models_item_data)



            available_models.append(available_models_item)


        business_constraints = BusinessConstraints.from_dict(d.pop("businessConstraints"))




        permissions = Permissions.from_dict(d.pop("permissions"))




        app_context_response = cls(
            available_models=available_models,
            business_constraints=business_constraints,
            permissions=permissions,
        )


        app_context_response.additional_properties = d
        return app_context_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
