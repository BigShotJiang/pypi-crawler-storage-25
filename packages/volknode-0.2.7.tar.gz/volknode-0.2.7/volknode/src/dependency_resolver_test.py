import os
from pathlib import Path

from volknode.src.dependency_resolver import DependencyResolver
from volknode.src.llm.fake_llm_runner import FakeLlmRunner
from volknode.src.llm.real_llm_runner import RealLlmRunner
from volknode.src.nexus.fake_nexus import FakeNexus
from volknode.src.nexus.real_nexus import RealNexus


class TestDependencyResolver:
    def test_default_returns_real_llm_runner(self, tmp_path: Path):
        resolver = DependencyResolver()
        result = resolver.llm_runner(cache_dir=tmp_path)
        assert isinstance(result, RealLlmRunner)

    def test_default_returns_real_nexus(self):
        resolver = DependencyResolver()
        result = resolver.nexus(nexus_url="http://localhost:8080")
        assert isinstance(result, RealNexus)

    def test_use_fake_llm_returns_fake_llm_runner(self, tmp_path: Path):
        resolver = DependencyResolver(use_fake_llm=True)
        result = resolver.llm_runner(cache_dir=tmp_path)
        assert isinstance(result, FakeLlmRunner)

    def test_use_fake_nexus_returns_fake_nexus(self):
        resolver = DependencyResolver(use_fake_nexus=True)
        result = resolver.nexus(nexus_url="http://localhost:8080")
        assert isinstance(result, FakeNexus)

    def test_from_env_defaults_to_real_when_vars_unset(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("USE_FAKE_LLM", raising=False)
        monkeypatch.delenv("USE_FAKE_NEXUS", raising=False)
        resolver = DependencyResolver.from_env()
        assert isinstance(resolver.llm_runner(cache_dir=tmp_path), RealLlmRunner)
        assert isinstance(resolver.nexus(nexus_url="http://localhost:8080"), RealNexus)

    def test_from_env_reads_use_fake_llm(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("USE_FAKE_LLM", "true")
        monkeypatch.delenv("USE_FAKE_NEXUS", raising=False)
        resolver = DependencyResolver.from_env()
        assert isinstance(resolver.llm_runner(cache_dir=tmp_path), FakeLlmRunner)

    def test_from_env_reads_use_fake_nexus(self, monkeypatch):
        monkeypatch.delenv("USE_FAKE_LLM", raising=False)
        monkeypatch.setenv("USE_FAKE_NEXUS", "1")
        resolver = DependencyResolver.from_env()
        assert isinstance(resolver.nexus(nexus_url="http://localhost:8080"), FakeNexus)

    def test_from_env_accepts_yes(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("USE_FAKE_LLM", "yes")
        monkeypatch.setenv("USE_FAKE_NEXUS", "YES")
        resolver = DependencyResolver.from_env()
        assert isinstance(resolver.llm_runner(cache_dir=tmp_path), FakeLlmRunner)
        assert isinstance(resolver.nexus(nexus_url="http://localhost:8080"), FakeNexus)
