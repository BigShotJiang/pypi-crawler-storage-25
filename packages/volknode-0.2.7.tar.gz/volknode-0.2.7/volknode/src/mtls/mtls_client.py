import json
import ssl
import tempfile
import urllib.request


class MtlsClient:
    def __init__(self, *, certificate_pem: str, private_key_pem: str, ca_certificate_pem: str):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False

        with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
            f.write(certificate_pem)
            cert_file = f.name

        with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
            f.write(private_key_pem)
            key_file = f.name

        with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
            f.write(ca_certificate_pem)
            ca_file = f.name

        ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)
        ctx.load_verify_locations(cafile=ca_file)
        self._ctx = ctx

    def post(self, url: str, body: dict) -> dict:
        request_body = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=request_body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, context=self._ctx) as resp:
            return json.loads(resp.read().decode("utf-8"))
