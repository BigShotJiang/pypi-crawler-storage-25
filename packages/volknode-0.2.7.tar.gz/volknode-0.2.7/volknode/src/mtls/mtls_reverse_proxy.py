import http.client
import http.server
import ssl
import tempfile
import threading
from urllib.parse import urlparse


class MtlsReverseProxy:
    def start(
        self,
        *,
        private_key_pem: str,
        certificate_pem: str,
        ca_certificate_pem: str,
        listen_host: str,
        listen_port: int,
        upstream_url: str,
    ) -> None:
        parsed_upstream = urlparse(upstream_url)
        upstream_host = parsed_upstream.hostname
        upstream_port = parsed_upstream.port or 80

        class ProxyHandler(http.server.BaseHTTPRequestHandler):
            def do_request(self):
                conn = http.client.HTTPConnection(upstream_host, upstream_port)
                content_length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_length) if content_length > 0 else None
                headers = {k: v for k, v in self.headers.items() if k.lower() != "host"}
                conn.request(self.command, self.path, body=body, headers=headers)
                response = conn.getresponse()
                self.send_response(response.status)
                for header, value in response.getheaders():
                    if header.lower() != "transfer-encoding":
                        self.send_header(header, value)
                self.end_headers()
                while True:
                    chunk = response.read1(4096)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
                conn.close()

            do_GET = do_request
            do_POST = do_request
            do_PUT = do_request
            do_DELETE = do_request
            do_PATCH = do_request

            def log_message(self, format, *args):
                pass

        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)

        key_file = tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False)
        key_file.write(private_key_pem)
        key_file.flush()

        cert_file = tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False)
        cert_file.write(certificate_pem)
        cert_file.flush()

        ca_file = tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False)
        ca_file.write(ca_certificate_pem)
        ca_file.flush()

        ctx.load_cert_chain(certfile=cert_file.name, keyfile=key_file.name)
        ctx.load_verify_locations(cafile=ca_file.name)
        ctx.verify_mode = ssl.CERT_REQUIRED

        server = http.server.HTTPServer((listen_host, listen_port), ProxyHandler)
        server.socket = ctx.wrap_socket(server.socket, server_side=True)

        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
