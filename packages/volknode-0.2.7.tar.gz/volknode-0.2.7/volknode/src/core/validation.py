class Validation:
    def __init__(self):
        self._error_list: list[str] = []

    def add_error(self, err: str) -> None:
        self._error_list.append(err)

    def merge_with(self, other: "Validation") -> None:
        self._error_list.extend(other._error_list)

    def errors(self) -> list[str]:
        return self._error_list

    def error(self) -> str | None:
        if not self._error_list:
            return None
        return "\n".join(self._error_list)

    def has_errors(self) -> bool:
        return len(self._error_list) > 0
