import datetime
import os
import subprocess
import pytest
import requests

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.x509 import ObjectIdentifier

from volknode.src.http_client.ai_suite_client.models.register_llm_node_request import RegisterLlmNodeRequest
from volknode.src.http_client.ai_suite_client.models.register_llm_node_response import RegisterLlmNodeResponse
from volknode.src.http_client.ai_suite_client.models.create_personal_access_token_request import CreatePersonalAccessTokenRequest
from volknode.src.http_client.ai_suite_client.models.login_with_credentials_request import LoginWithCredentialsRequest
from volknode.src.csr.csr_service import CsrService, LlmNodeCsr
from volknode.src.csr.key_pair_generator import KeyPairGenerator
from volknode.src.nexus.real_nexus import RealNexus
from volknode.src.nexus.fake_nexus import FakeNexus

_OID_LLM_MODEL_NAME = ObjectIdentifier("1.3.6.1.4.1.99999.1.1")
_OID_LLM_NODE_MODEL_ID = ObjectIdentifier("1.3.6.1.4.1.99999.1.2")
_OID_LLM_NODE_MODEL_QUANTIZATION = ObjectIdentifier("1.3.6.1.4.1.99999.1.4")
_OID_LLM_NODE_MODEL_CONTEXT_WINDOW = ObjectIdentifier("1.3.6.1.4.1.99999.1.5")
_OID_LLM_NODE_LLM_NODE_URL = ObjectIdentifier("1.3.6.1.4.1.99999.1.10")


def _get_nexus_url() -> str:
    container_name = os.environ.get("NEXUS_CONTAINER_NAME", "nexus")
    result = subprocess.run(
        ["docker", "inspect", "--format",
         '{{(index (index .NetworkSettings.Ports "8080/tcp") 0).HostPort}}',
         container_name],
        capture_output=True, text=True, check=True,
    )
    port = result.stdout.strip()
    host = os.environ.get("NEXUS_HOST", "localhost")
    return f"http://{host}:{port}"


NEXUS_URL = _get_nexus_url()


@pytest.fixture(autouse=True)
def reset_app():
    requests.post(f"{NEXUS_URL}/testing/reset-app")


def _login_and_create_token(nexus) -> str:
    nexus.login(LoginWithCredentialsRequest(username="root", password="password"))
    token = nexus.create_personal_access_token(CreatePersonalAccessTokenRequest(
        name="llm-token",
        scope_codes=["llm:manage"],
        expires_at=datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=30),
    ))
    return token.plaintext_token


def _register_llm_node(nexus, token, csr_pem, llm_node_csr):
    request = RegisterLlmNodeRequest(
        personal_access_token=token,
        model_name=llm_node_csr.model_name,
        csr=csr_pem,
        model_id=llm_node_csr.model_id,
        quantization=llm_node_csr.model_quantization,
        context_window=llm_node_csr.model_context_window,
        llm_node_url=llm_node_csr.llm_node_url,
    )
    return nexus.register_llm_node(request)


def _parse_certificate(pem: str) -> x509.Certificate:
    return x509.load_pem_x509_certificate(pem.encode("utf-8"))


def _get_subject_attr(cert: x509.Certificate, oid: ObjectIdentifier) -> str:
    attrs = cert.subject.get_attributes_for_oid(oid)
    assert len(attrs) == 1, f"Expected exactly 1 attribute for OID {oid}, got {len(attrs)}"
    return attrs[0].value


def test_register_llm_node_returns_equivalent_response():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="test-model-name",
        model_id="test-model-id",
        model_quantization="Q4_K_M",
        model_context_window=4096,
        llm_node_url="http://localhost:8000/v1",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    assert isinstance(real_result, RegisterLlmNodeResponse)
    assert isinstance(fake_result, RegisterLlmNodeResponse)

    assert real_result.model_name == fake_result.model_name == "test-model-name"

    assert isinstance(real_result.id, str) and len(real_result.id) > 0
    assert isinstance(fake_result.id, str) and len(fake_result.id) > 0

    assert isinstance(real_result.certificate, str) and len(real_result.certificate) > 0
    assert isinstance(fake_result.certificate, str) and len(fake_result.certificate) > 0

    assert isinstance(real_result.ca_certificate, str) and len(real_result.ca_certificate) > 0
    assert isinstance(fake_result.ca_certificate, str) and len(fake_result.ca_certificate) > 0


def test_certificate_subject_contains_csr_model_name():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="my-special-model-name",
        model_id="my-special-model-id",
        model_quantization="Q4_K_M",
        model_context_window=4096,
        llm_node_url="http://localhost:8000/v1",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    fake_cert = _parse_certificate(fake_result.certificate)

    assert _get_subject_attr(real_cert, _OID_LLM_MODEL_NAME) == "my-special-model-name"
    assert _get_subject_attr(fake_cert, _OID_LLM_MODEL_NAME) == "my-special-model-name"


def test_certificate_subject_contains_csr_model_id():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="test-model-name",
        model_id="llama-3.1-70b",
        model_quantization="Q4_K_M",
        model_context_window=4096,
        llm_node_url="http://localhost:8000/v1",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    fake_cert = _parse_certificate(fake_result.certificate)

    assert _get_subject_attr(real_cert, _OID_LLM_NODE_MODEL_ID) == "llama-3.1-70b"
    assert _get_subject_attr(fake_cert, _OID_LLM_NODE_MODEL_ID) == "llama-3.1-70b"


def test_certificate_subject_contains_csr_quantization():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="test-model-name",
        model_id="test-model-id",
        model_quantization="Q8_0",
        model_context_window=4096,
        llm_node_url="http://localhost:8000/v1",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    fake_cert = _parse_certificate(fake_result.certificate)

    assert _get_subject_attr(real_cert, _OID_LLM_NODE_MODEL_QUANTIZATION) == "Q8_0"
    assert _get_subject_attr(fake_cert, _OID_LLM_NODE_MODEL_QUANTIZATION) == "Q8_0"


def test_certificate_subject_contains_csr_context_window():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="test-model-name",
        model_id="test-model-id",
        model_quantization="Q4_K_M",
        model_context_window=131072,
        llm_node_url="http://localhost:8000/v1",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    fake_cert = _parse_certificate(fake_result.certificate)

    assert _get_subject_attr(real_cert, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "131072"
    assert _get_subject_attr(fake_cert, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "131072"


def test_certificate_subject_contains_csr_llm_node_url():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="test-model-name",
        model_id="test-model-id",
        model_quantization="Q4_K_M",
        model_context_window=4096,
        llm_node_url="https://gpu-server.example.com:9090/api/v2",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    fake_cert = _parse_certificate(fake_result.certificate)

    assert _get_subject_attr(real_cert, _OID_LLM_NODE_LLM_NODE_URL) == "https://gpu-server.example.com:9090/api/v2"
    assert _get_subject_attr(fake_cert, _OID_LLM_NODE_LLM_NODE_URL) == "https://gpu-server.example.com:9090/api/v2"


def test_certificate_is_signed_by_returned_ca():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="test-model-name",
        model_id="test-model-id",
        model_quantization="Q4_K_M",
        model_context_window=4096,
        llm_node_url="http://localhost:8000/v1",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    real_ca = _parse_certificate(real_result.ca_certificate)
    fake_cert = _parse_certificate(fake_result.certificate)
    fake_ca = _parse_certificate(fake_result.ca_certificate)

    # Verify issuer matches CA subject
    assert real_cert.issuer == real_ca.subject
    assert fake_cert.issuer == fake_ca.subject

    # Verify the signature is valid
    real_ca.public_key().verify(
        real_cert.signature,
        real_cert.tbs_certificate_bytes,
        padding.PKCS1v15(),
        hashes.SHA256(),
    )
    fake_ca.public_key().verify(
        fake_cert.signature,
        fake_cert.tbs_certificate_bytes,
        padding.PKCS1v15(),
        hashes.SHA256(),
    )


def test_certificate_public_key_matches_csr_key_pair():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="test-model-name",
        model_id="test-model-id",
        model_quantization="Q4_K_M",
        model_context_window=4096,
        llm_node_url="http://localhost:8000/v1",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    fake_cert = _parse_certificate(fake_result.certificate)

    expected_public_key_pem = private_key.public_key.pem

    real_public_key_pem = real_cert.public_key().public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    fake_public_key_pem = fake_cert.public_key().public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")

    assert real_public_key_pem == expected_public_key_pem
    assert fake_public_key_pem == expected_public_key_pem


def test_different_csr_values_produce_certificates_with_matching_subjects():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    private_key = KeyPairGenerator().generate()
    llm_node_csr = LlmNodeCsr(
        model_name="production-gpu-node-3",
        model_id="Qwen/Qwen2.5-72B-Instruct",
        model_quantization="FP16",
        model_context_window=32768,
        llm_node_url="https://10.0.1.50:443/inference",
    )
    csr_pem = CsrService().generate_csr(private_key, llm_node_csr)

    real_result = _register_llm_node(real_nexus, real_token, csr_pem, llm_node_csr)
    fake_result = _register_llm_node(fake_nexus, fake_token, csr_pem, llm_node_csr)

    real_cert = _parse_certificate(real_result.certificate)
    fake_cert = _parse_certificate(fake_result.certificate)

    for cert in [real_cert, fake_cert]:
        assert _get_subject_attr(cert, _OID_LLM_MODEL_NAME) == "production-gpu-node-3"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_ID) == "Qwen/Qwen2.5-72B-Instruct"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_QUANTIZATION) == "FP16"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "32768"
        assert _get_subject_attr(cert, _OID_LLM_NODE_LLM_NODE_URL) == "https://10.0.1.50:443/inference"


def test_two_registrations_produce_different_certificates():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    real_token = _login_and_create_token(real_nexus)
    fake_token = _login_and_create_token(fake_nexus)

    key1 = KeyPairGenerator().generate()
    csr1_data = LlmNodeCsr(
        model_name="node-1",
        model_id="model-a",
        model_quantization="Q4_K_M",
        model_context_window=4096,
        llm_node_url="http://localhost:8000/v1",
    )
    csr1_pem = CsrService().generate_csr(key1, csr1_data)

    key2 = KeyPairGenerator().generate()
    csr2_data = LlmNodeCsr(
        model_name="node-2",
        model_id="model-b",
        model_quantization="Q8_0",
        model_context_window=8192,
        llm_node_url="http://localhost:9000/v2",
    )
    csr2_pem = CsrService().generate_csr(key2, csr2_data)

    real_result1 = _register_llm_node(real_nexus, real_token, csr1_pem, csr1_data)
    real_result2 = _register_llm_node(real_nexus, real_token, csr2_pem, csr2_data)
    fake_result1 = _register_llm_node(fake_nexus, fake_token, csr1_pem, csr1_data)
    fake_result2 = _register_llm_node(fake_nexus, fake_token, csr2_pem, csr2_data)

    real_cert1 = _parse_certificate(real_result1.certificate)
    real_cert2 = _parse_certificate(real_result2.certificate)
    fake_cert1 = _parse_certificate(fake_result1.certificate)
    fake_cert2 = _parse_certificate(fake_result2.certificate)

    # First registration certificates should have node-1 attributes
    for cert in [real_cert1, fake_cert1]:
        assert _get_subject_attr(cert, _OID_LLM_MODEL_NAME) == "node-1"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_ID) == "model-a"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_QUANTIZATION) == "Q4_K_M"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "4096"
        assert _get_subject_attr(cert, _OID_LLM_NODE_LLM_NODE_URL) == "http://localhost:8000/v1"

    # Second registration certificates should have node-2 attributes
    for cert in [real_cert2, fake_cert2]:
        assert _get_subject_attr(cert, _OID_LLM_MODEL_NAME) == "node-2"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_ID) == "model-b"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_QUANTIZATION) == "Q8_0"
        assert _get_subject_attr(cert, _OID_LLM_NODE_MODEL_CONTEXT_WINDOW) == "8192"
        assert _get_subject_attr(cert, _OID_LLM_NODE_LLM_NODE_URL) == "http://localhost:9000/v2"

    # Certificates should have different serial numbers
    assert real_cert1.serial_number != real_cert2.serial_number
    assert fake_cert1.serial_number != fake_cert2.serial_number
