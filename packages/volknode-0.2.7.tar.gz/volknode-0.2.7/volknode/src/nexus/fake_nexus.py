import uuid
from dataclasses import dataclass

from volknode.src.nexus.fake_certificate_authority import FakeCertificateAuthority
from volknode.src.http_client.ai_suite_client.models.register_llm_node_request import RegisterLlmNodeRequest
from volknode.src.http_client.ai_suite_client.models.register_llm_node_response import RegisterLlmNodeResponse
from volknode.src.http_client.ai_suite_client.models.create_personal_access_token_request import CreatePersonalAccessTokenRequest
from volknode.src.http_client.ai_suite_client.models.logged_in_user import LoggedInUser
from volknode.src.http_client.ai_suite_client.models.login_with_credentials_request import LoginWithCredentialsRequest

from volknode.src.http_client.ai_suite_client.models.personal_access_token_created_successfully import PersonalAccessTokenCreatedSuccessfully
from volknode.src.http_client.ai_suite_client.models.successful_login_response import SuccessfulLoginResponse
from volknode.src.http_client.ai_suite_client.models.user_role import UserRole
from volknode.src.http_client.ai_suite_client.models.user_role_name import UserRoleName
from volknode.src.nexus.nexus import Nexus


@dataclass
class FakeUser:
    user_id: str
    username: str
    password: str
    role: UserRole


class FakeNexus(Nexus):
    def __init__(self):
        self._certificate_authority = FakeCertificateAuthority()
        self.registered_llm_nodes: list[RegisterLlmNodeResponse] = []
        self.created_personal_access_tokens: list[PersonalAccessTokenCreatedSuccessfully] = []
        self._logged_in_user: FakeUser | None = None
        self._users: list[FakeUser] = [
            FakeUser(
                user_id=str(uuid.uuid4()),
                username="root",
                password="password",
                role=UserRole(
                    id=str(uuid.uuid4()),
                    name=UserRoleName.SUPERADMIN,
                ),
            ),
        ]

    def register_llm_node(self, request: RegisterLlmNodeRequest) -> RegisterLlmNodeResponse:
        errors: list[str] = []

        if not request.model_name.strip():
            errors.append("Model name cannot be empty.")

        if not request.model_id.strip():
            errors.append("Model id cannot be empty.")

        if not request.quantization.strip():
            errors.append("Quantization cannot be empty.")

        if request.context_window <= 0:
            errors.append("Context window must be greater than 0.")

        llm_node_url = request.llm_node_url.strip()
        if not llm_node_url:
            errors.append("URL cannot be empty.")
        else:
            from urllib.parse import urlparse
            parsed = urlparse(llm_node_url)
            if parsed.scheme not in ("http", "https"):
                errors.append("URL scheme must be 'http' or 'https'.")
            if not parsed.hostname:
                errors.append("URL must contain a host.")

        if errors:
            raise RuntimeError("; ".join(errors))

        certificate_pem, ca_certificate_pem = self._certificate_authority.sign_csr(request.csr)
        response = RegisterLlmNodeResponse(
            id=str(uuid.uuid4()),
            model_name=request.model_name,
            certificate=certificate_pem,
            ca_certificate=ca_certificate_pem,
        )
        self.registered_llm_nodes.append(response)
        return response

    def login(self, request: LoginWithCredentialsRequest) -> SuccessfulLoginResponse:
        for user in self._users:
            if user.username == request.username and user.password == request.password:
                self._logged_in_user = user
                return SuccessfulLoginResponse(
                    logged_in_user=LoggedInUser(
                        user_id=user.user_id,
                        username=user.username,
                        role=user.role,
                    ),
                )
        raise RuntimeError("Invalid username or password")

    def create_personal_access_token(self, request: CreatePersonalAccessTokenRequest) -> PersonalAccessTokenCreatedSuccessfully:
        if self._logged_in_user is None:
            raise RuntimeError("Not authenticated")
        token = PersonalAccessTokenCreatedSuccessfully(
            id=str(uuid.uuid4()),
            name=request.name,
            plaintext_token=str(uuid.uuid4()),
        )
        self.created_personal_access_tokens.append(token)
        return token
