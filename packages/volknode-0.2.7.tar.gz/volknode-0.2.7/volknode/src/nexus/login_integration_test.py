import os
import subprocess
import pytest
import requests

from volknode.src.http_client.ai_suite_client.models.login_with_credentials_request import LoginWithCredentialsRequest
from volknode.src.http_client.ai_suite_client.models.successful_login_response import SuccessfulLoginResponse
from volknode.src.http_client.ai_suite_client.models.user_role_name import UserRoleName
from volknode.src.nexus.real_nexus import RealNexus
from volknode.src.nexus.fake_nexus import FakeNexus


def _get_nexus_url() -> str:
    container_name = os.environ.get("NEXUS_CONTAINER_NAME", "nexus")
    result = subprocess.run(
        ["docker", "inspect", "--format",
         '{{(index (index .NetworkSettings.Ports "8080/tcp") 0).HostPort}}',
         container_name],
        capture_output=True, text=True, check=True,
    )
    port = result.stdout.strip()
    host = os.environ.get("NEXUS_HOST", "localhost")
    return f"http://{host}:{port}"


NEXUS_URL = _get_nexus_url()


@pytest.fixture(autouse=True)
def reset_app():
    requests.post(f"{NEXUS_URL}/testing/reset-app")


def test_login_with_valid_credentials_returns_equivalent_response():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    request = LoginWithCredentialsRequest(username="root", password="password")

    real_result = real_nexus.login(request)
    fake_result = fake_nexus.login(request)

    assert isinstance(real_result, SuccessfulLoginResponse)
    assert isinstance(fake_result, SuccessfulLoginResponse)

    assert real_result.logged_in_user.username == fake_result.logged_in_user.username == "root"
    assert real_result.logged_in_user.role.name == fake_result.logged_in_user.role.name == UserRoleName.SUPERADMIN

    assert isinstance(real_result.logged_in_user.user_id, str) and len(real_result.logged_in_user.user_id) > 0
    assert isinstance(fake_result.logged_in_user.user_id, str) and len(fake_result.logged_in_user.user_id) > 0

    assert isinstance(real_result.logged_in_user.role.id, str) and len(real_result.logged_in_user.role.id) > 0
    assert isinstance(fake_result.logged_in_user.role.id, str) and len(fake_result.logged_in_user.role.id) > 0



def test_login_with_invalid_credentials_fails_on_both():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    request = LoginWithCredentialsRequest(username="root", password="wrong")

    with pytest.raises(RuntimeError):
        real_nexus.login(request)

    with pytest.raises(RuntimeError):
        fake_nexus.login(request)
