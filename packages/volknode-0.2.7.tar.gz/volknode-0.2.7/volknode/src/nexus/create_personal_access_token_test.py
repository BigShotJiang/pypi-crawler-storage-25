import datetime
import os
import subprocess
import pytest
import requests

from volknode.src.http_client.ai_suite_client.models.create_personal_access_token_request import CreatePersonalAccessTokenRequest
from volknode.src.http_client.ai_suite_client.models.login_with_credentials_request import LoginWithCredentialsRequest
from volknode.src.http_client.ai_suite_client.models.personal_access_token_created_successfully import PersonalAccessTokenCreatedSuccessfully
from volknode.src.nexus.real_nexus import RealNexus
from volknode.src.nexus.fake_nexus import FakeNexus


def _get_nexus_url() -> str:
    container_name = os.environ.get("NEXUS_CONTAINER_NAME", "nexus")
    result = subprocess.run(
        ["docker", "inspect", "--format",
         '{{(index (index .NetworkSettings.Ports "8080/tcp") 0).HostPort}}',
         container_name],
        capture_output=True, text=True, check=True,
    )
    port = result.stdout.strip()
    host = os.environ.get("NEXUS_HOST", "localhost")
    return f"http://{host}:{port}"


NEXUS_URL = _get_nexus_url()


@pytest.fixture(autouse=True)
def reset_app():
    requests.post(f"{NEXUS_URL}/testing/reset-app")


def _login(nexus):
    nexus.login(LoginWithCredentialsRequest(username="root", password="password"))


def test_create_personal_access_token_returns_equivalent_response():
    real_nexus = RealNexus(nexus_url=NEXUS_URL)
    fake_nexus = FakeNexus()

    _login(real_nexus)
    _login(fake_nexus)

    request = CreatePersonalAccessTokenRequest(
        name="test-token",
        scope_codes=["llm:manage"],
        expires_at=datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=30),
    )

    real_result = real_nexus.create_personal_access_token(request)
    fake_result = fake_nexus.create_personal_access_token(request)

    assert isinstance(real_result, PersonalAccessTokenCreatedSuccessfully)
    assert isinstance(fake_result, PersonalAccessTokenCreatedSuccessfully)

    assert real_result.name == fake_result.name == "test-token"

    assert isinstance(real_result.id, str) and len(real_result.id) > 0
    assert isinstance(fake_result.id, str) and len(fake_result.id) > 0

    assert isinstance(real_result.plaintext_token, str) and len(real_result.plaintext_token) > 0
    assert isinstance(fake_result.plaintext_token, str) and len(fake_result.plaintext_token) > 0


def test_create_personal_access_token_fails_without_login():
    fake_nexus = FakeNexus()

    request = CreatePersonalAccessTokenRequest(
        name="test-token",
        scope_codes=["llm:manage"],
        expires_at=datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=30),
    )

    with pytest.raises(RuntimeError):
        fake_nexus.create_personal_access_token(request)
