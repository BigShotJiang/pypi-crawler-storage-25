from abc import ABC, abstractmethod

from volknode.src.http_client.ai_suite_client.models.register_llm_node_request import RegisterLlmNodeRequest
from volknode.src.http_client.ai_suite_client.models.register_llm_node_response import RegisterLlmNodeResponse
from volknode.src.http_client.ai_suite_client.models.create_personal_access_token_request import CreatePersonalAccessTokenRequest
from volknode.src.http_client.ai_suite_client.models.login_with_credentials_request import LoginWithCredentialsRequest
from volknode.src.http_client.ai_suite_client.models.personal_access_token_created_successfully import PersonalAccessTokenCreatedSuccessfully
from volknode.src.http_client.ai_suite_client.models.successful_login_response import SuccessfulLoginResponse


class Nexus(ABC):
    @abstractmethod
    def register_llm_node(self, request: RegisterLlmNodeRequest) -> RegisterLlmNodeResponse:
        pass

    @abstractmethod
    def login(self, request: LoginWithCredentialsRequest) -> SuccessfulLoginResponse:
        pass

    @abstractmethod
    def create_personal_access_token(self, request: CreatePersonalAccessTokenRequest) -> PersonalAccessTokenCreatedSuccessfully:
        pass
