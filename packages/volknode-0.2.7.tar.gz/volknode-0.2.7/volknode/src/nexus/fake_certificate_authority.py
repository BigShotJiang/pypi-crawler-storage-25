import datetime
import os

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


class FakeCertificateAuthority:
    def __init__(self):
        self._ca_private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=4096,
        )

        self._ca_cert = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Nexus CA"),
                x509.NameAttribute(NameOID.COMMON_NAME, "Nexus Root CA"),
            ]))
            .issuer_name(x509.Name([
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Nexus CA"),
                x509.NameAttribute(NameOID.COMMON_NAME, "Nexus Root CA"),
            ]))
            .public_key(self._ca_private_key.public_key())
            .serial_number(1)
            .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
            .not_valid_after(datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=3650))
            .add_extension(x509.BasicConstraints(ca=True, path_length=1), critical=True)
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True,
                    key_cert_sign=True,
                    crl_sign=True,
                    content_commitment=False,
                    key_encipherment=False,
                    data_encipherment=False,
                    key_agreement=False,
                    encipher_only=False,
                    decipher_only=False,
                ),
                critical=True,
            )
            .sign(self._ca_private_key, hashes.SHA256())
        )

        self._ca_cert_pem = self._ca_cert.public_bytes(serialization.Encoding.PEM).decode("utf-8")

    def sign_csr(self, csr_pem: str) -> tuple[str, str]:
        """Sign a PEM-encoded CSR. Returns (certificate_pem, ca_certificate_pem)."""
        csr = x509.load_pem_x509_csr(csr_pem.encode("utf-8"))

        serial_number = int.from_bytes(os.urandom(16), byteorder="big")

        cert = (
            x509.CertificateBuilder()
            .subject_name(csr.subject)
            .issuer_name(self._ca_cert.subject)
            .public_key(csr.public_key())
            .serial_number(serial_number)
            .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
            .not_valid_after(datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=365))
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True,
                    key_encipherment=True,
                    content_commitment=False,
                    data_encipherment=False,
                    key_agreement=False,
                    key_cert_sign=False,
                    crl_sign=False,
                    encipher_only=False,
                    decipher_only=False,
                ),
                critical=True,
            )
            .add_extension(
                x509.ExtendedKeyUsage([
                    x509.oid.ExtendedKeyUsageOID.CLIENT_AUTH,
                    x509.oid.ExtendedKeyUsageOID.SERVER_AUTH,
                ]),
                critical=False,
            )
            .sign(self._ca_private_key, hashes.SHA256())
        )

        cert_pem = cert.public_bytes(serialization.Encoding.PEM).decode("utf-8")
        return cert_pem, self._ca_cert_pem

    @property
    def ca_certificate_pem(self) -> str:
        return self._ca_cert_pem
