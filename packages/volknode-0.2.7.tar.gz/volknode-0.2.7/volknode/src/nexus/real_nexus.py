from volknode.src.http_client.ai_suite_client.client import Client
from volknode.src.http_client.ai_suite_client.api.default.register_llm_node import sync as register_llm_node_sync
from volknode.src.http_client.ai_suite_client.api.default.login_with_credentials import sync_detailed as login_sync_detailed
from volknode.src.http_client.ai_suite_client.api.default.create_personal_access_token import sync as create_pat_sync
from volknode.src.http_client.ai_suite_client.models.register_llm_node_request import RegisterLlmNodeRequest
from volknode.src.http_client.ai_suite_client.models.register_llm_node_response import RegisterLlmNodeResponse
from volknode.src.http_client.ai_suite_client.models.create_personal_access_token_request import CreatePersonalAccessTokenRequest
from volknode.src.http_client.ai_suite_client.models.login_with_credentials_request import LoginWithCredentialsRequest
from volknode.src.http_client.ai_suite_client.models.personal_access_token_created_successfully import PersonalAccessTokenCreatedSuccessfully
from volknode.src.http_client.ai_suite_client.models.successful_login_response import SuccessfulLoginResponse
from volknode.src.http_client.ai_suite_client.models.error import Error
from volknode.src.nexus.nexus import Nexus


class RealNexus(Nexus):
    def __init__(self, nexus_url: str, verify_ssl: bool = True):
        self._client = Client(base_url=nexus_url, verify_ssl=verify_ssl)

    def register_llm_node(self, request: RegisterLlmNodeRequest) -> RegisterLlmNodeResponse:
        result = register_llm_node_sync(client=self._client, body=request)
        if result is None:
            raise RuntimeError("Unexpected response from server")
        if isinstance(result, Error):
            raise RuntimeError(f"{result.description}")
        return result

    def login(self, request: LoginWithCredentialsRequest) -> SuccessfulLoginResponse:
        response = login_sync_detailed(client=self._client, body=request)
        result = response.parsed
        if result is None:
            raise RuntimeError("Unexpected response from server")
        if isinstance(result, Error):
            raise RuntimeError(f"{result.description}")
        session_id = response.headers.get("set-cookie", "")
        for part in session_id.split(";"):
            part = part.strip()
            if part.startswith("session_id="):
                self._client = self._client.with_cookies({"session_id": part.split("=", 1)[1]})
                break
        return result

    def create_personal_access_token(self, request: CreatePersonalAccessTokenRequest) -> PersonalAccessTokenCreatedSuccessfully:
        result = create_pat_sync(client=self._client, body=request)
        if result is None:
            raise RuntimeError("Unexpected response from server")
        if isinstance(result, Error):
            raise RuntimeError(f"{result.description}")
        return result
