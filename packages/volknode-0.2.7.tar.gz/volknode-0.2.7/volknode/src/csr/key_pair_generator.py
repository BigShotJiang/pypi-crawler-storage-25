from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


class PublicKey:
    def __init__(self, pem: str):
        self.pem = pem


class PrivateKey:
    def __init__(self, pem: str, public_key: PublicKey):
        self.pem = pem
        self.public_key = public_key


class KeyPairGenerator:
    def generate(self) -> PrivateKey:
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )

        private_key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode("utf-8")

        public_key_pem = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("utf-8")

        return PrivateKey(private_key_pem, PublicKey(public_key_pem))
