from dataclasses import dataclass

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.x509 import ObjectIdentifier

from volknode.src.csr.key_pair_generator import PrivateKey

_OID_LLM_MODEL_NAME = ObjectIdentifier("1.3.6.1.4.1.99999.1.1")
_OID_LLM_NODE_MODEL_ID = ObjectIdentifier("1.3.6.1.4.1.99999.1.2")
_OID_LLM_NODE_MODEL_QUANTIZATION = ObjectIdentifier("1.3.6.1.4.1.99999.1.4")
_OID_LLM_NODE_MODEL_CONTEXT_WINDOW = ObjectIdentifier("1.3.6.1.4.1.99999.1.5")
_OID_LLM_NODE_LLM_NODE_URL = ObjectIdentifier("1.3.6.1.4.1.99999.1.10")


@dataclass
class LlmNodeCsr:
    model_name: str
    model_id: str
    model_quantization: str
    model_context_window: int
    llm_node_url: str


class CsrService:
    def generate_csr(self, private_key: PrivateKey, llm_node_csr: LlmNodeCsr) -> str:
        """Returns PEM-encoded CSR"""
        rsa_private_key = serialization.load_pem_private_key(
            private_key.pem.encode("utf-8"),
            password=None,
        )

        subject = x509.Name([
            x509.NameAttribute(_OID_LLM_MODEL_NAME, llm_node_csr.model_name),
            x509.NameAttribute(_OID_LLM_NODE_MODEL_ID, llm_node_csr.model_id),
            x509.NameAttribute(_OID_LLM_NODE_MODEL_QUANTIZATION, llm_node_csr.model_quantization),
            x509.NameAttribute(_OID_LLM_NODE_MODEL_CONTEXT_WINDOW, str(llm_node_csr.model_context_window)),
            x509.NameAttribute(_OID_LLM_NODE_LLM_NODE_URL, llm_node_csr.llm_node_url),
        ])

        csr = (
            x509.CertificateSigningRequestBuilder()
            .subject_name(subject)
            .sign(rsa_private_key, hashes.SHA256())
        )

        return csr.public_bytes(serialization.Encoding.PEM).decode("utf-8")
