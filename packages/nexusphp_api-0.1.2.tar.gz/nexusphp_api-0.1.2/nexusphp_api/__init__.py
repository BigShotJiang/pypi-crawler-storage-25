"""NexusPHP API Client - A Python client for interacting with NexusPHP forum API.

This package provides a convenient way to interact with the NexusPHP API,
supporting operations such as managing bookmarks, comments, torrents, and user profiles.

Example:
    >>> from nexusphp_api import NexusAPIClient
    >>> client = NexusAPIClient(token="your-token")
    >>> profile = client.profile.get_profile()
"""

__version__ = "0.1.2"
__author__ = "NexusPHP Team"
__license__ = "MIT"

from .api_client import NexusAPIClient, APIError

__all__ = ["NexusAPIClient", "APIError", "__version__"]
