from dataclasses import dataclass
from typing import Any, Optional, TypeVar, Type, cast
from .type_utils import from_str, from_int, from_float, to_class


T = TypeVar("T")


@dataclass
class BaseResponse:
    """Base response class"""
    """Result code, 0 = success, others = failure"""
    ret: int
    """Text message"""
    msg: str
    """Request ID"""
    rid: str
    """Response time in seconds"""
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'BaseResponse':
        assert isinstance(obj, dict)
        ret = from_int(obj.get("ret"))
        msg = from_str(obj.get("msg"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return BaseResponse(ret, msg, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["ret"] = from_int(self.ret)
        result["msg"] = from_str(self.msg)
        result["rid"] = from_str(self.rid)
        result["time"] = from_float(self.time)
        return result


@dataclass
class DataResponse(BaseResponse):
    """Response class with data"""
    data: Any

    @staticmethod
    def from_dict(obj: Any, data_class: Type[T]) -> 'DataResponse':
        assert isinstance(obj, dict)
        base = BaseResponse.from_dict(obj)
        data = data_class.from_dict(obj.get("data"))
        return DataResponse(base.ret, base.msg, base.rid, base.time, data)

    def to_dict(self) -> dict:
        result = super().to_dict()
        if hasattr(self.data, "to_dict"):
            result["data"] = self.data.to_dict()
        else:
            result["data"] = self.data
        return result
