from typing import Any, TypeVar, Type, cast, Callable, List, Dict, Optional, Union


T = TypeVar("T")
EnumT = TypeVar("EnumT")


def from_str(x: Any) -> str:
    """Convert any type to string"""
    assert isinstance(x, str)
    return x


def from_int(x: Any) -> int:
    """Convert any type to integer"""
    if isinstance(x, str):
        try:
            return int(x)
        except ValueError:
            assert False, f"Cannot convert string to integer: {x}"
    if isinstance(x, float):
        return int(x)
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def from_int_optional(x: Any) -> Optional[int]:
    """Convert any type to integer (supports null)"""
    if x is None:
        return None
    if isinstance(x, str):
        try:
            return int(x)
        except ValueError:
            assert False, f"Cannot convert string to integer: {x}"
    if isinstance(x, float):
        return int(x)
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def from_float(x: Any) -> float:
    """Convert any type to float"""
    if isinstance(x, str):
        try:
            return float(x)
        except ValueError:
            assert False, f"Cannot convert string to float: {x}"
    assert isinstance(x, (float, int)) and not isinstance(x, bool)
    return float(x)


def from_bool(x: Any) -> bool:
    """Convert any type to boolean"""
    assert isinstance(x, bool)
    return x


def from_none(x: Any) -> Any:
    """Convert any type to None"""
    assert x is None
    return x


def from_union(fs, x):
    """Convert from union type"""
    if x is None:
        for f in fs:
            if f == from_none:
                return f(x)
    for f in fs:
        if f == from_none:
            continue
        try:
            return f(x)
        except:
            pass
    assert False, f"Cannot convert {x} to any union type"


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    """Convert any type to list"""
    if x is None:
        return []
    assert isinstance(x, list)
    return [f(y) for y in x]


def from_dict(f: Callable[[Any], T], x: Any) -> Dict[str, T]:
    """Convert any type to dictionary"""
    if x is None:
        return {}
    assert isinstance(x, dict)
    return {k: f(v) for (k, v) in x.items()}


def to_float(x: Any) -> float:
    """Convert any type to float (for output)"""
    assert isinstance(x, float)
    return x


def to_class(c: Type[T], x: Any) -> dict:
    """Convert class instance to dictionary"""
    if x is None:
        return None
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


def to_enum(c: Type[EnumT], x: Any) -> EnumT:
    """Convert enum instance to its value"""
    if x is None:
        return None
    assert isinstance(x, c)
    return x.value
