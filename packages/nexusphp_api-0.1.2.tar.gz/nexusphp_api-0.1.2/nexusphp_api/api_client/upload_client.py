from typing import Optional, Dict, Any
from .client import Client
from ..api.torrent.upload.upload import Upload


class UploadClient(Client):
    """Upload API client"""
    
    def upload_torrent(
        self,
        name: str,
        torrent_file: bytes,
        descr: str,
        type: int,
        small_descr: Optional[str] = None,
        url: Optional[str] = None,
        tags: Optional[str] = None,
        pos_state: Optional[str] = "normal",
        pos_state_until: Optional[str] = None,
        pick_type: Optional[str] = "normal",
        uplver: Optional[str] = "no",
        source: Optional[int] = None,
        medium: Optional[int] = None,
        codec: Optional[int] = None,
        audiocodec: Optional[int] = None,
        standard: Optional[int] = None,
        processing: Optional[int] = None,
        team: Optional[int] = None,
        nfo: Optional[bytes] = None,
        technical_info: Optional[str] = None,
        price: Optional[int] = None,
        pt_gen: Optional[str] = None,
    ) -> Upload:
        """
        Publish torrent
        
        Args:
            name: Title
            torrent_file: Torrent file data
            descr: Description info
            type: Type/category ID
            small_descr: Subtitle
            url: IMDB link
            tags: Tag IDs, multiple separated by comma
            pos_state: Sticky position, normal/sticky/r_sticky
            pos_state_until: Sticky until time
            pick_type: Recommended movie, normal/hot/classic/recommended
            uplver: Anonymous, yes/no
            source: Subcategory source field
            medium: Subcategory medium field
            codec: Subcategory codec field
            audiocodec: Subcategory audiocodec field
            standard: Subcategory standard field
            processing: Subcategory processing field
            team: Subcategory team field
            nfo: NFO file data
            technical_info: MediaInfo
            price: Price
            pt_gen: PTGen link
            
        Returns:
            Upload: Upload response object
        """
        endpoint = "/api/v1/upload"
        
        files = {
            'file': ('torrent.torrent', torrent_file, 'application/x-bittorrent'),
        }
        
        data = {
            'name': name,
            'descr': descr,
            'type': type,
        }
        
        if small_descr:
            data['small_descr'] = small_descr
        if url:
            data['url'] = url
        if tags:
            data['tags'] = tags
        if pos_state:
            data['pos_state'] = pos_state
        if pos_state_until:
            data['pos_state_until'] = pos_state_until
        if pick_type:
            data['pick_type'] = pick_type
        if uplver:
            data['uplver'] = uplver
        if source is not None:
            data['source'] = source
        if medium is not None:
            data['medium'] = medium
        if codec is not None:
            data['codec'] = codec
        if audiocodec is not None:
            data['audiocodec'] = audiocodec
        if standard is not None:
            data['standard'] = standard
        if processing is not None:
            data['processing'] = processing
        if team is not None:
            data['team'] = team
        if technical_info:
            data['technical_info'] = technical_info
        if price is not None:
            data['price'] = price
        if pt_gen:
            data['pt_gen'] = pt_gen
            
        if nfo:
            files['nfo'] = ('nfo.nfo', nfo, 'application/octet-stream')
        
        response_data = self.post(endpoint, data=data, files=files)
        return Upload.from_dict(response_data)
