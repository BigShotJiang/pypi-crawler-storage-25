from typing import Optional, Dict, Any
from .client import Client
from ..api.comment.comments.comments import Comments


class CommentClient(Client):
    """Comment API client"""
    
    def get_comments(self, torrent_id: int) -> Comments:
        """
        Get torrent comment list
        
        Args:
            torrent_id: Torrent ID
            
        Returns:
            Comments: Comment list response object
            
        Compatible version: >= 1.9.14
        """
        endpoint = "/api/v1/comments"
        params = {"torrent_id": torrent_id}
        
        response_data = self.get(endpoint, params=params)
        return Comments.from_dict(response_data)
