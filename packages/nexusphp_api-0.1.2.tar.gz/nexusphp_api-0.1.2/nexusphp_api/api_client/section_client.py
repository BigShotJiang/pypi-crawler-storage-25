from typing import Dict, Any
from .client import Client
from ..api.section.sections.sections import Sections


class SectionClient(Client):
    """Section API client"""
    
    def get_sections(self) -> Sections:
        """
        Get section list
        
        Returns:
            Sections: Section list response object
            
        Compatible version: >= 1.9.0
        """
        endpoint = "/api/v1/sections"
        
        response_data = self.get(endpoint)
        return Sections.from_dict(response_data)
