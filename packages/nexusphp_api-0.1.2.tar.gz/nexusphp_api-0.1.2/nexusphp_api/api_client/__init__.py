from .client import Client, APIError
from .profile_client import ProfileClient
from .bookmark_client import BookmarkClient
from .comment_client import CommentClient
from .section_client import SectionClient
from .torrent_client import TorrentClient


class NexusAPIClient:
    """NexusPHP API client main class"""
    
    def __init__(self, base_url: str = "https://dev.nexusphp.org", token: str = ""):
        """
        Initialize NexusPHP API client
        
        Args:
            base_url: API base URL
            token: Bearer Token
        """
        self.base_url = base_url
        self.token = token
        
        # Initialize clients for each module
        self.profile = ProfileClient(base_url, token)
        self.bookmark = BookmarkClient(base_url, token)
        self.comment = CommentClient(base_url, token)
        self.section = SectionClient(base_url, token)
        self.torrent = TorrentClient(base_url, token)
    
    def set_token(self, token: str):
        """
        Set authentication token
        
        Args:
            token: Bearer Token
        """
        self.token = token
        # Update tokens for all clients
        self.profile.set_token(token)
        self.bookmark.set_token(token)
        self.comment.set_token(token)
        self.section.set_token(token)
        self.torrent.set_token(token)
    
    def set_base_url(self, base_url: str):
        """
        Set base URL
        
        Args:
            base_url: API base URL
        """
        self.base_url = base_url
        # Update base URLs for all clients
        self.profile.set_base_url(base_url)
        self.bookmark.set_base_url(base_url)
        self.comment.set_base_url(base_url)
        self.section.set_base_url(base_url)
        self.torrent.set_base_url(base_url)


__all__ = [
    "Client",
    "APIError",
    "ProfileClient",
    "BookmarkClient",
    "CommentClient",
    "SectionClient",
    "TorrentClient",
    "NexusAPIClient"
]
