from typing import Optional, Dict, Any
import requests


class APIError(Exception):
    """API error exception"""
    def __init__(self, status_code: int = None, message: str = None, response_data: Dict[str, Any] = None):
        self.status_code = status_code
        self.message = message
        self.response_data = response_data
        super().__init__(f"API Error {status_code}: {message}")


class ClientConfig:
    """Client configuration"""
    def __init__(self, max_retries: int = 3, retry_interval: float = 1.0):
        self.max_retries = max_retries
        self.retry_interval = retry_interval


class Client:
    """API client base class"""
    
    def __init__(self, base_url: str, token: str = None, config: ClientConfig = None):
        """
        Initialize client
        
        Args:
            base_url: API base URL
            token: Authentication token
            config: Client configuration
        """
        self.base_url = base_url.rstrip('/')
        self.token = token
        self.config = config or ClientConfig()
        self.timeout = 30
        
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
        })
        
        if token:
            self.session.headers.update({
                'Authorization': f'Bearer {token}',
            })
    
    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Send GET request
        
        Args:
            endpoint: API endpoint
            params: Query parameters
            
        Returns:
            Response data
            
        Raises:
            APIError: API error
        """
        url = f"{self.base_url}{endpoint}"
        return self._request("GET", url, params=params)
    
    def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None, files: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Send POST request
        
        Args:
            endpoint: API endpoint
            data: Request data
            files: File data (for upload)
            
        Returns:
            Response data
            
        Raises:
            APIError: API error
        """
        url = f"{self.base_url}{endpoint}"
        if files:
            return self._request("POST", url, data=data, files=files)
        else:
            return self._request("POST", url, json=data)
    
    def set_token(self, token: str):
        """
        Set authentication token
        
        Args:
            token: Bearer Token
        """
        self.token = token
        if token:
            self.session.headers.update({"Authorization": f"Bearer {token}"})
        else:
            self.session.headers.pop("Authorization", None)
    
    def set_base_url(self, base_url: str):
        """
        Set base URL
        
        Args:
            base_url: API base URL
        """
        self.base_url = base_url.rstrip("/")
    
    def _request(self, method: str, url: str, **kwargs) -> Dict[str, Any]:
        """
        Send request and handle response
        
        Args:
            method: Request method
            url: Request URL
            **kwargs: Other request parameters
            
        Returns:
            Response data
            
        Raises:
            APIError: API error
        """
        retries = 0
        max_retries = self.config.max_retries
        retry_interval = self.config.retry_interval
        
        while retries <= max_retries:
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    timeout=self.timeout,
                    **kwargs
                )
                
                if response.status_code >= 400:
                    raise APIError(
                        status_code=response.status_code,
                        message=response.text
                    )
                
                data = response.json()
                
                if data.get("ret") and data.get("ret") != 0:
                    raise APIError(
                        status_code=response.status_code,
                        message=data.get("msg", "Unknown error"),
                        response_data=data
                    )
                
                return data
                
            except requests.exceptions.RequestException as e:
                retries += 1
                if retries <= max_retries:
                    import time
                    time.sleep(retry_interval)
                else:
                    raise APIError(message=str(e))
