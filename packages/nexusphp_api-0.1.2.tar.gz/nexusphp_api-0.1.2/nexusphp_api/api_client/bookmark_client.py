from typing import Dict, Any
from .client import Client
from ..api.bookmark.bookmarks.bookmarks import Bookmarks
from ..api.bookmark.bookmarks_delete.bookmarks_delete import BookmarksDelete


class BookmarkClient(Client):
    """Bookmark API client"""
    
    def add_bookmark(self, torrent_id: int) -> Bookmarks:
        """
        Add bookmark
        
        Args:
            torrent_id: Torrent ID
            
        Returns:
            Bookmarks: Bookmark response object
        """
        endpoint = "/api/v1/bookmarks"
        data = {"torrent_id": torrent_id}
        
        response_data = self.post(endpoint, data=data)
        return Bookmarks.from_dict(response_data)
    
    def delete_bookmark(self, torrent_id: int) -> BookmarksDelete:
        """
        Delete bookmark
        
        Args:
            torrent_id: Torrent ID
            
        Returns:
            BookmarksDelete: Delete response object
        """
        endpoint = "/api/v1/bookmarks/delete"
        data = {"torrent_id": torrent_id}
        
        response_data = self.post(endpoint, data=data)
        return BookmarksDelete.from_dict(response_data)
