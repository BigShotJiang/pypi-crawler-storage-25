from typing import Optional, Dict, Any, List
from .client import Client
from ..api.torrent.torrents.torrents import Torrents
from ..api.torrent.detail.detail import Detail
from ..api.torrent.upload.upload import Upload


class TorrentClient(Client):
    """Torrent API client"""
    
    def get_torrents(self, 
                      section: Optional[str] = None, 
                      per_page: Optional[int] = None, 
                      page: Optional[int] = None, 
                      sorts: Optional[str] = None, 
                      filters: Optional[Dict[str, Any]] = None, 
                      includes: Optional[str] = None, 
                      include_fields: Optional[str] = None, 
                      include_counts: Optional[str] = None) -> Torrents:
        """
        Get torrent list
        
        Args:
            section: Section name, if not provided show default section
            per_page: Items per page
            page: Page number
            sorts: Sorting, multiple separated by comma, e.g., "-size,seeders"
            filters: Filter conditions, e.g., {"title": "2014", "bookmark": 1}
            includes: Include relations, e.g., "user,extra"
            include_fields: Include fields, e.g., "has_bookmarked,active_status"
            include_counts: Include stats, e.g., "claims"
            
        Returns:
            Torrents: Torrent list response object
            
        Compatible version: >= 1.9.0
        """
        # Build endpoint
        if section:
            endpoint = f"/api/v1/torrents/{section}"
        else:
            endpoint = "/api/v1/torrents"
        
        # Build query parameters
        params = {}
        if per_page:
            params["per_page"] = per_page
        if page:
            params["page"] = page
        if sorts:
            params["sorts"] = sorts
        if includes:
            params["includes"] = includes
        if include_fields:
            params["include_fields[torrent]"] = include_fields
        if include_counts:
            params["include_counts"] = include_counts
        
        # Handle filter conditions
        if filters:
            for key, value in filters.items():
                if isinstance(value, dict):
                    for op, val in value.items():
                        params[f"filter[{key}][{op}]"] = val
                else:
                    params[f"filter[{key}]"] = value
        
        # Send request
        response_data = self.get(endpoint, params=params)
        return Torrents.from_dict(response_data)
    
    def get_torrent_detail(self, torrent_id: int, 
                           includes: Optional[str] = None, 
                           include_fields: Optional[str] = None, 
                           include_counts: Optional[str] = None) -> Detail:
        """
        Get torrent details
        
        Args:
            torrent_id: Torrent ID
            includes: Include relations, e.g., "user,extra"
            include_fields: Include fields, e.g., "has_bookmarked,active_status"
            include_counts: Include stats, e.g., "claims"
            
        Returns:
            Detail: Torrent detail response object
        """
        endpoint = f"/api/v1/detail/{torrent_id}"
        
        params = {}
        if includes:
            params["includes"] = includes
        if include_fields:
            params["include_fields[torrent]"] = include_fields
        if include_counts:
            params["include_counts"] = include_counts
        
        response_data = self.get(endpoint, params=params)
        return Detail.from_dict(response_data)
    
    def upload_torrent(self, 
                       torrent_file: str, 
                       name: str, 
                       small_descr: str, 
                       descr: str, 
                       category: int, 
                       section: int, 
                       imdb: Optional[str] = None, 
                       tmdb: Optional[str] = None, 
                       tvdb: Optional[str] = None, 
                       douban: Optional[str] = None, 
                       tags: Optional[List[int]] = None, 
                       media_info: Optional[str] = None, 
                       nfo: Optional[str] = None, 
                       anonymous: Optional[int] = None, 
                       visible: Optional[int] = None, 
                       password: Optional[str] = None, 
                       free: Optional[int] = None, 
                       double_upload: Optional[int] = None, 
                       sticky: Optional[int] = None, 
                       reward: Optional[int] = None, 
                       pick: Optional[int] = None, 
                       upload_type: Optional[int] = None, 
                       source_sel: Optional[int] = None, 
                       codec_sel: Optional[int] = None, 
                       standard_sel: Optional[int] = None, 
                       team_sel: Optional[int] = None, 
                       medium_sel: Optional[int] = None, 
                       audiocodec_sel: Optional[int] = None, 
                       processing_sel: Optional[int] = None) -> Upload:
        """
        Upload torrent
        
        Args:
            torrent_file: Torrent file path
            name: Title
            small_descr: Subtitle
            descr: Description
            category: Category ID
            section: Section ID
            imdb: IMDB ID
            tmdb: TMDB ID
            tvdb: TVDB ID
            douban: Douban ID
            tags: Tag ID list
            media_info: MediaInfo info
            nfo: NFO file content
            anonymous: Anonymous (0/1)
            visible: Visible (0/1)
            password: Password
            free: Free leech (0/1)
            double_upload: Double upload (0/1)
            sticky: Sticky (0/1)
            reward: Reward (0/1)
            pick: Recommended (0/1)
            upload_type: Upload type
            source_sel: Source selection
            codec_sel: Codec selection
            standard_sel: Standard/resolution selection
            team_sel: Team selection
            medium_sel: Medium selection
            audiocodec_sel: Audio codec selection
            processing_sel: Processing selection
            
        Returns:
            Upload: Upload response object
        """
        endpoint = "/api/v1/torrents/upload"
        
        # Prepare form data
        data = {
            "name": name,
            "small_descr": small_descr,
            "descr": descr,
            "category": category,
            "section": section
        }
        
        # Add optional parameters
        if imdb:
            data["imdb"] = imdb
        if tmdb:
            data["tmdb"] = tmdb
        if tvdb:
            data["tvdb"] = tvdb
        if douban:
            data["douban"] = douban
        if tags:
            data["tags"] = tags
        if media_info:
            data["media_info"] = media_info
        if nfo:
            data["nfo"] = nfo
        if anonymous is not None:
            data["anonymous"] = anonymous
        if visible is not None:
            data["visible"] = visible
        if password:
            data["password"] = password
        if free is not None:
            data["free"] = free
        if double_upload is not None:
            data["double_upload"] = double_upload
        if sticky is not None:
            data["sticky"] = sticky
        if reward is not None:
            data["reward"] = reward
        if pick is not None:
            data["pick"] = pick
        if upload_type is not None:
            data["upload_type"] = upload_type
        if source_sel is not None:
            data["source_sel"] = source_sel
        if codec_sel is not None:
            data["codec_sel"] = codec_sel
        if standard_sel is not None:
            data["standard_sel"] = standard_sel
        if team_sel is not None:
            data["team_sel"] = team_sel
        if medium_sel is not None:
            data["medium_sel"] = medium_sel
        if audiocodec_sel is not None:
            data["audiocodec_sel"] = audiocodec_sel
        if processing_sel is not None:
            data["processing_sel"] = processing_sel
        
        # Prepare files
        files = {
            "torrent_file": open(torrent_file, "rb")
        }
        
        try:
            response_data = self.post(endpoint, data=data, files=files)
            return Upload.from_dict(response_data)
        finally:
            # Close file
            files["torrent_file"].close()
