from typing import Optional, Dict, Any
from .client import Client
from ..api.user.profile.profile import Profile


class ProfileClient(Client):
    """User profile API client"""
    
    def get_profile(self, user_id: Optional[int] = None, includes: Optional[str] = None, include_fields: Optional[str] = None) -> Profile:
        """
        Get user details
        
        Args:
            user_id: User ID, if not provided get current user
            includes: Include relations, e.g., "inviter,valid_medals"
            include_fields: Include fields, e.g., "seeding_leeching_data"
            
        Returns:
            Profile: User profile object
            
        Compatible version: >= 1.9.0
        """
        # Build endpoint
        if user_id:
            endpoint = f"/api/v1/profile/{user_id}"
        else:
            endpoint = "/api/v1/profile"
        
        # Build query parameters
        params = {}
        if includes:
            params["includes"] = includes
        if include_fields:
            params["include_fields[user]"] = include_fields
        
        # Send request
        data = self.get(endpoint, params=params)
        
        # Parse response
        return Profile.from_dict(data)
