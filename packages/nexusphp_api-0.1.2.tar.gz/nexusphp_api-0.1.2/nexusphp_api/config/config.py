import os
from typing import Dict, Any, Optional


class Config:
    """Project configuration management"""
    
    def __init__(self):
        """Initialize configuration"""
        # API configuration
        self.api_base_url = os.environ.get("API_BASE_URL", "https://api.nexusphp.org")
        self.api_timeout = int(os.environ.get("API_TIMEOUT", "30"))
        
        # Authentication configuration
        self.token = os.environ.get("API_TOKEN", "")
        
        # Logging configuration
        self.log_level = os.environ.get("LOG_LEVEL", "INFO")
        self.log_file = os.environ.get("LOG_FILE", "api.log")
        
        # Other configurations
        self.max_retries = int(os.environ.get("MAX_RETRIES", "3"))
        self.retry_interval = float(os.environ.get("RETRY_INTERVAL", "1.0"))
    
    @property
    def headers(self) -> Dict[str, str]:
        """Get default request headers"""
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration item"""
        return getattr(self, key, default)
    
    def set(self, key: str, value: Any) -> None:
        """Set configuration item"""
        setattr(self, key, value)


# Create global configuration instance
config = Config()


def get_config() -> Config:
    """Get configuration instance"""
    return config
