from typing import Dict, Any, TypeVar, Callable
from ....utils import from_dict


T = TypeVar("T")


def body_from_dict(s: Any) -> Dict[str, Any]:
    return from_dict(lambda x: x, s)


def body_to_dict(x: Dict[str, Any]) -> Any:
    return from_dict(lambda x: x, x)
