from dataclasses import dataclass
from typing import Any, Optional, List, TypeVar, Type, Callable
from ....utils import from_float, from_int, from_str, from_none, from_union, to_class, from_list


T = TypeVar("T")


@dataclass
class Category:
    """Category info"""
    """Category ID"""
    id: int
    """Category name"""
    name: str

    @staticmethod
    def from_dict(obj: Any) -> 'Category':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        return Category(id, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        return result


@dataclass
class Tag:
    """Tag info"""
    """Tag ID"""
    id: int
    """Tag name"""
    name: str
    """Background color"""
    color: str
    """Font color"""
    font_color: str
    """Font size"""
    font_size: str
    """Padding"""
    padding: str
    """Margin"""
    margin: str
    """Border radius"""
    border_radius: str
    """Priority"""
    priority: int
    """Created at"""
    created_at: str
    """Updated at"""
    updated_at: str

    @staticmethod
    def from_dict(obj: Any) -> 'Tag':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        color = from_str(obj.get("color"))
        font_color = from_str(obj.get("font_color"))
        font_size = from_str(obj.get("font_size"))
        padding = from_str(obj.get("padding"))
        margin = from_str(obj.get("margin"))
        border_radius = from_str(obj.get("border_radius"))
        priority = from_int(obj.get("priority"))
        created_at = from_str(obj.get("created_at"))
        updated_at = from_str(obj.get("updated_at"))
        return Tag(id, name, color, font_color, font_size, padding, margin, border_radius, priority, created_at, updated_at)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        result["color"] = from_str(self.color)
        result["font_color"] = from_str(self.font_color)
        result["font_size"] = from_str(self.font_size)
        result["padding"] = from_str(self.padding)
        result["margin"] = from_str(self.margin)
        result["border_radius"] = from_str(self.border_radius)
        result["priority"] = from_int(self.priority)
        result["created_at"] = from_str(self.created_at)
        result["updated_at"] = from_str(self.updated_at)
        return result


@dataclass
class SubCategoryData:
    """Subcategory data"""
    """Subcategory ID"""
    id: int
    """Subcategory name"""
    name: str

    @staticmethod
    def from_dict(obj: Any) -> 'SubCategoryData':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        return SubCategoryData(id, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        return result


@dataclass
class SubCategory:
    """Subcategory info"""
    """Field name"""
    field: str
    """Label"""
    label: str
    """Data"""
    data: List[SubCategoryData]

    @staticmethod
    def from_dict(obj: Any) -> 'SubCategory':
        assert isinstance(obj, dict)
        field = from_str(obj.get("field"))
        label = from_str(obj.get("label"))
        data = from_list(SubCategoryData.from_dict, obj.get("data"))
        return SubCategory(field, label, data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["field"] = from_str(self.field)
        result["label"] = from_str(self.label)
        result["data"] = from_list(lambda x: to_class(SubCategoryData, x), self.data)
        return result


@dataclass
class Section:
    """Section info"""
    """Section ID"""
    id: int
    """Section name"""
    name: str
    """Section display name"""
    display_name: str
    """Categories"""
    categories: List[Category]
    """Tags"""
    tags: List[Tag]
    """Subcategories"""
    sub_categories: List[SubCategory]

    @staticmethod
    def from_dict(obj: Any) -> 'Section':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        display_name = from_str(obj.get("display_name"))
        categories = from_list(Category.from_dict, obj.get("categories"))
        tags = from_list(Tag.from_dict, obj.get("tags"))
        sub_categories = from_list(SubCategory.from_dict, obj.get("sub_categories"))
        return Section(id, name, display_name, categories, tags, sub_categories)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        result["display_name"] = from_str(self.display_name)
        result["categories"] = from_list(lambda x: to_class(Category, x), self.categories)
        result["tags"] = from_list(lambda x: to_class(Tag, x), self.tags)
        result["sub_categories"] = from_list(lambda x: to_class(SubCategory, x), self.sub_categories)
        return result


@dataclass
class DataData:
    """Data wrapper"""
    """Section data"""
    data: List[Section]

    @staticmethod
    def from_dict(obj: Any) -> 'DataData':
        assert isinstance(obj, dict)
        data = from_list(Section.from_dict, obj.get("data"))
        return DataData(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(Section, x), self.data)
        return result


@dataclass
class Sections:
    """Section response"""
    """Data"""
    data: DataData
    """Message"""
    msg: str
    """Result code, 0 means success, others mean failure"""
    ret: int
    """Request ID"""
    rid: str
    """Response time in seconds"""
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'Sections':
        assert isinstance(obj, dict)
        data = DataData.from_dict(obj.get("data"))
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return Sections(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(DataData, self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = from_float(self.time)
        return result


def sections_from_dict(s: Any) -> Sections:
    return Sections.from_dict(s)


def sections_to_dict(x: Sections) -> Any:
    return to_class(Sections, x)
