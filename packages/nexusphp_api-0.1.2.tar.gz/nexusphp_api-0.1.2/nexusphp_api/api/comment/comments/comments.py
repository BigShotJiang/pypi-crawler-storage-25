from enum import Enum
from dataclasses import dataclass
from typing import Optional, Any, List, TypeVar, Type, Callable
from ....utils import from_str, from_int, from_float, from_none, from_union, to_float, to_enum, to_class, from_bool, from_list, from_int_optional


T = TypeVar("T")
EnumT = TypeVar("EnumT", bound=Enum)


class Enabled(Enum):
    """Enabled status"""
    NO = "no"
    YES = "yes"


class Status(Enum):
    """Confirmation status"""
    CONFIRMED = "confirmed"
    PENDING = "pending"


@dataclass
class UserBasicInfo:
    """Commenter info"""
    """User basic info, poster info"""
    """Editor info"""
    """Registration time"""
    added: str
    """Registration time formatted"""
    added_human: str
    """Attendance card count"""
    attendance_card: int
    """Avatar URL"""
    avatar: str
    """Bonus points"""
    bonus: float
    """Bonus points formatted"""
    bonus_human: str
    """User class"""
    user_class: int
    """User class name"""
    class_text: str
    """Downloaded bytes"""
    downloaded: int
    """Downloaded bytes formatted"""
    downloaded_text: str
    """Enabled status"""
    enabled: Enabled
    """User ID"""
    id: int
    """Invite count"""
    invites: int
    """Last active time"""
    last_access: str
    """Last active time formatted"""
    last_access_human: str
    """Last login time"""
    last_login: str
    """Last login time formatted"""
    last_login_human: str
    """Leech time in seconds"""
    leechtime: int
    """Leech time formatted"""
    leechtime_text: str
    """Seed bonus per hour. Compatible with >=1.9.13"""
    seed_bonus_per_hour: int
    """Seed bonus per hour formatted. Compatible with >=1.9.13"""
    seed_bonus_per_hour_human: str
    """Seed points"""
    seed_points: float
    """Seed points formatted"""
    seed_points_human: str
    """Seed points per hour. Compatible with >=1.9.13"""
    seed_points_per_hour: int
    """Seed points per hour formatted. Compatible with >=1.9.13"""
    seed_points_per_hour_human: str
    """Seed time in seconds"""
    seedtime: int
    """Seed time formatted"""
    seedtime_text: str
    """Share ratio rich text"""
    share_ratio: str
    """Confirmation status"""
    status: Status
    """Uploaded bytes"""
    uploaded: int
    """Uploaded bytes formatted"""
    uploaded_text: str
    """Username"""
    username: str
    """Email, only present if user has permission to view"""
    email: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'UserBasicInfo':
        assert isinstance(obj, dict)
        added = from_str(obj.get("added"))
        added_human = from_str(obj.get("added_human"))
        attendance_card = from_int(obj.get("attendance_card"))
        avatar = from_str(obj.get("avatar"))
        bonus = from_float(obj.get("bonus"))
        bonus_human = from_str(obj.get("bonus_human"))
        user_class = from_int(obj.get("class"))
        class_text = from_str(obj.get("class_text"))
        downloaded = from_int(obj.get("downloaded"))
        downloaded_text = from_str(obj.get("downloaded_text"))
        enabled = Enabled(obj.get("enabled"))
        id = from_int(obj.get("id"))
        invites = from_int(obj.get("invites"))
        last_access = from_str(obj.get("last_access"))
        last_access_human = from_str(obj.get("last_access_human"))
        last_login = from_str(obj.get("last_login"))
        last_login_human = from_str(obj.get("last_login_human"))
        leechtime = from_int(obj.get("leechtime"))
        leechtime_text = from_str(obj.get("leechtime_text"))
        seed_bonus_per_hour = from_int(obj.get("seed_bonus_per_hour"))
        seed_bonus_per_hour_human = from_str(obj.get("seed_bonus_per_hour_human"))
        seed_points = from_float(obj.get("seed_points"))
        seed_points_human = from_str(obj.get("seed_points_human"))
        seed_points_per_hour = from_int(obj.get("seed_points_per_hour"))
        seed_points_per_hour_human = from_str(obj.get("seed_points_per_hour_human"))
        seedtime = from_int(obj.get("seedtime"))
        seedtime_text = from_str(obj.get("seedtime_text"))
        share_ratio = from_str(obj.get("share_ratio"))
        status = Status(obj.get("status"))
        uploaded = from_int(obj.get("uploaded"))
        uploaded_text = from_str(obj.get("uploaded_text"))
        username = from_str(obj.get("username"))
        email = from_union([from_str, from_none], obj.get("email"))
        return UserBasicInfo(added, added_human, attendance_card, avatar, bonus, bonus_human, user_class, class_text, downloaded, downloaded_text, enabled, id, invites, last_access, last_access_human, last_login, last_login_human, leechtime, leechtime_text, seed_bonus_per_hour, seed_bonus_per_hour_human, seed_points, seed_points_human, seed_points_per_hour, seed_points_per_hour_human, seedtime, seedtime_text, share_ratio, status, uploaded, uploaded_text, username, email)

    def to_dict(self) -> dict:
        result: dict = {}
        result["added"] = from_str(self.added)
        result["added_human"] = from_str(self.added_human)
        result["attendance_card"] = from_int(self.attendance_card)
        result["avatar"] = from_str(self.avatar)
        result["bonus"] = to_float(self.bonus)
        result["bonus_human"] = from_str(self.bonus_human)
        result["class"] = from_int(self.user_class)
        result["class_text"] = from_str(self.class_text)
        result["downloaded"] = from_int(self.downloaded)
        result["downloaded_text"] = from_str(self.downloaded_text)
        result["enabled"] = to_enum(Enabled, self.enabled)
        result["id"] = from_int(self.id)
        result["invites"] = from_int(self.invites)
        result["last_access"] = from_str(self.last_access)
        result["last_access_human"] = from_str(self.last_access_human)
        result["last_login"] = from_str(self.last_login)
        result["last_login_human"] = from_str(self.last_login_human)
        result["leechtime"] = from_int(self.leechtime)
        result["leechtime_text"] = from_str(self.leechtime_text)
        result["seed_bonus_per_hour"] = from_int(self.seed_bonus_per_hour)
        result["seed_bonus_per_hour_human"] = from_str(self.seed_bonus_per_hour_human)
        result["seed_points"] = to_float(self.seed_points)
        result["seed_points_human"] = from_str(self.seed_points_human)
        result["seed_points_per_hour"] = from_int(self.seed_points_per_hour)
        result["seed_points_per_hour_human"] = from_str(self.seed_points_per_hour_human)
        result["seedtime"] = from_int(self.seedtime)
        result["seedtime_text"] = from_str(self.seedtime_text)
        result["share_ratio"] = from_str(self.share_ratio)
        result["status"] = to_enum(Status, self.status)
        result["uploaded"] = from_int(self.uploaded)
        result["uploaded_text"] = from_str(self.uploaded_text)
        result["username"] = from_str(self.username)
        if self.email is not None:
            result["email"] = from_union([from_str, from_none], self.email)
        return result


@dataclass
class Datum:
    """Comment basic info"""
    """Commenter info"""
    create_user: UserBasicInfo
    """Created at"""
    created_at: str
    """Comment ID"""
    id: int
    """Comment content (bbcode)"""
    text: str
    """Updated at"""
    updated_at: str
    """Editor info"""
    update_user: Optional[UserBasicInfo] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Datum':
        assert isinstance(obj, dict)
        create_user = UserBasicInfo.from_dict(obj.get("create_user"))
        created_at = from_str(obj.get("created_at"))
        id = from_int(obj.get("id"))
        text = from_str(obj.get("text"))
        updated_at = from_str(obj.get("updated_at"))
        update_user = from_union([UserBasicInfo.from_dict, from_none], obj.get("update_user"))
        return Datum(create_user, created_at, id, text, updated_at, update_user)

    def to_dict(self) -> dict:
        result: dict = {}
        result["create_user"] = to_class(UserBasicInfo, self.create_user)
        result["created_at"] = from_str(self.created_at)
        result["id"] = from_int(self.id)
        result["text"] = from_str(self.text)
        result["updated_at"] = from_str(self.updated_at)
        if self.update_user is not None:
            result["update_user"] = from_union([lambda x: to_class(UserBasicInfo, x), from_none], self.update_user)
        return result


@dataclass
class PaginationLinks:
    """Pagination link info"""
    """First page link"""
    first: str
    """Last page link"""
    last: str
    """Next page link"""
    next: Optional[str] = None
    """Previous page link"""
    prev: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'PaginationLinks':
        assert isinstance(obj, dict)
        first = from_str(obj.get("first"))
        last = from_str(obj.get("last"))
        next = from_union([from_none, from_str], obj.get("next"))
        prev = from_union([from_none, from_str], obj.get("prev"))
        return PaginationLinks(first, last, next, prev)

    def to_dict(self) -> dict:
        result: dict = {}
        result["first"] = from_str(self.first)
        result["last"] = from_str(self.last)
        result["next"] = from_union([from_none, from_str], self.next)
        result["prev"] = from_union([from_none, from_str], self.prev)
        return result


@dataclass
class Link:
    """Pagination item"""
    """Is current page"""
    active: bool
    """Page number text"""
    label: str
    """Pagination link"""
    url: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Link':
        assert isinstance(obj, dict)
        active = from_bool(obj.get("active"))
        label = from_str(obj.get("label"))
        url = from_union([from_none, from_str], obj.get("url"))
        return Link(active, label, url)

    def to_dict(self) -> dict:
        result: dict = {}
        result["active"] = from_bool(self.active)
        result["label"] = from_str(self.label)
        result["url"] = from_union([from_none, from_str], self.url)
        return result


@dataclass
class PaginationMeta:
    """Pagination meta info"""
    """Current page number"""
    current_page: int
    """Data start index"""
    meta_from: int
    """Last page number"""
    last_page: int
    """Pagination info"""
    links: List[Link]
    """Current link path"""
    path: str
    """Items per page"""
    per_page: int
    """Data end index"""
    to: int
    """Total record count"""
    total: int

    @staticmethod
    def from_dict(obj: Any) -> 'PaginationMeta':
        assert isinstance(obj, dict)
        current_page = from_int(obj.get("current_page"))
        meta_from = from_int_optional(obj.get("from"))
        last_page = from_int(obj.get("last_page"))
        links = from_list(Link.from_dict, obj.get("links"))
        path = from_str(obj.get("path"))
        per_page = from_int(obj.get("per_page"))
        meta_to = from_int_optional(obj.get("to"))
        total = from_int(obj.get("total"))
        return PaginationMeta(current_page, meta_from, last_page, links, path, per_page, meta_to, total)

    def to_dict(self) -> dict:
        result: dict = {}
        result["current_page"] = from_int(self.current_page)
        if self.meta_from is not None:
            result["from"] = from_int(self.meta_from)
        result["last_page"] = from_int(self.last_page)
        result["links"] = from_list(lambda x: to_class(Link, x), self.links)
        result["path"] = from_str(self.path)
        result["per_page"] = from_int(self.per_page)
        if self.to is not None:
            result["to"] = from_int(self.to)
        result["total"] = from_int(self.total)
        return result


@dataclass
class Data:
    """Data wrapper"""
    """Comment data list"""
    data: List[Datum]
    links: PaginationLinks
    meta: PaginationMeta

    @staticmethod
    def from_dict(obj: Any) -> 'Data':
        assert isinstance(obj, dict)
        data = from_list(Datum.from_dict, obj.get("data"))
        links = PaginationLinks.from_dict(obj.get("links"))
        meta = PaginationMeta.from_dict(obj.get("meta"))
        return Data(data, links, meta)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(Datum, x), self.data)
        result["links"] = to_class(PaginationLinks, self.links)
        result["meta"] = to_class(PaginationMeta, self.meta)
        return result


@dataclass
class Comments:
    """Data wrapper"""
    data: Data
    """Text message"""
    msg: str
    """Result code, 0 means success, others mean failure"""
    ret: int
    """Request ID"""
    rid: str
    """Response time in seconds"""
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'Comments':
        assert isinstance(obj, dict)
        data = Data.from_dict(obj.get("data"))
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return Comments(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(Data, self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = to_float(self.time)
        return result


def comments_from_dict(s: Any) -> Comments:
    return Comments.from_dict(s)


def comments_to_dict(x: Comments) -> Any:
    return to_class(Comments, x)
