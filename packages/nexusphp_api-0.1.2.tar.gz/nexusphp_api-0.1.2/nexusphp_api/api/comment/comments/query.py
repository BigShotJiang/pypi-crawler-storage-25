from dataclasses import dataclass
from typing import Optional, Any, TypeVar, Type
from ....utils import from_int, from_none, from_union, to_class


T = TypeVar("T")


@dataclass
class Query:
    """Torrent ID"""
    torrent_id: Optional[int] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Query':
        assert isinstance(obj, dict)
        torrent_id = from_union([from_int, from_none], obj.get("torrent_id"))
        return Query(torrent_id)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.torrent_id is not None:
            result["torrent_id"] = from_union([from_int, from_none], self.torrent_id)
        return result


def query_from_dict(s: Any) -> Query:
    return Query.from_dict(s)


def query_to_dict(x: Query) -> Any:
    return to_class(Query, x)
