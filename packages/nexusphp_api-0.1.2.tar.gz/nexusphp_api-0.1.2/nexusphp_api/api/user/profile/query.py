from dataclasses import dataclass
from typing import Optional, Any, TypeVar, Type
from ....utils import from_str, from_none, from_union, to_class


T = TypeVar("T")


@dataclass
class Query:
    """seeding_leeching_data: seeding and leeching data"""
    include_fields_user: Optional[str] = None
    """inviter: inviter, valid_medals: valid medals"""
    includes: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Query':
        assert isinstance(obj, dict)
        include_fields_user = from_union([from_str, from_none], obj.get("include_fields[user]"))
        includes = from_union([from_str, from_none], obj.get("includes"))
        return Query(include_fields_user, includes)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.include_fields_user is not None:
            result["include_fields[user]"] = from_union([from_str, from_none], self.include_fields_user)
        if self.includes is not None:
            result["includes"] = from_union([from_str, from_none], self.includes)
        return result


def query_from_dict(s: Any) -> Query:
    return Query.from_dict(s)


def query_to_dict(x: Query) -> Any:
    return to_class(Query, x)
