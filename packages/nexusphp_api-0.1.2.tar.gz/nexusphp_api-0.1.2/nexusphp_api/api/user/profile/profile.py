from enum import Enum
from typing import Optional, Any, List, TypeVar, Type, Callable, cast
from ....utils import from_str, from_int, from_float, from_bool, from_none, from_union, to_float, to_enum, to_class, from_list, from_int_optional


T = TypeVar("T")
EnumT = TypeVar("EnumT", bound=Enum)


class Enabled(Enum):
    """Enabled status"""
    NO = "no"
    YES = "yes"


class Status(Enum):
    """Confirmation status"""
    CONFIRMED = "confirmed"
    PENDING = "pending"


class UserBasicInfo:
    """User basic info, poster info"""
    """Registration time"""
    added: str
    """Registration time formatted"""
    added_human: str
    """Attendance card count"""
    attendance_card: int
    """Avatar URL"""
    avatar: str
    """Bonus points"""
    bonus: float
    """Bonus points formatted"""
    bonus_human: str
    """User class"""
    user_class: int
    """User class name"""
    class_text: str
    """Downloaded bytes"""
    downloaded: int
    """Downloaded bytes formatted"""
    downloaded_text: str
    """Email, only present if user has permission to view"""
    email: Optional[str]
    """Enabled status"""
    enabled: Enabled
    """User ID"""
    id: int
    """Invite count"""
    invites: int
    """Last active time"""
    last_access: str
    """Last active time formatted"""
    last_access_human: str
    """Last login time"""
    last_login: str
    """Last login time formatted"""
    last_login_human: str
    """Leech time in seconds"""
    leechtime: int
    """Leech time formatted"""
    leechtime_text: str
    """Seed bonus per hour. Compatible with >=1.9.13"""
    seed_bonus_per_hour: int
    """Seed bonus per hour formatted. Compatible with >=1.9.13"""
    seed_bonus_per_hour_human: str
    """Seed points"""
    seed_points: float
    """Seed points formatted"""
    seed_points_human: str
    """Seed points per hour. Compatible with >=1.9.13"""
    seed_points_per_hour: int
    """Seed points per hour formatted. Compatible with >=1.9.13"""
    seed_points_per_hour_human: str
    """Seed time in seconds"""
    seedtime: int
    """Seed time formatted"""
    seedtime_text: str
    """Share ratio rich text"""
    share_ratio: str
    """Confirmation status"""
    status: Status
    """Uploaded bytes"""
    uploaded: int
    """Uploaded bytes formatted"""
    uploaded_text: str
    """Username"""
    username: str

    def __init__(self, added: str, added_human: str, attendance_card: int, avatar: str, bonus: float, bonus_human: str, user_class: int, class_text: str, downloaded: int, downloaded_text: str, email: Optional[str], enabled: Enabled, id: int, invites: int, last_access: str, last_access_human: str, last_login: str, last_login_human: str, leechtime: int, leechtime_text: str, seed_bonus_per_hour: int, seed_bonus_per_hour_human: str, seed_points: float, seed_points_human: str, seed_points_per_hour: int, seed_points_per_hour_human: str, seedtime: int, seedtime_text: str, share_ratio: str, status: Status, uploaded: int, uploaded_text: str, username: str) -> None:
        self.added = added
        self.added_human = added_human
        self.attendance_card = attendance_card
        self.avatar = avatar
        self.bonus = bonus
        self.bonus_human = bonus_human
        self.user_class = user_class
        self.class_text = class_text
        self.downloaded = downloaded
        self.downloaded_text = downloaded_text
        self.email = email
        self.enabled = enabled
        self.id = id
        self.invites = invites
        self.last_access = last_access
        self.last_access_human = last_access_human
        self.last_login = last_login
        self.last_login_human = last_login_human
        self.leechtime = leechtime
        self.leechtime_text = leechtime_text
        self.seed_bonus_per_hour = seed_bonus_per_hour
        self.seed_bonus_per_hour_human = seed_bonus_per_hour_human
        self.seed_points = seed_points
        self.seed_points_human = seed_points_human
        self.seed_points_per_hour = seed_points_per_hour
        self.seed_points_per_hour_human = seed_points_per_hour_human
        self.seedtime = seedtime
        self.seedtime_text = seedtime_text
        self.share_ratio = share_ratio
        self.status = status
        self.uploaded = uploaded
        self.uploaded_text = uploaded_text
        self.username = username

    @staticmethod
    def from_dict(obj: Any) -> 'UserBasicInfo':
        assert isinstance(obj, dict)
        added = from_str(obj.get("added"))
        added_human = from_str(obj.get("added_human"))
        attendance_card = from_int(obj.get("attendance_card"))
        avatar = from_str(obj.get("avatar"))
        bonus = from_float(obj.get("bonus"))
        bonus_human = from_str(obj.get("bonus_human"))
        user_class = from_int(obj.get("class"))
        class_text = from_str(obj.get("class_text"))
        downloaded = from_int(obj.get("downloaded"))
        downloaded_text = from_str(obj.get("downloaded_text"))
        email = from_union([from_str, from_none], obj.get("email"))
        enabled = Enabled(obj.get("enabled"))
        id = from_int(obj.get("id"))
        invites = from_int(obj.get("invites"))
        last_access = from_str(obj.get("last_access"))
        last_access_human = from_str(obj.get("last_access_human"))
        last_login = from_str(obj.get("last_login"))
        last_login_human = from_str(obj.get("last_login_human"))
        leechtime = from_int(obj.get("leechtime"))
        leechtime_text = from_str(obj.get("leechtime_text"))
        seed_bonus_per_hour = from_int(obj.get("seed_bonus_per_hour"))
        seed_bonus_per_hour_human = from_str(obj.get("seed_bonus_per_hour_human"))
        seed_points = from_float(obj.get("seed_points"))
        seed_points_human = from_str(obj.get("seed_points_human"))
        seed_points_per_hour = from_int(obj.get("seed_points_per_hour"))
        seed_points_per_hour_human = from_str(obj.get("seed_points_per_hour_human"))
        seedtime = from_int(obj.get("seedtime"))
        seedtime_text = from_str(obj.get("seedtime_text"))
        share_ratio = from_str(obj.get("share_ratio"))
        status = Status(obj.get("status"))
        uploaded = from_int(obj.get("uploaded"))
        uploaded_text = from_str(obj.get("uploaded_text"))
        username = from_str(obj.get("username"))
        return UserBasicInfo(added, added_human, attendance_card, avatar, bonus, bonus_human, user_class, class_text, downloaded, downloaded_text, email, enabled, id, invites, last_access, last_access_human, last_login, last_login_human, leechtime, leechtime_text, seed_bonus_per_hour, seed_bonus_per_hour_human, seed_points, seed_points_human, seed_points_per_hour, seed_points_per_hour_human, seedtime, seedtime_text, share_ratio, status, uploaded, uploaded_text, username)

    def to_dict(self) -> dict:
        result: dict = {}
        result["added"] = from_str(self.added)
        result["added_human"] = from_str(self.added_human)
        result["attendance_card"] = from_int(self.attendance_card)
        result["avatar"] = from_str(self.avatar)
        result["bonus"] = to_float(self.bonus)
        result["bonus_human"] = from_str(self.bonus_human)
        result["class"] = from_int(self.user_class)
        result["class_text"] = from_str(self.class_text)
        result["downloaded"] = from_int(self.downloaded)
        result["downloaded_text"] = from_str(self.downloaded_text)
        if self.email is not None:
            result["email"] = from_union([from_str, from_none], self.email)
        result["enabled"] = to_enum(Enabled, self.enabled)
        result["id"] = from_int(self.id)
        result["invites"] = from_int(self.invites)
        result["last_access"] = from_str(self.last_access)
        result["last_access_human"] = from_str(self.last_access_human)
        result["last_login"] = from_str(self.last_login)
        result["last_login_human"] = from_str(self.last_login_human)
        result["leechtime"] = from_int(self.leechtime)
        result["leechtime_text"] = from_str(self.leechtime_text)
        result["seed_bonus_per_hour"] = from_int(self.seed_bonus_per_hour)
        result["seed_bonus_per_hour_human"] = from_str(self.seed_bonus_per_hour_human)
        result["seed_points"] = to_float(self.seed_points)
        result["seed_points_human"] = from_str(self.seed_points_human)
        result["seed_points_per_hour"] = from_int(self.seed_points_per_hour)
        result["seed_points_per_hour_human"] = from_str(self.seed_points_per_hour_human)
        result["seedtime"] = from_int(self.seedtime)
        result["seedtime_text"] = from_str(self.seedtime_text)
        result["share_ratio"] = from_str(self.share_ratio)
        result["status"] = to_enum(Status, self.status)
        result["uploaded"] = from_int(self.uploaded)
        result["uploaded_text"] = from_str(self.uploaded_text)
        result["username"] = from_str(self.username)
        return result


class SeedingLeechingData:
    """Seeding or leeching data, returned when include_fields[user] includes seeding_leeching_data. Compatible with >=1.9.13"""
    """Leeching count"""
    leeching_count: int
    """Leeching size"""
    leeching_size: int
    """Seeding count"""
    seeding_count: int
    """Seeding size"""
    seeding_size: int

    def __init__(self, leeching_count: int, leeching_size: int, seeding_count: int, seeding_size: int) -> None:
        self.leeching_count = leeching_count
        self.leeching_size = leeching_size
        self.seeding_count = seeding_count
        self.seeding_size = seeding_size

    @staticmethod
    def from_dict(obj: Any) -> 'SeedingLeechingData':
        assert isinstance(obj, dict)
        leeching_count = from_int(obj.get("leeching_count"))
        leeching_size = from_int(obj.get("leeching_size"))
        seeding_count = from_int(obj.get("seeding_count"))
        seeding_size = from_int(obj.get("seeding_size"))
        return SeedingLeechingData(leeching_count, leeching_size, seeding_count, seeding_size)

    def to_dict(self) -> dict:
        result: dict = {}
        result["leeching_count"] = from_int(self.leeching_count)
        result["leeching_size"] = from_int(self.leeching_size)
        result["seeding_count"] = from_int(self.seeding_count)
        result["seeding_size"] = from_int(self.seeding_size)
        return result


class UserMedalInfo:
    """User medal info"""
    """Valid days"""
    duration: Optional[int]
    """Expire at"""
    expire_at: Optional[str]
    """Get type"""
    get_type: int
    """Get type text"""
    get_type_text: str
    """Medal ID"""
    id: int
    """Large image"""
    image_large: str
    """Small image"""
    image_small: str
    """Medal name"""
    name: str
    """Price"""
    price: int
    """Price formatted"""
    price_human: str
    """User medal ID"""
    user_medal_id: int
    """Wearing status"""
    wearing_status: int
    """Wearing status text"""
    wearing_status_text: str

    def __init__(self, duration: Optional[int], expire_at: Optional[str], get_type: int, get_type_text: str, id: int, image_large: str, image_small: str, name: str, price: int, price_human: str, user_medal_id: int, wearing_status: int, wearing_status_text: str) -> None:
        self.duration = duration
        self.expire_at = expire_at
        self.get_type = get_type
        self.get_type_text = get_type_text
        self.id = id
        self.image_large = image_large
        self.image_small = image_small
        self.name = name
        self.price = price
        self.price_human = price_human
        self.user_medal_id = user_medal_id
        self.wearing_status = wearing_status
        self.wearing_status_text = wearing_status_text

    @staticmethod
    def from_dict(obj: Any) -> 'UserMedalInfo':
        assert isinstance(obj, dict)
        duration = from_union([from_none, from_int], obj.get("duration"))
        expire_at = from_union([from_none, from_str], obj.get("expire_at"))
        get_type = from_int(obj.get("get_type"))
        get_type_text = from_str(obj.get("get_type_text"))
        id = from_int(obj.get("id"))
        image_large = from_str(obj.get("image_large"))
        image_small = from_str(obj.get("image_small"))
        name = from_str(obj.get("name"))
        price = from_int(obj.get("price"))
        price_human = from_str(obj.get("price_human"))
        user_medal_id = from_int(obj.get("user_medal_id"))
        wearing_status = from_int(obj.get("wearing_status"))
        wearing_status_text = from_str(obj.get("wearing_status_text"))
        return UserMedalInfo(duration, expire_at, get_type, get_type_text, id, image_large, image_small, name, price, price_human, user_medal_id, wearing_status, wearing_status_text)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.duration is not None:
            result["duration"] = from_union([from_none, from_int], self.duration)
        if self.expire_at is not None:
            result["expire_at"] = from_union([from_none, from_str], self.expire_at)
        result["get_type"] = from_int(self.get_type)
        result["get_type_text"] = from_str(self.get_type_text)
        result["id"] = from_int(self.id)
        result["image_large"] = from_str(self.image_large)
        result["image_small"] = from_str(self.image_small)
        result["name"] = from_str(self.name)
        result["price"] = from_int(self.price)
        result["price_human"] = from_str(self.price_human)
        result["user_medal_id"] = from_int(self.user_medal_id)
        result["wearing_status"] = from_int(self.wearing_status)
        result["wearing_status_text"] = from_str(self.wearing_status_text)
        return result


class DataData:
    """Registration time"""
    added: str
    """Registration time formatted"""
    added_human: str
    """Attendance card count"""
    attendance_card: int
    """Avatar URL"""
    avatar: str
    """Bonus points"""
    bonus: float
    """Bonus points formatted"""
    bonus_human: str
    """User class"""
    user_class: int
    """User class name"""
    class_text: str
    """Downloaded bytes"""
    downloaded: int
    """Downloaded bytes formatted"""
    downloaded_text: str
    """Email, only present if user has permission to view"""
    email: Optional[str]
    """Enabled status"""
    enabled: Enabled
    """User ID"""
    id: int
    """Inviter"""
    inviter: Optional[UserBasicInfo]
    """Invite count"""
    invites: int
    """Last active time"""
    last_access: str
    """Last active time formatted"""
    last_access_human: str
    """Last login time"""
    last_login: str
    """Last login time formatted"""
    last_login_human: str
    """Leech time in seconds"""
    leechtime: int
    """Leech time formatted"""
    leechtime_text: str
    """Seed bonus per hour. Compatible with >=1.9.13"""
    seed_bonus_per_hour: Optional[int]
    """Seed bonus per hour formatted. Compatible with >=1.9.13"""
    seed_bonus_per_hour_human: Optional[str]
    """Seed points"""
    seed_points: float
    """Seed points formatted"""
    seed_points_human: str
    """Seed points per hour. Compatible with >=1.9.13"""
    seed_points_per_hour: Optional[int]
    """Seed points per hour formatted. Compatible with >=1.9.13"""
    seed_points_per_hour_human: Optional[str]
    """Seeding or leeching data, returned when include_fields[user] includes seeding_leeching_data. Compatible with >=1.9.13"""
    seeding_leeching_data: Optional[SeedingLeechingData]
    """Seed time in seconds"""
    seedtime: int
    """Seed time formatted"""
    seedtime_text: str
    """Share ratio rich text"""
    share_ratio: str
    """Confirmation status"""
    status: Status
    """Uploaded bytes"""
    uploaded: int
    """Uploaded bytes formatted"""
    uploaded_text: str
    """Username"""
    username: str
    """Valid medals"""
    valid_medals: Optional[List[UserMedalInfo]]

    def __init__(self, added: str, added_human: str, attendance_card: int, avatar: str, bonus: float, bonus_human: str, user_class: int, class_text: str, downloaded: int, downloaded_text: str, email: Optional[str], enabled: Enabled, id: int, inviter: Optional[UserBasicInfo], invites: int, last_access: str, last_access_human: str, last_login: str, last_login_human: str, leechtime: int, leechtime_text: str, seed_bonus_per_hour: Optional[int], seed_bonus_per_hour_human: Optional[str], seed_points: float, seed_points_human: str, seed_points_per_hour: Optional[int], seed_points_per_hour_human: Optional[str], seeding_leeching_data: Optional[SeedingLeechingData], seedtime: int, seedtime_text: str, share_ratio: str, status: Status, uploaded: int, uploaded_text: str, username: str, valid_medals: Optional[List[UserMedalInfo]]) -> None:
        self.added = added
        self.added_human = added_human
        self.attendance_card = attendance_card
        self.avatar = avatar
        self.bonus = bonus
        self.bonus_human = bonus_human
        self.user_class = user_class
        self.class_text = class_text
        self.downloaded = downloaded
        self.downloaded_text = downloaded_text
        self.email = email
        self.enabled = enabled
        self.id = id
        self.inviter = inviter
        self.invites = invites
        self.last_access = last_access
        self.last_access_human = last_access_human
        self.last_login = last_login
        self.last_login_human = last_login_human
        self.leechtime = leechtime
        self.leechtime_text = leechtime_text
        self.seed_bonus_per_hour = seed_bonus_per_hour
        self.seed_bonus_per_hour_human = seed_bonus_per_hour_human
        self.seed_points = seed_points
        self.seed_points_human = seed_points_human
        self.seed_points_per_hour = seed_points_per_hour
        self.seed_points_per_hour_human = seed_points_per_hour_human
        self.seeding_leeching_data = seeding_leeching_data
        self.seedtime = seedtime
        self.seedtime_text = seedtime_text
        self.share_ratio = share_ratio
        self.status = status
        self.uploaded = uploaded
        self.uploaded_text = uploaded_text
        self.username = username
        self.valid_medals = valid_medals

    @staticmethod
    def from_dict(obj: Any) -> 'DataData':
        assert isinstance(obj, dict)
        added = from_str(obj.get("added"))
        added_human = from_str(obj.get("added_human"))
        attendance_card = from_int(obj.get("attendance_card"))
        avatar = from_str(obj.get("avatar"))
        bonus = from_float(obj.get("bonus"))
        bonus_human = from_str(obj.get("bonus_human"))
        user_class = from_int(obj.get("class"))
        class_text = from_str(obj.get("class_text"))
        downloaded = from_int(obj.get("downloaded"))
        downloaded_text = from_str(obj.get("downloaded_text"))
        email = from_union([from_str, from_none], obj.get("email"))
        enabled = Enabled(obj.get("enabled"))
        id = from_int(obj.get("id"))
        inviter = from_union([UserBasicInfo.from_dict, from_none], obj.get("inviter"))
        invites = from_int(obj.get("invites"))
        last_access = from_str(obj.get("last_access"))
        last_access_human = from_str(obj.get("last_access_human"))
        last_login = from_str(obj.get("last_login"))
        last_login_human = from_str(obj.get("last_login_human"))
        leechtime = from_int(obj.get("leechtime"))
        leechtime_text = from_str(obj.get("leechtime_text"))
        seed_bonus_per_hour = from_union([from_int, from_none], obj.get("seed_bonus_per_hour"))
        seed_bonus_per_hour_human = from_union([from_str, from_none], obj.get("seed_bonus_per_hour_human"))
        seed_points = from_float(obj.get("seed_points"))
        seed_points_human = from_str(obj.get("seed_points_human"))
        seed_points_per_hour = from_union([from_int, from_none], obj.get("seed_points_per_hour"))
        seed_points_per_hour_human = from_union([from_str, from_none], obj.get("seed_points_per_hour_human"))
        seeding_leeching_data = from_union([SeedingLeechingData.from_dict, from_none], obj.get("seeding_leeching_data"))
        seedtime = from_int(obj.get("seedtime"))
        seedtime_text = from_str(obj.get("seedtime_text"))
        share_ratio = from_str(obj.get("share_ratio"))
        status = Status(obj.get("status"))
        uploaded = from_int(obj.get("uploaded"))
        uploaded_text = from_str(obj.get("uploaded_text"))
        username = from_str(obj.get("username"))
        valid_medals = from_union([lambda x: from_list(UserMedalInfo.from_dict, x), from_none], obj.get("valid_medals"))
        return DataData(added, added_human, attendance_card, avatar, bonus, bonus_human, user_class, class_text, downloaded, downloaded_text, email, enabled, id, inviter, invites, last_access, last_access_human, last_login, last_login_human, leechtime, leechtime_text, seed_bonus_per_hour, seed_bonus_per_hour_human, seed_points, seed_points_human, seed_points_per_hour, seed_points_per_hour_human, seeding_leeching_data, seedtime, seedtime_text, share_ratio, status, uploaded, uploaded_text, username, valid_medals)

    def to_dict(self) -> dict:
        result: dict = {}
        result["added"] = from_str(self.added)
        result["added_human"] = from_str(self.added_human)
        result["attendance_card"] = from_int(self.attendance_card)
        result["avatar"] = from_str(self.avatar)
        result["bonus"] = to_float(self.bonus)
        result["bonus_human"] = from_str(self.bonus_human)
        result["class"] = from_int(self.user_class)
        result["class_text"] = from_str(self.class_text)
        result["downloaded"] = from_int(self.downloaded)
        result["downloaded_text"] = from_str(self.downloaded_text)
        if self.email is not None:
            result["email"] = from_union([from_str, from_none], self.email)
        result["enabled"] = to_enum(Enabled, self.enabled)
        result["id"] = from_int(self.id)
        if self.inviter is not None:
            result["inviter"] = from_union([lambda x: to_class(UserBasicInfo, x), from_none], self.inviter)
        result["invites"] = from_int(self.invites)
        result["last_access"] = from_str(self.last_access)
        result["last_access_human"] = from_str(self.last_access_human)
        result["last_login"] = from_str(self.last_login)
        result["last_login_human"] = from_str(self.last_login_human)
        result["leechtime"] = from_int(self.leechtime)
        result["leechtime_text"] = from_str(self.leechtime_text)
        if self.seed_bonus_per_hour is not None:
            result["seed_bonus_per_hour"] = from_union([from_int, from_none], self.seed_bonus_per_hour)
        if self.seed_bonus_per_hour_human is not None:
            result["seed_bonus_per_hour_human"] = from_union([from_str, from_none], self.seed_bonus_per_hour_human)
        result["seed_points"] = to_float(self.seed_points)
        result["seed_points_human"] = from_str(self.seed_points_human)
        if self.seed_points_per_hour is not None:
            result["seed_points_per_hour"] = from_union([from_int, from_none], self.seed_points_per_hour)
        if self.seed_points_per_hour_human is not None:
            result["seed_points_per_hour_human"] = from_union([from_str, from_none], self.seed_points_per_hour_human)
        if self.seeding_leeching_data is not None:
            result["seeding_leeching_data"] = from_union([lambda x: to_class(SeedingLeechingData, x), from_none], self.seeding_leeching_data)
        result["seedtime"] = from_int(self.seedtime)
        result["seedtime_text"] = from_str(self.seedtime_text)
        result["share_ratio"] = from_str(self.share_ratio)
        result["status"] = to_enum(Status, self.status)
        result["uploaded"] = from_int(self.uploaded)
        result["uploaded_text"] = from_str(self.uploaded_text)
        result["username"] = from_str(self.username)
        if self.valid_medals is not None:
            result["valid_medals"] = from_union([lambda x: from_list(lambda x: to_class(UserMedalInfo, x), x), from_none], self.valid_medals)
        return result


class ProfileData:
    """Data wrapper"""
    data: DataData

    def __init__(self, data: DataData) -> None:
        self.data = data

    @staticmethod
    def from_dict(obj: Any) -> 'ProfileData':
        assert isinstance(obj, dict)
        data = DataData.from_dict(obj.get("data"))
        return ProfileData(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(DataData, self.data)
        return result


class Profile:
    """Data wrapper"""
    data: ProfileData
    """Message"""
    msg: str
    """Result code, 0 means success, others mean failure"""
    ret: int
    """Request ID"""
    rid: str
    """Response time in seconds"""
    time: float

    def __init__(self, data: ProfileData, msg: str, ret: int, rid: str, time: float) -> None:
        self.data = data
        self.msg = msg
        self.ret = ret
        self.rid = rid
        self.time = time

    @staticmethod
    def from_dict(obj: Any) -> 'Profile':
        assert isinstance(obj, dict)
        data = ProfileData.from_dict(obj.get("data"))
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return Profile(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(ProfileData, self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = to_float(self.time)
        return result


def profile_from_dict(s: Any) -> Profile:
    return Profile.from_dict(s)


def profile_to_dict(x: Profile) -> Any:
    return to_class(Profile, x)
