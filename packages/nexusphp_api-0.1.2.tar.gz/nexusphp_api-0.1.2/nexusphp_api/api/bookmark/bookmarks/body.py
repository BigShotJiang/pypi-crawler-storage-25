from dataclasses import dataclass
from typing import Optional, Any, TypeVar, Type
from ....utils import from_int, from_none, from_union, to_class


T = TypeVar("T")


@dataclass
class Body:
    """Torrent ID"""
    torrent_id: Optional[int] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Body':
        assert isinstance(obj, dict)
        torrent_id = from_union([from_int, from_none], obj.get("torrent_id"))
        return Body(torrent_id)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.torrent_id is not None:
            result["torrent_id"] = from_union([from_int, from_none], self.torrent_id)
        return result


def body_from_dict(s: Any) -> Body:
    return Body.from_dict(s)


def body_to_dict(x: Body) -> Any:
    return to_class(Body, x)
