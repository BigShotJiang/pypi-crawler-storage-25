from dataclasses import dataclass
from typing import Any, Optional, TypeVar, Type
from ....utils import from_str, to_class


T = TypeVar("T")


@dataclass
class Header:
    """Request headers information"""
    accept: str
    content_type: str
    """Authentication Token, format: Bearer {token}"""
    authorization: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Header':
        assert isinstance(obj, dict)
        accept = from_str(obj.get("Accept"))
        content_type = from_str(obj.get("Content-Type"))
        authorization = obj.get("Authorization")
        return Header(accept, content_type, authorization)

    def to_dict(self) -> dict:
        result: dict = {}
        result["Accept"] = from_str(self.accept)
        result["Content-Type"] = from_str(self.content_type)
        if self.authorization is not None:
            result["Authorization"] = from_str(self.authorization)
        return result


def header_from_dict(s: Any) -> Header:
    return Header.from_dict(s)


def header_to_dict(x: Header) -> Any:
    return to_class(Header, x)
