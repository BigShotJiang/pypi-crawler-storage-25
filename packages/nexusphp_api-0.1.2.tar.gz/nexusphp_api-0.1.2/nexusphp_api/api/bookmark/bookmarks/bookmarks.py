from dataclasses import dataclass
from typing import Any, TypeVar, Type, Optional, List
from ....utils import from_int, from_str, from_float, to_float, to_class, from_list


T = TypeVar("T")


@dataclass
class DataData:
    """Bookmark record ID"""
    id: int
    """Torrent ID"""
    torrent_id: int
    """User ID"""
    user_id: int

    @staticmethod
    def from_dict(obj: Any) -> 'DataData':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        torrent_id = from_int(obj.get("torrent_id"))
        user_id = from_int(obj.get("user_id"))
        return DataData(id, torrent_id, user_id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["torrent_id"] = from_int(self.torrent_id)
        result["user_id"] = from_int(self.user_id)
        return result


@dataclass
class Bookmarks:
    """Data wrapper"""
    data: List[DataData]
    """Text message"""
    msg: str
    """Result code, 0 means success, others mean failure"""
    ret: int
    """Request ID"""
    rid: str
    """Response time in seconds"""
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'Bookmarks':
        assert isinstance(obj, dict)
        data = obj.get("data", [])
        if isinstance(data, list):
            data = from_list(DataData.from_dict, data)
        else:
            data = []
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return Bookmarks(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(DataData, x), self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = to_float(self.time)
        return result


def bookmarks_from_dict(s: Any) -> Bookmarks:
    return Bookmarks.from_dict(s)


def bookmarks_to_dict(x: Bookmarks) -> Any:
    return to_class(Bookmarks, x)
