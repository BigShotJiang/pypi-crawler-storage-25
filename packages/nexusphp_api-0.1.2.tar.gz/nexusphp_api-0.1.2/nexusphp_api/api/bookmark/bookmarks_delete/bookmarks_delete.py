from dataclasses import dataclass
from typing import List, Dict, Any, Union, Optional, TypeVar, Callable, Type
from ....utils import from_none, from_float, from_int, from_bool, from_str, from_list, from_dict, from_union, to_float, to_class


T = TypeVar("T")


@dataclass
class DataClass:
    """Data wrapper"""
    """Success: true, failure: submitted data"""
    data: Optional[Union[float, int, bool, str, List[str], Dict[str, Any]]] = None

    @staticmethod
    def from_dict(obj: Any) -> 'DataClass':
        assert isinstance(obj, dict)
        data = from_union([from_none, from_float, from_int, from_bool, from_str, lambda x: from_list(from_str, x), lambda x: from_dict(lambda x: x, x)], obj.get("data"))
        return DataClass(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_union([from_none, to_float, from_int, from_bool, from_str, lambda x: from_list(from_str, x), lambda x: from_dict(lambda x: x, x)], self.data)
        return result


@dataclass
class BookmarksDelete:
    """Data wrapper"""
    data: DataClass
    """Text message"""
    msg: str
    """Result code, 0 means success, others mean failure"""
    ret: int
    """Request ID"""
    rid: str
    """Response time in seconds"""
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'BookmarksDelete':
        assert isinstance(obj, dict)
        data_value = obj.get("data")
        if isinstance(data_value, dict):
            data = DataClass.from_dict(data_value)
        else:
            # If data is not dict, directly create DataClass instance
            data = DataClass(data=data_value)
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return BookmarksDelete(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(DataClass, self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = to_float(self.time)
        return result


def bookmarks_delete_from_dict(s: Any) -> BookmarksDelete:
    return BookmarksDelete.from_dict(s)


def bookmarks_delete_to_dict(x: BookmarksDelete) -> Any:
    return to_class(BookmarksDelete, x)
