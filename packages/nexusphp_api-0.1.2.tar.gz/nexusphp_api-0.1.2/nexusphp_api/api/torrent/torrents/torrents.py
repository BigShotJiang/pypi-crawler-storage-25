from enum import Enum
from dataclasses import dataclass
from typing import Any, Optional, Dict, List, TypeVar, Type, Callable
from ....utils import from_float, to_enum, to_float, from_int, from_str, from_none, from_union, to_class, from_dict, from_list, from_bool


T = TypeVar("T")
EnumT = TypeVar("EnumT", bound=Enum)


class ActiveStatusEnum(Enum):
    """Active status"""
    INACTIVITY = "inactivity"
    LEECHING = "leeching"
    SEEDING = "seeding"


class Finished(Enum):
    """Download status or enabled status"""
    NO = "no"
    YES = "yes"


@dataclass
class ActiveStatusClass:
    """Active status"""
    active_status: ActiveStatusEnum
    """Download finished status"""
    finished: Finished
    """Download progress, float in [0,1]"""
    progress: float

    @staticmethod
    def from_dict(obj: Any) -> 'ActiveStatusClass':
        assert isinstance(obj, dict)
        active_status = ActiveStatusEnum(obj.get("active_status"))
        finished = Finished(obj.get("finished"))
        progress = from_float(obj.get("progress"))
        return ActiveStatusClass(active_status, finished, progress)

    def to_dict(self) -> dict:
        result: dict = {}
        result["active_status"] = to_enum(ActiveStatusEnum, self.active_status)
        result["finished"] = to_enum(Finished, self.finished)
        result["progress"] = to_float(self.progress)
        return result


@dataclass
class CategoryInfo:
    """Category info"""
    id: int
    name: str

    @staticmethod
    def from_dict(obj: Any) -> 'CategoryInfo':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        return CategoryInfo(id, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        return result


@dataclass
class DescriptionData:
    """Description data"""
    """Text info, available when type is text"""
    text: Optional[str] = None
    """Link info, available when type is attachment/image"""
    url: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'DescriptionData':
        assert isinstance(obj, dict)
        text = from_union([from_str, from_none], obj.get("text"))
        url = from_union([from_str, from_none], obj.get("url"))
        return DescriptionData(text, url)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.text is not None:
            result["text"] = from_union([from_str, from_none], self.text)
        if self.url is not None:
            result["url"] = from_union([from_str, from_none], self.url)
        return result


class TypeEnum(Enum):
    """Type"""
    ATTACHMENT = "attachment"
    IMAGE = "image"
    TEXT = "text"


@dataclass
class Description:
    """Description item"""
    """Data"""
    data: DescriptionData
    """Type"""
    type: TypeEnum

    @staticmethod
    def from_dict(obj: Any) -> 'Description':
        assert isinstance(obj, dict)
        data = DescriptionData.from_dict(obj.get("data"))
        type = TypeEnum(obj.get("type"))
        return Description(data, type)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(DescriptionData, self.data)
        result["type"] = to_enum(TypeEnum, self.type)
        return result


@dataclass
class Videos:
    """Bit depth"""
    bit_depth: Optional[str] = None
    """Bitrate"""
    bitrate: Optional[str] = None
    """Frame rate"""
    frame_rate: Optional[str] = None
    profile: Optional[str] = None
    """Resolution"""
    resolution: Optional[str] = None
    """Runtime"""
    runtime: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Videos':
        if not isinstance(obj, dict):
            return Videos()
        bit_depth = from_union([from_str, from_none], obj.get("Bit depth"))
        bitrate = from_union([from_str, from_none], obj.get("Bitrate"))
        frame_rate = from_union([from_str, from_none], obj.get("Frame rate"))
        profile = from_union([from_str, from_none], obj.get("Profile"))
        resolution = from_union([from_str, from_none], obj.get("Resolution"))
        runtime = from_union([from_str, from_none], obj.get("Runtime"))
        return Videos(bit_depth, bitrate, frame_rate, profile, resolution, runtime)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.bit_depth is not None:
            result["Bit depth"] = from_str(self.bit_depth)
        if self.bitrate is not None:
            result["Bitrate"] = from_str(self.bitrate)
        if self.frame_rate is not None:
            result["Frame rate"] = from_str(self.frame_rate)
        if self.profile is not None:
            result["Profile"] = from_str(self.profile)
        if self.resolution is not None:
            result["Resolution"] = from_str(self.resolution)
        if self.runtime is not None:
            result["Runtime"] = from_str(self.runtime)
        return result


@dataclass
class MediaInfoSummary:
    """Audio related, null if no data"""
    audios: Optional[Dict[str, Any]] = None
    """Subtitle related, null if no data"""
    subtitles: Optional[Dict[str, Any]] = None
    """Video related, null if no data"""
    videos: Optional[Videos] = None

    @staticmethod
    def from_dict(obj: Any) -> 'MediaInfoSummary':
        if not isinstance(obj, dict):
            return MediaInfoSummary()
        audios = obj.get("audios")
        subtitles = obj.get("subtitles")
        videos = obj.get("videos")
        if videos is not None:
            videos = Videos.from_dict(videos)
        return MediaInfoSummary(audios, subtitles, videos)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.audios is not None:
            result["audios"] = self.audios
        if self.subtitles is not None:
            result["subtitles"] = self.subtitles
        if self.videos is not None:
            result["videos"] = self.videos.to_dict()
        return result


@dataclass
class Extra:
    """Extra info, returned when includes contains extra"""
    """Torrent description"""
    descr: str
    """Media Info"""
    media_info: Optional[str] = None
    """Media Info summary"""
    media_info_summary: Optional[MediaInfoSummary] = None
    """Nfo file content"""
    nfo: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Extra':
        assert isinstance(obj, dict)
        descr = from_str(obj.get("descr"))
        media_info = from_union([from_none, from_str], obj.get("media_info"))
        media_info_summary = from_union([from_none, MediaInfoSummary.from_dict], obj.get("media_info_summary"))
        nfo = from_union([from_none, from_str], obj.get("nfo"))
        return Extra(descr, media_info, media_info_summary, nfo)

    def to_dict(self) -> dict:
        result: dict = {}
        result["descr"] = from_str(self.descr)
        result["media_info"] = from_union([from_none, from_str], self.media_info)
        result["media_info_summary"] = from_union([from_none, lambda x: to_class(MediaInfoSummary, x)], self.media_info_summary)
        result["nfo"] = from_union([from_none, from_str], self.nfo)
        return result


@dataclass
class PickInfo:
    """Pick info"""
    """Pick name color"""
    color: str
    """Pick name"""
    text: str

    @staticmethod
    def from_dict(obj: Any) -> 'PickInfo':
        assert isinstance(obj, dict)
        color = from_str(obj.get("color"))
        text = from_str(obj.get("text"))
        return PickInfo(color, text)

    def to_dict(self) -> dict:
        result: dict = {}
        result["color"] = from_str(self.color)
        result["text"] = from_str(self.text)
        return result


@dataclass
class PromotionInfo:
    """Promotion info"""
    """Promotion name color"""
    color: str
    """Download multiplier"""
    down_multiplier: Optional[int]
    """Promotion name"""
    text: str
    """Upload multiplier"""
    up_multiplier: Optional[int]

    @staticmethod
    def from_dict(obj: Any) -> 'PromotionInfo':
        assert isinstance(obj, dict)
        color = from_str(obj.get("color"))
        down_multiplier = obj.get("down_multiplier")
        if down_multiplier is not None:
            try:
                down_multiplier = int(down_multiplier)
            except (ValueError, TypeError):
                down_multiplier = None
        text = from_str(obj.get("text"))
        up_multiplier = obj.get("up_multiplier")
        if up_multiplier is not None:
            try:
                up_multiplier = int(up_multiplier)
            except (ValueError, TypeError):
                up_multiplier = None
        return PromotionInfo(color, down_multiplier, text, up_multiplier)

    def to_dict(self) -> dict:
        result: dict = {}
        result["color"] = from_str(self.color)
        if self.down_multiplier is not None:
            result["down_multiplier"] = from_union([from_int, from_none], self.down_multiplier)
        result["text"] = from_str(self.text)
        if self.up_multiplier is not None:
            result["up_multiplier"] = from_union([from_int, from_none], self.up_multiplier)
        return result


@dataclass
class SubCategoryItem:
    """Subcategory item info"""
    """Label"""
    label: str
    """Value"""
    value: str

    @staticmethod
    def from_dict(obj: Any) -> 'SubCategoryItem':
        assert isinstance(obj, dict)
        label = from_str(obj.get("label"))
        value = from_str(obj.get("value"))
        return SubCategoryItem(label, value)

    def to_dict(self) -> dict:
        result: dict = {}
        result["label"] = from_str(self.label)
        result["value"] = from_str(self.value)
        return result


@dataclass
class Medium:
    """Medium info"""
    """Label"""
    label: str
    """Value"""
    value: str

    @staticmethod
    def from_dict(obj: Any) -> 'Medium':
        assert isinstance(obj, dict)
        label = from_str(obj.get("label"))
        value = from_str(obj.get("value"))
        return Medium(label, value)

    def to_dict(self) -> dict:
        result: dict = {}
        result["label"] = from_str(self.label)
        result["value"] = from_str(self.value)
        return result


@dataclass
class SubCategories:
    """Audio codec info"""
    audiocodec: Optional[SubCategoryItem] = None
    """Codec info"""
    codec: Optional[SubCategoryItem] = None
    """Medium info"""
    medium: Optional[Medium] = None
    """Processing info"""
    processing: Optional[SubCategoryItem] = None
    """Source info"""
    source: Optional[SubCategoryItem] = None
    """Standard info"""
    standard: Optional[SubCategoryItem] = None
    """Team info"""
    team: Optional[SubCategoryItem] = None

    @staticmethod
    def from_dict(obj: Any) -> 'SubCategories':
        assert isinstance(obj, dict)
        audiocodec = from_union([SubCategoryItem.from_dict, from_none], obj.get("audiocodec"))
        codec = from_union([SubCategoryItem.from_dict, from_none], obj.get("codec"))
        medium = from_union([Medium.from_dict, from_none], obj.get("medium"))
        processing = from_union([SubCategoryItem.from_dict, from_none], obj.get("processing"))
        source = from_union([SubCategoryItem.from_dict, from_none], obj.get("source"))
        standard = from_union([SubCategoryItem.from_dict, from_none], obj.get("standard"))
        team = from_union([SubCategoryItem.from_dict, from_none], obj.get("team"))
        return SubCategories(audiocodec, codec, medium, processing, source, standard, team)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.audiocodec is not None:
            result["audiocodec"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.audiocodec)
        if self.codec is not None:
            result["codec"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.codec)
        if self.medium is not None:
            result["medium"] = from_union([lambda x: to_class(Medium, x), from_none], self.medium)
        if self.processing is not None:
            result["processing"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.processing)
        if self.source is not None:
            result["source"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.source)
        if self.standard is not None:
            result["standard"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.standard)
        if self.team is not None:
            result["team"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.team)
        return result


@dataclass
class TagInfo:
    """Tag info"""
    """Border radius"""
    border_radius: str
    """Background color"""
    color: str
    """Created at"""
    created_at: str
    """Font color"""
    font_color: str
    """Font size"""
    font_size: str
    """Tag id"""
    id: int
    """Margin"""
    margin: str
    """Name"""
    name: str
    """Padding"""
    padding: str
    """Priority"""
    priority: int
    """Updated at"""
    updated_at: str

    @staticmethod
    def from_dict(obj: Any) -> 'TagInfo':
        assert isinstance(obj, dict)
        border_radius = from_str(obj.get("border_radius"))
        color = from_str(obj.get("color"))
        created_at = from_str(obj.get("created_at"))
        font_color = from_str(obj.get("font_color"))
        font_size = from_str(obj.get("font_size"))
        id = from_int(obj.get("id"))
        margin = from_str(obj.get("margin"))
        name = from_str(obj.get("name"))
        padding = from_str(obj.get("padding"))
        priority = from_int(obj.get("priority"))
        updated_at = from_str(obj.get("updated_at"))
        return TagInfo(border_radius, color, created_at, font_color, font_size, id, margin, name, padding, priority, updated_at)

    def to_dict(self) -> dict:
        result: dict = {}
        result["border_radius"] = from_str(self.border_radius)
        result["color"] = from_str(self.color)
        result["created_at"] = from_str(self.created_at)
        result["font_color"] = from_str(self.font_color)
        result["font_size"] = from_str(self.font_size)
        result["id"] = from_int(self.id)
        result["margin"] = from_str(self.margin)
        result["name"] = from_str(self.name)
        result["padding"] = from_str(self.padding)
        result["priority"] = from_int(self.priority)
        result["updated_at"] = from_str(self.updated_at)
        return result


class Status(Enum):
    """Confirmation status"""
    CONFIRMED = "confirmed"
    PENDING = "pending"


@dataclass
class User:
    """Uploader info, returned when includes contains user"""
    """Registration time"""
    added: Optional[str] = None
    """Registration time formatted"""
    added_human: Optional[str] = None
    """Attendance card count"""
    attendance_card: Optional[int] = None
    """Avatar URL"""
    avatar: Optional[str] = None
    """Bonus points"""
    bonus: Optional[int] = None
    """User class"""
    user_class: Optional[int] = None
    """User class name"""
    class_text: Optional[str] = None
    """Downloaded bytes"""
    downloaded: Optional[int] = None
    """Downloaded bytes formatted"""
    downloaded_text: Optional[str] = None
    """Email, available when user has permission to view"""
    email: Optional[str] = None
    """Enabled status"""
    enabled: Optional[Finished] = None
    """User ID"""
    id: Optional[int] = None
    """Invite count"""
    invites: Optional[int] = None
    """Last access time"""
    last_access: Optional[str] = None
    """Last access time formatted"""
    last_access_human: Optional[str] = None
    """Leech time in seconds"""
    leechtime: Optional[int] = None
    """Leech time formatted"""
    leechtime_text: Optional[str] = None
    """Seed points"""
    seed_points: Optional[int] = None
    """Seed time in seconds"""
    seedtime: Optional[int] = None
    """Seed time formatted"""
    seedtime_text: Optional[str] = None
    """Confirmation status"""
    status: Optional[Status] = None
    """Uploaded bytes"""
    uploaded: Optional[int] = None
    """Uploaded bytes formatted"""
    uploaded_text: Optional[str] = None
    """Username"""
    username: Optional[str] = None
    """Bonus points formatted"""
    bonus_human: Optional[str] = None
    """Last login time"""
    last_login: Optional[str] = None
    """Last login time formatted"""
    last_login_human: Optional[str] = None
    """Seed bonus per hour. Compatible with >=1.9.13"""
    seed_bonus_per_hour: Optional[int] = None
    """Seed bonus per hour formatted. Compatible with >=1.9.13"""
    seed_bonus_per_hour_human: Optional[str] = None
    """Seed points formatted"""
    seed_points_human: Optional[str] = None
    """Seed points per hour. Compatible with >=1.9.13"""
    seed_points_per_hour: Optional[int] = None
    """Seed points per hour formatted. Compatible with >=1.9.13"""
    seed_points_per_hour_human: Optional[str] = None
    """Share ratio rich text"""
    share_ratio: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'User':
        if not isinstance(obj, dict):
            return User()
        added = obj.get("added")
        added_human = obj.get("added_human")
        attendance_card = obj.get("attendance_card")
        avatar = obj.get("avatar")
        bonus = obj.get("bonus")
        user_class = obj.get("class")
        class_text = obj.get("class_text")
        downloaded = obj.get("downloaded")
        downloaded_text = obj.get("downloaded_text")
        email = obj.get("email")
        enabled = obj.get("enabled")
        id = obj.get("id")
        invites = obj.get("invites")
        last_access = obj.get("last_access")
        last_access_human = obj.get("last_access_human")
        leechtime = obj.get("leechtime")
        leechtime_text = obj.get("leechtime_text")
        seed_points = obj.get("seed_points")
        seedtime = obj.get("seedtime")
        seedtime_text = obj.get("seedtime_text")
        status = obj.get("status")
        uploaded = obj.get("uploaded")
        uploaded_text = obj.get("uploaded_text")
        username = obj.get("username")
        bonus_human = obj.get("bonus_human")
        last_login = obj.get("last_login")
        last_login_human = obj.get("last_login_human")
        seed_bonus_per_hour = obj.get("seed_bonus_per_hour")
        seed_bonus_per_hour_human = obj.get("seed_bonus_per_hour_human")
        seed_points_human = obj.get("seed_points_human")
        seed_points_per_hour = obj.get("seed_points_per_hour")
        seed_points_per_hour_human = obj.get("seed_points_per_hour_human")
        share_ratio = obj.get("share_ratio")

        return User(
            added, added_human, attendance_card, avatar, bonus, user_class, class_text,
            downloaded, downloaded_text, email, enabled, id, invites, last_access,
            last_access_human, leechtime, leechtime_text, seed_points, seedtime,
            seedtime_text, status, uploaded, uploaded_text, username, bonus_human,
            last_login, last_login_human, seed_bonus_per_hour, seed_bonus_per_hour_human,
            seed_points_human, seed_points_per_hour, seed_points_per_hour_human, share_ratio
        )

    def to_dict(self) -> dict:
        result: dict = {}
        if self.added is not None:
            result["added"] = from_str(self.added)
        if self.added_human is not None:
            result["added_human"] = from_str(self.added_human)
        if self.attendance_card is not None:
            result["attendance_card"] = from_int(self.attendance_card)
        if self.avatar is not None:
            result["avatar"] = from_str(self.avatar)
        if self.bonus is not None:
            result["bonus"] = from_int(self.bonus)
        if self.user_class is not None:
            result["class"] = from_int(self.user_class)
        if self.class_text is not None:
            result["class_text"] = from_str(self.class_text)
        if self.downloaded is not None:
            result["downloaded"] = from_int(self.downloaded)
        if self.downloaded_text is not None:
            result["downloaded_text"] = from_str(self.downloaded_text)
        if self.email is not None:
            result["email"] = from_str(self.email)
        if self.enabled is not None:
            result["enabled"] = to_enum(Finished, self.enabled)
        if self.id is not None:
            result["id"] = from_int(self.id)
        if self.invites is not None:
            result["invites"] = from_int(self.invites)
        if self.last_access is not None:
            result["last_access"] = from_str(self.last_access)
        if self.last_access_human is not None:
            result["last_access_human"] = from_str(self.last_access_human)
        if self.leechtime is not None:
            result["leechtime"] = from_int(self.leechtime)
        if self.leechtime_text is not None:
            result["leechtime_text"] = from_str(self.leechtime_text)
        if self.seed_points is not None:
            result["seed_points"] = from_int(self.seed_points)
        if self.seedtime is not None:
            result["seedtime"] = from_int(self.seedtime)
        if self.seedtime_text is not None:
            result["seedtime_text"] = from_str(self.seedtime_text)
        if self.status is not None:
            result["status"] = to_enum(Status, self.status)
        if self.uploaded is not None:
            result["uploaded"] = from_int(self.uploaded)
        if self.uploaded_text is not None:
            result["uploaded_text"] = from_str(self.uploaded_text)
        if self.username is not None:
            result["username"] = from_str(self.username)
        if self.bonus_human is not None:
            result["bonus_human"] = from_str(self.bonus_human)
        if self.last_login is not None:
            result["last_login"] = from_str(self.last_login)
        if self.last_login_human is not None:
            result["last_login_human"] = from_str(self.last_login_human)
        if self.seed_bonus_per_hour is not None:
            result["seed_bonus_per_hour"] = from_int(self.seed_bonus_per_hour)
        if self.seed_bonus_per_hour_human is not None:
            result["seed_bonus_per_hour_human"] = from_str(self.seed_bonus_per_hour_human)
        if self.seed_points_human is not None:
            result["seed_points_human"] = from_str(self.seed_points_human)
        if self.seed_points_per_hour is not None:
            result["seed_points_per_hour"] = from_int(self.seed_points_per_hour)
        if self.seed_points_per_hour_human is not None:
            result["seed_points_per_hour_human"] = from_str(self.seed_points_per_hour_human)
        if self.share_ratio is not None:
            result["share_ratio"] = from_str(self.share_ratio)
        return result


@dataclass
class TorrentInfo:
    """Torrent info"""
    """Added time"""
    added: str
    """Added time formatted"""
    added_human: str
    """Anonymous upload"""
    anonymous: str
    """Category id"""
    category: int
    """Category info"""
    category_info: CategoryInfo
    """Comments count"""
    comments: int
    """Cover image"""
    cover: str
    """Filename"""
    filename: str
    """Hash"""
    hash: str
    """Hits"""
    hits: int
    """Hit & Run status"""
    hr: int
    """Id"""
    id: int
    """Last action time"""
    last_action: str
    """Last action time formatted"""
    last_action_human: str
    """Leechers count"""
    leechers: int
    """Name"""
    name: str
    """Number of files"""
    numfiles: int
    """Pick info"""
    pick_info: PickInfo
    """Pick type"""
    pick_type: str
    """Position state"""
    pos_state: str
    """Promotion info"""
    promotion_info: PromotionInfo
    """Seeders count"""
    seeders: int
    """Size bytes"""
    size: int
    """Size formatted"""
    size_human: str
    """Small description"""
    small_descr: str
    """Seed promotion state"""
    sp_state: int
    """Seed promotion state real"""
    sp_state_real: int
    """Times completed"""
    times_completed: int
    """Views"""
    views: int
    """Active status, returned when include_fields[torrent] contains active_status"""
    active_status: Optional[ActiveStatusClass] = None
    """Claims count, returned when include_counts contains claims"""
    claims_count: Optional[int] = None
    """Formatted description, returned when include_fields[torrent] contains description"""
    description: Optional[List[Description]] = None
    """Download url, returned when include_fields[torrent] contains download_url"""
    download_url: Optional[str] = None
    """Extra info, returned when includes contains extra"""
    extra: Optional[Extra] = None
    """Bookmark status, returned when include_fields[torrent] contains has_bookmarked"""
    has_bookmarked: Optional[bool] = None
    """Claimed status, returned when include_fields[torrent] contains has_claimed"""
    has_claimed: Optional[bool] = None
    """Rewarded status, returned when include_fields[torrent] contains has_rewarded"""
    has_rewarded: Optional[bool] = None
    """Thanked status, returned when include_fields[torrent] contains has_thanked"""
    has_thanked: Optional[bool] = None
    """All images in description, returned when include_fields[torrent] contains description"""
    images: Optional[List[str]] = None
    """Pick time"""
    pick_time: Optional[str] = None
    """Position state until"""
    pos_state_until: Optional[str] = None
    """Position state until formatted"""
    pos_state_until_human: Optional[str] = None
    """Reward logs count, returned when include_counts contains reward_logs"""
    reward_logs_count: Optional[int] = None
    """Sub categories info"""
    sub_categories: Optional[SubCategories] = None
    """Tags info, returned when includes contains tags"""
    tags: Optional[List[TagInfo]] = None
    """Thank users count, returned when include_counts contains thank_users"""
    thank_users_count: Optional[int] = None
    """Uploader info, returned when includes contains user"""
    user: Optional[User] = None

    @staticmethod
    def from_dict(obj: Any) -> 'TorrentInfo':
        assert isinstance(obj, dict)
        added = from_str(obj.get("added"))
        added_human = from_str(obj.get("added_human"))
        anonymous = from_str(obj.get("anonymous"))
        category = from_int(obj.get("category"))
        category_info = CategoryInfo.from_dict(obj.get("category_info"))
        comments = from_int(obj.get("comments"))
        cover = from_str(obj.get("cover"))
        filename = from_str(obj.get("filename"))
        hash = from_str(obj.get("hash"))
        hits = from_int(obj.get("hits"))
        hr = from_int(obj.get("hr"))
        id = from_int(obj.get("id"))
        last_action = from_str(obj.get("last_action"))
        last_action_human = from_str(obj.get("last_action_human"))
        leechers = from_int(obj.get("leechers"))
        name = from_str(obj.get("name"))
        numfiles = from_int(obj.get("numfiles"))
        pick_info = PickInfo.from_dict(obj.get("pick_info"))
        pick_type = from_str(obj.get("pick_type"))
        pos_state = from_str(obj.get("pos_state"))
        promotion_info = PromotionInfo.from_dict(obj.get("promotion_info"))
        seeders = from_int(obj.get("seeders"))
        size = from_int(obj.get("size"))
        size_human = from_str(obj.get("size_human"))
        small_descr = from_str(obj.get("small_descr"))
        sp_state = from_int(obj.get("sp_state"))
        sp_state_real = from_int(obj.get("sp_state_real"))
        times_completed = from_int(obj.get("times_completed"))
        views = from_int(obj.get("views"))
        active_status = from_union([from_none, ActiveStatusClass.from_dict], obj.get("active_status"))
        claims_count = from_union([from_int, from_none], obj.get("claims_count"))
        description = from_union([lambda x: from_list(Description.from_dict, x), from_none], obj.get("description"))
        download_url = from_union([from_str, from_none], obj.get("download_url"))
        extra = from_union([Extra.from_dict, from_none], obj.get("extra"))
        has_bookmarked = from_union([from_bool, from_none], obj.get("has_bookmarked"))
        has_claimed = from_union([from_bool, from_none], obj.get("has_claimed"))
        has_rewarded = from_union([from_bool, from_none], obj.get("has_rewarded"))
        has_thanked = from_union([from_bool, from_none], obj.get("has_thanked"))
        images = from_union([lambda x: from_list(from_str, x), from_none], obj.get("images"))
        pick_time = from_union([from_none, from_str], obj.get("pick_time"))
        pos_state_until = from_union([from_none, from_str], obj.get("pos_state_until"))
        pos_state_until_human = from_union([from_none, from_str], obj.get("pos_state_until_human"))
        reward_logs_count = from_union([from_int, from_none], obj.get("reward_logs_count"))
        sub_categories = from_union([from_none, SubCategories.from_dict], obj.get("sub_categories"))
        tags = from_union([lambda x: from_list(TagInfo.from_dict, x), from_none], obj.get("tags"))
        thank_users_count = from_union([from_int, from_none], obj.get("thank_users_count"))
        user = from_union([User.from_dict, from_none], obj.get("user"))
        return TorrentInfo(added, added_human, anonymous, category, category_info, comments, cover, filename, hash, hits, hr, id, last_action, last_action_human, leechers, name, numfiles, pick_info, pick_type, pos_state, promotion_info, seeders, size, size_human, small_descr, sp_state, sp_state_real, times_completed, views, active_status, claims_count, description, download_url, extra, has_bookmarked, has_claimed, has_rewarded, has_thanked, images, pick_time, pos_state_until, pos_state_until_human, reward_logs_count, sub_categories, tags, thank_users_count, user)

    def to_dict(self) -> dict:
        result: dict = {}
        result["added"] = from_str(self.added)
        result["added_human"] = from_str(self.added_human)
        result["anonymous"] = from_str(self.anonymous)
        result["category"] = from_int(self.category)
        result["category_info"] = to_class(CategoryInfo, self.category_info)
        result["comments"] = from_int(self.comments)
        result["cover"] = from_str(self.cover)
        result["filename"] = from_str(self.filename)
        result["hash"] = from_str(self.hash)
        result["hits"] = from_int(self.hits)
        result["hr"] = from_int(self.hr)
        result["id"] = from_int(self.id)
        result["last_action"] = from_str(self.last_action)
        result["last_action_human"] = from_str(self.last_action_human)
        result["leechers"] = from_int(self.leechers)
        result["name"] = from_str(self.name)
        result["numfiles"] = from_int(self.numfiles)
        result["pick_info"] = to_class(PickInfo, self.pick_info)
        result["pick_type"] = from_str(self.pick_type)
        result["pos_state"] = from_str(self.pos_state)
        result["promotion_info"] = to_class(PromotionInfo, self.promotion_info)
        result["seeders"] = from_int(self.seeders)
        result["size"] = from_int(self.size)
        result["size_human"] = from_str(self.size_human)
        result["small_descr"] = from_str(self.small_descr)
        result["sp_state"] = from_int(self.sp_state)
        result["sp_state_real"] = from_int(self.sp_state_real)
        result["times_completed"] = from_int(self.times_completed)
        result["views"] = from_int(self.views)
        if self.active_status is not None:
            result["active_status"] = from_union([from_none, lambda x: to_class(ActiveStatusClass, x)], self.active_status)
        if self.claims_count is not None:
            result["claims_count"] = from_union([from_int, from_none], self.claims_count)
        if self.description is not None:
            result["description"] = from_union([lambda x: from_list(lambda x: to_class(Description, x), x), from_none], self.description)
        if self.download_url is not None:
            result["download_url"] = from_union([from_str, from_none], self.download_url)
        if self.extra is not None:
            result["extra"] = from_union([lambda x: to_class(Extra, x), from_none], self.extra)
        if self.has_bookmarked is not None:
            result["has_bookmarked"] = from_union([from_bool, from_none], self.has_bookmarked)
        if self.has_claimed is not None:
            result["has_claimed"] = from_union([from_bool, from_none], self.has_claimed)
        if self.has_rewarded is not None:
            result["has_rewarded"] = from_union([from_bool, from_none], self.has_rewarded)
        if self.has_thanked is not None:
            result["has_thanked"] = from_union([from_bool, from_none], self.has_thanked)
        if self.images is not None:
            result["images"] = from_union([lambda x: from_list(from_str, x), from_none], self.images)
        result["pick_time"] = from_union([from_none, from_str], self.pick_time)
        result["pos_state_until"] = from_union([from_none, from_str], self.pos_state_until)
        result["pos_state_until_human"] = from_union([from_none, from_str], self.pos_state_until_human)
        if self.reward_logs_count is not None:
            result["reward_logs_count"] = from_union([from_int, from_none], self.reward_logs_count)
        if self.sub_categories is not None:
            result["sub_categories"] = from_union([from_none, lambda x: to_class(SubCategories, x)], self.sub_categories)
        if self.tags is not None:
            result["tags"] = from_union([lambda x: from_list(lambda x: to_class(TagInfo, x), x), from_none], self.tags)
        if self.thank_users_count is not None:
            result["thank_users_count"] = from_union([from_int, from_none], self.thank_users_count)
        if self.user is not None:
            result["user"] = from_union([lambda x: to_class(User, x), from_none], self.user)
        return result


@dataclass
class Links:
    """Pagination links info"""
    """First page link"""
    first: str
    """Last page link"""
    last: str
    """Next page link"""
    next: Optional[str] = None
    """Previous page link"""
    prev: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Links':
        assert isinstance(obj, dict)
        first = from_str(obj.get("first"))
        last = from_str(obj.get("last"))
        next = from_union([from_none, from_str], obj.get("next"))
        prev = from_union([from_none, from_str], obj.get("prev"))
        return Links(first, last, next, prev)

    def to_dict(self) -> dict:
        result: dict = {}
        result["first"] = from_str(self.first)
        result["last"] = from_str(self.last)
        result["next"] = from_union([from_none, from_str], self.next)
        result["prev"] = from_union([from_none, from_str], self.prev)
        return result


@dataclass
class Link:
    """Pagination link"""
    """Is active"""
    active: bool
    """Page label"""
    label: str
    """Page url"""
    url: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Link':
        assert isinstance(obj, dict)
        active = from_bool(obj.get("active"))
        label = from_str(obj.get("label"))
        url = from_union([from_none, from_str], obj.get("url"))
        return Link(active, label, url)

    def to_dict(self) -> dict:
        result: dict = {}
        result["active"] = from_bool(self.active)
        result["label"] = from_str(self.label)
        result["url"] = from_union([from_none, from_str], self.url)
        return result


@dataclass
class Meta:
    """Pagination meta info"""
    """Current page"""
    current_page: int
    """From"""
    meta_from: int
    """Last page"""
    last_page: int
    """Links"""
    links: List[Link]
    """Path"""
    path: str
    """Per page"""
    per_page: int
    """To"""
    to: int
    """Total"""
    total: int

    @staticmethod
    def from_dict(obj: Any) -> 'Meta':
        assert isinstance(obj, dict)
        current_page = from_int(obj.get("current_page"))
        meta_from = from_int(obj.get("from"))
        last_page = from_int(obj.get("last_page"))
        links = from_list(Link.from_dict, obj.get("links"))
        path = from_str(obj.get("path"))
        per_page = from_int(obj.get("per_page"))
        to = from_int(obj.get("to"))
        total = from_int(obj.get("total"))
        return Meta(current_page, meta_from, last_page, links, path, per_page, to, total)

    def to_dict(self) -> dict:
        result: dict = {}
        result["current_page"] = from_int(self.current_page)
        result["from"] = from_int(self.meta_from)
        result["last_page"] = from_int(self.last_page)
        result["links"] = from_list(lambda x: to_class(Link, x), self.links)
        result["path"] = from_str(self.path)
        result["per_page"] = from_int(self.per_page)
        result["to"] = from_int(self.to)
        result["total"] = from_int(self.total)
        return result


@dataclass
class TorrentsData:
    """Data wrapper"""
    """Torrent list"""
    data: List[TorrentInfo]
    """Links"""
    links: Links
    """Meta"""
    meta: Meta

    @staticmethod
    def from_dict(obj: Any) -> 'TorrentsData':
        assert isinstance(obj, dict)
        data = from_list(TorrentInfo.from_dict, obj.get("data"))
        links = Links.from_dict(obj.get("links"))
        meta = Meta.from_dict(obj.get("meta"))
        return TorrentsData(data, links, meta)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = from_list(lambda x: to_class(TorrentInfo, x), self.data)
        result["links"] = to_class(Links, self.links)
        result["meta"] = to_class(Meta, self.meta)
        return result


@dataclass
class Torrents:
    """Response wrapper"""
    data: TorrentsData
    """Text message"""
    msg: str
    """Result code, 0 success, others failure"""
    ret: int
    """Request id"""
    rid: str
    """Response time in seconds"""
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'Torrents':
        assert isinstance(obj, dict)
        data = TorrentsData.from_dict(obj.get("data"))
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return Torrents(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(TorrentsData, self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = to_float(self.time)
        return result


def torrents_from_dict(s: Any) -> Torrents:
    return Torrents.from_dict(s)


def torrents_to_dict(x: Torrents) -> Any:
    return to_class(Torrents, x)
