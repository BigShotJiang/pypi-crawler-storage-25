from dataclasses import dataclass
from typing import Optional, Any, TypeVar, Type
from ....utils import from_int, from_none, from_union, from_str, to_class


T = TypeVar("T")


@dataclass
class Query:
    """Filter bookmarks, 1 only bookmarked, 2 only not bookmarked, no default. Compatible with >= 1.9.7"""
    filter_bookmark: Optional[int] = None
    """Filter by size > 1024"""
    filter_size_gt: Optional[int] = None
    """Filter by source"""
    filter_source: Optional[str] = None
    """Keyword filter, searches title and subtitle"""
    filter_title: Optional[str] = None
    """Filter dead torrents, 0 all, 1 active, 2 dead, default 0. Compatible with >= 1.9.7"""
    filter_visible: Optional[int] = None
    """Filter source = 1 or code = 2 data"""
    filter_any_codec_gt: Optional[int] = None
    """Filter source = 1 or code = 2 data"""
    filter_any_source_gt: Optional[int] = None
    """Include counts, same as detail API"""
    include_counts: Optional[str] = None
    """Include fields, same as detail API"""
    include_fields_torrent: Optional[str] = None
    """Include relations, same as detail API"""
    includes: Optional[str] = None
    """Page number"""
    page: Optional[int] = None
    """Items per page"""
    per_page: Optional[int] = None
    """Sorting, multiple separated by English commas. Default ascending, prepend - for descending, e.g. size for ascending by size, -size for descending by size. Available values: id (publish order), comments (comment count), size (size), seeders (seeder count), leechers (leecher count), times_completed (completed count)"""
    sorts: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Query':
        assert isinstance(obj, dict)
        filter_bookmark = from_union([from_int, from_none], obj.get("filter[bookmark]"))
        filter_size_gt = from_union([from_int, from_none], obj.get("filter[size][gt]"))
        filter_source = from_union([from_str, from_none], obj.get("filter[source]"))
        filter_title = from_union([from_str, from_none], obj.get("filter[title]"))
        filter_visible = from_union([from_int, from_none], obj.get("filter[visible]"))
        filter_any_codec_gt = from_union([from_int, from_none], obj.get("filter_any[codec][gt]"))
        filter_any_source_gt = from_union([from_int, from_none], obj.get("filter_any[source][gt]"))
        include_counts = from_union([from_str, from_none], obj.get("include_counts"))
        include_fields_torrent = from_union([from_str, from_none], obj.get("include_fields[torrent]"))
        includes = from_union([from_str, from_none], obj.get("includes"))
        page = from_union([from_int, from_none], obj.get("page"))
        per_page = from_union([from_int, from_none], obj.get("per_page"))
        sorts = from_union([from_str, from_none], obj.get("sorts"))
        return Query(filter_bookmark, filter_size_gt, filter_source, filter_title, filter_visible, filter_any_codec_gt, filter_any_source_gt, include_counts, include_fields_torrent, includes, page, per_page, sorts)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.filter_bookmark is not None:
            result["filter[bookmark]"] = from_union([from_int, from_none], self.filter_bookmark)
        if self.filter_size_gt is not None:
            result["filter[size][gt]"] = from_union([from_int, from_none], self.filter_size_gt)
        if self.filter_source is not None:
            result["filter[source]"] = from_union([from_str, from_none], self.filter_source)
        if self.filter_title is not None:
            result["filter[title]"] = from_union([from_str, from_none], self.filter_title)
        if self.filter_visible is not None:
            result["filter[visible]"] = from_union([from_int, from_none], self.filter_visible)
        if self.filter_any_codec_gt is not None:
            result["filter_any[codec][gt]"] = from_union([from_int, from_none], self.filter_any_codec_gt)
        if self.filter_any_source_gt is not None:
            result["filter_any[source][gt]"] = from_union([from_int, from_none], self.filter_any_source_gt)
        if self.include_counts is not None:
            result["include_counts"] = from_union([from_str, from_none], self.include_counts)
        if self.include_fields_torrent is not None:
            result["include_fields[torrent]"] = from_union([from_str, from_none], self.include_fields_torrent)
        if self.includes is not None:
            result["includes"] = from_union([from_str, from_none], self.includes)
        if self.page is not None:
            result["page"] = from_union([from_int, from_none], self.page)
        if self.per_page is not None:
            result["per_page"] = from_union([from_int, from_none], self.per_page)
        if self.sorts is not None:
            result["sorts"] = from_union([from_str, from_none], self.sorts)
        return result


def query_from_dict(s: Any) -> Query:
    return Query.from_dict(s)


def query_to_dict(x: Query) -> Any:
    return to_class(Query, x)
