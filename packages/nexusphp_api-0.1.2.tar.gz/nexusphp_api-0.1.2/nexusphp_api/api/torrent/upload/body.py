from dataclasses import dataclass
from typing import Optional, Any, TypeVar, Type, cast
from ....utils import from_str, from_int, from_none, from_union, to_class


T = TypeVar("T")


@dataclass
class Body:
    """Description"""
    descr: str
    """Torrent file, ending with .torrent"""
    file: str
    """Title"""
    name: str
    """Type"""
    type: int
    """Subcategory audiocodec field, see section list API for details"""
    audiocodec: Optional[int] = None
    """Subcategory codec field, see category list API for details"""
    codec: Optional[int] = None
    """Subcategory medium field, see section list API for details"""
    medium: Optional[int] = None
    """Nfo file"""
    nfo: Optional[str] = None
    """Pick type, can only be: normal (normal), hot (hot), classic (classic), recommended (recommended)"""
    pick_type: Optional[str] = None
    """Position state, can only be: normal (normal), sticky (level 1 sticky), r_sticky (level 2 sticky)"""
    pos_state: Optional[str] = None
    """Position state until, valid when pos_state != 'normal'"""
    pos_state_until: Optional[str] = None
    """Price, which is the bonus deducted for downloading the torrent"""
    price: Optional[int] = None
    """Subcategory processing field, see section list API for details"""
    processing: Optional[int] = None
    """PTGen link (compatible with >= 1.9.7)"""
    pt_gen: Optional[str] = None
    """Subtitle"""
    small_descr: Optional[str] = None
    """Subcategory source field, see section list API for details"""
    source: Optional[int] = None
    """Subcategory standard field, see section list API for details"""
    standard: Optional[int] = None
    """Tag IDs, multiple separated by English commas"""
    tags: Optional[str] = None
    """Subcategory team field, see section list API for details"""
    team: Optional[int] = None
    """Media Info"""
    technical_info: Optional[str] = None
    """Is anonymous, yes or no, not yes is treated as no"""
    uplver: Optional[str] = None
    """IMDb link"""
    url: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Body':
        assert isinstance(obj, dict)
        descr = from_str(obj.get("descr"))
        file = from_str(obj.get("file"))
        name = from_str(obj.get("name"))
        type = from_int(obj.get("type"))
        audiocodec = from_union([from_int, from_none], obj.get("audiocodec"))
        codec = from_union([from_int, from_none], obj.get("codec"))
        medium = from_union([from_int, from_none], obj.get("medium"))
        nfo = from_union([from_str, from_none], obj.get("nfo"))
        pick_type = from_union([from_str, from_none], obj.get("pick_type"))
        pos_state = from_union([from_str, from_none], obj.get("pos_state"))
        pos_state_until = from_union([from_str, from_none], obj.get("pos_state_until"))
        price = from_union([from_int, from_none], obj.get("price"))
        processing = from_union([from_int, from_none], obj.get("processing"))
        pt_gen = from_union([from_str, from_none], obj.get("pt_gen"))
        small_descr = from_union([from_str, from_none], obj.get("small_descr"))
        source = from_union([from_int, from_none], obj.get("source"))
        standard = from_union([from_int, from_none], obj.get("standard"))
        tags = from_union([from_str, from_none], obj.get("tags"))
        team = from_union([from_int, from_none], obj.get("team"))
        technical_info = from_union([from_str, from_none], obj.get("technical_info"))
        uplver = from_union([from_str, from_none], obj.get("uplver"))
        url = from_union([from_str, from_none], obj.get("url"))
        return Body(descr, file, name, type, audiocodec, codec, medium, nfo, pick_type, pos_state, pos_state_until, price, processing, pt_gen, small_descr, source, standard, tags, team, technical_info, uplver, url)

    def to_dict(self) -> dict:
        result: dict = {}
        result["descr"] = from_str(self.descr)
        result["file"] = from_str(self.file)
        result["name"] = from_str(self.name)
        result["type"] = from_int(self.type)
        if self.audiocodec is not None:
            result["audiocodec"] = from_union([from_int, from_none], self.audiocodec)
        if self.codec is not None:
            result["codec"] = from_union([from_int, from_none], self.codec)
        if self.medium is not None:
            result["medium"] = from_union([from_int, from_none], self.medium)
        if self.nfo is not None:
            result["nfo"] = from_union([from_str, from_none], self.nfo)
        if self.pick_type is not None:
            result["pick_type"] = from_union([from_str, from_none], self.pick_type)
        if self.pos_state is not None:
            result["pos_state"] = from_union([from_str, from_none], self.pos_state)
        if self.pos_state_until is not None:
            result["pos_state_until"] = from_union([from_str, from_none], self.pos_state_until)
        if self.price is not None:
            result["price"] = from_union([from_int, from_none], self.price)
        if self.processing is not None:
            result["processing"] = from_union([from_int, from_none], self.processing)
        if self.pt_gen is not None:
            result["pt_gen"] = from_union([from_str, from_none], self.pt_gen)
        if self.small_descr is not None:
            result["small_descr"] = from_union([from_str, from_none], self.small_descr)
        if self.source is not None:
            result["source"] = from_union([from_int, from_none], self.source)
        if self.standard is not None:
            result["standard"] = from_union([from_int, from_none], self.standard)
        if self.tags is not None:
            result["tags"] = from_union([from_str, from_none], self.tags)
        if self.team is not None:
            result["team"] = from_union([from_int, from_none], self.team)
        if self.technical_info is not None:
            result["technical_info"] = from_union([from_str, from_none], self.technical_info)
        if self.uplver is not None:
            result["uplver"] = from_union([from_str, from_none], self.uplver)
        if self.url is not None:
            result["url"] = from_union([from_str, from_none], self.url)
        return result


def body_from_dict(s: Any) -> Body:
    return Body.from_dict(s)


def body_to_dict(x: Body) -> Any:
    return to_class(Body, x)
