from dataclasses import dataclass
from typing import Any, Optional, TypeVar, Type
from ....utils import from_int, from_none, from_union, to_class, from_str, from_float, to_float


T = TypeVar("T")


@dataclass
class DataData:
    """Torrent ID"""
    id: int

    @staticmethod
    def from_dict(obj: Any) -> 'DataData':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        return DataData(id)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        return result


@dataclass
class UploadData:
    """Data"""
    data: Optional[DataData] = None

    @staticmethod
    def from_dict(obj: Any) -> 'UploadData':
        assert isinstance(obj, dict)
        data = from_union([DataData.from_dict, from_none], obj.get("data"))
        return UploadData(data)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.data is not None:
            result["data"] = from_union([lambda x: to_class(DataData, x), from_none], self.data)
        return result


@dataclass
class Upload:
    """Data"""
    data: UploadData
    """Text message"""
    msg: str
    """Result code, 0 means success, others mean failure"""
    ret: int
    """Request ID"""
    rid: str
    """Response time in seconds"""
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'Upload':
        assert isinstance(obj, dict)
        data = UploadData.from_dict(obj.get("data"))
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return Upload(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(UploadData, self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = to_float(self.time)
        return result


def upload_from_dict(s: Any) -> Upload:
    return Upload.from_dict(s)


def upload_to_dict(x: Upload) -> Any:
    return to_class(Upload, x)
