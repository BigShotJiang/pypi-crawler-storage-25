from typing import Dict, Any, TypeVar, Callable


T = TypeVar("T")


def from_dict(f: Callable[[Any], T], x: Any) -> Dict[str, T]:
    assert isinstance(x, dict)
    return { k: f(v) for (k, v) in x.items() }


def body_from_dict(s: Any) -> Dict[str, Any]:
    return from_dict(lambda x: x, s)


def body_to_dict(x: Dict[str, Any]) -> Any:
    return from_dict(lambda x: x, x)