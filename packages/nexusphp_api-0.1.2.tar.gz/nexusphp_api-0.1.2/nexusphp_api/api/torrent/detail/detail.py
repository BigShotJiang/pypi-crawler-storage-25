from enum import Enum
from dataclasses import dataclass
from typing import Any, Optional, Dict, List, TypeVar, Type, Callable
from ....utils import from_float, to_enum, to_float, from_int, from_str, from_none, from_union, to_class, from_dict, from_list, from_bool, from_int_optional


T = TypeVar("T")
EnumT = TypeVar("EnumT", bound=Enum)


class ActiveStatusEnum(Enum):
    """Active status"""
    INACTIVITY = "inactivity"
    LEECHING = "leeching"
    SEEDING = "seeding"


class Finished(Enum):
    """Finished status"""
    NO = "no"
    YES = "yes"


class Status(Enum):
    """Confirmation status"""
    CONFIRMED = "confirmed"
    PENDING = "pending"


class TypeEnum(Enum):
    """Type"""
    ATTACHMENT = "attachment"
    IMAGE = "image"
    TEXT = "text"


@dataclass
class ActiveStatusClass:
    """Active status"""
    active_status: ActiveStatusEnum
    """Finished status"""
    finished: Finished
    """Download progress, float in [0,1]"""
    progress: float

    @staticmethod
    def from_dict(obj: Any) -> 'ActiveStatusClass':
        assert isinstance(obj, dict)
        active_status = ActiveStatusEnum(obj.get("active_status"))
        finished = Finished(obj.get("finished"))
        progress = from_float(obj.get("progress"))
        return ActiveStatusClass(active_status, finished, progress)

    def to_dict(self) -> dict:
        result: dict = {}
        result["active_status"] = to_enum(ActiveStatusEnum, self.active_status)
        result["finished"] = to_enum(Finished, self.finished)
        result["progress"] = to_float(self.progress)
        return result


@dataclass
class CategoryInfo:
    """Category info"""
    id: int
    name: str

    @staticmethod
    def from_dict(obj: Any) -> 'CategoryInfo':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        return CategoryInfo(id, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        return result


@dataclass
class PromotionInfo:
    """Promotion info"""
    text: str
    up_multiplier: Optional[int]
    down_multiplier: Optional[int]
    color: str

    @staticmethod
    def from_dict(obj: Any) -> 'PromotionInfo':
        if obj is None:
            return PromotionInfo("", None, None, "")
        assert isinstance(obj, dict)
        text = from_str(obj.get("text"))
        up_multiplier = obj.get("up_multiplier")
        if up_multiplier is not None:
            try:
                up_multiplier = int(up_multiplier)
            except (ValueError, TypeError):
                up_multiplier = None
        down_multiplier = obj.get("down_multiplier")
        if down_multiplier is not None:
            try:
                down_multiplier = int(down_multiplier)
            except (ValueError, TypeError):
                down_multiplier = None
        color = from_str(obj.get("color"))
        return PromotionInfo(text, up_multiplier, down_multiplier, color)

    def to_dict(self) -> dict:
        result: dict = {}
        result["text"] = from_str(self.text)
        if self.up_multiplier is not None:
            result["up_multiplier"] = self.up_multiplier
        if self.down_multiplier is not None:
            result["down_multiplier"] = self.down_multiplier
        result["color"] = from_str(self.color)
        return result


@dataclass
class PickInfo:
    """Pick info"""
    text: str
    color: str

    @staticmethod
    def from_dict(obj: Any) -> 'PickInfo':
        assert isinstance(obj, dict)
        text = from_str(obj.get("text"))
        color = from_str(obj.get("color"))
        return PickInfo(text, color)

    def to_dict(self) -> dict:
        result: dict = {}
        result["text"] = from_str(self.text)
        result["color"] = from_str(self.color)
        return result


@dataclass
class User:
    """User info"""
    id: int
    username: str
    email: Optional[str]
    status: Status
    enabled: Finished
    added: str
    added_human: str
    last_access: str
    last_access_human: str
    last_login: str
    last_login_human: str
    user_class: int
    class_text: str
    avatar: str
    invites: int
    attendance_card: int
    uploaded: int
    uploaded_text: str
    downloaded: int
    downloaded_text: str
    bonus: int
    bonus_human: str
    seed_points: int
    seed_points_human: str
    seedtime: int
    seedtime_text: str
    leechtime: int
    leechtime_text: str
    share_ratio: str
    seed_points_per_hour: Optional[int]
    seed_points_per_hour_human: Optional[str]
    seed_bonus_per_hour: Optional[int]
    seed_bonus_per_hour_human: Optional[str]

    @staticmethod
    def from_dict(obj: Any) -> 'User':
        if obj is None:
            return None
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        username = from_str(obj.get("username"))
        email = from_union([from_str, from_none], obj.get("email"))
        status = Status(obj.get("status"))
        enabled = Finished(obj.get("enabled"))
        added = from_str(obj.get("added"))
        added_human = from_str(obj.get("added_human"))
        last_access = from_str(obj.get("last_access"))
        last_access_human = from_str(obj.get("last_access_human"))
        last_login = from_str(obj.get("last_login"))
        last_login_human = from_str(obj.get("last_login_human"))
        user_class = from_int(obj.get("class"))
        class_text = from_str(obj.get("class_text"))
        avatar = from_str(obj.get("avatar"))
        invites = from_int(obj.get("invites"))
        attendance_card = from_int(obj.get("attendance_card"))
        uploaded = from_int(obj.get("uploaded"))
        uploaded_text = from_str(obj.get("uploaded_text"))
        downloaded = from_int(obj.get("downloaded"))
        downloaded_text = from_str(obj.get("downloaded_text"))
        bonus = obj.get("bonus")
        if bonus is not None:
            try:
                bonus = int(bonus)
            except (ValueError, TypeError):
                bonus = None
        bonus_human = from_str(obj.get("bonus_human"))
        seed_points = obj.get("seed_points")
        if seed_points is not None:
            try:
                seed_points = int(seed_points)
            except (ValueError, TypeError):
                seed_points = None
        seed_points_human = from_str(obj.get("seed_points_human"))
        seedtime = from_int(obj.get("seedtime"))
        seedtime_text = from_str(obj.get("seedtime_text"))
        leechtime = from_int(obj.get("leechtime"))
        leechtime_text = from_str(obj.get("leechtime_text"))
        share_ratio = from_str(obj.get("share_ratio"))
        seed_points_per_hour = obj.get("seed_points_per_hour")
        if seed_points_per_hour is not None:
            try:
                seed_points_per_hour = int(seed_points_per_hour)
            except (ValueError, TypeError):
                seed_points_per_hour = None
        seed_points_per_hour_human = obj.get("seed_points_per_hour_human")
        if seed_points_per_hour_human is not None:
            seed_points_per_hour_human = str(seed_points_per_hour_human)
        else:
            seed_points_per_hour_human = None
        seed_bonus_per_hour = obj.get("seed_bonus_per_hour")
        if seed_bonus_per_hour is not None:
            try:
                seed_bonus_per_hour = int(seed_bonus_per_hour)
            except (ValueError, TypeError):
                seed_bonus_per_hour = None
        seed_bonus_per_hour_human = obj.get("seed_bonus_per_hour_human")
        if seed_bonus_per_hour_human is not None:
            seed_bonus_per_hour_human = str(seed_bonus_per_hour_human)
        else:
            seed_bonus_per_hour_human = None
        return User(id, username, email, status, enabled, added, added_human, last_access, last_access_human, last_login, last_login_human, user_class, class_text, avatar, invites, attendance_card, uploaded, uploaded_text, downloaded, downloaded_text, bonus, bonus_human, seed_points, seed_points_human, seedtime, seedtime_text, leechtime, leechtime_text, share_ratio, seed_points_per_hour, seed_points_per_hour_human, seed_bonus_per_hour, seed_bonus_per_hour_human)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["username"] = from_str(self.username)
        if self.email is not None:
            result["email"] = from_union([from_str, from_none], self.email)
        result["status"] = to_enum(Status, self.status)
        result["enabled"] = to_enum(Finished, self.enabled)
        result["added"] = from_str(self.added)
        result["added_human"] = from_str(self.added_human)
        result["last_access"] = from_str(self.last_access)
        result["last_access_human"] = from_str(self.last_access_human)
        result["last_login"] = from_str(self.last_login)
        result["last_login_human"] = from_str(self.last_login_human)
        result["class"] = from_int(self.user_class)
        result["class_text"] = from_str(self.class_text)
        result["avatar"] = from_str(self.avatar)
        result["invites"] = from_int(self.invites)
        result["attendance_card"] = from_int(self.attendance_card)
        result["uploaded"] = from_int(self.uploaded)
        result["uploaded_text"] = from_str(self.uploaded_text)
        result["downloaded"] = from_int(self.downloaded)
        result["downloaded_text"] = from_str(self.downloaded_text)
        result["bonus"] = from_int(self.bonus)
        result["bonus_human"] = from_str(self.bonus_human)
        result["seed_points"] = from_int(self.seed_points)
        result["seed_points_human"] = from_str(self.seed_points_human)
        result["seedtime"] = from_int(self.seedtime)
        result["seedtime_text"] = from_str(self.seedtime_text)
        result["leechtime"] = from_int(self.leechtime)
        result["leechtime_text"] = from_str(self.leechtime_text)
        result["share_ratio"] = from_str(self.share_ratio)
        if self.seed_points_per_hour is not None:
            result["seed_points_per_hour"] = from_union([from_int, from_none], self.seed_points_per_hour)
        if self.seed_points_per_hour_human is not None:
            result["seed_points_per_hour_human"] = from_union([from_str, from_none], self.seed_points_per_hour_human)
        if self.seed_bonus_per_hour is not None:
            result["seed_bonus_per_hour"] = from_union([from_int, from_none], self.seed_bonus_per_hour)
        if self.seed_bonus_per_hour_human is not None:
            result["seed_bonus_per_hour_human"] = from_union([from_str, from_none], self.seed_bonus_per_hour_human)
        return result


@dataclass
class Videos:
    """Video info"""
    Runtime: str
    Resolution: str
    Bitrate: str
    Bit_depth: str
    Frame_rate: str
    Profile: str

    @staticmethod
    def from_dict(obj: Any) -> 'Videos':
        assert isinstance(obj, dict)
        Runtime = from_str(obj.get("Runtime"))
        Resolution = from_str(obj.get("Resolution"))
        Bitrate = from_str(obj.get("Bitrate"))
        Bit_depth = from_str(obj.get("Bit depth"))
        Frame_rate = from_str(obj.get("Frame rate"))
        Profile = from_str(obj.get("Profile"))
        return Videos(Runtime, Resolution, Bitrate, Bit_depth, Frame_rate, Profile)

    def to_dict(self) -> dict:
        result: dict = {}
        result["Runtime"] = from_str(self.Runtime)
        result["Resolution"] = from_str(self.Resolution)
        result["Bitrate"] = from_str(self.Bitrate)
        result["Bit depth"] = from_str(self.Bit_depth)
        result["Frame rate"] = from_str(self.Frame_rate)
        result["Profile"] = from_str(self.Profile)
        return result


@dataclass
class MediaInfoSummary:
    """Media info summary"""
    videos: Optional[Any] = None
    audios: Optional[Any] = None
    subtitles: Optional[Any] = None

    @staticmethod
    def from_dict(obj: Any) -> 'MediaInfoSummary':
        if obj is None:
            return MediaInfoSummary(None, None, None)
        if not isinstance(obj, dict):
            return MediaInfoSummary(None, None, None)
        videos = obj.get("videos")
        if videos is not None and isinstance(videos, dict):
            try:
                videos = Videos.from_dict(videos)
            except:
                videos = None
        audios = obj.get("audios")
        subtitles = obj.get("subtitles")
        return MediaInfoSummary(videos, audios, subtitles)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.videos is not None:
            result["videos"] = self.videos
        if self.audios is not None:
            result["audios"] = self.audios
        if self.subtitles is not None:
            result["subtitles"] = self.subtitles
        return result


@dataclass
class Extra:
    """Extra info"""
    descr: str
    media_info: Optional[str] = None
    media_info_summary: Optional[MediaInfoSummary] = None
    nfo: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Extra':
        assert isinstance(obj, dict)
        descr = from_str(obj.get("descr"))
        media_info = from_union([from_none, from_str], obj.get("media_info"))
        media_info_summary = from_union([from_none, MediaInfoSummary.from_dict], obj.get("media_info_summary"))
        nfo = from_union([from_none, from_str], obj.get("nfo"))
        return Extra(descr, media_info, media_info_summary, nfo)

    def to_dict(self) -> dict:
        result: dict = {}
        result["descr"] = from_str(self.descr)
        result["media_info"] = from_union([from_none, from_str], self.media_info)
        if self.media_info_summary is not None:
            result["media_info_summary"] = from_union([from_none, lambda x: to_class(MediaInfoSummary, x)], self.media_info_summary)
        result["nfo"] = from_union([from_none, from_str], self.nfo)
        return result


@dataclass
class TagInfo:
    """Tag info"""
    id: int
    name: str
    color: str
    font_color: str
    font_size: str
    padding: str
    margin: str
    border_radius: str
    priority: int
    created_at: str
    updated_at: str

    @staticmethod
    def from_dict(obj: Any) -> 'TagInfo':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        color = from_str(obj.get("color"))
        font_color = from_str(obj.get("font_color"))
        font_size = from_str(obj.get("font_size"))
        padding = from_str(obj.get("padding"))
        margin = from_str(obj.get("margin"))
        border_radius = from_str(obj.get("border_radius"))
        priority = from_int(obj.get("priority"))
        created_at = from_str(obj.get("created_at"))
        updated_at = from_str(obj.get("updated_at"))
        return TagInfo(id, name, color, font_color, font_size, padding, margin, border_radius, priority, created_at, updated_at)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        result["color"] = from_str(self.color)
        result["font_color"] = from_str(self.font_color)
        result["font_size"] = from_str(self.font_size)
        result["padding"] = from_str(self.padding)
        result["margin"] = from_str(self.margin)
        result["border_radius"] = from_str(self.border_radius)
        result["priority"] = from_int(self.priority)
        result["created_at"] = from_str(self.created_at)
        result["updated_at"] = from_str(self.updated_at)
        return result


@dataclass
class SubCategoryItem:
    """Subcategory item"""
    label: str
    value: str

    @staticmethod
    def from_dict(obj: Any) -> 'SubCategoryItem':
        assert isinstance(obj, dict)
        label = from_str(obj.get("label"))
        value = from_str(obj.get("value"))
        return SubCategoryItem(label, value)

    def to_dict(self) -> dict:
        result: dict = {}
        result["label"] = from_str(self.label)
        result["value"] = from_str(self.value)
        return result


@dataclass
class SubCategories:
    """Subcategories"""
    medium: Optional[SubCategoryItem] = None
    codec: Optional[SubCategoryItem] = None
    standard: Optional[SubCategoryItem] = None
    team: Optional[SubCategoryItem] = None
    source: Optional[SubCategoryItem] = None
    audiocodec: Optional[SubCategoryItem] = None
    processing: Optional[SubCategoryItem] = None

    @staticmethod
    def from_dict(obj: Any) -> 'SubCategories':
        assert isinstance(obj, dict)
        medium = from_union([SubCategoryItem.from_dict, from_none], obj.get("medium"))
        codec = from_union([SubCategoryItem.from_dict, from_none], obj.get("codec"))
        standard = from_union([SubCategoryItem.from_dict, from_none], obj.get("standard"))
        team = from_union([SubCategoryItem.from_dict, from_none], obj.get("team"))
        source = from_union([SubCategoryItem.from_dict, from_none], obj.get("source"))
        audiocodec = from_union([SubCategoryItem.from_dict, from_none], obj.get("audiocodec"))
        processing = from_union([SubCategoryItem.from_dict, from_none], obj.get("processing"))
        return SubCategories(medium, codec, standard, team, source, audiocodec, processing)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.medium is not None:
            result["medium"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.medium)
        if self.codec is not None:
            result["codec"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.codec)
        if self.standard is not None:
            result["standard"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.standard)
        if self.team is not None:
            result["team"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.team)
        if self.source is not None:
            result["source"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.source)
        if self.audiocodec is not None:
            result["audiocodec"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.audiocodec)
        if self.processing is not None:
            result["processing"] = from_union([lambda x: to_class(SubCategoryItem, x), from_none], self.processing)
        return result


@dataclass
class DescriptionData:
    """Description data"""
    text: Optional[str] = None
    url: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'DescriptionData':
        assert isinstance(obj, dict)
        text = from_union([from_str, from_none], obj.get("text"))
        url = from_union([from_str, from_none], obj.get("url"))
        return DescriptionData(text, url)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.text is not None:
            result["text"] = from_union([from_str, from_none], self.text)
        if self.url is not None:
            result["url"] = from_union([from_str, from_none], self.url)
        return result


@dataclass
class Description:
    """Description item"""
    data: DescriptionData
    type: TypeEnum

    @staticmethod
    def from_dict(obj: Any) -> 'Description':
        assert isinstance(obj, dict)
        data = DescriptionData.from_dict(obj.get("data"))
        type = TypeEnum(obj.get("type"))
        return Description(data, type)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(DescriptionData, self.data)
        result["type"] = to_enum(TypeEnum, self.type)
        return result


@dataclass
class DataData:
    """Torrent detail data"""
    id: int
    category: CategoryInfo
    source: str
    url: str
    download_url: str
    name: str
    small_descr: str
    labels: List[TagInfo]
    size: int
    size_text: str
    added: str
    added_timestamp: int
    added_human: str
    comments: int
    hits: int
    times_completed: int
    seeders: int
    leechers: int
    subtitle: Optional[str] = None
    chinese_title: Optional[str] = None
    english_title: Optional[str] = None
    other_titles: Optional[List[str]] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    total_episodes: Optional[int] = None
    pick: Optional[PickInfo] = None
    promotion_time_type: Optional[str] = None
    promotion_until: Optional[int] = None
    promotion_until_timestamp: Optional[int] = None
    active_status: Optional[ActiveStatusClass] = None
    hr: Optional[bool] = None
    promotion: Optional[PromotionInfo] = None
    price: Optional[int] = None
    bargain_price: Optional[int] = None
    bargain_until: Optional[int] = None
    bargain_until_timestamp: Optional[int] = None
    user: Optional[User] = None
    extra: Optional[Extra] = None
    subcategories: Optional[SubCategories] = None
    descriptions: Optional[List[Description]] = None
    basic_info: Optional[Dict[str, Any]] = None

    @staticmethod
    def from_dict(obj: Any) -> 'DataData':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        category = CategoryInfo.from_dict(obj.get("category"))
        source = from_str(obj.get("source"))
        url = from_str(obj.get("url"))
        download_url = from_str(obj.get("download_url"))
        name = from_str(obj.get("name"))
        small_descr = from_str(obj.get("small_descr"))
        labels = from_list(TagInfo.from_dict, obj.get("labels"))
        size = from_int(obj.get("size"))
        size_text = from_str(obj.get("size_text"))
        added = from_str(obj.get("added"))
        added_timestamp = from_int(obj.get("added_timestamp"))
        added_human = from_str(obj.get("added_human"))
        comments = from_int(obj.get("comments"))
        hits = from_int(obj.get("hits"))
        times_completed = from_int(obj.get("times_completed"))
        seeders = from_int(obj.get("seeders"))
        leechers = from_int(obj.get("leechers"))
        subtitle = from_union([from_str, from_none], obj.get("subtitle"))
        chinese_title = from_union([from_str, from_none], obj.get("chinese_title"))
        english_title = from_union([from_str, from_none], obj.get("english_title"))
        other_titles = from_union([lambda x: from_list(from_str, x), from_none], obj.get("other_titles"))
        season = from_union([from_int, from_none], obj.get("season"))
        episode = from_union([from_int, from_none], obj.get("episode"))
        total_episodes = from_union([from_int, from_none], obj.get("total_episodes"))
        pick = from_union([PickInfo.from_dict, from_none], obj.get("pick"))
        promotion_time_type = from_union([from_str, from_none], obj.get("promotion_time_type"))
        promotion_until = from_union([from_int, from_none], obj.get("promotion_until"))
        promotion_until_timestamp = from_union([from_int, from_none], obj.get("promotion_until_timestamp"))
        active_status = from_union([ActiveStatusClass.from_dict, from_none], obj.get("active_status"))
        hr = from_union([from_bool, from_none], obj.get("hr"))
        promotion = from_union([PromotionInfo.from_dict, from_none], obj.get("promotion"))
        price = from_union([from_int, from_none], obj.get("price"))
        bargain_price = from_union([from_int, from_none], obj.get("bargain_price"))
        bargain_until = from_union([from_int, from_none], obj.get("bargain_until"))
        bargain_until_timestamp = from_union([from_int, from_none], obj.get("bargain_until_timestamp"))
        user = from_union([User.from_dict, from_none], obj.get("user"))
        extra = from_union([Extra.from_dict, from_none], obj.get("extra"))
        subcategories = from_union([SubCategories.from_dict, from_none], obj.get("subcategories"))
        descriptions = from_union([lambda x: from_list(Description.from_dict, x), from_none], obj.get("descriptions"))
        basic_info = obj.get("basic_info")
        return DataData(id, category, source, url, download_url, name, small_descr, labels, size, size_text, added, added_timestamp, added_human, comments, hits, times_completed, seeders, leechers, subtitle, chinese_title, english_title, other_titles, season, episode, total_episodes, pick, promotion_time_type, promotion_until, promotion_until_timestamp, active_status, hr, promotion, price, bargain_price, bargain_until, bargain_until_timestamp, user, extra, subcategories, descriptions, basic_info)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["category"] = to_class(CategoryInfo, self.category)
        result["source"] = from_str(self.source)
        result["url"] = from_str(self.url)
        result["download_url"] = from_str(self.download_url)
        result["name"] = from_str(self.name)
        result["small_descr"] = from_str(self.small_descr)
        result["labels"] = from_list(lambda x: to_class(TagInfo, x), self.labels)
        result["size"] = from_int(self.size)
        result["size_text"] = from_str(self.size_text)
        result["added"] = from_str(self.added)
        result["added_timestamp"] = from_int(self.added_timestamp)
        result["added_human"] = from_str(self.added_human)
        result["comments"] = from_int(self.comments)
        result["hits"] = from_int(self.hits)
        result["times_completed"] = from_int(self.times_completed)
        result["seeders"] = from_int(self.seeders)
        result["leechers"] = from_int(self.leechers)
        if self.subtitle is not None:
            result["subtitle"] = from_union([from_str, from_none], self.subtitle)
        if self.chinese_title is not None:
            result["chinese_title"] = from_union([from_str, from_none], self.chinese_title)
        if self.english_title is not None:
            result["english_title"] = from_union([from_str, from_none], self.english_title)
        if self.other_titles is not None:
            result["other_titles"] = from_union([lambda x: from_list(from_str, x), from_none], self.other_titles)
        if self.season is not None:
            result["season"] = from_union([from_int, from_none], self.season)
        if self.episode is not None:
            result["episode"] = from_union([from_int, from_none], self.episode)
        if self.total_episodes is not None:
            result["total_episodes"] = from_union([from_int, from_none], self.total_episodes)
        if self.pick is not None:
            result["pick"] = from_union([lambda x: to_class(PickInfo, x), from_none], self.pick)
        if self.promotion_time_type is not None:
            result["promotion_time_type"] = from_union([from_str, from_none], self.promotion_time_type)
        if self.promotion_until is not None:
            result["promotion_until"] = from_union([from_int, from_none], self.promotion_until)
        if self.promotion_until_timestamp is not None:
            result["promotion_until_timestamp"] = from_union([from_int, from_none], self.promotion_until_timestamp)
        if self.active_status is not None:
            result["active_status"] = from_union([lambda x: to_class(ActiveStatusClass, x), from_none], self.active_status)
        if self.hr is not None:
            result["hr"] = from_union([from_bool, from_none], self.hr)
        if self.promotion is not None:
            result["promotion"] = from_union([lambda x: to_class(PromotionInfo, x), from_none], self.promotion)
        if self.price is not None:
            result["price"] = from_union([from_int, from_none], self.price)
        if self.bargain_price is not None:
            result["bargain_price"] = from_union([from_int, from_none], self.bargain_price)
        if self.bargain_until is not None:
            result["bargain_until"] = from_union([from_int, from_none], self.bargain_until)
        if self.bargain_until_timestamp is not None:
            result["bargain_until_timestamp"] = from_union([from_int, from_none], self.bargain_until_timestamp)
        if self.user is not None:
            result["user"] = from_union([lambda x: to_class(User, x), from_none], self.user)
        if self.extra is not None:
            result["extra"] = from_union([lambda x: to_class(Extra, x), from_none], self.extra)
        if self.subcategories is not None:
            result["subcategories"] = from_union([lambda x: to_class(SubCategories, x), from_none], self.subcategories)
        if self.descriptions is not None:
            result["descriptions"] = from_union([lambda x: from_list(lambda y: to_class(Description, y), x), from_none], self.descriptions)
        if self.basic_info is not None:
            result["basic_info"] = self.basic_info
        return result


@dataclass
class DetailData:
    """Detail data wrapper"""
    data: DataData

    @staticmethod
    def from_dict(obj: Any) -> 'DetailData':
        assert isinstance(obj, dict)
        data = DataData.from_dict(obj.get("data"))
        return DetailData(data)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(DataData, self.data)
        return result


@dataclass
class Detail:
    """Detail wrapper"""
    data: DetailData
    msg: str
    ret: int
    rid: str
    time: float

    @staticmethod
    def from_dict(obj: Any) -> 'Detail':
        assert isinstance(obj, dict)
        data = DetailData.from_dict(obj.get("data"))
        msg = from_str(obj.get("msg"))
        ret = from_int(obj.get("ret"))
        rid = from_str(obj.get("rid"))
        time = from_float(obj.get("time"))
        return Detail(data, msg, ret, rid, time)

    def to_dict(self) -> dict:
        result: dict = {}
        result["data"] = to_class(DetailData, self.data)
        result["msg"] = from_str(self.msg)
        result["ret"] = from_int(self.ret)
        result["rid"] = from_str(self.rid)
        result["time"] = to_float(self.time)
        return result


def detail_from_dict(s: Any) -> Detail:
    return Detail.from_dict(s)


def detail_to_dict(x: Detail) -> Any:
    return to_class(Detail, x)
