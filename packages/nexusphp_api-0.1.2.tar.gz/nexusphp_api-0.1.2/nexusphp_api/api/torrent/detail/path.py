from dataclasses import dataclass
from typing import Any, TypeVar, Type, cast
from ....utils import from_int, from_str, to_class


T = TypeVar("T")


@dataclass
class Path:
    id: int
    name: str

    @staticmethod
    def from_dict(obj: Any) -> 'Path':
        assert isinstance(obj, dict)
        id = from_int(obj.get("id"))
        name = from_str(obj.get("name"))
        return Path(id, name)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_int(self.id)
        result["name"] = from_str(self.name)
        return result


def path_from_dict(s: Any) -> Path:
    return Path.from_dict(s)


def path_to_dict(x: Path) -> Any:
    return to_class(Path, x)
