from dataclasses import dataclass
from typing import Optional, Any, TypeVar, Type
from ....utils import from_str, from_none, from_union, to_class


T = TypeVar("T")


@dataclass
class Query:
    """Extra fields, available values: bonus_reward_values (bonus reward options)"""
    extra_fields: Optional[str] = None
    """Extra settings, available values: torrent.claim_torrent_user_counts_up_limit (user claim count limit per torrent)"""
    extra_settings: Optional[str] = None
    """Include counts, available values: claims (claims), thank_users (thank users), reward_logs (rewards)"""
    include_counts: Optional[str] = None
    """Include fields, available values: description (category description), download_url (torrent download URL), has_bookmarked (is bookmarked), has_claimed (is claimed), has_thanked (is thanked), has_rewarded (is rewarded), active_status (active status, compatible with >= v1.9.10)"""
    include_fields_torrent: Optional[str] = None
    """Include relations, available values: user (uploader), tags (tags), extra (extra info like detailed description, MediaInfo)"""
    includes: Optional[str] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Query':
        assert isinstance(obj, dict)
        extra_fields = from_union([from_str, from_none], obj.get("extra_fields"))
        extra_settings = from_union([from_str, from_none], obj.get("extra_settings"))
        include_counts = from_union([from_str, from_none], obj.get("include_counts"))
        include_fields_torrent = from_union([from_str, from_none], obj.get("include_fields[torrent]"))
        includes = from_union([from_str, from_none], obj.get("includes"))
        return Query(extra_fields, extra_settings, include_counts, include_fields_torrent, includes)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.extra_fields is not None:
            result["extra_fields"] = from_union([from_str, from_none], self.extra_fields)
        if self.extra_settings is not None:
            result["extra_settings"] = from_union([from_str, from_none], self.extra_settings)
        if self.include_counts is not None:
            result["include_counts"] = from_union([from_str, from_none], self.include_counts)
        if self.include_fields_torrent is not None:
            result["include_fields[torrent]"] = from_union([from_str, from_none], self.include_fields_torrent)
        if self.includes is not None:
            result["includes"] = from_union([from_str, from_none], self.includes)
        return result


def query_from_dict(s: Any) -> Query:
    return Query.from_dict(s)


def query_to_dict(x: Query) -> Any:
    return to_class(Query, x)
