import unittest
from unittest.mock import Mock, patch
from api_client import NexusAPIClient, APIError


class TestAPIClient(unittest.TestCase):
    """测试 API 客户端"""
    
    def setUp(self):
        """设置测试环境"""
        self.client = NexusAPIClient(base_url="https://test.nexusphp.org", token="test-token")
    
    def test_initialization(self):
        """测试初始化"""
        self.assertEqual(self.client.base_url, "https://test.nexusphp.org")
        self.assertEqual(self.client.token, "test-token")
        # 测试各个子客户端是否初始化
        self.assertIsNotNone(self.client.profile)
        self.assertIsNotNone(self.client.bookmark)
        self.assertIsNotNone(self.client.comment)
        self.assertIsNotNone(self.client.section)
        self.assertIsNotNone(self.client.torrent)
    
    def test_set_token(self):
        """测试设置 token"""
        new_token = "new-token"
        self.client.set_token(new_token)
        self.assertEqual(self.client.token, new_token)
    
    def test_set_base_url(self):
        """测试设置 base_url"""
        new_url = "https://new.nexusphp.org"
        self.client.set_base_url(new_url)
        self.assertEqual(self.client.base_url, new_url)
    
    @patch('api_client.client.requests.Session.request')
    def test_api_error(self, mock_request):
        """测试 API 错误处理"""
        # 模拟网络错误
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        mock_request.return_value = mock_response
        
        with self.assertRaises(APIError):
            self.client.profile.get_profile()
    
    @patch('api_client.client.requests.Session.request')
    def test_success_response(self, mock_request):
        """测试成功响应"""
        # 模拟成功响应
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "ret": 0,
            "msg": "success",
            "data": {
                "data": {
                    "id": 1,
                    "username": "testuser",
                    "email": "test@example.com",
                    "status": "confirmed",
                    "enabled": "yes",
                    "added": "2024-01-01 00:00:00",
                    "added_human": "2024-01-01",
                    "last_access": "2024-01-01 00:00:00",
                    "last_access_human": "2024-01-01",
                    "last_login": "2024-01-01 00:00:00",
                    "last_login_human": "2024-01-01",
                    "class": 1,
                    "class_text": "Member",
                    "avatar": "",
                    "invites": 0,
                    "attendance_card": 0,
                    "uploaded": 0,
                    "uploaded_text": "0 B",
                    "downloaded": 0,
                    "downloaded_text": "0 B",
                    "bonus": 0,
                    "bonus_human": "0",
                    "seed_points": 0,
                    "seed_points_human": "0",
                    "seedtime": 0,
                    "seedtime_text": "0",
                    "leechtime": 0,
                    "leechtime_text": "0",
                    "share_ratio": "0",
                    "seed_points_per_hour": 0,
                    "seed_points_per_hour_human": "0",
                    "seed_bonus_per_hour": 0,
                    "seed_bonus_per_hour_human": "0"
                }
            },
            "rid": "test-rid",
            "time": 0.1
        }
        mock_request.return_value = mock_response
        
        # 测试获取用户资料
        profile = self.client.profile.get_profile()
        self.assertEqual(profile.ret, 0)
        self.assertEqual(profile.msg, "success")
        self.assertEqual(profile.data.data.username, "testuser")


if __name__ == '__main__':
    unittest.main()
