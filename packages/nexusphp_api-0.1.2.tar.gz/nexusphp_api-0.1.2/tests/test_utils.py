import unittest
from utils import (
    from_str, from_int, from_float, from_bool, from_none,
    from_union, from_list, from_dict, to_float, to_class
)


class TestUtils(unittest.TestCase):
    """测试工具函数"""
    
    def test_from_str(self):
        """测试字符串转换"""
        self.assertEqual(from_str("test"), "test")
        with self.assertRaises(AssertionError):
            from_str(123)
    
    def test_from_int(self):
        """测试整数转换"""
        self.assertEqual(from_int(123), 123)
        with self.assertRaises(AssertionError):
            from_int("123")
        with self.assertRaises(AssertionError):
            from_int(True)
    
    def test_from_float(self):
        """测试浮点数转换"""
        self.assertEqual(from_float(123.45), 123.45)
        self.assertEqual(from_float(123), 123.0)
        with self.assertRaises(AssertionError):
            from_float("123.45")
        with self.assertRaises(AssertionError):
            from_float(True)
    
    def test_from_bool(self):
        """测试布尔值转换"""
        self.assertEqual(from_bool(True), True)
        self.assertEqual(from_bool(False), False)
        with self.assertRaises(AssertionError):
            from_bool(1)
        with self.assertRaises(AssertionError):
            from_bool("true")
    
    def test_from_none(self):
        """测试 None 转换"""
        self.assertIsNone(from_none(None))
        with self.assertRaises(AssertionError):
            from_none("")
    
    def test_from_union(self):
        """测试联合类型转换"""
        self.assertEqual(from_union([from_int, from_str], 123), 123)
        self.assertEqual(from_union([from_int, from_str], "123"), "123")
        with self.assertRaises(AssertionError):
            from_union([from_int, from_str], 123.45)
    
    def test_from_list(self):
        """测试列表转换"""
        self.assertEqual(from_list(from_int, [1, 2, 3]), [1, 2, 3])
        with self.assertRaises(AssertionError):
            from_list(from_int, "[1, 2, 3]")
    
    def test_from_dict(self):
        """测试字典转换"""
        self.assertEqual(from_dict(from_int, {"a": 1, "b": 2}), {"a": 1, "b": 2})
        with self.assertRaises(AssertionError):
            from_dict(from_int, "{\"a\": 1}")
    
    def test_to_float(self):
        """测试浮点数输出转换"""
        self.assertEqual(to_float(123.45), 123.45)
        with self.assertRaises(AssertionError):
            to_float(123)
    
    def test_to_class(self):
        """测试类实例转换"""
        class TestClass:
            def __init__(self, value):
                self.value = value
            def to_dict(self):
                return {"value": self.value}
        
        obj = TestClass(123)
        self.assertEqual(to_class(TestClass, obj), {"value": 123})
        with self.assertRaises(AssertionError):
            to_class(TestClass, 123)


if __name__ == "__main__":
    unittest.main()