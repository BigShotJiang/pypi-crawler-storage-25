import unittest
import os
from config import config, get_config


class TestConfig(unittest.TestCase):
    """测试配置管理"""
    
    def setUp(self):
        """设置测试环境"""
        # 保存原始环境变量
        self.original_env = os.environ.copy()
    
    def tearDown(self):
        """恢复原始环境变量"""
        os.environ.clear()
        os.environ.update(self.original_env)
    
    def test_default_config(self):
        """测试默认配置"""
        # 清除环境变量
        for key in list(os.environ.keys()):
            if key.startswith("API_") or key in ["LOG_LEVEL", "LOG_FILE", "MAX_RETRIES", "RETRY_INTERVAL"]:
                del os.environ[key]
        
        # 重新初始化配置
        from config import config as new_config
        
        # 测试默认值
        self.assertEqual(new_config.api_base_url, "https://api.nexusphp.org")
        self.assertEqual(new_config.api_timeout, 30)
        self.assertEqual(new_config.token, "")
        self.assertEqual(new_config.log_level, "INFO")
        self.assertEqual(new_config.log_file, "api.log")
        self.assertEqual(new_config.max_retries, 3)
        self.assertEqual(new_config.retry_interval, 1.0)
    
    def test_env_config(self):
        """测试从环境变量读取配置"""
        # 直接创建新的 Config 实例来测试
        import config
        
        # 设置环境变量
        os.environ["API_BASE_URL"] = "https://test.api.org"
        os.environ["API_TIMEOUT"] = "60"
        os.environ["API_TOKEN"] = "test-token"
        os.environ["LOG_LEVEL"] = "DEBUG"
        os.environ["LOG_FILE"] = "test.log"
        os.environ["MAX_RETRIES"] = "5"
        os.environ["RETRY_INTERVAL"] = "2.5"
        
        # 创建新的配置实例
        new_config = config.Config()
        
        # 测试从环境变量读取的值
        self.assertEqual(new_config.api_base_url, "https://test.api.org")
        self.assertEqual(new_config.api_timeout, 60)
        self.assertEqual(new_config.token, "test-token")
        self.assertEqual(new_config.log_level, "DEBUG")
        self.assertEqual(new_config.log_file, "test.log")
        self.assertEqual(new_config.max_retries, 5)
        self.assertEqual(new_config.retry_interval, 2.5)
    
    def test_headers(self):
        """测试请求头生成"""
        # 测试无 token 的情况
        config.token = ""
        headers = config.headers
        self.assertEqual(headers["Accept"], "application/json")
        self.assertEqual(headers["Content-Type"], "application/json")
        self.assertNotIn("Authorization", headers)
        
        # 测试有 token 的情况
        config.token = "test-token"
        headers = config.headers
        self.assertEqual(headers["Authorization"], "Bearer test-token")
    
    def test_get_set(self):
        """测试 get 和 set 方法"""
        # 测试 get 方法
        self.assertEqual(config.get("api_base_url"), "https://api.nexusphp.org")
        self.assertEqual(config.get("non_existent", "default"), "default")
        
        # 测试 set 方法
        config.set("api_base_url", "https://new.api.org")
        self.assertEqual(config.api_base_url, "https://new.api.org")
        
    def test_get_config(self):
        """测试 get_config 函数"""
        config_instance = get_config()
        self.assertIsInstance(config_instance, type(config))


if __name__ == "__main__":
    unittest.main()