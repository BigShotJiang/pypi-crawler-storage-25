# palinex × nexus × Claude Code — sequence diagram

End-to-end sequence for the static-snapshot path: user types a prompt → Claude decides to render a surface → **palinex MCP server** produces an MCP UI resource → Claude Code renders it as a sandboxed iframe → user sees the surface inline.

Documents process boundaries (the load-bearing detail) so each hop is explicit. Implements palinex RDR-003 (packaging: plugin + nexus-front-end role). Note: nexus RDR-127 v2 records the corresponding non-decision on the nexus side — nexus ships no surface-rendering code; palinex depends on nexus (via the `[nexus]` extra), not vice versa.

## Scope: which product this describes

This diagram is **specifically for Claude Code — the developer product — running as the desktop Electron app**. Other host configurations differ:

| Product | MCP UI resource handling | What changes vs this diagram |
|---|---|---|
| **Claude Code — desktop (Electron)** | First-class; renders inline as an iframe | This diagram applies directly. |
| **Claude Code — CLI (terminal)** | Terminal can't render HTML. Behavior is host-implementation-specific: likely either dropped, written to a temp file, or handed off to the system browser (`open <file>`). | Drop processes A' (Chromium renderer) and A'' (outer iframe inside A'). If the temp-file path is taken AND the user opens it, the iframe chain re-appears inside the system browser (Safari/Chrome) — but rooted in that separate app, not in the CLI process. |
| **Claude Chat — desktop or web** | MCP UI resources are not part of the consumer feature set (as of this writing). MCP is a developer-product capability. | Not applicable. |

If you're reading this in a CLI session, the multi-process Electron path described below is *not* what's happening in your terminal — verify the actual handling by calling `render_surface` and observing.

## Diagram

```mermaid
sequenceDiagram
    autonumber

    actor User

    box rgba(200,220,255,0.15) Process A — Claude Code (Electron)
        participant Main as Node main<br/>process
        participant ChatUI as Chromium renderer<br/>(chat UI)
        participant OuterFrame as Outer iframe<br/>(UI resource)
    end

    box rgba(220,200,255,0.15) Process A''' — Chromium site-isolation
        participant InnerFrame as Inner iframe<br/>(palinex renderer<br/>from github.io)
    end

    box rgba(255,220,200,0.15) Process B — palinex MCP server (Python subprocess)
        participant PalinexMCP as FastMCP("palinex")<br/>render_surface tool
        participant Bridge as palinex.nexus_bridge<br/>(lazy import shim)
        participant Palinex as palinex<br/>(wrap_as_mcp_ui_resource)
    end

    box rgba(220,255,220,0.15) Process C / network
        participant T3 as T3 ChromaDB<br/>(local or cloud)
        participant CDN as jsDelivr + GitHub Pages
    end

    %% — prompt → tool call —
    User->>ChatUI: 1. types prompt<br/>"show me chunks X, Y as a surface"
    ChatUI->>Main: 2. Electron IPC (prompt event)
    Main->>Main: 3. Claude (agent) chooses<br/>render_surface(payload)
    Note over Main,PalinexMCP: process boundary: stdio JSON-RPC<br/>(Claude Code → MCP subprocess)
    Main->>PalinexMCP: 4. tools/call render_surface(payload, collection)

    %% — chash resolution loop (inside Process B) —
    PalinexMCP->>Palinex: 5. wrap_as_mcp_ui_resource(<br/>payload, chash_resolver=Bridge.chash_resolver)
    loop for each string in data model
        Palinex->>Bridge: 6. chash_resolver(candidate)<br/>(callable, in-process)
        alt 32-char lowercase hex
            Bridge->>T3: 7. t3.get_by_id(collection, chash)
            T3-->>Bridge: 8. chunk content or None
        else not chash-shaped
            Bridge-->>Palinex: (skip — returns None)
        end
        Bridge-->>Palinex: 9. resolved text or None
    end
    Palinex->>Palinex: 10. substitute resolved text<br/>+ rewrite Button.openChash<br/>→ Button.copyToClipboard
    Palinex-->>PalinexMCP: 11. HTML wrapper string

    %% — return path —
    PalinexMCP-->>Main: 12. tools/call response<br/>{type:"resource", resource:<br/>{uri, mimeType:"text/html", text}}
    Note over Main,ChatUI: process boundary: Electron IPC<br/>(Node main → Chromium renderer)
    Main->>ChatUI: 13. render UI resource inline
    ChatUI->>OuterFrame: 14. create iframe with wrapper HTML

    %% — outer iframe loads —
    OuterFrame->>CDN: 15. GET hellblazer.github.io/palinex/index.html
    CDN-->>OuterFrame: 16. index.html

    Note over OuterFrame,InnerFrame: process boundary: Chromium site-isolation<br/>(cross-origin iframe → separate renderer process)
    OuterFrame->>InnerFrame: 17. instantiate cross-origin child frame

    %% — inner iframe (palinex renderer) loads —
    InnerFrame->>CDN: 18. GET cdn.jsdelivr.net/.../lit-html@3.2.1
    CDN-->>InnerFrame: 19. lit-html ESM module
    InnerFrame->>InnerFrame: 20. attach postMessage listener

    %% — payload delivery —
    OuterFrame->>InnerFrame: 21. postMessage({type:"a2ui.load", payload})
    InnerFrame->>InnerFrame: 22. render surface<br/>(lit-html → DOM)
    InnerFrame-->>User: 23. citations visible inline<br/>(resolved chunk text already in DOM)

    %% — interaction (static-snapshot path) —
    User->>InnerFrame: 24. clicks "Open chunk"
    InnerFrame->>InnerFrame: 25. copyToClipboard(text)<br/>(pure browser API)
    Note right of InnerFrame: text on clipboard;<br/>NO additional boundary crossings.<br/>nexus is never re-contacted.
```

## Process / boundary key

| Layer | Boundary kind | Transport | Notes |
|---|---|---|---|
| **A** Node main process | OS process | — | Claude Code Electron main; owns the MCP client and spawns MCP server subprocesses |
| **A'** Chromium renderer process | OS process (Electron IPC to A) | Electron contextBridge / IPC channels | Hosts the chat UI; renders messages including MCP UI resources |
| **A''** Outer iframe | Browsing context inside A' (may stay same OS process or go cross-process under site-isolation) | DOM + postMessage to parent | Loaded with the wrapper HTML returned by `render_surface` |
| **A'''** Inner iframe | Browsing context, cross-origin to A' (almost certainly a separate OS process under Chromium site-isolation, since it loads from `hellblazer.github.io` ≠ Claude Code's origin) | postMessage to A''; cannot read A'' DOM | The actual palinex renderer (`index.html` + lit-html) |
| **B** palinex MCP server | OS process (Python subprocess of A) | stdio JSON-RPC | Spawned by A at session start via the `palinex-mcp` console script declared in the Claude Code plugin's `.mcp.json`. Imports `palinex.nexus_bridge` lazily on first chash; that module imports nexus internals via `nexus.mcp_infra.get_t3` + `nexus.corpus.t3_collection_name`. |
| **C** T3 ChromaDB | In-process with B (local mode) OR separate machine (cloud mode) | direct calls / HTTPS | Configurable; nexus picks based on env. Process B's address space holds the nexus client objects — no separate nexus process exists in this picture. |
| **CDN** | Network | HTTPS | jsDelivr for lit-html ESM, GitHub Pages for `index.html` |

## What crosses each boundary in this sequence

| Step | Boundary | Payload |
|---|---|---|
| 4 | A → B (stdio) | `tools/call render_surface` request with full payload JSON |
| 7 | B → T3 | doc_id lookup query (one per candidate string in data model) |
| 8 | T3 → B | chunk content (≤ ~4 KB) or None |
| 12 | B → A (stdio) | tools/call response containing the HTML wrapper |
| 13 | A → A' (Electron IPC) | UI resource for inline rendering |
| 15, 18 | A''' → CDN | HTTPS GET for index.html and lit-html (cacheable; one-time per session) |
| 17 | A'' → A''' (site-isolation) | iframe instantiation |
| 21 | A'' → A''' (postMessage) | payload JSON (the surface data) |
| 25 | A''' → OS clipboard | resolved chunk text |

## What does NOT cross any boundary

- The chash resolver callable is injected into palinex **inside process B**. The callable itself never crosses A↔B; only the resolved strings do. (Steps 5–11 all happen inside B.)
- Once the inner iframe receives its payload (step 22), it has everything it needs. No further round-trips to nexus, no further T3 lookups, no further Claude turns. That's the **static-snapshot** guarantee — and the reason this is much cheaper than interactive flows.

## What interactive flows would add

If we later ship the bidirectional protocol (the shape `host-bridge.html` demonstrates), each user click would round-trip:

```
A''' (click)
  → postMessage to A'' (cross-process)
  → Electron IPC A' → A
  → stdio A → B (tool call)
  → in-process call B → T3
  → return path: 5 hops back
```

**Six process boundaries per click** vs zero in the static-snapshot path. That's the architectural cost of "live" UIs and why static comes first.

## Where each repo's code participates

| Repo | What runs where |
|---|---|
| `palinex` (this repo) | Steps 4, 11, 12 (the MCP tool registration + return path) run in B as part of the `palinex-mcp` console script. Steps 5, 10 (the `wrap_as_mcp_ui_resource` helper) run in B as in-process library calls. Steps 6, 9 (the `nexus_bridge` chash resolver — including the lazy nexus imports) run in B. Steps 20, 22, 25 (the renderer) run in A''' as the loaded HTML. |
| `nexus` (depended on via `palinex[nexus]` extra) | Steps 7, 8 (T3 lookup). Imported by palinex.nexus_bridge inside Process B; nexus contributes the T3 client objects but does not run as a separate process. |
| `Claude Code` (upstream Anthropic) | Steps 2, 3, 13, 14, 23 (the host) — agent decision, MCP client, UI resource rendering. Also spawns Process B at session boot via the plugin's `.mcp.json`. |
| Upstream open source | a2ui v0.9 spec (Google) shapes the payload format. lit-html (Google) is the renderer's only runtime dep. FastMCP is the MCP server framework B uses. |

## See also

- `docs/rdr/rdr-001-architecture.md` — palinex architecture decisions (a2ui v0.9 IR, three delivery shapes, postMessage RPC, markdown sidecar)
- `docs/rdr/rdr-002-pyodide-as-runtime-augmentation.md` — Pyodide-as-default policy
- `docs/rdr/rdr-003-plugin-and-source-layout.md` — packaging: Claude Code plugin + nexus-front-end role + `src/` layout
- nexus `docs/rdr/rdr-127-substrate-decoupled-surface-rendering.md` — the corresponding non-decision on the nexus side (nexus ships no surface-rendering code; palinex is downstream)
- `web/host-bridge.html` — reference implementation of the bidirectional postMessage protocol for the future interactive-flows path
- `plugin/` — the Claude Code plugin scaffolding that ships this integration
