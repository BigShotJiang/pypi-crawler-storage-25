#!/usr/bin/env python3
"""BuildAI CLI entry point."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from importlib.metadata import version as pkg_version
from pathlib import Path

import typer
from dotenv import load_dotenv

from cli._has_core import has_core
from cli.commands.api_proxy import api
from cli.commands.assets_cli import app as assets_app
from cli.commands.auth_lite import login, logout, whoami
from cli.commands.clips import app as clips_app
from cli.commands.inference import app as inference_app
from cli.commands.jobs import app as jobs_app
from cli.commands.query_api import query
from cli.commands.reports import app as reports_app
from cli.commands.search import app as search_app
from cli.console import error, info, set_verbose, success, warning

load_dotenv()

_AUTO_UPGRADE_SENTINEL = "BUILDAI_SKIP_AUTO_UPGRADE"


def _current_version() -> str:
    try:
        return pkg_version("buildai-cli")
    except Exception:
        return "0.0.0"


def _latest_pypi_version() -> str | None:
    """Check PyPI for the latest buildai-cli version (non-blocking, 3s timeout)."""
    import json
    from urllib.request import urlopen

    try:
        with urlopen("https://pypi.org/pypi/buildai-cli/json", timeout=3) as resp:
            data = json.loads(resp.read())
            return data.get("info", {}).get("version")
    except Exception:
        return None


def _is_workspace_install() -> bool:
    path = Path(__file__).resolve()
    if "apps/buildai-cli" not in path.as_posix():
        return False
    return any((parent / ".git").exists() for parent in path.parents)


def _buildai_binary_path() -> str:
    return shutil.which("buildai") or ""


def _is_homebrew_install() -> bool:
    path = _buildai_binary_path()
    return "/homebrew/" in path or "/Cellar/" in path


def _is_uv_tool_install() -> bool:
    """True when the resolved ``buildai`` on PATH is managed by ``uv tool install``.

    Auto-upgrade only applies to that channel. Other installers (npm shims, pip,
    etc.) leave a different ``buildai`` first on PATH; running ``uv tool upgrade``
    updates uv's copy while ``which("buildai")`` still points at the old entry,
    which makes every run look out-of-date and loops on "Updating… Restarting…".
    """
    path = _buildai_binary_path()
    if not path:
        return False
    try:
        resolved = Path(path).resolve()
    except OSError:
        return False
    p = resolved.as_posix()
    if "/uv/tools/" in p or "\\uv\\tools\\" in str(resolved):
        return True
    tool_dir = os.environ.get("UV_TOOL_DIR")
    if tool_dir:
        try:
            resolved.relative_to(Path(tool_dir).resolve())
            return True
        except ValueError:
            pass
    return False


def _upgrade_command() -> list[str] | None:
    if shutil.which("uv"):
        return ["uv", "tool", "upgrade", "buildai-cli"]
    return None


def _reexec_current_process() -> None:
    buildai_path = _buildai_binary_path()
    if buildai_path:
        os.execv(buildai_path, [buildai_path, *sys.argv[1:]])
    raise typer.Exit(code=0)


def _version_tuple(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0, 0, 0)


def _check_update() -> None:
    """Print a warning if a newer version is available on PyPI."""
    current = _current_version()
    latest = _latest_pypi_version()
    if not latest:
        return
    if _version_tuple(latest) > _version_tuple(current):
        warning(f"Update available: {current} → {latest}")
        info("  Run: uv tool upgrade buildai-cli")


def _enforce_fresh_cli() -> None:
    if os.environ.get(_AUTO_UPGRADE_SENTINEL) == "1":
        return
    if _is_workspace_install():
        return
    if not _is_uv_tool_install():
        return
    latest = _latest_pypi_version()
    current = _current_version()
    if not latest or _version_tuple(latest) <= _version_tuple(current):
        return

    if _is_homebrew_install():
        error(
            "This buildai install came from Homebrew, which is no longer a supported "
            "distribution channel for automatic updates."
        )
        info("Run: brew uninstall buildai-cli")
        info("Then: uv tool install --force buildai-cli")
        raise typer.Exit(code=1)

    command = _upgrade_command()
    if command is None:
        error(
            "A newer buildai-cli is required, but uv is not installed. "
            "Install uv and run: uv tool install --force buildai-cli"
        )
        raise typer.Exit(code=1)

    info(f"Updating buildai-cli {current} → {latest} before running...")
    env = os.environ.copy()
    env[_AUTO_UPGRADE_SENTINEL] = "1"
    result = subprocess.run(command, capture_output=True, text=True, env=env)
    if result.returncode != 0:
        error("Automatic CLI upgrade failed.")
        stderr = result.stderr.strip()
        if stderr:
            error(stderr)
        raise typer.Exit(code=1)
    success(f"Updated buildai-cli to {latest}. Restarting command...")
    _reexec_current_process()


def _do_upgrade() -> None:
    """Force upgrade the CLI to the latest version."""
    current = _current_version()
    if _is_homebrew_install():
        error("Homebrew-installed buildai is deprecated and cannot self-upgrade cleanly.")
        info("Run: brew uninstall buildai-cli")
        info("Then: uv tool install --force buildai-cli")
        raise typer.Exit(code=1)

    command = _upgrade_command()
    if command is None:
        error("uv is required to upgrade buildai-cli. Install uv and run:")
        info("  uv tool install --force buildai-cli")
        raise typer.Exit(code=1)

    info(f"Current: {current}. Upgrading via uv...")
    env = os.environ.copy()
    env[_AUTO_UPGRADE_SENTINEL] = "1"
    result = subprocess.run(command, capture_output=True, text=True, env=env)
    if result.returncode == 0:
        success("Upgraded. Run your command again.")
    else:
        error(f"Upgrade failed: {result.stderr.strip()}")


def _version_callback(value: bool) -> None:
    if value:
        _enforce_fresh_cli()
        v = _current_version()
        print(f"buildai-cli {v}")
        _check_update()
        raise typer.Exit()


_HELP = """\
Build AI CLI — query data, run inference, sign media URLs.

Get started:
  uv tool install buildai-cli          Install the standalone CLI
  buildai login                         Authenticate (opens browser)
  buildai whoami                        Show your identity and permissions
  buildai query "SELECT count(*) FROM core.clips"

Output: table (terminal) or JSON (pipe). Override with -o json/jsonl/csv.
Upgrade: buildai upgrade
"""

app = typer.Typer(
    name="buildai",
    help=_HELP,
    no_args_is_help=True,
    rich_markup_mode="rich",
)


@app.callback()
def main_callback(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
    version: bool | None = typer.Option(
        None,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    del version
    _enforce_fresh_cli()
    set_verbose(verbose)


@app.command("upgrade")
def upgrade() -> None:
    """Upgrade buildai-cli to the latest version."""
    _do_upgrade()


app.command("api")(api)
app.command("login")(login)
app.command("whoami")(whoami)
app.command("logout")(logout)
app.command("query")(query)

app.add_typer(clips_app, name="clips")
app.add_typer(assets_app, name="assets")
app.add_typer(inference_app, name="inference")
app.add_typer(jobs_app, name="jobs")
app.add_typer(search_app, name="search", help="Semantic search across clips and frames.")
app.add_typer(reports_app, name="reports")

admin_app = typer.Typer(
    name="admin",
    help="DB-direct ops commands (requires workspace install + gcloud IAM).",
    no_args_is_help=True,
)


@admin_app.callback()
def admin_callback(
    ctx: typer.Context,
    env: str | None = typer.Option(
        None,
        "--env",
        "-e",
        help="Target environment. Defaults to APP_ENV, then production.",
    ),
    auth: str = typer.Option(None, "--auth", "-a", help="Auth method: iam or password."),
    user: str = typer.Option(None, "--user", "-u", help="Override database user."),
    profile: str | None = typer.Option(None, "--profile", "-p", help="CLI scope profile."),
    write: bool = typer.Option(False, "--write", help="Allow write operations."),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose logging."),
) -> None:
    """Set up ops-plane context for admin commands."""
    ctx.ensure_object(dict)
    ctx.obj["cli_profile"] = profile
    ctx.obj["allow_write"] = write
    ctx.obj["_env"] = env
    ctx.obj["_auth"] = auth
    ctx.obj["_user"] = user
    ctx.obj["_verbose"] = verbose
    ctx.obj["_ops_ready"] = False

    from cli.ops_init import init_ops_context

    init_ops_context(ctx)


if has_core():
    from cli.commands.database import app as database_app
    from cli.commands.embed import app as embed_app
    from cli.commands.external import app as external_app
    from cli.commands.keys import app as keys_app
    from cli.commands.medoid import app as medoid_app
    from cli.commands.operations import app as operations_app
    from cli.commands.partners import app as partners_app
    from cli.commands.projection import app as projection_app
    from cli.commands.query import query as admin_query
    from cli.commands.schema import app as schema_app
    from cli.commands.stats import app as stats_app

    admin_app.command("query")(admin_query)
    admin_app.add_typer(operations_app, name="operations")
    admin_app.add_typer(partners_app, name="partners")
    admin_app.add_typer(keys_app, name="keys")
    admin_app.add_typer(stats_app, name="stats")
    admin_app.add_typer(schema_app, name="schema")
    admin_app.add_typer(embed_app, name="embeddings")
    admin_app.add_typer(database_app, name="database")
    admin_app.add_typer(external_app, name="external")
    admin_app.add_typer(projection_app, name="projection")
    admin_app.add_typer(medoid_app, name="medoid")

app.add_typer(admin_app, name="admin")


def main() -> None:
    app()
