"""CLI commands for clips (SDK-backed)."""

from __future__ import annotations

import itertools

import typer

from cli.output import Format, format_option, output
from cli.pagination import auto_paginate
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="clips",
    help="Browse and search clips.",
    no_args_is_help=True,
)


@app.command("list")
def clips_list(
    factory: str | None = typer.Option(None, "--factory", "-f", help="Filter by factory ID"),
    worker: str | None = typer.Option(None, "--worker", "-w", help="Filter by worker ID"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max results"),
    format: Format | None = format_option(),
) -> None:
    """List clips with optional factory/worker filter."""
    client = get_sdk_client()
    results = list(
        itertools.islice(
            auto_paginate(client.clips.list, factory_id=factory, worker_id=worker),
            limit,
        )
    )
    output(
        results,
        format=format,
        columns=["id", "factory_id", "worker_id", "duration_sec", "recorded_at"],
    )


@app.command("get")
def clips_get(
    clip_id: str = typer.Argument(..., help="Clip UUID"),
    format: Format | None = format_option(),
) -> None:
    """Get details for a single clip."""
    client = get_sdk_client()
    clip = client.clips.get(clip_id)
    output(clip, format=format)


@app.command("search")
def clips_search(
    query: str = typer.Argument(..., help="Search query text"),
    factory: str | None = typer.Option(None, "--factory", "-f"),
    limit: int = typer.Option(10, "--limit", "-n"),
    format: Format | None = format_option(),
) -> None:
    """Search clips by text query."""
    client = get_sdk_client()
    results = client.search.query(
        query_text=query,
        factory_ids=[factory] if factory else None,
        page_size=limit,
    )
    output(results.data, format=format, columns=["clip_id", "score", "factory_id", "recorded_at"])


@app.command("frames")
def clips_frames(
    clip_id: str = typer.Argument(..., help="Clip UUID"),
    limit: int = typer.Option(10, "--limit", "-n"),
    format: Format | None = format_option(),
) -> None:
    """List frames for a clip."""
    client = get_sdk_client()
    frames = list(itertools.islice(auto_paginate(client.frames.list, clip_id=clip_id), limit))
    output(frames, format=format)
