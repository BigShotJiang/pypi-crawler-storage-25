"""Multimodal inference commands."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import typer

from cli.console import info, success
from cli.output import OutputFormat, auto_format, render
from cli.pagination import auto_paginate
from cli.sdk_client import get_internal_sdk_client

app = typer.Typer(
    name="inference",
    help=(
        "Multimodal batch inference over SQL-defined bundles. "
        "Use this to validate selectors, queue runs, watch progress, and fetch full results "
        "for videos, frames, audio, IMU, text, or mixed media prompts. "
        "Contracts can use model_backend=auto to route image-only bundles through AI Studio "
        "and mixed bundles through Vertex."
    ),
    no_args_is_help=True,
)


def _load_json(path: str) -> dict[str, Any]:
    return json.loads(Path(path).read_text())


@app.command("contracts-list")
def contracts_list(
    output: OutputFormat | None = typer.Option(None, "-o", "--output", help="Render format."),
) -> None:
    """List available inference contracts."""
    client = get_internal_sdk_client()
    try:
        result = client.inference.contracts()
    finally:
        client.close()
    render(
        result.data,
        format=output or auto_format(),
        columns=["id", "display_name", "model_backend", "model", "response_mime_type"],
    )


@app.command("contracts-create")
def contracts_create(
    contract_file: str = typer.Option(
        ...,
        "--contract-file",
        help=(
            "Path to contract JSON with prompt, model, and response schema. "
            "Use model_backend=auto for fast frame-only routing via AI Studio."
        ),
    ),
    output: OutputFormat | None = typer.Option(None, "-o", "--output", help="Render format."),
) -> None:
    """Create an immutable inference contract from JSON."""
    payload = _load_json(contract_file)
    client = get_internal_sdk_client()
    try:
        contract = client.inference.create_contract(payload)
    finally:
        client.close()
    render(contract, format=output or auto_format())


@app.command("validate")
def validate(
    contract_file: str | None = typer.Option(
        None,
        "--contract-file",
        help="Inline contract JSON. Use this when creating a new contract definition.",
    ),
    contract_id: str | None = typer.Option(
        None,
        "--contract-id",
        help="Existing contract id. Use this when reusing a stored contract.",
    ),
    selector_file: str = typer.Option(
        ...,
        "--selector-file",
        help=(
            "Path to selector JSON. The SQL must return item_id, factory_id, worker_id, "
            "clip_ids, frame_ids, input_bundle, metadata, and selection_rank."
        ),
    ),
    requests_per_minute: int = typer.Option(
        ...,
        "--requests-per-minute",
        help="Global request budget for the run.",
    ),
    max_parallel_requests_per_worker: int = typer.Option(
        8,
        "--max-parallel-requests-per-worker",
        help="Max concurrent Gemini requests per worker process.",
    ),
    max_attempts_per_item: int = typer.Option(
        8,
        "--max-attempts-per-item",
        help="Retry limit per staged bundle.",
    ),
    output: OutputFormat | None = typer.Option(None, "-o", "--output", help="Render format."),
) -> None:
    """Validate selector shape, staged items, and bundle guardrails without launching."""
    payload: dict[str, Any] = {
        "selector": _load_json(selector_file),
        "requests_per_minute": requests_per_minute,
        "max_parallel_requests_per_worker": max_parallel_requests_per_worker,
        "max_attempts_per_item": max_attempts_per_item,
    }
    if contract_file:
        payload["contract"] = _load_json(contract_file)
    if contract_id:
        payload["contract_id"] = contract_id

    client = get_internal_sdk_client()
    try:
        result = client.inference.validate_run(payload)
    finally:
        client.close()
    render(result, format=output or auto_format())


@app.command("run")
def run(
    contract_file: str | None = typer.Option(
        None,
        "--contract-file",
        help="Inline contract JSON. Useful for one-off smoke tests or new contracts.",
    ),
    contract_id: str | None = typer.Option(
        None,
        "--contract-id",
        help="Existing immutable contract id.",
    ),
    selector_file: str = typer.Option(
        ...,
        "--selector-file",
        help="Path to selector JSON describing the staged multimodal bundles.",
    ),
    requests_per_minute: int = typer.Option(
        ...,
        "--requests-per-minute",
        help="Global request budget for the run.",
    ),
    max_parallel_requests_per_worker: int = typer.Option(
        8,
        "--max-parallel-requests-per-worker",
        help="Max concurrent Gemini requests per worker.",
    ),
    max_attempts_per_item: int = typer.Option(
        8,
        "--max-attempts-per-item",
        help="Retry limit per bundle before persisting failure.",
    ),
    launch: bool = typer.Option(
        True,
        "--launch/--no-launch",
        help="Launch immediately after queueing. Use --no-launch to queue first and submit later.",
    ),
    max_tasks: int = typer.Option(
        20,
        "--max-tasks",
        help="Max Cloud Run or Batch tasks when launching.",
    ),
    platform: str = typer.Option(
        "cloudrun",
        "--platform",
        help="Execution platform: cloudrun, batch, or auto.",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        help="Execution region override.",
    ),
    cpu: str | None = typer.Option(
        None,
        "--cpu",
        help="Optional worker CPU override.",
    ),
    memory: str | None = typer.Option(
        None,
        "--memory",
        help="Optional worker memory override.",
    ),
    watch: bool = typer.Option(
        True,
        "--watch",
        help="Poll progress until the run reaches a terminal state.",
    ),
    output: OutputFormat | None = typer.Option(None, "-o", "--output", help="Render format."),
) -> None:
    """Queue a multimodal inference run and optionally launch and watch it."""
    payload: dict[str, Any] = {
        "selector": _load_json(selector_file),
        "requests_per_minute": requests_per_minute,
        "max_parallel_requests_per_worker": max_parallel_requests_per_worker,
        "max_attempts_per_item": max_attempts_per_item,
    }
    if contract_file:
        payload["contract"] = _load_json(contract_file)
    if contract_id:
        payload["contract_id"] = contract_id

    client = get_internal_sdk_client()
    try:
        run_obj = client.inference.create_run(payload)
        success(f"Queued inference run {run_obj.id} manifest={run_obj.manifest_id}")
        if launch:
            submit_payload = {
                "max_tasks": max_tasks,
                "platform": platform,
                "region": region,
                "cpu": cpu,
                "memory": memory,
            }
            submit_obj = client.inference.submit_run(run_obj.id, submit_payload)
            success(
                f"Submitted {run_obj.manifest_id} on {submit_obj.platform} as {submit_obj.batch_job_name}"
            )
        if watch and launch:
            _watch_run(client, run_obj.id)
        else:
            render(run_obj, format=output or auto_format())
    finally:
        client.close()


@app.command("submit")
def submit_run(
    run_id: str = typer.Argument(...),
    max_tasks: int = typer.Option(20, "--max-tasks", help="Max worker tasks to launch."),
    platform: str = typer.Option(
        "cloudrun",
        "--platform",
        help="Execution platform: cloudrun, batch, or auto.",
    ),
    region: str | None = typer.Option(None, "--region", help="Execution region override."),
    cpu: str | None = typer.Option(None, "--cpu", help="Optional worker CPU override."),
    memory: str | None = typer.Option(
        None,
        "--memory",
        help="Optional worker memory override.",
    ),
    output: OutputFormat | None = typer.Option(None, "-o", "--output", help="Render format."),
) -> None:
    """Launch a previously queued inference run."""
    client = get_internal_sdk_client()
    try:
        result = client.inference.submit_run(
            run_id,
            {
                "max_tasks": max_tasks,
                "platform": platform,
                "region": region,
                "cpu": cpu,
                "memory": memory,
            },
        )
    finally:
        client.close()
    render(result, format=output or auto_format())


@app.command("progress")
def progress(
    run_id: str = typer.Argument(...),
    output: OutputFormat | None = typer.Option(None, "-o", "--output", help="Render format."),
) -> None:
    """Fetch current run progress, success counts, and ETA."""
    client = get_internal_sdk_client()
    try:
        result = client.inference.progress(run_id)
    finally:
        client.close()
    render(result, format=output or auto_format())


@app.command("watch")
def watch(
    run_id: str = typer.Argument(...),
    interval: float = typer.Option(
        5.0,
        "--interval",
        help="Polling interval in seconds.",
    ),
) -> None:
    """Continuously poll run progress until completion."""
    client = get_internal_sdk_client()
    try:
        _watch_run(client, run_id, interval=interval)
    finally:
        client.close()


def _watch_run(client: Any, run_id: str, *, interval: float = 5.0) -> None:
    last_status: str | None = None
    while True:
        progress = client.inference.progress(run_id)
        status = progress.status
        if status != last_status:
            info(f"status={status}")
            last_status = status
        info(
            "progress="
            f"{progress.progress_pct:.1f}% "
            f"chunks={progress.chunks_succeeded}/{progress.total_chunks} "
            f"items={progress.items_succeeded} failed={progress.items_failed} "
            f"eta={progress.eta_seconds}"
        )
        if status in {"succeeded", "failed", "cancelled"}:
            return
        time.sleep(interval)


@app.command("results")
def results(
    run_id: str = typer.Argument(...),
    page_size: int = typer.Option(
        500,
        "--page-size",
        min=1,
        max=500,
        help="API page size for auto-pagination.",
    ),
    output: OutputFormat | None = typer.Option(None, "-o", "--output", help="Render format."),
) -> None:
    """Fetch the full result set for a run. This auto-paginates all pages."""
    client = get_internal_sdk_client()
    try:
        items = list(auto_paginate(client.inference.results, run_id=run_id, page_size=page_size))
    finally:
        client.close()
    render(items, format=output or auto_format())
