"""Schema management and comparison tools."""

import asyncio
import json
from dataclasses import dataclass, field
from typing import Any

import typer
from infra.settings import switch_environment
from rich.table import Table
from typing_extensions import Annotated

from cli.console import console, error, info, success, warning
from cli.context import get_admin_connection, get_connection, resolve_admin_connection_config

app = typer.Typer(
    name="schema",
    help="Schema management and comparison tools",
    no_args_is_help=True,
)


def _schema_connection(settings):
    """Prefer the canonical admin connection for read-only schema introspection."""
    if resolve_admin_connection_config(settings) is not None:
        return get_admin_connection(settings)
    return get_connection(settings)


@dataclass
class ColumnInfo:
    """Information about a database column."""

    name: str
    data_type: str
    is_nullable: bool
    column_default: str | None
    character_maximum_length: int | None = None


@dataclass
class TableInfo:
    """Information about a database table."""

    schema: str
    name: str
    columns: dict[str, ColumnInfo] = field(default_factory=dict)


@dataclass
class SchemaDiff:
    """Differences between two schemas."""

    # Tables that exist in source but not target
    tables_missing_in_target: list[str] = field(default_factory=list)
    # Tables that exist in target but not source
    tables_extra_in_target: list[str] = field(default_factory=list)
    # Column differences: {table: {column: (source_type, target_type)}}
    column_type_diffs: dict[str, dict[str, tuple[str, str]]] = field(default_factory=dict)
    # Columns missing in target: {table: [columns]}
    columns_missing_in_target: dict[str, list[str]] = field(default_factory=dict)
    # Columns extra in target: {table: [columns]}
    columns_extra_in_target: dict[str, list[str]] = field(default_factory=dict)

    def is_empty(self) -> bool:
        """Check if there are no differences."""
        return (
            not self.tables_missing_in_target
            and not self.tables_extra_in_target
            and not self.column_type_diffs
            and not self.columns_missing_in_target
            and not self.columns_extra_in_target
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON output."""
        return {
            "tables_missing_in_target": self.tables_missing_in_target,
            "tables_extra_in_target": self.tables_extra_in_target,
            "column_type_diffs": self.column_type_diffs,
            "columns_missing_in_target": self.columns_missing_in_target,
            "columns_extra_in_target": self.columns_extra_in_target,
        }


async def fetch_schema_info(env: str) -> dict[str, TableInfo]:
    """
    Fetch schema information from a database.

    Uses information_schema to get table and column details.
    """
    settings = switch_environment(env)

    query = """
        SELECT
            t.table_schema,
            t.table_name,
            c.column_name,
            c.data_type,
            c.is_nullable,
            c.column_default,
            c.character_maximum_length
        FROM information_schema.tables t
        JOIN information_schema.columns c
            ON t.table_schema = c.table_schema
            AND t.table_name = c.table_name
        WHERE t.table_schema IN ('core', 'observations', 'ops', 'collections', 'auth', 'archive', 'agent')
            AND t.table_type = 'BASE TABLE'
        ORDER BY t.table_schema, t.table_name, c.ordinal_position
    """

    tables: dict[str, TableInfo] = {}

    async with _schema_connection(settings) as conn:
        rows = await conn.fetch(query)

        for row in rows:
            full_name = f"{row['table_schema']}.{row['table_name']}"

            if full_name not in tables:
                tables[full_name] = TableInfo(
                    schema=row["table_schema"],
                    name=row["table_name"],
                )

            tables[full_name].columns[row["column_name"]] = ColumnInfo(
                name=row["column_name"],
                data_type=row["data_type"],
                is_nullable=row["is_nullable"] == "YES",
                column_default=row["column_default"],
                character_maximum_length=row["character_maximum_length"],
            )

    return tables


def compare_schemas(source: dict[str, TableInfo], target: dict[str, TableInfo]) -> SchemaDiff:
    """Compare two schema snapshots and return differences."""
    diff = SchemaDiff()

    source_tables = set(source.keys())
    target_tables = set(target.keys())

    # Find missing/extra tables
    diff.tables_missing_in_target = sorted(source_tables - target_tables)
    diff.tables_extra_in_target = sorted(target_tables - source_tables)

    # Compare columns in common tables
    for table_name in source_tables & target_tables:
        source_table = source[table_name]
        target_table = target[table_name]

        source_cols = set(source_table.columns.keys())
        target_cols = set(target_table.columns.keys())

        # Missing columns
        missing = sorted(source_cols - target_cols)
        if missing:
            diff.columns_missing_in_target[table_name] = missing

        # Extra columns
        extra = sorted(target_cols - source_cols)
        if extra:
            diff.columns_extra_in_target[table_name] = extra

        # Type differences in common columns
        for col_name in source_cols & target_cols:
            source_col = source_table.columns[col_name]
            target_col = target_table.columns[col_name]

            # Compare data types (normalize for comparison)
            source_type = source_col.data_type
            target_type = target_col.data_type

            if source_type != target_type:
                if table_name not in diff.column_type_diffs:
                    diff.column_type_diffs[table_name] = {}
                diff.column_type_diffs[table_name][col_name] = (source_type, target_type)

    return diff


def print_diff_table(diff: SchemaDiff, source_env: str, target_env: str) -> None:
    """Print schema differences as a formatted table."""
    if diff.is_empty():
        success(f"Schemas are identical between {source_env} and {target_env}")
        return

    warning(f"Schema differences found between {source_env} and {target_env}")
    console.print()

    # Missing tables
    if diff.tables_missing_in_target:
        table = Table(title=f"Tables in {source_env} missing from {target_env}")
        table.add_column("Table", style="red")
        for t in diff.tables_missing_in_target:
            table.add_row(t)
        console.print(table)
        console.print()

    # Extra tables
    if diff.tables_extra_in_target:
        table = Table(title=f"Tables in {target_env} not in {source_env}")
        table.add_column("Table", style="yellow")
        for t in diff.tables_extra_in_target:
            table.add_row(t)
        console.print(table)
        console.print()

    # Column type differences
    if diff.column_type_diffs:
        table = Table(title="Column Type Differences")
        table.add_column("Table", style="cyan")
        table.add_column("Column", style="white")
        table.add_column(f"{source_env}", style="green")
        table.add_column(f"{target_env}", style="red")
        for tbl, cols in sorted(diff.column_type_diffs.items()):
            for col, (src_type, tgt_type) in sorted(cols.items()):
                table.add_row(tbl, col, src_type, tgt_type)
        console.print(table)
        console.print()

    # Missing columns
    if diff.columns_missing_in_target:
        table = Table(title=f"Columns in {source_env} missing from {target_env}")
        table.add_column("Table", style="cyan")
        table.add_column("Column", style="red")
        for tbl, cols in sorted(diff.columns_missing_in_target.items()):
            for col in cols:
                table.add_row(tbl, col)
        console.print(table)
        console.print()

    # Extra columns
    if diff.columns_extra_in_target:
        table = Table(title=f"Columns in {target_env} not in {source_env}")
        table.add_column("Table", style="cyan")
        table.add_column("Column", style="yellow")
        for tbl, cols in sorted(diff.columns_extra_in_target.items()):
            for col in cols:
                table.add_row(tbl, col)
        console.print(table)


@app.command()
def compare(
    source: Annotated[
        str, typer.Option("--source", "-s", help="Source environment")
    ] = "development",
    target: Annotated[
        str, typer.Option("--target", "-t", help="Target environment")
    ] = "production",
    output_format: Annotated[
        str, typer.Option("--format", "-f", help="Output format: table, json, markdown")
    ] = "table",
) -> None:
    """
    Compare schemas between two database environments.

    Useful for detecting schema drift between dev and production.

    Examples:
        buildai admin schema compare                              # Compare development vs production (default)
        buildai admin schema compare -s development -t production # Explicit environments
        buildai admin schema compare --format json                # Output as JSON
    """

    async def run() -> None:
        info(f"Fetching schema from {source}...")
        source_schema = await fetch_schema_info(source)
        info(f"  Found {len(source_schema)} tables")

        info(f"Fetching schema from {target}...")
        target_schema = await fetch_schema_info(target)
        info(f"  Found {len(target_schema)} tables")

        console.print()
        diff = compare_schemas(source_schema, target_schema)

        if output_format == "json":
            console.print(json.dumps(diff.to_dict(), indent=2))
        elif output_format == "markdown":
            # Simple markdown output
            if diff.is_empty():
                console.print(f"✓ Schemas are identical between {source} and {target}")
            else:
                console.print(f"## Schema Drift: {source} → {target}\n")
                if diff.tables_missing_in_target:
                    console.print(f"### Tables missing in {target}")
                    for t in diff.tables_missing_in_target:
                        console.print(f"- `{t}`")
                    console.print()
                if diff.tables_extra_in_target:
                    console.print(f"### Extra tables in {target}")
                    for t in diff.tables_extra_in_target:
                        console.print(f"- `{t}`")
                    console.print()
                if diff.column_type_diffs:
                    console.print("### Column type differences")
                    for tbl, cols in sorted(diff.column_type_diffs.items()):
                        for col, (src, tgt) in sorted(cols.items()):
                            console.print(f"- `{tbl}.{col}`: `{src}` → `{tgt}`")
                    console.print()
        else:
            print_diff_table(diff, source, target)

    asyncio.run(run())


@app.command("tables")
def list_tables(
    ctx: typer.Context,
    schema_name: Annotated[
        str | None, typer.Option("--schema", "-s", help="Filter by schema name")
    ] = None,
) -> None:
    """
    List all tables in the database.

    Examples:
        buildai admin schema tables              # List all tables
        buildai admin schema tables -s core      # List only core.* tables
    """
    settings = ctx.obj["settings"]

    async def run() -> None:
        query = """
            SELECT
                table_schema,
                table_name,
                (
                    SELECT COUNT(*)
                    FROM information_schema.columns c
                    WHERE c.table_schema = t.table_schema
                    AND c.table_name = t.table_name
                ) as column_count
            FROM information_schema.tables t
            WHERE table_schema NOT IN ('pg_catalog', 'information_schema', 'pg_toast', 'cron', 'public')
                AND table_type = 'BASE TABLE'
        """

        if schema_name:
            query += f" AND table_schema = '{schema_name}'"

        query += " ORDER BY table_schema, table_name"

        async with _schema_connection(settings) as conn:
            rows = await conn.fetch(query)

            table = Table(title="Database Tables")
            table.add_column("Schema", style="cyan")
            table.add_column("Table", style="white")
            table.add_column("Columns", justify="right")

            for row in rows:
                table.add_row(
                    row["table_schema"],
                    row["table_name"],
                    str(row["column_count"]),
                )

            console.print(table)
            console.print(f"\n[dim]Total: {len(rows)} tables[/dim]")

    asyncio.run(run())


@app.command("describe")
def describe_table(
    ctx: typer.Context,
    table_name: Annotated[str, typer.Argument(help="Table name (e.g., core.clips)")],
) -> None:
    """
    Show detailed information about a table.

    Examples:
        buildai admin schema describe core.clips
        buildai admin schema describe processing.manifests
    """
    settings = ctx.obj["settings"]

    async def run() -> None:
        # Parse schema.table format
        if "." in table_name:
            schema, name = table_name.split(".", 1)
        else:
            error("Table name must include schema (e.g., core.clips)")
            raise typer.Exit(1)

        query = """
            SELECT
                column_name,
                data_type,
                is_nullable,
                column_default,
                character_maximum_length
            FROM information_schema.columns
            WHERE table_schema = $1 AND table_name = $2
            ORDER BY ordinal_position
        """

        async with _schema_connection(settings) as conn:
            rows = await conn.fetch(query, schema, name)

            if not rows:
                error(f"Table not found: {table_name}")
                raise typer.Exit(1)

            table = Table(title=f"Table: {table_name}")
            table.add_column("Column", style="cyan")
            table.add_column("Type", style="white")
            table.add_column("Nullable", justify="center")
            table.add_column("Default", style="dim")

            for row in rows:
                dtype = row["data_type"]
                if row["character_maximum_length"]:
                    dtype += f"({row['character_maximum_length']})"

                nullable = "✓" if row["is_nullable"] == "YES" else ""
                default = str(row["column_default"])[:30] if row["column_default"] else ""

                table.add_row(row["column_name"], dtype, nullable, default)

            console.print(table)

    asyncio.run(run())
