"""API-backed query command."""

from __future__ import annotations

import json
import sys
from typing import Any

import typer

from cli.output import OutputFormat, auto_format, render
from cli.sdk_client import get_internal_sdk_client


def _append_offset(sql: str, offset: int) -> str:
    return f"{sql.rstrip().rstrip(';')} OFFSET {offset}"


def _fetch_all_rows(
    client: Any, sql: str, limit: int, max_rows: int
) -> tuple[list[dict[str, Any]], list[str]]:
    """Auto-paginate through the API, collecting up to max_rows total."""
    offset = 0
    rows: list[dict[str, Any]] = []
    columns: list[str] = []

    while len(rows) < max_rows:
        result = client.query.run(_append_offset(sql, offset) if offset else sql, limit=limit)
        columns = result.columns or columns
        rows.extend(result.rows)
        if not result.truncated or not result.rows:
            break
        offset += limit

    return rows[:max_rows], columns


def _stream_jsonl(client: Any, sql: str, limit: int, max_rows: int) -> None:
    """Stream JSONL rows directly to stdout without buffering the full result."""
    offset = 0
    emitted = 0

    while emitted < max_rows:
        result = client.query.run(_append_offset(sql, offset) if offset else sql, limit=limit)
        for row in result.rows:
            if emitted >= max_rows:
                break
            sys.stdout.write(json.dumps(row, default=str) + "\n")
            emitted += 1
        sys.stdout.flush()
        if not result.truncated or not result.rows:
            break
        offset += limit


def query(
    sql: str = typer.Argument(..., help="Read-only SQL query to execute through the API."),
    limit: int = typer.Option(500, "--limit", help="Rows per API request (page size)."),
    max_rows: int = typer.Option(
        100_000,
        "--max-rows",
        help="Maximum total rows to fetch across all pages. Set to 0 for unlimited.",
    ),
    output: OutputFormat | None = typer.Option(
        None,
        "-o",
        "--output",
        help="Output format: table, json, jsonl, csv. Default: table (TTY) or json (pipe).",
    ),
) -> None:
    """Execute a read-only SQL query via the API.

    Examples:

        buildai query "SELECT count(*) FROM core.clips"

        buildai query "SELECT * FROM core.clips LIMIT 10" -o json

        buildai query "SELECT * FROM core.clips" -o jsonl > clips.jsonl

        buildai query "SELECT * FROM core.clips" -o csv > clips.csv

        buildai query "SELECT * FROM core.clips" --max-rows 500000 -o jsonl > big_export.jsonl
    """
    effective_max = max_rows if max_rows > 0 else 10_000_000
    client = get_internal_sdk_client()
    try:
        fmt = output or auto_format()

        # JSONL: stream directly to stdout without buffering
        if fmt == OutputFormat.JSONL:
            _stream_jsonl(client, sql, limit, effective_max)
            return

        # CSV: auto-paginate, then render
        if fmt == OutputFormat.CSV:
            rows, columns = _fetch_all_rows(client, sql, limit, effective_max)
            render(rows, format=fmt, columns=columns)
            return

        # JSON: single page (or auto-paginate if piped)
        if fmt == OutputFormat.JSON:
            if sys.stdout.isatty():
                # Interactive: show single page with metadata
                result = client.query.run(sql, limit=limit)
                render(result.model_dump(mode="json"), format=fmt)
            else:
                # Piped: auto-paginate and emit array
                rows, columns = _fetch_all_rows(client, sql, limit, effective_max)
                render(rows, format=fmt, columns=columns)
            return

        # TABLE: single page
        result = client.query.run(sql, limit=limit)
        render(result.rows, format=fmt, columns=result.columns)
    finally:
        client.close()
