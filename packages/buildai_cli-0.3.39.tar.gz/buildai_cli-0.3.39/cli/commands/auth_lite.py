"""Lightweight auth commands backed by the public API."""

from __future__ import annotations

import sys
import time
import webbrowser
from typing import Any

import httpx
import typer

from cli.config import clear_credential, resolve_api_url, save_cli_config
from cli.console import console, error, info, success, warning
from cli.output import auto_format, render
from cli.sdk_client import get_internal_sdk_client

app = typer.Typer(no_args_is_help=True)


def _api_base_url() -> str:
    return resolve_api_url()


def _raise_for_status(resp: httpx.Response) -> None:
    try:
        payload = resp.json()
    except Exception:
        payload = None

    message = None
    if isinstance(payload, dict):
        if isinstance(payload.get("detail"), str):
            message = payload["detail"]
        elif isinstance(payload.get("error"), dict):
            message = payload["error"].get("message")
    if not message:
        message = resp.text or f"HTTP {resp.status_code}"
    raise typer.BadParameter(message)


def _start_device_login(client: httpx.Client, client_name: str) -> dict[str, Any]:
    resp = client.post(
        f"{_api_base_url()}/v1/auth/cli/start",
        json={"client_name": client_name},
    )
    if resp.status_code >= 400:
        _raise_for_status(resp)
    return resp.json()


def _poll_device_login(client: httpx.Client, device_code: str) -> dict[str, Any]:
    resp = client.get(
        f"{_api_base_url()}/v1/auth/cli/poll",
        params={"device_code": device_code},
    )
    if resp.status_code == 429:
        retry_after = resp.headers.get("Retry-After")
        if retry_after:
            try:
                time.sleep(max(float(retry_after), 0.0))
            except ValueError:
                pass
        return {"status": "pending"}
    if resp.status_code >= 400:
        _raise_for_status(resp)
    return resp.json()


def _store_token(token: str, *, profile: str | None = None) -> None:
    save_cli_config(profile=profile, api_key=token)
    success("Saved CLI credentials to ~/.buildai/credentials.json")


def _device_login(
    *,
    client_name: str = "buildai-cli",
    open_browser: bool = True,
    profile: str | None = None,
) -> None:
    with httpx.Client(timeout=15.0) as client:
        try:
            start = _start_device_login(client, client_name)
        except typer.BadParameter as exc:
            error(str(exc))
            raise typer.Exit(1) from exc

        verification_url = start["verification_url"]
        user_code = start["user_code"]
        expires_in = int(start["expires_in"])
        poll_interval = max(int(start["poll_interval"]), 1)

        console.print(f"  code   : [cyan]{user_code}[/cyan]")
        console.print(f"  verify : [cyan]{verification_url}[/cyan]")
        info("Approve this login in the browser, then the CLI will finish automatically.")

        if open_browser:
            try:
                if webbrowser.open(verification_url):
                    info("Opened verification URL in your browser.")
                else:
                    warning("Could not open your browser automatically.")
            except Exception:
                warning("Could not open your browser automatically.")

        deadline = time.monotonic() + expires_in + poll_interval
        while time.monotonic() < deadline:
            try:
                poll = _poll_device_login(client, start["device_code"])
            except typer.BadParameter as exc:
                error(str(exc))
                raise typer.Exit(1) from exc

            status = poll.get("status")
            if status == "approved":
                token = poll.get("token")
                if not token:
                    error("CLI login completed without a token.")
                    raise typer.Exit(1)
                _store_token(token, profile=profile)
                return
            if status == "pending":
                time.sleep(poll_interval)
                continue
            if status == "expired":
                error("CLI login expired before approval.")
                raise typer.Exit(1)
            if status == "consumed":
                error("CLI login token was already consumed.")
                raise typer.Exit(1)
            error(f"Unexpected CLI login status: {status!r}")
            raise typer.Exit(1)

    error("CLI login timed out before approval.")
    raise typer.Exit(1)


@app.command("login")
def login(
    token: bool = typer.Option(
        False,
        "--token",
        help="Read a token from stdin instead of running browser-based device login.",
    ),
    client_name: str = typer.Option(
        "buildai-cli",
        "--client-name",
        help="Client name sent to the API for device-login requests.",
    ),
    open_browser: bool = typer.Option(
        True,
        "--open-browser/--no-open-browser",
        help="Open the verification URL in your browser during device login.",
    ),
    profile: str | None = typer.Option(None, "--profile", hidden=True),
) -> None:
    """Log in with device flow, or read a token from stdin for CI."""
    if token:
        value = sys.stdin.read().strip()
        if not value:
            error("Expected a token on stdin.")
            raise typer.Exit(1)
        _store_token(value, profile=profile)
        return
    _device_login(client_name=client_name, open_browser=open_browser, profile=profile)


@app.command("login-device", hidden=True)
def login_device(
    client_name: str = typer.Option("buildai-cli", "--client-name"),
    open_browser: bool = typer.Option(True, "--open-browser/--no-open-browser"),
    profile: str | None = typer.Option(None, "--profile"),
) -> None:
    """Backward-compatible alias for device login."""
    _device_login(client_name=client_name, open_browser=open_browser, profile=profile)


@app.command("whoami")
def whoami() -> None:
    """Inspect the resolved principal and permissions for the current credential."""
    client = get_internal_sdk_client()
    try:
        access = client.access.inspect()
    finally:
        client.close()

    render(
        {
            "principal_display_name": access.principal_display_name,
            "principal_subject": access.principal_subject,
            "principal_type": access.principal_type,
            "audience": access.audience,
            "mode": access.mode,
            "permissions": access.permissions,
            "boundary": access.boundary.model_dump(mode="json") if access.boundary else None,
        },
        format=auto_format(),
        columns=[
            "principal_display_name",
            "principal_subject",
            "principal_type",
            "audience",
            "mode",
            "permissions",
            "boundary",
        ],
    )


@app.command("logout")
def logout() -> None:
    """Remove the locally stored CLI credential."""
    clear_credential()
    success("Removed ~/.buildai/credentials.json")
