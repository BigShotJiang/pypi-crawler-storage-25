"""Execute SQL queries against the database."""

import asyncio
import re

import typer
from infra.settings import Settings
from typing_extensions import Annotated

from cli.console import console, dim, error, show_sql, warning
from cli.context import get_admin_connection, get_connection, resolve_admin_connection_config
from cli.output import Format, format_option, output

# =============================================================================
# Query hints for DAL-covered tables
# =============================================================================

# Map of table patterns to suggested CLI commands
QUERY_HINTS = {
    "processing.jobs": "Tip: Use 'buildai admin embeddings index list' for embedding index status.",
    "processing.jobs_embed": "Tip: Use 'buildai admin embeddings index list' for embedding index status.",
    "observations.frame_embeddings": "Note: observations.frame_embeddings has been dropped. Use observations.emb_siglip2_ego100k_frame_default instead. 'buildai admin embeddings index list' shows current spaces.",
    "observations.clip_embeddings": "Note: observations.clip_embeddings has been dropped. Use observations.emb_qwen_holistic_v1 (or other emb_qwen_* / emb_siglip_*) instead. 'buildai admin embeddings index list' shows current spaces.",
    "observations.text_embeddings": "Note: observations.text_embeddings has been dropped. Use observations.emb_gemini_task_name (or other emb_gemini_*) instead. 'buildai admin embeddings index list' shows current spaces.",
    "observations.embedding_models": "Note: observations.embedding_models has been dropped. Use observations.embedding_spaces instead. 'buildai admin embeddings index list' shows current spaces.",
    "observations.embedding_spaces": "Tip: Use 'buildai admin embeddings index list' to see embedding spaces and index status.",
    "observations.projection": "Tip: Use 'buildai admin projection status' to inspect projection jobs.",
    "public._migrations": "Tip: Use 'buildai admin database migrate' to view migration status.",
    "core.clips": None,  # No specific hint, DAL covers this but raw queries are often needed
}


def _show_query_hints(sql: str) -> None:
    """Show helpful hints when queries touch DAL-covered tables."""
    sql_lower = sql.lower()
    shown = set()

    for table_pattern, hint in QUERY_HINTS.items():
        if hint and table_pattern.lower() in sql_lower and hint not in shown:
            dim(f"\n{hint}")
            shown.add(hint)


def _normalize_sql(sql: str) -> str:
    """Normalize SQL for analysis (remove comments, collapse whitespace)."""
    # Remove single-line comments
    normalized = re.sub(r"--.*$", "", sql, flags=re.MULTILINE)
    # Remove multi-line comments
    normalized = re.sub(r"/\*.*?\*/", "", normalized, flags=re.DOTALL)
    # Collapse whitespace
    return " ".join(normalized.split()).upper()


def _is_write_query(sql: str) -> bool:
    """
    Detect if query modifies data using sqlparse AST.

    Checks for SQL statements that modify database state.
    SELECT queries (including CTEs, subqueries) are considered safe.
    """
    import sqlparse

    _WRITE_TYPES = {
        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "CREATE",
        "ALTER",
        "TRUNCATE",
        "GRANT",
        "REVOKE",
    }

    statements = sqlparse.parse(sql)
    for stmt in statements:
        stmt_type = stmt.get_type()
        if stmt_type and stmt_type.upper() in _WRITE_TYPES:
            return True

    # Fallback: sqlparse may not classify VACUUM/REASSIGN
    normalized = _normalize_sql(sql)
    for kw in ("VACUUM", "REASSIGN"):
        if normalized.startswith(kw + " ") or normalized == kw:
            return True

    return False


def _is_ddl_query(sql: str) -> bool:
    """Detect schema/ownership-changing DDL statements."""
    import sqlparse

    ddl_types = {
        "DROP",
        "CREATE",
        "ALTER",
        "TRUNCATE",
        "GRANT",
        "REVOKE",
    }

    statements = sqlparse.parse(sql)
    for stmt in statements:
        stmt_type = stmt.get_type()
        if stmt_type and stmt_type.upper() in ddl_types:
            return True

    normalized = _normalize_sql(sql)
    return normalized.startswith("REASSIGN ") or normalized == "REASSIGN"


def _is_select_query(sql: str) -> bool:
    """
    Detect if query returns rows (SELECT or WITH ... SELECT).

    Commands like GRANT, DROP, INSERT, etc. return status strings, not rows.
    """
    normalized = _normalize_sql(sql)

    # SELECT queries return rows
    if normalized.startswith("SELECT "):
        return True

    # WITH ... SELECT returns rows (CTEs)
    if normalized.startswith("WITH "):
        # Check if it ends with SELECT (not INSERT/UPDATE/DELETE)
        for kw in ["INSERT", "UPDATE", "DELETE"]:
            if f" {kw} " in normalized:
                return False
        return True

    # SHOW, EXPLAIN, TABLE also return rows
    for kw in ["SHOW ", "EXPLAIN ", "TABLE "]:
        if normalized.startswith(kw):
            return True

    return False


def query(
    ctx: typer.Context,
    sql: Annotated[str, typer.Argument(help="SQL query to execute")],
    format: Format = format_option(),
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation for write queries"),
    ] = False,
    write: Annotated[
        bool,
        typer.Option("--write", help="Allow write queries (requires internal_admin profile)"),
    ] = False,
) -> None:
    """
    Execute SQL queries directly against the database.

    Environment is controlled by --env flag on the main CLI:
    - Default: development (safe)
    - Production: requires --env production flag

    SAFETY: Write operations (INSERT, UPDATE, DELETE, etc.) to production
    require confirmation. SELECT queries run without prompting.

    Examples:
        buildai admin query "SELECT COUNT(*) FROM core.clips"
        buildai admin query "SELECT * FROM operations.device_models"
        buildai admin query "SELECT schemaname, tablename FROM pg_tables WHERE schemaname = 'core'" -f json
        buildai admin --env production --profile internal_admin query "INSERT INTO ..." --write --yes  # Skip confirmation
    """
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        is_write = _is_write_query(sql)
        is_ddl = _is_ddl_query(sql)
        cli_profile = (ctx.obj or {}).get("cli_profile", "internal_viewer")

        if is_write and not write:
            error("Write query blocked. Re-run with --write and an internal_admin profile.")
            raise typer.Exit(1)

        if is_write and cli_profile != "internal_admin":
            error("Write query requires --profile internal_admin.")
            raise typer.Exit(1)

        if settings.is_production and is_ddl:
            error(
                "Production DDL is blocked in 'buildai admin query'. "
                "Use 'buildai admin database migrate ...' or dedicated ops tooling."
            )
            raise typer.Exit(1)

        # SAFETY: Only confirm WRITE operations to production
        if settings.is_production and is_write and not yes:
            warning("WRITE operation to PRODUCTION database")
            console.print(f"  Database: [bold red]{settings.db_name}[/bold red]")
            preview = sql[:100] + ("..." if len(sql) > 100 else "")
            console.print(f"  Query: [dim]{preview}[/dim]")
            console.print()
            if not typer.confirm("Execute this write query?", default=False):
                console.print("[dim]Aborted.[/dim]")
                raise typer.Exit(0)
            console.print()

        show_sql(sql)

        admin_config = resolve_admin_connection_config(settings)
        use_admin_connection = admin_config is not None and (
            _is_select_query(sql) or (is_write and cli_profile == "internal_admin")
        )
        if use_admin_connection and admin_config is not None:
            dim(f"Using admin DB principal: {admin_config.user}")

        connection_context = (
            get_admin_connection(settings) if use_admin_connection else get_connection(settings)
        )

        async with connection_context as conn:
            try:
                if _is_select_query(sql):
                    # SELECT queries return rows
                    result = await conn.fetch(sql)
                    rows = [dict(row) for row in result]
                    columns = list(result[0].keys()) if result else []
                    output(rows, format=format, columns=columns)
                else:
                    # DDL/DML commands return status string
                    status = await conn.execute(sql)
                    # Status examples: "GRANT", "REVOKE", "DROP OWNED", "INSERT 0 1", "UPDATE 5"
                    console.print(f"[green]✓[/green] {status}")

                # Show helpful hints for DAL-covered tables
                _show_query_hints(sql)
            except Exception as e:
                error(f"Query failed: {e}")
                # Show more details for permission errors
                err_str = str(e).lower()
                if "permission denied" in err_str:
                    console.print(
                        "[dim]Hint: You may need GRANT <role> TO your_user to perform this action[/dim]"
                    )
                elif "does not exist" in err_str:
                    console.print(
                        "[dim]Hint: Check if the object/role name is correct and quoted properly[/dim]"
                    )
                elif "cannot be dropped" in err_str:
                    console.print(
                        '[dim]Hint: Use DROP OWNED BY "user" CASCADE first to remove dependencies[/dim]'
                    )
                raise typer.Exit(1)

    asyncio.run(run())
