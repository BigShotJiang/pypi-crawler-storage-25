"""CLI commands for jobs (SDK-backed data-plane)."""

from __future__ import annotations

import itertools
import time
from typing import Any

import typer

from cli.console import info, success, warning
from cli.output import Format, format_option, output
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="jobs",
    help="Manage processing jobs.",
    no_args_is_help=True,
)


def _job_row(job: Any) -> dict[str, Any]:
    return {
        "job_id": job.job_id,
        "job_type": job.job_type,
        "status": job.status,
        "progress_pct": getattr(job, "progress_pct", 0.0),
        "total_items": getattr(job, "total_items", None),
        "chunk_count": getattr(job, "chunk_count", None),
        "created_at": getattr(job, "created_at", None),
    }


def _launch_job(
    client: Any,
    job_id: str,
    *,
    max_tasks: int,
    spot: bool,
    platform: str,
    region: str | None,
    cpu: str,
    memory: str,
) -> Any:
    return client.jobs.submit(
        job_id,
        max_tasks=max_tasks,
        spot=spot,
        platform=platform,
        region=region,
        cpu=cpu,
        memory=memory,
    )


def _watch_job(client: Any, job_id: str, *, interval: float) -> None:
    last_line: str | None = None
    while True:
        progress = client.jobs.progress(job_id)
        line = (
            f"{progress.status} "
            f"chunks={progress.chunks_succeeded + progress.chunks_failed}/{progress.total_chunks} "
            f"items={progress.items_succeeded} ok/{progress.items_failed} failed "
            f"items_per_sec={progress.items_per_second} "
            f"chunks_per_sec={progress.chunks_per_second} "
            f"eta_s={progress.eta_seconds}"
        )
        if line != last_line:
            info(f"{job_id}: {line}")
            last_line = line
        if progress.status in {"succeeded", "failed", "cancelled"}:
            if progress.status != "succeeded":
                failures = client.jobs.failures(job_id, page_size=5)
                if failures.data:
                    for failure in failures.data:
                        warning(
                            f"{failure.entity_id} | "
                            f"{failure.error_code or 'error'} | "
                            f"{failure.error_message or ''}"
                        )
            return
        time.sleep(interval)


@app.command("list")
def jobs_list(
    status: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
    type: str | None = typer.Option(None, "--type", "-t", help="Filter by job type"),
    limit: int = typer.Option(20, "--limit", "-n"),
    format: Format | None = format_option(),
) -> None:
    """List processing jobs."""
    client = get_sdk_client()
    results = list(
        itertools.islice(
            client.jobs.iter(status=status, type=type),
            limit,
        )
    )
    output(
        [_job_row(job) for job in results],
        format=format,
        columns=["job_id", "job_type", "status", "progress_pct", "total_items", "chunk_count"],
    )


@app.command("get")
def jobs_get(
    job_id: str = typer.Argument(..., help="Manifest ID"),
    format: Format | None = format_option(),
) -> None:
    """Get details for a single job."""
    client = get_sdk_client()
    job = client.jobs.get(job_id)
    output(job, format=format)


@app.command("submit")
def jobs_submit(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Manifest ID"),
    max_tasks: int = typer.Option(750, "--max-tasks"),
    spot: bool = typer.Option(True, "--spot/--no-spot"),
    platform: str = typer.Option("auto", "--platform"),
    region: str | None = typer.Option(None, "--region"),
    cpu: str = typer.Option("8", "--cpu"),
    memory: str = typer.Option("8Gi", "--memory"),
    watch: bool = typer.Option(False, "--watch"),
    interval: float = typer.Option(5.0, "--interval"),
) -> None:
    """Submit an existing manifest to execution."""
    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    result = _launch_job(
        client,
        job_id,
        max_tasks=max_tasks,
        spot=spot,
        platform=platform,
        region=region,
        cpu=cpu,
        memory=memory,
    )
    success(
        f"Submitted {job_id} on {result.platform} "
        f"as {result.batch_job_name} with {result.task_count} tasks"
    )
    if watch:
        _watch_job(client, job_id, interval=interval)


@app.command("watch")
def jobs_watch(
    job_id: str = typer.Argument(..., help="Manifest ID"),
    interval: float = typer.Option(5.0, "--interval"),
) -> None:
    """Watch a job until completion."""
    client = get_sdk_client()
    _watch_job(client, job_id, interval=interval)


@app.command("retry")
def jobs_retry(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Manifest ID"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Retry a failed job."""
    if dry_run:
        info(f"Would retry job {job_id}")
        return

    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    client.jobs.retry(job_id)
    success(f"Retried job {job_id}")


@app.command("cancel")
def jobs_cancel(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Manifest ID"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Cancel a running job."""
    if dry_run:
        info(f"Would cancel job {job_id}")
        return

    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    client.jobs.cancel(job_id)
    success(f"Cancelled job {job_id}")
