"""CLI commands for operations (SDK-backed, internal mode)."""

from __future__ import annotations

import typer

from cli.output import Format, format_option, output
from cli.sdk_client import get_internal_sdk_client

app = typer.Typer(
    name="operations",
    help="Operational metrics (internal).",
    no_args_is_help=True,
)


@app.command("hours")
def ops_hours(
    range: str = typer.Option("7d", "--range", "-r", help="Time range (e.g. 7d, 30d)"),
    by_team: bool = typer.Option(False, "--by-team", help="Break down by team"),
    format: Format | None = format_option(),
) -> None:
    """Show recording hours summary."""
    client = get_internal_sdk_client()
    result = client.operations.hours(range=range, by_team=by_team)
    output(result, format=format)


@app.command("teams")
def ops_teams(
    range: str = typer.Option("7d", "--range", "-r"),
    format: Format | None = format_option(),
) -> None:
    """Show team activity summary."""
    client = get_internal_sdk_client()
    result = client.operations.teams(range=range)
    output(result, format=format)


@app.command("devices")
def ops_devices(
    range: str = typer.Option("7d", "--range", "-r"),
    format: Format | None = format_option(),
) -> None:
    """Show device timeline."""
    client = get_internal_sdk_client()
    result = client.operations.devices(range=range)
    output(result, format=format)
