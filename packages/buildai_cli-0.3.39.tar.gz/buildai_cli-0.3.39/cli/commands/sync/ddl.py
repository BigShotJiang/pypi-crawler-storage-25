"""DDL generation functions for database schema objects."""

from cli.commands.sync.models import (
    ConstraintInfo,
    IndexInfo,
    MaterializedViewInfo,
    SequenceInfo,
    TriggerInfo,
)

# =============================================================================
# Index DDL
# =============================================================================


def generate_index_ddl(index: IndexInfo, if_not_exists: bool = True) -> str:
    """
    Generate CREATE INDEX statement.

    Args:
        index: IndexInfo object with index metadata
        if_not_exists: Add IF NOT EXISTS clause

    Returns:
        CREATE INDEX SQL statement
    """
    ddl = index.index_def

    if if_not_exists and "IF NOT EXISTS" not in ddl.upper():
        # Insert IF NOT EXISTS after CREATE [UNIQUE] INDEX
        if "UNIQUE INDEX" in ddl.upper():
            ddl = ddl.replace("CREATE UNIQUE INDEX", "CREATE UNIQUE INDEX IF NOT EXISTS", 1)
        else:
            ddl = ddl.replace("CREATE INDEX", "CREATE INDEX IF NOT EXISTS", 1)

    # Ensure statement ends with semicolon
    if not ddl.rstrip().endswith(";"):
        ddl = ddl.rstrip() + ";"

    return ddl


def generate_index_ddl_concurrent(index: IndexInfo) -> str:
    """
    Generate CREATE INDEX CONCURRENTLY statement (non-blocking).

    This is useful for production environments where you don't want
    to lock the table during index creation.

    Args:
        index: IndexInfo object with index metadata

    Returns:
        CREATE INDEX CONCURRENTLY SQL statement
    """
    ddl = index.index_def

    # Add CONCURRENTLY if not present
    if "CONCURRENTLY" not in ddl.upper():
        if "UNIQUE INDEX" in ddl.upper():
            ddl = ddl.replace("CREATE UNIQUE INDEX", "CREATE UNIQUE INDEX CONCURRENTLY", 1)
        else:
            ddl = ddl.replace("CREATE INDEX", "CREATE INDEX CONCURRENTLY", 1)

    if not ddl.rstrip().endswith(";"):
        ddl = ddl.rstrip() + ";"

    return ddl


def generate_drop_index_ddl(index: IndexInfo, if_exists: bool = True) -> str:
    """
    Generate DROP INDEX statement.

    Args:
        index: IndexInfo object with index metadata
        if_exists: Add IF EXISTS clause

    Returns:
        DROP INDEX SQL statement
    """
    prefix = "DROP INDEX IF EXISTS" if if_exists else "DROP INDEX"
    return f"{prefix} {index.schema_name}.{index.index_name};"


def generate_drop_index_ddl_concurrent(index: IndexInfo) -> str:
    """
    Generate DROP INDEX CONCURRENTLY statement (non-blocking).

    Args:
        index: IndexInfo object with index metadata

    Returns:
        DROP INDEX CONCURRENTLY SQL statement
    """
    return f"DROP INDEX CONCURRENTLY IF EXISTS {index.schema_name}.{index.index_name};"


# =============================================================================
# Constraint DDL
# =============================================================================


def generate_add_constraint_ddl(constraint: ConstraintInfo) -> str:
    """
    Generate ALTER TABLE ADD CONSTRAINT statement.

    Args:
        constraint: ConstraintInfo object with constraint metadata

    Returns:
        ALTER TABLE ADD CONSTRAINT SQL statement
    """
    return (
        f"ALTER TABLE {constraint.schema_name}.{constraint.table_name}\n"
        f"ADD CONSTRAINT {constraint.constraint_name} {constraint.constraint_def};"
    )


def generate_drop_constraint_ddl(constraint: ConstraintInfo, if_exists: bool = True) -> str:
    """
    Generate ALTER TABLE DROP CONSTRAINT statement.

    Args:
        constraint: ConstraintInfo object with constraint metadata
        if_exists: Add IF EXISTS clause

    Returns:
        ALTER TABLE DROP CONSTRAINT SQL statement
    """
    if_clause = "IF EXISTS " if if_exists else ""
    return (
        f"ALTER TABLE {constraint.schema_name}.{constraint.table_name}\n"
        f"DROP CONSTRAINT {if_clause}{constraint.constraint_name};"
    )


# =============================================================================
# Trigger DDL
# =============================================================================


def generate_trigger_ddl(trigger: TriggerInfo, include_function: bool = True) -> str:
    """
    Generate CREATE TRIGGER statement with optional function.

    Args:
        trigger: TriggerInfo object with trigger metadata
        include_function: Include the trigger function definition

    Returns:
        CREATE FUNCTION + CREATE TRIGGER SQL statements
    """
    statements = []

    # Add function definition if available and requested
    if include_function and trigger.function_def:
        func_def = trigger.function_def.rstrip()
        if not func_def.endswith(";"):
            func_def += ";"
        statements.append(func_def)

    # Add trigger definition
    trigger_def = trigger.trigger_def.rstrip()
    if not trigger_def.endswith(";"):
        trigger_def += ";"
    statements.append(trigger_def)

    return "\n\n".join(statements)


def generate_drop_trigger_ddl(trigger: TriggerInfo, if_exists: bool = True) -> str:
    """
    Generate DROP TRIGGER statement.

    Args:
        trigger: TriggerInfo object with trigger metadata
        if_exists: Add IF EXISTS clause

    Returns:
        DROP TRIGGER SQL statement
    """
    if_clause = "IF EXISTS " if if_exists else ""
    return (
        f"DROP TRIGGER {if_clause}{trigger.trigger_name} "
        f"ON {trigger.schema_name}.{trigger.table_name};"
    )


# =============================================================================
# Materialized View DDL
# =============================================================================


def generate_matview_ddl(
    matview: MaterializedViewInfo,
    include_indexes: bool = True,
    with_no_data: bool = False,
) -> str:
    """
    Generate CREATE MATERIALIZED VIEW statement.

    Args:
        matview: MaterializedViewInfo object with view metadata
        include_indexes: Include CREATE INDEX statements for view indexes
        with_no_data: Create without populating data (requires REFRESH later)

    Returns:
        CREATE MATERIALIZED VIEW SQL statement(s)
    """
    # Clean up the view definition
    view_def = matview.view_def.strip()
    if view_def.endswith(";"):
        view_def = view_def[:-1].strip()

    data_clause = "WITH NO DATA" if with_no_data else "WITH DATA"

    statements = [
        f"CREATE MATERIALIZED VIEW IF NOT EXISTS {matview.full_name} AS\n{view_def}\n{data_clause};"
    ]

    # Add indexes if requested
    if include_indexes:
        for idx in matview.indexes:
            statements.append(generate_index_ddl(idx))

    return "\n\n".join(statements)


def generate_drop_matview_ddl(matview: MaterializedViewInfo, if_exists: bool = True) -> str:
    """
    Generate DROP MATERIALIZED VIEW statement.

    Args:
        matview: MaterializedViewInfo object with view metadata
        if_exists: Add IF EXISTS clause

    Returns:
        DROP MATERIALIZED VIEW SQL statement
    """
    if_clause = "IF EXISTS " if if_exists else ""
    return f"DROP MATERIALIZED VIEW {if_clause}{matview.full_name};"


def generate_refresh_matview_ddl(matview: MaterializedViewInfo, concurrently: bool = False) -> str:
    """
    Generate REFRESH MATERIALIZED VIEW statement.

    Args:
        matview: MaterializedViewInfo object with view metadata
        concurrently: Use CONCURRENTLY (requires unique index)

    Returns:
        REFRESH MATERIALIZED VIEW SQL statement
    """
    concurrent_clause = "CONCURRENTLY " if concurrently else ""
    return f"REFRESH MATERIALIZED VIEW {concurrent_clause}{matview.full_name};"


# =============================================================================
# Sequence DDL
# =============================================================================


def generate_sequence_ddl(sequence: SequenceInfo) -> str:
    """
    Generate CREATE SEQUENCE statement.

    Args:
        sequence: SequenceInfo object with sequence metadata

    Returns:
        CREATE SEQUENCE SQL statement
    """
    return (
        f"CREATE SEQUENCE IF NOT EXISTS {sequence.full_name}\n"
        f"    AS {sequence.data_type}\n"
        f"    START WITH {sequence.start_value}\n"
        f"    INCREMENT BY {sequence.increment_by};"
    )


def generate_drop_sequence_ddl(sequence: SequenceInfo, if_exists: bool = True) -> str:
    """
    Generate DROP SEQUENCE statement.

    Args:
        sequence: SequenceInfo object with sequence metadata
        if_exists: Add IF EXISTS clause

    Returns:
        DROP SEQUENCE SQL statement
    """
    if_clause = "IF EXISTS " if if_exists else ""
    return f"DROP SEQUENCE {if_clause}{sequence.full_name};"


# =============================================================================
# Utility functions
# =============================================================================


def wrap_in_transaction(statements: list[str]) -> str:
    """
    Wrap multiple DDL statements in a transaction.

    Args:
        statements: List of SQL statements

    Returns:
        Transaction-wrapped SQL
    """
    return "BEGIN;\n\n" + "\n\n".join(statements) + "\n\nCOMMIT;"


def format_ddl_comment(message: str) -> str:
    """
    Format a comment for inclusion in DDL output.

    Args:
        message: Comment text

    Returns:
        SQL comment string
    """
    return f"-- {message}"
