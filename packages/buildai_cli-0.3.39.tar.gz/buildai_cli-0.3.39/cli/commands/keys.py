"""CLI commands for self-managed PATs (SDK-backed)."""

from __future__ import annotations

import typer

from cli.console import info, success, warning
from cli.guard import require_write
from cli.output import Format, format_option, output
from cli.sdk_client import get_internal_sdk_client

app = typer.Typer(
    name="keys",
    help="Personal access token management.",
    no_args_is_help=True,
)


@app.command("list")
def keys_list(
    include_revoked: bool = typer.Option(False, "--include-revoked", "-r"),
    format: Format | None = format_option(),
) -> None:
    """List personal access tokens."""
    client = get_internal_sdk_client()
    results = list(client.keys.iter(include_revoked=include_revoked))
    output(
        results,
        format=format,
        columns=["key_prefix", "name", "is_active", "last_used_at", "created_at"],
    )


@app.command("create")
def keys_create(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Name for the personal access token"),
    scope: list[str] | None = typer.Option(
        None,
        "--scope",
        "-s",
        help="Optional narrower subset. Omit to inherit the full template.",
    ),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Create a new personal access token."""
    if dry_run:
        subset = ", ".join(scope or []) or "<full-template>"
        info(f"Would create PAT '{name}' with subset={subset}")
        return

    require_write(ctx, "API key creation")
    client = get_internal_sdk_client()
    key = client.keys.create(name=name, scopes=scope)
    success(f"Created key: {key.key.key_prefix}...")
    warning("Save the raw token — it will not be shown again:")
    print(key.raw_key)


@app.command("revoke")
def keys_revoke(
    ctx: typer.Context,
    key_id: str = typer.Argument(..., help="Key UUID"),
    reason: str | None = typer.Option(None, "--reason", "-r"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Revoke a personal access token."""
    if dry_run:
        info(f"Would revoke key {key_id}")
        return

    require_write(ctx, "API key revocation")
    client = get_internal_sdk_client()
    client.keys.revoke(key_id, reason=reason)
    success(f"Revoked key {key_id}")
