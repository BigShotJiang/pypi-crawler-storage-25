"""The builtin to update firmware of the Elektroline boards."""

import asyncio
import collections.abc
import hashlib
import io
import json
import os
import pathlib
import platform
import time
import urllib.parse
import urllib.request

from packaging.version import Version
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completion, WordCompleter
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.shortcuts import CompleteStyle, ProgressBar, ProgressBarCounter
from shvcli import Builtin, Builtins, Client, CliItems, State, Tree
from shvcli.file import copy_file
from shvcli.options import ViModeOption
from shvcli.tools.complet import comp_path

CACHE_DIR: pathlib.Path
if _cache_dir_env := os.getenv("CACHEDIR"):
    CACHE_DIR = pathlib.Path(_cache_dir_env)
elif platform.system() == "Windows":
    CACHE_DIR = pathlib.Path(os.getenv("APPDATA") or "")
else:
    CACHE_DIR = pathlib.Path.home() / ".cache"
CACHE_DIR /= "ellembflasher"
OLDNESS = 300


class _BuiltinFwUpdate(Builtin):
    """Common implementation for both online and offline firmware update."""

    @property
    def _offline(self) -> bool:
        raise NotImplementedError

    @property
    def description(self) -> tuple[str, str]:
        return "[PATH]", "Update Elektroline EMB device firmware"

    def completion(
        self, items: CliItems, client: Client
    ) -> collections.abc.Iterable[Completion]:
        yield from comp_path(items.param, self.state.path, Tree(self.state), "")

    async def completion_async(
        self, items: CliItems, client: Client
    ) -> collections.abc.AsyncGenerator[Completion, None]:
        await client.probe(
            items.path_param if items.param.endswith("/") else items.path_param.parent
        )

        async for res in super().completion_async(items, client):
            yield res

    @staticmethod
    def _check_file(file: pathlib.Path, hsh: str) -> bool:
        """Check if given file is valid against given cache."""
        if not file.exists():
            return False
        with file.open("rb") as f:
            digest = hashlib.file_digest(f, "sha256")
        return digest.hexdigest() == hsh

    @classmethod
    def _fetch_file(
        cls, file: str, outpath: pathlib.Path, hsh: str | None = None
    ) -> None:
        """Peform fetch of given file."""
        if hsh is not None and cls._check_file(outpath, hsh):
            return  # File is cached so no need to fetch it again
        req = urllib.request.Request(
            "https://builds.elektroline.cz/firmware/download?"
            + urllib.parse.urlencode({"filename": file})
        )
        req.add_header(
            "X-Secure-Elektroline-Token", "nd0DrfGO-Mr4WksxdOINk0wBU6EP7JnPsqlND8FnCZU"
        )
        outpath.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(req) as src:  # noqa: S310
            with outpath.open("bw") as dfile:
                with patch_stdout():
                    with ProgressBar() as pb:
                        pbcnt: ProgressBarCounter = pb(label=file, total=100)
                        while data := src.read(io.DEFAULT_BUFFER_SIZE):
                            dfile.write(data)
                            pbcnt.items_completed += len(data)

    async def _fetch_index(self) -> dict[str, dict[str, dict[str, dict[str, str]]]]:
        """Fetch and read index file."""
        fpath = CACHE_DIR / "public-index.json"
        if self._offline:
            if not fpath.exists():
                print("Index not cached and can't be fetched in offline mode")
                return {}
        elif not fpath.exists() or fpath.stat().st_mtime + OLDNESS <= time.time():
            try:
                await asyncio.to_thread(self._fetch_file, "index.json", fpath)
            except Exception as exc:
                print(exc)
                return {}
        with fpath.open("r") as file:
            res = json.load(file)
        assert isinstance(res, dict)
        return res

    async def run(self, items: CliItems, client: Client) -> None:
        path = items.path_param
        name = str(await client.call(path / ".device", "name"))
        index = await self._fetch_index()
        if not index:
            return
        if name not in index:
            print(f"Board {name} is not supported!")
            return
        current_version = str(await client.call(path / ".app", "version"))
        print(
            f"{name} current version is {current_version}",
            "" if self._offline else ", checking available versions...",
        )
        versions = [
            v[1:]
            for v, files in index[name].items()
            if v[0] == "v"
            and "nuttx.nximg" in files
            and (
                not self._offline
                or self._check_file(
                    CACHE_DIR / f"{name}-{v}" / "nuttx.nximg",
                    files["nuttx.nximg"]["sha256"],
                )
            )
        ]
        if not versions:
            print("No supported versions are available")
            return
        versions.sort(key=Version, reverse=True)
        with patch_stdout():
            res: str = await PromptSession().prompt_async(
                [("ansibrightyellow", f"Select version [{versions[0]}]"), ("", "> ")],
                complete_style=CompleteStyle.MULTI_COLUMN,
                completer=WordCompleter(versions, sentence=True),
                vi_mode=bool(ViModeOption(client.state)),
            )
        res = res or versions[0]
        if res not in versions:
            print("No such version available")
            return

        finfo = index[name][f"v{res}"]["nuttx.nximg"]
        img = CACHE_DIR / f"{name}-v{res}" / "nuttx.nximg"
        try:
            await asyncio.to_thread(
                self._fetch_file,
                f"{name}/v{res}/{finfo['file']}",
                img,
                index[name][f"v{res}"]["nuttx.nximg"]["sha256"],
            )
        except Exception as exc:
            print(exc)
            return

        await copy_file(client, img, path / "fwUpdate", label=str(img))

        print(f"Firmware is loaded. Use {path / '.device'}:reset to reboot.")


class BuiltinFwUpdate(_BuiltinFwUpdate):
    """The builtin for firmware updating helper ``fwUpdate``."""

    def __init__(self, builtins: Builtins, state: State) -> None:
        super().__init__(builtins, state)
        builtins["fwUpdate"] = self

    @property
    def _offline(self) -> bool:
        return False


class BuiltinFwUpdateOffline(_BuiltinFwUpdate):
    """The builtin for firmware updating helper ``fwUpdateOffline``."""

    def __init__(self, builtins: Builtins, state: State) -> None:
        super().__init__(builtins, state)
        builtins["fwUpdateOffline"] = self

    @property
    def _offline(self) -> bool:
        return True

    @property
    def description(self) -> tuple[str, str]:  # noqa: D102
        attr, desc = super().description
        return attr, desc + " without accessing the Internet"
