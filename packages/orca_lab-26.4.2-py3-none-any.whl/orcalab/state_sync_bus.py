from enum import Enum
from orcalab.event_bus import create_event_bus


class ManipulatorType(Enum):
    Translate = 0
    Rotate = 1
    Scale = 2

class CameraMovementType(Enum):
    CameraTranslate = 0
    CameraRotate = 1
    CameraScale = 2
    CameraNone = 3

class MeasureType(Enum):
    Distance = 0
    Angle = 1
    MeasureNone = 2

class StateSyncRequest:
    async def set_manipulator_type(self, type: ManipulatorType):
        pass

    async def set_camera_movement_type(self, type: CameraMovementType):
        pass

    async def set_measure_type(self, type: MeasureType):
        pass

    async def set_debug_draw(self, enabled: bool):
        pass

    async def set_runtime_grab(self, enabled: bool):
        pass


StateSyncRequestBus = create_event_bus(StateSyncRequest)


class StateSyncNotification:

    def on_manipulator_type_changed(self, type: ManipulatorType):
        pass

    def on_camera_movement_type_changed(self, type: CameraMovementType):
        pass

    def on_measure_type_changed(self, type: MeasureType):
        pass

    def on_debug_draw_changed(self, enabled: bool):
        pass

    def on_runtime_grab_changed(self, enabled: bool):
        pass

StateSyncNotificationBus = create_event_bus(StateSyncNotification)
