"""
moneyfeel.client — MoneyFeel MRI Python Client
"""
from __future__ import annotations

import time
from datetime import datetime
from io import StringIO
from typing import Optional

import requests

from .exceptions import (
    MRIAuthError,
    MRIRateLimitError,
    MRINotFoundError,
    MRIClientError,
)

_BASE_URL = "https://api.moneyfeel.ai/v1"
_TIMEOUT  = 15


class MRI:
    """
    MoneyFeel Macro & Geopolitical Risk Index — Python Client.

    Parameters
    ----------
    api_key : str
        Your API key. Get one free at https://moneyfeel.it/account
    timeout : int
        Request timeout in seconds (default: 15)

    Examples
    --------
    >>> from moneyfeel import MRI
    >>> client = MRI("mf_live_YOUR_KEY")
    >>> current = client.current()
    >>> history = client.history("US", "WEEKLY", from_date="2020-01-01")
    >>> df = client.history_df("US", "WEEKLY")  # returns pandas DataFrame
    """

    BASE_URL = _BASE_URL

    def __init__(self, api_key: str, timeout: int = _TIMEOUT):
        if not api_key or not api_key.startswith("mf_live_"):
            raise ValueError(
                "Invalid API key. Keys start with 'mf_live_'. "
                "Get yours free at https://moneyfeel.it/account"
            )
        self._key     = api_key
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "User-Agent":    f"moneyfeel-mri-python/{_version()}",
        })

    # ── Private ───────────────────────────────────────────────────────────────

    def _get(self, path: str, params: dict = None, auth: bool = True) -> dict:
        headers = {} if auth else {"Authorization": ""}
        session = self._session if auth else requests.Session()
        try:
            r = session.get(
                f"{self.BASE_URL}{path}",
                params=params,
                timeout=self._timeout,
                headers=headers if not auth else None,
            )
        except requests.exceptions.Timeout:
            raise MRIClientError(f"Request timed out after {self._timeout}s")
        except requests.exceptions.ConnectionError as e:
            raise MRIClientError(f"Connection error: {e}")

        if r.status_code == 200:
            return r.json()
        if r.status_code == 401:
            raise MRIAuthError(r.json().get("message", "Unauthorized"))
        if r.status_code == 429:
            data        = r.json()
            retry_after = int(r.headers.get("Retry-After", 60))
            raise MRIRateLimitError(
                data.get("message", "Rate limit exceeded"),
                retry_after=retry_after,
            )
        if r.status_code == 404:
            raise MRINotFoundError(r.json().get("message", "Not found"))

        raise MRIClientError(
            f"HTTP {r.status_code}: {r.json().get('message', r.text[:200])}"
        )

    # ── Public endpoints (no auth) ────────────────────────────────────────────

    def status(self) -> dict:
        """
        Health check — no authentication required.

        Returns
        -------
        dict with keys: status, worker, version, ts
        """
        return requests.get(
            f"{self.BASE_URL}/status", timeout=self._timeout
        ).json()

    def regions(self) -> dict:
        """
        Returns available regions and timeframes.

        Returns
        -------
        dict with keys: regions, timeframes, coverage, updated
        """
        return requests.get(
            f"{self.BASE_URL}/regions", timeout=self._timeout
        ).json()

    def current(self) -> list[dict]:
        """
        Current regime for all 5 regions — no authentication required.

        Returns
        -------
        list of dicts, one per region. Each dict contains:
            region, regime_daily, regime_weekly, regime_monthly,
            score_daily, score_weekly, score_monthly,
            confidence_daily, confidence_weekly, confidence_monthly,
            days_in_weekly, days_in_monthly, updated_at

        Examples
        --------
        >>> regimes = client.current()
        >>> for r in regimes:
        ...     print(r["region"], r["regime_weekly"], r["score_weekly"])
        """
        data = requests.get(
            f"{self.BASE_URL}/current", timeout=self._timeout
        ).json()
        return data.get("data", [])

    # ── Authenticated endpoints ───────────────────────────────────────────────

    def history(
        self,
        region: str,
        tf: str = "WEEKLY",
        from_date: Optional[str] = None,
        to_date:   Optional[str] = None,
    ) -> list[dict]:
        """
        Historical regime classifications.

        Parameters
        ----------
        region : str
            One of: GLOBAL, US, EU, ASIA, EM
        tf : str
            Timeframe: DAILY, WEEKLY, MONTHLY (default: WEEKLY)
        from_date : str, optional
            Start date YYYY-MM-DD (default: 2007-01-01)
        to_date : str, optional
            End date YYYY-MM-DD (default: today)

        Returns
        -------
        list of dicts with fields:
            as_of_date, regime, regime_numeric, mri_score,
            prob_strong_bull, prob_bull, prob_neutral, prob_bear, prob_strong_bear,
            regime_confidence, days_in_regime, regime_changed

        Examples
        --------
        >>> data = client.history("US", "WEEKLY", from_date="2020-01-01")
        >>> print(data[-1])  # latest record
        """
        params = {"region": region.upper(), "tf": tf.upper()}
        if from_date: params["from"] = from_date
        if to_date:   params["to"]   = to_date
        return self._get("/history", params).get("data", [])

    def history_df(
        self,
        region: str,
        tf: str = "WEEKLY",
        from_date: Optional[str] = None,
        to_date:   Optional[str] = None,
    ):
        """
        Historical regime data as a pandas DataFrame.

        Requires pandas. Parses as_of_date as datetime automatically.

        Examples
        --------
        >>> df = client.history_df("US", "WEEKLY", from_date="2020-01-01")
        >>> df.set_index("as_of_date", inplace=True)
        >>> df["regime"].value_counts()
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError("pandas is required for history_df(). pip install pandas")
        rows = self.history(region, tf, from_date, to_date)
        df   = pd.DataFrame(rows)
        if "as_of_date" in df.columns:
            df["as_of_date"] = pd.to_datetime(df["as_of_date"])
        return df

    def latest(self, region: str, tf: str = "WEEKLY") -> dict:
        """
        Latest regime record for a region and timeframe.

        Parameters
        ----------
        region : str
        tf : str

        Returns
        -------
        dict with regime, mri_score, regime_confidence, as_of_date, etc.
        """
        return self._get("/regime/latest",
                         {"region": region.upper(), "tf": tf.upper()}).get("data", {})

    def metrics(
        self,
        region: Optional[str] = None,
        tf: str = "WEEKLY",
    ) -> list[dict]:
        """
        Strategy performance KPIs.

        Parameters
        ----------
        region : str, optional
            Filter by region. If None, returns all 5 regions.
        tf : str
            Timeframe (default: WEEKLY)

        Returns
        -------
        list of dicts with fields:
            region, timeframe, cagr_strategy, cagr_benchmark,
            sharpe, sortino, max_dd, volatility_ann, alpha,
            beta, win_month_pct, best_year, worst_year, ...

        Examples
        --------
        >>> m = client.metrics("US", "WEEKLY")[0]
        >>> print(f"Sharpe: {m['sharpe']} | MaxDD: {m['max_dd']}%")
        """
        params = {"tf": tf.upper()}
        if region:
            params["region"] = region.upper()
        return self._get("/metrics", params).get("data", [])

    def timeseries(
        self,
        region: str,
        tf: str = "WEEKLY",
        from_date: Optional[str] = None,
    ) -> list[dict]:
        """
        Daily strategy vs benchmark return series.

        Returns
        -------
        list of dicts with fields:
            as_of_date, bench_return, strategy_return, strategy_weight,
            cum_benchmark, cum_strategy, active_return, cum_outperform,
            rolling_vol_6m, rolling_sharpe_6m, rolling_beta_6m,
            drawdown_series, rf_rate
        """
        params = {"region": region.upper(), "tf": tf.upper()}
        if from_date: params["from"] = from_date
        return self._get("/timeseries", params).get("data", [])

    def timeseries_df(
        self,
        region: str,
        tf: str = "WEEKLY",
        from_date: Optional[str] = None,
    ):
        """
        Strategy vs benchmark timeseries as a pandas DataFrame.
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError("pandas is required. pip install pandas")
        rows = self.timeseries(region, tf, from_date)
        df   = pd.DataFrame(rows)
        if "as_of_date" in df.columns:
            df["as_of_date"] = pd.to_datetime(df["as_of_date"])
        return df

    def eoy(self, region: str, tf: str = "WEEKLY") -> list[dict]:
        """
        Year-by-year return comparison (strategy vs benchmark).

        Returns
        -------
        list of dicts: year, benchmark_ret, strategy_ret, won
        """
        return self._get("/eoy",
                         {"region": region.upper(), "tf": tf.upper()}).get("data", [])

    def drawdowns(self, region: str, tf: str = "WEEKLY") -> list[dict]:
        """
        Top 10 drawdown periods.

        Returns
        -------
        list of dicts: rank, started, recovered, drawdown_pct, days
        """
        return self._get("/drawdowns",
                         {"region": region.upper(), "tf": tf.upper()}).get("data", [])

    def download(
        self,
        region: str,
        tf: str = "WEEKLY",
        output_path: Optional[str] = None,
    ):
        """
        Download full dataset as CSV or pandas DataFrame.

        Parameters
        ----------
        region : str
        tf : str
        output_path : str, optional
            If provided, saves CSV to this path and returns the path.
            If None, returns a pandas DataFrame.

        Examples
        --------
        >>> df = client.download("US", "WEEKLY")           # DataFrame
        >>> client.download("US", "WEEKLY", "us_weekly.csv")  # save to file
        """
        r = self._session.get(
            f"{self.BASE_URL}/download",
            params={"region": region.upper(), "tf": tf.upper()},
            timeout=60,
        )
        if r.status_code != 200:
            raise MRIClientError(f"Download failed: HTTP {r.status_code}")

        if output_path:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(r.text)
            return output_path

        try:
            import pandas as pd
        except ImportError:
            raise ImportError("pandas is required for DataFrame output. pip install pandas")

        lines = [l for l in r.text.splitlines() if not l.startswith("#")]
        return pd.read_csv(StringIO("\n".join(lines)))

    # ── Convenience ───────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"MRI(key={self._key[:12]}..., base_url={self.BASE_URL})"


def _version() -> str:
    try:
        from importlib.metadata import version
        return version("moneyfeel-mri")
    except Exception:
        return "unknown"
