"""
moneyfeel — MoneyFeel MRI Python Client

Free access to the MoneyFeel Macro & Geopolitical Risk Index.
5 regions · 3 timeframes · 2007 to present · Updated daily.

Quick start:
    pip install moneyfeel-mri

    from moneyfeel import MRI
    client = MRI("mf_live_YOUR_KEY")

    current = client.current()
    history = client.history_df("US", "WEEKLY", from_date="2020-01-01")

Get your free API key at: https://moneyfeel.it/account
Documentation:           https://github.com/moneyfeel-io/mri-api
"""

from .client     import MRI
from .exceptions import (
    MRIError,
    MRIAuthError,
    MRIRateLimitError,
    MRINotFoundError,
    MRIClientError,
)

__all__ = [
    "MRI",
    "MRIError",
    "MRIAuthError",
    "MRIRateLimitError",
    "MRINotFoundError",
    "MRIClientError",
]

__version__ = "1.0.0"
__author__  = "moneyfeel"
__url__     = "https://moneyfeel.it"
