"""
moneyfeel.exceptions — Custom exceptions for the MRI client.
"""


class MRIError(Exception):
    """Base exception for all MRI client errors."""


class MRIAuthError(MRIError):
    """Raised when the API key is missing, invalid or revoked."""


class MRIRateLimitError(MRIError):
    """Raised when rate limit or daily quota is exceeded."""

    def __init__(self, message: str, retry_after: int = 60):
        super().__init__(message)
        self.retry_after = retry_after


class MRINotFoundError(MRIError):
    """Raised when the requested resource does not exist."""


class MRIClientError(MRIError):
    """Raised for generic HTTP or connection errors."""
