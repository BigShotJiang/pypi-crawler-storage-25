﻿from moneyfeel import MRI

print("Import OK")

client = MRI("mf_live_TEST_KEY")
print("Client OK:", client)