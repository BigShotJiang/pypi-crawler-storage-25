"""Tests for auto_diagnose tool — P1 Free tier mode + module router.

Hybrid heuristics + structured frame approach (option C):
- Strong signals (FR + EN keywords) score the 4 modes.
- Gap >= 2 between top-1 and top-2 → confidence "high".
- Otherwise → confidence "medium" + disambiguation_questions.
- Empty input → return the 5-question framing directly.
"""

from __future__ import annotations

from artefact_mcp.resources.formula import auto_diagnose


# --- Happy path: one strong-signal case per mode (4 tests) ---


def test_self_serve_solo_founder_french():
    """Solo founder, free, exploratory — Self-Serve."""
    ctx = "Je suis fondateur solo d'une startup SaaS. Je veux essayer gratuit pour voir."
    result = auto_diagnose(ctx)
    assert result["mode"] == "Self-Serve"
    assert result["confidence"] == "high"
    assert result["starting_module"] == "FOND-1"


def test_poc_4_weeks_validation_french():
    """4-week POC validation — POC mode."""
    ctx = "On veut un POC sur 4 semaines pour valider la valeur avant de s'engager."
    result = auto_diagnose(ctx)
    assert result["mode"] == "POC"
    assert result["confidence"] == "high"
    assert result["starting_module"] == "POC-1"


def test_diy_no_bandwidth_french():
    """VP Ops, 50 employees, sponsor wants deliverable, no bandwidth — DIY."""
    ctx = (
        "VP Ops, équipe de 50 personnes en M365. Le sponsor veut un livrable, "
        "pas de bandwidth pour co-construire. On veut être reviewer."
    )
    result = auto_diagnose(ctx)
    assert result["mode"] == "DIY"
    assert result["confidence"] == "high"
    assert result["starting_module"] == "DIY-1"


def test_co_build_pilot_motivated_french():
    """Pilot 5-8h/week, sponsor exec, autonomy goal — Co-Build."""
    ctx = (
        "Pilote disponible 5 à 8 heures par semaine, motivé pour apprendre. "
        "Sponsor exécutif veut autonomie après 8 à 12 semaines."
    )
    result = auto_diagnose(ctx)
    assert result["mode"] == "Co-Build"
    assert result["confidence"] == "high"
    assert result["starting_module"] == "FOND-1"
    assert "ARC-1" in result["parallel_modules"]


# --- English variants (2 tests) ---


def test_poc_english():
    ctx = "We want a proof of concept in 4 weeks to test the value before committing."
    result = auto_diagnose(ctx)
    assert result["mode"] == "POC"
    assert result["confidence"] == "high"


def test_diy_english():
    ctx = (
        "Sponsor wants the work done for them. No bandwidth on our side. "
        "We just want to be reviewers on the deliverable."
    )
    result = auto_diagnose(ctx)
    assert result["mode"] == "DIY"


# --- Edge cases ---


def test_empty_input_returns_framing_questions():
    """No context → return the structured frame, not a guessed mode."""
    result = auto_diagnose("")
    assert result["mode"] is None
    assert result["confidence"] == "framing"
    assert len(result["disambiguation_questions"]) >= 4


def test_ambiguous_input_returns_medium_confidence():
    """Mixed signals (POC + Co-Build words) → medium confidence + alternatives."""
    ctx = "Pilote motivé pour apprendre, mais on veut tester rapidement la valeur."
    result = auto_diagnose(ctx)
    assert result["confidence"] == "medium"
    assert len(result["alternatives"]) >= 1
    assert len(result["disambiguation_questions"]) >= 1


def test_archetype_hint_loi_25():
    """Loi 25 keyword surfaces archetype A hint."""
    ctx = "Organisme public sous Loi 25 stricte, fondateur solo qui veut essayer."
    result = auto_diagnose(ctx)
    assert result.get("archetype_hint") == "A"


def test_archetype_hint_microsoft_365():
    """M365-heavy → archetype C hint."""
    ctx = "PME industrielle 100% Microsoft 365, sponsor veut livrable, équipe de 50."
    result = auto_diagnose(ctx)
    assert result.get("archetype_hint") == "C"


# --- Structural / contract tests ---


def test_output_shape_is_stable():
    """All required keys present in every successful response."""
    result = auto_diagnose("Je suis fondateur solo, je veux tester gratuit.")
    required_keys = {
        "mode",
        "confidence",
        "reasoning",
        "starting_module",
        "parallel_modules",
        "next_module_after_starting",
        "alternatives",
        "disambiguation_questions",
        "signals_detected",
    }
    assert required_keys.issubset(set(result.keys()))


def test_starting_module_matches_mode():
    """Module mapping is deterministic given the chosen mode."""
    cases = [
        ("Je suis fondateur solo, je veux essayer gratuit.", "FOND-1"),
        ("POC sur 4 semaines pour valider.", "POC-1"),
        ("Pas de bandwidth, sponsor veut livrable, équipe 50.", "DIY-1"),
        ("Pilote 5-8h/sem motivé pour apprendre, autonomie après.", "FOND-1"),
    ]
    for ctx, expected in cases:
        result = auto_diagnose(ctx)
        assert result["starting_module"] == expected, f"Failed for: {ctx}"


def test_signals_detected_cites_keywords():
    """Reasoning cites the actual keywords found (transparent, not magic)."""
    ctx = "POC sur 4 semaines."
    result = auto_diagnose(ctx)
    assert len(result["signals_detected"]) >= 1
    # At least one signal should reference the input substring
    joined = " ".join(s.get("keyword", "") for s in result["signals_detected"]).lower()
    assert "poc" in joined or "4 semaines" in joined or "weeks" in joined


# --- Patches from Gemini cross-validate (May 5 2026) ---


def test_negation_drops_co_construire_signal():
    """Gemini case 3: 'pas de bandwidth pour co-construire' must NOT award
    Co-Build the 'co-construire' signal — negation must drop the hit."""
    ctx = "Le sponsor veut un livrable. Pas de bandwidth pour co-construire."
    result = auto_diagnose(ctx)
    assert result["mode"] == "DIY"
    keywords = [s["keyword"] for s in result["signals_detected"]]
    assert "co-construire" not in keywords, (
        "Negation handling regression: 'co-construire' was kept despite "
        "being preceded by 'pas de bandwidth pour'."
    )


def test_negation_english_dont_have_time():
    """English negation: 'we don't have time' should not falsely trigger
    a positive 'time' bias."""
    ctx = "We do not have time to learn the system. Sponsor wants outputs."
    result = auto_diagnose(ctx)
    assert result["mode"] == "DIY"


def test_low_absolute_scores_with_gap_2_is_medium():
    """Gemini case 7: gap=2 with low absolute scores (e.g. 5 vs 3) is
    qualitatively ambiguous and must report medium confidence — not high."""
    ctx = "Pilote motivé pour apprendre, mais on veut aussi tester rapidement la valeur en 4 semaines."
    result = auto_diagnose(ctx)
    assert result["confidence"] == "medium", (
        f"Expected medium confidence on low-score gap=2 ambiguity. "
        f"Got: {result['confidence']} with signals_detected={result['signals_detected']}"
    )
    assert len(result["disambiguation_questions"]) >= 1


def test_high_confidence_requires_gap_3_or_strong_signal():
    """High confidence is reserved for unambiguous cases — gap>=3 or
    (gap>=2 AND top_score>=6)."""
    # Strong unambiguous Co-Build (Pierre-Luc Bixi pattern)
    ctx = (
        "Pilote disponible 5 à 8 heures par semaine, motivé pour apprendre. "
        "Sponsor exécutif veut autonomie de l'équipe après 8 à 12 semaines. "
        "On veut co-construire le système."
    )
    result = auto_diagnose(ctx)
    assert result["confidence"] == "high"


def test_willing_to_learn_kicks_co_build_score():
    """Gemini gap: 'willing to learn' is now a Co-Build keyword."""
    ctx = "Pilot is willing to learn alongside us. Sponsor wants outputs fast."
    result = auto_diagnose(ctx)
    # Should at least surface Co-Build in alternatives or as the top
    modes_seen = [result["mode"]] + [a["mode"] for a in result["alternatives"]]
    assert "Co-Build" in modes_seen


def test_4_to_6_weeks_kicks_diy_score():
    """Gemini gap: 4-6 weeks is now a DIY hint."""
    ctx = "We want this delivered in 4-6 weeks, sponsor wants outputs fast."
    result = auto_diagnose(ctx)
    assert result["mode"] == "DIY"
