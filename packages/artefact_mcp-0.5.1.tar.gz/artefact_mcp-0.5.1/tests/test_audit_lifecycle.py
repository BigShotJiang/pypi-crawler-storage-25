"""Tests for audit_lifecycle_stages (v0.5.0 Free tier audit tool)."""

from datetime import datetime, timezone

import pytest

from artefact_mcp.tools.audit_lifecycle import (
    audit_lifecycle_stages,
    _detect_orphans,
    _stage_age_distribution,
    _generate_recommendations,
    LIFECYCLE_CONCEPT_EXPLAINER,
)


# --- Sample-data path (deterministic) -----------------------------------------

class TestSampleDataPath:
    """Verifies the built-in fixture produces stable, expected output."""

    def test_returns_dict(self):
        result = audit_lifecycle_stages(source="sample")
        assert isinstance(result, dict)

    def test_total_contacts_30(self):
        result = audit_lifecycle_stages(source="sample")
        assert result["total_contacts"] == 30

    def test_stage_counts_match_fixture(self):
        result = audit_lifecycle_stages(source="sample")
        # Fixture distribution: 5 subscriber + 8 lead + 6 MQL + 5 SQL + 4 opp + 2 customer
        assert result["stage_counts"]["Subscriber"] == 5
        assert result["stage_counts"]["Lead"] == 8
        assert result["stage_counts"]["MQL"] == 6
        assert result["stage_counts"]["SQL"] == 5
        assert result["stage_counts"]["Opportunity"] == 4
        assert result["stage_counts"]["Customer"] == 2
        assert result["stage_counts"]["Other"] == 0

    def test_orphans_detected(self):
        result = audit_lifecycle_stages(source="sample")
        # Fixture surfaces 4 orphans:
        # - C016, C017 (MQL with no Lead date)
        # - C022 (SQL with no MQL date)
        # - C023 (SQL with no Lead date — promoted past MQL with Lead missing)
        assert result["orphan_count"] == 4
        ids = {o["contact_id"] for o in result["orphans_sample"]}
        assert ids == {"C016", "C017", "C022", "C023"}

    def test_orphan_rate_pct(self):
        result = audit_lifecycle_stages(source="sample")
        # 4 / 30 = 13.3%
        assert result["orphan_rate_pct"] == pytest.approx(13.3, abs=0.1)

    def test_age_distribution_present_for_each_stage(self):
        result = audit_lifecycle_stages(source="sample")
        dist = result["stage_age_distribution"]
        # All 6 occupied stages should appear
        for label in ("Subscriber", "Lead", "MQL", "SQL", "Opportunity", "Customer"):
            assert label in dist
            assert dist[label]["count"] > 0
            assert dist[label]["median_days"] >= 0
            assert dist[label]["max_days"] >= dist[label]["min_days"]

    def test_concept_explainer_included(self):
        result = audit_lifecycle_stages(source="sample")
        assert "lifecycle_concept" in result
        assert "Lead vs" in result["lifecycle_concept"] or "Lifecycle stage vs" in result["lifecycle_concept"]
        # Per Syeda's audit content recommendation: explainer surfaces "lead vs lifecycle"
        assert "lifecyclestage" in result["lifecycle_concept"].lower() or "lifecycle" in result["lifecycle_concept"].lower()

    def test_recommendations_capped_at_5(self):
        result = audit_lifecycle_stages(source="sample")
        assert len(result["recommendations"]) <= 5

    def test_recommendations_have_required_fields(self):
        result = audit_lifecycle_stages(source="sample")
        for rec in result["recommendations"]:
            assert "priority" in rec
            assert "finding" in rec
            assert "action" in rec
            assert rec["priority"] in ("high", "medium", "low")


# --- Edge cases ---------------------------------------------------------------

class TestEdgeCases:
    """PRD: tests cover empty data, single-stage drift, missing properties, deletion in flight."""

    def test_empty_data_path(self, monkeypatch):
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_lifecycle.sample_contacts",
            lambda: [],
        )
        result = audit_lifecycle_stages(source="sample")
        assert result["total_contacts"] == 0
        assert result["stage_counts"] == {}
        assert result["orphan_count"] == 0
        assert result["orphan_rate_pct"] == 0.0
        assert result["recommendations"] == []
        # Explainer always present, even on empty data
        assert "lifecycle_concept" in result

    def test_single_stage_drift(self):
        """All contacts in the same stage — no orphans, distribution still computes."""
        contacts = [
            {"id": f"X{i}", "properties": {
                "lifecyclestage": "lead",
                "hs_lifecyclestage_lead_date": "2026-04-01T10:00:00Z",
            }}
            for i in range(10)
        ]
        orphans = _detect_orphans(contacts)
        assert orphans == []

        now = datetime(2026, 5, 8, tzinfo=timezone.utc)
        dist = _stage_age_distribution(contacts, now)
        assert dist["Lead"]["count"] == 10
        # 2026-04-01T10:00 UTC → 2026-05-08T00:00 UTC = 36 full days (timedelta.days truncates)
        assert dist["Lead"]["median_days"] == 36

    def test_missing_properties_object(self):
        """Contact returned with no properties dict at all — must not crash."""
        contacts = [{"id": "X1"}]  # No 'properties' key
        orphans = _detect_orphans(contacts)
        assert orphans == []
        now = datetime(2026, 5, 8, tzinfo=timezone.utc)
        dist = _stage_age_distribution(contacts, now)
        assert dist == {}

    def test_unknown_lifecycle_stage_bucketed_as_other(self):
        """Custom lifecycle stage values land in 'Other' bucket."""
        # Use the real audit_lifecycle_stages with a monkeypatched fixture
        contacts = [
            {"id": "X1", "properties": {"lifecyclestage": "weirdcustomstage"}},
            {"id": "X2", "properties": {"lifecyclestage": "lead", "hs_lifecyclestage_lead_date": "2026-04-01T10:00:00Z"}},
        ]
        # Use _detect_orphans + manual count to verify pure logic
        orphans = _detect_orphans(contacts)
        assert orphans == []  # 'weirdcustomstage' isn't in LIFECYCLE_ORDER, skipped

    def test_deletion_in_flight_returns_partial(self):
        """If a contact is deleted mid-fetch and the API returns a partial record,
        the audit should still produce a result (no crash)."""
        contacts = [
            {"id": "X1", "properties": {"lifecyclestage": "lead", "hs_lifecyclestage_lead_date": "2026-04-01T10:00:00Z"}},
            {"id": "X2", "properties": {}},  # Mid-deletion: properties exists but empty
            {"id": "X3"},  # Mid-deletion: no properties at all
        ]
        orphans = _detect_orphans(contacts)
        assert orphans == []

    def test_malformed_date_does_not_crash_age_distribution(self):
        contacts = [
            {"id": "X1", "properties": {
                "lifecyclestage": "lead",
                "hs_lifecyclestage_lead_date": "not-a-date",
            }},
            {"id": "X2", "properties": {
                "lifecyclestage": "lead",
                "hs_lifecyclestage_lead_date": "2026-04-01T10:00:00Z",
            }},
        ]
        now = datetime(2026, 5, 8, tzinfo=timezone.utc)
        dist = _stage_age_distribution(contacts, now)
        assert dist["Lead"]["count"] == 1  # Only the valid one was counted

    def test_invalid_source_raises(self):
        with pytest.raises(ValueError, match="Invalid source"):
            audit_lifecycle_stages(source="banana")

    def test_hubspot_source_without_client_raises(self):
        with pytest.raises(ValueError, match="HubSpot client required"):
            audit_lifecycle_stages(source="hubspot")


# --- Pipeline_id reservation --------------------------------------------------

class TestPipelineIdReserved:
    def test_pipeline_id_surfaced_in_notes(self):
        result = audit_lifecycle_stages(source="sample", pipeline_id="default")
        assert any("pipeline_id" in n for n in result.get("notes", []))


# --- Truncation flag (Gemini cross-review fix) -------------------------------

class TestTruncation:
    def test_sample_path_data_truncated_false(self):
        result = audit_lifecycle_stages(source="sample")
        assert result["data_truncated"] is False

    def test_truncation_warning_propagated_from_client(self):
        """If the HubSpot client signals truncation via last_fetch_meta,
        the audit response surfaces a warning note and data_truncated=True."""

        class FakeTruncatedClient:
            def __init__(self):
                self.last_fetch_meta = {
                    "truncated": True,
                    "pages_fetched": 500,
                    "max_pages": 500,
                    "records_returned": 50000,
                }

            def fetch_contacts_with_lifecycle(self):
                # Return one minimal contact so we hit the populated-data path
                return [{"id": "T1", "properties": {"lifecyclestage": "lead",
                         "hs_lifecyclestage_lead_date": "2026-04-01T10:00:00Z"}}]

            def close(self):
                pass

        result = audit_lifecycle_stages(
            source="hubspot", hubspot_client=FakeTruncatedClient()
        )
        assert result["data_truncated"] is True
        assert any("WARNING" in n and "partial" in n.lower() for n in result["notes"])


# --- Explainer string ---------------------------------------------------------

class TestExplainer:
    def test_explainer_addresses_syeda_audit_concept(self):
        # Per Syeda's audit: educational opportunity around "lead vs lifecycle confusion"
        text = LIFECYCLE_CONCEPT_EXPLAINER.lower()
        assert "lifecycle" in text
        assert "lead" in text
