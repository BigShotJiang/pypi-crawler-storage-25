"""Tests for gate_check tool — P1 Free tier module gate validator.

Hybrid (option C):
- Empty input → framing + list of modules with gates
- module_id only → checklist (gate_status="pending"), all evidence_provided=false
- module_id + evidence (list or dict) → pass/fail with next_module
"""

from __future__ import annotations

import json

from artefact_mcp.resources.formula import gate_check, parse_gate, get_module


# --- Empty / framing ---


def test_empty_input_returns_framing():
    result = gate_check("", "")
    assert result["gate_status"] == "framing"
    assert "modules_with_gates" in result
    assert len(result["modules_with_gates"]) >= 30  # 34 modules all have gates
    assert "FOND-1" in result["modules_with_gates"]


# --- Invalid module ---


def test_unknown_module_returns_error():
    result = gate_check("XYZ-99", "")
    assert "error" in result


def test_invalid_evidence_json_returns_error():
    result = gate_check("FOND-1", "{not json")
    assert "error" in result


# --- Pending state (module_id only) ---


def test_pending_state_no_evidence():
    result = gate_check("FOND-1", "")
    assert result["gate_status"] == "pending"
    assert result["module_id"] == "FOND-1"
    assert len(result["gate_items"]) == 4
    for item in result["gate_items"]:
        assert item["evidence_provided"] is False
        assert item["passes"] is False


# --- Pass / partial / fail evaluation ---


def test_all_true_evidence_returns_pass():
    """List of bools — all True → status=pass, advancement allowed."""
    evidence = json.dumps([True, True, True, True])
    result = gate_check("FOND-1", evidence)
    assert result["gate_status"] == "pass"
    assert result["items_passed"] == 4
    assert result["items_total"] == 4
    assert result["advancement_blocked"] is False
    assert result["next_module"] is not None


def test_all_false_evidence_returns_fail():
    evidence = json.dumps([False, False, False, False])
    result = gate_check("FOND-1", evidence)
    assert result["gate_status"] == "fail"
    assert result["items_passed"] == 0
    assert result["advancement_blocked"] is True
    assert len(result["blocking_failures"]) == 4


def test_partial_evidence_returns_partial():
    """Some True, some missing (None or absent) → partial."""
    evidence = json.dumps([True, True, None, None])
    result = gate_check("FOND-1", evidence)
    assert result["gate_status"] == "partial"
    assert result["items_passed"] == 2
    assert len(result["missing_evidence"]) == 2


# --- Evidence formats ---


def test_dict_evidence_keyed_by_index():
    """Evidence as {"1": true, "2": true, ...} (1-indexed)."""
    evidence = json.dumps({"1": True, "2": True, "3": True, "4": True})
    result = gate_check("FOND-1", evidence)
    assert result["gate_status"] == "pass"


def test_string_evidence_counts_as_pass():
    """Non-empty string evidence → counts as pass with proof."""
    evidence = json.dumps([
        "Bixi — Mobilité urbaine",
        "Directeur Marketing",
        "3 KPIs validés en kickoff",
        "~/.claude/skills/ confirmé",
    ])
    result = gate_check("FOND-1", evidence)
    assert result["gate_status"] == "pass"
    assert result["gate_items"][0]["evidence_value"] == "Bixi — Mobilité urbaine"


def test_negative_string_evidence_counts_as_fail():
    """String containing 'non' / 'no' / 'pas encore' → fail, not pass."""
    evidence = json.dumps([
        True,
        "non, pas encore validé",
        True,
        True,
    ])
    result = gate_check("FOND-1", evidence)
    assert result["gate_status"] == "fail"
    assert 2 in result["blocking_failures"]


# --- Output shape ---


def test_output_shape_is_stable():
    result = gate_check("FOND-1", "")
    required_keys = {
        "module_id",
        "module_title",
        "gate_status",
        "gate_items",
        "items_passed",
        "items_total",
        "blocking_failures",
        "missing_evidence",
        "next_module",
        "advancement_blocked",
        "guidance",
    }
    assert required_keys.issubset(set(result.keys()))


# --- parse_gate helper ---


def test_parse_gate_returns_items_for_all_34_modules():
    """Sanity: every module has a parseable gate."""
    from artefact_mcp.resources.formula import _modules_payload
    failures = []
    for module in _modules_payload()["modules"]:
        items = parse_gate(module)
        if not items:
            failures.append(module["id"])
    assert failures == [], f"Modules with no parseable gate: {failures}"


def test_parse_gate_arc_1_has_6_items():
    """ARC-1 is the canonical 6-item gate (archetype decision)."""
    module = get_module("ARC-1")
    items = parse_gate(module)
    assert len(items) == 6
    # First item should mention archetype
    assert "archétype" in items[0]["label"].lower() or "archetype" in items[0]["label"].lower()


# --- Patches from Gemini cross-validate (May 5 2026) ---


def test_extended_negative_tokens_fr():
    """Gemini patch: 'en attente', 'à faire', 'rejeté', 'bloqué' all count as fail."""
    cases = [
        "En attente du sponsor",
        "À faire après le kickoff",
        "Bloqué par DTI client",
        "Refusé par legal",
    ]
    for ev_text in cases:
        evidence = json.dumps([ev_text, True, True, True])
        result = gate_check("FOND-1", evidence)
        assert result["gate_status"] == "fail", f"Expected fail for '{ev_text}'"
        assert 1 in result["blocking_failures"]


def test_extended_negative_tokens_en():
    """Gemini patch: 'pending', 'in progress', 'on hold', 'blocked' count as fail."""
    cases = ["Pending review", "In progress", "On hold", "Blocked by client IT"]
    for ev_text in cases:
        evidence = json.dumps([True, ev_text, True, True])
        result = gate_check("FOND-1", evidence)
        assert result["gate_status"] == "fail", f"Expected fail for '{ev_text}'"


def test_n_est_pas_negation_caught():
    """Gemini patch: 'n'est pas' / 'n'a pas' detected as negation."""
    evidence = json.dumps([True, "Le sponsor n'est pas disponible", True, True])
    result = gate_check("FOND-1", evidence)
    assert result["gate_status"] == "fail"


def test_terminal_module_returns_no_invalid_next():
    """Gemini patch: POC-4 is the last in the POC family. Passing the gate
    should NOT suggest a non-existent POC-5."""
    # POC-4 has 4 items
    evidence = json.dumps([True, True, True, True])
    result = gate_check("POC-4", evidence)
    assert result["gate_status"] == "pass"
    # next_module should either be None or a real module ID, not "POC-5"
    nm = result["next_module"]
    if nm is not None:
        # Get all module IDs
        from artefact_mcp.resources.formula import _modules_payload
        catalog = {m["id"] for m in _modules_payload()["modules"]}
        assert nm in catalog, f"next_module '{nm}' is not in the catalog"
