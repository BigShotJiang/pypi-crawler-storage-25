"""Tests for generate_claude_md tool — P1 Free tier CLAUDE.md scaffolder.

Hybrid (option D):
- Empty input → return raw template, completeness="template"
- Partial dict → render with markers + missing_required_fields populated
- Complete dict → clean render, completeness="complete"
- Invalid JSON → error JSON returned (does not raise)
- KPI validation: warn if no target/frequency, warn if >3 KPIs
- Length budget: warn if outside 80-150 lines
- Always returns qa_gate_questions + next_module
"""

from __future__ import annotations

import json

from artefact_mcp.resources.formula import generate_claude_md


# --- Empty / template path ---


def test_empty_input_returns_template():
    result = generate_claude_md("")
    assert result["completeness"] == "template"
    assert "{{CLIENT}}" in result["rendered_markdown"]
    assert "{{PILOTE_PRENOM}}" in result["rendered_markdown"]
    assert len(result["missing_required_fields"]) >= 1


def test_invalid_json_returns_error():
    result = generate_claude_md("{not valid json")
    assert "error" in result


# --- Required vs optional ---


def test_required_fields_only_completeness_complete():
    """Minimum viable input — all required fields → completeness=complete."""
    fields = json.dumps({
        "client_name": "Bixi",
        "pilot": {"first_name": "Pierre-Luc", "role": "Directeur Marketing"},
        "function": "Marketing",
        "kpis": [
            {"name": "Taux conversion lead → opp", "target": "18%", "frequency": "mensuelle"},
        ],
    })
    result = generate_claude_md(fields)
    assert result["completeness"] == "complete"
    assert result["missing_required_fields"] == []
    assert "Bixi" in result["rendered_markdown"]
    assert "Pierre-Luc" in result["rendered_markdown"]
    assert "Marketing" in result["rendered_markdown"]


def test_partial_input_marks_completeness_partial():
    fields = json.dumps({
        "client_name": "Bixi",
        # missing pilot, function, kpis
    })
    result = generate_claude_md(fields)
    assert result["completeness"] == "partial"
    assert "pilot.first_name" in result["missing_required_fields"]
    assert "function" in result["missing_required_fields"]
    assert "kpis" in result["missing_required_fields"]


# --- Validation: KPIs ---


def test_kpi_without_target_emits_warning():
    fields = json.dumps({
        "client_name": "Bixi",
        "pilot": {"first_name": "Pierre-Luc", "role": "DM"},
        "function": "Marketing",
        "kpis": [
            {"name": "Augmenter la visibilité"},  # no target, no frequency
        ],
    })
    result = generate_claude_md(fields)
    warning_text = " ".join(result["warnings"]).lower()
    assert "kpi" in warning_text
    assert "theme" in warning_text or "measurable" in warning_text


def test_more_than_3_kpis_emits_warning():
    fields = json.dumps({
        "client_name": "Bixi",
        "pilot": {"first_name": "Pierre-Luc", "role": "DM"},
        "function": "Marketing",
        "kpis": [
            {"name": "K1", "target": "X", "frequency": "M"},
            {"name": "K2", "target": "X", "frequency": "M"},
            {"name": "K3", "target": "X", "frequency": "M"},
            {"name": "K4", "target": "X", "frequency": "M"},
        ],
    })
    result = generate_claude_md(fields)
    warning_text = " ".join(result["warnings"]).lower()
    assert "max 3" in warning_text or "maximum" in warning_text


def test_3_complete_kpis_no_warning_about_kpis():
    fields = json.dumps({
        "client_name": "Bixi",
        "pilot": {"first_name": "Pierre-Luc", "role": "DM"},
        "function": "Marketing",
        "kpis": [
            {"name": "K1", "target": "18%", "frequency": "mensuelle"},
            {"name": "K2", "target": "+10%", "frequency": "trimestrielle"},
            {"name": "K3", "target": "5", "frequency": "hebdo"},
        ],
    })
    result = generate_claude_md(fields)
    kpi_warnings = [w for w in result["warnings"] if "kpi" in w.lower()]
    assert kpi_warnings == []


# --- Output structure ---


def test_output_shape_is_stable():
    result = generate_claude_md("")
    required_keys = {
        "rendered_markdown",
        "completeness",
        "missing_required_fields",
        "missing_recommended_fields",
        "warnings",
        "qa_gate_questions",
        "next_module",
    }
    assert required_keys.issubset(set(result.keys()))


def test_qa_gate_questions_always_present():
    result = generate_claude_md("")
    assert len(result["qa_gate_questions"]) == 4
    joined = " ".join(result["qa_gate_questions"]).lower()
    assert "client" in joined
    assert "kpi" in joined or "kpis" in joined
    assert "skill" in joined


def test_next_module_points_to_fond_2():
    result = generate_claude_md("")
    assert "FOND-2" in result["next_module"]


def test_rendered_contains_all_5_section_headers():
    fields = json.dumps({
        "client_name": "Bixi",
        "pilot": {"first_name": "Pierre-Luc", "role": "DM"},
        "function": "Marketing",
        "kpis": [{"name": "K1", "target": "18%", "frequency": "mensuelle"}],
    })
    result = generate_claude_md(fields)
    md = result["rendered_markdown"]
    assert "## 1. Identité" in md
    assert "## 2. Business context" in md
    assert "## 3. Équipe" in md
    assert "## 4. KPIs prioritaires" in md
    assert "## 5. Workflow defaults" in md


def test_length_status_under_target_for_minimal_input():
    """Gemini patch: length_status field surfaces under_target / ok / over_target
    so the agent can decide whether to ask the pilot for more detail."""
    fields = json.dumps({
        "client_name": "Bixi",
        "pilot": {"first_name": "Pierre-Luc", "role": "DM"},
        "function": "Marketing",
        "kpis": [{"name": "K1", "target": "18%", "frequency": "mensuelle"}],
    })
    result = generate_claude_md(fields)
    assert result["length_status"] == "under_target"
    assert "line_count" in result
    assert result["line_count"] < 80


def test_clarified_plan_mode_first_jargon():
    """Gemini patch: 'plan-mode-first' jargon is now annotated inline."""
    result = generate_claude_md("")
    md = result["rendered_markdown"]
    assert "proposer un plan détaillé avant exécution" in md


def test_linked_project_mds_rendered_when_provided():
    fields = json.dumps({
        "client_name": "Bixi",
        "pilot": {"first_name": "Pierre-Luc", "role": "DM"},
        "function": "Marketing",
        "kpis": [{"name": "K1", "target": "18%", "frequency": "mensuelle"}],
        "linked_project_mds": ["produit", "fonction-marketing", "workflow-campaign"],
    })
    result = generate_claude_md(fields)
    md = result["rendered_markdown"]
    assert "CLAUDE-produit.md" in md
    assert "CLAUDE-fonction-marketing.md" in md
    assert "CLAUDE-workflow-campaign.md" in md
