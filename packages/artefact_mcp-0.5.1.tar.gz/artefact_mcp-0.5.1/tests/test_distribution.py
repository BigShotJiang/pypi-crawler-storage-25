"""Tests for distribution artifacts: pyproject, server.json, manifest.json (DXT),
smithery.yaml. Gates the release before PyPI / Smithery publish."""

from __future__ import annotations

import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

EXPECTED_VERSION = "0.5.0"


# --- DXT manifest ---


def test_manifest_json_valid_dxt():
    """manifest.json parses + has the required DXT fields."""
    manifest_path = REPO_ROOT / "manifest.json"
    assert manifest_path.exists(), "manifest.json missing at repo root"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    required = {"dxt_version", "name", "version", "description", "server"}
    missing = required - set(manifest.keys())
    assert missing == set(), f"manifest.json missing required DXT fields: {missing}"

    server = manifest["server"]
    assert "mcp_config" in server, "manifest.server.mcp_config required"
    cfg = server["mcp_config"]
    assert cfg["command"] == "uvx"
    assert "artefact-mcp" in cfg["args"]


def test_manifest_version_matches_pyproject():
    """The DXT manifest version, server.json version, and pyproject version
    must all be in sync — drift breaks the install flow."""
    pyproject = (REPO_ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert f'version = "{EXPECTED_VERSION}"' in pyproject

    manifest = json.loads((REPO_ROOT / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["version"] == EXPECTED_VERSION

    server = json.loads((REPO_ROOT / "server.json").read_text(encoding="utf-8"))
    assert server["version"] == EXPECTED_VERSION
    assert server["packages"][0]["version"] == EXPECTED_VERSION


# --- Smithery ---


def test_smithery_yaml_uses_uvx_artefact_mcp():
    """smithery.yaml must invoke 'uvx artefact-mcp' to match the PyPI flow."""
    smithery = (REPO_ROOT / "smithery.yaml").read_text(encoding="utf-8")
    assert "uvx" in smithery
    assert "artefact-mcp" in smithery
    # Must expose both env vars
    assert "HUBSPOT_API_KEY" in smithery
    assert "ARTEFACT_LICENSE_KEY" in smithery


# --- Sanity: manifest tools list reflects what's actually registered ---


def test_manifest_tools_count_matches_server():
    """The manifest's `tools` array should list all 13 tools registered in
    server.py (5 GTM OS builders + 4 audit tools + 4 Pro tools). Drift =
    users see wrong tool descriptions in Claude Desktop."""
    manifest = json.loads((REPO_ROOT / "manifest.json").read_text(encoding="utf-8"))
    declared_tools = {t["name"] for t in manifest.get("tools", [])}

    expected_tools = {
        # Free tier — GTM OS builders (5)
        "module_prompt_free",
        "archetype_decision",
        "auto_diagnose",
        "generate_claude_md",
        "gate_check",
        # Free tier — HubSpot audit (4, new in v0.5.0)
        "audit_lifecycle_stages",
        "audit_pipeline_hygiene",
        "score_ai_readiness",
        "audit_property_governance",
        # Pro tier — revenue intelligence (4)
        "run_rfm",
        "qualify",
        "score_pipeline_health",
        "validate_configuration",
    }
    assert declared_tools == expected_tools, (
        f"manifest tools drift. Missing: {expected_tools - declared_tools}, "
        f"unexpected: {declared_tools - expected_tools}"
    )


def test_icon_exists_and_is_png():
    """manifest.json references icon.png — the file must exist and be a PNG."""
    icon_path = REPO_ROOT / "icon.png"
    assert icon_path.exists(), "icon.png missing — referenced by manifest.json"
    # PNG signature: 89 50 4E 47 0D 0A 1A 0A
    assert icon_path.read_bytes()[:8] == b"\x89PNG\r\n\x1a\n", "icon.png is not a valid PNG"
