"""Tests for audit_pipeline_hygiene (v0.5.0 Free tier audit tool)."""

from datetime import datetime, timezone

import pytest

from artefact_mcp.tools.audit_pipeline_hygiene import (
    audit_pipeline_hygiene,
    _detect_stale,
    _detect_missing_fields,
    _detect_stage_abuse,
    _detect_age_outliers,
    _stage_age_distribution,
    PIPELINE_HYGIENE_EXPLAINER,
    REQUIRED_FIELDS,
)


# --- Sample-data path ---------------------------------------------------------

class TestSampleDataPath:
    def test_total_deals_8(self):
        result = audit_pipeline_hygiene(source="sample")
        assert result["total_deals"] == 8

    def test_stale_deals_detected(self):
        result = audit_pipeline_hygiene(source="sample")
        # Fixture plants D003 (53d) and D004 (86d) as stale at default threshold (30d)
        assert result["stale_deals_count"] == 2
        ids = {d["deal_id"] for d in result["stale_deals_top10"]}
        assert ids == {"D003", "D004"}

    def test_stale_deals_sorted_by_age_desc(self):
        result = audit_pipeline_hygiene(source="sample")
        # D004 (86d) older than D003 (53d) → D004 first
        assert result["stale_deals_top10"][0]["deal_id"] == "D004"
        assert result["stale_deals_top10"][0]["days_since_modified"] > result["stale_deals_top10"][1]["days_since_modified"]

    def test_missing_fields_detected(self):
        result = audit_pipeline_hygiene(source="sample")
        # Fixture plants D006 (no amount), D007 (no closedate)
        assert result["missing_fields_count"] == 2
        gaps = {(m["deal_id"], tuple(m["missing"])) for m in result["missing_fields_sample"]}
        assert ("D006", ("amount",)) in gaps
        assert ("D007", ("closedate",)) in gaps

    def test_stage_abuse_detected(self):
        result = audit_pipeline_hygiene(source="sample")
        # qualifiedtobuy and presentationscheduled stages are >50% old
        stages = {a["stage"] for a in result["stage_abuses"]}
        assert "qualifiedtobuy" in stages
        assert "presentationscheduled" in stages

    def test_age_outlier_detected(self):
        result = audit_pipeline_hygiene(source="sample")
        # D008 (Hotel Corp Long Tail, 266d) is the planted outlier in qualifiedtobuy
        assert any(o["deal_id"] == "D008" for o in result["age_outliers"])

    def test_recommendations_capped_at_5(self):
        result = audit_pipeline_hygiene(source="sample")
        assert 1 <= len(result["recommendations"]) <= 5

    def test_recommendation_priorities_valid(self):
        result = audit_pipeline_hygiene(source="sample")
        for r in result["recommendations"]:
            assert r["priority"] in ("high", "medium", "low")
            assert "finding" in r and "action" in r

    def test_concept_explainer_included(self):
        result = audit_pipeline_hygiene(source="sample")
        assert "pipeline_hygiene_concept" in result
        text = result["pipeline_hygiene_concept"].lower()
        assert "stale" in text and "hygiene" in text


# --- Edge cases ---------------------------------------------------------------

class TestEdgeCases:
    """PRD: tests cover empty pipeline, all-stale pipeline, healthy pipeline."""

    def test_empty_pipeline(self, monkeypatch):
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_pipeline_hygiene.sample_deals",
            lambda: [],
        )
        result = audit_pipeline_hygiene(source="sample")
        assert result["total_deals"] == 0
        assert result["stale_deals_count"] == 0
        assert result["missing_fields_count"] == 0
        assert result["stage_abuses"] == []
        assert result["age_outliers"] == []
        # Always one baseline recommendation, never empty
        assert len(result["recommendations"]) == 1
        assert "pipeline_hygiene_concept" in result

    def test_all_stale_pipeline(self, monkeypatch):
        very_old = "2025-01-01T10:00:00Z"
        deals = [
            {
                "id": f"D{i}",
                "properties": {
                    "dealname": f"Stale Deal {i}",
                    "amount": "10000",
                    "dealstage": "qualifiedtobuy",
                    "pipeline": "default",
                    "createdate": very_old,
                    "closedate": "2026-12-31T00:00:00Z",
                    "hs_lastmodifieddate": very_old,
                    "hubspot_owner_id": "OW001",
                },
            }
            for i in range(5)
        ]
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_pipeline_hygiene.sample_deals",
            lambda: deals,
        )
        result = audit_pipeline_hygiene(source="sample")
        # Every deal is stale
        assert result["stale_deals_count"] == 5
        # And every deal in qualifiedtobuy is old → stage abuse fires
        assert any(a["stage"] == "qualifiedtobuy" for a in result["stage_abuses"])

    def test_healthy_pipeline(self, monkeypatch):
        recent = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        deals = [
            {
                "id": f"D{i}",
                "properties": {
                    "dealname": f"Fresh Deal {i}",
                    "amount": "10000",
                    "dealstage": "qualifiedtobuy",
                    "pipeline": "default",
                    "createdate": recent,
                    "closedate": "2026-12-31T00:00:00Z",
                    "hs_lastmodifieddate": recent,
                    "hubspot_owner_id": "OW001",
                },
            }
            for i in range(5)
        ]
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_pipeline_hygiene.sample_deals",
            lambda: deals,
        )
        result = audit_pipeline_hygiene(source="sample")
        assert result["stale_deals_count"] == 0
        assert result["missing_fields_count"] == 0
        assert result["stage_abuses"] == []
        # The "clean" baseline recommendation should fire
        assert any("clean" in r["finding"].lower() for r in result["recommendations"])

    def test_missing_required_fields_logic(self):
        deals = [
            {"id": "D1", "properties": {"dealname": "X", "dealstage": "abc"}},  # missing amount, closedate, owner
        ]
        missing = _detect_missing_fields(deals)
        assert len(missing) == 1
        assert set(missing[0]["missing"]) == {"amount", "closedate", "hubspot_owner_id"}

    def test_amount_zero_does_not_count_as_missing(self):
        # amount="0" should not be flagged as missing — 0 is a valid numeric value.
        deals = [
            {"id": "D1", "properties": {
                "dealname": "Zero Deal",
                "amount": "0",
                "closedate": "2026-12-31T00:00:00Z",
                "dealstage": "qualifiedtobuy",
                "hubspot_owner_id": "OW001",
            }},
        ]
        missing = _detect_missing_fields(deals)
        assert missing == []

    def test_invalid_source_raises(self):
        with pytest.raises(ValueError, match="Invalid source"):
            audit_pipeline_hygiene(source="banana")

    def test_hubspot_source_without_client_raises(self):
        with pytest.raises(ValueError, match="HubSpot client required"):
            audit_pipeline_hygiene(source="hubspot")


# --- Threshold parameter ------------------------------------------------------

class TestStalenessThreshold:
    def test_higher_threshold_fewer_stale(self):
        default_result = audit_pipeline_hygiene(source="sample", staleness_days=30)
        strict_result = audit_pipeline_hygiene(source="sample", staleness_days=90)
        # 90-day threshold should catch fewer or equal deals
        assert strict_result["stale_deals_count"] <= default_result["stale_deals_count"]

    def test_zero_threshold_catches_everything(self):
        result = audit_pipeline_hygiene(source="sample", staleness_days=0)
        # Even today's modifications count as 0 days >= 0 days threshold
        assert result["stale_deals_count"] == 8


# --- Pipeline filter ----------------------------------------------------------

class TestPipelineFilter:
    def test_pipeline_filter_on_sample(self):
        # All sample deals are pipeline='default'. Filter to a non-existent pipeline → empty.
        result = audit_pipeline_hygiene(source="sample", pipeline_id="nonexistent")
        assert result["total_deals"] == 0


# --- Stage abuse helper -------------------------------------------------------

class TestStageAbuseHelper:
    def test_single_deal_stage_skipped(self):
        # PRD acceptance: stage abuse needs >=2 deals to be statistically interesting
        now = datetime(2026, 5, 8, tzinfo=timezone.utc)
        deals = [
            {"id": "D1", "properties": {"dealstage": "lone", "createdate": "2025-01-01T00:00:00Z"}},
        ]
        abuses = _detect_stage_abuse(deals, now)
        assert abuses == []

    def test_50_pct_threshold(self):
        now = datetime(2026, 5, 8, tzinfo=timezone.utc)
        # 2 of 4 are old (=50%) → triggers
        deals = [
            {"id": "D1", "properties": {"dealstage": "abc", "createdate": "2025-01-01T00:00:00Z"}},  # very old
            {"id": "D2", "properties": {"dealstage": "abc", "createdate": "2025-01-15T00:00:00Z"}},  # very old
            {"id": "D3", "properties": {"dealstage": "abc", "createdate": "2026-04-30T00:00:00Z"}},  # fresh
            {"id": "D4", "properties": {"dealstage": "abc", "createdate": "2026-05-01T00:00:00Z"}},  # fresh
        ]
        abuses = _detect_stage_abuse(deals, now)
        assert len(abuses) == 1
        assert abuses[0]["old_deal_ratio_pct"] == 50.0


# --- Age outlier helper -------------------------------------------------------

class TestTruncation:
    """Gemini cross-review fix: pagination cap must surface, not silently truncate."""

    def test_sample_path_data_truncated_false(self):
        result = audit_pipeline_hygiene(source="sample")
        assert result["data_truncated"] is False

    def test_truncation_warning_propagated(self):
        class FakeTruncatedClient:
            def __init__(self):
                self.last_fetch_meta = {
                    "truncated": True,
                    "pages_fetched": 500,
                    "max_pages": 500,
                    "records_returned": 50000,
                }

            def fetch_deals_with_hygiene(self, pipeline_id=None):
                return [{
                    "id": "T1",
                    "properties": {
                        "dealname": "Test", "amount": "1000",
                        "dealstage": "qualifiedtobuy", "pipeline": "default",
                        "createdate": "2026-04-01T10:00:00Z",
                        "closedate": "2026-12-31T00:00:00Z",
                        "hs_lastmodifieddate": "2026-05-07T10:00:00Z",
                        "hubspot_owner_id": "OW1",
                    },
                }]

            def close(self):
                pass

        result = audit_pipeline_hygiene(
            source="hubspot", hubspot_client=FakeTruncatedClient()
        )
        assert result["data_truncated"] is True
        assert any("WARNING" in n for n in result["notes"])


class TestAgeOutlierHelper:
    def test_three_x_median_threshold(self):
        now = datetime(2026, 5, 8, tzinfo=timezone.utc)
        deals = [
            {"id": "D1", "properties": {"dealstage": "abc", "createdate": "2026-04-28T00:00:00Z"}},  # 10d
            {"id": "D2", "properties": {"dealstage": "abc", "createdate": "2026-04-28T00:00:00Z"}},  # 10d
            {"id": "D3", "properties": {"dealstage": "abc", "createdate": "2026-04-28T00:00:00Z"}},  # 10d (median)
            {"id": "D4", "properties": {"dealstage": "abc", "createdate": "2026-01-01T00:00:00Z"}},  # 127d (>3x)
        ]
        age_dist = _stage_age_distribution(deals, now)
        outliers = _detect_age_outliers(deals, now, age_dist)
        assert len(outliers) == 1
        assert outliers[0]["deal_id"] == "D4"
