"""Tests for the usage logger module (v0.5.0 Phase 6)."""

import os
import time
from unittest.mock import patch, MagicMock

import pytest

from artefact_mcp.core.usage_logger import (
    log_usage,
    _hash_license_key,
    UsageEvent,
)


class TestHashLicenseKey:
    def test_returns_16_chars(self):
        h = _hash_license_key("artefact-pro-abc123")
        assert h is not None
        assert len(h) == 16
        # Hex characters only
        assert all(c in "0123456789abcdef" for c in h)

    def test_consistent(self):
        a = _hash_license_key("same-key")
        b = _hash_license_key("same-key")
        assert a == b

    def test_different_inputs_diverge(self):
        a = _hash_license_key("key-A")
        b = _hash_license_key("key-B")
        assert a != b

    def test_none_returns_none(self):
        assert _hash_license_key(None) is None

    def test_empty_string_returns_none(self):
        assert _hash_license_key("") is None


class TestLogUsageNoop:
    """When ANY of the 3 env conditions is unmet, log_usage is a no-op."""

    def _set_endpoint_and_key(self, monkeypatch):
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_ENDPOINT", "https://x.test/rest/v1/mcp_license_usage")
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_KEY", "anon-key-xyz")

    def test_no_endpoint_no_post(self, monkeypatch):
        monkeypatch.delenv("ARTEFACT_USAGE_LOG_ENDPOINT", raising=False)
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_KEY", "k")
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "true")

        with patch("httpx.post") as mock_post:
            log_usage(tool_name="audit_lifecycle_stages", tier="free", success=True)
            assert mock_post.call_count == 0

    def test_no_key_no_post(self, monkeypatch):
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_ENDPOINT", "https://x.test/rest/v1/mcp_license_usage")
        monkeypatch.delenv("ARTEFACT_USAGE_LOG_KEY", raising=False)
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "true")

        with patch("httpx.post") as mock_post:
            log_usage(tool_name="audit_lifecycle_stages", tier="free", success=True)
            assert mock_post.call_count == 0

    def test_no_opt_in_no_post(self, monkeypatch):
        """Loi 25: even with endpoint+key set, no POST without explicit opt-in."""
        self._set_endpoint_and_key(monkeypatch)
        monkeypatch.delenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", raising=False)

        with patch("httpx.post") as mock_post:
            log_usage(tool_name="audit_lifecycle_stages", tier="free", success=True)
            assert mock_post.call_count == 0

    def test_opt_in_false_no_post(self, monkeypatch):
        self._set_endpoint_and_key(monkeypatch)
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "false")

        with patch("httpx.post") as mock_post:
            log_usage(tool_name="audit_lifecycle_stages", tier="free", success=True)
            assert mock_post.call_count == 0

    def test_opt_in_garbage_no_post(self, monkeypatch):
        """Anything other than literal 'true' (case-insensitive) blocks the POST."""
        self._set_endpoint_and_key(monkeypatch)
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "yes")

        with patch("httpx.post") as mock_post:
            log_usage(tool_name="audit_lifecycle_stages", tier="free", success=True)
            assert mock_post.call_count == 0


class TestLogUsageActive:
    """When all 3 env conditions are set, a daemon thread fires a POST."""

    def test_post_fires(self, monkeypatch):
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_ENDPOINT", "https://x.test/rest/v1/mcp_license_usage")
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_KEY", "anon-key-xyz")
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "true")

        with patch("httpx.post") as mock_post:
            log_usage(
                tool_name="audit_lifecycle_stages",
                tier="pro",
                success=True,
                license_key="real-key-1234",
                source="hubspot",
                mcp_version="0.5.0",
            )
            # Daemon thread — give it a moment
            time.sleep(0.2)
            assert mock_post.call_count == 1

            args, kwargs = mock_post.call_args
            assert args[0] == "https://x.test/rest/v1/mcp_license_usage"
            payload = kwargs["json"]
            assert payload["tool_name"] == "audit_lifecycle_stages"
            assert payload["tier"] == "pro"
            assert payload["success"] is True
            assert payload["source"] == "hubspot"
            assert payload["mcp_version"] == "0.5.0"
            # Hash, not raw key
            assert "license_key_hash" in payload
            assert payload["license_key_hash"] != "real-key-1234"
            assert len(payload["license_key_hash"]) == 16

            # Headers contain the anon key
            headers = kwargs["headers"]
            assert headers["apikey"] == "anon-key-xyz"
            assert headers["Authorization"] == "Bearer anon-key-xyz"

    def test_no_license_key_emits_null_hash(self, monkeypatch):
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_ENDPOINT", "https://x.test/")
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_KEY", "k")
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "true")

        with patch("httpx.post") as mock_post:
            log_usage(tool_name="module_prompt_free", tier="free", success=True)
            time.sleep(0.2)
            assert mock_post.call_count == 1
            payload = mock_post.call_args[1]["json"]
            # license_key_hash absent (UsageEvent omits None values from payload)
            assert "license_key_hash" not in payload

    def test_failure_event(self, monkeypatch):
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_ENDPOINT", "https://x.test/")
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_KEY", "k")
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "true")

        with patch("httpx.post") as mock_post:
            log_usage(
                tool_name="run_rfm",
                tier="free",
                success=False,
                error_code="license_required",
                source="hubspot",
            )
            time.sleep(0.2)
            payload = mock_post.call_args[1]["json"]
            assert payload["success"] is False
            assert payload["error_code"] == "license_required"

    def test_post_failure_swallowed(self, monkeypatch):
        """If the POST itself fails, the caller never sees an exception."""
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_ENDPOINT", "https://x.test/")
        monkeypatch.setenv("ARTEFACT_USAGE_LOG_KEY", "k")
        monkeypatch.setenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "true")

        with patch("httpx.post", side_effect=Exception("boom")):
            # Should not raise even though httpx raises in the daemon thread
            log_usage(tool_name="any_tool", tier="free", success=True)
            time.sleep(0.2)


class TestUsageEventDataclass:
    def test_round_trip(self):
        event = UsageEvent(
            tool_name="x",
            tier="pro",
            success=True,
            source="sample",
        )
        assert event.tool_name == "x"
        assert event.tier == "pro"
        assert event.success is True
        assert event.source == "sample"
