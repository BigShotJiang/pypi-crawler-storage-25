"""Tests for archetype_decision tool — P1 Free tier."""

from __future__ import annotations

from artefact_mcp.resources.formula import ARCHETYPES, archetype_decision


def test_default_returns_archetype_a():
    """All flags at default (only can_adopt_open=True) → A is the Artefact default."""
    result = archetype_decision()
    assert result["archetype"] == "A"
    assert "Open" in result["name"]


def test_m365_dominant_routes_to_c():
    result = archetype_decision(m365_dominant=True)
    assert result["archetype"] == "C"
    assert "Microsoft" in result["name"]


def test_google_workspace_routes_to_b():
    result = archetype_decision(google_workspace_dominant=True)
    assert result["archetype"] == "B"
    assert "Google" in result["name"]


def test_sovereignty_extreme_routes_to_d():
    result = archetype_decision(sovereignty_extreme=True)
    assert result["archetype"] == "D"
    assert "on-prem" in result["name"] or "Hybride" in result["name"]


def test_loi_25_strict_skips_to_a():
    """Loi 25 strict shortcuts the tree to A even if M365 dominant — pattern from doc."""
    result = archetype_decision(loi_25_strict=True, m365_dominant=True)
    assert result["archetype"] == "A"
    assert any("skip" in step.lower() for step in result["decision_path"])


def test_decision_path_recorded():
    result = archetype_decision(google_workspace_dominant=True)
    assert len(result["decision_path"]) >= 2
    assert any("Q3" in step for step in result["decision_path"])


def test_each_archetype_has_three_advantages_three_constraints():
    for code, info in ARCHETYPES.items():
        assert len(info["advantages"]) == 3, f"Archetype {code} should have 3 advantages"
        assert len(info["constraints"]) == 3, f"Archetype {code} should have 3 constraints"


def test_response_includes_next_module():
    result = archetype_decision()
    assert "ARC-2" in result["next_module"]
