"""Tests for the v0.4.1 onboarding UX improvements: welcome resource +
5 MCP prompts (/artefact-start, /artefact-diagnose, /artefact-claude-md,
/artefact-archetype, /artefact-modules).

These verify that the slash commands and the welcome resource are
registered with the FastMCP server. The post-install UX problem is that
a user opens Claude Desktop after install and has no entry point — the
prompts surface in the slash menu and fix that gap.
"""

from __future__ import annotations

import asyncio

import pytest


@pytest.fixture(scope="module")
def mcp_server():
    """Import the configured server. Module-scoped to avoid re-init cost."""
    from artefact_mcp.server import mcp
    return mcp


@pytest.fixture(scope="module")
def registered_prompts(mcp_server):
    return asyncio.run(mcp_server.get_prompts())


@pytest.fixture(scope="module")
def registered_resources(mcp_server):
    return asyncio.run(mcp_server.get_resources())


# --- Welcome resource ---


def test_welcome_resource_registered(registered_resources):
    """methodology://welcome must be in the resource list — the agent reads
    it on first interaction to orient the user."""
    uris = list(registered_resources)
    assert any("methodology://welcome" in str(u) for u in uris), (
        f"methodology://welcome not registered. Found: {uris}"
    )


def test_welcome_resource_mentions_slash_commands():
    """The welcome resource body must surface the 5 slash commands so the
    agent knows what to suggest to a new user."""
    from artefact_mcp.server import welcome
    body = welcome.fn()
    for cmd in (
        "/artefact-start",
        "/artefact-diagnose",
        "/artefact-claude-md",
        "/artefact-archetype",
        "/artefact-modules",
    ):
        assert cmd in body, f"welcome resource missing {cmd}"


def test_welcome_resource_includes_starter_prompt():
    """v0.4.3: the welcome resource must surface the canonical starter
    prompt 'Help me build my AI Operating System' as the first concrete
    sentence the agent suggests to a new user."""
    from artefact_mcp.server import welcome
    body = welcome.fn()
    assert "Help me build my AI Operating System" in body


# --- 5 prompts ---


def test_all_five_prompts_registered(registered_prompts):
    expected = {
        "artefact-start",
        "artefact-diagnose",
        "artefact-claude-md",
        "artefact-archetype",
        "artefact-modules",
    }
    declared = set(registered_prompts.keys())
    missing = expected - declared
    assert missing == set(), f"Prompts not registered: {missing}. Found: {declared}"


def test_prompt_start_has_no_required_args(registered_prompts):
    p = registered_prompts["artefact-start"]
    # 0 args means user can call it directly from the slash menu
    assert len(p.arguments or []) == 0


def test_prompt_diagnose_accepts_optional_context(registered_prompts):
    p = registered_prompts["artefact-diagnose"]
    arg_names = {a.name for a in (p.arguments or [])}
    assert "context" in arg_names
    # context must be optional so user can call /artefact-diagnose with nothing
    context_arg = next(a for a in p.arguments if a.name == "context")
    assert context_arg.required is False


def test_prompt_claude_md_accepts_optional_seed_args(registered_prompts):
    p = registered_prompts["artefact-claude-md"]
    arg_names = {a.name for a in (p.arguments or [])}
    assert {"client_name", "function"}.issubset(arg_names)


def test_prompt_archetype_has_no_required_args(registered_prompts):
    p = registered_prompts["artefact-archetype"]
    # All 5 yes/no questions are asked interactively, no args needed upfront
    assert len(p.arguments or []) == 0


def test_prompt_modules_accepts_optional_module_id(registered_prompts):
    p = registered_prompts["artefact-modules"]
    arg_names = {a.name for a in (p.arguments or [])}
    assert "module_id" in arg_names


# --- Prompt body content sanity ---


def test_prompt_diagnose_body_routes_to_auto_diagnose():
    from artefact_mcp.server import prompt_diagnose
    body_empty = prompt_diagnose.fn("")
    body_with_ctx = prompt_diagnose.fn("solo founder, want to test free")
    # Empty path: agent should ask the 3 framing questions
    assert "auto_diagnose" in body_empty
    assert "3" in body_empty or "three" in body_empty.lower()
    # With context: agent should call auto_diagnose directly
    assert "auto_diagnose" in body_with_ctx
    assert "solo founder" in body_with_ctx


def test_prompt_claude_md_body_routes_to_generate_claude_md():
    from artefact_mcp.server import prompt_claude_md
    body = prompt_claude_md.fn(client_name="Acme", function="Marketing")
    assert "generate_claude_md" in body
    assert "Acme" in body
    assert "Marketing" in body


def test_prompt_archetype_body_routes_to_archetype_decision():
    from artefact_mcp.server import prompt_archetype
    body = prompt_archetype.fn()
    assert "archetype_decision" in body
    # Must enumerate the 5 questions
    for keyword in ("Loi 25", "Microsoft 365", "Google Workspace", "Sovereignty", "open"):
        assert keyword.lower() in body.lower(), f"prompt_archetype missing question keyword: {keyword}"


def test_prompt_modules_body_routes_to_module_prompt_free():
    from artefact_mcp.server import prompt_modules
    body_empty = prompt_modules.fn("")
    body_with_id = prompt_modules.fn("FOND-1")
    assert "module_prompt_free" in body_empty
    assert "module_prompt_free" in body_with_id
    assert "FOND-1" in body_with_id


def test_prompt_start_body_uses_welcome_resource():
    """Start prompt must direct the agent to read methodology://welcome
    so the orientation logic is centralized in the resource."""
    from artefact_mcp.server import prompt_start
    body = prompt_start.fn()
    assert "methodology://welcome" in body
