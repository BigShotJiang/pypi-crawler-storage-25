"""Tests for HubSpot client with mocked HTTP responses."""

import time
from unittest.mock import patch, MagicMock

import pytest
import json
import httpx

from artefact_mcp.core.hubspot_client import HubSpotClient, _TokenBucket


class TestHubSpotClientInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="API key required"):
            HubSpotClient(api_key=None)

    def test_accepts_api_key(self):
        client = HubSpotClient(api_key="test-key-123")
        # api_key property returns masked value for safety
        assert client.api_key == "test...-123"
        client.close()

    def test_context_manager(self):
        with HubSpotClient(api_key="test-key-abc") as client:
            assert client.api_key == "test...-abc"


class TestHubSpotClientHelpers:
    def setup_method(self):
        self.client = HubSpotClient(api_key="test-key")

    def teardown_method(self):
        self.client.close()

    def test_safe_float(self):
        assert self.client._safe_float("123.45") == 123.45
        assert self.client._safe_float(None) == 0.0
        assert self.client._safe_float("not-a-number") == 0.0

    def test_safe_int(self):
        assert self.client._safe_int("42") == 42
        assert self.client._safe_int(None) is None
        assert self.client._safe_int("not-a-number") is None

    def test_parse_employee_band(self):
        assert self.client._parse_employee_band("5") == "1-10"
        assert self.client._parse_employee_band("25") == "11-50"
        assert self.client._parse_employee_band("100") == "51-200"
        assert self.client._parse_employee_band("300") == "201-500"
        assert self.client._parse_employee_band("800") == "501-1000"
        assert self.client._parse_employee_band("5000") == "1000+"
        assert self.client._parse_employee_band(None) is None

    def test_parse_revenue_band(self):
        assert self.client._parse_revenue_band("500000") == "<$1M"
        assert self.client._parse_revenue_band("3000000") == "$1M-$5M"
        assert self.client._parse_revenue_band("10000000") == "$5M-$20M"
        assert self.client._parse_revenue_band("50000000") == "$20M-$70M"
        assert self.client._parse_revenue_band("100000000") == "$70M+"
        assert self.client._parse_revenue_band(None) is None

    def test_parse_date(self):
        dt = self.client._parse_date("2026-01-15T10:00:00Z")
        assert dt is not None
        assert dt.year == 2026
        assert dt.month == 1

        assert self.client._parse_date(None) is None
        assert self.client._parse_date("invalid") is None

    def test_aggregate_by_company(self):
        deals = [
            {
                "id": "1",
                "name": "Deal 1",
                "amount": 10000,
                "close_date": None,
                "stage": "closedwon",
                "associations": {
                    "companies": {"results": [{"id": "C1"}]}
                },
            },
            {
                "id": "2",
                "name": "Deal 2",
                "amount": 20000,
                "close_date": None,
                "stage": "closedwon",
                "associations": {
                    "companies": {"results": [{"id": "C1"}]}
                },
            },
        ]
        companies = {
            "C1": {
                "id": "C1",
                "name": "Test Corp",
                "domain": "test.com",
                "industry": "SaaS",
                "employee_count": "51-200",
                "company_revenue": "$5M-$20M",
                "state_region": "Quebec",
            }
        }

        result = self.client._aggregate_by_company(deals, companies)
        assert len(result) == 1
        assert result[0]["client_name"] == "Test Corp"
        assert result[0]["total_revenue"] == 30000
        assert result[0]["transaction_count"] == 2


class TestTokenBucket:
    """Gemini round-2 cross-review fix: rate-limit guard against runaway loops."""

    def test_capacity_starts_full(self):
        b = _TokenBucket(rate=10.0, capacity=10.0)
        # Should be able to acquire capacity tokens immediately without sleep
        start = time.monotonic()
        for _ in range(10):
            b.acquire()
        assert time.monotonic() - start < 0.1

    def test_throttles_when_drained(self):
        b = _TokenBucket(rate=10.0, capacity=2.0)  # 10 req/sec, burst 2
        # First 2 are instant, third must wait ~0.1s for refill
        b.acquire()
        b.acquire()
        start = time.monotonic()
        b.acquire()
        elapsed = time.monotonic() - start
        # Refill is rate=10/sec → 1 token in 0.1s. Allow 50% slack.
        assert elapsed >= 0.05

    def test_minimum_rate_enforced(self):
        # Even passing 0 should not produce a divide-by-zero
        b = _TokenBucket(rate=0.0, capacity=1.0)
        assert b.rate >= 0.1


class TestRateLimitRetry:
    """The _request method must retry on 429 with backoff before raising."""

    def setup_method(self):
        self.client = HubSpotClient(api_key="test-key")

    def teardown_method(self):
        self.client.close()

    def _make_429_response(self, retry_after=None):
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 429
        resp.text = "rate limited"
        resp.headers = {"Retry-After": retry_after} if retry_after else {}
        err = httpx.HTTPStatusError(
            "rate limited", request=MagicMock(), response=resp
        )
        return err

    def _make_ok_response(self):
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 200
        resp.json = MagicMock(return_value={"results": []})
        resp.raise_for_status = MagicMock()
        return resp

    def test_429_then_success_retries(self):
        """First call gets 429, second call succeeds — should not raise."""
        ok = self._make_ok_response()
        bad = self._make_429_response(retry_after="0")

        with patch.object(self.client._client, "request") as mock_req:
            mock_req.side_effect = [
                MagicMock(raise_for_status=MagicMock(side_effect=bad)),
                ok,
            ]
            response = self.client._request("GET", "https://api.test/x")
            assert response is ok
            assert mock_req.call_count == 2

    def test_429_persistent_raises_after_max_attempts(self):
        bad_resp = MagicMock(spec=httpx.Response)
        bad_resp.status_code = 429
        bad_resp.text = "rate limited"
        bad_resp.headers = {"Retry-After": "0"}
        bad_resp.raise_for_status = MagicMock(
            side_effect=httpx.HTTPStatusError(
                "429", request=MagicMock(), response=bad_resp
            )
        )

        with patch.object(self.client._client, "request", return_value=bad_resp):
            with pytest.raises(ValueError, match="rate limit"):
                self.client._request("GET", "https://api.test/x")

    def test_429_honors_retry_after(self):
        """If Retry-After header sets a small delay, the retry sleeps for it."""
        ok = self._make_ok_response()
        bad_resp = MagicMock(spec=httpx.Response)
        bad_resp.status_code = 429
        bad_resp.text = "rate limited"
        bad_resp.headers = {"Retry-After": "0.2"}
        bad_resp.raise_for_status = MagicMock(
            side_effect=httpx.HTTPStatusError(
                "429", request=MagicMock(), response=bad_resp
            )
        )

        with patch.object(self.client._client, "request") as mock_req:
            mock_req.side_effect = [bad_resp, ok]
            start = time.monotonic()
            response = self.client._request("GET", "https://api.test/x")
            elapsed = time.monotonic() - start
            assert response is ok
            # Retry-After=0.2s → request should take >=0.15s
            assert elapsed >= 0.15

    def test_401_no_retry(self):
        """Non-429 errors do not retry."""
        bad_resp = MagicMock(spec=httpx.Response)
        bad_resp.status_code = 401
        bad_resp.text = "unauthorized"
        bad_resp.headers = {}
        bad_resp.raise_for_status = MagicMock(
            side_effect=httpx.HTTPStatusError(
                "401", request=MagicMock(), response=bad_resp
            )
        )

        with patch.object(self.client._client, "request", return_value=bad_resp) as mock_req:
            with pytest.raises(ValueError, match="invalid or expired"):
                self.client._request("GET", "https://api.test/x")
            # Only one call — no retry on 401
            assert mock_req.call_count == 1


class TestRateLimitConfig:
    def test_env_var_sets_rps(self, monkeypatch):
        monkeypatch.setenv("ARTEFACT_HUBSPOT_RPS", "20")
        client = HubSpotClient(api_key="test-key")
        assert client._bucket.rate == 20.0
        client.close()

    def test_invalid_env_var_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv("ARTEFACT_HUBSPOT_RPS", "not-a-number")
        client = HubSpotClient(api_key="test-key")
        assert client._bucket.rate == 8.0
        client.close()

    def test_default_rps_is_8(self, monkeypatch):
        monkeypatch.delenv("ARTEFACT_HUBSPOT_RPS", raising=False)
        client = HubSpotClient(api_key="test-key")
        assert client._bucket.rate == 8.0
        client.close()
