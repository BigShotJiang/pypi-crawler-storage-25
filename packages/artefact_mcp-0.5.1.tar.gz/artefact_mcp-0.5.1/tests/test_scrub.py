"""Tests for the scrub pipeline that anonymizes client refs before PyPI build."""

from __future__ import annotations

import json
import sys
from pathlib import Path

# Make `scripts/` importable for the test
_SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

from scrub import (  # type: ignore[import-not-found]
    PUBLIC_MARKS,
    SCRUB_TARGETS,
    find_unscrubbed,
    scrub_payload,
    scrub_text,
)


# --- Compound substitutions ---


def test_compound_pierre_luc_bixi():
    """Compound MUST run before simple — single label, not two."""
    result = scrub_text("Pattern Pierre-Luc Bixi observé pendant le mandat")
    assert "[Pilote A — Client A]" in result
    assert "[Pilote A] [Client A]" not in result
    assert "Bixi" not in result
    assert "Pierre-Luc" not in result


def test_compound_david_aubert():
    result = scrub_text("Le sponsor David Aubert a validé")
    assert "[Sponsor B]" in result
    assert "David Aubert" not in result


def test_compound_alexandre_laroche():
    result = scrub_text("Pattern Alexandre Laroche M Groupe Conseil")
    assert "[Pilote C]" in result
    assert "[Client C]" in result


# --- Simple substitutions ---


def test_simple_bixi():
    result = scrub_text("Le mandat Bixi en avril 2026")
    assert result == "Le mandat [Client A] en avril 2026"


def test_simple_pierre_luc_alone():
    """Pierre-Luc alone (without Bixi) → [Pilote A]."""
    result = scrub_text("Pierre-Luc a livré le sprint")
    assert "[Pilote A]" in result
    assert "Pierre-Luc" not in result


def test_simple_isothermic():
    result = scrub_text("Mandat Isothermic Operations OS")
    assert "[Client B]" in result
    assert "Isothermic" not in result


# --- Public marks preserved ---


def test_preserves_synapse():
    text = "Synapse est l'infra Artefact partagée"
    result = scrub_text(text)
    assert "Synapse" in result
    assert "Artefact" in result


def test_preserves_alex_boissonneault():
    text = "Alex Boissonneault, fondateur d'Artefact, anime la Phase 1"
    assert scrub_text(text) == text


def test_preserves_code_marketing():
    text = "Partenariat formalisé avec Code Marketing"
    assert scrub_text(text) == text


# --- Idempotence ---


def test_scrub_is_idempotent():
    """scrub(scrub(x)) == scrub(x). Critical: the labels themselves must not
    re-trigger substitutions on subsequent runs."""
    text = "Pierre-Luc Bixi et David Aubert ont kicked off"
    once = scrub_text(text)
    twice = scrub_text(once)
    assert once == twice


# --- Recursive payload ---


def test_scrub_payload_walks_nested_structures():
    payload = {
        "modules": [
            {"id": "FOND-1", "raw_markdown": "Pattern Bixi observé"},
            {"id": "ARC-1", "raw_markdown": "Synapse pattern"},
        ],
        "meta": {"pilot_example": "Pierre-Luc Bixi"},
    }
    result = scrub_payload(payload)
    assert result["modules"][0]["raw_markdown"] == "Pattern [Client A] observé"
    assert result["modules"][1]["raw_markdown"] == "Synapse pattern"  # preserved
    assert result["meta"]["pilot_example"] == "[Pilote A — Client A]"


def test_scrub_payload_does_not_mutate_input():
    payload = {"text": "Bixi"}
    scrub_payload(payload)
    assert payload["text"] == "Bixi"  # original untouched


# --- Regression: built JSON must be clean ---


def test_built_json_files_have_no_client_names():
    """The actual built JSON files committed in the wheel must contain
    zero unscrubbed references. This is the gate before PyPI publish."""
    data_dir = Path(__file__).resolve().parent.parent / "src" / "artefact_mcp" / "resources" / "_data"
    for json_file in ("modules.json", "kit_fondation.json", "modes.json"):
        path = data_dir / json_file
        assert path.exists(), f"Missing {json_file} — run scripts/build_resources.py"
        text = path.read_text(encoding="utf-8")
        unscrubbed = find_unscrubbed(text)
        assert unscrubbed == [], (
            f"{json_file} still contains unscrubbed names: {unscrubbed}. "
            "Re-run scripts/build_resources.py."
        )


def test_built_json_files_preserve_public_marks():
    """Sanity: public marks should still appear in the built JSON (the scrub
    didn't accidentally take them out)."""
    data_dir = Path(__file__).resolve().parent.parent / "src" / "artefact_mcp" / "resources" / "_data"
    modules_text = (data_dir / "modules.json").read_text(encoding="utf-8")
    # At least Synapse and Artefact should appear since they're heavily referenced
    assert "Synapse" in modules_text
    assert "Artefact" in modules_text
