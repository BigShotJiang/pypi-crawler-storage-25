"""Tests for scripts/build_resources.py — verify MOS template serialization."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = REPO_ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import build_resources  # noqa: E402


@pytest.fixture(scope="module")
def built() -> dict:
    return build_resources.build()


@pytest.fixture(scope="module")
def modules_payload() -> dict:
    path = build_resources.OUTPUT_DIR / "modules.json"
    return json.loads(path.read_text(encoding="utf-8"))


def test_modules_count_matches_source(built):
    """All non-README .md files in modules/ are serialized."""
    source_count = len(
        [p for p in (build_resources.TEMPLATE_DIR / "modules").glob("*.md") if p.name != "README.md"]
    )
    assert built["modules"] == source_count
    assert built["modules"] >= 30, "expected at least 30 modules in the v2.2 template"


def test_module_metadata_extracted(modules_payload):
    """FOND-1 should expose its Pilier and Sprint metadata."""
    fond1 = next(m for m in modules_payload["modules"] if m["id"] == "FOND-1")
    assert "Pilier" in fond1["metadata"]
    assert fond1["metadata"]["Pilier"].startswith("A.1")
    assert "Sprint" in fond1["metadata"]
    assert fond1["title"]
    assert fond1["raw_markdown"].startswith("# Module FOND-1")


def test_qa_gate_section_present(modules_payload):
    """QA gate section is one of the load-bearing artefacts — must be parsed for FOND-1."""
    fond1 = next(m for m in modules_payload["modules"] if m["id"] == "FOND-1")
    assert "qa_gate" in fond1["sections"]
    assert fond1["sections"]["qa_gate"]["body"]
    assert "nouveau chat" in fond1["sections"]["qa_gate"]["body"].lower()


def test_kit_fondation_files_serialized():
    path = build_resources.OUTPUT_DIR / "kit_fondation.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    ids = {f["id"] for f in payload["files"]}
    assert "5-piliers-7-capacites" in ids
    assert "glossaire-20-termes" in ids
    assert "decision-tree-infra" in ids


def test_modes_files_serialized():
    path = build_resources.OUTPUT_DIR / "modes.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    ids = {f["id"] for f in payload["files"]}
    assert {"self-serve", "poc", "diy", "co-build"}.issubset(ids)


def test_build_meta_records_sha():
    path = build_resources.OUTPUT_DIR / "_build_meta.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert "source_sha" in payload
    assert "counts" in payload
    assert payload["counts"]["modules"] > 0
