"""Tests for v0.4.6 embedded explanations.

Each Free tier tool now injects 1-line concept explainers into its output
so the agent can frame results without the user needing external docs.
Driven by Syeda's audit (May 5 2026): "Methodology depth creates a learning
curve... new users may not immediately understand the language or why it
matters."
"""

from __future__ import annotations

import json

from artefact_mcp.resources.formula import (
    archetype_decision,
    auto_diagnose,
    gate_check,
    generate_claude_md,
    get_module,
    pillar_for_module,
    render_module,
)


def test_archetype_decision_includes_explainer():
    result = archetype_decision(m365_dominant=True)
    assert result["archetype"] == "C"
    assert "archetype_explainer" in result
    assert "Microsoft" in result["archetype_explainer"]
    assert "Copilot" in result["archetype_explainer"]


def test_auto_diagnose_includes_mode_and_pillar_explainers():
    # Use the same proven input from test_auto_diagnose.py for Self-Serve
    result = auto_diagnose("Je suis fondateur solo d'une startup SaaS. Je veux essayer gratuit.")
    assert result["mode"] == "Self-Serve"
    assert "mode_explainer" in result
    assert "small tech-savvy" in result["mode_explainer"] or "Free tier" in result["mode_explainer"]
    # Starting module is FOND-1, pillar FOND
    assert "starting_module_pillar_explainer" in result
    assert "Foundation" in result["starting_module_pillar_explainer"]


def test_auto_diagnose_archetype_hint_includes_explainer():
    result = auto_diagnose("PME industrielle 100% Microsoft 365, sponsor veut livrable, équipe de 50")
    assert result.get("archetype_hint") == "C"
    assert "archetype_hint_explainer" in result
    assert "Microsoft" in result["archetype_hint_explainer"]


def test_gate_check_includes_concept_and_pillar():
    result = gate_check("FOND-1", "")
    assert "gate_concept" in result
    assert "binary checklist" in result["gate_concept"]
    assert "module_pillar_explainer" in result
    assert "Foundation" in result["module_pillar_explainer"]


def test_generate_claude_md_empty_includes_concept():
    result = generate_claude_md("")
    assert "claude_md_concept" in result
    assert "master prompt" in result["claude_md_concept"].lower() or "business logic" in result["claude_md_concept"].lower()


def test_generate_claude_md_complete_includes_concept():
    fields = json.dumps({
        "client_name": "Acme",
        "pilot": {"first_name": "Alex", "role": "DM"},
        "function": "Marketing",
        "kpis": [{"name": "K1", "target": "18%", "frequency": "mensuelle"}],
    })
    result = generate_claude_md(fields)
    assert "claude_md_concept" in result


def test_render_module_prepends_pillar_context_for_known_module():
    module = get_module("FOND-1")
    rendered = render_module(module)
    # Should start with "> **Pillar context — FOND.**"
    first_line = rendered.split("\n", 1)[0]
    assert "Pillar context" in first_line
    assert "FOND" in first_line
    assert "Foundation" in first_line
    # Original module body still present
    assert "# Module FOND-1" in rendered


def test_render_module_handles_pillar_correctly_for_arc():
    module = get_module("ARC-1")
    rendered = render_module(module)
    assert "Pillar context — ARC" in rendered
    assert "Architecture" in rendered


def test_pillar_for_module_helper():
    assert pillar_for_module("FOND-1") == "FOND"
    assert pillar_for_module("arc-2") == "ARC"
    assert pillar_for_module("POC-4") == "POC"
    assert pillar_for_module("") is None
    assert pillar_for_module("invalid") is None
