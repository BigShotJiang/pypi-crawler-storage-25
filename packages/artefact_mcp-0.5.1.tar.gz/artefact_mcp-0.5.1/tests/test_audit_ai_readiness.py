"""Tests for score_ai_readiness (v0.5.0 Free tier audit tool)."""

import pytest

from artefact_mcp.tools.audit_ai_readiness import (
    score_ai_readiness,
    _detect_naming_chaos,
    _score_data_completeness,
    _score_property_governance,
    _score_workflow_coverage,
    _score_lifecycle_discipline,
    _score_sales_process_consistency,
    _score_integration_maturity,
    DIMENSION_WEIGHTS,
    AI_READINESS_EXPLAINER,
)


# --- Sample-data path: PRD acceptance (50-70 mid-maturity) --------------------

class TestSampleDataPath:
    def test_overall_score_in_50_to_70_band(self):
        result = score_ai_readiness(source="sample")
        # PRD acceptance: realistic mid-maturity baseline
        assert 50 <= result["overall_score"] <= 70

    def test_six_dimensions_present(self):
        result = score_ai_readiness(source="sample")
        assert len(result["dimensions"]) == 6

    def test_top_3_blockers_returned(self):
        result = score_ai_readiness(source="sample")
        assert len(result["top_3_blockers"]) == 3
        # Blockers must be the three lowest-scoring dimensions
        scores = sorted(
            (info["score"] for info in result["dimensions"].values())
        )
        blocker_scores = sorted(b["score"] for b in result["top_3_blockers"])
        assert blocker_scores == scores[:3]

    def test_sprint_0_actions_returns_5(self):
        result = score_ai_readiness(source="sample")
        assert len(result["sprint_0_actions"]) == 5

    def test_sprint_0_action_fields(self):
        result = score_ai_readiness(source="sample")
        for a in result["sprint_0_actions"]:
            assert "dimension" in a
            assert "title" in a
            assert "detail" in a
            assert "estimated_lift" in a

    def test_concept_explainer_included(self):
        result = score_ai_readiness(source="sample")
        assert "ai_readiness_concept" in result
        text = result["ai_readiness_concept"].lower()
        # PRD acceptance: explainer covers what AI readiness means in HubSpot context
        assert "ai" in text and "hubspot" in text

    def test_readiness_label_matches_band(self):
        result = score_ai_readiness(source="sample")
        score = result["overall_score"]
        if score >= 75:
            assert "Production-ready" in result["readiness_label"]
        elif score >= 50:
            assert "Mid-maturity" in result["readiness_label"]
        else:
            assert "Not ready" in result["readiness_label"]


# --- Per-dimension calculation ------------------------------------------------

class TestPerDimensionScoring:
    def test_data_completeness_zero_data(self):
        out = _score_data_completeness([], [], [])
        assert out["score"] == 0

    def test_property_governance_no_custom_props(self):
        # No custom props = no governance burden = perfect
        out = _score_property_governance([
            {"name": "email", "is_custom": False},
        ])
        assert out["score"] == 100

    def test_property_governance_penalties(self):
        # 1 deprecated-in-use (-10), 2 low-fill (-10), naming chaos (-10) = 70
        out = _score_property_governance([
            {"name": "tech_stack", "is_custom": True, "is_deprecated": True,
             "referenced_in_workflows": ["WF1"], "fill_rate": 0.5},
            {"name": "abandoned", "is_custom": True, "is_deprecated": False,
             "referenced_in_workflows": [], "fill_rate": 0.02},
            {"name": "techStackV1", "is_custom": True, "is_deprecated": False,
             "referenced_in_workflows": [], "fill_rate": 0.04},
        ])
        # 1 deprecated-in-use (tech_stack): -10
        # 2 low-fill (<=0.05): -10
        # naming chaos (snake + camel): -10
        # = 70
        assert out["score"] == 70

    def test_workflow_coverage_zero_workflows(self):
        out = _score_workflow_coverage([])
        assert out["score"] == 0

    def test_workflow_coverage_all_enabled(self):
        out = _score_workflow_coverage([
            {"is_enabled": True}, {"is_enabled": True},
        ])
        assert out["score"] == 100

    def test_workflow_coverage_half_enabled(self):
        out = _score_workflow_coverage([
            {"is_enabled": True}, {"is_enabled": False},
        ])
        assert out["score"] == 50

    def test_lifecycle_discipline_perfect(self):
        # All contacts in Lead with full history → no orphans
        contacts = [
            {"id": f"X{i}", "properties": {
                "lifecyclestage": "lead",
                "hs_lifecyclestage_lead_date": "2026-04-01T10:00:00Z",
            }}
            for i in range(10)
        ]
        out = _score_lifecycle_discipline(contacts)
        assert out["score"] == 100

    def test_lifecycle_discipline_zero_data(self):
        out = _score_lifecycle_discipline([])
        assert out["score"] == 0

    def test_sales_process_perfect(self):
        from datetime import datetime, timezone
        recent = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        deals = [
            {
                "id": f"D{i}",
                "properties": {
                    "dealname": "OK",
                    "amount": "10000",
                    "dealstage": "stage1",
                    "closedate": "2026-12-31T00:00:00Z",
                    "createdate": recent,
                    "hs_lastmodifieddate": recent,
                    "hubspot_owner_id": "OW",
                },
            }
            for i in range(5)
        ]
        out = _score_sales_process_consistency(deals)
        assert out["score"] == 100

    def test_integration_maturity_no_custom_props(self):
        out = _score_integration_maturity([
            {"name": "email", "is_custom": False},
        ])
        assert out["score"] == 100

    def test_integration_maturity_no_referenced(self):
        out = _score_integration_maturity([
            {"name": "x", "is_custom": True, "referenced_in_workflows": []},
            {"name": "y", "is_custom": True, "referenced_in_workflows": []},
        ])
        assert out["score"] == 0

    def test_integration_maturity_half_referenced(self):
        out = _score_integration_maturity([
            {"name": "x", "is_custom": True, "referenced_in_workflows": ["W1"]},
            {"name": "y", "is_custom": True, "referenced_in_workflows": []},
        ])
        assert out["score"] == 50


# --- Naming chaos detection ---------------------------------------------------

class TestNamingChaos:
    def test_pure_snake_case(self):
        props = [{"name": "tech_stack"}, {"name": "growth_signal"}]
        assert _detect_naming_chaos(props) is False

    def test_pure_camel_case(self):
        props = [{"name": "techStack"}, {"name": "growthSignal"}]
        assert _detect_naming_chaos(props) is False

    def test_pure_pascal_case(self):
        props = [{"name": "TechStack"}, {"name": "GrowthSignal"}]
        assert _detect_naming_chaos(props) is False

    def test_snake_plus_camel_is_chaos(self):
        props = [{"name": "tech_stack"}, {"name": "growthSignal"}]
        assert _detect_naming_chaos(props) is True

    def test_three_conventions_is_chaos(self):
        props = [
            {"name": "tech_stack"},
            {"name": "growthSignal"},
            {"name": "AccountTier"},
        ]
        assert _detect_naming_chaos(props) is True


# --- Edge cases (PRD acceptance) ---------------------------------------------

class TestEdgeCases:
    """PRD: tests cover zero-data, perfect-data, mixed cases."""

    def test_zero_data_returns_zero_overall(self, monkeypatch):
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_ai_readiness.sample_contacts", lambda: []
        )
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_ai_readiness.sample_deals", lambda: []
        )
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_ai_readiness.sample_properties", lambda: []
        )
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_ai_readiness.sample_workflows", lambda: []
        )
        result = score_ai_readiness(source="sample")
        assert result["overall_score"] == 0

    def test_invalid_source_raises(self):
        with pytest.raises(ValueError, match="Invalid source"):
            score_ai_readiness(source="banana")

    def test_hubspot_source_without_client_raises(self):
        with pytest.raises(ValueError, match="HubSpot client required"):
            score_ai_readiness(source="hubspot")


# --- Weights ------------------------------------------------------------------

class TestWeights:
    def test_weights_sum_to_100(self):
        assert sum(DIMENSION_WEIGHTS.values()) == 100


# --- Explainer ----------------------------------------------------------------

class TestExplainer:
    def test_explainer_addresses_six_dimensions(self):
        text = AI_READINESS_EXPLAINER.lower()
        # Each of the six dimensions should be named in the explainer
        for keyword in (
            "completeness",
            "governance",
            "workflow",
            "lifecycle",
            "consistency",
            "integration",
        ):
            assert keyword in text
