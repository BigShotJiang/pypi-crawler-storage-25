"""Tests for audit_property_governance (v0.5.0 Free tier audit tool)."""

import pytest

from artefact_mcp.tools.audit_property_governance import (
    audit_property_governance,
    _classify_naming,
    _detect_deprecated_patterns,
    PROPERTY_GOVERNANCE_EXPLAINER,
)


# --- Sample-data path ---------------------------------------------------------

class TestSampleDataPath:
    def test_total_29_properties(self):
        result = audit_property_governance(source="sample")
        assert result["total_properties"] == 29

    def test_system_vs_custom_split(self):
        result = audit_property_governance(source="sample")
        assert result["system_count"] == 19
        assert result["custom_count"] == 10

    def test_naming_chaos_detected(self):
        result = audit_property_governance(source="sample")
        assert result["naming_chaos"] is True
        # All three conventions present in the fixture
        assert result["naming_distribution"]["snake_case"] >= 1
        assert result["naming_distribution"]["camelCase"] >= 1
        assert result["naming_distribution"]["PascalCase"] >= 1

    def test_low_fill_rate_detected(self):
        result = audit_property_governance(source="sample")
        # Fixture: techStackV1 (0.04), legacy_persona_old (0.02), abandoned_property (0.01)
        assert len(result["low_fill_rate_properties"]) == 3
        names = {p["name"] for p in result["low_fill_rate_properties"]}
        assert names == {"techStackV1", "legacy_persona_old", "abandoned_property"}

    def test_low_fill_sorted_ascending(self):
        result = audit_property_governance(source="sample")
        rates = [p["fill_rate"] for p in result["low_fill_rate_properties"]]
        assert rates == sorted(rates)

    def test_deprecated_in_use_detected(self):
        result = audit_property_governance(source="sample")
        # Fixture: legacy_persona_old is api-flagged AND referenced by WF004
        # techStackV1 is api-flagged but NOT referenced anywhere
        names = {p["name"] for p in result["deprecated_properties_in_use"]}
        assert "legacy_persona_old" in names

    def test_deprecated_active_workflow_flag(self):
        result = audit_property_governance(source="sample")
        for p in result["deprecated_properties_in_use"]:
            if p["name"] == "legacy_persona_old":
                # WF004 is disabled, so still_referenced_by_active_workflow=False
                assert p["still_referenced_by_active_workflow"] is False

    def test_top_10_by_usage(self):
        result = audit_property_governance(source="sample")
        top = result["top_10_by_usage"]
        assert len(top) == 10
        # Sorted descending by usage_count
        usages = [p["usage_count"] for p in top]
        assert usages == sorted(usages, reverse=True)

    def test_concept_explainer_included(self):
        result = audit_property_governance(source="sample")
        assert "property_governance_concept" in result
        text = result["property_governance_concept"].lower()
        assert "property" in text and "governance" in text

    def test_consolidation_plan_present(self):
        result = audit_property_governance(source="sample")
        assert len(result["consolidation_plan"]) >= 1
        # Sample fixture surfaces deprecated + low-fill + chaos → 3 actions
        for c in result["consolidation_plan"]:
            assert c["priority"] in ("high", "medium", "low")
            assert "action" in c and "detail" in c

    def test_custom_to_system_ratio(self):
        result = audit_property_governance(source="sample")
        # 10 / 19 = 0.53 (rounded)
        assert result["custom_to_system_ratio"] == pytest.approx(0.53, abs=0.01)


# --- Naming classifier --------------------------------------------------------

class TestNamingClassifier:
    def test_snake_case(self):
        assert _classify_naming("tech_stack") == "snake_case"
        assert _classify_naming("growth_signal") == "snake_case"

    def test_camel_case(self):
        assert _classify_naming("techStack") == "camelCase"
        assert _classify_naming("decisionAuthority") == "camelCase"

    def test_pascal_case(self):
        assert _classify_naming("TechStack") == "PascalCase"
        assert _classify_naming("BudgetTier") == "PascalCase"

    def test_lowercase_word(self):
        assert _classify_naming("email") == "lowercase"

    def test_empty_string(self):
        assert _classify_naming("") == "unknown"


# --- Deprecated pattern detection ---------------------------------------------

class TestDeprecatedPatternDetection:
    def test_old_suffix(self):
        assert _detect_deprecated_patterns("persona_old") is True

    def test_v1_suffix(self):
        assert _detect_deprecated_patterns("tech_stack_v1") is True

    def test_legacy_suffix(self):
        assert _detect_deprecated_patterns("crm_legacy") is True

    def test_clean_name(self):
        assert _detect_deprecated_patterns("growth_signal") is False

    def test_case_insensitive(self):
        assert _detect_deprecated_patterns("PERSONA_OLD") is True


# --- Edge cases (PRD acceptance) ---------------------------------------------

class TestEdgeCases:
    """PRD: tests cover minimal customization, heavy customization, naming chaos."""

    def test_minimal_customization(self, monkeypatch):
        # Two system fields, zero custom — perfect governance baseline
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_properties",
            lambda: [
                {"name": "email", "label": "Email", "object_type": "contact",
                 "is_custom": False, "fill_rate": 1.0, "usage_count": 100,
                 "is_deprecated": False, "referenced_in_workflows": []},
                {"name": "firstname", "label": "First Name", "object_type": "contact",
                 "is_custom": False, "fill_rate": 1.0, "usage_count": 100,
                 "is_deprecated": False, "referenced_in_workflows": []},
            ],
        )
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_workflows",
            lambda: [],
        )
        result = audit_property_governance(source="sample")
        assert result["custom_count"] == 0
        assert result["naming_chaos"] is False
        assert result["low_fill_rate_properties"] == []
        assert result["deprecated_properties_in_use"] == []
        # Only the "healthy" baseline rec should fire
        assert any("baseline" in c["action"].lower() for c in result["consolidation_plan"])

    def test_heavy_customization(self, monkeypatch):
        # 35 custom snake_case props — only-snake → no chaos, but high count
        custom = [
            {"name": f"custom_field_{i}", "label": f"Custom {i}", "object_type": "contact",
             "is_custom": True, "fill_rate": 0.5, "usage_count": 10,
             "is_deprecated": False, "referenced_in_workflows": []}
            for i in range(35)
        ]
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_properties",
            lambda: custom,
        )
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_workflows",
            lambda: [],
        )
        result = audit_property_governance(source="sample")
        assert result["custom_count"] == 35
        assert result["naming_chaos"] is False
        # The "approaching governance debt" rec should appear when count >30
        assert any(
            "governance debt" in c["action"].lower() for c in result["consolidation_plan"]
        )

    def test_naming_chaos_only(self, monkeypatch):
        # 6 custom props mixing all three conventions, but no other issues
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_properties",
            lambda: [
                {"name": "alpha_one", "is_custom": True, "fill_rate": 0.5,
                 "usage_count": 5, "is_deprecated": False, "referenced_in_workflows": []},
                {"name": "betaTwo", "is_custom": True, "fill_rate": 0.5,
                 "usage_count": 5, "is_deprecated": False, "referenced_in_workflows": []},
                {"name": "GammaThree", "is_custom": True, "fill_rate": 0.5,
                 "usage_count": 5, "is_deprecated": False, "referenced_in_workflows": []},
            ],
        )
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_workflows",
            lambda: [],
        )
        result = audit_property_governance(source="sample")
        assert result["naming_chaos"] is True
        assert any(
            "naming convention" in c["action"].lower() for c in result["consolidation_plan"]
        )

    def test_invalid_source_raises(self):
        with pytest.raises(ValueError, match="Invalid source"):
            audit_property_governance(source="banana")

    def test_hubspot_source_without_client_raises(self):
        with pytest.raises(ValueError, match="HubSpot client required"):
            audit_property_governance(source="hubspot")

    def test_empty_properties_returns_zeros(self, monkeypatch):
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_properties",
            lambda: [],
        )
        monkeypatch.setattr(
            "artefact_mcp.tools.audit_property_governance.sample_workflows",
            lambda: [],
        )
        result = audit_property_governance(source="sample")
        assert result["total_properties"] == 0
        assert result["consolidation_plan"] == []


# --- Explainer ----------------------------------------------------------------

class TestExplainer:
    def test_explainer_addresses_three_failure_patterns(self):
        text = PROPERTY_GOVERNANCE_EXPLAINER.lower()
        # Per Syeda's audit content recommendation: explainer covers what
        # property governance failure looks like.
        assert "explosion" in text or "graveyard" in text
        assert "naming" in text
        assert "deprecated" in text or "legacy" in text or "landmines" in text
