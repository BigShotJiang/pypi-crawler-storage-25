"""Tests for license validation module."""

import json
import time
from unittest.mock import patch, MagicMock

import pytest

from artefact_mcp.core.license import (
    validate_license,
    require_license,
    LicenseInfo,
    _hash_key,
    _read_cache,
    _write_cache,
)


class TestLicenseInfo:
    def test_free_tier_no_key(self):
        """No license key = free tier, still valid."""
        with patch.dict("os.environ", {}, clear=True):
            result = validate_license(None)
            assert result.valid is True
            assert result.tier == "free"

    def test_free_tier_from_env_missing(self):
        """Missing env var = free tier."""
        with patch.dict("os.environ", {}, clear=True):
            result = validate_license()
            assert result.valid is True
            assert result.tier == "free"


class TestRequireLicense:
    def test_sample_always_allowed(self):
        """Sample data works on any tier."""
        free = LicenseInfo(valid=True, tier="free")
        pro = LicenseInfo(valid=True, tier="pro")
        enterprise = LicenseInfo(valid=True, tier="enterprise")

        # Should not raise
        require_license("sample", free)
        require_license("sample", pro)
        require_license("sample", enterprise)

    def test_gating_flag_disabled_bypasses_check(self, monkeypatch):
        """ARTEFACT_LICENSE_GATING_ENABLED=false bypasses all gating —
        emergency kill switch for Lemon Squeezy outages."""
        monkeypatch.setenv("ARTEFACT_LICENSE_GATING_ENABLED", "false")
        free = LicenseInfo(valid=True, tier="free")
        # Would normally raise; with the flag off it should pass.
        require_license("hubspot", free)

    def test_gating_flag_enabled_explicit(self, monkeypatch):
        """ARTEFACT_LICENSE_GATING_ENABLED=true (default) keeps gating active."""
        monkeypatch.setenv("ARTEFACT_LICENSE_GATING_ENABLED", "true")
        free = LicenseInfo(valid=True, tier="free")
        with pytest.raises(ValueError, match="Pro license"):
            require_license("hubspot", free)

    def test_gating_flag_unset_defaults_to_enabled(self, monkeypatch):
        """No env var = gating enabled (safe default)."""
        monkeypatch.delenv("ARTEFACT_LICENSE_GATING_ENABLED", raising=False)
        free = LicenseInfo(valid=True, tier="free")
        with pytest.raises(ValueError, match="Pro license"):
            require_license("hubspot", free)

    def test_hubspot_blocked_on_free(self):
        """HubSpot source requires paid license."""
        free = LicenseInfo(valid=True, tier="free")
        with pytest.raises(ValueError, match="Pro license"):
            require_license("hubspot", free)

    def test_hubspot_allowed_on_pro(self):
        """Pro tier can access HubSpot."""
        pro = LicenseInfo(valid=True, tier="pro")
        require_license("hubspot", pro)  # Should not raise

    def test_hubspot_allowed_on_enterprise(self):
        """Enterprise tier can access HubSpot."""
        enterprise = LicenseInfo(valid=True, tier="enterprise")
        require_license("hubspot", enterprise)  # Should not raise


class TestHashKey:
    def test_consistent(self):
        """Same key produces same hash."""
        h1 = _hash_key("test-key-123")
        h2 = _hash_key("test-key-123")
        assert h1 == h2

    def test_different_keys(self):
        """Different keys produce different hashes."""
        h1 = _hash_key("key-1")
        h2 = _hash_key("key-2")
        assert h1 != h2

    def test_truncated(self):
        """Hash is truncated to 16 chars."""
        h = _hash_key("any-key")
        assert len(h) == 16


class TestCache:
    def test_write_and_read(self, tmp_path):
        """Write then read a cached license."""
        cache_file = tmp_path / "license_cache.json"
        info = LicenseInfo(valid=True, tier="pro", customer_name="Test Corp")

        with patch("artefact_mcp.core.license.CACHE_FILE", cache_file):
            _write_cache("test-key", info)
            result = _read_cache("test-key")

        assert result is not None
        assert result.valid is True
        assert result.tier == "pro"
        assert result.customer_name == "Test Corp"

    def test_cache_miss_wrong_key(self, tmp_path):
        """Wrong key returns None."""
        cache_file = tmp_path / "license_cache.json"
        info = LicenseInfo(valid=True, tier="pro")

        with patch("artefact_mcp.core.license.CACHE_FILE", cache_file):
            _write_cache("key-1", info)
            result = _read_cache("key-2")

        assert result is None

    def test_cache_expired(self, tmp_path):
        """Expired cache returns None."""
        cache_file = tmp_path / "license_cache.json"
        info = LicenseInfo(valid=True, tier="pro")

        with patch("artefact_mcp.core.license.CACHE_FILE", cache_file):
            _write_cache("test-key", info)

            # Manually expire the cache
            data = json.loads(cache_file.read_text())
            data["cached_at"] = time.time() - 100000
            cache_file.write_text(json.dumps(data))

            result = _read_cache("test-key")

        assert result is None

    def test_cache_no_file(self, tmp_path):
        """Missing cache file returns None."""
        cache_file = tmp_path / "nonexistent" / "cache.json"
        with patch("artefact_mcp.core.license.CACHE_FILE", cache_file):
            result = _read_cache("any-key")
        assert result is None


class TestGraceCacheFallback:
    """Gemini cross-review 2026-05-08: any LS API failure must use grace
    cache, not just httpx.ConnectError, so a Pro user is not silently
    downgraded on transient backend errors."""

    def test_remote_5xx_falls_back_to_grace_cache(self, tmp_path):
        from artefact_mcp.core.license import _validate_remote, _write_cache

        cache_file = tmp_path / "license_cache.json"
        cached = LicenseInfo(valid=True, tier="pro", customer_name="Test Co")

        with patch("artefact_mcp.core.license.CACHE_FILE", cache_file):
            _write_cache("test-key-123", cached)

            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                # Simulate 503 Service Unavailable — not a ConnectError
                mock_client.post = MagicMock(return_value=MagicMock(status_code=503))
                mock_client_cls.return_value = mock_client

                result = _validate_remote("test-key-123")

        # Without the Gemini patch this would return valid=False, tier=free.
        # With the patch the 503 path also tries grace cache.
        assert result.valid is True
        assert result.tier == "pro"

    def test_remote_timeout_falls_back_to_grace_cache(self, tmp_path):
        import httpx

        from artefact_mcp.core.license import _validate_remote, _write_cache

        cache_file = tmp_path / "license_cache.json"
        cached = LicenseInfo(valid=True, tier="enterprise", customer_name="Big Co")

        with patch("artefact_mcp.core.license.CACHE_FILE", cache_file):
            _write_cache("ent-key-456", cached)

            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.post = MagicMock(side_effect=httpx.ReadTimeout("slow"))
                mock_client_cls.return_value = mock_client

                result = _validate_remote("ent-key-456")

        assert result.valid is True
        assert result.tier == "enterprise"
        # Error message should explain we used cached validation
        assert "cached" in (result.error or "").lower()

    def test_no_grace_cache_with_failure_returns_free(self, tmp_path):
        """If LS fails AND there's no cache, fall back to free tier (not crash)."""
        import httpx

        from artefact_mcp.core.license import _validate_remote

        cache_file = tmp_path / "no_cache.json"

        with patch("artefact_mcp.core.license.CACHE_FILE", cache_file):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.post = MagicMock(side_effect=httpx.ReadTimeout("slow"))
                mock_client_cls.return_value = mock_client

                result = _validate_remote("uncached-key")

        assert result.valid is False
        assert result.tier == "free"
