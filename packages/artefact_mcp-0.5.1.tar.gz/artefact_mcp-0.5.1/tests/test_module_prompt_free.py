"""Tests for the module_prompt_free tool — P1 Free tier."""

from __future__ import annotations

from artefact_mcp.resources.formula import (
    get_module,
    list_modules,
    render_catalog,
    render_module,
)


def test_list_modules_returns_full_set():
    modules = list_modules()
    assert len(modules) == 34
    ids = {m["id"] for m in modules}
    assert "FOND-1" in ids
    assert "POC-4" in ids
    assert "EXT-5" in ids


def test_get_module_known_id():
    m = get_module("FOND-1")
    assert m is not None
    assert m["title"]
    assert "raw_markdown" in m
    assert m["raw_markdown"].startswith("# Module FOND-1")


def test_get_module_case_insensitive():
    assert get_module("fond-1") is not None
    assert get_module("Fond-1") is not None
    assert get_module(" FOND-1 ") is not None


def test_get_module_unknown_returns_none():
    assert get_module("XYZ-99") is None
    assert get_module("") is None


def test_render_catalog_groups_by_pillar():
    catalog = render_catalog()
    assert "## FOND" in catalog
    assert "## POC" in catalog
    assert "## EXT" in catalog
    for module_id in ["FOND-1", "POC-1", "SKL-3", "EXT-5", "GOV-4"]:
        assert module_id in catalog


def test_render_module_returns_full_markdown():
    m = get_module("FOND-1")
    assert m is not None
    body = render_module(m)
    # v0.4.6: render_module now prepends a "Pillar context" block
    # before the module body. The body itself remains unchanged.
    assert "# Module FOND-1" in body
    assert "QA gate" in body or "qa_gate" in body.lower()


def test_render_module_for_poc_variant():
    """POC modules have a different metadata schema — should still render."""
    m = get_module("POC-1")
    assert m is not None
    body = render_module(m)
    assert "Module POC-1" in body
