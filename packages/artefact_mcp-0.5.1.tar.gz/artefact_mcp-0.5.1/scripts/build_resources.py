"""
Build script: serialize Artefact Formula MOS template (Markdown) into JSON
artifacts embedded in the artefact_mcp package.

Reads:
  projects/systeme-operatoire-ia-template/
    modules/*.md           (34 module files, structured with H2 sections)
    kit-fondation/*.md     (7 reference files, free-form)
    modes/*.md             (4 mode files + README, free-form)

Writes:
  src/artefact_mcp/resources/_data/
    modules.json
    kit_fondation.json
    modes.json
    _build_meta.json

Re-run whenever the template MOS source changes. Output is committed so that
the published wheel does not require the template repo at install time.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

# Local import — scrub lives next to this build script
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scrub import scrub_payload  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
TEMPLATE_DIR = REPO_ROOT / "projects" / "systeme-operatoire-ia-template"
OUTPUT_DIR = (
    Path(__file__).resolve().parent.parent
    / "src"
    / "artefact_mcp"
    / "resources"
    / "_data"
)

H1_PATTERN = re.compile(r"^#\s+(.+?)\s*$", re.MULTILINE)
H2_PATTERN = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
META_LINE_PATTERN = re.compile(r"^\*\*([^*:]+?):\*\*\s*(.+?)\s*$", re.MULTILINE)
MODULE_ID_PATTERN = re.compile(r"^([A-Z]+-\d+)-")
TITLE_AFTER_DASH_PATTERN = re.compile(r"^Module\s+[A-Z]+-\d+\s+[—–-]\s+(.+)$")

SECTION_SLUG_RULES = [
    ("pourquoi", lambda h: h.lower().startswith("pourquoi")),
    ("inputs", lambda h: h.lower().startswith("inputs")),
    ("live_flow", lambda h: h.lower().startswith("live")),
    ("devoirs", lambda h: h.lower().startswith("devoirs")),
    ("output", lambda h: h.lower().startswith("output") or h.lower().startswith("artefact")),
    ("qa_gate", lambda h: h.lower().startswith("qa") or "quality gate" in h.lower()),
    ("pieges", lambda h: h.lower().startswith("piège") or h.lower().startswith("pieges")),
    ("variantes", lambda h: h.lower().startswith("variantes")),
    ("reference", lambda h: h.lower().startswith("référence") or h.lower().startswith("reference")),
    ("module_suivant", lambda h: "suivant" in h.lower()),
]


def slugify_section(heading: str) -> str:
    """Map a free-form H2 heading to a stable slug. Falls back to a normalized form."""
    for slug, matcher in SECTION_SLUG_RULES:
        if matcher(heading):
            return slug
    normalized = re.sub(r"[^\w\s-]", "", heading.lower())
    normalized = re.sub(r"[\s_-]+", "_", normalized).strip("_")
    return normalized or "section"


def extract_h1(text: str) -> str | None:
    match = H1_PATTERN.search(text)
    return match.group(1).strip() if match else None


def extract_module_id(filename: str) -> str | None:
    match = MODULE_ID_PATTERN.match(filename)
    return match.group(1) if match else None


def extract_title(h1: str) -> str:
    """Strip 'Module FOND-1 — ' prefix, keep the rest."""
    match = TITLE_AFTER_DASH_PATTERN.match(h1)
    return match.group(1).strip() if match else h1.strip()


def extract_metadata(text: str) -> dict[str, str]:
    """Extract the **Key:** Value lines that appear before the first '---' divider."""
    head = text.split("\n---\n", 1)[0] if "\n---\n" in text else text[:2000]
    metadata: dict[str, str] = {}
    for match in META_LINE_PATTERN.finditer(head):
        key = match.group(1).strip()
        value = match.group(2).strip()
        metadata[key] = value
    return metadata


def split_sections(text: str) -> dict[str, dict[str, str]]:
    """Split a module's body into sections keyed by stable slug.

    Returns a dict keyed by slug, with shape {"heading": <raw H2>, "body": <markdown>}.
    Sections appearing more than once (e.g. multiple 'Devoirs') are concatenated.
    """
    sections: dict[str, dict[str, str]] = {}
    matches = list(H2_PATTERN.finditer(text))
    if not matches:
        return sections

    for index, match in enumerate(matches):
        heading = match.group(1).strip()
        body_start = match.end()
        body_end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        body = text[body_start:body_end].strip()
        slug = slugify_section(heading)
        if slug in sections:
            sections[slug]["body"] += "\n\n" + body
        else:
            sections[slug] = {"heading": heading, "body": body}
    return sections


def parse_module_file(path: Path) -> dict | None:
    raw = path.read_text(encoding="utf-8")
    module_id = extract_module_id(path.name)
    if not module_id:
        return None
    h1 = extract_h1(raw) or path.stem
    return {
        "id": module_id,
        "filename": path.name,
        "title": extract_title(h1),
        "metadata": extract_metadata(raw),
        "sections": split_sections(raw),
        "raw_markdown": raw,
    }


def parse_freeform_file(path: Path) -> dict:
    raw = path.read_text(encoding="utf-8")
    h1 = extract_h1(raw) or path.stem.replace("-", " ").title()
    return {
        "id": path.stem,
        "filename": path.name,
        "title": h1,
        "raw_markdown": raw,
    }


def collect_modules() -> list[dict]:
    modules_dir = TEMPLATE_DIR / "modules"
    items: list[dict] = []
    for path in sorted(modules_dir.glob("*.md")):
        if path.name == "README.md":
            continue
        parsed = parse_module_file(path)
        if parsed:
            items.append(parsed)
    return items


def collect_freeform(folder: str) -> list[dict]:
    items: list[dict] = []
    for path in sorted((TEMPLATE_DIR / folder).glob("*.md")):
        items.append(parse_freeform_file(path))
    return items


def git_sha(repo: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--short", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def write_json(path: Path, payload: dict) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=False) + "\n",
        encoding="utf-8",
    )


def build() -> dict[str, int]:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    modules = collect_modules()
    kit_fondation = collect_freeform("kit-fondation")
    modes = collect_freeform("modes")

    # Scrub client refs before serializing — sources keep real names, the
    # published wheel must not. See scripts/scrub.py for the substitution map.
    modules = scrub_payload(modules)
    kit_fondation = scrub_payload(kit_fondation)
    modes = scrub_payload(modes)

    sha = git_sha(REPO_ROOT)
    built_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

    write_json(
        OUTPUT_DIR / "modules.json",
        {"build_meta": {"source_sha": sha, "built_at": built_at, "count": len(modules)},
         "modules": modules},
    )
    write_json(
        OUTPUT_DIR / "kit_fondation.json",
        {"build_meta": {"source_sha": sha, "built_at": built_at, "count": len(kit_fondation)},
         "files": kit_fondation},
    )
    write_json(
        OUTPUT_DIR / "modes.json",
        {"build_meta": {"source_sha": sha, "built_at": built_at, "count": len(modes)},
         "files": modes},
    )
    write_json(
        OUTPUT_DIR / "_build_meta.json",
        {
            "source_sha": sha,
            "built_at": built_at,
            "template_dir": str(TEMPLATE_DIR.relative_to(REPO_ROOT)),
            "counts": {
                "modules": len(modules),
                "kit_fondation": len(kit_fondation),
                "modes": len(modes),
            },
        },
    )

    return {"modules": len(modules), "kit_fondation": len(kit_fondation), "modes": len(modes)}


def main() -> int:
    if not TEMPLATE_DIR.is_dir():
        sys.stderr.write(f"Template directory not found: {TEMPLATE_DIR}\n")
        return 1
    counts = build()
    sys.stdout.write(
        f"Built resources to {OUTPUT_DIR.relative_to(Path.cwd()) if OUTPUT_DIR.is_relative_to(Path.cwd()) else OUTPUT_DIR}\n"
    )
    for key, count in counts.items():
        sys.stdout.write(f"  {key}: {count}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
