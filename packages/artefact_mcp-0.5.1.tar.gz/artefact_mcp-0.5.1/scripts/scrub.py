"""Scrub client references from text payloads before they are bundled into
the published wheel.

The published `artefact-mcp` package on PyPI must not carry real client names,
pilot names, or sponsor names. Source `.md` files keep them for internal Synapse
use; this module substitutes them with neutral labels at build time.

Public marks (Synapse, Alex Boissonneault, Code Marketing, Artefact) are
intentionally NOT scrubbed — they are part of Artefact's public surface.

Usage:
    from scripts.scrub import scrub_payload
    payload = scrub_payload(payload)  # recursive on dicts/lists/strings

Compound substitutions (e.g. "Pierre-Luc Bixi" → "[Pilote A — Client A]")
are applied BEFORE simple ones so that "Pierre-Luc Bixi" never produces
"[Pilote A] [Client A]".
"""

from __future__ import annotations

import re
from typing import Any

# Order matters: compounds first, then simple. Each entry is (regex, replacement).
SCRUB_MAP: list[tuple[re.Pattern, str]] = [
    # --- Compound: pilot + client ---
    (re.compile(r"\bPierre[-\s]?Luc\s+Bixi\b"), "[Pilote A — Client A]"),
    # --- Compound: full names (sponsor, pilot, partner) ---
    (re.compile(r"\bDavid\s+Aubert\b"), "[Sponsor B]"),
    (re.compile(r"\bAlexandre\s+Laroche\b"), "[Pilote C]"),
    (re.compile(r"\bM\s+Groupe\s+Conseil\b"), "[Client C]"),
    (re.compile(r"\bPascal[-\s]?Philippe\s+Bergeron\b"), "[Partenaire technique]"),
    (re.compile(r"\bSolarium\s+Optimum\b"), "[Client F]"),
    # --- Simple: client names ---
    (re.compile(r"\bBixi\b"), "[Client A]"),
    (re.compile(r"\bIsothermic\b"), "[Client B]"),
    (re.compile(r"\bComprod\b"), "[Client D]"),
    (re.compile(r"\bCashew\b"), "[Client E]"),
    # --- Simple: pilot/sponsor first names ---
    # Order matters within: Pierre-Luc before bare "Pierre"
    (re.compile(r"\bPierre[-\s]?Luc\b"), "[Pilote A]"),
    # --- Simple: partner alias ---
    (re.compile(r"\bPépé\b"), "[Partenaire technique]"),
]

# Public marks that must NEVER be scrubbed. Used by tests as a regression guard.
PUBLIC_MARKS: tuple[str, ...] = (
    "Synapse",
    "Alex Boissonneault",
    "Code Marketing",
    "Artefact",
)

# All client/personal names that must NOT appear in the built JSON.
SCRUB_TARGETS: tuple[str, ...] = (
    "Bixi",
    "Pierre-Luc",
    "Isothermic",
    "David Aubert",
    "Alexandre Laroche",
    "M Groupe Conseil",
    "Pépé",
    "Pascal-Philippe Bergeron",
    "Comprod",
    "Cashew",
    "Solarium Optimum",
)


def scrub_text(text: str) -> str:
    """Apply the scrub map to a single string. Idempotent."""
    if not text:
        return text
    for pattern, replacement in SCRUB_MAP:
        text = pattern.sub(replacement, text)
    return text


def scrub_payload(value: Any) -> Any:
    """Recursively walk a JSON-shaped payload and scrub all string leaves.

    Returns a new structure (does not mutate the input).
    """
    if isinstance(value, str):
        return scrub_text(value)
    if isinstance(value, list):
        return [scrub_payload(v) for v in value]
    if isinstance(value, dict):
        return {k: scrub_payload(v) for k, v in value.items()}
    return value


def find_unscrubbed(text: str) -> list[str]:
    """Return the list of SCRUB_TARGETS that still appear in the given text.

    Used by the regression test to verify the built JSON is clean.
    """
    found: list[str] = []
    for target in SCRUB_TARGETS:
        if re.search(rf"\b{re.escape(target)}\b", text):
            found.append(target)
    return found
