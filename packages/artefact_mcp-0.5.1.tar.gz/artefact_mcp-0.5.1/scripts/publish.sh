#!/usr/bin/env bash
# Publish artefact-mcp-server to PyPI.
#
# Pattern captured from sentinel proposals 2026-05-07-token_waste_repeated_calls-debian-96355817-{3,7}.
# That session ran the full release flow inline: pytest loop + build + wheel inspect + twine upload + git push.
# Bundled here so the next release is one command.
#
# Usage:
#   scripts/publish.sh [--skip-tests] [--dry-run]
#
# Reads PyPI token via `synapse-secret get 'PYPI -API Credentials'`.
# Bumps nothing — bump pyproject.toml version manually before invoking.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

SKIP_TESTS=0
DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --skip-tests) SKIP_TESTS=1 ;;
    --dry-run)    DRY_RUN=1 ;;
    *) echo "Unknown flag: $arg" >&2; exit 2 ;;
  esac
done

VERSION=$(grep -m1 '^version = ' pyproject.toml | sed -E 's/version = "(.+)"/\1/')
echo "📦 Publishing artefact-mcp-server v${VERSION}"

if [[ -z "${VIRTUAL_ENV:-}" && ! -x .venv/bin/python ]]; then
  echo "❌ No .venv. Run: python -m venv .venv && .venv/bin/pip install -e '.[dev]'" >&2
  exit 1
fi
PYBIN=".venv/bin/python"
[[ -n "${VIRTUAL_ENV:-}" ]] && PYBIN="python"

if (( SKIP_TESTS == 0 )); then
  echo "▶ Running pytest (must pass before publish)..."
  $PYBIN -m pytest -q
fi

echo "▶ Cleaning dist/ and building wheel..."
rm -rf dist/
$PYBIN -m build --wheel --sdist

echo "▶ Verifying wheel contents..."
WHEEL=$(ls dist/*.whl | tail -1)
$PYBIN -c "
import zipfile, sys
z = zipfile.ZipFile('$WHEEL')
names = z.namelist()
must = ['artefact_mcp/server.py', 'artefact_mcp/__init__.py']
missing = [m for m in must if not any(n.endswith(m) for n in names)]
if missing:
    print('❌ Missing from wheel:', missing); sys.exit(1)
print(f'✅ Wheel OK: {len(names)} files, includes {must}')
"

echo "▶ Checking git is clean..."
if [[ -n "$(git status --porcelain)" ]]; then
  echo "❌ Uncommitted changes — commit before publishing." >&2
  git status --short >&2
  exit 1
fi

if (( DRY_RUN == 1 )); then
  echo "✅ Dry run complete. Would have uploaded $WHEEL and tagged v${VERSION}."
  exit 0
fi

echo "▶ Uploading to PyPI..."
TOKEN=$(synapse-secret get 'PYPI -API Credentials')
$PYBIN -m twine upload --username __token__ --password "$TOKEN" dist/*

echo "▶ Tagging v${VERSION} and pushing..."
git tag -a "v${VERSION}" -m "Release v${VERSION}"
git push origin "v${VERSION}"
git push origin "$(git rev-parse --abbrev-ref HEAD)"

echo "✅ Published v${VERSION}: https://pypi.org/project/artefact-mcp-server/${VERSION}/"
