#!/usr/bin/env python3
"""
Quick verification script for RFM threshold configuration.
Tests that custom thresholds correctly override defaults.
"""

from artefact_mcp.core.rfm_thresholds import (
    RFMThresholds,
    DEFAULT_RFM_THRESHOLDS,
    B2B_SERVICE_THRESHOLDS,
    PRESET_THRESHOLDS,
)
from artefact_mcp.core.rfm_scorer import RFMScorer


def test_default_thresholds():
    """Test default RFM thresholds."""
    print("\n=== Test 1: Default Thresholds ===")

    thresholds = DEFAULT_RFM_THRESHOLDS
    config = thresholds.to_scorer_config()
    scorer = RFMScorer(thresholds=config)

    # Test recency scoring
    assert scorer.score_recency(15) == 5  # 0-30 days
    assert scorer.score_recency(60) == 4  # 31-90 days
    assert scorer.score_recency(120) == 3  # 91-180 days
    print("✓ Recency scoring: 15 days → 5, 60 days → 4, 120 days → 3")

    # Test frequency scoring
    assert scorer.score_frequency(12) == 5  # 10+ transactions
    assert scorer.score_frequency(7) == 4  # 5-9 transactions
    assert scorer.score_frequency(1) == 1  # 1 transaction
    print("✓ Frequency scoring: 12 txns → 5, 7 txns → 4, 1 txn → 1")

    # Test monetary scoring (percentile method)
    revenues = [10000, 20000, 30000, 50000, 100000]
    assert scorer.score_monetary(100000, revenues) == 5  # Top
    assert scorer.score_monetary(50000, revenues) == 4
    assert scorer.score_monetary(10000, revenues) == 1  # Bottom
    print("✓ Monetary scoring (percentile): Top → 5, Bottom → 1")

    print("✓ Default thresholds test passed")


def test_custom_thresholds():
    """Test custom RFM thresholds."""
    print("\n=== Test 2: Custom Thresholds ===")

    # Custom thresholds for longer sales cycles
    custom = RFMThresholds(
        recency_days=[90, 180, 365, 730],  # Longer cycles
        frequency_counts=[3, 2, 1, 0],  # Lower frequency expectations
        monetary_method="fixed",  # Fixed thresholds
        monetary_fixed_thresholds=[500000, 200000, 100000, 50000],
    )

    config = custom.to_scorer_config()
    scorer = RFMScorer(thresholds=config)

    # Test custom recency
    assert scorer.score_recency(60) == 5  # 0-90 days
    assert scorer.score_recency(150) == 4  # 91-180 days
    assert scorer.score_recency(300) == 3  # 181-365 days
    print("✓ Custom recency: 60 days → 5, 150 days → 4, 300 days → 3")

    # Test custom frequency
    assert scorer.score_frequency(4) == 5  # 3+ transactions
    assert scorer.score_frequency(2) == 4  # 2 transactions
    assert scorer.score_frequency(1) == 3  # 1 transaction
    print("✓ Custom frequency: 4 txns → 5, 2 txns → 4, 1 txn → 3")

    # Test fixed monetary scoring
    revenues = []  # Not needed for fixed method
    assert scorer.score_monetary(600000, revenues) == 5  # >= 500K
    assert scorer.score_monetary(250000, revenues) == 4  # >= 200K
    assert scorer.score_monetary(150000, revenues) == 3  # >= 100K
    assert scorer.score_monetary(75000, revenues) == 2  # >= 50K
    assert scorer.score_monetary(25000, revenues) == 1  # < 50K
    print("✓ Fixed monetary: $600K → 5, $250K → 4, $25K → 1")

    print("✓ Custom thresholds test passed")


def test_preset_thresholds():
    """Test built-in preset thresholds."""
    print("\n=== Test 3: Preset Thresholds ===")

    # Test B2B Service preset
    b2b_service = B2B_SERVICE_THRESHOLDS
    config = b2b_service.to_scorer_config()
    scorer = RFMScorer(thresholds=config)

    # B2B Service has longer recency thresholds (60, 180, 365, 730)
    assert scorer.score_recency(45) == 5  # 0-60 days
    assert scorer.score_recency(100) == 4  # 61-180 days
    print("✓ B2B Service preset: 45 days → 5, 100 days → 4")

    # Test that all presets are available
    assert "default" in PRESET_THRESHOLDS
    assert "b2b_service" in PRESET_THRESHOLDS
    assert "saas" in PRESET_THRESHOLDS
    assert "manufacturing" in PRESET_THRESHOLDS
    print("✓ All presets available: default, b2b_service, saas, manufacturing")

    print("✓ Preset thresholds test passed")


def test_threshold_conversion():
    """Test RFMThresholds to scorer config conversion."""
    print("\n=== Test 4: Config Conversion ===")

    # Test percentile method config
    percentile_config = RFMThresholds(
        monetary_method="percentile",
        monetary_percentiles=[90, 70, 50, 30]
    )
    config = percentile_config.to_scorer_config()

    assert config["monetary"]["method"] == "percentile"
    assert config["monetary"]["percentiles"] == [90, 70, 50, 30]
    assert "thresholds" not in config["monetary"]
    print("✓ Percentile config conversion correct")

    # Test fixed method config
    fixed_config = RFMThresholds(
        monetary_method="fixed",
        monetary_fixed_thresholds=[1000000, 500000, 250000, 100000]
    )
    config = fixed_config.to_scorer_config()

    assert config["monetary"]["method"] == "fixed"
    assert config["monetary"]["thresholds"] == [1000000, 500000, 250000, 100000]
    assert "percentiles" not in config["monetary"]
    print("✓ Fixed config conversion correct")

    print("✓ Config conversion test passed")


if __name__ == "__main__":
    print("Testing RFM Threshold Configuration")
    print("=" * 50)

    test_default_thresholds()
    test_custom_thresholds()
    test_preset_thresholds()
    test_threshold_conversion()

    print("\n" + "=" * 50)
    print("✅ All tests passed!")
    print("\nRFM threshold configuration is working correctly.")
