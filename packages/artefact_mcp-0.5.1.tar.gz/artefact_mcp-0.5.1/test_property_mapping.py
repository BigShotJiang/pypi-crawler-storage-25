#!/usr/bin/env python3
"""
Quick verification script for property mapping functionality.
Tests that PropertyMapper correctly transforms HubSpot data.
"""

from artefact_mcp.core.property_mappings import PropertyMapping
from artefact_mcp.core.property_mapper import PropertyMapper

def test_default_mapping():
    """Test with default mapping (no custom properties)."""
    print("\n=== Test 1: Default Mapping ===")

    mapping = PropertyMapping()
    mapper = PropertyMapper(mapping)

    hubspot_data = {
        "id": "12345",
        "properties": {
            "name": "Acme Corp",
            "industry": "Technology",
            "annualrevenue": "5000000",
            "numberofemployees": "50",
            "state": "Quebec",
        }
    }

    result = mapper.map_to_icp_input(hubspot_data, deal_count=2)

    print(f"Company: {result['company_name']}")
    print(f"Industry: {result['industry']}")
    print(f"Revenue: ${result['annual_revenue']:,.0f}" if result['annual_revenue'] else "Revenue: None")
    print(f"Employees: {result['employee_count']}")
    print(f"Geography: {result['geography']}")
    print(f"Tech Stack: {result['tech_stack']}")
    print(f"Growth Signals: {result['growth_signals']}")
    print(f"Purchase History: {result['purchase_history']}")

    assert result['company_name'] == "Acme Corp"
    assert result['industry'] == "Technology"
    assert result['annual_revenue'] == 5000000.0
    assert result['employee_count'] == 50
    assert result['geography'] == "Quebec"
    assert result['tech_stack'] == []  # No custom property configured
    assert result['growth_signals'] == []  # No custom properties configured
    assert result['purchase_history'] == "occasional"  # 2 deals

    print("✓ Default mapping test passed")


def test_custom_mapping():
    """Test with custom property mapping."""
    print("\n=== Test 2: Custom Property Mapping ===")

    mapping = PropertyMapping(
        tech_stack="technologies_used",
        tech_stack_delimiter=",",
        growth_signals=["linkedin_hiring_count", "recent_funding"],
        growth_signal_keywords={
            "linkedin_hiring_count": "hiring",
            "recent_funding": "funding",
        },
        content_engagement="page_views",
        content_engagement_thresholds={"active": 10, "occasional": 3},
        decision_maker_access="contact_role",
        budget_authority="budget_status",
        strategic_alignment="growth_conviction",
    )

    mapper = PropertyMapper(mapping)

    hubspot_data = {
        "id": "67890",
        "properties": {
            "name": "TechCo Inc",
            "industry": "SaaS",
            "annualrevenue": "10000000",
            "numberofemployees": "80",
            "state": "Ontario",
            # Custom properties
            "technologies_used": "HubSpot,Google Analytics,Salesforce",
            "linkedin_hiring_count": "5",
            "recent_funding": "Series A",
            "page_views": "15",
            "contact_role": "c_suite",
            "budget_status": "dedicated",
            "growth_conviction": "strong",
        }
    }

    result = mapper.map_to_icp_input(hubspot_data, deal_count=4)

    print(f"Company: {result['company_name']}")
    print(f"Industry: {result['industry']}")
    print(f"Tech Stack: {result['tech_stack']}")
    print(f"Growth Signals: {result['growth_signals']}")
    print(f"Content Engagement: {result['content_engagement']}")
    print(f"Purchase History: {result['purchase_history']}")
    print(f"Decision Maker Access: {result['decision_maker_access']}")
    print(f"Budget Authority: {result['budget_authority']}")
    print(f"Strategic Alignment: {result['strategic_alignment']}")

    assert result['company_name'] == "TechCo Inc"
    assert result['tech_stack'] == ["HubSpot", "Google Analytics", "Salesforce"]
    assert "hiring" in result['growth_signals']
    assert "funding" in result['growth_signals']
    assert result['content_engagement'] == "active"  # 15 >= 10
    assert result['purchase_history'] == "regular"  # 4 >= 3
    assert result['decision_maker_access'] == "c_suite"
    assert result['budget_authority'] == "dedicated"
    assert result['strategic_alignment'] == "strong"

    print("✓ Custom mapping test passed")


def test_threshold_logic():
    """Test engagement and purchase history thresholds."""
    print("\n=== Test 3: Threshold Logic ===")

    mapping = PropertyMapping(
        content_engagement="engagement_score",
        content_engagement_thresholds={"active": 5, "occasional": 1},
    )

    mapper = PropertyMapper(mapping)

    # Test active engagement
    data1 = {"properties": {"engagement_score": "10"}}
    result1 = mapper.map_to_icp_input(data1)
    assert result1['content_engagement'] == "active"
    print(f"✓ Score 10 → active")

    # Test occasional engagement
    data2 = {"properties": {"engagement_score": "3"}}
    result2 = mapper.map_to_icp_input(data2)
    assert result2['content_engagement'] == "occasional"
    print(f"✓ Score 3 → occasional")

    # Test no engagement
    data3 = {"properties": {"engagement_score": "0"}}
    result3 = mapper.map_to_icp_input(data3)
    assert result3['content_engagement'] == "none"
    print(f"✓ Score 0 → none")

    # Test purchase history
    result_regular = mapper.map_to_icp_input(data1, deal_count=5)
    assert result_regular['purchase_history'] == "regular"
    print(f"✓ 5 deals → regular")

    result_occasional = mapper.map_to_icp_input(data1, deal_count=1)
    assert result_occasional['purchase_history'] == "occasional"
    print(f"✓ 1 deal → occasional")

    result_never = mapper.map_to_icp_input(data1, deal_count=0)
    assert result_never['purchase_history'] == "never"
    print(f"✓ 0 deals → never")

    print("✓ Threshold logic test passed")


if __name__ == "__main__":
    print("Testing Property Mapping Implementation")
    print("=" * 50)

    test_default_mapping()
    test_custom_mapping()
    test_threshold_logic()

    print("\n" + "=" * 50)
    print("✅ All tests passed!")
    print("\nProperty mapping implementation is working correctly.")
