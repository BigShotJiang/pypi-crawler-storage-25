# Installing Artefact Formula MCP

> **The GTM Operating System builder for AI-native B2B teams.** Methodology · scaffolds · intelligence tools · 22 guided module prompts.

## Prerequisites

- Python 3.10+
- Optional: HubSpot private app access token (intelligence tools work with demo data without it)
- Optional: Lemon Squeezy license key for Build tier (Free tier needs no key)

## Install

```bash
pip install artefact-mcp
```

Or run directly with uvx (no install needed):

```bash
uvx artefact-mcp
```

**Note:** For MCP server configuration (Claude Desktop, Cursor, etc.), we recommend using the Python method (`python3 -m artefact_mcp`) instead of `uvx` to avoid PATH issues. See configuration sections below.

## Three Tiers

| Tier | Price | License key needed | What you get |
|---|---|---|---|
| **Free** | $0 | No | Methodology resources · auto-diagnostic · CLAUDE.md scaffold · archetype decision tree · second brain guides · 3 intelligence tools with demo data |
| **Build solo** | $200/mo | Yes | All Free + skill scaffolds · sentinelle scaffolds · cost estimator · live HubSpot intelligence · 22 module prompts |
| **Build team** | $500/mo | Yes (multi-seat) | All Build solo + 3-5 user seats |
| **Mandate** | $30K-80K | Yes (consulting bundle, comp'd) | Build team + Alex Boissonneault's animation · entrevues · custom skills · sponsor coaching |

[Purchase a license →](https://artefactventures.lemonsqueezy.com)

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `HUBSPOT_API_KEY` | No | HubSpot private app token (format: `pat-na1-xxxxxxxx`). Without it, use `source="sample"` for demo data. |
| `ARTEFACT_LICENSE_KEY` | No | Lemon Squeezy license key for Build tier. Free tier works without a key. |
| `ARTEFACT_PROPERTY_MAPPING_PATH` | No | Path to JSON file with custom HubSpot property mappings (Build tier only). |
| `ARTEFACT_RFM_THRESHOLDS_PATH` | No | Path to JSON file with custom RFM scoring thresholds (Build tier only). |

## Claude Desktop Configuration

Add to `claude_desktop_config.json`:

**Recommended (Python method):**
```json
{
  "mcpServers": {
    "artefact": {
      "command": "python3",
      "args": ["-m", "artefact_mcp"],
      "env": {
        "HUBSPOT_API_KEY": "pat-na1-xxxxxxxx",
        "ARTEFACT_LICENSE_KEY": "your-build-license-key"
      }
    }
  }
}
```

**Alternative (uvx method):**
```json
{
  "mcpServers": {
    "artefact": {
      "command": "uvx",
      "args": ["artefact-mcp"],
      "env": {
        "HUBSPOT_API_KEY": "pat-na1-xxxxxxxx",
        "ARTEFACT_LICENSE_KEY": "your-build-license-key"
      }
    }
  }
}
```

*Note: If using uvx and seeing "Server disconnected" errors, see [Common Issues](#common-issues) below.*

## Claude Code Configuration

```bash
claude mcp add artefact -- uvx artefact-mcp
```

Or with environment variables:

```bash
claude mcp add artefact \
  -e HUBSPOT_API_KEY=pat-na1-xxxxxxxx \
  -e ARTEFACT_LICENSE_KEY=your-build-license-key \
  -- uvx artefact-mcp
```

## Cursor Configuration

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "artefact": {
      "command": "python3",
      "args": ["-m", "artefact_mcp"],
      "env": {
        "HUBSPOT_API_KEY": "pat-na1-xxxxxxxx",
        "ARTEFACT_LICENSE_KEY": "your-build-license-key"
      }
    }
  }
}
```

## Windsurf Configuration

Add to Windsurf MCP settings with the same structure as Cursor.

## Other MCP-Compatible Clients

The Model Context Protocol is now natively supported across all major LLM providers and IDEs. Artefact Formula MCP works the same way in any MCP client:

- **ChatGPT Desktop** — Apps SDK + Connectors + Developer Mode (full read/write since Oct 2025). Configure via ChatGPT's settings UI or developer mode for custom MCP servers.
- **Google Gemini API · Vertex AI Agent Builder · Gemini CLI** — Native MCP support since Mar 2026. See Google Cloud documentation for MCP server registration.
- **Microsoft Copilot Studio · M365 Copilot · GitHub Copilot · Security Copilot** — GA across the Copilot suite. Configure via Copilot Studio's MCP integration UI.
- **Zed** — Editor with native MCP support. Configure in `~/.config/zed/settings.json`.
- **JetBrains AI Assistant** — Native MCP support across IntelliJ IDEA, PyCharm, etc.
- **Vercel AI SDK · OpenAI Agents SDK** — SDK-level MCP support for custom agents.
- **Ollama · LM Studio** — Local LLM clients with community MCP support.

For all clients, the install is the same: `pip install artefact-mcp` (or `uvx artefact-mcp`), then point your client's MCP configuration at `python3 -m artefact_mcp` with environment variables `HUBSPOT_API_KEY` (optional) and `ARTEFACT_LICENSE_KEY` (Build tier).

## Available Tools After Installation

### Free tier (no license required)

| Tool | Purpose |
|---|---|
| `diagnostic_run` | Scans your workspace, returns current stage and next recommended module |
| `archetype_decision` | Interactive 7-question flow → A/B/C/D archetype + stack suggestions |
| `generate_claude_md` | Generates CLAUDE.md master + 3 referenced project MDs |

### Build tier (Lemon Squeezy license required)

| Tool | Purpose |
|---|---|
| `skill_scaffold` | Generates a complete SKILL.md (frontmatter + steps + examples) |
| `sentinelle_scaffold` | Generates sentinelle SKILL.md + orchestrator config (systemd / cron / routine) |
| `cost_estimate` | Monthly cost breakdown: licence + tokens + infra |
| `run_rfm` | RFM analysis with 11-segment classification, ICP pattern extraction |
| `qualify` | ICP Triangulation across firmographic + behavioral + growth signals |
| `score_pipeline_health` | Pipeline health: velocity, conversion rates, at-risk deals, 0-100 score |

### Build team tier (multi-seat, 22 module prompts)

22 slash prompts covering the full GTM Operating System learning path:
- KCK-1 (kickoff), FOND-1 to FOND-3 (foundation), ARC-1 to ARC-3 (architecture)
- ONB-1 (onboarding), DEC-1 (entrevues), NOT-1 (hub doc)
- WFL-1 (workflows), SKL-1 to SKL-3 (skills)
- SNT-1, SNT-2 (sentinelles), INT-1, INT-2 (interfaces), DSH-1 (dashboard)
- EXT-1, EXT-2 (extension), HDF-1 (handoff)

## Available Resources (Free tier)

| URI | Description |
|---|---|
| `artefact://methodology/5-piliers` | The 5 piliers of the Système Opératoire IA |
| `artefact://methodology/archetypes` | A/B/C/D + decision tree |
| `artefact://methodology/glossaire` | 20 essential terms |
| `artefact://methodology/skills-taxonomy` | Cat 1 / Cat 2 / Cat 3 |
| `artefact://templates/claude-md-master` | Annotated CLAUDE.md template |
| `artefact://guides/second-brain` | PARA · Tiago Forte abridged |
| `methodology://scoring-model` | ICP Triangulation Framework reference |
| `methodology://tier-definitions` | 4-tier classification (Ideal / Strong / Moderate / Poor) |
| `methodology://rfm-segments` | 11 RFM segment definitions |
| `methodology://spiced-framework` | SPICED discovery framework |

## Verify Installation

Ask your AI assistant:
- **Free tier:** "Run a diagnostic on my workspace" · "What archetype fits my organization?" · "Generate a CLAUDE.md for my B2B SaaS company"
- **Build tier:** "Run an RFM analysis on my HubSpot data" · "Scaffold me a first skill for triaging emails" · "Estimate monthly costs for archetype A with 100k tokens/mo and 5 users"
- **Build team:** "/artefact-fond-1" (start the CLAUDE.md Master module guided walkthrough)

## Common Issues

### Server Disconnected (uvx PATH Issue)

**Problem:** "MCP artefact: Server disconnected" error when using `uvx` command.

**Cause:** Claude Desktop and other sandboxed applications may not have access to `uvx` in your PATH. This commonly happens when `uvx` is installed via:
- Homebrew → `~/.local/bin/uvx`
- curl installation → `~/.cargo/bin/uvx`

**Solutions:**

1. **Switch to Python method (recommended):**
   ```json
   {
     "mcpServers": {
       "artefact": {
         "command": "python3",
         "args": ["-m", "artefact_mcp"],
         "env": {}
       }
     }
   }
   ```

2. **Use full uvx path:** Find your uvx location and use the full path:
   ```bash
   which uvx
   # Example output: /Users/yourname/.local/bin/uvx
   ```

   Update config:
   ```json
   {
     "mcpServers": {
       "artefact": {
         "command": "/Users/yourname/.local/bin/uvx",
         "args": ["artefact-mcp"],
         "env": {}
       }
     }
   }
   ```

3. **Verify manually:** Test that the server starts:
   ```bash
   uvx artefact-mcp
   # Should see: "Artefact Formula MCP Server running..."
   ```

### Other Issues

- **"HubSpot API key required"** — Set `HUBSPOT_API_KEY` or use `source="sample"` for demo data
- **"Build license required"** — Set `ARTEFACT_LICENSE_KEY` from your Lemon Squeezy purchase. Free tier tools work without a key.
- **"License expired"** — Your Lemon Squeezy subscription has lapsed. Renew at https://artefactventures.lemonsqueezy.com or contact support if your consulting bundle key has prematurely expired.
- **Import errors with `python3 -m artefact_mcp`** — Ensure package is installed: `pip install artefact-mcp`
- **Server won't start** — Ensure Python 3.10+ and `fastmcp>=2.0` are installed

## Mandate Clients (Consulting Bundle)

If you are an Artefact Ventures mandate client (POC, DIY hosted, or Co-Build), Alex generates a Build tier license key tied to your mandate duration at kickoff. No separate purchase required. At the end of the mandate, you receive an automatic email to convert to Build standalone if you want to keep the system alive.

Mandate setup:
1. Receive consulting bundle key from Alex during kickoff
2. Add `ARTEFACT_LICENSE_KEY=your-bundle-key` to your MCP configuration
3. All Build tier tools are unlocked for the mandate duration
4. At expiration: receive email with one-click conversion to Build standalone (60-80% mandate clients convert)
