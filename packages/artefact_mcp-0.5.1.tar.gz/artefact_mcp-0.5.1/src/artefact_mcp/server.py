"""
Artefact Revenue Intelligence MCP Server

FastMCP server that exposes 3 revenue intelligence tools and 4 methodology resources.
Free tier works with sample data. Pro/Enterprise tiers require ARTEFACT_LICENSE_KEY.
"""

import functools
import json
import os
import sys
from typing import Optional

from fastmcp import FastMCP

from artefact_mcp import __version__ as MCP_VERSION
from artefact_mcp.core.hubspot_client import HubSpotClient
from artefact_mcp.core.license import validate_license, require_license, LicenseInfo
from artefact_mcp.core.usage_logger import log_usage
from artefact_mcp.core.property_mappings import PropertyMapping, DEFAULT_PROPERTY_MAPPING
from artefact_mcp.core.rfm_thresholds import RFMThresholds
from artefact_mcp.core.config_validator import (
    load_json_safely,
    validate_property_mapping_config,
    validate_rfm_thresholds_config,
    sanitize_error_message,
)
from artefact_mcp.tools.rfm import run_rfm_analysis
from artefact_mcp.tools.icp import qualify_prospect
from artefact_mcp.tools.pipeline import score_pipeline
from artefact_mcp.tools.audit_lifecycle import audit_lifecycle_stages as _audit_lifecycle_stages
from artefact_mcp.tools.audit_pipeline_hygiene import audit_pipeline_hygiene as _audit_pipeline_hygiene
from artefact_mcp.tools.audit_ai_readiness import score_ai_readiness as _score_ai_readiness
from artefact_mcp.tools.audit_property_governance import audit_property_governance as _audit_property_governance
from artefact_mcp.resources.methodology import get_resource, list_resources
from artefact_mcp.resources.formula import (
    archetype_decision as _archetype_decision,
    auto_diagnose as _auto_diagnose,
    gate_check as _gate_check,
    generate_claude_md as _generate_claude_md,
    get_module,
    render_catalog,
    render_module,
)

# --- License validation at startup ---
_license: LicenseInfo = validate_license()

if not _license.valid:
    print(f"[Artefact MCP] License error: {_license.error}", file=sys.stderr)
    print("[Artefact MCP] Running in free mode (sample data only).", file=sys.stderr)
    _license.tier = "free"
elif _license.tier == "free":
    print("[Artefact MCP] No license key found. Running in free mode (sample data only).", file=sys.stderr)
    print("[Artefact MCP] Purchase a license at https://artefactventures.lemonsqueezy.com", file=sys.stderr)
else:
    print(f"[Artefact MCP] License valid — tier: {_license.tier}", file=sys.stderr)
    if _license.customer_name:
        print(f"[Artefact MCP] Licensed to: {_license.customer_name}", file=sys.stderr)

# --- Load property mapping configuration (Pro/Enterprise only) ---
_property_mapping: Optional[PropertyMapping] = None
_property_mapping_errors: list[str] = []

if _license.tier in ("pro", "enterprise"):
    mapping_path = os.getenv("ARTEFACT_PROPERTY_MAPPING_PATH")
    if mapping_path:
        # Load and validate configuration securely
        config, error = load_json_safely(mapping_path)
        if error:
            print(f"[Artefact MCP] Property mapping validation failed: {error}", file=sys.stderr)
            print("[Artefact MCP] Using default property mapping.", file=sys.stderr)
            _property_mapping_errors.append(error)
            _property_mapping = DEFAULT_PROPERTY_MAPPING
        else:
            # Validate configuration structure
            is_valid, errors = validate_property_mapping_config(config)
            if not is_valid:
                print(f"[Artefact MCP] Property mapping configuration errors:", file=sys.stderr)
                for err in errors:
                    print(f"  - {err}", file=sys.stderr)
                print("[Artefact MCP] Using default property mapping.", file=sys.stderr)
                _property_mapping_errors.extend(errors)
                _property_mapping = DEFAULT_PROPERTY_MAPPING
            else:
                try:
                    _property_mapping = PropertyMapping(**config)
                    print(f"[Artefact MCP] Loaded custom property mapping", file=sys.stderr)
                except Exception as e:
                    safe_error = sanitize_error_message(e)
                    print(f"[Artefact MCP] Failed to create property mapping: {safe_error}", file=sys.stderr)
                    print("[Artefact MCP] Using default property mapping.", file=sys.stderr)
                    _property_mapping_errors.append(safe_error)
                    _property_mapping = DEFAULT_PROPERTY_MAPPING
    else:
        _property_mapping = DEFAULT_PROPERTY_MAPPING

# --- Load RFM threshold configuration (Pro/Enterprise only) ---
_rfm_thresholds: Optional[RFMThresholds] = None
_rfm_thresholds_errors: list[str] = []

if _license.tier in ("pro", "enterprise"):
    rfm_path = os.getenv("ARTEFACT_RFM_THRESHOLDS_PATH")
    if rfm_path:
        # Load and validate configuration securely
        config, error = load_json_safely(rfm_path)
        if error:
            print(f"[Artefact MCP] RFM thresholds validation failed: {error}", file=sys.stderr)
            print("[Artefact MCP] Using default RFM thresholds.", file=sys.stderr)
            _rfm_thresholds_errors.append(error)
        else:
            # Validate configuration structure
            is_valid, errors = validate_rfm_thresholds_config(config)
            if not is_valid:
                print(f"[Artefact MCP] RFM thresholds configuration errors:", file=sys.stderr)
                for err in errors:
                    print(f"  - {err}", file=sys.stderr)
                print("[Artefact MCP] Using default RFM thresholds.", file=sys.stderr)
                _rfm_thresholds_errors.extend(errors)
            else:
                try:
                    _rfm_thresholds = RFMThresholds(**config)
                    print(f"[Artefact MCP] Loaded custom RFM thresholds", file=sys.stderr)
                except Exception as e:
                    safe_error = sanitize_error_message(e)
                    print(f"[Artefact MCP] Failed to create RFM thresholds: {safe_error}", file=sys.stderr)
                    print("[Artefact MCP] Using default RFM thresholds.", file=sys.stderr)
                    _rfm_thresholds_errors.append(safe_error)

# --- Server ---

mcp = FastMCP(
    "Artefact Formula MCP",
    instructions=(
        "Artefact Formula MCP exposes the Artefact methodology as callable tools for B2B teams.\n\n"
        "ROUTING RULES (read carefully before choosing a tool):\n"
        "1. If the user asks to start, build, set up, scaffold, or explore their AI Operating System / "
        "Système opératoire IA / GTM Operating System / methodology / Synapse build / pilote, "
        "FIRST call `module_prompt_free` (no args) to load the catalog OR `auto_diagnose` to recommend "
        "the right deployment mode and starting module. Do NOT default to revenue intelligence tools.\n"
        "2. If the user asks to choose an archetype / stack / infrastructure (open vs Microsoft vs Google "
        "vs on-prem), call `archetype_decision`.\n"
        "3. If the user asks to create / generate / scaffold their CLAUDE.md or master prompt file, "
        "call `generate_claude_md`.\n"
        "4. If the user asks whether they can advance / passed a module gate / completed devoirs, "
        "call `gate_check`.\n"
        "5. ONLY when the user explicitly asks about HubSpot revenue intelligence (RFM, ICP scoring, "
        "pipeline health, prospect qualification with HubSpot data) call `run_rfm`, `qualify`, or "
        "`score_pipeline_health`. Never default to these tools for general 'what should I do' or "
        "'help me build' questions.\n\n"
        "When the user opens a session for the first time or says hi, read methodology://welcome and "
        "respond per its guidance (orient them to the 5 slash commands).\n\n"
        "USER CONTEXT — IMPORTANT:\n"
        "The user IS THEIR OWN pilot. They are a B2B operator, founder, or consultant building their "
        "OWN GTM Operating System for THEIR OWN company or client. Do NOT offer 'Use a current "
        "Artefact Ventures situation' or 'Use an internal Artefact case' as menu options. The user "
        "has no access to Artefact Ventures internal data and the methodology references inside "
        "the modules are anonymized examples ([Client A], [Pilote A], etc.), not actionable cases. "
        "When the user provides empty context, ask them to describe THEIR situation in their own "
        "words rather than offering them fictitious options."
    ),
)


def _get_hubspot_client() -> Optional[HubSpotClient]:
    """Create a HubSpot client if API key is available."""
    api_key = os.getenv("HUBSPOT_API_KEY")
    if api_key:
        return HubSpotClient(api_key)
    return None


def _logged(tool_name: str):
    """Decorator that emits a usage event after the tool completes.

    No-op when ARTEFACT_USAGE_LOG_ENDPOINT/KEY env vars are unset (see
    core.usage_logger). Distinguishes between exceptions and tool-level
    JSON errors. Preserves the original signature via functools.wraps so
    FastMCP's @mcp.tool() decorator sees the right schema.
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            success = True
            error_code = None
            source = kwargs.get("source")
            try:
                result = fn(*args, **kwargs)
                # Detect tool-level error returned as JSON (catches the
                # try/except blocks inside each tool body that return
                # {"error": ...} on failure).
                if isinstance(result, str):
                    try:
                        parsed = json.loads(result)
                        if isinstance(parsed, dict) and "error" in parsed:
                            success = False
                            error_code = "tool_error"
                    except (ValueError, TypeError):
                        pass
                return result
            except Exception as e:
                success = False
                error_code = type(e).__name__
                raise
            finally:
                log_usage(
                    tool_name=tool_name,
                    tier=_license.tier,
                    source=source,
                    success=success,
                    error_code=error_code,
                    license_key=os.getenv("ARTEFACT_LICENSE_KEY"),
                    mcp_version=MCP_VERSION,
                )
        return wrapper
    return decorator


# --- Tools ---


@mcp.tool()
@_logged("module_prompt_free")
def module_prompt_free(module_id: Optional[str] = None) -> str:
    """Browse the Artefact Formula 34-module catalog OR load any module's full body.

    CALL THIS TOOL WHEN THE USER ASKS TO:
    - Start, build, or set up their Système opératoire IA / AI Operating System / GTM OS / Synapse build
    - Explore the Artefact methodology, modules, pillars, or devoirs
    - See "what modules are available" or "show me the catalog"
    - Load a specific module body (FOND-1, ARC-2, POC-1, etc.)
    - Get the facilitation script for any methodology module

    DO NOT call run_rfm, qualify, or score_pipeline_health for these queries —
    those are HubSpot revenue intelligence tools, not methodology browsers.

    The 34 modules are organized across pillars: FOND (foundation), ARC
    (architecture), SKL (skills library), WFL (workflows), SNT (sentinelles /
    governance signals), GOV (governance), INT (interfaces), EXT (export and
    handoff), plus mode-specific POC and DIY modules.

    Each module is a 60-90 min facilitation script with: pourquoi (why),
    inputs, live flow, devoirs (homework), output, QA gate, pièges (pitfalls),
    variantes par mode, référence canonique, module suivant.

    Args:
        module_id: Module ID like "FOND-1", "POC-2", "SKL-3". Case-insensitive.
                   If omitted, returns the full catalog grouped by pillar.

    Returns:
        Markdown — either the module catalog (no ID) or the full module body.
    """
    if not module_id:
        return render_catalog()
    module = get_module(module_id)
    if not module:
        return (
            f"# Module not found\n\n"
            f"Unknown module ID: `{module_id}`. "
            f"Call `module_prompt_free()` (no argument) to see all 34 module IDs grouped by pillar."
        )
    return render_module(module)


@mcp.tool()
@_logged("archetype_decision")
def archetype_decision(
    loi_25_strict: bool = False,
    m365_dominant: bool = False,
    google_workspace_dominant: bool = False,
    sovereignty_extreme: bool = False,
    can_adopt_open: bool = True,
) -> str:
    """Recommend a technical archetype (A/B/C/D) for a Système opératoire IA build.

    CALL THIS TOOL WHEN THE USER ASKS TO:
    - Choose their archetype, stack, infrastructure, or technology platform
    - Decide between open-source vs Microsoft 365 vs Google Workspace vs on-prem
    - Get a recommendation on Loi 25 / sovereignty / data residency
    - Compare Claude vs Gemini vs Copilot for their AI Operating System

    Implements the canonical Artefact decision tree from the kit-fondation:
    5 yes/no questions return archetype + stack + 3 advantages + 3 constraints +
    decision path traced for transparency.

    The 4 archetypes:
    - A: Open / souverain (Claude + Notion + Supabase + OVH Beauharnois). Default.
    - B: Google-natif (Gemini + Drive + Vertex AI + GCP Montreal)
    - C: Microsoft-natif (Copilot + SharePoint + Azure OpenAI + Azure Canada)
    - D: Hybride / on-prem (Llama or Mistral + Postgres self-hosted + bare metal)

    Args:
        loi_25_strict: Client is bound by strict Loi 25 (public sector, health,
                       finance) — typically forces archetype A.
        m365_dominant: Client uses Microsoft 365 (Outlook + Teams + SharePoint)
                       on >80% of workflows with Copilot licenses.
        google_workspace_dominant: Client uses Google Workspace on >80% of
                                   workflows.
        sovereignty_extreme: Data must never leave the client's physical
                             perimeter (health, defense, sensitive R&D).
        can_adopt_open: Client willing to adopt open-source / non-Microsoft /
                        non-Google tooling (default True).

    Returns:
        JSON with archetype code, name, stack, ideal_for, advantages,
        constraints, decision_path, next_module.
    """
    result = _archetype_decision(
        loi_25_strict=loi_25_strict,
        m365_dominant=m365_dominant,
        google_workspace_dominant=google_workspace_dominant,
        sovereignty_extreme=sovereignty_extreme,
        can_adopt_open=can_adopt_open,
    )
    return json.dumps(result, indent=2, ensure_ascii=False)


@mcp.tool()
@_logged("auto_diagnose")
def auto_diagnose(context: str = "") -> str:
    """First tool to call when the user wants to start their AI Operating System build.

    CALL THIS TOOL WHEN THE USER ASKS:
    - "Where do I start / par quoi je commence / démarre le build"
    - "Help me build my Système opératoire IA / GTM OS / AI Operating System"
    - "What deployment mode fits my pilot"
    - "Start the Synapse build / start my methodology setup"
    - Any open-ended "what should I do first" question about the methodology

    DO NOT default to run_rfm or score_pipeline_health for these queries —
    those are HubSpot revenue intelligence tools and inappropriate for
    methodology setup or system build questions.

    Hybrid heuristics on 4 modes (Self-Serve / POC / DIY / Co-Build) with
    bilingual French + English keyword detection. Falls back to a structured
    framing question set when input is empty or signals are ambiguous.

    Output JSON contract:
      mode: "Self-Serve" | "POC" | "DIY" | "Co-Build" | null
      confidence: "high" | "medium" | "framing"
      starting_module: e.g. "FOND-1", "POC-1", "DIY-1"
      parallel_modules: list of module IDs to load alongside (e.g. ["ARC-1"])
      next_module_after_starting: module to suggest after starting_module
      alternatives: ranked list of next-best modes with why_not rationales
      disambiguation_questions: populated when confidence is "medium" or "framing"
      signals_detected: keyword hits with weights (transparent reasoning trace)
      archetype_hint: optional A/B/C/D when infra signals detected
      reasoning: EN-first prose with FR keywords cited verbatim

    Args:
        context: Free-text description of the pilot's situation — function,
                 current state, urgency, constraints, engagement signals.
                 Empty input returns the framing questions.

    Returns:
        JSON string with the structured recommendation.
    """
    result = _auto_diagnose(context=context)
    return json.dumps(result, indent=2, ensure_ascii=False)


@mcp.tool()
@_logged("generate_claude_md")
def generate_claude_md(fields: str = "") -> str:
    """Render a CLAUDE.md master scaffold for a Système opératoire IA pilot.

    CALL THIS TOOL WHEN THE USER ASKS TO:
    - Create / generate / scaffold their CLAUDE.md or master prompt file
    - Set up the foundation file for their AI Operating System
    - Start the FOND-1 module
    - Code their business logic into a markdown master file

    Implements module FOND-1 (the bloquant entry point of Sprint 1) as a
    callable tool. The output is a 5-section markdown master file that codes
    the pilot's business logic. The only file that survives an LLM or infra
    swap.

    Hybrid behavior (option D):
      - Empty input → returns the raw template with placeholders intact
        (completeness="template"), so an agent can read the structure and ask
        the pilot for each field.
      - Partial dict → renders with markers + missing_required_fields
        populated (completeness="partial").
      - Complete dict → clean render (completeness="complete").
      - Invalid JSON → returns {"error": ...} (does not raise).

    Required fields: client_name, pilot.first_name, pilot.role, function,
    kpis (>= 1).
    Recommended: sponsor.first_name, sector, team_size, mandate_name,
    kickoff_date, language, icp_description.

    Validates KPIs (max 3, must have target + frequency or warning fires)
    and total length (80-150 lines per FOND-1 strict limit).

    Args:
        fields: JSON string. Schema example:
            {
              "client_name": "Bixi",
              "sector": "Mobilité urbaine",
              "team_size": "~80 personnes",
              "pilot": {"first_name": "...", "last_name": "...", "role": "..."},
              "sponsor": {"first_name": "...", "last_name": "...", "role": "..."},
              "function": "Marketing",
              "mandate_name": "Marketing OS Phase 1",
              "kickoff_date": "2026-04-17",
              "phase_1_end_date": "2026-06-30",
              "products_list": "...",
              "icp_description": "...",
              "constraints": "...",
              "transitions": "...",
              "collaborators": [{"name": "...", "role": "...", "scope": "..."}],
              "kpis": [
                {"name": "...", "target": "...", "frequency": "..."}
              ],
              "language": "Français",
              "tone": "Professionnel",
              "linked_project_mds": ["produit", "fonction", "workflow"]
            }

    Returns:
        JSON with rendered_markdown, completeness, missing_required_fields,
        missing_recommended_fields, warnings, qa_gate_questions, next_module.
    """
    result = _generate_claude_md(fields=fields)
    return json.dumps(result, indent=2, ensure_ascii=False)


@mcp.tool()
@_logged("gate_check")
def gate_check(module_id: str = "", evidence: str = "") -> str:
    """Validate a module's QA gate against pilot evidence.

    CALL THIS TOOL WHEN THE USER ASKS:
    - "Did I complete the FOND-1 / ARC-1 / SKL-2 (etc.) module?"
    - "Can I advance to the next module?"
    - "Validate my devoirs / homework for module X"
    - "Check if my gate is green / passed / red / blocked"
    - "Am I ready for the next sprint?"

    Every Artefact Formula module ends with a binary QA gate, a checklist
    that must clear before the pilot advances to the next module. This tool
    parses the gate, accepts evidence, and returns pass / fail per item plus
    an advancement signal.

    Hybrid behavior (option C):
      - Empty input → returns the framing + list of all modules with gates
      - module_id only → returns the gate as a pending checklist
      - module_id + evidence → returns full evaluation with next_module if
        all items pass

    Evidence format (JSON string):
      - List positionally aligned to gate items:
        `[true, true, "Loi 25 confirmé par sponsor", null]`
      - Or dict keyed by 1-indexed item number:
        `{"1": true, "2": true, "3": "see Notion changelog"}`

    Evidence semantics:
      - True / non-empty string → passes
      - False / null / missing → does not pass
      - String with negative tokens (non, pas encore, todo, tbd, à confirmer)
        → counts as fail, not pass

    Args:
        module_id: Module ID like "FOND-1", "ARC-2", "POC-4". Case-insensitive.
        evidence: Optional JSON string (list or dict) with evidence per item.

    Returns:
        JSON with module_id, gate_status (framing/pending/pass/partial/fail),
        gate_items (per-item evaluation), items_passed/items_total,
        blocking_failures, missing_evidence, next_module (if pass),
        advancement_blocked, guidance.
    """
    result = _gate_check(module_id=module_id, evidence=evidence)
    return json.dumps(result, indent=2, ensure_ascii=False)


@mcp.tool()
@_logged("audit_lifecycle_stages")
def audit_lifecycle_stages(
    source: str = "hubspot",
    pipeline_id: Optional[str] = None,
) -> str:
    """Audit HubSpot lifecycle stage discipline (Lead vs MQL vs SQL drift). Free tier.

    CALL THIS TOOL when the user asks to:
    - Audit / check / review their HubSpot lifecycle stages
    - Find Lead vs MQL vs SQL drift, orphaned contacts, lifecycle skips
    - Diagnose why MQL or SQL counts look wrong
    - Understand "lead vs lifecycle" before an AI rollout

    Surfaces (1) counts per lifecycle stage, (2) orphan contacts that skipped
    a prior stage, (3) median age in current stage, and (4) 3-5 specific
    HubSpot config recommendations to fix drift. Includes an embedded
    explainer of the lifecycle vs lead-status distinction.

    Free tier: works on built-in sample data (source='sample') without a
    HubSpot key, OR on live HubSpot when HUBSPOT_API_KEY is set.

    Args:
        source: "hubspot" for live data (auto-falls-back to sample if no key),
                "sample" for the built-in 30-contact mid-maturity fixture.
        pipeline_id: Reserved for future scoping. Currently surfaced in
                response notes but not honored.

    Returns:
        JSON with stage_counts, orphan_count + sample, stage_age_distribution,
        recommendations, and lifecycle_concept explainer.
    """
    # Free tier: auto-fallback to sample if HubSpot key is missing.
    effective_source = source
    if source == "hubspot" and not os.getenv("HUBSPOT_API_KEY"):
        effective_source = "sample"

    client = _get_hubspot_client() if effective_source == "hubspot" else None
    try:
        result = _audit_lifecycle_stages(
            source=effective_source,
            pipeline_id=pipeline_id,
            hubspot_client=client,
        )
        if effective_source != source:
            result.setdefault("notes", []).insert(
                0,
                "HUBSPOT_API_KEY not set — falling back to built-in sample fixture.",
            )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if client:
            client.close()


@mcp.tool()
@_logged("audit_pipeline_hygiene")
def audit_pipeline_hygiene(
    source: str = "hubspot",
    pipeline_id: Optional[str] = None,
    staleness_days: int = 30,
) -> str:
    """Audit HubSpot deal pipeline for stale deals, missing fields, stage abuse, age outliers. Free tier.

    CALL THIS TOOL when the user asks to:
    - Audit / clean up / hygiene-check their HubSpot pipeline
    - Find stale deals, missing fields, deals stuck in a stage
    - Diagnose forecast accuracy issues from dirty deal data
    - Pre-flight pipeline data before connecting an AI tool

    Surfaces (1) stale deals (no modification in N days), (2) deals missing
    dealname/amount/closedate/owner, (3) stage abuse (>=50% of deals in a
    stage older than 60 days), (4) age outliers (deals 3x+ the stage median),
    plus impact-ranked HubSpot config recommendations.

    Free tier: works on built-in sample data without a HubSpot key, OR on live
    HubSpot when HUBSPOT_API_KEY is set.

    Args:
        source: "hubspot" for live data (auto-falls-back to sample if no key),
                "sample" for the built-in 8-deal mid-maturity fixture.
        pipeline_id: Optional pipeline ID to scope the audit.
        staleness_days: Days without modification before a deal counts as
                stale (default 30).

    Returns:
        JSON with stale deals, missing fields, stage abuses, age outliers,
        recommendations, and pipeline_hygiene_concept explainer.
    """
    effective_source = source
    if source == "hubspot" and not os.getenv("HUBSPOT_API_KEY"):
        effective_source = "sample"

    client = _get_hubspot_client() if effective_source == "hubspot" else None
    try:
        result = _audit_pipeline_hygiene(
            source=effective_source,
            pipeline_id=pipeline_id,
            staleness_days=staleness_days,
            hubspot_client=client,
        )
        if effective_source != source:
            result.setdefault("notes", []).insert(
                0,
                "HUBSPOT_API_KEY not set — falling back to built-in sample fixture.",
            )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if client:
            client.close()


@mcp.tool()
@_logged("score_ai_readiness")
def score_ai_readiness(source: str = "hubspot") -> str:
    """Score HubSpot AI readiness 0-100 across 6 weighted dimensions. Free tier.

    CALL THIS TOOL when the user asks to:
    - Score / assess / evaluate HubSpot for AI readiness
    - Diagnose what to fix before deploying an AI / Copilot / agent on HubSpot
    - Get a CRM maturity baseline

    The 6 dimensions (each 0-100, weighted to single overall):
    1. Data Completeness (20%) — system + custom field fill rates
    2. Property Governance (15%) — deprecated/low-fill/naming chaos penalties
    3. Workflow Coverage (15%) — active vs total workflows
    4. Lifecycle Discipline (20%) — orphan/stage-skip rate
    5. Sales Process Consistency (15%) — missing/stale/abused-stage deal metrics
    6. Integration Maturity (15%) — % of custom properties wired to workflows

    Free tier: works on built-in sample data without a HubSpot key, OR on live
    HubSpot when HUBSPOT_API_KEY is set. Live mode degrades gracefully if the
    properties or workflows API scope is not granted.

    Args:
        source: "hubspot" for live data (auto-falls-back to sample if no key),
                "sample" for the built-in mid-maturity fixture (lands ~55).

    Returns:
        JSON with overall_score, per-dimension scores + evidence, top_3_blockers,
        sprint_0_actions (5 ranked), and ai_readiness_concept explainer.
    """
    effective_source = source
    if source == "hubspot" and not os.getenv("HUBSPOT_API_KEY"):
        effective_source = "sample"

    client = _get_hubspot_client() if effective_source == "hubspot" else None
    try:
        result = _score_ai_readiness(
            source=effective_source,
            hubspot_client=client,
        )
        if effective_source != source:
            result.setdefault("notes", []).insert(
                0,
                "HUBSPOT_API_KEY not set — falling back to built-in sample fixture.",
            )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if client:
            client.close()


@mcp.tool()
@_logged("audit_property_governance")
def audit_property_governance(source: str = "hubspot") -> str:
    """Audit HubSpot custom property hygiene (count, naming, fill rate, deprecated). Free tier.

    CALL THIS TOOL when the user asks to:
    - Audit / clean up / consolidate their HubSpot custom properties
    - Find low-fill / deprecated / inconsistently-named properties
    - Reduce CRM property explosion before adding new ones

    Surfaces (1) custom-to-system property ratio, (2) naming convention
    distribution + chaos detection, (3) properties with <=5% fill rate,
    (4) deprecated properties still referenced by workflows, (5) top 10
    properties by usage count, plus a prioritized consolidation plan.

    Free tier: works on built-in sample data without a HubSpot key, OR on
    live HubSpot when HUBSPOT_API_KEY is set. Live mode is best-effort —
    fill rate and workflow references aren't fully exposed by the v3
    properties API and become richer in v0.6.0.

    Args:
        source: "hubspot" for live data (auto-falls-back to sample if no key),
                "sample" for the built-in 29-property mid-maturity fixture.

    Returns:
        JSON with property counts, naming analysis, low-fill list, deprecated
        list, top-10 usage list, consolidation plan, and concept explainer.
    """
    effective_source = source
    if source == "hubspot" and not os.getenv("HUBSPOT_API_KEY"):
        effective_source = "sample"

    client = _get_hubspot_client() if effective_source == "hubspot" else None
    try:
        result = _audit_property_governance(
            source=effective_source,
            hubspot_client=client,
        )
        if effective_source != source:
            result.setdefault("notes", []).insert(
                0,
                "HUBSPOT_API_KEY not set — falling back to built-in sample fixture.",
            )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if client:
            client.close()


@mcp.tool()
@_logged("run_rfm")
def run_rfm(
    source: str = "hubspot",
    industry_preset: str = "default",
) -> str:
    """RFM (Recency, Frequency, Monetary) analysis on HubSpot client data. Pro tier.

    ONLY CALL THIS TOOL when the user EXPLICITLY asks for RFM analysis,
    customer segmentation, or scores clients based on purchase behavior.
    Do NOT call this for general "build my system" or "where do I start"
    questions; for those, route to module_prompt_free or auto_diagnose.

    Requires a HubSpot API key for live data. Segments clients into 11
    categories (Champions through Lost) and extracts ICP patterns from
    top performers.

    Args:
        source: Data source — "hubspot" for live HubSpot data, "sample" for built-in demo data.
        industry_preset: Scoring preset — "b2b_service", "saas", "manufacturing", or "default".

    Returns:
        JSON with scored clients, segment distribution, ICP patterns, and tier recommendations.
    """
    try:
        require_license(source, _license)
    except ValueError as e:
        return json.dumps({"error": str(e)})

    client = _get_hubspot_client() if source == "hubspot" else None
    try:
        result = run_rfm_analysis(
            source=source,
            industry_preset=industry_preset,
            hubspot_client=client,
            custom_thresholds=_rfm_thresholds if _license.tier != "free" else None,
        )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if client:
            client.close()


@mcp.tool()
@_logged("qualify")
def qualify(
    company_id: Optional[str] = None,
    company_data: Optional[str] = None,
) -> str:
    """Score a SPECIFIC prospect against the ICP Triangulation Framework. Pro tier.

    ONLY CALL THIS TOOL when the user EXPLICITLY provides a specific
    prospect / company / lead to qualify with HubSpot or company data.
    Do NOT call this for general "build my system" or "what should I do"
    questions; for those, route to module_prompt_free or auto_diagnose.

    Goes beyond demographics by triangulating across three dimensions:
    - Firmographic Fit: Who they are (industry, revenue, employees, geography)
    - Behavioral Fit: What they're doing (tech stack, growth signals, engagement, purchase history)
    - Strategic Fit: Where they're heading (decision-maker access, budget authority, alignment)

    Returns tier classification (1-4), score breakdown, and recommended engagement strategy.

    Provide EITHER company_id (HubSpot ID, requires HUBSPOT_API_KEY) OR company_data (JSON string).

    Args:
        company_id: HubSpot company ID to fetch and score.
        company_data: JSON string with company attributes. Example keys:
            industry, annual_revenue, employee_count, geography, tech_stack (list),
            growth_signals (list), content_engagement ("active"|"occasional"|"none"),
            purchase_history ("regular"|"occasional"|"never"),
            decision_maker_access ("c_suite"|"director"|"manager"|"indirect"|"none"),
            budget_authority ("dedicated"|"shared"|"possible"|"none"),
            strategic_alignment ("strong"|"partial"|"misaligned").

    Returns:
        JSON with total score, tier, breakdown, exclusion check, and recommended action.
    """
    # company_id requires HubSpot = requires license
    if company_id:
        try:
            require_license("hubspot", _license)
        except ValueError as e:
            return json.dumps({"error": str(e)})

    parsed_data = None
    if company_data:
        try:
            parsed_data = json.loads(company_data) if isinstance(company_data, str) else company_data
        except (json.JSONDecodeError, TypeError) as e:
            return json.dumps({"error": f"Invalid company_data JSON: {e}"})

    client = _get_hubspot_client() if company_id else None
    try:
        result = qualify_prospect(
            company_id=company_id,
            company_data=parsed_data,
            hubspot_client=client,
            property_mapping=_property_mapping if _license.tier != "free" else None,
        )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if client:
            client.close()


@mcp.tool()
@_logged("validate_configuration")
def validate_configuration() -> str:
    """Validate custom configuration files without making API calls.

    Tests property mapping and RFM threshold configurations for correctness.
    Useful for debugging configuration issues before running analysis.

    Returns:
        JSON with validation results, errors, and warnings.
    """
    results = {
        "license_tier": _license.tier,
        "property_mapping": {
            "configured": _property_mapping is not None and _property_mapping != DEFAULT_PROPERTY_MAPPING,
            "source": "custom" if _property_mapping and _property_mapping != DEFAULT_PROPERTY_MAPPING else "default",
            "errors": _property_mapping_errors,
            "status": "valid" if not _property_mapping_errors else "invalid"
        },
        "rfm_thresholds": {
            "configured": _rfm_thresholds is not None,
            "source": "custom" if _rfm_thresholds else "default",
            "errors": _rfm_thresholds_errors,
            "status": "valid" if not _rfm_thresholds_errors else "invalid"
        },
        "overall_status": "valid" if not (_property_mapping_errors or _rfm_thresholds_errors) else "invalid"
    }

    # Add configuration details if valid
    if _property_mapping and not _property_mapping_errors:
        results["property_mapping"]["details"] = {
            "tech_stack_property": _property_mapping.tech_stack,
            "growth_signals_count": len(_property_mapping.growth_signals) if _property_mapping.growth_signals else 0,
            "content_engagement_property": _property_mapping.content_engagement,
            "strategic_properties_configured": bool(
                _property_mapping.decision_maker_access or
                _property_mapping.budget_authority or
                _property_mapping.strategic_alignment
            )
        }

    if _rfm_thresholds and not _rfm_thresholds_errors:
        results["rfm_thresholds"]["details"] = {
            "recency_thresholds": _rfm_thresholds.recency_days,
            "frequency_thresholds": _rfm_thresholds.frequency_counts,
            "monetary_method": _rfm_thresholds.monetary_method
        }

    return json.dumps(results, indent=2)


@mcp.tool()
@_logged("score_pipeline_health")
def score_pipeline_health(
    pipeline_id: Optional[str] = None,
    source: str = "hubspot",
) -> str:
    """Analyze HubSpot pipeline health (velocity, conversion, at-risk deals). Pro tier.

    ONLY CALL THIS TOOL when the user EXPLICITLY asks about HubSpot pipeline
    health, deal velocity, stage-to-stage conversion, or at-risk deal detection.
    Do NOT call this for general "build my system" or "what should I do"
    questions; for those, route to module_prompt_free or auto_diagnose.

    Calculates overall health score (0-100), identifies bottleneck stages,
    measures stage-to-stage conversion rates, and flags stalled or overdue deals.

    Args:
        pipeline_id: Optional HubSpot pipeline ID to filter. Default: all pipelines.
        source: "hubspot" for live data, "sample" for built-in demo data.

    Returns:
        JSON with health score, velocity metrics, conversion rates, at-risk deals, and stage distribution.
    """
    try:
        require_license(source, _license)
    except ValueError as e:
        return json.dumps({"error": str(e)})

    client = _get_hubspot_client() if source == "hubspot" else None
    try:
        result = score_pipeline(
            pipeline_id=pipeline_id,
            source=source,
            hubspot_client=client,
        )
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        if client:
            client.close()


# --- Resources ---


@mcp.resource("methodology://scoring-model")
def scoring_model() -> str:
    """ICP Triangulation Framework technical reference."""
    return get_resource("scoring-model")


@mcp.resource("methodology://tier-definitions")
def tier_definitions() -> str:
    """4-tier classification system (Ideal / Strong / Moderate / Poor)."""
    return get_resource("tier-definitions")


@mcp.resource("methodology://rfm-segments")
def rfm_segments() -> str:
    """11 RFM segment definitions with scoring scales."""
    return get_resource("rfm-segments")


@mcp.resource("methodology://spiced-framework")
def spiced_framework() -> str:
    """SPICED discovery framework reference."""
    return get_resource("spiced-framework")


@mcp.resource("methodology://data-requirements")
def data_requirements() -> str:
    """HubSpot data setup and enrichment requirements for ICP triangulation."""
    return get_resource("data-requirements")


@mcp.resource("methodology://welcome")
def welcome() -> str:
    """Onboarding context the agent reads to orient a new user. When the user
    says hi or asks 'what can you do', the agent uses this resource to frame
    its response with one concrete starter prompt and the route forward."""
    return """# Artefact Formula MCP — onboarding context

When the user opens this MCP for the first time or sends a vague greeting
(hi, hello, what can you do, allo, salut), your job is to orient them in
ONE short message that ends with a single concrete starter sentence the
user can copy-paste back. Do not list 9 tools or 5 slash commands.

## How to greet a new user

Reply with exactly this shape (under 6 lines):

> Welcome to the Artefact Formula MCP. I have 5 Free tier tools to help
> you build your AI Operating System (GTM methodology, archetype, CLAUDE.md
> scaffold, gate validation) plus 4 Pro tools for HubSpot revenue intelligence.
>
> To start, type: **"Help me build my AI Operating System"**
>
> The MCP also exposes 5 slash commands (/artefact-start, /artefact-diagnose,
> /artefact-claude-md, /artefact-archetype, /artefact-modules) for clients
> that surface MCP prompts (Claude Code, Cursor). Claude Desktop users
> typically interact through natural language above instead.

If the user writes in French, mirror their language in the reply but keep
the starter prompt as the English literal sentence (the agent's routing
keywords are tuned in both languages, so either FR or EN input works).

## Methodology vocabulary the user may ask about

- CLAUDE.md: 5-section master prompt file that codes a pilot's business
  logic into 80 to 150 lines.
- Module: discrete unit of GTM work, organized by pillar (FOND, ARC,
  SKL, WFL, SNT, GOV, INT, EXT) plus mode-specific (POC, DIY).
- Pillar: capability area (foundation, architecture, skills library,
  workflows, sentinelles, governance, interfaces, export/handoff).
- Mode: deployment style (Self-Serve, POC, DIY, Co-Build).
- Archetype: technical stack family (A: Open/sovereign, B: Google-
  native, C: Microsoft-native, D: Hybrid/on-prem).

## Tier semantics

- Free tier (5 tools, 100% local): module_prompt_free,
  archetype_decision, auto_diagnose, generate_claude_md, gate_check.
- Pro tier (4 tools, requires HubSpot API key): run_rfm, qualify,
  score_pipeline_health, validate_configuration. Lemon Squeezy license
  gating arrives in v0.5.0.
"""


# --- Prompts (slash commands surfaced in MCP-compatible clients) ---


@mcp.prompt(
    name="artefact-start",
    title="Artefact: Quick start",
    description="Welcome tour with the 5 Free tier tools and a suggested next step.",
)
def prompt_start() -> str:
    return (
        "Read methodology://welcome, then give me a 30-second orientation: "
        "what is the Artefact Formula MCP, what are the 5 Free tier tools, "
        "and which one should I try first based on the most common pilot "
        "starting point. Keep it under 6 lines and finish with one specific "
        "slash command suggestion to call next."
    )


@mcp.prompt(
    name="artefact-diagnose",
    title="Artefact: Recommend a deployment mode",
    description="Diagnose the right deployment mode (Self-Serve / POC / DIY / Co-Build) and starting module for my pilot.",
)
def prompt_diagnose(context: str = "") -> str:
    if not context.strip():
        return (
            "I want to figure out the right deployment mode for my GTM "
            "Operating System pilot. Ask me 3 short questions to gather: "
            "(1) who pilots the system and how many hours per week they "
            "have, (2) the engagement horizon and budget shape, (3) the "
            "dominant infrastructure (Microsoft 365, Google Workspace, "
            "open). Then call the auto_diagnose tool with my answers as "
            "the context argument and explain the recommendation."
        )
    return (
        f"Call the auto_diagnose tool with this context: {context.strip()}. "
        "Then summarize the recommended mode, starting module, and one "
        "concrete next step. If the confidence is medium or framing, ask "
        "me the disambiguation questions before recommending."
    )


@mcp.prompt(
    name="artefact-claude-md",
    title="Artefact: Scaffold my CLAUDE.md",
    description="Generate a CLAUDE.md master scaffold (5 sections, 80 to 150 lines) for my pilot.",
)
def prompt_claude_md(client_name: str = "", function: str = "") -> str:
    seed = []
    if client_name.strip():
        seed.append(f'client name "{client_name.strip()}"')
    if function.strip():
        seed.append(f'function "{function.strip()}"')
    seed_str = " (" + ", ".join(seed) + ")" if seed else ""
    return (
        f"I want to generate my CLAUDE.md master file{seed_str}. "
        "Walk me through the 5 sections (Identity, Business context, "
        "Team, KPIs, Workflow defaults) by asking me concise questions, "
        "one section at a time. When you have enough to fill required "
        "fields (client_name, pilot.first_name, pilot.role, function, "
        "at least 1 KPI with target and frequency), call generate_claude_md "
        "with the JSON. Show me the rendered markdown plus any warnings "
        "and the QA gate questions, then ask whether to refine any section."
    )


@mcp.prompt(
    name="artefact-archetype",
    title="Artefact: Recommend a technical archetype",
    description="Recommend a technical archetype (A: Open / B: Google / C: Microsoft / D: On-prem) from 5 yes/no questions.",
)
def prompt_archetype() -> str:
    return (
        "I need to choose a technical archetype for my Artefact Formula "
        "GTM OS. Ask me the 5 yes/no questions in order: "
        "(1) Loi 25 strict (public sector, health, finance), "
        "(2) Microsoft 365 dominant on more than 80% of workflows, "
        "(3) Google Workspace dominant on more than 80% of workflows, "
        "(4) Sovereignty extreme (data must never leave my perimeter), "
        "(5) Can adopt open-source / non-Microsoft / non-Google tooling. "
        "Then call archetype_decision with my answers and explain the "
        "recommended archetype, the stack, the 3 advantages, the 3 "
        "constraints, and the next module to load."
    )


@mcp.prompt(
    name="artefact-modules",
    title="Artefact: Browse the methodology",
    description="Browse the 34-module Artefact Formula catalog or load any module's full body.",
)
def prompt_modules(module_id: str = "") -> str:
    if module_id.strip():
        mid = module_id.strip().upper()
        return (
            f"Call module_prompt_free with module_id={mid!r} and present "
            "the module to me with: a 2-line summary at the top, the QA "
            "gate as a checklist I can fill, and the next module to load "
            "after this one. Keep the rest of the body verbatim from the "
            "tool output."
        )
    return (
        "Call module_prompt_free with no arguments and present the catalog "
        "of 34 modules grouped by pillar. After the catalog, ask me "
        "whether I want to load a specific module, run the auto-diagnostic "
        "to find my entry point, or learn what each pillar means."
    )


def main():
    """Entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
