"""
Usage logging for Artefact MCP Server (v0.5.0).

Fire-and-forget per-call POST to a Supabase REST endpoint. All exceptions
are swallowed so logging never breaks tool execution.

Activation requires THREE conditions, ALL of which must be met:
1. ARTEFACT_USAGE_LOG_ENDPOINT — full PostgREST URL, e.g.
   https://fmtrtufcfusqtbxujuae.supabase.co/rest/v1/mcp_license_usage
2. ARTEFACT_USAGE_LOG_KEY — Supabase anon key (insert-only RLS policy)
3. ARTEFACT_USAGE_TELEMETRY_OPT_IN — set to "true" by the user. This is
   an explicit opt-in distinct from the licensing contract (Loi 25 / GDPR
   require consent for analytics-class telemetry beyond strictly necessary
   contract performance).

Any one of the three unset → no logging happens (no error).

Loi 25 framing: license_key_hash is pseudonymous personal data. Tool name +
source + success/failure are usage-telemetry data. The two have different
legal bases:
- License hash + tier: contract necessity (Loi 25 art. 12 par. 1 al. 1°),
  needed for license validation and billing reconciliation.
- Tool name, source, success/failure: explicit user opt-in. We do not
  collect this until the user sets ARTEFACT_USAGE_TELEMETRY_OPT_IN=true.

Full PIA: docs/law25-pia-mcp-license-usage.md.

Cross-validated against Gemini 2.5 Pro round 2 (2026-05-08): the original
"contract necessity" framing for full telemetry was too aggressive; this
module now respects the split.
"""

from __future__ import annotations

import hashlib
import os
import threading
from dataclasses import asdict, dataclass
from typing import Optional

import httpx


_LOG_TIMEOUT_SECONDS = 1.5


def _hash_license_key(key: Optional[str]) -> Optional[str]:
    """SHA-256 truncated to 16 hex chars. Pseudonymous, not anonymous."""
    if not key:
        return None
    return hashlib.sha256(key.encode()).hexdigest()[:16]


@dataclass
class UsageEvent:
    """One row destined for mcp_license_usage."""

    tool_name: str
    tier: str
    success: bool
    license_key_hash: Optional[str] = None
    source: Optional[str] = None
    error_code: Optional[str] = None
    mcp_version: Optional[str] = None
    client_user_agent: Optional[str] = None


def _post_event(endpoint: str, key: str, event_payload: dict) -> None:
    """Synchronous POST to PostgREST. Called from a daemon thread."""
    try:
        httpx.post(
            endpoint,
            json=event_payload,
            headers={
                "apikey": key,
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "Prefer": "return=minimal",
            },
            timeout=_LOG_TIMEOUT_SECONDS,
        )
    except Exception:
        # Fire-and-forget — never raise from the logger thread.
        pass


def log_usage(
    tool_name: str,
    tier: str,
    success: bool,
    *,
    license_key: Optional[str] = None,
    source: Optional[str] = None,
    error_code: Optional[str] = None,
    mcp_version: Optional[str] = None,
    client_user_agent: Optional[str] = None,
) -> None:
    """Log one MCP tool call. Fire-and-forget — returns immediately.

    No-op unless ALL THREE conditions are met:
    1. ARTEFACT_USAGE_LOG_ENDPOINT is set
    2. ARTEFACT_USAGE_LOG_KEY is set
    3. ARTEFACT_USAGE_TELEMETRY_OPT_IN is set to "true" (explicit user consent)

    The opt-in gate is REQUIRED for Loi 25 / GDPR compliance — usage telemetry
    (tool name, source, success/failure) goes beyond what license-validation
    contract necessity covers.

    Errors during the POST are silently swallowed.
    """
    endpoint = os.getenv("ARTEFACT_USAGE_LOG_ENDPOINT")
    key = os.getenv("ARTEFACT_USAGE_LOG_KEY")
    opt_in = os.getenv("ARTEFACT_USAGE_TELEMETRY_OPT_IN", "").lower() == "true"
    if not endpoint or not key or not opt_in:
        return

    event = UsageEvent(
        tool_name=tool_name,
        tier=tier,
        success=success,
        license_key_hash=_hash_license_key(license_key),
        source=source,
        error_code=error_code,
        mcp_version=mcp_version,
        client_user_agent=client_user_agent,
    )

    payload = {k: v for k, v in asdict(event).items() if v is not None or k in ("success",)}

    threading.Thread(
        target=_post_event,
        args=(endpoint, key, payload),
        daemon=True,
    ).start()
