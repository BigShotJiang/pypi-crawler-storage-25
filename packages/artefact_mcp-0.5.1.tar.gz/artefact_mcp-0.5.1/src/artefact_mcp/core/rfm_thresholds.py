"""
RFM threshold configuration for custom scoring presets.

Allows Pro/Enterprise users to define custom RFM scoring thresholds
for their specific industry or business model.
"""

from typing import Optional, Dict, List
from dataclasses import dataclass, field


@dataclass
class RFMThresholds:
    """Custom RFM scoring thresholds."""

    # Recency thresholds (days since last purchase)
    recency_days: List[int] = field(default_factory=lambda: [30, 90, 180, 365])
    recency_scores: List[int] = field(default_factory=lambda: [5, 4, 3, 2, 1])

    # Frequency thresholds (transaction count)
    frequency_counts: List[int] = field(default_factory=lambda: [10, 5, 3, 2])
    frequency_scores: List[int] = field(default_factory=lambda: [5, 4, 3, 2, 1])

    # Monetary method and thresholds
    monetary_method: str = "percentile"  # "percentile" or "fixed"
    monetary_percentiles: List[int] = field(default_factory=lambda: [80, 60, 40, 20])
    monetary_fixed_thresholds: List[float] = field(default_factory=lambda: [100000, 50000, 25000, 10000])
    monetary_scores: List[int] = field(default_factory=lambda: [5, 4, 3, 2, 1])

    def to_scorer_config(self) -> dict:
        """Convert to RFMScorer configuration format."""
        config = {
            "recency": {
                "days": self.recency_days,
                "scores": self.recency_scores,
            },
            "frequency": {
                "counts": self.frequency_counts,
                "scores": self.frequency_scores,
            },
            "monetary": {
                "method": self.monetary_method,
            }
        }

        if self.monetary_method == "percentile":
            config["monetary"]["percentiles"] = self.monetary_percentiles
        else:
            config["monetary"]["thresholds"] = self.monetary_fixed_thresholds
            config["monetary"]["scores"] = self.monetary_scores

        return config


# Default thresholds (standard RFM)
DEFAULT_RFM_THRESHOLDS = RFMThresholds()

# B2B Service preset (longer buying cycles)
B2B_SERVICE_THRESHOLDS = RFMThresholds(
    recency_days=[60, 180, 365, 730],
    recency_scores=[5, 4, 3, 2, 1],
    frequency_counts=[5, 3, 2, 1],
    frequency_scores=[5, 4, 3, 2, 1],
    monetary_method="percentile",
    monetary_percentiles=[80, 60, 40, 20],
)

# B2B SaaS preset (subscription businesses)
B2B_SAAS_THRESHOLDS = RFMThresholds(
    recency_days=[30, 60, 90, 180],
    recency_scores=[5, 4, 3, 2, 1],
    frequency_counts=[5, 3, 2, 1, 0],
    frequency_scores=[5, 4, 3, 2, 1],
    monetary_method="percentile",
    monetary_percentiles=[80, 60, 40, 20],
)

# B2B Manufacturing preset (long cycles, large transactions)
B2B_MANUFACTURING_THRESHOLDS = RFMThresholds(
    recency_days=[90, 365, 730, 1095],
    recency_scores=[5, 4, 3, 2, 1],
    frequency_counts=[8, 4, 2, 1],
    frequency_scores=[5, 4, 3, 2, 1],
    monetary_method="percentile",
    monetary_percentiles=[80, 60, 40, 20],
)

# Preset mapping
PRESET_THRESHOLDS = {
    "default": DEFAULT_RFM_THRESHOLDS,
    "b2b_service": B2B_SERVICE_THRESHOLDS,
    "saas": B2B_SAAS_THRESHOLDS,
    "manufacturing": B2B_MANUFACTURING_THRESHOLDS,
}
