"""
HubSpot API Client

Fetches deal and company data from HubSpot API.
Uses httpx for async-compatible HTTP requests.
"""

import os
import threading
import time
from datetime import datetime
from typing import Optional, List

import httpx


class _TokenBucket:
    """Thread-safe token-bucket rate limiter.

    Caps outbound HubSpot calls to a fixed rate (default 8 req/sec, under
    HubSpot's 10/sec free-tier ceiling). Prevents a runaway agent loop from
    exhausting a customer's HubSpot API quota for the entire org.

    Cross-validated against Gemini round-2 cross-review (2026-05-08): rate
    limiting at the client level is the right place to enforce this — the
    risk is systemic, not proportional to user count.
    """

    def __init__(self, rate: float, capacity: Optional[float] = None):
        self.rate = max(0.1, float(rate))                 # req/sec, lower bound 0.1
        self.capacity = float(capacity) if capacity else self.rate * 1.5
        self.tokens = self.capacity
        self.last_refill = time.monotonic()
        self.lock = threading.Lock()

    def acquire(self) -> None:
        """Block until one token is available, then consume it."""
        with self.lock:
            now = time.monotonic()
            elapsed = now - self.last_refill
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
            self.last_refill = now

            if self.tokens >= 1:
                self.tokens -= 1
                return

            # Sleep just long enough to earn one token.
            wait = (1 - self.tokens) / self.rate
        time.sleep(wait)
        with self.lock:
            self.tokens = 0
            self.last_refill = time.monotonic()


class HubSpotClient:
    """HubSpot API client for revenue intelligence data."""

    BASE_URL = "https://api.hubapi.com"
    # Safety limit. 500 pages × 100/page = 50,000 records — covers Artefact's
    # entire ICP ($1.6M-$70M B2B). Audit fetchers also expose a `truncated`
    # signal when the cap is hit so callers can surface the warning instead of
    # silently analysing partial data (Gemini cross-review 2026-05-08).
    MAX_PAGES = 500

    def __init__(self, api_key: Optional[str] = None):
        self._api_key = api_key or os.getenv("HUBSPOT_API_KEY")
        if not self._api_key:
            raise ValueError(
                "HubSpot API key required. Set HUBSPOT_API_KEY environment variable "
                "or pass api_key to constructor."
            )
        self._client = httpx.Client(
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )
        # Rate limiter — default 8 req/sec, under HubSpot's 10/sec free-tier
        # cap. Configurable via ARTEFACT_HUBSPOT_RPS for paid tiers with a
        # higher quota.
        try:
            rps = float(os.getenv("ARTEFACT_HUBSPOT_RPS", "8"))
        except (ValueError, TypeError):
            rps = 8.0
        self._bucket = _TokenBucket(rate=rps)
        # Populated by audit-tool fetchers so callers can surface truncation.
        # Reset at the start of each fetch — see fetch_contacts_with_lifecycle
        # and fetch_deals_with_hygiene.
        self.last_fetch_meta: dict = {
            "truncated": False,
            "pages_fetched": 0,
            "max_pages": self.MAX_PAGES,
        }

    @property
    def api_key(self) -> str:
        """Masked API key for safe display."""
        if self._api_key and len(self._api_key) > 8:
            return self._api_key[:4] + "..." + self._api_key[-4:]
        return "***"

    def __repr__(self) -> str:
        return f"HubSpotClient(api_key='{self.api_key}')"

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # --- Client Data (for RFM) ---

    def fetch_client_data(
        self,
        stage_filter: Optional[str] = "closedwon",
        limit: int = 100,
    ) -> list[dict]:
        """Fetch deals and aggregate by company for RFM analysis."""
        deals = self._fetch_deals(stage_filter, limit)

        company_ids = set()
        for deal in deals:
            assocs = (
                deal.get("associations", {}).get("companies", {}).get("results", [])
            )
            for assoc in assocs:
                company_ids.add(assoc.get("id"))

        companies = self._batch_fetch_companies(list(company_ids))
        return self._aggregate_by_company(deals, companies)

    # --- Open Deals (for Pipeline) ---

    def fetch_open_deals(self, pipeline_id: Optional[str] = None) -> list[dict]:
        """Fetch all open deals, optionally filtered by pipeline."""
        deals = []
        after = None
        pages = 0

        while pages < self.MAX_PAGES:
            pages += 1
            url = f"{self.BASE_URL}/crm/v3/objects/deals"
            params: dict = {
                "limit": 100,
                "properties": "dealname,amount,closedate,dealstage,pipeline,createdate,hs_lastmodifieddate",
                "associations": "companies",
            }
            if after:
                params["after"] = after

            response = self._request("GET", url, params=params)
            data = response.json()

            for deal in data.get("results", []):
                props = deal.get("properties", {})
                stage = props.get("dealstage", "")

                if stage.lower() in ("closedwon", "closedlost"):
                    continue
                if pipeline_id and props.get("pipeline") != pipeline_id:
                    continue

                deals.append({
                    "id": deal.get("id"),
                    "name": props.get("dealname"),
                    "amount": self._safe_float(props.get("amount")),
                    "stage": stage,
                    "pipeline": props.get("pipeline"),
                    "create_date": self._parse_date(props.get("createdate")),
                    "close_date": self._parse_date(props.get("closedate")),
                    "last_modified": self._parse_date(props.get("hs_lastmodifieddate")),
                })

            paging = data.get("paging", {})
            if paging.get("next"):
                after = paging["next"].get("after")
            else:
                break

        return deals

    # --- Deal Stage History (for Velocity) ---

    def fetch_deal_stage_history(self, deal_id: str) -> list[dict]:
        """Fetch stage change history for a specific deal."""
        url = f"{self.BASE_URL}/crm/v3/objects/deals/{deal_id}"
        params = {"propertiesWithHistory": "dealstage"}

        response = self._request("GET", url, params=params)
        data = response.json()

        history = []
        stage_versions = (
            data.get("propertiesWithHistory", {})
            .get("dealstage", [])
        )

        for i, version in enumerate(stage_versions):
            entered = self._parse_date(version.get("timestamp"))
            exited = None
            duration_days = None

            if i > 0:
                exited = self._parse_date(stage_versions[i - 1].get("timestamp"))
                if entered and exited:
                    duration_days = (exited - entered).days

            history.append({
                "stage": version.get("value"),
                "entered_at": entered.isoformat() if entered else None,
                "exited_at": exited.isoformat() if exited else None,
                "duration_days": duration_days,
            })

        return history

    # --- Properties + Workflows (for score_ai_readiness, audit_property_governance) ---

    def fetch_properties_overview(self) -> list[dict]:
        """Fetch contact + company + deal properties with is_custom flag.

        v0.5.0 best-effort: HubSpot's properties API exposes `hubspotDefined`
        but not native fill-rate or workflow-reference metadata. The audit
        tools fall back to a minimal shape and emit weaker signals on live
        data than on the sample fixture. v0.6.0 will sample contacts/deals
        to compute fill rate and traverse workflows for references.
        """
        results: list[dict] = []
        for object_type in ("contacts", "companies", "deals"):
            url = f"{self.BASE_URL}/crm/v3/properties/{object_type}"
            try:
                response = self._request("GET", url)
                data = response.json()
                for p in data.get("results", []):
                    name = p.get("name", "")
                    if not name:
                        continue
                    results.append({
                        "name": name,
                        "label": p.get("label", name),
                        "object_type": object_type[:-1] if object_type.endswith("s") else object_type,
                        "type": p.get("type", "string"),
                        "is_custom": not p.get("hubspotDefined", True),
                        "fill_rate": None,  # not available without sampling
                        "usage_count": 0,
                        "is_deprecated": False,  # not surfaced by API
                        "referenced_in_workflows": [],
                    })
            except Exception:
                continue
        return results

    def fetch_workflows_overview(self) -> list[dict]:
        """Fetch automation workflows (enabled flag + name).

        v0.5.0 best-effort. Some workspaces require Operations Hub for the
        workflows API. On 401/403, returns an empty list and the audit
        degrades gracefully.
        """
        url = f"{self.BASE_URL}/automation/v3/workflows"
        try:
            response = self._request("GET", url)
            data = response.json()
        except Exception:
            return []

        workflows: list[dict] = []
        for w in data.get("workflows", []):
            workflows.append({
                "id": str(w.get("id", "")),
                "name": w.get("name", ""),
                "type": w.get("type", "contact-based"),
                "is_enabled": bool(w.get("enabled")),
                "referenced_properties": [],  # not surfaced cleanly by API in v0.5.0
                "last_triggered": None,
                "enrollment_count_30d": 0,
            })
        return workflows

    # --- Deals (for audit_pipeline_hygiene — raw v3 shape) ---

    def fetch_deals_with_hygiene(
        self, pipeline_id: Optional[str] = None
    ) -> list[dict]:
        """Fetch open deals with hygiene-relevant properties in raw v3 shape.

        Distinct from fetch_open_deals (which transforms shape for Pro tools).
        Returns [{"id": ..., "properties": {...}}] so audit_pipeline_hygiene
        operates on the same shape as the sample fixture.
        """
        deals: list[dict] = []
        after = None
        pages = 0
        truncated = False

        properties = (
            "dealname,amount,dealstage,pipeline,closedate,createdate,"
            "hs_lastmodifieddate,hubspot_owner_id"
        )

        while pages < self.MAX_PAGES:
            pages += 1
            url = f"{self.BASE_URL}/crm/v3/objects/deals"
            params: dict = {"limit": 100, "properties": properties}
            if after:
                params["after"] = after

            response = self._request("GET", url, params=params)
            data = response.json()

            for deal in data.get("results", []):
                props = deal.get("properties", {})
                stage = (props.get("dealstage") or "").lower()
                if stage in ("closedwon", "closedlost"):
                    continue
                if pipeline_id and props.get("pipeline") != pipeline_id:
                    continue
                deals.append({
                    "id": deal.get("id"),
                    "properties": props,
                })

            paging = data.get("paging", {})
            if paging.get("next"):
                after = paging["next"].get("after")
                if pages >= self.MAX_PAGES:
                    truncated = True
            else:
                break

        self.last_fetch_meta = {
            "truncated": truncated,
            "pages_fetched": pages,
            "max_pages": self.MAX_PAGES,
            "records_returned": len(deals),
        }
        return deals

    # --- Contacts (for audit_lifecycle_stages) ---

    def fetch_contacts_with_lifecycle(self) -> list[dict]:
        """Fetch all contacts with lifecycle stage history properties.

        Returns raw HubSpot v3 shape: [{"id": "...", "properties": {...}}].
        Used by audit_lifecycle_stages — caller does the analytics. Sets
        self.last_fetch_meta with truncated/pages_fetched so the audit tool
        can surface partial-data warnings.
        """
        contacts: list[dict] = []
        after = None
        pages = 0
        truncated = False

        properties = (
            "email,firstname,lastname,lifecyclestage,hubspot_owner_id,"
            "createdate,lastmodifieddate,"
            "hs_lifecyclestage_subscriber_date,"
            "hs_lifecyclestage_lead_date,"
            "hs_lifecyclestage_marketingqualifiedlead_date,"
            "hs_lifecyclestage_salesqualifiedlead_date,"
            "hs_lifecyclestage_opportunity_date,"
            "hs_lifecyclestage_customer_date,"
            "hs_lifecyclestage_evangelist_date"
        )

        while pages < self.MAX_PAGES:
            pages += 1
            url = f"{self.BASE_URL}/crm/v3/objects/contacts"
            params: dict = {"limit": 100, "properties": properties}
            if after:
                params["after"] = after

            response = self._request("GET", url, params=params)
            data = response.json()

            for contact in data.get("results", []):
                contacts.append({
                    "id": contact.get("id"),
                    "properties": contact.get("properties", {}),
                })

            paging = data.get("paging", {})
            if paging.get("next"):
                after = paging["next"].get("after")
                if pages >= self.MAX_PAGES:
                    truncated = True
            else:
                break

        self.last_fetch_meta = {
            "truncated": truncated,
            "pages_fetched": pages,
            "max_pages": self.MAX_PAGES,
            "records_returned": len(contacts),
        }
        return contacts

    # --- Company Lookup (for ICP) ---

    def fetch_company(self, company_id: str) -> dict:
        """Fetch a single company by ID with standard properties."""
        url = f"{self.BASE_URL}/crm/v3/objects/companies/{company_id}"
        params = {
            "properties": "name,domain,industry,numberofemployees,annualrevenue,state,country,hs_analytics_source,lifecyclestage",
        }

        response = self._request("GET", url, params=params)
        data = response.json()

        props = data.get("properties", {})
        return {
            "id": data.get("id"),
            "name": props.get("name", "Unknown"),
            "domain": props.get("domain"),
            "industry": props.get("industry"),
            "employee_count": self._safe_int(props.get("numberofemployees")),
            "annual_revenue": self._safe_float(props.get("annualrevenue")),
            "geography": props.get("state") or props.get("country"),
        }

    def fetch_company_with_custom_properties(
        self,
        company_id: str,
        property_names: List[str]
    ) -> dict:
        """Fetch a company with specified custom properties.

        Args:
            company_id: HubSpot company ID.
            property_names: List of additional custom property names to fetch.

        Returns:
            Dict with company ID and properties dict containing all requested fields.
        """
        url = f"{self.BASE_URL}/crm/v3/objects/companies/{company_id}"

        # Include both standard and custom properties
        all_properties = [
            "name", "domain", "industry", "numberofemployees",
            "annualrevenue", "state", "country"
        ] + property_names

        params = {"properties": ",".join(all_properties)}

        response = self._request("GET", url, params=params)
        data = response.json()

        return {
            "id": data.get("id"),
            "properties": data.get("properties", {}),  # Return all properties for flexible mapping
        }

    def search_companies(self, query: str, limit: int = 10) -> list[dict]:
        """Search companies by name or domain."""
        url = f"{self.BASE_URL}/crm/v3/objects/companies/search"
        limit = min(limit, 100)  # Cap at HubSpot max
        payload = {
            "query": query,
            "limit": limit,
            "properties": [
                "name", "domain", "industry", "numberofemployees",
                "annualrevenue", "state", "country",
            ],
        }

        response = self._request("POST", url, json=payload)

        results = []
        for company in response.json().get("results", []):
            props = company.get("properties", {})
            results.append({
                "id": company.get("id"),
                "name": props.get("name", "Unknown"),
                "domain": props.get("domain"),
                "industry": props.get("industry"),
                "employee_count": self._safe_int(props.get("numberofemployees")),
                "annual_revenue": self._safe_float(props.get("annualrevenue")),
                "geography": props.get("state") or props.get("country"),
            })

        return results

    # --- Internal Helpers ---

    _RATE_LIMIT_MAX_ATTEMPTS = 3
    _RATE_LIMIT_BACKOFF_CAP_SECONDS = 60.0

    def _request(self, method: str, url: str, **kwargs) -> httpx.Response:
        """Make an HTTP request with token-bucket throttle + 429 retry."""
        backoff = 1.0
        for attempt in range(self._RATE_LIMIT_MAX_ATTEMPTS):
            self._bucket.acquire()
            try:
                response = self._client.request(method, url, **kwargs)
                response.raise_for_status()
                return response
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if status == 429 and attempt < self._RATE_LIMIT_MAX_ATTEMPTS - 1:
                    # Honor Retry-After if HubSpot provides it; else exponential.
                    retry_after = e.response.headers.get("Retry-After")
                    sleep_for = backoff
                    if retry_after:
                        try:
                            sleep_for = float(retry_after)
                        except (ValueError, TypeError):
                            pass
                    time.sleep(min(sleep_for, self._RATE_LIMIT_BACKOFF_CAP_SECONDS))
                    backoff *= 2
                    continue
                if status == 401:
                    raise ValueError("HubSpot API key is invalid or expired.") from e
                if status == 403:
                    raise ValueError(
                        "HubSpot API key lacks required scopes. "
                        "Ensure crm.objects.deals.read and crm.objects.companies.read are enabled."
                    ) from e
                if status == 429:
                    raise ValueError(
                        "HubSpot API rate limit exceeded after retries. "
                        "Either raise ARTEFACT_HUBSPOT_RPS, or wait for the quota to reset."
                    ) from e
                raise ValueError(f"HubSpot API error ({status}): {e.response.text[:200]}") from e
            except httpx.ConnectError as e:
                raise ValueError("Cannot connect to HubSpot API. Check your network.") from e
        # Defensive — should be unreachable because the loop always returns or raises.
        raise ValueError("HubSpot API: unexpected retry loop exit")

    def _fetch_deals(self, stage_filter: Optional[str], limit: int) -> list[dict]:
        deals = []
        after = None
        pages = 0

        while pages < self.MAX_PAGES:
            pages += 1
            url = f"{self.BASE_URL}/crm/v3/objects/deals"
            params: dict = {
                "limit": limit,
                "properties": "dealname,amount,closedate,dealstage,pipeline",
                "associations": "companies",
            }
            if after:
                params["after"] = after

            response = self._request("GET", url, params=params)
            data = response.json()

            for deal in data.get("results", []):
                props = deal.get("properties", {})
                if stage_filter and props.get("dealstage", "").lower() != stage_filter:
                    continue
                deals.append({
                    "id": deal.get("id"),
                    "name": props.get("dealname"),
                    "amount": self._safe_float(props.get("amount")),
                    "close_date": self._parse_date(props.get("closedate")),
                    "stage": props.get("dealstage"),
                    "associations": deal.get("associations", {}),
                })

            paging = data.get("paging", {})
            if paging.get("next"):
                after = paging["next"].get("after")
            else:
                break

        return deals

    def _batch_fetch_companies(self, company_ids: list[str]) -> dict:
        if not company_ids:
            return {}

        companies = {}
        for i in range(0, len(company_ids), 100):
            batch = company_ids[i : i + 100]
            url = f"{self.BASE_URL}/crm/v3/objects/companies/batch/read"
            payload = {
                "inputs": [{"id": cid} for cid in batch],
                "properties": [
                    "name", "domain", "industry", "numberofemployees",
                    "annualrevenue", "state", "country",
                ],
            }

            response = self._request("POST", url, json=payload)

            for company in response.json().get("results", []):
                props = company.get("properties", {})
                companies[company.get("id")] = {
                    "id": company.get("id"),
                    "name": props.get("name", "Unknown"),
                    "domain": props.get("domain"),
                    "industry": props.get("industry"),
                    "employee_count": self._parse_employee_band(
                        props.get("numberofemployees")
                    ),
                    "company_revenue": self._parse_revenue_band(
                        props.get("annualrevenue")
                    ),
                    "state_region": props.get("state") or props.get("country"),
                }

        return companies

    def _aggregate_by_company(self, deals: list[dict], companies: dict) -> list[dict]:
        company_data: dict = {}

        for deal in deals:
            assocs = (
                deal.get("associations", {}).get("companies", {}).get("results", [])
            )
            if not assocs:
                continue

            company_id = assocs[0].get("id")
            if not company_id:
                continue

            if company_id not in company_data:
                company_info = companies.get(company_id, {})
                company_data[company_id] = {
                    "client_id": company_id,
                    "client_name": company_info.get("name", "Unknown"),
                    "total_revenue": 0,
                    "transaction_count": 0,
                    "last_purchase_date": None,
                    "industry": company_info.get("industry"),
                    "employee_count": company_info.get("employee_count"),
                    "company_revenue": company_info.get("company_revenue"),
                    "state_region": company_info.get("state_region"),
                }

            company_data[company_id]["total_revenue"] += deal.get("amount", 0)
            company_data[company_id]["transaction_count"] += 1

            close_date = deal.get("close_date")
            if close_date:
                current_last = company_data[company_id]["last_purchase_date"]
                if not current_last or close_date > current_last:
                    company_data[company_id]["last_purchase_date"] = close_date

        return list(company_data.values())

    def _safe_float(self, value) -> float:
        if not value:
            return 0.0
        try:
            return float(value)
        except (ValueError, TypeError):
            return 0.0

    def _safe_int(self, value) -> Optional[int]:
        if not value:
            return None
        try:
            return int(value)
        except (ValueError, TypeError):
            return None

    def _parse_date(self, value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None

    def _parse_employee_band(self, value) -> Optional[str]:
        if not value:
            return None
        try:
            count = int(value)
            if count <= 10:
                return "1-10"
            elif count <= 50:
                return "11-50"
            elif count <= 200:
                return "51-200"
            elif count <= 500:
                return "201-500"
            elif count <= 1000:
                return "501-1000"
            else:
                return "1000+"
        except (ValueError, TypeError):
            return str(value)

    def _parse_revenue_band(self, value) -> Optional[str]:
        if not value:
            return None
        try:
            revenue = float(value)
            if revenue < 1_000_000:
                return "<$1M"
            elif revenue < 5_000_000:
                return "$1M-$5M"
            elif revenue < 20_000_000:
                return "$5M-$20M"
            elif revenue < 70_000_000:
                return "$20M-$70M"
            else:
                return "$70M+"
        except (ValueError, TypeError):
            return str(value)
