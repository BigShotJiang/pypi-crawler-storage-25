"""
Property mapping configuration for HubSpot custom properties.

Allows Pro/Enterprise users to configure which HubSpot custom properties
map to ICP scoring dimensions.
"""

from typing import Optional, Dict, List
from dataclasses import dataclass, field


@dataclass
class PropertyMapping:
    """Maps HubSpot properties to ICP scoring dimensions."""

    # Firmographic (usually standard properties)
    industry: str = "industry"
    annual_revenue: str = "annualrevenue"
    employee_count: str = "numberofemployees"
    geography_state: str = "state"
    geography_country: str = "country"

    # Behavioral - Tech Stack
    tech_stack: Optional[str] = None  # HubSpot property name for tech stack (multi-select or text)
    tech_stack_delimiter: str = ";"  # For splitting text fields

    # Behavioral - Growth Signals
    growth_signals: Optional[List[str]] = None  # List of HubSpot properties to check
    growth_signal_keywords: Dict[str, str] = field(default_factory=dict)  # Property → keyword mapping

    # Behavioral - Content Engagement
    content_engagement: Optional[str] = None  # HubSpot engagement score property
    content_engagement_thresholds: Dict[str, int] = field(default_factory=lambda: {
        "active": 5,  # >= 5 interactions
        "occasional": 1,  # 1-4 interactions
    })

    # Behavioral - Purchase History
    purchase_history_deal_count_threshold: Dict[str, int] = field(default_factory=lambda: {
        "regular": 3,  # >= 3 deals
        "occasional": 1,  # 1-2 deals
    })

    # Strategic Fit
    decision_maker_access: Optional[str] = None  # Custom property
    budget_authority: Optional[str] = None  # Custom property
    strategic_alignment: Optional[str] = None  # Custom property


# Default mapping (works with standard HubSpot properties only)
DEFAULT_PROPERTY_MAPPING = PropertyMapping()


# Example Pro user customization (for documentation)
EXAMPLE_CUSTOM_MAPPING = PropertyMapping(
    tech_stack="technologies_used",  # Custom property name
    growth_signals=["linkedin_job_postings", "recent_funding", "press_mentions_count"],
    growth_signal_keywords={
        "linkedin_job_postings": "hiring",
        "recent_funding": "funding",
        "press_mentions_count": "press",
    },
    content_engagement="hs_analytics_num_page_views",
    decision_maker_access="primary_contact_role",
    budget_authority="budget_status",
    strategic_alignment="revenue_ops_maturity",
)
