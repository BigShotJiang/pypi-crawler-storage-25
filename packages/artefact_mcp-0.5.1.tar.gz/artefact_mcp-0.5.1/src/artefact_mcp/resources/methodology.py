"""
Static methodology resources for the Artefact Revenue Intelligence MCP server.

Exposed as MCP resources so AI assistants can reference the scoring models,
tier definitions, segment definitions, and SPICED framework.
"""

SCORING_MODEL = """# ICP Triangulation Framework™

**Three-dimensional revenue intelligence. Because demographics alone don't close deals.**

Traditional ICP models stop at firmographics. Artefact triangulates across profile, activity, and momentum to identify revenue-ready prospects.

## Technical Implementation: 14.5-Point Scoring Model

### Dimension 1: Firmographic Fit (5 points)
- **Industry** (2 pts): Primary target = 2.0, Adjacent = 1.0, Tangential = 0.5, Outside = 0
- **Revenue Range** (1.5 pts): Sweet spot ($1.6M-$70M) = 1.5, Acceptable = 1.0, Stretch = 0.5, Outside = 0
- **Employee Count** (1 pt): Ideal (10-200) = 1.0, Borderline = 0.5, Outside = 0
- **Geography** (0.5 pts): Primary (Canada) = 0.5, Secondary (US) = 0.25, Outside = 0

### Dimension 2: Behavioral Fit (5 points)
*What they're doing — intent indicators*

- **Tech Stack Match** (2 pts): Full core (HubSpot+) = 2.0, Most = 1.5, Partial = 1.0, Minimal = 0.5, None = 0
- **Growth Signals** (1.5 pts): Multiple (3+) = 1.5, Some (2) = 1.0, Weak (1) = 0.5, None = 0
- **Content Engagement** (1 pt): Active = 1.0, Occasional = 0.5, None = 0
- **Purchase Frequency** (0.5 pts): Regular = 0.5, Occasional = 0.25, Never = 0

### Dimension 3: Strategic Fit (4.5 points)
*Where they're heading — buying power indicators*
- **Decision-Maker Access** (2 pts): C-suite = 2.0, Director = 1.5, Manager = 1.0, Indirect = 0.5, None = 0
- **Budget Authority** (1.5 pts): Dedicated = 1.5, Shared = 1.0, Possible = 0.5, None = 0
- **Strategic Alignment** (1 pt): Strong = 1.0, Partial = 0.5, Misaligned = 0

## Exclusions
Industries excluded from scoring: Agencies, Consulting firms, B2C/Retail, Non-profits, Staffing, Events Services, VC/PE

## 5 Discriminators (Must Have 4 of 5)
1. HubSpot Active User (Mandatory)
2. Revenue Architecture Conviction (Mandatory)
3. Marketing Function Engaged (Mandatory)
4. Clear Growth Targets (High)
5. Multiple Stakeholders (High)
"""

TIER_DEFINITIONS = """# ICP Tier Definitions

## Tier 1: Ideal (12.0 - 14.5 points)
- **Color:** Green | **HubSpot:** tier_1_ideal
- Pursue aggressively. Same-day response. Senior team, custom proposals, full pricing.
- Expected: 40-60% win rate, shortest cycle, highest LTV
- Distribution: 10-15% of addressable market

## Tier 2: Strong (9.0 - 11.9 points)
- **Color:** Blue | **HubSpot:** tier_2_strong
- Active pursuit. 24h response. Standard team, selective discounting.
- Expected: 25-40% win rate, moderate cycle, good LTV
- Distribution: 20-30% of addressable market

## Tier 3: Moderate (6.0 - 8.9 points)
- **Color:** Yellow | **HubSpot:** tier_3_moderate
- Selective — inbound or strategic only. 48h response. Junior team.
- Expected: 10-25% win rate, longer cycle, lower LTV
- Distribution: 30-40% of addressable market

## Tier 4: Poor (0 - 5.9 points)
- **Color:** Red | **HubSpot:** tier_4_poor
- Deprioritize — nurture only. No SLA. Fully automated.
- Expected: <10% win rate, longest cycle, lowest LTV
- Distribution: 20-30% of addressable market

## Health Check
- Tier 1: 10-15% (>25% or <5% = adjust thresholds)
- Tier 1+2: 30-45% (>60% or <20% = review criteria)
- Tier 4: 20-30% (>50% or <10% = revisit model)
"""

RFM_SEGMENTS = """# RFM Segment Definitions (11 Segments)

| Segment | R | F | Total | Action |
|---------|---|---|-------|--------|
| **Champions** | >=4 | >=4 | >=13 | Reward loyalty, ask for referrals |
| **Loyal Customers** | >=3 | >=3 | >=11 | Cross-sell, maintain relationship |
| **Potential Loyalists** | >=4 | 2-3 | >=9 | Nurture with targeted content |
| **New Customers** | =5 | =1 | >=8 | Exceptional onboarding |
| **Promising** | =4 | =1 | >=7 | Second purchase incentive |
| **Need Attention** | =3 | 2-3 | 7-10 | Re-engagement campaigns |
| **About to Sleep** | 2-3 | 1-2 | 5-8 | Win-back campaigns |
| **At Risk** | <=2 | >=3 | >=8 | Urgent outreach, investigate |
| **Can't Lose Them** | 1-2 | >=4 | >=10 | Executive outreach, service recovery |
| **Hibernating** | <=2 | <=2 | <=6 | Low-cost re-engagement |
| **Lost** | =1 | =1 | <=4 | Remove from active campaigns |

## Scoring Scales (1-5)
- **Recency:** Days since last purchase (lower = better). Default: <=30=5, 31-90=4, 91-180=3, 181-365=2, 366+=1
- **Frequency:** Transaction count (higher = better). Default: 10+=5, 5-9=4, 3-4=3, 2=2, 1=1
- **Monetary:** Revenue percentile (higher = better). Default: Top 20%=5, 60-80%=4, 40-60%=3, 20-40%=2, Bottom 20%=1

## Industry Presets
- **B2B Service:** Longer recency windows (60/180/365/730 days)
- **SaaS:** Shorter recency windows (30/60/90/180 days)
- **Manufacturing:** Longest cycles (90/365/730/1095 days)
"""

SPICED_FRAMEWORK = """# SPICED Discovery Framework

SPICED is Artefact Ventures' discovery methodology for extracting deal intelligence.

| Letter | Dimension | What to Extract |
|--------|-----------|-----------------|
| **S** | Situation | Current state — growth plateau, operational silos, tech stack, team structure |
| **P** | Pain | Core pain — revenue predictability, invisible ROI, departmental silos, manual processes |
| **I** | Impact | Quantified impact — $2-5M revenue lost annually, missed opportunities, team churn |
| **C** | Critical Event | Trigger — investor pressure, competitive threat, missed quarter, leadership change |
| **E** | Economic Buyer | Decision maker — typically CEO + CFO, 2-3 month decision cycle |
| **D** | Decision Process | Committee of 3-4, needs cross-functional alignment, approval workflow |

## Key Personas

### François - SMB CEO
- Pain: Revenue predictability, invisible marketing ROI
- Trigger: Investor pressure, competitive threat
- Cycle: 2-3 months, committee decision

### Martin - VP Sales
- Pain: Chaotic pipeline, underperforming team
- Trigger: Missed quarter, lost top performer
- Cycle: 2-4 weeks, needs CEO approval

## Qualification Signals

### Great Fit
- HubSpot active with data
- Leadership convinced on revenue architecture
- Marketing + Sales alignment
- Clear growth targets with timeline
- 2-3+ stakeholders engaged

### Poor Fit
- NOT convinced on CRM value
- NO marketing role/function
- NO clear vision or targets
- Single decision maker resistant to change
- Looking for "just a tool"
"""

DATA_REQUIREMENTS = """# Data Requirements for ICP Triangulation (qualify tool)

## Overview

The `qualify` tool uses the **ICP Triangulation Framework™** to score prospects across three dimensions:

- **🏢 Firmographic Fit** (Who they are) — Native HubSpot data
- **🎯 Behavioral Fit** (What they're doing) — Mixed: HubSpot + external enrichment required
- **📈 Growth Signals** (Where they're heading) — Requires external enrichment (Clay, Clearbit, manual research)

**Traditional ICP models stop at firmographics. Artefact triangulates across profile, activity, and momentum.**

## Firmographic Fit — ✅ Native HubSpot (No Setup Needed)

Available from standard HubSpot properties:
- **Industry** (2 pts): `industry` property
- **Revenue** (1.5 pts): `annualrevenue` property
- **Employee Count** (1 pt): `numberofemployees` property
- **Geography** (0.5 pts): `state`, `country` properties

## Behavioral Fit — Mixed Data Sources

### ✅ Available in HubSpot

**Tech Stack (2 pts):**
- Create custom property: `tech_stack` (multi-select or text)
- Options: HubSpot, Salesforce, Google Analytics, Marketing Automation, etc.
- Can detect some via website tracking (GTM, tracking codes)
- For deeper detection, use Clay or Clearbit enrichment

**Content Engagement (1 pt):**
- Native HubSpot tracking: page views, email opens/clicks, webinar attendance
- Create workflow to classify: "active" (5+ engagements/month), "occasional" (1-4), "none"
- Alternative: Use engagement score property

**Purchase History (0.5 pts):**
- Query closed-won deal count per company
- Create calculated property: "regular" (3+ deals), "occasional" (1-2), "never" (0)

### ⚠️ Requires External Enrichment

**Growth Signals (1.5 pts) — CRITICAL: Cannot be tracked in HubSpot alone**

HubSpot does not natively track:
- Hiring trends (LinkedIn job postings)
- Funding rounds (Crunchbase data)
- New product launches
- Office expansions, executive hires
- Press mentions, award wins

**Recommended Tools:**
- **Clay** (best option): LinkedIn job scraper, Crunchbase API, news mentions
- **Clearbit**: Company signals API
- **LinkedIn Sales Navigator**: Hiring alerts
- **ZoomInfo**: Growth intelligence

**Implementation with Clay:**
1. Create Clay table with HubSpot companies
2. Add enrichment columns:
   - "LinkedIn Job Postings" (count active postings)
   - "Recent Funding" (Crunchbase lookup)
   - "News Mentions" (Google News API)
3. Create "growth_signals" array: ["hiring", "funding", "expansion"]
4. Push to HubSpot custom property: `growth_signals` (multi-select)
5. Refresh quarterly via workflow

**Alternative (Manual):**
- Research during discovery calls
- Store in HubSpot: `growth_signals` (multi-select dropdown)
- Options: Hiring, Funding, Product Launch, Expansion, Press Mentions

## Strategic Fit — ✅ HubSpot Custom Properties

Create these custom properties in HubSpot (Settings > Properties > Company):

**Decision Maker Access (2 pts):**
- Property: `decision_maker_access` (dropdown)
- Options: "c_suite", "director", "manager", "indirect", "none"
- Populate based on contact roles
- Workflow: If deal has CEO/CFO/CRO contact → set to "c_suite"

**Budget Authority (1.5 pts):**
- Property: `budget_authority` (dropdown)
- Options: "dedicated", "shared", "possible", "none"
- Ask during discovery: "Do you have dedicated budget for this?"

**Strategic Alignment (1 pt):**
- Property: `strategic_alignment` (dropdown)
- Options: "strong", "partial", "misaligned"
- Assess during discovery: Does their GTM strategy align with Artefact methodology?

## Quick Setup Checklist

Before using `qualify` tool:
- [ ] Firmographic data populated (industry, revenue, employees, geography)
- [ ] `tech_stack` custom property created
- [ ] Content engagement tracking enabled (or engagement score property)
- [ ] Purchase history calculated (deal count per company)
- [ ] **Growth signals enrichment setup (Clay) OR manual research process**
- [ ] `decision_maker_access` custom property created
- [ ] `budget_authority` custom property created
- [ ] `strategic_alignment` custom property created

## Scoring Impact

**With full data (HubSpot + Clay enrichment):**
- Max score: 14.5 / 14.5 points
- Behavioral fit: 5 / 5 points

**Without growth signals enrichment:**
- Max score: 13 / 14.5 points (missing 1.5 pts)
- Behavioral fit: 3.5 / 5 points
- Impact: A Tier 1 prospect (Ideal) could drop to Tier 2 (Strong)

## Best Practice: Automate with Clay

1. Clay table: Weekly sync from HubSpot
2. Enrich: LinkedIn jobs, Crunchbase funding, news mentions
3. Calculate: `growth_signals` field
4. Push: Update HubSpot `growth_signals` property
5. AI calls: `qualify` tool with fresh, enriched data

This ensures ICP scoring is always based on current behavioral signals without manual research.
"""


def get_resource(name: str) -> str:
    """Get a methodology resource by name."""
    resources = {
        "scoring-model": SCORING_MODEL,
        "tier-definitions": TIER_DEFINITIONS,
        "rfm-segments": RFM_SEGMENTS,
        "spiced-framework": SPICED_FRAMEWORK,
        "data-requirements": DATA_REQUIREMENTS,
    }
    return resources.get(name, f"Unknown resource: {name}")


def list_resources() -> list[dict]:
    """List all available methodology resources."""
    return [
        {"uri": "methodology://scoring-model", "name": "ICP Triangulation Framework", "description": "Three-dimensional ICP scoring model reference"},
        {"uri": "methodology://tier-definitions", "name": "Tier Definitions", "description": "4-tier classification system"},
        {"uri": "methodology://rfm-segments", "name": "RFM Segments", "description": "11 RFM segment definitions"},
        {"uri": "methodology://spiced-framework", "name": "SPICED Framework", "description": "SPICED discovery extraction reference"},
        {"uri": "methodology://data-requirements", "name": "Data Requirements", "description": "HubSpot data setup and enrichment requirements for ICP triangulation"},
    ]
