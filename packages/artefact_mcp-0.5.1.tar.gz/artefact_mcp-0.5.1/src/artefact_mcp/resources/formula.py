"""Loader for the Artefact Formula GTM OS resources (P1 Free tier).

Reads the build artefacts produced by scripts/build_resources.py from
src/artefact_mcp/resources/_data/. No license required, no network calls.
"""

from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

_DATA_DIR = Path(__file__).resolve().parent / "_data"


@lru_cache(maxsize=1)
def _modules_payload() -> dict:
    return json.loads((_DATA_DIR / "modules.json").read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _kit_fondation_payload() -> dict:
    return json.loads((_DATA_DIR / "kit_fondation.json").read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _modes_payload() -> dict:
    return json.loads((_DATA_DIR / "modes.json").read_text(encoding="utf-8"))


def list_modules() -> list[dict]:
    """Compact catalog of all modules (id, title, pillar, sprint, duration)."""
    return [
        {
            "id": m["id"],
            "title": m["title"],
            "pillar": m["metadata"].get("Pilier", ""),
            "sprint": m["metadata"].get("Sprint", ""),
            "duration": m["metadata"].get("Durée séance", ""),
        }
        for m in _modules_payload()["modules"]
    ]


def get_module(module_id: str) -> dict | None:
    """Return the full module record by ID. Case-insensitive on the ID."""
    if not module_id:
        return None
    needle = module_id.strip().upper()
    for m in _modules_payload()["modules"]:
        if m["id"].upper() == needle:
            return m
    return None


def render_catalog() -> str:
    """Markdown catalog of all modules — for AI agents to discover available IDs."""
    entries = list_modules()
    by_prefix: dict[str, list[dict]] = {}
    for entry in entries:
        prefix = entry["id"].split("-", 1)[0]
        by_prefix.setdefault(prefix, []).append(entry)

    pillar_order = ["FOND", "ARC", "SKL", "WFL", "SNT", "GOV", "INT", "EXT", "POC", "DIY"]
    lines = [
        "# Artefact Formula — module catalog",
        "",
        "GTM Operating System methodology, organized by pillar.",
        f"{len(entries)} modules total. Call `module_prompt_free(module_id=\"FOND-1\")` to load any module's full body.",
        "",
    ]
    for prefix in pillar_order:
        if prefix not in by_prefix:
            continue
        lines.append(f"## {prefix}")
        lines.append("")
        for entry in by_prefix[prefix]:
            duration = f" ({entry['duration']})" if entry["duration"] else ""
            lines.append(f"- **{entry['id']}** — {entry['title']}{duration}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


# --- Embedded glossary (v0.4.6 — reduce methodology learning curve) ---
#
# One-line plain-English explanations injected into tool outputs so the
# agent can frame results without the user needing to read external docs.
# Keep entries SHORT (one sentence). Longer context belongs in module bodies.

_PILLAR_GLOSSARY: dict[str, str] = {
    "FOND": "Foundation — the master prompt file (CLAUDE.md), vault of secrets, glossary, repo metacontext. Bloquant for everything else.",
    "ARC": "Architecture — choice of technical archetype (A/B/C/D), server provisioning, structured logging.",
    "SKL": "Skills library — first skill (ship-QA pattern), catalog of 4-6 skills, import of Cat 2 OS Synapse skills.",
    "WFL": "Workflows — 3 critical workflows captured first, then file structure with Drive/SharePoint redundancy.",
    "SNT": "Sentinelles — scheduled governance checks that watch for silent failures (skill drift, stale metacontext, broken auth tokens).",
    "GOV": "Governance — product roadmap (Epic/PRD/Changelog), sponsor cadence, Loi 25 compliance, user onboarding.",
    "INT": "Interfaces — daily recap, MCPs (CRM/Knowledge/Productivity), conversational channels (Slack/Teams), auth tokens audit.",
    "EXT": "Export and handoff — cost monitoring, pilot autonomy dashboard, Phase 2 handoff, skill export to other functions.",
    "POC": "POC modules — 4-week proof of concept path (laptop setup, single skill, demo + metric, go/no-go gate).",
    "DIY": "DIY modules — sponsor-driven, pilot is reviewer not builder. Cadrage outputs, mapping data sources, review cadence.",
}

_MODE_GLOSSARY: dict[str, str] = {
    "Self-Serve": "Solo or small tech-savvy team building their AI Operating System through the Free tier. No mandate, low-touch.",
    "POC": "4-week proof of concept (~5K$). Pilot wants to validate value on their laptop with their own credentials before committing to a larger engagement.",
    "DIY": "DIY hosted (~30-50K$, 4-6 weeks). Sponsor wants outputs not co-construction. Pilot is reviewer, not builder.",
    "Co-Build": "Co-Build (~50-80K$, 8-12 weeks). Pilot has 5-8 h/week and learns alongside Artefact. Sponsor wants in-house autonomy after Phase 1.",
}

_ARCHETYPE_GLOSSARY: dict[str, str] = {
    "A": "Open / sovereign (Claude + Notion + Supabase Canada + OVH Beauharnois). Best for Loi 25 strict, public sector, Quebec PMEs. Artefact default.",
    "B": "Google-native (Gemini + Drive + Vertex AI + GCP Montreal). Best for Workspace-heavy scaleups and agencies.",
    "C": "Microsoft-native (Copilot + SharePoint + Azure OpenAI + Azure Canada). Best for M365-heavy industrial PMEs with existing Copilot licenses.",
    "D": "Hybrid / on-prem (Llama or Mistral + Postgres self-hosted). Best for sensitive data that cannot leave the perimeter (health, defense, R&D).",
}

_GATE_CONCEPT = (
    "A QA gate is a binary checklist that must clear before the pilot advances "
    "to the next module. Each item is either green or red. Red items block "
    "advancement to prevent drift (4-week debt tomorrow vs 1-hour fix today)."
)

_CLAUDE_MD_CONCEPT = (
    "CLAUDE.md is the master prompt file that codes your business logic into "
    "80 to 150 lines. It is the only file that survives an LLM swap or infra "
    "swap. The 5 sections (Identité, Business context, Équipe, KPIs, Workflow "
    "defaults) are read by your AI agents at the start of every session."
)


def pillar_for_module(module_id: str) -> str | None:
    """Extract the pillar prefix from a module ID like FOND-1 -> FOND."""
    if not module_id or "-" not in module_id:
        return None
    return module_id.split("-", 1)[0].upper()


def render_module(module: dict) -> str:
    """Return the module's full raw markdown body, prepended with a pillar
    context block so a new user understands which capability area they are
    in before reading the module body."""
    pillar = pillar_for_module(module.get("id", ""))
    body = module["raw_markdown"]
    if pillar and pillar in _PILLAR_GLOSSARY:
        prefix = f"> **Pillar context — {pillar}.** {_PILLAR_GLOSSARY[pillar]}\n\n"
        return prefix + body
    return body


# --- Archetype decision tree (kit-fondation/decision-tree-infra.md) ---

ARCHETYPES: dict[str, dict] = {
    "A": {
        "name": "Open / souverain",
        "stack": "Claude + Notion + Supabase Canada + OVH Beauharnois",
        "ideal_for": "Loi 25 stricte, organismes publics, PME québécoises, défaut Artefact",
        "advantages": [
            "Loi 25 native: tout le périmètre est en sol canadien (OVH Beauharnois, Supabase ca-central-1)",
            "Outillage Synapse mature: 8 skills Cat 2 OS Synapse partageables, 245 $/h justifié par l'IP partagée",
            "Pas de lock-in éditeur: Claude + Notion + Supabase peuvent être substitués indépendamment",
        ],
        "constraints": [
            "Coût infra fixe minimum (~32 $/mo OVH KS-1-B) — moins économique sub-3 utilisateurs vs B/C",
            "Expertise Linux/CLI requise pour l'admin serveur — moins clé-en-main que C/B",
            "Connecteurs SharePoint/OneDrive nécessitent MCPs custom — friction si client M365 lourd",
        ],
    },
    "B": {
        "name": "Google-natif",
        "stack": "Gemini + Drive + Vertex AI + GCP Montreal (northamerica-northeast1)",
        "ideal_for": "Scaleups et agences 100 % Workspace",
        "advantages": [
            "Faible friction adoption: les équipes Google sont déjà dans Drive/Gmail/Meet",
            "Loi 25 OK via GCP Montreal — vérifier que toute la chaîne reste en northamerica-northeast1",
            "Apps Script + Workflows GCP intègrent profondément avec Drive/Gmail",
        ],
        "constraints": [
            "Gemini Pro reste derrière Claude Opus / GPT-4 pour le raisonnement complexe (avril 2026)",
            "Lock-in Google: difficile de partir si Workspace est la fondation",
            "Outillage Artefact moins mature côté Gemini CLI que côté Claude Code",
        ],
    },
    "C": {
        "name": "Microsoft-natif",
        "stack": "Copilot + SharePoint + Azure OpenAI + Azure Canada Central",
        "ideal_for": "PME industrielles 100 % M365 avec licences Copilot existantes",
        "advantages": [
            "Faible friction adoption: les équipes M365 vivent déjà dans Outlook/Teams/SharePoint",
            "Copilot Studio + Power Automate offrent un low-code déjà connu des admins M365",
            "Loi 25 OK via Azure Canada Central + résidence des données Microsoft 365",
        ],
        "constraints": [
            "Coût licence Copilot (~30 $/user/mo) s'ajoute à l'infra — peut dépasser A pour <10 utilisateurs",
            "Lock-in Microsoft profond, moins de portabilité des skills que dans A",
            "GPT-4 via Azure parfois plus lent / quotas serrés que via OpenAI direct",
        ],
    },
    "D": {
        "name": "Hybride / on-prem",
        "stack": "Llama 3.3 / Mistral + Postgres self-hosted + bare metal ou VPC privé",
        "ideal_for": "Santé, défense, R&D sensible — données qui ne peuvent pas sortir du périmètre client",
        "advantages": [
            "Souveraineté absolue: aucune donnée ne quitte le périmètre physique du client",
            "Pas de dépendance LLM cloud: aucun risque de coupure ou changement de TOS amont",
            "Conformité forte pour secteurs réglementés (HIPAA-like, défense, R&D propriétaire)",
        ],
        "constraints": [
            "Coût infra et opération élevé: GPU dédiés ou VPC privé + maintenance",
            "Modèles open-source (Llama/Mistral) restent en retrait de Claude/GPT pour le raisonnement complexe",
            "Expertise interne requise (ML ops + sysadmin) — pas un mode self-serve",
        ],
    },
}


def archetype_decision(
    loi_25_strict: bool = False,
    m365_dominant: bool = False,
    google_workspace_dominant: bool = False,
    sovereignty_extreme: bool = False,
    can_adopt_open: bool = True,
) -> dict:
    """Run the 5-question decision tree and return the recommended archetype.

    Faithful to kit-fondation/decision-tree-infra.md:
      Q1 loi_25_strict True → skip Q2-Q4, evaluate Q5 directly (default A).
      Q2 m365_dominant True → C
      Q3 google_workspace_dominant True → B
      Q4 sovereignty_extreme True → D
      Q5 can_adopt_open True → A (default fallback)
    """
    decision_path: list[str] = []

    if loi_25_strict:
        decision_path.append("Q1: loi_25_strict=True → skip to Q5 (verify hors-Canada interdit)")
        if can_adopt_open:
            decision_path.append("Q5: can_adopt_open=True → A (default Artefact, pattern Synapse)")
            archetype = "A"
        else:
            decision_path.append(
                "Q5: can_adopt_open=False → A flagged for review (Loi 25 strict + ouvert refusé "
                "implique souvent une discussion avec le sponsor sur le périmètre acceptable)"
            )
            archetype = "A"
    else:
        decision_path.append("Q1: loi_25_strict=False → continue")
        if m365_dominant:
            decision_path.append("Q2: m365_dominant=True → C (Microsoft-natif)")
            archetype = "C"
        elif google_workspace_dominant:
            decision_path.append("Q2: m365_dominant=False")
            decision_path.append("Q3: google_workspace_dominant=True → B (Google-natif)")
            archetype = "B"
        elif sovereignty_extreme:
            decision_path.append("Q2-Q3: ni M365 ni Google dominant")
            decision_path.append("Q4: sovereignty_extreme=True → D (hybride / on-prem)")
            archetype = "D"
        elif can_adopt_open:
            decision_path.append("Q2-Q4: aucune contrainte forte")
            decision_path.append("Q5: can_adopt_open=True → A (default Artefact)")
            archetype = "A"
        else:
            decision_path.append("Q2-Q5: aucun match clair → A par défaut, flagged for review")
            archetype = "A"

    info = ARCHETYPES[archetype]
    return {
        "archetype": archetype,
        "name": info["name"],
        "archetype_explainer": _ARCHETYPE_GLOSSARY.get(archetype, ""),
        "stack": info["stack"],
        "ideal_for": info["ideal_for"],
        "advantages": info["advantages"],
        "constraints": info["constraints"],
        "decision_path": decision_path,
        "next_module": "ARC-2 — provisioning serveur / sandbox",
    }


# --- auto_diagnose: hybrid mode + module router (option C) ---
#
# Strong-signal scoring on the 4 modes (Self-Serve / POC / DIY / Co-Build),
# bilingual FR + EN keyword detection. Falls back to a structured framing
# question set when input is empty or ambiguous (gap < 2 between top-1 and
# top-2 mode scores).

# Bias signal definitions. Each signal contributes `weight` points to one mode.
# Order matters only for the `signals_detected` trace; scoring is sum-based.
_MODE_SIGNALS: list[dict] = [
    # ---- POC bias ----
    {
        "mode": "POC",
        "weight": 3,
        "keywords": [
            "poc",
            "proof of concept",
            "preuve de concept",
            "valider rapidement",
            "validate quickly",
            "tester la valeur",
            "test the value",
            "tester rapidement",
            "test it fast",
            "test this fast",
            "avant de s'engager",
            "before committing",
            "before signing",
            "essai pilote",
            "pilot test",
        ],
    },
    {
        "mode": "POC",
        "weight": 2,
        "keywords": [
            "4 semaines",
            "4 weeks",
            "2-3 semaines",
            "2-3 weeks",
            "deux semaines",
            "two weeks",
            "court mandat",
            "short engagement",
            "quick win",
            "gain rapide",
        ],
    },
    # ---- DIY bias ----
    {
        "mode": "DIY",
        "weight": 3,
        "keywords": [
            "pas de bandwidth",
            "no bandwidth",
            "pas le temps",
            "don't have time",
            "do not have time",
            "sponsor veut un livrable",
            "sponsor wants a deliverable",
            "sponsor wants the work done",
            "sponsor wants outputs",
            "want outputs",
            "wants outputs",
            "want results",
            "wants results",
            "want it done for me",
            "done for me",
            "done it for you",
            "fait pour moi",
            "hands off",
            "reviewer",
            "be reviewers",
            "etre reviewer",
            "être reviewer",
        ],
    },
    {
        "mode": "DIY",
        "weight": 2,
        "keywords": [
            "50 personnes",
            "50 employees",
            "100 employees",
            "200 personnes",
            "équipe de 50",
            "team of 50",
            "vp ops",
            "directeur exécutif",
            "executive sponsor only",
            "pme industrielle",
            "4-6 weeks",
            "4-6 semaines",
            "4 à 6 semaines",
            "4 to 6 weeks",
            "outputs fast",
            "results fast",
        ],
    },
    # ---- Co-Build bias ----
    {
        "mode": "Co-Build",
        "weight": 3,
        "keywords": [
            "co-build",
            "co-construction",
            "co-construire",
            "pilote disponible",
            "pilot available",
            "5 à 8 heures",
            "5-8 heures",
            "5 to 8 hours",
            "5-8h/sem",
            "5h/sem",
            "motivé pour apprendre",
            "motivated to learn",
            "wants to learn",
            "willing to learn",
            "veut apprendre",
            "build it together",
            "construire ensemble",
        ],
    },
    {
        "mode": "Co-Build",
        "weight": 2,
        "keywords": [
            "autonomie",
            "autonomy",
            "8 à 12 semaines",
            "8-12 semaines",
            "8 to 12 weeks",
            "8-12 weeks",
            "phase 2",
            "handoff",
            "in-house capability",
            "capacité interne",
        ],
    },
    # ---- Self-Serve bias ----
    {
        "mode": "Self-Serve",
        "weight": 3,
        "keywords": [
            "fondateur solo",
            "solo founder",
            "founder solo",
            "i'm solo",
            "je suis solo",
            "je suis fondateur",
            "free tier",
            "gratuit",
            "essayer gratuit",
            "try for free",
            "tech-savvy",
            "self-serve",
            "self serve",
        ],
    },
    {
        "mode": "Self-Serve",
        "weight": 2,
        "keywords": [
            "moins de 10",
            "less than 10",
            "< 10 personnes",
            "under 10 people",
            "small team",
            "petite équipe",
            "startup saas",
            "saas startup",
            "i want to try",
            "je veux essayer",
            "explore",
            "explorer",
            "budget limité",
            "limited budget",
            "tight budget",
            "apprendre par nous-mêmes",
            "learn ourselves",
            "learn on our own",
            "self-taught",
        ],
    },
]

# Negation tokens — when one appears within ~30 chars BEFORE a matched
# keyword, the hit is dropped. Prevents "pas de bandwidth pour co-construire"
# from awarding Co-Build a positive signal on "co-construire".
_NEGATION_TOKENS: tuple[str, ...] = (
    "pas de",
    "pas le",
    "pas la",
    "ne pas",
    "aucun",
    "aucune",
    "sans ",
    "no ",
    "not ",
    "don't",
    "do not",
    "doesn't",
    "does not",
    "without ",
    "lacking ",
)
_NEGATION_WINDOW = 30  # chars before keyword

# Archetype hints scanned independently of mode signals.
_ARCHETYPE_HINTS: list[dict] = [
    {
        "code": "A",
        "weight": 3,
        "keywords": [
            "loi 25",
            "law 25",
            "organisme public",
            "public sector",
            "souveraineté",
            "data sovereignty",
            "ovh",
            "supabase canada",
        ],
    },
    {
        "code": "C",
        "weight": 3,
        "keywords": [
            "microsoft 365",
            "m365",
            "sharepoint",
            "outlook teams",
            "copilot license",
            "licence copilot",
            "azure",
        ],
    },
    {
        "code": "B",
        "weight": 3,
        "keywords": [
            "google workspace",
            "google drive",
            "gmail",
            "vertex ai",
            "gemini cli",
        ],
    },
    {
        "code": "D",
        "weight": 3,
        "keywords": [
            "on-prem",
            "on prem",
            "bare metal",
            "data must not leave",
            "données ne peuvent pas sortir",
            "santé sensible",
            "défense",
            "defense sector",
            "self-hosted llm",
            "llama 3.3",
            "mistral self-hosted",
        ],
    },
]

# Mode → starting module + parallel modules + next-after.
_MODE_TO_MODULES: dict[str, dict] = {
    "Self-Serve": {
        "starting_module": "FOND-1",
        "parallel_modules": ["ARC-1"],
        "next_module_after_starting": "SKL-1",
    },
    "POC": {
        "starting_module": "POC-1",
        "parallel_modules": [],
        "next_module_after_starting": "POC-2",
    },
    "DIY": {
        "starting_module": "DIY-1",
        "parallel_modules": [],
        "next_module_after_starting": "DIY-2",
    },
    "Co-Build": {
        "starting_module": "FOND-1",
        "parallel_modules": ["ARC-1"],
        "next_module_after_starting": "SKL-1",
    },
}

_FRAMING_QUESTIONS: list[str] = [
    "Who is the pilot? (solo founder, dedicated employee, executive sponsor only, etc.)",
    "How much weekly bandwidth does the pilot have? (under 2h, 5–8h, more)",
    "What is the engagement horizon? (open-ended self-serve, 4-week POC, 4–6-week DIY, 8–12-week Co-Build)",
    "What is the dominant infrastructure? (Microsoft 365, Google Workspace, mixed/open, on-prem)",
    "Is Loi 25 / data sovereignty a hard constraint?",
]

_MODE_RATIONALES: dict[str, str] = {
    "Self-Serve": "Solo or small tech-savvy team exploring without active mandate — fits Free tier coaching.",
    "POC": "Short validation window (2–4 weeks) before committing to a larger engagement.",
    "DIY": "Sponsor wants outputs, not co-construction — pilot is reviewer, not builder.",
    "Co-Build": "Pilot has 5–8h/week and motivation to learn the system alongside Artefact.",
}


def _is_negated(text_lower: str, kw_start: int) -> bool:
    """Return True if a negation token appears within _NEGATION_WINDOW chars
    before the keyword start position."""
    window_start = max(0, kw_start - _NEGATION_WINDOW)
    window = text_lower[window_start:kw_start]
    return any(neg in window for neg in _NEGATION_TOKENS)


def _scan_signals(text_lower: str, signal_groups: list[dict]) -> list[dict]:
    """Return matching signal hits, dropping any keyword preceded by a
    negation token within _NEGATION_WINDOW chars."""
    hits: list[dict] = []
    for group in signal_groups:
        for kw in group["keywords"]:
            idx = text_lower.find(kw)
            if idx == -1:
                continue
            if _is_negated(text_lower, idx):
                continue
            hits.append(
                {
                    "keyword": kw,
                    "weight": group["weight"],
                    "target": group.get("mode") or group.get("code"),
                }
            )
    return hits


def auto_diagnose(context: str = "") -> dict:
    """Recommend a deployment mode + starting module from a free-text context.

    Hybrid scoring (option C):
      - Bilingual FR + EN keyword scan against 4 modes.
      - Gap >= 2 between top-1 and top-2 → confidence "high".
      - Gap < 2 → confidence "medium" + disambiguation questions.
      - Empty input → confidence "framing" + the 5 framing questions.
    """
    text = (context or "").strip()
    if not text:
        return {
            "mode": None,
            "confidence": "framing",
            "reasoning": "No context provided. Ask the pilot the framing questions below, then call auto_diagnose again with their answers.",
            "starting_module": None,
            "parallel_modules": [],
            "next_module_after_starting": None,
            "alternatives": [],
            "disambiguation_questions": list(_FRAMING_QUESTIONS),
            "signals_detected": [],
        }

    text_lower = text.lower()

    # Score each mode
    mode_hits = _scan_signals(text_lower, _MODE_SIGNALS)
    scores: dict[str, int] = {"Self-Serve": 0, "POC": 0, "DIY": 0, "Co-Build": 0}
    for hit in mode_hits:
        scores[hit["target"]] += hit["weight"]

    # Score archetype hints
    archetype_hits = _scan_signals(text_lower, _ARCHETYPE_HINTS)
    archetype_scores: dict[str, int] = {}
    for hit in archetype_hits:
        archetype_scores[hit["target"]] = archetype_scores.get(hit["target"], 0) + hit["weight"]
    archetype_hint = max(archetype_scores, key=archetype_scores.get) if archetype_scores else None

    # Rank modes
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    top_mode, top_score = ranked[0]
    second_mode, second_score = ranked[1]
    gap = top_score - second_score

    # No signals at all → degrade to framing
    if top_score == 0:
        return {
            "mode": None,
            "confidence": "framing",
            "reasoning": "No strong mode signals detected in the provided context. Use the framing questions below to qualify the pilot.",
            "starting_module": None,
            "parallel_modules": [],
            "next_module_after_starting": None,
            "alternatives": [],
            "disambiguation_questions": list(_FRAMING_QUESTIONS),
            "signals_detected": [],
            **({"archetype_hint": archetype_hint} if archetype_hint else {}),
        }

    # Revised confidence: gap alone is brittle on low absolute scores.
    # high if gap >= 3, OR (gap >= 2 AND top_score >= 6).
    # Otherwise medium. This catches "5 vs 3" ambiguity that the simpler
    # gap >= 2 rule mis-classified as high.
    if gap >= 3 or (gap >= 2 and top_score >= 6):
        confidence = "high"
    else:
        confidence = "medium"
    modules = _MODE_TO_MODULES[top_mode]

    # Reasoning string (EN-first, with FR keywords cited verbatim)
    cited = ", ".join(f'"{h["keyword"]}"' for h in mode_hits if h["target"] == top_mode)
    reasoning = (
        f"{_MODE_RATIONALES[top_mode]} Detected signals for {top_mode}: {cited}."
        if cited
        else _MODE_RATIONALES[top_mode]
    )

    # Alternatives = next-best modes that scored > 0
    alternatives = []
    for mode_name, mode_score in ranked[1:]:
        if mode_score == 0:
            continue
        alternatives.append(
            {
                "mode": mode_name,
                "score": mode_score,
                "why_not": (
                    f"Lower score than {top_mode} ({mode_score} vs {top_score}). "
                    f"Would apply if: {_MODE_RATIONALES[mode_name]}"
                ),
            }
        )

    # Disambiguation only when confidence is medium
    disambiguation: list[str] = []
    if confidence == "medium":
        disambiguation = [
            f"Between {top_mode} and {second_mode}: how committed is the pilot to a multi-week engagement vs a fast validation?",
            "Does the sponsor want to co-build (pilot learns alongside) or just receive a working system?",
            "What is the firm budget envelope and timeline?",
        ]

    response: dict = {
        "mode": top_mode,
        "mode_explainer": _MODE_GLOSSARY.get(top_mode, ""),
        "confidence": confidence,
        "reasoning": reasoning,
        "starting_module": modules["starting_module"],
        "starting_module_pillar_explainer": (
            _PILLAR_GLOSSARY.get(pillar_for_module(modules["starting_module"]) or "", "")
        ),
        "parallel_modules": list(modules["parallel_modules"]),
        "next_module_after_starting": modules["next_module_after_starting"],
        "alternatives": alternatives,
        "disambiguation_questions": disambiguation,
        "signals_detected": mode_hits,
    }
    if archetype_hint:
        response["archetype_hint"] = archetype_hint
        response["archetype_hint_explainer"] = _ARCHETYPE_GLOSSARY.get(archetype_hint, "")
    return response


# --- generate_claude_md: hybrid CLAUDE.md scaffolder (option D) ---
#
# Empty input → raw template (placeholders intact), completeness="template".
# Partial dict → render with markers + missing_required_fields populated.
# Complete dict → clean render, completeness="complete".
# Invalid JSON → error JSON returned (does not raise).
#
# The template is embedded as a Python literal (extracted from
# kit-fondation/CLAUDE-md-template-annote.md). No runtime markdown parsing.

_CLAUDE_MD_TEMPLATE = """# {{CLIENT}} — Système opératoire IA — CLAUDE.md master

<!-- Ce fichier code la logique d'affaires du système. Le LLM est remplaçable, ce fichier non. -->
<!-- Limite stricte : 80-150 lignes. Au-delà, déplacer vers project MDs liés. -->

## 1. Identité

- **Pilote :** {{PILOTE_PRENOM}} {{PILOTE_NOM}} — {{ROLE_PILOTE}}
- **Sponsor :** {{SPONSOR_PRENOM}} {{SPONSOR_NOM}} — {{ROLE_SPONSOR}}
- **Fonction visée :** {{FONCTION}}
- **Mandat actif :** {{NOM_OFFRE}} — Phase 1 du {{KICKOFF_DATE}} au {{FIN_PHASE_1}}

## 2. Business context

<!-- Pour chaque transition active, préciser le pourquoi et l'échéance. Sinon le système ne saura pas prioriser. -->

- **Entreprise :** {{CLIENT}} — {{SECTEUR}}, {{TAILLE_EQUIPE}}, {{REVENUS_ANNUELS}}
- **Produits / services principaux :** {{LISTE_PRODUITS}}
- **ICP :** {{DESCRIPTION_ICP}}
- **Contraintes connues :** {{CONTRAINTES}}
- **Transitions actives :** {{TRANSITIONS}}

## 3. Équipe

<!-- Format `Prénom (Rôle) — décide pour / joignable pour`. Le « pour quoi » importe plus que le titre. -->

{{EQUIPE_BLOCK}}

## 4. KPIs prioritaires

{{KPIS_BLOCK}}

## 5. Workflow defaults

- **Langue :** {{LANGUE}} — répondre dans la langue du message
- **Ton :** {{TON}}
- **Conventions :** plan-mode-first (proposer un plan détaillé avant exécution sur tâches non triviales), pas d'em dashes en français pro, accents français obligatoires
- **Skills :** auto-discovery dans `~/.claude/skills/` et `.claude/skills/`
- **Notion changelog :** chaque commit logué dans la DB Changelog
- **Cadence sponsor :** {{CADENCE_SPRINT_REVIEW}}

## Modules détaillés

{{LINKED_MDS_BLOCK}}
"""

_REQUIRED_FIELDS: tuple[tuple[str, str], ...] = (
    ("client_name", "{{CLIENT}}"),
    ("pilot.first_name", "{{PILOTE_PRENOM}}"),
    ("pilot.role", "{{ROLE_PILOTE}}"),
    ("function", "{{FONCTION}}"),
    ("kpis", "{{KPIS_BLOCK}}"),
)

_RECOMMENDED_FIELDS: tuple[str, ...] = (
    "sponsor.first_name",
    "sector",
    "team_size",
    "mandate_name",
    "kickoff_date",
    "language",
    "icp_description",
)

_QA_GATE_QUESTIONS: tuple[str, ...] = (
    "Who is my client?",
    "What is my role?",
    "What are my 3 priority KPIs?",
    "Where are my skills?",
)

_NEXT_MODULE = "FOND-2 — Vault de secrets"

_LINE_BUDGET = (80, 150)


def _get_nested(d: dict, dotted_key: str):
    """Resolve 'pilot.first_name' against a nested dict. Returns None if missing."""
    parts = dotted_key.split(".")
    current = d
    for part in parts:
        if not isinstance(current, dict):
            return None
        if part not in current:
            return None
        current = current[part]
    return current


def _render_team_block(fields: dict) -> str:
    pilot = fields.get("pilot") or {}
    sponsor = fields.get("sponsor") or {}
    collaborators = fields.get("collaborators") or []

    lines: list[str] = []
    if pilot.get("first_name"):
        last = f" {pilot.get('last_name')}" if pilot.get("last_name") else ""
        role = pilot.get("role", "{{ROLE_PILOTE}}")
        lines.append(f"- **{pilot['first_name']}{last}** ({role}) — pilote du système")
    else:
        lines.append("- **{{PILOTE_PRENOM}}** ({{ROLE_PILOTE}}) — pilote du système")

    if sponsor.get("first_name"):
        last = f" {sponsor.get('last_name')}" if sponsor.get("last_name") else ""
        role = sponsor.get("role", "{{ROLE_SPONSOR}}")
        lines.append(f"- **{sponsor['first_name']}{last}** ({role}) — sponsor exécutif")
    else:
        lines.append("- **{{SPONSOR_PRENOM}}** ({{ROLE_SPONSOR}}) — sponsor exécutif")

    for c in collaborators:
        if not isinstance(c, dict):
            continue
        name = c.get("name", "{{COLLABORATEUR}}")
        role = c.get("role", "{{ROLE}}")
        scope = c.get("scope", "{{ZONE_EXPERTISE}}")
        lines.append(f"- **{name}** ({role}) — joignable pour {scope}")

    lines.append("- **Artefact externe :** Alex Boissonneault — animateur Phase 1")
    return "\n".join(lines)


def _render_kpis_block(kpis: list, warnings: list[str]) -> str:
    if not kpis:
        # Fallback to placeholder block — kpis missing is a required-field gap
        return (
            "1. **{{KPI_1}}** — cible {{VALEUR_CIBLE}}, mesurée {{FREQUENCE}}\n"
            "2. **{{KPI_2}}** — cible {{VALEUR_CIBLE}}, mesurée {{FREQUENCE}}\n"
            "3. **{{KPI_3}}** — cible {{VALEUR_CIBLE}}, mesurée {{FREQUENCE}}"
        )

    if len(kpis) > 3:
        warnings.append(
            f"KPI section has {len(kpis)} entries — maximum 3 recommended (FOND-1 gate)"
        )

    lines: list[str] = []
    for i, kpi in enumerate(kpis[:3], start=1):
        if not isinstance(kpi, dict):
            continue
        name = kpi.get("name", f"{{{{KPI_{i}}}}}")
        target = kpi.get("target")
        frequency = kpi.get("frequency")
        if not target or not frequency:
            warnings.append(
                f"KPI #{i} ('{name}') is missing target and/or frequency — "
                "treat as theme, not measurable KPI (FOND-1 gate)"
            )
        target_str = target or "{{VALEUR_CIBLE}}"
        freq_str = frequency or "{{FREQUENCE}}"
        lines.append(f"{i}. **{name}** — cible {target_str}, mesurée {freq_str}")
    return "\n".join(lines)


def _render_linked_mds(linked_mds: list) -> str:
    if not linked_mds:
        return (
            "- Voir [docs/CLAUDE-{{produit}}.md](./CLAUDE-{{produit}}.md) pour le contexte produit\n"
            "- Voir [docs/CLAUDE-{{fonction}}.md](./CLAUDE-{{fonction}}.md) pour le contexte fonction\n"
            "- Voir [docs/CLAUDE-{{workflow-critique}}.md](./CLAUDE-{{workflow-critique}}.md) pour les workflows"
        )
    lines = []
    for slug in linked_mds[:5]:  # cap at 5 per FOND-1 guidance
        slug_str = str(slug).strip()
        lines.append(
            f"- Voir [docs/CLAUDE-{slug_str}.md](./CLAUDE-{slug_str}.md) pour {slug_str}"
        )
    if len(linked_mds) > 5:
        lines.append(f"<!-- {len(linked_mds) - 5} link(s) skipped — master max 5 linked MDs -->")
    return "\n".join(lines)


def generate_claude_md(fields: str = "") -> dict:
    """Render a CLAUDE.md master scaffold from a JSON fields dict.

    Hybrid (option D):
      - Empty input → raw template (placeholders intact), completeness="template"
      - Partial dict → render with markers + missing_required_fields populated
      - Complete dict → clean render, completeness="complete"
      - Invalid JSON → returns {"error": ...} (does not raise)
    """
    fields_str = (fields or "").strip()

    if not fields_str:
        rendered = _render_template(data={})
        return {
            "rendered_markdown": rendered,
            "completeness": "template",
            "claude_md_concept": _CLAUDE_MD_CONCEPT,
            "missing_required_fields": [k for k, _ in _REQUIRED_FIELDS],
            "missing_recommended_fields": list(_RECOMMENDED_FIELDS),
            "warnings": [],
            "length_status": "template",
            "line_count": len(rendered.splitlines()),
            "qa_gate_questions": list(_QA_GATE_QUESTIONS),
            "next_module": _NEXT_MODULE,
        }

    try:
        data = json.loads(fields_str)
    except (json.JSONDecodeError, TypeError) as e:
        return {"error": f"Invalid fields JSON: {e}"}
    if not isinstance(data, dict):
        return {"error": "fields must be a JSON object (dict)"}

    warnings: list[str] = []
    rendered = _render_template(data=data, warnings=warnings)

    # Detect missing required / recommended
    missing_required = []
    for key, _ in _REQUIRED_FIELDS:
        val = _get_nested(data, key)
        if val is None or val == "" or val == []:
            missing_required.append(key)

    missing_recommended = []
    for key in _RECOMMENDED_FIELDS:
        val = _get_nested(data, key)
        if val is None or val == "" or val == []:
            missing_recommended.append(key)

    if missing_required == []:
        completeness = "complete"
    elif len(missing_required) == len(_REQUIRED_FIELDS):
        completeness = "template"
    else:
        completeness = "partial"

    # Length budget check
    line_count = len(rendered.splitlines())
    lo, hi = _LINE_BUDGET
    if line_count < lo:
        length_status = "under_target"
        warnings.append(
            f"Rendered length {line_count} lines is below the {lo}-{hi} target "
            "(FOND-1). Pilot likely needs to flesh out business context, team, and constraints."
        )
    elif line_count > hi:
        length_status = "over_target"
        warnings.append(
            f"Rendered length {line_count} lines exceeds the {lo}-{hi} target "
            "(FOND-1 strict limit). Move detail into linked project MDs."
        )
    else:
        length_status = "ok"

    return {
        "rendered_markdown": rendered,
        "completeness": completeness,
        "claude_md_concept": _CLAUDE_MD_CONCEPT,
        "missing_required_fields": missing_required,
        "missing_recommended_fields": missing_recommended,
        "warnings": warnings,
        "length_status": length_status,
        "line_count": line_count,
        "qa_gate_questions": list(_QA_GATE_QUESTIONS),
        "next_module": _NEXT_MODULE,
    }


# --- gate_check: hybrid module gate validator (option C) ---
#
# Empty input → framing + list of modules with gates.
# module_id only → checklist (pending), evidence_provided=False on all items.
# module_id + evidence (list or dict) → pass/fail per item, advancement signal.

_GATE_SECTION_RE = re.compile(r"## QA gate[^\n]*\n(.*?)(?=\n## |\Z)", re.DOTALL)
_GATE_ITEM_RE = re.compile(r"^\* \[ \] (.+)$", re.MULTILINE)
_GATE_LABEL_RE = re.compile(r"^(?:\*\*(.+?)\*\*\s*(?:[—:]|→)?\s*)?(.*)$")
_NEXT_MODULE_RE = re.compile(
    r"(?:ne pas passer (?:à|au) )([A-Z]+-\d+)|(?:passer (?:à|au) )([A-Z]+-\d+)",
    re.IGNORECASE,
)
_NEGATIVE_TOKENS: tuple[str, ...] = (
    # Direct negations FR
    "non,",
    "non ",
    "n'est pas",
    "n'a pas",
    "il n'y a pas",
    "pas encore",
    "pas validé",
    "pas validée",
    "pas fait",
    "pas faite",
    # Direct negations EN
    "no,",
    "no ",
    "not yet",
    "not validated",
    "not done",
    # Pending status FR
    "à faire",
    "à confirmer",
    "à valider",
    "en attente",
    "en cours",
    "tbd",
    "todo",
    # Pending status EN
    "pending",
    "in progress",
    "on hold",
    "incomplete",
    # Explicit failure
    "fail",
    "refusé",
    "rejeté",
    "bloqué",
    "rejected",
    "blocked",
)


def parse_gate(module: dict) -> list[dict]:
    """Extract gate items from a module's raw_markdown.

    Returns a list of {index, label, description, raw} dicts. The label is
    the bold-prefixed text (or the full line if no bold), and description is
    whatever follows after the separator.
    """
    if not module:
        return []
    md = module.get("raw_markdown", "")
    section_match = _GATE_SECTION_RE.search(md)
    if not section_match:
        return []
    section = section_match.group(1)
    raw_items = _GATE_ITEM_RE.findall(section)
    items: list[dict] = []
    for i, raw in enumerate(raw_items, start=1):
        m = _GATE_LABEL_RE.match(raw.strip())
        if m:
            label = (m.group(1) or m.group(2) or raw).strip().strip('«»"')
            description = m.group(2).strip() if m.group(1) else ""
        else:
            label = raw.strip()
            description = ""
        items.append({
            "index": i,
            "label": label,
            "description": description,
            "raw": raw.strip(),
        })
    return items


def _next_module_for(module: dict) -> str | None:
    """Heuristic: scan the gate's closing sentence for 'ne pas passer à X'
    or 'passer à X', else fallback to alphabetical successor. Validates
    the resulting ID against the catalog so terminal modules (POC-4,
    EXT-5...) don't return a non-existent next."""
    catalog_ids = {m["id"].upper() for m in _modules_payload()["modules"]}

    md = module.get("raw_markdown", "")
    for match in _NEXT_MODULE_RE.finditer(md):
        candidate = match.group(1) or match.group(2)
        if candidate and candidate.upper() != module["id"].upper():
            cand_upper = candidate.upper()
            if cand_upper in catalog_ids:
                return cand_upper

    # Alphabetical fallback: same prefix, +1 numeric suffix — only if it exists
    parts = module["id"].split("-")
    if len(parts) == 2 and parts[1].isdigit():
        candidate = f"{parts[0]}-{int(parts[1]) + 1}"
        if candidate in catalog_ids:
            return candidate
    return None


def _evidence_for_item(evidence: dict | list | None, index: int):
    """Look up evidence for a 1-indexed item from either list or dict shape."""
    if evidence is None:
        return None
    if isinstance(evidence, list):
        if index - 1 < len(evidence):
            return evidence[index - 1]
        return None
    if isinstance(evidence, dict):
        # Try string and int keys
        for key in (str(index), index):
            if key in evidence:
                return evidence[key]
    return None


def _evaluate_evidence(value) -> tuple[bool, bool]:
    """Return (evidence_provided, passes) for one evidence value."""
    if value is None:
        return False, False
    if isinstance(value, bool):
        return True, value
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return False, False
        lower = stripped.lower()
        # Negative-token detection — string proofs that read like "not yet"
        for tok in _NEGATIVE_TOKENS:
            if tok in lower:
                return True, False
        return True, True
    # numbers, other truthy values
    return True, bool(value)


def gate_check(module_id: str = "", evidence: str = "") -> dict:
    """Evaluate a module's QA gate.

    Hybrid (option C):
      - Empty module_id → framing + module list
      - module_id only → pending checklist
      - module_id + evidence (JSON list or dict) → pass/fail per item

    Evidence can be:
      - List of {bool | str | None} positionally aligned to gate items
      - Dict mapping "1" / "2" / ... (1-indexed) to {bool | str}

    String evidence containing a negative token (non, pas encore, todo, tbd)
    counts as fail, not pass.
    """
    mid = (module_id or "").strip().upper()

    # Framing path
    if not mid:
        modules = []
        for m in _modules_payload()["modules"]:
            if parse_gate(m):
                modules.append(m["id"])
        return {
            "gate_status": "framing",
            "modules_with_gates": sorted(modules),
            "guidance": (
                "Call gate_check(module_id) to load that module's gate as a "
                "checklist. Call gate_check(module_id, evidence) where evidence "
                "is a JSON list of bools/strings positionally aligned to the "
                "gate items, or a dict {\"1\": true, ...} (1-indexed)."
            ),
        }

    module = get_module(mid)
    if not module:
        return {
            "error": f"Unknown module ID: {module_id}. "
            "Call gate_check() with no args to see available modules."
        }

    items = parse_gate(module)
    if not items:
        return {
            "error": f"Module {mid} has no parseable QA gate."
        }

    # Parse evidence
    parsed_evidence = None
    evidence_str = (evidence or "").strip()
    if evidence_str:
        try:
            parsed_evidence = json.loads(evidence_str)
        except (json.JSONDecodeError, TypeError) as e:
            return {"error": f"Invalid evidence JSON: {e}"}
        if not isinstance(parsed_evidence, (list, dict)):
            return {"error": "evidence must be a JSON list or dict"}

    # Evaluate each item
    gate_items_out: list[dict] = []
    items_passed = 0
    blocking_failures: list[int] = []
    missing_evidence: list[int] = []

    for item in items:
        value = _evidence_for_item(parsed_evidence, item["index"])
        provided, passes = _evaluate_evidence(value)
        if provided and passes:
            items_passed += 1
        elif provided and not passes:
            blocking_failures.append(item["index"])
        else:
            missing_evidence.append(item["index"])

        gate_items_out.append({
            "index": item["index"],
            "label": item["label"],
            "evidence_provided": provided,
            "passes": provided and passes,
            "evidence_value": value if value is not None else None,
        })

    items_total = len(items)
    if parsed_evidence is None:
        gate_status = "pending"
    elif blocking_failures:
        gate_status = "fail"
    elif missing_evidence:
        gate_status = "partial"
    else:
        gate_status = "pass"

    advancement_blocked = gate_status in ("fail", "partial", "pending")
    next_module = _next_module_for(module) if gate_status == "pass" else None

    if gate_status == "pass":
        if next_module:
            guidance = f"Gate cleared. Advance to {next_module}."
        else:
            guidance = (
                f"Gate cleared. {mid} is terminal in its sequence — no automatic "
                "next module. Choose the next pillar or transition (POC → mandate, "
                "EXT → handoff, etc.) based on the pilot's mode."
            )
    elif gate_status == "fail":
        guidance = (
            f"{len(blocking_failures)} blocking failure(s). "
            "Address them before advancing — see blocking_failures indices."
        )
    elif gate_status == "partial":
        guidance = (
            f"{items_passed}/{items_total} items passed. "
            "Provide evidence for the remaining items — see missing_evidence indices."
        )
    else:
        guidance = (
            f"Gate has {items_total} items. Provide evidence as a JSON list of "
            "bools/strings or a dict {\"1\": true, ...} to evaluate."
        )

    # Module title from raw_markdown's H1
    md = module.get("raw_markdown", "")
    title_match = re.match(r"# Module [A-Z]+-\d+ — (.+)", md)
    module_title = title_match.group(1).strip() if title_match else module.get("title", "")

    return {
        "module_id": mid,
        "module_title": module_title,
        "module_pillar_explainer": _PILLAR_GLOSSARY.get(pillar_for_module(mid) or "", ""),
        "gate_concept": _GATE_CONCEPT,
        "gate_status": gate_status,
        "gate_items": gate_items_out,
        "items_passed": items_passed,
        "items_total": items_total,
        "blocking_failures": blocking_failures,
        "missing_evidence": missing_evidence,
        "next_module": next_module,
        "advancement_blocked": advancement_blocked,
        "guidance": guidance,
    }


def _render_template(data: dict, warnings: list[str] | None = None) -> str:
    """Substitute placeholders in the template with values from data."""
    if warnings is None:
        warnings = []

    pilot = data.get("pilot") or {}
    sponsor = data.get("sponsor") or {}

    substitutions: dict[str, str] = {
        "{{CLIENT}}": data.get("client_name") or "{{CLIENT}}",
        "{{PILOTE_PRENOM}}": pilot.get("first_name") or "{{PILOTE_PRENOM}}",
        "{{PILOTE_NOM}}": pilot.get("last_name") or "{{PILOTE_NOM}}",
        "{{ROLE_PILOTE}}": pilot.get("role") or "{{ROLE_PILOTE}}",
        "{{SPONSOR_PRENOM}}": sponsor.get("first_name") or "{{SPONSOR_PRENOM}}",
        "{{SPONSOR_NOM}}": sponsor.get("last_name") or "{{SPONSOR_NOM}}",
        "{{ROLE_SPONSOR}}": sponsor.get("role") or "{{ROLE_SPONSOR}}",
        "{{FONCTION}}": data.get("function") or "{{FONCTION}}",
        "{{NOM_OFFRE}}": data.get("mandate_name") or "{{NOM_OFFRE}}",
        "{{KICKOFF_DATE}}": data.get("kickoff_date") or "{{KICKOFF_DATE}}",
        "{{FIN_PHASE_1}}": data.get("phase_1_end_date") or "{{FIN_PHASE_1}}",
        "{{SECTEUR}}": data.get("sector") or "{{SECTEUR}}",
        "{{TAILLE_EQUIPE}}": data.get("team_size") or "{{TAILLE_EQUIPE}}",
        "{{REVENUS_ANNUELS}}": data.get("annual_revenue") or "{{REVENUS_ANNUELS}}",
        "{{LISTE_PRODUITS}}": data.get("products_list") or "{{LISTE_PRODUITS}}",
        "{{DESCRIPTION_ICP}}": data.get("icp_description") or "{{DESCRIPTION_ICP}}",
        "{{CONTRAINTES}}": data.get("constraints") or "{{CONTRAINTES}}",
        "{{TRANSITIONS}}": data.get("transitions") or "{{TRANSITIONS}}",
        "{{LANGUE}}": data.get("language") or "{{LANGUE}}",
        "{{TON}}": data.get("tone") or "{{TON}}",
        "{{CADENCE_SPRINT_REVIEW}}": data.get("sponsor_cadence") or "{{CADENCE_SPRINT_REVIEW}}",
        "{{EQUIPE_BLOCK}}": _render_team_block(data),
        "{{KPIS_BLOCK}}": _render_kpis_block(data.get("kpis") or [], warnings),
        "{{LINKED_MDS_BLOCK}}": _render_linked_mds(data.get("linked_project_mds") or []),
    }

    rendered = _CLAUDE_MD_TEMPLATE
    for placeholder, value in substitutions.items():
        rendered = rendered.replace(placeholder, str(value))
    return rendered
