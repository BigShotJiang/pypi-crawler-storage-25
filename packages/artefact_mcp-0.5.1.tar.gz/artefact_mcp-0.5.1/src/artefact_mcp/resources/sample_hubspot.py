"""Loader for sample HubSpot fixtures used by the v0.5.0 Free tier audit tools.

Returns deterministic mid-maturity sample data so audit tools work without
a HubSpot API key. Fixtures live in _data/sample_hubspot/ and are loaded
once per process via lru_cache.
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

_DATA_DIR = Path(__file__).resolve().parent / "_data" / "sample_hubspot"


@lru_cache(maxsize=1)
def sample_contacts() -> list[dict]:
    """Return the 30-contact sample dataset (HubSpot CRM v3 shape)."""
    return json.loads((_DATA_DIR / "contacts.json").read_text(encoding="utf-8"))["contacts"]


@lru_cache(maxsize=1)
def sample_deals() -> list[dict]:
    """Return the 8-deal sample dataset (HubSpot CRM v3 shape)."""
    return json.loads((_DATA_DIR / "deals.json").read_text(encoding="utf-8"))["deals"]


@lru_cache(maxsize=1)
def sample_properties() -> list[dict]:
    """Return the 29-property sample dataset (custom + system, mixed naming)."""
    return json.loads((_DATA_DIR / "properties.json").read_text(encoding="utf-8"))["properties"]


@lru_cache(maxsize=1)
def sample_workflows() -> list[dict]:
    """Return the 5-workflow sample dataset (3 active + 2 disabled)."""
    return json.loads((_DATA_DIR / "workflows.json").read_text(encoding="utf-8"))["workflows"]
