"""
audit_lifecycle_stages tool

Audits HubSpot lifecycle stage discipline. Surfaces orphan contacts (stage
skips), per-stage age distribution, and recommends specific HubSpot config
fixes. Free tier — works on sample data or live HubSpot.
"""

from datetime import datetime, timezone
from statistics import median
from typing import Optional

from artefact_mcp.core.hubspot_client import HubSpotClient
from artefact_mcp.resources.sample_hubspot import sample_contacts


LIFECYCLE_ORDER = [
    "subscriber",
    "lead",
    "marketingqualifiedlead",
    "salesqualifiedlead",
    "opportunity",
    "customer",
    "evangelist",
]

LIFECYCLE_LABELS = {
    "subscriber": "Subscriber",
    "lead": "Lead",
    "marketingqualifiedlead": "MQL",
    "salesqualifiedlead": "SQL",
    "opportunity": "Opportunity",
    "customer": "Customer",
    "evangelist": "Evangelist",
}

LIFECYCLE_CONCEPT_EXPLAINER = (
    "Lifecycle stage vs. lead status: HubSpot ships two overlapping fields and operators "
    "routinely conflate them.\n\n"
    "Lifecycle stage is the *funnel position* (Subscriber → Lead → MQL → SQL → Opportunity → "
    "Customer). It is monotonic: contacts should advance one step at a time, never skip. "
    "Lead status is a *qualification verdict* inside Lead/MQL/SQL (New, Connected, Open Deal, "
    "Unqualified). It can move in any direction.\n\n"
    "Why this audit matters: when contacts skip stages (e.g. Lead → SQL with no MQL date), "
    "marketing attribution breaks, MQL conversion math becomes meaningless, and AI tools that "
    "key off lifecyclestage produce nonsense. The fix is upstream — in HubSpot workflow design "
    "— not in reporting filters."
)


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _detect_orphans(contacts: list[dict]) -> list[dict]:
    """Find contacts whose current stage skipped one or more prior stages.

    Subscriber is treated as optional (many ICPs never enter as Subscriber).
    Stage skip = current stage is at index i (>0) but `hs_lifecyclestage_<prior>_date`
    is missing for any prior stage between Lead and current.
    """
    orphans: list[dict] = []
    for c in contacts:
        props = c.get("properties", {})
        stage = props.get("lifecyclestage")
        if stage not in LIFECYCLE_ORDER:
            continue
        idx = LIFECYCLE_ORDER.index(stage)
        if idx <= 1:  # Subscriber or Lead — nothing required upstream
            continue
        # Walk Lead..(stage-1), skip Subscriber which is optional
        for prior in LIFECYCLE_ORDER[1:idx]:
            date_key = f"hs_lifecyclestage_{prior}_date"
            if not props.get(date_key):
                orphans.append({
                    "contact_id": c.get("id"),
                    "email": props.get("email"),
                    "current_stage": LIFECYCLE_LABELS[stage],
                    "missing_prior_stage": LIFECYCLE_LABELS[prior],
                })
                break
    return orphans


def _stage_age_distribution(
    contacts: list[dict], now: datetime
) -> dict[str, dict[str, int]]:
    """Median/min/max days in current lifecycle stage, grouped by stage label."""
    ages: dict[str, list[int]] = {}
    for c in contacts:
        props = c.get("properties", {})
        stage = props.get("lifecyclestage")
        if stage not in LIFECYCLE_ORDER:
            continue
        date_str = props.get(f"hs_lifecyclestage_{stage}_date")
        d = _parse_iso(date_str)
        if not d:
            continue
        days = max((now - d).days, 0)
        ages.setdefault(LIFECYCLE_LABELS[stage], []).append(days)

    return {
        label: {
            "median_days": int(median(days_list)),
            "min_days": min(days_list),
            "max_days": max(days_list),
            "count": len(days_list),
        }
        for label, days_list in ages.items()
    }


def _generate_recommendations(
    stage_counts: dict[str, int],
    orphans: list[dict],
    age_dist: dict[str, dict[str, int]],
    total: int,
) -> list[dict]:
    """Convert findings into 3-5 actionable HubSpot config recommendations."""
    recs: list[dict] = []

    if orphans:
        skip_pct = round(len(orphans) / total * 100, 1)
        recs.append({
            "priority": "high",
            "finding": f"{len(orphans)} contacts ({skip_pct}%) skipped a prior lifecycle stage.",
            "action": (
                "Add a HubSpot workflow that requires `hs_lifecyclestage_<prior>_date` to be set "
                "before allowing lifecyclestage to advance. Prevents orphans from being created "
                "by manual edits or imports."
            ),
        })

    # Stale stage detection — any stage where median > 90 days
    for label, dist in age_dist.items():
        if dist["median_days"] > 90 and dist["count"] >= 3:
            recs.append({
                "priority": "medium",
                "finding": (
                    f"Median age in {label} is {dist['median_days']} days "
                    f"(n={dist['count']}, max={dist['max_days']})."
                ),
                "action": (
                    f"Define an exit gate for {label} — if contacts sit there >60 days they "
                    "should either advance or be re-classified. Add a workflow that demotes "
                    "stale MQL/SQL back to Lead with a re-engagement task."
                ),
            })

    # MQL → SQL conversion sanity check
    mql = stage_counts.get("MQL", 0)
    sql = stage_counts.get("SQL", 0)
    if mql > 0 and sql > mql * 2:
        recs.append({
            "priority": "high",
            "finding": (
                f"SQL count ({sql}) is more than 2× MQL count ({mql}) — operators are "
                "likely promoting Lead directly to SQL and bypassing the MQL gate."
            ),
            "action": (
                "Audit which workflows or manual actions write `lifecyclestage = "
                "salesqualifiedlead` without first writing `marketingqualifiedlead`. "
                "Consider locking the field via a HubSpot custom permission."
            ),
        })

    # Customer count low — funnel visibility
    customer = stage_counts.get("Customer", 0)
    if total >= 20 and customer == 0:
        recs.append({
            "priority": "medium",
            "finding": "No contacts have been advanced to Customer stage.",
            "action": (
                "If you're closing deals, the Customer transition is likely manual-only. "
                "Add a workflow: when a deal moves to Closed Won, set the associated "
                "primary contact's `lifecyclestage = customer`."
            ),
        })

    # Always include a baseline governance recommendation
    recs.append({
        "priority": "low",
        "finding": "Lifecycle governance baseline.",
        "action": (
            "Document the official stage-transition rules in a Notion page (or your team "
            "wiki) and link it from the Settings > Lifecycle Stages help text. New ops hires "
            "fix this in week one rather than month six."
        ),
    })

    return recs[:5]


def audit_lifecycle_stages(
    source: str = "hubspot",
    pipeline_id: Optional[str] = None,
    hubspot_client: Optional[HubSpotClient] = None,
) -> dict:
    """Audit HubSpot lifecycle stage discipline.

    Args:
        source: "hubspot" for live data, "sample" for built-in fixture.
        pipeline_id: Reserved for future scoping (lifecycle is contact-level,
            pipeline filtering would require deal traversal). Currently ignored
            and surfaced in the response so the caller knows.
        hubspot_client: Pre-configured HubSpotClient (required when source="hubspot").

    Returns:
        Audit dict with stage counts, orphan detection, age distribution,
        recommendations, and embedded concept explainer.
    """
    fetch_meta: dict = {}
    if source == "sample":
        contacts = sample_contacts()
    elif source == "hubspot":
        if not hubspot_client:
            raise ValueError(
                "HubSpot client required for source='hubspot'. "
                "Set HUBSPOT_API_KEY environment variable."
            )
        contacts = hubspot_client.fetch_contacts_with_lifecycle()
        fetch_meta = getattr(hubspot_client, "last_fetch_meta", {}) or {}
    else:
        raise ValueError(f"Invalid source: {source}. Use 'hubspot' or 'sample'.")

    now = datetime.now(timezone.utc)

    if not contacts:
        return {
            "source": source,
            "total_contacts": 0,
            "data_truncated": False,
            "stage_counts": {},
            "orphan_count": 0,
            "orphan_rate_pct": 0.0,
            "orphans_sample": [],
            "stage_age_distribution": {},
            "recommendations": [],
            "lifecycle_concept": LIFECYCLE_CONCEPT_EXPLAINER,
            "notes": ["No contacts returned. If using source='hubspot', verify HUBSPOT_API_KEY scopes include crm.objects.contacts.read."],
        }

    # Stage counts (include "Other" bucket for unknown values)
    stage_counts: dict[str, int] = {label: 0 for label in LIFECYCLE_LABELS.values()}
    stage_counts["Other"] = 0
    for c in contacts:
        stage = c.get("properties", {}).get("lifecyclestage")
        label = LIFECYCLE_LABELS.get(stage, "Other")
        stage_counts[label] += 1

    orphans = _detect_orphans(contacts)
    age_dist = _stage_age_distribution(contacts, now)
    recommendations = _generate_recommendations(
        stage_counts, orphans, age_dist, len(contacts)
    )

    notes: list[str] = []
    if pipeline_id:
        notes.append(
            f"pipeline_id='{pipeline_id}' was provided but is not yet honored "
            "(lifecycle is contact-level; pipeline scoping requires deal traversal)."
        )
    if fetch_meta.get("truncated"):
        notes.append(
            f"WARNING: HubSpot returned more contacts than the {fetch_meta['max_pages']}-page "
            f"({fetch_meta['max_pages'] * 100} record) cap allows. Audit covers the first "
            f"{fetch_meta['records_returned']} contacts only — results are partial. Run on a "
            "filtered view (e.g. recent contacts or single segment) for accurate counts."
        )

    return {
        "source": source,
        "total_contacts": len(contacts),
        "data_truncated": fetch_meta.get("truncated", False),
        "stage_counts": stage_counts,
        "orphan_count": len(orphans),
        "orphan_rate_pct": round(len(orphans) / len(contacts) * 100, 1),
        "orphans_sample": orphans[:10],
        "stage_age_distribution": age_dist,
        "recommendations": recommendations,
        "lifecycle_concept": LIFECYCLE_CONCEPT_EXPLAINER,
        "notes": notes,
    }
