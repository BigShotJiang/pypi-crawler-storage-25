"""
audit_pipeline_hygiene tool

Audits HubSpot deal pipeline for stale deals, missing required fields,
stage abuse, and age outliers. Free tier — works on sample data or live HubSpot.
"""

from datetime import datetime, timezone
from statistics import median
from typing import Optional

from artefact_mcp.core.hubspot_client import HubSpotClient
from artefact_mcp.resources.sample_hubspot import sample_deals


REQUIRED_FIELDS = ("dealname", "amount", "closedate", "hubspot_owner_id")

PIPELINE_HYGIENE_EXPLAINER = (
    "Pipeline hygiene is the discipline of keeping the deal record true to reality. "
    "It is the most under-rated lever in B2B revenue ops because it compounds: every dirty "
    "deal corrupts forecast math, every missing close date breaks velocity reporting, every "
    "stale deal in stage 4 makes win-rate look better than it is.\n\n"
    "Four operational signals to watch:\n"
    "1. *Stale deals* — open >30 days with no last-modified update. Either advance them or "
    "close-lost them. Sitting deals don't close themselves.\n"
    "2. *Missing required fields* — deals without amount, close date, or owner can't be "
    "forecasted. They show up as zeros in pipeline reports and silently distort blended math.\n"
    "3. *Stage abuse* — when >50% of deals in a stage have been there >60 days, that stage "
    "has stopped being a stage. It's a parking lot.\n"
    "4. *Age outliers* — deals 3× the median age in their stage are usually one of: dead, "
    "stuck on a buyer-side blocker, or owned by someone who left.\n\n"
    "Why this matters before AI: every AI feature that consumes deal data — forecasting, "
    "next-best-action, copilot — will inherit the dirt. Clean once, benefit forever."
)


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _safe_float(value: Optional[str]) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def _detect_stale(
    deals: list[dict], now: datetime, threshold_days: int
) -> list[dict]:
    """Return deals whose hs_lastmodifieddate is older than threshold_days."""
    stale: list[dict] = []
    for d in deals:
        props = d.get("properties", {})
        last_mod = _parse_iso(props.get("hs_lastmodifieddate"))
        if not last_mod:
            continue
        days = (now - last_mod).days
        if days >= threshold_days:
            stale.append({
                "deal_id": d.get("id"),
                "dealname": props.get("dealname"),
                "stage": props.get("dealstage"),
                "days_since_modified": days,
            })
    stale.sort(key=lambda x: x["days_since_modified"], reverse=True)
    return stale


def _detect_missing_fields(deals: list[dict]) -> list[dict]:
    """Return deals missing one or more required fields."""
    missing: list[dict] = []
    for d in deals:
        props = d.get("properties", {})
        gaps = []
        for field in REQUIRED_FIELDS:
            value = props.get(field)
            if value is None or value == "":
                gaps.append(field)
        if gaps:
            missing.append({
                "deal_id": d.get("id"),
                "dealname": props.get("dealname"),
                "stage": props.get("dealstage"),
                "missing": gaps,
            })
    return missing


def _stage_age_distribution(
    deals: list[dict], now: datetime
) -> dict[str, dict[str, int]]:
    """Per-stage distribution of days since deal createdate."""
    ages: dict[str, list[int]] = {}
    for d in deals:
        props = d.get("properties", {})
        stage = props.get("dealstage")
        created = _parse_iso(props.get("createdate"))
        if not stage or not created:
            continue
        days = max((now - created).days, 0)
        ages.setdefault(stage, []).append(days)

    return {
        stage: {
            "count": len(days_list),
            "median_days": int(median(days_list)),
            "min_days": min(days_list),
            "max_days": max(days_list),
        }
        for stage, days_list in ages.items()
    }


def _detect_stage_abuse(
    deals: list[dict], now: datetime, abuse_threshold_days: int = 60
) -> list[dict]:
    """A stage is abused when >=50% of its deals have createdate older than abuse_threshold_days."""
    stage_deals: dict[str, list[int]] = {}
    for d in deals:
        props = d.get("properties", {})
        stage = props.get("dealstage")
        created = _parse_iso(props.get("createdate"))
        if not stage or not created:
            continue
        stage_deals.setdefault(stage, []).append((now - created).days)

    abuses: list[dict] = []
    for stage, ages in stage_deals.items():
        if len(ages) < 2:
            continue  # Single-deal stage isn't statistically interesting
        old_count = sum(1 for a in ages if a > abuse_threshold_days)
        ratio = old_count / len(ages)
        if ratio >= 0.5:
            abuses.append({
                "stage": stage,
                "deals_in_stage": len(ages),
                "old_deal_count": old_count,
                "old_deal_ratio_pct": round(ratio * 100, 1),
                "threshold_days": abuse_threshold_days,
            })
    return abuses


def _detect_age_outliers(
    deals: list[dict], now: datetime, age_dist: dict[str, dict[str, int]]
) -> list[dict]:
    """Deals whose stage-age is >3× the stage median."""
    outliers: list[dict] = []
    for d in deals:
        props = d.get("properties", {})
        stage = props.get("dealstage")
        created = _parse_iso(props.get("createdate"))
        if not stage or not created or stage not in age_dist:
            continue
        median_for_stage = age_dist[stage]["median_days"]
        if median_for_stage <= 0:
            continue
        days = (now - created).days
        if days > median_for_stage * 3:
            outliers.append({
                "deal_id": d.get("id"),
                "dealname": props.get("dealname"),
                "stage": stage,
                "days_in_pipeline": days,
                "stage_median_days": median_for_stage,
                "x_median": round(days / median_for_stage, 1),
            })
    outliers.sort(key=lambda x: x["x_median"], reverse=True)
    return outliers


def _generate_recommendations(
    stale: list[dict],
    missing: list[dict],
    abuses: list[dict],
    outliers: list[dict],
    total_deals: int,
) -> list[dict]:
    """Convert findings into impact-ranked HubSpot config recommendations."""
    recs: list[dict] = []

    if total_deals == 0:
        return [{
            "priority": "low",
            "finding": "No open deals to audit.",
            "action": "Run again once you have an active pipeline. Or use this tool on the existing closed-won pipeline to verify hygiene retroactively.",
        }]

    if missing:
        miss_pct = round(len(missing) / total_deals * 100, 1)
        recs.append({
            "priority": "high",
            "finding": (
                f"{len(missing)} deals ({miss_pct}%) are missing one or more required fields "
                f"({', '.join(REQUIRED_FIELDS)})."
            ),
            "action": (
                "In HubSpot: Settings > Objects > Deals > make `dealname`, `amount`, "
                "`closedate`, and `hubspot_owner_id` required. Then run a one-time backfill "
                "workflow that flags existing deals with gaps."
            ),
        })

    if stale:
        stale_pct = round(len(stale) / total_deals * 100, 1)
        oldest = stale[0]
        recs.append({
            "priority": "high" if stale_pct > 30 else "medium",
            "finding": (
                f"{len(stale)} deals ({stale_pct}%) haven't been touched in 30+ days. "
                f"Oldest: '{oldest['dealname']}' at {oldest['days_since_modified']} days."
            ),
            "action": (
                "Add a HubSpot workflow: when `hs_lastmodifieddate` exceeds 30 days on an "
                "open deal, create a task for the deal owner. After 60 days idle, "
                "auto-move to Closed Lost with a reason of 'No engagement'."
            ),
        })

    for abuse in abuses:
        recs.append({
            "priority": "high",
            "finding": (
                f"Stage '{abuse['stage']}' is acting like a parking lot — "
                f"{abuse['old_deal_ratio_pct']}% of {abuse['deals_in_stage']} deals there "
                f"have been open >{abuse['threshold_days']} days."
            ),
            "action": (
                f"Either split this stage into clearer sub-stages, define a hard exit "
                f"criterion ('must have a signed proposal'), or add an SLA workflow that "
                f"escalates after {abuse['threshold_days']} days."
            ),
        })

    if outliers:
        worst = outliers[0]
        recs.append({
            "priority": "medium",
            "finding": (
                f"{len(outliers)} deals are {worst['x_median']}×+ the median age in their "
                f"stage. Worst offender: '{worst['dealname']}' "
                f"({worst['days_in_pipeline']} days vs {worst['stage_median_days']}-day median)."
            ),
            "action": (
                "Surface these in a dedicated 'At Risk' deal view and review weekly. "
                "Ask the rep: still real? if yes, what's the unblock? if no, close it."
            ),
        })

    # Always include a baseline rec so the audit is never empty
    if not recs:
        recs.append({
            "priority": "low",
            "finding": "Pipeline is clean on the four basic hygiene signals.",
            "action": (
                "Re-run this audit monthly — the data drifts faster than people think. "
                "Consider promoting the Pro tier `score_pipeline_health` tool for velocity, "
                "conversion, and forecast accuracy on the same data."
            ),
        })

    return recs[:5]


def audit_pipeline_hygiene(
    source: str = "hubspot",
    pipeline_id: Optional[str] = None,
    staleness_days: int = 30,
    hubspot_client: Optional[HubSpotClient] = None,
) -> dict:
    """Audit HubSpot deal pipeline for stale deals, missing fields, stage abuse, age outliers.

    Args:
        source: "hubspot" for live data, "sample" for built-in fixture.
        pipeline_id: Optional pipeline ID filter (live path only).
        staleness_days: Days without modification before a deal counts as stale (default 30).
        hubspot_client: Pre-configured HubSpotClient (required when source="hubspot").

    Returns:
        Audit dict with stale/missing/abuse/outlier findings, recommendations,
        and embedded pipeline hygiene explainer.
    """
    fetch_meta: dict = {}
    if source == "sample":
        deals = sample_deals()
    elif source == "hubspot":
        if not hubspot_client:
            raise ValueError(
                "HubSpot client required for source='hubspot'. "
                "Set HUBSPOT_API_KEY environment variable."
            )
        deals = hubspot_client.fetch_deals_with_hygiene(pipeline_id=pipeline_id)
        fetch_meta = getattr(hubspot_client, "last_fetch_meta", {}) or {}
    else:
        raise ValueError(f"Invalid source: {source}. Use 'hubspot' or 'sample'.")

    # Optional pipeline filter on the sample path so output is consistent.
    if source == "sample" and pipeline_id:
        deals = [
            d for d in deals
            if d.get("properties", {}).get("pipeline") == pipeline_id
        ]

    now = datetime.now(timezone.utc)
    total = len(deals)

    notes: list[str] = []
    if fetch_meta.get("truncated"):
        notes.append(
            f"WARNING: HubSpot returned more deals than the {fetch_meta['max_pages']}-page "
            f"({fetch_meta['max_pages'] * 100} record) cap allows. Audit covers the first "
            f"{fetch_meta['records_returned']} deals only — results are partial. Filter by "
            "pipeline_id or by date range for accurate counts."
        )

    if total == 0:
        return {
            "source": source,
            "pipeline_id": pipeline_id,
            "total_deals": 0,
            "data_truncated": fetch_meta.get("truncated", False),
            "stale_deals_count": 0,
            "stale_deals_top10": [],
            "missing_fields_count": 0,
            "missing_fields_sample": [],
            "stage_age_distribution": {},
            "stage_abuses": [],
            "age_outliers": [],
            "recommendations": _generate_recommendations([], [], [], [], 0),
            "pipeline_hygiene_concept": PIPELINE_HYGIENE_EXPLAINER,
            "notes": notes,
        }

    stale = _detect_stale(deals, now, staleness_days)
    missing = _detect_missing_fields(deals)
    age_dist = _stage_age_distribution(deals, now)
    abuses = _detect_stage_abuse(deals, now)
    outliers = _detect_age_outliers(deals, now, age_dist)
    recommendations = _generate_recommendations(stale, missing, abuses, outliers, total)

    return {
        "source": source,
        "pipeline_id": pipeline_id,
        "staleness_threshold_days": staleness_days,
        "total_deals": total,
        "data_truncated": fetch_meta.get("truncated", False),
        "stale_deals_count": len(stale),
        "stale_deals_top10": stale[:10],
        "missing_fields_count": len(missing),
        "missing_fields_sample": missing[:10],
        "stage_age_distribution": age_dist,
        "stage_abuses": abuses,
        "age_outliers": outliers[:10],
        "recommendations": recommendations,
        "pipeline_hygiene_concept": PIPELINE_HYGIENE_EXPLAINER,
        "notes": notes,
    }
