"""
audit_property_governance tool

Audits HubSpot custom property hygiene: count vs defaults, naming consistency,
low-fill-rate fields, deprecated properties still in active workflows, top-N
by usage. Free tier — works on sample data or live HubSpot.
"""

from collections import Counter
from typing import Optional

from artefact_mcp.core.hubspot_client import HubSpotClient
from artefact_mcp.resources.sample_hubspot import sample_properties, sample_workflows


PROPERTY_GOVERNANCE_EXPLAINER = (
    "Property governance is the difference between a CRM that compounds in value and one that "
    "becomes a graveyard of half-built fields nobody trusts. Three failure patterns recur:\n\n"
    "1. *Property explosion* — every operator adds a custom property to fix the issue of the "
    "week. After 18 months you have 200 custom fields, 80% empty, 20% half-populated. The fields "
    "you actually rely on are now buried.\n"
    "2. *Naming chaos* — `tech_stack`, `techStackV1`, `TechStackVersion`, `tech_stack_new`. "
    "Each was the right answer at the time. Together they mean an AI tool retrieves whichever "
    "one was indexed last, which may not be the one with current data.\n"
    "3. *Deprecated landmines* — properties marked old or v1 that are still referenced by a "
    "disabled workflow or a forgotten Zap. They're invisible until the day they fire wrong.\n\n"
    "The fix is boring and effective: quarterly audits, hard naming convention, retire-or-revive "
    "rule for any field below 5% fill rate, and an explicit `*_deprecated_<date>` rename before "
    "deletion so the migration leaves a forensic trail."
)


# --- Naming detection helpers -------------------------------------------------

def _classify_naming(name: str) -> str:
    """Return naming convention bucket for a property name."""
    if not name:
        return "unknown"
    if name[0].isupper():
        return "PascalCase"
    if "_" in name and name.islower():
        return "snake_case"
    if any(c.isupper() for c in name[1:]):
        return "camelCase"
    if name.islower():
        return "lowercase"
    return "other"


def _detect_deprecated_patterns(name: str) -> bool:
    """Heuristic: name suggests deprecation even when the API doesn't flag it."""
    suffixes = ("_old", "_v1", "_v2", "_legacy", "_deprecated", "_archived", "_temp")
    return any(name.lower().endswith(s) for s in suffixes)


# --- Tool ---------------------------------------------------------------------

def audit_property_governance(
    source: str = "hubspot",
    hubspot_client: Optional[HubSpotClient] = None,
) -> dict:
    """Audit HubSpot custom property hygiene.

    Args:
        source: "hubspot" for live data, "sample" for built-in fixture.
        hubspot_client: Pre-configured HubSpotClient (required when source="hubspot").

    Returns:
        Audit dict with counts, naming distribution, low-fill list, deprecated
        list, top-10 by usage, consolidation plan, and embedded explainer.
    """
    if source == "sample":
        properties = sample_properties()
        workflows = sample_workflows()
    elif source == "hubspot":
        if not hubspot_client:
            raise ValueError(
                "HubSpot client required for source='hubspot'. "
                "Set HUBSPOT_API_KEY environment variable."
            )
        properties = hubspot_client.fetch_properties_overview()
        try:
            workflows = hubspot_client.fetch_workflows_overview()
        except Exception:
            workflows = []
    else:
        raise ValueError(f"Invalid source: {source}. Use 'hubspot' or 'sample'.")

    if not properties:
        return {
            "source": source,
            "total_properties": 0,
            "system_count": 0,
            "custom_count": 0,
            "custom_to_system_ratio": 0.0,
            "naming_distribution": {},
            "naming_chaos": False,
            "low_fill_rate_properties": [],
            "deprecated_properties_in_use": [],
            "top_10_by_usage": [],
            "consolidation_plan": [],
            "property_governance_concept": PROPERTY_GOVERNANCE_EXPLAINER,
        }

    system = [p for p in properties if not p.get("is_custom")]
    custom = [p for p in properties if p.get("is_custom")]

    # Naming convention distribution (custom only — system fields follow HubSpot's own conventions)
    naming_counter: Counter = Counter()
    for p in custom:
        naming_counter[_classify_naming(p.get("name", ""))] += 1
    naming_distribution = dict(naming_counter)
    distinct_conventions = sum(
        1 for k in ("snake_case", "camelCase", "PascalCase") if naming_distribution.get(k, 0) > 0
    )
    chaos = distinct_conventions >= 2

    # Low fill rate (<= 5%)
    low_fill = [
        {
            "name": p["name"],
            "label": p.get("label"),
            "object_type": p.get("object_type"),
            "fill_rate": p.get("fill_rate"),
        }
        for p in custom
        if p.get("fill_rate") is not None and p["fill_rate"] <= 0.05
    ]
    low_fill.sort(key=lambda x: (x["fill_rate"] or 0))

    # Active workflow IDs for "in use" determination
    active_wf_ids = {w["id"] for w in workflows if w.get("is_enabled")}

    # Deprecated properties still referenced in *any* workflow
    # (Both API-flagged is_deprecated AND name-pattern-flagged.)
    deprecated_in_use: list[dict] = []
    for p in custom:
        api_flagged = p.get("is_deprecated", False)
        name_flagged = _detect_deprecated_patterns(p.get("name", ""))
        if not (api_flagged or name_flagged):
            continue
        refs = p.get("referenced_in_workflows") or []
        if refs:
            still_active = [w for w in refs if w in active_wf_ids]
            deprecated_in_use.append({
                "name": p["name"],
                "label": p.get("label"),
                "object_type": p.get("object_type"),
                "fill_rate": p.get("fill_rate"),
                "api_flagged_deprecated": api_flagged,
                "name_pattern_suggests_deprecated": name_flagged,
                "referenced_workflows": refs,
                "still_referenced_by_active_workflow": bool(still_active),
            })

    # Top 10 by usage_count (proxy: how often the property appears on records)
    by_usage = sorted(properties, key=lambda p: p.get("usage_count", 0) or 0, reverse=True)
    top_10 = [
        {
            "name": p["name"],
            "label": p.get("label"),
            "object_type": p.get("object_type"),
            "is_custom": p.get("is_custom"),
            "usage_count": p.get("usage_count", 0),
            "fill_rate": p.get("fill_rate"),
        }
        for p in by_usage[:10]
    ]

    # Consolidation plan
    consolidation: list[dict] = []
    if deprecated_in_use:
        consolidation.append({
            "priority": "high",
            "action": (
                f"Migrate or retire {len(deprecated_in_use)} deprecated properties still "
                "referenced by workflows."
            ),
            "detail": (
                "For each: identify the replacement property, point all workflows at it, "
                "rename the old property to `<name>_deprecated_<YYYYMM>` for one cycle, then "
                "delete. Avoids silent failures when a forgotten workflow references a "
                "deleted property."
            ),
        })
    if low_fill:
        consolidation.append({
            "priority": "medium",
            "action": f"Decide retire-or-revive on {len(low_fill)} custom properties with <=5% fill rate.",
            "detail": (
                "For each low-fill custom property: ask the field owner why it's empty. If the "
                "answer is 'we never built the workflow that fills it' → revive (build the "
                "workflow this sprint). If the answer is 'we tried, didn't work' → retire."
            ),
        })
    if chaos:
        conventions_present = [
            k for k in ("snake_case", "camelCase", "PascalCase")
            if naming_distribution.get(k, 0) > 0
        ]
        consolidation.append({
            "priority": "medium",
            "action": (
                f"Pick one naming convention and rename outliers. Currently using "
                f"{', '.join(conventions_present)}."
            ),
            "detail": (
                "Adopt snake_case (HubSpot's default convention for new system properties). "
                "Rename camelCase + PascalCase customs over a 4-week migration window — long "
                "enough to update workflows and integrations referencing the old names."
            ),
        })

    if len(custom) > 30 and not consolidation:
        consolidation.append({
            "priority": "medium",
            "action": f"Custom property count ({len(custom)}) is approaching governance debt territory.",
            "detail": (
                "Run a quarterly review where every custom property's owner re-justifies it. "
                "Properties without a current owner go on a 90-day retire warning."
            ),
        })

    if not consolidation:
        consolidation.append({
            "priority": "low",
            "action": "Property governance baseline is healthy.",
            "detail": (
                "Re-run this audit quarterly. Custom property explosion is gradual and the "
                "first time it's a problem is usually 6 months past the warning signs."
            ),
        })

    custom_to_system_ratio = round(
        len(custom) / len(system), 2
    ) if system else float(len(custom))

    return {
        "source": source,
        "total_properties": len(properties),
        "system_count": len(system),
        "custom_count": len(custom),
        "custom_to_system_ratio": custom_to_system_ratio,
        "naming_distribution": naming_distribution,
        "naming_chaos": chaos,
        "low_fill_rate_properties": low_fill,
        "deprecated_properties_in_use": deprecated_in_use,
        "top_10_by_usage": top_10,
        "consolidation_plan": consolidation,
        "property_governance_concept": PROPERTY_GOVERNANCE_EXPLAINER,
    }
