"""
score_ai_readiness tool

Scores HubSpot AI readiness across 6 dimensions (0-100 each, weighted to a
single 0-100 overall). Aggregates findings from contacts + deals + properties
+ workflows. Free tier — works on sample data or live HubSpot.
"""

from datetime import datetime, timezone
from typing import Optional

from artefact_mcp.core.hubspot_client import HubSpotClient
from artefact_mcp.resources.sample_hubspot import (
    sample_contacts,
    sample_deals,
    sample_properties,
    sample_workflows,
)
from artefact_mcp.tools.audit_lifecycle import _detect_orphans
from artefact_mcp.tools.audit_pipeline_hygiene import (
    _detect_stale,
    _detect_missing_fields,
    _detect_stage_abuse,
)


# Dimension weights (must sum to 100)
DIMENSION_WEIGHTS = {
    "data_completeness": 20,
    "property_governance": 15,
    "workflow_coverage": 15,
    "lifecycle_discipline": 20,
    "sales_process_consistency": 15,
    "integration_maturity": 15,
}

DIMENSION_LABELS = {
    "data_completeness": "Data Completeness",
    "property_governance": "Property Governance",
    "workflow_coverage": "Workflow Coverage",
    "lifecycle_discipline": "Lifecycle Discipline",
    "sales_process_consistency": "Sales Process Consistency",
    "integration_maturity": "Integration Maturity",
}

AI_READINESS_EXPLAINER = (
    "AI readiness in a HubSpot context is not about installing more AI tools. It is about "
    "whether your CRM data and process discipline can survive being read by an AI agent that "
    "takes everything literally.\n\n"
    "The six dimensions tested here are the upstream constraints. An AI tool layered on a CRM "
    "that scores low on any of them will produce confident nonsense:\n\n"
    "- Data Completeness: empty fields look like absent context, and AI hallucinates to fill the gap.\n"
    "- Property Governance: deprecated and chaotically-named properties cause AI to retrieve the "
    "wrong field and reason against it as if it were authoritative.\n"
    "- Workflow Coverage: low workflow density means the AI has to re-derive process logic from "
    "raw signals — fragile, slow, expensive.\n"
    "- Lifecycle Discipline: stage skips destroy funnel math, so any AI-generated forecast or "
    "next-best-action ranking will be wrong by construction.\n"
    "- Sales Process Consistency: dirty deals corrupt every downstream model that consumes them.\n"
    "- Integration Maturity: custom properties that aren't wired into workflows are dead weight, "
    "and custom properties referenced by disabled workflows are landmines.\n\n"
    "Mid-maturity is 50-70 overall. Below 50: don't deploy AI yet — you'll be debugging both "
    "the AI and the CRM at the same time. Above 75: you're ready for production AI workflows."
)


def _safe_pct(num: float, denom: float) -> float:
    return (num / denom * 100) if denom > 0 else 0.0


def _detect_naming_chaos(custom_props: list[dict]) -> bool:
    """True if custom properties mix multiple naming conventions."""
    has_camel = False
    has_snake = False
    has_pascal = False
    for p in custom_props:
        name = p.get("name", "")
        if not name:
            continue
        # Pascal: starts with uppercase
        if name and name[0].isupper():
            has_pascal = True
            continue
        # Snake: contains underscore, all lowercase
        if "_" in name and name.islower():
            has_snake = True
            continue
        # Camel: no underscore, has internal uppercase
        if any(c.isupper() for c in name[1:]):
            has_camel = True

    conventions = sum([has_camel, has_snake, has_pascal])
    return conventions >= 2


# --- Per-dimension scorers ----------------------------------------------------

def _score_data_completeness(
    contacts: list[dict], deals: list[dict], properties: list[dict]
) -> dict:
    """50% weight on system-required field fill rates, 50% on custom property fill rates."""
    if not contacts and not deals and not properties:
        return {"score": 0, "evidence": ["No data available."]}

    # System required fill rates
    sys_fills: list[float] = []
    if contacts:
        for field in ("email", "firstname", "lifecyclestage"):
            filled = sum(1 for c in contacts if c.get("properties", {}).get(field))
            sys_fills.append(filled / len(contacts))
    if deals:
        for field in ("dealname", "amount", "closedate", "hubspot_owner_id"):
            filled = sum(
                1 for d in deals
                if d.get("properties", {}).get(field) not in (None, "")
            )
            sys_fills.append(filled / len(deals))

    sys_avg = sum(sys_fills) / len(sys_fills) if sys_fills else 0.0

    # Custom property fill rates
    custom_props = [p for p in properties if p.get("is_custom")]
    custom_avg = (
        sum(p.get("fill_rate", 0) for p in custom_props) / len(custom_props)
        if custom_props
        else 0.0
    )

    score = round((sys_avg * 0.5 + custom_avg * 0.5) * 100)
    return {
        "score": score,
        "evidence": [
            f"System required fields fill rate: {round(sys_avg * 100)}%",
            f"Custom property fill rate average: {round(custom_avg * 100)}%",
        ],
    }


def _score_property_governance(properties: list[dict]) -> dict:
    """Penalize deprecated-still-in-use, low-fill custom props, and naming chaos."""
    if not properties:
        return {"score": 0, "evidence": ["No properties available."]}

    custom = [p for p in properties if p.get("is_custom")]
    if not custom:
        return {
            "score": 100,
            "evidence": ["No custom properties — governance burden is zero."],
        }

    deprecated_in_use = [
        p for p in custom
        if p.get("is_deprecated") and p.get("referenced_in_workflows")
    ]
    low_fill = [p for p in custom if p.get("fill_rate", 1.0) <= 0.05]
    chaos = _detect_naming_chaos(custom)

    score = 100
    score -= 10 * len(deprecated_in_use)
    score -= 5 * len(low_fill)
    score -= 10 if chaos else 0
    score = max(0, score)

    return {
        "score": score,
        "evidence": [
            f"Custom properties: {len(custom)}",
            f"Deprecated still referenced in workflows: {len(deprecated_in_use)}",
            f"Low fill rate (<=5%): {len(low_fill)}",
            f"Naming chaos (mixed conventions): {chaos}",
        ],
    }


def _score_workflow_coverage(workflows: list[dict]) -> dict:
    """Enabled / total workflow ratio, scaled to 100."""
    if not workflows:
        return {"score": 0, "evidence": ["No workflows configured."]}

    enabled = sum(1 for w in workflows if w.get("is_enabled"))
    pct = enabled / len(workflows) * 100
    return {
        "score": round(pct),
        "evidence": [
            f"Active workflows: {enabled} / {len(workflows)}",
        ],
    }


def _score_lifecycle_discipline(contacts: list[dict]) -> dict:
    """100 - (orphan_rate_pct * 3). Penalizes contacts that skipped lifecycle stages."""
    if not contacts:
        return {"score": 0, "evidence": ["No contacts available."]}

    orphans = _detect_orphans(contacts)
    rate_pct = len(orphans) / len(contacts) * 100
    score = max(0, round(100 - rate_pct * 3))
    return {
        "score": score,
        "evidence": [
            f"Contacts: {len(contacts)}",
            f"Lifecycle orphans (stage skips): {len(orphans)} ({round(rate_pct, 1)}%)",
        ],
    }


def _score_sales_process_consistency(deals: list[dict]) -> dict:
    """Penalize missing fields, stale deals, stage abuse."""
    if not deals:
        return {"score": 0, "evidence": ["No deals available."]}

    now = datetime.now(timezone.utc)
    missing = _detect_missing_fields(deals)
    stale = _detect_stale(deals, now, threshold_days=30)
    abuses = _detect_stage_abuse(deals, now)

    missing_pct = len(missing) / len(deals) * 100
    stale_pct = len(stale) / len(deals) * 100

    score = 100 - missing_pct - (stale_pct * 0.5) - (len(abuses) * 5)
    score = max(0, round(score))

    return {
        "score": score,
        "evidence": [
            f"Deals: {len(deals)}",
            f"Missing required fields: {len(missing)} ({round(missing_pct, 1)}%)",
            f"Stale deals: {len(stale)} ({round(stale_pct, 1)}%)",
            f"Stage abuses (parking-lot stages): {len(abuses)}",
        ],
    }


def _score_integration_maturity(properties: list[dict]) -> dict:
    """% of custom properties wired into at least one workflow."""
    if not properties:
        return {"score": 0, "evidence": ["No properties available."]}

    custom = [p for p in properties if p.get("is_custom")]
    if not custom:
        return {
            "score": 100,
            "evidence": ["No custom properties — integration scope is the system fields."],
        }

    referenced = [p for p in custom if p.get("referenced_in_workflows")]
    pct = len(referenced) / len(custom) * 100
    return {
        "score": round(pct),
        "evidence": [
            f"Custom properties: {len(custom)}",
            f"Referenced in any workflow: {len(referenced)} ({round(pct, 1)}%)",
        ],
    }


# --- Blocker + action generators ----------------------------------------------

def _identify_blockers(scores: dict[str, int]) -> list[dict]:
    """Top 3 lowest-scoring dimensions, with reason text."""
    BLOCKER_REASONS = {
        "data_completeness": "AI tools confidently hallucinate context to fill empty fields.",
        "property_governance": "Deprecated and chaotically-named properties make AI retrieval unreliable.",
        "workflow_coverage": "Low workflow density forces AI to re-derive process logic from raw signals.",
        "lifecycle_discipline": "Stage skips destroy funnel math — AI forecasts are wrong by construction.",
        "sales_process_consistency": "Dirty deal data corrupts every model that reads from it.",
        "integration_maturity": "Custom properties that aren't wired into automation are dead weight.",
    }
    sorted_dims = sorted(scores.items(), key=lambda kv: kv[1])
    return [
        {
            "dimension": DIMENSION_LABELS[k],
            "score": v,
            "why_it_blocks_ai": BLOCKER_REASONS[k],
        }
        for k, v in sorted_dims[:3]
    ]


def _generate_sprint_0_actions(scores: dict[str, int]) -> list[dict]:
    """5 actions ranked to lift the score by ~20 points within 1 sprint (2 weeks)."""
    library: dict[str, dict] = {
        "data_completeness": {
            "title": "Backfill required field values on existing contacts/deals",
            "detail": "Run a one-time HubSpot list query on contacts where lifecyclestage IS NULL. Assign defaults (most likely 'lead'). Same for deals missing amount or closedate — fill from associated quote line items or last known forecast.",
            "estimated_lift": 6,
        },
        "property_governance": {
            "title": "Retire deprecated custom properties referenced in disabled workflows",
            "detail": "Identify custom properties flagged is_deprecated AND still referenced in disabled workflows. Either delete the workflow (and the property), or migrate the workflow to the replacement property.",
            "estimated_lift": 4,
        },
        "workflow_coverage": {
            "title": "Re-enable or delete disabled workflows",
            "detail": "Disabled workflows are dormant cost: they reference properties (creating governance debt) without delivering value. For each disabled workflow, decide: re-enable, retire, or replace.",
            "estimated_lift": 4,
        },
        "lifecycle_discipline": {
            "title": "Add a workflow gate that prevents lifecycle stage skips",
            "detail": "Create a HubSpot workflow: when lifecyclestage advances by more than one step within 24h, flag the contact for ops review. Stops new orphans from being created while the cleanup proceeds.",
            "estimated_lift": 6,
        },
        "sales_process_consistency": {
            "title": "Make dealname, amount, closedate, hubspot_owner_id required at the field level",
            "detail": "In HubSpot Settings > Objects > Deals, mark these fields required. Then run a backfill task assignment for existing deals with gaps. Stops the bleeding upstream.",
            "estimated_lift": 5,
        },
        "integration_maturity": {
            "title": "Wire 1-2 high-fill custom properties into a new active workflow",
            "detail": "Pick a custom property with >40% fill rate that isn't yet referenced in any workflow. Build a routing or scoring workflow that uses it. Increases the % of custom properties that pull operational weight.",
            "estimated_lift": 5,
        },
    }
    sorted_dims = sorted(scores.items(), key=lambda kv: kv[1])
    actions = []
    for dim, score in sorted_dims:
        actions.append({
            "dimension": DIMENSION_LABELS[dim],
            "current_score": score,
            **library[dim],
        })
    return actions[:5]


# --- Public entry -------------------------------------------------------------

def score_ai_readiness(
    source: str = "hubspot",
    hubspot_client: Optional[HubSpotClient] = None,
) -> dict:
    """Score HubSpot AI readiness 0-100 across 6 weighted dimensions.

    Args:
        source: "hubspot" for live data, "sample" for built-in fixture.
        hubspot_client: Pre-configured HubSpotClient (required when source="hubspot").

    Returns:
        Dict with overall_score, per-dimension scores + evidence, top 3
        blockers, 5 Sprint 0 actions, and embedded explainer.
    """
    truncation_warnings: list[str] = []
    if source == "sample":
        contacts = sample_contacts()
        deals = sample_deals()
        properties = sample_properties()
        workflows = sample_workflows()
    elif source == "hubspot":
        if not hubspot_client:
            raise ValueError(
                "HubSpot client required for source='hubspot'. "
                "Set HUBSPOT_API_KEY environment variable."
            )
        contacts = hubspot_client.fetch_contacts_with_lifecycle()
        contacts_meta = getattr(hubspot_client, "last_fetch_meta", {}) or {}
        if contacts_meta.get("truncated"):
            truncation_warnings.append(
                f"contacts: returned only {contacts_meta['records_returned']} of {contacts_meta['max_pages']}-page cap"
            )
        deals = hubspot_client.fetch_deals_with_hygiene()
        deals_meta = getattr(hubspot_client, "last_fetch_meta", {}) or {}
        if deals_meta.get("truncated"):
            truncation_warnings.append(
                f"deals: returned only {deals_meta['records_returned']} of {deals_meta['max_pages']}-page cap"
            )
        # Properties + workflows live behind less-common scopes; if unavailable,
        # we degrade gracefully rather than failing the whole audit.
        properties = []
        workflows = []
        try:
            properties = hubspot_client.fetch_properties_overview()
        except Exception:
            pass
        try:
            workflows = hubspot_client.fetch_workflows_overview()
        except Exception:
            pass
    else:
        raise ValueError(f"Invalid source: {source}. Use 'hubspot' or 'sample'.")

    dimensions = {
        "data_completeness": _score_data_completeness(contacts, deals, properties),
        "property_governance": _score_property_governance(properties),
        "workflow_coverage": _score_workflow_coverage(workflows),
        "lifecycle_discipline": _score_lifecycle_discipline(contacts),
        "sales_process_consistency": _score_sales_process_consistency(deals),
        "integration_maturity": _score_integration_maturity(properties),
    }

    scores_only = {k: v["score"] for k, v in dimensions.items()}

    # Weighted overall
    overall = sum(
        scores_only[dim] * (DIMENSION_WEIGHTS[dim] / 100)
        for dim in DIMENSION_WEIGHTS
    )
    overall = round(overall)

    if overall >= 75:
        readiness_label = "Production-ready"
    elif overall >= 50:
        readiness_label = "Mid-maturity (cleanup recommended before deploying AI)"
    else:
        readiness_label = "Not ready (significant cleanup required)"

    notes: list[str] = []
    if truncation_warnings:
        notes.append(
            "WARNING: HubSpot result set was truncated for one or more entities. "
            "Score is computed on partial data. Details: " + "; ".join(truncation_warnings)
        )

    return {
        "source": source,
        "overall_score": overall,
        "readiness_label": readiness_label,
        "data_truncated": bool(truncation_warnings),
        "notes": notes,
        "dimensions": {
            DIMENSION_LABELS[k]: {
                "score": v["score"],
                "weight_pct": DIMENSION_WEIGHTS[k],
                "evidence": v["evidence"],
            }
            for k, v in dimensions.items()
        },
        "top_3_blockers": _identify_blockers(scores_only),
        "sprint_0_actions": _generate_sprint_0_actions(scores_only),
        "ai_readiness_concept": AI_READINESS_EXPLAINER,
    }
