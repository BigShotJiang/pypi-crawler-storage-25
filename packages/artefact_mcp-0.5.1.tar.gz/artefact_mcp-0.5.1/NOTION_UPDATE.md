# Artefact MCP Server - Pro/Enterprise Configuration Features

**Release Date:** February 11, 2026
**Version:** 1.1.0
**Status:** ✅ Deployed to Production

## 🎯 Overview

Major enhancement to Artefact MCP server adding flexible configuration for Pro/Enterprise customers. Users can now customize HubSpot property mappings and RFM scoring thresholds to match their specific business models and data structures.

## ✨ New Features

### 1. Custom Property Mapping (Pro/Enterprise)

**What it does:**
- Maps custom HubSpot properties to ICP Triangulation Framework scoring dimensions
- Automatically fetches and scores all three ICP dimensions from HubSpot
- Eliminates manual JSON input for behavioral and strategic fit data

**Configuration:**
```bash
export ARTEFACT_PROPERTY_MAPPING_PATH=/path/to/property_mapping.json
```

**Use Cases:**
- Every HubSpot instance has different custom property names
- Users with enriched HubSpot data (Clay, Clearbit integrations)
- Companies tracking growth signals, tech stack, engagement in custom properties

**Example Config:**
```json
{
  "tech_stack": "technologies_used",
  "growth_signals": ["linkedin_hiring_count", "recent_funding"],
  "content_engagement": "hubspot_engagement_score",
  "decision_maker_access": "primary_contact_role"
}
```

---

### 2. Custom RFM Thresholds (Pro/Enterprise)

**What it does:**
- Customize Recency, Frequency, and Monetary scoring thresholds
- Match thresholds to specific business models and buying cycles
- Support for percentile-based OR fixed dollar thresholds

**Configuration:**
```bash
export ARTEFACT_RFM_THRESHOLDS_PATH=/path/to/rfm_thresholds.json
```

**Use Cases:**
- Longer sales cycles (consulting, manufacturing): extend recency thresholds
- Subscription businesses: adjust frequency expectations
- Enterprise vs SMB segmentation: use fixed dollar thresholds

**Example Config:**
```json
{
  "recency_days": [60, 180, 365, 730],
  "frequency_counts": [5, 3, 2, 1],
  "monetary_method": "percentile",
  "monetary_percentiles": [80, 60, 40, 20]
}
```

---

### 3. Configuration Validation Tool

**New MCP Tool:** `validate_configuration()`

**What it does:**
- Tests configuration files without making HubSpot API calls
- Shows what properties will be fetched
- Exposes any configuration errors
- Returns validation status and details

**Usage:**
```python
validate_configuration()
```

**Returns:**
```json
{
  "property_mapping": {
    "status": "valid",
    "errors": [],
    "details": {
      "tech_stack_property": "technologies_used",
      "growth_signals_count": 3,
      "strategic_properties_configured": true
    }
  },
  "rfm_thresholds": {
    "status": "valid",
    "errors": [],
    "details": {
      "recency_thresholds": [60, 180, 365, 730],
      "monetary_method": "percentile"
    }
  }
}
```

---

## 🔒 Security Enhancements

### Path Traversal Protection
- ✅ Absolute paths only (no relative paths)
- ✅ `.json` files only
- ✅ File size limit: 1MB max
- ✅ Validates files exist and are readable

### Configuration Validation
- ✅ JSON schema validation
- ✅ Type checking on all fields
- ✅ Array size limits (max 50 growth signals)
- ✅ Logical constraint validation (ascending/descending order)

### Error Message Sanitization
- ✅ File paths stripped from error messages
- ✅ Stack traces sanitized
- ✅ Information disclosure prevented

---

## 📊 Technical Details

### New Core Modules
- `property_mappings.py` - Configuration dataclass for property mapping
- `property_mapper.py` - Maps HubSpot data to ICP scorer format
- `rfm_thresholds.py` - Configuration dataclass for RFM thresholds
- `config_validator.py` - Security validation layer

### Modified Modules
- `server.py` - Secure config loading + validation tool
- `icp.py` - PropertyMapper integration
- `rfm.py` - Custom thresholds support
- `hubspot_client.py` - Custom property fetching

### Test Coverage
- Property mapping: 3/3 tests passing
- RFM thresholds: 4/4 tests passing
- Security validation: 13/13 tests passing
- **Total: 23/23 tests passing ✅**

---

## 📝 Documentation

### User Documentation
- README.md: Full configuration guide with examples
- Example configs: 4 JSON templates provided
- llms.txt: Updated for AI discoverability

### Internal Documentation
- IMPLEMENTATION_PROPERTY_MAPPING.md: Implementation details
- IMPLEMENTATION_RFM_THRESHOLDS.md: Implementation details
- SECURITY_CX_AUDIT.md: Full security audit report
- SECURITY_FIXES_SUMMARY.md: Security fixes summary

---

## 🚀 Deployment

- ✅ Committed to GitHub: `a930999` + `0e37e1f`
- ✅ All tests passing
- ✅ Security audit complete
- ✅ Documentation updated
- ✅ Backward compatible (no breaking changes)

### Repository
- **GitHub:** https://github.com/alexboissAV/artefact-ai-workspace
- **Commit:** a930999 (main feature), 0e37e1f (docs update)

---

## 💰 Business Impact

### For Pro Tier ($149/mo)
- ✅ Custom property mapping enabled
- ✅ Custom RFM thresholds enabled
- ✅ Configuration validation tool
- ✅ Full three-dimensional ICP scoring from HubSpot

### For Enterprise Tier ($499/mo)
- ✅ All Pro features
- ✅ Priority support for configuration setup
- 🔮 Future: Multiple mapping profiles per portal

### For Free Tier
- ℹ️ No changes (sample data only, as before)

---

## 📋 Next Steps

### Immediate (Complete)
- [x] Deploy to production
- [x] Update documentation
- [x] Security audit and fixes
- [x] Test coverage complete

### Short Term (Optional)
- [ ] Customer onboarding guide for configuration
- [ ] Video tutorial for Pro customers
- [ ] Configuration migration tool (if needed)

### Future Enhancements
- [ ] Web UI for configuration (no code setup)
- [ ] Auto-detection of HubSpot properties
- [ ] Multiple mapping profiles (Enterprise)
- [ ] Property validation against live HubSpot schema

---

## 🎓 SR&ED Relevance

**Technical Uncertainties Addressed:**
- **TU-035:** Configuration-based property mapping for heterogeneous CRM schemas
- **TU-036:** Secure configuration file validation and path traversal prevention
- **TU-037:** Dynamic threshold adjustment for RFM segmentation across business models

**R&D Hours:**
- Planning & Design: 2 hours
- Implementation: 6 hours
- Security audit & fixes: 3 hours
- Testing & validation: 2 hours
- Documentation: 2 hours
- **Total: 15 hours**

---

## 📞 Support

For Pro/Enterprise customers needing configuration assistance:
- Email: alex@artefactventures.com
- Documentation: See README.md in repository
- Validation tool: Use `validate_configuration()` to test configs

---

## 🏆 Success Metrics

- **Lines of code:** +3,125 lines (23 files changed)
- **Test coverage:** 23/23 tests passing (100%)
- **Security vulnerabilities:** 5 found, 5 fixed
- **CX improvements:** 8 identified, 3 critical fixed
- **Configuration options:** 15+ customizable parameters
- **Example configs:** 4 templates provided
- **Documentation pages:** 4 implementation guides created

**Status:** ✅ **Production Ready - Safe to Deploy**
