# FastMCP 2.x Production Guide

Comprehensive guide to building production MCP servers with FastMCP 2.x (Python MCP SDK by jlowin).

**Last Updated:** 2026-02-10

---

## Table of Contents

1. [Overview & Installation](#overview--installation)
2. [Tool Decorators (@mcp.tool)](#tool-decorators-mcptool)
3. [Resource Decorators (@mcp.resource)](#resource-decorators-mcpresource)
4. [Authentication Patterns](#authentication-patterns)
5. [Context & Dependency Injection](#context--dependency-injection)
6. [Transport Configuration](#transport-configuration)
7. [Project Structure](#project-structure)
8. [pyproject.toml Configuration](#pyprojecttoml-configuration)
9. [Publishing to PyPI](#publishing-to-pypi)
10. [Production Best Practices](#production-best-practices)

---

## Overview & Installation

FastMCP 2.x is the production-ready Python framework for building MCP (Model Context Protocol) servers. FastMCP 1.0 was incorporated into the official MCP SDK in 2024, while FastMCP 2.0 extends with advanced patterns.

**Key Features:**
- Advanced MCP patterns (server composition, proxying, OpenAPI/FastAPI generation)
- Enterprise auth (Google, GitHub, WorkOS, Azure, Auth0, and more)
- Deployment tools and testing utilities
- Comprehensive client libraries

**Installation:**

```bash
# Production installation
pip install fastmcp

# With WebSocket support
pip install fastmcp[websockets]

# Pin to v2 for stability (v3 is in beta)
pip install 'fastmcp<3'
```

**Documentation:** [gofastmcp.com](https://gofastmcp.com)

---

## Tool Decorators (@mcp.tool)

Tools let LLMs take actions through your server.

### Basic Tool

```python
from fastmcp import FastMCP

mcp = FastMCP("My Server")

@mcp.tool
def add(a: int, b: int) -> int:
    """Add two numbers"""
    return a + b
```

### Asynchronous Tool

```python
@mcp.tool
async def create_user(name: str, email: str) -> dict:
    """Create a new user"""
    await asyncio.sleep(0.1)  # Simulate DB operation
    return {"id": 123, "name": name, "email": email}
```

### Tool with Complex Types

```python
from typing import List, Dict, Any

@mcp.tool
def query_users(
    filters: Dict[str, Any],
    limit: int = 10,
    offset: int = 0
) -> List[Dict[str, Any]]:
    """Query users from database with filters"""
    return [
        {"id": i, "name": f"User {i}", "active": True}
        for i in range(offset, offset + limit)
    ]
```

### Tool with Error Handling

```python
from fastmcp import ToolError

@mcp.tool
def divide(a: float, b: float) -> float:
    """Divide two numbers with error handling"""
    if b == 0:
        raise ToolError("Division by zero is not allowed")
    return a / b
```

### Tool with Context (Advanced)

```python
from fastmcp import Context

@mcp.tool
async def process_with_context(
    ctx: Context,
    message: str
) -> str:
    """Process message using context features"""
    ctx.info(f"Processing message: {message}")

    # Access resources through context
    data = await ctx.read_resource("config://settings")

    # Call Claude through context
    response = await ctx.sample(
        model="claude-3-5-sonnet-20241022",
        messages=[{
            "role": "user",
            "content": f"Summarize this: {message}"
        }],
        max_tokens=100
    )
    return response.content
```

---

## Resource Decorators (@mcp.resource)

Resources provide read-only access to data (similar to GET endpoints in REST).

### Static Resource

```python
@mcp.resource("config://version")
def get_version() -> str:
    """Get application version"""
    return "2.0.1"

@mcp.resource("config://settings")
def app_settings() -> str:
    """Application configuration"""
    return json.dumps({
        "version": "1.0.0",
        "debug": False,
        "max_connections": 100
    })
```

### Dynamic Resource with URI Templates

```python
@mcp.resource("user://{user_id}/profile")
def user_profile(user_id: str) -> dict:
    """Get user profile by ID"""
    return {
        "id": user_id,
        "name": f"User {user_id}",
        "created": "2024-01-01"
    }

@mcp.resource("data://{dataset}/latest")
def get_dataset(dataset: str) -> dict:
    """Fetch latest data from specified dataset"""
    # Implementation here
    return {"dataset": dataset, "records": []}
```

### Resource with Annotations (Best Practice)

Use annotations to indicate resource behavior and safety profile:

```python
@mcp.resource(
    "data://config",
    annotations={
        "readOnlyHint": True,
        "idempotentHint": True
    }
)
def get_config() -> str:
    """Get application configuration - read-only, idempotent"""
    return json.dumps({"version": "1.0", "debug": False})

@mcp.resource(
    "cache://{key}",
    annotations={
        "readOnlyHint": False,  # May have side effects
        "idempotentHint": False  # Not idempotent
    }
)
def get_cached_value(key: str) -> str:
    """Get cached value (may trigger cache refresh)"""
    # Implementation may have side effects
    return cache.get(key, refresh_if_stale=True)
```

**Annotation Guidelines:**
- `readOnlyHint: True` - Resource has no side effects
- `readOnlyHint: False` - Resource may perform computation or have side effects
- `idempotentHint: True` - Multiple calls return same result
- `idempotentHint: False` - Results may vary between calls

---

## Authentication Patterns

FastMCP implements three authentication responsibility levels.

### 1. Token Validation (TokenVerifier)

**Use when:** Your organization already uses JWT-based systems, API gateways, or enterprise SSO.

```python
from fastmcp import FastMCP
from fastmcp.server.auth.providers.jwt import JWTVerifier

auth = JWTVerifier(
    jwks_uri="https://your-auth-system.com/.well-known/jwks.json",
    issuer="https://your-auth-system.com",
    audience="your-mcp-server"
)

mcp = FastMCP(name="Protected Server", auth=auth)
```

**Key benefit:** Separates authentication (identity verification) from authorization (access control), leveraging existing JWT infrastructure.

### 2. External Identity Providers (RemoteAuthProvider)

**Use when:** Working with providers supporting Dynamic Client Registration (DCR) like Descope and WorkOS AuthKit.

```python
from fastmcp import FastMCP
from fastmcp.server.auth.providers.workos import AuthKitProvider

auth = AuthKitProvider(
    authkit_domain="https://your-project.authkit.app",
    base_url="https://your-fastmcp-server.com"
)

mcp = FastMCP(name="Enterprise Server", auth=auth)
```

### 3. OAuth Proxy (OAuthProxy)

**Use when:** Integrating with traditional OAuth providers (GitHub, Google, Azure) lacking DCR support.

```python
from fastmcp import FastMCP
from fastmcp.server.auth.providers.github import GitHubProvider

auth = GitHubProvider(
    client_id="Ov23li...",
    client_secret="abc123...",
    base_url="https://your-server.com"
)

mcp = FastMCP(name="GitHub-Protected Server", auth=auth)
```

**Google OAuth:**

```python
from fastmcp.server.auth.providers.google import GoogleProvider

auth = GoogleProvider(
    client_id="your-client-id.apps.googleusercontent.com",
    client_secret="your-client-secret",
    base_url="https://your-server.com"
)

mcp = FastMCP("Secure Server", auth=auth)
```

### Environment Variable Configuration

**Best Practice:** Never hardcode credentials; always use environment variables.

```python
import os
from fastmcp.server.auth.providers.github import GitHubProvider

auth = GitHubProvider(
    client_id=os.environ.get("GITHUB_CLIENT_ID"),
    client_secret=os.environ.get("GITHUB_CLIENT_SECRET"),
    base_url=os.environ.get("BASE_URL", "http://localhost:8000")
)

mcp = FastMCP(name="My Server", auth=auth)
```

### API Key Authentication (Custom)

For simple API key authentication, access HTTP headers within tools:

```python
from fastmcp import Context
from fastmcp.server.http import get_http_request

@mcp.tool
async def protected_operation(ctx: Context, data: str) -> str:
    """Protected operation requiring API key"""
    request = get_http_request()
    api_key = request.headers.get("X-API-Key")

    if not api_key or api_key not in VALID_API_KEYS:
        raise ToolError("Invalid or missing API key")

    # Perform operation
    return f"Processed: {data}"
```

### Authentication Selection Guide

| Scenario | Recommended Approach |
|----------|---------------------|
| Existing JWT infrastructure | TokenVerifier |
| Modern DCR-supporting platforms (Descope, WorkOS) | RemoteAuthProvider |
| Legacy OAuth providers (GitHub, Google, Azure) | OAuth Proxy |
| Custom requirements or air-gapped environments | Full OAuth implementation |

**Important:** Authentication applies only to HTTP-based transports (`http` and `sse`). The STDIO transport inherits security from its local execution environment.

---

## Context & Dependency Injection

The `Context` object provides access to MCP features and request-scoped data.

### Logging

```python
from fastmcp import Context

@mcp.tool
async def process_data(ctx: Context, data: str) -> str:
    """Process data with logging"""
    ctx.info(f"Processing data: {data[:50]}...")
    ctx.debug(f"Full data: {data}")
    ctx.warning("This operation may take time")

    try:
        result = heavy_computation(data)
        ctx.info("Processing complete")
        return result
    except Exception as e:
        ctx.error(f"Processing failed: {e}")
        raise
```

### Resource Access

```python
@mcp.tool
async def summarize(uri: str, ctx: Context) -> str:
    """Summarize content from a resource"""
    await ctx.info(f"Reading resource from {uri}")
    data = await ctx.read_resource(uri)
    return f"Content length: {len(data.content)}"
```

### Claude Sampling (AI Invocation)

```python
@mcp.tool
async def intelligent_analysis(ctx: Context, text: str) -> str:
    """Analyze text using Claude"""
    response = await ctx.sample(
        model="claude-3-5-sonnet-20241022",
        messages=[{
            "role": "user",
            "content": f"Analyze this text: {text}"
        }],
        max_tokens=200
    )
    return response.content
```

### HTTP Request Access

```python
from fastmcp.server.http import get_http_request

@mcp.tool
async def check_auth(ctx: Context) -> dict:
    """Access HTTP request details"""
    request = get_http_request()
    return {
        "method": request.method,
        "path": request.path,
        "headers": dict(request.headers),
        "client": request.client.host if request.client else None
    }
```

---

## Transport Configuration

FastMCP supports three transport mechanisms: STDIO, SSE, and HTTP.

### STDIO Transport (Default - Local)

**Server Side:**

```python
if __name__ == "__main__":
    # Default: STDIO transport
    mcp.run()
```

**Client Side:**

```python
from fastmcp.client.transports import StdioTransport
from fastmcp import Client

transport = StdioTransport(
    command="python",
    args=["my_server.py", "--verbose"],
    env={
        "API_KEY": "secret",
        "LOG_LEVEL": "DEBUG"
    },
    cwd="/path/to/server"
)

client = Client(transport)
```

**Critical Pattern:** STDIO servers run in isolated environments and do NOT inherit shell environment variables. You must explicitly pass required configuration:

```python
import os

required_vars = ["API_KEY", "DATABASE_URL", "REDIS_HOST"]
env = {
    var: os.environ[var]
    for var in required_vars
    if var in os.environ
}

transport = StdioTransport(
    command="python",
    args=["server.py"],
    env=env
)
```

**Session Management:**
- `keep_alive=True` (default) - Reuse subprocess across connections
- `keep_alive=False` - Isolate each connection in new subprocess

### SSE Transport (Remote - Legacy)

**Server Side:**

```python
if __name__ == "__main__":
    mcp.run(transport="sse", host="127.0.0.1", port=8000)
```

**Client Side:**

```python
from fastmcp.client.transports import SSETransport

transport = SSETransport(
    url="https://api.example.com/sse",
    headers={"Authorization": "Bearer token"}
)

client = Client(transport)
```

**Note:** SSE is maintained for backward compatibility. Streamable HTTP is preferred for new implementations.

### HTTP Transport (Remote - Preferred)

**Server Side:**

```python
if __name__ == "__main__":
    mcp.run(
        transport="http",
        host="0.0.0.0",
        port=8080,
        path="/mcp"
    )
```

**Client Side:**

```python
from fastmcp.client.transports import StreamableHttpTransport
from fastmcp import Client

transport = StreamableHttpTransport(
    url="https://api.example.com/mcp",
    headers={
        "Authorization": "Bearer your-token-here",
        "X-Custom-Header": "value"
    }
)

client = Client(transport)
```

**Authentication Helper:**

```python
from fastmcp.client.auth import BearerAuth

client = Client(
    "https://api.example.com/mcp",
    auth=BearerAuth("your-token-here")
)
```

### Transport Selection Guide

| Use Case | Transport | Why |
|----------|-----------|-----|
| Local development, testing | STDIO | Simple, no network needed |
| Claude Desktop integration | STDIO | Standard MCP client pattern |
| Remote access, web deployment | HTTP | Modern, full auth support |
| Legacy remote systems | SSE | Compatibility with older clients |

### CLI Usage

```bash
# Run with default STDIO transport
fastmcp run server.py

# Run with SSE transport
fastmcp run server.py --transport sse --port 8000

# Run with HTTP transport
fastmcp run server.py --transport http --port 8080

# Development mode with debug logging
fastmcp dev server.py --log-level DEBUG
```

---

## Project Structure

### Recommended Structure for Pip-Installable MCP Server

```
my-mcp-server/
├── src/
│   └── my_mcp_package/
│       ├── __init__.py
│       ├── server.py           # Main server definition
│       ├── tools/
│       │   ├── __init__.py
│       │   ├── database.py     # Database-related tools
│       │   └── api.py          # API integration tools
│       ├── resources/
│       │   ├── __init__.py
│       │   └── config.py       # Configuration resources
│       └── auth/
│           ├── __init__.py
│           └── providers.py    # Custom auth providers
├── tests/
│   ├── __init__.py
│   ├── test_tools.py
│   └── test_resources.py
├── pyproject.toml              # Project configuration
├── README.md
├── LICENSE
└── .env.example                # Example environment variables
```

### Example server.py

```python
"""
Main MCP server definition
"""
import os
from fastmcp import FastMCP
from .tools import database, api
from .resources import config

# Initialize server
mcp = FastMCP(
    name="My MCP Server",
    mask_error_details=os.getenv("ENVIRONMENT") == "production",
    dependencies=["httpx", "sqlalchemy"]
)

# Register tools from modules
mcp.tool(database.query_users)
mcp.tool(database.create_user)
mcp.tool(api.fetch_data)

# Register resources
mcp.resource("config://version")(config.get_version)
mcp.resource("config://settings")(config.get_settings)

def main():
    """Entry point for CLI"""
    transport = os.getenv("MCP_TRANSPORT", "stdio")

    if transport == "http":
        mcp.run(
            transport="http",
            host=os.getenv("MCP_HOST", "0.0.0.0"),
            port=int(os.getenv("MCP_PORT", "8080"))
        )
    elif transport == "sse":
        mcp.run(
            transport="sse",
            host=os.getenv("MCP_HOST", "0.0.0.0"),
            port=int(os.getenv("MCP_PORT", "8000"))
        )
    else:
        mcp.run()  # STDIO default

if __name__ == "__main__":
    main()
```

### Example tools/database.py

```python
"""Database-related tools"""
from typing import List, Dict, Any
from fastmcp import Context, ToolError
import sqlalchemy

async def query_users(
    ctx: Context,
    filters: Dict[str, Any],
    limit: int = 10
) -> List[Dict[str, Any]]:
    """Query users from database"""
    ctx.info(f"Querying users with filters: {filters}")

    # Implementation
    results = []  # Database query here

    ctx.info(f"Found {len(results)} users")
    return results

async def create_user(
    ctx: Context,
    name: str,
    email: str
) -> Dict[str, Any]:
    """Create a new user"""
    if not email or "@" not in email:
        raise ToolError("Invalid email address")

    ctx.info(f"Creating user: {name}")

    # Implementation
    user = {"id": 123, "name": name, "email": email}

    return user
```

### Example resources/config.py

```python
"""Configuration resources"""
import json
import os

def get_version() -> str:
    """Get application version"""
    return "1.0.0"

def get_settings() -> str:
    """Get application settings"""
    settings = {
        "version": get_version(),
        "debug": os.getenv("DEBUG", "false").lower() == "true",
        "max_connections": int(os.getenv("MAX_CONNECTIONS", "100")),
        "environment": os.getenv("ENVIRONMENT", "development")
    }
    return json.dumps(settings, indent=2)
```

---

## pyproject.toml Configuration

### Complete Example

```toml
[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "my-mcp-server"
version = "1.0.0"
description = "Production MCP server built with FastMCP"
readme = "README.md"
requires-python = ">=3.9"
license = {text = "MIT"}
authors = [
    {name = "Your Name", email = "you@example.com"}
]
keywords = ["mcp", "model-context-protocol", "ai", "llm"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]

dependencies = [
    "fastmcp>=2.0,<3.0",
    "httpx>=0.25.0",
    "sqlalchemy>=2.0",
    "pydantic>=2.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
    "pytest-cov>=4.0",
    "black>=23.0",
    "ruff>=0.1.0",
    "mypy>=1.0",
]
test = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
]

[project.urls]
Homepage = "https://github.com/yourusername/my-mcp-server"
Documentation = "https://my-mcp-server.readthedocs.io"
Repository = "https://github.com/yourusername/my-mcp-server"
Issues = "https://github.com/yourusername/my-mcp-server/issues"

[project.scripts]
my-mcp-server = "my_mcp_package.server:main"
mcp-server-dev = "my_mcp_package.server:main"

[tool.setuptools]
package-dir = {"" = "src"}

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
testpaths = ["tests"]
asyncio_mode = "auto"
addopts = "-v --cov=my_mcp_package --cov-report=term-missing"

[tool.black]
line-length = 88
target-version = ["py39", "py310", "py311", "py312"]

[tool.ruff]
line-length = 88
target-version = "py39"
select = ["E", "F", "W", "I", "N", "UP", "S", "B", "C4"]
ignore = ["E501"]

[tool.mypy]
python_version = "3.9"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
```

### Key Sections Explained

#### [build-system]
Specifies how to build your package. Use `setuptools` for standard Python packages.

#### [project]
Core metadata about your package:
- `name` - Package name on PyPI (use hyphens, not underscores)
- `version` - Semantic version (major.minor.patch)
- `dependencies` - Runtime requirements
- `requires-python` - Minimum Python version
- `classifiers` - PyPI classifiers for discoverability

#### [project.optional-dependencies]
Additional dependencies for specific use cases:
- `dev` - Development tools (linting, formatting, type checking)
- `test` - Testing dependencies

#### [project.scripts]
Command-line entry points installed with your package:

```toml
[project.scripts]
my-mcp-server = "my_mcp_package.server:main"
```

This creates a `my-mcp-server` command that calls `main()` from `my_mcp_package.server`.

**After installation:**
```bash
pip install my-mcp-server
my-mcp-server  # Runs your server
```

#### [tool.setuptools]
Configure package discovery:
- `package-dir` - Source directory location
- `packages.find.where` - Where to find Python packages

---

## Publishing to PyPI

### 1. Prepare Your Package

Ensure your package structure is correct:

```bash
my-mcp-server/
├── src/
│   └── my_mcp_package/
│       ├── __init__.py
│       └── server.py
├── pyproject.toml
├── README.md
└── LICENSE
```

### 2. Build Distribution Files

Install build tools:

```bash
pip install build twine
```

Build your package:

```bash
python -m build
```

This creates `dist/` directory with:
- `my-mcp-server-1.0.0.tar.gz` (source distribution)
- `my_mcp_server-1.0.0-py3-none-any.whl` (wheel)

### 3. Test on TestPyPI (Optional but Recommended)

Register on [test.pypi.org](https://test.pypi.org) and upload:

```bash
python -m twine upload --repository testpypi dist/*
```

Test installation:

```bash
pip install --index-url https://test.pypi.org/simple/ my-mcp-server
```

### 4. Publish to PyPI

Register on [pypi.org](https://pypi.org) and upload:

```bash
python -m twine upload dist/*
```

Enter your PyPI credentials (or use API token).

### 5. Verify Installation

```bash
pip install my-mcp-server
my-mcp-server --help
```

### Using API Tokens (Recommended)

Create PyPI API token at: https://pypi.org/manage/account/token/

Configure in `~/.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-your-api-token-here

[testpypi]
username = __token__
password = pypi-your-test-api-token-here
```

### GitHub Actions CI/CD

Automate publishing with GitHub Actions:

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3

    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'

    - name: Install dependencies
      run: |
        pip install build twine

    - name: Build package
      run: python -m build

    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*
```

Add `PYPI_API_TOKEN` to GitHub repository secrets.

---

## Production Best Practices

### 1. Error Masking in Production

```python
import os

mcp = FastMCP(
    "Production Server",
    mask_error_details=os.getenv("ENVIRONMENT") == "production"
)
```

When `mask_error_details=True`, internal errors are hidden from clients.

### 2. Environment-Based Configuration

```python
import os
from dotenv import load_dotenv

load_dotenv()

# Configuration from environment
DEBUG = os.getenv("DEBUG", "false").lower() == "true"
DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.getenv("API_KEY")

if not DATABASE_URL:
    raise ValueError("DATABASE_URL environment variable is required")
```

### 3. Structured Logging

```python
import logging
from fastmcp import Context

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)

@mcp.tool
async def important_operation(ctx: Context, data: str) -> str:
    """Operation with proper logging"""
    logger = logging.getLogger(__name__)

    logger.info(f"Starting operation for data: {data[:50]}")
    ctx.info("User-visible log message")

    try:
        result = process(data)
        logger.info("Operation completed successfully")
        return result
    except Exception as e:
        logger.error(f"Operation failed: {e}", exc_info=True)
        ctx.error(f"Operation failed: {str(e)}")
        raise
```

### 4. Input Validation with Pydantic

```python
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional

class CreateUserInput(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: Optional[int] = Field(None, ge=0, le=150)

    @validator('name')
    def name_must_not_contain_special_chars(cls, v):
        if not v.replace(' ', '').isalnum():
            raise ValueError('Name must be alphanumeric')
        return v

@mcp.tool
async def create_user(
    ctx: Context,
    name: str,
    email: str,
    age: Optional[int] = None
) -> dict:
    """Create user with validated input"""
    # Validate input
    try:
        user_input = CreateUserInput(name=name, email=email, age=age)
    except Exception as e:
        raise ToolError(f"Invalid input: {e}")

    # Process validated data
    return {"id": 123, "name": user_input.name, "email": user_input.email}
```

### 5. Rate Limiting

```python
from functools import wraps
from time import time
from collections import defaultdict

# Simple in-memory rate limiter
rate_limits = defaultdict(list)

def rate_limit(max_calls: int, period: int):
    """Rate limit decorator: max_calls per period (seconds)"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Get user ID from context (simplified)
            user_id = "default"

            now = time()
            # Clean old entries
            rate_limits[user_id] = [
                t for t in rate_limits[user_id]
                if now - t < period
            ]

            if len(rate_limits[user_id]) >= max_calls:
                raise ToolError(f"Rate limit exceeded: {max_calls} calls per {period}s")

            rate_limits[user_id].append(now)
            return await func(*args, **kwargs)
        return wrapper
    return decorator

@mcp.tool
@rate_limit(max_calls=10, period=60)
async def expensive_operation(ctx: Context, data: str) -> str:
    """Rate-limited expensive operation"""
    return f"Processed: {data}"
```

### 6. Database Connection Pooling

```python
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from contextlib import asynccontextmanager

# Initialize connection pool
engine = create_async_engine(
    os.getenv("DATABASE_URL"),
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True
)

AsyncSessionLocal = sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)

@asynccontextmanager
async def get_db():
    """Database session context manager"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise

@mcp.tool
async def query_database(ctx: Context, query: str) -> list:
    """Query database with connection pooling"""
    async with get_db() as db:
        result = await db.execute(query)
        return result.fetchall()
```

### 7. Health Check Endpoint

```python
@mcp.resource("health://status")
def health_check() -> dict:
    """Health check for monitoring"""
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "version": "1.0.0"
    }
```

### 8. Graceful Shutdown

```python
import signal
import sys

def signal_handler(sig, frame):
    """Handle shutdown signals gracefully"""
    print("\nShutting down gracefully...")
    # Close database connections
    # Finish pending operations
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

if __name__ == "__main__":
    mcp.run()
```

### 9. Monitoring and Metrics

```python
from time import time
import logging

metrics_logger = logging.getLogger("metrics")

@mcp.tool
async def monitored_operation(ctx: Context, data: str) -> str:
    """Operation with metrics tracking"""
    start_time = time()

    try:
        result = await process(data)
        duration = time() - start_time
        metrics_logger.info(f"operation_success,duration={duration}")
        return result
    except Exception as e:
        duration = time() - start_time
        metrics_logger.error(f"operation_failure,duration={duration},error={type(e).__name__}")
        raise
```

### 10. Testing Pattern

```python
# tests/test_tools.py
import pytest
from fastmcp import Client
from my_mcp_package.server import mcp

@pytest.mark.asyncio
async def test_add_tool():
    """Test the add tool"""
    client = Client(mcp)

    async with client:
        result = await client.call_tool("add", {"a": 5, "b": 3})
        assert result.content[0].text == "8"

@pytest.mark.asyncio
async def test_divide_by_zero():
    """Test divide tool error handling"""
    client = Client(mcp)

    async with client:
        with pytest.raises(Exception) as exc_info:
            await client.call_tool("divide", {"a": 10, "b": 0})
        assert "Division by zero" in str(exc_info.value)
```

---

## Complete Production Example

Here's a complete, production-ready FastMCP server example:

```python
"""
Production FastMCP Server
"""
import os
import logging
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv
from fastmcp import FastMCP, Context, ToolError
from pydantic import BaseModel, EmailStr, Field
import httpx

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO if not os.getenv("DEBUG") else logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)

# Initialize FastMCP server
mcp = FastMCP(
    name="Production MCP Server",
    mask_error_details=os.getenv("ENVIRONMENT") == "production",
    dependencies=["httpx", "pydantic"]
)

# Pydantic models for validation
class UserInput(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: Optional[int] = Field(None, ge=0, le=150)

# Tools
@mcp.tool
async def create_user(
    ctx: Context,
    name: str,
    email: str,
    age: Optional[int] = None
) -> Dict[str, Any]:
    """Create a new user with validated input"""
    logger.info(f"Creating user: {name}")

    try:
        user_input = UserInput(name=name, email=email, age=age)
    except Exception as e:
        ctx.error(f"Validation failed: {e}")
        raise ToolError(f"Invalid input: {e}")

    # Simulate user creation
    user = {
        "id": 123,
        "name": user_input.name,
        "email": user_input.email,
        "age": user_input.age
    }

    ctx.info(f"User created successfully: {user['id']}")
    return user

@mcp.tool
async def fetch_api_data(
    ctx: Context,
    endpoint: str,
    params: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Fetch data from external API"""
    api_key = os.getenv("API_KEY")
    if not api_key:
        raise ToolError("API_KEY not configured")

    ctx.info(f"Fetching data from: {endpoint}")

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(
                f"https://api.example.com/{endpoint}",
                params=params,
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=30.0
            )
            response.raise_for_status()
            data = response.json()
            ctx.info(f"Successfully fetched {len(data)} items")
            return data
        except httpx.HTTPError as e:
            ctx.error(f"API request failed: {e}")
            raise ToolError(f"Failed to fetch data: {e}")

# Resources
@mcp.resource(
    "config://version",
    annotations={"readOnlyHint": True, "idempotentHint": True}
)
def get_version() -> str:
    """Get application version"""
    return "1.0.0"

@mcp.resource(
    "config://settings",
    annotations={"readOnlyHint": True, "idempotentHint": True}
)
def get_settings() -> Dict[str, Any]:
    """Get application settings"""
    return {
        "version": get_version(),
        "environment": os.getenv("ENVIRONMENT", "development"),
        "debug": os.getenv("DEBUG", "false").lower() == "true"
    }

@mcp.resource("health://status")
def health_check() -> Dict[str, Any]:
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": get_version()
    }

# Entry point
def main():
    """Main entry point for CLI"""
    transport = os.getenv("MCP_TRANSPORT", "stdio")

    logger.info(f"Starting MCP server with {transport} transport")

    if transport == "http":
        mcp.run(
            transport="http",
            host=os.getenv("MCP_HOST", "0.0.0.0"),
            port=int(os.getenv("MCP_PORT", "8080"))
        )
    elif transport == "sse":
        mcp.run(
            transport="sse",
            host=os.getenv("MCP_HOST", "0.0.0.0"),
            port=int(os.getenv("MCP_PORT", "8000"))
        )
    else:
        mcp.run()  # STDIO default

if __name__ == "__main__":
    main()
```

**Corresponding .env file:**

```env
# Environment
ENVIRONMENT=production
DEBUG=false

# Transport
MCP_TRANSPORT=stdio
MCP_HOST=0.0.0.0
MCP_PORT=8080

# API Configuration
API_KEY=your-api-key-here

# Authentication (if using OAuth)
GITHUB_CLIENT_ID=your-github-client-id
GITHUB_CLIENT_SECRET=your-github-client-secret
BASE_URL=https://your-server.com
```

---

## Sources

Research compiled from:

- [FastMCP GitHub Repository](https://github.com/jlowin/fastmcp)
- [FastMCP PyPI Package](https://pypi.org/project/fastmcp/)
- [FastMCP 2.0 Introduction](https://www.jlowin.dev/blog/fastmcp-2)
- [FastMCP Documentation](https://gofastmcp.com)
- [FastMCP Authentication Guide](https://gofastmcp.com/servers/auth/authentication)
- [FastMCP Resources Documentation](https://gofastmcp.com/servers/resources)
- [FastMCP Client Transports](https://gofastmcp.com/clients/transports)
- [Building MCP Servers with FastMCP (MCPcat)](https://mcpcat.io/guides/building-mcp-server-python-fastmcp/)
- [How to Build Your First MCP Server (FreeCodeCamp)](https://www.freecodecamp.org/news/how-to-build-your-first-mcp-server-using-fastmcp/)
- [Building and Exposing MCP Servers with FastMCP](https://medium.com/@anil.goyal0057/building-and-exposing-mcp-servers-with-fastmcp-stdio-http-and-sse-ace0f1d996dd)
- [Python Packaging Guide - pyproject.toml](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/)
- [Setuptools Entry Points](https://setuptools.pypa.io/en/latest/userguide/entry_point.html)

---

**Last Updated:** 2026-02-10 by Alex Boissonneault
