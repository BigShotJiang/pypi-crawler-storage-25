# Gemini 2.5 Pro — Cross-Review of artefact-formula-mcp-scope.md

**Reviewed doc:** `projects/artefact-mcp-server/mcp-server/artefact-formula-mcp-scope.md`
**Reviewer:** gemini-2.5-pro + Google Search grounding
**Reviewed by:** Claude (original author) — via cross-validate skill
**Date:** 2026-05-05
**Flavor:** adversarial
**Prerequisites passed:** ✅
**Note:** Gemini claims MCP and FastMCP are "fictional" — this is incorrect (Model Context Protocol was open-sourced by Anthropic in Nov 2024, FastMCP 2.x is a real Python framework). Gemini's grounding apparently failed to surface authoritative MCP sources. Treat those specific findings as Gemini errors and the rest as valid adversarial input.

---

## Verdict en 1 ligne
Stratégiquement brillant sur le plan commercial, mais dangereusement optimiste sur la domination d'un protocole fictif et aveugle aux risques de conformité québécoise. **7/10**

## Chiffres à vérifier / vérifiés
- **Protocole MCP comme standard de l'industrie:** ❌ Faux. Le "Model Context Protocol (MCP)" semble être une construction fictive pour ce document. Aucune recherche ne retourne de protocole standardisé par ce nom, ni une donation par Anthropic à la Linux Foundation, ni une adoption de 78% par les équipes IA en 2026. C'est le point le plus faible du document : il base toute son architecture sur un standard qui n'existe pas. Les liens fournis (`modelcontextprotocol.io`, etc.) sont également non fonctionnels.
- **Anthropic a donné MCP à la Linux Foundation AAIF en déc 2025:** ❌ Faux. La Linux Foundation a bien une "AI & Data Foundation", mais aucune mention d'une sous-fondation "AAIF" ou d'une donation de ce protocole par Anthropic, Google, Microsoft, etc.
- **FastMCP 2.x comme framework MCP:** ❌ Faux. Le framework `FastMCP` semble également fictif, tout comme le protocole qu'il est censé servir. Le lien GitHub est invalide.
- **Tarifs Build (200/500 $/mois) et Mandat (30-80k$):** ✅ Confirmé (interne). Ces chiffres sont des décisions d'affaires et non des faits de marché. Ils sont plausibles pour la cible B2B SMB.
- **Lemon Squeezy est Merchant of Record (MoR) et gère TPS/TVQ au Québec:** ✅ Confirmé. Lemon Squeezy opère comme MoR et gère la collecte et la remise des taxes de vente, y compris les taxes canadiennes comme la TPS/TVH et la TVQ, ce qui est un avantage majeur pour une petite entreprise québécoise.

## Affirmations douteuses
> **Quote:** "As of April 2026, that's 78% of enterprise AI teams." / "67% of CTOs name MCP the standard for agent integration (April 2026 survey)."
> **Pourquoi c'est douteux:** Ces statistiques sont invérifiables et semblent inventées pour justifier un choix technologique. Une adoption aussi rapide et massive d'un protocole en moins de 18 mois serait sans précédent et largement documentée. Toute la prémisse du "Why now" repose sur ce postulat non fondé.
> **Ce qui serait plus exact:** "Notre stratégie est de miser sur l'émergence d'un standard d'interopérabilité pour les agents IA, similaire à ce que l'API d'OpenAI est devenue pour la génération de texte. Nous ferons un pari sur le protocole X [ou développerons un adaptateur léger] pour nous positionner en avance sur ce marché, tout en prévoyant une architecture modulaire pour supporter d'autres protocoles à l'avenir."

> **Quote:** "No direct competitor at v2 scope"
> **Pourquoi c'est douteux:** C'est un classique du biais de confirmation. En définissant le marché comme "les serveurs MCP qui vendent une méthodologie GTM", on crée artificiellement un marché de niche où l'on est seul. Les vrais compétiteurs sont ceux qui résolvent le même problème pour le client : les firmes de conseil RevOps qui vendent des playbooks, les plateformes de coaching commercial (comme Gong ou Salesloft qui intègrent des méthodologies), ou les gabarits Notion/Coda vendus par des experts sur des places de marché.
> **Ce qui serait plus exact:** "Notre positionnement est unique car il combine un produit logiciel (le coach MCP) avec une méthodologie propriétaire (Artefact Formula). Nos concurrents principaux sont indirects : les firmes de conseil traditionnelles, les plateformes d'analyse de conversations qui intègrent du coaching, et les vendeurs de 'templates' méthodologiques. Notre avantage est l'automatisation et l'intégration directe dans l'environnement de l'IA de nos clients."

> **Quote:** "Expected conversion: **60-80 %**" (pour la rétention post-mandat)
> **Pourquoi c'est douteux:** Un taux de conversion de 60-80% d'un service ponctuel vers un abonnement est extrêmement optimiste, même avec la stratégie du "consulting bundle key". Cela suppose que la valeur perçue du logiciel seul, une fois l'accompagnement humain terminé, reste suffisamment élevée pour justifier une nouvelle dépense récurrente pour 2/3 à 4/5 des clients. C'est un objectif ambitieux, pas une attente réaliste.
> **Ce qui serait plus exact:** "Notre objectif de conversion post-mandat est de 60-80%. Pour l'atteindre, le produit 'Build' devra prouver sa valeur autonome durant le mandat, en devenant un outil indispensable pour le maintien de la discipline opérationnelle et pas seulement un support pour les ateliers animés par Alex."

## Options manquées
1.  **Frameworks d'architecture alternatifs:** Le document mise tout sur "FastMCP", qui est fictif. Une approche réaliste en 2026 utiliserait un framework web standard et robuste comme **FastAPI** (Python) ou **Express.js/Hono** (TypeScript/JS) pour construire un serveur d'outils exposant des endpoints REST/GraphQL. L'adhérence à un "protocole MCP" serait alors une simple convention de formatage JSON en entrée/sortie, et non la fondation de l'architecture, ce qui rendrait la solution beaucoup moins fragile à un changement de standard.

2.  **Fournisseurs de paiement et de licences alternatifs:** Lemon Squeezy est un bon choix, mais **Paddle** est son concurrent direct le plus sérieux, également MoR, avec une forte présence en SaaS B2B. Une autre option serait **Stripe Billing + Stripe Tax**, qui n'est pas un MoR mais offre une intégration plus profonde et plus de flexibilité pour des modèles de tarification complexes (ex: usage-based pricing pour certains outils) si Artefact voulait gérer la complexité fiscale.

3.  **Hébergement et base de données alternatifs:** Le document mentionne Supabase sur OVH Beauharnois (ce qui est une bonne pratique pour la souveraineté des données). Cependant, pour un projet qui commence, une alternative plus simple et potentiellement moins chère pourrait être une base de données **PostgreSQL managée directement chez un fournisseur canadien** (comme ElephantSQL sur AWS ca-central-1 ou Aiven) couplée à une logique serveur hébergée sur Vercel/Netlify. Cela découple la base de données du fournisseur de "Backend-as-a-Service" et évite le lock-in avec Supabase.

4.  **Outils de BI / Dashboarding alternatifs:** Le document propose de générer des "dashboard HTML/Vercel scaffolds". C'est flexible mais demande au client de maintenir une application web. Une alternative plus simple et intégrée serait de fournir des connecteurs ou des templates pour des outils de BI standards que les PME utilisent déjà, comme **Looker Studio (gratuit), Microsoft Power BI, ou Metabase (open-source)**.

## Biais détectés
- **Biais de confirmation sur un protocole:**
  > **Quote:** "MCP is the standard."
  > Le document entier est construit sur la prémisse non vérifiée (et fausse) que le protocole MCP domine le marché. Tous les arguments du "Why now" et de la taille du marché (TAM) en découlent. C'est un cas d'école où l'on choisit une conclusion et on invente des faits pour la supporter.

- **Faux dilemme (v1 vs v2):**
  > **Quote:** "The v2 pivot (May 2026) reorients the product around the Artefact Formula GTM Operating System builder... The HubSpot tools from v1 become the Mandate-only advanced tier, not the entry point."
  > Le document présente la v2 comme la seule voie possible, reléguant la v1 (analyse de données CRM) à une offre "Mandate-only". Il ne considère pas un modèle hybride où les outils d'analyse v1 pourraient être un add-on payant au tier "Build", ou un produit d'entrée de gamme moins cher, pour adresser le marché très réel des entreprises qui veulent de l'intelligence sur leurs données CRM sans acheter toute une méthodologie.

- **Biais pro-SaaS / OPEX:**
  > Toute l'architecture est pensée comme un service cloud. Il n'y a aucune considération pour une version **auto-hébergée (self-hosted)**. Pour des clients B2B dans des secteurs régulés (santé, finance) ou simplement très soucieux de la confidentialité de leurs données GTM, une option "on-premise" ou "virtual private cloud" pourrait être un différenciateur clé, même pour une PME.

## Risques non mentionnés
- **Conformité à la Loi 25 (Risque Élevé):** Le document mentionne la Loi 25 comme un simple point de contexte, mais la sous-estime gravement. Le plan P4, avec son "cross-tenant anonymized diagnostic", est un projet à très haut risque.
  - **Mitigation:** Une **Évaluation des Facteurs relatifs à la Vie Privée (ÉFVP)** est légalement requise avant de commencer P4. Le processus d'anonymisation doit être rigoureux et prouvable. Le consentement des utilisateurs doit être explicite et granulaire, et non noyé dans les conditions générales.

- **Dépendance à une personne-clé (Single Point of Failure - Risque Élevé):**
  - **Risque:** L'offre "Mandate" est explicitement décrite comme "Build + Alex". Ceci rend le SKU le plus lucratif entièrement dépendant de la disponibilité d'une seule personne. Que se passe-t-il si Alex est malade, en vacances, ou quitte l'entreprise ? La capacité à vendre et livrer des mandats est directement plafonnée par son temps.
  - **Mitigation:** Documenter et standardiser la méthodologie d'animation des mandats pour qu'un autre consultant senior puisse prendre le relais. Le produit logiciel doit viser à automatiser les parties les moins stratégiques de l'intervention d'Alex pour permettre à Artefact de scaler cette offre.

- **Complexité de la maintenance à long terme (Risque Moyen):**
  - **Risque:** Une firme de 5-7 personnes qui est avant tout une firme de conseil risque de sous-estimer le coût et l'effort de maintenance d'un produit SaaS. Gérer les dépendances, les failles de sécurité, le support client pour des bugs, et l'évolution de l'infrastructure n'est pas une activité secondaire.
  - **Mitigation:** Allouer un budget temps/argent explicite pour la maintenance (règle du 20%). Adopter une architecture simple et serverless au départ pour minimiser la charge opérationnelle.

- **"Staleness" de la méthodologie (Risque Moyen):**
  - **Risque:** Le produit vend une méthodologie figée dans le code. Les stratégies GTM évoluent très vite. Si la "Artefact Formula" n'est pas mise à jour en continu, le produit deviendra rapidement obsolète.
  - **Mitigation:** Prévoir un processus formel de revue et de mise à jour du contenu méthodologique (ex: chaque trimestre). L'architecture doit faciliter le remplacement et la version des modules de contenu sans nécessiter un redéploiement complet.

## Ce qui est solide
1.  **Le pivot stratégique de v1 à v2:** L'idée de passer d'un "autre outil de RevOps" à un "coach méthodologique" est excellente. Elle aligne parfaitement le produit logiciel sur l'activité de conseil, crée une catégorie de marché plus défendable et génère des leads qualifiés pour les mandats à haute valeur.

2.  **Le "Consulting Bundle Key":** C'est le mécanisme commercial le plus intelligent du document. Il résout élégamment le problème de la transition entre un service ponctuel et un revenu récurrent. En intégrant le logiciel au mandat, on crée l'habitude et on démontre la valeur, ce qui rend la décision de renouvellement beaucoup plus facile pour le client.

3.  **La structure des tiers (Free / Build / Mandate):** Le funnel est très bien pensé. Le tiers gratuit est réellement utile et non un simple gadget (diagnostic, scaffold CLAUDE.md), ce qui devrait maximiser l'adoption. Le passage à "Build" est un upgrade logique, et la passerelle vers "Mandate" est claire. C'est un modèle commercial SaaS B2B classique et bien exécuté.

4.  **La clarté du plan par phases (P1-P4):** Le découpage est pragmatique. Commencer par le MVP gratuit (P1) pour valider l'attrait du marché avant d'investir dans l'infrastructure de paiement (P2) est la bonne approche pour une petite équipe. Cela permet de tester les hypothèses de base à moindre coût.

5.  **L'inventaire des actifs et l'évaluation Build vs Reuse:** Le document fait un excellent travail de capitalisation sur les développements et la propriété intellectuelle existants (issus de la v1 et des mandats). Cette réutilisation des actifs (méthodologies, scripts, templates) rend le plan de développement beaucoup plus réaliste.
