# Artefact Formula MCP — Technical Scope (v2.1)

**Project:** Artefact Ventures — Self-Serve GTM Operating System Builder
**Author:** Alex Boissonneault
**Date:** 2026-05-05 (v2 pivot from 2026-02-10 v1) · 2026-05-05 (v2.1 cross-review patches)
**Status:** Architecture & Scoping
**Supersedes:** `mcp-revenue-intelligence-server-scope.md` (v1, HubSpot Revenue Intelligence focus)

## v2.1 changelog (2026-05-05)

Patches issus du cross-review Gemini 2.5 Pro adversarial du même jour. Documents de review : [`artefact-formula-mcp-scope-cross-review-gemini-2026-05-05.md`](./artefact-formula-mcp-scope-cross-review-gemini-2026-05-05.md) + [`../../systeme-operatoire-ia-template/modes/README-cross-review-gemini-2026-05-05.md`](../../systeme-operatoire-ia-template/modes/README-cross-review-gemini-2026-05-05.md).

* **Préambule MCP** ajouté avec sources canoniques (cross-review #1 Gemini ne savait pas ce qu'est MCP — signal que les sponsors non-tech non plus)
* **Stats 78%/67%** reformulées en signaux directionnels sourçables (étaient invérifiables précisément)
* **Conversion 60-80% post-mandat** reformulée comme **cible** avec conditions de succès (était présentée comme attente)
* **Biais pro-SaaS** reconnu : retainer stratégique présenté comme alternative au funnel Build retention
* **SPOF Alex** ajouté en Section 13 comme question ouverte critique
* **Loi 25 P4** durci : ÉFVP requise AVANT conception P4 (pas avant ship)
* **Compétiteurs indirects** reconnus en Section 10 (firmes RevOps, plateformes coaching, marketplaces templates)
* **Retainer stratégique** entre Build et Mandate ajouté en option à valider
* **Maintenance long-terme** : règle 20% du dev pour maintenance ajoutée en Section 9
* **Staleness méthodologique** : cadence trimestrielle de revue ajoutée en Section 13
* **Self-hosted option** Mandate-tier ajoutée en Section 13

## Préambule — qu'est-ce que MCP

**Model Context Protocol (MCP)** est le protocole open-source d'interopérabilité entre LLMs et outils externes, créé par Anthropic et open-sourcé en novembre 2024 (`https://modelcontextprotocol.io/`). Il a été donné à la **Linux Foundation Agentic AI Foundation (AAIF)** le 9 décembre 2025, avec OpenAI et Block comme co-fondateurs et Google, Microsoft, Amazon, Bloomberg, Cloudflare comme membres platinum.

**Sources canoniques :**
* Site officiel : `modelcontextprotocol.io`
* Spécification : `github.com/modelcontextprotocol/specification`
* SDK Python : `github.com/modelcontextprotocol/python-sdk`
* SDK TypeScript : `github.com/modelcontextprotocol/typescript-sdk`
* FastMCP framework : `github.com/jlowin/fastmcp` (basé sur le Python SDK officiel)
* Donation AAIF : `anthropic.com/news/donating-the-model-context-protocol`

Si un sponsor ou un développeur ne connaît pas MCP, l'inviter à parcourir ces ressources avant de discuter de la roadmap. C'est un protocole jeune (18 mois) mais largement adopté.

---

## Why this v2 supersedes v1

The v1 scope (Feb 2026) was a HubSpot Revenue Intelligence layer — proprietary scoring on top of CRM data, sold as a paid SaaS subscription. It was commercially correct but strategically narrow:

* **Free tier was « fake data demo »** — weak UX, weak lead gen
* **Paid tier was « run analysis on your data »** — competes head-on with crowded RevOps tooling space
* **Monetization was disconnected from mandates** — no mechanism to convert a Build subscriber to a Mandate, or a Mandate client to a Build retainer post-handoff
* **Niching was implicit** — server claimed to do « revenue intelligence » without anchoring to a specific function

The v2 pivot (May 2026) reorients the product around the Artefact Formula GTM Operating System builder. The MCP becomes the **self-serve front-end of the consulting practice** — a methodology coach that scaffolds, diagnoses, and (optionally) executes against a client's GTM stack. The HubSpot tools from v1 become the **Mandate-only advanced tier**, not the entry point.

**Strategic effect:** widens the funnel (Free is now genuinely useful), creates retention post-mandate (consulting bundle key), and defends the moat against AI commoditization by capturing the methodological standard.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Niching: GTM Operating System Builder](#2-niching-gtm-operating-system-builder)
3. [Pricing Model: 4 SKUs](#3-pricing-model-4-skus)
4. [Architecture](#4-architecture)
5. [Tools by Tier](#5-tools-by-tier)
6. [Resources by Tier](#6-resources-by-tier)
7. [Phase Plan (P1-P4)](#7-phase-plan-p1-p4)
8. [Existing Asset Inventory](#8-existing-asset-inventory)
9. [Build vs Reuse Assessment](#9-build-vs-reuse-assessment)
10. [Competitive Landscape](#10-competitive-landscape)
11. [Pricing Strategy: Consulting Bundle Key](#11-pricing-strategy-consulting-bundle-key)
12. [Multi-LLM Strategy](#12-multi-llm-strategy)
13. [Open Questions](#13-open-questions)

---

## 1. Executive Summary

### What this is

An MCP server that productizes the Artefact Formula methodology as a self-serve GTM Operating System builder. Users at any tier can:

* **Free** — read methodology, get an auto-diagnostic of their GTM maturity, generate a CLAUDE.md scaffold, get architecture decision-tree guidance
* **Build solo (200 $/mo)** — generate skill scaffolds, deploy v1 sentinelles, get module prompts (`/artefact-fond-1` etc.), use cost estimator and Notion DB templates
* **Build team (500 $/mo)** — multi-seat Build with shared library
* **Mandate (30-80 K$ ponctuel)** — Build + Alex (entrevues, custom Cat 1 skills, Cat 2 advanced sentinelles, sponsor coaching)

The server runs **anywhere MCP is supported** — Claude (Desktop, Code, Team, Cowork), ChatGPT, Gemini (CLI, API, Vertex), Copilot, Cursor, Windsurf, and every IDE/SDK that has adopted the protocol. Adoption signal in 2026 : majeure dans l'écosystème agent enterprise (rapports Anthropic + Linux Foundation AAIF, à sourcer précisément avant tout deck client public).

### Why now

* **MCP is converging into a standard.** Adoption en croissance forte chez Claude, ChatGPT (oct 2025), Gemini (mars 2026), Copilot. Multi-LLM TAM beaucoup plus large que « utilisateurs Claude ». **Note : éviter de citer des pourcentages d'adoption précis dans les decks clients sans source publique vérifiable** — préférer « adoption significative documentée par AAIF + Anthropic ».
* **Anthropic donated MCP to the Linux Foundation AAIF** in December 2025. Co-founders OpenAI + Block, members include Google, Microsoft, AWS, Bloomberg.
* **Methodology marketplaces are whitespace.** Every existing MCP server is a CRUD wrapper. Nobody is selling a *methodology* via MCP yet.
* **Lemon Squeezy MoR** removes the revenue infrastructure problem (taxes globally including TPS/TVQ Quebec, license keys built-in, customer portal native).

### Why this beats v1

| Dimension | v1 (Feb 2026) | v2 (May 2026) |
|---|---|---|
| Free tier | Fake-data demo | Architecture coach with auto-diagnostic, CLAUDE.md scaffold, 5 piliers reference |
| Paid tier | Pay to run RFM/SPICED on your CRM | Build subscription that scaffolds an entire GTM operating system |
| Funnel | « Discovery → Paid trial → Subscription » | « Free coach → Build subscriber → Mandate prospect → Mandate client → Build retainer » |
| TAM | Claude users with HubSpot | Any AI agent user with a GTM function |
| Mandate fit | Disconnected | Build + Mandate stack via consulting bundle key |
| Moat | « Better scoring than generic CRUD » | « Captures the methodological standard for GTM OS » |

### Targets — cibles, pas attentes

Tous les chiffres ci-dessous sont des **cibles ambitieuses**, pas des prévisions actuariales. À atteindre, des conditions doivent être remplies (voir notes).

* **2026-Q4** — 100 paying Build subscribers = 240 K$ ARR (condition : P1 Free shipped en mai-juin et premier mois de visibilité directories Tier 1 atteint)
* **2027** — 500 Build subscribers = 1.2 M$ ARR (condition : conversion Free → Build atteint 5-10 % et taux de churn mensuel reste sous 5 %)
* **Mandate conversion** — 5-10 % of Build → Mandate = 25-50 pre-educated prospects/year (condition : module library prompts P3 shipped et utilisés activement par les pilotes)
* **Mandate retention cible** — **objectif 60-80 % de Mandate clients keep Build post-mandate** via consulting bundle key. Cible ambitieuse, non garantie. Conditions de succès :
  * Build doit prouver sa **valeur autonome** durant le mandat (pas seulement support des séances animées par Alex)
  * La **mécanique anti-drift** (`/artefact-fond-1` etc., sentinelles v1) doit devenir indispensable au quotidien du pilote
  * Si ces conditions ne sont pas remplies, prévoir un **plan de repli** : retainer stratégique 2-5 K$/mois pour 4 h/mois Alex (voir Section 13 question 7), ou autonomie complète sans Build (le client a internalisé la méthodologie en Phase 1)

---

## 2. Niching: GTM Operating System Builder

The MCP builds a **GTM Operating System** — sales, marketing, RevOps, customer success. It is applicable to other functions but the IP, the skills, and the brand are GTM. This is intentional and aligned with:

* **Artefact Formula** — 4 pillars of revenue intelligence, 22-workshop portfolio
* **CRO app** — pipeline intelligence, ICP scoring, RFM, signal architecture, blueprint workshops
* **Synapse / OS Synapse** — internal proof of the methodology applied to Artefact's own GTM

**Why GTM and not « anything »:**

* Generic « AI methodology coach » competes with every consulting firm's blog
* « GTM Operating System » competes with point tools (Gong, Clari, 6sense), but with a different shape — they execute, we orchestrate the methodology that orchestrates them
* Artefact's IP is specifically GTM (SPICED, ICP scoring, RFM, pipeline gates, signal layers)
* The vocabulary, examples, and reference clients are all GTM-flavored

### Adjacent functions reachable later

The same architecture works for Operations, Service, and Direction — but that's Phase 5+, not the launch. Stay narrow.

---

## 3. Pricing Model: 4 SKUs

| SKU | Price | What it includes |
|---|---|---|
| **Free** | 0 $ | Methodology read-only · auto-diagnostic (« you're at FOND-3, next SKL-1 ») · second brain guides (PARA / Tiago Forte) · CLAUDE.md scaffold · archetype decision tree · glossary 20 terms |
| **Build solo** | 200 $/mo | Everything Free + skill/sentinelle scaffolds · module prompts (`/artefact-fond-1`, etc.) · dashboard templates · cost estimator · simple v1 sentinelle (skill usage + metacontext freshness) · Notion DB templates (Roadmap / PRDs / Changelog) |
| **Build team** | 500 $/mo (3-5 seats) | Build solo + multi-seat + shared library + collective gate checks |
| **Mandate** | 30-80 K$ | Build + Alex (animation, departmental interviews, custom Cat 1 skills, Cat 2 advanced sentinelles, sponsor coaching) |

### Cat 2 hybrid

The « Cat 2 OS Synapse » skills (sentinelle, logging, silent failure detection, metacontext refresh, cost monitor, etc.) are split:

* **Simple v1 versions** in Build — useful, proves the value, but not the depth that justifies a Mandate
* **Advanced versions** (cross-CRM BI, predictive sentinelles, learning loop) — Mandate-only

This « teaser, then upgrade » pattern is what creates Build → Mandate pull.

### Build × Mandate stacks (not alternatives)

During an active Mandate, Alex generates a license key tied to mandate duration via the admin tool (P2). The client gets Build comp'd into the consulting price, no separate billing, no friction. **The client uses Build during the mandate to do « homework » between sessions.**

At T-7 days from license expiry, Lemon Squeezy sends an automated email: « your Build access expires, keep it active at 200 $/mo (solo) or 500 $/mo (team). »

**Cible de conversion : 60-80 %** (objectif ambitieux, pas garantie actuarielle). Le client a vécu la valeur, le coût marginal est faible vs ce qu'il vient de payer. Trois sorties valides : Build retention (60-80 % cible), retainer stratégique 2-5 K$/mo (alternative pour ceux qui valorisent l'expertise > outils), autonomie complète (succès Co-Build). Voir Section 11.3 garde-fou pro-SaaS pour le détail. **Anti-pattern :** ne pas pousser Build aux clients qui sortent en autonomie complète — c'est le cas idéal du Co-Build, pas un échec à compenser.

---

## 4. Architecture

### 4.1 Tech stack

* **Language:** Python 3.11+
* **MCP framework:** FastMCP 2.x
* **Distribution:** PyPI package `artefact-mcp` (single package, two faces — Revenue Intelligence + GTM OS Builder)
* **Licensing:** Lemon Squeezy MoR (license keys API, subscription webhooks, customer portal)
* **State:** Supabase (Synapse internal ops project, not CRO) for usage tracking, audit logs, anonymized diagnostic data (P4)
* **Cache:** local filesystem + 5-min in-memory for license validation

### 4.2 Authentication and licensing

```
Free tools     → no key required (100% local, no validation call)
Build tools    → @requires_license("build") decorator
                  ↓
                  Lemon Squeezy License Keys API
                  + 5-min local cache
                  + Supabase Synapse for usage tracking (separate from validation)
Mandate tools  → @requires_license("mandate") decorator
                  ↓
                  Same path, different tier check
```

* Free tools never make a network call for validation — privacy-first, works offline
* Build/Mandate tools validate via Lemon Squeezy with short-cache to avoid rate limits
* Dev bypass key in repo for local development (already exists from v1 scaffold)

### 4.3 Multi-tenant model

Each subscriber's CLAUDE.md scaffold, Notion DB template URLs, and audit logs are tied to their license key. Build team has a shared workspace pointer (managed by team owner) that propagates to all seats.

### 4.4 Server structure

```
artefact-mcp/
  pyproject.toml
  README.md
  src/
    artefact_mcp/
      __init__.py
      server.py              # FastMCP server entrypoint
      config.py
      licensing/
        __init__.py
        lemon_squeezy.py     # License Keys API client + cache
        decorators.py        # @requires_license("build" | "mandate")
        usage_tracker.py     # Supabase Synapse usage logger
      tools/
        free/
          auto_diagnose.py
          generate_claude_md.py
          archetype_decision.py
          gate_check.py
        build/
          skill_scaffold.py
          sentinelle_scaffold.py
          module_prompts.py    # /artefact-fond-1 etc.
          notion_templates.py
          cost_estimator.py
        mandate/
          # v1 RevenueIntelligence tools live here:
          analyze_deal.py
          score_pipeline.py
          identify_at_risk_deals.py
          qualify_prospect.py
          run_rfm_analysis.py
          audit_revenue_health.py
          suggest_next_actions.py
      methodology/
        spiced.py
        icp_model.py
        rfm_engine.py
        maturity.py
        artefact_formula.py
        five_pillars.py        # NEW v2
        seven_capabilities.py  # NEW v2
        archetypes.py          # NEW v2 (A/B/C/D)
      resources/
        free/                  # methodology read-only
        build/                 # templates, scaffolds
        mandate/               # advanced playbooks
  tests/
```

---

## 5. Tools by Tier

### 5.1 Free tier (P1)

| Tool | Description | Output |
|---|---|---|
| `auto_diagnose` | Scans the user's repo for FOND-* / SKL-* / SNT-* signals and returns « you're at FOND-3, next SKL-1 » | JSON: current level + next module + missing prerequisites |
| `generate_claude_md` | Generates a CLAUDE.md scaffold with 5 obligatory sections, given basic inputs (pilote, sponsor, function, 3 KPIs) | `CLAUDE.md` text + project MD links |
| `archetype_decision` | Walks the 5 questions of the decision tree to identify archetype A/B/C/D | Recommended archetype + stack + 3 trade-offs |
| `gate_check` | Verifies QA gate criteria for Sprint 1→2 / Sprint 2→3 / Sprint 3→4 against repo state | Pass/fail per gate + missing items |
| `module_prompt_free` | Returns the « what is FOND-1 » read-only briefing (read methodology, don't execute) | Module brief + facilitation flow + QA gate |

### 5.2 Build tier (P2-P3)

| Tool | Description | Output |
|---|---|---|
| `skill_scaffold` | Generates a `SKILL.md` scaffold (frontmatter + steps + test cases) for a Cat 1 or Cat 3 skill | `SKILL.md` + 1 example execution |
| `sentinelle_scaffold` | Generates a v1 sentinelle (skill usage + metacontext freshness) with systemd timer or cron | Python script + service file + Notion alert template |
| `module_prompt_build` | Active module prompts: `/artefact-fond-1` runs FOND-1 facilitation flow live, `/artefact-skl-1` runs SKL-1, etc. | Step-by-step facilitation with gate check |
| `notion_templates` | Provisions Roadmap + PRDs + Changelog DBs in user's Notion workspace via OAuth | Notion DB IDs + first Epic stub |
| `cost_estimator` | Estimates monthly cost (license + tokens + infra) for the chosen archetype + skill catalog size | Cost breakdown + comparison vs alternatives |
| `dashboard_template` | Generates dashboard HTML/Vercel scaffolds (santé sponsor, cost monitor, usage skills) | Repo + Vercel deploy URL |
| `gate_check_team` | (Build team only) Aggregates gate checks across all team seats | Team-level gate state + dependencies |

### 5.3 Mandate tier (P2-P3)

These are the v1 Revenue Intelligence tools, repositioned as Mandate-only advanced. Same scope as v1 sections 4.1-4.7:

| Tool | Description |
|---|---|
| `analyze_deal` | SPICED deal intelligence (Section 4.1 of v1) |
| `score_pipeline` | Pipeline health assessment (Section 4.2 of v1) |
| `identify_at_risk_deals` | Deal risk flagging (Section 4.3 of v1) |
| `qualify_prospect` | 14.5-point ICP scoring (Section 4.4 of v1) |
| `suggest_next_actions` | AI-powered next best actions (Section 4.5 of v1) |
| `run_rfm_analysis` | RFM segmentation + ICP pattern extraction (Section 4.6 of v1) |
| `audit_revenue_health` | 4-pillar maturity assessment (Section 4.7 of v1) |

These tools require HubSpot connection (Private App token in Build, OAuth in Mandate) and access to advanced Cat 2 sentinelles. They are **not** in the Build tier because they're CRO-app-grade — selling them at 200 $/mo would erode Mandate pricing.

---

## 6. Resources by Tier

### Free
* `artefact://methodology/five-pillars`
* `artefact://methodology/seven-capabilities`
* `artefact://methodology/archetypes`
* `artefact://methodology/four-modes`
* `artefact://methodology/spiced` (read-only)
* `artefact://methodology/icp-model` (read-only)
* `artefact://methodology/rfm-segments` (read-only)
* `artefact://methodology/glossary-20-terms`
* `artefact://templates/claude-md-scaffold`
* `artefact://templates/decision-tree-infra`

### Build
* All Free resources +
* `artefact://templates/skill-scaffold`
* `artefact://templates/sentinelle-v1`
* `artefact://templates/notion-roadmap-db`
* `artefact://templates/notion-prds-db`
* `artefact://templates/notion-changelog-db`
* `artefact://templates/dashboard-sponsor`
* `artefact://templates/dashboard-cost`
* `artefact://playbooks/module-fond-1`
* `artefact://playbooks/module-skl-1`
* `artefact://playbooks/module-snt-1`
* `artefact://playbooks/module-poc-1` to `poc-4`
* `artefact://playbooks/module-diy-1` to `diy-3`

### Mandate
* All Build resources +
* `artefact://methodology/maturity-levels` (full)
* `artefact://methodology/seven-capabilities-advanced`
* `artefact://config/icp-exclusions` (Artefact's anti-ICP list)
* `artefact://playbooks/cat2-advanced-sentinelles`
* `artefact://playbooks/learning-loop`
* `artefact://playbooks/handoff-roadmap`

---

## 7. Phase Plan (P1-P4)

### P1 — Free tier MVP (2-4 weeks)

**Goal:** Ship the methodology coach that drives lead generation.

* `auto_diagnose`, `generate_claude_md`, `archetype_decision`, `gate_check`, `module_prompt_free`
* Free resources (5 pillars, 7 capabilities, archetypes, modes, glossary, scaffolds, decision tree)
* PyPI publish, MCP registry listing, Smithery deploy
* Distribution playbook (Tier 1 directories — see `mcp-directory-optimization-playbook.md`)
* No license validation (Free tier = no network call)

**Deliverable:** Anyone can install `pip install artefact-mcp`, point Claude/ChatGPT/Gemini at it, and get a methodology coach for their GTM org for free.

### P2 — Build solo (4-8 weeks)

**Goal:** Ship the subscription that converts Free users.

* All Free tools +
* Build tools: `skill_scaffold`, `sentinelle_scaffold`, `module_prompt_build`, `notion_templates`, `cost_estimator`, `dashboard_template`
* `@requires_license("build")` decorator + Lemon Squeezy integration
* Lemon Squeezy storefront live, Build solo plan at 200 $/mo, dev bypass key in repo
* Customer portal (subscription management, license key reissue, plan upgrade)
* First Mandate-only tools shipped under `@requires_license("mandate")` (not yet sold separately, only via consulting bundle key)

**Deliverable:** Anyone can subscribe to Build solo, validate their license key, and get the full GTM OS scaffolder.

### P3 — Build team + module library prompts (8-12 weeks)

**Goal:** Ship the team tier and the killer feature that makes Build sticky during a mandate.

* All Build solo tools +
* Multi-seat: Build team plan (500 $/mo for 3-5 seats), shared library, `gate_check_team`
* Full module library prompts: `/artefact-fond-1` through `/artefact-ext-5` (active facilitation prompts that walk the user through each module)
* P3 is the priority — without active module prompts, Build is just a scaffolder. With them, it's a learning engine for active mandate pilotes.
* All Mandate-only tools complete and tested (analyze_deal, score_pipeline, etc. — the v1 scope)
* Consulting bundle key admin tool for Alex to mint license keys tied to mandate duration

**Deliverable:** A Bixi-class Co-Build pilot can install Build, run `/artefact-fond-1` between sessions, and arrive at the next session with the module fully bouclé. Alex's animation time drops 30-40%.

### P4 — Sentinelles, dashboards, learning loop (later)

**Goal:** Close the product loop with anonymized aggregate intelligence.

* User-side sentinelles running locally (skill usage, metacontext drift, cost anomalies)
* Cross-tenant anonymized diagnostic — « 73% of Free users at FOND-3 fail SKL-1 because of vault setup »
* Dashboard templates (Vercel deploy from MCP)
* Cat 2 advanced sentinelles for Mandate clients (cross-CRM BI, predictive)
* Webhook entrant patterns (formulaire HubSpot → trigger skill) for the INT-6 module

**Deliverable:** A self-improving product with telemetry that informs Artefact's next mandate offerings.

---

## 8. Existing Asset Inventory

Inherited from v1 — most assets remain reusable, with two repositioning shifts:

* **HubSpot-specific assets** are now Mandate-only (not Build)
* **Methodology assets** become the core of Free + Build

| Asset class | Location | Reuse for v2 |
|---|---|---|
| Edge Functions (Supabase/Deno) | `/tmp/artefact-grow/supabase/functions/` | Mandate tools (HubSpot sync, ICP push, persona, pipeline, SPICED, intelligence-ai-assistant) |
| Frontend service layer | `/tmp/artefact-grow/src/lib/hubspot.ts` | Mandate tools |
| RFM Python engine | `scripts/rfm-analysis/` | Mandate tools (run_rfm_analysis) |
| Methodology skills | `~/.claude/skills/discovery-analysis`, `icp-qualification`, `icp-workshop`, `rfm-analysis`, `artefact-formula`, `gtm-discovery-workshop`, `workshop-frameworks` | **Critical** — these become MCP resources for Free + Build |
| MOS template | `projects/systeme-operatoire-ia-template/` | **Critical for v2** — kit-fondation, modes, qa-gates, modules become MCP resources |
| Architecture agnostique | `projects/systeme-operatoire-ia-template/architecture-agnostique.md` | Free resource (5 piliers, 7 capacités, 4 archétypes) |
| Database schema | Supabase CRO app | Mandate tools (HubSpot mirroring) |
| Synapse Supabase | OVH Beauharnois | License usage tracking, audit logs (separate from CRO) |

For full v1 asset inventory by file, see superseded `mcp-revenue-intelligence-server-scope.md` Section 2.

---

## 9. Build vs Reuse Assessment

### 9.1 Net new for v2

| Component | Effort | Status |
|---|---|---|
| Lemon Squeezy License Keys integration | LOW | New (LS account exists) |
| `@requires_license` decorator | LOW | Pattern is standard |
| Free tier tools (`auto_diagnose`, `generate_claude_md`, `archetype_decision`, `gate_check`) | MEDIUM | Methodology scaffolds exist in MOS template; codification is new |
| Build tier scaffolders (`skill_scaffold`, `sentinelle_scaffold`, `notion_templates`, `dashboard_template`) | HIGH | Templates exist, MCP packaging is new |
| Module library prompts (`/artefact-fond-1` etc.) | HIGH | The 33 modules exist (10 written, 23 stubed) — codification into active prompts is the work |
| Multi-seat Build team plan | MEDIUM | Lemon Squeezy supports it; UX is the work |
| Consulting bundle key admin tool | LOW | Trivial admin endpoint that mints LS license keys with custom duration |
| Cross-tenant diagnostic (P4) | HIGH | Privacy-first design required, anonymization layer |

### 9.2 Reuse from v1

| Component | Effort to port to v2 |
|---|---|
| FastMCP scaffold | Direct |
| Auth model (private app token) | Direct (Mandate tier only) |
| HubSpot client (Python + TypeScript) | Direct (Mandate tier only) |
| RFM scoring engine | Direct (Mandate tier only) |
| ICP scoring 14.5-point model | Direct (Mandate tier only) |
| SPICED framework | Direct (Mandate tier only) |
| Pipeline health logic | Direct (Mandate tier only) |
| Caching layer | Direct |

### 9.3 Estimated effort by phase

| Phase | Effort | Calendar |
|---|---|---|
| P1 — Free MVP | MEDIUM | 2-4 weeks |
| P2 — Build solo + LS integration | HIGH | 4-8 weeks |
| P3 — Build team + module library prompts + Mandate tools | HIGH | 8-12 weeks |
| P4 — Sentinelles + dashboards + learning loop | HIGH | TBD (2026-Q4 / 2027-Q1) |

Total elapsed: **3-6 months** to commercial launch (P1+P2+P3).

### 9.4 Maintenance budget — règle du 20 %

**Sous-estimation classique des firmes consulting qui se lancent en SaaS :** négliger le coût de maintenance ongoing. Une firme de 5-7 personnes peut sous-estimer le travail récurrent (dépendances, failles de sécurité, support client, évolution infra, refactor).

**Règle 20 %** : allouer 20 % du temps de développement à la maintenance dès le P2 commercial launch. Concrètement :

* P1 (4 sem dev) → 0,8 sem/an de maintenance dédiée à partir du shipping
* P2 (8 sem dev) → 1,6 sem/an cumulé
* P3 (12 sem dev) → 2,4 sem/an cumulé
* **Total à 6 mois post-launch :** ~5 sem/an de maintenance allouée explicitement, soit ~10 % du temps d'un dev équivalent temps plein

Cette ligne budgétaire doit apparaître dans le P&L produit, pas être absorbée par « le temps libre » du dev. Sinon le produit accumule la dette technique et plante dans 12-18 mois.

**Architecture defensive :** privilégier serverless / managed (Vercel, Supabase managed, Lemon Squeezy hosted) plutôt que self-managed. Réduit la charge ops récurrente.

---

## 10. Competitive Landscape

### 10.1 Pas de compétiteur direct au scope v2 — mais des compétiteurs indirects sérieux

**Compétiteur direct = personne** ne combine méthodologie GTM + scaffold de système opératoire + multi-LLM via MCP. La niche v2 est, à ce jour, vide.

**Compétiteurs indirects = nombreux**, et c'est eux que le client compare réellement à Artefact :

| Compétiteur indirect | Ce qu'ils vendent | Pourquoi le client peut nous préférer | Pourquoi le client peut les préférer |
|---|---|---|---|
| **Firmes RevOps consulting** (Pavilion, RevOps Co-op, Champify) | Méthodologie + animation humaine | Notre méthodologie est codée, pas juste documentée. Réplicable par les pilotes seuls via Build. | Marque établie, communauté, événements, formation par les pairs. |
| **Plateformes coaching commercial** (Gong, Clari, Salesloft, Outreach) | Outils + méthodologies intégrées (signaux, recommandations) | On orchestre la méthodologie qui orchestre Gong/Clari, pas une alternative. Complémentaire. | Déjà déployés, intégrations matures, contrats existants. |
| **GTM Tech stack consultancies** (Winning by Design, Scratchpad, Modern Sales Pros) | Méthodologie SaaS-flavored + advisory | Multi-LLM, pas de lock-in vendeur, Loi 25 souveraine. | Réseau de pairs, certifications reconnues, séminaires. |
| **Templates marketplaces Notion / Coda / Obsidian** | Templates GTM (CRM Notion, OS marketing Notion) à 50-500 $ | Live méthodologie active vs templates statiques + scaffolds adaptés au contexte. | Beaucoup moins cher (500 $ une fois vs 200 $/mois). |
| **Operational excellence consulting** (Boston Consulting, McKinsey RevOps practices) | Diagnostic + roadmap stratégique | Échelle PME 1.6-70 M$ (pas le cœur de cible des grands cabinets). | Marque tier-1, accès C-level, capacité de transformation profonde. |

### 10.2 Artefact's position

La méthodologie codée qui orchestre la méthodologie qui orchestre les outils. Moat défendu par :

* **33 modules + 5 piliers + 4 archétypes + QA gates + kit de fondation** déjà rédigés (un CMO ne peut pas répliquer en un weekend)
* **Multi-LLM** via MCP — pas de lock-in vendeur
* **Cat 2 OS Synapse avancé** Mandate-only — IP propriétaire qui justifie le saut Build → Mandate
* **Souveraineté Loi 25** native (archétype A par défaut, OVH Beauharnois, Supabase Canada)

### 10.3 Defensive moves

* **Capturer le vocabulaire** — « GTM Operating System », « Module FOND-1 », « QA gate Sprint 2 → 3 » doivent devenir les termes Artefact dans l'index de recherche
* **Vitesse de ship P1** — les 8 prochaines semaines comptent ; si un compétiteur ship en premier, le slot « methodology MCP » se remplit avec son vocabulaire
* **Open-source partiel du MOS template** — discuter avec PP si un sous-ensemble (les 10 modules déjà rédigés + kit de fondation) devient un open-source comme wedge marketing

---

## 11. Pricing Strategy: Consulting Bundle Key

The single biggest commercial innovation of v2.

### Mechanism

1. Mandate is signed at 30-80 K$ ponctuel
2. At kickoff, Alex generates a **consulting bundle key** via the admin tool
3. The key is a Lemon Squeezy license tied to mandate duration (4-6 sem POC, 4-6 sem DIY, 8-12 sem Co-Build) at Build solo or Build team tier
4. The client receives the key in the kickoff package
5. **No separate billing** — Build access is comp'd into the consulting price
6. The pilote uses Build during the mandate to do « homework » between sessions (`/artefact-fond-1`, etc.)
7. At T-7 days from key expiry, Lemon Squeezy sends an automated email: « your Build access expires, keep it active at 200 $/mo (solo) or 500 $/mo (team). »
8. **Cible de conversion : 60-80 %** (objectif, pas attente actuarielle — voir notes Section 1 Targets et garde-fou pro-SaaS Section 1)

### Why this works

* The client has lived the value for 4-12 weeks — they know what Build does
* The marginal cost (200-500 $/mo) is small vs what they just paid (30-80 K$)
* The risk of *losing* the system feels real (it's their CLAUDE.md, their skills, their sentinelles — Build is the runtime)
* No friction — it's a one-click renewal in the customer portal

### Anti-drift mechanism

Without Build, mandate pilots drift. They forget the discipline (PARA, batched skills, marketplace before 3 shipped), they stop logging in Notion changelog, they don't refresh metacontext. With Build's active module prompts (`/artefact-fond-1` etc.), the MCP keeps the agenda — the pilot can't drift without explicitly skipping a gate.

### Garde-fou pro-SaaS — 3 sorties valides post-mandat

Le mécanisme du consulting bundle key pousse vers la rétention Build. Risque : gonfler les métriques MRR au détriment du service au client. **Un mandat réussi peut légitimement aboutir à un client autonome qui n'a plus besoin de Build** — c'est même le résultat cible en Co-Build, pas un échec.

Trois sorties post-mandat sont valides — pas seulement l'abonnement Build :

| Sortie | Prix | Pour qui | Compte dans la « rétention » ? |
|---|---|---|---|
| **Build retention** | 200/500 $/mo | Clients qui valorisent les outils, templates, sentinelles v1 | ✅ |
| **Retainer stratégique** | 2-5 K$/mo (4 h/mois Alex) | Clients qui valorisent l'expertise continue plutôt que les outils. Comble le gouffre Build (200) → Mandate (30-80 K$). | ✅ |
| **Autonomie complète** | 0 $ | Clients Co-Build qui ont internalisé la méthodologie en Phase 1. **C'est un succès.** | ❌ (mais souhaitable, 20-40 % attendu) |

**Anti-pattern à proscrire :** pousser Build à un client qui sort en autonomie complète. C'est le résultat idéal du Co-Build, pas une fuite de revenu à compenser.

### Recurring MRR economics — projections révisées

Hypothèses ajustées (cible, pas attente actuarielle) :

* 100 mandats/an
* **40-60 % en Build retention** (ajusté à la baisse vs 70 % initial pour rester réaliste)
* **15-25 % en retainer stratégique** (nouveau revenu)
* **20-40 % en autonomie complète** (souhaitable en Co-Build)

**Calcul :**
* Build retention : 100 × 50 % × 3 K$/an = **150 K$ ARR**
* Retainer stratégique : 100 × 20 % × 36 K$/an (3 K$/mois) = **720 K$ ARR potentiel** (mais avec une charge Alex implicite — pas tous monétisables sans cap d'heures)
* Total prudent post-mandat : **300-500 K$ ARR récurrent** (mix Build + retainer plafonné)

C'est en plus du 240-1200 K$ ARR de Build organique. Total cible 2027 : **1.5-2 M$ ARR** combinés (Build organique + post-mandat retention + retainer plafonné).

---

## 12. Multi-LLM Strategy

MCP is multi-LLM as of April 2026. The product must work in every harness equally well.

### Validated harnesses (April 2026 WebSearch — sources à valider avant deck client)

| Harness | MCP support | Adoption signal |
|---|---|---|
| Claude Desktop / Code / Team / Cowork | Native since Nov 2024 | Anthropic's flagship |
| ChatGPT | Full read/write since Oct 2025 | Plus and Team plans |
| Gemini (CLI, API, Vertex) | Since March 2026 | Google's enterprise push |
| Copilot Studio / M365 / GitHub / Security | Native | Microsoft's standard |
| Cursor, Windsurf, Zed | Native | Developer tools |
| JetBrains AI, Vercel AI SDK, OpenAI Agents SDK | Native | SDK-level |
| Ollama, LM Studio | Native | Local-first |

### Marketing positioning

« Works wherever your team uses AI. » The product is harness-agnostic. The Free tier proves it (no auth, runs anywhere).

### Testing matrix

The QA suite should run against at least: Claude Code, Claude Desktop, Cursor, ChatGPT, Gemini CLI. Each has subtle MCP transport quirks (STDIO vs streamable HTTP, parallel tool calls, parameter validation). The mcp-server-qa skill (`.claude/skills/mcp-server-qa`) covers this — extend it for v2 multi-harness testing.

---

## 13. Open Questions

### Resolved from v1

| v1 question | v2 resolution |
|---|---|
| LLM dependency for SPICED extraction | Return structured context, let the AI client reason. Confirmed. |
| State management between tool calls | Session-scoped cache in FastMCP context. Confirmed. |
| Write operations in Phase 1 | Phase 1 (Free) = read-only. Build = scaffold + write to Notion (with OAuth). Mandate = HubSpot read+write. |
| Pricing model | Resolved: Free + 200 $/mo solo + 500 $/mo team + 30-80 K$ Mandate |
| Free tier vs gated | Resolved: Free is genuinely useful (auto-diagnostic, scaffolds, methodology), not crippled |
| White-label potential | Deferred to Phase 5+. Architecture supports pluggable methodology models, but not a launch concern. |
| CRO app integration | Confirmed complementary. CRO app = visual dashboard. MCP = AI-native coach. Shared scoring logic via shared Supabase or shared Python package (TBD). |

### New for v2

1. **MOS modules to ship as Free resources** — 10 modules are written (FOND-1, SKL-1, SNT-1, POC-1..4, DIY-1..3). Should the 23 stubed modules be visible in Free as « coming soon » placeholders, or hidden until written?
   * **Recommendation:** Visible with status « to be written » + estimated date. Creates anticipation, signals roadmap, and lets Free users vote with a `/request_module` tool.

2. **Lemon Squeezy vs Stripe** — LS is decided, but Stripe via Vercel could compete on integration depth. Worth re-validating?
   * **Recommendation:** Stay LS. MoR removes tax + Loi 25 billing complexity.

3. **Open-source the MOS template** — should `projects/systeme-operatoire-ia-template/` be public on GitHub?
   * **Recommendation:** Discuss with PP. Open-sourcing the 10 written modules + kit-fondation as marketing wedge could drive Free adoption. Cat 2 advanced + the rest of the Mandate IP stays private.

4. **Consulting bundle key duration extension** — what if a mandate runs over (Bixi pattern)? Auto-extend the LS license, or cut off at the original date?
   * **Recommendation:** Auto-extend up to 30 days, then human-in-the-loop for longer.

5. **Anonymized cross-tenant diagnostic (P4) — Loi 25 high risk** *(durci suite cross-review Gemini May 2026)*
   * Le P4 « cross-tenant anonymized diagnostic » est un projet à très haut risque Loi 25. La CAI peut auditer.
   * **Recommandation durcie :** **ÉFVP (Évaluation des Facteurs relatifs à la Vie Privée) requise AVANT la conception P4** — pas avant le ship. Le processus d'anonymisation doit être prouvable (k-anonymity ≥ 5, ou similaire). Consentement explicite et granulaire dans l'EULA Free + Build (pas noyé dans les CGU).
   * **Mention CAI explicit :** documenter qui est le délégué à la protection des données chez Artefact (par défaut Alex jusqu'à délégation), processus de notification incident < 72h, registre des sous-traitants à jour (Anthropic, OpenAI, Google si Gemini, Lemon Squeezy).
   * **Différer P4** jusqu'à : (a) ÉFVP validée, (b) avocat Loi 25 consulté, (c) volume Build atteint 50+ subscribers (sinon le coût compliance dépasse la valeur produit).

6. **Webhook entrant pattern** (INT-6 in MOS) — should the MCP itself receive webhooks, or are those separate Make.com / n8n workflows?
   * **Recommendation:** Separate. MCP is request-response. Webhook handlers live in `scripts/synapse-*` or in client-specific Make scenarios. The MCP can scaffold them but doesn't run them.

7. **Retainer stratégique post-mandat** *(nouveau suite cross-review Gemini May 2026)*
   * Cross-review #2 a noté un trou commercial : entre Build (200-500 $/mo) et Mandate (30-80 K$ ponctuel), il n'y a rien pour les clients qui valorisent l'expertise continue plutôt que les outils.
   * **Proposition :** offrir un retainer 2-5 K$/mo pour 4 h/mois Alex (advisory, coaching, QA système). Cible : 15-25 % des clients post-mandat.
   * **Risque :** charge Alex implicite, plafonner le nombre de retainers actifs (max 8-10 simultanés à 4 h/mois = 32-40 h/mois Alex).
   * **À valider :** prévoir le retainer formellement en Phase 2 commerciale, ou rester en informel ad-hoc tant que la demande n'est pas constatée ? Décision PP + Phil avant Q3 2026.

8. **Single-point-of-failure Alex — Mandate scaling** *(nouveau suite cross-review Gemini May 2026)*
   * Cross-review (les 2) a noté : l'offre Mandate est explicitement « Build + Alex ». Capacité de vente plafonnée par sa disponibilité. Maladie / vacances / départ = risque structurel.
   * **Mitigation court terme :** PP (Code Marketing) déjà co-livre les mandats Bixi + Isothermic. Standardiser la méthodologie d'animation (modules + kit de fondation + qa-gates) suffit à monter à 2 consultants Mandate-capable d'ici Q3 2026.
   * **Mitigation moyen terme :** former 1-2 senior consultants externes (Code Marketing, ou nouveau hire) sur la méthodologie via un programme « Train-the-trainer ». Cible Q4 2026 : 3 consultants Mandate-capable.
   * **Risque résiduel :** la marque reste « Alex Boissonneault / Artefact ». Migration progressive vers « équipe Artefact » dans le marketing Q3-Q4 2026.

9. **Staleness méthodologique** *(nouveau suite cross-review Gemini May 2026)*
   * Cross-review #1 : « Le produit vend une méthodologie figée dans le code. Les stratégies GTM évoluent vite. Si Artefact Formula n'évolue pas, le produit deviendra obsolète. »
   * **Recommandation :** cadence trimestrielle de **revue méthodologique** formelle. Pour chaque module, vérifier :
     * Reste-t-il pertinent vs les pratiques 2026-2027 ?
     * Y a-t-il des patterns clients récurrents qui justifient un nouveau module ?
     * Les références citées (skills Artefact, mémoires, mandats sources) sont-elles à jour ?
   * **Versionning :** chaque module a un champ `version` dans son frontmatter (v1.0 initial → v1.1 patch → v2.0 breaking change). MCP charge la version la plus récente, garde les anciennes accessibles.
   * **Cadence :** Q1, Q2, Q3, Q4 — alignée avec le calendrier QBR client. Documentée dans le Notion Roadmap d'Artefact (DB Product Roadmap).

10. **Self-hosted option Mandate-tier** *(nouveau suite cross-review Gemini May 2026)*
    * Cross-review : pour clients régulés (santé, finance, organismes publics) ou très soucieux de la confidentialité GTM, une option « on-premise / VPC » pourrait être différenciante.
    * **À valider :** est-ce dans la roadmap P5+ ?
    * **Recommandation :** différer jusqu'à 1ère demande client explicite. Trop tôt pour un effort produit. Si demandé, l'archétype D (hybride / on-prem) du MOS template couvre déjà la livraison ; reste à packager le MCP en self-hosted (Docker image + manuel d'installation).

---

## References

### MOS template (canonical methodology source)

* [`projects/systeme-operatoire-ia-template/`](../../systeme-operatoire-ia-template/) — root
* [`modes/`](../../systeme-operatoire-ia-template/modes/) — 4 modes (self-serve, poc, diy, co-build)
* [`kit-fondation/`](../../systeme-operatoire-ia-template/kit-fondation/) — 6 distributable assets
* [`modules/`](../../systeme-operatoire-ia-template/modules/) — bibliothèque (10 written, 23 stubs)
* [`qa-gates.md`](../../systeme-operatoire-ia-template/qa-gates.md) — gates inter-sprints
* [`architecture-agnostique.md`](../../systeme-operatoire-ia-template/architecture-agnostique.md) — 4 archetypes detail

### MCP infrastructure

* [Build an MCP Server — Official Docs](https://modelcontextprotocol.io/docs/develop/build-server)
* [FastMCP 2.0 — GitHub](https://github.com/jlowin/fastmcp)
* [Python MCP SDK](https://github.com/modelcontextprotocol/python-sdk)
* [TypeScript MCP SDK](https://github.com/modelcontextprotocol/typescript-sdk)
* [MCP Best Practices](https://mcp-best-practice.github.io/mcp-best-practice/)

### Lemon Squeezy

* [License Keys API](https://docs.lemonsqueezy.com/api/license-keys)
* [Subscription Webhooks](https://docs.lemonsqueezy.com/help/webhooks)
* [Customer Portal](https://docs.lemonsqueezy.com/help/customer-portal)

### Companion documents

* [`mcp-directory-optimization-playbook.md`](./mcp-directory-optimization-playbook.md) — distribution to MCP registries (with Free tier as lead magnet, see v2 update)
* [`mcp-marketplace-intelligence-report-2026.md`](./mcp-marketplace-intelligence-report-2026.md) — ecosystem state (with self-serve angle, see v2 update)
* [`fastmcp-2x-production-guide.md`](./fastmcp-2x-production-guide.md) — production setup (unchanged)
* [`artefact-mcp-server-product-guide.md`](./artefact-mcp-server-product-guide.md) — product guide (refresh in P1)
