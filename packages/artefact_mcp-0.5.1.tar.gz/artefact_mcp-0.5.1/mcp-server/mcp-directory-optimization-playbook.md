# MCP Directory & Marketplace Optimization Playbook
**Date:** February 10, 2026 (v1) — May 5, 2026 (v2 update)
**Server:** Artefact Formula MCP (formerly Artefact Revenue Intelligence MCP)
**Goal:** Maximum discoverability across all MCP directories, registries, and marketplaces

> **v2 update note (May 2026):** the product pivoted from « HubSpot Revenue Intelligence » to « Self-Serve GTM Operating System Builder » with a 4-SKU model (Free / Build solo / Build team / Mandate). The Free tier is the new lead magnet — it changes the distribution strategy substantially. See [`artefact-formula-mcp-scope.md`](./artefact-formula-mcp-scope.md) for the v2 scope, and **section 0 below** for how the Free tier reshapes the playbook.

---

## 0. Free Tier as Lead Magnet (v2 strategy, May 2026)

The single biggest shift from v1 to v2 is that the Free tier is **genuinely useful**, not a crippled demo. This changes the directory submission strategy in three ways.

### 0.1 Why Free changes the game

In v1, distribution served a paid-only product. Every directory listing had to convince a developer to install, configure HubSpot, and pay before they got value. In v2, the funnel is :

```
Directory listing → install (zero auth) → run auto_diagnose → see methodology coach in action
                                                ↓
                          (some users) → subscribe to Build solo (200 $/mo)
                                                ↓
                          (some Build users) → mandate qualification → Mandate (30-80 K$)
                                                ↓
                          (all Mandate clients) → Build retention 60-80% post-mandate
```

The **install-to-value time drops from days to seconds.** A user can `pip install artefact-mcp`, point Claude/ChatGPT/Gemini at it, ask « am I at FOND-3? », and get an answer with no credentials, no signup, no payment. This is the unit economics that make ranking on usage-volume registries (Smithery, mcp.so) actually feasible.

### 0.2 Description rewrites for Free-as-magnet

The description across all directories must **lead with the Free tier value**, not with the paid features. Compare :

* **v1 description (sells the paid layer):** « Methodology-driven revenue intelligence MCP server with RFM analysis, 14.5-point ICP scoring, pipeline health scoring, and HubSpot integration. Embeds proprietary Artefact Formula scoring — not a generic CRUD wrapper. »
* **v2 description (drains the Free funnel):** « Self-serve GTM Operating System builder. Free tier: methodology coach, auto-diagnostic, CLAUDE.md scaffold, archetype decision tree. Paid tiers add skill scaffolds, sentinelles, Notion DBs, HubSpot intelligence. Works in Claude, ChatGPT, Gemini, Copilot, Cursor. »

The v2 description :
* Leads with the **product category** (GTM OS builder)
* Names what's free (4 specific tools) instead of vague « scoring »
* Lists the multi-LLM compatibility — broadens TAM in search results
* Mentions the upgrade path without burying the lede

### 0.3 Keywords reordered

The v1 keyword set (`revenue-intelligence`, `rfm-analysis`, `icp-scoring`, `pipeline-health`, `hubspot`, `crm`, `b2b`) is too narrow for the v2 funnel. The new ordering :

```python
keywords = [
    # Tier 1 — protocol (catch protocol-level searches, mandatory)
    "mcp", "mcp-server", "model-context-protocol",
    # Tier 2 — product category (catch GTM OS searches)
    "gtm-operating-system", "go-to-market", "revenue-operations", "revops",
    # Tier 3 — function (catch coaching/methodology searches that lead to Free)
    "ai-methodology-coach", "claude-md-scaffold", "skill-scaffold",
    "ai-architecture", "second-brain", "para-method",
    # Tier 4 — paid features (capture intent for Build/Mandate tiers)
    "rfm-analysis", "icp-scoring", "pipeline-health", "spiced-methodology",
    # Tier 5 — integrations (Mandate tier)
    "hubspot", "notion", "lemon-squeezy",
    # Tier 6 — ecosystem (broad reach)
    "claude", "chatgpt", "gemini", "copilot", "cursor",
    # Tier 7 — domain
    "b2b", "crm", "ai-tools", "llm-tools", "sales-intelligence",
]
```

The reordering matters because PyPI and other registries use the keyword order as a relevance signal. Lead with what gets you found by Free-tier-curious users, not by Mandate-tier-ready buyers.

### 0.4 Tag/category strategy on registries

| Registry | v1 category | v2 category | Why |
|---|---|---|---|
| Official MCP Registry | `business-intelligence` | `productivity` + tags `gtm`, `methodology`, `coaching` | Productivity has more browsing traffic; BI is too narrow for the Free funnel |
| Smithery | (default) | Tag `coach` + `template-generator` + `gtm` | Smithery rewards usage volume; coaching tools have higher repeat usage than CRM connectors |
| mcp.so | `business-intelligence` | `developer-tools` + `productivity` | mcp.so's call-volume leaderboard rewards tools called 10x/day. A coach gets called multiple times per session; a CRM connector once or twice. |
| Glama | `business` | `productivity` + `templates` | Glama's editorial curation rewards tools with multiple distinct use cases. Free tier has 5 tools that target different user moments. |

### 0.5 README structure for Free magnet

The README is what every directory crawls. It must :

1. **First 200 characters** — name the Free tier explicitly. « Install for free, get a methodology coach in 30 seconds. »
2. **First fold (above the install instructions)** — show 1 GIF of `auto_diagnose` returning a result. No payment friction visible.
3. **Install section** — `pip install artefact-mcp` with zero environment variables required for Free tools
4. **Tools section** — split into 3 columns (Free / Build / Mandate). Free tools listed first with green checkmarks. Build/Mandate listed with subscription badges.
5. **Pricing section** — at the bottom, not the top. Free tier is the lead, not the upsell.

### 0.6 Lemon Squeezy storefront as a parallel funnel

Beyond MCP directories, the Lemon Squeezy storefront (`artefactventures.lemonsqueezy.com` or similar) is a parallel discovery channel. LS surfaces products in their own customer-facing index. Optimize the LS product page with the same keyword strategy — it's a separate SEO surface from PyPI/registries.

### 0.7 Distribution sequencing for v2 launch

Recommended order to maximize the Free-funnel lift :

1. **Week 1** — PyPI publish + GitHub repo public (with the Free GIF in README)
2. **Week 2** — Official MCP Registry (`mcp-publisher publish`) + Smithery deploy
3. **Week 3** — mcp.so + Glama + PulseMCP submission, all with v2 descriptions
4. **Week 4** — Cline Marketplace + awesome-mcp-servers PR
5. **Week 5** — Lemon Squeezy storefront live + Build solo plan launched
6. **Week 6+** — Tier 2/3 directories, depending on traffic data from week 1-5

The first 2 weeks are the critical Free funnel ramp. If `auto_diagnose` calls cross 1,000 in week 2, the Smithery leaderboard kicks in and amplifies. If they don't, debug the description and the install GIF before submitting more directories.

---

## 1. Complete Directory/Registry Master List

### Tier 1 - Must List (Highest Traffic / Authority)

| # | Directory | URL | How to Submit | Ranking Signals | Status |
|---|-----------|-----|---------------|-----------------|--------|
| 1 | **Official MCP Registry** | registry.modelcontextprotocol.io | `mcp-publisher publish` CLI tool | Metadata completeness, health pings every 5s, namespace verification | TODO |
| 2 | **Smithery** | smithery.ai | Deploy via smithery.ai/new + `smithery deploy .` CLI | Usage count (tool calls), leaderboard position (24h rolling), GitHub stars | TODO |
| 3 | **Glama** | glama.ai/mcp/servers | "Add Server" button on site; auto-crawls GitHub | Security score, compatibility score, editorial curation, category filters | TODO |
| 4 | **PulseMCP** | pulsemcp.com/servers | pulsemcp.com/submit (manual) + auto-crawling | Popularity data, security analysis, compatibility analysis, visitor estimates | TODO |
| 5 | **MCP.so** | mcp.so | Create GitHub issue via "Submit" button in navbar | Call ranking (call volume leaderboard), Featured/Latest/Official filters | TODO |
| 6 | **Cline MCP Marketplace** | github.com/cline/mcp-marketplace | GitHub issue with repo URL + 400x400 PNG logo | Community adoption (GitHub stars/forks), developer credibility, README quality | TODO |
| 7 | **awesome-mcp-servers (punkpeye)** | github.com/punkpeye/awesome-mcp-servers | Pull request following CONTRIBUTING.md | Curated by maintainer; claim server flair on Glama after merge | TODO |

### Tier 2 - Should List (Significant Traffic)

| # | Directory | URL | How to Submit |
|---|-----------|-----|---------------|
| 8 | **MCPMarket** | mcpmarket.com | Use the `index` CLI tool to submit GitHub repo; auto-detects MCP compatibility |
| 9 | **LobeHub MCP Marketplace** | lobehub.com/mcp | Submit via their GitHub repo (lobe-chat ecosystem) |
| 10 | **mcpservers.org** | mcpservers.org | mcpservers.org/submit or GitHub issue |
| 11 | **MCP Server Finder** | mcpserverfinder.com | Appears to auto-crawl; contact via site |
| 12 | **Awesome MCP Servers (wong2)** | github.com/wong2/awesome-mcp-servers | Pull request |
| 13 | **mcp-awesome.com** | mcp-awesome.com | Appears to aggregate; submit via contact |
| 14 | **OpenTools Registry** | opentools.com/registry | Task-oriented listing; contact for submission |
| 15 | **MCP-Get** | mcp-get.com | Metrics-driven; submit via their process |

### Tier 3 - Nice to Have (Aggregators / Niche)

| # | Directory | URL | How to Submit |
|---|-----------|-----|---------------|
| 16 | **Mastra MCP Registry Registry** | mastra.ai/mcp-registry-registry | Meta-aggregator (crawls other registries automatically) |
| 17 | **Portkey** | portkey.ai/mcp-servers | Curated list |
| 18 | **MCP360** | mcp360.com | Unified gateway marketplace |
| 19 | **mcpservers.com** | mcpservers.com | Directory listing |
| 20 | **findmcpservers.com** | findmcpservers.com | Directory listing |
| 21 | **AIXPLORIA** | aixploria.com | AI tools directory with MCP section |
| 22 | **mcp-servers-hub (GitHub)** | github.com/apappascs/mcp-servers-hub | Pull request |
| 23 | **best-of-mcp-servers** | github.com/tolkonepiu/best-of-mcp-servers | Auto-ranked weekly from GitHub/package manager metrics |

---

## 2. Official MCP Registry - Full Setup

### server.json (Complete Example for Artefact)

```json
{
  "$schema": "https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json",
  "name": "io.github.alexboissav/artefact-revenue-intelligence",
  "description": "Self-serve GTM Operating System builder. Free tier: methodology coach, auto-diagnostic, CLAUDE.md scaffold, archetype decision tree. Paid tiers add skill scaffolds, sentinelles, Notion DBs, HubSpot intelligence. Works in Claude, ChatGPT, Gemini, Copilot, Cursor.",
  "version": "0.1.0",
  "packages": [
    {
      "registry_type": "pypi",
      "identifier": "artefact-revenue-intelligence-mcp",
      "version": "0.1.0",
      "transport": ["stdio"]
    }
  ],
  "_meta": {
    "io.modelcontextprotocol.registry/publisher-provided": {
      "category": "productivity",
      "tags": ["gtm-operating-system", "methodology-coach", "claude-md-scaffold", "skill-scaffold", "revenue-intelligence", "hubspot", "rfm-analysis", "icp-scoring", "pipeline-health"]
    }
  }
}
```

### Publishing Steps

```bash
# 1. Install mcp-publisher
brew install mcp-publisher

# 2. Initialize server.json in your repo root
cd /path/to/artefact-revenue-intelligence-mcp
mcp-publisher init
# Follow interactive prompts

# 3. Authenticate with GitHub (for io.github.* namespace)
mcp-publisher login github
# Opens browser for OAuth

# 4. Publish
mcp-publisher publish

# 5. Verify
curl "https://registry.modelcontextprotocol.io/v0/servers?search=artefact-revenue-intelligence"
```

### PyPI Validation Requirement
Your PyPI package README MUST contain this exact string (can be in an HTML comment):
```
<!-- mcp-name: io.github.alexboissav/artefact-revenue-intelligence -->
```
The registry fetches `https://pypi.org/pypi/artefact-revenue-intelligence-mcp/json` and validates that `mcp-name: io.github.alexboissav/artefact-revenue-intelligence` appears in the README content.

---

## 3. Smithery Optimization

### smithery.yaml (Place in Repo Root)

```yaml
build:
  dockerBuildPath: ./

startCommand:
  type: stdio
  configSchema:
    type: object
    required:
      - hubspotApiKey
    properties:
      hubspotApiKey:
        type: string
        title: "HubSpot API Key"
        description: "Your HubSpot private app access token for CRM data access"
      companyDomain:
        type: string
        title: "Company Domain"
        description: "Your company domain for context (e.g., artefactventures.com)"
  commandFunction: |
    (config) => ({
      command: 'uvx',
      args: ['artefact-revenue-intelligence-mcp'],
      env: {
        HUBSPOT_API_KEY: config.hubspotApiKey,
        COMPANY_DOMAIN: config.companyDomain || ''
      }
    })
```

### What Affects Smithery Ranking

1. **Usage count** - Number of tool calls in last 24 hours (displayed on leaderboard at smithery.ai/leaderboard)
2. **GitHub stars** - Crawled from your GitHub repo
3. **Description quality** - Used in search results
4. **configSchema completeness** - Well-documented config fields improve user experience and adoption
5. **Deployment reliability** - Servers that start cleanly rank better than those that error

### Smithery Deployment Steps

```bash
# Option A: Via web UI
# 1. Go to smithery.ai/new
# 2. Authenticate with GitHub
# 3. Select your repo
# 4. Configure and deploy

# Option B: Via CLI
npm install -g @smithery/cli
smithery deploy .
```

### Smithery Optimization Tactics
- **Ensure your server starts in under 5 seconds** - slow cold starts kill adoption
- **Provide an `exampleConfig`** in smithery.yaml so users can try immediately
- **Use clear, search-friendly title** - "Artefact Revenue Intelligence" not "artefact-mcp"
- **Document all tools in your README** - Smithery displays tool lists from your server's MCP capabilities
- **Drive initial usage** - Get your own team and early clients using it through Smithery to build the call count

---

## 4. PyPI Optimization

### pyproject.toml Metadata (Optimized for Discovery)

```toml
[project]
name = "artefact-revenue-intelligence-mcp"
description = "Methodology-driven MCP server for revenue intelligence: RFM analysis, 14.5-point ICP scoring, pipeline health scoring, and HubSpot integration"
readme = "README.md"
license = {text = "MIT"}
requires-python = ">=3.10"

keywords = [
    "mcp",
    "mcp-server",
    "model-context-protocol",
    "revenue-intelligence",
    "hubspot",
    "rfm-analysis",
    "icp-scoring",
    "pipeline-health",
    "b2b",
    "crm",
    "ai-tools",
    "llm-tools",
    "claude",
    "sales-intelligence",
    "customer-scoring",
]

classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "Intended Audience :: Financial and Insurance Industry",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
    "Topic :: Office/Business :: Financial",
    "Topic :: Office/Business",
    "Framework :: AsyncIO",
    "Typing :: Typed",
]

[project.urls]
Homepage = "https://github.com/alexboissAV/artefact-revenue-intelligence-mcp"
Documentation = "https://github.com/alexboissAV/artefact-revenue-intelligence-mcp#readme"
Repository = "https://github.com/alexboissAV/artefact-revenue-intelligence-mcp"
Issues = "https://github.com/alexboissAV/artefact-revenue-intelligence-mcp/issues"
Changelog = "https://github.com/alexboissAV/artefact-revenue-intelligence-mcp/blob/main/CHANGELOG.md"
```

### PyPI Keyword Strategy
The keywords above are ordered by search priority:
- **Protocol keywords**: `mcp`, `mcp-server`, `model-context-protocol` (catch protocol-level searches)
- **Function keywords**: `revenue-intelligence`, `rfm-analysis`, `icp-scoring`, `pipeline-health` (catch use-case searches)
- **Integration keywords**: `hubspot`, `crm`, `b2b` (catch tool-specific searches)
- **Ecosystem keywords**: `ai-tools`, `llm-tools`, `claude` (catch AI ecosystem searches)
- **Domain keywords**: `sales-intelligence`, `customer-scoring` (catch business domain searches)

### PyPI Description Optimization
- Keep under 200 characters for search result display
- Lead with differentiator ("Methodology-driven") not generic ("An MCP server for...")
- Include primary use cases in the description line itself
- The long description (README) is what the registry validates for `mcp-name`

---

## 5. GitHub Repository Optimization

### Repository Topics (Settings > Topics)
Add these topics to your GitHub repo:
```
mcp
mcp-server
model-context-protocol
revenue-intelligence
hubspot
rfm-analysis
icp-scoring
pipeline-health
b2b
crm
ai-tools
llm
claude
fastmcp
```

### Repository Description (Settings > About)
```
Revenue intelligence MCP server: RFM analysis, 14.5-point ICP scoring, pipeline health scoring. Embeds Artefact Formula methodology. HubSpot integration.
```

### README.md Structure (Optimized for Directories)

Directories crawl your README. Structure it as follows:

```markdown
# Artefact Revenue Intelligence MCP Server

<!-- mcp-name: io.github.alexboissav/artefact-revenue-intelligence -->

[![MCP](https://img.shields.io/badge/MCP-compatible-blue)](https://modelcontextprotocol.io)
[![PyPI](https://img.shields.io/pypi/v/artefact-revenue-intelligence-mcp)](https://pypi.org/project/artefact-revenue-intelligence-mcp/)
[![Smithery](https://smithery.ai/badge/artefact-revenue-intelligence)](https://smithery.ai/server/artefact-revenue-intelligence)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

> Methodology-driven revenue intelligence for AI agents. Not a generic HubSpot CRUD wrapper.

## What This Does

A Model Context Protocol (MCP) server that gives AI agents access to:
- **RFM Analysis** - Recency, Frequency, Monetary scoring of your customer base
- **ICP Scoring (14.5-point model)** - Score prospects against your ideal customer profile
- **Pipeline Health Scoring** - Identify at-risk deals and revenue leaks
- **HubSpot Integration** - Pull live CRM data for real-time analysis

Built on the [Artefact Formula](https://artefactventures.com) methodology.

## Quick Start

### Install via PyPI
\`\`\`bash
pip install artefact-revenue-intelligence-mcp
\`\`\`

### Install via Smithery
\`\`\`bash
npx @smithery/cli install artefact-revenue-intelligence
\`\`\`

### Claude Desktop Configuration
\`\`\`json
{
  "mcpServers": {
    "artefact-revenue-intelligence": {
      "command": "uvx",
      "args": ["artefact-revenue-intelligence-mcp"],
      "env": {
        "HUBSPOT_API_KEY": "your-key-here"
      }
    }
  }
}
\`\`\`

## Available Tools

| Tool | Description |
|------|-------------|
| `rfm_analyze` | Run RFM analysis on your customer base |
| `icp_score_company` | Score a company against your 14.5-point ICP model |
| `icp_score_batch` | Batch score multiple companies |
| `pipeline_health_check` | Analyze pipeline health and identify at-risk deals |
| `pipeline_velocity` | Calculate deal velocity and conversion metrics |
| `revenue_forecast` | Generate revenue forecast from pipeline data |

## Why This Is Different

Most HubSpot MCP servers are CRUD wrappers — they read/write contacts and deals.

This server **embeds scoring methodology**:
- RFM scoring uses configurable thresholds calibrated to B2B revenue cycles
- ICP scoring weights 14.5 factors across firmographic, technographic, and behavioral signals
- Pipeline health scoring detects 12 specific risk patterns (stalled deals, missing next steps, champion changes)

## Configuration

[... detailed configuration docs ...]

## License

MIT
```

### Key README Optimization Points
1. **`mcp-name` comment at the top** - Required by Official Registry validation
2. **Badges** - MCP compatibility, PyPI version, Smithery listing, license (directories display these)
3. **"Available Tools" table** - Smithery and Glama parse tool names from README
4. **Claude Desktop config example** - Cline marketplace specifically tests that giving an AI just the README allows successful setup
5. **Differentiation section** - "Why This Is Different" helps with editorial curation on Glama and awesome-mcp-servers

### llms-install.md (For Cline Marketplace)
Create an `llms-install.md` file in your repo root with simplified installation instructions. Cline's review process tests whether an AI can install your server from just the README + this file.

```markdown
# Installation Instructions for AI Agents

## Prerequisites
- Python 3.10+
- A HubSpot private app access token

## Install
\`\`\`bash
pip install artefact-revenue-intelligence-mcp
\`\`\`

## Configure
Add to Claude Desktop config (~/.claude/claude_desktop_config.json):
\`\`\`json
{
  "mcpServers": {
    "artefact-revenue-intelligence": {
      "command": "uvx",
      "args": ["artefact-revenue-intelligence-mcp"],
      "env": {
        "HUBSPOT_API_KEY": "<user's HubSpot API key>"
      }
    }
  }
}
\`\`\`

## Verify
After installation, the server exposes these tools: rfm_analyze, icp_score_company, icp_score_batch, pipeline_health_check, pipeline_velocity, revenue_forecast
```

### llms.txt (For GitMCP and AI Agents)
Create an `llms.txt` in your repo root for AI agent context:
```
# Artefact Revenue Intelligence MCP Server

> Methodology-driven revenue intelligence MCP server

## Docs
- [README](https://github.com/alexboissAV/artefact-revenue-intelligence-mcp/blob/main/README.md): Overview and installation
- [Configuration](https://github.com/alexboissAV/artefact-revenue-intelligence-mcp/blob/main/docs/configuration.md): Configuration reference
- [API Reference](https://github.com/alexboissAV/artefact-revenue-intelligence-mcp/blob/main/docs/api.md): Tool reference
```

---

## 6. MCP-Specific SEO / Indexing Patterns

### What Directories Actually Crawl

| Directory | What They Index | Source |
|-----------|----------------|--------|
| **Official Registry** | server.json fields (name, description, version, packages) | Your published server.json |
| **Smithery** | GitHub repo README, tool names from MCP capabilities response, usage metrics | GitHub + runtime introspection |
| **Glama** | GitHub repo (README, code, metadata), security scan results, compatibility | GitHub crawl + automated analysis |
| **PulseMCP** | Auto-crawling + manual submission; enriches with popularity, security, corrections | Multiple sources + manual curation |
| **MCP.so** | GitHub issue submission content + GitHub repo data | GitHub issue + crawl |
| **Cline** | README.md + llms-install.md (tested by AI for installability) | GitHub repo |
| **awesome-mcp-servers** | Your PR description + README one-liner | Manual PR review |
| **best-of-mcp-servers** | GitHub stars, forks, issues, last commit, package downloads | Automated weekly scrape |

### The `instructions` Field in MCP Server Implementation
The MCP protocol's `instructions` field (set in your server's initialization) is used by **AI clients** to understand what your server does. While directories don't directly index this field today, it affects:
- How Claude/other agents describe your server to users
- Whether AI agents recommend your server for a given task
- The quality of tool selection when multiple servers are available

Set it to something search-friendly:
```python
# In your FastMCP server
mcp = FastMCP(
    "Artefact Revenue Intelligence",
    instructions="""Revenue intelligence MCP server with methodology-driven scoring.
    Tools: RFM customer analysis, 14.5-point ICP scoring, pipeline health scoring.
    Integrates with HubSpot CRM. Designed for B2B revenue teams.
    Unlike generic HubSpot wrappers, this server embeds the Artefact Formula
    scoring methodology for actionable revenue intelligence."""
)
```

### Cross-Pollination Strategy
1. **Official Registry** is the canonical source - other registries (PulseMCP, Mastra) pull from it
2. **Smithery** and **Glama** are the two biggest independent marketplaces - list on both
3. **awesome-mcp-servers** PR drives traffic to your Glama listing (maintainer recommends claiming on Glama)
4. **GitHub stars** affect ranking on multiple directories (best-of-mcp-servers auto-ranks by stars)
5. **PyPI downloads** affect the best-of-mcp-servers weekly ranking

---

## 7. Submission Checklist (Execution Order)

### Phase 1: Foundation (Before Any Submissions)
- [ ] Publish package to PyPI with optimized metadata (keywords, classifiers, description)
- [ ] Include `mcp-name: io.github.alexboissav/artefact-revenue-intelligence` in PyPI README
- [ ] Set GitHub repo topics (14 topics listed above)
- [ ] Set GitHub repo description
- [ ] Add badges to README (MCP, PyPI, Smithery, License)
- [ ] Create `llms-install.md` in repo root
- [ ] Create `llms.txt` in repo root
- [ ] Create `smithery.yaml` in repo root
- [ ] Create `server.json` in repo root
- [ ] Design 400x400 PNG logo for Cline submission

### Phase 2: Tier 1 Submissions (Week 1)
- [ ] Publish to Official MCP Registry via `mcp-publisher publish`
- [ ] Deploy to Smithery via `smithery deploy .` or web UI
- [ ] Submit to Glama via "Add Server" button
- [ ] Submit to PulseMCP via pulsemcp.com/submit
- [ ] Submit to MCP.so via GitHub issue
- [ ] Submit to Cline Marketplace via GitHub issue (repo URL + logo)
- [ ] Submit PR to punkpeye/awesome-mcp-servers

### Phase 3: Tier 2 Submissions (Week 2)
- [ ] Submit to MCPMarket via `index` CLI tool
- [ ] Submit to LobeHub marketplace
- [ ] Submit to mcpservers.org
- [ ] Submit to MCP Server Finder
- [ ] Submit PR to wong2/awesome-mcp-servers
- [ ] Submit to OpenTools Registry
- [ ] Submit to MCP-Get

### Phase 4: Ongoing Optimization
- [ ] Monitor Smithery leaderboard position weekly
- [ ] Drive usage through your own team/clients to build call counts
- [ ] Respond to GitHub issues promptly (signals active maintenance)
- [ ] Track PyPI download metrics
- [ ] Earn GitHub stars (include "Star this repo" CTA in docs)
- [ ] Monitor for new directories (the ecosystem is still growing fast)

---

## 8. Differentiation Positioning for Directory Listings

When writing descriptions for each directory, emphasize these differentiators consistently:

**One-liner (under 100 chars):**
> Methodology-driven revenue intelligence: RFM, ICP scoring, pipeline health. HubSpot.

**Short description (under 200 chars):**
> Revenue intelligence MCP server with RFM analysis, 14.5-point ICP scoring, and pipeline health scoring. Embeds Artefact Formula methodology. HubSpot integration.

**Positioning against competition:**
> Unlike generic HubSpot CRUD wrappers, this server embeds proprietary scoring methodology -- RFM thresholds calibrated to B2B revenue cycles, ICP scoring across 14.5 weighted factors, and pipeline health detection for 12 specific risk patterns.

**Category tags to use across all directories:**
`revenue-intelligence`, `hubspot`, `business-intelligence`, `crm`, `sales`, `analytics`

---

## Sources

- [Official MCP Registry Publishing Guide](https://modelcontextprotocol.info/tools/registry/publishing/)
- [Official MCP Registry FAQ](https://modelcontextprotocol.info/tools/registry/faq/)
- [Official MCP Registry GitHub](https://github.com/modelcontextprotocol/registry)
- [Smithery Documentation](https://smithery.ai/docs/build/getting-started)
- [Smithery Leaderboard](https://smithery.ai/leaderboard)
- [Glama MCP Servers](https://glama.ai/mcp/servers)
- [PulseMCP Directory](https://www.pulsemcp.com/servers)
- [PulseMCP Submit](https://www.pulsemcp.com/submit)
- [MCP.so](https://mcp.so/)
- [Cline MCP Marketplace](https://github.com/cline/mcp-marketplace)
- [awesome-mcp-servers (punkpeye)](https://github.com/punkpeye/awesome-mcp-servers)
- [awesome-mcp-servers CONTRIBUTING.md](https://github.com/punkpeye/awesome-mcp-servers/blob/main/CONTRIBUTING.md)
- [MCPMarket Index Tool](https://mcpmarket.com/server/index)
- [LobeHub MCP Marketplace](https://lobehub.com/mcp)
- [mcpservers.org](https://mcpservers.org/)
- [MCP Server Finder](https://www.mcpserverfinder.com/)
- [Glama Blog - Official MCP Registry Requirements](https://glama.ai/blog/2026-01-24-official-mcp-registry-serverjson-requirements)
- [Nordic APIs - 7 MCP Registries](https://nordicapis.com/7-mcp-registries-worth-checking-out/)
- [WorkOS Blog - Smithery AI](https://workos.com/blog/smithery-ai)
- [best-of-mcp-servers (auto-ranked weekly)](https://github.com/tolkonepiu/best-of-mcp-servers)
- [MCP Server Discoverability Discussion](https://github.com/modelcontextprotocol/modelcontextprotocol/issues/561)
- [PyPI Classifiers](https://pypi.org/classifiers/)
- [Python Packaging - pyproject.toml Guide](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/)
