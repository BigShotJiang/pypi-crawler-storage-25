# Artefact Formula MCP — Product Guide

**Product Name:** Artefact Formula MCP
**SKU:** `artefact-mcp` (PyPI) / `artefact-formula` (Smithery, future)
**Status:** Pivoted May 4 2026 — v0.3.x stable (Revenue Intelligence Tools), v0.4.0 (P1) in development
**Owner:** Alex Boissonneault / Artefact Ventures
**Category:** GTM Operating System Builder • AI-Native SaaS
**Repository:** https://github.com/alexboissAV/artefact-mcp-server
**Notion Epic:** [EPIC — Artefact Formula MCP (self-serve GTM OS)](https://www.notion.so/3578ca3ef30a8148ab61ff9e84111965)
**Strategic memory:** `~/.claude/projects/-home-debian-workspace/memory/mcp-server-v2-artefact-formula.md`

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Product Overview](#2-product-overview)
3. [How It Works](#3-how-it-works)
4. [Relationship with CRO App & Notion](#4-relationship-with-cro-app--notion)
5. [Revenue Model & Pricing](#5-revenue-model--pricing)
6. [Technical Architecture](#6-technical-architecture)
7. [Sales Assets & Positioning](#7-sales-assets--positioning)
8. [Distribution Channels](#8-distribution-channels)
9. [Competitive Landscape](#9-competitive-landscape)
10. [Roadmap & Evolution](#10-roadmap--evolution)

---

## 1. Executive Summary

### What It Is

The **Artefact Formula MCP** is a Model Context Protocol server that delivers a complete **GTM Operating System** directly into AI assistants. It evolved (May 2026 pivot) from the original Revenue Intelligence Tools focus toward a broader self-serve methodology product — three tiers from Free architecture coach to Build self-serve to Mandate consulting bundle. The original 3 intelligence tools (`run_rfm`, `qualify`, `score_pipeline_health`) continue to work and are now part of the Build tier.

### Why It Matters

- **Productizes consulting IP at scale:** Methodology delivered as MCP resources, scaffolds, and 22 guided modules — runs 24/7 without consultant capacity constraints
- **Multi-tier revenue:** Free (lead gen + qualif), $200/mo solo and $500/mo team Build (recurring SaaS via Lemon Squeezy), $30-80K Mandate (consulting with Build comp'd)
- **Competitive moat against AI commoditization:** Captures the Artefact Formula GTM standard in code; competitors copy data tools, not embedded methodology
- **Funnel for consulting:** Self-serve users who hit a wall arrive pre-educated to mandate qualif calls (5-10% conversion expected = 25-50 prospects/year)
- **MRR layer post-mandate:** Mandate clients receive a Build consulting bundle key for their engagement; convert to standalone Build subscription at expiration (60-80% conversion expected)
- **Anti-drift co-pilot:** Active mandate clients use Build prompts (`/artefact-fond-1` etc.) between sessions to do their devoirs and stay on agenda — solves the drift observed on Pierre-Luc Bixi Sprint 3 and Alexandre Laroche pré-mandate (4 mai 2026)

### The Differentiation

| What Others Do | What Artefact Formula MCP Does |
|---|---|
| Generic HubSpot CRUD operations | Embedded GTM methodology (5 piliers · 4 archétypes · 22 modules) |
| Read/write contacts and deals | Architecture diagnostic + CLAUDE.md scaffolds + decision trees |
| List pipeline stages | Pipeline health + ICP triangulation + RFM (Build tier) |
| Search companies | Module library prompts that walk the user through a guided learning path |
| No built-in methodology | Artefact Formula methodology is **the product**, not just an add-on |
| One-tier SaaS only | Free coach + Build self-serve + Mandate consulting bundle that stack |

---

## 2. Product Overview

### Core Value Proposition

**"Three-dimensional revenue intelligence. Because demographics alone don't close deals."**

Traditional ICP models stop at firmographics. Artefact triangulates across profile, activity, and momentum to identify revenue-ready prospects.

Instead of booking a discovery call, running a manual RFM analysis in Excel, or waiting for a consultant to score your pipeline, B2B teams can now ask Claude:

- _"Run an RFM analysis on our HubSpot data"_
- _"Qualify this prospect: SaaS company, $5M revenue, 80 employees in Ontario"_
- _"Score our pipeline health and identify bottleneck stages"_

The AI assistant calls the Artefact MCP server, which applies proprietary scoring models and returns structured intelligence — in seconds.

### Three Core Tools

#### 1. **`run_rfm` — RFM Analysis**

**What it does:**
Scores clients based on Recency, Frequency, and Monetary value. Segments them into 11 categories (Champions, Loyal Customers, At Risk, Lost, etc.) and extracts ICP patterns from top performers.

**Industry-specific presets:**
- **B2B Service** (default): Recency thresholds [60, 180, 365, 730 days]
- **B2B SaaS**: Recency thresholds [30, 60, 90, 180 days]
- **B2B Manufacturing**: Recency thresholds [90, 365, 730, 1095 days]

**Returns:**
- Scored client list with RFM codes (e.g., "554" = Champion)
- Segment distribution (% of clients, % of revenue per segment)
- ICP patterns with concentration analysis and lift ratios
- Tier 1/2/3/4 ICP recommendations

**Data sources:**
- Live HubSpot (requires `HUBSPOT_API_KEY` + Pro license)
- Built-in sample data (free tier)

---

#### 2. **`qualify` — ICP Triangulation Framework™**

**What it does:**
Scores prospects across three dimensions to identify revenue-ready opportunities:

- **🏢 Firmographic Fit (Who they are):** Industry, revenue range, employee count, geography — the foundation
- **🎯 Behavioral Fit (What they're doing):** Tech stack adoption, growth signals, content engagement, purchase history — intent indicators
- **📈 Growth Signals (Where they're heading):** Hiring trends, funding rounds, expansion momentum, press mentions — buying power indicators

*Technical implementation: 14.5-point scoring model across Firmographic (5 pts), Behavioral (5 pts), Strategic (4.5 pts).*

**Returns:**
- Total score (0-14.5)
- Tier classification:
  - **Tier 1 (Ideal Fit):** 11+ points → "Prioritize and white-glove"
  - **Tier 2 (Strong Fit):** 8-10.9 points → "Pursue actively"
  - **Tier 3 (Moderate Fit):** 5-7.9 points → "Nurture and educate"
  - **Tier 4 (Poor Fit):** <5 points → "Deprioritize or disqualify"
- Exclusion check (anti-ICP: agencies, B2C, nonprofits, VC/PE, etc.)
- Recommended engagement strategy

**Data sources:**
- HubSpot company ID (fetches from HubSpot API)
- JSON payload (works offline with structured data)

**⚠️ Important:** For accurate **Behavioral Fit** scoring, growth signals (1.5 pts) require external enrichment via tools like Clay, Clearbit, or manual research. HubSpot alone provides firmographic data, tech stack (if tracked), content engagement, and purchase history. See [Data Requirements & Setup](#data-requirements--setup) for full implementation guide.

---

#### 3. **`score_pipeline_health` — Pipeline Health Scoring**

**What it does:**
Analyzes open deals for velocity metrics, stage-to-stage conversion rates, bottleneck identification, and at-risk deal detection.

**Calculates:**
- **Overall health score (0-100)** with letter grade (A-F)
- **Velocity metrics:**
  - Average days per stage
  - Bottleneck stage identification
  - Overall average cycle time
  - Stage conversion rates (e.g., "Lead → Discovery: 65%")
- **At-risk deal detection:**
  - Stalled deals (exceeding 2x average stage duration)
  - Slipping close dates
  - Single-threaded deals (only 1 contact)
  - No recent activity
- **Stage distribution:**
  - Deal count and value by stage
  - Top-heavy vs. bottom-heavy analysis
  - Concentration risk (% of pipeline in top 2 deals)

**Returns:**
- Health grade, metrics, velocity analysis, at-risk deals list, issue flags

**Data sources:**
- Live HubSpot (requires `HUBSPOT_API_KEY` + Pro license)
- Built-in sample data (free tier)

---

### Four Methodology Resources

MCP Resources expose read-only reference data to the AI assistant:

| URI | Description |
|-----|-------------|
| `methodology://scoring-model` | ICP Triangulation Framework technical reference with criteria and thresholds |
| `methodology://tier-definitions` | 4-tier classification system with engagement strategies |
| `methodology://rfm-segments` | 11 RFM segment definitions with scoring scales and actions |
| `methodology://spiced-framework` | SPICED discovery framework (Situation, Pain, Impact, Critical Event, Decision) |

These give the AI contextual knowledge about Artefact methodology without requiring tool calls.

---

### Data Requirements & Setup

To get the most value from the **`qualify` tool** (ICP Triangulation Framework), you need to ensure your HubSpot instance has the right data populated across all three dimensions.

#### **Firmographic Fit (5 pts) — Native HubSpot Data ✅**

These fields are **standard HubSpot properties** and typically auto-populate:

| Scoring Dimension | HubSpot Property | Notes |
|---|---|---|
| **Industry (2 pts)** | `industry` | Standard property, usually set during company creation |
| **Revenue (1.5 pts)** | `annualrevenue` | May need manual entry or enrichment |
| **Employee Count (1 pt)** | `numberofemployees` | Standard property |
| **Geography (0.5 pts)** | `state`, `country` | Standard properties |

**Setup:** Ensure these properties are populated on your HubSpot companies. You can bulk-update via CSV import if needed.

---

#### **Behavioral Fit (5 pts) — Mixed: HubSpot + External Enrichment**

This is where it gets more complex. Some behavioral signals are trackable in HubSpot, while others require external enrichment tools.

##### ✅ **Available in HubSpot (Native or via Workflows)**

| Scoring Dimension | HubSpot Implementation | How to Track |
|---|---|---|
| **Tech Stack (2 pts)** | Custom property: `tech_stack` (multi-select) | Create custom property, populate manually or via form submissions. HubSpot can detect some tools via website tracking (e.g., GTM, HubSpot Tracking Code). For deeper tech stack detection, use Clay or Clearbit enrichment. |
| **Content Engagement (1 pt)** | Engagement score or custom property | Use HubSpot's native engagement tracking: blog page views, email opens/clicks, webinar attendance, gated content downloads. Create a workflow to classify as "active" (5+ engagements/month), "occasional" (1-4), or "none". |
| **Purchase History (0.5 pts)** | Deal stage history or custom property | Check closed-won deal count per company. Create a calculated property: "regular" (3+ deals), "occasional" (1-2 deals), "never" (0 deals). |

##### ⚠️ **Requires External Enrichment (Clay, Clearbit, ZoomInfo, etc.)**

| Scoring Dimension | Why HubSpot Alone Isn't Enough | Recommended Tools |
|---|---|---|
| **Growth Signals (1.5 pts)** | HubSpot doesn't natively track hiring trends, funding rounds, new product launches, expansion signals, or press mentions. | **Clay** (LinkedIn job postings scraper, funding data from Crunchbase), **Clearbit** (company signals API), **LinkedIn Sales Navigator** (hiring alerts), **Crunchbase** (funding data). |

**Growth signals you should track:**
- **Hiring activity:** New job postings on LinkedIn (indicates growth/expansion)
- **Funding rounds:** Recent Series A/B/C funding (indicates budget availability)
- **Product launches:** New product announcements (indicates momentum)
- **Expansion signals:** New office openings, executive hires (C-suite additions)
- **Press mentions:** Media coverage, award wins (indicates market visibility)

**How to implement with Clay:**
1. Create a Clay table with your HubSpot companies
2. Add enrichment columns:
   - "LinkedIn Job Postings" (count active job postings)
   - "Recent Funding" (Crunchbase API lookup)
   - "Recent News Mentions" (Google News API or NewsAPI)
3. Create a "Growth Signals" calculated field that returns an array: `["hiring", "funding"]` if signals detected
4. Push this data back to HubSpot as a custom property: `growth_signals` (multi-select or JSON text field)
5. Use HubSpot workflows to keep it fresh (e.g., re-enrich quarterly)

**Alternative approach (no Clay):**
- Manually research growth signals during discovery calls
- Store in HubSpot custom property: `growth_signals` (multi-select: Hiring, Funding, Product Launch, Expansion, Press Mentions)
- Update via deal notes or qualification forms

---

#### **Strategic Fit (4.5 pts) — Native HubSpot Data ✅**

These are relationship-based signals that your sales team manually tracks:

| Scoring Dimension | HubSpot Property | How to Track |
|---|---|---|
| **Decision Maker Access (2 pts)** | Custom property: `decision_maker_access` | Dropdown: "c_suite", "director", "manager", "indirect", "none". Populate based on contact roles. Create workflow: if deal has contact with title containing "CEO\|CFO\|CRO\|VP", set to "c_suite". |
| **Budget Authority (1.5 pts)** | Custom property: `budget_authority` | Dropdown: "dedicated", "shared", "possible", "none". Ask during discovery: "Do you have a dedicated budget for this initiative?" Populate on deal or company record. |
| **Strategic Alignment (1 pt)** | Custom property: `strategic_alignment` | Dropdown: "strong", "partial", "misaligned". Assess during discovery: Does their GTM strategy align with Artefact's methodology? |

**Setup:** Create these custom properties in HubSpot (Settings > Properties > Company Properties). Add them to your deal qualification form.

---

#### **Quick Setup Checklist**

Before using the `qualify` tool effectively:

- [ ] **Firmographic data populated** (industry, revenue, employees, geography)
- [ ] **Tech stack property created** and populated (manually or via Clay)
- [ ] **Content engagement tracking enabled** (HubSpot workflows scoring engagement)
- [ ] **Purchase history calculated** (deal count per company)
- [ ] **Growth signals enrichment setup** (Clay recommended) OR manual research process
- [ ] **Strategic fit properties created** (decision maker access, budget authority, alignment)
- [ ] **Qualification form updated** to capture strategic fit during discovery

---

#### **Example: Using `qualify` with Full Data**

```json
{
  "company_data": {
    "company_name": "TechCorp Inc.",
    "industry": "Software",
    "annual_revenue": 12000000,
    "employee_count": 85,
    "geography": "Ontario",
    "tech_stack": ["HubSpot", "Google Analytics", "Salesforce"],
    "growth_signals": ["hiring", "funding"],
    "content_engagement": "active",
    "purchase_history": "occasional",
    "decision_maker_access": "c_suite",
    "budget_authority": "dedicated",
    "strategic_alignment": "strong"
  }
}
```

**Result:** This prospect would score **~12.5 / 14.5 points** (Tier 1 - Ideal Fit) with full behavioral and strategic data populated.

**Without growth signals enrichment (no Clay):** Same prospect would score **~11 / 14.5** (still Tier 1, but lower confidence).

---

#### **Pro Tip: Automate with Clay → HubSpot Sync**

**Best practice workflow:**
1. **Clay table:** Import HubSpot companies (weekly sync)
2. **Enrich:** Add LinkedIn job postings, Crunchbase funding, news mentions
3. **Calculate:** Create "growth_signals" field (array of detected signals)
4. **Push to HubSpot:** Update `growth_signals` custom property
5. **Trigger MCP:** AI assistant calls `qualify` with fresh HubSpot data, gets accurate behavioral fit scores

This ensures your ICP scoring is **always based on fresh, enriched data** without manual research.

---

## 3. How It Works

### User Journey

#### 1. **Installation (< 1 minute)**

User adds the MCP server to their AI assistant:

**Claude Desktop (Recommended - Python method):**
```json
{
  "mcpServers": {
    "artefact-revenue": {
      "command": "python3",
      "args": ["-m", "artefact_mcp"],
      "env": {
        "HUBSPOT_API_KEY": "pat-na1-xxxxxxxx"
      }
    }
  }
}
```

**Alternative (uvx method):**
```json
{
  "mcpServers": {
    "artefact-revenue": {
      "command": "uvx",
      "args": ["artefact-mcp"],
      "env": {
        "HUBSPOT_API_KEY": "pat-na1-xxxxxxxx"
      }
    }
  }
}
```

*Note: If using uvx and seeing "Server disconnected" errors, see README Troubleshooting section.*

**Claude Code:**
```bash
claude mcp add artefact-revenue -e HUBSPOT_API_KEY=pat-na1-xxxxxxxx -- uvx artefact-mcp
```

**Cursor / Windsurf:**
Same JSON structure in `.cursor/mcp.json` (Python method recommended).

---

#### 2. **Usage (conversational)**

User asks their AI assistant:

> _"Run an RFM analysis on our HubSpot data and tell me which industries our Champions are in"_

**Behind the scenes:**
1. AI assistant calls `run_rfm(source="hubspot", industry_preset="b2b_service")`
2. MCP server validates license, connects to HubSpot API
3. Fetches all closed-won deals, aggregates by company
4. Applies industry-specific RFM scoring (recency, frequency, monetary percentiles)
5. Segments clients into 11 categories
6. Runs ICP pattern extraction on Champions + Loyal clients
7. Returns structured JSON with scores, segments, patterns, tier recommendations
8. AI assistant interprets results and answers user's question

---

#### 3. **Output (structured intelligence)**

The MCP server returns JSON like:

```json
{
  "analysis_date": "2026-02-11",
  "total_clients": 47,
  "industry_scorer": "b2b_service",
  "segment_distribution": {
    "Champions": { "count": 5, "pct": 10.6, "revenue": 480000, "pct_revenue": 38.2 },
    "Loyal Customers": { "count": 8, "pct": 17.0, "revenue": 320000, "pct_revenue": 25.5 }
  },
  "top_10": [ /* scored clients */ ],
  "icp_patterns": {
    "strong_patterns": [
      { "dimension": "industry", "value": "Software", "concentration": 65, "lift": 2.3 }
    ],
    "tier_recommendations": {
      "tier_1": { "industry": ["Software", "Professional Services"], "size": "51-200", "revenue": "$5M-$20M" }
    }
  }
}
```

The AI assistant synthesizes this into a natural-language answer:

> _"Your Champions (10.6% of clients, generating 38.2% of revenue) are heavily concentrated in Software (65%) with 51-200 employees. This is 2.3x higher than the overall client base, indicating a strong ICP signal. Tier 1 target: Software or Professional Services companies with $5M-$20M revenue and 51-200 employees."_

---

### Technical Flow

```
User (AI Assistant)
       ↓ natural language query
AI Assistant (Claude / Cursor / Windsurf)
       ↓ MCP tool call: run_rfm(source="hubspot")
Artefact MCP Server
       ↓ 1. License validation (ARTEFACT_LICENSE_KEY)
       ↓ 2. HubSpot API client init (HUBSPOT_API_KEY)
       ↓ 3. Fetch closed-won deals
HubSpot API
       ↓ deals, companies, contacts
Artefact MCP Server
       ↓ 4. RFM scoring engine (Python)
       ↓ 5. 11-segment classification
       ↓ 6. ICP pattern extraction
       ↓ 7. Return structured JSON
AI Assistant
       ↓ synthesize natural-language response
User
```

---

## 4. Relationship with CRO App & Notion

### Three Products, One Ecosystem

| Product | What It Is | Who Uses It | Primary Use Case |
|---|---|---|---|
| **Artefact CRO App** (artefact-grow) | Visual SaaS dashboard for revenue teams | B2B revenue teams (CRO, VP Sales, RevOps) | Ongoing revenue optimization, GTM assessments, campaign management, HubSpot sync |
| **Artefact MCP Server** (artefact-mcp) | AI-native API for revenue intelligence tools | Developers, AI power users, consultants | AI-assisted analysis, embedded intelligence, API-first workflows |
| **Notion Workspace** | Project management and delivery hub | Artefact internal team + client stakeholders | Workshop deliverables, client reviews, task tracking, documentation |

---

### How They Relate

#### **Shared IP, Different Interfaces**

The **CRO app** and **MCP server** implement the same underlying methodology:
- Same ICP scoring model (14.5 points)
- Same RFM segmentation logic (11 segments)
- Same pipeline health metrics (velocity, conversion rates)
- Same SPICED framework

**Difference:**
- **CRO app** = visual, interactive dashboard (React + Supabase). Users click, configure, and visualize.
- **MCP server** = API-first, AI-native tool layer (Python + FastMCP). Users ask AI assistants, get structured responses.

---

#### **Complementary Positioning**

| Scenario | Best Tool |
|---|---|
| Client wants a revenue intelligence dashboard to monitor metrics daily | **CRO app** |
| Client wants to integrate revenue intelligence into their AI assistant (Claude, Cursor, custom GPT) | **MCP server** |
| Consultant wants to run ad-hoc RFM analysis during a discovery call | **MCP server** (via Claude Code) |
| Client wants to push ICP tiers and personas to HubSpot, then sync bi-directionally | **CRO app** |
| Developer wants to embed Artefact methodology in their own product | **MCP server** (via Python API or MCP client) |

---

#### **Notion Integration**

**Current state:**
- Notion is the **delivery hub** for Artefact consulting engagements
- Workshop outputs (GTM Discovery PRDs, Blueprint PRDs, ICP scoring models) live in Notion
- Client reviews, weekly scorecards, and deliverable tracking happen in Notion
- The **`weekly-fireflies-sync`** skill syncs Fireflies meeting transcripts to Notion project pages

**Future integration:**
- **MCP server → Notion:** An AI assistant could call the MCP server to generate RFM analysis, then write the results to a Notion database via the Notion MCP
- **CRO app → Notion:** Push completed assessments, ICP models, and campaign briefs to Notion as structured pages
- **Notion → MCP server:** Pull ICP definitions from Notion, use them to customize the `qualify` tool's scoring model

**Key principle:** Notion is the **source of truth for client deliverables**. The MCP server and CRO app are **execution engines** that generate intelligence. Notion captures the output.

---

### Data Flow Example: ICP Scoring Workflow

1. **Workshop (Fireflies):** Client completes ICP Workshop transcript
2. **Skill (`icp-workshop`):** Claude Code analyzes transcript → extracts 14.5-point scoring criteria → generates ICP model
3. **Notion:** ICP model is written to client's Notion project page as a structured PRD
4. **CRO App:** Client or Artefact team logs into CRO app → creates ICP record → syncs to HubSpot (creates custom properties)
5. **HubSpot:** ICP tier and score properties are now on all companies
6. **MCP Server:** Developer or consultant uses `qualify` tool → pulls company from HubSpot → scores against ICP model → returns tier and engagement strategy
7. **AI Assistant (Claude):** Consultant asks _"Which of our open deals are Tier 1 ICPs?"_ → Claude calls `qualify` for each deal's company → returns prioritized list

**Result:** Single ICP model, used across three systems, no manual re-entry.

---

## 5. Revenue Model & Pricing

### Pricing Tiers (revised May 4 2026)

| Tier | Price | License key | What's Included | Target Customer |
|------|-------|-------------|-----------------|----------------|
| **Free** | $0/mo | No | Methodology resources (5 piliers, archetypes, glossaire, taxonomie skills) · auto-diagnostic · CLAUDE.md scaffold · archetype decision tree · second brain guides · 3 intelligence tools with demo data | Lead gen, qualif, sub-1.6M founders, students, freemium trial |
| **Build solo** | $200/mo | Yes (Lemon Squeezy) | All Free + skill scaffolds · sentinelle scaffolds · cost estimator · live HubSpot intelligence (run_rfm, qualify, score_pipeline_health) | PME tech-savvy, fondateurs, solo RevOps managers, individual consultants |
| **Build team** | $500/mo | Yes (Lemon Squeezy, multi-seat 3-5) | All Build solo + 3-5 user seats · multi-seat dashboards · 22 module prompts (`/artefact-fond-1` etc.) | Équipes < 10, mandate clients during engagement, consulting agencies multi-client |
| **Mandate** | $30K-80K | Yes (consulting bundle key, comp'd) | Build team bundle + Alex Boissonneault's animation · entrevues départementales · custom Cat 1 skills · sponsor coaching · Co-Build (8-12 sem) ou DIY hosted (4-6 sem) | $1.6M-$70M revenue, sponsor exécutif engagé, équipes prêtes à co-construire ou consommer |

**Purchase:** https://artefactventures.lemonsqueezy.com (Build solo / Build team)
**Mandate:** Contact alex@artefactventures.com pour qualification

> **Important pivot note:** The previous tiers ($149 Pro, $499 Enterprise) are deprecated. Existing customers will be migrated as of v0.5.0 (P2) ship: $149 Pro → $200 Build solo (50$ premium reflects expanded scope), $499 Enterprise → $500 Build team (functionally equivalent).

---

### Revenue Model

**Subscription SaaS via Lemon Squeezy (Merchant of Record):**
- Monthly recurring revenue (MRR)
- LS handles taxes globally (TPS/TVQ Loi 25 compliant côté facturation)
- License Keys API native (validation built-in)
- Customer portal for cancellations / billing changes
- Webhooks for subscription events (created, cancelled, expired)

**Mandate Consulting Bundle Keys:**
- Alex generates a Build tier license key tied to mandate duration via admin tool (P2)
- Comp'd in mandate price, no separate billing
- 7 days before expiration: automatic email CTA to convert to Build standalone
- Conversion expected: 60-80% (client has lived the value, marginal cost vs the mandate they just paid)

**Rationale:**
- Simple, predictable pricing
- LS handles complexity (taxes, billing, portal, webhooks)
- Aligns with value (methodology + intelligence + guided learning, not query volume)
- Stacking model creates MRR layer post-mandate that didn't exist before

---

### License Validation

**How it works:**
1. User pays via Lemon Squeezy → receives `ARTEFACT_LICENSE_KEY`
2. User sets env var
3. MCP server validates key on each Build tool call via LS License Keys API (50ms round-trip)
4. Cache local 5 min for performance
5. Free tools never check the key (work 100% local)
6. Webhook LS → Supabase Synapse captures subscription events for usage tracking

**Enforcement:**
- Free tier: All Free tools work without a key (`diagnostic_run`, `archetype_decision`, `generate_claude_md`, methodology resources, intelligence tools with `source="sample"`)
- Build tier: Tools decorated with `@requires_license("build")` validate the key before execution
- Mandate consulting bundle: Same as Build, key generated by Alex with custom duration

**License server:** Lemon Squeezy hosts validation. Usage events tracked on Supabase Synapse (ca-central-1, Beauharnois) — license_key_hash + tool_name + timestamp + success.

---

### Monetization Strategy

**Year 1 (2026):** Pivot launch (May), focus on Free tier adoption + Build solo conversion

| Segment | Target | Strategy |
|---|---|---|
| **Free tier users** | 1,000+ in first 6 months | MCP registry listings, HubSpot community, Reddit, Hacker News, Substack newsletter, organic SEO |
| **Build solo conversions** | 50-100 paying customers by end of 2026 | CTA in `diagnostic_run` ("next module is SKL-1, unlock with Build"), in-tool upgrade prompts |
| **Build team accounts** | 10-15 by Q4 2026 | Outbound to consulting agencies + active mandate clients post-handoff |
| **Mandate prospects via Build** | 5-10 mandates won via self-serve funnel | Trigger analytics surface qualified accounts (≥3 active users, custom skill request, etc.) |

**MRR Goal:**
- End of 2026: $15K-$25K MRR (75 Build solo @ $200 + 5 Build team @ $500 ≈ $17.5K)
- End of 2027: $80K-$120K MRR (400 Build solo + 30 Build team + 10 mandates/year via funnel)

**High-leverage plays:**
1. **MCP registry SEO:** Rank #1 for "GTM operating system MCP", "CLAUDE.md generator MCP", "AI methodology framework"
2. **HubSpot Marketplace:** List as Partner App once OAuth ships
3. **YouTube tutorials:** "Build a GTM operating system in 30 minutes with Claude" (P3 launch hook)
4. **Substack + LinkedIn:** Methodology essays driving Free tier adoption
5. **Mandate flywheel:** Every mandate creates a Build standalone customer post-handoff (~80% conversion)

---

### Competitive Pricing

| Product | Price | Scope |
|---|---|---|
| **HubSpot Official MCP** | Free | CRUD only, no intelligence, no methodology |
| **CData HubSpot MCP** | $299/mo | SQL-based access, no methodology |
| **Zapier MCP** | Free / usage-based | Workflow automation, different use case |
| **Generic AI consultant via ChatGPT** | $20/mo (ChatGPT Plus) | Conversational advice, no scaffolds, no diagnostic, no module path |
| **Artefact Formula MCP Free** | $0 | Architecture coach + diagnostic + CLAUDE.md scaffold + methodology |
| **Artefact Formula MCP Build solo** | $200/mo | All Free + scaffolds + intelligence tools |
| **Artefact Formula MCP Build team** | $500/mo | Build solo + multi-seat + module library prompts |

**Positioning:** "Free coach beats $20/mo ChatGPT for GTM. $200/mo Build beats $300+/mo data-only competitors because it's a complete operating system, not just data access."

---

## 6. Technical Architecture

### Stack

| Layer | Technology |
|---|---|
| **Language** | Python 3.10+ |
| **Framework** | FastMCP 2.x (official MCP SDK wrapper) |
| **HTTP Client** | `httpx` (async-ready for future) |
| **Packaging** | Hatchling (modern Python build backend) |
| **Distribution** | PyPI (`pip install artefact-mcp`) |
| **Transport** | STDIO (Claude Desktop / Claude Code / Cursor / Windsurf) |
| **License Validation** | Offline validation (hardcoded keys for MVP) |
| **Testing** | `pytest` + `pytest-asyncio` + `respx` (HTTP mocking) |

---

### Project Structure

```
artefact-mcp-server/
├── pyproject.toml              # Hatchling project definition
├── README.md                   # Product README
├── LICENSE                     # BSL 1.1
├── smithery.yaml               # Smithery registry metadata
├── server.json                 # MCP server descriptor
├── llms.txt                    # LLM context file
├── llms-install.md             # Installation guide for LLMs
├── src/
│   └── artefact_mcp/
│       ├── __init__.py
│       ├── server.py           # FastMCP server entrypoint
│       ├── core/
│       │   ├── rfm_scorer.py   # RFM scoring engine
│       │   ├── segmenter.py    # 11-segment classifier
│       │   ├── icp_scorer.py   # 14.5-point ICP model
│       │   ├── hubspot_client.py # HubSpot API client
│       │   └── license.py      # License validation
│       ├── tools/
│       │   ├── rfm.py          # run_rfm tool
│       │   ├── icp.py          # qualify tool
│       │   └── pipeline.py     # score_pipeline_health tool
│       └── resources/
│           └── methodology.py  # MCP resources (scoring model, tiers, RFM segments, SPICED)
└── tests/
    ├── test_rfm.py
    ├── test_icp.py
    └── test_pipeline.py
```

---

### Key Modules

#### **`server.py` — FastMCP Server**

Defines the MCP server with 3 tools and 4 resources. Handles:
- License validation on startup
- Environment variable loading (`HUBSPOT_API_KEY`, `ARTEFACT_LICENSE_KEY`)
- Tool routing
- Resource serving
- Error handling

---

#### **`core/rfm_scorer.py` — RFM Scoring Engine**

Pure Python implementation of RFM scoring logic:
- Calculates recency, frequency, monetary percentiles
- Applies industry-specific thresholds (B2B service, SaaS, manufacturing)
- Generates R/F/M scores (1-5 scale)
- No pandas, no numpy — lightweight and fast

**Reused from:** `scripts/rfm-analysis/scoring/rfm_scorer.py` (existing codebase)

---

#### **`core/segmenter.py` — 11-Segment Classifier**

Classifies clients into segments based on RFM scores:

| Segment | RFM Pattern | Action |
|---|---|---|
| Champions | R:5, F:5, M:4-5 | VIP treatment, exclusives |
| Loyal Customers | R:4-5, F:4-5, M:3-5 | Upsell, cross-sell |
| Potential Loyalists | R:4-5, F:2-3, M:3-4 | Nurture, build frequency |
| New Customers | R:5, F:1, M:1-3 | Onboard, engage quickly |
| At Risk | R:2-3, F:2-3, M:3-4 | Re-engagement campaign |
| Can't Lose Them | R:1-2, F:5, M:5 | Win-back urgently |
| Lost | R:1, F:1-2, M:1-2 | Archive or low-touch |

Also includes **`ICPAnalyzer`** for pattern extraction (lift ratios, concentration analysis, tier recommendations).

**Reused from:** `scripts/rfm-analysis/scoring/segmenter.py`

---

#### **`core/icp_scorer.py` — 14.5-Point ICP Model**

Implements the Artefact ICP scoring model:

**Firmographic Fit (5 pts):**
- Industry match (2 pts): Exact match industries (Software, SaaS, Professional Services, Manufacturing, Healthcare, FinTech)
- Revenue range (1.5 pts): $1.6M-$70M sweet spot
- Employee count (1 pt): 10-500 employees
- Geography (0.5 pts): North America (US, Canada)

**Behavioral Fit (5 pts):**
- Tech stack (2 pts): HubSpot active = 2.0, Marketing Automation = 1.5, Basic CRM = 1.0
- Growth signals (1.5 pts): Hiring, funding, new product launches
- Content engagement (1 pt): Active blog readers, webinar attendees, gated content downloaders
- Purchase history (0.5 pts): Repeat buyers = 0.5, first-time = 0.25

**Strategic Fit (4.5 pts):**
- Decision-maker access (2 pts): C-suite = 2.0, Director = 1.5, Manager = 1.0, Indirect = 0.5
- Budget authority (1.5 pts): Dedicated budget = 1.5, Shared = 1.0, Possible = 0.5
- Strategic alignment (1 pt): Strong = 1.0, Partial = 0.5, Misaligned = 0

**Exclusions (disqualification):**
- Agencies, consulting firms (compete with Artefact)
- B2C companies (methodology is B2B-specific)
- Nonprofits (budget constraints)
- VC/PE firms (advisor role, not operator)

**Returns:**
- Gross score (0-14.5)
- Disqualification penalty (if excluded industries)
- Net score
- Tier (1-4)
- Engagement strategy

**Reused from:** `.claude/skills/icp-workshop/SKILL.md` and `.claude/skills/icp-qualification/SKILL.md`

---

#### **`core/hubspot_client.py` — HubSpot API Client**

Thin wrapper around HubSpot API v3:
- Company search
- Deal search (with stage history)
- Contact search
- Batch reads
- Association fetching
- Pagination handling

**Reused from:** `/tmp/artefact-grow/src/lib/hubspot.ts` (TypeScript) → ported to Python

---

#### **`core/license.py` — License Validation**

Validates `ARTEFACT_LICENSE_KEY` on startup:
- Format: `AV-{TIER}-{ID}-{HASH}` (e.g., `AV-PRO-12345-ABCDE`)
- Returns `LicenseInfo` with `valid`, `tier`, `customer_name`, `error`
- Enforces free tier restrictions (sample data only)

**Future:** Online validation via Lemon Squeezy webhook.

---

#### **`tools/rfm.py` — run_rfm Tool**

MCP tool wrapper for `run_rfm_analysis`:
1. Validates license (requires Pro/Enterprise for HubSpot)
2. Inits HubSpot client (if `source="hubspot"`)
3. Calls RFM scorer with industry preset
4. Runs ICP pattern extraction
5. Returns structured JSON

---

#### **`tools/icp.py` — qualify Tool**

MCP tool wrapper for `qualify_prospect`:
1. Accepts HubSpot company ID or JSON payload
2. Fetches company from HubSpot (if ID provided)
3. Calls ICP scorer
4. Checks exclusion list
5. Returns score, tier, engagement strategy

---

#### **`tools/pipeline.py` — score_pipeline_health Tool**

MCP tool wrapper for `score_pipeline`:
1. Validates license
2. Fetches open deals from HubSpot (or uses sample data)
3. Calculates velocity metrics (avg days per stage, bottleneck stage)
4. Computes stage-to-stage conversion rates
5. Flags at-risk deals (stalled, single-threaded, no activity)
6. Returns health score (0-100), grade (A-F), metrics, at-risk list

---

#### **`resources/methodology.py` — MCP Resources**

Serves 4 static methodology documents:
- `methodology://scoring-model` → 14.5-point ICP model reference
- `methodology://tier-definitions` → 4-tier classification
- `methodology://rfm-segments` → 11 RFM segment definitions
- `methodology://spiced-framework` → SPICED discovery framework

These are embedded as Python strings, sourced from `.claude/skills/` markdown files.

---

### Testing Strategy

| Test Type | Coverage | Tools |
|---|---|---|
| **Unit tests** | Core scoring logic (RFM, ICP, segmenter) | `pytest` |
| **Integration tests** | HubSpot API client (mocked with `respx`) | `pytest-asyncio` + `respx` |
| **MCP tests** | Tool invocation, resource serving | FastMCP testing utilities |
| **Manual tests** | Live HubSpot integration, AI assistant UX | Claude Desktop, Claude Code |

---

## 7. Sales Assets & Positioning

### Target Personas

#### 1. **RevOps Manager / Revenue Operations Lead**

**Profile:**
- Works at a B2B SaaS or services company ($5M-$50M revenue)
- Manages HubSpot, owns pipeline reporting
- Frustrated with manual Excel-based RFM analysis
- Wants AI-assisted insights but doesn't want to build custom integrations

**Pain points:**
- "I manually export deals to Excel every month to run RFM analysis"
- "I don't have a structured ICP scoring model — just gut feel"
- "Pipeline health is a black box — I can see the numbers but not the story"
- "Our sales team ignores low-quality leads because we can't prioritize effectively"

**Value prop:**
- "Get RFM analysis, ICP scoring, and pipeline health insights directly in Claude — no Excel, no manual work, no data science team required."

---

#### 2. **B2B Revenue Consultant / Fractional CRO**

**Profile:**
- Independent consultant or small consulting firm
- Delivers RevOps assessments, ICP workshops, pipeline audits to 5-10 clients per year
- Currently uses manual frameworks (Excel templates, slide decks)
- Wants to differentiate with AI-powered tools

**Pain points:**
- "I spend 4-6 hours running RFM analysis for each client"
- "My ICP scoring is subjective — clients question the methodology"
- "I can't scale beyond 10 clients per year without hiring"
- "Clients want real-time insights, not a static deliverable"

**Value prop:**
- "Deliver Artefact-quality revenue intelligence to your clients in minutes, not hours. White-label the methodology, 10x your delivery speed."

---

#### 3. **AI Power User / Developer**

**Profile:**
- Software engineer or technical founder
- Uses Claude Code / Cursor for development
- Building internal tools or custom AI workflows
- Wants to embed revenue intelligence in their product

**Pain points:**
- "I need revenue scoring logic but don't want to build it from scratch"
- "HubSpot's official MCP server is just CRUD — no intelligence"
- "I want to integrate RFM analysis into our internal ops dashboard"

**Value prop:**
- "Drop-in revenue intelligence API for AI assistants. No ML expertise required. Open-source methodology. Integrate in 5 minutes."

---

### Messaging Framework

**Positioning Statement:**
> "Artefact MCP is the only Model Context Protocol server with the **ICP Triangulation Framework™** — scoring prospects across firmographics, behaviors, and growth signals. Traditional ICP models stop at demographics. We triangulate across profile, activity, and momentum to identify revenue-ready prospects."

**Tagline:**
> "Three-dimensional revenue intelligence. Because demographics alone don't close deals."

**Category:**
> Revenue Intelligence Infrastructure

---

### Competitive Differentiation

| Competitor | What They Do | Artefact's Advantage |
|---|---|---|
| **HubSpot Official MCP** | Generic CRUD access to HubSpot CRM | Artefact adds ICP Triangulation Framework — firmographics + behaviors + growth signals |
| **CData HubSpot MCP** | SQL-based access to HubSpot data | Artefact is API-first, AI-native, no SQL knowledge required |
| **Traditional ICP Models** | Demographics-only scoring (industry, size, location) | Artefact triangulates across profile, activity, and momentum |
| **Manual Excel RFM** | Export deals, pivot tables, manual scoring | Artefact is automated, repeatable, instant |
| **Consulting engagement** | Hire a consultant, wait 2-4 weeks, get a PDF | Artefact delivers intelligence in seconds, on-demand |

---

### Sales Collateral

**Needed assets:**

1. **One-pager PDF** (1 page, visual)
   - What it is, 3 tools, pricing, how to install
   - QR code → GitHub repo

2. **Demo video** (2 min, Loom)
   - Install in Claude Desktop
   - Ask "Run an RFM analysis on sample data"
   - Ask "Qualify a SaaS company with $10M revenue"
   - Ask "Score pipeline health"
   - Show output, explain value

3. **HubSpot Community post** (long-form, authentic)
   - Title: "I built an MCP server that runs RFM analysis on HubSpot data"
   - Story: Why I built it, the methodology, how it works
   - Link to GitHub, PyPI, Smithery
   - Call to action: Try it with sample data

4. **Reddit launch post** (/r/hubspot, /r/ClaudeAI)
   - Title: "Show HN: Artefact MCP — Revenue intelligence for AI assistants"
   - Format: Problem → Solution → Demo → Link
   - Goal: 100+ upvotes, drive traffic to GitHub

5. **YouTube tutorial** (5 min, screen recording)
   - Title: "How to analyze your pipeline health with Claude in 60 seconds"
   - SEO keywords: "HubSpot pipeline analysis Claude AI"
   - Call to action: Install link in description

---

## 8. Distribution Channels

### Primary Channels

#### 1. **MCP Registries**

**What they are:** Community-maintained directories of MCP servers, discoverable by AI assistants and developers.

**Key registries:**
- [Smithery.ai](https://smithery.ai) — Official MCP registry (Anthropic-endorsed)
- [Glama.ai](https://glama.ai/mcp/servers) — Community-driven MCP server list
- [PulseMCP](https://pulsemcp.com) — MCP search engine

**Status:** Already listed on Smithery (`artefact-revenue-intelligence`)

**Optimization:**
- Rich metadata (`smithery.yaml`: tags, screenshots, demo video)
- SEO keywords: "hubspot", "revenue-intelligence", "rfm-analysis", "icp-scoring", "pipeline-health"
- Testimonials / reviews from early users

---

#### 2. **GitHub / Open Source**

**Repo:** https://github.com/alexboissAV/artefact-mcp-server

**Strategy:**
- **README optimization:** Clear value prop, quick start, FAQ, alternatives section
- **GitHub Topics:** `mcp`, `mcp-server`, `hubspot`, `revenue-intelligence`, `ai-tools`
- **Stars campaign:** Post on Reddit, Hacker News, Twitter → drive stars
- **Contributor-friendly:** Good docs, open issues, CONTRIBUTING.md

**Goal:** 100+ stars in first 3 months, 500+ stars by end of 2026

---

#### 3. **PyPI (Python Package Index)**

**Package:** `artefact-mcp` — https://pypi.org/project/artefact-mcp/

**Strategy:**
- Rich PyPI README (synced from GitHub README)
- Version badges, download stats, MCP-compatible badge
- Keywords: revenue-intelligence, hubspot, rfm-analysis, mcp-server

**Goal:** 1,000+ downloads in first 3 months

---

#### 4. **HubSpot App Marketplace** (Phase 2)

**Status:** Not yet listed (requires OAuth integration)

**Requirements:**
- HubSpot OAuth 2.0 app registration
- Partner review (security, UX, compliance)
- Public app listing with screenshots, video, pricing

**Timeline:** Q3 2026 (after OAuth implementation)

**Value:** Official HubSpot endorsement, discovery by HubSpot users, trust signal

---

#### 5. **Social / Community**

**Platforms:**
- **Reddit:** /r/hubspot (38K members), /r/ClaudeAI (22K members), /r/RevOps (8K members)
- **HubSpot Community:** Forums, blog comments, user groups
- **LinkedIn:** Alex's personal network, RevOps LinkedIn groups
- **Twitter/X:** #HubSpot, #ClaudeAI, #RevOps hashtags
- **YouTube:** SEO-optimized tutorials

**Content strategy:**
- Authentic launch story (not spammy)
- Educational content (how to run RFM analysis, why ICP scoring matters)
- User-generated content (retweet testimonials, share use cases)

---

#### 6. **Artefact Website / Blog**

**Landing page:** https://artefactventures.com/mcp-server

**Content:**
- Product overview
- Pricing
- Installation guide
- FAQ
- Comparison table (vs. alternatives)
- Testimonials (once available)
- CTA: "Install now" + "Book a demo"

**Blog posts:**
- "Introducing Artefact MCP: Methodology-driven revenue intelligence for AI assistants"
- "How to run RFM analysis on HubSpot data with Claude"
- "The anatomy of a great ICP scoring model (14.5 points)"
- "Why generic HubSpot MCP servers aren't enough for revenue teams"

---

### Distribution Metrics

**Key metrics to track:**

| Metric | Target (End of 2026) |
|---|---|
| GitHub stars | 500+ |
| PyPI downloads | 10,000+ total |
| Smithery installs | 500+ |
| Paying customers (Pro) | 10-15 |
| Paying customers (Enterprise) | 2-3 |
| MRR | $2,000-$3,000 |
| Reddit post upvotes | 100+ |
| YouTube video views | 1,000+ |

---

## 9. Competitive Landscape

### Direct Competitors

#### 1. **HubSpot Official MCP Server**

**What it does:** Generic CRUD access to HubSpot CRM objects (contacts, companies, deals, tickets, etc.)

**Strengths:**
- Official, first-party trust
- Full HubSpot API coverage
- Free

**Weaknesses:**
- No intelligence, no scoring, no methodology
- Just data access, not insights
- No RFM, no ICP, no pipeline health

**Artefact's positioning:** "We're not replacing HubSpot's MCP server — we're adding intelligence on top of it. Use both together."

---

#### 2. **CData HubSpot MCP Server**

**What it does:** SQL-based access to HubSpot data via CData connectors

**Strengths:**
- SQL queries for advanced users
- Multi-CRM support (not just HubSpot)

**Weaknesses:**
- Requires SQL knowledge
- No built-in methodology
- Enterprise pricing ($299+/mo)

**Artefact's positioning:** "No SQL required. Conversational revenue intelligence, not database queries."

---

#### 3. **Manual Excel-based RFM Analysis**

**What it is:** Export HubSpot deals to Excel, pivot tables, manual scoring

**Strengths:**
- Free (if you already have Excel)
- Full control over logic

**Weaknesses:**
- Time-consuming (4-6 hours per analysis)
- Error-prone (manual data entry)
- Not repeatable (no version control)
- Requires RevOps expertise

**Artefact's positioning:** "Automate what you're already doing manually. Same methodology, 100x faster."

---

#### 4. **Consulting Engagement (Hire a Consultant)**

**What it is:** Hire a RevOps consultant (Artefact, Stage 2 Capital, Winning by Design, etc.) to run RFM analysis, build ICP model, audit pipeline

**Strengths:**
- Expert guidance
- Customized to your business
- Full strategic context

**Weaknesses:**
- Expensive ($5K-$20K per engagement)
- Slow (2-4 weeks delivery)
- One-time deliverable (not ongoing)

**Artefact's positioning:** "Consulting delivers strategic guidance. Artefact MCP delivers ongoing intelligence. Use both: consultant for strategy, MCP for execution."

---

### Indirect Competitors

| Product | Category | How They Compete |
|---|---|---|
| **Gong Revenue Intelligence** | Sales intelligence platform | Full-featured SaaS, not AI-native, expensive ($$$) |
| **Clari** | Revenue operations platform | Enterprise-only, complex, not methodology-driven |
| **Outreach.io** | Sales engagement platform | Different use case (outbound), not revenue intelligence |
| **HubSpot Revenue Analytics** | Native HubSpot reporting | Basic dashboards, no RFM or ICP scoring, no AI |

---

### Competitive Moat

**What makes Artefact defensible:**

1. **Proprietary methodology:** ICP Triangulation Framework (firmographics + behaviors + growth signals), 11-segment RFM classification, Artefact Formula — built from real consulting engagements
2. **First-mover advantage:** First MCP server with three-dimensional ICP scoring (as of Feb 2026) — competitors are stuck on demographics-only models
3. **Open-source trust:** Code is transparent (BSL 1.1), users can audit the logic
4. **AI-native distribution:** MCP registries, AI assistant integration → hard to replicate via traditional SaaS
5. **Consulting IP moat:** Methodology is validated by paid consulting engagements (not academic theory)

---

## 10. Roadmap & Evolution

> **Pivot May 4 2026.** The roadmap below reflects the new strategic direction. Tracked in Notion: [EPIC — Artefact Formula MCP (self-serve GTM OS)](https://www.notion.so/3578ca3ef30a8148ab61ff9e84111965). 4 phases corresponding to 4 PRDs.

### Phase 0: Pre-pivot MVP (Feb-May 2026) ✅

**Delivered (v0.3.x):**
- 3 core Revenue Intelligence tools: `run_rfm`, `qualify`, `score_pipeline_health`
- 4 methodology resources (scoring model, tier definitions, RFM segments, SPICED framework)
- Free tier with sample data
- Pro/Enterprise tier with HubSpot integration
- PyPI package, Smithery listing, GitHub repo
- License validation infrastructure (offline, hardcoded keys)

---

### Phase 1: Méthodologie + auto-diagnostic (v0.4.0 — 2-4 weeks) — débloque Free tier

**Scope:** Methodology read-only resources + auto-diagnostic tool + CLAUDE.md generator + second brain guides. 100% local, no license.

**New resources:**
- `artefact://methodology/5-piliers`
- `artefact://methodology/archetypes` (A/B/C/D + complete decision tree)
- `artefact://methodology/glossaire` (20 essential terms)
- `artefact://methodology/skills-taxonomy` (Cat 1 / Cat 2 / Cat 3)
- `artefact://templates/claude-md-master` (annotated template)
- `artefact://guides/second-brain` (PARA + Tiago Forte abridged)

**New tools (Free):**
- `diagnostic_run(workspace_path)` — scans setup, returns current stage + next module
- `archetype_decision()` — interactive 7-question flow → A/B/C/D
- `generate_claude_md(company, role, kpis, context)` — master scaffold + 3 project MDs

**PRD:** [P1 Méthodologie read-only + auto-diagnostic](https://www.notion.so/3578ca3ef30a810aa69cc6da63782344) (escalated)

---

### Phase 2: Foundation tools + Lemon Squeezy licensing (v0.5.0 — 4-8 weeks) — débloque Build solo $200/mo

**Scope:** Build tier scaffolds + Lemon Squeezy License Keys integration + admin tool for consulting bundle keys.

**New tools (Build):**
- `skill_scaffold(workflow_description, category)` — generates SKILL.md frontmatter + steps + examples
- `sentinelle_scaffold(scan_target, archetype)` — generates sentinelle SKILL.md + orchestrator config (systemd / cron / routine selon archétype)
- `cost_estimate(archetype, volume_tokens, n_users)` — coûts mensuels licence + tokens + infra

**Licensing infrastructure:**
- Lemon Squeezy License Keys API integration
- Décorateur Python `@requires_license("build")` avec cache 5 min
- Webhook handler LS → Supabase Synapse pour subscription events
- Admin tool `generate_consulting_bundle_key(duration_days, mandate_label)`
- Reminder email LS 7 jours avant expiration consulting bundle

**PRD:** [P2 Foundation tools + Lemon Squeezy licensing](https://www.notion.so/3578ca3ef30a81fa9e76f8c87d2d6b79) (escalated)

---

### Phase 3: Module library prompts + multi-seat (v0.6.0 — 8-12 weeks) — débloque Build team $500/mo

**Scope:** 22 module prompts pour la bibliothèque MOS + multi-seat licensing + dashboards templates + triggers Build → Mandate.

**New prompts (Build team):**
22 slash commands `/artefact-{module-id}` corresponding to the 22 modules of the Artefact Formula GTM Operating System (KCK-1, FOND-1 to FOND-3, ARC-1 to ARC-3, ONB-1, DEC-1, NOT-1, WFL-1, SKL-1 to SKL-3, SNT-1, SNT-2, INT-1, INT-2, DSH-1, EXT-1, EXT-2, HDF-1).

**Multi-seat infrastructure:**
- LS Build team variant 500$/mo with seat enforcement
- Migration Supabase Synapse: table `mcp_seats` (license_key_hash, account_id, user_label)
- Décorateur étendu pour valider seat assignment
- Admin tool: assign / revoke seat sur compte team

**Triggers Build → Mandate:**
- Métriques passives: ≥3 active users (7j), ≥2 entrevues départementales tentées, custom skill request
- Vue Supabase `qualified_build_accounts`
- Notification Slack `#sales` quand un account passe le seuil
- Questionnaire opt-in « gouvernance vivante + scalabilité » → CTA partage calendrier booking Alex

**Dashboards templates:**
- CLAUDE.md health · Skills inventory · Sentinelles dashboard · Mandate progress
- Tool `generate_dashboard(type, data_source)` produit HTML local

**PRD:** [P3 Module library + multi-seat](https://www.notion.so/3578ca3ef30a8108b98acf441e1cfed3) (standard)

---

### Phase 4: Sentinelles + diagnostic anonymisé (v0.7.0 — plus tard) — débloque Build complet

**Scope:** Sentinelles tournant chez l'utilisateur + télémétrie produit anonymisée opt-in.

**Sentinelles utilisateur:**
- Templates de sentinelle par archétype (systemd / Cloud Scheduler / Azure Scheduler / cron)
- Catalogue v1: usage skills, fraîcheur métacontexte, health check automations
- Tool `deploy_sentinelle(template, archetype)` génère config orchestrateur

**Télémétrie produit (opt-in):**
- Tool `enable_telemetry()` avec disclosure complet (Loi 25)
- Pipeline pseudonymisé: license_key_hash + bucketing par archétype
- Endpoint Supabase Synapse `mcp_telemetry_events` avec PII scrubbing
- Dashboard interne Artefact (Vercel): module completion funnel, archetype distribution, time-per-module

**Loi 25 compliance:**
- PIA `docs/law25-pia-mcp-telemetry.md` (bloquant ship)
- Privacy policy update sur artefactventures.com/mcp
- Audit trail des opt-ins
- Boutons « exporter mes données télémétrie » + « supprimer mes données » (Loi 25 art. 27/28)

**PRD:** [P4 Sentinelles + diagnostic anonymisé](https://www.notion.so/3578ca3ef30a814ca4bfccc8350e4812) (escalated, Risk High)

---

### Future Explorations (post-P4)

- **Multi-CRM support:** Salesforce, Pipedrive providers (était Phase 5 ancien plan)
- **Cloud-hosted Streamable HTTP transport:** Railway, Fly.io
- **Notion integration:** Sync RFM analysis results, ICP models, pipeline audits to Notion databases
- **Slack notifications:** At-risk deal alerts, weekly pipeline health summary
- **HubSpot OAuth 2.0 + Marketplace listing:** Phase 2 distribution
- **Predictive models:** Deal win probability, churn risk, upsell propensity (requires ML)
- **Cat 2 OS Synapse advanced features:** BI cross-CRM, predictive sentinelles, learning loop (Mandate-only, not Build)

---

## Conclusion

The **Artefact Formula MCP** represents the next category of AI-native SaaS: **methodology-as-infrastructure** at three commercial tiers. It packages the Artefact Formula GTM Operating System — 5 piliers, 4 archétypes, 22 modules, taxonomie skills 3 catégories — into a software product that scales from a free architecture coach to a paid self-serve build to a full consulting mandate, all stacking on the same MCP package.

**Key success factors:**
1. **Distribution:** MCP registries, GitHub, PyPI, Substack methodology essays, organic SEO on GTM keywords
2. **Differentiation:** The only MCP that delivers a complete operating system, not just data access. Free tier (architecture coach) is genuinely useful and creates a qualified funnel.
3. **Trust:** Open-source code (BSL 1.1), transparent logic, methodology validated by paid consulting engagements at Artefact Ventures
4. **UX:** Conversational, AI-native interface (ask Claude, get diagnostic, get scaffolds, get guided modules)
5. **Pricing:** Three commercial tiers stacking with mandate consulting (Free → Build solo $200 → Build team $500 → Mandate $30-80K). Lemon Squeezy handles complexity.
6. **Moat:** Captures the GTM methodology standard in code before competitors. Cat 2 OS Synapse advanced features stay Mandate-only.

**The vision:** Every B2B revenue team uses Artefact Formula MCP as their GTM operating system. Free coaches founders through architecture decisions. Build powers RevOps teams through scaffolds and intelligence. Mandate adds Alex Boissonneault's animation for the parts that need human judgment. The package runs 24/7 on every team's laptop, embedded in their workflow, delivering methodology + intelligence + guided learning in seconds. Mandate clients receive Build comp'd during engagement and convert to standalone post-mandate, creating a recurring MRR layer that mandates alone never produced.

---

**Last updated:** May 4, 2026 (post-pivot)
**Author:** Alex Boissonneault / Artefact Ventures
**Contact:** alex@artefactventures.com
**Notion Epic:** [EPIC — Artefact Formula MCP (self-serve GTM OS)](https://www.notion.so/3578ca3ef30a8148ab61ff9e84111965)
**Strategic memory:** `~/.claude/projects/-home-debian-workspace/memory/mcp-server-v2-artefact-formula.md`
**Website:** https://artefactventures.com
