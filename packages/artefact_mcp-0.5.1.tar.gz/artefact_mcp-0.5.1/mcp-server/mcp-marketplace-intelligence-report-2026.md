# MCP Marketplace & Distribution Intelligence Report
**Date:** February 10, 2026 (v1) — May 5, 2026 (v2 self-serve update)
**Prepared for:** Artefact Ventures — MCP Revenue Stream Assessment
**Research scope:** MCP ecosystem as of early 2026

> **v2 update note (May 2026):** the report below remains the authoritative ecosystem analysis. The « Strategic Implications » section was rewritten in May 2026 to reflect the product pivot from « HubSpot Revenue Intelligence MCP » to « Artefact Formula MCP — Self-Serve GTM OS Builder » with a 4-SKU model (Free / Build solo / Build team / Mandate). See **section 11 (Self-Serve Angle)** below for the v2 positioning analysis, and [`artefact-formula-mcp-scope.md`](./artefact-formula-mcp-scope.md) for the full v2 scope.

---

## Executive Summary

The Model Context Protocol (MCP) ecosystem has exploded from ~100 servers in November 2024 to **10,000+ public servers** by late 2025, with the MCP SDK reaching **97 million monthly downloads**. Anthropic donated MCP to the Linux Foundation's Agentic AI Foundation (AAIF) in December 2025, with co-founders OpenAI and Block alongside members Google, Microsoft, AWS, Cloudflare, and Bloomberg. The ecosystem is rapidly institutionalizing, but **monetization remains nascent** — the protocol lacks a built-in payment layer, and most revenue comes from enterprise platform integrations rather than standalone paid servers. This represents both a challenge and a whitespace opportunity for Artefact Ventures.

---

## 1. MCP Marketplaces & Registries

### Official MCP Registry
- **URL:** registry.modelcontextprotocol.io
- **Status:** Launched in preview September 2025; progressing toward GA
- **Architecture:** Open-source parent registry that enables third-party "sub-registries" (marketplaces) to build on top of it
- **Features:** Verification mechanisms, server health pinging (every 5 seconds), moderation, OpenAPI spec
- **Strategic significance:** Canonical source of truth; all other registries can ingest from it

### Smithery.ai (Largest Independent Marketplace)
- **URL:** smithery.ai
- **Server count:** 7,300+ tools and extensions
- **Key features:** Hosted/remote server deployment on Smithery infrastructure + local installation via CLI; enterprise security; developer SDK (TypeScript)
- **Activity level:** Very active (CLI updated Feb 9, 2026)
- **Deployment:** Two modes — hosted (cloud, managed by Smithery) and local (user-installed)
- **Traction:** Highest among independent marketplaces; strong developer mindshare

### mcp.so (Largest Aggregator)
- **URL:** mcp.so
- **Server count:** 17,590 servers collected (highest raw count, includes duplicates/forks)
- **Key features:** "Call Ranking" leaderboard based on actual usage volume; filters for Featured, Latest, Official, Hosted; community moderation
- **Positioning:** Third-party aggregator focused on usage metrics and discovery

### Glama.ai
- **URL:** glama.ai/mcp
- **Server count:** ~10,000 production-ready entries
- **Key features:** Security scanning, compatibility ranking, ease-of-use scoring; ChatGPT-like UI for direct server interaction; API gateway; 30-day usage sorting
- **Positioning:** "Most comprehensive registry" — emphasizes curation and quality signals

### Other Notable Registries

| Registry | Focus |
|----------|-------|
| **PulseMCP** | 5,500+ servers; editorial analysis and ecosystem news |
| **Mastra MCP Registry** | Meta-aggregator across multiple registries; unified cross-registry view |
| **OpenTools Registry** | Task-oriented discovery; capability-based filtering |
| **MCP-Get** | Real-time monitoring; uptime insights; activity metrics |
| **MCPize** | 500+ servers; combined hosting + monetization platform |
| **GitHub MCP Registry** | Reference implementations; community contributions; GitHub-native signals |
| **Azure API Center** | Microsoft's enterprise MCP server inventory and discovery |
| **Kong MCP Registry** | Enterprise directory within Kong Konnect Catalog (announced Feb 2, 2026) |

### Assessment
Smithery has the most developer traction as a marketplace with deployment capabilities. mcp.so has the largest raw catalog but is more of an aggregator. The official registry is becoming the canonical source. **No single dominant marketplace has emerged yet** — the ecosystem is fragmented, which creates opportunity for vertical-specific marketplaces.

---

## 2. Distribution Channels & Installation UX

### How People Discover MCP Servers
1. **GitHub** — Browse awesome-mcp-servers lists, search repos
2. **Registries** — Smithery, mcp.so, Glama for browsing/filtering
3. **Word of mouth** — Developer communities, Twitter/X, Discord
4. **IDE marketplaces** — VS Code extensions view, Cursor settings
5. **Vendor documentation** — HubSpot, Salesforce etc. publish their own

### Installation UX by Client

**Claude Code (CLI)**
- Add via CLI command: `claude mcp add <name> <command>`
- Configuration stored in project or user settings
- Servers appear as available tools in the conversation

**Claude Desktop**
- Manual JSON config file editing: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Add server entries with command, args, and env vars
- Restart required after changes
- Improving but still technical

**VS Code (Copilot)**
- Extensions view: search `@mcp` to browse MCP servers
- Command Palette: `MCP: Browse Servers`
- CLI option: `--add-mcp` with JSON configuration
- Best native UX — integrated into familiar extension ecosystem

**Cursor**
- Settings > Tools & Integrations > New MCP Server
- Name it, set command type, paste command
- Relatively simple UI-driven setup

**Windsurf (Cascade)**
- Native MCP integration with MCP Marketplace discovery
- Supports stdio, Streamable HTTP, and SSE transports
- Configuration via `mcp_config.json` or marketplace UI
- Tools, resources, and prompts all supported

**Cline & Roo Code**
- Configuration file-based setup
- Cross-client MCP config sync tools available

### Assessment
Installation UX is **improving rapidly but still developer-focused**. The biggest friction is for non-technical users and enterprise rollouts where terminal commands are required. This is a key pain point that enterprise solutions (Kong, MCP Manager) are trying to solve. **A consulting firm could differentiate by handling deployment/configuration for clients.**

---

## 3. Monetization Models

### Current State
MCP **lacks a built-in monetization layer**. This is the single biggest challenge for anyone wanting to sell MCP servers. Developers must implement their own billing infrastructure.

### Emerging Pricing Models

| Model | Description | Examples |
|-------|-------------|----------|
| **Credit-based subscription** | Monthly credits, pay-per-use beyond allocation | Ref ($9/mo for 1,000 credits) |
| **Freemium + tiers** | Free requests, paid plans for volume/features | 21st.dev ($16-$32/mo), lesson plan tool ($9.99-$29.99/mo) |
| **Pay-per-event** | Charge per tool call or API request | Apify marketplace model |
| **Enterprise licensing** | High-touch, premium pricing for organizations | K2view ($5,000/mo), Vectara ($499-$1,999/mo) |
| **Platform fee / revenue share** | Marketplace takes 15-30% of transactions | Dedalus Labs (80/20 split to developer) |
| **Indirect monetization** | Free MCP server increases platform stickiness | HubSpot, Salesforce, Atlassian |
| **Hybrid subscription + overages** | Base subscription with usage-based fees beyond cap | Growing pattern |

### Documented Revenue Examples

| Product | Revenue | Model |
|---------|---------|-------|
| **Ref** (documentation search) | "Hundreds of subscribers" @ $9/mo | Credit-based subscription |
| **21st.dev Magic MCP** (UI components) | ~$400+ MRR | Freemium tiers + 50% revenue share with publishers |
| **Apify top creators** | $2,000-$10,000+/mo MRR | Pay-per-event marketplace |
| **Lesson plan generator** (education) | ~$3,000/mo | Subscription tiers |
| **Legal document analyzer** | ~$5,000/mo | Premium subscription ($24.99/mo) |
| **K2view** (enterprise data) | Enterprise pricing | $5,000/mo+ |

### Monetization Infrastructure Platforms

| Platform | What It Offers |
|----------|----------------|
| **Apify** | Full hosting + marketplace + pay-per-event billing; 130K+ monthly signups |
| **MCPize** | Hosting + monetization + marketplace; 85% revenue to developers |
| **Moesif** | API monetization layer with Stripe/Chargebee integration |
| **MonetizedMCP.org** | Monetization via Fluora |
| **Dedalus Labs** | Marketplace with $0.0025-$0.005/call; 80% to developers |
| **Stripe + Cloudflare SDK** | Direct payment processing for MCP agents |

### Assessment
Monetization is **very early stage**. Most successful revenue comes from either: (a) enterprise-grade vertical solutions with high-touch sales, or (b) developer-tool freemium models. **The enterprise licensing model ($300-$6,000+/mo) aligns best with Artefact's B2B consulting model.** The market is characterized as "the bottom of an exponential growth curve" — the window to establish premium positioning is now.

---

## 4. Competitive Landscape: HubSpot, CRM & RevOps MCP Servers

### Official HubSpot MCP Server
- **URL:** developers.hubspot.com/mcp
- **Status:** Public Beta
- **Access:** Read-only across contacts, companies, deals, tickets, invoices, products, line items, quotes, subscriptions, orders, carts, users
- **Write access:** Beta, admin must enable
- **Positioning:** Generic CRM data access; "skip the busywork"
- **Limitations:** No intelligence layer, no scoring, no pipeline analytics, no methodology — it's a raw data connector

### Third-Party HubSpot MCP Servers

| Server | Platform | Capabilities |
|--------|----------|--------------|
| **@shinzo-labs/hubspot-mcp** | Smithery | 100+ tools for CRM data management |
| **@KaranThink41/hubspot-mcp-summary** | Smithery | Summary records, notes management |
| **peakmojo/mcp-hubspot** | GitHub | Vector storage + caching layer on top of HubSpot API |
| **Hubspot-MCP (deezsecc)** | mcp.so | Database integration streamlining |
| **Coupler.io Salesforce MCP** | Standalone | No-code "AI-Powered CRM data analyst" |
| **Speakeasy HubSpot MCP** | Standalone | Auto-generated from HubSpot OpenAPI spec |

### Salesforce MCP Servers
- **Salesforce Hosted MCP Servers:** In beta since October 2025; managed infrastructure via AgentExchange
- **Agentforce MCP Support:** Deep integration with Salesforce's AI agent platform
- **Multiple third-party implementations** available

### Other CRM MCP Servers
- **Twenty CRM** (open-source CRM) — MCP server on Smithery
- **GoHighLevel** — 269+ tools on Smithery
- **Attio** — CRM workflow automation MCP

### What Does NOT Exist (The Gap)
**There is no MCP server that provides:**
- Revenue methodology/framework intelligence (e.g., Artefact Formula, SPICED)
- GTM maturity assessment automation
- ICP scoring and qualification models
- Pipeline health analysis with prescriptive recommendations
- Workshop-to-CRM intelligence workflows
- Multi-pillar revenue diagnostics
- Deal velocity analysis with methodology-driven coaching
- Customer Value Journey mapping through CRM data

All existing HubSpot/CRM MCP servers are **data connectors** — they read/write CRM objects. None embed domain expertise, scoring models, or revenue operations methodology. This is Artefact's whitespace.

---

## 5. Anthropic's Direction & Ecosystem Strategy

### Key Strategic Moves (Chronological)

1. **November 2024:** MCP open-sourced by Anthropic
2. **March 2025:** OpenAI adopts MCP for ChatGPT
3. **Mid-2025:** Google, Microsoft adopt MCP across their platforms
4. **September 2025:** Official MCP Registry launched in preview
5. **October 2025:** MCP Apps Extension (SEP-1865) — Anthropic and OpenAI co-release interactive UI capabilities for MCP
6. **December 9, 2025:** Anthropic donates MCP to the **Agentic AI Foundation (AAIF)** under the Linux Foundation
7. **December 18, 2025:** Anthropic releases **Agent Skills** as an independent open standard (agentskills.io)
8. **February 2, 2026:** Kong announces enterprise MCP Registry in Konnect

### AAIF Foundation Members
- **Co-founders:** Anthropic, Block, OpenAI
- **Platinum members:** Amazon, Bloomberg, Cloudflare, Google, Microsoft
- **Founding projects:** MCP, goose (Block), AGENTS.md (OpenAI)

### Agent Skills
- Open standard for packaging capabilities that AI agents can use
- Launch partners: Atlassian, Figma, Canva, Stripe, Notion, Zapier
- **No revenue-sharing arrangements** — ecosystem development focus
- Enterprise management tools for organization-wide skill deployment
- Relationship to MCP: "MCP for tool connectivity, Agent Skills for capability customization"

### MCP Roadmap Signals
- Full standardization expected in 2026
- Registry transitioning from preview to production
- API-level support for metering and monetization planned
- Verification mechanisms for security and quality
- Multi-agent collaboration as the default pattern

### Assessment
Anthropic is playing the **platform/infrastructure game** — building open standards and ceding control to foundations for maximum adoption. They are NOT building a commercial marketplace themselves. This leaves monetization to the ecosystem. The Agent Skills standard (December 2025) adds a higher-level abstraction on top of MCP that is more enterprise-friendly. **Artefact should watch Agent Skills closely as a potential packaging format.**

---

## 6. Developer Ecosystem Size & Growth

### Raw Numbers

| Metric | Value | Date |
|--------|-------|------|
| MCP servers (official registries) | 5,867+ | June 2025 |
| MCP servers (mcp.so aggregated) | 17,590 | Late 2025 |
| MCP servers (public, per AAIF) | 10,000+ | December 2025 |
| MCP SDK monthly downloads | 97 million | December 2025 |
| MCP clients | 300+ | Mid-2025 |
| Growth (Nov 2024 to May 2025) | ~100 to 4,000+ servers | 40x in 6 months |
| Server downloads | 100K to 8M | Nov 2024 to Apr 2025 |

### Most Downloaded Servers (Top 5)
1. **GitHub** — 889,000 downloads
2. **Fetch** (Anthropic) — 801,000
3. **Context7** (documentation) — 590,000
4. **Playwright** (browser automation) — 590,000
5. **Filesystem** (Anthropic) — 575,000

### Popular Categories
1. Web scraping & data collection (1,772+ servers)
2. Database connectors
3. Filesystem operations
4. Browser automation
5. Productivity & communication (Slack, email, calendars)
6. Developer tools (Git, CI/CD)
7. AI/ML tools
8. Financial & business APIs

### Official SDKs Available
Python, Java, TypeScript, C#, Kotlin, Swift

### Market Size Projections
- Global MCP server market: $2.7B (2025) projected to $5.6B (2034) at 8.3% CAGR
- MCP ecosystem broadly: $1.2B (2022) to $4.5B (2025)

### Assessment
Explosive growth but heavily concentrated in **developer-facing categories** (filesystem, GitHub, browser automation, databases). **Business/revenue/CRM intelligence is underrepresented** in the ecosystem. The ratio of servers to paying users suggests massive supply-side competition for generic tools but opportunity for specialized, domain-expert servers.

---

## 7. Enterprise Adoption

### Current State
2025 was the year of enterprise pilot projects. 2026 is being called **"the year for enterprise-ready MCP adoption"** — the transition from proof-of-concept to production deployment.

### Enterprise Deployment Models

| Model | Description | Target |
|-------|-------------|--------|
| **Workstation/Local** | Developers run MCP servers on their machines | Individual contributors |
| **Remote/Hosted** | HTTP-based connection to cloud-managed servers | Teams, light enterprise |
| **Managed Enterprise** | Containerized clusters behind load balancers, multi-region | Large organizations |
| **Gateway-mediated** | Kong or similar API gateway manages all MCP traffic centrally | Security-conscious enterprises |
| **Hybrid** | Mix of all above within one organization | Reality for most enterprises |

### Enterprise Infrastructure Vendors

| Vendor | Offering |
|--------|----------|
| **Kong** | Enterprise MCP Gateway (paid); MCP Registry in Konnect (Feb 2026); OAuth plugin; MCP Composer + Runner (early 2026) |
| **MCP Manager** (mcpmanager.ai) | Secure deployment at scale; enterprise governance |
| **Solo.io** | Enterprise MCP adoption consulting/challenges |
| **TrueFoundry** | Enterprise MCP server deployment platform |
| **Descope** | Authentication/security for remote MCP servers |
| **CData** | Enterprise data connectivity for MCP |
| **Microsoft Azure** | API Center with MCP server registration and discovery |
| **Salesforce** | Hosted MCP Servers via AgentExchange (managed infrastructure) |

### Enterprise Adoption Examples
- **Block** (fka Square) — Production MCP deployment with goose agent framework
- **Microsoft** — MCP integrated into Windows 11, Azure AI Foundry, Copilot Studio
- **Google/Alphabet** — Gemini models with managed MCP servers
- **Amazon** — Trainium chips optimized for MCP workloads; Amazon Bedrock integration
- **Salesforce** — Hosted MCP Servers in beta; Agentforce MCP support

### Key Enterprise Challenges
1. **Security:** MCP's authentication spec is still evolving; OAuth implementation inconsistent
2. **Governance/sprawl:** Developers spinning up ad-hoc servers without standardization
3. **Cost management:** AI deployment costs rising with agent workloads
4. **Resilience:** Infrastructure not yet proven for massive agent-driven load
5. **Non-technical deployment:** Terminal-based installation blocks adoption by business users

### Assessment
Enterprise adoption is real but apprehensive. CTOs recognize the value but face security and governance challenges. **The gap between "developers can use it" and "business users can benefit from it" is exactly where a consulting firm adds value.** The enterprise distribution model is converging on gateway-mediated, managed deployments — not individual server installations.

---

## 11. Self-Serve Angle (v2 update, May 2026)

The v1 report assumed Artefact would sell a single paid product to enterprise buyers. The May 2026 pivot reframes the question : how do you use the MCP ecosystem to **drain leads at the top of a funnel** that ends in a 30-80 K$ Mandate, not in a 500-2000 $/mo enterprise license ?

### 11.1 Why freemium fits the MCP ecosystem better than enterprise-only

Three observations from the report above support a freemium-first strategy :

1. **Section 3 Monetization** — the validated revenue examples are dominated by freemium tiers, not enterprise-only. 21st.dev (~400 $ MRR), the lesson plan generator (~3 000 $ MRR), and Ref (« hundreds of subscribers » @ 9 $/mo) all converted free users to paid plans. K2view's 5 000 $/mo enterprise tier is real but is the exception, not the rule, in the current MCP economy.
2. **Section 6 Ecosystem Size** — 97 million monthly SDK downloads + 10 000+ public servers means the discovery channel is enormous. A free tool that lands on the Smithery leaderboard or mcp.so call-volume index can drain 1 000-10 000 unique users in week 1. Charging at install time loses this entire pool.
3. **Section 7 Enterprise Adoption** — the friction noted in « non-technical deployment blocks adoption by business users » is exactly what a coaching MCP solves. The Free tier shifts the unit economics : a CMO who would never `pip install` a HubSpot connector will run an « auto-diagnose my GTM maturity » tool because it costs nothing and answers a question they already had.

### 11.2 The whitespace was bigger than v1 thought

Section 4 of this report identified the gap : « no MCP server provides revenue methodology/framework intelligence ». The v1 scope sought to fill that gap with a paid product. The v2 scope fills it with a **freemium product whose Free tier is the lead magnet**. The whitespace expands :

* **v1 whitespace** = paid revenue intelligence (small, contested by enterprise vendors)
* **v2 whitespace** = methodology coaching as MCP (uncontested as of April 2026, expanding fast)

The v2 product still includes the v1 paid-tier features (RFM, ICP scoring, pipeline health) — they're now the Mandate-only advanced tier. But the *category-defining* product is the Free coach.

### 11.3 Funnel mechanics — Build × Mandate stack

The report's Section 3 lists « indirect monetization — free MCP server increases platform stickiness » with HubSpot/Salesforce/Atlassian as examples. Artefact's twist : indirect monetization that funnels into a **separate** paid product (the Mandate), not the same product (subscription).

```
Free tier (MCP, 0 $)
    ↓ usage signals + qualitative qualif questionnaire
Build tier (MCP, 200-500 $/mo)
    ↓ triggers : ≥ 3 active users, custom Cat 1 skill needed, 2+ failed dept interviews, gouvernance/scalabilité signals
Mandate (consulting, 30-80 K$ ponctuel)
    ↓ at mandate completion, consulting bundle key activates
Build retention (60-80 % expected, MRR recurring)
```

This funnel does two things the v1 funnel couldn't :

* **Captures users who would never become Mandate clients** (sub-1.6 M$ revenue PMEs, founders) at the Build tier — pure self-serve revenue
* **Converts mandate clients to recurring MRR post-handoff** via the consulting bundle key — solves the « consulting revenue is lumpy » problem at the bottom of the funnel

### 11.4 Distribution implications vs v1

Section 1 of this report listed all the registries (Smithery, mcp.so, Glama, etc.). The v1 strategy was to list everywhere with the same paid-product description. The v2 strategy differs :

| Channel | v1 emphasis | v2 emphasis |
|---|---|---|
| Smithery | Listed for credibility | Listed for **leaderboard** — Free tier usage volume drives ranking |
| mcp.so | Aggregator presence | Call-volume leaderboard target — coaches get called multiple times per session |
| Glama | Editorial curation | Free tier description rewards the « productivity » category, not « business intelligence » |
| Lemon Squeezy storefront | Not in v1 | New in v2 — parallel discovery channel, MoR handles tax + Loi 25 |
| HubSpot App Marketplace | Mandatory | Deferred — only Mandate tier needs HubSpot OAuth ; Free + Build don't, so HubSpot Marketplace is a Phase 4 concern |

The v2 distribution sequencing prioritizes Free funnel ramp in weeks 1-4, then layers in paid infrastructure (Lemon Squeezy storefront in week 5, Mandate-tier integrations later). See [`mcp-directory-optimization-playbook.md`](./mcp-directory-optimization-playbook.md) section 0 for the week-by-week plan.

### 11.5 Risk reframing

The v1 report's risks (Section « Risks to Consider ») included « MCP monetization infrastructure is immature ». The v2 strategy addresses this : Lemon Squeezy is mature, MoR-grade, and built for SaaS license keys. The remaining risks shift :

| v1 risk | v2 status |
|---|---|
| MCP monetization immature | **Resolved** by Lemon Squeezy (License Keys API + subscriptions + customer portal + global tax handling) |
| Security concerns may slow enterprise adoption | Lower in v2 — Free tier is local-only, no data egress, no security review |
| Ecosystem could consolidate around large platforms | **Higher** in v2 — if Salesforce/Microsoft launch their own GTM coaching MCPs, the Free funnel is contested. Mitigation : ship Free P1 in 2-4 weeks |
| Free alternatives could commoditize basic CRM access | **Irrelevant** in v2 — Free tier doesn't access CRM, it's methodology only |
| Agent Skills standard may shift packaging | **Opportunity** in v2 — Agent Skills could be the next-layer packaging for the module library prompts (P3) |

### 11.6 Targets reframed

The v1 report didn't set ARR targets. v2 does :

* **2026-Q4** — 100 paying Build subscribers = 240 K$ ARR
* **2027** — 500 Build subscribers = 1.2 M$ ARR (matches CRO app target by self-serve alone)
* **Mandate flow** — 5-10 % of Build → Mandate = 25-50 pre-educated prospects/year
* **Mandate retention** — 60-80 % keep Build post-mandate = 210 K$ ARR/year added at steady state

The 1.2 M$ ARR target is achievable by Free funnel mechanics alone. Mandate revenue is on top.

---

## Strategic Implications for Artefact Ventures

### The Opportunity
1. **No revenue methodology MCP servers exist.** Every CRM MCP server is a data connector. None embed GTM expertise, scoring models, or prescriptive revenue intelligence.

2. **Enterprise monetization works.** The $300-$6,000+/mo tier for enterprise MCP servers is validated. This aligns with Artefact's B2B consulting model better than consumer freemium.

3. **The timing is right.** The ecosystem is at "the bottom of the exponential curve." Early movers in vertical-specific, methodology-embedded MCP servers can establish category leadership.

4. **Distribution is multi-channel.** List on Smithery + mcp.so + official registry for discovery. Sell directly to clients for revenue. Package as part of consulting engagements.

5. **HubSpot is underserved.** The official HubSpot MCP server is read-only basic data access. Third-party alternatives add marginal value. None provide intelligence.

### Potential MCP Server Products

| Server Concept | Value Proposition | Pricing Model |
|----------------|-------------------|---------------|
| **Artefact Revenue Intelligence MCP** | GTM maturity assessment, pipeline health scoring, deal velocity analysis via HubSpot data | Enterprise license ($500-$2,000/mo) |
| **ICP Qualification MCP** | AI-powered prospect scoring against ICP criteria using HubSpot + enrichment data | Per-qualification credit ($5-$15/qualification) |
| **Workshop Intelligence MCP** | Process Fireflies transcripts, extract SPICED data, generate assessments | Per-workshop processing ($200-$500/workshop) |
| **Revenue Operations Copilot MCP** | Natural language revenue operations queries against HubSpot with methodology-backed insights | Subscription ($300-$1,000/mo) |

### Risks to Consider
- MCP monetization infrastructure is immature; you'd need to build billing yourself or use Apify/MCPize
- Security concerns may slow enterprise adoption
- The ecosystem could consolidate around a few large platforms (Salesforce, Microsoft)
- Free alternatives could commoditize basic CRM access
- Agent Skills standard may shift the packaging model

### Recommended Next Steps (v1, February 2026 — superseded by v2 below)

1. Build a proof-of-concept MCP server wrapping Artefact's HubSpot integration + methodology
2. List on Smithery for visibility and developer feedback
3. Test willingness-to-pay with 2-3 existing clients
4. Monitor Agent Skills standard for enterprise packaging opportunities
5. Consider Apify or MCPize for monetization infrastructure
6. Track Kong MCP Gateway for enterprise distribution channel

### Recommended Next Steps (v2, May 2026)

1. **Ship P1 Free tier in 2-4 weeks** — `auto_diagnose`, `generate_claude_md`, `archetype_decision`, `gate_check`, `module_prompt_free`. PyPI publish + GitHub repo public + first 7 directory submissions. No license validation, no auth, no payment. Time-to-value < 30 seconds.
2. **Lemon Squeezy storefront live with Build solo plan in 4-8 weeks** — 200 $/mo + 500 $/mo team, License Keys API integration, customer portal. Stripe deferred (LS is the simpler MoR-grade choice).
3. **Module library prompts (P3) in 8-12 weeks** — `/artefact-fond-1` through the 10 written modules + stubs for the 23 to-be-written. This is what makes Build sticky during a mandate (anti-drift mechanic).
4. **Mandate-tier tools complete in P3** — the v1 RevenueIntelligence tools (analyze_deal, score_pipeline, qualify_prospect, run_rfm_analysis, audit_revenue_health) ship behind `@requires_license("mandate")`, comp'd via consulting bundle key during mandates, sold separately at high tier afterwards if enterprise demand exists.
5. **Agent Skills standard tracking** — keep monitoring as a potential next-layer packaging format for the module library prompts. Not a P1-P3 dependency.
6. **Kong MCP Gateway / Salesforce Hosted MCP / Azure API Center** — enterprise distribution channels for the Mandate tier. Phase 4+ concern, not launch.
7. **Open-sourcing decision for the MOS template** — discuss with PP whether the 10 written modules + kit-fondation become an open-source marketing wedge. Cat 2 advanced + the rest of the IP stays private.

---

## Sources

### MCP Registries & Marketplaces
- [Official MCP Registry](https://registry.modelcontextprotocol.io/)
- [Official MCP Registry Blog Post](http://blog.modelcontextprotocol.io/posts/2025-09-08-mcp-registry-preview/)
- [Smithery.ai](https://smithery.ai/)
- [Smithery Documentation](https://smithery.ai/docs)
- [MCP.SO](https://mcp.so/)
- [Glama MCP Servers](https://glama.ai/mcp/servers)
- [7 MCP Registries Worth Checking Out (Nordic APIs)](https://nordicapis.com/7-mcp-registries-worth-checking-out/)
- [MCPize Platform](https://mcpize.com/platform)
- [MonetizedMCP.org](https://www.monetizedmcp.org/)

### Ecosystem Statistics
- [MCP Statistics (mcpevals.io)](https://www.mcpevals.io/blog/mcp-statistics)
- [MCP Adoption Statistics 2025 (MCP Manager)](https://mcpmanager.ai/blog/mcp-adoption-statistics/)
- [A Year of MCP: From Internal Experiment to Industry Standard (Pento)](https://www.pento.ai/blog/a-year-of-mcp-2025-review)
- [Model Context Protocol Enterprise Adoption Guide](https://guptadeepak.com/the-complete-guide-to-model-context-protocol-mcp-enterprise-adoption-market-trends-and-implementation-strategies/)

### Monetization & Business Models
- [Pricing the Unknown: A Paid MCP Server (PulseMCP)](https://www.pulsemcp.com/posts/pricing-the-unknown-a-paid-mcp-server)
- [MCP Server Monetization: Emerging Commercial Landscape (Ritza)](https://ritza.co/articles/gen-articles/mcp-server-monetization-the-emerging-commercial-landscape/)
- [Monetizing MCP Servers with Moesif](https://www.moesif.com/blog/api-strategy/model-context-protocol/Monetizing-MCP-Model-Context-Protocol-Servers-With-Moesif/)
- [MCP Server Economics: TCO Analysis (Zeo)](https://zeo.org/resources/blog/mcp-server-economics-tco-analysis-business-models-roi)
- [Building the MCP Economy: Lessons from 21st.dev (Cline)](https://cline.bot/blog/building-the-mcp-economy-lessons-from-21st-dev-and-the-future-of-plugin-monetization)
- [Build and Monetize MCP Servers (Apify)](https://apify.com/mcp/developers)
- [Will People Pay for MCP Servers? (MCP in Context)](https://www.mcpincontext.com/p/will-people-actually-pay-for-mcp)

### HubSpot & CRM MCP Servers
- [HubSpot MCP Server (Official)](https://developers.hubspot.com/mcp)
- [HubSpot MCP on Smithery](https://smithery.ai/server/@shinzo-labs/hubspot-mcp)
- [peakmojo/mcp-hubspot (GitHub)](https://github.com/peakmojo/mcp-hubspot)
- [Salesforce MCP Servers Beta](https://developer.salesforce.com/blogs/2025/10/salesforce-hosted-mcp-servers-are-in-beta-today)
- [Agentforce MCP Support (Salesforce)](https://www.salesforce.com/agentforce/mcp-support/)

### Anthropic & AAIF
- [Anthropic Donates MCP to AAIF](https://www.anthropic.com/news/donating-the-model-context-protocol-and-establishing-of-the-agentic-ai-foundation)
- [MCP Joins AAIF (MCP Blog)](http://blog.modelcontextprotocol.io/posts/2025-12-09-mcp-joins-agentic-ai-foundation/)
- [Linux Foundation AAIF Announcement](https://www.linuxfoundation.org/press/linux-foundation-announces-the-formation-of-the-agentic-ai-foundation)
- [Anthropic Launches Agent Skills (VentureBeat)](https://venturebeat.com/technology/anthropic-launches-enterprise-agent-skills-and-opens-the-standard)
- [Agent Skills Open Standard (Anthropic)](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills)
- [Agent Skills GitHub](https://github.com/anthropics/skills)

### Enterprise Adoption
- [MCP in Enterprise: Real World Adoption at Block](https://block.github.io/goose/blog/2025/04/21/mcp-in-enterprise/)
- [Enterprise Challenges with MCP Adoption (Solo.io)](https://www.solo.io/blog/enterprise-challenges-with-mcp-adoption)
- [2026: The Year for Enterprise-Ready MCP Adoption (CData)](https://www.cdata.com/blog/2026-year-enterprise-ready-mcp-adoption)
- [Kong Enterprise MCP Gateway](https://konghq.com/blog/product-releases/enterprise-mcp-gateway)
- [Kong MCP Registry in Konnect](https://konghq.com/company/press-room/press-release/kong-introduces-mcp-registry)
- [MCP Server Deployment at Scale (MCP Manager)](https://mcpmanager.ai/blog/secure-mcp-server-deployment-at-scale-the-complete-guide/)

### MCP Roadmap & Future
- [MCP Roadmap (Official)](https://modelcontextprotocol.io/development/roadmap)
- [The Future of MCP (Knit)](https://www.getknit.dev/blog/the-future-of-mcp-roadmap-enhancements-and-whats-next)
- [MCP Apps Extension (Anthropic + OpenAI)](https://inkeep.com/blog/anthropic-openai-mcp-apps-extension)
- [Anthropic Built MCP, Then Shipped Skills (EntropyTown)](https://entropytown.com/articles/2025-10-20-claude-mcp-skills/)
- [USB-C for AI: MCP and Enterprise Agent Skills](https://business.times-online.com/times-online/article/tokenring-2026-1-5-the-usb-c-for-ai-how-anthropics-mcp-and-enterprise-agent-skills-are-standardizing-the-agentic-era)
