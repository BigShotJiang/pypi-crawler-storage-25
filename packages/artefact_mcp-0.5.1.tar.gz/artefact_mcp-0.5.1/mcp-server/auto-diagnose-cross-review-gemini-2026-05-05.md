## Per-case verdict

**Case 1: Pierre-Luc Bixi pattern (known Co-Build)**
The tool correctly identifies this as a `Co-Build` case with `high` confidence. The input is a textbook example containing multiple strong, unambiguous signals (e.g., "co-construire", "pilote disponible 5 à 8 heures", "motivé pour apprendre"), fully justifying the recommendation and the confidence level. This case performs perfectly.

**Case 2: Alexandre Laroche M Groupe Conseil (known POC)**
The tool's recommendation of `POC` with `high` confidence is correct. The input explicitly uses the term "POC" and mentions key qualifying criteria like a "4 semaines" timeline and the goal to "tester rapidement" before a larger commitment. The classification is accurate and the confidence is honest.

**Case 3: David Aubert Isothermic (known DIY)**
The recommended `mode` (DIY) and `archetype_hint` (C for M365) are correct. However, the tool's reasoning is flawed and reveals a critical weakness: it does not handle negation. It incorrectly flagged "co-construire" as a positive signal for Co-Build, even though the input was "**pas de** bandwidth pour **co-construire**". While the overwhelming weight of correct DIY signals led to the right answer, this error means the confidence is not entirely honest; it should have recognized a contradiction, not a competing signal.

**Case 4: Solo SaaS founder (Self-Serve)**
This case is handled perfectly. The `Self-Serve` recommendation is correct, supported by numerous strong signals like "fondateur solo", "gratuit", and "tech-savvy". The `high` confidence is appropriate given the clarity of the user's request.

**Case 5: VP RevOps mid-market 50 employees ambiguous EN**
This is a critical failure. The tool recommends `DIY` with `high` confidence based on a single, weak signal ("50 employees"). It completely misses the ambiguity created by "sponsor wants outputs fast" (a DIY signal) and "pilot is willing to learn" (a Co-Build signal). The confidence level is dangerously dishonest; it should be `medium` at best, triggering disambiguation questions. This highlights a severe gap in the English keyword set. The mode should be ambiguous, leaning towards DIY or Co-Build.

**Case 6: CMO scaleup tech-savvy 30 people**
The `Self-Serve` recommendation is correct, but the reasoning is thin. The tool only picked up on "tech-savvy" and "self-serve". It missed other important signals like "budget limité" and "on apprendra par nous-mêmes". While the result is right, it shows the keyword set is not robust enough and could fail if the user slightly alters their phrasing. The confidence should arguably be `medium` due to the low number of matched signals.

**Case 7: Volontairement ambigu Co-Build + POC**
This case exposes a fundamental flaw in the confidence algorithm. The tool recommends `POC` with `high` confidence, but the input is explicitly ambiguous, containing strong signals for both POC ("tester rapidement", "4 semaines") and Co-Build ("motivé pour apprendre"). The score gap (5 vs 3) is exactly 2, which the algorithm rigidly interprets as `high` confidence. For low absolute scores, a small gap like this represents significant ambiguity. The confidence should be `medium`, and this case should have resulted in disambiguation questions.

## Systemic gaps

*   **No Negation Handling:** The tool cannot process negative phrases like "pas de bandwidth" or "not interested in". As seen in case 3, it incorrectly treats a negated keyword as a positive signal for the competing mode, which is a major logical flaw.
*   **Insufficient Keyword/Signal Coverage:** The algorithm missed several obvious signals in the synthetic cases. Key concepts like "budget limité" (Self-Serve/POC), "apprendre par nous-mêmes" (Self-Serve), "willing to learn" (Co-Build), and timeframes like "4-6 weeks" (DIY) are missing, leading to incorrect classifications (Case 5) or fragile ones (Case 6).
*   **Flawed Confidence Logic:** The `gap >= 2` rule is too simplistic and brittle. It fails to account for the absolute value of the scores, leading to false `high` confidence when two modes have low but close scores (Case 7). A gap of 2 between scores of 5 and 3 is highly ambiguous, whereas a gap between 16 and 14 is less so.
*   **Lack of Anti-Signals:** The model only adds points for keywords; it doesn't subtract them. An explicit statement like "pas de bandwidth pour co-construire" should actively penalize the Co-Build score, not just boost the DIY score.

## Recommended weight adjustments

Adjusting individual weights is secondary to fixing the systemic gaps. However, the logic for confidence should be changed immediately.

**Confidence Algorithm Change:**
Instead of a simple `gap >= 2` rule, confidence should be a function of both the gap and the magnitude of the scores. A potential revised logic could be:
*   **High:** Gap is >= 3 OR (Gap is 2 AND Top Score is > 5).
*   **Medium:** Any other case where the top score is not 0 and confidence is not High.
*   **Framing:** All scores are 0.

This change would have correctly reclassified Case 7 ("Volontairement ambigu Co-Build + POC") as `medium` confidence (Gap is 2, Top Score is 5), which is the honest assessment.

## Bottom line

**Hold.**

The tool performs well on clean, "textbook" inputs that match its limited keyword set. However, it fails dangerously on ambiguous inputs, reporting `high` confidence in incorrect or contested recommendations (Cases 5 & 7). The lack of negation handling (Case 3) is a fundamental flaw that will lead to predictable errors in production. Before this tool can be shipped, it requires significant patches:

1.  **Implement Negation Handling:** The algorithm must recognize and correctly process negative phrases.
2.  **Rework Confidence Logic:** The `gap >= 2` rule must be replaced with a more robust calculation that considers score magnitude.
3.  **Expand Keyword Set:** The dictionary of signals in both French and English must be significantly broadened to capture more realistic user language.
