"""Oracle services."""
