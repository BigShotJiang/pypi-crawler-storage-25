import os
import torch
from dotenv import load_dotenv
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
from tqdm import tqdm
from sklearn.metrics import f1_score, precision_score, recall_score

load_dotenv()
token = os.getenv("HF_TOKEN")


def generate_and_evaluate(model_id, adapter_dir, test_ds, prompt_col, label_col,
                          input_col=None, max_new_tokens=10):
    """
    Load a base model + LoRA adapter and run generative evaluation.

    Parameters
    ----------
    model_id : str
        HuggingFace model ID or local path for the base model.
    adapter_dir : str
        Path to the saved LoRA adapter directory.
    test_ds : Dataset
        HuggingFace Dataset with prompt and label columns.
    prompt_col : str
        Column name containing the user prompt/instruction.
    label_col : str
        Column name containing the ground-truth label.
    input_col : str, optional
        Column name containing additional input context.
    max_new_tokens : int
        Maximum tokens to generate per example.

    Returns
    -------
    dict
        Evaluation metrics: accuracy, f1, precision, recall.
    """
    tokenizer = AutoTokenizer.from_pretrained(model_id, use_fast=True, token=token)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    base_model = AutoModelForCausalLM.from_pretrained(
        model_id, torch_dtype=torch.bfloat16, device_map="auto", token=token,
    )
    model = PeftModel.from_pretrained(base_model, adapter_dir)
    model.eval()

    all_preds = []
    all_labels = []
    correct = 0
    total = 0

    print("\nRunning inference...")
    for i, example in tqdm(enumerate(test_ds), total=len(test_ds)):
        instr = example[prompt_col].strip()
        input_text = (example.get(input_col) or "").strip() if input_col else ""
        user = instr if not input_text else f"{instr}\n\nInput:\n{input_text}"

        messages = [{"role": "user", "content": user}]
        prompt_text = tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        inputs = tokenizer(prompt_text, return_tensors="pt").to(model.device)

        ground_truth = str(example[label_col]).strip()

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id,
            )

        generated_text = tokenizer.decode(
            outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True
        ).strip()

        all_labels.append(ground_truth.lower())
        all_preds.append(generated_text.lower())

        is_correct = generated_text.lower() == ground_truth.lower()
        if is_correct:
            correct += 1
        total += 1

        if i < 5:
            print(f"\n--- Example {i+1} ---")
            print(f"Pred: {generated_text}")
            print(f"True: {ground_truth}")
            print(f"Correct: {is_correct}")

    accuracy = correct / total if total > 0 else 0.0
    print(f"\nFinal Test Accuracy: {accuracy:.2%} ({correct}/{total})")

    f1 = f1_score(all_labels, all_preds, average="weighted", zero_division=0)
    precision = precision_score(all_labels, all_preds, average="weighted", zero_division=0)
    recall = recall_score(all_labels, all_preds, average="weighted", zero_division=0)

    print(f"F1 Score (Weighted): {f1:.4f}")
    print(f"Precision (Weighted): {precision:.4f}")
    print(f"Recall (Weighted):    {recall:.4f}")

    return {"accuracy": accuracy, "f1": f1, "precision": precision, "recall": recall}


def main():
    """CLI entry point using environment variables."""
    import argparse

    parser = argparse.ArgumentParser(description="Evaluate a LoRA adapter with generative inference")
    parser.add_argument("--model", type=str, default=os.getenv("MODEL_ID", "meta-llama/Llama-3.1-8B-Instruct"))
    parser.add_argument("--adapter", type=str, default=os.getenv("ADAPTER_DIR", "./adapter-output"))
    parser.add_argument("--data", type=str, default=os.getenv("DATA_PATH", "data.csv"))
    parser.add_argument("--prompt_col", type=str, required=True, help="Column name for prompts")
    parser.add_argument("--label_col", type=str, required=True, help="Column name for ground-truth labels")
    parser.add_argument("--input_col", type=str, default=None, help="Column name for additional input context")
    parser.add_argument("--max_new_tokens", type=int, default=10)
    args = parser.parse_args()

    from datasets import load_dataset

    if args.data.endswith(".csv"):
        ds = load_dataset("csv", data_files=args.data, split="train")
    else:
        ds = load_dataset(args.data, split="train")

    # Use last 10% as test split
    splits = ds.train_test_split(test_size=0.1, seed=42)
    test_ds = splits["test"]

    generate_and_evaluate(
        model_id=args.model,
        adapter_dir=args.adapter,
        test_ds=test_ds,
        prompt_col=args.prompt_col,
        label_col=args.label_col,
        input_col=args.input_col,
        max_new_tokens=args.max_new_tokens,
    )


if __name__ == "__main__":
    main()
