import json
import os
from copy import deepcopy
from typing import Union

import torch
from datasets import Dataset, DatasetDict
from dotenv import load_dotenv
from peft import LoraConfig, get_peft_model
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    DataCollatorForSeq2Seq,
    Trainer,
    TrainingArguments,
)

from neotune.train import (
    compute_metrics,
    preprocess_logits_for_metrics,
    tokenize,
)

load_dotenv()
_token = os.getenv("HF_TOKEN")

DEFAULT_HYPERPARAMETERS = {
    # Training
    "learning_rate": 1e-4,
    "num_train_epochs": 3,
    "batch_size": 1,
    "gradient_accumulation_steps": 4,
    "warmup_ratio": 0.03,
    "weight_decay": 0.01,
    "bf16": True,
    "gradient_checkpointing": False,
    "logging_steps": 10,
    "eval_steps": 50,
    "save_steps": 100,
    "save_total_limit": 3,
    # LoRA
    "lora_r": 16,
    "lora_alpha": 32,
    "lora_dropout": 0.05,
    "lora_target_modules": [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ],
    # Output
    "output_dir": "./adapter-output",
    "hf_repo": None,
    # DeepSpeed
    "ds_config": None,
    # Data
    "max_len": 2048,
    "dataset_text_field": "text",
}

DEFAULT_DS_CONFIG = {
    "train_micro_batch_size_per_gpu": "auto",
    "gradient_accumulation_steps": "auto",
    "bf16": {"enabled": True},
    "zero_optimization": {
        "stage": 2,
        "overlap_comm": True,
        "contiguous_gradients": True,
    },
    "gradient_clipping": 1.0,
    "steps_per_print": 50,
    "optimizer": {
        "type": "AdamW",
        "params": {"lr": "auto", "betas": "auto", "eps": "auto", "weight_decay": "auto"},
    },
    "scheduler": {
        "type": "WarmupDecayLR",
        "params": {
            "total_num_steps": "auto",
            "warmup_min_lr": "auto",
            "warmup_max_lr": "auto",
            "warmup_num_steps": "auto",
        },
    },
}


def _resolve_ds_config(ds_config):
    if ds_config is None:
        return deepcopy(DEFAULT_DS_CONFIG)
    if isinstance(ds_config, dict):
        return ds_config
    with open(ds_config, "r") as f:
        return json.load(f)


def _is_tokenized(dataset: Dataset) -> bool:
    cols = set(dataset.column_names)
    return "input_ids" in cols and "labels" in cols


class NeoTune:
    """
    High-level API for LoRA supervised fine-tuning with DeepSpeed.

    Parameters
    ----------
    model : str
        HuggingFace model ID or local path
        (e.g. ``"meta-llama/Llama-3.1-8B-Instruct"``).

    datasets : dict[str, Dataset]
        Pre-built HuggingFace ``Dataset`` splits. Required key: ``"train"``.
        Optional keys: ``"validation"``, ``"test"``.

        Each dataset must contain **either**:

        * A text column (default ``"text"``) with fully-formatted
          prompt/response strings. NeoTune will tokenize it automatically.
        * ``input_ids``, ``attention_mask``, and ``labels`` columns —
          already tokenized and ready for training.

    hyperparameters : dict, optional
        Override any default. Supported keys:

        *Training:* ``learning_rate``, ``num_train_epochs``, ``batch_size``,
        ``gradient_accumulation_steps``, ``warmup_ratio``, ``weight_decay``,
        ``bf16``, ``gradient_checkpointing``, ``logging_steps``,
        ``eval_steps``, ``save_steps``, ``save_total_limit``

        *LoRA:* ``lora_r``, ``lora_alpha``, ``lora_dropout``,
        ``lora_target_modules``

        *Output:* ``output_dir``, ``hf_repo``

        *DeepSpeed:* ``ds_config`` (``None`` for built-in ZeRO-2,
        a file path, or a dict)

        *Data:* ``max_len``, ``dataset_text_field``

    Example
    -------
    ::

        from neotune import NeoTune

        nt = NeoTune(
            model="meta-llama/Llama-3.1-8B-Instruct",
            datasets={"train": train_ds, "validation": val_ds},
            hyperparameters={"learning_rate": 2e-4, "num_train_epochs": 5},
        )
        results = nt.train()
    """

    def __init__(
        self,
        model: str,
        datasets: dict,
        hyperparameters: Union[dict, None] = None,
    ):
        self.model_id = model
        self.hparams = {**DEFAULT_HYPERPARAMETERS, **(hyperparameters or {})}
        self.ds_config = _resolve_ds_config(self.hparams.get("ds_config"))
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self._tokenizer = None
        self._splits = self._validate_datasets(datasets)

    def _validate_datasets(self, datasets: dict) -> dict:
        if isinstance(datasets, DatasetDict):
            datasets = dict(datasets)
        if "train" not in datasets:
            raise ValueError("datasets must include a 'train' key")
        for name, ds in datasets.items():
            if not isinstance(ds, Dataset):
                raise TypeError(
                    f"datasets['{name}'] must be a HuggingFace Dataset, "
                    f"got {type(ds).__name__}"
                )
        return datasets

    @property
    def tokenizer(self):
        if self._tokenizer is None:
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.model_id, use_fast=True, token=_token
            )
            if self._tokenizer.pad_token is None:
                self._tokenizer.pad_token = self._tokenizer.eos_token
        return self._tokenizer

    def _prepare_splits(self) -> dict:
        max_len = self.hparams["max_len"]
        text_field = self.hparams["dataset_text_field"]
        splits = {}
        for name, ds in self._splits.items():
            if _is_tokenized(ds):
                splits[name] = ds
            else:
                if text_field not in ds.column_names:
                    raise ValueError(
                        f"Dataset '{name}' must have a '{text_field}' column "
                        f"(for auto-tokenization) or 'input_ids'+'labels' "
                        f"columns (pre-tokenized). "
                        f"Found columns: {ds.column_names}"
                    )
                remove_cols = [c for c in ds.column_names if c != text_field]
                # Rename to "text" if using a custom field name
                if text_field != "text":
                    ds = ds.rename_column(text_field, "text")
                ds_tok = ds.map(
                    lambda ex: tokenize(ex, self.tokenizer, max_len),
                    remove_columns=remove_cols + ["text"],
                )
                splits[name] = ds_tok
        return splits

    def _push_to_hub(self, model):
        repo = self.hparams["hf_repo"]
        print(f"Pushing adapter to HuggingFace Hub: {repo}")
        model.push_to_hub(repo, token=_token)
        self.tokenizer.push_to_hub(repo, token=_token)

    def train(self) -> dict:
        """
        Fine-tune the model with LoRA and return evaluation metrics.

        Returns test-set metrics if a ``"test"`` split was provided,
        otherwise returns validation metrics from the last evaluation step.
        """
        splits = self._prepare_splits()

        model = AutoModelForCausalLM.from_pretrained(
            self.model_id, torch_dtype=torch.bfloat16, token=_token
        )
        model.gradient_checkpointing_enable()
        model.enable_input_require_grads()
        model.config.use_cache = False

        lora_cfg = LoraConfig(
            task_type="CAUSAL_LM",
            r=self.hparams["lora_r"],
            lora_alpha=self.hparams["lora_alpha"],
            lora_dropout=self.hparams["lora_dropout"],
            target_modules=self.hparams["lora_target_modules"],
            bias="none",
        )
        model = get_peft_model(model, lora_cfg)
        model.print_trainable_parameters()

        output_dir = self.hparams["output_dir"]

        training_args = TrainingArguments(
            output_dir=output_dir,
            per_device_train_batch_size=self.hparams["batch_size"],
            gradient_accumulation_steps=self.hparams["gradient_accumulation_steps"],
            learning_rate=self.hparams["learning_rate"],
            num_train_epochs=self.hparams["num_train_epochs"],
            warmup_ratio=self.hparams["warmup_ratio"],
            weight_decay=self.hparams["weight_decay"],
            logging_steps=self.hparams["logging_steps"],
            eval_strategy="steps" if "validation" in splits else "no",
            eval_steps=self.hparams["eval_steps"] if "validation" in splits else None,
            per_device_eval_batch_size=self.hparams["batch_size"],
            save_steps=self.hparams["save_steps"],
            save_total_limit=self.hparams["save_total_limit"],
            bf16=self.hparams["bf16"],
            gradient_checkpointing=self.hparams["gradient_checkpointing"],
            deepspeed=self.ds_config,
        )

        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=splits["train"],
            eval_dataset=splits.get("validation"),
            data_collator=DataCollatorForSeq2Seq(
                self.tokenizer, pad_to_multiple_of=8, return_tensors="pt", padding=True
            ),
            preprocess_logits_for_metrics=preprocess_logits_for_metrics,
            compute_metrics=compute_metrics,
        )
        trainer.train()

        results = {}
        if "test" in splits:
            print("Running final evaluation on test set...")
            results = trainer.evaluate(splits["test"])
            print(f"Test Results: {results}")

        if trainer.is_world_process_zero():
            os.makedirs(output_dir, exist_ok=True)
            trainer.model.save_pretrained(output_dir)
            self.tokenizer.save_pretrained(output_dir)
            if self.hparams.get("hf_repo"):
                self._push_to_hub(trainer.model)

        return results


def finetune(
    model: str,
    datasets: dict,
    hyperparameters: Union[dict, None] = None,
) -> dict:
    """
    One-call fine-tuning: create a NeoTune instance and train immediately.

    Parameters
    ----------
    model : str
        HuggingFace model ID or local path.
    datasets : dict[str, Dataset]
        Dataset splits (must include ``"train"``).
    hyperparameters : dict, optional
        Override any default (see ``NeoTune`` for full list).

    Returns
    -------
    dict
        Test-set evaluation metrics (empty dict if no test split).
    """
    nt = NeoTune(model=model, datasets=datasets, hyperparameters=hyperparameters)
    return nt.train()
