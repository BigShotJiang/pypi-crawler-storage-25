import argparse
import json
import os
import tempfile
from copy import deepcopy
from typing import Any, Dict, Tuple

import torch
from torch.utils.data import DataLoader

import ray
import ray.train
import ray.train.torch
from ray.train import RunConfig, ScalingConfig
from ray.train.torch import TorchTrainer

import deepspeed
from deepspeed.accelerator import get_accelerator

import yaml
from datasets import load_dataset
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer, DataCollatorForSeq2Seq

from neotune.utils import dict_to_obj


def _load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _resolve_local_path(path: str, *, base_dir: str) -> str:
    """
    Resolve relative paths to absolute, with a fallback relative to base_dir.
    Ray workers may have a different working directory than the driver.
    """
    if "://" in path:
        return path
    if os.path.isabs(path) and os.path.exists(path):
        return path

    candidate = os.path.abspath(path)
    if os.path.exists(candidate):
        return candidate

    candidate = os.path.abspath(os.path.join(base_dir, path))
    if os.path.exists(candidate):
        return candidate

    return path


def _normalize_cfg(cfg: Dict[str, Any]) -> Dict[str, Any]:
    cfg = deepcopy(cfg)
    cfg.setdefault("mode", "train")
    cfg.setdefault("train", {})

    lr = cfg["train"].get("learning_rate")
    if isinstance(lr, str):
        cfg["train"]["learning_rate"] = float(lr)

    return cfg


def _build_ds_config(
    ds_config_path: str, *, micro_batch_size: int, grad_accum_steps: int
) -> Dict[str, Any]:
    ds_cfg = _load_json(ds_config_path)

    ds_cfg.pop("optimizer", None)
    ds_cfg.pop("scheduler", None)

    ds_cfg["train_micro_batch_size_per_gpu"] = micro_batch_size
    ds_cfg["gradient_accumulation_steps"] = grad_accum_steps
    return ds_cfg


def _load_and_tokenize_dataset(cfg_obj) -> Tuple[Any, Any]:
    if cfg_obj.data.local_path.endswith(".csv"):
        full_ds = load_dataset("csv", data_files=cfg_obj.data.local_path, split="train")
    else:
        full_ds = load_dataset(cfg_obj.data.local_path, split="train")

    train_size = cfg_obj.data.train_size
    val_size = cfg_obj.data.val_size
    test_size = cfg_obj.data.test_size
    if not abs(train_size + val_size + test_size - 1.0) < 1e-6:
        raise ValueError("Splits must sum to 1.0")

    train_test = full_ds.train_test_split(test_size=test_size, seed=42)
    train_val = train_test["train"]
    val_ratio = val_size / (train_size + val_size)
    train_val_split = train_val.train_test_split(test_size=val_ratio, seed=42)

    return train_val_split["train"], train_val_split["test"]


def _build_tokenizer(cfg_obj):
    tokenizer = AutoTokenizer.from_pretrained(
        cfg_obj.model,
        use_fast=True,
        token=os.getenv("HF_TOKEN"),
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer


def _format_prompt(example, tokenizer, cfg_obj):
    instr = (example.get(cfg_obj.data.prompt_col) or "").strip()
    input_text = (example.get(cfg_obj.data.input_col) or "").strip()
    output_text = (example.get(cfg_obj.data.output_col) or "").strip()

    user = instr if not input_text else f"{instr}\n\nInput:\n{input_text}"
    messages = [{"role": "user", "content": user}]
    if output_text:
        messages.append({"role": "assistant", "content": output_text})

    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=False)
    return {"text": text}


def _tokenize(example, tokenizer, max_len: int):
    toks = tokenizer(
        example["text"],
        truncation=True,
        max_length=max_len,
        padding=False,
    )
    toks["labels"] = toks["input_ids"].copy()
    return toks


def train_loop_per_worker(config: Dict[str, Any]) -> None:
    config_path = config["config_path"]
    base_dir = (
        os.path.dirname(os.path.abspath(config_path))
        if "://" not in config_path
        else os.getcwd()
    )

    cfg_dict = _normalize_cfg(_load_yaml(config_path))
    if isinstance(cfg_dict.get("data", {}).get("local_path"), str):
        cfg_dict["data"]["local_path"] = _resolve_local_path(
            cfg_dict["data"]["local_path"], base_dir=base_dir
        )
    if isinstance(cfg_dict.get("output", {}).get("local_path"), str):
        cfg_dict["output"]["local_path"] = _resolve_local_path(
            cfg_dict["output"]["local_path"], base_dir=base_dir
        )

    cfg = dict_to_obj(cfg_dict)

    tokenizer = _build_tokenizer(cfg)
    train_ds, _ = _load_and_tokenize_dataset(cfg)

    column_names = train_ds.column_names
    train_ds = train_ds.map(
        lambda ex: _format_prompt(ex, tokenizer, cfg),
        remove_columns=column_names,
    )
    train_ds = train_ds.map(
        lambda ex: _tokenize(ex, tokenizer, cfg.data.max_len),
        remove_columns=["text"],
    )

    collator = DataCollatorForSeq2Seq(
        tokenizer=tokenizer,
        padding=True,
        pad_to_multiple_of=8,
        return_tensors="pt",
    )
    train_loader = DataLoader(
        train_ds,
        batch_size=config["micro_batch_size"],
        shuffle=True,
        drop_last=True,
        collate_fn=collator,
    )
    train_loader = ray.train.torch.prepare_data_loader(train_loader)

    model = AutoModelForCausalLM.from_pretrained(
        cfg.model,
        torch_dtype=torch.bfloat16 if cfg.train.bf16 else None,
        token=os.getenv("HF_TOKEN"),
    )
    model.config.use_cache = False
    enable_gc = bool(getattr(cfg.train, "gradient_checkpointing", False))
    if not enable_gc and int(getattr(cfg.data, "max_len", 0) or 0) >= 4096:
        enable_gc = True

    if enable_gc:
        model.gradient_checkpointing_enable()
        model.enable_input_require_grads()

    lora = LoraConfig(
        task_type="CAUSAL_LM",
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        bias="none",
    )
    model = get_peft_model(model, lora)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.train.learning_rate,
        weight_decay=cfg.train.weight_decay,
    )

    ds_config = _build_ds_config(
        config["ds_config_path"],
        micro_batch_size=config["micro_batch_size"],
        grad_accum_steps=cfg.train.gradient_accumulation_steps,
    )

    ds_engine, optimizer, _, _ = deepspeed.initialize(
        model=model, optimizer=optimizer, config=ds_config
    )

    device = get_accelerator().device_name(ds_engine.local_rank)
    num_epochs = int(cfg.train.num_train_epochs)

    for epoch in range(num_epochs):
        ds_engine.train()
        running_loss = 0.0
        num_batches = 0

        sampler = getattr(train_loader, "sampler", None)
        if sampler is not None and hasattr(sampler, "set_epoch"):
            sampler.set_epoch(epoch)

        for batch in train_loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            outputs = ds_engine(
                input_ids=batch["input_ids"],
                attention_mask=batch.get("attention_mask"),
                labels=batch.get("labels"),
                use_cache=False,
            )
            loss = outputs.loss
            ds_engine.backward(loss)
            ds_engine.step()
            running_loss += float(loss.detach().cpu())
            num_batches += 1

        metrics = {"epoch": epoch, "loss": running_loss / max(1, num_batches)}

        with tempfile.TemporaryDirectory() as tmp_dir:
            ckpt_dir = os.path.join(tmp_dir, "checkpoint")
            os.makedirs(ckpt_dir, exist_ok=True)
            ds_engine.save_checkpoint(ckpt_dir)
            ray.train.report(metrics, checkpoint=ray.train.Checkpoint.from_directory(tmp_dir))

    if ray.train.get_context().get_world_rank() == 0:
        os.makedirs(cfg.output.local_path, exist_ok=True)
        ds_engine.module.save_pretrained(cfg.output.local_path)
        tokenizer.save_pretrained(cfg.output.local_path)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=str, default="config.yaml")
    p.add_argument("--ds_config", type=str, default="ds_config.json")
    p.add_argument("--num_workers", type=int, default=2)
    p.add_argument("--micro_batch_size", type=int, default=1)
    p.add_argument("--storage_path", type=str, default=os.getenv("RAY_STORAGE_PATH", "./ray_results"))
    p.add_argument("--run_name", type=str, default=os.getenv("RAY_RUN_NAME", "neotune-ray"))
    return p.parse_args()


def main():
    args = parse_args()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = _resolve_local_path(args.config, base_dir=script_dir)
    ds_config_path = _resolve_local_path(args.ds_config, base_dir=script_dir)

    scaling = ScalingConfig(num_workers=args.num_workers, use_gpu=True)
    storage_path = args.storage_path
    if "://" not in storage_path:
        storage_path = os.path.abspath(storage_path)

    run_config = RunConfig(storage_path=storage_path, name=args.run_name)

    trainer = TorchTrainer(
        train_loop_per_worker=train_loop_per_worker,
        train_loop_config={
            "config_path": config_path,
            "ds_config_path": ds_config_path,
            "micro_batch_size": args.micro_batch_size,
        },
        scaling_config=scaling,
        run_config=run_config,
    )

    result = trainer.fit()
    print(result)


if __name__ == "__main__":
    ray_address = os.getenv("RAY_ADDRESS")
    try:
        if ray_address:
            ray.init(address=ray_address, ignore_reinit_error=True)
        else:
            ray.init(ignore_reinit_error=True)
    except ConnectionError:
        ray.init(ignore_reinit_error=True)
    main()
