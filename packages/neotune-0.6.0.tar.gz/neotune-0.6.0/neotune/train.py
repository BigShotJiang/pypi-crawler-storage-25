import os
import torch
import numpy as np
from copy import deepcopy

import argparse
import yaml
from tqdm import tqdm

from sklearn.metrics import f1_score, precision_score, recall_score
from dotenv import load_dotenv
from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model, PeftModel
from transformers import DataCollatorForSeq2Seq, Trainer, TrainingArguments

from neotune.utils import dict_to_obj

load_dotenv()
token = os.getenv("HF_TOKEN")


# ------------------------------------------------------------------
# Shared utilities (used by NeoTune API and CLI entry points)
# ------------------------------------------------------------------

def tokenize(example, tokenizer, max_len):
    toks = tokenizer(example["text"], truncation=True, max_length=max_len, padding="max_length")
    toks["labels"] = toks["input_ids"].copy()
    return toks


def preprocess_logits_for_metrics(logits, labels):
    if isinstance(logits, tuple):
        logits = logits[0]
    return logits.argmax(dim=-1)


def compute_metrics(eval_preds):
    preds, labels = eval_preds
    labels = labels.reshape(-1)
    preds = preds.reshape(-1)
    mask = labels != -100
    labels = labels[mask]
    preds = preds[mask]

    acc = (preds == labels).mean()
    f1 = f1_score(labels, preds, average="macro", zero_division=0)
    precision = precision_score(labels, preds, average="macro", zero_division=0)
    recall = recall_score(labels, preds, average="macro", zero_division=0)

    return {
        "accuracy": acc,
        "f1_macro": f1,
        "precision_macro": precision,
        "recall_macro": recall,
    }


def format_prompt(example, tokenizer, prompt_col, input_col, output_col):
    instr = example.get(prompt_col, "").strip()
    input_text = (example.get(input_col) or "").strip()
    output_text = example.get(output_col, "").strip()

    user = instr if not input_text else f"{instr}\n\nInput:\n{input_text}"
    messages = [{"role": "user", "content": user}]

    if output_text:
        messages.append({"role": "assistant", "content": output_text})

    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=False)
    return {"text": text}


def train_test_split(ds, train_size, val_size, test_size, seed=42):
    if not abs(train_size + val_size + test_size - 1.0) < 1e-6:
        raise ValueError("Splits must sum to 1.0")

    train_test = ds.train_test_split(test_size=test_size, seed=seed)
    train_val = train_test["train"]

    val_ratio = val_size / (train_size + val_size)
    train_val_split = train_val.train_test_split(test_size=val_ratio, seed=seed)

    return {
        "train": train_val_split["train"],
        "validation": train_val_split["test"],
        "test": train_test["test"],
    }


# ------------------------------------------------------------------
# CLI entry point (config.yaml-based workflow)
# ------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--config", type=str, default="config.yaml")

    # Optional overrides (default = None)
    parser.add_argument("--model_id", type=str)
    parser.add_argument("--data_id", type=str)
    parser.add_argument("--out_dir", type=str)

    parser.add_argument("--train_batch_size", type=int)
    parser.add_argument("--gradient_accumulation_steps", type=int)
    parser.add_argument("--num_train_epochs", type=int)
    parser.add_argument("--learning_rate", type=float)
    parser.add_argument("--weight_decay", type=float)
    parser.add_argument("--warmup_steps", type=int)

    parser.add_argument("--bf16", action="store_true")
    parser.add_argument("--deepspeed", type=str)

    parser.add_argument("--mode", type=str, choices=["train", "inference"], default="train")
    parser.add_argument("--local_rank", type=int)

    return parser.parse_args()


def load_config(config_path):
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    return config


def merge_args_into_config(cfg, args):
    args_dict = vars(args)

    for key, value in args_dict.items():
        if value is None:
            continue

        if key == "model_id":
            cfg["model"] = value
            continue
        if key == "out_dir":
            cfg.setdefault("output", {})
            cfg["output"]["local_path"] = value
            continue
        if key == "mode":
            cfg["mode"] = value
            continue

        if key in cfg:
            cfg[key] = value
        elif key in cfg.get("train", {}):
            cfg["train"][key] = value
        elif key in cfg.get("data", {}):
            cfg["data"][key] = value
        elif key in cfg.get("output", {}):
            cfg["output"][key] = value

    return cfg


def fine_tune(cfg, ds, tokenizer):
    model = AutoModelForCausalLM.from_pretrained(
        cfg.model,
        torch_dtype=torch.bfloat16,
        token=token,
    )

    model.gradient_checkpointing_enable()
    model.enable_input_require_grads()
    model.config.use_cache = False

    lora = LoraConfig(
        task_type="CAUSAL_LM",
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        bias="none",
    )
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()

    training_args = TrainingArguments(
        output_dir=cfg.output.local_path,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=cfg.train.gradient_accumulation_steps,
        learning_rate=cfg.train.learning_rate,
        num_train_epochs=cfg.train.num_train_epochs,
        warmup_ratio=cfg.train.warmup_steps,
        logging_steps=cfg.train.logging_steps,
        eval_strategy="steps",
        eval_steps=cfg.train.eval_steps,
        per_device_eval_batch_size=1,
        save_steps=cfg.train.save_steps,
        save_total_limit=cfg.train.save_total_limit,
        bf16=True,
        gradient_checkpointing=cfg.train.gradient_checkpointing,
        gradient_checkpointing_kwargs=cfg.train.gradient_checkpointing_kwargs,
        ddp_find_unused_parameters=cfg.train.ddp_find_unused_parameters,
        deepspeed=cfg.train.deepspeed,
        report_to=cfg.train.report_to,
        run_name=cfg.train.run_name,
        local_rank=cfg.train.local_rank,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=ds["train"],
        eval_dataset=ds["validation"],
        data_collator=DataCollatorForSeq2Seq(tokenizer, pad_to_multiple_of=8, return_tensors="pt", padding=True),
        preprocess_logits_for_metrics=preprocess_logits_for_metrics,
        compute_metrics=compute_metrics,
    )
    trainer.train()

    print("Running final evaluation on Test set...")
    test_results = trainer.evaluate(ds["test"])
    print(f"Test Results: {test_results}")

    if trainer.is_world_process_zero():
        os.makedirs(cfg.output.local_path, exist_ok=True)
        trainer.model.save_pretrained(cfg.output.local_path)
        tokenizer.save_pretrained(cfg.output.local_path)


class Runner:
    """Config-based runner for the CLI entry point (neotune.train:main)."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = self._load_tokenizer()

    def _load_tokenizer(self):
        tokenizer = AutoTokenizer.from_pretrained(
            self.cfg.model,
            use_fast=True,
            token=token,
        )
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        return tokenizer

    def _load_data(self):
        if self.cfg.data.local_path.endswith(".csv"):
            full_ds = load_dataset("csv", data_files=self.cfg.data.local_path, split="train")
        else:
            full_ds = load_dataset(self.cfg.data.local_path, split="train")

        splits = train_test_split(
            full_ds,
            self.cfg.data.train_size,
            self.cfg.data.val_size,
            self.cfg.data.test_size,
        )

        return full_ds, splits

    def run(self):
        full_ds, splits = self._load_data()

        if self.cfg.mode == "train":
            column_names = full_ds.column_names
            for split in splits:
                splits[split] = splits[split].map(
                    lambda ex: format_prompt(
                        ex,
                        self.tokenizer,
                        self.cfg.data.prompt_col,
                        self.cfg.data.input_col,
                        self.cfg.data.output_col,
                    ),
                    remove_columns=column_names,
                )
                splits[split] = splits[split].map(
                    lambda ex: tokenize(ex, self.tokenizer, self.cfg.data.max_len),
                    remove_columns=["text"],
                )

            fine_tune(self.cfg, splits, self.tokenizer)


def main():
    args = parse_args()
    raw_cfg = load_config(args.config)
    cfg = merge_args_into_config(raw_cfg, args)

    cfg.setdefault("mode", args.mode)

    if isinstance(cfg.get("train", {}).get("learning_rate"), str):
        cfg["train"]["learning_rate"] = float(cfg["train"]["learning_rate"])

    cfg = deepcopy(cfg)
    cfg = dict_to_obj(cfg)

    runner = Runner(cfg)
    runner.run()


if __name__ == "__main__":
    main()
