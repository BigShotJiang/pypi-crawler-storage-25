from types import SimpleNamespace


def dict_to_obj(d):
    """
    Recursively convert a dict into an object with dot notation access.
    """
    return SimpleNamespace(
        **{
            k: dict_to_obj(v) if isinstance(v, dict) else v
            for k, v in d.items()
        }
    )
