"""Taegis Magic bundled resources."""
