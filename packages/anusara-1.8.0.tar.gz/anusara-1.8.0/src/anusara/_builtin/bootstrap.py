from __future__ import annotations

from anusara._builtin.definitions import builtin_agent_definitions
from anusara._registry.agent_registry import AgentRegistry


def register_builtin_agents(registry: AgentRegistry) -> None:
    for definition in builtin_agent_definitions():
        registry.register_resolved_definition(definition)
