from __future__ import annotations

import builtins

from anusara._contracts.agent import Agent
from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._contracts.agent_schema_provider import AgentSchemaProvider
from anusara._registry.errors import AgentNotFoundError
from anusara._registry.factory_builders import InstanceAgentFactory
from anusara._registry.loaders.resolution import resolve_registration_spec
from anusara._registry.registration_spec import AgentRegistrationSpec
from anusara._registry.resolved_definition import ResolvedAgentDefinition
from anusara._registry.validation import (
    validate_agent_id,
    validate_agent_instance,
    validate_resolved_definition,
)
from anusara._utils.collections import dedupe_capabilities


class AgentRegistry:
    """
    Registry for managing resolved agent definitions.

    Provides deterministic mapping between stable agent identifiers and
    validated factory-backed runtime definitions used during execution.

    Behavior:
    - Strict mode (default): duplicate registrations raise KeyError
    - Non-strict mode: later registrations overwrite earlier ones

    Design principles:
    - Explicit registration only (no implicit discovery)
    - Deterministic lookup
    - Stable identifier-based resolution
    - Factory-backed runtime creation
    - Lightweight and side-effect free registry access
    """

    def __init__(self, strict: bool = True) -> None:
        """
        Args:
            strict:
                If True, duplicate registrations raise KeyError.
                If False, later registrations overwrite earlier ones.
        """
        self._agents: dict[str, ResolvedAgentDefinition] = {}
        self._strict = strict

    # ---------------------------------------------------------
    # REGISTRATION
    # ---------------------------------------------------------

    def register(self, name: str, agent: Agent) -> None:
        """
        Backward-compatible registration API.

        Registers a concrete agent instance under an identifier by wrapping
        it in an InstanceAgentFactory and normalizing it into a
        ResolvedAgentDefinition.

        Args:
            name: Unique identifier for the agent
            agent: Agent implementation

        Raises:
            ValueError: If identifier is invalid
            TypeError: If agent does not satisfy the Agent contract
            KeyError: If strict mode is enabled and identifier already exists
        """
        validate_agent_id(name)
        validate_agent_instance(agent, agent_id=name)

        description, capabilities = self._extract_agent_metadata(name, agent)

        definition = ResolvedAgentDefinition(
            agent_id=name,
            factory=InstanceAgentFactory(agent=agent),
            namespace=self._infer_namespace(name),
            is_builtin=False,
            source_kind="instance",
            source_ref=type(agent).__name__,
            description=description,
            capabilities=capabilities,
        )

        self.register_resolved_definition(definition)

    def register_resolved_definition(self, definition: ResolvedAgentDefinition) -> None:
        """
        Register a validated runtime agent definition.

        Args:
            definition: Resolved runtime registration record

        Raises:
            ValueError: If the definition is invalid
            TypeError: If the resolved factory does not create a valid Agent
            KeyError: If strict mode is enabled and agent_id already exists
        """
        validate_resolved_definition(definition)

        if self._strict and definition.agent_id in self._agents:
            raise KeyError(f"Agent '{definition.agent_id}' is already registered.")

        self._agents[definition.agent_id] = definition

    # ---------------------------------------------------------
    # LOOKUP / RESOLUTION
    # ---------------------------------------------------------

    def get(self, name: str) -> Agent:
        """
        Resolve and create an agent instance for the given identifier.

        Args:
            name: Agent identifier

        Returns:
            Agent instance created through the registered factory

        Raises:
            AgentNotFoundError: If agent is not registered
            TypeError: If the created object does not satisfy the Agent contract
        """
        definition = self.get_definition(name)
        agent = definition.factory.create()
        validate_agent_instance(agent, agent_id=name)
        return agent

    def get_definition(self, agent_id: str) -> ResolvedAgentDefinition:
        """
        Retrieve a full resolved agent definition.

        Args:
            agent_id: Agent identifier

        Returns:
            ResolvedAgentDefinition

        Raises:
            AgentNotFoundError: If agent is not registered
        """
        try:
            return self._agents[agent_id]
        except KeyError as exc:
            raise AgentNotFoundError(agent_id) from exc

    # ---------------------------------------------------------
    # LIFECYCLE
    # ---------------------------------------------------------

    def unregister(self, name: str) -> None:
        """
        Remove a registered agent.

        Raises:
            AgentNotFoundError: If agent is not registered
        """
        if name not in self._agents:
            raise AgentNotFoundError(name)

        del self._agents[name]

    def exists(self, name: str) -> bool:
        """Check if an agent is registered."""
        return name in self._agents

    def clear(self) -> None:
        """Remove all registered agents."""
        self._agents.clear()

    # ---------------------------------------------------------
    # COLLECTION HELPERS
    # ---------------------------------------------------------

    def __contains__(self, name: str) -> bool:
        return name in self._agents

    def __len__(self) -> int:
        return len(self._agents)

    def list(self) -> list[str]:
        """List registered agent identifiers."""
        return list(self._agents.keys())

    def list_definitions(self) -> builtins.list[ResolvedAgentDefinition]:
        """List full resolved agent definitions."""
        return list(self._agents.values())

    # ---------------------------------------------------------
    # METADATA
    # ---------------------------------------------------------

    def metadata(self, name: str) -> dict[str, str]:
        """
        Return metadata for a registered agent.

        Raises:
            AgentNotFoundError: If agent is not registered
        """
        definition = self.get_definition(name)

        return {
            "agent_id": definition.agent_id,
            "namespace": definition.namespace or "",
            "version": definition.version or "",
            "is_builtin": str(definition.is_builtin),
            "source_kind": definition.source_kind,
            "source_ref": definition.source_ref,
            "description": definition.description or "",
            "capabilities": ",".join(definition.capabilities),
            "factory_type": type(definition.factory).__name__,
        }

    # ---------------------------------------------------------
    # INTERNALS
    # ---------------------------------------------------------

    def _infer_namespace(self, agent_id: str) -> str | None:
        if "." not in agent_id:
            return None

        namespace, _ = agent_id.split(".", 1)
        return namespace or None

    def register_spec(self, spec: AgentRegistrationSpec) -> None:
        """
        Resolve and register an agent from an explicit registration spec.

        Args:
            spec: Durable registration input describing how to resolve the agent

        Raises:
            ValueError: If spec fields are invalid
            ImportError: If module import fails
            AttributeError: If symbol is missing
            TypeError: If resolved symbol is not a supported Agent class
            KeyError: If strict mode is enabled and agent_id already exists
        """
        definition = resolve_registration_spec(spec)
        self.register_resolved_definition(definition)

    def _extract_agent_metadata(
        self,
        agent_id: str,
        agent: Agent,
    ) -> tuple[str | None, builtins.list[str]]:
        if not isinstance(agent, AgentSchemaProvider):
            return None, []

        descriptor = agent.describe_schema()

        if not isinstance(descriptor, AgentSchemaDescriptor):
            raise TypeError(
                f"Agent '{agent_id}' describe_schema() must return AgentSchemaDescriptor."
            )

        capabilities = dedupe_capabilities(descriptor.capabilities)
        return descriptor.description, capabilities
