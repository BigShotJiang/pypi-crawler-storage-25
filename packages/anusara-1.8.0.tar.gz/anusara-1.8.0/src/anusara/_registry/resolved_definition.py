from __future__ import annotations

from dataclasses import dataclass, field

from anusara._registry.factory_protocol import AgentFactory


@dataclass(frozen=True)
class ResolvedAgentDefinition:
    """
    Runtime-authoritative agent registration record.

    This is the validated form stored in the registry after registration
    input has been normalized and resolved into executable factory-backed
    metadata.
    """

    agent_id: str
    factory: AgentFactory
    namespace: str | None = None
    version: str | None = None
    is_builtin: bool = False
    source_kind: str = "unknown"
    source_ref: str = ""
    description: str | None = None
    capabilities: list[str] = field(default_factory=list)


__all__ = ["ResolvedAgentDefinition"]
