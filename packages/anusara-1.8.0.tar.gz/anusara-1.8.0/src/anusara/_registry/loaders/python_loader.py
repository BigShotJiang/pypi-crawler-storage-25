from __future__ import annotations

import importlib
import inspect
from types import ModuleType
from typing import cast

from anusara._contracts.agent import Agent
from anusara._registry.factory_builders import ClassAgentFactory
from anusara._registry.factory_protocol import AgentFactory
from anusara._registry.sources.python_import_source import PythonImportAgentSource


def load_python_agent_factory(
    source: PythonImportAgentSource,
) -> tuple[AgentFactory, str, str]:
    """
    Resolve a Python import source into a typed runtime factory.

    Returns:
        tuple of:
        - validated AgentFactory
        - source_kind
        - source_ref

    Raises:
        ImportError: if module import fails
        AttributeError: if symbol is missing
        TypeError: if symbol is not a supported Agent class
    """
    module: ModuleType = importlib.import_module(source.module)
    namespace = cast(dict[str, object], module.__dict__)

    if source.symbol not in namespace:
        raise AttributeError(
            f"Module '{source.module}' does not define symbol '{source.symbol}'."
        )

    symbol_object = namespace[source.symbol]

    if not inspect.isclass(symbol_object):
        raise TypeError(
            f"Resolved symbol '{source.module}:{source.symbol}' must be a class."
        )

    candidate_cls = cast(type[object], symbol_object)

    if not issubclass(candidate_cls, Agent):
        raise TypeError(
            f"Resolved symbol '{source.module}:{source.symbol}' must be an Agent class."
        )

    agent_cls: type[Agent] = candidate_cls

    factory = ClassAgentFactory(agent_cls=agent_cls)
    source_kind = "python_import"
    source_ref = f"{source.module}:{source.symbol}"

    return factory, source_kind, source_ref


__all__ = ["load_python_agent_factory"]
