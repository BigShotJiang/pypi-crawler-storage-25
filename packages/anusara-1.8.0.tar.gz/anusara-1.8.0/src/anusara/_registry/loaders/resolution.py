from __future__ import annotations

from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._contracts.agent_schema_provider import AgentSchemaProvider
from anusara._registry.factory_protocol import AgentFactory
from anusara._registry.loaders.python_loader import load_python_agent_factory
from anusara._registry.registration_spec import AgentRegistrationSpec
from anusara._registry.resolved_definition import ResolvedAgentDefinition
from anusara._registry.validation import validate_agent_id
from anusara._utils.collections import dedupe_capabilities


def resolve_registration_spec(
    spec: AgentRegistrationSpec,
) -> ResolvedAgentDefinition:
    """
    Resolve a durable agent registration spec into a runtime-authoritative
    resolved definition.

    Raises:
        ValueError: if spec fields are invalid
        ImportError: if module import fails
        AttributeError: if symbol is missing
        TypeError: if resolved symbol is not a supported Agent class
    """
    validate_agent_id(spec.agent_id)

    if spec.namespace is not None:
        if not isinstance(spec.namespace, str) or not spec.namespace:
            raise ValueError("namespace must be a non-empty string when provided.")

    if spec.version is not None:
        if not isinstance(spec.version, str) or not spec.version:
            raise ValueError("version must be a non-empty string when provided.")

    factory, source_kind, source_ref = load_python_agent_factory(spec.source)

    description, capabilities = _extract_agent_metadata_from_factory(
        spec.agent_id,
        factory,
    )

    return ResolvedAgentDefinition(
        agent_id=spec.agent_id,
        factory=factory,
        namespace=spec.namespace,
        version=spec.version,
        is_builtin=spec.is_builtin,
        source_kind=source_kind,
        source_ref=source_ref,
        description=description,
        capabilities=capabilities,
    )


def _extract_agent_metadata_from_factory(
    agent_id: str,
    factory: AgentFactory,
) -> tuple[str | None, list[str]]:
    agent = factory.create()

    if not isinstance(agent, AgentSchemaProvider):
        return None, []

    descriptor = agent.describe_schema()

    if not isinstance(descriptor, AgentSchemaDescriptor):
        raise TypeError(
            f"Agent '{agent_id}' describe_schema() must return AgentSchemaDescriptor."
        )

    capabilities = dedupe_capabilities(descriptor.capabilities)
    return descriptor.description, capabilities


__all__ = [
    "resolve_registration_spec",
    "_extract_agent_metadata_from_factory",
]
