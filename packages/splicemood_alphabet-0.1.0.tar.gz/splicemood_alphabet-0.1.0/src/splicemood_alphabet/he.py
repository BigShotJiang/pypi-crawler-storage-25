# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "אבגדהוזחטיכךלמםנןסעפףצץקרשת"
base = 27
