# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCÇDEƏFGĞHXIİJKQLMNOÖPRSŞTUÜVYZabcçdeəfgğhxıijkqlmnoöprsştuüvyz0123456789"
base = 74
