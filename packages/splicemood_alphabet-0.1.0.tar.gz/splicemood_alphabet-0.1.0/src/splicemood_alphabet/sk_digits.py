# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AÁÄBCČDĎEÉFGHIÍJKLMNŇOÓÔPQRŔSŠTŤUÚVWXYÝZŽaáäbcčdďeéfghiíjklmnňoóôpqrŕsštťuúvwxyýzž0123456789"
base = 92
