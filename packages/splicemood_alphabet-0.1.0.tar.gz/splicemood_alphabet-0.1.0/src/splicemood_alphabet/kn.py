# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ಅಆಇಈಉಊಋೠಎಏಐಒಓಔಕಖಗಘಙಚಛಜಝಞಟಠಡಢಣತಥದಧನಪಫಬಭಮಯರಲವಶಷಸಹಳ"
base = 48
