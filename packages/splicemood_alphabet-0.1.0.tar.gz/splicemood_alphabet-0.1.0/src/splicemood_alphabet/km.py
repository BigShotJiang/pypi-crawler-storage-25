# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "កខគឃងចឆជឈញដឋឌឍណតថទធនបផពភមយរលវឝឞសហឡអ"
base = 35
