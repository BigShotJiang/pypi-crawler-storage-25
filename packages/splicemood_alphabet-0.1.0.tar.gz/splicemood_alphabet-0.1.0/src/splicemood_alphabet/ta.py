# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "அஆஇஈஉஊஎஏஐஒஓஔஃகஙசஞடணதநபமயரலவழளறனஜஷஸஹ"
base = 35
