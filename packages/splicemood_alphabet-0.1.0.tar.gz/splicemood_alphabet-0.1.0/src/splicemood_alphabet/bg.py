# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЬЮЯабвгдежзийклмнопрстуфхцчшщъьюя"
base = 60
