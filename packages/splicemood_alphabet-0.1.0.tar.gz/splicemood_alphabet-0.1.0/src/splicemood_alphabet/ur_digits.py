# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "آابپتٹثجچحخدڈذرڑزژسشصضطظعغفقکگلمنںوہھءیے0123456789"
base = 50
