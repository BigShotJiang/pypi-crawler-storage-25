# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ಅಆಇಈಉಊಋೠಎಏಐಒಓಔಕಖಗಘಙಚಛಜಝಞಟಠಡಢಣತಥದಧನಪಫಬಭಮಯರಲವಶಷಸಹಳ0123456789"
base = 58
