# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AÁBDÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖaábdðeéfghiíjklmnoóprstuúvxyýþæö0123456789"
base = 74
