# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĂÂBCDEFGHIÎJKLMNOPQRSȘTȚUVWXYZaăâbcdefghiîjklmnopqrsștțuvwxyz"
base = 62
