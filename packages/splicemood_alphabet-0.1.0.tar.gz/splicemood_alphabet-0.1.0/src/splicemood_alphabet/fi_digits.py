# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖabcdefghijklmnopqrstuvwxyzåäö0123456789"
base = 68
