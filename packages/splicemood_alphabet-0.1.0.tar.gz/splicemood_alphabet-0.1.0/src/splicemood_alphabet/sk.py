# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AÁÄBCČDĎEÉFGHIÍJKLMNŇOÓÔPQRŔSŠTŤUÚVWXYÝZŽaáäbcčdďeéfghiíjklmnňoóôpqrŕsštťuúvwxyýzž"
base = 82
