# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "აბგდევზთიკლმნოპჟრსტუფქღყშჩცძწჭხჯჰ0123456789"
base = 43
