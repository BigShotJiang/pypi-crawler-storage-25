# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCĈDEFGĜHĤIJĴKLMNOPRSŜTUŬVZabcĉdefgĝhĥijĵklmnoprsŝtuŭvz0123456789"
base = 66
