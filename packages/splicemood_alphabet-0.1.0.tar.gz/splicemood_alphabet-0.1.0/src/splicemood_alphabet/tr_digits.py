# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZabcçdefgğhıijklmnoöprsştuüvyz0123456789"
base = 68
