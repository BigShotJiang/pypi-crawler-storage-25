# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĄBCČDEĘĖFGHIĮYJKLMNOPRSŠTUŲŪVZŽaąbcčdeęėfghiįyjklmnoprsštuųūvzž0123456789"
base = 74
