# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCĊDEFGĠHĦIJKLMNOPQRSTUVWXYZŻabcċdefgġhħijklmnopqrstuvwxyzż0123456789"
base = 70
