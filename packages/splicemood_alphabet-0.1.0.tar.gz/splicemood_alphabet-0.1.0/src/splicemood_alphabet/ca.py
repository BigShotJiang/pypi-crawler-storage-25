# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÀÉÈÍÏÓÒÚÜÇabcdefghijklmnopqrstuvwxyzàéèíïóòúüç"
base = 72
