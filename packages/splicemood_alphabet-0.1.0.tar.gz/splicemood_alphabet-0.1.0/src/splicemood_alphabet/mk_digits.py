# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "АБВГДЃЕЖЗЅИЈКЛЉМНЊОПРСТЌУФХЦЧЏШабвгдѓежзѕијклљмнњопрстќуфхцчџш0123456789"
base = 72
