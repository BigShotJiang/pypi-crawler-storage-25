# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЬЮЯабвгдежзийклмнопрстуфхцчшщъьюя0123456789"
base = 70
