# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي0123456789"
base = 38
