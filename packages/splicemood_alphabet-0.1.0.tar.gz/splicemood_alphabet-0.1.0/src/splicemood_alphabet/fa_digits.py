# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی0123456789"
base = 43
