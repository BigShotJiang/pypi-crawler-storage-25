# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "АБВГДЂЕЖЗИЈКЛЉМНЊОПРСТЋУФХЦЧЏШабвгдђежзијклљмнњопрстћуфхцчџш0123456789"
base = 70
