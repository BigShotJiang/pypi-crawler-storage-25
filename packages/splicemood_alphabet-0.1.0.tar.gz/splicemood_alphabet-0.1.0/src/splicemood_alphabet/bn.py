# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "অআইঈউঊঋএঐওঔকখগঘঙচছজঝঞটঠডঢণতথদধনপফবভমযরলশষসহৎ"
base = 44
