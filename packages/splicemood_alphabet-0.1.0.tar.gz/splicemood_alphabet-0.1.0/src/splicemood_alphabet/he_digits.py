# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "אבגדהוזחטיכךלמםנןסעפףצץקרשת0123456789"
base = 37
