# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ਅਆਇਈਉਊਏਐਓਔਕਖਗਘਙਚਛਜਝਞਟਠਡਢਣਤਥਦਧਨਪਫਬਭਮਯਰਲਵਸਹੜ0123456789"
base = 52
