# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "آابپتٹثجچحخدڈذرڑزژسشصضطظعغفقکگلمنںوہھءیے"
base = 40
