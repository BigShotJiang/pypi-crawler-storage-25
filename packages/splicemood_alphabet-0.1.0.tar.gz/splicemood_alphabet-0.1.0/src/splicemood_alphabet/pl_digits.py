# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĄBCĆDEĘFGHIJKLŁMNŃOÓPRSŚTUWYZŹŻaąbcćdeęfghijklłmnńoóprsśtuwyzźż0123456789"
base = 74
