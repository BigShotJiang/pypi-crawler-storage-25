# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCÇDEƏFGĞHXIİJKQLMNOÖPRSŞTUÜVYZabcçdeəfgğhxıijkqlmnoöprsştuüvyz"
base = 64
