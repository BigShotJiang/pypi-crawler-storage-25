# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรลวศษสหฬอฮ"
base = 44
