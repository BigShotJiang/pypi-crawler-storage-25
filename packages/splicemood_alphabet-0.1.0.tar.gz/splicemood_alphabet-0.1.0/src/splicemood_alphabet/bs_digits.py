# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCČĆDĐEFGHIJKLMNOPRSŠTUVZŽabcčćdđefghijklmnoprsštuvzž0123456789"
base = 64
