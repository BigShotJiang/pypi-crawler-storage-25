# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHILMNOPQRSTUVZabcdefghilmnopqrstuvz"
base = 42
