# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "అఆఇఈఉఊఋౠఎఏఐఒఓఔకఖగఘఙచఛజఝఞటఠడఢణతథదధనపఫబభమయరలవశషసహళఱ0123456789"
base = 59
