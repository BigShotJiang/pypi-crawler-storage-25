# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي"
base = 28
