# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĂÂBCDĐEÊGHIKLMNOÔƠPQRSTUƯVXYaăâbcdđeêghiklmnoôơpqrstuưvxy0123456789"
base = 68
