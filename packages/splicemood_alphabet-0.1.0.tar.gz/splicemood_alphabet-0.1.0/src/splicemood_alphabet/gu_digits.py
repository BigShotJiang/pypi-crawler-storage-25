# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "અઆઇઈઉઊઋએઐઓઔકખગઘઙચછજઝઞટઠડઢણતથદધનપફબભમયરલવશષસહળ0123456789"
base = 55
