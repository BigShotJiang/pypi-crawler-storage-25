# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĂÂBCDEFGHIÎJKLMNOPQRSȘTȚUVWXYZaăâbcdefghiîjklmnopqrsștțuvwxyz0123456789"
base = 72
