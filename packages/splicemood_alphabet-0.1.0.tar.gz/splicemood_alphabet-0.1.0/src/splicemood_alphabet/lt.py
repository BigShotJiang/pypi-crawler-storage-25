# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĄBCČDEĘĖFGHIĮYJKLMNOPRSŠTUŲŪVZŽaąbcčdeęėfghiįyjklmnoprsštuųūvzž"
base = 64
