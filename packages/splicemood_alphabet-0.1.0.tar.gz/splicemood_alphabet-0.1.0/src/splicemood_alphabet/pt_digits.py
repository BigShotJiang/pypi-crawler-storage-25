# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÁÂÃÀÇÉÊÍÓÔÕÚÜabcdefghijklmnopqrstuvwxyzáâãàçéêíóôõúü0123456789"
base = 88
