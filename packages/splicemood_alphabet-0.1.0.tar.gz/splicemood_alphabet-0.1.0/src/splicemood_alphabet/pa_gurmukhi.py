# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ਅਆਇਈਉਊਏਐਓਔਕਖਗਘਙਚਛਜਝਞਟਠਡਢਣਤਥਦਧਨਪਫਬਭਮਯਰਲਵਸਹੜ"
base = 42
