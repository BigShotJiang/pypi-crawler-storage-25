# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCÇDEËFGHIJKLMNOPQRSTUVWXYZaçdeëfghijklmnopqrstuvwxyz"
base = 54
