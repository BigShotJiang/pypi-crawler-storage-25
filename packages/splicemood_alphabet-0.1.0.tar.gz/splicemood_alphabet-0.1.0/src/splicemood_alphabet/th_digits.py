# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรลวศษสหฬอฮ0123456789"
base = 54
