# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψως0123456789"
base = 59
