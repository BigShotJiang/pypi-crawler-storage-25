# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "അആഇഈഉഊഋൠഎഏഐഒഓഔകഖഗഘങചഛജഝഞടഠഡഢണതഥദധനപഫബഭമയരലവശഷസഹളഴറ"
base = 50
