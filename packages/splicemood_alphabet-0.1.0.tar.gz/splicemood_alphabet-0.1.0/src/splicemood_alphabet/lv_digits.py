# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĀBCČDEĒFGĢHIĪJKĶLĻMNŅOPRSŠTUŪVZŽaābcčdeēfgģhiījkķlļmnņoprsštuūvzž0123456789"
base = 76
