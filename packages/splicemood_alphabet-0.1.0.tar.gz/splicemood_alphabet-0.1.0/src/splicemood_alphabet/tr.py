# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZabcçdefgğhıijklmnoöprsştuüvyz"
base = 58
