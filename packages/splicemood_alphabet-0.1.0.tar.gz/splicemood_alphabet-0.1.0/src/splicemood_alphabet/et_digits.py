# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABDEFGHIJKLMNOPRSŠZŽTUVÕÄÖÜabdefghijklmnoprsšzžtuvõäöü0123456789"
base = 64
