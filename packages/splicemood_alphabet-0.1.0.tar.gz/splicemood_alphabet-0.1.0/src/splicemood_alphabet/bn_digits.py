# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "অআইঈউঊঋএঐওঔকখগঘঙচছজঝঞটঠডঢণতথদধনপফবভমযরলশষসহৎ0123456789"
base = 54
