# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĀBCČDEĒFGĢHIĪJKĶLĻMNŅOPRSŠTUŪVZŽaābcčdeēfgģhiījkķlļmnņoprsštuūvzž"
base = 66
