# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЪЬЭЮЯЎҚҒҲабвгдеёжзийклмнопрстуфхцчшъьэюяўқғҳ"
base = 70
