# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "АБВГДЂЕЖЗИЈКЛЉМНЊОПРСТЋУФХЦЧЏШабвгдђежзијклљмнњопрстћуфхцчџш"
base = 60
