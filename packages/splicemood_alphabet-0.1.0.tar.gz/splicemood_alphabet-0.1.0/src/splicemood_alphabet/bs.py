# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCČĆDĐEFGHIJKLMNOPRSŠTUVZŽabcčćdđefghijklmnoprsštuvzž"
base = 54
