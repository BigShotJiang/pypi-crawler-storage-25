# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "అఆఇఈఉఊఋౠఎఏఐఒఓఔకఖగఘఙచఛజఝఞటఠడఢణతథదధనపఫబభమయరలవశషసహళఱ"
base = 49
