# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCĈDEFGĜHĤIJĴKLMNOPRSŜTUŬVZabcĉdefgĝhĥijĵklmnoprsŝtuŭvz"
base = 56
