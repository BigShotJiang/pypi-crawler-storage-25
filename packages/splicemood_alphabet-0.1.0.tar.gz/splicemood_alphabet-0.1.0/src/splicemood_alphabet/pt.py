# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÁÂÃÀÇÉÊÍÓÔÕÚÜabcdefghijklmnopqrstuvwxyzáâãàçéêíóôõúü"
base = 78
