# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "अआइईउऊऋएऐओऔकखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह"
base = 44
