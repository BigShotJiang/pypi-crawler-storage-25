# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "აბგდევზთიკლმნოპჟრსტუფქღყშჩცძწჭხჯჰ"
base = 33
