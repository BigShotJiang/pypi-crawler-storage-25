# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCČDEFGHIJKLMNOPRSŠTUVZŽabcčdefghijklmnoprsštuvzž0123456789"
base = 60
