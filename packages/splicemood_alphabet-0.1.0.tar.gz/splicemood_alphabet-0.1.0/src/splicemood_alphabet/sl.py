# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCČDEFGHIJKLMNOPRSŠTUVZŽabcčdefghijklmnoprsštuvzž"
base = 50
