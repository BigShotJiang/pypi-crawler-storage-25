# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCĊDEFGĠHĦIJKLMNOPQRSTUVWXYZŻabcċdefgġhħijklmnopqrstuvwxyzż"
base = 60
