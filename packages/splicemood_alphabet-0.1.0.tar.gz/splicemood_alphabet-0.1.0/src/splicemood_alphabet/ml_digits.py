# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "അആഇഈഉഊഋൠഎഏഐഒഓഔകഖഗഘങചഛജഝഞടഠഡഢണതഥദധനപഫബഭമയരലവശഷസഹളഴറ0123456789"
base = 60
