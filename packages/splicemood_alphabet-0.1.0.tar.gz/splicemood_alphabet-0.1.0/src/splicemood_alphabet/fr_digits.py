# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÀÂÆÇÉÈÊËÎÏÔŒÙÛÜŸabcdefghijklmnopqrstuvwxyzàâæçéèêëîïôœùûüÿ0123456789"
base = 94
