# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "កខគឃងចឆជឈញដឋឌឍណតថទធនបផពភមយរលវឝឞសហឡអ0123456789"
base = 45
