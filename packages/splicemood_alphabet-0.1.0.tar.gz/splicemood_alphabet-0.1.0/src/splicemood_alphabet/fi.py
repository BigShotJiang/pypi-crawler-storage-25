# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖabcdefghijklmnopqrstuvwxyzåäö"
base = 58
