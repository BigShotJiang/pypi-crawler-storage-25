# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "АБВГДЕЁЖЗИЙКЛМНОҢӨПРСТУҮФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмноңөпрстуүфхцчшщъыьэюя"
base = 72
