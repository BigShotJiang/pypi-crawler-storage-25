# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "அஆஇஈஉஊஎஏஐஒஓஔஃகஙசஞடணதநபமயரலவழளறனஜஷஸஹ0123456789"
base = 45
