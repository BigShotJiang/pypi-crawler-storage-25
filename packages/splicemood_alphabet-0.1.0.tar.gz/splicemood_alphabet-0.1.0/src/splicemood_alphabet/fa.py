# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی"
base = 33
