# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÀÉÈÍÏÓÒÚÜÇabcdefghijklmnopqrstuvwxyzàéèíïóòúüç0123456789"
base = 82
