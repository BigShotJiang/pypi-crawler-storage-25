# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AÁBDÐEÉFGHIÍJKLMNOÓPRSTUÚVXYÝÞÆÖaábdðeéfghiíjklmnoóprstuúvxyýþæö"
base = 64
