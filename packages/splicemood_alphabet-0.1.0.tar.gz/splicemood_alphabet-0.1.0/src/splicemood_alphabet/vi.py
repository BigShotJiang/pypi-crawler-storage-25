# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "AĂÂBCDĐEÊGHIKLMNOÔƠPQRSTUƯVXYaăâbcdđeêghiklmnoôơpqrstuưvxy"
base = 58
