# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
base = 52
