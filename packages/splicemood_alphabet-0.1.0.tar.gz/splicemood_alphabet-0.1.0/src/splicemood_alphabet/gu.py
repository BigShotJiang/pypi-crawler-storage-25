# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "અઆઇઈઉઊઋએઐઓઔકખગઘઙચછજઝઞટઠડઢણતથદધનપફબભમયરલવશષસહળ"
base = 45
