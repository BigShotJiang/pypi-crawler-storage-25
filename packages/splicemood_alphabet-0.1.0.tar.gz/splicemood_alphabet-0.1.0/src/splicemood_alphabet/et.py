# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "ABDEFGHIJKLMNOPRSŠZŽTUVÕÄÖÜabdefghijklmnoprsšzžtuvõäöü"
base = 54
