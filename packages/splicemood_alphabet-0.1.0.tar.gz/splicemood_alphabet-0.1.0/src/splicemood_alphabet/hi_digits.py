# AUTO-GENERATED FILE. DO NOT EDIT.

alphabet = "अआइईउऊऋएऐओऔकखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह0123456789"
base = 54
