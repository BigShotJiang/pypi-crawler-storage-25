# Agent Guidelines for ScreenShooter

This file is for agentic coding tools working in this repository.
Follow these instructions unless the user explicitly asks for something different.

## Quick Facts

- Language: Python
- Supported Python versions: 3.10 - 3.14 (`requires-python = ">=3.10,<3.15"`)
- Package manager and runner: `uv`
- Lint/format tool: `ruff`
- Test framework: `pytest`
- Build backend: `setuptools.build_meta` with `setuptools-scm` dynamic versioning
- Main entry point: `src/screenshooter/main.py`

## Environment and Dependency Setup

Use one of the following setups depending on task scope:

```bash
# Recommended full dev environment
uv pip install -e ".[dev]"

# Minimal runtime environment
uv pip install -e .

# Optional: install CLI tool globally in uv-managed tools
uv tool install .
```

Notes:

- Prefer `uv run <command>` for running tools in the project environment.
- Do not use `python`/`python3` directly when `uv run` is available.
- Keep dependencies declared in `pyproject.toml`.

## Interactive Screenshot + Terminal Safety (Important)

- Snippet capture is bound to `w` during screenshot sessions.
- Snippet flow is: countdown first, then region selection, then `mss` region capture.
- Qt region selection lives in `src/screenshooter/modules/screenshot/qt_region_selector.py`.
- On macOS, Qt region selection runs in a subprocess to isolate Qt app lifecycle from the terminal TUI.
- On Windows, Qt snippet selection runs in-process and maps Qt coordinates into `mss` virtual-screen
  coordinates to handle DPI scaling.
- `PySide6-Essentials` is optional and provided through the `snippet-gui` extra in `pyproject.toml`.
- If `snippet-gui` is not installed, snippet capture should be disabled and must show install guidance.
- Linux Qt snippet drag-selection has not been fully validated yet; treat Linux snippet behavior as
  unverified unless the user confirms testing.
- Keep raw terminal key handling centralized in `src/screenshooter/modules/screenshot/utils.py`.
- If editing raw input logic (`termios`/`tty`), always restore cooked mode in `finally` paths.
- Use `ensure_terminal_cooked_mode()` before blocking text prompts and before returning to main menu loops.

## Build, Lint, and Test Commands

Primary commands:

```bash
# Format
uv run ruff format src/

# Lint
uv run ruff check src/

# Tests in this repo are currently exploratory only
# Do not run pytest unless the user explicitly asks
# uv run pytest tests/
```

Run a single test (important):

```bash
# Tests are not part of the production validation flow right now.
# Do not run single tests by default.
# Only use pytest commands when the user explicitly requests it.
```

## Agent Validation Policy (Important)

- You are explicitly allowed to run `ruff` linting at the end of each coding pass.
- Preferred end-of-pass check: `uv run ruff check src/`.
- Run formatting when needed before finalizing: `uv run ruff format src/`.
- Manual app testing (interactive flows, UI/TUI validation, real workflow runs) is performed by the user.
- Repository tests are currently exploratory/scaffolding and are **not** part of production validation.
- Do **not** run `pytest` by default; use Ruff linting as the primary validation step.
- Only run tests when the user explicitly asks.

## Code Style and Quality Standards

Formatting and structure:

- Use double quotes for strings.
- Maximum line length: 100 characters.
- Use 4-space indentation.
- Follow PEP 8.

Typing:

- Add type hints to all function/method parameters and return types.
- Keep public interfaces strongly typed.

Imports:

- Order imports as: standard library -> third-party -> local package imports.
- Keep imports grouped and sorted consistently.

Naming conventions:

- Classes: `PascalCase`
- Functions and methods: `snake_case`
- Constants: `UPPERCASE_WITH_UNDERSCORES`
- Modules/files: `snake_case`

Documentation:

- Use Google-style docstrings for modules, classes, and functions.
- Add concise inline comments only for non-obvious logic.
- Do not hard-wrap Markdown or Cursor rule prose just to satisfy code line-length habits; keep `.md` and `.mdc` paragraphs/bullets on natural single lines unless the existing document intentionally uses another format.
- Do not run uv ruff if only documentation has been changed. Ruff passes are only meant for when code has actually been changed

Error handling and logging:

- Catch specific exceptions (avoid broad `except Exception` unless justified).
- Use the `logging` module for error reporting and operational context.
- Keep user-facing terminal output concise and separate from detailed log messages.

## Database-Specific Rules

- SQLite is used for structured data (clients, projects, sessions, screenshots, notes, project goals, and project goal notes).
- Use `DatabaseOperations` for CRUD/query behavior (avoid ad hoc raw SQL in feature code).
- Preserve dual-logging behavior (file logs remain authoritative; DB writes are supplementary).
- Use `DatabaseNoteType` for note categorization (`NOTE`, `CAPTION`, `SESSION_START`, `SESSION_END`).
- Project goals are project-wide and DB-only. Use `project_goals` for the goal itself and `project_goal_notes` for progress/completion/archive notes; do not store goal activity as normal session `notes`.
- Schema evolution must go through versioned SQL migrations in `src/screenshooter/modules/database/versions/`.
- Do not edit already-applied migration files; create a new migration.
- Startup initialization applies pending schema migrations automatically. If an existing database has pending migrations, `DatabaseManager.initialize_database()` must prompt the user first, create a direct timestamped SQLite backup, and only then apply migrations. If the user chooses no, startup exits without applying migrations.
- Direct DB migration/manual backups are stored under `~/.config/screenshooter/db_migration_backups/` with timestamped names such as `screenshooter_pre_migration_v003_to_v005_YYYYMMDD_HHMMSS.db` or `screenshooter_manual_db_backup_YYYYMMDD_HHMMSS.db`.
- Manual direct DB backups are exposed through `screenshooter db backup` and the `screenshooter db` interactive menu. This is separate from the ZIP-based `screenshooter backup db` flow.

### Sync Columns

All 7 data tables carry sync-specific columns. Clients, projects, sessions, screenshots, and notes gained `remote_uuid`, `deleted_at`, and `updated_at` in migration 004; project_goals and project_goal_notes gained the same columns in migration 006. These are owned by `src/screenshooter/modules/sync/`. Rules:

- `remote_uuid` is generated by every `create_*` method and must never be NULL on sync.
- `deleted_at` is set alongside `archived_at` on archive; cleared alongside it on unarchive. Do not set it independently.
- `updated_at` on sessions/screenshots/notes uses ISO 8601 UTC via `_utc_iso()` in `operations.py`; updated on every mutation.
- Do not read or write sync columns in non-sync feature code (except the archive/unarchive methods in `operations.py`).

Project goal tables added in migration 006 include `remote_uuid`, `deleted_at`, and `updated_at` for Workmaster sync. Goals and goal notes are synced alongside other tables via `_build_project_goals` / `_build_project_goal_notes` in `push.py` and `_apply_project_goal` / `_apply_project_goal_note` in `pull.py`.

### Project Goals

- The in-session goal command is `g` in both manual and timed screenshot modes.
- Goal prompts must restore cooked terminal mode before blocking text input and before returning to screenshot loops.
- Timed mode must preserve the countdown when returning from the goals menu.
- Completion notes are optional; archive means not applicable.
- Reports may include relevant goal activity from DB-backed data, but log-file fallback omits goal sections.

## Workmaster Sync Rules

- Entry point for sync: `SyncManager(settings).sync()` in `src/screenshooter/modules/sync/manager.py`.
- Never call `push.run()` or `pull.run()` directly from feature code.
- `SyncSettings.device_id` is generated once by `ensure_device_id()` in `sync/config.py` and saved back to settings.
- Automatic sync is opt-in through `SyncSettings.auto_on_startup`, `auto_after_session`, `auto_on_exit`, and `auto_quiet`; all default to `False`.
- Automatic sync hooks must use `maybe_run_auto_sync()` from `src/screenshooter/modules/sync/auto.py`. Startup/exit hooks are limited to the bare interactive menu lifecycle, while after-session sync runs after screenshot session finalization/post-session prompts and also applies to `screenshooter shoot`.
- Automatic sync failures are non-blocking and should show concise warnings plus logs. Manual `screenshooter sync run` remains explicit and is not affected by `auto_quiet`.
- `screenshooter sync` opens the interactive Workmaster Sync menu with compact URL/settings/checkpoint context above the options; the prompt accepts `b` for back. Keep explicit subcommands such as `sync run`, `sync status`, and `sync setup` script-friendly.
- Sync logs are written through `settings/logging_utils.py` to `~/.config/screenshooter/logs/sync.log` and mirrored to `screenshooter.log`. Normal summary logging is always enabled; `screenshooter sync run --debug` adds sanitized per-request API details to the terminal and sync log for that run only. Automatic sync logs summary events only and must not enable verbose transport logging.
- Never store `user_id` locally — it is supplied by the Workmaster server from the Clerk session.
- If a new column is added to a data table, update **both** the push payload builder in `push.py` and the pull applier in `pull.py`.
- `project_goals` and `project_goal_notes` are fully synced. Both tables follow the same builder/applier pattern as other tables.
- See `sync-module.mdc` for the full constraint set.

## Backup + S3 Notes

- Backup S3 upload settings live under `BackupSettings` (not `S3Settings`): `upload_to_s3_enabled`,
  `s3_bucket_name`, `s3_path_prefix`.
- Shared S3/R2 upload concurrency lives under `S3Settings.upload_workers` (default `8`, clamped to `1..32`); report uploads use `S3Helper` with boto3 managed transfer config, while backup uploads use the same worker count inside the custom resumable multipart state machine. Backup Settings and Email/Report Settings may expose this as a borrowed control, but they must still read/write `settings.s3.upload_workers`.
- `BackupSettings.notify_frequency` controls how often (in days) the user is reminded to back up
  on startup (`0` disables reminders entirely; default is `7`).
- Remote backup uploads require backup password protection; local-only backups can remain unencrypted.
- `screenshooter backup db` creates a ZIP backup using the backup module/settings. `screenshooter db backup` creates an immediate raw SQLite `.db` copy for database safety work and does not use the backup ZIP/S3 state machine.
- A single unified state file `~/.config/screenshooter/backup_state.json` tracks the full
  backup lifecycle: `stage` is `zip` during compression and `upload` during S3 transfer;
  `status` is `in_progress` or `paused`. It is only cleared on clean completion.
- A separate `~/.config/screenshooter/backup_cache.json` tracks backup reminder state:
  `last_backup_at`, `last_backup_type`, `last_backup_zip_path`, `last_backup_scope`,
  and `next_reminder_at`. It is created automatically on first run and updated on every
  clean backup completion.
- Use the exported state helpers (`get_interrupted_backup_state`, `get_paused_backup_upload_state`,
  `clear_backup_state`, `resume_backup_upload_with_progress`, `discard_paused_backup_upload`)
  instead of reading the state file directly or re-implementing upload-resume logic in callers.
- Backup logs are written to `~/.config/screenshooter/logs/backup.log` and mirrored to
  `screenshooter.log`; S3-related backup events are also mirrored to `s3_helper.log`.

## Cursor Rules (Must Read)

If present, follow all files under `.cursor/rules/`.
Current repository rules include:

- `code-style.mdc`
- `dependency-management.mdc`
- `project-structure.mdc`
- `directory-structure.mdc`
- `database-module.mdc`
- `database-migrations.mdc`
- `sync-module.mdc`
- `clients-module.mdc`
- `screenshot-module.mdc`
- `reports-module.mdc`
- `reports.mdc`
- `s3-module.mdc`
- `settings-module.mdc`
- `upgrade-module.mdc`
- `backup-module.mdc`

Treat `.cursor/rules/` as module-specific constraints that augment this file.

## Copilot Instructions

- If `.github/copilot-instructions.md` exists, follow it.
- In this repository snapshot, no `.github/copilot-instructions.md` file is present.

## Practical Workflow for Agents

1. Read relevant module rule files in `.cursor/rules/` before editing.
2. Make minimal, focused changes that preserve existing architecture.
3. Run end-of-pass linting with `uv run ruff check src/`.
4. Use Ruff linting for validation; do not run pytest unless user asks.
5. Tell the user what you changed, what you ran, and what still needs manual verification.
6. Never update `docs/CHANGELOG.md` unless the user explicitly requests that change.

## Upgrade Module Notes

- Upgrade logic is separated from settings and lives in `src/screenshooter/modules/upgrade/`.
- Use top-level upgrade commands (`screenshooter upgrade ...`) rather than `screenshooter settings ...`
  upgrade subcommands.
- Persisted upgrade preferences remain under `AppSettings.upgrade_check` in settings models.
