"""ScreenShooter - A sophisticated screenshot cross-platform screenshot tool."""

from screenshooter.versioning import get_runtime_version

__version__ = get_runtime_version()

# Available modules
# - main: Main entry point with interactive menu
# - modules.client: Client management functionality
# - modules.screenshot: Screenshot capture functionality
# - modules.report: PDF report generation and email
