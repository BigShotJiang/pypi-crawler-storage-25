#!/usr/bin/env python3
"""ScreenShooter - Main Menu Interface."""

import builtins
import logging
import platform
import signal  # Handle SIGINT early during import to exit gracefully
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import click
from packaging import version as pkg_version
from rich.console import Console
from rich.panel import Panel

from screenshooter import __version__
from screenshooter.modules.backup import (
    clear_backup_state,
    discard_paused_backup_upload,
    get_backup_log_file,
    get_interrupted_backup_state,
    get_or_create_backup_cache,
    get_paused_backup_upload_state,
    handle_paused_backup_upload_interactive,
    perform_backup,
    resume_backup_upload_with_progress,
    save_backup_cache,
)
from screenshooter.modules.database import (
    DatabaseManager,
    DatabaseMigrator,
    DatabaseOperations,
    get_database_manager,
)
from screenshooter.modules.database.cli import database as database_cli
from screenshooter.modules.reports.report_cli import interactive_report_generation
from screenshooter.modules.screenshot.main import main as screenshot_main
from screenshooter.modules.screenshot.utils import ensure_terminal_cooked_mode
from screenshooter.modules.settings.logging_utils import LOGS_DIR
from screenshooter.modules.settings.main import run_backup_options_screen
from screenshooter.modules.settings.settings_helper import (
    get_config_dir,
    get_screenshots_dir,
    get_settings,
    reload_settings,
    save_settings,
    should_use_database,
)
from screenshooter.modules.sync.auto import AutoSyncTrigger, maybe_run_auto_sync
from screenshooter.modules.sync.cli import sync as sync_cli
from screenshooter.modules.upgrade.checker import show_simple_upgrade_notification
from screenshooter.modules.upgrade.cli import upgrade as upgrade_cli

# Configure logging
logger = logging.getLogger(__name__)


def _handle_sigint(signum: int, frame: Any) -> None:
    """Handle SIGINT and restore terminal mode before exiting."""
    _ = signum, frame
    ensure_terminal_cooked_mode()
    sys.exit(0)


signal.signal(signal.SIGINT, _handle_sigint)

# Initialize rich console
console = Console()


def _open_path_cross_platform(path: Path) -> bool:
    """Open a path (file or directory) with the default system handler."""
    system = platform.system()
    target = str(path)

    try:
        if system == "Darwin":
            return subprocess.run(["open", target], check=False).returncode == 0
        if system == "Linux":
            return subprocess.run(["xdg-open", target], check=False).returncode == 0
        if system == "Windows":
            subprocess.Popen(["start", "", target], shell=True)
            return True
    except Exception:
        return False

    return False


def prompt_ask_on_new_line(prompt_text: str, **kwargs: Any) -> str:
    """Prompt with choices/default shown on one line, input on a clean `> ` line below."""
    ensure_terminal_cooked_mode()
    choices = kwargs.get("choices")
    hidden_choices = kwargs.get("hidden_choices") or []
    default = kwargs.get("default")

    # Render the full question with choices/default on the first line
    if choices:
        choices_str = "/".join(str(c) for c in choices)
        # Escape opening bracket so Rich doesn't treat choices as markup tags.
        extra = f" \\[{choices_str}]"
        if default is not None:
            extra += f" ({default})"
        console.print(f"{prompt_text}{extra}:")
    else:
        console.print(f"{prompt_text}:")

    # Simple loop with validation instead of relying on rich.Prompt for layout
    while True:
        raw = input("> ").strip()
        if not raw and default is not None:
            raw = str(default)
        if choices:
            visible_choice_values = [str(c) for c in choices]
            hidden_choice_values = [str(c) for c in hidden_choices]
            if raw in visible_choice_values + hidden_choice_values:
                return raw
            console.print(
                f"[red]Invalid choice: {raw}. Please enter one of: "
                f"{', '.join(str(c) for c in choices)}[/red]"
            )
            continue
        return raw


MENU_OPTIONS = [
    {
        "id": "1",
        "name": "Take Screenshots",
        "description": "Capture screenshots manually or on a timer",
    },
    {
        "id": "2",
        "name": "Manage Clients/Projects",
        "description": "Create, edit, or view clients/projects",
    },
    {
        "id": "3",
        "name": "Generate Reports",
        "description": "Generate PDF reports from screenshot sessions",
    },
    {"id": "4", "name": "Settings", "description": "Configure application settings"},
    {"id": "5", "name": "Help", "description": "View help information"},
    {"id": "6", "name": "Exit", "description": "Exit the application"},
]


def display_menu() -> str:
    """Display the main menu and get user choice."""
    console.print("\n[bold]ScreenShooter[/bold]", style="bold blue")
    console.print("===================\n")

    # Show beta notice for Linux and Windows platforms
    current_platform = platform.system().lower()
    if current_platform in ["linux", "windows"]:
        platform_name = "Linux" if current_platform == "linux" else "Windows"
        console.print(f"[yellow]ScreenShooter is currently in beta for {platform_name}[/yellow]\n")

    # Display menu options
    for option in MENU_OPTIONS:
        console.print(f"[bold]{option['id']}.[/bold] {option['name']} - {option['description']}")

    # Get user choice
    choice = prompt_ask_on_new_line(
        "\nPlease select an option or press e for extra options",
        choices=[option["id"] for option in MENU_OPTIONS] + ["e"],
        hidden_choices=["0", "q"],
        default="1",
    )

    return choice


def display_extra_options_menu() -> str:
    """Display hidden extra options menu and get user choice."""
    console.print("\n[bold]Extra Options[/bold]", style="bold blue")
    console.print("=============\n")
    extra_options = [
        {
            "id": "1",
            "name": "Database",
            "description": "Manage database status, backups, migrations and verification",
        },
        {
            "id": "2",
            "name": "Upgrade",
            "description": "Check for updates and manage upgrade settings",
        },
        {
            "id": "3",
            "name": "Sync",
            "description": "Run or configure Workmaster sync",
        },
        {
            "id": "4",
            "name": "Backup",
            "description": "Create settings, database, or full data backups",
        },
        {
            "id": "5",
            "name": "Logs",
            "description": "Open the ScreenShooter logs directory",
        },
    ]

    for option in extra_options:
        console.print(f"[bold]{option['id']}.[/bold] {option['name']} - {option['description']}")

    return prompt_ask_on_new_line(
        "\nSelect an option or press b to go back",
        choices=[option["id"] for option in extra_options] + ["b"],
        hidden_choices=["q"],
        default="1",
    )


def display_upgrade_extra_menu() -> str:
    """Display hidden upgrade options menu and get user choice."""
    console.print("\n[bold]Upgrade Options[/bold]", style="bold blue")
    console.print("===============\n")
    console.print("1. Check for updates")
    console.print("2. Show upgrade status")
    console.print("3. Upgrade settings")

    return prompt_ask_on_new_line(
        "\nSelect an option or press b to go back",
        choices=["1", "2", "3", "b"],
        hidden_choices=["q"],
        default="1",
    )


def _pause_after_extra_action() -> None:
    """Wait for Enter after a hidden menu action."""
    ensure_terminal_cooked_mode()
    input("\nPress Enter to continue...")


def run_upgrade_extra_menu() -> bool:
    """Run hidden upgrade options menu.

    Returns:
        bool: True if the caller should return to extras, False if the app should exit.
    """
    while True:
        ensure_terminal_cooked_mode()
        choice = display_upgrade_extra_menu()

        if choice == "b":
            return True

        if choice == "q":
            return False

        try:
            if choice == "1":
                upgrade_cli.main(args=["check"], standalone_mode=False)
                _pause_after_extra_action()
                continue

            if choice == "2":
                upgrade_cli.main(args=["status"], standalone_mode=False)
                _pause_after_extra_action()
                continue

            if choice == "3":
                console.print("[dim]Opening Settings. Upgrade settings are on page 2.[/dim]")
                run_settings_module([])
                _pause_after_extra_action()
                continue
        except Exception as e:
            console.print(f"[bold red]Error running extra option: {e}[/bold red]")
            _pause_after_extra_action()


def run_extra_options_menu(*, debug: bool = False) -> bool:
    """Run hidden extra options menu.

    Returns:
        bool: True if the caller should return to the main menu, False if the app should exit.
    """
    while True:
        ensure_terminal_cooked_mode()
        choice = display_extra_options_menu()

        if choice == "b":
            return True

        if choice == "q":
            return False

        try:
            if choice == "1":
                database_cli.main(args=[], standalone_mode=False)
                continue

            if choice == "2":
                if not run_upgrade_extra_menu():
                    return False
                continue

            if choice == "3":
                sync_cli.main(args=[], standalone_mode=False)
                continue

            if choice == "4":
                backup_args = ["--debug"] if debug else []
                backup.main(args=backup_args, standalone_mode=False)
                continue

            if choice == "5":
                logs.main(standalone_mode=False)
                _pause_after_extra_action()
                continue
        except Exception as e:
            console.print(f"[bold red]Error running extra option: {e}[/bold red]")
            _pause_after_extra_action()


def run_screenshot_module(args: list[str] | None = None) -> int:
    """Run the screenshot capturing module.

    Returns:
        int: 1 if the caller should return to the main menu, 0 if the app should exit.
    """
    try:
        ensure_terminal_cooked_mode()
        # Build click args list; default to interactive when no args
        click_args: builtins.list[str] = args or []

        # Call click command in non-standalone mode to avoid sys.exit
        result: int | None = None
        try:
            result = screenshot_main.main(args=click_args, standalone_mode=False)
        except SystemExit:
            # Defensive: in case standalone mode toggles elsewhere - treat as exit
            return 0

        # Default to returning to main menu when result is not an int
        return int(result) if isinstance(result, int) else 1

    except Exception as e:
        console.print(f"[bold red]Error running screenshot module: {e}[/bold red]")
        # On error, return to main menu to avoid dropping the user
        return 1
    finally:
        ensure_terminal_cooked_mode()


def run_client_module(args: list[str] | None = None) -> None:
    """Run the client management module."""
    command = [sys.executable, "-m", "screenshooter.modules.clients"]

    if args:
        command.extend(args)

    try:
        subprocess.run(command, check=False)
    except Exception as e:
        console.print(f"[bold red]Error running client module: {e}[/bold red]")


def run_report_module(args: list[str] | None = None) -> bool:
    """Run the report generation module.

    Returns:
        bool: True if should return to main menu, False if should exit
    """
    # Direct module execution approach
    command = [sys.executable, "-m", "screenshooter.modules.reports.report"]

    if args:
        command.extend(args)

    try:
        # Process args into a dict format that interactive_report_generation expects
        cli_args = {}
        if args:
            # Basic parsing of args for common parameters
            # This is a simplified version and may need to be expanded
            i = 0
            while i < len(args):
                if args[i].startswith("--"):
                    param = args[i][2:]  # Remove '--' prefix
                    if i + 1 < len(args) and not args[i + 1].startswith("--"):
                        cli_args[param] = args[i + 1]
                        i += 2
                    else:
                        cli_args[param] = True  # Flag parameter
                        i += 1
                else:
                    i += 1

        # A debug-only invocation should keep the interactive report flow.
        command_line_args = {key: value for key, value in cli_args.items() if key != "debug"}

        # Run the report generator directly with processed args
        result = interactive_report_generation(
            use_command_line=bool(command_line_args),
            cli_args=cli_args,
        )

        # If result is 1, it means user wants to return to main menu
        return result == 1
    except Exception as e:
        console.print(f"[bold red]Error running report module: {e}[/bold red]")
        return True  # On error, return to main menu


def run_settings_module(args: list[str] | None = None) -> int:
    """Run the settings module and return its exit code."""
    command = [sys.executable, "-m", "screenshooter.modules.settings.main"]

    if args:
        command.extend(args)

    try:
        result = subprocess.run(command, check=False)
        return result.returncode
    except Exception as e:
        console.print(f"[bold red]Error running settings module: {e}[/bold red]")
        return 1


def display_help() -> None:
    """Display help information."""
    help_text = """
    [bold]ScreenShooter[/bold] is a sophisticated screenshot tool with timer support
    and organization features.
    
    [bold]Commands:[/bold]
    • screenshooter - Interactive menu
    • screenshooter clients - List all clients
    • screenshooter client "ClientName" - Manage specific client
    • screenshooter client "ClientName" projects - List projects for a client
    • screenshooter shoot --client "Name" --project "Project" - Start screenshots
    • screenshooter report - Interactive report generator
    • screenshooter --debug report - Interactive report generator with report debug logging
    • screenshooter report generate --client "Name" --project "Project" - Generate specific report
    • screenshooter settings - Manage application settings
    • screenshooter sync - Workmaster sync menu
    • screenshooter sync setup - Configure Workmaster sync and optional automatic sync
    • screenshooter sync status - Show Workmaster sync status and automatic sync settings
    • screenshooter sync run - Run one Workmaster sync cycle
    • screenshooter sync run --debug - Show sanitized sync request/response details
    • screenshooter upgrade - Manage upgrade checks and notifications
    • screenshooter settings export/import/reset - Settings file operations
    
    [bold]Key Features:[/bold]
    • Take screenshots of all screens, main screen, second screen, or selected window
    • Timer support for automatic screenshots
    • Organize screenshots by client and project
    • Session-based organization with timestamps
    • Add notes and captions to screenshots
    • Generate PDF reports from screenshot sessions
    • Configurable settings for email, storage, notifications and more
    
    [bold]Getting Started:[/bold]
    1. Use 'screenshooter settings' to configure application settings
    2. Use 'screenshooter clients' to create and manage clients
    3. Use 'screenshooter shoot --client "Name" --project "Project"' to begin capturing
    4. Use 'screenshooter report' to create PDFs of your sessions
    """

    console.print(Panel(help_text, title="Help & Information"))
    input("\nPress Enter to continue...")


def print_usage() -> None:
    """Display command-line usage."""
    console.print("\n[bold]ScreenShooter - Command Usage[/bold]")
    console.print("=====================================")
    console.print("\nCommands:")
    console.print("  [bold]clients[/bold]                             List all clients")
    console.print('  [bold]client[/bold] "ClientName"                 Manage specific client')
    console.print(
        '  [bold]client[/bold] "ClientName" [bold]projects[/bold]      List projects for a client'
    )
    console.print('  [bold]shoot[/bold] --client "Name" --project "Proj"  Take screenshots')
    console.print("    Options:")
    console.print("      --timer N                       Take screenshots every N minutes")
    console.print("      --mode [all|main|second|window] Screenshot mode")
    console.print("  [bold]report[/bold]                             Interactive report generator")
    console.print(
        "  [bold]--debug report[/bold]                     Report generator with debug logs"
    )
    console.print(
        '  [bold]report generate[/bold] --client "Name" --project "Proj"  Generate specific report'
    )
    console.print("  [bold]settings[/bold]                           Manage application settings")
    console.print("  [bold]sync[/bold]                               Workmaster sync menu")
    console.print("  [bold]sync setup[/bold]                         Configure sync and auto-sync")
    console.print(
        "  [bold]sync status[/bold]                        Show sync and auto-sync status"
    )
    console.print("  [bold]sync run[/bold]                           Run one Workmaster sync cycle")
    console.print("  [bold]sync run --debug[/bold]                   Show sync request details")
    console.print("  [bold]backup TYPE --debug[/bold]                Show backup event details")
    console.print("  [bold]--debug backup TYPE[/bold]                Show backup event details")
    console.print("  [bold]upgrade[/bold]                            Manage upgrade checks")
    console.print("  [bold]settings reset[/bold]                     Reset settings to defaults")
    console.print("  [bold]settings export[/bold] FILENAME           Export settings to JSON file")
    console.print(
        "  [bold]settings import[/bold] FILENAME           Import settings from JSON file"
    )
    console.print("  [bold]open logs|config[/bold]                  Open logs or config directory")
    console.print("  [bold]db[/bold]                                 Database management commands")
    console.print(
        "  [bold]backup[/bold] TYPE [--outputdir DIR] [--scope active-only|all]  "
        "Create a backup (settings, db, all)"
    )
    console.print("  [bold]help[/bold]                               Show this help message")
    console.print("\nRun any command with --help for more information")


def _is_non_mainline_version(version_text: str) -> bool:
    """Return True when version appears to be a dev/prerelease build."""
    try:
        parsed = pkg_version.parse(version_text)
    except pkg_version.InvalidVersion:
        return "dev" in version_text.lower()

    if not isinstance(parsed, pkg_version.Version):
        return False

    return parsed.is_devrelease or parsed.is_prerelease or parsed.local is not None


def _suggest_dev_branch(version_text: str) -> str | None:
    """Suggest a version branch name from current package version."""
    try:
        parsed = pkg_version.parse(version_text)
    except pkg_version.InvalidVersion:
        return None

    if not isinstance(parsed, pkg_version.Version):
        return None

    if parsed.is_devrelease or parsed.is_prerelease:
        return f"v{parsed.base_version}"

    return None


def _maybe_prompt_switch_to_dev_channel() -> None:
    """Prompt once to switch update channel when running a dev build."""
    settings = get_settings()
    upgrade_settings = settings.upgrade_check

    if upgrade_settings.channel == "dev":
        return
    if upgrade_settings.dev_channel_prompted:
        return
    if not _is_non_mainline_version(__version__):
        return

    suggested_branch = _suggest_dev_branch(__version__) or upgrade_settings.dev_branch or "main"
    choice = prompt_ask_on_new_line(
        "You're currently on a development build. "
        f"Switch upgrade checks to dev channel for branch '{suggested_branch}'?",
        choices=["y", "n"],
        default="y",
    )

    if choice == "y":
        upgrade_settings.channel = "dev"
        if (upgrade_settings.dev_branch or "main") == "main":
            upgrade_settings.dev_branch = suggested_branch
        console.print(
            f"[green]Upgrade channel set to dev (branch: {upgrade_settings.dev_branch})[/green]"
        )
        console.print(
            "[dim]You can change this any time with: "
            "screenshooter upgrade branch <branch-name>[/dim]"
        )

    upgrade_settings.dev_channel_prompted = True
    save_settings(settings)


def _backup_prompt(label_r: str) -> str:
    """Prompt for backup recovery action. No default — Enter alone re-prompts."""
    prompt_text = (
        f"[bold]\\[D][/bold] Dismiss  [bold]\\[R][/bold] {label_r}  [bold]\\[L][/bold] View log"
    )
    return prompt_ask_on_new_line(prompt_text, choices=["d", "r", "l"]).strip().lower()


def _handle_interrupted_zip_on_startup(state: dict, *, debug: bool = False) -> None:
    """Interactive handler for a backup interrupted during ZIP creation."""
    backup_type = str(state.get("backup_type") or "unknown")
    file_scope = str(state.get("file_scope") or "all")
    verbosity = str(state.get("verbosity") or "full")
    started_at = str(state.get("started_at") or "unknown")
    zip_path = Path(str(state.get("zip_path") or ""))

    scope_label = f" ({file_scope})" if backup_type == "all" else ""
    console.print("\n[yellow bold]Backup interrupted during compression[/yellow bold]")
    console.print(f"  Type:    {backup_type}{scope_label}")
    console.print(f"  Started: {started_at}")
    if zip_path.name:
        console.print(f"  Output:  {zip_path}")
    console.print("")

    while True:
        key = _backup_prompt("Retry")

        if key == "l":
            _open_path_cross_platform(get_backup_log_file())
            console.print("")
            continue

        if key == "d":
            if zip_path.exists():
                try:
                    zip_path.unlink()
                except OSError:
                    pass
            clear_backup_state()
            console.print("[dim]Backup notice dismissed.[/dim]")
            return

        if key == "r":
            if zip_path.exists():
                try:
                    zip_path.unlink()
                except OSError:
                    pass
            clear_backup_state()
            output_dir = str(zip_path.parent) if zip_path.parent.exists() else None
            console.print("\n[bold]Retrying backup...[/bold]")
            try:
                result_path = perform_backup(
                    backup_type,
                    output_dir,
                    verbosity=verbosity,
                    file_scope=file_scope,
                    debug_logging=debug,
                )
                console.print(f"[green]Backup created:[/green] {result_path}")
            except Exception as exc:
                console.print(f"[bold red]Backup failed:[/bold red] {exc}")
            console.print(f"[dim]Backup log:[/dim] {get_backup_log_file()}")
            sys.exit(0)


def _handle_paused_upload_on_startup(state: dict) -> None:
    """Interactive handler for a backup upload paused mid-transfer."""
    backup_type = str(state.get("backup_type") or "unknown")
    zip_path = Path(str(state.get("zip_path") or ""))
    object_key = str(state.get("object_key") or "(unknown)")
    uploaded_parts = len(state.get("parts") or [])
    total_parts = int(state.get("total_parts") or 0)
    started_at = str(state.get("started_at") or "unknown")

    console.print("\n[yellow bold]Backup upload paused[/yellow bold]")
    console.print(f"  Type:     {backup_type}")
    if zip_path.name:
        console.print(f"  File:     {zip_path.name}")
    console.print(f"  Progress: {uploaded_parts}/{total_parts} parts")
    console.print(f"  Key:      {object_key}")
    console.print(f"  Started:  {started_at}")
    console.print("")

    while True:
        key = _backup_prompt("Resume")

        if key == "l":
            _open_path_cross_platform(get_backup_log_file())
            console.print("")
            continue

        if key == "d":
            _, message = discard_paused_backup_upload()
            console.print(f"[dim]{message}[/dim]")
            return

        if key == "r":
            console.print("")
            resumed, message = resume_backup_upload_with_progress(console)
            if resumed:
                console.print(f"[green]{message}[/green]")
            else:
                console.print(f"[yellow]{message}[/yellow]")
            console.print(f"[dim]Backup log:[/dim] {get_backup_log_file()}")
            sys.exit(0)


def _check_backup_state_on_startup(*, debug: bool = False) -> None:
    """Interactively handle any interrupted or paused backup before startup continues."""
    try:
        interrupted = get_interrupted_backup_state()
        if interrupted:
            _handle_interrupted_zip_on_startup(interrupted, debug=debug)
            return

        paused = get_paused_backup_upload_state()
        if paused:
            _handle_paused_upload_on_startup(paused)
    except Exception as e:
        logger.debug(f"Backup state startup check failed: {e}")


def _check_for_updates_on_startup() -> None:
    """Run upgrade check without interrupting app startup."""
    try:
        settings = get_settings()
        if not settings.upgrade_check.enabled:
            return
        _maybe_prompt_switch_to_dev_channel()
        show_simple_upgrade_notification(console)
    except Exception as e:
        logger.debug(f"Upgrade check failed: {e}")


def _handle_backup_reminder_prompt(settings, cache, days_since, *, debug: bool = False) -> None:
    """Show the blocking backup reminder prompt until the user decides."""
    console.print("\n[yellow bold]Backup reminder[/yellow bold]")
    console.print(f"You haven't backed up in {days_since} day(s).")
    console.print("")

    notify_frequency = getattr(settings.backup, "notify_frequency", 7)

    while True:
        freq_label = f"Remind in {notify_frequency} days"
        prompt_text = (
            f"[bold]\\[D][/bold] Do Not Show Again  [bold]\\[R][/bold] {freq_label}"
            f"  [bold]\\[B][/bold] Backup Now"
        )
        raw = prompt_ask_on_new_line(prompt_text, choices=["d", "r", "b"]).strip().lower()

        if raw == "d":
            settings.backup.notify_frequency = 0
            save_settings(settings)
            cache["next_reminder_at"] = None
            save_backup_cache(cache)
            console.print("[dim]Backup reminder dismissed.[/dim]")
            return

        if raw == "r":
            days = notify_frequency
            next_at = datetime.now() + timedelta(days=days)
            cache["next_reminder_at"] = next_at.replace(
                hour=0, minute=0, second=0, microsecond=0
            ).isoformat()
            save_backup_cache(cache)
            console.print(f"[dim]Reminder scheduled in {days} day(s).[/dim]")
            return

        if raw == "b":
            run_backup_options_screen(debug_logging=debug)
            sys.exit(0)


def _check_backup_reminder_on_startup(*, debug: bool = False) -> None:
    """Check if a backup reminder is due and prompt the user interactively."""
    try:
        settings = get_settings()
        notify_frequency = getattr(settings.backup, "notify_frequency", 7)
        if notify_frequency == 0:
            return

        cache = get_or_create_backup_cache()
        next_reminder_str = cache.get("next_reminder_at")
        if not next_reminder_str:
            if notify_frequency > 0:
                next_reminder = datetime.now() + timedelta(days=notify_frequency)
                cache["next_reminder_at"] = next_reminder.replace(
                    hour=0, minute=0, second=0, microsecond=0
                ).isoformat()
                save_backup_cache(cache)
            else:
                return

        next_reminder = datetime.fromisoformat(cache["next_reminder_at"])
        if datetime.now() < next_reminder:
            return

        last_backup_str = cache.get("last_backup_at")
        if last_backup_str:
            last_backup = datetime.fromisoformat(last_backup_str)
            days_since = (datetime.now() - last_backup).days
        else:
            days_since = "unknown"

        _handle_backup_reminder_prompt(settings, cache, days_since, debug=debug)
    except Exception as e:
        logger.debug(f"Backup reminder check failed: {e}")


def _maybe_migrate_database_from_logs() -> None:
    """Offer one-time log-file migration after database initialization."""
    if (
        prompt_ask_on_new_line(
            "Do you want to import existing log data into the database?",
            choices=["y", "n"],
            default="y",
        )
        != "y"
    ):
        return

    console.print("Migrating data from log files...")
    try:
        db_ops = DatabaseOperations()
        migrator = DatabaseMigrator(db_ops)
        migrator.migrate_all_data(Path(get_screenshots_dir()))
        console.print("[green]Data migration completed successfully.[/green]")
    except Exception as e:
        console.print(f"[red]Data migration failed: {e}[/red]")
        logging.error(f"Data migration failed: {e}")


def _ensure_database_ready_for_menu() -> bool:
    """Ensure database exists when database-backed mode is enabled."""
    if not should_use_database():
        return True

    try:
        provisional_manager = DatabaseManager()
        db_path = provisional_manager.db_path
        if db_path.exists():
            get_database_manager()
            return True

        console.print(f"\n[yellow]Warning: Database file not found at {db_path}.[/yellow]")
        create_database = prompt_ask_on_new_line(
            "Do you want to create the database now?",
            choices=["y", "n"],
            default="y",
        )
        if create_database != "y":
            console.print(
                "[yellow]Database is required when configured as data source. Exiting.[/yellow]"
            )
            return False

        console.print("Initializing database...")
        get_database_manager()
        console.print("[green]Database created successfully.[/green]")
        _maybe_migrate_database_from_logs()
        return True
    except Exception as e:
        if "Database migration cancelled by user" in str(e):
            console.print("[yellow]Database updates cancelled. Exiting.[/yellow]")
            return False
        logging.error(f"Failed to check database existence: {e}")
        return True


def _run_interactive_menu_loop(debug: bool = False) -> None:
    """Run interactive menu until the user exits."""
    exit_sync_ran = False

    def run_exit_sync_once() -> None:
        nonlocal exit_sync_ran
        if exit_sync_ran:
            return
        exit_sync_ran = True
        maybe_run_auto_sync(AutoSyncTrigger.EXIT, console=console)

    while True:
        ensure_terminal_cooked_mode()
        choice = display_menu()

        if choice in ("0", "e"):
            if not run_extra_options_menu(debug=debug):
                run_exit_sync_once()
                console.print("[bold green]Thank you for using ScreenShooter![/bold green]")
                return
            continue

        if choice == "q":
            run_exit_sync_once()
            console.print("[bold green]Thank you for using ScreenShooter![/bold green]")
            return

        if choice == "1":
            result = run_screenshot_module()
            if result == 0:
                run_exit_sync_once()
                console.print("[bold green]Thank you for using ScreenShooter![/bold green]")
                return
            continue

        if choice == "2":
            run_client_module()
            continue

        if choice == "3":
            report_args = ["--debug"] if debug else None
            if not run_report_module(report_args):
                run_exit_sync_once()
                return
            continue

        if choice == "4":
            run_settings_module()
            continue

        if choice == "5":
            display_help()
            continue

        if choice == "6":
            run_exit_sync_once()
            console.print("[bold green]Thank you for using ScreenShooter![/bold green]")
            return


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="screenshooter")
@click.option("--debug", is_flag=True, help="Enable debug logging for menu-launched workflows")
@click.pass_context
def cli(ctx, debug):
    """ScreenShooter - A sophisticated screenshot cross-platform screenshot tool."""
    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug

    _check_backup_state_on_startup(debug=debug)
    _check_for_updates_on_startup()
    _check_backup_reminder_on_startup(debug=debug)

    # If no subcommand is provided, show menu
    if ctx.invoked_subcommand is None:
        if not _ensure_database_ready_for_menu():
            sys.exit(1)
        maybe_run_auto_sync(AutoSyncTrigger.STARTUP, console=console)
        _run_interactive_menu_loop(debug=debug)


# Client commands
@cli.group(invoke_without_command=True)
@click.pass_context
def clients(ctx):
    """Manage clients (list all clients if no subcommand)."""
    if ctx.invoked_subcommand is None:
        run_client_module(["--list"])


@cli.group(invoke_without_command=True)
@click.argument("client_name")
@click.pass_context
def client(ctx, client_name):
    """Manage a specific client."""
    if ctx.invoked_subcommand is None:
        run_client_module(["--client", client_name])


@client.command()
def list():
    """List information for a specific client."""
    # Using the parent command's client_name
    ctx = click.get_current_context()
    client_name = ctx.parent.params.get("client_name")
    run_client_module(["--client", client_name])


@client.command()
def projects():
    """List projects for a specific client."""
    # Using the parent command's client_name
    ctx = click.get_current_context()
    client_name = ctx.parent.params.get("client_name")
    run_client_module(["--client", client_name, "--list-projects"])


# Screenshot commands
@cli.command()
@click.option("--client", help="Client name for screenshot module", required=True)
@click.option("--project", help="Project name for screenshot module", required=True)
@click.option("--timer", type=int, help="Timer interval in minutes for screenshot module")
@click.option(
    "--mode",
    type=click.Choice(["all", "main", "second", "window"]),
    help="Screenshot mode (all, main, second, window)",
)
def shoot(client, project, timer, mode):
    """Take screenshots with specified options."""
    args = []

    args.extend(["--client", client])
    args.extend(["--project", project])

    if timer is not None:
        args.extend(["--timer", str(timer)])

    if mode is not None:
        args.extend(["--mode", mode])

    # Run screenshot module with arguments
    run_screenshot_module(args)


# Report commands
@cli.group(invoke_without_command=True)
@click.pass_context
def report(ctx):
    """Generate reports (opens interactive report UI if no subcommand)."""
    if ctx.invoked_subcommand is None:
        debug_enabled = bool(ctx.obj and ctx.obj.get("debug"))
        args = ["--debug"] if debug_enabled else []
        run_report_module(args)


@report.command()
@click.option("--client", help="Client name for report generation", required=True)
@click.option("--project", help="Project name for report generation", required=True)
@click.pass_context
def generate(ctx, client, project):
    """Generate a report for a specific client and project."""
    args = ["--client", client, "--project", project]
    debug_enabled = bool(ctx.obj and ctx.obj.get("debug"))
    if debug_enabled:
        args.append("--debug")
    run_report_module(args)


# Settings commands
@cli.group(invoke_without_command=True)
@click.pass_context
def settings(ctx):
    """Manage application settings."""
    if ctx.invoked_subcommand is None:
        run_settings_module([])


@settings.command()
def reset():
    """Reset all settings to defaults."""
    run_settings_module(["--reset"])


@settings.command()
@click.argument("filename")
def export(filename):
    """Export settings to a JSON file."""
    run_settings_module(["--export", filename])


@settings.command()
@click.argument("filename")
def import_settings(filename):
    """Import settings from a JSON file."""
    run_settings_module(["--import-file", filename])


@cli.group(name="open", invoke_without_command=True)
@click.pass_context
def open_cmd(ctx):
    """Open application directories in the system file browser."""
    if ctx.invoked_subcommand is None:
        console.print("Use 'screenshooter open logs' or 'screenshooter open config'.")


@open_cmd.command()
def logs() -> None:
    """Open the logs directory in the default file browser."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    if _open_path_cross_platform(LOGS_DIR):
        console.print(f"[green]Opened logs directory:[/green] {LOGS_DIR}")
    else:
        console.print(f"[yellow]Could not open logs directory:[/yellow] {LOGS_DIR}")


@open_cmd.command()
def config() -> None:
    """Open the config directory in the default file browser."""
    config_dir = Path(get_config_dir())
    config_dir.mkdir(parents=True, exist_ok=True)

    if _open_path_cross_platform(config_dir):
        console.print(f"[green]Opened config directory:[/green] {config_dir}")
    else:
        console.print(f"[yellow]Could not open config directory:[/yellow] {config_dir}")


def _run_backup_and_report(
    backup_type: str,
    output_dir: str | None,
    verbosity: str | None,
    file_scope: str,
    debug: bool,
) -> None:
    """Run perform_backup and print the outcome, noting any paused upload."""
    try:
        zip_path = perform_backup(
            backup_type,
            output_dir,
            verbosity=verbosity,
            file_scope=file_scope,
            debug_logging=debug,
        )
        if get_paused_backup_upload_state():
            console.print(f"[green]Backup ZIP created:[/green] {zip_path}")
            console.print(
                "[yellow]Upload was paused. Run [bold]screenshooter backup[/bold]"
                " to resume or discard it.[/yellow]"
            )
        else:
            console.print(f"[green]Backup created:[/green] {zip_path}")
    except Exception as e:
        console.print(f"[bold red]Backup failed:[/bold red] {e}")
    console.print(f"[dim]Backup log:[/dim] {get_backup_log_file()}")


def _prompt_backup_file_scope() -> str:
    """Prompt for all-backup client/project file scope."""
    return prompt_ask_on_new_line(
        "Scope for backup of clients/projects:",
        choices=["active-only", "all"],
        default="all",
    )


@cli.command()
@click.argument("backup_type", required=False, type=click.Choice(["settings", "db", "all"]))
@click.option(
    "--outputdir",
    "output_dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    help="Directory to write the backup ZIP file to",
)
@click.option(
    "--verbosity",
    type=click.Choice(["off", "summary", "full"]),
    help="Backup output verbosity (default from settings).",
)
@click.option(
    "--scope",
    "file_scope",
    type=click.Choice(["active-only", "all"]),
    default="all",
    show_default=True,
    help="Client/project file scope for all-data backups.",
)
@click.option("--debug", is_flag=True, help="Write full structured backup event details.")
@click.pass_context
def backup(  # noqa: PLR0913 - Click passes one argument per option.
    ctx: click.Context,
    backup_type: str | None,
    output_dir: str | None,
    verbosity: str | None,
    file_scope: str,
    debug: bool,
) -> None:
    """Create a backup of settings, database, or all data.

    When BACKUP_TYPE is omitted, shows current backup settings and prompts:
    - y: run backup now
    - e: open settings UI to edit backup settings
    - n: cancel
    """
    debug = debug or bool(ctx.obj and ctx.obj.get("debug"))

    # Interactive mode when no backup type is provided
    if backup_type is None:
        if handle_paused_backup_upload_interactive(
            lambda question, choices, default: prompt_ask_on_new_line(
                question,
                choices=choices,
                default=default,
            ),
            console_instance=console,
        ):
            return

        while True:
            settings = get_settings()

            # Compute effective backup directory (same logic as backup settings UI)
            default_backup_dir = Path(settings.storage.base_directory).expanduser() / "backups"
            configured_dir = settings.backup.backup_directory.strip()
            effective_dir = (
                Path(configured_dir).expanduser() if configured_dir else default_backup_dir
            )

            encryption_enabled = bool(settings.backup.password_enabled and settings.backup.password)
            settings_verbosity = getattr(settings.backup, "verbosity", "full") or "full"
            configured_verbosity = verbosity or settings_verbosity or "full"
            backup_s3_enabled = bool(getattr(settings.backup, "upload_to_s3_enabled", False))
            backup_bucket = str(getattr(settings.backup, "s3_bucket_name", "") or "").strip()
            effective_bucket = backup_bucket or settings.s3.bucket_name or "(main bucket not set)"
            backup_prefix = str(
                getattr(settings.backup, "s3_path_prefix", "backups") or "backups"
            ).strip()
            effective_prefix = backup_prefix or "backups"

            console.print("\n[bold]Backup Configuration Preview[/bold]")
            console.print("===============================")
            console.print(f"Backup directory: {effective_dir}")
            console.print(f"Password protection: {'Enabled' if encryption_enabled else 'Disabled'}")
            console.print(f"Backup verbosity: {configured_verbosity}")
            console.print(f"S3 backup upload: {'Enabled' if backup_s3_enabled else 'Disabled'}")
            if backup_s3_enabled:
                console.print(f"S3 backup location: {effective_bucket}/{effective_prefix}")

            action = prompt_ask_on_new_line(
                "\nRun backup now with these settings or edit them first?",
                choices=["y", "e", "n"],
                default="y",
            )

            console.print("")  # Visual separation before any follow-up prompt

            if action == "n":
                console.print("[dim]Backup cancelled.[/dim]")
                return
            if action == "e":
                console.print("[dim]Opening Backup Settings editor.[/dim]")
                result = run_settings_module(["--edit-backup-direct"])
                if result == 1:
                    console.print("[dim]Backup settings edit discarded.[/dim]")
                    continue
                if result != 0:
                    console.print("[bold red]Unable to open backup settings editor.[/bold red]")
                    return
                reload_settings()
                continue

            break

        # Ask for backup type interactively
        backup_type = prompt_ask_on_new_line(
            "Select backup type",
            choices=["settings", "db", "all"],
            default="all",
        )
        if backup_type == "all":
            file_scope = _prompt_backup_file_scope()

    # Non-interactive path or interactive path after selecting type
    _run_backup_and_report(backup_type, output_dir, verbosity, file_scope, debug)


@cli.command()
def help():
    """Show detailed help information."""
    print_usage()


# Database commands
cli.add_command(database_cli, name="db")
cli.add_command(sync_cli, name="sync")
cli.add_command(upgrade_cli, name="upgrade")


# Define main for compatibility with entry points
def main():
    """Entry point for the application."""
    try:
        ensure_terminal_cooked_mode()
        cli()
    except Exception as e:
        console.print(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)
    finally:
        ensure_terminal_cooked_mode()


if __name__ == "__main__":
    try:
        ensure_terminal_cooked_mode()
        cli()
    except KeyboardInterrupt:
        console.print("\n[bold]Program terminated by user.[/bold]")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[bold red]An error occurred: {e}[/bold red]")
        sys.exit(1)
    finally:
        ensure_terminal_cooked_mode()
