"""Runtime version resolution for ScreenShooter."""

from __future__ import annotations

import json
import logging
import re
import subprocess
from datetime import datetime
from importlib import metadata
from pathlib import Path
from urllib.parse import unquote, urlparse

from packaging.version import InvalidVersion, Version

logger = logging.getLogger(__name__)

PACKAGE_NAME = "wm-screenshooter"
RELEASE_TAG_PATTERN = re.compile(r"^v?(?P<version>\d+\.\d+\.\d+)$")


def get_runtime_version() -> str:
    """Resolve the most accurate runtime version for the current import context."""
    source_path = Path(__file__).resolve()
    project_root = _find_project_root(source_path)
    repo_root = _find_git_root(source_path)

    if repo_root is not None:
        git_version = _build_git_version(repo_root)
        if git_version is not None:
            return git_version

    metadata_version = _get_metadata_version(project_root)
    if metadata_version is not None:
        return metadata_version

    return "dev"


def _find_project_root(source_path: Path) -> Path | None:
    """Find the project root containing `pyproject.toml` when available."""
    for parent in [source_path.parent, *source_path.parents]:
        if (parent / "pyproject.toml").exists():
            return parent
    return None


def _find_git_root(source_path: Path) -> Path | None:
    """Find the git root for the imported source tree when available."""
    for parent in [source_path.parent, *source_path.parents]:
        if (parent / ".git").exists():
            return parent
    return None


def _build_git_version(repo_root: Path) -> str | None:
    """Build a PEP 440 version from the current git checkout."""
    head_sha = _git_stdout(repo_root, "rev-parse", "--short=9", "HEAD")
    if head_sha is None:
        return None

    local_dirty_suffix = _get_dirty_suffix(repo_root)
    exact_tag = _get_exact_release_tag(repo_root)
    if exact_tag is not None:
        if local_dirty_suffix:
            return f"{exact_tag}+{local_dirty_suffix.lstrip('.')}"
        return exact_tag

    latest_tag = _get_latest_reachable_release_tag(repo_root)
    if latest_tag is not None:
        distance_text = _git_stdout(repo_root, "rev-list", "--count", f"v{latest_tag}..HEAD")
        if distance_text is None:
            distance_text = _git_stdout(repo_root, "rev-list", "--count", f"{latest_tag}..HEAD")
        if distance_text is not None:
            try:
                distance = int(distance_text)
            except ValueError:
                logger.debug("Failed to parse git distance: %s", distance_text)
            else:
                next_version = _increment_patch(latest_tag)
                return f"{next_version}.dev{distance}+g{head_sha}{local_dirty_suffix}"

    commit_count_text = _git_stdout(repo_root, "rev-list", "--count", "HEAD")
    commit_count = 0
    if commit_count_text is not None:
        try:
            commit_count = int(commit_count_text)
        except ValueError:
            logger.debug("Failed to parse commit count: %s", commit_count_text)

    return f"0.0.0.dev{commit_count}+g{head_sha}{local_dirty_suffix}"


def _get_exact_release_tag(repo_root: Path) -> str | None:
    """Return the highest matching release tag pointing at HEAD."""
    output = _git_stdout(repo_root, "tag", "--points-at", "HEAD")
    if output is None:
        return None

    candidates: list[Version] = []
    for line in output.splitlines():
        parsed = _parse_release_tag(line.strip())
        if parsed is not None:
            candidates.append(parsed)

    if not candidates:
        return None

    return str(max(candidates))


def _get_latest_reachable_release_tag(repo_root: Path) -> str | None:
    """Return the closest reachable release tag from HEAD."""
    output = _git_stdout(
        repo_root,
        "describe",
        "--tags",
        "--abbrev=0",
        "--match",
        "v[0-9]*.[0-9]*.[0-9]*",
        "--match",
        "[0-9]*.[0-9]*.[0-9]*",
    )
    if output is None:
        return None

    parsed = _parse_release_tag(output.strip())
    if parsed is None:
        return None

    return str(parsed)


def _parse_release_tag(tag_name: str) -> Version | None:
    """Parse a stable release tag into a packaging version."""
    match = RELEASE_TAG_PATTERN.fullmatch(tag_name)
    if match is None:
        return None

    try:
        return Version(match.group("version"))
    except InvalidVersion:
        return None


def _increment_patch(version_text: str) -> str:
    """Increment the patch component of a stable version string."""
    parsed = Version(version_text)
    major, minor, patch = parsed.release[:3]
    return f"{major}.{minor}.{patch + 1}"


def _is_dirty(repo_root: Path) -> bool:
    """Return True when the git checkout has local modifications."""
    output = _git_stdout(repo_root, "status", "--short")
    return bool(output)


def _get_dirty_suffix(repo_root: Path) -> str:
    """Return the local-version dirty suffix used for modified checkouts."""
    if not _is_dirty(repo_root):
        return ""
    return f".d{datetime.now().strftime('%Y%m%d')}"


def _git_stdout(repo_root: Path, *args: str) -> str | None:
    """Run a git command and return stripped stdout when successful."""
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=repo_root,
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError:
        return None

    if result.returncode != 0:
        return None

    return result.stdout.strip()


def _get_metadata_version(current_project_root: Path | None) -> str | None:
    """Resolve an installed distribution version, preferring the current checkout."""
    matching_version: str | None = None

    for distribution in metadata.distributions():
        name = distribution.metadata.get("Name", "")
        if name != PACKAGE_NAME:
            continue

        direct_url_path = _get_direct_url_path(distribution)
        if current_project_root is not None and direct_url_path is not None:
            if _same_path(direct_url_path, current_project_root):
                return distribution.version
            continue

        if current_project_root is None and matching_version is None:
            matching_version = distribution.version

    if matching_version is not None:
        return matching_version

    try:
        return metadata.version(PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        return None


def _get_direct_url_path(distribution: metadata.Distribution) -> Path | None:
    """Read the source path recorded in `direct_url.json` for editable installs."""
    raw_direct_url = distribution.read_text("direct_url.json")
    if not raw_direct_url:
        return None

    try:
        direct_url_data = json.loads(raw_direct_url)
    except json.JSONDecodeError:
        return None

    url = str(direct_url_data.get("url", "")).strip()
    if not url:
        return None

    parsed = urlparse(url)
    if parsed.scheme != "file":
        return None

    path_text = unquote(parsed.path)
    if parsed.netloc:
        path_text = f"//{parsed.netloc}{path_text}"

    try:
        return Path(path_text).resolve()
    except OSError:
        return None


def _same_path(left: Path, right: Path) -> bool:
    """Return True when two paths refer to the same normalized location."""
    try:
        return left.resolve() == right.resolve()
    except OSError:
        return False
