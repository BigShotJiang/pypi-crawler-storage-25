#!/usr/bin/env python3
"""S3/R2 helper module for ScreenShooter Mac."""

import logging
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

import boto3
from boto3.s3.transfer import TransferConfig
from botocore.exceptions import ClientError
from rich.console import Console

from screenshooter.modules.settings.settings_helper import get_settings

# Initialize rich console
console = Console()

# Configure logging
logger = logging.getLogger("s3_helper")
logger.setLevel(logging.INFO)
logger.propagate = False
DEBUG_TERMINAL_STATE = {"enabled": False}
DEFAULT_S3_UPLOAD_WORKERS = 8
MIN_S3_UPLOAD_WORKERS = 1
MAX_S3_UPLOAD_WORKERS = 32


def clamp_s3_upload_workers(value: Any | None) -> int:
    """Return a safe S3/R2 upload worker count."""
    if value is None:
        return DEFAULT_S3_UPLOAD_WORKERS
    try:
        parsed_value = int(value)
    except (TypeError, ValueError):
        return DEFAULT_S3_UPLOAD_WORKERS
    return max(MIN_S3_UPLOAD_WORKERS, min(MAX_S3_UPLOAD_WORKERS, parsed_value))


def set_s3_debug_terminal_output(enabled: bool) -> None:
    """Enable or disable terminal mirroring for S3 log entries."""
    DEBUG_TERMINAL_STATE["enabled"] = enabled


def _print_log_to_terminal(message: str, level: int) -> None:
    """Print an S3 log message to the terminal with a level-appropriate style."""
    if level >= logging.ERROR:
        console.print(f"[bold red]{message}[/bold red]")
    elif level >= logging.WARNING:
        console.print(f"[bold yellow]{message}[/bold yellow]")
    elif level <= logging.DEBUG:
        console.print(f"[dim]{message}[/dim]")
    else:
        console.print(message)


def log_entry(
    message: str,
    terminal_message: str | None = None,
    debug: bool = False,
    level: int = logging.INFO,
) -> None:
    """Log a message to both the log file and terminal.

    Args:
        message: Message to log to file
        terminal_message: Optional formatted message for terminal (if None, uses message)
        debug: Whether this is a debug message (only shown in terminal if debug=True)
        level: Logging level for file/handler output.
    """
    logger.log(level, message)
    if terminal_message and terminal_message.strip():
        console.print(terminal_message)
    elif debug or DEBUG_TERMINAL_STATE["enabled"]:
        _print_log_to_terminal(message, level)


def setup_report_logging(project_path: Path) -> None:
    """Set up logging to write to the project's report-generation.log file."""
    log_file = project_path / "report-generation.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)


# Create a file handler for detailed logging
log_file = Path.home() / ".config" / "screenshooter" / "logs" / "s3_helper.log"
log_file.parent.mkdir(parents=True, exist_ok=True)
file_handler = logging.FileHandler(log_file)
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

# Create a console handler that only shows errors
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.ERROR)
console_formatter = logging.Formatter("%(levelname)s: %(message)s")
console_handler.setFormatter(console_formatter)
logger.addHandler(console_handler)


@contextmanager
def suppress_console_errors() -> Iterator[None]:
    """Temporarily suppress direct S3 console error logging.

    Useful while Rich progress bars are active to avoid interleaving log lines
    with progress rendering. Errors are still written to log files.
    """
    previous_level = console_handler.level
    console_handler.setLevel(logging.CRITICAL + 1)
    try:
        yield
    finally:
        console_handler.setLevel(previous_level)


class S3Helper:
    """Helper class for S3/R2 operations."""

    def __init__(
        self,
        endpoint_url: str,
        access_key_id: str,
        secret_access_key: str,
        bucket_name: str,
        **options: str | bool | int,
    ) -> None:
        """Initialize S3 helper with credentials and configuration.

        Args:
            endpoint_url: S3/R2 endpoint URL
            access_key_id: Access key ID
            secret_access_key: Secret access key
            bucket_name: Bucket name
            options: Optional config keys: region, debug, and upload_workers
        """
        region = str(options.get("region", "auto"))
        debug = bool(options.get("debug", False))
        self.endpoint_url = endpoint_url
        self.access_key_id = access_key_id
        self.secret_access_key = secret_access_key
        self.bucket_name = bucket_name
        self.region = region
        self.debug = debug
        self.upload_workers = clamp_s3_upload_workers(
            options.get("upload_workers", DEFAULT_S3_UPLOAD_WORKERS)
        )
        self.transfer_config = TransferConfig(
            max_concurrency=self.upload_workers,
            use_threads=self.upload_workers > 1,
        )
        set_s3_debug_terminal_output(debug)
        if debug:
            logger.setLevel(logging.DEBUG)

        # Initialize S3 client
        self.s3_client = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            region_name=region,
        )

        if debug:
            log_entry(
                (
                    "S3 helper initialized with debug mode enabled "
                    f"| upload_workers={self.upload_workers}"
                ),
                (
                    "[yellow]S3 helper initialized with debug mode enabled "
                    f"(workers={self.upload_workers})[/yellow]"
                ),
                debug,
            )

    def upload_file(
        self,
        file_path: Path,
        object_name: str | None = None,
        metadata: dict[str, str] | None = None,
        path_prefix_override: str | None = None,
        progress_callback: Callable[[int], None] | None = None,
    ) -> str | None:
        """Upload a file to S3/R2.

        Args:
            file_path: Path to the file to upload
            object_name: S3 object name (default: file name)
            metadata: Optional metadata to attach to the object
            path_prefix_override: Optional path prefix override for this upload only
            progress_callback: Optional callback receiving uploaded bytes for progress updates

        Returns:
            str: Object key if successful, None if failed
        """
        try:
            # Use file name as object name if not specified
            if object_name is None:
                object_name = file_path.name

            # Add timestamp to object name to ensure uniqueness
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            object_name = f"{Path(object_name).stem}_{timestamp}{Path(object_name).suffix}"

            if path_prefix_override is None:
                settings = get_settings()
                path_prefix = settings.s3.path_prefix.strip("/")
            else:
                path_prefix = path_prefix_override.strip("/")

            # Combine path prefix with object name
            if path_prefix:
                object_name = f"{path_prefix}/{object_name}"

            if self.debug:
                log_entry(
                    f"Starting S3/R2 upload for {file_path} as {object_name}",
                    (
                        f"[cyan]Starting S3/R2 upload: {object_name} "
                        f"(workers={self.upload_workers})[/cyan]"
                    ),
                    self.debug,
                    level=logging.DEBUG,
                )

            # Upload file
            extra_args = {}
            if metadata:
                extra_args["Metadata"] = metadata

            upload_kwargs: dict[str, Any] = {"ExtraArgs": extra_args}
            if progress_callback is not None:
                upload_kwargs["Callback"] = progress_callback

            self.s3_client.upload_file(
                str(file_path),
                self.bucket_name,
                object_name,
                Config=self.transfer_config,
                **upload_kwargs,
            )

            if self.debug:
                log_entry(
                    f"Successfully uploaded {file_path} to {object_name}",
                    f"[green]Successfully uploaded {file_path} to {object_name}[/green]",
                    self.debug,
                    level=logging.DEBUG,
                )

            return object_name

        except ClientError as e:
            log_entry(
                f"Error uploading file to S3: {e}",
                f"[red]Error uploading file to S3: {e}[/red]",
                level=logging.ERROR,
            )
            return None
        except Exception as e:
            log_entry(
                f"Unexpected error uploading file: {e}",
                f"[red]Unexpected error uploading file: {e}[/red]",
                level=logging.ERROR,
            )
            return None

    def generate_presigned_url(self, object_name: str, expiration: int = 3600) -> str | None:
        """Generate a presigned URL for an S3/R2 object.

        Args:
            object_name: Name of the object
            expiration: URL expiration time in seconds (default: 1 hour)

        Returns:
            str: Presigned URL if successful, None if failed
        """
        try:
            if self.debug:
                log_entry(
                    f"Generating presigned URL for {object_name} with expiration {expiration}s",
                    f"[cyan]Generating presigned URL for {object_name}[/cyan]",
                    self.debug,
                    level=logging.DEBUG,
                )

            url = self.s3_client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket_name, "Key": object_name},
                ExpiresIn=expiration,
            )

            if self.debug:
                log_entry(
                    f"Generated presigned URL for {object_name}",
                    f"[green]Generated presigned URL for {object_name}[/green]",
                    self.debug,
                    level=logging.DEBUG,
                )

            return url

        except ClientError as e:
            log_entry(
                f"Error generating presigned URL: {e}",
                f"[red]Error generating presigned URL: {e}[/red]",
                level=logging.ERROR,
            )
            return None
        except Exception as e:
            log_entry(
                f"Unexpected error generating presigned URL: {e}",
                f"[red]Unexpected error generating presigned URL: {e}[/red]",
                level=logging.ERROR,
            )
            return None

    def delete_object(self, object_name: str) -> bool:
        """Delete an object from S3/R2.

        Args:
            object_name: Name of the object to delete

        Returns:
            bool: True if successful, False if failed
        """
        try:
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=object_name)

            if self.debug:
                log_entry(
                    f"Successfully deleted {object_name}",
                    f"[green]Successfully deleted {object_name}[/green]",
                    self.debug,
                )

            return True

        except ClientError as e:
            log_entry(
                f"Error deleting object: {e}",
                f"[red]Error deleting object: {e}[/red]",
                level=logging.ERROR,
            )
            return False
        except Exception as e:
            log_entry(
                f"Unexpected error deleting object: {e}",
                f"[red]Unexpected error deleting object: {e}[/red]",
                level=logging.ERROR,
            )
            return False


def get_s3_settings() -> dict[str, Any]:
    """Get S3/R2 settings from application settings."""
    settings = get_settings()

    # No need for expiration mapping since we store seconds directly
    return {
        "enabled": settings.s3.enabled,
        "endpoint_url": settings.s3.endpoint_url,
        "access_key_id": settings.s3.access_key_id,
        "secret_access_key": settings.s3.secret_access_key,
        "bucket_name": settings.s3.bucket_name,
        "region": settings.s3.region,
        # Use the value directly from settings
        "url_expiration": settings.s3.url_expiration,
        "send_attachment": settings.s3.send_attachment,
        "path_prefix": settings.s3.path_prefix,
        "upload_workers": clamp_s3_upload_workers(settings.s3.upload_workers),
    }


def is_s3_enabled() -> bool:
    """Check if S3/R2 functionality is enabled."""
    return get_settings().s3.enabled
