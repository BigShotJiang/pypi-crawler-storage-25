"""Sync state — read/write last_push and last_pull checkpoints in the sync_state table."""

from screenshooter.modules.database.database import DatabaseManager
from screenshooter.modules.database.operations import DatabaseOperations


def get_last_push(db: DatabaseManager, server_url: str, device_id: str) -> str | None:
    """Return the ISO 8601 timestamp of the last successful push, or None."""
    sync_state = DatabaseOperations(db).get_sync_state(server_url, device_id)
    return sync_state["last_push"] if sync_state else None


def get_last_pull(db: DatabaseManager, server_url: str, device_id: str) -> str | None:
    """Return the ISO 8601 timestamp of the last successful pull, or None."""
    sync_state = DatabaseOperations(db).get_sync_state(server_url, device_id)
    return sync_state["last_pull"] if sync_state else None


def update_push(db: DatabaseManager, server_url: str, device_id: str, timestamp: str) -> None:
    """Record a successful push checkpoint."""
    DatabaseOperations(db).update_sync_state_push(server_url, device_id, timestamp)


def update_pull(db: DatabaseManager, server_url: str, device_id: str, timestamp: str) -> None:
    """Record a successful pull checkpoint."""
    DatabaseOperations(db).update_sync_state_pull(server_url, device_id, timestamp)


def reset_push(db: DatabaseManager, server_url: str, device_id: str) -> None:
    """Clear the push checkpoint so the next sync re-pushes all records."""
    DatabaseOperations(db).reset_sync_state_push(server_url, device_id)
