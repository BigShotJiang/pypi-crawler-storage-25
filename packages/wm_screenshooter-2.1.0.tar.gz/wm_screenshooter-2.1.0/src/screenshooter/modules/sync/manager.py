"""Sync manager — orchestrates one full push → pull cycle.

Usage from the screenshooter UI or CLI:

    from screenshooter.modules.sync.manager import SyncManager
    from screenshooter.modules.settings.models import SettingsManager

    settings_mgr = SettingsManager()
    settings = settings_mgr.load_settings()
    manager = SyncManager(settings)
    result = manager.sync()
    print(result)
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit

from screenshooter.modules.database.database import DatabaseManager, get_database_manager
from screenshooter.modules.settings.logging_utils import get_sync_logger
from screenshooter.modules.settings.models import AppSettings, SettingsManager

from . import image_uploader, pull, push, state
from .config import ensure_device_id, is_configured
from .transport import SyncAuthError, SyncServerError, SyncTransport, SyncTransportError


@dataclass
class SyncResult:
    success: bool
    pushed: int = 0
    pulled: int = 0
    images_uploaded: int = 0
    images_failed: int = 0
    error: str = ""
    skipped_reason: str = ""


class SyncManager:
    """Runs a complete push → pull sync cycle."""

    def __init__(
        self,
        settings: AppSettings,
        *,
        debug: bool = False,
        debug_callback: Callable[[str], None] | None = None,
        show_progress: bool = False,
    ) -> None:
        self._settings = settings
        self._settings_mgr = SettingsManager()
        self._debug_enabled = debug
        self._debug_callback = debug_callback
        self._show_progress = show_progress and not debug
        self._logger = get_sync_logger(__name__)

    def sync(self) -> SyncResult:
        sync_cfg = self._settings.sync

        if not is_configured(sync_cfg):
            skipped_reason = (
                "Sync is not configured (enable it and set server_url and a Screenshooter API key)."
            )
            self._logger.info("Sync skipped | reason=%s", skipped_reason)
            return SyncResult(
                success=False,
                skipped_reason=skipped_reason,
            )

        # Ensure this device has a persistent ID.
        device_id = ensure_device_id(sync_cfg)
        self._settings_mgr.save_settings(self._settings)
        safe_server_url = _sanitize_server_url(sync_cfg.server_url)
        self._logger.info("Sync started | server_url=%s device_id=%s", safe_server_url, device_id)
        self._debug(f"Using server_url={safe_server_url}")
        self._debug(f"Using device_id={device_id}")

        db = get_database_manager()
        transport = SyncTransport(
            server_url=sync_cfg.server_url,
            clerk_auth_token=sync_cfg.clerk_auth_token,
            device_id=device_id,
            debug_callback=self._debug if self._debug_enabled else None,
        )

        try:
            last_push_ts = state.get_last_push(db, sync_cfg.server_url, device_id)
            last_pull_ts = state.get_last_pull(db, sync_cfg.server_url, device_id)
            self._logger.info(
                "Sync checkpoints | last_push=%s last_pull=%s",
                last_push_ts or "Never",
                last_pull_ts or "Never",
            )
            self._debug(f"Last push checkpoint={last_push_ts or 'Never'}")
            self._debug(f"Last pull checkpoint={last_pull_ts or 'Never'}")

            self._logger.info("Push phase started")
            self._debug("Starting push phase")
            push_result = push.run(
                db, transport, device_id, last_push_ts,
                debug=self._debug if self._debug_enabled else None,
            )
            self._logger.info(
                "Push phase complete | accepted=%s rejected=%s server_time=%s",
                push_result.accepted,
                push_result.rejected,
                push_result.server_time,
            )
            self._debug(
                "Push phase result: "
                f"accepted={push_result.accepted}, rejected={push_result.rejected}, "
                f"server_time={push_result.server_time}"
            )
            if push_result.server_time:
                state.update_push(db, sync_cfg.server_url, device_id, push_result.server_time)
                self._logger.info(
                    "Push checkpoint updated | server_time=%s",
                    push_result.server_time,
                )
            else:
                self._logger.info("Push checkpoint unchanged | no records sent")

            pull_mode = "incremental" if last_pull_ts else "full first sync"
            self._logger.info("Pull phase started | mode=%s", pull_mode)
            self._debug(f"Starting pull phase ({pull_mode})")
            pull_result = pull.run(db, transport, last_pull_ts)
            self._logger.info(
                "Pull phase complete | seen=%s applied=%s server_time=%s",
                pull_result.seen,
                pull_result.applied,
                pull_result.server_time,
            )
            self._debug(
                "Pull phase result: "
                f"seen={pull_result.seen}, applied={pull_result.applied}, "
                f"server_time={pull_result.server_time}"
            )
            if pull_result.server_time:
                state.update_pull(db, sync_cfg.server_url, device_id, pull_result.server_time)
                self._logger.info(
                    "Pull checkpoint updated | server_time=%s",
                    pull_result.server_time,
                )

            images_uploaded, images_failed = self._run_image_upload(
                db,
                transport,
                sync_cfg.upload_images,
                sync_cfg.upload_image_workers,
            )

            self._logger.info(
                "Sync complete | pushed=%s pulled=%s images_uploaded=%s images_failed=%s",
                push_result.accepted,
                pull_result.applied,
                images_uploaded,
                images_failed,
            )
            return SyncResult(
                success=True,
                pushed=push_result.accepted,
                pulled=pull_result.applied,
                images_uploaded=images_uploaded,
                images_failed=images_failed,
            )

        except SyncAuthError as exc:
            self._logger.warning("Sync auth failed | error=%s", exc)
            return SyncResult(
                success=False,
                error=(
                    "Authentication failed — check your Screenshooter API key or create"
                    f" a new one in Workmaster Settings. ({exc})"
                ),
            )
        except SyncServerError as exc:
            self._logger.warning("Sync server error | error=%s", exc)
            return SyncResult(success=False, error=f"Server error: {exc}")
        except SyncTransportError as exc:
            self._logger.warning("Sync transport error | error=%s", exc)
            return SyncResult(
                success=False,
                error=f"Network error — check your connection and server URL. ({exc})",
            )
        except Exception as exc:
            self._logger.exception("Sync unexpected error")
            return SyncResult(success=False, error=f"Unexpected error: {exc}")

    def _run_image_upload(
        self,
        db: DatabaseManager,
        transport: SyncTransport,
        enabled: bool,
        workers: int,
    ) -> tuple[int, int]:
        """Run the image upload phase if enabled; return (uploaded, failed) counts."""
        if not enabled:
            self._debug("Image upload skipped (upload_images is disabled)")
            return 0, 0
        self._logger.info("Image upload phase started")
        self._debug("Starting image upload phase")
        result = image_uploader.run(
            db,
            transport,
            debug=self._debug if self._debug_enabled else None,
            show_progress=self._show_progress,
            workers=workers,
        )
        self._logger.info(
            "Image upload phase complete | uploaded=%s skipped=%s failed=%s",
            result.uploaded,
            result.skipped,
            result.failed,
        )
        return result.uploaded, result.failed

    def _debug(self, message: str) -> None:
        """Emit verbose sync logging if debug output is enabled."""
        if not self._debug_enabled:
            return
        self._logger.debug(message)
        if self._debug_callback is not None:
            self._debug_callback(message)


def _sanitize_server_url(server_url: str) -> str:
    """Return server URL without credentials, query string, or fragment."""
    parsed = urlsplit(server_url.strip())
    hostname = parsed.hostname or ""
    port = f":{parsed.port}" if parsed.port is not None else ""
    netloc = f"{hostname}{port}" if hostname else parsed.netloc.split("@")[-1]
    return urlunsplit((parsed.scheme, netloc, parsed.path.rstrip("/"), "", ""))
