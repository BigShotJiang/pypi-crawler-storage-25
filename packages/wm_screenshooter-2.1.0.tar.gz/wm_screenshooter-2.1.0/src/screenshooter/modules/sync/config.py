"""Sync configuration helpers."""

import uuid

from screenshooter.modules.settings.models import SyncSettings


def ensure_device_id(settings: SyncSettings) -> str:
    """Return the device_id, generating and persisting one if it doesn't exist yet.

    Callers are responsible for saving settings after this call if a new
    device_id was generated (settings.device_id will be mutated in place).
    """
    if not settings.device_id:
        settings.device_id = str(uuid.uuid4())
    return settings.device_id


def is_configured(settings: SyncSettings) -> bool:
    """Return True if sync is enabled and the minimum required fields are set."""
    return bool(settings.enabled and settings.server_url and settings.clerk_auth_token)
