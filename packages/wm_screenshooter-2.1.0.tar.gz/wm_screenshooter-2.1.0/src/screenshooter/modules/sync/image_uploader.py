"""Upload screenshot image files to Workmaster R2 via the upload prepare/complete API.

Flow per screenshot:
  1. POST /sync/screenshots/upload/prepare  → get presigned R2 PUT URL(s)
  2. PUT raw bytes directly to each R2 URL  (no auth headers — URL is presigned)
  3. POST /sync/screenshots/upload/complete → server verifies and marks upload_status=ready

Local state is persisted in ~/.config/screenshooter/image_upload_cache.json so that
completed uploads are never re-sent and transient failures can be retried.
"""

from __future__ import annotations

import hashlib
import json
import os
import struct
from collections.abc import Callable
from concurrent.futures import CancelledError, Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, BinaryIO

import requests
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)

from screenshooter.modules.database.database import DatabaseManager
from screenshooter.modules.database.operations import DatabaseOperations
from screenshooter.modules.settings.logging_utils import get_sync_logger

from .transport import SyncAuthError, SyncTransport, UploadPermanentError

_console = Console()

_CONFIG_DIR = Path.home() / ".config" / "screenshooter"
_UPLOAD_STATE_FILE = _CONFIG_DIR / "image_upload_cache.json"

_MIME_MAP: dict[str, str] = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
}

# Binary parsing offsets / masks
_JPEG_MARKER_BYTE = 0xFF
_JPEG_SOF_MARKERS = (0xC0, 0xC1, 0xC2)
_JPEG_STOP_MARKERS = (0xD8, 0xD9, 0xDA)
_PNG_MIN_HEADER = 24
_WEBP_MIN_HEADER = 30
_VP8_MASK = 0x3FFF
_DEFAULT_WORKERS = 8
_MAX_WORKERS = 32
_IMAGE_HEADER_READ_BYTES = 65536


@dataclass
class _UploadEntry:
    status: str = "not_uploaded"
    retry_count: int = 0
    last_error: str = ""


@dataclass(frozen=True)
class ImageUploadResult:
    """Result from one image upload pass."""

    uploaded: int = 0
    skipped: int = 0
    failed: int = 0


@dataclass(frozen=True)
class _UploadCandidate:
    uuid: str
    file_path: str
    mime: str
    file_size: int
    retry_count: int


@dataclass(frozen=True)
class _UploadOutcome:
    uuid: str
    status: str
    retry_count: int
    error: str = ""


@dataclass(frozen=True)
class _UploadContext:
    transport: SyncTransport
    debug: Callable[[str], None] | None
    progress_callback: Callable[[int], None] | None = None


# ---------------------------------------------------------------------------
# Local state helpers
# ---------------------------------------------------------------------------


def _load_state() -> dict[str, dict[str, Any]]:
    if not _UPLOAD_STATE_FILE.exists():
        return {}
    try:
        return json.loads(_UPLOAD_STATE_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        get_sync_logger(__name__).warning(
            "Image upload cache is unreadable | path=%s error=%s",
            _UPLOAD_STATE_FILE,
            exc,
        )
        return {}


def _save_state(state: dict[str, dict[str, Any]]) -> None:
    logger = get_sync_logger(__name__)
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    temp_path = _UPLOAD_STATE_FILE.with_suffix(".tmp")
    try:
        with open(temp_path, "w", encoding="utf-8") as file_handle:
            file_handle.write(json.dumps(state, indent=2))
            file_handle.flush()
            os.fsync(file_handle.fileno())
        os.replace(temp_path, _UPLOAD_STATE_FILE)
    except OSError as exc:
        logger.warning(
            "Could not save image upload cache | path=%s error=%s",
            _UPLOAD_STATE_FILE,
            exc,
        )
        raise


def _get_entry(state: dict[str, dict[str, Any]], uuid: str) -> _UploadEntry:
    raw = state.get(uuid, {})
    return _UploadEntry(
        status=raw.get("status", "not_uploaded"),
        retry_count=raw.get("retry_count", 0),
        last_error=raw.get("last_error", ""),
    )


def _set_entry(state: dict[str, dict[str, Any]], uuid: str, entry: _UploadEntry) -> None:
    state[uuid] = {
        "status": entry.status,
        "retry_count": entry.retry_count,
        "last_error": entry.last_error,
        "last_attempt": datetime.now(timezone.utc).isoformat(),
    }


def _clamp_workers(workers: int) -> int:
    """Return a safe upload worker count."""
    try:
        requested = int(workers or _DEFAULT_WORKERS)
    except (TypeError, ValueError):
        requested = _DEFAULT_WORKERS
    return min(max(requested, 1), _MAX_WORKERS)


# ---------------------------------------------------------------------------
# File introspection helpers (no PIL required)
# ---------------------------------------------------------------------------


def _mime_type(file_path: str) -> str | None:
    return _MIME_MAP.get(Path(file_path).suffix.lower())


def _jpeg_dimensions(data: bytes) -> tuple[int, int]:
    """Extract (width, height) from raw JPEG bytes by scanning SOF markers."""
    i = 2  # skip SOI
    while i < len(data) - 8:
        if data[i] != _JPEG_MARKER_BYTE:
            break
        marker = data[i + 1]
        if marker in _JPEG_SOF_MARKERS:  # SOF0 / SOF1 / SOF2
            h = struct.unpack(">H", data[i + 5 : i + 7])[0]
            w = struct.unpack(">H", data[i + 7 : i + 9])[0]
            return w, h
        if marker in _JPEG_STOP_MARKERS:
            break
        length = struct.unpack(">H", data[i + 2 : i + 4])[0]
        i += 2 + length
    return 0, 0


def _image_dimensions(file_path: str) -> tuple[int, int]:
    """Return (width, height) for JPEG/PNG/WebP using stdlib struct only."""
    p = Path(file_path)
    try:
        with open(p, "rb") as file_handle:
            data = file_handle.read(_IMAGE_HEADER_READ_BYTES)
        suffix = p.suffix.lower()
        if suffix in (".jpg", ".jpeg"):
            return _jpeg_dimensions(data)
        if suffix == ".png" and len(data) >= _PNG_MIN_HEADER:
            w = struct.unpack(">I", data[16:20])[0]
            h = struct.unpack(">I", data[20:24])[0]
            return w, h
        if suffix == ".webp" and len(data) >= _WEBP_MIN_HEADER:
            # VP8 / VP8L / VP8X — try VP8 lossy bitstream
            if data[12:16] == b"VP8 " and len(data) >= _WEBP_MIN_HEADER:
                w = (struct.unpack("<H", data[26:28])[0] & _VP8_MASK) + 1
                h = (struct.unpack("<H", data[28:30])[0] & _VP8_MASK) + 1
                return w, h
    except (OSError, struct.error, IndexError) as exc:
        get_sync_logger(__name__).debug(
            "Could not parse image dimensions | file_path=%s error=%s",
            file_path,
            exc,
        )
    return 0, 0


def _sha256_hex(file_path: str) -> str:
    h = hashlib.sha256()
    with open(file_path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# R2 direct PUT (no WorkMaster auth — presigned URL handles authorization)
# ---------------------------------------------------------------------------


class _ProgressFileReader:
    """File-like reader that reports bytes read to a progress callback."""

    def __init__(self, file_handle: BinaryIO, callback: Callable[[int], None] | None) -> None:
        self._file_handle = file_handle
        self._callback = callback

    def read(self, size: int = -1) -> bytes:
        chunk = self._file_handle.read(size)
        if chunk and self._callback is not None:
            self._callback(len(chunk))
        return chunk

    def __getattr__(self, name: str) -> Any:
        return getattr(self._file_handle, name)


def _put_r2(
    upload_url: str,
    file_path: str,
    content_type: str,
    debug: Callable[[str], None] | None,
    progress_callback: Callable[[int], None] | None = None,
) -> None:
    file_size = Path(file_path).stat().st_size
    if debug:
        debug(f"R2 PUT {upload_url[:80]}... size={file_size} content_type={content_type}")
    with open(file_path, "rb") as fh:
        reader = _ProgressFileReader(fh, progress_callback)
        resp = requests.put(
            upload_url,
            data=reader,
            headers={"Content-Type": content_type},
            timeout=120,
        )
    if debug:
        elapsed_ms = int(resp.elapsed.total_seconds() * 1000)
        debug(f"R2 PUT response status={resp.status_code} elapsed={elapsed_ms}ms")
    if resp.status_code in (400, 413, 415):
        raise UploadPermanentError(
            f"Permanent R2 upload error {resp.status_code}: {resp.text[:200]}"
        )
    resp.raise_for_status()


# ---------------------------------------------------------------------------
# Per-screenshot upload helper
# ---------------------------------------------------------------------------


def _upload_one(context: _UploadContext, candidate: _UploadCandidate) -> None:
    """Run the prepare → PUT → complete flow for a single screenshot.

    Raises on any failure so the caller can classify and record the error.
    """
    file_size = Path(candidate.file_path).stat().st_size
    w, h = _image_dimensions(candidate.file_path)
    sha = _sha256_hex(candidate.file_path)

    if context.debug:
        context.debug(
            f"Screenshot {candidate.uuid}: uploading {Path(candidate.file_path).name} "
            f"size={file_size} mime={candidate.mime} {w}x{h}"
        )

    prepare = context.transport.upload_prepare(
        {
            "screenshot_uuid": candidate.uuid,
            "variants": [
                {
                    "variant": "original",
                    "content_type": candidate.mime,
                    "content_length": file_size,
                    "width": w,
                    "height": h,
                    "sha256": sha,
                }
            ],
        }
    )
    if context.debug:
        context.debug(
            f"Screenshot {candidate.uuid}: prepare OK r2_prefix={prepare.get('r2_prefix')} "
            f"expires_at={prepare.get('expires_at')}"
        )

    uploads: list[dict[str, Any]] = prepare.get("uploads", [])
    if not uploads:
        raise ValueError("prepare returned no upload URLs")

    upload = uploads[0]
    upload_url: str = upload["upload_url"]
    r2_key: str = upload["r2_key"]
    upload_content_type: str = upload.get("headers", {}).get("content-type", candidate.mime)

    _put_r2(
        upload_url,
        candidate.file_path,
        upload_content_type,
        context.debug,
        context.progress_callback,
    )

    complete = context.transport.upload_complete(
        {
            "screenshot_uuid": candidate.uuid,
            "uploads": [
                {"variant": "original", "r2_key": r2_key, "width": w, "height": h, "sha256": sha}
            ],
        }
    )
    if context.debug:
        context.debug(
            f"Screenshot {candidate.uuid}: complete OK "
            f"upload_status={complete.get('upload_status')}"
        )


# ---------------------------------------------------------------------------
# Main upload runner
# ---------------------------------------------------------------------------


def _process_rows(
    candidates: list[_UploadCandidate],
    skipped: int,
    state: dict[str, dict[str, Any]],
    context: _UploadContext,
    workers: int,
) -> ImageUploadResult:
    """Process screenshot rows with bounded parallel uploads and return counts."""
    logger = get_sync_logger(__name__)
    if not candidates:
        return ImageUploadResult(skipped=skipped)

    uploaded = failed = 0
    clamped_workers = _clamp_workers(workers)

    with ThreadPoolExecutor(max_workers=clamped_workers) as executor:
        futures = _submit_uploads(executor, candidates, context)
        for future in as_completed(futures):
            candidate = futures[future]
            try:
                outcome = future.result()
            except SyncAuthError:
                for pending in futures:
                    pending.cancel()
                executor.shutdown(wait=False, cancel_futures=True)
                raise
            except CancelledError:
                if context.debug:
                    context.debug(f"Screenshot {candidate.uuid}: upload cancelled")
                continue

            if outcome.status == "complete":
                _set_entry(state, outcome.uuid, _UploadEntry(status="complete"))
                logger.info("Image upload complete | screenshot_uuid=%s", outcome.uuid)
                uploaded += 1
                continue

            fail_status = outcome.status
            _set_entry(
                state,
                outcome.uuid,
                _UploadEntry(
                    status=fail_status,
                    retry_count=outcome.retry_count,
                    last_error=outcome.error[:300],
                ),
            )
            logger.warning(
                "Image upload failed | screenshot_uuid=%s error=%s",
                outcome.uuid,
                outcome.error,
            )
            if context.debug:
                context.debug(
                    f"Screenshot {outcome.uuid}: upload failed ({fail_status}): {outcome.error}"
                )
            failed += 1

    return ImageUploadResult(uploaded=uploaded, skipped=skipped, failed=failed)


def _build_upload_candidates(
    rows: list[Any],
    state: dict[str, dict[str, Any]],
    debug: Callable[[str], None] | None,
) -> tuple[list[_UploadCandidate], int]:
    """Return upload candidates and the count of skipped rows."""
    candidates: list[_UploadCandidate] = []
    skipped = 0

    for row in rows:
        uuid = row["remote_uuid"]
        file_path = row["file_path"] or ""
        entry = _get_entry(state, uuid)

        if entry.status in ("complete", "failed_permanent"):
            if entry.status == "failed_permanent" and debug:
                debug(f"Screenshot {uuid}: permanent failure — skipping")
            skipped += 1
            continue

        if not file_path or not Path(file_path).exists():
            if debug:
                debug(f"Screenshot {uuid}: file not found at {file_path!r} — skipping")
            skipped += 1
            continue

        mime = _mime_type(file_path)
        if mime is None:
            if debug:
                debug(
                    f"Screenshot {uuid}: unsupported extension "
                    f"{Path(file_path).suffix!r} — skipping"
                )
            skipped += 1
            continue

        candidates.append(
            _UploadCandidate(
                uuid=uuid,
                file_path=file_path,
                mime=mime,
                file_size=Path(file_path).stat().st_size,
                retry_count=entry.retry_count,
            )
        )

    return candidates, skipped


def _submit_uploads(
    executor: ThreadPoolExecutor,
    candidates: list[_UploadCandidate],
    context: _UploadContext,
) -> dict[Future[_UploadOutcome], _UploadCandidate]:
    """Submit upload candidates to the worker pool."""
    return {
        executor.submit(_upload_candidate, context, candidate): candidate
        for candidate in candidates
    }


def _upload_candidate(
    context: _UploadContext,
    candidate: _UploadCandidate,
) -> _UploadOutcome:
    """Upload one candidate and return a state outcome."""
    try:
        _upload_one(context, candidate)
        return _UploadOutcome(
            uuid=candidate.uuid,
            status="complete",
            retry_count=0,
        )
    except SyncAuthError:
        raise
    except UploadPermanentError as exc:
        return _UploadOutcome(
            uuid=candidate.uuid,
            status="failed_permanent",
            retry_count=candidate.retry_count + 1,
            error=str(exc),
        )
    except Exception as exc:
        return _UploadOutcome(
            uuid=candidate.uuid,
            status="failed_retryable",
            retry_count=candidate.retry_count + 1,
            error=str(exc),
        )


def run(
    db: DatabaseManager,
    transport: SyncTransport,
    debug: Callable[[str], None] | None = None,
    show_progress: bool = False,
    workers: int = _DEFAULT_WORKERS,
) -> ImageUploadResult:
    """Upload screenshot images that have not yet been sent to R2.

    Queries all non-deleted screenshots with a remote_uuid (i.e. metadata has
    been pushed), checks the local state cache, and runs the prepare → PUT →
    complete flow for each that still needs uploading.

    When show_progress=True a Rich progress bar is rendered. This is mutually
    exclusive with debug: the manager sets show_progress only when debug is off.
    """
    state = _load_state()

    rows = DatabaseOperations(db).list_screenshots_for_image_upload()

    clamped_workers = _clamp_workers(workers)
    candidates, skipped = _build_upload_candidates(rows, state, debug)
    total_bytes = sum(candidate.file_size for candidate in candidates)

    if debug:
        debug(
            f"Image upload phase: {len(rows)} screenshot(s) to evaluate; "
            f"{len(candidates)} upload candidate(s); workers={clamped_workers}"
        )

    try:
        if show_progress and candidates and total_bytes > 0:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                DownloadColumn(binary_units=True),
                TransferSpeedColumn(),
                TimeElapsedColumn(),
                console=_console,
            ) as progress:
                task_id = progress.add_task(
                    f"Uploading screenshots with {clamped_workers} workers...",
                    total=total_bytes,
                )

                def _on_progress(bytes_read: int) -> None:
                    progress.advance(task_id, bytes_read)

                result = _process_rows(
                    candidates,
                    skipped,
                    state,
                    _UploadContext(transport, debug, _on_progress),
                    clamped_workers,
                )
                progress.update(task_id, description="Image upload complete")
        else:
            result = _process_rows(
                candidates,
                skipped,
                state,
                _UploadContext(transport, debug),
                clamped_workers,
            )
    finally:
        _save_state(state)

    if debug:
        debug(
            f"Image upload phase complete: "
            f"uploaded={result.uploaded} skipped={result.skipped} failed={result.failed}"
        )

    return result
