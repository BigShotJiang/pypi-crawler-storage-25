"""Command line interface for Workmaster sync configuration and execution."""

from __future__ import annotations

import platform
import subprocess
import webbrowser
from pathlib import Path

import click
from rich.console import Console

from screenshooter.modules.database.database import get_database_manager
from screenshooter.modules.settings.logging_utils import LOGS_DIR, get_sync_log_file
from screenshooter.modules.settings.models import AppSettings, SettingsManager
from screenshooter.modules.settings.settings_helper import reload_settings
from screenshooter.modules.sync import state
from screenshooter.modules.sync.manager import SyncManager

DEFAULT_WORKMASTER_URL = "https://workmaster.app"
API_KEY_PATH = "/dash/settings/api-keys"

console = Console()


def _prompt_on_new_line(prompt_text: str, **kwargs) -> str:
    """Prompt with choices/default on one line and input on a clean `> ` line."""
    choices = kwargs.get("choices")
    default = kwargs.get("default")
    password = kwargs.get("password", False)

    if choices:
        choices_str = "/".join(str(c) for c in choices)
        extra = f" \\[{choices_str}]"
        if default is not None:
            extra += f" ({default})"
        console.print(f"{prompt_text}{extra}:")
    elif default is not None:
        console.print(f"{prompt_text} ({default}):")
    else:
        console.print(f"{prompt_text}:")

    while True:
        raw = click.prompt(">", default="", hide_input=password, show_default=False).strip()
        if not raw and default is not None:
            raw = str(default)
        if choices and raw not in [str(choice) for choice in choices]:
            console.print(
                f"[red]Invalid choice: {raw}. Please enter one of: "
                f"{', '.join(str(choice) for choice in choices)}[/red]"
            )
            continue
        return raw


def _confirm_on_new_line(prompt_text: str, *, default: bool = False) -> bool:
    """Prompt for a yes/no answer with input on a clean `> ` line."""
    default_char = "y" if default else "n"
    console.print(f"{prompt_text} \\[y/n] ({default_char}):")

    while True:
        raw = input("> ").strip().lower()
        if not raw:
            return default
        if raw in ("y", "n"):
            return raw == "y"
        console.print("[red]Please enter 'y' or 'n'.[/red]")


def _prompt_int_on_new_line(
    prompt_text: str,
    *,
    saved_value: int,
    minimum: int,
    maximum: int,
    default_value: int,
) -> int:
    """Prompt for a bounded integer with input on a clean `> ` line."""
    console.print(f"{prompt_text} [{minimum}-{maximum} - default {default_value}] ({saved_value}):")

    while True:
        raw = input("> ").strip()
        if not raw:
            return saved_value
        try:
            value = int(raw)
        except ValueError:
            console.print("[red]Please enter a whole number.[/red]")
            continue
        if minimum <= value <= maximum:
            return value
        console.print(f"[red]Please enter a number from {minimum} to {maximum}.[/red]")


def _load_settings() -> AppSettings:
    """Load app settings from disk."""
    return SettingsManager().load_settings()


def _save_settings(settings: AppSettings, *, allow_overwrite_on_failed_load: bool = False) -> None:
    """Save app settings and refresh the helper cache."""
    SettingsManager().save_settings(
        settings,
        allow_overwrite_on_failed_load=allow_overwrite_on_failed_load,
    )
    reload_settings()


def _configured_server_url(settings: AppSettings) -> str:
    """Return the configured server URL or the production default."""
    return settings.sync.server_url.strip().rstrip("/") or DEFAULT_WORKMASTER_URL


def _key_status(settings: AppSettings) -> str:
    """Return a masked API key status string."""
    return "Set (masked)" if settings.sync.clerk_auth_token else "Not set"


def _has_required_sync_fields(settings: AppSettings) -> bool:
    """Return True when sync has the required server URL and API key fields."""
    return bool(settings.sync.server_url and settings.sync.clerk_auth_token)


def _configuration_status(settings: AppSettings) -> str:
    """Return a human-readable configuration status."""
    return "Configured" if _has_required_sync_fields(settings) else "Not configured"


def _key_page_url(settings: AppSettings) -> str:
    """Return the Workmaster API key management URL."""
    return f"{_configured_server_url(settings)}{API_KEY_PATH}"


def _open_path_cross_platform(path: Path) -> bool:
    """Open a path with the default system handler."""
    system = platform.system()
    target = str(path)

    try:
        if system == "Darwin":
            return subprocess.run(["open", target], check=False).returncode == 0
        if system == "Linux":
            return subprocess.run(["xdg-open", target], check=False).returncode == 0
        if system == "Windows":
            subprocess.Popen(["start", "", target], shell=True)
            return True
    except Exception:
        return False

    return False


def _print_sync_status(settings: AppSettings) -> None:
    """Render the current sync settings and local checkpoint state."""
    sync_settings = settings.sync

    console.print("\n[bold]Workmaster Sync[/bold]")
    console.print("================")
    console.print(f"Enabled: {'Yes' if sync_settings.enabled else 'No'}")
    console.print(f"Configuration: {_configuration_status(settings)}")
    console.print(f"Server URL: {sync_settings.server_url or 'Not set'}")
    console.print(f"Device ID: {sync_settings.device_id or 'Generated on first sync'}")
    console.print(f"Screenshooter API key: {_key_status(settings)}")
    console.print(f"Auto-sync on startup: {'Yes' if sync_settings.auto_on_startup else 'No'}")
    console.print(
        f"Auto-sync after screenshot session: {'Yes' if sync_settings.auto_after_session else 'No'}"
    )
    console.print(f"Auto-sync on app exit: {'Yes' if sync_settings.auto_on_exit else 'No'}")
    console.print(f"Auto-sync quiet mode: {'Yes' if sync_settings.auto_quiet else 'No'}")
    console.print(f"Upload images to R2: {'Yes' if sync_settings.upload_images else 'No'}")
    if sync_settings.upload_images:
        console.print(f"Image upload workers: {sync_settings.upload_image_workers}")

    if not sync_settings.device_id or not sync_settings.server_url:
        console.print(
            "\n[dim]Sync checkpoints: unavailable until server URL and device ID exist.[/dim]"
        )
        return

    try:
        db = get_database_manager()
        last_push = state.get_last_push(db, sync_settings.server_url, sync_settings.device_id)
        last_pull = state.get_last_pull(db, sync_settings.server_url, sync_settings.device_id)
    except Exception as exc:
        console.print(f"\n[yellow]Sync checkpoints unavailable: {exc}[/yellow]")
        return

    console.print("\n[bold]Local Checkpoints[/bold]")
    console.print(f"Last push: {last_push or 'Never'}")
    console.print(f"Last pull: {last_pull or 'Never'}")


def _checkpoint_summary(settings: AppSettings) -> tuple[str, str]:
    """Return last push/pull checkpoint labels for compact menu display."""
    sync_settings = settings.sync
    if not sync_settings.device_id or not sync_settings.server_url:
        return "Unavailable", "Unavailable"

    try:
        db = get_database_manager()
        last_push = state.get_last_push(db, sync_settings.server_url, sync_settings.device_id)
        last_pull = state.get_last_pull(db, sync_settings.server_url, sync_settings.device_id)
    except Exception:
        return "Unavailable", "Unavailable"

    return last_push or "Never", last_pull or "Never"


def _auto_sync_summary(settings: AppSettings) -> str:
    """Return a compact auto-sync settings summary."""
    sync_settings = settings.sync
    enabled_hooks = []
    if sync_settings.auto_on_startup:
        enabled_hooks.append("startup")
    if sync_settings.auto_after_session:
        enabled_hooks.append("after session")
    if sync_settings.auto_on_exit:
        enabled_hooks.append("exit")

    hook_text = ", ".join(enabled_hooks) if enabled_hooks else "off"
    quiet_text = "quiet" if sync_settings.auto_quiet else "verbose"
    return f"{hook_text} ({quiet_text})"


def _print_sync_menu_header() -> None:
    """Render the compact Workmaster sync menu header."""
    settings = _load_settings()
    sync_settings = settings.sync
    last_push, last_pull = _checkpoint_summary(settings)
    server_url = sync_settings.server_url or "Not set"
    image_status = "off"
    if sync_settings.upload_images:
        image_status = f"on, workers={sync_settings.upload_image_workers}"

    console.print("\n[bold]Workmaster Sync[/bold]")
    console.print("================")
    console.print(f"Sync URL: [orange3]{server_url}[/orange3]")
    console.print(
        "[dim]"
        f"Enabled: {'Yes' if sync_settings.enabled else 'No'} | "
        f"Configuration: {_configuration_status(settings)} | "
        f"API key: {_key_status(settings)}"
        "[/dim]"
    )
    console.print(f"[dim]Auto-sync: {_auto_sync_summary(settings)} | Images: {image_status}[/dim]")
    console.print(f"[dim]Last push: {last_push}[/dim]")
    console.print(f"[dim]Last pull: {last_pull}[/dim]")


def edit_sync_settings(settings: AppSettings) -> None:
    """Edit Workmaster sync settings interactively."""
    console.print("\n[bold]Workmaster Sync Settings[/bold]")
    console.print("========================")
    console.print(
        "[dim]Create a Screenshooter API key in Workmaster Settings -> "
        "Screenshooter API Keys.[/dim]"
    )
    console.print(f"[dim]API key page: {_key_page_url(settings)}[/dim]\n")

    settings.sync.server_url = _prompt_on_new_line(
        "Workmaster server URL",
        default=_configured_server_url(settings),
    ).rstrip("/")

    if settings.sync.clerk_auth_token:
        update_key = _confirm_on_new_line("Update Screenshooter API key", default=False)
    else:
        update_key = True

    if update_key:
        settings.sync.clerk_auth_token = _prompt_on_new_line(
            "Screenshooter API key",
            password=True,
        )

    settings.sync.enabled = _confirm_on_new_line("Enable sync", default=True)
    if not settings.sync.enabled:
        return

    settings.sync.auto_on_startup = _confirm_on_new_line(
        "Auto-sync on app startup",
        default=settings.sync.auto_on_startup,
    )
    settings.sync.auto_after_session = _confirm_on_new_line(
        "Auto-sync after screenshot session ends",
        default=settings.sync.auto_after_session,
    )
    settings.sync.auto_on_exit = _confirm_on_new_line(
        "Auto-sync on app exit",
        default=settings.sync.auto_on_exit,
    )
    settings.sync.auto_quiet = _confirm_on_new_line(
        "Quiet successful automatic sync messages",
        default=settings.sync.auto_quiet,
    )
    settings.sync.upload_images = _confirm_on_new_line(
        "Upload screenshot images to Workmaster R2",
        default=settings.sync.upload_images,
    )
    if settings.sync.upload_images:
        settings.sync.upload_image_workers = _prompt_int_on_new_line(
            "Parallel image upload workers",
            saved_value=settings.sync.upload_image_workers,
            minimum=1,
            maximum=32,
            default_value=8,
        )


def _print_next_steps(settings: AppSettings) -> None:
    """Render concise guidance after default sync status output."""
    if not _has_required_sync_fields(settings):
        console.print("\n[dim]Run `screenshooter sync setup` to configure Workmaster sync.[/dim]")
        console.print("[dim]Run `screenshooter sync open-key-page` to create an API key.[/dim]")
        return

    if not settings.sync.enabled:
        console.print("\n[dim]Run `screenshooter sync enable` to enable sync.[/dim]")
        return

    console.print("\n[dim]Run `screenshooter sync run` to start a sync cycle.[/dim]")


def _run_sync_cycle(*, debug: bool = False) -> None:
    """Run one Workmaster sync cycle with user-facing output."""
    settings = _load_settings()
    sync_settings = settings.sync

    if not sync_settings.enabled:
        console.print("[yellow]Sync is disabled.[/yellow]")
        console.print("[dim]Run `screenshooter sync enable` or `screenshooter sync setup`.[/dim]")
        return

    missing = []
    if not sync_settings.server_url:
        missing.append("server URL")
    if not sync_settings.clerk_auth_token:
        missing.append("Screenshooter API key")
    if missing:
        console.print(f"[yellow]Sync is missing: {', '.join(missing)}.[/yellow]")
        console.print("[dim]Run `screenshooter sync setup` to configure sync.[/dim]")
        return

    console.print("[bold]Running Workmaster sync...[/bold]")
    if debug:
        console.print("[dim cyan][sync debug][/dim cyan] Debug output enabled.")
    result = SyncManager(
        settings,
        debug=debug,
        debug_callback=_print_debug,
        show_progress=not debug,
    ).sync()
    if result.success:
        parts = [f"Pushed: {result.pushed}.", f"Pulled: {result.pulled}."]
        if settings.sync.upload_images:
            parts.append(f"Images uploaded: {result.images_uploaded}.")
            if result.images_failed:
                parts.append(f"[yellow]Images failed: {result.images_failed}.[/yellow]")
        console.print(f"[green]Sync complete.[/green] {' '.join(parts)}")
    else:
        message = result.error or result.skipped_reason or "Sync did not complete."
        console.print(f"[bold red]{message}[/bold red]")

    if debug:
        log_path = get_sync_log_file()
        console.print(f"[dim]Debug log: {log_path}[/dim]")


def _open_sync_logs() -> None:
    """Open the ScreenShooter logs directory."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    get_sync_log_file()
    if _open_path_cross_platform(LOGS_DIR):
        console.print(f"[green]Opened logs directory:[/green] {LOGS_DIR}")
        return
    console.print(f"[yellow]Could not open logs directory:[/yellow] {LOGS_DIR}")


def _clear_api_key() -> None:
    """Clear the stored Screenshooter API key."""
    settings = _load_settings()
    settings.sync.clerk_auth_token = ""
    _save_settings(settings)
    console.print("[yellow]Screenshooter API key cleared.[/yellow]")


def _open_key_page() -> None:
    """Open the Workmaster Screenshooter API Keys page."""
    settings = _load_settings()
    url = _key_page_url(settings)
    if webbrowser.open(url):
        console.print(f"[green]Opened API key page:[/green] {url}")
        return
    console.print(f"[yellow]Could not open API key page:[/yellow] {url}")


def _pause_after_menu_action() -> None:
    """Wait for Enter after an interactive menu action."""
    input("\nPress Enter to continue...")


def _run_interactive_sync_menu() -> None:
    """Run the numbered Workmaster sync menu."""
    while True:
        _print_sync_menu_header()
        console.print("")
        console.print("1. Run Sync")
        console.print("2. Sync Status")
        console.print("3. Sync Settings")
        console.print("4. Open Logs")
        console.print("5. Open API Key Page")
        console.print("6. Clear API Key")

        choice = _prompt_on_new_line(
            "\nSelect an option (or 'b' to go back)",
            choices=["1", "2", "3", "4", "5", "6", "b"],
            default="1",
        )

        if choice == "1":
            _run_sync_cycle()
            _pause_after_menu_action()
            continue

        if choice == "2":
            _print_sync_status(_load_settings())
            _pause_after_menu_action()
            continue

        if choice == "3":
            settings = _load_settings()
            edit_sync_settings(settings)
            _save_settings(settings, allow_overwrite_on_failed_load=True)
            console.print("[green]Sync settings saved.[/green]")
            _pause_after_menu_action()
            continue

        if choice == "4":
            _open_sync_logs()
            _pause_after_menu_action()
            continue

        if choice == "5":
            _open_key_page()
            _pause_after_menu_action()
            continue

        if choice == "6":
            if _confirm_on_new_line(
                "Are you sure you want to clear the Screenshooter API key? Sync will stop working",
                default=False,
            ):
                _clear_api_key()
            else:
                console.print("[dim]Screenshooter API key unchanged.[/dim]")
            _pause_after_menu_action()
            continue

        if choice == "b":
            return


@click.group(invoke_without_command=True)
@click.pass_context
def sync(ctx: click.Context) -> None:
    """Configure and run Workmaster sync."""
    if ctx.invoked_subcommand is not None:
        return
    _run_interactive_sync_menu()


@sync.command()
def status() -> None:
    """Show current Workmaster sync settings and checkpoints."""
    _print_sync_status(_load_settings())


@sync.command()
def setup() -> None:
    """Interactively configure Workmaster sync."""
    settings = _load_settings()
    edit_sync_settings(settings)
    _save_settings(settings, allow_overwrite_on_failed_load=True)
    console.print("[green]Sync settings saved.[/green]")


def _print_debug(message: str) -> None:
    """Print a sync debug message."""
    console.print(f"[dim cyan][sync debug][/dim cyan] {message}")


@sync.command(name="run")
@click.option("--debug", is_flag=True, help="Show sanitized sync request/response details")
def run_sync(debug: bool) -> None:
    """Run one Workmaster sync cycle."""
    _run_sync_cycle(debug=debug)


@sync.command()
def enable() -> None:
    """Enable Workmaster sync."""
    settings = _load_settings()
    settings.sync.enabled = True
    _save_settings(settings)
    console.print("[green]Sync enabled.[/green]")


@sync.command()
def disable() -> None:
    """Disable Workmaster sync."""
    settings = _load_settings()
    settings.sync.enabled = False
    _save_settings(settings)
    console.print("[yellow]Sync disabled.[/yellow]")


@sync.command(name="reset-checkpoint")
def reset_checkpoint() -> None:
    """Clear the push checkpoint so the next sync re-pushes all records.

    Use this after adding new table support to Workmaster to force pre-existing
    local records to be included in the next push cycle.
    """
    settings = _load_settings()
    sync_settings = settings.sync
    if not sync_settings.server_url or not sync_settings.device_id:
        console.print("[yellow]Sync is not fully configured (missing server URL or device ID).[/yellow]")
        return
    db = get_database_manager()
    state.reset_push(db, sync_settings.server_url, sync_settings.device_id)
    console.print("[green]Push checkpoint cleared.[/green] The next sync will re-push all records.")


@sync.command(name="set")
@click.option("--server-url", help="Workmaster server URL")
@click.option("--api-key", help="Screenshooter API key")
@click.option(
    "--auto-on-startup/--no-auto-on-startup",
    default=None,
    help="Enable or disable automatic sync when the interactive app starts",
)
@click.option(
    "--auto-after-session/--no-auto-after-session",
    default=None,
    help="Enable or disable automatic sync after screenshot sessions end",
)
@click.option(
    "--auto-on-exit/--no-auto-on-exit",
    default=None,
    help="Enable or disable automatic sync when the interactive app exits",
)
@click.option(
    "--auto-quiet/--no-auto-quiet",
    default=None,
    help="Enable or disable quiet output for successful automatic sync",
)
@click.option(
    "--upload-images/--no-upload-images",
    default=None,
    help="Enable or disable uploading screenshot images to Workmaster R2",
)
@click.option(
    "--image-upload-workers",
    type=click.IntRange(1, 32),
    default=None,
    help="Number of parallel screenshot image uploads to run, from 1 to 32.",
)
def set_sync_settings(  # noqa: PLR0913 - Click passes one argument per option.
    server_url: str | None,
    api_key: str | None,
    auto_on_startup: bool | None,
    auto_after_session: bool | None,
    auto_on_exit: bool | None,
    auto_quiet: bool | None,
    upload_images: bool | None,
    image_upload_workers: int | None,
) -> None:
    """Set sync settings non-interactively."""
    if (
        server_url is None
        and api_key is None
        and auto_on_startup is None
        and auto_after_session is None
        and auto_on_exit is None
        and auto_quiet is None
        and upload_images is None
        and image_upload_workers is None
    ):
        console.print(
            "[yellow]No changes requested. Use --server-url, --api-key, "
            "an auto-sync flag, or an image upload option.[/yellow]"
        )
        return

    settings = _load_settings()
    if server_url is not None:
        settings.sync.server_url = server_url.strip().rstrip("/")
    if api_key is not None:
        settings.sync.clerk_auth_token = api_key.strip()
    if auto_on_startup is not None:
        settings.sync.auto_on_startup = auto_on_startup
    if auto_after_session is not None:
        settings.sync.auto_after_session = auto_after_session
    if auto_on_exit is not None:
        settings.sync.auto_on_exit = auto_on_exit
    if auto_quiet is not None:
        settings.sync.auto_quiet = auto_quiet
    if upload_images is not None:
        settings.sync.upload_images = upload_images
    if image_upload_workers is not None:
        settings.sync.upload_image_workers = image_upload_workers

    _save_settings(settings)
    console.print("[green]Sync settings updated.[/green]")


@sync.command()
def clear_key() -> None:
    """Clear the stored Screenshooter API key."""
    _clear_api_key()


@sync.command()
def open_key_page() -> None:
    """Open the Workmaster Screenshooter API Keys page."""
    _open_key_page()
