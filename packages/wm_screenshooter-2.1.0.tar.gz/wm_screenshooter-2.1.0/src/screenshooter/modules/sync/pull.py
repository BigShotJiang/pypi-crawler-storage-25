"""Apply remote changes from the Workmaster sync API to the local SQLite database.

Strategy:
- Fetch changes via GET /sync/pull?since=<timestamp>, or GET /sync/full on first pull.
- Match each incoming record to a local row by remote_uuid.
- If no local row exists for the UUID, skip (records are always created locally first).
- Apply upserts: update local fields that may have changed in the dashboard.
- Apply deletes (deleted_at non-null): set archived_at and deleted_at on local row.
- Only update if incoming updated_at is newer than the local updated_at.

This module intentionally does not create new local records from remote-only
data, because the local integer FK hierarchy (client → project → session) would
require resolving parent IDs that may not exist locally.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from screenshooter.modules.database.database import DatabaseManager

from .transport import SyncTransport


@dataclass(frozen=True)
class PullRunResult:
    """Result from one remote-to-local pull pass."""

    server_time: str
    seen: int = 0
    applied: int = 0


def _parse_ts(val: str | datetime | None) -> datetime | None:
    if not val:
        return None
    if isinstance(val, datetime):
        return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(val, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def _is_newer(
    incoming_updated_at: str | datetime | None,
    local_updated_at: str | datetime | None,
) -> bool:
    """Return True if the incoming timestamp is strictly newer than the local one."""
    incoming = _parse_ts(incoming_updated_at)
    local = _parse_ts(local_updated_at)
    if incoming is None:
        return False
    if local is None:
        return True
    return incoming > local


def _apply_client(db: DatabaseManager, record: dict[str, Any]) -> bool:
    remote_uuid = record.get("uuid")
    if not remote_uuid:
        return False
    cursor = db.execute_query(
        "SELECT id, updated_at FROM clients WHERE remote_uuid = ?", (remote_uuid,)
    )
    row = cursor.fetchone()
    if row is None:
        return False  # not created locally yet — skip

    if not _is_newer(record.get("updated_at"), row["updated_at"]):
        return False

    if record.get("deleted_at"):
        db.execute_query(
            "UPDATE clients SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),"
            " deleted_at = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (record["deleted_at"], row["id"]),
        )
        return True

    db.execute_query(
        """
        UPDATE clients SET
            name = COALESCE(?, name),
            company_name = COALESCE(?, company_name),
            contact_name = COALESCE(?, contact_name),
            contact_email = COALESCE(?, contact_email),
            pdf_password = COALESCE(?, pdf_password),
            preferences = COALESCE(?, preferences),
            archived_at = ?,
            deleted_at = NULL,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            record.get("name"),
            record.get("company_name"),
            record.get("contact_name"),
            record.get("contact_email"),
            record.get("pdf_password"),
            record.get("preferences"),
            record.get("archived_at"),
            row["id"],
        ),
    )
    return True


def _apply_project(db: DatabaseManager, record: dict[str, Any]) -> bool:
    remote_uuid = record.get("uuid")
    if not remote_uuid:
        return False
    cursor = db.execute_query(
        "SELECT id, updated_at FROM projects WHERE remote_uuid = ?", (remote_uuid,)
    )
    row = cursor.fetchone()
    if row is None:
        return False

    if not _is_newer(record.get("updated_at"), row["updated_at"]):
        return False

    if record.get("deleted_at"):
        db.execute_query(
            "UPDATE projects SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),"
            " deleted_at = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (record["deleted_at"], row["id"]),
        )
        return True

    db.execute_query(
        """
        UPDATE projects SET
            name = COALESCE(?, name),
            archived_at = ?,
            deleted_at = NULL,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (record.get("name"), record.get("archived_at"), row["id"]),
    )
    return True


def _apply_session(db: DatabaseManager, record: dict[str, Any]) -> bool:
    remote_uuid = record.get("uuid")
    if not remote_uuid:
        return False
    cursor = db.execute_query(
        "SELECT id, updated_at FROM sessions WHERE remote_uuid = ?", (remote_uuid,)
    )
    row = cursor.fetchone()
    if row is None:
        return False

    if not _is_newer(record.get("updated_at"), row["updated_at"]):
        return False

    now_iso = record.get("updated_at", "")

    if record.get("deleted_at"):
        db.execute_query(
            "UPDATE sessions SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),"
            " deleted_at = ?, updated_at = ? WHERE id = ?",
            (record["deleted_at"], now_iso, row["id"]),
        )
        return True

    db.execute_query(
        """
        UPDATE sessions SET
            name = COALESCE(?, name),
            end_time = COALESCE(?, end_time),
            duration_seconds = COALESCE(?, duration_seconds),
            timer_mode = COALESCE(?, timer_mode),
            archived_at = ?,
            deleted_at = NULL,
            updated_at = ?
        WHERE id = ?
        """,
        (
            record.get("name"),
            record.get("end_time"),
            record.get("duration_seconds"),
            record.get("timer_mode"),
            record.get("archived_at"),
            now_iso,
            row["id"],
        ),
    )
    return True


def _apply_screenshot(db: DatabaseManager, record: dict[str, Any]) -> bool:
    remote_uuid = record.get("uuid")
    if not remote_uuid:
        return False
    cursor = db.execute_query(
        "SELECT id, updated_at FROM screenshots WHERE remote_uuid = ?", (remote_uuid,)
    )
    row = cursor.fetchone()
    if row is None:
        return False

    if not _is_newer(record.get("updated_at"), row["updated_at"]):
        return False

    now_iso = record.get("updated_at", "")

    if record.get("deleted_at"):
        db.execute_query(
            "UPDATE screenshots SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),"
            " deleted_at = ?, updated_at = ? WHERE id = ?",
            (record["deleted_at"], now_iso, row["id"]),
        )
        return True

    db.execute_query(
        """
        UPDATE screenshots SET
            archived_at = ?,
            deleted_at = NULL,
            updated_at = ?
        WHERE id = ?
        """,
        (record.get("archived_at"), now_iso, row["id"]),
    )
    return True


def _apply_note(db: DatabaseManager, record: dict[str, Any]) -> bool:
    remote_uuid = record.get("uuid")
    if not remote_uuid:
        return False
    cursor = db.execute_query(
        "SELECT id, updated_at FROM notes WHERE remote_uuid = ?", (remote_uuid,)
    )
    row = cursor.fetchone()
    if row is None:
        return False

    if not _is_newer(record.get("updated_at"), row["updated_at"]):
        return False

    now_iso = record.get("updated_at", "")

    if record.get("deleted_at"):
        db.execute_query(
            "UPDATE notes SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),"
            " deleted_at = ?, updated_at = ? WHERE id = ?",
            (record["deleted_at"], now_iso, row["id"]),
        )
        return True

    db.execute_query(
        """
        UPDATE notes SET
            content = COALESCE(?, content),
            archived_at = ?,
            deleted_at = NULL,
            updated_at = ?
        WHERE id = ?
        """,
        (record.get("content"), record.get("archived_at"), now_iso, row["id"]),
    )
    return True


def _apply_project_goal(db: DatabaseManager, record: dict[str, Any]) -> bool:
    remote_uuid = record.get("uuid")
    if not remote_uuid:
        return False
    cursor = db.execute_query(
        "SELECT id, updated_at FROM project_goals WHERE remote_uuid = ?", (remote_uuid,)
    )
    row = cursor.fetchone()
    if row is None:
        return False

    if not _is_newer(record.get("updated_at"), row["updated_at"]):
        return False

    now_iso = record.get("updated_at", "")

    if record.get("deleted_at"):
        db.execute_query(
            "UPDATE project_goals SET"
            " archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),"
            " deleted_at = ?, updated_at = ? WHERE id = ?",
            (record["deleted_at"], now_iso, row["id"]),
        )
        return True

    db.execute_query(
        """
        UPDATE project_goals SET
            title = COALESCE(?, title),
            description = COALESCE(?, description),
            status = COALESCE(?, status),
            completed_at = ?,
            archived_at = ?,
            deleted_at = NULL,
            updated_at = ?
        WHERE id = ?
        """,
        (
            record.get("title"),
            record.get("description"),
            record.get("status"),
            record.get("completed_at"),
            record.get("archived_at"),
            now_iso,
            row["id"],
        ),
    )
    return True


def _apply_project_goal_note(db: DatabaseManager, record: dict[str, Any]) -> bool:
    remote_uuid = record.get("uuid")
    if not remote_uuid:
        return False
    cursor = db.execute_query(
        "SELECT id, updated_at FROM project_goal_notes WHERE remote_uuid = ?", (remote_uuid,)
    )
    row = cursor.fetchone()
    if row is None:
        return False

    if not _is_newer(record.get("updated_at"), row["updated_at"]):
        return False

    now_iso = record.get("updated_at", "")

    if record.get("deleted_at"):
        db.execute_query(
            "UPDATE project_goal_notes SET"
            " archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),"
            " deleted_at = ?, updated_at = ? WHERE id = ?",
            (record["deleted_at"], now_iso, row["id"]),
        )
        return True

    db.execute_query(
        """
        UPDATE project_goal_notes SET
            content = COALESCE(?, content),
            archived_at = ?,
            deleted_at = NULL,
            updated_at = ?
        WHERE id = ?
        """,
        (record.get("content"), record.get("archived_at"), now_iso, row["id"]),
    )
    return True


_APPLIERS = {
    "clients": _apply_client,
    "projects": _apply_project,
    "sessions": _apply_session,
    "screenshots": _apply_screenshot,
    "notes": _apply_note,
    "project_goals": _apply_project_goal,
    "project_goal_notes": _apply_project_goal_note,
}


def run(
    db: DatabaseManager,
    transport: SyncTransport,
    last_pull: str | None,
) -> PullRunResult:
    """Fetch and apply remote changes and return server checkpoint/counts."""
    response = transport.pull(since=last_pull) if last_pull else transport.full()
    changes: list[dict[str, Any]] = response.get("changes", [])
    server_time: str = response.get("server_time", "")

    applied = 0
    for change in changes:
        table = change.get("table", "")
        record = change.get("record", {})
        applier = _APPLIERS.get(table)
        if applier is None:
            continue
        if applier(db, record):
            applied += 1

    db.commit()
    return PullRunResult(server_time=server_time, seen=len(changes), applied=applied)
