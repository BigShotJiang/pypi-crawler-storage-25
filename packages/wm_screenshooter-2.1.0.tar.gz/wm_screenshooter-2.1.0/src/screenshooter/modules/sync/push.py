"""Build and send push payloads to the Workmaster sync API.

Strategy:
- For each table, fetch all records where updated_at > last_push (or all
  records when last_push is None / first sync).
- Translate local integer FK references to remote_uuid equivalents.
- Batch all changes into a single POST /sync/push call.
- Return the server_time from the response so the caller can checkpoint it.

Timestamp normalisation:
  clients/projects use SQLite CURRENT_TIMESTAMP format (YYYY-MM-DD HH:MM:SS).
  sessions/screenshots/notes use ISO 8601 (YYYY-MM-DDTHH:MM:SS.sssZ).
  Both are parsed to aware UTC datetimes for comparison; all outbound
  payloads use ISO 8601 with milliseconds.
"""

from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from screenshooter.modules.database.database import DatabaseManager
from screenshooter.modules.settings.logging_utils import get_sync_logger

from .transport import SyncTransport

_logger = get_sync_logger("screenshooter.sync.push")

_DebugFn = Callable[[str], None] | None

# The Workmaster Durable Object writes two D1 statements per change
# (upsert + change log). Keep this safely below D1's free-tier per-invocation
# query limit while still batching enough records to avoid excessive requests.
_BATCH_SIZE = 20


@dataclass(frozen=True)
class PushRunResult:
    """Result from one local-to-remote push pass."""

    server_time: str
    accepted: int = 0
    rejected: int = 0


def _parse_ts(val: str | datetime | None) -> datetime | None:
    """Parse any local timestamp string to an aware UTC datetime."""
    if not val:
        return None
    if isinstance(val, datetime):
        return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d %H:%M:%S",
    ):
        try:
            dt = datetime.strptime(val, fmt)
            return dt.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def _to_iso(val: str | datetime | None) -> str | None:
    """Convert any timestamp to ISO 8601 UTC with milliseconds."""
    if val is None:
        return None
    if isinstance(val, datetime):
        dt = val if val.tzinfo else val.replace(tzinfo=timezone.utc)
        ms = dt.microsecond // 1000
        return dt.strftime(f"%Y-%m-%dT%H:%M:%S.{ms:03d}Z")
    parsed = _parse_ts(str(val))
    if parsed is None:
        return str(val)
    ms = parsed.microsecond // 1000
    return parsed.strftime(f"%Y-%m-%dT%H:%M:%S.{ms:03d}Z")


def _after(ts_str: str | datetime | None, since: datetime | None) -> bool:
    """Return True if ts_str represents a time strictly after since."""
    if since is None:
        return True
    parsed = _parse_ts(ts_str)
    if parsed is None:
        return True  # NULL updated_at — include so it gets a timestamp on remote
    parsed = parsed.replace(microsecond=0)
    since = since.replace(microsecond=0)
    return parsed > since


def _fetch_uuid(db: DatabaseManager, table: str, local_id: int | None) -> str | None:
    """Look up remote_uuid for a record by its local integer id."""
    if local_id is None:
        return None
    cursor = db.execute_query(
        f"SELECT remote_uuid FROM {table} WHERE id = ?",
        (local_id,),
    )
    row = cursor.fetchone()
    return row["remote_uuid"] if row else None


def _build_clients(db: DatabaseManager, since: datetime | None) -> list[dict[str, Any]]:
    cursor = db.execute_query("SELECT * FROM clients")
    changes = []
    for row in cursor.fetchall():
        if not _after(row["updated_at"], since):
            _logger.debug("clients: id=%s skipped (timestamp %s)", row["id"], row["updated_at"])
            continue
        if row["remote_uuid"] is None:
            _logger.debug("clients: id=%s skipped (no remote_uuid)", row["id"])
            continue
        record: dict[str, Any] = {
            "uuid": row["remote_uuid"],
            "name": row["name"],
            "directory_name": row["directory_name"],
            "company_name": row["company_name"] or "",
            "contact_name": row["contact_name"] or "",
            "contact_email": row["contact_email"] or "",
            "pdf_password": row["pdf_password"] or "",
            "preferences": row["preferences"] or "{}",
            "archived_at": _to_iso(row["archived_at"]),
            "deleted_at": row["deleted_at"],
            "created_at": _to_iso(row["created_at"]),
            "updated_at": _to_iso(row["updated_at"]),
        }
        operation = "delete" if row["deleted_at"] else "upsert"
        _logger.debug("clients: id=%s queued (%s)", row["id"], operation)
        changes.append({"table": "clients", "operation": operation, "record": record})
    return changes


def _build_projects(db: DatabaseManager, since: datetime | None) -> list[dict[str, Any]]:
    cursor = db.execute_query("SELECT * FROM projects")
    changes = []
    for row in cursor.fetchall():
        if not _after(row["updated_at"], since):
            _logger.debug("projects: id=%s skipped (timestamp %s)", row["id"], row["updated_at"])
            continue
        if row["remote_uuid"] is None:
            _logger.debug("projects: id=%s skipped (no remote_uuid)", row["id"])
            continue
        client_uuid = _fetch_uuid(db, "clients", row["client_id"])
        if client_uuid is None:
            _logger.debug(
                "projects: id=%s skipped (client_id=%s has no remote_uuid)",
                row["id"], row["client_id"],
            )
            continue
        record: dict[str, Any] = {
            "uuid": row["remote_uuid"],
            "client_uuid": client_uuid,
            "name": row["name"],
            "directory_name": row["directory_name"],
            "archived_at": _to_iso(row["archived_at"]),
            "deleted_at": row["deleted_at"],
            "created_at": _to_iso(row["created_at"]),
            "updated_at": _to_iso(row["updated_at"]),
        }
        operation = "delete" if row["deleted_at"] else "upsert"
        _logger.debug("projects: id=%s queued (%s)", row["id"], operation)
        changes.append({"table": "projects", "operation": operation, "record": record})
    return changes


def _build_sessions(db: DatabaseManager, since: datetime | None) -> list[dict[str, Any]]:
    cursor = db.execute_query("SELECT * FROM sessions")
    changes = []
    for row in cursor.fetchall():
        if not _after(row["updated_at"], since):
            _logger.debug("sessions: id=%s skipped (timestamp %s)", row["id"], row["updated_at"])
            continue
        if row["remote_uuid"] is None:
            _logger.debug("sessions: id=%s skipped (no remote_uuid)", row["id"])
            continue
        project_uuid = _fetch_uuid(db, "projects", row["project_id"])
        if project_uuid is None:
            _logger.debug(
                "sessions: id=%s skipped (project_id=%s has no remote_uuid)",
                row["id"], row["project_id"],
            )
            continue
        record: dict[str, Any] = {
            "uuid": row["remote_uuid"],
            "project_uuid": project_uuid,
            "name": row["name"] or "",
            "start_time": _to_iso(row["start_time"]),
            "end_time": _to_iso(row["end_time"]),
            "duration_seconds": row["duration_seconds"] or 0,
            "timer_mode": row["timer_mode"],
            "archived_at": _to_iso(row["archived_at"]),
            "deleted_at": row["deleted_at"],
            "created_at": _to_iso(row["created_at"]),
            "updated_at": row["updated_at"],
        }
        operation = "delete" if row["deleted_at"] else "upsert"
        _logger.debug("sessions: id=%s queued (%s)", row["id"], operation)
        changes.append({"table": "sessions", "operation": operation, "record": record})
    return changes


def _build_screenshots(db: DatabaseManager, since: datetime | None) -> list[dict[str, Any]]:
    cursor = db.execute_query("SELECT * FROM screenshots")
    changes = []
    for row in cursor.fetchall():
        if not _after(row["updated_at"], since):
            _logger.debug("screenshots: id=%s skipped (timestamp %s)", row["id"], row["updated_at"])
            continue
        if row["remote_uuid"] is None:
            _logger.debug("screenshots: id=%s skipped (no remote_uuid)", row["id"])
            continue
        session_uuid = _fetch_uuid(db, "sessions", row["session_id"])
        if session_uuid is None:
            _logger.debug(
                "screenshots: id=%s skipped (session_id=%s has no remote_uuid)",
                row["id"], row["session_id"],
            )
            continue
        record: dict[str, Any] = {
            "uuid": row["remote_uuid"],
            "session_uuid": session_uuid,
            "set_id": row["set_id"],
            "file_path": row["file_path"],
            "r2_key": None,  # R2 upload not yet implemented
            "timestamp": _to_iso(row["timestamp"]),
            "display_mode": row["display_mode"],
            "suffix": row["suffix"],
            "archived_at": _to_iso(row["archived_at"]),
            "deleted_at": row["deleted_at"],
            "created_at": _to_iso(row["created_at"]),
            "updated_at": row["updated_at"],
        }
        operation = "delete" if row["deleted_at"] else "upsert"
        _logger.debug("screenshots: id=%s queued (%s)", row["id"], operation)
        changes.append({"table": "screenshots", "operation": operation, "record": record})
    return changes


def _build_notes(db: DatabaseManager, since: datetime | None) -> list[dict[str, Any]]:
    cursor = db.execute_query("SELECT * FROM notes")
    changes = []
    for row in cursor.fetchall():
        if not _after(row["updated_at"], since):
            _logger.debug("notes: id=%s skipped (timestamp %s)", row["id"], row["updated_at"])
            continue
        if row["remote_uuid"] is None:
            _logger.debug("notes: id=%s skipped (no remote_uuid)", row["id"])
            continue
        session_uuid = _fetch_uuid(db, "sessions", row["session_id"])
        if session_uuid is None:
            _logger.debug(
                "notes: id=%s skipped (session_id=%s has no remote_uuid)",
                row["id"], row["session_id"],
            )
            continue
        record: dict[str, Any] = {
            "uuid": row["remote_uuid"],
            "session_uuid": session_uuid,
            "content": row["content"],
            "note_type": row["note_type"] or "note",
            "timestamp": _to_iso(row["timestamp"]),
            "archived_at": _to_iso(row["archived_at"]),
            "deleted_at": row["deleted_at"],
            "created_at": _to_iso(row["created_at"]),
            "updated_at": row["updated_at"],
        }
        operation = "delete" if row["deleted_at"] else "upsert"
        _logger.debug("notes: id=%s queued (%s)", row["id"], operation)
        changes.append({"table": "notes", "operation": operation, "record": record})
    return changes


def _build_project_goals(db: DatabaseManager, since: datetime | None) -> list[dict[str, Any]]:
    cursor = db.execute_query("SELECT * FROM project_goals")
    changes = []
    for row in cursor.fetchall():
        if not _after(row["updated_at"], since):
            _logger.debug(
                "project_goals: id=%s skipped (timestamp %s)", row["id"], row["updated_at"]
            )
            continue
        if row["remote_uuid"] is None:
            _logger.debug("project_goals: id=%s skipped (no remote_uuid)", row["id"])
            continue
        project_uuid = _fetch_uuid(db, "projects", row["project_id"])
        if project_uuid is None:
            _logger.debug(
                "project_goals: id=%s skipped (project_id=%s has no remote_uuid)",
                row["id"], row["project_id"],
            )
            continue
        created_session_uuid = None
        if row["created_session_id"] is not None:
            created_session_uuid = _fetch_uuid(db, "sessions", row["created_session_id"])
            if created_session_uuid is None:
                _logger.debug(
                    "project_goals: id=%s created_session_id=%s missing remote_uuid, null used",
                    row["id"], row["created_session_id"],
                )
        closed_session_uuid = None
        if row["closed_session_id"] is not None:
            closed_session_uuid = _fetch_uuid(db, "sessions", row["closed_session_id"])
            if closed_session_uuid is None:
                _logger.debug(
                    "project_goals: id=%s closed_session_id=%s missing remote_uuid, null used",
                    row["id"], row["closed_session_id"],
                )
        record: dict[str, Any] = {
            "uuid": row["remote_uuid"],
            "project_uuid": project_uuid,
            "title": row["title"],
            "description": row["description"] or "",
            "status": row["status"] or "active",
            "created_session_uuid": created_session_uuid,
            "closed_session_uuid": closed_session_uuid,
            "completed_at": _to_iso(row["completed_at"]),
            "archived_at": _to_iso(row["archived_at"]),
            "deleted_at": row["deleted_at"],
            "created_at": _to_iso(row["created_at"]),
            "updated_at": _to_iso(row["updated_at"]),
        }
        operation = "delete" if row["deleted_at"] else "upsert"
        _logger.debug("project_goals: id=%s queued (%s)", row["id"], operation)
        changes.append({"table": "project_goals", "operation": operation, "record": record})
    return changes


def _build_project_goal_notes(db: DatabaseManager, since: datetime | None) -> list[dict[str, Any]]:
    cursor = db.execute_query("SELECT * FROM project_goal_notes")
    changes = []
    for row in cursor.fetchall():
        if not _after(row["updated_at"], since):
            _logger.debug(
                "project_goal_notes: id=%s skipped (timestamp %s)", row["id"], row["updated_at"]
            )
            continue
        if row["remote_uuid"] is None:
            _logger.debug("project_goal_notes: id=%s skipped (no remote_uuid)", row["id"])
            continue
        goal_uuid = _fetch_uuid(db, "project_goals", row["goal_id"])
        if goal_uuid is None:
            _logger.debug(
                "project_goal_notes: id=%s skipped (goal_id=%s has no remote_uuid)",
                row["id"], row["goal_id"],
            )
            continue
        session_uuid = None
        if row["session_id"] is not None:
            session_uuid = _fetch_uuid(db, "sessions", row["session_id"])
            if session_uuid is None:
                _logger.debug(
                    "project_goal_notes: id=%s skipped (session_id=%s has no remote_uuid)",
                    row["id"], row["session_id"],
                )
                continue
        record: dict[str, Any] = {
            "uuid": row["remote_uuid"],
            "goal_uuid": goal_uuid,
            "session_uuid": session_uuid,
            "content": row["content"],
            "note_type": row["note_type"] or "progress",
            "timestamp": _to_iso(row["timestamp"]),
            "archived_at": _to_iso(row["archived_at"]),
            "deleted_at": row["deleted_at"],
            "created_at": _to_iso(row["created_at"]),
            "updated_at": _to_iso(row["updated_at"]),
        }
        operation = "delete" if row["deleted_at"] else "upsert"
        _logger.debug("project_goal_notes: id=%s queued (%s)", row["id"], operation)
        changes.append({"table": "project_goal_notes", "operation": operation, "record": record})
    return changes


def run(
    db: DatabaseManager,
    transport: SyncTransport,
    device_id: str,
    last_push: str | None,
    debug: _DebugFn = None,
) -> PushRunResult:
    """Build and send push payload and return server checkpoint/counts."""
    since = _parse_ts(last_push)

    changes: list[dict[str, Any]] = []

    def _extend(new_items: list[dict[str, Any]], table_name: str) -> None:
        changes.extend(new_items)
        if debug:
            count = len(new_items)
            msg = f"{table_name}: {count} to push" if count else f"{table_name}: nothing new"
            debug(msg)

    # Order matters: parents before children so remote FK lookups succeed.
    _extend(_build_clients(db, since), "clients")
    _extend(_build_projects(db, since), "projects")
    _extend(_build_sessions(db, since), "sessions")
    _extend(_build_screenshots(db, since), "screenshots")
    _extend(_build_notes(db, since), "notes")
    _extend(_build_project_goals(db, since), "project_goals")
    _extend(_build_project_goal_notes(db, since), "project_goal_notes")

    if not changes:
        return PushRunResult(server_time="")

    # Send in batches to avoid oversized payloads.
    server_time: str = ""
    accepted = 0
    rejected = 0
    for i in range(0, len(changes), _BATCH_SIZE):
        batch = changes[i : i + _BATCH_SIZE]
        response = transport.push({"device_id": device_id, "changes": batch})
        server_time = response.get("server_time", server_time)
        accepted += int(response.get("accepted", 0) or 0)
        rejected += int(response.get("rejected", 0) or 0)

    return PushRunResult(server_time=server_time, accepted=accepted, rejected=rejected)
