"""Optional automatic Workmaster sync hooks."""

from __future__ import annotations

from enum import Enum

from rich.console import Console

from screenshooter.modules.settings.logging_utils import get_sync_logger
from screenshooter.modules.settings.settings_helper import get_settings
from screenshooter.modules.sync.manager import SyncManager, SyncResult


class AutoSyncTrigger(str, Enum):
    """Supported automatic sync trigger points."""

    STARTUP = "startup"
    AFTER_SESSION = "after_session"
    EXIT = "exit"


_TRIGGER_SETTING_ATTRS = {
    AutoSyncTrigger.STARTUP: "auto_on_startup",
    AutoSyncTrigger.AFTER_SESSION: "auto_after_session",
    AutoSyncTrigger.EXIT: "auto_on_exit",
}


def _is_trigger_enabled(trigger: AutoSyncTrigger, settings_attr: object) -> bool:
    """Return whether the given trigger is enabled on sync settings."""
    attr_name = _TRIGGER_SETTING_ATTRS[trigger]
    return bool(getattr(settings_attr, attr_name, False))


def maybe_run_auto_sync(
    trigger: AutoSyncTrigger,
    *,
    console: Console | None = None,
) -> SyncResult:
    """Run automatic sync for a trigger when configured.

    Automatic sync is intentionally non-blocking for callers: failures are
    returned and logged, but exceptions are caught and converted to SyncResult.
    """
    output = console or Console()
    logger = get_sync_logger("screenshooter.sync.auto")

    try:
        settings = get_settings()
        sync_settings = settings.sync
        quiet = bool(sync_settings.auto_quiet)

        if not sync_settings.enabled:
            logger.info("Auto-sync skipped for %s: sync disabled", trigger.value)
            return SyncResult(success=False, skipped_reason="Sync is disabled.")

        if not _is_trigger_enabled(trigger, sync_settings):
            logger.info("Auto-sync skipped for %s: trigger disabled", trigger.value)
            return SyncResult(success=False, skipped_reason="Auto-sync trigger is disabled.")

        missing = []
        if not sync_settings.server_url:
            missing.append("server URL")
        if not sync_settings.clerk_auth_token:
            missing.append("Screenshooter API key")
        if missing:
            message = f"Auto-sync skipped: missing {', '.join(missing)}."
            logger.warning(
                "Auto-sync skipped for %s: missing %s",
                trigger.value,
                ", ".join(missing),
            )
            if not quiet:
                output.print(f"[yellow]{message}[/yellow]")
            return SyncResult(success=False, skipped_reason=message)

        if not quiet:
            output.print(f"[bold]Auto-syncing with Workmaster ({trigger.value})...[/bold]")

        result = SyncManager(settings).sync()
        if result.success:
            logger.info(
                "Auto-sync complete for %s: pushed=%s pulled=%s images_uploaded=%s",
                trigger.value,
                result.pushed,
                result.pulled,
                result.images_uploaded,
            )
            if not quiet:
                parts = [f"Pushed: {result.pushed}.", f"Pulled: {result.pulled}."]
                if result.images_uploaded:
                    parts.append(f"Images uploaded: {result.images_uploaded}.")
                output.print(f"[green]Auto-sync complete.[/green] {' '.join(parts)}")
            return result

        message = result.error or result.skipped_reason or "Sync did not complete."
        logger.warning("Auto-sync failed for %s: %s", trigger.value, message)
        output.print(f"[yellow]Auto-sync failed: {message}[/yellow]")
        return result
    except Exception as exc:
        logger.exception("Auto-sync failed for %s with an unexpected error", trigger.value)
        message = f"Unexpected auto-sync error: {exc}"
        output.print(f"[yellow]Auto-sync failed: {message}[/yellow]")
        return SyncResult(success=False, error=message)
