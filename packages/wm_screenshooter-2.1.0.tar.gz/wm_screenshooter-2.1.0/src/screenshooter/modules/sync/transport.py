"""HTTP transport for the Workmaster sync API.

Uses the ``requests`` library (already a project dependency).
Raises typed exceptions so callers can distinguish auth failures from
transient network errors.
"""

import time
from collections.abc import Callable
from typing import Any

import requests


class SyncAuthError(Exception):
    """Raised when the server returns a 401 or 403."""


class SyncServerError(Exception):
    """Raised when the server returns a 5xx response."""


class SyncTransportError(Exception):
    """Raised on network-level failures (timeout, connection refused, etc.)."""


class UploadPermanentError(Exception):
    """Raised when an upload endpoint returns a permanent rejection."""


_RETRY_DELAYS = (1, 2, 4)  # seconds between attempts
_CLIENT_ERROR_THRESHOLD = 400
_SERVER_ERROR_THRESHOLD = 500
_PERMANENT_UPLOAD_ERROR_CODES = {"size_too_large", "content_type_invalid"}


class SyncTransport:
    """Thin authenticated HTTP client for the Workmaster sync API."""

    def __init__(
        self,
        server_url: str,
        clerk_auth_token: str,
        timeout: int = 30,
        device_id: str | None = None,
        debug_callback: Callable[[str], None] | None = None,
    ) -> None:
        self._base = server_url.rstrip("/")
        self._headers = {
            "Authorization": f"Bearer {clerk_auth_token}",
            "Content-Type": "application/json",
        }
        if device_id:
            self._headers["X-WorkMaster-Device-Id"] = device_id
        self._timeout = timeout
        self._debug_callback = debug_callback

    def push(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST /sync/push and return the parsed JSON response."""
        return self._post("/sync/push", payload)

    def pull(self, since: str | None = None) -> dict[str, Any]:
        """GET /sync/pull (optionally filtered by since timestamp)."""
        params = {"since": since} if since else {}
        return self._get("/sync/pull", params)

    def full(self) -> dict[str, Any]:
        """GET /sync/full — complete snapshot."""
        return self._get("/sync/full", {})

    def upload_prepare(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST /sync/screenshots/upload/prepare and return presigned upload URLs."""
        return self._post("/sync/screenshots/upload/prepare", payload)

    def upload_complete(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST /sync/screenshots/upload/complete to confirm a finished R2 upload."""
        return self._post("/sync/screenshots/upload/complete", payload)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        url = self._base + path
        last_exc: Exception = RuntimeError("No attempts made")
        for attempt, delay in enumerate((*_RETRY_DELAYS, None), start=1):
            try:
                self._debug_request("POST", path, attempt, body=body)
                resp = requests.post(url, json=body, headers=self._headers, timeout=self._timeout)
                self._debug_response("POST", path, resp)
                self._raise_for_status(resp)
                return resp.json()
            except (SyncAuthError, SyncServerError):
                raise
            except requests.RequestException as exc:
                last_exc = SyncTransportError(str(exc))
                self._debug(f"POST {path} transport error on attempt {attempt}: {exc}")
            if delay is not None:
                self._debug(f"POST {path} retrying in {delay}s")
                time.sleep(delay)
        raise last_exc

    def _get(self, path: str, params: dict[str, str]) -> dict[str, Any]:
        url = self._base + path
        last_exc: Exception = RuntimeError("No attempts made")
        for attempt, delay in enumerate((*_RETRY_DELAYS, None), start=1):
            try:
                self._debug_request("GET", path, attempt, params=params)
                resp = requests.get(
                    url, params=params, headers=self._headers, timeout=self._timeout
                )
                self._debug_response("GET", path, resp)
                self._raise_for_status(resp)
                return resp.json()
            except (SyncAuthError, SyncServerError):
                raise
            except requests.RequestException as exc:
                last_exc = SyncTransportError(str(exc))
                self._debug(f"GET {path} transport error on attempt {attempt}: {exc}")
            if delay is not None:
                self._debug(f"GET {path} retrying in {delay}s")
                time.sleep(delay)
        raise last_exc

    def _debug(self, message: str) -> None:
        """Emit a verbose sync message if debug output is enabled."""
        if self._debug_callback is not None:
            self._debug_callback(message)

    def _debug_request(
        self,
        method: str,
        path: str,
        attempt: int,
        *,
        body: dict[str, Any] | None = None,
        params: dict[str, str] | None = None,
    ) -> None:
        """Emit sanitized request details for verbose sync logging."""
        device_header = self._headers.get("X-WorkMaster-Device-Id", "not set")
        self._debug(f"{method} {self._base}{path} attempt={attempt}")
        self._debug(
            "Headers: Authorization=<redacted>; "
            f"Content-Type={self._headers.get('Content-Type')}; "
            f"X-WorkMaster-Device-Id={device_header}"
        )
        if params:
            self._debug(f"Query params: {params}")
        if body is not None:
            self._debug(f"Body summary: {self._summarize_body(body)}")

    def _debug_response(self, method: str, path: str, resp: requests.Response) -> None:
        """Emit sanitized response details for verbose sync logging."""
        elapsed_ms = int(resp.elapsed.total_seconds() * 1000)
        body = resp.text[:1000] if resp.text else ""
        self._debug(f"{method} {path} response status={resp.status_code} elapsed={elapsed_ms}ms")
        if body:
            self._debug(f"Response body: {body}")

    @staticmethod
    def _summarize_body(body: dict[str, Any]) -> str:
        """Return a compact, non-secret summary of a JSON body."""
        changes = body.get("changes")
        if not isinstance(changes, list):
            return f"keys={sorted(body.keys())}"

        by_table: dict[str, int] = {}
        by_operation: dict[str, int] = {}
        for change in changes:
            if not isinstance(change, dict):
                continue
            table = str(change.get("table") or "unknown")
            operation = str(change.get("operation") or "unknown")
            by_table[table] = by_table.get(table, 0) + 1
            by_operation[operation] = by_operation.get(operation, 0) + 1

        device_id = body.get("device_id")
        device_display = device_id if isinstance(device_id, str) and device_id else "not set"
        return (
            f"device_id={device_display}; changes={len(changes)}; "
            f"tables={by_table}; operations={by_operation}"
        )

    @staticmethod
    def _raise_for_status(resp: requests.Response) -> None:
        if resp.status_code in (401, 403):
            raise SyncAuthError(f"Auth error {resp.status_code}: {resp.text[:200]}")
        if resp.status_code >= _SERVER_ERROR_THRESHOLD:
            raise SyncServerError(f"Server error {resp.status_code}: {resp.text[:200]}")
        if resp.status_code >= _CLIENT_ERROR_THRESHOLD:
            try:
                payload = resp.json()
            except ValueError:
                payload = {}
            error_code = str(payload.get("code") or payload.get("error") or "")
            if error_code in _PERMANENT_UPLOAD_ERROR_CODES:
                raise UploadPermanentError(
                    f"Permanent upload error {resp.status_code}: {error_code}"
                )
        resp.raise_for_status()
