"""Workmaster sync module for ScreenShooter.

Provides push/pull synchronisation between the local SQLite database and
the remote Workmaster D1 database via the Workmaster sync API.
"""
