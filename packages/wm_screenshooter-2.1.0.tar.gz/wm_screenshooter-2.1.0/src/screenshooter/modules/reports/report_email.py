#!/usr/bin/env python3
"""Email functionality for ScreenShooter Mac reports."""

import base64
import logging
import smtplib
import traceback
from dataclasses import dataclass
from datetime import datetime
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any

import requests
from rich.console import Console

# Import S3 helper
from screenshooter.modules.s3 import S3Helper, generate_custom_link, get_s3_settings, is_s3_enabled
from screenshooter.modules.s3.helper import set_s3_debug_terminal_output

# Import the necessary helpers for custom links
from screenshooter.modules.settings.models import EmailSettings
from screenshooter.modules.settings.settings_helper import is_s3_custom_link_enabled

# Constants for URL expiration times
ONE_DAY_SECONDS = 86400
THREE_DAYS_SECONDS = 259200
SMTP_TIMEOUT_SECONDS = 20

# Initialize rich console
console = Console()

# Configure logging
logger = logging.getLogger("report_email")
logger.setLevel(logging.INFO)
DEBUG_TERMINAL_STATE = {"enabled": False}

# Remove any existing handlers to prevent duplicate logging
for handler in logger.handlers[:]:
    logger.removeHandler(handler)

# Prevent propagation to root logger (which might have console handlers)
logger.propagate = False


@dataclass
class EmailSendConfig:
    """Resolved email send configuration."""

    provider: str
    sender_email: str
    sender_name: str | None
    recipient_type: str
    debug: bool
    report_type: str
    extra_body_lines: list[str] | None
    report_meta: dict[str, Any] | None
    smtp: dict[str, Any]
    cloudflare: dict[str, Any]


@dataclass
class RecipientGroups:
    """Grouped recipient lists by header type."""

    to_recipients: list[str]
    cc_recipients: list[str]
    bcc_recipients: list[str]

    def all_recipients(self) -> list[str]:
        """Return flattened list of recipients for SMTP envelope."""
        recipients: list[str] = []
        recipients.extend(self.to_recipients)
        recipients.extend(self.cc_recipients)
        recipients.extend(self.bcc_recipients)
        return recipients


@dataclass
class EmailBodyContext:
    """Context for building plain and HTML email bodies."""

    config: EmailSendConfig
    client_info: dict[str, Any]
    project_name: str
    session_date: str
    pdf_url: str | None
    s3_settings: dict[str, Any]


@dataclass
class BatchEmailProjectReport:
    """Per-project payload used by batch email sends."""

    pdf_file: Path
    project_name: str
    report_type: str
    session_date: str
    report_meta: dict[str, Any] | None
    notes_lines: list[str] | None = None
    pdf_url: str | None = None


@dataclass
class CloudflareMessageContext:
    """Cloudflare message payload context."""

    subject: str
    body_text: str
    body_html: str
    recipient_groups: "RecipientGroups"
    s3_settings: dict[str, Any]
    pdf_files: list[Path]


def _set_debug_terminal_output(enabled: bool) -> None:
    """Enable or disable terminal mirroring for report email log entries."""
    DEBUG_TERMINAL_STATE["enabled"] = enabled


def _print_log_to_terminal(message: str, level: str) -> None:
    """Print a log message to the terminal using a level-appropriate style."""
    if level == "error":
        console.print(f"[bold red]{message}[/bold red]")
    elif level == "warning":
        console.print(f"[bold yellow]{message}[/bold yellow]")
    elif level == "debug":
        console.print(f"[dim]{message}[/dim]")
    else:
        console.print(message)


def log_entry(message: str, terminal_message: str | None = None, level: str = "info") -> None:
    """Log a message to both the log file and terminal.

    Args:
        message: Message to log to file
        terminal_message: Optional formatted message for terminal
            (if None or empty, no terminal output)
        level: Log level (info, warning, error, debug)
    """
    # Log to the appropriate level
    if level == "error":
        logger.error(message)
    elif level == "warning":
        logger.warning(message)
    elif level == "debug":
        logger.debug(message)
    else:
        logger.info(message)

    # Display in terminal when requested, or mirror log entries while report debug is active.
    if terminal_message and terminal_message.strip():
        _print_log_to_terminal(terminal_message, level)
    elif DEBUG_TERMINAL_STATE["enabled"]:
        _print_log_to_terminal(message, level)


def debug_log_entry(message: str, terminal_message: str | None, debug: bool) -> None:
    """Write a debug log entry and optionally expose it in the terminal."""
    if not debug:
        return
    log_entry(message, terminal_message, level="debug")


def setup_report_logging(project_path: Path) -> None:
    """Set up logging to write to the project's log files.

    Instead of using a separate report-generation.log file, this will now
    use the project's primary log files:
    - {project_name}_log.txt
    - {project_name}_report_generation_log.txt
    """
    # Extract project name from the path
    project_name = project_path.name

    # Define the log files
    master_log_file = project_path / f"{project_name}_log.txt"
    report_log_file = project_path / f"{project_name}_report_generation_log.txt"

    # Create the log files if they don't exist
    master_log_file.touch(exist_ok=True)
    report_log_file.touch(exist_ok=True)

    # Remove any existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Prevent propagation to root logger
    logger.propagate = False

    # Create a custom handler that writes to both files
    class DualFileHandler(logging.Handler):
        def emit(self, record):
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            message = record.getMessage()
            entry = f"[{timestamp}] {message}"

            # Write to both log files
            try:
                with open(master_log_file, "a") as f:
                    f.write(f"{entry}\n")
                with open(report_log_file, "a") as f:
                    f.write(f"{entry}\n")
            except Exception:
                # Fall back to standard logging if file write fails
                pass

    # Add the custom handler
    logger.addHandler(DualFileHandler())


def _resolve_send_config(email_options: dict[str, Any]) -> tuple[EmailSendConfig, list[str]]:
    """Resolve send config and additional recipients from kwargs."""
    normalized_options = EmailSettings._normalize_email_settings_data(email_options)
    sender_email = str(normalized_options.get("sender_email", ""))
    smtp_options = dict(normalized_options.get("smtp") or {})
    cloudflare_options = dict(normalized_options.get("cloudflare") or {})

    smtp_options.setdefault("server", "")
    smtp_options.setdefault("port", 587)
    smtp_options.setdefault("connection_security", "TLS")
    smtp_options.setdefault("username", sender_email)
    smtp_options.setdefault("password", "")

    cloudflare_options.setdefault("account_id", "")
    cloudflare_options.setdefault("api_token", "")

    config = EmailSendConfig(
        provider=str(normalized_options.get("provider", "smtp") or "smtp"),
        sender_email=sender_email,
        sender_name=normalized_options.get("sender_name"),
        recipient_type=str(normalized_options.get("recipient_type", "TO")),
        debug=bool(normalized_options.get("debug", False)),
        report_type=str(normalized_options.get("report_type", "session")),
        extra_body_lines=normalized_options.get("extra_body_lines"),
        report_meta=normalized_options.get("report_meta"),
        smtp={
            "server": str(smtp_options.get("server", "")),
            "port": int(smtp_options.get("port", 587) or 587),
            "connection_security": str(smtp_options.get("connection_security", "TLS") or "TLS"),
            "username": str(smtp_options.get("username") or sender_email),
            "password": str(smtp_options.get("password", "")),
        },
        cloudflare={
            "account_id": str(cloudflare_options.get("account_id", "")),
            "api_token": str(cloudflare_options.get("api_token", "")),
        },
    )
    recipients = normalized_options.get("recipients") or []
    return config, recipients


def _build_recipient_groups(
    client_info: dict[str, Any],
    recipients: list[str],
    recipient_type: str,
    debug: bool,
) -> RecipientGroups:
    """Build TO/CC/BCC recipient groups."""
    to_recipients: list[str] = []
    cc_recipients: list[str] = []
    bcc_recipients: list[str] = []

    client_email = client_info.get("contact_email") if client_info else None
    if client_email:
        to_recipients.append(client_email)
    else:
        logger.warning("No client email found in client settings")

    for email in recipients:
        if not email or email in to_recipients:
            continue
        if recipient_type == "TO":
            to_recipients.append(email)
        elif recipient_type == "CC":
            cc_recipients.append(email)
        elif recipient_type == "BCC":
            bcc_recipients.append(email)
        if debug:
            logger.debug(f"Added {recipient_type} recipient: {email}")

    return RecipientGroups(
        to_recipients=to_recipients,
        cc_recipients=cc_recipients,
        bcc_recipients=bcc_recipients,
    )


def _resolve_subject(config: EmailSendConfig, project_name: str, session_date: str) -> str:
    """Resolve email subject from report metadata and report type."""
    if config.report_type == "day":
        subject_label = "Day Report"
    elif config.report_type == "project":
        subject_label = "Project Report"
    else:
        subject_label = "Session Report"

    subject_suffix = f" - {config.sender_name}" if config.sender_name else ""
    if (
        config.report_type == "project"
        and config.report_meta
        and config.report_meta.get("range_start")
        and config.report_meta.get("range_end")
    ):
        return (
            f"{subject_label}: {project_name} - {config.report_meta['range_start']} to "
            f"{config.report_meta['range_end']}{subject_suffix}"
        )
    return f"{subject_label}: {project_name} - {session_date}{subject_suffix}"


def _resolve_expiration_str(expiration_seconds: int) -> str:
    """Convert expiration seconds to friendly text."""
    if expiration_seconds == ONE_DAY_SECONDS:
        return "1 day"
    if expiration_seconds == THREE_DAYS_SECONDS:
        return "3 days"
    hours = expiration_seconds // 3600
    return f"{hours} hour{'s' if hours != 1 else ''}"


def _resolve_pdf_link(pdf_file: Path, debug: bool) -> tuple[str | None, dict[str, Any]]:
    """Upload PDF and resolve optional S3/custom link."""
    s3_settings = get_s3_settings()
    pdf_url: str | None = None
    if not is_s3_enabled():
        debug_log_entry(
            "S3/R2 is disabled. Email will use direct attachment if configured.",
            "[dim]S3/R2 disabled; using attachment settings.[/dim]",
            debug,
        )
        return pdf_url, s3_settings

    debug_log_entry(
        "S3/R2 is enabled. Initializing S3 helper.",
        "[cyan]S3/R2 enabled; initializing upload helper.[/cyan]",
        debug,
    )
    s3_helper = S3Helper(
        endpoint_url=s3_settings["endpoint_url"],
        access_key_id=s3_settings["access_key_id"],
        secret_access_key=s3_settings["secret_access_key"],
        bucket_name=s3_settings["bucket_name"],
        region=s3_settings["region"],
        upload_workers=s3_settings["upload_workers"],
        debug=debug,
    )
    debug_log_entry(
        f"Uploading report PDF '{pdf_file.name}' to S3/R2.",
        f"[cyan]Uploading report PDF to S3/R2: {pdf_file.name}[/cyan]",
        debug,
    )
    object_name = s3_helper.upload_file(pdf_file)
    if not object_name:
        log_entry(
            "Failed to upload PDF to S3/R2. No URL will be included.",
            "[red]Failed to upload PDF[/red]",
        )
        return None, s3_settings

    log_entry(
        f"Successfully uploaded to S3/R2 as object: {object_name}",
        "[green]Successfully uploaded to S3 bucket[/green]",
    )
    expiration_seconds = s3_settings["url_expiration"]
    if is_s3_custom_link_enabled():
        debug_log_entry(
            "Custom link feature enabled. Generating custom URL.",
            "[cyan]Generating custom report download link.[/cyan]",
            debug,
        )
        custom_success, pdf_url = generate_custom_link(
            s3_helper_instance=s3_helper,
            object_name=object_name,
            expiration=expiration_seconds,
            debug=debug,
        )
        if custom_success and pdf_url:
            log_entry(f"Generated custom link: {pdf_url}", "[green]Generated custom link[/green]")
            return pdf_url, s3_settings
        log_entry(
            "Custom URL generation failed. Falling back to direct S3 presigned URL.",
            "Custom URL generation failed. Falling back to direct S3 presigned URL.",
        )

    pdf_url = s3_helper.generate_presigned_url(object_name, expiration=expiration_seconds)
    if pdf_url:
        log_entry(f"Generated presigned URL: {pdf_url}", "[green]Generated URL[/green]")
    else:
        log_entry(
            "Failed to generate presigned S3 URL. No URL will be included in the email.",
            "[red]Failed to generate URL[/red]",
        )
    return pdf_url, s3_settings


def _append_report_type_text(
    body_parts: list[str],
    html_parts: list[str],
    config: EmailSendConfig,
    project_name: str,
    session_date: str,
) -> None:
    """Append report-type specific copy to plain+HTML body parts."""
    report_meta = config.report_meta or {}
    if config.report_type == "session":
        date_str = report_meta.get("date") or session_date
        start_time = report_meta.get("start_time", "")
        end_time = report_meta.get("end_time", "")
        hours = report_meta.get("hours", 0)
        minutes = report_meta.get("minutes", 0)
        if project_name and start_time and end_time:
            body_parts.append(
                f"Attached is the session report for the "
                f"{project_name} project from {start_time} to "
                f"{end_time} on {date_str}."
            )
            html_parts.append(
                f"<p>Attached is the <strong>session report</strong> "
                f"for the <em>{project_name}</em> "
                f"project from {start_time} to {end_time} on {date_str}.</p>"
            )
        elif project_name:
            body_parts.append(
                f"Attached is the session report for the {project_name} project on {date_str}."
            )
            html_parts.append(
                f"<p>Attached is the <strong>session report</strong> "
                f"for the <em>{project_name}</em> "
                f"project on {date_str}.</p>"
            )
        else:
            body_parts.append(f"Attached is the session report on {date_str}.")
            html_parts.append(
                f"<p>Attached is the <strong>session report</strong> on {date_str}.</p>"
            )
        body_parts.append(
            "\nThis report includes all screenshots taken during this work session, along with any "
            "notes and captions that were added."
        )
        body_parts.append(
            f"\nTotal time tracked: {hours} hour{'s' if hours != 1 else ''} and {minutes} "
            f"minute{'s' if minutes != 1 else ''}."
        )
        html_parts.append(
            "<p>This report includes all screenshots taken during this work session, along with "
            "any notes and captions that were added.</p>"
        )
        html_parts.append(
            f"<p>Total time tracked: {hours} hour{'s' if hours != 1 else ''} and {minutes} "
            f"minute{'s' if minutes != 1 else ''}.</p>"
        )
        _append_goal_counts(body_parts, html_parts, report_meta, include_active=False)
        return

    if config.report_type == "day":
        date_str = report_meta.get("date") or session_date
        session_count = report_meta.get("session_count", 0)
        hours = report_meta.get("hours", 0)
        minutes = report_meta.get("minutes", 0)
        body_parts.append(
            f"Attached is the day report for the {project_name} project on {date_str}."
        )
        body_parts.append(
            f"\nThis summary includes all {session_count} work sessions completed that day, with "
            "their screenshots, notes, and captions."
        )
        body_parts.append(
            f"\nTotal time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} "
            f"minute{'s' if minutes != 1 else ''} across {session_count} sessions."
        )
        html_parts.append(
            f"<p>Attached is the <strong>day report</strong> for the <em>{project_name}</em> "
            f"project on {date_str}.</p>"
        )
        html_parts.append(
            f"<p>This summary includes all {session_count} work sessions completed that day, with "
            "their screenshots, notes, and captions.</p>"
        )
        html_parts.append(
            f"<p>Total time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} "
            f"minute{'s' if minutes != 1 else ''} across {session_count} sessions.</p>"
        )
        _append_goal_counts(body_parts, html_parts, report_meta, include_active=False)
        return

    session_count = report_meta.get("session_count", 0)
    hours = report_meta.get("hours", 0)
    minutes = report_meta.get("minutes", 0)
    range_start = report_meta.get("range_start", "")
    range_end = report_meta.get("range_end", "")
    body_parts.append(
        f"Attached is the project report for the {project_name} "
        f"project from {range_start} to {range_end}."
    )
    body_parts.append(
        f"\nThis summary includes all {session_count} work sessions completed in this period, with "
        "their screenshots, notes, and captions."
    )
    body_parts.append(
        f"\nTotal time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} "
        f"minute{'s' if minutes != 1 else ''} across {session_count} sessions."
    )
    html_parts.append(
        f"<p>Attached is the <strong>project report</strong> for the <em>{project_name}</em> "
        f"project from {range_start} to {range_end}.</p>"
    )
    html_parts.append(
        f"<p>This summary includes all {session_count} work sessions completed in this period, "
        "with their screenshots, notes, and captions.</p>"
    )
    html_parts.append(
        f"<p>Total time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} "
        f"minute{'s' if minutes != 1 else ''} across {session_count} sessions.</p>"
    )
    _append_goal_counts(body_parts, html_parts, report_meta, include_active=True)


def _append_goal_counts(
    body_parts: list[str],
    html_parts: list[str],
    report_meta: dict[str, Any],
    *,
    include_active: bool,
) -> None:
    """Append compact goal counts when report metadata includes them."""
    goals_updated = int(report_meta.get("goals_updated", 0) or 0)
    goals_completed = int(report_meta.get("goals_completed", 0) or 0)
    active_goals = int(report_meta.get("active_goals", 0) or 0)

    parts: list[str] = []
    if include_active and active_goals:
        parts.append(f"{active_goals} active goal{'s' if active_goals != 1 else ''}")
    if goals_updated:
        parts.append(f"{goals_updated} goal update{'s' if goals_updated != 1 else ''}")
    if goals_completed:
        parts.append(f"{goals_completed} completed goal{'s' if goals_completed != 1 else ''}")
    if not parts:
        return

    summary = ", ".join(parts)
    body_parts.append(f"\nProject goals: {summary}.")
    html_parts.append(f"<p>Project goals: {summary}.</p>")


def _append_notes_to_body(
    body_parts: list[str], html_parts: list[str], notes: list[str] | None
) -> None:
    """Append optional notes section to plain and HTML parts."""
    if not notes:
        return

    body_parts.append("")
    body_parts.append("Notes:")
    html_parts.append("<p><strong>Notes:</strong></p>")
    in_list = False
    for raw in notes:
        line = (raw or "").strip()
        if not line:
            continue
        body_parts.append(line)
        if line.startswith("- "):
            if not in_list:
                html_parts.append("<ul>")
                in_list = True
            html_parts.append(f"<li>{line[2:].strip()}</li>")
        else:
            if in_list:
                html_parts.append("</ul>")
                in_list = False
            html_parts.append("<p>" + line.replace("\n", "<br>") + "</p>")
    if in_list:
        html_parts.append("</ul>")


def _build_email_bodies(context: EmailBodyContext) -> tuple[str, str]:
    """Build plain text and HTML email bodies."""
    config = context.config
    client_info = context.client_info
    project_name = context.project_name
    session_date = context.session_date
    pdf_url = context.pdf_url
    s3_settings = context.s3_settings

    body_parts: list[str] = []
    html_parts: list[str] = []
    client_name_display = client_info.get("contact_name", "") if client_info else ""
    if client_name_display:
        body_parts.append(f"Hello {client_name_display},")
        body_parts.append("")
        html_parts.append(f"<p>Hello {client_name_display},</p>")

    _append_report_type_text(body_parts, html_parts, config, project_name, session_date)

    if pdf_url:
        expiration_str = _resolve_expiration_str(s3_settings["url_expiration"])
        body_parts.append(
            f"\nYou can download the report PDF here (link expires in {expiration_str}): {pdf_url}"
        )
        html_parts.append(
            f"<p>You can download the report PDF here (link expires in {expiration_str}): "
            f'<a href="{pdf_url}">{pdf_url}</a></p>'
        )
    elif is_s3_enabled() and not s3_settings["send_attachment"]:
        body_parts.append("\n(There was an error generating the download link for the report.)")
        html_parts.append(
            "<p>(There was an error generating the download link for the report.)</p>"
        )

    if client_info and client_info.get("pdf_password"):
        body_parts.append("\nThe attached PDF report is password protected.")
        body_parts.append("You will need the password to open the document.")
        html_parts.append(
            "<p>The attached PDF report is password protected.<br>You will need the "
            "password to open the document.</p>"
        )

    _append_notes_to_body(body_parts, html_parts, config.extra_body_lines)

    if config.sender_name:
        body_parts.append("")
        body_parts.append("Kind regards,")
        body_parts.append(config.sender_name)
        html_parts.append(f"<p>Kind regards,<br>{config.sender_name}</p>")

    return "\n".join(body_parts), "\n".join(html_parts)


def _attach_pdf_if_needed(msg: MIMEMultipart, pdf_file: Path, s3_settings: dict[str, Any]) -> None:
    """Attach PDF when direct attachment is enabled."""
    if is_s3_enabled() and not s3_settings["send_attachment"]:
        return
    with open(pdf_file, "rb") as f:
        attachment = MIMEApplication(f.read(), _subtype="pdf")
        attachment.add_header("Content-Disposition", "attachment", filename=pdf_file.name)
        msg.attach(attachment)


def _attach_pdfs_if_needed(
    msg: MIMEMultipart,
    pdf_files: list[Path],
    s3_settings: dict[str, Any],
) -> None:
    """Attach multiple PDFs when direct attachment is enabled."""
    if is_s3_enabled() and not s3_settings["send_attachment"]:
        return
    for pdf_file in pdf_files:
        with open(pdf_file, "rb") as f:
            attachment = MIMEApplication(f.read(), _subtype="pdf")
            attachment.add_header("Content-Disposition", "attachment", filename=pdf_file.name)
            msg.attach(attachment)


def _build_cloudflare_attachments(
    pdf_files: list[Path],
    s3_settings: dict[str, Any],
) -> list[dict[str, str]]:
    """Build Cloudflare attachment payloads when direct attachment is enabled."""
    if is_s3_enabled() and not s3_settings["send_attachment"]:
        return []

    attachments: list[dict[str, str]] = []
    for pdf_file in pdf_files:
        encoded_content = base64.b64encode(pdf_file.read_bytes()).decode("ascii")
        attachments.append(
            {
                "filename": pdf_file.name,
                "content": encoded_content,
                "type": "application/pdf",
                "disposition": "attachment",
            }
        )
    return attachments


def _send_smtp_message(
    msg: MIMEMultipart, config: EmailSendConfig, recipient_list: list[str]
) -> None:
    """Send MIME message through SMTP with configured security."""
    smtp_config = config.smtp
    connection_security = str(smtp_config.get("connection_security", "TLS"))
    debug_log_entry(
        (
            "Sending report email via SMTP "
            f"server={smtp_config.get('server', '')}, security={connection_security}, "
            f"recipients={len(recipient_list)}."
        ),
        (f"[cyan]Sending report email via SMTP ({len(recipient_list)} recipient(s)).[/cyan]"),
        config.debug,
    )
    if connection_security == "SSL":
        server = smtplib.SMTP_SSL(
            str(smtp_config.get("server", "")),
            int(smtp_config.get("port", 587)),
            timeout=SMTP_TIMEOUT_SECONDS,
        )
    else:
        server = smtplib.SMTP(
            str(smtp_config.get("server", "")),
            int(smtp_config.get("port", 587)),
            timeout=SMTP_TIMEOUT_SECONDS,
        )
        if connection_security == "TLS":
            server.ehlo()
            server.starttls()
            server.ehlo()

    server.login(
        str(smtp_config.get("username") or config.sender_email),
        str(smtp_config.get("password", "")),
    )
    server.send_message(msg, to_addrs=recipient_list)
    server.quit()
    debug_log_entry(
        "SMTP report email send completed.",
        "[green]SMTP report email send completed.[/green]",
        config.debug,
    )


def _build_cloudflare_address(address: str, name: str | None = None) -> str | dict[str, str]:
    """Build Cloudflare address payload for sender or recipients."""
    if name:
        return {
            "address": address,
            "name": name,
        }
    return address


def _extract_cloudflare_errors(response_data: dict[str, Any]) -> str:
    """Extract Cloudflare API errors into a readable string."""
    errors = response_data.get("errors")
    if not isinstance(errors, list) or not errors:
        return "Unknown Cloudflare API error"
    messages: list[str] = []
    for error in errors:
        if not isinstance(error, dict):
            continue
        message = error.get("message") or error.get("code")
        if message:
            messages.append(str(message))
    return "; ".join(messages) or "Unknown Cloudflare API error"


def _cloudflare_has_errors(response_data: dict[str, Any]) -> bool:
    """Return whether the Cloudflare API response contains any errors."""
    errors = response_data.get("errors")
    return isinstance(errors, list) and len(errors) > 0


def _validate_transport_config(config: EmailSendConfig) -> str | None:
    """Validate transport-specific configuration and return an error if incomplete."""
    if config.provider == "cloudflare":
        if not config.sender_email:
            return "Cloudflare email settings incomplete (sender email)."
        if not config.cloudflare.get("account_id") or not config.cloudflare.get("api_token"):
            return "Cloudflare email settings incomplete (account ID / API token)."
        return None

    if not config.sender_email:
        return "SMTP email settings incomplete (sender email)."
    if not config.smtp.get("server") or not config.smtp.get("password"):
        return "SMTP email settings incomplete (server / password)."
    return None


def _send_cloudflare_message(config: EmailSendConfig, context: CloudflareMessageContext) -> None:
    """Send email through Cloudflare Email Sending builder API."""
    cloudflare_config = config.cloudflare
    account_id = str(cloudflare_config.get("account_id", ""))
    api_token = str(cloudflare_config.get("api_token", ""))
    endpoint = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/email/sending/send"

    payload: dict[str, Any] = {
        "from": _build_cloudflare_address(config.sender_email, config.sender_name),
        "subject": context.subject,
        "text": context.body_text,
        "html": context.body_html,
        "to": context.recipient_groups.to_recipients,
    }
    if context.recipient_groups.cc_recipients:
        payload["cc"] = context.recipient_groups.cc_recipients
    if context.recipient_groups.bcc_recipients:
        payload["bcc"] = context.recipient_groups.bcc_recipients

    attachments = _build_cloudflare_attachments(context.pdf_files, context.s3_settings)
    if attachments:
        payload["attachments"] = attachments

    debug_log_entry(
        (
            "Sending report email via Cloudflare Email Sending "
            f"recipients={len(context.recipient_groups.all_recipients())}, "
            f"attachments={len(attachments)}."
        ),
        (
            "[cyan]Sending report email via Cloudflare "
            f"({len(context.recipient_groups.all_recipients())} recipient(s)).[/cyan]"
        ),
        config.debug,
    )
    response = requests.post(
        endpoint,
        headers={
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=10,
    )
    debug_log_entry(
        f"Cloudflare Email Sending response status: {response.status_code}.",
        f"[cyan]Cloudflare email response: {response.status_code}[/cyan]",
        config.debug,
    )
    debug_log_entry(
        f"Cloudflare Email Sending response body: {response.text}",
        None,
        config.debug,
    )
    response.raise_for_status()

    response_data = response.json()
    if not response_data.get("success") or _cloudflare_has_errors(response_data):
        raise ValueError(_extract_cloudflare_errors(response_data))
    debug_log_entry(
        "Cloudflare report email send completed.",
        "[green]Cloudflare report email send completed.[/green]",
        config.debug,
    )


def _extract_alternative_bodies(msg: MIMEMultipart) -> tuple[str, str]:
    """Extract plain-text and HTML bodies from a multipart/alternative payload."""
    parts = msg.get_payload()[0].get_payload()
    plain_text = _decode_mime_part_text(parts[0]) if parts else ""
    html_text = _decode_mime_part_text(parts[1]) if len(parts) > 1 else ""
    return plain_text, html_text


def _decode_mime_part_text(part: MIMEText) -> str:
    """Decode a MIME part payload into text using the part charset."""
    payload = part.get_payload(decode=True)
    if payload is None:
        raw_payload = part.get_payload()
        if isinstance(raw_payload, str):
            return raw_payload
        if isinstance(raw_payload, bytes):
            payload = raw_payload
        else:
            return ""

    if isinstance(payload, bytes):
        charset = part.get_content_charset() or "utf-8"
        try:
            return payload.decode(charset, errors="replace")
        except LookupError:
            return payload.decode("utf-8", errors="replace")

    return str(payload)


def _log_success(
    recipient_list: list[str], pdf_file: Path, pdf_url: str | None, s3_settings: dict[str, Any]
) -> None:
    """Log successful send details to file and terminal."""
    recipient_count = len(recipient_list)
    recipient_str = ", ".join(recipient_list)
    log_entry(
        f"Email sent successfully to {recipient_count} recipient(s): {recipient_str}",
        f"[green]Email sent successfully to {recipient_count} recipient(s)[/green]",
    )
    if not is_s3_enabled() or s3_settings["send_attachment"]:
        log_entry(
            f"PDF file '{pdf_file.name}' was attached to the email",
            "[blue]PDF file was attached to the email[/blue]",
        )
        return
    if pdf_url:
        log_entry(
            f"Email included link to download the PDF: {pdf_url}",
            "[blue]Email included link to download the PDF[/blue]",
        )


def _append_batch_project_section(
    body_parts: list[str],
    html_parts: list[str],
    report: BatchEmailProjectReport,
    s3_settings: dict[str, Any],
) -> None:
    """Append one project's stats and notes in batch-email body."""
    report_meta = report.report_meta or {}
    session_count = int(report_meta.get("session_count", 0))
    hours = int(report_meta.get("hours", 0))
    minutes = int(report_meta.get("minutes", 0))
    range_start = str(report_meta.get("range_start", ""))
    range_end = str(report_meta.get("range_end", ""))
    date_str = str(report_meta.get("date", "")) or report.session_date

    body_parts.append("")
    body_parts.append(f"{report.project_name}:")
    html_parts.append(f"<h4>{report.project_name}</h4>")

    if report.report_type == "day":
        body_parts.append(f"- Report type: Day ({date_str})")
        body_parts.append(f"- Sessions: {session_count}")
        body_parts.append(f"- Total time: {hours}h {minutes}m")
        html_parts.append(f"<p><strong>Report type:</strong> Day ({date_str})</p>")
        html_parts.append(f"<p><strong>Sessions:</strong> {session_count}</p>")
        html_parts.append(f"<p><strong>Total time:</strong> {hours}h {minutes}m</p>")
    elif report.report_type == "project":
        body_parts.append(f"- Report type: Project ({range_start} to {range_end})")
        body_parts.append(f"- Sessions: {session_count}")
        body_parts.append(f"- Total time: {hours}h {minutes}m")
        html_parts.append(
            f"<p><strong>Report type:</strong> Project ({range_start} to {range_end})</p>"
        )
        html_parts.append(f"<p><strong>Sessions:</strong> {session_count}</p>")
        html_parts.append(f"<p><strong>Total time:</strong> {hours}h {minutes}m</p>")
    else:
        body_parts.append(f"- Report type: {report.report_type.title()} ({date_str})")
        html_parts.append(
            f"<p><strong>Report type:</strong> {report.report_type.title()} ({date_str})</p>"
        )

    goal_body_parts: list[str] = []
    goal_html_parts: list[str] = []
    _append_goal_counts(
        goal_body_parts,
        goal_html_parts,
        report_meta,
        include_active=report.report_type == "project",
    )
    body_parts.extend(part.strip() for part in goal_body_parts if part.strip())
    html_parts.extend(goal_html_parts)

    if report.notes_lines:
        _append_notes_to_body(body_parts, html_parts, report.notes_lines)

    if is_s3_enabled() and not s3_settings["send_attachment"]:
        expiration_str = _resolve_expiration_str(s3_settings["url_expiration"])
        if report.pdf_url:
            body_parts.append(f"- Download link (expires in {expiration_str}): {report.pdf_url}")
            html_parts.append(
                "<p><strong>Download link</strong> "
                f"(expires in {expiration_str}): "
                f'<a href="{report.pdf_url}">{report.pdf_url}</a></p>'
            )
        else:
            body_parts.append("- Download link: unavailable")
            html_parts.append("<p><strong>Download link:</strong> unavailable</p>")


def _build_batch_email_message(
    config: EmailSendConfig,
    recipient_groups: RecipientGroups,
    client_info: dict[str, Any],
    reports: list[BatchEmailProjectReport],
    s3_settings: dict[str, Any],
) -> MIMEMultipart:
    """Build MIME message for batch email, including body content."""
    msg = MIMEMultipart()
    msg["From"] = (
        f"{config.sender_name} <{config.sender_email}>"
        if config.sender_name
        else config.sender_email
    )
    if recipient_groups.to_recipients:
        msg["To"] = ", ".join(recipient_groups.to_recipients)
    if recipient_groups.cc_recipients:
        msg["Cc"] = ", ".join(recipient_groups.cc_recipients)

    client_label = str(client_info.get("contact_name") or "Client")
    msg["Subject"] = f"Batch Reports: {client_label} ({len(reports)} projects)"

    body_parts: list[str] = []
    html_parts: list[str] = []
    if client_label:
        body_parts.append(f"Hello {client_label},")
        body_parts.append("")
        html_parts.append(f"<p>Hello {client_label},</p>")
    if is_s3_enabled() and not s3_settings["send_attachment"]:
        body_parts.append(
            f"Attached are the following {len(reports)} project reports. "
            "Follow the links below to download the PDFs."
        )
        html_parts.append(
            f"<p>Attached are the following <strong>{len(reports)} project reports</strong>. "
            "Follow the links below to download the PDFs.</p>"
        )
    else:
        body_parts.append(
            f"Attached are {len(reports)} project reports generated in a single batch run."
        )
        html_parts.append(
            f"<p>Attached are <strong>{len(reports)} project reports</strong> generated in a "
            "single batch run.</p>"
        )
    for report in reports:
        _append_batch_project_section(body_parts, html_parts, report, s3_settings)

    if config.sender_name:
        body_parts.append("")
        body_parts.append("Kind regards,")
        body_parts.append(config.sender_name)
        html_parts.append(f"<p>Kind regards,<br>{config.sender_name}</p>")

    alternative = MIMEMultipart("alternative")
    alternative.attach(MIMEText("\n".join(body_parts), "plain"))
    alternative.attach(MIMEText("\n".join(html_parts), "html"))
    msg.attach(alternative)
    return msg


def _resolve_batch_report_links(
    reports: list[BatchEmailProjectReport],
    debug: bool,
    s3_settings: dict[str, Any],
) -> tuple[list[BatchEmailProjectReport] | None, list[str]]:
    """Resolve S3 links for each batch report when attachments are disabled."""
    if not (is_s3_enabled() and not s3_settings["send_attachment"]):
        return reports, []

    resolved_reports: list[BatchEmailProjectReport] = []
    failed_projects: list[str] = []
    for report in reports:
        pdf_url, _ = _resolve_pdf_link(report.pdf_file, debug)
        if not pdf_url:
            failed_projects.append(report.project_name)
            continue
        resolved_reports.append(
            BatchEmailProjectReport(
                pdf_file=report.pdf_file,
                project_name=report.project_name,
                report_type=report.report_type,
                session_date=report.session_date,
                report_meta=report.report_meta,
                notes_lines=report.notes_lines,
                pdf_url=pdf_url,
            )
        )
    if failed_projects:
        return None, failed_projects
    return resolved_reports, []


def send_batch_email(
    client_info: dict[str, Any],
    reports: list[BatchEmailProjectReport],
    **email_options: Any,
) -> bool:
    """Send a single email containing multiple project report PDFs."""
    missing_files = [report.pdf_file for report in reports if not report.pdf_file.exists()]
    if not reports or missing_files:
        message = "No reports supplied for batch email"
        terminal_message = "[red]No reports to email[/red]"
        if missing_files:
            message = "One or more batch PDF files are missing"
            terminal_message = "[red]One or more batch PDF files are missing[/red]"
        log_entry(
            message,
            terminal_message,
        )
        return False

    config, recipients = _resolve_send_config(email_options)
    _set_debug_terminal_output(config.debug)
    set_s3_debug_terminal_output(config.debug)
    if config.debug:
        logger.setLevel(logging.DEBUG)
    project_path = reports[0].pdf_file.parent.parent
    setup_report_logging(project_path)
    s3_settings = get_s3_settings()
    transport_error = _validate_transport_config(config)
    if transport_error:
        log_entry(transport_error, f"[red]{transport_error}[/red]", level="error")
        return False

    recipient_groups = _build_recipient_groups(
        client_info,
        recipients,
        config.recipient_type,
        config.debug,
    )
    recipient_list = recipient_groups.all_recipients()
    if not recipient_list:
        logger.error("No recipient email addresses available")
        return False

    try:
        resolved_reports, failed_projects = _resolve_batch_report_links(
            reports=reports,
            debug=config.debug,
            s3_settings=s3_settings,
        )
        if resolved_reports is None:
            failed_list = ", ".join(failed_projects)
            log_entry(
                f"Failed to generate S3 links for projects: {failed_list}",
                "[red]Failed to generate one or more S3 links for batch email.[/red]",
                level="error",
            )
            return False

        msg = _build_batch_email_message(
            config=config,
            recipient_groups=recipient_groups,
            client_info=client_info,
            reports=resolved_reports,
            s3_settings=s3_settings,
        )
        pdf_files = [report.pdf_file for report in resolved_reports]
        if config.provider == "cloudflare":
            plain_text, html_text = _extract_alternative_bodies(msg)
            _send_cloudflare_message(
                config,
                CloudflareMessageContext(
                    subject=str(msg["Subject"]),
                    body_text=plain_text,
                    body_html=html_text,
                    recipient_groups=recipient_groups,
                    s3_settings=s3_settings,
                    pdf_files=pdf_files,
                ),
            )
        else:
            _attach_pdfs_if_needed(msg, pdf_files, s3_settings)
            _send_smtp_message(msg, config, recipient_list)
        log_entry(
            f"Batch email sent successfully with {len(resolved_reports)} reports.",
            f"[green]Batch email sent successfully ({len(resolved_reports)} reports)[/green]",
        )
        return True
    except Exception as e:
        error_msg = f"Error sending batch email: {e}"
        log_entry(error_msg, f"[red]Failed to send batch email: {e}[/red]", level="error")
        if config.debug:
            log_entry(f"Batch email error details: {traceback.format_exc()}", level="debug")
        return False


def send_email(
    pdf_file: Path,
    client_info: dict[str, Any],
    project_name: str,
    session_date: str,
    **email_options: Any,
) -> bool:
    """Send the PDF report as an email attachment or link.

    Args:
        pdf_file: Path to the PDF file to send.
        client_info: Client information dictionary.
        project_name: Name of the project.
        session_date: Session date string.
        **email_options: Provider-aware email options. Supports both the nested
            `provider` / `smtp` / `cloudflare` shape and the legacy flat SMTP keys
            (`smtp_server`, `smtp_port`, `connection_security`, `username`, `password`),
            plus sender/recipient/report metadata values shared by both providers.

    Returns:
        True if email was sent successfully, False otherwise.
    """
    if not pdf_file or not pdf_file.exists():
        log_entry("No PDF file to send", "[red]No PDF file to send[/red]")
        return False

    config, recipients = _resolve_send_config(email_options)
    _set_debug_terminal_output(config.debug)
    set_s3_debug_terminal_output(config.debug)
    if config.debug:
        logger.setLevel(logging.DEBUG)
    project_path = pdf_file.parent.parent
    setup_report_logging(project_path)
    transport_error = _validate_transport_config(config)
    if transport_error:
        log_entry(transport_error, f"[red]{transport_error}[/red]", level="error")
        return False

    recipient_groups = _build_recipient_groups(
        client_info,
        recipients,
        config.recipient_type,
        config.debug,
    )
    recipient_list = recipient_groups.all_recipients()
    if not recipient_list:
        logger.error("No recipient email addresses available")
        return False

    try:
        msg = MIMEMultipart()
        msg["From"] = (
            f"{config.sender_name} <{config.sender_email}>"
            if config.sender_name
            else config.sender_email
        )
        if recipient_groups.to_recipients:
            msg["To"] = ", ".join(recipient_groups.to_recipients)
        if recipient_groups.cc_recipients:
            msg["Cc"] = ", ".join(recipient_groups.cc_recipients)
        msg["Subject"] = _resolve_subject(config, project_name, session_date)

        pdf_url, s3_settings = _resolve_pdf_link(pdf_file, config.debug)
        if is_s3_enabled() and not s3_settings["send_attachment"] and not pdf_url:
            log_entry(
                "S3 upload/link generation failed. Email will not be sent.",
                "[red]S3 upload/link failed. Email will not be sent.[/red]",
                level="error",
            )
            return False

        body_text, body_html = _build_email_bodies(
            EmailBodyContext(
                config=config,
                client_info=client_info,
                project_name=project_name,
                session_date=session_date,
                pdf_url=pdf_url,
                s3_settings=s3_settings,
            )
        )

        alternative = MIMEMultipart("alternative")
        alternative.attach(MIMEText(body_text, "plain"))
        alternative.attach(MIMEText(body_html, "html"))
        msg.attach(alternative)

        if config.provider == "cloudflare":
            _send_cloudflare_message(
                config,
                CloudflareMessageContext(
                    subject=str(msg["Subject"]),
                    body_text=body_text,
                    body_html=body_html,
                    recipient_groups=recipient_groups,
                    s3_settings=s3_settings,
                    pdf_files=[pdf_file],
                ),
            )
        else:
            _attach_pdf_if_needed(msg, pdf_file, s3_settings)
            _send_smtp_message(msg, config, recipient_list)
        _log_success(recipient_list, pdf_file, pdf_url, s3_settings)
        return True

    except Exception as e:
        error_msg = f"Error sending email: {e}"
        log_entry(error_msg, f"[red]Failed to send email: {e}[/red]", level="error")
        if config.debug:
            log_entry(f"Email error details: {traceback.format_exc()}", level="debug")
        return False
