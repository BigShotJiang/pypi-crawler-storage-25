#!/usr/bin/env python3
"""PDF generation methods for the ReportGenerator class."""

import logging
import traceback
from dataclasses import dataclass
from datetime import datetime
from functools import partial
from pathlib import Path

from reportlab.lib.units import inch
from reportlab.platypus import KeepTogether, PageBreak, Paragraph, Spacer

from screenshooter.modules.reports.pdf.components import (
    add_report_title,
    add_section_header,
    add_subsection_header,
)
from screenshooter.modules.reports.pdf.helper import (
    ImageOptimizationOptions,
    ReportPageCanvas,
    ScreenshotRenderContext,
    add_screenshot,
    create_pdf_document,
    get_pdf_styles,
)
from screenshooter.modules.reports.pdf.tables import (
    SessionSummaryData,
    add_client_info_table,
    add_event_table,
    add_goal_update_event_table,
    add_goals_summary_table,
    add_report_summary_table,
    add_session_summary_table,
)
from screenshooter.modules.reports.pdf.utils import handle_image_relocations

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pdf_generation")


@dataclass
class EventRenderContext:
    """Context for rendering chronological session events."""

    story: list
    session_log: object
    screenshots_dir: Path
    report_generator: object
    styles: dict
    relocation_log: list
    page_break_between_sets: bool


def _resolve_pdf_password(report_generator) -> str | None:
    """Resolve optional PDF password from client preferences."""
    if (
        report_generator.client_info
        and report_generator.client_info.preferences.get("pdf_security") == "password"
        and report_generator.client_info.pdf_password
    ):
        report_generator.log_entry(
            "Applying password protection to PDF", level="info", suppress_logger=True
        )
        return report_generator.client_info.pdf_password
    return None


def _compute_note_count(session_log) -> int:
    """Compute total note count including captions and session note."""
    note_count = len(session_log.notes)
    note_count += len(getattr(session_log, "captions", {}))
    note_count += len(getattr(session_log, "set_captions", {}))
    if session_log.session_note:
        note_count += 1
    note_count += sum(
        1
        for event in getattr(session_log, "chronological_events", [])
        if event.get("type") == "caption"
    )
    return note_count


def _compute_goal_count(session_log) -> int:
    """Compute number of goal updates in a session log."""
    goal_events = getattr(session_log, "goal_events", []) or []
    return sum(_count_goal_event_updates(goal_event) for goal_event in goal_events)


def _goal_event_value(goal_event, key: str):
    """Read a goal event value from either a dict or object."""
    if isinstance(goal_event, dict):
        return goal_event.get(key)
    return getattr(goal_event, key, None)


def _count_goal_event_updates(goal_event) -> int:
    """Count concrete updates represented by a grouped goal event."""
    update_count = 0
    for collection_key in ("events", "updates", "entries", "notes"):
        collection = _goal_event_value(goal_event, collection_key)
        if collection:
            update_count += len(collection)
            break
    if _goal_event_value(goal_event, "created_in_scope"):
        update_count += 1
    if _goal_event_value(goal_event, "closed_in_scope"):
        update_count += 1
    return update_count or 1


def _collect_screenshot_indices(session_log) -> list[int]:
    """Collect chronological-event indexes for screenshot events."""
    return [
        index
        for index, event in enumerate(session_log.chronological_events)
        if event["type"] == "screenshot"
    ]


def _is_last_screenshot_in_set(
    event_index: int,
    set_id,
    session_log,
    screenshot_indices: list[int],
) -> bool:
    """Return True when the screenshot event is the last in its set."""
    if event_index not in screenshot_indices:
        return False

    next_screenshot_idx = None
    for idx in screenshot_indices:
        if idx > event_index:
            next_screenshot_idx = idx
            break
    if next_screenshot_idx is None:
        return True
    return session_log.chronological_events[next_screenshot_idx]["set_id"] != set_id


def _append_set_caption_if_present(story, session_log, current_set, styles) -> None:
    """Append set caption directly under a completed set when available."""
    set_captions = getattr(session_log, "set_captions", {})
    if not set_captions or not current_set:
        return

    try:
        set_id_int = int(current_set)
    except Exception:
        return
    if set_id_int not in set_captions:
        return

    timestamp, set_caption = set_captions[set_id_int]
    add_event_table(
        story,
        event_type="Caption",
        timestamp=timestamp,
        content=set_caption,
        styles=styles,
    )


def _build_image_options(report_generator) -> ImageOptimizationOptions:
    """Build image optimization options from report generator settings."""
    return ImageOptimizationOptions(
        image_quality=report_generator.image_quality,
        image_format=report_generator.image_format,
        max_dimension=report_generator.max_dimension,
        use_thumbnails=report_generator.use_thumbnails,
        thumbnail_size=report_generator.thumbnail_size,
        debug=report_generator.image_search_debug
        if hasattr(report_generator, "image_search_debug")
        else report_generator.debug,
    )


def _aggregate_day_goal_events(multi_sessions) -> list[dict]:
    """Merge goal_events across all sessions for a day-level goals summary table."""
    goals_by_id: dict[int, dict] = {}
    for session_log in multi_sessions.session_logs.values():
        for goal_event in getattr(session_log, "goal_events", []) or []:
            goal_id = goal_event.get("id")
            if goal_id is None:
                continue
            if goal_id not in goals_by_id:
                goals_by_id[goal_id] = {k: v for k, v in goal_event.items() if k != "notes"}
                goals_by_id[goal_id]["notes"] = []
            goals_by_id[goal_id]["notes"].extend(goal_event.get("notes", []))
    return list(goals_by_id.values())


def _render_goals_summary_table(story: list, goals: list[dict], styles: dict) -> None:
    """Render the project goals summary table (Goal | Status | Latest Note)."""
    if not goals:
        return
    add_section_header(story, "Project Goals", styles)
    add_goals_summary_table(story=story, goals=goals, styles=styles)
    story.append(PageBreak())


def _session_header_from_start(session_log) -> str:
    """Build a session header label from the session start timestamp."""
    session_start = session_log.session_start or ""
    if " " in session_start:
        return f"Session: {session_start.split(' ', 1)[1]}"
    if session_start:
        return f"Session: {session_start}"
    return "Session"


def _render_session_start_note(story: list, session_log, styles: dict) -> None:
    """Render the session-start note as a normal note event."""
    if not session_log.session_note:
        return
    add_event_table(
        story,
        event_type="Note",
        timestamp=session_log.session_start or "",
        content=session_log.session_note,
        styles=styles,
    )


def _render_chronological_events(context: EventRenderContext) -> None:
    """Render chronological session events (screenshots, notes, captions)."""
    story = context.story
    session_log = context.session_log
    screenshots_dir = context.screenshots_dir
    report_generator = context.report_generator
    styles = context.styles
    relocation_log = context.relocation_log
    page_break_between_sets = context.page_break_between_sets

    current_set = None
    screenshot_count = 0
    screenshot_indices = _collect_screenshot_indices(session_log)
    image_options = _build_image_options(report_generator)

    for idx, event in enumerate(session_log.chronological_events):
        if event["type"] == "screenshot":
            screenshot_count += 1
            set_id = event["set_id"]
            screenshot_block = []

            if set_id != current_set:
                if current_set is not None:
                    if page_break_between_sets:
                        story.append(PageBreak())
                    else:
                        story.append(Spacer(1, 0.3 * inch))
                current_set = set_id
                if set_id:
                    screenshot_block.append(Paragraph(f"Set #{set_id}", styles["Heading3Bold"]))
                    screenshot_block.append(Spacer(1, 0.1 * inch))

            screenshot_data = session_log.screenshots[event["index"]]
            add_screenshot(
                target_story=screenshot_block,
                screenshot_data=screenshot_data,
                screenshot_num=screenshot_count,
                context=ScreenshotRenderContext(
                    screenshots_dir=screenshots_dir,
                    captions=session_log.captions,
                    options=image_options,
                    styles=styles,
                    temp_files=report_generator.temp_files,
                    client_base_dir=report_generator.client_dir,
                    report_relocations=True,
                    relocation_log=relocation_log,
                    project_dir=report_generator.project_dir,
                ),
            )
            story.append(KeepTogether(screenshot_block))

            if _is_last_screenshot_in_set(idx, set_id, session_log, screenshot_indices):
                _append_set_caption_if_present(story, session_log, current_set, styles)
            continue

        if event["type"] == "note":
            add_event_table(
                story,
                event_type="Note",
                timestamp=event["timestamp"],
                content=event["content"],
                styles=styles,
            )
            continue

        if event["type"] == "goal_update":
            goal_title = event.get("goal_title", "")
            add_goal_update_event_table(
                story,
                goal_title=goal_title,
                timestamp=event["timestamp"],
                content=event["content"],
                styles=styles,
            )
            continue

        if event["type"] == "caption":
            add_event_table(
                story,
                event_type="Caption",
                timestamp=event["timestamp"],
                content=event["content"],
                styles=styles,
            )


def _build_pdf_with_logging(report_generator, doc, story) -> Path:
    """Build PDF and log success or error details."""
    try:
        canvas_maker = partial(
            ReportPageCanvas,
            header_text=getattr(doc, "screenshooter_header_text", "ScreenShooter Report"),
        )
        doc.build(story, canvasmaker=canvas_maker)
        report_generator.log_entry(
            f"PDF report generated successfully: {report_generator.pdf_file}",
            terminal_message="",
        )
        return report_generator.pdf_file
    except Exception as e:
        error_msg = f"Error building PDF: {e}"
        report_generator.log_entry(error_msg, level="error")
        if report_generator.debug:
            report_generator.log_entry(f"Stack trace: {traceback.format_exc()}", level="debug")
        raise


def generate_single_session_pdf(report_generator) -> Path:
    """Generate PDF report for a single session.

    Args:
        report_generator: The ReportGenerator instance

    Returns:
        Path to the generated PDF
    """
    if not report_generator.session_log:
        error_msg = "No session data loaded"
        report_generator.log_entry(error_msg, level="error")
        raise ValueError(error_msg)

    relocation_log = []
    project_name = (
        report_generator.project_name or report_generator.screenshots_dir.parent.parent.name
    )
    session_date = report_generator.session_date or report_generator.screenshots_dir.parent.name
    report_title = f"{project_name} - {session_date}"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_filename = f"{project_name}_Session_Report_{timestamp}.pdf"
    report_generator.pdf_file = report_generator.output_dir / pdf_filename
    report_generator.log_entry(f"Creating PDF at: {report_generator.pdf_file}", level="debug")

    pdf_password = _resolve_pdf_password(report_generator)
    doc = create_pdf_document(
        output_path=report_generator.pdf_file,
        page_size=report_generator.page_size,
        compress_pdf=report_generator.compress_pdf,
        pdf_password=pdf_password,
        header_text=report_title,
    )
    styles = get_pdf_styles()
    story = []

    add_report_title(story, "Screenshot Session Report", styles)
    add_section_header(story, report_title, styles)
    if report_generator.client_info:
        add_client_info_table(
            story=story, client_info=report_generator.client_info.dict(), styles=styles
        )

    add_section_header(story, "Session Summary", styles)
    if report_generator.session_log.session_start and report_generator.session_log.session_end:
        note_count = _compute_note_count(report_generator.session_log)
        add_session_summary_table(
            story=story,
            summary=SessionSummaryData(
                session_start=report_generator.session_log.session_start,
                session_end=report_generator.session_log.session_end,
                session_duration=report_generator.session_log.session_duration,
                screenshot_count=len(report_generator.session_log.screenshots),
                note_count=note_count,
                goal_count=_compute_goal_count(report_generator.session_log),
            ),
            styles=styles,
        )

    _render_goals_summary_table(
        story,
        getattr(report_generator.session_log, "goal_events", []) or [],
        styles,
    )

    add_subsection_header(story, _session_header_from_start(report_generator.session_log), styles)

    _render_session_start_note(story, report_generator.session_log, styles)

    _render_chronological_events(
        EventRenderContext(
            story=story,
            session_log=report_generator.session_log,
            screenshots_dir=report_generator.screenshots_dir,
            report_generator=report_generator,
            styles=styles,
            relocation_log=relocation_log,
            page_break_between_sets=True,
        )
    )

    if relocation_log:
        changes_saved = handle_image_relocations(report_generator, relocation_log)
        report_generator.log_entry(
            f"Processed {len(relocation_log)} image relocations (changes: {changes_saved})",
            level="debug",
        )
    return _build_pdf_with_logging(report_generator, doc, story)


def _resolve_multi_report_metadata(report_generator) -> tuple[str, str]:
    """Resolve multi-session report title and type string."""
    project_name = report_generator.project_name
    if report_generator.report_type == "day":
        date_str = report_generator.specific_date or datetime.now().strftime("%Y-%m-%d")
        return f"{project_name} - Day Report ({date_str})", "Day"
    return f"{project_name} - Project Report", "Project"


def _add_multi_summary_table(story: list, stats: dict, styles: dict, report_type: str) -> None:
    """Add report summary table for multi-session reports."""
    summary_data = [
        ["Total Sessions", str(stats["total_sessions"])],
        ["Total Screenshots", str(stats["total_screenshots"])],
        ["Total Notes", str(stats["total_notes"])],
        ["Total Duration", stats["formatted_total_duration"]],
    ]
    if report_type == "project":
        summary_data.insert(1, ["Days Covered", str(stats["days_covered"])])
    if stats["earliest_session_str"]:
        summary_data.append(["First Session", stats["earliest_session_str"]])
    if stats["latest_session_str"]:
        summary_data.append(["Last Session", stats["latest_session_str"]])

    add_report_summary_table(story, summary_data, styles)


def _resolve_session_screenshots_dir(report_generator, session_dir) -> Path:
    """Resolve screenshots directory for session source type."""
    if str(session_dir).startswith("/mock_sessions/"):
        return report_generator.screenshots_dir
    return session_dir / "screenshots"


def _append_page_break_if_needed(story: list) -> None:
    """Append a page break unless the story already ends with one."""
    if story and not isinstance(story[-1], PageBreak):
        story.append(PageBreak())


def generate_multi_session_pdf(report_generator) -> Path:
    """Generate PDF report for multiple sessions (day or project).

    Args:
        report_generator: The ReportGenerator instance

    Returns:
        Path to the generated PDF
    """
    relocation_log = []
    if not report_generator.multi_sessions:
        error_msg = "No multi-session data loaded"
        report_generator.log_entry(error_msg, level="error")
        raise ValueError(error_msg)

    project_name = report_generator.project_name
    report_title, report_type_str = _resolve_multi_report_metadata(report_generator)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_filename = f"{project_name}_{report_type_str}_Report_{timestamp}.pdf"
    report_generator.pdf_file = report_generator.output_dir / pdf_filename
    report_generator.log_entry(f"Creating PDF at: {report_generator.pdf_file}", level="debug")

    pdf_password = _resolve_pdf_password(report_generator)
    doc = create_pdf_document(
        output_path=report_generator.pdf_file,
        page_size=report_generator.page_size,
        compress_pdf=report_generator.compress_pdf,
        pdf_password=pdf_password,
        header_text=report_title,
    )
    styles = get_pdf_styles()
    story = []

    if report_generator.report_type == "day":
        add_report_title(story, "Screenshot Day Report", styles)
    else:
        add_report_title(story, "Screenshot Project Report", styles)
    add_section_header(story, report_title, styles)

    if report_generator.client_info:
        add_client_info_table(
            story=story, client_info=report_generator.client_info.dict(), styles=styles
        )

    stats = report_generator.multi_sessions.get_combined_stats()
    add_section_header(story, "Report Summary", styles)
    _add_multi_summary_table(story, stats, styles, report_generator.report_type)
    if report_generator.report_type == "project":
        _render_goals_summary_table(
            story,
            getattr(report_generator.multi_sessions, "project_goal_summary", []) or [],
            styles,
        )
    else:
        _render_goals_summary_table(
            story, _aggregate_day_goal_events(report_generator.multi_sessions), styles
        )

    for day, sessions in sorted(report_generator.multi_sessions.sessions_by_day.items()):
        _append_page_break_if_needed(story)
        add_section_header(story, f"Day: {day}", styles)

        for session_dir in sessions:
            session_name = session_dir.name
            session_time = session_name.split("_")[1].replace("-", ":")
            session_log = report_generator.multi_sessions.session_logs.get(session_name)
            if not session_log:
                report_generator.log_entry(
                    f"Session log for {session_name} not loaded", level="warning"
                )
                continue

            add_subsection_header(story, f"Session: {session_time}", styles)

            if session_log.session_start and session_log.session_end:
                note_count = _compute_note_count(session_log)
                add_session_summary_table(
                    story=story,
                    summary=SessionSummaryData(
                        session_start=session_log.session_start,
                        session_end=session_log.session_end,
                        session_duration=session_log.session_duration,
                        screenshot_count=len(session_log.screenshots),
                        note_count=note_count,
                        goal_count=_compute_goal_count(session_log),
                    ),
                    styles=styles,
                )

            _render_session_start_note(story, session_log, styles)

            _render_chronological_events(
                EventRenderContext(
                    story=story,
                    session_log=session_log,
                    screenshots_dir=_resolve_session_screenshots_dir(
                        report_generator,
                        session_dir,
                    ),
                    report_generator=report_generator,
                    styles=styles,
                    relocation_log=relocation_log,
                    page_break_between_sets=False,
                )
            )

            # Add a page break after each session except the last one in the last day
            if not (
                day == list(sorted(report_generator.multi_sessions.sessions_by_day.keys()))[-1]
                and session_dir == sessions[-1]
            ):
                story.append(PageBreak())

    if relocation_log:
        changes_saved = handle_image_relocations(report_generator, relocation_log)
        report_generator.log_entry(
            f"Processed {len(relocation_log)} image relocations (changes: {changes_saved})",
            level="debug",
        )
    return _build_pdf_with_logging(report_generator, doc, story)
