#!/usr/bin/env python3
"""PDF table components for consistent report design."""

from dataclasses import dataclass
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

REPORT_TABLE_HEADER_BG = colors.HexColor("#808080")
REPORT_TABLE_GRID = colors.HexColor("#9a9a9a")
REPORT_TABLE_HEADER_TEXT = colors.white
REPORT_TABLE_BODY_TEXT = colors.black
REPORT_TABLE_FONT_SIZE = 10
REPORT_TABLE_LEADING = 13
REPORT_TABLE_PADDING_Y = 6
REPORT_TABLE_PADDING_X = 4

REPORT_TABLE_HEADER_CELL = ParagraphStyle(
    "ReportTableHeaderCell",
    fontName="Helvetica-Bold",
    fontSize=REPORT_TABLE_FONT_SIZE,
    leading=REPORT_TABLE_LEADING,
    textColor=REPORT_TABLE_HEADER_TEXT,
)
REPORT_TABLE_CELL = ParagraphStyle(
    "ReportTableCell",
    fontName="Helvetica",
    fontSize=REPORT_TABLE_FONT_SIZE,
    leading=REPORT_TABLE_LEADING,
    textColor=REPORT_TABLE_BODY_TEXT,
)
REPORT_TABLE_LABEL_CELL = ParagraphStyle(
    "ReportTableLabelCell",
    fontName="Helvetica-Bold",
    fontSize=REPORT_TABLE_FONT_SIZE,
    leading=REPORT_TABLE_LEADING,
    textColor=REPORT_TABLE_BODY_TEXT,
)
REPORT_EVENT_BODY_CELL = ParagraphStyle(
    "ReportEventBodyCell",
    fontName="Helvetica",
    fontSize=11,
    leading=15,
    textColor=REPORT_TABLE_BODY_TEXT,
)


def _as_paragraph(value: object, style: ParagraphStyle) -> Paragraph:
    """Convert a table value into a styled paragraph."""
    text = "" if value is None else str(value)
    return Paragraph(escape(text).replace("\n", "<br/>"), style)


def _table_cell(value: object) -> Paragraph:
    """Create a standard report table body cell."""
    return _as_paragraph(value, REPORT_TABLE_CELL)


def _table_header(value: object) -> Paragraph:
    """Create a standard report table header cell."""
    return _as_paragraph(value, REPORT_TABLE_HEADER_CELL)


def _apply_report_table_style(table: Table, *, centered_columns: tuple[int, ...] = ()) -> None:
    """Apply the shared report table visual system."""
    commands = [
        ("BACKGROUND", (0, 0), (-1, 0), REPORT_TABLE_HEADER_BG),
        ("TEXTCOLOR", (0, 0), (-1, 0), REPORT_TABLE_HEADER_TEXT),
        ("TEXTCOLOR", (0, 1), (-1, -1), REPORT_TABLE_BODY_TEXT),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), REPORT_TABLE_FONT_SIZE),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, REPORT_TABLE_GRID),
        ("BOTTOMPADDING", (0, 0), (-1, -1), REPORT_TABLE_PADDING_Y),
        ("TOPPADDING", (0, 0), (-1, -1), REPORT_TABLE_PADDING_Y),
        ("LEFTPADDING", (0, 0), (-1, -1), REPORT_TABLE_PADDING_X),
        ("RIGHTPADDING", (0, 0), (-1, -1), REPORT_TABLE_PADDING_X),
    ]
    for column in centered_columns:
        commands.append(("ALIGN", (column, 0), (column, -1), "CENTER"))
    table.setStyle(TableStyle(commands))


def _apply_report_event_table_style(table: Table) -> None:
    """Apply shared styling for note, caption, and goal-update event tables."""
    _apply_report_table_style(table)
    table.setStyle(
        TableStyle(
            [
                ("SPAN", (0, 1), (-1, 1)),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 8),
                ("TOPPADDING", (0, 1), (-1, 1), 8),
            ]
        )
    )


def _apply_goal_update_event_table_style(table: Table) -> None:
    """Apply shared styling for goal-update event tables with a goal title row."""
    _apply_report_table_style(table)
    table.setStyle(
        TableStyle(
            [
                ("SPAN", (0, 1), (-1, 1)),
                ("BACKGROUND", (0, 1), (-1, 1), REPORT_TABLE_HEADER_BG),
                ("TEXTCOLOR", (0, 1), (-1, 1), REPORT_TABLE_HEADER_TEXT),
                ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
                ("SPAN", (0, 2), (-1, 2)),
                ("BOTTOMPADDING", (0, 2), (-1, 2), 8),
                ("TOPPADDING", (0, 2), (-1, 2), 8),
            ]
        )
    )


def _build_header_table(
    rows: list[list[object]],
    col_widths: list[float],
    centered_columns: tuple[int, ...] = (),
) -> Table:
    """Build a table with a dark header row and shared report styling."""
    styled_rows = [
        [_table_header(value) if row_index == 0 else _table_cell(value) for value in row]
        for row_index, row in enumerate(rows)
    ]
    table = Table(styled_rows, colWidths=col_widths, repeatRows=1)
    _apply_report_table_style(table, centered_columns=centered_columns)
    return table


def _build_key_value_table(rows: list[list[str]], col_widths: list[float]) -> Table:
    """Build a standard two-column report table."""
    return _build_header_table(rows, col_widths)


def add_client_info_table(story: list, client_info: dict, styles: dict) -> None:
    """Add client information table to the PDF story."""
    client_data = [
        ["Field", "Value"],
        ["Client", client_info.get("client_name", "")],
        ["Company", client_info.get("company_name", "")],
        ["Contact", client_info.get("contact_name", "")],
        ["Email", client_info.get("contact_email", "")],
    ]
    story.append(_build_key_value_table(client_data, [1.5 * inch, 4 * inch]))
    story.append(Spacer(1, 0.3 * inch))


def add_session_summary_table(
    story: list,
    summary: "SessionSummaryData",
    styles: dict,
) -> None:
    """Add session summary table to the PDF story."""
    session_data = [
        ["Metric", "Value"],
        ["Start Time", summary.session_start],
        ["End Time", summary.session_end],
        ["Duration", summary.session_duration],
        ["Screenshots", str(summary.screenshot_count)],
        ["Notes", str(summary.note_count)],
    ]
    if summary.goal_count:
        session_data.append(["Goal Updates", str(summary.goal_count)])
    story.append(_build_key_value_table(session_data, [1.5 * inch, 4 * inch]))
    story.append(Spacer(1, 0.2 * inch))


def add_report_summary_table(
    story: list,
    summary_data: list[list[str]],
    styles: dict,
) -> None:
    """Add multi-session report summary data using the shared table design."""
    rows: list[list[object]] = [["Metric", "Value"], *summary_data]
    story.append(_build_key_value_table(rows, [2 * inch, 3 * inch]))
    story.append(Spacer(1, 0.3 * inch))


def add_event_table(
    story: list,
    event_type: str,
    timestamp: str,
    content: str,
    styles: dict,
) -> None:
    """Add a timeline event as a readable two-row report table."""
    rows = [
        [_table_header(event_type), _table_header(timestamp)],
        [_as_paragraph(content, REPORT_EVENT_BODY_CELL), ""],
    ]
    table = Table(rows, colWidths=[2 * inch, 4.5 * inch], repeatRows=1)
    _apply_report_event_table_style(table)
    story.append(table)
    story.append(Spacer(1, 0.15 * inch))


def add_goal_update_event_table(
    story: list,
    goal_title: str,
    timestamp: str,
    content: str,
    styles: dict,
) -> None:
    """Add a goal-update timeline event with the goal name as a header row."""
    goal_label = f"Goal Update: {goal_title}" if goal_title else "Goal Update"
    rows = [
        [_table_header("Goal Update"), _table_header(timestamp)],
        [_table_header(goal_label), ""],
        [_as_paragraph(content, REPORT_EVENT_BODY_CELL), ""],
    ]
    table = Table(rows, colWidths=[2 * inch, 4.5 * inch], repeatRows=1)
    _apply_goal_update_event_table_style(table)
    story.append(table)
    story.append(Spacer(1, 0.15 * inch))


_STATUS_LABELS: dict[str, str] = {
    "active": "Active",
    "completed": "Complete",
    "archived": "Archived",
}


def add_goals_summary_table(story: list, goals: list[dict], styles: dict) -> None:
    """Add project goals summary table (Goal | Status | Latest Note) to the PDF story."""
    if not goals:
        return

    rows: list[list] = [
        [
            "Goal",
            "Status",
            "Latest Note",
        ]
    ]
    for goal in goals:
        title = goal.get("title", "Untitled")
        status_label = _STATUS_LABELS.get(goal.get("status", "active"), "Active")
        notes = [n for n in goal.get("notes", []) if n.get("timestamp")]
        latest_note = ""
        if notes:
            best = max(notes, key=lambda n: n["timestamp"])
            ts = best.get("timestamp", "")
            content = best.get("content", "")
            latest_note = f"{ts}: {content}" if ts else content
        rows.append(
            [
                title,
                status_label,
                latest_note,
            ]
        )

    col_widths = [2.2 * inch, 0.9 * inch, 3.4 * inch]
    story.append(_build_header_table(rows, col_widths, centered_columns=(1,)))
    story.append(Spacer(1, 0.3 * inch))


@dataclass(slots=True)
class SessionSummaryData:
    """Summary values displayed in a report session table."""

    session_start: str
    session_end: str
    session_duration: str
    screenshot_count: int
    note_count: int
    goal_count: int = 0
