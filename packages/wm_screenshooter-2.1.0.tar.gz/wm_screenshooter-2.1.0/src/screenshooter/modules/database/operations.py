#!/usr/bin/env python3
"""Database operations for ScreenShooter Mac.

Provides CRUD operations for all database entities, mirroring
the existing file-based logging functionality.
"""

import json
import uuid
from datetime import datetime, timezone

from .database import DatabaseManager, get_database_manager
from .models import (
    DatabaseClient,
    DatabaseGoalNoteType,
    DatabaseGoalStatus,
    DatabaseNote,
    DatabaseProject,
    DatabaseProjectGoal,
    DatabaseProjectGoalNote,
    DatabaseScreenshot,
    DatabaseSession,
    DatabaseTimingAnomaly,
)


def _utc_iso() -> str:
    """Return current UTC time as ISO 8601 string with milliseconds."""
    now = datetime.now(timezone.utc)
    return now.strftime(f"%Y-%m-%dT%H:%M:%S.{now.microsecond // 1000:03d}Z")


class DatabaseOperations:
    """Handles all database CRUD operations."""

    def __init__(self, db_manager: DatabaseManager | None = None):
        """Initialize database operations.

        Args:
            db_manager: Optional database manager instance
        """
        self.db = db_manager or get_database_manager()

    # Client operations
    def create_client(self, client: DatabaseClient) -> int | None:
        """Create a new client record.

        Args:
            client: Client data

        Returns:
            Client ID
        """
        remote_uuid = client.remote_uuid or str(uuid.uuid4())
        cursor = self.db.execute_query(
            """
            INSERT INTO clients (name, directory_name, company_name, contact_name,
                               contact_email, pdf_password, preferences, remote_uuid)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                client.name,
                client.directory_name,
                client.company_name,
                client.contact_name,
                client.contact_email,
                client.pdf_password,
                json.dumps(client.preferences),
                remote_uuid,
            ),
        )
        self.db.commit()
        client_id = cursor.lastrowid
        if client_id is None:
            raise RuntimeError("Failed to create client: no ID returned")
        return client_id

    def get_client_by_name(self, name: str) -> DatabaseClient | None:
        """Get client by name.

        Args:
            name: Client name

        Returns:
            Client data or None if not found
        """
        cursor = self.db.execute_query("SELECT * FROM clients WHERE name = ?", (name,))
        row = cursor.fetchone()
        if row:
            return self._row_to_client(row)
        return None

    def get_client_by_directory(self, directory_name: str) -> DatabaseClient | None:
        """Get client by directory name.

        Args:
            directory_name: Client directory name

        Returns:
            Client data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM clients WHERE directory_name = ?", (directory_name,)
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_client(row)
        return None

    def list_clients(self, active_only: bool = False) -> list[DatabaseClient]:
        """List clients.

        Args:
            active_only: If True, only return active clients (not archived)

        Returns:
            List of clients
        """
        if active_only:
            cursor = self.db.execute_query(
                "SELECT * FROM clients WHERE archived_at IS NULL ORDER BY name"
            )
        else:
            cursor = self.db.execute_query("SELECT * FROM clients ORDER BY name")
        return [self._row_to_client(row) for row in cursor.fetchall()]

    def update_client(self, client: DatabaseClient) -> bool:
        """Update client record.

        Args:
            client: Updated client data

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE clients SET name = ?, directory_name = ?, company_name = ?,
                              contact_name = ?, contact_email = ?, pdf_password = ?,
                              preferences = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """,
            (
                client.name,
                client.directory_name,
                client.company_name,
                client.contact_name,
                client.contact_email,
                client.pdf_password,
                json.dumps(client.preferences),
                client.id,
            ),
        )
        self.db.commit()
        return cursor.rowcount > 0

    # Project operations
    def create_project(self, project: DatabaseProject) -> int | None:
        """Create a new project record.

        Args:
            project: Project data

        Returns:
            Project ID
        """
        remote_uuid = project.remote_uuid or str(uuid.uuid4())
        cursor = self.db.execute_query(
            """
            INSERT INTO projects (client_id, name, directory_name, remote_uuid)
            VALUES (?, ?, ?, ?)
            """,
            (project.client_id, project.name, project.directory_name, remote_uuid),
        )
        self.db.commit()
        project_id = cursor.lastrowid
        if project_id is None:
            raise RuntimeError("Failed to create project: no ID returned")
        return project_id

    def get_project_by_name(self, client_id: int, name: str) -> DatabaseProject | None:
        """Get project by client ID and name.

        Args:
            client_id: Client ID
            name: Project name

        Returns:
            Project data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM projects WHERE client_id = ? AND name = ?", (client_id, name)
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_project(row)
        return None

    def get_project_by_directory(
        self, client_id: int, directory_name: str
    ) -> DatabaseProject | None:
        """Get project by client ID and directory name.

        Args:
            client_id: Client ID
            directory_name: Project directory name

        Returns:
            Project data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM projects WHERE client_id = ? AND directory_name = ?",
            (client_id, directory_name),
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_project(row)
        return None

    def get_project_by_id(self, project_id: int) -> DatabaseProject | None:
        """Get project by ID.

        Args:
            project_id: Project ID

        Returns:
            Project data or None if not found
        """
        cursor = self.db.execute_query("SELECT * FROM projects WHERE id = ?", (project_id,))
        row = cursor.fetchone()
        if row:
            return self._row_to_project(row)
        return None

    def list_projects(self, client_id: int, active_only: bool = True) -> list[DatabaseProject]:
        """List projects for a client.

        Args:
            client_id: Client ID
            active_only: If True, only return active projects

        Returns:
            List of projects
        """
        if active_only:
            cursor = self.db.execute_query(
                """
                SELECT * FROM projects
                WHERE client_id = ? AND archived_at IS NULL
                ORDER BY name
                """,
                (client_id,),
            )
        else:
            cursor = self.db.execute_query(
                "SELECT * FROM projects WHERE client_id = ? ORDER BY name", (client_id,)
            )
        return [self._row_to_project(row) for row in cursor.fetchall()]

    def list_archived_projects(self, client_id: int) -> list[DatabaseProject]:
        """List archived projects for a client, ordered by most recently archived.

        Args:
            client_id: Client ID

        Returns:
            List of archived projects ordered by updated_at DESC
        """
        cursor = self.db.execute_query(
            """
            SELECT * FROM projects
            WHERE client_id = ? AND archived_at IS NOT NULL
            ORDER BY archived_at DESC
            """,
            (client_id,),
        )
        return [self._row_to_project(row) for row in cursor.fetchall()]

    def update_project_name(self, project_id: int, new_name: str) -> bool:
        """Update a project's display name.

        Args:
            project_id: Project ID to update
            new_name: New display name for the project

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE projects
            SET name = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (new_name, project_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def list_archived_clients(self) -> list[DatabaseClient]:
        """List archived clients, ordered by most recently archived.

        Returns:
            List of archived clients ordered by archived_at DESC
        """
        cursor = self.db.execute_query(
            """
            SELECT * FROM clients
            WHERE archived_at IS NOT NULL
            ORDER BY archived_at DESC
            """
        )
        return [self._row_to_client(row) for row in cursor.fetchall()]

    # Session operations

    def create_session(self, session: DatabaseSession) -> int | None:
        """Create a new session record.

        Args:
            session: Session data

        Returns:
            Session ID
        """
        remote_uuid = session.remote_uuid or str(uuid.uuid4())
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            INSERT INTO sessions (project_id, name, start_time, end_time,
                                duration_seconds, timer_mode, remote_uuid, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                session.project_id,
                session.name,
                session.start_time,
                session.end_time,
                session.duration_seconds,
                session.timer_mode,
                remote_uuid,
                now,
            ),
        )
        self.db.commit()
        session_id = cursor.lastrowid
        if session_id is None:
            raise RuntimeError("Failed to create session: no ID returned")
        return session_id

    def update_session(self, session: DatabaseSession) -> bool:
        """Update session record.

        Args:
            session: Updated session data

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE sessions SET end_time = ?, duration_seconds = ?,
                              timer_mode = ?, updated_at = ?
            WHERE id = ?
        """,
            (
                session.end_time,
                session.duration_seconds,
                session.timer_mode,
                _utc_iso(),
                session.id,
            ),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_session(self, session_id: int) -> bool:
        """Archive a session (soft delete).

        Args:
            session_id: Session ID to archive

        Returns:
            True if successful, False otherwise
        """
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            UPDATE sessions
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),
                deleted_at = COALESCE(deleted_at, ?),
                updated_at = ?
            WHERE id = ?
            """,
            (now, now, session_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_client(self, client_id: int) -> bool:
        """Archive a client and all related data (soft delete).

        Args:
            client_id: Client ID to archive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE clients
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),
                deleted_at = COALESCE(deleted_at, strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (client_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_client(self, client_id: int) -> bool:
        """Unarchive a client.

        Args:
            client_id: Client ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE clients
            SET archived_at = NULL,
                deleted_at = NULL,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (client_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def get_sync_state(self, server_url: str, device_id: str) -> dict[str, str | None] | None:
        """Return sync checkpoint state for a server/device pair."""
        cursor = self.db.execute_query(
            """
            SELECT last_push, last_pull
            FROM sync_state
            WHERE server_url = ? AND device_id = ?
            """,
            (server_url, device_id),
        )
        row = cursor.fetchone()
        if row is None:
            return None
        return {"last_push": row["last_push"], "last_pull": row["last_pull"]}

    def update_sync_state_push(self, server_url: str, device_id: str, timestamp: str) -> None:
        """Record a successful push checkpoint for a server/device pair."""
        self.db.execute_query(
            """
            INSERT INTO sync_state (server_url, device_id, last_push,
                                    updated_at)
            VALUES (?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
            ON CONFLICT(server_url, device_id)
            DO UPDATE SET last_push = excluded.last_push,
                          updated_at = excluded.updated_at
            """,
            (server_url, device_id, timestamp),
        )
        self.db.commit()

    def reset_sync_state_push(self, server_url: str, device_id: str) -> None:
        """Clear the push checkpoint so the next sync re-pushes all records."""
        self.db.execute_query(
            """
            UPDATE sync_state
            SET last_push = NULL, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
            WHERE server_url = ? AND device_id = ?
            """,
            (server_url, device_id),
        )
        self.db.commit()

    def update_sync_state_pull(self, server_url: str, device_id: str, timestamp: str) -> None:
        """Record a successful pull checkpoint for a server/device pair."""
        self.db.execute_query(
            """
            INSERT INTO sync_state (server_url, device_id, last_pull,
                                    updated_at)
            VALUES (?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
            ON CONFLICT(server_url, device_id)
            DO UPDATE SET last_pull = excluded.last_pull,
                          updated_at = excluded.updated_at
            """,
            (server_url, device_id, timestamp),
        )
        self.db.commit()

    def archive_project(self, project_id: int) -> bool:
        """Archive a project and all related data (soft delete).

        Args:
            project_id: Project ID to archive

        Returns:
            True if successful, False otherwise
        """
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            UPDATE projects
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),
                updated_at = CURRENT_TIMESTAMP,
                deleted_at = COALESCE(deleted_at, ?)
            WHERE id = ?
            """,
            (now, project_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_project(self, project_id: int) -> bool:
        """Unarchive a project (restore from soft delete).

        Args:
            project_id: Project ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE projects
            SET archived_at = NULL,
                updated_at = CURRENT_TIMESTAMP,
                deleted_at = NULL
            WHERE id = ?
            """,
            (project_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_screenshot(self, screenshot_id: int) -> bool:
        """Archive a screenshot (soft delete).

        Args:
            screenshot_id: Screenshot ID to archive

        Returns:
            True if successful, False otherwise
        """
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            UPDATE screenshots
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),
                deleted_at = COALESCE(deleted_at, ?),
                updated_at = ?
            WHERE id = ?
            """,
            (now, now, screenshot_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_note(self, note_id: int) -> bool:
        """Archive a note (soft delete).

        Args:
            note_id: Note ID to archive

        Returns:
            True if successful, False otherwise
        """
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            UPDATE notes
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),
                deleted_at = COALESCE(deleted_at, ?),
                updated_at = ?
            WHERE id = ?
            """,
            (now, now, note_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_screenshot(self, screenshot_id: int) -> bool:
        """Unarchive a screenshot (restore from soft delete).

        Args:
            screenshot_id: Screenshot ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            UPDATE screenshots
            SET archived_at = NULL,
                deleted_at = NULL,
                updated_at = ?
            WHERE id = ?
            """,
            (now, screenshot_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_note(self, note_id: int) -> bool:
        """Unarchive a note (restore from soft delete).

        Args:
            note_id: Note ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            UPDATE notes
            SET archived_at = NULL,
                deleted_at = NULL,
                updated_at = ?
            WHERE id = ?
            """,
            (now, note_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def get_session_by_name(self, project_id: int, name: str) -> DatabaseSession | None:
        """Get session by project ID and name.

        Args:
            project_id: Project ID
            name: Session name

        Returns:
            Session data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM sessions WHERE project_id = ? AND name = ?", (project_id, name)
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_session(row)
        return None

    def list_sessions(self, project_id: int) -> list[DatabaseSession]:
        """List sessions for a project.

        Args:
            project_id: Project ID

        Returns:
            List of sessions
        """
        cursor = self.db.execute_query(
            "SELECT * FROM sessions WHERE project_id = ? ORDER BY start_time DESC", (project_id,)
        )
        return [self._row_to_session(row) for row in cursor.fetchall()]

    def list_timing_anomalies(self, include_archived: bool = True) -> list[DatabaseTimingAnomaly]:
        """List sessions with suspicious timing values.

        Args:
            include_archived: If True, include archived clients, projects, and sessions

        Returns:
            List of anomalous session timing rows
        """
        archived_filter = ""
        if not include_archived:
            archived_filter = (
                "AND c.archived_at IS NULL AND p.archived_at IS NULL AND s.archived_at IS NULL"
            )

        cursor = self.db.execute_query(
            f"""
            SELECT
                c.name AS client_name,
                c.directory_name AS client_directory_name,
                p.name AS project_name,
                p.directory_name AS project_directory_name,
                s.name AS session_name,
                s.duration_seconds AS duration_seconds,
                CASE
                    WHEN s.start_time IS NOT NULL AND s.end_time IS NOT NULL THEN
                        CAST((julianday(s.end_time) - julianday(s.start_time)) * 86400 AS INTEGER)
                    ELSE NULL
                END AS computed_seconds,
                s.start_time AS start_time,
                s.end_time AS end_time,
                CASE
                    WHEN s.duration_seconds IS NOT NULL AND s.duration_seconds < 0 THEN
                        'negative duration_seconds'
                    WHEN s.duration_seconds IS NULL
                        AND s.start_time IS NOT NULL
                        AND s.end_time IS NOT NULL
                        AND CAST(
                            (julianday(s.end_time) - julianday(s.start_time)) * 86400
                            AS INTEGER
                        ) < 0
                    THEN 'end_time before start_time'
                    ELSE 'unknown anomaly'
                END AS reason
            FROM clients c
            JOIN projects p ON p.client_id = c.id
            JOIN sessions s ON s.project_id = p.id
            WHERE (
                (s.duration_seconds IS NOT NULL AND s.duration_seconds < 0)
                OR (
                    s.duration_seconds IS NULL
                    AND s.start_time IS NOT NULL
                    AND s.end_time IS NOT NULL
                    AND CAST(
                        (julianday(s.end_time) - julianday(s.start_time)) * 86400 AS INTEGER
                    ) < 0
                )
            )
            {archived_filter}
            ORDER BY c.name, p.name, s.name
            """
        )
        return [self._row_to_timing_anomaly(row) for row in cursor.fetchall()]

    # Screenshot operations

    def create_screenshot(self, screenshot: DatabaseScreenshot) -> int | None:
        """Create a new screenshot record.

        Args:
            screenshot: Screenshot data

        Returns:
            Screenshot ID
        """
        remote_uuid = screenshot.remote_uuid or str(uuid.uuid4())
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            INSERT INTO screenshots (session_id, set_id, file_path, timestamp,
                                   display_mode, suffix, remote_uuid, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                screenshot.session_id,
                screenshot.set_id,
                screenshot.file_path,
                screenshot.timestamp,
                screenshot.display_mode,
                screenshot.suffix,
                remote_uuid,
                now,
            ),
        )
        self.db.commit()
        screenshot_id = cursor.lastrowid
        if screenshot_id is None:
            raise RuntimeError("Failed to create screenshot: no ID returned")
        return screenshot_id

    def list_screenshots(
        self, session_id: int, include_archived: bool = False
    ) -> list[DatabaseScreenshot]:
        """List screenshots for a session.

        Args:
            session_id: Session ID
            include_archived: If True, include archived screenshots

        Returns:
            List of screenshots
        """
        if include_archived:
            cursor = self.db.execute_query(
                "SELECT * FROM screenshots WHERE session_id = ? ORDER BY timestamp", (session_id,)
            )
        else:
            cursor = self.db.execute_query(
                (
                    "SELECT * FROM screenshots WHERE session_id = ? AND archived_at IS NULL "
                    "ORDER BY timestamp"
                ),
                (session_id,),
            )
        return [self._row_to_screenshot(row) for row in cursor.fetchall()]

    def list_all_screenshots(self) -> list[DatabaseScreenshot]:
        """List all screenshots across all sessions.

        Returns:
            List of all screenshots
        """
        cursor = self.db.execute_query("SELECT * FROM screenshots ORDER BY timestamp")
        return [self._row_to_screenshot(row) for row in cursor.fetchall()]

    def list_screenshots_for_image_upload(self) -> list[dict[str, str | int | None]]:
        """List screenshots eligible for Workmaster image upload.

        Returns:
            Screenshot rows with id, remote_uuid, and file_path.
        """
        cursor = self.db.execute_query(
            "SELECT id, remote_uuid, file_path FROM screenshots "
            "WHERE remote_uuid IS NOT NULL AND deleted_at IS NULL"
        )
        return [
            {
                "id": row["id"],
                "remote_uuid": row["remote_uuid"],
                "file_path": row["file_path"],
            }
            for row in cursor.fetchall()
        ]

    # Note operations

    def create_note(self, note: DatabaseNote) -> int | None:
        """Create a new note record.

        Args:
            note: Note data

        Returns:
            Note ID
        """
        remote_uuid = note.remote_uuid or str(uuid.uuid4())
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            INSERT INTO notes (session_id, content, note_type, timestamp, remote_uuid, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (note.session_id, note.content, note.note_type, note.timestamp, remote_uuid, now),
        )
        self.db.commit()
        note_id = cursor.lastrowid
        if note_id is None:
            raise RuntimeError("Failed to create note: no ID returned")
        return note_id

    def list_notes(self, session_id: int, include_archived: bool = False) -> list[DatabaseNote]:
        """List notes for a session.

        Args:
            session_id: Session ID
            include_archived: If True, include archived notes

        Returns:
            List of notes
        """
        if include_archived:
            cursor = self.db.execute_query(
                "SELECT * FROM notes WHERE session_id = ? ORDER BY timestamp", (session_id,)
            )
        else:
            cursor = self.db.execute_query(
                (
                    "SELECT * FROM notes WHERE session_id = ? AND archived_at IS NULL ORDER "
                    "BY timestamp"
                ),
                (session_id,),
            )
        return [self._row_to_note(row) for row in cursor.fetchall()]

    # Project goal operations

    def create_project_goal(self, goal: DatabaseProjectGoal) -> int | None:
        """Create a new project goal record."""
        remote_uuid = goal.remote_uuid or str(uuid.uuid4())
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            INSERT INTO project_goals (
                project_id, title, description, status, created_session_id,
                closed_session_id, created_at, updated_at, completed_at,
                archived_at, remote_uuid, deleted_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                goal.project_id,
                goal.title,
                goal.description,
                goal.status or DatabaseGoalStatus.ACTIVE,
                goal.created_session_id,
                goal.closed_session_id,
                goal.created_at or now,
                now,
                goal.completed_at,
                goal.archived_at,
                remote_uuid,
                goal.deleted_at,
            ),
        )
        self.db.commit()
        goal_id = cursor.lastrowid
        if goal_id is None:
            raise RuntimeError("Failed to create project goal: no ID returned")
        return goal_id

    def list_project_goals(
        self, project_id: int, include_archived: bool = False
    ) -> list[DatabaseProjectGoal]:
        """List goals for a project."""
        if include_archived:
            cursor = self.db.execute_query(
                """
                SELECT * FROM project_goals
                WHERE project_id = ?
                ORDER BY created_at ASC, id ASC
                """,
                (project_id,),
            )
        else:
            cursor = self.db.execute_query(
                """
                SELECT * FROM project_goals
                WHERE project_id = ? AND deleted_at IS NULL
                ORDER BY created_at ASC, id ASC
                """,
                (project_id,),
            )
        return [self._row_to_project_goal(row) for row in cursor.fetchall()]

    def list_active_project_goals(self, project_id: int) -> list[DatabaseProjectGoal]:
        """List active, non-archived goals for a project."""
        cursor = self.db.execute_query(
            """
            SELECT * FROM project_goals
            WHERE project_id = ? AND status = ? AND deleted_at IS NULL
            ORDER BY created_at ASC, id ASC
            """,
            (project_id, DatabaseGoalStatus.ACTIVE),
        )
        return [self._row_to_project_goal(row) for row in cursor.fetchall()]

    def list_recent_closed_project_goals(
        self, project_id: int, limit: int = 5
    ) -> list[DatabaseProjectGoal]:
        """List recently completed or archived goals for a project."""
        cursor = self.db.execute_query(
            """
            SELECT * FROM project_goals
            WHERE project_id = ? AND status IN (?, ?)
            ORDER BY COALESCE(completed_at, archived_at, updated_at, created_at) DESC, id DESC
            LIMIT ?
            """,
            (
                project_id,
                DatabaseGoalStatus.COMPLETED,
                DatabaseGoalStatus.ARCHIVED,
                limit,
            ),
        )
        return [self._row_to_project_goal(row) for row in cursor.fetchall()]

    def get_project_goal(self, goal_id: int) -> DatabaseProjectGoal | None:
        """Get a project goal by ID."""
        cursor = self.db.execute_query("SELECT * FROM project_goals WHERE id = ?", (goal_id,))
        row = cursor.fetchone()
        if row:
            return self._row_to_project_goal(row)
        return None

    def add_project_goal_note(self, note: DatabaseProjectGoalNote) -> int | None:
        """Create a note attached to a project goal."""
        return self._insert_project_goal_note(note, commit=True)

    def list_project_goal_notes(
        self, goal_id: int, include_archived: bool = False
    ) -> list[DatabaseProjectGoalNote]:
        """List notes for a project goal."""
        if include_archived:
            cursor = self.db.execute_query(
                """
                SELECT * FROM project_goal_notes
                WHERE goal_id = ?
                ORDER BY timestamp ASC, id ASC
                """,
                (goal_id,),
            )
        else:
            cursor = self.db.execute_query(
                """
                SELECT * FROM project_goal_notes
                WHERE goal_id = ? AND deleted_at IS NULL
                ORDER BY timestamp ASC, id ASC
                """,
                (goal_id,),
            )
        return [self._row_to_project_goal_note(row) for row in cursor.fetchall()]

    def list_goal_changes_for_sessions(
        self, project_id: int, session_ids: list[int]
    ) -> list[DatabaseProjectGoal]:
        """List goals created, closed, or noted in the given sessions."""
        if not session_ids:
            return []

        placeholders = ", ".join("?" for _ in session_ids)
        params: tuple = (project_id, *session_ids, *session_ids, *session_ids)
        cursor = self.db.execute_query(
            f"""
            SELECT DISTINCT g.*
            FROM project_goals g
            LEFT JOIN project_goal_notes n ON n.goal_id = g.id
            WHERE g.project_id = ?
              AND (
                g.created_session_id IN ({placeholders})
                OR g.closed_session_id IN ({placeholders})
                OR n.session_id IN ({placeholders})
              )
            ORDER BY g.created_at ASC, g.id ASC
            """,
            params,
        )
        return [self._row_to_project_goal(row) for row in cursor.fetchall()]

    def complete_project_goal(
        self, goal_id: int, session_id: int | None, note: str | None = None
    ) -> bool:
        """Complete a goal and optionally attach a completion note."""
        now = _utc_iso()
        try:
            cursor = self.db.execute_query(
                """
                UPDATE project_goals
                SET status = ?,
                    closed_session_id = ?,
                    completed_at = COALESCE(completed_at, ?),
                    archived_at = NULL,
                    deleted_at = NULL,
                    updated_at = ?
                WHERE id = ?
                """,
                (DatabaseGoalStatus.COMPLETED, session_id, now, now, goal_id),
            )
            if cursor.rowcount <= 0:
                self.db.rollback()
                return False
            if note:
                self._insert_project_goal_note(
                    DatabaseProjectGoalNote(
                        goal_id=goal_id,
                        session_id=session_id,
                        content=note,
                        note_type=DatabaseGoalNoteType.COMPLETION,
                        timestamp=now,
                    ),
                    commit=False,
                )
            self.db.commit()
            return True
        except Exception:
            self.db.rollback()
            raise

    def archive_project_goal(
        self, goal_id: int, session_id: int | None, note: str | None = None
    ) -> bool:
        """Archive a goal as not applicable and optionally attach an archive note."""
        now = _utc_iso()
        try:
            cursor = self.db.execute_query(
                """
                UPDATE project_goals
                SET status = ?,
                    closed_session_id = ?,
                    archived_at = COALESCE(archived_at, ?),
                    deleted_at = COALESCE(deleted_at, ?),
                    updated_at = ?
                WHERE id = ?
                """,
                (DatabaseGoalStatus.ARCHIVED, session_id, now, now, now, goal_id),
            )
            if cursor.rowcount <= 0:
                self.db.rollback()
                return False
            if note:
                self._insert_project_goal_note(
                    DatabaseProjectGoalNote(
                        goal_id=goal_id,
                        session_id=session_id,
                        content=note,
                        note_type=DatabaseGoalNoteType.ARCHIVE,
                        timestamp=now,
                    ),
                    commit=False,
                )
            self.db.commit()
            return True
        except Exception:
            self.db.rollback()
            raise

    def unarchive_project_goal(self, goal_id: int) -> bool:
        """Restore an archived goal to active status."""
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            UPDATE project_goals
            SET status = ?,
                closed_session_id = NULL,
                completed_at = NULL,
                archived_at = NULL,
                deleted_at = NULL,
                updated_at = ?
            WHERE id = ?
            """,
            (DatabaseGoalStatus.ACTIVE, now, goal_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def _insert_project_goal_note(
        self, note: DatabaseProjectGoalNote, *, commit: bool
    ) -> int | None:
        """Insert a project goal note, optionally committing immediately."""
        remote_uuid = note.remote_uuid or str(uuid.uuid4())
        now = _utc_iso()
        cursor = self.db.execute_query(
            """
            INSERT INTO project_goal_notes (
                goal_id, session_id, content, note_type, timestamp,
                created_at, updated_at, archived_at, remote_uuid, deleted_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                note.goal_id,
                note.session_id,
                note.content,
                note.note_type or DatabaseGoalNoteType.PROGRESS,
                note.timestamp or now,
                note.created_at or now,
                now,
                note.archived_at,
                remote_uuid,
                note.deleted_at,
            ),
        )
        self.db.execute_query(
            "UPDATE project_goals SET updated_at = ? WHERE id = ?",
            (now, note.goal_id),
        )
        if commit:
            self.db.commit()
        note_id = cursor.lastrowid
        if note_id is None:
            raise RuntimeError("Failed to create project goal note: no ID returned")
        return note_id

    # Helper methods for converting database rows to models

    def _row_to_client(self, row) -> DatabaseClient:
        """Convert database row to DatabaseClient."""
        row_keys = row.keys()
        return DatabaseClient(
            id=row["id"],
            name=row["name"],
            directory_name=row["directory_name"],
            company_name=row["company_name"],
            contact_name=row["contact_name"],
            contact_email=row["contact_email"],
            pdf_password=row["pdf_password"],
            preferences=json.loads(row["preferences"]) if row["preferences"] else {},
            archived_at=row["archived_at"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            remote_uuid=row["remote_uuid"] if "remote_uuid" in row_keys else None,
            deleted_at=row["deleted_at"] if "deleted_at" in row_keys else None,
        )

    def _row_to_project(self, row) -> DatabaseProject:
        """Convert database row to DatabaseProject."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        active_value = archived_at is None

        return DatabaseProject(
            id=row["id"],
            client_id=row["client_id"],
            name=row["name"],
            directory_name=row["directory_name"],
            active=active_value,
            archived_at=archived_at,
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            remote_uuid=row["remote_uuid"] if "remote_uuid" in row_keys else None,
            deleted_at=row["deleted_at"] if "deleted_at" in row_keys else None,
        )

    def _row_to_session(self, row) -> DatabaseSession:
        """Convert database row to DatabaseSession."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        active_value = archived_at is None

        return DatabaseSession(
            id=row["id"],
            project_id=row["project_id"],
            name=row["name"],
            start_time=row["start_time"],
            end_time=row["end_time"],
            duration_seconds=row["duration_seconds"],
            timer_mode=row["timer_mode"],
            created_at=row["created_at"],
            active=active_value,
            archived_at=archived_at,
            remote_uuid=row["remote_uuid"] if "remote_uuid" in row_keys else None,
            updated_at=row["updated_at"] if "updated_at" in row_keys else None,
            deleted_at=row["deleted_at"] if "deleted_at" in row_keys else None,
        )

    def _row_to_screenshot(self, row) -> DatabaseScreenshot:
        """Convert database row to DatabaseScreenshot."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        active_value = archived_at is None

        return DatabaseScreenshot(
            id=row["id"],
            session_id=row["session_id"],
            set_id=row["set_id"],
            file_path=row["file_path"],
            timestamp=row["timestamp"],
            display_mode=row["display_mode"],
            suffix=row["suffix"],
            active=active_value,
            archived_at=archived_at,
            created_at=row["created_at"],
            remote_uuid=row["remote_uuid"] if "remote_uuid" in row_keys else None,
            updated_at=row["updated_at"] if "updated_at" in row_keys else None,
            deleted_at=row["deleted_at"] if "deleted_at" in row_keys else None,
        )

    def _row_to_note(self, row) -> DatabaseNote:
        """Convert database row to DatabaseNote."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        active_value = archived_at is None

        return DatabaseNote(
            id=row["id"],
            session_id=row["session_id"],
            content=row["content"],
            note_type=row["note_type"] if row["note_type"] else "note",
            timestamp=row["timestamp"],
            active=active_value,
            archived_at=archived_at,
            created_at=row["created_at"],
            remote_uuid=row["remote_uuid"] if "remote_uuid" in row_keys else None,
            updated_at=row["updated_at"] if "updated_at" in row_keys else None,
            deleted_at=row["deleted_at"] if "deleted_at" in row_keys else None,
        )

    def _row_to_project_goal(self, row) -> DatabaseProjectGoal:
        """Convert database row to DatabaseProjectGoal."""
        row_keys = row.keys()
        return DatabaseProjectGoal(
            id=row["id"],
            project_id=row["project_id"],
            title=row["title"],
            description=row["description"] or "",
            status=row["status"] or DatabaseGoalStatus.ACTIVE,
            created_session_id=row["created_session_id"],
            closed_session_id=row["closed_session_id"],
            created_at=row["created_at"],
            updated_at=row["updated_at"] if "updated_at" in row_keys else None,
            completed_at=row["completed_at"],
            archived_at=row["archived_at"],
            remote_uuid=row["remote_uuid"] if "remote_uuid" in row_keys else None,
            deleted_at=row["deleted_at"] if "deleted_at" in row_keys else None,
        )

    def _row_to_project_goal_note(self, row) -> DatabaseProjectGoalNote:
        """Convert database row to DatabaseProjectGoalNote."""
        row_keys = row.keys()
        return DatabaseProjectGoalNote(
            id=row["id"],
            goal_id=row["goal_id"],
            session_id=row["session_id"],
            content=row["content"],
            note_type=row["note_type"] or DatabaseGoalNoteType.PROGRESS,
            timestamp=row["timestamp"],
            created_at=row["created_at"],
            updated_at=row["updated_at"] if "updated_at" in row_keys else None,
            archived_at=row["archived_at"],
            remote_uuid=row["remote_uuid"] if "remote_uuid" in row_keys else None,
            deleted_at=row["deleted_at"] if "deleted_at" in row_keys else None,
        )

    def _row_to_timing_anomaly(self, row) -> DatabaseTimingAnomaly:
        """Convert database row to DatabaseTimingAnomaly."""
        return DatabaseTimingAnomaly(
            client_name=row["client_name"],
            client_directory_name=row["client_directory_name"],
            project_name=row["project_name"],
            project_directory_name=row["project_directory_name"],
            session_name=row["session_name"],
            duration_seconds=row["duration_seconds"],
            computed_seconds=row["computed_seconds"],
            start_time=row["start_time"],
            end_time=row["end_time"],
            reason=row["reason"],
        )

    # No separate caption table anymore; captions are stored in ``notes``
    # with ``note_type = DatabaseNoteType.CAPTION``.
