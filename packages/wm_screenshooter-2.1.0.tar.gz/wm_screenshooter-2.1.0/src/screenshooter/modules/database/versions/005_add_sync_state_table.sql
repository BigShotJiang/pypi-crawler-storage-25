-- Migration: 005_add_sync_state_table.sql
-- Purpose: Add sync_state table to track push/pull checkpoints per server
-- Description: Create sync_state table for tracking push/pull checkpoints per server

BEGIN TRANSACTION;

CREATE TABLE IF NOT EXISTS sync_state (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_url TEXT NOT NULL,
    device_id TEXT NOT NULL,
    last_push TEXT,
    last_pull TEXT,
    created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    UNIQUE(server_url, device_id)
);

COMMIT;

-- Rollback:
-- DROP TABLE IF EXISTS sync_state;
