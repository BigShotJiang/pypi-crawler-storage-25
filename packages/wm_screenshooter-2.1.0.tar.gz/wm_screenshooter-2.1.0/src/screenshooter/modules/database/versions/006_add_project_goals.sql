-- Migration: 006_add_project_goals.sql
-- Purpose: Add project-wide goals and goal notes
-- Description: Create local project goal tracking tables for progress visible across sessions

BEGIN TRANSACTION;

CREATE TABLE IF NOT EXISTS project_goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active',
    created_session_id INTEGER,
    closed_session_id INTEGER,
    created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    completed_at TEXT,
    archived_at TEXT,
    remote_uuid TEXT UNIQUE,
    deleted_at TEXT,
    CHECK (status IN ('active', 'completed', 'archived')),
    FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE,
    FOREIGN KEY (created_session_id) REFERENCES sessions (id) ON DELETE SET NULL,
    FOREIGN KEY (closed_session_id) REFERENCES sessions (id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS project_goal_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    goal_id INTEGER NOT NULL,
    session_id INTEGER,
    content TEXT NOT NULL,
    note_type TEXT NOT NULL DEFAULT 'progress',
    timestamp TEXT NOT NULL,
    created_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    archived_at TEXT,
    remote_uuid TEXT UNIQUE,
    deleted_at TEXT,
    CHECK (note_type IN ('progress', 'completion', 'archive')),
    FOREIGN KEY (goal_id) REFERENCES project_goals (id) ON DELETE CASCADE,
    FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_project_goals_project_id ON project_goals (project_id);
CREATE INDEX IF NOT EXISTS idx_project_goals_status ON project_goals (status);
CREATE INDEX IF NOT EXISTS idx_project_goals_updated_at ON project_goals (updated_at);
CREATE INDEX IF NOT EXISTS idx_project_goals_remote_uuid ON project_goals (remote_uuid);
CREATE INDEX IF NOT EXISTS idx_project_goal_notes_goal_id ON project_goal_notes (goal_id);
CREATE INDEX IF NOT EXISTS idx_project_goal_notes_session_id ON project_goal_notes (session_id);
CREATE INDEX IF NOT EXISTS idx_project_goal_notes_timestamp ON project_goal_notes (timestamp);
CREATE INDEX IF NOT EXISTS idx_project_goal_notes_remote_uuid ON project_goal_notes (remote_uuid);

COMMIT;

-- Rollback:
-- DROP INDEX IF EXISTS idx_project_goal_notes_remote_uuid;
-- DROP INDEX IF EXISTS idx_project_goal_notes_timestamp;
-- DROP INDEX IF EXISTS idx_project_goal_notes_session_id;
-- DROP INDEX IF EXISTS idx_project_goal_notes_goal_id;
-- DROP INDEX IF EXISTS idx_project_goals_remote_uuid;
-- DROP INDEX IF EXISTS idx_project_goals_updated_at;
-- DROP INDEX IF EXISTS idx_project_goals_status;
-- DROP INDEX IF EXISTS idx_project_goals_project_id;
-- DROP TABLE IF EXISTS project_goal_notes;
-- DROP TABLE IF EXISTS project_goals;
