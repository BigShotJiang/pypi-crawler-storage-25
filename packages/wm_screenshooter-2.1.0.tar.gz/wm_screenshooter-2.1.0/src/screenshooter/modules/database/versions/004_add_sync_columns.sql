-- Migration: 004_add_sync_columns.sql
-- Purpose: Add Workmaster sync identity, tombstone, and mutation tracking columns
-- Description: Add remote_uuid, deleted_at, and updated_at columns for Workmaster sync

BEGIN TRANSACTION;

-- SQLite does not allow ALTER TABLE ADD COLUMN with a UNIQUE constraint,
-- so each table is recreated with the new columns included from the start.

PRAGMA foreign_keys = OFF;

-- =========================
-- Clients
-- =========================

CREATE TABLE clients_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    directory_name TEXT NOT NULL UNIQUE,
    company_name TEXT DEFAULT '',
    contact_name TEXT DEFAULT '',
    contact_email TEXT DEFAULT '',
    pdf_password TEXT DEFAULT '',
    preferences TEXT DEFAULT '{}',
    archived_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remote_uuid TEXT UNIQUE,
    deleted_at TEXT
);

INSERT INTO clients_new (
    id, name, directory_name, company_name, contact_name,
    contact_email, pdf_password, preferences,
    archived_at, created_at, updated_at
)
SELECT
    id, name, directory_name, company_name, contact_name,
    contact_email, pdf_password, preferences,
    archived_at, created_at, updated_at
FROM clients;

DROP TABLE clients;
ALTER TABLE clients_new RENAME TO clients;

CREATE INDEX IF NOT EXISTS idx_clients_name ON clients (name);
CREATE INDEX IF NOT EXISTS idx_clients_directory ON clients (directory_name);
CREATE INDEX IF NOT EXISTS idx_clients_remote_uuid ON clients (remote_uuid);

-- =========================
-- Projects
-- =========================

CREATE TABLE projects_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    directory_name TEXT NOT NULL,
    archived_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remote_uuid TEXT UNIQUE,
    deleted_at TEXT,
    FOREIGN KEY (client_id) REFERENCES clients (id) ON DELETE CASCADE,
    UNIQUE(client_id, directory_name)
);

INSERT INTO projects_new (
    id, client_id, name, directory_name,
    archived_at, created_at, updated_at
)
SELECT
    id, client_id, name, directory_name,
    archived_at, created_at, updated_at
FROM projects;

DROP TABLE projects;
ALTER TABLE projects_new RENAME TO projects;

CREATE INDEX IF NOT EXISTS idx_projects_client_id ON projects (client_id);
CREATE INDEX IF NOT EXISTS idx_projects_directory ON projects (client_id, directory_name);
CREATE INDEX IF NOT EXISTS idx_projects_archived_at ON projects (archived_at);
CREATE INDEX IF NOT EXISTS idx_projects_remote_uuid ON projects (remote_uuid);

-- =========================
-- Sessions
-- =========================

CREATE TABLE sessions_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_seconds INTEGER,
    timer_mode TEXT,
    archived_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remote_uuid TEXT UNIQUE,
    updated_at TEXT,
    deleted_at TEXT,
    FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE
);

INSERT INTO sessions_new (
    id, project_id, name, start_time, end_time,
    duration_seconds, timer_mode, archived_at, created_at
)
SELECT
    id, project_id, name, start_time, end_time,
    duration_seconds, timer_mode, archived_at, created_at
FROM sessions;

DROP TABLE sessions;
ALTER TABLE sessions_new RENAME TO sessions;

CREATE INDEX IF NOT EXISTS idx_sessions_project_id ON sessions (project_id);
CREATE INDEX IF NOT EXISTS idx_sessions_start_time ON sessions (start_time);
CREATE INDEX IF NOT EXISTS idx_sessions_remote_uuid ON sessions (remote_uuid);
CREATE INDEX IF NOT EXISTS idx_sessions_updated_at ON sessions (updated_at);

-- =========================
-- Screenshots
-- =========================

CREATE TABLE screenshots_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    set_id INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    display_mode TEXT,
    suffix TEXT,
    archived_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remote_uuid TEXT UNIQUE,
    updated_at TEXT,
    deleted_at TEXT,
    FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE CASCADE
);

INSERT INTO screenshots_new (
    id, session_id, set_id, file_path, timestamp,
    display_mode, suffix, archived_at, created_at
)
SELECT
    id, session_id, set_id, file_path, timestamp,
    display_mode, suffix, archived_at, created_at
FROM screenshots;

DROP TABLE screenshots;
ALTER TABLE screenshots_new RENAME TO screenshots;

CREATE INDEX IF NOT EXISTS idx_screenshots_session_id ON screenshots (session_id);
CREATE INDEX IF NOT EXISTS idx_screenshots_timestamp ON screenshots (timestamp);
CREATE INDEX IF NOT EXISTS idx_screenshots_remote_uuid ON screenshots (remote_uuid);
CREATE INDEX IF NOT EXISTS idx_screenshots_updated_at ON screenshots (updated_at);

-- =========================
-- Notes
-- =========================

CREATE TABLE notes_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    note_type TEXT DEFAULT 'note',
    timestamp TIMESTAMP NOT NULL,
    archived_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    remote_uuid TEXT UNIQUE,
    updated_at TEXT,
    deleted_at TEXT,
    FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE CASCADE
);

INSERT INTO notes_new (
    id, session_id, content, note_type, timestamp,
    archived_at, created_at
)
SELECT
    id, session_id, content, note_type, timestamp,
    archived_at, created_at
FROM notes;

DROP TABLE notes;
ALTER TABLE notes_new RENAME TO notes;

CREATE INDEX IF NOT EXISTS idx_notes_session_id ON notes (session_id);
CREATE INDEX IF NOT EXISTS idx_notes_timestamp ON notes (timestamp);
CREATE INDEX IF NOT EXISTS idx_notes_remote_uuid ON notes (remote_uuid);
CREATE INDEX IF NOT EXISTS idx_notes_updated_at ON notes (updated_at);

PRAGMA foreign_keys = ON;

COMMIT;

-- Rollback:
-- Recreate tables without the sync columns and re-populate from current data.
-- Not provided inline due to complexity; restore from a backup instead.
