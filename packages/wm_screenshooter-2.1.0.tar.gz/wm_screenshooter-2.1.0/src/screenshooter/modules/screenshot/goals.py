"""Goal file helpers for the screenshot module."""

import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_logger = logging.getLogger(__name__)

GOALS_FILE_NAME = "goals.json"
GOALS_FILE_VERSION = 1


def _utc_iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass
class GoalNoteFileEntry:
    id: int
    goal_id: int
    content: str
    note_type: str
    timestamp: str
    archived_at: str | None = None
    local_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "local_id": self.local_id,
            "content": self.content,
            "note_type": self.note_type,
            "timestamp": self.timestamp,
            "archived_at": self.archived_at,
        }

    @classmethod
    def from_dict(cls, data: dict, goal_id: int, index: int) -> "GoalNoteFileEntry":
        return cls(
            id=index,
            goal_id=goal_id,
            content=data["content"],
            note_type=data.get("note_type", "progress"),
            timestamp=data["timestamp"],
            archived_at=data.get("archived_at"),
            local_id=data.get("local_id", str(uuid.uuid4())),
        )


@dataclass
class GoalFileEntry:
    id: int
    title: str
    description: str
    status: str
    notes: list[GoalNoteFileEntry] = field(default_factory=list)
    created_at: str = field(default_factory=_utc_iso_now)
    updated_at: str = field(default_factory=_utc_iso_now)
    completed_at: str | None = None
    archived_at: str | None = None
    local_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict:
        return {
            "local_id": self.local_id,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "completed_at": self.completed_at,
            "archived_at": self.archived_at,
            "notes": [n.to_dict() for n in self.notes],
        }

    @classmethod
    def from_dict(cls, data: dict, index: int) -> "GoalFileEntry":
        notes_raw = data.get("notes", [])
        notes = [
            GoalNoteFileEntry.from_dict(n, goal_id=index, index=i)
            for i, n in enumerate(notes_raw)
        ]
        return cls(
            id=index,
            title=data["title"],
            description=data.get("description", ""),
            status=data.get("status", "active"),
            notes=notes,
            created_at=data.get("created_at", _utc_iso_now()),
            updated_at=data.get("updated_at", _utc_iso_now()),
            completed_at=data.get("completed_at"),
            archived_at=data.get("archived_at"),
            local_id=data.get("local_id", str(uuid.uuid4())),
        )


class FileGoalsBackend:
    """Goals backend for log-file mode, backed by goals.json in the project directory."""

    def __init__(self, project_dir: Path) -> None:
        self._path = project_dir / GOALS_FILE_NAME

    def _load(self) -> list[GoalFileEntry]:
        if not self._path.exists():
            return []
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            return [
                GoalFileEntry.from_dict(g, index=i)
                for i, g in enumerate(data.get("goals", []))
            ]
        except Exception:
            _logger.debug("Failed to load %s", self._path, exc_info=True)
            return []

    def _save(self, goals: list[GoalFileEntry]) -> None:
        payload = json.dumps(
            {"version": GOALS_FILE_VERSION, "goals": [g.to_dict() for g in goals]},
            indent=2,
            ensure_ascii=False,
        )
        self._path.write_text(payload, encoding="utf-8")

    def list_active_project_goals(self, project_id: int) -> list[GoalFileEntry]:
        return [g for g in self._load() if g.status == "active"]

    def list_recent_closed_project_goals(
        self, project_id: int, limit: int = 5
    ) -> list[GoalFileEntry]:
        closed = [g for g in self._load() if g.status in ("completed", "archived")]
        return closed[-limit:]

    def list_project_goals(
        self, project_id: int, include_archived: bool = False
    ) -> list[GoalFileEntry]:
        goals = self._load()
        if not include_archived:
            goals = [g for g in goals if g.archived_at is None]
        return goals

    def list_project_goal_notes(
        self, goal_id: int, include_archived: bool = False
    ) -> list[GoalNoteFileEntry]:
        goals = self._load()
        if goal_id < 0 or goal_id >= len(goals):
            return []
        notes = goals[goal_id].notes
        if not include_archived:
            notes = [n for n in notes if n.archived_at is None]
        return notes

    def create_project_goal(self, goal: Any) -> int | None:
        goals = self._load()
        new_id = len(goals)
        entry = GoalFileEntry(
            id=new_id,
            title=goal.title,
            description=goal.description or "",
            status="active",
        )
        goals.append(entry)
        self._save(goals)
        return new_id

    def add_project_goal_note(self, note: Any) -> int | None:
        goals = self._load()
        goal_id = note.goal_id
        if goal_id < 0 or goal_id >= len(goals):
            return None
        now = _utc_iso_now()
        new_note = GoalNoteFileEntry(
            id=len(goals[goal_id].notes),
            goal_id=goal_id,
            content=note.content,
            note_type=str(note.note_type).split(".")[-1].lower() if note.note_type else "progress",
            timestamp=note.timestamp or now,
        )
        goals[goal_id].notes.append(new_note)
        goals[goal_id].updated_at = now
        self._save(goals)
        return new_note.id

    def complete_project_goal(
        self, goal_id: int, session_id: int | None, note: str | None = None
    ) -> bool:
        goals = self._load()
        if goal_id < 0 or goal_id >= len(goals):
            return False
        now = _utc_iso_now()
        goals[goal_id].status = "completed"
        goals[goal_id].completed_at = now
        goals[goal_id].updated_at = now
        if note:
            goals[goal_id].notes.append(
                GoalNoteFileEntry(
                    id=len(goals[goal_id].notes),
                    goal_id=goal_id,
                    content=note,
                    note_type="completion",
                    timestamp=now,
                )
            )
        self._save(goals)
        return True

    def archive_project_goal(
        self, goal_id: int, session_id: int | None, note: str | None = None
    ) -> bool:
        goals = self._load()
        if goal_id < 0 or goal_id >= len(goals):
            return False
        now = _utc_iso_now()
        goals[goal_id].status = "archived"
        goals[goal_id].archived_at = now
        goals[goal_id].updated_at = now
        if note:
            goals[goal_id].notes.append(
                GoalNoteFileEntry(
                    id=len(goals[goal_id].notes),
                    goal_id=goal_id,
                    content=note,
                    note_type="archive",
                    timestamp=now,
                )
            )
        self._save(goals)
        return True


def update_goals_json_from_db(project_dir: Path, db_ops: Any, project_id: int) -> None:
    """Rewrite goals.json from the database after a mutation.

    Keeps a human-readable, migration-importable snapshot alongside every DB write.
    Errors are silenced — this is a best-effort mirror, never load-bearing.
    """
    try:
        goals = db_ops.list_project_goals(project_id, include_archived=True)
        entries = []
        for goal in goals:
            notes_raw = db_ops.list_project_goal_notes(goal.id, include_archived=True)
            note_dicts = [
                {
                    "local_id": str(getattr(note, "remote_uuid", "") or uuid.uuid4()),
                    "content": note.content,
                    "note_type": str(note.note_type).split(".")[-1].lower(),
                    "timestamp": note.timestamp,
                    "archived_at": getattr(note, "archived_at", None),
                }
                for note in notes_raw
            ]
            entries.append(
                {
                    "local_id": str(getattr(goal, "remote_uuid", "") or uuid.uuid4()),
                    "title": goal.title,
                    "description": goal.description or "",
                    "status": str(goal.status).split(".")[-1].lower(),
                    "created_at": goal.created_at,
                    "updated_at": goal.updated_at,
                    "completed_at": goal.completed_at,
                    "archived_at": goal.archived_at,
                    "notes": note_dicts,
                }
            )
        payload = json.dumps(
            {"version": GOALS_FILE_VERSION, "goals": entries}, indent=2, ensure_ascii=False
        )
        (project_dir / GOALS_FILE_NAME).write_text(payload, encoding="utf-8")
    except Exception:
        _logger.debug("Failed to write goals.json for %s", project_dir, exc_info=True)
