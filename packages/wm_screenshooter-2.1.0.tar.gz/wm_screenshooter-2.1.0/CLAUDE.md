# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build/Lint/Test Commands

```bash
# Install dependencies
uv pip install -e .           # Production install
uv pip install -e ".[dev]"    # With dev dependencies

# Install as CLI tool
uv tool install .
screenshooter --version

# Format and lint
uv run ruff format src/
uv run ruff check src/

# Tests in this repo are exploratory/scaffolding only
# Do not run pytest unless explicitly requested by the user
# uv run pytest tests/
```

## Agent Validation Policy

- Ruff linting is explicitly allowed at the end of each coding pass.
- Preferred end-of-pass validation: `uv run ruff check src/`.
- Run `uv run ruff format src/` when formatting fixes are needed.
- Manual app testing (interactive/manual workflows) should be done by the user.
- Do not run manual/integration testing flows unless the user explicitly asks.
- Repository tests are exploratory and not part of production validation.
- Do not run `pytest` by default; use Ruff linting as the primary validation.
- Only run tests when the user explicitly asks.
- Never update `docs/CHANGELOG.md` unless the user explicitly requests it.
- Do not run uv ruff if only documentation or rules have been changed. Ruff passes are only meant for when code has actually been changed

## Code Style

- Python 3.10 - 3.14, use `uv` for package management
- Double quotes, 100 char line length, 4-space indentation
- Type hints required for all function parameters and return values
- Import order: stdlib → third-party → local
- Naming: Classes=PascalCase, functions=snake_case, constants=UPPERCASE_WITH_UNDERSCORES
- Google style docstrings
- Use specific exceptions in try/except, use logging module for errors
- Rich console formatting for UI; input prompts on new line prefixed with `>`

## Architecture

**Entry Point:** `src/screenshooter/main.py`

**Modules** (`src/screenshooter/modules/`):

- `clients/` - Client management, data models, CLI
- `screenshot/` - Screenshot capture, session management, timer
- `reports/` - PDF report generation and email delivery
- `database/` - SQLite storage, migrations, operations layer
- `s3/` - S3/R2 cloud storage integration
- `settings/` - Application settings models and manager
- `upgrade/` - Upgrade check engine and top-level upgrade CLI
- `backup/` - Backup creation, state tracking, and recovery prompts
- `sync/` - Workmaster sync (push/pull to remote D1 database via Workmaster API) and screenshot image upload to R2

Each module has `__init__.py` and may include `main.py` or `cli.py` for CLI entry points.

## Upgrade Command Structure

- Upgrade commands are top-level under `screenshooter upgrade`.
- Use: `check`, `status`, `channel`, `branch`, `settings`, `skip`, `pin`, `unpin`, `help`.
- Do not add upgrade commands back under `screenshooter settings`.
- Persisted upgrade settings remain in `AppSettings.upgrade_check`.

## Interactive Screenshot Notes

- Snippet capture command is `w` in screenshot sessions.
- Snippet flow is countdown first, then region selection, then capture via `mss` region grab.
- Qt selector implementation is in `src/screenshooter/modules/screenshot/qt_region_selector.py`.
- On macOS, Qt selector runs in a subprocess to isolate Qt lifecycle from terminal input handling.
- On Windows, Qt selector runs in-process and remaps Qt coordinates into `mss` coordinates to avoid DPI
  scaling mismatch in snippet captures.
- `PySide6-Essentials` is optional and provided through the `snippet-gui` extra in `pyproject.toml`.
- If `snippet-gui` is not installed, snippet capture is disabled and should show install guidance.
- Linux Qt snippet drag-selection has not been fully tested yet.
- Terminal raw-mode safety is centralized in `src/screenshooter/modules/screenshot/utils.py`.
- If editing raw key handling, always restore cooked mode in `finally` and use
  `ensure_terminal_cooked_mode()` before blocking input/menu prompts.

## Database Guidelines

SQLite database at `~/.config/screenshooter/screenshooter.db` stores clients, projects, sessions, screenshots, and notes.

- **Always use `DatabaseOperations`** for CRUD - never raw SQL directly
- **Dual logging**: File-based logs remain authoritative; DB writes are supplementary
- **Note types**: Use `DatabaseNoteType` enum (NOTE, CAPTION, SESSION_START, SESSION_END) - no separate caption table
- **Schema changes**: Use versioned migrations in `versions/` directory, not direct DB modifications
- Migration files: `XXX_descriptive_name.sql` with transaction wrapping and rollback sections
- Startup initialization applies pending schema migrations automatically. If an existing database has pending migrations, the app prompts first, creates a timestamped raw SQLite backup under `~/.config/screenshooter/db_migration_backups/`, and exits without applying migrations if the user declines.
- Manual direct DB backups are available through `screenshooter db backup` and the `screenshooter db` interactive menu. These create raw `.db` copies and are separate from ZIP-based `screenshooter backup db`.

### Sync Columns

All 5 data tables carry sync columns added in migration 004: `remote_uuid TEXT UNIQUE`, `deleted_at TEXT`, and (for sessions/screenshots/notes) `updated_at TEXT`. These are owned by the `sync/` module — do not write to them in non-sync feature code, except that `archive_*` / `unarchive_*` methods in `operations.py` set/clear `deleted_at` alongside `archived_at`.

## Workmaster Sync Guidelines

The `sync/` module syncs local data to the remote Workmaster D1 database using a `remote_uuid` pattern — integer PKs are never changed.

- **Entry point**: `SyncManager(settings).sync()` — always go through the manager, not push/pull directly
- **Sync cycle order**: push metadata → pull remote changes → upload images (if `upload_images` is enabled)
- **`remote_uuid`**: Generated at record creation time in every `create_*` method; never modified after creation
- **`deleted_at`**: Set alongside `archived_at` on every archive operation; cleared alongside it on unarchive
- **`updated_at`** (sessions/screenshots/notes): ISO 8601 UTC string via `_utc_iso()`; updated on every mutation
- **SyncSettings** in `AppSettings`: `enabled`, `server_url`, `device_id` (auto-generated), `clerk_auth_token`, `upload_images`
- **Never store `user_id` locally** — injected by the Workmaster server from the Clerk session
- See `sync-module.mdc` and `image-upload.mdc` for full constraints

### Image Upload

- Controlled by `SyncSettings.upload_images` (opt-in, default `False`). Enable via `screenshooter sync setup` or `screenshooter sync set --upload-images`.
- Implemented in `sync/image_uploader.py` using the Workmaster prepare → R2 PUT → complete flow.
- Local upload state tracked in `~/.config/screenshooter/image_upload_cache.json` (keyed by `remote_uuid`).
- States: `not_uploaded`, `complete`, `failed_retryable`, `failed_permanent`.
- **Never** add `r2_key`, `r2_prefix`, or `upload_status` to the local DB — they are server-owned fields.
- **Never** include those fields in `/sync/push` payloads.
- Image dimensions are read from file headers using stdlib `struct` — no PIL/Pillow required.
- A Rich progress bar (`MofNCompleteColumn`) is shown during `screenshooter sync run` (not auto-sync, not debug mode).
- `SyncResult` gains `images_uploaded` and `images_failed` fields populated after the upload phase.

## Backup + S3 Guidelines

- Backup remote upload config is part of `backup` settings (`upload_to_s3_enabled`,
  `s3_bucket_name`, `s3_path_prefix`), with bucket fallback to main S3 bucket when override is blank.
- S3/R2 upload concurrency is shared through `S3Settings.upload_workers` (default `8`, clamped to `1..32`); report uploads use `S3Helper`/boto3 managed transfer config, while backup uploads use the same worker setting inside the custom resumable multipart state machine. Backup Settings and Email/Report Settings may expose this as a borrowed control, but they must still read/write `settings.s3.upload_workers`.
- `BackupSettings.notify_frequency` controls how often (in days) the user is reminded to back up
  on startup (`0` disables reminders entirely; default is `7`).
- If backup S3 upload is enabled, backup password protection is required.
- `screenshooter backup db` uses the ZIP backup flow/settings. `screenshooter db backup` creates a direct timestamped SQLite `.db` copy in `~/.config/screenshooter/db_migration_backups/` and does not use the backup ZIP/S3 state machine.
- A unified backup state file `~/.config/screenshooter/backup_state.json` tracks the full
  lifecycle: `stage` progresses from `zip` (compression) to `upload` (S3 multipart), with
  `status` of `in_progress` or `paused`. The file is only cleared on clean completion.
- A separate `~/.config/screenshooter/backup_cache.json` tracks backup reminder state:
  `last_backup_at`, `last_backup_type`, `last_backup_zip_path`, `last_backup_scope`,
  and `next_reminder_at`. Created automatically on first run and updated on every clean completion.
- On every invocation, before the upgrade check, the startup handler detects any interrupted
  or paused backup state and offers interactive Dismiss / Retry / Resume / View log options.
- After the upgrade check, a backup reminder prompt appears if due: `[D] Do Not Show Again`,
  `[R] Remind in N days`, `[B] Backup Now`.
- Backup operational logs are written to `~/.config/screenshooter/logs/backup.log` (also mirrored to
  `screenshooter.log`); S3 backup upload events are mirrored to `s3_helper.log`.

## User Data Structure

Screenshots and client data stored at `~/WorkMaster_Screenshooter/`:

```directory
~/WorkMaster_Screenshooter/
└── CLIENT_NAME/
    ├── client.json
    └── PROJECT_NAME/
        ├── project.json
        ├── PROJECT_NAME_log.txt
        ├── reports/
        └── sessions/YYYY-MM-DD_HH-MM-SS/
            ├── session.json
            ├── session.log
            └── screenshots/
                └── PROJECT_NAME_YYYY-MM-DD_HH-MM-SS_*.jpg
```

## Cursor Rules Reference

Additional module-specific guidelines exist in `.cursor/rules/`:

- `database-module.mdc` - SQLite integration, schema, operations layer
- `database-migrations.mdc` - Versioned migration system
- `sync-module.mdc` - Workmaster sync architecture, remote_uuid pattern, push/pull rules
- `image-upload.mdc` - Screenshot image upload to Workmaster R2 (prepare/PUT/complete flow, local state, progress bar)
- `clients-module.mdc`, `reports-module.mdc`, `s3-module.mdc`, `screenshot-module.mdc`,
  `settings-module.mdc`, `upgrade-module.mdc`, `backup-module.mdc`
