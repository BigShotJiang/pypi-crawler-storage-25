# Database Structure

The SQLite database is created at runtime at `~/.config/screenshooter/screenshooter.db`.

There are **9 tables** — 7 data tables, 1 sync state table, and 1 internal migration tracking table.

---

## `clients`

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| name | TEXT | NOT NULL UNIQUE |
| directory_name | TEXT | NOT NULL UNIQUE |
| company_name | TEXT | DEFAULT '' |
| contact_name | TEXT | DEFAULT '' |
| contact_email | TEXT | DEFAULT '' |
| pdf_password | TEXT | DEFAULT '' |
| preferences | TEXT | DEFAULT '{}' |
| archived_at | TIMESTAMP | nullable |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| updated_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| remote_uuid | TEXT | UNIQUE, nullable — sync identity |
| deleted_at | TEXT | nullable — ISO 8601 sync tombstone |

Indexes: `idx_clients_name`, `idx_clients_directory`, `idx_clients_remote_uuid`

---

## `projects`

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| client_id | INTEGER | NOT NULL → clients(id) ON DELETE CASCADE |
| name | TEXT | NOT NULL |
| directory_name | TEXT | NOT NULL |
| archived_at | TIMESTAMP | nullable |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| updated_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| remote_uuid | TEXT | UNIQUE, nullable — sync identity |
| deleted_at | TEXT | nullable — ISO 8601 sync tombstone |

Constraints: `UNIQUE(client_id, directory_name)`

Indexes: `idx_projects_client_id`, `idx_projects_directory`, `idx_projects_archived_at`, `idx_projects_remote_uuid`

---

## `sessions`

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| project_id | INTEGER | NOT NULL → projects(id) ON DELETE CASCADE |
| name | TEXT | NOT NULL |
| start_time | TIMESTAMP | NOT NULL |
| end_time | TIMESTAMP | nullable |
| duration_seconds | INTEGER | nullable |
| timer_mode | TEXT | nullable |
| archived_at | TIMESTAMP | nullable |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| remote_uuid | TEXT | UNIQUE, nullable — sync identity |
| updated_at | TEXT | nullable — ISO 8601 UTC, set on every mutation |
| deleted_at | TEXT | nullable — ISO 8601 sync tombstone |

Indexes: `idx_sessions_project_id`, `idx_sessions_start_time`, `idx_sessions_remote_uuid`, `idx_sessions_updated_at`

---

## `screenshots`

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| session_id | INTEGER | NOT NULL → sessions(id) ON DELETE CASCADE |
| set_id | INTEGER | NOT NULL |
| file_path | TEXT | NOT NULL |
| timestamp | TIMESTAMP | NOT NULL |
| display_mode | TEXT | nullable |
| suffix | TEXT | nullable |
| archived_at | TIMESTAMP | nullable |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| remote_uuid | TEXT | UNIQUE, nullable — sync identity |
| updated_at | TEXT | nullable — ISO 8601 UTC, set on every mutation |
| deleted_at | TEXT | nullable — ISO 8601 sync tombstone |

Indexes: `idx_screenshots_session_id`, `idx_screenshots_timestamp`, `idx_screenshots_remote_uuid`, `idx_screenshots_updated_at`

---

## `notes`

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| session_id | INTEGER | NOT NULL → sessions(id) ON DELETE CASCADE |
| content | TEXT | NOT NULL |
| note_type | TEXT | DEFAULT 'note' |
| timestamp | TIMESTAMP | NOT NULL |
| archived_at | TIMESTAMP | nullable |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| remote_uuid | TEXT | UNIQUE, nullable — sync identity |
| updated_at | TEXT | nullable — ISO 8601 UTC, set on every mutation |
| deleted_at | TEXT | nullable — ISO 8601 sync tombstone |

`note_type` values: `note`, `caption`, `session_start`, `session_end`, `pause`, `resume`

Indexes: `idx_notes_session_id`, `idx_notes_timestamp`, `idx_notes_remote_uuid`, `idx_notes_updated_at`

---

## `project_goals`

Project-wide goals that persist across screenshot sessions.

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| project_id | INTEGER | NOT NULL → projects(id) ON DELETE CASCADE |
| title | TEXT | NOT NULL |
| description | TEXT | DEFAULT '' |
| status | TEXT | NOT NULL DEFAULT 'active' |
| created_session_id | INTEGER | nullable → sessions(id) ON DELETE SET NULL |
| closed_session_id | INTEGER | nullable → sessions(id) ON DELETE SET NULL |
| created_at | TEXT | DEFAULT strftime ISO 8601 UTC |
| updated_at | TEXT | DEFAULT strftime ISO 8601 UTC, set on every mutation |
| completed_at | TEXT | nullable |
| archived_at | TEXT | nullable |
| remote_uuid | TEXT | UNIQUE, nullable — future sync identity |
| deleted_at | TEXT | nullable — future sync tombstone |

`status` values: `active`, `completed`, `archived`

Indexes: `idx_project_goals_project_id`, `idx_project_goals_status`, `idx_project_goals_updated_at`, `idx_project_goals_remote_uuid`

---

## `project_goal_notes`

Progress, completion, and archive notes attached to project goals.

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| goal_id | INTEGER | NOT NULL → project_goals(id) ON DELETE CASCADE |
| session_id | INTEGER | nullable → sessions(id) ON DELETE SET NULL |
| content | TEXT | NOT NULL |
| note_type | TEXT | NOT NULL DEFAULT 'progress' |
| timestamp | TEXT | NOT NULL |
| created_at | TEXT | DEFAULT strftime ISO 8601 UTC |
| updated_at | TEXT | DEFAULT strftime ISO 8601 UTC, set on every mutation |
| archived_at | TEXT | nullable |
| remote_uuid | TEXT | UNIQUE, nullable — future sync identity |
| deleted_at | TEXT | nullable — future sync tombstone |

`note_type` values: `progress`, `completion`, `archive`

Indexes: `idx_project_goal_notes_goal_id`, `idx_project_goal_notes_session_id`, `idx_project_goal_notes_timestamp`, `idx_project_goal_notes_remote_uuid`

---

## `sync_state`

Tracks the last successful push and pull checkpoint per Workmaster server and device pair.

| Column | Type | Constraints |
| --- | --- | --- |
| id | INTEGER | PK AUTOINCREMENT |
| server_url | TEXT | NOT NULL |
| device_id | TEXT | NOT NULL |
| last_push | TEXT | nullable — ISO 8601 UTC |
| last_pull | TEXT | nullable — ISO 8601 UTC |
| created_at | TEXT | DEFAULT strftime ISO 8601 UTC |
| updated_at | TEXT | DEFAULT strftime ISO 8601 UTC |

Constraints: `UNIQUE(server_url, device_id)`

---

## `schema_migrations` (internal)

| Column | Type | Constraints |
| --- | --- | --- |
| version | INTEGER | PK |
| filename | TEXT | NOT NULL UNIQUE |
| applied_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP |
| checksum | TEXT | NOT NULL |

---

## Key Design Notes

- **Soft deletes**: nullable `archived_at` on data tables that support archiving. NULL = active, non-NULL = archived timestamp.
- **Cascading deletes**: `clients → projects → sessions → screenshots/notes` (all foreign keys use `ON DELETE CASCADE`).
- **`preferences`** on `clients` stores JSON serialized as TEXT.
- **Captions** live in the `notes` table with `note_type = 'caption'` and a `[set #N]` prefix in content.
- **`updated_at`** format differs by table age:
  - `clients` and `projects`: `TIMESTAMP DEFAULT CURRENT_TIMESTAMP` (YYYY-MM-DD HH:MM:SS, pre-existing column).
  - `sessions`, `screenshots`, `notes`: `TEXT` ISO 8601 UTC with milliseconds (added in migration 004, written by `_utc_iso()` in `operations.py`).
- **Sync columns** (`remote_uuid`, `deleted_at`, new `updated_at`) were added to the original sync tables in migration 004 and are managed exclusively by `src/screenshooter/modules/sync/`. Goal tables include matching future sync identity/tombstone columns, but Workmaster goal sync is not implemented yet.
- **`deleted_at`** mirrors `archived_at` semantics for the remote system: set alongside `archived_at` on archive, cleared alongside it on unarchive.
- **Migrations** are versioned SQL files in `src/screenshooter/modules/database/versions/` tracked by the `schema_migrations` table.
  - 001: initial schema
  - 002: active boolean columns
  - 003: archived_at soft-delete columns
  - 004: sync columns (remote_uuid, deleted_at, updated_at)
  - 005: sync_state table
  - 006: project_goals and project_goal_notes
- **Startup migration safety**: existing databases with pending schema migrations trigger a prompt before changes are applied. Choosing yes creates a timestamped raw SQLite backup first; choosing no exits without applying migrations.
- **Direct DB backups**: `screenshooter db backup` and the database interactive menu create raw timestamped `.db` copies under `~/.config/screenshooter/db_migration_backups/`, independent of pending migrations and separate from ZIP backups.
