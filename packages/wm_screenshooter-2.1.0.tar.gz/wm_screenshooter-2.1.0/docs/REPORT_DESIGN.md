# Report Design

This note defines the visual rules for generated PDF reports.

## Tables

All report tables must use the shared helpers in `src/screenshooter/modules/reports/pdf/tables.py`. Do not add one-off `TableStyle` blocks for normal report tables.

Tables use a dark grey header row with white bold text, white body rows, grey grid lines, 10pt Helvetica body text, 10pt Helvetica-Bold headers, 6pt top and bottom padding, and 4pt left and right padding.

Key/value data should still be presented as a two-column table with a real header row, not as a shaded first column. Client info, session summaries, report summaries, and project goals should all follow this system.

## Day Dividers

Day dividers render as normal section headers. Each day section must start on a new PDF page.

## Notes

Notes, captions, session-start notes, and goal updates render as event tables using the shared report table design. The header row has the event type in the first column and the event timestamp in the second column. The body row spans the full table width and contains the note, caption, or goal-update text.

Session-start notes render as normal `Note` event tables. Do not reintroduce a standalone `Session Note:` or `Session note` label.

Goal updates remain chronological timeline events. A goal update table has `Goal Update` and the timestamp in the first header row, then a full-width dark header row reading `Goal Update: <goal name>`, then the update text in the body row.

Single-session reports should include a `Session: ...` subsection header before timeline content, matching the session headers used in day and project reports.

The project goals summary table remains a single top-level overview table. When it appears, add a page break after it before rendering session or day timeline content. Log-file fallback reports should omit goal sections when no goal source exists.

## Page Chrome

All generated PDF reports use a shared header and footer. The header shows the report title, and the footer includes the page number in `Page X of Y` format.
