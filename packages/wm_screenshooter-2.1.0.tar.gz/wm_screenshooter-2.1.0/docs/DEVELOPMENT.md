# DEVELOPMENT

Developer guidance for working on ScreenShooter during active feature development.

## Branch and Release Flow

- `main` is the stable branch.
- Stable versions are tagged releases (for example, `v1.0.9`, `v1.0.10`).
- You can keep separate dev branches per version (for example, `v1.0.10` or `dev/v1.0.10`).
- Do not tag every commit. Tag only stable release points.
- External contributors should work from forks and submit merge requests from their fork branches rather than being given direct push access to the main repository.

## Versioning with `setuptools-scm`

ScreenShooter uses SCM-derived package versions so dev builds are uniquely identifiable by commit.

- Stable tagged commit example: `1.0.10`
- Dev commit example: `1.0.11.devN+g<sha>`
- Branch names do not change the package version by themselves.
- A branch named `v1.0.12` still reports a dev build until `main` is tagged `v1.0.12`.

This prevents ambiguity when a local/dev install is ahead of the latest public release tag.

For local checkout workflows, runtime version reporting prefers the imported checkout's git state over
arbitrary installed metadata. This prevents stale editable installs from another clone from
misreporting `screenshooter --version` or influencing upgrade checks.

## Upgrade Check Channels

Upgrade checks support two channels:

- `release`: checks GitLab releases (stable/public release path).
- `dev`: checks branch head commit for the configured dev branch.
  - Dev channel intentionally checks upstream on every run (no cache reads).
  - The GitLab project target is the official `workmaster/screenshooter` repository.
  - For local checkout workflows (`uv run screenshooter`), the current commit comes from local git
    `HEAD` first, then falls back to package version metadata if git is unavailable.
  - Dev checks are commit-based, not release-version-based. They report whether local checkout is
    behind, identical to, ahead of, or diverged from the tracked GitLab branch.
  - Version pinning is for the `release` channel and is not meaningful for active dev work.

On first startup of a detected development build, ScreenShooter prompts once to switch upgrade checks
to the `dev` channel and suggests a version branch (for example `v1.0.10`).

### Commands

```bash
screenshooter upgrade check
screenshooter upgrade status
screenshooter upgrade channel <release|dev>
screenshooter upgrade branch <branch-name>
screenshooter upgrade settings --enable --frequency 7
screenshooter upgrade skip <version>
screenshooter upgrade pin <version>
screenshooter upgrade unpin
```

## Recommended Daily Workflow

1. Create or switch to your target dev branch (for example, `v1.0.10`).
2. Keep channel on `dev` while actively developing:
   - `screenshooter upgrade channel dev`
   - `screenshooter upgrade branch v1.0.10`
3. Use `release` channel when validating stable/public updates:
   - `screenshooter upgrade channel release`

## Dev Branch Logic

- `upgrade branch` matters only on the `dev` channel. It defines which GitLab branch is treated as
  the upstream branch for commit comparison.
- Use `release` for stable/public installs and `dev` for active development.
- When developing on a feature branch, point `upgrade branch` at the shared upstream branch you are
  targeting, usually the release-prep branch such as `v1.0.12`.
- For contributors working from forks, `upgrade branch` still refers to the official upstream branch on `workmaster/screenshooter`, not the contributor's fork branch.
- If your feature branch already contains the tracked branch head commit, the dev checker should
  report no update. In that case your local branch will usually be reported as `ahead`.
- If the tracked branch moves ahead of your local checkout, the dev checker should report an update.
- `pin_version` and `skip_version` are release-channel concepts and should generally be ignored while
  actively developing on the `dev` channel.
- If you move from one release line to another, update the tracked dev branch explicitly, for
  example from `v1.0.10` to `v1.0.12`.

## Contribution Policy

- Contributor development should be fork-first by default.
- Merge requests should come from contributor forks unless you intentionally grant direct branch access to a trusted maintainer.
- The upgrade checker is not designed to track arbitrary contributor forks; it tracks the official upstream GitLab project and a configured upstream branch within that project.

## Validation Checklist

- Confirm version metadata is SCM-derived:
  - `uv run screenshooter --version`
- Confirm release channel behavior:
  - `uv run screenshooter upgrade channel release`
  - `uv run screenshooter upgrade check`
- Confirm dev branch behavior:
  - `uv run screenshooter upgrade channel dev`
  - `uv run screenshooter upgrade branch <branch-name>`
  - `uv run screenshooter upgrade check`
  - Confirm a feature branch that already contains the tracked branch head reports no update
  - Confirm a checkout missing newer tracked-branch commits reports an update
