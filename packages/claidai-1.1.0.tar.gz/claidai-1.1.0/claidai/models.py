from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import requests


@dataclass
class ImageMeta:
    width: int
    height: int
    format: str
    megapixels: float
    mime: str

    def __str__(self) -> str:
        return f"{self.width}×{self.height} {self.format} ({self.megapixels} MP)"


@dataclass
class EditResult:
    input_meta: ImageMeta
    output_meta: ImageMeta
    tmp_url: Optional[str] = field(default=None, repr=False)

    def save(self, path: str | Path) -> Path:
        """Download the processed image and save it to path."""
        if not self.tmp_url:
            raise ValueError("No output URL available.")
        dest = Path(path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        resp = requests.get(self.tmp_url, timeout=60)
        resp.raise_for_status()
        dest.write_bytes(resp.content)
        return dest

    def __str__(self) -> str:
        return f"EditResult: {self.input_meta} → {self.output_meta}"


def _parse_result(data: dict) -> EditResult:
    def _meta(d: dict) -> ImageMeta:
        return ImageMeta(
            width=d["width"],
            height=d["height"],
            format=d["format"],
            megapixels=d["mps"],
            mime=d.get("mime", ""),
        )
    return EditResult(
        input_meta=_meta(data["input"]),
        output_meta=_meta(data["output"]),
        tmp_url=data["output"].get("tmp_url"),
    )