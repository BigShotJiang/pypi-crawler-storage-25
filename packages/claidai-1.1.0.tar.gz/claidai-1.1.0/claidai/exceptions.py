class ClaidError(Exception):
    """Base exception for all Claid API errors."""

class ClaidAuthError(ClaidError):
    """Invalid or missing API key."""

class ClaidNoCreditsError(ClaidError):
    """Account has run out of API credits."""

class ClaidRateLimitError(ClaidError):
    """Too many requests — rate limit hit."""

class ClaidValidationError(ClaidError):
    """Bad request payload (422)."""

class ClaidFileError(ClaidError):
    """Local file not found or unreadable."""