import os
import sys
from pathlib import Path

import click

from claidai import Claid
from claidai.exceptions import ClaidError


def _get_key(ctx_key: str | None) -> str:
    key = ctx_key or os.environ.get("CLAID_API_KEY", "")
    if not key:
        click.echo(
            click.style("✖  API key missing.", fg="red", bold=True) + "\n"
            "   Pass --api-key OR set environment variable:\n"
            "   export CLAID_API_KEY=your_key_here",
            err=True,
        )
        sys.exit(1)
    return key


def _default_output(input_path: str, suffix: str) -> str:
    p = Path(input_path)
    return str(p.parent / f"{p.stem}_{suffix}{p.suffix}")


def _run(result, output: str):
    saved = result.save(output)
    inp = result.input_meta
    out = result.output_meta
    click.echo(
        click.style("✔  Done!", fg="green", bold=True)
        + f"  {inp.width}×{inp.height} → {out.width}×{out.height} {out.format}"
    )
    click.echo(f"   Saved → {click.style(str(saved.resolve()), fg='cyan')}")


@click.group()
@click.version_option(package_name="claidai")
def cli():
    """claidai — AI-powered image editing via Claid.ai API."""


@cli.command("remove-bg")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output",   default=None)
@click.option("--category",       default="products", show_default=True,
              type=click.Choice(["products", "general", "cars"]))
@click.option("--bg-color",       default="transparent", show_default=True)
@click.option("--no-clipping",    is_flag=True, default=False)
@click.option("--format",         default="png", show_default=True,
              type=click.Choice(["png", "jpeg", "webp", "avif"]))
@click.option("--api-key",        default=None, envvar="CLAID_API_KEY")
def remove_bg(image, output, category, bg_color, no_clipping, format, api_key):
    """Remove the background from an image."""
    output = output or _default_output(image, "nobg")
    try:
        result = Claid(_get_key(api_key)).remove_bg(
            image, category=category, bg_color=bg_color,
            clipping=not no_clipping, output_format=format,
        )
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("upscale")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output",  default=None)
@click.option("--scale",         default="200%", show_default=True)
@click.option("--method",        default="smart_enhance", show_default=True,
              type=click.Choice(["smart_enhance", "smart_resize", "photo", "faces", "digital_art"]))
@click.option("--format",        default="jpeg", show_default=True,
              type=click.Choice(["jpeg", "png", "webp"]))
@click.option("--api-key",       default=None, envvar="CLAID_API_KEY")
def upscale(image, output, scale, method, format, api_key):
    """AI-powered image upscaling."""
    output = output or _default_output(image, f"upscaled_{scale.replace('%','p')}")
    try:
        result = Claid(_get_key(api_key)).upscale(image, scale=scale, method=method, output_format=format)
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("blur-bg")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output",  default=None)
@click.option("--type", "blur_type", default="lens", show_default=True,
              type=click.Choice(["regular", "lens"]))
@click.option("--level",             default="medium", show_default=True,
              type=click.Choice(["low", "medium", "high"]))
@click.option("--category",          default="general", show_default=True,
              type=click.Choice(["general", "products", "cars"]))
@click.option("--format",            default="jpeg", show_default=True,
              type=click.Choice(["jpeg", "png", "webp"]))
@click.option("--api-key",           default=None, envvar="CLAID_API_KEY")
def blur_bg(image, output, blur_type, level, category, format, api_key):
    """Blur the background while keeping the subject sharp."""
    output = output or _default_output(image, "blurbg")
    try:
        result = Claid(_get_key(api_key)).blur_bg(
            image, blur_type=blur_type, level=level, category=category, output_format=format
        )
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("enhance")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output",   default=None)
@click.option("--hdr",            default=0, type=click.IntRange(0, 100),    show_default=True)
@click.option("--exposure",       default=0, type=click.IntRange(-100, 100), show_default=True)
@click.option("--saturation",     default=0, type=click.IntRange(-100, 100), show_default=True)
@click.option("--contrast",       default=0, type=click.IntRange(-100, 100), show_default=True)
@click.option("--sharpness",      default=0, type=click.IntRange(0, 100),    show_default=True)
@click.option("--format",         default="jpeg", show_default=True,
              type=click.Choice(["jpeg", "png", "webp"]))
@click.option("--api-key",        default=None, envvar="CLAID_API_KEY")
def enhance(image, output, hdr, exposure, saturation, contrast, sharpness, format, api_key):
    """Adjust colour, light, and sharpness."""
    output = output or _default_output(image, "enhanced")
    try:
        result = Claid(_get_key(api_key)).enhance(
            image, hdr=hdr, exposure=exposure, saturation=saturation,
            contrast=contrast, sharpness=sharpness, output_format=format,
        )
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("resize")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output", default=None)
@click.option("--width",  required=True)
@click.option("--height", default=None)
@click.option("--fit",    default="crop", show_default=True,
              type=click.Choice(["crop", "bounds", "cover", "canvas", "outpaint"]))
@click.option("--smart",  is_flag=True, default=False)
@click.option("--format", default="jpeg", show_default=True,
              type=click.Choice(["jpeg", "png", "webp"]))
@click.option("--api-key", default=None, envvar="CLAID_API_KEY")
def resize(image, output, width, height, fit, smart, format, api_key):
    """Resize an image to specific dimensions."""
    output = output or _default_output(image, "resized")
    w = int(width)  if width.isdigit()               else width
    h = int(height) if height and height.isdigit()   else height
    try:
        result = Claid(_get_key(api_key)).resize(
            image, width=w, height=h, fit=fit, smart=smart, output_format=format
        )
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("polish")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output",  default=None)
@click.option("--decompress",    default="auto", show_default=True,
              type=click.Choice(["auto", "moderate", "strong"]))
@click.option("--format",        default="jpeg", show_default=True,
              type=click.Choice(["jpeg", "png", "webp"]))
@click.option("--api-key",       default=None, envvar="CLAID_API_KEY")
def polish(image, output, decompress, format, api_key):
    """Sharpen details and remove JPEG artefacts."""
    output = output or _default_output(image, "polished")
    try:
        result = Claid(_get_key(api_key)).polish(image, decompress=decompress, output_format=format)
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("outpaint")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output",   default=None)
@click.option("--width",          default="150%", show_default=True)
@click.option("--height",         default="100%", show_default=True)
@click.option("--feathering",     default="20%",  show_default=True)
@click.option("--format",         default="jpeg", show_default=True,
              type=click.Choice(["jpeg", "png", "webp"]))
@click.option("--api-key",        default=None, envvar="CLAID_API_KEY")
def outpaint(image, output, width, height, feathering, format, api_key):
    """Expand canvas with AI-generated background."""
    output = output or _default_output(image, "outpaint")
    try:
        result = Claid(_get_key(api_key)).outpaint(
            image, width=width, height=height, feathering=feathering, output_format=format
        )
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("convert")
@click.argument("image", type=click.Path(exists=True))
@click.option("-o", "--output", default=None)
@click.option("--format", required=True,
              type=click.Choice(["jpeg", "png", "webp", "avif", "tiff"]))
@click.option("--quality", default=85, show_default=True, type=click.IntRange(1, 100))
@click.option("--api-key", default=None, envvar="CLAID_API_KEY")
def convert(image, output, format, quality, api_key):
    """Convert an image to a different format."""
    p = Path(image)
    output = output or str(p.parent / f"{p.stem}.{format}")
    try:
        result = Claid(_get_key(api_key)).convert(image, output_format=format, quality=quality)
        _run(result, output)
    except ClaidError as e:
        click.echo(click.style(f"✖  {e}", fg="red"), err=True); sys.exit(1)


@cli.command("batch")
@click.argument("input_folder",  type=click.Path(exists=True))
@click.argument("output_folder")
@click.option("--operation", required=True,
              type=click.Choice(["remove-bg", "upscale", "blur-bg", "enhance", "polish", "convert"]))
@click.option("--format",    default="jpeg", show_default=True,
              type=click.Choice(["jpeg", "png", "webp", "avif"]))
@click.option("--recursive",     is_flag=True, default=False)
@click.option("--workers",       default=3, show_default=True, type=click.IntRange(1, 4))
@click.option("--skip-existing", is_flag=True, default=False)
@click.option("--scale",         default="200%",          help="[upscale] Scale factor.")
@click.option("--method",        default="smart_enhance", help="[upscale] AI model.")
@click.option("--category",      default="products",      help="[remove-bg/blur-bg] Subject category.")
@click.option("--bg-color",      default="transparent",   help="[remove-bg] Background colour.")
@click.option("--blur-type",     default="lens",          help="[blur-bg] regular or lens.")
@click.option("--level",         default="medium",        help="[blur-bg] low/medium/high.")
@click.option("--hdr",           default=80, type=int,    help="[enhance] HDR (0-100).")
@click.option("--sharpness",     default=40, type=int,    help="[enhance] Sharpness (0-100).")
@click.option("--decompress",    default="auto",          help="[polish] auto/moderate/strong.")
@click.option("--api-key",       default=None, envvar="CLAID_API_KEY")
def batch(input_folder, output_folder, operation, format, recursive, workers, skip_existing,
          scale, method, category, bg_color, blur_type, level, hdr, sharpness, decompress, api_key):
    """Process ALL images in a folder with one operation."""
    from claidai.batch import process_folder

    c = Claid(_get_key(api_key))

    op_map = {
        "remove-bg": (c.remove_bg, {"category": category, "bg_color": bg_color}),
        "upscale":   (c.upscale,   {"scale": scale, "method": method}),
        "blur-bg":   (c.blur_bg,   {"blur_type": blur_type, "level": level, "category": category}),
        "enhance":   (c.enhance,   {"hdr": hdr, "sharpness": sharpness}),
        "polish":    (c.polish,    {"decompress": decompress}),
        "convert":   (c.convert,   {}),
    }

    op_fn, op_kwargs = op_map[operation]

    src     = Path(input_folder)
    pattern = "**/*" if recursive else "*"
    exts    = {".jpg", ".jpeg", ".png", ".webp", ".avif", ".bmp", ".tiff"}
    files   = [f for f in src.glob(pattern) if f.is_file() and f.suffix.lower() in exts]

    if not files:
        click.echo(click.style("⚠  No images found in folder.", fg="yellow"))
        return

    click.echo(
        f"\n{click.style('🚀 Batch processing', bold=True, fg='cyan')}  "
        f"{len(files)} images  ·  operation: {click.style(operation, fg='yellow')}  "
        f"·  workers: {workers}\n"
        f"  Input  → {click.style(str(Path(input_folder).resolve()), fg='white')}\n"
        f"  Output → {click.style(str(Path(output_folder).resolve()), fg='white')}\n"
    )

    def on_progress(done: int, total: int, filepath: Path):
        bar_len = 30
        filled  = int(bar_len * done / total)
        bar     = "█" * filled + "░" * (bar_len - filled)
        pct     = int(100 * done / total)
        click.echo(f"\r  [{bar}] {pct:3d}%  {done}/{total}  {filepath.name[:30]:<30}", nl=False)

    try:
        result = process_folder(
            c, input_folder, output_folder,
            operation=op_fn,
            operation_kwargs=op_kwargs,
            recursive=recursive,
            workers=workers,
            skip_existing=skip_existing,
            output_format=format,
            on_progress=on_progress,
        )
    except ClaidError as e:
        click.echo(click.style(f"\n✖  {e}", fg="red"), err=True); sys.exit(1)

    click.echo(
        f"\n\n  {click.style('✔  Done!', fg='green', bold=True)}  "
        f"{result.success_count}/{result.total} succeeded"
    )
    if result.failed:
        click.echo(click.style(f"\n  Failed ({result.fail_count}):", fg="red"))
        for fp, err in result.failed:
            click.echo(f"    • {fp.name}: {err}")


def main():
    cli()


if __name__ == "__main__":
    main()