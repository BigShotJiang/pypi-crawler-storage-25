from claidai.client import Claid
from claidai.models import EditResult, ImageMeta
from claidai.batch import process_folder, BatchResult
from claidai.exceptions import (
    ClaidError,
    ClaidAuthError,
    ClaidNoCreditsError,
    ClaidRateLimitError,
    ClaidValidationError,
    ClaidFileError,
)

__all__ = [
    "Claid",
    "EditResult",
    "ImageMeta",
    "process_folder",
    "BatchResult",
    "ClaidError",
    "ClaidAuthError",
    "ClaidNoCreditsError",
    "ClaidRateLimitError",
    "ClaidValidationError",
    "ClaidFileError",
]

__version__ = "1.0.0"
__author__  = "Kumaresan"