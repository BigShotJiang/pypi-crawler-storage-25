from __future__ import annotations

import concurrent.futures
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from claidai.exceptions import ClaidError
from claidai.models import EditResult

SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".avif", ".bmp", ".tiff", ".gif"}


@dataclass
class BatchResult:
    succeeded: list[tuple[Path, EditResult]] = field(default_factory=list)
    failed:    list[tuple[Path, str]]        = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.succeeded) + len(self.failed)

    @property
    def success_count(self) -> int:
        return len(self.succeeded)

    @property
    def fail_count(self) -> int:
        return len(self.failed)

    def __str__(self) -> str:
        return (
            f"BatchResult: {self.success_count}/{self.total} succeeded"
            + (f", {self.fail_count} failed" if self.fail_count else "")
        )


def process_folder(
    client,
    input_folder: str | Path,
    output_folder: str | Path,
    operation: Callable,
    operation_kwargs: dict | None = None,
    *,
    recursive: bool = False,
    workers: int = 3,
    skip_existing: bool = False,
    output_format: str = "jpeg",
    on_progress: Optional[Callable[[int, int, Path], None]] = None,
) -> BatchResult:
    """
    Process all images in input_folder using operation and save
    results to output_folder, preserving the sub-folder structure.

    Args:
        client:           A Claid instance.
        input_folder:     Folder containing source images.
        output_folder:    Folder where processed images will be saved.
        operation:        A bound method of Claid e.g. client.remove_bg.
        operation_kwargs: Extra keyword arguments forwarded to operation.
        recursive:        If True, walk sub-folders too.
        workers:          Number of parallel threads (max 4 recommended).
        skip_existing:    Skip files whose output already exists.
        output_format:    Output format extension used to build output filename.
        on_progress:      Optional callback fn(done, total, current_file).

    Returns:
        BatchResult

    Example::

        from claidai import Claid, process_folder

        c = Claid("YOUR_API_KEY")
        result = process_folder(
            c, "photos/", "photos_nobg/",
            operation=c.remove_bg,
            output_format="png",
            workers=3,
        )
        print(result)  # BatchResult: 24/25 succeeded, 1 failed
    """
    src  = Path(input_folder)
    dest = Path(output_folder)

    if not src.exists():
        raise FileNotFoundError(f"Input folder not found: {src.resolve()}")

    dest.mkdir(parents=True, exist_ok=True)

    pattern = "**/*" if recursive else "*"
    files = [
        f for f in src.glob(pattern)
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not files:
        return BatchResult()

    kwargs = operation_kwargs or {}
    result = BatchResult()
    done   = 0

    def _process(filepath: Path) -> tuple[Path, EditResult | str]:
        relative = filepath.relative_to(src)
        out_path = dest / relative.parent / f"{filepath.stem}.{output_format}"
        out_path.parent.mkdir(parents=True, exist_ok=True)

        if skip_existing and out_path.exists():
            return filepath, "skipped"

        try:
            edit_result = operation(filepath, output_format=output_format, **kwargs)
            edit_result.save(out_path)
            return filepath, edit_result
        except ClaidError as e:
            return filepath, str(e)
        except Exception as e:
            return filepath, f"Unexpected error: {e}"

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(workers, 4)) as pool:
        futures = {pool.submit(_process, f): f for f in files}
        for future in concurrent.futures.as_completed(futures):
            filepath, outcome = future.result()
            done += 1
            if on_progress:
                on_progress(done, len(files), filepath)
            if isinstance(outcome, EditResult):
                result.succeeded.append((filepath, outcome))
            elif outcome != "skipped":
                result.failed.append((filepath, outcome))

    return result