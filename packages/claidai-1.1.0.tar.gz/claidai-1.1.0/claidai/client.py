from __future__ import annotations

import json
from pathlib import Path
from typing import Literal, Optional

import requests

from claidai.exceptions import (
    ClaidAuthError,
    ClaidError,
    ClaidFileError,
    ClaidNoCreditsError,
    ClaidRateLimitError,
    ClaidValidationError,
)
from claidai.models import EditResult, _parse_result

BASE_URL = "https://api.claid.ai/v1"

UpscaleMethod  = Literal["smart_enhance", "smart_resize", "photo", "faces", "digital_art"]
FitMode        = Literal["crop", "bounds", "cover", "canvas", "outpaint"]
BlurLevel      = Literal["low", "medium", "high"]
BlurType       = Literal["regular", "lens"]
BgCategory     = Literal["general", "products", "cars"]
DecompressMode = Literal["auto", "moderate", "strong"]
OutputFormat   = Literal["jpeg", "png", "webp", "avif", "tiff"]


class Claid:
    """
    Main client for the Claid.ai API.

    Usage::

        from claidai import Claid
        c = Claid("YOUR_API_KEY")
        c.remove_bg("photo.jpg").save("out.png")
    """

    def __init__(self, api_key: str):
        if not api_key or api_key == "YOUR_API_KEY_HERE":
            raise ClaidAuthError("A valid API key is required.")
        self._api_key = api_key
        self._session = requests.Session()
        self._session.headers.update({"Authorization": f"Bearer {api_key}"})

    def remove_bg(
        self,
        image: str | Path,
        *,
        category: BgCategory = "products",
        bg_color: str = "transparent",
        clipping: bool = True,
        output_format: OutputFormat = "png",
    ) -> EditResult:
        """
        Remove the background from an image.

        Args:
            image:         Path to local image file.
            category:      Subject hint — "products", "general", or "cars".
            bg_color:      Fill after removal. "transparent" or hex e.g. "#ffffff".
            clipping:      Crop canvas to foreground object bounds.
            output_format: Output format (default "png" for transparency).
        """
        return self._upload(
            image,
            operations={
                "background": {
                    "remove": {"category": category, "clipping": clipping},
                    "color": bg_color,
                }
            },
            output_format=output_format,
        )

    def upscale(
        self,
        image: str | Path,
        *,
        scale: str = "200%",
        method: UpscaleMethod = "smart_enhance",
        output_format: OutputFormat = "jpeg",
    ) -> EditResult:
        """
        AI-powered image upscaling.

        Args:
            image:         Path to local image file.
            scale:         Factor as percentage string e.g. "200%" or "400%".
            method:        Neural network to use.
                           "smart_enhance" — products/food/real estate.
                           "smart_resize"  — high-quality photos with text.
                           "photo"         — nature/architecture/phone photos.
                           "faces"         — portraits.
                           "digital_art"   — illustrations/anime/drawings.
            output_format: Output format.
        """
        return self._upload(
            image,
            operations={
                "restorations": {"upscale": method},
                "resizing": {"width": scale, "height": scale},
            },
            output_format=output_format,
        )

    def blur_bg(
        self,
        image: str | Path,
        *,
        blur_type: BlurType = "lens",
        level: BlurLevel = "medium",
        category: BgCategory = "general",
        output_format: OutputFormat = "jpeg",
    ) -> EditResult:
        """
        Blur the background while keeping the subject sharp.

        Args:
            image:         Path to local image file.
            blur_type:     "regular" (Gaussian) or "lens" (depth-of-field).
            level:         Blur strength — "low", "medium", or "high".
            category:      Subject hint for better detection.
            output_format: Output format.
        """
        return self._upload(
            image,
            operations={
                "background": {
                    "blur": {
                        "category": category,
                        "type": blur_type,
                        "level": level,
                    }
                }
            },
            output_format=output_format,
        )

    def enhance(
        self,
        image: str | Path,
        *,
        hdr: int = 0,
        exposure: int = 0,
        saturation: int = 0,
        contrast: int = 0,
        sharpness: int = 0,
        output_format: OutputFormat = "jpeg",
    ) -> EditResult:
        """
        Adjust colour and light.

        Args:
            image:      Path to local image file.
            hdr:        ML-based HDR colour balance (0–100).
            exposure:   Brighten (+) or darken (-).
            saturation: Increase (+) or decrease (-) saturation.
            contrast:   Increase (+) or decrease (-) contrast.
            sharpness:  Sharpen detail (0–100).
        """
        adj: dict = {}
        if hdr:        adj["hdr"]        = hdr
        if exposure:   adj["exposure"]   = exposure
        if saturation: adj["saturation"] = saturation
        if contrast:   adj["contrast"]   = contrast
        if sharpness:  adj["sharpness"]  = sharpness

        if not adj:
            raise ClaidValidationError("Provide at least one adjustment value.")

        return self._upload(image, operations={"adjustments": adj}, output_format=output_format)

    def resize(
        self,
        image: str | Path,
        *,
        width: int | str,
        height: int | str | None = None,
        fit: FitMode = "crop",
        smart: bool = False,
        output_format: OutputFormat = "jpeg",
    ) -> EditResult:
        """
        Resize an image.

        Args:
            image:         Path to local image file.
            width:         Target width in pixels (800) or percentage ("150%").
            height:        Target height. None keeps aspect ratio.
            fit:           "crop", "bounds", "cover", "canvas", "outpaint".
            smart:         Content-aware smart crop (only when fit="crop").
            output_format: Output format.
        """
        resizing: dict = {"width": width}
        if height is not None:
            resizing["height"] = height
        if fit == "crop" and smart:
            resizing["fit"] = {"crop": "smart"}
        else:
            resizing["fit"] = fit

        return self._upload(image, operations={"resizing": resizing}, output_format=output_format)

    def polish(
        self,
        image: str | Path,
        *,
        decompress: DecompressMode = "auto",
        output_format: OutputFormat = "jpeg",
    ) -> EditResult:
        """
        Sharpen details and remove JPEG compression artefacts.

        Args:
            image:       Path to local image file.
            decompress:  Artefact removal — "auto", "moderate", "strong".
        """
        return self._upload(
            image,
            operations={"restorations": {"polish": True, "decompress": decompress}},
            output_format=output_format,
        )

    def outpaint(
        self,
        image: str | Path,
        *,
        width: str = "150%",
        height: str = "100%",
        feathering: str = "20%",
        output_format: OutputFormat = "jpeg",
    ) -> EditResult:
        """
        Expand the image canvas with AI-generated background.

        Args:
            image:      Path to local image file.
            width:      Target width as percentage e.g. "150%".
            height:     Target height as percentage.
            feathering: Blend smoothness at transition edge (max "50%").
        """
        return self._upload(
            image,
            operations={
                "resizing": {
                    "width": width,
                    "height": height,
                    "fit": {"type": "outpaint", "feathering": feathering},
                }
            },
            output_format=output_format,
        )

    def convert(
        self,
        image: str | Path,
        *,
        output_format: OutputFormat,
        quality: int = 85,
    ) -> EditResult:
        """
        Convert an image to a different format.

        Args:
            image:         Path to local image file.
            output_format: Target — "jpeg", "png", "webp", "avif", "tiff".
            quality:       Compression quality for lossy formats (1–100).
        """
        return self._upload(
            image,
            operations={},
            output_format=output_format,
            output_options={"quality": quality},
        )

    # ── Internal helpers ──────────────────────────────────

    def _upload(
        self,
        image: str | Path,
        operations: dict,
        output_format: OutputFormat = "jpeg",
        output_options: dict | None = None,
    ) -> EditResult:
        path = Path(image)
        if not path.exists():
            raise ClaidFileError(f"File not found: {path.resolve()}")

        fmt_block: dict = {"type": output_format}
        if output_options:
            fmt_block.update(output_options)

        data_payload = json.dumps({
            "operations": operations,
            "output": {"format": fmt_block},
        })

        mime = "image/png" if path.suffix.lower() == ".png" else "image/jpeg"

        with path.open("rb") as f:
            resp = self._session.post(
                f"{BASE_URL}/image/edit/upload",
                files={
                    "file": (path.name, f, mime),
                    "data": (None, data_payload, "application/json"),
                },
                timeout=120,
            )

        return self._handle(resp)

    def _handle(self, resp: requests.Response) -> EditResult:
        code = resp.status_code
        if code == 200:
            return _parse_result(resp.json()["data"])
        try:
            body = resp.json()
            msg  = body.get("error_message", resp.text)
        except Exception:
            msg = resp.text

        if code == 401: raise ClaidAuthError(msg)
        if code == 402: raise ClaidNoCreditsError(msg)
        if code == 422: raise ClaidValidationError(msg)
        if code == 429: raise ClaidRateLimitError(msg)
        raise ClaidError(f"HTTP {code}: {msg}")