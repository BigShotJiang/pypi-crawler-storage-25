# Technical Specifications

This folder contains technical specifications, design documents, and research for Axiom.

**PRDs define *what* to build. Specs define *how* to build it.**

## Document Structure

```
specs/
├── spec-executive.md    # Full technical architecture
├── spec-executive.md   # 2-page technical overview
├── design-prompts/                   # Implementation guides for AI/dev
├── diagrams/                         # Architecture diagrams
├── deeplynx-assessment.md            # External technology assessments
├── platform-comparison-databricks.md # Platform alternatives analysis
└── hyperledger-domain-specific-use-cases.md  # Research: blockchain applications
```

## Core Specifications

| Document | Purpose | Audience |
|----------|---------|----------|
| [Master Tech Spec](spec-executive.md) | Complete architecture, schemas, APIs | Engineers |
| [Executive Tech Spec](spec-executive.md) | 2-page technical overview | Stakeholders, PMs |

## Design Prompts

The `design-prompts/` folder contains implementation guides:

| Prompt | Component |
|--------|-----------|
| [Bronze Layer Ingest](design-prompts/prompt-bronze-layer-ingest.md) | Dagster + Iceberg ingestion |
| [dbt Silver Models](design-prompts/prompt-dbt-silver-models.md) | Data transformation |
| [Superset Dashboards](design-prompts/prompt-superset-dashboards.md) | Analytics visualizations |
| [Dagster Orchestration](design-prompts/prompt-dagster-orchestration.md) | Pipeline scheduling |

## Research & Analysis

| Document | Topic |
|----------|-------|
| [DeepLynx Assessment](deeplynx-assessment.md) | INL DeepLynx vs Axiom |
| [Platform Comparison](platform-comparison-databricks.md) | Databricks/Snowflake alternatives |
| [Hyperledger Use Cases](hyperledger-domain-specific-use-cases.md) | Blockchain for domain-specific |

## Proposals & External Docs

| Document | Purpose |
|----------|---------|
| [CINR Pre-App](CINR_PreApp_Concept_Draft.md) | Grant pre-application |
| [LDRD Collaboration](LDRD_Collaboration_OnePager.md) | INL partnership proposal |

## Relationship to PRDs

| PRD (what) | Spec (how) |
|------------|------------|
| [Executive PRD](../prd/axiom-executive-prd.md) | [Master Tech Spec](spec-executive.md) |
| [System Ops Log PRD](../prd/system-ops-log-prd.md) | Tech spec §3.4.5 (log_entries schema) |
| [Experiment Manager PRD](../prd/experiment-manager-prd.md) | Tech spec §3.4.6 (sample_tracking schema) |
| [Analytics PRD](../prd/analytics-dashboards-prd.md) | [Superset Design Prompt](design-prompts/prompt-superset-dashboards.md) |

## Word Documents

Word (.docx) versions are maintained for stakeholder review:
- `axiom-master-tech-spec.docx`
- `axiom-executive-summary.docx`
- `deeplynx-assessment.docx`
