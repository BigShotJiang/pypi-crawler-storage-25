"""Allow ``python -m axiom.rag``."""

from .cli import main

main()
