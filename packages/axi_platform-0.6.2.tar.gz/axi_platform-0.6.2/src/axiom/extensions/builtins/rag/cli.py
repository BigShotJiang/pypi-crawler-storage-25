"""axi rag — thin extension wrapper delegating to axiom.rag.cli."""

from __future__ import annotations

import sys


def main(argv: list[str] | None = None) -> None:
    from axiom.rag.cli import main as rag_main

    rag_main(argv)


if __name__ == "__main__":
    main(sys.argv[1:])
