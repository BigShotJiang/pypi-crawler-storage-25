"""axi web-api — HTTP API for axi chat, embeddable in any web page."""
