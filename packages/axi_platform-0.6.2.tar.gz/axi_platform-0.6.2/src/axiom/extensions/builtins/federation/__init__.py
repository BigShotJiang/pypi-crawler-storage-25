"""Federation extension — CLI commands for multi-node federation and fleet management."""
