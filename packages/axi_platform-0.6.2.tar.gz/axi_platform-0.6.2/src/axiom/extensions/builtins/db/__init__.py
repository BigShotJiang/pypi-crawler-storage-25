"""NeutronOS database infrastructure management.

This module provides shared PostgreSQL + pgvector infrastructure used
across all NeutronOS components (Sense, Chat, etc.).

Commands:
    axi db up        Start local K3D cluster with PostgreSQL
    axi db down      Stop local cluster
    axi db delete    Delete cluster and all data
    axi db status    Show cluster and database status
    axi db migrate   Run schema migrations
    axi db bootstrap Full setup from scratch
"""
