# D-FIB Routines

> OpenClaw HEARTBEAT.md equivalent — defines D-FIB's continuous operational loops.

## Always-On Health Watch

D-FIB runs as a background service, continuously monitoring system health:

| Check | Interval | Description |
|-------|----------|-------------|
| **Connection health** | 60s | Verify all configured connections are reachable and authenticated |
| **Agent service status** | 60s | Check that Mo, EVE, and PR-T services are running |
| **Configuration audit** | 300s | Check for misconfigurations, stale settings, missing dependencies |
| **Security scan** | 3600s | Audit EC content placement, log integrity, injection patterns |

## On Issue Detected

When D-FIB detects a problem:

1. Classify severity (critical, warning, info)
2. Attempt automated diagnosis using LLM
3. If fixable by M-O, delegate to M-O with RACI approval
4. If not, escalate to operator with specific remediation steps

## Heartbeat (60s)

- Aggregate health status across all subsystems
- Publish summary to `axi status` output
- Log diagnostic events for audit trail

## On Startup

- Run full system diagnosis (`axi doctor` equivalent)
- Report any issues accumulated while D-FIB was stopped
- Verify LLM gateway is available (required for diagnosis)
