"""CLI handler for axi config.

Usage:
    axi config                Run full wizard (or resume if state exists)
    axi config --status       Show current configuration status
    axi config --set <name>   Configure a specific connection
    axi config --reset        Clear state and start over
"""

from __future__ import annotations

import argparse
import sys

from axiom.setup.state import clear_state
from axiom.setup.wizard import SetupWizard


def get_parser() -> argparse.ArgumentParser:
    """Build and return the argument parser.

    Exposed for CLI registry introspection and argcomplete.
    """
    parser = argparse.ArgumentParser(
        prog="axi config",
        description="Interactive onboarding wizard",
    )
    parser.add_argument("--status", action="store_true", help="Show configuration status")
    parser.add_argument("--set", metavar="NAME", help="Configure a specific connection")
    parser.add_argument("--reset", action="store_true", help="Clear state and start over")
    return parser


def main() -> None:
    """Entry point for `axi config`."""
    args = sys.argv[1:]

    if "--help" in args or "-h" in args:
        _print_help()
        return

    if "--reset" in args:
        clear_state()
        print("  Setup state cleared. Run 'axi config' to start fresh.")
        return

    wizard = SetupWizard()

    if "--status" in args:
        wizard.show_status()
        return

    if "--set" in args:
        idx = args.index("--set")
        if idx + 1 < len(args):
            wizard.fix(args[idx + 1])
        else:
            print("  Usage: axi config --set <connection-name>")
            print("  Example: axi config --set github_token")
        return

    # Default: run the full wizard
    try:
        wizard.run()
    except KeyboardInterrupt:
        print("\n\n  Setup paused. Run 'axi config' to resume.\n")
        sys.exit(130)


def _print_help() -> None:
    print("axi config — Interactive onboarding wizard")
    print()
    print("Usage:")
    print("  axi config              Run full wizard (or resume)")
    print("  axi config --status     Show current configuration status")
    print("  axi config --set NAME   Configure a specific connection")
    print("  axi config --reset      Clear state and start over")
    print()
    print("Connections:")
    from axiom.setup.guides import CREDENTIAL_GUIDES  # pylint: disable=import-outside-toplevel
    for g in CREDENTIAL_GUIDES:
        tag = "required" if g.required else "optional"
        print(f"  {g.env_var.lower():<30s} {g.display_name} ({tag})")
