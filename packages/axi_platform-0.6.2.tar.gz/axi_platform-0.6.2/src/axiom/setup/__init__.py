"""axi config — Interactive onboarding wizard for Neutron OS."""
