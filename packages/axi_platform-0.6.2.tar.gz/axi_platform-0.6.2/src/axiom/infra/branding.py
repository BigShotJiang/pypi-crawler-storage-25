"""Axiom branding registry.

Domain products (e.g. NeutronOS) register their branding here before
invoking Axiom's CLI. All user-facing text in Axiom reads from the active
branding, so domain products get a fully white-labeled experience without
any code duplication.

Usage (domain product's CLI entry point)::

    from axiom.infra.branding import BrandingConfig, register

    register(BrandingConfig(
        cli_name="neut",
        product_name="Neutron OS",
        mascot_name="Neut",
        tagline="The intelligence platform for nuclear power systems",
        package_name="neutron-os",
    ))

    from axiom.axiom_cli import main
    main()

If no branding is registered, Axiom defaults to Axi.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


@dataclass  # pylint: disable=too-many-instance-attributes
class BrandingConfig:
    """Branding configuration for a product built on Axiom.

    All fields have Axiom/Axi defaults. Override only what you need.
    """

    # CLI identity
    cli_name: str = "axi"
    product_name: str = "Axiom"
    mascot_name: str = "Axi"
    tagline: str = "The intelligent operations platform"
    package_name: str = "axiom"

    # Terminal colors (ANSI escape codes)
    accent_color: str = "\033[38;2;0;207;255m"  # Axiom cyan
    engine_color: str = "\033[38;2;255;140;0m"  # Engine orange
    eye_color: str = "\033[38;2;0;255;255m"  # Sensor cyan

    # Optional overrides
    # If set, called instead of the default Axi banner
    banner_fn: Callable[[], None] | None = None
    # Module path for default chat agent (None = use built-in neut_agent)
    agent_module: str | None = None

    # Infrastructure cluster name — always the framework's, not the consumer's.
    # Consumers adopt the framework cluster rather than creating their own.
    cluster_name: str = "axi-local"

    # Shell alias comment written to .bashrc/.zshrc
    shell_comment: str | None = None

    # Git URL used by the self-update command (None = disable self-update)
    update_repo_url: str | None = None

    def __post_init__(self) -> None:
        if self.shell_comment is None:
            self.shell_comment = f"{self.product_name} CLI shortcut"


# ---------------------------------------------------------------------------
# Registry — last registered wins (domain products load after axiom)
# ---------------------------------------------------------------------------

_registered: list[BrandingConfig] = []
_DEFAULT = BrandingConfig()


def register(config: BrandingConfig) -> None:
    """Register domain branding. Call this before importing the CLI entry point."""
    _registered.append(config)


def get_branding() -> BrandingConfig:
    """Return active branding. Domain product if registered, else Axi default."""
    return _registered[-1] if _registered else _DEFAULT


def reset() -> None:
    """Clear registered branding (used in tests)."""
    _registered.clear()
