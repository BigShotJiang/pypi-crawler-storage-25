" Vim syntax file for MCNP input decks
" Language:    MCNP (Monte Carlo N-Particle)
" Maintainer:  NeutronOS <bbooth@utexas.edu>
" Last Change: 2026-04-01
"
" Install: copy to ~/.vim/syntax/mcnp.vim
"   then add to ~/.vimrc:
"     au BufRead,BufNewFile *.i,*.inp set filetype=mcnp

if exists("b:current_syntax")
  finish
endif

" Case insensitive
syn case ignore

" Comments — lines starting with 'c' in column 1 (or C)
syn match mcnpComment "^[cC]\s.*$"
syn match mcnpComment "^[cC]$"
" Dollar-sign inline comments
syn match mcnpInlineComment "\$.*$"

" Blank delimiter line (separates cell/surface/data blocks)
syn match mcnpDelimiter "^\s*$"

" Numbers
syn match mcnpNumber "\<[-+]\?\d\+\.\?\d*[eEdD][-+]\?\d*\>"
syn match mcnpNumber "\<[-+]\?\.\d\+[eEdD][-+]\?\d*\>"
syn match mcnpNumber "\<\d\+\>"
syn match mcnpFloat  "\<[-+]\?\d\+\.\d*\>"

" Isotope/ZAID identifiers (e.g., 92235.70c, 1001.80c)
syn match mcnpIsotope "\<\d\{4,6}\.\d\{2}[cdepuyshtla]\>"

" Tally cards
syn match mcnpTally "^[fF]\d\+\>"
syn match mcnpTally "^[fF][cCmMqQsSuU]\d\+"
syn match mcnpTally "\<[tT][fF]\d\+"

" Source definition
syn keyword mcnpSource SDEF SI SP SB DS SC SSW SSR
syn keyword mcnpSource KCODE KSRC

" Material cards
syn match mcnpMaterial "^[mM]\d\+\s"
syn match mcnpMaterial "^[mM][tT]\d\+"

" Importance cards
syn keyword mcnpImportance IMP VOL AREA

" Transformation cards
syn match mcnpTransform "^[*]\?[tT][rR]\d\+"

" Surface types
syn keyword mcnpSurface PX PY PZ P SO S SX SY SZ
syn keyword mcnpSurface CX CY CZ C/X C/Y C/Z
syn keyword mcnpSurface KX KY KZ K/X K/Y K/Z
syn keyword mcnpSurface TX TY TZ
syn keyword mcnpSurface GQ SQ
syn keyword mcnpSurface RPP BOX RCC RHP HEX

" Physics cards
syn keyword mcnpPhysics MODE PHYS CUT ELPT DBCN PRINT PRDMP
syn keyword mcnpPhysics NPS CTME LOST RAND GEN SEED STRIDE

" Geometry operators
syn match mcnpOperator "[:#()]"
syn match mcnpOperator "\<[uU]=\d\+"
syn match mcnpOperator "\<[lL][aA][tT]=\d\+"
syn match mcnpOperator "\<[fF][iI][lL][lL]=\d\+"

" Continuation (5 leading spaces)
syn match mcnpContinuation "^     \S"

" Highlighting
hi def link mcnpComment      Comment
hi def link mcnpInlineComment Comment
hi def link mcnpNumber       Number
hi def link mcnpFloat        Float
hi def link mcnpIsotope      Special
hi def link mcnpTally        Function
hi def link mcnpSource       Keyword
hi def link mcnpMaterial     Type
hi def link mcnpImportance   PreProc
hi def link mcnpTransform    PreProc
hi def link mcnpSurface      Constant
hi def link mcnpPhysics      Statement
hi def link mcnpOperator     Operator
hi def link mcnpContinuation Underlined
hi def link mcnpDelimiter    SpecialKey

let b:current_syntax = "mcnp"
