"""Node discovery — find and track federation peers."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path

try:
    import yaml  # type: ignore[import-untyped]

    _HAS_YAML = True
except ImportError:  # pragma: no cover
    _HAS_YAML = False

_DEFAULT_REGISTRY_PATH = Path.home() / ".axi" / "nodes.yaml"


class NodeState(Enum):
    """Lifecycle states for a known peer node."""

    UNKNOWN = "unknown"
    DISCOVERED = "discovered"
    VERIFIED = "verified"
    TRUSTED = "trusted"
    FEDERATED = "federated"
    UNREACHABLE = "unreachable"
    LEAVING = "leaving"
    EVICTED = "evicted"


@dataclass
class KnownNode:
    """A remote node we know about."""

    node_id: str
    display_name: str
    url: str  # A2A endpoint or SSH host
    transport: str = "ssh"  # "ssh", "a2a", "mdns"
    state: NodeState = NodeState.UNKNOWN
    profile: str = "standard"
    capabilities: list[str] = field(default_factory=list)
    last_seen: str = ""  # ISO 8601
    trust_level: str = "untrusted"
    ssh_user: str = ""
    ssh_host: str = ""

    def to_dict(self) -> dict:
        """Serialise to a plain ``dict`` (YAML-friendly)."""
        return {
            "node_id": self.node_id,
            "display_name": self.display_name,
            "url": self.url,
            "transport": self.transport,
            "state": self.state.value,
            "profile": self.profile,
            "capabilities": self.capabilities,
            "last_seen": self.last_seen,
            "trust_level": self.trust_level,
            "ssh_user": self.ssh_user,
            "ssh_host": self.ssh_host,
        }


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class NodeRegistry:
    """Local registry of known nodes — persisted to ``~/.axi/nodes.yaml``."""

    def __init__(self, registry_path: Path | None = None) -> None:
        self._path = registry_path or _DEFAULT_REGISTRY_PATH
        self._nodes: dict[str, KnownNode] = {}
        if self._path.exists():
            self.load()

    # -- CRUD ---------------------------------------------------------------

    def add(self, node: KnownNode) -> None:
        """Add or overwrite a node entry."""
        self._nodes[node.node_id] = node

    def remove(self, node_id: str) -> bool:
        """Remove a node. Returns ``True`` if it existed."""
        return self._nodes.pop(node_id, None) is not None

    def get(self, node_id: str) -> KnownNode | None:
        """Lookup by *node_id*."""
        return self._nodes.get(node_id)

    def list_all(self) -> list[KnownNode]:
        """Return all known nodes."""
        return list(self._nodes.values())

    def update_state(self, node_id: str, state: NodeState) -> None:
        """Transition a node to a new state."""
        node = self._nodes.get(node_id)
        if node is None:
            msg = f"Unknown node: {node_id}"
            raise KeyError(msg)
        node.state = state
        node.last_seen = _now_iso()

    # -- Persistence --------------------------------------------------------

    def save(self) -> None:
        """Write registry to YAML."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        data = [n.to_dict() for n in self._nodes.values()]
        if _HAS_YAML:
            self._path.write_text(yaml.dump(data, default_flow_style=False))
        else:  # pragma: no cover
            import json

            self._path.write_text(json.dumps(data, indent=2))

    def load(self) -> None:
        """Read registry from YAML (or JSON fallback)."""
        if not self._path.exists():
            return
        raw = self._path.read_text()
        if _HAS_YAML:
            entries = yaml.safe_load(raw) or []
        else:  # pragma: no cover
            import json

            entries = json.loads(raw)
        self._nodes.clear()
        for entry in entries:
            entry["state"] = NodeState(entry.get("state", "unknown"))
            self._nodes[entry["node_id"]] = KnownNode(**entry)

    # -- Discovery helpers --------------------------------------------------

    def discover_ssh(self, name: str, user: str, host: str) -> KnownNode:
        """Register a node reachable via SSH."""
        import hashlib

        node_id = hashlib.sha256(f"ssh:{user}@{host}".encode()).hexdigest()[:16]
        node = KnownNode(
            node_id=node_id,
            display_name=name,
            url=f"ssh://{user}@{host}",
            transport="ssh",
            state=NodeState.DISCOVERED,
            ssh_user=user,
            ssh_host=host,
            last_seen=_now_iso(),
        )
        self.add(node)
        return node

    def discover_a2a(self, name: str, url: str) -> KnownNode:
        """Register a node reachable via A2A HTTP."""
        import hashlib

        node_id = hashlib.sha256(f"a2a:{url}".encode()).hexdigest()[:16]
        node = KnownNode(
            node_id=node_id,
            display_name=name,
            url=url,
            transport="a2a",
            state=NodeState.DISCOVERED,
            last_seen=_now_iso(),
        )
        self.add(node)
        return node

    def check_health(self, node_id: str) -> dict:
        """Placeholder health check for a single node."""
        node = self.get(node_id)
        if node is None:
            return {"node_id": node_id, "status": "not_found"}
        return {
            "node_id": node_id,
            "display_name": node.display_name,
            "state": node.state.value,
            "last_seen": node.last_seen,
        }

    def check_all(self) -> list[dict]:
        """Health-check summaries for every known node."""
        return [self.check_health(nid) for nid in self._nodes]
