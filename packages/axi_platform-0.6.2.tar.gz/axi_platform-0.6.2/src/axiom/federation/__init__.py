"""Federation — node identity, A2A agent cards, peer discovery, and trust."""
