#!/usr/bin/env python3
"""Validate that SDK version constants are in sync with pyproject.toml."""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def get_pyproject_version() -> str:
    text = (ROOT / "pyproject.toml").read_text()
    match = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
    if not match:
        print("ERROR: Could not find version in pyproject.toml")
        sys.exit(1)
    return match.group(1)


def get_client_version() -> str:
    text = (ROOT / "optropic" / "client.py").read_text()
    match = re.search(r'^_SDK_VERSION\s*=\s*"([^"]+)"', text, re.MULTILINE)
    if not match:
        print("ERROR: Could not find _SDK_VERSION in client.py")
        sys.exit(1)
    return match.group(1)


def main() -> None:
    pyproject = get_pyproject_version()
    client = get_client_version()

    ok = True

    if pyproject != client:
        print(f"MISMATCH: pyproject.toml={pyproject}  client.py={client}")
        ok = False

    if ok:
        print(f"OK: All versions in sync at {pyproject}")
    else:
        print("FAIL: Version mismatch detected!")
        sys.exit(1)


if __name__ == "__main__":
    main()
