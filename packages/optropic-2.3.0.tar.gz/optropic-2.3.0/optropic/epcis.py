"""EPCIS 2.0 Event Type Mapping.

Maps Optropic provenance events to GS1 EPCIS 2.0 event types and
vocabularies. Enables interoperability with supply chain systems that
speak EPCIS (SAP, Oracle, TraceLink, etc.) and aligns with
DIN SPEC 91406 product identification.

EPCIS 2.0 spec: GS1 General Specification §7 + EPCIS/CBV 2.0
See: https://www.gs1.org/standards/epcis
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional, Sequence
from urllib.parse import quote


# ── EPCIS 2.0 Event Types ──────────────────────────────────────────────────

EPCISEventType = Literal[
    "ObjectEvent",
    "AggregationEvent",
    "TransactionEvent",
    "TransformationEvent",
    "AssociationEvent",
]

ProvenanceEventType = Literal[
    "manufactured",
    "labeled",
    "enrolled",
    "shipped",
    "received",
    "transferred",
    "verified",
    "recalled",
    "destroyed",
    "custom",
]

# ── CBV 2.0 Vocabulary Constants ────────────────────────────────────────────

# Commonly used business step URNs (subset relevant for DPP)
BIZSTEP_COMMISSIONING = "urn:epcglobal:cbv:bizstep:commissioning"
BIZSTEP_SHIPPING = "urn:epcglobal:cbv:bizstep:shipping"
BIZSTEP_RECEIVING = "urn:epcglobal:cbv:bizstep:receiving"
BIZSTEP_INSPECTING = "urn:epcglobal:cbv:bizstep:inspecting"
BIZSTEP_DESTROYING = "urn:epcglobal:cbv:bizstep:destroying"
BIZSTEP_ENCODING = "urn:epcglobal:cbv:bizstep:encoding"
BIZSTEP_HOLDING = "urn:epcglobal:cbv:bizstep:holding"
BIZSTEP_DECOMMISSIONING = "urn:epcglobal:cbv:bizstep:decommissioning"
BIZSTEP_TRANSFORMING = "urn:epcglobal:cbv:bizstep:transforming"
BIZSTEP_PACKING = "urn:epcglobal:cbv:bizstep:packing"
BIZSTEP_UNPACKING = "urn:epcglobal:cbv:bizstep:unpacking"
BIZSTEP_TRANSPORTING = "urn:epcglobal:cbv:bizstep:transporting"
BIZSTEP_REPAIRING = "urn:epcglobal:cbv:bizstep:repairing"
BIZSTEP_CYCLE_COUNTING = "urn:epcglobal:cbv:bizstep:cycle_counting"
BIZSTEP_RETAIL_SELLING = "urn:epcglobal:cbv:bizstep:retail_selling"

# Commonly used disposition URNs
DISP_ACTIVE = "urn:epcglobal:cbv:disp:active"
DISP_IN_TRANSIT = "urn:epcglobal:cbv:disp:in_transit"
DISP_RECALLED = "urn:epcglobal:cbv:disp:recalled"
DISP_DESTROYED = "urn:epcglobal:cbv:disp:destroyed"
DISP_IN_PROGRESS = "urn:epcglobal:cbv:disp:in_progress"
DISP_ENCODED = "urn:epcglobal:cbv:disp:encoded"
DISP_INACTIVE = "urn:epcglobal:cbv:disp:inactive"


# ── Mapping Types ───────────────────────────────────────────────────────────


@dataclass(frozen=True)
class EPCISMapping:
    """Result of mapping an Optropic provenance event to EPCIS 2.0."""

    event_type: EPCISEventType
    """The EPCIS event type."""

    biz_step: str
    """CBV business step URN."""

    disposition: str
    """CBV disposition URN (state of the object after the event)."""

    exact: bool
    """Whether this is a one-to-one mapping (True) or best-effort."""

    note: str
    """Human-readable description of the mapping rationale."""


@dataclass
class EPCISEvent:
    """A single EPCIS 2.0 event in the JSON-LD representation."""

    type: EPCISEventType
    event_time: str
    event_time_zone_offset: str
    biz_step: str
    disposition: str
    epc_list: List[str] = field(default_factory=list)
    read_point: Optional[str] = None
    biz_location: Optional[str] = None
    optropic_provenance_event_id: Optional[str] = None
    optropic_chain_sequence: Optional[int] = None
    optropic_event_hash: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to EPCIS 2.0 JSON-LD format."""
        result: Dict[str, Any] = {
            "type": self.type,
            "eventTime": self.event_time,
            "eventTimeZoneOffset": self.event_time_zone_offset,
            "bizStep": self.biz_step,
            "disposition": self.disposition,
        }
        if self.epc_list:
            result["epcList"] = self.epc_list
        if self.read_point:
            result["readPoint"] = {"id": self.read_point}
        if self.biz_location:
            result["bizLocation"] = {"id": self.biz_location}
        if self.optropic_provenance_event_id:
            result["optropic:provenanceEventId"] = self.optropic_provenance_event_id
        if self.optropic_chain_sequence is not None:
            result["optropic:chainSequence"] = self.optropic_chain_sequence
        if self.optropic_event_hash:
            result["optropic:eventHash"] = self.optropic_event_hash
        return result


# ── Mapping Table ───────────────────────────────────────────────────────────

_MAPPING_TABLE: Dict[str, EPCISMapping] = {
    "manufactured": EPCISMapping(
        event_type="TransformationEvent",
        biz_step=BIZSTEP_COMMISSIONING,
        disposition=DISP_ACTIVE,
        exact=True,
        note="Raw materials transformed into finished product; new EPC commissioned.",
    ),
    "labeled": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_ENCODING,
        disposition=DISP_ENCODED,
        exact=True,
        note="Physical label or tag applied/encoded on the product.",
    ),
    "enrolled": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_COMMISSIONING,
        disposition=DISP_ACTIVE,
        exact=False,
        note="Optropic-specific: substrate fingerprint captured. Mapped to commissioning as closest EPCIS equivalent.",
    ),
    "shipped": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_SHIPPING,
        disposition=DISP_IN_TRANSIT,
        exact=True,
        note="Product shipped from origin; enters transit.",
    ),
    "received": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_RECEIVING,
        disposition=DISP_ACTIVE,
        exact=True,
        note="Product received at destination.",
    ),
    "transferred": EPCISMapping(
        event_type="TransactionEvent",
        biz_step=BIZSTEP_HOLDING,
        disposition=DISP_ACTIVE,
        exact=False,
        note="Ownership transfer. TransactionEvent captures business transaction linkage; disposition remains active.",
    ),
    "verified": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_INSPECTING,
        disposition=DISP_ACTIVE,
        exact=True,
        note="Product authenticity or integrity verified.",
    ),
    "recalled": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_HOLDING,
        disposition=DISP_RECALLED,
        exact=True,
        note="Product recalled; removed from distribution.",
    ),
    "destroyed": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_DECOMMISSIONING,
        disposition=DISP_DESTROYED,
        exact=True,
        note="Product destroyed; EPC decommissioned.",
    ),
    "custom": EPCISMapping(
        event_type="ObjectEvent",
        biz_step=BIZSTEP_HOLDING,
        disposition=DISP_ACTIVE,
        exact=False,
        note="Custom event with no direct EPCIS equivalent; mapped to generic observation.",
    ),
}


# ── Public API ──────────────────────────────────────────────────────────────


def map_to_epcis(event_type: str) -> EPCISMapping:
    """Get the EPCIS 2.0 mapping for an Optropic provenance event type.

    Args:
        event_type: Optropic provenance event type string.

    Returns:
        EPCISMapping with EPCIS event type, bizStep, disposition, and notes.

    Example::

        mapping = map_to_epcis("manufactured")
        print(mapping.event_type)  # "TransformationEvent"
        print(mapping.biz_step)    # "urn:epcglobal:cbv:bizstep:commissioning"
    """
    return _MAPPING_TABLE.get(event_type, _MAPPING_TABLE["custom"])


def get_epcis_mapping_table() -> Dict[str, EPCISMapping]:
    """Get the full mapping table (useful for documentation / UI display).

    Returns:
        Dictionary mapping each ProvenanceEventType to its EPCISMapping.
    """
    return dict(_MAPPING_TABLE)


def to_epcis_event(
    event: Dict[str, Any],
    *,
    timezone_offset: str = "+00:00",
    gs1_company_prefix: Optional[str] = None,
) -> EPCISEvent:
    """Convert an Optropic ProvenanceEvent dict into an EPCIS 2.0 event.

    This produces a single EPCIS event object suitable for inclusion
    in an EPCISDocument's eventList. The output follows the EPCIS 2.0
    JSON/JSON-LD binding specification.

    Args:
        event: Optropic provenance event dictionary from the API.
        timezone_offset: Timezone offset string (default: "+00:00").
        gs1_company_prefix: GS1 company prefix for EPC URI generation.

    Returns:
        EPCISEvent ready for serialization.

    Example::

        event = client.provenance.get("evt-123")
        epcis_event = to_epcis_event(event)
    """
    mapping = map_to_epcis(event.get("event_type", event.get("eventType", "custom")))
    asset_id = event.get("asset_id", event.get("assetId", ""))
    location = event.get("location", {}) or {}

    epc = _asset_id_to_epc(asset_id, gs1_company_prefix)

    read_point = None
    biz_location = None
    if location.get("facility"):
        read_point = _build_location_uri(location, gs1_company_prefix)
        biz_location = _build_location_uri(location, gs1_company_prefix)

    return EPCISEvent(
        type=mapping.event_type,
        event_time=event.get("timestamp", ""),
        event_time_zone_offset=timezone_offset,
        biz_step=mapping.biz_step,
        disposition=mapping.disposition,
        epc_list=[epc],
        read_point=read_point,
        biz_location=biz_location,
        optropic_provenance_event_id=event.get("id"),
        optropic_chain_sequence=event.get("chain_sequence", event.get("chainSequence")),
        optropic_event_hash=event.get("event_hash", event.get("eventHash")),
    )


def build_epcis_document(events: Sequence[EPCISEvent]) -> Dict[str, Any]:
    """Wrap one or more EPCIS events in a full EPCISDocument (JSON-LD).

    Args:
        events: Sequence of EPCISEvent objects.

    Returns:
        Complete EPCIS 2.0 document dict, ready for JSON serialization.

    Example::

        chain = client.provenance.get_chain("asset-123")
        epcis_events = [to_epcis_event(e) for e in chain["events"]]
        doc = build_epcis_document(epcis_events)
        # doc is ready for json.dumps()
    """
    return {
        "@context": [
            "https://ref.gs1.org/standards/epcis/2.0.0/epcis-context.jsonld",
            {"optropic": "https://api.optropic.com/ns/epcis/"},
        ],
        "type": "EPCISDocument",
        "schemaVersion": "2.0",
        "creationDate": datetime.now(timezone.utc).isoformat(),
        "epcisBody": {
            "eventList": [e.to_dict() for e in events],
        },
    }


def provenance_chain_to_epcis(
    events: Sequence[Dict[str, Any]],
    *,
    timezone_offset: str = "+00:00",
    gs1_company_prefix: Optional[str] = None,
) -> Dict[str, Any]:
    """Convert a full Optropic provenance chain to an EPCIS 2.0 document.

    Convenience function combining to_epcis_event + build_epcis_document.

    Args:
        events: Sequence of Optropic provenance event dicts.
        timezone_offset: Timezone offset string.
        gs1_company_prefix: GS1 company prefix for EPC URIs.

    Returns:
        Complete EPCIS 2.0 JSON-LD document dict.
    """
    epcis_events = [
        to_epcis_event(e, timezone_offset=timezone_offset, gs1_company_prefix=gs1_company_prefix)
        for e in events
    ]
    return build_epcis_document(epcis_events)


# ── Helpers ─────────────────────────────────────────────────────────────────

_GTIN_RE = re.compile(r"^\d{8,14}$")


def _asset_id_to_epc(asset_id: str, gs1_company_prefix: Optional[str] = None) -> str:
    """Convert an Optropic asset ID to an EPC URI."""
    if gs1_company_prefix and _GTIN_RE.match(asset_id):
        return f"urn:epc:id:sgtin:{gs1_company_prefix}.{asset_id}"
    return f"urn:optropic:asset:{asset_id}"


def _build_location_uri(
    location: Dict[str, Any],
    gs1_company_prefix: Optional[str] = None,
) -> str:
    """Build a GS1-style location URI from Optropic location dict."""
    facility = location.get("facility", "")
    if gs1_company_prefix and facility:
        return f"urn:epc:id:sgln:{gs1_company_prefix}.{quote(facility)}"
    parts = [
        v for v in [location.get("country"), location.get("region"), facility] if v
    ]
    return f"urn:optropic:location:{':'.join(parts)}"
