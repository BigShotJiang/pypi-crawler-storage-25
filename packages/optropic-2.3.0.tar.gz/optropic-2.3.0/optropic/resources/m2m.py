from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Optropic


class M2M:
    """Machine-to-Machine physical authentication protocol.

    Enables challenge-response verification between devices and assets.
    This is used for high-security verification where a device must prove
    physical possession of an asset's authentication credentials.

    .. note::

        M2M endpoints are in preview and require enterprise access.
        Contact support@optropic.com to enable M2M for your tenant.

    Example::

        # 1. Initiate a challenge
        challenge = client.m2m.initiate_challenge("ast_abc123")

        # 2. Device signs the nonce (application-specific)
        response_sig = device.sign(challenge["nonce"])

        # 3. Verify the response
        result = client.m2m.verify(
            challenge_id=challenge["id"],
            response=response_sig,
        )
        print(result["valid"])  # True or False
    """

    def __init__(self, client: Optropic) -> None:
        self._client = client

    def initiate_challenge(
        self,
        asset_id: str,
        *,
        algorithm: str = "ed25519",
        ttl_seconds: int = 60,
    ) -> Dict[str, Any]:
        """Initiate an M2M challenge for an asset.

        The server generates a random nonce that must be signed by the
        asset's private key (or a device credential bound to the asset).

        Args:
            asset_id: The asset to authenticate.
            algorithm: Signature algorithm. Currently only ``"ed25519"``.
            ttl_seconds: Challenge time-to-live in seconds (default 60).

        Returns:
            Challenge object with ``id``, ``asset_id``, ``nonce``,
            ``algorithm``, ``expires_at``, ``created_at``.
        """
        return self._client._request(
            "POST",
            "/m2m/challenge",
            json={
                "asset_id": asset_id,
                "algorithm": algorithm,
                "ttl_seconds": ttl_seconds,
            },
        )

    def verify(
        self,
        challenge_id: str,
        response: str,
        *,
        device_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Verify an M2M challenge response.

        Args:
            challenge_id: The challenge ID from :meth:`initiate_challenge`.
            response: The hex-encoded signature of the challenge nonce.
            device_id: Optional verifier device ID for audit trail.

        Returns:
            Verification result with ``valid``, ``asset_id``,
            ``challenge_id``, ``verified_at``, and optional ``reason``
            if invalid (``"expired"``, ``"bad_signature"``, ``"revoked"``).
        """
        payload: Dict[str, Any] = {
            "challenge_id": challenge_id,
            "response": response,
        }
        if device_id is not None:
            payload["device_id"] = device_id

        return self._client._request("POST", "/m2m/verify", json=payload)

    def register_device(
        self,
        label: str,
        public_key: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Register a verifier device.

        Args:
            label: Human-readable device label.
            public_key: Hex-encoded Ed25519 public key.
            metadata: Optional device metadata.

        Returns:
            Device object with ``device_id``, ``label``, ``public_key``,
            ``status``, ``created_at``.
        """
        payload: Dict[str, Any] = {
            "label": label,
            "public_key": public_key,
        }
        if metadata is not None:
            payload["metadata"] = metadata

        return self._client._request("POST", "/m2m/devices", json=payload)

    def get_device(self, device_id: str) -> Dict[str, Any]:
        """Get a verifier device by ID."""
        return self._client._request("GET", f"/m2m/devices/{device_id}")

    def list_devices(self) -> list:
        """List all registered verifier devices."""
        data = self._client._request("GET", "/m2m/devices")
        return data.get("data", data) if isinstance(data, dict) else data

    def revoke_device(self, device_id: str) -> Dict[str, Any]:
        """Revoke a verifier device."""
        return self._client._request("DELETE", f"/m2m/devices/{device_id}")
