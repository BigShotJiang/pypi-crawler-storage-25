"""OID Provenance — track the full lifecycle of physical objects.

Each provenance event is cryptographically linked to the previous one,
forming a tamper-evident chain. Combined with Document Enrollment
(substrate fingerprints), this enables end-to-end physical-digital trust.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Optropic


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

from dataclasses import dataclass


@dataclass
class RecordProvenanceParams:
    """Parameters for recording a provenance event."""

    asset_id: str
    event_type: str  # manufactured, labeled, enrolled, shipped, received, etc.
    actor: str
    location: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class ListProvenanceParams:
    """Parameters for listing provenance events."""

    asset_id: Optional[str] = None
    event_type: Optional[str] = None
    from_date: Optional[str] = None
    to_date: Optional[str] = None
    page: Optional[int] = None
    per_page: Optional[int] = None


# ---------------------------------------------------------------------------
# Resource
# ---------------------------------------------------------------------------


class Provenance:
    """OID Provenance chain operations — record and verify lifecycle events."""

    def __init__(self, client: Optropic) -> None:
        self._client = client

    def record(self, params: RecordProvenanceParams) -> Dict[str, Any]:
        """Record a new provenance event in the chain.

        Events are automatically chained — the server links each new event
        to the previous one via cryptographic hash.

        Usage::

            event = client.provenance.record(RecordProvenanceParams(
                asset_id="asset-123",
                event_type="manufactured",
                actor="factory-line-7",
                location={"country": "DE", "facility": "Munich Plant"},
            ))
        """
        body = {k: v for k, v in asdict(params).items() if v is not None}
        return self._client._request("POST", "/provenance", json=body)

    def get_chain(self, asset_id: str) -> Dict[str, Any]:
        """Get the full provenance chain for an asset."""
        return self._client._request("GET", f"/provenance/chain/{asset_id}")

    def get(self, event_id: str) -> Dict[str, Any]:
        """Retrieve a single provenance event by ID."""
        return self._client._request("GET", f"/provenance/{event_id}")

    def list(self, params: Optional[ListProvenanceParams] = None) -> Dict[str, Any]:
        """List provenance events with optional filtering."""
        query = {k: v for k, v in asdict(params).items() if v is not None} if params else None
        return self._client._request("GET", "/provenance", params=query)

    def verify_chain(self, asset_id: str) -> Dict[str, Any]:
        """Verify the integrity of an asset's provenance chain.

        Checks that all events are correctly linked via cryptographic hashes.
        """
        return self._client._request("POST", f"/provenance/chain/{asset_id}/verify")
