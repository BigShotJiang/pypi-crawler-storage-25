"""Document Enrollment — register physical objects with substrate fingerprints.

Central to Optropic's Material Entropy technology: a physical object is
photographed, its micro-surface features are extracted as a 3D descriptor
[GB, GE, M7-PCA], and the resulting fingerprint is enrolled as a document
linked to an asset.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Optropic


# ---------------------------------------------------------------------------
# Types (added to types.py conceptually, inline here for self-containment)
# ---------------------------------------------------------------------------

from dataclasses import dataclass


@dataclass
class EnrollDocumentParams:
    """Parameters for enrolling a new document."""

    asset_id: str
    fingerprint_hash: str
    descriptor_version: str
    substrate_type: str
    capture_device: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class VerifyDocumentParams:
    """Parameters for verifying a fingerprint against enrolled documents."""

    fingerprint_hash: str
    descriptor_version: str
    threshold: Optional[float] = None


@dataclass
class ListDocumentsParams:
    """Parameters for listing enrolled documents."""

    asset_id: Optional[str] = None
    substrate_type: Optional[str] = None
    status: Optional[str] = None
    page: Optional[int] = None
    per_page: Optional[int] = None


# ---------------------------------------------------------------------------
# Resource
# ---------------------------------------------------------------------------


class Documents:
    """Document enrollment operations — register and verify substrate fingerprints."""

    def __init__(self, client: Optropic) -> None:
        self._client = client

    def enroll(self, params: EnrollDocumentParams) -> Dict[str, Any]:
        """Enroll a new document (substrate fingerprint) linked to an asset.

        Usage::

            doc = client.documents.enroll(EnrollDocumentParams(
                asset_id="asset-123",
                fingerprint_hash="sha256:abc123...",
                descriptor_version="GB_GE_M7PCA_v1",
                substrate_type="S_fb",
                capture_device="iPhone16ProMax_main",
            ))
        """
        body = {k: v for k, v in asdict(params).items() if v is not None}
        return self._client._request("POST", "/documents", json=body)

    def verify(self, params: VerifyDocumentParams) -> Dict[str, Any]:
        """Verify a fingerprint against enrolled documents.

        Returns the best match if similarity exceeds the threshold.
        """
        body = {k: v for k, v in asdict(params).items() if v is not None}
        return self._client._request("POST", "/documents/verify", json=body)

    def get(self, document_id: str) -> Dict[str, Any]:
        """Retrieve a single document by ID."""
        return self._client._request("GET", f"/documents/{document_id}")

    def list(self, params: Optional[ListDocumentsParams] = None) -> Dict[str, Any]:
        """List enrolled documents with optional filtering."""
        query = {k: v for k, v in asdict(params).items() if v is not None} if params else None
        return self._client._request("GET", "/documents", params=query)

    def supersede(self, document_id: str, new_document_id: str) -> Dict[str, Any]:
        """Supersede a document (e.g., re-enrollment with better capture)."""
        return self._client._request(
            "POST",
            f"/documents/{document_id}/supersede",
            json={"new_document_id": new_document_id},
        )
