"""EU Digital Product Passport (DPP) — Types & Helpers.

Supports the ESPR/DPP regulation (EU DPP Registry goes live 19 July 2026).
Provides typed metadata structures for Battery Passport (Feb 2027),
Textiles (Q2 2027), and general product passports.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Literal


# ── Core DPP Types ─────────────────────────────────────────────────────────

DPPCategory = Literal[
    "battery",
    "textile",
    "electronics",
    "construction",
    "steel",
    "furniture",
    "chemical",
    "general",
]


@dataclass
class SubstanceEntry:
    """Entry for a substance of concern (SCIP database)."""

    name: str
    cas_number: Optional[str] = None
    concentration: Optional[float] = None
    unit: Optional[str] = None


@dataclass
class ConformityDeclaration:
    """Conformity declaration or certification."""

    standard: str
    certificate_id: Optional[str] = None
    issued_by: Optional[str] = None
    valid_until: Optional[str] = None


@dataclass
class BatteryPassportData:
    """Battery-specific data for EU Battery Passport (Feb 2027)."""

    type: Literal["battery"] = "battery"
    chemistry: str = ""
    capacity_kwh: float = 0.0
    state_of_health: Optional[float] = None
    cycle_count: Optional[int] = None
    cobalt_content: Optional[float] = None
    lithium_content: Optional[float] = None
    recycled_cobalt_percent: Optional[float] = None
    recycled_lithium_percent: Optional[float] = None
    recycled_nickel_percent: Optional[float] = None
    recycled_lead_percent: Optional[float] = None
    carbon_class: Optional[str] = None
    expected_lifetime_cycles: Optional[int] = None
    due_diligence_url: Optional[str] = None


@dataclass
class FiberEntry:
    """Fiber composition entry for textile passports."""

    fiber: str
    percent: float
    recycled: Optional[bool] = None
    origin: Optional[str] = None


@dataclass
class TextilePassportData:
    """Textile-specific data for EU Textile Passport (Q2 2027)."""

    type: Literal["textile"] = "textile"
    fiber_composition: List[FiberEntry] = field(default_factory=list)
    processes: Optional[List[str]] = None
    water_usage_liters: Optional[float] = None
    microfiber_release: Optional[Literal["low", "medium", "high"]] = None
    care_instructions: Optional[List[str]] = None


@dataclass
class DPPMetadata:
    """Base Digital Product Passport metadata.

    Aligns with the EU DPP data model (ESPR Art. 8-12).
    """

    product_id: str
    """Unique product identifier (GS1 GTIN, SGTIN, or custom)."""

    product_name: str
    """Product name / trade name."""

    manufacturer: str
    """Manufacturer / economic operator name."""

    country_of_origin: str
    """Country of manufacture (ISO 3166-1 alpha-2)."""

    category: DPPCategory
    """Product category for DPP regulation scope."""

    carbon_footprint: Optional[float] = None
    """Carbon footprint in kg CO2e (if applicable)."""

    recycled_content: Optional[float] = None
    """Recycled content percentage (0-100)."""

    durability_years: Optional[float] = None
    """Durability / expected lifetime in years."""

    repairability_score: Optional[float] = None
    """Repairability score (EU scale, if applicable)."""

    substances_of_concern: Optional[List[SubstanceEntry]] = None
    """List of substances of concern (SCIP database)."""

    dpp_registry_id: Optional[str] = None
    """EU DPP Registry reference (assigned after July 2026)."""

    conformity_declarations: Optional[List[ConformityDeclaration]] = None
    """Conformity declarations / certifications."""

    sector_data: Optional[
        BatteryPassportData | TextilePassportData | Dict[str, Any]
    ] = None
    """Additional sector-specific metadata."""


# ── Helpers ────────────────────────────────────────────────────────────────


@dataclass
class DPPValidationResult:
    """Result of DPP metadata validation."""

    valid: bool
    """Whether the metadata is valid."""

    errors: List[str] = field(default_factory=list)
    """List of validation errors (empty if valid)."""


def build_dpp_config(metadata: DPPMetadata) -> Dict[str, Any]:
    """Build a DPP-compliant asset config from metadata.

    Converts a typed DPPMetadata object into the flat config format
    expected by the Optropic API's asset creation endpoint.

    Args:
        metadata: DPP metadata with product information and optional sector data.

    Returns:
        Dictionary suitable for passing to the API's asset config.

    Example:
        >>> config = build_dpp_config(DPPMetadata(
        ...     product_id='04012345000010',
        ...     product_name='EcoWidget Pro',
        ...     manufacturer='GreenTech GmbH',
        ...     country_of_origin='DE',
        ...     category='electronics',
        ...     carbon_footprint=12.5,
        ...     recycled_content=35,
        ... ))
        >>> # Use config in API: client.assets.create(...)
    """
    config: Dict[str, Any] = {
        "product_id": metadata.product_id,
        "product_name": metadata.product_name,
        "manufacturer": metadata.manufacturer,
        "country_of_origin": metadata.country_of_origin,
        "dpp_category": metadata.category,
    }

    if metadata.carbon_footprint is not None:
        config["carbon_footprint_kg_co2e"] = metadata.carbon_footprint
    if metadata.recycled_content is not None:
        config["recycled_content_percent"] = metadata.recycled_content
    if metadata.durability_years is not None:
        config["durability_years"] = metadata.durability_years
    if metadata.repairability_score is not None:
        config["repairability_score"] = metadata.repairability_score
    if metadata.substances_of_concern is not None:
        config["substances_of_concern"] = metadata.substances_of_concern
    if metadata.dpp_registry_id is not None:
        config["dpp_registry_id"] = metadata.dpp_registry_id
    if metadata.conformity_declarations is not None:
        config["conformity_declarations"] = metadata.conformity_declarations
    if metadata.sector_data is not None:
        config["sector_data"] = metadata.sector_data

    return config


def validate_dpp_metadata(metadata: DPPMetadata) -> DPPValidationResult:
    """Validate that DPP metadata meets minimum requirements for the given category.

    Performs basic required field validation and category-specific checks:
    - All metadata: requires product_id, product_name, manufacturer, country_of_origin
    - Country code: must be ISO 3166-1 alpha-2 (2 uppercase letters)
    - Recycled content: must be between 0-100 if provided
    - Battery sector: requires chemistry and capacity_kwh in sectorData
    - Textile sector: requires non-empty fiber_composition in sectorData

    Args:
        metadata: DPP metadata to validate.

    Returns:
        DPPValidationResult with valid flag and list of error messages.
    """
    errors: List[str] = []

    # Required fields
    if not metadata.product_id:
        errors.append("product_id is required")
    if not metadata.product_name:
        errors.append("product_name is required")
    if not metadata.manufacturer:
        errors.append("manufacturer is required")
    if not metadata.country_of_origin:
        errors.append("country_of_origin is required")

    # Country code validation
    if metadata.country_of_origin and not _is_valid_iso_country_code(
        metadata.country_of_origin
    ):
        errors.append('country_of_origin must be ISO 3166-1 alpha-2 (e.g., "DE")')

    # Recycled content validation
    if metadata.recycled_content is not None:
        if metadata.recycled_content < 0 or metadata.recycled_content > 100:
            errors.append("recycled_content must be between 0 and 100")

    # Battery-specific validation
    if metadata.category == "battery" and metadata.sector_data:
        battery = metadata.sector_data
        if isinstance(battery, BatteryPassportData):
            if not battery.chemistry:
                errors.append("battery.chemistry is required for battery passports")
            if not battery.capacity_kwh:
                errors.append("battery.capacity_kwh is required for battery passports")

    # Textile-specific validation
    if metadata.category == "textile" and metadata.sector_data:
        textile = metadata.sector_data
        if isinstance(textile, TextilePassportData):
            if not textile.fiber_composition or len(textile.fiber_composition) == 0:
                errors.append(
                    "textile.fiber_composition is required for textile passports"
                )

    return DPPValidationResult(valid=len(errors) == 0, errors=errors)


def _is_valid_iso_country_code(code: str) -> bool:
    """Check if code is a valid ISO 3166-1 alpha-2 country code.

    Args:
        code: Two-letter code to validate.

    Returns:
        True if code matches the pattern (exactly 2 uppercase letters).
    """
    if not isinstance(code, str) or len(code) != 2:
        return False
    return code.isupper() and code.isalpha()
