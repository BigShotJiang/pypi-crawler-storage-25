"""DPP Access Control Levels.

Implements tiered access control for EU Digital Product Passport data.
Required before the EU DPP Registry launch (19 July 2026).

The ESPR regulation mandates that DPP data is available at different
levels depending on the requester's role:

- **public**: Consumer-facing data (product name, manufacturer,
  carbon footprint, recycled content, repairability score).
- **authenticated**: Data available to verified supply chain partners
  (substances of concern, sector-specific data, conformity declarations).
- **regulatory**: Full dataset available to market surveillance
  authorities (all fields + audit trail).
- **owner**: Complete data including internal metadata, accessible
  only to the economic operator who created the passport.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Sequence

from .dpp import DPPCategory


# ── Access Levels ───────────────────────────────────────────────────────────

DPPAccessLevelValue = Literal["public", "authenticated", "regulatory", "owner"]

_LEVEL_RANK: Dict[str, int] = {
    "public": 0,
    "authenticated": 1,
    "regulatory": 2,
    "owner": 3,
}


class DPPAccessLevel:
    """DPP access levels, ordered from least to most privileged."""

    PUBLIC: DPPAccessLevelValue = "public"
    AUTHENTICATED: DPPAccessLevelValue = "authenticated"
    REGULATORY: DPPAccessLevelValue = "regulatory"
    OWNER: DPPAccessLevelValue = "owner"

    @staticmethod
    def is_at_least(level: DPPAccessLevelValue, required: DPPAccessLevelValue) -> bool:
        """Check if a level has at least the privilege of another.

        Args:
            level: The requester's access level.
            required: The minimum required level.

        Returns:
            True if the requester's level meets or exceeds the requirement.

        Example::

            DPPAccessLevel.is_at_least("regulatory", "authenticated")  # True
            DPPAccessLevel.is_at_least("public", "regulatory")         # False
        """
        return _LEVEL_RANK.get(level, 0) >= _LEVEL_RANK.get(required, 0)

    @staticmethod
    def all_levels() -> List[DPPAccessLevelValue]:
        """Return all access levels in ascending privilege order."""
        return ["public", "authenticated", "regulatory", "owner"]


# ── Field Visibility ────────────────────────────────────────────────────────


@dataclass(frozen=True)
class DPPFieldVisibility:
    """Defines which DPP fields are visible at each access level."""

    field: str
    """Field name (matches DPPMetadata property)."""

    min_level: DPPAccessLevelValue
    """Minimum access level required to view this field."""

    category_override: Optional[Dict[str, DPPAccessLevelValue]] = None
    """Optional per-DPP-category overrides for the minimum level."""


@dataclass
class DPPAccessPolicy:
    """Complete access policy for a DPP dataset."""

    default_level: DPPAccessLevelValue = "public"
    """Default access level applied when none is specified."""

    fields: List[DPPFieldVisibility] = field(default_factory=list)
    """Per-field visibility rules."""

    redaction_mode: Literal["omit", "placeholder"] = "omit"
    """Whether redacted fields show '[REDACTED]' or are omitted entirely."""


@dataclass
class DPPAccessContext:
    """Context for an access control decision."""

    level: DPPAccessLevelValue
    """The requester's access level."""

    category: Optional[DPPCategory] = None
    """Optional: the specific DPP category (for category-specific overrides)."""

    show_redacted: Optional[bool] = None
    """Optional: if True, include redaction markers instead of omitting fields."""


# ── Default Policy ──────────────────────────────────────────────────────────

_DEFAULT_FIELD_VISIBILITY: List[DPPFieldVisibility] = [
    # ── Public fields
    DPPFieldVisibility(field="product_id", min_level="public"),
    DPPFieldVisibility(field="product_name", min_level="public"),
    DPPFieldVisibility(field="manufacturer", min_level="public"),
    DPPFieldVisibility(field="country_of_origin", min_level="public"),
    DPPFieldVisibility(field="category", min_level="public"),
    DPPFieldVisibility(field="carbon_footprint", min_level="public"),
    DPPFieldVisibility(field="recycled_content", min_level="public"),
    DPPFieldVisibility(field="durability_years", min_level="public"),
    DPPFieldVisibility(field="repairability_score", min_level="public"),
    DPPFieldVisibility(field="dpp_registry_id", min_level="public"),
    # ── Authenticated fields
    DPPFieldVisibility(
        field="substances_of_concern",
        min_level="authenticated",
        # Battery regulation requires public disclosure of substances
        category_override={"battery": "public"},
    ),
    DPPFieldVisibility(field="conformity_declarations", min_level="authenticated"),
    DPPFieldVisibility(
        field="sector_data",
        min_level="authenticated",
        # Battery basic data (chemistry, capacity) is public per Battery Regulation Art. 13
        category_override={"battery": "public"},
    ),
    # ── Regulatory fields
    DPPFieldVisibility(field="internal_batch_id", min_level="regulatory"),
    DPPFieldVisibility(field="audit_trail_ref", min_level="regulatory"),
    DPPFieldVisibility(field="manufacturing_date", min_level="regulatory"),
    DPPFieldVisibility(field="facility_id", min_level="regulatory"),
    # ── Owner-only fields
    DPPFieldVisibility(field="cost_data", min_level="owner"),
    DPPFieldVisibility(field="supplier_contracts", min_level="owner"),
    DPPFieldVisibility(field="internal_notes", min_level="owner"),
]


# ── Public API ──────────────────────────────────────────────────────────────


def get_dpp_access_policy(
    overrides: Optional[List[DPPFieldVisibility]] = None,
) -> DPPAccessPolicy:
    """Get the default DPP access policy.

    Returns the policy that aligns with ESPR and EU Battery Regulation
    requirements. Can be customized per tenant via the API's compliance
    configuration.

    Args:
        overrides: Optional field visibility overrides to use instead of defaults.

    Returns:
        The access policy.
    """
    fields = overrides if overrides is not None else list(_DEFAULT_FIELD_VISIBILITY)
    return DPPAccessPolicy(
        default_level="public",
        fields=fields,
        redaction_mode="omit",
    )


def filter_dpp_by_access(
    metadata: Dict[str, Any],
    context: DPPAccessContext,
    policy: Optional[DPPAccessPolicy] = None,
) -> Dict[str, Any]:
    """Filter DPP metadata based on the requester's access level.

    Returns a new dict containing only the fields the requester is
    authorized to see. Fields below the access threshold are either
    omitted or replaced with '[REDACTED]' placeholders.

    Args:
        metadata: Full DPP metadata dict (all fields).
        context: Access context (level, category, redaction preference).
        policy: Optional custom access policy; uses default if omitted.

    Returns:
        Filtered metadata dictionary.

    Example::

        # Consumer view — only public fields
        public_view = filter_dpp_by_access(full_metadata, DPPAccessContext(
            level=DPPAccessLevel.PUBLIC,
            category="battery",
        ))

        # Regulatory view — full access
        reg_view = filter_dpp_by_access(full_metadata, DPPAccessContext(
            level=DPPAccessLevel.REGULATORY,
            category="battery",
            show_redacted=True,
        ))
    """
    effective_policy = policy if policy is not None else get_dpp_access_policy()
    result: Dict[str, Any] = {}
    show_redacted = (
        context.show_redacted
        if context.show_redacted is not None
        else (effective_policy.redaction_mode == "placeholder")
    )

    # Build field lookup
    field_rules: Dict[str, DPPFieldVisibility] = {
        f.field: f for f in effective_policy.fields
    }

    for key, value in metadata.items():
        rule = field_rules.get(key)

        if rule is None:
            # Fields not in the policy are owner-only by default
            if DPPAccessLevel.is_at_least(context.level, "owner"):
                result[key] = value
            elif show_redacted:
                result[key] = "[REDACTED]"
            continue

        # Determine effective minimum level (check category override)
        effective_min_level = rule.min_level
        if context.category and rule.category_override:
            override = rule.category_override.get(context.category)
            if override is not None:
                effective_min_level = override

        if DPPAccessLevel.is_at_least(context.level, effective_min_level):
            result[key] = value
        elif show_redacted:
            result[key] = "[REDACTED]"
        # else: omit the field entirely

    return result
