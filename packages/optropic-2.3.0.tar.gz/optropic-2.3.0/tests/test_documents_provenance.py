"""Tests for Documents and Provenance resource modules (Phase 2).

Uses unittest.mock to patch the client's _request method so no real HTTP calls are made.
"""

from __future__ import annotations

import pytest
from unittest.mock import patch

from optropic import Optropic
from optropic.resources.documents import (
    Documents,
    EnrollDocumentParams,
    VerifyDocumentParams,
    ListDocumentsParams,
)
from optropic.resources.provenance import (
    Provenance,
    RecordProvenanceParams,
    ListProvenanceParams,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def client():
    """Create a client with a test key and mock the HTTP layer."""
    return Optropic(api_key="optr_test_abcdefghijklmnopqrst")


@pytest.fixture
def mock_request(client):
    """Patch client._request so no real HTTP calls are made."""
    with patch.object(client, "_request") as m:
        yield m


# ---------------------------------------------------------------------------
# Documents
# ---------------------------------------------------------------------------


class TestDocuments:
    def test_enroll(self, client, mock_request):
        mock_request.return_value = {
            "id": "doc-1",
            "asset_id": "asset-123",
            "fingerprint_hash": "sha256:abc123",
            "descriptor_version": "GB_GE_M7PCA_v1",
            "substrate_type": "S_fb",
            "status": "active",
        }
        params = EnrollDocumentParams(
            asset_id="asset-123",
            fingerprint_hash="sha256:abc123",
            descriptor_version="GB_GE_M7PCA_v1",
            substrate_type="S_fb",
            capture_device="iPhone16ProMax_main",
        )
        result = client.documents.enroll(params)

        assert result["id"] == "doc-1"
        assert result["status"] == "active"

        call_args = mock_request.call_args
        assert call_args[0] == ("POST", "/documents")
        body = call_args[1]["json"]
        assert body["asset_id"] == "asset-123"
        assert body["fingerprint_hash"] == "sha256:abc123"
        assert body["capture_device"] == "iPhone16ProMax_main"

    def test_enroll_minimal(self, client, mock_request):
        mock_request.return_value = {"id": "doc-2", "status": "active"}
        params = EnrollDocumentParams(
            asset_id="asset-456",
            fingerprint_hash="sha256:def789",
            descriptor_version="GB_GE_M7PCA_v1",
            substrate_type="S_fb",
        )
        result = client.documents.enroll(params)

        call_args = mock_request.call_args
        body = call_args[1]["json"]
        assert "capture_device" not in body
        assert "metadata" not in body

    def test_verify(self, client, mock_request):
        mock_request.return_value = {
            "matched": True,
            "document_id": "doc-1",
            "asset_id": "asset-123",
            "similarity": 0.95,
        }
        params = VerifyDocumentParams(
            fingerprint_hash="sha256:abc123",
            descriptor_version="GB_GE_M7PCA_v1",
            threshold=0.85,
        )
        result = client.documents.verify(params)

        assert result["matched"] is True
        assert result["similarity"] == 0.95

        call_args = mock_request.call_args
        assert call_args[0] == ("POST", "/documents/verify")
        body = call_args[1]["json"]
        assert body["threshold"] == 0.85

    def test_get(self, client, mock_request):
        mock_request.return_value = {"id": "doc-1", "status": "active"}
        result = client.documents.get("doc-1")

        mock_request.assert_called_once_with("GET", "/documents/doc-1")
        assert result["id"] == "doc-1"

    def test_list_no_params(self, client, mock_request):
        mock_request.return_value = {"data": [], "total": 0}
        result = client.documents.list()

        mock_request.assert_called_once_with("GET", "/documents", params=None)
        assert result["data"] == []

    def test_list_with_filters(self, client, mock_request):
        mock_request.return_value = {"data": [{"id": "doc-1"}], "total": 1}
        params = ListDocumentsParams(asset_id="asset-123", substrate_type="S_fb")
        client.documents.list(params)

        call_args = mock_request.call_args
        query = call_args[1]["params"]
        assert query["asset_id"] == "asset-123"
        assert query["substrate_type"] == "S_fb"

    def test_supersede(self, client, mock_request):
        mock_request.return_value = {
            "id": "doc-1",
            "status": "superseded",
            "superseded_by": "doc-2",
        }
        result = client.documents.supersede("doc-1", "doc-2")

        assert result["status"] == "superseded"

        call_args = mock_request.call_args
        assert call_args[0] == ("POST", "/documents/doc-1/supersede")
        body = call_args[1]["json"]
        assert body["new_document_id"] == "doc-2"


# ---------------------------------------------------------------------------
# Provenance
# ---------------------------------------------------------------------------


class TestProvenance:
    def test_record(self, client, mock_request):
        mock_request.return_value = {
            "id": "prov-1",
            "asset_id": "asset-123",
            "event_type": "manufactured",
            "actor": "factory-line-7",
            "chain_sequence": 1,
        }
        params = RecordProvenanceParams(
            asset_id="asset-123",
            event_type="manufactured",
            actor="factory-line-7",
            location={"country": "DE", "facility": "Munich Plant"},
        )
        result = client.provenance.record(params)

        assert result["id"] == "prov-1"
        assert result["event_type"] == "manufactured"

        call_args = mock_request.call_args
        assert call_args[0] == ("POST", "/provenance")
        body = call_args[1]["json"]
        assert body["asset_id"] == "asset-123"
        assert body["event_type"] == "manufactured"
        assert body["location"]["country"] == "DE"

    def test_record_minimal(self, client, mock_request):
        mock_request.return_value = {"id": "prov-2", "event_type": "shipped"}
        params = RecordProvenanceParams(
            asset_id="asset-456",
            event_type="shipped",
            actor="logistics-hub",
        )
        client.provenance.record(params)

        call_args = mock_request.call_args
        body = call_args[1]["json"]
        assert "location" not in body
        assert "metadata" not in body

    def test_get_chain(self, client, mock_request):
        mock_request.return_value = {
            "asset_id": "asset-123",
            "events": [
                {"id": "prov-1", "event_type": "manufactured"},
                {"id": "prov-2", "event_type": "shipped"},
            ],
            "chain_valid": True,
            "event_count": 2,
        }
        result = client.provenance.get_chain("asset-123")

        mock_request.assert_called_once_with("GET", "/provenance/chain/asset-123")
        assert result["chain_valid"] is True
        assert len(result["events"]) == 2

    def test_get(self, client, mock_request):
        mock_request.return_value = {"id": "prov-1", "event_type": "manufactured"}
        result = client.provenance.get("prov-1")

        mock_request.assert_called_once_with("GET", "/provenance/prov-1")
        assert result["id"] == "prov-1"

    def test_list_no_params(self, client, mock_request):
        mock_request.return_value = {"data": [], "total": 0}
        result = client.provenance.list()

        mock_request.assert_called_once_with("GET", "/provenance", params=None)
        assert result["data"] == []

    def test_list_with_filters(self, client, mock_request):
        mock_request.return_value = {"data": [{"id": "prov-1"}], "total": 1}
        params = ListProvenanceParams(
            asset_id="asset-123",
            event_type="manufactured",
        )
        client.provenance.list(params)

        call_args = mock_request.call_args
        query = call_args[1]["params"]
        assert query["asset_id"] == "asset-123"
        assert query["event_type"] == "manufactured"

    def test_verify_chain(self, client, mock_request):
        mock_request.return_value = {
            "chain_valid": True,
            "events_checked": 5,
            "verified_at": "2026-03-27T10:00:00Z",
        }
        result = client.provenance.verify_chain("asset-123")

        assert result["chain_valid"] is True
        assert result["events_checked"] == 5

        mock_request.assert_called_once_with(
            "POST", "/provenance/chain/asset-123/verify"
        )


# ---------------------------------------------------------------------------
# Lazy property instantiation
# ---------------------------------------------------------------------------


class TestLazyProperties:
    def test_documents_property(self, client):
        """documents property returns a Documents instance and caches it."""
        docs = client.documents
        assert isinstance(docs, Documents)
        assert client.documents is docs  # same instance

    def test_provenance_property(self, client):
        """provenance property returns a Provenance instance and caches it."""
        prov = client.provenance
        assert isinstance(prov, Provenance)
        assert client.provenance is prov  # same instance
