"""Tests for auto-sandbox detection in the Optropic client."""

from __future__ import annotations

import pytest

from optropic import Optropic


class TestSandboxDetection:
    """Client correctly detects sandbox vs live mode from API key prefix."""

    def test_test_key_is_sandbox(self) -> None:
        client = Optropic(api_key="optr_test_abc123")
        assert client.is_sandbox is True
        assert client.is_live is False
        assert client.environment == "sandbox"

    def test_live_key_is_live(self) -> None:
        client = Optropic(api_key="optr_live_abc123")
        assert client.is_sandbox is False
        assert client.is_live is True
        assert client.environment == "live"

    def test_unknown_prefix_defaults_to_live(self) -> None:
        client = Optropic(api_key="unknown_prefix_key")
        assert client.is_sandbox is False
        assert client.is_live is True
        assert client.environment == "live"

    def test_explicit_sandbox_override_true(self) -> None:
        """Explicit sandbox=True overrides live key detection."""
        client = Optropic(api_key="optr_live_abc123", sandbox=True)
        assert client.is_sandbox is True
        assert client.environment == "sandbox"

    def test_explicit_sandbox_override_false(self) -> None:
        """Explicit sandbox=False overrides test key detection."""
        client = Optropic(api_key="optr_test_abc123", sandbox=False)
        assert client.is_sandbox is False
        assert client.environment == "live"

    def test_missing_api_key_raises(self) -> None:
        with pytest.raises(ValueError, match="api_key is required"):
            Optropic(api_key=None)

    def test_env_var_fallback(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OPTROPIC_API_KEY", "optr_test_from_env")
        client = Optropic()
        assert client.is_sandbox is True
