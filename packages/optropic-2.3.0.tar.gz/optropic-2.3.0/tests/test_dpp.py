"""Tests for DPP (Digital Product Passport) module."""

import pytest

from optropic.dpp import (
    BatteryPassportData,
    ConformityDeclaration,
    DPPMetadata,
    DPPValidationResult,
    FiberEntry,
    SubstanceEntry,
    TextilePassportData,
    build_dpp_config,
    validate_dpp_metadata,
)


class TestBuildDPPConfig:
    """Tests for build_dpp_config helper."""

    def test_minimal_metadata(self):
        """Test building config with minimal required fields."""
        metadata = DPPMetadata(
            product_id="04012345000010",
            product_name="Basic Product",
            manufacturer="TestCorp",
            country_of_origin="DE",
            category="general",
        )

        config = build_dpp_config(metadata)

        assert config["product_id"] == "04012345000010"
        assert config["product_name"] == "Basic Product"
        assert config["manufacturer"] == "TestCorp"
        assert config["country_of_origin"] == "DE"
        assert config["dpp_category"] == "general"
        assert "carbon_footprint_kg_co2e" not in config
        assert "recycled_content_percent" not in config

    def test_all_optional_fields(self):
        """Test building config with all optional fields."""
        substances = [
            SubstanceEntry(
                name="Lead",
                cas_number="7439-92-1",
                concentration=0.5,
                unit="wt%",
            ),
        ]

        conformities = [
            ConformityDeclaration(
                standard="RoHS 2011/65/EU",
                certificate_id="CERT-2024-001",
                issued_by="TÜV SÜD",
                valid_until="2027-01-01",
            ),
        ]

        metadata = DPPMetadata(
            product_id="04012345000010",
            product_name="EcoWidget Pro",
            manufacturer="GreenTech GmbH",
            country_of_origin="DE",
            category="electronics",
            carbon_footprint=12.5,
            recycled_content=35.0,
            durability_years=5,
            repairability_score=7.5,
            substances_of_concern=substances,
            dpp_registry_id="DPP-REG-001",
            conformity_declarations=conformities,
        )

        config = build_dpp_config(metadata)

        assert config["carbon_footprint_kg_co2e"] == 12.5
        assert config["recycled_content_percent"] == 35.0
        assert config["durability_years"] == 5
        assert config["repairability_score"] == 7.5
        assert config["dpp_registry_id"] == "DPP-REG-001"
        assert len(config["substances_of_concern"]) == 1
        assert len(config["conformity_declarations"]) == 1

    def test_battery_sector_data(self):
        """Test building config with battery sector data."""
        battery_data = BatteryPassportData(
            chemistry="NMC",
            capacity_kwh=50.0,
            state_of_health=98.5,
            cycle_count=150,
            cobalt_content=12.5,
            lithium_content=8.2,
            recycled_cobalt_percent=5.0,
            carbon_class="B",
            expected_lifetime_cycles=1000,
        )

        metadata = DPPMetadata(
            product_id="BAT-001",
            product_name="EV Battery Pack",
            manufacturer="BatteryMaker",
            country_of_origin="SE",
            category="battery",
            sector_data=battery_data,
        )

        config = build_dpp_config(metadata)

        assert config["dpp_category"] == "battery"
        assert isinstance(config["sector_data"], BatteryPassportData)
        assert config["sector_data"].chemistry == "NMC"
        assert config["sector_data"].capacity_kwh == 50.0
        assert config["sector_data"].state_of_health == 98.5
        assert config["sector_data"].cycle_count == 150
        assert config["sector_data"].carbon_class == "B"

    def test_textile_sector_data(self):
        """Test building config with textile sector data."""
        fibers = [
            FiberEntry(fiber="cotton", percent=95.0, recycled=False, origin="India"),
            FiberEntry(fiber="elastane", percent=5.0, recycled=False),
        ]

        textile_data = TextilePassportData(
            fiber_composition=fibers,
            processes=["dyeing", "weaving"],
            water_usage_liters=150.0,
            microfiber_release="low",
            care_instructions=["30C", "no_bleach"],
        )

        metadata = DPPMetadata(
            product_id="TEX-001",
            product_name="Eco T-Shirt",
            manufacturer="TextileCorp",
            country_of_origin="PT",
            category="textile",
            sector_data=textile_data,
        )

        config = build_dpp_config(metadata)

        assert config["dpp_category"] == "textile"
        assert isinstance(config["sector_data"], TextilePassportData)
        assert len(config["sector_data"].fiber_composition) == 2
        assert config["sector_data"].fiber_composition[0].fiber == "cotton"
        assert config["sector_data"].fiber_composition[0].percent == 95.0
        assert config["sector_data"].water_usage_liters == 150.0


class TestValidateDPPMetadata:
    """Tests for validate_dpp_metadata validation."""

    def test_valid_minimal_metadata(self):
        """Test validation passes for minimal valid metadata."""
        metadata = DPPMetadata(
            product_id="04012345000010",
            product_name="Basic Product",
            manufacturer="TestCorp",
            country_of_origin="DE",
            category="general",
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is True
        assert len(result.errors) == 0

    def test_missing_product_id(self):
        """Test validation fails when product_id is missing."""
        metadata = DPPMetadata(
            product_id="",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="DE",
            category="general",
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "product_id is required" in result.errors

    def test_missing_product_name(self):
        """Test validation fails when product_name is missing."""
        metadata = DPPMetadata(
            product_id="001",
            product_name="",
            manufacturer="Corp",
            country_of_origin="DE",
            category="general",
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "product_name is required" in result.errors

    def test_missing_manufacturer(self):
        """Test validation fails when manufacturer is missing."""
        metadata = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="",
            country_of_origin="DE",
            category="general",
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "manufacturer is required" in result.errors

    def test_missing_country_of_origin(self):
        """Test validation fails when country_of_origin is missing."""
        metadata = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="",
            category="general",
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "country_of_origin is required" in result.errors

    def test_invalid_country_code(self):
        """Test validation fails for invalid ISO country code."""
        metadata = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="DEU",  # Invalid: should be 2 chars
            category="general",
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert 'country_of_origin must be ISO 3166-1 alpha-2 (e.g., "DE")' in result.errors

    def test_invalid_country_code_lowercase(self):
        """Test validation fails for lowercase country code."""
        metadata = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="de",  # Invalid: must be uppercase
            category="general",
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert 'country_of_origin must be ISO 3166-1 alpha-2 (e.g., "DE")' in result.errors

    def test_recycled_content_below_range(self):
        """Test validation fails when recycled_content is below 0."""
        metadata = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="DE",
            category="general",
            recycled_content=-5.0,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "recycled_content must be between 0 and 100" in result.errors

    def test_recycled_content_above_range(self):
        """Test validation fails when recycled_content is above 100."""
        metadata = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="DE",
            category="general",
            recycled_content=105.0,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "recycled_content must be between 0 and 100" in result.errors

    def test_recycled_content_valid_boundaries(self):
        """Test validation passes for recycled_content at boundaries (0 and 100)."""
        metadata_zero = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="DE",
            category="general",
            recycled_content=0.0,
        )
        result_zero = validate_dpp_metadata(metadata_zero)
        assert result_zero.valid is True

        metadata_hundred = DPPMetadata(
            product_id="001",
            product_name="Test",
            manufacturer="Corp",
            country_of_origin="DE",
            category="general",
            recycled_content=100.0,
        )
        result_hundred = validate_dpp_metadata(metadata_hundred)
        assert result_hundred.valid is True

    def test_battery_missing_chemistry(self):
        """Test validation fails when battery chemistry is missing."""
        battery_data = BatteryPassportData(
            chemistry="",  # Invalid: required
            capacity_kwh=50.0,
        )

        metadata = DPPMetadata(
            product_id="BAT-001",
            product_name="Battery",
            manufacturer="Corp",
            country_of_origin="DE",
            category="battery",
            sector_data=battery_data,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "battery.chemistry is required for battery passports" in result.errors

    def test_battery_missing_capacity(self):
        """Test validation fails when battery capacity_kwh is missing."""
        battery_data = BatteryPassportData(
            chemistry="NMC",
            capacity_kwh=0.0,  # Invalid: required
        )

        metadata = DPPMetadata(
            product_id="BAT-001",
            product_name="Battery",
            manufacturer="Corp",
            country_of_origin="DE",
            category="battery",
            sector_data=battery_data,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert "battery.capacity_kwh is required for battery passports" in result.errors

    def test_battery_valid_data(self):
        """Test validation passes for valid battery data."""
        battery_data = BatteryPassportData(
            chemistry="LFP",
            capacity_kwh=100.0,
            state_of_health=99.0,
        )

        metadata = DPPMetadata(
            product_id="BAT-001",
            product_name="Battery",
            manufacturer="Corp",
            country_of_origin="SE",
            category="battery",
            sector_data=battery_data,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is True

    def test_textile_missing_fiber_composition(self):
        """Test validation fails when textile fiber_composition is empty."""
        textile_data = TextilePassportData(
            fiber_composition=[],  # Invalid: required and non-empty
        )

        metadata = DPPMetadata(
            product_id="TEX-001",
            product_name="Textile",
            manufacturer="Corp",
            country_of_origin="PT",
            category="textile",
            sector_data=textile_data,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert (
            "textile.fiber_composition is required for textile passports"
            in result.errors
        )

    def test_textile_missing_fiber_composition_none(self):
        """Test validation fails when textile fiber_composition is None."""
        textile_data = TextilePassportData(
            fiber_composition=None,  # Invalid: required
        )

        metadata = DPPMetadata(
            product_id="TEX-001",
            product_name="Textile",
            manufacturer="Corp",
            country_of_origin="PT",
            category="textile",
            sector_data=textile_data,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False

    def test_textile_valid_data(self):
        """Test validation passes for valid textile data."""
        fibers = [
            FiberEntry(fiber="cotton", percent=95.0),
            FiberEntry(fiber="elastane", percent=5.0),
        ]

        textile_data = TextilePassportData(
            fiber_composition=fibers,
            water_usage_liters=200.0,
            microfiber_release="low",
        )

        metadata = DPPMetadata(
            product_id="TEX-001",
            product_name="Textile",
            manufacturer="Corp",
            country_of_origin="PT",
            category="textile",
            sector_data=textile_data,
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is True

    def test_multiple_validation_errors(self):
        """Test validation collects multiple errors."""
        metadata = DPPMetadata(
            product_id="",  # Missing
            product_name="",  # Missing
            manufacturer="",  # Missing
            country_of_origin="INVALID",  # Invalid format
            category="general",
            recycled_content=150.0,  # Out of range
        )

        result = validate_dpp_metadata(metadata)

        assert result.valid is False
        assert len(result.errors) >= 5


class TestDPPTypes:
    """Tests for DPP dataclass types and their structure."""

    def test_substance_entry_creation(self):
        """Test SubstanceEntry dataclass creation."""
        substance = SubstanceEntry(
            name="Cadmium",
            cas_number="7440-43-9",
            concentration=0.1,
            unit="wt%",
        )
        assert substance.name == "Cadmium"
        assert substance.cas_number == "7440-43-9"
        assert substance.concentration == 0.1
        assert substance.unit == "wt%"

    def test_conformity_declaration_creation(self):
        """Test ConformityDeclaration dataclass creation."""
        conformity = ConformityDeclaration(
            standard="CE",
            certificate_id="CERT-123",
            issued_by="Notified Body XYZ",
            valid_until="2025-12-31",
        )
        assert conformity.standard == "CE"
        assert conformity.certificate_id == "CERT-123"

    def test_fiber_entry_creation(self):
        """Test FiberEntry dataclass creation."""
        fiber = FiberEntry(
            fiber="polyester",
            percent=60.0,
            recycled=True,
            origin="EU",
        )
        assert fiber.fiber == "polyester"
        assert fiber.percent == 60.0
        assert fiber.recycled is True
        assert fiber.origin == "EU"

    def test_battery_passport_defaults(self):
        """Test BatteryPassportData default values."""
        battery = BatteryPassportData()
        assert battery.type == "battery"
        assert battery.chemistry == ""
        assert battery.capacity_kwh == 0.0
        assert battery.state_of_health is None

    def test_textile_passport_defaults(self):
        """Test TextilePassportData default values."""
        textile = TextilePassportData()
        assert textile.type == "textile"
        assert textile.fiber_composition == []
        assert textile.processes is None
        assert textile.water_usage_liters is None

    def test_dpp_metadata_all_categories(self):
        """Test DPPMetadata with all valid categories."""
        categories = [
            "battery",
            "textile",
            "electronics",
            "construction",
            "steel",
            "furniture",
            "chemical",
            "general",
        ]

        for cat in categories:
            metadata = DPPMetadata(
                product_id="001",
                product_name="Test",
                manufacturer="Corp",
                country_of_origin="DE",
                category=cat,
            )
            assert metadata.category == cat

    def test_validation_result_structure(self):
        """Test DPPValidationResult dataclass."""
        result = DPPValidationResult(
            valid=False,
            errors=["error1", "error2"],
        )
        assert result.valid is False
        assert len(result.errors) == 2
        assert "error1" in result.errors

        result_valid = DPPValidationResult(valid=True)
        assert result_valid.valid is True
        assert result_valid.errors == []
