#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# Optropic Python SDK — PyPI Publish Script
#
# Publishes optropic v2.0.0 to PyPI.
# Requirements: pip install build twine
#
# Usage:
#   ./publish.sh          # publish to PyPI (production)
#   ./publish.sh --test   # publish to TestPyPI first
# ──────────────────────────────────────────────────────────────────────────────

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "═══════════════════════════════════════════════════════════"
echo "  Optropic Python SDK — Build & Publish"
echo "═══════════════════════════════════════════════════════════"

# 1. Clean previous builds
echo ""
echo "→ Cleaning dist/"
rm -rf dist/ build/ *.egg-info

# 2. Build
echo "→ Building wheel and sdist..."
python -m build

echo ""
echo "→ Built artifacts:"
ls -la dist/

# 3. Check
echo ""
echo "→ Running twine check..."
python -m twine check dist/*

# 4. Publish
if [[ "${1:-}" == "--test" ]]; then
  echo ""
  echo "→ Publishing to TestPyPI..."
  python -m twine upload --repository testpypi dist/*
  echo ""
  echo "✅ Published to TestPyPI!"
  echo "   Install with: pip install --index-url https://test.pypi.org/simple/ optropic==2.0.0"
else
  echo ""
  echo "→ Publishing to PyPI..."
  python -m twine upload dist/*
  echo ""
  echo "✅ Published to PyPI!"
  echo "   Install with: pip install optropic==2.0.0"
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Done! Current version: $(python -c 'import tomllib; print(tomllib.load(open("pyproject.toml","rb"))["project"]["version"])')"
echo "═══════════════════════════════════════════════════════════"
