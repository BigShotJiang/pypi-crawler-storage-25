# Changelog

All notable changes to the Optropic Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.3.0] - Unreleased

### Added
- `Permission` enum for type-safe API key creation
- `RateLimitInfo` dataclass with automatic header parsing — accessible via `client.rate_limit`
- `assets.batch_create()` method for bulk asset creation
- `assets.batch_verify()` method for bulk asset verification
- `assets.batch_revoke()` method for bulk asset revocation
- Version sync validation script (`scripts/check_version.py`)

## [2.2.0] - 2026-03-28

### Added
- Debug logging mode — `Optropic(debug=True)` logs all requests/responses with secrets redacted
- Outbound `X-Request-ID` header on every request for end-to-end correlation
- Per-operation timeout overrides — pass `timeout=` to any request method
- Test suite for Tier 2 observability features (11 tests)

## [2.1.0] - 2026-03-28

### Added
- Retry with exponential backoff + jitter (formula: `delay * 2^attempt + delay * 0.5 * random()`)
- Full error parity with TypeScript SDK — 15 typed error classes
- `create_error_from_response()` factory with two-tier mapping (error code → HTTP status → generic)
- Auto-generated `Idempotency-Key` header for POST/PUT/PATCH requests
- Webhook timestamp validation with configurable tolerance
- `WebhookVerifyResult` structured result with `valid`, `reason`, `__bool__`
- `assets.list_all()` auto-pagination iterator
- Test suite for Phase 3 Tier 1 features (40+ tests)

### Changed
- `OptropicError` base class now carries `retryable`, `details`, `request_id` fields
- `verify_webhook_signature()` returns `WebhookVerifyResult` instead of `bool` (backward compatible via `__bool__`)

## [2.0.0] - 2026-03-15

### Added
- Provenance resource — `client.provenance.record()`, `get_chain()`, `verify_chain()`
- Documents resource — substrate fingerprint enrollment and verification
- Schema Registry v2.0 — `client.schemas.create()`, `get()`, `validate()`
- Compliance resource — `verify_chain()`, Merkle proofs, audit export
- Offline verification via Cuckoo filters — `assets.verify(local_filter=...)`
- `assets.sync_filter()` for downloading revocation filters
- `FilterSyncResult` type with binary filter, salts, issued_at, item_count
- Full type coverage with dataclasses for all request/response types

### Changed
- Client now auto-detects sandbox mode from API key prefix (`optr_test_*`)
- `assets.create()` accepts both `CreateAssetParams` and keyword arguments

## [1.0.0] - 2026-02-01

### Added
- Initial release
- `Optropic` client with API key authentication
- Assets resource — create, list, get, update, revoke, verify
- Audit resource — list, get, create events
- Keys resource — create, list, revoke, update
- Webhooks resource — create, list, delete, list deliveries
- `verify_webhook_signature()` for HMAC-SHA256 webhook verification
- Typed error classes: `OptropicError`, `AuthenticationError`, `ForbiddenError`, `ValidationError`, `NotFoundError`, `RateLimitError`
