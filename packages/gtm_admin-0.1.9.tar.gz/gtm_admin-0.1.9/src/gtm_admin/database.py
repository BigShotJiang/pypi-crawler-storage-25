from __future__ import annotations

import asyncio
import concurrent.futures
from collections.abc import AsyncGenerator
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel.ext.asyncio.session import AsyncSession

_engine: AsyncEngine | None = None
_SessionLocal: sessionmaker | None = None
_db_url: str | None = None


from __future__ import annotations

import asyncio
import concurrent.futures
from collections.abc import AsyncGenerator
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel.ext.asyncio.session import AsyncSession

_engine: AsyncEngine | None = None
_SessionLocal: sessionmaker | None = None
_db_url: str | None = None


def setup_engine(db_url: str) -> None:
    global _engine, _SessionLocal, _db_url
    _db_url = db_url

    async_url = db_url.replace("postgresql://", "postgresql+asyncpg://", 1)

    # asyncpg doesn't understand libpq-style ?sslmode=require — strip it and
    # translate to the native connect_args ssl parameter.
    parsed = urlparse(async_url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    sslmode = params.pop("sslmode", [None])[0]
    clean_url = urlunparse(parsed._replace(query=urlencode({k: v[0] for k, v in params.items()})))

    connect_args: dict = {}
    if sslmode == "require":
        connect_args["ssl"] = "require"
    elif sslmode in ("verify-ca", "verify-full"):
        import ssl
        connect_args["ssl"] = ssl.create_default_context()

    _engine = create_async_engine(clean_url, echo=False, connect_args=connect_args)
    _SessionLocal = sessionmaker(_engine, class_=AsyncSession, expire_on_commit=False)


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    if _SessionLocal is None:
        raise RuntimeError("Database not initialized. GTMAdmin must be instantiated first.")
    async with _SessionLocal() as session:
        yield session


async def run_migrations() -> None:
    """Run Alembic migrations programmatically on startup."""
    from alembic import command
    from alembic.config import Config

    migrations_dir = Path(__file__).parent / "migrations"
    # Pass the async URL directly — env.py normalises it to asyncpg
    async_url = (_db_url or "").replace("postgresql://", "postgresql+asyncpg://", 1)

    cfg = Config()
    cfg.set_main_option("script_location", str(migrations_dir))
    cfg.set_main_option("sqlalchemy.url", async_url)

    loop = asyncio.get_event_loop()
    with concurrent.futures.ThreadPoolExecutor() as executor:
        await loop.run_in_executor(executor, command.upgrade, cfg, "head")
