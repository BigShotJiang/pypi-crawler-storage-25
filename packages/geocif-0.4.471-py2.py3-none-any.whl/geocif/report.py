"""PDF Report Generator for Yield Outlook.

Compiles yield outlook maps, diagnostic plots, agmet graphics, and
model comparison into a single professional PDF report.

Usage::

    from geocif.report import generate_report
    generate_report(dir_outlook, parser, current_year, ...)
"""

import logging
import os
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def _find_images(base_dir, pattern="*.png"):
    """Find all PNGs matching pattern under base_dir, sorted."""
    base = Path(base_dir)
    if not base.exists():
        return []
    return sorted(base.glob(pattern))


def _find_agmet_dir(parser, country, crop, season, year):
    """Locate agmet output directory for a country/crop/season/year."""
    dir_output = Path(parser.get("PATHS", "dir_output"))
    category = parser.get(country, "category", fallback="AMIS")
    crop_short = crop[:2]
    folder = f"{crop_short}_s{season}_{year}"

    # Agmet output uses dated subdirectory — find the latest
    base = dir_output / "crop_condition"
    if not base.exists():
        return None

    dated_dirs = sorted(base.iterdir(), reverse=True)
    for d in dated_dirs:
        candidate = d / "plots" / category / country / folder / "condition"
        if candidate.exists():
            return candidate
        # Also check without the "condition" subfolder
        candidate2 = d / "plots" / category / country / folder
        if candidate2.exists():
            return candidate2

    return None


def generate_report(
    dir_outlook,
    parser,
    current_year,
    countries,
    crops,
    models,
    dir_output=None,
):
    """Generate a PDF report from yield outlook outputs.

    Walks ``dir_outlook`` to collect existing PNGs and assembles them
    into a structured PDF with cover page, sections, and page numbers.

    Args:
        dir_outlook: Path to the outlook output directory.
        parser: ConfigParser with project settings.
        current_year: Forecast year.
        countries: List of country names.
        crops: List of crop names.
        models: List of model names.
        dir_output: Where to save the PDF (default: dir_outlook).
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import inch, cm
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.enums import TA_CENTER, TA_LEFT
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Image as RLImage,
            PageBreak, Table, TableStyle, KeepTogether,
        )
        from reportlab.lib import colors as rl_colors
    except ImportError:
        logger.warning("reportlab not installed — skipping PDF report generation")
        return

    dir_outlook = Path(dir_outlook)
    if dir_output is None:
        dir_output = dir_outlook

    pdf_path = Path(dir_output) / f"yield_outlook_report_{current_year}.pdf"
    logger.info(f"Generating PDF report: {pdf_path}")

    # Page setup
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=A4,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
        leftMargin=1.5 * cm,
        rightMargin=1.5 * cm,
    )
    page_w = A4[0] - 3 * cm
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        "SectionTitle", parent=styles["Heading1"],
        fontSize=16, spaceAfter=12, textColor=rl_colors.HexColor("#1a5276"),
    ))
    styles.add(ParagraphStyle(
        "SubSection", parent=styles["Heading2"],
        fontSize=13, spaceAfter=8, textColor=rl_colors.HexColor("#2e86c1"),
    ))
    styles.add(ParagraphStyle(
        "CoverTitle", parent=styles["Title"],
        fontSize=28, alignment=TA_CENTER, spaceAfter=20,
    ))
    styles.add(ParagraphStyle(
        "CoverSubtitle", parent=styles["Normal"],
        fontSize=14, alignment=TA_CENTER, spaceAfter=8,
        textColor=rl_colors.HexColor("#555555"),
    ))

    elements = []

    def _add_image(path, max_width=None, max_height=None, caption=None):
        """Add an image scaled to fit, preserving aspect ratio."""
        path = Path(path)
        if not path.exists():
            return
        max_w = max_width or page_w
        max_h = max_height or (A4[1] * 0.45)

        # Read actual image size to preserve aspect ratio
        try:
            from PIL import Image as PILImage
            with PILImage.open(path) as pil_img:
                img_w, img_h = pil_img.size
            aspect = img_w / img_h
            # Scale to fit within max_w × max_h
            if max_w / aspect <= max_h:
                w = max_w
                h = max_w / aspect
            else:
                h = max_h
                w = max_h * aspect
        except ImportError:
            # Fallback: use max dims (may distort)
            w, h = max_w, max_h

        img = RLImage(str(path), width=w, height=h)
        elements.append(img)
        if caption:
            elements.append(Spacer(1, 4))
            elements.append(Paragraph(caption, styles["Italic"]))
        elements.append(Spacer(1, 12))

    def _section(title):
        elements.append(PageBreak())
        elements.append(Paragraph(title, styles["SectionTitle"]))
        elements.append(Spacer(1, 8))

    def _subsection(title):
        elements.append(Paragraph(title, styles["SubSection"]))
        elements.append(Spacer(1, 6))

    # ---- Logos ----
    dir_images = Path(parser.get("PATHS", "dir_metadata", fallback="")) / "images"
    logo_harvest = dir_images / parser.get("AGMET", "logo_harvest", fallback="harvest.png")
    logo_geoglam = dir_images / parser.get("AGMET", "logo_geoglam", fallback="geoglam.png")

    # ========================================
    # 1. Cover Page
    # ========================================
    elements.append(Spacer(1, 2 * inch))

    # Logos side by side
    logo_data = []
    for lp in [logo_harvest, logo_geoglam]:
        if lp.exists():
            logo_data.append(RLImage(str(lp), width=1.5 * inch, height=1.5 * inch))
        else:
            logo_data.append("")
    if any(logo_data):
        logo_table = Table([logo_data], colWidths=[page_w / 2] * 2)
        logo_table.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
        elements.append(logo_table)
        elements.append(Spacer(1, 0.5 * inch))

    elements.append(Paragraph("Crop Yield Forecast Report", styles["CoverTitle"]))

    countries_display = [c.title().replace("_", " ") for c in countries]
    crops_display = [c.title().replace("_", " ") for c in crops]

    for line in [
        f"{'  |  '.join(countries_display)}",
        f"{'  |  '.join(crops_display)}",
        f"Models: {', '.join(models)}",
        f"Forecast Year: {current_year}",
        f"Generated by GeoCIF",
    ]:
        elements.append(Paragraph(line, styles["CoverSubtitle"]))

    # ========================================
    # 2. AI Narrative
    # ========================================
    from .narrative import generate_narrative

    # Collect model summary data for the narrative
    for model in models:
        for country in countries:
            country_lower = country.lower().replace(" ", "_")

            # Try to read yield predictions and metrics from the outlook CSV
            csv_files = list(dir_outlook.glob(f"yield_outlook_*_{current_year}.csv"))
            yield_data = {}
            metrics_data = {}
            if csv_files:
                try:
                    df_csv = pd.read_csv(csv_files[0])
                    df_model = df_csv[df_csv["Model"] == model] if "Model" in df_csv.columns else df_csv
                    if "current_predicted" in df_model.columns and "Region" in df_model.columns:
                        yield_data = df_model.set_index("Region")["current_predicted"].to_dict()
                    if "outlook_index" in df_model.columns:
                        metrics_data["Mean Outlook Index"] = df_model["outlook_index"].mean()
                except Exception:
                    pass

            category = parser.get(country, "category", fallback="AMIS")
            paragraphs = generate_narrative(
                country, crop=crops[0] if crops else "maize",
                current_year=current_year,
                yield_data=yield_data,
                metrics=metrics_data,
                category=category,
            )

            if paragraphs:
                _section("Season Assessment")
                for para in paragraphs:
                    elements.append(Paragraph(para, styles["Normal"]))
                    elements.append(Spacer(1, 10))
            break  # one narrative per report
        if paragraphs:
            break

    # ========================================
    # 3. Executive Summary
    # ========================================
    _section("Executive Summary")

    for model in models:
        for country in countries:
            country_lower = country.lower().replace(" ", "_")
            plot_dir = dir_outlook / "plots" / model / country_lower

            # Yield table
            yt = list(plot_dir.glob(f"yield_table_*_{model}.png"))
            if yt:
                _subsection(f"{country.title()} — {model}")
                _add_image(yt[0], caption="Yield forecast summary")

            # Forest plot (CI)
            ci = list(plot_dir.glob(f"yield_ci_*_{model}.png"))
            if ci:
                _add_image(ci[0], caption="Predicted yield with confidence intervals")

    # ========================================
    # 3. Current Season Forecast
    # ========================================
    _section("Current Season Forecast")

    for model in models:
        map_dir = dir_outlook / "maps" / model
        _subsection(f"Model: {model}")

        # Yield outlook map
        outlook_maps = _find_images(map_dir, f"yield_outlook_*_{current_year}.png")
        for m in outlook_maps[:1]:
            _add_image(m, caption="Yield outlook — % departure from historical mean")

        # Predicted yield map
        pred_maps = _find_images(map_dir, f"predicted_yield_*_{current_year}.png")
        for m in pred_maps[:1]:
            _add_image(m, caption="Predicted yield (tn/ha)")

        # Observed anomaly maps
        obs_dir = map_dir / "obs_anomaly"
        if obs_dir.exists():
            for period_dir in sorted(obs_dir.iterdir()):
                if period_dir.is_dir():
                    obs_maps = _find_images(period_dir, f"yield_outlook_*_{current_year}.png")
                    for m in obs_maps[:1]:
                        _add_image(m, caption=f"Observed anomaly — {period_dir.name}")

    # ========================================
    # 4. Model Performance
    # ========================================
    _section("Model Performance")

    for model in models:
        for country in countries:
            country_lower = country.lower().replace(" ", "_")
            plot_dir = dir_outlook / "plots" / model / country_lower
            map_dir = dir_outlook / "maps" / model

            _subsection(f"{country.title()} — {model}")

            # Scatter
            scatter = list(plot_dir.glob(f"scatter_*_{model}.png"))
            if scatter:
                _add_image(scatter[0], caption="Observed vs Predicted yield")

            # MAPE bar
            mape_bar = list(plot_dir.glob(f"mape_bar_*_{model}.png"))
            if mape_bar:
                _add_image(mape_bar[0], caption="MAPE by region")

            # MAPE by year
            mape_year = list(plot_dir.glob(f"mape_year_*_{model}.png"))
            if mape_year:
                _add_image(mape_year[0], caption="MAPE by year")

            # Combined map + MAPE
            combined = list(plot_dir.glob(f"combined_*_{model}.png"))
            if combined:
                _add_image(combined[0], caption="Predicted yield map with MAPE by region")

            # MAPE map
            mape_maps = _find_images(map_dir, f"mape_map_*_{model}.png")
            if mape_maps:
                _add_image(mape_maps[0], caption="MAPE choropleth map")

    # ========================================
    # 5. Multi-Step Progression
    # ========================================
    has_progression = False
    for model in models:
        for country in countries:
            country_lower = country.lower().replace(" ", "_")
            prog_dir = dir_outlook / "plots" / model / country_lower / "progression"
            if prog_dir.exists() and list(prog_dir.glob("*.png")):
                has_progression = True
                break
        if has_progression:
            break

    if has_progression:
        _section("Forecast Skill Progression")

        for model in models:
            for country in countries:
                country_lower = country.lower().replace(" ", "_")
                prog_dir = dir_outlook / "plots" / model / country_lower / "progression"
                if not prog_dir.exists():
                    continue

                _subsection(f"{country.title()} — {model}")

                for metric, caption in [
                    ("mape", "MAPE progression across growing season"),
                    ("r2", "R² progression across growing season"),
                    ("rmse", "RMSE progression across growing season"),
                ]:
                    imgs = _find_images(prog_dir, f"{metric}_progression_*.png")
                    for img in imgs[:1]:
                        _add_image(img, caption=caption)

    # ========================================
    # 6. Model Comparison
    # ========================================
    comp_dir = dir_outlook / "plots" / "model_comparison"
    if comp_dir.exists() and len(models) > 1:
        _section("Model Comparison")

        for country_dir in sorted(comp_dir.iterdir()):
            if not country_dir.is_dir():
                continue

            _subsection(country_dir.name.title())

            # Best model map
            best_map = list(country_dir.glob("best_model_map_*.png"))
            if best_map:
                _add_image(best_map[0], caption="Best model by region (lowest MAPE)")

            # Metric comparisons
            for metric, caption in [
                ("mape", "MAPE comparison"),
                ("rmse", "RMSE comparison"),
                ("r2", "R² comparison"),
            ]:
                by_region = list(country_dir.glob(f"{metric}_by_region_*.png"))
                if by_region:
                    _add_image(by_region[0], caption=f"{caption} by region")

                by_year = list(country_dir.glob(f"{metric}_by_year_*.png"))
                if by_year:
                    _add_image(by_year[0], caption=f"{caption} by year")

    # ========================================
    # 7. Agmet Monitoring
    # ========================================
    agmet_found = False
    for country in countries:
        for crop in crops:
            agmet_dir = _find_agmet_dir(parser, country, crop, 1, current_year)
            if agmet_dir and list(Path(agmet_dir).glob("*.png")):
                agmet_found = True
                break
        if agmet_found:
            break

    if agmet_found:
        _section("Agricultural Meteorology Monitoring")

        for country in countries:
            for crop in crops:
                agmet_dir = _find_agmet_dir(parser, country, crop, 1, current_year)
                if not agmet_dir:
                    continue

                agmet_pngs = sorted(Path(agmet_dir).glob("*.png"))
                if not agmet_pngs:
                    continue

                _subsection(f"{country.title()} — {crop.title()}")

                for png in agmet_pngs:
                    region_name = png.stem.replace("_", " ").title()
                    _add_image(png, caption=f"Agmet monitoring — {region_name}")

    # ========================================
    # 8. Explainability (SHAP)
    # ========================================
    xai_dir = dir_outlook.parent / "xai" if dir_outlook.parent.exists() else None
    if xai_dir and xai_dir.exists():
        shap_pngs = _find_images(xai_dir, "**/*.png")
        if shap_pngs:
            _section("Model Explainability (SHAP)")
            for png in shap_pngs[:10]:
                _add_image(png, caption=png.stem.replace("_", " ").title())

    # ---- Build PDF ----
    try:
        doc.build(elements)
        logger.info(f"Report saved to {pdf_path}")
    except Exception as e:
        logger.error(f"Failed to build PDF report: {e}")
