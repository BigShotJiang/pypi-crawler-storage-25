<div align="center">
<br/>

```
██╗  ██╗██╗   ██╗██████╗ ███████╗██████╗
██║  ██║╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗
███████║ ╚████╔╝ ██████╔╝█████╗  ██████╔╝
██╔══██║  ╚██╔╝  ██╔═══╝ ██╔══╝  ██╔══██╗
██║  ██║   ██║   ██║     ███████╗██║  ██║
╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚══════╝╚═╝  ╚═╝
```

# Hyper-Sentinel

**The terminal to command all markets.**

One AI. Every exchange. Every signal. Execute.

<br/>

[![PyPI](https://img.shields.io/pypi/v/hyper-sentinel?style=flat&logo=pypi&logoColor=white&label=pypi&color=8b5cf6)](https://pypi.org/project/hyper-sentinel/)
[![Python](https://img.shields.io/pypi/pyversions/hyper-sentinel?style=flat&logo=python&logoColor=white&color=8b5cf6)](https://pypi.org/project/hyper-sentinel/)
[![License](https://img.shields.io/github/license/hyper-sentinel/hyper-sentinel-sdk?style=flat&color=8b5cf6)](LICENSE)
[![Downloads](https://img.shields.io/pypi/dm/hyper-sentinel?style=flat&logo=pypi&logoColor=white&label=downloads&color=8b5cf6)](https://pypi.org/project/hyper-sentinel/)

[Website](https://hyper-sentinel.com) · [Docs](https://hyper-sentinel.com/docs) · [API Reference](https://api.hyper-sentinel.com/docs) · [PyPI](https://pypi.org/project/hyper-sentinel/) · [GitHub](https://github.com/hyper-sentinel/hyper-sentinel-sdk)

</div>

---

## Install

```bash
pip install hyper-sentinel
```

Three dependencies. Python 3.10+.

## Launch

```bash
sentinel
```

Paste an API key from any supported AI provider:

| Provider | Get a Key |
|:---------|:----------|
| Anthropic (Claude) | [console.anthropic.com](https://console.anthropic.com) |
| OpenAI (GPT) | [platform.openai.com](https://platform.openai.com) |
| Google (Gemini) | [aistudio.google.com](https://aistudio.google.com) — free tier available |
| xAI (Grok) | [console.x.ai](https://console.x.ai) |

Your AI key is exchanged for a Sentinel API key. Both saved locally to `~/.sentinel/`.

## What You Get

**Live data — no setup required:**

| Source | What |
|--------|------|
| CoinGecko | 10,000+ crypto prices, charts, market caps |
| Yahoo Finance | Stocks, ETFs, analyst recommendations, full quant analysis |
| FRED | GDP, CPI, unemployment, Fed rate, VIX, yield curve |
| DexScreener | DEX pairs, trending tokens, on-chain analytics |

**Connect your exchanges to unlock trading:**

| Venue | What It Unlocks |
|-------|----------------|
| Hyperliquid | Perp futures (crypto + TradFi: GOLD, TSLA, SP500) |
| Aster DEX | Perp futures with leverage |
| Polymarket | Prediction markets |

**Intelligence feeds:**

| Source | What |
|--------|------|
| X / Twitter | Tweet search, sentiment analysis |
| Y2 Intelligence | AI news recaps, sentiment scores |
| Elfa AI | Trending tokens, social mentions |

## Chat

Type what you want. The AI agent has 62+ tools.

```
> What's BTC at?
Sentinel: BTC $84,219 (+1.8%) | Vol $31.2B | MCap $1.67T

> Run a full quant analysis on NVDA
Sentinel: [calls run_stock_analysis]
1. CURRENT PRICE: $847.20 (+2.1%)
2. VALUATION: P/E 58.3 (fwd 42.1), P/S 32.4 ...
[11-section analysis with scores, verdict, entry points]

> Show my Hyperliquid positions
Sentinel:
| Coin | Size  | Entry    | PnL      | ROE    | Leverage |
|------|-------|----------|----------|--------|----------|
| ETH  | 1.2   | $3,840   | +$45.20  | +3.9%  | 3x       |

> Buy 0.01 BTC on Hyperliquid at market
Sentinel: Confirm: BUY 0.01 BTC @ market on Hyperliquid? [y/n]
```

---

## Algo Trading (v0.6.0)

Automated strategies that trade 24/7 on your behalf. Six algorithms, server-side execution, guardrails, and full trade journaling.

**Risk Disclaimer:** Algorithmic trading involves substantial risk of financial loss. No algorithm is guaranteed to produce profits. Always use stop losses and position sizing you can afford to lose.

### Available Algorithms

| Algo | Strategy | Signal |
|------|----------|--------|
| **SMA Crossover** | Trend-following | Fast SMA crosses slow SMA |
| **BB Reversion** | Mean-reversion | Price touches Bollinger Band edges |
| **MACD Momentum** | Momentum | MACD line crosses signal line |
| **EMA Spread** | Reversal | EMA convergence after divergence |
| **RSI + ICT** | Counter-trend | RSI extremes filtered by ICT Kill Zones |
| **Gain EMA** | Configurable | EMA level in trend or reversion mode |

### Quick Start

```python
from sentinel import SentinelClient

client = SentinelClient()

# List available algorithms
client.list_algos()

# Configure
client.strategy_set_algo("sma", params={"fast": 9, "slow": 21})
client.strategy_config(symbol="ETH", venue="hl", leverage=3, trade_usd=20)

# Start (requires auto-execute enabled in guardrails)
client.strategy_start()

# Monitor
status = client.strategy_status()
# {"running": True, "algo": "sma", "current_position": "long", ...}

# Stop
client.strategy_stop()
```

### Via CLI

```bash
sentinel
> strategy                    # view config + status
> strategy set algo bb        # switch to Bollinger Bands
> strategy set leverage 3     # set leverage
> strategy start              # begin trading
> strategy stop               # stop trading
```

### Via Copilot Chat

```
> Start a Bollinger Bands strategy on ETH with $50 trades
> What's my strategy status?
> Switch the algo to RSI + ICT
> Stop the strategy
```

### Guardrails

| Protection | Default | Description |
|-----------|---------|-------------|
| Kill Switch | OFF | Immediately stops all trading |
| Max Trade Size | $500 | Per-trade limit |
| Max Daily Trades | 5 | Pauses after 5 trades/day |
| Max Daily Loss | $1,000 | Pauses if daily P&L hits limit |
| Auto-Execute | OFF | Must be explicitly enabled |

### Position Management

- **Take Profit:** Closes at 1.0% ROE (leverage-adjusted)
- **Stop Loss:** Closes at -2.0% ROE (leverage-adjusted)
- **DCA:** Optional dollar-cost averaging on dips (2% spread, max 3 layers)

---

## Python SDK

```python
from sentinel import SentinelClient

client = SentinelClient()  # auto-loads from ~/.sentinel/

# Market data
client.get_crypto_price("bitcoin")
client.get_stock_price("NVDA")
client.get_economic_dashboard()

# Trading
client.place_hl_order("BTC", "buy", 0.01, order_type="market")
client.get_hl_positions()
client.close_hl_position("ETH")

# Intelligence
client.get_news_sentiment("crypto")
client.get_trending_tokens()
client.search_x("BTC sentiment")

# Algo trading
client.list_algos()
client.strategy_set_algo("macd")
client.strategy_start()
client.strategy_status()
client.strategy_stop()

# Any of the 62+ tools
client.call_tool("get_fred_series", series_id="GDP")
```

## Architecture

```
Your terminal / Your code
         |
  Sentinel SDK (3 deps: httpx, click, rich)
         |
+--------------------------------+
|  Go API Gateway                |
|  Auth | Billing | Rate Limits  |
|  api.hyper-sentinel.com        |
+---------------+----------------+
                |
+---------------v----------------+
|  Python Engine (Cloud Run)     |
|  62+ tools | AI agent          |
|  6 algos | Trade journal       |
|  HL | Aster | Polymarket       |
|  CoinGecko | FRED | X | Y2    |
+--------------------------------+
```

Every call is authenticated, metered, and routed through the gateway. The SDK is a thin REST client — all heavy lifting happens server-side.

## Security

| Key | Purpose | Storage |
|-----|---------|---------|
| **API Key** (`sk-sentinel-xxx`) | Authenticates API calls | Server (hashed) |
| **Secret Key** (`sdg-vault-xxx`) | Encrypts your config vault | Client only — never sent |
| **AI Provider Key** | Forwarded to LLM provider | Never stored on our servers |

Exchange keys are encrypted client-side with AES-256-GCM before leaving your machine.

## Pricing

No feature gating. All tiers get full access to all 62+ tools.

| Tier | Price | LLM Markup | Trade Fees (M/T) | Rate Limit |
|------|-------|-----------|-------------------|------------|
| **Free** | $0 | 40% | 0.10% / 0.07% | 300/min |
| **Pro** | $100/mo | 20% | 0.06% / 0.04% | 1,000/min |
| **Enterprise** | $1,000/mo | 10% | 0.02% / 0.01% | Unlimited |

---

## Links

- **Website**: [hyper-sentinel.com](https://hyper-sentinel.com)
- **Docs**: [hyper-sentinel.com/docs](https://hyper-sentinel.com/docs)
- **API Reference**: [api.hyper-sentinel.com/docs](https://api.hyper-sentinel.com/docs)
- **PyPI**: [pypi.org/project/hyper-sentinel](https://pypi.org/project/hyper-sentinel/)
- **GitHub**: [github.com/hyper-sentinel](https://github.com/hyper-sentinel)

## License

[AGPL-3.0](LICENSE) — 2026 Sentinel Labs LLC

---

<div align="center">
<sub><i>Soli Deo Gloria</i></sub>
</div>
