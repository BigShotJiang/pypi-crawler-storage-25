"""Module defining the Hamming-weight-preserving backend."""

# pylint: disable=W0212

from typing import Dict, List, Optional, Set, Tuple, Union

from numpy.typing import ArrayLike
from scipy.special import binom

from qibo import gates
from qibo.config import raise_error
from qibo.gates.abstract import Gate


def apply_gate(
    self, gate: Gate, state: ArrayLike, nqubits: int, weight: int
) -> ArrayLike:
    """Apply ``gate`` to ``state``.

    Args:
        gate (:class:`qibo.gates.abstract.Gate`): gate to apply to ``state``.
        state (ArrayLike): state to apply ``gate`` to.
        nqubits (int): total number of qubits in ``state``.
        weight (int): fixed Hamming weight of ``state``.

    Returns:
        ArrayLike: ``state`` after the action of ``gate``.
    """
    if isinstance(gate, gates.M):
        return gate.apply_hamming_weight(self, state, nqubits, weight)

    if isinstance(gate, gates.CCZ):
        # CCZ has a custom apply method because currently it is the only
        # 3-qubit gate that is also Hamming-weight-preserving
        # and this custom method is faster than the n-qubit method
        return self._apply_gate_ccz(gate, state, nqubits, weight)

    if len(gate.target_qubits) == 1:
        return self._apply_gate_single_qubit(gate, state, nqubits, weight)

    if len(gate.target_qubits) == 2:
        return self._apply_gate_two_qubit(gate, state, nqubits, weight)

    return self._apply_gate_n_qubit(gate, state, nqubits, weight)


def execute_circuit(
    self,
    circuit,
    weight: int,
    initial_state: Optional[ArrayLike] = None,
    nshots: int = 1000,
):
    """Execute ``circuit`` by applying the queue of gates to the ``initial_state``.

    Args:
        circuit (:class:`qibo.models.circuit.Circuit`): Hamming-weight-preserving circuit
            to be executed.
        weight (int): fixed Hamming weight of the ``initial_state``.
        initial_state (ArrayLike, optional): initial state that ``circuit`` acts on.
            If ``None``, defaults to :math:`\\ket{0^{n-k} \\, 1^{k}}`,
            with :math:`n` being the total number of qubits in the circuit,
            and :math:`k` being the Hamming ``weight``. Defaults to ``None``.
        nshots (int, optional): total number of shots to simulate when ``circuit``
            contains measurement gates (:class:`qibo.gates.M`). Defaults to :math:`1000`.

    Returns:
        :class:`qibo.quantum_info.hamming_weight.HammingWeightResult`: Object
        containing the results of circuit execution of a Hamming-weight-preserving
        circuit.
    """
    from qibo.quantum_info.hamming_weight import (  # pylint: disable=import-outside-toplevel
        HammingWeightResult,
    )

    if circuit.density_matrix:
        raise_error(RuntimeError, "Density matrix simulation is not supported.")

    for gate in circuit.queue:
        if isinstance(gate, gates.Channel):
            raise_error(RuntimeError, "Circuit must not contain channels.")
        if not gate.hamming_weight and not isinstance(gate, gates.M):
            raise_error(
                RuntimeError,
                "Circuit contains non-Hammming weight preserving  gates.",
            )

    nqubits = circuit.nqubits

    self._dict_indexes = self._get_lexicographical_order(nqubits, weight)

    try:
        if initial_state is None:
            n_choose_k = int(binom(nqubits, weight))
            initial_state = self.zeros(n_choose_k)
            initial_state[0] = 1

        state = initial_state
        for gate in circuit.queue:
            state = self.apply_gate(gate, state, nqubits, weight)

        result = HammingWeightResult(
            state,
            weight,
            nqubits,
            measurements=circuit.measurements,
            nshots=nshots,
            platform=self.platform,
        )

        return result

    except self.oom_error:  # pragma: no cover
        raise_error(
            RuntimeError,
            f"State does not fit in {self.device} memory."
            "Please switch the execution device to a "
            "different one using ``qibo.set_device``.",
        )


def _gray_code(self, initial_string: ArrayLike) -> ArrayLike:
    """Return all bitstrings of a fixed Hamming weight.

    Uses the ``ehrlich_algorithm`` with an ``initial_string``.

    Args:
        initial_string (ArrayLike): Array of bits representing the input
            of the Ehrlich algorithm.

    Returns:
        ArrayLike: All bitstrings with the same Hamming weight as ``initial_string``.
    """
    from qibo.models._encodings import _ehrlich_algorithm  # pylint: disable=C0415

    strings = _ehrlich_algorithm(initial_string, return_indices=False)
    strings = [[int(b) for b in string] for string in strings]
    strings = self.cast(strings, dtype=self.int64)

    return strings


def _get_cached_strings(
    self, nqubits: int, weight: int, ncontrols: int = 0, two_qubit_gate: bool = True
) -> Union[ArrayLike, List[ArrayLike]]:
    """Generate list of strings necessary for the custom ``apply_gate`` method.

    Given the total number of qubits ``nqubits``, the Hamming ``weight`` to be
    preserved, and the number of controls ``ncontrols`` in the gate, returns a
    sequence of bitstrings for the custom ``apply_gate`` method.

    The sequence is generated for the first gate with a unique combination of ``nqubits``,
    ``weight`` and ``ncontrols``, and then cached to be resued for similar gates.

    Args:
        nqubits (int): total number of qubits in the quantum system.
        weight (int): Hamming weight of the state that gates are acting on.
        ncontrols (int, optional): number of controls in the gate that is being
            applied to the state. Defaults to :math:`0`.
        two_qubit_gate (bool, optional): if ``True``, generate strings assuming the
            gate is a two-qubit gate. If ``False``, it assumes the gate is a single-qubit
            gate. Defaults to ``True``.

    Returns:
        ArrayLike or List[int]: Bitstrings for two-qubit gates or a list of two arrays
        of bitstrings for single-qubit gates.
    """
    if two_qubit_gate:
        initial_string = self.cast(
            [1] * (weight - 1 - ncontrols)
            + [0] * ((nqubits - 2 - ncontrols) - (weight - 1 - ncontrols)),
            dtype=self.int64,
        )
        strings = self._gray_code(initial_string)
    else:
        initial_string = self.cast(
            [1] * (weight - ncontrols)
            + [0] * ((nqubits - 1 - ncontrols) - (weight - ncontrols)),
            dtype=self.int64,
        )
        strings_0 = self._gray_code(initial_string)

        initial_string = self.cast(
            [1] * (weight - 1 - ncontrols)
            + [0] * ((nqubits - 1 - ncontrols) - max(0, (weight - 1 - ncontrols))),
            dtype=self.int64,
        )
        strings_1 = self._gray_code(initial_string)

        strings = [strings_0, strings_1]

    return strings


def _cast_value_to_str(self, value):
    return (
        str(value.item())
        if self.name == "hamming_weight" and self.platform == "pytorch"
        else str(value)
    )


def _get_lexicographical_order(
    self, nqubits: int, weight: int
) -> Dict[str, Tuple[int, ...]]:
    """Sort bistrings generated from ``self._get_cached_strings`` in lexicographical order.

    Bitstrings are sorted in lexicographical (ascending) order.
    Moreover, they are also converted to integers and both representations are cached,
    creating a map between the full statevector representation and the condensed
    Hamming-weight-preserving representation.

    Args:
        nqubits (int): total number of qubits.
        weight (int): Hamming weight of the state.

    Returns:
        dict: Dictionary with the cached bitstrings and the aforementioned map.
    """
    n_choose_k = int(binom(nqubits, weight))
    indexes = list(range(n_choose_k))

    lexicographical_order = self._get_cached_strings(nqubits + 2, weight + 1)
    lexicographical_order = [
        "".join(self._cast_value_to_str(elem) for elem in item)
        for item in lexicographical_order
    ]
    lexicographical_order.sort()
    lexicographical_order_int = [int(item, base=2) for item in lexicographical_order]
    _dict_indexes = dict(
        zip(lexicographical_order, zip(indexes, lexicographical_order_int))
    )

    return _dict_indexes


def _get_single_qubit_matrix(self, gate: Gate) -> Tuple[complex, ...]:
    """Return non-zero elements of the matrix representation of
    Hamming-weight-preserving single-qubit gates.

    Args:
        gate (:class:`qibo.gates.abstract.Gate`): Hamming-weight-preserving
            single-qubit gate.

    Returns:
        tuple(complex, complex): Non-zero elements of a Hamming-weight-preserving ``gate``.
    """
    matrix = gate.matrix(backend=self)

    if gate.name in ["cz", "crz", "cu1"]:
        matrix = matrix[2:, 2:]

    return self.diag(matrix)


def _apply_gate_single_qubit(
    self, gate: Gate, state: ArrayLike, nqubits: int, weight: int
) -> ArrayLike:
    """Custom ``apply_gate`` method for Hamming-weight-preserving single-qubit gates.

    Instead of relying on matrix multiplication, this method applies
    Hamming-weight-preserving single-qubit gates by directly multiplying
    the amplitudes of interest elementwise by the necessary phase(s).

    Args:
        gate (:class:`qibo.gates.abstract.Gate`): Hamming-weight-preserving
            single-qubit gate to be applied to ``state``
        state (ArrayLike): state to suffer the action of ``gate``.
        nqubits (int): total number of qubits in the circuit.
        weight (int): Hamming weight of ``state``.

    Returns:
        ArrayLike: ``state`` after the action of ``gate``.
    """
    qubits = list(gate.target_qubits)
    controls = list(gate.control_qubits)
    ncontrols = len(controls)
    other_qubits = list(set(range(nqubits)) ^ set(qubits + controls))

    key_0, key_1 = f"{ncontrols}_0", f"{ncontrols}_1"
    if (
        key_0 not in self._dict_cached_strings_one
        or key_1 not in self._dict_cached_strings_one
    ):
        strings_0, strings_1 = self._get_cached_strings(
            nqubits, weight, ncontrols, False
        )
        self._dict_cached_strings_one[key_0] = strings_0
        self._dict_cached_strings_one[key_1] = strings_1
    else:
        strings_0 = self._dict_cached_strings_one[key_0]
        strings_1 = self._dict_cached_strings_one[key_1]

    matrix_00, matrix_11 = self._get_single_qubit_matrix(gate)

    indexes_one = self.zeros((len(strings_1), nqubits), dtype=self.int64)

    if matrix_00 != 1.0 and nqubits - weight > 0:
        indexes_zero = self.zeros((len(strings_0), nqubits), dtype=self.int64)
        indexes_zero[:, other_qubits] = strings_0
        indexes_zero[:, qubits] = [0]
        if len(controls) > 0:
            indexes_zero[:, controls] = 1
        indexes_zero = self.cast(
            [
                self._dict_indexes["".join(str(e) for e in elem)][0]
                for elem in indexes_zero
            ],
            dtype=self.int64,
        )

        state[indexes_zero] *= matrix_00

    if matrix_11 != 1.0 and weight - ncontrols > 0:
        indexes_one[:, other_qubits] = strings_1
        if len(controls) > 0:
            indexes_one[:, controls] = 1

        indexes_one[:, qubits] = [1]
        indexes_one = self.cast(
            [
                self._dict_indexes["".join(str(e) for e in elem)][0]
                for elem in indexes_one
            ],
            dtype=self.int64,
        )

        state[indexes_one] *= matrix_11

    return state


def _update_amplitudes(
    self,
    state: ArrayLike,
    qubits: List[int],
    controls: List[int],
    other_qubits: List[int],
    weight: int,
    matrix_element: Union[complex, float],
    bitlist: List[str],
    shift: int,
) -> ArrayLike:
    """Update in-place the amplitudes changed by a two-qubit Hamming-weight-preserving gate.

    Args:
        state (ArrayLike): state that the two-qubit gate acts on.
        qubits (list): target qubits of the gate.
        controls (list): control qubits of the gate.
        other_qubits (list): remaining qubits in the circuit.
        weight (int): Hamming weight of ``state``.
        matrix_element (complex or float): non-zero element of the gate that
            multiplies the amplitudes of ``state``.
        bitlist (list): If the amplitude being updated is associated to the computational basis
            state :math:`\\ket{\\dots00\\dots}`, then ``bitlist=["0", "0"]``.
            If the amplitude is associated to :math:`\\ket{\\dots11\\dots}`,
            then ``bitlist=["1", "1"]``.
        shift (int): shift in the Hamming weight necessary to generate bitstrings.
            If the amplitude being updated is associated to the computational basis
            state :math:`\\ket{\\dots00\\dots}`, then ``shift`` is :math:`1`.
            If the amplitude is associated to :math:`\\ket{\\dots11\\dots}`,
            then ``shift`` is :math:`-1`.

    Returns:
        ArrayLike: ``state`` after the action of two-qubit Hamming-weight-preserving gate.
    """
    ncontrols = len(controls)
    nqubits = len(qubits) + ncontrols + len(other_qubits)

    strings = self._get_cached_strings(nqubits, weight + shift, ncontrols)
    indexes_in = self.zeros((len(strings), nqubits), dtype=self.int64)
    indexes_in[:, other_qubits] = strings
    if ncontrols > 0:
        indexes_in[:, controls] = 1
    indexes_in[:, qubits] = bitlist
    indexes_in = self.cast(
        [self._dict_indexes["".join(str(e) for e in elem)][0] for elem in indexes_in],
        dtype=self.int64,
    )
    state[indexes_in] *= matrix_element

    return state


def _apply_gate_two_qubit(
    self, gate: Gate, state: ArrayLike, nqubits: int, weight: int
) -> ArrayLike:
    """Custom ``apply_gate`` method for Hamming-weight-preserving two-qubit gates.

    Instead of relying on matrix multiplication, this method applies
    Hamming-weight-preserving two-qubit gates by directly multiplying
    the amplitudes of interest elementwise by the necessary phase(s).

    Args:
        gate (:class:`qibo.gates.abstract.Gate`): Hamming-weight-preserving
            two-qubit gate to be applied to ``state``
        state (ArrayLike): state to suffer the action of ``gate``.
        nqubits (int): total number of qubits in the circuit.
        weight (int): Hamming weight of ``state``.

    Returns:
        ArrayLike: ``state`` after the action of ``gate``.
    """
    qubits = list(gate.target_qubits)
    controls = list(gate.control_qubits)
    ncontrols = len(controls)
    other_qubits = list(set(list(range(nqubits))) ^ set(qubits + controls))

    key = f"{ncontrols}"
    if key not in self._dict_cached_strings_two:
        self._dict_cached_strings_two[key] = self._get_cached_strings(
            nqubits, weight, ncontrols
        )
    strings = self._dict_cached_strings_two[key]

    matrix = gate.matrix(backend=self)
    matrix_0000, matrix_1111 = matrix[0, 0], matrix[3, 3]
    matrix_0101, matrix_0110 = matrix[1, 1], matrix[1, 2]
    matrix_1001, matrix_1010 = matrix[2, 1], matrix[2, 2]

    if weight - ncontrols > 0 and weight not in [0, nqubits]:
        indexes_in = self.zeros((len(strings), nqubits), dtype=self.int64)

        strings_t = self.cast(strings, dtype=self.int64)
        pair_10 = self.cast([1, 0], dtype=self.int64)
        pair_01 = self.cast([0, 1], dtype=self.int64)

        indexes_in[:, other_qubits] = strings_t
        if len(controls) > 0:
            indexes_in[:, controls] = 1
        indexes_in[:, qubits] = pair_10

        indexes_out = self.cast(indexes_in, dtype=indexes_in.dtype, copy=True)
        indexes_out[:, qubits] = pair_01

        indexes_in = self.cast(
            [
                (
                    self._dict_indexes[
                        "".join(self._cast_value_to_str(e) for e in elem)
                    ][0]
                )
                for elem in indexes_in
            ],
            dtype=self.int64,
        )
        indexes_out = self.cast(
            [
                (
                    self._dict_indexes[
                        "".join((self._cast_value_to_str(e)) for e in elem)
                    ][0]
                )
                for elem in indexes_out
            ],
            dtype=self.int64,
        )

        old_in, old_out = state[indexes_in], state[indexes_out]
        new_amplitudes_in = matrix_1010 * old_in + matrix_1001 * old_out
        new_amplitudes_out = matrix_0101 * old_out + matrix_0110 * old_in

        state[indexes_in] = new_amplitudes_in
        state[indexes_out] = new_amplitudes_out

    if (
        weight - ncontrols >= 0
        and nqubits - weight > 1
        and (matrix_0000.real != 1 or abs(matrix_0000.imag) > 0)
    ):
        # update the |...00...> amplitudes if necessary
        state = self._update_amplitudes(
            state,
            qubits,
            controls,
            other_qubits,
            weight,
            matrix_0000,
            ["0", "0"],
            shift=1,
        )

    if weight - ncontrols > 1 and (matrix_1111.real != 1 or abs(matrix_1111.imag) > 0):
        # update the |...11...> amplitudes if necessary
        state = self._update_amplitudes(
            state,
            qubits,
            controls,
            other_qubits,
            weight,
            matrix_1111,
            ["1", "1"],
            shift=-1,
        )

    return state


def _apply_gate_ccz(
    self, gate: Gate, state: ArrayLike, nqubits: int, weight: int
) -> ArrayLike:
    """Custom ``apply_gate`` method for the :class:`qibo.gates.CCZ` gate.

    Args:
        gate (:class:`qibo.gates.CCZ`): :math:`2`-controlled :math:`Z` gate
            to be applied to ``state``.
        state (ArrayLike): state to suffer the action of ``gate``.
        nqubits (int): total number of qubits in the circuit.
        weight (int): Hamming-weight of ``state``.

    Returns:
        ArrayLike: ``state`` after the action of the :class:`qibo.gates.CCZ` gate.
    """
    qubits = list(gate.qubits)
    gate_qubits = len(qubits)

    self._dict_indexes = self._get_lexicographical_order(nqubits, weight)

    strings = list(self._dict_indexes.keys())

    for j in range(len(strings)):
        gate_string = [strings[j][q] for q in qubits]
        if gate_string.count("1") == gate_qubits:
            state[j] *= -1

    return state


def _apply_gate_n_qubit(
    self, gate: Gate, state: ArrayLike, nqubits: int, weight: int
) -> ArrayLike:
    """Custom ``apply_gate`` method for Hamming-weight-preserving n-qubit gates.

    This method performs matrix multiplication directly in the subspace with Hamming-weight
    ``weight`` without the need to calculate the full matrix representation of the gate.

    .. note::
        The attribute ``gate.hamming_weight`` must be manually set to ``True``
        for this method to work.

    Args:
        gate (:class:`qibo.gates.abstract.Gate`): Hamming-weight-preserving
            :math:`n`-qubit gate to be applied to ``state``
        state (ArrayLike): state to suffer the action of ``gate``.
        nqubits (int): total number of qubits in the circuit.
        weight (int): Hamming weight of ``state``.

    Returns:
        ArrayLike: ``state`` after the action of ``gate``.
    """
    gate_matrix = gate.matrix(backend=self)
    qubits = list(gate.target_qubits)
    gate_qubits = len(qubits)
    if 2**gate_qubits != gate_matrix.shape[0]:
        qubits = list(gate.qubits)
        gate_qubits = len(qubits)
        controls = []
    else:
        controls = list(gate.control_qubits)

    if gate.is_controlled_by and len(controls) > 0:
        ncontrols = len(controls)
        ntargets = gate_qubits
        full_dim = 2 ** (ntargets + ncontrols)
        ctrl_mask = (1 << ncontrols) - 1
        expanded_matrix = self.identity(full_dim, dtype=gate_matrix.dtype)

        for trow in range(2**ntargets):
            row_index = (trow << ncontrols) | ctrl_mask
            for tcol in range(2**ntargets):
                col_index = (tcol << ncontrols) | ctrl_mask
                expanded_matrix[row_index, col_index] = gate_matrix[trow, tcol]
        gate_matrix = expanded_matrix

    active_qubits = qubits + controls
    k = len(active_qubits)

    if len(set(active_qubits)) != k:  # pragma: no cover
        raise_error(ValueError, "Duplicate qubit indices in active_qubits")

    self._dict_indexes = self._get_lexicographical_order(nqubits, weight)
    key = (tuple(sorted(active_qubits)), tuple(controls), nqubits, weight)

    if key not in self._transition_cache:
        strings = list(self._dict_indexes.keys())
        basis = self.cast([list(map(int, s)) for s in strings], dtype=self.int8)

        powers_full = 1 << self.arange(nqubits)
        encoded_basis = (basis * powers_full).sum(axis=1)

        sort_idx = self.argsort(encoded_basis)
        encoded_basis_sorted = encoded_basis[sort_idx]

        active_bits = basis[:, active_qubits]
        local_indices = active_bits.dot(1 << self.arange(k - 1, -1, -1))

        patterns = (self.arange(2**k)[:, None] >> self.arange(k - 1, -1, -1)) & 1

        active_hw = active_bits.sum(axis=1)
        pattern_hw = patterns.sum(axis=1)
        valid_mask = pattern_hw[None, :] == active_hw[:, None]

        powers_active = powers_full[active_qubits]
        active_contrib = active_bits.dot(powers_active)
        base_encoded = encoded_basis - active_contrib
        pattern_encoded = patterns.dot(powers_active)
        encoded = base_encoded[:, None] + pattern_encoded[None, :]

        valid_idx = self.where(valid_mask)
        valid_encoded = encoded[valid_idx]

        indices_in_sorted = self.searchsorted(encoded_basis_sorted, valid_encoded)

        transitions = -self.ones(encoded.shape, dtype=self.int64)
        transitions[valid_idx] = sort_idx[indices_in_sorted]

        valid_mask_flat = transitions >= 0
        rows, cols = self.where(valid_mask_flat)
        target_indices = transitions[rows, cols]

        self._transition_cache[key] = transitions
        self._local_index_cache[key] = local_indices
        self._flat_cache[key] = (rows, cols, target_indices)

    transitions = self._transition_cache[key]
    local_indices = self._local_index_cache[key]
    rows, cols, target_indices = self._flat_cache[key]

    d = state.shape[0]
    new_state = self.zeros(d, dtype=state.dtype)

    state = self.ascontiguousarray(state)

    coeffs = gate_matrix[cols, local_indices[rows]]
    values = coeffs * state[rows]

    self.add_at(new_state, target_indices, values)

    return new_state


def calculate_symbolic(
    self,
    state: ArrayLike,
    nqubits: int,
    weight: int,
    decimals: int = 5,
    cutoff: float = 1e-10,
    max_terms: int = 20,
) -> str:
    """Dirac notation representation of the state in the computational basis.

    Args:
        state (ArrayLike): state to suffer the action of ``gate``.
        nqubits (int): total number of qubits in the circuit.
        weight (int): Hamming-weight of ``state``.
        decimals (int, optional): Number of decimals for the amplitudes.
            Defaults to :math:`5`.
        cutoff (float, optional): Amplitudes with absolute value smaller than the
            cutoff are ignored from the representation. Defaults to  :math:`1e-10`.
        max_terms (int, optional): Maximum number of terms to print. If the state
            contains more terms they will be ignored. Defaults to :math:`20`.

    Returns:
        str: String representing the state in the computational basis.
    """
    terms = []

    self._dict_indexes = self._get_lexicographical_order(nqubits, weight)

    strings = list(self._dict_indexes.keys())
    for elem in self.nonzero(state)[0]:
        elem = int(elem)
        b = strings[elem]
        if self.abs(state[elem]) >= cutoff:
            x = self.round(state[elem], decimals=decimals)
            terms.append(f"{x}|{b}>")
        if len(terms) >= max_terms:
            terms.append("...")
            return terms
    return terms


def calculate_probabilities(
    self,
    state: ArrayLike,
    qubits: Union[List[int], Tuple[int, ...], Set[int]],
    weight: int,
    nqubits: int,
) -> ArrayLike:
    """Calculate the probabilities of the measured qubits from the statevector.

    Args:
        state (ArrayLike): state to suffer the action of ``gate``.
        qubits (list or tuple or set, optional): qubits that are measured.
        weight (int): Hamming-weight of ``state``.
        nqubits (int): total number of qubits in the circuit.

    Returns:
        ArrayLike: Probabilities over the input qubits.
    """
    rtype = self.real(state).dtype

    self._dict_indexes = self._get_lexicographical_order(nqubits, weight)

    strings = list(self._dict_indexes.keys())
    indexes = [index[0] for index in self._dict_indexes.values()]

    measured_strings = {}
    for string, index in zip(strings, indexes):
        measured_string = "".join(string[q] for q in qubits)
        measured_strings[measured_string] = measured_strings.get(
            measured_string, 0
        ) + self.real(self.abs(state[index]) ** 2)

    strings = list(measured_strings.keys())
    indexes = [int(string, 2) for string in strings]
    probs = self.zeros(2 ** len(qubits), dtype=rtype)
    for index, string in zip(indexes, strings):
        probs[index] = measured_strings[string]
    return probs


def collapse_state(
    self,
    state: ArrayLike,
    qubits: Union[List[int], Tuple[int, ...], Set[int]],
    shot: List[int],
    weight: int,
    nqubits: int,
    normalize: bool = True,
) -> ArrayLike:
    """Collapse state vector according to measurement shot.

    Args:
        state (ArrayLike): state to suffer the action of ``gate``.
        qubits (list or tuple or set, optional): qubits that are measured.
        shot (list): Decimal value of the bitstring measured.
        weight (int): Hamming-weight of ``state``.
        nqubits (int): total number of qubits in the circuit.

    Returns:
        ArrayLike: collapsed ``state``.
    """
    self._dict_indexes = self._get_lexicographical_order(nqubits, weight)

    strings = list(self._dict_indexes.keys())
    indexes = [index[0] for index in self._dict_indexes.values()]
    binshot = self.samples_to_binary(shot, len(qubits))[0]
    binshot = "".join(str(s) for s in binshot)
    for string, index in zip(strings, indexes):
        if "".join(string[q] for q in qubits) != binshot:
            state[index] = 0

    if normalize:
        norm = self.sqrt(self.sum(self.abs(state) ** 2))
        state = state / norm

    return state
