"""Bloch sphere module."""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Union

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d
from numpy.typing import ArrayLike

from qibo.backends.abstract import Backend
from qibo.config import raise_error
from qibo.hamiltonians import SymbolicHamiltonian
from qibo.symbols import X, Y, Z


class Arrow3D(FancyArrowPatch):
    """This class creates the arrows for the Bloch sphere."""

    def __init__(self, xs, ys, zs, *args, **kwargs):
        super().__init__((0, 0), (0, 0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def do_3d_projection(self) -> float:
        """This function performs the 3D projection of the arrow rendering.

        This method is automatically called by Matplotlib's 3D axis
        to transform the arrow's 3D coordinates into 2D screen coordinates,
        handling perspective and position for correct display.
        """
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, self.axes.M)
        self.set_positions((xs[0], ys[0]), (xs[1], ys[1]))

        return np.min(zs)


@dataclass
class BlochSphere:
    """This class creates a Bloch sphere."""

    @staticmethod
    def _make_style() -> dict:
        _style = {
            "figure.figsize": (6, 6),
            "lines.linewidth": 0.9,
        }
        return _style

    @staticmethod
    def _make_style_text() -> dict:
        return {"text.color": "black", "font.size": 19}

    # Plot style sheets
    style_text: dict = field(default_factory=_make_style_text)
    style: dict = field(default_factory=_make_style)

    # Data
    _points: list = field(default_factory=list)
    _vectors: list = field(default_factory=list)

    # Color data
    _color_points: list = field(default_factory=list)
    _color_vectors: list = field(default_factory=list)

    _shown: bool = False

    _numpy_backend: Optional[Backend] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        # No toolbar
        mpl.rcParams["toolbar"] = "None"

        # Figure
        self.fig = plt.figure(figsize=self.style["figure.figsize"])
        self.ax = self.fig.add_subplot(projection="3d", elev=30, azim=30)

        # Title of the window
        self.fig.canvas.manager.set_window_title("Bloch sphere")

    def _new_window(self) -> None:
        """It creates a new Figure object and it adds to it a new Axis."""
        self.fig = plt.figure(figsize=self.style["figure.figsize"])
        self.ax = self.fig.add_subplot(projection="3d", elev=30, azim=30)
        self.fig.canvas.manager.set_window_title("Bloch sphere")

    # -----Sphere-----
    def _sphere_surface(self) -> Tuple[float, ...]:
        """Helper method to `_create_sphere` to construct the sphere's surface"""
        phi, theta = np.mgrid[0.0 : np.pi : 100j, 0.0 : 2.0 * np.pi : 100j]
        x = np.sin(phi) * np.cos(theta)
        y = np.sin(phi) * np.sin(theta)
        z = np.cos(phi)
        return x, y, z

    def _axis(self) -> Tuple[float, ...]:
        """Helper method to `_create_sphere` to construct the sphere's axis."""
        theta = np.linspace(0, 2 * np.pi, 100)
        z = np.zeros(100)
        x = np.sin(theta)
        y = np.cos(theta)
        return x, y, z

    def _parallel(self, z: float) -> Tuple[float, ...]:
        """Helper method to `_create_sphere` to construct the sphere's parallels."""
        theta = np.linspace(0, 2 * np.pi, 100)
        z = np.full(100, z)
        r = np.sqrt(1 - z[0] ** 2)
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        return x, y, z

    def _meridian(self, phi: float) -> Tuple[float, ...]:
        """Helper method to `_create_sphere` to construct the sphere's meridians."""
        theta = np.linspace(0, 2 * np.pi, 100)
        x = np.sin(theta) * np.cos(phi)
        y = np.sin(theta) * np.sin(phi)
        z = np.cos(theta)
        return x, y, z

    def _create_sphere(self) -> None:
        "This function builds an empty Bloch sphere."

        # Empty sphere
        self.ax.plot_surface(*self._sphere_surface(), color="lavenderblush", alpha=0.2)

        # Axis
        x, y, z = self._axis()
        combinations_axis = [(x, y, z), (z, x, y), (y, z, x)]

        # Axis lines
        line, zeros = np.linspace(-1, 1, 100), np.zeros(100)
        combinations_axis_line = [
            (line, zeros, zeros),
            (zeros, line, zeros),
            (zeros, zeros, line),
        ]

        # Meridian and Parallel
        phi = [(n + 1) * np.pi / 3 for n in range(6)]
        lat = (0.4, -0.4, 0.9, -0.9)
        meridian = lambda x: self.ax.plot(*self._meridian(x), color="darkgrey")
        parallel = lambda x: self.ax.plot(*self._parallel(x), color="darkgrey")

        # Axis, Axis lines, Meridians, Parallels
        with mpl.rc_context(self.style):
            _ = [
                self.ax.plot(*combinations_axis[i], color="darkgrey") for i in range(3)
            ]
            _ = [
                self.ax.plot(*combinations_axis_line[i], color="darkgrey")
                for i in range(3)
            ]
            _ = [meridian(p) for p in phi]
            _ = [parallel(l) for l in lat]

        # Text
        with mpl.rc_context(self.style_text):
            self.ax.text(1.2, 0, 0, "x", ha="center")
            self.ax.text(0, 1.2, 0, "y", ha="center")
            self.ax.text(0, 0, 1.2, r"$|0\rangle$", ha="center")
            self.ax.text(0, 0, -1.3, r"$|1\rangle$", ha="center")

    # -----States and Vectors-----
    def _paulis_expectation(self, state: ArrayLike) -> Tuple[float, ...]:
        """This function computes the expectation value of Pauli matrices
        on the considered state and yields its cartesian coordinates on the Bloch sphere.
        """
        if self._numpy_backend is None:
            from qibo.backends.numpy import NumpyBackend  # pylint: disable=C0415

            self._numpy_backend = NumpyBackend()

        sigma_x = SymbolicHamiltonian(
            X(0, backend=self._numpy_backend), backend=self._numpy_backend
        )
        sigma_y = SymbolicHamiltonian(
            Y(0, backend=self._numpy_backend), backend=self._numpy_backend
        )
        sigma_z = SymbolicHamiltonian(
            Z(0, backend=self._numpy_backend), backend=self._numpy_backend
        )

        x = sigma_x.expectation_from_state(state)
        y = sigma_y.expectation_from_state(state)
        z = sigma_z.expectation_from_state(state)
        return x, y, z

    def _is_density_matrix(self, rho: ArrayLike) -> bool:
        """This function is used only to check whether an input of shape (2,2)
        is two state vectors or one density matrix."""
        return np.allclose(rho, rho.conj().T) and np.isclose(np.trace(rho), 1)

    def _broadcasting_semantics(
        self, vector: ArrayLike, mode: Union[list, str], color: Union[list, str]
    ) -> Tuple[ArrayLike, ...]:
        """This function makes sure that `vector`, `mode`, `color` have the same sizes."""
        if isinstance(vector, list):
            vector = np.array(vector)
        if isinstance(mode, (list, str)):
            mode = np.array(mode)
        if isinstance(color, (list, str)):
            color = np.array(color)

        # Check to distinguish if (2,2) is one density matrix or two state vectors.
        if vector.ndim == 2 and vector.shape == (2, 2):
            if self._is_density_matrix(vector):
                vector = np.expand_dims(vector, axis=0)

        vector = np.atleast_2d(vector)
        vector, mode, color = np.broadcast_arrays(vector, mode, color)
        return vector, mode.flatten(), color.flatten()

    def add_vector(
        self,
        vector: ArrayLike,
        mode: Union[str, List[str]] = "vector",
        color: Union[str, List[str]] = "black",
    ) -> None:
        """This function adds a vector to the sphere."""

        vectors, modes, colors = self._broadcasting_semantics(vector, mode, color)
        for _vector, _color, _mode in zip(vectors, colors, modes):
            if _mode not in ("vector", "point"):
                raise_error(ValueError, "Mode not supported. Try: `point` or `vector`.")
            if _mode == "vector":
                self._vectors.append(_vector)
                self._color_vectors.append(_color)
            else:
                self._points.append(_vector)
                self._color_points.append(_color)

    def add_state(
        self,
        state: ArrayLike,
        mode: Union[str, list[str]] = "vector",
        color: Union[str, list[str]] = "black",
    ) -> None:
        """This function adds a state to the sphere."""

        vectors, modes, colors = self._broadcasting_semantics(state, mode, color)
        for _vector, _color, _mode in zip(vectors, colors, modes):
            if _mode not in ("vector", "point"):
                raise_error(ValueError, "Mode not supported. Try: `point` or `vector`.")

            x, y, z = self._paulis_expectation(_vector)

            if _mode == "vector":
                self._vectors.append(np.array([x, y, z]))
                self._color_vectors.append(_color)
            else:
                self._points.append(np.array([x, y, z]))
                self._color_points.append(_color)

    # -----Clear and produce the sphere-----
    def clear(self) -> None:
        """This function clears the sphere."""
        plt.close()
        self._new_window()

        # Clear data
        self._points = []
        self._vectors = []

        # Clear Color
        self._color_points = []
        self._color_vectors = []

        self.render()

    def render(self) -> None:
        """This function creates the empty sphere and plots the
        vectors and points on it."""
        if self._shown is True:
            plt.close()
            self._new_window()
        self._shown = True

        self._create_sphere()

        for color, vector in zip(self._color_vectors, self._vectors):
            xs3d = vector[0] * np.array([0, 1])
            ys3d = vector[1] * np.array([0, 1])
            zs3d = vector[2] * np.array([0, 1])
            a = Arrow3D(
                xs3d,
                ys3d,
                zs3d,
                lw=2.0,
                arrowstyle="-|>",
                mutation_scale=20,
                color=color,
            )
            self.ax.add_artist(a)

        for color, point in zip(self._color_points, self._points):
            self.ax.scatter(point[0], point[1], point[2], color=color, s=10)

        self.ax.set_xlim([-0.7, 0.7])
        self.ax.set_ylim([-0.7, 0.7])
        self.ax.set_zlim([-0.7, 0.7])
        self.ax.set_aspect("equal")
        self.ax.axis("off")
        self.fig.tight_layout()
