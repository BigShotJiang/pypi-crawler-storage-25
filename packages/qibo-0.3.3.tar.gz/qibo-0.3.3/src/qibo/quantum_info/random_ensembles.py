"""Module with functions that create random quantum and classical objects."""

import math
import warnings
from typing import Optional, Union

import numpy as np
from numpy.typing import DTypeLike
from scipy.stats import rv_continuous

from qibo import Circuit, gates
from qibo.backends import Backend, _check_backend, _check_backend_and_local_state
from qibo.config import MAX_ITERATIONS, PRECISION_TOL, raise_error
from qibo.quantum_info.basis import comp_basis_to_pauli
from qibo.quantum_info.clifford import Clifford
from qibo.quantum_info.superoperator_transformations import (
    choi_to_chi,
    choi_to_kraus,
    choi_to_liouville,
    choi_to_pauli,
    choi_to_stinespring,
    vectorization,
)


class _ProbabilityDistributionGaussianLoader(rv_continuous):
    """Probability density function for sampling phases of
    the RBS gates as a function of circuit depth."""

    def _pdf(self, theta: float, depth: int):
        amplitude = 2 * math.gamma(2 ** (depth - 1)) / math.gamma(2 ** (depth - 2)) ** 2

        probability = abs(math.sin(theta) * math.cos(theta)) ** (2 ** (depth - 1) - 1)

        return amplitude * probability / 4


class _probability_distribution_sin(rv_continuous):  # pragma: no cover
    def _pdf(self, theta: float):
        return 0.5 * np.sin(theta)

    def _cdf(self, theta: float):
        return np.sin(theta / 2) ** 2

    def _ppf(self, theta: float):
        return 2 * np.arcsin(np.sqrt(theta))


def uniform_sampling_U3(
    ngates: int, seed: Optional[int] = None, backend: Optional[Backend] = None
):
    """Samples parameters for Haar-random :class:`qibo.gates.U3`.

    Args:
        ngates (int): Total number of :math:`U_{3}` gates to be sampled.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of random
            numbers or a fixed seed to initialize a generator. If ``None``, initializes
            a generator with a random seed. Default: ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: array of shape (``ngates``, :math:`3`).
    """
    if not isinstance(ngates, int):
        raise_error(
            TypeError, f"ngates must be type int, but it is type {type(ngates)}."
        )

    if ngates <= 0:
        raise_error(ValueError, f"ngates must be non-negative, but it is {ngates}.")

    backend = _check_backend(backend)

    # necessary to use numpy rng explicitly because of scipy
    local_state = (
        np.random.default_rng(seed) if seed is None or isinstance(seed, int) else seed
    )

    sampler = _probability_distribution_sin(a=0, b=np.pi, seed=local_state)
    phases = local_state.random((ngates, 3))
    phases[:, 0] = sampler.rvs(size=len(phases[:, 0]))
    phases[:, 1] = phases[:, 1] * 2 * np.pi
    phases[:, 2] = phases[:, 2] * 2 * np.pi

    phases = backend.cast(phases, dtype=phases.dtype)

    return phases


def random_gaussian_matrix(
    dims: int,
    rank: Optional[int] = None,
    mean: float = 0.0,
    stddev: float = 1.0,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Generates a random Gaussian Matrix.

    Gaussian matrices are matrices where each entry is
    sampled from a Gaussian probability distribution

    .. math::"haar",
        p(x) = \\frac{1}{\\sqrt{2 \\, \\pi} \\, \\sigma} \\,
            \\exp{\\left(-\\frac{(x - \\mu)^{2}}{2\\,\\sigma^{2}}\\right)}

    with mean :math:`\\mu` and standard deviation :math:`\\sigma`.

    Args:
        dims (int): dimension of the matrix.
        rank (int, optional): rank of the matrix. If ``None``, then
            ``rank == dims``. Default: ``None``.
        mean (float, optional): mean of the Gaussian distribution. Defaults to 0.
        stddev (float, optional): standard deviation of the Gaussian distribution.
            Defaults to ``1``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of random
            numbers or a fixed seed to initialize a generator. If ``None``, initializes
            a generator with a random seed. Default: ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: Random Gaussian matrix with dimensions ``(dims, rank)``.
    """
    if not isinstance(dims, int):
        raise_error(TypeError, f"dims must be an integer, but got {type(dims)}.")

    if rank is None:
        rank = dims
    else:
        if not isinstance(rank, int):
            raise_error(TypeError, f"rank must be an integer, but got {type(rank)}.")
        if rank > dims:
            raise_error(
                ValueError, f"rank ({rank}) cannot be greater than dims ({dims})."
            )

    if dims <= 0 or rank <= 0:
        raise_error(ValueError, "Dimensions must be positive integers.")

    backend = _check_backend(backend)

    if seed is not None and not isinstance(seed, (int, np.random.Generator)):
        raise_error(
            TypeError, f"seed must be an integer or Generator, but got {type(seed)}."
        )

    backend.set_seed(seed)
    return backend.qinfo._random_gaussian_matrix(dims, rank, mean, stddev)


def random_hermitian(
    dims: int,
    semidefinite: bool = False,
    normalize: bool = False,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Generates a random Hermitian matrix :math:`H`, i.e.
    a random matrix such that :math:`H = H^{\\dagger}.`

    Args:
        dims (int): dimension of the matrix.
        semidefinite (bool, optional): if ``True``, returns a Hermitian matrix that
            is also positive semidefinite. Defaults to ``False``.
        normalize (bool, optional): if ``True`` and ``semidefinite=False``, returns
            a Hermitian matrix with eigenvalues in the interval
            :math:`[-1, \\, 1]`. If ``True`` and ``semidefinite=True``,
            interval is :math:`[0, \\, 1]`. Defaults to ``False``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: Hermitian matrix :math:`H` with dimensions ``(dims, dims)``.
    """

    backend = _check_backend(backend)
    backend.set_seed(seed)
    if semidefinite:
        matrix = backend.qinfo._random_hermitian_semidefinite(dims)
    else:
        matrix = backend.qinfo._random_hermitian(dims)

    if normalize:
        matrix = matrix / backend.matrix_norm(matrix)

    return matrix


def random_unitary(
    dims: int,
    measure: Optional[str] = None,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Returns a random Unitary operator :math:`U`, i.e.
    a random operator such that :math:`U^{-1} = U^{\\dagger}`.

    Args:
        dims (int): dimension of the matrix.
        measure (str, optional): probability measure in which to sample the unitary
            from. If ``None``, functions returns :math:`\\exp{(-i \\, H)}`, where
            :math:`H` is a Hermitian operator. If ``"haar"``, returns an Unitary
            matrix sampled from the Haar measure. Defaults to ``None``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: Unitary matrix :math:`U` with dimensions ``(dims, dims)``.
    """

    backend = _check_backend(backend)
    backend.set_seed(seed)

    if measure is not None and measure != "haar":
        raise_error(ValueError, f"measure {measure} not implemented.")

    if measure == "haar":
        return backend.qinfo._random_unitary_haar(dims)

    return backend.qinfo._random_unitary(dims)


def random_quantum_channel(
    dims: int,
    representation: str = "liouville",
    measure: Optional[str] = None,
    rank: Optional[int] = None,
    order: str = "row",
    normalize: bool = False,
    precision_tol: Optional[float] = None,
    validate_cp: bool = True,
    nqubits: Optional[int] = None,
    initial_state_env=None,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Creates a random superoperator from an unitary operator in one of the
    supported superoperator representations.

    Args:
        dims (int): dimension of the :math:`n`-qubit operator, i.e. :math:`\\text{dims}=2^{n}`.
        representation (str, optional): If ``"chi"``, returns a random channel in the
            Chi representation. If ``"choi"``, returns channel in Choi representation.
            If ``"kraus"``, returns Kraus representation of channel. If ``"liouville"``,
            returns Liouville representation. If ``"pauli"``, returns Pauli-Liouville
            representation. If "pauli-<pauli_order>" or "chi-<pauli_order>", (e.g. "pauli-IZXY"),
            returns it in the Pauli basis with the corresponding order of single-qubit Pauli elements
            (see :func:`qibo.quantum_info.pauli_basis`). If ``"stinespring"``,
            returns random channel in the Stinespring representation. Defaults to ``"liouville"``.
        measure (str, optional): probability measure in which to sample the unitary
            from. If ``None``, functions returns :math:`\\exp{(-i \\, H)}`, where
            :math:`H` is a Hermitian operator. If ``"haar"``, returns an Unitary
            matrix sampled from the Haar measure. If ``"bcsz"``, it samples an unitary
            from the BCSZ distribution with Kraus ``rank``. Defaults to ``None``.
        rank (int, optional): used when ``measure=="bcsz"``. Rank of the matrix.
            If ``None``, then ``rank==dims``. Defaults to ``None``.
        order (str, optional): If ``"row"``, vectorization is performed row-wise.
            If ``"column"``, vectorization is performed column-wise. If ``"system"``,
            a block-vectorization is performed. Defaults to ``"row"``.
        normalize (bool, optional): used when ``representation="chi"`` or
            ``representation="pauli"``. If ``True`` assumes the normalized Pauli basis.
            If ``False``, it assumes unnormalized Pauli basis. Defaults to ``False``.
        precision_tol (float, optional): if ``representation="kraus"``, it is the
            precision tolerance for eigenvalues found in the spectral decomposition
            problem. Any eigenvalue :math:`\\lambda <` ``precision_tol`` is set
            to 0 (zero). If ``None``, ``precision_tol`` defaults to
            ``qibo.config.PRECISION_TOL=1e-8``. Defaults to ``None``.
        validate_cp (bool, optional): used when ``representation="stinespring"``.
            If ``True``, checks if the Choi representation of superoperator
            used as intermediate step is a completely positive map.
            If ``False``, it assumes that it is completely positive (and Hermitian).
            Defaults to ``True``.
        nqubits (int, optional): used when ``representation="stinespring"``.
            Total number of qubits in the system that is interacting with
            the environment. Must be equal or greater than the number of
            qubits that Kraus representation of the system superoperator acts on.
            If ``None``, defaults to the number of qubits in the Kraus operators.
            Defauts to ``None``.
        initial_state_env (ndarray, optional): used when ``representation="stinespring"``.
            Statevector representing the initial state of the enviroment.
            If ``None``, it assumes the environment in its ground state.
            Defaults to ``None``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: Superoperator representation of a random unitary gate.
    """
    if representation not in (
        "chi",
        "choi",
        "kraus",
        "liouville",
        "pauli",
        "stinespring",
    ):
        if (
            ("chi-" not in representation and "pauli-" not in representation)
            or len(representation.split("-")) != 2
            or set(representation.split("-")[1]) != {"I", "X", "Y", "Z"}
        ):
            raise_error(ValueError, f"representation {representation} not implemented.")

    backend = _check_backend(backend)
    backend.set_seed(seed)

    if measure == "bcsz":
        super_op = _super_op_from_bcsz_measure(
            dims=dims, rank=rank, order=order, seed=seed, backend=backend
        )
    elif measure == "haar":
        func_order = getattr(backend.qinfo, f"_super_op_from_haar_measure_{order}")
        super_op = func_order(dims)
    elif measure is None:
        func_order = getattr(backend.qinfo, f"_super_op_from_hermitian_measure_{order}")
        super_op = func_order(dims)

    if "chi" in representation:
        pauli_order = "IXYZ"
        if "-" in representation:
            pauli_order = representation.split("-")[1]
        super_op = choi_to_chi(
            super_op,
            normalize=normalize,
            order=order,
            pauli_order=pauli_order,
            backend=backend,
        )
    elif representation == "kraus":
        super_op = choi_to_kraus(
            super_op,
            precision_tol=precision_tol,
            order=order,
            validate_cp=False,
            backend=backend,
        )
    elif representation == "liouville":
        super_op = choi_to_liouville(super_op, order=order, backend=backend)
    elif "pauli" in representation:
        pauli_order = "IXYZ"
        if "-" in representation:
            pauli_order = representation.split("-")[1]
        super_op = choi_to_pauli(
            super_op,
            normalize=normalize,
            order=order,
            pauli_order=pauli_order,
            backend=backend,
        )
    elif representation == "stinespring":
        super_op = choi_to_stinespring(
            super_op,
            precision_tol=precision_tol,
            order=order,
            validate_cp=validate_cp,
            nqubits=nqubits,
            initial_state_env=initial_state_env,
            backend=backend,
        )

    return super_op


def random_statevector(
    dims: int,
    dtype: Optional[DTypeLike] = None,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Creates a random statevector :math:`\\ket{\\psi}`.

    .. math::
        \\ket{\\psi} = \\sum_{k = 0}^{d - 1} \\, \\sqrt{p_{k}} \\,
            e^{i \\phi_{k}} \\, \\ket{k} \\, ,

    where :math:`d` is ``dims``, and :math:`p_{k}` and :math:`\\phi_{k}` are, respectively,
    the probability and phase corresponding to the computational basis state :math:`\\ket{k}`.

    .. note::
        If ``dtype`` if ``"float64"``, ``"float32"``, or an equivalent type,
        then :math:`\\ket{\\psi} \\in \\mathbb{R}^{\\text{dims}}`. Otherwise,
        :math:`\\ket{\\psi} \\in \\mathbb{C}^{\\text{dims}}`.

    Args:
        dims (int): dimension of the matrix.
        dtype (str or type, optional): data type for the random statevector.
            Options are ``"complex128``, ``"complex64"``, ``"float64"``, or ``"float32"``.
            It also accepts the equivalent data types of ``backend``'s engines, *e.g.*
            ``numpy.complex128`` or ``cupy.float64``. If ``None``, defaults to
            ``backend.dtype``. Defaults to ``None``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: Random statevector :math:`\\ket{\\psi}`.
    """
    backend = _check_backend(backend)
    backend.set_seed(seed)

    if dtype is None:
        dtype = backend.dtype

    if "complex" in str(dtype):
        state = backend.qinfo._random_statevector(dims)
    else:
        state = backend.qinfo._random_statevector_real(dims)

    return backend.cast(state, dtype=dtype)


def random_density_matrix(
    dims: int,
    rank: Optional[int] = None,
    pure: bool = False,
    metric: str = "hilbert-schmidt",
    basis: Optional[str] = None,
    normalize: bool = False,
    order: str = "row",
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Creates a random density matrix :math:`\\rho`. If ``pure=True``,

    .. math::
        \\rho = \\ketbra{\\psi}{\\psi} \\, ,

    where :math:`\\ket{\\psi}` is a :func:`qibo.quantum_info.random_statevector`.
    If ``pure=False``, then

    .. math::
        \\rho = \\sum_{k} \\, p_{k} \\, \\ketbra{\\psi_{k}}{\\psi_{k}} \\, .

    is a mixed state.

    Args:
        dims (int): dimension of the matrix.
        rank (int, optional): rank of the matrix. If ``None``, then ``rank == dims``.
            Defaults to ``None``.
        pure (bool, optional): if ``True``, returns a pure state. Defaults to ``False``.
        metric (str, optional): metric to sample the density matrix from. Options:
            ``"hilbert-schmidt"``, ``"ginibre"``, and ``"bures"``.
            Note that, by definition, ``rank`` defaults to ``None``
            when ``metric=="hilbert-schmidt"``. Defaults to ``"hilbert-schmidt"``.
        basis (str, optional): if ``None``, returns random density matrix in the
            computational basis. If ``"pauli-<pauli_order>"``, (e.g. ``"pauli-IZXY"``),
            returns it in the Pauli basis with the corresponding order of single-qubit
            Pauli elements (see :func:`qibo.quantum_info.pauli_basis`).
            Defaults to ``None``.
        normalize(bool, optional): used when ``basis="pauli-<pauli-order>"``. If ``True``
            returns random density matrix in the normalized Pauli basis. If ``False``,
            returns state in the unnormalized Pauli basis. Defaults to ``False``.
        order (str, optional): used when ``basis="pauli-<pauli-order>"``. If ``"row"``,
            vectorization of Pauli basis is performed row-wise. If ``"column"``,
            vectorization is performed column-wise. If ``"system"``, system-wise
            vectorization is performed. Default is ``"row"``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: Random density matrix :math:`\\rho`.
    """

    if rank is not None and rank > dims:
        raise_error(ValueError, f"rank ({rank}) cannot be greater than dims ({dims}).")

    if metric not in ["hilbert-schmidt", "ginibre", "bures"]:
        raise_error(ValueError, f"metric {metric} not implemented.")

    if basis is not None and basis != "pauli":
        if (
            "pauli-" not in basis
            or len(basis.split("-")) != 2
            or set(basis.split("-")[1]) != {"I", "X", "Y", "Z"}
        ):
            raise_error(ValueError, f"basis {basis} nor recognized.")

    if normalize and basis is None:
        raise_error(ValueError, "normalize cannot be True when basis=None.")

    backend = _check_backend(backend)
    backend.set_seed(seed)

    if pure:
        state = backend.qinfo._random_density_matrix_pure(dims)
    else:
        if metric in ["hilbert-schmidt", "ginibre"]:
            state = backend.qinfo._random_density_matrix_hs_ginibre(
                dims, dims, 0.0, 1.0
            )
        else:
            state = backend.qinfo._random_density_matrix_bures(dims, dims, 0.0, 1.0)

    if basis is not None:
        pauli_order = basis.split("-")[1]
        unitary = comp_basis_to_pauli(
            int(np.log2(dims)),
            normalize=normalize,
            order=order,
            pauli_order=pauli_order,
            backend=backend,
        )
        state = unitary @ vectorization(state, order=order, backend=backend)

    return state


def random_clifford(
    nqubits: int,
    return_circuit: bool = True,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
    **kwargs,
):
    """Generates a random :math:`n`-qubit Clifford operator, where :math:`n` is ``nqubits``.
    For the mathematical details, see Reference [1].

    Args:
        nqubits (int): number of qubits.
        return_circuit (bool, optional): if ``True``, returns a :class:`qibo.models.Circuit`
            object. If ``False``, returns an ``ndarray`` object. Defaults to ``True``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.
        kwargs (dict, optional): Additional arguments used to initialize a Circuit object.
            For details, see the documentation of :class:`qibo.models.circuit.Circuit`.

    Returns:
        :class:`qibo.quantum_info.clifford.Clifford` or :class:`qibo.models.Circuit`:
        Random Clifford operator.

    Reference:
        1. S. Bravyi and D. Maslov, *Hadamard-free circuits expose the
           structure of the Clifford group*.
           `arXiv:2003.09412 [quant-ph] <https://arxiv.org/abs/2003.09412>`_.
    """
    if not isinstance(return_circuit, bool):
        raise_error(
            TypeError,
            f"return_circuit must be type bool, but it is type {type(return_circuit)}.",
        )

    backend = _check_backend(backend)
    backend.set_seed(seed)
    dtype = backend.uint8 if nqubits <= 255 else backend.int16

    hadamards, permutations = backend.qinfo._sample_from_quantum_mallows_distribution(
        nqubits
    )
    hadamards = backend.cast(hadamards, dtype=dtype)
    permutations = backend.cast(permutations, dtype=dtype)

    gamma = backend.diag(backend.random_integers(2, size=nqubits, dtype=dtype))

    gamma_prime = backend.diag(backend.random_integers(2, size=nqubits, dtype=dtype))

    delta = backend.identity(nqubits, dtype=dtype)
    delta_prime = backend.cast(delta, dtype=delta.dtype, copy=True)

    backend.qinfo._fill_tril(gamma, symmetric=True)
    backend.qinfo._fill_tril(gamma_prime, symmetric=True)
    backend.qinfo._fill_tril(delta, symmetric=False)
    backend.qinfo._fill_tril(delta_prime, symmetric=False)

    # For large nqubits numpy.inv function called below can
    # return invalid output leading to a non-symplectic Clifford
    # being generated. This can be prevented by manually forcing
    # block inversion of the matrix.
    block_inverse_threshold = 50

    # Compute stabilizer table
    zero = backend.zeros((nqubits, nqubits), dtype=dtype)
    prod1 = (gamma @ delta) % 2
    prod2 = (gamma_prime @ delta_prime) % 2
    inv1 = backend.qinfo._inverse_tril(delta, block_inverse_threshold).T
    inv2 = backend.qinfo._inverse_tril(delta_prime, block_inverse_threshold).T

    # backend.block cannot be used below because there is no cupy equivalent
    # hence the necessity for three backend.concatenate's
    had_free_operator_1 = backend.concatenate(
        [
            backend.concatenate([delta, zero], axis=1),
            backend.concatenate([prod1, inv1], axis=1),
        ],
        axis=0,
    )
    had_free_operator_2 = backend.concatenate(
        [
            backend.concatenate([delta_prime, zero], axis=1),
            backend.concatenate([prod2, inv2], axis=1),
        ],
        axis=0,
    )

    # Apply qubit permutation
    table = had_free_operator_2[
        backend.concatenate([permutations, nqubits + permutations], axis=0)
    ]

    # Apply layer of Hadamards
    inds = hadamards * backend.arange(1, nqubits + 1)
    inds = inds[inds > 0] - 1
    lhs_inds = backend.concatenate([inds, inds + nqubits], axis=0)
    rhs_inds = backend.concatenate([inds + nqubits, inds], axis=0)
    table[lhs_inds, :] = table[rhs_inds, :]

    # Apply table
    tableau = backend.zeros((2 * nqubits, 2 * nqubits + 1), dtype=bool)
    tableau[:, :-1] = (had_free_operator_1 @ table) % 2

    # Generate random phases
    integers = backend.random_integers(2, size=2 * nqubits)
    integers = backend.cast(integers, dtype=integers.dtype)
    tableau[:, -1] = integers

    engine = (
        backend.platform
        if backend.name in ("clifford", "qibojit", "qiboml")
        else backend.name
    )
    cliff = Clifford(tableau, platform=engine)

    if return_circuit:
        method = "BM20" if engine == "cupy" else "AG04"
        return cliff.to_circuit(method, **kwargs)

    return cliff


def random_pauli(
    qubits,
    depth: int,
    max_qubits: Optional[int] = None,
    subset: Optional[list] = None,
    return_circuit: bool = True,
    density_matrix: bool = False,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Creates random Pauli operator(s).

    Pauli operators are sampled from the single-qubit Pauli set
    :math:`\\{I, \\, X, \\, Y, \\, Z\\}`.

    Args:
        qubits (int or list or ndarray): if ``int`` and ``max_qubits=None``, the
            number of qubits. If ``int`` and ``max_qubits != None``, qubit index
            in which the Pauli sequence will act. If ``list`` or ``ndarray``,
            indexes of the qubits for the Pauli sequence to act.
        depth (int): length of the sequence of Pauli gates.
        max_qubits (int, optional): total number of qubits in the circuit.
            If ``None``, ``max_qubits = max(qubits)``. Defaults to ``None``.
        subset (list, optional): list containing a subset of the 4 single-qubit
            Pauli operators. If ``None``, defaults to the complete set.
            Defaults to ``None``.
        return_circuit (bool, optional): if ``True``, returns a :class:`qibo.models.Circuit`
            object. If ``False``, returns an ``ndarray`` with shape (qubits, depth, 2, 2)
            that contains all Pauli matrices that were sampled. Defaults to ``True``.
        density_matrix (bool, optional): used when ``return_circuit=True``. If `True`,
            the circuit would evolve density matrices. Defaults to ``False``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        (ndarray or :class:`qibo.models.Circuit`): all sampled Pauli operators.

    """

    if max_qubits is not None:
        if isinstance(qubits, int) and qubits >= max_qubits:
            raise_error(
                ValueError,
                f"qubit index ({qubits}) must be < max_qubits ({max_qubits}).",
            )
        elif not isinstance(qubits, int) and any(q >= max_qubits for q in qubits):
            raise_error(ValueError, "all qubit indexes must be < max_qubits.")
    if depth < 1:
        raise_error(ValueError, "``depth`` must be >= 1.")

    if subset is not None and any(isinstance(item, str) is False for item in subset):
        raise_error(
            TypeError,
            "subset argument must be a subset of strings in the set ['I', 'X', 'Y', 'Z'].",
        )

    backend = _check_backend(backend)
    backend.set_seed(seed)

    complete_set = (
        {"I": gates.I, "X": gates.X, "Y": gates.Y, "Z": gates.Z}
        if return_circuit
        else {
            "I": backend.matrices.I(),
            "X": backend.matrices.X,
            "Y": backend.matrices.Y,
            "Z": backend.matrices.Z,
        }
    )

    if subset is None:
        subset = complete_set
    else:
        subset = {key: complete_set[key] for key in subset}

    keys = list(subset.keys())

    if max_qubits is None:
        if isinstance(qubits, int):
            max_qubits = qubits
            qubits = range(qubits)
        else:
            max_qubits = int(max(qubits)) + 1
    else:
        if isinstance(qubits, int):
            qubits = [qubits]

    # this may be optimized as well (the sampling mostly) but maybe it's not worth it
    indexes = backend.random_integers(0, len(subset), size=(len(qubits), depth))
    indexes = [[keys[int(item)] for item in row] for row in indexes]

    if return_circuit:
        gate_grid = Circuit(max_qubits, density_matrix=density_matrix)
        for qubit, row in zip(qubits, indexes):
            for column_item in row:
                if subset[column_item] != gates.I:
                    gate_grid.add(subset[column_item](qubit))
    else:
        gate_grid = backend.cast(
            [
                backend.cast([subset[column_item] for column_item in row])
                for row in indexes
            ]
        )

    return gate_grid


def random_pauli_hamiltonian(
    nqubits: int,
    max_eigenvalue: Optional[Union[int, float]] = None,
    normalize: bool = False,
    pauli_order: str = "IXYZ",
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Generates a random Hamiltonian in the Pauli basis.

    Args:
        nqubits (int): number of qubits.
        max_eigenvalue (int or float, optional): fixes the value of the
            largest eigenvalue. Defaults to ``None``.
        normalize (bool, optional): If ``True``, fixes the gap of the
            Hamiltonian as ``1.0``. Moreover, if ``True``, then ``max_eigenvalue``
            must be ``> 1.0``. Defaults to ``False``.
        pauli_order (str, optional): corresponds to the order of 4 single-qubit
            Pauli elements in the basis. Defaults to "IXYZ".
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        tuple(ndarray, ndarray): Hamiltonian in the Pauli basis and its corresponding eigenvalues.
    """
    if isinstance(nqubits, int) is False:
        raise_error(
            TypeError, f"nqubits must be type int, but it is type {type(nqubits)}."
        )
    elif nqubits <= 0:
        raise_error(ValueError, "nqubits must be a positive int.")

    if isinstance(max_eigenvalue, (int, float)) is False and normalize is True:
        raise_error(
            TypeError,
            f"when normalize=True, max_eigenvalue must be type float, "
            + f"but it is {type(max_eigenvalue)}.",
        )
    elif (
        isinstance(max_eigenvalue, (int, float)) is False and max_eigenvalue is not None
    ):
        raise_error(
            TypeError,
            f"max_eigenvalue must be type float, but it is {type(max_eigenvalue)}.",
        )

    if isinstance(normalize, bool) is False:
        raise_error(
            TypeError,
            f"normalize must be type bool, but it is type {type(normalize)}.",
        )
    elif normalize is True and max_eigenvalue <= 1.0:
        raise_error(
            ValueError,
            "when normalize=True, gap is = 1, thus max_eigenvalue must be > 1.",
        )

    backend = _check_backend(backend)
    backend.set_seed(seed)

    d = 2**nqubits

    hamiltonian = random_hermitian(d, normalize=True, seed=seed, backend=backend)

    eigenvalues, eigenvectors = backend.eigenvectors(hamiltonian)
    if backend.platform == "tensorflow":
        eigenvalues = backend.to_numpy(eigenvalues)
        eigenvectors = backend.to_numpy(eigenvectors)

    if normalize is True:
        eigenvalues = eigenvalues - eigenvalues[0]

        eigenvalues = eigenvalues / eigenvalues[1]

        shift = 2
        eigenvectors[:, shift:] = (
            eigenvectors[:, shift:] * max_eigenvalue / eigenvalues[-1]
        )
        eigenvalues[shift:] = eigenvalues[shift:] * max_eigenvalue / eigenvalues[-1]

        hamiltonian = backend.zeros((d, d), dtype=backend.complex128)
        hamiltonian = backend.cast(hamiltonian, dtype=hamiltonian.dtype)
        # excluding the first eigenvector because first eigenvalue is zero
        for eigenvalue, eigenvector in zip(
            eigenvalues[1:], backend.transpose(eigenvectors, (1, 0))[1:]
        ):
            hamiltonian = hamiltonian + eigenvalue * backend.outer(
                eigenvector, backend.conj(eigenvector)
            )

    U = comp_basis_to_pauli(
        nqubits, normalize=True, pauli_order=pauli_order, backend=backend
    )

    hamiltonian = backend.real(U @ vectorization(hamiltonian, backend=backend))

    return hamiltonian, eigenvalues


def random_stochastic_matrix(
    dims: int,
    bistochastic: bool = False,
    diagonally_dominant: bool = False,
    precision_tol: Optional[float] = None,
    max_iterations: Optional[int] = None,
    seed: Optional[int] = None,
    backend: Optional[Backend] = None,
):
    """Creates a random stochastic matrix.

    Args:
        dims (int): dimension of the matrix.
        bistochastic (bool, optional): if ``True``, matrix is row- and column-stochastic.
            If ``False``, matrix is row-stochastic. Defaults to ``False``.
        diagonally_dominant (bool, optional): if ``True``, matrix is strictly diagonally
            dominant. Defaults to ``False``.
        precision_tol (float, optional): tolerance level for how much each probability
            distribution can deviate from summing up to ``1.0``. If ``None``,
            it defaults to ``qibo.config.PRECISION_TOL``. Defaults to ``None``.
        max_iterations (int, optional): when ``bistochastic=True``, maximum number
            of iterations used to normalize all rows and columns simultaneously.
            If ``None``, defaults to ``qibo.config.MAX_ITERATIONS``.
            Defaults to ``None``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a statevectorgenerator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.

    Returns:
        ndarray: a random stochastic matrix.

    """
    if dims <= 0:
        raise_error(ValueError, "dims must be type int and positive.")

    if not isinstance(bistochastic, bool):
        raise_error(
            TypeError,
            f"bistochastic must be type bool, but it is type {type(bistochastic)}.",
        )

    if not isinstance(diagonally_dominant, bool):
        raise_error(
            TypeError,
            f"diagonally_dominant must be type bool, but it is type {type(diagonally_dominant)}.",
        )

    if precision_tol is not None:
        if not isinstance(precision_tol, float):
            raise_error(
                TypeError,
                f"precision_tol must be type float, but it is type {type(precision_tol)}.",
            )
        if precision_tol < 0.0:
            raise_error(ValueError, "precision_tol must be non-negative.")

    if max_iterations is not None:
        if not isinstance(max_iterations, int):
            raise_error(
                TypeError,
                f"max_iterations must be type int, but it is type {type(precision_tol)}.",
            )
        if max_iterations <= 0.0:
            raise_error(ValueError, "max_iterations must be a positive int.")

    backend, local_state = _check_backend_and_local_state(seed, backend)

    if precision_tol is None:
        precision_tol = PRECISION_TOL
    if max_iterations is None:
        max_iterations = MAX_ITERATIONS

    matrix = local_state.random(size=(dims, dims))
    matrix = backend.cast(matrix, dtype=matrix.dtype)
    if diagonally_dominant:
        matrix /= dims**2
        for k, row in enumerate(matrix):
            row = backend.delete(row, k)
            matrix[k, k] = 1 - backend.sum(row)

    row_sum = backend.sum(matrix, axis=1)

    if bistochastic:
        column_sum = backend.sum(matrix, axis=0)
        count = 0
        while count <= max_iterations - 1 and (
            (
                backend.any(row_sum >= 1 + precision_tol)
                or backend.any(row_sum <= 1 - precision_tol)
            )
            or (
                backend.any(column_sum >= 1 + precision_tol)
                or backend.any(column_sum <= 1 - precision_tol)
            )
        ):
            matrix = matrix / backend.sum(matrix, axis=0)
            matrix = matrix / backend.sum(matrix, axis=1)[:, np.newaxis]
            row_sum = backend.sum(matrix, axis=1)
            column_sum = backend.sum(matrix, axis=0)
            count += 1
        if count == max_iterations:
            warnings.warn("Reached max iterations.", RuntimeWarning)
    else:
        matrix = matrix / backend.outer(row_sum, backend.ones(dims, dtype=int))

    return matrix


def _super_op_from_bcsz_measure(dims: int, rank: int, order: str, seed, backend):
    """Helper function for :func:qibo.quantum_info.random_ensembles.random_quantum_channel.
    Generates a channel from the BCSZ measure.

    Args:
        dims (int): dimension of the :math:`n`-qubit operator, i.e. :math:`\\text{dims}=2^{n}`.
        rank (int, optional): used when ``measure=="bcsz"``. Rank of the matrix.
            If ``None``, then ``rank==dims``. Defaults to ``None``.
        order (str, optional): If ``"row"``, vectorization is performed row-wise.
            If ``"column"``, vectorization is performed column-wise. Defaults to ``"row"``.
        seed (int or :class:`numpy.random.Generator`, optional): Either a generator of
            random numbers or a fixed seed to initialize a generator. If ``None``,
            initializes a generator with a random seed. Defaults to ``None``.
        backend (:class:`qibo.backends.abstract.Backend`, optional): backend to be used
            in the execution. If ``None``, it uses the current backend.
            Defaults to ``None``.
    """
    backend.set_seed(seed)

    if rank is None:
        rank = dims

    if order not in ("row", "column"):
        raise_error(
            ValueError, f"Unrecognized {order} order, pick one in ('row', 'column')."
        )

    if order == "column":
        return backend.qinfo._super_op_from_bcsz_measure_column(dims, rank)

    return backend.qinfo._super_op_from_bcsz_measure_row(dims, rank)
