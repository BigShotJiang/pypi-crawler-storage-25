from typing import TypedDict


class SessionOptionDict(TypedDict):
    name: str
    "Name of the option"
    index: int
    "Index of the option. Used as a fallback when `name` doesn't exist"


# What is textual reactive?
class SessionManager:
    """Manages session-related variables.

    Attributes:
        directories (list[str]): A list of dictionaries that contain a
            directory's name within. The closer it is to index 0, the
            older it is.
        historyIndex (int): The index of the session in the directories.
            This can be a number between 0 and the length of the list - 1,
            inclusive.
        lastHighlighted (dict[str, SessionOptionDict]): A dictionary mapping directory
                                 paths to the index of the last highlighted item. If a
                                 directory is not in the dictionary, the default is 0.
        selectMode (bool): Whether select mode is enabled for that directory.
        selectedItems (list[SessionOptionDict]): A list of selected items within the
                                                                      current directory
        search (str): The current search string.
    """

    def __init__(self) -> None:
        self.directories: list[str] = []
        self.historyIndex: int = 0
        self.lastHighlighted: dict[str, SessionOptionDict] = {}
        self.selectMode: bool = False
        self.selectedItems: list[SessionOptionDict] = []
        self.search: str = ""
