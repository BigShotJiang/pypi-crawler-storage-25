import contextlib
from os import getcwd, makedirs, path
from typing import cast

from textual import work
from textual.content import Content
from textual.worker import Worker, WorkerError

from rovr.classes.textual_validators import IsValidFilePath, PathNoLongerExists
from rovr.functions.icons import get_icon
from rovr.functions.path import dump_exc, normalise
from rovr.screens import ModalInput
from rovr.variables.constants import config
from rovr.widgets import Button


class NewItemButton(Button):
    ALLOW_MAXIMIZE = False

    def __init__(self) -> None:
        super().__init__(get_icon("general", "new")[0], classes="option", id="new")
        if config["interface"]["tooltips"]:
            self.tooltip = "Create a new file or directory"

    @work
    async def on_button_pressed(self) -> None:
        if self.disabled:
            return
        response = await self.app.push_screen(
            ModalInput(
                border_title="Create New Item",
                border_subtitle="End with a slash (/) to create a directory",
                is_path=True,
                validators=[PathNoLongerExists(), IsValidFilePath()],
            ),
            wait_for_dismiss=True,
        )
        if not response:
            return
        response = str(response)
        location = normalise(path.join(getcwd(), response)) + (
            "/" if response.endswith("/") or response.endswith("\\") else ""
        )
        if location.endswith("/"):
            # recursive directory creation
            try:
                worker = self.app.run_in_thread(makedirs, location)
                await worker.wait()
                if isinstance(worker.result, Exception):
                    raise worker.result
            except Exception as exc:
                self.notify(
                    # i had to force a cast, i didn't have any other choice
                    # notify supports non-string objects, but ty wasn't taking
                    # any of it, so i had to cast it
                    message=cast(
                        str,
                        Content(
                            f"Error creating directory '{response}'\n{type(exc).__name__}: {exc}"
                        ),
                    ),
                    title="New Item",
                    severity="error",
                    markup=False,
                )
        elif len(location.split("/")) > 1:
            # recursive directory until file creation
            location_parts = location.split("/")
            dir_path = "/".join(location_parts[:-1])
            try:
                worker = self.app.run_in_thread(makedirs, dir_path)
                await worker.wait()
                if isinstance(worker.result, Exception):
                    raise worker.result
                # performance wise shouldn't be that bad, unless
                # the file is being created in a directory with a very long path
                # or some weird voodoo stuff happens, idk
                with open(location, "w") as f:
                    f.write("")  # Create an empty file
            except FileExistsError:
                with open(location, "w") as f:
                    f.write("")
            except Exception as exc:
                # i had to force a cast, i didn't have any other choice
                # notify supports non-string objects, but ty wasn't taking
                # any of it, so i had to cast it
                self.notify(
                    message=cast(
                        str,
                        Content(
                            f"Error creating file '{response}'\n{type(exc).__name__}: {exc}"
                        ),
                    ),
                    title="New Item",
                    severity="error",
                    markup=False,
                )
        else:
            # normal file creation I hope
            try:
                with open(location, "w") as f:
                    f.write("")  # Create an empty file
            except Exception as exc:
                self.notify(
                    message=f"Error creating file '{response}'\n{type(exc).__name__}: {exc}",
                    title="New Item",
                    severity="error",
                    markup=False,
                )
        try:
            self.app.file_list.file_list_pause_check = True
            self.app.file_list.focus()
            worker: Worker = self.app.file_list.update_file_list(
                add_to_session=False, focus_on=path.basename(location.rstrip("/"))
            )
            with contextlib.suppress(WorkerError):
                await worker.wait()
        except Exception as exc:
            dump_exc(self, exc)
        finally:
            self.app.file_list.file_list_pause_check = False
