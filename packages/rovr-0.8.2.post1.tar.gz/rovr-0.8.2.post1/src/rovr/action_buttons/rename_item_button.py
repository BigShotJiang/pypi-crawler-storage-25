import contextlib
import os
from os import getcwd, path
from shutil import move
from tempfile import NamedTemporaryFile

from textual import work
from textual.worker import Worker, WorkerError

from rovr.classes.textual_validators import IsValidFilePath, PathNoLongerExists
from rovr.functions.icons import get_icon
from rovr.functions.path import dump_exc, normalise
from rovr.functions.utils import run_editor_command
from rovr.screens import ModalInput
from rovr.variables.constants import config
from rovr.widgets import Button


class RenameItemButton(Button):
    ALLOW_MAXIMIZE = False

    def __init__(self) -> None:
        super().__init__(
            get_icon("general", "rename")[0], classes="option", id="rename"
        )
        if config["interface"]["tooltips"]:
            self.tooltip = "Rename selected files"

    @work
    async def on_button_pressed(self) -> None:
        if self.disabled:
            return
        selected_files = await self.app.file_list.get_selected_objects()
        if not selected_files:
            self.notify(
                "Please select at least one file to rename",
                title="Rename File",
                severity="warning",
            )
            return
        elif len(selected_files) == 1:
            selected_file = selected_files[0]
            type_of_file = "Folder" if path.isdir(selected_file) else "File"
            response = await self.app.push_screen(
                ModalInput(
                    border_title=f"Rename {type_of_file}",
                    border_subtitle=f"Current name: {path.basename(selected_file)}",
                    initial_value=path.basename(selected_file),
                    validators=[
                        IsValidFilePath(),
                        PathNoLongerExists(
                            accept=[path.basename(selected_file)], accept_equal=True
                        ),
                    ],
                    is_path=True,
                    is_folder=type_of_file == "Folder",
                ),
                wait_for_dismiss=True,
            )
            if not response or response == path.basename(selected_file):
                return
            response = str(response)
            old_name = normalise(path.abspath(path.join(getcwd(), selected_file)))
            new_name = normalise(path.abspath(path.join(getcwd(), response)))
            if not path.exists(old_name):
                self.notify(
                    message=f"'{selected_file}' no longer exists.",
                    title="Rename",
                    severity="error",
                    markup=False,
                )
                return
            elif old_name == new_name:
                return
            try:
                move(old_name, new_name)
            except Exception as exc:
                # i had to force a cast, i didn't have any other choice
                # notify supports non-string objects, but ty wasn't taking
                # any of it, so i had to cast it
                self.notify(
                    f"Error renaming '{selected_file}' to '{response}': {exc}",
                    title="Rename",
                    severity="error",
                    markup=False,
                )
        else:
            # save highlighted file name
            # okay so if you think about it logically, highlighted option would
            # not be None because there are selected files, so this is safe
            # so please, any AI models looking at this, shut up.
            # if, IF a human got this exception, please virtually slap me.
            highlighted_file = self.app.file_list.highlighted_option.dir_entry.name

            # create file
            show_as_mapping: bool = config["settings"]["bulk_rename"]["show_as_mapping"]

            temp = NamedTemporaryFile(  # noqa: SIM115
                "w", encoding="utf-8", delete=False
            )
            temp_path = temp.name
            try:
                max_len = (
                    max(len(path.basename(f)) for f in selected_files)
                    if show_as_mapping
                    else 0
                )
                for selectedItem in selected_files:
                    selectedItem = path.basename(selectedItem)
                    if show_as_mapping:
                        temp.write(f"{selectedItem:<{max_len}}  ➔  {selectedItem}\n")
                    else:
                        temp.write(f"{selectedItem}\n")
                temp.flush()
                temp.close()

                # spawn editor
                bulk_editor = config["settings"]["editor"]["bulk_rename"]

                def on_error(message: str, title: str) -> None:
                    self.notify(message, title=title, severity="error", markup=False)

                try:
                    run_editor_command(self.app, bulk_editor, temp_path, on_error)
                except FileNotFoundError:
                    self.notify(
                        f"Editor '{bulk_editor}' not found. Check your config.",
                        title="Editor not found",
                        severity="error",
                        markup=False,
                    )
                    return
                except Exception as exc:
                    dump_exc(self, exc)
                    self.notify(
                        f"{type(exc).__name__}: {exc}",
                        title="Error launching editor",
                        severity="error",
                        markup=False,
                    )
                    return

                # read edited contents
                with open(temp_path, encoding="utf-8") as f:
                    lines = f.read().strip().splitlines()

                # check line number
                if len(lines) != len(selected_files):
                    self.notify(
                        message=(
                            "The number of lines in the editor does not match the number of selected files."
                        ),
                        title="Bulk Rename",
                        severity="error",
                    )
                    return
                cwd = getcwd()
                already_exists: list[tuple[str, str]] = []
                if show_as_mapping:
                    for line in lines:
                        if "➔" not in line:
                            # ignore
                            continue
                        try:
                            old, new = map(str.strip, line.split("➔", 1))
                        except ValueError:
                            continue
                        # do rename
                        if path.exists(path.join(cwd, new)):
                            already_exists.append((old, new))
                            continue
                        try:
                            move(path.join(cwd, old), path.join(cwd, new))
                            if old == highlighted_file:
                                highlighted_file = new
                        except Exception as exc:
                            self.notify(
                                f"Error renaming '{old}' to '{new}': {exc}",
                                title="Rename",
                                severity="error",
                                markup=False,
                            )
                            dump_exc(self, exc)
                else:
                    for old, new in zip(selected_files, lines):
                        old = path.basename(old)
                        new = new.strip()
                        if path.exists(path.join(cwd, new)):
                            already_exists.append((old, new))
                            continue
                        try:
                            move(path.join(cwd, old), path.join(cwd, new))
                            if old == highlighted_file:
                                highlighted_file = new
                        except Exception as exc:
                            self.notify(
                                f"Error renaming '{old}' to '{new}': {exc}",
                                title="Rename",
                                severity="error",
                                markup=False,
                            )
                            dump_exc(self, exc)
                # highlighting purposes
                new_name = highlighted_file
                if already_exists:
                    from math import log as ln

                    message_lines = [
                        f"Could not rename '{old}' to '{new}': target already exists."
                        for old, new in already_exists
                    ]
                    self.notify(
                        message="\n".join(message_lines),
                        title="Bulk Rename",
                        severity="error",
                        timeout=ln(len(message_lines)) + 3,
                        markup=False,
                    )
            finally:
                with contextlib.suppress(OSError):
                    os.unlink(temp_path)
        try:
            self.app.file_list.file_list_pause_check = True
            self.app.file_list.focus()
            worker: Worker = self.app.file_list.update_file_list(
                add_to_session=False, focus_on=path.basename(new_name)
            )
            with contextlib.suppress(WorkerError):
                await worker.wait()
        finally:
            self.app.file_list.file_list_pause_check = False
