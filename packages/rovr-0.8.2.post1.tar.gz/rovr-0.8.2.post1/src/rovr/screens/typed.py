from typing import Literal, NamedTuple, TypedDict


class FileInUse(TypedDict):
    value: Literal["try_again", "cancel", "skip"]
    toggle: bool


class YesOrNo(TypedDict):
    value: bool
    toggle: bool


class FileNameConflict(TypedDict):
    value: Literal["overwrite", "rename", "skip", "cancel"]
    same_for_next: bool


class ArchiveScreenReturnType(NamedTuple):
    path: str
    algo: Literal["zip", "tar", "tar.gz", "tar.bz2", "tar.xz", "tar.zst"]
    level: int


class ShellExecReturnType(NamedTuple):
    command: str
    mode: Literal["background", "block", "suspend"]
