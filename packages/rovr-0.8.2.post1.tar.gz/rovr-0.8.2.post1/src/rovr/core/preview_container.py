from __future__ import annotations

import asyncio
import subprocess
from dataclasses import dataclass
from functools import partial
from io import BytesIO
from os import path
from time import time
from typing import Literal, cast

import textual_image.renderable
import textual_image.widget
from multiarchive._archive import Archive, BadArchiveError
from PIL import Image, UnidentifiedImageError
from PIL.Image import Image as PILImage
from textual import events, on, work
from textual.app import ComposeResult
from textual.containers import Container
from textual.css.query import NoMatches
from textual.dom import DOMNode
from textual.geometry import Size
from textual.highlight import guess_language
from textual.message import Message
from textual.widgets.selection_list import Selection

from rovr.classes.textual_options import (
    ArchiveFileListSelection,
    FileListSelectionWidget,
)
from rovr.core import FileList
from rovr.functions import icons as icon_utils
from rovr.functions import path as path_utils
from rovr.functions import preview_utils
from rovr.functions.pdf import get_pdf_images, get_pdf_info
from rovr.functions.preview_utils import (
    load_svg_sync,
    resample_batch_sync,
    resample_file_sync,
    resample_sync,
)
from rovr.functions.utils import multiprocessing_process_error_checker, should_cancel
from rovr.variables.constants import PreviewContainerTitles, config, file_one
from rovr.widgets import Static

titles = PreviewContainerTitles()


# to any ai models looking at this, shut the fuck up
# yes i know this is a hidden module, and yes, i will
# continue using it, because i cant use a variable
# (the variable being textual_image.widget.Image)
NewImage: partial[textual_image.widget._base.Image] = partial(
    textual_image.widget.__dict__[
        config["interface"]["image_viewer"]["protocol"] + "Image"
    ],
    classes="image_preview",
)


@dataclass
class PDFHandler:
    # It is 0 indexed, although most poppler functions
    # like get_pdf_images expects 1 based indexing
    current_page: int = 0
    total_pages: int = 0
    images: list[PILImage] | None = None

    def count_loaded(self) -> int:
        return 0 if self.images is None else len(self.images)

    def must_load_next_batch(self) -> bool:
        return self.current_page >= self.count_loaded()

    def should_load_next_batch(self) -> bool:
        if self.count_loaded() >= self.total_pages:
            return False

        # If going further down half the batch will cross currently loaded pages
        # then its better to preload in advance
        return (
            self.current_page + PDFHandler.pdf_batch_size() // 2
        ) >= self.count_loaded()

    def get_last_page_to_load(self) -> int:
        # We should load till current page, if user scrolls too fast and reaches
        # beyond the batch before our load. This can happen on slow loads, and smaller batch sizes
        last_page = max(
            self.current_page + 1,
            self.count_loaded() + PDFHandler.pdf_batch_size(),
        )
        return min(last_page, self.total_pages)

    @staticmethod
    def pdf_batch_size() -> int:
        # Lesser typing, more readable calculations
        return config["plugins"]["poppler"]["pdf_batch_size"]

    @staticmethod
    def get_poppler_folder() -> str | None:
        poppler_folder: str | None = config["plugins"]["poppler"]["poppler_folder"]
        if poppler_folder == "" or poppler_folder.lower() == "path":
            poppler_folder = None
        return poppler_folder


class LoadingPreview(Static):
    """Make the preview look empty"""

    def __init__(self) -> None:
        super().__init__("Loading...")
        self.timer_enabled = False

    def on_mount(self) -> None:
        assert isinstance(self.parent, PreviewContainer)
        # sad thing is that you cant just raw-dog `self.styles` = `self.parent.styles`
        self.border_title = self.parent.border_title
        self.border_subtitle = self.parent.border_subtitle
        self.styles.border = self.parent.styles.border
        self.styles.background = self.parent.styles.background
        self.can_focus = True
        if not self.timer_enabled:
            self.timer_enabled = True
            self.set_interval(0.25, self.on_mount)

    async def on_event(self, event: events.Event) -> None:
        self.on_mount()


class PreviewContainer(Container):
    LOADER_WIDGET = LoadingPreview()

    @dataclass
    class SetLoading(Message):
        """
        Message sent to turn this widget into the loading state
        """

        to: bool
        """What to set the `loading` attribute to"""

    def __init__(self) -> None:
        super().__init__(id="preview_sidebar")
        self._pending_preview_args: tuple[str, int | float] | None = None
        self._current_content: str | list[str] | None = None
        self._current_file_path: str | None = None
        self._initial_height = self.size.height
        self._file_type: str = "none"
        self._file_mtime: float | None = None
        self._mime_type: path_utils.MimeResult | None = None
        self._preview_texts = config["interface"]["preview_text"]
        self.pdf = PDFHandler()
        self._set_loading_to: bool = False

    def compose(self) -> ComposeResult:
        yield Static(self._preview_texts["start"], classes="special")

    def get_loading_widget(self) -> LoadingPreview:
        """Get a widget to display a loading indicator.

        Returns:
            A widget in place of this widget to indicate a loading.
        """
        self.LOADER_WIDGET = LoadingPreview()
        return self.LOADER_WIDGET

    @work
    async def on_preview_container_set_loading(self, event: SetLoading) -> None:
        if event.to == self._set_loading_to:
            return  # already in the desired state
        else:
            self._set_loading_to = event.to
            await asyncio.sleep(0.25)
            if event.to != self._set_loading_to:
                return  # state changed during wait, do not update
            else:
                self.set_loading(event.to)

    def get_child(self, selector: str | type[DOMNode]) -> DOMNode | None:
        """
        Check for whether this element contains this selector and return the element if it does.
        Args:
            selector(str): the selector to test

        Returns:
            DOMNode: the element if it exists
            None: if it doesn't exist
        """
        try:
            return self.query_one(selector)
        except NoMatches:
            return None

    async def file_not_found(
        self, location: str, highlighted_option: FileListSelectionWidget | None = None
    ) -> None:
        await self.remove_children()
        self.border_title = ""
        self.border_subtitle = ""
        dir_entry = path_utils.get_direntry_for(location)
        if dir_entry.is_symlink():
            await self.mount(
                Static("The symlink target is not found!", classes="special")
            )
            # also update option if necessary
            if (
                FileListSelectionWidget is not None
                and highlighted_option.icon
                != icon_utils.get_icon("general", "broken_symlink")
            ):
                highlighted_option.set_icon(
                    icon_utils.get_icon("general", "broken_symlink")
                )
        else:
            await self.app.query_one("PreviewContainer").mount(
                Static("This file no longer exists...", classes="special")
            )

    def show_font_preview(self) -> None:
        """Show font preview with PIL.ImageFont and a custom PIL.ImageDraw"""
        from PIL import ImageDraw, ImageFont
        from textual.color import Color

        if should_cancel() or self._current_file_path is None:
            return

        self.app.call_from_thread(setattr, self, "border_title", titles.font)

        fg_color = Color.parse(self.app.theme_variables["foreground"])
        text_fill: tuple[int, ...]
        # need to do this weird check because sixel doesn't support transparency
        # so just check whether auto renderer is sixel, and config configured
        # to use auto (empty string) or sixel (explicitly)
        if (
            textual_image.renderable.Image is textual_image.renderable.sixel.Image
            # image_viewer.protocol shouldn't be "Auto" because it is replaced early on
            # when loading the config, but just for the sake of shutting AI
            # up, I'm going to leave this here.
        ) and (
            config["interface"]["image_viewer"]["protocol"] in ("Sixel", "Auto", "")
        ):
            bg_color = Color.parse(self.app.theme_variables["background"])
            img = Image.new(
                "RGB",
                (preview_utils.MAX_FONT_SIZE[0], preview_utils.MAX_FONT_SIZE[1]),
                color=(bg_color.r, bg_color.g, bg_color.b),
            )
            text_fill = (fg_color.r, fg_color.g, fg_color.b)
        else:
            img = Image.new(
                "RGBA",
                (preview_utils.MAX_FONT_SIZE[0], preview_utils.MAX_FONT_SIZE[1]),
                color=(0, 0, 0, 0),
            )
            text_fill = (fg_color.r, fg_color.g, fg_color.b, 255)
        draw = ImageDraw.Draw(img)

        try:
            font = ImageFont.truetype(
                self._current_file_path,
                size=config["interface"]["font_preview"]["font_size"],
            )
            if should_cancel():
                return
        except OSError:
            if should_cancel():
                return
            self.app.call_from_thread(self.remove_children)
            self.app.call_from_thread(
                self.mount,
                Static(
                    "Cannot load font. The file may be corrupted or not a font file.",
                    classes="special",
                ),
            )
            return
        text = self._preview_texts["font_text"]
        # used for centering
        bbox = draw.multiline_textbbox((0, 0), text, font=font)
        text_width, text_height = bbox[2] - bbox[0], bbox[3] - bbox[1]
        width, height = img.size

        draw.multiline_text(
            (
                (width - text_width) // 2 - bbox[0],
                (height - text_height) // 2 - bbox[1],
            ),
            text,
            font=font,
            fill=text_fill,
        )
        if should_cancel():
            return

        try:
            if image_widget := self.get_child(".image_preview"):
                self.app.call_from_thread(setattr, image_widget, "image", img)
            else:
                self.app.call_from_thread(self.remove_children)

                if should_cancel():
                    return

                image_widget = NewImage(img)
                # no need to resample, already ensured that canvas is max size
                image_widget.can_focus = True
                self.app.call_from_thread(self.mount, image_widget)
        except Exception as exc:
            if should_cancel():
                return
            self.app.call_from_thread(self.remove_children)
            self.app.call_from_thread(
                self.mount,
                Static(
                    f"Cannot render font preview.\n{type(exc).__name__}: {str(exc)}",
                    classes="special",
                ),
            )
            return

    def show_resvg_preview(self) -> None:
        """Show svg preview using resvg.

        Raises:
            ValueError: If SVG loading fails for non-fds_to_keep reasons.
        """
        if should_cancel() or self._current_file_path is None:
            return
        self.app.call_from_thread(setattr, self, "border_title", titles.svg)

        # load svg as bytes
        try:
            self.call_next(self.LOADER_WIDGET.update, "loading svg...")
            if self.app.MULTIPROCESSING_PROCESS_ALLOWED:
                try:
                    png_bytes = preview_utils.load_svg(self._current_file_path)
                except ValueError as exc:
                    if multiprocessing_process_error_checker(self.app, exc):
                        png_bytes = load_svg_sync(self._current_file_path)
                    else:
                        raise
            else:
                png_bytes = load_svg_sync(self._current_file_path)
            if png_bytes is None:
                self.notify(
                    "Failed to load SVG. The file may be corrupted or not an SVG file.",
                    title="SVG Preview",
                    severity="error",
                )
                self.app.call_from_thread(self.remove_children)
                self.border_title = ""
                return
            elif png_bytes == b"cancelled":
                return

            if should_cancel():
                return

            self.call_next(self.LOADER_WIDGET.update, "resampling svg...")

            if self.app.MULTIPROCESSING_PROCESS_ALLOWED:
                try:
                    pil_object = preview_utils.resample(Image.open(BytesIO(png_bytes)))
                except ValueError as exc:
                    if multiprocessing_process_error_checker(self.app, exc):
                        pil_object = resample_sync(Image.open(BytesIO(png_bytes)))
                    else:
                        raise
            else:
                pil_object = resample_sync(Image.open(BytesIO(png_bytes)))

            if should_cancel():
                return

            if image_widget := self.get_child(".image_preview"):
                self.app.call_from_thread(setattr, image_widget, "image", pil_object)
            else:
                self.app.call_from_thread(self.remove_children)

                if should_cancel():
                    return

                image_widget = NewImage(pil_object)
                image_widget.can_focus = True
                self.app.call_from_thread(self.mount, image_widget)
        except ValueError as exc:
            if should_cancel():
                return
            self.app.call_from_thread(self.remove_children)
            self.app.call_from_thread(
                self.mount,
                Static(
                    f"Cannot render svg.\n{str(exc)}",
                    classes="special",
                ),
            )
            return
        except Exception as exc:
            if should_cancel():
                return
            self.app.call_from_thread(self.remove_children)
            self.app.call_from_thread(
                self.mount,
                Static(
                    f"Cannot render svg.\n{type(exc).__name__}: {str(exc)}",
                    classes="special",
                ),
            )
            return

    def show_image_preview(self) -> None:
        """Show image preview. Runs in a thread.

        Raises:
            ValueError: If image loading fails for non-fds_to_keep reasons.
        """
        if should_cancel() or self._current_file_path is None:
            return
        self.app.call_from_thread(setattr, self, "border_title", titles.image)

        try:
            if self.app.MULTIPROCESSING_PROCESS_ALLOWED:
                try:
                    pil_object = preview_utils.resample_file(self._current_file_path)
                except ValueError as exc:
                    if multiprocessing_process_error_checker(self.app, exc):
                        pil_object = resample_file_sync(self._current_file_path)
                    else:
                        raise
            else:
                pil_object = resample_file_sync(self._current_file_path)
            if pil_object is None:
                return
        except UnidentifiedImageError:
            if should_cancel():
                return
            self.app.call_from_thread(self.remove_children)
            self.app.call_from_thread(
                self.mount,
                Static(
                    f"Cannot render image (is the encoding wrong?)\nMIME Type: {self._mime_type}",
                    classes="special",
                ),
            )
            return
        except FileNotFoundError:
            if should_cancel():
                return
            self.app.call_from_thread(self.remove_children)
            self.app.call_from_thread(
                self.mount,
                Static(
                    self._preview_texts["error"],
                    classes="special",
                ),
            )
            return

        if image_widget := self.get_child(".image_preview"):
            if should_cancel():
                return
            self.app.call_from_thread(setattr, image_widget, "image", pil_object)
        else:
            self.app.call_from_thread(self.remove_children)

            if should_cancel():
                return

            image_widget = NewImage(pil_object)
            image_widget.can_focus = True
            self.app.call_from_thread(self.mount, image_widget)

        if should_cancel():
            return

    # ------------ PDF related functions start ------------

    def update_current_pdf_page_by_diff(self, diff: int) -> None:
        """Updates the current pages by a diff"""
        self.update_current_pdf_page(self.pdf.current_page + diff)

    # Note : We must ensure that any update to current_page happens via this
    def update_current_pdf_page(self, current_page: int) -> None:
        """Updates the current pages and ensure to spawn a worker that will eventually load them"""
        if current_page < 0 or current_page >= self.pdf.total_pages:
            return
        if current_page == self.pdf.current_page:
            return

        self.pdf.current_page = current_page
        setattr(
            self,
            "border_subtitle",
            f"Page {self.pdf.current_page + 1}/{self.pdf.total_pages}",
        )
        self._trigger_pdf_update()

    def load_pdf_pages(self, first_page: int, last_page: int) -> list[PILImage]:
        """
        Returns:
            List of images, one per pages fetched

        Raises:
            ValueError: If PDF conversion returns 0 pages.
        """
        if first_page > last_page:
            raise ValueError(
                f"Invalid args, first_page={first_page} > last_page={last_page}"
            )

        result = get_pdf_images(
            str(self._current_file_path),
            first_page=first_page,
            last_page=last_page,
            use_pdftocairo=config["plugins"]["poppler"]["use_pdftocairo"],
            thread_count=config["plugins"]["poppler"]["threads"],
            poppler_path=PDFHandler.get_poppler_folder(),
        )
        if len(result) == 0:
            raise ValueError(
                "Obtained 0 pages from Poppler. Something may have gone wrong..."
            )
        # Resample images once when loaded for better performance
        if self.app.MULTIPROCESSING_PROCESS_ALLOWED:
            try:
                return preview_utils.resample_batch(result)
            except ValueError as exc:
                if multiprocessing_process_error_checker(self.app, exc):
                    return resample_batch_sync(result)
                raise
        return resample_batch_sync(result)

    def show_pdf_preview(self) -> None:
        """
        Show PDF preview. Runs in a thread.
        The job of this function is to load the pdf file for the first time.
        Or ensure the batched loading
        """
        self.app.call_from_thread(setattr, self, "border_title", titles.pdf)

        if should_cancel() or self._current_file_path is None:
            return

        # Convert PDF to images if not already done
        if self.pdf.images is None:
            try:
                self.pdf.total_pages = int(
                    get_pdf_info(
                        str(self._current_file_path),
                        poppler_path=PDFHandler.get_poppler_folder(),
                    )["Pages"]
                )
                result = self.load_pdf_pages(
                    first_page=1, last_page=self.pdf.get_last_page_to_load()
                )
            except Exception as exc:
                if should_cancel():
                    return
                self.app.call_from_thread(self.remove_children)
                self.app.call_from_thread(
                    self.mount,
                    Static(f"{type(exc).__name__}: {str(exc)}", classes="special"),
                )
                return
            self.pdf.images = result

            # The only one case when current page and border subtitles
            # should be manually adjusted. Not the best design though.
            self.pdf.current_page = 0
            self.app.call_from_thread(
                setattr,
                self,
                "border_subtitle",
                f"Page {self.pdf.current_page + 1}/{self.pdf.total_pages}",
            )

        elif self.pdf.should_load_next_batch():
            # Saving the value per thread instead of recalculating after the load
            # Even if something changes in between, we want the threads that set the status to
            # loading, to always unset it
            toggle_loading = self.pdf.must_load_next_batch()

            if toggle_loading:
                self.post_message(self.SetLoading(True))
            try:
                result = self.load_pdf_pages(
                    first_page=self.pdf.count_loaded() + 1,
                    last_page=self.pdf.get_last_page_to_load(),
                )
            except Exception as exc:
                if should_cancel():
                    return
                if toggle_loading:
                    self.call_later(lambda: self.post_message(self.SetLoading(False)))
                self.app.call_from_thread(self.remove_children)
                self.app.call_from_thread(
                    self.mount,
                    Static(f"{type(exc).__name__}: {str(exc)}", classes="special"),
                )
                return
            if toggle_loading:
                self.call_later(lambda: self.post_message(self.SetLoading(False)))
            # Note - This should_cancel must be kept here, not before the `load_pdf_pages` call
            # That, somehow doesn't prevents multiple threads executing the load
            # even though, we successful prevent multiple threads
            # appending the results via this one
            # Also we must ensure to cancel only after you reset the SetLoading(false)
            # We don't want threads to Set the screen in Loading state, and never turn it back
            if should_cancel():
                return

            # This mutation on the `images` object should be done by one one thread
            # and the entire flow of checking `should_load_next_batch` to loading
            # to appending the pages should be atomic.
            # At this point, we are using `should_cancel` to allow only one thread
            # to reach here
            self.pdf.images += result

        if should_cancel():
            return

        current_image = self.pdf.images[self.pdf.current_page]

        if image_widget := self.get_child(".image_preview"):
            if should_cancel():
                return
            self.app.call_from_thread(setattr, image_widget, "image", current_image)
        else:
            self.app.call_from_thread(self.remove_children)
            self.app.call_from_thread(self.remove_class, "bat", "full", "clip")

            if should_cancel():
                return

            image_widget = NewImage(current_image)
            image_widget.can_focus = True
            self.app.call_from_thread(self.mount, image_widget)

        if should_cancel():
            return

    # ------------ PDF related functions end ------------

    def show_bat_file_preview(self) -> bool:
        """Show bat file preview. Runs in a thread.

        Returns:
            bool: True if successful, False otherwise.
        """
        bat_executable = config["plugins"]["bat"]["executable"]
        command = [
            bat_executable,
            "--force-colorization",
            "--paging=never",
            "--style=numbers"
            if config["interface"]["show_line_numbers"]
            else "--style=plain",
        ]
        max_lines = self.size.height
        if max_lines > 0:
            command.append(f"--line-range=:{max_lines}")
        assert self._current_file_path is not None
        command.extend(["--", self._current_file_path])

        if should_cancel():
            return False

        from rich.text import Text

        self.app.call_from_thread(setattr, self, "border_title", titles.bat)

        try:
            # Use synchronous subprocess since we're already in a thread
            result = subprocess.run(
                command,
                capture_output=True,
                text=False,
            )

            if should_cancel():
                return False

            if result.returncode == 0:
                bat_output = result.stdout.decode("utf-8", errors="ignore")
                new_content = Text.from_ansi(bat_output)

                if should_cancel():
                    return False

                if static_widget := self.get_child("Static"):
                    self.log("Using existing Static")
                    self.app.call_from_thread(static_widget.update, new_content)
                    self.app.call_from_thread(static_widget.set_classes, "bat_preview")
                else:
                    self.log("Mounting new Static")
                    self.app.call_from_thread(self.remove_children)

                    if should_cancel():
                        return False

                    static_widget = Static(new_content, classes="bat_preview")
                    self.app.call_from_thread(self.mount, static_widget)
                    if should_cancel():
                        return False
                    static_widget.can_focus = True
                return True
            else:
                error_message = result.stderr.decode("utf-8", errors="ignore")
                if should_cancel():
                    return False
                self.app.call_from_thread(self.remove_children)
                self.app.call_from_thread(
                    self.notify,
                    error_message,
                    title="Plugins: Bat",
                    severity="warning",
                )
                return False
        except Exception as exc:
            if should_cancel():
                return False
            self.app.call_from_thread(
                self.notify, str(exc), title="Plugins: Bat", severity="error"
            )
            path_utils.dump_exc(self, exc)
            return False

    def show_normal_file_preview(self) -> None:
        """Show normal file preview with syntax highlighting. Runs in a thread."""
        if should_cancel():
            return

        from rich.syntax import Syntax

        self.app.call_from_thread(setattr, self, "border_title", titles.file)

        if not isinstance(self._current_content, str):
            # force read by brute-forcing encoding methods
            encodings_to_try = [
                "utf8",
                "utf16",
                "utf32",
                "latin1",
                "iso8859-1",
                "mbcs",
                "ascii",
                "us-ascii",
            ]
            for encoding in encodings_to_try:
                try:
                    with open(self._current_file_path, "r", encoding=encoding) as f:
                        self._current_content = f.read(1024)
                    break
                except (UnicodeDecodeError, FileNotFoundError):
                    continue
            if self._current_content is None:
                self._current_content = self._preview_texts["error"]
                self.mount_special_messages()
                return

        lines = self._current_content.splitlines()
        max_lines = self.size.height
        if max_lines > 0:
            if len(lines) > max_lines:
                lines = lines[:max_lines]
        else:
            lines = []
        max_width = self.size.width * 2
        if max_width > 0:
            processed_lines = []
            for line in lines:
                if len(line) > max_width:
                    processed_lines.append(line[:max_width])
                else:
                    processed_lines.append(line)
            lines = processed_lines
        text_to_display = "\n".join(lines)
        # add syntax highlighting
        language = (
            guess_language(text_to_display, path=self._current_file_path) or "text"
        )
        syntax = Syntax(
            text_to_display,
            lexer=language,
            line_numbers=config["interface"]["show_line_numbers"],
            word_wrap=False,
            tab_size=4,
            theme=config["theme"]["preview"],
            background_color=None,
            code_width=max_width,
        )

        if should_cancel():
            return

        if static_widget := self.get_child("Static"):
            self.app.call_from_thread(static_widget.update, syntax)
        else:
            self.app.call_from_thread(self.remove_children)

            if should_cancel():
                return

            self.app.call_from_thread(self.mount, Static(syntax))

        if should_cancel():
            return

    def show_folder_preview(self, folder_path: str) -> None:
        """Show folder preview."""
        if should_cancel():
            return
        self.app.call_from_thread(setattr, self, "border_title", titles.folder)

        if not (this_list := self.get_child("FileList")):
            self.app.call_from_thread(self.remove_children)

            if should_cancel():
                return

            this_list = FileList(
                name=folder_path,
                classes="file-list",
                dummy=True,
                enter_into=folder_path,
            )
            self.app.call_from_thread(self.mount, this_list)

        if should_cancel():
            return

        assert isinstance(this_list, FileList)
        this_list.enter_into = folder_path

        self.app.call_from_thread(this_list.set_classes, "file-list")

        # Query StateManager for sort preferences for the previewed folder
        from rovr.functions.path import normalise
        from rovr.state_manager import StateManager

        state_manager: StateManager = self.app.query_one(StateManager)
        normalised_path = normalise(folder_path)
        sort_by, sort_descending = state_manager.get_sort_prefs(normalised_path)
        options = []
        try:
            loading_timer = self.app.call_from_thread(
                self.set_timer,
                0.25,
                lambda: setattr(self, "border_subtitle", "Getting list\u2026"),
            )
            folders, files = path_utils.sync_get_cwd_object(
                self,
                folder_path,
                config["interface"]["show_hidden_files"],
                sort_by=sort_by,
                reverse=sort_descending,
                return_nothing_if_this_returns_true=should_cancel,
            )
            loading_timer.stop()  # if timer did not fire, stop it
            if files is None or folders is None:
                return
            if not (folders or files):
                options = [Selection("  --no-files--", value="", id="", disabled=True)]
            else:
                file_list_options = folders + files
                file_list_option_length = len(file_list_options)
                start_time = time()
                for index, item in enumerate(file_list_options):
                    options.append(
                        FileListSelectionWidget(
                            icon_factory=item["icon"],
                            label=item["name"],
                            dir_entry=item["dir_entry"],
                            clipboard=self.app.Clipboard,
                        )
                    )
                    if start_time + 0.25 < time():
                        self.app.call_from_thread(
                            setattr,
                            self,
                            "border_subtitle",
                            f"{index + 1} / {file_list_option_length}",
                        )
                        start_time = time()
                        if should_cancel():
                            loading_timer.stop()
                            return
        except PermissionError:
            options = [
                Selection(
                    " Permission Error: Unable to access this directory.",
                    id="",
                    value="",
                    disabled=True,
                )
            ]
        loading_timer.stop()
        if should_cancel():
            return
        self.call_next(setattr, self, "border_subtitle", "")
        self.app.call_from_thread(this_list.set_options, options)

    def show_archive_preview(self) -> None:
        """Show archive preview."""
        if should_cancel():
            return
        self.app.call_from_thread(setattr, self, "border_title", titles.archive)

        if not (file_list := self.get_child("FileList")):
            self.app.call_from_thread(self.remove_children)

            if should_cancel():
                return

            file_list = FileList(
                classes="archive-list",
                dummy=True,
            )

            self.app.call_from_thread(self.mount, file_list)

        if should_cancel():
            return

        assert isinstance(file_list, FileList)

        self.app.call_from_thread(file_list.set_classes, "archive-list")
        options = []
        if not self._current_content:
            options = [Selection("  --no-files--", value="", id="", disabled=True)]
        else:

            def get_archive_icon(target_file_path: str) -> tuple[str, str]:
                if target_file_path.endswith("/"):
                    return icon_utils.get_icon_for_folder(target_file_path.strip("/"))
                return icon_utils.get_icon_for_file(target_file_path)

            file_list_length = len(self._current_content)
            start_time = time()
            for index, file_path in enumerate(self._current_content):
                options.append(
                    ArchiveFileListSelection(
                        lambda file_path=file_path: get_archive_icon(file_path),
                        file_path,
                    )
                )
                if start_time + 0.25 < time():
                    self.app.call_from_thread(
                        setattr,
                        self,
                        "border_subtitle",
                        f"{index + 1} / {file_list_length}",
                    )
                    start_time = time()
                    if should_cancel():
                        return

        if should_cancel():
            return
        self.app.call_from_thread(file_list.set_options, options)
        self.app.call_from_thread(setattr, self, "border_subtitle", "")

    def show_preview(self, file_path: str, mtime: int | float) -> None:
        """Public method to show preview."""
        if (
            "hide" in self.classes
            or "-no-preview" in self.screen.classes
            or "-filelist-only" in self.screen.classes
        ):
            self._pending_preview_args = (file_path, mtime)
            return
        self._pending_preview_args = None
        self.perform_show_preview(file_path, mtime)

    @work(exclusive=True, thread=True)
    def perform_show_preview(self, file_path: str, mtime: int) -> None:
        """Main preview worker. Runs in a thread."""
        try:
            if should_cancel():
                return

            if file_path == self._current_file_path:
                # check mtime as well
                try:
                    new_mtime = path.getmtime(file_path)
                except FileNotFoundError:
                    # if file is gone/symlink target is gone
                    self.app.call_from_thread(self.file_not_found, file_path)
                    return
                if self._file_mtime == new_mtime:
                    return

            self.app.call_from_thread(setattr, self, "border_subtitle", "")
            if should_cancel():
                return
            self.post_message(self.SetLoading(True))

            # Reset PDF state when changing files
            if file_path != self._current_file_path:
                self.pdf.images = None
                self.pdf.current_page = 0
                self.pdf.total_pages = 0

            if path.isdir(file_path):
                self.update_ui(
                    file_path=file_path,
                    mime_type=path_utils.MimeResult("basic", "inode/directory"),
                    file_type="folder",
                )
            else:
                content = None  # for now
                mime_result = path_utils.get_mime_type(file_path, mtime)
                self.log(mime_result)
                if mime_result is None:
                    self.log(f"Could not get MIME type for {file_path}")
                    self.update_ui(
                        file_path=file_path,
                        file_type="file",
                        content=self._preview_texts["error"],
                    )
                    self.call_later(lambda: self.post_message(self.SetLoading(False)))
                    return
                content = mime_result.content

                file_type = path_utils.match_mime_to_preview_type(
                    self, mime_result.mime_type
                )
                if file_type is None:
                    self.log("Could not match MIME type to preview type")
                    self.update_ui(
                        file_path=file_path,
                        file_type="file",
                        mime_type=mime_result,
                        content=self._preview_texts["error"],
                    )
                    self.call_later(lambda: self.post_message(self.SetLoading(False)))
                    return
                elif file_type == "remime":
                    mime_result = path_utils.get_mime_type(
                        file_path, mtime, ("basic", "puremagic")
                    )
                    if mime_result is None:
                        self.log("Could not get MIME type for remime")
                        self.update_ui(
                            file_path=file_path,
                            file_type="file",
                            content=self._preview_texts["error"],
                            mime_type=mime_result,
                        )
                        self.call_later(
                            lambda: self.post_message(self.SetLoading(False))
                        )
                        return
                    file_type = path_utils.match_mime_to_preview_type(
                        self, mime_result.mime_type
                    )
                    if file_type is None:
                        self.log("Could not match MIME type to preview type")
                        self.update_ui(
                            file_path=file_path,
                            file_type="file",
                            mime_type=mime_result,
                            content=self._preview_texts["error"],
                        )
                        self.call_later(
                            lambda: self.post_message(self.SetLoading(False))
                        )
                        return
                self.log(f"Previewing as {file_type} (MIME: {mime_result.mime_type})")

                if file_type == "archive":
                    try:
                        with Archive(file_path, mode="r") as archive:
                            all_files = []
                            for member in archive.infolist():
                                if should_cancel():
                                    self.call_later(
                                        lambda: self.post_message(
                                            self.SetLoading(False)
                                        )
                                    )
                                    return

                                if not member.is_dir:
                                    all_files.append(member.name)
                        content = all_files
                    except (
                        BadArchiveError,
                        ValueError,
                        FileNotFoundError,
                    ):
                        content = [self._preview_texts["error"]]

                self.update_ui(
                    file_path,
                    file_type=file_type,
                    content=content,
                    mime_type=mime_result,
                )

            if should_cancel():
                return
            self.call_later(lambda: self.post_message(self.SetLoading(False)))

            if should_cancel():
                return
        except Exception as exc:
            self.notify(
                f"{type(exc).__name__} was raised while generating the preview\n{str(exc)}",
                severity="error",
                markup=False,
            )
            path_utils.dump_exc(self, exc)

    def update_ui(
        self,
        file_path: str,
        file_type: str,
        content: str | list[str] | None = None,
        mime_type: path_utils.MimeResult | None = None,
    ) -> None:
        """
        Update the preview UI. Runs in a thread, uses call_from_thread for UI ops.
        """
        self._current_file_path = file_path
        self._current_content = content
        self._mime_type = mime_type
        self._file_mtime = path.getmtime(file_path)

        self._file_type = file_type
        self.app.call_from_thread(self.remove_class, "pdf")
        if file_type == "folder":
            self.log("Showing folder preview")
            self.show_folder_preview(file_path)
        elif file_type == "image":
            self.log("Showing image preview")
            self.show_image_preview()
        elif file_type == "archive":
            self.log("Showing archive preview")
            self.show_archive_preview()
        elif file_type == "pdf":
            self.log("Showing pdf preview")
            self.app.call_from_thread(self.add_class, "pdf")
            self.show_pdf_preview()
        elif file_type == "resvg":
            self.log("Showing resvg preview")
            self.show_resvg_preview()
        elif file_type == "font":
            self.log("Showing font preview")
            self.show_font_preview()
        else:
            if content in self._preview_texts.values():
                self.log("Showing special preview")
                self.mount_special_messages()
            else:
                if config["plugins"]["bat"]["enabled"]:
                    self.log("Showing bat preview")
                    if self.show_bat_file_preview():
                        return
                self.show_normal_file_preview()

    def mount_special_messages(self) -> None:
        """Mount special messages. Runs in a thread."""
        if should_cancel():
            return
        self.log(self._mime_type)
        assert isinstance(self._current_content, str)
        self.app.call_from_thread(setattr, self, "border_title", "")

        display_content: str = self._current_content
        if self._mime_type:
            display_content = f"MIME Type: {self._mime_type.mime_type}"
            if (
                config["plugins"]["file_one"]["enabled"]
                and config["plugins"]["file_one"]["get_description"]
            ):
                try:
                    executable = file_one()
                    if executable:
                        process = subprocess.run(
                            [executable, "--brief", "--", self._current_file_path],
                            capture_output=True,
                            text=True,
                            check=True,
                            timeout=1,
                        )
                        display_content += f"\n{process.stdout.strip()}"
                except (subprocess.SubprocessError, FileNotFoundError) as exc:
                    path_utils.dump_exc(self, exc)

        if static_widget := self.get_child("Static"):
            self.app.call_from_thread(static_widget.update, display_content)
            self.app.call_from_thread(static_widget.set_classes, "special")
        else:
            self.app.call_from_thread(self.remove_children)
            if should_cancel():
                return
            static_widget = Static(display_content, classes="special")
            self.app.call_from_thread(self.mount, static_widget)
        # not wasting an isinstance on this
        cast(Static, static_widget).can_focus = True

    def on_mouse_scroll_up(self, event: events.MouseScrollUp) -> None:
        """Handle mouse scroll up for PDF navigation."""
        if self.border_title == titles.pdf and self._file_type == "pdf":
            event.stop()
            self.update_current_pdf_page_by_diff(-1)

    def on_mouse_scroll_down(self, event: events.MouseScrollDown) -> None:
        """Handle mouse scroll down for PDF navigation."""
        if self.border_title == titles.pdf and self._file_type == "pdf":
            event.stop()
            self.update_current_pdf_page_by_diff(1)

    # not sure if exclusive does anything, but whatever
    @work(thread=True, exclusive=True)
    def _trigger_pdf_update(self) -> None:
        """Trigger PDF preview update from a thread."""
        self.show_pdf_preview()

    @property
    def size(self) -> Size:
        if self.loading:
            return self._render_widget.size
        else:
            return self.content_region.size

    # commented out until further notice
    # felt like there was an issue with the way file list
    # updates on resize, so this remains as is, until i
    # resolve that
    # def on_resize(self, event: events.Resize) -> None:
    #     """Re-render the preview on resize"""
    #     if self.get_child("Static") and event.size.height != self._initial_height:
    #         if self._current_content is not None:
    #             is_special_content = self._current_content in self._preview_texts.values()
    #             if not is_special_content:
    #                 self._trigger_resize_update()
    #         self._initial_height = event.size.height

    @work(thread=True)
    def _trigger_resize_update(self) -> None:
        """Trigger resize update from a thread."""
        if config["plugins"]["bat"]["enabled"] and self.show_bat_file_preview():
            return
        self.show_normal_file_preview()

    @on(events.Show)
    def when_become_visible(self) -> None:
        if isinstance(self._pending_preview_args, tuple):
            pending = self._pending_preview_args
            self._pending_preview_args = None
            self.show_preview(pending[0], pending[1])

    def on_key(self, event: events.Key) -> None:
        """Check for vim keybinds."""
        from rovr.functions.utils import check_key

        if (
            check_key(event, config["keybinds"]["up"])
            and self.action_up() is None
            or check_key(event, config["keybinds"]["down"])
            and self.action_down() is None
            or check_key(event, config["keybinds"]["page_up"])
            and self.action_page_up() is None
            or check_key(event, config["keybinds"]["page_down"])
            and self.action_page_down() is None
            or check_key(event, config["keybinds"]["home"])
            and self.action_home() is None
            or check_key(event, config["keybinds"]["end"])
            and self.action_end() is None
        ):
            event.stop()

    def on_click(self, event: events.Click) -> None:
        if event.widget is self and self.children:
            self.children[-1].focus()

    def _is_pdf(self) -> bool:
        return self.border_title == titles.pdf and self._file_type == "pdf"

    def action_up(self) -> Literal[False] | None:
        if self._is_pdf() and self.pdf.images is not None:
            self.update_current_pdf_page_by_diff(-1)
        elif self.border_title == titles.archive and (
            filelist := self.get_child(FileList)
        ):
            filelist.scroll_up(animate=False)
        else:
            return False

    def action_down(self) -> Literal[False] | None:
        if self._is_pdf() and self.pdf.images is not None:
            self.update_current_pdf_page_by_diff(1)
        elif self.border_title == titles.archive and (
            filelist := self.get_child(FileList)
        ):
            filelist.scroll_down(animate=False)
        else:
            return False

    def action_page_up(self) -> Literal[False] | None:  # ty: ignore[invalid-method-override]
        if self._is_pdf() and self.pdf.images is not None:
            self.update_current_pdf_page_by_diff(-1)
        elif self.border_title == titles.archive and (
            filelist := self.get_child(FileList)
        ):
            filelist.scroll_page_up(animate=False)
        else:
            return False

    def action_page_down(self) -> Literal[False] | None:  # ty: ignore[invalid-method-override]
        if self._is_pdf() and self.pdf.images is not None:
            self.update_current_pdf_page_by_diff(1)
        elif self.border_title == titles.archive and (
            filelist := self.get_child(FileList)
        ):
            filelist.scroll_page_down(animate=False)
        else:
            return False

    def action_home(self) -> Literal[False] | None:
        if self._is_pdf() and self.pdf.images is not None:
            self.update_current_pdf_page(0)
        elif self.border_title == titles.archive and (
            filelist := self.get_child(FileList)
        ):
            filelist.scroll_home(animate=False)
        else:
            return False

    def action_end(self) -> Literal[False] | None:
        if self._is_pdf() and self.pdf.images is not None:
            self.update_current_pdf_page(self.pdf.total_pages - 1)
        elif self.border_title == titles.archive and (
            filelist := self.get_child(FileList)
        ):
            filelist.scroll_end(animate=False)
        else:
            return False
