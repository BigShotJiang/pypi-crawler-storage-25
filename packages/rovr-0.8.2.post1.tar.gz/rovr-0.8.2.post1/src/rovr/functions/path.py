from __future__ import annotations

import asyncio
import base64
import ctypes
import os
import re
import stat
import subprocess
from functools import lru_cache, partial
from os import path
from typing import Callable, Literal, NamedTuple, TypedDict, overload

from rich.console import Console
from textual import work
from textual.app import App
from textual.dom import DOMNode

from rovr import pprint
from rovr.classes.type_aliases import (
    DirEntryType,
    DirEntryTypes,
    PreviewTypes,
    SortByOptions,
)
from rovr.variables.constants import config, file_one, log_name, os_type

from .drive_workers import normalise
from .icons import get_icon_for_file, get_icon_for_folder

mime_re_cache: dict[
    PreviewTypes,
    list[re.Pattern],
] = {}
mime_preview_cache: dict[str, PreviewTypes | None] = {}


# natsort dead
@lru_cache(maxsize=8196)
def natsort(key: str) -> list:
    import re

    return [
        int(text) if text.isdigit() else text.lower()
        for text in re.split(r"(\d+)", key)
    ]


def is_hidden_file(filepath: str) -> bool:
    if os_type == "Windows":
        try:
            GetFileAttributesW = ctypes.windll.kernel32.GetFileAttributesW
            GetFileAttributesW.argtypes = [ctypes.c_wchar_p]
            GetFileAttributesW.restype = ctypes.c_uint32
            attrs = GetFileAttributesW(filepath)
            if attrs == 0xFFFFFFFF:  # INVALID_FILE_ATTRIBUTES
                return False
            return bool(attrs & 0x02)  # FILE_ATTRIBUTE_HIDDEN
        except (OSError, AttributeError):
            return False
    elif os_type == "Darwin":
        # dotfiles should always be hidden, and so should UF_HIDDEN-flagged files
        name_hidden = path.basename(filepath).startswith(".")
        try:
            st = os.stat(filepath, follow_symlinks=False)
            flag_hidden = bool(
                getattr(st, "st_flags", 0) & getattr(stat, "UF_HIDDEN", 0)
            )
        except OSError:
            flag_hidden = False
        return name_hidden or flag_hidden
    else:
        return path.basename(filepath).startswith(".")


# insanely scuffed implementation, but it's required due
# to Textual's strict limitation for ids to consist of
# letters, numbers, underscores, or hyphens, and must
# not begin with a number
def compress(text: str) -> str:
    return "u_" + base64.urlsafe_b64encode(text.encode("utf-8")).decode(
        "ascii"
    ).replace("=", "_")


def decompress(text: str) -> str:
    return base64.urlsafe_b64decode(text[2:].replace("_", "=").encode("ascii")).decode(
        "utf-8"
    )


create_proc = partial(
    asyncio.create_subprocess_exec,
    stdout=asyncio.subprocess.PIPE,
    stderr=asyncio.subprocess.PIPE,
)


@work
async def open_file(app: App, filepath: str) -> None:
    """Cross-platform function to open files with their default application.

    Args:
        app (App): The Textuall application instance
        filepath (str): Path to the file to open
    """
    system = os_type.lower()
    # check if it is available first
    if not path.exists(filepath):
        app.notify(
            f"File not found: {filepath}",
            title="Open File",
            severity="error",
            markup=False,
        )
        return

    try:
        match system:
            case "windows":
                process = await create_proc(
                    "cmd",
                    "/c",
                    "start",
                    "",
                    filepath,
                )
            case "darwin":  # macOS
                process = await create_proc("open", filepath)
            case _:  # Linux and other Unix-like
                process = await create_proc("xdg-open", filepath)
        _, stderr = await process.communicate()
        if stderr:
            app.notify(
                str(stderr.decode().strip()),
                title="Open File",
                severity="error",
                markup=False,
            )
        elif process.returncode and process.returncode != 0:
            app.notify(
                f"Process exited with return code {process.returncode}",
                title="Open File",
                severity="error",
                markup=False,
            )
    except Exception as e:
        app.notify(str(e), title="Open File", severity="error", markup=False)


def get_filtered_dir_names(cwd: str | bytes, show_hidden: bool = False) -> set[str]:
    """
    Get the names of all items in a directory, respecting the show_hidden setting.
    This function is used for comparison in file watchers to avoid refresh loops.

    Args:
        cwd(str): The working directory to check
        show_hidden(bool): Whether to include hidden files/folders

    Returns:
        set[str]: A set of item names in the directory

    Raises:
        PermissionError: When access to the directory is denied
    """
    try:
        listed_dir = os.scandir(cwd)
    except (PermissionError, FileNotFoundError, OSError):
        raise PermissionError(f"PermissionError: Unable to access {cwd}")

    names = set()
    for item in listed_dir:
        if not show_hidden and is_hidden_file(item.path):
            continue
        names.add(item.name)

    return names


class CWDObjectReturnDict(TypedDict):
    name: str
    icon: Callable[[], tuple[str, str]]
    dir_entry: DirEntryType


def get_extension_sort_key(file_dict: dict) -> tuple[int, str]:
    name = file_dict["name"]
    if "." not in name:
        # files without extensions
        return (1, name.lower())
    elif name.startswith(".") and name.count(".") == 1:
        # dotfiles
        return (2, name[1:].lower())
    else:
        # files with extensions
        return (3, name.split(".")[-1].lower())


def sorter(
    thing: CWDObjectReturnDict, sort_st: Literal["ctime", "mtime", "size"]
) -> int | float | str:
    try:
        match sort_st:
            case "ctime":
                return thing["dir_entry"].stat().st_ctime_ns
            case "mtime":
                return thing["dir_entry"].stat().st_mtime_ns
            case "size":
                try:
                    return thing["dir_entry"].stat().st_size
                except FileNotFoundError:
                    return 0  # only for this, since it makes sense
    except FileNotFoundError:
        # if  we cant access it, sort with name
        return thing["name"].lower()


@overload
def sync_get_cwd_object(
    dom_node: DOMNode,
    cwd: str,
    show_hidden: bool = False,
    sort_by: SortByOptions | None = "name",
    reverse: bool = False,
) -> tuple[list[CWDObjectReturnDict], list[CWDObjectReturnDict]]: ...


@overload
def sync_get_cwd_object(
    dom_node: DOMNode,
    cwd: str,
    show_hidden: bool = False,
    sort_by: SortByOptions | None = "name",
    reverse: bool = False,
    return_nothing_if_this_returns_true: Callable[[], bool] | None = None,
) -> (
    tuple[list[CWDObjectReturnDict], list[CWDObjectReturnDict]] | tuple[None, None]
): ...


def sync_get_cwd_object(
    dom_node: DOMNode,
    cwd: str,
    show_hidden: bool = False,
    sort_by: SortByOptions | None = "name",
    reverse: bool = False,
    return_nothing_if_this_returns_true: Callable[[], bool] | None = None,
) -> tuple[list[CWDObjectReturnDict], list[CWDObjectReturnDict]] | tuple[None, None]:
    """
    Get the objects (files and folders) in a provided directory
    Args:
        dom_node(DOMNode): The DOM node requesting this operation
        cwd(str): The working directory to check
        show_hidden(bool): Whether to include hidden files/folders (dot-prefixed on Unix; flagged hidden on Windows/macOS)
        sort_by(str): What to sort by
        reverse(bool): Whether to reverse the sorting
        return_nothing_if_this_returns_true(Callable[[], bool] | None): A callable that returns a bool. If it returns True, the function returns None.

    Returns:
        tuple[list[dict], list[dict]]: (folders, files) on success
        tuple[None, None]: When early termination is triggered

    Raises:
        TypeError: if the wrong type is received
        PermissionError: When access to the directory is denied
    """

    try:
        scanned_entries = os.scandir(cwd)
    except (PermissionError, FileNotFoundError, OSError):
        raise PermissionError(f"PermissionError: Unable to access {cwd}")

    with scanned_entries as entries:
        if (
            return_nothing_if_this_returns_true is not None
            and return_nothing_if_this_returns_true()
        ):
            if globals().get("is_dev", False):
                print("Cut off early after scandir")
            return None, None

        folders: list[CWDObjectReturnDict] = []
        files: list[CWDObjectReturnDict] = []

        for item in entries:
            if not isinstance(item, DirEntryTypes):
                raise TypeError(f"Expected a DirEntry object but got {type(item)}")
            if not show_hidden and is_hidden_file(item.path):
                continue

            if item.is_dir():
                item_name = item.name
                folders.append({
                    "name": item_name,
                    "icon": lambda item_name=item_name: get_icon_for_folder(item_name),
                    "dir_entry": item,
                })
            else:
                item_name = item.name
                files.append({
                    "name": item_name,
                    "icon": lambda item_name=item_name: get_icon_for_file(item_name),
                    "dir_entry": item,
                })
            if (
                return_nothing_if_this_returns_true is not None
                and return_nothing_if_this_returns_true()
            ):
                if globals().get("is_dev", False):
                    dom_node.log("Cut off early during dictionary building")
                return None, None

    dom_node.log(f"Collected {len(folders)} folders and {len(files)} files in {cwd}")

    # sort order
    match sort_by:
        case "name":
            folders.sort(key=lambda x: x["name"].lower())
            files.sort(key=lambda x: x["name"].lower())
        case "natural":
            folders.sort(key=lambda x: natsort(x["name"]))
            files.sort(key=lambda x: natsort(x["name"]))
        case "created":
            folders.sort(key=lambda x: sorter(x, "ctime"))
            files.sort(key=lambda x: sorter(x, "ctime"))
        case "modified":
            folders.sort(key=lambda x: sorter(x, "mtime"))
            files.sort(key=lambda x: sorter(x, "mtime"))
        case "size":
            # no we will not be calculating the folder size
            folders.sort(key=lambda x: x["name"].lower())
            files.sort(key=lambda x: sorter(x, "size"))
        case "extension":
            # folders dont have extensions btw
            # and i will not count dot prepended folders
            folders.sort(key=lambda x: x["name"].lower())
            files.sort(key=get_extension_sort_key)
        case None:
            pass

    if (
        return_nothing_if_this_returns_true is not None
        and return_nothing_if_this_returns_true()
    ):
        if globals().get("is_dev", False):
            dom_node.log("Cut off early before reversing results")
        return None, None
    if reverse:
        files.reverse()
        folders.reverse()

    if globals().get("is_dev", False):
        dom_node.log(f"Found {len(folders)} folders and {len(files)} files in {cwd}")
    return folders, files


def file_is_type(
    file_path: str,
) -> Literal["unknown", "symlink", "directory", "junction", "file"]:
    """Get a given path's type
    Args:
        file_path(str): The file path to check

    Returns:
        str: The string that says what type it is (unknown, symlink, directory, junction or file)
    """
    try:
        file_stat = os.lstat(file_path)
    except (OSError, FileNotFoundError):
        return "unknown"
    mode = file_stat.st_mode
    if stat.S_ISLNK(mode):
        return "symlink"
    elif (
        os_type == "Windows"
        and getattr(file_stat, "st_file_attributes", 0)
        & stat.FILE_ATTRIBUTE_REPARSE_POINT
    ):
        return "junction"
    elif stat.S_ISDIR(mode):
        return "directory"
    else:
        return "file"


def force_obtain_write_permission(item_path: str) -> bool:
    """
    Forcefully obtain write permission to a file or directory.

    Args:
        item_path (str): The path to the file or directory.

    Returns:
        bool: True if permission was granted successfully, False otherwise.
    """
    if not path.exists(item_path):
        return False
    try:
        current_permissions = stat.S_IMODE(os.lstat(item_path).st_mode)
        os.chmod(item_path, current_permissions | stat.S_IWRITE)
        return True
    except (OSError, PermissionError) as e:
        pprint(
            f"[bright_red]Permission Error:[/] Failed to change permission for {item_path}: {e}"
        )
        return False


class FileObj(TypedDict):
    path: str
    relative_loc: str


@overload
def get_recursive_files(object_path: str) -> list[FileObj]: ...


@overload
def get_recursive_files(
    object_path: str, with_folders: Literal[False]
) -> list[FileObj]: ...


@overload
def get_recursive_files(
    object_path: str, with_folders: Literal[True]
) -> tuple[list[FileObj], list[str]]: ...


def get_recursive_files(
    object_path: str, with_folders: bool = False
) -> list[FileObj] | tuple[list[FileObj], list[str]]:
    """Get the files available at a directory recursively, regardless of whether it is a directory or not
    Args:
        object_path (str): The object's path
        with_folders (bool): Return a list of folders as well

    Returns:
        list: A list of dictionaries, with a "path" key and "relative_loc" key
        OR
        list: A list of dictionaries, with a "path" key and "relative_loc" key for files
        list: A list of path strings that were involved in the file list.
    """
    if file_is_type(object_path) != "directory":
        if with_folders:
            return [
                FileObj(
                    path=normalise(object_path),
                    relative_loc=path.basename(object_path),
                )
            ], []
        return [
            FileObj(
                path=normalise(object_path),
                relative_loc=path.basename(object_path),
            )
        ]
    else:
        files = []
        folders = []
        for folder, folders_in_folder, files_in_folder in os.walk(object_path):
            if with_folders:
                for folder_in_folder in folders_in_folder:
                    full_path = normalise(path.join(folder, folder_in_folder))
                    if full_path not in folder:
                        folders.append(full_path)
            for file in files_in_folder:
                full_path = normalise(path.join(folder, file))  # normalise the path
                files.append(
                    FileObj(
                        path=full_path,
                        relative_loc=normalise(
                            path.relpath(full_path, object_path + "/..")
                        ),
                    )
                )
        if with_folders:
            return files, folders
        return files


def ensure_existing_directory(directory: str) -> str:
    while not (path.exists(directory) and path.isdir(directory)):
        parent = path.dirname(directory)
        # If we can't even access the root then there is a bigger problem
        # and this could result in infinite loop
        if parent == directory:
            break

        directory = parent
    if directory == "":
        directory = "."
    return directory


def match_mime_to_preview_type(
    widget: DOMNode,
    mime_type: str,
) -> (
    Literal["text", "image", "pdf", "archive", "folder", "remime", "resvg", "font"]
    | None
):
    """
    Match a MIME type against configured rules to determine preview type.

    Args:
        widget: The DOMNode widget to log to if needed
        mime_type: The MIME type to match (e.g., "text/plain", "image/png")

    Returns:
        str : The preview type ("text", "image", "pdf", "archive", "folder")
        None: None if no rule matches
    """
    if mime_type in mime_preview_cache:
        return mime_preview_cache[mime_type]

    global mime_re_cache

    if not mime_re_cache:
        widget.log("Compiling MIME type regexes for the first time...")
        for pattern, preview_type in config["interface"]["mime_rules"].items():
            if preview_type not in mime_re_cache:
                mime_re_cache[preview_type] = []
            mime_re_cache[preview_type].append(re.compile(pattern))

    for preview_type, patterns in mime_re_cache.items():
        for pattern in patterns:
            if pattern.fullmatch(mime_type):
                mime_preview_cache[mime_type] = preview_type
                return preview_type
    mime_preview_cache[mime_type] = None
    return None


class MimeResult(NamedTuple):
    method: Literal["basic", "puremagic", "file1"]
    mime_type: str
    content: str | None = None


@lru_cache(maxsize=8192)
def get_mime_type(
    file_path: str,
    mtime: int | float,
    ignore: tuple[Literal["basic", "puremagic", "file1"], ...] | None = None,
) -> MimeResult | None:
    """
    Synchronous/Threaded wrapper to get the MIME type of a file.

    Args:
        file_path: Path to the file to check
        mtime: The last modified time of the file, used for caching purposes
        ignore: List of detection methods to skip

    Returns:
        MimeResult: The method used and the detected MIME type
        None: If the method is not available or failed

    Raises:
        FileNotFoundError: If file(1) executable is unavailable when that method is selected.
        ╰╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┴> Ruff wants this part here, even though the function
                           handles it internally, so I'm just leaving it here
    """
    if ignore is None:
        ignore = ()

    base = path.basename(file_path)
    if base.startswith("."):
        file_extension = base[1:]
    else:
        file_extension = "".join(base.split(".")[1:]).lower()

    # Read file bytes once, reuse for both puremagic and basic detection
    try:
        with open(file_path, "rb") as f:
            file_bytes = f.read(1024)  # Read first 1KiB
    except OSError:
        # Cannot open file at all
        return None

    # Step 1: Try puremagic (magic byte detection) first
    if "puremagic" not in ignore:
        import puremagic

        try:
            puremagic_result: list[puremagic.PureMagicWithConfidence] = (
                puremagic.magic_string(file_bytes)
            )
            if puremagic_result:
                # If multiple matches exist, prefer one matching the file extension
                for match in puremagic_result:
                    if match.extension.lower() == file_extension and match.mime_type:
                        return MimeResult("puremagic", match.mime_type)
                # Otherwise, return first result with a mime type
                for match in puremagic_result:
                    if match.mime_type:
                        return MimeResult("puremagic", match.mime_type)
        except Exception:
            # puremagic failed, continue to next method
            pass

    # Step 2: Try decoding as text, checking all encodings in order of most likely
    # If puremagic didn't recognise it, it might perhaps be a plain text file
    if "basic" not in ignore:
        from textual.highlight import guess_language

        encodings_to_try = [
            "utf8",
            "utf16",
            "utf32",
            "latin1",
            "iso8859-1",
            "mbcs",
            "ascii",
            "us-ascii",
        ]

        for encoding in encodings_to_try:
            try:
                content = file_bytes.decode(encoding)
                return MimeResult(
                    "basic", f"text/{guess_language(content, file_path)}", content
                )
            except UnicodeDecodeError:
                pass

    # Step 3: Fall back to file(1) command if available
    if "file1" not in ignore:
        try:
            file_executable = file_one()
            if file_executable is None:
                raise FileNotFoundError
            process = subprocess.run(
                [file_executable, "--mime-type", "-b", file_path],
                capture_output=True,
                text=True,
                check=True,
                timeout=1,
            )
            mime_type = process.stdout.strip()
            if mime_type:
                return MimeResult("file1", mime_type)
        except (
            subprocess.CalledProcessError,
            subprocess.TimeoutExpired,
            FileNotFoundError,
        ):
            # file(1) command failed or is not available
            pass

    return None


def get_direntry_for(file_path: str) -> DirEntryType | None:
    """Get the DirEntry object for a given file path.

    Args:
        file_path (str): The path to the file

    Returns:
        DirEntryType | None: The DirEntry object if found, else None
    """
    parent_dir = path.dirname(file_path)
    base_name = path.basename(file_path)
    try:
        with os.scandir(parent_dir) as it:
            for entry in it:
                if entry.name == base_name:
                    return entry
    except (PermissionError, FileNotFoundError, OSError):
        return None
    return None


# trust me ruff, I know what I'm doing
def dump_exc(widget: DOMNode | None, exc: Exception | Traceback) -> str | None:  # noqa: F821
    """Dump an exception to the console for debugging purposes.

    Args:
        widget (DOMNode, None): The widget where the exception occurred.
        exc (Exception, Traceback): The exception to dump.

    Returns:
        str: The path to the log file where the exception was dumped.
    """
    from datetime import datetime

    from rich.panel import Panel
    from rich.traceback import Traceback

    from rovr.variables.maps import RovrVars

    rich_traceback = (
        Traceback.from_exception(
            type(exc),
            exc,
            exc.__traceback__,
            width=None,
            code_width=None,
            show_locals=True,
            max_frames=5,
        )
        if isinstance(exc, Exception)
        else exc
    )
    if isinstance(widget, DOMNode):
        widget.log(rich_traceback)

    dump_path = path.join(
        path.realpath(RovrVars.ROVRCONFIG),
        "logs",
        f"{log_name}.log",
    )
    os.makedirs(path.dirname(dump_path), exist_ok=True)
    with open(dump_path, "a", encoding="utf-8") as file_log:
        # don't need to handle OS Error, Textual automatically chains errors
        error_log = Console(file=file_log, legacy_windows=True)
        # section it with time and date
        error_log.print(
            Panel(rich_traceback, title=f"Exception dumped on {str(datetime.now())}")
        )
    return dump_path
