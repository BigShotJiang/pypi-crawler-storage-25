# investgame-mcp

MCP server for [InvestGame Arcadia](https://app.investgame.net) — gaming industry investment deals and company data.

Search 8,600+ gaming companies, 5,200+ M&A/investment deals, investor analytics, and portfolio exits.

## 🟠 Claude.ai — One-Click Setup (recommended)

> **No installation needed.** Connect InvestGame directly in Claude.ai in under 60 seconds:

1. Open **[Claude.ai Settings → Connectors](https://claude.ai/settings/connectors)**
2. Click **"Add custom connector"**
3. Enter URL: `https://app.investgame.net/mcp`
4. Claude will open the InvestGame authorize page — enter your API key
5. Done — 10 tools available in every conversation

> **Get an API key:** Go to **[app.investgame.net/profile](https://app.investgame.net/profile)** → click **Reveal Key** → copy it.

> **⚠️ Enable tool permissions.** After connecting, click **Configure** next to InvestGame in the Connectors list. Set **Tool permissions** to **"Needs approval"** or **"Always allow"** for all 10 tools. Without this, Claude will say tools are "not currently available".

---

## Local Installation (Claude Desktop / Claude Code)

For local setups where you run Claude Desktop or Claude Code on your machine.

### All Installation Methods

#### Prerequisites

Install `uvx` — a command from the [uv](https://docs.astral.sh/uv/) Python package manager:

| OS | Command |
|----|---------|
| **macOS / Linux** | `curl -LsSf https://astral.sh/uv/install.sh \| sh` |
| **Windows** | `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 \| iex"` |

After installing, **restart your terminal** (or reboot on Windows) so `uvx` is available.

> **Don't want to install uv?** Use [pip install](#2-pip-install) method instead — it works with any Python 3.12+ installation.

#### Config file locations

| OS | Config file path |
|----|-----------------|
| **macOS** | `~/Library/Application Support/Claude/claude_desktop_config.json` |
| **Windows** | `%APPDATA%\Claude\claude_desktop_config.json` |
| **Linux** | `~/.config/Claude/claude_desktop_config.json` |
| **Claude Code** | `.mcp.json` in project root |

#### 1. uvx (recommended, no install needed)

```json
{
  "mcpServers": {
    "investgame": {
      "command": "uvx",
      "args": ["investgame-mcp"],
      "env": { "INVESTGAME_API_KEY": "your-key" }
    }
  }
}
```

Restart Claude Desktop. Done — 10 tools available.

#### 2. pip install

```bash
pip install investgame-mcp
```

```json
{
  "mcpServers": {
    "investgame": {
      "command": "investgame-mcp",
      "env": { "INVESTGAME_API_KEY": "your-key" }
    }
  }
}
```

> **Windows note:** If `investgame-mcp` is not found after pip install, ensure Python's `Scripts` directory is in your PATH. Run `python -m investgame_mcp.server` as a workaround.
>
> **Alternative:** Use `pipx install investgame-mcp` — installs in an isolated environment and adds the command to PATH automatically. Install pipx first: `pip install pipx && pipx ensurepath`.

## Get API Key

1. Sign up at [app.investgame.net](https://app.investgame.net)
2. Go to **Profile → API Key → Generate**
3. Copy the key immediately (shown once)
4. Set as `INVESTGAME_API_KEY` in your MCP config

## Tools

| Tool | Credits | What it does |
|------|---------|-------------|
| `search_companies` | 1/item | Search and filter companies by name, type, sector, region, platform, features |
| `get_company` | 1 | Full company profile: sector, platforms, deals, metrics, contacts, LinkedIn |
| `get_company_investment_stats` | 1 | Investment analytics: activity, focus, portfolio exits (VC/PE/Strategic) |
| `get_company_exits` | 1 | Portfolio exit details — M&A and IPO deals |
| `get_company_stats` | 1 | Aggregate company counts with optional group_by (e.g., by country) |
| `search_deals` | 1/item | Search deals by type, period, sector, size range, company |
| `get_deal` | 1 | Full deal details: ~50 fields including participants, terms, financials |
| `get_deal_stats` | 1 | Aggregate deal statistics: count, total value, average, median |
| `get_multiples_stats` | 1 | Valuation multiples (EV/Revenue, EV/EBITDA) with top deals breakdown |
| `compare_deal_segments` | 2 | Side-by-side comparison of two deal segments (e.g., mobile vs PC/console) |

### MCP Resources

15 read-only resources with `investgame://` URIs provide valid filter values for all enum parameters (company types, deal categories, platforms, genres, sectors, etc.). Claude reads these automatically before making tool calls — no manual lookup needed.

### Example Queries

**Search & Detail:**
- "Find all VC firms investing in mobile gaming"
- "Show me M&A deals over $100M in the last quarter"
- "Get investment stats for Tencent"
- "What are the recent IPOs in gaming?"

**Stats & Analytics:**
- "How many gaming deals happened in 2025?"
- "Average M&A deal size by year"
- "Which country has the most gaming studios?"

**Multiples & Comparison:**
- "What are typical EV/Revenue multiples for gaming M&A?"
- "Compare mobile vs PC/console deal activity in 2024"
- "Top 10 deals by revenue multiple"

## Credits & Limits

| Limit | Value |
|-------|-------|
| Weekly credits | 350 |
| Monthly credits | 1,200 |
| Rate limit | 30 requests/min |
| Search tools | 1 credit per unique item returned |
| Stats tools | 1 credit flat |
| Detail tools | 1 credit each |
| Segment comparison | 2 credits |
| Repeat access | Free (same entity = no charge) |

Credit balance is included in every response (`_credits` field).

## Environment Variables

| Variable | Required | Default |
|----------|----------|---------|
| `INVESTGAME_API_KEY` | Yes | — |
| `INVESTGAME_API_URL` | No | `https://app.investgame.net/api/v1` |

## Changelog

### 0.5.4 (2026-04-12)

- README: fix link formatting, add pipx alternative for Windows

### 0.5.3 (2026-04-12)

**Claude Connectors integration — remote HTTP + OAuth:**

- **Claude.ai one-click setup** — connect via `https://app.investgame.net/mcp` in Settings → Connectors (no local install needed)
- OAuth 2.0 + PKCE (S256) authorization flow with API key input
- Per-request API key resolution — `_resolve_client()` uses OAuth token on remote HTTP, env var on local stdio
- Both `uvx investgame-mcp` (local) and Claude Connectors (remote) work from the same codebase
- README restructured: Claude.ai setup first, local install second

### 0.5.2 (2026-04-05)

**Default output formatting hints + setup docs:**

- Server instructions now include `## Default Output` — recommended format for each tool (table, card, metric summary)
- Added `'top VC investors'` to Common patterns (alongside existing PE, advisory, publisher patterns)
- Updated Tools table in README (was showing 6 tools, now 10)
- Added **Prerequisites** section with `uv` install commands for macOS, Linux, and Windows
- Added Windows and Linux config file paths to Quick Start
- Expanded Example Queries: added stats, multiples, and comparison examples
- Added MCP Resources subsection documenting 15 `investgame://` enum resources
- Added **Troubleshooting** section with 5 common issues and solutions
- Added Windows PATH note for pip install method
- Fixed Python version in pip fallback note (was 3.10+, correct is 3.12+)
- Fixed Credits table: search tools were listed as Free (actual cost since 0.4.0: 1 credit/item)

### 0.5.1 (2026-04-02)

**Improved error diagnostics:**

- 5xx errors now include `detail`/`message` from JSON body (was generic "Try again later.")
- `ConnectError` shows `base_url` + connection failure reason in logs
- All error branches in `_call_api_dict()` log `warning`/`error` before raising `ToolError`
- DRY: unified `_extract_detail()` helper for error detail extraction across all status codes
- Safety: `isinstance(val, str)` guard prevents DRF dict/list values from leaking into messages
- Error detail truncated to 300 chars (prevents HTML dump from Django DEBUG=True)

### 0.5.0 (2026-03-31)

- 10 tools: search_companies, get_company, get_company_investment_stats, get_company_exits, get_company_stats, search_deals, get_deal, get_deal_stats, get_multiples_stats, compare_deal_segments
- 15 resources: enum values for all filter fields
- Smart date parsing (Q1 2024, H2 2025, YTD, last_quarter)
- Credit tracking with `_credits` in every response
- PII redaction (email, linkedin)

### 0.4.0 (2026-03-26)

- Credit monetization: per-item charging, dedup (same entity = free), cache miss billing
- `x-credits-charged`, `x-credits-weekly-remaining`, `x-credits-monthly-remaining` headers

### 0.3.0 (2026-03-24)

- Server split: `app.py`, `types.py`, `validators.py`, `resources.py`
- Security: `follow_redirects=False`, PII redaction, error truncation
- 19 fixes from deep code review (PR #386)

### 0.2.1 (2026-03-22)

- Hotfix: `DEFAULT_API_URL` pointed to old domain (`arcadia.investgame.net` → `app.investgame.net`)

### 0.2.0 (2026-03-18)

- Initial PyPI release: 6 tools, 7 resources, 4 prompts

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `uvx: command not found` | Install uv first — see [Prerequisites](#prerequisites) |
| `Invalid API key` | Check `INVESTGAME_API_KEY` in your MCP config. Keys are shown once — generate a new one at [Profile → API Key](https://app.investgame.net/profile) |
| `Credits exhausted` | Weekly (350) and monthly (1,200) limits reset automatically. Use stats tools (1 credit) instead of search to save credits |
| `investgame-mcp: command not found` (pip) | Add Python Scripts to PATH, or use `python -m investgame_mcp.server` |
| Changes not taking effect | Fully restart Claude Desktop (quit from system tray, not just close window) |

## Coming Soon

- **Anthropic Connectors Directory** — official listing alongside FactSet, PitchBook, Morningstar
- **More tools** — market data, company charts, XLSX export
- **Smithery listing** — one-click install from [smithery.ai](https://smithery.ai)
- **MCP prompts** — pre-built query templates for common use cases

## License

Proprietary. [InvestGame Ltd](https://investgame.net).
