"""InvestGame MCP Server — thin wrapper over InvestGame Public REST API.

10 tools: search_companies, get_company, get_company_investment_stats,
get_company_exits, get_company_stats, search_deals, get_deal_stats,
get_multiples_stats, get_deal, compare_deal_segments.

Usage: INVESTGAME_API_KEY=... python -m investgame_mcp.server
  or:  INVESTGAME_API_KEY=... fastmcp run investgame_mcp/server.py
"""

import json
import logging
import os
from collections.abc import Callable
from typing import Literal
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

import httpx
from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

import investgame_mcp.resources  # noqa: F401 — регистрация @mcp.resource декораторов
from investgame_mcp.app import mcp  # noqa: F401 — re-export + get mcp instance
from investgame_mcp.client import ArcadiaApiError, _get_client, create_client_for_key, handle_response
from investgame_mcp.resources import monetization_types  # noqa: F401 — re-export для тестов
from investgame_mcp.types import (
    _BUYER_TYPE_LITERAL,
    _COMPANY_TYPE_LITERAL,
    _CONTENT_TYPE_LITERAL,
    _DEAL_CATEGORY_LITERAL,
    _DEAL_TYPE_LITERAL,
    _ECOSYSTEM_SEGMENT_LITERAL,
    _ECOSYSTEM_TYPE_LITERAL,
    _FEATURES_LITERAL,
    _GAME_GENRE_LITERAL,
    _INVESTMENT_ROUND_TYPE_LITERAL,
    _MONETIZATION_TYPE_LITERAL,
    _OWNERSHIP_TYPE_LITERAL,
    _PLATFORM_LITERAL,
)
from investgame_mcp.validators import (  # noqa: F401 — re-export _parse_smart_date, _resolve_smart_dates
    _map_feature,
    _map_sector,
    _normalize_country,
    _parse_smart_date,
    _resolve_and_validate_dates,
    _resolve_smart_dates,
)

# PII-редактирование: по умолчанию включено, отключается через INVESTGAME_REDACT_PII=false|0|no|off
_REDACT_PII = os.environ.get("INVESTGAME_REDACT_PII", "true").lower() not in (
    "false",
    "0",
    "no",
    "off",
)
_PII_FIELDS = frozenset({"email", "ceo_founder_linkedin"})


def _redact_pii(data):
    """Рекурсивно редактирует PII-поля в ответах компаний.

    Управляется env var INVESTGAME_REDACT_PII (default: true, frozen at import time).
    Обрабатывает вложенные dict и list для future-proof защиты.
    """
    if not _REDACT_PII:
        return data
    if isinstance(data, dict):
        return {
            k: ("[redacted — use InvestGame web UI]" if k in _PII_FIELDS else _redact_pii(v)) for k, v in data.items()
        }
    if isinstance(data, list):
        return [_redact_pii(item) for item in data]
    return data


# --- Web URL generation ---

# Base URL для web-ссылок (вычисляется из API URL или отдельного env var)
# removesuffix — anchored удаление, безопаснее чем .replace() (open redirect prevention)
# rstrip("/") перед removesuffix — обрабатывает случай INVESTGAME_API_URL с trailing slash
_WEB_BASE_URL = os.environ.get(
    "INVESTGAME_WEB_URL",
    os.environ.get("INVESTGAME_API_URL", "https://app.investgame.net/api/v1").rstrip("/").removesuffix("/api/v1"),
).rstrip("/")

# Параметры, которые frontend НЕ принимает (не передавать в web URL)
_WEB_SKIP_PARAMS = frozenset({"limit", "offset", "group_by", "page", "format", "description_q"})


def _company_url(company_id: int) -> str:
    """Web URL для компании."""
    return f"{_WEB_BASE_URL}/companies/{company_id}"


def _deal_url(deal_id: int) -> str:
    """Web URL для сделки."""
    return f"{_WEB_BASE_URL}/deals/{deal_id}"


def _web_url(path: str, params: dict | None = None) -> str:
    """Build web UI URL с query params (только непустые значения, без служебных)."""
    if params:
        # Frontend ожидает lowercase boolean (true/false), Python даёт True/False
        clean = {}
        for k, v in params.items():
            if v is None or k in _WEB_SKIP_PARAMS:
                continue
            clean[k] = str(v).lower() if isinstance(v, bool) else v
        if clean:
            return f"{_WEB_BASE_URL}{path}?{urlencode(clean)}"
    return f"{_WEB_BASE_URL}{path}"


def _enrich_list(data: dict, params: dict | None, *, item_url_fn: Callable[[int], str], list_path: str) -> dict:
    """Добавить _url к каждому элементу в results + _web_url на список (DRY: companies + deals)."""
    if not isinstance(data, dict):
        return data
    if "results" in data and isinstance(data["results"], list):
        for item in data["results"]:
            if isinstance(item, dict) and "id" in item:
                item["_url"] = item_url_fn(item["id"])
    data["_web_url"] = _web_url(list_path, params)
    return data


def _enrich_company_list(data: dict, params: dict | None = None) -> dict:
    return _enrich_list(data, params, item_url_fn=_company_url, list_path="/companies")


def _enrich_deal_list(data: dict, params: dict | None = None) -> dict:
    return _enrich_list(data, params, item_url_fn=_deal_url, list_path="/deals")


def _format_response(data: dict) -> str:
    """Compact JSON response (no indent — saves ~40% tokens).

    Применяет PII redaction ко ВСЕМ ответам (defence-in-depth):
    get_company, get_deal, search_deals — все проходят через эту точку.
    """
    data = _redact_pii(data)
    return json.dumps(data, ensure_ascii=False, default=str)


def _resolve_client() -> httpx.Client:
    """Get httpx client — OAuth per-request key or env var singleton.

    Remote HTTP: API key comes from OAuth token (different per user).
    Stdio: API key from INVESTGAME_API_KEY env var (singleton).
    """
    try:
        from investgame_mcp.oauth.verifier import current_api_key

        return create_client_for_key(current_api_key())
    except Exception:
        return _get_client()


def _call_api_dict(path: str, params: dict | None = None, *, transform: Callable[[dict], dict] | None = None) -> dict:
    """Common API call → dict. For cases where dict is needed (compare_deal_segments)."""
    try:
        resp = _resolve_client().get(path, params=params)
        data = handle_response(resp)
        if transform:
            data = transform(data)
        return data
    except ArcadiaApiError as e:
        logger.warning("API error %s on %s: %s", e.status_code, path, e.message)
        raise ToolError(e.message) from None
    except ValueError as e:
        logger.error("Configuration error for %s: %s", path, e)
        raise ToolError(f"Configuration error: {e}") from None
    except httpx.TimeoutException:
        logger.error("Timeout on %s", path)
        raise ToolError("Request timed out. Try again later.") from None
    except httpx.ConnectError as e:
        base_url = _resolve_client().base_url
        logger.error("Cannot connect to %s (base: %s): %s", path, base_url, e)
        raise ToolError(f"Cannot connect to InvestGame API at {base_url}. Is the server running?") from None
    except httpx.TooManyRedirects:
        logger.error("Too many redirects on %s", path)
        raise ToolError("Too many redirects. Check INVESTGAME_API_URL.") from None
    except httpx.RequestError as e:
        logger.error("Network error on %s: %s", path, e)
        raise ToolError("Network error communicating with InvestGame API.") from None
    except ToolError:
        raise
    except Exception:
        logger.exception("Unexpected error in _call_api(%s)", path)
        raise ToolError("Unexpected error processing API response. Try a different query or inform the user.") from None


def _call_api(path: str, params: dict | None = None, *, transform: Callable[[dict], dict] | None = None) -> str:
    """Common API call → JSON string. Обёртка над _call_api_dict + _format_response."""
    return _format_response(_call_api_dict(path, params=params, transform=transform))


# --- Filter builders ---


def _build_deal_filter_params(
    *,
    period: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    category: str | None = None,
    type: str | None = None,
    sector: str | None = None,
    hq_country: str | None = None,
    size_from: float | None = None,
    size_to: float | None = None,
    investment_round_type: str | None = None,
    target_platform: str | None = None,
    target_features: str | None = None,
    target_content_type: str | None = None,
    target_game_genre: str | None = None,
    target_ecosystem_segment: str | None = None,
    target_ecosystem_type: str | None = None,
    target_monetization_type: str | None = None,
    buyer_type: str | None = None,
    description_q: str | None = None,
    has_earn_out: bool | None = None,
    has_both_side_advisors: bool | None = None,
) -> dict:
    """Build normalized filter params shared by search_deals and get_deal_stats."""
    validated_from, validated_to = _resolve_and_validate_dates(date_from, date_to, period)
    return {
        k: v
        for k, v in {
            "period": period,
            "category": category,
            "type": type,
            "sector": _map_sector(sector) if sector else None,
            "hq_country": _normalize_country(hq_country) if hq_country else None,
            "date_from": validated_from,
            "date_to": validated_to,
            "size_from": size_from,
            "size_to": size_to,
            "investment_round_type": investment_round_type,
            "target_platform": target_platform,
            # Только features нуждается в маппинге (BLOCKCHAIN→BLOCKCHAIN_OR_WEB3, UGC→UGC_MODDING, RMG→CASH...)
            # Остальные target_* совпадают с DB enum values напрямую
            "target_features": _map_feature(target_features) if target_features else None,
            "target_content_type": target_content_type,
            "target_game_genre": target_game_genre,
            "target_ecosystem_segment": target_ecosystem_segment,
            "target_ecosystem_type": target_ecosystem_type,
            "target_monetization_type": target_monetization_type,
            "buyer_type": buyer_type,
            "description_q": (description_q.strip()[:200] or None) if description_q else None,
            "has_earn_out": has_earn_out,
            "has_both_side_advisors": has_both_side_advisors,
        }.items()
        if v is not None
    }


_REGION_EXPANSION: dict[str, list[str]] = {
    "EUROPE": [
        "British Isles",
        "Northern Europe",
        "Western Europe",
        "Eastern Europe",
        "Southern Europe",
        "Baltic Countries",
        "Nordic Countries",
    ],
}


def _expand_region(value: str | None) -> str | None:
    """Expand meta-region aliases (EUROPE → 7 sub-regions comma-separated)."""
    if not value:
        return None
    expanded = _REGION_EXPANSION.get(value.strip().upper())
    if expanded:
        return ",".join(expanded)
    return value


def _build_company_filter_params(
    *,
    type: str | None = None,
    sector: str | None = None,
    hq_country: str | None = None,
    hq_region: str | None = None,
    ownership_type: str | None = None,
    features: str | None = None,
    platform: str | None = None,
    game_genre: str | None = None,
    ecosystem_segment: str | None = None,
    content_type: str | None = None,
    ecosystem_type: str | None = None,
    monetization_type: str | None = None,
    year_founded_from: int | None = None,
    year_founded_to: int | None = None,
    description_q: str | None = None,
    has_dual_role: bool | None = None,
    multi_category: bool | None = None,
) -> dict:
    """Build normalized filter params for company endpoints."""
    return {
        k: v
        for k, v in {
            "type": type,
            "sector": _map_sector(sector) if sector else None,
            "hq_country": _normalize_country(hq_country) if hq_country else None,
            "hq_region": _expand_region(hq_region),
            "ownership_type": ownership_type,
            "features": _map_feature(features) if features else None,
            "platform": platform,
            "game_genre": game_genre,
            "ecosystem_segment": ecosystem_segment,
            "content_type": content_type,
            "ecosystem_type": ecosystem_type,
            "monetization_type": monetization_type,
            "year_founded_from": year_founded_from,
            "year_founded_to": year_founded_to,
            "description_q": (description_q.strip()[:200] or None) if description_q else None,
            "has_dual_role": has_dual_role,
            "multi_category": multi_category,
        }.items()
        if v is not None
    }


# --- Tools ---


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def search_companies(
    query: str | None = None,
    type: _COMPANY_TYPE_LITERAL | None = None,
    sector: str | None = None,
    hq_region: str | None = None,
    hq_country: str | None = None,
    ownership_type: _OWNERSHIP_TYPE_LITERAL | None = None,
    features: _FEATURES_LITERAL | None = None,
    platform: _PLATFORM_LITERAL | None = None,
    game_genre: _GAME_GENRE_LITERAL | None = None,
    ecosystem_segment: _ECOSYSTEM_SEGMENT_LITERAL | None = None,
    content_type: _CONTENT_TYPE_LITERAL | None = None,
    ecosystem_type: _ECOSYSTEM_TYPE_LITERAL | None = None,
    monetization_type: _MONETIZATION_TYPE_LITERAL | None = None,
    year_founded_from: int | None = None,
    year_founded_to: int | None = None,
    description_q: str | None = None,
    has_dual_role: bool | None = None,
    multi_category: bool | None = None,
    sort_by: (
        Literal[
            "deals_count",
            "-deals_count",
            "deals_size",
            "-deals_size",
            "deals_count_as_investor",
            "-deals_count_as_investor",
            "deals_size_as_investor",
            "-deals_size_as_investor",
            "deals_count_as_target",
            "-deals_count_as_target",
            "deals_size_as_target",
            "-deals_size_as_target",
            "deals_count_as_advisor",
            "-deals_count_as_advisor",
            "deals_size_as_advisor",
            "-deals_size_as_advisor",
            "portfolio_exits_ma_count",
            "-portfolio_exits_ma_count",
            "portfolio_exits_ipo_count",
            "-portfolio_exits_ipo_count",
        ]
        | None
    ) = None,
    date_from: str | None = None,
    date_to: str | None = None,
    offset: int = 0,
    limit: int = 20,
) -> str:
    """Search and filter gaming/investment companies. Costs 1 credit per unique item returned (limit=20 → up to 20 credits). Reduce limit to save credits. Previously seen items (same billing period) are free (dedup).

    Use when: finding companies by type, sector, geography, platform, or deal activity.
    Read investgame:// resources for valid filter values before choosing enum params.
    sort_by: '-' prefix for descending. Key sorts: -deals_count_as_investor (top investors),
    -deals_count_as_target (most-targeted), -deals_count_as_advisor (top advisors),
    -portfolio_exits_ma_count (most exits), -deals_size (largest portfolios).
    date_from/date_to: YYYY-MM-DD or shortcuts ("2024", "Q1 2024", "H1 2024", "YTD", "last quarter").
    hq_region: EUROPE expands to 7 sub-regions. description_q: keyword substring search.
    offset: pagination (default 0). limit: 1-100 (default 20).
    Use get_company(id) for full details (1 credit).
    """
    limit = max(1, min(limit, 100))
    offset = max(0, offset)
    validated_from, validated_to = _resolve_and_validate_dates(date_from, date_to)
    params = _build_company_filter_params(
        type=type,
        sector=sector,
        hq_country=hq_country,
        hq_region=hq_region,
        ownership_type=ownership_type,
        features=features,
        platform=platform,
        game_genre=game_genre,
        ecosystem_segment=ecosystem_segment,
        content_type=content_type,
        ecosystem_type=ecosystem_type,
        monetization_type=monetization_type,
        year_founded_from=year_founded_from,
        year_founded_to=year_founded_to,
        description_q=description_q,
        has_dual_role=has_dual_role,
        multi_category=multi_category,
    )
    if query:
        params["q"] = query
    if validated_from:
        params["date_from"] = validated_from
    if validated_to:
        params["date_to"] = validated_to
    params["limit"] = limit
    if offset > 0:
        params["offset"] = offset
    if sort_by:
        params["o"] = sort_by
    return _call_api("/companies/", params=params, transform=lambda data: _enrich_company_list(data, params))


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def get_company_stats(
    group_by: Literal["country"] | None = None,
    type: _COMPANY_TYPE_LITERAL | None = None,
    sector: str | None = None,
    hq_country: str | None = None,
    hq_region: str | None = None,
    ownership_type: _OWNERSHIP_TYPE_LITERAL | None = None,
    features: _FEATURES_LITERAL | None = None,
    platform: _PLATFORM_LITERAL | None = None,
    game_genre: _GAME_GENRE_LITERAL | None = None,
    ecosystem_segment: _ECOSYSTEM_SEGMENT_LITERAL | None = None,
    content_type: _CONTENT_TYPE_LITERAL | None = None,
    ecosystem_type: _ECOSYSTEM_TYPE_LITERAL | None = None,
    monetization_type: _MONETIZATION_TYPE_LITERAL | None = None,
    year_founded_from: int | None = None,
    year_founded_to: int | None = None,
    description_q: str | None = None,
    has_dual_role: bool | None = None,
    multi_category: bool | None = None,
) -> str:
    """Get aggregated company statistics (NOT individual companies).

    Costs 1 credit flat per call. Use for: 'How many studios in each country?', 'Company count by sector'.
    Do NOT use for: individual company profile (use get_company), company deals (use get_company_investment_stats).
    group_by=country: returns {total, groups: [{country, count}]} sorted by count, top 30.
    Without group_by: returns total count only.
    Same filters as search_companies: type, sector, hq_country, platform, has_dual_role, multi_category,
    description_q (keyword search in descriptions), etc.
    """
    params = _build_company_filter_params(
        type=type,
        sector=sector,
        hq_country=hq_country,
        hq_region=hq_region,
        ownership_type=ownership_type,
        features=features,
        platform=platform,
        game_genre=game_genre,
        ecosystem_segment=ecosystem_segment,
        content_type=content_type,
        ecosystem_type=ecosystem_type,
        monetization_type=monetization_type,
        year_founded_from=year_founded_from,
        year_founded_to=year_founded_to,
        description_q=description_q,
        has_dual_role=has_dual_role,
        multi_category=multi_category,
    )
    if group_by:
        params["group_by"] = group_by

    def _add_web_url(data: dict) -> dict:
        data["_web_url"] = _web_url("/companies", params)
        return data

    return _call_api("/companies/aggregate-stats/", params=params, transform=_add_web_url)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def get_company(company_id: int) -> str:
    """Get full company profile by ID.

    Costs 1 credit. Returns: name, sector, type, ownership_type, platforms, game_genres,
    content_type, ecosystem_type, ecosystem_segment, features, deals count/size,
    parent company, investor specialization, AUM, website, LinkedIn.
    """

    def _enrich(data: dict) -> dict:
        if isinstance(data, dict) and "id" in data:
            data["_url"] = _company_url(data["id"])
        return data

    return _call_api(f"/companies/{company_id}/", transform=_enrich)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def get_company_investment_stats(company_id: int) -> str:
    """Get investment analytics for a company.

    Costs 1 credit. For VC/PE: investment activity, focus areas, portfolio exits.
    For Strategic: funding raised, ownership changes. For Service Providers: advisory track record.
    """

    def _add_urls(data: dict) -> dict:
        if isinstance(data, dict):
            data["_url"] = _company_url(company_id)
            data["_web_url"] = _web_url("/deals", {"company_id": company_id, "role": "investor"})
        return data

    return _call_api(f"/companies/{company_id}/deals-stats/", transform=_add_urls)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def get_company_exits(
    company_id: int,
    exit_type: Literal["MA", "IPO"] | None = None,
) -> str:
    """Get portfolio exit details for an investor.

    Costs 1 credit. Returns paginated list of deals where portfolio companies exited.
    exit_type: "MA" (acquired) or "IPO" (went public).
    """
    params = {}
    if exit_type is not None:
        # API ожидает lowercase, MCP использует UPPER_CASE для консистентности с остальными enum
        params["exit_type"] = exit_type.lower()

    def _add_urls(data: dict) -> dict:
        if isinstance(data, dict):
            data["_url"] = _company_url(company_id)
            # Добавить _url к каждому exit deal в results
            if "results" in data and isinstance(data["results"], list):
                for item in data["results"]:
                    if isinstance(item, dict) and "id" in item:
                        item["_url"] = _deal_url(item["id"])
        return data

    return _call_api(f"/companies/{company_id}/portfolio-exits/", params=params, transform=_add_urls)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def search_deals(
    query: str | None = None,
    period: Literal["1w", "4w", "12w", "YTD", "6m+1", "12m+1", "24m+1", "36m+1"] | None = None,
    type: _DEAL_TYPE_LITERAL | None = None,
    category: _DEAL_CATEGORY_LITERAL | None = None,
    sector: str | None = None,
    hq_country: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    size_from: float | None = None,
    size_to: float | None = None,
    company_id: int | None = None,
    role: Literal["target", "investor", "advisor"] | None = None,
    sort_by: (
        Literal["size", "-size", "announcement_date", "-announcement_date", "investors_count", "-investors_count"]
        | None
    ) = None,
    investment_round_type: _INVESTMENT_ROUND_TYPE_LITERAL | None = None,
    target_platform: _PLATFORM_LITERAL | None = None,
    target_features: _FEATURES_LITERAL | None = None,
    target_content_type: _CONTENT_TYPE_LITERAL | None = None,
    target_game_genre: _GAME_GENRE_LITERAL | None = None,
    target_ecosystem_segment: _ECOSYSTEM_SEGMENT_LITERAL | None = None,
    target_ecosystem_type: _ECOSYSTEM_TYPE_LITERAL | None = None,
    target_monetization_type: _MONETIZATION_TYPE_LITERAL | None = None,
    buyer_type: _BUYER_TYPE_LITERAL | None = None,
    description_q: str | None = None,
    has_earn_out: bool | None = None,
    has_both_side_advisors: bool | None = None,
    offset: int = 0,
    limit: int = 20,
) -> str:
    """Search M&A, investment, and IPO deals in gaming industry. Costs 1 credit per unique item returned (limit=20 → up to 20 credits). Reduce limit to save credits. Previously seen items are free (dedup). For counts/averages/trends → use get_deal_stats (1 credit flat) instead.

    Use when: listing individual deals. For counts/averages/trends → use get_deal_stats instead.
    Returns: target company, type, size, date, investors.
    date_from/date_to: YYYY-MM-DD or shortcuts ("2024", "Q1 2024", "H1 2024", "YTD", "last quarter").
    target_* filters: filter by target company attributes (platform, features, genre, monetization).
    buyer_type: M&A only — STRATEGIC_CORPORATE, FINANCIAL_SPONSOR, MANAGEMENT_MBO.
    company_id + role: filter by company participation (role requires company_id).
    description_q: keyword substring search in deal descriptions.
    sort_by: -size (largest), -announcement_date (latest), -investors_count (mega-syndicated).
    Read investgame:// resources for valid enum values.
    offset: pagination (default 0). limit: 1-100 (default 20).
    Note: hq_region NOT available for deals — use hq_country (ISO 2-letter).
    """
    if role and not company_id:
        raise ToolError(
            "'role' requires 'company_id'. "
            "Search the company first with search_companies, "
            "then filter deals by role."
        )
    limit = max(1, min(limit, 100))
    offset = max(0, offset)
    params = _build_deal_filter_params(
        period=period,
        date_from=date_from,
        date_to=date_to,
        category=category,
        type=type,
        sector=sector,
        hq_country=hq_country,
        size_from=size_from,
        size_to=size_to,
        investment_round_type=investment_round_type,
        target_platform=target_platform,
        target_features=target_features,
        target_content_type=target_content_type,
        target_game_genre=target_game_genre,
        target_ecosystem_segment=target_ecosystem_segment,
        target_ecosystem_type=target_ecosystem_type,
        target_monetization_type=target_monetization_type,
        buyer_type=buyer_type,
        description_q=description_q,
        has_earn_out=has_earn_out,
        has_both_side_advisors=has_both_side_advisors,
    )
    # Параметры специфичные для search_deals
    if query:
        params["q"] = query
    if company_id is not None:
        params["company_id"] = company_id
    if role:
        params["role"] = role
    if sort_by:
        params["o"] = sort_by
    params["limit"] = limit
    if offset > 0:
        params["offset"] = offset
    return _call_api("/deals/", params=params, transform=lambda data: _enrich_deal_list(data, params))


# Ключи time-series для удаления из compare (компактный вывод)
_TIME_SERIES_KEYS = frozenset({"deals_count_by_periods", "deals_size_by_periods"})


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def get_deal_stats(
    period: Literal["1w", "4w", "12w", "YTD", "6m+1", "12m+1", "24m+1", "36m+1"] | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    category: _DEAL_CATEGORY_LITERAL | None = None,
    type: _DEAL_TYPE_LITERAL | None = None,
    sector: str | None = None,
    hq_country: str | None = None,
    size_from: float | None = None,
    size_to: float | None = None,
    investment_round_type: _INVESTMENT_ROUND_TYPE_LITERAL | None = None,
    target_platform: _PLATFORM_LITERAL | None = None,
    target_features: _FEATURES_LITERAL | None = None,
    target_content_type: _CONTENT_TYPE_LITERAL | None = None,
    target_game_genre: _GAME_GENRE_LITERAL | None = None,
    target_ecosystem_segment: _ECOSYSTEM_SEGMENT_LITERAL | None = None,
    target_ecosystem_type: _ECOSYSTEM_TYPE_LITERAL | None = None,
    target_monetization_type: _MONETIZATION_TYPE_LITERAL | None = None,
    buyer_type: _BUYER_TYPE_LITERAL | None = None,
    description_q: str | None = None,
    has_earn_out: bool | None = None,
    has_both_side_advisors: bool | None = None,
    include_time_series: bool = False,
    group_by: Literal["country", "year"] | None = None,
) -> str:
    """Use when user asks about deal counts, totals, averages, medians, trends, or segment comparisons.

    NOT for listing individual deals (use search_deals) or single deal details (use get_deal).
    Costs 1 credit flat per call. Returns: total count, total value ($M), average size, median.
    Common patterns: 'How many deals in 2024?' → date_from/date_to without group_by.
    'Deal trend by year' → group_by="year". 'Which country has most deals?' → group_by="country".
    'M&A vs investment breakdown' → call twice: category="MA" then category="EARLY_STAGE_INVESTMENT".
    'Mobile gaming deals median' → target_platform="MOBILE" (returns median in totals).
    Deal filters: category, type, sector, hq_country, date_from/date_to (YYYY-MM-DD or smart: "2024", "Q1 2024", "H1 2024", "YTD", "last quarter"),
    size_from/size_to, has_earn_out, has_both_side_advisors (true = deals with advisors on both buy and sell side).
    Target company filters: filter deals by characteristics of the target company —
    target_platform, target_features, target_content_type, target_game_genre,
    target_ecosystem_segment, target_ecosystem_type. See investgame:// resources for valid values.
    description_q: search deal descriptions for keywords ('rewarded UA', 'cloud gaming').
    include_time_series: set True to get monthly/quarterly breakdown arrays (large response).
    Default False returns compact totals only. Use True for: 'deal trend over time', 'chart data'.
    Note: only relevant without group_by. With group_by=year/country, time-series is not returned regardless.
    group_by=country: returns {total, groups: [{country, deals_count, deals_size, deals_size_avg}]} sorted by count, top 30.
    group_by=year: returns {total, groups: [{year, deals_count, deals_size, deals_size_avg}]} sorted by year.
    Note: hq_region is NOT available for deals. Use hq_country (ISO 2-letter) to filter by target HQ.
    """
    params = _build_deal_filter_params(
        period=period,
        date_from=date_from,
        date_to=date_to,
        category=category,
        type=type,
        sector=sector,
        hq_country=hq_country,
        size_from=size_from,
        size_to=size_to,
        investment_round_type=investment_round_type,
        target_platform=target_platform,
        target_features=target_features,
        target_content_type=target_content_type,
        target_game_genre=target_game_genre,
        target_ecosystem_segment=target_ecosystem_segment,
        target_ecosystem_type=target_ecosystem_type,
        target_monetization_type=target_monetization_type,
        buyer_type=buyer_type,
        description_q=description_q,
        has_earn_out=has_earn_out,
        has_both_side_advisors=has_both_side_advisors,
    )
    if group_by:
        params["group_by"] = group_by

    def _transform_stats(data: dict) -> dict:
        if isinstance(data, dict):
            data["_web_url"] = _web_url("/", params)
            if not include_time_series:
                # Убираем time-series для компактности (~2000-4000 tokens saved)
                for key in _TIME_SERIES_KEYS:
                    data.pop(key, None)
        return data

    return _call_api("/deals/stats/", params=params, transform=_transform_stats)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def get_multiples_stats(
    category: _DEAL_CATEGORY_LITERAL | None = None,
    sector: str | None = None,
    hq_country: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    size_from: float | None = None,
    size_to: float | None = None,
    top_deals: int | None = None,
) -> str:
    """Get deal valuation multiples (EV/Revenue, EV/EBITDA) — averages, medians, ranges.

    Costs 1 credit flat per call. Uses LTM (Last Twelve Months) financial data.
    Common patterns: 'Gaming M&A multiples' → category="MA".
    'Which deals had highest multiples?' → top_deals=10.
    'Recent M&A multiples' → category="MA", date_from="2024-01-01", top_deals=10.
    date_from/date_to support smart shortcuts: "2024", "Q1 2024", "H1 2024", "YTD", "last quarter".
    For a single deal's multiples, use get_deal(deal_id) instead.
    Do NOT use for: deal counts or volumes (use get_deal_stats).
    Only ~130 deals have Revenue data, ~70 have EBITDA. Range filter: 0.1x-100.0x.
    Recommended: filter by category=MA for most meaningful results.
    top_deals (1-50): when set, returns top_deals_by_revenue and top_deals_by_ebitda arrays
    with individual deal info (deal_id, target_company, size, date, multiple value).
    """
    validated_from, validated_to = _resolve_and_validate_dates(date_from, date_to)
    if top_deals is not None and not 1 <= top_deals <= 50:
        raise ToolError("top_deals must be between 1 and 50")

    params = {
        k: v
        for k, v in {
            "category": category,
            "sector": _map_sector(sector) if sector else None,
            "hq_country": _normalize_country(hq_country) if hq_country else None,
            "date_from": validated_from,
            "date_to": validated_to,
            "size_from": size_from,
            "size_to": size_to,
            "top_deals": top_deals,
        }.items()
        if v is not None
    }

    def _enrich(data: dict) -> dict:
        if isinstance(data, dict):
            data["_web_url"] = _web_url("/deals", params)
            # Добавить _url к top deals если есть
            for key in ("top_deals_by_revenue", "top_deals_by_ebitda"):
                if key in data and isinstance(data[key], list):
                    for item in data[key]:
                        if isinstance(item, dict) and "deal_id" in item:
                            item["_url"] = _deal_url(item["deal_id"])
        return data

    return _call_api("/deals/multiples-stats/", params=params, transform=_enrich)


# Маппинг segment_field → функция нормализации значения сегмента
_SEGMENT_NORMALIZERS: dict[str, Callable[[str], str]] = {
    "sector": _map_sector,
    "target_features": _map_feature,
    "hq_country": _normalize_country,
}


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def compare_deal_segments(
    segment_a: str,
    segment_b: str,
    segment_field: Literal[
        "category",
        "target_platform",
        "hq_country",
        "target_features",
        "target_game_genre",
        "sector",
        "target_monetization_type",
    ],
    date_from: str | None = None,
    date_to: str | None = None,
    category: _DEAL_CATEGORY_LITERAL | None = None,
) -> str:
    """Compare two deal segments side-by-side in a single call.

    Use when user asks to compare: 'mobile vs console', 'US vs UK', 'M&A vs early-stage'.
    Returns both segments' stats (count, size, avg, median) without time-series (compact).
    Costs 2 credits (1 per segment).
    If one segment fails (e.g. invalid value), its result contains {"_error": "message"}
    while the other segment's stats are still returned (graceful partial failure).
    Common patterns: 'Compare mobile vs console' → segment_field="target_platform",
    segment_a="MOBILE", segment_b="PC_CONSOLE".
    'US vs China in 2024' → segment_field="hq_country", segment_a="US", segment_b="CN", date_from="2024".
    'M&A vs early-stage' → segment_field="category", segment_a="MA", segment_b="EARLY_STAGE_INVESTMENT".
    date_from/date_to: YYYY-MM-DD, or shortcuts: "2024", "Q1 2024", "H1 2024", "YTD", "last quarter".
    category: дополнительный фильтр (работает когда segment_field != "category").
    """
    # Нормализация segment values (sector алиасы, features маппинг, country ISO)
    normalizer = _SEGMENT_NORMALIZERS.get(segment_field)
    if normalizer:
        segment_a = normalizer(segment_a)
        segment_b = normalizer(segment_b)

    # Общие параметры
    base_params = _build_deal_filter_params(
        date_from=date_from,
        date_to=date_to,
        category=category,
    )

    def _fetch_segment(segment_value: str) -> dict:
        """Запрашивает stats для одного сегмента через _call_api_dict (без double JSON parse)."""
        params = {**base_params, segment_field: segment_value}

        def _compact(data: dict) -> dict:
            result = {k: v for k, v in data.items() if k not in _TIME_SERIES_KEYS}
            result["_web_url"] = _web_url("/", params)
            return result

        return _call_api_dict("/deals/stats/", params=params, transform=_compact)

    # Последовательные запросы + graceful partial failure per-segment
    result = {}
    for label in (segment_a, segment_b):
        try:
            result[label] = _fetch_segment(label)
        except (ToolError, ArcadiaApiError) as e:
            result[label] = {"_error": str(e)}
    return _format_response(result)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
def get_deal(deal_id: int) -> str:
    """Get full deal details by ID.

    Costs 1 credit. Returns ~50 fields: target company, acquirer/investors (with roles),
    advisors (buy/sell-side), enterprise value, deal size (USD M), payment structure,
    earn-out terms, multiples, investment_round_type, announcement date, status.
    """

    def _enrich(data: dict) -> dict:
        if isinstance(data, dict):
            if "id" in data:
                data["_url"] = _deal_url(data["id"])
            # Ссылка на target company если есть
            tc = data.get("target_company")
            if isinstance(tc, dict) and "id" in tc:
                tc["_url"] = _company_url(tc["id"])
        return data

    return _call_api(f"/deals/{deal_id}/", transform=_enrich)


def main():
    """Entry point for CLI: investgame-mcp."""
    mcp.run()


if __name__ == "__main__":
    main()
