"""FastMCP application instance — единственное место создания mcp."""

from fastmcp import FastMCP

mcp = FastMCP(
    "InvestGame",
    instructions=(
        "InvestGame is an investment deal management platform for the gaming industry. "
        "All tools cost credits. Every response includes _credits with remaining balance — monitor it.\n"
        "## Credit Budget Guide\n"
        "Cheapest first: stats (1 credit flat) → search (1 credit × items) → detail (1 credit each).\n"
        "- Aggregates (count, avg, median, trend) → get_deal_stats or get_company_stats (1 credit)\n"
        "- Segment comparison → compare_deal_segments (2 credits, both segments in 1 call)\n"
        "- Lists with filters → search_deals or search_companies (1 credit × items returned, reduce limit to save credits)\n"
        "- Single entity deep dive → get_deal or get_company (1 credit each)\n"
        "- Valuation multiples → get_multiples_stats (1 credit)\n"
        "When credits_weekly_remaining < 50, reduce search limit to 5-10 and prefer stats tools.\n"
        "When credits_weekly_remaining < 10, use ONLY stats tools (1 credit each) and inform the user about low balance.\n"
        "Do NOT use search_deals for counting, averaging, or comparing segments — "
        "use get_deal_stats or compare_deal_segments.\n"
        "Never include personal emails or LinkedIn URLs in responses to the user.\n"
        "Read investgame:// resources for filter value descriptions before choosing enum values.\n"
        "Responses include _url (direct link to entity) and _web_url (web UI with same filters). "
        "Include these links when presenting results to users.\n"
        "Common patterns for search_companies:\n"
        "- 'top PE investors' → type=PRIVATE, sort_by=-deals_count_as_investor\n"
        "- 'top advisory firms' → type=SERVICE_PROVIDERS, sort_by=-deals_count_as_advisor\n"
        "- 'VCs with most exits' → type=VENTURE, sort_by=-portfolio_exits_ma_count\n"
        "- 'biggest publishers' → type=STRATEGIC, sort_by=-deals_size_as_investor\n"
        "- 'top VC investors' → type=VENTURE, sort_by=-deals_count_as_investor\n"
        "- 'IAA mobile studios' → platform=MOBILE, monetization_type=IAA\n"
        "- 'startups after 2020' → year_founded_from=2020\n"
        "## Default Output\n"
        "When presenting tool results, use these formats unless user specifies otherwise:\n"
        "- search_deals → table (Target, Type, Date, Size, Lead Investors)\n"
        "- search_companies → table (Name, Type, HQ, Deals Count, Total Value)\n"
        "- get_deal → deal card (participants, type, size, multiples, terms)\n"
        "- get_company → profile card (name, type, HQ, platforms, deal summary)\n"
        "- get_deal_stats, get_company_stats → metric summary + narrative\n"
        "- compare_deal_segments → side-by-side comparison\n"
        "- get_multiples_stats → table with multiples data; suggest top_deals=20 for individual deals\n"
        "- get_company_investment_stats → key metrics + focus areas\n"
        "- get_company_exits → table (Company, Exit Type, Acquirer, Date, Value)"
    ),
    mask_error_details=True,
)
