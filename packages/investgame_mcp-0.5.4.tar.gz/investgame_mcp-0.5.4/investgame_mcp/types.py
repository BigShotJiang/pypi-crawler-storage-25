"""Shared Literal types и маппинги — переиспользуются в tools, validators и resources."""

from typing import Literal, get_args

# --- Shared Literal types (переиспользуются в нескольких tools) ---

_DEAL_TYPE_LITERAL = Literal[
    "MA_CONTROL",
    "MA_MINORITY",
    "SEED",
    "SERIES_A",
    "SERIES_B",
    "SERIES_C_H",
    "GROWTH_OR_EXPANSION",
    "EARLY_STAGE_OTHER",
    "OTHER_LATE_STAGE",
    "LISTING",
    "PIPE",
    "FIXED_INCOME",
]

_DEAL_CATEGORY_LITERAL = Literal[
    "MA",
    "EARLY_STAGE_INVESTMENT",
    "LATE_STAGE_INVESTMENT",
    "PUBLIC_OFFERING",
]

_INVESTMENT_ROUND_TYPE_LITERAL = Literal[
    "PREF_COMMON_STOCK",
    "SAFE_CONVERTIBLE",
    "VENTURE_DEBT",
    "OTHER",
]

_GAME_GENRE_LITERAL = Literal[
    "PUZZLE",
    "ARCADE",
    "SPORTS_RACING",
    "TABLETOP",
    "SHOOTER",
    "STRATEGY_MOBA",
    "ACTION_RPG",
    "SIMULATION_SANDBOX",
    "CASINO",
    "OTHER",
]

_ECOSYSTEM_SEGMENT_LITERAL = Literal[
    "CREATION_DEVELOPMENT",
    "ESPORTS",
    "ADTECH",
    "HARDWARE",
    "INFRASTRUCTURE_SERVICES",
    "DISTRIBUTION_SOCIAL_PLATFORMS",
    "STREAMING_ENTERTAINMENT",
    "OTHER",
]

_PLATFORM_LITERAL = Literal["MOBILE", "PC_CONSOLE", "BROWSER", "VR_AR"]
_FEATURES_LITERAL = Literal["AI_OR_ML", "BLOCKCHAIN", "UGC", "RMG"]
_CONTENT_TYPE_LITERAL = Literal["DEVELOPER_1P_PUBLISHER", "PUBLISHER_3P", "OUTSOURCING_WFH"]
_ECOSYSTEM_TYPE_LITERAL = Literal["B2C", "B2B"]
_MONETIZATION_TYPE_LITERAL = Literal["IAP", "IAA", "GAAS", "UPFRONT_SALE", "DLC", "SUBSCRIPTION"]
_BUYER_TYPE_LITERAL = Literal["STRATEGIC_CORPORATE", "FINANCIAL_SPONSOR", "MANAGEMENT_MBO"]
_OWNERSHIP_TYPE_LITERAL = Literal["PUBLIC", "PRIVATE"]
_COMPANY_TYPE_LITERAL = Literal[
    "STRATEGIC", "VENTURE", "PRIVATE", "SERVICE_PROVIDERS", "ANGELS", "ASSET", "OTHER", "AUTO"
]


# --- Маппинг пользовательских значений MCP → значения API/DB ---
# MCP использует короткие понятные enum-ы, а API/DB — полные внутренние имена.

_FEATURES_MAPPING: dict[str, str] = {
    "BLOCKCHAIN": "BLOCKCHAIN_OR_WEB3",
    "UGC": "UGC_MODDING",
    "RMG": "CASH_OR_SKILL_BASED_OR_RMG",
}

_SECTOR_ALIASES: dict[str, str] = {
    # Короткие алиасы → каноничные значения API
    "GAMING": "GAMING_CONTENT",
    "ECOSYSTEM": "GAMING_ECOSYSTEM",
    "CONSUMER": "CONSUMER_APPS",
}

# Каноничные значения sector, принимаемые API
_VALID_SECTORS = {"GAMING_CONTENT", "GAMING_ECOSYSTEM", "CONSUMER_APPS"}


# Валидные DB-значения features — auto-derived из Literal + маппинга.
# Каждое MCP-значение прогоняется через _FEATURES_MAPPING (или passthrough).
_VALID_FEATURES_DB = frozenset(_FEATURES_MAPPING.get(v, v) for v in get_args(_FEATURES_LITERAL))
