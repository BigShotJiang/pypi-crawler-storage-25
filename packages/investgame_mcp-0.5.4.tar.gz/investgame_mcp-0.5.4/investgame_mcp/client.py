"""InvestGame API httpx client + error mapping HTTP → ArcadiaApiError."""

import functools
import os

import httpx

VERSION = "0.5.4"
DEFAULT_API_URL = "https://app.investgame.net/api/v1"


class ArcadiaApiError(Exception):
    """Arcadia REST API error with human-readable message for MCP."""

    def __init__(self, message: str, status_code: int = 0):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


def create_client() -> httpx.Client:
    """Create httpx client with API key from env."""
    api_key = os.environ.get("INVESTGAME_API_KEY")
    if not api_key:
        raise ValueError(
            "INVESTGAME_API_KEY env variable is required. " "Get your key at https://app.investgame.net/profile"
        )
    base_url = os.environ.get("INVESTGAME_API_URL", DEFAULT_API_URL)
    return httpx.Client(
        base_url=base_url,
        # follow_redirects=False — предотвращает утечку x-api-key при cross-origin redirect.
        # Arcadia API не использует редиректы (кроме 301 old domain → new, пофикшен в v0.2.1).
        follow_redirects=False,
        headers={
            "x-api-key": api_key,
            "user-agent": f"investgame-mcp/{VERSION}",
        },
        timeout=httpx.Timeout(connect=5.0, read=30.0, write=10.0, pool=5.0),
        # MCP: 1-2 параллельных запроса, 10-30s между вызовами — keepalive 30s экономит TLS handshake
        limits=httpx.Limits(max_connections=5, max_keepalive_connections=2, keepalive_expiry=30.0),
    )


@functools.lru_cache(maxsize=1)
def _get_client() -> httpx.Client:
    """Lazy singleton — creates client on first call."""
    return create_client()


def create_client_for_key(api_key: str) -> httpx.Client:
    """Create a per-request httpx client with a specific API key.

    Used by remote HTTP OAuth mode where each request has a different user.
    """
    base_url = os.environ.get("INVESTGAME_API_URL", DEFAULT_API_URL)
    return httpx.Client(
        base_url=base_url,
        follow_redirects=False,
        headers={
            "x-api-key": api_key,
            "user-agent": f"investgame-mcp/{VERSION}",
        },
        timeout=httpx.Timeout(connect=5.0, read=30.0, write=10.0, pool=5.0),
    )


def _safe_int(value: str, default: int = 0) -> int:
    """Safe int() for credit headers."""
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def _extract_detail(body: dict, *keys: str, default: str = "", max_len: int = 300) -> str:
    """Первое непустое строковое значение из body по ключам, truncated для безопасности.

    Безопасно: работает с parsed JSON dict, не дампит response.text
    (Django DEBUG=True может содержать секреты в HTML traceback).
    """
    for key in keys:
        val = body.get(key)
        if val and isinstance(val, str):
            return val[:max_len]
    return default


def handle_response(response: httpx.Response) -> dict:
    """Process response: error mapping HTTP → ArcadiaApiError + credit header enrichment."""
    if response.is_success:
        try:
            data = response.json()
        except ValueError:
            raise ArcadiaApiError(
                "InvestGame API returned non-JSON response. Service may be unavailable.",
                response.status_code,
            ) from None
        # Enrich with credit info if present
        credits_info = {}
        for header, key in (
            ("x-credits-charged", "credits_charged"),
            ("x-credits-weekly-remaining", "credits_weekly_remaining"),
            ("x-credits-monthly-remaining", "credits_monthly_remaining"),
        ):
            if header in response.headers:
                credits_info[key] = _safe_int(response.headers[header])
        if credits_info:
            if isinstance(data, dict):
                data["_credits"] = credits_info
            elif isinstance(data, list):
                data = {"results": data, "_credits": credits_info}
        return data

    # Error mapping
    status = response.status_code
    try:
        body = response.json()
    except ValueError:
        body = {}

    if status == 401:
        # Очищаем кеш клиента — возможна ротация API key
        _get_client.cache_clear()
        raise ArcadiaApiError("Invalid API key. Check INVESTGAME_API_KEY env variable.", status) from None

    if status == 402:
        # CreditLimitExceeded returns {code, message, remaining, required, reset_at}
        code = body.get("code", "")
        if code in ("weekly_limit_exceeded", "monthly_limit_exceeded"):
            remaining = body.get("remaining", 0)
            reset_at = body.get("reset_at", "soon")
            period = "weekly" if "weekly" in code else "monthly"
            raise ArcadiaApiError(
                f"Credits exhausted ({period}, {remaining} remaining, resets {reset_at}). "
                f"Use get_deal_stats or get_company_stats (1 credit each) instead of search. "
                f"Inform the user about credit limit.",
                status,
            ) from None
        msg = _extract_detail(body, "message", default="payment required")
        raise ArcadiaApiError(f"Payment required: {msg}", status) from None

    if status == 403:
        msg = _extract_detail(body, "message", "detail", default="access denied")
        raise ArcadiaApiError(f"Access denied: {msg}", status) from None

    if status == 400:
        detail = _extract_detail(body, "detail", "message", default="check parameter values")
        raise ArcadiaApiError(f"Invalid request parameters: {detail}", status) from None

    if status == 404:
        raise ArcadiaApiError(
            "Resource not found. Check the ID and try a search first.",
            status,
        ) from None

    if status == 429:
        retry_after = _safe_int(response.headers.get("retry-after", ""), default=60)
        raise ArcadiaApiError(
            f"Rate limit exceeded (30 req/min). Retry after {retry_after}s.",
            status,
        ) from None

    # 5xx и прочие — извлекаем detail через единый хелпер (безопасно: body уже распарсен,
    # никогда не дампим response.text, т.к. Django DEBUG=True может содержать секреты)
    detail = _extract_detail(body, "detail", "message", "error")
    msg = f"InvestGame API error ({status})"
    if detail:
        msg += f": {detail}"
    else:
        msg += ". Try again later."
    raise ArcadiaApiError(msg, status) from None
