"""InvestGame OAuth token verifier — subclass FastMCP TokenVerifier.

Redis lookup -> Fernet decrypt -> AccessToken with api_key in claims.
Django-free — uses redis.asyncio + investgame_mcp.oauth.storage.
"""

from __future__ import annotations

import hashlib
import logging

import redis.asyncio as aioredis
from fastmcp.exceptions import ToolError
from fastmcp.server.auth import TokenVerifier
from fastmcp.server.auth.auth import AccessToken
from fastmcp.server.dependencies import get_access_token

from investgame_mcp.oauth.storage import decrypt_api_key, get_token_payload

logger = logging.getLogger(__name__)


class InvestGameTokenVerifier(TokenVerifier):
    """Verify opaque bearer tokens via Redis, inject api_key into claims."""

    def __init__(
        self,
        redis_client: aioredis.Redis,
        *,
        base_url: str,
    ) -> None:
        super().__init__(
            base_url=base_url,
            required_scopes=["mcp.access"],
        )
        self._redis = redis_client

    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify bearer token -> AccessToken with api_key in claims."""
        if not token or not token.strip():
            return None

        token_h = hashlib.sha256(token.encode()).hexdigest()[:16]

        payload = await get_token_payload(self._redis, token)
        if payload is None:
            logger.info(
                "MCP token verify miss",
                extra={"token_hash": token_h, "reason": "not_in_redis"},
            )
            return None

        api_key = decrypt_api_key(payload["api_key_encrypted"])
        if api_key is None:
            # Fernet decrypt failed — logged as CRITICAL in storage.decrypt_api_key
            return None

        return AccessToken(
            token=token,
            client_id=str(payload.get("client_id", "unknown")),
            scopes=["mcp.access"],
            expires_at=payload.get("exp"),
            claims={
                "api_key": api_key,
                "user_id": payload.get("user_id"),
                "email": payload.get("email"),
            },
        )


def current_api_key() -> str:
    """Extract API key from current MCP request's OAuth access token.

    Called from tool functions: api_key = current_api_key()
    """
    token = get_access_token()
    if token is None:
        raise ToolError("Not authenticated")
    api_key = token.claims.get("api_key")
    if not api_key:
        raise ToolError("Token missing api_key claim")
    return api_key
