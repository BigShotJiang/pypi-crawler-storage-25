"""OAuth 2.0 implementation for InvestGame MCP remote HTTP server.

Public API:
    InvestGameTokenVerifier — TokenVerifier subclass for FastMCP
    current_api_key — extract api_key from MCP context
    OAuthError — RFC 6749 §5.2 error exception
"""

from investgame_mcp.oauth.storage import OAuthError
from investgame_mcp.oauth.verifier import InvestGameTokenVerifier, current_api_key

__all__ = ["InvestGameTokenVerifier", "OAuthError", "current_api_key"]
