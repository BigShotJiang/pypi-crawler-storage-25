"""OAuth 2.0 HTTP endpoints: authorize, token, register, revoke + well-known discovery.

Single module per review finding S-5 (fold 8 files into 4).
Starlette routes — mounted via ProtocolTypeRouter in arcadia/asgi.py.
"""

from __future__ import annotations

import hmac
import logging
import os
import time
from functools import lru_cache
from html import escape
from urllib.parse import urlencode

import httpx
import redis.asyncio as aioredis
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, RedirectResponse
from starlette.routing import Route
from starlette.templating import Jinja2Templates

from investgame_mcp.oauth.storage import (
    OAuthError,
    consume_auth_code,
    decrypt_api_key,
    get_client,
    issue_auth_code,
    issue_tokens,
    refresh_access_token,
    register_client,
    require_s256_method,
    revoke_token,
    verify_pkce_s256,
)

logger = logging.getLogger(__name__)

# Templates directory inside package
_TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")
templates = Jinja2Templates(directory=_TEMPLATES_DIR)


def _build_redis_url(base_url: str) -> str:
    """Append /3 as DB index if not already present.

    MCP uses Redis DB 3 (isolated namespace):
    - DB 0: Django cache (django-redis)
    - DB 1: Celery broker queue
    - DB 2: Celery result backend (celery-task-meta-* keys)
    - DB 3: MCP OAuth tokens (mcp:* keys)

    Heroku Redis URL format: rediss://:password@host:port — no DB path.
    Local dev: redis://localhost:6379 — no DB path either.
    We parse the URL and only add /3 if the path component is empty.
    """
    from urllib.parse import urlparse, urlunparse

    parsed = urlparse(base_url)
    # parsed.path is "" for redis://host:port, "/0" for redis://host:port/0
    if not parsed.path or parsed.path == "/":
        parsed = parsed._replace(path="/3")
    return urlunparse(parsed)


@lru_cache(maxsize=1)
def _get_redis() -> aioredis.Redis:
    """Singleton Redis client — one connection pool per worker process.

    Handles both local (redis://) and Heroku Premium (rediss:// with self-signed cert).
    Cached to prevent connection pool proliferation (15 conns per pool × N calls).
    """
    raw_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
    url = _build_redis_url(raw_url)

    # Heroku Redis uses self-signed certs on rediss:// — disable cert verification.
    # Safe because Heroku's private network makes MITM impractical and the cert
    # is issued internally. See Heroku Redis docs on TLS.
    kwargs = {
        "decode_responses": True,
        "max_connections": 15,
    }
    if url.startswith("rediss://"):
        import ssl

        kwargs["ssl_cert_reqs"] = ssl.CERT_NONE

    return aioredis.from_url(url, **kwargs)


@lru_cache(maxsize=1)
def _get_callback_allowlist() -> frozenset[str]:
    """Allowlist callback URLs — configurable via MCP_CALLBACK_URLS env var."""
    raw = os.environ.get(
        "MCP_CALLBACK_URLS",
        "https://claude.ai/api/mcp/auth_callback,"
        "https://claude.com/api/mcp/auth_callback,"
        "http://localhost:6274/oauth/callback",
    )
    return frozenset(u.strip() for u in raw.split(",") if u.strip())


@lru_cache(maxsize=1)
def _get_base_url() -> str:
    """Base URL for well-known metadata."""
    return os.environ.get("MCP_BASE_URL", "https://app.investgame.net").rstrip("/")


@lru_cache(maxsize=1)
def _get_upstream_api_url() -> str:
    """Upstream /api/v1/ URL for API key validation."""
    return os.environ.get("INVESTGAME_API_URL", "https://app.investgame.net/api/v1").rstrip("/")


def _error_response(error: str, description: str = "", status: int = 400) -> JSONResponse:
    """RFC 6749 §5.2 error response."""
    payload = {"error": error}
    if description:
        payload["error_description"] = description
    return JSONResponse(payload, status_code=status)


# ==================
# Well-known
# ==================


async def oauth_as_metadata(request: Request) -> JSONResponse:
    """RFC 8414 — Authorization Server Metadata."""
    base = _get_base_url()
    return JSONResponse(
        {
            "issuer": base,
            "authorization_endpoint": f"{base}/mcp/auth",
            "token_endpoint": f"{base}/mcp/token",
            "registration_endpoint": f"{base}/mcp/register",
            "revocation_endpoint": f"{base}/mcp/revoke",
            "scopes_supported": ["mcp.access"],
            "response_types_supported": ["code"],
            "grant_types_supported": ["authorization_code", "refresh_token"],
            "code_challenge_methods_supported": ["S256"],
            "token_endpoint_auth_methods_supported": ["none"],
        }
    )


async def oauth_protected_resource(request: Request) -> JSONResponse:
    """RFC 9728 — Protected Resource Metadata."""
    base = _get_base_url()
    return JSONResponse(
        {
            "resource": f"{base}/mcp",
            "authorization_servers": [base],
            "scopes_supported": ["mcp.access"],
            "bearer_methods_supported": ["header"],
        }
    )


# ==================
# /register (DCR)
# ==================


async def register_endpoint(request: Request) -> JSONResponse:
    """RFC 7591 Dynamic Client Registration."""
    try:
        body = await request.json()
    except Exception:
        return _error_response("invalid_request", "malformed JSON body")

    redirect_uris = body.get("redirect_uris", [])
    if not isinstance(redirect_uris, list) or not redirect_uris:
        return _error_response("invalid_redirect_uri", "redirect_uris required")

    allowlist = _get_callback_allowlist()
    for uri in redirect_uris:
        if not isinstance(uri, str) or uri not in allowlist:
            return _error_response("invalid_redirect_uri", f"URI not in allowlist: {uri[:80]}")

    client_name = body.get("client_name", "MCP Client")
    if not isinstance(client_name, str):
        client_name = "MCP Client"

    redis_client = _get_redis()
    client_id = await register_client(
        redis_client=redis_client,
        redirect_uris=redirect_uris,
        client_name=client_name,
    )

    return JSONResponse(
        {
            "client_id": client_id,
            "client_id_issued_at": int(time.time()),
            "redirect_uris": redirect_uris,
            "token_endpoint_auth_method": "none",
            "grant_types": ["authorization_code", "refresh_token"],
            "response_types": ["code"],
        }
    )


# ==================
# /authorize GET + POST
# ==================


def _validate_authorize_params(params: dict) -> tuple[str, str, str, str, str]:
    """Validate authorize params. Returns (client_id, redirect_uri, challenge, state, scope)."""
    client_id = params.get("client_id", "")
    redirect_uri = params.get("redirect_uri", "")
    code_challenge = params.get("code_challenge", "")
    code_challenge_method = params.get("code_challenge_method", "")
    state = params.get("state", "")
    scope = params.get("scope", "mcp.access")

    if not client_id:
        raise OAuthError("invalid_request", "client_id required")
    if not redirect_uri:
        raise OAuthError("invalid_request", "redirect_uri required")
    if not code_challenge:
        raise OAuthError("invalid_request", "code_challenge required")

    require_s256_method(code_challenge_method)

    if len(state) < 8 or len(state) > 256:
        raise OAuthError("invalid_request", "state length must be 8..256")

    return client_id, redirect_uri, code_challenge, state, scope


async def _validate_client_and_redirect(redis_client: aioredis.Redis, client_id: str, redirect_uri: str) -> None:
    """Verify client exists and redirect_uri is in both client and global allowlists."""
    client_data = await get_client(redis_client, client_id)
    if client_data is None:
        raise OAuthError("invalid_client", "unknown client_id")

    if redirect_uri not in client_data["redirect_uris"]:
        raise OAuthError("invalid_redirect_uri", "not in client allowlist")

    if redirect_uri not in _get_callback_allowlist():
        raise OAuthError("invalid_redirect_uri", "not in global allowlist")


async def authorize_get(request: Request) -> HTMLResponse:
    """GET /authorize — renders HTML form."""
    try:
        params = dict(request.query_params)
        client_id, redirect_uri, challenge, state, scope = _validate_authorize_params(params)
        redis_client = _get_redis()
        await _validate_client_and_redirect(redis_client, client_id, redirect_uri)
    except OAuthError as exc:
        return HTMLResponse(
            f"<h1>OAuth Error</h1><p>{escape(exc.error)}: {escape(exc.description)}</p>",
            status_code=exc.status,
        )

    return templates.TemplateResponse(
        request,
        "authorize.html",
        {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "code_challenge": challenge,
            "code_challenge_method": params.get("code_challenge_method", "S256"),
            "state": state,
            "scope": scope,
            "error": None,
        },
    )


_async_client: httpx.AsyncClient | None = None


def _get_async_client() -> httpx.AsyncClient:
    """Lazy singleton httpx client — one per worker, reuses TCP connections."""
    global _async_client
    if _async_client is None:
        _async_client = httpx.AsyncClient(
            timeout=10.0,
            limits=httpx.Limits(
                max_connections=5,
                max_keepalive_connections=2,
                keepalive_expiry=30.0,
            ),
        )
    return _async_client


async def _validate_api_key(api_key: str) -> dict | None:
    """Validate API key via upstream /api/v1/auth/me/. Returns user data or None."""
    url = _get_upstream_api_url() + "/auth/me/"
    try:
        response = await _get_async_client().get(url, headers={"X-Api-Key": api_key})
        if response.status_code == 200:
            return response.json()
        return None
    except httpx.HTTPError as exc:
        logger.warning("Upstream /auth/me/ check failed", exc_info=exc)
        return None


async def authorize_post(request: Request) -> HTMLResponse | RedirectResponse:
    """POST /authorize — validate API key → redirect with code."""
    form = await request.form()
    form_data = {k: v for k, v in form.items() if isinstance(v, str)}

    try:
        client_id, redirect_uri, challenge, state, scope = _validate_authorize_params(form_data)
        redis_client = _get_redis()
        await _validate_client_and_redirect(redis_client, client_id, redirect_uri)
    except OAuthError as exc:
        return HTMLResponse(
            f"<h1>OAuth Error</h1><p>{escape(exc.error)}: {escape(exc.description)}</p>",
            status_code=exc.status,
        )

    api_key = form_data.get("api_key", "").strip()
    if not api_key:
        return templates.TemplateResponse(
            request,
            "authorize.html",
            {
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "state": state,
                "scope": scope,
                "error": "API key is required",
            },
            status_code=400,
        )

    user_data = await _validate_api_key(api_key)
    if user_data is None:
        return templates.TemplateResponse(
            request,
            "authorize.html",
            {
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "state": state,
                "scope": scope,
                "error": "Invalid API key. Get one at Profile → API Key.",
            },
            status_code=401,
        )

    code = await issue_auth_code(
        redis_client=redis_client,
        api_key=api_key,
        code_challenge=challenge,
        code_challenge_method="S256",
        client_id=client_id,
        redirect_uri=redirect_uri,
        user_id=user_data.get("id", 0),
    )

    redirect_url = f"{redirect_uri}?{urlencode({'code': code, 'state': state})}"
    response = RedirectResponse(url=redirect_url, status_code=302)
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private"
    return response


# ==================
# /token
# ==================


def _token_response(data: dict) -> JSONResponse:
    """Token response with RFC 6749 §5.1 mandatory Cache-Control."""
    resp = JSONResponse(data)
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["Pragma"] = "no-cache"
    return resp


async def _handle_authorization_code(
    redis_client: aioredis.Redis,
    form: dict,
) -> JSONResponse:
    """Handle authorization_code grant type."""
    code = form.get("code", "")
    code_verifier = form.get("code_verifier", "")
    client_id = form.get("client_id", "")
    redirect_uri = form.get("redirect_uri", "")

    if not all([code, code_verifier, client_id, redirect_uri]):
        return _error_response("invalid_request", "missing required params")

    payload = await consume_auth_code(redis_client, code)
    if payload is None:
        return _error_response("invalid_grant", "code not found or used")

    if not hmac.compare_digest(client_id, payload["client_id"]):
        return _error_response("invalid_grant", "client_id mismatch")
    if not hmac.compare_digest(redirect_uri, payload["redirect_uri"]):
        return _error_response("invalid_grant", "redirect_uri mismatch")
    if not verify_pkce_s256(code_verifier, payload["code_challenge"]):
        return _error_response("invalid_grant", "code_verifier mismatch")

    api_key = decrypt_api_key(payload["api_key_encrypted"])
    if api_key is None:
        return _error_response("server_error", "decryption failed")

    access_token, refresh_token, expires_in = await issue_tokens(
        redis_client=redis_client,
        api_key=api_key,
        user_id=payload["user_id"],
        email=payload.get("email", ""),
        client_id=client_id,
    )
    return _token_response(
        {
            "access_token": access_token,
            "token_type": "Bearer",
            "expires_in": expires_in,
            "refresh_token": refresh_token,
            "scope": "mcp.access",
        }
    )


async def _handle_refresh_token(
    redis_client: aioredis.Redis,
    form: dict,
) -> JSONResponse:
    """Handle refresh_token grant type."""
    refresh_token = form.get("refresh_token", "")
    if not refresh_token:
        return _error_response("invalid_request", "refresh_token required")

    result = await refresh_access_token(redis_client, refresh_token)
    if result is None:
        return _error_response("invalid_grant", "refresh token not found")

    new_access, same_refresh, expires_in = result
    return _token_response(
        {
            "access_token": new_access,
            "token_type": "Bearer",
            "expires_in": expires_in,
            "refresh_token": same_refresh,
            "scope": "mcp.access",
        }
    )


async def token_endpoint(request: Request) -> JSONResponse:
    """POST /token — authorization_code or refresh_token grant."""
    form = await request.form()
    grant_type = form.get("grant_type", "")
    redis_client = _get_redis()

    if grant_type == "authorization_code":
        return await _handle_authorization_code(redis_client, dict(form))
    if grant_type == "refresh_token":
        return await _handle_refresh_token(redis_client, dict(form))
    return _error_response("unsupported_grant_type", f"grant_type={grant_type}")


# ==================
# /revoke
# ==================


async def revoke_endpoint(request: Request) -> JSONResponse:
    """POST /revoke — delete access token."""
    form = await request.form()
    token = form.get("token", "")

    if token:
        redis_client = _get_redis()
        await revoke_token(redis_client, token)

    # RFC 7009: always 200, even if token not found (unauthenticated clients)
    return JSONResponse({}, status_code=200)


# ==================
# App factory
# ==================


def build_oauth_app() -> Starlette:
    """Build standalone Starlette app with OAuth routes.

    Used in tests and as sub-app in arcadia/asgi.py.
    """
    return Starlette(
        routes=[
            Route("/.well-known/oauth-authorization-server", oauth_as_metadata, methods=["GET"]),
            Route("/.well-known/oauth-protected-resource", oauth_protected_resource, methods=["GET"]),
            Route("/register", register_endpoint, methods=["POST"]),
            Route("/auth", authorize_get, methods=["GET"]),
            Route("/auth", authorize_post, methods=["POST"]),
            Route("/token", token_endpoint, methods=["POST"]),
            Route("/revoke", revoke_endpoint, methods=["POST"]),
        ],
    )
