"""OAuth token storage: PKCE, Fernet crypto, Redis CRUD for opaque tokens.

Single module (KISS per review finding S-5). Django-free — redis.asyncio + cryptography only.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
import time
from functools import lru_cache

import redis.asyncio as aioredis
from cryptography.fernet import Fernet, InvalidToken, MultiFernet

logger = logging.getLogger(__name__)


# ==================
# OAuthError
# ==================


class OAuthError(Exception):
    """RFC 6749 §5.2 OAuth error — serialized as JSON {error, error_description}."""

    def __init__(self, error: str, description: str = "", status: int = 400) -> None:
        self.error = error
        self.description = description
        self.status = status
        message = f"{error}: {description}" if description else error
        super().__init__(message)

    def to_dict(self) -> dict[str, str]:
        payload: dict[str, str] = {"error": self.error}
        if self.description:
            payload["error_description"] = self.description
        return payload


# ==================
# PKCE
# ==================


def require_s256_method(method: str) -> None:
    """MCP spec + OAuth 2.1: S256 MANDATORY, reject plain."""
    if method != "S256":
        raise OAuthError("invalid_request", "code_challenge_method must be S256")


def verify_pkce_s256(verifier: str, stored_challenge: str) -> bool:
    """RFC 7636 §4.6 — S256 verification с constant-time compare."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    expected = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return hmac.compare_digest(expected, stored_challenge)


# ==================
# Fernet Crypto
# ==================


@lru_cache(maxsize=1)
def _get_fernet() -> MultiFernet:
    """MultiFernet: primary + optional secondary for safe key rotation.

    Primary: API_KEY_ENCRYPTION_KEY (required, used for encrypt).
    Secondary: API_KEY_ENCRYPTION_KEY_OLD (optional, decrypts old data during rotation).
    Heroku dyno restart after config:set clears the lru_cache.
    """
    primary_key = os.environ.get("API_KEY_ENCRYPTION_KEY")
    if not primary_key:
        raise RuntimeError(
            "API_KEY_ENCRYPTION_KEY is not configured — investgame_mcp " "cannot encrypt/decrypt OAuth token payloads."
        )
    keys = [Fernet(primary_key.encode())]

    secondary_key = os.environ.get("API_KEY_ENCRYPTION_KEY_OLD")
    if secondary_key:
        keys.append(Fernet(secondary_key.encode()))

    return MultiFernet(keys)


def encrypt_api_key(api_key: str) -> str:
    """Fernet-encrypt API key for Redis storage."""
    return _get_fernet().encrypt(api_key.encode()).decode()


def decrypt_api_key(blob: str) -> str | None:
    """Fernet-decrypt API key. Returns None on error (key rotation, corruption)."""
    try:
        return _get_fernet().decrypt(blob.encode()).decode()
    except InvalidToken:
        logger.critical(
            "Fernet InvalidToken decrypting OAuth token payload — "
            "check API_KEY_ENCRYPTION_KEY consistency between Django and investgame_mcp"
        )
        return None


# ==================
# Redis Token Store
# ==================

# TTL defaults (seconds)
_ACCESS_TOKEN_TTL = int(os.environ.get("MCP_ACCESS_TOKEN_TTL", "3600"))
_REFRESH_TOKEN_TTL = int(os.environ.get("MCP_REFRESH_TOKEN_TTL", "2592000"))
_AUTH_CODE_TTL = int(os.environ.get("MCP_AUTH_CODE_TTL", "60"))
_CLIENT_TTL = int(os.environ.get("MCP_CLIENT_TTL", "7776000"))  # 90 days


async def register_client(
    *,
    redis_client: aioredis.Redis,
    redirect_uris: list[str],
    client_name: str = "",
) -> str:
    """DCR: register a new client, return client_id."""
    client_id = f"ig_mcp_{secrets.token_urlsafe(16)}"
    payload = json.dumps(
        {
            "redirect_uris": redirect_uris,
            "client_name": client_name[:64],
            "issued_at": int(time.time()),
        },
        separators=(",", ":"),
    )
    await redis_client.setex(f"mcp:client:{client_id}", _CLIENT_TTL, payload)
    return client_id


async def get_client(redis_client: aioredis.Redis, client_id: str) -> dict | None:
    """Read client metadata from Redis."""
    raw = await redis_client.get(f"mcp:client:{client_id}")
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None


async def issue_auth_code(
    *,
    redis_client: aioredis.Redis,
    api_key: str,
    code_challenge: str,
    code_challenge_method: str,
    client_id: str,
    redirect_uri: str,
    user_id: int,
) -> str:
    """Issue authorization code, store in Redis with TTL."""
    code = secrets.token_urlsafe(32)
    payload = json.dumps(
        {
            "api_key_encrypted": encrypt_api_key(api_key),
            "code_challenge": code_challenge,
            "code_challenge_method": code_challenge_method,
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "user_id": user_id,
            "issued_at": int(time.time()),
        },
        separators=(",", ":"),
    )
    await redis_client.setex(f"mcp:authcode:{code}", _AUTH_CODE_TTL, payload)
    return code


async def consume_auth_code(redis_client: aioredis.Redis, code: str) -> dict | None:
    """Atomically consume auth code from Redis (single-use).

    Uses GETDEL (Redis 6.2+) — atomic get-and-delete in one round-trip.
    Returns dict payload or None if code not found / already consumed.
    """
    raw = await redis_client.getdel(f"mcp:authcode:{code}")
    if raw is None:
        return None
    return json.loads(raw)


async def issue_tokens(
    *,
    redis_client: aioredis.Redis,
    api_key: str,
    user_id: int,
    email: str,
    client_id: str,
) -> tuple[str, str, int]:
    """Issue access + refresh tokens. Returns (access, refresh, expires_in)."""
    access_token = secrets.token_urlsafe(32)
    refresh_token = secrets.token_urlsafe(32)
    now = int(time.time())

    access_payload = json.dumps(
        {
            "api_key_encrypted": encrypt_api_key(api_key),
            "user_id": user_id,
            "email": email,
            "client_id": client_id,
            "exp": now + _ACCESS_TOKEN_TTL,
        },
        separators=(",", ":"),
    )
    refresh_payload = json.dumps(
        {
            "api_key_encrypted": encrypt_api_key(api_key),
            "user_id": user_id,
            "client_id": client_id,
            "exp": now + _REFRESH_TOKEN_TTL,
        },
        separators=(",", ":"),
    )

    # Two SETEX — not atomic, but TTL handles orphans (review finding: Lua deferred to v2)
    await redis_client.setex(f"mcp:token:{access_token}", _ACCESS_TOKEN_TTL, access_payload)
    await redis_client.setex(f"mcp:refresh:{refresh_token}", _REFRESH_TOKEN_TTL, refresh_payload)

    return access_token, refresh_token, _ACCESS_TOKEN_TTL


async def get_token_payload(redis_client: aioredis.Redis, access_token: str) -> dict | None:
    """Read access token payload from Redis."""
    raw = await redis_client.get(f"mcp:token:{access_token}")
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        logger.critical("Corrupted JSON in mcp:token — possible data integrity issue")
        return None


async def revoke_token(redis_client: aioredis.Redis, access_token: str) -> None:
    """Delete access token from Redis."""
    await redis_client.delete(f"mcp:token:{access_token}")


async def refresh_access_token(redis_client: aioredis.Redis, refresh_token: str) -> tuple[str, str, int] | None:
    """Refresh → new access token. Returns (new_access, same_refresh, expires_in) or None.

    Simple implementation without rotation (deferred per review finding S-3).
    Refresh token stays the same, new access token is issued.
    """
    raw = await redis_client.get(f"mcp:refresh:{refresh_token}")
    if raw is None:
        return None

    data = json.loads(raw)
    api_key_encrypted = data["api_key_encrypted"]
    api_key = decrypt_api_key(api_key_encrypted)
    if api_key is None:
        return None

    # New access token
    new_access = secrets.token_urlsafe(32)
    now = int(time.time())
    access_payload = json.dumps(
        {
            "api_key_encrypted": encrypt_api_key(api_key),
            "user_id": data["user_id"],
            "email": data.get("email", ""),
            "client_id": data.get("client_id", "unknown"),
            "exp": now + _ACCESS_TOKEN_TTL,
        },
        separators=(",", ":"),
    )
    await redis_client.setex(f"mcp:token:{new_access}", _ACCESS_TOKEN_TTL, access_payload)

    return new_access, refresh_token, _ACCESS_TOKEN_TTL
