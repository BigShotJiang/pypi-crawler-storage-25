"""Валидация и smart date parsing для MCP tools."""

import calendar
import datetime
import re

from fastmcp.exceptions import ToolError

from investgame_mcp.types import _FEATURES_MAPPING, _SECTOR_ALIASES, _VALID_FEATURES_DB, _VALID_SECTORS


def _map_feature(value: str) -> str:
    """Map MCP features enum to internal DB value, with validation.

    Raises ToolError for unknown values (аналогично _map_sector).
    """
    upper = value.strip().upper()
    mapped = _FEATURES_MAPPING.get(upper, upper)
    if mapped not in _VALID_FEATURES_DB:
        raise ToolError(f"Unknown feature '{value}'. Valid: AI_OR_ML, BLOCKCHAIN, UGC, RMG")
    return mapped


def _map_sector(value: str) -> str:
    """Map user-facing sector value to API value, with validation.

    Supports aliases (e.g. GAMING → GAMING_CONTENT). Raises ToolError for unknown values.
    """
    upper = value.strip().upper()
    mapped = _SECTOR_ALIASES.get(upper, upper)
    if mapped not in _VALID_SECTORS:
        raise ToolError(f"Unknown sector '{value}'. Valid: GAMING_CONTENT, GAMING_ECOSYSTEM, CONSUMER_APPS")
    return mapped


def _normalize_country(value: str) -> str:
    """Normalize ISO 3166-1 alpha-2 country code: upper + strip + validate."""
    code = value.strip().upper()
    if len(code) != 2 or not code.isalpha():
        raise ToolError(f"hq_country must be a 2-letter ISO code (e.g. US, GB, TR), got: '{value}'")
    return code


def _validate_date(value: str | None, param_name: str) -> str | None:
    """Validate YYYY-MM-DD date format and semantic correctness. Raises ToolError on failure."""
    if value is None:
        return None
    value = value.strip()
    try:
        datetime.date.fromisoformat(value)
    except ValueError:
        raise ToolError(f"{param_name} must be a valid YYYY-MM-DD date, got: '{value}'") from None
    return value


def _check_period_date_conflict(period: str | None, date_from: str | None, date_to: str | None) -> None:
    """Validate that period and date_from/date_to are not used together, and date_from <= date_to."""
    if period and (date_from or date_to):
        raise ToolError("Cannot use 'period' together with 'date_from'/'date_to'. Use one or the other.")
    if date_from and date_to:
        if datetime.date.fromisoformat(date_from) > datetime.date.fromisoformat(date_to):
            raise ToolError(f"date_from ({date_from}) must not be after date_to ({date_to})")


def _resolve_and_validate_dates(
    date_from: str | None, date_to: str | None, period: str | None = None
) -> tuple[str | None, str | None]:
    """Smart date parsing + validation (DRY: используется в tools без period и с period)."""
    resolved_from, resolved_to = _resolve_smart_dates(date_from, date_to)
    validated_from = _validate_date(resolved_from, "date_from")
    validated_to = _validate_date(resolved_to, "date_to")
    _check_period_date_conflict(period, validated_from, validated_to)
    return validated_from, validated_to


# Паттерны для smart date parsing (Q1 2024, 1Q2024, H1 2024)
_RE_QUARTER = re.compile(r"^[Qq]([1-4])\s*(\d{4})$")
_RE_QUARTER_COMPACT = re.compile(r"^([1-4])[Qq](\d{4})$")
_RE_HALF = re.compile(r"^[Hh]([12])\s*(\d{4})$")
_RE_YEAR = re.compile(r"^(\d{4})$")

# Маппинг квартал → (start_month, end_month)
_QUARTER_MONTHS = {1: (1, 3), 2: (4, 6), 3: (7, 9), 4: (10, 12)}


def _parse_smart_date(value: str) -> tuple[str, str | None]:
    """Parse human-friendly date shortcut into (date_from, date_to | None).

    Поддерживаемые форматы: "2024" (год), "Q1 2024"/"1Q2024" (квартал),
    "H1 2024" (полугодие), "YTD" (с начала года), "last quarter",
    "YYYY-MM-DD" (ISO, passthrough).
    Возвращает (date_from, date_to) для периодов, (date, None) для точных дат.
    """
    value = value.strip()

    # YTD
    if value.upper() == "YTD":
        today = datetime.date.today()
        return (f"{today.year}-01-01", today.isoformat())

    # last quarter
    if value.lower() == "last quarter":
        today = datetime.date.today()
        # Текущий квартал: (month-1)//3 + 1, предыдущий = current - 1
        current_q = (today.month - 1) // 3 + 1
        if current_q == 1:
            # Предыдущий = Q4 прошлого года
            year = today.year - 1
            start_m, end_m = _QUARTER_MONTHS[4]
        else:
            year = today.year
            start_m, end_m = _QUARTER_MONTHS[current_q - 1]
        last_day = calendar.monthrange(year, end_m)[1]
        return (f"{year}-{start_m:02d}-01", f"{year}-{end_m:02d}-{last_day:02d}")

    # Полный год: "2024"
    m = _RE_YEAR.match(value)
    if m:
        year = m.group(1)
        return (f"{year}-01-01", f"{year}-12-31")

    # Квартал: "Q1 2024" или "1Q2024"
    m = _RE_QUARTER.match(value) or _RE_QUARTER_COMPACT.match(value)
    if m:
        q, year = int(m.group(1)), int(m.group(2))
        start_m, end_m = _QUARTER_MONTHS[q]
        last_day = calendar.monthrange(year, end_m)[1]
        return (f"{year}-{start_m:02d}-01", f"{year}-{end_m:02d}-{last_day:02d}")

    # Полугодие: "H1 2024" / "H2 2024"
    m = _RE_HALF.match(value)
    if m:
        h, year = int(m.group(1)), int(m.group(2))
        if h == 1:
            return (f"{year}-01-01", f"{year}-06-30")
        else:
            return (f"{year}-07-01", f"{year}-12-31")

    # ISO дата или неизвестный формат → passthrough
    return (value, None)


def _resolve_smart_dates(date_from: str | None, date_to: str | None) -> tuple[str | None, str | None]:
    """Apply smart date parsing. Handles single or both boundaries as shortcuts.

    Логика: каждый параметр парсится независимо через _parse_smart_date.
    Для date_from берём начало периода (parsed_from).
    Для date_to берём конец периода (parsed_to, или parsed_from если точная дата).
    При одном параметре: auto-expand если результат — период.
    """
    if not date_from and not date_to:
        return None, None

    resolved_from = date_from
    resolved_to = date_to

    if date_from and date_to:
        # Оба заданы — парсим каждый независимо
        from_start, from_end = _parse_smart_date(date_from)
        to_start, to_end = _parse_smart_date(date_to)
        resolved_from = from_start  # Начало периода date_from
        resolved_to = to_end or to_start  # Конец периода date_to (или сама дата)
    elif date_from:
        parsed_from, parsed_to = _parse_smart_date(date_from)
        resolved_from = parsed_from
        if parsed_to:
            resolved_to = parsed_to
    elif date_to:
        parsed_from, parsed_to = _parse_smart_date(date_to)
        if parsed_to:
            resolved_to = parsed_to
            resolved_from = parsed_from
        else:
            resolved_to = parsed_from

    return resolved_from, resolved_to
