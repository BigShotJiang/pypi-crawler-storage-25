"""MCP Resources — static data для агентов (enum descriptions).

Все 15 @mcp.resource декораторов + _json_resource helper.
"""

import json

from investgame_mcp.app import mcp


def _json_resource(data: dict) -> str:
    """Compact JSON для MCP resources (DRY helper)."""
    return json.dumps(data, ensure_ascii=False)


@mcp.resource("investgame://company-types")
def company_types() -> str:
    """Company type (role) filter values. Maps to _FILTER_TO_DB_TYPE in API."""
    return _json_resource(
        {
            "STRATEGIC": "Operating companies & their corporate venture arms — game studios, publishers, platform holders that also invest (e.g. Tencent, Sony, EA)",
            "VENTURE": "Venture capital funds & accelerators focused on gaming investments",
            "PRIVATE": "Private equity firms & institutional investors (pension funds, sovereign wealth)",
            "SERVICE_PROVIDERS": "Deal advisors, investment banks, legal firms, transaction services",
            "ANGELS": "Business angels & high-net-worth individual investors",
            "ASSET": "Game IP / Franchise (tracked as entity, not a legal company)",
            "OTHER": "Companies not fitting above categories",
            "AUTO": "Auto-assigned type (legacy, being phased out)",
        },
    )


@mcp.resource("investgame://deal-types")
def deal_types() -> str:
    """Deal type (sub-type) filter values for search_deals and get_deal_stats.

    These are more granular than category. E.g. category=MA contains MA_CONTROL + MA_MINORITY.
    """
    return _json_resource(
        {
            "MA_CONTROL": "M&A control (incl. LBO/MBO) — full acquisition",
            "MA_MINORITY": "M&A minority stake — partial ownership",
            "SEED": "Pre-Seed / Seed round",
            "SERIES_A": "Series A",
            "SERIES_B": "Series B",
            "SERIES_C_H": "Series C through H combined (group: expands to 6 sub-types)",
            "GROWTH_OR_EXPANSION": "Growth / Expansion round (late-stage VC or growth equity)",
            "EARLY_STAGE_OTHER": "Undisclosed early-stage / Accelerator / Grant (group: expands to 2 sub-types)",
            "OTHER_LATE_STAGE": "Undisclosed late-stage investment",
            "LISTING": "IPO / SPAC listing (going public)",
            "PIPE": "PIPE (Private Investment in Public Equity)",
            "FIXED_INCOME": "Fixed Income / Debt / Bond / Convertible notes issuance",
        },
    )


@mcp.resource("investgame://deal-categories")
def deal_categories() -> str:
    """Deal category (broad grouping) filter values."""
    return _json_resource(
        {
            "MA": "Mergers & Acquisitions — full or partial ownership change (buyouts, minority stakes)",
            "EARLY_STAGE_INVESTMENT": "Early-stage: Seed, Series A/B, accelerator grants, angel rounds",
            "LATE_STAGE_INVESTMENT": "Late-stage: Series C+, growth equity, expansion, venture debt",
            "PUBLIC_OFFERING": "Public offerings: IPO, SPAC listing, PIPE, fixed income / bond issuance",
        },
    )


@mcp.resource("investgame://features")
def company_features() -> str:
    """Company technology feature filter values."""
    return _json_resource(
        {
            "AI_OR_ML": "AI / Machine Learning — companies using AI/ML in games or tools",
            "BLOCKCHAIN": "Blockchain / Web3 / NFT / Play-to-Earn",
            "UGC": "User-Generated Content / Modding platforms",
            "RMG": "Real-Money Gaming / Skill-based / Cash competitions",
        },
    )


@mcp.resource("investgame://sectors")
def company_sectors() -> str:
    """Company sector filter values for search_companies and search_deals."""
    return _json_resource(
        {
            "GAMING_CONTENT": "Game developers, publishers, outsourcing / work-for-hire studios",
            "GAMING_ECOSYSTEM": "Gaming infrastructure: esports, adtech, dev tools, hardware, streaming, platforms",
            "CONSUMER_APPS": "Consumer applications adjacent to gaming (companion apps, social, entertainment)",
        },
    )


@mcp.resource("investgame://game-genres")
def game_genres() -> str:
    """Game genre filter values. Use to find studios by the type of games they make."""
    return _json_resource(
        {
            "PUZZLE": "Puzzle, Match-3, Word games, Casual brain games, Trivia",
            "ARCADE": "Arcade, Hyper-casual, Endless runners, Clicker-adjacent",
            "SPORTS_RACING": "Sports simulations, Racing, Driving",
            "TABLETOP": "Board games, Card games, Digital tabletop, TCG/CCG",
            "SHOOTER": "FPS, TPS, Battle Royale shooters, Tactical shooters",
            "STRATEGY_MOBA": "RTS, Turn-based strategy, 4X, MOBA, Tower defense",
            "ACTION_RPG": "Action, RPG, ARPG, MMORPG, Hack & slash, Metroidvania",
            "SIMULATION_SANDBOX": "Life sim, City builder, Farming, Sandbox, Survival, Crafting",
            "CASINO": "Social casino, Slots, Poker, Bingo, Chance-based games",
            "OTHER": "Casual, Educational, Clicker, Idle, Music/Rhythm, Visual novel, Other genres",
        },
    )


@mcp.resource("investgame://ecosystem-segments")
def ecosystem_segments() -> str:
    """Ecosystem segment filter values for Gaming Ecosystem companies."""
    return _json_resource(
        {
            "CREATION_DEVELOPMENT": "Game engines, SDKs, Dev tools, QA, Localization, Audio",
            "ESPORTS": "Esports organizations, Tournaments, Leagues, Team management",
            "ADTECH": "Ad networks, Monetization, Attribution, User acquisition, Analytics",
            "HARDWARE": "Gaming hardware, Peripherals, VR/AR devices, Cloud gaming infra",
            "INFRASTRUCTURE_SERVICES": "Hosting, Backend-as-a-service, Payments, Anti-cheat, LiveOps",
            "DISTRIBUTION_SOCIAL_PLATFORMS": "App stores, Game platforms, Social platforms, Discord-like",
            "STREAMING_ENTERTAINMENT": "Game streaming, Content platforms, Influencer tools, Media",
            "OTHER": "Other gaming ecosystem services",
        },
    )


@mcp.resource("investgame://platforms")
def company_platforms() -> str:
    """Target platform filter values for search_companies."""
    return _json_resource(
        {
            "MOBILE": "iOS, Android mobile games",
            "PC_CONSOLE": "PC, PlayStation, Xbox, Nintendo Switch",
            "BROWSER": "Web browser games (HTML5, WebGL)",
            "VR_AR": "Virtual Reality / Augmented Reality games and experiences",
        },
    )


@mcp.resource("investgame://ownership-types")
def ownership_types() -> str:
    """Company ownership type filter values."""
    return _json_resource(
        {
            "PUBLIC": "Listed on stock exchange (NYSE, NASDAQ, LSE, TSE, etc.)",
            "PRIVATE": "Not publicly traded, privately held",
        },
    )


@mcp.resource("investgame://content-types")
def content_types() -> str:
    """Content type filter for Gaming Content sector companies."""
    return _json_resource(
        {
            "DEVELOPER_1P_PUBLISHER": "Game developer / First-party publisher — makes and publishes own games",
            "PUBLISHER_3P": "Third-party publisher — funds and publishes games made by other studios",
            "OUTSOURCING_WFH": "Outsourcing / Work-for-hire — art, QA, porting, co-development services",
        },
    )


@mcp.resource("investgame://ecosystem-types")
def ecosystem_types() -> str:
    """Target audience type for Gaming Ecosystem companies."""
    return _json_resource(
        {
            "B2C": "Business-to-Consumer — products/services for end users and gamers",
            "B2B": "Business-to-Business — tools/services for game companies (SDKs, analytics, infra)",
        },
    )


@mcp.resource("investgame://monetization-types")
def monetization_types() -> str:
    """Monetization model filter values for Gaming Content companies."""
    return _json_resource(
        {
            "IAP": "In-App Purchases — freemium with virtual goods/currency",
            "IAA": "In-App Advertising — ad-supported (rewarded video, interstitials)",
            "GAAS": "Games as a Service — live ops, battle passes, seasons",
            "UPFRONT_SALE": "Upfront Sale — premium buy-to-play (PC/console)",
            "DLC": "Downloadable Content — paid expansions, cosmetics packs",
            "SUBSCRIPTION": "Subscription — recurring payment (Apple Arcade, Game Pass)",
        },
    )


@mcp.resource("investgame://buyer-types")
def buyer_types() -> str:
    """Buyer type filter values for M&A deals (buyer_type parameter)."""
    return _json_resource(
        {
            "STRATEGIC_CORPORATE": "Operating company acquirer — game studios, publishers, platform holders (e.g. Tencent, EA)",
            "FINANCIAL_SPONSOR": "PE fund or VC fund acquirer — financial investors doing buyouts",
            "MANAGEMENT_MBO": "Management buyout — single individual/angel investor acquiring control",
        },
    )


@mcp.resource("investgame://investment-round-types")
def investment_round_types() -> str:
    """Investment round structure types for deal filtering."""
    return _json_resource(
        {
            "PREF_COMMON_STOCK": "Preferred or Common Stock equity round (standard VC structure)",
            "SAFE_CONVERTIBLE": "SAFE / Convertible Note — deferred valuation, converts to equity later",
            "VENTURE_DEBT": "Venture Debt / Revenue-based financing — non-dilutive capital",
            "OTHER": "Grants, accelerator funding, other non-standard structures",
        },
    )


@mcp.resource("investgame://regions")
def hq_regions() -> str:
    """HQ region filter values. Use EUROPE as shortcut for all European sub-regions."""
    return _json_resource(
        {
            "EUROPE": "Meta-region: expands to all 7 European sub-regions below",
            "British Isles": "UK, Ireland",
            "Northern Europe": "Scandinavia (non-Nordic classification)",
            "Western Europe": "France, Germany, Netherlands, Belgium, Switzerland, Austria",
            "Eastern Europe": "Poland, Czech Republic, Romania, Bulgaria, Ukraine, Russia",
            "Southern Europe": "Spain, Italy, Portugal, Greece, Turkey (European part)",
            "Baltic Countries": "Estonia, Latvia, Lithuania",
            "Nordic Countries": "Sweden, Finland, Denmark, Norway, Iceland",
            "North America": "USA, Canada",
            "Middle East": "UAE, Saudi Arabia, Israel, Turkey",
            "Eastern Asia": "China, Japan, South Korea, Hong Kong, Taiwan",
            "Southeast Asia": "Singapore, Vietnam, Philippines, Indonesia, Thailand",
            "Southern and Central_Asia": "India, Pakistan, Central Asia",
            "Oceania": "Australia, New Zealand",
        },
    )
