"""Pydantic contracts — минимальные поля, от которых зависит MCP server.

extra="allow" означает: новые поля в API не ломают тесты.
Только УДАЛЁННЫЕ или ИЗМЕНИВШИЕ ТИП поля вызывают ошибку.
"""

from pydantic import BaseModel


class _ResultItem(BaseModel):
    """Минимальный элемент списка — MCP server использует id для URL enrichment."""

    id: int
    model_config = {"extra": "allow"}


class CompanyListContract(BaseModel):
    """GET /companies/ — paginated list."""

    count: int
    results: list[_ResultItem]
    model_config = {"extra": "allow"}


class DealListContract(BaseModel):
    """GET /deals/ — paginated list."""

    count: int
    results: list[_ResultItem]
    model_config = {"extra": "allow"}


class DealStatsContract(BaseModel):
    """GET /deals/stats/ — aggregate statistics."""

    deals_count: int | None = None
    deals_size: str | None = None
    model_config = {"extra": "allow"}


class MultiplesContract(BaseModel):
    """GET /deals/multiples-stats/ — valuation multiples."""

    revenue_multiple: dict | None = None
    ebitda_multiple: dict | None = None
    model_config = {"extra": "allow"}


class CompanyStatsContract(BaseModel):
    """GET /companies/aggregate-stats/ — company aggregates."""

    total: dict
    model_config = {"extra": "allow"}
