"""
### Tribulnation Btcalpha
> An SDK to connect Btcalpha with the Tribulnation ecosystem.

- Details
"""