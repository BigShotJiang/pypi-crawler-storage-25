# Tribulnation Btcalpha SDK

> An SDK to connect Btcalpha with the Tribulnation ecosystem.

🚧 Under construction.