from setuptools import setup


setup(
    name="aion-news-to-signal",
    version="1.0.0",
    description="Offline/self-hosted AION News-to-Signal package for Indian financial news analysis.",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=["aion"],
    include_package_data=True,
    package_data={
        "aion": [
            "taxonomy/*.yaml",
            "data/*.csv",
            "models/*",
        ]
    },
    install_requires=[
        "torch==2.10.0",
        "transformers==5.3.0",
        "sentencepiece",
        "pandas",
        "numpy",
        "pyyaml",
        "huggingface_hub==1.7.1",
        "safetensors",
    ],
    python_requires=">=3.10",
)
