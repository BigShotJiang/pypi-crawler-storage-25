# AION News-to-Signal

Local/self-hosted Python package for Indian financial news analysis.

```python
from aion import analyze

result = analyze("RBI hikes repo rate by 25 bps")
print(result["trade_direction_signals"])
```

## Important packaging note

The full model artifacts are larger than standard PyPI per-file limits, so this wheel ships the full local inference code plus bundled taxonomy/data assets and downloads the public weights from Hugging Face on first use.

No hosted API calls are made during analysis. After the first artifact download, inference runs locally from the on-disk cache.

Artifacts are cached under:

- macOS: `~/Library/Caches/aion-news-to-signal`
- Linux: `~/.cache/aion-news-to-signal`

You can override this with:

- `AION_CACHE_DIR=/path/to/cache`

To force cached-only operation after the first download:

- `AION_LOCAL_FILES_ONLY=1`

Public weights:

- `AION-Analytics/aion-news-to-signal`
- `distilbert-base-uncased`
