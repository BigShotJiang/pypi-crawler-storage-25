from time import time

import pytest

from ellama import Document, EllamaDB


@pytest.fixture
def db(tmp_path):
    res = EllamaDB("test", model='all-minilm', cache_root=tmp_path)
    assert res.embeddings._ndim == 384
    assert res.embeddings.num_ctx == 512
    return res


def test_db(db: EllamaDB):
    db.add_documents([
        Document("hello world", metadata={"time": time(), "key": "value"}, id="one"),
        Document("goodbye and goodnight", metadata={"time": time()}, id="two")])
    docs = db.similarity_search("Greetings, Earth!", k=1)
    assert len(docs) == 1
    assert docs[0].id == "one"

    docs = db.similarity_search_with_relevance_scores_by_id("one")
    assert docs[0][0].page_content == "hello world"

    docs = db.get_docs({"key": "value"})
    assert len(docs) == 1
    assert docs[0].id == "one"


def test_long_context(db: EllamaDB):
    db.add_documents([Document("hello world " * 512, id="long")])
