"""Embeddings using Ollama + FAISS + Langchain.

config env var defaults:
- OLLAMA_BASE_URL=http://localhost:11434
- OLLAMA_MODEL=all-minilm (see <https://ollama.com/search?c=embedding>)
- CACHE_ROOT=.cache
"""
import functools
import logging
import os
import pickle
from contextlib import contextmanager
from pathlib import Path, PurePath
from shutil import rmtree
from warnings import warn

from tqdm import tqdm

os.environ['LIBGL_DEBUG'] = "quiet" # suppres FAISS libGL missing drirc file warnings

from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_community.vectorstores import FAISS
from langchain_community.vectorstores.faiss import dependable_faiss_import
from langchain_core.documents import Document
from langchain_ollama import OllamaEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

__all__ = ['EllamaDB']
log = logging.getLogger(__name__)
faiss = dependable_faiss_import()
BASE_URL = os.getenv('OLLAMA_BASE_URL', "http://localhost:11434")
MODEL = os.getenv('OLLAMA_MODEL', 'all-minilm:l6-v2')
CACHE_ROOT = Path(os.getenv('CACHE_ROOT', ".cache"))


@contextmanager
def log_level(logger_name: str, level: int | str):
    logger = logging.getLogger(logger_name)
    old = logger.level
    logger.setLevel(level)
    try:
        yield
    finally:
        logger.setLevel(old)


def mean(vectors: list[list[float]]) -> list[float]:
    """`numpy.mean(vectors, axis=0).tolist()`"""
    N, D = len(vectors), len(vectors[0])
    return [sum(v[i] for v in vectors) / N for i in range(D)]


class EllamaEmbeddings(OllamaEmbeddings):
    def __init__(self, *args, chars_per_token: float = 4, pull=True, **kwargs):
        super().__init__(*args, **kwargs)
        self._chars_per_token = chars_per_token
        if pull:
            with tqdm(desc=f"pulling {self.model}", unit="B", unit_scale=True, unit_divisor=1024) as t:
                for i in self._client.pull(self.model, stream=True):
                    t.total = i.total
                    if i.completed:
                        t.update(i.completed - t.n)
        info = self._client.show(self.model).modelinfo
        self._ndim = next(v for k, v in info.items() if k.endswith('embedding_length'))
        self.num_ctx = next(v for k, v in info.items() if k.endswith('context_length'))

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [
            mean([
                super().embed_documents([chunk])[0] for chunk in RecursiveCharacterTextSplitter(
                    chunk_size=int(self.num_ctx *
                                   self._chars_per_token)).split_text(text)]) if len(text) > self.num_ctx *
            self._chars_per_token else super().embed_documents([text])[0] for text in texts]


@functools.cache
def get_embedder(model, base_url, **kwargs):
    return EllamaEmbeddings(model=model, base_url=base_url, **kwargs)


class EllamaDB(FAISS):
    def __init__(self, name: str, model: str = MODEL, base_url: str = BASE_URL, cache_root: PurePath = CACHE_ROOT,
                 **ollama_kwargs):
        self.db_path = db_path = Path(cache_root) / name
        embedder = get_embedder(model, base_url, **ollama_kwargs)
        if (db_path / "index.faiss").exists():
            # super().load_local(db_path, embedder, allow_dangerous_deserialization=True)
            index = faiss.read_index(str(db_path / "index.faiss"))
            with (db_path / "index.pkl").open("rb") as f:
                docstore, index_to_docstore_id = pickle.load(f)
            super().__init__(embedder, index, docstore, index_to_docstore_id)
        else:
            rmtree(db_path, ignore_errors=True)
            super().__init__(embedder, faiss.IndexFlatL2(embedder._ndim), InMemoryDocstore(), {})

    def save_local(self):
        super().save_local(str(self.db_path))

    def add_documents(self, docs: list[Document], save_local=True):
        with log_level('httpx', logging.WARNING):
            for doc in tqdm(docs, desc=f"{self.db_path.name}:indexing", unit="doc"):
                if (old := self.get_by_ids([doc.id])) != [doc]:
                    if old:
                        log.debug("updating:%r", doc.id)
                        self.delete([doc.id])
                    log.debug("adding:%r", doc.id)
                    super().add_documents([doc])
        if save_local:
            self.save_local()

    @property
    def vectors(self) -> list[list[float]]:
        ntotal, d = self.index.ntotal, self.index.d
        return faiss.rev_swig_ptr(self.index.get_xb(), ntotal * d).reshape(ntotal, d)

    def similarity_search_with_relevance_scores_by_id(self, id: str, **kwargs) -> list[tuple[Document, float]]:
        index_id = next(i for i, j in self.index_to_docstore_id.items() if j == id)
        vec = self.vectors[index_id]
        relevance_score_fn = self._select_relevance_score_fn()
        k = self.index.ntotal
        return [(doc, relevance_score_fn(score))
                for doc, score in self.similarity_search_with_score_by_vector(vec, k=k, fetch_k=k, **kwargs)]

    def get_docs(self, filter: dict[str]) -> list[Document]:
        filter_func = self._create_filter_func(filter)
        return [doc for doc in self.get_by_ids(self.index_to_docstore_id.values()) if filter_func(doc.metadata)]

    @functools.cache
    def components(self, algo, random_state, **algo_kwargs):
        match algo.lower():
            case 'pca':
                from sklearn.decomposition import PCA as Algo
            case 'tsne' | 't-sne':
                from sklearn.manifold import TSNE as Algo
            case 'umap':
                from umap import UMAP as Algo
            case _:
                raise KeyError(f"Unknown algorithm: {algo}")

        algo = Algo(n_components=2, random_state=random_state, **algo_kwargs)
        return algo.fit_transform(self.vectors)

    def plot(self, algo='PCA', random_state=42, filter=None, ntotal=None, algo_kwargs=None, **plot_kwargs):
        """
        algo: {PCA, t-SNE, UMAP}

        Warning: run `self.components.cache_clear()` if docstore has changed since last plot.
        """
        import matplotlib.pyplot as plt
        components = self.components(algo, random_state, **(algo_kwargs or {}))
        if filter is None:
            mask = slice(0, None)
        else:
            filter_func = self._create_filter_func(filter)
            docs = self.get_by_ids([self.index_to_docstore_id[i] for i in range(ntotal or self.index.ntotal)])
            mask = [filter_func(doc.metadata) for doc in docs]
        plt.scatter(components[mask, 0], components[mask, 1], **plot_kwargs)

    def lora(self, anchors: list[str], output_model: str, epochs: int, train_split=0.9,
             base_model="sentence-transformers/all-MiniLM-L6-v2", num_ctx=None):
        """
        anchors: Document.metadata keys to use as positive target class
        """
        from datasets import Dataset
        from sentence_transformers import SentenceTransformerTrainer, SentenceTransformerTrainingArguments
        from sentence_transformers.sentence_transformer import losses
        from sentence_transformers.sentence_transformer.training_args import BatchSamplers
        from unsloth import FastSentenceTransformer, is_bf16_supported

        target_modules = ['value', 'key', 'dense', 'query']
        base = base_model.split("/")[1].lower()
        if base.startswith('qwen3-'):
            num_ctx = num_ctx or 1 << 15
            target_modules = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
        elif base.startswith('all-minilm-'):
            num_ctx = num_ctx or 512
        else:
            if num_ctx is None:
                warn("unknown model: defaulting to num_ctx=512", UserWarning, stacklevel=2)
                num_ctx = 512

        dataset = Dataset.from_list([{'anchor': doc.metadata[anchor], 'positive': doc.page_content}
                                     for anchor in anchors for doc in self.get_docs(lambda m: anchor in m)])
        split = dataset.train_test_split(train_size=train_split, seed=42)
        model = FastSentenceTransformer.from_pretrained(model_name=base_model, max_seq_length=num_ctx)
        model = FastSentenceTransformer.get_peft_model(model, r=32, target_modules=target_modules, lora_alpha=32,
                                                       use_gradient_checkpointing="unsloth",
                                                       task_type="FEATURE_EXTRACTION")

        loss = losses.MultipleNegativesRankingLoss(model)
        trainer = SentenceTransformerTrainer(
            model=model, train_dataset=split['train'],
            eval_dataset=split['test'], loss=loss, args=SentenceTransformerTrainingArguments(
                output_dir=str(self.db_path / "lora"), num_train_epochs=epochs, per_device_train_batch_size=256,
                learning_rate=3e-5, fp16=not is_bf16_supported(), bf16=is_bf16_supported(), eval_strategy="steps",
                eval_steps=50, logging_steps=50, warmup_ratio=0.03, report_to="none",
                lr_scheduler_type="constant_with_warmup", batch_sampler=BatchSamplers.NO_DUPLICATES))
        trainer.train()

        model_path = self.db_path / "lora" / output_model.replace(":", "-")
        saved = model.save_pretrained_gguf(str(model_path))
        if not saved['modelfile_location']:
            model_file = model_path / "Modelfile"
            gguf = Path(saved['gguf_files'][0])
            model_file.write_text(f"FROM {gguf.resolve()}")
            print("Please run:")
            print(f"ollama create {output_model} -f {model_file}")
