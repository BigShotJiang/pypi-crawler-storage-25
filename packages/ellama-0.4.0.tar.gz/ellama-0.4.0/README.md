# Ellama

*Embeddings library*

[![ollama](https://img.shields.io/badge/models-ollama-black?logo=ollama)](https://ollama.com/search?c=embedding)
[![unsloth](https://img.shields.io/badge/LoRA-unsloth-55b48c?logo=faker&logoColor=55b48c)](https://unsloth.ai/docs/basics/embedding-finetuning)
[![faiss](https://img.shields.io/badge/database-faiss-0866ff?logo=facebook)](https://github.com/facebookresearch/faiss)
[![langchain](https://img.shields.io/badge/glue-langchain-7fc8ff?logo=langchain)](https://github.com/langchain-ai/langchain)

[![pca](https://img.shields.io/badge/projection-PCA-f7931e?logo=scikit-learn)](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html)
[![t-sne](https://img.shields.io/badge/projection-t--SNE-f7931e?logo=scikit-learn)](https://scikit-learn.org/stable/modules/generated/sklearn.manifold.TSNE.html)
[![umap](https://img.shields.io/badge/projection-UMAP-f7931e)](https://umap-learn.readthedocs.io)
[![matplotlib](https://img.shields.io/badge/plot-matplotlib-green)](https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.scatter.html)

[![test](https://github.com/casperdcl/ellama/actions/workflows/test.yml/badge.svg)](https://github.com/casperdcl/ellama/actions/workflows/test.yml)

Unlike the overwhelming majority of alternatives:

- handles long inputs without truncation even if the underlying model has a small context window
- minimal config
- 100% human-written (thus sane & clean) codebase

> [!TIP]
> Please open an issue if you know of any better alternatives. I would love to archive this repo.

```py
from ellama import EllamaDB, Document

db = EllamaDB("test")
db.add_documents([
    Document("hello world", id="salutation"),
    Document("goodbye and goodnight", id="farewell")])
docs = db.similarity_search("Greetings, Earth!", k=1)
assert len(docs) == 1
assert docs[0].id == "salutation"
```

## plot

Embedding database visualisation:

```py
import matplotlib.pyplot as plt
from ellama import EllamaDB, Document
from sklearn.datasets import fetch_20newsgroups

raw = fetch_20newsgroups(data_home='.cache')
db = EllamaDB("20newsgroups")
db.add_documents([
    Document(raw.data[i], id=str(i), metadata={'name': raw.target_names[raw.target[i]]})
    for i in range(200)])

for group in ['alt.atheism', 'comp', 'misc.forsale', 'rec', 'rec.sport', 'sci',
              'soc.religion', 'talk.politics', 'talk.religion']:
    db.plot('t-SNE', label=group,
            filter=lambda metadata: metadata['name'].startswith(f'{group}.'))

plt.title(f"Newsgroup {db.embeddings.model} embeddings t-SNE")
plt.legend()
plt.show()
```

![](https://img.cdcl.ml/ellama-plot.svg)

## fine-tune

Low-rank adaptation (LoRA) re-using the newsgroups database created above:

```py
from ellama import EllamaDB
db = EllamaDB("20newsgroups")
db.lora(['name'], "ellama-lora:news", epochs=600)
# ollama create ellama-lora:news -f .cache/20newsgroups/lora/ellama-lora-news/Modelfile

# create new database using the new model
db_lora = EllamaDB("20newsgroups_lora", "ellama-lora:news", pull=False)
db_lora.add_documents(db.get_docs({}))
```

![](https://img.cdcl.ml/ellama-lora.svg)

## install

### `pip` (CPU)

```sh
pip install "ellama[cpu]"           # basic
pip install "ellama[cpu,plot]"      # plot('PCA' or 't-SNE')
pip install "ellama[cpu,plot,umap]" # plot('UMAP')
pip install "ellama[lora]"          # fine-tuning
```

### `conda` (GPU)

```yml
name: ellama
channels: [pytorch, nvidia, conda-forge]
dependencies:
- langchain 1.*
- langchain-community
- faiss-gpu
- requests
- tqdm
#- matplotlib   # ellama plot()
#- scikit-learn # ellama plot()
#- umap-learn   # ellama plot('UMAP')
#- unsloth      # ellama lora()
- pip
- pip:
  - ellama
```
