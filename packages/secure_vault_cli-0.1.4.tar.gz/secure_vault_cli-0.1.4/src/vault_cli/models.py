from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True, slots=True)
class KDFConfig:
    algorithm: str
    time_cost: int
    memory_cost: int
    parallelism: int
    hash_len: int
    salt_b64: str


@dataclass(frozen=True, slots=True)
class WrappingConfig:
    algorithm: str
    nonce_b64: str
    wrapped_master_key_b64: str


@dataclass(frozen=True, slots=True)
class VaultConfig:
    schema_version: int
    kdf: KDFConfig
    wrapping: WrappingConfig


@dataclass(frozen=True, slots=True)
class VaultSession:
    master_key: bytes
    index_key: bytes


@dataclass(frozen=True, slots=True)
class Document:
    id: str
    title: str
    created_at: datetime
    updated_at: datetime
    folder: str
    tags: tuple[str, ...]
    template_name: str
    body: str


@dataclass(frozen=True, slots=True)
class ListItem:
    id: str
    title: str
    updated_at: datetime
    folder: str
    tags: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class StoredDocument:
    lookup_key: bytes
    payload_version: int
    encrypted_payload: bytes
