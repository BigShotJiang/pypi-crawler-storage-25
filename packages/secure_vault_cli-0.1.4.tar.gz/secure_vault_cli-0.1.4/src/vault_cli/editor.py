from __future__ import annotations

import os
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

from vault_cli.models import Document
from vault_cli.permissions import restrict_path_permissions
from vault_cli.time_utils import clean_optional_text, parse_tags

DEFAULT_TEMPLATE_BODY = """Summary:
----text----

Goals / Scope:
----text----

Parts / Components:
----text----

Requirements / Constraints:
----text----

Notes:
----text----

Links / References:
----text----"""


@dataclass(frozen=True, slots=True)
class EditorResult:
    title: str
    folder: str
    tags: tuple[str, ...]
    body: str


class EditorCancelledError(Exception):
    """Raised when the integrated editor is cancelled."""


def initial_body_for_template(template_name: str) -> str:
    return DEFAULT_TEMPLATE_BODY if template_name == "default" else ""


def _prompt(prompt_text: str, default: str) -> str:
    suffix = f" [{default}]" if default else ""
    response = input(f"{prompt_text}{suffix}: ")
    return response if response.strip() else default


def run_integrated_editor(document: Document) -> EditorResult:
    print(f"Editing document: {document.id}")
    print(f"Created At: {document.created_at.isoformat()}")
    print(f"Template: {document.template_name}")
    print("Enter body lines. Use .save to save, .cancel to abort, .print to preview, .help for help.")
    title = clean_optional_text(_prompt("Title", document.title))
    folder = clean_optional_text(_prompt("Folder", document.folder))
    tags_text = _prompt("Tags (comma-separated)", ", ".join(document.tags))
    body_lines = document.body.splitlines()
    while True:
        line = input()
        if line == ".save":
            return EditorResult(
                title=title,
                folder=folder,
                tags=tuple(parse_tags(tags_text)),
                body="\n".join(body_lines).rstrip(),
            )
        if line == ".cancel":
            raise EditorCancelledError("Editor cancelled.")
        if line == ".print":
            print("\n".join(body_lines))
            continue
        if line == ".help":
            print(".save saves changes, .cancel aborts, .print shows the current body.")
            continue
        body_lines.append(line)


def run_external_editor(document: Document, state_dir: Path) -> EditorResult:
    editor = os.getenv("VISUAL") or os.getenv("EDITOR")
    if not editor:
        editor = "notepad" if os.name == "nt" else "vi"
    state_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w+", suffix=".txt", delete=False, dir=state_dir, encoding="utf-8") as handle:
        handle.write(document.body)
        handle.flush()
        temp_path = Path(handle.name)
    restrict_path_permissions(temp_path)
    try:
        subprocess.run([editor, str(temp_path)], check=True)
        body = temp_path.read_text(encoding="utf-8")
    finally:
        temp_path.unlink(missing_ok=True)
    return EditorResult(
        title=document.title,
        folder=document.folder,
        tags=document.tags,
        body=body.rstrip(),
    )
