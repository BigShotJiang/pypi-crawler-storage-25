from __future__ import annotations

from dataclasses import replace

from cryptography.exceptions import InvalidTag

from vault_cli.crypto import (
    PAYLOAD_VERSION,
    build_vault_config,
    compute_lookup_key,
    decrypt_document,
    encrypt_document,
    unlock_vault,
)
from vault_cli.db import get_connection
from vault_cli.models import Document, ListItem, VaultConfig, VaultSession
from vault_cli.paths import AppPaths, resolve_app_paths
from vault_cli.repository import DuplicateDocumentError, VaultRepository
from vault_cli.time_utils import clean_optional_text, normalize_document_id, parse_tags, utc_now
from vault_cli.vault_config import load_vault_config, save_vault_config, vault_is_initialized


class VaultError(Exception):
    """Base application error."""


class VaultNotInitializedError(VaultError):
    """Raised when the vault has not been initialized."""


class VaultAuthError(VaultError):
    """Raised when the passphrase cannot unlock the vault."""


class DocumentNotFoundError(VaultError):
    """Raised when a document cannot be found."""


class DocumentExistsError(VaultError):
    """Raised when a document ID already exists."""


class DocumentValidationError(VaultError):
    """Raised when user input is invalid."""


class VaultManager:
    def __init__(self, paths: AppPaths | None = None) -> None:
        self.paths = paths or resolve_app_paths()

    def is_initialized(self) -> bool:
        return vault_is_initialized(self.paths)

    def load_config(self) -> VaultConfig:
        if not self.is_initialized():
            raise VaultNotInitializedError("Vault is not initialized. Run `vault init` first.")
        return load_vault_config(self.paths)

    def initialize(self, passphrase: str) -> VaultSession:
        if self.is_initialized():
            raise DocumentValidationError("Vault is already initialized.")
        config, session = build_vault_config(passphrase)
        connection = get_connection(self.paths)
        connection.close()
        save_vault_config(self.paths, config)
        return session

    def unlock(self, passphrase: str) -> VaultSession:
        try:
            return unlock_vault(passphrase, self.load_config())
        except (InvalidTag, ValueError):
            raise VaultAuthError("Invalid passphrase.") from None

    def _repository(self) -> VaultRepository:
        return VaultRepository(get_connection(self.paths))

    def _lookup_key(self, session: VaultSession, raw_id: str) -> tuple[bytes, str, bool]:
        try:
            normalized_id, changed = normalize_document_id(raw_id)
        except ValueError as exc:
            raise DocumentValidationError(str(exc)) from exc
        return compute_lookup_key(session.index_key, normalized_id), normalized_id, changed

    def create_document(self, session: VaultSession, raw_id: str, template_name: str, body: str = "") -> tuple[Document, bool]:
        lookup_key, normalized_id, changed = self._lookup_key(session, raw_id)
        now = utc_now()
        document = Document(
            id=normalized_id,
            title="",
            created_at=now,
            updated_at=now,
            folder="inbox",
            tags=(),
            template_name=template_name,
            body=body,
        )
        stored = replace(encrypt_document(session, document, payload_version=PAYLOAD_VERSION), lookup_key=lookup_key)
        repository = self._repository()
        try:
            repository.insert_document(stored)
        except DuplicateDocumentError as exc:
            raise DocumentExistsError(str(exc)) from exc
        finally:
            repository.close()
        return document, changed

    def get_document(self, session: VaultSession, raw_id: str) -> Document:
        lookup_key, _, _ = self._lookup_key(session, raw_id)
        repository = self._repository()
        try:
            row = repository.get_document_row(lookup_key)
        finally:
            repository.close()
        if row is None:
            raise DocumentNotFoundError(f"Document '{raw_id.strip()}' was not found.")
        return decrypt_document(session, int(row["payload_version"]), row["encrypted_payload"])

    def list_documents(self, session: VaultSession, *, folder: str | None = None, tag: str | None = None) -> list[ListItem]:
        repository = self._repository()
        try:
            rows = repository.list_document_rows()
        finally:
            repository.close()
        items: list[ListItem] = []
        folder_filter = clean_optional_text(folder)
        tag_filter = clean_optional_text(tag).lower()
        for row in rows:
            document = decrypt_document(session, int(row["payload_version"]), row["encrypted_payload"])
            if folder_filter and document.folder != folder_filter:
                continue
            if tag_filter and tag_filter not in {item.lower() for item in document.tags}:
                continue
            items.append(
                ListItem(
                    id=document.id,
                    title=document.title,
                    updated_at=document.updated_at,
                    folder=document.folder,
                    tags=document.tags,
                )
            )
        items.sort(key=lambda item: item.id)
        return items

    def update_document(
        self,
        session: VaultSession,
        raw_id: str,
        *,
        title: str,
        folder: str,
        tags: list[str] | tuple[str, ...],
        body: str,
    ) -> Document:
        existing = self.get_document(session, raw_id)
        updated = Document(
            id=existing.id,
            title=clean_optional_text(title),
            created_at=existing.created_at,
            updated_at=utc_now(),
            folder=clean_optional_text(folder) or "inbox",
            tags=tuple(parse_tags(list(tags))),
            template_name=existing.template_name,
            body=body.rstrip(),
        )
        stored = encrypt_document(session, updated, payload_version=PAYLOAD_VERSION)
        repository = self._repository()
        try:
            changed = repository.update_document(stored)
        finally:
            repository.close()
        if not changed:
            raise DocumentNotFoundError(f"Document '{raw_id.strip()}' was not found.")
        return updated

    def delete_document(self, session: VaultSession, raw_id: str) -> Document:
        document = self.get_document(session, raw_id)
        lookup_key, _, _ = self._lookup_key(session, raw_id)
        repository = self._repository()
        try:
            deleted = repository.delete_document(lookup_key)
        finally:
            repository.close()
        if not deleted:
            raise DocumentNotFoundError(f"Document '{raw_id.strip()}' was not found.")
        return document
