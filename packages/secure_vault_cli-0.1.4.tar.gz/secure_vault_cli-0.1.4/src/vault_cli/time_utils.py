from __future__ import annotations

import re
from datetime import UTC, datetime

ID_ALLOWED_RE = re.compile(r"^[a-z0-9._-]+$")
CONTROL_CHAR_RE = re.compile(r"[\x00-\x1f\x7f]")


def utc_now() -> datetime:
    return datetime.now(UTC).replace(microsecond=0)


def to_utc_iso(value: datetime) -> str:
    normalized = value.astimezone(UTC).replace(microsecond=0)
    return normalized.isoformat().replace("+00:00", "Z")


def from_utc_iso(value: str) -> datetime:
    normalized = value.replace("Z", "+00:00")
    return datetime.fromisoformat(normalized).astimezone(UTC)


def normalize_document_id(raw_id: str) -> tuple[str, bool]:
    stripped = raw_id.strip().lower()
    if CONTROL_CHAR_RE.search(stripped):
        raise ValueError("Document ID cannot contain control characters.")
    if "/" in stripped or "\\" in stripped:
        raise ValueError("Document ID cannot contain path separators.")
    normalized = re.sub(r"\s+", "-", stripped)
    changed = normalized != raw_id
    if not normalized:
        raise ValueError("Document ID cannot be empty after normalization.")
    if not ID_ALLOWED_RE.match(normalized):
        raise ValueError("Document ID may only contain lowercase letters, digits, dots, underscores, and hyphens.")
    return normalized, changed


def clean_optional_text(value: str | None) -> str:
    if value is None:
        return ""
    return value.strip()


def parse_tags(value: str | list[str] | None) -> list[str]:
    if value is None:
        return []
    source = value if isinstance(value, list) else value.split(",")
    tags: list[str] = []
    seen: set[str] = set()
    for raw in source:
        tag = raw.strip()
        if not tag:
            continue
        lowered = tag.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        tags.append(tag)
    return tags
