from __future__ import annotations

SUCCESS = 0
ERROR = 1
INVALID_USAGE = 2
LOCKED = 3
NOT_FOUND = 4
ALREADY_EXISTS = 5
ABORTED = 6

