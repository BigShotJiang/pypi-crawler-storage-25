from __future__ import annotations

import os
import shutil
import subprocess


class ClipboardUnavailableError(Exception):
    """Raised when no supported clipboard backend is available."""


def copy_text(value: str) -> None:
    if os.name == "nt":
        subprocess.run(["clip"], input=value.encode("utf-16le"), check=True)
        return
    if shutil.which("wl-copy"):
        subprocess.run(["wl-copy"], input=value.encode("utf-8"), check=True)
        return
    if shutil.which("xclip"):
        subprocess.run(["xclip", "-selection", "clipboard"], input=value.encode("utf-8"), check=True)
        return
    if shutil.which("xsel"):
        subprocess.run(["xsel", "--clipboard", "--input"], input=value.encode("utf-8"), check=True)
        return
    raise ClipboardUnavailableError("No supported clipboard backend is available on this system.")
