from __future__ import annotations

import sqlite3

from vault_cli.paths import AppPaths, ensure_parent_directories

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS vault_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
    lookup_key BLOB NOT NULL PRIMARY KEY,
    payload_version INTEGER NOT NULL,
    encrypted_payload BLOB NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_documents_lookup_key
ON documents (lookup_key);
"""


def initialize_database(connection: sqlite3.Connection) -> None:
    connection.executescript(SCHEMA_SQL)
    connection.commit()


def get_connection(paths: AppPaths) -> sqlite3.Connection:
    ensure_parent_directories(paths)
    connection = sqlite3.connect(paths.db_path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=DELETE;")
    connection.execute("PRAGMA temp_store=MEMORY;")
    initialize_database(connection)
    return connection
