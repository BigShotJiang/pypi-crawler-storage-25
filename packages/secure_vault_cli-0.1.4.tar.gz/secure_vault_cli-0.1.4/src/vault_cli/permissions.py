from __future__ import annotations

import os
import stat
from pathlib import Path


def restrict_path_permissions(path: Path) -> None:
    if not path.exists():
        return
    try:
        if os.name == "nt":
            os.chmod(path, stat.S_IREAD | stat.S_IWRITE)
        else:
            os.chmod(path, 0o600)
    except OSError:
        return
