from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from platformdirs import PlatformDirs

APP_NAME = "vault_cli"
APP_DISPLAY_NAME = "vault"
HOME_ENV_VAR = "VAULT_CLI_HOME"
VAULT_FILE_NAME = "vault.json"
DB_FILE_NAME = "vault.db"


@dataclass(frozen=True, slots=True)
class AppPaths:
    data_dir: Path
    config_dir: Path
    cache_dir: Path
    state_dir: Path
    db_path: Path
    config_path: Path

    def purge_targets(self) -> tuple[Path, ...]:
        ordered = [
            self.config_path,
            self.db_path,
            self.cache_dir,
            self.state_dir,
            self.config_dir,
            self.data_dir,
        ]
        unique: list[Path] = []
        seen: set[Path] = set()
        for path in ordered:
            resolved = path.expanduser()
            if resolved not in seen:
                unique.append(resolved)
                seen.add(resolved)
        return tuple(unique)


def resolve_app_paths() -> AppPaths:
    custom_home = os.getenv(HOME_ENV_VAR)
    if custom_home:
        root = Path(custom_home).expanduser()
        data_dir = root / "data"
        config_dir = root / "config"
        cache_dir = root / "cache"
        state_dir = root / "state"
    else:
        dirs = PlatformDirs(appname=APP_NAME, appauthor=False, roaming=False, ensure_exists=False)
        data_dir = Path(dirs.user_data_path)
        config_dir = Path(dirs.user_config_path)
        cache_dir = Path(dirs.user_cache_path)
        state_dir = Path(dirs.user_state_path)
    return AppPaths(
        data_dir=data_dir,
        config_dir=config_dir,
        cache_dir=cache_dir,
        state_dir=state_dir,
        db_path=data_dir / DB_FILE_NAME,
        config_path=config_dir / VAULT_FILE_NAME,
    )


def ensure_parent_directories(paths: AppPaths) -> None:
    paths.data_dir.mkdir(parents=True, exist_ok=True)
    paths.config_dir.mkdir(parents=True, exist_ok=True)
    paths.cache_dir.mkdir(parents=True, exist_ok=True)
    paths.state_dir.mkdir(parents=True, exist_ok=True)
