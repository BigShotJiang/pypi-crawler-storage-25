from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from vault_cli.paths import AppPaths, resolve_app_paths


@dataclass(frozen=True, slots=True)
class PathStatus:
    path: Path
    exists: bool
    kind: str


def _path_kind(path: Path) -> str:
    if path.exists():
        return "dir" if path.is_dir() else "file"
    return "file" if path.suffix else "dir"


def describe_vault_paths(app_paths: AppPaths | None = None) -> tuple[PathStatus, ...]:
    resolved = app_paths or resolve_app_paths()
    return tuple(
        PathStatus(path=path, exists=path.exists(), kind=_path_kind(path))
        for path in resolved.purge_targets()
    )


def purge_vault_paths(app_paths: AppPaths | None = None) -> tuple[Path, ...]:
    deleted: list[Path] = []
    for item in describe_vault_paths(app_paths):
        path = item.path
        if not path.exists():
            continue
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=False)
        else:
            path.unlink(missing_ok=True)
        deleted.append(path)
    return tuple(deleted)
