from __future__ import annotations

import shlex
import sys
from contextlib import contextmanager
from dataclasses import dataclass
from io import StringIO
from pathlib import Path

import click
import typer
from rich.console import Console, Group, RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from vault_cli.command_docs import COMMAND_SPECS, visible_command_specs
from vault_cli.editor import EditorCancelledError, initial_body_for_template, run_external_editor, run_integrated_editor
from vault_cli.exit_codes import ABORTED, ALREADY_EXISTS, ERROR, INVALID_USAGE, LOCKED, NOT_FOUND
from vault_cli.maintenance import describe_vault_paths, purge_vault_paths
from vault_cli.models import Document, VaultSession
from vault_cli.paths import resolve_app_paths
from vault_cli.render import render_document_full, render_list_json, render_list_table
from vault_cli.services import (
    DocumentExistsError,
    DocumentNotFoundError,
    DocumentValidationError,
    VaultAuthError,
    VaultManager,
)
from vault_cli.time_utils import normalize_document_id, utc_now

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.history import InMemoryHistory

    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:  # pragma: no cover
    PromptSession = None  # type: ignore[assignment]
    PROMPT_TOOLKIT_AVAILABLE = False

    class Completer:  # type: ignore[no-redef]
        pass

    class Completion:  # type: ignore[no-redef]
        pass

    class AutoSuggestFromHistory:  # type: ignore[no-redef]
        pass

    class InMemoryHistory:  # type: ignore[no-redef]
        pass

app = typer.Typer(add_completion=False, help="Private local vault CLI for notes, ideas, and project documents.")
console = Console()
error_console = Console(stderr=True)
SHELL_EXIT_COMMANDS = {"exit", "q"}
SHELL_COMMAND_NAMES = tuple(spec.name for spec in visible_command_specs() if spec.name != "exit") + ("q",)
SHELL_TITLE = "vault"
SHELL_PROMPT_BASE = "vault"
COMMAND_OPTION_SPECS: dict[str, tuple[str, ...]] = {
    "new": ("--template",),
    "edit": ("--external-editor",),
    "list": ("--verbose", "--json", "--folder", "--tag"),
    "delete": ("--yes",),
    "export": ("--body-only", "--force"),
    "copy": ("--full",),
    "purge": ("--yes",),
}
TEMPLATE_CHOICES = ("default", "none")


@dataclass(slots=True)
class ShellState:
    session: VaultSession | None = None

    @property
    def unlocked(self) -> bool:
        return self.session is not None


ACTIVE_SHELL_STATE: ShellState | None = None


class CommandCompleter(Completer):
    def __init__(self, state_getter) -> None:
        self.state_getter = state_getter

    def get_completions(self, document, complete_event):  # type: ignore[override]
        text = document.text_before_cursor
        current_word = document.get_word_before_cursor(WORD=True)
        try:
            tokens = shlex.split(text)
            new_token = not text or text[-1].isspace()
        except ValueError:
            tokens = text.split()
            new_token = not text or text[-1].isspace()

        if not tokens or (len(tokens) == 1 and not new_token):
            for name in SHELL_COMMAND_NAMES:
                if name.startswith(current_word):
                    yield Completion(name, start_position=-len(current_word))
            return

        command = tokens[0].lower()
        prefix = "" if new_token else current_word

        if command in {"help", "man"}:
            for name in SHELL_COMMAND_NAMES:
                if name.startswith(prefix):
                    yield Completion(name, start_position=-len(prefix))
            return

        if tokens and tokens[-1] == "--template":
            for choice in TEMPLATE_CHOICES:
                yield Completion(choice, start_position=0)
            return

        if command == "new" and "--template" in tokens:
            for choice in TEMPLATE_CHOICES:
                if choice.startswith(prefix):
                    yield Completion(choice, start_position=-len(prefix))
            return

        if prefix.startswith("-") or new_token:
            for option in COMMAND_OPTION_SPECS.get(command, ()):
                if option.startswith(prefix):
                    yield Completion(option, start_position=-len(prefix))

        if command in {"view", "edit", "delete", "export", "copy"} and self.state_getter().unlocked:
            for document_id in _document_ids_for_completion(self.state_getter().session):
                if document_id.startswith(prefix):
                    yield Completion(document_id, start_position=-len(prefix))


def _document_ids_for_completion(session: VaultSession | None) -> list[str]:
    if session is None:
        return []
    manager = VaultManager(resolve_app_paths())
    try:
        return [item.id for item in manager.list_documents(session)]
    except Exception:
        return []


def is_tty_available() -> bool:
    return sys.stdin.isatty()


def prompt_passphrase(label: str = "Passphrase") -> str:
    return typer.prompt(label, hide_input=True)


def abort_with_code(message: str, exit_code: int) -> None:
    error_console.print(f"[bold red]Error:[/bold red] {message}")
    raise typer.Exit(code=exit_code)


def abort_invalid_usage(message: str) -> None:
    abort_with_code(message, INVALID_USAGE)


def shell_help_text() -> RenderableType:
    body = Text()
    body.append("Available commands:\n", style="bold")
    for spec in visible_command_specs():
        color = "magenta" if spec.name in {"help", "man", "exit"} else "cyan"
        body.append(f"  {spec.name:<12}", style=color)
        body.append(f"{spec.short}\n")
    body.append("  q           Exit the interactive shell.\n", style="magenta")
    return body


def render_command_help(command_name: str) -> RenderableType:
    spec = COMMAND_SPECS.get(command_name.lower())
    if spec is None:
        return f"Error: Unknown command '{command_name}'. Use `help` to see the available commands."
    body = Text()
    body.append(f"{spec.name}\n", style="bold cyan")
    body.append(f"{spec.short}\n\n")
    body.append("Usage:\n", style="bold")
    for usage in spec.usage:
        body.append(f"  {usage}\n")
    return body


def render_manual_index() -> RenderableType:
    body = Text()
    paths = resolve_app_paths()
    body.append("OVERVIEW\n", style="bold")
    body.append("  vault is a local single-user encrypted document vault for ideas, notes, and project documents.\n")
    body.append("  Functional metadata stays inside the encrypted payload. Only lookup_key, encrypted_payload,\n")
    body.append("  and non-sensitive technical metadata remain outside ciphertext.\n\n")
    body.append("COMMANDS\n", style="bold")
    for spec in visible_command_specs():
        body.append(f"  {spec.name:<12}", style="cyan")
        body.append(f"{spec.short}\n")
    body.append("\nDATA PATHS\n", style="bold")
    body.append(f"  vault.json  {paths.config_path}\n")
    body.append(f"  vault.db    {paths.db_path}\n")
    body.append("\nSECURITY NOTES\n", style="bold")
    body.append("  Passphrases are never accepted by CLI argument or environment variable in v1.\n")
    body.append("  export, copy, and --external-editor move plaintext outside the encrypted perimeter.\n")
    body.append("  SQLite uses journal_mode=DELETE and temp_store=MEMORY to reduce auxiliary artifacts.\n")
    body.append("\nLIMITATIONS\n", style="bold")
    body.append("  list and filters decrypt payloads in memory in v1.\n")
    body.append("  purge is application-level cryptographic erase, not guaranteed forensic erasure.\n")
    return body


def render_manual_page(command_name: str) -> RenderableType:
    spec = COMMAND_SPECS.get(command_name.lower())
    if spec is None:
        return f"Error: Unknown command '{command_name}'. Use `man` to see the command index."
    body = Text()
    body.append("NAME\n", style="bold")
    body.append(f"  {spec.name} - {spec.short}\n\n")
    body.append("USAGE\n", style="bold")
    for usage in spec.usage:
        body.append(f"  {usage}\n")
    body.append("\nDESCRIPTION\n", style="bold")
    body.append(f"  {spec.description}\n")
    if spec.options:
        body.append("\nOPTIONS\n", style="bold")
        for option in spec.options:
            body.append(f"  {option}\n")
    if spec.examples:
        body.append("\nEXAMPLES\n", style="bold")
        for example in spec.examples:
            body.append(f"  {example}\n")
    if spec.notes:
        body.append("\nNOTES\n", style="bold")
        for note in spec.notes:
            body.append(f"  {note}\n")
    if spec.security_notes:
        body.append("\nSECURITY\n", style="bold")
        for note in spec.security_notes:
            body.append(f"  {note}\n")
    if spec.exit_codes:
        body.append("\nEXIT CODES\n", style="bold")
        for item in spec.exit_codes:
            body.append(f"  {item}\n")
    return body


def render_shell_header(state: ShellState, status: str | None = None) -> Panel:
    body = Text()
    body.append(f"{SHELL_TITLE}\n", style="bold cyan")
    body.append("Secure local vault shell\n", style="white")
    body.append("Primary: init, unlock, lock, new, edit, view, list, delete, export, copy, purge\n")
    body.append("Shell: help, man, exit, q\n")
    body.append("Autocomplete: Tab completes commands and IDs only after unlock.\n", style="dim")
    body.append(
        f"Vault: {'unlocked' if state.unlocked else 'locked'}",
        style="green" if state.unlocked else "yellow",
    )
    if status:
        body.append(f"\nStatus: {status}", style="bright_black")
    return Panel(body, title="Interactive Shell", border_style="cyan")


def render_shell_view(state: ShellState, last_output: RenderableType | None, status: str | None = None) -> Group:
    if last_output is None or (isinstance(last_output, str) and not last_output.strip()):
        result_panel = Panel("No output yet. Type `help`, `man`, or run a command.", title="Result", border_style="dim")
    else:
        result_panel = Panel(last_output, title="Result", border_style="green")
    return Group(render_shell_header(state, status=status), result_panel)


@contextmanager
def command_capture() -> tuple[StringIO, StringIO]:
    global console, error_console
    stdout_buffer = StringIO()
    stderr_buffer = StringIO()
    original_console = console
    original_error_console = error_console
    console = Console(file=stdout_buffer, force_terminal=False, color_system=None)
    error_console = Console(file=stderr_buffer, force_terminal=False, color_system=None)
    try:
        yield stdout_buffer, stderr_buffer
    finally:
        console = original_console
        error_console = original_error_console


def dispatch_command(tokens: list[str]) -> str:
    try:
        with command_capture() as (stdout_buffer, stderr_buffer):
            app(args=tokens, prog_name="vault", standalone_mode=False)
    except click.ClickException as exc:
        return exc.format_message()
    except click.exceptions.Exit:
        return ""
    stdout_text = stdout_buffer.getvalue().strip()
    stderr_text = stderr_buffer.getvalue().strip()
    return "\n".join(part for part in (stdout_text, stderr_text) if part)


def _build_prompt_session(state_getter):
    if not PROMPT_TOOLKIT_AVAILABLE or not sys.stdin.isatty() or not sys.stdout.isatty():
        return None
    return PromptSession(
        completer=CommandCompleter(state_getter),
        complete_while_typing=False,
        history=InMemoryHistory(),
        auto_suggest=AutoSuggestFromHistory(),
        bottom_toolbar=lambda: _shell_toolbar_text(state_getter()),
    )


def _prompt_input(prompt_text: str, session=None) -> str:
    if session is None:
        return input(prompt_text)
    return session.prompt(prompt_text)


def _shell_prompt_text(state: ShellState) -> str:
    if state.unlocked:
        return f"{SHELL_PROMPT_BASE}> "
    return f"{SHELL_PROMPT_BASE}[locked]> "


def _shell_toolbar_text(state: ShellState) -> str:
    if state.unlocked:
        return " Tab: autocomplete commands and document IDs | Ctrl-D: exit | Plaintext leaves the vault with export/copy "
    return " Tab: autocomplete commands | unlock to enable ID completion | Ctrl-D: exit "


def _manager() -> VaultManager:
    return VaultManager(resolve_app_paths())


def _require_tty_for_prompt() -> None:
    if not is_tty_available():
        abort_with_code("This command requires an interactive TTY.", INVALID_USAGE)


def _resolve_session() -> VaultSession:
    if ACTIVE_SHELL_STATE is not None and ACTIVE_SHELL_STATE.session is not None:
        return ACTIVE_SHELL_STATE.session
    manager = _manager()
    if not manager.is_initialized():
        abort_with_code("Vault is not initialized. Run `vault init` first.", ERROR)
    if not is_tty_available():
        abort_with_code("Vault is locked and this command requires authentication in an interactive TTY.", LOCKED)
    try:
        return manager.unlock(prompt_passphrase())
    except VaultAuthError as exc:
        abort_with_code(str(exc), LOCKED)


def _confirm(prompt_text: str) -> bool:
    return typer.confirm(prompt_text, default=False)


def _warn_normalized(raw_id: str, normalized_id: str) -> None:
    if raw_id != normalized_id:
        console.print(f"Normalized document ID to '[cyan]{normalized_id}[/cyan]' before saving.")


def _editor_seed(raw_id: str, template_name: str) -> Document:
    now = utc_now()
    return Document(
        id=raw_id,
        title="",
        created_at=now,
        updated_at=now,
        folder="inbox",
        tags=(),
        template_name=template_name,
        body=initial_body_for_template(template_name),
    )


@app.command()
def help(command: str | None = typer.Argument(None, metavar="COMMAND")) -> None:
    console.print(shell_help_text() if command is None else render_command_help(command))


@app.command()
def man(command: str | None = typer.Argument(None, metavar="COMMAND")) -> None:
    console.print(render_manual_index() if command is None else render_manual_page(command))


@app.command()
def init() -> None:
    _require_tty_for_prompt()
    manager = _manager()
    if manager.is_initialized():
        abort_with_code("Vault is already initialized.", ERROR)
    first = prompt_passphrase("New passphrase")
    second = prompt_passphrase("Confirm passphrase")
    if first != second:
        abort_with_code("Passphrases do not match.", INVALID_USAGE)
    if not first:
        abort_invalid_usage("Passphrase cannot be empty.")
    manager.initialize(first)
    console.print("Vault initialized successfully.")


@app.command()
def unlock() -> None:
    _require_tty_for_prompt()
    manager = _manager()
    if not manager.is_initialized():
        abort_with_code("Vault is not initialized. Run `vault init` first.", ERROR)
    try:
        session = manager.unlock(prompt_passphrase())
    except VaultAuthError as exc:
        abort_with_code(str(exc), LOCKED)
    if ACTIVE_SHELL_STATE is None:
        run_shell(initial_state=ShellState(session=session))
        return
    ACTIVE_SHELL_STATE.session = session
    console.print("Vault unlocked for the current shell session.")


@app.command()
def lock() -> None:
    if ACTIVE_SHELL_STATE is not None:
        ACTIVE_SHELL_STATE.session = None
    console.print("Vault locked.")


@app.command()
def new(
    id: str = typer.Argument(..., metavar="ID"),
    template: str = typer.Option("default", "--template"),
) -> None:
    if template not in {"default", "none"}:
        abort_invalid_usage("Template must be `default` or `none`.")
    session = _resolve_session()
    manager = _manager()
    try:
        result = run_integrated_editor(_editor_seed(id, template))
    except EditorCancelledError:
        abort_with_code("Document creation cancelled.", ABORTED)
    body = result.body if template == "none" else (result.body or initial_body_for_template(template))
    try:
        normalized_id, _ = normalize_document_id(id)
        document, changed = manager.create_document(session, id, template, body=body)
        updated = manager.update_document(
            session,
            document.id,
            title=result.title,
            folder=result.folder,
            tags=result.tags,
            body=body,
        )
    except DocumentExistsError as exc:
        abort_with_code(str(exc), ALREADY_EXISTS)
    except DocumentValidationError as exc:
        abort_invalid_usage(str(exc))
    if changed:
        _warn_normalized(id, normalized_id)
    console.print(f"Created document '[cyan]{updated.id}[/cyan]'.")


@app.command()
def view(id: str = typer.Argument(..., metavar="ID")) -> None:
    session = _resolve_session()
    manager = _manager()
    try:
        document = manager.get_document(session, id)
    except DocumentNotFoundError as exc:
        abort_with_code(str(exc), NOT_FOUND)
    except DocumentValidationError as exc:
        abort_invalid_usage(str(exc))
    console.print(render_document_full(document))


@app.command(name="list")
def list_documents(
    verbose: bool = typer.Option(False, "--verbose"),
    json_output: bool = typer.Option(False, "--json"),
    folder: str | None = typer.Option(None, "--folder"),
    tag: str | None = typer.Option(None, "--tag"),
) -> None:
    session = _resolve_session()
    manager = _manager()
    items = manager.list_documents(session, folder=folder, tag=tag)
    if json_output:
        console.print(render_list_json(items))
        return
    if not items:
        console.print("No documents found.")
        return
    console.print(render_list_table(items, verbose=verbose))


@app.command()
def delete(
    id: str = typer.Argument(..., metavar="ID"),
    yes: bool = typer.Option(False, "--yes"),
) -> None:
    session = _resolve_session()
    manager = _manager()
    if not yes and not _confirm(f"Delete document '{id}'?"):
        abort_with_code("Delete aborted.", ABORTED)
    try:
        document = manager.delete_document(session, id)
    except DocumentNotFoundError as exc:
        abort_with_code(str(exc), NOT_FOUND)
    except DocumentValidationError as exc:
        abort_invalid_usage(str(exc))
    console.print(f"Deleted document '[cyan]{document.id}[/cyan]'.")


@app.command()
def edit(
    id: str = typer.Argument(..., metavar="ID"),
    external_editor: bool = typer.Option(False, "--external-editor"),
) -> None:
    session = _resolve_session()
    manager = _manager()
    try:
        existing = manager.get_document(session, id)
    except DocumentNotFoundError as exc:
        abort_with_code(str(exc), NOT_FOUND)
    except DocumentValidationError as exc:
        abort_invalid_usage(str(exc))
    try:
        if external_editor:
            console.print("Warning: the external editor may create plaintext artifacts outside the encrypted perimeter.")
            result = run_external_editor(existing, resolve_app_paths().state_dir)
        else:
            result = run_integrated_editor(existing)
        updated = manager.update_document(
            session,
            id,
            title=result.title,
            folder=result.folder,
            tags=result.tags,
            body=result.body,
        )
    except EditorCancelledError:
        abort_with_code("Edit cancelled.", ABORTED)
    console.print(f"Updated document '[cyan]{updated.id}[/cyan]'.")


def _validate_export_destination(path: Path, *, force: bool) -> None:
    if not path.parent.exists():
        abort_with_code("Destination directory does not exist.", INVALID_USAGE)
    if path.exists() and not force:
        abort_with_code("Destination already exists. Use --force to overwrite.", ABORTED)


@app.command()
def export(
    id: str = typer.Argument(..., metavar="ID"),
    path: Path = typer.Argument(..., metavar="PATH"),
    body_only: bool = typer.Option(False, "--body-only"),
    force: bool = typer.Option(False, "--force"),
) -> None:
    session = _resolve_session()
    manager = _manager()
    _validate_export_destination(path, force=force)
    try:
        document = manager.get_document(session, id)
    except DocumentNotFoundError as exc:
        abort_with_code(str(exc), NOT_FOUND)
    console.print("Warning: export writes plaintext outside the encrypted perimeter.")
    content = document.body if body_only else render_document_full(document)
    path.write_text(content, encoding="utf-8")
    console.print(f"Exported document to {path}.")


@app.command()
def copy(
    id: str = typer.Argument(..., metavar="ID"),
    full: bool = typer.Option(False, "--full"),
) -> None:
    from vault_cli.clipboard import ClipboardUnavailableError, copy_text

    session = _resolve_session()
    manager = _manager()
    try:
        document = manager.get_document(session, id)
    except DocumentNotFoundError as exc:
        abort_with_code(str(exc), NOT_FOUND)
    console.print("Warning: clipboard output is outside the encrypted perimeter.")
    try:
        copy_text(render_document_full(document) if full else document.body)
    except ClipboardUnavailableError as exc:
        abort_with_code(str(exc), ERROR)
    console.print(f"Copied {'full document' if full else 'document body'} to clipboard.")


@app.command()
def purge(
    yes: bool = typer.Option(False, "--yes"),
) -> None:
    _resolve_session()
    preview = describe_vault_paths(resolve_app_paths())
    table = Table(title="Vault Paths")
    table.add_column("Path", style="cyan")
    table.add_column("Kind", style="magenta")
    table.add_column("Status", style="green")
    for item in preview:
        table.add_row(str(item.path), item.kind, "exists" if item.exists else "missing")
    console.print(table)
    console.print("Warning: purge performs application-level cryptographic erase and cannot guarantee forensic disk erasure.")
    if not yes and not _confirm("Purge the local vault?"):
        abort_with_code("Purge aborted.", ABORTED)
    deleted = purge_vault_paths(resolve_app_paths())
    if ACTIVE_SHELL_STATE is not None:
        ACTIVE_SHELL_STATE.session = None
    console.print(f"Purged {len(deleted)} vault path(s).")


@app.command()
def shell() -> None:
    run_shell()


def run_shell(initial_state: ShellState | None = None) -> None:
    global ACTIVE_SHELL_STATE
    state = initial_state or ShellState(session=None)
    ACTIVE_SHELL_STATE = state
    session = _build_prompt_session(lambda: state)
    last_output: RenderableType | None = shell_help_text()
    status = "Ready"
    while True:
        console.clear()
        console.print(render_shell_view(state, last_output, status=status))
        try:
            raw_line = _prompt_input(_shell_prompt_text(state), session=session)
        except (EOFError, KeyboardInterrupt):
            console.print()
            break
        line = raw_line.strip()
        if not line:
            status = "Waiting for command"
            continue
        try:
            tokens = shlex.split(line)
        except ValueError as exc:
            last_output = f"Error: {exc}"
            status = "Parse error"
            continue
        if tokens[0].lower() in SHELL_EXIT_COMMANDS:
            break
        last_output = dispatch_command(tokens)
        status = f"Completed: {tokens[0].lower()}"
    ACTIVE_SHELL_STATE = None


def main() -> None:
    if len(sys.argv) <= 1:
        run_shell()
        return
    app()


if __name__ == "__main__":
    main()
