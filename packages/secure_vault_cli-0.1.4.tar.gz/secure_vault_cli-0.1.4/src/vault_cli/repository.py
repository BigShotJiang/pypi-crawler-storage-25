from __future__ import annotations

import sqlite3

from vault_cli.models import StoredDocument


class RepositoryError(Exception):
    """Base exception for repository operations."""


class DuplicateDocumentError(RepositoryError):
    """Raised when a document ID already exists."""


class VaultRepository:
    def __init__(self, connection: sqlite3.Connection) -> None:
        self.connection = connection

    def close(self) -> None:
        self.connection.close()

    def insert_document(self, stored: StoredDocument) -> None:
        try:
            self.connection.execute(
                """
                INSERT INTO documents (lookup_key, payload_version, encrypted_payload)
                VALUES (?, ?, ?)
                """,
                (stored.lookup_key, stored.payload_version, stored.encrypted_payload),
            )
            self.connection.commit()
        except sqlite3.IntegrityError as exc:
            self.connection.rollback()
            raise DuplicateDocumentError("A document with that ID already exists.") from exc

    def update_document(self, stored: StoredDocument) -> bool:
        cursor = self.connection.execute(
            """
            UPDATE documents
            SET payload_version = ?, encrypted_payload = ?
            WHERE lookup_key = ?
            """,
            (stored.payload_version, stored.encrypted_payload, stored.lookup_key),
        )
        self.connection.commit()
        return cursor.rowcount > 0

    def get_document_row(self, lookup_key: bytes) -> sqlite3.Row | None:
        return self.connection.execute(
            """
            SELECT lookup_key, payload_version, encrypted_payload
            FROM documents
            WHERE lookup_key = ?
            """,
            (lookup_key,),
        ).fetchone()

    def list_document_rows(self) -> list[sqlite3.Row]:
        return self.connection.execute(
            """
            SELECT lookup_key, payload_version, encrypted_payload
            FROM documents
            ORDER BY rowid ASC
            """
        ).fetchall()

    def delete_document(self, lookup_key: bytes) -> bool:
        cursor = self.connection.execute(
            """
            DELETE FROM documents
            WHERE lookup_key = ?
            """,
            (lookup_key,),
        )
        self.connection.commit()
        return cursor.rowcount > 0
