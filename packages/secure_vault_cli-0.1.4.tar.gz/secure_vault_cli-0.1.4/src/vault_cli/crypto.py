from __future__ import annotations

import base64
import hmac
import json
import os
from hashlib import sha256

from argon2.low_level import Type, hash_secret_raw
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from vault_cli.models import Document, KDFConfig, StoredDocument, VaultConfig, VaultSession, WrappingConfig
from vault_cli.time_utils import from_utc_iso, to_utc_iso
from vault_cli.vault_config import VAULT_SCHEMA_VERSION

MASTER_KEY_SIZE = 32
INDEX_KEY_SIZE = 32
AES_GCM_NONCE_SIZE = 12
PAYLOAD_VERSION = 1
DOCUMENT_TYPE_AAD = "document-v1"
WRAP_AAD = b"vault-master-key-v1"


def _b64encode(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _b64decode(data: str) -> bytes:
    return base64.b64decode(data.encode("ascii"))


def default_kdf_config() -> KDFConfig:
    return KDFConfig(
        algorithm="argon2id",
        time_cost=3,
        memory_cost=65536,
        parallelism=4,
        hash_len=32,
        salt_b64=_b64encode(os.urandom(16)),
    )


def derive_wrapping_key(passphrase: str, kdf: KDFConfig) -> bytes:
    return hash_secret_raw(
        secret=passphrase.encode("utf-8"),
        salt=_b64decode(kdf.salt_b64),
        time_cost=kdf.time_cost,
        memory_cost=kdf.memory_cost,
        parallelism=kdf.parallelism,
        hash_len=kdf.hash_len,
        type=Type.ID,
    )


def build_vault_config(passphrase: str) -> tuple[VaultConfig, VaultSession]:
    kdf = default_kdf_config()
    wrapping_key = derive_wrapping_key(passphrase, kdf)
    master_key = os.urandom(MASTER_KEY_SIZE)
    nonce = os.urandom(AES_GCM_NONCE_SIZE)
    wrapped_master_key = AESGCM(wrapping_key).encrypt(nonce, master_key, WRAP_AAD)
    session = VaultSession(master_key=master_key, index_key=derive_index_key(master_key))
    config = VaultConfig(
        schema_version=VAULT_SCHEMA_VERSION,
        kdf=kdf,
        wrapping=WrappingConfig(
            algorithm="AESGCM",
            nonce_b64=_b64encode(nonce),
            wrapped_master_key_b64=_b64encode(wrapped_master_key),
        ),
    )
    return config, session


def unlock_vault(passphrase: str, config: VaultConfig) -> VaultSession:
    wrapping_key = derive_wrapping_key(passphrase, config.kdf)
    master_key = AESGCM(wrapping_key).decrypt(
        _b64decode(config.wrapping.nonce_b64),
        _b64decode(config.wrapping.wrapped_master_key_b64),
        WRAP_AAD,
    )
    return VaultSession(master_key=master_key, index_key=derive_index_key(master_key))


def derive_index_key(master_key: bytes) -> bytes:
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=INDEX_KEY_SIZE,
        salt=None,
        info=b"vault-cli:index-key:v1",
    )
    return hkdf.derive(master_key)


def compute_lookup_key(index_key: bytes, normalized_id: str) -> bytes:
    return hmac.new(index_key, normalized_id.encode("utf-8"), sha256).digest()


def build_document_aad(payload_version: int) -> bytes:
    return f"{DOCUMENT_TYPE_AAD}:{payload_version}".encode("utf-8")


def serialize_document(document: Document) -> bytes:
    payload = {
        "id": document.id,
        "title": document.title,
        "created_at": to_utc_iso(document.created_at),
        "updated_at": to_utc_iso(document.updated_at),
        "folder": document.folder,
        "tags": list(document.tags),
        "template_name": document.template_name,
        "body": document.body,
    }
    return json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode("utf-8")


def deserialize_document(data: bytes) -> Document:
    payload = json.loads(data.decode("utf-8"))
    return Document(
        id=payload["id"],
        title=payload.get("title", ""),
        created_at=from_utc_iso(payload["created_at"]),
        updated_at=from_utc_iso(payload["updated_at"]),
        folder=payload.get("folder", ""),
        tags=tuple(payload.get("tags", [])),
        template_name=payload.get("template_name", "none"),
        body=payload.get("body", ""),
    )


def encrypt_document(session: VaultSession, document: Document, payload_version: int = PAYLOAD_VERSION) -> StoredDocument:
    serialized = serialize_document(document)
    nonce = os.urandom(AES_GCM_NONCE_SIZE)
    ciphertext = AESGCM(session.master_key).encrypt(nonce, serialized, build_document_aad(payload_version))
    return StoredDocument(
        lookup_key=compute_lookup_key(session.index_key, document.id),
        payload_version=payload_version,
        encrypted_payload=nonce + ciphertext,
    )


def decrypt_document(session: VaultSession, payload_version: int, encrypted_payload: bytes) -> Document:
    nonce = encrypted_payload[:AES_GCM_NONCE_SIZE]
    ciphertext = encrypted_payload[AES_GCM_NONCE_SIZE:]
    plaintext = AESGCM(session.master_key).decrypt(nonce, ciphertext, build_document_aad(payload_version))
    return deserialize_document(plaintext)
