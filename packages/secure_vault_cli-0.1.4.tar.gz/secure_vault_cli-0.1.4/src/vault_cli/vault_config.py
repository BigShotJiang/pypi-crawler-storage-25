from __future__ import annotations

import json
from dataclasses import asdict

from vault_cli.models import KDFConfig, VaultConfig, WrappingConfig
from vault_cli.paths import AppPaths, ensure_parent_directories
from vault_cli.permissions import restrict_path_permissions

VAULT_SCHEMA_VERSION = 1


def save_vault_config(paths: AppPaths, config: VaultConfig) -> None:
    ensure_parent_directories(paths)
    paths.config_path.write_text(json.dumps(asdict(config), indent=2), encoding="utf-8")
    restrict_path_permissions(paths.config_path)


def load_vault_config(paths: AppPaths) -> VaultConfig:
    raw = json.loads(paths.config_path.read_text(encoding="utf-8"))
    return VaultConfig(
        schema_version=int(raw["schema_version"]),
        kdf=KDFConfig(
            algorithm=raw["kdf"]["algorithm"],
            time_cost=int(raw["kdf"]["time_cost"]),
            memory_cost=int(raw["kdf"]["memory_cost"]),
            parallelism=int(raw["kdf"]["parallelism"]),
            hash_len=int(raw["kdf"]["hash_len"]),
            salt_b64=raw["kdf"]["salt_b64"],
        ),
        wrapping=WrappingConfig(
            algorithm=raw["wrapping"]["algorithm"],
            nonce_b64=raw["wrapping"]["nonce_b64"],
            wrapped_master_key_b64=raw["wrapping"]["wrapped_master_key_b64"],
        ),
    )


def vault_is_initialized(paths: AppPaths) -> bool:
    return paths.config_path.exists() and paths.db_path.exists()
