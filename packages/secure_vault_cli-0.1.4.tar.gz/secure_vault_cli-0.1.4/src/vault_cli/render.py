from __future__ import annotations

import json

from rich import box
from rich.table import Table

from vault_cli.models import Document, ListItem
from vault_cli.time_utils import to_utc_iso


def render_document_full(document: Document) -> str:
    tags = ", ".join(document.tags)
    return (
        f"ID: {document.id}\n"
        f"Title: {document.title}\n"
        f"Created At: {to_utc_iso(document.created_at)}\n"
        f"Updated At: {to_utc_iso(document.updated_at)}\n"
        f"Folder: {document.folder}\n"
        f"Tags: {tags}\n"
        "\n"
        f"{document.body}"
    ).rstrip()


def render_list_table(items: list[ListItem], *, verbose: bool) -> Table:
    table = Table(
        title=f"Documents ({len(items)})",
        box=box.SIMPLE_HEAVY,
        header_style="bold",
        row_styles=["none", "dim"],
    )
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Title", style="magenta")
    table.add_column("Updated At", style="green")
    if verbose:
        table.add_column("Folder", style="yellow")
        table.add_column("Tags", style="blue")
    for item in items:
        row = [item.id, item.title or "-", to_utc_iso(item.updated_at)]
        if verbose:
            row.extend([item.folder or "-", ", ".join(item.tags) or "-"])
        table.add_row(*row)
    return table


def render_list_json(items: list[ListItem]) -> str:
    payload = {
        "items": [
            {
                "id": item.id,
                "title": item.title,
                "updated_at": to_utc_iso(item.updated_at),
                "folder": item.folder,
                "tags": list(item.tags),
            }
            for item in items
        ]
    }
    return json.dumps(payload, indent=2)
