from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CommandSpec:
    name: str
    short: str
    usage: tuple[str, ...]
    description: str
    options: tuple[str, ...] = ()
    examples: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()
    security_notes: tuple[str, ...] = ()
    exit_codes: tuple[str, ...] = ()
    requires_unlock: bool = False


COMMAND_SPECS: dict[str, CommandSpec] = {
    "init": CommandSpec(
        name="init",
        short="Initialize a local encrypted vault.",
        usage=("init",),
        description="Create vault.json and vault.db, derive wrapping material from a master passphrase, and prepare the local vault.",
        notes=("Requires a TTY to capture the passphrase securely.",),
        exit_codes=("0 success", "2 invalid usage", "1 generic error"),
    ),
    "unlock": CommandSpec(
        name="unlock",
        short="Unlock the current interactive shell session.",
        usage=("unlock",),
        description="Verify the master passphrase and keep the master key only in the current process memory.",
        notes=("Running `vault unlock` enters the interactive shell in unlocked mode.",),
        exit_codes=("0 success", "2 invalid usage", "3 auth required", "1 generic error"),
    ),
    "lock": CommandSpec(
        name="lock",
        short="Lock the current session and drop in-memory keys.",
        usage=("lock",),
        description="Forget the in-memory session material so sensitive commands require unlocking again.",
        exit_codes=("0 success", "1 generic error"),
    ),
    "new": CommandSpec(
        name="new",
        short="Create a new encrypted document.",
        usage=("new ID", "new ID --template default", "new ID --template none"),
        description="Create a new document with a normalized unique ID and open the integrated editor.",
        options=("--template [default|none]  Choose the initial body template.",),
        security_notes=("IDs are normalized before storage and never persisted in cleartext.",),
        exit_codes=("0 success", "2 invalid usage", "3 auth required", "5 already exists"),
        requires_unlock=True,
    ),
    "edit": CommandSpec(
        name="edit",
        short="Edit an existing encrypted document.",
        usage=("edit ID", "edit ID --external-editor"),
        description="Edit the user-controlled fields of an existing document while preserving system-managed metadata.",
        options=("--external-editor  Opt in to an external editor with an explicit privacy warning.",),
        security_notes=("The built-in editor avoids plaintext temp files by default.",),
        exit_codes=("0 success", "3 auth required", "4 not found", "1 generic error"),
        requires_unlock=True,
    ),
    "view": CommandSpec(
        name="view",
        short="Render one document in a readable terminal view.",
        usage=("view ID",),
        description="Decrypt and display a document using the canonical full renderer shared with export and copy --full.",
        exit_codes=("0 success", "3 auth required", "4 not found"),
        requires_unlock=True,
    ),
    "list": CommandSpec(
        name="list",
        short="List documents from the local vault.",
        usage=("list", "list --verbose", "list --json"),
        description="Decrypt document payloads in memory to show IDs, titles, timestamps, and optional folder/tag metadata.",
        options=("--verbose  Include folder and tags.", "--json  Emit the stable JSON structure with root `items`."),
        security_notes=("v1 lists by decrypting in memory; no searchable metadata is stored in cleartext.",),
        exit_codes=("0 success", "3 auth required", "1 generic error"),
        requires_unlock=True,
    ),
    "delete": CommandSpec(
        name="delete",
        short="Delete one document from the vault.",
        usage=("delete ID", "delete ID --yes"),
        description="Remove one document after confirmation unless an explicit non-interactive confirmation flag is provided.",
        options=("--yes  Skip the confirmation prompt.",),
        exit_codes=("0 success", "3 auth required", "4 not found", "6 destructive action aborted"),
        requires_unlock=True,
    ),
    "export": CommandSpec(
        name="export",
        short="Export one decrypted document to a text file.",
        usage=("export ID PATH", "export ID PATH --body-only", "export ID PATH --force"),
        description="Write a decrypted render to a text file outside the encrypted perimeter.",
        options=("--body-only  Export only the body.", "--force  Overwrite an existing destination."),
        security_notes=("Export writes plaintext outside the encrypted vault perimeter.",),
        exit_codes=("0 success", "3 auth required", "4 not found", "6 destructive action aborted", "1 generic error"),
        requires_unlock=True,
    ),
    "copy": CommandSpec(
        name="copy",
        short="Copy document content to the clipboard.",
        usage=("copy ID", "copy ID --full"),
        description="Copy the body by default or the canonical full render when --full is used.",
        options=("--full  Copy the full canonical render.",),
        security_notes=("Clipboard contents are outside the encrypted perimeter and may remain visible to other local processes.",),
        exit_codes=("0 success", "3 auth required", "4 not found", "1 generic error"),
        requires_unlock=True,
    ),
    "purge": CommandSpec(
        name="purge",
        short="Cryptographically erase the vault at application level.",
        usage=("purge", "purge --yes"),
        description="Destroy the wrapped master key and remove app-managed storage, which prevents future decryption without promising forensic erasure.",
        options=("--yes  Skip the strong confirmation prompt.",),
        security_notes=("Purge is application-level cryptographic erase, not guaranteed physical media erasure.",),
        exit_codes=("0 success", "3 auth required", "6 destructive action aborted", "1 generic error"),
        requires_unlock=True,
    ),
    "help": CommandSpec(
        name="help",
        short="Show short command help.",
        usage=("help", "help COMMAND"),
        description="Show the shell command index or one short help entry backed by the command registry.",
        exit_codes=("0 success",),
    ),
    "man": CommandSpec(
        name="man",
        short="Show the integrated manual.",
        usage=("man", "man COMMAND"),
        description="Show the manual index or a detailed manual page generated from the same command registry as help.",
        exit_codes=("0 success",),
    ),
    "exit": CommandSpec(
        name="exit",
        short="Exit the interactive shell.",
        usage=("exit",),
        description="Close the interactive shell.",
        exit_codes=("0 success",),
    ),
}


def visible_command_specs() -> tuple[CommandSpec, ...]:
    ordered = (
        "init",
        "unlock",
        "lock",
        "new",
        "edit",
        "view",
        "list",
        "delete",
        "export",
        "copy",
        "purge",
        "help",
        "man",
        "exit",
    )
    return tuple(COMMAND_SPECS[name] for name in ordered)
