from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest
from cryptography.exceptions import InvalidTag

from vault_cli.crypto import AES_GCM_NONCE_SIZE, PAYLOAD_VERSION, compute_lookup_key, decrypt_document
from vault_cli.db import get_connection
from vault_cli.services import DocumentExistsError, DocumentNotFoundError, DocumentValidationError, VaultAuthError


def test_init_and_unlock_roundtrip(manager) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")

    assert len(session.master_key) == 32
    assert len(session.index_key) == 32


def test_unlock_rejects_wrong_passphrase(manager) -> None:
    manager.initialize("secret-pass")

    with pytest.raises(VaultAuthError):
        manager.unlock("wrong-pass")


def test_create_view_list_update_delete_document(manager) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")

    created, changed = manager.create_document(session, "Idea One", "default", body="hello")
    updated = manager.update_document(
        session,
        created.id,
        title="My Title",
        folder="projects",
        tags=["alpha", "beta"],
        body="updated body",
    )
    fetched = manager.get_document(session, "idea-one")
    listed = manager.list_documents(session)
    deleted = manager.delete_document(session, "idea-one")

    assert changed is True
    assert created.id == "idea-one"
    assert updated.created_at == created.created_at
    assert updated.updated_at >= created.updated_at
    assert fetched.title == "My Title"
    assert listed[0].id == "idea-one"
    assert deleted.id == "idea-one"
    with pytest.raises(DocumentNotFoundError):
        manager.get_document(session, "idea-one")


def test_duplicate_ids_collide_after_normalization(manager) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")

    manager.create_document(session, "My Idea", "none", body="")

    with pytest.raises(DocumentExistsError):
        manager.create_document(session, " my    idea ", "none", body="")


def test_rejects_invalid_ids(manager) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")

    with pytest.raises(DocumentValidationError):
        manager.create_document(session, "bad/id", "none", body="")

    with pytest.raises(DocumentValidationError):
        manager.create_document(session, "   ", "none", body="")


def test_list_filters_descifrar_in_memory(manager) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")
    first, _ = manager.create_document(session, "First", "none", body="a")
    second, _ = manager.create_document(session, "Second", "none", body="b")
    manager.update_document(session, first.id, title="One", folder="inbox", tags=["red"], body="a")
    manager.update_document(session, second.id, title="Two", folder="work", tags=["blue"], body="b")

    folder_items = manager.list_documents(session, folder="work")
    tag_items = manager.list_documents(session, tag="red")

    assert [item.id for item in folder_items] == ["second"]
    assert [item.id for item in tag_items] == ["first"]


def test_lookup_and_payload_are_not_stored_in_cleartext(manager, app_paths) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")
    manager.create_document(session, "secret-doc", "none", body="top secret body")
    manager.update_document(session, "secret-doc", title="Top Secret", folder="vault", tags=["private"], body="top secret body")

    db_bytes = app_paths.db_path.read_bytes()
    config_text = app_paths.config_path.read_text(encoding="utf-8")

    assert b"secret-doc" not in db_bytes
    assert b"Top Secret" not in db_bytes
    assert "secret-pass" not in config_text


def test_lookup_key_matches_hmac_sha256(manager, app_paths) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")
    manager.create_document(session, "lookup-doc", "none", body="x")

    connection = get_connection(app_paths)
    try:
        row = connection.execute("SELECT lookup_key, payload_version, encrypted_payload FROM documents").fetchone()
    finally:
        connection.close()

    assert row["lookup_key"] == compute_lookup_key(session.index_key, "lookup-doc")
    assert len(row["lookup_key"]) == 32
    assert row["payload_version"] == PAYLOAD_VERSION
    assert len(row["encrypted_payload"][:AES_GCM_NONCE_SIZE]) == AES_GCM_NONCE_SIZE


def test_aad_changes_break_decryption(manager, app_paths) -> None:
    manager.initialize("secret-pass")
    session = manager.unlock("secret-pass")
    manager.create_document(session, "aad-doc", "none", body="x")

    connection = sqlite3.connect(app_paths.db_path)
    connection.row_factory = sqlite3.Row
    row = connection.execute("SELECT payload_version, encrypted_payload FROM documents").fetchone()
    connection.close()

    with pytest.raises(InvalidTag):
        decrypt_document(session, int(row["payload_version"]) + 1, row["encrypted_payload"])
