from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from vault_cli import cli
from vault_cli.editor import EditorResult
from vault_cli.exit_codes import ABORTED, ALREADY_EXISTS, INVALID_USAGE, LOCKED, NOT_FOUND
from vault_cli.services import VaultManager

runner = CliRunner()


def _init_vault(monkeypatch, cli_env: dict[str, str]) -> None:
    for key, value in cli_env.items():
        monkeypatch.setenv(key, value)
    monkeypatch.setattr(cli, "is_tty_available", lambda: True)
    answers = iter(["secret-pass", "secret-pass"])
    monkeypatch.setattr(cli, "prompt_passphrase", lambda label="Passphrase": next(answers))
    result = runner.invoke(cli.app, ["init"], env=cli_env)
    assert result.exit_code == 0


def _unlock_for_direct(monkeypatch, cli_env: dict[str, str]) -> None:
    for key, value in cli_env.items():
        monkeypatch.setenv(key, value)
    monkeypatch.setattr(cli, "is_tty_available", lambda: True)
    monkeypatch.setattr(cli, "prompt_passphrase", lambda label="Passphrase": "secret-pass")


def test_init_requires_tty(cli_env, monkeypatch) -> None:
    monkeypatch.setattr(cli, "is_tty_available", lambda: False)
    result = runner.invoke(cli.app, ["init"], env=cli_env)
    assert result.exit_code == INVALID_USAGE


def test_locked_non_interactive_command_fails_with_code_3(cli_env, monkeypatch) -> None:
    _init_vault(monkeypatch, cli_env)
    monkeypatch.setattr(cli, "is_tty_available", lambda: False)
    result = runner.invoke(cli.app, ["list"], env=cli_env)
    assert result.exit_code == LOCKED


def test_new_view_list_delete_flow(cli_env, monkeypatch) -> None:
    _init_vault(monkeypatch, cli_env)
    _unlock_for_direct(monkeypatch, cli_env)
    monkeypatch.setattr(
        cli,
        "run_integrated_editor",
        lambda document: EditorResult(title="My Title", folder="inbox", tags=("red",), body="Body text"),
    )

    create = runner.invoke(cli.app, ["new", "My Doc", "--template", "none"], env=cli_env)
    view = runner.invoke(cli.app, ["view", "my-doc"], env=cli_env)
    listing = runner.invoke(cli.app, ["list"], env=cli_env)
    verbose = runner.invoke(cli.app, ["list", "--verbose"], env=cli_env)
    listing_json = runner.invoke(cli.app, ["list", "--json"], env=cli_env)
    delete = runner.invoke(cli.app, ["delete", "my-doc", "--yes"], env=cli_env)

    assert create.exit_code == 0
    assert "Normalized document ID" in create.stdout
    assert view.exit_code == 0
    assert "ID: my-doc" in view.stdout
    assert "Title: My Title" in view.stdout
    assert listing.exit_code == 0
    assert "Documents" in listing.stdout
    assert verbose.exit_code == 0
    assert "inbox" in verbose.stdout
    assert delete.exit_code == 0
    assert "Deleted document" in delete.stdout

    payload = json.loads(listing_json.stdout)
    assert list(payload.keys()) == ["items"]
    assert payload["items"][0]["id"] == "my-doc"
    assert payload["items"][0]["title"] == "My Title"
    assert payload["items"][0]["folder"] == "inbox"
    assert payload["items"][0]["tags"] == ["red"]
    assert payload["items"][0]["updated_at"].endswith("Z")


def test_duplicate_id_returns_code_5(cli_env, monkeypatch) -> None:
    _init_vault(monkeypatch, cli_env)
    _unlock_for_direct(monkeypatch, cli_env)
    monkeypatch.setattr(
        cli,
        "run_integrated_editor",
        lambda document: EditorResult(title="", folder="inbox", tags=(), body="Body"),
    )

    first = runner.invoke(cli.app, ["new", "Dup ID", "--template", "none"], env=cli_env)
    second = runner.invoke(cli.app, ["new", "dup   id", "--template", "none"], env=cli_env)

    assert first.exit_code == 0
    assert second.exit_code == ALREADY_EXISTS


def test_edit_updates_updated_at_and_preserves_created_at(cli_env, monkeypatch) -> None:
    _init_vault(monkeypatch, cli_env)
    _unlock_for_direct(monkeypatch, cli_env)
    first_result = EditorResult(title="A", folder="inbox", tags=("x",), body="first")
    second_result = EditorResult(title="B", folder="work", tags=("y",), body="second")
    monkeypatch.setattr(cli, "run_integrated_editor", lambda document: first_result)
    assert runner.invoke(cli.app, ["new", "edit-doc", "--template", "none"], env=cli_env).exit_code == 0

    manager = VaultManager()
    session = manager.unlock("secret-pass")
    original = manager.get_document(session, "edit-doc")

    monkeypatch.setattr(cli, "run_integrated_editor", lambda document: second_result)
    edit = runner.invoke(cli.app, ["edit", "edit-doc"], env=cli_env)
    updated = manager.get_document(session, "edit-doc")

    assert edit.exit_code == 0
    assert updated.created_at == original.created_at
    assert updated.updated_at >= original.updated_at
    assert updated.title == "B"
    assert updated.folder == "work"
    assert updated.body == "second"


def test_export_and_copy_behaviour(cli_env, monkeypatch, app_home: Path) -> None:
    _init_vault(monkeypatch, cli_env)
    _unlock_for_direct(monkeypatch, cli_env)
    monkeypatch.setattr(
        cli,
        "run_integrated_editor",
        lambda document: EditorResult(title="Exported", folder="docs", tags=("t",), body="Body only"),
    )
    assert runner.invoke(cli.app, ["new", "export-doc", "--template", "none"], env=cli_env).exit_code == 0

    exported = app_home / "exported.txt"
    exported_body = app_home / "exported-body.txt"
    captured: list[str] = []

    monkeypatch.setattr("vault_cli.clipboard.copy_text", lambda value: captured.append(value))

    export_full = runner.invoke(cli.app, ["export", "export-doc", str(exported)], env=cli_env)
    export_body = runner.invoke(cli.app, ["export", "export-doc", str(exported_body), "--body-only"], env=cli_env)
    copy_body = runner.invoke(cli.app, ["copy", "export-doc"], env=cli_env)
    copy_full = runner.invoke(cli.app, ["copy", "export-doc", "--full"], env=cli_env)
    overwrite = runner.invoke(cli.app, ["export", "export-doc", str(exported)], env=cli_env)

    assert export_full.exit_code == 0
    assert export_body.exit_code == 0
    assert copy_body.exit_code == 0
    assert copy_full.exit_code == 0
    assert "ID: export-doc" in exported.read_text(encoding="utf-8")
    assert exported_body.read_text(encoding="utf-8") == "Body only"
    assert captured[0] == "Body only"
    assert captured[1].startswith("ID: export-doc")
    assert overwrite.exit_code == ABORTED


def test_purge_and_abort(cli_env, monkeypatch) -> None:
    _init_vault(monkeypatch, cli_env)
    _unlock_for_direct(monkeypatch, cli_env)
    monkeypatch.setattr(cli, "_confirm", lambda prompt_text: False)
    aborted = runner.invoke(cli.app, ["purge"], env=cli_env)
    assert aborted.exit_code == ABORTED

    purged = runner.invoke(cli.app, ["purge", "--yes"], env=cli_env)
    assert purged.exit_code == 0


def test_shell_does_not_persist_history(cli_env, monkeypatch, app_paths) -> None:
    for key, value in cli_env.items():
        monkeypatch.setenv(key, value)
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: False)
    monkeypatch.setattr(cli.sys.stdout, "isatty", lambda: False)
    result = runner.invoke(cli.app, ["shell"], input="help\nq\n", env=cli_env)

    assert result.exit_code == 0
    assert not any(app_paths.state_dir.iterdir()) if app_paths.state_dir.exists() else True


def test_shell_prompt_reflects_locked_state() -> None:
    assert cli._shell_prompt_text(cli.ShellState()) == "vault[locked]> "
    assert cli._shell_prompt_text(cli.ShellState(session=object())) == "vault> "


def test_autocomplete_ids_only_when_unlocked(cli_env, monkeypatch) -> None:
    prompt_toolkit = pytest.importorskip("prompt_toolkit.document")
    _init_vault(monkeypatch, cli_env)
    _unlock_for_direct(monkeypatch, cli_env)
    monkeypatch.setattr(
        cli,
        "run_integrated_editor",
        lambda document: EditorResult(title="", folder="inbox", tags=(), body="Body"),
    )
    assert runner.invoke(cli.app, ["new", "complete-me", "--template", "none"], env=cli_env).exit_code == 0

    locked_state = cli.ShellState()
    unlocked_state = cli.ShellState(session=VaultManager().unlock("secret-pass"))
    completer_locked = cli.CommandCompleter(lambda: locked_state)
    completer_unlocked = cli.CommandCompleter(lambda: unlocked_state)

    locked = list(completer_locked.get_completions(prompt_toolkit.Document(text="view co", cursor_position=7), None))
    unlocked = list(completer_unlocked.get_completions(prompt_toolkit.Document(text="view co", cursor_position=7), None))

    assert not any(item.text == "complete-me" for item in locked)
    assert any(item.text == "complete-me" for item in unlocked)


def test_autocomplete_suggests_commands_help_topics_and_options(cli_env, monkeypatch) -> None:
    prompt_toolkit = pytest.importorskip("prompt_toolkit.document")
    _init_vault(monkeypatch, cli_env)
    completer = cli.CommandCompleter(lambda: cli.ShellState())

    command_hits = list(completer.get_completions(prompt_toolkit.Document(text="he", cursor_position=2), None))
    help_hits = list(completer.get_completions(prompt_toolkit.Document(text="help l", cursor_position=6), None))
    list_option_hits = list(completer.get_completions(prompt_toolkit.Document(text="list --v", cursor_position=8), None))
    template_hits = list(
        completer.get_completions(prompt_toolkit.Document(text="new draft --template d", cursor_position=22), None)
    )

    assert any(item.text == "help" for item in command_hits)
    assert any(item.text == "list" for item in help_hits)
    assert any(item.text == "--verbose" for item in list_option_hits)
    assert any(item.text == "default" for item in template_hits)


def test_not_found_exit_code(cli_env, monkeypatch) -> None:
    _init_vault(monkeypatch, cli_env)
    _unlock_for_direct(monkeypatch, cli_env)
    result = runner.invoke(cli.app, ["view", "missing"], env=cli_env)
    assert result.exit_code == NOT_FOUND
