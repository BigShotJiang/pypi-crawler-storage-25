from __future__ import annotations

from typer.testing import CliRunner

from vault_cli import cli
from vault_cli.command_docs import COMMAND_SPECS, visible_command_specs

runner = CliRunner()


def test_help_index_contains_visible_commands() -> None:
    result = runner.invoke(cli.app, ["help"])
    assert result.exit_code == 0
    for spec in visible_command_specs():
        assert spec.name in result.stdout
        assert spec.short in result.stdout


def test_man_page_contains_help_short_text() -> None:
    for name, spec in COMMAND_SPECS.items():
        result = runner.invoke(cli.app, ["man", name])
        assert result.exit_code == 0
        assert spec.short in result.stdout
        assert "USAGE" in result.stdout
        assert "DESCRIPTION" in result.stdout


def test_shell_help_and_man_use_same_registry() -> None:
    help_result = runner.invoke(cli.app, ["help", "list"])
    man_result = runner.invoke(cli.app, ["man", "list"])
    assert help_result.exit_code == 0
    assert man_result.exit_code == 0
    assert COMMAND_SPECS["list"].short in help_result.stdout
    assert COMMAND_SPECS["list"].short in man_result.stdout
