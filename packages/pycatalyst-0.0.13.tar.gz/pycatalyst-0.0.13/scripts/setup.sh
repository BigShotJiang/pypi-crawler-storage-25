#!/bin/bash
################################################################################
# Setup script for PyCatalyst development environment
#
# Creates venv, installs dev dependencies, optional API deps, Jupyter kernel,
# and pre-commit hooks. Run from the repo root (script cds to repo root):
#   ./scripts/setup.sh
#   bash /path/to/pycatalyst/scripts/setup.sh
################################################################################

set -euo pipefail

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info() { echo -e "${BLUE}ℹ${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }
warning() { echo -e "${YELLOW}⚠${NC} $1"; }
error() { echo -e "${RED}✗${NC} $1" >&2; }

################################################################################
# Script directory and repo root
################################################################################
SCRIPT_DIR=$(cd -- "$(dirname "${BASH_SOURCE[0]:-.}")" &>/dev/null && pwd)
REPO_ROOT=$(cd "$SCRIPT_DIR/.." && pwd)
cd "$REPO_ROOT" || exit 1

# Check if Python 3 is available
if ! command -v python3 &> /dev/null; then
    error "Python 3 is not installed. Please install Python 3.11 or higher."
    exit 1
fi

# Check Python version (requires 3.11+)
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
    error "Python 3.11 or higher is required. Found: $PYTHON_VERSION"
    exit 1
fi

info "Python version: $PYTHON_VERSION"
echo ""

# Recreate venv if the repo was moved: bin/activate embeds the old absolute path (PATH won't include this venv).
WANT_VENV="$(cd "$REPO_ROOT" && pwd -P)/venv"
if [ -f venv/bin/activate ]; then
    GOT_VENV=$(grep -m1 'export VIRTUAL_ENV=/' venv/bin/activate | sed 's/.*export VIRTUAL_ENV=//; s/\r//' || true)
    if [ -n "${GOT_VENV:-}" ] && [ "$GOT_VENV" != "$WANT_VENV" ]; then
        info "Removing virtual environment (was created at $GOT_VENV; expected $WANT_VENV)..."
        rm -rf venv
    fi
fi

# Create virtual environment (or recreate if broken, e.g. missing venv/bin/activate)
if [ ! -d "venv" ] || [ ! -f "venv/bin/activate" ]; then
    if [ -d "venv" ]; then
        info "Removing broken or incomplete virtual environment..."
        rm -rf venv
    fi
    info "Creating virtual environment..."
    python3 -m venv venv
    success "Virtual environment created"
else
    success "Virtual environment already exists"
fi

VENV_PY="$REPO_ROOT/venv/bin/python"
if [ ! -x "$VENV_PY" ]; then
    error "venv interpreter missing or not executable: $VENV_PY"
    exit 1
fi
info "Using virtualenv: $VENV_PY"

# Upgrade pip, setuptools, wheel
info "Upgrading pip, setuptools, and wheel..."
"$VENV_PY" -m pip install --upgrade pip setuptools wheel --quiet

# Install package in development mode (with dev + kafka + rabbitmq so tests pass)
info "Installing PyCatalyst in development mode..."
if "$VENV_PY" -m pip install -e ".[dev,kafka,rabbitmq]" --quiet; then
    success "PyCatalyst installed with dev, kafka, and rabbitmq dependencies"
else
    error "Failed to install PyCatalyst. Check the error messages above."
    exit 1
fi

# Install API dependencies if requested or if API exists (src layout)
if [ -d "src/pycatalyst/api" ]; then
    info "Installing API dependencies (required for API server)..."
    if "$VENV_PY" -m pip install -e ".[api]" --quiet; then
        success "API dependencies installed"
    else
        warning "Failed to install API dependencies. API server may not work."
    fi
    # ML deps (torch, sklearn, etc.) so Model Training UI experiments can run
    if [ -d "src/pycatalyst/ml" ]; then
        info "Installing ML dependencies (required for Model Training experiments)..."
        if "$VENV_PY" -m pip install -e ".[ml-sklearn]" --quiet 2>/dev/null; then
            success "ML dependencies (sklearn + PyTorch) installed"
        else
            warning "ML install failed or skipped. Install manually: $VENV_PY -m pip install -e \".[ml-sklearn]\""
        fi
    fi
fi

# Pre-commit hooks
if "$VENV_PY" -c "import pre_commit" 2>/dev/null; then
    info "Installing pre-commit hooks..."
    "$VENV_PY" -m pre_commit install
    "$VENV_PY" -m pre_commit install --hook-type pre-push
    success "Pre-commit hooks installed."
else
    warning "pre-commit not installed in venv. Add it to [dev] extras and re-run setup."
fi

# Create Jupyter kernel for this environment
# Note: Jupyter Lab and ipykernel are already installed via dev dependencies
KERNEL_NAME="pycatalyst-dev"
KERNEL_DISPLAY_NAME="Python (pycatalyst-dev)"

info "Setting up Jupyter kernel..."
# Remove existing kernel if it exists (ignore errors)
"$VENV_PY" -m jupyter kernelspec remove "$KERNEL_NAME" --quiet 2>/dev/null || true

# Create new kernel
if "$VENV_PY" -m ipykernel install --user --name="$KERNEL_NAME" --display-name="$KERNEL_DISPLAY_NAME" 2>/dev/null; then
    success "Jupyter kernel '$KERNEL_DISPLAY_NAME' created"
else
    warning "Failed to create Jupyter kernel. You can create it manually later."
fi

echo ""
success "Setup complete!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📋 Quick Start"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "To activate the environment:"
echo "  source venv/bin/activate"
echo ""
echo "To start development servers:"
echo "  pycatalyst api    # Start API server (http://localhost:8005)"
echo "  pycatalyst ui dev  # Start UI dev server"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📓 Jupyter Lab"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "To start Jupyter Lab:"
echo "  1. Activate the environment: source venv/bin/activate"
echo "  2. Start Jupyter Lab: jupyter lab"
echo "  3. Select kernel: '$KERNEL_DISPLAY_NAME'"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🧪 Testing"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Run tests:"
echo "  pytest"
echo ""
echo "Run tests with coverage:"
echo "  pytest --cov=pycatalyst"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "💡 Development Tips"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "• Package is installed in editable mode (-e), so code changes are"
echo "  reflected immediately (restart kernel/server to see changes)"
echo ""
echo "• To verify the kernel is using the right environment, run in a notebook:"
echo "  import sys; print(sys.executable)"
echo ""
echo "• To list all available kernels:"
echo "  jupyter kernelspec list"
echo ""
echo "• Linux: if 'pycatalyst ui dev' fails with 'OS file watch limit reached', run once:"
echo "  ./scripts/ensure-inotify-limit.sh"
echo ""
