"""Unified architecture and backend discovery across all ML engines.

Provides top-level functions for listing available backends and their
architectures without requiring all dependencies to be installed::

    from pycatalyst.ml.registry import list_backends, list_architectures

    backends = list_backends()           # ['sklearn']
    archs = list_architectures()         # {'sklearn': ['knn', 'lasso', ...]}
    sklearn_archs = list_architectures("sklearn")  # {'sklearn': [...]}
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def list_backends() -> list[str]:
    """List backends whose dependencies are installed.

    Returns:
        Sorted list of available backend name strings.
    """
    available: list[str] = []

    try:
        import sklearn  # noqa: F401

        available.append("sklearn")
    except ImportError:
        pass

    try:
        import torch  # noqa: F401

        available.append("pytorch")
    except ImportError:
        pass

    try:
        import transformers  # noqa: F401

        available.append("huggingface")
    except ImportError:
        pass

    return sorted(available)


def list_architectures(
    backend: str | None = None,
) -> dict[str, list[str]]:
    """List available architectures per backend.

    Args:
        backend: If given, only list architectures for that backend.
            Must be one of ``"sklearn"``, ``"pytorch"``, ``"huggingface"``.
            If ``None``, list all installed backends.

    Returns:
        Dict mapping backend name to sorted list of architecture names.

    Raises:
        ValueError: If an unknown *backend* is specified.
    """
    result: dict[str, list[str]] = {}
    valid = {"sklearn", "pytorch", "huggingface"}

    if backend is not None and backend not in valid:
        raise ValueError(
            f"Unknown backend {backend!r}. Must be one of: {sorted(valid)}"
        )

    targets = [backend] if backend else list_backends()

    for name in targets:
        if name == "sklearn":
            result["sklearn"] = _sklearn_architectures()
        elif name == "pytorch":
            result["pytorch"] = _pytorch_architectures()
        elif name == "huggingface":
            # HuggingFace uses model identifiers, not a fixed registry
            result["huggingface"] = []

    return result


def _sklearn_architectures() -> list[str]:
    """Get sklearn architectures from engine registry."""
    try:
        from pycatalyst.ml.sklearn.engine import list_architectures

        return list_architectures()
    except ImportError:
        logger.debug("sklearn not available")
        return []


def _pytorch_architectures() -> list[str]:
    """Get pytorch architectures from model registry."""
    try:
        from pycatalyst.ml.pytorch.models.registry import MODEL_REGISTRY

        return sorted(MODEL_REGISTRY.keys())
    except ImportError:
        logger.debug("pytorch not available")
        return []
