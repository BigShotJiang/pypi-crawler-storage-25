"""Pydantic configuration for PyTorch experiments.

Every field relevant to a PyTorch training run is defined here.  The config
is validated eagerly so that misconfiguration fails fast before any data
loading or GPU allocation.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

# ---------------------------------------------------------------------------
# Section models
# ---------------------------------------------------------------------------


class ExperimentSection(BaseModel):
    name: str = Field(..., min_length=1)
    seed: int = Field(default=42, ge=0)
    backend: Literal["pytorch"] = "pytorch"
    output_dir: str = Field(default="./runs/experiment")


class SplitConfig(BaseModel):
    strategy: Literal["temporal", "holdout"] = "temporal"
    train: float = Field(default=0.7, gt=0, lt=1)
    val: float = Field(default=0.15, gt=0, lt=1)
    test: float = Field(default=0.15, gt=0, lt=1)

    @model_validator(mode="after")
    def _ratios_sum_to_one(self) -> SplitConfig:
        total = self.train + self.val + self.test
        if abs(total - 1.0) > 1e-6:
            raise ValueError(
                f"Split ratios must sum to 1.0, got {total:.4f} "
                f"(train={self.train}, val={self.val}, test={self.test})"
            )
        return self


class PanelConfig(BaseModel):
    """Panel (multi-symbol) data source configuration."""

    directory: str | None = Field(
        default=None,
        description="Directory of per-symbol Parquet files",
    )
    pattern: str = Field(
        default="*.parquet",
        description="Glob pattern for files within directory",
    )
    symbol_column: str | None = Field(
        default=None,
        description="Column to group by when using a single file",
    )
    sort_column: str = Field(
        default="timestamp",
        description="Column to sort each symbol by chronologically",
    )


class DataSection(BaseModel):
    source: Literal["local", "s3"] = "local"
    path: str | None = Field(
        default=None,
        description="Path to data file (required for format='single')",
    )
    target: str = Field(..., min_length=1)
    features: list[str] | None = Field(
        default=None,
        description="Explicit feature columns; null = all non-target columns",
    )
    split: SplitConfig = Field(default_factory=SplitConfig)
    scaler: Literal["minmax", "standard", "robust", "none"] = "minmax"
    sequence_length: int = Field(default=60, ge=1)
    stride: int = Field(default=1, ge=1)

    format: Literal["single", "panel"] = Field(
        default="single",
        description="'single' for one file, 'panel' for multi-symbol",
    )
    panel: PanelConfig | None = Field(
        default=None,
        description="Panel data source config (required when format='panel')",
    )
    scale_per_symbol: bool = Field(
        default=True,
        description="Fit separate scalers per symbol (panel mode)",
    )
    training_mode: Literal["shared", "per_symbol"] = Field(
        default="shared",
        description="'shared' trains one model on all symbols; "
        "'per_symbol' trains one model per symbol",
    )
    num_workers: int = Field(default=0, ge=0, description="DataLoader workers")
    pin_memory: bool = Field(default=False, description="Pin memory for CUDA")

    @model_validator(mode="after")
    def _validate_data_source(self) -> DataSection:
        if self.format == "single" and not self.path:
            raise ValueError("data.path is required when format='single'")
        if self.format == "panel" and self.panel is None:
            raise ValueError("data.panel section is required when format='panel'")
        return self


class ModelSection(BaseModel):
    architecture: str = Field(..., min_length=1)
    params: dict[str, Any] = Field(default_factory=dict)

    @field_validator("params")
    @classmethod
    def _validate_dropout(cls, v: dict[str, Any]) -> dict[str, Any]:
        if "dropout" in v:
            d = v["dropout"]
            if not (0 <= d <= 1):
                raise ValueError(f"dropout must be in [0, 1], got {d}")
        return v


class EarlyStoppingConfig(BaseModel):
    patience: int = Field(default=10, ge=1)
    metric: str = "val_loss"
    mode: Literal["min", "max"] = "min"


class CheckpointConfig(BaseModel):
    metric: str = "val_loss"
    save_best_only: bool = True


class TrainingSection(BaseModel):
    epochs: int = Field(default=100, ge=1)
    batch_size: int = Field(default=32, ge=1)
    learning_rate: float = Field(default=1e-3, gt=0)
    optimizer: Literal["adam", "adamw", "sgd"] = "adam"
    scheduler: Literal["cosine", "step", "plateau"] | None = None
    gradient_clip: float = Field(default=1.0, ge=0)
    early_stopping: EarlyStoppingConfig = Field(
        default_factory=EarlyStoppingConfig,
    )
    checkpoint: CheckpointConfig = Field(default_factory=CheckpointConfig)
    log_dir: str | None = None

    mixed_precision: bool = Field(
        default=False,
        description="Enable torch.amp mixed precision training (fp16/bf16)",
    )
    gradient_accumulation_steps: int = Field(
        default=1,
        ge=1,
        description="Accumulate gradients over N batches before stepping",
    )
    loss: Literal["mse", "mae", "huber", "smooth_l1"] = Field(
        default="mse",
        description="Loss function for training",
    )
    resume_from: str | None = Field(
        default=None,
        description="Path to checkpoint.pt to resume training from",
    )


class EvaluationSection(BaseModel):
    metrics: list[str] = Field(
        default=["mse", "mae"],
        min_length=1,
    )
    plots: list[str] = Field(default=["predicted_vs_actual", "loss_curves"])


class ServingSection(BaseModel):
    jit_export: bool = False


# ---------------------------------------------------------------------------
# Top-level config
# ---------------------------------------------------------------------------


class PytorchExperimentConfig(BaseModel):
    """Complete PyTorch experiment configuration."""

    experiment: ExperimentSection
    data: DataSection
    model: ModelSection
    training: TrainingSection = Field(default_factory=TrainingSection)
    evaluation: EvaluationSection = Field(default_factory=EvaluationSection)
    serving: ServingSection = Field(default_factory=ServingSection)

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> PytorchExperimentConfig:
        """Construct from a raw dict (parsed YAML)."""
        return cls.model_validate(raw)

    @classmethod
    def from_yaml(cls, path: str) -> PytorchExperimentConfig:
        """Load from a YAML file path."""
        from pathlib import Path

        import yaml

        text = Path(path).read_text(encoding="utf-8")
        raw = yaml.safe_load(text)
        return cls.from_raw(raw)
