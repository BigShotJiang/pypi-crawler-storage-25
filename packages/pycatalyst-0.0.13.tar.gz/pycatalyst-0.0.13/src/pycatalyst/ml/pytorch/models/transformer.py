"""Transformer encoder model for time-series forecasting."""

from __future__ import annotations

import math

import torch
import torch.nn as nn

from pycatalyst.ml.pytorch.models.base import TorchModel


class _PositionalEncoding(nn.Module):
    """Sinusoidal positional encoding. Computes for the exact sequence length of the input."""

    def __init__(self, d_model: int, max_len: int = 5000) -> None:
        super().__init__()
        self.d_model = d_model
        self._max_len = max_len

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, d_model); need (1, seq_len, d_model) to add
        batch, seq_len, feat_dim = x.shape
        device = x.device
        dtype = x.dtype
        # Always compute pe for exact input shape to avoid buffer/slice mismatches
        position = torch.arange(seq_len, device=device, dtype=dtype).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, feat_dim, 2, device=device, dtype=dtype)
            * (-math.log(10000.0) / feat_dim)
        )
        pe = torch.zeros(seq_len, feat_dim, device=device, dtype=dtype)
        pe[:, 0::2] = torch.sin(position * div_term)
        if feat_dim > 1:
            pe[:, 1::2] = torch.cos(position * div_term[: feat_dim // 2])
        return x + pe.unsqueeze(0)


class TransformerModel(TorchModel):
    """Transformer encoder with positional encoding for time-series."""

    architecture = "transformer"

    def __init__(
        self,
        *,
        input_size: int,
        hidden_size: int = 64,
        num_layers: int = 2,
        attention_heads: int = 4,
        dropout: float = 0.1,
        output_size: int = 1,
    ) -> None:
        super().__init__(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            attention_heads=attention_heads,
            dropout=dropout,
            output_size=output_size,
        )
        self.input_proj = nn.Linear(input_size, hidden_size)
        self.pos_enc = _PositionalEncoding(hidden_size)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_size,
            nhead=attention_heads,
            dim_feedforward=hidden_size * 4,
            dropout=dropout,
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, input_size)
        out = self.input_proj(x)
        out = self.pos_enc(out)
        out = self.encoder(out)
        return self.fc(out[:, -1, :])
