"""Temporal Convolutional Network (TCN) for time-series forecasting."""

from __future__ import annotations

import torch
import torch.nn as nn

from pycatalyst.ml.pytorch.models.base import TorchModel


class _CausalConv1dBlock(nn.Module):
    """Single causal convolution block with residual connection."""

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        dilation: int,
        dropout: float,
    ) -> None:
        super().__init__()
        padding = (kernel_size - 1) * dilation
        self.conv1 = nn.Conv1d(
            in_channels,
            out_channels,
            kernel_size,
            padding=padding,
            dilation=dilation,
        )
        self.conv2 = nn.Conv1d(
            out_channels,
            out_channels,
            kernel_size,
            padding=padding,
            dilation=dilation,
        )
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.trim1 = padding
        self.trim2 = padding
        self.residual = (
            nn.Conv1d(in_channels, out_channels, 1)
            if in_channels != out_channels
            else nn.Identity()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.dropout(self.relu(self.conv1(x)))
        if self.trim1 > 0:
            out = out[:, :, : -self.trim1]
        out = self.dropout(self.relu(self.conv2(out)))
        if self.trim2 > 0:
            out = out[:, :, : -self.trim2]
        return self.relu(out + self.residual(x))


class TCNModel(TorchModel):
    """Temporal Convolutional Network with stacked causal dilated convolutions."""

    architecture = "tcn"

    def __init__(
        self,
        *,
        input_size: int,
        hidden_size: int = 64,
        num_layers: int = 4,
        kernel_size: int = 3,
        dropout: float = 0.0,
        output_size: int = 1,
    ) -> None:
        super().__init__(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            kernel_size=kernel_size,
            dropout=dropout,
            output_size=output_size,
        )
        layers: list[nn.Module] = []
        in_ch = input_size
        for i in range(num_layers):
            dilation = 2**i
            layers.append(
                _CausalConv1dBlock(in_ch, hidden_size, kernel_size, dilation, dropout)
            )
            in_ch = hidden_size

        self.network = nn.Sequential(*layers)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, features) -> conv expects (batch, features, seq_len)
        out = self.network(x.transpose(1, 2))
        return self.fc(out[:, :, -1])
