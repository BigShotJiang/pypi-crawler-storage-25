"""Multi-layer perceptron for tabular regression / classification."""

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from pycatalyst.ml.pytorch.models.base import TorchModel


def _normalize_hidden_sizes(
    hidden_sizes: list[int] | None = None,
    hidden_size: int | None = None,
    num_layers: int | None = None,
) -> list[int]:
    """Return a list of hidden layer sizes from either hidden_sizes or hidden_size/num_layers."""
    if hidden_sizes is not None and len(hidden_sizes) > 0:
        return list(hidden_sizes)
    size = hidden_size if hidden_size is not None else 128
    layers = num_layers if num_layers is not None else 3
    return [size] * (layers - 1)  # e.g. 3 layers -> [128, 128] then output


class MLPModel(TorchModel):
    """Simple feed-forward MLP for tabular data.

    Accepts either:
      - hidden_sizes: list of ints (e.g. [64, 32]) for variable-width layers
      - hidden_size + num_layers: uniform hidden layers (e.g. 128, 3)
    """

    architecture = "mlp"

    def __init__(
        self,
        *,
        input_size: int,
        hidden_sizes: list[int] | None = None,
        hidden_size: int = 128,
        num_layers: int = 3,
        dropout: float = 0.0,
        output_size: int = 1,
    ) -> None:
        sizes = _normalize_hidden_sizes(hidden_sizes, hidden_size, num_layers)
        # Persist for save/load: store hidden_sizes so reload reproduces same architecture
        base_kw: dict[str, Any] = {
            "input_size": input_size,
            "hidden_size": sizes[0] if sizes else 128,
            "num_layers": len(sizes) + 1,
            "dropout": dropout,
            "output_size": output_size,
        }
        if hidden_sizes is not None and len(hidden_sizes) > 0:
            base_kw["hidden_sizes"] = list(hidden_sizes)
        super().__init__(**base_kw)
        layers_list: list[nn.Module] = []
        in_dim = input_size
        for dim in sizes:
            layers_list.extend(
                [
                    nn.Linear(in_dim, dim),
                    nn.ReLU(),
                    nn.Dropout(dropout),
                ]
            )
            in_dim = dim
        layers_list.append(nn.Linear(in_dim, output_size))
        self.net = nn.Sequential(*layers_list)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)
