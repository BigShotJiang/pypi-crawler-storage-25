"""LSTM model for time-series forecasting."""

from __future__ import annotations

import torch
import torch.nn as nn

from pycatalyst.ml.pytorch.models.base import TorchModel


class LSTMModel(TorchModel):
    """Multi-layer LSTM with a fully-connected output head."""

    architecture = "lstm"

    def __init__(
        self,
        *,
        input_size: int,
        hidden_size: int = 128,
        num_layers: int = 2,
        dropout: float = 0.0,
        output_size: int = 1,
    ) -> None:
        super().__init__(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout,
            output_size=output_size,
        )
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0.0,
            batch_first=True,
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, input_size)
        out, _ = self.lstm(x)
        return self.fc(out[:, -1, :])  # last time-step
