"""Base class for all PyTorch models in the engine.

Adds ``save`` / ``load`` / ``get_config`` on top of ``nn.Module`` so the
serving layer can reconstruct a model from config + weights alone.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn


class TorchModel(nn.Module):
    """Abstract base for engine-managed PyTorch models.

    Subclasses must set ``architecture`` and implement ``forward``.
    Constructor kwargs are stored as ``_model_params`` so they can be
    persisted alongside the weights.
    """

    architecture: str = ""

    def __init__(self, *, input_size: int, **kwargs: Any) -> None:
        super().__init__()
        self._model_params: dict[str, Any] = {"input_size": input_size, **kwargs}

    def get_config(self) -> dict[str, Any]:
        return {
            "architecture": self.architecture,
            **self._model_params,
        }

    def save(self, directory: str | Path) -> dict[str, str]:
        """Persist weights and config; return artifact paths."""
        d = Path(directory)
        d.mkdir(parents=True, exist_ok=True)

        weights_path = d / "model.pt"
        config_path = d / "model_config.json"

        torch.save(self.state_dict(), weights_path)
        config_path.write_text(
            json.dumps(self.get_config(), indent=2),
            encoding="utf-8",
        )

        return {
            "weights": str(weights_path),
            "config": str(config_path),
        }

    @classmethod
    def load(cls, directory: str | Path) -> TorchModel:
        """Reconstruct model from saved config + weights.

        Uses the model registry so the correct subclass is instantiated.
        """
        from pycatalyst.ml.pytorch.models.registry import MODEL_REGISTRY

        d = Path(directory)
        config_path = d / "model_config.json"
        weights_path = d / "model.pt"

        cfg = json.loads(config_path.read_text(encoding="utf-8"))
        arch = cfg.pop("architecture")

        model_cls = MODEL_REGISTRY.get(arch)
        if model_cls is None:
            raise ValueError(
                f"Unknown architecture {arch!r}. Registered: {list(MODEL_REGISTRY)}"
            )

        model = model_cls(**cfg)
        model.load_state_dict(
            torch.load(weights_path, map_location="cpu", weights_only=True),
        )
        return model
