"""Model registry — maps architecture name strings to model classes."""

from __future__ import annotations

from typing import Any

from pycatalyst.ml.pytorch.models.base import TorchModel
from pycatalyst.ml.pytorch.models.gru import GRUModel
from pycatalyst.ml.pytorch.models.lstm import LSTMModel
from pycatalyst.ml.pytorch.models.mlp import MLPModel
from pycatalyst.ml.pytorch.models.tcn import TCNModel
from pycatalyst.ml.pytorch.models.transformer import TransformerModel

MODEL_REGISTRY: dict[str, type[TorchModel]] = {
    "lstm": LSTMModel,
    "gru": GRUModel,
    "tcn": TCNModel,
    "transformer": TransformerModel,
    "mlp": MLPModel,
}

# Aliases (e.g. sklearn-style names) → canonical registry key
_ARCHITECTURE_ALIASES: dict[str, str] = {
    "mlpregressor": "mlp",
    "transformerregressor": "transformer",
    "tcnregressor": "tcn",
    "gruregressor": "gru",
    "lstmregressor": "lstm",
}


def get_canonical_architecture(architecture: str) -> str:
    """Return the canonical registry key for an architecture name (e.g. TransformerRegressor → transformer)."""
    key = architecture.strip().lower()
    return _ARCHITECTURE_ALIASES.get(key, key)


def create_model(architecture: str, **kwargs: Any) -> TorchModel:
    """Instantiate a model from the registry by name.

    Accepts canonical names (e.g. ``mlp``) or aliases (e.g. ``MLPRegressor``).
    Raises:
        ValueError: If *architecture* is not registered.
    """
    key = architecture.strip().lower()
    key = _ARCHITECTURE_ALIASES.get(key, key)
    cls = MODEL_REGISTRY.get(key)
    if cls is None:
        raise ValueError(
            f"Unknown architecture {architecture!r}. Registered: {list(MODEL_REGISTRY)}"
        )
    return cls(**kwargs)
