"""Device detection — CUDA -> MPS -> CPU."""

from __future__ import annotations

import logging

import torch

logger = logging.getLogger(__name__)


def get_device(preference: str | None = None) -> torch.device:
    """Return the best available device.

    If *preference* is given (e.g. ``"cpu"``, ``"cuda"``, ``"mps"``), it is
    honoured if available; otherwise we fall back to auto-detection.
    """
    if preference:
        pref = preference.strip().lower()
        if pref == "cuda" and torch.cuda.is_available():
            dev = torch.device("cuda")
            logger.info("Using device: %s (%s)", dev, torch.cuda.get_device_name(0))
            return dev
        if pref == "mps" and torch.backends.mps.is_available():
            dev = torch.device("mps")
            logger.info("Using device: %s", dev)
            return dev
        if pref == "cpu":
            logger.info("Using device: cpu (forced)")
            return torch.device("cpu")
        logger.warning(
            "Requested device %r not available, falling back to auto-detect", pref
        )

    if torch.cuda.is_available():
        dev = torch.device("cuda")
        logger.info("Using device: %s (%s)", dev, torch.cuda.get_device_name(0))
        return dev

    if torch.backends.mps.is_available():
        dev = torch.device("mps")
        logger.info("Using device: %s", dev)
        return dev

    logger.info("Using device: cpu")
    return torch.device("cpu")
