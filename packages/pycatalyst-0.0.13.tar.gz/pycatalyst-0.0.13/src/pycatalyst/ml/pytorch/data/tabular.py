"""Tabular data pipeline — CSV/Parquet to DataLoaders for MLP-style models."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, TensorDataset

from pycatalyst.ml.io import load_dataframe as load_dataframe_from_uri
from pycatalyst.ml.pytorch.config import PytorchExperimentConfig
from pycatalyst.ml.pytorch.data.scaling import Scaler


@dataclass
class TabularSplits:
    train_loader: DataLoader
    val_loader: DataLoader
    test_loader: DataLoader
    scaler: Scaler
    feature_names: list[str]
    target_name: str
    input_size: int


def prepare_tabular(config: PytorchExperimentConfig) -> TabularSplits:
    """Load tabular data, split, scale, and return DataLoaders.

    Uses a holdout (random) or temporal (chronological) split.  The scaler
    is fit **only** on the training portion.
    """
    df = _load_dataframe(config.data.path)
    target = config.data.target

    if target not in df.columns:
        raise ValueError(
            f"Target column {target!r} not found. Available: {list(df.columns)}"
        )

    feature_cols = config.data.features or [c for c in df.columns if c != target]
    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Feature columns not found: {missing}")

    X = df[feature_cols].values.astype(np.float32)
    y = df[target].values.astype(np.float32).reshape(-1, 1)

    n = len(X)
    split = config.data.split
    n_train = int(n * split.train)
    n_val = int(n * split.val)

    if split.strategy == "holdout":
        rng = np.random.RandomState(config.experiment.seed)
        idx = rng.permutation(n)
    else:
        idx = np.arange(n)

    train_idx = idx[:n_train]
    val_idx = idx[n_train : n_train + n_val]
    test_idx = idx[n_train + n_val :]

    X_train, y_train = X[train_idx], y[train_idx]
    X_val, y_val = X[val_idx], y[val_idx]
    X_test, y_test = X[test_idx], y[test_idx]

    scaler = Scaler(config.data.scaler)
    scaler.fit(X_train)
    X_train = scaler.transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)

    bs = config.training.batch_size

    train_loader = DataLoader(
        TensorDataset(torch.from_numpy(X_train), torch.from_numpy(y_train)),
        batch_size=bs,
        shuffle=(split.strategy == "holdout"),
    )
    val_loader = DataLoader(
        TensorDataset(torch.from_numpy(X_val), torch.from_numpy(y_val)),
        batch_size=bs,
        shuffle=False,
    )
    test_loader = DataLoader(
        TensorDataset(torch.from_numpy(X_test), torch.from_numpy(y_test)),
        batch_size=bs,
        shuffle=False,
    )

    return TabularSplits(
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
        scaler=scaler,
        feature_names=feature_cols,
        target_name=target,
        input_size=len(feature_cols),
    )


def _load_dataframe(path: str) -> pd.DataFrame:
    return load_dataframe_from_uri(path)
