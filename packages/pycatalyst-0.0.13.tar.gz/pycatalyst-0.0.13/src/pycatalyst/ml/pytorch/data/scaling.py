"""Stateful scalers — fit on train, serialize for inference.

Scalers are intentionally implemented without sklearn so that the serving
path has zero heavy dependencies.  Parameters are serialised as plain JSON.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np


class Scaler:
    """MinMax / Standard / Robust scaler with serialisation."""

    def __init__(self, method: str = "minmax") -> None:
        if method not in ("minmax", "standard", "robust", "none"):
            raise ValueError(f"Unknown scaler method: {method!r}")
        self.method = method
        self._params: dict[str, Any] = {}

    def fit(self, data: np.ndarray) -> Scaler:
        """Fit scaler parameters from *data* (2-D array, rows=samples)."""
        if self.method == "none":
            return self

        if self.method == "minmax":
            self._params["min"] = data.min(axis=0).tolist()
            self._params["max"] = data.max(axis=0).tolist()

        elif self.method == "standard":
            self._params["mean"] = data.mean(axis=0).tolist()
            self._params["std"] = data.std(axis=0).tolist()

        elif self.method == "robust":
            self._params["median"] = np.median(data, axis=0).tolist()
            q25 = np.percentile(data, 25, axis=0)
            q75 = np.percentile(data, 75, axis=0)
            self._params["iqr"] = (q75 - q25).tolist()

        return self

    def transform(self, data: np.ndarray) -> np.ndarray:
        """Apply the fitted transform to *data*."""
        if self.method == "none":
            return data

        if self.method == "minmax":
            mn = np.array(self._params["min"])
            mx = np.array(self._params["max"])
            denom = mx - mn
            denom[denom == 0] = 1.0
            return (data - mn) / denom

        if self.method == "standard":
            mean = np.array(self._params["mean"])
            std = np.array(self._params["std"])
            std[std == 0] = 1.0
            return (data - mean) / std

        if self.method == "robust":
            med = np.array(self._params["median"])
            iqr = np.array(self._params["iqr"])
            iqr[iqr == 0] = 1.0
            return (data - med) / iqr

        return data

    def inverse_transform(self, data: np.ndarray) -> np.ndarray:
        """Reverse the scaling."""
        if self.method == "none":
            return data

        if self.method == "minmax":
            mn = np.array(self._params["min"])
            mx = np.array(self._params["max"])
            return data * (mx - mn) + mn

        if self.method == "standard":
            mean = np.array(self._params["mean"])
            std = np.array(self._params["std"])
            std[std == 0] = 1.0
            return data * std + mean

        if self.method == "robust":
            med = np.array(self._params["median"])
            iqr = np.array(self._params["iqr"])
            iqr[iqr == 0] = 1.0
            return data * iqr + med

        return data

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Write scaler parameters to a JSON file."""
        payload = {"method": self.method, "params": self._params}
        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> Scaler:
        """Reconstruct a scaler from a saved JSON file."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        scaler = cls(method=data["method"])
        scaler._params = data["params"]
        return scaler


class PanelScaler:
    """Fit/transform scaling parameters per-symbol or globally.

    When ``per_symbol=True`` (default), each symbol gets its own
    :class:`Scaler` fitted on that symbol's training data.  When
    ``per_symbol=False``, a single global scaler is fitted on the
    concatenation of all symbols' training data.

    Args:
        method: Scaling method (``"standard"``, ``"minmax"``,
            ``"robust"``, ``"none"``).
        per_symbol: Whether to maintain separate scalers per symbol.
    """

    def __init__(
        self,
        method: str = "standard",
        per_symbol: bool = True,
    ) -> None:
        self.method = method
        self.per_symbol = per_symbol
        self._scalers: dict[str, Scaler] = {}
        self._global_scaler: Scaler | None = None

    def fit(
        self,
        symbol_data: dict[str, np.ndarray],
    ) -> PanelScaler:
        """Fit scaler(s) from per-symbol 2-D training arrays.

        Args:
            symbol_data: ``{symbol: features_array}`` where each array
                is ``(rows, n_features)``.

        Returns:
            self
        """
        if self.per_symbol:
            for sym, data in symbol_data.items():
                scaler = Scaler(self.method)
                scaler.fit(data)
                self._scalers[sym] = scaler
        else:
            all_data = np.concatenate(list(symbol_data.values()), axis=0)
            self._global_scaler = Scaler(self.method)
            self._global_scaler.fit(all_data)
        return self

    def transform(self, symbol: str, data: np.ndarray) -> np.ndarray:
        """Transform data for a given symbol."""
        scaler = self._get_scaler(symbol)
        return scaler.transform(data)

    def inverse_transform(self, symbol: str, data: np.ndarray) -> np.ndarray:
        """Reverse the transform for a given symbol."""
        scaler = self._get_scaler(symbol)
        return scaler.inverse_transform(data)

    def _get_scaler(self, symbol: str) -> Scaler:
        if self.per_symbol:
            if symbol not in self._scalers:
                raise KeyError(
                    f"No scaler fitted for symbol {symbol!r}. "
                    f"Fitted: {sorted(self._scalers.keys())}"
                )
            return self._scalers[symbol]
        if self._global_scaler is None:
            raise RuntimeError("PanelScaler has not been fitted yet.")
        return self._global_scaler

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Save all scaler parameters to a single JSON file."""
        payload: dict[str, Any] = {
            "method": self.method,
            "per_symbol": self.per_symbol,
        }
        if self.per_symbol:
            payload["scalers"] = {
                sym: scaler._params for sym, scaler in self._scalers.items()
            }
        else:
            payload["global_params"] = (
                self._global_scaler._params if self._global_scaler else {}
            )

        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> PanelScaler:
        """Reconstruct a PanelScaler from a saved JSON file."""
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        ps = cls(method=raw["method"], per_symbol=raw["per_symbol"])
        if ps.per_symbol:
            for sym, params in raw.get("scalers", {}).items():
                scaler = Scaler(ps.method)
                scaler._params = params
                ps._scalers[sym] = scaler
        else:
            scaler = Scaler(ps.method)
            scaler._params = raw.get("global_params", {})
            ps._global_scaler = scaler
        return ps

    def __repr__(self) -> str:
        mode = "per_symbol" if self.per_symbol else "global"
        n = len(self._scalers) if self.per_symbol else 1
        return f"PanelScaler(method={self.method!r}, mode={mode}, n_scalers={n})"
