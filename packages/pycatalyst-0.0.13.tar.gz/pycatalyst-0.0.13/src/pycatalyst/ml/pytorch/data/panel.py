"""Panel data pipeline -- load multi-symbol data, split, scale, return DataLoaders.

This is the entry point that wires :class:`PanelData`,
:class:`PanelScaler`, and :class:`PanelTemporalDataset` together into
ready-to-train DataLoaders.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import numpy as np
from torch.utils.data import DataLoader

from pycatalyst.ml.pytorch.data.panel_dataset import PanelTemporalDataset
from pycatalyst.ml.pytorch.data.scaling import PanelScaler

if TYPE_CHECKING:
    from pycatalyst.ml.data import PanelData
    from pycatalyst.ml.pytorch.config import PytorchExperimentConfig

logger = logging.getLogger(__name__)


@dataclass
class PanelSplits:
    """Result of :func:`prepare_panel_temporal` -- parallel to TemporalSplits."""

    train_loader: DataLoader
    val_loader: DataLoader
    test_loader: DataLoader
    scaler: PanelScaler
    feature_names: list[str]
    target_name: str
    input_size: int
    sequence_length: int
    symbols: list[str]


def prepare_panel_temporal(
    config: PytorchExperimentConfig,
    *,
    panel_data: PanelData | None = None,
) -> PanelSplits | dict[str, PanelSplits]:
    """Load multi-symbol data, split chronologically, scale, return DataLoaders.

    If *panel_data* is provided (programmatic API), it is used directly.
    Otherwise the data is loaded from config (config-driven API).

    For ``training_mode="shared"`` (default): returns a single
    :class:`PanelSplits` with all symbols interleaved.

    For ``training_mode="per_symbol"``: returns
    ``dict[str, PanelSplits]``, one entry per symbol.

    Args:
        config: Validated experiment configuration.
        panel_data: Optional pre-loaded PanelData object.

    Returns:
        PanelSplits or dict of PanelSplits.
    """
    if panel_data is None:
        panel_data = _load_panel_from_config(config)

    arrays = panel_data.to_arrays()

    split_cfg = config.data.split
    train_r = split_cfg.train
    val_r = split_cfg.val
    seq_len = config.data.sequence_length
    stride = config.data.stride
    batch_size = config.training.batch_size
    scale_per_symbol = getattr(config.data, "scale_per_symbol", True)
    training_mode = getattr(config.data, "training_mode", "shared")
    num_workers = getattr(config.data, "num_workers", 0)
    pin_memory = getattr(config.data, "pin_memory", False)

    # Chronological split per symbol
    train_arrays: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    val_arrays: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    test_arrays: dict[str, tuple[np.ndarray, np.ndarray]] = {}

    for sym, (feat, tgt) in arrays.items():
        n = len(feat)
        n_train = int(n * train_r)
        n_val = int(n * val_r)

        train_arrays[sym] = (feat[:n_train], tgt[:n_train])
        val_arrays[sym] = (
            feat[n_train : n_train + n_val],
            tgt[n_train : n_train + n_val],
        )
        test_arrays[sym] = (feat[n_train + n_val :], tgt[n_train + n_val :])

    # Fit scaler on training data only
    scaler = PanelScaler(method=config.data.scaler, per_symbol=scale_per_symbol)
    scaler.fit({sym: feat for sym, (feat, _) in train_arrays.items()})

    # Transform all splits
    for split_dict in (train_arrays, val_arrays, test_arrays):
        for sym in list(split_dict.keys()):
            feat, tgt = split_dict[sym]
            split_dict[sym] = (scaler.transform(sym, feat), tgt)

    if training_mode == "per_symbol":
        return _build_per_symbol_splits(
            train_arrays,
            val_arrays,
            test_arrays,
            scaler,
            panel_data,
            seq_len,
            stride,
            batch_size,
            num_workers,
            pin_memory,
        )

    return _build_shared_splits(
        train_arrays,
        val_arrays,
        test_arrays,
        scaler,
        panel_data,
        seq_len,
        stride,
        batch_size,
        num_workers,
        pin_memory,
    )


def _build_shared_splits(
    train_arrays: dict[str, tuple[np.ndarray, np.ndarray]],
    val_arrays: dict[str, tuple[np.ndarray, np.ndarray]],
    test_arrays: dict[str, tuple[np.ndarray, np.ndarray]],
    scaler: PanelScaler,
    panel_data: PanelData,
    seq_len: int,
    stride: int,
    batch_size: int,
    num_workers: int,
    pin_memory: bool,
) -> PanelSplits:
    train_ds = PanelTemporalDataset(train_arrays, seq_len, stride)
    val_ds = PanelTemporalDataset(val_arrays, seq_len, stride)
    test_ds = PanelTemporalDataset(test_arrays, seq_len, stride)

    logger.info(
        "Panel data prepared: %d symbols, %d/%d/%d windows (train/val/test)",
        panel_data.n_symbols,
        len(train_ds),
        len(val_ds),
        len(test_ds),
    )

    loader_kwargs: dict[str, Any] = {
        "batch_size": batch_size,
        "num_workers": num_workers,
        "pin_memory": pin_memory,
    }

    return PanelSplits(
        train_loader=DataLoader(train_ds, shuffle=True, **loader_kwargs),
        val_loader=DataLoader(val_ds, shuffle=False, **loader_kwargs),
        test_loader=DataLoader(test_ds, shuffle=False, **loader_kwargs),
        scaler=scaler,
        feature_names=panel_data.features,
        target_name=panel_data.target,
        input_size=panel_data.n_features,
        sequence_length=seq_len,
        symbols=panel_data.symbols,
    )


def _build_per_symbol_splits(
    train_arrays: dict[str, tuple[np.ndarray, np.ndarray]],
    val_arrays: dict[str, tuple[np.ndarray, np.ndarray]],
    test_arrays: dict[str, tuple[np.ndarray, np.ndarray]],
    scaler: PanelScaler,
    panel_data: PanelData,
    seq_len: int,
    stride: int,
    batch_size: int,
    num_workers: int,
    pin_memory: bool,
) -> dict[str, PanelSplits]:
    result: dict[str, PanelSplits] = {}
    loader_kwargs: dict[str, Any] = {
        "batch_size": batch_size,
        "num_workers": num_workers,
        "pin_memory": pin_memory,
    }

    for sym in panel_data.symbols:
        train_ds = PanelTemporalDataset({sym: train_arrays[sym]}, seq_len, stride)
        val_ds = PanelTemporalDataset({sym: val_arrays[sym]}, seq_len, stride)
        test_ds = PanelTemporalDataset({sym: test_arrays[sym]}, seq_len, stride)

        result[sym] = PanelSplits(
            train_loader=DataLoader(train_ds, shuffle=True, **loader_kwargs),
            val_loader=DataLoader(val_ds, shuffle=False, **loader_kwargs),
            test_loader=DataLoader(test_ds, shuffle=False, **loader_kwargs),
            scaler=scaler,
            feature_names=panel_data.features,
            target_name=panel_data.target,
            input_size=panel_data.n_features,
            sequence_length=seq_len,
            symbols=[sym],
        )

    return result


def _load_panel_from_config(config: PytorchExperimentConfig) -> PanelData:
    """Build a PanelData from config's data section."""
    from pycatalyst.ml.data import PanelData

    panel_cfg = getattr(config.data, "panel", None)
    if panel_cfg is None:
        raise ValueError("data.panel section is required when data.format='panel'")

    target = config.data.target
    features = config.data.features

    if panel_cfg.symbol_column:
        path = config.data.path
        return PanelData.from_parquet(
            path,
            symbol_column=panel_cfg.symbol_column,
            target=target,
            sort_by=panel_cfg.sort_column,
            features=features,
        )

    directory = panel_cfg.directory
    if directory is None:
        raise ValueError(
            "data.panel must specify either 'directory' or 'symbol_column'"
        )
    return PanelData.from_directory(
        directory,
        target=target,
        sort_by=panel_cfg.sort_column,
        pattern=panel_cfg.pattern,
        features=features,
    )
