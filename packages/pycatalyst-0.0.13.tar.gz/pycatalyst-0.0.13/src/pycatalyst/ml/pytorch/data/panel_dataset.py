"""Lazy sliding-window dataset for multi-symbol panel data.

Each ``__getitem__`` call slices a single window from the raw numpy
arrays -- no pre-allocation of the full windowed tensor.  This keeps
memory usage proportional to the raw data size (~4 GB for 100 symbols x
100k rows x 100 features in float32) rather than the windowed expansion
(which would be ~60x larger).
"""

from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import Dataset


class PanelTemporalDataset(Dataset):
    """Lazy sliding-window dataset across multiple symbols.

    Args:
        symbol_arrays: ``{symbol: (features, targets)}`` where
            *features* is ``(rows, n_features)`` and *targets* is
            ``(rows,)`` numpy float32 arrays.
        seq_len: Number of time steps per input window.
        stride: Step size between consecutive windows.
    """

    def __init__(
        self,
        symbol_arrays: dict[str, tuple[np.ndarray, np.ndarray]],
        seq_len: int,
        stride: int = 1,
    ) -> None:
        self._symbols = symbol_arrays
        self._seq_len = seq_len

        self._index: list[tuple[str, int]] = []
        for sym, (feat, _tgt) in symbol_arrays.items():
            n = len(feat)
            for start in range(0, n - seq_len, stride):
                self._index.append((sym, start))

    def __len__(self) -> int:
        return len(self._index)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        sym, start = self._index[idx]
        feat, tgt = self._symbols[sym]
        end = start + self._seq_len
        x = np.ascontiguousarray(feat[start:end])
        y = np.array([tgt[end]], dtype=np.float32)
        return torch.from_numpy(x), torch.from_numpy(y)

    @property
    def symbols(self) -> list[str]:
        """Sorted list of symbols in this dataset."""
        return sorted(self._symbols.keys())

    @property
    def seq_len(self) -> int:
        return self._seq_len

    def symbol_window_counts(self) -> dict[str, int]:
        """Return the number of windows per symbol."""
        counts: dict[str, int] = {}
        for sym, _ in self._index:
            counts[sym] = counts.get(sym, 0) + 1
        return counts

    def __repr__(self) -> str:
        return (
            f"PanelTemporalDataset(symbols={len(self._symbols)}, "
            f"windows={len(self)}, seq_len={self._seq_len})"
        )
