"""PyTorch training loop with checkpointing, early stopping, and gradient clipping.

This is the single most important file in the engine.  It orchestrates the
full experiment lifecycle: seed → data → model → train → evaluate → save.
"""

from __future__ import annotations

import json
import logging
import math
import random
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from torch.optim.lr_scheduler import CosineAnnealingLR, ReduceLROnPlateau, StepLR
from torch.utils.data import DataLoader

from pycatalyst.ml.pytorch.config import PytorchExperimentConfig
from pycatalyst.ml.pytorch.data.scaling import Scaler
from pycatalyst.ml.pytorch.device import get_device
from pycatalyst.ml.pytorch.models.registry import (
    create_model,
    get_canonical_architecture,
)
from pycatalyst.ml.results import ExperimentResult

logger = logging.getLogger(__name__)

TEMPORAL_ARCHITECTURES = frozenset({"lstm", "gru", "tcn", "transformer"})


@dataclass
class TrainOutput:
    """Internal result from ``_train_impl`` carrying fitted objects."""

    result: ExperimentResult
    model: nn.Module
    scaler: Scaler | Any


_LOSS_REGISTRY: dict[str, type[nn.Module]] = {
    "mse": nn.MSELoss,
    "mae": nn.L1Loss,
    "huber": nn.HuberLoss,
    "smooth_l1": nn.SmoothL1Loss,
}


# ------------------------------------------------------------------
# Public entry point
# ------------------------------------------------------------------


def train(
    config: PytorchExperimentConfig,
    *,
    on_progress: Callable[[int, dict[str, float]], None] | None = None,
) -> ExperimentResult:
    """Run a full PyTorch experiment from a validated config."""
    return _train_impl(config, on_progress=on_progress).result


def _train_impl(
    config: PytorchExperimentConfig,
    *,
    on_progress: Callable[[int, dict[str, float]], None] | None = None,
) -> TrainOutput:
    """Run a full PyTorch experiment, returning model + scaler + result."""
    t0 = time.time()
    _seed_all(config.experiment.seed)

    output_dir = Path(config.experiment.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    device = get_device()

    # --- Data ---
    data_format = getattr(config.data, "format", "single")
    if data_format == "panel":
        from pycatalyst.ml.pytorch.data.panel import prepare_panel_temporal

        panel_result = prepare_panel_temporal(config)
        training_mode = getattr(config.data, "training_mode", "shared")
        if training_mode == "per_symbol" and isinstance(panel_result, dict):
            return _train_per_symbol(
                config, panel_result, device, output_dir, t0, on_progress
            )
        splits = panel_result
        input_size = splits.input_size
        scaler: Any = splits.scaler
    else:
        canonical_arch = get_canonical_architecture(config.model.architecture)
        if canonical_arch in TEMPORAL_ARCHITECTURES:
            from pycatalyst.ml.pytorch.data.temporal import prepare_temporal

            splits = prepare_temporal(config)
        else:
            from pycatalyst.ml.pytorch.data.tabular import prepare_tabular

            splits = prepare_tabular(config)
        input_size = splits.input_size
        scaler = splits.scaler

    scaler_path = output_dir / "scaler.json"
    scaler.save(scaler_path)

    # --- Model ---
    model = create_model(
        config.model.architecture,
        input_size=input_size,
        **config.model.params,
    )
    model.to(device)
    logger.info(
        "Model: %s  params=%s  device=%s",
        config.model.architecture,
        sum(p.numel() for p in model.parameters()),
        device,
    )

    # --- Optimizer & scheduler ---
    optimizer = _build_optimizer(
        model,
        config.training.optimizer,
        config.training.learning_rate,
    )
    scheduler = _build_scheduler(
        optimizer,
        config.training.scheduler,
        config.training.epochs,
    )

    # --- Checkpoint resume ---
    start_epoch = 1
    best_metric = (
        math.inf if config.training.early_stopping.mode == "min" else -math.inf
    )
    resume_from = getattr(config.training, "resume_from", None)
    if resume_from:
        ckpt = torch.load(resume_from, map_location=device, weights_only=False)
        model.load_state_dict(ckpt["model_state"])
        optimizer.load_state_dict(ckpt["optimizer_state"])
        if scheduler is not None and "scheduler_state" in ckpt:
            scheduler.load_state_dict(ckpt["scheduler_state"])
        start_epoch = ckpt.get("epoch", 0) + 1
        best_metric = ckpt.get("best_metric", best_metric)
        logger.info("Resumed from %s at epoch %d", resume_from, start_epoch)

    # --- Training config ---
    loss_name = getattr(config.training, "loss", "mse")
    criterion = _LOSS_REGISTRY.get(loss_name, nn.MSELoss)()
    use_amp = getattr(config.training, "mixed_precision", False)
    accum_steps = getattr(config.training, "gradient_accumulation_steps", 1)

    amp_scaler = torch.amp.GradScaler(device.type, enabled=use_amp)

    patience_counter = 0
    history: list[dict[str, Any]] = []

    for epoch in range(start_epoch, config.training.epochs + 1):
        train_loss = _train_one_epoch(
            model,
            splits.train_loader,
            criterion,
            optimizer,
            device,
            config.training.gradient_clip,
            amp_scaler=amp_scaler,
            use_amp=use_amp,
            accum_steps=accum_steps,
        )

        val_loss = _evaluate_loss(
            model,
            splits.val_loader,
            criterion,
            device,
            use_amp=use_amp,
        )

        if scheduler is not None:
            if isinstance(scheduler, ReduceLROnPlateau):
                scheduler.step(val_loss)
            else:
                scheduler.step()

        current_lr = optimizer.param_groups[0]["lr"]
        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "lr": current_lr,
            }
        )

        if on_progress is not None:
            on_progress(
                epoch,
                {"train_loss": train_loss, "val_loss": val_loss, "lr": current_lr},
            )

        logger.info(
            "Epoch %d/%d  train_loss=%.6f  val_loss=%.6f  lr=%.2e",
            epoch,
            config.training.epochs,
            train_loss,
            val_loss,
            current_lr,
        )

        if math.isnan(train_loss) or math.isnan(val_loss):
            logger.error("NaN detected at epoch %d -- stopping training", epoch)
            break

        improved = _is_improvement(
            val_loss,
            best_metric,
            config.training.early_stopping.mode,
        )
        if improved:
            best_metric = val_loss
            patience_counter = 0
            model.save(output_dir)
            _save_checkpoint(
                output_dir / "checkpoint.pt",
                model,
                optimizer,
                scheduler,
                epoch,
                best_metric,
            )
            logger.info("  checkpoint saved (val_loss=%.6f)", val_loss)
        else:
            patience_counter += 1

        if patience_counter >= config.training.early_stopping.patience:
            logger.info(
                "Early stopping at epoch %d (patience=%d)",
                epoch,
                config.training.early_stopping.patience,
            )
            break

    # --- Save training history ---
    history_path = output_dir / "history.json"
    history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")

    # --- Reload best weights for evaluation ---
    best_weights = output_dir / "model.pt"
    if best_weights.exists():
        model.load_state_dict(
            torch.load(best_weights, map_location=device, weights_only=True),
        )

    # --- Evaluation on test set ---
    from pycatalyst.ml.pytorch.evaluation import evaluate

    metrics, plot_paths = evaluate(
        model=model,
        test_loader=splits.test_loader,
        scaler=scaler if isinstance(scaler, Scaler) else Scaler("none"),
        device=device,
        output_dir=output_dir,
        metric_names=config.evaluation.metrics,
        plot_names=config.evaluation.plots,
        history=history,
        target_idx=-1,
    )

    if config.serving.jit_export:
        _export_jit(model, splits, device, output_dir)

    duration = time.time() - t0

    artifacts = {
        "weights": str(output_dir / "model.pt"),
        "config": str(output_dir / "model_config.json"),
        "scaler": str(scaler_path),
        "history": str(history_path),
    }
    for name, path_str in plot_paths.items():
        artifacts[f"plot_{name}"] = path_str

    result = ExperimentResult(
        name=config.experiment.name,
        backend="pytorch",
        metrics=metrics,
        artifacts=artifacts,
        training_history=history,
        duration_seconds=duration,
    )
    return TrainOutput(result=result, model=model, scaler=scaler)


def _train_per_symbol(
    config: PytorchExperimentConfig,
    symbol_splits: dict,
    device: torch.device,
    output_dir: Path,
    t0: float,
    on_progress: Callable[[int, dict[str, float]], None] | None = None,
) -> TrainOutput:
    """Train one model per symbol, aggregate results."""

    all_metrics: dict[str, dict[str, float]] = {}
    all_artifacts: dict[str, str] = {}
    all_history: list[dict[str, Any]] = []
    last_model: nn.Module | None = None
    last_scaler: Any = None

    for symbol, splits in symbol_splits.items():
        sym_dir = output_dir / symbol
        sym_dir.mkdir(parents=True, exist_ok=True)
        logger.info("Training model for symbol: %s", symbol)

        model = create_model(
            config.model.architecture,
            input_size=splits.input_size,
            **config.model.params,
        )
        model.to(device)

        loss_name = getattr(config.training, "loss", "mse")
        criterion = _LOSS_REGISTRY.get(loss_name, nn.MSELoss)()
        use_amp = getattr(config.training, "mixed_precision", False)
        accum_steps = getattr(config.training, "gradient_accumulation_steps", 1)
        amp_scaler = torch.amp.GradScaler(device.type, enabled=use_amp)

        opt = _build_optimizer(
            model,
            config.training.optimizer,
            config.training.learning_rate,
        )
        sched = _build_scheduler(
            opt,
            config.training.scheduler,
            config.training.epochs,
        )

        best_val = math.inf
        patience_ctr = 0

        for _epoch in range(1, config.training.epochs + 1):
            train_loss = _train_one_epoch(
                model,
                splits.train_loader,
                criterion,
                opt,
                device,
                config.training.gradient_clip,
                amp_scaler=amp_scaler,
                use_amp=use_amp,
                accum_steps=accum_steps,
            )
            val_loss = _evaluate_loss(
                model,
                splits.val_loader,
                criterion,
                device,
                use_amp=use_amp,
            )

            if sched is not None:
                if isinstance(sched, ReduceLROnPlateau):
                    sched.step(val_loss)
                else:
                    sched.step()

            if val_loss < best_val:
                best_val = val_loss
                patience_ctr = 0
                model.save(sym_dir)
            else:
                patience_ctr += 1

            if patience_ctr >= config.training.early_stopping.patience:
                break

        all_metrics[symbol] = {"val_loss": best_val}
        all_artifacts[f"{symbol}/weights"] = str(sym_dir / "model.pt")
        last_model = model
        last_scaler = splits.scaler

    avg_val = np.mean([m["val_loss"] for m in all_metrics.values()])
    duration = time.time() - t0

    result = ExperimentResult(
        name=config.experiment.name,
        backend="pytorch",
        metrics={
            "avg_val_loss": float(avg_val),
            **{f"{sym}_val_loss": m["val_loss"] for sym, m in all_metrics.items()},
        },
        artifacts=all_artifacts,
        training_history=all_history,
        duration_seconds=duration,
    )
    return TrainOutput(result=result, model=last_model, scaler=last_scaler)


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------


def _seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _build_optimizer(
    model: nn.Module,
    optimizer_name: str,
    learning_rate: float,
) -> torch.optim.Optimizer:
    if optimizer_name == "adam":
        return torch.optim.Adam(model.parameters(), lr=learning_rate)
    if optimizer_name == "adamw":
        return torch.optim.AdamW(model.parameters(), lr=learning_rate)
    if optimizer_name == "sgd":
        return torch.optim.SGD(model.parameters(), lr=learning_rate)
    raise ValueError(f"Unknown optimizer: {optimizer_name!r}")


def _build_scheduler(
    optimizer: torch.optim.Optimizer,
    scheduler_name: str | None,
    epochs: int,
) -> Any | None:
    if scheduler_name is None:
        return None
    if scheduler_name == "cosine":
        return CosineAnnealingLR(optimizer, T_max=epochs)
    if scheduler_name == "step":
        return StepLR(optimizer, step_size=max(1, epochs // 3))
    if scheduler_name == "plateau":
        return ReduceLROnPlateau(optimizer, patience=5)
    raise ValueError(f"Unknown scheduler: {scheduler_name!r}")


def _train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    clip_norm: float,
    *,
    amp_scaler: torch.amp.GradScaler | None = None,
    use_amp: bool = False,
    accum_steps: int = 1,
) -> float:
    model.train()
    running_loss = 0.0
    n_batches = 0
    optimizer.zero_grad()

    for i, (X_batch, y_batch) in enumerate(loader):
        X_batch = X_batch.to(device=device, dtype=torch.float32)
        y_batch = y_batch.to(device=device, dtype=torch.float32)

        with torch.amp.autocast(device.type, enabled=use_amp):
            preds = model(X_batch)
            loss = criterion(preds, y_batch) / accum_steps

        if amp_scaler is not None and use_amp:
            amp_scaler.scale(loss).backward()
        else:
            loss.backward()

        if (i + 1) % accum_steps == 0 or (i + 1) == len(loader):
            if clip_norm > 0:
                if amp_scaler is not None and use_amp:
                    amp_scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), clip_norm)

            if amp_scaler is not None and use_amp:
                amp_scaler.step(optimizer)
                amp_scaler.update()
            else:
                optimizer.step()
            optimizer.zero_grad()

        running_loss += loss.item() * accum_steps
        n_batches += 1

    return running_loss / max(n_batches, 1)


def _evaluate_loss(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
    *,
    use_amp: bool = False,
) -> float:
    model.eval()
    running_loss = 0.0
    n_batches = 0

    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch = X_batch.to(device=device, dtype=torch.float32)
            y_batch = y_batch.to(device=device, dtype=torch.float32)
            with torch.amp.autocast(device.type, enabled=use_amp):
                preds = model(X_batch)
                loss = criterion(preds, y_batch)
            running_loss += loss.item()
            n_batches += 1

    return running_loss / max(n_batches, 1)


def _is_improvement(current: float, best: float, mode: str) -> bool:
    if mode == "min":
        return current < best
    return current > best


def _save_checkpoint(
    path: Path,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any | None,
    epoch: int,
    best_metric: float,
) -> None:
    """Save full training state for resumption."""
    state = {
        "model_state": model.state_dict(),
        "optimizer_state": optimizer.state_dict(),
        "epoch": epoch,
        "best_metric": best_metric,
    }
    if scheduler is not None:
        state["scheduler_state"] = scheduler.state_dict()
    torch.save(state, path)


def _export_jit(
    model: nn.Module,
    splits: Any,
    device: torch.device,
    output_dir: Path,
) -> None:
    model.eval()
    sample = next(iter(splits.test_loader))[0][:1].to(
        device=device, dtype=torch.float32
    )
    try:
        traced = torch.jit.trace(model, sample)
        jit_path = output_dir / "model_jit.pt"
        traced.save(str(jit_path))
        logger.info("TorchScript model saved to %s", jit_path)
    except Exception:
        logger.warning("TorchScript export failed", exc_info=True)
