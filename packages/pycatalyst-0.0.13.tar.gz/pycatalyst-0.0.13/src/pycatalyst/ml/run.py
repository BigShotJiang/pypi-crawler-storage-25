"""Experiment dispatcher — reads YAML, detects backend, calls the right engine.

Public API::

    from pycatalyst.ml import run, load, validate, preview, schema

    config = load("experiment.yaml")   # parse without running
    ok, errors = validate(config)      # validate without running
    info = preview(config)             # data pre-flight
    result = run("experiment.yaml")    # parse + train
    result = run(config_dict)          # dict input also supported
    json_schema = schema("pytorch")    # JSON Schema for editor autocomplete
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

import yaml

from pycatalyst.ml.results import ExperimentResult


def _get_raw_config(
    config: str | Path | dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    """Load config to dict if path/string; return (raw_dict, errors). Errors empty if success."""
    errors: list[str] = []
    if isinstance(config, str | Path):
        try:
            raw = load(config)
        except FileNotFoundError as e:
            return {}, [str(e)]
        except ValueError as e:
            return {}, [str(e)]
    else:
        raw = config
    if not isinstance(raw, dict):
        return {}, ["Config must be a mapping (dict)."]
    return raw, errors


def validate(config: str | Path | dict[str, Any]) -> tuple[bool, list[str]]:
    """Validate experiment config without loading data or training.

    Args:
        config: Path to YAML/JSON, or a config dict.

    Returns:
        Tuple of (valid, errors). If valid is True, errors is empty.
        If valid is False, errors is a list of human-readable messages.
    """
    raw, load_errors = _get_raw_config(config)
    if load_errors:
        return False, load_errors

    experiment = raw.get("experiment") or {}
    backend = experiment.get("backend")
    if not backend:
        return False, [
            "Missing 'experiment.backend'. Must be one of: pytorch, sklearn, huggingface"
        ]
    backend = str(backend).strip().lower()
    if backend not in ("pytorch", "sklearn", "huggingface"):
        return False, [
            f"Unknown backend: {backend!r}. Must be one of: pytorch, sklearn, huggingface"
        ]

    try:
        if backend == "sklearn":
            from pycatalyst.ml.sklearn.config import SklearnExperimentConfig

            SklearnExperimentConfig.model_validate(raw)
        elif backend == "pytorch":
            from pycatalyst.ml.pytorch.config import PytorchExperimentConfig

            PytorchExperimentConfig.from_raw(raw)
        else:
            from pycatalyst.ml.huggingface.config import HFExperimentConfig

            HFExperimentConfig.from_raw(raw)
    except Exception as e:
        from pydantic import ValidationError

        if isinstance(e, ValidationError):
            errors = []
            for err in e.errors():
                loc = ".".join(str(x) for x in err["loc"])
                msg = err.get("msg", "")
                errors.append(f"{loc}: {msg}" if loc else msg)
            return False, errors
        return False, [str(e)]

    return True, []


def load(path: str | Path) -> dict[str, Any]:
    """Load and return an experiment config without running it.

    Useful for inspection, modification, or passing to ``run()``.

    Args:
        path: Path to a YAML or JSON experiment config file.

    Returns:
        Parsed config dictionary.

    Raises:
        FileNotFoundError: If *path* does not exist.
        ValueError: If the file content is not a mapping.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")

    raw = yaml.safe_load(p.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Expected a YAML mapping, got {type(raw).__name__}")
    return raw


def run(
    config: str | Path | dict[str, Any],
    *,
    on_progress: Callable[[int, dict[str, float]], None] | None = None,
) -> ExperimentResult:
    """Load an experiment config and dispatch to the appropriate engine.

    This is the primary config-driven entry point for pycatalyst ML.

    Args:
        config: Path to a YAML/JSON config file, or a dict.
        on_progress: Optional callback(epoch, metrics) called each epoch
            (PyTorch/HuggingFace) or once at end (sklearn). Not called if None.

    Returns:
        ExperimentResult from the engine.

    Raises:
        FileNotFoundError: If a path is given and does not exist.
        ValueError: If the backend is missing or unrecognised.
    """
    if isinstance(config, str | Path):
        raw = load(config)
    else:
        raw = config

    backend = (raw.get("experiment") or {}).get("backend")
    if not backend:
        raise ValueError(
            "Missing 'experiment.backend' in config. "
            "Must be one of: pytorch, sklearn, huggingface"
        )

    backend = backend.strip().lower()

    if backend == "pytorch":
        try:
            from pycatalyst.ml.pytorch import run as pytorch_run  # noqa: WPS433
        except ImportError as exc:
            raise ImportError(
                "PyTorch engine requires torch. "
                "Install with: pip install pycatalyst[ml-core]"
            ) from exc
        return pytorch_run(raw, on_progress=on_progress)

    if backend == "sklearn":
        try:
            from pycatalyst.ml.sklearn import run as sklearn_run  # noqa: WPS433
        except ImportError as exc:
            raise ImportError(
                "Sklearn engine requires scikit-learn. "
                "Install with: pip install pycatalyst[ml-sklearn]"
            ) from exc
        return sklearn_run(raw, on_progress=on_progress)

    if backend == "huggingface":
        try:
            from pycatalyst.ml.huggingface import run as hf_run  # noqa: WPS433
        except ImportError as exc:
            raise ImportError(
                "HuggingFace engine requires transformers + peft. "
                "Install with: pip install pycatalyst[ml-llm]"
            ) from exc
        return hf_run(raw, on_progress=on_progress)

    raise ValueError(
        f"Unknown backend: {backend!r}. Must be one of: pytorch, sklearn, huggingface"
    )


def schema(backend: str) -> dict[str, Any]:
    """Export JSON Schema for a backend's experiment config.

    Useful for editor autocomplete and config file validation.

    Args:
        backend: Backend name (``"pytorch"``, ``"sklearn"``, ``"huggingface"``).

    Returns:
        JSON Schema dictionary.

    Raises:
        ValueError: If *backend* is unknown.

    Example::

        import json
        print(json.dumps(schema("pytorch"), indent=2))
    """
    backend = backend.strip().lower()

    if backend == "pytorch":
        from pycatalyst.ml.pytorch.config import PytorchExperimentConfig

        return PytorchExperimentConfig.model_json_schema()

    if backend == "sklearn":
        from pycatalyst.ml.sklearn.config import SklearnExperimentConfig

        return SklearnExperimentConfig.model_json_schema()

    if backend == "huggingface":
        from pycatalyst.ml.huggingface.config import HFExperimentConfig

        return HFExperimentConfig.model_json_schema()

    available = "pytorch, sklearn, huggingface"
    raise ValueError(f"Unknown backend {backend!r}. Available: {available}")


# Backward compatibility alias
run_experiment = run
