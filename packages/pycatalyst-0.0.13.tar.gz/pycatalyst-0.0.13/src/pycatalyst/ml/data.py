"""Multi-symbol time-series data container for panel (multi-asset) training.

``PanelData`` is a backend-agnostic data object that holds per-symbol
DataFrames.  It is the primary way to pass multi-symbol data to
trainers programmatically::

    from pycatalyst.ml.data import PanelData

    data = PanelData.from_directory("./features/", target="ret", sort_by="ts")
    data = PanelData.from_parquet("all.parquet", symbol_column="sym",
                                   target="ret", sort_by="ts")
    data = PanelData.from_dataframes({"AAPL": df, "MSFT": df2},
                                      target="ret", sort_by="ts")

    print(data.symbols, data.n_features, data.total_rows)
    trainer.fit(data, sequence_length=60)
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class PanelData:
    """Multi-symbol time-series data container.

    Stores per-symbol DataFrames with a consistent feature set.  Provides
    convenience constructors for common data layouts and properties for
    introspection.  Pass to ``PytorchTrainer.fit()`` or use via the
    config-driven pipeline.

    Args:
        data: Mapping of symbol name to DataFrame.
        target: Name of the target column.
        sort_by: Name of the column used to sort each symbol chronologically.
        features: Explicit feature column list.  ``None`` means all columns
            that are neither *target* nor *sort_by*.
    """

    def __init__(
        self,
        data: dict[str, pd.DataFrame],
        target: str,
        sort_by: str = "timestamp",
        features: list[str] | None = None,
    ) -> None:
        if not data:
            raise ValueError("data must be a non-empty dict of DataFrames")

        self._data = data
        self._target = target
        self._sort_by = sort_by

        sample_df = next(iter(data.values()))
        if target not in sample_df.columns:
            raise ValueError(
                f"Target column {target!r} not found in data. "
                f"Available: {list(sample_df.columns)}"
            )

        if features is not None:
            self._features = list(features)
        else:
            self._features = [
                c for c in sample_df.columns if c != target and c != sort_by
            ]

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_directory(
        cls,
        path: str | Path,
        target: str,
        sort_by: str = "timestamp",
        pattern: str = "*.parquet",
        features: list[str] | None = None,
    ) -> PanelData:
        """Load from a directory of per-symbol Parquet files.

        Each file is one symbol; the filename stem is used as the symbol
        name (e.g. ``AAPL.parquet`` -> symbol ``"AAPL"``).

        Args:
            path: Directory path (local or S3 prefix).
            target: Target column name.
            sort_by: Column to sort each symbol by.
            pattern: Glob pattern for files within the directory.
            features: Explicit feature columns (``None`` = auto-detect).

        Returns:
            PanelData instance.
        """
        directory = Path(path)
        if not directory.is_dir():
            raise FileNotFoundError(f"Directory not found: {directory}")

        files = sorted(directory.glob(pattern))
        if not files:
            raise FileNotFoundError(f"No files matching {pattern!r} in {directory}")

        data: dict[str, pd.DataFrame] = {}
        for fp in files:
            symbol = fp.stem
            df = pd.read_parquet(fp)
            if sort_by in df.columns:
                df = df.sort_values(sort_by).reset_index(drop=True)
            data[symbol] = df

        logger.info(
            "Loaded %d symbols from %s (%s total rows)",
            len(data),
            directory,
            sum(len(df) for df in data.values()),
        )
        return cls(data, target=target, sort_by=sort_by, features=features)

    @classmethod
    def from_parquet(
        cls,
        path: str | Path,
        symbol_column: str,
        target: str,
        sort_by: str = "timestamp",
        features: list[str] | None = None,
    ) -> PanelData:
        """Load from a single Parquet file with a symbol column.

        Groups by *symbol_column* to produce per-symbol DataFrames.

        Args:
            path: Path to the Parquet file.
            symbol_column: Column that identifies each symbol.
            target: Target column name.
            sort_by: Column to sort each symbol by.
            features: Explicit feature columns (``None`` = auto-detect).

        Returns:
            PanelData instance.
        """
        df = pd.read_parquet(path)
        if symbol_column not in df.columns:
            raise ValueError(
                f"Symbol column {symbol_column!r} not found. "
                f"Available: {list(df.columns)}"
            )

        data: dict[str, pd.DataFrame] = {}
        for symbol, group in df.groupby(symbol_column, sort=False):
            group_df = group.drop(columns=[symbol_column])
            if sort_by in group_df.columns:
                group_df = group_df.sort_values(sort_by).reset_index(drop=True)
            data[str(symbol)] = group_df

        logger.info(
            "Loaded %d symbols from %s (%d total rows)",
            len(data),
            path,
            len(df),
        )

        auto_features = features
        if auto_features is not None:
            auto_features = [f for f in auto_features if f != symbol_column]
        return cls(data, target=target, sort_by=sort_by, features=auto_features)

    @classmethod
    def from_dataframes(
        cls,
        data: dict[str, pd.DataFrame],
        target: str,
        sort_by: str = "timestamp",
        features: list[str] | None = None,
    ) -> PanelData:
        """Create from an in-memory dict of DataFrames.

        Args:
            data: ``{symbol_name: DataFrame}`` mapping.
            target: Target column name.
            sort_by: Column to sort each symbol by.
            features: Explicit feature columns (``None`` = auto-detect).

        Returns:
            PanelData instance.
        """
        sorted_data: dict[str, pd.DataFrame] = {}
        for symbol, df in data.items():
            if sort_by in df.columns:
                df = df.sort_values(sort_by).reset_index(drop=True)
            sorted_data[symbol] = df
        return cls(sorted_data, target=target, sort_by=sort_by, features=features)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def symbols(self) -> list[str]:
        """Sorted list of symbol names."""
        return sorted(self._data.keys())

    @property
    def n_symbols(self) -> int:
        """Number of symbols."""
        return len(self._data)

    @property
    def features(self) -> list[str]:
        """Feature column names."""
        return list(self._features)

    @property
    def n_features(self) -> int:
        """Number of feature columns."""
        return len(self._features)

    @property
    def target(self) -> str:
        """Target column name."""
        return self._target

    @property
    def sort_column(self) -> str:
        """Sort column name."""
        return self._sort_by

    @property
    def total_rows(self) -> int:
        """Total rows across all symbols."""
        return sum(len(df) for df in self._data.values())

    @property
    def memory_usage(self) -> str:
        """Human-readable memory usage estimate."""
        total_bytes = sum(
            df.memory_usage(deep=True).sum() for df in self._data.values()
        )
        if total_bytes > 1e9:
            return f"{total_bytes / 1e9:.1f} GB"
        return f"{total_bytes / 1e6:.1f} MB"

    # ------------------------------------------------------------------
    # Data access
    # ------------------------------------------------------------------

    def get_symbol(self, symbol: str) -> pd.DataFrame:
        """Return the DataFrame for a single symbol.

        Raises:
            KeyError: If symbol is not in the dataset.
        """
        if symbol not in self._data:
            raise KeyError(f"Symbol {symbol!r} not found. Available: {self.symbols}")
        return self._data[symbol]

    def to_arrays(self) -> dict[str, tuple[np.ndarray, np.ndarray]]:
        """Convert to numpy arrays for training.

        Returns:
            ``{symbol: (features_array, target_array)}`` where
            features is ``(rows, n_features)`` float32 and target
            is ``(rows,)`` float32.
        """
        result: dict[str, tuple[np.ndarray, np.ndarray]] = {}
        for symbol, df in self._data.items():
            feat = df[self._features].values.astype(np.float32)
            tgt = df[self._target].values.astype(np.float32)
            result[symbol] = (feat, tgt)
        return result

    def describe(self) -> dict[str, Any]:
        """Summary statistics for the panel dataset.

        Returns:
            Dict with keys: n_symbols, n_features, total_rows,
            memory_usage, per_symbol (list of dicts with symbol, rows,
            date_range if sort_column exists).
        """
        per_symbol = []
        for symbol in self.symbols:
            df = self._data[symbol]
            info: dict[str, Any] = {"symbol": symbol, "rows": len(df)}
            if self._sort_by in df.columns:
                info["min_date"] = str(df[self._sort_by].min())
                info["max_date"] = str(df[self._sort_by].max())
            per_symbol.append(info)

        return {
            "n_symbols": self.n_symbols,
            "n_features": self.n_features,
            "target": self._target,
            "total_rows": self.total_rows,
            "memory_usage": self.memory_usage,
            "per_symbol": per_symbol,
        }

    def __repr__(self) -> str:
        return (
            f"PanelData(n_symbols={self.n_symbols}, "
            f"n_features={self.n_features}, "
            f"total_rows={self.total_rows:,})"
        )

    def __len__(self) -> int:
        return self.total_rows
