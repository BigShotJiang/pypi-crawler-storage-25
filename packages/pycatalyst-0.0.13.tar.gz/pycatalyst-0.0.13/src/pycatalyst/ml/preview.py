"""Data preview / pre-flight — check data loads and split sizes without training."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pycatalyst.ml.run import _get_raw_config


def preview(config: str | Path | dict[str, Any]) -> dict[str, Any]:
    """Preview data for an experiment config without training.

    Loads the config, detects the backend, and for sklearn loads the
    data file to report rows, columns, target/feature presence, and
    split sizes. For other backends returns a minimal stub (path, rows
    if loadable).

    Args:
        config: Path to YAML/JSON, or a config dict.

    Returns:
        Dict with at least: path, rows, columns, target, target_found,
        features, split_sizes (train, val, test). For sklearn all are
        populated; for PyTorch/HuggingFace only path (and optionally
        rows) may be set.
    """
    raw, load_errors = _get_raw_config(config)
    if load_errors:
        return {
            "path": "",
            "rows": 0,
            "columns": [],
            "target": "",
            "target_found": False,
            "features": None,
            "split_sizes": {"train": 0, "val": 0, "test": 0},
            "error": load_errors[0],
        }

    experiment = raw.get("experiment") or {}
    backend = (experiment.get("backend") or "").strip().lower()

    if backend == "sklearn":
        return _preview_sklearn(raw)

    if backend == "pytorch":
        return _preview_pytorch(raw)

    return _preview_generic(raw)


def _preview_pytorch(raw: dict[str, Any]) -> dict[str, Any]:
    """PyTorch-specific preview with full data inspection."""
    from pycatalyst.ml.io import load_dataframe

    data = raw.get("data") or {}
    path = data.get("path") or ""
    target = data.get("target") or ""
    features = data.get("features")
    split_cfg = data.get("split") or {}
    train_r = split_cfg.get("train", 0.7)
    val_r = split_cfg.get("val", 0.15)
    seq_len = data.get("sequence_length", 60)
    stride = data.get("stride", 1)

    result: dict[str, Any] = {
        "path": path,
        "rows": 0,
        "columns": [],
        "target": target,
        "target_found": False,
        "features": features,
        "split_sizes": {"train": 0, "val": 0, "test": 0},
        "sequence_length": seq_len,
        "stride": stride,
        "estimated_windows": 0,
        "memory_estimate_mb": 0.0,
    }

    if not path:
        return result

    try:
        df = load_dataframe(path)
    except Exception as e:
        result["error"] = str(e)
        return result

    n = len(df)
    result["rows"] = n
    result["columns"] = list(df.columns)
    result["target_found"] = target in df.columns

    if features is None:
        feature_list = [c for c in df.columns if c != target]
    else:
        feature_list = features
    result["features"] = feature_list

    n_train = int(n * train_r)
    n_val = int(n * val_r)
    n_test = n - n_train - n_val
    result["split_sizes"] = {"train": n_train, "val": n_val, "test": n_test}

    n_features = len(feature_list)
    total_windows = max(0, (n - seq_len) // stride)
    result["estimated_windows"] = total_windows
    result["memory_estimate_mb"] = round(
        n * n_features * 4 / (1024 * 1024),
        1,
    )

    return result


def _preview_generic(raw: dict[str, Any]) -> dict[str, Any]:
    """Generic preview for HuggingFace or unknown backends."""
    data = raw.get("data") or {}
    path = data.get("path") or ""
    rows = 0
    if path:
        try:
            p = Path(path)
            if p.suffix.lower() == ".csv" and p.exists():
                with open(p, encoding="utf-8") as f:
                    rows = sum(1 for _ in f) - 1
            elif p.suffix.lower() == ".parquet" and p.exists():
                import pandas as pd

                rows = len(pd.read_parquet(p))
        except Exception:
            pass

    return {
        "path": path,
        "rows": rows,
        "columns": [],
        "target": "",
        "target_found": False,
        "features": None,
        "split_sizes": {"train": 0, "val": 0, "test": 0},
    }


def _preview_sklearn(raw: dict[str, Any]) -> dict[str, Any]:
    """Sklearn-specific preview: load dataframe, check columns, compute split sizes."""
    from pycatalyst.ml.sklearn._helpers import load_dataframe

    data = raw.get("data") or {}
    path = data.get("path") or ""
    target = data.get("target") or ""
    features = data.get("features")
    split_cfg = data.get("split") or {}
    train_r = split_cfg.get("train", 0.7)
    val_r = split_cfg.get("val", 0.15)

    result: dict[str, Any] = {
        "path": path,
        "rows": 0,
        "columns": [],
        "target": target,
        "target_found": False,
        "features": features,
        "split_sizes": {"train": 0, "val": 0, "test": 0},
    }

    if not path:
        return result

    try:
        df = load_dataframe(path)
    except Exception as e:
        result["error"] = str(e)
        return result

    n = len(df)
    result["rows"] = n
    result["columns"] = list(df.columns)
    result["target_found"] = target in df.columns

    if features is None:
        result["features"] = [c for c in df.columns if c != target]
    else:
        result["features"] = features

    n_train = int(n * train_r)
    n_val = int(n * val_r)
    n_test = n - n_train - n_val
    result["split_sizes"] = {"train": n_train, "val": n_val, "test": n_test}

    return result
