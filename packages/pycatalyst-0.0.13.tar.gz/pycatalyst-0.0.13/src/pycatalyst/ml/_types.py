"""ML-specific types and enums.

Defines the core value types for the ML training subsystem: training
status codes, backend identifiers, and supporting constants.
"""

from __future__ import annotations

from enum import Enum


class TrainingStatus(str, Enum):
    """Training run termination status.

    Mirrors pyoptima's ``SolverStatus`` for ML training outcomes.
    """

    COMPLETED = "completed"
    """Training finished successfully (all epochs or convergence)."""

    EARLY_STOPPED = "early_stopped"
    """Training stopped early due to patience / no improvement."""

    FAILED = "failed"
    """Training failed due to an error (NaN loss, OOM, etc.)."""

    INTERRUPTED = "interrupted"
    """Training was interrupted externally (e.g. user cancellation)."""

    UNKNOWN = "unknown"
    """Status could not be determined."""


class Backend(str, Enum):
    """Supported ML backends.

    Each backend maps to a separate engine module with its own
    dependencies and training logic.
    """

    SKLEARN = "sklearn"
    """Scikit-learn classical ML models."""

    PYTORCH = "pytorch"
    """PyTorch deep learning models (LSTM, GRU, TCN, Transformer, MLP)."""

    HUGGINGFACE = "huggingface"
    """HuggingFace Transformers with PEFT/LoRA fine-tuning."""


# Convenience sets for validation
VALID_BACKENDS: frozenset[str] = frozenset(b.value for b in Backend)
"""All valid backend name strings."""
