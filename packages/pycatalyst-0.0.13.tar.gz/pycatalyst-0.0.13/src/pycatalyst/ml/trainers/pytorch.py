"""PyTorch trainer -- sklearn-style estimator wrapping the PyTorch engine.

Supports both config-driven and fully programmatic workflows::

    # Config-driven
    trainer = PytorchTrainer.from_config("experiment.yaml")
    result = trainer.run()
    preds = trainer.predict(X_test)

    # Fully programmatic
    trainer = PytorchTrainer(architecture="lstm", epochs=50, learning_rate=1e-3)
    trainer.fit(X_train, y_train, X_val=X_val, y_val=y_val)
    preds = trainer.predict(X_test)
    trainer.save("./my_model/")

    # Panel data (requires pycatalyst.ml.data.PanelData)
    data = PanelData.from_directory("./features/", target="ret", sort_by="ts")
    trainer.fit(data, sequence_length=60, scale_per_symbol=True)
"""

from __future__ import annotations

import json
import logging
import math
import time
from pathlib import Path
from typing import Any, Self

import numpy as np

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.trainers.base import BaseTrainer

logger = logging.getLogger(__name__)


class PytorchTrainer(BaseTrainer):
    """Trainer for PyTorch deep learning models.

    Wraps the PyTorch engine with full sklearn-style API:
    ``fit``/``predict``/``score``/``save``/``load``/``get_params``/``set_params``.

    Args:
        architecture: Model type (``"lstm"``, ``"gru"``, ``"tcn"``,
            ``"transformer"``, ``"mlp"``).
        params: Model hyperparameters (hidden_size, num_layers, etc.).
        epochs: Number of training epochs.
        batch_size: Mini-batch size.
        learning_rate: Optimizer learning rate.
        optimizer: Optimizer name (``"adam"``, ``"adamw"``, ``"sgd"``).
        scheduler: LR scheduler name or ``None``.
        gradient_clip: Max gradient norm for clipping.
        patience: Early stopping patience.
        seed: Random seed.
        jit_export: Whether to export TorchScript model.
        output_dir: Directory for saving artifacts.
    """

    def __init__(
        self,
        architecture: str = "lstm",
        params: dict[str, Any] | None = None,
        epochs: int = 100,
        batch_size: int = 32,
        learning_rate: float = 1e-3,
        optimizer: str = "adam",
        scheduler: str | None = None,
        gradient_clip: float = 1.0,
        patience: int = 10,
        seed: int = 42,
        jit_export: bool = False,
        output_dir: str = "./runs/pytorch",
    ) -> None:
        self.architecture = architecture
        self.params = params or {}
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.gradient_clip = gradient_clip
        self.patience = patience
        self.seed = seed
        self.jit_export = jit_export
        self.output_dir = output_dir

        # Fitted state (public sklearn-convention attributes)
        self.model_: Any = None
        self.scaler_: Any = None
        self.result_: ExperimentResult | None = None

    # ------------------------------------------------------------------
    # fit() -- accepts arrays, PanelData, or falls through to config path
    # ------------------------------------------------------------------

    def fit(
        self,
        X: Any = None,
        y: Any = None,
        *,
        X_val: Any | None = None,
        y_val: Any | None = None,
        sequence_length: int | None = None,
        **kwargs: Any,
    ) -> Self:
        """Train the model from arrays or PanelData.

        Supports three calling conventions:

        1. **Arrays** -- ``fit(X, y)`` where *X* is a numpy array
           (2-D for tabular, 3-D for pre-windowed temporal).
        2. **PanelData** -- ``fit(panel_data, sequence_length=60)``.
        3. **Config fallback** -- ``fit()`` (delegates to ``run()``).

        Args:
            X: Input features (ndarray) or :class:`PanelData`.
            y: Target values (ndarray).  Ignored when *X* is PanelData.
            X_val: Optional validation features.
            y_val: Optional validation targets.
            sequence_length: If provided and *X* is 2-D, creates
                sliding windows automatically for temporal architectures.
            **kwargs: Extra options forwarded to panel training.

        Returns:
            self
        """
        # PanelData dispatch (lazy import to avoid circular dep)
        try:
            from pycatalyst.ml.data import PanelData

            if isinstance(X, PanelData):
                return self._fit_panel(X, sequence_length=sequence_length, **kwargs)
        except ImportError:
            pass

        if X is not None and y is not None:
            return self._fit_arrays(
                X,
                y,
                X_val=X_val,
                y_val=y_val,
                sequence_length=sequence_length,
            )

        return super().fit(X, y, **kwargs)

    # ------------------------------------------------------------------
    # _fit_arrays -- in-memory training from numpy arrays
    # ------------------------------------------------------------------

    def _fit_arrays(
        self,
        X: Any,
        y: Any,
        *,
        X_val: Any | None = None,
        y_val: Any | None = None,
        sequence_length: int | None = None,
    ) -> Self:
        import torch
        from torch.utils.data import DataLoader, TensorDataset

        from pycatalyst.ml.pytorch.data.scaling import Scaler
        from pycatalyst.ml.pytorch.device import get_device
        from pycatalyst.ml.pytorch.models.registry import (
            create_model,
            get_canonical_architecture,
        )
        from pycatalyst.ml.pytorch.trainer import (
            TEMPORAL_ARCHITECTURES,
            _build_optimizer,
            _build_scheduler,
            _evaluate_loss,
            _seed_all,
            _train_one_epoch,
        )

        t0 = time.time()
        _seed_all(self.seed)

        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.float32)
        if y.ndim == 1:
            y = y.reshape(-1, 1)

        canonical_arch = get_canonical_architecture(self.architecture)
        is_temporal = canonical_arch in TEMPORAL_ARCHITECTURES

        # Auto-window 2-D data for temporal architectures
        if X.ndim == 2 and is_temporal:
            if sequence_length is None:
                raise ValueError(
                    f"Architecture {self.architecture!r} requires 3-D input "
                    "(batch, seq_len, features) or pass sequence_length= "
                    "to auto-window 2-D data."
                )
            X, y = _sliding_windows(X, y, sequence_length)

        # Train / validation split
        if X_val is None:
            split_idx = int(len(X) * 0.8)
            X_train, X_val_arr = X[:split_idx], X[split_idx:]
            y_train, y_val_arr = y[:split_idx], y[split_idx:]
        else:
            X_train = X
            y_train = y
            X_val_arr = np.asarray(X_val, dtype=np.float32)
            y_val_arr = np.asarray(y_val, dtype=np.float32)
            if y_val_arr.ndim == 1:
                y_val_arr = y_val_arr.reshape(-1, 1)

        # Scale features (reshape for 2-D fit, then restore shape)
        scaler = Scaler("standard")
        orig_shape_train = X_train.shape
        orig_shape_val = X_val_arr.shape
        X_train_2d = X_train.reshape(-1, X_train.shape[-1])
        X_val_2d = X_val_arr.reshape(-1, X_val_arr.shape[-1])
        scaler.fit(X_train_2d)
        X_train = scaler.transform(X_train_2d).reshape(orig_shape_train)
        X_val_arr = scaler.transform(X_val_2d).reshape(orig_shape_val)

        # DataLoaders
        train_loader = DataLoader(
            TensorDataset(
                torch.from_numpy(X_train),
                torch.from_numpy(y_train),
            ),
            batch_size=self.batch_size,
            shuffle=not is_temporal,
        )
        val_loader = DataLoader(
            TensorDataset(
                torch.from_numpy(X_val_arr),
                torch.from_numpy(y_val_arr),
            ),
            batch_size=self.batch_size,
            shuffle=False,
        )

        # Model
        input_size = X_train.shape[-1]
        model = create_model(
            self.architecture,
            input_size=input_size,
            **self.params,
        )
        device = get_device()
        model.to(device)

        opt = _build_optimizer(model, self.optimizer, self.learning_rate)
        sched = _build_scheduler(opt, self.scheduler, self.epochs)

        # Training loop
        criterion = torch.nn.MSELoss()
        best_val = math.inf
        patience_counter = 0
        best_state: dict[str, Any] | None = None
        history: list[dict[str, Any]] = []

        for epoch in range(1, self.epochs + 1):
            train_loss = _train_one_epoch(
                model,
                train_loader,
                criterion,
                opt,
                device,
                self.gradient_clip,
            )
            val_loss = _evaluate_loss(model, val_loader, criterion, device)

            if sched is not None:
                from torch.optim.lr_scheduler import ReduceLROnPlateau

                if isinstance(sched, ReduceLROnPlateau):
                    sched.step(val_loss)
                else:
                    sched.step()

            history.append(
                {
                    "epoch": epoch,
                    "train_loss": train_loss,
                    "val_loss": val_loss,
                    "lr": opt.param_groups[0]["lr"],
                }
            )

            if math.isnan(train_loss) or math.isnan(val_loss):
                logger.error("NaN at epoch %d -- stopping", epoch)
                break

            if val_loss < best_val:
                best_val = val_loss
                patience_counter = 0
                best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            else:
                patience_counter += 1

            if patience_counter >= self.patience:
                logger.info("Early stopping at epoch %d", epoch)
                break

        # Restore best weights
        if best_state is not None:
            model.load_state_dict(best_state)

        model.eval()
        duration = time.time() - t0

        # Compute test metrics on validation set
        metrics: dict[str, float] = {"val_loss": best_val}

        self.model_ = model
        self.scaler_ = scaler
        self.result_ = ExperimentResult(
            name=f"pytorch-{self.architecture}",
            backend="pytorch",
            metrics=metrics,
            training_history=history,
            duration_seconds=duration,
            config=self.to_config(),
        )
        logger.info(
            "Trained %s in %.1fs -- val_loss=%.6f",
            self.architecture,
            duration,
            best_val,
        )
        return self

    # ------------------------------------------------------------------
    # _fit_panel -- placeholder dispatched from fit(); implemented in Phase 4
    # ------------------------------------------------------------------

    def _fit_panel(self, panel_data: Any, **kwargs: Any) -> Self:
        raise NotImplementedError(
            "Panel data training via fit(PanelData) is not yet available. "
            "Use the config-driven path: ml.run('experiment.yaml') with "
            "data.format='panel'."
        )

    # ------------------------------------------------------------------
    # _train -- config-driven path (used by run())
    # ------------------------------------------------------------------

    def _train(self, **data: Any) -> ExperimentResult:
        """Train via the PyTorch engine from a config dict."""
        if "experiment" not in data:
            raise ValueError(
                "Config-driven training requires an 'experiment' section. "
                "Use fit(X, y) for programmatic training."
            )

        from pycatalyst.ml.pytorch.config import PytorchExperimentConfig
        from pycatalyst.ml.pytorch.trainer import _train_impl

        config = PytorchExperimentConfig.from_raw(data)
        output = _train_impl(config)

        self.model_ = output.model
        self.scaler_ = output.scaler
        return output.result

    # ------------------------------------------------------------------
    # predict / _predict
    # ------------------------------------------------------------------

    def _predict(self, X: Any) -> np.ndarray:
        """Run inference using the fitted model and scaler."""
        import torch

        if self.model_ is None:
            raise RuntimeError("No fitted model. Call fit() or run() first.")

        from pycatalyst.ml.pytorch.device import get_device

        X = np.asarray(X, dtype=np.float32)
        device = get_device()

        # Scale
        if self.scaler_ is not None:
            orig_shape = X.shape
            X_2d = X.reshape(-1, X.shape[-1])
            X_2d = self.scaler_.transform(X_2d)
            X = X_2d.reshape(orig_shape)

        # Add batch dim if needed
        if X.ndim == 1:
            X = X.reshape(1, -1)

        tensor = torch.from_numpy(X).to(device=device, dtype=torch.float32)
        self.model_.to(device)
        self.model_.eval()
        with torch.no_grad():
            output = self.model_(tensor)
        return output.cpu().numpy()

    def _primary_metric(self) -> str:
        return "mse"

    # ------------------------------------------------------------------
    # save / load
    # ------------------------------------------------------------------

    def _save(self, directory: str | Path) -> dict[str, str]:
        """Save model, scaler, and trainer config to *directory*."""
        d = Path(directory)
        d.mkdir(parents=True, exist_ok=True)

        paths: dict[str, str] = {}

        if self.model_ is not None and hasattr(self.model_, "save"):
            model_paths = self.model_.save(d)
            paths.update(model_paths)

        if self.scaler_ is not None and hasattr(self.scaler_, "save"):
            scaler_path = d / "scaler.json"
            self.scaler_.save(scaler_path)
            paths["scaler"] = str(scaler_path)

        trainer_config = self.get_params(deep=False)
        config_path = d / "trainer_config.json"
        config_path.write_text(
            json.dumps(trainer_config, indent=2, default=str),
            encoding="utf-8",
        )
        paths["trainer_config"] = str(config_path)

        return paths

    @classmethod
    def _load(cls, directory: str | Path) -> PytorchTrainer:
        """Reconstruct a fitted PytorchTrainer from a saved directory."""
        d = Path(directory)

        config_path = d / "trainer_config.json"
        if not config_path.exists():
            raise FileNotFoundError(f"trainer_config.json not found in {d}")
        raw = json.loads(config_path.read_text(encoding="utf-8"))

        init_params = {
            "architecture": raw.get("architecture", "lstm"),
            "params": raw.get("params", {}),
            "epochs": raw.get("epochs", 100),
            "batch_size": raw.get("batch_size", 32),
            "learning_rate": raw.get("learning_rate", 1e-3),
            "optimizer": raw.get("optimizer", "adam"),
            "scheduler": raw.get("scheduler"),
            "gradient_clip": raw.get("gradient_clip", 1.0),
            "patience": raw.get("patience", 10),
            "seed": raw.get("seed", 42),
            "jit_export": raw.get("jit_export", False),
            "output_dir": raw.get("output_dir", str(d)),
        }
        trainer = cls(**init_params)

        from pycatalyst.ml.pytorch.data.scaling import Scaler
        from pycatalyst.ml.pytorch.models.base import TorchModel

        model_config = d / "model_config.json"
        model_weights = d / "model.pt"
        if model_config.exists() and model_weights.exists():
            trainer.model_ = TorchModel.load(d)

        scaler_path = d / "scaler.json"
        if scaler_path.exists():
            trainer.scaler_ = Scaler.load(scaler_path)

        trainer.result_ = ExperimentResult(name="loaded", backend="pytorch")
        return trainer

    # ------------------------------------------------------------------
    # Validation / introspection
    # ------------------------------------------------------------------

    def _validate_config(self, config: dict[str, Any]) -> None:
        if "experiment" not in config:
            raise ValueError("Config must have an 'experiment' section")
        if "data" not in config:
            raise ValueError("Config must have a 'data' section")
        if "model" not in config:
            raise ValueError("Config must have a 'model' section")

    @staticmethod
    def list_architectures() -> list[str]:
        """Return sorted list of available PyTorch architectures."""
        try:
            from pycatalyst.ml.pytorch.models.registry import MODEL_REGISTRY

            return sorted(MODEL_REGISTRY.keys())
        except ImportError:
            logger.warning("PyTorch not installed -- cannot list architectures")
            return []

    @classmethod
    def from_config(cls, config: dict[str, Any] | str | Path) -> PytorchTrainer:
        """Build a trainer from a config file or dict.

        If config has an ``experiment`` section (standard experiment YAML),
        maps experiment/model/training/serving sections to trainer kwargs.
        Otherwise delegates to the base implementation for flat configs.
        """
        from pycatalyst.ml.trainers.base import _load_config_file

        if isinstance(config, str | Path):
            cfg = _load_config_file(config)
        elif isinstance(config, dict):
            cfg = config
        elif hasattr(config, "model_dump"):
            cfg = config.model_dump()
        else:
            cfg = dict(config) if hasattr(config, "__iter__") else {}

        if "experiment" not in cfg:
            return super().from_config(cfg)  # type: ignore[return-value]

        exp = cfg.get("experiment") or {}
        model = cfg.get("model") or {}
        training = cfg.get("training") or {}
        early_stopping = training.get("early_stopping") or {}
        serving = cfg.get("serving") or {}

        kwargs: dict[str, Any] = {
            "architecture": model.get("architecture", "lstm"),
            "params": model.get("params") or {},
            "epochs": training.get("epochs", 100),
            "batch_size": training.get("batch_size", 32),
            "learning_rate": training.get("learning_rate", 1e-3),
            "optimizer": training.get("optimizer", "adam"),
            "scheduler": training.get("scheduler"),
            "gradient_clip": training.get("gradient_clip", 1.0),
            "patience": early_stopping.get("patience", 10),
            "seed": exp.get("seed", 42),
            "jit_export": serving.get("jit_export", False),
            "output_dir": exp.get("output_dir", "./runs/pytorch"),
        }
        trainer = cls(**kwargs)
        trainer._config_data = cfg  # noqa: SLF001
        return trainer


def _sliding_windows(
    features: np.ndarray,
    targets: np.ndarray,
    seq_len: int,
    stride: int = 1,
) -> tuple[np.ndarray, np.ndarray]:
    """Create sliding windows from 2-D feature and 1-D/2-D target arrays."""
    n = len(features)
    n_features = features.shape[1]
    if n <= seq_len:
        return (
            np.empty((0, seq_len, n_features), dtype=np.float32),
            np.empty((0, 1), dtype=np.float32),
        )

    indices = list(range(0, n - seq_len, stride))
    X = np.empty((len(indices), seq_len, n_features), dtype=np.float32)
    y = np.empty((len(indices), 1), dtype=np.float32)
    tgt = targets.ravel()

    for i, start in enumerate(indices):
        X[i] = features[start : start + seq_len]
        y[i, 0] = tgt[start + seq_len] if start + seq_len < n else tgt[-1]

    return X, y
