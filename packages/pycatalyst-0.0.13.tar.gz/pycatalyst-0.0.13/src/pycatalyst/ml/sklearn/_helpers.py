"""Shared helpers for the sklearn engine and SklearnTrainer.

Extracted from ``engine.py`` to keep both modules under 400 lines
and allow reuse from the trainer's sklearn-style data path.
"""

from __future__ import annotations

import logging
import random
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from pycatalyst.ml.io import load_dataframe as load_dataframe_from_uri

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Seeding
# ------------------------------------------------------------------


def seed_all(seed: int) -> None:
    """Set random seeds for reproducibility.

    Args:
        seed: Integer seed value.
    """
    random.seed(seed)
    np.random.seed(seed)  # noqa: NPY002


# ------------------------------------------------------------------
# Data loading
# ------------------------------------------------------------------


def load_dataframe(path: str) -> pd.DataFrame:
    """Load a CSV or Parquet file into a DataFrame.

    Args:
        path: File path (must end with ``.csv`` or ``.parquet``).

    Returns:
        Loaded DataFrame.
    """
    return load_dataframe_from_uri(path)


def handle_missing(df: pd.DataFrame, strategy: str) -> pd.DataFrame:
    """Handle missing values using the given strategy.

    Args:
        df: Input DataFrame.
        strategy: One of ``"drop"``, ``"mean"``, ``"median"``, ``"mode"``.

    Returns:
        DataFrame with missing values handled.
    """
    if strategy == "drop":
        return df.dropna()
    if strategy == "mean":
        return df.fillna(df.mean(numeric_only=True))
    if strategy == "median":
        return df.fillna(df.median(numeric_only=True))
    if strategy == "mode":
        return df.fillna(df.mode().iloc[0])
    return df


# ------------------------------------------------------------------
# Splitting
# ------------------------------------------------------------------


def split(
    X: np.ndarray,
    y: np.ndarray,
    strategy: str,
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
]:
    """Split arrays into train / val / test.

    Args:
        X: Feature array.
        y: Target array.
        strategy: ``"random"`` (shuffled) or ``"temporal"`` (ordered).
        train_ratio: Fraction for training.
        val_ratio: Fraction for validation.
        seed: Random seed for shuffling.

    Returns:
        Tuple of (X_train, X_val, X_test, y_train, y_val, y_test).
    """
    n = len(X)
    n_train = int(n * train_ratio)
    n_val = int(n * val_ratio)

    if strategy == "random":
        rng = np.random.RandomState(seed)  # noqa: NPY002
        idx = rng.permutation(n)
    else:
        idx = np.arange(n)

    train_idx = idx[:n_train]
    val_idx = idx[n_train : n_train + n_val]
    test_idx = idx[n_train + n_val :]

    return (
        X[train_idx],
        X[val_idx],
        X[test_idx],
        y[train_idx],
        y[val_idx],
        y[test_idx],
    )


# ------------------------------------------------------------------
# Scaling
# ------------------------------------------------------------------


def scale(
    X_train: np.ndarray,
    X_val: np.ndarray,
    X_test: np.ndarray,
    method: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Fit a scaler on train and transform all splits.

    Args:
        X_train: Training features.
        X_val: Validation features.
        X_test: Test features.
        method: One of ``"standard"``, ``"minmax"``, ``"robust"``,
            ``"none"``.

    Returns:
        Tuple of (scaled_train, scaled_val, scaled_test, scaler_params).
    """
    if method == "none":
        return X_train, X_val, X_test, {}

    if method == "standard":
        mean = X_train.mean(axis=0)
        std = X_train.std(axis=0)
        std[std == 0] = 1.0
        params = {"mean": mean.tolist(), "std": std.tolist()}
        return (
            (X_train - mean) / std,
            (X_val - mean) / std,
            (X_test - mean) / std,
            params,
        )

    if method == "minmax":
        mn = X_train.min(axis=0)
        mx = X_train.max(axis=0)
        denom = mx - mn
        denom[denom == 0] = 1.0
        params = {"min": mn.tolist(), "max": mx.tolist()}
        return (
            (X_train - mn) / denom,
            (X_val - mn) / denom,
            (X_test - mn) / denom,
            params,
        )

    if method == "robust":
        med = np.median(X_train, axis=0)
        iqr = np.percentile(X_train, 75, axis=0) - np.percentile(X_train, 25, axis=0)
        iqr[iqr == 0] = 1.0
        params = {"median": med.tolist(), "iqr": iqr.tolist()}
        return (
            (X_train - med) / iqr,
            (X_val - med) / iqr,
            (X_test - med) / iqr,
            params,
        )

    return X_train, X_val, X_test, {}


# ------------------------------------------------------------------
# Metrics
# ------------------------------------------------------------------


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    names: list[str],
    task: str = "regression",
    y_proba: np.ndarray | None = None,
) -> dict[str, float]:
    """Compute evaluation metrics.

    Args:
        y_true: Ground-truth values or labels.
        y_pred: Predicted values or labels.
        names: Metric names to compute.
        task: ``"regression"`` or ``"classification"``.
        y_proba: For classification, optional predicted probabilities (n_samples, n_classes).

    Returns:
        Dict mapping metric name to value.
    """
    out: dict[str, float] = {}

    if task == "classification":
        from sklearn.metrics import (
            accuracy_score,
            f1_score,
            precision_score,
            recall_score,
            roc_auc_score,
        )

        for name in names:
            if name == "accuracy":
                out["accuracy"] = float(accuracy_score(y_true, y_pred))
            elif name == "precision" or name == "precision_macro":
                out["precision_macro"] = float(
                    precision_score(y_true, y_pred, average="macro", zero_division=0)
                )
            elif name == "precision_weighted":
                out["precision_weighted"] = float(
                    precision_score(y_true, y_pred, average="weighted", zero_division=0)
                )
            elif name == "recall" or name == "recall_macro":
                out["recall_macro"] = float(
                    recall_score(y_true, y_pred, average="macro", zero_division=0)
                )
            elif name == "recall_weighted":
                out["recall_weighted"] = float(
                    recall_score(y_true, y_pred, average="weighted", zero_division=0)
                )
            elif name == "f1" or name == "f1_macro":
                out["f1_macro"] = float(
                    f1_score(y_true, y_pred, average="macro", zero_division=0)
                )
            elif name == "f1_weighted":
                out["f1_weighted"] = float(
                    f1_score(y_true, y_pred, average="weighted", zero_division=0)
                )
            elif name == "roc_auc" and y_proba is not None:
                try:
                    n_classes = y_proba.shape[1]
                    if n_classes == 2:
                        out["roc_auc"] = float(roc_auc_score(y_true, y_proba[:, 1]))
                    else:
                        out["roc_auc_ovr"] = float(
                            roc_auc_score(
                                y_true, y_proba, multi_class="ovr", average="macro"
                            )
                        )
                        out["roc_auc_ovo"] = float(
                            roc_auc_score(
                                y_true, y_proba, multi_class="ovo", average="macro"
                            )
                        )
                except ValueError:
                    pass
            else:
                logger.warning("Unknown or unsupported classification metric %r", name)
        return out

    # Regression
    for name in names:
        if name == "mse":
            out["mse"] = float(np.mean((y_true - y_pred) ** 2))
        elif name == "mae":
            out["mae"] = float(np.mean(np.abs(y_true - y_pred)))
        elif name == "rmse":
            out["rmse"] = float(np.sqrt(np.mean((y_true - y_pred) ** 2)))
        elif name == "r2":
            ss_res = np.sum((y_true - y_pred) ** 2)
            ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
            out["r2"] = float(1 - ss_res / ss_tot) if ss_tot != 0 else 0.0
        elif name == "mape":
            mask = y_true != 0
            if mask.any():
                out["mape"] = float(
                    np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
                )
        elif name == "accuracy":
            out["accuracy"] = float(np.mean(y_true == y_pred))
        else:
            logger.warning("Unknown metric %r — skipping", name)
    return out


# ------------------------------------------------------------------
# Plots
# ------------------------------------------------------------------


def generate_plots(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model: Any,
    feature_names: list[str],
    plot_names: list[str],
    plot_dir: Path,
    task: str = "regression",
    y_proba: np.ndarray | None = None,
) -> dict[str, str]:
    """Generate evaluation plots and save to disk.

    Args:
        y_true: Ground-truth values or labels.
        y_pred: Predicted values or labels.
        model: Fitted sklearn model (used for feature_importance).
        feature_names: List of feature column names.
        plot_names: Plot types to generate.
        plot_dir: Directory to save plots.
        task: ``"regression"`` or ``"classification"``.
        y_proba: For classification, optional predicted probabilities (for ROC).

    Returns:
        Dict mapping plot name to file path.
    """
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        logger.warning("matplotlib not installed — skipping plots")
        return {}

    paths: dict[str, str] = {}

    for name in plot_names:
        if task == "classification" and name in ("predicted_vs_actual", "residuals"):
            continue
        if task == "regression" and name in ("confusion_matrix", "roc_curve"):
            continue

        if name == "predicted_vs_actual":
            fig, ax = plt.subplots(figsize=(8, 8))
            ax.scatter(y_true, y_pred, alpha=0.4, s=10)
            lims = [
                min(y_true.min(), y_pred.min()),
                max(y_true.max(), y_pred.max()),
            ]
            ax.plot(lims, lims, "r--", alpha=0.6, label="y = x")
            ax.set_xlabel("Actual")
            ax.set_ylabel("Predicted")
            ax.set_title("Predicted vs Actual")
            ax.legend()
            ax.grid(True, alpha=0.3)
            p = plot_dir / "predicted_vs_actual.png"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            plt.close(fig)
            paths[name] = str(p)

        elif name == "confusion_matrix" and task == "classification":
            from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix

            cm = confusion_matrix(y_true, y_pred)
            fig, ax = plt.subplots(figsize=(8, 8))
            disp = ConfusionMatrixDisplay(confusion_matrix=cm)
            disp.plot(ax=ax)
            p = plot_dir / "confusion_matrix.png"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            plt.close(fig)
            paths[name] = str(p)

        elif name == "roc_curve" and task == "classification" and y_proba is not None:
            from sklearn.metrics import roc_curve

            n_classes = y_proba.shape[1]
            if n_classes == 2:
                fpr, tpr, _ = roc_curve(y_true, y_proba[:, 1], pos_label=1)
                fig, ax = plt.subplots(figsize=(6, 6))
                ax.plot(fpr, tpr)
                ax.plot([0, 1], [0, 1], "k--")
                ax.set_xlabel("False Positive Rate")
                ax.set_ylabel("True Positive Rate")
                ax.set_title("ROC Curve")
                ax.grid(True, alpha=0.3)
                p = plot_dir / "roc_curve.png"
                fig.savefig(p, dpi=150, bbox_inches="tight")
                plt.close(fig)
                paths[name] = str(p)
            else:
                fig, ax = plt.subplots(figsize=(6, 6))
                for i in range(n_classes):
                    fpr, tpr, _ = roc_curve(
                        (np.asarray(y_true) == i).astype(int), y_proba[:, i]
                    )
                    ax.plot(fpr, tpr, label=f"Class {i}")
                ax.plot([0, 1], [0, 1], "k--")
                ax.set_xlabel("False Positive Rate")
                ax.set_ylabel("True Positive Rate")
                ax.set_title("ROC Curves (One-vs-Rest)")
                ax.legend()
                ax.grid(True, alpha=0.3)
                p = plot_dir / "roc_curve.png"
                fig.savefig(p, dpi=150, bbox_inches="tight")
                plt.close(fig)
                paths[name] = str(p)

        elif name == "feature_importance":
            importance = getattr(model, "feature_importances_", None)
            if importance is None:
                continue
            idx = np.argsort(importance)[::-1]
            n_features = len(feature_names)
            fig, ax = plt.subplots(figsize=(10, max(4, n_features * 0.3)))
            ax.barh(
                [feature_names[i] for i in reversed(idx)],
                importance[list(reversed(idx))],
            )
            ax.set_xlabel("Importance")
            ax.set_title("Feature Importance")
            ax.grid(True, alpha=0.3, axis="x")
            p = plot_dir / "feature_importance.png"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            plt.close(fig)
            paths[name] = str(p)

        elif name == "residuals":
            residuals = y_true - y_pred
            fig, ax = plt.subplots(figsize=(10, 5))
            ax.hist(residuals, bins=50, edgecolor="black", alpha=0.7)
            ax.set_xlabel("Residual")
            ax.set_ylabel("Frequency")
            ax.set_title("Residual Distribution")
            ax.grid(True, alpha=0.3)
            p = plot_dir / "residuals.png"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            plt.close(fig)
            paths[name] = str(p)

        else:
            logger.warning("Unknown plot %r — skipping", name)

    return paths
