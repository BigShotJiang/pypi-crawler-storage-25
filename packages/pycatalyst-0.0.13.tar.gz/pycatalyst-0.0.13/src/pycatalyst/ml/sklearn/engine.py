"""Sklearn engine — load, split, fit, cross-val, evaluate, save.

The heavy helper functions (split, scale, metrics, plots) are in
``_helpers.py`` to keep both modules under the 400-line limit.
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import numpy as np

from pycatalyst.ml.results import ExperimentResult
from pycatalyst.ml.sklearn._helpers import (
    compute_metrics,
    generate_plots,
    handle_missing,
    load_dataframe,
    scale,
    seed_all,
    split,
)
from pycatalyst.ml.sklearn.config import SklearnExperimentConfig

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Model registry
# ------------------------------------------------------------------

_MODEL_REGISTRY: dict[str, Any] = {}


def _populate_registry() -> None:
    """Lazily populate the registry on first use (regressors and classifiers)."""
    if _MODEL_REGISTRY:
        return

    from sklearn.ensemble import (
        AdaBoostRegressor,
        GradientBoostingRegressor,
        RandomForestRegressor,
    )
    from sklearn.linear_model import Lasso, LinearRegression, Ridge
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.svm import SVR
    from sklearn.tree import DecisionTreeRegressor

    _MODEL_REGISTRY.update(
        {
            "linear_regression": LinearRegression,
            "ridge": Ridge,
            "lasso": Lasso,
            "decision_tree": DecisionTreeRegressor,
            "random_forest": RandomForestRegressor,
            "gradient_boosting": GradientBoostingRegressor,
            "adaboost": AdaBoostRegressor,
            "svm": SVR,
            "knn": KNeighborsRegressor,
        }
    )

    try:
        from sklearn.ensemble import HistGradientBoostingRegressor

        _MODEL_REGISTRY["hist_gradient_boosting"] = HistGradientBoostingRegressor
    except ImportError:
        pass

    # Classifiers (same registry; distinct names)
    from sklearn.ensemble import (
        AdaBoostClassifier,
        GradientBoostingClassifier,
        RandomForestClassifier,
    )
    from sklearn.linear_model import LogisticRegression
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.svm import SVC
    from sklearn.tree import DecisionTreeClassifier

    _MODEL_REGISTRY.update(
        {
            "logistic_regression": LogisticRegression,
            "random_forest_classifier": RandomForestClassifier,
            "gradient_boosting_classifier": GradientBoostingClassifier,
            "adaboost_classifier": AdaBoostClassifier,
            "svc": SVC,
            "knn_classifier": KNeighborsClassifier,
            "decision_tree_classifier": DecisionTreeClassifier,
        }
    )

    try:
        from sklearn.ensemble import HistGradientBoostingClassifier

        _MODEL_REGISTRY["hist_gradient_boosting_classifier"] = (
            HistGradientBoostingClassifier
        )
    except ImportError:
        pass


def list_architectures() -> list[str]:
    """Return sorted list of registered sklearn architecture names."""
    _populate_registry()
    return sorted(_MODEL_REGISTRY.keys())


def get_model_class(architecture: str) -> Any:
    """Look up an sklearn model class by architecture name.

    Args:
        architecture: Registered model name (e.g. ``"ridge"``).

    Returns:
        The sklearn estimator class.

    Raises:
        ValueError: If *architecture* is not registered.
    """
    _populate_registry()
    cls = _MODEL_REGISTRY.get(architecture)
    if cls is None:
        raise ValueError(
            f"Unknown architecture {architecture!r}. Registered: {list_architectures()}"
        )
    return cls


# ------------------------------------------------------------------
# Public entry point
# ------------------------------------------------------------------


def train(
    config: SklearnExperimentConfig,
    *,
    on_progress: Callable[[int, dict[str, float]], None] | None = None,
) -> ExperimentResult:
    """Run a full sklearn experiment."""
    t0 = time.time()
    seed_all(config.experiment.seed)

    output_dir = Path(config.experiment.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- Data ---
    df = load_dataframe(config.data.path)
    df = handle_missing(df, config.data.handle_missing)

    target = config.data.target
    if target not in df.columns:
        raise ValueError(
            f"Target column {target!r} not found. Available: {list(df.columns)}"
        )

    feature_cols = config.data.features or [c for c in df.columns if c != target]
    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Feature columns not found: {missing}")

    task = getattr(config.experiment, "task", "regression") or "regression"

    X = df[feature_cols].values.astype(np.float64)
    y_raw = df[target]
    if task == "classification":
        from sklearn.preprocessing import LabelEncoder

        le = LabelEncoder()
        y = le.fit_transform(y_raw)
        n_classes = len(le.classes_)
    else:
        le = None
        y = y_raw.values.astype(np.float64)

    X_train, X_val, X_test, y_train, y_val, y_test = split(
        X,
        y,
        config.data.split.strategy,
        config.data.split.train,
        config.data.split.val,
        config.experiment.seed,
    )

    # --- Scaling ---
    X_train, X_val, X_test, scaler_params = scale(
        X_train,
        X_val,
        X_test,
        config.data.scaler,
    )

    scaler_path = output_dir / "scaler.json"
    scaler_path.write_text(
        json.dumps(
            {"method": config.data.scaler, "params": scaler_params},
            indent=2,
        ),
        encoding="utf-8",
    )

    cv_results: dict[str, Any] = {}
    cv_config = config.training.cross_validation
    search_config = getattr(config.training, "search", None)
    run_standalone_cv = cv_config.enabled and (
        search_config is None
        or not (search_config.param_grid or search_config.param_distributions)
    )

    # --- Model ---
    model_cls = get_model_class(config.model.architecture)
    base_estimator = model_cls(**config.model.params)

    scoring = config.training.cross_validation.scoring
    if task == "classification" and scoring == "neg_mean_squared_error":
        scoring = "accuracy"

    search_config = getattr(config.training, "search", None)
    if search_config is not None and (
        search_config.param_grid or search_config.param_distributions
    ):
        from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

        cv_folds = config.training.cross_validation.folds
        if search_config.strategy == "grid" and search_config.param_grid:
            search = GridSearchCV(
                base_estimator,
                param_grid=search_config.param_grid,
                scoring=scoring,
                refit=True,
                cv=cv_folds,
            )
        else:
            if not search_config.param_distributions:
                raise ValueError(
                    "Random search requires training.search.param_distributions"
                )
            search = RandomizedSearchCV(
                base_estimator,
                param_distributions=search_config.param_distributions,
                n_iter=search_config.n_iter,
                scoring=scoring,
                refit=True,
                cv=cv_folds,
            )
        X_fit = np.concatenate([X_train, X_val])
        y_fit = np.concatenate([y_train, y_val])
        logger.info(
            "Running %s search (%s) with cv=%s",
            search_config.strategy,
            scoring,
            cv_folds,
        )
        search.fit(X_fit, y_fit)
        model = search.best_estimator_
        cv_results["best_cv_score"] = float(search.best_score_)
        cv_results["best_params"] = search.best_params_
        logger.info(
            "Best CV score: %.4f, best params: %s",
            search.best_score_,
            search.best_params_,
        )
    else:
        model = base_estimator
        logger.info(
            "Training %s with params %s",
            config.model.architecture,
            config.model.params,
        )
        model.fit(X_train, y_train)

    # --- Cross-validation (standalone CV when search not used) ---
    if run_standalone_cv:
        from sklearn.model_selection import cross_val_score

        scoring = cv_config.scoring
        if task == "classification" and scoring == "neg_mean_squared_error":
            scoring = "accuracy"
        scores = cross_val_score(
            model_cls(**config.model.params),
            np.concatenate([X_train, X_val]),
            np.concatenate([y_train, y_val]),
            cv=cv_config.folds,
            scoring=scoring,
        )
        cv_results = {
            "cv_mean": float(scores.mean()),
            "cv_std": float(scores.std()),
            "cv_scores": scores.tolist(),
        }
        logger.info(
            "CV %s: %.4f ± %.4f",
            scoring,
            scores.mean(),
            scores.std(),
        )

    # --- Evaluate ---
    y_pred_test = model.predict(X_test)
    y_proba_test: np.ndarray | None = None
    if task == "classification" and hasattr(model, "predict_proba"):
        y_proba_test = model.predict_proba(X_test)

    metrics = compute_metrics(
        y_test,
        y_pred_test,
        config.evaluation.metrics,
        task=task,
        y_proba=y_proba_test,
    )
    metrics.update(cv_results)

    if on_progress is not None:
        numeric_metrics = {
            k: v for k, v in metrics.items() if isinstance(v, int | float)
        }
        on_progress(0, numeric_metrics)

    metrics_path = output_dir / "metrics.json"
    metrics_path.write_text(
        json.dumps(
            metrics,
            indent=2,
            default=lambda x: float(x) if hasattr(x, "item") else str(x),
        ),
        encoding="utf-8",
    )
    logger.info(
        "Metrics: %s",
        {k: v for k, v in metrics.items() if isinstance(v, float)},
    )

    # --- Plots ---
    plot_dir = output_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    plot_paths = generate_plots(
        y_test,
        y_pred_test,
        model,
        feature_cols,
        config.evaluation.plots,
        plot_dir,
        task=task,
        y_proba=y_proba_test,
    )

    # --- Save model ---
    import joblib

    model_path = output_dir / "model.joblib"
    joblib.dump(model, model_path)

    config_path = output_dir / "model_config.json"
    config_payload: dict[str, Any] = {
        "architecture": config.model.architecture,
        "params": config.model.params,
        "features": feature_cols,
        "target": target,
        "task": task,
    }
    if task == "classification" and le is not None:
        config_payload["classes_"] = le.classes_.tolist()
    config_path.write_text(
        json.dumps(config_payload, indent=2),
        encoding="utf-8",
    )

    duration = time.time() - t0

    artifacts = {
        "model": str(model_path),
        "config": str(config_path),
        "scaler": str(scaler_path),
        "metrics": str(metrics_path),
    }
    for name, path in plot_paths.items():
        artifacts[f"plot_{name}"] = path

    return ExperimentResult(
        name=config.experiment.name,
        backend="sklearn",
        metrics={k: v for k, v in metrics.items() if isinstance(v, int | float)},
        artifacts=artifacts,
        training_history=[],
        duration_seconds=duration,
    )
