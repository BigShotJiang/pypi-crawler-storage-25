"""Text data loading and tokenization for LLM fine-tuning."""

from __future__ import annotations

import json
import logging
from typing import Any

from pycatalyst.ml.huggingface.config import HFExperimentConfig
from pycatalyst.ml.io import load_dataframe as load_dataframe_from_uri
from pycatalyst.ml.io import read_text

logger = logging.getLogger(__name__)

# Prompt templates per data format
_INSTRUCTION_TEMPLATE = (
    "### Instruction:\n{instruction}\n\n### Input:\n{input}\n\n### Response:\n{output}"
)

_COMPLETION_TEMPLATE = "{text}"

_CHAT_SYSTEM = "You are a helpful assistant."


def load_and_tokenize(
    config: HFExperimentConfig,
    tokenizer: Any,
) -> tuple[Any, Any]:
    """Load data, format prompts, tokenize, and return train/val HF Datasets.

    Returns:
        (train_dataset, val_dataset) — both are HuggingFace ``Dataset`` objects
        with ``input_ids``, ``attention_mask``, and ``labels`` columns.
    """
    from datasets import Dataset

    records = _load_records(config.data.path)
    texts = [_format_record(r, config.data.format) for r in records]

    if not texts:
        raise ValueError(f"No records found in {config.data.path}")
    logger.info("Loaded %d records from %s", len(texts), config.data.path)

    ds = Dataset.from_dict({"text": texts})

    split = ds.train_test_split(
        test_size=config.data.val_split, seed=config.experiment.seed
    )
    train_ds = split["train"]
    val_ds = split["test"]

    max_len = config.data.max_length

    def tokenize_fn(examples: dict[str, list]) -> dict[str, list]:
        out = tokenizer(
            examples["text"],
            truncation=True,
            max_length=max_len,
            padding="max_length",
        )
        out["labels"] = out["input_ids"].copy()
        return out

    train_ds = train_ds.map(tokenize_fn, batched=True, remove_columns=["text"])
    val_ds = val_ds.map(tokenize_fn, batched=True, remove_columns=["text"])

    train_ds.set_format("torch")
    val_ds.set_format("torch")

    return train_ds, val_ds


def _load_records(path: str) -> list[dict[str, Any]]:
    lowered = path.lower()
    if lowered.endswith(".jsonl"):
        lines = read_text(path, encoding="utf-8").strip().splitlines()
        return [json.loads(line) for line in lines if line.strip()]
    if lowered.endswith(".json"):
        data = json.loads(read_text(path, encoding="utf-8"))
        return data if isinstance(data, list) else [data]
    if lowered.endswith(".csv"):
        return load_dataframe_from_uri(path).to_dict("records")
    raise ValueError(
        "Unsupported data format. Use .json, .jsonl, or .csv in data.path."
    )


def _format_record(record: dict[str, Any], fmt: str) -> str:
    if fmt == "instruction":
        return _INSTRUCTION_TEMPLATE.format(
            instruction=record.get("instruction", ""),
            input=record.get("input", ""),
            output=record.get("output", ""),
        )
    if fmt == "completion":
        return _COMPLETION_TEMPLATE.format(text=record.get("text", ""))
    if fmt == "chat":
        messages = record.get("messages", [])
        if not messages:
            messages = [
                {"role": "system", "content": _CHAT_SYSTEM},
                {"role": "user", "content": record.get("instruction", "")},
                {"role": "assistant", "content": record.get("output", "")},
            ]
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            parts.append(f"<|{role}|>\n{content}")
        return "\n".join(parts)

    raise ValueError(f"Unknown data format: {fmt!r}")
