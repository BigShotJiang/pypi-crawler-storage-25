"""HuggingFace engine — PEFT/LoRA fine-tuning with HF Trainer."""

from __future__ import annotations

import json
import logging
import math
import random
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import numpy as np

from pycatalyst.ml.huggingface.config import HFExperimentConfig
from pycatalyst.ml.results import ExperimentResult

logger = logging.getLogger(__name__)


def train(
    config: HFExperimentConfig,
    *,
    on_progress: Callable[[int, dict[str, float]], None] | None = None,
) -> ExperimentResult:
    """Run a full HuggingFace fine-tuning experiment."""
    import torch
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        Trainer,
        TrainingArguments,
    )

    t0 = time.time()
    _seed_all(config.experiment.seed)

    output_dir = Path(config.experiment.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- Tokenizer ---
    tokenizer = AutoTokenizer.from_pretrained(config.model.base_model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # --- Data ---
    from pycatalyst.ml.huggingface.data import load_and_tokenize

    train_ds, val_ds = load_and_tokenize(config, tokenizer)
    logger.info("Train: %d samples, Val: %d samples", len(train_ds), len(val_ds))

    # --- Model ---
    model_kwargs: dict[str, Any] = {}
    quant = config.model.quantization

    if quant is not None:
        from transformers import BitsAndBytesConfig

        if quant == "4bit":
            model_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4",
            )
        elif quant == "8bit":
            model_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_8bit=True,
            )

    model = AutoModelForCausalLM.from_pretrained(
        config.model.base_model,
        torch_dtype=torch.bfloat16 if quant is None else None,
        device_map="auto",
        **model_kwargs,
    )

    # --- LoRA / QLoRA ---
    if config.model.adapter in ("lora", "qlora"):
        from peft import LoraConfig, TaskType, get_peft_model

        lora_cfg = LoraConfig(
            r=config.model.params.r,
            lora_alpha=config.model.params.lora_alpha,
            lora_dropout=config.model.params.lora_dropout,
            target_modules=config.model.params.target_modules,
            task_type=TaskType.CAUSAL_LM,
            bias="none",
        )
        model = get_peft_model(model, lora_cfg)
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        total = sum(p.numel() for p in model.parameters())
        logger.info(
            "LoRA applied: trainable=%s / %s (%.2f%%)",
            trainable,
            total,
            100 * trainable / total,
        )

    # --- Training args ---
    mp = config.training.mixed_precision
    training_args = TrainingArguments(
        output_dir=str(output_dir / "checkpoints"),
        num_train_epochs=config.training.epochs,
        per_device_train_batch_size=config.training.batch_size,
        per_device_eval_batch_size=config.training.batch_size,
        gradient_accumulation_steps=config.training.gradient_accumulation_steps,
        learning_rate=config.training.learning_rate,
        warmup_ratio=config.training.warmup_ratio,
        max_grad_norm=config.training.max_grad_norm,
        fp16=(mp == "fp16"),
        bf16=(mp == "bf16"),
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        logging_steps=10,
        logging_dir=str(output_dir / "logs"),
        report_to="none",
        seed=config.experiment.seed,
        remove_unused_columns=False,
    )

    # --- Trainer ---
    callbacks: list[Any] = []
    if on_progress is not None:
        from transformers import TrainerCallback

        class _ProgressCallback(TrainerCallback):
            def __init__(self, cb: Callable[[int, dict[str, float]], None]) -> None:
                self._cb = cb

            def on_evaluate(
                self,
                args: Any,
                state: Any,
                control: Any,
                metrics: dict[str, float] | None = None,
                **kwargs: Any,
            ) -> None:
                m = metrics or kwargs.get("metrics") or {}
                if not m:
                    return
                epoch = int(round(state.epoch)) if state.epoch is not None else 0
                numeric = {
                    k: float(v) for k, v in m.items() if isinstance(v, int | float)
                }
                if numeric:
                    self._cb(epoch, numeric)

        callbacks.append(_ProgressCallback(on_progress))

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        tokenizer=tokenizer,  # type: ignore[call-arg]
        callbacks=callbacks,
    )

    train_result = trainer.train()
    logger.info("Training done: %s", train_result.metrics)

    # --- Evaluate ---
    eval_result = trainer.evaluate()
    logger.info("Eval metrics: %s", eval_result)

    metrics: dict[str, float] = {}
    for name in config.evaluation.metrics:
        if name == "eval_loss":
            metrics["eval_loss"] = eval_result.get("eval_loss", 0.0)
        elif name == "perplexity":
            loss = eval_result.get("eval_loss", 0.0)
            metrics["perplexity"] = math.exp(loss) if loss < 100 else float("inf")

    metrics_path = output_dir / "metrics.json"
    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    # --- Save ---
    model.save_pretrained(str(output_dir / "adapter"))
    tokenizer.save_pretrained(str(output_dir / "tokenizer"))

    config_path = output_dir / "experiment_config.json"
    config_path.write_text(
        json.dumps(config.model_dump(), indent=2, default=str),
        encoding="utf-8",
    )

    # --- Build history from trainer log ---
    history: list[dict] = []
    for entry in trainer.state.log_history:
        h: dict[str, Any] = {}
        if "loss" in entry:
            h["train_loss"] = entry["loss"]
        if "eval_loss" in entry:
            h["eval_loss"] = entry["eval_loss"]
        if "epoch" in entry:
            h["epoch"] = entry["epoch"]
        if h:
            history.append(h)

    history_path = output_dir / "history.json"
    history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")

    duration = time.time() - t0

    return ExperimentResult(
        name=config.experiment.name,
        backend="huggingface",
        metrics=metrics,
        artifacts={
            "adapter": str(output_dir / "adapter"),
            "tokenizer": str(output_dir / "tokenizer"),
            "config": str(config_path),
            "metrics": str(metrics_path),
            "history": str(history_path),
        },
        training_history=history,
        duration_seconds=duration,
    )


def _seed_all(seed: int) -> None:
    import torch

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        from transformers import set_seed

        set_seed(seed)
    except ImportError:
        pass
