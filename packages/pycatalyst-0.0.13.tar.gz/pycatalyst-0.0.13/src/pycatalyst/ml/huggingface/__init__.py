"""PyCatalyst HuggingFace engine — config-driven LLM fine-tuning with LoRA/QLoRA."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pycatalyst.ml.results import ExperimentResult


def run(
    raw: dict[str, Any],
    *,
    on_progress: Callable[[int, dict[str, float]], None] | None = None,
) -> ExperimentResult:
    """Entry point for the HuggingFace engine."""
    from pycatalyst.ml.huggingface.config import HFExperimentConfig
    from pycatalyst.ml.huggingface.engine import train

    config = HFExperimentConfig.from_raw(raw)
    return train(config, on_progress=on_progress)
