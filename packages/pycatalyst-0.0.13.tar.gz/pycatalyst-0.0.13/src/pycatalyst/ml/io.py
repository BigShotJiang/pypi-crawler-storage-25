"""I/O helpers for loading ML training data from local paths or S3 URIs."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

import pandas as pd

from pycatalyst.config.aws import get_aws_profile, get_aws_s3_client_config


def is_s3_uri(path: str) -> bool:
    """Return True when a path is an S3 URI."""
    return path.startswith("s3://")


def parse_s3_uri(uri: str) -> tuple[str, str]:
    """Parse an ``s3://bucket/key`` URI into (bucket, key)."""
    if not is_s3_uri(uri):
        raise ValueError(f"Not an S3 URI: {uri!r}")
    without_scheme = uri[5:]
    if "/" not in without_scheme:
        raise ValueError(f"Invalid S3 URI (missing key): {uri!r}")
    bucket, key = without_scheme.split("/", 1)
    if not bucket or not key:
        raise ValueError(f"Invalid S3 URI: {uri!r}")
    return bucket, key


def read_binary(path: str) -> bytes:
    """Read bytes from local filesystem or S3."""
    if is_s3_uri(path):
        try:
            import boto3  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(
                "S3 input requires boto3. Install with: pip install boto3"
            ) from exc
        bucket, key = parse_s3_uri(path)
        client_kwargs = get_aws_s3_client_config()
        profile = get_aws_profile()
        if profile and "aws_access_key_id" not in client_kwargs:
            session = boto3.session.Session(profile_name=profile)
            client = session.client("s3", **client_kwargs)
        else:
            client = boto3.client("s3", **client_kwargs)
        response = client.get_object(Bucket=bucket, Key=key)
        body = response["Body"].read()
        if not isinstance(body, bytes | bytearray):
            raise ValueError(f"Unexpected S3 body type for {path!r}")
        return bytes(body)
    return Path(path).read_bytes()


def read_text(path: str, encoding: str = "utf-8") -> str:
    """Read UTF-8 text from local filesystem or S3."""
    return read_binary(path).decode(encoding)


def load_dataframe(path: str) -> pd.DataFrame:
    """Load CSV/Parquet DataFrame from local filesystem or S3."""
    lowered = path.lower()
    if is_s3_uri(path):
        data = BytesIO(read_binary(path))
        if lowered.endswith(".parquet"):
            return pd.read_parquet(data)
        return pd.read_csv(data)
    if lowered.endswith(".parquet"):
        return pd.read_parquet(path)
    return pd.read_csv(path)
