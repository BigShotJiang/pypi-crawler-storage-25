"""pycatalyst — a schema-aware data generation and testing platform."""

from __future__ import annotations

try:
    from importlib.metadata import version

    __version__ = version("pycatalyst")
except Exception:
    __version__ = "0.1.0"

# -- Core types --
# -- Protocols --
from pycatalyst._protocols import (
    Generator,
    SchemaInferrer,
)
from pycatalyst._types import (
    Distribution,
    FieldConstraints,
    FieldQuality,
    FieldSpec,
    FieldType,
    GenerationResult,
    SchemaSpec,
)

# -- Errors --
from pycatalyst.errors import (
    CatalystError,
    ConfigError,
    ConstraintViolationError,
    ErrorCode,
    GenerationError,
    GeneratorNotFoundError,
    InferenceError,
    RecipeError,
    SchemaError,
)

# -- Generators --
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.generators.registry import GeneratorRegistry

# -- Mock DSL --
from pycatalyst.mockdsl import (
    MockModel,
    array,
    bool_,
    date,
    datetime,
    enum,
    float_,
    int_,
    mock,
    object_,
    string,
    uuid,
)
from pycatalyst.schema.inferrer import infer_from_file, infer_from_records
from pycatalyst.schema.json_schema import from_json_schema
from pycatalyst.schema.pydantic import from_pydantic_model
from pycatalyst.schema.spec import SchemaBuilder
from pycatalyst.streaming import (
    StreamLimits,
    clamp_stream_params,
    stream_records,
)
from pycatalyst.streaming.formats import ndjson_line, sse_event

__all__ = [
    "__version__",
    # Types
    "Distribution",
    "FieldConstraints",
    "FieldQuality",
    "FieldSpec",
    "FieldType",
    "GenerationResult",
    "SchemaSpec",
    # Protocols
    "Generator",
    "SchemaInferrer",
    # Errors
    "CatalystError",
    "ConfigError",
    "ConstraintViolationError",
    "ErrorCode",
    "GenerationError",
    "GeneratorNotFoundError",
    "InferenceError",
    "RecipeError",
    "SchemaError",
    # Generators
    "GenerationEngine",
    "GeneratorRegistry",
    "StreamLimits",
    "clamp_stream_params",
    "ndjson_line",
    "sse_event",
    "stream_records",
    # Schema
    "SchemaBuilder",
    "from_json_schema",
    "from_pydantic_model",
    "infer_from_file",
    "infer_from_records",
    # Mock DSL
    "MockModel",
    "array",
    "bool_",
    "date",
    "datetime",
    "enum",
    "float_",
    "int_",
    "mock",
    "object_",
    "string",
    "uuid",
]
