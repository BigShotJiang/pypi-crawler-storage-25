"""In-memory catalyst store implementation.

Dict-based store keyed by natural keys per entity type.
Useful for testing and development — all data is lost on destroy.
"""

from __future__ import annotations

import copy
import uuid
from typing import Any

from pycatalyst.catalyst_store.client import CatalystStoreClient


class InMemoryCatalystStore(CatalystStoreClient):
    """In-memory catalyst store backed by plain dictionaries.

    Keys:
        experiments  — ``(name, backend)``
        recipes      — ``(name, version)``
        schema_specs — ``name``
        generation_runs — ``run_id`` (UUID string)
    """

    def __init__(self) -> None:
        """Initialize in-memory store with empty collections."""
        super().__init__()
        self._experiments: dict[tuple[str, str], dict[str, Any]] = {}
        self._recipes: dict[tuple[str, str], dict[str, Any]] = {}
        self._schema_specs: dict[str, dict[str, Any]] = {}
        self._generation_runs: dict[str, dict[str, Any]] = {}
        self._artifacts: dict[tuple[str, str], bytes] = {}

    def connect(self) -> None:
        """No-op for in-memory store."""
        self._connection = "connected"

    def disconnect(self) -> None:
        """No-op for in-memory store."""
        self._connection = None

    # -- Experiment CRUD -----------------------------------------------------

    def store_experiment(
        self,
        name: str,
        backend: str,
        experiment: dict[str, Any],
    ) -> str:
        """Store an experiment. Returns synthetic ID ``name:backend``."""
        entry = copy.deepcopy(experiment)
        entry.setdefault("name", name)
        entry.setdefault("backend", backend)
        self._experiments[(name, backend)] = entry
        return f"{name}:{backend}"

    def get_experiment(self, name: str, backend: str) -> dict[str, Any] | None:
        """Retrieve an experiment by (name, backend)."""
        entry = self._experiments.get((name, backend))
        return copy.deepcopy(entry) if entry is not None else None

    def list_experiments(
        self,
        backend: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List experiments with optional filters."""
        results: list[dict[str, Any]] = []
        for (_n, b), exp in self._experiments.items():
            if backend and b != backend:
                continue
            if status and exp.get("status") != status:
                continue
            results.append(copy.deepcopy(exp))
        return results

    def delete_experiment(self, experiment_id: str) -> bool:
        """Delete experiment by ID (``name:backend``)."""
        parts = experiment_id.split(":", 1)
        if len(parts) != 2:
            return False
        key = (parts[0], parts[1])
        return self._experiments.pop(key, None) is not None

    # -- Recipe CRUD ---------------------------------------------------------

    def store_recipe(
        self,
        name: str,
        version: str,
        recipe: dict[str, Any],
    ) -> str:
        """Store a recipe. Returns synthetic ID ``name:version``."""
        entry = copy.deepcopy(recipe)
        entry.setdefault("name", name)
        entry.setdefault("version", version)
        self._recipes[(name, version)] = entry
        return f"{name}:{version}"

    def get_recipe(self, name: str, version: str) -> dict[str, Any] | None:
        """Retrieve a recipe by (name, version)."""
        entry = self._recipes.get((name, version))
        return copy.deepcopy(entry) if entry is not None else None

    def list_recipes(self) -> list[dict[str, Any]]:
        """List all stored recipes."""
        return [copy.deepcopy(r) for r in self._recipes.values()]

    def delete_recipe(self, recipe_id: str) -> bool:
        """Delete recipe by ID (``name:version``)."""
        parts = recipe_id.split(":", 1)
        if len(parts) != 2:
            return False
        key = (parts[0], parts[1])
        return self._recipes.pop(key, None) is not None

    # -- SchemaSpec CRUD -----------------------------------------------------

    def store_schema_spec(
        self,
        name: str,
        schema_spec: dict[str, Any],
    ) -> str:
        """Store a schema spec. Returns ``name`` as the ID."""
        entry = copy.deepcopy(schema_spec)
        entry.setdefault("name", name)
        self._schema_specs[name] = entry
        return name

    def get_schema_spec(self, name: str) -> dict[str, Any] | None:
        """Retrieve a schema spec by name."""
        entry = self._schema_specs.get(name)
        return copy.deepcopy(entry) if entry is not None else None

    def list_schema_specs(self) -> list[dict[str, Any]]:
        """List all stored schema specs."""
        return [copy.deepcopy(s) for s in self._schema_specs.values()]

    def delete_schema_spec(self, schema_spec_id: str) -> bool:
        """Delete schema spec by name."""
        return self._schema_specs.pop(schema_spec_id, None) is not None

    # -- GenerationRun CRUD --------------------------------------------------

    def store_generation_run(
        self,
        recipe_name: str,
        recipe_version: str,
        run: dict[str, Any],
    ) -> str:
        """Store a generation run. Returns a UUID string."""
        run_id = str(uuid.uuid4())
        entry = copy.deepcopy(run)
        entry.setdefault("recipe_name", recipe_name)
        entry.setdefault("recipe_version", recipe_version)
        entry["id"] = run_id
        self._generation_runs[run_id] = entry
        return run_id

    def get_generation_run(self, run_id: str) -> dict[str, Any] | None:
        """Retrieve a generation run by ID."""
        entry = self._generation_runs.get(run_id)
        return copy.deepcopy(entry) if entry is not None else None

    def list_generation_runs(
        self, recipe_name: str | None = None
    ) -> list[dict[str, Any]]:
        """List generation runs, optionally filtered by recipe name."""
        results: list[dict[str, Any]] = []
        for run in self._generation_runs.values():
            if recipe_name and run.get("recipe_name") != recipe_name:
                continue
            results.append(copy.deepcopy(run))
        return results

    def delete_generation_run(self, run_id: str) -> bool:
        """Delete generation run by ID."""
        return self._generation_runs.pop(run_id, None) is not None

    # -- Artifact CRUD -------------------------------------------------------

    def _store_artifact_native(self, experiment_id: str, name: str, data: bytes) -> str:
        """Store artifact in memory. Returns ``experiment_id:name``."""
        self._artifacts[(experiment_id, name)] = data
        return f"{experiment_id}:{name}"

    def _get_artifact_native(self, experiment_id: str, name: str) -> bytes | None:
        """Retrieve artifact bytes from memory."""
        return self._artifacts.get((experiment_id, name))

    def _list_artifacts_native(self, experiment_id: str) -> list[str]:
        """List artifact names for an experiment."""
        return [n for (eid, n) in self._artifacts if eid == experiment_id]

    def _delete_artifact_native(self, experiment_id: str, name: str) -> bool:
        """Delete artifact from memory."""
        return self._artifacts.pop((experiment_id, name), None) is not None
