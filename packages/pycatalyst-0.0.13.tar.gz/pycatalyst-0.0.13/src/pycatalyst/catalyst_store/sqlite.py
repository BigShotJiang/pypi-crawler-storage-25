"""SQLite catalyst store implementation.

Thin wrapper around ``_SQLAlchemyCatalystStoreBase`` that validates the
connection string and defaults to the configured database URL.
"""

from __future__ import annotations

import logging
from pathlib import Path

from pycatalyst.catalyst_store._sqlalchemy_base import (
    _SQLAlchemyCatalystStoreBase,
)

logger = logging.getLogger(__name__)

try:
    from pycatalyst.db.config import get_db_url
except ImportError:

    def get_db_url(**kwargs: object) -> str | None:  # type: ignore[misc]
        """Stub when config module is unavailable."""
        return None


class SQLiteCatalystStore(_SQLAlchemyCatalystStoreBase):
    """SQLite-backed catalyst store.

    Connection string format: ``sqlite:///path/to/database.db``
    or ``sqlite:///:memory:`` for in-memory databases.

    Usage::

        store = SQLiteCatalystStore("sqlite:///pycatalyst.db")
        store.connect(auto_initialize=True)

    If *connection_string* is ``None``, resolves from env / config.
    """

    def __init__(self, connection_string: str | None = None) -> None:
        resolved = connection_string or get_db_url(required=False)
        if not resolved:
            raise ValueError(
                "connection_string is required. Provide it directly, "
                "or set PYCATALYST_DATABASE_URL."
            )
        if not resolved.startswith("sqlite://"):
            raise ValueError(
                f"SQLiteCatalystStore requires a sqlite:// URL, got: {resolved!r}"
            )
        if resolved.startswith("sqlite:///"):
            db_path = resolved[len("sqlite:///") :]
            if db_path != ":memory:":
                Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        super().__init__(resolved)

    def connect(
        self,
        validate_schema_on_connect: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Connect to the SQLite database.

        Args:
            validate_schema_on_connect: Check that required tables exist.
            auto_initialize: Create tables if missing.
        """
        self._connect_engine(
            schema_name=None,
            validate_schema=validate_schema_on_connect,
            auto_initialize=auto_initialize,
        )
