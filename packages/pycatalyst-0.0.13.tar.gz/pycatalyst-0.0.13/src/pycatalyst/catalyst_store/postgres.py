"""PostgreSQL catalyst store implementation.

Thin wrapper around ``_SQLAlchemyCatalystStoreBase`` that validates the
connection string and sets the ``pycatalyst`` schema.
"""

from __future__ import annotations

import logging

from pycatalyst.catalyst_store._sqlalchemy_base import (
    _SQLAlchemyCatalystStoreBase,
)

logger = logging.getLogger(__name__)

try:
    from pycatalyst.db.config import get_db_url
except ImportError:

    def get_db_url(**kwargs: object) -> str | None:  # type: ignore[misc]
        """Stub when config module is unavailable."""
        return None


class PostgresCatalystStore(_SQLAlchemyCatalystStoreBase):
    """PostgreSQL-backed catalyst store.

    Stores entities in PostgreSQL tables within the ``pycatalyst`` schema.

    Usage::

        store = PostgresCatalystStore(
            "postgresql://user:pass@localhost/pycatalyst"
        )
        store.connect()

    If *connection_string* is ``None``, resolves from env / config.
    """

    def __init__(
        self,
        connection_string: str | None = None,
        schema_name: str = "pycatalyst",
    ) -> None:
        resolved = connection_string or get_db_url(required=False)
        if not resolved:
            raise ValueError(
                "connection_string is required. Provide it directly, "
                "or set PYCATALYST_DATABASE_URL."
            )
        if not resolved.startswith(("postgresql://", "postgres://")):
            raise ValueError(
                f"PostgresCatalystStore requires a postgresql:// URL, got: {resolved!r}"
            )
        super().__init__(resolved)
        self._pg_schema_name = schema_name

    def connect(
        self,
        validate_schema_on_connect: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Connect to the PostgreSQL database.

        Args:
            validate_schema_on_connect: Check that required tables exist.
            auto_initialize: Create tables if missing.
        """
        self._connect_engine(
            schema_name=self._pg_schema_name,
            validate_schema=validate_schema_on_connect,
            auto_initialize=auto_initialize,
        )
