"""MongoDB catalyst store implementation.

Stores domain entities in MongoDB collections: experiments, recipes,
schema_specs, generation_runs.
"""

from __future__ import annotations

import copy
import logging
from typing import Any

try:
    from gridfs import GridFS  # type: ignore[import-untyped]
    from pymongo import MongoClient  # type: ignore[import-untyped]

    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False
    GridFS = None  # type: ignore[assignment,misc]
    MongoClient = None  # type: ignore[assignment,misc]

from pycatalyst.catalyst_store.client import CatalystStoreClient

logger = logging.getLogger(__name__)


class MongoDBCatalystStore(CatalystStoreClient):
    """MongoDB-backed catalyst store.

    Collections:
    - ``experiments``      — keyed by (name, backend)
    - ``recipes``          — keyed by (name, version)
    - ``schema_specs``     — keyed by name (unique)
    - ``generation_runs``  — keyed by _id (ObjectId)

    Connection string format: ``mongodb://[user:pass@]host[:port][/db]``

    Example::

        store = MongoDBCatalystStore("mongodb://localhost:27017/pycatalyst")
        store.connect()
    """

    def __init__(
        self,
        connection_string: str | None = None,
        database_name: str = "pycatalyst",
    ) -> None:
        """Initialize MongoDB catalyst store.

        Args:
            connection_string: MongoDB connection URI.
            database_name: Database name (default ``pycatalyst``).
        """
        if not MONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for MongoDBCatalystStore. "
                "Install with: pip install pycatalyst[mongodb]"
            )
        if connection_string and not connection_string.startswith(
            ("mongodb://", "mongodb+srv://")
        ):
            raise ValueError(
                f"MongoDBCatalystStore requires a mongodb:// URL, "
                f"got: {connection_string!r}"
            )
        super().__init__(connection_string)
        self.database_name = database_name
        self._client: Any = None
        self._db: Any = None
        self._gridfs: Any = None

    # -- lifecycle -----------------------------------------------------------

    def connect(self, ensure_indexes: bool = True) -> None:
        """Connect to MongoDB.

        Args:
            ensure_indexes: Create indexes on first connect (default True).
        """
        if not self.connection_string:
            raise ValueError("connection_string is required for MongoDB")
        self._client = MongoClient(self.connection_string)
        self._db = self._client[self.database_name]
        self._connection = self._db
        self._gridfs = GridFS(self._db, collection="artifacts")
        if ensure_indexes:
            self._ensure_indexes()

    def disconnect(self) -> None:
        """Close MongoDB connection."""
        if self._client:
            self._client.close()
            self._client = None
            self._db = None
            self._gridfs = None
            self._connection = None

    def _ensure_indexes(self) -> None:
        """Create indexes idempotently."""
        if self._db is None:
            return

        def _create(collection: Any, spec: Any, **kw: Any) -> None:
            collection.create_index(spec, background=True, **kw)

        _create(
            self._db.experiments,
            [("name", 1), ("backend", 1)],
            unique=True,
        )
        _create(self._db.experiments, "status")

        _create(
            self._db.recipes,
            [("name", 1), ("version", 1)],
            unique=True,
        )

        _create(self._db.schema_specs, "name", unique=True)

        _create(self._db.generation_runs, "recipe_name")

    # -- helpers -------------------------------------------------------------

    def _require_db(self) -> Any:
        """Return db handle or raise."""
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._db

    # -- Experiment CRUD -----------------------------------------------------

    def store_experiment(
        self,
        name: str,
        backend: str,
        experiment: dict[str, Any],
    ) -> str:
        """Store experiment. Upserts by (name, backend)."""
        from bson import ObjectId

        db = self._require_db()
        doc = copy.deepcopy(experiment)
        doc["name"] = name
        doc["backend"] = backend
        existing = db.experiments.find_one({"name": name, "backend": backend})
        if existing:
            db.experiments.update_one({"_id": existing["_id"]}, {"$set": doc})
            return str(existing["_id"])
        doc["_id"] = ObjectId()
        db.experiments.insert_one(doc)
        return str(doc["_id"])

    def get_experiment(self, name: str, backend: str) -> dict[str, Any] | None:
        """Retrieve experiment by (name, backend)."""
        db = self._require_db()
        doc = db.experiments.find_one({"name": name, "backend": backend})
        if doc is None:
            return None
        doc["id"] = str(doc.pop("_id"))
        return doc

    def list_experiments(
        self,
        backend: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List experiments with optional filters."""
        db = self._require_db()
        query: dict[str, Any] = {}
        if backend:
            query["backend"] = backend
        if status:
            query["status"] = status
        results: list[dict[str, Any]] = []
        for doc in db.experiments.find(query):
            doc["id"] = str(doc.pop("_id"))
            results.append(doc)
        return results

    def delete_experiment(self, experiment_id: str) -> bool:
        """Delete experiment by ID."""
        from bson import ObjectId

        db = self._require_db()
        result = db.experiments.delete_one({"_id": ObjectId(experiment_id)})
        return result.deleted_count > 0

    # -- Recipe CRUD ---------------------------------------------------------

    def store_recipe(
        self,
        name: str,
        version: str,
        recipe: dict[str, Any],
    ) -> str:
        """Store recipe. Upserts by (name, version)."""
        from bson import ObjectId

        db = self._require_db()
        doc = copy.deepcopy(recipe)
        doc["name"] = name
        doc["version"] = version
        existing = db.recipes.find_one({"name": name, "version": version})
        if existing:
            db.recipes.update_one({"_id": existing["_id"]}, {"$set": doc})
            return str(existing["_id"])
        doc["_id"] = ObjectId()
        db.recipes.insert_one(doc)
        return str(doc["_id"])

    def get_recipe(self, name: str, version: str) -> dict[str, Any] | None:
        """Retrieve recipe by (name, version)."""
        db = self._require_db()
        doc = db.recipes.find_one({"name": name, "version": version})
        if doc is None:
            return None
        doc["id"] = str(doc.pop("_id"))
        return doc

    def list_recipes(self) -> list[dict[str, Any]]:
        """List all recipes."""
        db = self._require_db()
        results: list[dict[str, Any]] = []
        for doc in db.recipes.find():
            doc["id"] = str(doc.pop("_id"))
            results.append(doc)
        return results

    def delete_recipe(self, recipe_id: str) -> bool:
        """Delete recipe by ID."""
        from bson import ObjectId

        db = self._require_db()
        result = db.recipes.delete_one({"_id": ObjectId(recipe_id)})
        return result.deleted_count > 0

    # -- SchemaSpec CRUD -----------------------------------------------------

    def store_schema_spec(
        self,
        name: str,
        schema_spec: dict[str, Any],
    ) -> str:
        """Store schema spec. Upserts by name."""
        from bson import ObjectId

        db = self._require_db()
        doc = copy.deepcopy(schema_spec)
        doc["name"] = name
        existing = db.schema_specs.find_one({"name": name})
        if existing:
            db.schema_specs.update_one({"_id": existing["_id"]}, {"$set": doc})
            return str(existing["_id"])
        doc["_id"] = ObjectId()
        db.schema_specs.insert_one(doc)
        return str(doc["_id"])

    def get_schema_spec(self, name: str) -> dict[str, Any] | None:
        """Retrieve schema spec by name."""
        db = self._require_db()
        doc = db.schema_specs.find_one({"name": name})
        if doc is None:
            return None
        doc["id"] = str(doc.pop("_id"))
        return doc

    def list_schema_specs(self) -> list[dict[str, Any]]:
        """List all schema specs."""
        db = self._require_db()
        results: list[dict[str, Any]] = []
        for doc in db.schema_specs.find():
            doc["id"] = str(doc.pop("_id"))
            results.append(doc)
        return results

    def delete_schema_spec(self, schema_spec_id: str) -> bool:
        """Delete schema spec by ID."""
        from bson import ObjectId

        db = self._require_db()
        result = db.schema_specs.delete_one({"_id": ObjectId(schema_spec_id)})
        return result.deleted_count > 0

    # -- GenerationRun CRUD --------------------------------------------------

    def store_generation_run(
        self,
        recipe_name: str,
        recipe_version: str,
        run: dict[str, Any],
    ) -> str:
        """Store generation run. Returns ObjectId string."""
        from bson import ObjectId

        db = self._require_db()
        doc = copy.deepcopy(run)
        doc["recipe_name"] = recipe_name
        doc["recipe_version"] = recipe_version
        doc["_id"] = ObjectId()
        db.generation_runs.insert_one(doc)
        return str(doc["_id"])

    def get_generation_run(self, run_id: str) -> dict[str, Any] | None:
        """Retrieve generation run by ID."""
        from bson import ObjectId

        db = self._require_db()
        doc = db.generation_runs.find_one({"_id": ObjectId(run_id)})
        if doc is None:
            return None
        doc["id"] = str(doc.pop("_id"))
        return doc

    def list_generation_runs(
        self, recipe_name: str | None = None
    ) -> list[dict[str, Any]]:
        """List generation runs with optional recipe filter."""
        db = self._require_db()
        query: dict[str, Any] = {}
        if recipe_name:
            query["recipe_name"] = recipe_name
        results: list[dict[str, Any]] = []
        for doc in db.generation_runs.find(query):
            doc["id"] = str(doc.pop("_id"))
            results.append(doc)
        return results

    def delete_generation_run(self, run_id: str) -> bool:
        """Delete generation run by ID."""
        from bson import ObjectId

        db = self._require_db()
        result = db.generation_runs.delete_one({"_id": ObjectId(run_id)})
        return result.deleted_count > 0

    # -- Artifact CRUD (GridFS) ----------------------------------------------

    def _require_gridfs(self) -> Any:
        """Return GridFS handle or raise."""
        if self._gridfs is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._gridfs

    def _store_artifact_native(self, experiment_id: str, name: str, data: bytes) -> str:
        """Store artifact via GridFS. Replaces existing file if present."""
        fs = self._require_gridfs()
        existing = fs.find_one({"experiment_id": experiment_id, "filename": name})
        if existing:
            fs.delete(existing._id)
        file_id = fs.put(
            data,
            filename=name,
            experiment_id=experiment_id,
        )
        return str(file_id)

    def _get_artifact_native(self, experiment_id: str, name: str) -> bytes | None:
        """Retrieve artifact bytes from GridFS."""
        fs = self._require_gridfs()
        grid_out = fs.find_one({"experiment_id": experiment_id, "filename": name})
        if grid_out is None:
            return None
        return grid_out.read()

    def _list_artifacts_native(self, experiment_id: str) -> list[str]:
        """List artifact names for an experiment via GridFS."""
        self._require_db()
        db = self._db
        files = db["artifacts.files"].find(
            {"experiment_id": experiment_id},
            {"filename": 1},
        )
        return sorted({doc["filename"] for doc in files})

    def _delete_artifact_native(self, experiment_id: str, name: str) -> bool:
        """Delete artifact from GridFS."""
        fs = self._require_gridfs()
        existing = fs.find_one({"experiment_id": experiment_id, "filename": name})
        if existing is None:
            return False
        fs.delete(existing._id)
        return True
