"""Artifact storage protocol for composable backend delegation.

Defines the ``ArtifactBackend`` protocol that any artifact store
(InMemory, SQLAlchemy, MongoDB, S3) must satisfy.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class ArtifactBackend(Protocol):
    """Protocol for binary artifact storage backends.

    Implementations:
        - ``InMemoryCatalystStore`` (dict-based)
        - ``_SQLAlchemyCatalystStoreBase`` (ArtifactModel table)
        - ``MongoDBCatalystStore`` (GridFS)
        - ``S3ArtifactStore`` (standalone, boto3)
    """

    def store_artifact(self, experiment_id: str, name: str, data: bytes) -> str:
        """Store a binary artifact.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name (e.g. ``"model.pt"``).
            data: Raw bytes.

        Returns:
            Artifact identifier string.
        """
        ...

    def get_artifact(self, experiment_id: str, name: str) -> bytes | None:
        """Retrieve a binary artifact.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.

        Returns:
            Raw bytes or ``None`` if not found.
        """
        ...

    def list_artifacts(self, experiment_id: str) -> list[str]:
        """List artifact names for an experiment.

        Args:
            experiment_id: Owning experiment ID.

        Returns:
            List of artifact name strings.
        """
        ...

    def delete_artifact(self, experiment_id: str, name: str) -> bool:
        """Delete a binary artifact.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.

        Returns:
            ``True`` if deleted, ``False`` if not found.
        """
        ...
