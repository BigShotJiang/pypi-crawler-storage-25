"""Catalyst Store Client — persistent storage for domain entities.

Entity-centric API for experiments, recipes, schema specs, and generation runs.

Architecture notes:
    ``CatalystStoreClient`` is an abstract base class.  Subclasses (SQLite,
    Postgres, MongoDB, InMemory) implement the ``@abstractmethod`` methods.
    Template methods (``get_experiment_summary``, ``get_recipe_with_schema``)
    are concrete and compose from the abstract primitives.

    The ``connect`` / ``disconnect`` / ``__enter__`` / ``__exit__`` lifecycle
    mirrors pycharter's ``MetadataStoreClient``.
"""

from __future__ import annotations

import copy
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pycatalyst.catalyst_store._artifact_protocol import ArtifactBackend


class CatalystStoreClient(ABC):
    """Client for storing and retrieving catalyst domain entities.

    Implementations extend this for specific backends
    (SQLite, PostgreSQL, MongoDB, InMemory).

    Artifact storage is composable: set ``artifact_backend`` to delegate
    artifact calls to a different backend (e.g. S3 for artifacts while
    using SQLite for entities).
    """

    def __init__(self, connection_string: str | None = None) -> None:
        """Initialize catalyst store client.

        Args:
            connection_string: Database connection string (format depends
                on implementation).
        """
        self.connection_string = connection_string
        self._connection: Any = None
        self._artifact_backend: ArtifactBackend | None = None

    # -- artifact backend delegation ----------------------------------------

    @property
    def artifact_backend(self) -> ArtifactBackend | None:
        """Return the current artifact backend delegate, if any."""
        return self._artifact_backend

    @artifact_backend.setter
    def artifact_backend(self, backend: ArtifactBackend | None) -> None:
        """Set an artifact backend delegate.

        Args:
            backend: An ``ArtifactBackend`` implementation, or ``None``
                to revert to native artifact storage.
        """
        self._artifact_backend = backend

    # -- lifecycle -----------------------------------------------------------

    @abstractmethod
    def connect(self) -> None:
        """Establish database connection.  Subclasses must implement."""

    def disconnect(self) -> None:
        """Close database connection."""
        if self._connection:
            self._connection = None

    def _require_connection(self) -> None:
        """Raise ``RuntimeError`` if ``connect()`` has not been called."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    def __enter__(self) -> CatalystStoreClient:
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.disconnect()

    # -----------------------------------------------------------------------
    # Experiment CRUD
    # -----------------------------------------------------------------------

    @abstractmethod
    def store_experiment(
        self,
        name: str,
        backend: str,
        experiment: dict[str, Any],
    ) -> str:
        """Store an experiment record.

        Args:
            name: Experiment name.
            backend: ML backend (pytorch, sklearn, huggingface).
            experiment: Experiment data dict (config, metrics, artifacts, etc.).

        Returns:
            Experiment ID or identifier.
        """

    @abstractmethod
    def get_experiment(self, name: str, backend: str) -> dict[str, Any] | None:
        """Retrieve an experiment by name and backend.

        Args:
            name: Experiment name.
            backend: ML backend.

        Returns:
            Experiment dict or ``None`` if not found.
        """

    @abstractmethod
    def list_experiments(
        self,
        backend: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List experiments, optionally filtered.

        Args:
            backend: Filter by backend.
            status: Filter by status.

        Returns:
            List of experiment summary dicts.
        """

    @abstractmethod
    def delete_experiment(self, experiment_id: str) -> bool:
        """Delete an experiment by ID.

        Args:
            experiment_id: The experiment identifier.

        Returns:
            ``True`` if deleted, ``False`` if not found.
        """

    # -----------------------------------------------------------------------
    # Recipe CRUD
    # -----------------------------------------------------------------------

    @abstractmethod
    def store_recipe(
        self,
        name: str,
        version: str,
        recipe: dict[str, Any],
    ) -> str:
        """Store a recipe configuration.

        Args:
            name: Recipe name.
            version: Recipe version.
            recipe: Full recipe configuration dict.

        Returns:
            Recipe ID or identifier.
        """

    @abstractmethod
    def get_recipe(self, name: str, version: str) -> dict[str, Any] | None:
        """Retrieve a recipe by name and version.

        Args:
            name: Recipe name.
            version: Recipe version.

        Returns:
            Recipe dict or ``None`` if not found.
        """

    @abstractmethod
    def list_recipes(self) -> list[dict[str, Any]]:
        """List all stored recipes.

        Returns:
            List of recipe summary dicts.
        """

    @abstractmethod
    def delete_recipe(self, recipe_id: str) -> bool:
        """Delete a recipe by ID.

        Args:
            recipe_id: The recipe identifier.

        Returns:
            ``True`` if deleted, ``False`` if not found.
        """

    # -----------------------------------------------------------------------
    # SchemaSpec CRUD
    # -----------------------------------------------------------------------

    @abstractmethod
    def store_schema_spec(
        self,
        name: str,
        schema_spec: dict[str, Any],
    ) -> str:
        """Store a schema specification.

        Args:
            name: Schema spec name.
            schema_spec: Schema definition dict (fields, metadata).

        Returns:
            SchemaSpec ID or identifier.
        """

    @abstractmethod
    def get_schema_spec(self, name: str) -> dict[str, Any] | None:
        """Retrieve a schema spec by name.

        Args:
            name: Schema spec name.

        Returns:
            Schema spec dict or ``None`` if not found.
        """

    @abstractmethod
    def list_schema_specs(self) -> list[dict[str, Any]]:
        """List all stored schema specs.

        Returns:
            List of schema spec summary dicts.
        """

    @abstractmethod
    def delete_schema_spec(self, schema_spec_id: str) -> bool:
        """Delete a schema spec by ID.

        Args:
            schema_spec_id: The schema spec identifier.

        Returns:
            ``True`` if deleted, ``False`` if not found.
        """

    # -----------------------------------------------------------------------
    # GenerationRun CRUD
    # -----------------------------------------------------------------------

    @abstractmethod
    def store_generation_run(
        self,
        recipe_name: str,
        recipe_version: str,
        run: dict[str, Any],
    ) -> str:
        """Store a generation run record.

        Args:
            recipe_name: Name of the recipe used.
            recipe_version: Version of the recipe used.
            run: Run data dict (record_count, duration, seed, output, etc.).

        Returns:
            Run ID (UUID string).
        """

    @abstractmethod
    def get_generation_run(self, run_id: str) -> dict[str, Any] | None:
        """Retrieve a generation run by ID.

        Args:
            run_id: The run UUID string.

        Returns:
            Run dict or ``None`` if not found.
        """

    @abstractmethod
    def list_generation_runs(
        self, recipe_name: str | None = None
    ) -> list[dict[str, Any]]:
        """List generation runs, optionally filtered by recipe.

        Args:
            recipe_name: Filter by recipe name.

        Returns:
            List of run summary dicts.
        """

    @abstractmethod
    def delete_generation_run(self, run_id: str) -> bool:
        """Delete a generation run by ID.

        Args:
            run_id: The run UUID string.

        Returns:
            ``True`` if deleted, ``False`` if not found.
        """

    # -----------------------------------------------------------------------
    # Template methods  (concrete — compose from abstract primitives)
    # -----------------------------------------------------------------------

    def get_experiment_summary(self, name: str, backend: str) -> dict[str, Any] | None:
        """Return experiment without bulky fields (training_history, config).

        Args:
            name: Experiment name.
            backend: ML backend.

        Returns:
            Experiment summary dict or ``None`` if not found.
        """
        experiment = self.get_experiment(name, backend)
        if experiment is None:
            return None
        summary = copy.deepcopy(experiment)
        summary.pop("training_history", None)
        summary.pop("config", None)
        return summary

    def get_recipe_with_schema(
        self, recipe_name: str, recipe_version: str
    ) -> dict[str, Any] | None:
        """Return recipe with its linked schema spec resolved inline.

        Args:
            recipe_name: Recipe name.
            recipe_version: Recipe version.

        Returns:
            Recipe dict with ``schema_spec`` key populated, or ``None``.
        """
        recipe = self.get_recipe(recipe_name, recipe_version)
        if recipe is None:
            return None
        result = copy.deepcopy(recipe)
        schema_name = result.get("schema_name")
        if not schema_name:
            recipe_data = result.get("recipe_data")
            if isinstance(recipe_data, dict):
                schema_name = recipe_data.get("schema_name")
        if schema_name:
            schema_spec = self.get_schema_spec(schema_name)
            if schema_spec:
                result["schema_spec"] = schema_spec
        return result

    # -----------------------------------------------------------------------
    # Artifact storage (composable — delegates to artifact_backend if set)
    # -----------------------------------------------------------------------

    def store_artifact(self, experiment_id: str, name: str, data: bytes) -> str:
        """Store a binary artifact for an experiment.

        Delegates to ``artifact_backend`` when set; otherwise falls back
        to the native implementation (subclass override or raises
        ``NotImplementedError``).

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.
            data: Raw bytes.

        Returns:
            Artifact identifier.
        """
        if self._artifact_backend is not None:
            return self._artifact_backend.store_artifact(experiment_id, name, data)
        return self._store_artifact_native(experiment_id, name, data)

    def get_artifact(self, experiment_id: str, name: str) -> bytes | None:
        """Retrieve a binary artifact for an experiment.

        Delegates to ``artifact_backend`` when set; otherwise falls back
        to the native implementation.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.

        Returns:
            Raw bytes or ``None`` if not found/supported.
        """
        if self._artifact_backend is not None:
            return self._artifact_backend.get_artifact(experiment_id, name)
        return self._get_artifact_native(experiment_id, name)

    def list_artifacts(self, experiment_id: str) -> list[str]:
        """List artifact names for an experiment.

        Delegates to ``artifact_backend`` when set; otherwise falls back
        to the native implementation.

        Args:
            experiment_id: Owning experiment ID.

        Returns:
            List of artifact name strings.
        """
        if self._artifact_backend is not None:
            return self._artifact_backend.list_artifacts(experiment_id)
        return self._list_artifacts_native(experiment_id)

    def delete_artifact(self, experiment_id: str, name: str) -> bool:
        """Delete a binary artifact for an experiment.

        Delegates to ``artifact_backend`` when set; otherwise falls back
        to the native implementation.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.

        Returns:
            ``True`` if deleted, ``False`` if not found.
        """
        if self._artifact_backend is not None:
            return self._artifact_backend.delete_artifact(experiment_id, name)
        return self._delete_artifact_native(experiment_id, name)

    # -- native artifact hooks (override in subclasses) ---------------------

    def _store_artifact_native(self, experiment_id: str, name: str, data: bytes) -> str:
        """Native artifact storage. Override in subclasses."""
        raise NotImplementedError(
            f"{type(self).__name__} does not support artifact storage."
        )

    def _get_artifact_native(self, experiment_id: str, name: str) -> bytes | None:
        """Native artifact retrieval. Override in subclasses."""
        return None

    def _list_artifacts_native(self, experiment_id: str) -> list[str]:
        """Native artifact listing. Override in subclasses."""
        return []

    def _delete_artifact_native(self, experiment_id: str, name: str) -> bool:
        """Native artifact deletion. Override in subclasses."""
        return False
