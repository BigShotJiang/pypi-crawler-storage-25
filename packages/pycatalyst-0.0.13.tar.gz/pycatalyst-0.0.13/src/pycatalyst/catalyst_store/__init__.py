"""Catalyst Store — persistent storage for domain entities.

Available implementations:
- InMemoryCatalystStore: Dict-based store for testing/development
- SQLiteCatalystStore: SQLite implementation (requires sqlalchemy)
- PostgresCatalystStore: PostgreSQL implementation (requires sqlalchemy, psycopg2)
- MongoDBCatalystStore: MongoDB implementation (requires pymongo)
- S3ArtifactStore: S3-backed artifact storage (requires boto3)

Artifact delegation:
    Set ``store.artifact_backend = S3ArtifactStore(bucket="...")`` to route
    artifact calls to S3 while keeping entities in a different backend.
"""

from __future__ import annotations

from pycatalyst.catalyst_store._artifact_protocol import ArtifactBackend
from pycatalyst.catalyst_store.client import CatalystStoreClient
from pycatalyst.catalyst_store.in_memory import InMemoryCatalystStore

try:
    from pycatalyst.catalyst_store.sqlite import SQLiteCatalystStore
except ImportError:
    SQLiteCatalystStore = None  # type: ignore[assignment,misc]

try:
    from pycatalyst.catalyst_store.postgres import PostgresCatalystStore
except ImportError:
    PostgresCatalystStore = None  # type: ignore[assignment,misc]

try:
    from pycatalyst.catalyst_store.mongodb import MongoDBCatalystStore
except ImportError:
    MongoDBCatalystStore = None  # type: ignore[assignment,misc]

try:
    from pycatalyst.catalyst_store.s3 import S3ArtifactStore
except ImportError:
    S3ArtifactStore = None  # type: ignore[assignment,misc]

__all__ = [
    "ArtifactBackend",
    "CatalystStoreClient",
    "InMemoryCatalystStore",
    "MongoDBCatalystStore",
    "PostgresCatalystStore",
    "S3ArtifactStore",
    "SQLiteCatalystStore",
]
