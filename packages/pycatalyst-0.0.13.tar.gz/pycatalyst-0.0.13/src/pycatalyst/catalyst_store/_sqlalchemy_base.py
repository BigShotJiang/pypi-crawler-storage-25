"""Private shared SQLAlchemy base for SQLite and PostgreSQL catalyst stores.

Internal — import the public stores from ``pycatalyst.catalyst_store``.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from sqlalchemy import inspect
from sqlalchemy.orm import Session, sessionmaker

from pycatalyst.catalyst_store.client import CatalystStoreClient
from pycatalyst.db.base import Base, get_engine
from pycatalyst.db.models.artifact import ArtifactModel
from pycatalyst.db.models.experiment import ExperimentModel
from pycatalyst.db.models.generation_run import GenerationRunModel
from pycatalyst.db.models.recipe import RecipeModel
from pycatalyst.db.models.schema_spec import SchemaSpecModel

logger = logging.getLogger(__name__)

_CORE_TABLES = [
    ExperimentModel.__table__,
    RecipeModel.__table__,
    SchemaSpecModel.__table__,
    GenerationRunModel.__table__,
    ArtifactModel.__table__,
]


class _SQLAlchemyCatalystStoreBase(CatalystStoreClient):
    """Shared SQLAlchemy query logic for SQLite and PostgreSQL stores."""

    def __init__(self, connection_string: str) -> None:
        super().__init__(connection_string)
        self._engine: Any = None
        self._session: Session | None = None
        self._schema_name: str | None = None

    # ------------------------------------------------------------------
    # Engine / session lifecycle
    # ------------------------------------------------------------------

    def _connect_engine(
        self,
        schema_name: str | None,
        *,
        validate_schema: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Create engine, session, and optionally validate/create tables."""
        self._schema_name = schema_name
        self._engine = get_engine(self.connection_string)  # type: ignore[arg-type]
        factory = sessionmaker(bind=self._engine)
        self._session = factory()
        self._connection = self._session

        if validate_schema and not self._is_schema_initialized():
            if auto_initialize:
                self._initialize_schema()
            else:
                raise RuntimeError(
                    "Database schema is not initialized. "
                    "Run 'pycatalyst db init' first.\n"
                    f"Connection: {self.connection_string}"
                )

    def disconnect(self) -> None:
        """Close session and dispose engine."""
        if self._session is not None:
            self._session.close()
            self._session = None
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None
        self._connection = None

    # ------------------------------------------------------------------
    # Schema helpers
    # ------------------------------------------------------------------

    def _is_schema_initialized(self) -> bool:
        """Check whether the ``experiments`` table exists."""
        if self._engine is None:
            return False
        try:
            insp = inspect(self._engine)
            tables = insp.get_table_names(schema=self._schema_name)
            return "experiments" in tables
        except Exception:
            return False

    def _initialize_schema(self) -> None:
        """Create catalyst store tables from SQLAlchemy models."""
        try:
            Base.metadata.create_all(self._engine, tables=_CORE_TABLES)
        except Exception as exc:
            raise RuntimeError(f"Failed to initialize schema: {exc}") from exc

    def _get_session(self) -> Session:
        """Return the active session, raising if not connected."""
        self._require_connection()
        assert self._session is not None  # noqa: S101
        return self._session

    @staticmethod
    def _parse_json(value: Any) -> Any:
        """Ensure JSON column value is a Python object, not a string."""
        if isinstance(value, str):
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        return value

    # -- Experiment CRUD ---------------------------------------------------

    def store_experiment(
        self,
        name: str,
        backend: str,
        experiment: dict[str, Any],
    ) -> str:
        """Store an experiment. Returns experiment ID string."""
        session = self._get_session()
        row = ExperimentModel(
            name=name,
            backend=backend,
            status=experiment.get("status"),
            metrics=experiment.get("metrics"),
            artifacts=experiment.get("artifacts"),
            training_history=experiment.get("training_history"),
            duration_seconds=experiment.get("duration_seconds"),
            config=experiment.get("config"),
        )
        session.add(row)
        session.commit()
        return str(row.id)

    def get_experiment(self, name: str, backend: str) -> dict[str, Any] | None:
        """Retrieve experiment by (name, backend)."""
        session = self._get_session()
        row = (
            session.query(ExperimentModel)
            .filter(
                ExperimentModel.name == name,
                ExperimentModel.backend == backend,
            )
            .first()
        )
        if row is None:
            return None
        return self._experiment_to_dict(row)

    def list_experiments(
        self,
        backend: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List experiments with optional filters."""
        session = self._get_session()
        query = session.query(ExperimentModel)
        if backend:
            query = query.filter(ExperimentModel.backend == backend)
        if status:
            query = query.filter(ExperimentModel.status == status)
        return [self._experiment_to_dict(r) for r in query.all()]

    def delete_experiment(self, experiment_id: str) -> bool:
        """Delete experiment by ID."""
        session = self._get_session()
        row = session.get(ExperimentModel, uuid.UUID(experiment_id))
        if row is None:
            return False
        session.delete(row)
        session.commit()
        return True

    def _experiment_to_dict(self, row: ExperimentModel) -> dict[str, Any]:
        """Convert ORM row to dict."""
        return {
            "id": str(row.id),
            "name": row.name,
            "backend": row.backend,
            "status": row.status,
            "metrics": self._parse_json(row.metrics),
            "artifacts": self._parse_json(row.artifacts),
            "training_history": self._parse_json(row.training_history),
            "duration_seconds": row.duration_seconds,
            "config": self._parse_json(row.config),
        }

    # -- Recipe CRUD -------------------------------------------------------

    def store_recipe(
        self,
        name: str,
        version: str,
        recipe: dict[str, Any],
    ) -> str:
        """Store a recipe. Returns recipe ID string."""
        session = self._get_session()
        row = RecipeModel(
            name=name,
            version=version,
            description=recipe.get("description"),
            recipe_data=recipe,
        )
        session.add(row)
        session.commit()
        return str(row.id)

    def get_recipe(self, name: str, version: str) -> dict[str, Any] | None:
        """Retrieve recipe by (name, version)."""
        session = self._get_session()
        row = (
            session.query(RecipeModel)
            .filter(
                RecipeModel.name == name,
                RecipeModel.version == version,
            )
            .first()
        )
        if row is None:
            return None
        return self._recipe_to_dict(row)

    def list_recipes(self) -> list[dict[str, Any]]:
        """List all recipes."""
        session = self._get_session()
        rows = (
            session.query(RecipeModel)
            .order_by(RecipeModel.name, RecipeModel.version)
            .all()
        )
        return [self._recipe_to_dict(r) for r in rows]

    def delete_recipe(self, recipe_id: str) -> bool:
        """Delete recipe by ID."""
        session = self._get_session()
        row = session.get(RecipeModel, uuid.UUID(recipe_id))
        if row is None:
            return False
        session.delete(row)
        session.commit()
        return True

    def _recipe_to_dict(self, row: RecipeModel) -> dict[str, Any]:
        """Convert ORM row to dict."""
        data = self._parse_json(row.recipe_data) or {}
        if isinstance(data, dict):
            data.setdefault("name", row.name)
            data.setdefault("version", row.version)
        return {
            "id": str(row.id),
            "name": row.name,
            "version": row.version,
            "description": row.description,
            "recipe_data": data,
        }

    # -- SchemaSpec CRUD ---------------------------------------------------

    def store_schema_spec(
        self,
        name: str,
        schema_spec: dict[str, Any],
    ) -> str:
        """Store a schema spec. Returns schema spec ID string."""
        session = self._get_session()
        row = SchemaSpecModel(
            name=name,
            description=schema_spec.get("description"),
            schema_data=schema_spec.get("fields") or schema_spec,
            spec_metadata=schema_spec.get("metadata"),
        )
        session.add(row)
        session.commit()
        return str(row.id)

    def get_schema_spec(self, name: str) -> dict[str, Any] | None:
        """Retrieve schema spec by name."""
        session = self._get_session()
        row = (
            session.query(SchemaSpecModel).filter(SchemaSpecModel.name == name).first()
        )
        if row is None:
            return None
        return self._schema_spec_to_dict(row)

    def list_schema_specs(self) -> list[dict[str, Any]]:
        """List all schema specs."""
        session = self._get_session()
        rows = session.query(SchemaSpecModel).order_by(SchemaSpecModel.name).all()
        return [self._schema_spec_to_dict(r) for r in rows]

    def delete_schema_spec(self, schema_spec_id: str) -> bool:
        """Delete schema spec by ID."""
        session = self._get_session()
        row = session.get(SchemaSpecModel, uuid.UUID(schema_spec_id))
        if row is None:
            return False
        session.delete(row)
        session.commit()
        return True

    def _schema_spec_to_dict(self, row: SchemaSpecModel) -> dict[str, Any]:
        """Convert ORM row to dict."""
        return {
            "id": str(row.id),
            "name": row.name,
            "description": row.description,
            "schema_data": self._parse_json(row.schema_data),
            "metadata": self._parse_json(row.spec_metadata),
        }

    # -- GenerationRun CRUD ------------------------------------------------

    def store_generation_run(
        self,
        recipe_name: str,
        recipe_version: str,
        run: dict[str, Any],
    ) -> str:
        """Store a generation run. Returns run ID string."""
        session = self._get_session()
        row = GenerationRunModel(
            recipe_name=recipe_name,
            recipe_version=recipe_version,
            schema_name=run.get("schema_name"),
            record_count=run.get("record_count"),
            duration_ms=run.get("duration_ms"),
            seed=run.get("seed"),
            run_data=run,
        )
        session.add(row)
        session.commit()
        return str(row.id)

    def get_generation_run(self, run_id: str) -> dict[str, Any] | None:
        """Retrieve generation run by ID."""
        session = self._get_session()
        row = session.get(GenerationRunModel, uuid.UUID(run_id))
        if row is None:
            return None
        return self._run_to_dict(row)

    def list_generation_runs(
        self, recipe_name: str | None = None
    ) -> list[dict[str, Any]]:
        """List generation runs with optional recipe name filter."""
        session = self._get_session()
        query = session.query(GenerationRunModel)
        if recipe_name:
            query = query.filter(GenerationRunModel.recipe_name == recipe_name)
        return [self._run_to_dict(r) for r in query.all()]

    def delete_generation_run(self, run_id: str) -> bool:
        """Delete generation run by ID."""
        session = self._get_session()
        row = session.get(GenerationRunModel, uuid.UUID(run_id))
        if row is None:
            return False
        session.delete(row)
        session.commit()
        return True

    def _run_to_dict(self, row: GenerationRunModel) -> dict[str, Any]:
        """Convert ORM row to dict."""
        return {
            "id": str(row.id),
            "recipe_name": row.recipe_name,
            "recipe_version": row.recipe_version,
            "schema_name": row.schema_name,
            "record_count": row.record_count,
            "duration_ms": row.duration_ms,
            "seed": row.seed,
            "run_data": self._parse_json(row.run_data),
        }

    # -- Artifact CRUD -----------------------------------------------------

    def _store_artifact_native(self, experiment_id: str, name: str, data: bytes) -> str:
        """Store artifact as a row in the artifacts table (upsert)."""
        session = self._get_session()
        exp_uuid = uuid.UUID(experiment_id)
        existing = (
            session.query(ArtifactModel)
            .filter(
                ArtifactModel.experiment_id == exp_uuid,
                ArtifactModel.name == name,
            )
            .first()
        )
        if existing:
            existing.data = data
            existing.size_bytes = len(data)
            session.commit()
            return str(existing.id)
        row = ArtifactModel(
            experiment_id=exp_uuid,
            name=name,
            data=data,
            size_bytes=len(data),
        )
        session.add(row)
        session.commit()
        return str(row.id)

    def _get_artifact_native(self, experiment_id: str, name: str) -> bytes | None:
        """Retrieve artifact bytes from the artifacts table."""
        session = self._get_session()
        row = (
            session.query(ArtifactModel)
            .filter(
                ArtifactModel.experiment_id == uuid.UUID(experiment_id),
                ArtifactModel.name == name,
            )
            .first()
        )
        if row is None:
            return None
        return row.data  # type: ignore[return-value]

    def _list_artifacts_native(self, experiment_id: str) -> list[str]:
        """List artifact names for an experiment."""
        session = self._get_session()
        rows = (
            session.query(ArtifactModel.name)
            .filter(
                ArtifactModel.experiment_id == uuid.UUID(experiment_id),
            )
            .order_by(ArtifactModel.name)
            .all()
        )
        return [r[0] for r in rows]

    def _delete_artifact_native(self, experiment_id: str, name: str) -> bool:
        """Delete artifact from the artifacts table."""
        session = self._get_session()
        row = (
            session.query(ArtifactModel)
            .filter(
                ArtifactModel.experiment_id == uuid.UUID(experiment_id),
                ArtifactModel.name == name,
            )
            .first()
        )
        if row is None:
            return False
        session.delete(row)
        session.commit()
        return True
