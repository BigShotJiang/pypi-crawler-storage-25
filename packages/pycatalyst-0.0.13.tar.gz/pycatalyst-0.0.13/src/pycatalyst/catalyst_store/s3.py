"""S3-backed artifact store using boto3.

Standalone ``ArtifactBackend`` implementation. Can be used as a delegate
on any ``CatalystStoreClient`` or independently.

Credential resolution (standard boto3 chain):
    1. Explicit ``credentials`` dict passed to constructor.
    2. Environment variables (``AWS_ACCESS_KEY_ID``, ``AWS_SECRET_ACCESS_KEY``).
    3. Shared credentials file (``~/.aws/credentials``).
    4. IAM instance role (EC2, ECS, Lambda).

Example::

    store.artifact_backend = S3ArtifactStore(bucket="my-models")
    store.store_artifact(exp_id, "model.pt", model_bytes)  # -> S3
"""

from __future__ import annotations

import logging
import os
from typing import Any

try:
    import boto3
    from botocore.exceptions import ClientError

    S3_AVAILABLE = True
except ImportError:
    S3_AVAILABLE = False
    boto3 = None  # type: ignore[assignment]
    ClientError = None  # type: ignore[assignment,misc]

logger = logging.getLogger(__name__)


class S3ArtifactStore:
    """S3-backed binary artifact storage.

    Keys are formatted as ``{prefix}{experiment_id}/{name}``.

    Args:
        bucket: S3 bucket name. Falls back to ``PYCATALYST_S3_BUCKET`` env var.
        prefix: Key prefix (default ``"artifacts/"``). Falls back to
            ``PYCATALYST_S3_PREFIX`` env var.
        region: AWS region (default ``"us-east-1"``). Falls back to
            ``AWS_DEFAULT_REGION`` env var.
        credentials: Optional dict with ``aws_access_key_id`` and
            ``aws_secret_access_key``. When absent, boto3's default
            credential chain is used.
    """

    def __init__(
        self,
        bucket: str | None = None,
        prefix: str | None = None,
        region: str | None = None,
        credentials: dict[str, str] | None = None,
    ) -> None:
        if not S3_AVAILABLE:
            raise ImportError(
                "boto3 is required for S3ArtifactStore. "
                "Install with: pip install pycatalyst[s3]"
            )
        self._bucket = bucket or os.environ.get("PYCATALYST_S3_BUCKET", "")
        if not self._bucket:
            raise ValueError(
                "S3 bucket is required. Pass bucket= or set "
                "PYCATALYST_S3_BUCKET env var."
            )
        self._prefix = (
            prefix
            if prefix is not None
            else os.environ.get("PYCATALYST_S3_PREFIX", "artifacts/")
        )
        self._region = region or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        self._client = self._create_client(credentials)

    def _create_client(self, credentials: dict[str, str] | None) -> Any:
        """Create boto3 S3 client with optional explicit credentials."""
        kwargs: dict[str, Any] = {"region_name": self._region}
        if credentials:
            kwargs["aws_access_key_id"] = credentials["aws_access_key_id"]
            kwargs["aws_secret_access_key"] = credentials["aws_secret_access_key"]
        return boto3.client("s3", **kwargs)

    def _key(self, experiment_id: str, name: str) -> str:
        """Build the full S3 object key."""
        return f"{self._prefix}{experiment_id}/{name}"

    # -- ArtifactBackend protocol -------------------------------------------

    def store_artifact(self, experiment_id: str, name: str, data: bytes) -> str:
        """Upload artifact to S3.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.
            data: Raw bytes.

        Returns:
            S3 object key.
        """
        key = self._key(experiment_id, name)
        self._client.put_object(
            Bucket=self._bucket,
            Key=key,
            Body=data,
        )
        logger.info("stored artifact s3://%s/%s", self._bucket, key)
        return key

    def get_artifact(self, experiment_id: str, name: str) -> bytes | None:
        """Download artifact from S3.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.

        Returns:
            Raw bytes or ``None`` if not found.
        """
        key = self._key(experiment_id, name)
        try:
            response = self._client.get_object(Bucket=self._bucket, Key=key)
            return response["Body"].read()
        except ClientError as exc:
            if exc.response["Error"]["Code"] == "NoSuchKey":
                return None
            raise

    def list_artifacts(self, experiment_id: str) -> list[str]:
        """List artifact names for an experiment in S3.

        Args:
            experiment_id: Owning experiment ID.

        Returns:
            List of artifact name strings.
        """
        prefix = f"{self._prefix}{experiment_id}/"
        names: list[str] = []
        paginator = self._client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self._bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                artifact_name = obj["Key"].removeprefix(prefix)
                if artifact_name:
                    names.append(artifact_name)
        return sorted(names)

    def delete_artifact(self, experiment_id: str, name: str) -> bool:
        """Delete artifact from S3.

        Args:
            experiment_id: Owning experiment ID.
            name: Artifact name.

        Returns:
            ``True`` if the object existed and was deleted, ``False``
            if not found.
        """
        key = self._key(experiment_id, name)
        try:
            self._client.head_object(Bucket=self._bucket, Key=key)
        except ClientError as exc:
            if exc.response["Error"]["Code"] == "404":
                return False
            raise
        self._client.delete_object(Bucket=self._bucket, Key=key)
        logger.info("deleted artifact s3://%s/%s", self._bucket, key)
        return True
