"""Serialization helpers for streamed records (SSE, NDJSON)."""

from __future__ import annotations

import json
from typing import Any


def sse_event(data: dict[str, Any], *, event: str = "record") -> str:
    """Format one Server-Sent Events message (data lines + blank line)."""
    payload = json.dumps(data, separators=(",", ":"))
    return f"event: {event}\ndata: {payload}\n\n"


def ndjson_line(data: dict[str, Any]) -> str:
    """One newline-terminated JSON object for NDJSON stdout."""
    return json.dumps(data, separators=(",", ":")) + "\n"
