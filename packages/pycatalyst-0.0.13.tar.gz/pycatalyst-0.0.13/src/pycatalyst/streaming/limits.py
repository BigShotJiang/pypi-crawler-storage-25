"""Configurable caps for streaming (HTTP, CLI)."""

from __future__ import annotations

import os
from dataclasses import dataclass


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        return max(1, int(raw))
    except ValueError:
        return default


@dataclass(frozen=True)
class StreamLimits:
    """Upper bounds for stream requests (env-overridable)."""

    max_records: int = 100_000
    max_interval_ms: int = 60_000

    @classmethod
    def from_env(cls) -> StreamLimits:
        return cls(
            max_records=_env_int("PYCATALYST_STREAM_MAX_RECORDS", 100_000),
            max_interval_ms=_env_int("PYCATALYST_STREAM_MAX_INTERVAL_MS", 60_000),
        )


def clamp_stream_params(
    max_records: int,
    interval_ms: int,
    *,
    limits: StreamLimits | None = None,
) -> tuple[int, int]:
    """Clamp ``max_records`` and ``interval_ms`` to configured ceilings."""
    lim = limits or StreamLimits.from_env()
    n = min(max(1, max_records), lim.max_records)
    ms = min(max(0, interval_ms), lim.max_interval_ms)
    return n, ms
