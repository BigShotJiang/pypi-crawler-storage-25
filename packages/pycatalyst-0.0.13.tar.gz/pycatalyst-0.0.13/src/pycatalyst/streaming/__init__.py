"""Streaming helpers: record iteration wrappers and wire formats.

Use :meth:`pycatalyst.generators.engine.GenerationEngine.iter_records` for
the core iterator, or :func:`stream_records` for a one-liner.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from pycatalyst._types import SchemaSpec
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.streaming.formats import ndjson_line, sse_event
from pycatalyst.streaming.limits import StreamLimits, clamp_stream_params

__all__ = [
    "StreamLimits",
    "clamp_stream_params",
    "ndjson_line",
    "sse_event",
    "stream_records",
]


def stream_records(
    schema: SchemaSpec,
    *,
    limit: int,
    seed: int | None = None,
    engine: GenerationEngine | None = None,
) -> Iterator[dict[str, Any]]:
    """Yield up to ``limit`` records for ``schema`` (thin wrapper over the engine).

    Example:
        >>> from pycatalyst import GenerationEngine, SchemaBuilder
        >>> engine = GenerationEngine()
        >>> schema = SchemaBuilder("x").add_string("id").build()
        >>> list(stream_records(schema, limit=2, engine=engine))
    """
    gen = engine or GenerationEngine()
    yield from gen.iter_records(schema, seed=seed, limit=limit)
