"""Service container manager — spins up dockerized Postgres/MongoDB on demand.

Manages the lifecycle of companion database containers for workbench
environments: create, health-check, destroy, and orphan recovery.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from pycatalyst.errors import ServiceError

logger = logging.getLogger(__name__)

# Guard docker imports — the docker package is an optional dependency.
try:
    from docker.errors import APIError as DockerAPIError
    from docker.errors import ImageNotFound as DockerImageNotFound
except ImportError:

    class DockerImageNotFound(Exception):  # type: ignore[no-redef]
        """Stub for docker.errors.ImageNotFound when docker is not installed."""

    class DockerAPIError(Exception):  # type: ignore[no-redef]
        """Stub for docker.errors.APIError when docker is not installed."""

# ── Nanosecond constants for Docker healthcheck config ──────────────────────

_NS_PER_SECOND = 1_000_000_000

# ── Health-check polling backoff ────────────────────────────────────────────

_POLL_INITIAL = 0.5
_POLL_MULTIPLIER = 2.0
_POLL_MAX = 5.0


class ServiceType(str, Enum):
    """Supported database service types."""

    POSTGRES = "postgres"
    MONGODB = "mongodb"


class ServiceStatus(str, Enum):
    """Lifecycle status of a service container."""

    CREATING = "creating"
    STARTING = "starting"
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class ServiceConfig:
    """Immutable configuration for a service container.

    Attributes:
        service_type: Which database engine to run.
        database: Name of the initial database to create.
        username: Database admin username.
        password: Database admin password.
        image: Docker image override (resolved from config if empty).
        mem_limit: Container memory limit (e.g. '512m').
    """

    service_type: ServiceType
    database: str = "pycatalyst_db"
    username: str = "pycatalyst"
    password: str = "pycatalyst_dev"
    image: str = ""
    mem_limit: str = ""


@dataclass(slots=True)
class ServiceInfo:
    """Runtime state of a service container.

    Attributes:
        service_id: Unique identifier for this service instance.
        env_id: The workbench environment this service is tied to.
        service_type: Which database engine is running.
        config: The config used to create this service.
        status: Current lifecycle status.
        host_url: Connection string reachable from the host (localhost:port).
        container_url: Connection string reachable from sibling containers.
        host_port: The mapped host port.
        container_name: Docker container name (used as DNS in bridge network).
        container_id: Docker container short ID.
        created_at: Unix timestamp of creation.
        error_message: Last error message, if any.
    """

    service_id: str
    env_id: str
    service_type: ServiceType
    config: ServiceConfig
    status: ServiceStatus = ServiceStatus.CREATING
    host_url: str = ""
    container_url: str = ""
    host_port: int = 0
    container_name: str = ""
    container_id: str = ""
    created_at: float = field(default_factory=time.time)
    error_message: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a dict suitable for API responses."""
        return {
            "service_id": self.service_id,
            "env_id": self.env_id,
            "service_type": self.service_type.value,
            "status": self.status.value,
            "host_url": self.host_url,
            "container_url": self.container_url,
            "host_port": self.host_port,
            "container_name": self.container_name,
            "container_id": self.container_id,
            "database": self.config.database,
            "username": self.config.username,
            "created_at": self.created_at,
            "error_message": self.error_message,
        }


# ── Docker helpers per service type ─────────────────────────────────────────


def _postgres_run_kwargs(cfg: ServiceConfig, name: str) -> dict[str, Any]:
    """Build ``containers.run()`` kwargs for Postgres."""
    return {
        "environment": {
            "POSTGRES_USER": cfg.username,
            "POSTGRES_PASSWORD": cfg.password,
            "POSTGRES_DB": cfg.database,
        },
        "healthcheck": {
            "test": ["CMD-SHELL", f"pg_isready -U {cfg.username} -d {cfg.database}"],
            "interval": 2 * _NS_PER_SECOND,
            "timeout": 5 * _NS_PER_SECOND,
            "retries": 5,
            "start_period": 5 * _NS_PER_SECOND,
        },
        "ports": {"5432/tcp": None},
        "internal_port": 5432,
    }


def _mongodb_run_kwargs(cfg: ServiceConfig, name: str) -> dict[str, Any]:
    """Build ``containers.run()`` kwargs for MongoDB."""
    return {
        "environment": {
            "MONGO_INITDB_ROOT_USERNAME": cfg.username,
            "MONGO_INITDB_ROOT_PASSWORD": cfg.password,
            "MONGO_INITDB_DATABASE": cfg.database,
        },
        "healthcheck": {
            "test": [
                "CMD-SHELL",
                "mongosh --eval 'db.runCommand({ping:1})' --quiet",
            ],
            "interval": 2 * _NS_PER_SECOND,
            "timeout": 5 * _NS_PER_SECOND,
            "retries": 5,
            "start_period": 10 * _NS_PER_SECOND,
        },
        "ports": {"27017/tcp": None},
        "internal_port": 27017,
    }


_SERVICE_RUN_KWARGS = {
    ServiceType.POSTGRES: _postgres_run_kwargs,
    ServiceType.MONGODB: _mongodb_run_kwargs,
}


def _build_urls(
    stype: ServiceType,
    cfg: ServiceConfig,
    container_name: str,
    host_port: int,
    internal_port: int,
) -> tuple[str, str]:
    """Return (host_url, container_url) connection strings."""
    if stype == ServiceType.POSTGRES:
        base = f"postgresql://{cfg.username}:{cfg.password}@"
        host_url = f"{base}localhost:{host_port}/{cfg.database}"
        container_url = f"{base}{container_name}:{internal_port}/{cfg.database}"
    else:
        base = f"mongodb://{cfg.username}:{cfg.password}@"
        qs = f"/{cfg.database}?authSource=admin"
        host_url = f"{base}localhost:{host_port}{qs}"
        container_url = f"{base}{container_name}:{internal_port}{qs}"
    return host_url, container_url


# ── Manager ─────────────────────────────────────────────────────────────────


class ServiceContainerManager:
    """Manages dockerized database service containers for workbench envs."""

    def __init__(self, client: Any) -> None:
        self._client = client
        self._services: dict[str, ServiceInfo] = {}
        self._networks: dict[str, Any] = {}  # env_id → docker Network
        self._containers: dict[str, Any] = {}  # service_id → docker Container
        self._lock = asyncio.Lock()
        self._recover_orphans()

    # ------------------------------------------------------------------
    # Orphan recovery
    # ------------------------------------------------------------------

    def _recover_orphans(self) -> None:
        """Scan Docker for pycatalyst service containers and reconcile."""
        try:
            containers = self._client.containers.list(
                all=True,
                filters={"label": "pycatalyst.service=true"},
            )
        except Exception:
            logger.warning("Could not scan for orphan service containers")
            return

        for container in containers:
            labels = container.labels or {}
            env_id = labels.get("pycatalyst.env_id", "")
            stype_raw = labels.get("pycatalyst.service_type", "")
            svc_id = labels.get("pycatalyst.service_id", "")

            if not env_id or not stype_raw or not svc_id:
                logger.warning(
                    "Removing unlabelled orphan service container %s",
                    container.short_id,
                )
                self._force_remove_container(container)
                continue

            try:
                stype = ServiceType(stype_raw)
            except ValueError:
                logger.warning(
                    "Removing orphan with unknown service_type=%s", stype_raw
                )
                self._force_remove_container(container)
                continue

            # Rebuild in-memory state from the live container
            status = self._docker_status_to_service_status(container)
            cfg = ServiceConfig(service_type=stype)
            info = ServiceInfo(
                service_id=svc_id,
                env_id=env_id,
                service_type=stype,
                config=cfg,
                status=status,
                container_name=container.name or "",
                container_id=container.short_id,
            )

            # Try to resolve host port and build URLs
            try:
                container.reload()
                host_port = self._extract_host_port(container, stype)
                if host_port:
                    internal = 5432 if stype == ServiceType.POSTGRES else 27017
                    h_url, c_url = _build_urls(
                        stype, cfg, info.container_name, host_port, internal
                    )
                    info.host_url = h_url
                    info.container_url = c_url
                    info.host_port = host_port
            except Exception:
                logger.debug("Could not resolve port for recovered service %s", svc_id)

            self._services[svc_id] = info
            self._containers[svc_id] = container
            logger.info(
                "Recovered orphan service %s (%s, env=%s, status=%s)",
                svc_id,
                stype.value,
                env_id,
                status.value,
            )

    # ------------------------------------------------------------------
    # Network management
    # ------------------------------------------------------------------

    def ensure_network(self, env_id: str) -> Any:
        """Create or return the Docker bridge network for an environment."""
        if env_id in self._networks:
            return self._networks[env_id]

        net_name = f"pycatalyst-net-{env_id}"
        try:
            network = self._client.networks.create(
                net_name,
                driver="bridge",
                labels={
                    "pycatalyst.service": "true",
                    "pycatalyst.env_id": env_id,
                },
            )
        except Exception:
            # Network may already exist (e.g. from a recovered orphan)
            try:
                existing = self._client.networks.list(names=[net_name])
                if existing:
                    network = existing[0]
                else:
                    raise
            except Exception as exc:
                raise ServiceError(
                    f"Failed to create Docker network for env {env_id}",
                    service_type="network",
                    context={"env_id": env_id},
                ) from exc

        self._networks[env_id] = network
        logger.info("Ensured Docker network %s for env %s", net_name, env_id)
        return network

    # ------------------------------------------------------------------
    # Service creation
    # ------------------------------------------------------------------

    async def create_service(
        self,
        env_id: str,
        config: ServiceConfig,
    ) -> ServiceInfo:
        """Create a database service container for an environment.

        Lock-guarded. Idempotent: returns existing if same type+env.
        Rolls back partial resources on failure.
        """
        async with self._lock:
            # Idempotent — return existing service if already created
            for svc in self._services.values():
                if (
                    svc.env_id == env_id
                    and svc.service_type == config.service_type
                    and svc.status not in (ServiceStatus.STOPPED, ServiceStatus.ERROR)
                ):
                    return svc

            # Enforce per-env limit
            from pycatalyst.config.workbench import get_service_max_per_env

            active = sum(
                1
                for s in self._services.values()
                if s.env_id == env_id
                and s.status not in (ServiceStatus.STOPPED, ServiceStatus.ERROR)
            )
            limit = get_service_max_per_env()
            if active >= limit:
                raise ServiceError(
                    f"Maximum services per environment ({limit}) reached",
                    service_type=config.service_type.value,
                    context={"env_id": env_id, "limit": limit},
                )

            # Resolve image from config
            resolved_config = self._resolve_config(config)

            service_id = uuid.uuid4().hex[:12]
            container_name = f"pycatalyst-svc-{config.service_type.value}-{env_id}"

            info = ServiceInfo(
                service_id=service_id,
                env_id=env_id,
                service_type=config.service_type,
                config=resolved_config,
                status=ServiceStatus.CREATING,
                container_name=container_name,
            )
            self._services[service_id] = info

            network_created_here = env_id not in self._networks
            container = None
            try:
                network = await asyncio.to_thread(self.ensure_network, env_id)
                info.status = ServiceStatus.STARTING
                container = await asyncio.to_thread(
                    self._create_container, env_id, resolved_config, network, info
                )
                self._containers[service_id] = container
                info.container_id = container.short_id
            except ServiceError:
                # Clean up on failure
                self._services.pop(service_id, None)
                if container is not None:
                    self._force_remove_container(container)
                if network_created_here:
                    self._safe_remove_network(env_id)
                raise
            except Exception as exc:
                self._services.pop(service_id, None)
                if container is not None:
                    self._force_remove_container(container)
                if network_created_here:
                    self._safe_remove_network(env_id)
                raise ServiceError(
                    f"Failed to create {config.service_type.value} service: {exc}",
                    service_id=service_id,
                    service_type=config.service_type.value,
                ) from exc

        # Wait for healthy (outside lock so we don't block other operations)
        healthy = await self.wait_healthy(service_id)
        if not healthy:
            info.status = ServiceStatus.ERROR
            info.error_message = (
                "Service container did not become healthy within timeout"
            )
            logger.warning(
                "Service %s (%s) failed health check — cleaning up",
                service_id,
                config.service_type.value,
            )
            # Clean up unhealthy container
            await self.destroy_service(service_id)
            raise ServiceError(
                info.error_message,
                service_id=service_id,
                service_type=config.service_type.value,
            )

        return info

    def _resolve_config(self, config: ServiceConfig) -> ServiceConfig:
        """Fill in image and mem_limit from environment config if not set."""
        from pycatalyst.config.workbench import (
            get_service_mem_limit,
            get_service_mongodb_image,
            get_service_postgres_image,
        )

        image = config.image
        if not image:
            if config.service_type == ServiceType.POSTGRES:
                image = get_service_postgres_image()
            else:
                image = get_service_mongodb_image()

        mem = config.mem_limit or get_service_mem_limit()

        return ServiceConfig(
            service_type=config.service_type,
            database=config.database,
            username=config.username,
            password=config.password,
            image=image,
            mem_limit=mem,
        )

    def _create_container(
        self,
        env_id: str,
        config: ServiceConfig,
        network: Any,
        info: ServiceInfo,
    ) -> Any:
        """Create the Docker container (runs in thread)."""
        builder = _SERVICE_RUN_KWARGS[config.service_type]
        kwargs = builder(config, info.container_name)

        internal_port = kwargs.pop("internal_port")

        try:
            container = self._client.containers.run(
                config.image,
                detach=True,
                name=info.container_name,
                mem_limit=config.mem_limit,
                network=network.name,
                restart_policy={"Name": "unless-stopped"},
                labels={
                    "pycatalyst.service": "true",
                    "pycatalyst.env_id": env_id,
                    "pycatalyst.service_type": config.service_type.value,
                    "pycatalyst.service_id": info.service_id,
                },
                **kwargs,
            )
        except DockerImageNotFound as exc:
            raise ServiceError(
                f"Docker image '{config.image}' not found. "
                f"Pull it with 'docker pull {config.image}' or set "
                f"PYCATALYST_SERVICE_{config.service_type.value.upper()}_IMAGE",
                service_id=info.service_id,
                service_type=config.service_type.value,
            ) from exc
        except DockerAPIError as exc:
            logger.warning(
                "Docker API error creating %s service: %s",
                config.service_type.value,
                exc,
            )
            raise ServiceError(
                f"Docker API error: {exc}",
                service_id=info.service_id,
                service_type=config.service_type.value,
            ) from exc

        # Extract the mapped host port
        container.reload()
        host_port = self._extract_host_port(container, config.service_type)
        if host_port:
            h_url, c_url = _build_urls(
                config.service_type,
                config,
                info.container_name,
                host_port,
                internal_port,
            )
            info.host_url = h_url
            info.container_url = c_url
            info.host_port = host_port

        logger.info(
            "Created %s container %s (port=%s, env=%s)",
            config.service_type.value,
            container.short_id,
            host_port,
            env_id,
        )
        return container

    # ------------------------------------------------------------------
    # Health checking
    # ------------------------------------------------------------------

    async def wait_healthy(self, service_id: str, timeout: int = 0) -> bool:
        """Poll Docker health status with exponential backoff.

        Returns True if healthy within timeout, False otherwise.
        """
        if timeout <= 0:
            from pycatalyst.config.workbench import get_service_health_timeout

            timeout = get_service_health_timeout()

        container = self._containers.get(service_id)
        info = self._services.get(service_id)
        if container is None or info is None:
            return False

        deadline = time.monotonic() + timeout
        delay = _POLL_INITIAL

        while time.monotonic() < deadline:
            try:
                status = await asyncio.to_thread(self._check_health, container)
            except Exception:
                status = "error"

            if status == "healthy":
                info.status = ServiceStatus.HEALTHY
                logger.info("Service %s is healthy", service_id)
                return True

            if status in ("unhealthy", "error"):
                info.status = ServiceStatus.UNHEALTHY
                logger.warning("Service %s health check: %s", service_id, status)
                return False

            await asyncio.sleep(delay)
            delay = min(delay * _POLL_MULTIPLIER, _POLL_MAX)

        info.status = ServiceStatus.UNHEALTHY
        logger.warning(
            "Service %s health check timed out after %ds", service_id, timeout
        )
        return False

    @staticmethod
    def _check_health(container: Any) -> str:
        """Read Docker health status (runs in thread)."""
        container.reload()
        health = container.attrs.get("State", {}).get("Health", {})
        return health.get("Status", "starting")

    # ------------------------------------------------------------------
    # Destruction
    # ------------------------------------------------------------------

    async def destroy_service(self, service_id: str) -> None:
        """Stop and remove a service container. Idempotent."""
        async with self._lock:
            info = self._services.pop(service_id, None)
            container = self._containers.pop(service_id, None)

        if container is not None:
            await asyncio.to_thread(self._stop_remove_container, container)

        if info is not None:
            logger.info(
                "Destroyed service %s (%s, env=%s)",
                service_id,
                info.service_type.value,
                info.env_id,
            )

    async def destroy_all_for_env(self, env_id: str) -> None:
        """Destroy all services and the network for an environment."""
        svc_ids = [sid for sid, info in self._services.items() if info.env_id == env_id]
        for sid in svc_ids:
            try:
                await self.destroy_service(sid)
            except Exception:
                logger.warning("Failed to destroy service %s during env cleanup", sid)

        self._safe_remove_network(env_id)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_service(self, service_id: str) -> ServiceInfo | None:
        """Look up a service by ID."""
        return self._services.get(service_id)

    def list_services(self, env_id: str | None = None) -> list[ServiceInfo]:
        """List services, optionally filtered by environment."""
        if env_id is None:
            return list(self._services.values())
        return [s for s in self._services.values() if s.env_id == env_id]

    def refresh_status(self, service_id: str) -> ServiceStatus | None:
        """Reload container status from Docker."""
        info = self._services.get(service_id)
        container = self._containers.get(service_id)
        if info is None:
            return None

        if container is None:
            info.status = ServiceStatus.STOPPED
            return info.status

        try:
            info.status = self._docker_status_to_service_status(container)
        except Exception:
            info.status = ServiceStatus.STOPPED
            logger.debug(
                "Container not found for service %s — marking stopped", service_id
            )

        return info.status

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------

    def shutdown(self) -> None:
        """Stop all service containers and remove all networks."""
        for sid, container in list(self._containers.items()):
            try:
                self._stop_remove_container(container)
            except Exception:
                logger.warning("Failed to stop service container %s on shutdown", sid)

        self._containers.clear()
        self._services.clear()

        for env_id in list(self._networks.keys()):
            self._safe_remove_network(env_id)

        logger.info("ServiceContainerManager shut down")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_host_port(container: Any, stype: ServiceType) -> int:
        """Extract the mapped host port from container port bindings."""
        internal = "5432/tcp" if stype == ServiceType.POSTGRES else "27017/tcp"
        ports = container.attrs.get("NetworkSettings", {}).get("Ports", {})
        bindings = ports.get(internal, [])
        if bindings and bindings[0]:
            try:
                return int(bindings[0]["HostPort"])
            except (KeyError, ValueError, TypeError):
                pass
        return 0

    @staticmethod
    def _docker_status_to_service_status(container: Any) -> ServiceStatus:
        """Map Docker container state to ServiceStatus."""
        try:
            container.reload()
        except Exception:
            return ServiceStatus.STOPPED

        status = container.status
        if status == "running":
            health = (
                container.attrs.get("State", {}).get("Health", {}).get("Status", "")
            )
            if health == "healthy":
                return ServiceStatus.HEALTHY
            if health == "unhealthy":
                return ServiceStatus.UNHEALTHY
            return ServiceStatus.STARTING
        if status in ("created", "restarting"):
            return ServiceStatus.STARTING
        if status in ("exited", "dead", "removing"):
            return ServiceStatus.STOPPED
        return ServiceStatus.ERROR

    @staticmethod
    def _force_remove_container(container: Any) -> None:
        """Force-remove a container, swallowing errors."""
        try:
            container.stop(timeout=5)
        except Exception:
            pass
        try:
            container.remove(force=True)
        except Exception:
            logger.debug("Could not force-remove container %s", container.short_id)

    @staticmethod
    def _stop_remove_container(container: Any) -> None:
        """Stop + remove a container with logging."""
        try:
            container.stop(timeout=10)
        except Exception:
            logger.warning("Could not gracefully stop container %s", container.short_id)
        try:
            container.remove(force=True)
        except Exception:
            logger.warning("Could not remove container %s", container.short_id)

    def _safe_remove_network(self, env_id: str) -> None:
        """Remove a Docker network, ignoring errors."""
        network = self._networks.pop(env_id, None)
        if network is None:
            return
        try:
            network.remove()
            logger.info("Removed Docker network for env %s", env_id)
        except Exception:
            logger.debug(
                "Could not remove network for env %s (may still have containers)",
                env_id,
            )
