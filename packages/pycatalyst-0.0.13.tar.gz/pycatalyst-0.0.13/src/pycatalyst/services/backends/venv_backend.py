"""Tier 1 backend — per-session venv isolation using stdlib venv + pty.fork."""

from __future__ import annotations

import asyncio
import fcntl
import json
import logging
import os
import pty
import shutil
import signal
import struct
import sys
import termios
import uuid
from pathlib import Path
from typing import Any

from pycatalyst.services.backends.base import SessionHandle

logger = logging.getLogger(__name__)


def _resolve_command(command: str, venv_bin: Path) -> list[str]:
    """Turn a command name into a full argv list targeting *venv_bin*."""
    if command in ("bash", "sh", "zsh", "fish"):
        exe = shutil.which(command)
        if not exe:
            exe = shutil.which("bash") or shutil.which("sh") or "/bin/sh"
        return [exe, "-l"]

    if command == "python":
        python = str(venv_bin / "python")
        if os.path.isfile(python):
            return [python]
        return [sys.executable]

    if command == "ipython":
        ipython = str(venv_bin / "ipython")
        if os.path.isfile(ipython):
            return [ipython]
        python = str(venv_bin / "python")
        if os.path.isfile(python):
            return [python, "-m", "IPython"]
        return [sys.executable, "-m", "IPython"]

    exe = shutil.which(command)
    if exe:
        return [exe]
    raise ValueError(f"Command {command!r} not found on PATH")


def _build_venv_env(venv_path: Path) -> dict[str, str]:
    """Build env vars that activate *venv_path* for a child process.

    Strips PYTHONPATH so completions and imports match the venv only.
    """
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)
    env["TERM"] = "xterm-256color"
    env["VIRTUAL_ENV"] = str(venv_path)
    venv_bin = str(venv_path / "bin")
    parent_path = os.environ.get(
        "PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    )
    env["PATH"] = f"{venv_bin}:{parent_path}"
    env.pop("PYTHONHOME", None)
    return env


class VenvBackend:
    """Tier 1 backend: per-environment venv with PTY-backed sessions."""

    backend_type: str = "venv"

    def __init__(self, base_dir: str | Path) -> None:
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)
        self._envs: dict[str, Path] = {}
        self._sessions: dict[str, SessionHandle] = {}

    async def create(self) -> str:
        env_id = uuid.uuid4().hex[:12]
        venv_path = self._base_dir / env_id

        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-m",
            "venv",
            str(venv_path),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(
                f"Failed to create venv: {stderr.decode(errors='replace')}"
            )

        pip = venv_path / "bin" / "pip"
        if pip.is_file():
            upgrade = await asyncio.create_subprocess_exec(
                str(pip),
                "install",
                "--upgrade",
                "pip",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await upgrade.communicate()
            ipython_install = await asyncio.create_subprocess_exec(
                str(pip),
                "install",
                "ipython",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            _, ipy_stderr = await ipython_install.communicate()
            if ipython_install.returncode != 0:
                logger.warning(
                    "Failed to install ipython in venv %s: %s",
                    env_id,
                    ipy_stderr.decode(errors="replace").strip() or "unknown",
                )

        self._envs[env_id] = venv_path
        logger.info("Created venv environment %s at %s", env_id, venv_path)
        return env_id

    async def destroy(self, env_id: str) -> None:
        venv_path = self._envs.pop(env_id, None)
        if venv_path is None:
            return

        for sid, handle in list(self._sessions.items()):
            if handle.env_id == env_id:
                handle.close()
                self._sessions.pop(sid, None)

        await asyncio.to_thread(shutil.rmtree, venv_path, ignore_errors=True)
        logger.info("Destroyed venv environment %s", env_id)

    async def spawn_session(
        self,
        env_id: str,
        command: str,
        cols: int,
        rows: int,
    ) -> SessionHandle:
        venv_path = self._envs.get(env_id)
        if venv_path is None:
            raise ValueError(f"Unknown venv environment: {env_id}")

        venv_bin = venv_path / "bin"
        argv = _resolve_command(command, venv_bin)
        env = _build_venv_env(venv_path)

        child_pid, fd = pty.fork()

        if child_pid == 0:
            os.execvpe(argv[0], argv, env)
            os._exit(1)

        flags = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

        session_id = uuid.uuid4().hex[:12]
        closed = False

        def _write(data: bytes) -> None:
            nonlocal closed
            if closed:
                return
            try:
                os.write(fd, data)
            except OSError:
                pass

        def _resize(c: int, r: int) -> None:
            nonlocal closed
            if closed:
                return
            try:
                winsize = struct.pack("HHHH", r, c, 0, 0)
                fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)
            except OSError:
                pass

        def _close() -> None:
            nonlocal closed
            if closed:
                return
            closed = True
            try:
                os.close(fd)
            except OSError:
                pass
            try:
                os.kill(child_pid, signal.SIGHUP)
            except OSError:
                pass
            try:
                os.waitpid(child_pid, os.WNOHANG)
            except ChildProcessError:
                pass

        def _is_alive() -> bool:
            if closed:
                return False
            try:
                pid_result, _ = os.waitpid(child_pid, os.WNOHANG)
                return pid_result == 0
            except ChildProcessError:
                return False

        handle = SessionHandle(
            session_id=session_id,
            env_id=env_id,
            command=command,
            backend_type="venv",
            read_fd=fd,
            write=_write,
            resize=_resize,
            close=_close,
            is_alive=_is_alive,
            pid=child_pid,
            cols=cols,
            rows=rows,
        )

        _resize(cols, rows)
        self._sessions[session_id] = handle
        logger.info(
            "Spawned venv session %s (pid=%d, cmd=%s, env=%s)",
            session_id,
            child_pid,
            command,
            env_id,
        )
        return handle

    async def install_packages(
        self,
        env_id: str,
        packages: list[str],
        *,
        editable: bool = False,
        upgrade: bool = False,
    ) -> dict[str, Any]:
        """Install packages into the venv via pip.

        Args:
            env_id: Environment identifier.
            packages: Package specs (names, paths, or URLs).
            editable: Use ``-e`` flag for editable installs.
            upgrade: Use ``--upgrade`` flag.

        Returns:
            Dict with ``success``, ``output``, and ``packages`` keys.
        """
        venv_path = self._envs.get(env_id)
        if venv_path is None:
            raise ValueError(f"Unknown venv environment: {env_id}")

        pip = str(venv_path / "bin" / "pip")
        args: list[str] = [pip, "install"]
        if editable:
            args.append("-e")
        if upgrade:
            args.append("--upgrade")
        args.extend(packages)

        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        stdout, _ = await proc.communicate()
        output = stdout.decode(errors="replace") if stdout else ""
        success = proc.returncode == 0

        if success:
            logger.info("Installed packages in venv %s: %s", env_id, packages)
        else:
            logger.warning("pip install failed in venv %s: %s", env_id, output[:200])

        installed = await self.list_packages(env_id)
        return {"success": success, "output": output, "packages": installed}

    async def uninstall_packages(
        self,
        env_id: str,
        packages: list[str],
    ) -> dict[str, Any]:
        """Uninstall packages from the venv via pip.

        Args:
            env_id: Environment identifier.
            packages: Package names to remove.

        Returns:
            Dict with ``success``, ``output``, and ``packages`` keys.
        """
        venv_path = self._envs.get(env_id)
        if venv_path is None:
            raise ValueError(f"Unknown venv environment: {env_id}")

        pip = str(venv_path / "bin" / "pip")
        args = [pip, "uninstall", "-y", *packages]

        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        stdout, _ = await proc.communicate()
        output = stdout.decode(errors="replace") if stdout else ""
        success = proc.returncode == 0

        if success:
            logger.info("Uninstalled packages from venv %s: %s", env_id, packages)
        else:
            logger.warning("pip uninstall failed in venv %s: %s", env_id, output[:200])

        remaining = await self.list_packages(env_id)
        return {"success": success, "output": output, "packages": remaining}

    async def list_packages(self, env_id: str) -> list[dict]:
        venv_path = self._envs.get(env_id)
        if venv_path is None:
            raise ValueError(f"Unknown venv environment: {env_id}")

        pip = venv_path / "bin" / "pip"
        if not pip.is_file():
            return []

        proc = await asyncio.create_subprocess_exec(
            str(pip),
            "list",
            "--format=json",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await proc.communicate()
        if proc.returncode != 0:
            return []

        try:
            return json.loads(stdout.decode())
        except (json.JSONDecodeError, ValueError):
            return []

    def get_session(self, session_id: str) -> SessionHandle | None:
        handle = self._sessions.get(session_id)
        if handle and not handle.is_alive():
            self._sessions.pop(session_id, None)
            return None
        return handle

    def remove_session(self, session_id: str) -> bool:
        handle = self._sessions.pop(session_id, None)
        if handle is None:
            return False
        handle.close()
        return True

    def get_env_path(self, env_id: str) -> Path | None:
        return self._envs.get(env_id)

    def has_env(self, env_id: str) -> bool:
        return env_id in self._envs

    def env_session_count(self, env_id: str) -> int:
        return sum(1 for h in self._sessions.values() if h.env_id == env_id)

    def list_sessions(self) -> list[SessionHandle]:
        """Return all active session handles."""
        return list(self._sessions.values())

    def shutdown(self) -> None:
        for handle in self._sessions.values():
            handle.close()
        self._sessions.clear()
        # Preserve venvs on disk so they survive server restarts.
        # Environments are cleaned up explicitly via destroy().
        self._envs.clear()
        logger.info("VenvBackend shut down")

    @classmethod
    def is_available(cls) -> bool:
        return True
