(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,87486,e=>{"use strict";var t=e.i(43476),a=e.i(25913),i=e.i(75157);let r=(0,a.cva)("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",{variants:{variant:{default:"border-transparent bg-primary text-primary-foreground hover:bg-primary/80",secondary:"border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",destructive:"border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",outline:"text-foreground"}},defaultVariants:{variant:"default"}});function s({className:e,variant:a,...s}){return(0,t.jsx)("div",{className:(0,i.cn)(r({variant:a}),e),...s})}e.s(["Badge",()=>s])},78583,e=>{"use strict";let t=(0,e.i(75254).default)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);e.s(["FileText",()=>t],78583)},58041,e=>{"use strict";let t=(0,e.i(75254).default)("Database",[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]]);e.s(["Database",()=>t],58041)},18393,e=>{"use strict";let t=(0,e.i(75254).default)("Server",[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2",key:"ngkwjq"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2",key:"iecqi9"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6",key:"16zg32"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18",key:"nzw8ys"}]]);e.s(["Server",()=>t],18393)},25931,e=>{"use strict";var t=e.i(43476),a=e.i(22016),i=e.i(15288),r=e.i(87486),s=e.i(19455),n=e.i(93998),o=e.i(22706),d=e.i(58041),c=e.i(78583),l=e.i(75254);let p=(0,l.default)("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]),u=(0,l.default)("HardDrive",[["line",{x1:"22",x2:"2",y1:"12",y2:"12",key:"1y58io"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",key:"oot6mr"}],["line",{x1:"6",x2:"6.01",y1:"16",y2:"16",key:"sgf278"}],["line",{x1:"10",x2:"10.01",y1:"16",y2:"16",key:"1l4acy"}]]),y=(0,l.default)("Radio",[["path",{d:"M4.9 19.1C1 15.2 1 8.8 4.9 4.9",key:"1vaf9d"}],["path",{d:"M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5",key:"u1ii0m"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5",key:"1j5fej"}],["path",{d:"M19.1 4.9C23 8.8 23 15.1 19.1 19",key:"10b0cb"}]]);var h=e.i(18393);let x=[{name:"Memory",description:"Store generated records in-memory for programmatic access and testing. No external dependencies required.",icon:u,extras:null,config:`sink:
  type: memory`},{name:"File",description:"Write records to JSON, CSV, or YAML files. Supports append mode for incremental writes.",icon:c.FileText,extras:null,config:`sink:
  type: file
  config:
    path: output/data.json
    format: json  # json, csv, yaml
    append: false`},{name:"HTTP",description:"Send records via HTTP POST/PUT/PATCH to REST APIs. Supports batching, auth tokens, and custom headers.",icon:p,extras:"pip install pycatalyst[http]",config:`sink:
  type: http
  config:
    url: http://localhost:8000/api/v1/data
    method: POST
    headers:
      Content-Type: application/json
    batch_size: 100
    timeout: 30`},{name:"Database",description:"Insert records into any SQL database via SQLAlchemy. Supports batching, append/replace modes.",icon:d.Database,extras:"pip install pycatalyst[db]",config:`sink:
  type: database
  config:
    connection_url: sqlite:///data.db
    table_name: generated_data
    batch_size: 500
    if_exists: append  # append or replace`},{name:"Kafka",description:"Publish records as JSON messages to Kafka topics. Supports key fields and delivery callbacks.",icon:y,extras:"pip install pycatalyst[kafka]",config:`sink:
  type: kafka
  config:
    bootstrap_servers: localhost:9092
    topic: test-data
    key_field: id
    flush_timeout: 10.0`},{name:"RabbitMQ",description:"Publish records to RabbitMQ exchanges. Supports queue declaration, routing keys, and persistent delivery.",icon:h.Server,extras:"pip install pycatalyst[rabbitmq]",config:`sink:
  type: rabbitmq
  config:
    url: amqp://guest:guest@localhost/
    exchange: ""
    routing_key: test-queue
    queue: test-queue
    declare_queue: true`}];function m(){return(0,t.jsxs)(n.PageContainer,{children:[(0,t.jsx)(o.PageHeader,{title:"Sinks",description:"Available data sink types for delivering generated records to targets"}),(0,t.jsx)("div",{className:"mb-6",children:(0,t.jsx)(s.Button,{asChild:!0,variant:"outline",size:"sm",children:(0,t.jsx)(a.default,{href:"/generate?mode=recipe",children:"Run a recipe with sink options in Generate"})})}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:x.map(e=>{let a=e.icon;return(0,t.jsxs)(i.Card,{children:[(0,t.jsxs)(i.CardHeader,{children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)(a,{className:"h-6 w-6 text-primary"}),(0,t.jsxs)("div",{children:[(0,t.jsx)(i.CardTitle,{className:"text-lg",children:e.name}),e.extras&&(0,t.jsx)(r.Badge,{variant:"secondary",className:"mt-1 font-mono text-xs",children:e.extras})]})]}),(0,t.jsx)(i.CardDescription,{className:"mt-2",children:e.description})]}),(0,t.jsx)(i.CardContent,{children:(0,t.jsx)("pre",{className:"bg-muted rounded-md p-3 overflow-x-auto text-xs font-mono",children:e.config})})]},e.name)})})]})}e.s(["default",()=>m],25931)}]);