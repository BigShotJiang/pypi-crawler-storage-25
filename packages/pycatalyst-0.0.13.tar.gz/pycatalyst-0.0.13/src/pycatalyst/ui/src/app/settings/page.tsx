'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { PageContainer } from '@/components/layout/PageContainer';
import { PageHeader } from '@/components/layout/PageHeader';
import { loadSettings, saveSettings } from '@/lib/settings';
import { api, type ArtifactStoreResponse, type AwsDataSourceResponse } from '@/lib/api';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export default function SettingsPage() {
  const [apiUrl, setApiUrl] = useState('');
  const [saved, setSaved] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [testing, setTesting] = useState(false);

  const [artifactType, setArtifactType] = useState<'database' | 's3'>('database');
  const [artifactS3Bucket, setArtifactS3Bucket] = useState('');
  const [artifactS3Prefix, setArtifactS3Prefix] = useState('');
  const [artifactLoading, setArtifactLoading] = useState(true);
  const [artifactError, setArtifactError] = useState<string | null>(null);
  // artifactSaved, artifactSaving removed — model storage is read-only

  const [awsLoading, setAwsLoading] = useState(true);
  const [awsError, setAwsError] = useState<string | null>(null);
  const [awsRegion, setAwsRegion] = useState('');
  const [awsProfile, setAwsProfile] = useState('');
  const [awsEndpointUrl, setAwsEndpointUrl] = useState('');
  const [awsCredSource, setAwsCredSource] = useState<'explicit' | 'profile' | 'ambient'>('ambient');
  const [awsAccessKeyConfigured, setAwsAccessKeyConfigured] = useState(false);
  const [awsSecretKeyConfigured, setAwsSecretKeyConfigured] = useState(false);
  const [awsSessionTokenConfigured, setAwsSessionTokenConfigured] = useState(false);

  useEffect(() => {
    const settings = loadSettings();
    setApiUrl(settings.apiServer.url);
  }, []);

  useEffect(() => {
    let cancelled = false;
    setAwsLoading(true);
    setAwsError(null);
    api.settings
      .getAwsDataSource()
      .then((data: AwsDataSourceResponse) => {
        if (cancelled) return;
        setAwsRegion(data.region ?? '');
        setAwsProfile(data.profile ?? '');
        setAwsEndpointUrl(data.s3_endpoint_url ?? '');
        setAwsCredSource(data.credentials_source ?? 'ambient');
        setAwsAccessKeyConfigured(!!data.access_key_id_configured);
        setAwsSecretKeyConfigured(!!data.secret_access_key_configured);
        setAwsSessionTokenConfigured(!!data.session_token_configured);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setAwsError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (!cancelled) setAwsLoading(false);
      });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setArtifactLoading(true);
    setArtifactError(null);
    api.settings
      .getArtifactStore()
      .then((data: ArtifactStoreResponse) => {
        if (cancelled) return;
        setArtifactType(data.type === 's3' ? 's3' : 'database');
        setArtifactS3Bucket(data.s3_bucket ?? '');
        setArtifactS3Prefix(data.s3_prefix ?? '');
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setArtifactError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (!cancelled) setArtifactLoading(false);
      });
    return () => { cancelled = true; };
  }, []);

  const handleSave = () => {
    const settings = loadSettings();
    settings.apiServer.url = apiUrl.trim();
    saveSettings(settings);
    setSaved(true);
    setTestResult(null);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    const url = apiUrl.trim() || window.location.origin;
    try {
      const res = await fetch(`${url.replace(/\/+$/, '')}/health`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        setTestResult({ ok: true, message: 'API server is reachable' });
      } else {
        setTestResult({ ok: false, message: `Server returned ${res.status}` });
      }
    } catch {
      setTestResult({ ok: false, message: 'Cannot connect to API server' });
    } finally {
      setTesting(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader title="Settings" description="Configure PyCatalyst UI preferences" />

      <div className="space-y-6 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>API Server</CardTitle>
            <CardDescription>
              Configure the PyCatalyst API server URL. Leave empty to use the default (same origin proxy).
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="api-url">API URL</Label>
              <Input
                id="api-url"
                value={apiUrl}
                onChange={(e) => { setApiUrl(e.target.value); setSaved(false); }}
                placeholder="http://localhost:8005"
              />
              <p className="text-xs text-muted-foreground">
                Default: http://localhost:8005 — Start with: <code className="font-mono">pycatalyst api</code>
              </p>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saved}>
                {saved ? 'Saved!' : 'Save'}
              </Button>
              <Button variant="outline" onClick={handleTest} disabled={testing}>
                {testing ? 'Testing...' : 'Test Connection'}
              </Button>
            </div>

            {testResult && (
              <Alert variant={testResult.ok ? 'default' : 'destructive'}>
                {testResult.ok ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <AlertCircle className="h-4 w-4" />
                )}
                <AlertDescription>{testResult.message}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Model storage</CardTitle>
            <CardDescription>
              Where models and artifacts are stored. Configure via environment variables or the
              <code className="mx-1 font-mono text-xs">[artifact]</code>
              section in pycatalyst.cfg (same as database URL, UI theme, etc.).
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {artifactLoading ? (
              <p className="text-sm text-muted-foreground">Loading…</p>
            ) : (
              <>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Storage type</Label>
                  <p className="text-sm font-medium capitalize">{artifactType}</p>
                </div>
                {artifactType === 's3' && (
                  <>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">S3 bucket</Label>
                      <p className="text-sm font-mono">{artifactS3Bucket || '—'}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">S3 prefix</Label>
                      <p className="text-sm font-mono">{artifactS3Prefix || 'artifacts/ (default)'}</p>
                    </div>
                  </>
                )}
                {artifactError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{artifactError}</AlertDescription>
                  </Alert>
                )}
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>AWS data source (S3)</CardTitle>
            <CardDescription>
              Resolved AWS configuration used for reading S3 training data.
              Environment variables take precedence over
              <code className="mx-1 font-mono text-xs">[aws]</code>
              in pycatalyst.cfg.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {awsLoading ? (
              <p className="text-sm text-muted-foreground">Loading…</p>
            ) : (
              <>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Credential source</Label>
                  <p className="text-sm font-medium capitalize">{awsCredSource}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Region</Label>
                  <p className="text-sm font-mono">{awsRegion || '—'}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Profile</Label>
                  <p className="text-sm font-mono">{awsProfile || '—'}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Custom S3 endpoint</Label>
                  <p className="text-sm font-mono">{awsEndpointUrl || '—'}</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="rounded-md border p-3">
                    <Label className="text-muted-foreground">Access key id</Label>
                    <p className="text-sm font-medium mt-1">{awsAccessKeyConfigured ? 'Configured' : 'Not set'}</p>
                  </div>
                  <div className="rounded-md border p-3">
                    <Label className="text-muted-foreground">Secret access key</Label>
                    <p className="text-sm font-medium mt-1">{awsSecretKeyConfigured ? 'Configured' : 'Not set'}</p>
                  </div>
                  <div className="rounded-md border p-3">
                    <Label className="text-muted-foreground">Session token</Label>
                    <p className="text-sm font-medium mt-1">{awsSessionTokenConfigured ? 'Configured' : 'Not set'}</p>
                  </div>
                </div>
                {awsError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{awsError}</AlertDescription>
                  </Alert>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
