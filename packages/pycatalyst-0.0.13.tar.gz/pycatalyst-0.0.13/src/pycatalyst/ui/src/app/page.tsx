'use client';

import Link from 'next/link';
import { Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { ROUTES } from '@/lib/constants';
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config';

const features = [
  {
    name: 'Generate',
    description:
      'Infer schemas from sample data, build schemas with the form, or run YAML recipes — then generate synthetic data in one place.',
    icon: Zap,
    href: ROUTES.GENERATE,
    cta: 'Open Generate',
  },
];

export default function Home() {
  const appName = useAppConfigStore(selectAppName);
  const version = useAppConfigStore(selectVersion);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
              {appName}
            </h1>
            <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-2xl mx-auto">
              Data Generation and Testing Platform
              {version && (
                <span className="block mt-2 text-sm font-medium text-muted-foreground">
                  Release {version}
                </span>
              )}
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <Link href={ROUTES.GENERATE}>
                <Button size="lg">Get Started</Button>
              </Link>
              <Link href={`${ROUTES.GENERATE}?mode=recipe`}>
                <Button variant="outline" size="lg">Browse Recipes</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:max-w-xl gap-6">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <Card key={feature.name}>
                <CardHeader>
                  <Icon className="h-8 w-8 text-primary mb-2" />
                  <CardTitle>{feature.name}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Link href={feature.href}>
                    <Button variant="outline" className="w-full">
                      {feature.cta}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
