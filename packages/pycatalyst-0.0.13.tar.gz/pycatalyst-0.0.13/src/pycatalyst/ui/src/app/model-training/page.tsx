'use client';

import { useState } from 'react';
import JSZip from 'jszip';
import { PageContainer } from '@/components/layout/PageContainer';
import { CollapsibleSidebar, type SidebarSection } from '@/components/sidebar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { api, ApiError } from '@/lib/api';
import type { MlRunResponse } from '@/lib/types';
import { BarChart3, Play, FileText, HelpCircle, FileArchive, Boxes } from 'lucide-react';
import { ModelRegistryPanel, RunPanel, ResultsPanel, useExperimentForm, TEMPLATE_SETS } from '@/components/model-training';
import type { TemplateKind } from '@/components/model-training';

type ModelTrainingView = 'overview' | 'run' | 'results' | 'models' | 'help';

const SIDEBAR_SECTIONS: SidebarSection[] = [
  { id: 'overview', title: 'Overview', icon: BarChart3, items: [{ id: 'overview', label: 'Overview' }] },
  { id: 'experiment', title: 'Experiment', icon: Play, items: [{ id: 'run', label: 'Run experiment' }] },
  { id: 'results', title: 'Results', icon: FileText, items: [{ id: 'results', label: 'Last run' }] },
  { id: 'models', title: 'Models', icon: Boxes, items: [{ id: 'models', label: 'Manage models' }] },
  { id: 'help', title: 'Help', icon: HelpCircle, items: [{ id: 'help', label: 'Config reference' }] },
];

function getHeaderInfo(view: ModelTrainingView): { title: string; description: string } {
  switch (view) {
    case 'overview':
      return { title: 'Model Training', description: 'Run and inspect ML experiments from YAML config' };
    case 'run':
      return { title: 'Run experiment', description: 'Configure and submit a training job' };
    case 'results':
      return { title: 'Last run', description: 'Metrics, artifacts, and training history from the latest run' };
    case 'models':
      return { title: 'Manage models', description: 'Browse saved model runs and manage persisted artifacts' };
    case 'help':
      return { title: 'Config reference', description: 'Required YAML shape and backend options' };
    default:
      return { title: 'Model Training', description: '' };
  }
}

const HELP_CONTENT = `# Experiment config (YAML)

Top-level key \`experiment\` is required with at least:

- \`name\`: string — experiment name
- \`backend\`: one of \`pytorch\`, \`sklearn\`, \`huggingface\`

Example (minimal):

\`\`\`yaml
experiment:
  name: my-experiment
  backend: sklearn
  # ... backend-specific sections (data, model, train)
\`\`\`

Backends require different sections (data path, model architecture, training params). See package docs for each engine.`;

async function downloadAllTemplatesAsZip(kind: TemplateKind) {
  const items = TEMPLATE_SETS[kind];
  const zip = new JSZip();
  const folder = zip.folder(`${kind}-templates`) ?? zip;
  for (const item of items) {
    folder.file(item.filename, item.content);
  }
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `pycatalyst-${kind}-templates.zip`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function ModelTrainingPage() {
  const [activeView, setActiveView] = useState<ModelTrainingView>('overview');
  const [lastResult, setLastResult] = useState<MlRunResponse | null>(null);
  const [running, setRunning] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);

  const form = useExperimentForm();

  const handleSidebarItemClick = (_sectionId: string, itemId: string) => {
    setActiveView(itemId as ModelTrainingView);
    setRunError(null);
  };

  const handleRun = async () => {
    const config = form.getSubmitYaml();
    if (!config.trim()) {
      setRunError('Enter a non-empty YAML config');
      return;
    }
    setRunError(null);
    setRunning(true);
    try {
      const result = await api.ml.runExperiment({ config });
      setLastResult(result);
      setActiveView('results');
    } catch (err) {
      let msg = 'Run failed';
      if (err instanceof ApiError) {
        const d = err.response?.detail;
        msg = typeof d === 'object' && d !== null && 'message' in d
          ? String((d as { message: unknown }).message)
          : typeof d === 'string'
            ? d
            : err.message;
      } else if (err instanceof Error) {
        msg = err.message;
      }
      setRunError(msg);
    } finally {
      setRunning(false);
    }
  };

  const { title, description } = getHeaderInfo(activeView);

  return (
    <PageContainer fullHeight>
      <CollapsibleSidebar
        sections={SIDEBAR_SECTIONS}
        headerTitle="Model Training"
        onItemClick={handleSidebarItemClick}
        selectedItemId={activeView}
      />
      <main className="flex-1 overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
          </div>
          {(activeView === 'overview' || activeView === 'run') && (
            <div className="flex items-center gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={() => downloadAllTemplatesAsZip('sklearn')}>
                <FileArchive className="mr-2 h-4 w-4" />Sklearn (zip)
              </Button>
              <Button variant="outline" size="sm" onClick={() => downloadAllTemplatesAsZip('pytorch')}>
                <FileArchive className="mr-2 h-4 w-4" />PyTorch (zip)
              </Button>
              <Button variant="outline" size="sm" onClick={() => downloadAllTemplatesAsZip('huggingface')}>
                <FileArchive className="mr-2 h-4 w-4" />HF (zip)
              </Button>
              {activeView === 'overview' && (
                <Button onClick={() => setActiveView('run')}>Run experiment</Button>
              )}
            </div>
          )}
        </div>

        {activeView === 'overview' && (
          <Card>
            <CardHeader>
              <CardTitle>Overview</CardTitle>
              <CardDescription>
                Run ML experiments (PyTorch, sklearn, Hugging Face) using the visual form builder or raw YAML. Download template patterns above or jump straight into the experiment builder.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Backends: <code className="bg-muted px-1 rounded">pytorch</code>, <code className="bg-muted px-1 rounded">sklearn</code>, <code className="bg-muted px-1 rounded">huggingface</code>.
                {lastResult && (
                  <span className="block mt-2">
                    Last run: <strong>{lastResult.name}</strong> ({lastResult.backend}) — {lastResult.duration_seconds.toFixed(1)}s
                  </span>
                )}
              </p>
              <Button onClick={() => setActiveView('run')}>Run experiment</Button>
            </CardContent>
          </Card>
        )}

        {activeView === 'run' && (
          <RunPanel
            form={form}
            running={running}
            runError={runError}
            onRun={handleRun}
          />
        )}

        {activeView === 'results' && (
          <ResultsPanel
            result={lastResult}
            onRunAgain={() => setActiveView('run')}
          />
        )}

        {activeView === 'help' && (
          <Card>
            <CardHeader>
              <CardTitle>Config reference</CardTitle>
              <CardDescription>Required YAML structure for experiment config.</CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto text-sm whitespace-pre-wrap font-mono text-foreground">
                {HELP_CONTENT}
              </pre>
            </CardContent>
          </Card>
        )}

        {activeView === 'models' && (
          <ModelRegistryPanel highlightedModelId={lastResult?.persisted_model_id ?? null} />
        )}
      </main>
    </PageContainer>
  );
}
