'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function RecipesPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/generate?mode=recipe', { scroll: false });
  }, [router]);

  return (
    <div className="flex items-center justify-center min-h-[200px] text-muted-foreground">
      Redirecting to Generate…
    </div>
  );
}
