'use client';

import { Panel, Group, Separator } from 'react-resizable-panels';
import {
  ResizableWorkspaceLayout,
  type SidebarLayoutApi,
} from '@/components/layout/ResizableWorkspaceLayout';
import { GenerateSidebar } from '@/components/generate/ide/GenerateSidebar';
import { GenerateToolbar } from '@/components/generate/ide/GenerateToolbar';
import { SchemaFieldTable } from '@/components/generate/ide/SchemaFieldTable';
import { FieldInspectorPanel } from '@/components/generate/ide/FieldInspectorPanel';
import { OutputPanel } from '@/components/generate/ide/OutputPanel';
import {
  useGenerateWorkspaceStore,
  selectBottomPanelOpen,
} from '@/stores/generate-workspace';

export default function GeneratePage() {
  const bottomPanelOpen = useGenerateWorkspaceStore(selectBottomPanelOpen);

  return (
    <ResizableWorkspaceLayout
      groupId="catalyst-generate"
      defaultSidebarSize={22}
      defaultMainSize={78}
      height="calc(100vh - 4rem)"
      renderSidebar={(api: SidebarLayoutApi) => <GenerateSidebar {...api} />}
    >
      <div className="relative flex flex-col h-full overflow-hidden">
        {/* Floating execution toolbar */}
        <GenerateToolbar />

        {/* Floating field inspector */}
        <FieldInspectorPanel />

        {/* Main content: schema table + output panel */}
        {bottomPanelOpen ? (
          <Group
            id="generate-vertical"
            orientation="vertical"
            className="flex-1 min-h-0"
          >
            <Panel
              id="generate-schema"
              defaultSize="65"
              minSize="15"
              className="flex flex-col min-h-0"
            >
              <div className="flex-1 min-h-0 overflow-auto">
                <SchemaFieldTable />
              </div>
            </Panel>
            <Separator
              className="shrink-0 bg-border transition-colors"
              style={{ height: 6, cursor: 'row-resize' }}
            />
            <Panel
              id="generate-output"
              defaultSize="35"
              minSize="10"
              className="flex flex-col min-h-0"
            >
              <OutputPanel />
            </Panel>
          </Group>
        ) : (
          <div className="flex-1 min-h-0 overflow-auto">
            <SchemaFieldTable />
          </div>
        )}
      </div>
    </ResizableWorkspaceLayout>
  );
}
