/** Three-card backend picker for experiment configuration. */

'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BACKENDS } from './constants';
import type { Backend } from './types';
import { cn } from '@/lib/utils';

interface BackendSelectorProps {
  value: Backend;
  onChange: (backend: Backend) => void;
}

export function BackendSelector({ value, onChange }: BackendSelectorProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {BACKENDS.map((b) => {
        const selected = value === b.id;
        return (
          <Card
            key={b.id}
            className={cn(
              'cursor-pointer transition-colors',
              selected
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted',
            )}
            onClick={() => onChange(b.id)}
          >
            <CardContent className="p-4 text-center space-y-1">
              <p className="font-semibold text-sm">{b.label}</p>
              <p className="text-xs text-muted-foreground">{b.subtitle}</p>
              <Badge variant={selected ? 'default' : 'secondary'} className="mt-1">
                {b.badge}
              </Badge>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
