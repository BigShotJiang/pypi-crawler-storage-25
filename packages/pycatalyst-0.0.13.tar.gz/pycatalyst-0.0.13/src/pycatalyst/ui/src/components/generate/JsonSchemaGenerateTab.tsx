'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { GenerateField } from '@/lib/types';
import { parseJsonSchemaToFields } from '@/components/generate/generate-utils';
import type { FieldRunContext } from '@/components/generate/GenerateRunBar';
import { FileJson, AlertCircle } from 'lucide-react';

type JsonSchemaGenerateTabProps = {
  onParsedFields: (fields: GenerateField[] | null) => void;
  onRunContext: (ctx: FieldRunContext | null) => void;
};

export function JsonSchemaGenerateTab({
  onParsedFields,
  onRunContext,
}: JsonSchemaGenerateTabProps) {
  const [schemaInput, setSchemaInput] = useState('');
  const [schemaName, setSchemaName] = useState('json_schema');
  const [parsedFields, setParsedFields] = useState<GenerateField[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!parsedFields?.length) {
      onRunContext(null);
      return;
    }
    onRunContext({
      schemaName: schemaName.trim() || 'json_schema',
      fields: parsedFields,
    });
  }, [parsedFields, schemaName, onRunContext]);

  const handleParse = () => {
    setError(null);
    setParsedFields(null);
    onParsedFields(null);
    onRunContext(null);
    let schema: Record<string, unknown>;
    try {
      schema = JSON.parse(schemaInput);
      if (!schema || typeof schema !== 'object') {
        setError('Invalid JSON. Root must be an object.');
        return;
      }
    } catch {
      setError('Invalid JSON. Please enter a valid JSON Schema.');
      return;
    }
    const fields = parseJsonSchemaToFields(schema);
    if (fields.length === 0) {
      setError('No "properties" found in the JSON Schema.');
      return;
    }
    setParsedFields(fields);
    onParsedFields(fields);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">From JSON Schema</CardTitle>
        <CardDescription>
          Paste a JSON Schema (with a &quot;properties&quot; object), parse it, then
          run batch or stream from the right panel
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>JSON Schema</Label>
          <Textarea
            value={schemaInput}
            onChange={(e) => setSchemaInput(e.target.value)}
            placeholder={
              '{\n  "type": "object",\n  "properties": {\n    "id": { "type": "integer" },\n    "name": { "type": "string" },\n    "active": { "type": "boolean" }\n  }\n}'
            }
            className="font-mono text-sm min-h-[200px]"
          />
        </div>
        <Button onClick={handleParse} disabled={!schemaInput.trim()}>
          <FileJson className="h-4 w-4 mr-2" />
          Parse schema
        </Button>

        {parsedFields && parsedFields.length > 0 && (
          <div className="border-t pt-4 space-y-2">
            <Label className="text-xs">Schema name (for runs)</Label>
            <Input
              value={schemaName}
              onChange={(e) => setSchemaName(e.target.value)}
              placeholder="json_schema"
            />
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
