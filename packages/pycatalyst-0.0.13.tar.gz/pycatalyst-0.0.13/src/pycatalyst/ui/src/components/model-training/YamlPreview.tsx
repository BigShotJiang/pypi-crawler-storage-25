/** Collapsible YAML preview with read-only and edit modes. */

'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, Copy, Download, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface YamlPreviewProps {
  yamlString: string;
  yamlOverride: string | null;
  onYamlOverride: (yaml: string | null) => void;
}

export function YamlPreview({ yamlString, yamlOverride, onYamlOverride }: YamlPreviewProps) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('preview');

  const displayYaml = yamlOverride ?? yamlString;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(displayYaml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([displayYaml], { type: 'application/x-yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'experiment.yaml';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <Card>
        <CardHeader className="pb-3">
          <CollapsibleTrigger className="flex items-center justify-between w-full">
            <CardTitle className="text-base">YAML Preview</CardTitle>
            <ChevronDown className={cn('h-4 w-4 transition-transform', open && 'rotate-180')} />
          </CollapsibleTrigger>
        </CardHeader>
        <CollapsibleContent>
          <CardContent className="space-y-3">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <div className="flex items-center justify-between">
                <TabsList>
                  <TabsTrigger value="preview">Preview</TabsTrigger>
                  <TabsTrigger value="edit">Edit</TabsTrigger>
                </TabsList>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? <Check className="mr-1 h-3 w-3" /> : <Copy className="mr-1 h-3 w-3" />}
                    {copied ? 'Copied' : 'Copy'}
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownload}>
                    <Download className="mr-1 h-3 w-3" />
                    Download
                  </Button>
                </div>
              </div>
              <TabsContent value="preview">
                <pre className="bg-muted p-4 rounded-md overflow-x-auto text-xs font-mono max-h-96">
                  {displayYaml}
                </pre>
              </TabsContent>
              <TabsContent value="edit">
                <textarea
                  className="w-full min-h-[240px] rounded-md border border-input bg-background px-3 py-2 text-sm font-mono ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  value={yamlOverride ?? yamlString}
                  onChange={(e) => onYamlOverride(e.target.value)}
                  placeholder="Edit YAML here..."
                />
                {yamlOverride !== null && (
                  <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                    Editing raw YAML — form fields are overridden. Clear to return to form mode.
                  </p>
                )}
                {yamlOverride !== null && (
                  <Button variant="ghost" size="sm" className="mt-1" onClick={() => onYamlOverride(null)}>
                    Clear override
                  </Button>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}
