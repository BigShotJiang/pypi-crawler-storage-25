'use client';

import { useCallback } from 'react';
import { Plus, Trash2, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  RecipeSinkFields,
  type RecipeSinkValue,
} from '@/components/recipes/RecipeSinkFields';
import {
  useGenerateWorkspaceStore,
  selectSinks,
  type SinkConfig,
} from '@/stores/generate-workspace';
import {
  useAppConfigStore,
  selectRecipeSinkMode,
} from '@/stores/app-config';

/** Status badge variant by sink status. */
function statusVariant(
  status: SinkConfig['status'],
): 'default' | 'secondary' | 'destructive' | 'outline' {
  switch (status) {
    case 'connected':
      return 'default';
    case 'testing':
      return 'secondary';
    case 'error':
      return 'destructive';
    default:
      return 'outline';
  }
}

/**
 * Multi-sink configuration panel for the Sinks sidebar tab.
 *
 * Lists configured sinks, allows adding/removing, and delegates
 * per-sink config editing to `RecipeSinkFields`.
 */
export function SinkConfigPanel() {
  const sinks = useGenerateWorkspaceStore(selectSinks);
  const addSink = useGenerateWorkspaceStore((s) => s.addSink);
  const updateSink = useGenerateWorkspaceStore((s) => s.updateSink);
  const removeSink = useGenerateWorkspaceStore((s) => s.removeSink);
  const recipeSinkMode = useAppConfigStore(selectRecipeSinkMode);

  const handleSinkChange = useCallback(
    (id: string, value: RecipeSinkValue) => {
      updateSink(id, { type: value.type, config: value.config });
    },
    [updateSink],
  );

  return (
    <div className="flex flex-col gap-3 px-3 py-3 overflow-y-auto">
      {/* Sink mode indicator */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Database className="h-3.5 w-3.5 shrink-0" />
        <span>
          Mode:{' '}
          <span className="font-medium text-foreground">
            {recipeSinkMode === 'full' ? 'Full (external sinks)' : 'Memory only'}
          </span>
        </span>
      </div>

      {recipeSinkMode === 'memory' && (
        <p className="text-xs text-muted-foreground rounded-md border border-dashed border-border px-2.5 py-2">
          External sinks require{' '}
          <code className="text-[10px]">
            PYCATALYST_RECIPE_SINK_MODE=full
          </code>
          . Output appears in Results only.
        </p>
      )}

      <Separator />

      {/* Sink list */}
      {sinks.map((sink, idx) => (
        <Collapsible key={sink.id} defaultOpen>
          <div className="rounded-md border border-border">
            <CollapsibleTrigger className="flex w-full items-center justify-between px-3 py-2 text-sm font-medium hover:bg-muted/50 transition-colors">
              <span className="flex items-center gap-2">
                <span>
                  Sink {idx + 1}
                  {sink.label ? ` — ${sink.label}` : ''}
                </span>
                <Badge variant={statusVariant(sink.status)} className="text-[10px] px-1.5 py-0">
                  {sink.status}
                </Badge>
              </span>
              {sinks.length > 1 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeSink(sink.id);
                  }}
                  aria-label={`Remove sink ${idx + 1}`}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </CollapsibleTrigger>

            <CollapsibleContent>
              <div className="px-2 pb-3">
                <RecipeSinkFields
                  value={{ type: sink.type, config: sink.config }}
                  onChange={(v) => handleSinkChange(sink.id, v)}
                  disabled={recipeSinkMode === 'memory' && sink.type !== 'memory'}
                />
                {sink.error && (
                  <p className="mt-1.5 text-xs text-destructive">
                    {sink.error}
                  </p>
                )}
              </div>
            </CollapsibleContent>
          </div>
        </Collapsible>
      ))}

      {/* Add sink button */}
      <Button
        variant="outline"
        size="sm"
        className="w-full gap-1.5"
        onClick={() => addSink('memory')}
      >
        <Plus className="h-3.5 w-3.5" />
        Add sink
      </Button>
    </div>
  );
}
