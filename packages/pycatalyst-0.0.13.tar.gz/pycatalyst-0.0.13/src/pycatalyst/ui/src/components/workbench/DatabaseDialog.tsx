'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X, Rocket } from 'lucide-react';
import type { CreateServiceOptions } from '@/lib/workbench';

interface DatabaseDialogProps {
  open: boolean;
  onClose: () => void;
  onLaunch: (opts: CreateServiceOptions) => void;
  loading?: boolean;
}

export function DatabaseDialog({ open, onClose, onLaunch, loading }: DatabaseDialogProps) {
  const [serviceType, setServiceType] = useState<'postgres' | 'mongodb'>('postgres');
  const [database, setDatabase] = useState('pycatalyst_db');
  const [username, setUsername] = useState('pycatalyst');
  const [password, setPassword] = useState('pycatalyst_dev');

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLaunch({
      service_type: serviceType,
      database: database.trim() || 'pycatalyst_db',
      username: username.trim() || 'pycatalyst',
      password: password.trim() || 'pycatalyst_dev',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-background border rounded-lg shadow-xl w-full max-w-md mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Launch Database</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded hover:bg-muted text-muted-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Database Engine</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={serviceType === 'postgres' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setServiceType('postgres')}
                className="flex-1"
              >
                PostgreSQL
              </Button>
              <Button
                type="button"
                variant={serviceType === 'mongodb' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setServiceType('mongodb')}
                className="flex-1"
              >
                MongoDB
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="db-name">Database Name</Label>
            <Input
              id="db-name"
              value={database}
              onChange={(e) => setDatabase(e.target.value)}
              placeholder="pycatalyst_db"
              className="font-mono text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="db-user">Username</Label>
              <Input
                id="db-user"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="pycatalyst"
                className="font-mono text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="db-pass">Password</Label>
              <Input
                id="db-pass"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="pycatalyst_dev"
                className="font-mono text-sm"
              />
            </div>
          </div>

          <p className="text-xs text-muted-foreground">
            A Docker container running{' '}
            <code className="bg-muted px-1 rounded">
              {serviceType === 'postgres' ? 'postgres:16-alpine' : 'mongo:7'}
            </code>{' '}
            will be launched. The connection string will be shown once healthy.
          </p>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" size="sm" disabled={loading}>
              <Rocket className="h-4 w-4 mr-1.5" />
              {loading ? 'Launching...' : 'Launch'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
