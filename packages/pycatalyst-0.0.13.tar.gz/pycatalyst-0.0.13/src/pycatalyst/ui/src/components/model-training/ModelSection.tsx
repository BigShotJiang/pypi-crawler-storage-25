/** Model architecture card grid with dynamic hyperparameter inputs. */

'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import type {
  Backend,
  SklearnModelState,
  SklearnArchitecture,
  PytorchModelState,
  PytorchArchitecture,
  HuggingfaceModelState,
} from './types';
import {
  SKLEARN_MODELS,
  PYTORCH_MODELS,
  SVM_KERNEL_OPTIONS,
  HF_ADAPTER_OPTIONS,
  HF_QUANTIZATION_OPTIONS,
} from './constants';
import { cn } from '@/lib/utils';
import { HelpTip } from './HelpTip';

interface SklearnModelProps {
  value: SklearnModelState;
  onChange: (partial: Partial<SklearnModelState>) => void;
}

function updateParam(current: Record<string, number | string>, key: string, val: number | string): Record<string, number | string> {
  return { ...current, [key]: val };
}

function SklearnModel({ value, onChange }: SklearnModelProps) {
  const setParam = (key: string, val: number | string) => {
    onChange({ params: updateParam(value.params, key, val) });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        {SKLEARN_MODELS.map((m) => (
          <button
            key={m.id}
            type="button"
            className={cn(
              'rounded-md border px-3 py-2 text-left transition-colors',
              value.architecture === m.id
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted',
            )}
            onClick={() => onChange({ architecture: m.id as SklearnArchitecture })}
          >
            <p className="text-sm font-medium">{m.name}</p>
            <p className="text-xs text-muted-foreground">{m.description}</p>
          </button>
        ))}
      </div>

      <Separator />

      <div className="space-y-1">
        <p className="text-sm font-medium text-muted-foreground">
          Hyperparameters — {SKLEARN_MODELS.find((m) => m.id === value.architecture)?.name}
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {(value.architecture === 'ridge' || value.architecture === 'lasso') && (
          <div className="space-y-2">
            <Label>
              alpha
              <HelpTip text="Regularization strength" />
            </Label>
            <Input type="number" step={0.1} min={0} value={value.params.alpha ?? 1.0} onChange={(e) => setParam('alpha', Number(e.target.value))} />
          </div>
        )}

        {value.architecture === 'knn' && (
          <div className="space-y-2">
            <Label>
              n_neighbors
              <HelpTip text="Number of nearest neighbors" />
            </Label>
            <Input type="number" min={1} value={value.params.n_neighbors ?? 5} onChange={(e) => setParam('n_neighbors', Number(e.target.value))} />
          </div>
        )}

        {(value.architecture === 'random_forest' || value.architecture === 'gradient_boosting' || value.architecture === 'adaboost') && (
          <div className="space-y-2">
            <Label>
              n_estimators
              <HelpTip text="Number of trees in the ensemble" />
            </Label>
            <Input type="number" min={1} value={value.params.n_estimators ?? 100} onChange={(e) => setParam('n_estimators', Number(e.target.value))} />
          </div>
        )}

        {(value.architecture === 'random_forest' || value.architecture === 'gradient_boosting' || value.architecture === 'decision_tree' || value.architecture === 'hist_gradient_boosting') && (
          <div className="space-y-2">
            <Label>
              max_depth
              <HelpTip text="Maximum tree depth" />
            </Label>
            <Input type="number" min={1} value={value.params.max_depth ?? 10} onChange={(e) => setParam('max_depth', Number(e.target.value))} />
          </div>
        )}

        {value.architecture === 'svm' && (
          <>
            <div className="space-y-2">
              <Label>
                C
                <HelpTip text="Regularization parameter" />
              </Label>
              <Input type="number" step={0.1} min={0.01} value={value.params.C ?? 1.0} onChange={(e) => setParam('C', Number(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label>kernel</Label>
              <Select value={String(value.params.kernel ?? 'rbf')} onValueChange={(v) => setParam('kernel', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SVM_KERNEL_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </>
        )}

        {value.architecture === 'linear_regression' && (
          <p className="text-xs text-muted-foreground col-span-full">No hyperparameters for Linear Regression</p>
        )}
      </div>
    </div>
  );
}

interface PytorchModelProps {
  value: PytorchModelState;
  onChange: (partial: Partial<PytorchModelState>) => void;
}

function PytorchModel({ value, onChange }: PytorchModelProps) {
  const setParam = (key: string, val: number | string) => {
    onChange({ params: updateParam(value.params, key, val) });
  };

  const info = PYTORCH_MODELS.find((m) => m.id === value.architecture);

  const handleArchChange = (id: PytorchArchitecture) => {
    const model = PYTORCH_MODELS.find((m) => m.id === id);
    onChange({ architecture: id, params: model ? { ...model.defaultParams } : {} });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        {PYTORCH_MODELS.map((m) => (
          <button
            key={m.id}
            type="button"
            className={cn(
              'rounded-md border px-3 py-2 text-left transition-colors',
              value.architecture === m.id
                ? 'border-primary bg-primary/5'
                : 'border-border hover:bg-muted',
            )}
            onClick={() => handleArchChange(m.id)}
          >
            <p className="text-sm font-medium">{m.name}</p>
            <p className="text-xs text-muted-foreground">{m.description}</p>
          </button>
        ))}
      </div>

      <Separator />

      <p className="text-sm font-medium text-muted-foreground">
        Hyperparameters — {info?.name}
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {(value.architecture === 'lstm' || value.architecture === 'gru' || value.architecture === 'transformer') && (
          <>
            <div className="space-y-2">
              <Label>
                hidden_size
                <HelpTip text="Size of the hidden state" />
              </Label>
              <Input type="number" min={1} value={value.params.hidden_size ?? 64} onChange={(e) => setParam('hidden_size', Number(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label>
                num_layers
                <HelpTip text="Number of stacked layers" />
              </Label>
              <Input type="number" min={1} value={value.params.num_layers ?? 2} onChange={(e) => setParam('num_layers', Number(e.target.value))} />
            </div>
          </>
        )}

        {value.architecture === 'transformer' && (
          <div className="space-y-2">
            <Label>
              attention_heads
              <HelpTip text="Number of attention heads" />
            </Label>
            <Input type="number" min={1} value={value.params.attention_heads ?? 4} onChange={(e) => setParam('attention_heads', Number(e.target.value))} />
          </div>
        )}

        {value.architecture === 'mlp' && (
          <div className="space-y-2 col-span-2">
            <Label>
              hidden_sizes
              <HelpTip text="Comma-separated list of hidden layer sizes" />
            </Label>
            <Input value={value.params.hidden_sizes ?? '64, 32'} onChange={(e) => setParam('hidden_sizes', e.target.value)} placeholder="64, 32" />
          </div>
        )}

        {(value.architecture === 'lstm' || value.architecture === 'gru' || value.architecture === 'transformer' || value.architecture === 'mlp') && (
          <div className="space-y-2">
            <Label>
              dropout
              <HelpTip text="Dropout rate (0-1)" />
            </Label>
            <div className="flex items-center gap-3">
              <Slider
                value={[Number(value.params.dropout ?? 0.1)]}
                onValueChange={([v]) => setParam('dropout', Math.round(v * 100) / 100)}
                min={0}
                max={1}
                step={0.05}
                className="flex-1"
              />
              <span className="text-sm text-muted-foreground w-10 text-right">{value.params.dropout ?? 0.1}</span>
            </div>
          </div>
        )}

        {value.architecture === 'tcn' && (
          <p className="text-xs text-muted-foreground col-span-full">TCN uses default parameters</p>
        )}
      </div>
    </div>
  );
}

interface HuggingfaceModelProps {
  value: HuggingfaceModelState;
  onChange: (partial: Partial<HuggingfaceModelState>) => void;
}

function HuggingfaceModel({ value, onChange }: HuggingfaceModelProps) {
  const showLoraParams = value.adapter !== 'none';

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>
            Base model
            <HelpTip text="HuggingFace model ID (e.g. meta-llama/Llama-2-7b-hf)" />
          </Label>
          <Input value={value.baseModel} onChange={(e) => onChange({ baseModel: e.target.value })} placeholder="meta-llama/Llama-2-7b-hf" />
        </div>
        <div className="space-y-2">
          <Label>
            Adapter
            <HelpTip text="Fine-tuning method" />
          </Label>
          <Select
            value={value.adapter}
            onValueChange={(v) => {
              const adapter = v as HuggingfaceModelState['adapter'];
              const updates: Partial<HuggingfaceModelState> = { adapter };
              if (adapter === 'qlora') updates.quantization = '4bit';
              else if (adapter === 'none') updates.quantization = 'none';
              onChange(updates);
            }}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {HF_ADAPTER_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Quantization
            <HelpTip text="Weight quantization for memory efficiency" />
          </Label>
          <Select value={value.quantization} onValueChange={(v) => onChange({ quantization: v as HuggingfaceModelState['quantization'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {HF_QUANTIZATION_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {showLoraParams && (
        <>
          <Separator />
          <p className="text-sm font-medium text-muted-foreground">LoRA Parameters</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>
                r (rank)
                <HelpTip text="LoRA rank dimension" />
              </Label>
              <Input type="number" min={1} value={value.loraR} onChange={(e) => onChange({ loraR: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>
                lora_alpha
                <HelpTip text="LoRA scaling factor" />
              </Label>
              <Input type="number" min={1} value={value.loraAlpha} onChange={(e) => onChange({ loraAlpha: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label>
                lora_dropout
                <HelpTip text="Dropout for LoRA layers" />
              </Label>
              <div className="flex items-center gap-3">
                <Slider
                  value={[value.loraDropout]}
                  onValueChange={([v]) => onChange({ loraDropout: Math.round(v * 100) / 100 })}
                  min={0}
                  max={0.5}
                  step={0.01}
                  className="flex-1"
                />
                <span className="text-sm text-muted-foreground w-10 text-right">{value.loraDropout}</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>
                target_modules
                <HelpTip text="Comma-separated list of modules to apply LoRA to" />
              </Label>
              <Input value={value.targetModules} onChange={(e) => onChange({ targetModules: e.target.value })} placeholder="q_proj, v_proj" />
            </div>
          </div>
        </>
      )}
    </div>
  );
}

interface ModelSectionProps {
  backend: Backend;
  sklearnModel: SklearnModelState;
  pytorchModel: PytorchModelState;
  hfModel: HuggingfaceModelState;
  onSklearnChange: (partial: Partial<SklearnModelState>) => void;
  onPytorchChange: (partial: Partial<PytorchModelState>) => void;
  onHfChange: (partial: Partial<HuggingfaceModelState>) => void;
}

export function ModelSection({
  backend,
  sklearnModel,
  pytorchModel,
  hfModel,
  onSklearnChange,
  onPytorchChange,
  onHfChange,
}: ModelSectionProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Model Architecture</CardTitle>
      </CardHeader>
      <CardContent>
        {backend === 'sklearn' && <SklearnModel value={sklearnModel} onChange={onSklearnChange} />}
        {backend === 'pytorch' && <PytorchModel value={pytorchModel} onChange={onPytorchChange} />}
        {backend === 'huggingface' && <HuggingfaceModel value={hfModel} onChange={onHfChange} />}
      </CardContent>
    </Card>
  );
}
