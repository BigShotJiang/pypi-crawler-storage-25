'use client';

import { useCallback, useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  useGenerateWorkspaceStore,
  selectFields,
} from '@/stores/generate-workspace';
import { FIELD_TYPES } from '@/components/generate/generate-utils';
import type { GenerateField } from '@/lib/types';

/* ── Extended type list (includes object, array) ───────── */

const ALL_TYPES = [...FIELD_TYPES, 'object', 'array'] as const;

const DISTRIBUTION_OPTIONS = [
  'uniform',
  'normal',
  'log-normal',
  'exponential',
] as const;

const FORMAT_OPTIONS = ['none', 'email', 'url', 'phone'] as const;

/* ── Section wrapper ───────────────────────────────────── */

function Section({
  title,
  defaultOpen = true,
  children,
}: {
  title: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="border-b border-border pb-3">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-1.5 py-1.5 text-xs
          font-semibold uppercase tracking-wider text-muted-foreground
          hover:text-foreground transition-colors"
      >
        {open ? (
          <ChevronDown className="h-3.5 w-3.5" />
        ) : (
          <ChevronRight className="h-3.5 w-3.5" />
        )}
        {title}
      </button>
      {open && <div className="mt-2 space-y-3">{children}</div>}
    </div>
  );
}

/* ── Labelled form row ─────────────────────────────────── */

function Row({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}

/* ── FieldInspectorForm ────────────────────────────────── */

type Props = { fieldIndex: number };

export function FieldInspectorForm({ fieldIndex }: Props) {
  const fields = useGenerateWorkspaceStore(selectFields);
  const updateField = useGenerateWorkspaceStore((s) => s.updateField);
  const field = fields[fieldIndex];

  /* ── Updater ─────────────────────────────────────────── */

  const patch = useCallback(
    (partial: Partial<GenerateField>) => {
      updateField(fieldIndex, { ...field, ...partial });
    },
    [updateField, fieldIndex, field],
  );

  const patchConstraint = useCallback(
    (key: string, value: unknown) => {
      const next = { ...(field.constraints ?? {}) };
      if (value === '' || value === undefined || value === null) {
        delete next[key];
      } else {
        next[key] = value;
      }
      patch({
        constraints: Object.keys(next).length > 0 ? next : undefined,
      });
    },
    [patch, field.constraints],
  );

  const c = field.constraints ?? {};
  const fieldType = field.type;

  /* ── Basic ───────────────────────────────────────────── */

  return (
    <div className="space-y-4">
      <Section title="Basic properties">
        <Row label="Name">
          <Input
            value={field.name}
            onChange={(e) => patch({ name: e.target.value })}
            className="h-8 text-sm"
          />
        </Row>

        <Row label="Type">
          <Select
            value={fieldType}
            onValueChange={(v) => patch({ type: v, constraints: undefined })}
          >
            <SelectTrigger className="h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ALL_TYPES.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Row>

        <Row label="Description">
          <Input
            value={(c.description as string) ?? ''}
            onChange={(e) => patchConstraint('description', e.target.value)}
            placeholder="Optional description"
            className="h-8 text-sm"
          />
        </Row>
      </Section>

      {/* ── Nullable ───────────────────────────────────── */}

      <Section title="Nullable">
        <div className="flex items-center justify-between">
          <Label className="text-xs">Nullable</Label>
          <Switch
            checked={field.nullable ?? false}
            onCheckedChange={(v) => patch({ nullable: v })}
          />
        </div>

        {field.nullable && (
          <Row label={`Nullable rate: ${Number(c.nullable_rate ?? 0)}%`}>
            <Slider
              min={0}
              max={100}
              step={1}
              value={[Number(c.nullable_rate ?? 0)]}
              onValueChange={([v]) => patchConstraint('nullable_rate', v)}
            />
          </Row>
        )}
      </Section>

      {/* ── Type-dependent constraints ─────────────────── */}

      <ConstraintSection
        fieldType={fieldType}
        constraints={c}
        onPatch={patchConstraint}
      />

      {/* ── Quality ────────────────────────────────────── */}

      <Section title="Quality" defaultOpen={false}>
        <Row label={`Invalid rate: ${Number(c.invalid_rate ?? 0)}%`}>
          <Slider
            min={0}
            max={100}
            step={1}
            value={[Number(c.invalid_rate ?? 0)]}
            onValueChange={([v]) => patchConstraint('invalid_rate', v)}
          />
        </Row>
        <Row label={`Out of range rate: ${Number(c.out_of_range_rate ?? 0)}%`}>
          <Slider
            min={0}
            max={100}
            step={1}
            value={[Number(c.out_of_range_rate ?? 0)]}
            onValueChange={([v]) => patchConstraint('out_of_range_rate', v)}
          />
        </Row>
        <Row label={`Truncate rate: ${Number(c.truncate_rate ?? 0)}%`}>
          <Slider
            min={0}
            max={100}
            step={1}
            value={[Number(c.truncate_rate ?? 0)]}
            onValueChange={([v]) => patchConstraint('truncate_rate', v)}
          />
        </Row>
      </Section>
    </div>
  );
}

/* ── ConstraintSection (type-dependent) ────────────────── */

function ConstraintSection({
  fieldType,
  constraints,
  onPatch,
}: {
  fieldType: string;
  constraints: Record<string, unknown>;
  onPatch: (key: string, value: unknown) => void;
}) {
  const c = constraints;

  if (fieldType === 'int' || fieldType === 'float') {
    return (
      <Section title="Constraints">
        <Row label="Min">
          <Input
            type="number"
            className="h-8 text-sm"
            value={(c.min as number) ?? ''}
            onChange={(e) =>
              onPatch('min', e.target.value ? Number(e.target.value) : '')
            }
          />
        </Row>
        <Row label="Max">
          <Input
            type="number"
            className="h-8 text-sm"
            value={(c.max as number) ?? ''}
            onChange={(e) =>
              onPatch('max', e.target.value ? Number(e.target.value) : '')
            }
          />
        </Row>
        <Row label="Distribution">
          <Select
            value={(c.distribution as string) ?? 'uniform'}
            onValueChange={(v) => onPatch('distribution', v)}
          >
            <SelectTrigger className="h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {DISTRIBUTION_OPTIONS.map((d) => (
                <SelectItem key={d} value={d}>
                  {d}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Row>
        {(c.distribution === 'normal' || c.distribution === 'log-normal') && (
          <>
            <Row label="Mean">
              <Input
                type="number"
                className="h-8 text-sm"
                value={(c.mean as number) ?? ''}
                onChange={(e) =>
                  onPatch(
                    'mean',
                    e.target.value ? Number(e.target.value) : '',
                  )
                }
              />
            </Row>
            <Row label="Std">
              <Input
                type="number"
                className="h-8 text-sm"
                value={(c.std as number) ?? ''}
                onChange={(e) =>
                  onPatch(
                    'std',
                    e.target.value ? Number(e.target.value) : '',
                  )
                }
              />
            </Row>
          </>
        )}
        {fieldType === 'float' && (
          <Row label="Precision">
            <Input
              type="number"
              min={0}
              max={15}
              className="h-8 text-sm"
              value={(c.precision as number) ?? ''}
              onChange={(e) =>
                onPatch(
                  'precision',
                  e.target.value ? Number(e.target.value) : '',
                )
              }
            />
          </Row>
        )}
        <div className="flex items-center justify-between">
          <Label className="text-xs">Unique</Label>
          <Switch
            checked={Boolean(c.unique)}
            onCheckedChange={(v) => onPatch('unique', v || undefined)}
          />
        </div>
        <Row label="Multiple of">
          <Input
            type="number"
            className="h-8 text-sm"
            value={(c.multiple_of as number) ?? ''}
            onChange={(e) =>
              onPatch(
                'multiple_of',
                e.target.value ? Number(e.target.value) : '',
              )
            }
          />
        </Row>
      </Section>
    );
  }

  if (fieldType === 'string') {
    return (
      <Section title="Constraints">
        <Row label="Min length">
          <Input
            type="number"
            min={0}
            className="h-8 text-sm"
            value={(c.min_length as number) ?? ''}
            onChange={(e) =>
              onPatch(
                'min_length',
                e.target.value ? Number(e.target.value) : '',
              )
            }
          />
        </Row>
        <Row label="Max length">
          <Input
            type="number"
            min={0}
            className="h-8 text-sm"
            value={(c.max_length as number) ?? ''}
            onChange={(e) =>
              onPatch(
                'max_length',
                e.target.value ? Number(e.target.value) : '',
              )
            }
          />
        </Row>
        <Row label="Pattern (regex)">
          <Input
            className="h-8 text-sm font-mono"
            value={(c.pattern as string) ?? ''}
            onChange={(e) => onPatch('pattern', e.target.value)}
            placeholder="e.g. ^[A-Z]{3}$"
          />
        </Row>
        <Row label="Format">
          <Select
            value={(c.format as string) ?? 'none'}
            onValueChange={(v) =>
              onPatch('format', v === 'none' ? undefined : v)
            }
          >
            <SelectTrigger className="h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {FORMAT_OPTIONS.map((f) => (
                <SelectItem key={f} value={f}>
                  {f}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Row>
        <div className="flex items-center justify-between">
          <Label className="text-xs">Unique</Label>
          <Switch
            checked={Boolean(c.unique)}
            onCheckedChange={(v) => onPatch('unique', v || undefined)}
          />
        </div>
      </Section>
    );
  }

  if (fieldType === 'enum') {
    return (
      <Section title="Constraints">
        <Row label="Choices (comma-separated)">
          <Input
            className="h-8 text-sm"
            value={
              Array.isArray(c.choices) ? (c.choices as string[]).join(', ') : ''
            }
            onChange={(e) => {
              const raw = e.target.value;
              const arr = raw
                .split(',')
                .map((s) => s.trim())
                .filter(Boolean);
              onPatch('choices', arr.length > 0 ? arr : undefined);
            }}
            placeholder="e.g. buy, sell, hold"
          />
        </Row>
      </Section>
    );
  }

  if (fieldType === 'date' || fieldType === 'datetime') {
    return (
      <Section title="Constraints">
        <Row label="Min">
          <Input
            className="h-8 text-sm"
            value={(c.min as string) ?? ''}
            onChange={(e) => onPatch('min', e.target.value)}
            placeholder={
              fieldType === 'date' ? '2020-01-01' : '2020-01-01T00:00:00'
            }
          />
        </Row>
        <Row label="Max">
          <Input
            className="h-8 text-sm"
            value={(c.max as string) ?? ''}
            onChange={(e) => onPatch('max', e.target.value)}
            placeholder={
              fieldType === 'date' ? '2025-12-31' : '2025-12-31T23:59:59'
            }
          />
        </Row>
      </Section>
    );
  }

  if (fieldType === 'array') {
    return (
      <Section title="Constraints">
        <Row label="Min items">
          <Input
            type="number"
            min={0}
            className="h-8 text-sm"
            value={(c.min_items as number) ?? ''}
            onChange={(e) =>
              onPatch(
                'min_items',
                e.target.value ? Number(e.target.value) : '',
              )
            }
          />
        </Row>
        <Row label="Max items">
          <Input
            type="number"
            min={0}
            className="h-8 text-sm"
            value={(c.max_items as number) ?? ''}
            onChange={(e) =>
              onPatch(
                'max_items',
                e.target.value ? Number(e.target.value) : '',
              )
            }
          />
        </Row>
      </Section>
    );
  }

  if (fieldType === 'object') {
    return (
      <Section title="Constraints">
        <p className="text-xs text-muted-foreground">
          Object children can be edited by expanding this field in the schema
          tree.
        </p>
      </Section>
    );
  }

  // bool, uuid, or unknown type: no additional constraints
  return null;
}
