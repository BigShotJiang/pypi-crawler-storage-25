'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { X, Download, Loader2 } from 'lucide-react';
import { installPackages, type PackageInfo } from '@/lib/workbench';

interface InstallPackageDialogProps {
  open: boolean;
  envId: string;
  onClose: () => void;
  onInstalled: (packages: PackageInfo[]) => void;
}

export function InstallPackageDialog({
  open,
  envId,
  onClose,
  onInstalled,
}: InstallPackageDialogProps) {
  const [packageSpec, setPackageSpec] = useState('');
  const [editable, setEditable] = useState(false);
  const [upgrade, setUpgrade] = useState(false);
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');

  if (!open) return null;

  const looksLikeLocalPath =
    packageSpec.startsWith('/') ||
    packageSpec.startsWith('./') ||
    packageSpec.startsWith('~');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const specs = packageSpec
      .split(/[\s,]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (specs.length === 0) return;

    setLoading(true);
    setOutput('');
    setError('');

    try {
      const result = await installPackages(envId, specs, {
        editable: editable || looksLikeLocalPath,
        upgrade,
      });
      setOutput(result.output);
      if (result.success) {
        onInstalled(result.packages);
      } else {
        setError('Installation failed — see output above.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setPackageSpec('');
    setEditable(false);
    setUpgrade(false);
    setOutput('');
    setError('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={handleClose} />
      <div className="relative bg-background border rounded-lg shadow-xl w-full max-w-lg mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Install Packages</h2>
          <button
            type="button"
            onClick={handleClose}
            className="p-1 rounded hover:bg-muted text-muted-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="pkg-spec">Package spec(s)</Label>
            <Input
              id="pkg-spec"
              value={packageSpec}
              onChange={(e) => setPackageSpec(e.target.value)}
              placeholder="e.g. httpx, requests>=2.0, /path/to/pkg"
              className="font-mono text-sm"
              autoFocus
            />
            <p className="text-xs text-muted-foreground">
              Separate multiple packages with spaces or commas.
            </p>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Switch
                id="editable"
                checked={editable || looksLikeLocalPath}
                onCheckedChange={setEditable}
              />
              <Label htmlFor="editable" className="text-sm">
                Editable (-e)
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch id="upgrade" checked={upgrade} onCheckedChange={setUpgrade} />
              <Label htmlFor="upgrade" className="text-sm">
                Upgrade (--upgrade)
              </Label>
            </div>
          </div>

          {output && (
            <pre className="bg-muted rounded p-3 text-xs font-mono max-h-48 overflow-auto whitespace-pre-wrap">
              {output}
            </pre>
          )}

          {error && (
            <p className="text-sm text-destructive">{error}</p>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={handleClose}>
              Close
            </Button>
            <Button type="submit" size="sm" disabled={loading || !packageSpec.trim()}>
              {loading ? (
                <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
              ) : (
                <Download className="h-4 w-4 mr-1.5" />
              )}
              {loading ? 'Installing...' : 'Install'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
