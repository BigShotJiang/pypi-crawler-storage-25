'use client';

import { useState, useEffect, useCallback } from 'react';
import { BookOpen } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { api } from '@/lib/api';
import { BUILT_IN_TEMPLATES } from '@/components/generate/generate-utils';
import { recipeObjectToDraft } from '@/lib/recipe-draft';
import { useGenerateWorkspaceStore } from '@/stores/generate-workspace';
import type { RecipeTemplateItem } from '@/lib/types';

/**
 * Template browser for the Templates sidebar tab.
 *
 * Shows built-in templates and any server-side templates. Clicking a
 * template parses its YAML, extracts fields, and writes them to the
 * workspace store.
 */
export function RecipeTemplateBrowser() {
  const setFields = useGenerateWorkspaceStore((s) => s.setFields);
  const setSchemaName = useGenerateWorkspaceStore((s) => s.setSchemaName);
  const setSchemaSource = useGenerateWorkspaceStore((s) => s.setSchemaSource);

  const [serverTemplates, setServerTemplates] = useState<RecipeTemplateItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function fetchTemplates() {
      try {
        const res = await api.recipes.list();
        if (!cancelled) {
          setServerTemplates(res.recipes);
        }
      } catch {
        if (!cancelled) {
          setError('Could not load server templates');
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }
    void fetchTemplates();
    return () => {
      cancelled = true;
    };
  }, []);

  const loadBuiltIn = useCallback(
    async (yaml: string) => {
      try {
        const jsYaml = await import('js-yaml');
        const loaded = jsYaml.load(yaml);
        if (!loaded || typeof loaded !== 'object' || Array.isArray(loaded)) return;
        const result = recipeObjectToDraft(loaded as Record<string, unknown>);
        if (!result.ok) return;
        setFields(result.draft.fields);
        setSchemaName(result.draft.name);
        setSchemaSource('build');
      } catch {
        /* ignore parse errors on built-in templates */
      }
    },
    [setFields, setSchemaName, setSchemaSource],
  );

  const loadServerTemplate = useCallback(
    async (name: string) => {
      try {
        const res = await api.recipes.getTemplate(name);
        const jsYaml = await import('js-yaml');
        const loaded = jsYaml.load(res.yaml);
        if (!loaded || typeof loaded !== 'object' || Array.isArray(loaded)) return;
        const result = recipeObjectToDraft(loaded as Record<string, unknown>);
        if (!result.ok) return;
        setFields(result.draft.fields);
        setSchemaName(result.draft.name);
        setSchemaSource('build');
      } catch {
        /* template fetch or parse failed */
      }
    },
    [setFields, setSchemaName, setSchemaSource],
  );

  return (
    <div className="flex flex-col gap-3 px-3 py-3 overflow-y-auto">
      {/* Built-in templates */}
      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
        Built-in
      </h3>
      <div className="flex flex-col gap-2">
        {Object.entries(BUILT_IN_TEMPLATES).map(([name, yaml]) => (
          <TemplateCard
            key={name}
            name={name}
            description="Built-in template"
            onClick={() => void loadBuiltIn(yaml)}
          />
        ))}
      </div>

      <Separator />

      {/* Server templates */}
      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
        Server recipes
      </h3>
      {loading && (
        <div className="flex flex-col gap-2">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </div>
      )}
      {!loading && error && (
        <p className="text-xs text-muted-foreground">{error}</p>
      )}
      {!loading && !error && serverTemplates.length === 0 && (
        <p className="text-xs text-muted-foreground">
          No server-side templates found.
        </p>
      )}
      {!loading &&
        !error &&
        serverTemplates.map((t) => (
          <TemplateCard
            key={t.name}
            name={t.name}
            description={t.description}
            onClick={() => void loadServerTemplate(t.name)}
          />
        ))}
    </div>
  );
}

/** Clickable template card. */
function TemplateCard({
  name,
  description,
  onClick,
}: {
  name: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-start gap-2.5 rounded-md border border-border p-2.5 text-left transition-colors hover:bg-muted/50 hover:border-primary/30"
    >
      <BookOpen className="h-4 w-4 mt-0.5 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-sm font-medium leading-tight truncate">{name}</p>
        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
          {description}
        </p>
      </div>
    </button>
  );
}
