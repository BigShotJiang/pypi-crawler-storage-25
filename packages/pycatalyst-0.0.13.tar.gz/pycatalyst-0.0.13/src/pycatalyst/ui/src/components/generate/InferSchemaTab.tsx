'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { api, ApiError } from '@/lib/api';
import type { InferField } from '@/lib/types';
import {
  inferredFieldsToGenerateFields,
  TYPES_REQUIRING_CHILDREN,
} from '@/components/generate/generate-utils';
import type { FieldRunContext } from '@/components/generate/GenerateRunBar';
import { Search, AlertCircle } from 'lucide-react';

type InferSchemaTabProps = {
  onInferred: (fields: InferField[] | null) => void;
  onRunContext: (ctx: FieldRunContext | null) => void;
};

export function InferSchemaTab({ onInferred, onRunContext }: InferSchemaTabProps) {
  const [sampleInput, setSampleInput] = useState('');
  const [schemaName, setSchemaName] = useState('');
  const [inferredFields, setInferredFields] = useState<InferField[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!inferredFields?.length) {
      onRunContext(null);
      return;
    }
    const { fields } = inferredFieldsToGenerateFields(inferredFields);
    if (!fields.length) onRunContext(null);
    else
      onRunContext({
        schemaName: schemaName.trim() || 'inferred_schema',
        fields,
      });
  }, [inferredFields, schemaName, onRunContext]);

  const handleInfer = async () => {
    setError(null);
    setInferredFields(null);
    onInferred(null);
    onRunContext(null);
    let records: Record<string, unknown>[];
    try {
      records = JSON.parse(sampleInput);
      if (!Array.isArray(records)) {
        setError('Input must be a JSON array of records');
        return;
      }
    } catch {
      setError('Invalid JSON. Please enter a valid JSON array.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.infer.run({
        records,
        name: schemaName || undefined,
      });
      setInferredFields(res.fields);
      if (!schemaName) setSchemaName(res.name);
      onInferred(res.fields);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Inference failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Infer from data</CardTitle>
        <CardDescription>
          Paste sample records as a JSON array to infer the schema, then use Run in
          the panel on the right
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Schema name (optional)</Label>
          <Input
            value={schemaName}
            onChange={(e) => setSchemaName(e.target.value)}
            placeholder="inferred_schema"
          />
        </div>
        <div className="space-y-2">
          <Label>Sample data (JSON array)</Label>
          <Textarea
            value={sampleInput}
            onChange={(e) => setSampleInput(e.target.value)}
            placeholder={
              '[\n  { "id": 1, "name": "Alice", "score": 95.5 },\n  { "id": 2, "name": "Bob", "score": 87.3 }\n]'
            }
            className="font-mono text-sm min-h-[200px]"
          />
        </div>
        <Button
          onClick={handleInfer}
          disabled={loading || !sampleInput.trim()}
        >
          <Search className="h-4 w-4 mr-2" />
          {loading ? 'Inferring...' : 'Infer schema'}
        </Button>

        {inferredFields && inferredFields.length > 0 && (
          <div className="border-t pt-4 space-y-2">
            {inferredFields.some((f) =>
              TYPES_REQUIRING_CHILDREN.includes(f.type.toLowerCase()),
            ) && (
              <p className="text-xs text-muted-foreground">
                Object/array fields are omitted when generating (infer does not return
                nested structure).
              </p>
            )}
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
