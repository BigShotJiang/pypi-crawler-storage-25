'use client';

import { useEffect, useRef, useCallback, useState } from 'react';
import { Terminal } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { WebLinksAddon } from '@xterm/addon-web-links';
import '@xterm/xterm/css/xterm.css';
import { X, Square, WifiOff } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getTerminalWsUrl } from '@/lib/workbench';
import { buildTerminalTheme } from '@/lib/terminal-theme';
import { useAppConfigStore, selectTheme } from '@/stores/app-config';

export type PanelType = 'venv' | 'container';

interface TerminalPanelProps {
  sessionId: string;
  command: string;
  envId: string;
  panelType: PanelType;
  onClose: () => void;
  onStop?: () => void;
  isActive: boolean;
  onFocus: () => void;
}

/** Maximum number of reconnection attempts before giving up. */
const MAX_RECONNECT_ATTEMPTS = 5;

/** Base delay (ms) for exponential backoff: 1s, 2s, 4s, 8s, 16s. */
const RECONNECT_BASE_DELAY_MS = 1000;

export function TerminalPanel({
  sessionId,
  command,
  envId,
  panelType,
  onClose,
  onStop,
  isActive,
  onFocus,
}: TerminalPanelProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const termRef = useRef<Terminal | null>(null);
  const fitRef = useRef<FitAddon | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const unmountedRef = useRef(false);

  const [connectionState, setConnectionState] = useState<
    'connecting' | 'connected' | 'reconnecting' | 'disconnected'
  >('connecting');

  const appTheme = useAppConfigStore(selectTheme);

  const scheduleReconnect = useCallback(() => {
    if (unmountedRef.current) return;
    if (reconnectAttemptsRef.current >= MAX_RECONNECT_ATTEMPTS) {
      setConnectionState('disconnected');
      const term = termRef.current;
      if (term) {
        term.write('\r\n\x1b[90m[session ended — reconnection failed]\x1b[0m\r\n');
      }
      return;
    }

    setConnectionState('reconnecting');
    const delay =
      RECONNECT_BASE_DELAY_MS * Math.pow(2, reconnectAttemptsRef.current);
    reconnectAttemptsRef.current += 1;

    const term = termRef.current;
    if (term) {
      term.write(
        `\r\n\x1b[93m[reconnecting in ${Math.round(delay / 1000)}s...]\x1b[0m\r\n`,
      );
    }

    reconnectTimerRef.current = setTimeout(() => {
      if (!unmountedRef.current) {
        connectWs();
      }
    }, delay);
  }, []);

  const connectWs = useCallback(() => {
    if (unmountedRef.current) return;
    if (wsRef.current && wsRef.current.readyState <= WebSocket.OPEN) {
      return;
    }

    setConnectionState('connecting');
    const wsUrl = getTerminalWsUrl(sessionId, { command, envId });
    const ws = new WebSocket(wsUrl);
    ws.binaryType = 'arraybuffer';
    wsRef.current = ws;

    ws.onopen = () => {
      if (unmountedRef.current) return;
      reconnectAttemptsRef.current = 0;
      setConnectionState('connected');
      const fit = fitRef.current;
      if (fit) {
        try {
          fit.fit();
        } catch {
          // fit may fail if container is hidden
        }
      }
    };

    ws.onmessage = (event) => {
      if (typeof event.data === 'string') {
        try {
          const msg = JSON.parse(event.data) as { type?: string };
          if (msg?.type === 'ping') {
            ws.send(JSON.stringify({ type: 'pong' }));
            return;
          }
        } catch {
          // not JSON — treat as terminal output
        }
      }
      const term = termRef.current;
      if (!term) return;
      if (event.data instanceof ArrayBuffer) {
        term.write(new Uint8Array(event.data));
      } else {
        term.write(event.data);
      }
    };

    ws.onclose = (event) => {
      if (unmountedRef.current) return;

      // Code 1008 = Policy Violation (server rejected: auth failure, session
      // not found, command not allowed).  No point reconnecting.
      if (event.code === 1008) {
        setConnectionState('disconnected');
        const term = termRef.current;
        if (term) {
          const reason = event.reason || 'connection refused';
          term.write(`\r\n\x1b[90m[${reason}]\x1b[0m\r\n`);
        }
        return;
      }

      // Normal close (e.g., server shutdown, process exited) with code 1000
      // or empty code — the session is truly gone.
      if (event.code === 1000 || event.code === 1001) {
        setConnectionState('disconnected');
        const term = termRef.current;
        if (term) {
          const reason = event.reason || 'Session ended';
          term.write(`\r\n\x1b[90m[${reason}]\x1b[0m\r\n`);
        }
        return;
      }

      // Unexpected close (network error, server crash) — try to reconnect.
      scheduleReconnect();
    };

    ws.onerror = () => {
      // onclose fires after onerror, so reconnect logic is handled there.
    };
  }, [sessionId, command, envId, scheduleReconnect]);

  useEffect(() => {
    unmountedRef.current = false;

    if (!containerRef.current) return;

    const term = new Terminal({
      cursorBlink: true,
      fontSize: 14,
      fontFamily:
        "'JetBrains Mono', 'Fira Code', 'Cascadia Code', Menlo, Monaco, 'Courier New', monospace",
      theme: buildTerminalTheme(),
      scrollback: 5000,
      convertEol: true,
      allowProposedApi: true,
    });

    const fitAddon = new FitAddon();
    const webLinksAddon = new WebLinksAddon();

    term.loadAddon(fitAddon);
    term.loadAddon(webLinksAddon);
    term.open(containerRef.current);

    termRef.current = term;
    fitRef.current = fitAddon;

    try {
      fitAddon.fit();
    } catch {
      // fit may fail if container not yet laid out
    }

    term.onData((data) => {
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });

    term.onBinary((data) => {
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        const buffer = new Uint8Array(data.length);
        for (let i = 0; i < data.length; i++) {
          buffer[i] = data.charCodeAt(i) & 0xff;
        }
        ws.send(buffer);
      }
    });

    term.onResize(({ cols, rows }) => {
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'resize', cols, rows }));
      }
    });

    connectWs();

    const resizeObserver = new ResizeObserver(() => {
      try {
        fitAddon.fit();
      } catch {
        // ignore
      }
    });
    resizeObserver.observe(containerRef.current);

    return () => {
      unmountedRef.current = true;
      resizeObserver.disconnect();
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      const ws = wsRef.current;
      if (ws) {
        ws.onclose = null;
        ws.onerror = null;
        ws.close();
        wsRef.current = null;
      }
      term.dispose();
      termRef.current = null;
      fitRef.current = null;
    };
  }, [connectWs]);

  // Re-apply terminal theme when the app theme changes.
  // Uses a small delay so the CSS variables have time to update in the DOM.
  useEffect(() => {
    const term = termRef.current;
    if (!term) return;
    const timer = setTimeout(() => {
      term.options.theme = buildTerminalTheme();
    }, 50);
    return () => clearTimeout(timer);
  }, [appTheme]);

  const envLabel = envId.slice(0, 8);
  const typeLabel = panelType === 'container' ? 'container' : 'venv';

  return (
    <div
      className={cn(
        'flex flex-col h-full min-h-0 border rounded-md overflow-hidden',
        isActive ? 'border-primary/50' : 'border-border',
      )}
      onClick={onFocus}
    >
      <div className="flex items-center justify-between px-3 py-1.5 bg-muted/50 border-b border-border shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-xs font-medium text-muted-foreground truncate">
            {command}
          </span>
          <span
            className={cn(
              'text-[10px] px-1.5 py-0.5 rounded-full font-medium shrink-0',
              panelType === 'container'
                ? 'bg-blue-500/15 text-blue-400'
                : 'bg-green-500/15 text-green-400',
            )}
          >
            {typeLabel}: {envLabel}
          </span>
          {connectionState === 'reconnecting' && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-yellow-500/15 text-yellow-400 shrink-0 animate-pulse">
              reconnecting
            </span>
          )}
          {connectionState === 'disconnected' && (
            <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full font-medium bg-red-500/15 text-red-400 shrink-0">
              <WifiOff className="h-2.5 w-2.5" />
              disconnected
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {panelType === 'container' && onStop && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onStop();
              }}
              className="p-0.5 rounded hover:bg-yellow-500/20 hover:text-yellow-400 text-muted-foreground transition-colors"
              title="Stop container"
            >
              <Square className="h-3.5 w-3.5" />
            </button>
          )}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="p-0.5 rounded hover:bg-destructive/20 hover:text-destructive text-muted-foreground transition-colors"
            title="Close terminal"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
      <div ref={containerRef} className="flex-1 min-h-0" />
    </div>
  );
}
