/** Backend options, model metadata, and default values. */

import type {
  Backend,
  ExperimentState,
  SklearnArchitecture,
  SklearnDataState,
  SklearnModelState,
  SklearnTrainingState,
  SklearnEvaluationState,
  PytorchArchitecture,
  PytorchDataState,
  PytorchModelState,
  PytorchTrainingState,
  PytorchEvaluationState,
  HuggingfaceDataState,
  HuggingfaceModelState,
  HuggingfaceTrainingState,
  HuggingfaceEvaluationState,
} from './types';

// ── Backend metadata ─────────────────────────────────────────────

export interface BackendInfo {
  id: Backend;
  label: string;
  subtitle: string;
  badge: string;
}

export const BACKENDS: BackendInfo[] = [
  { id: 'sklearn', label: 'Sklearn', subtitle: 'Classical ML', badge: '10 models' },
  { id: 'pytorch', label: 'PyTorch', subtitle: 'Deep Learning', badge: '5 architectures' },
  { id: 'huggingface', label: 'Hugging Face', subtitle: 'LLM Fine-tuning', badge: 'Any HF model' },
];

// ── Sklearn model metadata ──────────────────────────────────────

export interface ModelInfo {
  id: SklearnArchitecture;
  name: string;
  description: string;
  defaultParams: Record<string, number | string>;
}

export const SKLEARN_MODELS: ModelInfo[] = [
  { id: 'linear_regression', name: 'Linear Regression', description: 'Ordinary least squares', defaultParams: {} },
  { id: 'ridge', name: 'Ridge', description: 'L2 regularized linear model', defaultParams: { alpha: 1.0 } },
  { id: 'lasso', name: 'Lasso', description: 'L1 regularized linear model', defaultParams: { alpha: 1.0 } },
  { id: 'decision_tree', name: 'Decision Tree', description: 'Non-parametric tree model', defaultParams: { max_depth: 10 } },
  { id: 'random_forest', name: 'Random Forest', description: 'Ensemble of decision trees', defaultParams: { n_estimators: 100, max_depth: 10 } },
  { id: 'gradient_boosting', name: 'Gradient Boosting', description: 'Sequential boosted trees', defaultParams: { n_estimators: 100, max_depth: 3 } },
  { id: 'adaboost', name: 'AdaBoost', description: 'Adaptive boosting ensemble', defaultParams: { n_estimators: 50 } },
  { id: 'svm', name: 'SVM', description: 'Support vector machine', defaultParams: { C: 1.0, kernel: 'rbf' } },
  { id: 'knn', name: 'KNN', description: 'K-nearest neighbors', defaultParams: { n_neighbors: 5 } },
  { id: 'hist_gradient_boosting', name: 'Hist GBM', description: 'Histogram-based gradient boosting', defaultParams: { max_depth: 10 } },
];

// ── PyTorch architecture metadata ────────────────────────────────

export interface PytorchModelInfo {
  id: PytorchArchitecture;
  name: string;
  description: string;
  defaultParams: Record<string, number | string>;
}

export const PYTORCH_MODELS: PytorchModelInfo[] = [
  { id: 'lstm', name: 'LSTM', description: 'Long short-term memory', defaultParams: { hidden_size: 64, num_layers: 2, dropout: 0.1 } },
  { id: 'gru', name: 'GRU', description: 'Gated recurrent unit', defaultParams: { hidden_size: 64, num_layers: 2, dropout: 0.1 } },
  { id: 'tcn', name: 'TCN', description: 'Temporal convolutional network', defaultParams: {} },
  { id: 'transformer', name: 'Transformer', description: 'Multi-head self-attention', defaultParams: { hidden_size: 64, num_layers: 2, attention_heads: 4, dropout: 0.1 } },
  { id: 'mlp', name: 'MLP', description: 'Multi-layer perceptron', defaultParams: { hidden_sizes: '64, 32', dropout: 0.1 } },
];

// ── Select options ───────────────────────────────────────────────

export const SKLEARN_SPLIT_OPTIONS = [
  { value: 'random', label: 'Random' },
  { value: 'temporal', label: 'Temporal' },
] as const;

export const PYTORCH_SPLIT_OPTIONS = [
  { value: 'temporal', label: 'Temporal' },
  { value: 'holdout', label: 'Holdout' },
] as const;

export const SCALER_OPTIONS = [
  { value: 'standard', label: 'Standard' },
  { value: 'minmax', label: 'Min-Max' },
  { value: 'robust', label: 'Robust' },
  { value: 'none', label: 'None' },
] as const;

export const MISSING_OPTIONS = [
  { value: 'drop', label: 'Drop rows' },
  { value: 'mean', label: 'Mean imputation' },
  { value: 'median', label: 'Median imputation' },
  { value: 'mode', label: 'Mode imputation' },
] as const;

export const HF_FORMAT_OPTIONS = [
  { value: 'instruction', label: 'Instruction' },
  { value: 'chat', label: 'Chat' },
  { value: 'completion', label: 'Completion' },
] as const;

export const HF_ADAPTER_OPTIONS = [
  { value: 'lora', label: 'LoRA' },
  { value: 'qlora', label: 'QLoRA' },
  { value: 'none', label: 'None (full)' },
] as const;

export const HF_QUANTIZATION_OPTIONS = [
  { value: '4bit', label: '4-bit' },
  { value: '8bit', label: '8-bit' },
  { value: 'none', label: 'None' },
] as const;

export const OPTIMIZER_OPTIONS = [
  { value: 'adam', label: 'Adam' },
  { value: 'adamw', label: 'AdamW' },
  { value: 'sgd', label: 'SGD' },
] as const;

export const SCHEDULER_OPTIONS = [
  { value: 'none', label: 'None' },
  { value: 'cosine', label: 'Cosine' },
  { value: 'step', label: 'Step' },
  { value: 'plateau', label: 'Plateau' },
] as const;

export const EARLY_STOP_MODE_OPTIONS = [
  { value: 'min', label: 'Min' },
  { value: 'max', label: 'Max' },
] as const;

export const MIXED_PRECISION_OPTIONS = [
  { value: 'bf16', label: 'BF16' },
  { value: 'fp16', label: 'FP16' },
] as const;

export const SVM_KERNEL_OPTIONS = [
  { value: 'rbf', label: 'RBF' },
  { value: 'linear', label: 'Linear' },
  { value: 'poly', label: 'Polynomial' },
  { value: 'sigmoid', label: 'Sigmoid' },
] as const;

// ── Evaluation options ───────────────────────────────────────────

export const SKLEARN_METRICS = ['mse', 'mae', 'r2', 'rmse', 'mape'] as const;
export const SKLEARN_PLOTS = ['predicted_vs_actual', 'residuals', 'feature_importance'] as const;
export const SKLEARN_SCORING_OPTIONS = [
  { value: 'neg_mean_squared_error', label: 'Neg MSE' },
  { value: 'neg_mean_absolute_error', label: 'Neg MAE' },
  { value: 'r2', label: 'R2' },
] as const;

export const PYTORCH_METRICS = ['mse', 'mae', 'rmse'] as const;
export const PYTORCH_PLOTS = ['predicted_vs_actual', 'loss_curves', 'residuals'] as const;

export const HF_METRICS = ['eval_loss', 'perplexity'] as const;

// ── Default values ───────────────────────────────────────────────

export const DEFAULT_EXPERIMENT: ExperimentState = {
  name: 'my-experiment',
  seed: 42,
  outputDir: './runs/experiment',
};

export const DEFAULT_SKLEARN_DATA: SklearnDataState = {
  source: 'local',
  path: '/path/to/your/data.csv',
  s3Uri: '',
  target: 'target_column_name',
  features: '',
  splitStrategy: 'random',
  trainRatio: 0.7,
  valRatio: 0.15,
  testRatio: 0.15,
  scaler: 'standard',
  handleMissing: 'drop',
};

export const DEFAULT_SKLEARN_MODEL: SklearnModelState = {
  architecture: 'random_forest',
  params: { n_estimators: 100, max_depth: 10 },
};

export const DEFAULT_SKLEARN_TRAINING: SklearnTrainingState = {
  crossValidationEnabled: false,
  folds: 5,
  scoring: 'neg_mean_squared_error',
};

export const DEFAULT_SKLEARN_EVALUATION: SklearnEvaluationState = {
  metrics: ['mse', 'mae', 'r2'],
  plots: ['predicted_vs_actual'],
};

export const DEFAULT_PYTORCH_DATA: PytorchDataState = {
  source: 'local',
  path: '/path/to/your/data.csv',
  s3Uri: '',
  target: 'target_column_name',
  features: '',
  splitStrategy: 'temporal',
  trainRatio: 0.7,
  valRatio: 0.15,
  testRatio: 0.15,
  scaler: 'minmax',
  sequenceLength: 60,
  stride: 1,
};

export const DEFAULT_PYTORCH_MODEL: PytorchModelState = {
  architecture: 'mlp',
  params: { hidden_sizes: '64, 32', dropout: 0.1 },
};

export const DEFAULT_PYTORCH_TRAINING: PytorchTrainingState = {
  epochs: 10,
  batchSize: 32,
  learningRate: 0.001,
  optimizer: 'adam',
  scheduler: 'none',
  gradientClip: 1.0,
  earlyStoppingEnabled: true,
  earlyStoppingPatience: 5,
  earlyStoppingMetric: 'val_loss',
  earlyStoppingMode: 'min',
  checkpointEnabled: false,
};

export const DEFAULT_PYTORCH_EVALUATION: PytorchEvaluationState = {
  metrics: ['mse', 'mae'],
  plots: ['predicted_vs_actual'],
};

export const DEFAULT_HF_DATA: HuggingfaceDataState = {
  source: 'local',
  path: '/path/to/your/instruction_data.json',
  s3Uri: '',
  format: 'instruction',
  maxLength: 512,
  valSplit: 0.1,
};

export const DEFAULT_HF_MODEL: HuggingfaceModelState = {
  baseModel: 'meta-llama/Llama-2-7b-hf',
  adapter: 'lora',
  quantization: 'none',
  loraR: 16,
  loraAlpha: 32,
  loraDropout: 0.05,
  targetModules: 'q_proj, v_proj',
};

export const DEFAULT_HF_TRAINING: HuggingfaceTrainingState = {
  epochs: 3,
  batchSize: 4,
  gradientAccumulationSteps: 4,
  learningRate: 0.0002,
  warmupRatio: 0.03,
  mixedPrecision: 'bf16',
  maxGradNorm: 1.0,
};

export const DEFAULT_HF_EVALUATION: HuggingfaceEvaluationState = {
  metrics: ['eval_loss', 'perplexity'],
};
