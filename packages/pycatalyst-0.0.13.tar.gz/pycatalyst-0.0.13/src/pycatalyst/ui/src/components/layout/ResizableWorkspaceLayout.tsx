'use client';

/**
 * ResizableWorkspaceLayout – collapsible, resizable left sidebar + main content area.
 *
 * COPY-PASTE: This file can be copied to another repo to get the same layout.
 * - Required dependency: react-resizable-panels
 * - Usage: renderSidebar(api) => <YourSidebar {...api} /> and pass main content as children.
 *   Your sidebar should accept: isPanelCollapsed, sidebarDisplayMode, onCollapseRequested,
 *   onExpandRequested.
 * - Optional: height="fill" when this layout is inside a flex container that provides height.
 *
 * SIZE RULES (react-resizable-panels): Numeric values = pixels. Strings without units = percent (0–100).
 * We pass percentage-based props (defaultSize, maxSize, mainMinSize) as strings so the library
 * interprets them correctly; pixel-based props (sidebarMinSize, collapsedSize) stay numeric.
 *
 * OPTIONAL CSS: For resize handle cursor and hover/drag styles, add to your global CSS:
 *   [data-group] { touch-action: none; }
 *   [data-separator] {
 *     touch-action: none !important;
 *     user-select: none !important;
 *     cursor: col-resize !important;
 *     pointer-events: auto !important;
 *     position: relative;
 *   }
 *   [data-separator]:hover { background-color: hsl(var(--primary) / 0.5) !important; }
 *   [data-separator][data-separator-state="dragging"] { background-color: hsl(var(--primary)) !important; }
 */

import { type ReactNode, useRef, useState, useCallback } from 'react';
import { Panel, Group, Separator, type PanelImperativeHandle } from 'react-resizable-panels';

/** Default layout values. Single source of truth for panel sizes and collapse behavior. */
const DEFAULT_LAYOUT = {
  height: 'calc(100vh - 4rem)' as const,
  groupId: 'workspace-layout',
  defaultSidebarSize: 20,
  defaultMainSize: 80,
  sidebarMinSize: 64,
  sidebarMaxSize: 50,
  collapsedSize: 64,
  mainMinSize: 30,
  collapseThresholdPx: 70,
  compactThresholdPx: 360,
} as const;

/** Percent as string for react-resizable-panels (library treats string without unit as %). */
function pct(n: number): string {
  return String(n);
}

export type SidebarDisplayMode = 'expanded' | 'compact' | 'collapsed';

export interface SidebarLayoutApi {
  isPanelCollapsed: boolean;
  sidebarDisplayMode: SidebarDisplayMode;
  onCollapseRequested: () => void;
  onExpandRequested: () => void;
}

export interface ResizableWorkspaceLayoutProps {
  /** Renders the left sidebar; receives collapse API from the layout. */
  renderSidebar: (api: SidebarLayoutApi) => ReactNode;
  /** Main content (e.g. diagram + overlay toolbar). */
  children: ReactNode;
  /** CSS height for the root, or 'fill' to use flex-1 min-h-0 inside a flex parent. */
  height?: string | 'fill';
  /** Prefix for panel ids. Use a unique value if multiple layouts exist on the same page. */
  groupId?: string;
  /** Default sidebar size (percent 0–100). */
  defaultSidebarSize?: number;
  /** Default main size (percent 0–100). */
  defaultMainSize?: number;
  /** Sidebar min size in pixels (numeric = pixels in this library). */
  sidebarMinSize?: number;
  /** Sidebar max size (percent 0–100). */
  sidebarMaxSize?: number;
  /** Sidebar size when collapsed in pixels. */
  collapsedSize?: number;
  /** Main panel min size (percent 0–100). */
  mainMinSize?: number;
  /** Sidebar width in px below which isPanelCollapsed is true. */
  collapseThresholdPx?: number;
  /** Sidebar width in px below which header should switch to compact mode. */
  compactThresholdPx?: number;
  /** Optional class name for the root container. */
  className?: string;
  /** Optional style for the root container (merged with layout styles). */
  style?: React.CSSProperties;
  /** Optional class name for the separator (resize handle). */
  separatorClassName?: string;
  /** Optional class name for the sidebar content wrapper. */
  sidebarClassName?: string;
  /** Optional class name for the main content wrapper. */
  mainClassName?: string;
}

export function ResizableWorkspaceLayout({
  renderSidebar,
  children,
  height = DEFAULT_LAYOUT.height,
  groupId = DEFAULT_LAYOUT.groupId,
  defaultSidebarSize = DEFAULT_LAYOUT.defaultSidebarSize,
  defaultMainSize = DEFAULT_LAYOUT.defaultMainSize,
  sidebarMinSize = DEFAULT_LAYOUT.sidebarMinSize,
  sidebarMaxSize = DEFAULT_LAYOUT.sidebarMaxSize,
  collapsedSize = DEFAULT_LAYOUT.collapsedSize,
  mainMinSize = DEFAULT_LAYOUT.mainMinSize,
  collapseThresholdPx = DEFAULT_LAYOUT.collapseThresholdPx,
  compactThresholdPx = DEFAULT_LAYOUT.compactThresholdPx,
  className,
  style,
  separatorClassName,
  sidebarClassName,
  mainClassName,
}: ResizableWorkspaceLayoutProps) {
  const sidebarPanelRef = useRef<PanelImperativeHandle | null>(null);
  const [sidebarDisplayMode, setSidebarDisplayMode] =
    useState<SidebarDisplayMode>('expanded');

  const onCollapseRequested = useCallback(() => {
    sidebarPanelRef.current?.collapse();
    setSidebarDisplayMode('collapsed');
  }, []);

  const onExpandRequested = useCallback(() => {
    sidebarPanelRef.current?.expand();
    setSidebarDisplayMode('expanded');
  }, []);

  const sidebarPanelCollapsed = sidebarDisplayMode === 'collapsed';
  const sidebarApi: SidebarLayoutApi = {
    isPanelCollapsed: sidebarPanelCollapsed,
    sidebarDisplayMode,
    onCollapseRequested,
    onExpandRequested,
  };

  const isFill = height === 'fill';
  const rootBaseClassName = `flex h-full bg-background ${isFill ? 'flex-1 min-h-0' : ''}`;
  const rootClassName = [rootBaseClassName, className].filter(Boolean).join(' ');
  const rootStyle: React.CSSProperties =
    isFill ? (style ?? {}) : { height, overflow: 'hidden', ...(style ?? {}) };

  const separatorClass = [
    'w-1.5 shrink-0 bg-border transition-colors',
    separatorClassName,
  ].filter(Boolean).join(' ');

  const sidebarWrapperClass = [
    'flex-1 min-h-0 overflow-hidden',
    sidebarClassName,
  ].filter(Boolean).join(' ');

  const mainWrapperClass = [
    'relative flex-1 min-h-0',
    mainClassName,
  ].filter(Boolean).join(' ');

  return (
    <div className={rootClassName} style={rootStyle}>
      <Group
        id={`${groupId}-group`}
        orientation="horizontal"
        className="flex-1 min-w-0"
      >
        <Panel
          id={`${groupId}-sidebar`}
          panelRef={sidebarPanelRef}
          defaultSize={pct(defaultSidebarSize)}
          minSize={sidebarMinSize}
          maxSize={pct(sidebarMaxSize)}
          collapsible
          collapsedSize={collapsedSize}
          className="flex flex-col min-w-0"
          onResize={(size) => {
            const px = size.inPixels;
            if (px <= collapseThresholdPx) {
              setSidebarDisplayMode('collapsed');
            } else if (px <= compactThresholdPx) {
              setSidebarDisplayMode('compact');
            } else {
              setSidebarDisplayMode('expanded');
            }
          }}
        >
          <div className={sidebarWrapperClass}>
            {renderSidebar(sidebarApi)}
          </div>
        </Panel>
        <Separator className={separatorClass} />
        <Panel
          id={`${groupId}-main`}
          defaultSize={pct(defaultMainSize)}
          minSize={pct(mainMinSize)}
          className="flex flex-col min-w-0"
        >
          <div className={mainWrapperClass} style={{ overflow: 'hidden' }}>
            {children}
          </div>
        </Panel>
      </Group>
    </div>
  );
}
