'use client';

import { useState, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { api, ApiError } from '@/lib/api';
import { buildRecipeRunRequestFromFields } from '@/lib/recipe-from-fields';
import { streamSseRecords } from '@/lib/sse-stream';
import {
  RecipeSinkFields,
  type RecipeSinkValue,
} from '@/components/recipes/RecipeSinkFields';
import type { GenerateField } from '@/lib/types';
import type { RecipeSinkMode } from '@/stores/app-config';
import { Play, Square, AlertCircle } from 'lucide-react';

export type FieldRunContext = {
  schemaName: string;
  fields: GenerateField[];
};

export type BatchSuccessPayload = {
  records: Record<string, unknown>[];
  count: number;
  durationMs: number;
  sinkType?: string;
  errors?: string[];
  usedRecipeEndpoint: boolean;
  /** From API `python_api` when present. */
  pythonApi?: string;
};

type GenerateRunBarProps = {
  runContext: FieldRunContext | null;
  recipeSinkMode: RecipeSinkMode;
  onBatchSuccess: (p: BatchSuccessPayload) => void;
  onStreamStarted: () => void;
  onStreamRecord: (record: Record<string, unknown>) => void;
  onStreamFinished: (error?: string) => void;
};

export function GenerateRunBar({
  runContext,
  recipeSinkMode,
  onBatchSuccess,
  onStreamStarted,
  onStreamRecord,
  onStreamFinished,
}: GenerateRunBarProps) {
  const [deliveryMode, setDeliveryMode] = useState<'batch' | 'stream'>('batch');
  const [count, setCount] = useState(10);
  const [seed, setSeed] = useState('');
  const [maxRecords, setMaxRecords] = useState(50);
  const [intervalMs, setIntervalMs] = useState(0);
  const [sink, setSink] = useState<RecipeSinkValue>({
    type: 'memory',
    config: {},
  });
  const [busy, setBusy] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const parseSeed = (): number | undefined => {
    const t = seed.trim();
    if (!t) return undefined;
    const n = Number(t);
    return Number.isFinite(n) ? n : undefined;
  };

  const stopStream = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  const runBatch = async () => {
    if (!runContext) return;
    setError(null);
    setBusy(true);
    const seedN = parseSeed();
    try {
      if (recipeSinkMode === 'full') {
        const body = buildRecipeRunRequestFromFields(
          runContext.schemaName,
          runContext.fields,
          { count, seed: seedN },
          sink,
          recipeSinkMode,
        );
        const res = await api.recipes.run(body);
        onBatchSuccess({
          records: res.records,
          count: res.count,
          durationMs: res.duration_ms,
          sinkType: res.sink_type,
          errors: res.errors,
          usedRecipeEndpoint: true,
          pythonApi: res.python_api,
        });
      } else {
        const res = await api.generate.run({
          name: runContext.schemaName,
          fields: runContext.fields,
          count,
          seed: seedN,
        });
        onBatchSuccess({
          records: res.records,
          count: res.count,
          durationMs: res.duration_ms,
          usedRecipeEndpoint: false,
          pythonApi: res.python_api,
        });
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Generation failed');
    } finally {
      setBusy(false);
    }
  };

  const runStream = async () => {
    if (!runContext) return;
    setError(null);
    const ac = new AbortController();
    abortRef.current = ac;
    setBusy(true);
    setStreaming(true);
    onStreamStarted();
    try {
      const res = await api.stream.openSse(
        {
          name: runContext.schemaName,
          fields: runContext.fields,
          max_records: maxRecords,
          interval_ms: intervalMs || undefined,
          seed: parseSeed(),
        },
        ac.signal,
      );
      for await (const ev of streamSseRecords(res, { signal: ac.signal })) {
        if (ev.kind === 'error') {
          onStreamFinished(ev.message);
          setError(ev.message);
          return;
        }
        onStreamRecord(ev.record);
      }
      onStreamFinished();
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        onStreamFinished();
        return;
      }
      const msg = err instanceof ApiError ? err.message : String(err);
      setError(msg);
      onStreamFinished(msg);
    } finally {
      abortRef.current = null;
      setStreaming(false);
      setBusy(false);
    }
  };

  const handlePrimary = () => {
    if (streaming) {
      stopStream();
      return;
    }
    if (deliveryMode === 'batch') void runBatch();
    else void runStream();
  };

  const canRun = Boolean(runContext?.fields.length);
  const primaryLabel = streaming
    ? 'Stop stream'
    : deliveryMode === 'batch'
      ? busy
        ? 'Generating…'
        : 'Run batch'
      : busy
        ? 'Streaming…'
        : 'Start stream';

  return (
    <div className="space-y-4 rounded-lg border border-border bg-card p-4">
      <div>
        <Label className="text-xs text-muted-foreground">Delivery</Label>
        <div className="flex rounded-md border border-input overflow-hidden mt-1.5 max-w-md">
          <button
            type="button"
            onClick={() => setDeliveryMode('batch')}
            disabled={streaming}
            className={`flex-1 px-3 py-2 text-sm font-medium transition-colors ${
              deliveryMode === 'batch'
                ? 'bg-primary text-primary-foreground'
                : 'bg-background hover:bg-muted'
            }`}
          >
            Batch
          </button>
          <button
            type="button"
            onClick={() => setDeliveryMode('stream')}
            disabled={streaming}
            className={`flex-1 px-3 py-2 text-sm font-medium transition-colors border-l border-input ${
              deliveryMode === 'stream'
                ? 'bg-primary text-primary-foreground'
                : 'bg-background hover:bg-muted'
            }`}
          >
            Stream (live preview)
          </button>
        </div>
        <p className="text-xs text-muted-foreground mt-1.5">
          {deliveryMode === 'batch'
            ? 'Generate all rows at once. Optional sinks when the server uses full recipe mode.'
            : 'Rows arrive over SSE (preview only; no external sink on this path).'}
        </p>
      </div>

      {deliveryMode === 'batch' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="space-y-1">
            <Label className="text-xs">Count</Label>
            <Input
              type="number"
              min={1}
              max={100000}
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
              disabled={busy}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Seed (optional)</Label>
            <Input
              value={seed}
              onChange={(e) => setSeed(e.target.value)}
              placeholder="e.g. 42"
              disabled={busy}
            />
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="space-y-1">
            <Label className="text-xs">Max records</Label>
            <Input
              type="number"
              min={1}
              max={100000}
              value={maxRecords}
              onChange={(e) => setMaxRecords(Number(e.target.value))}
              disabled={busy}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Interval (ms)</Label>
            <Input
              type="number"
              min={0}
              value={intervalMs}
              onChange={(e) => setIntervalMs(Number(e.target.value))}
              disabled={busy}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Seed (optional)</Label>
            <Input
              value={seed}
              onChange={(e) => setSeed(e.target.value)}
              placeholder="e.g. 42"
              disabled={busy}
            />
          </div>
        </div>
      )}

      {deliveryMode === 'batch' && recipeSinkMode === 'full' && (
        <RecipeSinkFields value={sink} onChange={setSink} disabled={busy} />
      )}

      {deliveryMode === 'batch' && recipeSinkMode === 'memory' && (
        <p className="text-xs text-muted-foreground rounded-md border border-dashed border-border px-3 py-2">
          Server is in memory-only mode: output appears in Results (external sinks
          require{' '}
          <code className="text-[10px]">PYCATALYST_RECIPE_SINK_MODE=full</code>).
        </p>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex gap-2">
        <Button
          onClick={handlePrimary}
          disabled={!canRun || (busy && !streaming)}
          className="flex-1 sm:flex-none"
        >
          {streaming ? (
            <Square className="h-4 w-4 mr-2" />
          ) : (
            <Play className="h-4 w-4 mr-2" />
          )}
          {primaryLabel}
        </Button>
        {!canRun && (
          <span className="text-xs text-muted-foreground self-center">
            Define a schema in this tab to enable Run
          </span>
        )}
      </div>
    </div>
  );
}
