/** Assembles all form sections + template/file controls + Run button. */

'use client';

import { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Play, RefreshCw, Upload, RotateCcw } from 'lucide-react';
import { BackendSelector } from './BackendSelector';
import { ExperimentSection } from './ExperimentSection';
import { DataSection } from './DataSection';
import { ModelSection } from './ModelSection';
import { TrainingSection } from './TrainingSection';
import { EvaluationSection } from './EvaluationSection';
import { YamlPreview } from './YamlPreview';
import { ALL_TEMPLATE_OPTIONS } from './templates';
import type { ExperimentFormReturn } from './useExperimentForm';

interface RunPanelProps {
  form: ExperimentFormReturn;
  running: boolean;
  runError: string | null;
  onRun: () => void;
}

export function RunPanel({ form, running, runError, onRun }: RunPanelProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleTemplateSelect = (id: string) => {
    if (!id) return;
    const item = ALL_TEMPLATE_OPTIONS.find((t) => t.id === id);
    if (item) {
      form.loadFromYaml(item.content);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = typeof reader.result === 'string' ? reader.result : '';
      if (!form.loadFromYaml(text)) {
        form.setYamlOverride(text);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-4">
      {runError && (
        <Alert variant="destructive">
          <AlertDescription>{runError}</AlertDescription>
        </Alert>
      )}

      {/* Template + file controls */}
      <div className="flex flex-wrap items-end gap-4">
        <div className="space-y-2 min-w-[200px]">
          <Label>Load template</Label>
          <Select onValueChange={handleTemplateSelect}>
            <SelectTrigger>
              <SelectValue placeholder="Select a template..." />
            </SelectTrigger>
            <SelectContent>
              {ALL_TEMPLATE_OPTIONS.map((item) => (
                <SelectItem key={item.id} value={item.id}>
                  {item.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button variant="outline" type="button" onClick={() => fileInputRef.current?.click()}>
          <Upload className="mr-2 h-4 w-4" />
          Upload file
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".yaml,.yml,application/x-yaml,text/yaml"
          className="hidden"
          onChange={handleFileChange}
          aria-label="Load YAML config file"
        />
        <Button variant="ghost" type="button" onClick={form.reset}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
      </div>

      {/* Backend selector */}
      <BackendSelector value={form.backend} onChange={form.setBackend} />

      {/* Form sections */}
      <ExperimentSection value={form.experiment} onChange={form.updateExperiment} />

      <DataSection
        backend={form.backend}
        sklearnData={form.sklearnData}
        pytorchData={form.pytorchData}
        hfData={form.hfData}
        onSklearnChange={form.updateSklearnData}
        onPytorchChange={form.updatePytorchData}
        onHfChange={form.updateHfData}
      />

      <ModelSection
        backend={form.backend}
        sklearnModel={form.sklearnModel}
        pytorchModel={form.pytorchModel}
        hfModel={form.hfModel}
        onSklearnChange={form.updateSklearnModel}
        onPytorchChange={form.updatePytorchModel}
        onHfChange={form.updateHfModel}
      />

      <TrainingSection
        backend={form.backend}
        sklearnTraining={form.sklearnTraining}
        pytorchTraining={form.pytorchTraining}
        hfTraining={form.hfTraining}
        onSklearnChange={form.updateSklearnTraining}
        onPytorchChange={form.updatePytorchTraining}
        onHfChange={form.updateHfTraining}
      />

      <EvaluationSection
        backend={form.backend}
        sklearnEvaluation={form.sklearnEvaluation}
        pytorchEvaluation={form.pytorchEvaluation}
        hfEvaluation={form.hfEvaluation}
        onSklearnChange={form.updateSklearnEvaluation}
        onPytorchChange={form.updatePytorchEvaluation}
        onHfChange={form.updateHfEvaluation}
      />

      <YamlPreview
        yamlString={form.yamlString}
        yamlOverride={form.yamlOverride}
        onYamlOverride={form.setYamlOverride}
      />

      {/* Run button */}
      <div className="flex justify-end">
        <Button size="lg" onClick={onRun} disabled={running}>
          {running ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Play className="mr-2 h-4 w-4" />}
          {running ? 'Running...' : 'Run Experiment'}
        </Button>
      </div>
    </div>
  );
}
