'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { api, ApiError } from '@/lib/api';
import type { RecipeRunRequest } from '@/lib/types';
import { applyRecipeSinkPolicy } from '@/lib/recipe-from-fields';
import {
  emptyRecipeDraft,
  recipeObjectToDraft,
  draftToSerializable,
  type RecipeDraft,
} from '@/lib/recipe-draft';
import { BUILT_IN_TEMPLATES } from '@/components/generate/generate-utils';
import { RecipeStructuredForm } from '@/components/generate/RecipeStructuredForm';
import type { RecipeSinkMode } from '@/stores/app-config';
import { Play, BookOpen, AlertCircle, Info, Code2, LayoutList } from 'lucide-react';

type RecipeDraftEditorProps = {
  recipeSinkMode: RecipeSinkMode;
  onResult: (
    records: Record<string, unknown>[],
    count: number,
    sink: string,
    duration: number,
    errors?: string[],
    pythonApi?: string,
  ) => void;
};

async function yamlLoad(text: string): Promise<unknown> {
  const jsYaml = await import('js-yaml');
  return jsYaml.load(text);
}

async function yamlDump(obj: Record<string, unknown>): Promise<string> {
  const jsYaml = await import('js-yaml');
  return jsYaml.dump(obj, { lineWidth: 100, noRefs: true });
}

export function RecipeDraftEditor({
  recipeSinkMode,
  onResult,
}: RecipeDraftEditorProps) {
  const [topTab, setTopTab] = useState<'source' | 'structured'>('source');
  const [yamlText, setYamlText] = useState('');
  const [draft, setDraft] = useState<RecipeDraft>(() => emptyRecipeDraft());
  const [syncRevision, setSyncRevision] = useState(0);
  const [structuredError, setStructuredError] = useState<string | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const [sinkWarning, setSinkWarning] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const applyParsedDraft = useCallback((d: RecipeDraft) => {
    setDraft(d);
    setSyncRevision((n) => n + 1);
    setStructuredError(null);
  }, []);

  const tryParseYamlToDraft = useCallback(
    async (text: string): Promise<boolean> => {
      const trimmed = text.trim();
      if (!trimmed) {
        setStructuredError(null);
        applyParsedDraft(emptyRecipeDraft());
        return true;
      }
      try {
        const loaded = await yamlLoad(trimmed);
        if (!loaded || typeof loaded !== 'object' || Array.isArray(loaded)) {
          setStructuredError('YAML root must be an object.');
          return false;
        }
        const r = recipeObjectToDraft(loaded as Record<string, unknown>);
        if (!r.ok) {
          setStructuredError(r.error);
          return false;
        }
        applyParsedDraft(r.draft);
        return true;
      } catch {
        setStructuredError('Invalid YAML syntax.');
        return false;
      }
    },
    [applyParsedDraft],
  );

  const handleTopTabChange = async (v: string) => {
    const next = v as 'source' | 'structured';
    if (next === 'structured') {
      await tryParseYamlToDraft(yamlText);
    }
    setTopTab(next);
  };

  useEffect(() => {
    if (topTab !== 'structured') return;
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      void (async () => {
        try {
          const y = await yamlDump(draftToSerializable(draft));
          setYamlText(y);
        } catch {
          /* ignore dump errors */
        }
      })();
    }, 280);
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [draft, topTab]);

  const loadTemplate = async (yaml: string) => {
    setYamlText(yaml);
    setRunError(null);
    setStructuredError(null);
    try {
      const loaded = await yamlLoad(yaml);
      if (loaded && typeof loaded === 'object' && !Array.isArray(loaded)) {
        const r = recipeObjectToDraft(loaded as Record<string, unknown>);
        if (r.ok) {
          applyParsedDraft(r.draft);
        }
      }
    } catch {
      /* template always valid */
    }
  };

  const handleRun = async () => {
    setRunError(null);
    setSinkWarning(null);
    if (!yamlText.trim()) {
      setRunError('Enter a recipe YAML, use the structured editor, or select a template');
      return;
    }
    setLoading(true);
    try {
      const loaded = await yamlLoad(yamlText);
      if (!loaded || typeof loaded !== 'object' || Array.isArray(loaded)) {
        setRunError('Invalid YAML format');
        return;
      }
      const r = recipeObjectToDraft(loaded as Record<string, unknown>);
      if (!r.ok) {
        setRunError(r.error);
        return;
      }
      if (r.draft.fields.length === 0) {
        setRunError('Add at least one schema field before running');
        return;
      }
      const body: RecipeRunRequest = {
        name: r.draft.name,
        description: r.draft.description,
        schema: { fields: r.draft.fields },
        generation: {
          count: r.draft.generation.count,
          ...(r.draft.generation.seed !== undefined
            ? { seed: r.draft.generation.seed }
            : {}),
        },
        sink: applyRecipeSinkPolicy(r.draft.sink, recipeSinkMode),
      };
      const res = await api.recipes.run(body);
      onResult(
        res.records,
        res.count,
        res.sink_type,
        res.duration_ms,
        res.errors,
        res.python_api,
      );
      if (res.errors?.length) {
        setSinkWarning(res.errors.join('; '));
      }
    } catch (err) {
      if (err instanceof ApiError) {
        setRunError(err.message);
      } else if (err instanceof Error) {
        setRunError(err.message);
      } else {
        setRunError('Recipe execution failed');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recipe</CardTitle>
        <CardDescription>
          Full pipeline: schema + generation + sink. Switch between Source (YAML) and
          Structured views — they stay in sync when the YAML is valid. Batch-only here;
          live SSE from field definitions uses the other Generate tabs.
        </CardDescription>
        {recipeSinkMode === 'memory' && (
          <p className="text-sm text-muted-foreground font-normal">
            API uses an in-memory sink unless{' '}
            <code className="text-xs">PYCATALYST_RECIPE_SINK_MODE=full</code> is set.
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="border-muted">
          <Info className="h-4 w-4" />
          <AlertDescription className="text-xs">
            Structured round-trip may drop YAML comments and keys not represented in the
            form. Nested schema fields remain in YAML; edit them under Source.
          </AlertDescription>
        </Alert>

        <div className="space-y-2">
          <Label>Templates</Label>
          <div className="flex flex-wrap gap-2">
            {Object.keys(BUILT_IN_TEMPLATES).map((name) => (
              <Button
                key={name}
                variant="outline"
                size="sm"
                onClick={() => loadTemplate(BUILT_IN_TEMPLATES[name])}
              >
                <BookOpen className="h-3 w-3 mr-1" />
                {name}
              </Button>
            ))}
          </div>
        </div>

        <Tabs value={topTab} onValueChange={handleTopTabChange}>
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="source" className="gap-2">
              <Code2 className="h-4 w-4" />
              Source (YAML)
            </TabsTrigger>
            <TabsTrigger value="structured" className="gap-2">
              <LayoutList className="h-4 w-4" />
              Structured
            </TabsTrigger>
          </TabsList>

          <TabsContent value="source" className="mt-4 space-y-2">
            <p className="text-xs text-muted-foreground">
              Edit as YAML. Open Structured to validate and edit in forms — invalid YAML
              shows an error there without changing your last good recipe.
            </p>
            <Label>Recipe YAML</Label>
            <Textarea
              value={yamlText}
              onChange={(e) => {
                setYamlText(e.target.value);
                setStructuredError(null);
              }}
              placeholder="Paste recipe YAML or select a template..."
              className="font-mono text-sm min-h-[320px]"
            />
          </TabsContent>

          <TabsContent value="structured" className="mt-4 space-y-3">
            {structuredError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{structuredError}</AlertDescription>
              </Alert>
            )}
            {!structuredError && (
              <RecipeStructuredForm
                draft={draft}
                onDraftChange={setDraft}
                syncRevision={syncRevision}
                disabled={loading}
                recipeSinkMode={recipeSinkMode}
              />
            )}
          </TabsContent>
        </Tabs>

        {sinkWarning && (
          <Alert variant="default">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>Sink reported: {sinkWarning}</AlertDescription>
          </Alert>
        )}
        {runError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{runError}</AlertDescription>
          </Alert>
        )}
        <Button onClick={handleRun} disabled={loading} className="w-full">
          <Play className="h-4 w-4 mr-2" />
          {loading ? 'Running...' : 'Run recipe'}
        </Button>
      </CardContent>
    </Card>
  );
}
