/** Training hyperparameters section with backend-specific controls. */

'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Separator } from '@/components/ui/separator';
import { ChevronDown } from 'lucide-react';
import type {
  Backend,
  SklearnTrainingState,
  PytorchTrainingState,
  HuggingfaceTrainingState,
} from './types';
import {
  SKLEARN_SCORING_OPTIONS,
  OPTIMIZER_OPTIONS,
  SCHEDULER_OPTIONS,
  EARLY_STOP_MODE_OPTIONS,
  MIXED_PRECISION_OPTIONS,
} from './constants';
import { HelpTip } from './HelpTip';

// ── Sklearn Training ─────────────────────────────────────────────

interface SklearnTrainingProps {
  value: SklearnTrainingState;
  onChange: (partial: Partial<SklearnTrainingState>) => void;
}

function SklearnTraining({ value, onChange }: SklearnTrainingProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Switch
          checked={value.crossValidationEnabled}
          onCheckedChange={(checked) => onChange({ crossValidationEnabled: checked })}
        />
        <Label>
          Cross-validation
          <HelpTip text="Enable k-fold cross-validation for robust metric estimates" />
        </Label>
      </div>

      {value.crossValidationEnabled && (
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>
              Folds
              <HelpTip text="Number of cross-validation folds" />
            </Label>
            <Input
              type="number"
              min={2}
              max={20}
              value={value.folds}
              onChange={(e) => onChange({ folds: Number(e.target.value) })}
            />
          </div>
          <div className="space-y-2">
            <Label>
              Scoring
              <HelpTip text="Metric used for cross-validation scoring" />
            </Label>
            <Select value={value.scoring} onValueChange={(v) => onChange({ scoring: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SKLEARN_SCORING_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}
    </div>
  );
}

// ── PyTorch Training ─────────────────────────────────────────────

interface PytorchTrainingProps {
  value: PytorchTrainingState;
  onChange: (partial: Partial<PytorchTrainingState>) => void;
}

function PytorchTraining({ value, onChange }: PytorchTrainingProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>
            Epochs
            <HelpTip text="Number of full passes over the training data" />
          </Label>
          <Input type="number" min={1} value={value.epochs} onChange={(e) => onChange({ epochs: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Batch size
            <HelpTip text="Samples per gradient update" />
          </Label>
          <Input type="number" min={1} value={value.batchSize} onChange={(e) => onChange({ batchSize: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Learning rate
            <HelpTip text="Step size for optimizer updates" />
          </Label>
          <Input type="number" step={0.0001} min={0} value={value.learningRate} onChange={(e) => onChange({ learningRate: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>Optimizer</Label>
          <Select value={value.optimizer} onValueChange={(v) => onChange({ optimizer: v as PytorchTrainingState['optimizer'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {OPTIMIZER_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Scheduler
            <HelpTip text="Learning rate schedule" />
          </Label>
          <Select value={value.scheduler} onValueChange={(v) => onChange({ scheduler: v as PytorchTrainingState['scheduler'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {SCHEDULER_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Gradient clip
            <HelpTip text="Maximum gradient norm for clipping" />
          </Label>
          <Input type="number" step={0.1} min={0} value={value.gradientClip} onChange={(e) => onChange({ gradientClip: Number(e.target.value) })} />
        </div>
      </div>

      <Separator />

      <Collapsible defaultOpen={value.earlyStoppingEnabled}>
        <div className="flex items-center gap-3">
          <Switch
            checked={value.earlyStoppingEnabled}
            onCheckedChange={(checked) => onChange({ earlyStoppingEnabled: checked })}
          />
          <CollapsibleTrigger className="flex items-center gap-1 text-sm font-medium">
            Early Stopping
            <ChevronDown className="h-4 w-4" />
          </CollapsibleTrigger>
        </div>
        <CollapsibleContent>
          {value.earlyStoppingEnabled && (
            <div className="grid grid-cols-3 gap-4 mt-3">
              <div className="space-y-2">
                <Label>
                  Patience
                  <HelpTip text="Epochs to wait before stopping" />
                </Label>
                <Input type="number" min={1} value={value.earlyStoppingPatience} onChange={(e) => onChange({ earlyStoppingPatience: Number(e.target.value) })} />
              </div>
              <div className="space-y-2">
                <Label>Metric</Label>
                <Input value={value.earlyStoppingMetric} onChange={(e) => onChange({ earlyStoppingMetric: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Mode</Label>
                <Select value={value.earlyStoppingMode} onValueChange={(v) => onChange({ earlyStoppingMode: v as PytorchTrainingState['earlyStoppingMode'] })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {EARLY_STOP_MODE_OPTIONS.map((o) => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </CollapsibleContent>
      </Collapsible>

      <div className="flex items-center gap-3">
        <Switch
          checked={value.checkpointEnabled}
          onCheckedChange={(checked) => onChange({ checkpointEnabled: checked })}
        />
        <Label>
          Save checkpoints
          <HelpTip text="Save best model weights during training" />
        </Label>
      </div>
    </div>
  );
}

// ── HuggingFace Training ─────────────────────────────────────────

interface HuggingfaceTrainingProps {
  value: HuggingfaceTrainingState;
  onChange: (partial: Partial<HuggingfaceTrainingState>) => void;
}

function HuggingfaceTraining({ value, onChange }: HuggingfaceTrainingProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>
            Epochs
            <HelpTip text="Number of training epochs" />
          </Label>
          <Input type="number" min={1} value={value.epochs} onChange={(e) => onChange({ epochs: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Batch size
            <HelpTip text="Per-device training batch size" />
          </Label>
          <Input type="number" min={1} value={value.batchSize} onChange={(e) => onChange({ batchSize: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Gradient accumulation
            <HelpTip text="Steps before weight update (effective batch = batch_size x steps)" />
          </Label>
          <Input type="number" min={1} value={value.gradientAccumulationSteps} onChange={(e) => onChange({ gradientAccumulationSteps: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Learning rate
            <HelpTip text="Peak learning rate" />
          </Label>
          <Input type="number" step={0.0001} min={0} value={value.learningRate} onChange={(e) => onChange({ learningRate: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Warmup ratio
            <HelpTip text="Fraction of training for LR warmup" />
          </Label>
          <div className="flex items-center gap-3">
            <Slider
              value={[value.warmupRatio]}
              onValueChange={([v]) => onChange({ warmupRatio: Math.round(v * 100) / 100 })}
              min={0}
              max={0.5}
              step={0.01}
              className="flex-1"
            />
            <span className="text-sm text-muted-foreground w-10 text-right">{value.warmupRatio}</span>
          </div>
        </div>
        <div className="space-y-2">
          <Label>Mixed precision</Label>
          <Select value={value.mixedPrecision} onValueChange={(v) => onChange({ mixedPrecision: v as HuggingfaceTrainingState['mixedPrecision'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {MIXED_PRECISION_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="max-w-xs space-y-2">
        <Label>
          Max gradient norm
          <HelpTip text="Maximum gradient norm for clipping" />
        </Label>
        <Input type="number" step={0.1} min={0} value={value.maxGradNorm} onChange={(e) => onChange({ maxGradNorm: Number(e.target.value) })} />
      </div>
    </div>
  );
}

// ── Main export ──────────────────────────────────────────────────

interface TrainingSectionProps {
  backend: Backend;
  sklearnTraining: SklearnTrainingState;
  pytorchTraining: PytorchTrainingState;
  hfTraining: HuggingfaceTrainingState;
  onSklearnChange: (partial: Partial<SklearnTrainingState>) => void;
  onPytorchChange: (partial: Partial<PytorchTrainingState>) => void;
  onHfChange: (partial: Partial<HuggingfaceTrainingState>) => void;
}

export function TrainingSection({
  backend,
  sklearnTraining,
  pytorchTraining,
  hfTraining,
  onSklearnChange,
  onPytorchChange,
  onHfChange,
}: TrainingSectionProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Training</CardTitle>
      </CardHeader>
      <CardContent>
        {backend === 'sklearn' && <SklearnTraining value={sklearnTraining} onChange={onSklearnChange} />}
        {backend === 'pytorch' && <PytorchTraining value={pytorchTraining} onChange={onPytorchChange} />}
        {backend === 'huggingface' && <HuggingfaceTraining value={hfTraining} onChange={onHfChange} />}
      </CardContent>
    </Card>
  );
}
