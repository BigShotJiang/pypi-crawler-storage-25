'use client';

import { useCallback } from 'react';
import { Plus, Pencil, Trash2, Circle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  useGenerateWorkspaceStore,
  selectFields,
  selectSelectedFieldIndex,
} from '@/stores/generate-workspace';
import { FIELD_TYPES } from '@/components/generate/generate-utils';
import type { GenerateField } from '@/lib/types';

/* ── Type badge colour map ─────────────────────────────── */

const TYPE_COLOR: Record<string, string> = {
  string: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  int: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  float:
    'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
  bool: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
  date: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
  datetime:
    'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200',
  uuid: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200',
  enum: 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
  object: 'bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-200',
  array:
    'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
};

function typeBadgeClass(type: string): string {
  return TYPE_COLOR[type] ?? TYPE_COLOR.string;
}

/* ── Constraints summary ───────────────────────────────── */

function summariseConstraints(
  constraints: Record<string, unknown> | undefined,
): string {
  if (!constraints || Object.keys(constraints).length === 0) return '--';

  const parts: string[] = [];

  if ('min' in constraints) parts.push(`min: ${constraints.min}`);
  if ('max' in constraints) parts.push(`max: ${constraints.max}`);
  if ('min_length' in constraints) {
    parts.push(`minLen: ${constraints.min_length}`);
  }
  if ('max_length' in constraints) {
    parts.push(`maxLen: ${constraints.max_length}`);
  }
  if ('choices' in constraints) {
    const choices = constraints.choices;
    if (Array.isArray(choices)) {
      const preview =
        choices.length <= 3
          ? choices.join(', ')
          : `${choices.slice(0, 3).join(', ')}...`;
      parts.push(`[${preview}]`);
    }
  }
  if ('pattern' in constraints) {
    parts.push(`/${String(constraints.pattern)}/`);
  }
  if ('format' in constraints) parts.push(`fmt: ${constraints.format}`);
  if ('distribution' in constraints) {
    parts.push(`dist: ${constraints.distribution}`);
  }
  if ('unique' in constraints && constraints.unique) parts.push('unique');
  if ('min_items' in constraints) {
    parts.push(`minItems: ${constraints.min_items}`);
  }
  if ('max_items' in constraints) {
    parts.push(`maxItems: ${constraints.max_items}`);
  }

  return parts.length > 0 ? parts.join(', ') : '--';
}

/* ── Default field factory ─────────────────────────────── */

function makeDefaultField(): GenerateField {
  return {
    name: `field_${Date.now().toString(36)}`,
    type: FIELD_TYPES[0],
    nullable: false,
  };
}

/* ── Column header cell ────────────────────────────────── */

function Th({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <th
      className={`px-3 py-2 text-left text-xs font-medium uppercase
        tracking-wider text-muted-foreground ${className ?? ''}`}
    >
      {children}
    </th>
  );
}

/* ── Field row ─────────────────────────────────────────── */

type FieldRowProps = {
  field: GenerateField;
  index: number;
  isSelected: boolean;
  onSelect: (index: number) => void;
  onRemove: (index: number) => void;
};

function FieldRow({
  field,
  index,
  isSelected,
  onSelect,
  onRemove,
}: FieldRowProps) {
  const constraintText = summariseConstraints(field.constraints);

  return (
    <tr
      role="button"
      tabIndex={0}
      onClick={() => onSelect(index)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect(index);
        }
      }}
      className={`cursor-pointer border-b border-border transition-colors
        hover:bg-muted/50 ${isSelected ? 'bg-primary/5 ring-1 ring-inset ring-primary/20' : ''}`}
    >
      <td className="px-3 py-2 text-xs text-muted-foreground tabular-nums">
        {index + 1}
      </td>

      <td className="px-3 py-2 text-sm font-medium">{field.name || '(unnamed)'}</td>

      <td className="px-3 py-2">
        <Badge
          variant="secondary"
          className={`text-[10px] ${typeBadgeClass(field.type)}`}
        >
          {field.type}
        </Badge>
      </td>

      <td className="px-3 py-2 text-center">
        {field.nullable ? (
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Circle className="mx-auto h-3 w-3 fill-amber-400 text-amber-400" />
              </TooltipTrigger>
              <TooltipContent side="top" className="text-xs">
                Nullable
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ) : (
          <span className="text-xs text-muted-foreground">--</span>
        )}
      </td>

      <td className="max-w-[200px] truncate px-3 py-2 text-xs text-muted-foreground">
        {constraintText}
      </td>

      <td className="px-3 py-2">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={(e) => {
              e.stopPropagation();
              onSelect(index);
            }}
            aria-label={`Edit field ${field.name}`}
          >
            <Pencil className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-destructive hover:text-destructive"
            onClick={(e) => {
              e.stopPropagation();
              onRemove(index);
            }}
            aria-label={`Delete field ${field.name}`}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </td>
    </tr>
  );
}

/* ── SchemaFieldTable ──────────────────────────────────── */

export function SchemaFieldTable() {
  const fields = useGenerateWorkspaceStore(selectFields);
  const selectedFieldIndex = useGenerateWorkspaceStore(selectSelectedFieldIndex);
  const setSelectedFieldIndex = useGenerateWorkspaceStore(
    (s) => s.setSelectedFieldIndex,
  );
  const addField = useGenerateWorkspaceStore((s) => s.addField);
  const removeField = useGenerateWorkspaceStore((s) => s.removeField);

  const handleSelect = useCallback(
    (idx: number) => {
      setSelectedFieldIndex(idx === selectedFieldIndex ? null : idx);
    },
    [setSelectedFieldIndex, selectedFieldIndex],
  );

  const handleRemove = useCallback(
    (idx: number) => {
      removeField(idx);
    },
    [removeField],
  );

  const handleAdd = useCallback(() => {
    addField(makeDefaultField());
    setSelectedFieldIndex(fields.length);
  }, [addField, setSelectedFieldIndex, fields.length]);

  /* ── Empty state ─────────────────────────────────────── */

  if (fields.length === 0) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4 p-8 text-center">
        <p className="text-sm text-muted-foreground">
          Define a schema using the sidebar, or load a template to get started.
        </p>
        <Button variant="outline" size="sm" onClick={handleAdd}>
          <Plus className="mr-1.5 h-3.5 w-3.5" />
          Add field
        </Button>
      </div>
    );
  }

  /* ── Table ───────────────────────────────────────────── */

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse text-sm">
          <thead className="sticky top-0 z-[1] bg-muted/80 backdrop-blur-sm">
            <tr className="border-b border-border">
              <Th className="w-10">#</Th>
              <Th>Name</Th>
              <Th className="w-24">Type</Th>
              <Th className="w-16 text-center">Null</Th>
              <Th>Constraints</Th>
              <Th className="w-24">Actions</Th>
            </tr>
          </thead>
          <tbody>
            {fields.map((field, idx) => (
              <FieldRow
                key={`${field.name}-${idx}`}
                field={field}
                index={idx}
                isSelected={selectedFieldIndex === idx}
                onSelect={handleSelect}
                onRemove={handleRemove}
              />
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex-none border-t border-border px-3 py-2">
        <Button variant="outline" size="sm" onClick={handleAdd}>
          <Plus className="mr-1.5 h-3.5 w-3.5" />
          Add field
        </Button>
      </div>
    </div>
  );
}
