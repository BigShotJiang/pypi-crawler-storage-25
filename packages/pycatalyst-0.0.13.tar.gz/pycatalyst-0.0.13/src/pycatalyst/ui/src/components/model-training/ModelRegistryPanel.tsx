/** Saved model management panel for listing, inspecting, and deleting models. */

'use client';

import { useEffect, useState } from 'react';
import { AlertCircle, Download, RefreshCw, Search, Trash2, X } from 'lucide-react';
import { api, ApiError } from '@/lib/api';
import type { MlModelDetail, MlModelSummary } from '@/lib/types';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface ModelRegistryPanelProps {
  highlightedModelId?: string | null;
}

type BackendFilter = 'all' | 'sklearn' | 'pytorch' | 'huggingface';
type SortBy = 'timestamp' | 'name' | 'backend' | 'duration_seconds';
type SortOrder = 'asc' | 'desc';

const PAGE_SIZE_OPTIONS = [10, 20, 50];

export function ModelRegistryPanel({ highlightedModelId = null }: ModelRegistryPanelProps) {
  const [models, setModels] = useState<MlModelSummary[]>([]);
  const [selectedModelId, setSelectedModelId] = useState<string | null>(highlightedModelId);
  const [selectedModel, setSelectedModel] = useState<MlModelDetail | null>(null);
  const [search, setSearch] = useState('');
  const [backendFilter, setBackendFilter] = useState<BackendFilter>('all');
  const [sortBy, setSortBy] = useState<SortBy>('timestamp');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(1);
  const [totalModels, setTotalModels] = useState(0);
  const [loading, setLoading] = useState(false);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [deletingModel, setDeletingModel] = useState(false);
  const [actioningArtifact, setActioningArtifact] = useState<string | null>(null);
  const [confirmDeleteModelOpen, setConfirmDeleteModelOpen] = useState(false);
  const [confirmDeleteArtifactName, setConfirmDeleteArtifactName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const totalPages = Math.max(1, Math.ceil(totalModels / pageSize));

  const fetchModels = async (preferredSelectionId?: string | null) => {
    setLoading(true);
    setError(null);
    try {
      const response = await api.ml.listModels({
        backend: backendFilter === 'all' ? undefined : backendFilter,
        limit: pageSize,
        offset: (page - 1) * pageSize,
        sortBy,
        sortOrder,
      });
      setModels(response.models);
      setTotalModels(response.total);

      if (response.models.length === 0) {
        if (page > 1) {
          setPage((p) => p - 1);
          return;
        }
        setSelectedModelId(null);
        setSelectedModel(null);
        return;
      }

      const candidateId = preferredSelectionId ?? selectedModelId ?? highlightedModelId;
      const hasCandidate = candidateId && response.models.some((m) => m.id === candidateId);
      setSelectedModelId(hasCandidate ? candidateId : response.models[0].id);
    } catch (err) {
      setError(resolveApiError(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchModels();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [backendFilter, sortBy, sortOrder, pageSize, page]);

  useEffect(() => {
    if (highlightedModelId) {
      setSelectedModelId(highlightedModelId);
    }
  }, [highlightedModelId]);

  useEffect(() => {
    if (!selectedModelId) {
      setSelectedModel(null);
      return;
    }
    const fetchDetail = async () => {
      setLoadingDetails(true);
      setError(null);
      try {
        const detail = await api.ml.getModel(selectedModelId);
        setSelectedModel(detail);
      } catch (err) {
        setError(resolveApiError(err));
      } finally {
        setLoadingDetails(false);
      }
    };
    void fetchDetail();
  }, [selectedModelId]);

  const filteredModels = models.filter((model) => {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return model.name.toLowerCase().includes(q) || model.id.toLowerCase().includes(q);
  });

  const handleDeleteModel = async () => {
    if (!selectedModelId) return;
    setDeletingModel(true);
    setError(null);
    try {
      await api.ml.deleteModel(selectedModelId);
      setConfirmDeleteModelOpen(false);
      await fetchModels(null);
    } catch (err) {
      setError(resolveApiError(err));
    } finally {
      setDeletingModel(false);
    }
  };

  const handleDownloadArtifact = async (artifactName: string) => {
    if (!selectedModelId) return;
    setActioningArtifact(artifactName);
    setError(null);
    try {
      const blob = await api.ml.downloadArtifact(selectedModelId, artifactName);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = artifactName;
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(resolveApiError(err));
    } finally {
      setActioningArtifact(null);
    }
  };

  const handleDeleteArtifact = async (artifactName: string) => {
    if (!selectedModelId) return;
    setActioningArtifact(artifactName);
    setError(null);
    try {
      await api.ml.deleteArtifact(selectedModelId, artifactName);
      const detail = await api.ml.getModel(selectedModelId);
      setSelectedModel(detail);
      setConfirmDeleteArtifactName(null);
    } catch (err) {
      setError(resolveApiError(err));
    } finally {
      setActioningArtifact(null);
    }
  };

  return (
    <>
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
        <Card className="xl:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle>Saved Models</CardTitle>
            <CardDescription>Browse persisted training runs and select one for details.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="relative sm:col-span-2">
                <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search current page"
                  className="pl-9"
                />
              </div>

              <Select
                value={backendFilter}
                onValueChange={(v) => {
                  setBackendFilter(v as BackendFilter);
                  setPage(1);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Filter backend" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All backends</SelectItem>
                  <SelectItem value="sklearn">Sklearn</SelectItem>
                  <SelectItem value="pytorch">PyTorch</SelectItem>
                  <SelectItem value="huggingface">Hugging Face</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortBy)}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="timestamp">Sort: Timestamp</SelectItem>
                  <SelectItem value="name">Sort: Name</SelectItem>
                  <SelectItem value="backend">Sort: Backend</SelectItem>
                  <SelectItem value="duration_seconds">Sort: Duration</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortOrder} onValueChange={(v) => setSortOrder(v as SortOrder)}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort order" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="desc">Newest first</SelectItem>
                  <SelectItem value="asc">Oldest first</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={String(pageSize)}
                onValueChange={(v) => {
                  setPageSize(Number(v));
                  setPage(1);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Page size" />
                </SelectTrigger>
                <SelectContent>
                  {PAGE_SIZE_OPTIONS.map((size) => (
                    <SelectItem key={size} value={String(size)}>
                      {size} / page
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">{totalModels} total</p>
              <Button variant="outline" size="sm" onClick={() => void fetchModels()} disabled={loading}>
                {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                Refresh
              </Button>
            </div>

            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {filteredModels.length === 0 && (
                <p className="text-sm text-muted-foreground py-4">No saved models found.</p>
              )}
              {filteredModels.map((model) => (
                <button
                  key={model.id}
                  onClick={() => setSelectedModelId(model.id)}
                  className={`w-full text-left p-3 rounded-lg border transition ${
                    selectedModelId === model.id
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50 hover:bg-muted/40'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold truncate">{model.name}</p>
                    <Badge variant="secondary">{model.backend}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{model.id}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatTimestamp(model.timestamp)} • {model.artifact_names.length} artifact(s)
                  </p>
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                size="sm"
                disabled={page <= 1 || loading}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </Button>
              <p className="text-xs text-muted-foreground">Page {page} / {totalPages}</p>
              <Button
                variant="ghost"
                size="sm"
                disabled={page >= totalPages || loading}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="xl:col-span-3">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <CardTitle>Model Details</CardTitle>
                <CardDescription>Inspect run metadata, config, metrics, and downloadable artifacts.</CardDescription>
              </div>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setConfirmDeleteModelOpen(true)}
                disabled={!selectedModelId || loadingDetails}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete model
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {!selectedModelId && (
              <p className="text-sm text-muted-foreground">Select a model from the left panel.</p>
            )}

            {selectedModelId && loadingDetails && (
              <p className="text-sm text-muted-foreground">Loading model details...</p>
            )}

            {selectedModel && !loadingDetails && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <InfoCard label="Name" value={selectedModel.name} />
                  <InfoCard label="Backend" value={selectedModel.backend} />
                  <InfoCard label="Status" value={selectedModel.status ?? 'n/a'} />
                  <InfoCard
                    label="Duration"
                    value={selectedModel.duration_seconds != null ? `${selectedModel.duration_seconds.toFixed(2)}s` : 'n/a'}
                  />
                </div>

                <section>
                  <h3 className="text-sm font-semibold mb-2">Metrics</h3>
                  <pre className="bg-muted rounded-md p-3 overflow-x-auto text-xs">
                    {JSON.stringify(selectedModel.metrics, null, 2)}
                  </pre>
                </section>

                <section>
                  <h3 className="text-sm font-semibold mb-2">Artifacts</h3>
                  {selectedModel.artifact_names.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No persisted artifacts for this model.</p>
                  ) : (
                    <div className="space-y-2">
                      {selectedModel.artifact_names.map((artifactName) => (
                        <div key={artifactName} className="flex items-center justify-between gap-2 rounded-md border p-2">
                          <span className="text-sm truncate">{artifactName}</span>
                          <div className="flex items-center gap-2 shrink-0">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => void handleDownloadArtifact(artifactName)}
                              disabled={actioningArtifact === artifactName}
                            >
                              <Download className="mr-2 h-3.5 w-3.5" />
                              Download
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setConfirmDeleteArtifactName(artifactName)}
                              disabled={actioningArtifact === artifactName}
                            >
                              <Trash2 className="mr-2 h-3.5 w-3.5" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </section>

                <section>
                  <h3 className="text-sm font-semibold mb-2">Config</h3>
                  <pre className="bg-muted rounded-md p-3 overflow-x-auto text-xs max-h-52">
                    {JSON.stringify(selectedModel.config, null, 2)}
                  </pre>
                </section>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <ConfirmDialog
        open={confirmDeleteModelOpen}
        title="Delete model"
        description="This will permanently remove the selected model entry and its persisted artifacts."
        confirmLabel="Delete model"
        loading={deletingModel}
        onCancel={() => setConfirmDeleteModelOpen(false)}
        onConfirm={() => void handleDeleteModel()}
      />

      <ConfirmDialog
        open={confirmDeleteArtifactName !== null}
        title="Delete artifact"
        description={confirmDeleteArtifactName ? `Delete artifact '${confirmDeleteArtifactName}'?` : 'Delete artifact?'}
        confirmLabel="Delete artifact"
        loading={!!confirmDeleteArtifactName && actioningArtifact === confirmDeleteArtifactName}
        onCancel={() => setConfirmDeleteArtifactName(null)}
        onConfirm={() => {
          if (!confirmDeleteArtifactName) return;
          void handleDeleteArtifact(confirmDeleteArtifactName);
        }}
      />
    </>
  );
}

interface InfoCardProps {
  label: string;
  value: string;
}

function InfoCard({ label, value }: InfoCardProps) {
  return (
    <div className="rounded-md border p-3">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold mt-1">{value}</p>
    </div>
  );
}

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  description: string;
  confirmLabel: string;
  loading?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel,
  loading = false,
  onCancel,
  onConfirm,
}: ConfirmDialogProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onCancel} />
      <div className="relative bg-background border rounded-lg shadow-xl w-full max-w-md mx-4 p-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button
            type="button"
            onClick={onCancel}
            className="p-1 rounded hover:bg-muted text-muted-foreground"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <p className="text-sm text-muted-foreground mb-5">{description}</p>
        <div className="flex justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={onCancel} disabled={loading}>
            Cancel
          </Button>
          <Button variant="destructive" size="sm" onClick={onConfirm} disabled={loading}>
            {loading ? 'Deleting...' : confirmLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}

function formatTimestamp(raw: string | null): string {
  if (!raw) return 'Unknown time';
  const date = new Date(raw);
  if (Number.isNaN(date.getTime())) return 'Unknown time';
  return date.toLocaleString();
}

function resolveApiError(err: unknown): string {
  if (err instanceof ApiError) {
    const detail = err.response?.detail;
    if (typeof detail === 'string') return detail;
    if (typeof detail === 'object' && detail && 'message' in detail) {
      return String((detail as { message: unknown }).message);
    }
    return err.message;
  }
  if (err instanceof Error) return err.message;
  return 'Unexpected error';
}
