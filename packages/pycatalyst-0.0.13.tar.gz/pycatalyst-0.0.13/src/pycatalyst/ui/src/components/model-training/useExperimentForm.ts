/** Custom hook for experiment form state management. */

import { useState, useMemo, useCallback } from 'react';
import type {
  Backend,
  ExperimentState,
  FormState,
  SklearnDataState,
  SklearnModelState,
  SklearnTrainingState,
  SklearnEvaluationState,
  PytorchDataState,
  PytorchModelState,
  PytorchTrainingState,
  PytorchEvaluationState,
  HuggingfaceDataState,
  HuggingfaceModelState,
  HuggingfaceTrainingState,
  HuggingfaceEvaluationState,
} from './types';
import {
  DEFAULT_EXPERIMENT,
  DEFAULT_SKLEARN_DATA,
  DEFAULT_SKLEARN_MODEL,
  DEFAULT_SKLEARN_TRAINING,
  DEFAULT_SKLEARN_EVALUATION,
  DEFAULT_PYTORCH_DATA,
  DEFAULT_PYTORCH_MODEL,
  DEFAULT_PYTORCH_TRAINING,
  DEFAULT_PYTORCH_EVALUATION,
  DEFAULT_HF_DATA,
  DEFAULT_HF_MODEL,
  DEFAULT_HF_TRAINING,
  DEFAULT_HF_EVALUATION,
  SKLEARN_MODELS,
} from './constants';
import { formStateToYaml, parseYamlToFormState } from '@/lib/yaml-builder';

export interface ExperimentFormReturn {
  // State
  backend: Backend;
  experiment: ExperimentState;
  formState: FormState;
  yamlString: string;
  yamlOverride: string | null;

  // Backend switching
  setBackend: (b: Backend) => void;

  // Section updaters
  updateExperiment: (partial: Partial<ExperimentState>) => void;

  // Sklearn
  sklearnData: SklearnDataState;
  sklearnModel: SklearnModelState;
  sklearnTraining: SklearnTrainingState;
  sklearnEvaluation: SklearnEvaluationState;
  updateSklearnData: (partial: Partial<SklearnDataState>) => void;
  updateSklearnModel: (partial: Partial<SklearnModelState>) => void;
  updateSklearnTraining: (partial: Partial<SklearnTrainingState>) => void;
  updateSklearnEvaluation: (partial: Partial<SklearnEvaluationState>) => void;

  // PyTorch
  pytorchData: PytorchDataState;
  pytorchModel: PytorchModelState;
  pytorchTraining: PytorchTrainingState;
  pytorchEvaluation: PytorchEvaluationState;
  updatePytorchData: (partial: Partial<PytorchDataState>) => void;
  updatePytorchModel: (partial: Partial<PytorchModelState>) => void;
  updatePytorchTraining: (partial: Partial<PytorchTrainingState>) => void;
  updatePytorchEvaluation: (partial: Partial<PytorchEvaluationState>) => void;

  // HuggingFace
  hfData: HuggingfaceDataState;
  hfModel: HuggingfaceModelState;
  hfTraining: HuggingfaceTrainingState;
  hfEvaluation: HuggingfaceEvaluationState;
  updateHfData: (partial: Partial<HuggingfaceDataState>) => void;
  updateHfModel: (partial: Partial<HuggingfaceModelState>) => void;
  updateHfTraining: (partial: Partial<HuggingfaceTrainingState>) => void;
  updateHfEvaluation: (partial: Partial<HuggingfaceEvaluationState>) => void;

  // Actions
  loadFromYaml: (yamlStr: string) => boolean;
  setYamlOverride: (yaml: string | null) => void;
  getSubmitYaml: () => string;
  reset: () => void;
}

export function useExperimentForm(): ExperimentFormReturn {
  const [backend, setBackendRaw] = useState<Backend>('sklearn');
  const [experiment, setExperiment] = useState<ExperimentState>({ ...DEFAULT_EXPERIMENT });

  // Sklearn state
  const [sklearnData, setSklearnData] = useState<SklearnDataState>({ ...DEFAULT_SKLEARN_DATA });
  const [sklearnModel, setSklearnModel] = useState<SklearnModelState>({
    ...DEFAULT_SKLEARN_MODEL,
    params: { ...DEFAULT_SKLEARN_MODEL.params },
  });
  const [sklearnTraining, setSklearnTraining] = useState<SklearnTrainingState>({ ...DEFAULT_SKLEARN_TRAINING });
  const [sklearnEvaluation, setSklearnEvaluation] = useState<SklearnEvaluationState>({
    ...DEFAULT_SKLEARN_EVALUATION,
    metrics: [...DEFAULT_SKLEARN_EVALUATION.metrics],
    plots: [...DEFAULT_SKLEARN_EVALUATION.plots],
  });

  // PyTorch state
  const [pytorchData, setPytorchData] = useState<PytorchDataState>({ ...DEFAULT_PYTORCH_DATA });
  const [pytorchModel, setPytorchModel] = useState<PytorchModelState>({
    ...DEFAULT_PYTORCH_MODEL,
    params: { ...DEFAULT_PYTORCH_MODEL.params },
  });
  const [pytorchTraining, setPytorchTraining] = useState<PytorchTrainingState>({ ...DEFAULT_PYTORCH_TRAINING });
  const [pytorchEvaluation, setPytorchEvaluation] = useState<PytorchEvaluationState>({
    ...DEFAULT_PYTORCH_EVALUATION,
    metrics: [...DEFAULT_PYTORCH_EVALUATION.metrics],
    plots: [...DEFAULT_PYTORCH_EVALUATION.plots],
  });

  // HuggingFace state
  const [hfData, setHfData] = useState<HuggingfaceDataState>({ ...DEFAULT_HF_DATA });
  const [hfModel, setHfModel] = useState<HuggingfaceModelState>({ ...DEFAULT_HF_MODEL });
  const [hfTraining, setHfTraining] = useState<HuggingfaceTrainingState>({ ...DEFAULT_HF_TRAINING });
  const [hfEvaluation, setHfEvaluation] = useState<HuggingfaceEvaluationState>({
    ...DEFAULT_HF_EVALUATION,
    metrics: [...DEFAULT_HF_EVALUATION.metrics],
  });

  // YAML override (when user edits raw YAML)
  const [yamlOverride, setYamlOverride] = useState<string | null>(null);

  // Build current form state as discriminated union
  const formState: FormState = useMemo(() => {
    switch (backend) {
      case 'sklearn':
        return { backend, experiment, data: sklearnData, model: sklearnModel, training: sklearnTraining, evaluation: sklearnEvaluation };
      case 'pytorch':
        return { backend, experiment, data: pytorchData, model: pytorchModel, training: pytorchTraining, evaluation: pytorchEvaluation };
      case 'huggingface':
        return { backend, experiment, data: hfData, model: hfModel, training: hfTraining, evaluation: hfEvaluation };
    }
  }, [backend, experiment, sklearnData, sklearnModel, sklearnTraining, sklearnEvaluation, pytorchData, pytorchModel, pytorchTraining, pytorchEvaluation, hfData, hfModel, hfTraining, hfEvaluation]);

  const yamlString = useMemo(() => formStateToYaml(formState), [formState]);

  // Partial updaters
  const updateExperiment = useCallback((partial: Partial<ExperimentState>) => {
    setExperiment((prev) => ({ ...prev, ...partial }));
    setYamlOverride(null);
  }, []);

  const makeUpdater = <T,>(setter: React.Dispatch<React.SetStateAction<T>>) =>
    (partial: Partial<T>) => {
      setter((prev) => ({ ...prev, ...partial }));
      setYamlOverride(null);
    };

  const updateSklearnData = useCallback(makeUpdater(setSklearnData), []);
  const updateSklearnModel = useCallback((partial: Partial<SklearnModelState>) => {
    setSklearnModel((prev) => {
      const next = { ...prev, ...partial };
      // When architecture changes, load default params
      if (partial.architecture && partial.architecture !== prev.architecture) {
        const info = SKLEARN_MODELS.find((m) => m.id === partial.architecture);
        next.params = info ? { ...info.defaultParams } : {};
      }
      return next;
    });
    setYamlOverride(null);
  }, []);
  const updateSklearnTraining = useCallback(makeUpdater(setSklearnTraining), []);
  const updateSklearnEvaluation = useCallback(makeUpdater(setSklearnEvaluation), []);

  const updatePytorchData = useCallback(makeUpdater(setPytorchData), []);
  const updatePytorchModel = useCallback(makeUpdater(setPytorchModel), []);
  const updatePytorchTraining = useCallback(makeUpdater(setPytorchTraining), []);
  const updatePytorchEvaluation = useCallback(makeUpdater(setPytorchEvaluation), []);

  const updateHfData = useCallback(makeUpdater(setHfData), []);
  const updateHfModel = useCallback(makeUpdater(setHfModel), []);
  const updateHfTraining = useCallback(makeUpdater(setHfTraining), []);
  const updateHfEvaluation = useCallback(makeUpdater(setHfEvaluation), []);

  const setBackend = useCallback((b: Backend) => {
    setBackendRaw(b);
    setYamlOverride(null);
  }, []);

  const loadFromYaml = useCallback((yamlStr: string): boolean => {
    const parsed = parseYamlToFormState(yamlStr);
    if (!parsed) return false;

    setExperiment(parsed.experiment);
    setBackendRaw(parsed.backend);
    setYamlOverride(null);

    switch (parsed.backend) {
      case 'sklearn':
        setSklearnData(parsed.data);
        setSklearnModel(parsed.model);
        setSklearnTraining(parsed.training);
        setSklearnEvaluation(parsed.evaluation);
        break;
      case 'pytorch':
        setPytorchData(parsed.data);
        setPytorchModel(parsed.model);
        setPytorchTraining(parsed.training);
        setPytorchEvaluation(parsed.evaluation);
        break;
      case 'huggingface':
        setHfData(parsed.data);
        setHfModel(parsed.model);
        setHfTraining(parsed.training);
        setHfEvaluation(parsed.evaluation);
        break;
    }
    return true;
  }, []);

  const getSubmitYaml = useCallback(() => {
    return yamlOverride ?? yamlString;
  }, [yamlOverride, yamlString]);

  const reset = useCallback(() => {
    setBackendRaw('sklearn');
    setExperiment({ ...DEFAULT_EXPERIMENT });
    setSklearnData({ ...DEFAULT_SKLEARN_DATA });
    setSklearnModel({ ...DEFAULT_SKLEARN_MODEL, params: { ...DEFAULT_SKLEARN_MODEL.params } });
    setSklearnTraining({ ...DEFAULT_SKLEARN_TRAINING });
    setSklearnEvaluation({ ...DEFAULT_SKLEARN_EVALUATION, metrics: [...DEFAULT_SKLEARN_EVALUATION.metrics], plots: [...DEFAULT_SKLEARN_EVALUATION.plots] });
    setPytorchData({ ...DEFAULT_PYTORCH_DATA });
    setPytorchModel({ ...DEFAULT_PYTORCH_MODEL, params: { ...DEFAULT_PYTORCH_MODEL.params } });
    setPytorchTraining({ ...DEFAULT_PYTORCH_TRAINING });
    setPytorchEvaluation({ ...DEFAULT_PYTORCH_EVALUATION, metrics: [...DEFAULT_PYTORCH_EVALUATION.metrics], plots: [...DEFAULT_PYTORCH_EVALUATION.plots] });
    setHfData({ ...DEFAULT_HF_DATA });
    setHfModel({ ...DEFAULT_HF_MODEL });
    setHfTraining({ ...DEFAULT_HF_TRAINING });
    setHfEvaluation({ ...DEFAULT_HF_EVALUATION, metrics: [...DEFAULT_HF_EVALUATION.metrics] });
    setYamlOverride(null);
  }, []);

  return {
    backend,
    experiment,
    formState,
    yamlString,
    yamlOverride,
    setBackend,
    updateExperiment,
    sklearnData, sklearnModel, sklearnTraining, sklearnEvaluation,
    updateSklearnData, updateSklearnModel, updateSklearnTraining, updateSklearnEvaluation,
    pytorchData, pytorchModel, pytorchTraining, pytorchEvaluation,
    updatePytorchData, updatePytorchModel, updatePytorchTraining, updatePytorchEvaluation,
    hfData, hfModel, hfTraining, hfEvaluation,
    updateHfData, updateHfModel, updateHfTraining, updateHfEvaluation,
    loadFromYaml,
    setYamlOverride,
    getSubmitYaml,
    reset,
  };
}
