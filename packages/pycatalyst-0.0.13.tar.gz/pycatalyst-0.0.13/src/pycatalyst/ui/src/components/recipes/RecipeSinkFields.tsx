'use client';

import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

export type RecipeSinkValue = {
  type: string;
  config: Record<string, unknown>;
};

const SINK_TYPES = [
  'memory',
  'file',
  'http',
  'database',
  'kafka',
  'rabbitmq',
] as const;

function numOrUndef(raw: string): number | undefined {
  const t = raw.trim();
  if (!t) return undefined;
  const n = Number(t);
  return Number.isFinite(n) ? n : undefined;
}

export function RecipeSinkFields({
  value,
  onChange,
  disabled,
}: {
  value: RecipeSinkValue;
  onChange: (v: RecipeSinkValue) => void;
  disabled?: boolean;
}) {
  const cfg = value.config;
  const setType = (type: string) => onChange({ type, config: {} });
  const patch = (p: Record<string, unknown>) =>
    onChange({ ...value, config: { ...value.config, ...p } });

  return (
    <div className="space-y-3 rounded-md border border-border p-3">
      <div className="space-y-1">
        <Label className="text-xs">Output sink</Label>
        <select
          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={value.type}
          onChange={(e) => setType(e.target.value)}
          disabled={disabled}
        >
          {SINK_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      {value.type === 'file' && (
        <div className="grid gap-2 sm:grid-cols-2">
          <div className="space-y-1 sm:col-span-2">
            <Label className="text-xs">Path (must be under system temp when using API)</Label>
            <Input
              className="font-mono text-sm"
              value={String(cfg.path ?? '')}
              onChange={(e) => patch({ path: e.target.value })}
              placeholder="/tmp/out.json"
              disabled={disabled}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">format</Label>
            <Input
              value={String(cfg.format ?? 'json')}
              onChange={(e) => patch({ format: e.target.value })}
              placeholder="json"
              disabled={disabled}
            />
          </div>
          <div className="flex items-end gap-2 pb-1">
            <label className="flex items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={Boolean(cfg.append)}
                onChange={(e) => patch({ append: e.target.checked })}
                disabled={disabled}
              />
              append
            </label>
          </div>
        </div>
      )}

      {value.type === 'http' && (
        <div className="grid gap-2">
          <div className="space-y-1">
            <Label className="text-xs">URL</Label>
            <Input
              className="font-mono text-sm"
              value={String(cfg.url ?? '')}
              onChange={(e) => patch({ url: e.target.value })}
              placeholder="https://api.example.com/v1/data"
              disabled={disabled}
            />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">Method</Label>
              <Input
                value={String(cfg.method ?? 'POST')}
                onChange={(e) => patch({ method: e.target.value })}
                disabled={disabled}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">batch_size</Label>
              <Input
                value={cfg.batch_size != null ? String(cfg.batch_size) : ''}
                onChange={(e) => {
                  const n = numOrUndef(e.target.value);
                  if (n === undefined) patch({ batch_size: 0 });
                  else patch({ batch_size: n });
                }}
                disabled={disabled}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">timeout</Label>
              <Input
                value={cfg.timeout != null ? String(cfg.timeout) : ''}
                onChange={(e) => {
                  const n = numOrUndef(e.target.value);
                  patch({ timeout: n ?? 30 });
                }}
                disabled={disabled}
              />
            </div>
          </div>
        </div>
      )}

      {value.type === 'database' && (
        <div className="grid gap-2">
          <div className="space-y-1">
            <Label className="text-xs">connection_url</Label>
            <Input
              className="font-mono text-sm"
              value={String(cfg.connection_url ?? '')}
              onChange={(e) => patch({ connection_url: e.target.value })}
              placeholder="sqlite:///data.db"
              disabled={disabled}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">table_name</Label>
            <Input
              className="font-mono text-sm"
              value={String(cfg.table_name ?? '')}
              onChange={(e) => patch({ table_name: e.target.value })}
              disabled={disabled}
            />
          </div>
        </div>
      )}

      {value.type === 'kafka' && (
        <div className="grid gap-2">
          <div className="space-y-1">
            <Label className="text-xs">bootstrap_servers</Label>
            <Input
              className="font-mono text-sm"
              value={String(cfg.bootstrap_servers ?? '')}
              onChange={(e) => patch({ bootstrap_servers: e.target.value })}
              placeholder="localhost:9092"
              disabled={disabled}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">topic</Label>
            <Input
              value={String(cfg.topic ?? '')}
              onChange={(e) => patch({ topic: e.target.value })}
              disabled={disabled}
            />
          </div>
        </div>
      )}

      {value.type === 'rabbitmq' && (
        <div className="grid gap-2">
          <div className="space-y-1">
            <Label className="text-xs">url</Label>
            <Input
              className="font-mono text-sm"
              value={String(cfg.url ?? '')}
              onChange={(e) => patch({ url: e.target.value })}
              placeholder="amqp://guest:guest@localhost/"
              disabled={disabled}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">exchange</Label>
              <Input
                value={String(cfg.exchange ?? '')}
                onChange={(e) => patch({ exchange: e.target.value })}
                disabled={disabled}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">routing_key</Label>
              <Input
                value={String(cfg.routing_key ?? '')}
                onChange={(e) => patch({ routing_key: e.target.value })}
                disabled={disabled}
              />
            </div>
          </div>
        </div>
      )}

      {value.type === 'memory' && (
        <p className="text-xs text-muted-foreground">
          Records are returned in the API response only.
        </p>
      )}
    </div>
  );
}
