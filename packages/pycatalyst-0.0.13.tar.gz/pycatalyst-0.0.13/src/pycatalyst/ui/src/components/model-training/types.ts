/** TypeScript interfaces for the experiment form state. */

export type Backend = 'sklearn' | 'pytorch' | 'huggingface';

// ── Experiment (shared) ──────────────────────────────────────────

export interface ExperimentState {
  name: string;
  seed: number;
  outputDir: string;
}

// ── Sklearn ──────────────────────────────────────────────────────

export type SklearnSplitStrategy = 'random' | 'temporal';
export type ScalerType = 'standard' | 'minmax' | 'robust' | 'none';
export type HandleMissing = 'drop' | 'mean' | 'median' | 'mode';

export interface SklearnDataState {
  source: 'local' | 's3';
  path: string;
  s3Uri: string;
  target: string;
  features: string;
  splitStrategy: SklearnSplitStrategy;
  trainRatio: number;
  valRatio: number;
  testRatio: number;
  scaler: ScalerType;
  handleMissing: HandleMissing;
}

export type SklearnArchitecture =
  | 'linear_regression'
  | 'ridge'
  | 'lasso'
  | 'decision_tree'
  | 'random_forest'
  | 'gradient_boosting'
  | 'adaboost'
  | 'svm'
  | 'knn'
  | 'hist_gradient_boosting';

export interface SklearnModelState {
  architecture: SklearnArchitecture;
  params: Record<string, number | string>;
}

export interface SklearnTrainingState {
  crossValidationEnabled: boolean;
  folds: number;
  scoring: string;
}

export interface SklearnEvaluationState {
  metrics: string[];
  plots: string[];
}

// ── PyTorch ──────────────────────────────────────────────────────

export type PytorchSplitStrategy = 'temporal' | 'holdout';
export type PytorchArchitecture = 'lstm' | 'gru' | 'tcn' | 'transformer' | 'mlp';
export type PytorchOptimizer = 'adam' | 'adamw' | 'sgd';
export type PytorchScheduler = 'cosine' | 'step' | 'plateau' | 'none';
export type EarlyStoppingMode = 'min' | 'max';

export interface PytorchDataState {
  source: 'local' | 's3';
  path: string;
  s3Uri: string;
  target: string;
  features: string;
  splitStrategy: PytorchSplitStrategy;
  trainRatio: number;
  valRatio: number;
  testRatio: number;
  scaler: ScalerType;
  sequenceLength: number;
  stride: number;
}

export interface PytorchModelState {
  architecture: PytorchArchitecture;
  params: Record<string, number | string>;
}

export interface PytorchTrainingState {
  epochs: number;
  batchSize: number;
  learningRate: number;
  optimizer: PytorchOptimizer;
  scheduler: PytorchScheduler;
  gradientClip: number;
  earlyStoppingEnabled: boolean;
  earlyStoppingPatience: number;
  earlyStoppingMetric: string;
  earlyStoppingMode: EarlyStoppingMode;
  checkpointEnabled: boolean;
}

export interface PytorchEvaluationState {
  metrics: string[];
  plots: string[];
}

// ── HuggingFace ──────────────────────────────────────────────────

export type HfDataFormat = 'instruction' | 'chat' | 'completion';
export type HfAdapter = 'lora' | 'qlora' | 'none';
export type HfQuantization = '4bit' | '8bit' | 'none';
export type HfMixedPrecision = 'bf16' | 'fp16';

export interface HuggingfaceDataState {
  source: 'local' | 's3';
  path: string;
  s3Uri: string;
  format: HfDataFormat;
  maxLength: number;
  valSplit: number;
}

export interface HuggingfaceModelState {
  baseModel: string;
  adapter: HfAdapter;
  quantization: HfQuantization;
  loraR: number;
  loraAlpha: number;
  loraDropout: number;
  targetModules: string;
}

export interface HuggingfaceTrainingState {
  epochs: number;
  batchSize: number;
  gradientAccumulationSteps: number;
  learningRate: number;
  warmupRatio: number;
  mixedPrecision: HfMixedPrecision;
  maxGradNorm: number;
}

export interface HuggingfaceEvaluationState {
  metrics: string[];
}

// ── Discriminated union ──────────────────────────────────────────

export interface SklearnFormState {
  backend: 'sklearn';
  experiment: ExperimentState;
  data: SklearnDataState;
  model: SklearnModelState;
  training: SklearnTrainingState;
  evaluation: SklearnEvaluationState;
}

export interface PytorchFormState {
  backend: 'pytorch';
  experiment: ExperimentState;
  data: PytorchDataState;
  model: PytorchModelState;
  training: PytorchTrainingState;
  evaluation: PytorchEvaluationState;
}

export interface HuggingfaceFormState {
  backend: 'huggingface';
  experiment: ExperimentState;
  data: HuggingfaceDataState;
  model: HuggingfaceModelState;
  training: HuggingfaceTrainingState;
  evaluation: HuggingfaceEvaluationState;
}

export type FormState = SklearnFormState | PytorchFormState | HuggingfaceFormState;

// ── Section update callbacks ─────────────────────────────────────

export type UpdateFn<T> = (updater: Partial<T> | ((prev: T) => T)) => void;
