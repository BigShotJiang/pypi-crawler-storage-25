'use client';

import { useAuthInit } from '@/hooks/use-auth-init';
import { AuthGuard } from '@/components/layout/AuthGuard';
import { Navigation } from '@/components/layout/Navigation';
import { ApiUnavailableBanner } from '@/components/layout/ApiUnavailableBanner';

export function AppShell({ children }: { children: React.ReactNode }) {
  useAuthInit();

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <ApiUnavailableBanner />
      <main className="flex-1 flex flex-col min-h-0 overflow-hidden relative">
        <AuthGuard>{children}</AuthGuard>
      </main>
    </div>
  );
}
