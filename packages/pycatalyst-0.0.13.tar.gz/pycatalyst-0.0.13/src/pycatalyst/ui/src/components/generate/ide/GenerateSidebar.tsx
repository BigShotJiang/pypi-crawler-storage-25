'use client';

import { Layers, BookOpen, Database } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SidebarHeaderWithToggle } from '@/components/layout/SidebarHeaderWithToggle';
import type { SidebarLayoutApi } from '@/components/layout/ResizableWorkspaceLayout';
import {
  useGenerateWorkspaceStore,
  selectSidebarTab,
  selectSchemaSource,
  type SidebarTab,
} from '@/stores/generate-workspace';
import { SchemaSourceSelector } from './SchemaSourceSelector';
import { SinkConfigPanel } from './SinkConfigPanel';
import { RecipeTemplateBrowser } from './RecipeTemplateBrowser';
import {
  BuildSchemaContent,
  InferSchemaContent,
  JsonSchemaContent,
  RecipeYamlContent,
} from './SidebarSchemaContent';

/** Tab metadata for the sidebar navigation. */
const TABS: { id: SidebarTab; label: string; icon: typeof Layers }[] = [
  { id: 'schema', label: 'Schema', icon: Layers },
  { id: 'templates', label: 'Templates', icon: BookOpen },
  { id: 'sinks', label: 'Sinks', icon: Database },
];

/**
 * Left sidebar for the Generate IDE workspace.
 *
 * Three tabs (Schema, Templates, Sinks) driven by the workspace store.
 * When collapsed, shows icon buttons that expand and activate the tab.
 */
export function GenerateSidebar({
  isPanelCollapsed,
  sidebarDisplayMode,
  onCollapseRequested,
  onExpandRequested,
}: SidebarLayoutApi) {
  const sidebarTab = useGenerateWorkspaceStore(selectSidebarTab);
  const setSidebarTab = useGenerateWorkspaceStore((s) => s.setSidebarTab);

  const handleToggle = isPanelCollapsed
    ? onExpandRequested
    : onCollapseRequested;

  /** Expand sidebar and switch to the given tab. */
  const activateTab = (tab: SidebarTab) => {
    if (isPanelCollapsed) {
      onExpandRequested();
    }
    setSidebarTab(tab);
  };

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header with tab selectors or collapse toggle */}
      <SidebarHeaderWithToggle
        isCollapsed={isPanelCollapsed}
        displayMode={sidebarDisplayMode}
        onToggle={handleToggle}
      >
        <div className="flex items-center gap-1">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setSidebarTab(id)}
              className={cn(
                'flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors',
                sidebarTab === id
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
              )}
              aria-pressed={sidebarTab === id}
            >
              <Icon className="h-3.5 w-3.5" />
              {sidebarDisplayMode === 'expanded' && label}
            </button>
          ))}
        </div>
      </SidebarHeaderWithToggle>

      {/* Collapsed: icon rail */}
      {isPanelCollapsed && (
        <div className="flex flex-col items-center gap-2 py-3">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => activateTab(id)}
              className={cn(
                'p-2 rounded-md transition-colors',
                sidebarTab === id
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
              )}
              title={label}
              aria-label={`Open ${label} tab`}
            >
              <Icon className="h-5 w-5" />
            </button>
          ))}
        </div>
      )}

      {/* Expanded: tab content */}
      {!isPanelCollapsed && (
        <div className="flex-1 min-h-0 overflow-y-auto">
          {sidebarTab === 'schema' && <SchemaTabContent />}
          {sidebarTab === 'templates' && <RecipeTemplateBrowser />}
          {sidebarTab === 'sinks' && <SinkConfigPanel />}
        </div>
      )}
    </div>
  );
}

// ── Schema tab content ─────────────────────────────────────

/**
 * Schema tab: source selector + placeholder content per mode.
 *
 * Actual tab components (BuildSchemaTab, InferSchemaTab, etc.)
 * will be wired in later; for now each mode shows a placeholder.
 */
function SchemaTabContent() {
  const schemaSource = useGenerateWorkspaceStore(selectSchemaSource);

  return (
    <div className="flex flex-col">
      <SchemaSourceSelector />

      <div className="px-1">
        {schemaSource === 'build' && <BuildSchemaContent />}
        {schemaSource === 'infer' && <InferSchemaContent />}
        {schemaSource === 'json-schema' && <JsonSchemaContent />}
        {schemaSource === 'recipe' && <RecipeYamlContent />}
      </div>
    </div>
  );
}
