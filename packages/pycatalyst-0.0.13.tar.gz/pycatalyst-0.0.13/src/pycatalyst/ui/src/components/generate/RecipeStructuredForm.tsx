'use client';

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import {
  RecipeSinkFields,
  type RecipeSinkValue,
} from '@/components/recipes/RecipeSinkFields';
import {
  FIELD_TYPES,
  newField,
  fieldRowsToGenerateFields,
  type FieldRow,
} from '@/components/generate/generate-utils';
import type { RecipeDraft } from '@/lib/recipe-draft';
import {
  flatSchemaFields,
  nestedSchemaFields,
  hasNestedSchemaFields,
  generateFieldsToFieldRows,
} from '@/lib/recipe-draft';
import type { RecipeSinkMode } from '@/stores/app-config';
import { Plus, Trash2, AlertCircle, FileText, Layers, Sliders, Database } from 'lucide-react';

export type RecipeStructuredFormProps = {
  draft: RecipeDraft;
  onDraftChange: (d: RecipeDraft) => void;
  /** Increment when YAML/template load should reset field rows from draft. */
  syncRevision: number;
  disabled?: boolean;
  recipeSinkMode: RecipeSinkMode;
};

export function RecipeStructuredForm({
  draft,
  onDraftChange,
  syncRevision,
  disabled,
  recipeSinkMode,
}: RecipeStructuredFormProps) {
  const [fieldRows, setFieldRows] = useState<FieldRow[]>([newField()]);
  const [structTab, setStructTab] = useState('meta');

  useEffect(() => {
    const flat = flatSchemaFields(draft.fields);
    setFieldRows(
      flat.length > 0 ? generateFieldsToFieldRows(flat) : [newField()],
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps -- only re-seed rows on YAML/template sync
  }, [syncRevision]);

  const mergeFieldsFromRows = useCallback(
    (rows: FieldRow[]) => {
      const nested = nestedSchemaFields(draft.fields);
      const flat = fieldRowsToGenerateFields(rows);
      onDraftChange({ ...draft, fields: [...nested, ...flat] });
    },
    [draft, onDraftChange],
  );

  const updateField = (id: number, patch: Partial<FieldRow>) => {
    const next = fieldRows.map((f) => (f.id === id ? { ...f, ...patch } : f));
    setFieldRows(next);
    mergeFieldsFromRows(next);
  };

  const addField = () => {
    const next = [...fieldRows, newField()];
    setFieldRows(next);
    mergeFieldsFromRows(next);
  };

  const removeField = (id: number) => {
    if (fieldRows.length <= 1) return;
    const next = fieldRows.filter((f) => f.id !== id);
    setFieldRows(next);
    mergeFieldsFromRows(next);
  };

  const nested = nestedSchemaFields(draft.fields);
  const nestedWarning = hasNestedSchemaFields(draft.fields);

  return (
    <div className="space-y-4">
      <Tabs value={structTab} onValueChange={setStructTab}>
        <TabsList className="flex flex-wrap h-auto gap-1 p-1">
          <TabsTrigger value="meta" className="text-xs gap-1">
            <FileText className="h-3 w-3" />
            Meta
          </TabsTrigger>
          <TabsTrigger value="schema" className="text-xs gap-1">
            <Layers className="h-3 w-3" />
            Schema
          </TabsTrigger>
          <TabsTrigger value="generation" className="text-xs gap-1">
            <Sliders className="h-3 w-3" />
            Generation
          </TabsTrigger>
          <TabsTrigger value="sink" className="text-xs gap-1">
            <Database className="h-3 w-3" />
            Sink
          </TabsTrigger>
        </TabsList>

        <TabsContent value="meta" className="mt-4 space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                value={draft.name}
                onChange={(e) =>
                  onDraftChange({ ...draft, name: e.target.value })
                }
                disabled={disabled}
                placeholder="recipe"
              />
            </div>
            <div className="space-y-2">
              <Label>Version</Label>
              <Input
                value={draft.version}
                onChange={(e) =>
                  onDraftChange({ ...draft, version: e.target.value })
                }
                disabled={disabled}
                placeholder="1.0"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Input
              value={draft.description}
              onChange={(e) =>
                onDraftChange({ ...draft, description: e.target.value })
              }
              disabled={disabled}
              placeholder="Optional"
            />
          </div>
        </TabsContent>

        <TabsContent value="schema" className="mt-4 space-y-4">
          {nestedWarning && (
            <Alert variant="default" className="border-amber-500/40">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-xs">
                This recipe includes nested schema fields (object/array children) that
                are not editable in the table below. Edit them in the Source (YAML) tab.
                Nested fields are preserved when you use the structured editor for flat
                fields only.
                {nested.length > 0 && (
                  <span className="block mt-1 font-mono text-[10px]">
                    {nested.map((f) => f.name).join(', ')}
                  </span>
                )}
              </AlertDescription>
            </Alert>
          )}
          <div className="flex items-center justify-between">
            <Label>Fields (flat)</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addField}
              disabled={disabled}
            >
              <Plus className="h-4 w-4 mr-1" /> Add field
            </Button>
          </div>
          <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
            {fieldRows.map((field) => (
              <div key={field.id} className="border rounded-md p-3 space-y-2">
                <div className="flex gap-2 items-end">
                  <div className="flex-1 space-y-1">
                    <Label className="text-xs">Name</Label>
                    <Input
                      value={field.name}
                      onChange={(e) =>
                        updateField(field.id, { name: e.target.value })
                      }
                      placeholder="field_name"
                      disabled={disabled}
                    />
                  </div>
                  <div className="w-32 space-y-1">
                    <Label className="text-xs">Type</Label>
                    <select
                      value={field.type}
                      onChange={(e) =>
                        updateField(field.id, { type: e.target.value })
                      }
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      disabled={disabled}
                    >
                      {FIELD_TYPES.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-2 pb-1">
                    <Switch
                      checked={field.nullable}
                      onCheckedChange={(checked) =>
                        updateField(field.id, { nullable: checked })
                      }
                      disabled={disabled}
                    />
                    <span className="text-xs text-muted-foreground">Null</span>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeField(field.id)}
                    disabled={disabled || fieldRows.length <= 1}
                    className="shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {(field.type === 'int' || field.type === 'float') && (
                  <div className="flex gap-2">
                    <div className="flex-1 space-y-1">
                      <Label className="text-xs">Min</Label>
                      <Input
                        type="number"
                        value={field.constraintMin}
                        onChange={(e) =>
                          updateField(field.id, { constraintMin: e.target.value })
                        }
                        disabled={disabled}
                      />
                    </div>
                    <div className="flex-1 space-y-1">
                      <Label className="text-xs">Max</Label>
                      <Input
                        type="number"
                        value={field.constraintMax}
                        onChange={(e) =>
                          updateField(field.id, { constraintMax: e.target.value })
                        }
                        disabled={disabled}
                      />
                    </div>
                  </div>
                )}
                {field.type === 'enum' && (
                  <div className="space-y-1">
                    <Label className="text-xs">Choices (comma-separated)</Label>
                    <Input
                      value={field.constraintChoices}
                      onChange={(e) =>
                        updateField(field.id, { constraintChoices: e.target.value })
                      }
                      disabled={disabled}
                    />
                  </div>
                )}
                {field.type === 'string' && (
                  <div className="space-y-1">
                    <Label className="text-xs">Pattern (regex, optional)</Label>
                    <Input
                      value={field.constraintPattern}
                      onChange={(e) =>
                        updateField(field.id, { constraintPattern: e.target.value })
                      }
                      disabled={disabled}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="generation" className="mt-4 space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Count</Label>
              <Input
                type="number"
                min={1}
                max={100000}
                value={draft.generation.count}
                onChange={(e) =>
                  onDraftChange({
                    ...draft,
                    generation: {
                      ...draft.generation,
                      count: Number(e.target.value) || 1,
                    },
                  })
                }
                disabled={disabled}
              />
            </div>
            <div className="space-y-2">
              <Label>Seed (optional)</Label>
              <Input
                value={
                  draft.generation.seed !== undefined
                    ? String(draft.generation.seed)
                    : ''
                }
                onChange={(e) => {
                  const t = e.target.value.trim();
                  onDraftChange({
                    ...draft,
                    generation: {
                      ...draft.generation,
                      seed: t === '' ? undefined : Number(t),
                    },
                  });
                }}
                disabled={disabled}
                placeholder="e.g. 42"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="sink" className="mt-4 space-y-4">
          {recipeSinkMode === 'memory' && (
            <p className="text-xs text-muted-foreground rounded-md border border-dashed border-border px-3 py-2">
              Server uses an in-memory sink unless{' '}
              <code className="text-[10px]">PYCATALYST_RECIPE_SINK_MODE=full</code> is
              set. You can still edit the sink below for YAML export; the API will
              override when not in full mode.
            </p>
          )}
          <RecipeSinkFields
            value={draft.sink}
            onChange={(sink: RecipeSinkValue) =>
              onDraftChange({ ...draft, sink })
            }
            disabled={disabled}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
