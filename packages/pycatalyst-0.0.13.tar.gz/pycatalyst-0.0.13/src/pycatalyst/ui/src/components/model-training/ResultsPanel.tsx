/** Enhanced results display with metric cards, training charts, and artifacts. */

'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { RotateCcw, Clock, Cpu, FileText } from 'lucide-react';
import type { MlRunResponse } from '@/lib/types';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface ResultsPanelProps {
  result: MlRunResponse | null;
  onRunAgain: () => void;
}

export function ResultsPanel({ result, onRunAgain }: ResultsPanelProps) {
  if (!result) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-muted-foreground">No run yet. Use Run experiment to submit a config.</p>
        </CardContent>
      </Card>
    );
  }

  const metrics = Object.entries(result.metrics);
  const artifacts = Object.entries(result.artifacts);
  const history = result.training_history;

  // Detect chart columns from training history
  const chartKeys = history.length > 0
    ? Object.keys(history[0]).filter((k) => k !== 'epoch' && typeof history[0][k as keyof typeof history[0]] === 'number')
    : [];

  const CHART_COLORS = ['hsl(var(--primary))', 'hsl(var(--destructive))', '#22c55e', '#f59e0b'];

  return (
    <div className="space-y-4">
      {/* Run metadata header */}
      <Card>
        <CardContent className="py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="font-semibold">{result.name}</span>
            </div>
            <Badge variant="secondary">
              <Cpu className="h-3 w-3 mr-1" />
              {result.backend}
            </Badge>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              {result.duration_seconds.toFixed(2)}s
            </div>
            {result.persisted_model_id && (
              <Badge variant="outline">
                Saved: {result.persisted_artifact_count} artifact(s)
              </Badge>
            )}
            <div className="ml-auto">
              <Button variant="outline" size="sm" onClick={onRunAgain}>
                <RotateCcw className="mr-2 h-3.5 w-3.5" />
                Run again
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Metric cards */}
      {metrics.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-muted-foreground mb-3">Metrics</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {metrics.map(([name, value]) => (
              <Card key={name}>
                <CardContent className="py-3 px-4 text-center">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">{name}</p>
                  <p className="text-xl font-bold mt-1">
                    {typeof value === 'number' ? formatMetric(value) : String(value)}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Training history chart */}
      {history.length > 1 && chartKeys.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Training History</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="epoch"
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <Legend />
                {chartKeys.map((key, i) => (
                  <Line
                    key={key}
                    type="monotone"
                    dataKey={key}
                    stroke={CHART_COLORS[i % CHART_COLORS.length]}
                    strokeWidth={2}
                    dot={false}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Artifacts */}
      {artifacts.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Artifacts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {artifacts.map(([name, path]) => (
                <div key={name} className="flex items-center gap-3 py-1.5">
                  <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{name}</p>
                    <p className="text-xs text-muted-foreground truncate">{path}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Raw training history (fallback if no chart) */}
      {history.length > 0 && chartKeys.length === 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Training History</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-3 rounded-md overflow-x-auto text-xs max-h-48">
              {JSON.stringify(history, null, 2)}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function formatMetric(value: number): string {
  if (Math.abs(value) < 0.001 && value !== 0) {
    return value.toExponential(3);
  }
  if (Math.abs(value) >= 1000) {
    return value.toFixed(1);
  }
  return value.toFixed(4);
}
