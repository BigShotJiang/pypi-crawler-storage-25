'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  X,
  Download,
  Trash2,
  RefreshCw,
  Search,
  Loader2,
  Package,
} from 'lucide-react';
import {
  listPackages,
  uninstallPackages,
  type PackageInfo,
} from '@/lib/workbench';

interface PackagePanelProps {
  open: boolean;
  envId: string;
  onClose: () => void;
  onInstallClick: () => void;
  packages: PackageInfo[];
  onPackagesChange: (packages: PackageInfo[]) => void;
}

export function PackagePanel({
  open,
  envId,
  onClose,
  onInstallClick,
  packages,
  onPackagesChange,
}: PackagePanelProps) {
  const [filter, setFilter] = useState('');
  const [loading, setLoading] = useState(false);
  const [uninstalling, setUninstalling] = useState<string | null>(null);

  useEffect(() => {
    if (open && envId) {
      refreshPackages();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, envId]);

  const refreshPackages = async () => {
    setLoading(true);
    try {
      const pkgs = await listPackages(envId);
      onPackagesChange(pkgs);
    } catch {
      // Refresh failed
    } finally {
      setLoading(false);
    }
  };

  const handleUninstall = async (name: string) => {
    setUninstalling(name);
    try {
      const result = await uninstallPackages(envId, [name]);
      onPackagesChange(result.packages);
    } catch {
      // Uninstall failed
    } finally {
      setUninstalling(null);
    }
  };

  if (!open) return null;

  const filtered = filter
    ? packages.filter((p) =>
        p.name.toLowerCase().includes(filter.toLowerCase()),
      )
    : packages;

  return (
    <div className="absolute right-0 top-0 bottom-0 w-80 bg-background border-l z-40 flex flex-col shadow-lg">
      <div className="flex items-center justify-between px-3 py-2 border-b">
        <div className="flex items-center gap-2">
          <Package className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Packages</span>
          <span className="text-xs text-muted-foreground">
            ({packages.length})
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshPackages}
            disabled={loading}
            className="h-7 w-7 p-0"
            title="Refresh"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-7 w-7 p-0"
          >
            <X className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      <div className="px-3 py-2 border-b">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder="Filter packages..."
              className="h-7 text-xs pl-7"
            />
          </div>
          <Button size="sm" className="h-7" onClick={onInstallClick}>
            <Download className="h-3.5 w-3.5 mr-1" />
            Install
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        {loading && packages.length === 0 && (
          <div className="flex items-center justify-center py-8 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        )}

        {!loading && packages.length === 0 && (
          <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
            <Package className="h-8 w-8 mb-2 opacity-30" />
            <p className="text-xs">No packages installed</p>
          </div>
        )}

        {filtered.map((pkg) => (
          <div
            key={pkg.name}
            className="flex items-center justify-between px-3 py-1.5 hover:bg-muted/50 group"
          >
            <div className="min-w-0 flex-1">
              <span className="text-xs font-mono truncate block">{pkg.name}</span>
              <span className="text-[10px] text-muted-foreground">{pkg.version}</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleUninstall(pkg.name)}
              disabled={uninstalling === pkg.name}
              className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
              title={`Uninstall ${pkg.name}`}
            >
              {uninstalling === pkg.name ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : (
                <Trash2 className="h-3 w-3" />
              )}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
