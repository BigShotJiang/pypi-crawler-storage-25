/** YAML template strings for experiment presets. */

export interface TemplateItem {
  id: string;
  name: string;
  filename: string;
  content: string;
}

export type TemplateKind = 'sklearn' | 'pytorch' | 'huggingface';

// ── Sklearn templates ────────────────────────────────────────────

const TEMPLATE_SKLEARN = `# Sklearn experiment template
# Edit data.path and data.target, then paste into Run experiment and run.

experiment:
  name: my-sklearn-experiment
  backend: sklearn
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/data.csv
  target: target_column_name
  split:
    strategy: random
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: standard
  handle_missing: drop

model:
  architecture: RandomForestRegressor
  params: {}

training:
  cross_validation:
    enabled: false
    folds: 5
    scoring: neg_mean_squared_error

evaluation:
  metrics: [mse, mae, r2]
  plots: [predicted_vs_actual]
`;

const TEMPLATE_SKLEARN_TEMPORAL = `# Sklearn — temporal split
# For time-ordered data. Edit data.path and data.target.

experiment:
  name: my-sklearn-temporal
  backend: sklearn
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/data.csv
  target: target_column_name
  split:
    strategy: temporal
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: standard
  handle_missing: drop

model:
  architecture: RandomForestRegressor
  params: {}

training:
  cross_validation:
    enabled: false
    folds: 5
    scoring: neg_mean_squared_error

evaluation:
  metrics: [mse, mae, r2]
  plots: [predicted_vs_actual]
`;

const TEMPLATE_SKLEARN_CROSS_VAL = `# Sklearn — with cross-validation
# Enable cross_validation for robust metrics. Edit data.path and data.target.

experiment:
  name: my-sklearn-cv
  backend: sklearn
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/data.csv
  target: target_column_name
  split:
    strategy: random
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: standard
  handle_missing: drop

model:
  architecture: RandomForestRegressor
  params: {}

training:
  cross_validation:
    enabled: true
    folds: 5
    scoring: neg_mean_squared_error

evaluation:
  metrics: [mse, mae, r2]
  plots: [predicted_vs_actual]
`;

const TEMPLATE_SKLEARN_RIDGE = `# Sklearn — Ridge regression
# Linear model with L2 regularization. Edit data.path and data.target.

experiment:
  name: my-sklearn-ridge
  backend: sklearn
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/data.csv
  target: target_column_name
  split:
    strategy: random
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: standard
  handle_missing: drop

model:
  architecture: Ridge
  params:
    alpha: 1.0

training:
  cross_validation:
    enabled: false
    folds: 5
    scoring: neg_mean_squared_error

evaluation:
  metrics: [mse, mae, r2]
  plots: [predicted_vs_actual]
`;

// ── PyTorch templates ────────────────────────────────────────────

const TEMPLATE_PYTORCH = `# PyTorch training template
# Edit data.path and data.target, then paste into Run experiment and run.

experiment:
  name: my-pytorch-experiment
  backend: pytorch
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/data.csv
  target: target_column_name
  split:
    strategy: temporal
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: minmax
  sequence_length: 60
  stride: 1

model:
  architecture: MLPRegressor
  params:
    hidden_sizes: [64, 32]
    dropout: 0.1

training:
  epochs: 10
  batch_size: 32
  learning_rate: 0.001
  early_stopping:
    patience: 5
    metric: val_loss
    mode: min

evaluation:
  metrics: [mse, mae]
  plots: [predicted_vs_actual]
`;

const TEMPLATE_PYTORCH_SCHEDULER = `# PyTorch — with learning rate scheduler
# Uses cosine annealing. Edit data.path and data.target.

experiment:
  name: my-pytorch-scheduler
  backend: pytorch
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/data.csv
  target: target_column_name
  split:
    strategy: temporal
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: minmax
  sequence_length: 60
  stride: 1

model:
  architecture: MLPRegressor
  params:
    hidden_sizes: [64, 32]
    dropout: 0.1

training:
  epochs: 20
  batch_size: 32
  learning_rate: 0.001
  optimizer: adam
  scheduler: cosine
  early_stopping:
    patience: 5
    metric: val_loss
    mode: min

evaluation:
  metrics: [mse, mae]
  plots: [predicted_vs_actual, loss_curves]
`;

const TEMPLATE_PYTORCH_HOLDOUT = `# PyTorch — holdout split
# For holdout strategy. Edit data.path and data.target.

experiment:
  name: my-pytorch-holdout
  backend: pytorch
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/data.csv
  target: target_column_name
  split:
    strategy: holdout
    train: 0.7
    val: 0.15
    test: 0.15
  scaler: minmax
  sequence_length: 60
  stride: 1

model:
  architecture: MLPRegressor
  params:
    hidden_sizes: [64, 32]
    dropout: 0.1

training:
  epochs: 10
  batch_size: 32
  learning_rate: 0.001
  early_stopping:
    patience: 5
    metric: val_loss
    mode: min

evaluation:
  metrics: [mse, mae]
  plots: [predicted_vs_actual]
`;

// ── HuggingFace templates ────────────────────────────────────────

const TEMPLATE_HUGGINGFACE = `# Hugging Face LLM fine-tuning template
# Edit data.path and model.base_model, then paste into Run experiment and run.

experiment:
  name: my-huggingface-experiment
  backend: huggingface
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/instruction_data.json
  format: instruction
  max_length: 512
  val_split: 0.1

model:
  base_model: meta-llama/Llama-2-7b-hf
  adapter: lora
  params:
    r: 16
    lora_alpha: 32
    lora_dropout: 0.05
    target_modules: [q_proj, v_proj]

training:
  epochs: 3
  batch_size: 4
  gradient_accumulation_steps: 4
  learning_rate: 0.0002
  warmup_ratio: 0.03
  mixed_precision: bf16
  max_grad_norm: 1.0

evaluation:
  metrics: [eval_loss, perplexity]
`;

const TEMPLATE_HUGGINGFACE_QLORA = `# Hugging Face — QLoRA (quantized LoRA)
# Memory-efficient fine-tuning with 4-bit quantization. Edit data.path and model.base_model.

experiment:
  name: my-huggingface-qlora
  backend: huggingface
  seed: 42
  output_dir: ./runs/experiment

data:
  path: /path/to/your/instruction_data.json
  format: instruction
  max_length: 512
  val_split: 0.1

model:
  base_model: meta-llama/Llama-2-7b-hf
  adapter: qlora
  quantization: 4bit
  params:
    r: 16
    lora_alpha: 32
    lora_dropout: 0.05
    target_modules: [q_proj, v_proj]

training:
  epochs: 3
  batch_size: 4
  gradient_accumulation_steps: 4
  learning_rate: 0.0002
  warmup_ratio: 0.03
  mixed_precision: bf16
  max_grad_norm: 1.0

evaluation:
  metrics: [eval_loss, perplexity]
`;

// ── Exports ──────────────────────────────────────────────────────

export const SKLEARN_TEMPLATES: TemplateItem[] = [
  { id: 'sklearn-minimal', name: 'Sklearn — minimal', filename: 'sklearn-minimal.yaml', content: TEMPLATE_SKLEARN },
  { id: 'sklearn-temporal', name: 'Sklearn — temporal split', filename: 'sklearn-temporal-split.yaml', content: TEMPLATE_SKLEARN_TEMPORAL },
  { id: 'sklearn-cross-val', name: 'Sklearn — cross-validation', filename: 'sklearn-cross-validation.yaml', content: TEMPLATE_SKLEARN_CROSS_VAL },
  { id: 'sklearn-ridge', name: 'Sklearn — Ridge regression', filename: 'sklearn-ridge.yaml', content: TEMPLATE_SKLEARN_RIDGE },
];

export const PYTORCH_TEMPLATES: TemplateItem[] = [
  { id: 'pytorch-minimal', name: 'PyTorch — minimal', filename: 'pytorch-minimal.yaml', content: TEMPLATE_PYTORCH },
  { id: 'pytorch-scheduler', name: 'PyTorch — with scheduler', filename: 'pytorch-with-scheduler.yaml', content: TEMPLATE_PYTORCH_SCHEDULER },
  { id: 'pytorch-holdout', name: 'PyTorch — holdout split', filename: 'pytorch-holdout.yaml', content: TEMPLATE_PYTORCH_HOLDOUT },
];

export const HUGGINGFACE_TEMPLATES: TemplateItem[] = [
  { id: 'huggingface-lora', name: 'Hugging Face — LoRA', filename: 'huggingface-lora.yaml', content: TEMPLATE_HUGGINGFACE },
  { id: 'huggingface-qlora', name: 'Hugging Face — QLoRA', filename: 'huggingface-qlora.yaml', content: TEMPLATE_HUGGINGFACE_QLORA },
];

export const TEMPLATE_SETS: Record<TemplateKind, TemplateItem[]> = {
  sklearn: SKLEARN_TEMPLATES,
  pytorch: PYTORCH_TEMPLATES,
  huggingface: HUGGINGFACE_TEMPLATES,
};

export const ALL_TEMPLATE_OPTIONS: TemplateItem[] = [
  ...SKLEARN_TEMPLATES,
  ...PYTORCH_TEMPLATES,
  ...HUGGINGFACE_TEMPLATES,
];
