/** Data configuration section with backend-specific fields. */

'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import type { Backend, SklearnDataState, PytorchDataState, HuggingfaceDataState } from './types';
import { HelpTip } from './HelpTip';
import {
  SKLEARN_SPLIT_OPTIONS,
  PYTORCH_SPLIT_OPTIONS,
  SCALER_OPTIONS,
  MISSING_OPTIONS,
  HF_FORMAT_OPTIONS,
} from './constants';

const DATA_SOURCE_OPTIONS = [
  { value: 'local', label: 'Local path' },
  { value: 's3', label: 'S3 URI' },
] as const;

// ── Sklearn Data ─────────────────────────────────────────────────

interface SklearnDataProps {
  value: SklearnDataState;
  onChange: (partial: Partial<SklearnDataState>) => void;
}

function SklearnData({ value, onChange }: SklearnDataProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Data source</Label>
          <Select value={value.source} onValueChange={(v) => onChange({ source: v as SklearnDataState['source'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {DATA_SOURCE_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Data path
            <HelpTip text={value.source === 's3' ? 'S3 URI (e.g. s3://bucket/path/data.csv)' : 'Path to CSV data file'} />
          </Label>
          <Input
            value={value.source === 's3' ? value.s3Uri : value.path}
            onChange={(e) => onChange(value.source === 's3' ? { s3Uri: e.target.value } : { path: e.target.value })}
            placeholder={value.source === 's3' ? 's3://my-bucket/path/to/data.csv' : '/path/to/data.csv'}
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>
            Target column
            <HelpTip text="Column name to predict" />
          </Label>
          <Input value={value.target} onChange={(e) => onChange({ target: e.target.value })} placeholder="target_column" />
        </div>
      </div>
      <div className="space-y-2">
        <Label>
          Features
          <HelpTip text="Comma-separated feature column names (leave empty for all)" />
        </Label>
        <Input value={value.features} onChange={(e) => onChange({ features: e.target.value })} placeholder="col1, col2, col3 (optional)" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="space-y-2">
          <Label>Split strategy</Label>
          <Select value={value.splitStrategy} onValueChange={(v) => onChange({ splitStrategy: v as SklearnDataState['splitStrategy'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {SKLEARN_SPLIT_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Scaler
            <HelpTip text="Feature scaling method" />
          </Label>
          <Select value={value.scaler} onValueChange={(v) => onChange({ scaler: v as SklearnDataState['scaler'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {SCALER_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Missing values
            <HelpTip text="Strategy for handling missing data" />
          </Label>
          <Select value={value.handleMissing} onValueChange={(v) => onChange({ handleMissing: v as SklearnDataState['handleMissing'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {MISSING_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Train ratio</Label>
          <Input type="number" step={0.05} min={0} max={1} value={value.trainRatio} onChange={(e) => onChange({ trainRatio: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>Val ratio</Label>
          <Input type="number" step={0.05} min={0} max={1} value={value.valRatio} onChange={(e) => onChange({ valRatio: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>Test ratio</Label>
          <Input type="number" step={0.05} min={0} max={1} value={value.testRatio} onChange={(e) => onChange({ testRatio: Number(e.target.value) })} />
        </div>
      </div>
      <SplitWarning train={value.trainRatio} val={value.valRatio} test={value.testRatio} />
    </div>
  );
}

// ── PyTorch Data ─────────────────────────────────────────────────

interface PytorchDataProps {
  value: PytorchDataState;
  onChange: (partial: Partial<PytorchDataState>) => void;
}

function PytorchData({ value, onChange }: PytorchDataProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Data source</Label>
          <Select value={value.source} onValueChange={(v) => onChange({ source: v as PytorchDataState['source'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {DATA_SOURCE_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Data path
            <HelpTip text={value.source === 's3' ? 'S3 URI (e.g. s3://bucket/path/data.csv)' : 'Path to CSV data file'} />
          </Label>
          <Input
            value={value.source === 's3' ? value.s3Uri : value.path}
            onChange={(e) => onChange(value.source === 's3' ? { s3Uri: e.target.value } : { path: e.target.value })}
            placeholder={value.source === 's3' ? 's3://my-bucket/path/to/data.csv' : '/path/to/data.csv'}
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>
            Target column
            <HelpTip text="Column name to predict" />
          </Label>
          <Input value={value.target} onChange={(e) => onChange({ target: e.target.value })} placeholder="target_column" />
        </div>
      </div>
      <div className="space-y-2">
        <Label>
          Features
          <HelpTip text="Comma-separated feature column names (leave empty for all)" />
        </Label>
        <Input value={value.features} onChange={(e) => onChange({ features: e.target.value })} placeholder="col1, col2, col3 (optional)" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="space-y-2">
          <Label>Split strategy</Label>
          <Select value={value.splitStrategy} onValueChange={(v) => onChange({ splitStrategy: v as PytorchDataState['splitStrategy'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {PYTORCH_SPLIT_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Scaler</Label>
          <Select value={value.scaler} onValueChange={(v) => onChange({ scaler: v as PytorchDataState['scaler'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {SCALER_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Sequence length
            <HelpTip text="Number of time steps in each input window" />
          </Label>
          <Input type="number" min={1} value={value.sequenceLength} onChange={(e) => onChange({ sequenceLength: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Stride
            <HelpTip text="Step size between consecutive windows" />
          </Label>
          <Input type="number" min={1} value={value.stride} onChange={(e) => onChange({ stride: Number(e.target.value) })} />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Train ratio</Label>
          <Input type="number" step={0.05} min={0} max={1} value={value.trainRatio} onChange={(e) => onChange({ trainRatio: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>Val ratio</Label>
          <Input type="number" step={0.05} min={0} max={1} value={value.valRatio} onChange={(e) => onChange({ valRatio: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>Test ratio</Label>
          <Input type="number" step={0.05} min={0} max={1} value={value.testRatio} onChange={(e) => onChange({ testRatio: Number(e.target.value) })} />
        </div>
      </div>
      <SplitWarning train={value.trainRatio} val={value.valRatio} test={value.testRatio} />
    </div>
  );
}

// ── HuggingFace Data ─────────────────────────────────────────────

interface HuggingfaceDataProps {
  value: HuggingfaceDataState;
  onChange: (partial: Partial<HuggingfaceDataState>) => void;
}

function HuggingfaceData({ value, onChange }: HuggingfaceDataProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Data source</Label>
          <Select value={value.source} onValueChange={(v) => onChange({ source: v as HuggingfaceDataState['source'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {DATA_SOURCE_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>
            Data path
            <HelpTip text={value.source === 's3' ? 'S3 URI (e.g. s3://bucket/path/data.jsonl)' : 'Path to instruction/chat dataset (JSON/JSONL/CSV)'} />
          </Label>
          <Input
            value={value.source === 's3' ? value.s3Uri : value.path}
            onChange={(e) => onChange(value.source === 's3' ? { s3Uri: e.target.value } : { path: e.target.value })}
            placeholder={value.source === 's3' ? 's3://my-bucket/path/to/data.jsonl' : '/path/to/data.json'}
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>
            Format
            <HelpTip text="Dataset format: instruction, chat, or completion" />
          </Label>
          <Select value={value.format} onValueChange={(v) => onChange({ format: v as HuggingfaceDataState['format'] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {HF_FORMAT_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>
            Max length
            <HelpTip text="Maximum token sequence length (min 16)" />
          </Label>
          <Input type="number" min={16} value={value.maxLength} onChange={(e) => onChange({ maxLength: Number(e.target.value) })} />
        </div>
        <div className="space-y-2">
          <Label>
            Validation split
            <HelpTip text="Fraction of data used for validation" />
          </Label>
          <div className="flex items-center gap-3">
            <Slider
              value={[value.valSplit]}
              onValueChange={([v]) => onChange({ valSplit: Math.round(v * 100) / 100 })}
              min={0}
              max={0.5}
              step={0.01}
              className="flex-1"
            />
            <span className="text-sm text-muted-foreground w-10 text-right">{value.valSplit}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Split ratio validation ───────────────────────────────────────

function SplitWarning({ train, val, test }: { train: number; val: number; test: number }) {
  const sum = train + val + test;
  const valid = Math.abs(sum - 1.0) < 0.01;
  if (valid) return null;
  return (
    <p className="text-xs text-destructive">
      Split ratios must sum to 1.0 (currently {sum.toFixed(2)})
    </p>
  );
}

// ── Main export ──────────────────────────────────────────────────

interface DataSectionProps {
  backend: Backend;
  sklearnData: SklearnDataState;
  pytorchData: PytorchDataState;
  hfData: HuggingfaceDataState;
  onSklearnChange: (partial: Partial<SklearnDataState>) => void;
  onPytorchChange: (partial: Partial<PytorchDataState>) => void;
  onHfChange: (partial: Partial<HuggingfaceDataState>) => void;
}

export function DataSection({
  backend,
  sklearnData,
  pytorchData,
  hfData,
  onSklearnChange,
  onPytorchChange,
  onHfChange,
}: DataSectionProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Data Configuration</CardTitle>
      </CardHeader>
      <CardContent>
        {backend === 'sklearn' && <SklearnData value={sklearnData} onChange={onSklearnChange} />}
        {backend === 'pytorch' && <PytorchData value={pytorchData} onChange={onPytorchChange} />}
        {backend === 'huggingface' && <HuggingfaceData value={hfData} onChange={onHfChange} />}
      </CardContent>
    </Card>
  );
}
