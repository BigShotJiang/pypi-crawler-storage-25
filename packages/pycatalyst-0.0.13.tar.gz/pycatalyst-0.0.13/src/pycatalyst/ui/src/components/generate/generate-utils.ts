import type { GenerateField, InferField } from '@/lib/types';

/** Convert array of records to CSV string (header + rows, quoted and escaped). */
export function recordsToCsv(records: Record<string, unknown>[]): string {
  if (records.length === 0) return '';
  const keys = Object.keys(records[0] as Record<string, unknown>);
  const escape = (v: unknown): string => {
    const s = v === null || v === undefined ? '' : String(v);
    if (s.includes('"') || s.includes(',') || s.includes('\n') || s.includes('\r')) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };
  const header = keys.map(escape).join(',');
  const rows = records.map((r) =>
    keys.map((k) => escape((r as Record<string, unknown>)[k])).join(','),
  );
  return [header, ...rows].join('\n');
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const FIELD_TYPES = [
  'string',
  'int',
  'float',
  'bool',
  'date',
  'datetime',
  'uuid',
  'enum',
] as const;

export const BUILT_IN_TEMPLATES: Record<string, string> = {
  'Order Events': `name: order_events
description: Generate order events for testing
schema:
  fields:
    - name: order_id
      type: uuid
    - name: symbol
      type: enum
      constraints:
        choices: [AAPL, GOOGL, MSFT, AMZN]
    - name: quantity
      type: int
      constraints:
        min: 1
        max: 10000
    - name: price
      type: float
      constraints:
        min: 1.0
        max: 5000.0
    - name: side
      type: enum
      constraints:
        choices: [buy, sell]
    - name: timestamp
      type: datetime
generation:
  count: 100
  seed: 42`,
  'User Profiles': `name: user_profiles
description: Generate user profile data
schema:
  fields:
    - name: user_id
      type: uuid
    - name: username
      type: string
    - name: email
      type: string
    - name: age
      type: int
      constraints:
        min: 18
        max: 85
    - name: active
      type: bool
    - name: signup_date
      type: date
generation:
  count: 50
  seed: 123`,
  'Sensor Readings': `name: sensor_readings
description: Generate IoT sensor data
schema:
  fields:
    - name: sensor_id
      type: uuid
    - name: temperature
      type: float
      constraints:
        min: -20.0
        max: 50.0
    - name: humidity
      type: float
      constraints:
        min: 0.0
        max: 100.0
    - name: status
      type: enum
      constraints:
        choices: [online, offline, error]
    - name: reading_time
      type: datetime
generation:
  count: 200`,
};

export const TYPES_REQUIRING_CHILDREN = ['object', 'array'];

export function inferFieldToGenerateField(f: InferField): GenerateField {
  return {
    name: f.name,
    type: f.type,
    nullable: f.nullable ?? false,
    constraints: f.constraints ?? undefined,
  };
}

export function inferredFieldsToGenerateFields(inferred: InferField[]): {
  fields: GenerateField[];
  omittedCount: number;
} {
  const omitted = inferred.filter((f) =>
    TYPES_REQUIRING_CHILDREN.includes(f.type.toLowerCase()),
  );
  const fields = inferred
    .filter((f) => !TYPES_REQUIRING_CHILDREN.includes(f.type.toLowerCase()))
    .map(inferFieldToGenerateField);
  return { fields, omittedCount: omitted.length };
}

export function jsonSchemaPropertyToGenerateField(
  name: string,
  prop: Record<string, unknown>,
): GenerateField {
  const type = prop.type as string | undefined;
  const format = prop.format as string | undefined;
  const enumVal = prop.enum as unknown[] | undefined;
  const nullable =
    prop.nullable === true ||
    (Array.isArray(type) && type.includes('null')) ||
    type === 'null';

  let fieldType = 'string';
  const constraints: Record<string, unknown> = {};

  if (enumVal && enumVal.length > 0) {
    fieldType = 'enum';
    constraints.choices = enumVal.map(String);
  } else if (type === 'integer') {
    fieldType = 'int';
    if (typeof prop.minimum === 'number') constraints.min = prop.minimum;
    if (typeof prop.maximum === 'number') constraints.max = prop.maximum;
    if (prop.exclusiveMinimum === true) constraints.exclusiveMinimum = true;
    if (prop.exclusiveMaximum === true) constraints.exclusiveMaximum = true;
    if (typeof prop.multipleOf === 'number') constraints.multipleOf = prop.multipleOf;
  } else if (type === 'number') {
    fieldType = 'float';
    if (typeof prop.minimum === 'number') constraints.min = prop.minimum;
    if (typeof prop.maximum === 'number') constraints.max = prop.maximum;
    if (prop.exclusiveMinimum === true) constraints.exclusiveMinimum = true;
    if (prop.exclusiveMaximum === true) constraints.exclusiveMaximum = true;
    if (typeof prop.multipleOf === 'number') constraints.multipleOf = prop.multipleOf;
  } else if (type === 'boolean') {
    fieldType = 'bool';
  } else if (type === 'string') {
    if (format === 'date') fieldType = 'date';
    else if (format === 'date-time') fieldType = 'datetime';
    else if (format === 'uuid') fieldType = 'uuid';
    else fieldType = 'string';
    if (typeof prop.pattern === 'string') constraints.pattern = prop.pattern;
    if (typeof prop.minLength === 'number') constraints.min = prop.minLength;
    if (typeof prop.maxLength === 'number') constraints.max = prop.maxLength;
  }

  const field: GenerateField = {
    name,
    type: fieldType,
    nullable: nullable ?? false,
  };
  if (Object.keys(constraints).length > 0) field.constraints = constraints;
  return field;
}

export function parseJsonSchemaToFields(schema: Record<string, unknown>): GenerateField[] {
  const props = schema.properties as Record<string, Record<string, unknown>> | undefined;
  if (!props || typeof props !== 'object') return [];
  return Object.entries(props).map(([name, prop]) =>
    jsonSchemaPropertyToGenerateField(name, prop ?? {}),
  );
}

export interface FieldRow {
  id: number;
  name: string;
  type: string;
  nullable: boolean;
  constraintMin: string;
  constraintMax: string;
  constraintChoices: string;
  constraintPattern: string;
}

let nextId = 1;
export function newField(): FieldRow {
  return {
    id: nextId++,
    name: '',
    type: 'string',
    nullable: false,
    constraintMin: '',
    constraintMax: '',
    constraintChoices: '',
    constraintPattern: '',
  };
}

export function fieldRowsToGenerateFields(fields: FieldRow[]): GenerateField[] {
  return fields
    .filter((f) => f.name.trim())
    .map((f) => {
      const field: GenerateField = {
        name: f.name.trim(),
        type: f.type,
        nullable: f.nullable,
      };
      const constraints: Record<string, unknown> = {};
      if (f.constraintMin) constraints.min = Number(f.constraintMin);
      if (f.constraintMax) constraints.max = Number(f.constraintMax);
      if (f.constraintChoices) {
        constraints.choices = f.constraintChoices
          .split(',')
          .map((c) => c.trim())
          .filter(Boolean);
      }
      if (f.constraintPattern) constraints.pattern = f.constraintPattern;
      if (Object.keys(constraints).length > 0) field.constraints = constraints;
      return field;
    });
}
