'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X, Rocket } from 'lucide-react';

interface ContainerDialogProps {
  open: boolean;
  onClose: () => void;
  onLaunch: (opts: { command: string }) => void;
  loading?: boolean;
}

export function ContainerDialog({ open, onClose, onLaunch, loading }: ContainerDialogProps) {
  const [command, setCommand] = useState('bash');

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLaunch({ command: command.trim() || 'bash' });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-background border rounded-lg shadow-xl w-full max-w-md mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Launch Container</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded hover:bg-muted text-muted-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="container-cmd">Command</Label>
            <Input
              id="container-cmd"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder="e.g. bash, pip install pystator && pystator worker"
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              The command to run inside the container. Use <code className="bg-muted px-1 rounded">bash</code> for
              an interactive shell, or a full command to run a service.
            </p>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" size="sm" disabled={loading}>
              <Rocket className="h-4 w-4 mr-1.5" />
              {loading ? 'Launching...' : 'Launch'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
