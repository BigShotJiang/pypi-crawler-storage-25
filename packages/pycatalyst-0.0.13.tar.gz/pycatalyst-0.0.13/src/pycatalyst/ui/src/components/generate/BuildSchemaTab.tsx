'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import {
  FIELD_TYPES,
  newField,
  fieldRowsToGenerateFields,
  type FieldRow,
} from '@/components/generate/generate-utils';
import type { FieldRunContext } from '@/components/generate/GenerateRunBar';
import { Plus, Trash2, AlertCircle } from 'lucide-react';

type BuildSchemaTabProps = {
  onRunContext: (ctx: FieldRunContext | null) => void;
};

export function BuildSchemaTab({ onRunContext }: BuildSchemaTabProps) {
  const [schemaName, setSchemaName] = useState('generated_data');
  const [fields, setFields] = useState<FieldRow[]>([newField()]);
  const built = fieldRowsToGenerateFields(fields);
  useEffect(() => {
    const genFields = fieldRowsToGenerateFields(fields);
    if (genFields.length === 0) {
      onRunContext(null);
      return;
    }
    onRunContext({
      schemaName: schemaName.trim() || 'generated_data',
      fields: genFields,
    });
  }, [fields, schemaName, onRunContext]);

  const addField = () => setFields([...fields, newField()]);
  const removeField = (id: number) => {
    if (fields.length > 1) setFields(fields.filter((f) => f.id !== id));
  };
  const updateField = (id: number, patch: Partial<FieldRow>) => {
    setFields(fields.map((f) => (f.id === id ? { ...f, ...patch } : f)));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Build schema</CardTitle>
        <CardDescription>
          Define fields and constraints, then run batch or stream from the right panel
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Schema name</Label>
            <Input
              value={schemaName}
              onChange={(e) => setSchemaName(e.target.value)}
              placeholder="my_schema"
            />
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>Fields</Label>
            <Button variant="outline" size="sm" onClick={addField}>
              <Plus className="h-4 w-4 mr-1" /> Add field
            </Button>
          </div>
          <div className="space-y-3">
            {fields.map((field) => (
              <div key={field.id} className="border rounded-md p-3 space-y-2">
                <div className="flex gap-2 items-end">
                  <div className="flex-1 space-y-1">
                    <Label className="text-xs">Name</Label>
                    <Input
                      value={field.name}
                      onChange={(e) => updateField(field.id, { name: e.target.value })}
                      placeholder="field_name"
                    />
                  </div>
                  <div className="w-32 space-y-1">
                    <Label className="text-xs">Type</Label>
                    <select
                      value={field.type}
                      onChange={(e) => updateField(field.id, { type: e.target.value })}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    >
                      {FIELD_TYPES.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex items-center gap-2 pb-1">
                    <Switch
                      checked={field.nullable}
                      onCheckedChange={(checked) =>
                        updateField(field.id, { nullable: checked })
                      }
                    />
                    <span className="text-xs text-muted-foreground">Null</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeField(field.id)}
                    disabled={fields.length <= 1}
                    className="shrink-0"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                {(field.type === 'int' || field.type === 'float') && (
                  <div className="flex gap-2">
                    <div className="flex-1 space-y-1">
                      <Label className="text-xs">Min</Label>
                      <Input
                        type="number"
                        value={field.constraintMin}
                        onChange={(e) =>
                          updateField(field.id, { constraintMin: e.target.value })
                        }
                        placeholder="min"
                      />
                    </div>
                    <div className="flex-1 space-y-1">
                      <Label className="text-xs">Max</Label>
                      <Input
                        type="number"
                        value={field.constraintMax}
                        onChange={(e) =>
                          updateField(field.id, { constraintMax: e.target.value })
                        }
                        placeholder="max"
                      />
                    </div>
                  </div>
                )}
                {field.type === 'enum' && (
                  <div className="space-y-1">
                    <Label className="text-xs">Choices (comma-separated)</Label>
                    <Input
                      value={field.constraintChoices}
                      onChange={(e) =>
                        updateField(field.id, { constraintChoices: e.target.value })
                      }
                      placeholder="a, b, c"
                    />
                  </div>
                )}
                {field.type === 'string' && (
                  <div className="space-y-1">
                    <Label className="text-xs">Pattern (regex, optional)</Label>
                    <Input
                      value={field.constraintPattern}
                      onChange={(e) =>
                        updateField(field.id, { constraintPattern: e.target.value })
                      }
                      placeholder="[A-Z]+"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        {built.length === 0 && (
          <Alert variant="default">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Add at least one field with a name to enable Run.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
