'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Copy, Check, X } from 'lucide-react';
import type { ServiceInfo } from '@/lib/workbench';

interface ServiceStatusBarProps {
  services: ServiceInfo[];
  onDestroy: (serviceId: string) => void;
}

const STATUS_DOT: Record<string, string> = {
  healthy: 'bg-green-500',
  starting: 'bg-yellow-500 animate-pulse',
  creating: 'bg-yellow-500 animate-pulse',
  unhealthy: 'bg-red-500',
  stopped: 'bg-gray-400',
  error: 'bg-red-500',
};

const TYPE_LABEL: Record<string, string> = {
  postgres: 'PostgreSQL',
  mongodb: 'MongoDB',
};

export function ServiceStatusBar({ services, onDestroy }: ServiceStatusBarProps) {
  // Deduplicate by service_id so React keys are unique (backend/listServices may return duplicates)
  const uniqueServices = Array.from(
    new Map(services.map((s) => [s.service_id, s])).values()
  );
  if (uniqueServices.length === 0) return null;

  return (
    <div className="flex items-center gap-2 px-4 py-1.5 border-b bg-muted/30 text-xs overflow-x-auto shrink-0">
      <span className="text-muted-foreground font-medium shrink-0">Services:</span>
      {uniqueServices.map((svc) => (
        <ServicePill key={svc.service_id} service={svc} onDestroy={onDestroy} />
      ))}
    </div>
  );
}

function ServicePill({
  service,
  onDestroy,
}: {
  service: ServiceInfo;
  onDestroy: (id: string) => void;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (!service.host_url) return;
    try {
      await navigator.clipboard.writeText(service.host_url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API may not be available
    }
  };

  const dotClass = STATUS_DOT[service.status] || 'bg-gray-400';
  const label = TYPE_LABEL[service.service_type] || service.service_type;

  return (
    <div className="flex items-center gap-1.5 bg-background border rounded-md px-2 py-1 shrink-0">
      <span className={`inline-block h-2 w-2 rounded-full ${dotClass}`} />
      <span className="font-medium">{label}</span>
      <span className="text-muted-foreground">({service.status})</span>

      {service.host_url && (
        <button
          type="button"
          onClick={handleCopy}
          className="flex items-center gap-1 ml-1 px-1.5 py-0.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors font-mono"
          title={`Copy connection string: ${service.host_url}`}
        >
          {copied ? (
            <Check className="h-3 w-3 text-green-500" />
          ) : (
            <Copy className="h-3 w-3" />
          )}
          <span className="max-w-[200px] truncate">{service.host_url}</span>
        </button>
      )}

      {service.error_message && (
        <span className="text-red-500 max-w-[200px] truncate" title={service.error_message}>
          {service.error_message}
        </span>
      )}

      <Button
        variant="ghost"
        size="sm"
        onClick={() => onDestroy(service.service_id)}
        className="h-5 w-5 p-0 ml-1 text-muted-foreground hover:text-destructive"
        title="Destroy service"
      >
        <X className="h-3 w-3" />
      </Button>
    </div>
  );
}
