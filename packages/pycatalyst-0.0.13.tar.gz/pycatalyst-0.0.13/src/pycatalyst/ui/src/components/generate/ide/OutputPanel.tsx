'use client';

import { useMemo, useCallback } from 'react';
import { Download, Trash2, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@/components/ui/tabs';
import {
  useGenerateWorkspaceStore,
  selectOutput,
  selectStreaming,
} from '@/stores/generate-workspace';
import type { OutputTab } from '@/stores/generate-workspace';
import {
  recordsToCsv,
  downloadBlob,
} from '@/components/generate/generate-utils';
import { useState } from 'react';

/* ── OutputPanel ───────────────────────────────────────── */

export function OutputPanel() {
  const output = useGenerateWorkspaceStore(selectOutput);
  const streaming = useGenerateWorkspaceStore(selectStreaming);
  const setOutputTab = useGenerateWorkspaceStore((s) => s.setOutputTab);
  const setOutputFormat = useGenerateWorkspaceStore((s) => s.setOutputFormat);
  const clearStream = useGenerateWorkspaceStore((s) => s.clearStream);

  return (
    <Tabs
      value={output.activeTab}
      onValueChange={(v) => setOutputTab(v as OutputTab)}
      className="flex h-full flex-col"
    >
      <div className="flex items-center justify-between border-b border-border px-3">
        <TabsList className="h-9">
          <TabsTrigger value="data" className="text-xs">
            Data
          </TabsTrigger>
          <TabsTrigger value="stream" className="text-xs">
            Stream
            {streaming && (
              <span className="ml-1.5 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-green-500" />
            )}
          </TabsTrigger>
          <TabsTrigger value="logs" className="text-xs">
            Logs
          </TabsTrigger>
          <TabsTrigger value="stats" className="text-xs">
            Stats
          </TabsTrigger>
        </TabsList>
      </div>

      <div className="flex-1 overflow-hidden">
        <TabsContent value="data" className="mt-0 h-full">
          <DataTab
            records={output.batchResults}
            meta={output.batchMeta}
            format={output.format}
            onFormatChange={setOutputFormat}
          />
        </TabsContent>

        <TabsContent value="stream" className="mt-0 h-full">
          <StreamTab
            records={output.streamRecords}
            totalReceived={output.streamTotalReceived}
            onClear={clearStream}
          />
        </TabsContent>

        <TabsContent value="logs" className="mt-0 h-full">
          <LogsTab logs={output.logs} />
        </TabsContent>

        <TabsContent value="stats" className="mt-0 h-full">
          <StatsTab records={output.batchResults} />
        </TabsContent>
      </div>
    </Tabs>
  );
}

/* ── Data tab ──────────────────────────────────────────── */

function DataTab({
  records,
  meta,
  format,
  onFormatChange,
}: {
  records: Record<string, unknown>[] | null;
  meta: {
    count: number;
    duration: number;
    sinkType?: string;
    pythonApi?: string;
  } | null;
  format: 'json' | 'csv';
  onFormatChange: (f: 'json' | 'csv') => void;
}) {
  const [snippetOpen, setSnippetOpen] = useState(false);

  const formatted = useMemo(() => {
    if (!records || records.length === 0) return '';
    return format === 'json'
      ? JSON.stringify(records, null, 2)
      : recordsToCsv(records);
  }, [records, format]);

  const handleDownload = useCallback(() => {
    if (!formatted) return;
    const ext = format === 'json' ? 'json' : 'csv';
    const mime = format === 'json' ? 'application/json' : 'text/csv';
    downloadBlob(
      new Blob([formatted], { type: mime }),
      `generate-output.${ext}`,
    );
  }, [formatted, format]);

  if (!records || records.length === 0) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        Run a batch to see results here
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-2 border-b border-border px-3 py-2">
        <div className="flex overflow-hidden rounded-md border border-input text-xs">
          <button
            type="button"
            onClick={() => onFormatChange('json')}
            className={`px-2 py-1 font-medium transition-colors ${
              format === 'json'
                ? 'bg-primary text-primary-foreground'
                : 'bg-background hover:bg-muted'
            }`}
          >
            JSON
          </button>
          <button
            type="button"
            onClick={() => onFormatChange('csv')}
            className={`border-l border-input px-2 py-1 font-medium
              transition-colors ${
                format === 'csv'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-background hover:bg-muted'
              }`}
          >
            CSV
          </button>
        </div>

        <Button variant="outline" size="sm" onClick={handleDownload}>
          <Download className="mr-1.5 h-3.5 w-3.5" />
          Download
        </Button>

        {meta && (
          <span className="text-xs text-muted-foreground">
            {meta.count} records in {meta.duration}ms
            {meta.sinkType ? ` | sink: ${meta.sinkType}` : ''}
          </span>
        )}
      </div>

      {/* Code block */}
      <pre className="flex-1 overflow-auto whitespace-pre bg-muted/30 p-3 font-mono text-xs leading-relaxed">
        {formatted}
      </pre>

      {/* Python API snippet */}
      {meta?.pythonApi && (
        <div className="border-t border-border">
          <button
            type="button"
            onClick={() => setSnippetOpen((v) => !v)}
            className="flex w-full items-center gap-1 px-3 py-1.5 text-xs
              text-muted-foreground hover:text-foreground transition-colors"
          >
            {snippetOpen ? (
              <ChevronDown className="h-3 w-3" />
            ) : (
              <ChevronRight className="h-3 w-3" />
            )}
            Python API
          </button>
          {snippetOpen && (
            <pre className="overflow-auto whitespace-pre bg-muted/30 px-3 pb-2 font-mono text-xs">
              {meta.pythonApi}
            </pre>
          )}
        </div>
      )}
    </div>
  );
}

/* ── Stream tab ────────────────────────────────────────── */

function StreamTab({
  records,
  totalReceived,
  onClear,
}: {
  records: Record<string, unknown>[];
  totalReceived: number;
  onClear: () => void;
}) {
  const ndjson = useMemo(
    () => records.map((r) => JSON.stringify(r)).join('\n'),
    [records],
  );

  const handleDownloadNdjson = useCallback(() => {
    if (!ndjson) return;
    downloadBlob(
      new Blob([ndjson], { type: 'application/x-ndjson' }),
      'stream-output.ndjson',
    );
  }, [ndjson]);

  const handleDownloadJson = useCallback(() => {
    if (records.length === 0) return;
    downloadBlob(
      new Blob([JSON.stringify(records, null, 2)], {
        type: 'application/json',
      }),
      'stream-output.json',
    );
  }, [records]);

  if (records.length === 0 && totalReceived === 0) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        Start streaming to see records here
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 border-b border-border px-3 py-2">
        <span className="text-xs font-medium tabular-nums">
          {totalReceived} records received
        </span>

        <div className="ml-auto flex gap-1.5">
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadNdjson}
            disabled={records.length === 0}
          >
            <Download className="mr-1.5 h-3.5 w-3.5" />
            NDJSON
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadJson}
            disabled={records.length === 0}
          >
            <Download className="mr-1.5 h-3.5 w-3.5" />
            JSON
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onClear}
            disabled={records.length === 0}
          >
            <Trash2 className="mr-1.5 h-3.5 w-3.5" />
            Clear
          </Button>
        </div>
      </div>

      <pre className="flex-1 overflow-auto whitespace-pre bg-muted/30 p-3 font-mono text-xs leading-relaxed">
        {ndjson}
      </pre>
    </div>
  );
}

/* ── Logs tab ──────────────────────────────────────────── */

function LogsTab({
  logs,
}: {
  logs: { timestamp: number; level: 'info' | 'warn' | 'error'; message: string }[];
}) {
  if (logs.length === 0) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        No logs yet
      </div>
    );
  }

  const levelClass: Record<string, string> = {
    info: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    warn: 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200',
    error: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
  };

  return (
    <div className="h-full overflow-auto">
      <ul className="divide-y divide-border">
        {logs.map((entry, idx) => (
          <li key={idx} className="flex items-start gap-2 px-3 py-1.5">
            <span className="shrink-0 pt-0.5 text-[10px] tabular-nums text-muted-foreground">
              {new Date(entry.timestamp).toLocaleTimeString()}
            </span>
            <Badge
              variant="secondary"
              className={`shrink-0 text-[10px] ${levelClass[entry.level] ?? ''}`}
            >
              {entry.level}
            </Badge>
            <span className="text-xs">{entry.message}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ── Stats tab ─────────────────────────────────────────── */

function StatsTab({
  records,
}: {
  records: Record<string, unknown>[] | null;
}) {
  const stats = useMemo(() => {
    if (!records || records.length === 0) return null;
    const keys = Object.keys(records[0] as Record<string, unknown>);
    return keys.map((key) => {
      const values = records.map(
        (r) => (r as Record<string, unknown>)[key],
      );
      const nonNull = values.filter(
        (v) => v !== null && v !== undefined,
      );
      const nullCount = values.length - nonNull.length;

      const nums = nonNull.filter(
        (v) => typeof v === 'number',
      ) as number[];

      const strings = nonNull.filter(
        (v) => typeof v === 'string',
      ) as string[];

      return {
        field: key,
        total: values.length,
        nullCount,
        min: nums.length > 0 ? Math.min(...nums) : undefined,
        max: nums.length > 0 ? Math.max(...nums) : undefined,
        uniqueCount:
          strings.length > 0 ? new Set(strings).size : undefined,
      };
    });
  }, [records]);

  if (!stats) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        Run a batch to see statistics
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto">
      <table className="w-full border-collapse text-xs">
        <thead className="sticky top-0 bg-muted/80 backdrop-blur-sm">
          <tr className="border-b border-border">
            <th className="px-3 py-2 text-left font-medium">Field</th>
            <th className="px-3 py-2 text-right font-medium">Count</th>
            <th className="px-3 py-2 text-right font-medium">Nulls</th>
            <th className="px-3 py-2 text-right font-medium">Min</th>
            <th className="px-3 py-2 text-right font-medium">Max</th>
            <th className="px-3 py-2 text-right font-medium">Unique</th>
          </tr>
        </thead>
        <tbody>
          {stats.map((s) => (
            <tr key={s.field} className="border-b border-border">
              <td className="px-3 py-1.5 font-medium">{s.field}</td>
              <td className="px-3 py-1.5 text-right tabular-nums">
                {s.total}
              </td>
              <td className="px-3 py-1.5 text-right tabular-nums">
                {s.nullCount}
              </td>
              <td className="px-3 py-1.5 text-right tabular-nums">
                {s.min !== undefined ? s.min : '--'}
              </td>
              <td className="px-3 py-1.5 text-right tabular-nums">
                {s.max !== undefined ? s.max : '--'}
              </td>
              <td className="px-3 py-1.5 text-right tabular-nums">
                {s.uniqueCount !== undefined ? s.uniqueCount : '--'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
