'use client';

import { LayoutGrid, Search, FileJson, BookOpen } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  useGenerateWorkspaceStore,
  selectSchemaSource,
  type SchemaSource,
} from '@/stores/generate-workspace';

const OPTIONS: { value: SchemaSource; label: string; icon: typeof LayoutGrid }[] = [
  { value: 'build', label: 'Build', icon: LayoutGrid },
  { value: 'infer', label: 'Infer', icon: Search },
  { value: 'json-schema', label: 'JSON Schema', icon: FileJson },
  { value: 'recipe', label: 'Recipe', icon: BookOpen },
];

/**
 * Segmented control for selecting the schema source mode.
 *
 * Reads and writes `schemaSource` in the generate workspace store.
 */
export function SchemaSourceSelector() {
  const schemaSource = useGenerateWorkspaceStore(selectSchemaSource);
  const setSchemaSource = useGenerateWorkspaceStore((s) => s.setSchemaSource);

  return (
    <div className="px-3 py-2">
      <div className="flex rounded-md border border-input overflow-hidden">
        {OPTIONS.map(({ value, label, icon: Icon }) => (
          <button
            key={value}
            type="button"
            onClick={() => setSchemaSource(value)}
            className={cn(
              'flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5',
              'text-xs font-medium transition-colors',
              value !== OPTIONS[0].value && 'border-l border-input',
              schemaSource === value
                ? 'bg-primary text-primary-foreground'
                : 'bg-background hover:bg-muted text-muted-foreground',
            )}
            aria-pressed={schemaSource === value}
          >
            <Icon className="h-3.5 w-3.5 shrink-0" />
            <span className="hidden sm:inline">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
