'use client';

import Link from 'next/link';
import { useAuthStore, selectApiUnavailable } from '@/stores/auth';
import { ROUTES } from '@/lib/constants';
import { AlertCircle } from 'lucide-react';

export function ApiUnavailableBanner() {
  const apiUnavailable = useAuthStore(selectApiUnavailable);
  if (!apiUnavailable) return null;

  return (
    <div className="bg-amber-500/10 border-b border-amber-500/30 px-4 py-2 flex items-center justify-center gap-2 text-sm text-amber-800 dark:text-amber-200" role="alert">
      <AlertCircle className="h-4 w-4 shrink-0" />
      <span>API server not connected. Some features are unavailable.</span>
      <Link href={ROUTES.SETTINGS} className="font-medium underline underline-offset-2 hover:no-underline">Settings</Link>
      <span className="text-muted-foreground">| Start API: pycatalyst api</span>
    </div>
  );
}
