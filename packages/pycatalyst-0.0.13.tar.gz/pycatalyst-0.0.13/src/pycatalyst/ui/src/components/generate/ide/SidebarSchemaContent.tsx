'use client';

/**
 * Store-connected wrappers for the existing schema tab components.
 *
 * Each wrapper bridges the prop-based tab component to the Zustand store,
 * syncing schema fields and run context when the user makes changes.
 */

import { useCallback } from 'react';
import { useGenerateWorkspaceStore } from '@/stores/generate-workspace';
import { BuildSchemaTab } from '@/components/generate/BuildSchemaTab';
import { InferSchemaTab } from '@/components/generate/InferSchemaTab';
import { JsonSchemaGenerateTab } from '@/components/generate/JsonSchemaGenerateTab';
import { RecipeDraftEditor } from '@/components/generate/RecipeDraftEditor';
import { useAppConfigStore, selectRecipeSinkMode } from '@/stores/app-config';
import type { FieldRunContext } from '@/components/generate/GenerateRunBar';
import type { InferField, GenerateField } from '@/lib/types';

/**
 * Sidebar-friendly Build schema content.
 * Wraps BuildSchemaTab and syncs run context to the store.
 */
export function BuildSchemaContent() {
  const setFields = useGenerateWorkspaceStore((s) => s.setFields);
  const setSchemaName = useGenerateWorkspaceStore((s) => s.setSchemaName);

  const handleRunContext = useCallback(
    (ctx: FieldRunContext | null) => {
      if (ctx) {
        setFields(ctx.fields);
        setSchemaName(ctx.schemaName);
      } else {
        setFields([]);
      }
    },
    [setFields, setSchemaName],
  );

  return (
    <div className="[&>div]:border-0 [&>div]:shadow-none [&>div]:rounded-none">
      <BuildSchemaTab onRunContext={handleRunContext} />
    </div>
  );
}

/**
 * Sidebar-friendly Infer schema content.
 * Wraps InferSchemaTab and syncs inferred fields to the store.
 */
export function InferSchemaContent() {
  const setFields = useGenerateWorkspaceStore((s) => s.setFields);
  const setSchemaName = useGenerateWorkspaceStore((s) => s.setSchemaName);
  const setInferredFields = useGenerateWorkspaceStore(
    (s) => s.setInferredFields,
  );

  const handleRunContext = useCallback(
    (ctx: FieldRunContext | null) => {
      if (ctx) {
        setFields(ctx.fields);
        setSchemaName(ctx.schemaName);
      } else {
        setFields([]);
      }
    },
    [setFields, setSchemaName],
  );

  const handleInferred = useCallback(
    (fields: InferField[] | null) => {
      setInferredFields(fields);
    },
    [setInferredFields],
  );

  return (
    <div className="[&>div]:border-0 [&>div]:shadow-none [&>div]:rounded-none">
      <InferSchemaTab
        onInferred={handleInferred}
        onRunContext={handleRunContext}
      />
    </div>
  );
}

/**
 * Sidebar-friendly JSON Schema content.
 * Wraps JsonSchemaGenerateTab and syncs parsed fields to the store.
 */
export function JsonSchemaContent() {
  const setFields = useGenerateWorkspaceStore((s) => s.setFields);
  const setSchemaName = useGenerateWorkspaceStore((s) => s.setSchemaName);
  const setJsonSchemaFields = useGenerateWorkspaceStore(
    (s) => s.setJsonSchemaFields,
  );

  const handleRunContext = useCallback(
    (ctx: FieldRunContext | null) => {
      if (ctx) {
        setFields(ctx.fields);
        setSchemaName(ctx.schemaName);
      } else {
        setFields([]);
      }
    },
    [setFields, setSchemaName],
  );

  const handleParsedFields = useCallback(
    (fields: GenerateField[] | null) => {
      setJsonSchemaFields(fields);
    },
    [setJsonSchemaFields],
  );

  return (
    <div className="[&>div]:border-0 [&>div]:shadow-none [&>div]:rounded-none">
      <JsonSchemaGenerateTab
        onParsedFields={handleParsedFields}
        onRunContext={handleRunContext}
      />
    </div>
  );
}

/**
 * Sidebar-friendly Recipe YAML content.
 * Wraps RecipeDraftEditor and syncs recipe results to the store.
 */
export function RecipeYamlContent() {
  const recipeSinkMode = useAppConfigStore(selectRecipeSinkMode);
  const setBatchResults = useGenerateWorkspaceStore((s) => s.setBatchResults);

  const handleResult = useCallback(
    (
      records: Record<string, unknown>[],
      count: number,
      sink: string,
      duration: number,
      errors?: string[],
      pythonApi?: string,
    ) => {
      setBatchResults(records, {
        count,
        duration,
        sinkType: sink,
        errors,
        usedRecipeEndpoint: true,
        pythonApi,
      });
    },
    [setBatchResults],
  );

  return (
    <div className="[&>div]:border-0 [&>div]:shadow-none [&>div]:rounded-none">
      <RecipeDraftEditor
        recipeSinkMode={recipeSinkMode}
        onResult={handleResult}
      />
    </div>
  );
}
