'use client';

import { useCallback, useEffect, useRef } from 'react';
import { Play, Square } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { api, ApiError } from '@/lib/api';
import { streamSseRecords } from '@/lib/sse-stream';
import { buildRecipeRunRequestFromFields } from '@/lib/recipe-from-fields';
import {
  useGenerateWorkspaceStore,
  selectGeneration,
  selectBusy,
  selectStreaming,
  selectFields,
} from '@/stores/generate-workspace';
import {
  useAppConfigStore,
  selectRecipeSinkMode,
} from '@/stores/app-config';

/* ── GenerateToolbar ───────────────────────────────────── */

export function GenerateToolbar() {
  const fields = useGenerateWorkspaceStore(selectFields);
  const generation = useGenerateWorkspaceStore(selectGeneration);
  const busy = useGenerateWorkspaceStore(selectBusy);
  const streaming = useGenerateWorkspaceStore(selectStreaming);

  const schemaName = useGenerateWorkspaceStore((s) => s.schemaName);
  const sinks = useGenerateWorkspaceStore((s) => s.sinks);
  const setGeneration = useGenerateWorkspaceStore((s) => s.setGeneration);
  const setBusy = useGenerateWorkspaceStore((s) => s.setBusy);
  const setStreaming = useGenerateWorkspaceStore((s) => s.setStreaming);
  const setError = useGenerateWorkspaceStore((s) => s.setError);
  const setBatchResults = useGenerateWorkspaceStore((s) => s.setBatchResults);
  const addStreamRecord = useGenerateWorkspaceStore((s) => s.addStreamRecord);
  const clearStream = useGenerateWorkspaceStore((s) => s.clearStream);
  const addLog = useGenerateWorkspaceStore((s) => s.addLog);

  const recipeSinkMode = useAppConfigStore(selectRecipeSinkMode);

  const abortRef = useRef<AbortController | null>(null);

  const { deliveryMode, count, maxRecords, intervalMs, seed } = generation;
  const isBatch = deliveryMode === 'batch';
  const canRun = fields.length > 0;

  /* ── Helpers ─────────────────────────────────────────── */

  const parseSeed = (): number | undefined => {
    const t = seed.trim();
    if (!t) return undefined;
    const n = Number(t);
    return Number.isFinite(n) ? n : undefined;
  };

  const stopStream = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  /* ── Batch run ───────────────────────────────────────── */

  const runBatch = useCallback(async () => {
    if (!canRun) return;
    setError(null);
    setBusy(true);
    addLog('info', `Starting batch generation (count=${count})`);
    const seedN = parseSeed();
    const start = performance.now();

    try {
      if (recipeSinkMode === 'full') {
        const activeSink = sinks[0] ?? {
          type: 'memory',
          config: {},
        };
        const body = buildRecipeRunRequestFromFields(
          schemaName,
          fields,
          { count, seed: seedN },
          { type: activeSink.type, config: activeSink.config },
          recipeSinkMode,
        );
        const res = await api.recipes.run(body);
        const elapsed = Math.round(performance.now() - start);
        setBatchResults(res.records, {
          count: res.count,
          duration: res.duration_ms ?? elapsed,
          sinkType: res.sink_type,
          errors: res.errors,
          usedRecipeEndpoint: true,
          pythonApi: res.python_api,
        });
        addLog(
          'info',
          `Batch complete: ${res.count} records in ${res.duration_ms}ms`,
        );
      } else {
        const res = await api.generate.run({
          name: schemaName,
          fields,
          count,
          seed: seedN,
        });
        const elapsed = Math.round(performance.now() - start);
        setBatchResults(res.records, {
          count: res.count,
          duration: res.duration_ms ?? elapsed,
          usedRecipeEndpoint: false,
          pythonApi: res.python_api,
        });
        addLog(
          'info',
          `Batch complete: ${res.count} records in ${res.duration_ms}ms`,
        );
      }
    } catch (err) {
      const msg =
        err instanceof ApiError ? err.message : 'Generation failed';
      setError(msg);
      addLog('error', msg);
    } finally {
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canRun, count, fields, recipeSinkMode, schemaName, sinks]);

  /* ── Stream run ──────────────────────────────────────── */

  const runStream = useCallback(async () => {
    if (!canRun) return;
    setError(null);
    clearStream();
    const ac = new AbortController();
    abortRef.current = ac;
    setBusy(true);
    setStreaming(true);
    addLog('info', `Starting stream (max=${maxRecords})`);

    try {
      const res = await api.stream.openSse(
        {
          name: schemaName,
          fields,
          max_records: maxRecords,
          interval_ms: intervalMs || undefined,
          seed: parseSeed(),
        },
        ac.signal,
      );

      for await (const ev of streamSseRecords(res, { signal: ac.signal })) {
        if (ev.kind === 'error') {
          setError(ev.message);
          addLog('error', ev.message);
          return;
        }
        addStreamRecord(ev.record);
      }
      addLog('info', 'Stream complete');
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        addLog('info', 'Stream stopped by user');
        return;
      }
      const msg = err instanceof ApiError ? err.message : String(err);
      setError(msg);
      addLog('error', msg);
    } finally {
      abortRef.current = null;
      setStreaming(false);
      setBusy(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canRun, maxRecords, intervalMs, fields, schemaName]);

  /* ── Primary button handler ──────────────────────────── */

  const handlePrimary = useCallback(() => {
    if (streaming) {
      stopStream();
      return;
    }
    if (isBatch) void runBatch();
    else void runStream();
  }, [streaming, stopStream, isBatch, runBatch, runStream]);

  const primaryLabel = streaming
    ? 'Stop stream'
    : isBatch
      ? busy
        ? 'Generating...'
        : 'Run batch'
      : busy
        ? 'Streaming...'
        : 'Start stream';

  /* ── Keyboard shortcut: Ctrl+Enter to run ────────────── */

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handlePrimary();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handlePrimary]);

  /* ── Render ──────────────────────────────────────────── */

  return (
    <div
      className="absolute right-3 top-3 z-10 flex items-center gap-3
        rounded-lg border border-border bg-card/90 px-3 py-2
        shadow-md backdrop-blur-sm"
    >
      {/* Delivery mode toggle */}
      <div className="flex overflow-hidden rounded-md border border-input text-xs">
        <button
          type="button"
          onClick={() => setGeneration({ deliveryMode: 'batch' })}
          disabled={streaming}
          className={`px-2.5 py-1 font-medium transition-colors ${
            isBatch
              ? 'bg-primary text-primary-foreground'
              : 'bg-background hover:bg-muted'
          }`}
        >
          Batch
        </button>
        <button
          type="button"
          onClick={() => setGeneration({ deliveryMode: 'stream' })}
          disabled={streaming}
          className={`border-l border-input px-2.5 py-1 font-medium
            transition-colors ${
              !isBatch
                ? 'bg-primary text-primary-foreground'
                : 'bg-background hover:bg-muted'
            }`}
        >
          Stream
        </button>
      </div>

      {/* Count / Max records */}
      <div className="flex items-center gap-1.5">
        <Label className="text-xs text-muted-foreground">
          {isBatch ? 'Count' : 'Max records'}
        </Label>
        <Input
          type="number"
          min={1}
          max={100000}
          className="h-7 w-20 text-xs"
          value={isBatch ? count : maxRecords}
          onChange={(e) => {
            const v = Number(e.target.value);
            if (isBatch) setGeneration({ count: v });
            else setGeneration({ maxRecords: v });
          }}
          disabled={busy}
        />
      </div>

      {/* Seed */}
      <div className="flex items-center gap-1.5">
        <Label className="text-xs text-muted-foreground">Seed</Label>
        <Input
          className="h-7 w-16 text-xs"
          value={seed}
          onChange={(e) => setGeneration({ seed: e.target.value })}
          placeholder="--"
          disabled={busy}
        />
      </div>

      {/* Stream interval (stream mode only) */}
      {!isBatch && (
        <div className="flex items-center gap-1.5">
          <Label className="text-xs text-muted-foreground">Interval ms</Label>
          <Input
            type="number"
            min={0}
            className="h-7 w-20 text-xs"
            value={intervalMs}
            onChange={(e) =>
              setGeneration({ intervalMs: Number(e.target.value) })
            }
            disabled={busy}
          />
        </div>
      )}

      {/* Primary action */}
      <Button
        size="sm"
        onClick={handlePrimary}
        disabled={!canRun || (busy && !streaming)}
        className="h-7 gap-1.5 text-xs"
        title={`${primaryLabel} (Ctrl+Enter)`}
      >
        {streaming ? (
          <Square className="h-3.5 w-3.5" />
        ) : (
          <Play className="h-3.5 w-3.5" />
        )}
        {primaryLabel}
      </Button>
    </div>
  );
}
