/** Evaluation metrics and plots multi-select section. */

'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { HelpTip } from './HelpTip';
import type {
  Backend,
  SklearnEvaluationState,
  PytorchEvaluationState,
  HuggingfaceEvaluationState,
} from './types';
import {
  SKLEARN_METRICS,
  SKLEARN_PLOTS,
  PYTORCH_METRICS,
  PYTORCH_PLOTS,
  HF_METRICS,
} from './constants';
import { cn } from '@/lib/utils';

// ── Toggle badge list ────────────────────────────────────────────

interface ToggleBadgesProps {
  label: string;
  help: string;
  options: readonly string[];
  selected: string[];
  onChange: (selected: string[]) => void;
}

function ToggleBadges({ label, help, options, selected, onChange }: ToggleBadgesProps) {
  const toggle = (item: string) => {
    if (selected.includes(item)) {
      onChange(selected.filter((s) => s !== item));
    } else {
      onChange([...selected, item]);
    }
  };

  return (
    <div className="space-y-2">
      <p className="text-sm font-medium">
        {label}
        <HelpTip text={help} />
      </p>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => {
          const active = selected.includes(opt);
          return (
            <Badge
              key={opt}
              variant={active ? 'default' : 'outline'}
              className={cn('cursor-pointer select-none', !active && 'hover:bg-muted')}
              onClick={() => toggle(opt)}
            >
              {opt}
            </Badge>
          );
        })}
      </div>
    </div>
  );
}

// ── Main export ──────────────────────────────────────────────────

interface EvaluationSectionProps {
  backend: Backend;
  sklearnEvaluation: SklearnEvaluationState;
  pytorchEvaluation: PytorchEvaluationState;
  hfEvaluation: HuggingfaceEvaluationState;
  onSklearnChange: (partial: Partial<SklearnEvaluationState>) => void;
  onPytorchChange: (partial: Partial<PytorchEvaluationState>) => void;
  onHfChange: (partial: Partial<HuggingfaceEvaluationState>) => void;
}

export function EvaluationSection({
  backend,
  sklearnEvaluation,
  pytorchEvaluation,
  hfEvaluation,
  onSklearnChange,
  onPytorchChange,
  onHfChange,
}: EvaluationSectionProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Evaluation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {backend === 'sklearn' && (
          <>
            <ToggleBadges
              label="Metrics"
              help="Metrics to compute on test set"
              options={SKLEARN_METRICS}
              selected={sklearnEvaluation.metrics}
              onChange={(metrics) => onSklearnChange({ metrics })}
            />
            <ToggleBadges
              label="Plots"
              help="Plots to generate after evaluation"
              options={SKLEARN_PLOTS}
              selected={sklearnEvaluation.plots}
              onChange={(plots) => onSklearnChange({ plots })}
            />
          </>
        )}
        {backend === 'pytorch' && (
          <>
            <ToggleBadges
              label="Metrics"
              help="Metrics to compute on test set"
              options={PYTORCH_METRICS}
              selected={pytorchEvaluation.metrics}
              onChange={(metrics) => onPytorchChange({ metrics })}
            />
            <ToggleBadges
              label="Plots"
              help="Plots to generate after evaluation"
              options={PYTORCH_PLOTS}
              selected={pytorchEvaluation.plots}
              onChange={(plots) => onPytorchChange({ plots })}
            />
          </>
        )}
        {backend === 'huggingface' && (
          <ToggleBadges
            label="Metrics"
            help="Metrics to compute during evaluation"
            options={HF_METRICS}
            selected={hfEvaluation.metrics}
            onChange={(metrics) => onHfChange({ metrics })}
          />
        )}
      </CardContent>
    </Card>
  );
}
