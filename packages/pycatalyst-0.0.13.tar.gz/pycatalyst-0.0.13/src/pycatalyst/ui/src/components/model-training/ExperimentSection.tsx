/** Experiment name, seed, and output directory inputs. */

'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { ExperimentState } from './types';
import { HelpTip } from './HelpTip';

interface ExperimentSectionProps {
  value: ExperimentState;
  onChange: (partial: Partial<ExperimentState>) => void;
}

export function ExperimentSection({ value, onChange }: ExperimentSectionProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Experiment</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="exp-name">
              Name
              <HelpTip text="Unique identifier for this experiment run" />
            </Label>
            <Input
              id="exp-name"
              value={value.name}
              onChange={(e) => onChange({ name: e.target.value })}
              placeholder="my-experiment"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="exp-seed">
              Random seed
              <HelpTip text="Seed for reproducible results" />
            </Label>
            <Input
              id="exp-seed"
              type="number"
              value={value.seed}
              onChange={(e) => onChange({ seed: Number(e.target.value) })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="exp-output">
              Output directory
              <HelpTip text="Where to save model artifacts and logs" />
            </Label>
            <Input
              id="exp-output"
              value={value.outputDir}
              onChange={(e) => onChange({ outputDir: e.target.value })}
              placeholder="./runs/experiment"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
