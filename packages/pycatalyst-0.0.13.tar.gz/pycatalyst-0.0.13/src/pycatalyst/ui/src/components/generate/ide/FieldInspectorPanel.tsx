'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  useGenerateWorkspaceStore,
  selectFields,
  selectSelectedFieldIndex,
} from '@/stores/generate-workspace';
import { FieldInspectorForm } from './FieldInspectorForm';

const MIN_WIDTH = 280;
const MAX_WIDTH = 600;
const DEFAULT_WIDTH = 320;

export function FieldInspectorPanel() {
  const fields = useGenerateWorkspaceStore(selectFields);
  const selectedFieldIndex = useGenerateWorkspaceStore(selectSelectedFieldIndex);
  const setSelectedFieldIndex = useGenerateWorkspaceStore(
    (s) => s.setSelectedFieldIndex,
  );

  const [width, setWidth] = useState(DEFAULT_WIDTH);
  const dragging = useRef(false);
  const panelRef = useRef<HTMLDivElement>(null);

  const isOpen = selectedFieldIndex !== null && selectedFieldIndex < fields.length;
  const field = isOpen ? fields[selectedFieldIndex] : null;

  /* ── Close on Escape ─────────────────────────────────── */

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedFieldIndex(null);
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [isOpen, setSelectedFieldIndex]);

  /* ── Close on outside click ──────────────────────────── */

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target as Node)
      ) {
        setSelectedFieldIndex(null);
      }
    };
    // Delay to prevent the opening click from immediately closing.
    const timer = setTimeout(() => {
      document.addEventListener('mousedown', handler);
    }, 0);
    return () => {
      clearTimeout(timer);
      document.removeEventListener('mousedown', handler);
    };
  }, [isOpen, setSelectedFieldIndex]);

  /* ── Resize via drag handle ──────────────────────────── */

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    dragging.current = true;

    const startX = e.clientX;
    const startWidth = width;

    const onMouseMove = (ev: MouseEvent) => {
      if (!dragging.current) return;
      const delta = startX - ev.clientX;
      setWidth(Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, startWidth + delta)));
    };

    const onMouseUp = () => {
      dragging.current = false;
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width]);

  if (!isOpen || !field) return null;

  return (
    <div
      ref={panelRef}
      style={{ width }}
      className="absolute bottom-0 right-0 top-0 z-20 flex border-l
        border-border bg-card shadow-lg animate-in slide-in-from-right-4
        duration-200"
    >
      {/* Drag handle */}
      <div
        role="separator"
        aria-orientation="vertical"
        onMouseDown={onMouseDown}
        className="w-1 cursor-col-resize hover:bg-primary/20
          active:bg-primary/30 transition-colors"
      />

      {/* Panel content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <h3 className="truncate text-sm font-semibold">
            {field.name || '(unnamed)'}
          </h3>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setSelectedFieldIndex(null)}
            aria-label="Close inspector"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Scrollable form body */}
        <div className="flex-1 overflow-y-auto px-4 py-3">
          <FieldInspectorForm fieldIndex={selectedFieldIndex} />
        </div>
      </div>
    </div>
  );
}
