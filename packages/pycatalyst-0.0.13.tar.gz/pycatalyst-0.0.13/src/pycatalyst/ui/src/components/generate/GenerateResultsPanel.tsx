'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { GenerateField, InferField } from '@/lib/types';
import { FileJson, FileSpreadsheet, Download, Trash2 } from 'lucide-react';
import { recordsToCsv, downloadBlob } from '@/components/generate/generate-utils';
import { PYTHON_API_STREAM_ITER_RECORDS } from '@/lib/generation-api-labels';

export const STREAM_DISPLAY_CAP = 1000;

export type BatchResultMeta = {
  count: number;
  duration: number;
  sinkType?: string;
  errors?: string[];
  usedRecipeEndpoint?: boolean;
  /** Python API that produced this batch (from REST `python_api`). */
  pythonApi?: string;
};

type GenerateResultsPanelProps = {
  outputView: 'batch' | 'stream';
  batchResults: Record<string, unknown>[] | null;
  batchMeta: BatchResultMeta | null;
  streamRecords: Record<string, unknown>[];
  streamTotalReceived: number;
  streaming: boolean;
  outputFormat: 'json' | 'csv';
  onOutputFormatChange: (f: 'json' | 'csv') => void;
  onClearStream: () => void;
  showInferredInResults: boolean;
  inferredFields: InferField[] | null;
  showJsonSchemaInResults: boolean;
  jsonSchemaFields: GenerateField[] | null;
};

export function GenerateResultsPanel({
  outputView,
  batchResults,
  batchMeta,
  streamRecords,
  streamTotalReceived,
  streaming,
  outputFormat,
  onOutputFormatChange,
  onClearStream,
  showInferredInResults,
  inferredFields,
  showJsonSchemaInResults,
  jsonSchemaFields,
}: GenerateResultsPanelProps) {
  const showBatch = outputView === 'batch' && batchMeta !== null;
  const showStream = outputView === 'stream';
  const streamTruncated = streamTotalReceived > STREAM_DISPLAY_CAP;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">
          Results
          {showBatch && batchMeta && (
            <span className="text-sm font-normal text-muted-foreground ml-2">
              {batchMeta.count} records
              {batchMeta.sinkType != null && ` · ${batchMeta.sinkType} sink`}
              {` · ${batchMeta.duration.toFixed(1)}ms`}
            </span>
          )}
          {showStream && (
            <span className="text-sm font-normal text-muted-foreground ml-2">
              {streaming ? 'Streaming' : 'Stream ended'} · received{' '}
              {streamTotalReceived}
              {streamTruncated &&
                ` (showing last ${STREAM_DISPLAY_CAP} in buffer)`}
            </span>
          )}
        </CardTitle>
        {showStream && (
          <div className="text-xs text-muted-foreground font-normal space-y-1">
            <p>
              Live preview only — use Batch + sink in Run (or Recipe YAML) to write to
              file, HTTP, Kafka, etc.
            </p>
            <p>
              <span className="text-muted-foreground">Python API: </span>
              <code className="text-[11px] bg-muted px-1.5 py-0.5 rounded break-all">
                {PYTHON_API_STREAM_ITER_RECORDS}
              </code>
              <span className="text-muted-foreground"> · HTTP </span>
              <code className="text-[11px]">POST /api/v1/stream/sse</code>
            </p>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {showBatch ? (
          <>
            {batchMeta?.errors && batchMeta.errors.length > 0 && (
              <p className="text-sm text-amber-700 dark:text-amber-400 mb-3">
                Sink reported: {batchMeta.errors.join('; ')}
              </p>
            )}
            {batchMeta?.pythonApi && (
              <p className="text-xs text-muted-foreground mb-3">
                <span className="font-medium text-foreground">Python API: </span>
                <code className="text-[11px] bg-muted px-1.5 py-0.5 rounded break-all">
                  {batchMeta.pythonApi}
                </code>
              </p>
            )}
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="text-sm text-muted-foreground">Output format:</span>
              <div className="flex rounded-md border border-input overflow-hidden">
                <button
                  type="button"
                  onClick={() => onOutputFormatChange('json')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium transition-colors ${
                    outputFormat === 'json'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background hover:bg-muted'
                  }`}
                >
                  <FileJson className="h-4 w-4" />
                  JSON
                </button>
                <button
                  type="button"
                  onClick={() => onOutputFormatChange('csv')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium transition-colors border-l border-input ${
                    outputFormat === 'csv'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background hover:bg-muted'
                  }`}
                >
                  <FileSpreadsheet className="h-4 w-4" />
                  CSV
                </button>
              </div>
              <Button
                variant="outline"
                size="sm"
                disabled={!batchResults?.length}
                onClick={() => {
                  if (!batchResults?.length) return;
                  const content =
                    outputFormat === 'json'
                      ? JSON.stringify(batchResults, null, 2)
                      : recordsToCsv(batchResults);
                  const blob =
                    outputFormat === 'json'
                      ? new Blob([content], { type: 'application/json' })
                      : new Blob([content], { type: 'text/csv' });
                  const ext = outputFormat === 'json' ? 'json' : 'csv';
                  downloadBlob(blob, `generated_data.${ext}`);
                }}
                className="ml-2"
              >
                <Download className="h-4 w-4 mr-2" />
                Save
              </Button>
            </div>
            {batchResults && batchResults.length > 0 ? (
              <pre className="bg-muted rounded-md p-4 overflow-auto max-h-[600px] text-xs font-mono whitespace-pre-wrap">
                {outputFormat === 'json'
                  ? JSON.stringify(batchResults, null, 2)
                  : recordsToCsv(batchResults)}
              </pre>
            ) : (
              <p className="text-sm text-muted-foreground py-6">
                No records returned (check sink output or generation count).
              </p>
            )}
          </>
        ) : showStream ? (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" onClick={onClearStream}>
                <Trash2 className="h-4 w-4 mr-2" />
                Clear buffer
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={streamRecords.length === 0}
                onClick={() => {
                  const ndjson = streamRecords
                    .map((r) => JSON.stringify(r))
                    .join('\n');
                  downloadBlob(
                    new Blob([ndjson], { type: 'application/x-ndjson' }),
                    'stream.ndjson',
                  );
                }}
              >
                <Download className="h-4 w-4 mr-2" />
                Download NDJSON
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={streamRecords.length === 0}
                onClick={() => {
                  const content = JSON.stringify(streamRecords, null, 2);
                  downloadBlob(
                    new Blob([content], { type: 'application/json' }),
                    'stream.json',
                  );
                }}
              >
                <Download className="h-4 w-4 mr-2" />
                Download JSON array
              </Button>
            </div>
            {streamRecords.length === 0 && !streaming ? (
              <p className="text-sm text-muted-foreground text-center py-12">
                Start a stream from the Run panel to see rows appear here.
              </p>
            ) : (
              <pre className="bg-muted rounded-md p-4 overflow-auto max-h-[600px] text-xs font-mono whitespace-pre-wrap">
                {streamRecords.map((r) => JSON.stringify(r)).join('\n')}
              </pre>
            )}
          </div>
        ) : showInferredInResults && inferredFields ? (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground mb-3">Inferred schema</p>
            {inferredFields.map((field) => (
              <div
                key={field.name}
                className="flex items-center gap-3 p-3 rounded-md border"
              >
                <span className="font-mono text-sm font-medium flex-1">
                  {field.name}
                </span>
                <span className="text-xs px-2 py-1 rounded bg-primary/10 text-primary font-medium">
                  {field.type}
                </span>
                {field.nullable && (
                  <span className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground">
                    nullable
                  </span>
                )}
              </div>
            ))}
          </div>
        ) : showJsonSchemaInResults && jsonSchemaFields ? (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground mb-3">From JSON Schema</p>
            {jsonSchemaFields.map((field) => (
              <div
                key={field.name}
                className="flex items-center gap-3 p-3 rounded-md border"
              >
                <span className="font-mono text-sm font-medium flex-1">
                  {field.name}
                </span>
                <span className="text-xs px-2 py-1 rounded bg-primary/10 text-primary font-medium">
                  {field.type}
                </span>
                {field.nullable && (
                  <span className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground">
                    nullable
                  </span>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center text-muted-foreground py-16">
            <p>
              Use a tab to define a schema, then run a batch or stream from the panel
              above. Recipe (YAML) uses its own Run button for full pipelines and
              sinks.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
