/**
 * Incremental SSE parser for fetch() streaming bodies (Bearer-safe vs EventSource).
 */

export type SseParsedEvent = {
  event: string;
  data: string;
};

/** Parse one SSE block (text between blank lines). */
export function parseSseBlock(block: string): SseParsedEvent {
  let event = 'message';
  const dataLines: string[] = [];
  for (const line of block.split('\n')) {
    if (line.startsWith('event:')) {
      event = line.slice(6).trim();
    } else if (line.startsWith('data:')) {
      dataLines.push(line.slice(5).trimStart());
    }
  }
  return { event, data: dataLines.join('\n') };
}

export type StreamRecordYield =
  | { kind: 'record'; record: Record<string, unknown> }
  | { kind: 'error'; message: string; detail?: unknown };

/**
 * Read a text/event-stream body and yield parsed record or error events.
 */
export async function* streamSseRecords(
  response: Response,
  options?: { signal?: AbortSignal },
): AsyncGenerator<StreamRecordYield> {
  const reader = response.body?.getReader();
  if (!reader) {
    yield { kind: 'error', message: 'No response body' };
    return;
  }

  const decoder = new TextDecoder();
  let buffer = '';
  const signal = options?.signal;

  try {
    while (true) {
      if (signal?.aborted) {
        return;
      }
      let readResult: ReadableStreamReadResult<Uint8Array>;
      try {
        readResult = await reader.read();
      } catch (e) {
        if (signal?.aborted) return;
        if (e instanceof DOMException && e.name === 'AbortError') return;
        throw e;
      }
      const { done, value } = readResult;
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      while (true) {
        const sep = buffer.indexOf('\n\n');
        if (sep === -1) break;
        const block = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        const trimmed = block.trim();
        if (!trimmed) continue;

        const { event, data } = parseSseBlock(trimmed);
        if (!data) continue;

        if (event === 'error') {
          try {
            const parsed = JSON.parse(data) as Record<string, unknown>;
            const msg =
              typeof parsed.message === 'string'
                ? parsed.message
                : typeof parsed.error === 'string'
                  ? parsed.error
                  : JSON.stringify(parsed);
            yield { kind: 'error', message: msg, detail: parsed };
          } catch {
            yield { kind: 'error', message: data };
          }
          return;
        }

        if (event === 'record' || event === 'message') {
          try {
            const record = JSON.parse(data) as Record<string, unknown>;
            if (record && typeof record === 'object' && 'error' in record) {
              const err = (record as { error?: unknown }).error;
              const message =
                typeof err === 'string'
                  ? err
                  : err && typeof err === 'object' && 'message' in err
                    ? String((err as { message: unknown }).message)
                    : JSON.stringify(err);
              yield { kind: 'error', message };
              return;
            }
            yield { kind: 'record', record };
          } catch {
            yield { kind: 'error', message: `Invalid JSON in SSE data: ${data.slice(0, 80)}` };
            return;
          }
        }
      }
    }

    const tail = buffer.trim();
    if (tail) {
      const { event, data } = parseSseBlock(tail);
      if (data && (event === 'record' || event === 'message')) {
        try {
          yield { kind: 'record', record: JSON.parse(data) as Record<string, unknown> };
        } catch {
          /* ignore trailing garbage */
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}
