import type { GenerateField, RecipeRunRequest } from '@/lib/types';

/** Sink shape sent to POST /recipes/run (matches RecipeSinkFields value). */
export type RecipeSinkPayload = {
  type: string;
  config: Record<string, unknown>;
};

export function applyRecipeSinkPolicy(
  sink: RecipeSinkPayload,
  recipeSinkMode: 'memory' | 'full',
): RecipeSinkPayload {
  return recipeSinkMode === 'full' ? sink : { type: 'memory', config: {} };
}

export function buildRecipeRunRequestFromFields(
  name: string,
  fields: GenerateField[],
  generation: { count: number; seed?: number },
  sink: RecipeSinkPayload,
  recipeSinkMode: 'memory' | 'full',
): RecipeRunRequest {
  const effective = applyRecipeSinkPolicy(sink, recipeSinkMode);
  return {
    name,
    description: '',
    schema: { fields },
    generation: {
      count: generation.count,
      ...(generation.seed !== undefined ? { seed: generation.seed } : {}),
    },
    sink: effective,
  };
}
