/** TypeScript type definitions for PyCatalyst API. */

// Auth
export interface AuthMeResponse {
  username: string;
  auth_disabled: boolean;
}

export interface AuthLoginResponse {
  access_token: string;
}

// Generate
export interface GenerateField {
  name: string;
  type: string;
  nullable?: boolean;
  constraints?: Record<string, unknown>;
  children?: GenerateField[];
}

export interface GenerateRequest {
  name: string;
  fields: GenerateField[];
  count: number;
  seed?: number;
}

export interface GenerateResponse {
  records: Record<string, unknown>[];
  count: number;
  schema_name: string;
  duration_ms: number;
  seed?: number;
  /** Python entrypoint that produced records (for docs / UI). */
  python_api?: string;
}

/** Body for POST /api/v1/stream/sse (matches StreamSSERequest). */
export interface StreamSSERequest {
  name: string;
  fields: GenerateField[];
  max_records: number;
  interval_ms?: number;
  seed?: number;
}

// Infer
export interface InferRequest {
  records: Record<string, unknown>[];
  name?: string;
}

export interface InferField {
  name: string;
  type: string;
  nullable: boolean;
  constraints?: Record<string, unknown>;
}

export interface InferResponse {
  name: string;
  fields: InferField[];
  field_count: number;
}

// Recipes
export interface RecipeRunRequest {
  name: string;
  description?: string;
  schema: Record<string, unknown>;
  generation?: Record<string, unknown>;
  sink?: Record<string, unknown>;
}

export interface RecipeRunResponse {
  records: Record<string, unknown>[];
  count: number;
  records_sent: number;
  sink_type: string;
  duration_ms: number;
  errors?: string[];
  /** Python entrypoint (recipe runner orchestrates engine + sink). */
  python_api?: string;
}

export interface RecipeTemplateItem {
  name: string;
  description: string;
}

export interface RecipeListResponse {
  recipes: RecipeTemplateItem[];
}

export interface RecipeTemplateYamlResponse {
  yaml: string;
}

// ML / Model Training
export interface MlRunRequest {
  config: string;
}

export interface MlRunResponse {
  name: string;
  backend: string;
  metrics: Record<string, number>;
  artifacts: Record<string, string>;
  training_history: Record<string, unknown>[];
  duration_seconds: number;
  persisted_model_id: string | null;
  persisted_artifact_count: number;
}

export interface MlModelSummary {
  id: string;
  name: string;
  backend: string;
  status: string | null;
  duration_seconds: number | null;
  timestamp: string | null;
  metrics: Record<string, unknown>;
  artifact_names: string[];
}

export interface MlModelDetail extends MlModelSummary {
  config: Record<string, unknown> | null;
  training_history: Record<string, unknown>[];
}

export interface MlModelListResponse {
  models: MlModelSummary[];
  total: number;
  limit: number;
  offset: number;
  sort_by: 'timestamp' | 'name' | 'backend' | 'duration_seconds';
  sort_order: 'asc' | 'desc';
}

export interface MlModelArtifactListResponse {
  model_id: string;
  artifact_names: string[];
}
