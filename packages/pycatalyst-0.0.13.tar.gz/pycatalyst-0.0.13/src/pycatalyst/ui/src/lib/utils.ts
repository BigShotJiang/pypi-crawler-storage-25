import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

/**
 * Utility function to merge Tailwind CSS classes
 * This is the main utility used by shadcn/ui components
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format a date value with configurable Intl options.
 * All date formatting in the app should go through this helper.
 */
export function formatDate(
  date: string | Date | null | undefined,
  options?: Intl.DateTimeFormatOptions,
): string {
  if (!date) return 'N/A';
  try {
    const d = typeof date === 'string' ? new Date(date) : date;
    const opts: Intl.DateTimeFormatOptions = options ?? {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    };
    return d.toLocaleString('en-US', opts);
  } catch {
    return String(date);
  }
}

/** Preset: long date with time (e.g. "January 15, 2024, 2:30 PM") */
export function formatDateTime(date: string | Date | null | undefined): string {
  return formatDate(date, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/** Preset: short date (e.g. "Jan 15, 2024") */
export function formatDateShort(date: string | Date | null | undefined): string {
  return formatDate(date, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

/** Preset: short date with time (e.g. "Jan 15, 2024, 2:30 PM") */
export function formatDateTimeShort(date: string | Date | null | undefined): string {
  return formatDate(date, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Truncate string with ellipsis
 */
export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.slice(0, length) + '...';
}

/**
 * Debounce function
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- `any` is required in generic function constraints for proper type inference
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null;

  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      timeout = null;
      func(...args);
    };

    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}
